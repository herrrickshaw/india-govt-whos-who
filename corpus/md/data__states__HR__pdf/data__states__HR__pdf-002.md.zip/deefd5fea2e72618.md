---
doc_id: "deefd5fea2e72618"
source_url: "https://hreyahs.gov.in/saksham/notification/notification_110.pdf"
ministry: "Employment Department, Haryana"
title: "View"
date: ""
pages: 26
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e57bd84a154a2b9d"
---

<!-- page 1 -->

1

Educated Youth Allowance and Honorarium Scheme -2016
A. Introduction
“Educated Youth Allowance and Honorarium Scheme-2016” has been approved by the
Haryana Government to provide monthly Unemployment Allowance to educated youth and
Honorarium to the eligible 10+2/graduate/post graduate applicants for honorary assignment in
various Departments/Boards/Corporations/Registered Societies etc. under Haryana Government
and in Private companies/enterprises.
B. Objectives:
a) The scheme aims to provide Unemployment Allowance & Honorarium to the
eligible youth.
b) This scheme also intends to provide allowance to eligible educated unemployed
youth of Haryana for their skill up-gradation.
c) This is expected to enable such youth to develop their skill which in turn will enable
them to take up employment or self-employment in the Sector of their choice, since
this scheme empowers the youth to choose the Sector in which they would like to
develop their skill.
C. Details of the Scheme
1. Short title & commencement:
a) The scheme is named as “Educated Youth Allowance and Honorarium Scheme2016 (EYAHS)”. It is popularly known as Saksham Yuva Scheme (SYS)1.
b) The Scheme shall be implemented from November 1, 2016.
2. Definitions:
a) "Aadhaar" means the unique identity number issued by the Unique Identification
Authority of India (UIDAI), Government of India;
b) “APBS”- Aadhaar Payment Bridge System
c)

"Eligible applicant" means the educated unemployed youth who fulfils the
requisite eligibility conditions for disbursement of allowance and is ordinarily a
domicile of Haryana State.

_________________________________________________________________________
1. As per the tenth amendment - August,2019

<!-- page 2 -->

2

d) "Allowance" means the disbursement to the eligible educated unemployed youth
who are the domicile of Haryana State and are registered with the department with
live/active enrolment.
e)

"Honorarium"

means

the

amount

of

money

to

be

paid

to

the

eligible10+2/graduate/post graduate applicants engaged for honorary assignments
in a month.
f) "Department" means the Department of Employment, Government of Haryana;
g) "Employment Exchange" means any Employment Exchange set up by the
Haryana Government.
h) "Government "means the Government of Haryana in the Administrative
Department.
i) "State" means the state of Haryana Government.
j) "Form" means a form appended to this Scheme or on the web-portal of the
Scheme/Department.
k) "Live Register" means the valid employment index cards of those persons who
are registered in the Employment Exchanges of the State of Haryana.
l) "Controlling

Officers/Office

Incharge"

of

the

Employment Exchange

will include an Officer/Official to whom the powers of the officer incharge of
the Employment Exchange under this Scheme may have been delegated by the
Department.
m) "Engagement" means the engagement of an eligible applicant, as per assignment
in the respective administrative department, purely for the purpose to disburse
honorarium in lieu of 100 hours of honorary assignment in a month.
n) "Indenting department" means that administrative department/s, on whose
request; the eligible applicant has been assigned 100 hours honorary assignment
in a month.
o) "Family" means a group of individuals who share ties of blood, marriage, or
adoption; a group residing together and consisting of parents, children, and

<!-- page 3 -->

3

other relatives by blood or marriage; a group of individuals residing together who
have consented to an arrangement similar to ties of blood or marriage;
p) "Family income" means the gross annual income of the family where the eligible
applicant is associated as a family member;
q) “Honorary assignment” means any work which is an occasional or intermittent
character as required by the different Departments/Boards/Corporations/Societies
etc. under Government of Haryana. It is not employment provided by
Government of Haryana and therefore, labour laws are not applicable in case of
this scheme1 .

3. Component of scheme/ eligibility of criterion.
The scheme shall have two components, namely:A. Unemployment Allowance Sub-Scheme/Component; and;
B. Honorarium Sub-Scheme/Component.

A.

Unemployment Allowance Sub-Scheme
All eligible applicants shall be disbursed unemployment allowance at the rate given

in the following table. An eligibility criterion to qualify under this sub-scheme is following:i)

Applicant should be a domicile of Haryana.

ii)

Applicants, who are only Graduate or 10+2 qualified, should be registered in the
Live Register of any Employment Exchange in the State for a minimum period of
three (03) years as on 1st November of a year.

iii) 10+2/Graduate/Post-graduate applicants should be registered in the Live Register
of any Employment Exchange in the State on the date of application. If not already
registered, a 10+2/Graduate/Post-graduate qualified applicant may now register
on www.hrex.gov.in website of the Department.

_________________________________________________________________________
1. As per the eleventh amendment. - August, 2019

<!-- page 4 -->

4

iv) (a)

Applicant should have passed the 10+2 examination from a Board recognized

by Haryana Government.
OR
(b) Two year certificate/diploma course passed after Matric from any
Board/University recognized by Haryana Government.
v)

(a)

Applicant should be holding a Graduate degree from a University recognized
by Haryana Government.
OR

(b) Applicant should have passed any recognized three year certificate/diploma
course after 10+2.
vi) Applicant should hold a Post-graduate degree from a University recognized by the
Haryana Government.
vii) Applicant’s age should be between 21 to 35 years.
viii) Applicant should not be an employee dismissed from Government Service.
ix) Applicant should not be in any kind of employment e.g. public/private
sector/quasi-government or self-employment.
x) The annual family income of applicant shall not exceed rupees three lakhs (Rs.3
lakhs) from all sources.
Rate of allowance (per month)1 is as follows:
Qualification

Rate of Allowance (w.e.f. 01-05-2025)
@ Rs./ per month

(for both Male & Female)
Matriculation

100/- *
* The applicants availing benefits under the earlier
scheme will be disbursed allowance, till they attain
the age of 35 years. Under the new scheme w.e.f.
01.11.2016, the minimum qualification is 10+2.

10+2

1,200/-

Graduates

2,000/-

Post-Graduates

3,500/-

______________________________-___________________________________________
1. As per the seventeenth amendment. – May, 2025

<!-- page 5 -->

5

B. Honorarium Sub-Scheme/Component
(1)

The eligible 10+2/graduate/post-graduate unemployed youth shall be paid an
additional amount as honorarium up to the limit of Rs. 6,000 per month for up to 100
hours of honorary assignment in a month in various Departments/Boards/
Corporations/Registered Societies etc. under Haryana Government and in Private
companies/enterprises (as per their requirement) with the assistance of Department of
Industries and Commerce, Haryana.

Note: (a) 25% of this honorarium, in lieu of the honorary assignments in various
Departments/Boards/ Corporations etc. under Haryana Government shall be
given by the Department of Employment as per number of hours of honorary
assignment performed by the Saksham Yuva @ Rs.60/- per hour from the
approved budget and head of the existing UEA Scheme-2005. Remaining
75% of the honorarium shall be given by concerned indenting department
directly into the account of deployed Saksham Yuva from their budget.1
(b) The honorarium to the eligible 10+2/graduate/post-graduate applicants engaged
for honorary assignments in the Private companies/enterprises will NOT be
paid by the Department of Employment but by the concerned
company/enterprise. For this purpose, Department of Industries and
Commerce, Haryana shall be the Nodal Department. The Unemployment
allowance of 1,200/2,000/3,5004 shall also be paid by the concerned private
company/enterprises2. However Unemployment Allowance of those
Saksham Yuva, who have been approved for honorary work till 1 st April,
2018, will be paid by Employment Department not by concerned Private
Companies/Enterprises which deploys them for honorary work3.
1. As per the sixteenth amendment, (a) of point 1 is amended - February, 2023
2. As per the second amendment, point (b) is amended – February, 2017
3. As per the sixth amendment, point (b) is amended – May, 2018
4. As per the seventeenth amendment. – May, 2025

<!-- page 6 -->

6

(2)

The eligibility conditions for giving the honorary assignment to a 10+2/graduate/post
graduate applicant shall be as follows:-

i) Applicant should be a domicile of Haryana.
ii) Applicant should be registered in the Live Register of the concerned Employment
Exchange. If not already registered, a 10+2/graduate/post-graduate qualified applicant
may simultaneously register on www.hrex.gov.in website of the Department
iii) The eligible Post Graduate/Graduate degree should have been obtained only through

regular courses1 from Punjabi University; Patiala1 and any recognized Universities

in

UT Chandigarh or NCT Delhi or Haryana. Those applicants who have obtained their
eligible degree through correspondence courses and been taking benefits under the
scheme will also continue to avail the benefits 1.
iv) Applicant should have passed 10+2 examination, as regular student, from any
recognized school, affiliated to Board of school Education Haryana, Bhiwani, Central
Board of School Education (CBSE) Delhi and Indian Certificate of secondary Education
(ICSE) Board, Delhi, situated in Haryana and UT Chandigarh only2.
v) Applicant’s age should be between 18 to 35 years for 10+2 2 and 21 to 35 years for
graduate/post graduate.
vi) Applicant should not have passed 10+2 examination through correspondence/ National
Open School2.
vii)

Applicant should not be a regular student under full time course2.

viii) Applicant should not be an employee dismissed from Government Service.
ix) Applicant should not be in any kind of employment e.g., public/private sector/quasigovernment or self-employment.
x) The annual family income of applicant shall not exceed rupees three lakhs (Rs.3 lakhs)
from all sources.
____________ __ __ _____________________________________________ __ ______
1. As per the fifth Amendment – April,2018
2. As per the tenth amendment, sub point iv) , vi) and vii) of 2 is inserted and sub point v) of 2
is amended- August,2019

<!-- page 7 -->

7

xi) The honorarium shall be paid for a maximum period of 03 years (36 months) or 35 years
of age, whichever is earlier. Period of 3 years (36 months) shall start from date of
allotment of honorarium assignment and age of 35 years shall be the exact date of
completion of 35 years 1.
xii)

The registration for this component of the scheme shall be online in digital mode

only on https://hreyahs.gov.in.
(3)

Further, the applicant shall furnish a self-attested declaration with the following
conditions:-

i)

That the house of applicant has a functional toilet. If the applicants house no functional
toilet he/she shall make a functional toilet within two months from the date of registration1.

ii)

That the family of the applicant has no pending dues payable to/is defaulter of the Power
Department or its companies and if in default, then she/he undertakes to utilize part of the
honorarium /allowance towards clearance of the dues.

iii) That the family of the applicant is not a defaulter of any Co-operative Bank and if in
default, then he/she undertakes to utilize part of the honorarium/allowance towards
payment of such dues1.
iv) That there is no encroachment on public/Panchayat land by any member of his/her family.

v)

That the family of the applicant is not a defaulter of house tax payable to an Urban Local
Body and if in default, then he/she undertakes to utilize part of the honorarium/allowance
towards of such dues1.

(4)

Honorary assignments (as per para (6)) will be offered seniority-wise and the
seniority of the applicants shall be maintained district-wise, either in the district of
his choice

OR where he is ordinarily resident of, and be determined as per the

following:i) Firstly, the applicant with higher age, as per the list, shall be higher in seniority;

________________________________________________________________________
1: As per the first amendment. - January, 2017

<!-- page 8 -->

8

ii)

In case the age is same, then the applicant who has obtained the 10+2/graduate/postgraduate degree earlier, shall be senior (for this the year of successful completion of
10+2/graduate/post-graduate studies shall be considered);

iii)

In the rare case where the age and year of 10+2/Graduate/PG certificate/degree is
identical,

then

the

applicant

obtaining

higher

percentage

of

marks

in

10+2/Graduation/Post-Graduation examination shall be senior. In case any applicant
acquires more than one Post-Graduation degree, the one with the highest percentage of
marks shall be considered.
iv)

The seniority list of a particular district shall be generated on the last working day of
the month for the purpose of assigning the honorarium assignment in the succeeding
month1.

v)

All those applicants who have not been assigned any honorarium assignment in a
particular month have to be taken in the seniority list for the assignment of honorary
assignment in the succeeding month1.

vi)

Notwithstanding above provision from (i) to (v), the applicant who got seniority in the
previous month to get the honorary work will retain his same seniority for the coming
months too for all purposes except in those cases where a requisitioning department
requests for a specific educational qualification2. In addition, priority will be given to
all those Saksham Yuva who have attended Skill Training Programme4. Overall
preference will be given in seniority for deployment to those applicants enrolled under
Saksham Yuva Scheme who are eligible under the Mukhyamantri Antyodaya Parivar
Utthan Yojana (MMAPUY) 5.

(5) An applicant must indicate a district of his choice where he would like to do an
honorary assignment at the time of online registration. He/she may change this option
of district once in six months, in the first3 fortnight of March & September every
year, through the online portal https://hreyahs.gov.in.
________________ __ _____________________________________________ __ ______
1.
2.
3.
4.
5.

As per the first amendment, sub point iv) and v) of 4 is inserted - January, 2017
As per the third amendment, sub point vi) of 4 is inserted.- April, 2017
As per twelfth amendment - January, 2020
As per thirteen amendment – March, 2020
As per the fifteenth amendment.- November, 2021

<!-- page 9 -->

9

(6) While submitting his/her application, the applicant shall select five preferential work
options (illustrative only), out of the following:i)

Information, Education & Communication (IEC) and suchlike activities of
Haryana Government/Union Government schemes such as ‘Beti BachaoBeti Padao’, ‘Swachh Bharat Mission’, ‘National Health Mission’, EYAHS
etc.

ii) Marketing, Field publicity, Awareness generation and suchlike work in
Government Boards, Corporations and other government agencies.
iii) Survey work such as SRDB, BPL etc.
iv) Remedial classes for weak students of Government Schools.
v)

Coaching classes for competitive exams.

vi) Awareness generation & survey work such as for water conservation,
micro/minor irrigation, soil testing, stoppage of burning of paddy
stubble/chaff in fields and other such activities.
vii) Sports and Yoga coaching classes in schools, colleges and village panchayats
for the so qualified and eligible 10+2/graduate/post-graduate applicants/
beneficiaries.
viii) Old age home services.
ix) Traffic Marshal/Home guard services related assignment & assistance.
x)

Any other work, as identified by the Government, a Department or Deputy
Commissioner at the field level in keeping with the specific needs of the area.

xi) In the private sector enterprises/establishments, the following sectors have
been broadly indicated by the Industries Department for the honorary
assignments:IT and ITeS.
Auto

and

auto-ancillary

Industries.

Textiles.
Banking, Financial Services and Insurance.
Retail Industry
Agriculture & Allied Sector etc.
xii) As far as is practicable, the beneficiary shall be given an honorary assignment out
of his/her preferences as indicated by him/her, however, he/she will be required to
undertake any honorary assignment as entrusted to him/her.

<!-- page 10 -->

10

(7)

Those eligible 10+2/graduate/post-graduate applicants whom the designated Department
is not able to engage for the honorary assignments shall be given allowance @
₹1,200/2,000/3,5005 per month, subject to the condition that the applicant shall attend skill

training under the various skill development programs being organized by the
Government as and when his/her name is sponsored and nominated for such training by
the Department. The skill training options (at least ten in all) shall be given by the
applicant at the time of registration from the over 200 skill trainings indicated in the online
registration form on the online portal https://hreyahs.gov.in (Annexure-I of the
identified priority areas and the skills of HSDM as appended may kindly be seen).
a) In case a beneficiary fails to attend a scheduled skill training at first instance,
his/her allowance will be suspended; and;1
b) If he/she does not attend the second such scheduled skill training, he/she will be
removed from the scheme1.
The eligible 10+2/graduate/post graduate applicant shall get unemployment
allowance @ ₹ 1,200/2,000/3,5005 from the month in which his/her application has been
approved instead of month of his registration on the portal under this scheme2. If the
application of the eligible 10+2/graduate/post graduate is approved on the last day of a
month, he/she will get the allowance of that month3.

(8)

The 10+2/graduate/post-graduate qualified Saksham Yuva who fails to attend to/report to
any honorary assignment he/she is nominated for, then 4 :a)

In the first instance, if he/she fails to report within 7 days, then the
unemployment allowance shall be discontinued and his/her name shall be kept
in abeyance/debar from the list of beneficiaries for one month;

1. As per the seventh amendment a) and b) of 7 are amended – August-2018
2. As per the third amendment. – April, 2017
3. As per the second amendment- Feburary,2017
4. As per the first amendment, Points 8 is inserted. – January, 2017 and later on replaced by
sixteenth amendment. – February, 2023
5. As per the seventeenth amendment. – May, 2025

<!-- page 11 -->

11

b) In the second instance, if he/she fails to report within 7 days, then the
unemployment allowance shall be discontinued and his/her name shall be kept
in abeyance/debar from the list of beneficiaries for one year;1

c) In the third instance, if he/she fails to report within 7 days, then he/she will be
rejected permanently from the scheme.1
(9)

If an applicant leaves the honorary assignment after few days of joining the assigning
without giving any reason, he/she will be declared ineligible for one year for any type of
honorary assignment. In such case, he/she can appeal for honorary assignment by submitting
valid reasons to the DC of the concerned District whose decision shall be final 2.

(10)

If the indenting department put the beneficiary on training required for honorary assignment
that shall be treated as part of honorary assignment provided the duration of such training
does not exceed 2 working days2.

(11)

A cap is to be provided to the “Saksham Yuva” (Young Unemployed Voluntary Associate) as
a token identity and honour to these youth. This cap will be procured and distributed by the
Head Quarter/Concerned District Employment Officer after the following due procedure 2.

(12)

The SAKSHAM YUVA Scheme is extended to incorporate registered Science, Engineering
and Science equivalent Graduates of the State. The registration for these graduates on
SAKSHAM Portal will start from April 1st, 2017. Commerce4 and Arts Graduates 4 are also
included in the scheme. The Saksham Yuva once deployed will get ₹ 8,000/- (Allowance ₹
2,0005 + Honorarium ₹ 6,000/-) for 3 years or 35 years of age whichever is earlier. The
eligibility conditions for Unemployment Allowance & Honorarium under the scheme shall
be as follows as approved in original scheme document:3
1.
2.
3.
4.
5.

As per the first amendment, Points 8 is inserted. – January, 2017 and later point b) is replaced
and c) is inserted under sixteenth amendment. – February, 2023
As per the first amendment, Points 9, 10 and 11 are inserted. – January, 2017
As per the third amendment point 12 is inserted (April, 2017) and later amended.
BA (Maths) as per third amendment (April, 2017), Commerce Graduates as per fourth amendment
(June, 2017) and Arts Graduates by eighth amendment (November, 2018) are included.
As per the seventeenth amendment. – May, 2025

<!-- page 12 -->

12

a)

All degrees of BE, B.Tech, B.Sc, B.Com2 and B.A.2 are to be considered as
eligible provided they have been granted by a recognized University/affiliated
colleges in the State of Haryana, NCT Delhi, UT Chandigarh and Punjabi
University, Patiala 1 only through regular courses 1.

b) Other eligibility conditions e.g. income, domicile etc. shall remain the same as
for Post-Graduate unemployed youths.
(13) The SAKSHAM YUVA Scheme is extended to incorporate registered 10+2 applicants
of the State. The Saksham Yuva once deployed will get ₹ 7,200/- (Allowance ₹ 1,2005
+ Honorarium ₹ 6,000/-) for 3 years or 35 years of age whichever is earlier. The
eligibility conditions for Unemployment Allowance & Honorarium under the scheme shall
be as follows 3:

a) Applicant should have passed 10+2 examination, as regular student, from any
recognized school, affiliated to Board of school Education Haryana, Bhiwani,
Central Board of School Education (CBSE) Delhi and Indian Certificate of
secondary Education (ICSE) Board, Delhi, situated in Haryana and UT Chandigarh
only.
b) Applicant’s age should be between 18 to 35 years.
c) Applicant should not have passed 10+2 examination through correspondence/
National Open School.
d) Applicant should not be a regular student under full time course.
e) Other eligibility conditions e.g. income, domicile etc. shall remain the same as for
Post-Graduate unemployed youths.
(14) The

cost

of

travelling

of

Saksham

Yuva

who

are

deployed

by

Departments/Boards/Corporations in any field work is to be reimbursed by the
concerned Indenting Department as per the actual cost of travelling by cheapest mode
of travel in the district i.e. Bus/Train and Auto (preferably shared) if bus/train is not
available 4.

_________________________________________________________________________
1.

As per the Fifth Amendment – April, 2018.

2.

BA (Maths) as per third amendment (April, 2017), Commerce Graduates as per fourth amendment
(June, 2017) and Arts Graduates by eighth amendment (November, 2018) are included.
As per the tenth amendment, point 13 (including sub points a) to e) ) is inserted.- August, 2019
As per ninth amendment, point no 14 is inserted- March, 2019
As per the seventeenth amendment. – May, 2025

3.
4.
5.

<!-- page 13 -->

13

4.

Application for the Allowances/ Honorarium
A Registered applicant with employment exchange shall apply online in digital
mode only on https://hreyahs.gov.in. If applicant is not already registered in the “Live
Register of Employment Exchange” he/she may now registered on www.hrex.gov.in
website of the Department.

5.

Processing of applications & Entitlement for honorarium:
On receipt of the online application for inclusion as eligible applicant, the
controlling officer of the Employment Exchange shall verify the credentials of the
applicant. Prior to entry into the honorarium component, the eligible applicant shall be
at a liberty to opt for five preferential jobs, in ascending order, out of the available job
profiles/options and place, as available. As far as is practicable, the beneficiary shall be
given an honorary assignment out of his/her preferences as indicated by him/her, however
he/she will be required to undertake any honorary assignment as entrusted to him/her. All
those eligible applicants, for engagement for the purpose of honorarium, shall furnish a
self-declaration/undertaking in respect of his house/family as per prescribed format
(Annexure-II).
The

controlling

officer

shall

provide

the

list

of

eligible/entitled

10+2/graduate/post-graduate applicants to the Divisional/District Employment Officer
of the District who will comply the list of all eligible applicants as work option wise and
forward it to the Deputy Commissioner of the District. The Deputy Commissioner will
coordinate with the departments to assign 100 hrs/month honorary assignments to the
eligible applicant as per seniority list. The Indenting department after getting the list of
eligible list of applicants under this sub-scheme shall allot the honorary assignment for
100 hrs/month. However, it is being clarified that for the ease of taking maximum work
from the applicants/beneficiaries and ease of calculation of number of hours the
department will take the work for 12½ days in a month.

<!-- page 14 -->

14

(i) On the SAKSHAM portal, if the SAKSHAM YUVA is deployed by any
indenting department/PSU/Universities/Boards, then he/she has to be deployed
for at least 3 years or on attaining 35 years of age, whichever is earlier1. To boost
the rotation of Saksham Yuva in various Departments/Boards/ Corporations etc.,
an Indenting Department will deploy Saksham Yuva for maximum 6 months (3
months Demand+ 3 months Extension). After 6 months it will relieve the
deployed Saksham Yuva and demand a fresh2.
(ii) The deployment of SAKSHAM YUVA for honorary assignment will be done
tehsil wise by 20th of every month and they will report on work within a week.
Therefore, requisitions from indenting departments will be obtained by 25th of the
previous month and be sanctioned in the first two working days of next month.3
(iii) “All indenting departments will send their demands tehsil wise in the following
manner:
a) For demand of Saksham Yuva upto 50 and period upto one month, then the
approval of demands will be taken from concerned Deputy Commissioner.
b) For demand of more than 50 Saksham Yuva and for the period more than one
month, indenting departments shall send the demand to their respective HOD for
the approval.3
The demand for DC office will be approved by concerned Divisional Commissioner.
After the certification of approval of demand from concerned HOD, the demand letter
shall also be uploaded on the portal with this certification from HOD.
The indenting department at the end of the month will mandatorily assess the performance
of all deployed Saksham Yuvas on honorary assignment and grade them on the basis of fixed
yardsticks (Annexure-III). Indenting Department will not send further demand for Saksham
Yuva unless performance assessment of all previously deployed Saksham Yuva is
completed.
1.
2.
3.

As per the third amendment, sub points (i), (ii) & (iii) of 5 are inserted – April, 2017
As per sixth amendment – May, 2018
As per sixteenth amendment Point ii) and iii) are amended - February, 2023.

<!-- page 15 -->

15

If the overall performance of Saksham Yuva is assessed as average or poor, then the
honorarium shall be deducted as per the following:
Performance

Deduction

Average

25 %

Poor

100% and rejection from the scheme

Further, in case the overall performance of Saksham Yuva is assessed as average or
poor thrice during the deployment period of 36 months, he/she will not be entitled for further
deployment on honorary assignment in any indenting department and he/she will avail only
UEA as per provision of the scheme.
The random physical inspection and verification in all indenting departments of the
work of deployed Saksham Yuva will be got done by the concerned Deputy Commissioner
through any officer.1
The district employment officer will prepare a list of those eligible
10+2/Graduate/Post Graduate applicants whom the designated department is not able to
engage for the honorary assignments and send the same to the Department of Industrial
Training and Skill Development. It will be the responsibility of the Department of Industrial
Training and Skill Development to enroll those applicants in appropriate Skill training module
available in their department.
Miscellaneous
Any fraudulent declaration, false information submitted by the eligible applicant shall invite
civil and/or criminal action, as per provisions under the applicable Acts, along with recovery of
the disbursed honorarium/allowance.
Once the eligible applicant crosses the age limit (35 years), as prescribed for allowance, the
Unemployment allowance shall be discontinued with immediate effect.
Honorarium for honorary assignments shall only be paid for a period of 3 years/36 months.
____________ __ __ _____________________________________________ __ __ ____
1. As per the sixteenth amendment – February, 2023.

<!-- page 16 -->

16

The honorarium to the eligible 10+2/Graduate/Post-graduate applicants engaged
for honorary assignments in the Private companies/enterprises will NOT be paid by
the Department of Employment but by the concerned company/enterprise. For this
purpose, Department of Industries and Commerce, Haryana shall be the Nodal
Department. The Unemployment allowance of ₹ 1,200/2,000/3,5004 shall also be paid
by the concerned private company/ enterprises 1. However Unemployment Allowance
of those Saksham Yuva, who have been approved for honorary work till 1st April, 2018,
will

be

paid

by

Employment

Department

not

by

concerned

Private

Companies/Enterprises which deploys them for honorary work2 .
If Saksham Yuva does not accept any job offer which comes at monthly
emolument equal or greater than twice the monthly honorarium i.e. ₹ 12,000 paid by
Govt. then his/her name should be deleted from the Scheme.3
The controlling officer shall periodically check the status of eligible applicants,
as per defined terms and conditions and a consolidated monthly report be forwarded to
the head of the department.
6.

Grievances Redressal Mechanism Fair
Opportunity for Being Heard:
In case of non-allotment of work by the Intending department of eligible applicant,
as the case may be, the eligible applicant may submit an application, in writing, to the
controlling officer. The Controlling Officer shall give the eligible applicant a reasonable
and fair opportunity for defending the case in person and it shall be responsibility of
indenting department to present before the controlling officer all relevant records for
passing a speaking order. The findings/order of the same shall be recorded for further
reference.
Appellate Authority/s:
First Appellate Authority: The concerned ADC of the District shall be First
Appellate Authority. Where the eligible applicant is aggrieved by any order of the

________________________________________ ____ _________________________________________
1. As per the second Amendment- February, 2017
2. As per the sixth amendment- May, 2018
3. As per the fourteenth amendment- April, 2021
4. As per the seventeenth amendment. – May, 2025

<!-- page 17 -->

17

Controlling Officer, he/she may, within 30 days of the date of communication of such
order, make an online1 application to the First Appellate Authority for revision against the
said order. Taking cognizance of order, the First Appellate Authority may confirm, alter or
rescind the decision of the Controlling Officer.

Second Appellate Authority: The Deputy Commissioner of the concerned district shall be
second and final appellate authority.
Provided that the Second Appellate Authority may entertain the application after the
expiry of the said period of fifteen days, if he is satisfied that the eligible applicant was
prevented by sufficient cause from filing the application in time.

Protection of Officers/officials from Personal Liability:
No suit, prosecution or other legal proceeding shall lie against any public servant or
any other acting for or anything in good faith done or intended to be done in pursuance of
the provisions of this scheme or of any directions made thereof.
7.

Power to Interpret, Amend and Relax
The power to interpret, change, amend, relax and removal of difficulties of the scheme
shall lie with the department. The communications regarding the interpretation and
alteration of this scheme shall be addressed to the Department of Employment by the
competent authority of the Indenting department concerned for their disposal.

------------x-------------

________________________________________ ____ _________________________________________
1. As per the tenth Amendment- August, 2019

<!-- page 18 -->

18

Annexure-I
Sectors
1

Agriculture
Allied Activities

Sub-Sector/Trades
&

1. Farm Machinery

16. Apiculture

2. Animal Husbandry

17. Minor Forest Product processing and
value addition,

3. Farm Mechanization

5. Fisheries& Allied Sector

18. Natural Fiber product processing and
value addition(Sericulture, Jute, cotton,
and diversified Products)

6. Agriculture

19. Pulses Cultivator

7.Plantation

20. Sugar Cane Cultivator

8. Horticulture

21. Citrus Fruit Grower

9. Floriculture

22. Bulb Crop Cultivator

10. Tractor Operator

23. Gardener

11. Harvesting Machine Operator

24. Beekeeper

12. Dairy Worker

25. Quality Seed Grower

13. Broiler Poultry Farm Worker

26. Green House Fitter

14. Hatchery Production Worker

27 Veterinary Field Assistant

15. Poultry and Allied Sector

28 Animal Health Worker

4. Precision farming

29. Solar Pump Technician
2

Textile
Allied

Apparel&

1. Garment Manufacturing

13. Weaving

2. Fashion Design.

14. Knitting & Processing for Cotton,

3. Garment making

15. Other Manmade & Synthetic Fibers

4. Handloom

16. Sewing Machine Operator

5. Brassware

17. Fabric Checker

6. Khadi

18.. Measurement Checker

7. Carpet

19. Sampling Tailor

<!-- page 19 -->

19

3

4

Automotive

Banking,
Finance
and
Insurance
Sector (BFSI)

8. Handicrafts

20. Hand Embroider

9. Handmade Paper and Paper Products

21. Garment Cutter-CAM

10. Home décor art

22. Quality Assessor

11. Ceramic Painting

23. Specialized Sewing Machine Operator

12. Spinning

24. Sampling Coordinator

1. Manufacturing

8. Maintenance Technician

2. Automotive Repair

9. Auto Body Technician

3. Auto Component Assembly Fitter

10.Washer

4. Machining Assistant

11. Welding Technician

5. Parts Picker

12. Automotive Sales

6. Press Shop Helper

13. Repair Painter – Auto Body

7. Quality Control Inspector

14. Service Technician

1. Banking Services

10. Debt Recovery Agent

2. Accounting Services

11. Accounts Executive (Recording &
Reporting)

3. Insurance Services
4. Mutual Fund Agent
5. Equity Dealer
6. Business Correspondent
7. Loan-approval Officer

12. Accounts Executive (Receivables &
Payables)
13. Accounts Executive (Payrolls)
14. Accounts Executive (Statutory
Compliance)

8. Life Insurance Agent
9. Small & Medium Enterprise Officer
(SME Officer)
5

Construction
Allied Activities

&

1. Construction Equipment Operator

13. Helper Electrician

2. Fabrication

14. Helper Painter & Decorator

3. Plumbing

15. Helper Laboratory & Field Technician

<!-- page 20 -->

20

6

Electronics
&
Telecommunication

4. Domestic Electrician

16. Bar Bender & Steel Fixer 17

5. Industrial Electrician

Reinforcement Fitter

6. Paint

18. Assistant Electrician

7. Wood Works

19. Assistant Plumber

8. Bamboo Fabrication

19. Plumber Masson

9. Carpentry

20. Plumber (Maintenance & Serving)

10. Masson General

21. Plumber General (Helper)

11. Masson Tiling

22. Plumber Welding Assistant

12. Masson Concrete

23. Plumber Products & Sales

1. Electronics System Design

5. Telecom Service Provider

2. Refrigeration and Air Conditioning

6. Handset Sales & Service

3. Consumer Electronics- Sales& Service

7. Customer Care Executive (Repair
Centre)

4. Network & Infrastructure Management

8. Optical Fiber Splicer
9. Optical Fiber Technician
10. Tower Technician
11. Field Maintenance Engineer\
7

8

Food Processing

1.

Industries

2. Fruit &Vegetable Products

9. Bread &Bakery

3. Cereals & Cereal Products

10. Spices& Condiments

4. Food Grain

11. Beverage

5. Edible Oil & Fats

12. Aerated Water &Soft Drinks

6.

Meat &Meat Products

13. Packaging of food products

7.

Fish & Fish Products

14. Pickles

Healthcare

Dairy Products

1. Medical and Nursing Healthcare

8. Sweets& Confectionery

6. Preventive Healthcare (including Nutrition
& Health Education)

<!-- page 21 -->

21
2. Machine Technician

7. Allied Healthcare

3. Lab Technician

8. Geriatric Healthcare

4. Community Healthcare

9. Health Counselor

5. Community Healthcare-Assistants
9

IT-ITeS

1. Information and Communication
Technology

3. Customer Care Executive (Call Centre)
4. Junior Data Associate

2. ICT Technician
10

11

12

13

Logistics
Transportation

&

Retail

Sports &
Education

Tourism
Hospitality

1. Courier & Logistics

7. Receiving Assistant

2. Warehouse Picker

8. Loading Supervisor

3. Knitting & Labeling

9. Consignment Booking Assistant

4. Warehouse Packer

10. Consignment Tracking Executive

5. Loader/Unloader

11. Mail Handler

6. Warehouse Supervisor

12. Courier Sorter

1. Store Operation

4. Cashier

2. Retail Services

5. Store Operator Assistant

3. Fast Moving Consumer Goods (FMCG)

6. Sales Associate

Physical 1. Sports &Goods Manufacture

&

3. Fitness Trainer

2. Sports service – Gym Instructor, Yoga
Instructor & other sports Instructor

4. Lifeguard

1. Food Production,

12. Food &Beverage Service

2. Cooking

13. Housekeeping

3. Hospitality

14. Travel & Tourism

4. Food& Beverage Services – Steward

15. Home Delivery Boy

5. Customer Service Executive (Meet &
Greet)

16. Dish Washer

6. Housekeeping Supervisor
7. Housekeeping Attendant (Manual)

5. Sports Masseur

17. Tandoor Chef
18. Travel Consultant

<!-- page 22 -->

22

14

15

Green Skills

8. Cleaner – Carpet & Chair

19. Ticketing Consultant

9. Cleaner – Pest Controller

20. Travel Insurance Executive

10. Kitchen Stewards

21. Visa Assistant Consultant

11. Bell Boy

22. Food & Beverage Stewards

1. Renewable energy

3. Green Retail

2. Rain Water Harvesting,

4. Allied green skills

Other Sectors such as 1. Spa and Wellness
Beauty
2. Beauty Culture& Hair Dressing,
&Wellness,
Security etc.
3. Naturopathy

11. Beauty Advisor
12. Décor Art-Mehandi
13. Fire & Safety Engineering

4. Assistant Spa Therapist

14. Security Services

5. Spa Therapist

15. Unarmed Security Guard

6. Pedicurist & Manicurist

16. Armed Security Guard

7. Assistant Nail Technician

17. CCTV Supervisor

8. Hair Stylist

18. Technical Helper Distribution – Power

9. Assistant Beauty Therapist

19. Helper-Power System Transmission

10. Beauty Therapist

<!-- page 23 -->

23

Annexure-II
Self-Declaration/ Undertaking form
I

S/o, D/o, W/o Sh.
solemnly affirm and declare that

Resident of
1. I am a domicile of Haryana state.

2. I have obtained my 10+2 certificate and Graduate/Post Graduate degree from -------------3. I am registered with the Employment Exchange -------------------, Registration No. -------from dated

.

4. My annual family income from all sources including that of spouse does not exceed Rs.
300000/- (3 lakh) from all sources
5. I am in the age of 18-35 or 21-35 years.
6. I am not a regular student under full time course.
7. I am not in any kind of employment e.g. public/private sector/quasi-government or selfemployment.
8. That I have a functional toilet in my house.
9. None of my family member is a defaulter of any Co- operative Bank.
10. There is no encroachment on public/Panchayat land by any member of my family.
11. That none of my family member is a defaulter of house tax payable to a Urban Local Body.
12. I shall stop receiving the allowance and inform the department of employment and the
concerned bank branch in case of me getting Placement/Job or becoming ineligible for
unemployment allowances/ honorarium. I further undertake to refund the whole amount
received by me with interest, for any period for which I am found ineligible, as decided by
the Govt.

PLACE:
DATE:

NAME OF THE APPLICANT

<!-- page 24 -->

24

Annexure-III

<!-- page 25 -->

25

<!-- page 26 -->

26
