---
doc_id: "0b60f9effdab456b"
source_url: "https://highereduhry.ac.in/Notices/1131.pdf"
ministry: "Higher Education Department, Haryana"
title: "Corrigendum regarding e-Tender for empanelment of companies/agencies for providing handholding support to government colleges and state universities of Haryana for getting/improving accreditation and ratings scores."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6b74b34a16153a35"
---

<!-- page 1 -->

Department of Higher Education, Government of Haryana
Shiksha Sadan, Ground & 1st Floor,
Sec - 5, Panchkula, Haryana (134105)
Corrigendum

With reference to NIT published in various newspaper regarding e-Tender for
empanelment of companies/agencies for providing handholding support to government
colleges and state universities of Haryana for getting/improving accreditation and ratings
scores.
Last date for the submission of bids has been extended to 27th June, 2019 till 5:00 PM.
Sd/Director Higher Education
Department of Higher Education
Government of Haryana
