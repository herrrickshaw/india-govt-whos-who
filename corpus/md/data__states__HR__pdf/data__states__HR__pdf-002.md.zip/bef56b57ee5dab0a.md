---
doc_id: "bef56b57ee5dab0a"
source_url: "https://cdn.s3waas.gov.in/s3a666587afda6e89aec274a3657558a27/uploads/2026/10/17933519957083.pdf"
ministry: "Kaithal"
title: "Order under Section 163 of the Bharatiya Nagarik Suraksha Sanhita (BNSS), 2023, the Explosive Act, 1884 & the Explosive Rules, in District Kaithal from 28-10-2026 to 31-01-2027"
date: ""
pages: 5
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "a809e19b0ccaf13f"
---

<!-- page 1 -->

A
4
OFFICE OF THE DISTRICT MAGISTRATE, KAITHAL
ORDER

Whereas, rising air pollution during the winter, specifically October to January months,
is a serious health concern especially with regard to high levels of Particulate Matters (PM)
such as PM 2.5 and PM 0 exceeding the National Ambient Air Quality Standards (NAAQS)
standards, 2009;

Whereas, several expert comments and other reports related to air pollution have
indicated that during this time period, air pollution in the State of Haryana is at its peak and it
has also been observed that various episodic events occurring during winter months aggravate
air pollution levels in the State of Haryana;

Whereas, it is a well established scientific fact that high air pollution causes serious
environmental risk with adverse effect on the health of people, particularly vulnerable sections
of the population like children, elderly and people with pre- existing respiratory and heart
disease, etc;

Whereas, amongst various events, emissions from bursting of fire crackers during
Diwali and other festivals like Gurupurab, Christmas, New Year eve etc, not only release
metal particles, dangerous toxins, harmful chemicals and noxious gases in the air but also
increases particulate matters (PM2.5 and PMI0) concentration in ambient air vis-a-vis
contributes to rise in pollution levels across Haryana;

Whereas, the issue of bursting of fire crackers and raising of air pollution has been
taken up by the Hon’ble Supreme Court as well as the Hon’ble National Green Tribunal
repeatedly and some of the landmark cases, with observations, are as under:

l. Writ Petition (Civil) No. 728 of 205, titled as Arjun Gopal & Ors. Vs. Union of India &
Ors., wherein Hon’ble Apex Court observed that “the health of the people in Delhi and in
the NCR must take precedence over any commercial or other interests.........and,
therefore, a graded regulation (of fire crackers) is necessary which would eventually
result in prohibition.” and also observed that “keeping in mind the adverse effect of Air
Pollution, the human right to breathe clear air and the human right to health, the Central
Government and other authorities should consider encouraging display fireworks
through community participation rather than individual bursting of fireworks. In addition
Hon'ble Apex Court observed that Use of Reduced Emission firecrackers (Improved
crackers) - (a) Avoidance of use of ash as desiccant or filler materials in crackers for
ae :
(s )
% 2
56
Ri XK eet
ie SN
: Kare’
E 2S at VED ua / Saat. &
C Scanned with OKEN Scanner

<!-- page 2 -->

i it 4 Nina Sp Sa ae
7 2

reduction in particulate matters by 5-20%. These can be implemented subject to
approval by PESO, and (b) usage of charcoal meeting specifications of explosives and
pyrotechnics as prescribed by PESO. Use of Reduced Emission Jirecrackers (Green
crackers: Safe water and air sprinklers (SWAS) - Low emission sound and light emitting
functional crackers with PM reduction by 30-35% and significant reduction in NOx and
SO> due to in-situ water generation as dust suppressant and low cost due to usage of low
cost oxidants. These can be implemented subject to approval by PESO.”

2. OA No. 249/2020, titled as Tribunal on its own Motion versus Ministry of Environment,
Forest, Climate Change and others, whereby Hon’ble NGT imposed total ban on sale and
use of all kind of fire crackers during COVID-9 pandemic in the NCR and all
cities/town in the Country where the Ambient Air Quality under the Poor and above
category, with further direction to restrict use of fire crackers in cities/towns, where air
quality is moderate or below to green cracker only and for duration of not more than 2
hours and only for celebration of any specified festivals or permitted occasions.

3. Civil Appeal No. 2865-2867 of 202I titled as Uttar Pradesh Udhyog Vyapar Pratinidhi
Mandar & Anr. Vs. Ministry of Environment Forest and Climate Change & Anr. etc.,
wherein Hon’ble Apex Court upheld the directions of Hon’ble Tribunal in OA No.
249/2020.

4, IA NO, 48692 OF 2022 and IA No. 04836 of 2023 in Writ Petition (Civil) No. 728 of
20I5 titled as Arjun Gopal & Ors. Vs. Union of India & Ors., wherein the Hon’ble
Supreme Court on it’s order dated 22/09/2023, rejected an interlocutory application (IA)
filed by The Tamil Nadu Fireworks and Amorces Manufacturers Association
(TANFAMA) to include reduced quantities of barium nitrate in firecrackers, reiterating
the directions issued in 209 and 202].

Whereas, while rejecting the above mentioned IAs the Hon’ble Apex Court
remarked that “at this stage allowing the use of Barium Nitrate merely because it is
indicated that the formulation as a whole would be 30 percent less polluting would in
fact be a retrograde step as compared to the effort that has been put in by various orders
of this Court. Therefore, at this stage, we are of the opinion that the prayer is not liable
to be granted. Further, the same would also apply to the request which was made on
behalf of some of the manufacturers to manufacture joined crackers.”

Whereas, CAQM letter dated 22.08.24 has directed to ensure the strict

i compliance of the orders(s) of Hon'ble Supreme Court and Hon'ble NGT for control
and regulation of sale and bursting of firecrackers.
: Whereas, keeping in view of the above mentioned background and in public interest, it
is necessary to prohibit the manufacture, sale and use of joined firecrackers (series crackers or
laris) & all kinds of fire crackers, except for Green Crackers. Barium salts in fireworks are also
८2
eB)
ee eet Joc
22000 tes oka mee ere J eis) |.
— ae Fie
C Scanned with OKEN Scanner

<!-- page 3 -->

4 3
to be banned, within the limits of District Kaithal as the same causes huge air/noise pollution and
solid waste problems.

Therefore, in compliance of the instructions received from the Government on the
suggestion of the Haryana State Pollution Control Board, I, Aparajita, I.A.S. District Magistrate,
Kaithal by exercising the powers vested upon me by the virtue of Section 63 of the Bhartiya
Nagarik Surksha Sanhita, 2023, the Explosive Act, I884 & the Explosive Rules and other
enabling powers as District Magistrate, Kaithal, do hereby prohibit the manufacture, sale,
bursting and use of joined firecrackers (series crackers or laris) & all kinds of fire crackers,
except for Green Crackers, besides ban of barium salts in the fireworks, within the limits of
District Kaithal as the same causes huge air/noise pollution and solid waste problems, for the
period from 28.0.2026 to 3.0.2027 except for the window given below:-

However, the windows for bursting of Green Crackers shall be as follows :

l. On Diwali days or on any other festivals like Gurupurab etc., when such fireworks
generally take place, bursting of Green Crackers would strictly be from 08:00 p.m. till
0:00 p.m. only.
2. On Christmas evening and New Year evening, when such fireworks start around
midnight, i.e. 2:00 a.m., bursting of Green Crackers would be from :55 p.m. till 2:30
a.m. only.
Moreover, no e-commerce websites, including Flipkart, Amazon, etc., shall accept any
online orders and effect online sales in the District Kaithal.
Orders of Hon’ble Supreme Court of India in IA No. 44727/202I, IA No. 48692/2022 &
IA No. 04836/2023 in Writ Petition (Civil) No. 728/205, Civil Appeal No. 2865-2867 of 202]
and NGT OA No. 249/2020 be strictly complied with.

Furthermore, the Regional Officer, Haryana State Pollution Control Board,

Kaithal is hereby directed to monitor the air quality regularly and upload the data on the
relevant websites as per the directions of the Hon’ble Apex Court and Central Pollution Control
Board, All the Departments/Boards/Corporations/Individuals are directed to expand full
cooperation for the same.

Superintendent of Police, Kaithal, District Municipal Commissioner, Kaithal, all
the Sub Divisional Magistrates, all Deputy Superintendent of Police/Tehsildars/Naib Tehsildars
/BDPOs, E.O./ Secretary, Municipal Committees, SHOs of all police Stations, Fire Officers,
Kaithal and other fire office staff shall enforce this order in letter and spirit. All the above
mentioned officers are hereby directed to conduct raids to enforce this order and submit reports
about the same, on a daily basis, to the office of the undersigned.

Non-compliance/violation of this order shall attract relevant penal action as per the
relevant sections of Section 223 of the Bhartiya Nyaya Sanhita, 2023 and other applicable
act/Rules, the Explosive Act 884 and the Explosive Rules, 2008.

Ko
E/ 44%
al Ne :
2 eae ae + ५
ao ig LSS pape eee PARA 7//
Hes saa किक cis
C Scanned with OKEN Scanner

<!-- page 4 -->

5
4
The District Information and Publi i 7 ‘
है ic Relation Offi aithal is di
the public aware about ill and harmful effects of Heads and + ie
hazards on bursting of firecrackers, through nukkud nataks, print oe a the health
know how of identifying green crackers from conventional ae hal eae ae
pares i है co shall also be publicized heavil
Further, he is directed to give wide publicity to this ord ४ 2
y to this order throughout the District Kaithal and thi
order should be sent to the press for wide publicity. District Inf . i F 5
shall be responsible to host a copy of thi ¥: District Informatics Officer, NIC, Kaithal
pawl thal goviny Py of this order on the official website of the district i.e.
; In view of the emergent situation, this order is passed ex-parte and is addressed to
the public at large.
Given under my hand and the seal of the Court, on this day of October, 2026.
co. .
Endst. No. : 35(9-3£39 /LPA Dated: AF-I5 —2026
A copy is forwarded to the following for information and necessary action:
l. Chief Secretary to Govt. Haryana, Chandigarh.
2. Additional Chief Secretary & Financial Commissioner to Govt. Haryana, Revenue &
Disaster Management Department Chandigarh.
3. Additional Chief Secretary to Govt. Haryana, Home Department Chandigarh.
4. State Election Commissioner of Haryana, Chandigarh.
5. Director General of Police, Haryana Chandigarh.
6. Commissioner, Karnal Division, Karnal.
7. IG.CID Haryana, Karnal.
8. I.G. of Police Karnal Range, Karnal.
9. District & Sessions Judge, Kaithal
0. All District Magistrates, in Haryana State.
. Member Secretary, Haryana State Pollution Control Board, Panchkula.
2. Superintendent of Police Kaithal.
3. Addl. Deputy Commissioner, Kaithal.
4, District Municipal Commissioner, Kaithal
5. Sub Divisional Magistrate Kaithal/Guhla/Kalayat.
6. C.E.O. Zila Parishad, Kaithal.
7. City Magistrate, Kaithal. ४
eae 5४%.
(3०
2 ‘
हर a
| SNe
la be ee 2 जाई:
। ie 9 okies 0277 a ana 5 wee
ee oe pias a
C Scanned with OKEN Scanner

<!-- page 5 -->

5
8. District Development & Panch ffi
ri Yat Officer, Kai
9. District Revenue Officer, Kaithal, ttl:
20. D.LOANIC), Kaithal wi ४
a. DIP ieee with the Tequest to upload the orders on District website.
ef oe a aithal. (for wide Publicity through print media/ social media)
. as eee Haryana State Pollution Control Board, Kaithal. He is directed to
monitor the air quality regularly and upload the data on the relevant websites.
23. All BDPO’s in the District. i i .
24. All Tehsildars/ Naib Tehsildars in the district,
। 25. Executive Officer, Municipal Council, Kaithal,
26. Secy. MC Cheeka/Rajound/Kalayat/Pundri/Siwan
27. All H.O.D. of District Kaithal (Except above)
28. P.A. to D.M. रे
(3 है)
kK fn Pes istrat
& a District Magistrate,
S 900 |,
i
® ws
400४:
Re
Vi Be :
Lae 2
ea tat a be
ts 0287 आज ८4 ये 50.
जे ieee gia as SE aaa
‘i 0 न Sia RE ca
् अर कक ss 5 (cane
a ' 2 ५ =i =a Ee ४0)
४ a Toes gt oe a
z fs, Ce 3 om a ७५० ४६4 ae fe
Be. ee ee es:
ew Sot oa
are: व a
जा
& ५ : भर
©@ Scanned with OKEN Scanner
