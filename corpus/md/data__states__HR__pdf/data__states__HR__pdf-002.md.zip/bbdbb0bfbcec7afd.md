---
doc_id: "bbdbb0bfbcec7afd"
source_url: "https://dmer.haryana.gov.in/uploads/cand_images/Engagement_of_contractual.pdf"
ministry: "Directorate of Medical Education & Research, Haryana"
title: "Public Notice regarding Engagement of Contractual Faculty Members in Government Medical, Dental and Nursing Colleges Policy, 2024.  Download (0.21 MB)"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "caf91a58bb35657f"
---

<!-- page 1 -->

DIRECTORATE OF MEDICAL EDUCATION AND RI,SEARCH, IIARYANA DHL

BUILDING, PLOT NO. 9,4rH FLOOR, IT PARK, SECTOR-22, PANCHKULA

PUBLIC NOTICE

In accordance 1o notification No. 98-2024/Ext. Chandigarh, entitled "Engagement ol
Conlractual Facully Members in Government Medical, Denlal and Nursing Colleges Policy,

2024" dated 03.07.2024 and to meet the NMC/DCI/INC guidelines (as applicable) as well as to
ensure uninterrupted and continuous teaching of under graduate and post graduate students (as

applicablc) in thc college. applications are invited from eligible candidates as per the prescribed
format for engagement against the sanctioned vacant faculty posts on contractual basis.

Eligibility Qualifi cation :
Dctails regarding Educational qualifications and experience for respective post shall be
available on thc wcbsite of the Institutes. Upper age limit for application to the various
posts shall be 70 years.

2. Remuneration:
Contractually engaged faculty members/doctors shall be paid consolidated monthly
remuneration as under:

For Medic al and Dental Colleses
Faculty

Monthly Remuneration

Assistant
Profcssor

Rs. 1.20,0001

1

)

Associate
Professor

I{s. I .42,0001 (if'rhe post-PG teaching elperi ence is under 06 years)
Rs. 1,88,000/- if the po st-PG teaching experience is 06 years or more)

J

Professor

Rs. 1.88,0001 ( i1'the post-PC teaching experience is under 09 years)
Rs. 2,00,0001 (ifthe post-PG teaching experience is 09 years or more)

S

No.

t-

Fo r Nursins Colleses

Faculty

Monthly Remuneration

I

Principal -cum-Professor

78,800/-

2

Vice Principal-cum-Professor

78,800/-

t

Associate Professor

67,7001-

4

Assistant Professor

56.l 00/-

-.-'.
).

['utor

53,1 00/-

S.No.

L

,_

3. E,ngagement Period:
The engagcment will be purely on contractual basis for an initial term of two years from
the date of .ioining duty aller acceptance of this contract. l'he tem.r of engagement of the
contractual employees may be extended by another two years from the date ol joining or

till the attainment of age of 70 years or till regular incumbent joins (whichever is earlier).
The period of contract can be reduced or extended at the sole discretion of the Competent

!

<!-- page 2 -->

Authority in Medical Education & Research Department, Haryana. However, the Govt.
reserves the right to terminate the services of the faculty with one month prior notice

without assigning any reason.

4. AvailableVacancies:
Coilege wise vacant posts are as under:Sr.

Name of College

Total vacant posts

No.

Govt. Medical Colleges
I
Pt. B.D. Sharma, PGIMS, Rohtak
2

Shaheed Hassan Khan Mewari, Covt.

t23
60

Medical, Nalhar
3

Bhagat Phool Singh, Govt. Medical College,

'72

Khanpur Kalan, Sonepat.
4

Kalpana Chawla Cow. Medical College,

39

Karnal
5

Shri Atal Bihari Vajpayee. Covt. Medical

42

College. Chhainsa. Faridabad.
6

Pt. Neki Ram Sharma. Govt. Medical

20'1

College, Bh iwani

Total

543

Govt. Dental College
7

Pt. B.D. Sharma, PGIDS Rohtak

Govt, N ursin Coll
8
Colle e of Nursin , Kutail
9

QqllpgCo I l! !rs{,g, Sa:@on, J ind

Total
Grand Total

9

27
29
56
60E

Details rcgarding College wise and category.wise availability of Faculty posts in
various departments along with the educational qualification and experience required
shall be available at the following websites ofconcemed institutes:
Sr.

No
I
2
J

Name o.f College

Website address

http ://www. pgimsrohtak. ac. ir/
Pt. B.D. Sharma, PCIMS, Rohrok
Shaheed Hassun Khan Mewati. Govt https ://www. gmcmewat. ac. ir/
Medical, Nalhar
Bhagat Phool Singh, Govt. Medical http ://www.bpsgmckhanpur.ac.inl
College for Women, Khanpur Kalan,
Sone

I

Kalpana Chowla Govt. Medical hups ://www.kcgmc.edu.in/
Colle e. Karnal

5

Shri Atal Bifutri Vajpaltee. Gotl. https:/iwww.sabvgmcfbd.edu. in/index.html

Medical College. ('hhainsa,

7

Faridabad.
Pt. Neki Ram Sharma, Govl. Medical http ://www.pgimsrohtak. ac. i d
College, Bhiwani
hups://pgids.ac.inl
Pt. B.D. Sharma. PGIDS Rohtak

8

College oJ Nursing, Kutlil

https ://www.kcgmc.edu. irL/

9

College oJ Nursing, Safidon, Jind

https ://www.kcgmc. edu. irL/

6

<!-- page 3 -->

5. Procedure of Selection:
Interested candidates shall submit their applications in the prescribed format along with
the selfattested copy of required documents and passport size coloured photographs

to

the Director of the institution within 15 days of publication of the advertisement
througl.. hard copy or by email.

The list of all eligible candidates from amongst the applicants against the published
advefiisement shall be published on website of the institute along with the schedule for

interview (subject wise).
a

The applicants who do not fulfill the required qualification and experience will be
rejected.

If the information provided by the candidate is found to be incorrect, his/trer
application shall be rejected and disciptinary/legal action as deemed proper shall be
initiated against him/her.
a

Selection will be strictly on basis of Merit List prepared on the basis of teaching
experience, research publications etc. 05 additional marks shall awarded to retired

faculty members in the pre-merit.
a

Eligibility for appearing before interview board is subject to documents verification on
the day of interview.

a

The applicant should regularly check the website of concemed Institute for any
amendments and updates.

If any candidate wants to apply for more than one college, the candidate has to apply
separately for each College.

In case an applicant gets selected by the selection committee and has applied for more
than one college, MedicalAiursing College shall be allotted to the candidate based on

meril list by the selection Committee.

6. Joining Time:
A period of one month would be given to selected candidates for joining the respective
Colleges

7. Terms and Conditions:
. Engaged faculty under this policy shall, in addition to public holidays and restricted
holidays, be entitled for ten casual leaves and ten medical leaves during a
calendaryear.

.

Private practice of any kind including laboratory and consultant practice is not
permissible. The faculty shall not engage himself/herself in any other paid
assignment during the validity of the contract.

8. Application form & List of Documents:
The application form complete in all respects in the prescribed format along with the

lbllowing documents/cerliflcates shall be submitted by the applicants to the Directors of
the respective Govt. Medical/Dental/N ursing Colleges within the stipulated time period.

<!-- page 4 -->

List of Documents required for List of Documents required for
application in MedicaUDental Colleges

application in Nursing Colleges

MBBS/BDS/MSC Degree Certificare along

Documents of Qualification alongwith

with Marks Sheets.

Marks Sheets.

MBBS/BDS/MSc Attempt Certifi cates.

Degree Attempt Certifi cates.

lnternship Completion Certifi cate.

Intemship Completion Certifi cate.

PC Degree along with

Registration Certificate with Haryana

Marks

Sheet/Cenificate

Nurses and Nurse-Midwives Council

PC Attempt Certificate.

Teaching Experience Certi fi cates.

MBBS/BDS Registration Certifi cate

Category Certificate.

MD/MS/DM/MCh/DNB/MDS Registration

Birth Date Certificate.

Certificate

Research Publications (both original &

'l'eaching Experience Cenifi cates.

photocopy) ifany with proof oI indexing.

Category Certificate.

4

Birth Date Certificate.
Research Publications (both original &
photocopy) with proof of indexing.
Ccrrificate legarding complction of the basic

course in Medical Education Technology
lionr Institutions designated by NMC.
ll

Cenificate regarding completion of the basic

course in Biomedical Research from
Institutions designated by NMC.

Note:

L Number ofposts is liable to increase or decrease as the condition may demand.
2.

No individual interview letter will be sent and no TA/DA will be paid for attending the
interview. Candidates are advised to regularly check the website of the concemed
institutes. where the applications has been subrnitted for latest updates.

J

Candidates must provide their e-mail ids and mobile no. as the interview dates and
regular updates will be sent accordingly.

4

The cut off date for agelqualification shall be the date of publication of Advt. in
newspaper/website.

5

'fhe applicants who are already in Govt./Semi Govt/Corporation or Autonomous Body,
should bring fresh, No Objection Certificate' at the time of interview, failing which the
applicant will not be considered for interview, NOC may not be older than 06 months
counted from closing date of inviting of applications.

Dated
Place:

lrhl)-ozll
P;,J k^ltu

sd/(Director General)
Medical Education & Research,
Haryana, Panchkula
