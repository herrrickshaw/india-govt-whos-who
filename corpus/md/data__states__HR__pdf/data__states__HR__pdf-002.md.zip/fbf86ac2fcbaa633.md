---
doc_id: "fbf86ac2fcbaa633"
source_url: "https://haryanatax.gov.in/Website_Content_Files/Notifications/GST/2025/23.pdf"
ministry: "Excise and Taxation Department, Haryana"
title: "No.39/GST-2 - Amendment of notification no. 28/ST-2, dated 25.01.2018 under the HGST Act, 2017 (H&E)."
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "146d615a53756ee4"
---

<!-- page 1 -->

Haryana Government Gazette
EXTRAORDINARY
Published by Authority
© Govt. of Haryana
No. 163-2025/Ext.] CHANDIGARH, WEDNESDAY, SEPTEMBER 17, 2025 (BHADRA 26, 1947 SAKA)

gfj;k.kk ljdkj
vkcdkjh rFkk djk/kku foHkkx
vf/klwpuk
fnukad 17 flracj] 2025
la[;k 39@th,lVh&2-& gfj;k.kk eky vkSj lsok dj vfèkfu;e] 2017 ¼2017 dk 19½ dh èkkjk 11 dh mi&èkkjk ¼1½
ds v/khu çnÙk 'kfDr;ksa dk ç;ksx djrs gq,] gfj;k.kk ds jkT;iky] bl ckr ls larq"V gksus ij fd ,slk djuk yksdfgr esa
vko';d gS] ifj"kn dh flQkfj'kksa ij] blds }kjk] gfj;k.kk ljdkj] vkcdkjh rFkk djkèkku foHkkx] vfèklwpuk la[;k
28@,lVh&2] fnukad 25 tuojh] 2018 esa fuEufyf[kr la'kksèku djrs gSa] vFkkZr~%&
la’kks/ku
gfj;k.kk ljdkj] vkcdkjh rFkk djkèkku foHkkx] vfèklwpuk la[;k 28@,lVh&2] fnukad 25 tuojh] 2018 esa ]
Þgfj;k.kk ljdkj] vkcdkjh rFkk djkèkku foHkkx] vfèklwpuk la[;k 35@,lVh&2] fnukad 30 twu] 2017 dh vuqlwph IVß
'kCnksa] fpg~uks]a vkSj vadkas ds LFkku ij] Þgfj;k.kk ljdkj] vkcdkjh rFkk djkèkku foHkkx] vfèklwpuk la[;k 36@th,lVh]
fnukad 17 flracj] 2025 dh vuqlwph – II ;k vuqlwph - III ß] 'kCn] fpg~u vkSj vad çfrLFkkfir fd, tk,axsA
2-

;g vf/klwpuk 22 flracj] 2025 ls ykxw gksxhA
vkf’kek cjkM+]
vk;qDr ,oa lfpo] gfj;k.kk ljdkj]
vkcdkjh rFkk djk/kku foHkkxA

(2445)

<!-- page 2 -->

2446

HARYANA GOVT. GAZ. (EXTRA.), SEPT. 17, 2025 (BHDR. 26, 1947 SAKA)
HARYANA GOVERNMENT
EXCISE AND TAXATION DEPARTMENT
Notification
The 17th September, 2025

No. 39/GST-2.— In exercise of the powers conferred under sub-section (1) of section 11 of the Haryana
Goods and Services Tax Act, 2017 (19 of 2017), the Governor of Haryana, on being satisfied that it is necessary in the
public interest so to do, on the recommendations of the Council, hereby makes the following amendments in the
Haryana Government, Excise and Taxation Department, notification No. 28/ST-2, dated the 25th January, 2018,
namely:AMENDMENT
In the Haryana Government, Excise and Taxation Department, notification No.28/ST-2, dated the
25th January, 2018, for the words, signs, and figures, “Schedule IV of the Haryana Government, Excise and Taxation
Department, notification No. 35/ST-2, dated the 30th June, 2017”, the words, signs, and figures, “Schedule II or
Schedule III of the Haryana Government, Excise and Taxation Department, notification No. 36/GST-2, dated the
17th September, 2025”, shall be substituted.
2.

This notification shall come into force with effect from the 22nd September 2025.

ASHIMA BRAR,
Commissioner and Secretary to Government Haryana,
Excise and Taxation Department.

12111—C.S.—H.G.P., Pkl.
