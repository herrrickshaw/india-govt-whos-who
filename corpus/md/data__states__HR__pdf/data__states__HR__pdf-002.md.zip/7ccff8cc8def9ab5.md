---
doc_id: "7ccff8cc8def9ab5"
source_url: "https://dmer.haryana.gov.in/uploads/cand_images/Gazette_98-2024_Ext_19672.pdf"
ministry: "Directorate of Medical Education & Research, Haryana"
title: "Procedure for admission to ANM, GNM & MPHW(M) courses in Government and Private Institutes in the State of Haryana for Academic Session 2024-25.  Download (0.76 MB)"
date: ""
pages: 26
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d00e71af37b9e37a"
---

<!-- page 1 -->

Haryana Government Gazette
EXTRAORDINARY
Published by Authority
© Govt. of Haryana
No. 98-2024/Ext.] CHANDIGARH, WEDNESDAY, JULY 3, 2024 (ASADHA 12, 1946 SAKA)
HARYANA GOVERNMENT
MEDICAL EDUCATION AND RESEARCH DEPARTMENT
Notification
The 3rd July, 2024
No. 16/6/2024-6HB-IV.—
Subject:-

Procedure for admission to ANM, GNM & MPHW(M) courses in Government andPrivate
Institutes in the State of Haryana for Academic Session 2024-25.
****

1.

2.

3.

4.

5.

The Governor of Haryana is pleased to notify the admission procedure in supersession of all the earlier
notifications issued in this regard, to be adopted for admission to ANM, GNM &MPHW(M) courses for
the Academic Session 2024-25in Government/Private Nursing and MPHW(M) Training Schools in the
State of Haryana.
It is notified that in the Government Nursing/MPHW(M) Schools all seats shall be assigned as State
Quota Seats.It is further notified that in Private Nursing/MPHW(M) Schools covered under this
notification, 50% of the seats will be assigned as State Quota seats and 50% seats as Management Quota
seats.
The candidates applying under PWBD category shall have to get the disability certificate issued by the
Medical Board from the Civil Hospitals/Government Medical College. Admissions to this category shall
be made as per INC/State Government guidelines. Any vacant seats in this category shall be filled up as
per State Reservation Policy.
All State Quota seats in Government/Private Nursing/MPHW(M) Schools shall be filled up as per State
Reservation policy. Reservation for EWS category shall be provided as per Haryana Government
notification 25.2.2019 (Annexure ‘I’). The candidates will be required to submit income and assets
certificate issued from competent Authority as per Annexure-I(i)of the notification dated 25.02.2019
The Haryana Nurses and Nurse Midwives Council, Panchkula is authorized to conduct Combined
Centralized Online Counselling as per the merit drawn on the basis of Qualifying Examination i.e. 10+2
for admission to ANM, GNM & MPHW (M) courses in Government/Private Nursing and MPHW(M)
Training Schools in the State of Haryana as per the procedure notified in this notification.
(a)
The admission shall be made in only those Nursing Institutes which have obtained NOC/LOP
from State Government (Department of MER only) and affiliated with Haryana Nurses & Nurse
Midwives Council.
(2034)

<!-- page 2 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)
(b)

6.

7.

2035

The list of such recognized and approved Institutes for the Academic session 2024-25 along with
tentative seat distribution of ANM, GNM & MPHW(M) courses in Government/ Private Nursing
and MPHW(M) Training Schools in the State shall be available on the website of Council
i.e.www.haryananursescouncil.in&Department website i.e. https://dmer.haryana.gov.in/ and as
well as on the admission webportal.
(c)
Roster for all categories of seats including PWBD, EWS shall be maintained by Haryana Nurses
and Nurse Midwives Council, Panchkula for allotment of seats under reserved category.
It is further notified that all the students desirous of seeking admission to ANM/GNM/MPHW(M)
courses will have to get themselves registered online through the Admission web Portal. The details of
admission web portal including dates for inviting online applications and counselling schedule will be
duly publicized as well as uploaded on the website of the Haryana Nurses and Nurse Midwives Council,
Panchkula i.e. www.haryananursescouncil.in. The candidates are required to visit the websites and
admission web portal regularly for latest updates.
Eligibility Criteria:
A candidate desirous of seeking admission in ANM, GNM & MPHW(M) courses for in
Government/Private Nursing Institutes and MPHW(M) schools shall be eligible if he/she:
i.
Is a citizen of India.
ii.
The candidates, who are bonafide residents of Haryana as per instructions issued by the Chief
Secretary to Govt. of Haryana and who/whose parents produce(s) Haryana Residence Certificate
as per Government instructions given in Annexure II, III &IV or any further amendments issued
by State Government from time to time.
iii.
For Management Category, candidates from All over India shall be eligible, irrespective of their
State of domicile and place of study.
iv.
The minimum age for candidates desirous of seeking admission should not be less then17 years
and more than 35 years as on 31.12.2024 (There is no upper age limit for ANM qualified
candidates applying for GNM course, provided minimum education eligibility qualification of
10+2 is fulfilled).
v.
All candidates (General/ SC/SC (Deprived)/ BC-A /BC-B/ PWBD/ EWS/ ESM/ FF) desirous of
seeking admissions in any Category of seats should fulfill the minimum eligibility
criteria/qualifications/qualifying criteria as per the Qualifying Examination for admission to these
courses.
vi.
All candidates should be medically fit, the certificate (issued by Health Department, Haryana) has
to be submitted to the School where he/she gets admission (Any candidate found to be medically
unfit shall be disqualified).
GNM
Minimum education:
 10+2 class with English and must have obtained a minimum of 40% at the qualifying
examination and English Individually from any recognized board. Candidates from
State Open School recognized by State government and National Institute of Open
School (NIOS) recognized by Central Government are also eligible.
 10+2 with English having 40% of marks in vocational ANM course from school
recognized by INC
 10+2 with English having 40% marks in Vocational Stream – Health care Science
from CBSE Board/Central Government.
 Registered ANM with pass marks.
ANM
Minimum Education:
 10+2 in any stream(Mathematics, Physics, Chemistry, Biology, Biotechnology,
Economics, Political Science, History, Geography, Business Studies, Accountancy,
Home Science, Sociology, Psychology, and Philosophy) and English Core/English
Elective or Science or Health care Science - Vocational stream only passing out from
recognized Board.
 Students qualified in 10+2 Arts or Science examination conducted by National
Institute of Open School.

<!-- page 3 -->

2036

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)


The candidate should have obtained minimum passing marks/percentage as specified
by the respective board.

MPHW(M)
Minimum Education:





8.

9.
(i)
(ii)

(iii)
(iv)

(v)

(vi)

10+2 with any stream (Mathematics, Physics, Chemistry, Biology, Biotechnology,
Economics, Political Science, History, Geography, Business Studies, Accountancy,
Home Science, Sociology, Psychology, and Philosophy) and English Core/English
Elective or Science or Health care Science - Vocational stream only passing out from
recognized Board.
Students qualified in 10+2 Arts or Science examination conducted by National
Institute of Open School.
The candidate should have obtained minimum passing marks/percentage as specified
by the respective board.

Note: Only female candidates will be considered for ANM course and only Male candidates for
MPHW(M) course.
 5% relaxation in merit shall be given in merit to SC/SC (Deprived)/ BC-A/BC-B/PWBD
candidates for admission in GNM Course.
 The candidates who have been provisionally allotted seats will have to bring, in original, all the
relevant certificates/documents at the time of document verification without which admission
shall not be granted. Attested photocopies of certificates/documents will not be considered valid
for the purpose of admission and the seat allocated to them online shall be cancelled.
 All candidates should be medically fit.
After commencement of Courses, if a candidate having joined the Institute leaves the course midway:(i)
He/she will be debarred for next three years from applying for admission to
ANM/GNM/MPHW(M) course in the State.
(ii)
He/she will have to pay the fee of the Academic Session during which he/she leaves the course
alongwith the 50% of fee of the next Academic Session.
Procedure for Admission
The schedule of counselling, admissions and start of classes shall be in conformity with the schedule laid
down by Indian Nursing Council / State Government/Haryana Nurses & Nurse Midwives Council.
(a)
Admission will be made through Online Centralised Counselling from the list of registered
candidates on the web portal as per merit in respective qualifying examination.
(b)
Preference in merit shall be given to candidates with the Subjects of Science in qualifying
examination. Only after exhausting the list of candidates with Science in qualifying examination,
the other eligible candidates will be considered.
(c)
In case of a tie between two or more candidates having equal marks/merit in the merit list, the tie
will be broken as under –
(i)
Candidates with higher marks in Biology (for candidates having biology as a subject)
(ii)
Candidates with higher aggregate in Physics, Chemistry and Biology.
(iii) Candidate older in age.
(iv) Alphabetically the one who comes first.
The choice of the course/institution exercised by the candidate on the Online portal will be considered
final and no further change will be allowed.
The allotment of the school/course shall be made strictly as per merit prepared/drawn on the basis of
qualifying examination and the choice/preference of the school filled up by the candidate on the online
portal.
Personal appearance of the Candidates with all original documents shall be compulsory at the time of
reporting at the institute. Attested photocopies of certificates/documents will not be considered valid for
the purpose of admission.
All admissions shall be provisional subject to verification/checking of eligibility for admission as per the
original documents produced at the time of reporting at the institute for admission. The principal of the
Institute shall be responsible for verifying/checking all original documents of the candidates as per
eligibility conditions.

<!-- page 4 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

(vii)

(viii)

(ix)

(x)

(xi)

(xii)

(xiii)

(xiv)

10.
(i)

11.

2037

The provisional allocation of the Seat/Institute online shall confer no legal right to the candidate for the
said seat and the seat shall be confirmed only after the document verification as per the specific period
notified.
In case there is a vacancy after the first round of counselling due to any reason, such seats will be filled
up during the second round of counselling by the same process. The seats remaining vacant even after
the two rounds of counselling will be filled up via mop up round/subsequent round(s) of counselling as
per merit.
The institute shall report and confirm the admission of candidates online on the web portal and admit the
candidate Online.
Any Institute failing to admit the candidates who have been allotted the seat and report at the institute
shall be liable for penalization as per provisions of Haryana Private Health Sciences Educational
Institutions (Regulation of Admissions, Maintenance of Educational Standards and Fixation of Fee),
Act 2012.
The Registration cum Counseling fee (Non-Refundable) shall be as under:
Rs. 1000/- for Unreserved Category.
Rs. 750/- for SC/BC-A/& BC-B,PWBD, FF, ESM, EWS Category candidates of Haryana domicile only.
The Registrar HN&NMC will be responsible for taking decisions regarding admission related matters
like supervision of admission Web portal, conduct of counselling, allocation of seats etc. in accordance
this Notification.
The Director Medical Education and Research, Haryana will be the final Appellate Authority for the
decision made by Registrar, HN&NMC in all admissions related disputes for all Institutions and his
decision shall be the final. Appeal can be sent on simple white paper with copy of decision of
HN&NMC/School concerned through email to dmer-hry@nic.in
(a)
Fresh registration shall be allowed for participating in the second round/Mop up round. Fresh
candidates will have to register themselves on the admission web-portal.
(b)
The candidates, who have already taken admission in any round shall not be allowed to participate
in the subsequent rounds.
Process for Admission to Management Category seats in Private Nursing/MPHW(M) schools of
Haryana:Similar procedure as described above for counseling for filling up State Quota seats in Government and
Private Nursing/MPHW(M) schools will be followed for admissions to Management Category seats as
per the eligibility criteria.
Eligible candidates seeking benefit of caste for Post Matric Scholarship shall have to upload the
following documents in original at the time of document verification:
a.
Caste Certificate.
b.
Aadhar Card.
c.
Account Number alongwith IFSC Code.
d.
Parivar Pehchan Patra(if applicable)
Fee
 The Fee structure for Government Nursing/MPHW (M) schools is at Annexure (V)
 The Fee structure for Private Nursing/MPHW (M) schools is at Annexure (VI)
 The candidate will deposit the fee to the concerned institution at the time of admission either
through DD/RTGS/NEFT in the name of the concerned institution.
 The Fee will be payable on annual basis only and the institutes shall not insist upon the candidates
to deposit fee for the entire course in advance (any violation will attract penal action as per the Act,
2012).
 In case of request for withdrawal of admission by a candidate after the last date of admission, the
fee shall not be refundable to the candidate except on account of death or serious mental
illness/serious grievous hurt.
In case, the candidate fails to report at the institute in the prescribed time period with original documents
and deposit the fee, his/her candidature will be cancelled and the seat allotted to the candidate will be
considered as vacant.

<!-- page 5 -->

2038
12.

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)
General Instructions:a.
List of documents to be brought at the time of reporting to the institution is at Annexure- VII.
b.
Admitted students will be required to pay fees and other charges as per the Notification.
c.
All candidates belonging to the Scheduled Castes/Backward Classes/EWS/PWBD/ESM/FF etc.
must submit a certificate in the prescribed format issued from the competent authority claiming
the benefit of reservation.
d.
The eligibility criteria for admission to Backward Classes shall be as per Haryana Government
Notification dated 17.11.2021(Annexure-VIII).
e.
Only Dependents of Freedom Fighters (FF) who wish to be considered for reservation as such
must submit a certificate from the Competent Authority along with undertaking (Annexure-IX).
f.
The reservation to Ex-servicemen and their wards will be considered as per notification of
Haryana Government, General Service III Branch No. 22/10/2013-1 GSIII (Annexure-X).
g.
A candidate from reserved Category shall have the right to compete for admission in unreserved
Category seats as per his/her merit. In case a candidate does not fill up his reserve Category in his
application form, he/she will not be subsequently considered for admission against that category.
However, if a reserved Category candidate has availed any concession, such as relaxation in upper
age limit, qualification or permitted number of chances in written examination etc., then he/she
cannot be considered against Un-reserved seats.
h.
Any candidate, if found to have submitted any false documents/claim benefit of reservation on the
basis of false documents will be liable for penal action under Section 420, 120B of IPC and
his/her candidature shall be cancelled immediately and shall be debarred for admissions in future.
(d) The admission shall be made to only those Institutes which posses valid NOC issued by DMER
and are recognized by Haryana Nurses and Nurse Midwives Council (HN&NMC). The
institutes that are unable to get such recognition/approval from Government and affiliation
from Haryana Nurses and Nurse Midwives Council shall not be considered for counselling.
The seat matrix shall be provided by Haryana Nurses and Nurse Midwives Council.
i.
It will be obligatory on the part of the Haryana Nurses & Nurse Midwives Council (HN&NMC)
to provide registration number to all the candidates duly admitted. However, if any institute
makes admissions on the seats more than the permitted seats, no registration number will be
provided to such candidates and strict action will be initiated against the erring institute under The
Haryana Private Health Sciences Educational Institutions (Regulation of Admission, Fixation of
Fee and Maintenance of Educational Standard) Act, 2012.
j.
Any admission made by the Institute other than procedure adopted under this Notification will be
invalid. Anyone found doing so will be prosecuted under Section 420, 120B of IPC.

Chandigarh:
The 1st July, 2024.

DR. SUMITA MISRA,
Additional Chief Secretary to Government Haryana,
Medical Education & Research Department, Chandigarh.

<!-- page 6 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2039
Annexure -I

No.22/12/2019-1GS-III
Government of Haryana
General Administration Department
(General Services III Branch)
Dated Chandigarh, the 25th February, 2019
To
1.
2.
3.
4.
5.
6.
7.

All the Administrative Secretaries to Government, Haryana.
All Heads of Department in the State of Haryana.
All the Managing Directors/Chief Administrators of Boards /Corporations /Public Sector
Undertakings in Haryana.
The Registrar General of Punjab & Haryana High Court, Chandigarh.
All the Divisional Commissioners in the State of Haryana
All the Deputy Commissioners and Sub Divisional Officers (Civil) in the State of Haryana.
The Registrars of all the Universities of the State of Haryana.

Subject:-

Reservation for Economically Weaker Sections in Direct recruitment in Civil posts and
services as well as in admissions in Government/Government Aided Educational Institutions
in the State of Haryana.
I am directed to inform that government of India has notified “THE CONSTITUTION (ONE
HUNDRED AND THIRD AMENDMENT) ACT, 2019” On 12th January, 2019 amending Article 15 & 16, which
are now read as under:Amendment of article 15
In Article 15 of the Constitution, after clause (5), the following clause shall be inserted namely:‘(6) Nothing in this article or sub-clauses (g) of clause(1) of article 19 or clause (2) of article 29 shall prevent the
State from making,a)

Any special provision for the advancement of any economically weaker sections of citizens other than the
classes mentioned in clauses (4) and (5); and
b) Any special provision for the advancement of any economically weaker sections of citizens other than the
classes mentioned in clauses (4) and (5); in so far as such special provisions relate to their admission to
educational institutions including private educational institutions, whether aided or unaided by the State,
other than the minority educational institutions referred to in clause(1) of article 30, which in the case of
reservation would be in addition to the existing reservations and subject to a maximum of ten per cent of the
total seats in each category.
Explanation- For the purposes of this article and article 16, “economically weaker sections” shall be such as
may be notified by the State from time to time on the basis of family income and other indicators of
economic disadvantage.’
Amendment of article 16
In Article 16 of the Constitution, after clause (5), the following clause shall be inserted, namely:-

<!-- page 7 -->

2040

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

“(6) Nothing in this article shall prevent the State from making any provision for the reservation of appointments or
posts in favour of any economically weaker sections of citizens other than the classes mentioned in clause (4), in
addition to the existing reservation and subject to a maximum of ten per cent of the posts in each category”.
In the wake of above enabling provisions, State Government has considered the matter and decided to
provide benefits of reservation on a preferential basis in Civil Posts in all the Departments/Boards/Corporations/Local
Bodies and in Admissions to Government/Government Aided Educational Institutions to those Economically Weaker
Sections (EWSs) who are not covered under the existing scheme of reservation for the Scheduled Castes, Backward
Classes (Block-A) and Backward Classes (Block-B).
2. QUANTUM OF RESERVATION:
The persons belonging to EWSs who are not covered under the existing scheme of reservation for Scheduled
Castes, Backward Classes (Block-A) and Backward Classes (Block-B) shall get 10% reservation in direct recruitment
to Group A,B,C and D posts in the Departments/Boards/Corporations/Local Bodies of Government of Haryana and
also in admission to Government/Government Aided Educational Institutions in the State of Haryana.
3.

EFFECTING RESERVATION-ROSTER POINT:

3.1

Direct recruitment in case of Group-A & B
Roster point No. 11-20-30-40-51-60-70-80-90 and 99

3.2

Direct recruitment in case of Group-C &D
Roster point No. 4-14-24-34-43-53-66-76-83 and 94

3.3
Where in any recruitment year any vacancy earmarked for EWS cannot be filled up due to non availability of
a suitable candidate belonging to EWS, such vacancies for that particular recruitment year shall not be carried
forward to the next recruitment year as backlog and will be filled from unreserved category.
3.4
Persons belonging to EWS selected against the quota for persons with benchmark disabilities/ex-servicemen
shall be placed against the roster points earmarked for EWS.
4. CRITERIA OF INCOME & ASSESTS
4.1 Persons who are not covered under the existing scheme of reservation for Scheduled Caste, Backward Classes
(Block-A) and Backward Classes (Block-B) and whose family has gross annual income below Rs. 6.00 lakh (Rupees
six lakh only) are to be identified as EWSs for benefit of reservation Income shall also include income from all
sources i.e. salary, agriculture, business, profession etc. for the financial year prior to the year of application.
4.2 Also persons whose family owns or possesses any of the following assets shall be excluded from being identified
as EWS, irrespective of the family income:I.
II.
III.
IV.
V.

5 acres of agricultural land and above.
Residential flat of 1000 sq. ft. and above.
Residential plot of 100 sq. Yards and above in notified municipalities.
Residential plot of 200 sq. Yards and above in areas other than the notified municipalities.
Total immovable assets owned are valued at Rs. One Crore or more.

4.3 The property held by a “Family” in different locations or different places/cities would be clubbed while applying
the land or property holding test to determine EWS status.
4.4
The team “Family” for this purpose will include the person who applies for benefit of reservation, his/her
parents, spouse as well as children and siblings below the age of 18 years.

<!-- page 8 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2041

5. INCOME AND ASSET CERTIFICATE ISSUING AUTHORITY AND VERIFICATION OF CERTIFICATE:
5.1
The benefit of reservation under EWS can be availed upon production of an income and Asset Certificate
issued by a Competent Authority. The Competent Authority for EWS Income and Asset Certificate shall be
Tehsildar of the area where the applicant normally resides.
5.2
The prescribed format for EWS Income and Asset Certificate shall be as provided at Annexure-I.
5.3
The Officer who issues the certificate would do the same after carefully verifying all relevant documents
following due process as prescribed by the State.
5.4
The crucial date for submitting Income and Asset Certificate by the candidate may be treated as the closing
date for receipt of application for the post, except in cases where crucial date is fixed otherwise.
5.5 The appointing authorities should in the offer of appointment to the candidates claiming to be belonging to EWS,
include the following clause:“The appointment in provisional and is subject to the Income and asset certificate being verified through the
proper channels and it the verification reveals that the claim to belong to EWS is fake/false the services will be
terminated forthwith without assigning any further reasons and without prejudice to such further action as may
be taken under the provisions of the Indian Penal Code for production of fake/false certificate.”
The appointing authority should verify the veracity of the Income and asset certificate submitted by the
candidate through the certificate issuing authority.
5.6 Instructions referred to above should be strictly followed so that it may not be possible for an unscrupulous
person to secure employment on the basis of a false claim and if any person gets an appointment on the basis of
such false claim, her/his services shall be terminated and penal action shall also be invoked.
6.

7.

ADJUSTMENT AGAINST UNRESERVED VACANCIES:
A person belonging to EWS cannot be denied the right to compete for appointment against an
unreserved vacancy. Persons belonging to EWS who are selected on the basis of merit and not on account of
reservation are not to be counted towards the quota meant for reservation.
The above scheme of reservation will be effective in respect of all direct recruitment vacancies to be notified
on or after 01.02.2019.

<!-- page 9 -->

2042

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)
Annexure (I)(A)
Government of Haryana
(Name & Address of the Authority issuing the certificate)
(ECONOMICALLY WEAKER SECTIONS)
INCOME DISCLOSURE CERTIFICATE

Certificate No…………………….

Date …………………………….

VALID FOR THE YEAR …………………………………
This is to certify that Shri/Smt/Kumari ……………………………………… son/daughter/wife of
………………………….….. is permanent resident of ………… village/street……………………………………..,
Post Office……………………..…………, District…………………………., Pin Code ………………………………
whose photograph is affixed below and attested below belongs to Economically Weaker Sections, Since the gross
annual income* of his/her family** is below Rs.6 Lakhs (Rupees Six Lakh only) for the Financial Year
………………..
It is further certified that His/her family does not own or possess any of the following assets***:
I. 5 acres of Agricultural Land and above.
II. Residential Flat of 1000 Sq. ft. and above.
III. Residential Plot of 100 Sq. Yards and above in notified Municipalities.
IV. Residential plot of 200 sq. yards and above in areas other than the notified municipalities.
V. Total immovable assets owned are valued at Rs.OneCrore or more.
2.
Shri/Smt/Kumari ………… belongs to the caste which is not recognized as a Scheduled Caste,
Backward Classes (Block-A) and Backward Classes (Block-B)
Signature with seal of office
Name
Designation

Recent Passport
Size

attested

Photograph

of

the applicant

*Note 1:

Income means income from all sources i.e. salary, agriculture, business profession etc.

**Note 2:

The term “family’’ for this purpose will include the person, who applies for benefit of
reservation, his/her parents, spouse as well as children and siblings below the age of 18
years

***Note 3:

The Property held by a “Family” in different locations or different places/cities are to be
clubbed while applying the land or property holding test to determine EWS status.

<!-- page 10 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2043
Annexure II

Copy of letter No. 62/17/95-6 GSI Dated, Chandigarh, the 3rd October, 1996 received from the Chief Secretary to
Government Haryana addressed to All Heads of Departments, Commissioners Ambala, Rohtak, Gurgaon and
Hisar Divisions, All Deputy Commissioners and all Sub Divisional Officers (Civil) in Haryana, The Registrar,
Punjab and Haryana High Court and all District and Session Judges in Haryana.
Subject:

“Bonafide residents of Haryana - Guidelines regarding”.
I am directed to invite your attention to Haryana Govt. letters noted in the margin on the subject

noted above vide which the instructions were issued regarding simplification of procedure for obtaining the
certificate of Domicile for the purpose

of

admission to

educational

institution

(including technical/Medical

institution). The matter has been reconsidered in the light of judgment delivered by the Hon’ble Supreme Court of
India in the case of Dr.Pradeep Jain vs. Union of India and others reported as AIR 1984-SC-1421, wherein it has
been held that instead of the word ‘Domicile’ the word ‘Resident’ be used in the instructions issued by the State
Government and it has been decided to revise the Government instructions. Henceforth, the following categories of
persons would be eligible for the grant of Resident Certificate: i)

Candidates, who have passed the examination qualifying there for selection in an institution from a
school/college in Haryana.

ii)

Children/Wards (if parents are not living)/Dependents: (a)

of the regular employees of HaryanaState posted in or outside HaryanaState or working on deputation;

(b)

of the regular employees of the statutory bodies/corporations established by or under an act of the
State of Haryana who are posted in Chandigarh or in Haryana or outside Haryana.

(c)

of the regular employees of the Government of India posted in Chandigarh or in Haryana in
connection with the affairs of the Haryana Government;

iii)

Children/wards (if parents not living)/dependents of persons who after retirement have permanently settled in
Haryana and draw their pensions from the treasuries situated in the State of Haryana.

iv)

Children/wards (if parents are not living)/dependents of pensioners of Haryana Government irrespective of the
fact that the original home of the retiree is in a state other than Haryana or he has settled after retirement in or
outside Haryana;

v)

Children/Wards (if parents are not living)/dependents of persons, who have permanent home in Haryana and
include persons who have been residing in Haryana for a period of not less than 15 years or who have
permanent home in Haryana but on account of their occupation they are living outside Haryana;

vi)

The wives of such persons who are bonafide residents of Haryana irrespective of the fact that they had
belonged to any other State before marriage;

vii)

Persons who were born in Haryana and produce a certificate to that effect; provided that the parents/guardians
(if parents are not living) of persons belonging to any one of the above mentioned categories are:
a)
b)

Citizen of India;
Produce an affidavit to the effect that they or their children/wards (if parents are not living)/dependents
have not obtained the benefit of Resident in any other State.

<!-- page 11 -->

2044

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2.

All candidates claiming to be bonafide residents of Haryana should produce a Haryana Resident Certificate
signed by the District Magistrate/General Assistant to Deputy Commissioner or Sub-Divisional Officer (Civil)
of the District/Sub-Divisions to which the candidates belong. Resident Certificates in respect of elsewhere or in
respect of the Children/Wards/Dependents of Haryana Govt. employees who are posted at Chandigarh, Delhi
or elsewhere or in respect of Children /Wards/ Dependents of pensioners of Haryana Govt. or in respect of the
Children/Wards/ Department of the employees of the Government of India posted at Chandigarh or in Haryana
in connection with the affairs of Haryana Government, or in respect of Children/Wards/Dependents of the
employees and retirees of the Statutory Bodies/Corporations of Haryana established by or under an Act of
the State of Haryana or a Central Act and located at Chandigarh, Haryana or outside Haryana, should be
by their respective Heads of Departments.

3.

Candidates seeking admission in educational institutions (including Medical and technical institutions) located
in Haryana may not be required to produce Resident Certificate, if they have passed the examination from a
school/college situated in Haryana. For this purpose, a certificate of the Principal/Headmaster from concerned
institution where the children/wards studied last should be considered sufficient. The Principal/Headmaster of
the institution shall be competent to issue such certificate, which should be sufficient.

4.

If a candidate is admitted on the basis of claim that he belongs to the State of Haryana but at any subsequent
time is discovered that his claim was false, the student shall be removed from the institution, all fees and other
dues paid up to the date of such removal shall be confiscated. The Principal/Headmaster may take such other
action against the student and his/her parents/guardians as he may deem proper in the circumstances of any
particular case.

5.

For the purpose of uniformity for issuing certificate of Residence in the case of various categories to be issued
by the competent Authorities, proforma have been prescribed which are enclosed herewith.

6.

These instructions may kindly be noted carefully for compliance and the receipt of this letter may please be
acknowledged.

<!-- page 12 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2045
Annexure III

U.O. No. 62/27/2003- 6 GSI
From:

Dated, Chandigarh the July 29, 2003

The Chief Secretary to Government Haryana

To

Sub :

1.
2.
3.
4.
5.

All the Heads of Departments in Haryana
The Commissioners Rohtak, Gurgaon, Hissar and Ambala divisions.
The Registrar, Punjab and Haryana High Court
All the Deputy Commissioners in Haryana
The Managing Directors of all Boards and Corporations in Haryana

6.

The Registrars, MaharshiDayanand University, Rohtak, Kurukshetra University, Kurukshetra, Ch.
Charan Singh Haryana Agriculture University, Hissar, Guru Jambheshwar University, Hissar and
Ch. Devi Lal University, Sirsa.

Bonafide residents of Haryana – Guidelines regarding.

Sir,
I am directed to invite your attention to Haryana Government circular letter No. 62/17/95-6GSI, dated
3.10.96 and No. 62/32/2000 - GSI, dated 23.5.2003 on the subject noted above vide which the instructions were
issued regarding simplification of procedure for obtaining the certificate of resident purpose of admission to
educational institutions (including technical/ Medical institutions)
2.
The matter has been reconsidered by the State Government in view of the problems faced by the children
and wards of accredited journalists recognized by Government of Haryana and it has been decided that the children
and wards of the accredited journalists residing at Chandigarh and recognized by Government of Haryana would also
be eligible for the grant of Residence Certificate only for the purpose of admission in the academic institutions of
Haryana State.
3.
These instructions may kindly be noted carefully for compliance and the receipt of this letter may please be
acknowledged.
Yours faithfully,
Sd/Under Secretary General Administration
for Chief Secretary to Government Haryana
A copy is forwarded to all the Financial Commissioners and Principal Secretaries/ Commissioners and
Secretaries to Government of Haryana for information and necessary action.

Sd/Under Secretary General Administration
for Chief Secretary to Government Haryana

<!-- page 13 -->

2046

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)
Annexure IV
Copy of letter No. 22/28/2003-3G.S.III Dated, Chandigarh the 30thJanuary, 2004.

From
The Chief Secretary to Government Haryana.
To
1.

All Heads of Departments in Haryana.

2.

The Commissioners, Rohtak, Gurgaon, Hisar and Ambala Divisions.

3.

The Registrar, Punjab and Haryana High Court, Chandigarh.

4.

All the Deputy Commissioners in Haryana.

5.

The Registrars, MaharshiDayanand University, Rohtak, Kurukshetra University, Kurukshetra, Ch.
Charan Singh Haryana Agriculture University, Hisar, Guru Jambheshwar University, Hisar and Ch.
Devi Lal University, Sirsa (Haryana).
Dated, Chandigarh the 3oth January, 2004.

Subject:

“Streamlining the procedure in the offices regarding issuing of Resident /Income Certificates
and the caste certificate to Scheduled Castes and Backward Classes”.

Sir,
I am directed to invite your attention to Haryana Government letters Nos. 62/17/95-2G.S.III, dated
03.10.96, No. 22/51/93-3G.S.III, dated 12.8.93 and even No. dated 14.10.97 on the subject noted above wherein
instructions regarding the caste certificates (SC/BC/OBC), and Resident certificates have been issued.
2.

The policy has been reviewed keeping in view the various courts judgments and the hardships caused to the
individuals in obtaining above quoted certificates. Government is of the view that the procedure be
institutionalized by delegating powers at proper level for ensuring speedy disposal of work without any
harassment or exploitation. The present modification of the policy also aims at simplifying the procedure for
obtaining certificate by an individual falling under the reserved categories.
The matter has also been reconsidered in depth by the State Government in view of the problems being faced by
the Government employees in obtaining these certificates. With a view to improve the existing system in issuing
various certificates, it has been decided by the Government that henceforth Circle Revenue Officers
(Tehsildar/NaibTehsildar-cum-Executive Magistrate) concerned will be authorized to issue Resident as well as
Caste Certificates (SC/BC/OBC) after getting the verification done through the subordinate revenue staff in case
of applicants residing in the rural area and through the Executive Officer/Secretary of the concerned Municipal
Committee/Municipal Council/Municipal Corporation concerned in case of applicants residing in urban area. It
has further been decided that in case of Haryana Government employees serving in the offices located at
Chandigarh/Panchkula and residing at Chandigarh/Panchkula, the Resident certificates and caste certificate to
SC/BC employees and for their children, may be issued by their respective Heads of Departments also.

3.

The validity of Resident Certificate issued by the competent authority shall be as long as the holder of this
certificate maintains his residential address in Haryana State.

4.

SC certificate once issued shall be valid as long as the caste is not removed from the Schedule of the Constitution
and BC certificate shall be valid for life from the date of issue of the certificate or till the applicant does not fall
into creamy layer Categoryas defined from time to time. The applicant applying for BC certificate would also
submit a self-declaration on simple paper that he does not fall under creamy layer category. The format for this
declaration is given at Annexure ‘A’ However, if the certificate has been obtained by fraud or misrepresentation

<!-- page 14 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2047

or concealment of facts or by some other means, the said certificate shall be declared as invalid/non-est and
benefit taken by the applicant will be withdrawn and a criminal case shall be registered against the applicant
misrepresenting the facts as well as against the guilty officers/officials, if any. In addition, Social Justice &
Empowerment Department, Haryana is being, directed to finalize the modalities and procedure to constitute the
Scrutiny Committee.
The files relating to Caste and Resident certificate shall be retained for 10 years and Register shall be retained
permanently. The proforma of the application form, Register and SC/BC certificates prescribed by the
Government shall be followed by all the Departments/Institutions in letter and spirit as it has come to the notice
of the Govt. that some Departments/Institutions demand such certificates in proforma which are at variance with
the proforma in which these certificates are being issued by the competent authorities (Tehsildar /
NaibTehsildar/HODs). It is, therefore, decided that the Departments/Institutions shall accept these certificates
only in the proforma in which these are being issued by the competent authorities which have been prescribed by
the Govt. itself (copy enclosed).
5.

To make institutional arrangements, it has also been decided that in future the Resident and Caste certificates will
be issued to all the students studying in class 8th every year as per the time schedule given below:-

i.

Filling of application form by the parents/students. 1st Nov. To 10th Nov.Every year. ii. Verification by (a)
Sarpanch/ Namberdar in case of rural areas and Municipal Councilors in case ofUrban areas.

(b)

Verification by Patwari in case of rural areas /EO/Secy.(MC) any other officer/official authorized by the local
body for the purpose in case of urban areas. Upto 30th November every year.

(c)

Head Teacher/Head Master Upto 15th Dec. iii. Forwarding of application to CRO by Head Teacher/Head
Master 31st Dec. iv. Verification& issue of certificate by CRO Upto 31st January every year.

6.

All application forms of a particular School may be sent to the Tehsildar / NaibTehsildar concerned preferably at
one go so that the certificates are issued and sent back to the Head masters of Government Schools/Private
Schools for distribution to the concerned students. The Head Teacher/Head Master shall be responsible for
getting the application forms filled and files prepared of all the students presently studying in Class-VIII to XII
will be issued these certificates during the months of January, 2004 to March, 2004. The schedule will be
finalized by the concerned Deputy Commissioner in this regard.

7.

It has been further decided that in case of SC/BC students claiming benefit under various welfare schemes upto
Class IX, the benefits will be given by the Head Master/Head Teacher after getting the verification done from
Sarpanch/ Namberdar/MC and a caste certificate issued by the CRO (Tehsildar / NaibTehsildar) may not be
demanded for this purpose by the School authorities.

8

The matter regarding issue of income certificate to the students for claiming various benefits in educational
institutions has been considered and it has been decided that in future the income certificate for educational
purpose will be issued by the CRO (Tehsildar / NaibTehsildar concerned) and income certificate for other
purposes by the SDO (C) concerned taking into account income of the applicant from various sources including
agriculture, trade, profession, salary etc. The verification will be got done through the subordinate revenue staff
in case of applicants residing in rural areas and through the Executive Officers/Secretary of the concerned
Municipal Committee/Council/Municipal Corporation in case of applicants residing in urban areas.

9.

It has also been brought to the notice of the Government that when posts are advertised, fairly large number of
candidates apply for such posts and Haryana Public Service Commission/Haryana Staff Selection Commission
/Department demand attested copies of Resident/Caste certificates and other documents from the candidates. This
creates not only financial problems for the unemployed youths but also increases the work load in the offices.

<!-- page 15 -->

2048

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)
Similar is the position in case of admission to educational/professional Engineering institutions. To give relief to
the public, it has been decided that at the time of applying for job or for admission in educational institutions
including technical/professional institutions etc. self-attested photo copy of the certificate about the residence and
caste status shall be sufficient and at the time of final interview/selection, original papers including castes and
Resident certificate issued by the competent authorities may be obtained/examined/inspected by the concerned
departments/institutions and attested copies thereof be kept in record. The fact may also be cross
checked/verified at the time of verification of the antecedents of the applicants before he/she joins the
Government service. Similar practice will be followed for degrees/mark sheets/other certificates of academic
qualifications. Necessary action to amend/revise the application form in this regard shall be taken by Haryana
Public Service Commission/ Haryana Staff Selection Commission/Head of the Departments/Universities etc. at
their own level under intimation to the Government.
These instructions may be brought to the knowledge of all for strict compliance.
Yours faithfully,
Sd/Special Secretary General Administration,
for Chief Secretary to Government Haryana

<!-- page 16 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2049
Annexure IV(A)

Affidavit Of The Parent /Guardian To Be Attested By Executive Magistrate/Oath Commissioner/Notary
Public.
I........................................................................................................................................father/mother/guardian
of Miss/Mr..................................................... resident of.................................do hereby solemnly state and affirm as
under:1.

That I am a Citizen of India.

2.

That neither the deponent nor the child/ward of the deponent have obtained the benefit of ‘Residence in any
other State.

Dated..........................

DEPONENT

VERIFICATION
Verified that the contents of my above affidavit are true and correct to the best of my knowledge and belief
and nothing has been concealed therein.
Dated.........................

DEPONENT

Annexure IV(B)
Haryana Resident Certificate (Residence Certificate To Be Issued By The Deputy Commissioner, Sub
Divisional Officer (Civil), G.A. To D.C.D.R.O. EmAnd Tehsildar).

Certified that Shri/Shrimati/Kumari ______________________________________Son/ Daughter of Shri
________________________________ Father/Guardian of Miss/ Mr. ______________________ name of
child/ward with full address hold Immovable property at _____________________________ (place and District) in
the State of Haryana for the past _________________ years.

OR

Certify
that
Miss/Mr.
_________________________________________Son/
________________________ resident of ____________________

Daughter

of

Shri

was born in Haryana as per birth certificate (Issued under the instructions of Haryana Govt. Letter No. 22/28/2003-3,
GS-III dated 30.1.2004).
No. ________ Tehsildar/NaibTehsildar
Signature of the Authority (mentioned above) (with seal)
Date :
The validity of Resident Certificate shall be as long as the holder of this certificate maintains his residential address in
Haryana State.

<!-- page 17 -->

2050

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)
Annexure IV(C)

Residence Certificate To Be Issued By Head Of Department
Certified that Sh. ______________________________ S/o Sh. ___________________________ father of Miss/Mr.
_________________________ is an employee of the __________________ (Name of office)
______________________ of Haryana Government. He is working as _____________________, and is posted at
________________________. He has more than three years service at his credit.
Place:

Head of the Department

Dated:

(with seal)

Annexure IV(D)

Residence Certificate To Be Issued By The Principal/Headmasters Of The Government/Recognized
School/College.

It is certified that Miss/Mr. ……………………………..S/o/D/o Sh. ……………………….. has been a
student of this School/College for

a period of ……………………………. Years, from ………………..to

……………….. He left the school/college on ………………………..
Dated
Signature of Principal/Headmaster
of the School/College (with seal)

Annexure IV(E)

Residence Certificate To Be Issued By The Respective Head Of The Department In The Case Of The
Employees Of Government Of India
Certified that Sh. …………………………….. S/o Sh. ………………………… father of Miss/Mr.
………………………………………….is

an

employee

of

Government

of

India

working

as

…………………………….. He has been posted at Chandigarh/Haryana in connection with the affairs of Haryana
Government for the past three years.

Dated

Head of Department
(with seal)

<!-- page 18 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2051
Annexure IV(F)

Certificate of Scheduled Caste
Certified that Mr./Miss................................... Son/Daughter
of Sh....................................
Village/Ward No..............................Teh...........................................District......................... Haryana belongs to
................................Caste.Which has been declared Scheduled Caste in the Constitution (Scheduled Castes) Order
1950.
Caste certificate shall be valid for life.

Dated.....................
Place :

Certificate from no other authority will be accepted.

Tehsildar/NaibTehsildar-cum- Executive
Magistrate/Head of the Department

<!-- page 19 -->

2052

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)
Annexure-V

Fee structure for Government ANM/GNM/MPHW(Male) Institutions annual:(Figure as in Rupees)
Particulars

Fees
MPHW(M)

ANM

GNM

Tuition Fee

7500

7500

7500

Security Refundable

1500

1500

1500

Admission Fee

1000

1000

1000

Lab and Library Fee

1500

1500

1500

Examination Fee

As per actual

As per actual

As per actual

Development Fund

2000

2000

2000

Hostel Fee

1500

1500

1500

Total

15000

15000

15000

<!-- page 20 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2053
Annexure- VI

Fee structure for Private ANM Schools
Sr. No.
1

Amount (In Rs.)
5000/4000/3000/3000/3000/4000/5000/27000/2500/-( Per Month)

Remarks

Total Amount

2.

Particulars
Admission Fee
Registration Fee
Lab and Library Fee
Amalgamated Fee
Building Fee
Medical Fee
Computer charges
Total Fee
Tuition Fee

Total Admission Fee
Tuition Fee per year –Rs. 30000/-

3.

Hostel Fee

1200/- (Per Month)

This fee includes room rent,
electricity and water charges.
Mess charges will be charged by
the Institute itself as per the actual

27000/60,000/-(For
entire Course)
28,800/-

4.

Second Year Admission
Fee
Practical Training
Examination Fee
Transport Charges

10,000/-

10000/-

5000/1000/-

10000/2000/-

5.
6.

Will be charged by the Institute
itself as per the actual

Total fee for the entire course.

1,37,800/-

Fee structurefor Private GNM Schools
Sr. No.
1

Amount (In Rs.)
5000/4000/3000/3000/3000/4000/5000/27000/2500/-( Per Month)

Remarks

Total Amount

2.

Particulars
Admission Fee
Registration Fee
Lab and Library Fee
Amalgamated Fee
Building Fee
Medical Fee
Computer charges
Total Fee
Tuition Fee

Total Admission Fee
Tuition Fee per year –Rs. 30000/-

3.

Hostel Fee

1200/- (Per Month)

This fee includes room rent,
electricity and water charges.
Mess charges will be charged by
the Institute itself as per the actual

27000/90,000/-(For
entire Course)
43,200/-

4.

Second Year Admission
Fee
Practical Training
Examination Fee
Final Year Admission
Fee
Transport Charges

10,000/-

10000/-

5000/1000/10000/-

15000/3000/10000/-

5.
6.
7.

-

Total fee for the entire course.
Fee structure for Private MPHW(M) Schools
1st Year Fees 50,000/2ndYear Fees 44,000/-

Will be charged by the Institute
itself as per the actual

1,98,200/-

<!-- page 21 -->

2054

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)
Annexure - VII
List of documents to be brought at the time of reporting to the Institution

The candidates, at the time of reporting must bring the following original certificates/documents/testimonials
along with two sets of duly attested photo copies. Any candidate, who fails to produce any of the required
certificate/document at the time of reporting at the institution, shall loose his/her :
1.

Matriculation Certificate/High School Certificate/ICSE/CBSE Class 10th or its equivalent certificate as
proof of date of birth.

2.

Pass Certificate/DMC of qualifying examination i.e. 10+2.

3.

ANM Registration Certificate (if applicable).

4.

Certificate of good conduct/character from the Principal of the institution last attended.

5.

Service Certificate from the employer if applicable.

6.

Resident Certificate issued by competent authority of the State Government (if applicable).

7.

Certificate of Bonafide Resident issued by competent authority of the State Government (if applicable).

8.

Caste Certificate issued by competent authority of the State Government (if applicable).

9.

Certificate of Disability issued by Competent Authority.

10. Certificate of Dependent of Freedom Fighters issued by competent authority of the State Government (if
applicable).
11. Certificate of ESM issued by competent authority of the State Government (if applicable).
12. Income and Asset certificate for EWS Category candidates.
13. Print out of Online Application form.
14. As proof of identification-Aadhar Card/PAN Card/Driving Licence/ Passport/Voter ID.
Note: Any candidate, who fails to produce any of the required certificate/document at the
time ofreporting at the Institution, shall loose his/her claim to admission.

<!-- page 22 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2055
Annexure VIII

Haryana Government
WELFARE OF SCHEDULED CASTES AND BACKWARD CLASSES DEPARTMENT
Notification
The 17th November, 2021
No. 491-SW(1)-2021.--- In exercise of the powers conferred under clause (d) of Section 2 and Sub-section
(2) of Section 5 of the Haryana Backward Classes (Reservation in Services and Admission in Educational
Institutions) Act, 2016 (15 of 2016), and in supersession of the Haryana Government, Welfare of Scheduled Castes
and Backward Classes Department, notification No. 808-SW(1), dated the 17th August, 2016 and the Haryana
Government, Welfare of Scheduled Castes and Backward Classes, Department, notification No. 1282-SW(1), dated
the 28th August, 2018, the Governor of Haryana hereby specifies the following criteria for exclusion of persons within
the Backward Classes as Creamy Layer as per Annexure appended hereto.
Annexure
______________________________________________________________________________________________
DESCRIPTION OF CATEGORY

TO WHOM RULE OF EXCLUSION SHALL
APPLY
______________________________________________________________________________________________
1
2
3
______________________________________________________________________________________________
Son(s) and daughter(s) of
I. Constitutional
Posts/Constitutional
(a)
President of India;
Personalities
(b)
Vice President of India;
(c)
Judges of the Supreme Court and of the High Court;
(d)
Chairman and Members of UPSC and of the State Public Service
Commission;
Chief Election Commissioner; Comptroller & Auditor General of
India;
(e)
Persons holding Constitutional positions of like nature.
(f)
Member of Parliament or Member of Legislative Assembly
II.

III.

IV.

Service Category
A.
Group A and
Group B/ Class
I and II Officers
of the All India,
Central
and
State Services
B. Employees in
Public
Sector
Undertakings
etc.
Armed Forces including
Para Military Forces
(Persons holding civil
posts are not included)
Property Owners
Agricultural holdings

Son(s) and daughter(s) of
(a) Parents, either or both of whom is or are a Class-I officer (Group A
Officer) or Class II officer (Group B Officer);

The criteria enumerated in A above in this Category shall apply mutatis
mutandis to officers holdings equivalent or comparable posts in PSUS Banks,
Insurance Organizations, Universities, etc. Pending the evaluation of the posts
on equivalent or comparable basis in these institutions, the criteria specified in
Category V below shall apply to the officers in these Institutions.
Son(s) an daughter(s)
Parents either or both of whom is or are in the rank of Major or above in the
Army or to Equivalent posts in the Navy or the Air Force or the Para Military
Forces.
Son(s) an daughter(s) of persons belonging to a family (father, mother and
minor children) which owns land more than the land permissible under the
Haryana ceiling on land Holdings Act, 1972 (26 of 1972).

<!-- page 23 -->

2056
V.

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)
Income Test/Wealth Test

Dated Chandigarh
The 17th November, 2021

Son(s) an daughter(s) of parents
Having gross annual income of Rs. 6 Lakhs or above.
OR
Possessing wealth above Rs. 1 Crore for a period of last three consecutive years.
Explanation:
Income from all sources shall be clubbed to arrive at the gross annual income.
VINEET GARG,
Principle Secretary to Government of Haryana,
Welfare of Scheduled Castes and Backward Classes Department,

<!-- page 24 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2057
Annexure-IX

(FOR DEPENDENTS OF FREEDOM FIGHTERS)
UNDERTAKING
I ____________ S/D of ____________________ R/o ____________________________ Teh.________________
Distt.hereby undertake as under:
That Sh./Smt. ______________________ S/D of Sh. _______________ R/o ______________________
Teh. _______________ Distt. ______________ is /was

Freedom Fighter and is/was my grandfather/

grandmother (Paternal/Maternal).
Date:

Place:

Sign of applicant

It is verified that all the above contents are true to the best of my knowledge.

Sign of Father/Mother of applicant
(Who is/was dependent of Freedom Fighter)

Sign of applicant

<!-- page 25 -->

2058

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)
Annexure-X
Government of Haryana
General Administration Department
General Services -III Branch
No. 22/10/2013-1GSIII
Dated Chandigarh, the 10th August, 2017

To
1.
2.
3.
4.
5.
6.
7.

Subject:

All the Additional Chief Secretaries/Administrative Secretaries to Government Haryana.
All Heads of Departments in the State of Haryana.
The Commissioners, Ambala/Hisar/Rohtak/Gurugram Division.
All the CAs/MDs of all Boards/Corporation/Public Sector Undertakings in Haryana
The Registrar General of Punjab & Haryana High Court, Chandigarh
All the Deputy Commissioners in the State of Haryana.
The Registrars of all the Universities in the State of Haryana.

Grant of reservation in admission in Government/Government Aided educational technical/
professional Institutions etc.

Sir/madam
I am directed to invite your kind attention to the Government instructions issued vide letter of even
number dated 15.07.2014 on the subject noted above.
It is intimated that Government of India, Ministry of Defence Department of Ex-Servicemen Welfare D(Res-II) has
intimated that vide letter number 6(1)/2017-D (Res-II) dated 19.05.2017, the following priorities for reservations of
preferences to the wards of Armed Forces personnel should be applied by States/UTs/Central/State
Universities/Autonomous Institutions for admission in medical/professional/non-professional courses:Priority-I:

Widows/Wards of Defence personnel killed in action.

Priority-II:

Wards of disabled in action and boarded out from service.

Priority-III:

Widows/Wards of Defence Personnel who died while in with death attributable to military service.

Priority-IV:

Wards of disabled in service and boarded out with disability attributable to military service.

Priority V:

Wards of Ex-Servicemen and serving personnel who are in receipt of Gallantry Awards:
(i)
(ii)
(iii)
(iv)
(v)
(vi)
(vii)
(viii)
(ix)
(x)
(xi)

ParamVir Chakra
Ashok Chakra
SarvottamYaudhSeva Medal
MahaVir Chakra
Kirti Chakra
UttamYudhSeva Medal
Vir Chakra
Shaurya Chakra
YudhSeva Medal
Sena, NauSena, VayuSena Medal
Mention-in Despatches

<!-- page 26 -->

HARYANA GOVT. GAZ. (EXTRA.), JULY 3, 2024 (ASAR. 12, 1946 SAKA)

2059

Priority-VI: Wards of Ex-servicemen
Priority-VII: Wards of Serving Personnel.
2.
The State Government has decided to adopt the above provision made by Govt. of India in their letter dated
19.05.2017 with the following amendments.
1.1 In Priority V, the words “and serving personnel” are removed.
1.2 The priority VII is altogether deleted.
Therefore, Para 5 of General Administration Department instructions even number dated
15.07.2014 is amended to this extent.
The above instructions may please be brought to the notice of all concerned for strict compliance.

Yours faithfully
Sd/Superintendent, GS-III Branch
for Chief Secretary to Government Haryana
INTERNAL DISTRIBUTION
Incharge NIC for hosting the above instructions on the State Government website.

11173—C.S.—H.G.P., Pkl.
