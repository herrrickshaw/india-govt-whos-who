---
doc_id: "4fa29c8efe60e4da"
source_url: "https://cdnbbsr.s3waas.gov.in/s33a1dd98341fafc1dfe9bcf36360e6b84/uploads/2022/06/2022062456.pdf"
ministry: "Archives Department, Haryana"
title: "Standing Order (PDF 2 MB)"
date: ""
pages: 8
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "6b54ca161ca391ce"
---

<!-- page 1 -->

STANDING ORDER है
DEAAYING ORDER
[Under Rules 8 and 9 of the Rules
Of Business of the Government, 977|
Pursuant to the provisions as contained in rules I8 and I9 of the Rules of
Business of the Government of Haryana, 977, framed under Article 66 of the
Constitution of India, it is hereby directed that all cases or classes, as the case
may be, pertaining to the Archives Department shall be disposed of in the
manner and at the level indicated against each category detailed out herein after.
Rule 8 above referred reads as follows:

“Except as otherwise provided by other rule, cases shall ordinary
disposed of by or under the authority of the Minister-in-charge who may, by
means of standing orders, give such directions as he thinks fit for the disposal of
cases in the Department. Copies of such standing orders shall be sent to the
Chief Minister and the Governor.”

Rule 9 above referred reads as follows:

“Each Minister shall means of Standing orders, arrange with the
Secretary what cases or classes of cases are to be brought to his personal notice.
Copies of such standing order shall be sent to the Chief Minister and the
Governor.

Provided that it shall not be necessary for the Secretary to obtain
the concurrence of the Minister-in-Charge for referring a case to the Chief
Secretary or to the Legal Remembrancer for advice, but he shall keep the
Minister-in-charge informed of the action taken;

Provided further that in case Administrative department propose
not to act according to the advice of the Chief Secretary or of the Legal
Remebrancer, it shall be necessary to refer the case to the Chief Minister before
taking final action in the matter.”

2. The cases mentioned in Annexure A shall be submited to the
Minister-in-Charge for final orders.
ee 7:77».

<!-- page 2 -->

3h The cases metitioned in Annexure ‘B’ and ‘C’ shall be disposed of by
the Administrative Secretary/Secretary to Government, Haryana, Archives
Department respectively at their own level.
4. In the event of absence of the Minister-in-charge from State
है headquarters, the Administrative Secretary to Government, Haryana, Archives
Department, and in the event of the absence of the latter from Chandigarh, the .
Secretary Archives will dispose of such cases of extreme urgency which, in the
ordinary course, would have been dealt with by the Minister-in-charge after his return
to Chandigarh/Headquarters, .
(Kamlesh Dhanda)
Minister of State for Archives
No. 2/23-92-Abhi /FLI— 3 | Dated Chandigarh the 22.3 9-9
: A copy along with copy of annexure is forwarded to the following for है
information/necessary actions:
iy Secretary General to Government, Haryana, Chandigarh.
2. Principal Secretary to Chief Minister, Haryana, Chandigarh. ,
3) Private Secretary to Minister, Archives Department, Haryana, Chandigarh,
4. Chief Secretary to Government Haryana (one copy each in Political Branch and
Cabin Section) है
की Additional Chief Secretary to Govt. of Haryana, Finance Department.
6. Principal Secretary to Government Haryana, Archives Department.
ie Special Secretary to Govt. Haryana and Director, Archives Department,
: Haryana, Panchkula. bo न
SpeCial Secretaryto-Government
. Haryana, Archives Department ५ o w) ?
for Principal Secretary to Govt.
. Haryana, Archives Department.
ee

<!-- page 3 -->

ANNEXURE ‘A’
List of cases pertaining to the Archives Department to be submitted to the
Minister-in-charge
de Legislative Matters

l.l All Legislative Assembly questions.

I.2 Replies to assurances/ premises made by the Minister on the floor
of the House which are not based on the decision already taken by
Government or which do not give factual information only and
which the Administrative Secretary may consider necessary to
submit to the Archives Minister,

.3 Replies to Parliament questions where information to be given is
not merely and/or wholly factual,

!.4 Framing of Acts and/or Rules there under or any amendments
therein and references to Legal Remembrancer regarding
preparation of Drafts Bills (s).

ir [६00 (०22 -
2. Administrative Administrative Matters

Administrative Matters

2.l Framing of Service Rules of all categories/groups of employees in
the Department and/or any amendments therein.

2.2 All matters pertaining to the First appointment/extension of
probationary period, confirmation, promotion, reversion, transfer,
compulsory retirement, pension, disciplinary action (except minor
punishment cases of Group B_ officers) in respect of
employees holding ex-cadre posts in Group A and B in the
Department.

2.3 Cases sent by or pertaining to Director/Director ( jeneral, Archives
excepting those relating to sanction of casual leave and approval
of tour programme ete.

Le

<!-- page 4 -->

2.4 Annual confidential Reports or Administrative Secretary,
Secretary, Director/Director General, Archives and all Group A
employees in the Department.

2.5. Training of Staffers/officers in the Department abroad all matters
pertaining to their deputation to the Union of India and/or State
Government(s).

2.6 Creation of posts in the Department.

2.7 Reference to the vigilance Department/Bureau in case of all
Groups A and B employees in the Department.

2.8 Cases to be sent to the Chief Minister/Governor.

2.9 All matters based on a memorials submitted by an employees in the
Department unless withheld under Rules by the Administrative
Secretary.

3. Financial Matters Fara (02

Ainancial Matters

3.l Grant or withdrawal of special/personal pay to all or any Group A
or B employees in the Department.

3.2. Reports of the Public Accounts and Estimates Committees of the
State Legislature when ripe for a final view/decision thereon.

3.3. Proposals/Schemes involving new expenditure of Rs. One lakh or
above.

3.4 Matters involving substantial loss of Government Stores and
public money.

3.5 Cases/reports relating to financial irregularities in the Department

3.6 Cases regarding the purchase and permission to sell property to
Group A employees in the Department. x

3.7 Waiving off any claim upon or recovery of amounts from any
Group A or B employees in the Department.

4. General/Miscellaneous Matters,

4.2 Any case relating to Group A and B employee(s) or of a non-

gazette employees which the Administrative Secretary may like
Lee

<!-- page 5 -->

to submit to the Chief Minister or which the Chief Minister
may requisition.

4.2. New plan/ non-plan schemes.

4.3 Important policy references received from or made to Government
of India.

4.4 Grants other than normal and general grants to non-government
institutions.

4.5. Matters relating to appointment of Advisor(s) or the constitution of
any Advisory Committee(s) or Board(s), as the case may be.

4.6 All policy matters, such as those relating to (I) major building
works; (2) any other important case involving major question of
policy or principle;(3) any other cases which the Administrative
Secretary may like to submit to the Minister-in-charge, or which
the Minister-in-charge may requisition:(4) institution or withdrawal
of civil or criminal proceedings in respect of Group A or B
employees, and according of approval to any payment from the
State revenues of damages in suits brought by or against such
employees

4.7 All cases concerning acquisition of land.

4.8 | Withholding of memoirs of employees other than Group A and B
employees.

g
Kam| 4
eS ee ee

<!-- page 6 -->

Annexure ‘B’
List of cases which are to be disposed off at the level of the Administrative
Secretary, to Government, Haryana, Archives Department.
Tee  ैैैहफहफ़़॒॒ः
I. All appeals and revisions under various Acts and Rules of the
Department.
2. Appeals under the relevant Service Rules by all Group A and B
employees of the Department and only of those Group C employee against
whom final orders have been passed by the Director/Director General,
3. Tour Programme of the Director/Director General.
4. Cases regarding the purchase and permission to sell property to Group B
employees in the Department.
5. Cases regarding the submission of factual information sought by the
Public Accounts Committee, Estimate Committee and other Committee of the
Vidhan Sabha.
han Sab ७0७८2 .
6. Cases regarding furnishing of factual information called by the
Government of India in respect of Parliament Questions.
7. Cases of expenditure in connection with repairs, new works
contingencies, installation of Machinery, telephones, purchase etc. in
consultation with Finance Department or where provision already exists in the
budget, ranging from Rs. One lakh and above.
8. Cases involving substantial loss of Government money stores. write off
’ _ of losses as per instruction by the Government from time to time,
9. — Hiring of accommodation in case of first approval.
0. Cases not involving change in Government policy.
Il. Cases to be referred to Finance Department/Legal Remembrancer/Chief
Secretary about which Minister-in-charge has to be kept informed.
I2. Grant of casual leave to the Head of Department.
I3. Referencing relating to reimbursement of Medical charges and time
barred claims in respect of Director/Director General, Archives.

<!-- page 7 -->

I4. Referencing relating to various advances e.g. G.P. Fund advance, car
scooter advance, house building Advance etc. where the relaxation of any rule
of standing Govt. Instruction is involved.
5. Reference relating study leaves cases of Group A and B employees.
I6. Proposals/Schemes involving new expenditure as per instructions issued
by the Government time to time.
7. Power to decide various types of cases of Group A employees under the
TA Rules for which the Department of Government have full powers,
I8. Any cases considered important for submission by Secretary to
Government Archives.

Ken |e.

<!-- page 8 -->

oath
ANNEXURE ‘C’

List of cases which are to be disposed off by the Secretary to Government,
Archives) Haryana Archives Department and Director/Director General,
Archives, Haryana.
ौ+ककुक+--++++-.ब.ऑ.न्‍.].हनन्‍नन्‍जआऑर- ह/हफस्‍फस्‍फऑफऑख
l. Matters relating to appeals of Group C and Group D employees of
Directorate against the order inflicting minor punishment under Punishment and
Appeal rules, 206 where final order were not passed by him/her.

2. Appeals of Group C and D employees of the Department against the
order inflicting minor punishment under Punishment and Appeal rules, 206
where final order were not passed by him/her.

3. Reference relating to reimbursement of medical charges, TA bill(s), and
time barred claims of all kinds of all employees including their payment as per
instructions issued in the Government time to time.

4. Reference(s) relating to various advances, i.e. General Provident Fund
advance, car/scooter/motor cycle advance, house building advance, etc. by or to
the employees of the Department, provided no relaxation in the provisions
under rules or standing _ instructions is involved. Kom [००८
5. Cases relating to fixation of pay, increments and allowances of all Group न,
A and B employees.

6. References relating to leave excepting study leave from or to all Group A
and B employees in the Department.

a. Grant of fee/honorarium to all Group A and B employees in the
Department, and other employees in the Department.

8. Administrative Sanctions.

9. Cases regarding the purchase and permission to sell property to Group C
and D employees in the Department.

0. Issue of financial sanctions after obtaining clearance from the Finance
Department.

l. Cases regarding Audit objections/reports.

2. Sanctions of recurring financial assistance/grant-in-aid in privately-
managed institutions within the amount already provided in the budget of the
Department.

3. Permission to employees for publishing a book or article of a purely
literacy or scientific character as per the approved policy of the Government.

l4. Disposal of cases relating to sanctioning of house rent allowance to all
employees in the Department.
