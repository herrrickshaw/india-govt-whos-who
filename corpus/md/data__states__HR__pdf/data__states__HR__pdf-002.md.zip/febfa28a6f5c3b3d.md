---
doc_id: "febfa28a6f5c3b3d"
source_url: "https://www.mansadevi.org.in/pdf/ashvin-mela-2025-tender-notice1pdf.pdf"
ministry: "Shri Mata Mansa Devi Shrine Board (SMMDSB), Panchkula, Haryana"
title: "Ashvin Mela 2025 Tender Notice"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "60efd5256e81ad01"
---

<!-- page 1 -->

Sr.

| Name

of

No | /Board/Corp. Authority
.
1. [ Shri Mata Mansa

2.

3.

e-tender

portal

Nodal

Officer/Contact
Detail/E-mail
0172-2920988/ | SMMDSB/2025

:;gg‘z‘g"zs

jaimansadevima

Shrine Complex, Panchkula, HR.

End Date

a@gmail.com

|[Shri

Mata

Mansa

01:00 PM
27.08.2025
Devi | Hiring of Agency for providing Tentage, PAGODA, | StartDate

Shrine Board, Panchkula

barricading

www.mansadevi.org.in

Mandir, Kalka and Shri Chandi
Chandimandir, Panchkula, HR.

| Shri

Mata

Mansa

Devi|

Panchkula

[ Shri

Mata

Mansa

Hiring

of

[lumination

| Shri

Mata

Mansa

Devi|

Hiring

www.mansadevi.org.in

Mansa

Agency

for

at

Mata

Shri

at

Shri

Providing
Mansa

Kali

Mata

Mata

of

Agency

for

Providing

27.08.2025
and | Startbate

Light
Devi

Shrine

HR.

Light

at

Mata

Mansa

Shri

Mata

15,000/-

0172-2920988/

Mansa

Devi

Shrine

5,000/-

0172-2920988/

End Date

a@gmail.com

Stage Light at Shri Kali Mata Mandir, Kalka, HR.

:;gg‘z‘g"zs

jaimansadevima

End Date

a@gmail.com

of Agency
at

for providing

Complex, Panchkula, HR.

Shri

Mata

Mansa

CCTV
Devi

for

01:00 PM
27.08.2025
E- | Startbate

Shrine

walls

for live display

of deity

and

4,000/-

5,000/-

0172-2920988/

0172-2920988/

;:gg‘z‘g"ﬁ

jaimansadevima

End Date

a@gmail.com

01:00 PM
27.08.2025
Devi | Hiring of agency for installation and operation of | StartDate
LED

| SMMDSB/2025

jaimansadevima
a@gmail.com

Complex, Panchkula, HR.

Wwww.mansadevi.org.in

Mansa

a@gmail.com

jaimansadevima

Surveillance

Mata

End Date

| SMMDSB/2025

01:00 PM

Shrine Board, Panchkula

|[Shri

0172-2920988/
jaimansadevima

01:00 PM
27.08.2025
Devi | Hiring of Agency for Providing Sound System and | StartDate

Shrine Board, Panchkula
www.mansadevi.org.in

50,000/-

:;gg‘z‘g"zs

Devi | Hiring

| SMMDSB/2025

a@gmail.com

:;gg‘z‘g"zs

01:00 PM
27.08.2025
and | Startbate

Light

0172-2920988/
jaimansadevima

Mandir, | gqpate
01:00 PM

www.mansadevi.org.in

| Shri

8,000/~

:;gg‘z‘g"zs

27.08.2025
Devi | Hiring of Agency for Providing Sound System and | StartDate
Stage

Mata

etc

Ilumination at at Shri Kali Mata Mandir, Kalka
:;gg‘z‘g"zs
and Shri Chandi Mata Mandir, Chandimandir, | gqpate

Shrine Board, Panchkula

|Shri

beddings

Complex, Panchkula, HR.

Shrine Board, Panchkula

8.

(Approx.) in
Rs.
40,000/~

barricading beddings etc at Shri Mata Mansa Devi

Panchkula,

7.

EMD/

www.mansadevi.org.in

Shrine Board, Panchkula
www.mansadevi.org.in

6.

Closing Date(Time)

Devi | Hiring of Agency for providing Tentage, PAGODA, | Startbate

www.mansadevi.org.in

5.

Notice

Shrine Board, Panchkula

Shrine Board,

4.

Public Notice/Tender
Opening Date

Department | Name of Work/Notice/Tender

cultural | 100AM
13.08.2025

programmes at Shri Mata Mansa Devi Shrine | poypos
Complex, Panchkula, HR.
01:00 Pm
27.08.2025

10,000/~

0172-2920988/
jaimansadevima
a@gmail.com

| SMMDSB/2025

| SMMDSB/2025

| SMMDSB/2025

| SMMDSB/2025

<!-- page 2 -->

Shri

Mata

Mansa

Devi | Hiring of Agency for Providing Flower Decoration | StartDate

Shrine Board, Panchkula
www.mansadevi.org.in

Shri

Mata

Mansa

Mata

Mansa

Mansa

Devi

Shrine

Complex,

at Shri Kali Mata Mandir, Kalka and Shri Chandi
Mata Mandir, Chandimandir, Panchkula, HR.

maniary

etc.

at

Shri

Mata

www.mansadevi.org.in

Complex, Panchkula, HR.

Mansa

Devi

Shrine

Shrine Complex, Panchkula, HR.

End Date

01:00 PM
27.08.2025

| 0172-2920988/

| SMMDSB/2025

jaimansadevima
a@gmail.com

25,000/-

hitps://etenders.hrynicin

| 0172-2920988/

| SMMDSB/2025

jaimansadevima
a@gmail.com

4,00,000/-

https://etenders.hrynicin

:;gg‘z‘g"zs

End Date
01:00 PM
27.08.2025
Shri
Mata
Mansa
Devi | Leasing out space for Mela Ground for joy rides | Startbate
Shrine Board, Panchkula
and temporary shops at Shri Mata Mansa Devi
:;gg‘z‘g"zs

www.mansadevi.org.in

https://etenders.hrynicin

;:gg‘z‘g"ﬁ
End Date

01:00 PM
27.08.2025
Devi | Leasing out space for temporary shops for parsad, | StartDate

Shrine Board, Panchkula

50,000/-

:;gg‘z‘g"zs
End Date

01:00 PM
27.08.2025
Devi | Hiring of Agency for Providing Flower Decoration | StartDate

Shrine Board, Panchkula
www.mansadevi.org.in

Shri

at Shri Mata
Panchkula, HR.

| 0172-2920988/

| SMMDSB/2025

jaimansadevima

a@gmail.com
1,00,000/-

https://etenders.hrynicin

| 0172-2920988/
jaimansadevima
a@gmail.com

| SMMDSB/2025

<!-- page 3 -->

Tender List :
S.No

e-Published Date

13-Aug-2025 11:00
AM

Closing Date

Opening

Date

27-Aug-2025 01:00 PM 27-Aug-2025 02:00 PM

Title and Ref.No./Tender ID

Organisation Chain

[Hiring of Agency for providing
Tentage, PAGODA, barricading
beddings etc at Shri Kali Mata
Mandir, Kalka and Shri Chandi
Mata Mandir, Chandimandir,
Panchkula, HR.] [Ashvin Navratra

Haryana Board
Corporation||Sri Mata

Mela/2025/Kalka/Tentage]

Mansa Devi Shrine

Board

[2025_HBC_464854_1]

[Hiring of Agency for Providing
13-Aug-2025 11:00

27-Aug-2025 01:00 PM

27-Aug-2025 02:00 PM

Sound System and Stage Light at
Shri Kali Mata _Mandiu Kalka, HR.]

Haryana Board
Corporation||Sri Mata

Mansa Devi Shrine

Board

13-Aug-2025 11:00
AM

13-Aug-2025 11:00
AM

27-Aug-2025 01:00 PM

27-Aug-2025 01:00 PM

27-Aug-2025 02:00 PM

27-Aug-2025 02:00 PM

[Hiring of Agency for Providing
Light and Tllumination at Shri
Mata Mansa Devi Shrine Complex,
Panchkula, HR.] [Ashvin Navratra
Mela/2025/MansaDevi/Light]
[2025_HBC_464858_1]
[Hiring of Agency for Providing
Light and Illumination at at Shri
Kali Mata Mandir, Kalka and Shri
Chandi Mata Mandir,
Chandimandir, Panchkula, HR.]
[Ashvin Navratra

Mela/2025/Kalka/Light]

Haryana Board
Corporation||Sri Mata

Mansa Devi Shrine
Board

Haryana Board
Corporation||Sri Mata

Mansa Devi Shrine
Board

[2025_HBC_464861_1]

[Hiring of Agency for providing

CCTV for E-Surveillance at Shri
13-Aug-2025 11:00
AM

27-Aug-2025 01:00 PM 27-Aug-2025 02:00 PM

Mata Mansa Devi Shrine Complex,
Panchkula, HR.] [Ashvin Navratra

Mela/2025/MansaDevi/CCTV]

Haryana Board
Corporation||Sri Mata

Mansa Devi Shrine
Board

[2025_HBC_464867_1]

13-Aug-2025 11:00
AM

27-Aug-2025 01:00 PM

27-Aug-2025 02:00 PM

[Hiring of Agency for providing
Tentage, PAGODA, barricading
beddings etc at Shri Mata Mansa
Devi Shrine Complex, Panchkula,
HR.] [Ashvin Navratra
Mela/2025/MansaDevi]
[2025_HBC_464848_1]

Haryana Board
Corporation||Sri Mata

Mansa Devi Shrine

Board

<!-- page 4 -->

[Hiring of agency for installation
13-Aug-2025 11:00
AM

27-Aug-2025 01:00 PM

27-Aug-2025 02:00 PM

and operation of LED walls for live
display of deity and cultural
programmes at Shri Mata Mansa
Devi Shrine Complex, Panchkula,
HR.] [Ashvin Navratra

Mela/2025/MansaDevi/LED Walls]

Haryana Board
Corporation||Sri Mata

Mansa Devi Shrine
Board

[2025_HBC_464869_1]

[Hiring of Agency for Providing
Flower Decoration at Shri Mata
13-Aug-2025 11:00
AM

27-Aug-2025 01:00 PM

27-Aug-2025 02:00 PM

Mansa Devi Shrine Complex,
Panchkula, HR.] [Ashvin Navratra
Mela/2025/MansaDevi]
[2025_HBC_464870_1]
[Hiring of Agency for Providing
Sound System and Stage Light at

9.

13-Aug-2025 11:00
AM

Shri Mata Mansa Devi Shrine
27-Aug-2025 01:00 PM

27-Aug-2025 02:00 PM

Complex, Panchkula, HR.] [Ashvin
Navratra

Mela/2025/MansaDevi/Sound]

Haryana Board
Corporation||Sri Mata

Mansa Devi Shrine

Board

Haryana Board
Corporation||Sri Mata

Mansa Devi Shrine
Board

[2025_HBC_464863_1]

[Hiring of Agency for Providing

Flower Decoration at Shri Kali

10.

13-Aug-2025 11:00
AM

27-Aug-2025 01:00 PM

27-Aug-2025 02:00 PM

Mata Mandir, Kalka and Shri
Chandi Mata Mandir,

Haryana Board
Corporation||Sri Mata

Mansa Devi Shrine
Board

[2025_HBC_464871_1]

11.

13-Aug-2025 11:00
AM

13-Aug-2025 11:00
AM

[Leasing out space for temporary
shops for parsad, maniary etc. at
Shri Mata Mansa Devi Shrine
27-Aug-2025 01:00 PM

27-Aug-2025 01:00 PM

27-Aug-2025 02:00 PM

27-Aug-2025 02:00 PM

‘Complex, Panchkula, HR.] [Ashvin
Navratra
Mela/2025/MansaDevi/Temp
Shop][2025_HBC_464872_1]
[Leasing out space for Mela
Ground for joy rides and
temporary shops at Shri Mata
Mansa Devi Shrine Complex,

Panchkula, HR.] [Ashvin Navratra
Mela/2025/MansaDevi/Mela
Ground for Joy Rides]

[2025_HBC_464873_1]

Haryana Board
Corporation||Sri Mata

Mansa Devi Shrine
Board

Haryana Board
Corporation||Sri Mata

Mansa Devi Shrine

Board
