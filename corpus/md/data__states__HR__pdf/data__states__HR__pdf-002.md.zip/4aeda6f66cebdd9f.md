---
doc_id: "4aeda6f66cebdd9f"
source_url: "https://cdn.s3waas.gov.in/s338b3eff8baf56627478ec76a704e9b52/uploads/2023/11/2023111452.pdf"
ministry: "Panipat"
title: "Order for Graded Response Action Plan"
date: ""
pages: 5
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "cec0423fc757edb8"
---

<!-- page 1 -->

रे
; 22४
BS
( a,
Ay
O/o Deputy Commissioner/District Magistrate/
District Collector, Panipat
Order for Graded Response Action Plan
| Sources [Critical Location/ | Details of | Nodal Agency | Actions to be Undertaken
| | Area | pollution |
cae —_ हि | | observed | _ _
| Industrial Airemission. (a. 5800-25, 22 | Industrial | HSPCB | Ensuring emission standards (already laid
(Part-I, Il) | emission from | down by the HSPCB) in industries and taking
| b. Samalkha | the industries | action a against the violators as per the law _|
c, Panipat City ints usage of approved fuels in the
| d, Old Industrial Area | industries
e. Israna | | Ensuring proper installation and operation of
f. Kurar | fait Beton air pollution contro! devices in all the industries |
" | | Installation of online monitoring devices by ॥7
| | Red Category L&M units and ensuring
‘connection of the same with the official
website of CPCB and HSPCB. |
| | Complete ban on CTE to new tyre pyrolysis
| | | _plants in the district
Regulation of ban on DG sets in compliance of |
| directions of CAQM direction No. 76 dated |
-_ _ 29.09.2023 _ _|
| MC Panipat Regulation of ban on DG setsin compliance of
/Municipalities/(ODPO/HSVP/DTCP/DIC. directions of CAQM direction No. 76 dated
| 29.09.2023except _industries/establishments
_ Boe ae 4 _ _ ___ covered under ambit of HSPCB
b) Vehicular air | a) Lal Batti Chowk Vehicular air Traffic Police/RTA Without Pollution Certificate
emission / traffic |b) Anaj Mandi emission q “Wrong Parking and illegalparking.—SOtC=CS*S

<!-- page 2 -->

ह | Congestion. ~~~) Gohana Chowk traffic : - _ 7 Carrying of dangerous goods aa
d) Sanoli Chowk congestion Lexplosives = |
| e) Rohtak Bye Pass Expire road certificate
f) Toll Plaza a x
| Panipat | Smooth Traffic Movement |
| | गा आज = ए छडे हू ee
| h) BBMB underpass i Impounding of the over aged vehicles
i) Sanoli Road |
j) Assandh Road
K) Gohana Road <a and impounding oF |
vehicles |
Isaac बता पड व + + किलप तले त-+ लक अत तक |
c) Road dust. 4) Along the Road dust NHAI, MC Panipat, HSVP, DTP, PWD | To Increase frequency of mechanized |
| Highway- (B&R), HSIIDC, Municipalities, HSAMB, | cleaning of road
NH44 | | Irrigation Deptt, PWD, PHED. Panchayati ce
| | Raj Deptt. Regular Sprinkling of water on road
| 2) Gohana Road | | ee फ
| | | | To ensure implementation of directions of
| | | don'ble SEs Sess laws /guidelines
3 li Road
की Baveiiisnad T | of MoEF&CC at road/oridge/underpasses
| 4) Assandh Road L constructions sites.
| NHAI, MC Panipat, HSVP, DTP, PWO | - Increase frequency of Cleaning of roads in all
| 5) Anaj Mandi i (B&R), HSIIDC, Municipalities, HSAMB, | traffic prone and busy roads and junctions |
| i Irrigation Deptt, PWD, PHED, Panchayati |
| 6) Major District Raj Deptt Increase Sprinkling at of roads in all traffic |
| | Roads, State | prone and busy roads and junctions |
|
| | Highway, { our rare T TT
| | internal Road | Paving of unpaved roads & filling of potholes
| | of City throughout the District Panipat |
a | lel eT ne कल कुक a Ft
| Panipat | Solid Waste NHAI, MC Panipat, HSVP, DTP, PWD Implementation and awareness of duties of
| | and Plastic (B&R), HSIIDC, Municipalities, HSAMB, generator |
d) Waste Burning | Waste Irrigation Deptt, PWD, PHED, Panchayath रुद---------5-------__
and Fires | | Raj Deptt To facilitate the Source segregation and wet |
| | waste management. Commissioner, Municipal |
| ४ i Corporation, Gurugram will implement action |
| wach टिक | plan submitted by him before Hon'ble छा "|
हु _OA No. 574/20i8&0A No. 72/2022 ;
\ | | | To stop illegal dumping and burning of |
| Industrial waste in Industrial and other areas
| | । [Nightpatroliing “४
| | | | Segregation and wet waste management in
| | | industrial areas/sectors

<!-- page 3 -->

| To arrange for door to door collection of
| segregated solid waste from all industrial
| areas /sectors. a
| To facilitate formation of Self Help Groups.
| | provide identity cards and _ thereafter
| | encourage integration in solid waste |
management including door to door collection
| _of waste: _
To setup material recovery facilities or
| | secondary storage facilities with sufficient
| space for sorting of recyclable materials to
| | enable informal or authorised waste pickers
| | and waste collectors to separate recyclables
| from the waste and provide easy access to
i | waste pickers and recyclers for collection of
| segregated recyclable wastc such as paper,
| | te metal, glass, textile from the source of
| generation in industrial areas /sectors or from
| material recovery facilities. S|
| To direct street sweepers not to burn tree
| leaves collected from street sweeping and
| | Store them separately and handover to the |
| | waste collectors oragency authorized by local |
[body शकिशिश =|
| To stop illegal dumping & burning of garbage |
| in Hot Spot
t | Reuse of plastic waste generated from |
| | | industrial areas /sectors in Road construction _|
| Collection-cum-purchase-cum- processing |
| | center for the plastic waste generated from |
| | | the industrial& other areas /sectors. it
| | Strict implémentation of order issued by |
i BE Magistrate, Panipat vide Endst. No. |
| 3327-33424/MA dated 04.44.2023. }
e) Construction and | Panipat | C&D waste | NHAI, MC Panipat, HSVP, DTP, PWD | Ensure separate ee collection,
Demolition Waste | dumping (B&R), HSIIDC, Municipalities, HSAMB, transportation& processing of Construction
| Irrigation Deptt. PWD, PHED, Panchayati | and Demolition Wastes |
Raj Deptt. | है
| Construction NHAI, MC Panipat, HSVP, DIP, PWD CAQM Direction No. 69 of 02.47.2022
, & demolition | (B&R), HSIIDC, Municipalities, HSAMB, fegarding dust control measures in
| | project | Irrigation Deptt, PWD, PHED, Panchayati Construction & demolition project — use of anti-
Raj Deptt., HSPCB, Other Construction smog guns & violations of Construction &
| Agencies Demolition activities
| | |
I. a | जाया हा i)Having built up or plot area less than 20000

<!-- page 4 -->

sh Sqm shall be implemented by concerned
| agencies in their respective jurisdiction by |

| MCK/Municipalities/DDPO/HSVP/DTCP/ PWD

(B&R) HSIIDC

| + 2) #2शावु 0ण॥ ५७ णा 900 area more than 20000

isqm area shall be looked into by HSPCB
and/or DTCP. |

|

[ese ne, eee SO | Lo a |
f) Fire Cracker Ban Panipat | Police Deptt, MCK SDM, 4 Naib | Prohibit the manufacture, sale, bursting and |
| Tehsildars /BDPOs, DSPs, E.O./Secretary, use of joined firecrackers (series crackers or |

Municipal Committees, SHOs, Fire Officer. | laris) & all kinds of fire crackers except for

| | | | Green Crackers besides ban of barium salts in
| | | DPRO, DIO/ADIO- For Information the fireworks, for the period from 04.4.2023

| Dissemination to 34.0/.2024 except for the window given
| | below:-

DEO and all Principals of all the Private The windows for bursting of Green Crackers |
| Schools- To make students aware about the — shall be as follows- |
| ill effects of crackers and nudge them | 5 caf |

| | | towards celebrating an eco-friendly Diwali + गा Diwali days or on any other festivals |
| | arid) other raati vale e Gurpurab etc., when such fireworks |
| | generally take place, it would strictly be |
| 5 |. | from 8:00 p.m. till 0:00 p.m. only. |
| | EE cae cae Melee |2. On Christmas even and New Year eve, |
i Monitoring as per the CPCB Guidelines | aha an Prewetes a areind |
| | | midnight, ie. 42:00 a.m., it would be
| | from 77:55 p.m. till 42:30 a.m. only.
a बे 22 ond Pw nnn न
| To make the public aware about ill and
| | harmful effects of fireworks and caution people
| about the health hazards on bursting of
| | firecrackers, through nukkudnataks, print and |
electronic media. The knowhow of identifying |
| | green crackers from conventional one shall |
| | also be publicized heavily,  ़स्‍
| | No e-commerce websites, including Flipkart,
Amazon, etc., shall accept any
| “online orders and effect online sales in the
| | | District
| | Orders of Hon'ble Supreme Court of India in |
| IA No. 44727/2027, IA No. 48692/2022&amp; |
| | | IA No. 04836/2023 in Writ Petition (Civil) No.
| | 728/2075, Civil Appeal No. 2865-2867 0f202
| and NGT OA No. 249/2020 be strictly
bec हा _ _ | complied with.

<!-- page 5 -->

है | Strict implementation of order issued by
District Magistrate, Panipat vide Endst. No

| I676/MA dated 28.09.2023. |

| |

| | |

All stakeholder departments will constitute a team for patrolling during GRAP for strict implementation of directions issued by Hon’ble

Supreme Court, Hon’ble NGT, CAQM, CPCB, District Administration, HSPCB etc.

Superintendent of Police, Panipat is requested to appoint a Nodal officer who can be contacted in need of any police assistance by any
Department/Agency. |
_The SDM’s of concerned Sub Division will be the Nodal Officer for implementation of Orders. 7 7 a=

oo a om aefbto2>
Panipat
Endst No. QL Dated fa | ti} 2423
All concerned offices for information and necessary action
