---
doc_id: "6c9bfb2b58cc31dc"
source_url: "https://hpa.haryanapolice.gov.in/Documents/StandingOrder/8.pdf"
ministry: "Haryana Police Academy, Haryana"
title: "View"
date: ""
pages: 4
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "a1c101c8e1bba09d"
---

<!-- page 1 -->

[ro DEPARTMENT So HARYANA STATE | |
_ DIRECTOR GENERA’S STANDING ORDER NO.!!] OF 20°), a
_ Subject‘ Police Hondnucten Civil Suits/ CWPs pertaining to State |
RAGES |
Civil Suits/CWPs against Police Department have multiplied
_ during the last few years and there is a need to monitor them at all the stages
from their inception to the implementation of orders passed by courts. In the
past, all the writ petitions had heen dealt with in the concerned branch and
there was no separate branch to deal with the court cases. This issue has been
_ considered at length and it has now been decided that all Civil Suits/CWPs
_ {Except the criminal writ retitions) wherein D.G.P is impleaded as a party will
be dealt with by the Legal Branch of State Police Headquarters which has been
_ specially constituted for the purpose. The following instructions regarding
functioning of Legal Branch are issued fcr guidance and meticulous compliance
' fi) Lege! Brach will act as a co-ordinatin a branch for all court cases.
including Civil Suits/ CWPs , MACT cases, SG CPC notices and 0.A in
| CAT. It shall be responsible for receiving all notices from courts and
for ensuring that the written statements/ affidavits are filed in courts
in time by the concerned units/branches cr by the Leged Branch

| itself, liaison with Advocate General, Haryana/ State Counsel and for |
monitoring, implementation cf court orders, filing cf appeals, etc.

Gi) _ Legal Branch shall receive all the notices regarding Civil Suits/ CWPs
notices cf 80 CPC, MACT cases, etc, from courts issued in the name |
of D.G.P {H} and shall make entry of the same in a register to be
maintained for the purpose, It shall dispatch copy of the notices to -
concerned unit/ branch for further and will constant ly monitor the |
progress of these cases till their finalization, Leged Branch of State |

| | Police Headquarters shall circulate the orders passed by courts to the
concerned unit/ branch and ensure t hat appeals are filed in time, if |
necessary. When it is decided by the appropriate authority that =

<!-- page 2 -->

हैँ पा ' हि
eo appeal need not be filed, the Legal Branch shall monitor the
implementation of the court order by the unit concerned. हि
दा). Legal Branch shall decide whether counter affidavit/reply to all those |
writ petitions/ civil suits wherein D.G.P is impleaded as a party will
be filed by the concerned unit or State Police Headquarters.
Gv} Legal Branch shall ensure that the written statements/ affidavit is
| prepaid and filed by the unit/branch concerned in time in the court
on behalf of the DGP (H) on the basis of draft counter comments
received from Units/Ranges IsG/Branches of State Police
Headquarter and Legal branch shall also ensure that such
| affidavits/Written Statements/ replies are filed by concerned
unit/branch in courts well before the dates fixed for hearing.
However, in case, where for unavoidable reasons it is not possible to
| finalise the replies/ affidavits/ written statements in प्रंडाठ, ६ शी पट
steps for seeking additional time to file such replies. - |
{vy} Legal Branch shall ensure that Incharge / dealing assistant of the
concerned Unit /Branch, who is well conversant of the case to contect .
and brief the matter alongwith relevant record tc Advocate General ,
Haryana/ Standing Counsel of the department before’ the date of
ह hearing and to attend the Court on the fixed date of hearing to help
them in conducting case is courts. | | | |
{vi} | Legal Branch of State Police Headquarters shall obtain permission to
defend the civil suits/ writ petitions / SLP from Legal Remembrancer,
Haryana on behalf of official respondents at public expenses and |
| convey the same to Advocate General, District Attorneys and
concerned unit/ branch of State Police Headquarters. In case, the
branch considers that a private counsel is to be engaged fer a
particular case, it shall take necessary steps for obtaining sanction of
the Govt. and making payment to the private counsel.
(vii) The Legal Branch will act as a repository of information regarding
: court cases and maintain record of land-mark judgements and will be
| responsible to circulate the same to all the units for their guidancef
references. | ४ ० यह

<!-- page 3 -->

पे (vin) The Legal Branch shall from time to time circulate standard counter
affidavit eliciting various points to be raised in various writ petitions
subject wise Ie reganting recruitinent, senicrity, promotions
deputation tc promotional course, adhoc promotion, ete. ,
(zt Incherge. Legal Branch shal! submit a month ly progress report of all —
Cour cases under following category.
di} Court cases in which notices have been received in the branch but |
written statements / affidavits are yet to be filed.
ai} Court cases in which written statements / affidavits have been filed
in the court and the cases are still pending in the court. |
GH} Court cases in which final erders have been passed by courts and
decision of the courts are yet to be implemented by the unit/ branch.
DIG/IGP Human Rights and Litigation in addition to their own duties,
will look-after the working of Legal Branch of State Police
| Headquarters and they shall he responsible for implementation of this
standing Order, IG/Admn, Training, M & W shall be responsible for
_ filing written statements/ affidavits / replies on behalf of the D.G.P in
all those cases wherein D.G.F is impleaded as a party and it has been.
decided to file the reply at CPO level. | a
The above instructions will supersede all instructions regarding
conduct of cases issued from this office from time to time.
| Mirmel Singh
ircotor Goncral of Police, Haryana.
है

<!-- page 4 -->

/ Nox 0566-66/LA-I, dated 27-9-2005. > a _
_ Acopy is forwarded to the following for information and necessary '
action. - |
te Addl. Mnrector General of Police, CPT & R, Bhondst.
2. Inspector General of Police, Railways & ‘Tech. Services, (H),
Panchkula.
3. Insnecter General of Police, Law & Order (H), Panchkula.
4. All Range IisGP im ilaryana.
5. Inspector General of Police, CID, Haryana.
5. Dircctor, SCRE, Madhuban.
ds Director, HPS’, Madhuhen. '
8. Inspector General, HAP, Madhuhan.
०. inspector General of Police, M&W (I), Panchkula. |
0. Inspector General of Police, Telecom (H), Panchkula. ;
ll. Asstt. Inspector Gcncrai of Poiicc, Administration {i}), Panchkula.
2. Asstt. Inspector General of Police, T&T (H}, Panchkula.
i3. Asstt. Inspector General of Police, Welfare (H}, Panchkula.
4. Ali District S.Ps i Haryane.
5. All Comdts. of HAP, Battahon. |
iS. Al Comdts. of IRB, Bhondsi, Gurgaon.
[7, Superintendent of Police, Rethvays, Ambala Centt.
i8. Superintendent of Policc, Commanda, Newal, Karnal.
9. District Attorney, PHQ (H), Panchkula. |
96. All Branch Incharge in PHO (H)}, Panchkula. |
: - (R. ah Mis yo
| AIG/ Administration
] for Director General of Police, U Haryana
८. a 4 \ 85
