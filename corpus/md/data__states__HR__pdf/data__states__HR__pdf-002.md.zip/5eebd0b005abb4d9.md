---
doc_id: "5eebd0b005abb4d9"
source_url: "https://cdn.s3waas.gov.in/s3b6d767d2f8ed5d21a44b0e5886680cb9/uploads/2021/04/2021042844.pdf"
ministry: "Palwal"
title: "Order regarding imposing section 144 during Covid-19 (dated 28-04-2021)"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "4e3f8ed7ea87d931"
---

<!-- page 1 -->

ORDER SECT
SAVER UNDER SECTION 44 OF CODE OF CRIMINAL PROCEDURE, 973 SECTION 44 OF CODE OF CRIMINAL PROCEDURE 4973
and National Disatter annoy 9 has been declared as pandemic by the World Health Organization
Cc anagem i i i i ith th
OVID-I9 pandemic: gement Authority, being satisfied that the country is threatened with the
Palwal di And whereas, it is evident that there has been an experimental surge in COVID- ]9 cases in
हक istrict necessary measures are to be adopted to contain the spread of the Covid-I9 and also to
nsure minimum collateral damage to the system.
है The Government of Haryana has considered it necessary to take effective measures to
prevent and contain the spread of the Covid-9 virus in the State including district Palwal in the
interest of maintenance of public health, hygiene and safety

Now, therefore, in exercise of the powers vested in me by virtue of Section 44 of the
Code of Criminal Procedure, 973, I, Satyender Duhan, HCS, District Magistrate, Palwal, do
hereby strictly prohibit the gathering of more than four persons, throughout the revenue limits
of district Palwal, unless specifically permitted.

ह This order shall not apply on police force and other public servants on duty, persons of
medical industries/institutions, persons working in sectors related to essential products/services.

This order shall come into force with immediate effect.

The order shall be disseminated for the information of general public and promulgated
within the revenue limits of District Palwal through publicity van of Public Relations Department and
also by affixing copies of this order at District, Sub Divisional, Tehsil Courts, Police Stations and
other public places as well.

Any person(s) contravening this order will be liable to be proceeded against under Section
I88 of the Indian Penal Code, 860. Superintendent of Police, Palwal shall implement this order.
Given under my hand and seal of the Court on 2770 day of April, 202I. \

)
Di eu agistrate,
Palwal.
3 g t 9 Jo2
Enést.No. 2SCD—/o mB. dae IF/o4/202/ ४
A copy of above is forwarded to the following for information and action, where necessary:
\. The Chief Sectary to govt. Haryana, Chandigarh
2. The Financial Commissioner & Additional Chief Secretary to Govt. Haryana, revenue & Disaster
Management Department, Chandigarh.
3. The Additional Chief Secretary to Govt. Haryana, Home Department, Chandigarh.
4. The Additional Chief Secretary to Govt. Haryana, Health Department, Chandigarh.
5. The Director General Police, Haryana, Chandigarh.
6. The Commissioner, Faridabad Division, Faridabad.
7. The inspector General C.].D Haryana, Chandigarh.
g The ADGP South Range, Rewari.

<!-- page 2 -->

vo Rie Sess, ra
i. Superintendent gtran in arvana.
!2. District Municipal c me ae
I3. Additional De Pp 7 ommissioner Palwal.
Pputy Commissioner, Palwal.
l4. CEO,ZP,Palwal. |
IS. Sub Divisional Magistrate, Palwal, Hodal, Hathin.
!6. DRO Palwal.
7. DDPO Palwal.
\8. Civil Surgeon, Palwal.
\9. Dy. Dir. Distt. Industries Center, Palwal
20. Drugs Control Officer, Palwal.
2l. DIPRO, palwal to ensure wide publicity
22. General Manager, Hr. Roadways, Palwal.
23. Station Master, Railway Station, Palwal.
24. Distt. Food, Civil Supplies & Consumer Affairs Controller, Palwal.
25. District Manager, HAFED/HWC, Palwal.
26. Dy. Director Agriculture, Palwal.
27. Dy. Excise & Taxation Commissioner (ST)/(Excise), Palwal.
28. Lead District Manager, palwal.
29. Executive Engineer, PWD (B&R) Dyn. L,II/HSAMB, Palwal.
30. Asstt. Labour Commissioner, Palwal.
3i. All Tehsildars/NTs/BDPOs in district Palwal.
32. EOs/Secretaries of all ULBs in distt. Palwal.
33. All Duty Magistrates i.e. incident Commandeers in district Palwal. (through concemed SDMs)
34. All respective members of Local/Sector/Zonal Committees in distt. Palwal.
35. In-charge, Distt. War/Control Room, Palwal.
36. All Head of District Offices of District Palwal.
37. D.I.0., NIC, Palwal. हर
38. PA/DM, Reader/DM. | if
idrict Magistrate,
Palwal.
