---
doc_id: "fafed486896bc3ad"
source_url: "https://bseh.org.in/uploads/files/64bfcb17be9c6b5625b343e6167b693f.pdf"
ministry: "Board of School Education Haryana"
title: "TENDER FOR PRINTING AND SUPPLY OF VARIOUS STATIONERY ITEMS FOR YEAR  2026-27"
date: ""
pages: 32
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "96213912675d4736"
---

<!-- page 1 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

Tender Fee. 1,000/- (Non-refundable)

BID DOCUMENT

TENDER FOR PRINTING AND SUPPLY OF
VARIOUS STATIONERY ITEMS FOR YEAR
2026-27

To
Secretary
Board of School Education Haryana,
Hansi Road, Bhiwani-127021
Phone: - 01664-243336
Website: www.bseh.org.in

Signature of the Bidder with Seal

1

<!-- page 2 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

TENDER DOCUMENT
FOR PRINTING AND SUPPLY OF VARIOUS STATIONERY ITEMS FOR
THE YEAR 2026-27
Contents

SECTION

NUMBER

NUMBER
1.

PAGE

BRIEF INFORMATION ON BID DOCUMENT

03

NOTICE INVITING E-TENDER

04

2.

TECHNICAL QUALIFICATION CRITERIA

05

3.

INSTRUCTIONS TO BIDDERS AND TABLES OF CLAUSES

06-09

4.

UNDERTAKING BY THE BIDDER

10

5.
6.

SPECIFICATIONS OF PAPER & PRICE SCHEDULE
BID SUBMISSION FORM

11-21
22

7.

CONDITIONS OF CONTRACT

23-27

8.

CONTRACT FORM

28

9.

CRITERIA FOR IMPOSITION OF PENALTIES

29-31

CHECKLIST OF THE TENDER DOCUMENTS

32

2

<!-- page 3 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

SECTION-1
BRIEF INFORMATION ON BID
Tender No.

2074/Pub

Tender Type

Open

Scope of Work

As per Tender Document

Tender Document Fee (Non-refundable)

1000/- (one thousand only) (Non-refundable)

EMD

16,000/- (Sixteen Thousand Only)

Mode of Bid submission

Through Online
https://etenders.hry.nic.in

Starting Date for Submission of Bid

12.08.2026

Last Date and time of Bid submission

11.09.2026 (10:00 AM)

Date and time of opening of Technical Bids

11.09.2026 (11:00 AM)

Validity of Bid

180 Days from the date of opening Technical Bids

Validity of Contract

The contract would initially be for a period of one year
which may be extended for maximum period of two
years on the basis of previous good performance.

Material to be supplied at

Publication Store, Board of School Education Haryana, Bhiwani
-127021

Approximate cost of Tender/project

8,00,000 (Eight Lac only)

Time Period for Completion of work

30 days from the next day of issuance of work order.
02 days will be given extra for preparation &
submission of proof in the Board’s Office. Proof
reading time taken by this office is excluded in said
time period.

Board’s G.S.T. NO.

06AAALB0940Q1Z4

3

<!-- page 4 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

NOTICE INVITING RE-ETENDER
The Secretary, Board of School Education Haryana, Bhiwani invites E-tender under Two Bid systems
from the reputed & experienced firms/agencies for printing and supply of Various Stationery items for the
year 2026-2027
For participation in the bid, agencies will fill the complete tender form available at the Board’s Website
www.bseh.org.inand https://etenders.hry.nic.inas per schedule given in CRITICAL DATES as under. Interested
agencies may download the tender document from Board’s Website www.bseh.org.in (for perusal /reference only):

CRITICAL DATES
Subject

Date and time

Bid Submission Start Date

12.08.2026

Bid Submission Closing Date

11.09.2026 (10:00 AM)

Technical Bid Opening Date

11.09.2026 (11:00 AM)

Any amendment/correction in the tender document will be done by the Board Authority through
https://etenders.hry.nic.in. Prospective bidders are requested to regularly visit/check the Board’s website. The cost of
bid document is Rs.1000/- (Rupees One thousand only) which is non-refundable and Earnest Money Deposit of Rs.
16,000/- (Rupees Sixteen thousand only) to be deposited through e-tender portal and the proof of EMD deposited slip
should be enclosed/uploaded with the tender document. Offline/incomplete bids and the bids received after the schedule
time will be rejected straightway. The Competent Authority of the Board reserves the right to accept or reject any or all
tenders without assigning any reason thereof. Conditional tender will not be accepted. The technical bids will be
opened/evaluated by the authorized committee in the Board’s Committee Room in presence of the bidders/authorized
representatives who may be present. Financial bids of those bidders will be opened who will qualify in technical bid.
The date and time of opening of financial bid shall be intimated to the technically qualified bidders in due course.
For any query/clarification/difficulty regarding tendering process, please contact on:

Address:
Assistant Secretary (Publication)
Board of School Education Haryana,
Bhiwani-127021.
E-mail: aspub@bseh.org.in
Mobile No. 9416629936, 9813601608

SECRETARY

4

<!-- page 5 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

Section-2
Technical Qualification Criteria
1.

TENDER FEE
The Bidders must submit Tender Document fee of Rs. 1000/- (One thousand only)
(Non-refundable) deposited through online and hard copy of fee deposited slip must be
attached/uploaded with the Technical Bids.

2. EARNEST MONEY
The Bidders must submit tender document earnest money of Rs.16,000/- (Sixteen thousand
only) to be deposited through online and hard copy of fee deposited slip must be
attached/uploaded with the Technical Bids.
3.

REGISTRATION CERTIFICATES
The firm must provide copies of the following Registration Certificates:

i) GST Registration Certificate.
ii) Registration certificate of the Firm.
iii) PAN of firm/Owner
4. The firm must have minimum average annual financial turnover (as certified by the
Chartered Account) during the last three years, ending 31st March of the previous financial
year, should not be less than 30% of the value of the work.
2023-2024
2024-2025
2025-2026
5.

Rs. ______________
Rs. ______________
Rs. ______________

Work Experience
The firm should have experience of minimum three years in the field of printing and supply of such
items. The firm should submit at least one satisfactory completion/execution certificates of the
printing job work.

6.

MSME firms registered only in Haryana State are entitled/eligible for relaxation under this
provision as per instructions of the appropriate Government/Authority.

5

<!-- page 6 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

SECTION-3
INSTRUCTIONS TO BIDDERS

3. INTRODUCTION
01.

Scope of Bid
1. The Secretary/Chairman, of Board of School Education Haryana, Bhiwani is the competent
authority to approve the tender and for all issues related to the tender, before and after issuance
of the tender and his orders shall be final and binding for one and all in all respects.
2. Board of School Education Haryana, Bhiwani hereinafter referred to as the Board, issues these
Bidding Documents for the supply of Goods and Related Services.

Amendment of Bidding Documents

02.
i)

At any time prior to the deadline for submission of Bids, the Board may amend the Bidding
Documents by issuing an addendum/corrigendum on the website only. No
addendum/corrigendum will be published in the newspapers.
ii) The amendment if any will be displayed on the Board’s website. The amendment will be
binding on all the Bidders. Bidders are advised to keep themselves updated with the information
displayed on the website of the Board and the Board shall not be responsible in case the bidder
has not received such addendum /corrigendum in the manner stated above.
iii) In order to afford Prospective Bidders reasonable time in which they can take the amendment
into account in preparing their Bid, the Board may at its discretion extend the deadline for the
submission of Bids by giving extended date on website only.
03.

Bid Prices
i)

The Bidder shall indicate on the Bid Submission Form and Price Schedule, inclusive of
cost of paper and other material, all jobs, related services and all other taxes etc., which
their firm proposes to supply under the contract. No Extra payment will be made for any
job-related service/Tax.

04. Earnest Money
i)

The bidders shall have to furnish, as part of the bid, Earnest Money in the amount specified
in the Brief information on Bid Document (Section-1)
ii) The Earnest Money is required to protect the Board against the risk of bidder’s conduct
which would warrant forfeiture of Earnest Money. The Earnest Money will be deposited
through online mode. Earnest money will be adjusted against Performance Security.
iii) EMD of unsuccessful bidder will be returned through online portal.
iv) EMD of Successful bidder will be returned after completion of work and final payment.
v) Earnest Money will be forfeited:
a. If a Bidder withdraws the Bid or does not accept the correction of errors during the
period of Bid validity specified by the Bidder on the Bid form; or
b. In case of the successful Bidders fails to sign in the contract and furnish the
Performance Security.
c. In case of fraudulent and corrupt practices as detailed in Clause 13.
d. If a successful bidder has been found incapable of executing the assigned job to the
satisfaction of the Board, which may reflect adversely on the image of
the Board/Govt., the earnest money will be forfeited and the competent authority may
allot the work to some other eligible firm.

6

<!-- page 7 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

05.

Format and Signing of Bid
i)

The Bidder shall submit only one Bid. Principal Firm and its sister concern firms cannot
submit separate bids.
ii) Failure to abide by any of the instructions will make the bid liable to be rejected.
06. Opening of Bids by the Board
i)

The Committee of the Board constituted by the Chairman/Secretary will open the online
Technical Bids in presence of the bidders/representatives, who may wish to be present

ii)

The Board will prepare minutes of the Bid Opening, including the information disclosed
to those present in the meeting.

iii) The evaluation of Technical Bids will commence after its opening and evaluation will be
made with respect to Earnest Money, Qualification Criteria and other information
furnished in DNIT. On the basis of such evaluation a list of the responsive Bids will be
drawn up. The Financial Bids of only those Bidders, who qualify in the evaluation of the
Technical Bids, will be considered.
iv) The Board will open financial bids of only technically qualified firms and will prepare the
minutes of the opening of the Financial Bids.
07. Clarification regarding Bids
i)

To assist in the examination, evaluation and comparison of Bids, the Board may at its
discretion to ask the Bidder for a written clarification of his/her Bid. No change in the
prices or substance of the Bid shall be sought, offered, or permitted, except to confirm
the correction of arithmetical errors, if discovered by the Board in the Evaluation of the
Bids.

ii)

No Bidder shall contact the Board on any matter relating to firm’s Bid from the time of
the Bid opening to the time the contract is awarded. Any attempt by any Bidder to
influence the Board’s Bid Evaluation, Bid Comparison or Contract Award decision in
any manner may result in summary rejection of his/her Bid and this will be treated as a
fraudulent and corrupt practice and in such cases the earnest money of the firm will be
forfeited besides any other action as deemed fit by the Board.

08. Award Criteria
i)

Before awarding the contract, the Board will evaluate the bids. If at any stage prior
opening the financial bids and even afterwards, it is found that any firm has indulged into
corrupt and fraudulent practices as laid down in Tender Document and the Board shall
have the discretion to reject the bid and to allot/redistribute the job to any other firm and
such orders of the Chairman/Secretary shall be conclusive and binding upon the defaulter
bidder/firm.

ii)

The Board may in its discretion redistribute awards of contract to eligible bidder/s
keeping in view the capacity/prior performance of the bidder/s, provided the bidder/s are
agreed to match the lowest evaluated substantial responsive bid.

iii) The Board also reserves the right to negotiate as per norms of the purchase/ negotiation
policy approved by the State Govt.

7

<!-- page 8 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

09.

Board’s Right to vary Quantities

10.

i)

At the time of award of contract, the Board reserves the right to increase or decrease the
quantity of goods by normally up to 50 (Fifty) percent in each subsequent order from quantity
originally specified in the Schedule of Specification in respect of the additional quantity of
the Conditions of Contract. However, in emergent situation, the Chairman/Secretary of the
Board shall have the power to exceed the order even more than 50% by allowing extra time
for execution of the job as deemed fit by him.

ii)

The Chairman/Secretary of the Board may repeat/extend the order in parts within the
validity period of bids and even afterwards or get printed the Stationery Items of the
subsequent session/s on the rates previously approved by the Board Office on the same
terms and conditions of the tender from the willing firms who had executed the job of
printing and supply of stationery items after approval of rates by the Board Office lastly
and in such cases the time period of printing and supply of stationery items or its
extension will also be decided by the Chairman/Secretary.

Board’s right to accept any Bid and to reject any or all the Bids
The Secretary/Chairman of the Board reserves the right to accept or reject any Bid and all Bids
at any time prior to award of contract.

11.

Notification of Award and Issue of Supply Orders
i)

Prior to the expiration of the period of Bid Validity, the Board will notify the successful
Bidder, in writing through registered letter or E-mail that the firm’s Bid has been accepted.

ii)

The placement of work order/purchase order will be treated as the formation of contract.

iii) Upon the successful Bidder furnishing of Contract Form and Performance Security, the Board
will promptly notify each unsuccessful Bidder and will discharge his/her Earnest Money.
iv) Successful Bidders will complete the delivery of awarded goods definitely within prescribed
time from the next day of handing over the work order and delivery of MSS. 02 days will be
given extra for preparation & submission of proof in the Board’s Office personally by the Firm
by sending messenger to avoid delay. Time taken by this office for proofreading is excluded
in said time period. The responsibility for getting in time clearance of proofs from the Board’s
office shall rest exclusively with the printer. It is the responsibility of the Printer to collect the
Manuscripts and all other relevant material necessary for starting the job of printing &
manufacturing.
12.

Signing of contract and depositing of Performance Security
i)

At the same time as the Board notifies the successful bidder that the firm’s Bid has been
accepted, the Board will send the bidder the Contract Form provided in Tender documents.

ii) Within seven (07) days from the issuance of the intimation letter regarding acceptance of the
Bids/rates, the successful bidder shall sign the contract form with date and it should be
personally handed over in The Board’s office along with Performance Security for an amount
of 10% of the contract value failing which a penalty @ Rs.500/- per day will be imposed,
otherwise action as deemed fit by the Chairman including forfeiture of the earnest money or
also blacklist the firm and to assign the job to the next eligible and willing firm or also to
enhance the amount of penalty can be taken and such order of the Chairman will be final and
binding upon the firm. However earnest money deposited along with the Bid, may be adjusted
against the Performance Security. If the amount of Performance Security exceeds beyond
Earnest Money, balance Performance Security will be furnished along with the Contract Form.

8

<!-- page 9 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

Performance Security may be deposited through RTGS/Demand Draft at the fee counter of the
Board at Bhiwani.
iii) If the successful bidder does not accept the award of contract, Board may forfeit the earnest
money and assign the award to one of the next lowest Evaluated Bidders willing to execute the
job on L-1 Rates or call for new Bids.
13. Corrupt or Fraudulent Practices
i)

The Board requires the Bidders to strictly observe the laws against fraud and corruption, as in
force in India, namely, Prevention of Corruption Act, 1988.

ii) “Corrupt practice” means the offering, giving, receiving or soliciting of anything of value to
influence the action of a public official in the procurement process or in contract execution.
iii) “Fraudulent practice” means misrepresentation of facts in order to influence a procurement
process or the execution of a contract which is detrimental to the Board and include collusion
practice among Bidders (prior to or after Bid submission) designed to establish bid price at
artificial, non-competitive levels and to deprive the Board of the benefits of free and fair
competition.
iv) If in any case it is found that a firm has tried to cheat the Board by using sub-standard paper or
any other material intentionally or in any other way, such cases will also be treated with in the
ambit of fraudulent practices, and penalty will be imposed as per provision of the tender.
v) If at any stage, it is found that a particular firm has misrepresented/ concealed the facts or the
contents of the documents and such documents submitted by the firm are found to be wrong or
false, such conduct of the firm shall also be dealt with under fraudulent practices.
14. Any point not covered under the Terms & Conditions of the tender
For any point which does not cover under the provisions of the tender, the Chairman of the
Board shall be the final authority, whose orders in any of such issues at all stages shall be final
for one and all as a matter of binding in all respects.

9

<!-- page 10 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

Section-4
UNDERTAKING BY THE BIDDER
The bidders will submit an undertaking/declaration on One Hundred Rupees Stamp paper
attested by Notary Public.
a) “That we have read and understood all the Terms & Conditions given in the Tender Documents
and our Firm fulfills the eligibility Criteria for executing the Job and information furnished in
the bidding documents is correct to the best of our knowledge and our firm will strictly act in
accordance with terms & conditions of the tender document and our firm is financially capable
to execute the work.
b) The Firm possesses sufficient machinery and other infrastructure capable to execute the order
in time pertaining to the allotted items for which we are bidding. We have also the sufficient
godown space for the safe storage of paper required for the printing of the various items and
storage of the printed material.
c) That our firm has never been disqualified/Blacklisted/Debarred for printing & Supply of any
publication work by the Board of School Education, Haryana/Any other
Board/University/Controller Printing work & Stationery Deptt., Haryana/Govt. of Haryana,
NCERT, New Delhi, Printing Board/Agency/Any semi–Govt. Board in India/any State
Govt./Central Govt. etc. nor any such action is in process against the firm
d) That we shall supply the required quantity of the item/s within stipulated time period.
e) That we shall supply the allotted items within the prescribed time schedule mentioned in the
Tender Documents from the date of receipt of the Work order. We also agree that if allotted
items are not supplied as per the Terms and Conditions of the Tender, Board will be at Liberty
to forfeit our EMD and Performance Security and to impose the penalty as deemed fit by the
Chairman of the Board.
f) The contract would initially be for a period of one year which may be extended on year-to-year
basis for a maximum period of two years as specified in the Tender Document from the last date
of receipt of the Bid.
g) That our firm is capable of procuring the Paper as per Specifications mentioned in the Schedule
of Specifications of the Tender Documents.
h) That our firm will use the presented WPP/craft paper/Muslin cloth etc.
i) That we will furnish the copies of purchase bills of paper, labels of the paper supplied by the
mills along with the invoice.
We undertake to abide by the terms and conditions of the tender, its contents including
addendum/corrigendum/instructions to be issued after issuance of the tender and the orders of
the Chairman, the final authority regarding to all issues will be binding upon us in all respects.
Deponent
VERIFICATION:

That the information given by me/us our firm is true and correct to the best of my knowledge
and belief and nothing has been concealed therein.

Deponent

10

<!-- page 11 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

Section- 5
Specifications of Paper & Price Schedule
I. PAPER SPECIFICATIONS FOR THE ITEMS
Ledger Paper/WPP/Craft paper/Art Paper of GSM required for the items shown in the schedule
of specifications Section-5 and as per BIS specification The Paper must conform to BIS
parameters/specifications.
Note: -Paper must be of best quality and fit for writing as well as printing purpose and of uniform
formation with fair smoothness and reasonably free from specks, sieves, holes and other
blemishes and the paper must conform to the necessary parameters and criterion, as laid down by
the Bureau of Indian Standards for the above type of paper.
II.

SAMPLE OF PAPER

No Sample of Paper and other materials to be submitted along with the Technical Bids.
The successful bidders shall submit the samples of paper (One full sheet) and other materials along
with their purchase bill to be used in the items as per specification mentioned in the schedule of
specifications to the Board’s office for approval. No bidder will use any paper and other material
without prior approval of the Board. The Board may inspect the paper & other materials and ready
samples at any time at the Firm’s Premises if necessary. Bidder can submit certified samples of reputed
‘A’ Grade Paper mills like 1. Star Paper Mills. 2 Andhra Paper Mills. 3 Ballarpur Paper Industries Ltd.
4. Hindustan Paper Corporation Ltd. 5. J.K. Paper Mills. 6 Orient Paper Mills. 7. West Coast Paper
Mills etc. Samples of paper submitted to the Board’s office for approval and the finished goods will be
got tested from the paper laboratory to ensure the use of correct and prescribed paper by the firm. No
firm in any case should use the paper other than the samples submitted to the Board’s office. However,
the firm can use prescribed paper of another Mill with the prior approval of the Board otherwise a very
serious view by treating the matter under fraudulent practices can be taken. Lab Test Charges shall be
borne by the firm and deduction of lab test charges shall be made from the firm’s bill at the time final
payment.

11

<!-- page 12 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

Price Schedule
SCHEDULE OF SPECIFICATIONS FOR PRINTING & SUPPLY OF VARIOUS ANNUAL STATIONERY
ITEMS FOR THE YEAR 2025-26
Sr. No. Name of item &
Description

Size & Printing

Quantity

Time
allowed

Prescribed paper BIS
Specification to be used

4-ASS-I Form of
A/Books

7 ½ ”x10” Single
side printing as
per MSS.

30,000 Copies
(1000 copies
each packet in
6mm plastic
step in cross)

30 days

WPP 60 GSM of ‘A’
Grade paper of reputed
Mill to be used by the
printer.

4-ASS-II

8½”×13½” Both
side printing as
per MSS

30,000 Copies
(1000 copies
each packet in
6mm plastic
step in cross)

30 days

Maplitho paper 60 GSM
of A Grade paper Mill to
be used by the printer.

7 ½ ” x10” Both
side printing and
Ruling as per
MSS.

5,000 Copies
(1000 copies
each packing)

30 days

A-101 (a)
Register

8 ½ “x 13 ½ “ after
folding Both side
ruling & printing
as per MSS

05 Registers
(100 leaves
each duly
Serial No. 001
to 200)

30 days

A-15 (a) Register

8 ½ “x 13 ½ “ after
folding Both side
ruling & printing
as per MSS

05 Registers
(100 leaves
each duly
Serial No. 001
to 200)

30 days

1.

2.

3.

4.

5.

5/SS Dispatch
Challan form

12

20”x30”/11.6 kg Maplitho
paper 60 GSM of A grade
Paper Mill to be used by
the printer.
i) Ledger paper of 70
GSM of ‘A’grade Paper
Mill to be used by the
printer.
ii) Canvas and Straw
board of 40 oz, Craft
Paper of 60
GSM,Grade-2, for end
paper superior quality
abri & other binding
material to be used by
the printer.
i) Ledger paper of 70
GSM of ‘A’grade Paper
Mill to be used by the
printer.
ii) Canvas and Straw
board of 40 oz, Craft
Paper of 60 GSM,Grade2, for end paper superior
quality abri & other
binding material to be
used by the printer.

Rates to be
quoted
+
tax
applicable
from time to
time
and
delivery
at
Board’s
godown
at
Bhiwani
Rs__________
___
In
words_______
___
Rs__________
___
In
words_______
Rs__________
_________
In
words_______
Rs__________
___
In
words______

Rs__________
___
In
words_______
___

<!-- page 13 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

6.

7.

8.

9.

10.

A-15 (b) Register

8 ½ “x 13 ½ “ after
folding Both side
ruling & printing
as per MSS

05 Registers
(100 leaves
each duly
Serial No. 001
to 200)

30 days

i) Ledger paper of 70
GSM of ‘A’grade Paper
Mill to be used by the
printer.
ii) Canvas and Straw
board of 40 oz, Craft
Paper of 60 GSM,Grade2, for end paper superior
quality abri & other
binding material to be
used by the printer.

Rs__________
___
In
words_______
___

A-37 Register

15”x20” both side
printing stop & cross
ruling as per MSS

05 Registers
(100 leaves
each duly
Serial No. 001
to 200)

30 days

Rs__________
___
In
words_______
___

15”x20” both side
printing stop & cross
ruling as per MSS

05 Registers
(200 leaves
each duly
Serial No. 001
to 400)

30 days

1) 20”x30”/13.5 kg 70 GSM
ledger paper of ‘A’ Grade
paper Mill to be used by
printer.
2) Canvas and Straw board
of 40 oz, Kraft Paper of 60
GSM,Grade-2, for end paper
superior quality abri & other
binding material to be used
by the printer.
1) 20”x30”/13.5 kg 70 GSM
ledger paper of ‘A’ Grade
paper Mill to be used by
printer.
2) Canvas and Straw board
of 40 oz, Kraft Paper of 60
GSM,Grade-2, for end paper
superior quality abri & other
binding material to be used
by the printer.

8 ½ “x 13 ½ “ after
folding Both side
ruling & printing
as per MSS

05 Registers
(100 leaves
each duly
Serial No. 001
to 200)

30 days

i) Ledger paper of 70
GSM of ‘A’grade Paper
Mill to be used by the
printer.
ii) Canvas and Straw
board of 40 oz, Craft
Paper of 60
GSM,Grade-2, for end
paper superior quality
abri & other binding
material to be used by
the printer.

Rs__________
___
In
words_______
___

8 ½ “x 13 ½ “ after
folding Both side
ruling & printing
as per MSS

10 Registers
(100 leaves
each duly
Serial No. 001
to 200)

30 days

i) WPP of 70 GSM of ‘A
‘grade Paper Mill to be
used by the printer.

A-37 Register

A-43 ITR
Register

A-62 Register

13

ii) Canvas and Straw
board of 40 oz, Craft
Paper of 60 GSM, Grade2, for end paper superior
quality abri & other
binding material to be
used by the printer.

Rs__________
___
In
words_______
___

Rs__________
___
In
words_______
___

<!-- page 14 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

11.

12.

13.

14.

15.

16.

A-64 Register

15 ½ “x 13 ½ “
after folding Both
side ruling &
printing as per
MSS

10 Registers
(100 leaves
each duly
Serial No. 001
to 200)

A-66

8 ½ “x 13
“printing on both
side as per MSS

05 Registers
(100 leaves
each duly
Serial No. 001
to 200)

30 days

2,000 Booklets
(28 leaves each
booklet & title
cover extra)

30 days

i) Maplitho paper 70 GSM
of A Grade Paper Mill to
be used by the printer for
text leaves.
ii) Appropriate size of Art
paper of 170 GSM with
lamination of reputed Mill
to be used by the printer
for title cover.

Rs__________
___
In
words_______
___

2,000 copies
(1,000 copies
each packing in
6mm
plastic
stap in cross)
60,000 (1,000
copies each
packing in
6mm plastic
stap in cross)

30 days

60 GSM Appropriate size
Maplitho paper to be used
by the printer.

30 days

20”x30”/11.6 Kg WPP of
60 GSM of A’ Grade
paper of reputed Mill to
be used by the printer.

Rs__________
___
In
words_______
___
Rs__________
_________

70,000

30 days

ABR & C-86
Proforma Booklet

AF-06 Proforma

C-114
Q.P. Receipt Slips

C-301 Tag

8½”x13½‫” ״‬
single side
printing .
Title cover single
side printing in
four color with
lamination as per
MSS. Wire
stitched at two
places with perfect
binding.
8 ½ ”x13½ ”
Single side
printing as per
MSS
5”×7½” single side
Printing as per
M.S.S.

3½”x5” single side
printing. one ring
is to be affixed on
left hand side in
the middle at the
distance of 1” as
per MSS.

14

i) WPP of 70 GSM of ‘A
‘grade Paper Mill to be
used by the printer.
ii) Canvas and Straw
board of 40 oz, Craft
Paper of 60 GSM, Grade2, for end paper superior
quality abri & other
binding material to be
used by the printer.
i) WPP of 70 GSM of
ledger Paper Mill to be
used by the printer.
ii) Canvas and Straw
board of 40 oz, Craft
Paper of 60 GSM, Grade2, for end paper superior
quality abri & other
binding material to be
used by the printer.

i) 200 GSM/ PBC ‘A’
Grade paper of reputed
Mill to be used by the
printer.
Ring and muslin cloth
24”x38”to be used by the
printer

Rs__________
___
In
words_______
___

Rs__________
___
In
words_______
___

In
words_______
________
Rs._________
______
(in
words)______
______

<!-- page 15 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

17.

18.

19.

20.

21.

22.

23.

24.

C-4 Proforma

15½”× 26” single
side printing and
ruling as per MSS

10,000 copies
(1,000 copies
each packing)

30 days

CC-S-1
Adjustment of
Advance

8 ½ ”x13 ½” Both
side printing as
per MSS

5,000 Copies
(1,000 copies
each packing)

30 days

17”x 27”/8.9 Kg
Maplitho paper 60 GSM
of A grade Paper Mill to
be used by the printer.

Rs__________
_________
In
words_______

Cert./DB-3

9” ×11½” Single
side printing as per
MSS

3,000
(1,000 copies
each packing
in 6mm plastic
strap in cross)

30 days

WPP of 60 GSM of ‘A’
Grade paper of reputed
Mill to be used by the
printer.

Rs__________
_________

2,000
(1,000 copies
each packing
in 6mm plastic
step in cross)

30 days

Cert-03

9” ×11½” Single
side printing as per
MSS

Maplitho paper of 70
GSM of Grade Paper mill
to be used by the printer

In
words_______
________
WPP of 60 GSM of ‘A’
Grade paper of reputed
Mill to be used by the
printer.

Rs__________
_________
In
words_______
________

Cert-04 Proforma

7½”x10“ Single
Side Ptg. as per
MSS

8,000 copies
(1,000 copies
each packing)

30 days

WPP of 60 GSM of ‘A’
Grade paper of reputed
Mill to be used by the
printer.

Cert./DB-2

9” ×11½” Single
side printing as per
MSS

3,000
(1,000 copies
each packing
in 6mm plastic
strap in cross)

30 days

WPP of 60 GSM of ‘A’
Grade paper of reputed
Mill to be used by the
printer.

Rs__________
___
In
words_______
___

Rs__________
_________
In
words_______
________

Cert-03(A)
Proforma

8½"x13½" Single
side printing as per
MSS.

5,000 copies
(1,000 copies
each packing)

30 days

Cert-07 Register

8½”×13½” after
folding both side
printing & Ruling
as per MSS

20 Registers of
100 leaves
each duly
(Sr. No. 1 to
100 )

30 days

15

Rs__________
___
In
words_______
___

WPP of 60 GSM of ‘A’
Grade paper of reputed
Mill to be used by the
printer.

Rs__________
___
In
words_______
___

Rs__________
_________
In
words_______
________

<!-- page 16 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

25.

26.

27.

28.

29.

Cert-146 (Fee
Verification
Certificate)

8½”×13½” after
folding both side
ruling and printing
as per MSS

10 Register of
100 leaves
each duly
(Sr. No. 1 to
100 )

30 days

Cert-4A

8 ½”x13½ “ Single
Side Printing as
per MSS

3,000

30 days

CL Proforma

8 ½”x11½ “ Single
Side Printing as
per MSS

5,000 copies
(1,000 copies
each packing)

30days

WPP of 60 GSM of ‘A
‘grade Paper Mill to be
used by the printer.

CRP-01

8 ½ “x 11 ½ “after
folding Both side
ruling & printing
as per MSS

10,000 copies
(1,000 copies
each packing)

30days

i) WPP of 60 GSM of ‘A
‘grade Paper Mill to be
used by the printer.

8 ½”x11 ½ “
Single Side
Printing as per
MSS

10,000 copies
(20 copies with
staple each set)

30 days

CS-11 Press copy
(A-4 Size)

i)

Ledger paper of
70GSM (superior
quality) to be used by
the printer.
ii) Canvas and Straw
board of 40 oz, Craft
Paper of 60 GSM,Grade2, for end paper superior
quality abri & other
binding material to be
used by the printer.
WPP of 60 GSM of A’
Grade paper of reputed
Mill to be used by the
printer

WPP 80 GSM of ‘A’
Grade paper of reputed
Mill to be used by the
Printer

Rs__________
___
In
words_______
___

Rs__________
___
In
words______
Rs__________
___
In
words_______

Rs__________
___
In
words______

Rs._________
_____
In
words______

30.

CS-12 Office
copy (A-4 Size)

8 ½”x11 ½ “
Single Side
Printing as per
MSS

10,000 copies
(20 copies with
staple each set)

30 days

WPP 80 GSM of ‘A’
Grade paper of reputed
Mill to be used by the
Printer

Rs._________
_____
In
words_______

31.

CS-13 (Marking
Ins. & Model
Answer)
(A-4 Size)

8 ½”x11 ½ “
Single Side
Printing as per
MSS

10,000 copies
(20 copies with
staple each set)

30 days

WPP 80 GSM of ‘A’
Grade paper of reputed
Mill to be used by the
Printer

Rs._________
_____
In
words_______

32.

CS-38

9”×11 ½ ” Single
side printing as
per M.S.S.

500

30 days

16

23”x36”/18.7Kg
Maplitho of 70 GSM of
“A” grade paper of
reputed Mill to be used
by the printer.

Rs._________
______
(in
words)______

<!-- page 17 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

CS-40

9”×11 ½ ” Single
side printing as
per M.S.S

500

30 days

34.

CS-43 Tyvek
Envelope

2,000

30 days

35.

CS-43 (a) Tyvek
Envelope

2,000

36.

CS-43 (b) Tyvek
Envelope

37.

CS-7
Proforma

9” x13” ready size
Flap 2½
“B.P.2”CP 1¼”
Space -2” printing
as per MSS.
When opening the
sealed envelope the
word
“OPEN”
should be visible
on the flap.
9” x13” ready size
Flap 2½
“B.P.2”CP 1¼”
Space -2” printing
as per MSS.
When opening the
sealed envelope the
word
“OPEN”
should be visible
on the flap.
9” x13” ready size
Flap 2½
“B.P.2”CP 1¼”
Space -2” printing
as per MSS.
When opening the
sealed envelope the
word
“OPEN”
should be visible
on the flap.
8 ½ “x13 ½ “
Single Side
Printing as per
MSS

CS-8
Proforma for
Coverage of the
Syllabus

Declaration form
(Supervisor)

33.

38.

39.

23”x36”/18.7 Kg
Maplitho of 70 GSM of
“A” grade paper of
reputed Mill to be used
by the printer.
Appropriate size of paper
to be used by the printer.
Readymade envelopes to
be supplied by the printer
as per M.S.S.

Rs._________
______
(in
words)_____

30 days

Appropriate size of paper
to be used by the printer.
Readymade envelopes to
be supplied by the printer
as per M.S.S.

Rs__________
_________
In
words_______

2,000

30 days

Appropriate size of paper
to be used by the printer.
Readymade envelopes to
be supplied by the printer
as per M.S.S.

Rs__________
_________
In
words_______

1,000 copies

30 days

17”x27”/10.4 kg WPP 70
GSM of ‘A’ Grade paper
of reputed Mill to be used
by the Printer

Rs__________
_____
in
words_______

8 ½ “x13 ½ “
Single Side
Printing as per
MSS

1,000 copies

30 days

17”x27”/10.4 kg WPP 70
GSM of ‘A’ Grade paper
of reputed Mill to be used
by the Printer

Rs__________
_____
in
words_______
________

9”x11 ½ “ Single
Side Printing as
per MSS

2,00,000
Copies
(1,000 copies
each packet in
6mm plastic
step in cross)

30 days

WPP 60 GSM of ‘A’
Grade paper of reputed
Mill to be used by the
Printer

Rs__________
_____
in
words_______
________

17

Rs__________
_________
In
words_______

<!-- page 18 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

40.

41.

42.

43.

E-11 Verification
Performa

8 ½ “x 11 ½
“single side
printing as per
MSS

7,000 copies
(1,000 copies
each packing)

30days

E-14 (Certificate
Fail/card Record
Register)

8 ½ “x 13 ½ “after
folding Both side
ruling & printing
as per MSS

20 Registers
(100 leaves
each duly
Serial No. 001
to 200)

30days

E-115 Proforma

7 ½ “ x 10” single
side printing as per
MSS

20,000 Copies
(1,000 copies
each packing)

30 days

E-171 Proforma

9”×11½ ” Single
side printing as
per MSS

15,000 Copies
(1,000 copies
each packing)

30 days

i) WPP of 60 GSM of ‘A
‘grade Paper Mill to be
used by the printer.
ii) Canvas and Straw
board of 40 oz, Craft
Paper of 60 GSM, Grade2, for end paper superior
quality abri & other
binding material to be
used by the printer.
i) WPP of 70 GSM of ‘A
‘grade Paper Mill to be
used by the printer.
ii) Canvas and Straw
board of 40 oz, Craft
Paper of 60 GSM, Grade2, for end paper superior
quality abri & other
binding material to be
used by the printer.
20”x30”/11.6 kg WPP of
60 GSM of “A” grade
paper of reputed Mill to
be used by the printer.

WPP of 60 GSM of “A”
grade paper of reputed
Mill to be used by the
printer.

Rs__________
___
In
words_______
___

Rs__________
___
In
words_______
___

Rs._________
_____
In
Words______

Rs__________
___________
In
words_______

44.

45.

46.

E-172 Proforma

E-182 (A)
Register

G-4 Register

9”×11½ ” single
side printing as per
MSS

10,000 Copies
(1,000 copies
each packing)

30 days

8½”×13”, single
side printing as per
MSS. Perforation
be done ¾” of top
side as per MSS

10 Registers
(100 leaves
each duly
Serial No. 001
to 200)

30 days

8½”×13½”after
folding both side
printing & Ruling .
duly Sr. No. 1 to
200 & Canvas
binding as per
MSS

10 Registers
(100 leaves in
each duly
Serial No. 001
to 200))

30 days

18

WPP of 60 GSM of “A”
grade paper of reputed
Mill to be used by the
printer.

i)

WPP 60 GSM of A
Grade Paper Mill to
be used by the printer
ii) Straw board of 40
oz, Craft paper of 70
GSM for upper cover,
binding cloth & other
binding material to be
used by the printer.
1) Ledger paper of 70
GSM ‘A’ Grade paper
Mill to be used by the
printer.
2) Canvas and Straw
board of 40 oz, Kraft
Paper of 60 GSM, Grade2, for end paper superior

Rs__________
_________
In
words_______
___
Rs__________
_________
In
words_______

Rs__________
_________
In
words_______

<!-- page 19 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

47.

48.

G-203 Register

HOS-58 Booklet

49.

HTET Absentee
Proforma

50.

HTET Proforma
Booklet

51.

HTET Seating
Plan sample
Proforma

1) Ledger paper of 70 GSM
‘A’ Grade paper Mill to be
used by the printer.
2) Canvas and Straw board of
40 oz, Kraft Paper of 60
GSM, Grade-2, for end paper
superior quality abri & other
binding material to be used
by the printer.

8½”×13½”after
folding both side
printing & Ruling .
duly Sr. No. 1 to
100 & Canvas
binding as per
MSS

10 Registers
(100 leaves in
each duly
Serial No. 001
to 200))

30 days

8 ½ “ x 13 ½ “
single side ptg. as
per MSS.
Ist in Red Colour
IInd in green
colour
IIIrd in Black
colour.
100 leaves each
booklet each
colour.
8½”x13½” Single
side printing &
wire stitched at 2
place as per MSS

10 Books
(300 leaves in
each Book)

30 days

700 Booklets
(each Booklet
10 Leaves)

30 days

WPP of 60 GSM of A’
Grade paper of reputed
Mill to be used by the
printer

Rs__________
___
In
words_______

A-4 size. two page
both side printed
and 54 pages
single side printing
in single colour as
per MSS and
numbering on each
page. Perforation
be done ¾” of top
side as per M.S.S.
perfect binding.
8½”x11½” Single
side printing as per
MSS

800 Booklets
(each Booklet
contains 56
leaves.)

30 days

i) WPP 70 GSM of A
Grade Paper Mill to
be used by the printer.
ii) Straw board of 32 oz,
Craft paper of 70 GSM for
upper cover, binding cloth
& other binding material
to be used by the printer.

Rs__________
___

WPP 70 GSM of A
Grade Paper Mill to be
used by the printer.

Rs__________
___

1,000

30 days

17×27”/8.9 Kg. WPP
60 GSM of A Grade
Paper Mill to be used
by the printer
ii) Straw board of 40
oz, Craft paper of 100
GSM for upper cover &
Pankaj Marka binding
cloth to be used by the
printer.

Rs__________
_________
In
words_______

i)

Rs__________
_________
In
words_______
________

In
words_______

In
words_______
___
52.

53.

Identity Card
(Inspection)

ME-43

3½”x2½”both side
in two colour
printing & Eye
litter hole at the
middle in the I
card as per MSS.

10,000 copies
(1,000 copies
each packing)

10”×15” after
folding both side
printing and
Ruling as per MSS

20 Registers
(100 leaves
each duly Sr.
No. 1 to 200).

19

30 days

30days

22”x28”/11.9 Kg 200
GSM PBC of Bilt/Star
Mill to be used by the
printer.

1) 70 GSM Ledger paper
of ‘A’ Grade paper Mill to
be used by the printer.
2) Canvas and Straw
board of 40 oz, Kraft
Paper of 60 GSM, Grade2, for end paper

s___________
________
In
words_______
Rs__________
___
In
words_______
___

<!-- page 20 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

54.

55.

56.

57.

58.

59.

60.

61.

62.

NSQF-01

O.I.G.S
Envelope
(Secretary)

9”x13 “Single Side
Printing as per
MSS

3,000 copies

30 days

Rs._________
_____

Appropriate Sunshine
Maplitho paper 95 GSM.
of “A” Grade paper of
reputed Mill to be used by
the printer.

Rs__________
_________

In Words------

10”x 4 ½ “, ready
size superior
quality envelopes
printing in two
colors as per MSS,

1,000
Envelopes

10”x 4 ½ “, ready
size superior
quality envelopes
printing in two
colors as per MSS,

1,000
Envelopes

Q.P. Record
Proforma for
center
Superintendent

9”x11½ “Single
Side Printing as
per MSS

60,000 copies

30 days

WPP 60 GSM of A
Grade Paper Mill to be
used by the printer.

Rs__________
In
words_______

RCA-2

8½” ×13½” after
folding both side
printing & Ruling.
duly Sr. No. 1 to
100 & Canvas
binding as per
MSS

100 Registers
(100 leaves in
each duly
Serial No. 001
to 200))

30 days

1) Ledger paper of 70 GSM
‘A’ Grade paper Mill to be
used by the printer.
2) Canvas and Straw board
of 40 oz, Kraft Paper of 60
GSM, Grade-2, for end
paper superior quality abri
& other binding material to
be used by the printer.

Rs__________
_________

8¾”x13” ready
size BP=¾”
CP=½”,flap – 1½”
extra single side
printing as per
MSS

10,000
Envelopes

30 days

Appropriate size of Craft
paper of 80 GSM of Star
paper Mill to be used by
the printer.

Rs__________
_________

6”x12¾” ready
size BP=¾”
CP=¼”,flap – 1½”
extra single side
printing as per
MSS
8½” ×13½” Single
side printing &
ruling as per MSS

10,000
Envelopes

Appropriate size of Craft
paper of 100 GSM of Star
paper Mill to be used by
the printer.

Rs__________
_________

O.I.G.S
Envelope
(Chairman)

S-11 A
Envelope

S-11 B
Envelope

S-3 Proforma

SEC-4
Craft Paper
Envelope

13”X 9 ½” ready
size, Flap 2 “, B.P
1”, C.P. 1”,
Printing as per
MSS.

20,000 (1,000
copies each
packing in
6mm plastic
strap in cross)
30,000
envelopes

20

30 days

18”x23”/8 kg Maplitho
Paper of
60 GSM to be used by the
printer.

30 days

30 days

30 days

Appropriate Sunshine
Maplitho paper 95 GSM.
of “A” Grade paper of
reputed Mill to be used by
the printer.

WPP 60 GSM of A Grade
Paper Mill to be used by
Printer

In
words_______
Rs__________
_________
In
words_______

In
words_______

In
words_______

In
words_______
Rs._________
__________
(in words)

30 days

Appropriate size of Craft
Paper of 100 GSM Star
paper Mill to be used by
the Printer

Rs__________
___
In
words_______

<!-- page 21 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

63.

64.

65.

SSE-17 Proforma

8½“ x 13½ ” single
side printing as per
MSS

10,000 Copies

30 days

17”x27”/ 8.9 kg of 60
GSM of “A” grade paper
of reputed Mill to be used
by the printer.

Rs._________
__________
(in
words)______
____________

Supervisor Alpha
Numeric code
proforma

9”x11½ “ Single
Side Printing as
per MSS

2,00,000
copies

30 days

WPP 60 GSM of A
Grade Paper Mill to be
used by the printer.

Rs__________
___
In words____

White Envelops

10”x 4 ½ “, ready
size superior
quality envelopes
as per MSS,

2,000

30 days

Appropriate Sunshine
Maplitho paper 95 GSM.
of “A” Grade paper of
reputed Mill to be used by
the printer.

Rs__________
___
In
words_______

NOTE: - The delivery period of the various items from the next date of work order has been shown in Section-1, Brief information on
bid. Time taken by this office in proof reading is excluded in the said time period.

Signature-----------------------------------------Name of firm-------------------------------------Mobile No----------------------------------------PAN No.------------------------------------------Email ----------------------------------------------

21

<!-- page 22 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

SECTION -6
Bid Submission Form
To,
The Secretary
Board of School Education Haryana
Bhiwani
Sir,
Having examined the Bidding Documents including Agenda Nos._____________ the receipt of which is hereby
acknowledged, we, the undersigned, undertake and offer to supply and deliver various Stationery items for the
year 2026-2027.
Further, we undertake that, if our Bid is accepted, we will deliver the goods as per specifications and in accordance
with the delivery schedule specified in the Schedule of Requirements and specifications.
If our bid is accepted, we shall be bound to furnish the Performance Security as equivalent to 10% of the Contract
Price for the due Performance of the Contract, in the form prescribed by the Board and the same will be submitted
within 07 days along with the Contract Form. Validity for the contract would initially be for a period of one year
which may be extendable on year-to-year basis for a maximum period of two years
I/We agree to abide by this Bid for the Bid Validity period of the contract would initially be for a period of one
year which may be extendable on year-to-year basis for a maximum period of two years from the date of opening
of Technical Bid. It shall remain binding upon us and may be accepted at any time before the expiration of that
period.
I/We agree that the following documents are deemed to be part of the Bid.
The placement of Work Order shall constitute a binding Contract between the Parties.
I/We undertake that, in competing for and for execution of the Contract if allotted (and, if the award is made to
me/us, in executing) the above Contract, we will strictly observe the laws against fraud and corruption as in force
in India namely “Prevention of Corruption Act, 1988”
I/We hereby certify that I/We have taken steps to ensure that no person acting for us or on our behalf will engage
in bribery.
I/We understand that you are not bound to accept the lowest/ to accept any bid or you may receive and you reserve
the right to reject any bid/ all bids without assigning any reason to me/us.
I/We confirm that I/we at the moment fulfill all the eligibility requirements as per Clause 2 and 3 of the Bidding
Documents.
Dated this _______ day of ____________ 2026
Duly authorized to sign Bid for and on behalf of _______________________________

Signature with seal

22

<!-- page 23 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

Section-7
CONDITIONS OF CONTRACT
01.

Definitions
i) In this contract, interpretation of terms will be as follows: —
ii) “The contract” means the agreement entered into between the Board and the Supplier, as
recorded in the Contract Form signed by the parties, including the printer/supplier all the
attachments and appendices thereto and all documents incorporated by reference therein.
iii) “Contract Documents” means the documents listed in the Contract Agreement, including any
amendment thereto.
iv) “Contract Price” means the price payable to the Printer/Supplier, as specified in the Contract
Agreement, subject to such additions and adjustments there to or deductions there- from, as
may be made pursuant to the Contract.
v) “Completion” means the fulfillment of total supply of goods as per specifications, by the
Supplier in accordance with the terms and conditions set forth in the Contract Tender and the
instructions given from time to time, to the entire satisfaction of the Board.
vi) “Goods” means all of the commodities and/or other materials that the Supplier is required to
supply to the Board under the Contract.
vii) "Related Services" and “Services” means services ancillary to the supply of the Goods, such as
transportation and insurance, and any other incidental services and other obligations of the
Supplier covered under the contract;
viii)
“Supplier” means the natural person, private or government entity, or a combination of the
above and the printer whose Bid to perform the Contract has been accepted by the Board and
is named as such in the Contract Agreement.
02.

Entire Agreement
i)

The Contract constitutes the entire agreement between the Board and the Supplier and
supersedes all communications, negotiations and agreements (whether written or oral) of the
parties with respect thereto made prior to the date of Contract.
ii) No amendment or other variation of the Contract shall be valid unless it is in writing, is dated,
expressly refers to the Contract, and is signed by a duly authorized representative of each party
thereto
03.

Specification and Standard: The goods supplied under this contract shall conform to the standard mentioned in the
specifications and standards mentioned in the schedule of requirements and specification.

04.

Performance Security
i)

Performance Security/any payment of already lying with the Board is not adjustable towards
the Performance Security of the present tender.
ii) Within 07 (Seven) days, after the Board's issue of the notification of award, the Supplier shall
furnish Performance Security along with contract form personally to the Board for an amount
of 10% of the contract value, validity of the contract would initially be for a period of one year
which may be extendable on year-to-year basis for a maximum period of two years from the date
of award of contract. In disputed cases, it will be at the discretion of the Chairman of the Board,
to extend the period. It will be the responsibility of the firm to collect the order letter, MSS etc.
within the stipulated period personally from Board’s office otherwise such period shall be
counted as delay period and deductions shall be made as specified in penalty clause.

23

<!-- page 24 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

iii) The proceeds of the Performance Security shall be payable to the Board as compensation for
any loss resulting from the Supplier's failure to complete his/her obligations under the contract
to the entire satisfaction of the Board and/or on account of deduction of the amount of penalties
and/or on account of any act of the bidder as defined in corrupt and fraudulent practices.
iv) In the event of any contract amendment, the Supplier shall furnish the amendment to the
Performance Security within 07 (seven) days of such amendment, rendering the same valid for
the contract, as amended.
v) The Performance Security will be released only after the final payment of the bill.
vi) For any misuse of material supplied by the Board or for use of any non-prescribed/ sub-standard
material by the firm shall result in forfeiture of the Performance Security and payment of the
firm, in addition to any other action to be taken by the Board, including black listing the firm
and in accordance with provisions of the tender, as per law or as deemed fit by the Chairman.
The Chairman may order registration of a criminal case against the firm in case of fraudulent
act of the firm for such an act. The MSS, proofs and whole material as specified in this tender
have to be returned to the Board otherwise payment bill will not be processed.
05.

Inspections and Tests
i)

The Board reserves the right to inspect the prescribed material such as Paper or any other
materials at any time after placement of order and during the work in progress and may ask for
the purchase vouchers and the orders placed with the relevant material manufacturing firms and
their relevant documents.

ii) The inspections of paper of various items under print may be conducted by the officers of the
Board in the premises of the Supplier. In case of non-assistance of the firm and/or failure of the
firm in having arranged the paper a penalty of @ of Rs.5000/- per visit in addition to the actual
expenditure incurred by the Board on visiting the firm shall be imposed.
iii) If at any stage any inspected Goods fail to confirm to the specifications, the Board has the right
to reject them and ask the Supplier to either replace the rejected goods or make all alterations
necessary to meet specification requirements free of cost to the Board, within a period of 10
(Ten) days of intimating such rejection or within the period as specified by the Chairman and
the Board will have also the right to take any action against the firm in accordance with the
provisions of tender, law or as deemed fit by the Chairman, in addition to replacement of the
defective Goods.
iv) The Board’s right to inspect, where necessary, reject the Goods after the Goods' arrival at the
final destination shall in no way be limited or waived by reason of the Goods having previously
been inspected, and passed by the Board or its representative prior to the Goods dispatch from
the place of Supplier.
v) Nothing in Clause 7 shall in any way release the Supplier from any warranty or other obligations
under this contract.
vi) The Board reserves the right to inspect at the premises of the Supplier at any time where the
paper is stored to ascertain the use of prescribed paper and the Board shall have also the right
to check the documentary record of the firm.
vii) Board may take samples of finished/unfinished allotted items at random for technical test
checking and may get it tested in all respects from any reputed lab/labs. or the Official Machine.
The supplier will bear the cost of such lab tests.
viii) Physical verification of firm can be done by board before or after giving the work order.
06.

Packing and documents
The packing of stationery items should be as per specification laid down in section-5.

24

<!-- page 25 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

07.

Delivery and Documents
i)

Time of delivery of the items of the prescribed specifications and high quality shall be essence
of the contract. The prescribed time limit for the job will begin next day from the date of
issuance of the order letter and MSS. 02 (Two) days will be given extra for preparation &
submission of proofs in the Board’s office The penalty will be imposed for late supply as
specified in the Schedule of delivery.
Incidental Services

i)

As specified in the Contract Form, the Supplier is required to provide all work-related services,
including loading/unloading at the points of dispatch and receipt. No extra payment will be
made by the Board except of Rates given by the bidder.

08.

ii) No additional costs will be borne by the Board towards such services.
09.

Terms of Payment
100% amount of Bill shall normally be paid within 30 working days after delivery of respective
whole quantity. Payment Bill shall be paid after receipt of the following Documents: i) Original MSS and all approved Proofs
ii) Acknowledged delivery receipts from the official of the Board.

10.

Prices
Prices charged by the Supplier for Goods delivered under the contract shall not vary from the
prices notified in the award of contract.

11.

Contract Amendments
No variation modification in the terms of the contract shall be made except by written
amendment signed by the parties.

12.

Assignment
i)

Neither the Board nor the Supplier shall assign, in whole or in part, its obligations to perform
under the contract, except with the prior written consent of the other party.
ii) No bidder is allowed to sublet the contract awarded to his firm and not even allowed to get any
of the jobs done from any other firm.
13.

Delay in the Supplier's Performance
i)

Delivery of the Goods as per specifications and Performance of the Services shall be made by
the Supplier in accordance with the time schedule specified by the Board in the Bid Submission
form and Price Schedule, to the entire satisfaction of the Board with a pre-agreed sanction
regarding deduction of liquidated damages for delay from the supplier’s bill as specified in
Section-9 criteria for imposition of Penalties.
ii) In case of an inordinate delay in the supply of the goods/any unexcused delay by the Supplier
in the Performance of its delivery obligations hurting the image of
the Board/Govt. shall render the supplier liable to any or all of the following sanctions in
addition to deduction of the liquidated damages mandatory to be imposed as mentioned above
and as per clause in Section 9: —
a) Forfeiture of its Earnest Money, Performance Security and payment of bills.
b) Termination of the Contract for defaults.
c) Black Listing of the firm.
iii) Any other action, as deemed fit by the Chairman/Secretary. If at any time during Performance
of the contract, the Supplier should encounter conditions impeding timely delivery of the
Goods, the Supplier shall promptly notify the Board in writing of the fact of the delay, it’s likely
duration and its cause(s). As soon as practicable after receipt of the Supplier’s notice, the

25

<!-- page 26 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

Chairman of the Board shall evaluate the situation on the merits of the case and may, at its
discretion, extend the Supplier’s time for Performance with or without liquidated damages, in
such case the extension shall be deemed to be ratified by the parties treating this as an
amendment. However, it will be at the discretion of the Chairman to enter into a fresh agreement
to the effect. All powers with regard to this issue rest with the chairman. No representation
regarding extension in time shall be entertained after completion/cancellation of work order.
iv) The power regarding extension of time period and for condoning the delay will be absolutely
at the discretion of the Chairman of the Board, whose decision shall be final and binding in all
respects.
14.

Termination for Default
i)

The Board may without prejudice to any other remedy for breach of contract, by written notice
of default sent to the Supplier, can terminate the contract in whole or part:
(a) If the supplier fails to deliver any or all of the Goods within the time period(s) specified
in the Contract, or within any extension thereof granted by the Board.
(b) If the Supplier fails to perform any other obligation(s) under the contract.
(c) If the Supplier, in the judgment of the Board, has engaged in fraud and corruption, in
competing for or in executing the Contract or has committed gross violation of the
terms and condition of the tender.
ii) In the event the Board terminates the contract in whole or in part, the Board may procure upon
such terms and in such manner as it deems appropriate, Goods or Services similar to those
undelivered, the Supplier shall be liable to pay to the Purchaser for any excess costs for such
similar Goods or Services. However, the Supplier shall continue the Performance of the
contract to the extent not terminated.
15.

Termination of Insolvency
The Board may at any time terminate the contract by giving written notice to the Supplier, if
the Supplier becomes bankrupt or otherwise insolvent. In this event, termination will be without
compensation to the Supplier, provided that such termination will not prejudice or affect any
right of action or remedy which has accrued or will accrue thereafter to the Board. After
termination of Agreement/Contract with the 1st bidder, the Chairman/ Secretary have right to
assign the work to the other bidder, if other bidder agree/willing to do the work at the same rate
by the 1st bidder.

16.

Resolution of Disputes/Arbitration Clauses
All disputes or differences arising between the parties out of or relating to meaning and
operation of effect of the contract or breach thereof shall be settled by arbitration in accordance
with the rules and regulation of arbitration act. The sole arbitrator shall be appointed on mutual
concurrence of both parties. However, it is the discretion of the Chairman to accept or not to
accept decision of the Arbitrator. In case of any dispute the legal jurisdiction will be at courts
of Bhiwani.

17.

Taxes and duties
The supplier shall be entirely responsible for all taxes, duties, road permits etc.

26

<!-- page 27 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

18.

Any point not covered under the terms & conditions of the tender
For any of the points arising at any stage which is not covered under the provisions of the
tender, the Board’s Chairman shall be the final competent authority, whose orders shall be final
and binding for one and all.
A Negotiation can be held with the firms as per negotiation policy of the Govt. of Haryana

19.

Force Majeure

20.

i)

The Supplier shall not be liable for forfeiture of its Earnest Money, Performance Security,
Liquidated Damages or Termination for Default, if and to the extent that, its delay in
Performance or other failure to perform its obligations under the contract is positively the result
of an event of Force Majeure.

ii) For purposes of this Clause, "Force Majeure" means an event beyond the control of the Supplier
and not involving the Supplier's fault or negligence and not foreseeable. Such events may
include, but are not restricted to, acts of the Board either in its sovereign or contractual capacity,
wars or revolutions, fires, floods, epidemics, quarantine restrictions and freight embargoes.
iii) If a Force Majeure situation arises, the Supplier shall promptly notify the Board in writing of
such conditions and the cause thereof. Unless otherwise directed by the Board in writing, the
Supplier/ firm shall continue to perform its obligations under the contract as far as is reasonably
practical, and shall seek all reasonable alternative means for Performance not prevented by the
Force Majeure event.

27

<!-- page 28 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

Section-8
CONTRACT FORM
(On Hundred Rupees Stamp Paper)
THIS AGREEMENT made the ............ day of ...................... 2026 between the Board of School
Education
of
Haryana
(hereinafter
called
“Board”)
of
the
one-part
and...................................................................................................
(Name
of
Supplier)
of..............................(Address).............................................................................................................
(hereinafter called “the Supplier”) of the other part.
WHEREAS the Board is desirous to get certain items manufactured and has accepted a bid by the
Supplier for the supply of those items in the sum of............................................ (Contract Price in Words
and Figures) (Hereinafter called “the Contract Price”).
NOW THIS AGREEMENT WITNESSETH AS FOLLOWS: 1. In this Agreement words and expressions shall have the same meanings as are respectively assigned
to them in the Conditions of Contract referred to.
2. The following documents shall be deemed to form and be read and construed as part of this
Agreement, viz.:
Section
Section 1
Section 2
Section 3
Section 4
Section 5
Section 6
Section 7
Section 8
Section 9

Brief information on bid document.
Technical qualification criteria.
Instructions to bidders and tables of clauses
undertaking by the bidder
Schedule of specifications & price schedule
Bid submission form
Conditions of contract
Contract form
Criteria for imposition of penalties

3. In consideration of the payments to be made by the Board to the Supplier as hereinafter mentioned,
the Supplier hereby covenants with the Board to provide the goods and services and to remedy defects
therein in conformity in all respects with the provisions of the Contract.
4.The Board hereby covenants to pay the Supplier in consideration of the provision of the goods and
services and the remedying of defects therein; the Contract Price or such other sum as may become
payable under the provisions of the Contract at the times and in the manner prescribed by the Contract.

Signatures with seal of the Supplier/Bidder
Full Name …………………………………...
Full Address………………………………….

28

<!-- page 29 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

Section-09
Criteria for Imposition of Penalties
(A)

Paper Quality:

(i)

For use of prescribed Paper but exceeding the permissible tolerance of the substance (as laid
down by B.I.S) penalty will be imposed as under: a)

For deviation of grammage 01-05:

2% of the total payable amount of the title.

b)

For deviation of grammage 06-10:

5% of the total payable amount of the title.

c)

For deviation of grammage 11-15:

10% of the total payable amount of the title.

d)

For deviation of grammage 16-20:

15% of the total payable amount of the title.

e)

For deviation of grammage>20:

20% of the total payable amount of the title.

(ii)

If it is found that a supplier has used un prescribed/substandard paper/muslin cloth, the whole
supply can be rejected by the Chairman and the supplier will have to resupply the rejected
items with correct specification free of cost within 10 days or within the time period as
prescribed by the Chairman or the firm will have to act as per orders by the Chairman, failing
which the Chairman reserves the right to forfeit the Earnest Money, Performance security,
amount of the bill of supplied of items and black-list the firm, besides imposition of any other
penalty as deemed fit by him.

(iii)

For all other deficiency found in the test report a penalty @ 0.5% per deficient para-meter of
the test norms of BIS on the total payable amount will be imposed on the printers/suppliers up
to 10 points and if it is over 10 points, penalty rate would be 1% of the total payable amount.

(B)

Printing/ Stapling etc.
Deduction at the following rates will be made in case of followings mistakes: (i) For printing mistake.

25 paise per mistake per piece.

(ii) For poor quality of printing

25 paise per mistake per piece.

(iii) For poor quality of cloth lined

50 paise per piece.

For short supply/missing/Torn items in bundles---- Rs 5/-per missing piece of items for the
whole lot and original cost of the item will not be paid.
(i) In case of short size of items than the prescribed size a penalty of 2% of total amount
of that lot item will be imposed.

(C)

(ii) For pasting defect

25 paise per mistake per piece.

(iii) Reg. Numbering misprint

25 paise per mistake per piece.

Penalty on account of late submission of contract form and Performance security:
If a supplier does not submit the contact agreement form and Performance Security within 07
days after intimation of awards, in such cases penalty @ Rs. 500/- per day up to next 10 days
will be imposed and thereafter it will be at the discretion of the Chairman to forfeit the earnest
money and/or black list the firm and/or to enhance the amount of penalty and to assign the job
to the next eligible willing firm.

29

<!-- page 30 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

(D)

Penalty on account of non-assistance of the firm or failure to arrange the paper for inspection:
In case of non-assistance of the firm to the visiting party during inspection of the firm or if a
printer fails to get inspected the paper to the visiting inspection team penalty of Rs. 5000/- per
visit shall be imposed, in addition to the actual expenditure incurred by the board on visiting
the firm.

(E)

Penalty for unspecified defects:
For any defects of the nature not specified in the tender, it will be at the discretion of the
Chairman of the Board; to impose the penalty as per merit of the case/as deemed fit by him and
orders of the Chairman shall be final and binding.

(F)

Forfeiture of Earnest Money, Performance Security and payment for the job executed or part
thereof:
Earnest money and/or Performance security, and/or full/part payment can be forfeited in case
of corrupt and fraudulent practice exercised by the bidding firm as detailed in Section -3 or in
case of incapability of the firm to execute the job which may reflect the reputation of the
Board /Govt. adversely.

(G)

(H)

Penalty for non-return of Proofs/MSS/Positives etc. In case of non-submission of documents,
the bill of the supplier for payment will not be processed. If any printer does not return the
Proofs/MSS/Positives etc. to the Board with his bill, a penalty @ Rs.1000/- shall be imposed
for each item.
SCHEDULE OF SUPPLY
(i) The prescribed time Period will start from the next day of handing over the order letter and
delivery of MSS. 02 days will be given extra for preparation & submission of proof/material
etc. in the Board’s office. The firm may submit the proofs personally to the Board’s office,
Bhiwani by sending a special messenger to avoid delay. Proof reading time will be given
extra. Schedule of delivery will be as follows:

(ii) Whole quantity delivery to be made within the prescribed time limit after issuance of work
order and handing over the M.S.S. The whole work is to be completed and goods supplied in
the stipulated time, failing which the firm will be liable to imposition of penalty for the late
execution of the job on the part job executed late, payable as per as under:
(I) For delay:
a) For delay up to 05 days
= 2% of the payable amount.
b) For delay up to 06-10 days = 5% of the payable amount.
c) For delay up to 11-15 days
= 10% of the payable amount
d) For delay beyond 15 days
= 15% of the payable amount

30

<!-- page 31 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

Note: If an item is supplied by the firm in parts, the penalty on account of delay will be imposed on
amount of the remaining quantity.
However, in case of emergent situation, Chairman, Board of School Education Haryana shall have the
power to extend the time period of the supply on request/ application of the firm before completion of
work.
Chairman of the Board shall have the power:
Besides above, the Chairman reserves the right to cancel the supply order in case the supply
order is not honored or the work is not completed within the prescribed time limit, forfeit the entire
amount of security, blacklist the firm and recover the difference of cost what-so-ever in getting the
goods supplied and allot the work to any other party. In case however, the firm does not start submitting
the proofs within 5 days after placing the order action as deemed fit by the Secretary will be taken
against the bidder. Chairman of the Board may impose penalty in case of nature of mistakes not covered
in this tender. In case the payment of the bill has already been made, the recovery of amount of penalty
can be made from any of the pending/subsequent bills of the firm.

31

<!-- page 32 -->

BOARD OF SCHOOL EDUCATION HARYANA , BHIWANI

CHECK LIST
Sr.
No.

Name of the Document

Available on page No.

1

Scanned copy of Hard copy of deposited cost of tender Rupees
1,000/- (One thousand only)

2

Scanned copy of Hard copy of deposited earnest Money of tender
Rupees 16,000/- (Sixteen thousand only)

3

Undertaking of the Bidder as per Section-4 on 100/- stamp Paper

4

Scanned of Certificates of satisfactory completion of the printing
job work allotted to the firm in the last three years.

5

The firm must have minimum average annual financial turnover
(as certified by the Chartered Account) during the last three years,
ending 31st March of the previous financial year, should not be
less than 30% of the value of the work

6

Registration certificate of the firm.

7

GST Registration Certificate and PAN of Firm

8

Certified samples of the paper/ Muslin cloth (bearing the seal
mark of the dealer/distributor/Miller) along with cloth lined.

9

Sample as per Specifications as per Clause-II of
Section-05

32
