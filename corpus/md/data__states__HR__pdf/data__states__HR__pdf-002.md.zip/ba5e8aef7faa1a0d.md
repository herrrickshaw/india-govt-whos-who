---
doc_id: "ba5e8aef7faa1a0d"
source_url: "https://cdn.s3waas.gov.in/s3a666587afda6e89aec274a3657558a27/uploads/2018/03/2018030957.pdf"
ministry: "Kaithal"
title: "State DDMA Notification (6146 KB)"
date: ""
pages: 7
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "2b3837dba2cb470e"
---

<!-- page 1 -->

| Extract from Haryana Government Gazette, dated the !6th October, 2007 |
HARYANA GOVERNMENT
REVENUE AND DISASTER MANAGEMENT DEPARTMENT
Notification
The 9th October, 2007

No. 576-ER-6-2007/I59L.—In exercise of the powers conferred by Sub-section (I) of Section 25 of the
Disaster Management Act, 2005 (53 of 2005), the Governor of Haryana is hereby establishes District Disaster
Management Authorities in all the Districts of Haryana consisting of the following members, namely ‘—

L. Deputy Commissioner of the District Chairperson ex-officio

2. Chairman of Zila Parishad Co-Chairperson

3. Additional Deputy Commissioner Chief Executive Officer ex-officio

4. District Superintendent of Police (for Gurgaon District) Member ex-officio

Superintendent of Police/Deputy Commissioner of
Police (Headquarter)

5, Chief Medical Officer Member ex-officio

6. The Superintending Engineer PWD (B&R) concerned Member

7. District Revenue and Disaster Management Officer Member

2, The Headquarters of each District Disaster Management Authority will be at the headquarters of the
District.

3. The District. Disaster Management Authority shall meet at least once in a year, as and when required at
such time and place as the Chairman of the Authority may think fit.

4. The objectives, powers and functions of the District Disaster Management Authority shall be as
follows :—

(2) The District Authority shall act as the district planning coordinating and implementing body for
disaster management and take all measures for the purposes of disaster management in the district
in accordance with the guidelines laid down by the National Disaster Management Authority and
the Haryana State Disaster Management Authority .

(2) Without prejudice to the generality of the provisions of sub-clause (), the District Authority
may—

(@) prepare a disaster management plan including district response plan for the district,

(ii) coordinate and monitor the implementation of the National Policy, Haryana State Disaster
Management Policy, National Disaster Management Plan, Haryana Disaster Management Plan
and District Disaster Management Plan:

(iii) ensure that the areas in the district vulnerable to disasters are identified and measures for the
prevention of disasters and the mitigation of its effects are undertaken by the departments of
the Haryana Government at the district level as well as by the local authorities;

(iv) ensure that the guidelines for prevention of disasters, mitigation of its effects, preparedness
and response measures as laid down by the National Authority and the Haryana State Disaster
Management Authority are followed by all departments of the Government at the district
level and the local authorities in the district.

(५) give directions to different departments at the district level and local authorities to take such
other measures for the prevention or mitigation of disasters as may be necessary;

<!-- page 2 -->

2

(vi) lay down guidelines for prevention of disaster management plans by the department of the
Haryana Government at the districts level and locat authorities in the district;

(vii) monitor the implementation of disaster management plans prepared by the Departments of
the Haryana Government at the district level;

(viii) lay down guidelines to be followed by the Departments of the Haryana Government at the
district level for purposes of integration of measures for prevention of disasters and mitigation
in their development plans and projects and provide necessary technical assistance therefor;

(ix) monitor the implementation of measures referred to in item No. (viii);

(x) review the State of capabilities for responding to any disaster or threatening disaster situation
in the district and give directions to the relevant departments or authorities at the district
level for their up-gradation as may be necessary:

(xi) review the preparedness measures and give directions to the concerned departments at the
district level or other concerned authorities where necessary for bringing the preparedness
measures to the levels required for responding effectively to any disaster threatending disaster
situation;

(xii) organize and coordinate specialized training programmes for different levels of officers,
employees and voluntary rescue workers in the district by State Centre for Disaster
Management Haryana;

(xiii) facilitate community training and awareness programmes for prevention of disaster or
mitigation with the support of local authorities, governmental and non-governmental
organizations;

(xiv) set up, maintain, review and upgrade the mechanism for early warnings and dissemination
of proper information to public;

(av) prepare, review and update district level response plan and guidelines;

(xvi) coordinate response to any threatening disaster situation or disaster,

(xvii) ensure that the Departments of the Government at the district level and the local authorities
prepare their response plans in accordance with the district response plan;

(xviii) lay down guidelines for, or give direction to the concerned Department of the Government
at the district level or any other authorities within the local Jimits of the district to take
measures to respond effectively to any threatend situation or disaster;

(xix) advise, assist and coordinate the activities of the Departments of the Government at the district
level. statutory bodies and other governmental and non-governmental organizations in the
district engaged in the disaster management;

(xx) coordinate with, and give guidelines to, local authorities in the district to ensure that pre-
disaster and post-disaster management activities in the district are carried out promptly and
effectively;

(xxi) provide necessary technical assistance or give advise to the local authorities in the district
for carrying out their functions, :

(छा) review development plans prepared by the Departments of the Government at the district
level, statutory authorities or Jocal authorities with a view to make necessary provisions
therein for prevention of disaster or mitigation:

(xxiii) examine the construction in any area in the district and, if it is of the opinion that the standards
for the prevention of disaster or mitigation laid down for such construction is not being or
has not been followed, may direct the concerned authority to take such action as may be
necessary {0 secure compliance of such standards;

<!-- page 3 -->

3
(xxiv) idenuty buildings and places which could, in the event of any threatening disaster situation
or disaster, be used as relief centres or camps and make arrangements for water supply and
sanitation is such buildings or places;
(xxv) establish stockpiles of relief and rescue materials or ensure preparedness to make such
materials available at a short notice;
(xxvi) provide information to the Haryana Disaster Management Authority relating to different
aspects of disaster management:
(xxvii) encourage the involvement of non-governmental organizations and voluntary social-welfare
institutions working at the grassroots level in the district for disaster management,
(xxviii) ensure communication systems are in order, and disaster management drills are carried out
periodically;
(xxix) perform such other functions as the Haryana Government or the Haryana Disaster Management
Authority may assign to it or as it deems necessary for disaster management in the District.
5. The Chairperson of the District Authority shall, in addition to presiding over the meetings of the
Histrict Authority , exercise and discharge such powers and functions of the District Authority as the District
Authority may delegate to him/her,
| 6. The Chairperson of the District Authority shall in the case of an emergency have power to exercise all
or any of the powers of the District Authority but the exercise of such powers shall be subject to ex-post-facto
atification of the District Authority .
7. The District Authority or the Chairperson of the District Authority may, by general or special order, in
writing, delegate such of its or his powers and functions, under clause 5 or 6 above, as the case may be, to the
Chief Executive Officer of the District Authority , subject to such conditions and limitations, if any, as it or he
deems fit
: 8. The District Authority may, as and when it considers necessary, constitute one or more advisory
committees and other committees for the efficient discharge of its functions
9. The District Authority shall, from amongst its members, appoint the Chairperson of the Committee
| referred to under clause 8 above.
i 0. Any person associated as an expert with any committee or sub-committee constituted under clause 8
above, may be paid such allowances as may be prescribed by the State Government.
DHARAM VIR, '
Financial Commissioner and Principal Secretary to Government
Haryana, Revenue and Disaster Management Department.
4336—-C.S.H.GP., Chd.

<!-- page 4 -->

>
[Extract from Haryana Government Gazette, dated the l6th October, 2007 ]
HARYANA GOVERNMENT
REVENUE AND DISASTER MANAGEMENT DEPARTMENT
Notification
The 9th October, 2007
No. 576-ER-6-2007/I5907.—In exercise of the powers conferred by Sub-section () of Section i4 of the
Disaster Management Act, 2005 (53 of 2005), the Governor of Haryana hereby establishes the Haryana State
Disaster Management Authority consisting of the following members, namely :—
L. Chief Minister, Haryana Chairperson, Ex-officio
2. Finance Minister, Haryana Member
i 3. Health Minister, Haryana Member
4, Rural Development and Panchayats Minister, Haryana Member
5. Minister of State for Revenue, Haryana Member
6. Chief Secretary, Haryana Member and Chief Executive
Officer, Ex-officio
7. Financial Commissioner, Revenue and Member
Disaster Management, Haryana
8. Home Secretary, Haryana Member
9. Representative of National Disaster Management Authority Member
2. The Headquarter of the Haryana State Disaster Management Authority will be at Chandigarh.
3. The Haryana State Disaster Management Authority shall meet at least once in a year and as and when
required at such time and place as the Chairman of the Authority may think fit
4. The objectives, powers and functions of the Haryana State Disaster Management Authority shall be as
under :—
(L) Subject to the provisions of this Act, a State Authority shall have the responsibility for laying
down policies and plans for disaster management in the State.
(2) Without prejudice to the generality of provisions contained in sub-clause (I), the State Authority
may—

(a) Lay down the State Disaster Management Policy; ढ़

(b) approve the State Plan in accordance with the guidelines laid down by the National Disaster
Management Authority;

(c) approve the Disaster Management Plans prepared by the Departments of the Government of
Haryana;

(9) lay down guidelines to be followed by the Departments of the Government of Haryana for the
purposes of integration of measures for prevention and mitigation of disasters in their
development plans and projects and provide necessary technical assistance therefor;

(e) coordinate the implementation of the State Disaster Management Plan:

(f) recommend provision of funds for preparedness and mitigation measures for Disaster
Management;

<!-- page 5 -->

2
(g) review the development ptans prepared by the Departments of the Government at the district
Jevel, statutory authorities or local authorities with a view to make necessary provisions therein
for prevention of disaster or mitigation;
(h) review the measures being taken for mitigation, capacity building and preparedness by the
departments of the Government of Haryana and issue such guidelines as may be necessary
(3) The Chairperson of the Haryana State Disaster Management Authority shall, in the case of
emergency, have power to exercise all or any of the powers of the Authority but the exercise of
such powers shall be subject to ex-post-facto ratification by the Haryana State Disaster Management
Authority
DHARAM VIR,
Financial Commissioner and Principal Secretary to Government
Haryana, Revenue and Disaster Management Department.
43436—-C.S.-H.G.P,, Chd.

<!-- page 6 -->

{ Extract from Haryana Government Gazette (Extra.), dated the I9th May, 2008]
HARYANA GOVERNMENT :
REVENUE AND DISASTER MANAGEMENT DEPARTMENT
Notification
The I9th May, 2008
No. 653-ER-6-2008/5855.—In exercise of the powers conferred by Sub-section () of Section 20 of the Disaster
Management Act, 2005 (53 of 2005), the Governor of Haryana hereby constitutes the Haryana Stale Executive Committee
for the purpose of said section consisting of the following members, namely :—
\. Chief Secretary to Government, Ha-yana Chairperson, Ex-officio
2. Financial Commissioner and Principal Secretary to Government, Member Ex-officio
Haryana, Revenue and Disaster Management
a 3. Financial Commissioner and Principal Secretary to Government, Member Ex-officio
Haryana, Home Department
4. Financial Commissioner and Principal Secretary to Government, Member Ex-officio
Haryana, Finance Department
5. Financial Commissioner and Principal Secretary to Government, Member Ex-officio
Haryana, Health Department
The State Executive Committee shall have the responsibility for implementing the National Plan and State Plan
and act as the coordinating and monitoring body for the management of disaster in the State.
Power and Functions ;
The State Executive Committee shall have powers and perform all the functions mentioned in Sections 22 and
24 of the said Act.
K.S. BHORIA,
Financial Commissioner and Principal Secretary
५ to Government Haryana,
~ : Revenue and Disaster Management Department.
4425—C SH.GP., Chi.

<!-- page 7 -->

[Extract from Haryana Government Gazette, dated the 29th June. 200}
~~ HARYANA GOVERNMENT = ct
REVENUE AND DISASTER MANAGEMENT DEPARTMENT.
Notification
The l7th June, 20i0
“T° No. 284/ER-6-200/662.— The Governor of Haryana is pleased to constitute the State Steering
Committee (SSC) for implementing, monitoring and reviewing the Disaster ‘Response Reduction Project (2009-20!2)
in the State of Haryana comprising, of the following -—
. Financial Commissioner and Principal Secretary Chairman
to Government, Haryana, Revenue Department
2. Representative of National Project Director . Member
3. Representative of NDMA Member
4. Financial Commissioner and Principal Secretary Member
to Government, Haryana, Home Department
5. Financial Commissioner and Principal Secretary Member
to Government, Haryana, Town and Country Planning Department
6. Financial Comniissioner and Principal Secretary Member
to Government, Haryana, Finance Department
7. Financial Commissioner and Principal Secretary Member
to Government, Haryana, Irrigation Department
8. Financial Commissioner and Principal Secretary Member
to Government, Haryana, Urban Locai Bodies Department be
2 9.  Special/Joint Secretary to Government, Haryana, Member Secretary
Revenue and Disaster Management Department-i
2. Other Officers may be associated, as and when required as special invitees :
3. The functions of the SSC Commitiee will be as below.
l. Ensure that the project goals and objectives are achieved in the defined time frame.
2. Reveiew the project progress and suggest implementation strategies periodically.
3. Review the project expenditure against activities and outcomes.
4. Approve Annual and Quarterly work plans.
7 “NARESH GULATI, ee
Firanciai Commissioner and Principal Secretary to
Government, Haryana,
Revenue and Disaster Management Department.
47220—C.S.—H.G.P., Chd.
