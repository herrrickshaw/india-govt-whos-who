---
doc_id: "fa1a538eeaee769f"
source_url: "https://cdnbbsr.s3waas.gov.in/s386e78499eeb33fb9cac16b7555b50767/uploads/2022/11/2022110440.pdf"
ministry: "Finance Department, Haryana"
title: "Instruction for preparation of Budget Estimates for 2023-24 regarding (PDF, 7.9KB)"
date: ""
pages: 18
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "f735167a5a814866"
---

<!-- page 1 -->

vu
MOST IMMEDIATE/DATE BOUND
No: 2/5/2022-IB&C
from
Additional Chief Secretary to Government Haryana.
Finance Department
४ आई
He All the Heads of Departments. ‘
2s Commissioners of all Divisions in the Haryana State.
3. Deputy Commissioners in the Haryana State.
4... Registrar General, Punjab & Haryana High Court, Chandigarh.
Dated, Chandigarh, the 20" October, 2022.
Subject:- Instructions for preparation of Budget Estimates for 2023-24- regarding.
: ert
Sir, 2:
All the Departments are required to submit Budget proposals every year to the Finance
कु Department for the finalization of Budget Estimates for the next year. Though the comprehensive
instructions for preparing these Budget proposals are contained in Chapters 3, 4 and 5 of the Budget
Manual, yet some additional instructions are issued on the subject by the Finance Department every year. It
has been observed that some Departments do noi adhere to these instructions while framing Budget
Estimates leading to unwanted correspondence and delay. You are, therefore, requested to instruct the
concerned officials of your organization to keep these guidelines in view besides the provisions contained in
the Budget Manual particularly to the above stated provisions while preparing the Budget Estimates for the
year 2023-24.
22, The instruction/guidelines (placed at Annexure — A & B) seeking tentative budget proposals
- of Welfare & Development Schemes and Centrally Sponsored Schemes for Annual Budget Estimates 2023-
24 along with the formats (Statement I to Iii, placed at Annexure-B) is also requested to adhere while
preparing Budget Estimates.
3 Attention is particularly invited to the submission of modified B.M.2 form through online
basis by Departments through the User Id assigned to them for Budget on bamsharyana.nic.in portal
(enclosed as Annexure-l) which should contain the following information:-
Conid...2

<!-- page 2 -->

[2]
(a) Original estimates (B.E.) of the current year 2022-23.
(b) Actuals Accounts of year 2020-2] as per Finance Accounts of PAG (A&E).
(c) Actuals of year 202-22 for the last 6 months.
(0) Actuals of current year 2022-23 for the first 6 months,
(e) Revised Estimates of expenditure for the year 2022-23 proposed by Department.
(f) Budget Estimates for the year 2023-24 proposed by the Department.
(g) Remarks.
(3) It should be submitted online by the Departments after consolidation of entire Budget _
proposals by their DDOs.
INFORMATION MAY BE SENT ONLY IN THE ONLINE MODE. However Department may submit hard copy
to Finance Department only downloaded from the website bamsharyana.nic.in.
INFORMATION NOT IN THE ABOVE FORMAT IS LIABLE TO BE RETURNED.
B.M. FORM 30
4, Information in B.M. form 0, enclosed at Annexure-II regarding Pay, DA, Medical Allowances
ete., be supplied alongwith the Budget Estimates for the year 2023-24 to enable the Finance Department to
assess the normal increase on account of annual increment and also on account of specific items leading to कु
increase in contingencies. In the absence of such information, no increase would normally be provided for. ,
The information may be obtained from HRMS Portal.
POL ae
So: The number of vehicles (petrol/diesel driven) in existence and number of vehicles likely to be
condemned/replaced during the year 2023-24 should be indicated separately, while demanding the provision
for POL.
6. With regard to the preparation of Budget Estimates for year 2023-24 following clarifications are
hereby made for the benefit of all concerned:-
i) It is mandatory for the State Government to seek advice of the Office of Accountant General (A&E),
Haryana in the matter of opening of new Sub Heads (New Scheme). It is, therefore, reiterated that no
new Sub Head (scheme), will be included until it is approved by the Accountant General (A&E),
Haryana. Departments are advised to obtain prior approval of the Accountant General (A&E).
: through Finance Department, if any new scheme is to be added in the Budget Estimates 2023-24.
Comtd...3

<!-- page 3 -->

[3]

ii) No object head can be opened without the consent of Accountant General (A&E), Haryana. A list of
standardized object heads alongwith their code enclosed Annexure- IJ. Budget documents will be
ptepared according to these Object Heads with their standardized code numbering 0! to 98. All the
Departments are requested to restrict their budgetary proposals within these object heads without
insisting upon any other object head beyond this list.

iii) It has been observed that various Departments keep sending proposals for the purchase of motor
vehicles during the year without any budget provision for the purpose. All Head of Departments are
requested to make specific budget provisions under object head "motor vehicles" if they intend to

. purchase any new vehicle or replace old vehicles during year 2023-24, otherwise no proposal for the
purchase of vehicles will be entertained by the Finance Department. It is also clarified that all

3 expenditure relating to vehicles such as maintenance, repair, purchase, replacement etc. will be
included under the object head "motor vehicles".

iv) All expenditure on account of accommodation, transport/DA etc. of Ministers/Officers on travel
abroad should be sanctioned and drawn distinctly under the object head "foreign travel allowance". It
is, therefore, requested that distinct provision for this purpose be made, if required, in the budget
proposal for the year 2023-24 under object head "48-foreign travel allowances".

v) In view of the discontinuation of Plan and Non-Plan classification with effect from year 208-]9, the
Plan Scheme memorandum is rechristened as Explanatory Memorandum on Welfare and
Development schemes. So the Departments are required io send the proposals to Department of

- Economic & Statistical Analysis (DESA) online for such schemes in the Standard Format. Only
downloaded documents from website: bamsharyana.nic.in may be submitted to Finance Department.

: vi) It has been observed that the payments to the persons working on contract basis, daily wages and
even those providing professional services is being drawn by many Departments from the salary

head object code: 04 which is against the rules/instructions. As per Government Rules/instructions

salary of only those Government employees who are working in the regular time scales sanctioned

by the Government can be drawn from salary Head object code: 0 Payment to contractual
employees is to be made from the contractual services head object code:*69, payments to
professional person such as IT. professionals e.g. Data Entry Operator, Programmer etc. taken on

: contract bases is to be drawn from the object head of Professional and Special Services object code:

33. Further, the payment to daily wagers/part timers is to be made from wages head object code: 02.

' These instructions need to be complied with strictly while preparing Budget Estimates for year 2023-
24.

Further, it has already been decided by Finance Department that the diversion of funds should be a
rarity in future and once funds are diverted from one object head to another by pointing out savings,
the funds so diverted would not be accounted- for during the Revised Estimates year 2022-23
except in cxceptional circumstances.

Contd....4

<!-- page 4 -->

[4]

vii) The Accountant General (A&E), Haryana has brought to the notice of Finance Department time and again
that the expenditure under Minor Head “800- Other Expenditure” is more than 50% of the expenditure under
various Major Heads. AG Office has further desired that all such Major Heads should be reviewed and get the
budget sanctioned under suitable Minor Heads other than “800- Other Expenditure” to avoid excessive
booking under Minor Head “800”. Thus, the departments are advised that the matter regarding opening of
Sub-Heads under Minor Head “800- Other Expenditure” may be taken up firstly with the AG Office
personally and afier consultation of AG Office, the case may be sent to Finance Department so that
expenditure could be booked/accommodated in the relevant Minor Heads.

viii) Attention is also invited to Finance Department instructions bearing No.2/]/2008-5B&C dated 4h February, _
2008 wherein it was decided that schemes exclusively meant for SCSP Component should continue to be
reflected under specific Minor Head 789-Special Component Plan for Scheduled Castes for State Schemes or -
793-Special Central Assistance for Scheduled Castes Component for Central Schemes. Further the said
instructions be followed mutatis-mutandis in the Revised Estimates 2022-23 and Budget Estimates 2023-24 as
well,

ix) The Accountant General (A&E), Haryana has further brought tc the notice of Finance Department vide their
letter No. Appn./A/es/Scrutiny/Budget 20]7-8/40 dated 4/06/207 that accounting of “Grant-in-Aid”
given by the State Government needs to properly account for in future. The following minor heads may be
opened below the Major/Sub-Major Heads when necessary.

90- Assistance to Public Sector and other undertakings

9- Assistance to Municipal Corporation

92- Assistance to Municipalities/Municipal Councils i

93- Assistance to Nagar Panchayats/Notified Area Committees or equivalent thereof :
95- Assistance to Co-operatives

96- Assistance to Zilla Parishads/District level Panchayats “

97-Assistance to Block Panchayats/Intermediate level Panchayats

98- Assistance to Gram Panchayats

99- Assistance to Other Non-Government Institutions

ECONOMY IN EXPENDITURE/GUIDELINES i
ds Instructions issued from time to time regarding economy in expenditure must be kept in view. S
BUDGET CALENDAR
8. Budget Calendar for the preparation of Budget Estimates for the financial year 2023-24 is enclosed
(Annexure-V). It may please be noted that the Finance Department will not be able to entertain any
budget proposal received after the specified dates or that is not otherwise in accordance with
these instructions, in such cases the budget proposals would be finalized by the Finance Department
according to its own best judgment, Contd...5

<!-- page 5 -->

[5]
9. As per new procedure for release of funds under Centrally Sponsored (Shared) Schemes
Government of India has decided that funds will be released under Centrally Sponsored (Shared) Schemes.
only through PFMS portal, Single Nodal Agency (SNA) at Head Quarter and different Child
Agencies/Implementing Agencies at field level are being operated through Bank Account. In this
connection a separate budget schemes for Centre Share and State Share have already been created in
Budget 2022-23. However, if any reason separate budget line has not been created. same may be ercated in
budget 2023-24. It is, therefore, requested to open the new schemes in consultation with the office of
Accountant General (A&E), Haryana through Finance Department for smooth implementation of new

- procedure of release of funds under Centrally Sponsored (Shared) Schemes from 2023-24 onward under
PFMS.

४50, In certain CSS, State Governments are releasing funds in excess of the prescribed proportions as
“top-up”. It is therefore, requested to open the new State Schemes (Part-l) for top-up amount in
consultation with O/o Accountant General, (A&E), Haryana through Finance Department.

l]. These instructions can be downloaded from the Finance Department website www finhrygorin.
Yours Sincerely,
Eval
Under Secretary Finance (B)
for Additional Chief Secretary to Government Haryana.
Finance Department 4
No.2/5/2022-IB&C : Dated, Chandigarh, the 20" October, 2022
A copy, with a copy of its enclosures, is forwarded to the Principal Accountant General, (Audit) and

Accountant General, (Accounts & Entitlement), Haryana with the request that:- ५
i) He/She may kindly inform the Finance Department about the estimates of the Heads of Accounts with which

he/she is concerned by the dates indicated in the calendar and ;
ii) He/She may kindly ensure up-to-date reconciliation of expenditure with the departments to enable the latter

to frame their Revised Estimates 2022-23 realistically.

Benak
: Under Secretary Finance (B)
for Additional Chief Secretary to Government Haryana,
Finance Department,

A copy, with enclosures, is forwarded to all the Additional Chief Secretaries / Principal Secretaries to

Government Haryana, for information.
Contd....6

<!-- page 6 -->

[6]
De They may kindly ensure that the Departments under their Administrative control will
submit the budget proposals by the dates prescribed in the schedule at Annexure-V.
वेट ९0५
Under Se€refary Finafice (B)
Jor Additional Chief Secretary to Government Haryana,
Finance Department d
To ?
All the Additional Chief Secretaries /Principal Secretaries ५
to Government, Haryana.
U.O, No.2/5/2022-IB&C Dated, Chandigarh, the 20" October, 2022.

A copy, alongwith copies of enclosures, is forwarded to all Secretary Finance-cum- Advisor/ Secretary,
Finance/ Special Secretary, Finance/Senior Economic Advisor/ Joint Secretary/ Deputy Secretaries/ Under
Secretaries) DD ERAMU/Advisor Finance & Planning/ Superintendents of the Finance Department (Budget
Control Branches) for information and necessary action.

2 It is requested that the dates prescribed in the Schedule should be adhered to Cases of default should be
brought to the notice of the concerned Administrative Secretary by the Branch Officer concerned. It is also
requested that all the printable budget material should be signed by the concerned Assistant, Superintendent, Under
Secretary, Deputy Secretary and Special Secretary/Additional Secretary Finance to ensure the correctness of not के
only language in Hindi and English both but the facts, figures and other material also.
’ 220०0 ;
Under Secretary Finance (B)
for Additional Chief Secretary to Government Haryana,
Finance Department of

To

All the Secretary Finance-cum- Advisor/ Secretary/ Special Secretary/Senior Economic Advisor/

Joint Secretary/ Deputy Secretaries/ Under Secretaries’ DD ERAMU/Advisor Finance & Planning/ -

Superintendents of the Finance Department (Budget Control Branches).
U.O, No.2/5/202-IB&C Dated, Chandigarh, the 20" October, 2022.
Internal Distribution
PS/CM
PS/ACSF Contd...7

४

<!-- page 7 -->

[7]
Annexure-A
insiructions/Guidelines for preparation of Annual Budget Estimates 2023-24
Welfare and Development Schemes

Ie ‘The scheme-wise budget proposals for 2023-24 should be realistic and formulated on the basis of
actual expenditure of previous years keeping in view the tentative minimum requirement of the
Department.

De The Capital and Revenue classification of each scheme may be worked out separately.

पा 3. Provision of State Share should be kept under the Centrally Sponsored Schemes to match the
corresponding Central Share. Government of India has changed the funding pattern in some of the

% schemes while some schemes may have been discontinued. Accordingly, the provision of State Share
as well as Centre Share is kept afier confirmation of the concerned Ministry of the Government of
India.

4, Sufficient funds should be kept for ongoing works in existing schemes so that these can be completed
without problem.

a Funds should be kept for the committed liability of the Department under existing schemes.

6. All ongoing Schemes should be reviewed and the schemes which have outlived their utility must be
closed down and the existing staff created under the scheme, if any, be transferred to other schemes.

Ds Restructuring of existing schemes should be done. For instance, Department may like to discontinue
or merge the schemes having annual outlay of Rs. 5.00 crore or less. This would enable the

हैः Department to rationalize its existing schemes to achieve optimum results within the given resources.
4 8. Schemes with similar objectives should be clubbed together to avoid overlapping.

oF No new State scheme be formulated if similar objectives are covered under any Centrally Sponsored

Scheme. ‘
:

]0. Efforts be made to formulate new schemes by augmenting resources from NABARD, NCRPB or
EAP etc.

Jl. The Department may explore the possibility of using all Centrally Sponsored Schemes which
are presently not being implemented in Haryana but are being implemented successfully in
other States.

i 2: Possibilities of new projects under Public Private Partnership (PPP) may be explored to invite private
entrepreneurship and capital into areas being regulated by the Department.
For SCSP Component

3, The funds earmarked under SCSP should be allocated only for those schemes (both Centre and State
Share) which ensure direct benefit to Scheduled Castes population. The funds earmarked under SCSP
will be non-divertible. Non-utilization of funds under SCSP will lead to proportionate cut in the
outlay of the Department. The departments are requested to follow the guidelines issued by erstwhile
Planning Commission now NITI Aayog (SJ& E Division) as under while formulating SCSP
schemes;- Contd..,.8

<!-- page 8 -->

[8]
i. Schemes which are exclusively benefiting Scheduled Caste individuals or Scheduled Caste
households, 00% of Scheme cost shall be allocated and accounted for under Scheduled
Castes Sub-Plan fund; i

ii. For Schemes benefitting Scheduled Caste habitations, 00% of Scheme cost shal] be
allocated and accounted for under the Scheduled Castes Sub-Plan fund.

iii. In case of other habitations the cost shall be allocated and accounted for under Scheduled

: Castes Sub-Plan in proportion of the population of the Scheduled Castes;

iv. For general Schemes, included in the Sub-Plan, benefitting Scheduled Castes individuals or
Scheduled Caste households, along with others, the Scheme cost shall be allocated and
accounted for under the Scheduled Castes Sub-Plan, in proportion to the Scheduled Caste
beneficiaries actually covered; :

vy. In respect of non-divisible infrastructure works a portion of the Scheme cost, as may be
determined by the State Government, will be deemed to have been attributed for Scheduled
Castes Sub-Plan. This fraction cannot, however, exceed one-third of the percentage of SC
population in the state.

For Women Component

]4, Information of Women Component (wherever applicable) out of the schemes implemented by the

department may be furnished as per annexed proforma.
For Urban & Rural Component

5. Urban & Rural Component of each scheme is also to be furnished as per the annexed proforma. The
area which is under the Municipal limit is considered as Urban Area.

Contd.,..9
‘

<!-- page 9 -->

[9]
Annexure-B
Name of the Department
A. Write Up
!. Goals of the Depariment
2. Strategies of the Department
3. Key Expected Outcomes of the Department
B. STATEMENT (Welfare & Developmental Schemes including CSS)
J. State Schemes (Part-I)
(Rs. in Jakh)
. [Name of Financial Year 2022-2023 Financial Year 2023-24
» Scheme [Annual Budget Physical Achieverment Proposed Budget Physical Targets
ith Code
| Sp Til Anticipated indicators Wargets Pachieve- [Budgeted JOfwhich [Ofwhich [Urban & Rural CompSDG Goal indicators
date Ee (in Units) nent %  |Estimates BCSP Women /% Urban |% Rural |No(only (in Units)
Estimates Targets (Tentative) [Compo-  ompo- ‘or Develop
(Tentative) pent ent Ment
Scheme
fincl. (CSS)
ae | cea] 5 | el TURES ema om re] me get vec $e) Z| A Me AA eee WG]
2. Centrally Sponsored Schemes (CSS) (Sharing Basis) (Part-H)
(Rs. in lakh)
same of Financial Year 2022-23 Financial Vear 2023-24
cheme | Annual Budget Physical Achievement Proposed Budget
vith Code
5 Outlay Pap. TH Anticipated indicators [rargets Achieve Budgeted [Ofwhich [fwhich [Urban & Rural [DG Goal No, fndicators Targets
date evised (in Unit) ent % |Estimates SCSP  \Yomen (Component {only for (in Unit)
Estimates ‘argets (Tentative) Componentrompo- evelopment
Ea (Tentative) Ee 'S SS pent x % [Schemes Incl.
iV BENS __¢}Urban {Rural 85) 5 ns
a a ee ee eee
}, Centrally Sponsored Schemes (CSS) (00%) (Part-IIl) (Rs. in lakh)
. Name of Financial Year 2022-23 Financial Year 2023-24
».Scheme with Annual Physical Achievement Proposed Budget Physical Targets
Code Budget
| 022-23
(Outlaylexp, [Anticipated | Indicators [Targets Achieve. Budgeted [OT which Pi which G Gon! fndicators  rargets
hs Revised {in Units) ent % [Estimates |SCSP | Women P% Urban [% Rural No (only for | (in Units)
jute [Estimates ‘arget {Tentative) Compo- bompo- evelopment
(Tentative) ent yent Bchemes |
incl. CSS)
[ess cae eee ee een [eras [eee छ पा (panies [238.5 a नल
Contd...0

<!-- page 10 -->

(ण
‘iM SO al Pee a. व जम RI 27 इन मा तट न नसन
eo ee ee
Form BM-2
Major HEAD Revised Estimate |Budget Estimate
2022-23 [2023-24
JSUBMAJOR HEAD Budget | Accounts |Aculals of provious |Acutals of current |Proposed by Head |Proposud by Head
IMINOR HEAD 2022-238 2020-2 |yearz027-22for —_|yoar 2022-23 jof Dept. lof Doptt,
JSTANDARO OBJECT last 6 months Hor first 6 months
JOF EXPENDITURE
iment eee ee गत
हि (oa ees cee पा न आय eT
ee eee aioe Oat कक जा जा |
ere ake eee
कप |
ic nag Pea | ere | |
डा पा [eee |
ees casera ceo | sr Tn ca ei eo
i lothers (pt Spocity as
selected form-Annexure-
IVI according to the
are ae ent amma oe
|Nole: In the case of lrrigstion Branch 5+6 months éclua!s need nol be supplied for any head except Contd 44
"Mainlenance and Rapairs” and “establisment”
:
*
