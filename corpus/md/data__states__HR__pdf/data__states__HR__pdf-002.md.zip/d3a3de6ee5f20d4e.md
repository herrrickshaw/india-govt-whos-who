---
doc_id: "d3a3de6ee5f20d4e"
source_url: "https://homeharyana.gov.in/pdfs/LatestUpdates/Gazette_12-2025_22453.pdf"
ministry: "Home & Administration of Justice Department, Haryana"
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ab0b5367723e69f0"
---

<!-- page 1 -->

Haryana Government Gazette
Published by Authority
© Government of Haryana
No. 12–2025]
CHANDIGARH, TUESDAY, MARCH 25, 2025 (CHAITRA 4, 1947 SAKA)

PART-I
Notifications, Orders and Declarations by Haryana Government
gfj;k.kk ljdkj
x`g foHkkx
vf/klwpuk
fnukad 12 ekpZ] 2025
la[;k 7@9@2024&1ts-ts-&1.— Hkkjrh; ukxfjd lqj{kk lafgrk] 2023 ¼dsUnzh; vf/kfu;e] 2023 dk 46½ dh /kkjk 20
dh mi /kkjk 3 ds rgr iznRr 'kfDr;ksa dk iz;ksx djrs gq,] gfj;k.kk ds jkT;iky vfHk;kstu funs’kky; dk iz’kkldh;
fu;U=.k U;k; iz’kklu foHkkx ls x`g foHkkx] gfj;k.kk esa LFkkukUrfjr djus dh vf/klwpuk tkjh djrs gSaA
MkWå lqferk feJk]
vij eq[; lfpo] gfj;k.kk ljdkj]
x`g foHkkxA
HARYANA GOVERNMENT
HOME DEPARTMENT
Notification
The 12th March, 2025
No. 7/9/2024-1JJ(1).— In exercise of power conferred under Sub-Section 3 of Section 20 of Bharatiya
Nagarik Suraksha Sanhita, 2023 (Central Act, 46 of 2023), the Governor of Haryana hereby notifies to shift the
administrative control of Directorate of Prosecution, (Prosecution Department) from the Administration of Justice
Department to Home Department, Haryana.

DR. SUMITA MISRA,
Additional Chief Secretary to Government Haryana,
Home Department.
11669—C.S.—H.G.P., Pkl.

(172)
