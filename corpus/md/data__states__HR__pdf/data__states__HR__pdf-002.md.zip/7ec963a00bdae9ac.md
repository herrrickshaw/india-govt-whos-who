---
doc_id: "7ec963a00bdae9ac"
source_url: "https://cdn.s3waas.gov.in/s315d4e891d784977cacbfcbb00c48f133/uploads/2026/06/17803909331567.pdf"
ministry: "Ambala"
title: "Publication of Short Term Tender Notice for purchase of T-Shirt for International Yoga Day- 2026"
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e14597b03a533c06"
---

<!-- page 1 -->

DistrictAyurvedicOffice,Ambala
Old Civil Hospital Ambala City
Email:-daoambala@gmail.com,PhoneNo-9416323981, 8396998900

Letterno/.“DAO/AMB/IYD/2026/ 18250

Dated:- 29-5-2026

ShortTermTenderNotice
District Ayurdedic Officer, Ambala inviting sealedtenders for the Purchase
of4000T-Shirts (Quantity may change upto 40% on higher side and
upto50% on lower side) of GSM of 110 & 38,40,42& 44 size with logo of
Haryana Govt. andInternational Yoga Day to be supplied on or before 1406-2026 (12PM). The sample of T-Shirt will be shown on the date of
opening of tender.TheTender fee is Rs. 1000/-and the Earnest Money Deposit
is Rs.5000/-.in favourof DisttrictAyurvedic Officer Ambala. Detailed DNIT can

be obtained fromo/o Distt. Ayurvedic Office Ambala by hand/ by Email or can
be
downloadedfrom
website
of
Distt.AdministrationAmbala(ambala.gov.in.).Under signed maybecontactedfor
anyinformation orchange.
TenderID
Last Date and time of Bid
Submission by registered postor By
Hand
TenderOpeningDate.

Place of opening of tender

“DAO/AMB/IYD/2026/18250
8.06.2024 upto (12:00PM).in office of District
Ayurvedic Office, Old Civil Hospital Ambala
City.
Technical bid on 8.06.2024(12:00PM) Financial
Bid on 8-06-2024(01:00PM)
O/oCEO, Zila Prishad,1st floor ADC Office
Ambala City

-SD-

DistrictAyurvedicOfficer
Ambala

<!-- page 2 -->

TERMS,CONDITIONSANDGENERALINSTRUCTIONSTOTHETENDERER(TenderNo.
“DAO/AMB/IYD/2026/18250”)
The bidders are expected to read carefully all the terms and conditions of the tender documents and their
submission will be taken as consent to abide
1.

2.

3.

The tender is “Two Bid’ document. The technical bid should contain all the relevant information and
desired enclosures in the prescribed format along with Earnest Money Deposit (EMD). The financial
bid should contain only Price bid document. In case, any bidder encloses the financial bid within
technical bid,the same shall be rejected summarily.
The tender form and other terms and conditions may be collected from the Office of District Ayurvedic
Officer Ambala by hand/by Emailor can be downloaded from website of Distt. Administration
(ambala.gov.in.). The bid must accompany with the earnest money deposit fee of Rs. 5000/(Fivethousand ) in the form of demand draft of any scheduled bank drawn in favor of District
Ayurvedic Officer Ambala payable at Ambala.
The Tenders should be typewritten or handwritten but there should not be any overwriting or
cutting.Correction, if any,shall be made by neatly crossing out, initialing, dating and rewriting. The
nameand signature of bidder’s authorized person should appear on each page of the application.
All pages of the tender documents shall be numbered and submitted as a package along with
forwarding letter on Firm’s letter head.

The Contracts concluded as a result of this Tender Inquiry shall be governed by the‘Terms &
Conditions’and other relevant instructions as contained in thisTender Document.
5. The prices/rates quoted should be indicated in words as well as in figures. In case of any discrepancy,
lower amount/rates shall beconsidered as valid.
6. Biddersare requested to quote their prices on a firm & fixed basis for the entire period
of the Contract. Bid soft the firms received with prices quoted on variable as is shall be rejected without
assigning any reasons and no communication in this regard shall be entertained.
7. Quotations qualified by such vague and indefinite expressions such as “subject to prior
confirmation”,“subject to immediate acceptance” etc. will be treated as vague offers and rejected
accordingly. Any conditional tender shall be rejected summarily.
8. Bidders are requested to enclose a copy of their valid certificate of PAN No., TAN No, Sale
Tax/GSTNo. Or anyother document as requested by the Office with their tender.
4.

Tenders received without EMD amount by way of demand draft in favor of District Ayurvedic
Officer, Ambala atwill notbeconsideredatallandshallbesummarilyrejected.
9.

Refund of Earnest Money Deposit: The EMD submitted by unsuccessful bidders shall be returned
tothem without any interest whatsoever, within60 days after conclusion of the contract with
successfulbidder. The EMD submitted by successful bidders shall be returned to them after conclusion
of the contract with successful bidder according to conditions stipulated in the bid document.
10. Bidders may note that if the date of tender opening given in this Tender Document is declared to be a
gazetted holiday, the tender shall be opened on the next working day at the same timing. In such an
event the closing hours for receipt of tenders in the Officeof District Ayurvedic Officer Ambala will
stand automatically extended upto12.00A.M.of the next working day in the Government offices.
11. Late/delayed tenders received in the Office of District Ayurvedic Officer, Ambala due to any reason
what so ever will not be accepted under any circumstances.

<!-- page 3 -->

12. Any laps in service or material supply by firm (as prescribed in tender notice) then 15-20% of penalty
on total amount may be imposed or decided by expenditure committee and earnest money will also be
forfeit.
13. At any time prior to date of submission of tender, Tender Inviting Authority may, for any reason,
ordecision, modify the terms & conditions of the tender document by a corrigendum displayed at the
Office of District Ayurvedic Officer,Ambala. In order to provide reasonable time to take the
amendment into account in preparing their bid, Tender Inviting Authority may or may not, at his
discretion, extend the date and time for submission of tenders.
14. Tendering firms are at liberty to be present or authorize a representative ob represent at the opening of
the tender at the time and date as specified in the Schedule. The name andaddress of the
representative authorized to attend the opening of the tender on behalfof a tendering firm should
be indicated in the tender. The representative so deputed should also bring with him aletter of
authority from the firm for having been authorized to be present at the time of opening of
tender. Only one representative per firm shall be permitted to attend the opening of the
tender.The name and address of permanent representative of the firm, if any, should also be indicated
in thetender.
15. The bidders having experience in similar field may be given preference.
16. DOCUMENTSCOMPRISINGTHEBID:
The bids prepared by the bidder shall comprise of (1)The Technical Bid and (2) Financial Bid:
TECHNICALBID:-To qualify in theTechnical bid the firms should have the minimum eligibility Criteria
as under and the firm in this regard must submitthe documents in support of their eligibility criteria and
theTender is liable to be rejected if the following documents are not received therewith:
(a) Duly filled format of Technical Bid as per Annexure“1”.
(b) TheTechnical bid should be accompanied by Demand Draft/BankGuarantee of Rs.5000/-(refundable)
for EMD/bid security.
(c) Attested copy of Name of the Agency/Firm/Proprietary concern registered & address along with
registration no.(if any)
(d) Attested Copy of PAN Card
(e) Attested copy of GST No.as applicable
(f)

The fee for tender documents will be Rs.1,000/- (Rupees One Thousand Only). This fee shall be paid
in the form of Demand Draft issued by a nationalized/scheduled bank, drawn in favour of “ District

Ayurvedic Officer, Ambala payable at Ambala. This fee is non-refundable. The tender fee draf
tshould be enclosed in separate cover superscripted “Tenderfee”.
FINANCIAL BID:- The financial bid shall contain:
16.

(a) Price Bid Form asper Annexure–2
SUBMISSION OF BIDS

16.1 SEALING AND MARKING OF BIDS:
All the relevant documents, D.D. of earnest money deposit along with tender document should be
placed in sealed envelope superscribedas Tende No. “DAO/AMB/IYD/2026/18250”. The bidder

<!-- page 4 -->

shall seal the EMD along with the Technical Bid and the Financial Bid in separate envelopes and
keep them in a bigger properly sealed envelope. The envelope containing the EMD along with
Technical Bid shall bear the name “TECHNICAL BID for Tender No. “DAO/AMB/IYD
/2026/18250” The envelope containing the Financial Bid shall bear the name “FINANCIAL BID
for Tender No.Tender No.“DAO/AMB/IYD/2026/18250” on the envelope for avoiding any
mismatch.
16.2 The sealed envelope shall be addressed as under:
(a)

Addressed at the following address:
District Ayurvedic Officer, Ambala
Old Civil Hospital Ambala City
The envelope shall bes uperscribed as “TENDER NO..“DAO/AMB/IYD/2026/18250” and the
words ‘DO NOT OPEN BEFORE’ (due date & time).

(b)
(c)

The envelopes shall indicate the name and address of the bidders to enable the bid to be returned
unopened in case it is declared ‘late’ or rejected.
Bids shall be delivered in person in the office of “ DistrictAyurvedic Officer, Ambala”or shall
be sent by Registered/SpeedPost. Bids sent by COURIER will not be entertained.The
Purchaser shall not be responsible if thebidsaredeliveredelsewhere.
(d) Venue of Tender Opening: Tender will be opened in the office of“O/o CEO,

Zila Prishad 1st floor ADC Office Ambala City Technical bid on 8.6.2026
(12:00PM) and Financial Bid on 8-06-2026 (01:00PM) on the same date. If due to
administrative reason, the venue/time of bid opening is changed, it will be displayed prominently
on the notice board of the District administration website (ambala.gov.in.)

17.
17.1

BID PRICES:
The offer shall be in the form of Indian Rupees only.No foreign exchange will be made available by
the office.

17.2

The prices quoted by the bidder shall remain fixed during the entire period of contract and shall not
be subject to variation on any account. Abid submitted with an adjustable price quotation will to be
treated as non-responsive and rejected.

18.
18.1

TECHNICALEVALUATION:
Detailed technical evaluation shall be carried out by Technical Evaluation Committee pursuant to
conditions in the tender document to determine the substantial responsiveness of each tender. For this
clause, the substantially responsive bid is one that conforms to all the eligibility and terms and
condition of the tender without any material deviation. The Office’s determination of bid's
responsiveness is to be based on the contents of the bid itself without recourse to extrinsic
evidence.The Office shall evaluate the technical bids also to determine whether they are complete,
whetherrequired sureties have been furnished, whether the documents have been properly signed and
whetherthebidsareinorder.

18.2 The committee may call the responsive bidders for discussion or Negotiation to facilitate and
assesstheirunderstandingof thescopeofworkanditsexecution.
18.3 Financial bids of only those bidders who qualify the technical criteria will be opened, provided
allotherrequirementsarefulfilled.

<!-- page 5 -->

18.4 Abiddeterminedassubstantiallynonresponsivewillberejectedbytheofficeandshallnotsubsequenttothebidopeningbemaderesponsiveby
thebidderby correctionofthenonconformity.
18.5 Thepurchase committeehaverighttoacceptorrejectanyoralltenderswithoutassigninganyreasonsthereof.
19.
19.1

FINANCIALEVALUATION:
The financial bid shall be opened and evaluated of only those bidders who have been found to
betechnically eligible. The financial bids shall be opened in presence of representatives of
technicallyeligible bidders, who may like to be present. The Office shall inform the date, place and
time foropeningoffinancialbid.

19.2

The Financial Bids of unsuccessful bidders would not be opened.

19.3

Agency shall define his Rate per unit inclusive of all taxes and other costs while quoting for the
tender, in“Annexure-2: Price Offer” to be kept in Envelop No. 2.Income Tax willbe deducted at
source from the bills as applicable. TheAgency needs to furnish its PAN number.

19.4

Arithmetical errors shall be rectified on the following basis.
If thereis a discrepancy between the unit price and totalprice that is, the unit price shall prevailand
the total price shall be corrected by the Office. If there is a discrepancy between words andfigures,
the lesser amount shall be considered as valid. If the Supplier does not accept the correction of the
errors, his bid shall be rejected.

19.5

The evaluation and comparison of responsive bids shall be done on the basis of rate per unit offered
by the bidder as indicated in the Price Schedule in Annexure-“2” of the Bid Document.

19.6

The purchase committee is not bound to accept the lowest bid or any bid and reserves the right
ofaccepting the whole or any part of the bid or portion of the job offered; and the bidder shall
providethe same at the rates quoted. Purchase committee reserves the right to reject any or all
offersreceived in response to tender or cancel or withdraw the tender notice without assigning any
reason,whatsoever.

20.

AWARDOFCONTRACT:PLACEMENTOFORDER
The purchase committee shall consider placement of orders for goods on those bidders whose
offers have been found technically and financially acceptable. The Office reserves the right to
counter offer price(s) against price(s) quoted by any bidder.
Distt.AyurvedicOfficer

Ambala
I/We submit this tender after reading the tender notice, instruction of terms and
conditions contained here in and accepted by me/us.
Dated:-Signature of the bidder

(withseal)
Address:

Mob.no.

<!-- page 6 -->

ANNEXURE-1

OFFICEOFDISTRCITAYURVEDICOFFICER,Ambala
TECHNICALBIDforpurchaseofTShirtTenderNo.“DAO/AMB/IYD/2026/18250”
Sr.No.

Content

1

Cost of Tender Form (Rs.1000/-) Non-refundable

Page
No.
Name of Bank……………….
D.D.No………………Dated…………….

2

Due date for Tender

3

Opening date and time of tender

4

Name of the Agency/Firm/Proprietary concern
registered & address

5

Telephone number of Authorized Person with email

8

Registration number of the firm/Agency(Ifany)

9

PANCardofAgency(Attachattestedcopy)

15

Detail so Earnest Money
a)AmountRs.
b)D.D.No.

8.06.2026upto12PM
Technical bid on 8.06.2026(12:00PM)
Financial Bid on 8-6-2026(01:00PM)

c)In favour of
d)Date of Issue
e)Name of Issuing Bank
23
24

GSTNo.
(AttachCertifiedCopy)
AnyOtherInformation

25

Declaration by the bidder

This is to certify that I/We before
signingthis tender have read and fully under
stood all the terms and co nditions
contained herein and undertake myself
/ourselves toabidebythem.
Enclosed-----Page with numbers withselfattested copies of documents.

<!-- page 7 -->

26

Signature of the bidder, Name, Designation,
address ( with seal ) and email address with
contactno.
ForOfficialUse

27

DairyNo. With date of tender
8.06.2026upto12PM

28

Signature Committee Members

1.

Accountofficer o/o CEO ZilaPrishad

2.

Distt Ayurvedic officer

3.

CEO,ZilaPrishad Ambala.

.

receipt upto

<!-- page 8 -->

Annexure-2
FINANCIALBIDFORPURCHASEOFTSHIRTS
To
TheDistt.Ayurvedic Officer,Ambala
RespectedMadam/Sir,
1. I/We....................................................................................................... submitted the bid forTender
No.:.“DAO/AMB/IYD/2026/18250”dated: 29-5-2026 .for Purchase of TShirts for International
Yoga day with Logo and with sample.
2. I / We thoroughly examined and understood instructions to tenders, scope of work, term and
conditions of contract given in the tender document and those contained appendix of Term &
condition of contract and agree to abide by them.
3. I / We hereby offer to provide T Shirts for IYD 2026 with logo at the following rates. I /
Weunderstand that I /We are not entitled to claim any enhancement of rates on any account
during the tenure of the contract.
Sr.No.
1

Discription
Supply of TShirts fo rInternational YogaDay2026

Quantity
As perTender
Notice

Add:StatutoryObligationsifany(PleaseSpecifyEachonthebasisofgroups)
Rate per unit@

inclu of GST

Signature of Authorized Person:
Name & Designation:
Name of Firm/Company/pAgency:
ContactDetails:

<!-- page 9 -->
