---
doc_id: "6f6ce8c4d0fdf29b"
source_url: "https://highereduhry.ac.in/Notices/Notice202609251712538941.pdf"
ministry: "Higher Education Department, Haryana"
title: "Guidelines for CM Budget Announcement 35(xxiii) 2026-27 Creditization for NCC, NSS,Sports & Yogasan, Cultural Activities, Youth Red Cross, Incubation and Outreach Activities under the NEP-aligned Undergraduate / Post-Graduate Framework."
date: ""
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f4dfc3cb1c7354ce"
---

<!-- page 1 -->

,l

From

Additional Chief Secretary to Government of Haryana,
Higher Education Department, Chandigarh
To

1. The Vice Chancellors,

i:

I
I

I
l

2.

i

All State Universities under the ambit of Higher Education Department.

. The Principals
All Govt./Govt. Aided Colleges/ Self financed/private Coileges situated

'. in the State of Haryana,

I
I
I
I
i
I

Memo No: 18188-2026-UNp (3)
Dated, Panchkula,
o1- ?-.oL6

I

I
t

the Z{-

l
I
I

I
I
I

Guidelines for cM Budget Announcement 3S(xxii i) 2026-27
creditization for NCC, NSS, Sports & yogasan, cultural

Subject:

i

Activities, Youth Red Cross, Incubation and' Outreach
Activities under the NEp-aligned Undergraduate / postGraduate Framework

* ?k r<* rrrr*

Kindly refer to the subject cited above.

It is intimated that to promote the holistic development of students , the State
Government has introduced a schdme namely "Creditization for NCC, NSS, Sports

&

Yogasan, Cultural Activities, Youth Red Cross, Incubation uld Outreach

Activities under the NEP-aligned Undergraduate /

Post-Graduate

Framework"

.A

copy of the guidelines regarding the scheme is hereby enclosed for

necessary action. These issues with the concurence of the competent authority.

S
-TINP
Additional
Chief
Secretary to.Govt. of.Haryana,
for
Higher Education Departmenl, Chandigarh

Endst..No. Even
Dated, panchkutaJthe
A copy of the above is forwarded to the foll owing for information and ne.essaly
action:-

)) lq lZf

1. The Director General Technical Education Haryana, Panchkula with the request
to circulate these Guidelines among their HEIs
2. PS/OSD/CM for information of OSD/CM.
3. PS/HEM for information of HEM.
4. PS/chairperson, HSHEC for information and taking necessary action
5. PS/ACSHE for information of WACSHE
6. PS/DGHE for informarion of WDGFIE.
8. AD-IT for uploading the notification on the Higher Education portal.
!yq.{n:ndent Admn., college-1, c-II, NCCAISS,college-It Branch, Library,
M.E. & Cordination at H.Q.

9.

sup.SIF.nII-rrNp
for Additional Chief Secretary to Govt. of Haryana,
Higher Education Department, Chandigarfl

<!-- page 2 -->

SCHEME / GUIDELINES
Integration of Non-Formal & Informal Learning Credits in UG and PG
Programmes
Creditization for NCC, NSS, Sports & Yogasan, Cultural Activities, Youth Red Cross,
Incubation and Outreach Activities under the NEP-aligned Undergraduate / Post-Graduate
Framework
Budget Announcement Reference: Hon’ble CM Budget 2026-27 Announcement Para 35
(xxiii)- ‘In 2026-27, I propose to integrate NCC/NSS/Sports & Yogasan into the Academic
Credit Bank. This initiative will benefit all 25,000 NCC and 70,000 NSS students.’

1. Preamble
In accordance with the National Education Policy (NEP) 2020 and the University Grants
Commission (UGC) guidelines for a Holistic and Multidisciplinary Education, the Government of
Haryana hereby formalizes the creditization of non-formal and informal learning for students
enrolled in Undergraduate (UG) and Post-Graduate (PG) programmes across all Higher
Education Institutions (HEIs) in the State of Haryana.
The National Credit Framework (NCrF) explicitly mandates the integration of “Life Skills” to
ensure students are job-ready and socially responsible. This initiative aims to recognize
experiential learning, community service, and entrepreneurship as integral components of the
degree programme, thereby giving due academic credit to the holistic development of students
beyond the classroom.

2. Vision
To build well-rounded, socially conscious, and employable graduates by formally recognizing the
skills, values, and competencies acquired through co-curricular, community service, and
experiential learning activities — embedding them within the academic credit architecture of
Higher Education in Haryana.

3. Objectives
•
•
•
•
•

To promote the holistic development of students.
To formally integrate NCC, NSS, Sports & Yogasan, Cultural Activities, Youth Red Cross,
Incubation (Startup development), and Outreach activities into the credit framework of
UG and PG programmes.
To enable students to earn academic credits for verified participation and achievement in
non-formal and informal learning activities.
To align the credit structure of Haryana’s HEIs with the National Credit Framework (NCrF)
and the Academic Bank of Credits (ABC) system of the Government of India.
To provide a transparent, standardized, and outcome-based assessment and grading
mechanism for co-curricular activities.

<!-- page 3 -->

•
•

To promote discipline, leadership, community service, entrepreneurship, and national
integration among students.
To ensure that credit earned through these activities is properly recorded in the
Academic Bank of Credits (ABC) portal for seamless academic mobility.

4. Applicability
These Guidelines shall apply to all Higher Education Institutions (HEIs) in the State of Haryana,
including:
•
•
•

All State Universities
All Government and Government-Aided Colleges affiliated to State Universities
All Self-financed/Private Colleges operating in Haryana

These guidelines shall be applicable to all students enrolled in:
•
•

3-year and 4-year Undergraduate (UG) programmes
1-year and 2-year Post-Graduate (PG) programmes

5. Definitions
5.1 Non-Formal Learning: Non-formal learning refers to structured, guided, and experiential
learning activities conducted on campus or off campus (in a recognized system) outside the
formal academic curriculum.
5.2 Informal Learning: Informal learning refers to self-directed learning undertaken by students
independently, often through off-campus environments and resources.
5.3 Academic Bank of Credits (ABC): A digital infrastructure established by the Government
of India under NEP 2020 that allows students to store, accumulate, and transfer credits earned
from recognized HEIs.
5.4 National Credit Framework (NCrF): A framework developed by the Government of India to
integrate academic, vocational, and skill education under a common credit system across all
levels of education.

6. Scheme Details
Integration of non-formal learning Credits in UG and PG Programmes — Creditization for NCC,
NSS, Sports & Yogasan, Cultural Activities, Youth Red Cross, Incubation and Outreach
Activities under the NEP-aligned Undergraduate/Post-Graduate Framework.
In accordance with the National Education Policy (NEP) 2020 and the University Grants
Commission (UGC) guidelines for a Holistic and Multidisciplinary Education, the formalization of
creditization of non-formal learning recognizes experiential learning, community service, and
entrepreneurship as integral components of the Undergraduate and post-graduate degree. The

<!-- page 4 -->

National Credit Framework (NCrF) explicitly mandates the integration of “Life Skills” to ensure
students are job-ready and socially responsible.

6.1 Scope
This will include —
1.Credit Recognition: Activities such as NCC, NSS, Sports & Yogasan, Cultural Activities),
Youth Red Cross, Incubation (Startup development) and outreach activities shall be recognized
as credit-earning courses.
2.Category Mapping: These activities shall be categorized by the University under the
concerned course as per UGC norms.
3.Credit Quantization: A maximum of 6 credits may be earned through these activities over the
3 or 4-year UG program and 4 credits for a 2 year PG programme. One credit shall be
equivalent to 30 hours of verified field work, practice, or participation.
4.Assessment & Grading: An Assessment Committee constituted by the university shall verify
certificates and outcomes. Evaluation shall follow a Grade-based system (O, A+, A, B, etc.) and
will be uploaded to the Academic Bank of Credits (ABC) portal. Controller of Examinations of
each university will make provisions to allow for the entry of co-curricular grades.
5.Non-Formal and Informal Learning: Non-formal learning refers to structured, guided, and
experiential learning activities conducted on campus/off campus (in a recognized system)
outside the formal academic curriculum. Informal learning refers to self-directed learning
undertaken by students independently, often through off-campus environments and resources.

6.2 Proposed Credit Table for Non-Formal and Informal Learning
Activity

Maximum Credits

Verification Authority

Non-formal Learning
NCC

6 (2 credits per
year)

Associate NCC Officer (ANO) / ‘C’ Certificate

NSS

4 (2 credits per
year)

NSS Programme Officer/Coordinator / Camp
Certificate of the institution

Sports & Yogasan

6 (2 credits per
year)

Director of Physical Education / AIU Certificate

Cultural

6 (2 credits per
year)

Director Youth Welfare and Cultural Affairs
(DYCA)

Incubation

6 (2 credits per
year)

Director of University Incubation Centre / IIC

Youth Red Cross

4 (2 credits per
year)

Dean of Student Welfare

Outreach

6 (2 credits per
year)

Dean of Student Welfare

Informal Learning
Informal

2 (2 credits during
whole Programme)

Concerned department/college/institute

<!-- page 5 -->

6.3 Assessment Rubrics and Evaluation
As per Annexure 1 appended to these Guidelines.

6.4 Credit Claim and Verification
Students may use the following form to claim credits for eligible non-formal or informal learning
activities completed during the semester.

STUDENT CREDIT CLAIM FORM
Student Name:
________________________________

Roll No. / Registration No.:
________________________________

Programme / Department:
________________________________

Semester / Year:
________________________________

Activity Category (tick one): [ ] NCC [ ] NSS [ ] Sports & Yogasan [ ] Cultural [ ] Youth Red
Cross [ ] Incubation [ ] Outreach [ ] Informal Learning [ ] Other: __________________
Title
/
Nature
of
Activity:
____________________________________________________________________________
Period of Participation: From __________________ To __________________ Total Hours
Claimed: __________________
Level of Participation / Achievement (tick one): [ ] Institutional [ ] Inter-College [ ] Zonal [ ]
State [ ] National [ ] International
Evidence Attached (tick all applicable): [ ] Logbook [ ] Certificate [ ] Attendance record [ ]
Report [ ] Portfolio [ ] Result sheet [ ] Mentor note [ ] Other: __________________
Credits Claimed: __________________
As per university norms

Basis of Claim: 1 credit = ________ verified hours /

Brief
Description
of
Work
/
Learning
_____________________________________________________________

Outcome:

____________________________________________________________________________
____________________________
Student Declaration: I certify that the information given above is true and that the attached
documents are genuine and submitted for credit consideration as per applicable university rules.
Date: __________________

Student Signature: ________________________________

Endorsement by Activity In-charge / Mentor: Verified and recommended for consideration.
Name:
________________________________
Designation:
________________________________
Signature with Date: ________________________________

<!-- page 6 -->

INSTITUTE CREDIT AWARD AND VERIFICATION FORM
This form may be used by the institute/college/department to verify student participation,
recommend credit award, and approve entry of earned credits in the institutional record/ABC
system, subject to applicable university regulations and the National Credit Framework.
1. Name of
Institution

___________________________
_____

2. Academic
Year /
Semester

___________________________
_____

3. Student
Name

___________________________
_____

4. Roll No. /
Registration
No.

___________________________
_____

5. Programme
/ Department

___________________________
_____

6. Year /
Semester of
Study

___________________________
_____

7. Activity
Category

NCC / NSS / Sports & Yogasan / Cultural / Youth Red Cross / Incubation / Outreach /
Informal Learning / Other: ________________________________

8. Title /
Nature of
Activity

_____________________________________________________________________
___________

9. Duration /
Period

From __________ To
__________

11. Level of
Participation /
Achievement

Institutional / Inter-College / Zonal / State / National / International

12. Evidence
Submitted

Attendance record / Logbook / Certificate / Report / Portfolio / Competition result /
Mentor note / Other: __________________________

13. Learning
Outcomes /
Skills
Demonstrated

Leadership / Teamwork / Discipline / Community engagement / Creativity / Innovation /
Entrepreneurship / Problem-solving / Communication / Other: __________________

14.
Verification by
Activity Incharge

Name: ______________________________ Designation:
______________________________ Remarks:
_____________________________________________________________________
___ Signature with date: ______________________________

15. Credit
Calculation

Verified hours: __________ ÷ prescribed hours per credit: __________ = Credits
recommended: __________ (Recommended benchmark under NCrF operational
practice: 1 credit = 30 hours of field/practical work or as per applicable university/UGC
norms.)

16. Grade /
Result
Recommende
d

O / A+ / A / B+ / B / etc. as per
Annexure 1

18.
Recommendat
ion of
Department /
Committee

Recommended / Not Recommended Remarks:
_____________________________________________________________________
___

19. Approval

Name: ______________________________ Designation:

10. Total
Verified
Hours

17. Credits
Recommend
ed

__________________

__________________

<!-- page 7 -->

by Competent
Authority

______________________________ Signature with seal:
______________________________ Date: ____________________________

20. Office Use

Credit entry approved for institutional record / ABC upload: Yes / No Entry date:
___________________ Entry by: ___________________ Reference No.:
___________________

Note: The University may adapt this format to its approved ordinances, credit ceilings, grading
scheme, and verification workflow and for circulating to the affiliating colleges. The National
Credit Framework recognizes academic, vocational, and experiential learning and supports
creditization of curricular and other activities; current UGC operational guidance also details
credit assignment norms for theory, practical/field work, and experiential learning.

<!-- page 8 -->

Table 1 : Non-formal learning Assessment Rubrics and Grading
Letter Grade

Grade
Point

O
(Outstanding)

10

A+ (Excellent)

9

Requirements
National Cadet Corps

National Service Scheme

International Youth Exchange
Programme/ Republic Day (RD)
participation

International Youth Exchange
Programme/ Participation in
Republic Day Parade Camp (RD)/
National NSS Award/ State NSS
Award/ Pre RD Camp
Participation in National
Integration Camp/NYF/IDC /
Adventure Camp Organised by
Ministry of Youth affairs & Sports
& Yogasan or State NSS Cell along
with NSS Merit Certificate

Centrally organized camps (TSC,
Army Day, IDSSC etc.)/National
Camp participation with ‘C’
Certificate

A (Very Good) 8

'C' Certificate (Alpha Grade)

B+ (Good)

7

'C' Certificate (Beta Grade)

B (Above
Average)

6

'B' Certificate (Alpha Grade)

NEYF/One State level NSS Camp/
University Level Camp along with
NSS Merit Certificate
NSS Merit Certificate along with
120 hours NSS activities (Per year)
+ 7 days Unit Level Camp +
planting and maintaining 02
plants or two-time blood donor
NSS Merit Certificate along with
120 hours NSS activities (Per Year)
+ 7 Days Unit Level Camp +
planting and maintaining 02

Youth Red Cross

International Youth Exchange
Programme/ National Award

Participation in National Level
YRC Youth Exchange Programme/
State level Award along with YRC
Merit Certificate
Participation in Regional level YRC
Training Camp/ 7 days One State
level YRC Training Camp / 7 days
University Level YRC Training
Camp along with Merit Certificate
Merit certificate along with 120
hours YRC activities (Per year) +
One District Level YRC Training
camp+ two time blood donor
Merit Certificate along with 120
hours YRC activities (Per year) +
Institutional Level 7 days YRC
Training camp + One time blood

<!-- page 9 -->

C (Average)

5

'B' Certificate (Beta Grade)

P (Pass)

4

Above 90 Percent attendance in
Regular Parade organized at
Institute level.

F (Fail)

0

Performance below pass level

Ab

0

Absent

plants or one time blood donor
7 Days Unit Level Camp+ 120
hours NSS activities (Per Year)+ 2
One Day Camps

donor
7 Days Institutional Level YRC
Training Camp + 120 hours YRC
activities (Per Year)+ Two days
first Aid Training Camp.

120 hours NSS activities (Per Year) 120 hours YRC activities (Per Year)
Performance below pass level /
insufficient participation

Performance below pass level /
insufficient participation

Absent

Absent

Table 2 : Non-formal learning Assessment Rubrics and Grading
Letter Grade

Grade
Point

O (Outstanding)

10

A+ (Excellent)

9

Requirements
*Sports

Cultural Activities (Music, dance, fine arts,
literary events, theatre etc.)
I, II, III Position at Olympic, World cup, Representation at international/ national level
Para Olympic, Commonwealth Games, cultural event organised by Govt Department/
Asian Games, Continental Games
Ministry with certificate.
Junior World Cup, Youth Olympic (04 year
cycle competition), World Uni Games
Participation at Olympic World cup, Para Position at state/inter-university youth festival
Olympic, Commonwealth Games, Asian with valid Certificate.
Games, Continental Games, World
University Games, Junior World Cup,
Youth
Olympic
(04
year
cycle
competition)

<!-- page 10 -->

A (Very Good)

8

B+ (Good)

7

B (Above Average)

6

C (Average)

5

P (Pass)

4

F (Fail)

0

Medalist/Participation at (I, II, III year
cycle competitions)
World Cup, Sr/Jr Level
Asian Champ Sr/Jr Level
World Champ Sr/Jr Level
Asian/World Uni /Championship
Any Recognised Sr/Jr Level
International Tournament
I, II, III Position at Sr. National/Federation
Cup. Interzonal National, All India Intervarsity(AIIU) Level, Khelo India Uni
Games/ Khelo India Youth Games with
valid certificate.
Participation at Sr. National/Federation
Cup. Interzonal National/AIIU Level, Khelo
India Uni Games, and zonal Inter
University Tournaments with Valid
Certificate.
Participation at Khelo India Youth games,
Junior National, Youth National
Competition, Any Recognized National
games for atleast above 19-year age
group
Sr. State Champ., Inter collegiate Champ,
I, II, III position of Junior State, Youth
State participation inat least19-year Age
Group
Any participation below the levels
mentioned above

Participation at state/inter-university youth
festival with valid Certificate or Position at
Inter-zonal level with valid certificate.

Position at Zonal Level

Position in Inter College level with valid
certificate or Participation in Zonal level.

Position in cultural activities at Institute level
with valid certificate

Participation in Institute Level training for
cultural activities for minimum 120 hours and
Participation in Institute level Cultural
Programme with valid documentation.
Insufficient participation, missing
documentation, or failure to meet the
minimum requirements in cultural activities.

<!-- page 11 -->

Ab

0

Absent

Absent

*
1. Championship must be organized by a recognized federation duly affiliated with IOC, Continental federation, JOA and
approved by Ministry of Youth Affair & Sports & Yogasan of Concern Govt. of State/Country.
2. The achievement must be in the duration of the course.
3. Grade Point for one of the Highest Achievement will be given in one session.
4. The competition must be in the at least under 19 age Group and above.

Table 3 : Non-formal learning Assessment Rubrics and Grading
Letter Grade

Grade
Point

O (Outstanding)

10

A+ (Excellent)

9

Requirements
Outreach
Leadership in a high-impact outreach
project (strong community participation,
measurable social impact) at
national/inter-university level with
documented outcomes such as suggested
solutions for identified local problems.
Major contribution to adult
education/dropout education/resource
mobilization/survey/ field work related to
community problems with with
documented evidence, and visible benefit

Incubation and entrepreneurship
Receiving Startup India Seed Grant /
TRL** level 7 or above/ Patent Granted /
Starting one’s own bootstrapped MSME/
Startup (should not be an business enterprise)
with at least revenue generation of 2 lakhs/
Getting funding of above 5 lakhs from an
incubation centre/ Winner (any position in SIH* )
Idea selected for the Final round of SIH /any
other Hackathon organized by an creditable
organizer /body or achieving a TRL level of 5 or
6 assessed by NTRAF#) /publishing a patent or
getting a funding between 2 to 5 lakhs

<!-- page 12 -->

to the target group.
A (Very Good)

8

Leadership role in organizing outreach
programmeby the college with
satisfactory contribution, proper
documentation, and demonstrated
learning or community benefit.

Achieving TRL Level (3 or 4 assessed by
NTRAF )/ pitching the idea to an incubation
centre/ filing a patent / getting funding in
innovation design challenge/Selection in the
internal Hackathon for SIH

B+ (Good)

7

Minimum 120 hours of active
participation in a structured outreach
activity in lead roles such as counselling
with supporting evidence such as
attendance, photographs, or activity
summary.

Secured a position in Idea Pitching at an event
organised at the state level by creditable
organizer/ achieving TRL (1 and 2) to be
assessed by NTRAF or university appointed
committee

B (Above Average)

6

Minimum 120 hours of active
participation in a structured outreach
activity such as awareness campaigns and
rallies with supporting evidence such as
attendance, photographs, or activity
summary.

Secured a position in Idea pitching at an event
organized at university Level

C (Average)

5

Minimum 120 hours of active
participation in a structured outreach
activity such as advocacy with supporting
evidence such as attendance,
photographs, or activity summary.
.

Pitched an idea in the event organized by a
department of the University .

P (Pass)

4

Enrollment in outreach activities and

1. Attended atleastFive events of IIC/

<!-- page 13 -->

participation in at least one training
programmes.

Incubation Centre/ in an year
OR
2. Attended at least Two workshops on
Entrepreneurship or IPR
OR
3. Completed a MOOC on
Entrepreneurship or IPR

F (Fail)

0

Insufficient participation, lack of valid
documentation, or failure to demonstrate
any meaningful outreach contribution.

No participation

Ab

0

Absent

Absent

Table 4: Assessment Rubrics and Grading for Yogasana Sports
Letter Grade
O
(Outstanding)

Grade
Point
10

Assessment Rubrics / Requirements


A+
(Excellent)

9



A
(Very Good)

8



Gold/Silver/Bronze Medal at World Yogasana Championship/ Asian Yogasana
Championship, or representation in internationally recognized Yogasana
competitions conducted by recognized federation by Ministry of Youth Affairs &
Sports, Govt. of India.
Participation in World Yogasana Championship / Asian Yogasana
Championship/International Yogasana Championship, or Medal at National Games
recognized by Government/recognized Yogasana Federation by Ministry of Youth
Affairs & Sports, Govt. of India.
Medal at Senior National Yogasana Championship / All India Inter University /
Federation Cup / Participation at National Games organized by Ministry of Youth
Affairs & Sports, Govt. of India.

<!-- page 14 -->

B+
(Good)

7



Participation in Senior National Yogasana Championship / All India Inter University Federation Cu
Yogasana / Medal at State Yogasana Championship.

B
(Above Average)

6



Participation in State Yogasana Championship / Medal at Inter- University Yogasana
Championship conducted by recognized federation by Ministry of Youth Affairs &
Sports, Govt. of India.



Participation in University / Medal at District Level Yogasana Championship or recognized Open Yog
Championship organized by State Association affiliated to Haryana Olympic Association.



Participation in College/Institution Level Yogasana Championship / Yogasana
demonstration, or minimum 120 hours of structured Yogasana training certified by
the recognized Federation.

C
(Average)

5

P
(Pass)

4

F
(Fail)
Ab

0
0

Less than the prescribed participation, inadequate documentation, or failure to complete
minimum Yoga Club requirements.
Absent

<!-- page 15 -->

Table 5: Assessment Rubrics and Grading for Yog Club
Letter Grade

O
(Outstanding)

A+
(Excellent)

Grade
Point

10

9

Attendance
Total Hours –
60

90% or above

80% or above

Mandatory Outreach Programs to be
Organized
Any 6 Programmes:
Village Yoga Camp, School Yoga
Awareness
Programme,
Women
Wellness Programme, Senior Citizen
Yoga Session, Anti-Drug Awareness
through Yoga, International Day of Yoga
(IDY) Celebration, Yoga for Government
Employees, Yoga for Persons with
Disabilities (where feasible).

Any 5 Programmes from the approved
Outreach Activities.

Requirements


Minimum 50 Participants in each Programme,
leadership role, complete documentation,
active participation in IDY, measurable
community impact.



10 Yog Sutras & 10 Bhagavad Gita Shlokas
(100% Memorized).

10 Asanas in each category performed with
perfection, i.e. Forward Bending, Backward
Bending, Hand Balance, Leg Balance, Supine &
Twisting. Ground Work Experience Book
completed with excellent documentation.
 Active organizer with complete documentation
and proper reporting.





8 Yog Sutras & 8 Bhagavad Gita Shlokas
(100% Memorized).



Minimum 8 Asanas in each category with good
alignment, Experience Book completed.
Active participation in Yoga Club & IDY with
complete documentation.


A
(Very Good)

8

75% or above

Any 4 Programmes from the approved
Outreach Activities.



6 Yog Sutras & 6 Bhagavad Gita Shlokas
(100% Memorized).

<!-- page 16 -->



B+
(Good)

7

70% or above


Any 3 Programmes from the approved
Outreach Activities.




B
(Above
Average)


6

65% or above

Any 2 Programmes from the approved
Outreach Activities.




C
(Average)

5

P
(Pass)

4

F
(Fail)

0

55% or above

50% or above

Below 50 %

Any 1 Programmes from the approved
Outreach Activities.

Participation in at least one Institutional
Yoga Activity (including IDY, Yoga
Awareness Programme or Wellness
Activity).
No Outreach Programme completed.





Minimum 7 Asanas in each category, Experience
Book submitted.
Regular
participation
and
proper
documentation.
4 Yog Sutras & 4 Bhagavad Gita Shlokas
(100% Memorized).
Minimum 6 Asanas in each category, Experience
Book with basic documentation.
Satisfactory participation and submission of
required records.
2 Yog Sutras & 2 Bhagavad Gita Shlokas
(100% Memorized).
Minimum 5 Asanas in each category, Experience
Book partially completed.
Minimum documentation completed.
2 Yog Sutras & 2 Bhagavad Gita Shlokas
(100% Memorized).
Basic Asana demonstration, Experience Book
submitted.





Basic documentation maintained.
Basic knowledge of Yog Sutras & Gita Shlokas.
Demonstration of a few Asanas, minimum
Experience Book maintained.



Minimum
requirements
not
documentation not submitted.
Competency requirements not
Experience Book not submitted.



fulfilled;
fulfilled;

<!-- page 17 -->

Ab

0

Absent

________

Table 6 : Informal Learning Assessment Rubrics and Grading
Letter Grade

Grade
Point

Requirement for Informal Learning

O
(Outstanding)

10

Completion of a high-impact self-learning activity with strong evidence, such as a certified online course,
published article/blog, portfolio, innovation prototype, or community learning project, along with a reflective
report showing clear outcomes and application.

A+ (Excellent)

9

Completion of an advanced self-learning activity with certificate/evidence, such as MOOCs, workshops,
independent projects, or structured field-based learning, with a well-written reflection and demonstrable skill
gain.

A (Very Good)

8

Completion of a relevant self-directed learning task with documented proof (certificate, portfolio, reading log,
project summary, mentor note) and a reflection showing good understanding and application.

B+ (Good)

7

Participation in a meaningful informal learning activity with partial documentation and a brief reflective note
showing learning outcomes.

B (Above
Average)

6

Evidence of consistent engagement in self-learning for the required minimum hours (60), with basic proof and
satisfactory reflection.

C (Average)

5

Minimum acceptable engagement in informal learning activity with limited documentation and basic
demonstration of learning.

P (Pass)

4

Completion of the minimum prescribed hours (60)/activity with proof of participation, but limited evidence of
reflection or measurable learning outcomes.

<!-- page 18 -->

F (Fail)

0

Inadequate participation, insufficient documentation, or inability to demonstrate any meaningful learning
outcome.

Ab (Absent)

0

Absent

Note: Creditization of informal learning should be based on transparent, verifiable, and outcome-based evidence to avoid
malpractice. Students must submit authentic proof such as certificates, portfolios, activity logs, mentor endorsements, project
reports, reflective statements, or demonstrable outputs. Institutions should assess all learning through multiple modes such as vivavoce, tests, presentations, plagiarism screening, random verification. It should be done through an institutional committee.
Duplicate claims, fabricated documents, proxy participation, and unverifiable activities should not be considered for credit. Proper
record keeping, periodic audits, and digital documentation may further strengthen fairness, accountability, and credibility in
awarding credits for informal learning.
