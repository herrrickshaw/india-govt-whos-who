---
doc_id: "ad5fbe1ca8d6ae3e"
source_url: "https://bseh.org.in/uploads/files/4f3b6362b0490969a07e18125ec04d56.pdf"
ministry: "Board of School Education Haryana"
title: "Quotation for Gazette and Result Sheet Binding"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "449be777a9785631"
---

<!-- page 1 -->

gfj;k.kk fo|ky; f’k{kk cksMZ+] fHkokuh
vuqca/k&
I
¼;g ist iw.kZ :i ls Hkjdj cksMZ dk;kZy; esa okfil Hkstk tkuk gSA½
dksVs'ku uksfVl la[;k%&
1631@izdk’ku
fnukad%&
08-10-2026
eqnz.k ,oa vkiwfrZ dh tkus okyh
lkexzh@lkekuds fof'k"Vrkvksa dh vuqlwph
Ø
0

vkbZVe dk
uke o fooj.k

vkdkj
,oa
eqnz.k

ek=k le;kof/k

iz;ksx fd, tkus okys dkxt dk
fooj.k

njsa lHkh djksa
lfgr o
fHkokuh esa cksMZ
Hk.Mkj d{k esa
tek djokus
lfgr gSA

1-

Gazette(New
& Old)

Size
12“x17”

295

60 Working
days

The Bidder will use original leather,
best quality 40 oz cardboard, craft
paper and cover paper of 60 GSM of
any reputed paper mill, and binding
should be corner leather binding

----------------Rs.

2

Result Sheet
(New & Old)

Size
8½“x13½
”

350

60 Working
days

The Bidder will use original leather,
best quality 40 oz cardboard, craft
paper and cover paper of 60 GSM of
any reputed paper mill, and binding
should be corner leather binding

----------------Rs.

;g izekf.kr fd;k tkrk gS fd dksVs'ku uksfVl ds vuqca/k&
I o II ds lHkh funsZ'k] fu;e
vkSj 'krsZa Lohdk;Z gSa vkSj esjs }kjk vuqca/k&
I esa nh xbZ njsa 01 o"kZ rd oS/k jgsxhA
123456789101112-

dksVs'kudÙkkZ dk uke
-------------------------------------------------------------------QeZ@,tsalh dk uke
-------------------------------------------------------------------QeZ@,tsalh dk irk
-------------------------------------------------------------------iSu uEcj
-------------------------------------------------------------------th,lVh uEcj ¼vfuok;Z½
-------------------------------------------------------------------eksckbZy uEcj ,oa bZ&esy vkbZMh -------------------------------------------------------------------QeZ@,tsalh dh iathdj.k la[;k
-------------------------------------------------------------------cSad dk uke ftlesa dksVs'kudÙkkZ dk [kkrk
S g-------------------------------------------------------------------cSad dh 'kk[kk dk uke
-------------------------------------------------------------------dksVs'kudÙkkZ dk [kkrk uEcj
-------------------------------------------------------------------cSad dh 'kk[kk dk vkbZ,Q,llh dksM -------------------------------------------------------------------esjh@gekjh QeZ@,tsalh m|ksx ,oa okf.kT; foHkkx gfj;k.kk ;k vU; fdlh ljdkjh
foHkkx@,tsalh ls okn&fookfnr@izfrcaf/kr@CySdfyfLVM ugha gSA

dksVs'kudÙkkZ ds gLrk{kj eksgj lfgr

<!-- page 2 -->

gfj;k.kk fo|ky; f’k{kk cksMZ+] fHkokuh
vuqca/k&
II
dksVs'ku ds fy, fu;e o 'krsZa%&
1-

ckbZ.MdjokbZ tkus okyh izys[kksa
ds izk:i izdk'ku 'kk[kk ds dk;kZy; esa fdlh Hkh
dk;Zfnol esa ns[ks tk ldrs gSaA

2-

ckbZ.M djokbZ tkus okys
izys[kksa
dh njsa vuqca/k&
I esa nh tkuh gS rFkk njsa lHkh VSDl lfgr
o fHkokuh esa cksMZ Hk.Mkj d{k esa tek djokus lfgr gSA dksVs'kudÙkkZ }kjk njksa dks vadksa ,
'kCnksa esa Hkjk tkuk gSA njksa dks Hkjus ds ckn
I dks
vuqca/k&
cksMZ dk;kZy; dh bZ&esy vkbZMh
ratesbseh@gmail.com ij okfil Hkstk tkuk gSA

3-

dksVs'ku dk le;@njsa ,d lky rd ekU; gksaxhA lwph esa fn, x, dk;Z ds vfrfjDr
vkns'k&i= dh frfFk ls ,d o"kZ rd blh nj ij leku fof'k"Vrkvksa okyh vU;
ckbZfMax
dk
dk;Z Hkh lgefr ds vk/kkj ij fn;k tk ldrk gSA

4-

QeZ@
ckbZ.Mjdh dksbZ Hkh 'krZ ekU; ugha gksxhA

5-

cksMZ dk;kZy; }kjk
izys[kksa
dh ek=k ?kVkbZ@c<+kbZ tk ldrh gSA

6-

dk;Z U;wure njksa ij lkSaik tk,xkA ;fn igyh QeZ }kjk lkSaik x;k dk;Z lEiUu ugha fd;k
tkrk gS rks ml voLFkk esa nwljh U;wure nj okyh QeZ dks dk;Z lkSai fn;k tk,xk vkSj njksa
esa tks Hkh varj gksxk og igyh QeZ ls olwy fd;k tk,xkA ;fn QeZ }kjk njksa dk varj
tek ugha djok;k tkrk gS rks lfpo] g0 fo0 f'k0 cksMZ QeZ dks CySdfyLV dj ldrs gSaA

7-

dk;Z vkns'k&i= lkSais tkus dh frfFk ls vxys fnu ls dk;Z vkjEHk djus dh frfFk ekuh
tk,xhA

8-

layXu lwph esa n’kkZ;k x;k dk;Z 60 dk;Zfnolksa esa lEiUu djuk gksxk vkSj dk;Z esa foyEc
gksus dh fLFkfr esa fcy esa fuEu fooj.k vuqlkj dVkSrh dh tk,xh%&
i.01 ls 10 fnu rd foyEc gksus ij dqy ns; jkf’k ij 2 izfr’krA
ii.
11 ls 20 fnu rd foyEc gksus ij dqy ns; jkf’k ij 5 izfr’krA

9-

;fn dk;Z esa flykbZ@ckbZf.Max bR;knh lEcU/kh xyrh ikbZ tkrh gS rks fuEukuqlkj dVkSrh
dh tk,xh%&
i)
ckbZfMax
dh xyrh] [kjkc xq.koÙkk] fpidkus@LVSifyax lEcU/kh xyrh]Øekad dh
xyrh bR;knh gksus ij 50 iSls izfr xyrh] izfr izys[k dVkSrh dh tk,xhA
ii)
de vkiwfrZ] dVh&QVh] xqe bR;knh ik, tkus ij
ckbZ.Mj}kjk mlh la[;k esa
lkexzh@lkeku dks cnyk tk, ;k ftruh ek=k esa lkeku@lkexzh
de@dVh&QVh@xqe ikbZ tkrh gSa ml voLFkk esa mruh gh ek=k dh ewy dher dh
nqxuh dVkSrh dh tk,xhA
iii)
;fn fn, x,
izys[kksa
ds fof'k"Vrkvksa dh vuqlwph ls dkxt
@ckbZfMax doj¼xÙkk½
dk
lkbZt NksVk
@cMkik;k tkrk gS rks fcy dh jkf'k esa ls ,d izfr'kr dh dVkSrh dh
tk,xhA

10-

;fn ckbZfMax
lkexzh@lkeku fn, x, lkexzh@lkeku ds fof'k"Vrkvksa dh vuqlwph
vuqlkj
ugha ikbZ tkrh gS ;kiz;ksx esa yk, tkus ;ksX; ugha gS rks lfpo] g0fo0f'k0cksMZckbZ.M
}kjk
fd, x, dk;Z dks vLohd`r fd;k tk ldrk gSA vLohd``r izys[kksa
ds LFkku ij nksckjk ls
lgh ckbZfMax
djds 5 fnuksa ds vUnj&vUnj ;k lfpo }kjk fn, x, le; esa
dk;Z dj uk
gksxkA ;fn QeZckbZfMax
esa vlQy gks tkrh gS rks lfpo ds ikl vf/kdkj gksxk fd og QeZ
dks CySdfyLV dj ldrs gSaA

11-

;fn fcy dk Hkqxrku igys gh fd;k tk pqdk gS] rks tqekZus dh jkf'k dh olwyh QeZ ds
fdlh Hkh yfEcr@ckn ds fcy ls dh tk ldrh gSA

12-

tks dksVs'ku mijksDr 'krksZa ds vuq:i ugha gS mUgsa fcuk fdlh fopkj ds vLohd``r dj fn;k
tk,xkA

13-

QeZ@,tsalh m|ksx ,oa okf.kT; foHkkx gfj;k.kk ;k vU; fdlh ljdkjh foHkkx@,tsalh ls
okn&fookfnr@izfrcaf/kr@CySdfyfLVM ugha gksuh pkfg,A

14-

dksVs'ku ls igys o ckn esa fu;e o 'krksZa esa cnyko@NwV] dksVs'ku jn~~n djus] lIykbZ
vkns'k jn~~~n djus]
fdlh Hkh fookn ds fy, o ;fn dksbZ fcUnw fu;e o 'krkasZ esa ugha gS rks
mlds fy, fu.kZ; ysus dk vf/kdkj lfpo] gfj;k.kk fo|ky; f'k{kk cksMZ dks gksxk o
QeZ@ckbZ.Mjds fy, ck/;dkjh gksxkA

<!-- page 3 -->

gfj;k.kk fo|ky; f’k{kk cksMZ+] fHkokuh
dksVs’ku lwpuk
dksVs’ku uksfVl la[;k%&
1631@çdk’ku

fnukad%&
08-10-2026

fo”k;%& cksMZ dk;kZy; ds xtV ,oa ifj.kke ‘khV ckbZ.M djokus ckjsA
cksMZ dk;kZy; ds xtV ,oa ifj.kke ‘khV ckbZ.M djokus ds fy,iqu%vkWuykbZu dksVs’ku
vkeaf=r dh tkrh gS ftldk fooj.k layXu vuqca/k&k esa fn;k x;k gS] tksfd vuqca/k&kk esa mYysf[kr
fu;eksa vkSj ‘krksZa ds v/khu gSA dksVs’k
u fnukad12-10-2026 dks iwokZg~u 11%00 cts rd bZ&esy
vkbZMh
ratesbseh@gmail.com ij Hksth tkuh gSA

;fn dksVs’kudŸkkZ bu lHkh funsZ’kksa@fu;eksa o ‘krksZa ¼tSlk fd vuqca/k&k ,oa vuqca/k&k
gS½ dk iwjh rjg ls ikyu ugha djrk gS] rks vkWuykbZu dksVs’ku ij fopkj ugha tk,xk
fd;k A
l{ke vf/kdkjh dh miyC/krk dh fLFkfr esa dksVs’ku mlh fnu [kksys tk,axsA

lgk;d lfpo ¼çdk’ku½
d`rs% lfpo
