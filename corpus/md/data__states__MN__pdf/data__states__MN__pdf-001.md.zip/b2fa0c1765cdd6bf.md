---
doc_id: "b2fa0c1765cdd6bf"
source_url: "https://planningmanipur.gov.in/media/filer_public/0e/25/0e252f80-66d3-4e46-b627-eedd9b6872bb/meld_e-tender_0001.pdf"
ministry: "Planning Department, Manipur"
title: "Notice Inviting Tender -Providing services of MEL&D under PMKSY WDC 2.0"
date: ""
pages: 35
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "a1cf39f392a147e9"
---

<!-- page 1 -->

STATE LEVEL NODAL AGENCY
WATERSHED MANAGEMENT, MANIPUR
SLNA-IWMP_S"> Department of Planning, Babupara, Imphal-795001
NOTICE INVITING TENDER
Imphal, thee November 2024
No; SLNA-103/7/2024-SLNA-WM(SLNA): State Level Nodal Agency for Watershed Management
~ SLNA (WM), Manipur invites e-tender from eligible and qualified GST registered firms for providing
services of monitoring, evaluation, learning and documentation (MEL&D) under Pradhan Mantri Krishi
Sinchayee Yojna — Watershed Development Component 2.0 (PMKSY — WDC 2.0) as per the Terms of
Reference (TOR) detailed at Annexure A, which is uploaded at website www.manipur.gov.in, httpsi/: |
planningmanipur.gov.in and www,manipurtendes.gov.in. Critical dates and important information are as
below: |
রর Chief Executive Officer, SLNA(WM), Manipur |
Name, Designation and address of the যি '
authority to whom the bids have to be Babar, Near State Guest House, Imphal, PIN: |
subrnitted online e-mail:kulka01@yahoo.co,in
iad 7 Online submission only through
Mode tor submiting the kids https://manipurtenders.gov.in
Bid Publishing date & time Date: 30.11.2024, Time: 04:00 PM
Bid document download start date Date: 01.12.2024
Bid submission start date and time Date: 06.12.2024, Time: 12:00 Noon
Closing date and time for submission of bids | Date: 22.12.2024, Time: 03:00 PM
Chief Executive Officer, SLNA (WM), Manipur,
Venue, time and date of opening of Planning Department, Babupara, Imphal West -
technical bids {if possible) 795001
Date: 23.12.2024, Time: 01:00 PM
Estimated Cost (Aprrox-maximum Rs. 170.23 lakhs
Earnest Money Deposit Rs, 3.40 lakhs
Bid validity period hea days from the date of opening of the Technical
(N. Kulkarani Devi) a 1০6
Chief Executive Officer
SLNA (WM), Manipur

<!-- page 2 -->

, : STATE LEVEL NODAL AGENCY
Mae WATERSHED MANAGEMENT, MANIPUR
SUNA-IWMP D> Department of Planning, Babupara, Imphal 795001
TERMS OF REFERENCE
For Monitoring, Evaluation, Learning and Documentation (MELD)
of
Pradhan Mantri Krishi Sinchayee Yojna —- Watershed Development Component 2.0 (PMKSY -
WDC 2.0)
4. Introduction:

PMKSY -WDC 2.0 is a CSS project sponsored by Department of Land resources, Government
of India for the project period of 2021-22 to 2025-26. DoLR has sanctioned/ approved 13 projects covering
13 districts (80 villages) with an area of 58690 Ha. State Level Nodal Agency (9115) for Watershed
Management, a registered Society under Planning Department, is implementing the 13 projects under
PMKSY -WDC 2.0 in Manipur along with 13 Watershed Cell cum Data Centres (WCDC) at district level,
13 Project Implementing Agencies (PIAs) at block level and 80 Watershed Committees (WCs) at village
levels. The project is implemented based on the Guideline for New Generation Watershed Development
Project 2021 published by DoLR.

Summary of the 13 projects under PMKSY -WDC 2.0 in Manipur

No of

Project ID Area | villages

covered

Imphal East -WDC-/2021-22 | Imphal East 4374 | 6 |
-WDC-1/2021-22
inh টি Imphal West | 4950 |e |
জি রা রা
Kakching-WDC-U/2021-22 Kakching 4658 | 6 |
| 5 | Chandel WDC-1/2021-22 Chandel 4972
Churachandpur-WDC-1/2021-22

pe [owen পে
Kanpokpi -WDC-12024-22 Kanpokpi [55778140499
| 8 _| Noney-WDC-1/2021-22 4924
| 9 _| Pherzawi -WDO-12021-22 4474
ভাতা 915
Tamengong-WDC-2021-22 4876
Tengnoupal-WDC-1/2021-22 Tengnoupal | 3994 | 6 |
Ukhrul-WDC-12021-22 Ukhrul 5039 | 5 |
77 ীগঞ_1589601 নয ___

<!-- page 3 -->

নে Objective of the Scheme: To improve productive 00191718100 rainfed / degraded land through
integrated watershed management; to strengthen community based local institutions for
promotion of livelihoods & watershed sustainability, and to improve the efficiency of watershed
projects through cross learning and incentive mechanism.
At macro - level, the vision of WDC-PMKSY 2.0 projects is to accelerate the economic growth
rate of agriculture in the less endowed rainfed areas of the country. Moreover, this should be
achieved by adopting harmony with ecological principles of development for ensuring sustained
transformation of economy and ecology. The guiding principles shall be a better Economy,
Ecology and Equity in the rainfed regions of the country.
At watershed level, the development plan shall be guided by the need to achieve higher incomes
for farmers, expanded livelihood options for landless, equity in distribution of benefits, community
ownership and management, and ecologically sustainable action plan.

2.4 Enhancing economic growth of village community dependent on watershed by:

¢ Securing production and farmers’ income against climate variability and Its risks of
drought spells through diversification of crop systems & animal husbandry, and varied
livelihood portfolios; efficient water harvesting and retention of rainwater in soil profile;
and entitling all project members to ground and surface water resources for life saving
irrigation on equitable basis.

improving intensity and productivity of various crops, livestock, fisherles and biomass
production systems through optimal, integrated, sustainable and efficient use of natural
resources in project areas.

e Recognising the stake of non-land holding project members, and promoting alternate
livelihood opportunities

¢ Building an ecosystem of enterprises for facilitating efficient scales of operations, access
to credit, and market linkages; knowledge sharing; and resource convergence led by
vibrant member managed farmers’ institutions.

2.2 Ecological restoration and sustainable management of natural resources across the project area
through:

e Sustained community action in management of natural resources/assets such as
groundwater, soil, community resources, etc. by way of building community
organisations like User Groups (UG), and transferring maintenance responsibilities to
them. Further, supporting UGs with regulatory norms, that are institutionalized through
the Gram Panchayats.

e Promotion of simple, easy to use and affordable technologies and practices, that builds
upon local knowledge and available materials,

2.3 Improving the economic and social conditions of the resource poor, asset-less, differently-abled
and women in particular through:

« Shared and equitable access to the land, water and biomass resources developed.

* Greater access to income generating opportunities.

¢ Facilitating co-option of members of these categories in various community institutions
ie. FPO, User Groups etc.

২০০৮

<!-- page 4 -->

Need for an Effective External MEL&D system
Though SLNA has placed an internal monitoring system at State, District, block and village levels,
the project in specific proposes for an independent and external MEL&D agency that has the skills and
proven experienced in the area, for the following reasons:
|, The project envisages botfoms-up approach of implementation by actively involving community
and other grass root level institutions like Watershed Committees, Self-Help Groups, User
Groups, Individual enterprises/ firms and the Watershed Development Team. These groups need
to work in tandem for effective implementation of the project.
IL The organizational learning processes need 10 be streamlined through the observaticns of an
extremal agency to assist project functionaries at various levels.

Il. Impact evaluation of watershed projects in particular has to be made using technology such as
Remote Sensing, GIS and GPS for unbiased and reliable assessment in terms of changes in
biophysical parameters.

IV. Aneffective and operational external MEL&D system is very much required for streamlining the
initiation, for tracking the progress and performance of the project’ process interventions,
possible mid-course corrections and assessing the impact of interventions.

V. Process monitoring along with documentation is to be done to confirm that the project activities
are implemented in compliance with the Guideline for New Generation Watershed Development

. Project 2021.

VI. Each project being implemented under PMKSY -WDC 2.0 requires timely and appropriate
information on its performance, measured by combining both qualitative and quantitative
performance indicators.

VII. [tis imperative that MEL&D under PMKSY -WDC 2.0 has to make immense value addition to the
project during its course of implementation and as well as on its impacts. It is further reiterated
that an effective MELD & D system is very essential in such projects to ensure transparency to
achieve the objectives.

Proposed Frame Work for the MEL&D System
PMKSY 400 2.0 emphasizes on learning-by-doing approach. It is realized that a carefully
developed independent Monitoring and Learning framework is critical to ensure learning and effectively
use the same for improving project implementation and thereby achieving the project development
objectives. An effective MEL&D system has to
|. Utilize the expertise of an extremal and independent agency in monitoring, evaluation,
learning and documentation which would contribute for effective implementation of the
project.
Il. Identify the Learnings early so as to facilitate informed decision making and timely
adoption at all levels namely village, GP, taluk, district and Stare,
Ill. Be supportive of learning among the various stakeholders of the project by facilitating
information dissemination.
IV. Institute bottoms-up modes of functioning and learning by providing links to decision
making forums at different levels staring from the Micto Watershed Executive
1৬৮

<!-- page 5 -->

: Committee/ PIA level to the State level (SLNA level) including the PIA (project level) and
the WCDC (district level). It is proposed to develop optimal information flow between
these groups of stakeholders and decision makers at different levels.
V. An effective monitoring. evaluation, learning and documentation system is expected to
improve operational learning at all levels (village, GP, taluk, district and State) throughout
the project implementation.
Outline of the tasks to be performed by External MEL&D Agency
SLNA proposes to appoint independent external agency to assist SLNA in evolving a more
responsive and effective MEL&D system for the PMKSY -WDC 2.0.
e Establishment of an operational MEL&D System:
Establish an effective MEL&D system to provide unbiased, reliable and relevant information on
progress and performance of each project by reflecting the actual status of the implementation process
(both quantitative and qualitative) and propose timely corrective measures.
e Mid Term Evaluation:
PMKSY - WDG 2.0 is at its mid-point period of implementation. Hence the mid-term
evaluation of these projects is proposed to be carried out to obtain feedback on the initial impactsof
the programme and the bottlenecks faced if any in the process of its implementation. This mid-term
evaluation would enable a pathway analysis at the mid-course providing for improvement in the next
course, The M&E system on the whole is designed as a learning mechanism with corrective options
both at the project & policy level. The proposed mid-term evaluation is a part of this overall strategy
with following focus area.
i) Help in deriving strategic lessons for mid-course correction, if any, in the approach and designsof
the project and its implementation, and assess whether the vision of economy, equily and ecology is |
being realized at ground level. The findings should help effecting necessary changes in
implementation strategy and reorient the focus on different components of the project development ৃ
plans if required. |
ii) To identify process gaps and assess performance and quality of outcomes. The evaluation willbe |
on the physical, technical, and financial aspects of the project.
iii) Learning related to institutions, technology, processes, resource allocation and impacts,besides |
other aspects of implementation can feed as valuable inputs for effecting necessary modifications and }
designing of the course of implementation.
a) Indicators for Evaluation :
|

<!-- page 6 -->

Whether all manpower positions in
place
at
Pre-Project |Mid-Project
Status Status
(aggregate) | (aggregate)
Amount of sanctioned Central
Share received (Rs. Crores)
[Amount of sanctioned State
Share received (Rs. Crores)
Amount of total funds
(central + state
share) Utilized (Rs. Crores)
otal funds planned 11001
convergence in the project area (Rs.
Crores)
Total expenditure incurred through
convergence (Rs. Crores)
3. Gross Cropped Area ( Ha.) This represents the
total area sown once
and/or more 19
lonce in a particulal
year, ie. the area ig
counted as man’
times as there are
lsowings in
lyear.
Area under rabi crop (Ha.) [7]
? | | |
৬9৮

<!-- page 7 -->

es
a
a 77
Net Sown Area (Ha.) This represents the
total area sown wit
crops and orchards.
‘Area sowed more
than once in the same
ear is counted onl
once.
ts Cropping Intensity (%) Ratio of 01099
Cropped Area to Net
SownArea in %
Area covered under diversified [This will capture the
crops/ change in cropping systems Change none pat o
Ha. crop to another patte
(Ha) resulting in addition
lof new crops
Area brought from Nil / Single
crop to double or more crop(Ha.}
Single to double or more crop
(18)
11,160 per hectare of major crops Average yields per |
Qt/Ha. hectare of principal |
) crops have been |
02120 by dividing the |
total production by the |
corresponding totalarea
lunder each crop.
a i
|
|

<!-- page 8 -->

. G.. Pulses
12. |Area of culturable wasteland (Ha.) is includes 1900
‘Available for cultivation
whether taken up or no}
taken up for cultivatio
lonce, but not cultivated
Iduring the last five years 0
more in — successio
lincludingthe current yea
for some reason or the
other. Such land maybe
either fallow or covered
with shrubs and jungles,
which arenot put
ito any use.
13. Number of Water Harvesting
Structures (WHS) constructed
/rejuvenated |
14, Area Covered with soil and
Moisture
conservation activities (Ha.)
15. Area under protective Irrigation Protective — irrigation
Ha. ৪05 as a
(Ha) upplementary source!
lof water over and!
above rainfall
16. Area of degraded land covered Degraded land
rainfed area developed (Ha.) represent the land
Iwith low productivity;
rainfed area is theone
where  solirce 0
irrigation is rainfall;
17. Farmers’ Average Household From interventions
Income Under WDC-PMKS
per Annum (Rs. In Lakhs) 2.0

<!-- page 9 -->

. 18, Number of Farmers Benefited From interventions
Under WDC- PMKS
2.0
19. No. of Persondays Generated
(man -days)
20. Average depth of water table in Standard — methods
dug wells (mts.)-Summer lof measuring 09910
Season water table may
be used
21, Average depth of water table in Standard = methods
tube wells (mts.) - Summer lof measuring depth
Season ‘of water table maybe
lused
22, Milk Production of Milch Cattle
0417)
24, Annual Migration from rural to urban
area in project area (Nos.)
25, INo. of springs rejuvenated
(if applicable)
26. No. of persons benefitted due to
rejuvenation of springs
27, No. of | Community Based
Organization
[7
a i 771
| ৯ 1 7]
28. No. of Members in Community
Based Organization
a
[১ i
রা রা রা
30. {Average annual net income of an
1520 Member
31. Average annual net income of an
ISHG = Member

<!-- page 10 -->

7 | কর | Ecological Perspective
ls there a system of auditing of status
of natural resources at intervals
(Yes/No)
Whether Gram Panchayats (GPs) and
[303 enforcing the norms relating ta
sharing of usufructs rights (Yes/No)
রে Whether all members of GPs and
UGs trained to: maintain and monitoral
the natural resources and assets
created (Yes/No)
| জি FFeuty Aspect
Whether landless poor and womenfind
a place in watershed units like
watershed committees
(Yes/No)
Whether landless poor and women
are active member of FPO, SHG,
Village Level Institutions (VLIs) and
vatious UGs
(Yes/No)
Whether landless and asset-less poo ৃ
benefited from activities that promote :
alternate livelihood options (Yes/No) ,
Execution of Planned Works :
against Targets
Variation of area under shape file ag (Shapefile Area —
compared to sanctionedproject area (Ha. Sanctioned Area)
* Impact Evaluation
The MEL&D agency has to carry out impact assessment to establish the net impact of
the project in terms of the identified indicators at different levels. Data have to be collected on
