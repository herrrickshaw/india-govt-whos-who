---
doc_id: "3fb77eabd9bd7ff6"
source_url: "https://cohsem.nic.in/GENERAL_GUIDELINES_FOR_ALLOTMENT_OF_20_MARKS_INTERNAL_ASSESSMENT.pdf"
ministry: "Council of Higher Secondary Education, Manipur"
title: "Guidelines for Internal Assessment"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8232d07d6d215707"
---

<!-- page 1 -->

Guidelines of Internal Assessment (20 marks) for non-practical subjects
In the Higher Secondary Examination (Class-XII) and Class-XI Examination, the 20 marks
allotted for Internal Assessment are generally awarded through a combination of periodic assessments
and subject-related activities/project work. The exact distribution may vary subject to subject, for which
a common mechanism is given below:
Component
Marks
Periodic Tests (Average of best 2 (two) out of 3 (three) tests conducted) 10 Marks
Activities/Project Work
10 Marks
Total
20 Marks
Mechanism for Awarding Internal Assessment Marks.
1.

Periodic Tests (10 Marks)
There are three periodic tests to be conducted by the institutions in the form of pen-paper test and
carrying maximum of 20 marks each.
Average mark of best 2 (two) out of 3 (three) tests shall be noted as A and mark awarded out of
𝑨

𝑨

𝟏𝟎 = 𝟐𝟎 × 𝟏𝟎 = 𝟐 = M1.
2.

Activities/Project Work (10 Marks)
The Project Work/Activities carrying 10 marks and its distribution of marks for different subcomponents may vary from subject to subject. Marks awarded out of 10 (ten) in this
Project/Activities is M2.

3.

Total Internal Assessment marks secured by the student = M1+M2.

4.

Timeline/Schedule for Assessment.
Activities

Month

Periodic Test - 1
Periodic Test - 2
Periodic Test – 3
Project Work/Subject Activities

Up to last day of July
Up to 10th (ten) September
Up to last day of October
November - December
Total:

Maximum
Marks

5.

Reporting/Submission.

*

Marks of Periodic Test: on or before 10th November.

*

Test Marks out of Internal Assessment 20 marks: on or before 10th January.

10
10
20

General Guidelines
Internal Assessment should be conducted continuously throughout the academic year.
Schools are required to maintain proper records and documentary evidence of assessments of
each and every student.
Marks should be awarded objectively and fairly bases on the student’s performance.
The Internal Assessment marks are to be uploaded by the school as per the timeline of the
CoHSEM.
