---
doc_id: "05ba6926db9cfafb"
source_url: "https://manipureducation.gov.in/wp-content/uploads/2024/11/Adobe-Scan-31-Oct-2024.pdf"
ministry: "Education (School) Department, Manipur"
title: "Office Memorandum"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5db869eb2bac6c57"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
SECRETARIAT: FINANCE DEPARTMENT
(Directorate of Management Information System)
OFFICE MEMORANDUM
Imphal, the 31 st October, 2024

No. MIS-308/ 1/ 2022-e-FD : The matter regarding the procedure for submitting proposal
for CMIS updation has been considered and it has come to the notice of this Directorate that
a uniform method is required to be followed by the line departments in term of the necessary
relevant documents to be uploaded in CMIS software while submitting the proposal. It has
also been observed that there are no extant orders/instructions for the above.
2.

In view of the above, the following procedure and required documents are hereby issued
to all the department: 1.
The proposal shall be submitted online through CMIS software.
ii.
A Checklist of necessary required documents to be uploaded while submitting
the proposal is listed in Annexure.
iii.
The documents should be legible and free from overwriting and tampering.
iv.
In case of any doubt on the documents uploaded, original documents will be called
when and required.
v.
The above instructions shall come with immediate effect
This is issued with approval from the competent authority.

3---tt

~

(Dr. Sonia Oi arh)
Director (MIS)
Finance Department, Manipur

Copy to:
1.
2.
3.
4.

The Secretary to the Governor of Manipur.
The Secretary to the Chief Minister, Manipur.
The staff Officer to the Chief Secretary, Government of Manipur.
All Administrative Secretaries, Government of Manipur.

5. All Head of Departments, -Manipur.
"
I d
. The Technical Director (CMIS), NIC, Manipur. - ,or up oa ing in CMIS portal.
6
. The Website Manager, DIT, Govt. of Manipur. - for kind uploading in
7
www.manipur.gov.in.

<!-- page 2 -->

ANNEXURE TO O.M. No. MIS-308/1/2022-e-FD{Pt Il dated 315t October, 2024

CHECKLIST OF DOCUMENTS REQUIRED FOR CMIS UPDATIONS
SI.
No.

1

Type of updation

Documents need to be uploaded

New Recruits (Allotment of EIN):
(a) Direct Recruit

(b) Die-in-harness

(c) Regularization/
Absorption

2

Promotion/ Promotion
with Transfer

3

Correction of employee
details

4

Sanctioned Post
Updation (Addition/
Edition)

(i) Recruitment notification/ advertisement
(ii) Appointment Order
(iii) Posting order
(iv) Joining Report
(v)Matriculation Certificate from an Education Board
recognized by Ministry of Human Resource Development
(MHRD), Gol.
(i) Appointment Order
(ii) Government Convey Letter for appointment
(iii) Posting order
(iv) Joining Report
(v) Matriculation Certificate from an Education Board
recognized by Ministry of Human Resource Development
(MHRD), Gol.
(i) Recruitment notification/ initial engagement document.
(ii) Appointment/regularization Order
(iii) Posting order
(iv) Joining Report
(v) Matriculation Certificate from an Education Board
recognized by Ministry of Human Resource Development
(MHRD), GoI.
(i) Promotion Order
(ii) Joining Report/ TR-1 copy with counter signature of
reporting officer (for promotion)
(iii) Posting Order (indicating previous posting & present
posting)
(iv) Joining Report/ TR-1 copy with counter signature of
reporting officer (for posting)
(i)Speaking Order issued by the concerned Administrative
Department
(ii) Appointment Order
(iii) Copy of Service Book/ Service Card (first 2 pages
reflecting personal details & service joining entries)
(iv) Matriculation Certificate or VIII certificate as the case
may be or certificate from the recognized school last
attended
(i) Post Creation Order
(ii) Post extension order (if the validity of the above post is
expired)
(iii) Post deployment/allocation order (name of Office under
the Department) (in case of new creation)

<!-- page 3 -->

ANNEXURE TO O.M. No. MIS-308/1/2022-e-FD(Pt D dated 31st October, 2024

5

Office Creation in CMIS
database

(i) Office Creation Order (with approval from competent
authority)
(ii) ODO Code allocation & ODO designation order by
Accounts.
&
Treasuries
of
Directorate
details.
(iii) Relevant Head of Account

(i) Post Re-allocation order
Sanctioned Post Re(with approval of Cabinet & concurrence from FD(PIC)
allocation
(from one office to
another)
(i) Re-designation order with concurrence from FD(PIC)
7 Sanctioned Post Redesignation/ Sanctioned indicating
the sanctioned post details (if only the post is to be rePost Re-designation
designated)
along with incumbents
(ii) Re-designation order along with incumbent of the post
with concurrence from FD(PIC) indicating the sanctioned
post details (if post as well as the incumbent of the post is
to be re-desiqnated)
(i) Sanctioned Post upgradation order with concurrence
8 Sanctioned Post
from FD(PIC) after obtaining the approval of Cabinet
Upgradation/
indicating the sanctioned post details (if only the post is to
Sanctioned Post
Upgradation along with be upgraded)
(ii) Sanctioned Post upgradation order along with
incumbents
incumbent of the post with concurrence from FD(PIC) after
obtaining the approval of Cabinet indicating the sanctioned
post details (if post as well as the incumbent of the post is
to be upqraded)
9 Re-instatement of
(i) Service re-instatement order
Service
(ii) Termination/suspension order.
(iii) Court directives (if any)

6
