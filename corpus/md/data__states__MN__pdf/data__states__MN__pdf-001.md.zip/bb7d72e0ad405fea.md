---
doc_id: "bb7d72e0ad405fea"
source_url: "https://cdn.s3waas.gov.in/s3c3c59e5f8b3e9753913f4d435b53c308/uploads/2023/11/2023111063.pdf"
ministry: "Chandel"
title: "Corrigendum OSC contractual staffs interview"
date: ""
pages: 1
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "401c9e052e9171c0"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
. OFFICE OF THE DEPUTY COMMISSIONER
CHANDEL DISTRICT
CORRIGENDUM
| Chandel, the 8" of November, 2023
| No. DC (CDL)/5/24(OSC)/2019: The date of interview for engagement of contractual Staffs for One
Stop Centre, Chandel vide notification No. DC (CDL)/5/24(OSC)/2019 dated 31% October, 2023 stands
amended as follows:
|
| Dates for issue of application form (The prescribed application form will| a
be available from the office of ADP Cell, Mini Secretariat, Chandel during | 31/10/2023 to 09/11/2023
Office hour).
Last date and time for receipt of applications form 10/11/2023 (5:00 PM)
| Date of interview 16/11/2023 (10:00 AM)
All other conditions in the advertisement notification remains unchanged.
7 এ 7
(Mayanglambam Rajkumar)
Deputy Commissioner, Chandel
Deputy Commissioner
Chandel
Copy to:
1. Guard file.
