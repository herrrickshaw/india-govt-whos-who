---
doc_id: "dcbeb302bbf66afa"
source_url: "https://gadmanipur.nic.in/media/xhchp0jv/nit-stationery-e-tender-3.pdf"
ministry: "General Administration Department, Manipur"
title: "NIT - Stationery e-tende"
date: ""
pages: 31
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "a68afac9639b78c7"
---

<!-- page 1 -->

Tender No. Str-206/2/2023-GAD-GAD-Part (1)
TENDER DOCUMENT
FOR
PROCUREMENT OF STATIONERY ITEMS TO MANIPUR SECRETARIAT ON
ANNUAL RATE CONTRACT BASIS FOR A PERIOD OF 1 YEAR
INDEX
TENDER DOCUMENT
FOR
PROCUREMENT OF STATIONERY ITEMS TO MANIPUR SECRETARIAT ON
ANNUAL RATE CONTRACT BASIS FOR A PERIOD OF 1 YEAR
INDEX
Sino. Subd
Notice Inviting Tender 5 2
2 | Instructions to the Bidders iE
Terms and Conditions 10
[ 4 _| Annexure :
|__1__| List of Stationery Items (Annexure I-A, I-B, I-C, I-D & I-E) 13-15
IL Technical Bids 16-17
(Documents/certificates to be submitted with the bid)
| = Mil: Price Bids (Schedule of Rates) “18-23
|. Price Bid Undertaking 24
৯ Tender Accepting Letter 2 ‘i ae 3 = 25 রি
VI Declaration Letter reg. blacklisting 26
Letter of authorization for attending the bid opening 2 a
VII Specimen Performance Security Bond 28-29
Specimen Agreement for signing contract : ~ 30-31
aS
~
h of
ae)
Page 1 of 31

<!-- page 2 -->

GOVERNMENT OF MANIPUR
STATIONERY DEPARTMENT
NOTICE INVITING TENDER
Imphal, the 4" April, 2025
Str-206/2/2023-GAD-GAD-Part(1): The undersigned, on behalf of the General Administration
Department, invites online tenders under a two-bid system—technical bid and financial bid—from
authorized distributors, dealers, or reputed suppliers located in the Imphal area for the supply of various
stationery items to the Manipur Secretariat on an Annual Rate Contract(ARC) basis (extendable for an
additional period of 1 (one) year upon satisfactory work report) with mutual consent of both parties.
The detail Tender Documents (Non-Transferable) including List of items can be downloaded from the
website www.manipurtenders.gov.in. The Tender documents shall be submitted on the date specified
given below:
Important Dates
Downloading of Tender Document 7 10-04-2025 রা
Last Date of seeking clarification | 17-04-2025 _ z :
Physical Submission of EMD & Tender Fee | 21-04-2025 from 11:00 AM to 3:00 PM
Last Date of uploading of Tender 28-04-2025 upto 3:00 PM
Date of Opening of Technical Bid | 29/04/2025 at 11:00 AM 7
‘ vay! shall be decided by the Tender
Date of Opening of Price Bid Committee
ip" is
০
a
(Ase ingina Chanu)
eputy Secretary
General Administration Department
Government of Manipur
Copy to: -
1. Staff Officer to Chief Secretary, Government of Manipur.
2. APS to Secretary (GAD/STY), Government of Manipur.
3. SIO, NIC Manipur State Unit for kind technical support & uploading e-tender documents in
https://manipurtenders.gov.in.
4. The Director (DIPR), Manipur for publication in 2(two) local dailies for 2(two) days consecutively
& submit the bills accordingly. The copy may also be displayed on DIPR Notice Board also.
5. Director/IT for uploading in Manipur Government website
6. The Editor, Poknapham(Manipur Editor)/Sangai Express(English Editor) for publication in their
local dailies for 2(two) consecutive days.
7. Notice Board (North & South) Block, Manipur Secretariat.
8. Guard file.
Page 2 of 31

<!-- page 3 -->

GOVERNMENT OF MANIPUR
STATIONERY DEPARTMENT
Str-206/2/2023-GAD-GAD-Part(1): Imphal, 4° April,2025
INVITATION FOR BI!

Quotations are invited from the Authorized distributors/dealers/reputed supplier located at Imphal area

for supply of the following Stationery Items.:

টা: ৯৭ ye Se]

1 tems for use at the Directorate of Printing & Stationery, Babupara Annexure-I-A and
Annexure -I-B
2 {Items for use in Manipur Secretariat including Chief Minister’s\Annexure -I-C, Annexure|
ecretariat___ ১১৯৮ 17179 and Annexure-I-E
ps Bid Submission:

Bids are to be submitted online through —e-procurement/Tender _ portal
https://manipurtenders.gov.in , Bids must be submitted online before the stipulated time. The e-tender
is a two-bid system and both the technical bid and the financial bid must be submitted through online
only and in no case, the bid must be submitted in hard copies. Financial bid will be opened for the
technically responsive bidders only. GAD/STY will not take any responsibility for the delay caused due
to non-availability of internet connection or network traffic jam for online bids.

Downloading of Tender Document 10-04-2025 ap

Last Date of seeking clarification 17-04-2025

Physical Submission of EMD & Tender Fee | 21-04-2025 from 11:00 AM to 3:00 PM

Last Date of uploading of Tender — 28-04-2025 upto 3:00 PM

Date of Opening of Technical Bid | 29/04/2025 at 11:00 AM

রী shall be decided by the Tender

Date of Opening of Price Bid __| Committee

A. Bid documents may be scanned with 100 dpi with black and white option which helps
in reducing size of the scanned document.

B. The details of the items and their specifications to be procured are provided in
Annexures I-A, I-B, I-C, I-D, and I-E. Bids for each Annexure/category of items will be
evaluated and awarded separately.

C. The tender for each Annexure will be awarded to a single firm. To be eligible for
consideration, a bidder must submit bids for all items listed in an Annexure. Failure to
quote for any item within an Annexure will render the bid unresponsive and liable for
rejection.

D. The bidder should bid at the rates below the Maximum Retail Price (MRP) in the
Prevailing year. Price quoted in excess of MRP in the prevailing year will be summarily
rejected.

3. No tender fee is required to be paid at the time of submission of bids.

4. Bid must be accompanied by EARNEST MONEY DEPOSIT of an amount of Rs. 60,000/-
(Rupees Sixty thousand Only) in the form of Banker's cheque/Demand Draft drawn in favor of
‘Deputy Secretary (GAD/STY), Government of Manipur.

no”
4
Page 3 of 31 H\°
৩,

<!-- page 4 -->

5. In case, if the Tenderer is found to be tempered/modified in any manner, tender will be
completely rejected and EMD would be forfeited and tenderer is liable to be blacklisted from doing
business with Manipur Secretariat.

6. Intending tenderers are advice to visit to tender website www.manipurtenders.gov.in regularly
till closing date of submission of tender for any corrigendum/addendum/amendment.

7. Bidder is further required to submit the 1(One) no. of each of the items, as sample, for which the
rates have been quoted on or before opening of the tender, or otherwise the bids will be rejected.

8. Bids will be opened as per date/time as mentioned in the “Important Dates”. After opening
of Technical-Bid the results of their qualification as well Price- Bid opening will be intimated later.
SUBMISSION OF TENDER

9. The tender shall be submitted online in two parts, viz., technical bid and financial bid.

10. All the pages of bid being submitted must be signed and sequentially numbered by the bidder
irrespective of nature of content of the documents before uploading.

11. The offers submitted by email shall not be considered. No correspondence will be entertained in
this matter.

TECHIN: D

12.The following documents are to be uploaded by the bidder along with Technical Bid as per

the tender document:

i. Bid must be accompanied by EARNEST MONEY DEPOSIT of an amount of Rs. 60,000/-
(Rupees Sixty thousand Only) in the form of Banker’s cheque/Demand Draft drawn in favor of
‘Deputy Secretary (GAD/STY), Government of Manipur.

li, Signed 010 scanned copy of proof for payment of Earnest Money Deposit;

ili, Signed and scanned copy of Registration certificate as per existing norms (indicating the legal
status—company/partnership firm/proprietorship concern, etc.);

iv. Signed and scanned copy of GST/TIN, GST clearance Certificate and Professional Tax Payment
receipt issued by the Department of Taxes, Manipur and PAN Card Registration Certificates;

v. Signed and scanned copy of Income Tax Returns filed for the last three financial years;

vi. Signed and scanned copy of Audited Profit & Loss Account Statements for the last three financial
years;

vii. Signed and scanned copy of proof of experience of supplying the quoted items in bulk to the
Government Departments /PSUs/Autonomous Bodies (copies of two Purchase Orders issued
during each of the last two years to be attached);

viii. Signed and scanned copy of the authorization from manufacturer against this Tender valid
throughout the period of the contract, in case the firm (s) is authorized dealer of the items;

ix. Signed and scanned copies of Price Bid Undertaking (Annexure-IV), Tender Accepting letter
(Annexure-V), Declaration regarding blacklisting or otherwise. (Annexure-VI) and Letter of
authorization for attending the bid opening (Annexure-VII),

SUBMISSION OF SAMPLES FOR VERIFICATION:

13. Bidders shall submit samples of the quoted stationery items in a sealed packet as a non-

refundable submission.

a. The samples will be verified for visual and physical quality by the Tender Evaluation
Committee or any committee constituted by the Tender Inviting Authority. The verified
samples shall be preserved in a sealed packet as the Master Sample for comparison with
the supplied items by the successful bidder. The list of items requiring sample submission
is provided in Annexures-I-A, I-B, I-C, I-D and I-E.

ss
no
4
Page 4 of 31 ] ৩
Od

<!-- page 5 -->

b. Samples may be sent through courier or submitted in person to the authorized officer
designated by the Tender Inviting Authority. A proper acknowledgment slip shall be issued
upon receipt of the samples. The samples must reach the Office of the Tender Inviting
Authority within five (5) working days from the opening and evaluation of the technical bid,
before 4:00 PM.

c. No claim for payment shall be entertained by the Tender Inviting Authority for the
verification, or evaluation of samples, including any usage during the assessment process.
The samples submitted by the lowest responsive bidder after price comparison shall be
retained by the Tender Inviting Authority as the Master Sample, even if not utilized during
evaluation.

d. The Tender Inviting Authority reserves the right to inspect, test, and, if necessary, reject
the supplied goods at the final delivery location, regardless of prior approval during sample
verification. The acceptance of samples does not waive the authority's right to assess
compliance upon final supply.

FINANCIAL BID
i) The e-tender follows a two-bid system, where the financial bid must be submitted online
only. Under no circumstances should the financial bid be submitted in hard copies. Only
technically responsive bidders will have their financial bids opened.
ii) The price bid must be submitted in the prescribed format:
"V3_BOQ_ItemWise_Template.xis".
iii) The quoted unit price shall be the landed cost at the destination (Secretariat at
Babupara/Mantripukhri, Imphal), inclusive of all charges, such as packing, forwarding,
taxes/duties, freight, loading, and unloading.
iv) All quoted prices must be inclusive of all applicable taxes, including GST.
v)The bidder should bid at the rates below the Maximum Retail Price (MRP) in the prevailing
year. Price quoted in excess of MRP in the prevailing year will be summarily rejected.
vi) The tender for each annexure will be awarded to a single firm. To qualify, a bidder must
submit bids for all items listed in the annexure they are bidding for (Annexure-I-A, Annexure-
I-B, Annexure-I-C, Annexure-I-D, or Annexure-I-E). Failure to quote for any item within the
selected annexure will render the bid non-responsive and liable for rejection for that
annexure.
vil) The lowest bidder (L1) for an annexure will be determined based on the sum of all item
costs quoted per unit/package in that annexure. The evaluation will be conducted based on
the combined grand total of all items in the annexure.
INSTRUCTIONS TO THE BIDDERS
1, Definitions: -
i) ‘The Purchaser’ means the General Administration Department/Sty.
ii) ‘The Bidder’ means the individual or firm who participates in this tender and =
submits bid. ws
৮7টি
Page 5 of 31 , \e ঠা
১67

<!-- page 6 -->

iii) ‘The supplier’ means the individual or firm supplying the goods under the
contract.
iv) ‘The contract price’ means the price payable to the supplier under the
purchase order for 01 full and proper performance of its contractual
obligation.
2. Bid Document
i. Instructions to the bidder
ii, Terms and conditions of the tender
ili. Technical Bid Format .
iv. Financial/Price bid Format (Price Schedule)
2.2 The bidder(s) is/are expected to examine all instructions, terms and conditions contained in
the bid document. Failure to furnish all information required as per the bid document or submission
of bid not substantially responsive to the bid document in every respect will be at the bidder's risk
and may result in rejection of the bid.
3. Minimum Eligibility Criteri:
Bidders should: -
i be an Indian company.

ii, be an authorized dealer/reputed supplier.

iii, have minimum two years of experience of supplying the quoted item in bulk to the
Government Departments (Copies of two Purchase Orders received from Govt. Deptts. /
PSUs/Autonomous Bodies during each of the last two years should be enclosed).

iv. have minimum Turnover of Rs. 15 lakh per year in preceding two financial years (valid and
Certified proof has to be enclosed).

v. mot have been blacklisted by the Government Departments/PSUs/Autonomous Bodies
(Declaration has to be submitted in the prescribed format — Annexure-VII).

The Financial/Price Bids for the bidder whose Technical Bids are complete and conform to

the eligibility criteria, shall be opened.
রঃ Documents/Certificates:

The bidders are required to upload the following documents along with Technical Bid in pdf format
(Documents in original should be produced for verification before signing of the agreement), failing
which their bids will be summarily/out-rightly rejected and will not be considered any further:

a. Registration certificate as per existing norms (indicating the legal status—
company/partnership firm/proprietorship concern, etc.);

b. Copy of GST Registration Certificates;

c. Copy of PAN Card Registration Certificates;

d. Copy of Income Tax Returns filed for the last three financial years;

e. Copies of Audited Profit & Loss Account Statements for the last three financial years;

f. The bid and all correspondence and documents shall be in the English language.

g. Copy of proof of experience of supplying the quoted items in bulk to the Government
Departments /PSUs/Autonomous Bodies (copies of two Purchase Orders issued during
each of the last two years to be attached);

h, Price Bid Undertaking (Annexure-IV), Tender Accepting letter (Annexure-V),
Declaration regarding blacklisting or otherwise. (Annexure-VI) and Letter of
authorization for attending the bid opening (Annexure-VII)

Se
Page 6 of 31 44 np
t
৮1৩1
6%

<!-- page 7 -->

Se Bid Security/Earnest Money Deposit (EMD)

Earnest Money Deposit (EMD) of Rs.60,000/- (Rupees sixty thousand five) must be deposited by
bidders in the form of Banker’s cheque/Demand Draft drawn in favour of ‘Deputy Secretary (GAD/Sty),
Manipur Secretariat, South Block, Babupara, Imphal on or before the opening of tender. The Purchaser
will not take any responsibility for delay or non-receipt.

52 The scanned copy of draft/Banker’s cheque of EMD must be uploaded along with
Technical Bid.
Dd: EMD shall remain valid for a period of 60 days beyond the final validity period of bids (120
days) from the date of opening of the bids.
০১০ No request for transfer of any previous deposit of earnest money or security deposit or payment
of any pending bill held by the Department in respect of any previous job/supply will be entertained.
5.5. Bid received without Bid security (EMD) shall be rejected as non-responsive.
5.6. EMD for lesser amount / EMD not submitted in the manner prescribed will be rejected and
returned to the bidder.
5.7. The submission of EMD is compulsory for all the Bidders and no exemption will be granted for
submission of EMD in any case. The Bid security of the unsuccessful bidder will be returned to them
within 30 days after finalization and award of the contract without any interest. The bid security may
be forfeited.
a. If a bidder withdraws his bid during the period of bid validity specified in the bid
document;
b. In the case of successful bidder, if the bidder fails to sign the contract & furnish the
performance security within the time specified in the document
6. Clarification on Bid document
In case the prospective bidders need any clarification regarding any terms and
conditions of the tender, he/she/they may seek clarification on or before the time indicated in the
“Important Dates”.
7. Amendment of Bid document
At any time prior to ‘Bid Submission Start Date’ indicated in “Important Dates”, the purchaser
may for any reason whether as its own initiative or in response to a clarification requested by the
prospective bidder, modify the bid documents by amendment.
8. Rejection of incomplete and conditional tenders
The incomplete and conditional tenders will be rejected. Quoting unrealistic rates will
be treated as disqualification.
9. Non transferability
This tender is non transferable.
10. Documents comprising the bid: -
The bids shall comprise of (i) technical bid and (ii) the financial bid:
ny aS
Page 7 of 31 Ow ৮০
of
ot

<!-- page 8 -->

in The documents / information sought should be in the same serial order as given in the
technical bid format.
ii. The financial bid shall specify the rates / prices in the format shown in the financial bid/price
schedule
11. Bid Prices:
The rates should be quoted in Indian Rupees only in words as well as figures. GST as applicable should
be quoted separately. Only one price should be quoted for the item and if more than one price is quoted
under different options the rate quoted by him in the first option only will be valid and considered for
evaluation. Rates/Price prices should be valid for one year from the date of signing of the agreement.
Rates/Prices shall remain fixed during the entire period of contract, i.e., one year. No claim for
compensation or loss due to fluctuations or any other reasons/causes will be entertained. A bid with
an adjustable price quotation will be treated as non responsive and will be rejected. The bidder should
bid at the rates below the Maximum Retail Price (MRP) in the prevailing year. Price quoted in excess of
MRP in the prevailing year will be summarily rejected.
12. Signing of the bids
The required documents for the tender should be properly paged and indexed and the
requisite information should be highlighted also.
13. Deadline for submission of bids Z
Bids must be submitted on or before the prescribed date and time mentioned in the Important
Date of Notice Inviting Tender (NIT).
14. Bid Opening:

On the date and time indicated in the ‘Important Dates” of Notice Inviting Tender (NIT) bids will
be opened in the Room of Deputy Secretary(GAD/Sty), South Block, Manipur Secretariat,
Babupara, Imphal — 795001 in the presence of the bidders or their representatives duly authorized
by the bidder who wish to be present. The representatives are required to bring photo identity card
issued by the firm / employer and also a copy of the authorization as given in the ‘Annexure-VIII’.
15, Process to be confidential

A. After the public opening of bids, information relating to the examination, clarification,
evaluation and comparisons of bids and recommendations concerning the award of contract
shall not be disclosed to bidders or other persons not officially concerned with such process.

B. Any effort by the bidder to influence the Purchaser in the process of examination, clarification,
evaluation and comparison of bids and decision concerning award of contract may result in the
rejection of the bidder's bid.

16. Clarification of Bids
To assist in the examination, evaluation and comparison of bids, the Purchaser may ask the
bidders individually for clarification of their tenders.
The request for clarification and their response shall be through www.manipurtenders.gov.in but no
change in the price or substance of the tender shall be sought, offered or permitted except as required
Page 8 of 31 রর
না v
ae ) ৮৫
(১৫!
ok
ha

<!-- page 9 -->

to confirm the correction of arithmetical errors discovered by the Purchaser during the evaluation of
the tenders. The bidder shall promptly provide all necessary information and documents to be submitted
to the Purchaser during evaluation of its tender.

17. Technical evaluation

The Purchaser shall carry out the evaluation solely based on the uploaded certificates/documents in
the www.manipurtenders.gov.in.

17.1. The competent authority shall examine/ evaluate the technical bids to determine whether they
(i) fulfill the eligibility criteria, (iii) submitted the requisite documents (iii) meet the terms and conditions
specified, (iv) complied with all the instructions contained therein, etc. For the purpose of this clause
a substantially responsive bid is one which conforms to all the terms and conditions of the
bid document without deviation or reservation. Prior to financial evaluation, the Purchaser will
determine the substantial responsiveness of each bid to the bid document.

18. Financial evaluation and comparison of substantially technically responsive bids
The Purchaser shall carry out the evaluation solely based on the uploaded schedule of rates (price
bids) in the www.manipurtenders. gov.in.

18.2. The financial bids of technically qualified bidders only will be recommended for opening and
consideration by the Competent Committee/Purchase Committee/Authority. The said Committee will
evaluate the bids to determine whether (i) they are complete; (ii) the requisite bid securities have been
furnished; (iii) the bids have been properly signed and stamped; (iv) the bids are generally in order,
etc,

18.3. The purchaser shall shortlist those who are eligible and submitted substantially
technical responsive bids for opening of financial bid. The names of the successful bidders will be
displayed on the portal of www.manipurtenders.gov.in. Such successful bidders may like to attend the
financial bid opening.

18.4. The date, time and venue of the financial bid opening will be uploaded on the website
www.manipurtenders.gov.in. The financial bids of unsuccessful bidders would not be opened.
19. Award of Contract
The contract shall be awarded with the approval of the competent authority to the bidder whose bid
has been determined to be eligible and to be substantially responsive to the bid documents and who
has offered the lowest evaluated bid subject to internal user feedback on the suitability.
20. Right to accept/reject any or all Bids:
The Purchaser reserves the right to accept or reject any bid including the lowest and to annul the
bidding process and reject all bids, at any time prior to award of contract, without thereby incurring
any liability to the affected bidder or bidders or any obligations to inform the affected bidder or bidders
of the grounds for the said action.
21. Signing of Agreement
Upon the receipt of the notification of award by the successful bidder, the successful bidder shall
fill the Agreement in accordance with form of Agreement included in the Bid Document within a
week of the date of receipt of notification of award.
22. Annulment of the Award
Ww
রী দা
/101
Colt
Page 9 of 31

<!-- page 10 -->

Failure of the successful bidder to comply with any of the requirements shall constitute sufficient ground
for the annulment of award and forfeiture of the bid security in which event the Purchaser may make
the award to any other bidder at the discretion of the Purchaser or call for new bids.

Purchaser reserves the right to disqualify the supplier for a suitable period who fails to supply
the item in time. Further, the suppliers whose items do not perform satisfactorily or the quality of which
is not satisfactory may also be disqualified for a suitable Period as decided by the Purchaser. Purchaser
reserves the right to blacklist a bidder for a suitable Period in case he fails to honor his bid without
sufficient grounds

TERMS & CONDITIONS
us Application
The general conditions shall apply in contracts made by the Purchaser for the procurement of Goods
2. Standards
The goods supplied under this contract shall conform to the standards prescribed specifications
mentioned there against the goods in the financial bid.
The bidder should furnish the full specification of the goods offered in the tender. No change shall be
permitted after opening of bids.
3. Performance Security Deposit (PSD)

3.1. Successful bidders have to deposit PSD @ 5% of annual contract value within 7 days

of notification of the award of contract.

3.2. PSD shall be in the form of (i) Demand Draft in favour of Deputy Secretary (GAD/Sty),

Government of Manipur. In case PSD is in the form of bank guarantee and should be froma

nationalized/scheduled bank and in the form provided in the Annexure-VIII.

3.3. PSD shall be in the form of (i) Demand Draft in favour of Deputy Secretary (GAD/Sty),
Government of Manipur. In case PSD is in the form of bank guarantee and should be from a
nationalized bank having a branch in Imphal and in the form provided in the Annexure-VIII.

3.4. PSD should remain valid for a Period of sixty days beyond the date of completion of all
contractual obligations by the supplier including warranty obligation, if any. EMD will be refunded to
the successful bidder on receipt of performance security.

3.5. PSD can be withheld or forfeited in full or in part in case the supply order is not executed
satisfactorily within the stipulated Period or for supply of goods of inferior quality, size, design or not
confirming to samples/specifications of quoted item.

4. Liquidated damages:
If the supplier fails to deliver the items or any consignment thereof within the period
Prescribed for delivery, the purchaser shall be entitled to recover 0.5% of the value of the delayed
supply with reference to the delivery date given in the Purchase Order up to 7 days and thereafter
at the rate of one percent (1.0%) of the value of the delayed supply for each week of delay or part
thereof.
WS
aes
Page 10 of 31 i {°
<0
