---
doc_id: "80f6ac4abbd3da29"
source_url: "https://familywelfare.in/uploads/media/2023/12/18/m1702895926.pdf"
ministry: "Family Welfare Department, Manipur"
title: "Hand Book on PC-PNDT Act & Rules"
date: ""
pages: 144
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2844813eea54b502"
---

<!-- page 1 -->

<!-- page 2 -->

Handbook on

Pre- Conception & Pre- Natal
Diagnostic Techniques Act, 1994
and Rules with Amendments

Ministry of Health and Family Welfare
Government of India
2006

<!-- page 3 -->

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

CONTENTS
Chapter

Pages

Foreword
I-

Introduction

1

II -

Definitions
Techniques
Places
Qualified Persons

4
4
5
6

III -

Registration
Procedure for Registration
Minimum Requirements for Registration
Process of Certification
Rejection of Application for Registration
Cancellation or Suspension of Registration
Provision for Appeal
Renewal of Registration
Rejection of Application for Renewal

9
9
10
12
13
14
14
15
16

IV - Prohibitions
Prohibitions
A) On places
B) On persons
C) Miscellaneous
Prescriptions and Regulations
Penalties
A) Offence by persons
B) Offence by a company

17
17
17
18
20
21
25
25
26

V-

Instrumentalities for Implementing the Act
Policy Making Body
Implementing Authorities

29
29
33

VI - Maintenance and Preservation of Records

36

VII - Search and Seizure
Search and Witnesses
Seizure and Preparation of List
Sealing
Collection of Evidence

38
39
39
40
41

<!-- page 7 -->

Annexures

Pages

I-

Form I Under The MTP Regulations

44

II -

Form C under the MTP Act

46

III - Form II Under The MTP Act

47

IV - Form III Under The MTP Regulations

48

V-

49

Draft of the type of complaint that can be made to the Appropriate Authority

VI - Draft of show cause notice that can be made by Appropriate Authority

53

VII - Draft of Complaint that can be made by Appropriate Authority in the
Court of Chief Metropolitan Magistrate

54

VIII - Format of Reply to Anticipatory Bail Application

56

IX -

Format of the Quarterly Report Required to be submitted by the
Appropriate Authorities

59

Appendices
I-

II -

The Pre-natal Diagnostic Techniques
(Regulation and Prevention of Misuse) Act, 1994

63

The Pre-natal Diagnostic Techniques
(Regulation and Prevention of Misuse) Rules, 1996 and
Pre-conception and Pre-natal Diagnostic Techniques
(Prohibition of Sex Selection) Rules, 1996

81

III - The Pre-natal Diagnostic Techniques (Regulation And
Prevention of Misuse) (Advisory Committee) Rules, 1996
IV-

V-

109

Final Judgement and other orders of The Supreme Court of India in CEHAT Vs.
Union of India & others Writ Petition [Civil] No. 301 Of 2000

112

Clarification regarding mobile clinics etc.

134

<!-- page 8 -->

Chapter

I

INTRODUCTION

The social, cultural and religious fibre of India is pre-dominantly patriarchal contributing extensively
to the secondary status to women. The patrilineal social structure based on the foundation that the
family line runs through a male, makes men a precious “commodity” that needs to be protected and
given a special status, Another important pillar of the patriarchal structure is marriage wherein women
are given a subordinate status, having no say in the running of their lives or any control over their
bodies or bodily integrity. Marriage is also considered as a process whereby the burden of the father is
passed on to the husband for a very high price. The dowry or groom price is so staggeringly high
irrespective of the class structure, that generations may have to toil to repay the debts incurred during
marriage. All of this has contributed to a low social status for women in society, to such an extent that
even the birth of a girl child in a family is sought to be avoided.
A deleterious fall-out of the subjugated position of women is their vulnerability to violence like domestic violence, rape, sexual abuse, dowry harassment, trafficking etc, with little or no mechanisms for
combating the same, either by way of effective laws and implementation or civil society action. A
pernicious form of violence against women in some parts of India has been and still is the elimination of
the girl child or female infanticide. Various methods were used to eliminate the girl child after her birth
like starving her, crushing her under the bed or giving her poison etc. Pertinently, the responsibility for
killing the child was fixed on the woman/mother as she was considered responsible for bringing the
girl child into existence.
An examination of the causes for eliminating the girl child indicates that the reasons are similar and
different depending upon the geographical location in which female infanticide is practiced. Exorbitant dowry demand is one of the main reasons for female infanticide. Some of the other reasons are the
belief that it is only the son who can perform the last rites, that lineage and inheritance runs through
the male line, sons will look after parents in old age, men are the bread winners etc. Things have come
to such a pass that in some villages of Madhya Pradesh, no marriages have taken place for years
because there are no girls and the boys are married by buying girls from faraway villages of Bihar for
paltry sums. In one district in west Rajasthan, in 1997, the first “baraat” was received after 110 years
and in another clan, there are only two female children compared to 400 male children. In some cases
parents are prepared to accept the daughter if she happens to be the first child but thereafter they want
only sons.

1

<!-- page 9 -->

Strong male preference and the consequent elimination of the female child has continued to increase
rather than decline with the spread of education. This has been helped by the techniques of elimination
of the girl child becoming more scientific with progress in science and technology. Female infanticide
now in most places has been replaced by female foeticide and in fact sadly, female foeticide has made
inroads into areas where traditionally there were no instances of female infanticide. The moral guilt
attached to the elimination of the girl child after she is born is not felt equally if the child is eliminated
while still in the womb.
Female foeticide or sex selective abortion is the elimination of the female foetus in the womb itself.
However, prior to the elimination, the sex of the foetus has to be determined and it is done by methods
like amniocentesis, chorion villus biopsy and now by the most popular technique, ultrasonography.
Once the sex of the foetus is determined, if it is a female foetus, it is ofthen aborted. Apart from the
technique and timing varying between female infanticide and female foeticide, for female foeticide the
assistance of a third party namely a medical practitioner, is required to determine the sex of the foetus.
This intervention could have been a great deterrent in effectively countering female foeticide. Instead
the continuous demand and easy money has lead to medical practitioners colluding with parents and
relatives in doing sex determination tests. As a consequence sex determination centres have mushroomed in all parts of the country including small districts and villages. Medical practitioners have
overnight changed their discipline to fulfill the never-ending demand for sex determination. In many
cases, these centres are manned not by qualified doctors but only by technicians.
The increase in female foeticide has seen the proportionate decrease in female sex ratio which has hit
an all-time low especially in the 0-6 age group, and if this decline is not checked the very delicate
equilibrium of nature can be permanently destroyed. Moreover it is not only a problem of numbers. The
very status of women and the gains that have been made over the years are at stake. If there are fewer
women in society, the violence against women in all its forms would go up and the resultant atmosphere of insecurity would lead to women again being confined within the four walls of the home. The
girls would not be allowed to go out to study and women would not be allowed to take up jobs. A time
would come when woman would be married off to several men, the manifestations of which are
already visible in areas like Dang district of Rajasthan, where a woman is living as the wife of eight
brothers. Thus the issue of female foeticide is one that needs to be addressed urgently. While it is a social
problem requiring changing the mindset of people, yet all possible efforts need to be made at every
level. Here the law can be used as an effective tool to create fear in the minds of those who resort to sexdetermination tests or those who carry out such techniques.

Legal Initiatives
Female infanticide had been prohibited through legislation in the pre-independence period. However
the legislation sadly remained toothless with few or no convictions under the law. Certain provisions
were also included in the Indian Penal Code, 1860 punishing causing of miscarriage and other like
offences, but unfortunately these provisions were rarely resorted to.
With the rise of pre-natal diagnostic techniques especially amniocentesis, the government in 1978
issued a directive banning the misuse of amniocentesis in government hospitals/laboratories. Thereafter
due to the relentless efforts of activists, a law to prevent sex determination tests was passed in Maharashtra
known as the Maharashtra Regulation of Pre-natal Diagnostic Techniques Act, 1988. Finally after
2

PNDT Act, 1994 & Amendments

<!-- page 10 -->

intensive public debate all over India the Parliament enacted the Pre-Natal Diagnostic Techniques
(Regulation and Prevention of Misuse) Act on 20th September 1994 (hereinafter referred to as the PNDT
Act) to provide for the regulation of:
the use of pre-natal diagnostic techniques for the purpose of detecting genetic or metabolic disorders or chromosomal abnormalities or certain congenital mal-formations or sex-linked disorders;
for the prevention of the misuse of such techniques for the purpose of pre-natal sex determination
leading to female foeticide; and
for matters connected there with or incidental thereto.
This Act came into force in 1996. By itself it is a comprehensive piece of legislation which defines the
terms used therein, lays down when the use of pre-natal diagnostic techniques is prohibited and where
it is regulated. It has provisions for bodies which are responsible for policy making under the Act and
those which are responsible for the implementation of the Act. The penalties for various offences and
how and by whom cognizance of complaints is to be taken, are also elaborated upon.

Amendments to the Act of 1994
During the course of the implementation of the said Act, certain inadequacies and practical difficulties
in the administration of the Act came to the notice of the Government. At the same time techniques
have been developed to select the sex of the child before conception which may further the declining
sex-ratio. These developments were also taken note of by the Supreme Court in its various orders in
CEHAT & Ors. V. UOI & Ors. which is pending before the Court, and the Court had also observed that
amendments to the PNDT Act are necessary. After detailed deliberations, the PNDT Act has been
amended with the amended Act having come into force with effect from January 2003. The main
purpose has been to ban the use of sex-selection techniques before or after conception as well as the
misuse of pre-natal diagnostic techniques for sex selective abortions and to regulate such techniques.
To make this clear, the long title of the Act has been suitably amended to read:
“An Act to provide for the prohibition of sex selection, before or after conception, and for regulation of
pre-natal diagnostic techniques for the purposes of detecting abnormalities or metabolic disorders or
chromosomal abnormalities or certain congenital malformations or sex-linked disorders and for the
prevention of their misuse for sex determination leading to female foeticide and for matters connected
therewith or incidental thereto.”
The title of the Act has also been suitably amended to reflect this and the title of the Act is now to read:
“The Pre-conception and Pre-natal Diagnostic Techniques (Prohibition of Sex Selection) Act.”
At the same time certain amendments have also been brought about in the Rules of 1996 to ensure
effective implementation of the Act and in view of the observations of the Supreme Court. The amended
Rules have come into effect from 14th Feb,2003.
This handbook duly incorporates the amendments that have been made to the PNDT Act and the
Rules of 1996 framed thereunder. This compilation puts together a comprehensive set of guidelines
elaborating various provisions of the Act and the Rules and their implementation mechanism which
clarifies various issues on which the medical practitioners, implementing agencies and people at large
have varying interpretations of, to bring in convergence of opinion among all the stake-holders.
Note: The amended portion in this handbook have been underlined for the convenience of the readers.

Introduction

3

<!-- page 11 -->

Chapter

II

DEFINITIONS

Techniques
Pre-natal diagnostic techniques include all pre-natal diagnostic procedures and pre-natal diagnostic
tests.1
A. Pre-natal diagnostic procedures mean all gynaecological or obstetrical or medical procedures such as:
Ultrasonography;
Foetoscopy;
Taking or removing samples of:
Amniotic fluid
Chorionic villi
Blood
Any tissue
Fluid
of a man or a woman before or after conception for being sent to a Genetic Laboratory or Genetic Clinic
for conducting any type of analysis or pre-natal diagnostic tests for selection of sex before or after
conception. 2
B. Pre-natal diagnostic test means:
Ultrasonography
Test or analysis of:
Amniotic fluid
Chorionic villi
Blood

1

Section 2(j) of the Act.

2

Section 2(i) of the Act.

4

PNDT Act, 1994 & Amendments

<!-- page 12 -->

Any tissue
Fluid
of any pregnant woman or conceptus conducted to detect:
Genetic disorders
Metabolic disorders
Chromosomal abnormalities
Congenital anomalies
Haemoglobinopathies
Sex-linked diseases.3
C. Sex selection includes:
Procedure
Technique
Test
Administration
Prescription
Provision
of anything for the purpose of ensuring or increasing the probability that an embryo will be of a particular sex.4

Places
A. Genetic Counselling Centre means:
An institute
Hospital
Nursing home
Any place
by whatever name called which provides genetic counselling to patients.5
B. Genetic Clinic means:
A clinic
Institute
Hospital
3

Section 2(k) of the Act.

4

Section 2(o) of the Act.

5

Section 2(c) of the Act.

Definitions

5

<!-- page 13 -->

Nursing home
Any place
by whatever name called which is used for conducting pre-natal diagnostic procedures.6
By an amendment to the Act of 1994, an explanation has been added to clarify the position of a
‘vehicle’. It provides that for the purposes of this clause, a Genetic Clinic includes a vehicle, where
ultrasound machine or imaging machine or scanner or other equipment capable of determining sex of
the foetus or a portable equipment which has the potential for detection of sex during pregnancy or
selection of sex before conception, is used.
C. Genetic Laboratory means
A laboratory; and
Includes a place
where facilities are provided for conducting analysis or tests of samples received from Genetic Clinic
for pre-natal diagnostic test.7
An explanation has been added by the amendments of 2002. The explanation provides that “for the
purposes of this clause (definition of Genetic Laboratory), Genetic Laboratory includes a place where
ultrasound machine or imaging machine or scanner or other equipment capable of determining sex of
the foetus or a portable equipment which has the potential for detection of sex during pregnancy or
selection of sex before conception, is used.”
It has been clarified under the amended Rules that every Genetic Counselling Centre/ Genetic Laboratory/
Genetic Clinic would include an ultrasound centre/imaging centre/nursing home/hospital/institute or
any other place, by whatever name called, where any of the machines or equipments capable of selection of sex before or after conception performing or performing any procedure, technique or test for
pre-natal detection of sex of foetus is used.8

Qualified Persons
A. Gynaecologist means a person who possesses a post-graduate qualification in gynaecology and
obstetrics.9
The Rules10 framed under the Act further qualify the qualifications by providing additional requirements for a gynaecologist when employed by a genetic counselling centre or a genetic clinic but do not
necessitate the engagement of a gynaecologist by a genetic laboratory.
For a genetic counselling centre, the gynaecologist must have
6 months experience in genetic counselling ; or
4 weeks training in genetic counselling .11
6

Section 2(d) of the Act.
Section 2(e) of the Act.
8
Explanation (1) to Rule 12
9
Section 2(f) of the Act
10
The Pre-Natal Diagnostic Techniques (Regulation and Prevention of Misuse) Rules, 1996 which came into force w.e.f. 1.1.1996.
11
Rule 3 (1) (i) under the PNDT Rules
7

6

PNDT Act, 1994 & Amendments

<!-- page 14 -->

For a genetic clinic, the gynaecologist should have adequate experience in pre-natal diagnostic procedures
i.e. should have performed at least 20 procedures in chorionic villi aspirations per vagina or per abdomen, chorionic villi biopsy, amniocentesis, cordocentesis foetoscopy, foetal skin or organ biopsy or
foetal blood sampling etc. under supervision of an experienced gynaecologist in these fields.12
B. Medical Geneticist includes a person who possesses:
Degree, or
Diploma
in genetic science in the fields of sex selection and pre-natal diagnostic techniques
or has experience of not less than two years in any of these fields after obtainingAny one of the medical qualifications recognized under the Indian Medical Council Act, 1956; or
A post-graduate degree in biological sciences.13
Under the amended definition, possessing a certificate does not make one a qualified medical geneticist.
C. Paediatrician means a person who possesses a post-graduate qualification in paediatrics.14
The Rules framed under the Act further qualify the qualifications by providing additional requirements for a paediatrician when employed by a genetic counselling centre.
For a genetic counselling centre, the paediatrician must have
6 months experience in genetic counselling; or
4 weeks training in genetic counselling.15
D. Registered Medical Practitioner means
A medical practitioner who possesses any recognized medical qualification as defined in
clause (h) of Section 2 of the Indian Medical Council Act, 1956; and
Whose name has been entered in a State Medical Register.16
The Rules framed under the Act further qualify the qualifications by providing additional requirements for a registered medical practitioner when employed by a genetic clinic. For the purposes of a genetic
clinic the registered medical practition should have a post graduate degree or diploma or six months
training or one year experience in sonography or image scanning.17
Besides, the Act and the Rules also refer to other types of personnel.
E. For a genetic laboratory, there should be a laboratory technician

12

Rule 3 (3)(1)(a) under the PNDT Rules.

13

Section 2(g) of the Act.

14

Section 2(h) of the Act.

15

Rule 3(1)(i) under the PNDT Rules.

16

Section 2 (m) of the Act. In Prakash Motiram Khobragade v. State of Maharashtra AIR 2000 Bom. 137, the Bombay High Court has held
that persons who are otherwise not qualified for registration under the Medical Practitioner Act, under the Indian Medical Council Act and
the State Acts are not entitled to claim any right to practice medicine.

17

Rule 3 (3)(1)(b) under the PNDT Rules.

Definitions

7

<!-- page 15 -->

Having
B.Sc. degree in Biological Sciences; or
Degree or;
Diploma, in medical laboratory course; and
At least one year’s experience in conducting appropriate pre-natal diagnostic techniques, tests or
procedures. 18
F. Radiologist 19
G. Sonologist or Imaging Specialist means a person who possessesAny one of the medical qualifications recognized under the Indian Medical Council Act, 1956; or
A post-graduate qualification in ultrasonography or imaging techniques or radiology.20
Certain miscellaneous definitions have been added to clarify concepts used for the first time in the
amended Act. These are:(A) Conceptus means any product of conception at any stage of development from fertilization until
birth including extra embryonic membranes as well as the embryo or foetus.21
(B) Embryo means a developing human organism after fertilization till the end of eight weeks (fifty-six
days). 22
(C) Foetus means a human organism during the period of its development beginning on the fifty-seventh day following fertilization or creation (excluding any time in which its development has been
suspended) and ending at the birth.23

18

Rule 3 (1) and Schedule II under the PNDT Rules.

19

Rule 3(3)(1)(b) under the PNDT Rules.

20

Section 2(p) of the Act.

21

Section 2(ba) of the Act.

22

Section 2 (bb) of the Act.

23

Section 2 (bc) of the Act.

8

PNDT Act, 1994 & Amendments

<!-- page 16 -->

Chapter

III

REGISTRATION

All bodies under the PNDT Act namely Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic
as defined in the preceding chapters, cannot function unless registered.1
The requirement of registration is mandatory whether the body is government, private, voluntary,
honorary, part-time, contractual or consultative. However the PNDT Act allows registration of these
bodies either separately or jointly when a body is for instance both a centre and a clinic.

Procedure for Registration
A. Every application for registration shall be made:
To the Chief Medical Officer of the district; or any other medical officer constituted as an appropriate authority
Medical officer constituted as appropriate authority for the sub-district within whose area or
jurisdiction the centre, clinic or laboratory is situated.2
B. Every application shall be made in duplicate in Form A which is appended to the rules.3
C. Every application shall be duly accompanied by an Affidavit containing(i) An undertaking to the effect that the Genetic Centre/Laboratory/Clinic/ Ultrasound Clinic/Imaging Centre/combination thereof, as the case may be, shall not conduct any test or procedure,
by whatever name called, for selection of sex before or after conception or for detection of sex
of foetus except for diseases specified in Section 4(2) nor shall the sex of foetus be disclosed to
any body; and
(ii) An undertaking to the effect that the Genetic Centre/Laboratory/Clinic/ combination thereof, as
the case may be, shall display prominently a notice that they do not conduct any technique,
test or procedure etc. by whatever name called, for detection of sex of foetus or for selection of
sex before or after conception.4

1

Section 3 (1) of the Act.

2

Rule 4 (1) under the PNDT Rules.

3

Id.

4

Id.

Registration

9

<!-- page 17 -->

D. The Appropriate Authority or any authorised person will acknowledge the application in the
acknowledgement slip provided at the bottom of Form A on the very same day if personally delivered, otherwise on the next day by post.5
E. Every application form shall be submitted along with an application fee of:
(a) Rs.3000.00 for Genetic Counselling Centre, Genetic Laboratory, Genetic Clinic, Ultrasound Clinic or
Imaging Centre.
(b) Rs.4000.00 for an institute, hospital, nursing home, or any place providing jointly the service of
a Genetic Counselling Centre, Genetic Laboratory, Genetic Clinic, Ultrasound Clinic or Imaging
Centre or any combination thereof.6
However, if an application for registration has been rejected by the Appropriate Authority, no fee shall
be required to be paid on re-submission of the application by the applicant for the same body within 90
days of rejection. But every subsequent application shall be accompanied by the prescribed fee. Application fee once paid will not be refunded.7
F. The application fee shall be paid
By way of a demand draft
Drawn in favour of the Appropriate Authority
On any scheduled bank payable at the headquarters of the Appropriate Authority concerned.8
G. The fees collected by the Appropriate Authority for registration shall be deposited by the
Appropriate Authority concerned in a bank account opened in the name of the official designation
of the Appropriate Authority concerned.9
H. The fees so collected by the Appropriate Authority shall be utilized by the Appropriate
Authority in connection with the activities connected with implementation of the provisions of the
Act and these rules.10

Minimum Requirements for Registration
There are different minimum requirements for different bodies as regards minimum qualifications of
the employees and the minimum equipment for each of the bodies under the PNDT Act. All the
requirements relating to qualifications and equipment are mandatory.11 Under the amended Rules, the
Schedules appended to the earlier Rules have been done away with and the requirements for a Genetic
Counselling Centre, Genetic Laboratory and Genetic Clinic have been added under Rule 3 itself by
redrafting the same though the requirements remain the same, more or less.

5

Rule 4 (2) under the PNDT Rules.

6

Rule 5(1) under the PNDT Rules.

7

Proviso to Rule 5 (1) under the PNDT Rules.

8

Rule 5 (2) under the PNDT Rules.

9

Rule 5 (2) under the PNDT Rules as amended.

10

Id.

11

Rule 3 (1) under the PNDT Rules.

10

PNDT Act, 1994 & Amendments

<!-- page 18 -->

A Genetic Counselling Centre:
The requirements for a Genetic Counselling Centre are enumerated in Rule 3(1) in the amended Rules.
The centre should have adequate space.
The centre should contain educational charts/models/equipments for carrying out genetic counselling .
The centre must have any one of the following employees namely:
A medical geneticist
A gynaecologist; or
A paediatrician
having such qualifications and experience as mentioned in the preceding chapter.
B. Genetic Laboratory
The requirements for a genetic laboratory are enumerated in Rule 3(2) in the amended Rules under the
PNDT Act.
The laboratory should have adequate space for conducting the tests.
The laboratory should have or acquire such of the equipments as may be necessary to conduct
chromosomal studies, biochemical studies and molecular studies from amongst those enumerated under the amended Rules which has been annexed in the Appendix to this manual.12
The laboratory must have both a medical geneticist and a laboratory technician in its employment having such qualifications and experience as mentioned in the preceding chapter.13
C. Genetic Clinic
The requirements for a genetic clinic are enumerated in Rule 3(3) of the amended Rules under the PNDT
Act.
The centre should have adequate space.
The clinic/ultrasound clinic/imaging centre should have or acquire such of the following equipments, as may be necessary for carrying out the tests or procedures:
(a) Equipment and accessories necessary for carrying out clinical examination by an
obstetrician/gynaecologist
(b) An ultra-sonography machine including mobile ultrasound machine, imaging machine or
any other equipment capable of conducting foetal ultrasonography.
(c) Appropriate catheters and equipment for carrying out chorionic villi aspirations per vagina
or per abdomen.
(d) Appropriate sterile needles for amniocentesis or cordocentesis.

12

Rule 3(2)(b) under the amended PNDT Rules.

13

Rule 3(2)(a) under the amended PNDT Rules.

Registration

11

<!-- page 19 -->

(e) A suitable foetoscope with appropriate accessories for foetoscopy, foetal skin or organ biopsy
or foetal blood sampling shall be optional.
(f) Equipment for dry and wet sterilization
(g) Equipment for carrying out emergency procedures such as evacuation of uterus or resuscitation in case of need.
(h) Genetic Works Station.14
The clinic must have gynaecologist or sonologist, imaging specialist, Radiologist or Registered
Medical Practitioner or medical geneticist in its employment having such qualifications and
experience as mentioned in the preceding chapter.15
The aforementioned requirements are minimum mandatory and each of these bodies can have
more equipment, more number of employees etc. as long as they fulfill the necessary qualifications mentioned in the PNDT Act.
Documentary proof of requisite qualifications and experience as specified under the PNDT Act
and rules of persons employed by the facility should be annexed with the application for registration.
The bodies can be owned by any person and he need not have the qualifications required under
the Act as long as he has employees that fulfill the minimum qualifications required under the
PNDT Act. If an institute, hospital, nursing home or any place provides services jointly of any of
these bodies then such a place should fulfill the minimum requirements of both the bodies in
order to be registered.

Process of Certification 16
(a) Every application received by the appropriate authority will firstly be scrutinized by it and an
enquiry into whether such body fulfills all the requirements under the PNDT Act will be done.17
(b) An enquiry by the Appropriate Authority includes an inspection of the premises after giving
due notice to the applicant.18
(c) After the appropriate authority is satisfied that the applicant has fulfilled all minimum requirements, the application will be placed before the Advisory Committee. The Advisory Committee
shall thereafter scrutinize the application and give its advice on the same to the appropriate
authority.
(d) The Appropriate Authority after considering the advice will grant a certificate of registration.19
(e) The certificate of registration shall be given in duplicate and in the form as prescribed in Form B
annexed to the rules under the PNDT Act and the same is also part of the appendix to this
14

Rule 3(3)(2) under the amended PNDT Rules.

15

Rule 3(3)(1) under the amended PNDT Rules.

16

Section 19 of the Act.

17

Rule 6 (1) under the PNDT Rules.

18

Rule 6 (4) under the PNDT Rules.

19

Rule 6 (2) under the PNDT Rules.

12

PNDT Act, 1994 & Amendments

<!-- page 20 -->

manual. The grant of certificate of registration shall be communicated within 90 days from the
date of receipt of application for registration.20
(f) It is mandatory for everybody registered under this Act to display the certificate of registration
at a conspicuous place in such centre, laboratory or clinic.21
(g) In some cases the appropriate authority depending upon the requirements available at such
centre, laboratory or clinic may grant a certificate only to conduct one or more specified prenatal diagnostic tests or procedures.22
(h) The certificate of registration shall be non-transferable.23
(i) In the event of change of ownership or change of management or when the centre, laboratory
or clinic ceases to function as one both copies of certificate of registration shall be surrendered to
the Appropriate Authority.24
(j) Each new owner or manager of a centre, laboratory or clinic has to apply afresh for grant of
certificate of registration.25
(k) All centres, laboratories and clinics registered under the PNDT Act shall give an affidavit
affirming that they will not indulge in pre-natal determination of sex as mandated by the
Supreme Court in the case of CEHAT & Ors v. Union of India.
(l) The Registration Certificate must mention the number of ultrasound machines in the centre. Further the registration certificate must also mention all the portable ultrasound machines in the
said centre. In case of registration certificates already issued, the list of ultrasound machines
portable or otherwise must be mentioned on another paper and the said paper must also be
displayed along with the registration certificate at a conspicuous place in the centre.

Rejection of Application for Registration
If after enquiry and after giving an opportunity of hearing to the applicant and after taking
advise from the Advisory Committee the Appropriate Authority has come to a conclusion that
the applicant has not complied with the requirements of the Act then the said application will be
rejected.26
The reasons for the rejection shall be given in writing and as specified in Form C appended to the
Rules under PNDT Act.27
The rejection of registration shall be communicated to the applicant within 90 days from the date
of the receipt of the registration.28

20

Rule 6 (2) read with Rule 6 (5) under the PNDT Rules.

21

Supra n.10.

22

Proviso to Rule 6(2) under the PNDT Rules.

23

Rule 6(6) under the PNDT Rules.

24

Id.

25

Rule 6(7) under the PNDT Rules.

26

Rule 6 (3) under the PNDT Rules.

27

Id.

28

Rule 6 (5) under the PNDT Rules.

Registration

13

<!-- page 21 -->

Cancellation or Suspension of Registration
The Appropriate Authority can at any time either on its own or on a complaint by anyone issue a show
cause notice to the Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic, Ultrasound Clinic or
Imaging Centre as to why its registration should not be cancelled or suspended for breach of any of the
provisions of the PNDT Act or the rules. The reasons for every such notice should be mentioned in the
notice itself.29
Thereafter the clinic, laboratory or centre must be given an opportunity to defend itself against the
charges. After giving the centre, laboratory or clinic a reasonable opportunity of being heard and after
taking into account the advice given by the Advisory Committee, the Appropriate Authority may
either suspend the registration of such a place or cancel the registration depending upon the gravity of
the charge. Action can be taken by the Appropriate Authority irrespective of any criminal action that
will be taken against such a place.30
In certain exceptional cases like in the case of public interest the Appropriate Authority may suspend
or cancel registration without issuing a show cause notice. However the reasons for waiving show
cause notice have to be given in writing.31

Provision for Appeal 32
Any genetic counselling centre, genetic laboratory or genetic clinic may appeal against an order of cancellation or suspension of registration within 30 days of the order of cancellation or suspension.
The appeal may be made to:
The Appropriate Authority at the district level if the order is passed by the Appropriate
Authority at sub-district level.33
The Appropriate Authority at the State/UT level if the order is passed by the Appropriate
Authority at district level.34
Each appeal shall be disposed of by the District Appropriate Authority or by the State/UT
ate Authority, as the case may be, within 60 days of its receipt.35

Appropri-

Thus a hierarchy of appellate bodies has been provided and further the time limit for disposing of the
appeals has been laid down.
Moreover the appeal shall be made to the Central Government if the order is passed by the Central
Appropriate Authority.36
The appeal shall be made to the State government if the order is passed by the State Appropriate
Authority. 37
29

Section 20 (1) of the Act.
Section 20 (2) of the Act.
31
Section 20 (3) of the Act.
32
Section 21 of the Act.
33
Rule 19(1) under the amended PNDT Rules.
34
Rule 19(2) under the amended PNDT Rules.
35
Rule 19(3) under the amended PNDT Rules.
36
Section 21(i) of the Act.
37
Section 21(ii) of the Act.
30

14

PNDT Act, 1994 & Amendments

<!-- page 22 -->

If the appeal is not made within the time as prescribed above, the Appropriate Authority may condone
the delay in case he/she is satisfied that appellant was prevented for sufficient cause from making such
appeal. 38

Renewal of Registration
A. Every certificate of registration shall be valid for a period of five years since its issuance.39
B. Thirty days before the date of expiry of the certificate of registration a fresh application for a certificate of Registration should be made.40
C. The application for renewal must be made in duplicate in the prescribed Form A (same as the one
prescribed for obtaining the first registration certificate) to the Appropriate Authority.41
D. The Appropriate Authority shall acknowledge the receipt of the application in the acknowledgement
slip provided at the bottom of Form A on the very same day if personally delivered, otherwise on
the next day by post.42
E. Along with the application for renewal of certificate, registration fees of half of what was initially
payable will be paid depending upon whether it is for a genetic counselling centre, genetic laboratory
or genetic clinic, ultrasound clinic or imaging centre or for a joint facility.43
F. After the receipt of the application the Appropriate Authority will hold an enquiry including an
inspection of the premises after giving due notice into whether the applicant has fulfilled all the
requirements necessary under the Act. The Appropriate Authority will also give the applicant a
hearing. 44
G. After conducting the enquiry and hearing if the Appropriate Authority finds everything satisfactory then it will place the application before the Advisory Committee for its scrutiny.
H. Thereafter having regard to the advice of the Advisory Committee the Appropriate Authority will
renew the certificate of registration in the prescribed Form B (same as the one prescribed for the first
registration certificate) for a further period of 5 years starting from the date of expiry of the old
certificate.45
I.

On the receipt of the renewed certificate of registration in duplicate, the two copies of the earlier
certificates will have to be surrendered immediately to the Appropriate Authority.46

38

Rule 19(4) under the amended PNDT Rules.

39

Rule 7 under the PNDT Rules.

40

Rule 8(1) under the PNDT Rules.

41

Id.

42

Id.

43

Rule 8(4) under the PNDT Rules.

44

Rule 8(2) under the PNDT Rules.

45

Id.

46

Rule 8(5) under the PNDT Rules.

Registration

15

<!-- page 23 -->

J.

One copy of the renewed certificate has to be displayed in a conspicuous place of the centre, laboratory or clinic.

K. If the Appropriate Authority fails to renew the certificate of registration within 90 days of its receiving
the application for renewal, it will amount to automatic renewal or deemed renewal.47

Rejection of Application for Renewal
After conducting an enquiry into the application for renewal, after hearing the applicant and
after taking the advice of the Advisory Committee if the Appropriate Authority finds that the
applicant has not complied with the requirements of the Act then the appropriate authority can
reject the application for renewal.48
Every order of rejection will contain reasons for rejection and it will be communicated in the
prescribed Form C.49 (same as the one prescribed for the initial rejection)
Once the applicant receives the communication of rejection the applicant must immediately
surrender both the copies of the earlier certificate of registration.50
In case the appropriate authority fails to communicate its rejection to the applicant within 90
days of receiving the application for renewal then it amounts to automatic renewal or deemed
renewal. 51
Note: In case of defence establishments, applications for registration have to be submitted to the
Appropriate Authorities specifically notified for defence establishments who are otherwise responsible
for the implementation of the Act in their areas.
If the machines are lying packed or are not in use, then also registration is mandatory because requirement
of registration arises by the very possession of the machines.

47

Rule 8(6) under the PNDT Rules.

48

Rule 8(3) under the PNDT Rules.

49

Id.

50

Rule 8(5) under the PNDT Rules.

51

Rule 8(6) under the PNDT Rules.

16

PNDT Act, 1994 & Amendments

<!-- page 24 -->

Chapter

IV

PROHIBITIONS

The PNDT Act is a comprehensive piece of legislation which prohibits sex selection before or after
conception and misuse of pre-natal diagnostic techniques for determination of the sex of the foetus,
leading to female foeticide as also advertisements in relation to such techniques for detection or determination of sex. The Act also specifies the punishment for violation of its provisions. Accordingly, the
Act imposes the following:

Prohibitions
A. ON PLACES
No genetic counselling centre or genetic clinic or genetic laboratory shall
Conduct; or
Associate with; or
Help in conducting pre-natal diagnostic techniques unless registered.1
Moreover the Registration certificate has to be displayed prominently on a board in such place.2
Employ or cause to be employed or take services of any person, whether on honorary basis or on
payment who does not possess prescribed qualifications.3
A qualified person could be:
Gynaecologist
Medical Geneticist
Paediatrician
Registered Medical Practitioner
Radiologist

1

Section 3 (1) of the Act.

2

Section 19 (4) of the Act.

3

Section 3 (2) of the Act.

Probibitions

17

<!-- page 25 -->

Sonologist
Imaging Specialist
who fulfils the requirements laid down under the Act
Conduct or cause to be conducted a pre-natal diagnostic technique except for the purposes specified
in the Act.
Conduct or cause to be conducted a pre-natal diagnostic technique including an ultrasonography for the purpose of determining the sex of the foetus.4
Every genetic counselling centre or genetic clinic or genetic laboratory is required to display prominently a notice in English and in the local language or languages that conduct of sex-determination tests/disclosure of sex of the foetus is prohibited.5
B. ON PERSONS
No person shall open any genetic counselling centre, genetic clinic or genetic laboratory including clinic, laboratory or centre having ultrasound or imaging machine or scanner or any other
technology capable of undertaking determination of sex of foetus and sex selection unless such
centre, clinic or laboratory is duly registered separately or jointly.6
No qualified person shall conduct or aid in conducting himself or through any other person a
pre-natal diagnostic technique at any place other than the place registered.7
Illustration
A. No one can conduct a pre-natal diagnostic technique at home, unless the facility at home is
also registered.
B. No one can conduct a pre-natal diagnostic technique either on a voluntary basis, or on a
charitable basis unless the body is registered after meeting all necessary qualifications of persons, place and equipment.
No person shall render any services to any facility, after the commencement of the Pre-natal
Diagnostic Techniques (Regulation and Prevention of Misuse) Amendment Act, 2002 unless such
facility is duly registered under the Act.8
No person including a relative or husband of the pregnant woman shall seek or encourage the
conduct of any pre-natal diagnostic techniques on her except for the purposes specified in clause (2)
of Section 4 of the Act.9

4

Section 6 (a) of the Act.

5

Rule 17 (1) under the PNDT Rules.

6

Section 18 (1) of the Act.

7

Section 3 (3) of the Act.

8

Section 18(1) of the Act.

9

Section 4 (4) of the Act.

18

PNDT Act, 1994 & Amendments

<!-- page 26 -->

No person including a relative or husband of a woman shall seek or encourage the conduct of
any sex-selection technique on her or him or both.10
No person shall conduct or cause to be conducted any pre-natal diagnostic technique including
ultrasonography for purpose of sex determination.11
In fact a good doctor should counsel the patient that sex-determination is illegal and should also positively propagate about the girl child. A doctor is highly regarded in the society and any counselling by
him/her will have great impact in the implementation of the Act.
No person, including a specialist or a team of specialists in the field of infertility, shall conduct or
cause to be conducted or aid in conducting by himself or by any other person, sex selection on a
woman or a man or on both or on any tissue, embryo, conceptus, fluid or gametes derived from
either or both of them.12
No person shall, by whatever means, cause or allow to be caused selection of sex before or after
conception.13
No person including the person conducting a pre-natal diagnostic procedures shall communicate
to the pregnant woman concerned or her relatives or any other person the sex of the foetus by
words, signs or in any other manner whatsoever.14
Illustration
A. Dr. Lata tells Ramu it is time to celebrate, give me a packet of sweets. This is illegal as indirectly the doctor is communicating to the father that it is a baby boy.
B. Dr. Lama told Geeta, “Oh! your shoulders have become heavy now”. This is also illegal as the
same indirectly conveys the fact that it is baby girl.
C. Dr Singha used to tell all his patients “You see I have all the latest techniques from America, I
can tell the sex of the child within 10 weeks of pregnancy”. In every case the doctor used to
tell his patients it was a girl and his wife Mrs. Singha used to conduct the abortions the very
next day. Dr. Singha’s actions are in clear violation of the PNDT law. Dr. Singha’s actions also
amount to misrepresentation and fraud.
D. Dr. Himmat never told his patients anything, he used raise his left eyebrow when it was a boy
and right eyebrow when it was a girl. Dr. Himmat’s, actions though creative are also in violation of the PNDT law as the same amount to signs and gestures which is also prohibited.
The Central Supervisory Board has laid down a code of conduct under section 16 (iv) of the Act to be
observed by persons working in bodies specified therein and as such the same has to be strictly followed.15

10

Section 4(5) of the Act.

11

Section 6 (b) of the Act.

12

Section 3A of the Act.

13

Section 6(c) of the Act.

14

Section 5 (2) of the Act.

15

The Supreme Court vide its order dated 4.5.2001 has also stressed the formulation of such a code of conduct. The same has now been
incorporated under Rule 18 of the amended PNDT Rules.

Probibitions

19

<!-- page 27 -->

C. MISCELLANEOUS
No person, organization, Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic, including
clinic, laboratory or centre having ultrasound machine or imaging machine or scanner or any other
technology capable of undertaking determination of sex of foetus or sex selection shall issue, publish, distribute, communicate or cause to be issued, published, distributed or communicated any
advertisement, in any form, including internet, regarding facilities of pre-natal determination of sex
or sex selection before conception available at such centre, laboratory, clinic or at any other place.16
Illustration
A. “Spend Rs.5000 now and save Rs.5 lakhs later. Contact Dr. Ahmed of Ahmed Diagnostic
Center.” This advertisement is illegal as it advertises facilities for sex determination.
B. “Urine test now and result known immediately whether boy or girl.” This advertisement is
also clearly illegal.
C. “Want to know – boy or girl, quick and easy. No surgery required.” This advertisement is
clearly illegal.
No person, organization including Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic
shall issue, publish, distribute, communicate or cause to be issued, published, distributed or communicated any advertisement, in any manner regarding pre-natal determination or pre-conception
selection of sex by any means whatsoever, scientific or otherwise.17
Illustration
A. A magazine published in America but distributed by AB Co in India, with its office in Delhi
carries an advertisement for sex-determination. Such an action on the part of the company in
Delhi is in violation of the Act.
Advertisement includes any notice, circular, label, wrapper or other document including advertisement through internet or any other media in electronic or print form and also includes any visible
representation made by means of any hoarding, wall-painting, signal, light, sound, smoke or gas.18
B. Wrappers of Meera Milk food with a colorful picture of a baby boy—if you want a baby boy
contact Meera Diagnostic Centre and they will help you, otherwise money back guaranteed.
This is clearly illegal.
No person shall sell, distribute, supply, rent, allow or authorize the use of any ultrasound
machine or imaging machine or scanner or any other equipment capable of detecting sex of foetus
whether on payment or otherwise to any Genetic Counselling Centre, Genetic Laboratory, Genetic
Clinic or any other person or body not registered under the Act.19
“Person” includes manufacturer, importer, dealer or supplier of ultrasound machines/imaging
machines or any other equipment capable of detecting sex of foetus” as also any organization including a commercial organization.
16

Section 22 (1) of the Act.

17

Section 22 (2) of the Act.

18

Explanation to Section 22 of the Act.

19

Section 3B of the Act read with Rule 3A under the amended PNDT Rules.

20

PNDT Act, 1994 & Amendments

<!-- page 28 -->

Further the provider of such machine/equipment to any person/body registered under the Act shall:
a) send to the concerned State/UT Appropriate Authority and to the Central Government, once
in three months a list of those to whom the machine/equipment has been provided; and
b) take an affidavit from such body or person purchasing or getting authorization for using such
machine/equipment that the machine/equipment shall not be used for detection of sex of
foetus or selection of sex before or after conception.20

Prescriptions and Regulations
The PNDT law is a prohibitory and regulatory statute; it seeks to put in place a mechanism which
prohibits sex selection while preventing the misuse and over-use of the pre-natal diagnostic techniques.
At the same time, the Act permits and regulates the use of such techniques for the purpose of detection
of specific genetic abnormalities or disorders and for the larger benefit of mankind. The Act further
permits the use of such techniques only under certain conditions by the registered bodies. The PNDT
Act prohibits the conduct of pre-natal diagnostic techniques for determination of the sex of the foetus but
allows the conduct of pre-natal diagnostic techniques for purposes that have also been specified under
the Act. These are for detection of:
Chromosomal abnormalities;
Genetic metabolic diseases;
Haemoglobinopathies;
Sex-linked genetic diseases;
Congenital anomalies;
Other abnormalities or diseases as specified by the Central Supervisory Board.21
The Central Supervisory Board has laid down a representative list of indications for ultrasound during
pregnancy (see new Form F under the amended Rules which have been annexed to this Handbook).
The conduct of pre-natal diagnostic techniques is further permissible if the person qualified is satisfied for
reasons to be recorded in writing that any of the following conditions exist:
Age of the pregnant woman is above thirty-five years;
Pregnant woman has undergone two or more spontaneous abortions or foetal loss;
Pregnant woman has been exposed to potentially teratogenic agents such as drugs, radiation,
infection or chemicals;
The pregnant woman or her spouse has a family history of mental retardation or physical deformities such as, spasticity or any other genetic disease;
Any other condition specified by the Central Supervisory Board.22
The doctors conducting pre-natal diagnostic techniques should maintain proper documentation.
20

Rule 3A(2) and (3) under the amended PNDT Rules.

21

Section 4 (1) of the Act read with Section 4 (2) of the Act.

22

Section 4 (1) of the Act read with Section 4 (3) of the Act.

Probibitions

21

<!-- page 29 -->

Under the amendments it has been made mandatory that the person conducting ultrasonography on a
pregnant woman shall keep complete record thereof in the clinic in such manner, as may be prescribed,
and any deficiency or inaccuracy found therein shall amount to contravention of provisions of section
5 or section 6 unless contrary is proved by the person conducting such ultrasongraphy.23
Once the doctor follows all the necessary requirements under the law and does the necessary paperwork as mentioned below, he can have no fear from the law. The woman must not only make sure that
her consent is taken in case of invasive procedures but must ask for a copy of every document that she
signs. If she does not understand anything she must ask for an explanation and it is her right to be told.
Pre-implantation genetic diagnosis or a pre-natal diagnostic technique/test/procedure such as amniocentesis,
chorionic villi biopsy, foetoscopy, foetal skin or organ biopsy or cordocentesis can be conducted:
ONLY
After obtaining the written consent of the woman in the prescribed format in a language which
she understands. The format for the written consent is provided in Form G under the Rules.
However, an exception is that where a Genetic Clinic has taken a sample of any body tissue or
body fluid and sent it to a Genetic Laboratory for analysis or test, it shall not be necessary for the
Genetic Laboratory to obtain a fresh consent in Form G.
Giving her a copy of the same; and
Explaining all known side and after effects of the procedures to the pregnant woman.24
Under the amended Rules, a distinction has been made between invasive and non-invasive techniques
for the purpose of obtaining consent and the consent is required in the case of invasive techniques.
However, in case of ultrasonography, other documentation is now required. Any person conducting
ultrasonography/image scanning on a pregnant woman shall give a declaration on each report on
ultrasonography/image scanning that he/she has neither detected nor disclosed the sex of foetus of
the pregnant woman to any body. The pregnant woman before undergoing ultrasonography/image
scanning declare that she does not want to know the sex of her foetus.25
It is important to mention that the PNDT Act has an important link with the Medical Termination of
Pregnancy Act, 1971 (hereinafter referred to as the MTP Act). Prior to 1971, abortions were considered
illegal in our country and in fact the same could be punishable under the Indian Penal Code. In 1971,
the MTP Act was passed which provides for the termination of certain pregnancies by registered
medical practitioners (as defined under the MTP Act). Thus it is clear that abortion is not provided for
in all cases of pregnancy but only in case of certain pregnancies. Under the Act, termination of pregnancy is possible where:
The length of the pregnancy does not exceed twelve weeks;
The length of the pregnancy exceeds twelve weeks but does not exceed twenty
weeks: in this case the opinion of two registered medical practitioners in favour of the termination of the pregnancy is essential.26
23

Proviso to Section 4(3) of the Act.

24

Section 5 of the Act.

25

Rule 10 (1A) under the amended PNDT Rules.

26

Section 3 (a) and (b) of the MTP Act.

22

PNDT Act, 1994 & Amendments

<!-- page 30 -->

ONLY
If the continuance of the pregnancy would involve a risk to the life of the pregnant woman or of
grave injury to her physical or mental health27; or
If there is a substantial risk that if the child were born, it would suffer from such physical or
mental abnormalities as to be seriously handicapped.28
It has been clarified under the Act that where the pregnancy is alleged to have been caused by rape, the
anguish caused by such pregnancy shall be presumed to constitute a grave injury to the mental health
of the pregnant woman.29 Thus, pregnancy due to rape can be validly terminated.
Further, where the pregnancy occurs as a result of failure of any device or method used by any married
woman or her husband for the purpose of limiting the number of children, the anguish caused by such
unwanted pregnancy may be presumed to constitute a grave injury to the mental health of the pregnant woman.30 Thus, failure of methods of family planning could also give rise to a ground for
termination of the pregnancy.
While considering whether the continuance of pregnancy would involve risk or injury to the health of
the pregnant woman, account may be taken of the pregnant woman’s actual or reasonable foreseeable
environment.31
There is another provision under which the pregnancy can be terminated validly irrespective of the
length of the pregnancy and the opinion of two registered medical practitioners. In this case, the registered medical practitioner should be of the opinion, formed in good faith that the termination of the
pregnancy is immediately necessary to save the life of the pregnant woman.32
The opinion of the registered medical practitioners should be formed in good faith. Such opinion has to
be certified in Form I under the MTP Regulations33 framed under the Act34. Form I is annexed here as
Annexure-I. In this form the reasons for forming the opinion also have to be stated. Further every
registered medical practitioner who terminates any pregnancy is required within three hours from the
termination of the pregnancy to certify such termination in the said form35 where again the reason for
terminating the pregnancy has to be specified.
It is clear from what is above mentioned that termination of pregnancy is possible only in certain
cases and where the pregnancy is more than 12 weeks old, opinion of two registered medical practitioners as defined under the MTP Act is essential, and then also abortion is possible only up to the
twentieth week. Through ultrasonography, which is the most commonly used technique for determination of the sex of the foetus, the sex of the foetus can be known only after the 14th week. Thus if a
woman were to go in for abortion after getting to know the sex of the foetus, since it would be a

27

Section 3 (i) of the MTP Act.

28

Section 3 (ii) of the MTP Act.

29

Explantation 1 to Section 3 of the MTP Act.

30

Explanation 2 to Section 3 of the MTP Act.

31

Explanation 3 to Section 3 of the MTP Act.

32

Section 5 of the MTP Act.

33

The Medical Termination of Pregnancy Regulations, 1975 published in the Gazette of India dated 4.10.75.

34

Regulation 3 (1) under the MTP Regulations.

35

Regulation 3 (2) under the MTP Regulations.

Probibitions

23

<!-- page 31 -->

second trimester pregnancy, opinion of two registered medical practitioners would be essential.
The MTP Act further provides that the pregnancy cannot be terminated (except where the woman has
not attained the age of 18 years or she has attained the age of 18 years but is a mentally ill person36 in
which case the consent in writing of the guardian is to be taken37) except with the consent of the
pregnant woman.38 The form for the consent is provided in Form C under the MTP Rules39 framed
under the MTP Act40 and is annexed here as Annexure - II. The Regulations provide for all the documents i.e. the consent given by a pregnant woman for termination of her pregnancy, the certified
opinion recorded under the above provisions and the intimation of termination of pregnancy:
To be put in a sealed envelope;
The envelope to be sent by the registered medical practitioner to the head of the hospital or owner
of the approved place;
Safe-custody of the same by the latter;
A weekly statement of cases where medical termination of pregnancy has been done is required
to be sent to the Chief Medical Officer by the head of the hospital or the owner of the approved
place.41 This is to be done in Form II under the Regulations and is annexed as Annexure-III.
An admission register is to be maintained for recording therein the admissions of women for the
termination of their pregnancies.42 This is to be done in Form III under the Regulations and is
annexed as Annexure-IV.
If all these records are duly maintained, with their aid the Appropriate Authorities can monitor the
abortions that are being done For instance, if there are too many cases referred by a particular doctor or
the reasons stated are essentially the same, the real reason for the abortion may be traceable to a
determination of the sex of the foetus.
The Rules framed under the PNDT Act lay down certain other conditions for analysis or test and prenatal diagnostic procedures. Thus:
A Genetic Laboratory cannot accept for analysis or test any sample, unless referred to it by a
Genetic Clinic;43
Every pre-natal diagnostic procedure has to be immediately preceded by locating the foetus and
placenta through ultrasonography;44
The pre-natal diagnostic procedure shall be done under direct ultrasonographic monitoring so as to
prevent any damage to the foetus and placenta.45
36

The word ‘lunatic’ has been substituted by ‘mentally ill person’ by an amendment made to the Act in 2002. A ‘mentally ill person’ means a
person who is in need of treatment by reason of any mental disorder other than mental retardation.

37

Section 3 (4) (a) of the MTP Act.

38

Section 3 (4) (b) of the MTP Act.

39

The Medical Termination of Pregnancy Rules, 1975, published in the Gazette of India, dated 4.10.75.

40

Rule 8 under the MTP Rules.

41

Regulation 4 under the MTP Regulations.

42

Regulation 5 under the MTP Regulations.

43

Rule 14 (1) under the MTP Rules.

44

Rule 14 (2) under the MTP Rules.

45

Ibid.

24

PNDT Act, 1994 & Amendments

<!-- page 32 -->

Penalties
A. Offence by persons
I.

If any person acts contrary to the prohibitions listed above including under Sections 22(1) and 22(2)
relating to advertisement, he will be liable to be punished with:
Imprisonment which may extend to 3 years; and
Fine which may extend to Rs.10,000/-.46

Any subsequent conviction entails:
Imprisonment which may extend to 5 years; and
Fine which may extend to Rs.50,000/-.47
II. In case of a person seeking the aid of the bodies or persons referred to above for sex selection or for
conducting pre-natal diagnostic techniques on any pregnant woman for the purposes other than
those specified in Section 4(2), he shall be liable to be punished with:
Imprisonment which may extend to three years; and
Fine which may extend to Rs.50,000/-.
Any subsequent conviction entails:
Imprisonment which may extend to 5 years; and
Fine which may extend to Rs.1 lakh.48
III. In case of a registered medical practitioner, his name shall be reported by the Appropriate Authority to the State Medical Council concerned for taking necessary action:
Including suspension of the registration if charges are framed by the court and till the case is
disposed of; and
For the removal of his name from the register of the council on conviction for the period of:
Five years for the first offence;
Permanently for the subsequent offence.49
IV. Husband and relatives of the pregnant woman who undergoes a pre-natal diagnostic technique for
the purposes other than those specified in sub-section (2) of section 4 shall be:
Presumed to have compelled the woman to undergo the pre-natal diagnostic technique unless
the contrary is proved;50 and

46

Sections 22 (3), 23 (1) and 23 (3) of the Act.

47

Sections 23 (1) of the Act.

48

Section 23 (3) of the Act.

49

Section 23 (2) of the Act.

50

Section 24 of the Act.

Probibitions

25

<!-- page 33 -->

Liable for abetment of offence under Section 23 (3);51 and
Punishable for the offence under Section 23 (3).52
If the contrary is proved, the woman can also be likewise punished. For the removal of doubts, it has
been made clear under the amendments that the provisions of Section 23 (3) shall not apply to the
woman who was compelled to undergo such diagnostic techniques or such selection.53
V. If any person contravenes any provision of the Act or the Rules made thereunder for which no
penalty has been specified, he will be liable to be punished with:
Imprisonment which may extend to three months; or
Fine which may extend to Rs.1000/-; or
With both.54
Any subsequent contravention entails an additional fine which may extend to Rs.500/- for every day
during which such contravention continues after conviction for the first such contravention.
B. Offence by a company:
A company:
Means any body corporate;
Includes a firm or other association of individuals.55
In case of offence by a company:
Every person incharge of; and
Every person responsible to the company for the conduct of the business of the company at the
time the offence was committed
The company shall all be deemed to be guilty and accordingly proceeded against and punished.56
The aforesaid is subject to the qualification that if any such person proves that the offence was committed without his knowledge or that he had exercise due diligence to prevent the commission of such
offence, he may not be so liable.57
If consent, connivance of or that it was attributable to any neglect on the part of:
Director and in relation to a firm, a partner in the firm
Manager
Secretary
Other officer
51

Ibid

52

Ibid

53

Section 23(4) of the Act.

54

Section 25 of the Act.

55

Explanation (a) to Section 26 of the Act.

56

Section 26 (1) of the Act.

57

Proviso to Section 26 (1) of the Act.

26

PNDT Act, 1994 & Amendments

<!-- page 34 -->

they shall also be deemed to be guilty and accordingly proceeded against and punished.58
The offences under the Act are:
Cognizable: This means that for such an offence the police officer may arrest without warrant.
Non-bailable: This means that the police cannot grant bail in such a case.
Non-compoundable.59: This means that the parties to the case cannot settle the case and decide
not to prosecute.

Who Can Make A Complaint?
The Appropriate Authority concerned;60
Any officer authorized in this behalf by the Central Government or State Government or the
Appropriate Authority;61
A person who has given notice of at least 15 days to the Appropriate Authority of the alleged
offence and of his intention to make a complaint in the court i.e. if the Appropriate Authority
fails to take action on the complaint made by a person, on the lapse of 15 days, that person can
directly approach the court.62
Every public spirited person can activate the PNDT law for the violation of the same and he/she can
seek the assistance of a lawyer, an NGO and even a group of persons can file a complaint together.
Once the complaint is made in the Court the public prosecutor will take on from there and the complainant need not be present on every date of hearing.
Significantly “person” includes a social organization.63
In such a case, the court, on demand by such person, may direct the Appropriate Authority to
make available copies of the relevant records in its possession to such person.64
The drafts of complaints that can be made by a public spirited person to the Appropriate Authority are
annexed herewith as Annexure-V.
The offence under the Act shall be tried only in a court of the Metropolitan Magistrate or a
Judicial Magistrate of the First Class.65
The drafts of complaints that can be filed by the Appropriate Authority in court are annexed herewith

58

Section 26 (2) of the Act.

59

Section 27 of the Act.

60

Section 28 (1) (a) of the Act.

61

Ibid.

62

Section 28 (1) (b) of the Act.

63

Explanation to Section 28 of the Act.

64

Section 28 (3) of the Act.

65

Section 28 (2) of the Act.

Probibitions

27

<!-- page 35 -->

as Annexure-VI. The reply that can be filed by the Appropriate Authority to an application for anticipatory bail is annexed as Annexure-VII.

Good Faith
No suit, prosecution or other legal proceeding shall lie against the Central or State Government or the
Appropriate Authority or any officer authorized by them for anything which is in good faith done or
intended to be done under the Act.66
Thus the Appropriate Authority can perform its duties under the Act without any fear of any type of
legal proceedings being initiated against him/her.

66

28

Section 31 of the Act.

PNDT Act, 1994 & Amendments

<!-- page 36 -->

Chapter

V

INSTRUMENTALITIES FOR
IMPLEMENTING THE ACT

A. Policy Making Body
I.

A Board is required to be constituted by the Central Government which is known as the Central
Supervisory Board (hereinafter referred to as the Board).1 The Act makes provision for inclusion of
government officials, specialists as well as representatives of welfare organizations in this Board.
Accordingly the Board is to comprise of:
a) The Minister in charge of the Ministry of Department of Family Welfare, who is the Chairman,
ex-officio.
b) The Secretary to the Government of India in charge of the Department of Family Welfare, who
is the Vice-Chairman, ex-officio.
c) Three members to be appointed by the Central Government to represent the Ministries of Central Government in charge of Women and Child Development, Department of Legal Affairs or
Legislative Department in the Ministry of Law and Justice, and Indian System of Medicine and
Homoeopathy, ex-officio.
d) Director General of Health Services of the Central Government, ex-officio.
e) Ten members appointed by the Central Government, two each from amongst1. Eminent medical geneticists;
2. Eminent gynaecologists and obstetrician or expert of stri-roga or prasuti tantra;
3. Eminent paediatricians;
4. Eminent social scientists; and
5. Representatives of women welfare organizations.
f)

1

Three women members of Parliament – two elected from Lok Sabha and one from Rajya Sabha.

Section 7 (1) of the Act.

Instrumentalities for Implementing the Act

29

<!-- page 37 -->

g) Four members appointed by the Central Government (on the recommendation of the respective
State Government or of Union Territory) by rotation to represent the States and Union
Territories.
h) An officer, not below the rank of Joint Secretary or equivalent of the Central Government, in
charge of Family Welfare who is the Member Secretary, ex-officio.2
The Act also specifies the terms of the various members3 and prescribes the procedure for the meetings
of the Board which is to be further provided for by regulations made by the Board.4 It is mandatory for
the Board to meet at least once in six months.5 Importantly, if a person, in the opinion of the Central
Government, has been associated with the use or promotion of pre-natal diagnostic technique for determination of sex or with any sex selection technique, he shall be disqualified from being appointed as a
member of the Board.6
In the amendments it has been clarified that no member other than an ex-officio member shall be appointed for more than two consecutive terms.7
The functions of the Board as specified under the Act are:
i)

To advise the Central Government on policy matters relating to use of pre-natal diagnostic techniques, sex selection techniques and against their misuse;

ii) To review and monitor implementation of the Act and the rules made thereunder and to recommend to the Central Government changes in both;
iii) To create public awareness against the practice of pre-conception sex selection and pre-natal
determination of sex of foetus leading to female foeticide;
iv) To lay down code of conduct to be observed by persons working at Genetic Counselling Centres,
Genetic Laboratories and Genetic Clinics;
v) To oversee the performance of various bodies constituted under the Act and take appropriate
steps to ensure its proper and effective implementation.8
The Board is also to perform any other functions as may be specified under the Act9 such as specifying
abnormalities or diseases for which pre-natal diagnostic techniques can be conducted10 or the conditions
which are necessary to exist before the conduct of these techniques.11 Thus the Act envisages the Board
as the main body which is to make recommendations on policy maters and on amendments that are
necessary in the Act.
The Supreme Court vide its order dated 4.5.2001 had also directed the Board to lay down a code of
conduct under section 16 (iv) of the Act to be observed by persons working in bodies specified therein
2

Section 7 (2) of the Act.

3

Section 8 of the Act.

4

Section 9 of the Act.

5

Proviso to Section 9 (1) of the Act.

6

Section 14 (f) of the Act.

7

Proviso to Section 15 of the Act.

8

Section 16 of the Act.

9

Section 16 (vi) of the Act.

10

Section 4 (2) (vi) of the Act.

11

Section 4 (3) (v) of the Act.

30

PNDT Act, 1994 & Amendments

<!-- page 38 -->

and to ensure its publication so that the public at large can know about it. Pursuant to this, the Board
has laid down a Code of Conduct to be observed by persons working at any of the facilities. This
provides that all persons including the owner, employee or any other persons associated with facilities
registered under the Act/the Rules shall(i)

Not conduct or associate with, or help in carrying out detection or disclosure of sex of
foetus in any manner;

(ii)

Not employ or cause to be employed any person not possessing qualifications necessary for
carrying out pre-natal diagnostic techniques/procedures and tests including ultrasonography;

(iii)

Not conduct or cause to be conducted or aid in conducting by himself or through any other
person any techniques or procedure for selection of sex before or after conception or for
detection of sex of foetus except for the purposes specified in sub-section (2) of section 4 of
the Act;

(iv)

Not conduct or cause to be conducted or aid in conducting by himself or through any other
person any techniques or test or procedure under the Act at a place other than a place
registered under the Act/the Rules;

(v)

Ensure that no provision of the Act and these Rules are violated in any manner;

(vi)

Ensure that the person conducting any techniques, test or procedure leading to detection of
sex of foetus for purposes not covered under section 4(2) of the Act or selection of sex before
or after conception is informed that such procedures lead to violation of the Act and the
Rules which are punishable offences;

(vii) Help the law enforcing agencies in bringing to book the violators of the provisions of the
Act and the Rules;
(viii) Display his/her name and designation prominently on the dress worn by him/her;
(ix)

Write his/her name and designation in full under his/her signature;

(x)

On no account conduct or allow/cause to be conducted female foeticide;

(xi)

Not commit any other act of professional misconduct.12

II. Under the amended provisions of the Act, a State Supervisory Board or the Union Territory Supervisory Board is required to be constituted by each State and Union Territory having a Legislature. It
shall consist of:
a) The Minister in charge of Health and Family Welfare in the State, who shall be the Chairperson,
ex-officio;
b) The Secretary in charge of the Department of Health and Family Welfare who shall be the ViceChairperson, ex-officio;
c) Secretaries or Commissioners in charge of Departments of Women and Child Development,
Social Welfare, Law and Indian System of Medicines and Homoeopathy, ex-officio, or their
representatives;
12

Incorporated as Rule 18 under the amended PNDT Rules.

31

<!-- page 39 -->

d) Director of Health and Family Welfare or Indian System of Medicines and Homoeopathy of the
State Government, ex-officio;
e) Three women members of Legislative Assembly or Legislative Council;
f)

Ten members to be appointed by the State Government out of which two each shall be from the
following categories:
i)

Eminent social scientists and legal experts;

ii) Eminent women activists from non-governmental organizations or otherwise;
iii) Eminent gynaecologists and obstetricians or experts of stri-roga or prasuti tantra;
iv) Eminent paediatricians or medical geneticists;
v) Eminent radiologists or sonologists;
g) An officer not below the rank of Joint Director in charge of Family Welfare, who shall be the
Member Secretary, ex-officio.13
The Act also specifies the terms of the various members other than ex-officio members as three years14,
co-opting of members 15 and procedure for the meetings of the Board. 16 The number of
co-opted members cannot exceed one-third of the total strength of the State Board. The co-opted members shall have the same powers and functions as other members, except the right to vote and shall
abide by the rules and regulations. It has been clarified that if a member of the Legislative Assembly or
member of the Legislative Council who is a member of the State Board, becomes Minister or Speaker or
Deputy Speaker of the Legislative Assembly or Chairperson or Deputy Chairperson of the Legislative
Council, she shall cease to be a member of the State Board.17 It is mandatory for the Board to meet at least
once in four months18 and one-third of the total number of members of the State Board shall constitute the
quorum.19
The functions of the Board as specified are:
i)

To create public awareness against the practice of pre-conception sex selection and prenatal determination of sex of foetus leading to female foeticide in the State;

ii) To review the activities of the Appropriate Authorities functioning in the State and recommend appropriate action against them;
iii) To monitor the implementation of provisions of the Act and the rules and make suitable
recommendations relating thereto, to the CSB;
iv) To send such consolidated reports as may be prescribed in respect of the various activities
undertaken in the State under the Act to the Board and the Central Government; and
v) Any other functions as may be prescribed under the Act.20
13

Section 16A (2) of the Act.
Section 16A (4) and (5) of the Act.
15
Section 16A (8) and (9) of the Act.
16
Section 16A(10) of the Act.
17
Section 16A (6) of the Act.
18
Section 16A (3) of the Act.
19
Section 16A (7) of the Act.
20
Section 16A (1) of the Act.
14

32

PNDT Act, 1994 & Amendments

<!-- page 40 -->

The Act does not specify the time frame within which such Boards are to be constituted but as the
Board has an important role with regard to policy matters and reviewing and monitoring the work of
the other bodies in the State, it would further the implementation of the provisions of the Act if such
Boards are set up as expediently as possible.
B. IMPLEMENTING AUTHORITIES
The role of the implementation of the Act has been assigned to the appropriate authorities. The Appropriate Authorities21 are to function with the aid and advice of an Advisory Committee. Under the Act:
The Central Government is required to appoint one or more Appropriate Authorities for each of the
Union territories;22
The State Government is required to appoint one or more Appropriate Authorities for the whole or
part of the States having regard to the intensity of the problem of pre-natal determination of sex
leading to female foeticide;23
Under the amendments, a multi-member body has been provided as the State Appropriate Authority
(or when appointed for the whole of the Union Territory) consisting of:
i)

An officer of or above the rank of the Joint Director of Health and Family Welfare-Chairperson;

ii) An eminent woman representing women’s organization; and
iii) An officer of Law Department of the State or the Union Territory concerned.24
Such authorities are to be constituted within three months of coming into force of the Amended Act
and any vacancy occurring therein is required to be filled within three months of the occurrence.25
Under the directions of the Supreme Court, Appropriate Authorities are to be appointed at District
and sub-district levels as well. At the District level, the Chief Medical Officers or the Civil Surgeons
have been designated as the Appropriate Authorities while at the sub-district level, the practice varies
from State to State.
Functions of the Appropriate Authority are:
To grant, suspend or cancel the registration;
To enforce the standards for genetic counselling centre, genetic clinic and genetic laboratory.
To investigate complaints of breach of provisions of the Act and the Rules;
To take the complaints to the court.
To take appropriate legal action against the use of any sex selection technique by any person at
any place, suo motu or brought to its notice and also to initiate independent investigations in such
matter;
To create public awareness against the practice of sex selection or pre-natal determination of sex;
21

Section 17 of the Act.

22

Section 17 (1) of the Act.

23

Section 17 (2) of the Act.

24

Section 17 (3)(a) of the Act.

25

Proviso to Section 17 (3) (a) of the Act.

33

<!-- page 41 -->

To supervise the implementation of the provisions of the Act and rules;
To recommend to the CSB and State Boards modifications required in the rules in accordance
with changes in technology or social conditions;
To take action on the recommendations of the Advisory Committee made after investigation of
complaint for suspension or cancellation of registration.26
While it is the function of the Appropriate Authority to take a complaint of breach of provisions of the
Act and the Rules thereunder to the court, if the Appropriate Authority fails to act on the complaint
within 15 days, a public spirited person can take the complaint to the court directly.27
Moreover the Appropriate Authority has been invested with the following powers, namelya) Summoning of any person who is in possession of any information relating to violation of the
provisions of this Act or the rules made thereunder;
b) Production of any document or material object relating to clause (a);
c) Issuing search warrant for any place suspected to be indulging in sex selection techniques or prenatal sex determination; and
d)Any other matter which may be prescribed.28
These provisions are meant to strengthen the hands of the Appropriate Authority while discharging its
functions under the Act.
Under the directions of the Supreme Court dated 4.5.2001, all State/Union Territory Appropriate
Authorities are required to furnish quarterly returns to the Board giving a report on the implementation and working of the Act. These returns are to cover information, inter alia about:
i)

Survey of bodies specified in Section 3 of the Act;

ii) Registration of bodies specified in Section 3 of the Act including bodies using ultrasound
machines;
iii) Action taken against non-registered bodies operating in violation of Section 3 of the Act,
inclusive of search and seizure of records;
iv) Complaints received by the Appropriate Authorities under the Act and action taken pursuant thereto;
v) Number and nature of awareness campaigns conducted and results flowing therefrom.
The format of the quarterly report that is required to be submitted is annexed herewith as
Annexure-IX.
The Act also provides for the appointment of an Advisory Committee by the Central or the State
Government, as the case may be, to aid and advise the Appropriate Authority in the discharge of its
functions.29 The Advisory Committee is to consist of:
26

Section 17 (4) of the Act.

27

Section 28 (1) (b) of the Act.

28

Section 17A of the Act.

29

Section 17 (5) of the Act.

34

PNDT Act, 1994 & Amendments

<!-- page 42 -->

Three medical experts from amongst gynecologists, obstetricians, pediatricians and medical
geneticists;
One legal expert;
One officer to represent the information and publicity department of the respective government;
Three eminent social workers with at least one being a representative of a women’s
organization.30
A person who has been associated with the use or promotion of pre-natal diagnostic techniques for
determination of sex or sex selection shall be disqualified from appointment as a member of the
Advisory Committee.31
The intervening period between any two meetings of the Advisory Committee shall not exceed
60 days32 whether any application for registration or cancellation of the same is pending or not. At
every meeting of the Advisory Committee, four members shall form a quorum. Thus at least four
members should be present for the meeting of the Advisory Committee to be held.
Under the Rules specially framed in this behalf, the Appropriate Authority is required to attend the
meeting of the Advisory Committee, provide all secretarial and other assistance to the Advisory
Committee for the discharge of its functions, though the Appropriate Authority shall not have a right
to vote in case of any difference of opinion amongst the members of the Advisory Committee and
voting is done.33
Moreover the procedure to be followed by the Advisory Committee is to be prescribed by rules and
regulations made in this regard. Separate Rules have been framed known as the Pre-Natal Diagnostic
Techniques (Regulation and Prevention of Misuse) (Advisory Committee) Rules, 1996 which regulate
the procedure to be followed by the Advisory Committees. The same are annexed herewith as
Appendix-III.

30

Section 17 (6) of the Act.

31

Section 17 (7) of the Act.

32

Rule 4 under the PNDT (Advisory Committee) Rules, 1996.

33

Rule 9 under the PNDT (Advisory Committee) Rules, 1996.

35

<!-- page 43 -->

Chapter

VI

MAINTENANCE AND
PRESERVATION OF RECORDS

The Act and the Rules also deal elaborately with the maintenance and preservation of records. Maintenance of proper records has a dual advantage:
From the point of view of the centre or clinic or laboratory, if there is any complaint against
them, through the records they can prove that their action was in accordance with the law and
the rules.
From the point of view of the implementing authorities, while non-maintenance of proper records
can itself give rise to a cause of action, the fact that proper records have not been maintained or
that for certain cases no records have been maintained can be indicative of the fact that the
centre or the clinic or the laboratory is conducting pre-natal diagnostic techniques for the purpose
of determination of the sex of the foetus or in violation of the Act.
Every Genetic Counselling Centre, Genetic Clinic or Genetic Laboratory, Ultrasound Clinic and Imaging
Centre is required to maintain certain records:
Register showing in serial order:
Names and addresses of men or women given genetic counselling and/or subjected to pre-natal
diagnostic procedure or test;
Names of their spouses or fathers;
Date on which they first reported for such counselling, procedure or test.1
Further,
Record by every Genetic Counselling Centre of each woman counselled is to be as specified in
FORM D under the Rules;2
Record by every Genetic Laboratory of each man or woman subjected to pre-natal diagnostic test is
to be as specified in FORM E under the Rules;3

1

Rule 9 (1) under the Rules.

2

Rule 9 (2) under the Rules.

3

Rule 9 (3) under the Rules.

36

PNDT Act, 1994 & Amendments

<!-- page 44 -->

Record by every Genetic Clinic of each man or woman subjected to pre-natal diagnostic procedure is
to be as specified in FORM F under the Rules.4
The other kinds of records include:
Case records
Forms of consent
Laboratory results
Microscopic pictures
Sonographic plates or slides
Recommendations and letters
A person conducting ultrasonography on a pregnant woman shall keep complete record thereof in the
clinic in such manner, as may be prescribed, and if any deficiency or inaccuracy is found in the same,
that would be treated as a contravention of provisions of section 5 or section 6 unless contrary is proved
by the person conducting the ultrasonography.5
Moreover every Genetic Counselling Centre, Genetic Laboratory, Genetic Clinic, Ultrasound Clinic and
Imaging Centre shall send a complete report in respect of all pre-conception or pregnancy-related
procedures/techniques/tests conducted by them in respect of each month by 5th day of the following
month to the concerned Appropriate Authority.6
These records are required to be maintained for a period of two years7 from the date of completion of
counselling , pre-natal diagnostic procedure or pre-natal diagnostic test or in the event of any legal
proceeding, till the final disposal of the legal proceeding.8
In case the records are maintained on computer or other electronic equipment, a printed copy of the
record is required to be taken and preserved after authentication by a person responsible for such
record.9
Records, at all reasonable times are to be made available for inspection to Appropriate Authority or
person authorized by the Appropriate Authority on this behalf.10
The Appropriate Authority is to maintain a permanent record of:
Applications for grant of certificate of registration;
Applications for renewal of certificate of registration as specified in Form H under the Rules;
Letters of intimation of every change of employee, place, address and equipment installed.11
4

Rule 9 (4) under the Rules.

5

Proviso to Section 4 (3) of the Act.

6

Rule 9(8) under the amended PNDT Rules.

7

Section 29 (1) of the Act.

8

Proviso to Section 29 (1) of the Act read with Rule 6 under the Rules.

9

Rule 9 (7) under the Rules.

10

Section 29 (2) of the Act.

11

Rule 9 (5) under the Rules.

37

<!-- page 45 -->

Chapter

VII

SEARCH AND SEIZURE

A search is an integral step in a criminal investigation. Whenever an appropriate authority or any
other authorised officer has reason to believe that an offence under the Act has been or is being committed, he may search for a genetic counselling centre, a genetic laboratory or genetic clinic or any other
place which is suspected to be conducting pre-natal diagnostic techniques.
The scope of the powers of the appropriate authority to search and seize is very wide and it includes
the power to:
Enter freely into the place of search.1
Search at all reasonable times.2
Examine and inspect all documents like:
i.

Registers

ii.

Records including consent forms, referral slips, charts, laboratory results, microscopic pictures

iii . Forms
iv. Books
v.

Pamphlets

vi. Advertisements
vii. Material objects like sonographic plates or slides
viii. Equipment like ultrasonography machines, needles, foetoscope etc.3
Seize and seal any document, record, material object or equipment etc. if there is reason to believe
that it may furnish evidence of commission of an offence punishable under the Act. 4
It has been clarified that ‘material object’ would include records, machines and equipments; and ‘seize’
and ‘seizure’ would include ‘seal’ and ‘sealing’ respectively.
1

Section 30(1) of the Act read with Rule 12 (1) under the PNDT Rules.

2

Id.

3

Section 30 (1) of the Act.

4

Id.

38

PNDT Act, 1994 & Amendments

<!-- page 46 -->

Under the amended Rules, it has been provided that every Genetic Counselling Centre, Genetic Laboratory,
Genetic Clinic, Ultrasound Clinic, Imaging Centre, nursing home, hospital, institute or any other place where
any of the machines or equipments capable of performing any procedure, technique or pre-natal determination of sex or selection of sex before or after conception is used, shall afford all reasonable facilities for
inspection of the place, equipment and records to the Appropriate Authority in this behalf for registration of
such institutions, by whatever name called, under the Act, or for detection of misuse of such facilities or
advertisement therefore, or for selection of sex before or after conception, or for detection/disclosure of sex
of foetus or for detection of cases of violation of the provisions of the Act in any other manner.
Further the Appropriate Authority may seal and seize any offending equiment if the facility has not
registered itself.5
The Act6 has to be read in conjunction with the rules7 under the Act and the Code of Criminal Procedure8 to ensure that the search and seizure is done in a fair and non-arbitrary manner.9
There are certain safeguards or prerequisites to be followed during the search and seizure to ensure
the aforementioned objective namely:

Search and Witnesses
A. During the search at least two independent witnesses of the locality should be present;10
B. If no such persons are available or willing to be a witness to the search, then two such persons of
another locality should be present;
C. The search should be made in the presence of the two or more independent witnesses;11
D. The witnesses are to be selected by the appropriate authority or the officer duly authorised to
conduct search;
E. The witnesses so selected should be unprejudiced and uninterested as the object of the section is to
ensure fair dealing and a feeling of confidence and security amongst public;
F. The witnesses may be summoned by Court to appear as witnesses.
G. Any person suspected of having any object on his person may also be searched. However, if such
person is a woman then, the search can be done only by a female officer.

Seizure and Preparation of List
A. A list of documents, records, material objects etc. seized during the search should be prepared in
duplicate and both copies of such list shall be signed on every page by the appropriate authority or
5

Rule 11 under the PNDT Rules.

6

Section 30 of the Act.

7

Rule 12 under the PNDT Rules.

8

Sections 99-105 of the Cr.P.C.

9

Section 30(2) of the Act.

10

Rule 12(1) under the PNDT Rules.

11

Proviso to Rule 12(2) under the PNDT Rules.

39

<!-- page 47 -->

the officer authorised and the witnesses to the seizure;12
B. Assistance of your office staff can always be taken during the process of search and seizure;
C. The list should be prepared at the place affecting the seizure and if it is not practicable to do so at
the place affecting the seizure then for reasons to be recorded in writing it can be done in any other
place but it has to be in the presence of the witnesses;
D. A copy of the list prepared must be handed over to the person from whose custody the document,
record or material object etc. is being seized or his representative under acknowledgment or sent by
registered post to him if he is not available at the place of effecting the seizure;13
E. The person from whose custody the document, record or material object etc. is being seized or his
representative should be permitted to attend during the search and seizure;
F. The appropriate authority or the officer duly authorised in this behalf may seize any document,
material object, record or equipment and take the same into safe custody;
G. It is preferable that along with the preparation of list of objects seized, a slip is made and pasted on
each object seized along with the date, time and the signature of the witnesses;
H. After a list of seizure is prepared the same must be sent to the Magistrate having jurisdiction or
incharge of the case within 24 hours of the seizure by the appropriate authority or officer duly
authorised. Permission to retain the seized objects should be obtained from the Court. The owner of
the seized object may make an application to the court for the release of the same. The court may do
so after imposing conditions for custody and taking a bond to the effect that, the objects must not be
misused for conducting sex-determination tests and that the objects must be produced in Court as
and when required etc.
I.

Police aid can be taken if the appropriate authority apprehends a law and order problem during
the process of search and seizure.

SEALING
A. If any material object seized is perishable in nature then arrangements shall be made promptly by
the appropriate authority or officer duly authorised for sealing, identification and preservation of
the same and send the same to a facility for test if so required;14
B. And till such arrangements for safe removal are made the refrigerator or other equipment used by
the Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic for preservation of such
material object seized shall be sealed; In case of such sealing it is important to mention the same in
the list of seizure prepared;15

12

Rule 12(2) under the PNDT Rules.

13

Rule 12 (3) under the PNDT Rules and the prroviso to the same.

14

Rule 12 (4) under the PNDT Rules.

15

Proviso to Rule 12 (4) under the PNDT Rules.

40

PNDT Act, 1994 & Amendments

<!-- page 48 -->

C. If the search and seizure is not completed in a day then the appropriate authority or officer duly
authorised may either seal the premises or mount a guard for safe keeping to prevent any tampering of the documents, records, material objects etc;16
D. After seizure the seized objects can be removed to your own premises or may be left in the custody
of a respectable person of the locality. If it is not possible to remove the seized objects, they may be
retained where they are found after taking a bond from the owner that the same would be produced before the court as and when required.
The machines of the facility that are seized and sealed may be released if such organization pays
penalty equal to five times of the registration fee to the Appropriate Authority concerned and gives an
undertaking that it shall not undertake detection of sex of foetus.17
The appropriate authority is duty bound to maintain systematic records of the search and seizure and
the same would also safeguard the appropriate authority against any allegations of abuse.

Collection of Evidence
The evidence that needs to be collected in order to make out a case under the PNDT Act varies depending upon the nature of the violation and in some cases the pieces of evidence can overlap.
I. Illegal Advertisement
In case any genetic counselling centre, genetic laboratory, genetic clinic, ultrasound clinic or imaging centre
advertises the facilities for pre-natal determination of sex or sex selection before or after conception, the
advertiser, the distributor, the person or centre who issues or causes to be issued an advertisement for
the aforementioned purpose will all be equally liable under the PNDT Act.
The documentary evidence will include:
A. The paper cutting of the advertisement, the name of the newspaper or magazine or any other
document which carries the advertisement, the date of the issuance of the advertisement;
B. The name of the advertiser, his place of business;
C. The name of the owner of the clinic, centre or laboratory issuing such advertisement, the address of
the said centre, laboratory or clinic;
D. The name of the distributor, his place of business ;
E. The photograph of the advertisement, the photograph of the hoarding, board, wall on which the
advertisement is present etc.
F. The letter heads, memorandum of association, annual reports, statements showing organizational
structure and ownership of the new-spaper, or distributorship, or the centre. This information has
to be collected in order to link the person to the violation.
The aforementioned list is not exhaustive but merely illustrative.

16

Rule 12 (5) under the PNDT Rules.

17

Rule 11(2) under the amended PNDT Rules.

41

<!-- page 49 -->

II. In case of conducting a test for determination of sex or communication of the sex of the foetus:
The investigation of cases of this nature is difficult because of the collusion between the doctor and the
persons wanting the test. Nevertheless there are ways and means to collect evidence in such cases as well:
The documentary evidence will include
(1)

referral slips

(2)

consent forms

(3)

laboratory results

(4)

microscopic pictures

(5)

sonographic plates or slides

(6)

registers containing names and addresses of patients and their families

(7)

case history of the patient

(8)

records of clients maintained on the computer or other electronic equipment can be taken on a
floppy or a printed copy of the same

(9)

floppy or printed copy of the ultrasound image of the foetus

(10) Receipt of fee paid for the test, details of cheque payment etc.
Oral and other evidence
Apart from documentary evidence, decoy witnesses namely pregnant women can also be sent to
suspected centres to find out if pre-natal determination of sex is done. If it is found that such centres are
conducting the tests the statements of such witnesses can be recorded by the appropriate authority.
Hidden tape recorders or cameras can also be used to record the conversation between the decoy
witness and the doctor. When decoy witnesses are sent for getting the tests done then the Chief Medical
Officer can at the same time raid the premises or inspect the premises and collect the evidence on the
spot. As and when decoy witnesses are used their statement should be taken on affidavit that they are
getting the tests done on humanitarian and on the grounds of public interest in order to assist the
appropriate authority.
In some cases women may themselves complain that they were forced to get the sex of the foetus
determined. Then that woman’s statement can be recorded and she can also be called as a witness to
depose about the doctor, the centre and the family members who forced her to get the test done.
III. In case of non-registration, cancellation or suspension of registration:
The collection of evidence in these cases is not very difficult as most of the records are available with the
appropriate authority itself.
The documentary and oral evidence will include
(a) Copy of the registration certificate
(b) Copy of the affidavit given by the owner that he will not conduct pre-natal determination of
sex.
(c) Copy of the particulars given about the qualifications of the employees while registration
42

PNDT Act, 1994 & Amendments

<!-- page 50 -->

(d) Documents collected from the MCI, the degree certificate of the medical practitioners (employees
of the centre) etc.
(e) Statements of decoy witnesses
(f)

The tape and video recording

(g) Other materials collected as evidence in case of conducting tests.
The complete evidence to be submitted before the Magistrate would include:
1. A copy of the complaint
2. A statement showing the list of witnesses both witnesses of the search and seizure and decoy
witnesses
3. The report of the search and seizure or commonly called Panchnamah
4. A copy of the all the documents collected.
5. Statements of witnesses if any.
6. Most essential would be the complete address of the genetic counselling centre, genetic clinic or genetic
laboratory.

43

<!-- page 51 -->

ANNEXURE-I

FORM I (under the MTP Regulations)
(See Regulation 3)
l…………………………………………………….
(Name and qualification of the Registered Medical Practitioner in block letters)
…………………………………………………….
(Full address of the Registered Medical Practitioner)
I,…………………………………………………
(Name and qualification of the Registered Medical Practitioner in block letters)
……………………………………………………
(Full address of the Registered Medical Practitioner) hereby certify that *I/we/am/are of opinion, formed in good faith,
that it is necessary to terminate the pregnancy of ………………………………….
(Full name of pregnant woman in block letters)
resident of……………………………………..
(Full address of woman in block letters)

for the reasons given below**,

*I/We hereby give intimation that *I/we terminated the pregnancy of the woman referred to above who bears the serial
No. ……………….in the Admission Register of the Hospital/approved place.
Signature of Registered Medical Practitioner
Place:
Date:

44

Signature of Registered Medical Practitioner

PNDT Act, 1994 & Amendments

<!-- page 52 -->

(i)

In order to save the life of the pregnant woman.

(ii)

In order to prevent grave injury to the physical or mental health of pregnant woman.

(iii) In view of the substantial risk that if the child was born it would suffer from such physical or mental abnormalities
as to be seriously handicapped.
(iv)

As the pregnancy is alleged by pregnant woman to have been caused by rape.

(v)

As the pregnancy has occurred as a result of failure of any contraceptive device or method used by the married
woman or her husband for the purpose of limiting the number of children.

Note- Account may be taken of the pregnant woman’s actual or reasonably foreseeable environment in determining
whether the continuance of a pregnancy would involve a grave injury to her physical or mental health.

Signature of Registered Medical Practitioner

Place:
Date:

Signature of Registered Medical Practitioner

*Strike out whichever is not applicable.
** Of the reasons specified items (i) to (v) write the one which is appropriate.

45

<!-- page 53 -->

ANNEXURE-II

FORM C*
(See rule 8)

I,………………………………………………………daughter/wife of………………………………………………………
aged about ……… years of ……………. (here state the permanent address) ……………………………
…………………………………………………………………at present residing at …………………………………………………
……………… …………………………………………………… do hereby give my consent of the termination of my pregnancy
at ……………………………………… (state the name of a place where the pregnancy is to be terminated).

Signature

Place:
Date:

(To be filled in by guardian where the woman is lunatic or minor)

I,………………………………………………………daughter/wife of………………………………………………………
aged about ……………..years of ……..…….. at present residing at ………………………………………………………………
………………………… (permanent address) ……………………………………………………….do hereby give my consent to
the termination of the pregnancy of my ward …………………………………………………………………who is a minor/
lunatic at ……………………… (place of termination of pregnancy).

Signature

Place:
Date:

*Under the MTP Act.

46

PNDT Act, 1994 & Amendments

<!-- page 54 -->

ANNEXURE-III

FORM-II*
[See Regulation 4 (5)]
1. Name of the State.
2. Name of Hospital/approved place.
3. Duration of pregnancy (give total number only):
(a) upto 12 weeks.
(b) Between 12-20 weeks.
4. Religion of woman:
(a) Hindu
(b) Muslim
(c) Christian
(d) Others
(e) Total
5. Termination with acceptance of contraception:
(a) Sterilization
(b) I.U.D.
6. Reasons for termination: (give total number under each sub-head):
(a) Danger to life of the pregnant woman.
(b) Grave injury to the mental health of the pregnant woman.
(c) Grave injury to the physical health of the pregnant woman.
(d) Pregnancy caused by rape.
(e) Substantial risk that if the child was born it would suffer from such physical or mental abnormalities as to be
seriously handicapped.
(f) Failure of any contraceptive device or method.
Signature of the Officer
In-charge with date.
* Under the MTP Act

47

<!-- page 55 -->

ANNEXURE-IV

FORM- III

(See Regulation 5)
Admission Register

(To be destroyed on the expiry of five years from the date of the last entry in the Register)
Sl.
No.

Date of Admission
Religion

Name of Patient

Wife/
Daughter

Age

2

3

4

5

6

Duration of
Pregnancy

Reasons on
which
Pregnancy
is Terminated

Date of
termination
of
pregnancy

Date of
discharge
of patient

Result and
Remarks

8

9

10

11

12

1

Address

7

Name of Registered Medical
Practitioner(s) by whom the
Opinion is formed
13

48

Name of Registered Medical
Practitioner(s) by whom pregnancy
is terminated
14

PNDT Act, 1994 & Amendments

<!-- page 56 -->

ANNEXURE-V

(Draft of the type of complaint that can be made to the Appropriate Authority)
The Appropriate Authority

Subject: Complaint of breach of provisions of the Pre-Natal Diagnostic
Techniques (Regulation and Prevention of Misuse) Act, 1994
Dear Sir,
We are a non-governmental organization consisting of lawyers and social workers working in different states of India
and working on issues relating to discrimination against women including female foeticide. We were shocked to see
the news item dated _______________ appearing in the__________________(name of the newspaper/magazine etc.)
and we wish to bring the same to your notice.
Your kind attention is invited for immediate investigation and action under Section 17(4) (c) of the Pre-Natal Diagnostic
Techniques (Regulation and Prevention of Misuse) Act, 1994 to the news item that appeared in
the_______________(name of the newspaper/magazine etc.) dated_________________ . A copy of the news item
which is self-explanatory is annexed herewith for your ready reference.
As you are aware, the object of the Act includes regulation of the use of pre-natal diagnostic techniques and the
prevention of the misuse of such techniques for the purpose of pre-natal sex determination leading to female foeticide,
and for matters connected therewith or incidental thereto.
Despite the existence of the Act on the statute books since 1994, the latest Census Report of 2001 shows that the sex ratio
has been declining in an alarming way and it has come down from 882 in 1991 to 874 in 2001 in the State of Punjab. The
sex ratio in case of age group of 0-6 is 793 according to 2001 Census whereas it was 875 in the State of Punjab according
to 1991 census which accentuates the situation as it shows that the number of females born is declining.
That you being the Appropriate Authority appointed under the Act are empowered to investigate any violation or
possible violation of the PNDT Act and take necessary action.
That a plain reading of the newspaper article demonstrates that there has been a clear cut violation of the provisions of
the PNDT Act and that pre-natal diagnostic techniques are misused for the purpose of sex determination and the sex
of the child is being conveyed to the family members.
That the said article describes the two diagnostic centres in ________________ (areas or the names of the centres)
which are being run by ____________________ (names of the doctors or owners). That one of the said clinics/nursing
homes contains ______________________ (name of the offending equipment such as ultrasound machine) and is
fully equipped with ultra sound and X-ray facilities.
That the appropriate authority under Section 30 of the Act has been granted very wide powers and the same is
reproduced herein below:
Section 30(1): If the appropriate authority has reason to believe that an offence under this Act has been or is
being committed at any Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic or any other place,
such authority or any officer authorised thereof in this behalf may subject to such rules as may be prescribed,
enter and search at all reasonable times with such assistance, if any, as such authority or officer considers

49

<!-- page 57 -->

necessary, such Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic or any other place and
examine any record, register, document book, pamphlet, advertisement or any other material, object found
therein and seize and seal the same if such authority or officer has reason to believe that it may furnish
evidence of the commission of an offence punishable under this Act.
That further Section 31 of the Act gives protection to the appropriate authority or any officer authorised thereunder for
action taken in good faith.
That in view of the aforementioned facts and circumstances, you are requested to take immediate action and investigate
into the matter without any delay.
Kindly treat this letter as a complaint and take appropriate action including filing of a criminal complaint before the
Metropolitan Magistrate or a Judicial Magistrate under Section 28 (1) (a) of the Act.
Acknowledgement of this complaint will be appreciated.

Yours sincerely,

50

PNDT Act, 1994 & Amendments

<!-- page 58 -->

The Appropriate Authority
Under the Pre-Natal Diagnostic Techniques Act
Government of NCT
Old Secretariat
Rajpur Road
Delhi
Dear Sir,
Subject: Complaint of breach of provisions of the Pre-Natal Diagnostic
Techniques (Regulation and Prevention of Misuse) Act, 1994
We public spirited lawyers working on issues relating to discrimination against women including female foeticide.
We were shocked to see an advertisement in ______________________ (name of the place) edition of
____________________ (the newspaper/magazine) which is circulated throughout India. The said advertisement
openly advertises sex determination tests. We wish to bring the same to your notice. A copy of the said advertisement
is annexed hereto. It is pertinent to mention that has its registered office at ______________________ (name of the
place).
As you are aware, the object of the Act includes regulation of the use of pre-natal diagnostic techniques and the
prevention of the misuse of such techniques for the purpose of pre-natal sex determination leading to female foeticide,
and for matters connected therewith or incidental thereto. That the said advertisement and what it seeks to provide is
clearly violative of the lofty ideals and intention of the Act.
The advertisement in blatant violation of the PNDT Act reads: (give the wordings of the advertisement)
That the said advertisement is in clear violation of different provisions of the PNDT Act which have been reproduced
herein below:
22. Prohibition of advertisement relating to pre-natal determination of sex and punishment for
contravention- (1) No person, organization, Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic,
including clinic, laboratory or centre having ultrasound machine or imaging machine or scanner or any other
technology capable of undertaking determination of sex of foetus or sex selection shall issue, publish, distribute,
communicate or cause to be issued, published, distributed or communicated any advertisement, in any
form, including internet, regarding facilities of pre-natal determination of sex or sex selection before
conception available at such centre, laboratory, clinic or at any other place.
(2) No person or organization including Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic
shall issue, publish, distribute, communicate or cause to be issued, published, distributed or communicated
any advertisement in any manner regarding pre-natal determination or pre-conception selection of sex by
any means whatsoever, scientific or otherwise.
(3) Any person who contravenes the provisions of sub-section (1) or sub-section (2) shall be punishable with
imprisonment for a term which may extend to three years and with fine which may extend to ten thousand
rupees.
Explanation-For the purposes of this section, “advertisement” includes any notice, circular, label, wrapper or
any other document including advertisement through internet or any other media in electronic or print form
and also includes any visible representation made by means of any hoarding, wall-painting, signal, light,
sound, smoke or gas.
This section prohibits advertisement by any means, by any person about conducting sex determination tests
anywhere. Therefore the aforementioned advertisement clearly falls foul of this provision.

51

<!-- page 59 -->

Section 5(2). “No person including the person conducting pre-natal diagnostic procedures shall communicate
to the pregnant woman concerned or her relatives or any other person the sex of the foetus by words, signs or
in any other manner”
Section 6-Determination of sex prohibited- on and from the commencement of this Act,(a) No Genetic Counselling centre or Genetic Laborartory or Genetic Clinic shall conduct or cause to be
conducted in its centre, laboratory or clinic, pre-natal diagnostic techniques including ultrasonography,
for the purpose or determining the sex of a foetus;
(b) No person shall conduct or cause to be conducted any pre-natal doagontic techniques including
ultrasonography for the purpose of determining the sex of the foetus.
(c) No person shall, by whatever means, cause or allow to be caused selection of sex before or after conception.
That you being the appropriate authority appointed under the Act are empowered to investigate any violation or
possible violation of the PNDT Act and take necessary action.
That the appropriate authority under Section 30 of the Act has been granted very wide powers and the same is
reproduced herein below:
Section 30(1): If the appropriate authority has reason to believe that an offence under this Act has been or is
being committed at any Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic or any other place,
such authority or any officer authorised thereof in this behalf may subject to such rules as may be prescribed,
enter and search at all reasonable times with such assistance, if any, as such authority or officer considers
necessary, such Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic or any other place and
examine any record, register, document book, pamphlet, advertisement or any other material, object found
therein and seize and seal the same if such authority or officer has reason to believe that it may furnish
evidence of the commission of an offence punishable under this Act.
That further Section 31 of the Act gives protection to the appropriate authority or any officer authorized thereunder for
action taken in good faith.
That further the Supreme Court in its order dated 4.5.2001 has directed the appropriate authorities to take prompt
action against any person or body who issues or causes to be issued any advertisement in violation of section 22 of the
Act.
That in view of the aforementioned facts and circumstances, you are requested to take immediate action and investigate
into the matter without any delay under Section 17(4) (c) of the Pre-Natal Diagnostic Techniques (Regulation and
Prevention of Misuse) Act, 1994.
Kindly treat this letter as a complaint and take appropriate action including filing of a criminal complaint before the
Metropolitan Magistrate or a Judicial Magistrate under Section 28 (1) (a) of the Act.
Acknowledgement of this complaint will be appreciated.

Yours sincerely,

52

PNDT Act, 1994 & Amendments

<!-- page 60 -->

ANNEXURE-VI

Though the Appropriate Authority can file a complaint in the Court on the basis of a complaint received by it or suo
motu, in some cases, if found necessary, show cause notice may be issued. The format of the same may be as under:
From

To

District Appropriate Authority

Subject: Show Cause Notice under Sections 3 and 18 of the
PNDT Act, 1994 read with the Rules, 1996.

Refer to subject cited above and the inspection dated _____________ by an inspection team of (names of the members
comprising the inspection team) and subsequent inspection dated_____________(if any subsequent inspection has
also been undertaken) by an inspection team of__________________ (names of the members).
You were found present at the time of inspection along with patient namely____________________
w/o_____________________a pregnant woman who had come for ultrasonography by Dr_____________ at
_____________ centre. You stated before the inspection team that you are a paid employee and assisting
Dr_____________ in ultrasonography including those of pregnant women (or you have stated before the inspection
team that you were providing space and other facilities to Dr.___________________ for conducting ultrasonography
on pregnant women and other patients. Dr. _____________ visits your laboratory with his portable ultrasound
machine on receiving your telephonic message for performing ultrasonogrpahy).
You also disclosed that Dr._______________________ used to charge patients for conducting ultrasonography
including on pregnant women and records with respect to these diagnostic tests were maintained by him and you also
handed over certified copies of your records/documents namely,______________________ (or you did not maintain
records of these diagnostic techniques and could not produce the same).
Since you were assisting in the conduct of pre-natal diagnostic techniques for the purpose of determination of the sex
of the foetus, you are hereby issued a show cause notice under Section 3 read with Section 18, Section 5 read with Rule
20 and Section 29 read with Rule 9 of the PNDT Act read with the PNDT Rules, 1996 why legal action should not be
taken against you. Your reply must reach within 7 days of receipt of this notice.

District Appropriate Authority

53

<!-- page 61 -->

ANNEXURE-VII

IN THE COURT OF CHIEF METROPOLITAN MAGISTRATE
………., DELHI
CASE No.
OF
BETWEEN:
Dr. …………………………………………………………………
APPROPRIATE AUTHORITY/ AUTHORISED OFFICER
………… DISTRICT

COMPLAINANT

AND
……………………..

ACCUSED

COMPLAINT UNDER SECTION 28 OF THE PRE-NATAL DIAGNOSTIC
TECHNIQUES (REGULATION AND PREVENTION OF MISUSE) ACT, 1994 READ
WITH THE RULES, 1996 AND SECTION 200 OF THE CODE OF CRIMINAL
PROCEDURE
MOST RESPECTFULLY SHOWETH:
1.

That the Complainant Dr. ______________________ s/o ______________________ aged about _____________
years functioning as District Health and Family Welfare officer of the District_____________ and being appointed
as the Appropriate Authority under the Pre-Natal Diagnostic Techniques (Regulation and Prevention of Misuse),
Act, 1994 (hereinafter referred to as the Act) vide Government Notification dated_____________under Section 2(a)
of the Act and the Rules framed thereunder.

2.

That in discharge of my duties under the Act, I have conducted a survey to ascertain how many Genetic Counselling
Centres/Genetic Laboratories/Genetic Clinics and Ultrasound scanning centres are existing in the City/District of
______________________ (name of the place). I came to know that the particular centre (can give the name of the
centre) is in existence since ______________________ and after verification, I found that such centre is not
registered with the Appropriate Authority. On personal verification of the relevant register maintained for that
purpose in the office of the Appropriate Authority as contemplated under Chapter IV, Section 18, it was found that
no registration certificate has been issued to this centre. Moreover no application has also been made by the centre
for registration as contemplated under the Act.

3.

That the complainant along with two persons 1 and 2 (two respectable and independent persons of the locality)
visited the premises of the centre at ______________________ (time of arrival at the place)
bearing______________________ (address of the centre) to verify and confirm the compliance with the provisions
of this Act. On verification, I found the following equipments installed and being used by the centre:

54

PNDT Act, 1994 & Amendments

<!-- page 62 -->

4.

That the equipments were housed in: (give details of the place of installation)

5.

That on enquiry it was learnt that the centre is being run by ______________________ (name of the owner and the
details of the staff employed therein). It is pertinent that the owner of the centre, namely accused No. _____________
failed to produce the certificate of registration on demand. The copy of the certificate of registration was also not
displayed as contemplated in the Act. It is submitted that the owner admitted before the inspection team that the
premises is not registered under the Act.

6.

That in view of the violation of the provisions of the Act, the below mentioned articles and relevant documents in
proof of the running of the centre were seized:

These were seized under a panchnama (mahzar) prepared in the presence of panchas______________________
(details of mahzar). It was found that these equipments are used/capable of being used for the purpose of detection of
the sex of the foetus.
7.

That the material as seized above proves that an offence has been committed under the PNDT Act, punishable
under Section 23 read with Section 25.

8.

That this Hon’ble Court has the jurisdiction to try the present matter.

9.

That I being a public servant may be exempted from personal appearances on every date of the hearing.

That in the facts and circumstances of the instant case and in the interests of justice, it is respectfully prayed that this
Hon’ble Court may be graciously pleased to take cognizance of the offence committed by the accused and punish him/
her in accordance with law.
Sd/Appropriate Authority with Seal
Place:
Date:
(If it is a case where the doctors have been caught conducting sex-determination tests or the complaint is being filed for
violation of other provisions of the Act, then the relevant facts can be stated and the material documents annexed with
the complaint)

55

<!-- page 63 -->

ANNEXURE-VIII

FORMAT OF REPLY TO ANTICIPATORY BAIL APPLICATION
(In a similar manner, reply to a bail application can be drafted)
IN THE COURT OF CHIEF JUDICIAL MAGISTRATE
COMPLAINT NO.————————2001
IN THE MATTER OF:
STATE
THROUGH DISTRICT APPROPRIATE
AUTHORITY CUM CIVIL SURGEON
COMPLAINANT
VERSUS
ACCUSED
REPLY TO ANTICIPATORY BAIL APPLICATION
FILED ON BEHALF OF THE ACCUSED
1.

That the aforementioned case is under a special statute specially enacted for the protection and promotion of
women and the girl child. The same being the Pre-Natal Diagnostic Techniques (Regulation and Prevention of
Misuse) Act 1994 and the Rules of 1996 made thereunder. That the said Act is a social welfare legislation and has
been legislated as part of a special provision for women under Article 15 (3) of the Constitution. That a legislation
of this nature has been enacted in the specific context of India and its problems relating to female foeticide and
deserves the highest respect and protection.

2.

That the Statement of Objects and Reasons of this special enactment are:
“An Act to provide for the prohibition of sex selection, before or after conception, and for regulation of
pre-natal diagnostic techniques for the purposes of detecting abnormalities or metabolic disorders or
chromosomal abnormalities or certain congenital malformations or sex-linked disorders and for the
prevention of their misuse for sex determination leading to female foeticide and for matters connected
therewith or incidental thereto.”

3.

That this enactment seeks to inter-alia prevent and prohibit pre-natal sex-determination and the salient features
of the Act are:
Registration of genetic counselling centres, genetic clinics and genetic laboratories,
Prescribed qualifications for those employed in the aforementioned centres, clinics or laboratories.
Prohibition on conducting any test or procedure without the written consent of the woman on whom the test
is being performed.
Prohibition on conducting any pre-natal diagnostic technique including ultrasonography for the purpose of
determining the sex of the foetus.
Prohibition on the communication of the sex of the foetus to the pregnant woman or her relatives.

56

PNDT Act, 1994 & Amendments

<!-- page 64 -->

Prohibition on any person, organization, genetic counselling centre, genetic laboratory or genetic clinic from
issuing or causing to be issued any advertisement in any manner regarding facilities of pre-natal determination
of sex available.
Appointment of Appropriate Authorities under the Act to investigate and prosecute complaints under the Act
Maintenance of all records, charts, forms, reports, consent letters and all documents relating to the pre-natal
diagnostic centre and tests.
4.

That this Act was enacted specially to check the growing disproportionality in the sex ratio among men and
women in the last few years. The latest statistics as seen in the census 2001 shows that the sex ratio in Haryana
has declined to 820 females for every 1000 males.

5.

That illegal pre-natal diagnostic centres are mushrooming all over the country where sex of the foetus is determined
and communicated to the concerned people leading to large-scale abortions of female foetus. These figures are
shocking and a strict implementation of the Act is the immediate need of the day. The law and law enforcement
agencies have to come down heavily on the violators of the Act to bring about any improvement to the present
scenario.

6.

That the anticipatory bail application should be rejected on the following among other grounds (the grounds as
may be relevant to a particular case may be used):
There is a prima facie case of breach of the provisions of the Act by the accused;
That the accused have after the registration of the complaint illegally removed the word ultrasonography
from the letterpads of their centres and from their name board and thereby tampered with evidence;
That the mandatory records as required under the Act have not been maintained by the accused in violation
of the Act;
That the ultrasound is being conducted by the accused on pregnant women without taking their written
consent in violation of the Act;
That the centres run by the accused have not been registered as required under the Act;
That the employees working in the said centres do not possess the necessary qualifications as required under
the Act;
That the accused are determining the sex of the foetus and communicating the same to the persons concerned
in violation of the Act;
That the accused are publishing or causing to be published advertisements advertising facilities for pre-natal
determination of sex;
That despite repeated show cause notices and applications for production of documents the accused have
not done so;
That the accused have not been present for investigation despite repeated requests and there is a serious
threat that they are trying to evade the processes of the law.
That the accused have already threatened the members of the appropriate authority.
That there is a grave threat of their intimidating and buying of the witnesses as they are powerful members of
the society.
That the Delhi High Court in the case of Court of On its own Motion v. Vishnu Pandit and another, 1993
Cr. L.J. 2025 has held that “crime against women is on the increase and courts have to be circumspect in
granting bail to the accused persons accused of committing crimes against women”
That in such cases of threat to the very life of the girl child, no bail should be granted.

57

<!-- page 65 -->

7.

That any violation of the provisions of Act is cognizable, non-bailable and non compoundable. The penalty for
the violation of any of the provisions of the Act is three years with fine. Therefore bail especially anticipatory bail
should not be granted to the accused.

8.

That the Hon’ble Supreme Court has in the case of CEHAT v Union Of India and others held that:
“1. Appropriate Authorities are directed to take prompt action against any person or body who issues or causes
to be issued any advertisement in violation of section 22 of the Act.
2. Appropriate Authorities are directed to take prompt action against all bodies specified in section 3 of the Act as
also against persons who are operating without a valid certificate of registration under the Act.”
Thus the Hon’ble Supreme Court has directed that prompt action should be taken against advertisements issued
in violation of the Act as well as in cases where registration has not been obtained.

9.

That there is a prima facie case of violation of the provisions of the Act. That irreparable loss would be caused to
the investigation and all the efforts of the Appropriate Authority if the accused are granted anticipatory bail. That
the balance of convenience lies in favour of the State and against the accused.

That in view of the aforementioned facts and circumstances, it is prayed that this Hon’ble Court be pleased to reject the
anticipatory bail applications of all the accused.
DATED:
PLACE:

58

APPROPRIATE AUTHORITY

PNDT Act, 1994 & Amendments

<!-- page 66 -->

ANNEXURE-IX

FORMAT
(14.2.2003)

Quarterly report on
Implementation of the pre-conception and pre-natal diagnostic techniques
(Prohibition of sex selection) act, 1994

Report for the quarter ended on : .....................................................................
Name of the State/Union Territory: ................................................................
Sl.
No.

Items

1.

Number of facilities registered in the State/UT as:
(a) Genetic Counselling Centres
(b) Genetic Laboratories
(c) Genetic Clinics
(d) Ultrasound Clinics/Imaging Centres
(e) Jointly as Genetic Counselling Centre/Genetic
Laboratory/Genetic Clinic/Ultrasound Clinics/
Imaging Centres or any combination thereof
(f) Mobile Clinics (Vehicle)
(g) Other bodies like IVF centres/Infertility cure centres/
fertility centres etc. using equipments/techniques
capable of making sex selection before or after
conception

2.

Of the number shown in item (1) above, number of
Government facilities in the State/UT (including Central
Government/State/UT Government/Zila Parishad/
Municipal):
(a) Genetic Counselling Centres
(b) Genetic Laboratories
(c) Genetic Clinics
(d) Ultrasound Clinics/Imaging Centres
(e) Jointly as Genetic Counselling Centre/Genetic
Laboratory/Genetic Clinic/Ultrasound Clinics/
Imaging Centres or any combination thereof
(f) Mobile Clinics (Vehicle)
(g) Other bodies like IVF centres/Infertility cure centres/
fertility centres etc. using equipments/techniques
capable of making sex selection before or after
conception

During
the quarter

Total upto this Quarter’s end
(since inception of the Act)

59

<!-- page 67 -->

Sl.
No.

60

Items

3.

Number of applications for registration rejected, for:
(a) Genetic Counselling Centres
(b) Genetic Laboratories
(c) Genetic Clinics
(d) Ultrasound Clinics/Imaging Centres
(e) Jointly as Genetic Counselling Centre/Genetic
Laboratory/Genetic Clinic/Ultrasound Clinics/
Imaging Centres or any combination thereof
(f) Mobile Clinics (Vehicle)
(g) Other bodies like IVF centres/Infertility cure centres/
fertility centres etc. using equipments/ techniques
capable of making sex selection before or after
conception
(Please give the reason for rejection of application in
each case)

4.

Number of renewals of registration in respect of:
(a) Genetic Counselling Centres
(b) Genetic Laboratories
(c) Genetic Clinics
(d) Ultrasound Clinics/Imaging Centres
(e) Jointly as Genetic Counselling Centre/Genetic
Laboratory/Genetic Clinic/Ultrasound Clinics/
Imaging Centres or any combination thereof
(f) Mobile Clinics (Vehicle)
(g) Other bodies like IVF centres/Infertility cure centres/
fertility centres etc. using equipments/techniques
capable of making sex selection before or after
conception

5.

Number of premises inspected by the Appropriate
Authorities or persons authorized by the Appropriate
Authorities during the quarter for registration/renewal
of registration/cancellation or suspension of
registration/ violations of the Act/Rules
(Please give details on separate sheet)

6.

Number of suspensions or cancellations of registration
under section 20 of the Pre-natal Diagnostic Techniques
(Regulation and Prevention of Misuse) Act, 1994 in the
State/UT in respect of:
(a) Genetic Counselling Centres
(b) Genetic Laboratories
(c) Genetic Clinics
(d) Ultrasound Clinics/Imaging Centres
(e) Jointly as Genetic Counselling Centre/Genetic
Laboratory/Genetic Clinic/Ultrasound Clinics/
Imaging Centres or any combination thereof

During
the quarter

Total upto this Quarter’s end
(since inception of the Act)

PNDT Act, 1994 & Amendments

<!-- page 68 -->

Sl.
No.

Items

During
the quarter

Total upto this Quarter’s end
(since inception of the Act)

(f) Mobile Clinics (Vehicle)
(g) Other bodies like IVF centres/Infertility cure centres/
fertility centres etc. using equipments/techniques
capable of making sex selection before or after
conception
(Please give details on a separate sheet)
7.

Action taken to create public awareness against the
practice of preconception sex selection, pre-natal
determination of sex and female foeticide through:
(a) Print Media
(b) Electronic Media including Radio and TV
(c) Hoarding
(d) Other appropriate means
(Please give details on separate sheet)

8.

(i) Dated of the meetings of the State Supervisory Board
constituted under section 16A of the ACT (at least
once in 4 months).
(ii) Dates of the meetings of the States level Multimember
Appropriate Authority appointed at the State/UT level
under section 17(3) (a) of the Act as amended vide
clause 15 of the PNDT Amendment Act, 2002.
(iii) Dates of the meetings of each Advisory Committee
(the intervening period between meetings of Advisory
Committees should not exceed 60 days).
(Please give details of the meetings of each and every
Advisory Committee functioning at State, District and
Sub-District level on separate sheet)

9.

Action taken to publish list of members of the State
Supervisory Board, Appropriate Authorities and Advisory
Committees through:
(a) Print Media
(b) Electronic Media
(c) Hoardings
(d) Any other appropriate means
(Please give details on separate sheet)

10.

Action taken inclusive of search and seizure of machines,
records etc. against bodies/person operating without a
valid certifi cate of registration under the Act.
(Please give details on separate sheet)

11.

Information/Report on survey of bodies i.e. Genetic
Counselling Centres, Genetic Laboratories, Genetic
Clinics/Ultrasound Clinic/Imagine Centre/Mobile
Clinic/other clinical establishments to unearth
violation(s) of provisions of the Act/Rules.
(Please give details on separate sheet)
61

<!-- page 69 -->

11.
Sl.
No.

During
the quarter

Items

12.

Details of cases fi led against violators of the Act/Rules for:
(i)
Non-registration
(ii) Non-maintenance of Records
(iii) Communication of sex of foetus
(iv) Advertisement about facilities for pre-conception /
pre-natal sex-selection.
(v) Number of cases decided/closed.
(vi) Number of ultrasound machines/image scanners
sealed/seized for –
(a) non-registration of clinic/centre
(b) other violations of the Act/Rules
(vii) Number of ultrasound machines/image scanners
released
(Please give details on separate sheet)

13.

Number of complaints received by the Appropriate
Authorities under the Act and details of action taken
pursuant thereto.

Total upto this Quarter’s end
(since inception of the Act)

(Please give details on separate sheet)
14.

Number of nature of the awareness campaigns conducted
and results fl owing therefrom.
(Please give details including details of advertisements/
posters/handbills etc. on separate sheet)

15.

Number of complaints fi led in courts in the State/UT
by Appropriate Authorities/others).
(please give details on separate sheet)

16.

Details of action taken on the information/report
received from the manufacturer, importer, dealer or
supplier etc., of ultrasound machines/imaging machines
etc. regarding details of those to whom the machines/
equipments have been provided during the quarter.

17.

Details of incidence coming to the notice of the State/UT
regarding sale of ultrasound machines/imaging machines
etc. to bodies not registered under the Act and action take
thereon.

Certified that all bodies/persons using ultra-sound machines capable of detecting sex of foetus in my
area of jurisdiction have been registered under the Act and prosecution has been launched against
those who have not got themselves registered.
Date:
Signature:
Place:

62

Name and Designation
(For and on behalf of State Government/U.T. Administration)
PNDT Act, 1994 & Amendments

<!-- page 70 -->

APPENDIX-I

THE PRE-NATAL DIAGNOSTIC TECHNIQUES
(REGULATION AND PREVENTION OF MISUSE) ACT, 1994
(ACT NO. 57 OF 1994)
AND
THE PRE-NATAL DIAGNOSTIC TECHNIQUES
(REGULATION AND PREVENTION OF MISUSE) AMENDMENT ACT, 2002
(No.14 OF 2003)

[20th September, 1994]
An Act to provide for the prohibition of sex selection, before or after conception, and for regulation of prenatal diagnostic techniques for the purposes of detecting genetic abnormalities or metabolic disorders or
chromosomal abnormalities or certain congenital malformations or sex-linked disorders and for the prevention of their misuse for sex determination leading to female foeticide; and, for matters connected therewith or
incidental thereto.
BE it enacted by Parliament in the Forty-fifth Year of the Republic of India as follows:—
CHAPTER I
PRELIMINARY
1. Short title, extent and commencement.- (1) This Act may be called the Pre-conception and Prenatal Diagnostic Techniques (Prohibition of Sex Selection) Act, 1994.
(2)It shall extend to the whole of India except the State of Jammu and Kashmir.
(3)It shall come into force on such date as the Central Government may, by notification in the
Official Gazette, appoint.
2. Definitions.- In this Act, unless the context otherwise requires,—
(a) “Appropriate Authority” means the Appropriate Authority appointed under section 17;
(b) “Board” means the Central Supervisory Board constituted under section 7;
(ba) ”conceptus” means any product of conception at any stage of development from fertilization
until birth including extra embryonic membranes as well as the embryo or foetus;
(bb) “embryo” means a developing human organism after fertilization till the end of eight weeks
(fifty-six days);

63

<!-- page 71 -->

(bc) “foetus” means a human organism during the period of its development beginning on the fiftyseventh day following fertilization or creation (excluding any time in which its development
has been suspended) and ending at the birth;
(c) “Genetic Counseling Centre” means an institute, hospital, nursing home or any place, by whatever name called, which provides for genetic counselling to patients;
(d) “Genetic Clinic” means a clinic, institute, hospital, nursing home or any place, by whatever
name called, which is used for conducting pre-natal diagnostic procedures.
Explanation- For the purposes of this clause, ‘Genetic Clinic’ includes a vehicle, where ultrasound machine or imaging machine or scanner or other equipment capable of determining sex
of the foetus or a portable equipment which has the potential for detection of sex during pregnancy or selection of sex before conception, is used.
(e) “Genetic Laboratory” means a laboratory and includes a place where facilities are provided for
conducting analysis or tests of samples received from Genetic Clinic for pre-natal diagnostic test.
Explanation- For the purposes of this clause, ‘Genetic Laboratory’ includes a place where ultrasound machine or imaging machine or scanner or other equipment capable of determining sex
of the foetus or a portable equipment which has the potential for detection of sex during pregnancy or selection of sex before conception, is used.
(f) “Gynaecologist” means a person who possesses a post- graduate qualification in gynaecology
and obstetrics;
(g) “Medical geneticist” includes a person who possesses a degree or diploma in genetic science in
the fields of sex selection and pre-natal diagnostic techniques or has experience of not less than
two years in such field after obtaining—
(i) any one of the medical qualifications recognised under the Indian Medical Council Act,
1956 (102 of 1956); or
(ii) a post-graduate degree in biological sciences;
(h) “Pediatrician” means a person who possesses a post-graduate qualification in pediatrics;
(i) “pre-natal diagnostic procedures” means all gynaecological or obstetrical or medical procedures such as ultrasonography, foetoscopy, taking or removing samples of amniotic fluid, chorionic villi, blood or any other tissue or fluid of a man, or of a woman for being sent to a Genetic
Laboratory or Genetic Clinic for conducting any type of analysis or pre-natal diagnostic tests
for selection of sex before or after conception;
(j) “pre-natal diagnostic techniques” includes all pre-natal diagnostic procedures and pre-natal
diagnostic tests;
(k) “pre-natal diagnostic test” means ultrasonography or any test or analysis of amniotic fluid,
chorionic villi, blood or any tissue or fluid of a pregnant woman or conceptus conducted to
detect genetic or metabolic disorders or chromosomal abnormalities or congenital anomalies or
haemoglobinopathies or sex-linked diseases;
(l) “prescribed” means prescribed by rules made under this Act;
(m) “registered medical practitioner” means a medical practitioner who possesses any recognised
64

PNDT Act, 1994 & Amendments

<!-- page 72 -->

medical qualification as defined in clause (h) of section 2 of the Indian Medical Council Act,
1956, (102 of 1956.) and whose name has been entered in a State Medical Register;
(n) “regulations” means regulations framed by the Board under this Act;
(o) “sex selection” includes any procedure, technique, test or administration or prescription or
provision of anything for the purpose of ensuring or increasing the probability that an embryo
will be of a particular sex;
(p) “sonologist or imaging specialist” means a person who possesses any one of the medical qualifications recognized under the Indian Medical Council Act, 1956 or who possesses a postgraduate qualification in ultrasonography or imaging techniques or radiology;
(q) “State Board” means a State Supervisory Board or a Union territory Supervisory Board constituted under Section 16A;
(r) “State Government” in relation to Union territory with Legislature means the Administrator of
that Union territory appointed by the President under article 239 of Constitution.
CHAPTER II
REGULATION OF GENETIC COUNSELLING CENTRES, GENETIC
LABORATORIES AND GENETIC CLINICS
3. Regulation of Genetic Counselling Centres, Genetic Laboratories and Genetic Clinics.- On and
from the commencement of this Act,—
1. no Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic unless registered under
this Act, shall conduct or associate with, or help in, conducting activities relating to prenatal diagnostic techniques;
2. no Genetic Counselling Centre or Genetic Laboratory or Genetic Clinic shall employ or cause to
be employed or take services of any person, whether on honorary basis or on payment who does
not possess qualifications as may be prescribed;
3. no medical geneticist, gynaecologist, paediatrician, registered medical practitioner or any other
person shall conduct or cause to be conducted or aid in conducting by himself or through any
other person, any pre-natal diagnostic techniques at a place other than a place registered
under this Act.
3A. Prohibition of sex-selection- No person, including a specialist or a team of specialists in the field of
infertility, shall conduct or cause to be conducted or aid in conducting by himself or by any other
person, sex selection on a woman or a man or on both or on any tissue, embryo, conceptus, fluid or
gametes derived from either or both of them.
3B. Prohibition on sale of ultrasound machines, etc., to persons, laboratories, clinics, etc. not registered under the Act.- No person shall sell any ultrasound machine or imaging machine or scanner
or any other equipment capable of detecting sex of foetus to any Genetic Counselling Centre, Genetic Laboratory, Genetic Clinic or any other person not registered under the Act.

65

<!-- page 73 -->

CHAPTER III
REGULATION OF PRE-NATAL DIAGNOSTIC TECHNIQUES
4. Regulation of pre-natal diagnostic techniques.- On and from the commencement of this Act,—
1. no place including a registered Genetic Counselling Centre or Genetic Laboratory or Genetic
Clinic shall be used or caused to be used by any person for conducting pre-natal diagnostic
techniques except for the purposes specified in clause (2) and after satisfying any of the conditions specified in clause (3);
2. no pre-natal diagnostic techniques shall be conducted except for the purposes of detection of
any of the following abnormalities, namely:—
(i) chromosomal abnormalities;
(ii) genetic metabolic diseases;
(iii) haemoglobinopathies;
(iv) sex-linked genetic diseases;
(v) congenital anomalies;
(vi) any other abnormalities or diseases as may be specified by the Central Supervisory Board;
3. no pre-natal diagnostic techniques shall be used or conducted unless the person qualified to do
so is satisfied for reasons to be recorded in writing that any of the following conditions are
fulfilled, namely:—
(i) age of the pregnant woman is above thirty-five years;
(ii) the pregnant woman has undergone of two or more spontaneous abortions or foetal loss;
(iii) the pregnant woman had been exposed to potentially teratogenic agents such as drugs,
radiation, infection or chemicals;
(iv) the pregnant woman or her spouse has a family history of mental retardation or physical
deformities such as, spasticity or any other genetic disease;
(v) any other condition as may be specified by the Central Supervisory Board;
Provided that the person conducting ultrasonography on a pregnant woman shall keep complete record
thereof in the clinic in such manner, as may be prescribed, and any deficiency or inaccuracy found
therein shall amount to contravention of provisions of section 5 or section 6 unless contrary is proved
by the person conducting such ultrasonography;
4. no person including a relative or husband of the pregnant woman shall seek or encourage the conduct of any pre-natal diagnostic techniques on her except for the purposes specified in clause (2).
5. no person including a relative or husband of a woman shall seek or encourage the conduct of
any sex-selection technique on her or him or both.
5. Written consent of pregnant woman and prohibition of communicating the sex of foetus.
1. No person referred to in clause (2) of section 3 shall conduct the pre-natal diagnostic procedures
unless—
66

PNDT Act, 1994 & Amendments

<!-- page 74 -->

(a) he has explained all known side and after effects of such procedures to the pregnant woman
concerned;
(b) he has obtained in the prescribed form her written consent to undergo such procedures in
the language which she understands; and
(c) a copy of her written consent obtained under clause (b) is given to the pregnant woman.
2. No person including the person conducting pre-natal diagnostic procedures shall communicate
to the pregnant woman concerned or her relatives or any other person the sex of the foetus by
words, signs or in any other manner.
6. Determination of sex prohibited.- On and from the commencement of this Act,—
(a) no Genetic Counselling Centre or Genetic Laboratory or Genetic Clinic shall conduct or
cause to be conducted in its Centre, Laboratory or Clinic, pre-natal diagnostic techniques
including ultrasonography, for the purpose of determining the sex of a foetus;
(b) no person shall conduct or cause to be conducted any pre-natal diagnostic techniques including ultrasonography for the purpose of determining the sex of a foetus;
(c) no person shall, by whatever means, cause or allow to be caused selection of sex before or
after conception.
CHAPTER IV
CENTRAL SUPERVISORY BOARD
7. Constitution of Central Supervisory Board.1. The Central Government shall constitute a Board to be known as the Central Supervisory Board
to exercise the powers and perform the functions conferred on the Board under this Act.
2. The Board shall consist of—
(a) the Minister in charge of the Ministry or Department of Family Welfare, who shall be the
Chairman, ex-officio;
(b) the Secretary to the Government of India in charge of the Department of Family Welfare,
who shall be the Vice-Chairman, ex-officio;
(c) three members to be appointed by the Central Government to represent the Ministries of
Central Government in charge of Women and Child Development, Department of Legal
Affairs or Legislative Department in the Ministry of Law and Justice, and Indian System of
Medicine and Homoeopathy, ex-officio;
(d) the Director General of Health Services of the Central Government, ex-officio;
(e) ten members to be appointed by the Central Government, two each from amongst—
(i) eminent medical geneticists;
(ii) eminent gynaecologist and obstetrician or expert of stri-roga or prasuti-tantra;
(iii) eminent paediatricians;
(iv) eminent social scientists; and
(v) representatives of women welfare organisations;
67

<!-- page 75 -->

(f) three women Members of Parliament, of whom two shall be elected by the House of the
People and one by the Council of States;
(g) four members to be appointed by the Central Government by rotation to represent the States
and the Union territories, two in the alphabetical order and two in the reverse alphabetical
order:
Provided that no appointment under this clause shall be made except on the recommendation of the State Government or, as the case may be, the Union territory;
(h) an officer, not below the rank of a Joint Secretary or equivalent of the Central Government,
in charge of Family Welfare, who shall be the Member-Secretary, ex-officio.
8. Terms of office of members.- (1) The term of office of a member, other than an ex-officio member,
shall be,—
(a) in case of appointment under clause (e) or clause (f) of sub-section (2) of section 7, three
years; and
(b) in case of appointment under clause (g) of the said subsection, one year.
2. If a casual vacancy occurs in the office of any other members, whether by reason of his death,
resignation or inability to discharge his functions owing to illness or other incapacity, such vacancy shall be filled by the Central Government by making a fresh appointment and the member
so appointed shall hold office for the remainder of the term of office of the person in whose place
he is so appointed.
3. The Vice-Chairman shall perform such functions as may be assigned to him by the Chairman
from time to time.
4. The procedure to be followed by the members in the discharge of their functions shall be such as
may be prescribed.
9. Meetings of the Board.1. The Board shall meet at such time and place, and shall observe such rules of procedure in regard
to the transaction of business at its meetings (including the quorum at such meetings) as may be
provided by regulations:
Provided that the Board shall meet at least once in six months.
2. The Chairman and in his absence the Vice-Chairman shall preside at the meetings of the Board.
3. If for any reason the Chairman or the Vice-Chairman is unable to attend any meeting of the
Board, any other member chosen by the members present at the meeting shall preside at the
meeting.
4. All questions which come up before any meeting of the Board shall be decided by a majority of
the votes of the members present and voting, and in the event of an equality of votes, the Chairman, or in his absence, the person presiding, shall have and exercise a second or casting vote.
5. Members other than ex-officio members shall receive such allowances, if any, from the Board as
may be prescribed.

68

PNDT Act, 1994 & Amendments

<!-- page 76 -->

10. Vacancies, etc., not to invalidate proceedings of the Board.- No act or proceeding of the Board shall
be invalid merely by reason of—
(a) any vacancy in, or any defect in the constitution of, the Board; or
(b) any defect in the appointment of a person acting as a member of the Board; or
(c) any irregularity in the procedure of the Board not affecting the merits of the case.
11. Temporary association of persons with the Board for particular purposes.
1. The Board may associate with itself, in such manner and for such purposes as may be determined by regulations, any person whose assistance or advice it may desire in carrying out any of
the provisions of this Act.
2. A person associated with it by the Board under sub-section (1) for any purpose shall have a right
to take part in the discussions relevant to that purpose, but shall not have a right to vote at a
meeting of the Board and shall not be a member for any other purpose.
12. Appointment or officers and other employees of the Board.1. For the purpose of enabling it efficiently to discharge its functions under this Act, the Board may,
subject to such regulations as may be made in this behalf, appoint (whether on deputation or
otherwise) such number of officers and other employees as it may consider necessary:
Provided that the appointment of such category of officers, as may be specified in such regulations, shall be subject to the approval of the Central Government.
2. Every officer or other employee appointed by the Board shall be subject to such conditions of
service and shall be entitled to such remuneration as may be specified in the regulations.
13. Authentication of orders and other instruments of the Board.- All orders and decisions of the Board
shall be authenticated by the signature of the Chairman or any other member authorised by the
Board in this behalf, and all other instruments issued by the Board shall be authenticated by the
signature of the Member-Secretary or any other officer of the Board authorised in like manner in
this behalf.
14. Disqualifications for appointment as member.- A person shall be disqualified for being appointed
as a member if, he—
(a) has been convicted and sentenced to imprisonment for an offence which, in the opinion of
the Central Government, involves moral turpitude; or
(b) is an undischarged insolvent; or
(c) is of unsound mind and stands so declared by a competent court; or
(d) has been removed or dismissed from the service of the Government or a Corporation owned
or controlled by the Government; or
(e) has, in the opinion of the Central Government, such financial or other interest in the Board
as is likely to affect prejudicially the discharge by him of his functions as a member; or
(f) has, in the opinion of the Central Government, been associated with the use or promotion of
pre-natal diagnostic technique for determination of sex or with any sex selection technique.

69

<!-- page 77 -->

15. Eligibility of member for reappointment.- Subject to the other terms and conditions of service as may
be prescribed, any person ceasing to be a member shall be eligible for reappointment as such member.
Provided that no member other than an ex-officio member shall be appointed for more than two
consecutive terms.
16. Functions of the Board. - The Board shall have the following functions, namely:—
(i) to advise the Central Government on policy matters relating to use of pre-natal diagnostic
techniques, sex selection techniques and against their misuse;
(ii) to review and monitor implementation of the Act and rules made thereunder and recommend to the Central Government changes in the said Act and rules;
(iii) to create public awareness against the practice of pre-conception sex selection and prenatal determination of sex of foetus leading to female foeticide;
(iv) to lay down code of conduct to be observed by persons working at Genetic Counselling
Centres, Genetic Laboratories and Genetic Clinics;
(v) to oversee the performance of various bodies constituted under the Act and take appropriate steps to ensure its proper and effective implementation;
(vi) any other functions as may be prescribed under the Act.
16A. Constitution of State Supervisory Board and Union territory Supervisory Board.1. Each State and Union territory having Legislature shall constitute a Board to be known as the
State Supervisory Board or the Union territory Supervisory Board, as the case may be, which
shall have the following functions:i)

to create public awareness against the practice of pre-conception sex selection and pre-natal
determination of sex of foetus leading to female foeticide in the State;

ii)

to review the activities of the Appropriate Authorities functioning in the State and recommend appropriate action against them;

iii) to monitor the implementation of provisions of the Act and the rules and make suitable
recommendations relating thereto, to the Board;
iv) to send such consolidated reports as may be prescribed in respect of the various activities
undertaken in the State under the Act to the Board and the Central Government; and
v)

any other functions as may be prescribed under the Act.

2. The State Board shall consist of,-

70

a)

the Minister in charge of Health and Family Welfare in the State, who shall be the Chairperson, ex-officio;

b)

the Secretary in charge of the Department of Health and Family Welfare who shall be the
Vice-Chairperson, ex-officio;

c)

Secretaries or Commissioners in charge of Departments of Women and Child Development,
Social Welfare, Law and Indian System of Medicines and Homoeopathy, ex-officio, or their
representatives;
PNDT Act, 1994 & Amendments

<!-- page 78 -->

d) Director of Health and Family Welfare or Indian System of Medicines and Homoeopathy of
the State Government, ex-officio;
e)

Three women members of Legislative Assembly or Legislative Council;

f)

Ten members to be appointed by the State Government out of which two each shall be from
the following categories:
i)

eminent social scientists and legal experts;

ii)

eminent women activists from non-governmental organizations or otherwise;

iii) eminent gynaecologists and obstetricians or experts of stri-roga or prasuti tantra;
iv) eminent paediatricians or medical geneticists;
v)
g)

eminent radiologists or sonologists;

an officer not below the rank of Joint Director in charge of Family Welfare, who shall be the
Member Secretary, ex-officio.

3. The State Board shall meet at least once in four months.
4. The term of office of a member, other than an ex-officio member, shall be three years.
5. If a vacancy occurs in the office of any member other than an ex-officio member, it shall be filled
by making fresh appointment.
6. If a member of the Legislative Assembly or member of the Legislative Council who is a member
of the State Board, becomes Minister or Speaker or Deputy Speaker of the Legislative Assembly
or Chairperson or Deputy Chairperson of the Legislative Council, she shall cease to be a member
of the State Board.
7. One-third of the total number of members of the State Board shall constitute the quorum.
8. The State Board may co-opt a member as and when required, provided that the number of coopted members does not exceed one-third of the total strength of the State Board.
9. The co-opted members shall have the same powers and functions as other members, except the
right to vote and shall abide by the rules and regulations.
10. In respect of matters not specified in this section, the State Board shall follow procedures and
conditions as are applicable to the Board.
CHAPTER V
APPROPRIATE AUTHORITY AND ADVISORY COMMITTEE
17. Appropriate Authority and Advisory Committee.- 1. The Central Government shall appoint, by
notification in the Official Gazette, one or more Appropriate Authorities for each of the Union
territories for the purposes of this Act.
2. The State Government shall appoint, by notification in the Official Gazette, one or more Appropriate Authorities for the whole or part of the State for the purposes of this Act having regard to
the intensity of the problem of pre-natal sex determination leading to female foeticide.
71

<!-- page 79 -->

3. The officers appointed as Appropriate Authorities under sub-section (1) or sub-section (2) shall be,—
(a) when appointed for the whole of the State or the Union territory, consisting of the following
three membersi)

an officer of or above the rank of the Joint Director of Health and Family WelfareChairperson;

ii)

an eminent woman representing women’s organization; and

iii) an officer of Law Department of the State or the Union territory concerned:
Provided that it shall be the duty of the State or the Union territory concerned to constitute multimember State or Union territory level Appropriate Authority within three months of the coming into
force of the Pre-natal Diagnostic Techniques (Regulation and Prevention of Misuse) Amendment Act,
2002:
Provided further that any vacancy occurring therein shall be filled within three months of that occurrence.
(b) when appointed for any part of the State or the Union territory, of such other rank as the
State Government or the Central Government, as the case may be, may deem fit.
4. The Appropriate Authority shall have the following functions, namely:—
(a) to grant, suspend or cancel registration of a Genetic Counselling Centre, Genetic Laboratory
or Genetic Clinic;
(b) to enforce standards prescribed for the Genetic Counselling Centre, Genetic Laboratory and
Genetic Clinic;
(c) to investigate complaints of breach of the provisions of this Act or the rules made thereunder
and take immediate action;
(d) to seek and consider the advice of the Advisory Committee, constituted under sub-section
(5), on application for registration and on complaints for suspension or cancellation of registration;
(e) to take appropriate legal action against the use of any sex selection technique by any person
at any place, suo motu or brought to its notice and also to initiate independent investigations
in such matter;
(f) to create public awareness against the practice of sex selection or pre-natal determination of sex;
(g) to supervise the implementation of the provisions of the Act and rules;
(h) to recommend to the CSB and State Boards modifications required in the rules in accordance
with changes in technology or social conditions;
(i) to take action on the recommendations of the Advisory Committee made after investigation
of complaint for suspension or cancellation of registration.
5. The Central Government or the State Government, as the case may be, shall constitute an
Advisory Committee for each Appropriate Authority to aid and advise the Appropriate Authority in the discharge of its functions, and shall appoint one of the members of the Advisory
Committee to be its Chairman.
72

PNDT Act, 1994 & Amendments

<!-- page 80 -->

6 The Advisory Committee shall consist of—
(a) three medical experts from amongst gynaecologists, obstericians, paediatricians and
medical geneticists;
(b) one legal expert;
(c) one officer to represent the department dealing with information and publicity of the State
Government or the Union territory, as the case may be;
(d) three eminent social workers of whom not less than one shall be from amongst representatives of women’s organisations.
7. No person who has been associated with the use or promotion of pre-natal diagnostic technique for
determination of sex or sex selection shall be appointed as a member of the Advisory Committee.
8. The Advisory Committee may meet as and when it thinks fit or on the request of the Appropriate Authority for consideration of any application for registration or any complaint for suspension or cancellation of registration and to give advice thereon:
Provided that the period intervening between any two meetings shall not exceed the prescribed
period.
9. The terms and conditions subject to which a person may be appointed to the Advisory Committee and the procedure to be followed by such Committee in the discharge of its functions shall be
such as may be prescribed.
17A. Powers of Appropriate Authorities.- The Appropriate Authority shall have the powers in respect
of the following matters, namely:a) summoning of any person who is in possession of any information relating to violation of the
provisions of this Act or the rules made thereunder;
b) production of any document or material object relating to clause (a);
c) issuing search warrant for any place suspected to be indulging in sex
pre-natal sex determination; and

selection techniques or

d)any other matter which may be prescribed.
CHAPTER VI
REGISTRATION OF GENETIC COUNSELLING CENTRES,
GENETIC LABORATORIES AND GENETIC CLINICS
18. Registration of Genetic Counselling Centres, Genetic Laboratories or Genetic Clinics. (1) No person shall open any Genetic Counselling Centre, Genetic Laboratory or Genetic Clinic, including
clinic, laboratory or centre having ultrasound or imaging machine or scanner or any other technology capable of undertaking determination of sex of foetus and sex selection, or render services to
any of them, after the commencement of the Pre-natal Diagnostic Techniques (Regulation and
Prevention of Misuse) Amendment Act, 2002 unless such centre, laboratory or clinic is duly registered under the Act.

73
