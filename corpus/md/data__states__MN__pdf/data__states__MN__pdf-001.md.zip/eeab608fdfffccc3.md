---
doc_id: "eeab608fdfffccc3"
source_url: "https://www.phedmanipur.gov.in/wp-content/uploads/2024/06/phed-order-no-7.pdf"
ministry: "Public Health Engineering Department, Manipur"
title: "phed-order-no-7"
date: ""
pages: 1
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "1be0c374240a8aa1"
---

<!-- page 1 -->

টি {GOVERNMENT OF MANIPUR
PUBLIC HEALTH ENGINEERING DEPARTMENT
RK
Office Order No. #
Imphal, thegfApril,2022
No.CE/PHE/3-75/2022/247 : In pursuance of Secretariat (PHE) letter No.Missc-
901/5/2020-PHED-PHED dated 19" April, 2022, Smt. Thokchom Bebina Devi, Superintending
Engineer (Urban), PHED, Manipur is hereby appointed as Nodal Officer for National Green
Tribunal (NGT) and State Public Information Officer (SPIO) for matters related to Right to
information (RTI) of Public Health Engineering Department, Manipur in addition to her
normal duties without any extra remuneration. “
> (Shafgrelpl ashumwo)
- hief Engineer, PHED
Govt. of Manipur

Copy to: 7

1. The Secretary (PHE), Government of Manipur '

2, ,779 Additional Chief Engineer (PHED), Manipur

3, All Superintending Engineers (PHED), Manipur

4. All Executive Engineers, PHED, Manipur

5. Officer Order Book

6. File concerned

uO 4
