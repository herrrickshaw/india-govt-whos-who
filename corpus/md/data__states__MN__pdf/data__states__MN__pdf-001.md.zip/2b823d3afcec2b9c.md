---
doc_id: "2b823d3afcec2b9c"
source_url: "https://manipcb.nic.in/document/Rules/EWMRules2016english23.03.2016.pdf"
ministry: "Manipur Pollution Control Board (MPCB), Manipur"
title: "Ministry of Environment, Forest and Climate Change"
date: ""
pages: 42
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ab4bba6a99618abe"
---

<!-- page 1 -->

[PUBLISHED IN THE GAZETTE OF INDIA, EXTRAORDINARY PART-II, SECTION3, SUB-SECTION (i)]
GOVERNMENT OF INDIA
MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 23rd March , 2016
G.S.R 338(E). - Whereas the draft rules, namely the e-waste (Management) Rules,
2015, were published by the Government of India in the Ministry of Environment,
Forest and Climate Change vide number G.S.R. 472(E), dated the 10th June, 2015 in
the Gazette of India, Extraordinary Part II, section 3, sub-section (ii) inviting objections
and suggestions from all persons likely to be affected thereby, before the expiry of the
period of sixty days from the date on which copies of the Gazette containing the said
notification were made available to the public;
AND WHEREAS the copies of the Gazette containing the said notification were made
available to the public on the 10th day of June, 2015;
AND WHEREAS the objections and suggestions received within the specified period
from the public in respect of the said draft rules have been duly considered by the
Central Government;
NOW, THEREFORE, in exercise of the powers conferred by sections 6, 8 and 25 of
the Environment (Protection) Act, 1986 (29 of 1986), and in supersession of the ewaste (Management and Handling) Rules, 2011, published in the Gazette of India,
section 3, sub-section (ii), vide number S.O. 1035(E), dated the 12th May, 2011,
except as respects things done or omitted to be done before such supersession, the
Central Government hereby makes the following rules, namely:CHAPTER I
PRELIMINARY
1.
Short title and commencement. - (1) These rules may be called the E-Waste
(Management) Rules, 2016.
(2) They shall come into force from the 1st day of October, 2016.
2.
Application. - These rules shall apply to every manufacturer,
producer, consumer, bulk consumer, collection centres, dealers, e-retailer, refurbisher,
dismantler and recycler involved in manufacture, sale, transfer, purchase, collection,
storage and processing of e-waste or electrical and electronic equipment listed in
Schedule I, including their components, consumables, parts and spares which make
the product operational but shall not apply to (a) used lead acid batteries as covered under the Batteries (Management and
Handling) Rules, 2001 made under the Act;
(b) micro enterprises as defined in the Micro, Small and Medium Enterprises
Development Act, 2006 (27 of 2006); and
1

<!-- page 2 -->

(c) radio-active wastes as covered under the provisions of the Atomic Energy Act,
1962 (33 of 1962) and rules made there under.
3. Definitions. - (1) In these rules, unless the context otherwise requires, (a) 'Act' means the Environment (Protection) Act, 1986 (29 of 1986);
(b) 'authorisation' means permission for generation, handling, collection, reception,
storage, transportation, refurbishing, dismantling, recycling, treatment and
disposal of e-waste, granted to manufacturer, dismantler, refurbisher and
recycler;
(c) 'bulk consumer' means bulk users of electrical and electronic equipment such
as Central Government or State Government Departments, public sector
undertakings, banks, educational institutions, multinational organisations,
international agencies, partnership and public or private companies that are
registered under the Factories Act, 1948 (63 of 1948) and the Companies Act,
2013 (18 of 2013) and health care facilities which have turnover of more than
one crore or have more than twenty employees;
(d) 'Central Pollution Control Board' means the Central Pollution Control Board
constituted under sub-section (1) of section 3 of the Water (Prevention and
Control of Pollution) Act, 1974 (6 of 1974);
(e) 'collection centre' means a centre or a collection point or both established by
producer individually or as association jointly to collect e-waste for
channelising the e-waste to recycler and play such role as indicated in the
authorisation for Extended Producer Responsibility granted to the producer and
having facilities as per the guidelines of Central Pollution Control Board,
including the collection centre established by the dismantler or refurbisher or
recycler which should be a part of their authorisation issued by the State
Pollution Control Board where the facility exists;
(f) ‘component’ means one of the parts of a sub-assembly or assembly of which a
manufactured product is made up and into which it may be resolved and
includes an accessory or attachment to another component;
(g) ‘consumables’ means an item, which participates in or is required for a
manufacturing process or for functioning of the electrical and electronic
equipment and may or may not form part of end-product. Items, which are
substantially or totally consumed during a manufacturing process, shall be
deemed to be consumables;
(h) 'consumer' means any person using electrical and electronic equipment
excluding the bulk consumers;
(i) ‘channelisation’ means to direct the path for movement of e-wastes from
collection onwards to authorised dismantler or recycler. In case of fluorescent
and other mercury containing lamps, where recyclers are not available, this
means path for movement from collection centre to Treatment, Storage and
Disposal Facility;
(j) 'dealer' means any individual or firm that buys or receives electrical and
electronic equipment as listed in Schedule I of these rules and their
components or consumables or parts or spares from producers for sale;
(k) ‘deposit refund scheme’ means a scheme whereby the producer charges an
additional amount as a deposit at the time of sale of the electrical and electronic
equipment and returns it to the consumer along with interest when the end-oflife electrical and electronic equipment is returned;
(l) 'dismantler' means any person or organisation engaged in dismantling of used
electrical and electronic equipment into their components and having facilities
2

<!-- page 3 -->

as per the guidelines of Central Pollution Control Board and having
authorisation from concerned State Pollution Control Board;
(m)'disposal' means any operation which does not lead to recycling, recovery or
reuse and includes physico-chemical or biological treatment, incineration and
deposition in secured landfill;
(n) ‘end-of-life’ of the product means the time when the product is intended to be
discarded by the user;
(o) 'environmentally sound management of e-waste' means taking all steps
required to ensure that e-waste is managed in a manner which shall protect
health and environment against any adverse effects, which may result from
such e-waste;
(p) 'electrical and electronic equipment' means equipment which are dependent on
electric current or electro-magnetic field in order to become functional;
(q) ‘e-retailer’ means an individual or company or business entity that uses an
electronic network such as internet, telephone, to sell its goods;
(r) 'e-waste' means electrical and electronic equipment, whole or in part discarded
as waste by the consumer or bulk consumer as well as rejects from
manufacturing, refurbishment and repair processes;
(s) ‘e-waste exchange’ means an independent market instrument offering
assistance or independent electronic systems offering services for sale and
purchase of e-waste generated from end-of-life electrical and electronic
equipment between agencies or organisations authorised under these rules;
(t) ‘Extended Producer Responsibility’ means responsibility of any producer of
electrical or electronic equipment, for channelisation of e-waste to ensure
environmentally sound management of such waste. Extended Producer
Responsibility may comprise of implementing take back system or setting up of
collection centres or both and having agreed arrangements with authorised
dismantler or recycler either individually or collectively through a Producer
Responsibility Organisation recognised by producer or producers in their
Extended Producer Responsibility - Authorisation;
(u) ‘Extended Producer Responsibility - Authorisation’ means a permission given
by Central Pollution Control Board to a producer, for managing Extended
Producer Responsibility with implementation plans and targets outlined in such
authorisation including detail of Producer Responsibility Organisation and
e-waste exchange, if applicable;
(v) ‘Extended Producer Responsibility Plan’ means a plan submitted by a producer
to Central Pollution Control Board, at the time of applying for Extended
Producer Responsibility - Authorisation in which a producer shall provide details
of e-waste channelisation system for targeted collection including detail of
Producer Responsibility Organisation and e-waste exchange, if applicable;
(w) 'facility' means any location wherein the process incidental to the collection,
reception, storage, segregation, refurbishing, dismantling, recycling, treatment
and disposal of e-waste are carried out;
(x) 'Form' means a form appended to these rules;
(y) ‘historical e-waste’ means e-waste generated from electrical and electronic
equipment as specified in Schedule I, which was available on the date from
which these rules come into force;
(z) ‘manufacturer’ means a person or an entity or a company as defined in the
Companies Act, 2013 (18 of 2013) or a factory as defined in the Factories Act,
1948 (63 of 1948) or Small and Medium Enterprises as defined in Micro, Small
and Medium Enterprises Development Act, 2006 (27 of 2006), which has
facilities for manufacture of electrical and electronic equipment;
3

<!-- page 4 -->

(aa) ‘orphaned products’ means non-branded or assembled electrical and
electronic equipment as specified in Schedule I or those produced by a
company, which has closed its operations;
(bb) ‘part’ means an element of a sub-assembly or assembly not normally useful by
itself, and not amenable to further disassembly for maintenance purposes. A
part may be a component, spare or an accessory;
(cc) ‘producer’ means any person who, irrespective of the selling technique used
such as dealer, retailer, e-retailer, etc.;
(i) manufactures and offers to sell electrical and electronic equipment and
their components or consumables or parts or spares under its own brand;
or
(ii) offers to sell under its own brand, assembled electrical and electronic
equipment and their components or consumables or parts or spares
produced by other manufacturers or suppliers; or
(iii) offers to sell imported electrical and electronic equipment and their
components or consumables or parts or spares;
(dd) ‘Producer Responsibility Organisation’ means a professional organisation
authorised or financed collectively or individually by producers, which can take
the responsibility for collection and channelisation of e-waste generated from
the ‘end-of-life’ of their products to ensure environmentally sound management
of such e-waste;
(ee) ‘recycler’ - means any person who is engaged in recycling and reprocessing of
waste electrical and electronic equipment or assemblies or their components
and having facilities as elaborated in the guidelines of Central Pollution Control
Board;
(ff) 'refurbishment' means repairing of used electrical and electronic equipment as
listed in Schedule I for extending its working life for its originally intended use
and selling the same in the market or returning to owner;
(gg) 'refurbisher' for the purpose of these rules, means any company or
undertaking registered under the Factories Act, 1948 or the Companies Act,
1956 or both or district industries centre engaged in refurbishment of used
electrical and electronic equipment;
(hh) 'Schedule' means the Schedule appended to these rules;
(ii) "spares” means a part or a sub-assembly or assembly for substitution which is
ready to replace an identical or similar part or sub-assembly or assembly
including a component or an accessory;
(jj) 'State Government in relation to an Union territory means, the Administrator
thereof appointed under article 239 of the Constitution;
(kk) 'State Pollution Control Board' means the concerned State Pollution Control
Board or the Pollution Control Committee of the Union Territories constituted
under sub-section (1) of section 4 of the Water (Prevention and Control of
Pollution) Act, 1974 (6 of 1974);
(ll) ‘target’ means the quantity of e-waste to be collected by the producer in
fulfilment of Extended Producer Responsibility;
(mm) ‘transporter’ means a person or company or entity engaged in the off-site
transportation of e-waste by air, rail, road or water carrying a manifest system
issued by the person or company or entity who has handed over the e-waste to
the transporter, giving the origin, destination and quantity of the e-waste being
transported;
(2) Words and expressions used in these rules and not defined but defined in the Act
shall have the meanings respectively assigned to them in the Act.
4

<!-- page 5 -->

CHAPTER II
RESPONSIBILITIES
4. Responsibilities of the manufacturer. - (1) collect e-waste generated during the
manufacture of any electrical and electronic equipment and channelise it for
recycling or disposal;
(2) apply for an authorisation in Form 1 (a) in accordance with the procedure
prescribed under sub-rule (2) of rule 13 from the concerned State Pollution Control
Board, which shall give the authorisation in accordance with Form 1 (bb);
(3) ensure that no damage is caused to the environment during storage and
transportation of e-waste;
(4) maintain records of the e-waste generated, handled and disposed in Form-2 and
make such records available for scrutiny by the concerned State Pollution Control
Board;
(5) file annual returns in Form-3, to the concerned State Pollution Control Board on or
before the 30th day of June following the financial year to which that return relates.
5. Responsibilities of the producer. - The producer of electrical and electronic
equipment listed in Schedule I shall be responsible for (1) implementing the Extended Producers Responsibility with the following
frameworks, namely:(a) collection and channelisation of e-waste generated from the ‘end-of-life’ of their
products or ‘end-of-life’ products with same electrical and electronic equipment
code and historical waste available on the date from which these rules come into
force as per Schedule I in line with the targets prescribed in Schedule III in
Extended Producer Responsibility - Authorisation;
(b) the mechanism used for channelisation of e-waste from ‘end-of-life’ products
including those from their service centres to authorised dismantler or recycler shall
be in accordance with the Extended Producer Responsibility - Authorisation. In
cases of fluorescent and other mercury containing lamps, where recyclers are not
available, channelisation may be from collection centre to Treatment, Storage and
Disposal Facility;
(c) for disposal in Treatment, Storage and Disposal Facility, a pre-treatment is
necessary to immobilise the mercury and reduce the volume of waste to be
disposed off;
(d) Extended Producer Responsibility - Authorisation should comprise of general
scheme for collection of waste Electrical and Electronic Equipment from the
Electrical and Electronic Equipment placed on the market earlier, such as through
dealer, collection centres, Producer Responsibility Organisation, through buy-back
arrangement, exchange scheme, Deposit Refund System, etc. whether directly or
through any authorised agency and channelising the items so collected to
authorised recyclers;
(e) providing contact details such as address, e-mail address, toll-free telephone
numbers or helpline numbers to consumer(s) or bulk consumer(s) through their
website and product user documentation so as to facilitate return of end-of-life
electrical and electronic equipment;
(f) creating awareness through media, publications, advertisements, posters, or by
any other means of communication and product user documentation
accompanying the equipment, with regard to 5

<!-- page 6 -->

(i) information on address, e-mail address, toll-free telephone numbers or helpline
numbers and web site;
(ii) information on hazardous constituents as specified in sub-rule 1 of rule 16 in
electrical and electronic equipment;
(iii) information on hazards of improper handling, disposal, accidental breakage,
damage or improper recycling of e-waste;
(iv) instructions for handling and disposal of the equipment after its use, along with
the Do’s and Don’ts;
(v) affixing a visible, legible and indelible symbol given below on the products or
product user documentation to prevent e-waste from being dropped in garbage
bins containing waste destined for disposal;

(vi) means and mechanism available for their consumers to return e-waste for
recycling including the details of Deposit Refund Scheme, if applicable;
(g) the producer shall opt to implement Extended Producer Responsibility individually
or collectively. In individual producer responsibility, producer may set up his own
collection centre or implement take back system or both to meet Extended
Producer Responsibility. In collective system, producers may tie-up as a member
with a Producer Responsibility Organisation or with e-waste exchange or both. It
shall be mandatory upon on the individual producer in every case to seek
Extended Producer Responsibility - Authorisation from Central Pollution Control
Board in accordance with the Form-1 and the procedure laid down in sub-rule (1)
of rule 13;
(2) to provide information on the implementation of Deposit Refund Scheme to ensure
collection of end-of-life products and their channelisation to authorised dismantlers
or recyclers, if such scheme is included in the Extended Producer Responsibility
Plan.
Provided that the producer shall refund the deposit amount that has been taken
from the consumer or bulk consumer at the time of sale, along with interest at the
prevalent rate for the period of the deposit at the time of take back of the end-oflife product;
(3) the import of electrical and electronic equipment shall be allowed only to producers
having Extended Producer Responsibility authorisation;
(4) maintaining records in Form-2 of the e-waste handled and make such records
available for scrutiny by the Central Pollution Control Board or the concerned
State Pollution Control Board;
(5) filing annual returns in Form-3, to the Central Pollution Control Board on or before
the 30th day of June following the financial year to which that return relates. In
case of the Producer with multiple offices in a State, one annual return combining
information from all the offices shall be filed;

6

<!-- page 7 -->

(6) the Producer shall apply to the Central Pollution Control Board for authorisation in
Form 1, which shall thereafter grant the Extended Producer Responsibility Authorisation in Form 1(aa).
(7) Operation without Extended Producer Responsibility-Authorisation by any
producer, as defined in this rule, shall be considered as causing damage to the
environment.
6. Responsibilities of collection centres. - (1) collect e-waste on behalf of
producer or dismantler or recycler or refurbisher including those arising from
orphaned products;
Provided the collection centres established by producer can also collect e-waste
on behalf of dismantler, refurbisher and recycler including those arising from
orphaned products
(2) ensure that the facilities are in accordance with the standards or guidelines issued
by Central Pollution Control Board from time to time;
(3) ensure that the e-waste collected by them is stored in a secured manner till it is
sent to authorised dismantler or recycler as the case may be;
(4) ensure that no damage is caused to the environment during storage and
transportation of e-waste;
(5) maintain records in Form-2 of the e-waste handled as per the guidelines of Central
Pollution Control Board and make such records available for scrutiny by the
Central Pollution Control Board or the concerned State Pollution Control Board as
and when asked for.
7. Responsibilities of dealers. – (1) in the case the dealer has been given the
responsibility of collection on behalf of the producer, the dealer shall collect the ewaste by providing the consumer a box, bin or a demarcated area to deposit ewaste, or through take back system and send the e-waste so collected to collection
centre or dismantler or recycler as designated by producer;
(2) the dealer or retailer or e-retailer shall refund the amount as per take back system
or Deposit Refund Scheme of the producer to the depositor of e-waste;
(3) every dealer shall ensure that the e-waste thus generated is safely transported to
authorised dismantlers or recyclers;
(4) ensure that no damage is caused to the environment during storage and
transportation of e-waste.
8. Responsibilities of the refurbisher. – (1) collect e-waste generated during the
process of refurbishing and channelise the waste to authorised dismantler or
recycler through its collection centre;
(2) make an application in Form 1(a) in accordance with the procedure laid down in
sub-rule (4) of rule 13 to the concerned State Pollution Control Board for grant of
one time authorisation;
(a) the concerned State Pollution Control Board shall authorise the Refurbisher on
one time basis as per Form 1 (bb) and authorisation would be deemed as
considered if not objected to within a period of thirty days;
(b) the authorised Refurbisher shall be required to submit details of e-waste
generated to the concerned State Pollution Control Board on yearly basis;
(3) ensure that no damage is caused to the environment during storage and
transportation of e-waste;
(4) ensure that the refurbishing process do not have any adverse effect on the health
and the environment;
7

<!-- page 8 -->

(5) ensure that the e-waste thus generated is safely transported to authorised
collection centres or dismantlers or recyclers;
(6) file annual returns in Form-3 to the concerned State Pollution Control Board, on or
before the 30th day of June following the financial year to which that return relates;
(7) maintain records of the e-waste handled in Form-2 and such records should be
available for scrutiny by the appropriate authority.
9. Responsibilities of consumer or bulk consumer. – (1) consumers or bulk
consumers of electrical and electronic equipment listed in Schedule I shall ensure
that e-waste generated by them is channelised through collection centre or dealer
of authorised producer or dismantler or recycler or through the designated take
back service provider of the producer to authorised dismantler or recycler;
(2) bulk consumers of electrical and electronic equipment listed in Schedule I shall
maintain records of e-waste generated by them in Form-2 and make such records
available for scrutiny by the concerned State Pollution Control Board;
(3) consumers or bulk consumers of electrical and electronic equipment listed in
Schedule I shall ensure that such end-of-life electrical and electronic equipment
are not admixed with e-waste containing radioactive material as covered under the
provisions of the Atomic Energy Act, 1962 (33 of 1962) and rules made there
under;
(4) bulk consumers of electrical and electronic equipment listed in Schedule I shall file
annual returns in Form-3, to the concerned State Pollution Control Board on or
before the 30th day of June following the financial year to which that return relates.
In case of the bulk consumer with multiple offices in a State, one annual return
combining information from all the offices shall be filed to the concerned State
Pollution Control Board on or before the 30th day of June following the financial
year to which that return relates
10. Responsibilities of the dismantler. - (1)ensure that the facility and dismantling
processes are in accordance with the standards or guidelines prescribed by Central
Pollution Control Board from time to time;
(2) obtain authorisation from the concerned State Pollution Control Board in
accordance with the procedure under sub-rule (3) of rule 13;
(3) ensure that no damage is caused to the environment during storage and
transportation of e-waste;
(4) ensure that the dismantling processes do not have any adverse effect on the
health and the environment;
(5) ensure that dismantled e-waste are segregated and sent to the authorised
recycling facilities for recovery of materials;
(6) ensure that non-recyclable or non-recoverable components are sent to authorised
treatment storage and disposal facilities;
(7) maintain record of e-waste collected, dismantled and sent to authorised recycler in
Form-2 and make such record available for scrutiny by the Central Pollution
Control Board or the concerned State Pollution Control Board;
(8) file a return in Form-3, to the concerned State Pollution Control Board as the case
may be, on or before 30th day of June following the financial year to which that
return relates;
(9) not process any e-waste for recovery or refining of materials, unless he is
authorised with concerned State Pollution Control Board as a recycler for refining
and recovery of materials;
(10) operation without Authorisation by any dismantler, as defined in this rule, shall be
considered as causing damage to the environment.
8

<!-- page 9 -->

11. Responsibilities of the recycler. – (1) shall ensure that the facility and recycling
processes are in accordance with the standards or guidelines prescribed by the
Central Pollution Control Board from time to time;
(2) obtain authorisation from concerned State Pollution Control Board in accordance
with the procedure under the sub-rule (3) of rule 13;
(3) ensure that no damage is caused to the environment during storage and
transportation of e-waste;
(4) ensure that the recycling processes do not have any adverse effect on the health
and the environment;
(5) make available all records to the Central Pollution Control Board or the concerned
State Pollution Control Board for inspection;
(6) ensure that the fractions or material not recycled in its facility is sent to the
respective authorised recyclers;
(7) ensure that residue generated during recycling process is disposed of in an
authorised treatment storage disposal facility;
(8) maintain record of e-waste collected, dismantled, recycled and sent to authorised
recycler in Form-2 and make such record available for scrutiny by the Central
Pollution Control Board or the concerned State Pollution Control Board;
(9) file annual returns in Form-3, to the concerned State Pollution Control Board as
the case may be, on or before 30th day of June following the financial year to
which that return relates;
(10) may accept waste electrical and electronic equipment or components not listed in
Schedule I for recycling provided that they do not contain any radioactive material
and same shall be indicated while taking the authorisation from concerned State
Pollution Control Board;
(11) operation without Authorisation by any recycler, as defined in this rule, shall be
considered as causing damage to the environment.
12.
Responsibilities of State Government for environmentally sound
management of E-waste. – (1) Department of Industry in State or any other
government agency authorised in this regard by the State Government, to ensure
earmarking or allocation of industrial space or shed for e-waste dismantling and
recycling in the existing and upcoming industrial park, estate and industrial clusters;
(2) Department of Labour in the State or any other government agency authorised in
this regard by the State Government shall:
a. ensure recognition and registration of workers involved in dismantling
and recycling;
b. assist formation of groups of such workers to facilitate setting up
dismantling facilities;
c. undertake industrial skill development activities for the workers involved
in dismantling and recycling;
d. undertake annual monitoring and to ensure safety & health of workers
involved in dismantling and recycling;
(3) State Government to prepare integrated plan for effective implementation of these
provisions, and to submit annual report to Ministry of Environment, Forest and Climate
Change.

9

<!-- page 10 -->

CHAPTER III
PROCEDURE FOR SEEKING AND GRANT OF AUTHORISATION FOR
MANAGEMENT OF E-WASTE
13. Procedure for Seeking and Grant of Authorisation. (1) Extended Producer Responsibility - Authorisation of Producers. – (i) every
producer of electrical and electronic equipment listed in Schedule I, shall make
an application for Extended Producer Responsibility - Authorisation within a
period of ninety days starting from the date of these rules coming into force in
Form-1 to Central Pollution Control Board;
(ii) on receipt of the application complete in all respects, the Central Pollution Control
Board will carry out evaluation of the Extended Producer Responsibility Plan and
on being satisfied that the producer has detailed out an effective system to
manage Extended Producer Responsibility in the country, shall grant Extended
Producer Responsibility - Authorisation, in Form 1(aa) within a period of one
hundred and twenty days. The Extended Producer Responsibility - Authorisation
shall be valid for a period of five years;
This authorisation shall include among others the targeted quantity of e-waste, product
code wise, to be collected during the year. The actual target for collection of e-waste
for dismantling or recycling will be fixed on the basis of quantity of electrical and
electronic equipment, product code wise, placed in the market in the previous years
and taking into consideration the average life of the equipment. The estimated quantity
of e-waste generated during the current year will be indicated by the producer and the
quantity expected to be collected with the collection scheme proposed to be
implemented by the producer will be indicated in the Extended Producer
Responsibility plan. The Central Pollution Control Board shall fix the targets in
accordance with Schedule III.
(iii) the Central Pollution Control Board, after giving reasonable opportunity of being
heard to the applicant shall refuse to grant Extended Producer Responsibility –
Authorisation;
(iv) in the event of refusal of Extended Producer Responsibility - Authorisation by the
Central Pollution Control Board, the producer will forfeit his right to put any
Electrical and Electronic Equipment in the market till such time the Extended
Producer Responsibility - Authorisation is granted;
(v)
the Central Pollution Control Board after grant of Extended Producer
Responsibility - Authorisation shall forward the Extended Producer Responsibility
Plan to respective State Pollution Control Board for monitoring;
(vi) an application for the renewal of Extended Producer Responsibility-Authorisation
shall be made in Form-1 before one hundred and twenty days of its expiry to
Central Pollution Control Board. The Central Pollution Control Board may renew
the authorisation for a period of five years after receipt of compliance report from
the concerned State Pollution Control Board which shall submit the compliance
report to Central Pollution Control Board within sixty days from the date of the
receipt of the application. In case of non receipt of the compliance report from the
State Pollution Control Board within stipulated time period of sixty days, Central
Pollution Control Board may renew the Extended Producer ResponsibilityAuthorisation after examining such case on merit basis, subject to no report of
violation of the provisions of the Act or the rules made there under or the
conditions specified in the Extended Producer Responsibility - Authorisation;
10

<!-- page 11 -->

(vii) every producer of Electrical and Electronic Equipment listed in Schedule I, shall
take all steps, wherever required, to comply with the conditions specified in the
Extended Producer Responsibility – Authorisation;
(viii) the concerned State Pollution Control Board shall monitor the compliance of
Extended Producer Responsibility - Authorisation, take cognizance of any noncompliance and inform Central Pollution Control Board for taking action, as
necessary;
(ix) Central Pollution Control Board shall conduct random check and if in its opinion,
the holders of the Extended Producer Responsibility - Authorisation has failed to
comply with any of the conditions of the authorisation or with any provisions of
the Act or these rules and after giving a reasonable opportunity of being heard
and after recording reasons thereof in writing cancel or suspend the Extended
Producer Responsibility - Authorisation issued under these rules for such period
as it considers necessary in the public interest and inform the concerned State
Pollution Control Board within ten days of cancellation.
(x) the Central Pollution Control Board shall maintain an online register of Extended
Producer Responsibility - Authorisation granted with conditions imposed under
these rules for environmentally sound management of e-waste, and which shall
be accessible to any citizen of the country.
(xi) The producer authorised under the provision of this rule shall maintain records in
Form-2 and shall file annual returns of its activities of previous year in Form-3 to
the Central Pollution Control Board on or before 30th day of June of every year;
(2) Authorisation of Manufacturer. – (i) the manufacturer generating e-waste shall
obtain an authorisation from the concerned State Pollution Control Board;
(ii) the manufacturer shall make an application for authorisation, within a period of
ninety days from the date of these rules coming into force in Form 1(a) to the
concerned State Pollution Control Board for grant of authorisation;
(iii) on receipt of the application complete in all respects for the authorisation, the
concerned State Pollution Control Board may, after such enquiry as it considers
necessary and on being satisfied that the applicant possesses appropriate
facilities, technical capabilities and equipment to handle e-waste safely, grant
within a period of one hundred and twenty days an authorisation in Form 1(bb) to
the applicant to carry out safe operations in the authorised place only, which shall
be valid for a period of five years;
(iv) the concerned State Pollution Control Board after giving reasonable opportunity of
being heard to the applicant may refuse to grant any authorisation;
(v) every person authorised under these rules shall maintain the record of e-waste
handled by them in Form-2 and prepare and submit to the concerned State
Pollution Control Board, an annual return containing the details specified in Form3 on or before the 30th day of June following the financial year to which that return
relates;
(vi) an application for the renewal of an authorisation shall be made in Form-1(a)
before one hundred and twenty days of its expiry and the concerned State
Pollution Control Board may renew the authorisation for a period of five years
after examining each case on merit and subject to the condition that there is no
report of violation of the provisions of the Act or the rules made thereunder or the
conditions specified in the authorisation;
(vii) manufacturer shall take all steps to comply with the conditions specified in the
authorisation;
(viii) the concerned State Pollution Control Board shall maintain an online register of
authorisations granted with conditions imposed under these rules for
11

<!-- page 12 -->

environmentally sound management of e-waste, and which shall be accessible to
any citizen of the country.
(3) Procedure for grant of authorisation to dismantler or recycler. - (i) every
Dismantler or Recycler of e-waste shall make an application, within a period of one
hundred and twenty days starting from the date of coming into force of these rules, in
Form-4 in triplicate to the concerned State Pollution Control Board accompanied with
a copy of the following documents for the grant or renewal of authorisation, namely:(a) consent to establish granted by the concerned State Pollution Control Board
under the Water (Prevention and Control of Pollution) Act, 1974, (25 of 1974)
and the Air (Prevention and Control of Pollution) Act, 1981(21 of 1981);
(b) certificate of registration issued by the District Industries Centre or any other
government agency authorised in this regard;
(c) proof of installed capacity of plant and machinery issued by the District
Industries Centre or any other government agency authorised in this behalf;
(d) in case of renewal, a certificate of compliance of effluent and emission
standards, treatment and disposal of hazardous wastes as applicable from the
concerned State Pollution Control Board or any other agency designated for
this purpose:
Provided that any person authorised or registered under the provisions of the
Hazardous Wastes (Management, Handling and Transboundary Movements) Rules,
2008, and the E-waste (Management & Handling) Rules, 2011 prior to the date of
coming into force of these rules shall not be required to make an application for
authorisation till the period of expiry of such authorisation or registration:
(ii)

the concerned State Pollution Control Board, on being satisfied that the
application is complete in all respects and that the applicant is utilising
environmentally sound technologies and possess adequate technical
capabilities, requisite facilities and equipment to dismantle or recycle and
process e-waste in compliance to the guidelines specified by Central Pollution
Control Board from time to time and through site inspection, may grant
authorisation to such applicants stipulating therein necessary conditions as
deemed necessary for carrying out safe operations in the authorised place only;
(iii) the concerned State Pollution Control Board shall dispose of the application for
authorisation within a period of one hundred and twenty days from the date of the
receipt of such application complete in all respects;
(iv) the authorisation granted under these rules shall be valid for a period of five
years from the date of its issue and shall be accompanied with a copy of the field
inspection report signed by that Board indicating the adequacy of facilities for
dismantling or recycling of e-waste and compliance to the guidelines specified by
Central Pollution Control Board from time to time;
(v) the concerned State Pollution Control Board may refuse, cancel or suspend an
authorisation granted under these rules, if it has reasons to believe that the
authorised dismantler or recycler has failed to comply with any of the conditions
of authorisation, or with any provisions of the Act or rules made thereunder, after
giving an opportunity to the dismantler or recycler to be heard and after recording
the reasons thereof;
(vi) an application for the renewal of authorisation shall be made in Form - 4 before
one hundred and twenty days of its expiry and the concerned State Pollution
Control Board may renew the authorisation for a period of five years after
12

<!-- page 13 -->

examining each case on merit and subject to the condition that there is no report
of violation of the provisions of the Act or the rules made there under or the
conditions specified in the authorisation;
(vii) the Dismantler and Recycler shall maintain records of the e-waste purchased,
processed in Form-2 and shall file annual returns of its activities of previous year
in Form-3 to the concerned State Pollution Control Board on or before 30 th day of
June of every year;
(viii) the Central Government and the Central Pollution Control Board may issue
guidelines for standards of performance for dismantling and recycling processes
from time to time.
(4)

Procedure for grant of authorisation to refurbisher. – (i) every refurbisher of
e-waste shall make an application, with in a period of one hundred and twenty
days starting from the date of coming into force of these rules, in Form 1 (a) in
triplicate to the concerned State Pollution Control Board accompanied with a
copy of the following documents for the grant or renewal of authorisation,
namely:(a) consent to establish granted by the concerned State Pollution Control Board
under the Water (Prevention and Control of Pollution) Act, 1974, (25 of
1974) and the Air (Prevention and Control of Pollution) Act, 1981 (21 of
1981);
(b) certificate of registration issued by the District Industries Centre or any other
government agency authorised in this regard;
(c) proof of installed capacity of plant and machinery issued by the District
Industries Centre or any other government agency authorised in this behalf.

(ii)

the concerned State Pollution Control Board, on being satisfied that the
application is complete in all respects and complies with the guidelines
prescribed by Central Pollution Control Board from time to time, may grant one
time authorisation in Form 1 (bb) to such applicants stipulating therein necessary
conditions as deemed necessary for carrying out refurbishing activities in the
authorised place only;
(iii) the concerned State Pollution Control Board shall dispose of the application for
authorisation within a period of one hundred and twenty days from the date of the
receipt of such application complete in all respects;
(iv) the concerned State Pollution Control Board may refuse, cancel or suspend a
authorisation granted under these rules, if it has reasons to believe that the
authorised refurbisher has failed to comply with any of the conditions of
authorisation, or with any provisions of the Act or rules made thereunder, after
giving an opportunity to the refurbisher to be heard and after recording the
reasons thereof;
(v) the Refurbisher shall maintain records of the e-waste purchased and refurbished
in Form-2 and shall file annual returns of its activities of previous year in Form-3
to the concerned State Pollution Control Board on or before 30 th day of June of
every year.
14. Power to suspend or cancel an authorisation.- (1) The State Pollution Control
Board may, if in its opinion, the holder of Manufacturer or Dismantler or Recycler or
Refurbisher Authorisation has failed to comply with any of the conditions of the
authorisation or with any provisions of the Act or these rules and after giving a
reasonable opportunity of being heard and after recording reasons thereof in writing
13

<!-- page 14 -->

cancel or suspend the authorisation issued under these rules for such period as it
considers necessary in the public interest and inform Central Pollution Control Board
within ten days of cancellation;
(2) The Central Pollution Control Board, if in its opinion, the holders of the Extended
Producer Responsibility- Authorisation has failed to comply with any of the conditions
of the authorisation or with any provisions of the Act or these rules and after giving a
reasonable opportunity of being heard and after recording reasons thereof in writing
cancel or suspend the Extended Producer Responsibility- Authorisation issued under
these rules for such period as it considers necessary in the public interest and inform
State Pollution Control Boards or Pollution Control Committees within ten days of
cancellation;
(3) Upon suspension or cancellation of the authorisation, the Central Pollution Control
Board or State Pollution Control Board may give directions to the persons whose
authorisation has been suspended or cancelled for the safe storage and management
of the e-waste and such persons shall comply with such directions.
CHAPTER IV
15.
Procedure for storage of e-waste. - Every manufacturer, producer, bulk
consumer, collection centre, dealer, refurbisher, dismantler and recycler may store the
e-waste for a period not exceeding one hundred and eighty days and shall maintain a
record of collection, sale, transfer and storage of wastes and make these records
available for inspection:
Provided that the concerned State Pollution Control Board may extend the said
period up to three hundred and sixty five days in case the waste needs to be
specifically stored for development of a process for its recycling or reuse.
CHAPTER V
REDUCTION IN THE USE OF HAZARDOUS SUBSTANCES IN THE
MANUFACTURE OF ELECTRICAL AND ELECTRONIC EQUIPMENT AND THEIR
COMPONENTS OR CONSUMABLES OR PARTS OR SPARES
16.
Reduction in the use of hazardous substances in the manufacture of
electrical and electronic equipment and their components or consumables or
parts or spares. – (1) Every producer of electrical and electronic equipment and their
components or consumables or parts or spares listed in Schedule I shall ensure that,
new Electrical and Electronic Equipment and their components or consumables or
parts or spares do not contain Lead, Mercury, Cadmium, Hexavalent Chromium,
polybrominated biphenyls and polybrominated diphenyl ethers beyond a maximum
concentration value of 0.1% by weight in homogenous materials for lead, mercury,
hexavalent chromium, polybrominated biphenyls and polybrominated diphenyl ethers
and of 0.01% by weight in homogenous materials for cadmium.
(2) Components or consumables or parts or spares required for the electrical and
electronic equipment placed in the market prior to 1 st May, 2014 may be exempted
from the provisions of sub-rule (1) of rule 16 provided Reduction of Hazardous
Substances compliant parts and spares are not available.
(3) The applications listed in Schedule II shall be exempted from provisions of subrule (1) of rule 16.
14

<!-- page 15 -->

(4) Every producer of applications listed in Schedule II shall ensure that the limits of
hazardous substances as given in Schedule II are to be complied.
(5) Every producer shall provide the detailed information on the constituents of the
equipment and their components or consumables or parts or spares alongwith a
declaration of conformance to the Reduction of Hazardous Substances provisions
in the product user documentation.
(6) Imports or placement in the market for new electrical and electronic equipment
shall be permitted only for those which are compliant to provisions of sub-rule (1)
and sub rule (4) of rule 16.
(7) Manufacture and supply of electrical and electronic equipment used for defence
and other similar strategic applications shall be excluded from provisions of subrule (1) of rule 16.
(8) Every producer while seeking Extended Producer Responsibility - Authorisation
will provide information on the compliance of the provisions of sub-rule (1) of
rule 16. This information shall be in terms of self-declaration.
(9) Central Pollution Control Board shall conduct random sampling of electrical and
electronic equipment placed on the market to monitor and verify the compliance of
Reduction of Hazardous Substances provisions and the cost for sample and
testing shall be borne by the Producer. The random sampling shall be as per the
guidelines of Central Pollution Control Board.
(10) If the product does not comply with Reduction of Hazardous Substances
provisions, the Producers shall take corrective measures to bring the product into
compliance and withdraw or recall the product from the market, within a
reasonable period as per the guidelines of the Central Pollution Control Board.
(11) Central Pollution Control Board shall publish the methods for sampling and
analysis of Hazardous Substances as listed in sub-rule(1) of rule 16 with respect
to the items listed in Schedule I and II and also enlist the labs for this purpose.

CHAPTER VI
MISCELLANEOUS
17.
Duties of authorities. - Subject to other provisions of these rules, the
authorities shall perform duties as specified in Schedule IV.
18.
Annual Report. – (1) The concerned State Pollution Control Board shall
prepare and submit to the Central Pollution Control Board an annual report with regard
to the implementation of these rules by the 30th day of September every year in
Form-5.
(2) The Central Pollution Control Board shall prepare the consolidated annual review
report on management of e-waste and forward it to the Central Government along with
its recommendations before the 30th day of December every year.
19.
Transportation of e-waste. –The transportation of e-waste shall be carried out
as per the manifest system whereby the transporter shall be required to carry a
document (three copies) prepared by the sender, giving the details as per Form-6:
Provided that the transportation of waste generated from manufacturing or recycling
destined for final disposal to a treatment, storage and disposal facility shall follow the
provisions under Hazardous Wastes (Management, Handling and Transboundary
Movement) Rules, 2008.
15

<!-- page 16 -->

20.
Accident reporting.- Where an accident occurs at the facility processing
e-waste or during transportation of e-waste, the producer, refurbisher, transporter,
dismantler, or recycler, as the case may be, shall report immediately to the concerned
State Pollution Control Board about the accident through telephone and e-mail.
21.
Liability of manufacturer, producer, importer, transporter, refurbisher,
dismantler and recycler.- (1) The manufacturer, producer, importer, transporter,
refurbisher, dismantler and recycler shall be liable for all damages caused to the
environment or third party due to improper handling and management of the e-waste;
(2)
The manufacturer, producer, importer, transporter, refurbisher, dismantler and
recycler shall be liable to pay financial penalties as levied for any violation of the
provisions under these rules by the State Pollution Control Board with the prior
approval of the Central Pollution Control Board.
22.
Appeal.- (1) Any person aggrieved by an order of suspension or cancellation or
refusal of authorisation or its renewal passed by the Central Pollution Control Board or
State Pollution Control Board may, within a period of thirty days from the date on
which the order is communicated to him, prefer a appeal in Form 7 to the Appellate
Authority comprising of the Environment Secretary of the State.
(2) The Appellate Authority may entertain the appeal after expiry of the said period of
thirty days if it is satisfied that the appellant was prevented by sufficient cause from
filing the appeal in time.
(3) Every appeal filed under this rule shall be disposed of within a period of sixty days
from the date of its filing.
23.
The collection, storage, transportation, segregation, refurbishment, dismantling,
recycling and disposal of e-waste shall be in accordance with the procedures
prescribed in the guidelines published by the Central Pollution Control Board from time
to time. Implementation of e-waste (Management and Handling) Amendment Rules,
2011 shall be in accordance with the guidelines prescribed by the Central Pollution
Control Board from time to time.
24.
Urban Local Bodies (Municipal Committee or Council or Corporation) shall
ensure that e-waste pertaining to orphan products is collected and channelised to
authorised dismantler or recycler.

******

16

<!-- page 17 -->

SCHEDULE I
[See rules 2, 3(j), 3(y), 3(aa) and 3(ff); 5; 9; 11(10); 13 (1) (i), 13 (1) (vii) and 16(1),
16(11)]
Categories of electrical and electronic equipment including their components,
consumables, parts and spares covered under the rules
Sr.
No.

i.

ii.

Categories of electrical and electronic equipment

Electrical and
electronic
equipment
code

Information technology and telecommunication
equipment :
Centralised data processing: Mainframes, Minicomputers ITEW1
Personal Computing: Personal Computers (Central
Processing Unit with input and output devices)
Personal
Computing:
Laptop
Computers(Central
Processing Unit with input and output devices)
Personal Computing: Notebook Computers
Personal Computing: Notepad Computers
Printers including cartridges
Copying equipment
Electrical and electronic typewriters
User terminals and systems
Facsimile
Telex
Telephones
Pay telephones
Cordless telephones
Cellular telephones
Answering systems
Consumer electrical and electronics:
Television sets (including sets based on (Liquid Crystal
Display and Light Emitting Diode technology)
Refrigerator
Washing Machine
Air-conditioners excluding centralised air conditioning
plants
Fluorescent and other Mercury containing lamps

17

ITEW2
ITEW3
ITEW4
ITEW5
ITEW6
ITEW7
ITEW8
ITEW9
ITEW10
ITEW11
ITEW12
ITEW13
ITEW14
ITEW15
ITEW16
CEEW1
CEEW2
CEEW3
CEEW4
CEEW5

<!-- page 18 -->

SCHEDULE II
[See rules 16 (3), 16 (4) and 16 (11)]
Applications, which are exempted from the requirements of sub-rule (1) of rule 16
Substance
1
Mercury in single capped (compact) fluorescent lamps not exceeding (per
burner):
1(a)
For general lighting purposes <30 W : 2.5 mg
1(b)

For general lighting purposes ≥ 30 W and <50 W : 3.5mg

1(c)

For general lighting purposes ≥ 50 W and <150 W : 5mg

1(d)

For general lighting purposes ≥150 W : 15 mg

1(e)

For general lighting purposes with circular or square structural shape and tube
diameter ≤17 mm : 7mg
For special purposes:5 mg

1(f)
2(a)
2(a)(1)

Mercury in double-capped linear fluorescent lamps for general lighting
purposes not exceeding (per lamp):
Tri-band phosphor with normal life time and a tube diameter < 9mm (e.g.
T2): 4mg

2(a)(2)

Tri-band phosphor with normal life time and a tube diameter ≥ 9 mm and
≤ 17 mm (e.g. T5): 3 mg

2(a)(3)

2(b)
2(b)(1)

Tri- band phosphor with normal life time and a tube diameter >17 mm and
≤ 28 mm(e.g. T8): 3.5 mg
Tri-band phosphor with normal life time and a tube diameter >28 mm (e.g. T
12):3.5 mg
Tri-band phosphor with long life time (≥25000 h):5mg
m
Mercury in other fluorescent lamps not exceeding(per lamp):
Linear halophosphate lamps with tube >28 mm (e.g. T 10 and T12):10 mg

2(b)(2)

Non-linear halophosphate lamps(all diameters):15mg

2(b)(3)

Non-linear tri-band phosphor lamps with tube diameter >17 mm(e.g.T9):
mm mmkh
15 mg
Lamps for other general lighting and special purposes (e.g. induction
mmmmmmm
lamps):15mg (e.g.T2) : 4 mg
Mercury in cold cathode fluorescent lamps and external electrode fluorescent
lamps (CCFL and EEFL)for special purposes not exceeding (per lamp):

2(a)(4)
2(a)(5)

2(b)(4)
3
3(a)

Short length( < 500 mm):3.5mg

3(b)

Medium length(>500 mm and<1500 mm): 5mg

3(c)

Long length(>1500 mm): 13mg

4(a)

Mercury in other low pressure discharge lamps (per lamp): 15mg

4(b)

Mercury in High Pressure Sodium(vapour) lamps for general lighting
purposes not exceeding (per burner)in lamps with improved colour rendering
index Ra>60:
18

<!-- page 19 -->

4(b)-I

P ≤155 W : 30 mg

4(b)-II

155 W < P <405 W : 40 mg

4(b)-III

P >405 W: 40 mg

4(c)

Mercury in other High Pressure Sodium(vapour)lamps for general lighting
purposes not exceeding (per burner):

4(c)-I

P<155 W:25mg

4(c)-II

155 W < P < 405 W:30 mg

4(c)-III

P >405 W:40 mg

4(d)

Mercury in High Pressure Mercury (vapour) lamps (HPMV)

4(e)

Mercury in metal halide lamps (MH)

4(f)

Mercury in other discharge lamps for special purposes not specifically
mentioned in this Schedule

5(a)

Lead in glass of cathode ray tubes

5(b)

Lead in glass of fluorescent tubes not exceeding 0.2% by weight

6(a)

Lead as an alloying element in steel for machining purposes and in galvanized
steel containing up to 0.35% lead by weight

6(b)

Lead as an alloying element in aluminium containing up to 0.4% lead by
weight

6(c)

Copper alloy containing up to 4% lead by weight

7(a)

Lead in high melting temperature type solders (i.e. lead-based alloys
containing 85% by weight or more lead)
Lead in solders for servers, storage and storage array systems, network
infrastructure
equipment for switching, signalling, transmission, and
network management for telecommunications

7(b)

7(c)-I

Electrical and electronic components containing lead in a glass or ceramic
other than dielectric ceramic in capacitors, e.g. piezoelectronic devices, or in a
glass or ceramic matrix compound.

7(c)-II

Lead in dielectric ceramic in capacitors for a rated voltage of 125 V AC or
250 V DC or higher

7(c)-III
8(a)

Lead in dielectric ceramic in capacitors for a rated voltage of less than 125
V AC or 250 V DC
Cadmium and its compounds in one shot pellet type thermal cut-offs

8(b)

Cadmium and its compounds in electrical contracts

9

Hexavalent chromium as an anticorrosion agent of the carbon steel cooling
system in absorption refrigerators up to 0.75% by weight in the cooling
solution
Lead in bearing shells and bushes for refrigerant-containing compressors
for heating, ventilation, air conditioning and refrigeration (HVACR)
application.

9(b)

19

<!-- page 20 -->

11(a)

Lead used in C-press compliant pin connector systems

11(b)

Lead used in other than C-press compliant pin connector systems

12

Lead as a coating material for the thermal conduction module C- ring

13(a)

Lead in white glasses used for optical applications

13(b)
14

Cadmium and lead in filter glasses and glasses used for reflectance
standards.
Lead in solders consisting of more than two elements for the connection
between the pins and the package of microprocessors with a lead content
of more than 80% and less than 85% by weight

15

Lead in solders to complete a viable electrical connection
between
semiconductor die and carrier within integrated circuit flip chip packages.

16

Lead in linear incandescent lamps with silicate coated tubes

17

Lead halide as radiant agent in high intensity discharge (HID) lamps used for
professional reprography applications.

18(a)

Lead as activator in the fluorescent powder (1% lead by weight or less) of
discharge lamps when used as specialty lamps for diazoprinting
reprography, lithography, insect traps, photochemical and curing processes
containing phosphors such as SMS ((Sr, Ba)2Mg Si2O7:Pb)

18(b)

Lead as activator in the fluorescent powder (1% lead by weight or less) of
discharge lamps when used as sun tanning lamps containing phosphors such
as BSP (Ba Si2O5:Pb)

19

Lead with PbBiSn-Hg and PblnSn-Hg in specific compositions as main
amalgam and with PbSn-Hg as auxiliary amalgam in very compact
energy saving lamps (ESL)

20

Lead oxide in glass used for bonding front and rear substrates of
fluorescent lamps used for Liquid Crystal Displays (LCDs)

21

Lead and cadmium in printing inks for the application of enamels on
glasses, such as borosilicate and soda lime glasses

23

Lead in finishes of fine pitch components other than connectors with a pitch of
0.65 mm and less

24

Lead in solders for the soldering to machined through hole discoidal and
planar array ceramic multilayer capacitors

25

Lead oxide in surface conduction electron emitter displays (SED) used in
structural elements, notably in the seal frit and frit ring.

26

Lead oxide in the glass envelope of black light blue lamps

27

Lead alloys as solder for transducers used in high-powered (designated to
operate for several hours at acoustic power levels of 125 dB SPL and
above) loudspeakers

29

Lead bound in crystal glass

20

flat

<!-- page 21 -->

30

Cadmium alloys as electrical/mechanical solder joints to electrical conductors
located directly on the voice coil in transducers used in high-powered
loudspeakers with sound pressure levels of 100 dB(A) and more

31

Lead in soldering materials in mercury free flat fluorescent lamps
(which e.g. are used for liquid crystal displays, design or industrial
lighting)

32

Lead oxide in seal frit used for making window assemblies for Argon and
Krypton laser tubes

33

Lead in solders for the soldering of thin copper wires of 100 µm diameter
and less in power transformers

34

Lead in cermet-based trimmer potentiometer elements

36

Mercury used as a cathode sputtering inhibitor in DC plasma displays with a
content up to 30 mg per display

37

Lead in the plating layer of high voltage diodes on the basis of a zinc
borate glass body

38

Cadmium and cadmium oxide in thick film pastes used on aluminium bonded
beryllium oxide

39

Cadmium in colour converting II-VI LEDs (<10 µg Cd per mm2of lightemitting area) for use in solid state illumination or display systems.

21

<!-- page 22 -->

SCHEDULE III
[See rules 5 (1) (a) and 13 (1) (ii)]
Targets for Extended Producer Responsibility - Authorisation
No.

Year

(i)

During first two year of
implementation of rules

(ii)

During third and fourth years of
implementation of rules

(iii)

During Fifth and Sixth years of
implementation of rules

(iv)

Seventh year onward of
implementation of rules

E-Waste Collection Target
(Number/Weight)
30% of the quantity of waste generation as
indicated
in
Extended
Producer
Responsibility Plan.
40% of the quantity of waste generation as
indicated
in
Extended
Producer
Responsibility Plan.
50% of the quantity of waste generation as
indicated
in
Extended
Producer
Responsibility Plan.
70% of the quantity of waste generation as
indicated
in
Extended
Producer
Responsibility Plan.

22

<!-- page 23 -->

SCHEDULE IV
[See rule (17)]
LIST OF AUTHORITIES AND CORREPONDING DUTIES
Sr. No
1.

2.

AUTHORITY
CORRESPONDING DUTIES
Central Pollution (i) Grant and Renewal of Extended Producer Responsibility
Control
Board,
- Authorisation and monitoring of its compliance.
Delhi
(ii) Maintain
information
on
Extended
Producer
Responsibility - Authorisation on its web site.
(iii) Set and revise targets for collection of e-waste from time
to time.
(iv) Coordination with State Pollution Control Boards
(v) Preparation of Guidelines for Environmentally Sound
Management of e-waste.
(vi) Conduct random check for ascertaining compliance of
the e-waste rules and identification of such importers or
producers who have not applied for Extended Producer
Responsibility authorisation or are not complying with
RoHS provision. Wherever necessary, Central Pollution
Control Board will seek the help of customs department
or any other agency of the Government of India.
(vii) Conduct random inspection of dismantler or recycler or
refurbisher.
(viii) Documentation, compilation of data on e-waste and
uploading on websites of Central Pollution Control Board
(ix) Actions against violation of these rules.
(x) Conducting training programmes.
(xi) Submit Annual Report to the Ministry.
(xii) Enforcement of provisions regarding reduction in use of
hazardous substances in manufacture of electrical and
electronic equipment.
(xiii) Interaction with IT industry for reducing hazardous
substances.
(xiv) Set and revise targets for compliance to the reduction in
use of hazardous substance in manufacture of electrical
and electronic equipment from time to time.
(xv) Any other function delegated by the Ministry under these
rules from time to time.
State Pollution
(i) Inventorisation of e-waste.
Control Boards or
(ii) Grant and renewal of authorisation to manufacturers,
Committees of
dismantlers, recyclers and refurbishers.
Union territories
(iii) Monitoring and compliance of Extended Producer
Responsibility - Authorisation as directed by Central
Pollution Control Board and that of dismantlers, recyclers
and refurbishers authorisation.
(iv) Conduct random inspection of dismantler or recycler or
refurbisher.
(v) Maintain online information regarding authorisation
granted to manufacturers, dismantlers, recyclers and
refurbishers.
23

<!-- page 24 -->

Sr. No

AUTHORITY

3.

Urban Local
Bodies (Municipal
Committee or
Council or
Corporation)

4.

Port
authority
under Indian Ports
Act, 1908 (15 of
1908)
and
Customs Authority
under the Customs
Act, 1962 (52 of
1962)

CORRESPONDING DUTIES
(vi) Implementation
of
programmes
to
encourage
environmentally sound recycling.
(vii) Action against violations of these rules.
(viii) Any other function delegated by the Ministry under these
rules.
(i) To ensure that e-waste if found to be mixed with Municipal
Solid Waste is properly segregated, collected and is
channelised to authorised dismantler or recycler.
(ii) To ensure that e-waste pertaining to orphan products is
collected and channelised to authorised dismantler or
recycler.
(i) Verify the Extended Producer Responsibility Authorisation.
(ii) Inform Central Pollution Control Board of any illegal traffic
for necessary action.
(iii) Take action against importer for violations under the
Indian Ports Act, 1908/Customs Act, 1962.

****

24

<!-- page 25 -->

FORM-1
[See Rules 5(1) (g), 13(1) (i), 13(1) (vi)]
Applicable to producers seeking Extended Producer Responsibility Authorisation
The application form should contain the following information:
1.

2.

3.

4.

Name and full address along with
telephone numbers, e-mail and other
contact details of Producer (It should
be the place from where sale in entire
country is being managed)
Name of the Authorised Person and
full address with e-mail, telephone and
fax number
Name, address and contact details of
Producer Responsibility Organisation,
if any with full address, e-mail,
telephone and fax number, if engaged
for implementing the Extended
Producer Responsibility
Details of electrical and electronic
equipment placed on market year-wise
during previous 10 years in the form of
Table 1 as given below:

:

:

:

:

Table 1: Details of Electrical and Electronic Equipment placed on the market in
previous years - Code wise
Sr. Electrical and
No. Electronic
Equipment Item

A
1

2

3

Electrical
Quantity, number and weight placed on
and
market (year-wise)
Electronic
Equipment
Code
Information technology and telecommunication equipment:
Centralised
data ITEW1
processing:
Mainframes,
Minicomputers
Personal
ITEW2
Computing:
Personal
Computers (Central
Processing
Unit
with
input
and
output devices)
Personal
ITEW3
Computing: Laptop
Computers(Central
Processing
Unit
with
input
and
25

<!-- page 26 -->

4

5

6
7
8

9
10
11
12
13
14
15
16
B
17

18
19
20

21

output devices)
Personal
ITEW4
Computing:
Notebook
Computers
Personal
ITEW5
Computing:
Notepad Computers
Printers
including ITEW6
cartridges
Copying equipment ITEW7
Electrical
and ITEW8
electronic
typewriters
User terminals and ITEW9
systems
Facsimile
ITEW10
Telex
ITEW11
Telephones
ITEW12
Pay telephones
ITEW13
Cordless
ITEW14
telephones
Cellular telephones ITEW15
Answering systems ITEW16
Consumer electrical and electronics:
Television
sets CEEW1
(including
sets
based on (Liquid
Crystal Display and
Light Emitting Diode
technology)
Refrigerator
CEEW2
Washing Machine
CEEW3
Air-conditioners
CEEW4
excluding
centralised
air
conditioning plants
Fluorescent
and CEEW5
other
Mercury
containing lamps

26

<!-- page 27 -->

5.

Estimated generation of Electrical and Electronic Equipment waste item-wise and
estimated collection target for the forthcoming year in the form of Table 2
including those being generated from their service centres, as given below:

Table 2: Estimated generation of Electrical and Electronic Equipment waste
item-wise and estimated collection target for the forthcoming year
Sr.
No.

Item

Estimated
waste Targeted
electrical
and collection
electronic equipment
generation
Number
weight
Number and weight

and

6. Extended Producer Responsibility Plans:
(a) Please provide details of your overall scheme to fulfil Extended Producer
Responsibility obligations including targets. This should comprise of general
scheme of collection of used/waste Electrical and Electronic Equipment from
the Electrical and Electronic Equipment placed on the market earlier such as
through dealers and collection centres, Producer Responsibility Organisation,
through buy-back arrangement, exchange scheme, Deposit Refund Scheme,
etc. whether directly or through any authorised agency and channelising the
items so collected to authorised recyclers.
(b) Provide the list with addresses along with agreement copies with dealers,
collection centres, recyclers, Treatment, Storage and Disposal Facility, etc.
under your scheme.
7. Estimated budget for Extended Producer Responsibility and allied initiatives to
create consumer awareness.
8. Details of proposed awareness programmes.
9. Details for Reduction of Hazardous Substances compliance (to be filled if
applicable):
(a) Whether the Electrical and Electronic Equipment placed on market complies with
the rule 16 (1) limits with respect to lead, mercury, cadmium, hexavalent chromium,
polybrominated biphenyls and polybrominateddiphenyl ethers;
(b)Provide
the
technical
documents
(Supplier
declarations,
Materials
declarations/Analytical reports) as evidence that the Reduction of Hazardous
Substances (RoHS) provisions are complied by the product based on standard EN
50581 of EU;
(c) Documents required:
i. Extended Producer Responsibility plan;
ii. Copy of the permission from the relevant Ministry/Department for selling their
product;
27

<!-- page 28 -->

iii. Copies of agreement with dealers, collection centre, recyclers, Treatment,
Storage and Disposal Facility, etc.;
iv. Copy of Directorate General of Foreign Trade license/permission as applicable;
v. Self-declaration regarding Reduction of Hazardous Substances provision;
vi. Any other document as required.

(Authorised signature)
Place: __________
Date: __________

28

<!-- page 29 -->

FORM 1(a)
[See rules 4(2), 8 (2), 13(2) (ii), 13(2) (vi) and 13(4) (i)]
APPLICATION FOR OBTAINING AUTHORISATION FOR GENERATION OR
STORAGE OR TREATMENT OR DISPOSAL OF E-WASTE BY MANUFACTURER
OR REFURBISHER*
From: ....................................
....................................
To
The Member Secretary,
................. Pollution Control Board or……………… Pollution Control Committee
........................................................
........................................................
Sir,
I / We hereby apply for authorisation/renewal of authorisation under rule 13(2) (i)
to 13(2) (viii) and/or 13 (4) (i) of the E-Waste (Management) Rules, 2016 for
collection/storage/ transportation/ treatment/ refurbishing/disposal of e-wastes.
For Office Use Only
Code No. :
Whether the unit is situated in a critically polluted area as identified by Ministry of
Environment and Forests (yes/no);
To be filled in by Applicant
1. Name and full address:
2. Contact Person with designation and contact details such as telephone Nos, Fax.
No. and E-mail:
3. Authorisation required for (Please tick mark appropriate activity/ies*)
(i) Generation during manufacturing or refurbishing*

(ii) Treatment, if any

(iii) Collection, Transportation, Storage

(iv) Refurbishing

4. E-waste details:
(a) Total quantity e-waste generated in MT/A
(b) Quantity refurbished (applicable to refurbisher)
(c) Quantity sent for recycling
(d) Quantity sent for disposal
5. Details of Facilities for storage/handling/treatment/refurbishing:
6. In case of renewal of authorisation previous authorisation no. and date and details
of annual returns:

Place : __________

Signature ______________

(Name_________________)
Date : __________
Designation: ___________
29

<!-- page 30 -->

Note:(1) * The authorisation for e-waste may be obtained along with authorisation for
hazardous waste under the Hazardous Wastes (Management, Handling and
Transboundary Movement) Rules, 2008, if applicable.
(2) Wherever necessary, use additional sheets to give requisite and necessary details.

30

<!-- page 31 -->

FORM 1 (aa)
[See rules 5 (6) and 13(1)(ii)]
FORMAT OF EXTENDED PRODUCER RESPONSIBILITY - AUTHORISATION
[Extended Producer Responsibility Authorisation for Producer of the Electrical
& Electronic Equipment]
Ref: Your application for Grant of Extended Producer Responsibility - Authorisation for
following Electrical & Electronic Equipment under E-Waste (Management) Rules, 2016
1. Number of Authorisation:
Date:
2. M/s. ------------------- is hereby granted Extended Producer Responsibility Authorisation based on:
(a) overall Extended Producer Responsibility plan
(b) proposed target for collection of e-waste
3. The Authorisation shall be valid for a period of ___ years from date of issue
with following conditions:
(i) you shall strictly follow the approved Extended Producer Responsibility plan,
a copy of which is enclosed herewith;
(ii) you shall ensure that collection mechanism or centre are set up or
designated as per the details given in the Extended Producer Responsibility
plan. Information on collection mechanism/centre including the state-wise setup
should be provided;
(iii) you shall ensure that all the collected e-waste is channelised to authorised
dismantler or recycler designated as per the details. Information on authorised
dismantler or recycler designated state-wise should be provided;
(iv) you shall maintain records, in Form-2 of these Rules, of e-waste and make
such records available for scrutiny by Central Pollution Control Board;
(v) you shall file annual returns in Form-3 to the Central Pollution Control Board
on or before 30th day of June following the financial year to which that returns
relates;
(vi) General Terms & Conditions of the Authorisation:
a. The authorisation shall comply with provisions of the Environment
(Protection) Act, 1986 and the Rules made there under;
b. The authorisation or its renewal shall be produced for inspection at the
request of an officer authorised by the Central Pollution Control Board;
c. Any change in the approved Extended Producer Responsibility plan
should be informed to Central Pollution Control Board on which decision
31

<!-- page 32 -->

shall be communicated by Central Pollution Control Board within sixty
days;
d. It is the duty of the authorised person to take prior permission of the
concerned State Pollution Control Boards and Central Pollution Control
Board to close down the facility;
e. An application for the renewal of authorisation shall be made as laid
down in sub-rule (vi) of rule of 13(1) the E-Waste (Management) Rules,
2016;
f. The Board reserves right to cancel/amend/revoke the authorisation at
any time as per the Policy of the Board or Government.

Authorized signatory
(with designation)
To,
Concerned Producer
Copy to:
1. Member Secretary, Concerned State.
2. In-charge, concerned Zonal Office, Central Pollution Control Board.

32

<!-- page 33 -->

FORM 1(bb)
[See rules 4(2), 8(2)(a), 13(2) (iii) and 13(4)(ii)]
FORMAT FOR GRANTING AUTHORISATION FOR GENERATION OR STORAGE
OR TREATMENT OR REFURBISHING OR DISPOSAL OF E-WASTE BY
MANUFACTURER OR REFURBISHER
Ref: Your application for Grant of Authorisation
1. (a) Authorisation no. ................ and (b) date of issue ………………………….
2.
……..….…………………of……………………………is
hereby
granted
an
authorisation for generation, storage, treatment, disposal of e-waste on the premises
situated at………………………………………… for the following:
a.
quantity of e-waste;
b.
nature of e-waste.
3. The authorisation shall be valid for a period from ……… to …………
4. The e-waste mentioned above shall be treated/ disposed off in a manner ............ at
..............
5. The authorisation is subject to the conditions stated below and such conditions as
may be specified in the rules for the time being in force under the Environment
(Protection) Act, 1986.
Signature ------------------------Designation ----------------------

Date: --------------------

Terms and conditions of authorisation
1. The authorisation shall comply with the provisions of the Environment (Protection)
Act, 1986, and the rules made thereunder.
2. The authorisation or its renewal shall be produced for inspection at the request of
an officer authorized by the concerned State Pollution Control Board.
3. Any unauthorised change in personnel, equipment as working conditions as
mentioned in the application by the person authorized shall constitute a breach of
his authorisation.
4. It is the duty of the authorised person to take prior permission of the concerned
State Pollution Control Board to close down the operations.
5. An application for the renewal of an authorisation shall be made as laid down in
sub-rule (vi) of rule 13(2).

33

<!-- page 34 -->

FORM-2
[See rules 4(4), 5(4), 6(5), 8(7), 9(2), 10(7), 11(8), 13 (1) (xi), 13(2)(v), 13(3)(vii) and
13 (4)(v)]
FORM FOR MAINTAINING RECORDS OF E-WASTE HANDLED OR GENERATED

1.

2.

3.

4.

5.
6.

7.

8.

9.

Generated Quantity in Metric Tonnes (MT) per year
Name & Address:
Producer or
Manufacturer or
Refurbisher or
Dismantler or Recycler
or Bulk Consumer*
Date of Issue of
Extended Producer
Responsibility
Authorisation*/
Authorisation*
Validity of Extended
Producer Responsibility
Authorisation*/
Authorisation*
Types & Quantity of eCategory
Quantity
waste handled or
Item Description
generated**
Types & Quantity of
Category
Quantity
e-waste stored
Item Description
Types & Quantity of
Category
Quantity
e-waste sent to
Item Description
collection centre
authorised by producer/
dismantler/recycler /
refurbisher or authorised
dismantler/recycler or
refurbisher**
Types & Quantity of
Category
Quantity
e-waste transported*
Quantity
Name, address and
contact details of the
destination
Types & Quantity of
Category
Quantity
e-waste refurbished*
Item Description
Name, address and
contact details of the
destination of
refurbished materials
Types & Quantity of
Category
Quantity
e-waste dismantled*
Item Description
Name, address and
contact details of the
destination
34

<!-- page 35 -->

10.

11.

12.

13.

Types & Quantity of
e-waste recycled*
Types & Quantity of
materials recovered
Name, address and
contact details of the
destination
Types & Quantity of ewaste sent to recyclers
by dismantlers
Name, address and
contact details of the
destination
Types & Quantity of
other waste sent to
respective recyclers by
dismantlers/recyclers of
e-waste
Name, address and
contact details of the
destination
Types & Quantity of
e-waste treated &
disposed
Name, address and
contact details of the
destination

Category

Quantity

Item Description
Quantity

Category
Item Description

Quantity

Category

Quantity

Item Description

Category
Item Description

Quantity

Note:(1) * Strike off whichever is not applicable
(2) Provide any other information as stipulated in the conditions to the authoriser
(3) ** For producers this information has to be provided state-wise

35

<!-- page 36 -->

FORM-3
[See rules 4(5), 5(5), 8(6), 9(4), 10(8), 11(9), 13 (1) (xi), 13(2)(v), 13(3)(vii) and
13(4)(v)]
FORM FOR FILING ANNUAL RETURNS
[To be submitted by producer or manufacturer or refurbisher or dismantler or recycler
by 30th day of June following the financial year to which that return relates].

1

2

3

3(A)*
3(B)*
3(C)*

3(D)*

4
5

Quantity in Metric Tonnes (MT) and numbers
Name and address of the producer or
manufacturer or refurbisher or dismantler
or recycler
Name of the authorised person and
complete address with telephone and fax
numbers and e-mail address
Total quantity of e-waste collected or
channelised to recyclers or dismantlers
for processing during the year for each
category of electrical and electronic
equipment listed in the Schedule I
(Attach list) by PRODUCERS
Details of the above
TYPE
QUANTITY
BULK CONSUMERS: Quantity of ewaste
REFURBISHERS: Quantity of e-waste:
DISMANTLERS:
i Quantity of e-waste processed (Code
wise);
ii. Details of materials or components
recovered and sold;
iii. Quantity of e-waste sent to recycler;
iv. Residual quantity of e-waste sent to
Treatment, Storage and Disposal
Facility.
RECYCLERS:
i. Quantity of e-waste processed (Code
wise);
ii. Details of materials recovered and sold
in the market;
iii. Details of residue sent to Treatment,
Storage and Disposal Facility.
Name and full address of the destination
with respect to 3(A)-3(D) above
Type and quantity of materials
Type
Quantity
segregated or recovered from e-waste of
different codes as applicable to 3(A)-3(D)

✔ Enclose the list of recyclers to whom e-waste have been sent for recycling.

Place_________________
36

No.

<!-- page 37 -->

Date__________________

Signature of the authorised person

Note:(1) * Strike off whichever is not applicable
(2) Provide any other information as stipulated in the conditions to the authoriser
(3) In case filing on behalf of multiple regional offices, Bulk Consumers and Producers
need to add extra rows to 1 & 3(A) with respect to each office.

37

<!-- page 38 -->

FORM-4
[See rules 13(3)(i) and 13(3)(vi)]
APPLICATION FORM FOR AUTHORISATION OF FACILITIES POSSESSING
ENVIRONMENTALLY SOUND MANAGEMENT PRACTICE FOR DISMANTLING OR
RECYCLING OF E-WASTE

7.

(To be submitted in triplicate)
Name and Address of the unit
Contact person with designation, Tel./Fax
Date of Commissioning
No.of workers (including contract labour)
Consents Validity
a. Water (Prevention and Control
of Pollution) Act, 1974;
Valid up to _________________
b. Air (Prevention and Control of
Pollution) Act, 1981;
Valid up to_________________
Validity of current authorisation if any
e-waste (Management &
Handling) Rules, 2011;
Valid up to _____________
Dismantling or Recycling Process
Please attach complete details

8.

Installed capacity in MT/year

Products

9.

E-waste processed during last three years

Year

1.
2.
3.
4.
5.

6.

10. Waste Management:
a. Waste generation in processing e-waste

b.

Provide details of disposal of residue.

Installed capacity
(MTA)

Product

Please provide details material
wise

Please provide details

c. Name of Treatment Storage and Disposal
Facility utilized for
11. Details of e-waste proposed to be procured from
re-processing

Please provide details

12. Occupational safety and health aspects
13. Details of Facilities for dismantling both manual
as well as mechanised:

Please provide details

38

Quantity

<!-- page 39 -->

14. Copy of agreement with Collection Centre
15. Copy agreement with Producer
16. Details of storage for dismantled e-waste
17. Copy of agreement with Recycler
18. Details of Facilities for Recycling
19. Copy of agreement with Collection Centre
20. Copy agreement with Producer
21. Details of storage for
recovered materials

raw materials and

II. In case of renewal of authorisation, previous registration or authorisation no.
and date
I hereby declare that the above statements or information are true and correct to the
best of my knowledge and belief.

Signature

Place:______________

Name:________________________

Date:______________

Designation:________________________

39

<!-- page 40 -->

Form-5
[See rule 18 (1)]
FORM FOR ANNUAL REPORT TO BE SUBMITTED BY THE STATE POLLUTION
CONTROL BOARD TO THE CENTRAL POLLUTION CONTROL BOARD
To,
The Chairman,
Central Pollution Control Board,
(Ministry of Environment And Forests)
Government Of India, ‘Parivesh Bhawan’, East Arjun Nagar,
Delhi- 110 0032
1.

2.
3.
4.
5.
6.

Number
of
authorised
manufacturer, :
refurbisher, collection centre, dismantler and
recycler for management of e-waste in the
State or Union territory under these rules
Categories of waste collected along with : Please attach as Annexure-I
their quantities on a monthly average basis:
A Summary Statement code-wise of e-waste : Please attach as Annexure-II
collected
Details of material recovered from recycling :
of e-waste
Quantity of CFL received at Treatment, :
Storage and Disposal Facility
The above report is for the period from ……………to .............…………………

Place: _________________
Date: ________________
Chairman or the Member Secretary
State Pollution Control Board

40

<!-- page 41 -->

Form-6
[See rule 19]
1.

2.
3.
4.

5.
6.
7.
8.
9.
10.
11.

12.

13.

E-WASTE MANIFEST
Sender’s name and mailing address
(including
Phone
No.)
:
Sender’s authorisation No, if applicable.
:
Manifest
Document
No.
:
Transporter’s
name
and
address
: (including Phone No.)
Type
of
vehicle (Truck or Tanker or Special
:
Vehicle)
Transporter/s
registration
No.
:
Vehicle registration No.
:
Receiver’s name & address :
Receiver’s authorisation No, if applicable.
:
Description of E-Waste (Item, Weight/
Numbers) :
Name and stamp of Sender* (Manufacturer or Producer or Bulk Consumer or
Collection Centre or Refurbisher or Dismantler):
Signature:
Month
Day
Year
Transporter acknowledgement of receipt of
E-Wastes
Name and stamp:
Signature:
Year

Month

Day

Receiver* (Collection Centre or Refurbisher or Dismantler or Recycler)
certification of receipt of E-waste
Name and stamp:
Signature:
Month
Day
Year

* As applicable
Note:Copy
number
Purpose
with colour code
(2)
(1)
Copy 1 (Yellow)
To be retained by the sender after taking signature on it from the
transporter and other three copies will be carried by transporter.
Copy 2 (Pink)
To be retained by the receiver after signature of the transporter.
Copy 3 (Orange) To be retained by the transporter after taking signature of the
receiver.
Copy 4 (Green)
To be returned by the receiver with his/her signature to the sender
41

<!-- page 42 -->

FORM 7
[See rule 22]

APPLICATION FOR FILING APPEAL
AGAINST THE ORDER PASSED BY CENTRAL POLLUTION CONTROL
BOARD/STATE POLLUTION CONTROL BOARD
1.
2.
3.
4.
5.

Name and address of the person making the appeal
Number, date of order and address of the authority
to which passed the order, against which appeal is
Ground on which the appeal is being made
Relief sought for
List of enclosures other than the order referred
in point 2 against which the appeal is being filed.

:
: (certified copy of the
order be attached)
:
:
:

Signature………………….
Name and address………….
Place:
Date:

____________________________________________________________________
Bishwanath Sinha
Joint Secretary to Government of India
(F No. 12-6/2013-HSMD)
*************

42
