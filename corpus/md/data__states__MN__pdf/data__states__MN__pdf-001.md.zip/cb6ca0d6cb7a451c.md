---
doc_id: "cb6ca0d6cb7a451c"
source_url: "https://gadmanipur.nic.in/media/vxdbwni1/time_extension.pdf"
ministry: "General Administration Department, Manipur"
title: "TENDER EXTENSION NOTICE"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8728831a9b11e16d"
---

<!-- page 1 -->

Str-206/2/2023-GAD-GAD-Part(1)

I/80157/2025

GOVERNMENT OF MANIPUR
STATIONERY DEPARTMENT
***
TENDER EXTENSION NOTICE
Imphal, the 24th April, 2025
No. Str-206/2/2023-GAD-GAD-Part(1) : In continuation of this Oﬃce’s Notice Inviting Tender
(NIT) of even No. dated 4th April, 2025 regarding supply of various stationery items to the
Manipur Secretariat on an Annual Rate Contract (ARC) basis, it is informed that due to
administrative reasons, the last date for submission of tender documents has been extended
and revised as per the details mentioned below.
Downloading of Tender Document

20-04-2025

Last Date of seeking clarification

27-04-2025

Physical submission of EMD & Tender Fee 01-05-2025 from 11:00 AM to 3:00 PM
Last Date of uploading of Tender

08-05-2025 upto 3:00 PM

Date of Opening of Price Bid

Shall be decided by the Tender Committee

2. All other information and guidelines of the earlier tender notice of even number dated 4th
April 2025, and the subsequent addendum of even number dated 23rd April 2025, shall
remain unchanged.

(Asem Rangina Chanu)
Deputy Secretary (GAD/STY),
Government of Manipur
Copy to:

1. Staff Officer to Chief Secretary, Government of Manipur.
2. APS to Secretary (GAD/STY), Government of Manipur.
3. SIO, NIC Manipur State Unit for uploading the Addendum in
https://manipurtenders.gov.in

4. The Director (DIPR), Manipur.
5. Director/IT for uploading in Manipur Government website
6. Notice Board (North & South) Block, Manipur Secretariat.
7. Guard File.
