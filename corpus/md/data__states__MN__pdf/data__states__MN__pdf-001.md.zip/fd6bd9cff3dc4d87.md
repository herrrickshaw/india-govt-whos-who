---
doc_id: "fd6bd9cff3dc4d87"
source_url: "https://ssamanipur.nic.in/Downloads/1.pdf"
ministry: "Sarva Shiksha Abhiyan (SSA), Manipur"
title: "Corrigendum for Notice of engagement on contract basis under SSA"
date: ""
pages: 1
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "e49cb40307b6b5fa"
---

<!-- page 1 -->

- চে [SARVA SHIKSHA ABHIGAIN |
' q 1 i ¢ i my *
১1011 STIASHA ABHIVAN STATE MISSION AUTHORITY WAMIPER
Priester Chief Minister, Manipur Regd No. 14Q/M/SR/2000
00115 Body Babupata, Imphal - 796091
cawman Chiel Secretary, Tele Fax 0369 - 2448534. 24486534
{xecutive Commttae — Government of Manipur e-mail ss@_manipur@renifime: com
CORRIGENDUM
Imphal, the 7" February 2015
No, 1/6/2013-SSA/SMA: In continuation of this office notification of even no. dated
28" February 2015 for contractual engagement of 13 categories of posts numbering 435
posts, the following essential and desirable qualifications for the posts of (i) System
Analys+, (ii) Subject specific Resource Persons and (iii) Cluster Resource Persons stands
partially modified as detailed under
| Essential Qualification: |
| (i) M.Sc.(Computer Science) M.Sc.(LT)/MCA/MBA(IT)/ PG
DITM from a recognized University/Institution.
(i) Bachelor's Degree in Engineering (Computer
1 System Analyst — Science)/Information Technology with a minimum of 2(two)
| years experience in data processing, data management,
| Software Development with following skill areas: VISUAL
BASIC, VISUAL FOXPRO, SQL, JAVA, COBOL, HTML,
Subject Specific | Essential Qualification:
Resource Person “ Masters' Degree or its equivalent from a recognized
2 (Language, University/Institution in concerned subject (Maths,
Mathematics, Science, Language, Social Science, Statistics &
| Social Science, Commerce, Social Works, Sociology). |
____ Science) esirable
| + Bachelor of Education (8,Ed)/Master of Education
3 Cluster Resource (M.Ed).
Person Knowledge of Computer.
i Knowledge of Manipuri, Hindi, English. _ |
=a
৫
(owe?
State Project Director
SSA/SMA, Manipur
Copy to:
1. The Secretary to Hon'ble Chief Minister, Manipur
2, The PPS to Hon'ble Minister, Education (S), Manipur,
3. The Staff Officer to Chief Secretary, Manipur.
4. The Secretary, Education (S), Manipur.
5, The Director of School Education (5), Manipur.
6. The€ditor, - For kind publication in their esteemed
daily.
7. File.
