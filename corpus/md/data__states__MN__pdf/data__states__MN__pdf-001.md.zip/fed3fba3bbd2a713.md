---
doc_id: "fed3fba3bbd2a713"
source_url: "https://familywelfare.mn.gov.in/uploads/news/2024/01/16/Memo_Review_Meeting_on_RI_on_15-1-2024.pdf"
ministry: "Family Welfare Department, Manipur"
title: "Memorandum regarding A State Level Review meeting on Routine Immunization and Covid Vaccination will be held on 15th January 2024."
date: ""
pages: 1
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "3c8c3fb6d97b14b5"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
DIRECTORATE OF FAMILY WELFARE SERVICES
MEMORANDUM
Imphal, the 40 " January, 2024
No.2/DFWS(ISP)/2023: A State Level Review Meeting on Routine Immunization and Covid
Vaccination will be held on 15" January, 2024 at 11:00 am at the Conference Hall of Directorate
of Family Welfare Services, Imphal, Manipur.

In this regard, the following officials are hereby informed to attend the meeting on time.

1. All DFWOs/DIOs,

2. State CCO i/c.

3. All DVSMs

4. State Surveillance Officer (IDSP), Manipur

5. All Development Partners of RI Program.

Further, all the DFWOs/ DlOs are also informed to prepare the achievement and status of
Immunization Program and COVID vaccination of their respective Districts in the enclosed ppt
template.

(Dr. L. Tomeha Khuman)
Director,
Family Welfare Services, Manipur.
Copy to:

1. PS to the Hon'ble Minister (Health & FW), Manipur.

2. Commissioner (Health & FW), Govt. of Manipur.

3. Director, Health Services, Manipur.

4. Mission Director, State Health Society, NHM Manipur.

5. State Surveillance Officer, IDSP Manipur.

6. All CMOs, Manipur.

7. All DFWOs/DIOs, Manipur.

8. State Cold Chain Officer i/c., Family Welfare Services, Manipur.

9. State Program Manager, NHM Manipur.

10. Deputy Director (Fin), NHM Manipur.

11. State Finance Manager, NHM Manipur. 7

12. State Data Manager, NHM Manipur.

13. All Development Partners: WHO/UNDP/UNICEF/JSI

14. All other concerned

15. Guard file.
