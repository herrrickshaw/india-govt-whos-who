---
doc_id: "3ad6d94ecdf28eae"
source_url: "https://cohsem.nic.in/docs/Notice/routine_notification2023.pdf"
ministry: "Council of Higher Secondary Education, Manipur"
title: "Notified information to all the concerned about the Progrmmes (Time Table) for Class XI and Higher Secondary Examination, 2023. Dated 13 st  January, 2023.        Annexure I (Class XI Time Table)"
date: ""
pages: 1
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "b3f982be249aab84"
---

<!-- page 1 -->

| COUNCIL OF HIGHER SECONDARY EDUCATION,
MANIPUR
NOTIFICATION
Imphal, the 13" January, 2023.
No.2/25/96-HSC(Pt-)/¥29 In pursuance of State Government's letter No. MISC5/50/2022-EDN(S)-
EDN(S) dated the 4" November, 2022, it is hereby informed to all concerned that the Programmes of the
ensuing Class XI and Higher Secondary Examinations, 2023 are notified as given in the enclosed
Annexures -] & II respectively. সত
18৮1, টি ৰ
(Ch. Biren Sin;
Secretary, .
Council of Hr. Sec. Edn.,Manipur.
Memo No.2/25/96-HSC(Pt-I): Imphal, the 135 January, 2023.
Copy to:
1, Special Secretary to the Governor of Manipur.
2. Secretary to the Hon'ble Chief Minister, Manipur.
3. P.P.S. to the Hon’ble Minister of Education, Manipur.
4. Staff Officer to the Chief Secretary, Government of Manipur.
5. Director General of Police, Government of Manipur.
6. Chief Election Commissioner, Election Commission of India, New Delhi.
7. Chief Electoral Officer, Government of Manipur.
8. Commissioner ( Higher & Technical Education) , Government of Manipur.
9. Commissioner Education (School), Government of Manipur.
10. Director of Higher and Technical Education, Government of Manipur.
11. Director of Education (School), Government of Manipur.
12. Deputy Commissioner, all Districts.
13. Chairman, Council of Higher Secondary Education, Manipur.
14. Superintendent of Police, all Districts.
15. Director of Youth affairs and Sports, Government of Manipur.
16. Controller of Examinations, Manipur University, Canchipur.
17. Controller of Examinations, Dhanamanjuri University, Imphal. 2
18. Controller of Examinations, Manipur Technical University, Imphal.
19. Controller of Technical Education Manipur, Takyel. -
20. Controller of Examinations, Central Agricultural University, Iroishemba, Imphal.
21. Secretary, Board of Secondary Education, Manipur.
22. Director , Information and Public Relations, Government of Manipur for wide publicity of the above
programmes.
23. Director, D.D.K., Imphal for kind newscast of the above programmes.
24. All members of the Council.
25. Principals of all Colleges and Hr. Sec. Schools under the Council.
26. AllO.Cs. of Police Stations, Government of Manipur.
27. All Officers/Sections of the Council.
Vs IT Section for uploading the Programmes to the Council's website.
29. News Editor, A.ILR., Imphal for kind newscast of the above programmes in all dialects.
30. Editor, 1.S.T.V/Impact TV., Imphal for kind newscast of the above programmes.
31. Editor,
i) Poknapham For kind insertion of the above notification in the space area
ii) Sangai Express 02) of 7x20 cms in their esteemed dailies for one day only.
iii) Sanaleibsk They are requested to submit their bills in duplicate for
iv) Pandam early payment.
32. Notice Board.
33. Guard File.
7.-০০০৯
(A. Sukumar singh)
Controller of Examinations,
নিস Af Un Onn Tan Manton
