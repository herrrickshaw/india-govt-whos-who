---
doc_id: "f1157da4bcffe09d"
source_url: "https://satmanipur.nic.in/wp-content/uploads/2025/04/AC-89-Selection.pdf"
ministry: "State Academy of Training (SAT), Manipur"
title: "Download notification"
date: ""
pages: 9
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "736b57ff55932035"
---

<!-- page 1 -->

: GOVERNMENT OF MANIPUR ]
STATE ACADEMY OF TRAINING ]
রি MANIPUR
: Imphal, the 15t April, 2025
k
a No. TNG-6/1/2025-SAT-SAT: It is hereby notified for general information that the
: 195 (one hundred and ninety-five) State Government employees listed in Annexure-I
: are selected for the 89tn Batch of State Account Training, and that the classes shall
i commence on 215 April, 2025, at the State Academy of Training, Takyelpat.
ই 1, All selected trainees are informed to report to the Additional Director, State
ই Academy of Training at 10.00 am on 21% April, 2025 along with release
8 orders from competent authority and statement of Casual Leave Account.
3 2. A trainee who fails to report within 3(three) working days i.e. by 10.00 AM of
A 25t April, 2025, will forfeit their selection.
3. A trainee who fails to attend at least 80% attendance will not be permitted to
appear for the Final Examination.
4. All trainees will be under the control of the Additional Director, State
E Academy of Training during the duration of the 89' Batch State Accounts
§ Training. However, application for grant of Earned Leave shall be submitted
5 to the controlling offices through the Additional Director, State Academy of
: Training.
: 5. ‘The Pay and allowances of the trainees will continue to be borne by the
respective offices/departments.
: 6. All trainees are informed to read and understand the revised scheme of State
2 Accounts Training notified on 31st January, 2022, for full details of the State
i Accounts Training.
হু 7. There will be an online class only for selected IDP candidates. No other
candidate is allowed to attend the online class for any reason. For further
information you may contact to i/c Deputy Director at 8415907226.
z Encl: As above. ]
2 (Md. 5. Daulat Khan )
রি Additional Director,
3 State Academy of Training, Manipur |
a Copy to :-
: 1. APS to Director General/SAT for kind information.
3 2, Principal Secretary/AR, Govt. of Manipur.
: 3, All Head of Departments/Offices concerned. |
4. All Selection Committee Members of 89" batch State Accounts Training.
5. Website of State Academy of Training, Manipur (www.satmanipur.nic.in)
নর 6. Notice Board, |
° 7. Guard File,

<!-- page 2 -->

La
| List of employees Shortlisted for 891 Batch State Accounts Training ‘
wee
1, Science & Technology
| Fr remmtesanon 057 |
2. Board of Secondary Education Manipur (BOSEM)
সপ EDA
[2 Nein Sani Sigh 77৮৮
3. District & Sessions Judge, Thoubal
Fi [righ abla shoe 0৮৮7
[2৮৭৮৮০০771৮
4, Directorate of Information & Public Relations
| Pi গঞ্জ 77577
2৮৮৮০৭779৮8
2711৮৯19৮7০
5. Directorate of Prosecution
6. Manipur Judicial Academy
eg
|
Pr rey Gunso Ci
[| [imnbininin UDA
9, Directorate of Trade Commerce & Industries
|
1 (৮ 0557
| ৮৮৮৮৯ 1] 777
y Page 1

<!-- page 3 -->

/ জমা. দা চলল
[০৮9০০০77557

[| Jlsttonoowiene 57

1 ০৮৮০০০57755

|

1 [০৮৮/৮০৮৭৮০৮77

1 ৮1০৮৮০০7577

|
[| [44১০৮০৮7577

[। [০৮৮৮০০৮৮757

| [| [ঞ্পাপপ্/ংঞল। 77557

[| WiganmngGuny 77577

[1 ৬পপনেস্ত 7557

| [1 1৮৮৮৮০৪০7

Page 2 Y

<!-- page 4 -->

SO |
৫ a
| eg 057
|
| । [০৮৮০০ 555
| 6 পঞ্চ
1 Pekcton sie Singh 7 ৮০০ 1
a 755
30. Directorate of Minority Affairs
|
ee a পদ
ee
(1০০০০৮০৮০৭0
| 7৮৮৮৮৮৮70৮7
1 akinesia 7 শন (|
চপ of Reef &Rewhiiwion 7ম
1 পপ 77757
Page 3

<!-- page 5 -->

0 se ee
, 36. Directorate of Sericulture

[1 [lian Sonos 0557
[1 Jlaripan ene
|
(71০০৮৭৮৮857
|
| [1 [wn chai ac
[2 0৮৮৮০০৮০।765555
[A Dincoreottitenes 7777
ই

‘ Page 4 7

<!-- page 6 -->

a |
|
a ০০
৭ 3৮4৯৮৮৪০৮০০
৭ পাচপপণ্ণ ৮৮৭ |
[1 [pitas vomnam JOA
2০০৮1 ০০৮০৮
মা fo
| eo
1 । amnion ৮০০০১ |
2 [tannins cows EDO |
চাপল ৮৮
| চাটনি
76 [RingmingPinones 1০০
| । CT ______৮৮ ২
[287০৮০০৯৮০৯ ১৮৯৩০
049৮৮০০9৮9০ ৮০৩০
| (৮ সপ 7৮০
[5 পপ গঞ্জ ০১৮০০
7০ 1 ১৮০০
[5 [rnin sans sgs [0] শিপ
Y Page 5

<!-- page 7 -->

— ২
[2 Nein anno টি ৰ
8 সপ) আদ
Nengzalian tenographer

[3 17৮০০100800 fw
| + ৮৮৮৯০৯৬7৮৮7
[5 [Poiana ৮
eg
77৮*৮7৮৮৮7
eg
Fa Nem MineDee 7

| Teen Pima
৮০০৮০৮55755
ee
০১৮০০০০৮৮০৮
9৯৮৮৮৮৮৮৮৮০
chances Aa |

| 3১০৮৮৮৮০০৮৮
টিটি
70৮৮ 7৮7
59, Police Department
পিচ OS
a) ৮77
|

, " Page 6
৮২ |

<!-- page 8 -->

রণ. [এ ভলদ্দ77 77
nis iter টি
|
|
4 টি mens ||
|
7
7৮7৮৮575৮77
77৮৮৮৮77
7৮৯০ _৮57
7০৯৮১৯৮7577 1
জটিল রর তো
Sheet
উট না
|
Se ee
nd
ee en |
তোল jo
ee |

Y page 7 ;

<!-- page 9 -->

og

OY

J
| ও ona Nema =o i

তা Sigh ————ice ite

| টা Sigh ———SS—d i |
[1 magus চন |
[2 ৮৮০৮৮7০7
[2 লা |
[4 পাপ
[5 [siinipan PanesiorSingh ৮৯৮৯৮
[6 [Mok Molin Kin SS A |
[7 [ale KinsiDinngd Se |
[e Naginan Ran 70৮৮1
[3 [Simon oionban ৮৯৮৮৮
7767৮৮০4০৭৯ |
[ar PRskanarBimonSingh 99৮৮
[1 1৮০৮৮০০৮771] বাত 7

|
Page 8
