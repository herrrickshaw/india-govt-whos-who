---
doc_id: "e13c57f6fa1cc9ee"
source_url: "https://ssamanipur.nic.in/Downloads/corrigendum12march2015.pdf"
ministry: "Sarva Shiksha Abhiyan (SSA), Manipur"
title: "Corrigendum for Notice of engagement on contract basis under SSA"
date: ""
pages: 2
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "85e3b45056ed2790"
---

<!-- page 1 -->

a পল নী:
১111 SHIKSHA ABHIVAN STATE MISSION AUTHORITY ॥ AVIPER
President Chief Minister, Manipur Regd. No. 146/M/SR/2000
General Body Babupara, Imphal - 795 001
Chaifmen Chief Secretary, Tele Fax 0365 - 2448534, 2448535
Executive Commitee Government of Manipur mail: ssa_manipur@redifimail com

neem ati
CORRIGENDUM
Imphal, the 101 March 2015
No.1/6/2013-SSA/SMA: Column No.7 of application form should read as
(7) 49 as on 28/02/2015 : Years শদাপিপতত MONTAS cee. 0055555555
instead of
(7) Age as on 04/03/2014 : Years ....... Months ......... Days ................
a
(Ng.Bhogendra)
Additional State Project Director
SSA/SMA, Manipur

<!-- page 2 -->

“a ons পা pa (CARR EDI Ae
«<i [SARVA SHIKSHA ABHIVAN |
1 _ 7 1 "i A ন্‌
31011 SHIKSHA 1010111 STATE MISSION AUTHORITY MANIPLR
President Chief Minister, Manipur Regd. No. 146/M/SR/2000
General Body Babupara, Imphal - 795 001
Chairman Chief Secretary Tele Fax 0365 - 2448534, 2448535
Executive Committee Government of Manipur e-mail: ssa_manipur@rediffmail. com
৮০২০০০০০০০০ - orien 1
CORRIGENDUM
Imphal, the 11" March 2015
No.1/6/2013-SSA/SMA: Date of Corrigendum specifying Essential and Desirable
qualifications for the posts of System Analyst, Subject Specific Resource Person
(Language, Mathematics, Social Science, Science) & Cluster Resource Person issued vide
even no. dated 7” February 2015 should read as 7" March 2015.
(Ng.Bhogendra)
Additional State Project Director
SSA/SMA, Manipur
Copy to:
1. The Secretary to Hon'ble Chief Minister, Manipur.
2. The PPS to Hon'ble Minister, Education (S), Manipur.
3. The Staff Officer to Chief Secretary, Manipur.
4. The Secretary, Education (S), Manipur.
5, The Director of School Education (S), Manipur.
6. The Editor, - for kind publication in their esteemed
daily.
7. File.
