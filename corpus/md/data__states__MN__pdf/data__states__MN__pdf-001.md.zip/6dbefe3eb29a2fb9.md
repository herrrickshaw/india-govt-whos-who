---
doc_id: "6dbefe3eb29a2fb9"
source_url: "https://gadmanipur.nic.in/media/5dlnfsji/republic-day.pdf"
ministry: "General Administration Department, Manipur"
title: "CIRCULAR: Observance of 'Republic Day Celebration 2024' regarding."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3e55a9234e14e64e"
---

<!-- page 1 -->

Str-101/1/2021-GAD-GAD-Part(1)
I/55999/2024
No. Str-101/1/2021-GAD-GAD-Part(1)
GOVERNMENT OF MANIPUR
SECRETARIAT: GENERAL ADMINISTRATION DEPARTMENT
(WELFARE SECTION)
CIRCULAR
Imphal, the 24 th January, 2024
It is hereby informed to all that the State Government will observe “Republic Day
Celebrations, 2024 ” on 26.01.2024 at 08.30 a.m as per the following program:Date

26th January, 2024

A) Morning Programme at Kangla
0830 hrs

Arrival of the Chief Guest at Salutinq Base

0831 hrs

Inspection of Guard of Honour.

0835 hrs

Unfurling of the National Flag and playing of National
Anthem by 1st M.R. Band.

0837 hrs

Presentation of Police Medals

0845 hrs

March Past

1000 hrs

Chief Guest leaves.

B) Vote of Thanks Ceremony at 1st Bn. Manipur Rifles Parade Ground, Imphal.
1100 hrs

Vote of thanks by Hon'ble Chief Minister, Manipur to
the participants of March past.

MS. Anusuiya Uikey, Hon’ble Governor of Manipur will grace the function at
Kangla as the Chief Guest.
It is, therefore, requested to kindly make it convenient to attend the said function in time.

(Asem Rangina Chanu)
Deputy Secretary
General Administration Department
Government of Manipur
Copy to:1. Staff Officer to Chief Secretary, Government of Manipur.
2. PS to Addl. Chief Secretaries/Principal Secretary/Commissioners/ Secretaries,
Government of Manipur.
3. All Additional Secretaries/HODs/Joint Secretaries/Deputy Secretaries/Under
Secretaries, Government of Manipur.
4. Notice Board
5. Guard file.
