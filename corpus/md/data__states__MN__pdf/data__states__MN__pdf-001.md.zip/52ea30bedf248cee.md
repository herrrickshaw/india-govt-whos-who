---
doc_id: "52ea30bedf248cee"
source_url: "https://artnculturemanipur.mn.gov.in/media/filer_public/44/f5/44f5409f-7888-469b-9da1-a6f1875d1877/1-1_notification-for-cmat-for-2021-2022.pdf"
ministry: "Art and Culture Department, Manipur"
title: "1. CMAT – Scheme for Artistes’ Pension (Category A for State & National Awardees) (Category B for Non-Awadees)-(click here to download the form)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "69cb32ef739f373d"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
DIRECTORATE OF ART AND CULTURE

TICE
Imphal, the

No. 1/53/2020-AC(CMAT): Applications in the prescribed fbrmat are invired fiom the willing anci
eligible persons lbr availing assistance under Chiel'Ministergi Artistessingi Tengbang
lcMai; fur
tlre catcgories given below fbr the year 2021-2022:

Sl No.

Scheme

('N{A l'- Schentc tbr Artistcs' I)cnsictrr
((iategorl A fbr State & National Aruardees) (Ciategory B tbr Non-Awardees)
2. CMAT' Schcme lbr Assistance 1br participation in International & National Festivals
l. ('l\4Al - Scheme 1br Assistance to the Cultural Group lbr Training and Nen.production
1. CNIA i' - Support lbr Pr,rrchase of Instruments / Equipment
5. CMA I - Scheme fbr Aw,ard ro Distinguished Artistes
1.

Detail is available on the website of the Department at http://artnculturemanipur.sov.irr. Duly filled
in application lbrm u'ith necessary documents may be submitted to the ofllce of the Directorate of
Art & Cr-riture. (iovernment of Manipr.rr at Palace C'ompound. Imphal East - 795001 latest br
3l'1 August 2021. One person can appiv tor one schemc on11 at a time. Application received after
c'lue date w'ill not be entertair-ied.

In,r'iew of the ongoing Clovid Pandemic, the applications will be accepted through Drop Box on the
r'"1 [:lourol-the Directorate Of1ice. Iroranl,qLler\,. pleasc
contact Shri C]. Dharmadas Sharma. Deputy
I)ircctor (Prourantt.t.te) throuuh n.robile no.97712961:lrl during olfice hours. It is lirrther requestecl
ilot t() rlait lbr last clate o1'firrttt sltbntission to aroicl croncling ancJ other inc6rtrepiclecs.

1

rh.

\Pi'ii

''?,

(\g. Utt'm€;i-ngh)

Director (Art & Clulture)
Government of Manipur
Ciopl'to:
I' Thc SecretarY to thc Hon'ble ('hief N{inister. Manipur (i/c) Minister (Art & Culture) 1br kind
inlormation
I'he Stafl' of-ficer ro the chiet' sccrerarl'. (iol'ern ment of' ManipLrr
2.
J. The Commissioner (Art & Culture). Government of Manipur
4.

The Dcputl' Commissioners (alt districls of Manipur fbr kind circulation and
rccornmendation )

5.
(r.

lhe Director (lPR). 1\4anipr-rr fbr niclc publicitv in thc print and electronic rr-redia

(rLrard lrlc
