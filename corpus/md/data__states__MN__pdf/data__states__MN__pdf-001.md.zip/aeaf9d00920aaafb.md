---
doc_id: "aeaf9d00920aaafb"
source_url: "https://gadmanipur.nic.in/media/4mdhff4l/stenonotificationextension.pdf"
ministry: "General Administration Department, Manipur"
title: "Extension of Online application for Steno Gr-III of GAD."
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ffd988babd566023"
---

<!-- page 1 -->

ESTT-1010/1/2024-GAD-GAD-Part(4)

I/70353/2024

GOVERNMENT OF MANIPUR
SECRETARIAT:GENERAL ADMINISTRATION DEPARTMENT
NOTIFICATION
Imphal, the 31st October, 2024.
ESTT-1010/1/2024-GAD-GAD-Part(4):
In continuation to GAD’s earlier Notiﬁcation
ESTT-1010/1/2024-GAD-GAD –Part(3) dated 15 th March, 2024 regarding recruitment of
8(eight) posts of Stenographer Grade-III on contractual basis
in the General
Administration Department, Government of Manipur, it is hereby notiﬁed that the last date of
online submission of application for the post of Stenographer Grade-III, is further extended
till 10th November, 2024 to provide opportunity to the intending candidates in the revised
Scheme of examination.
ii.
The willing and eligible candidates for the post of Stenographer Grade-III shall get
names sponsored by the concerned Employment Exchange Oﬃce on or before 8th
November, 2024. Thereafter, the intending and eligible candidate shall ﬁll up the application
online at https://gadmanipur.nic.in/.
iii.
The Scheme of examination is uploaded in the website
https://manipurgovtpress.nic.in/en/gazette and https://gadmanipur.nic.in/.
Sd/Deputy Secretary ,
General Administration Department,
Government of Manipur.

at

Copy to:-

1. Secretary to Chief Minister(i/c GAD), Manipur.
2. Staff Officer to Chief Secretary, Government of Manipur.
3. P.S. to Secretary (GAD), Government of Manipur.
4. Deputy Secretary ( Labour), Government of Manipur.
5. The Director of Employment Exchange, Manipur.
6. The Web Manager, Department of IT, Manipur for favour of uploading the
Notification of the Department on the Department’s Website.

7. Managing Director, M/s Cubetan Technologies, Imphal for favour of opening up of
window for online form submission till 10.11.2024.

8. The Editor,[Sangai Express (English)/Poknapham (Manipur edition). He is
requested to publish the Notification for 3(three) consecutive days and to send the Bill
in duplicate to the GAD, Governmnet of Manipur, for necessary action.

9. Notice Board
10. Guard file.
( Asem Rangina Chanu )
Deputy Secretary ,
General Administration Department,
Government of Manipur.

<!-- page 2 -->

ESTT-1010/1/2024-GAD-GAD-Part(4)

I/70353/2024
