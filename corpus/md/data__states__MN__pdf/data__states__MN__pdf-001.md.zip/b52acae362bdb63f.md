---
doc_id: "b52acae362bdb63f"
source_url: "https://dict.mizoram.gov.in/uploads/attachments/19894f83b2a63bbff42f374cc3d53c77/goi-web-guidelines.pdf"
ministry: "Department of Information & Communication Technology, Manipur"
title: "Government of India Website Guidelines"
date: ""
pages: 138
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "047658d7c65ab777"
---

<!-- page 1 -->

GUIDELINES
FOR
INDIAN GOVERNMENT WEBSITES
An Integral Part of
Central Secretariat Manual of Office Procedure

Prepared By :

Adopted By :

National Informatics Centre (NIC),
Department of InformationTechnology,
Ministry of Communications and Information Technology,
Government of India.

Department of Administrative Reforms and Public
Grievances (DARPG),
Ministry of Personnel, Public Grievances & Pension,
Government of India.

<!-- page 2 -->

<!-- page 3 -->

GUIDELINES
FOR
INDIAN GOVERNMENT WEBSITES
An Integral Part of
Central Secretariat Manual of Office Procedure

January 2009
Prepared By :
National Informatics Centre (NIC),
Department of InformationTechnology,
Ministry of Communications and
Information Technology,
Government of India.

Adopted By :
Department of Administrative Reforms
and Public Grievances (DARPG),
Ministry of Personnel, Public Grievances
& Pension,
Government of India.

ISBN - 978 - 81 - 909457-0 -7

<!-- page 4 -->

<!-- page 5 -->

jkT; ea=h
iz/kku ea=h dk;kZy; rFkk
dkfeZd] yksd f'kdk;r ,oa isa'ku ea=ky;
Hkkjr ljdkj
MINISTER OF STATE
PRIME MINISTER’S OFFICE AND
MINISTRY OF PERSONNEL,
PUBLIC GRIEVANCES AND PENSIONS
GOVERNMENT OF INDIA

i`Fohjkt pOgk.k
PRITHVIRAJ CHAVAN

MESSAGE
It is indeed a pleasure to learn that the Department of Administrative
Reforms and Public Grievances, in association with the National Informatics
Centre (NIC), has formulated Guidelines for Indian Government Websites.
With the advent of e-Governance and focus on web enablement
of citizen services, there has been an urgent need for such guidelines. I am
confident that these guidelines will bring uniformity in the quality of content
as well as enhance the overall usability and functionality of Indian Government
Websites. These guidelines would also assist the Government of India to improve
the standard of information and service delivery through the electronic media
and demonstrate its commitment to enhance government citizen interaction
through application of internet technologies.
The inclusion of these “Guidelines for Indian Government Websites”
in the Central Secretariat Manual of Office Procedure (CSMOP) would
augment the Manual and enable it to prescribe procedures for the management
of government presence in the web space.

(Prithviraj Chavan)

<!-- page 6 -->

<!-- page 7 -->

MESSAGE

The World Wide Web is poised to be the most widely used medium
for implementation of e governance initiatives. Realising the importance of this
medium a large number of websites belonging to different government entities
have been published on the web to ensure maximum reach of government
information and services to the citizens of India. However, to make this delivery
channel more effective a need for coherence in technical, design and navigation
standards across all government websites was felt.
National Informatics Centre (NIC) for long has been anchoring
e-governance initiatives in the country. NIC has also developed and launched
the National Portal of India, under the aegis of National e-governance Plan
(NeGP). To further strengthen the National Portal, NIC has formulated
‘Guidelines for Indian Government Websites’ in accordance to be internationally
accepted standards to ensure that the websites belonging to any constituent of
the government at any level are user friendly, secure and easy to maintain.
With the efforts of Department of Administrative Reforms and Public
Grievances these guidelines have now been included in the Central Secretariat
Manual of Office Procedures (CSMOP) which will further enhance their
status.
Compliance to these will enable the departments to enhance the
quality of online delivery of information and services and also ensure high
degree of consistency and uniformity in the Indian Government Web Space.

Jainder Singh
Secretary
Department of Information Technology
Ministry of Communications and Information Technology

<!-- page 8 -->

<!-- page 9 -->

MESSAGE

It is an accepted premise both in theory and practice that information
and communication technologies can make a significant contribution to
the achievement of national development goals. Government Departments
especially those with extensive public interface are increasingly using websites
as a tool to reach out to the citizens. With digital penetration increasing in
India, in times to come websites would be the preferred mode of contact for
a majority of the citizens with the government departments. The “Right to
Information Act” has further given an impetus to the government departments
to develop their websites to conform with the proactive disclosure requirements
under the Act.
While we are witness to an increasing number of government
websites, the user experience with the various government sites is not uniform.
This emanates from different technology standards, design layouts, navigation
architecture, functionality etc. This is one major impediment in making
government website usage by citizens pervasive.
It is in this context that the Department of Administrative Reforms
and Public Grievances in association with Department of Information
Technology and National Informatics Centre took up the initiative to bring out
the “Guidelines for Indian Government Websites”. These Guidelines have been
finalised through extensive consultation with Content Advisory Committee
(CAC) having representatives from various government departments and the
subgroup constituted for this purpose. It is hoped that the guidelines would
assist individual departments to design their websites conforming to a minimum
national standard, thereby assuring quality of government information and
services. The inclusion of the guidelines in the Central Secretariat Manual for
Office Procedures will further aid this effort and realise the objective of making
the government websites citizen centric and user friendly.

Rajni Razdan
Secretary
Department of Administrative Reforms & Public Grievances
Ministry of Personnel, PG & Pensions

<!-- page 10 -->

<!-- page 11 -->

FOREWORD

There has been a long felt need for comprehensive guidelines for
development and management of Government Websites given that the
government departments are increasingly using websites as a tool for interface
with the citizens. The guidelines presented in this document are an effort
towards this direction.
These guidelines are an outcome of extensive deliberation by the
Content Advisory Committee, feedback from government departments and
advice of experts in Information Technology and Government processes.
Guidelines of other countries as well as International bodies like ISO and W3C
were also consulted.
Special attention has been paid to ensure that the content of
the guidelines conform to the overarching philosophy of ensuring that the
government websites are citizen centric and user friendly. Inclusion of the
chapter on Compliance Matrix which provides a checklist of the essential
elements which a government website should have would ease compliance. The
write-up has been kept simple with minimal use of technical jargon, examples
have also been provided to ease comprehension and provide clarity of the
concept under discussion.
This manual has benefited from suggestions of a number of individuals
and organisations, the contribution is gratefully acknowledged. Readers of this
manual are encouraged to provide comments/suggestions for making these
guidelines more effective and keep the contents topical.

D.V. Singh
Additional Secretary
Department of Administrative Reforms and Public Grievances
Ministry of Personnel, PG & Pensions

(I)

<!-- page 12 -->

<!-- page 13 -->

PREFACE
Over the years a large number of websites belonging to different
Government bodies have been published on the internet to facilitate access to
government information and service to the citizens of India. However varied
nomenclatures, different layout standards, navigation strategies as well as of
different technology have defeated the very purpose of these websites.
National Portal of India was set up as a single point access to government
information and services. In this process of unification it aggregates content
from over 5000 website of Indian Government. National Portal of India can not
serve its users primarily; citizens of India beyond a certain level of quality, unless
the inherent quality of government websites increases. With this objective a
Content Advisory Committee with the senior officers from different Ministries
and State Governments as its members, was constituted to look into the means
to enhance the intrinsic quality of the Government websites.
At the advice of the Content Advisory Committee, NIC has
developed ‘Guidelines for Indian Government Website’ in accordance to the
international standards to ensure that the website belonging to any constituent
of the Government at any level are user friendly, secure and easy to maintain.
A subgroup from amongst the members of Content Advisory Committee was
specifically constituted to advice NIC during various stages of development of
the guidelines. After extensive deliberations and reviews by the subgroup and
subsequent refinements, these guidelines have been approved by the Content
Advisory Committee.
I would like to thank Special Secretary, DIT, Sh. R. Chandrasekhar for
his valuable advice and support in formulation of these guidelines. I appreciate
& acknowledge the efforts put in by all the members of the Content Advisory
Committee for reviewing these guidelines. I would also like to thank Additional
Secretary, DARPG, Sh. D.V. Singh for adopting these guidelines as an integral
part of CSMOP. Members of the subgroup have spared their valuable time
going through the draft in detail and providing valuable input. I acknowledge
& commend the efforts of Mrs. Lekha Kumar, Director DARPG and Mrs.
Neeta Verma, Senior Technical Director, NIC for putting their best efforts in
producing this high quality and extremely useful document.
I hope, with the support and cooperation of all of you these guidelines
will go a long way in improving the quality of Indian government web space.

Dr. B.K. Gairola
Director General
National Informatics Centre
Department of Information Technology
Ministry of Communications and Information Technology

(III)

<!-- page 14 -->

III

<!-- page 15 -->

ABOUT THE DOCUMENT
This document contains recommended guidelines for development and
management of Government websites and Portals in India. The primary
objective of these guidelines is to ensure that Indian Government websites,
belonging to any constituent of the Government, at any level, are citizen
centric and visitor friendly. It is advised that these guidelines be followed
while developing or managing any Government website, portal or web based
application.

Authorship
This document has been developed by a team at Data Centre and Web
Services Division of National Informatics Centre (NIC), Department of
Information Technology, Government of India, under the National Portal
Project. Though each member of the division has contributed to the
document in one way or the other, the primary authors are:

Neeta Verma, Senior Technical Director
Lokesh Joshi, Senior Systems Analyst

Copyright
© 2009; NIC, DIT
This document may not be reproduced partially or fully, without
due permission from NIC. If referred to as a part of another
publication, the source must be appropriately acknowledged.
The content of this document can not be used in any misleading
or objectionable context.

Address for
Correspondence

Data Centre and Web Services Division
National Informatics Centre
A- Block, CGO Complex,
Lodhi Road, New Delhi – 110003
Email : webguidelines@nic.in
Phone : 011-24363692
Fax : 011-24368854

(V)

<!-- page 16 -->

ABOUT THE DOCUMENT

Guidelines Development Process
National Informatics Centre has developed these Guidelines as an initiative
under the National Portal of India Project. Development of these guidelines
involved an extensive consultation process involving representatives from
National Informatics Centre and various other Indian Government
Departments, at the Centre and State levels. Established and recognised
Guidelines of other countries as well as International bodies like ISO and
W3C have also been referred to, while drafting these guidelines.
The draft guidelines underwent an elaborate process of review and
consultation by the concerned committees (as indicated below) and were
also circulated to several Departments for their feedback, which have been
duly incorporated.

Reviewed By
These Guidelines have been reviewed and enhanced by a Sub Group
constituted by the Content Advisory Committee of National Portal of India
(india.gov.in). The Sub Group comprises of the following members :

A.K. Srivastava

Principal Secretary (IT), Meghalaya

Dr G.D. Badgaiyan

Secretary, Rajiv Gandhi Foundation ,New Delhi

Neeta Verma

Senior Technical Director, National Informatics
Centre
Director, Dept. of Admin. Reforms & Public
Grievances
Director, Department of Information
Technology
Technical Director, National Informatics Centre

Lekha Kumar
Renu Budhiraja
Alka Mishra

(VI)

<!-- page 17 -->

Guidelines
for Indian Government Websites

Approved By
The draft of this document, as finalised after incorporating the suggestions
of the Sub- Group, has been approved by the Content Advisory Committee,
an Inter-Departmental Committee at the National level looking after the
policy making and management of content for the National Portal of India.
The composition of the Content Advisory Committee as on 20th August
2007 is as follows: D.V. Singh
R. Chandershekhar
Dr. B.K. Gairola
R. Sridharan
N.K. Sinha
V. N. Gaur
B. B. Tyagi
P. D. Sudhakar
A.K. Saxena
Ajay Kumar Sawhney
C.K. Mathew
Leena Nandan
D.N. Narsimha Raju
Rinka Dugga
Rajendra Kumar
Ajay Seth
Neeta Verma
Lekha Kumar
Rakesh Verma

Additional Secretary, Dept. of Admin.
Reforms & Public Grievances
Additional Secretary, Department of
Information Technology
Director General, National Informatics
Centre
Joint Secretary, Planning Commission
Joint Secretary, Ministry of Human
Resource Development
Joint Secretary, Ministry of Home Affairs
Joint Secretary, Ministry of External
Affairs
Joint Secretary, Department of Corporate
Affairs
Joint Secretary, Ministry of Statistics &
Programme Implementation
Joint Secretary, Department of Personnel
& Training
Principal Secretary, IT, Government of
Rajasthan
Joint Secretary, Ministry of Tourism
Joint Secretary, Ministry of Petroleum &
Natural Gas
IT Secretary, Andaman & Nicobar Islands
Secretary, IT, Government of Delhi
Secretary, IT, Government of Karnataka
Senior Technical Director, National
Informatics Centre
Director, Dept. of Admin. Reforms &
Public Grievances
Director, IT, Government of Punjab

(VII)

<!-- page 18 -->

<!-- page 19 -->

Guidelines for Indian Government Websites

Contents
Foreword

I

Preface

III

About The Document

V

01 Introduction

01

1.1
1.2
1.3
1.4
1.5
1.6
1.7
1.8

Background
Scope & Objective
Universal Accesibility
Definitions & Conventions
Compliance to Guidelines
How to use these Guidelines
Mandatory, Advisory and Voluntary
Feedback & Suggestions

02 Government of India Identifiers
2.1
2.2
2.3

Indian Government Identity
Government Domains
Link with The National Portal

03 Building Confidence
3.1
3.2
3.3
3.4

19

Content Copyright
Content Hyperlinking
Terms & Conditions
Privacy Policy

04 Scope of Content
4.1
4.2
4.3
4.4
4.5
4.6
4.7

09

Information in Public Domain
Primary Content
Secondary Content
Tertiary Content
Minimum Content
Information meant for Internal use
Information to Avoid

31

<!-- page 20 -->

Guidelines for Indian Government Websites

Contents
05

Quality of Content
5.1
5.2
5.3
5.4
5.5
5.6
5.7

06

07

IX

73

Mark-up Languages
Cascading Style Sheets (CSS)
Scripting Languages
File Formats
Ready Reference for Developers
Validation & Testing
Web Application Security

Website Hosting
8.1
8.2
8.3

61

Visual Identity
Page Layout
Graphic Buttons & Icons
Typography
Colour
Images
Audio/ Video/ Animation
Navigation
Site Search
Sitemap
Frames

Development
7.1
7.2
7.3
7.4
7.5
7.6
7.7

08

Citizen Orientation
Content Authenticity, Accuracy and Currency
Language
Consistent Terminology
International Conventions
Information Architecture & Relationship
Multilingual Versions

Design
6.1
6.2
6.3
6.4
6.5
6.6
6.7
6.8
6.9
6.10
6.11

51

Website Hosting
Hosting Service Provider
Contingency Management

83

<!-- page 21 -->

Guidelines for Indian Government Websites

Contents
09

Website Promotion
9.1
9.2

Search Engine Optimisation
Website Promotion Techniques

10 Website Management
10.1
10.2
10.3
10.4
10.5
10.6
10.7

95

Website Management Team
Website Maintenance Tools
Website Monitoring
Archiving of Documents
Compliance with Guidelines and Standards
Website Review and Enhancement
Website Policies

Compliance Matrix
1.
2.
3.
4.
5.
6.
7.
8.
9.

89

Government of India Identifiers
Building Confidence
Scope of Content
Quality of Content
Design
Development
Website Hosting
Website Promotion
Website Management

105

<!-- page 22 -->

<!-- page 23 -->

Guidelines for Indian Government Websites

CH 01

Introduction

1.1

BACKGROUND

1.2

SCOPE & OBJECTIVE

1.3

UNIVERSAL ACCESSIBILITY

1.4

DEFINITIONS & CONVENTIONS

1.5

COMPLIANCE TO GUIDELINES

1.6

HOW TO USE THESE GUIDELINES

1.7

MANDATORY, ADVISORY AND VOLUNTARY

1.8

FEEDBACK & SUGGESTIONS

<!-- page 24 -->

<!-- page 25 -->

Guidelines
for Indian Government Websites

Introduction
1.1
Background
India, the largest democracy in the world, is set to emerge as an ICT Superpower in
this millennium. Realising the recognition of ‘electronic governance’ as an important
goal by Governments world over, Indian Government has also laid a lot of emphasis
on anytime, anywhere delivery of Government services. As of today, there are over five
thousand Government websites in India. A close look at these websites, belonging to
both Central and State Government reveals that most of the important Government
entities have already made headway in establishing their presence on the Net and others
are in the process of doing so. Every other day, there is a new Government website, be
it of a Department of a Ministry, Taskforces set-up by the Government, new project,
citizen service initiative, State Government Department or even a remote district of
India. Awareness about the fast changing ICT world and keenness to keep pace with
the latest has ensured that almost all the State Governments in India already have their
websites up and running. In fact each state has multiple websites belonging to different
Departments.
However, these websites follow different Technology Standards, Design Layouts,
Navigation Architecture, or, in simple terms, different look and feel as well as
functionality. This invariably requires a common citizen to familiarise himself/herself
with the functionality of each individual website which results in a lot of inconvenience,
thus defeating the very purpose of these initiatives.
The need for standardisation and uniformity in websites belonging to the Government
cannot be stressed enough, in today scenario. Ideally, properly audited technical ‘Standards’
should form the foundation of the web efforts of any Country’s Government but it shall
take some time for any Country, no matter how developed and advanced it is in terms
of ICT levels to reach that stage of maturity. It is therefore imperative that a ‘phased
approach’ adopted to bring out a set of recommended guidelines and policies based on
common knowledge and accepted National and International norms. As a first step, it
is suggested that the Indian Government websites adhere to certain common minimum
standards which have been derived, in the form of guidelines discussed in this document,
as prerequisites for a Government website to fulfill its primary objective of being a citizen
centric source of information & service delivery. These guidelines could eventually form
the basis for establishment of the desired standards.

©2009,NIC

3

<!-- page 26 -->

CH 01

INTRODUCTION

1.2
Scope & Objective
This document recommends policies and guidelines for Indian Government websites and
Portals, at any organisational level and belonging to both Central Government as well as
State/UT Governments (including District Administrations to Village Panchayats) for
making Indian Government websites citizen centric and visitor friendly. Compliance to
these guidelines will ensure a high degree of consistency and uniformity in the content
coverage and presentation and further promote excellence in Indian Government Web
space.
These guidelines address common policy issues and practical challenges that Government
Departments face during development and management of their websites. The guidelines
aim to assist the Departments in ensuring that their website conform to a consistently
high standard. This is expected to enhance the trust level of the citizens while accessing
Government information and availing services online.

1.3
Universal Accessibility
The term ‘Universal Accessibility’ refers to making a website accessible to ALL
irrespective of technology, platforms, devices or disabilities of any kind. In other words,
Departments should consider the needs of a broad spectrum of visitors, including general
public, specialised audiences, people with disabilities, those without access to advanced
technologies, and those with limited English proficiency. Guidelines to address the above
needs have been given in various sections of this document.
Most pertinent guidelines have been placed in the mandatory category while others
have been made advisory or voluntary. Following the mandatory guidelines shall insure
compliance to W3C Web Content Accessibility Guidelines (Level A)

1.4
Definitions & Conventions
Visitors:

Throughout this document, the broad term ‘visitors’ encompasses all those who visit
and use the Indian Government websites for their needs with regards to government
information and services.
Departments:
All Government entities owning

4

a website, including Ministries, Departments,

<!-- page 27 -->

Guidelines
for Indian Government Websites

Administrations, Organisations, Corporations et.al. shall be commonly addressed as
‘Departments’ or ‘Entities’ in this document for the purpose of simplicity.

1.5
Compliance to Guidelines
These Guidelines have been framed with an objective to make the Indian Government
Websites conform to the essential pre-requisites of UUU trilogy i.e. Usable, User-Centric
and Universally Accessible. They also form the basis for obtaining Website Quality
Certification from STQC (Standardisation Testing Quality Certification) an organisation
of Department of Information Technology, Government of India.
These Guidelines are based on International Standards including ISO 23026, W3C’s
Web Content Accessibility Guidelines, Disability Act of India as well as Information
Technology Act of India. Further, the longstanding experience of the authors in design,
development and management of Government Websites as well as their knowledge of the
ground realities and challenges faced by the Government Departments in developing and
managing their websites have helped significantly in drafting these Guidelines.
These guidelines are being circulated amongst all Indian Government Departments at all
levels (Central, State, District). These should be followed and implemented on priority
basis so that the overall aim of making all Indian Government websites citizen focused
and visitor friendly may be realised.

1.6
How to use these Guidelines
Departments are expected to read, understand and implement these guidelines on all
of their web-based initiatives. In other words, all the websites set up and owned by the
Departments must comply with these guidelines. Though not mandated, it is advised
that even Intranet applications of the Departments, which are mostly browser based,
may follow these guidelines. The Departments may draw their short term and long
term timelines, depending upon their specific requirements, for compliance with these
guidelines.

1.7
Mandatory, Advisory and Voluntary
Guidelines are divided into three categories viz. mandatory, advisory and voluntary.
Explanation and requirement of each of these categories is given as follows .

©2009,NIC

5

<!-- page 28 -->

CH 01

INTRODUCTION

 Mandatory: The usage of term ‘MUST’ signifies requirements
which can be objectively assessed and which the Departments are
supposed to mandatorily comply with. It is anticipated that there
will be no exceptions for a Department not complying with these.
In the case of any Department, these guidelines shall apply to all the
WebPages/websites under the ownership of that Department. The
websites will be checked against these guidelines when audits for
compliance are undertaken or for the purpose of quality certification.
It is the responsibility of each Department to address and bring into
compliance, any non-compliant issues found in any website under
their ownership.
 Advisory: The usage of term ‘should’ refers to recommended practices
or advisories that are considered highly important and desirable but
for their wide scope and a degree of subjectivity these guidelines
would have otherwise qualified to be mandatory. Departments are,
however, expected to comply with these advisories.
 Voluntary: The usage of the term ‘may’ refers to voluntary practice,
which can be adopted by a Department if deemed suitable. These
have been drawn from good practices and conventions that have
proved successful and can help a Department achieve high quality
benchmarks for their web endeavours.

6

<!-- page 29 -->

Guidelines
for Indian Government Websites

1.8
Feedback & Suggestions
Feedback & Suggestions on the guidelines are welcome. We will try to include as many
suggestions/feedbacks as possible in the future versions. It will help in enhancing/
refining the guidelines further thus making them more comprehensive and relevant.
Feedback, Suggestions, Clarifications and Queries on this document may be sent at :

Address for
Correspondence

Data Centre and Web Services Division,
National Informatics Centre,
A- Block, CGO Complex,
Lodhi Road, New Delhi – 110003
Phone : 011-24363692
Email : webguidelines@nic.in
Website : http://web.guidelines.gov.in
Fax: 011-24368854

©2009,NIC

7

<!-- page 30 -->

<!-- page 31 -->

Guidelines for Indian Government Websites

CH 02

Government of India Identifiers

2.1

INDIAN GOVERNMENT IDENTITY

2.2

GOVERNMENT DOMAINS

2.3

LINK WITH THE NATIONAL PORTAL

<!-- page 32 -->

<!-- page 33 -->

Guidelines
for Indian Government Websites

Government of India Identifiers
2.1
Indian Government Identity
Visitors to a Government website are very particular about ensuring the veracity and
authenticity of the official status of the website before trusting its contents. Hence, it
is important to convey in some way to the visitors that Indian Government officially
sponsors and owns the information and services being provided in the concerned website.
All websites and Portals belonging to the Indian Government Domain at any hierarchical
level (Apex Offices, Constitutional Bodies, Ministries, Departments, Organisations,
States/UTs, District Administrations, and Village Panchayats et al) must prominently
display a strong Indian Identity and ownership of Indian Government. The above
objective can be achieved through the following :
2.1.1

The National Emblem of India MUST be displayed on the Homepage of the
websites of Central Government Ministries/Departments. The usage of National
Emblem on an Indian Government website must comply with the directives
as per the ‘State Emblem of India (Prohibition of improper use) Act, 2005’.
Further, the State Governments should also display the State Emblem (or the
National Emblem in case the State has adopted the National Emblem as its
official State Emblem) as per the Code provided in the above Act. The Public
Sector organisations and autonomous bodies should display their official logo on
the Homepage of the website to re-enforce their identity.

2.1.2

The Homepage and all important entry pages of the website MUST display the
ownership information, either in the header or footer.

2.1.3

The lineage of the Department should also be indicated at the bottom of the
Homepage and all important entry pages of the website. For instance, at the
bottom of the Homepage, the footer may state the lineage information, in the
following manner:
a.

‘This Website belongs to Department of Heavy Industries, Ministry of

Heavy Industries and Public Enterprises, Government of India’
(for a Central Government Department).
b.

‘This Website belongs to Department of Industries, State Government of
Himachal Pradesh, India’ (for a State Government Department).

©2009,NIC

11

<!-- page 34 -->

CH 02

Government of India Identifiers

c.

‘This is the official Website of Gas Authority of India Limited
(GAIL), a Public Sector Undertaking of the Government of India
under the Ministry of Petroleum and Natural Gas’
(for a Public Sector Undertaking).

d.

‘This is the official Website of the District Administration of Thanjavur,
State Government of Tamil Nadu (India)’
(for a District of India).

2.1.4

All subsequent pages of the website should also display the ownership information
in a summarised form. Further, the search engines often index individual pages
of a website and therefore, it is important that each webpage belonging to a site
displays the relevant ownership information.

2.1.5

In case of those websites which belong to Inter-Departmental initiatives involving
multiple Government Departments which are difficult to list on the Homepage,
the Government ownership should still be reflected clearly at the bottom of
the page with detailed information provided in the ‘About the Portal/Website’
section.

2.1.6

The page title of the Homepage (the title which appears on the top bar of the
browser) MUST be complete with the name of the country included, for instance,
instead of the title being just Ministry of Health and Family Welfare, it should
state, Government of India, Ministry of Health & Family Welfare. Alternatively,
in case of a State Government Department, it should state ‘Department of
Health, Government of Karnataka, India ‘. This will not only facilitate an easy
and unambiguous identification of the website but would also help in a more
relevant and visible presence in the search engine results. Further, it is important
since the screen readers used by the visually impaired users first read the title
of the page and in case the title is not explanatory enough, it may confuse or
mislead them.

2.2
Government Domains
The URL or the Web Address of any Government website is also a strong indicator of
its authenticity and status as being official. In today’s era with a large proliferation of
websites, which resemble Government websites and fraudulently claim to provide reliable
Government information and services, the role of a designated Government domain
name assumes a lot of significance.

12

<!-- page 35 -->

Guidelines
for Indian Government Websites

2.2.1

Hence, in compliance to the Government’s Domain Name Policy, all Indian
Government websites MUST use ‘gov.in’ or ‘nic.in’ domain exclusively allotted
and restricted to Government websites. The military institutions and organisations
in India may also use ‘mil.in’ domain in place of or in addition to the gov.in/.
nic.in domain. The above naming policy applies to all Government websites
irrespective of where they are hosted.

2.2.2

Those Departments and Government entities that are using and have been
publicising a domain name other than the above should take appropriate
early action to register official government domain names and use the existing
ones as ‘alias’ for a period of six months. An intermediary page with a clear
message notifying the visitors about the change in the URL and then auto redirecting them to the new URL after a time gap of 10 seconds should be used.

2.2.3

The Domain Name Conventions, as specified in the ‘.IN Registration’ policy
should be followed while registering a ‘gov.in’ Domain Name. A summary of the
domain name conventions is given below:

Domain Naming Conventions:
• Domains can contain the English-language letters ‘a’ through ‘z’, and
the digits 0 through 9.
• Departments can also use hyphens, but hyphens cannot begin or end a
domain name. Also, two hyphens together is usually not permitted, and
hyphens cannot appear in both the third and fourth positions.
• Spaces and special characters (such as !, $, &, _ and so on) are not
permitted.
• The minimum length is 3, and the maximum length is 63 characters
(excluding extension “. gov.in”).
•

Domain names are not case-sensitive. (i.e. you may use a mix of upper
or lower case letters).

Restrictions on the composition of domain names under .IN:
•

Generic names are not allowed (e.g. shipping.gov.in is not allowed).

•

For domains under gov.in, the domain MUST be derived from the name of
the organisation name/entity. (e.g. Central Vigilance Commission can opt
for a domain cvc.gov.in but NOT xyz.gov.in or vigilance.gov.in).

•

One and Two letter domain names are not allowed for registration (e.g.
ab.gov.in).

©2009,NIC

13

<!-- page 36 -->

CH 02

Government of India Identifiers

•

The generic second level names (SLDs) of .in should not be used as third level
names. (e.g. mil.gov.in and org.gov.in are not allowed as mil and org are generic
second level names under .in).
Source : http://registry.gov.in

Obtaining a GOV.IN Domain for your website
National Informatics Centre (NIC) is the exclusive Registrar for GOV.IN domain names.
The use of GOV.IN Domain is restricted to the constituents of Indian Government at
various levels right from Central, State/UT, District & Sub-District, block, village etc.
For detailed information and step-by-step procedure on how to register a .GOV IN
Domain, one may visit http://registry.gov.in

14

<!-- page 37 -->

Guidelines
for Indian Government Websites

2.3
Link with the National Portal
india.gov.in; The National Portal of India is a single window source for access to all
information and services being provided by the various constituents of the Indian
Government to its citizens and other stakeholders. The Portal is an aggregator of all Indian
Government websites belonging to different entities of the Government. National Portal
is a Mission Mode Project under the National E-Governance Plan of the Department
of IT, Ministry of Communications & IT. The Portal has been designed, developed and
hosted by National Informatics Centre (NIC), the premier ICT organisation of the
Government with a nationwide presence.
india.gov.in has a unified interface and seamless access to a wide variety of services for
citizens from all walks of life and from varied demography. This official Portal for the
Government of India acts as a gateway to a plethora of information and services provided
electronically by the different departments of Indian Government. It acts as an escort to
the visitors and guides them through varied web sites of Indian Government constituents
and also presents a lot of value added information like their association/status in terms of
sectors, ministries, departments etc. in a unique and unified manner.
There are exclusive sections on Citizens, Business, Overseas, Government, Know India,
Sectors etc. catering to the information needs. Sections targeting special interest groups
such as Government Employees, Students, Senior Citizens, Kids etc. are also present. A
variety of citizen services being provided by the government across sectors and States/UTs
can also be accessed from the Portal. The Portal also provides comprehensive information
& access to Government News, Press Releases, Documents, Policies, Forms and Tender
Notifications etc. The Portal combines the best of technology with the best of content. The
content of the Portal is also available in Hindi. Further, the content can be personalised
for each viewer based on his/her demographic profile and area of interest.
2.3.1

Since the National Portal is the official single entry Portal of the Indian
Government, all Indian Government websites MUST provide a prominent link
to the National Portal from the Homepage and other important pages of citizens’
interest.

2.3.2

The pages belonging to the National Portal MUST load into a newly opened
browser window of the user. This will also help visitors find information or service
they could not get on that particular website. It is quite common that citizens are
not aware which information or service is provided by which Department.

©2009,NIC

15

<!-- page 38 -->

CH 02

16

Government of India Identifiers

<!-- page 39 -->

Guidelines
for Indian Government Websites

How to link to the National Portal
As per linking Policy of the National Portal, no prior permission is required to link
‘india.gov.in’ from any Indian Government website. However, the Department
providing a link to The National Portal is required to inform the National Portal
Secretariat about the various sections of the National Portal that they have linked to,
so that they can be informed of any changes, updations/ additions therein. Also, it is
not permitted that the National Portal Pages be loaded into frames on any site. These
must be loaded into a new browser window.
Special Banners in different sizes and colour schemes for providing a link to the
National Portal have been given at
http://india.gov.in/linktous.php.
Instructions on how to provide a link have also been given. The Government websites/
Portals may choose any banner from the ones provided, depending upon their site
design and place the same on their Homepage.

©2009,NIC

17

<!-- page 40 -->

<!-- page 41 -->

Guidelines for Indian Government Websites

CH 03

Building Confidence

3.1

CONTENT COPYRIGHT

3.2

CONTENT HYPERLINKING

3.3

TERMS & CONDITIONS

3.4

PRIVACY POLICY

<!-- page 42 -->

<!-- page 43 -->

Guidelines
for Indian Government Websites

Building Confidence
3.1
Content Copyright
Copyright is a form of protection provided under law to the owners of “original works
of authorship” in any form or media. It is implied that the original information put
up on the website by a Government Department is by default a copyright of the owner
Department and may be copied, reproduced, republished, uploaded, posted, transmitted,
or distributed only if the copyright policy of the concerned Department allows so.
3.1.1

Hence, the information, material and documents made available on an Indian
Government website MUST be backed up with proper copyright policy
explaining the terms and conditions of their usage and reference by others. The
copyright policy of a Department could be liberal, moderate or conservative
depending upon their preferences based on the kind of information available on
their website. However, since it is a duty of a Government Department to provide
all the information in the public domain freely to the citizens, the Departments
should aim to have a liberal copyright policy.

3.1.2

In cases where the document is in public domain and there is no restriction on its
reproduction, the copyright statement may be worded as follows:
Sample : Copyright Statement
“Material featured on this site may be reproduced free of charge in any
format or media without requiring specific permission. This is subject to the
material being reproduced accurately and not being used in a derogatory
manner or in a misleading context. Where the material is being published
or issued to others, the source must be prominently acknowledged.
However, the permission to reproduce this material does not extend to any
material on this site, which is explicitly identified as being the copyright of
a third party. Authorisation to reproduce such material must be obtained
from the copyright holders concerned.”

3.1.3

In cases where the nature of information/document calls for a restriction on its
reproduction, the copyright statement may be worded as follows:

©2009,NIC

21

<!-- page 44 -->

CH 03

Building Confidence

Sample of alternate Copyright Statement
“Material on this site is subject to copyright protection unless otherwise
indicated. The material may be downloaded without requiring specific
prior permission. Any other proposed use of the material is subject to the
approval of (name of Department). Application for obtaining permission
should be made to (email address of the concerned Department).”
3.1.4

The Departments should also be sensitive towards publishing any information
having a third party copyright. The Government Departments MUST follow
proper procedures to obtain the permission, prior to publishing such information
on their websites.

3.1.5

If any published Government Document/Report is being reproduced on any
website, whether as excerpts or in full, the source of the same i.e. Full Title of the
Report/Document along with the name of the concerned Department and year
of publication MUST be provided.

3.2
Content Hyperlinking

22

3.2.1

Since Government websites often receive queries and requests from owners of
other websites who might want to provide a hyper link to their web pages, every
Indian Government website MUST have a comprehensive and clear-cut hyper
linking policy defined and spelt out for those who wish to hyper link content
from any of its sections. The basic hyper linking practices and rules should ideally
be common across the websites of a State/Ministry.

3.2.2

The hyperlinking policy enumerating the detailed criteria and guidelines with
respect to hyperlinks with other sites may be made available under the common
heading of ‘Hyperlinking Policy’ and displayed at a common point on the
Homepage of all sites under the ownership a State/Ministry.

3.2.3

In case the concerned Department has no objection to anyone providing a
hyperlink to their website, the policy statement may be worded as:

<!-- page 45 -->

Guidelines
for Indian Government Websites

Sample Hyperlinking Policy
“We do not object to you linking directly to the information that is hosted
on our site and no prior permission is required for the same. However, we
would like you to inform us about any links provided to our site so that
you can be informed of any changes or updations therein. Also, we do not
permit our pages to be loaded into frames on your site. Our Department’s
pages must load into a newly opened browser window of the user.”
3.2.4

In case Prior permission is required by anyone who wishes to provide a link to a
Government website, the policy statement may be worded as follows:
Sample of alternate Hyperlinking Policy
“Prior permission is required before hyperlinks are directed from any
website to this site. Permission for the same, stating the nature of the
content on the pages from where the link has to be given and the exact
language of the Hyperlink should be obtained by sending a request at
(Email address of the Department).”

3.2.5

Many a times, cross linkages between different websites can cause ambiguity
in the mind of the visitors about the owner of a particular portion of content
and whom to be contacted in case of any query. Also, many a times, there
could be a difference in the security domains of two linked websites. Hence,
it is important to notify the visitors when they are leaving a particular website
through a hyperlink and entering another one. Clear indications MUST be
given when leaving the Government site for a non-Government website.
Sample of indication of leaving the Government Website
“This link shall take you to a page outside the (website URL). For any
query regarding the contents of the linked page, please contact the
webmaster of the concerned website.”

3.2.6

To create a visual distinction for links that lead offsite, Cascading Style Sheets
(CSS) controls or XSL or some such similar mechanism should be used. In case
the link takes the user to another website of the same Department/Ministry/
State, a seamless transition should be used through appropriate CSS controls.

3.2.7

Third party content should only be linked when consideration about the
copyright, terms of use, permissions, content authenticity and other legal and
ethical aspects of the concerned content have been taken into account.

©2009,NIC

23

<!-- page 46 -->

CH 03

Building Confidence

3.2.8

The overall quality of a website’s content is also dependent, among other things
on the authenticity and relevance of the ‘linked’ information it provides. This
fact is all the more significant in the context of a Government website since
there is a lot of credibility attached with an official website. Therefore, all Indian
Government websites should make sure that the external hyperlinks, wherever
present on the site MUST be verified and checked on a regular basis to ensure
that the information being provided ‘through’ them is up-to-date, accurate and
relevant.

3.2.9

Further, it MUST be ensured that ‘broken links’ or those leading to ‘Page Not
Found’ errors are checked on a regular basis and are rectified or removed from
the site immediately upon discovery. A number of technology tools are available
for convenient discovery of broken links.

3.3
Terms & Conditions
3.3.1

With the increased proliferation of Internet, more and more citizens are accessing
information from Government websites. Clearly defined Terms & Conditions
including well-worded disclaimers regarding the usage of websites MUST be
present on every Indian Government website.
Terms & Conditions shall address the following aspects:





24

Ownership Details
Usage Policy of Content
Legal Aspects
Responsibility towards hyperlinked Sites

3.3.2

Since it is the responsibility of all Indian Government Departments to uphold
and maintain the trust imposed in them by the visitors to the sites, the
Government websites should not out rightly ‘disclaim’ the content of another
Government website. Instead, a politely worded statement clearly indicating the
ownership of the particular piece of content and the relevant details for further
queries and information may be provided. Once all Indian Government websites
follow standard content practices, the visitors should be able to move from one
Government website to another in a manner as seamless as possible.

3.3.3

The Terms & Conditions MUST also clarify whether the information available
on the website may be construed as a statement of law to be used for any legal
purposes or not. It should also be mentioned that in case of any legal dispute
arising out of the content on the Government website, the matter shall be heard
in a court of law within the jurisdiction of the State where the concerned owner

<!-- page 47 -->

Guidelines
for Indian Government Websites

Department of the website/portal is located.
3.3.4

In case the content is sourced / linked from a non-government website at the
other end; the Terms & Conditions MUST clearly state this fact and disclaim
responsibility for its accuracy and currency.

3.3.5

In case the website involves any e-payment features where electronic transactions
are involved, appropriate disclaimers, worded in consultation with the involved
agencies (bank, payment gateway service provider etc.) and the legal cell of the
Department should be placed on the site.

Sample Statement for Terms & Conditions
This website is designed, developed and maintained by (name of Department),
Government of India.
Though all efforts have been made to ensure the accuracy and currency of the
content on this website, the same should not be construed as a statement of
law or used for any legal purposes. In case of any ambiguity or doubts, users
are advised to verify/check with the Department(s) and/or other source(s), and
to obtain appropriate professional advice.
Under no circumstances will this Department be liable for any expense, loss
or damage including, without limitation, indirect or consequential loss or
damage, or any expense, loss or damage whatsoever arising from use, or loss of
use, of data, arising out of or in connection with the use of this website.
These terms and conditions shall be governed by and construed in accordance
with the Indian Laws. Any dispute arising under these terms and conditions
shall be subject to the jurisdiction of the courts of India.
The information posted on this website could include hypertext links or
pointers to information created and maintained by non-Government/private
organisations. (Name of Department) is providing these links and pointers solely
for your information and convenience. When you select a link to an outside
website, you are leaving the (Name of Department) website and are subject to the
privacy and security policies of the owners/sponsors of the outside website.
(Name of Department), does not guarantee the availability of such linked pages
at all times.

©2009,NIC

25

<!-- page 48 -->

CH 03

Building Confidence

(Name of Department), cannot authorise the use of copyrighted materials
contained in linked websites. Users are advised to request such authorisation
from the owner of the linked website.
(Name of Department), does not guarantee that linked websites comply with
Indian Government Web Guidelines.

3.4
Privacy Policy
3.4.1

Government websites should follow an extremely cautious approach when it
comes to collecting personal details/information about the visitors to the sites.
It should be an endeavour to solicit only that information which is absolutely
necessary.

3.4.2

In case a Department solicits or collects personal information from visitors
through their websites, it MUST incorporate a prominently displayed Privacy
Statement clearly stating the purpose for which information is being collected,
whether the information shall be disclosed to anyone for any purpose and to
whom.

3.4.3

Further, the privacy statement should also clarify whether any cookies shall be
transferred onto the visitor’s system during the process and what shall be the
purpose of the same.

3.4.4

Whenever a Department’s website allows e-commerce and collects high risk
personal information from its visitors such as credit card or bank details, it
MUST be done through sufficiently secure means to avoid any inconvenience.
SSL (Secure Socket Layer), Digital Certificates are some of the instruments,
which could be used to achieve this.

It is further informed that the following examples of Privacy Statements are only for
reference purpose and Departments are requested to customise it to the requirements of
their own websites.

26

<!-- page 49 -->

Guidelines
for Indian Government Websites

Sample Privacy Statement :
Thanks for visiting website of (Name of Department), and reviewing our
privacy policy.
We collect no personal information, like names or addresses, when you visit
our website. If you choose to provide that information to us, it is only used to
fulfil your request for information.
We do collect some technical information when you visit to make your visit
seamless. The section below explains how we handle and collect technical
information when you visit our website.

Information collected and stored automatically
When you browse, read pages, or download information on this website, we
automatically gather and store certain technical information about your visit.
This information never identifies who you are. The information we collect
and store about your visit is listed below:
 The Internet domain of your service provider (e.g. mtnl.net.in)
and IP address (an IP address is a number that is automatically
assigned to your computer whenever you’re surfing the web) from
which you access our website.
 The type of browser (such as Firefox, Netscape, or Internet
Explorer) and operating system (Windows, Linux) used to access
our site.
 The date and time you accessed access our site.
 The pages/URLs you have visited and
 If you reached this website from another website, the address of
that referring website.
This information is only used to help us make the site more useful for you. With this
data, we learn about the number of visitors to our site and the types of technology
our visitors use. We never track or record information about individuals and their
visits.

Cookies
When you visit some websites, they may download small pieces of software on
your computer/browsing device known as cookies. Some cookies collect personal
information to recognise your computer in the future. We only use non-persistent
cookies or “per- session cookies”.

©2009,NIC

27

<!-- page 50 -->

CH 03

Building Confidence

Per-session cookies serve technical purposes, like providing seamless navigation
through this website. These cookies do not collect personal information on
users and they are deleted as soon as you leave our website. The cookies do not
permanently record data and they are not stored on your computer’s hard drive.
The cookies are stored in memory and are only available during an active browser
session. Again, once you close your browser, the cookie disappears.

If you send us personal information
We do not collect personal information for any purpose other than to respond to
you (for example, to respond to your questions or provide subscriptions you have
chosen). If you choose to provide us with personal information— like filling out a
Contact Us form, with an e-mail address or postal address, and submitting it to us
through the website—we use that information to respond to your message, and to
help you get the information you’ve requested. We only share the information you
give us with another Government agency if your question relates to that agency, or
as otherwise required by law.
Our website never collects information or creates individual profiles for commercial
marketing. While you must provide an e-mail address for a localised response to
any incoming questions or comments to us, we recommend that you do NOT
include any other personal information.

Site Security

28

•

For site security purposes and to ensure that this service remains
available to all users, this Government computer system employs
commercial software programs to monitor network traffic to identify
unauthorised attempts to upload or change information, or otherwise
cause damage.

•

Except for authorised law enforcement investigations, no other
attempts are made to identify individual users or their usage habits.
Raw data logs are used for no other purposes and are scheduled for
regular deletion.

•

Unauthorised attempts to upload information or change information
on this service are strictly prohibited and may be punishable under
the Indian IT Act.

<!-- page 51 -->

Guidelines
for Indian Government Websites

Sample of alternate Privacy Policy Statement (in case a website does
not collect any personal data)
As a general rule, this website does not collect Personal Information about you
when you visit the site. You can generally visit the site without revealing Personal
Information, unless you choose to provide such information.

Site Visit data:
This website records your visit and logs the following information for statistical
purposes -your server’s address; the name of the top-level domain from which you
access the Internet (for example, .gov, .com, .in, etc.); the type of browser you
use; the date and time you access the site; the pages you have accessed and the
documents downloaded and the previous Internet address from which you linked
directly to the site.
We will not identify users or their browsing activities, except when a law
enforcement agency may exercise a warrant to inspect the service provider’s logs.

Cookies:
A cookie is a piece of software code that an internet web site sends to your browser
when you access information at that site. This site does not use cookies.

Email Management
Your email address will only be recorded if you choose to send a message. It will
only be used for the purpose for which you have provided it and will not be added
to a mailing list. Your email address will not be used for any other purpose, and
will not be disclosed, without your consent.

Collection of Personal Information:
If you are asked for any other Personal Information you will be informed how
it will be used if you choose to give it. If at any time you believe the principles
referred to in this privacy statement have not been followed, or have any
other comments on these principles, please notify the webmaster through the
contact us page.

Note: The use of the term “Personal Information” in this privacy statement refers
to any information from which your identity is apparent or can be reasonably
ascertained.

©2009,NIC

29

<!-- page 52 -->

<!-- page 53 -->

Guidelines for Indian Government Websites

CH 04

Scope of Content

4.1

INFORMATION IN PUBLIC DOMAIN

4.2

PRIMARY CONTENT

4.3

SECONDARY CONTENT

4.4

TERTIARY CONTENT

4.5

MINIMUM CONTENT

4.6

INFORMATION MEANT FOR INTERNAL USE

4.7

INFORMATION TO AVOID

<!-- page 54 -->

<!-- page 55 -->

Guidelines
for Indian Government Websites

Scope of Content
4.1
Information in Public Domain
The content of a Government website is its soul as the citizens rely heavily upon a
Government website to access authentic and up-to-date information. Ideally, an Indian
Government website ought to have the following kinds of content:
a. Primary Content :
Primary content shall be the original content that is sought by target audience
of the website which could be citizens, business community, overseas
citizens or other Government Departments or even Government employees.
Examples of such content are information about the Department, various schemes
and programmes of the Department, documents, forms etc. Besides regulatory
content mandated by legislation such as IT act, RTI or even directives from
apex offices shall also form a part of this category e.g. parliament question and
answers.
b. Secondary Content :
Secondary content is generated from the assortment, packaging of primary content
to suit the requirement of different audience, events and occasions Examples of
such content are advertisements / banners/ spotlight / media gallery/related sites
etc.
c. Tertiary Content :
Information about the ‘Primary’ and ‘Secondary’ content forms a part of the
tertiary content. This includes sections like About the Site, Online Help, Terms
and Conditions and Frequently Asked Questions (FAQ).
Departments/ Organisations should compile their own list of contents/ sub contents
which they feel should be in public domain or needed by their intended audience.
Information could be free to access by all or part of information, (due to concerns of
privacy & sensitivity) could be made available only to registered users.
A generic list of content is given at the following pages

©2009,NIC

33

<!-- page 56 -->

CH 04

Scope of Content

Generic List of Content
Primary Content
Long Term Value

Short Term Value

About The Ministry/Department/State

News

Acts & Rules

Press Releases

Programmes & Schemes

Tenders

Documents

Recruitments

Forms
Services
Sectoral Profile
Regional Profile
Contact Information

Secondary Content
Special Interest Group/ Audience Specific Views
Events / Announcements
Disscussion Forum
Spotlight
Related Links
Media Gallery
Greetings
Advertisements & Banners

Tertiary Content
About The Portal
Sitemap, Search
Terms and Conditions
FAQ
Feedback (General / Content Specific)
Help
Registration
Content Contributor, Source & Validity

Guidelines pertaining to compilation of content in some of the common content
categories have been given in the following sections.

34

<!-- page 57 -->

Guidelines
for Indian Government Websites

4.2
Primary Content
Primary Content forms the main focus of any Government website as it comprises
information which the citizen has visited the website for. Examples are information about
the Department, schemes and programmes, contact information, forms, documents,
tenders etc. Broadly, the following sub categories encompass most of the Primary Content
that ought to be made available on an Indian Government Website.

4.2.1 About Us
(Ministries/Department / State Govt./ Organisation/ District Administration)
This essentially refers to the content describing the owner Department of the website and
comprises the following information:
 Profile
 Mission/Vision Statement
 History/Background
 Departments/Divisions/Cells
 Role/Functions/Responsibilities/Activities
 Agencies under the Administrative Control
 Organisational Structure
 Who’s Who
This content should be reviewed frequently to ensure the accuracy and currency of the
information. All information concerning the Legislative/Government officials MUST
always be kept up to date.

4.2.2 Profile of a Sector / Region
Some websites/portals shall also be required to include a section on the overview of
sector(s) they deal with naming all information concerning that sector present on their
website or website of other Government entities working in that sector. This should be
made accessible to give a comprehensive view to the visitors.
Similarly some of the portals are required to publish profile of a region e.g. National
Portal publishes a profile of India. States Portals should publish a profile of the respective
States while District websites should publish a profile of their respective district.
Detailing of this segment should be done by each Department and included in their
web content policy. Policy must also include the frequency / event of updation as well as
officers responsible for updating this content.

©2009,NIC

35

<!-- page 58 -->

CH 04

Scope of Content

4.2.3 Programmes & Schemes
The Government Departments at the Centre and State have welfare programmes, and
schemes benefiting the individuals, groups of citizens (e.g. women, physically challenged
etc.) or community at large running in different regions and sectors across the country.
Information about all such schemes of the Central as well as State Governments is
included in this category. These schemes could be Centrally Sponsored, or being run by
the State/ District Administration itself. It is important to note that these schemes should
be directly benefiting the individuals, special interest groups of citizens (e.g. widows,
physically challenged etc.) or the community at large. Also, information should only be
highlighted with regard to those schemes, which are currently active and ongoing, and
not about schemes which are no longer open/available to the public.
a. The content submitted about schemes should be reviewed at least every quarter
to ensure the accuracy and currency of the information.
b. The complete official title of the Scheme MUST be reflected and should be
self-explanatory. The correct title would lead to an accurate search output for
information on that scheme and it would be easy for the users to locate it. Any
abbreviation in the title should be expanded.
c. This site should enlist all those who are eligible to receive benefits under the
scheme e.g. women, children, disabled, poor etc. Also, the details of the
eligibility criteria for availing those benefits should be clearly mentioned.
d. Information should be given about whether the scheme entails monetary or
non-monetary benefits. Also, what are the specific kinds of non-monetary
benefits, which can be availed e.g. Subsidy, training, land allotment etc.
e. Procedure to be followed, whom to contact, supporting documents to be
carried etc. for availing benefits under the scheme MUST form a part of this
content.
f. Validity of the scheme MUST also be mentioned so that the information could
accordingly be moved to archives after the expiry date and the visitors are not
misled in any way.

4.2.4 Services
A large number of citizen services are being provided by the various Ministries,
Departments and State/UT Governments. Information about these services as well as
the interface to access and use them (if it is available online) should be made available on
their websites.
a. It is important to clearly understand what constitutes the term ‘services’ in
this context. Information about all services provided by the Government,

36

<!-- page 59 -->

Guidelines
for Indian Government Websites

whether fully online, partially online or available offline but whose
description and details exist online can be called services. For example, if
the complete details about how to apply for a birth certificate in a particular
State are given along with the facility to download the requisite application
form, it shall be categorised as a Service. However, just information about
things like a programme of any Department, or access to a some searchable
database without any service associated will not constitute a ‘Service’.
b. The complete title of the Service MUST be reflected and should be selfexplanatory. The correct title would lead to an accurate search output for
information on that service and it would be easy for the users to locate it.
Any abbreviation in the title should be expanded.
c. The websites should prominently display the most often used/ accessed
services, so that visitors can locate and access them quickly.
d. The website MUST provide a complete description of what the service is,
how is it useful for the citizens, how it can be availed, who is eligible to
avail the service, who is to be contacted and during which hours. This is
very important for the common citizens to understand the significance of
the service and what are the steps to be followed for availing it.
e. If the service is delivered online then it should be developed as a webservice
so that other websites and portals can access it seamlessly, subject to
authorisation of the owner Department. All on-line services should be
made available through the National Portal as a ‘web service.’

4.2.5 Application Forms
Visitors to Government websites want fast, easy service 24 hours a day, 7 days a week.
They do not want to wait until an organisation is open for business. They do not want
to wait in line or on the phone to get forms and documents to avail the desired service.
Therefore, all application forms existing in the public domain and meant for applying for
licenses, certificates, scholarships, grants, services, information, loans, utilities etc. should
be published on the concerned Government website for the convenience of citizens.
a. All Forms MUST be provided in an accessible format (refer section 7.4.2).
b. The title of the form MUST be clearly indicated and should be selfexplanatory and devoid of any abbreviations which may render it universally
incomprehensible. The correct title would lead to an accurate search output for
information on that Form and it would be easy for the users to locate it. Also,
in case the Form is popularly known by a number (e.g. Form 16 for Income
Statement or Form 4 for Driving license), the same should also be mentioned

©2009,NIC

37

<!-- page 60 -->

CH 04

Scope of Content

along with the title.
c. It should be specified whether the language of the form is English, Hindi or
any other Regional language. In case of the latter, the name of the concerned
language MUST be mentioned clearly. If the form is bi-lingual/ multi-lingual,
it is important to mention the languages it exists in.
d. Information assisting the user in filling up the application form should also be
provided such as where to submit and which supporting documents to attach
etc.

4.2.6 Acts & Rules
All the Acts passed by the Parliament as well as the State Legislative Assemblies should
be reflected on the website of the concerned Government Department so that they can
be accessed for reference. Further, the Rules/Sub-ordinate legislations issued by the
Departments based on those Acts should also be displayed on the website.
a. The complete title of the Act as written in the official notification MUST be
mentioned which should be self explanatory and devoid of any abbreviations
etc. which may render it universally incomprehensible. The correct title would
lead to an accurate search output for information on that Act and it would be
easy for the users to locate it.
b. The ‘Extent of the Act’ or the scope or geographical region to which the Act
applies should also be mentioned. In case it is a Central Act passed by the
parliament, the extent is normally the whole of India. However, the Acts
passed by the State Legislatures are usually confined to the boundaries of the
concerned state.
c. The Commencement Date from which the Act comes into force should also
be mentioned.
d. As far as ‘Rules’ are concerned their relation with respective Acts should be
highlighted as far as possible.
e. Acts and Rules MUST be compiled in an accessible format (refer section
7.4.2).

4.2.7 Documents/Reports
a. All documents developed/published and issued in the Public Domain by
Government Departments, Ministries, State/UT Governments, Public Sector
Units and Organisations must be published in the website. The following list
gives an idea of the variety of Government documents that can be covered

38

<!-- page 61 -->

Guidelines
for Indian Government Websites

under this :
•
•
•
•
•
•
•
•

Five-year Plan documents
Annual Reports
Budget Documents
Guidelines by Government
Citizen Charters
Census Documents
Survey Outcomes / Reports
Statistical Reports etc.

b. This content should be reviewed every quarter to ensure the accuracy and
currency of the information.
c. The complete official title of the document MUST be mentioned on the site.
The correct title would lead to an accurate search output for that document and
it would be easy for the users to locate it. For example: ‘Policy on Promotion of
Tourism in the State of Manipur’ is a more appropriate title than just ‘Tourism
Policy.’ Any abbreviation in the title should be expanded and the title should
not be formulated on just a document number/date.
d. In case any reference to a document of another Government Department is
given, it should be clearly specified as with whom lies the ownership of the
document i.e. which is the exact Ministry/Department at the Central or State
level which has produced/published/issued the concerned document.
e. It should be specified whether the language of the document is English, Hindi
or any other Regional language. In case of the latter, the name of the concerned
language MUST be mentioned clearly. If the document is bi- lingual/ multilingual, it is important to mention the languages it exists in.
f. It is important that if the document is valid only for a certain time period, the
validity MUST be clearly mentioned on the site. In fact, the document should
be moved to the archives after expiry of the validity period.
g. Documents MUST be made available in an accessible format (ref. section
7.4.2).
h. In case a document is large it may be broken down into multiple parts to
facilitate easy download.

4.2.8 Circulars/Notifications
There are various Circular/ Notifications that are released from time to time by the
Indian Government at the Central or State level. Information about all the Circular/
Notifications of the Central as well as State Governments should be made available on
the National Portal.

©2009,NIC

39

<!-- page 62 -->

CH 04

Scope of Content

a. The official title of the Circular/ Notification MUST be mentioned and should
be self explanatory. The correct title will also help in accurate search output for
information on that circular and thus, it would be easy for the users to locate
it.
b. The ownership of the concerned circular should be specified i.e. Ministry/
Department and also the level i.e. Central/ State etc.
c. Circulars/Notifications MUST be made available in an accessible format (refer
section 7.4.2).
d. If the Circulars/Notifications are valid only for a certain time period, the validity
MUST be clearly mentioned on the site. In fact, the Circulars/Notifications
should be moved to the archives after expiry of the validity period.

4.2.9 Tenders
Government and Public Sector Procurement / Tenders/ Notifications issued by the
Central and State Governments and other public bodies across India for goods, services
and works MUST be made available through the websites. As is also directed by the
Central Vigilance Commission (CVC) following are some of the guidelines with respect
to tenders.
a. Information MUST include the notifications and complete documents for
tenders.
b. Tenders of all categories including open tenders, limited tenders, empanelment,
auctions, work contracts, service contracts etc. should be published on the
website.
c. All these tender notifications should be uploaded on the single entry
Tenders Portal for the Government ( http://tenders.gov.in ), which is
a one-stop source for tenders of various Government Departments,
developed on the advice of the Central Vigilance Commission
( refer- http://www.cvc.gov.in).
d. Outdated tenders MUST be immediately removed from the website and
moved to archive or deleted as per the Departmental policy. If the tenders are
published through the Tenders Portal it is automatically taken care of.
e. All tender documents MUST be published in an accessible format (refer
section 7.4.2).

4.2.10 Recruitment
All Indian Government websites MUST provide complete and transparent information on
their recruitment policies for the benefit of those who would like to join the Government
and serve the nation. In case the recruitment is through some Central or State level
examination or recruitment agency such as UPSC, SSC etc. that should be highlighted

40

<!-- page 63 -->

Guidelines
for Indian Government Websites

along with a link to respective pages of those organisations websites. In either of the cases
information about the recruitment should abide by the following guidelines.

CH
a. Th05
e title of the recruitment notice should be self-explanatory.
b. This site should enlist all those who are eligible for a particular recruitment.
Also the details of the eligibility criteria should be clearly mentioned.
c. All required application forms should be made available on the website so that
the interested person can download and submit the same.
d. Procedure to be followed, whom to contact, supporting documents to be
carried etc. for the particular recruitment MUST form a part of this content.
e. All currently open vacancies may be highlighted on the Homepage of the
website.
f. All recruitment notices MUST also be registered with the National Portal for
wider access by target audience.
g. Information for those recruitment notices in which the last date is over MUST
be either removed or moved into the archives section.

4.2.11 News and Press Releases
News having national importance and significance for the Citizens as well as Government
Press Releases issued by Departments and organisations at the Central and State level
should be published on the website of the concerned Department. News and Press
Releases MUST carry the date and should be organised as per the Archival Policy of the
website. News and Press releases should be published in RSS format so that associated
offices and Departments can also consume them on their websites with due permission
or based on their access policy.

4.2.12 Contact Information on Government Websites
Citizens would like to contact any Government Department or entity to ask questions,
get information, seek clarifications or sort out problems. Therefore it is essential that
Government websites provide them with the means to do that.
a. All Indian Government websites MUST have a ‘Contact Us’ page, linked from
the Homepage and all relevant places in the website.
b. The ‘Contact Us’ page should be categorised according to the various divisions
handling different kind of queries; e.g. grievance redressal, file status, procedural
details etc.

©2009,NIC

41

<!-- page 64 -->

CH 04

Scope of Content

c. The contact details for the Important functionaries in the Department MUST
have the telephone numbers, fax numbers, postal address as well as email address
along with the timings specified for personal public dealing (if applicable). The
content policy of the department should enlist the functionaries whose details
are to be given on the website.
d. There should be a clear-cut policy for redress (correction) of inaccurate
information found on the website. The contact details of the Web Information
Manager, who is overall responsible for the content on the website, should be
provided.

4.2.13

Presence on the National Portal
Mechanism MUST be in place to ensure that all Citizen Services, Forms,
Documents, Schemes are registered with the respective repositories of the
National Portal.

4.3
Secondary Content
Secondary content is generated from the assortment and packaging of primary content
to suit the requirement of different audience, events and occasions Examples of such
content are advertisements/banners/spotlight/media gallery/related sites.

4.3.1 Special Interest Group Corner
In case there is an event or occasions, Government departments may introduce a
special section for a particular target group e.g. during result time a special section
for students may be put up or the Department of Social Welfare may open a section
for senior citizens on its website. Here, it must be noted that the original content
that is sourced from various sections of the website to make up this section should
remain as such so that it may be referred to once the section has ben removed.

4.3.2 Events and Announcements
Government websites should have a section to cover various Events &
Announcements such as.
• Announcements having International/National/State level importance
should be published on the website.
• Announcements related to important upcoming Government events being
organised by a Ministry/Department/State/UT.

42

<!-- page 65 -->

Guidelines
for Indian Government Websites

• Announcements should be worded in simple English/Regional language
depending on whom it is meant for.
• Announcements related to schemes/grants/scholarships/fellowships etc.
• Warnings of Natural disasters/Epidemics etc.
• Calls for relief funds during disasters. Other help from citizens or civic
agencies.
• Display of important helpline numbers in case of crisis.
Guidelines relating to events and announcements are as follows:
a. It is MUST to take off / archive the announcement once it loses its relevance
or after the expiry of the time period attached to the event or happening.
b. All important announcements should also be published on the National
Portal for wider access.

4.3.3 Discussion Forums & Chat Rooms
Discussion forums are becoming an increasingly popular tool for sharing
viewpoints and information. Discussion Forums could be initiated by a
Department on any relevant topic of public interest and can prove quite useful
in obtaining opinions and viewpoints of the citizens on issues important for
policy making. While initiating an online discussion forum on a Government
Department’s website, the following has to be kept in mind:
a. The purpose and objective of the Discussion Forum should be clearly
defined. Preferably, an initiating document or background paper explaining
the theme of the topic for the forum may be provided on the site.
b. Clear-cut Terms and Conditions for participating in the Discussion Forum
should be indicated and a Usage Policy (see box) should be defined.
c. The discussion forums on a Government website MUST be moderated so
that there is some control to avoid publishing unwanted content on the
website. All the inputs submitted by the users must first be reviewed by the
moderator for context and appropriateness of the language and then posted
on the website.
d. The discussion forum should be open for a limited period of time and the
validity of the same should be prominently indicated on the site. However,
rather than closing the forum abruptly, it is advised that a summary of the
inputs received as well as an Action Taken Report, if possible, should be
provided on the website so that the visitors are assured that their inputs are
being seriously considered and valued by the Department.

©2009,NIC

43

<!-- page 66 -->

CH 04

Scope of Content

Chat Rooms
Chat rooms on a website could be used by citizens to exchange their viewpoints
on some common topic amongst each other as well as by the Departments
to facilitate an online conversation between a senior functionary and citizens.
Like Discussion Forums, Chat rooms should also follow a Usage Policy (see
box) and a proper code of conduct. It is desirable that the participants of an
online chat through a Government Department’s website be registered before
they are allowed to log in and post their messages. Permanent chat rooms
should be monitored frequently. In case of temporary or special occasion chat
sessions with a senior functionary, it is advised that questions be submitted to
the interviewee, before being published in the chat room.

Online Disscussion Forum : Usage Policy
A Usage Policy should be established and published alongside all online
discussion forums and chat rooms on a Government website. This policy should
be prominently displayed to any new user who should be made to pass through
a page with this information before being able to input data. The usage policy
should clearly specify that the following is forbidden :
• Insulting, threatening or provoking language.
• Inciting hatred on the basis of race, religion, gender, nationality or
sexuality or other personal characteristics.
• Swearing, using hate-speech or making obscene or vulgar
comments.
• Libel, condoning illegal activity, contempt of court and breach of
copyright.
• Spamming, i.e., adding the same comment repeatedly.
• Impersonating or falsely claiming to represent a person or
organisation.
• Posting in a language other than the language of the website.
• Invading people’s privacy.
• Posting off-topic comments.

4.3.4 Related links
For every content topic in different modules of the website, a section should be
provided for ‘Related Links’ to the concerned information.
a. Each content topic covered in the website may have some Related Links to
other Government websites which provide further details on the topic.
b. For every Related Link, the complete URL of the Homepage/Concerned

44

<!-- page 67 -->

Guidelines
for Indian Government Websites

webpage MUST be provided correctly along with the complete title of the
Website which shall appear on the screen.
c. The validity and accuracy of the URL MUST be checked on a regular basis to
make sure that the information is relevant and the linked address is correct.
Only Government websites/webpages should be provided as ‘Related Links’ for
further information since there is no control over the veracity and availability of
information on private websites.

4.3.5 Spotlight
The website may have a section called ‘Spotlight’ which focuses on a certain issue
of importance and brings it in to the limelight. The guidelines with regard to this
section are:a. Every Spotlight topic should be chosen keeping in mind the relevance and
significance of the topic in today’s context. It should be ensured that the chosen
topic is of significance and should interest a diverse group of audience.
b. The content for the Spotlight Section should have the following essential
elements:
• Brief introductory text to appear on the Homepage of the website.
• Detailed text on the topic in the Main Page of the Spotlight section. This
content should comprise key highlights of the topic and the facts ought
to be sourced from authentic and official sources relating to the topic.
• Address of the Webpage/Websites which have detailed information on
the topic addressed in the Spotlight.
• Graphical Banner highlighting the Spotlight topic and linked to the
webpage with further details.
c. Once the new Spotlight is launched, the older one should be passed in an
Archives section along with the date for future reference.

4.4
Tertiary Content
Information about the ‘primary’ and ‘secondary’ content forms a part of the tertiary
content. The guidelines for this type of content are given as follows:
4.4.1

About the site i.e. Department that is responsible for the contents as well as the

©2009,NIC

45

<!-- page 68 -->

CH 04

Scope of Content

maintenance of the site, what is the purpose behind the development of the site,
when was it launched, where is it hosted etc.
4.4.2

Navigation Aids Sections such as Online Help, Site Map, and Search (described
in detail in the latter sections).

4.4.3

Terms and Conditions with respect to the usage of content on the site. This
includes policies on Copyright, Privacy, Legal Implications etc. as well as Content
Disclaimers. This has been explained in detail in the previous chapter.

4.4.4 ‘Frequently Asked Questions’ or FAQs
Although the content developers of websites make (and should make) all possible
efforts to ensure that the content answers all possible and anticipated information
needs of the citizens, it is sometimes not possible to address it completely. Visitors
still have questions because either they couldn’t find what they were looking for or
because it is presented in such a manner that it is difficult for them to comprehend
or understand. In such a case, a detailed list of answers to common questions can
prove highly useful to the website audience. Also, it has been proved by usability
studies that information presented in a ‘question-answer’ form is much easier for
people to understand than lengthy write-ups.
Hence, Government websites, particularly the ones having frequent interaction
with citizen for various services/schemes should have a ‘Frequently Asked
Questions’ module linked from the Homepage and all other relevant places in
the site.
The web information managers can compile the list of commonly asked queries
and their answers through the following sources:
• Email, phone calls and letters from the public.
• A survey could be conducted amongst the public.
• Input from people who answer phones and mail in the organisation.
• Review of website usage statistics and top search terms.

4.4.5 User Feedback
A commonly used method of receiving the feedback from the visitors of the site is
through feedback forms or guest books. Feedback forms, with pre-decided fields,
to be filled in by the visitors, enable a much more structured way of receiving
feedback and hence make it easy to categorise or analyse the same. Forms are also
quite useful for receiving grievances/complaints from the users in a structured
and formatted manner. The information collected through feedback forms can
also be used as a means of knowing the usage pattern of the website and can be
used in the enhancement of further versions of the website.

46

<!-- page 69 -->

Guidelines
for Indian Government Websites

a. All feedback MUST be collected through online forms for reasons explained
above.
b. All feedback forms must be prominently displayed on the website.
c. Departments MUST respond to the feedback explaining how it shall be
processed.
d. Departments should also make it clear on the response screen whether citizens
should expect a reply on their feedback If ‘yes’ then in how many days.

4.4.6 Help
A special section ‘Help’ on the website MUST be created, which allows and
guides for a pleasant experience while browsing the website. This category includes
the kind of content which allows for an easy and convenient navigation for the
visitor to the website (e.g. online help, how to open files of certain formats, how
to access audio/video on the portal, kinds of plug-ins required etc.). Further, the
content which clarifies the purpose of the website as well as its policies for the
visitors should also be included in this category.

4.4.7 Downloads and Plug-ins
a.

Information about downloadable material
Downloading material from the Internet can be an expensive and timeconsuming exercise. Therefore, Government websites MUST provide
Information that will help visitors determine whether they want to access
downloadable material. This information would concern the following:
•

Self explanatory title of the document/file.

•

Download and use instructions (install, open, view).

•

File format & file size.

b. Size of downloads to be minimised:
The total size of the file should be kept to a minimum to ensure acceptable
download times for all users, especially those that do not have high-speed,
reliable Internet connections.
c. Virus Free Downloads:
Prior to making downloadable material available for visitors, Government
websites MUST check for viruses and clear them.

©2009,NIC

47

<!-- page 70 -->

CH 04

Scope of Content

4.5
Minimum Content
The homepage of a website is the primary entry page to the entire content of the website.
It is important that the visitors to the site get to access the most important content
elements from the Homepage itself.
4.5.1

Government websites MUST ensure the availability of the following minimum
content elements on the Homepage. This is applicable not just to the websites
of Departments but also to any Indian Government website, be it on a specific
Project, a Task Force, Committee or Service etc.

Minimum Content on the homepage of a Department
 Department Name (alternatively, the name of the Project, Service etc. as
applicable).
 National Emblem/Logo (as applicable).
 About the Department (including its main activities & functions).
 Link to all the major modules/sections of the site.
 Link to all the citizen services offered by the Department.
 A link to the ‘Contact Us’ page of the website.
 A link to the “Feedback” page.
 A link to National Portal.
 Search/Site Map.
 Terms and Conditions of Use.
4.5.2

Minimum Content on Subsequent Pages:
Apart from the Homepage, the subsequent pages of the website MUST have
the following minimum information, in addition to the main content.
 Self explanatory title of the page.
 Link to the Homepage.
 Link to the parent section/top module of the individual page.
 Ownership (name of the Department owning the website).
 Link to the “Contact Us” page.
 Last Reviewed / Updated date.

48

<!-- page 71 -->

Guidelines
for Indian Government Websites

4.6
Information meant for Internal Use

CH 05

Government websites contain information and services for the public. Therefore, it has
to be strictly noted that Indian Government websites should not be used to convey
information specific to the Department’s employees. Information meant for the internal
consumption of the employees should be disseminated through Intranets. This is required,
since information intended for employees can confuse the common public visiting the
website.
•

All information meant for internal consumption and not in public domain,
presently existing on any Indian Government website should be moved to an
Intranet secured through proper authentication.

In case for some reason it is not possible for the Department to develop an Intranet,
the information meant for internal use may be isolated and explicitly labelled (e.g. ‘for
employees’ or ‘for internal use’), to make it clear to the public that it is not intended for
them.

4.7
Information to Avoid
4.7.1

Commercial banner advertisements should be avoided on Government websites.
Banner advertisements that promote and link to other Government agencies as
well as social messages are permissible.

4.7.2

Any information in text, visual or any other media which may offend/harm the
National sentiments, religious communities as well as security and integrity of
the Country MUST be avoided on the websites.

4.7.3

Government Information which is confidential or only for restricted use should be
avoided on a website meant for the common public.

©2009,NIC

49

<!-- page 72 -->

<!-- page 73 -->

Guidelines for Indian Government Websites

CH 05 Quality of Content

5.1

CITIZEN ORIENTATION

5.2

CONTENT AUTHENTICITY, ACCURACY & CURRENCY

5.3

LANGUAGE

5.4

CONSISTENT TERMINOLOGY

5.5

INTERNATIONAL CONVENTIONS

5.6

INFORMATION ARCHITECTURE & RELATIONSHIP

5.7

MULTILINGUAL VERSIONS

<!-- page 74 -->

<!-- page 75 -->

Guidelines
for Indian Government Websites

Quality of Content
5.1
Citizen Orientation
The crucial element of an effective presence of Government on the Web is the way
its content is written and packaged. Indian Government websites should be oriented
towards their prospective audience. Intended audience to the Government website could
be Citizens, Businesses, Government Departments as well as Government employees.
Following are the guidelines towards the same.
5.1.1

The content MUST be selected keeping the audience in mind, not from the
Government’s perspective. Apart from the selection of the content, equal emphasis
should be given to the way it is written and presented on the web. Content
aimed at the common public should be written in simple language so that people
from diverse professional, educational and demographic backgrounds can easily
comprehend the same.

5.1.2

Homepage of the website should be designed carefully and effectively to provide
a good interface for the citizen. Homepages should ideally not feature photos
of individuals and office bearers of the Department. Those photos may be
appropriate on the “About Us” or “News” page.

5.1.3

In order to gauge the content requirements of the citizens, who are the prime
target audience of any Government website. Government Departments may use
following means to determine the best way to identify and package information
for citizens and other stakeholders.
 Discussion Forums.
 Customer satisfaction surveys.
 Online feedback from citizens.
 Analysing website usage reports, including search terms and statistics.
 Usability testing and research.

©2009,NIC

53

<!-- page 76 -->

CH 05

Quality Of Content

5.2
Content Authenticity, Accuracy & Currency
It is the duty of every Web Information manager to ensure that the content on his/
her website is always authentic, up-to-date and latest. This fact assumes paramount
significance in the context of Government websites since the public puts a lot of trust in
the information available on the official websites of the Government.
5.2.1

Each and every bit of content published on a Government website should be
verified and checked thoroughly as the public expects nothing less than authentic
and accurate information from a credible source such as an official Government
website. The Departments MUST have a Content Contribution, Moderation and
Approval Policy (CMAP) stating the responsibility, authorisation and workflow
details with regard to content publishing on the site.

5.2.2

The Homepage MUST and every important entry page of all Indian Government
websites/portals should display a time stamp indicating the following:
a. Date on which the information was posted on the website.
b. Date on which the content was last reviewed and/or modified.

54

5.2.3

Every piece of content appearing on the Government website should be
reviewed after a pre-decided duration for its accuracy, relevance and currency.
All Government Departments MUST formulate a proper web Content Review
Policy (CRP) depending upon the nature of their content and if possible; also
publish the policy on their website.

5.2.4

In case the nature of the content is ‘historical’ i.e. it will never change (e.g. press
releases, speeches, published reports/documents of a Department etc.), the date
of posting the content may be mentioned along with a note indicating the nature
of the document and explaining that it is not subject to revision.

5.2.5

In case the reports and documents are voluminous and it is difficult to mention
the time stamp on every page, the same MUST be indicated on the main page as
well as on all icons/places which link to that document.

5.2.6

For time sensitive content which expires after a certain date (e.g. tender
notifications, announcements for conference registrations, contest entries etc.), a
policy on whether the content should be archived for future reference or removed
altogether from the website should be decided by the concerned Department
after careful consideration of their nature of content. However, ‘expired’ content
MUST not be presented or flashed on the website. The Departments MUST
have a clearly laid out Content Archival Policy (CAP) clarifying the rules set in
this regard.

<!-- page 77 -->

Guidelines
for Indian Government Websites

5.3
Language
The language used in a Government website is very important for ensuring effective
communication with the target audiences. If the language on the website is complex and
uses terminology which a common visitor is unfamiliar with, the very purpose of having
the website will be lost.
5.3.1

Departments MUST ensure that homepage, all major entry points, and
navigational elements of Government websites are written in the clear and simple
language appropriate for the sites content.

5.3.2

Indian Government websites normally have diverse target audience with diverse
demographic profiles and educational background. Therefore it is highly desirable
that the language used in the Government website is understood easily and
correctly by all sections of the audiences.

5.3.3

Departments may test the language and its comprehension with a sample set of
typical visitors before making the site live for all audiences.

5.3.4

Writing for the web is very different from writing for the Print medium. One of
the best ways of making the language web friendly is to keep the sentences short
and simple. Long, convoluted sentences seem forbidding on screen and can
distract the visitors.

5.3.5

There are tools available which can help a Department evaluate how easy to
understand and comprehend the language used on their website is. Departments
should use such language tools, including language software, to evaluate the
readability of the website’s content.

5.3.6

The language used in a Government website MUST be free from any spelling or
grammatical errors of any kind. Further, there should be uniformity across the
site when it comes to using British/American English.

5.3.7

Abbreviations/Acronyms, which may be typical in Government parlance and may
not be commonplace with citizens of diverse backgrounds should be avoided or
expanded at all possible places. At the same time, if a short form or abbreviation
of a term is more popularly known and understood by the citizens than even its
full form, the short form should be mentioned.

5.3.8

Whereever there is a change in the default language of the document e.g. Hindi
used in English document, these changes in the language of a document’s text
and any text equivalents (e.g., captions) MUST be clearly identified.

©2009,NIC

55

<!-- page 78 -->

CH 05

Quality Of Content

5.4
Consistent Terminology
Common look and feel in Government websites of any country helps in promoting the
brand image of the Government; raises user confidence; provides a user-friendly experience
in navigating Government websites; and organises information more consistently to
facilitate search. An integral part of the common look and feel strategy is the usage
of standard content terminology, positioning and framework. Usability Research has
established that using common terms and placement of content can help visitors locate
the information they want more quickly and conveniently.
5.4.1

Hence it is suggested that ‘Consistent Content Terminology and Positioning’
should be adopted by Government websites in India. This could act as a beginning
for adopting a larger view towards common look and feel of Indian Government
websites in the long run. If a certain ‘term’ has been presented in a particular
manner at one place in the website, it should be referred to in the same manner
at all places in the site.

5.4.2

Consistency in nomenclature MUST be maintained across a website and should
also be followed across all the websites owned by a State/Ministry.

For example
•

If a certain Government entity has been referred to as the ‘Department’
at one place in the site, it should not be mentioned as ‘organisation’ or
some other name at an alternative place in the same site.

•

In any application form, if the button to submit information after
filling up the form says ‘SUBMIT’ then it must say so across the
entire website. It should not happen that different terminology is used
in the same context at various places in a single website.

5.5
International Conventions
Web as a medium transcends all geographic and physical boundaries. Obviously therefore,
the target audience of every website could be multicultural with highly varied demographic
backgrounds. It should be ensured that the content of every Indian Government website
takes international and cultural conventions into account.

56

<!-- page 79 -->

Guidelines
for Indian Government Websites

5.5.1

Currency: The mention of Indian Currency should be uniform across any Indian
Government Website. As per international convention, any monetary value in
terms of Indian currency may be described as INR (Indian National Rupee).

5.5.2

Time: To mention timings in any context, the IST (Indian Standard Time) should
be used and if possible, the standard reference of with respect to the more widely
known internationally GMT (Greenwich Mean Time) may be mentioned.

5.5.3

Phone Numbers: The format for mentioning the phone numbers should be
according to international conventions (+Country Code – Area Code- Phone No.)
and uniform across all Indian Government websites. e.g. +91-11-24305364.

5.5.4

Date: the format for date across all pages of Indian Government websites should
to be dd/mm/yyyy to ensure uniformity.

5.5.5

Holidays: Holidays and Work Hours may vary between geographical areas and
cultures and hence the websites should provide and clarify information taking
into account the culturally specific terms. Time zone variations as well as workday
variations should be considered in this context.

5.5.6

Icons: Icons can be international symbols or may be culturally dependent. Icons
may be accompanied by text to assist by individuals who are not familiar
with the icons used, individuals traversing the Web by text, and persons with
visual impairment.

5.5.7

Hemispherical: Some references are hemispherically oriented. Winter means
something different in the northern hemisphere than it does in the southern
hemisphere. Equating seasons to months should be avoided. Note that references
such as “west” or “east” may be culture-or hemisphere-specific.

5.5.8

Postal/Physical Address: When presenting or collecting address information,
country, state and postal/pin code should be included. It is important to know
that postal codes across Countries vary in format, and validation code should
take this into consideration. It may be useful to collect Country, State or Postal/
PIN Code information before other information to minimise the user entry
required, although it may not be made compulsory as many users may not know
details such as PIN Code.

Though it is preferable to follow international convention, however if for some reason
there is a deviation the same should be highlighted in the ‘help’ section.

©2009,NIC

57

<!-- page 80 -->

CH 05

Quality Of Content

5.6
Information Architecture and Relationship
‘The world can be seen as only connections, nothing else? A piece of information is really only
defined by what it’s related to, and how it’s related. There really is little else to meaning. The
structure is everything.’ Tim Berners-Lee
Information Architecture is concerned with how information is organized, structured,
labelled, and presented for maximum access. The content of a Government website or
any website per se, has to be structured in such a way that the target audience is able to
access the desired information with minimum effort. For the same, it is imperative that the
information and services on the website are well organised and categorized into relevant
modules/sections and sub-sections so that any information can be located conveniently
and is not buried deep inside WebPages. Also the information structure, relationship
between the information and the meaning is maintained across all presentation styles.
The following guidelines are important to achieving the objective of well-organized
Information Architecture:

58

5.6.1

The objective of the Homepage of a website is always to allow the visitors to
locate the desired information in the easiest possible manner. Homepages must
be designed so as to prominently highlight the most requested information and
services. Further, the homepage should provide an easy-to- identify section where
the purpose of the website and the value to citizens is explained in terms they can
understand. Indian Government websites MUST ensure that all information,
which is of direct importance to the citizen, is accessible from the Homepage
itself. Incase the information cannot be displayed on the Homepage; it should be
ensured that it is available in not more than three clicks from the homepage.

5.6.2

Sighted users perceive structure and relationships through various visual cues
(page headings are in a larger & bold font; list items are preceded by a bullet;
form fields may be positioned as groups that share text labels; a different
background color may be used to indicate related items and so on). It must be
ensured that these information and relationships are preserved even when the
presentation format changes. (For example when the content is read by a screen
reader or CSS is turned off or replaced).Therefore departments MUST ensure
that Information, structure, and relationships conveyed through presentation
can be programmatically determined or are available in text.

5.6.3

When the sequence in which content is presented affects its meaning, a correct
reading sequence MUST be programmatically determined. This helps people
who rely on assistive technologies like screen readers because the meaning evident
