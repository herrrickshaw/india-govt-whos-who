---
doc_id: "ba9fcaf1db36b045"
source_url: "https://pdsmanipur.nic.in/media/filer_public/3d/e3/3de31354-3498-4483-8635-e12fbeaa3692/decb257deb6dd4462e2bd1dba2238150.pdf"
ministry: "Consumer Affairs, Food and Public Distribution Department, Manipur"
title: "Notification of post of Peon, Chowkidar, Picker, Sweeper of CAF&PD"
date: ""
pages: 2
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "e515e139dc9a2240"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
DIRECTORATE OF CONSUMER AFFAIRS, FOOD & PUBLIC DISTRIBUTION DEPARTMENT
aK
NOTIFICATION
Imphal, the 10" March, 2021
No. 1/DR/2019-DCAF&PD (6) : In pursuance of letter No. 1/1/2020-CAF&PD dated
27/01/2021 of the Department of Consumer Affairs, Food and Public Distribution, Government of
Manipur and as approved by State Cabinet in its meeting held on 19/12/2020, application is invited
from the intending and eligible candidates for direct recruitment of the following posts in this
Directorate of CAF&PD, on temporary basis through sponsorship of the employment exchange
concerned.
Name of No. of OBC | OBC Essential
4440 - 7440 +
Be > aa eee
4440 - 7440 +
2 রা রা
রাত রোযার
4440 -7440 + ্ নি
সপ fees fo LL [= আপ
4440 - 7440 +
2. Mode of Selection: Through written examination.
3. Examination Scheme:
FOR THE POST OF PEON, CHOWKIDAR, PICKER AND SWEEPER
|____Subjects_ [|Full Marks Time Allowed
General Knowledge
*Questions will be based on multiple choice questions (MCQs)
4. Tentative Timeline for the recruitment:
| 910০, [Particulars 10205
10"March, 2021
Date of requisition from Employment Exchange 10March, 2021
Last date of requisition from Employment Exchange 25™March, 2021
[ 4 _| Date of issue of forms (from website*) 10"March, 2021
Last date of form submission 3 April, 2021
|_6 [Jssueofadmitcard To beentfied later
Date of Written Examination To be notified later
5. Syllabus:
Important Days, Awards and Honours, Indian History, Indian National Movement,
Books and Authors, General Policy, Current Affairs — International, National and
General । না
Knowledge State of Manipur, Capitals of India, Indian Economy, International and National
8 Organisation, Science — Inventions & Discoveries, Science & Technology, Sports,
Abbreviations.
*Website for downloading Application Form: www.manipur.gov.in and www.pdsmanipur.nic.in
6. Age Limit: A candidate must have attained the age of 18 years and must not have attained the age
of 38 years on the 10"March, 2021 i.e., he/she must have been born not earlier than 11"March,
1983 and not later than 10"March, 2003. The permissible relaxation in upper age limit for different
categories is as under: te

<!-- page 2 -->

ae a
ইতি চে 75. eee ge
Note: The Date of Birth filled by the candidate in the application form must be the same as recorded
in his/her Matriculation Certificate issued by a recognised Board/Council of the State or Central
Government.

7. Eligibility Condition:

i. The candidate must be a citizen of India.

i. The candidate must be able to speak Manipuri or any of the tribal dialects of Manipur.

ii. The candidate must be a permanent resident of Manipur, provided that a candidate whose
parent(s) or any of his/her direct lineage are permanent residents of the State, with proper
documentary proof like enrolment in the electoral roll and birth certificate, will also be
eligible.

8. Submission of Application Form: The willing and eligible candidates should get their names
sponsored by the Employment Exchange concerned on or before 25"March, 2021. Thereafter, the
sponsored candidates should submit the duly filed-in application form along with the required self-
attested copies of certificates and mark sheets on or before 3 April, 2021 at the office of the
Directorate of Consumer Affairs, Food & Public Distribution, Manipur at Sangaiprou, Imphal West.
9. Application Fee: Candidates are required to pay application fee @ Rs. 500/- for UR/OBC and @ Rs.
250/-for SC/ST respectively at the time of submission of forms. Candidates applying for more than
one post will have to pay prescribed cost X number of post applied at the time of form submission.
10. General instructions:
a. Application fee is non-refundable and not transferable.
b. ‘NO OBJECTION CERTIFICATE’ from the present employer will be required if candidates are
serving in any Government Department or Public Sector Undertaking or Autonomous Body.
c. Application form not accompanied with prescribed fee or not submitted in the prescribed
format or incomplete in any respect will not be entertained.
d. Canvassing for the posts, in any form will be ground for disqualification.
৫০ 03. fou
(Ranjan Yumnam)
+ Director (CAF&PD), Manipur
Copy to:

1. The Secretary to the Hon’ble Chief Minister, Manipur.

2. The Staff Officer to Chief Secretary, Government of Manipur.

3. The PS to Commissioner (CAF&PD), Government of Manipur.

4. The Under Secretary (DP), Government of Manipur.

5. The Under Secretary (Finance), Government of Manipur.

6. The Director (IPR), Manipur - with a request to arrange for publishing the above notifications
for two alternative days only in at least 2 dailies preferably Poknapham (Manipuri)/Sangai
Express (English)and to submit the bills in Triplicate to the Directorate for early payment).

7. The Web Manager, Department of IT, Manipur for favour of uploading the Notification of
the Department on the Website.

8. The New Editor, AIR/DDK, Imphal for inclusion of the above notification in the news bulletin
for 2(two) alternative days.

9. Relevant file.
