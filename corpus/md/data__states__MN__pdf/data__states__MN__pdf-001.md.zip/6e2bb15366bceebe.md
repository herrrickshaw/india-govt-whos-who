---
doc_id: "6e2bb15366bceebe"
source_url: "https://planningmanipur.gov.in/media/filer_public/77/79/777996f8-3502-4099-8b73-afd7b20b8149/notification_refund_of_examination_fee_for_recruitment_of_ra.pdf"
ministry: "Planning Department, Manipur"
title: "Notification - Refund of Examination Fees"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "176f2087691a5df2"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
SECRETARIAT PLAN NING DEPARTM ENT

NOTIFICAIION
f mpnat,

tf,e OSec ember, 2024

No. PLG1-201 l6t2O1}-PLG-PLANNIG: Planning Department'searlier
Notification No. Ll57l20L5-Plg(ft-1) dated 27 .12.2019 for direct recruitment of
3 (three) posts of Research Assistant on regular basis and Notification No. PLGIzdtrctzozz-pte-PLANNlc dated 12.02.2024 for recruitment of 1 (one) post of
Research Assistant on contractual basis are hereby cancelled.

2.

Examination fee submitted before for both the notifications will be
refunded after submission of required documents as per the format enclosed as
Annexure-A, which is being uploaded in the Government Website, to the
Planning Department, Sanjenthong, Imphal West on or before 06'01'2025'

The recruitment process for 4 (four) Research Assistants (Group -'B)
inutt o" made through Manipur Public Service Commission on contractual basis
for a period of t (onL) year, which may be extended from time to time'

3.

Further, the age limit for the candidates who have already applied for
after
t'n" port oi n"rearch-Assistant in the earlier notifications shall be relaxed
submission of relevant documents'

4.

5.

This issues with the approval of competent authority'

N, l/h-lkar.^' Qa,

( N. Kulkarani Devi)Zl-4'>6lu
Director
Copy to:

1. Secretary to Chief Minister, Manipur'
i. i6n ofri."r to Chief Secretary (Planning), G-overnment of Manipur'

S. Sftciaf Secretary (Planning), Government of Manipur'
oit".t t (rD, Manipur wiiii a request to upload in the Government

+.

-

website.

Express' They are

S. in"tJitor, Huiyen Lanpao, Poknapham-and.Sangai
in triplicate may
i"qr"rt"O io iniet the'notification for 1(one) day. Bill
payment.
ri,i,irv u" furnished to the Director/planning for early

6. Notice Board (Planning Department)'
7. Guard file

<!-- page 2 -->

ANNEXURE.A

GOVERNMENT OF MAN]PUR
SECRETARTAT PLANNING DEPARTMENT

t
/

(For office use)

Sl. No

r
Research Assistant (RA)

1

Name of Post

2

Notification No. & date

3

Roll No./APPlication No.

4

Name of the aPPlicant

5

Address

6

General/OBC/SC/ST

7

Name of Bank & Branch

8

Account No.

9

IFSC code

Signature of aPPlicant

concelled Bdnk
Admi! cor!' il:u::!:bte' and
with
otong
NB: Duly filled'in lorm
office hour'
the Plonning Deportment during
to
b"
must
Chegue

'uo''ii'i

(For office use)
Sl. No. ......'......'."'

Received application on """"""""""""""'
Oepartment, Sanjenthong'

(date) at the office of Planning

lmphal West'

N,Kulto.^-t{,

Signature of receiver'
