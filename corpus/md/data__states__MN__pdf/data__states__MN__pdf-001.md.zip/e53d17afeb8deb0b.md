---
doc_id: "e53d17afeb8deb0b"
source_url: "https://www.phedmanipur.gov.in/wp-content/uploads/2024/11/Notification-26-Nov-2024-16-52-18.pdf"
ministry: "Public Health Engineering Department, Manipur"
title: "Notification-26-Nov-2024-16-52-18"
date: ""
pages: 1
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "318c93a86a243816"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
PUBLIC HEALTH ENGINEERING DEPARTMENT
KOK
NOTIFICATION.

Imphal, the 2601 November, 2024
No.CE/PHE/1-1(NG)/2024/ 2384 :in continuation to this Office Notification
No.CE/PHE/1-1(NG)/2024/2157 dated, 6" November, 2024, it is to notify that
the date for collection of offer of appointment from the Office of the undersigned
and submission of the same is hereby extended till 16.12.2024.

(Shan ao Vashumwo)
Chigf Engineer, PHED,
ovt. of Manipur.
Copy to:-
1. The Secretary to Chief Minister, Manipur.
2. The P.S to Minister (PHE), Manipur.
3. The S.O to Chief Secretary, Govt of Manipur.
4. The Secretary (PHE),Govt. of Manipur.
5. The Director of Information & Public Relations , Govt.of Manipur.
6. The Department website www.phedmanipur.gov.in
7. Notice Board.
8. Order Book.
9. FileConcerned.
