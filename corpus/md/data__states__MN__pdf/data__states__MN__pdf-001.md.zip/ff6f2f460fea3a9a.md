---
doc_id: "ff6f2f460fea3a9a"
source_url: "https://artnculturemanipur.mn.gov.in/media/filer_public/c7/fb/c7fb6cf1-daa3-4fb0-ad44-09c3ec941bcb/notification-for-recruitment-rules_1.pdf"
ministry: "Art and Culture Department, Manipur"
title: "- Notification for recruitment rules and posts"
date: ""
pages: 3
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "d4d0e36aaf0ae2e0"
---

<!-- page 1 -->

a a
GOVERNMENT OF MANIPUR
DIRECTORATE OF ART & CULTURE
o T 1 6
Imphal, the 11'" November, 2020

No. 1/3/2011-AC(R/R) : In pursuant to Letter No, 1/12/19-RR/DP dated 24 4-2019 of the
Department of DP, Govt. of Manipur, the Department of Art & Culture, Manipur hereby
publishes/uploads proposed Recruitment Rules/ Amendment of Recruitment Rules of the
following posts: 1) Curator & 2) Asstt. Curator of the INA Museum Cum Library, Moirang in the
Departmental Web site.

All stakeholders are invited to furnish feedback/comments/views/ modification at the
enclosed R/R of the said posts positively within 30 days from the date of publication of this

পি
ie
i (Neg. এ ingh )
7 a Director,
s Art & Culture, Manipur
৮:
&. ulture), Manipur ~ for kind information
aquest to upload the above notice in the
॥ 111651 L
23
AI
4 f
নি
2. এ
শী

<!-- page 2 -->

SS aE ES ০ a... aaa
M.P.S.C. FORM-8
RECRUITMENT RULES FOR THE POST OF ASSISTANT CURATOR, IN INA MUSEUM CUM LIBRARY,ARTS AND CULTURE
DEPARTMENT, MANIPUR
[ 1 Designation of post it Assistant Curator :
,2 No of post _ _ |1fone)
|3 Classification ___| Class-Il/Group-B (GAZETTED)
] 4 Scale of pay L-8(Pre-revised Grade Pay 4300) Pay Matrix under M.S(8.P) Rules 2019
|S | Whether selection or non: | Selection —__ : :
|. | selection post : |
6 | Age of direct recruits 38(thirty eight) years & below ( upper age limit is relaxable for
| | Govt.Servants appointed under the Govt. af Manipur to the extent
| of the period of continuous services put in the post/service and by
| | 5 years for SC/ST candidates and by 3 years for OBC candidates
| and a Govt servant who belongs to SC/ST/ OBC will get the facility
| admissible to a Govt-servant in addition to the relaxation
} ২ __| admissible to SC/ST/OBC candidates =
7 | Educational and other | ESSENTIAL:
qualification required for direct 1, 1” of 2” Class Master's Degree in
| recruits History/Archaeology/Heritage Management with
| Diploma in Museology from a recognised University
OR
| 2. tst or 2™ Class Master's Degree in Museology from a
recognised University
| DESIRABLE:
1. 2(two) years’ experience in Museum Establishment
2. __ Knowledge of Hind|,Manipuri and English.
Whether age & educational | N.A.
qualification prescribed for
ances in which MP AS required under MPSC ( Exemption from consultation)
Ng.Uttam Singh
Director
Art and Culture, Manipur
৮
কা

<!-- page 3 -->

M.P.S.C. FORM-8
NOTIFICATION 0. ..........+4৮০ শপ পিপাসা
RECRUITMENT RULES FOR THE POST OF CURATOR IN I.N.A. MUSEUM CUM LIBRARY,ARTS AND CULTUR
DEPARTMENT, MANIPUR
i | Designation of post Curator |
12 1০ of post 1 (one)
|3 Classification Class-I/Group-A (GAZETTED) |
}a Scale of pay 1-12 (Pre-revised Grade Pay 5400) Pay Matrix
| — under M.S(R.P) Rules 2019
15 Whether selection or non-selection post Selection
| |
16 | Age of direct recruits — NA — —_
? Educational and other qualification required | N.A.
| for direct recruits
} 1 ই = = = 4
8 Whether age & educational qualification NA.
| prescribed for direct recruits will apply in
| | case of promotees —_ |
|9___| Period of probation, ifany =| 2 (two) years _
| 10 | Method of recruitment whether by direct By promotion failing which by transfer on
| recruit or by promotion or by deputation.
deputation/transfer and percentage of the
vacancies to be filled by various methods = |
11 In case of recruitment by Promotion:
promotion/deputation/transfer grades from | Assistant Curator,
which promotion/deputation/transfer to be | I.N.A Museum cum Library,Moirang
} m 0৪. with (3)three years regular service in the grade
wo rendered after appointment thereto in a
] | :
i ‘ | = regular basis.
ly ৬
hy . Transfer on Deputation:
॥ ny An officer holding analogous post under
1 ta Central/State Govt.
i | (Period of deputation ordinarily not exceeding
| 3 years)
নী
stances in which MPSC is to be As required under MPSC ( Exemption from
d in making recruitment consultation) Regulation 1972 __
|
a -
' Ng.Uttam Singh
= 06500
Art and Culture, Manipur
iy
] টি
