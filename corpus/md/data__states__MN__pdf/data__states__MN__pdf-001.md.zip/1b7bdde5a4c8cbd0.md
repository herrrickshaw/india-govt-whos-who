---
doc_id: "1b7bdde5a4c8cbd0"
source_url: "https://cdn.s3waas.gov.in/s3c3c59e5f8b3e9753913f4d435b53c308/uploads/2026/10/17922094031913.pdf"
ministry: "Chandel"
title: "Notification regarding the Vahani Scholarship 2026 ~ Private Schools"
date: ""
pages: 1
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "2c88d2cb8746372b"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
OFFICE OF THE DEPUTY COMMISSIONER, CHANDEL |
No.36/ADP/7/(DC/CDL) Chandel, the 16" October, 2026 |
To
1. The Principal, St. Peter’s Hr. Sec. School, Monsang Pantha, Chandel. |
2. The Principal, St. Paul’s Hr. Sec. School, Liwachangning, Chandel.
3. The Principal, Anallon Christian Institute, Lambung, Chandel.
4. The Principal, St. Joseph’s Hr. Sec. School, Sugnu, Chandel.
5. The Principal, South East Manipur Hr. Sec. School, Kapaam (Komlathabi), Chandel.
Subject: Notification regarding the Vahani Scholarship 2026 — reg.
Sir/Madam, |
With reference to the letter cited above, I am to inform you that the Vahani Scholarship
Trust, New Delhi, has invited applications for the Vahani Scholarship 2026. The scholarship
provides full financial support, along with mentorship, career guidance and skill-development
programmes, to meritorious students from economically weaker families.
The eligibility criteria are as follows:
1. The applicant must be studying in Class 12 at present.
2. The applicant must have secured at least 85% marks in the Class 10 Board Examination.
3. The annual family income must be below 23 lakh.
4, Selection is based on individual merit.
5. The application is free of cost, and the last date for submission is 1 November 2026,
]
] Eligible students may apply online at https://www.vahanischolarship.com by clicking the
| “Apply Now" button. For any queries, the Trust may be contacted at
info@vahanischolarship.com.
You are, therefore, requested to kindly bring this information to the notice of all Class 12 |
students and their parents, so that eligible students may apply within the stipulated time.
This communication is issued solely to disseminate information about the scholarship.
Selection rests entirely with the Vahani Scholarship Trust, and neither the District
Administration nor this office has any role in it.
Yours faithfully,
| HQ
(Mamoni , LAS)
Deputy Commissioner, Chandel
| Deputy Commissioner
| Copy to: Chandel
1. Zonal Education Officer, Chandel
| 2. DIO, NIC, Chandel (For kind notification to the District NIC)
| 3. Relevant file
MO
