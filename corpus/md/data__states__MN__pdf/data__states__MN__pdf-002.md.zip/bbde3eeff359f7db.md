---
doc_id: "bbde3eeff359f7db"
source_url: "https://manipurminority.gov.in/wp-content/uploads/2025/08/Remedial-Coaching.pdf"
ministry: "Minority Affairs Department, Manipur"
title: "Click Here for the Notification and Application Form."
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1fc2d17b0bb02771"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

“6-MONTH REMEDIAL COACHING
UNDER CM’s LAIRIK HEIMINNASHI PROGRAMME”

Implemented by MOBEDS for classes VIII–X & XI -XII
Funded by Department of Minority Affairs, Govt. of Manipur

Photograph

Name of Coaching Centre (as per preference) :
1. ……………………………………..…………………….
2. …………………………………………………………...
3. ……………………………………………………………

Student Application Form
for Class …….…….
Sl. No. ………
1.

Name of the Student (In Capital Letters)

: ……………………………………………

2.

Date of Birth

: ……………………….…… (dd/mm/yy)

3.

Boys/Girls

: ……………………………………………

4.

Name of the Parents/Guardians

: ……………………………………………

5.

Occupation of Parents/Guardians

: ……………………………………………

6.

Parents Income per annum

: ……………………………………………

7.

Category (Minority)

: ……………………………………………

8.

Postal Address

: ……………………………………………
……………………………………………

9.

Mobile No. (Student) ………………….….. (Parents/Guardians) …….…...………...………...

10. Name of the Institution/School (Presently studying)

: …………..………………………

……………………………………………………………..…………...…………………………
11. Last exam passed

: ………………………………….

12. Present Class

: ………………………………….

13. Marks/Percentage secured in the Last Examination

: ………………………………….

I request you to admit me to the above course and I agree to abide by Rules and Regulations of the
institution/coaching centre.
Place
Date

:
:
Signature of the Parents/Guardians

Documents to be attached with Application From:
1. Aadhar xerox copy
2. Last Exam marks sheet xerox copy
3. Parents income certificate
4. Two passport size photograph.

Signature of the Student
