---
doc_id: "66d5adbcaa3a52c9"
source_url: "https://rcsmanipur.gov.in/wp-content/uploads/2020/04/RR.pdf"
ministry: "Co-operative Department, Manipur"
title: "Recruitment Rules of MSCU, Lamphelpat"
date: ""
pages: 18
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "dc5b98d820ba3953"
---

<!-- page 1 -->

ee
Ay 422
4 tas এটি a
7 ree ২১ 1.4 তি
{ a, nF Jjorn
রী (de a “Ae 4 th
No. 2/7/2018 ~ Coop(mscu) / (ae 4
GOVERNMENT OF MANIPUR
SECRETARIAT: COOPERATION DEPARTMENT
€ Imphal, the 16°" March, 2020.
To,
ঃ টিটি এগ
Cooperative Societies, Manipur.
Subject: Request for convey approval to the farming/amendment of Recruitment
Rules in respect of the Executive posts of Manipur State Cooperative
Union, Lamphelpat.
Sir,
1 am directed to refer to your letter No. N-Coop/17/MSCU(RR)/2020 dated
25/02/2020 on the above subject and convey approval of Government for inviting
comments/views which is to be kept in Public domain for 30 (thirty) days. Thereafter
proposed RRs, are to be referred to DP for concurrence.
You are, therefore requested kindly to take necessary action.
a Yours faithfully,
1266
(Henry Alemo Francis)
Under Secretary (Cooperation),
Government of Manipur
Copy to:
1. PS to Commissioner (Cooperation), Government of Manipur. ao ২৮৮
2. Guard file. ¢ 7
* wo
gre NX
ডি ২০ ৩৬
০১ ৩
wy ২. a
wf 9৮ ২০৬ ৬ |
এ ও SE

<!-- page 2 -->

‘ / ৬ নন
টু 10 FORAMENDMENT UE FLA, (a গা
£ ADOPTED MUSCLORM =
& + pROPOS DEPARTMENT
MENTS WHILE FORWARDING PROPOSAL TO তি 1১,
PORM TO BE FILLED BY THE APPOINTING AUTHORITY OF ০ om COMMISSION FOR AMENDING RECRUITMENT RULES OF
AS ADOPTED THE PRECRIBED TORM OF THE MANIPUR PUBLIC SEREIEE © en ;
po MANIPUR STATE COOPERATIVE UNION (MSCU) Thad Execative Olficer, Manipur State Cooperative Union |
| 1] Name of Post: Chiet Executive Otticer Cue = - 1
(এ... Sate Cooperative Union 1
} — = e Cooperative |
| | Name of Department/Society Manipur State Coop ; _ | j
(৯), 75 550782550৭) 1
017২২ ৯, ie 56077554102 |
2 | Relerence numberof previous RR yale et ne | 4
dated 180 Feb 201 ছু Reasons for Revision ০
নত ২টি “ised Provision Proposed
Col. | Provistonin the Approved Rules Reviser Proposed | /
No. e“ ৫ oo st
লা Post: Chiet Executive
1 Designation of Post: Chief Executive Officer Designation of Post Chi i
Otticer মিন fil
2 | NoofPost:1 No. of Post: 1 . 7 sification]
5 হন Pay :9300-34800+GP 5400 No pay rectific ৩
Seale “of Pay (Old) 5008-75-83500 (New) 9300- | ১০৪০০1৯৬93৩ 7য়!
34800+GP, found i
5400. However, it may be revised from time to time as রে
নাছ এ As classified according to
LN
| Age linnts 25-35 years (relax able up to 40 years in case a 555
of SC/ST. However 3 (three) years for OBC ae ডি
Method of Recruitment: By promotion. If there is no Method of Recruitment whether by direct | Deputation from 0০
promotional fill up the post shall be recruited In recruit or by promotion or by | Cooperation Department
direct recruitment, However, if there are no both deputation/transfer and percentage of | 1s required as and when
conditions for recruitment, there may be on the vacancies to be filled by various | no incumbents are found
deputation from Registrar Cooperative Societies, methods: By deputation or promotion, | for promotion or under
Govt .of Manipur until the post Is filled up by Direct the policy of the »po
or Promotion Recruitment Department <a
Educational and other qualification required for Educational and other qualification al necessary,
Direct/promotion recruits required for Direct/promotion recruits: | qualification are
1) Atleast graduate of a recognized University NA prescribed in the lower ner
2) Higher Diploma in Cooperative Management post of RR for promotion
from a recognized Institute/MBA..
3) S(five) years experience as an Employces in be )
Cooperative Educational line,
"৪ Period of Probation 2 years Period of Probation : 2 years [Nocomment—«d
Whether age & education qualification prescribed for | Whether age & education qualiication | No comment ‘
direct recruitment will apply in case of promotion: NO_ | prescribed for direct recruits will apply
নল in the case of promotes:
- NA.
Incase of recruitment by deputation /Promotion grades | in case of recruitment by deputation “Deputation from the |
from which deputation/promotion to be made : /Promotion grades from which Cooperation Department
« 1) Principal deputation/promotion to be made: By | 4s required as and wh ‘
2) Publicity Officer Deputation of Class Il Officer from a sina “ie :
4) Education Officer Registrar of Cooperative Societies or | M° Mcumbents are found ]
7 Promotion from Principal/Education | fF Promotion or under 1
» | Officer/publicity officer with 6 (six) the policy 0 00৫
|| ears regular servic fi ৮. De
Minimum Experience for promotion to thelr respective’ হর service Inthe grade. টিসি ২] আও
grades: S{five) years regularin serviceintheir 7 . be)
Fespective post as mentioned in Rule-No.9. ?
Whether postis selection or Non-selection: Whether sel *
Ifa DPC exist what is its composition: DPC Is to be Wa DPC "To ted
exist WI বাল =
constituted by the managing Body/Admlnistrator of | Composition ov a Serie ta karen ae bee ihe
the unton from time to time as per the rules of বগা as ০০০65208180 ৬2 | es Se: Govt
Manipur State Cooperative 00195, Govt, Rules sa ee the ealsting State | Rules with the approval
= es “ th'the approval of RCS to | of RCS" to the existing
5 ston! 91110 .
গনি agement | proposal
|__| Points to be inserted/replaced Inthe Proposed RR
আত NAS] ——
র্‌
Gircamst WEIS
consul et in we MPSC is to be | 706 MSCU is Apex Level
decision making, recruit: On the | Cooperative organization
at Managing | receiving — Grant-in-aid |
the gop einstrator of the Union with | from the State Govt. {
11৩৭ of Cooperation Department. |
০ 2
i te ae of the Depariene Name, Address & Telephone number
০৭ E : (রও with whom those proposal may be
- : 'scussed ifnevessary for clarification/early decision:

<!-- page 3 -->

০
y
i - >
SBE রাও 2 we .
782) চা
gRS eee ae 4
2 | ae Bil ৪]
251 bs 1
রহ? 2াহা ডর
et | 2°
weer | = |
3 |
3
23 ভা 29]
a ১ জর
৯৪2৩ 3 ই]
2237? | 3 >)
3332 - লা
Bees 3 =| 2H)
3223]  9300-34800with | = 3]
হু ই হর
2 ই 2| Gr.Pay 5400 1 | হু ক]
সবর
৪2 ও হাল 2585
হই 5] ss?
Reet *| সহ 5ি2
ছি 2 | ও
3332 | E284 |
ইহ টুই Z 2
৪2৪ > 2 -
Ss 21০
ইহ হু a@ 2
2220 £8 হু
হহ2ই। ] ee 5
822 3) | হু হর
শাহ | m1 Zz
B32 8) | নি
৪975.) =
e525 হাঁ হন 2৪৪
2255 | 288208 3
8225 B 2B Fs! EI
se | ইহ ই
5822 s ©) 2 z
Fee? ue iF FE
23 2 2১ টি = ==
255 223 2ুহুছুই পা
8225) z Seezeiits = 25
হত os §t2eci biz Ps’ oo oe:
g° 85) Z2e22F22F= = Fs
2 #3! 22523 22 255 = oe
2 gz 4 £2745 52 = হু
2 Be a ane =z দু
2. পা 4:৯৯ 3
é ও str = রঃ
2 6s ga/° a8 = :
2 FF == শা টি:
2 ইহ নও ৪৪৪ oi:
হু 55] AE | 4523 BS i:
a হস ua Se 8 |
ই. 23) | পরনন্রস্যেশ রী
i see ree 3 = 2. *
5 33] yes) 2883233 =
& a =| ge 52525939525 = £
a হই za Sa EBsa8a 29 B :
€ of} ze Seaere832 oS! =
g $2! 22! 5583৪৪253৪5] =
2 উই EB} | ২5552 হু byl
দি. হত 5} | 222228 | Pd
= $3) = i a | ee
₹ হও 2 38527525 চি
হু ডু Bai’ es
2 98 | Fags Pad a
2 3 Z এ £
Bee Bre ৪
তির 3
উদ হত হহকহ 5512 ইডি ছভহ 3
3 83 25252ই?2ত7* 2ম ৪২৪ a
2 গনি 252১৪ 2জু 59253 & বু
B 25] হই 8858 25748 ই 3
g FFI SETEESTE 25 Ss 9 ড
52] SEER 3 § E] 62 82 3 3
2 39) ইনু] ¢S BF 8) 3
y 88! 8225523 6) ®8 3 é 3
8 83! sate হু হা] | 32 SE ই
z= 25 228 & 36
ঙ হু 33) ₹£ 52 ইুহছ | Es gf ই
3 2 of FP Fes! | $2 38 §
2 7 oO হু =)
a z 8 3 ges) | $ 3
হু a বত] 5৭] |
z ০০০
নন & 3%) হহহছরহহ512 ses
se e হুই PETSLERE SEIN gz
= ই হী SERBZ ASE CS] gko
ez 5 Si] ই655ছুহ ছু দে
s = জি) সুই হই ইত ই) gaa
৩. = ডি Secs se নত Ze: হু
S as হি হু 558) পি 2 ৪
টি s 32 * হু sl রা: হু
8 5 3] ZE2° 2. é Zz
3 x ছি a5 1 এ
্ ~*~ বু = 1 z
ই হু হু; ২1৮৮ 5
হু ছু 8a) 25১৯৩5১ 3329] P
> হর ছা ই25ই5915) 28 a5 =
8 নে ইইইভুঁইী | 2255) =
3 * 2s ইউ ৪হহু। ase ছু
53 ইইউ 558 a
তা ও 28 স্ইইইই | 348 a
3 হও) 22252) | ga8 =
8 z বর See নি
ই হু ১৪৪ Es 5 3
~ z #s !] ag হু
ই চর 1] =

<!-- page 4 -->

ee
0.
ue amore Mest FORM= 10 FOR AMENDMENT 0684
| ] yniLe FORVARDING PROPOSAL TO THE DEPARTMENT
*O BE FILLED BY THE APPOINTING AUTHORITY OF vEPARTHENTS commission 702 AMENDING RECRUITMENT RULES OF Pp
A2OPTED THE PRECRIRED Font OF THE 11/71507 PUBLIC SERVIC! je
| oY 7UR STATE COOPERATIVE 01108 08500)
cipal, COM, Manipur State Cooperative Union
1777 তি ৮ লি 9০2
Name of Depariment/Society; "| Manipur tia MSCUS-Esd 22 THT)
j Reference number of previous RR | come ie
ed 16% Feb 2019
dated 4 Reasons for Revision
ised Provision Propose te
Provision In the Approved Rules | Bev! Proposed 1
haa টিন নাছ
সপ নট নন রর
i Designation of Post: Principal | fs ০014900 4
i No.ofPostp - তাপ TGP No pay জজ la
1 Scale of Pay (Old) 6500-200-10560 (new) 9300 34G00-GP. | Scale of Pay amendment order is ‘
4400. However, it may be revised fram time to ume as per | 4499 found
rules of the union 17755575-5 las sified according
i Classification of Post - Sealed লিজ Group -B to existing pay and GP
i To be replaced by col,
রি ‘Age limit: 25-35 years (relax able up to 40 yo irs in case of
/ SC/ST However 3 (three) years for ORC - = 7 for direct
/ (পল দা Proven Tar det
/ Promotional fillup the post shall be recruited in direct. | promotion delete
/ | Fecruitment. However, there are no both condiuons tor | -
a Fecruitment, there may be on deputation trom Registrar
Cooperative Societies, Govt of Manipur until the postis
filled up by Direct or Promotion Recruitment
7 Educational and other qualification required for | Educational and other qualificauon | All necessary
Direct/promotion recruits required for Direct/promction qualification ae
1) Atleast graduate of a recognized University recruits NA. prescribed in the
2) Higher Diploma in Cooperative Management lower post of RR for
from a recognized Institute 2
ও) 9946) years experience as an Employees in
Cooperative Educational line.
|__| Periodof Probation: 2 years" বদলান
Whether age & education qualification prescribed for direct | Whether age &  educauon | Nocomment
Fecruitment will apply in case of promotion: NO qualification prescribed for direct |
recruits will apply in the case of |
promotes:
NA _
In case of recruitment by deputation /Promovon grades | In case of recruitment by The incumbents
from which deputation/promotion to be made : deputation /Promotion grades holding the post are to
1)Vice-Principal fromwhich deputation/promotion be retired by
2) Assistant Education Officer. tobe made : | superannuation
3) Assistant Publicity Officer Vice principal /District ]
4)District Cooperative Education Officer Cooperative Education Ofscer |
5) Project Officer /Asst. Cooperative Education |
Officer with 5 (five) years regular |
service in the grade failing which |
10 years regular service as District |
Cooperative Education Officer |
(Asst. Cooperative Education
Officer/Vice Principal and |
Cooperative Education Instructor/ |
Instructor/Lady Cooperative
Education Instructor/Firm
Guidance Instructor taken together
‘Minimum Experience for promotion to their respective | To be removed
grades: 3(three) years regular in service in their respective
ost as mentioned in Rule-No.9.
Whether postis selection or Non-selecton = Whether selection post or Non=
Tfa DPC exist whatis ts composition: DPC is t be Mf a OPC exist what is its | The MSCU is Apex
Constituted by the managing Body/Adminisrator ofthe | composition Composition of DPC | Level Cooperative
union from time to time as per the Manipur State 's to be constituted as per the | organization receiving
Cooperative union. existing State Govt. Rules with | Grant-in-aid from the
the approval of RCS to the | State Govt
decision 91. Management
Body, MSCU
fi. 8৮1
Circumstances in which MPSC isto | The MSCU is Apex
be consulted in making recruit: On | Level Cooperative
the ‘decision of Managing | organization receiving
Body/Administrator of the Union | Grant-in-aid from the
with the approval of Cooperation | state Gove.
Department.

<!-- page 5 -->

oe Se
(5 7 2 এ
RSs BSREE Be
ইষ্ট
232i er ae
ইঃ & ছু পু
ইঃ টু :
বই a3 3
is uz
—_———— re Bz
a2 BE
১5৪০ a
3s 3 Se
a8 ag
Ee 52
2257
333s a
23 ; §
2838 9300-34800 with Gr.Pay 4400 3!
ages
৪৯৯
হই টয়
£282 হই
S223 Saha
ইইইও Basa] .
হই টুইওরী .
Bes Be 2
=) = a
28% = aa| ই
age gel হই
2258 ৪৪ 3
24s :
geese ie
esae 2
হই 5
2323
৪822 লা TTT
226 232 g
৪৪৪? হু ইহ ছটু 3
2252 a হুইই) ই
gags beg] 3 _
28 :
ই ৪৪
ই 9433
3 5 9 78775 lap হালে
fee হাই ?ইহইহনু ইহা FES
8225 >) \§8Sea8F88) 2545
Bass 2 শি 536
pas e2sceegag| 28৪
8° ছু টি ইহ৪ই৪ ই) 322
g 3s টি = a oe ০০ ¢
£ দুই ৭ ৪ “$38| Bio
ই £8 ই:
3 88 eer) 2::
ছু ৪৪ ছুঁই] =38| ৪:
রা R= Pes) S: :
2 2 5৪ gee; ২৯: :
3 z * এ foe
a EF a | 55] ক:
হই ই:
নি 2152 95৩8 S::
ee als) 2828888) 3:
2 ছুই 2 হইচ5ই855 ©:
a as # হই হই হ। 5:
a টু FF Saeaegea3 Bs
5 5৪ = ERSSES a0] w
ই is ছু 3322082 s
5 ES 3 g8e3282 নু
# 23 3 S8es8oi3
ছি ছু 2 gEzok°o8 ঢা
ges ই) $352 22
হু ছু) হুঁ ইহ ইহ |
68 3
ই 4 Seeregs
2 2% ZESSELSPESS ET ইছুইইইহই By
3 ছুই ছুই? 2৪৪৪3 8) ছু
নাক, হই ইইউ? RBS agcag 8 <
ঃ B 86s 11177517717 #5 28 ২ ৯
a হছে FF ৪৪8৪৪ 28টুইু? হু হু ও
a 38 ই2ট৪789852885592587 Se দুই ছা ছু
) 2 8] FIebisrerisga ees ge 83 ই 2
| g 8 5 < g ইহ? 282 ¢
ই 28] এইট S2S5h72ebszee 25 85 3\ 5
এ 2 88 See 83798 £5 °S558 Re $2 ই
হু টি গু BES দত SE ae = g 3
q 3 38| #2 23 z 3
ই 3 38 7
২ 8 58 FERSESEa SS 85
2 হু 8717 z
| ২২১ ই FE 388288858 228
eS & <3 হী ৪2৪552দুছ টুর
উই a ই ইইইহই ই 228 a
হ 88 882২৯ ইই ছু?
I ও ও #2 ই রুট ইনিই, ্
H > চু as af E =
} 8 38 33 রহ নি
3 2 ইহ <= g
: 8 2 রঃ রর
ই 73 32 pizesle 2889 =
= হত ভু 822৪5 ees ই
3 | gs e252 £235 E
i F SE ইইইইছ 23 gs |
i = = seaca 5৪ =
i মূ 2 SSeFa 583 3
ই ses 3 =>
3 ইস ইইইইও 285 E
$ 25 ৪৪১৯৪ ই 55 g
yy >to RES 2.
g ae so z
ই - ¢ ao
| ১ 3 2 8 g
g z FA
8

<!-- page 6 -->

সু
vate _<$<<$< if)
র .)015010101-10108481510101 0114
\- AvOrTEDM
- FORWARDING PROPOSAL TO THE DEPARTMENT 43,
ETS TE eee NG RECRUITMENT RULESOF MANIDIi}
/ ১২৭ 70 BE FILLED BY THE APPOINTING AUTHORITY OF DEPART 01390608411
ADOPTED THE PRECRIBED FORM OF THE MANIPUR PUBLIC SERVICE CO টি
STATE COOPERATIVE UNION (MscU ZFramipur State Cooperati ররর |
Name of Post: Publicity Officer, Publicity 07০ ee
ative Union
~/ Name of Department/Socieny > Manipur State CooPe 7 —|
নান
মনত ম5/5554/82 শি
জু eer
a নল
Col. | Provision in the Approved Rules Revised Provision ProPe
Pubheny Ofcer | |
st: Publicity Officer Designation of Post "OS
ইতি টানি OME [No.of Post: তিক No pay rectification] amendment
Scale of Pay (Old) 6500-200-10500 (New) 9300. | Scale of Pay : 9800" order is found
34800+GP, 4400. However, it may be revised from
Classification of Post - Scale-1 Group -B pay and GP
চে ভিন
০ তারা ০০০০০৬৪
case of SC/ST. However 3 (three) years for OBC - vision for direct recruit is
6 | Method of Recruitment: By promotion. Ifthere isno | Method of Recruitment whether by dir ad pic a ue
Promotional fill up the post shall be recruited in direct | recruit or by promotion oF Pe
recruitment. However, ifthere are no both conditions | deputation/transfer and percentage ০1 .
for recruitment, there may be on deputation from vacancies to be filled by various methods:
Registrar Cooperative Societies, Govt of Manipur until | 100% by promotion
the postis filled up by Direct or Promotion
Recruitment -
7 | Educational and other qualification required for Educational and other qualification au cnr রি one
Direct/promotion recruits: Tequired for Direct/promotion recruits | prescribed in the lower po:
1) Atleast graduate of a recognized University | -NA for promotion
2) Higher Diploma in Cooperative
Management from a recognized Institute, .
3) 50846) years experience as an Employees in
Cooperative Educational line.
4) Ability to translate from Hindi, English to
Manipuri even from Hindi to Manipur.
ই রন years io same
‘Whether age & education qualification prescribed for | Whether age & education qualification
direct recruitment will apply incase of promotion: | prescribed for direct recruits will apply in
| No the case of promotes:
NA
mn case of recruitment by deputation /Promouon Tn case of recruitment by deputation The incumbents holding the post
rades from which deputation/promotion to be made: | /Promotion grades from wich are to be retired by superannuation
1) District Cooperative Education Officer. deputation/promotion to be made :
| 2) Assistant publicity Officer, District Cooperative Education Officer
| 3) AE.O(Assistant Ecucation Officer) JAsst. Cooperative Education Officer /Vice
| 3 ভে Principal with § (five) years regular
| oe Sepa service in the grade failing which 10 years
| regular service as District Cooperative
| : - Education Officer /Asst. Cooperative
| Education Offcer/Vice Principal and
| Cooperative Education Instructor/
! Instructor/Lady Cooperative Education
Instructor/Firm Guidance Instructor taken
‘together
Minimum Experience for promotion to thelr To be removed
Fespective grades: 3(three) years regular in service in
their respective post as mentioned irtRule-No9.
Whether postis selection or Non-selection: ১
Selection Post. Post :NA
Wa DPC exist what is its composition: DPC is to be 11 a DPC exist what is its composition 7 | The MSCU 75 Apex Level
treated by the managing Body/Administrator of | Composition of DPC Is ta be বর Cooperative organization receiving
Reunion from time to time as per the ManipurState | as per the exlsting State cone Rules | Grant-in-aid from the State Govt
Cooperative union. with the approval of RCS to the decision
of Management Body, MSCU
বদ Tea The roped ৯৮৮৮৮
টি 5
এ Circumstances in which MPSC Is to Be] The MSCU is registered
consulted in making recruit: On the Cooperative Organization unde:
decision of Managing Body/Administrator | Mcs Act.1986 .
of the Union with the approval of
Cooperation Department.
ঃ ».
নি aay ofthe igs ‘sPresentative with whom those proposal may টস
৮ ৭৫৫ if necessary for clarfication/early decision,

<!-- page 7 -->

a চি
z 29 নর
নর 55292 23 By
88? ই ৪8৪]
cag SES 23
zak ag" a me
ga: Bo 2
ই “3 2
ce
38 =
ge ss £8
১5৪৮ 8
রিও
3
23 22
35 ae
23 22
ইন of
2232 =
v33u
2০৪ P 5%
হাই9৪ 9300-34800 with Gr.Pay 4400 =o)
৪৪১৪ as
gees
228
assy B28
fess Sane
g23 5388
8555 5255
ওত 5 £25255
Save oe
2485
e885 2 ga
238 3g 2
328s b চি] দি
aA 4 F ? gol 8
Sas #3| 3
es এ
Bests হই
হু হি
শর নু
§323 2
28390 ze
52৪5. a aSaeea| 2
2৪৪89 ৪828৪? টি
£3256 585 5৪দু &
esse “ S835) এ
রা oa”
gee ৪ 82 হল
4 ও 23
Bass লে 56 দুল
gees Base eeees| £& 2S
S225 ২692 852ু 2 EB
gees 292558528) ৪ Ears}
£ 28 g2G8e98s| 2 Fg
23 s2SR88 = 1
sé ৪ i 2
zg 38 o Be S8@|a : 6
§ 88 # i
a ইহ a we
£ 38 MN
হু 2 a4
z 5৪ EX er | ও ££
= 88 &e aod Si:
8 FF “6 gga) 2 5:
cad 30 চি স্ব 5০ চে হত
শর oS) হে 5
চি চা = iw ip
দি ie. 3
5 ze | av a £ শি
5 এ ৪ ge) 28288238) ই :
2 ছু ই £৪£5835 2] 2 :
&@ gs 22858283) ছু :
= চি হা 267855285 i
gs 28 3 RSRES I eo] 2
5 ae 3 ই5দুইহ হই হু
a ই ই ইইছিইুহ 81৪
& eo Hy 202 2
= 838 ই ইহ হর 8
ছি 33 "Rg of 3
a চু a টু
ই 8a A
3 28 বর ইড় ডু হল হু
25 &8 ZESTETESHSS 28 SE998% FSss30~< ৪
a asl ৪8888281857 ইইইই৪ £ু
3 8c 71777778247 259725 8| 5
টি ag BR2SEFLIS a8 eesgks ছা2 @2 6] লু
3 32 GRE SSES Sa SSEE SEES হই শুই গ ছু
৪ নু £ইইট ই 5 82 হা 8
5 9 Fi ekegsBcre FOES" g
g 88 SPE CP OPE Asa FOES Ss 88 ৪
ge: AgEE 5 2 ই
8 8s sen 83435 BELEEF 2 Se
e 2 28 GEE S8282 ছুই ইহ ই 258 বন্ধ 3
এ নি #83 2@§ 33338 ই Ses Se 32 8
g eo of ze? eee “2 গড 2s gs লু
8 ছু ৪৪ 53 a 48 & a 3 ৬
হু 275
g 2 হল
a8 g x8 25555286595 ess
ge e a8 Sh R52 3333 356
x & 3 Sas 8saF2ag Bes
FRY, ৪. $3 22252855258 2 =
gk হী নু হইহইই5ছ হও ই ছু ৪
a2 B°RS E58 g S
Pes Fs 322% 8 * 3 =
s § 9s a | নি
Py 2 5৪: 5৪ =
8 2 ৪ 25 ৯5৮১ আআ:
ই LE Bs উই ই হই =
= > Re ইইইইই 2222 >
€ of 3 23222 Hess =
ক" উজ ইভ ইস ই হই =
ঘর = ইইইকুহ 543 z
3 BS g2gés ২5 =
ও es ৯৪5৯৪ Bes 9
3 Fo 855 7. gS 5 3
3 goa oo
3 2 g
8 §

<!-- page 8 -->

ঢা
নি (M5
~
রর . MENDY
ADOPTLD MPSCJOBM 19 LOR AMENDMENT Gp 1,
।
YRWARDING PROPOSAL TO THE DEPAST MEN ॥
é RTMENTS WHILE FORWARE & +
FORM TO BE FILLED SY THE APPOINTING AUTHORITY OF DEPARTMENT DUMISSION FOR AMENDING RECRUITMENT frit ps oe
ADOPTED THE PRECRIBED FORM OF THE MANIPUR 08৮10 SERVICE C — a
MANIPUR STATE COOPERATIVE 11২10২18400 +55 Taran Officer, Manipur State Cooperative Umea =
[2.7] Name ct Post ] Cooperative Educats
j | | er নিল {
10) | ঘর
সি 1]. ive Un
| | চি | Manipur State Cooperate
৮ বির _|
১১) 52৪৮7) 7
[ই হকির
121 Reference number of previous RE | Neufication No. MSC
| | 1 dated ret Feb2010 or সির |
1 date a leasons for Revision Proposed
| Col Provision in the Approved Rules 1 Revised Provision Propos |
Le | i 1৮
1 চন = Cooperative Education
|) | Designation of Post: Cooperatwe Education Officer | Designation of Post Coop |
i ! Officer শ
Li মভজচতল No. তাত এপ লুল ই
{ TEP 4400 No pay rectification/ amendment
| > | Seale ef Pay (Old) 6500-200-10500 (New) SOO | Scale af Pay SIOOTIOOO-GP & সন |
| | 34800+GP. 4400. However, it may be revised from |
me to time as per rules of the union | |
৯  Glassificanon of Pon | AS classitied accordin, to existing:
5 কন [নিশি ৪
|5 উহা | ey ৮. 4
3 | ‘Age limit: 25-35 years (relax able up to 40 jeans a Tobe replaced by cola. 1
| case of SC/ST. However 3 (three) years for 980 it he a
© | Method of Recrunment: By prometion there wae | Method of Recruitment whether by direct | Proposed to omit the জল
Promotional fllup the post shall berecruited in | recruit of by promoten of by | recruit/deputation
direct recruitment. However, if there are no beth deputation/transfer and percentage of the
conditions for recruitment, there may be on vacances to be filled by vanous methods: |
deputation from Registrar Cooperative Socetes, | 100% by promotion |
Govt of Manipur until the post is filled up by Direct \
or Promotion Recruitment { রি "নী এ
৮ 7 Educational and other qualification required for ~ | Educational and ether qualiicanon required T All necessary qualification are |
Direct/promotion recruits | SF Direct/promonion recruits NA. Prescribed in the lower post of |
1) Atleast graduate of a recognized | RR for promotion ]
University | |
2) Higher Diploma in Cooperative | ]
Management from a recognized Institute. | )
| 3) Sffive) years expenence as an Employees | ]
| in Cooperative Educational !
{8 T Period of Probation = 2 vears Period of Probation 2 years No comment |
9 Whether age & education qualification prescribed Whether age & educanon qualification | No comment |
. for direct recruits will apply in the case of | Prescribed tor direct recruits wall apply in the |
Promotion: NO | case of promotes 1
| sa |
| 10 | Incase of recruitment by deputation /Promonon Incase of recruitment by deputation ‘The incumbents holding the past |
grades from which deputauon/promotion to be /Promouon grades from which are 09. ৮৭ 0৫৫৫ ৯৮)
| made: Geputation/promotion to be made sDastricy superannuation {
1 1) Vice- Principal Cooperanve Education Officer /Asst. i
2) Assistant P(ublicty Officer Cooperative Education Officer /Vice Principal 1
11598 Ecucation Officer) with 5 {tive) years regular service in the |
101৩6. Offic
Grade failing which 10 years regular service 1
্ tive Education
সিএস 6০০৮ Educatio | 4s District Cooperative Education Others
JAsst. Cooperative Education Officer/Vice
Principal and Cooperative Education
lnstructor/ Instructor/Lady Cooperative
Education Instructor/Firm Guidance
| Instructor taken together
11 1 Minumum Expenience far promotion to ther ৬০০৯৭ উর
fespective grades. 3(three) years regular in service |
sa their respective Post as Mentioned in Rule-No 9. ]
22] Whether post is eelection or Non-selection Minether' selection peat or Nanaclecton |
Selection Post. Post NA |
| | Wa ec exist wharigits compontom DPC be | Ho DPC exist what is is composition | The MSCU is Apex Level
0588 the managing Yody/Administrator of | Composition of DPC x to be constituted as | Cooperative organization
the union from ume ta time as per the Manipur | Per the eulsting State Gove. Rules with the | recening Grantin-atd from the
State Cooperanve union. | approval of RCS to the decision Of | State Gove
| Management Body. siscu ]
Points tobe inserted/replaced in the proposed |
RR
cry Age for direct recruits: NAL a ai
iT
ক which MPSC is to be | The MSCU ও registered
= আত, On the decision | Cooperative Organization under
| a on wath 0১৩1৯ of the | MCS Act.986
nton with the approval of Cooperati
: হি eration |
" ই ্ ofthe b, Name, Address & Telephone number
নি বি ্ : fig ‘epresentative with whom those Proposal may be
ই Faas} = : £ : Ste “Ssussed if necessary for clarification early decisiow.

<!-- page 9 -->

re
হর
ক্র £ :
£28 BS ES ES 28 ‘
ইইউ ইইউ 38
as SEBsso8 Baw i
2৪2৪ gs
22 Ba 88 ae
ga ef 73 2
as = a
5£
১৪5৪৮
Nest Be
Fe g°
নু Go
] 8৪. 7
ES
F353 " ag
2233 28
338s ৪৪
8323 abe
e823 9300-34! i
g Pe a 1800 with Gr.Pay 4400 2.
ইইই 3.49
5৪86 ie
arou ২
easy
s23a 3
ইঃ? 2985
ৃ gS55 রাজ
উই ও 582 থু
sage 2৪55] 2
2822 Brot] &
হট - F}
28৪5 3
bags হই) ৪
gees 2৪1 3
ইঃ Ee! 2
স্রাব হট
e228 a| &
হরর ও “| 3
Be
#252 3
e282 হাহ নহি ভ্হা Z
৪৪ দুই eReecs| 2
Hee ই হই] &
ই Ge °sgs2) প্র
হই দু 5৪5 tT
233 229
Bees 3 হা 8
১৪2 6 8
2o চে 5 ই
11: or e@ ওল
উই ওহ 2৪ নুন 22হ] BS FS
3°33 SeBgagERs B ৪9
3 এই 2০59৪585258. নর
৪ 38 29০হঈন2 ইন 8 $2
a 28 নিন ৪ হুক গুহ] ছু a2
3 93 22555225231 = : 2
£ 26 * ee "S88 mn : 3
Ps ই ৪ 535% :
3 ই 3 m » Oo
৪ ৪৪ Pi
2 ZF ছুই হু দু ::
Ss 3টি az ই হু :
& 33 ag Ses ad ছক
z ০ " :
g 38 sea) o 2:
Be 255] 3 tos
3 zs > ৩ 4 2
2
ই 3 - om &
+ হরগরহছহর Bo:
হু as ন <Ra83288) 3 iS
A BE z SSueaFeS a :
রই g saeegegga) = :
g 2 g 282282855] = :
৪ 23 3] | 2833388) 8
ধু হয
লা 5 2 হু Sack ]
gz 83 2 2 সুহ ৪ | 2
এ: 3 g228° 98 | 3
= 2৬. 8 g
= ৪2: “ess হব i
2 ছু z° 68 নি
2 Be ®
5 38 aos m “a a
a3 FUESTEPESSELEFEST FRE SRERBTS| 5
B ৪5. 223 SReeFL EBS as
ই 53 BRSRSES ree SEES SEES Baa 5 3
& 32 23৪2৯ 288 ক ss ef &| 2
2 2৪ 3s ছা ৪
৪8৪ PIGEE ১6288288527 28 ছুই a] &
¢ ই & 3 > হু এনু2ইছউ 5 £ু <
এ 2 28 ees ২1288 ৪ ag ৪] ৪
টা & 68 eee Seeag een 38 8 5
ছু 89 585 অই ছুই ছু ক্র #5 ৪৪ প্র ¢
২. 8 58] ই 28৪৪ ই Fees RE 3৪ ই] ই
হু 3 8 58 a3 a 78 ee 3g ই) §
aa টু ই ০ 3 লাল
হা 8 নু
225 কু AE BESSEee8S sss
=e ছু ্ 58৪22289559 শন
ই হু 288258585 286
করা 28 ES SSE Oe 258 টুর
gt হু ইহ টন
ই 3 94247 হল
Se 22 ইউর টি
a ৪ 83 দুল 2 §$ & 3
4 2 Be. a8 #
§ 12 36 - = z
& 2 88 é
5 :
ই ge gazeels agso 4
3 33 S528 gage =
= Bs 353 22 22 >
E হ 83 555 z
=e BFE a কহ
i Se অপ নদুহর ্ঁ
ই ৪8 gage gee 3
টু ই SSeS a8 হি
$ = pases 54a ৪.
3 #5 ইহ দি =
Hl zs ৪5২৪ 208 =
: Eee zee ই
টু gee £6 ৪
৪৯ ৪ as z
~ দই g

<!-- page 10 -->

fi . ~
॥ 1
x scorn 10 FORAMENDMENT.OEILR
. ARNG proposal. TO ‘THE DEPARTMENT AS.
/ ILE ‘i SOF
i ons 70 BE FILLED BY THE APPOINTING AUTHORITY OF DEPART ey OR AMENDING RECRUITMENT RULESOF MANIPUR
[ADOPTED THE PRECRIBED FORM OF THE MANIPUR pustic seRvIce COMM
Aanipur State Cooperative Union
STATE COOPERATIVE UNION (MSCU Fincation Officer,
wave Union
[৬] Wane of Department/Society = নত ০০০৭৭
Fst /82-83(P)
ReTerence number of previous RR মতন MCU? pa
fa sai
Dswict Cooperative
Designation of Post District Cooperative Designation of Post CY
[| Rioceononce টুর...
[Z| No.of Post:3 No. of Post:3 oP 4300 No pay
Seale of Pay (01d5500-175-9000 (New) 9300- Seal ofPay:900-34000 rectification/amendment order
34800+GP 4300. However, it may be revised is found
from time to time as per rules of the union As classified according to
— To be replaced by col. No. 14
‘Age limit: 25-38 years (relax able up to 40 years
55
0৪0 1 7
Method of Recruitment: By promotion, Ifthere is saanod of Recromment whether by direct Proven a ae recruit is
no promotional fill up the post hall be recruited | recruitor by promotion orby proposed to delete
Indirect reeruitment. However, ifthere are no | deputation/transter and percentage of the
both conditions for recruitment, there may be on | vacancies 10 be filled by various methods:
deputation from Registrar Cooperative Societies, 100% by promotion
Govtof Manipur until the posts filled up by
Direct or Promotion Recruitment
Educational and other qualification required for Eucationalandother qualification required | All necessaty qualification are
Direct/promocion recruits: for Direct/promation recruits :N-A. prescribed in the lower post of
1) Atleast graduate of a recognized RR for promotion and col No. 10
University preferably in
Economics/Commerce/BBA
Agricultural economic/Cooperation.
2) Higher Diploma in Cooperative
Management from a recognized
Institute...
3) _S{five) years experience as an
Employees in Cooperative Educational
line, training extension
Desirable:
a) Field experience work in a Co-
‘operative Institution/
Department in a responsible
position.
b) Trained in Junior Basic Course of
Cooperation of the Manipur
Cooperative Training
| [@ | Period of Probation : 2 years Period of Probation : 2 years CT
Whether age & education qualification Whether age & education qualification | Requisite qualification আও
prescribed fordirect recruits will apply inthe | preseribed for direct recruits will apply in the | inserted to the lower post and
tase of promotion Educational qualification | case of promotes other qualification are
shall apply butage shall be relax able as perthe | NA. mentioned in col-10
Rules and Regulations of MSCU.
crane of recruitment by deputation /Promotion | Incase of recruitment by deputation Same cadres are proposed to
grades from which deputation/promotion to be, | /Promotion grades from which include in the promotional line
made: deputation/promotion to be made :
1) Cooperative Education Instructor. Promotion: Cooperative Education
Instructor/ Instructor/Lady Cooperative
Education Instructor/Firm Guidance
Instructor who have passed Higher Diploma in
\ Cooperative Management (HDCM) with S
(five) years regular service in the grade
Ti) Minimum Experience for promotion to their লালে
respective grades: 5{five) years regular in
service in their respective post as mentioned in
Rule-No.9.lastructor,
Selection Post. :NA
13 | ifa DPC exist what is its composition: DPC is to Tf a DPC exist what is its composition :
| be constituted by the managing Composition of DPC Is to be constituted as জি ° se ak
\ Body/Administrator of the union from time to per the existing State Govt. Rules with the | receiving ceancinald tom the
ij time as per the Manipur State Cooperative union. | approval of RCS to the decision of | State Govt. °
q Management Body,MSCU
El el এটি |
হি [7771 ig For circ eres. 17
i Circumstances ॥। দা
] 4 consulted in making ee ডঃ de Pale es ee
pag Hsing: D0d} /Adainasirakie ct etapa! = Seah Organization under
ee with the approval of Cooperation Department. ৭995
5১38 ofthe Name, Address & Telephone number
১০525 ন্‌ ও Tepresentative with whom those proposal may be §
পুন eee! ee ders a Ps ক - femiecad Wnarseears far clarification (তা পাতা
