---
doc_id: "2c1ffaccee2c95e0"
source_url: "https://manipurhealthdirectorate.mn.gov.in/uploads/news/2026/08/03/Scan_20260803.pdf"
ministry: "Directorate of Health Services, Manipur"
title: "NOTIFICATION FOR 92 BATCH STATE ACCOUNTS TRAINING"
date: ""
pages: 2
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "16141d91ede4292d"
---

<!-- page 1 -->

TIME BOUND
GOVERNMENT OF MANIPUR
DIRECTORATE OF HEALTH SERVICES
MEMORANDUM

Imphal, the বেরা 2026
No. G(Trs)/2016-DHS(Pt.): All the CMOs/DDOs/HOOs are hereby informed to nominate
eligible Group-C employees under the following terms and conditions in the prescribed
Nomination Form (ANNEXURE-I) for undergoing 3% months 92™ Batch State Accounts
Training in the State Academy of Training, Takyelpat.
Terms & Condition:

1. Only regular Group-C Ministerial employees of the Government of Manipur may be
nominated for the State Accounts Training; or other than Group-C employees whose
Recruitment Rules specifically mentions passing of State Accounts Training as one of
the criteria for promotion.

2. Qualifying Service: Group-C Ministerial employees of the Government of Manipur
who have completed at least 2 years of regular service as on 21/08/2026.

3. Additional qualification required: Applicants should have passed the Office
Procedure Examination conducted by the State Academy of Training.

4. Special condition: Female candidates whose maternity leave is likely to fall during the
training period need not apply as their candidature will be rejected.

5. Candidates shall fill Annexure-I and submit the same with relevant documents to the
undersigned through the CMOs/DDOs/HoOs concerned latest by 4:30 p.m. of

18/08/2026 in Room No. 228 of this Directorate.
All the CMOs/DDOs/POs
Kate
(Dr. N. Henfantakumar Singh)
Director of Health Services, Manipur
Copy to:

1. Commissioner-cum-Secretary (Health & FW), Govt. of Manipur

2. All Heads of Office under Health Department.

3. Webmaster of the official website www.manipurhealthdirectorate.mn.gov.in for
uploading.

4. Guard file.

<!-- page 2 -->

Annexure-I to Memorandum No. G(Trs)/20 16-DHS(Pt.) dated 3" August, 2026
NOMINATION FORM
(92" BATCH STATE ACCOUNTS TRAINING)
1. Name of Candidate Lo ccusessecsuanuenscccesseceneseessssensnauuneasonsanasaneanseeeceens
(in capital letter)
3, Date of Appointment ররর nse nsassnane seers
4. — Present post held on 2,,০০০০০০০০০০০০০০০০০০১০০০১০০৭৮০০০১০০০৩০০০১১২০১১০০০০০০০০০৭৩৭৭৭৭০৭
substantive basis
5, Present place of posting :.....ssssessesseerersestererssnsesenenenanensesesnenensgsee ees 0
6. Educatjonal qualification ররর র্যা nts aeracmaneenees
7. — Date of passing O.P. with :.....ততত তাত
Order No. & date
(DD/MM/YYYY)
8. Mobile No ট্র্যাক বব
NOTES:

(i) All fields above are MANDATORY; nominations which has over-writing will be
rejected.

(i) Only regular Group "C" Ministerial employees of Government of Manipur are to be
nominated.

(iii) Duly self-attested photocopies of 1. Service ID Card; 2. Certificate of Educational
Qualification; 3. Appointment Order; 4.Result Sheet of Office Procedure
Examination; and 5. | passport Size photograph is to be enclosed.

Signature of Candidate with Date
1 certify that the statement given by এ
১.,,,,55০55555555555555555555008 true the best of my knowledge.
Signature of DoD/HoO
With Official Seal & date
