---
doc_id: "caef36e81fc4c5a3"
source_url: "https://manipureducation.gov.in/wp-content/uploads/2026/09/TET-2026-Notification-15.9.26.pdf"
ministry: "Education (School) Department, Manipur"
title: "Notification"
date: ""
pages: 1
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "d8bfdedf702eefaa"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
DIRECTORATE OF EDUCATION(S)
NOTIFICATION
Imphal, the 1511 September,2026
No.AO/272/TET/2022-DE(S)Pt-l:In continuation of this Directorate's Notification of even number
dated 28" August, 2026, regarding the conduct of the Teachers Eligibility Test (TET), 2026
(Paper-I and Paper-ll), it is hereby notified that the Directorate has reviewed the applications
accepted in the previous notification dated 28" August, 2026 and scrutinised and examined all
claims and objections of rejected applicants submitted within the prescribed timeline.
2. As a result of the review and scrutiny, 9601 applications for TET Paper-] and 15175
applications for TET Paper-ll have been accepted. 101 applications for TET Paper-l and 52
applications for TET Paper-ll have been accepted provisionally. The list of provisionally
accepted applicants for TET-| and TET-II are detailed at ANNEXURE-I and ANNEXURE-II
respectively. 875 applications for TET Paper-! and 319 applications for TET Paper-ll are
rejected. The list of rejected applicants for TET-I and TET-II are detailed at Annexure-Ill and
Annexure-lV respectively.
3. All eligible candidates shall require to exercise their preference for the district in which
they intend to appear for the TET, 2026, from among the districts in which examination centres
are proposed to be established.
4. Candidates shall exercise their district preference through the link provided in the official
website of the Directorate of Education (S), Government of Manipur,
Www.manipureducation.gov.in, or directly through the link www.tet2026manedus.com by logging
in with the registered mobile number used at the time of submission of the online application by
20'September, 2026.
5. Candidates who fail to exercise their district preference within the prescribed period shall
be allotted an examination centre on the basis of the district of their present address furnished
in the application form, subject to availability of examination centres or at the discretion of the
Department subject to other administrative considerations and prevailing faw-and-order
conditions.
6. Accepted PWD (Visually Impaired and Orthopedically Handicap) applicants who are
willing to avail the personal Scribe are to furnish duly filled-in “Declarations by the Candidate
and Scribe” appended herewith as ANNEXURE-V to the office of the undersigned on or before
20 September, 2026.
7. All eligible candidates shall be allowed to download their admit cards through the link
provided in the official website of the Directorate of Education (S), Government of Manipur,
www.manipureducation.gov.in, or directly through the link www.tet2026manedus.com, by
logging in with the registered mobile number used at the time of submission of the online
application with effect from 17** September, 2026.
৪. The candidates are advised to visit regularly the official website of the Directorate of
Education (S), Government of Manipur, for further notifications, instructions and updates relating
to the conduct of TET, 2026.
Director of Education-S, Manipur.

Copy to:

1, P.S to the Commissioner, Education(S), Government of Manipur.

2. Director, DIPR, Manipur

3. Additional Directors of Education/Schools, Manipur

4. Sr, Administrative Officer, He is requested to upload the notification in the Official website.

5. The Editor, Poknapham(M), NaharolgiThoudang(M), HuiyenLanpao(M), Sangai

Express(E), with a request to publish the above Notification for 1(one) day only as paid
item, Bill in duplicate may be submitted to the Directorate for early payment.
6. Relevant File.
QE Scanned with OKEN Scanner
