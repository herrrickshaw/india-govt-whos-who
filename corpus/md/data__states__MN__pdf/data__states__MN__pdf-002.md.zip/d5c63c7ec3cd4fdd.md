---
doc_id: "d5c63c7ec3cd4fdd"
source_url: "https://manireda.mn.gov.in/wp-content/uploads/2025/10/Corrigendum_III_for_JV_SASCI_SLS__SHTM_Projects1.pdf"
ministry: "Manipur Renewable Energy Development Agency (MANIREDA), Manipur"
title: "Click here to download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7757f2381cb80272"
---

<!-- page 1 -->

Office of the
MANIPUR RENEWABLE ENERGY DEVELOPMENT AGENCY (MANIREDA)
(An Autonomous Govt. Institute under the Power Department)

2nd Floor, South Block, Secured Office Complex, Near 2nd M.R. Gate, Imphal-Dimapur Road, Imphal-795001
CORRIGENDUM-III
Dated: Imphal, the 28th October, 2025

No.62/9/2025/SHM & SLS/SASCI/MANIREDA:
In
continuation
to
this
office
Notification of even No. dated 15/10/2025, 20/10/2025 and its corresponding uploaded
tender document vide NIB No. MANIREDA/SHM & SSL/SASCI/2025-26/20 dated:
06/10/2025, for ‘Design, manufacture, supply, erection, testing and commissioning of
i) 12,000 Nos. of Solar Street Lighting Systems at different districts of Manipur.
ii) 250 Nos. of High Solar Tower Mast at different District Hospitals, CHCs and different
Administrative Offices in Manipur.
including 5(Five) years Maintenance and Performance Warrantee Contract (MPWC),
response to the requisitions submitted by the contending bidders, The following clause is
amended as follows :
Sl.
No.
1

Clause # / Page
No.
CHAPTER No. – III
Page No. – 9
Clause No. – 9.1

Description as per NIB

Amended Clauses

The bidder should be a
Registered Company/ Firm/
Corporation in India with
supporting
documents.
Cumulative Experience of
the Bidders should be of
executing contracts of Solar
Street Lighting systems and
High Solar Tower Mast
(installed & commissioned)

The
bidder
should
be
a
Registered Company/ Firm/
Corporation/ System Integrator/
Joint Venture in India with
supporting
documents.
Cumulative Experience of the
Bidders should be of executing
contracts of Solar Street Lighting
systems and High Solar Tower
Mast (installed & commissioned)

All the contending firms are informed to keep updated for any further
information on the matter at the website www.manireda.mn.gov.in. Director / Member
Secretary, MANIREDA reserves the right to m o d i f y / cancel the Tender without assigning
any reason t h e r e o f or without bearing any liability, whatsoever, consequent upon such
decision.

Sd/(Dr. Shailesh Kumar Chourasia)
Director/ Member Secretary, MANIREDA
