---
doc_id: "2fde35ffe5e9badc"
source_url: "https://manipurhealthdirectorate.mn.gov.in/uploads/news/2026/06/09/Notification_reg_Examination_Centres_and_Roll_Number_Allocation.pdf"
ministry: "Directorate of Health Services, Manipur"
title: "Notification regarding Examination Centres and Roll Number Allocation"
date: ""
pages: 2
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "30079fb66f393c19"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
DIRECTORATE OF MEDICAL EDUCATION
NOTIFICATION
Imphal, the June, 2026
No. DME-10/1/2026-HEALTH: In continuation of this Directorate notification of even
number date 08-05-2026 and 01-06-2026, Entrance Examinations for admission to
various Nursing, Pharmacy & Allied and Healthcare courses for the academic session
2026-27 session will be held in the following Exam Centres:
a. Common Entrance Examination for B. Sc. Nursing, Pharmacy &
Allied and Healthcare Courses 2026
Name of Examination Centre Roll no. of Candidates
No.
Tamphasana Girls’ Higher Secondary School, Old 110001 — 110500
Lambulane Road, Imphal West
Ibotonsana Girls’ Higher Secondary School,
Ahanthem Leikai, Uripok, Imphal West
DM College of Science, Thangmeiband, Imphal 111001 — 111600
West
DM College of Commerce, Thangmeiband, 111601 - 112000
___| Imphal West
5 DM College of Arts, Thangmeiband, Imphal West 112001 — 112668,
Pie ot 130085 and 130115,
1° Churachandpur Medical College, Churachandpur 120001 — 120256,
120258 — 120411
St. Xavier’s College, Maram Khunou, Senapati 130001 — 130084,
130086 — 130114,
130116 — 130146
8 Elite Higher Secondary School, IB Road, 140001 — 140036 and |
___| Kangpokpi ____ 120257 |
b. Entrance Examination for ANM Course 2026
Name of Examination Centre Roll no. of Candidates
No.
DM College of Arts, Thangmeiband, Imphal West 210001 - 210228
2 Churachandpur Medical College, Churachandpur 220001 - 220033
Elite Higher Secondary School, IB Road,
Kangpokpi a
c. Entrance Examination for M. Sc. Course 2026
Sl. | Name of Examination Centre | Roll no. of Candidates
No. | |
1 [DM College of Arts, Thangmeiband, Imphal West 310001-310049 |
2. Churachandpur Medical College, Churachandpur 320001
3 _ 151১8৬19175 College, Maram Khunou, Senapati 330001 - 330002

<!-- page 2 -->

2. Written Test for the Entrance Examinations will be held as under:

SI. | Entrance Examination : ~| Date & Time of Examination
No.

Common Entrance Examination for B. Sc.
Nursing, Pharmacy & Allied and Healthcare (10 AM to 12 PM)
Courses 2026

2 PM to 4 PM
2026 2PM to 4 PM

3. Details of Scheme of Examination are available in this Directorate notification of
even number dated 08-05-2026.

4. Candidates shall compulsorily bring hard copies of Admit Cards along with any
valid Photo ID proof (e.g., Driving License, Aadhaar Card, Indian Passport,
Government Issued Photo ID, Voter ID, etc) for appearing in the examination.
Candidates without Admit Cards & valid Photo ID proofs SHALL NOT BE
ALLOWED to enter the examination centres.

5. Details & updates may be had from the official website
www.manipurhealthdirectorate.mn.gov.in or on Mobile no. 9366255065 (10 am to
5 pm on working days)

ont) Lae
(Somorjit Salam)
Director of Medical Education
Copy to:
1. Director General of Police, Manipur
2. Commissioner-cum-Secretary (Health & FW), Govt. of Manipur
3. Director, Health Services, Manipur
4. Members of the Selection Board concerned
5. Centre Supervisors of all examination centres
6. Guard File
