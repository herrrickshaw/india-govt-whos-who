---
doc_id: "3e7aed63d964fcce"
source_url: "https://dict.mizoram.gov.in/uploads/attachments/7bc0e6299bcb1ffd6263d131da4fd869/ex-396-allocation-of-business-rules-2019.pdf"
ministry: "Department of Information & Communication Technology, Manipur"
title: "Allocation of Business Rules, 2019"
date: ""
pages: 23
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "65af41f21236ef96"
---

<!-- page 1 -->

The Mizoram Gazette
EXTRA ORDINARY

Published by Authority
RNI No. 27009/1973
Postal Regn. No. NE-313(MZ) 2006-2008
VOL - XLVIII Aizawl, Thursday 20.6.2019 Jyaistha 30, S.E. 1941, Issue No. 396
NOT IFICAT ION
No.A-46013/1/2017-GAD, the 19 th June, 2019. In exercise of the powers conferred by sub-clause
(3) of article 166 of the Constitution and all other powers enabling him in that behalf and in pursuance of the
approval of the Council of Ministers on dt.10.6.2019 conveyed vide Memo No. J.11011/1/2019-POL/Vol-II
dt.13.6.2019, the Governor of Mizoram is pleased to make the following rules, namely:
1.

Short Title & Commencement.(1) These rules may be called the Government of Mizoram (Allocation of Business) Rules, 2019;
(2) They shall come into force at once.

2.

Definitions.In these Rules, unless the context otherwise requires –
(a) “Governor” means the Governor of Mizoram;
(b) “Council” means the Council of Ministers under Article 163 of the Constitution of India;
(c) “Government” means the Government of Mizoram;
(d) “Secretary” means Chief Secretary or any other officer who is in charge of a Department or
Departments of Government.
(e) “schedules” mean the Schedules of business of Departments appended to these rules.

3.

Allocation of Business to Departments.The entire Business of the Government shall be transacted in the Departments of the Government
as specified in the Schedules and shall be classified and distributed among these Departments as laid
down therein:
Provided that the Governor may, from time to time, make such additional to or modifications in
the list of business allotted to a Department.

4.

Allocation of Departments to Ministers.The Governor shall, on the advice of the Chief Minister, allocate to the Minister so much of the
business of the Government as relates to matters with respect to which the Council is required under
article 163 of the Constitution of India to aid and advise the Governor in the exercise of his function
and for that purpose assign one or more Departments to the charge of a Minister:
Provided that nothing in these rules shall prevent the assignment of one Department to the
charge of more than one Minister.

<!-- page 2 -->

Ex-396/2019
5.

-2-

Head of Department.There shall be a Secretary for each Department who shall be an official head of that Department.
Provided that –
(a) more than one Department may be placed in charge of the same Secretary;
(b) the work of a Department may be divided between two or more Secretaries.

6.

Repeal and Savings.The Government of Mizoram (Allocation of Business) Rules, 2014 is hereby repealed.
Notwithstanding such repeal, anything done or any action shall be deemed to have been done
or taken under the corresponding provision of these rules.

By order and in the name of the Governor
Biaktluanga,
Commissioner & Secretary to the Government of Mizoram,
General Administration Department.

<!-- page 3 -->

-3-

Ex-396/2019

FIRST SCHEDULE :
AGRICULT URE DEPART MENT
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.

Food-grain development – cereals, pulses etc.
Production and certification of quality seeds and planting materials. Implementation of Seed Act
1966 and Seed Control Order 1983.
Manures and fertilisers (organic, inorganic & bio-fertilizer) to be used in agriculture.
Plant protection of agricultural plants/crops and plant quarantine.
Development of commercial crops like sugarcane and other crops which are not under other
Departments. Mission Organic Value Chain Development for North Eastern Region.
Agriculture extension and farmers training.
Crop insurance - implementation of Pradhan Mantri Fasal Bima Yojana (PMFBY).
Oil palm and oilseeds development.
Agriculture research and extension.
Soil survey and land use planning.
Agricultural machineries, tools & post-harvest management.
Implementation of the Mizoram Agriculture Produce Marketing Act, 2008 and regulation, management
of jhum cultivation.
Organic farming for agricultural crops (development, promotion and certification).
Soil health management and soil testing for agricultural crops.
NLUP related residual works.
SECOND SCHEDULE :
ANIMAL HUSBANDRY & VETERINARY DEPARTMENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.

12.

Animal husbandry and veterinary extension.
Regulation of veterinary polyclinic, hospitals, dispensaries and small animal clinics.
Animal feed and quality control.
Livestock census and integrated sample survey.
Development of poultry, piggery, mithun and cattle, goat and sheep.
Matters relating to State Poultry Association, Federation and other organisations.
Livestock insurance.
Development of grazing ground & pasture, grassland silvi-pasture development.
Slaughter house and meat processing plant.
Biogas development.
Administration of the following Acts:
i.
Prevention & Control of Contagious & Infectious Diseases Act, 2006.
ii.
Mizoram Veterinary Council Act.
iii.
The Prevention of Cruelty to Animal Act, 1960.
iv.
Mizoram Animal Slaughter Act, 2013.
Marketing of livestock and livestock products.
THIRD SCHEDULE :
ART & CULT URE DEPARTMENT

1.
2.
3.

Matters relating to Mizo history, art and culture.
Conservation and preservation of cultural heritage in Mizoram. Exhibition, exchange and exposure to
the heritages in and outside Mizoram.
Museums.

<!-- page 4 -->

Ex-396/2019
4.
5.
6.
7.
8.
9.
10.

-4-

Archives.
Library services.
Music & fine arts and related subjects.
Tribal Research.
Mizoram Publication Board.
Archaeology.
Organization of cultural festivals.
FOURTH SCHEDULE :
COMMERCE & INDUSTRIES DEPARTMENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30.

Establishment of major and minor industries.
Registration, regulation and inspection of industries/factories.
Industrial loan.
Allotment of raw materials.
Development of industrial areas.
Cottage industries.
Handicraft schemes.
Handloom development schemes.
Handmade paper mills.
Physical infrastructure for electronics industries in association with I&CT Department.
Development of textile industries.
Recycling of used plastics & metal scraps.
Food processing.
Ground water/hydro-geological survey/investigation and development.
Geo-technical survey and investigation including foundation studies of buildings, bridges and dams,
etc. formation cutting/excavation for developmental works.
Landslides and Geo-disaster studies, mitigation and remedial measures.
Mineral investigation and mapping, development and administration under the Mizoram Minor Minerals
Concession Rules, 2000.
Oil and natural gas and other major minerals.
Matters relating to inspecting, exploration and production of major and minor minerals.
Seismological studies and earthquake related issues.
Promotion and regulation of trade and commerce subject to provision of entry 33 of list in the 7th
Schedule of the Constitution.
Trading by Non-Tribal (Regulation) Act, 1974 and Rules thereunder.
Border trades.
Regulated markets and market yards.
Village market.
Inter-state trade.
Collection of toll taxes on roads/ bridges connecting India and foreign countries.
The Competition Act, 2002.
Export strategy of the State.
Price regulation of meat, vegetables, cereals.
FIFTH SCHEDULE :
COOPERATION DEPART MENT

1.

Promotion of cooperative movement.

<!-- page 5 -->

-52.
3.
4.
5.

Ex-396/2019

Registration and regulation of primary, district and state level Co-operative Societies/Credit Societies.
Price control through Co-operative Societies/Credit Societies.
Strengthening of cooperative credit structure through Credit Cooperative Societies.
Cooperative education, training, audit and inspection.
SIXTH SCHEDULE :
DISASTER MANAGEMENT & REHABILITATION DEPARTMENT

1.
2.
3.

Natural and man-made disaster.
Gratuitous relief.
Disaster Management:i.
Prevention of danger or threat of any disaster.
ii.
Mitigation or reduction of risk of any disaster or its severity or consequences.
iii.
Capacity-building.
iv.
Preparedness to deal with any disaster.
v.
Prompt response to any threatening disaster situation or disaster.
vi.
Assessing the severity or magnitude of effects of any disaster.
vii. Relief & rehabilitation.
viii. Planning, organising and coordinating with all Govt. departments and other stakeholders in
disaster management.
ix.
Post disaster management and reconstruction.
x.
Response to disaster.
SEVENTH SCHEDULE :
DISTRICT COUNCIL & MINORITY AFFAIRS DEPARTMENT

1.
2.
3.
4.

5.
6.

All matters relating to Sixth Schedule to the Constitution of India and functioning of the District
Councils in the Sixth Schedule areas.
Grants-in-aid to Autonomous District Council.
Monitoring of developmental works taken up by District Council.
Matters relating to minority communities, including:
i.
Overall policy, planning, coordination, evaluation and review of regulatory and development of
minority communities.
ii.
Matters relating to National Commission for minority communities.
iii.
Protection of places of worship of minority communities including burial ground, crematorium.
iv.
Representation of minority communities.
v.
Formulation of measures relating to the protection of minority communities and their security
in consultation with other concerned agencies.
vi.
Prime Minister’s 15-Point Programme for Welfare of Minorities.
vii. Any other issues pertaining to minority communities.
viii. All matters relating to funding of minorities except those specifically allotted to other
Departments.
ix.
Matter pertaining to socio-economic, cultural and educational status of minority communities.
x.
Funding of programmes and projects for the welfare of minority communities including MsDP.
xi.
Preservation of place of worship of minority communities including burial ground, crematorium.
The Waqf Act, 1995 (43 of 1995) and matters connected thereto.
Presidential Orders on SC&ST.

<!-- page 6 -->

Ex-396/2019

-6-

EIGHTH SCHEDULE :
ENVIRONMENT, FORESTS & CLIMATE CHANGE DEPARTMENT
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.

Environment and climate change.
Environmental Act & Rules.
Conservation, protection & development of forests, environment and wildlife.
Forests Policy, Acts & Rules.
Reserved forests, protected forests, village supply & safety reserve, community reserve/forests.
Biodiversity Acts and Rules.
Forest fire.
Afforestation and re-afforestation including tree felling.
Regulation and control of fishing in reserved forest.
Tiger reserves, national parks, wildlife sanctuaries, zoological parks and botanical parks.
Clearances for extraction of stone and sand from reserved forest/notified areas.
Non-timber Forest Produce (NTFP) including medicinal and aromatic plants & their marketing.
Minor forest produce & marketing.
Wetland management.
Conservation of rare & threatened flora and fauna.
Mizoram Pollution Control Board.
Wood based industries/saw mills.
Carbon economy & carbon trading.
Save Chite Lui Co-ordination Committee.
NINTH SCHEDULE :
EXCISE & NARCOT ICS DEPARTMENT

1.
2.
3.
4.
5.
6.
7.

Policy on Excise and Narcotics.
Mizoram Excise Act, 1973 & Rules, 1983.
Matters relating to Narcotic Drugs & Psychotropic Substances Act, 1985.
All matters connected with licensing, distribution and regulation of liquors.
All matters pertaining to Acts and Rules relating to Liquor Prohibition in Mizoram.
Co-operation and coordination with NGO’s on excise and narcotics policy.
The Mizoram Drugs (Controlled Substances) Act, 2016.
TENTH SCHEDULE :
FINANCE DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.

Financial powers and delegation thereof.
Revisions of pay & allowances.
General Financial Rules & Treasury Rules.
Embezzlement and other financial irregularities in public finance.
Rules relating to pay, allowance and travelling allowance.
Write off of loss.
Pre-audit and arrear claims.
Matters relating to Treasuries.
Rules relating to security deposits.
Cadre control for MFAS & MSFAS.
General advice on financial aspects of Service Rules etc.
Rules relating to grants-in-aid.

<!-- page 7 -->

-713.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.
36.
37.
38.
39.
40.
41.
42.
43.

All budgetary matters including control of expenditure.
Internal Audit and Audit of Local Funds.
Bank/Development of Bank in Mizoram.
Pension. Authorization of pension, DCRG etc., communication thereof.
Departmentalization of Accounts.
Lottery/IF&SL.
General insurance and insurance schemes of Govt. servants.
Discretionary Grants Rules and procedures.
Authorization of entitlement of Group A & B Officers of Mizoram Government Employees.
Rules relating to advances to government servants.
Matters relating to fiscal policy and public finance.
The Mizoram Transparency in Public Procurement Act, 2008 and Rules thereof.
State Finance Commission of Mizoram.
The Mizoram Public Demand Recovery Act & Rules, 2004.
Budget speech of Finance Minister.
State borrowings and debt management.
State Government Guarantees.
Management of cash balances.
Management of public accounts, including GPF, GIS, civil deposits, remittances, etc.
Policies and guidelines relating to procurement of goods, works and services.
Fixation of rent rates for accommodation of Government offices/purposes.
Administrative Approval for all new works/projects.
Expenditure sanction of fund beyond the delegated financial power.
Financial management including standardization/computerisation of Treasuries.
Public Expenditure reforms including Public Sector Undertakings/ Local Bodies under State
Government.
Mizoram Protection of Interest of Depositors (In Financial Establishment) Act, 2002.
Matters relating to engagement of consultancy firms.
Matters relating to public accounts-deposits & advances.
Framing of rules/procedures pertaining to medical re-imbursement.
All matters relating to Externally Aided Projects, and all other Loan Projects.
Allocation of State Matching Share.
ELEVENTH SCHEDULE :
FISHERIES DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.

Ex-396/2019

Fisheries research and education.
Fish production under culture and capture section
Conservation, regulation, control & management of riverine fisheries.
Control & management of fish health and hygiene.
Development of pond/tank by assistance to fish farmers.
Extension & training of fish farmers.
Enforcement of the Mizoram Fisheries Acts & Rules, etc.
Integrated fish farming.
Management and production of quality fish in Government Fish Seed Farm.
Marketing, preservation, processing and quality control of fish in the State.
Conservation & management of reservoir fisheries.
Culture of fish, prawn, crab, snail and ornamental fish.
Registration of fish farmers.

<!-- page 8 -->

Ex-396/2019
14.
15.
16.

-8-

Certification and registration of private fish seed farm.
Propagation, conservation and culture of indigenous fishes.
Procurement and distribution of essential fish farm inputs to the fish farmers.
TWELFTH SCHEDULE :
FOOD, CIVIL SUPPLIES & CONSUMER AFFAIRS DEPARTMENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.

Food and civil supplies.
Essential Commodities Act.
Price control and rationing.
Inter-State movement permits of food-stuff.
Warehouse for public distribution system.
Control, distribution and regulation of LPG.
Control, distribution and regulation of POL and its products.
Quality control, distribution and regulation of essential commodities.
Consumer affairs - Consumer protection including Mizoram State Consumer Disputes Redressal and
District Forum.
Legal Metrology.
Standards of weights and measures.
Bureau of Indian Standard related matters.
Implementation of NFSA including Constitution of Grievance Redressal Mechanism.
Test and re-calibration of water meter.
THIRTEENTH SCHEDULE :
GENERAL ADMINISTRAT ION DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.

Transaction/Allocation of Business under Government of Mizoram.
District administration.
Mizoram Houses and offices outside Mizoram.
State Guest House, Circuit House and Dak Bungalow/Rest House.
Air travel permission
Allotment, maintenance and furnishing of General Pool Government Quarters.
Annual Administration Report.
Aviation.
Regulation of flying drones/Unmanned Aerial Vehicles (UAVs) and the Licensing Authority for Drones/
UAVs.
Census.
Ceremonial functions including celebration of Republic Day/Independence Day.
Creation of district and sub-division.
Creation, reorganization and amalgamation of Department(s).
Determination of ceremonial procedure and precedence.
District Development Committee/Board except Lunglei HPC.
Entitlement of space, furniture and office equipment.
Official entitlements (e.g., accommodation, telephones, vehicles, foreign tours, air travel)
Entitlement/Purchase of Govt. vehicles.
Matters relating to National Flag, National Emblem, National Anthem and State Emblem.
Foreign tours/travel.
Hiring of private building for office accommodation.
Holiday.

<!-- page 9 -->

-923.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.

Ex-396/2019

Protocol and Hospitality.
Requisition of helicopter and matters relating to helipad. Air communication between Mizoram and
other places.
Sinlung Hills Council and Sialkal Range Development Council.
Government complexes at various places.
Special Casual Leave.
Statues and memorials.
All matter pertaining to elections, including State Election Commission.
State Mourning and Obituary.
Mizoram State Information Commission.
Co-ordination relating to UID.
Subjects not allocated to any Department.
FOURTEENTH SCHEDULE :
HEALT H & FAMILY WELFARE DEPARTMENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.

Administration of Government hospitals and health centers.
Drugs control Acts.
Implementation of national and State health schemes/ programmes.
Medical services.
Indian Lunacy Act, 1912.
Matters relating to Indian Medical Council/State Medical Council/State Nursing Council.
Health education/research schemes.
Mizoram Health Care Scheme.
Medical & Nursing Colleges/Institutions.
State Illness Assistance Fund.
Telemedicine.
State Council for Clinical Establishment Act, 2010.
Pre-conception and Pre-natal Diagnostics Techniques Act & Rules.
Transplantation of Human Organs Act, 1994 and Rules.
Matters relating to Medical Attendance Rules other than Framing of Rules/ Procedure pertaining to
Medical Reimbursement.
State Medicinal Plant Board.
Restriction of sale of acids.
The Poisons Act, 1919 and Model Poisons Possession and Sale Rules, 2013.
National population policy.
Food Safety and Standard Act, 2006/Rules.
AYUSH and National AYUSH Mission (NAM)
Bio-medical waste management.
Family welfare.
FIFTEENTH SCHEDULE :
HIGHER & TECHNICAL EDUCATION DEPARTMENT

1.
2.
3.
4.
5.

University / Post Graduate education.
College /Under Graduate education.
Centrally sponsored schemes of Government of India (RUSA).
Mizoram Scholarship Board.
All matters concerning education scholarships and incentives.

<!-- page 10 -->

Ex-396/2019
6.
7.
8.

- 10 -

Technical Education:
a)
Mizoram State Council for Technical Education (MSCTE).
b)
Conduct of professional and technical entrance examination and allotment of seats of Mizoram quota.
State Technical Entrance Examination (STEE).
Unnat Bharat Abhiyan.
SIXTEENTH SCHEDULE :
HOME DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.

18.
19.
20.
21.
22.
23.
24.

Law & order.
Security arrangement, security architecture and infrastructure.
Acts, Rules relating to Police.
Home Guards and Civil Defense.
All matters relating to foreigners.
Administration of Arms Act and matters relating thereto.
Fire & Emergency Services.
Sainik Welfare & Resettlement, SS&A Board and other matters relating to Ex-Servicemen.
Compensation to political sufferers.
Nationality, Passport, Citizenship, etc.
National Security Act 1980, Unlawful Activities (Prevention) Act, 1967.
Prisons Act 1894, Prisoners Act, 1900 and Administration of Prisons.
Explosives Act, 1884 and matters relating thereto.
Mizoram Essential Services Maintenance Act, 1990.
Inner Line Regulation and connected issues.
Matters relating to international/interstate boundaries and border management.
General matters relating to Scheduled Castes/ Scheduled Tribes.
EXPLANATION: The term “General matters” relating to SCs/STs under Sl.17 may constitute the
following:
i.
Overall policy, planning, coordination, evaluation and review of regulatory and development of
SCs/STs.
ii.
All matters relating to Law & Order relating to SCs/STs/MCs.
iii.
Policy initiative for SCs/STs/MCs and their security.
iv.
Matters relating to Linguistic Minorities in the State.
v.
Matters relating to National Commission for SCs/STs
vi.
Representation of SCs/STs
vii. Protection of Places of Worship of SCs/STs
viii. Formulation of measures relating to the protection of STs/SCs and their security in consultation
with other concerned agencies.
ix.
Prime Minister’s 15-Point Programme for Welfare of SCs/STs
x.
Enforcement of SCs/STs (Prevention of Atrocities) Act, 1989 and Rules thereof.
xi.
Any other issues pertaining to SCs/STs.
National Awards like Padma Shri etc., Governor Awards, etc.
Intelligence matters.
Civil-Military liaison.
Relocation of Assam Rifles Complex at Zokhawsang, and connected matters.
Human Rights, State Human Rights Commission and connected matters.
Declaration of restricted/protected areas for security purpose.
The Mizoram Scheduled Tribes and Scheduled Castes (Regulation of Issuance and Verification of)
Community Certificates Act, 2014.

<!-- page 11 -->

- 11 25.
26.
27.
28.
29.
30.
31.
32.

Ex-396/2019

Traffic management.
Forensic Science Laboratory.
Regulation of private security agencies.
Regulation of private placement agencies.
Other Backward Classes.
Prohibition of beggary.
Forensic Science Services.
Investiture of Executive Magisterial Powers.
SEVENTEENTH SCHEDULE :
HORT ICULT URE DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.

Aromatic plant development.
Tree borne oilseeds.
Spices & condiments development.
Floriculture development.
Medicinal plant development.
Manures & fertilizers to be used in horticulture.
Mushroom development.
Bee keeping.
Plantation crops of horticulture crops.
Root and tuber crops.
Spices and condiments development.
Tea plantation.
Chillies, turmeric, onion and vegetable development.
Plant Protection of Horticultural Crops.
Horticulture Machineries & Implements.
Creation of Water Sources & Micro-Irrigation.
Protected and precision farming.
Organic farming in horticulture.
Post-harvest management.
Implementation of Nursery Registration Act, 1992 & Rules.
Horticulture marketing.
Horticulture crop insurance.
Horticulture extension, research, education & training.
Horticulture Centre & production of quality seeds & planting materials.
Bamboo cultivation / development.
EIGHTEENTH SCHEDULE :
INFORMATION & COMMUNICATION TECHNOLOGY DEPART MENT

1.
2.
3.
4.
5.

Policy matters relating to electronics, information technology, and communication technology.
Cyber laws, cyber security, The Information Technology Act, 2000 and Rules and other IT related laws.
Promotion of electronics, including internet; IT and IT enabled services; digital transactions including
digital payments.
Promotion of electronics design and manufacturing, hardware/software industry including knowledge
based enterprise, etc.
Promotion of standardization, testing and quality in IT and standardization of procedure for IT
application and tasks.

<!-- page 12 -->

Ex-396/2019
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.

- 12 -

Assistance to other Departments in the promotion of e-Governance, e-Commerce, e-Medicine, eInfrastructure, etc.
Promotion of information technology education and information technology based education, digital
literacy, etc.
Coordination of information technology related matters with national and international agencies, bodies
and institutions relating to information & communication technology.
Control and regulation of internet service provider within the State.
IT related public sector undertakings and societies.
Technical matters relating to Unique Identification (UID).
Communication towers.
Infrastructure development for electronics; IT and telecommunication including internet.
Streamlining procedure and Issue of NOC for procurement of hardware and software including
software development.
Capacity building in IT and e-Governance.
NINETEENTH SCHEDULE :
INFOR MAT ION & PUBLIC RELATIONS DEPARTMENT

1.
2.
3.
4.
5.
6.

7.
8.
9.
10.
11.
12.
13.
14.
15.

Press, Newspapers and Periodicals and Electronic Media.
Publication and Publicity.
Advertisements.
Public Relation and Mass Communications.
Co-ordination with AIR and Doordarshan, PIB.
Regulating, Censoring and Monitoring the making, producing, displaying, broadcasting and exhibition
of Movies, Films, News Clippings etc. through any medium or channel of mass communication
operating in Mizoram, which imply application of relevant Act and Rules, such as :i)
the Cinematograph Act.
ii)
Cable TV Network Act, 1995 & Amendment Act, 2000.
iii)
The Mizoram Exhibition of Films on TV Screen through VCP Rules, 2000 & Amendment Act, 2005.
Field publicity, etc.
Journalist welfare.
Speeches of Governor in the first session after each Election of the Legislative Assembly and at the
commencement of the first session of Legislative Assembly each year.
Speeches of Governor and Chief Minister on National Important Days.
Production and certification of films.
Production of visual arts, films and painting.
Development of photography.
Publicity of Government development, progress, schemes through print and electronic media.
Information & publicity on National and State important days.
TWENTIETH SCHEDULE :
IRRIGATION & WATER RESOURCES DEPARTMENT

1.

Irrigation, which includes:
i.
River Lift Irrigation
ii.
Drips & Sprinklers, Hydrams etc.
iii.
Diversion Scheme.

<!-- page 13 -->

- 13 2.
3.
4.

5.
6.
7.

Ex-396/2019

Networking of Rivers.
Command Area Development.
Central Sector and CSS on Irrigation and related subjects which inter alia include:
i.
Surface Minor Irrigation.
ii.
Lift Irrigation.
iii.
Repair, Renovation and Restoration of Water Bodies under Pradhan Mantri Krishi Sinchai
Yojana (PMKSY).
iv.
National Hydrology Project.
Flood management programme for protection of agricultural land (excluding stream bank erosion control).
Harnessing water resources for promotion of agriculture and allied sector.
Ground water development and management for irrigation.
TWENTY FIRST SCHEDULE :
LABOUR, EMPLOYMENT, SKILL DEVELOPMENT & ENT REPRENEURS HIP
DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.

Employment exchanges/career counseling centre.
Labour Acts and Rules.
Fixation and revision of wages and settlement of wages in case of disputes.
Labour statistics.
Trade Union.
Welfare of labour and labour disputes.
Factories Acts, Regulation and implementation.
Fund & Miscellaneous Act, 1952, Payment of Gratuity Act, 1972, Employees State Insurance Act,
1978 and Employees Provident Funds and Miscellaneous Provisions Act, 1952.
Industrial Training Institute.
ITI’s Vocational & Technical Training of Craftsmen and Apprentice.
Regulation of placement agencies (India & Abroad).
The Mizoram Building & Other construction Workers’ Welfare Board.
Skill Development.
TWENTY SECOND SCHEDULE :
LAND RESOURCES, SOIL & WATER CONSERVATION DEPARTMENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.

Soil conservation.
Hill-side terracing.
Plantation for soil conservation such as arecanut, broom, coffee and rubber plantations.
Utilization of terrace land for various crops and cereals.
Contour bunding.
Soil erosion control /anti erosion works.
Gully control measures.
Water extension dams / water harvesting / rainwater harvesting structures.
Watershed development and management.
Soil survey, soil testing & soil health management.
Land resource development.
Extension and training.
Development of catchment area of water for water security.

<!-- page 14 -->

Ex-396/2019

- 14 TWENTY THIRD SCHEDULE :
LAND REVENUE & S ETTLEMENT DEPARTMENT

1.
2.
3.
4.
5.
6.
7.

Land revenue.
Land settlement.
Land records.
Land reforms.
Assessment/rental compensation on account of occupation of private properties by security forces
and para-military forces and others.
All matters pertaining to land acquisition.
Stamps and Registration.
TWENTY FOURTH SCHEDULE :
LAW & JUDICIAL DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.

Compilation, maintenance and interpretation of all Acts/Rules.
Laws and regulation in force from time to time.
Administration of justice in the State.
Advice on legal matters.
Appointment of Advocate General/Standing Counsel/Public Prosecutor and Government Advocate.
Advice on all cases involving the State of Mizoram in the Supreme Court, High Court and Civil Court
to the Department and agencies concerned.
Vetting of all official Bills/Rules/Regulations under Government of Mizoram.
Contract Deeds, Arbitration Cases and Memorandum of Understanding (MoU).
The Mizoram Marriage, Divorce and Inheritance of Property Act, 2014.
Infrastructure development of District and other Subordinate Courts.
Lushai Hills Autonomous District (Administration of Justice) Rules, 1953.
Personal laws and customary laws and practices.
Matters relating to Supreme / High Court.
Motor Accident Claims Tribunal.
Registration of marriage.
Matters relating to the Mizoram Judicial Services.
Matters relating to Mizoram Legal Services.
Matters relating to Mizoram Law Commission.
TWENTY FIFTH SCHEDULE :
LOCAL ADMINIST RAT ION DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.
9.

Village market and village administration.
Matters relating to Panchayati Raj Institution.
Naming of streets, roads and villages outside municipal areas.
Animal control and taxation outside municipal areas.
Park & recreation. Registration and regulation of recreation, park and places, like picnic spots, etc.,
outside municipal areas.
Housing loan and advances.
Local development works funded under State Plan Fund including housing assistance outside Aizawl
City and its agglomeration.
Preservation of place of worship of SCs/STs including burial ground, crematorium outside municipal areas.
Street Lights in rural areas.

<!-- page 15 -->

- 15 10.
11.
12.

Ex-396/2019

Village safety and supply reserve.
Village sanitation.
Dog bite in rural areas.
TWENTY SIXTH SCHEDULE :
PARLIAMENTARY AFFAIRS DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.

Summoning and prorogation of the Legislative Assembly, dissolution of the Assembly.
Planning and coordination of legislative and other official business in the Legislative Assembly.
Allocation of time to the Government in the House for discussion of motions given notice of by Members.
Liaison with Leaders and Whips of various parties and groups represented in the Legislative Assembly.
List of Members of Select and Joint Committees on Bills.
Appointment of Members to Committees and other Bodies set up by the Government.
Functioning of Consultative Committees of Members of the Legislative Assembly for various Ministries/
Departments.
Implementation of Assurances given by Ministers in the Assembly.
Government’s stand on Private Members Bills and Resolutions.
Salary, allowances and pension of Members of the State Legislature.
Salary, allowance etc.. of the Ministers, Speaker/Dy. Speaker, Government Whip, Leaders of
Opposition in the State Legislature, officers of the State Legislature.
Advice to Ministries on procedural and other legislative matters.
Coordination of action by Ministries on general application made by various Committees of the State Legislature.
Officially sponsored visits of Members of the Legislative Assembly to places of interest.
Matters connected with powers, privileges and immunities of Members of the Legislative Assembly.
Welfare of ex-Legislators and their families.
Matters relating to Legislative Assembly.
TWENTY-SEVENTH SCHEDULE :
PER SONNEL & ADMINIST RATIVE REFORMS DEPARTMENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.

All matters relating to recruitment/promotion/regularisation to Group ‘A’, ‘B’, ‘C’ and ‘D’ posts by
Mizoram Public Service Commission/ Departmental Promotion Committee including Assured Career
Progression Schemes and Time Bound Promotion Schemes.
Framing, amendment, relaxation of Service Rules/Recruitment Rules of various Services / Posts and
matter relating thereto.
Service matters relating to All India Services, Central Civil Services on deputation, Mizoram Civil
Service, Mizoram Secretariat Service and Heads of Department.
All service matters relating to Ministerial Service (Assistant), Mizoram Stenographer Service and
Mizoram Subordinate Stenographer Service.
Matters relating to Personal Staff of Ministers.
Rules and Procedures regarding Fixation of Seniority, Promotion, Counting of Past Services and all
matters relating thereto.
Advice on re-employment / extension of services of superannuated Government servant.
Honorary appointment of persons in civil posts.
Matters relating to Classification of Posts and Grant of Gazetted Status.
Reservation of posts in services for certain class of citizens.
Advice on absorption of staff, retrenched personnel and re-deployment of staff rendered surplus.
Matters relating to debarring persons from Government service.

<!-- page 16 -->

Ex-396/2019
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.
36.
37.
38.
39.
40.
41.

- 16 -

Compassionate appointment.
General policy regarding age limits, medical standards and educational qualifications.
General policy regarding verification of character and antecedents, suitability of candidates for
appointment to Government service.
Recognition of University degree and non-technical degrees/diploma for appointment to Government service.
Rules relating to application fee and instructions regarding advertisement for posts.
Advice on cadre review and restructuring.
Advice on creation, amalgamation, re-organisation and bifurcation of Government establishments / departments.
General policies on Performance Appraisal Report and Annual Confidential Report.
Custody of PARs of Civil / Secretariat Service Officers & Head of Department.
Deputation / Foreign Service.
All matters relating to Administrative Training Institute.
All matters relating to Good Governance initiatives.
The Mizoram Right to Public Services Act, 2015.
Public grievances including MIPUI AW.
Deputation of Gazetted and Non-Gazetted Officers for Training in India and abroad.
Advice on all matters pertaining to training.
All matters relating to Commissioner of Inquiry.
Matters relating to Public Service Commission.
Co-ordination with the Central Government on matters of administrative reforms.
General Policy on personnel administrative reforms, research in personnel administration and
manpower planning (service).
Organisation & method, works study/work measurement and laying down of yardstick for Departments.
Administration and interpretation of Service Rules including FR&SR.
Secretariat Manual.
Simplification of rules and procedures.
General Policy on Staff Welfare.
Matters relating to Service Associations.
General Rules governing petitions, appeal and memorial on service matters.
Maintenance of service books.
Maintenance of service books of Assistant, Steno II & III under Secretariat.
TWENTY EIGHTH SCHEDULE :
PLANNING & PROGRAMME IM PLEMENTATION DEPART MENT

1.
2.
3.
4.
5.
6.

7.
8.
9.

Formulation of development policy and plan.
Coordination, monitoring and evaluation of plan & other developmental schemes and projects including
Centrally Sponsored Schemes, Central Sector Schemes.
Mizoram State Planning Board and other Development/ Advisory Committees, and matters relating
to development coordination and decentralised planning including District Planning Committee etc.
Plan publicity.
Matters relating to MPLADS and MLALADS
Official Data and Statistics / Data including Census of Government Employees, various socio-economic
surveys, National Sample Survey, Agriculture Census, Economic Census, State Income Estimation,
Price Statistics, Index of Industrial Production, Annual Survey of Industries, Building Statistics, BPL
Statistics, Village Profile, Budget Analysis, Employment & Unemployment Survey etc.
Matters relating to Ministry of DoNER and North Eastern Council (NEC).
Evaluation and monitoring of statistics.
Survey on manpower planning, employment and credit linkages.

<!-- page 17 -->

- 17 10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.

Ex-396/2019

20-Point Programme.
Civil Registration System (Registration of Births and Deaths).
Infrastructure development, public investment & Public Private Partnership.
Resource Mapping for Sectoral Allocation and Formulation of Action Plan for Development of Mizoram.
Promotion and popularization of Science, Technology and Innovations. Mizoram Science, Technology
& Innovations Council, and matters relating to Department of Science & Technology, Ministry of
Science & Technology.
Remote sensing, GIS and Space Applications and matters relating to MIRSAC, NESAC and
Department of Space.
Matters relating to Intellectual Property Rights including Copyright Act, 1957; Patent Act, 1970 involving
establishment of Patent Information Centre; Design Act, 1999; Trademarks Act, 1999; and all Rules/
Regulation thereunder.
Meteorology and Weather Information.
Biotechnology and Bioresearches, and matter relating of Department of Biotechnology, Ministry of
Science & Technology.
Research and Analysis of the State’s Economy, Welfare Para Metres, Sectoral Surveillance and
Identification of Plan Priorities including Evaluation and Applied Research for Pilot Projects and
Policy Intervention.
Matter relating to Ministry of Statistics & Programme Implementation.
All matters relating to Central Planning Machinery (Planning Commission, NITI Aayog etc.) and
National / global development goals (Act East Policy, Sustainable Development Goals etc.).
Socio Economic Development Programme (SEDP).
TWENTY NINTH SCHEDULE :
POLIT ICAL & CABINET DEPARTMENT

1.
2.
3.
4.

Swearing-In of Cabinet Ministers/Ministers of State.
Appointment, Swearing-In and Resignation of Ministers.
Allocations of Departments to Ministers.
Council of Ministers Meeting and related matters.
THIRTIETH SCHEDULE :
POWER & ELECTRICITY DEPARTMENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.

The Electricity Act (EA) 2003 including the Rules and Regulations thereunder.
Central Electricity Regulation Commission (CERC) Rules and Regulations.
Central Electricity Authority (CEA) Regulations.
Energy Conservation Act, 2001 including Regulations made thereunder.
Implementation of Hydro Electric Power Policy of Mizoram, 2010 Solar Power Policy, 2017 and
Renewable Energy Policy, 2003.
Generation of Power both from conventional and non-conventional /renewable sources of energy.
Transmission of power including construction of transmission infrastructure.
Distribution of power including construction of supporting Infrastructure.
Purchase and sale of power including trading of power.
Tariff Policy, 2016.
Filing of Tariff.
Tariff Orders /Codes /Regulations issued by Joint Electricity Regulatory Commission, Manipur and
Mizoram [JERC(M&M)].
Mizoram Electrical Licensing Regulations, 2017.

<!-- page 18 -->

Ex-396/2019
14.
15.
16.
17.
18.

- 18 -

Matters relating to Joint Electricity Regulatory Commission [( Manipur and Mizoram) JERC(M&M)],
Zoram Energy Development Agency (ZEDA), Electrical Inspectorate (EI) and State Load Despatch
Centre (SLDC).
Execution of deposit works for external electrification as deemed licensee under Electricity Act, 2003.
Communication system in the power network with leasing out.
All matter pertaining to licensing and inspections of electrical installations.
Inspection and certification of lifts.
THIRTY FIRST SCHEDULE :
PRINTING & STATIONERY DEPARTMENT

1.
2.
3.
4.
5.
6.
7.
8.

Control of Government Printing Press and Printing Works.
Streamlining the procedure of local purchase of stationery by Departments under Government of Mizoram.
Printing of Departmental forms, leaflets, books, calendars, receipts, pamphlets, journals, invitations,
tickets, etc.
Procurement of stationery articles & supply to offices.
Publication of Mizoram Gazette.
All matters relating to all publications in respect of Mizoram.
Institute of Printing & Digital Technology.
Registration of private printing press.
THIRTY SECOND SCHEDULE :
PUBLIC HEALTH ENGINEERING DEPART MENT

1.
2.
3.
4.
5.
6.
7.

Administration of public health and water supply.
Ground water management for drinking water.
Urban and rural water supply.
Protection, renovation, restoration and repair of water bodies for drinking water.
Quality assessment, regulation, monitoring and surveillance of water bodies.
Sewerage, liquid & septage management.
Water and sanitation issues having adverse effect on public health.
THIRTY THIRD SCHEDULE :
PUBLIC WORKS DEPARTMENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.

Construction of Government buildings.
Supply of furniture to residential quarters.
Construction of Government residential quarters.
Construction and maintenance of urban and rural roads & bridges.
National Highway Act and other Laws/Regulation pertaining to roads.
The Mizoram Roadside Land Control Act, 1976 and related Rules.
Flood control measures excluding protection of agricultural land
Purchase, allotment and transfer of plant, tools and machinery.
Maintenance of Government buildings constructed by PWD.
The Mizoram Road Fund Act, 2007 and the Mizoram Road Fund Rules.
The Mizoram Rural Road Maintenance Policy.
Construction of major elevated roads and tunnels.
CPWD Codes and CPWD Works Manual maintained by PWD.
Construction of airports and helipads.

<!-- page 19 -->

- 19 -

Ex-396/2019

THIRTY FOURTH SCHEDULE :
RURAL DEVELOPMENT DEPARTMENT
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.

Rural Development Blocks including creation and demarcation of R.D. Block.
Rural employment and livelihood programme.
Planning, co-ordination, evaluation and monitoring of all Rural Development Schemes and Centrally
Sponsored Schemes for rural development.
All State funded Rural Development Schemes including social education, rural housing scheme,
Housing for Project Staff, Chief Ministers Rural Housing Scheme.
SLMC & IAC.
State Institute of Rural Development and Panchayati Raj.
National Rural Livelihood Mission/State Rural Livelihood Mission.
Pradhan Mantri Krishi Sinchai Yojana(PMKSY).
Border Area Development Programme (BADP).
Indira Awas Yojana / Pradhan Mantri Awas Yojana – Gramin.
Shyam Prasad Mukherji Rurban Mission.
Sansad Adarsh Gram Yojana / Vidhayak Adarsh Gram Yojana.
All matters relating to District Rural Development Agency (DRDA).
THIRTY FIFTH SCHEDULE :
SC HOOL EDUCATION DEPARTMENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.

Inclusive education in schools.
Elementary & secondary education.
Hindi education.
Teachers’ education and training.
Right to Education Act and Rules.
State Council for Educational Research & Training.
Mizoram Board of School Education (MBSE).
State Institute of Educational Management & Training
Physical education in schools.
Co-ordination with Government of India in matters relating to NIOS, Kendriya Vidyalaya, Navodaya
Vidyalaya, RIMC, Sainik School, Imphal.
Administration and management of Sainik School.
Regulation of hostels for school students.
Mid- Day Meal.
Development/publication & printing of elementary school textbooks.
Education research & evaluation.
Population / environment education.
Education through satellite.
School leadership.
RMSA/SSA.
Organization of school competition including School Games.
THIRTY SIXTH SCHEDULE :
SECRETARIAT ADMINIST RATION DEPARTMENT

1.
2.

All service matters relating to UDCs, LDCs, Drivers and Group D staff under SAD.
Pay and allowances and personal claims of Ministers, all Gazetted and Non-Gazetted Officers of Secretariat.

<!-- page 20 -->

Ex-396/2019
3.
4.
5.
6.
7.
8.
9.
10.
11.

- 20 -

All interest bearing and non-interest bearing advances and loans, maintenance of accounts/records
thereof for staff under SAD.
All kinds of contingency bills of Secretariat.
Accommodations of officer & staff in the Secretariat and minor repair/alteration works in the
Secretariat.
Maintenance of Secretariat vehicles.
Procurement and supply of furniture, stationery and office equipment in the Secretariat.
All matters relating to departmental proceedings of staff under SAD.
Arrangement of measures for security in the Secretariat.
Honorarium & OTA of officers & staff under SAD.
Beautification of Mizoram Secretariat and its premises.
THIRTY SEVENTH SCHEDULE :
SERICULT URE DEPARTMENT

1.
2.
3.
4.
5.
6.
7.

Development of mulberry silk.
Development of vanya silk (Muga, Eri and Oak Tasar).
Silkworm food plants development.
Silkworm seed development.
Post cocoon development.
Marketing of sericulture products.
Sericulture extension and training.
THIRTY EIGHT H SCHEDULE:
SOCIAL WELFARE AND TRIBAL AFFAIRS DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.

Welfare of women & children.
Matters relating to persons with disabilities.
Grant-in-Aid to voluntary organization.
Child protection.
Welfare of poor and destitute.
Implementation of Children’s Act, Immoral Traffic in Women and Girls Act and such social security scheme.
Integrated Child Development Services.
Component of health, nutrition and non-formal education to children below 6 years, pregnant and
lactating mother and adolescent girls.
The persons with Disability (Equal Opportunities, Protection of Right and Full Participation) Act, 1995.
Matters relating to senior citizens.
Protection of women from domestic violence.
Welfare matters relating to Schedule Castes/ Scheduled Tribes and Other Backward Classes/ Weaker
Section of the society.
The term “Welfare Measures” relating to SCs/STs under sl.12 may constitute
EXPLANAT ION:
the following:i.
Charities and charitable institutions, charitable and religious
endowments to subject dealt within the Department.
ii.
Matters pertaining to socio-economic, cultural and educational status
of SCs/STs.
iii.
Funding of programmes and projects for the welfare of SCs/STs
including MsDP.
iv.
Welfare matters relating to NC for SCs STs.

<!-- page 21 -->

- 21 13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.

Ex-396/2019

All matters relating to adoption.
All matters relating to social defence and rehabilitation.
National awards for women and children.
Maintenance and Welfare of Parents and Citizens Act, 2007.
Prohibition of Child Marriage Act, 2006.
The Scheduled Tribe, and other Traditional Forest Dwellers (Recognition of Forest Rights) Act, 2006.
Sexual harassment of women at workplace.
Aadhaar enrolment of children 0-5 years.
Universal Women’s Helpline.
Gender budgeting.
Manual scavengers and related matters.
Rights of lesbians, gays, bisexuals and transgender (LGBT).
Child rights protection.
THIRTY NINTH SCHEDULE :
SPORTS & YOUTH SERVICES DEPARTMENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.

Formulation and implementation of all policies relating to Sports and Youth Services.
Mizoram State Sports Council and grant-in-aid to sports associations.
Bharat Scouts and Guides.
Adventure sports.
National Service Scheme (NSS).
National Cadet Corps (NCC).
Youth Hostels.
Nehru Yuva Kendra.
Matters relating Sports Authority of India.
Matters relating to Mizoram Olympic Association.
Administration and maintenance of sports academies, hostels, sports complexes and other
infrastructures for sports and youth training and development.
Coordination with other departments for development of sports, youth services and sports tourism.
Promotion and development of adventure sports and youth services in schools and colleges.
Development of skills and personality of youth through youth development activities.
Incentive awards and scholarships to outstanding sportspersons.
Promotion of research and scientific study on sports and youth services.
Training of coaches, imparting of coaching at various levels.
Provision of sports infrastructure including distribution and arrangement of equipment to educational
and village level institutions and other stakeholders.
Organizing of sports competition at various levels directly or through the agency of autonomous
sports bodies and associations including School Games and State Games.
Physical Education.
Promotion of Sports & youth services in school.
Mizoram Youth Commission.
FORTIETH SCHEDULE :
TAXATION DEPART MENT

1.
2.
3.

Policy on taxes and its related matters.
Taxes on profession, trades, callings and employment.
Value Added Tax.

<!-- page 22 -->

Ex-396/2019
4.
5.
6.

- 22 -

Goods and Services Tax and related matters.
Registration of Firms and Societies.
Registration of Partnership Firms.
FORTY FIRST SCHEDULE :
TOURISM DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.

Policies for promotion and development of tourism.
Promotion and development of tourism including adventure tourism, eco-tourism etc.
Tourist accommodation and Tourist Information Centres.
Tour guides.
Tours and travels.
Hotels and restaurants.
Fairs and festivals for the promotion of tourism.
Ropeways and cable cars for Tourism Development.
FORTY SECOND SCHEDULE :
T RANSPORT DEPART MENT

1.
2.
3.
4.
5.
6.
7.

Matters relating to the registration and taxation of all surface transports including Inland Water Transport
and Ropeway, but excluding Railways.
Formulation and administration of Rules, Regulations and Laws governing all surface transport in the
State. Matter relating to Inland Water Transport, Ropeways and Non-Motorized Vehicles, subject to
the provisions of the Seventh Schedule to the Constitution of India.
Matter relating to improvement of road safety.
Matter relating to railways
All matter relating to rural and inter-state transport.
All matters relating to the constitution of the State Transport Authority and the subjects allocated to it.
Condemnation of Government vehicles.
FORTY THIRD SCHEDULE :
URBAN DEVELOPM ENT & POVERT Y ALLEVIAT ION DEPART MENT

1.

2.

3.

Urban Governance:
a.
Municipal administration.
b.
Development Authorities/Boards/Committees.
c.
Naming of streets, localities and development areas in urban areas.
d.
Notification/de-notification of Towns (including demarcation in urban areas).
e.
Street lighting and solar lighting (including Solar City Project).
Urban Development:
a.
Urban infrastructures.
b.
Urban renewal, transformation and rejuvenation.
c.
Urban amenities and social development.
d.
Township development
Urban Sanitation:
a.
Solid waste management.
b.
liquid waste management
c.
Cleanliness and sanitation.

<!-- page 23 -->

- 23 4.

5.

6.

7.

8.
9.
10.

Ex-396/2019

Urban Transport:
a.
Planning & co-ordination of urban transport.
b.
Infrastructure for urban transport.
c.
Non-motorized transport.
d.
Direction, delineation and signage.
e.
Metro-cable and urban ropeways.
Urban Planning:
a.
Master Plans for Urban Areas (including strategic development areas).
b.
City Development Plans.
c.
District/Region/Zone/Town Development Plans.
Urban Housing:
a.
Land development regulations.
b.
Building regulations.
c.
Urban Rent Control and Residential Tenancy.
d.
Property Titling.
e.
Regulation and engagement of developers.
Urban Poverty Alleviation:
a.
Street vending.
b.
Urban shelter
c.
Skill development and training.
d.
Social mobilization
e.
Urban wage employment.
Disposal of unclaimed dead bodies.
Animal control in urban areas.
Dog bite in municipal areas
FORTY FOURTH SCHEDULE :
VIGILANCE DEPART MENT

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.

All matters connected with vigilance work.
Anti-corruption measures.
Property Returns of Gazetted Officers.
Property Returns in respect of Group-B.
C.C.S (CCA) Rules, 1965.
CCS (Conduct) Rules, 1964.
Matters relating to Vigilance Commission.
Matters relating to Establishment & Administration of Anti-Corruption Bureau (ACB).
Reference of cases to Central Bureau Investigation (CBI).
Matters relating to Lokayukta.

Published and Issued by Controller, Printing & Stationery Department, Government of Mizoram
Printed at the Mizoram Government Press, Aizawl. C/180
