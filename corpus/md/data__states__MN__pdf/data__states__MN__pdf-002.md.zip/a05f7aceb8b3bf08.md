---
doc_id: "a05f7aceb8b3bf08"
source_url: "https://manipureducation.gov.in/wp-content/uploads/2026/08/TET-I-extension-2026-2nd-Notification.pdf"
ministry: "Education (School) Department, Manipur"
title: "Click here to download Notification"
date: ""
pages: 1
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "74161a7c3bfd7ee7"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
DIRECTORATE OF EDUCATION(S)
(Administrative Section)
FR
NOTIFICATION
Imphal, the 7" July, 2026
No. AO/272/TET/2022-DE(S)Pt-I: In continuation and partial modification of this office
Notification of even No. dated 16 June, 2026, it is hereby notified for information of
all the concerned that the last date for submission of online application forms for the
' Teacher Eligibility Test (TET) Paper-I is hereby extended up to 208" July, 2026.
2s All other terms and conditions contained in this Directorate's Notification of even
number dated 16" June, 2026 shall remain unchanged and shall continue to be in force
in addition to the insertion of eligibility criteria made herein for in-service teachers of
Government/Government Aided/Recognised Private Schools.

a) Graduation with at least 50% marks and Bachelor of Education(B.Ed.) provided
that the in-service teacher possesses a six months bridge course in Elementary
education recognised by NCTE or

b) Senior secondary or its equivalent and 18 months Diploma in elementary
education conducted by NIOS.

3. The date of examination and the centers of the examination for Teacher

Eligibility Test Paper-I shall be notified later.

4. The notification along with the Eligibility Criteria, Structure and Content of

Syllabus and Instruction to Candidates are uploaded in the website of the Department-

www.manipureducation.gov.in and also at the URL www.tet2026manedus.com.
7

Director of Education (5),
Manipur

Copy to:

1. P.S to the Commissioner, Education(S), Government of Manipur.

2. Director, DIPR, Manipur

3. Additional Directors of Education/Schools, Manipur

4. Sr. Administrative Officer, He is requested to upload the notification in the
Official website.

5. The Editor, Poknapham(M), NaharolgiThoudang(M), HuiyenLanpao(M), Sangai
Express(E), with a request to publish the above Notification for 4072) day only
as paid item. Bill in duplicate may be submitted to the Directorate for early
Payment.

6. Relevant File.
