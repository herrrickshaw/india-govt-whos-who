---
doc_id: "b9edd371fae56bff"
source_url: "https://manipurhealthdirectorate.mn.gov.in/uploads/news/2026/09/03/icu_organogram.pdf"
ministry: "Directorate of Health Services, Manipur"
title: "Order Regarding Approved Organogram and Functional Structure of ICU, Trauma & Emergency Services"
date: ""
pages: 6
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "bd1d619252a98d68"
---

<!-- page 1 -->

a
& /
4
GOVERNMENT OF MANIPUR.
j ; DIRECTORATE OF HEALTH SERVICES :
‘ ORDERS
Imphal, the 24 September, 2026
No.MC/Conf-ICU/CCU/2025-DHS: In pursuance of the Government of Manipur, Secretariat: Health
! Department Office Memorandum No. MED-1603/19/2023-HS-HEALTH, dated 1% July, 2026, Order No.
MED-1603/19/2023-HS-HEALTH, dated 7" August, 2026 and Order No. MED-1603/19/2023-HS-
HEALTH, dated 21 August, 2026, regarding the constitution of the State Level ICU Coordination
Committee, utilisation of MHS Grade-I and Grade-II Officers in the ICU, Trauma & Emergency Service
Division and implementation of the approved Organogram and Functional Structure, the following works,
functions and reporting arrangements are hereby prescribed with immediate effect.
2. Overall Administrative Authority
The Director of Health Services, Manipur shall be the Overall Administrative Head of the ICU,
Trauma & Emergency Service Division and shall exercise administrative control over the ICU
Implementation Unit.
3. ICU Implementation Unit
The Senior Consultant ICU/Nodal Officer and the designated Consultants shall constitute the ICU
Implementation Unit under the Directorate of Health Services. The ICU Implementation Unit shall be the
functional/technical implementation arm for the ICU, Trauma & Emergency Service Division and shall be
responsible for day-to-day coordination, implementation, monitoring, inspection follow-up and reporting
relating to ICU, Trauma & Emergency services.
3 (a). Senior Consultant ICU/Nodal Officer
Dr. S. Gopal Singh, Senior Consultant ICU (MHS Grade-I), shall function as the Nodal Officer of the
ICU Implementation Unit. He shall have oyerall supervision, implementation, monitoring and coordination
of the ICU Implementation Unit and shall report directly to the Director of Health Services. He shall also
e Supervise and guide the Consultants of the ICU Implementation Unit;
© Coordinate with the concerned Additional Directors and other relevant technical/administrative
officers;
© Monitor ICU gap assessment, compliance and implementation of corrective measures; and
¢ Maintain functional coordination with the State Level ICU Coordination Committee, District
Inspection Committees, State Health Society/NHM, Medical Colleges, District Hospitals and other
designated institutions/agencies.
3 (b). Consultant-I - ICU & Critical Care Systems
Dr. K. Nandinibala Devi, Consultant-I, shall function under the Senior Consultant ICU/Nodal
Officer and shall be responsible for ICU infrastructure mapping and standardisation, operationalisation and
quality assurance of ICU services, monitoring of ICU equipment and oxygen systems, facility inspection and
compliance monitoring, and identification and reporting of ICU gaps.
3 (০), Consultant-II — Trauma & Emergency Coordination
Dr. Th. Brojendro Singh, Consultant-II, shall function under the Senior Consultant ICU/Nodal
Officer and shall be responsible for coordination of ambulance services, trauma-care and emergency referral
GE Scanned with OKEN Scanner

<!-- page 2 -->

.
4
পর mechanisms, emergency communication and response systems, hospital emergency preparedness,
” coordination with District Committees and healthcare institutions, and monitoring of emergency drugs,
; trauma equipment and related logistics.
4, State Level ICU Coordination Committee — Separate Oversight/Advisory Body
The State Level ICU Coordination Committee is a separate State-level oversight and coordination
body and shall not form part of the vertical reporting structure of the ICU Implementation Unit. The
Committee shall function under the Chairmanship of the Director of Health Services, Manipur. It shall
provide policy-level oversight, technical guidance, advice and directions to the ICU Implementation Unit and
shall review the progress of ICU implementation, gap assessment, inspection, compliance and other related
matters,
4 (a). Chairman and In-charge
The Director of Health Services, Manipur shall be the Chairman of the State Level ICU Coordination
Committee. Dr. Y. Premachandra Singh, Additional Director (Planning & Finance) & SNO Tele-ICU, shall
be the In-charge of the State Level ICU Coordination Committee and shall convene meetings of the
Committee, the ICU Implementation Unit and District Inspection Committee members regularly on a
quarterly basis and whenever necessary on an emergency basis.
4 (b). Powers and Functions of the Committee
The State Level ICU Coordination Committee shall, in accordance with the Government
orders/Office Memorandum constituting the Committee, exercise State-level oversight and shall have the
power to issue binding directions, prescribe standards, classify facilities and ensure compliance across the
State. The Committee may advise, guide and issue directions to the ICU Implementation Unit for effective
implementation of the approved ICU, Trauma & Emergency standards and State Action Plan.
4 (c). Follow-up and Reporting
The In-charge of the State Level ICU Coordination Committee shall coordinate
technical/administrative follow-up, monitor implementation of decisions of the Committee, and consolidate
reports for placing before the Chairman/competent authority. The ICU Implementation Unit shall provide the
Committee with such reports, inspection findings, gap assessments and compliance status as may be required
f for review and further directions.
5. District Inspection Committees
The District Inspection Committees, under the supervision of the concerned Chief Medical Officer,
shall undertake district-wise gap assessment, inspection of ICU facilities, identification of deficiencies and
monitoring of corrective measures. The Committees shall submit inspection and compliance reports to the
concerned CMO. Matters requiring State-level intervention, policy guidance or directions shall be referred to
the State Level ICU Coordination Committee.
6. Reporting and Supervision within the ICU Implementation Unit
The vertical reporting structure shall apply only to the ICU Implementation Unit. The Consultants
shall function under the overall supervision of the Senior Consultant ICU/Nodal Officer and shall submit
reports, inspection findings and recommendations to him. The Nodal Officer and Consultants shall maintain
functional/lateral coordination with the concerned Additional Directors and other officers on subject matter.
Se
@ Scanned with OKEN Scanner

<!-- page 3 -->

7. Coordination
The ICU Implementation Unit shall maintain necessary functional coordination with the State Level
‘ ICU Coordination comes: District Inspection Committees, State Health Society/NHM, Medical
Colleges, District ospitals, SDHICHCs, emergency transport agencies and other designated health
institutions/agencies for effective operationalisation and monitoring of ICU, Trauma & Emergency Services.
8. Clarified Functional/Reporting Structure
Vertical administrative and functional reporting within the ICU Implementation Unit:
¢ Director of Health Services, Manipur
J ;
¢ Senior Consultant ICU/Nodal Officer — Dr. 9. Gopal Singh
t
¢ Consultant-I — Dr. K. Nandinibala Devi
e  Consultant-II — Dr. Th. Brojendro Singh
Separate State-level oversight relationship:
State Level ICU Coordination Committee (Chairman: Director of Health Services) —> Advice /
Technical Guidance / Binding Directions > ICU Implementation Unit
9. Implementation of Standards and State Action Plan
The officers of the ICU Implementation Unit shall assist in implementation of the approved State
Action Plan, prescribed ICU/Trauma & Emergency standards and directions of the competent authority
within their respective areas of responsibility. Directions issued by the State Level ICU Coordination
Committee within its authorised mandate shall be acted upon by the ICU Implementation Unit and reported
for compliance.
10. Organogram and Functional Structure
The approved Organogram and Functional Structure of the ICU, Trauma & Emergency Division
shall form an integral part of this Order. The Organogram shall clearly distinguish the ICU Implementation
Unit from the State Level ICU Coordination Committee and shall reflect the vertical reporting structure of
the Implementation Unit and the separate oversight/advisory/directional relationship of the Committee.
11. Existing Duties
The assignments shall be in addition to their existing duties, unless otherwise ordered by the
competent authority.
Encl.: Approved Organogram and Functional Structure of ICU, Trauma & Emergency Division.
(Dr. N. Hemantakumar Singh)
Director of Health Services, Manipur
Copy to:
1. The Commissioner-cum-Secretary (Health & FW), Government of Manipur, for information.
: 2. The Joint Secretary (Health & FW), Government of Manipur, for information.
3. State Mission Director, State Health Society, Manipur.
GE Scanned with OKEN Scanner

<!-- page 4 -->

2
রর
4. Dr. Y. Premchandra Singh, Additional Director (Planning & Finance) & SNO Tele-ICU, In-charge, State
* Level ICU Coordination Committee.
5, All Additional Directors, Directorate of Health Services, Manipur.
6. Dr. S. Gopal Singh, Senior Consultant ICU/Nodal Officer, ICU Implementation Unit.
7, Dr. K. Nandinibala Devi, Consultant-I - ICU & Critical Care Systems.
8. Dr. Th. Brojendro Singh, Consultant-II — Trauma & Emergency Coordination.
9. DD MC-A, Liaison Officer.
10. All Chief Medical Officers/Medical Superintendents concerned.
11. All Members of the State Level ICU Coordination Committee.
12. Guard File.
@ Scanned with OKEN Scanner

<!-- page 5 -->

; ORGANOGRAM রি
ICU, TRAUMA & EMERGENCY DIVISION qe
: ECTORATE OF HEALTH SERVICES, MANIPUR 2
“DIRECTOR OF HEALTH SERVICES’ . 1?
wR * (Overall Administrative Head) pie ৫
এ ADDITIONAL DIRECTORS Poa
Direct Reporting Futon Creatine AR
নি co AD (MEDICAL Cane) ;
; SENIOR CONSULTANT (CU ~: জার
: "ACU, TRAUMAS EMERGENCY, Division 2০ 8৮৮ ;
; - tf AD (PUBLIC HEALTH, ] :
- BONSULTANT | CONSULTANT . fet “ i:
ICU RGRITICAL. © ) TRAUMA. Po SDDMG-A oY )
SARE SY TEMS ; EMERGENCY 0450৭ OFFICER), ও
|. (MHS Gredectt Office) - COORDINATION তত
MRS 2৮ 28 miy. (MHS Grade-It Officer): ১:18 ne
পি tated
* 1০৫ : . iB £
. দস and © Monitof trauma care systems, * Foeittate administrative
ually of 1 ৬১ ‘Tafarrais and stabitzatlon processing and coordination:
eee কাপল and follow-uy> actions
৬ bape ৯. Coordinat 7 1৫ Fad OY
es Hopi tou elpley! 3 ‘eomengency preparedness { i
te 2 oe
---শশ১০-৯০০----- COORDINATION & COLLABORATION -----------+++--++++
> Chak Jin pis al © Chlof Medical Officer এ লতা লালা শি Care
এ st Fe Esper ক Medical Superintendent Agencies © Pinning & Finance
1, বনি. চিনা +. NOOs /c5R Partnera + Mo
© Raperszolaiey lipm « Noukol manianiciod + Other implementation = Other Wings
পুরে Expert Group Farts el [ 18]
হা বরা টি সনু দ্ Ha .. | :
ভি | পা ee দি পি নং a 10
কি বলত সিল Reporting লী Functional / Laterat Reporting
GE Scanned with OKEN Scanner

<!-- page 6 -->

Allscation of Portfolios and Responsibilities
ICU, Trauma & Emergency Division
Designation Key Responsibilities
* Overall supefvision, implementation, monitoring,
and coordination of activities related to the ICU,
y Trauma & Emergency Division. * Shall report directly
to the Director of Health Services. ক Coordination with
(MHS Grade-l) Additional Directors and Directorate wings for
Senior Consultant ICU division-specific activities. * Routing of division-
(Nodal Officer) telated files to the concerned authorities, wherever
necessary. + Supervision of ICU gap assessments,
compliance activities, implementation of the State
Action Plan, and directions of the Supreme Court. *
Coordination with State-level and District-level
Coordination Committees, the State Health Society,
and ICU Expert Groups.
* Shall function under the supervision of the Senior
Consultant ICU/Nodal Officer. + ICU infrastructure
mapping, standardization, operationalization,
তলে evita Monitoring, and quality assurance. Monitoring
(MHS Grade-II Officer) Procurement and utilization of ; 100) equipment,
oxygen systems, and related infrastructure. রা
Conducting facility inspections and compliance
reviews. + MHS Grade—l Officers may also be
deputed against the post, if required.
* Shall function under the supervision of the Senior
Consultant ICU/Nodal Officer. * Coordination of
ambulance services, trauma care systems, :
Consultant - Trauma emergency referral mechanisms; and logistics. *
& Emergency Coordination Monitoring emergency communication systems,
(MHS Grade-H] Officer) _ hospital mapping support, and emergency
preparedness activities. + Coordination with District
Committees and healthcare institutions for
emergency response activities. + MHS Grade—
Officers may also be deputed against the post, if
required.
* Liaison and coordination between the ICU, Trauma
& Emergency Division and the Medical Care wings of ;
DD MC-A (Liaison Officer) the Directorate. * Facilitation of administrative রি
Processes, Inter-departmental communication, and রর
follow-up activities;
৮ j
৷ 4
GE Scanned with OKEN Scanner
