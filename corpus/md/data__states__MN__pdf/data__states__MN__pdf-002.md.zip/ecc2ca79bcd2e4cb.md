---
doc_id: "ecc2ca79bcd2e4cb"
source_url: "https://manipurhealthdirectorate.mn.gov.in/uploads/news/2026/06/01/Exam_rescheduled.pdf"
ministry: "Directorate of Health Services, Manipur"
title: "Notification for the CEE for B.Sc Nursing,Pharmacy & Allied and Healthcare ,M.Sc Nursing and ANM Courses has rescheduled."
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a0bb31c9fef0ed48"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
DIRECTORATE OF MEDICAL EDUCATION

NOTIFICATION

Imphal, the 1s June 2026
No. DME- 10/1/2026-HEALTH: In continuation of this Directorate Notification No.

DME- 10/1/2026-HEALTH dated 08h May, 2026, it is hereby notified for infomation to
all concerned that the Entrance examinations for admission to the following courses
has been rescheduled on the following dates & time:
Common Entrance Examination (CEE) for B.Sc.

14-06-2026

Entrance Examination for ANM Course

14-06-2026

Entrance Examination for M.Sc. Nursing Course

14-06-2026

Nursing, Pharmacy & Allied and Healthcare Courses(10 AM to 12 Noon).

2.

(2PM to4 PM).

(2 PM to 4 PM).

Further, it is informed that Kangpokpi has been included as an additional

Examination city for the aforementioned examinations along with the previously
notified cities; Imphal, Senapati, and Churachandpur. Registered candidates who wish

to change their "Choice of Examination city",may do so after logging into the dedicated

online portal at https://manipurnc.mn.gov.in

from 02-06-2026 to 04-06-2026.

Technical instructions for change in Examination city are enclosed as Annexure.
3

The timeline for downloading of Admit cards from the online portal is

rescheduled from 05-06-2026 to 10-06-2026.

4. For any further queries, please contact this Directorate at 9366255065 (10
am to 5 pm on working days).

(Somofit Salam)

Director of Medical Education

Govermment of Manipur

<!-- page 2 -->

Entrance Examination for Nursing, Pharmacy and Allied & Healthcare courses,
Academic Session 2026-27

https://manipurmc.mn.gov.in

Change Exam City Option

1. To change exam city, login with your registration ID and password and click Update City
2. For each application, you can change exam City from the given Exam Cities list (N.B. You
must update for each Application)(if there are two, you need to change two exam Cites)
O Exam City Change is Available!

Update Cy (ANH)

You are permitted to update your preterrod Exam Ctychoice Plcaseclick on the acton buttongs) below to twitch to the

Update Cny (Comnon Errance amCEE))

appication torm and scicct your ncw pretered exam city

Entrance Examination for Nursing, Pharmacy and Aliod & Heathcare courses Porta-2026-27

Canon
PARENTHAHE

Logout

EamCh Se

BEOISTERED HOBLE

HANNOUNCEMENtS

View No

Please read the nothcation carefuly to check the eligibility citerla & important instructions

MyAppication History
cOURSE

APPICAION ID

ANM

Common Entrance Exam(CEE)
Sesuon 2024 2

APPLICATION ROADMAP

STATUS

PAYMENT

Not Asgned

Approd

O Paid

Update Clty

Nor Assgneg

Aoorowd

O Paid

Update City

Vlewing Application:
Course Common Entrance Exam(CEE)AD OiLY

Course Selectian

ACTIONs

EXAM CENTRE

Change Exam City
Exam Cty

|

|

Exit Review

Open for Edit

Personal Detais
Courses Choice

6 The otficial portal has enabled exam city change tor your application Please revew yo prevously selectederam city and select your
choice ftom the lst. All other helds n yout appication reman locked

PREVIOoUsLY SELECTEDEXAMCItY

Academic Details

Imphal

Upload Documents

-- Select Exam City --

aUpdate

- Select Exam City
Churachandput

Declaration

Kangpokpi
2

Personal Details
Address, domicie & esam city

Courses Applied

Senapat:
Locked

A Locked

3. If not required, do not change the Exam city. NO ACTION REQUIRED. (The previous
selected Exam City will be maintained)
4. Once Exam City is updated, the previous selected Exam city will be overwritten.
5. Complete the process before 5 pm of 04-06-2026. The option will be closed after this

period
