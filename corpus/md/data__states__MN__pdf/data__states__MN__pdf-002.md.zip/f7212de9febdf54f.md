---
doc_id: "f7212de9febdf54f"
source_url: "https://manipurhealthdirectorate.mn.gov.in/uploads/news/2026/04/21/Appointment_DIH_Gr-IV.pdf"
ministry: "Directorate of Health Services, Manipur"
title: "Notification for Appointment of DIH Gr-IV."
date: ""
pages: 3
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "1979f92b69e03906"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
DIRECTORATE OF HEALTH SERVICES
NOTIFICATION
Imphal, the yz-¥ April, 2026.
No. G/171/Apptt.(DIH)/2023-DHS: In pursuance of Secretariat: Health Department,
Government of Manipur letter No. MED-307/1/2026-HS-HEALTH dated 101 April, 2026 it
is to inform the following applicants for appointment as Grade-IV under ‘Die in Harness
scheme ‘to collect “Attestation Forms” from this Directorate and submit the same after
filling up the same within 03 (three) weeks from the date of notification.
[ 91২০. [Name ofapplicant [Post UONo |
D/o (L) Chingkhonem Dated 25/03/2026
D/o (L) T. Thamkhanneng Dated 25/03/2026
S/o (L) K. Nungshirei Kabuini Dated 25/03/2026
D/o (L) Khundire Dated 25/03/2026
estes eer ees |
: : Dated 25/03/2026
Seca (SOY eee
. D/o (L) DK. Leishilkham | Dated 25/03/2026
i D/o (L) A. Krishnamohon Singh Dated 25/03/2026
[৯ Wo (L). M. H.L. Joute Dated 25/03/2026
| তি লজ as |
Dated 25/03/2026
| Dated 25/03/2026
S/o (L) Y. Pishak Singh Dated 25/03/2026
S/o (L) Kh. Parijat Singh Dated 25/03/2026
S/o (L) M. Kulachandra Singh Dated 25/03/2026
14. | RK. Tourjit Singh No. 74/2025-2026/DIH/DP_ |
| | S/o (L) R.K. Khomei Singh Dated 25/03/2026 |
D/o (L) Mrs. Jamhoiching Dated 25/03/2026
ক টি জে উস
S/o (L) M. lbempishak Devi - | Dated 25/03/2026
Dated 25/03/2026
Sut
=|
@ Scanned with OKEN Scanner

<!-- page 2 -->

) -(2)-
18. S.R. Yuringam Group-IV | No. 78/2025-2026/DIH/DP
উল | S/o(L)KaluBahadur __ ____; Dated 25/03/2026
19. | Khollam Haokip Group-IV_| No. 79/2025-2026/DIH/DP
Wo (L) Lunjohn Haokip Dated 25/03/2026 _
20. | Esther Panmei No. 80/2025-2026/DIH/DP |
|__| D/o (L) Mangoinganbi Dated 25/03/2026 |
21. | Athumpui Wo (L) G. Angam No. 81/2025-2026/DIH/DP |
Dated 25/03/2026 |
S/o (L) Thangkhomang Dated 25/03/2026 |
: Dated 25/03/2026
; D/o (L) Kh. Meipakpi Devi Dated 25/03/2026
S/o (L) Th. Mangol Singh Dated 25/03/2026
S/o (L) K. Ibohal Singh Dated 25/03/2026
S/o (L) Manishang Dated 25/03/2026
S/o (L) P.C. Manga Dated 25/03/2026
Dated 25/03/2026
4 S/o (L) L. Ibobi Singh Dated 25/03/2026
¥ 31. N.S. Amos S/o (L) N.S. Ninghorla | Group-IV | No. 91/2025-2026/DIH/DP
| | S/o (L) Md. Rahaman Shah Dated 25/03/2026
| * | S/o (L) Mohamad Babu Khan Dated 25/03/2026
S/o (L) Md. Ajijur Rahaman Dated 25/03/2026
36. | Tharem Chiru No. 96/2025-2026/DIH/DP_ 1
| * | Wo (L) Rongneithang Chir Dated 25/03/2026 |
37. _ | RK. Bedarani Devi No. 97/2025-2026/DIH/DP |
a Wo (L) Ksh. Khorchandra Singh Dated 25/03/2026 |
38. | Urikhinbam Jotin Singh No. 98/2025-2026/DIH/DP |
| | Wo (L) U. Maipak Singh Dated 25/03/2026
39. | Kshetrimayum Babita Devi
| * | Wio (L) (L) Ksh. Temba Singh Dated 25/03/2026
Kamei Mema Kabuini No. 100/2025-2026/DIH/DP
| | Wo (L) Shamungou Kabui | Dated 25/03/2026
@ Scanned with OKEN Scanner

<!-- page 3 -->

-(3)-
B/o (L)Th. Ibeyaima Devi Dated 25/03/2026
S/o (L) Jamson Haokip Dated 25/03/2026
Dated 25/03/2026
Dated 25/03/2026
; (Dr. N. এ Singh)
Director of Health Services, Manipur
Copy to:-
1. Secretary to the Hon'ble Chief Minister of Manipur.
2. The Commissioner-cum-Secretary (Health & FW), Government of Manipur.
3. Webmaster of website www.manipurhealthdirectorate.mn.gov.in
4. Persons concerned,
5. Notice Board.
6. Guard File.
4
৫
‘
é
@ Scanned with OKEN Scanner
