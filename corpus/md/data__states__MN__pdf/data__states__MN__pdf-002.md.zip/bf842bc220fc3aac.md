---
doc_id: "bf842bc220fc3aac"
source_url: "https://manipureducation.gov.in/wp-content/uploads/2026/10/Notification-for-rejected-applicants-PPT.pdf"
ministry: "Education (School) Department, Manipur"
title: "Download Notification"
date: ""
pages: 1
method: "tesseract:eng+ben"
script: "LATIN"
needs_ocr: false
sha1: "3287dc12de23d33e"
---

<!-- page 1 -->

GOVERNMENT OF MANIPUR
DIRECTORATE OF EDUCATION (SCHOOLS)
* KKK
NOTIFICATION
Imphal, the 16” October, 2026
No. AO/24/APPT/2020(11)-DE(S)Pt-I: In continuation of this Office Notification of even number
dated 9th March, 2026 pertaining to the recruitment of 1140 (one thousand one hundred forty)
posts of Pre-Primary Teachers on contract basis under Samagra Shiksha, Manipur, it is hereby
notified that the applications of the candidates listed in the ANNEXURE have been kept under
"Rejected" status on the grounds indicated against their names.
2. The candidates whose applications have been kept under rejected status may submit
their claims and objections, if any, along with supporting documents, on or before 2৫
November, 2026, at the office of the undersigned, failing which no claims shall be
entertained.
ok All applicants are advised to visit the official website of the Directorate of Education (S),
Government of Manipur regularly for further notifications, instructions and updates relating to
this recruitment.
Enclosures: As stated.
___ ১৮
(Ng. Bhogendra Meitei)
Director of Education-S, Manipur.
Copy to:

1. P.S to the Commissioner, Education(S), Government of Manipur.

2. Director, DIPR, Manipur

3. Additional Directors of Education/Schools, Manipur

4. Sr. Administrative Officer, He is requested to upload the notification in the Official
website.

5. The Editor, Peoples Chronicle(E), NaharolgiThoudang(M), HuiyenLanpao(M), Sangai
Express(E), with a request to publish the above Notification for 1(one) day only as paid
item. Bill in duplicate may be submitted to the Directorate for early payment.

6. Relevant File.

QC scanned with OKEN Scanner
