---
doc_id: "ffcdfa6c8dc3dbc4"
source_url: "http://nrhmmanipur.org/wp-content/uploads/2012/08/national_Population_Policy_2000.pdf"
ministry: "National Health Mission, Manipur"
title: "national_Population_Policy_2000"
date: ""
pages: 39
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "45220101b310b783"
---

<!-- page 1 -->

C O NT E NT S
A.

Introduction ................................................................................................ 1

B.

Objectives .................................................................................................. 2

C.

Strategic Themes ....................................................................................... 4

D.

Legislation ................................................................................................ 11

E.

Public Support ......................................................................................... 12

F.

New Structures ....................................................................................... 12

G.

Funding .................................................................................................... 13

H.

Promotional and Motivational Measures for ............................................. 13
Adoption of the Small Family Norm

I.

Conclusion ............................................................................................... 15

List of Appendices
Appendix I .......................................................................................................... 16
Action Plan
Appendix II ......................................................................................................... 30
Milestones in the Evolution of the
Population Policy of India
Appendix III ........................................................................................................ 32
Demographic Profile
Appendix IV ....................................................................................................... 36
Unmet Needs & Deficiencies in Contraceptives
Services, Health Infrastructure, Specialists and Trained
Manpower with Implications for Funding

1

<!-- page 2 -->

List of Tables
1.

Population Projections for India (million) .................................................... 1

2.

Anticipated Growth in Population (million) ................................................. 3

3

Projections of Crude Birth Rate, Infant Mortality Rate, ............................. 3
and TFR, if the NPP 2000 is fully implemented.

4

Age Composition as Percentage of .......................................................... 32
the Total Population

5.

Population Profile of 9 States and Union Territories ............................... 33
of India with TFR less than or equal to 2.1

6.

Population Profile of 11 States and Union Territories ............................. 33
of India with TFR > 2.1 but < 3

7.

Population Profile of 11 States and Union Territories ............................. 34
of India with TFR greater than or equal to 3

8.

Maternal Mortality Ratios in Asia ............................................................ 34

9.

Inter-State Differences within India in ...................................................... 35

2
Maternal Mortality Ratios
10.

Infant Mortality Rates in Asia .................................................................. 35

List of Boxes
1.

India's Demographic Achievement ............................................................. 1

2.

National Socio-Demographic Goals for 2010 .............................................. 2

<!-- page 3 -->

A.

INTRODUCTION

1.

The overriding objective of economic and social development is to improve the quality of lives
that people lead, to enhance their well-being, and to provide them with opportunities and choices
to become productive assets in society.

2.

In 1952, India was the first country in the world to launch a national programme, emphasizing
family planning to the extent necessary for reducing birth rates "to stabilize the population at a
level consistent with the requirement of national economy"1 . After 1952, sharp declines in
death rates were, however, not accompanied by a similar drop in birth rates. The National
Health Policy, 1983 stated that replacement levels of total fertility rate2 (TFR) should be achieved
by the year 2000.

3.

On 11 May, 2000 India is projected to have 1 billion3 (100 crore) people, i.e. 16 percent of the
world's population on 2.4 percent of the globe's land area. If current trends continue, India
may overtake China in 2045, to become the most populous country in the world. While global
population has increased threefold during this century, from 2 billion to 6 billion, the population
of India has increased nearly five times from 238 million (23 crores) to 1 billion in the same
period. India's current annual increase in population of 15.5 million is large enough to neutralize
efforts to conserve the resource endowment and environment.
Box 1: India's Demographic Achievement

3
Half a century after formulating the national family welfare programme, India has:
v

reduced crude birth rate (CBR) from 40.8 (1951) to 26.4 (1998, SRS);

v

halved the infant mortality rate (IMR) from 146 per 1000 live births (1951) to 72
per 1000 live births (1998, SRS);

v

quadrupled the couple protection rate (CPR) from 10.4 percent (1971) to 44 percent
(1999);

v

reduced crude death rate (CDR) from 25 (1951) to 9.0 (1998, SRS);

v

added 25 years to life expectancy from 37 years to 62 years;

v

achieved nearly universal awareness of the need for and methods of family
planning, and

v

4.

reduced total fertility rate from 6.0 (1951) to 3.3 (1997, SRS).

India's population in 1991 and projections to 2016 are as follows:
Table 1: Population Projections for India (million)3

1

March 1991

March 2001

March 2011

March 2016

846.3

1012.4

1178.9

1263.5

Milestones in the Evolution of the Population Policy are listed at Appendix II, page 30
TFR: Average number of children born to a woman during her lifetime.
3
Source: Technical Group on Population Projections,Planning Commission.
2

<!-- page 4 -->

5.

Stabilising population is an essential requirement for promoting sustainable development with
more equitable distribution. However, it is as much a function of making reproductive health
care accessible and affordable for all, as of increasing the provision and outreach of primary
and secondary education, extending basic amenities including sanitation, safe drinking water
and housing, besides empowering women and enhancing their employment opportunities,
and providing transport and communications.

6.

The National Population Policy, 2000 (NPP 2000) affirms the commitment of government towards
voluntary and informed choice and consent of citizens while availing of reproductive health
care services, and continuation of the target free approach in administering family planning
services. The NPP 2000 provides a policy framework for advancing goals and prioritizing
strategies during the next decade, to meet the reproductive and child health needs of the
people of India, and to achieve net replacement levels (TFR) by 2010. It is based upon the
need to simultaneously address issues of child survival, maternal health, and contraception,
while increasing outreach and coverage of a comprehensive package of reproductive and
child heath services by government, industry and the voluntary non-government sector, working
in partnership.

B.

OBJECTIVES

7.

The immediate objective of the NPP 2000 is to address the unmet needs for contraception,
health care infrastructure, and health personnel, and to provide integrated service delivery for
basic reproductive and child health care. The medium-term objective is to bring the TFR to

4

replacement levels by 2010, through vigorous implementation of inter-sectoral operational
strategies. The long-term objective is to achieve a stable population by 2045, at a level
consistent with the requirements of sustainable economic growth, social development, and
environmental protection.
8.

In pursuance of these objectives, the following National Socio-Demographic Goals to be
achieved in each case by 2010 are formulated:
Box 2: National Socio-Demographic Goals for 2010
(1)

Address the unmet needs for basic reproductive and child health services, supplies
and infrastructure.

(2)

Make school education up to age 14 free and compulsory, and reduce drop outs
at primary and secondary school levels to below 20 percent for both boys and
girls.

(3)

Reduce infant mortality rate to below 30 per 1000 live births.

(4)

Reduce maternal mortality ratio to below 100 per 100,000 live births.

(5)

Achieve universal immunization of children against all vaccine preventable
diseases.

(6)

Promote delayed marriage for girls, not earlier than age 18 and preferably after
20 years of age.

<!-- page 5 -->

(7)

Achieve 80 percent institutional deliveries and 100 percent deliveries by trained
persons.

(8)

Achieve universal access to information/counseling, and services for fertility
regulation and contraception with a wide basket of choices.

(9)

Achieve 100 per cent registration of births, deaths, marriage and pregnancy.

(10)

Contain the spread of Acquired Immunodeficiency Syndrome (AIDS), and promote
greater integration between the management of reproductive tract infections (RTI)
and sexually transmitted infections (STI) and the National AIDS Control
Organisation.

(11)

Prevent and control communicable diseases.

(12)

Integrate Indian Systems of Medicine (ISM) in the provision of reproductive and
child health services, and in reaching out to households.

(13)

Promote vigorously the small family norm to achieve replacement levels of TFR.

(14)

Bring about convergence in implementation of related social sector programs so
that family welfare becomes a people centred programme.

If the NPP 2000 is fully implemented, we anticipate a population of 1107 million (110 crores) in 2010,
instead of 1162 million (116 crores) projected by the Technical Group on Population Projections:
Table 2: Anticipated Growth in Population (million)

Year

1991
1996
1997
2000
2002
2010

If current trends continue

If TFR 2.1 is achieved by 2010

Total
Population

Increase in
population

Total
population

Increase in
population

846.3
934.2
949.9
996.9
1027.6
1162.3

17.6
15.7
15.7
15.4
16.8

846.3
934.2
949.0
991.0
1013.0
1107.0

17.6
14.8
14.0
11.0
11.75

Similarly, the anticipated reductions in the birth, infant mortality and total fertility rates are:

Table 3: Projections of Crude Birth Rate, Infant Mortality Rate, and TFR,
if the NPP 2000 is fully implemented.
Year

Crude Birth Rate

Infant Mortality Rate

Total Fertility Rate

1997
1998
2002
2010

27.2
26.4
23.0
21.0

71
72
50
30

3.3
3.3
2.6
2.1

Source for Tables 2 and 3: Ministry of Health and Family Welfare

5

<!-- page 6 -->

9.

Population growth in India continues to be high on account of :
F

The large size of the population in the reproductive age-group (estimated contribution
58 percent). An addition of 417.2 million between 1991 and 2016 is anticipated despite
substantial reductions in family size in several states, including those which have already
achieved replacement levels of TFR. This momentum of increase in population will
continue for some more years because high TFRs in the past have resulted in a large
proportion of the population being currently in their reproductive years. It is imperative
that the the reproductive age group adopts without further delay or exception the "small
family norm", for the reason that about 45 percent of population increase is contributed
by births above two children per family.

F

Higher fertility due to unmet need for contraception (estimated contribution 20 percent).
India has 168 million eligible couples, of which just 44 percent are currently effectively
protected. Urgent steps are currently required to make contraception more widely
available, accessible, and affordable. Around 74 percent of the population lives in rural
areas, in about 5.5 lakh villages, many with poor communications and transport.
Reproductive health and basic health infrastructure and services often do not reach the
villages, and, accordingly, vast numbers of people cannot avail of these services.

F

High wanted fertility due to the high infant mortality rate (IMR) (estimated contribution
about 20 percent). Repeated child births are seen as an insurance against multiple
infant (and child) deaths and accordingly, high infant mortality stymies all efforts at

6

reducing TFR.
F

Over 50 percent of girls marry below the age of 18, the minimum legal age of marriage,
resulting in a typical reproductive pattern of "too early, too frequent, too many". Around
33 percent births occur at intervals of less than 24 months, which also results in high
IMR.

The country's demographic profile is given in Appendix III (pages 32-35).

C.

STRATEGIC THEMES

10.

We identify 12 strategic themes which must be simultaneously pursued in "stand alone" or
inter-sectoral programmes in order to achieve the national socio-demographic goals for 2010.
These are presented below:

(i)
11.

Decentralised Planning and Programme Implementation

The 73rd and 74th Constitutional Amendments Act, 1992, made health, family welfare, and
education a responsibility of village panchayats. The panchayati raj institutions are an important
means of furthering decentralised planning and programme implementation in the context of
the NPP 2000. However, in order to realize their potential, they need strengthening by further
delegation of administrative and financial powers, including powers of resource mobilization.

<!-- page 7 -->

Further, since 33 percent of elected panchayat seats are reserved for women, representative
committees of the panchayats (headed by an elected woman panchayat member) should be
formed to promote a gender sensitive, multi-sectoral agenda for population stabilisation, that
will "think, plan and act locally, and support nationally". These committees may identify areaspecific unmet needs for reproductive health services, and prepare need-based, demanddriven, socio-demographic plans at the village level, aimed at identifying and providing
responsive, people-centred and integrated, basic reproductive and child health care. Panchayats
demonstrating exemplary performance in the compulsory registration of births, deaths,
marriages, and pregnancies, universalizing the small family norm, increasing safe deliveries,
bringing about reductions in infant and maternal mortality, and promoting compulsory education
up to age 14, will be nationally recognized and honored.

(ii)
12.

Convergence of Service Delivery at Village Levels

Efforts at population stabilisation will be effective only if we direct an integrated package of
essential services at village and household levels. Below district levels, current health
infrastructure includes 2,500 community health centres, 25,000 primary health centres (each
covering a population of 30,000), and 1.36 lakh subcentres (each covering a population of
5,000 in the plains and 3,000 in hilly regions)4. Inadequacies in the existing health infrastructure
have led to an unmet need of 28 percent for contraception services, and obvious gaps in
coverage and outreach. Health care centres are over-burdened and struggle to provide services
with limited personnel and equipment. Absence of supportive supervision, lack of training in
inter-personal communication, and lack of motivation to work in rural areas, together impede
citizens' access to reproductive and child health services, and contribute to poor quality of
services and an apparent insensitivity to client's needs. The last 50 years have demonstrated
the unsuitability of these yardsticks for provision of health care infrastructure, particularly for
remote, inaccessible, or sparsely populated regions in the country like hilly and forested areas,
desert regions and tribal areas. We need to promote a more flexible approach, by extending
basic reproductive and child health care through mobile clinics and counseling services. Further,
recognizing that government alone cannot make up for the inadequacies in health care
infrastructure and services, in order to resolve unmet needs and extend coverage, the
involvement of the voluntary sector and the non-government sector in partnership with the
government is essential.

13.

Since the management, funding, and implementation of health and education programmes has been
decentralised to panchayats, in order to reach household levels, a one-stop, integrated and coordinated
service delivery should be provided at village levels, for basic reproductive and child health services.
A vast increase in the number of trained birth attendants, at least two per village, is necessary to
universalise coverage and outreach of ante-natal, natal and post-natal health care. An equipped
maternity hut in each village should be set up to serve as a delivery room, with functioning midwifery
kits, basic medication for essential obstetric aid, and indigenous medicines and supplies for
maternal and new born care. A key feature of the integrated service delivery will be the registration
at village levels, of births, deaths, marriage, and pregnancies. Each village should maintain a list of
community midwives and trained birth attendants, village health guides, panchayat sewa sahayaks,
primary school teachers and aanganwadi workers who may be entrusted with various responsibilities
in the implementation of integrated service delivery.

4

Source: MOHFW Statistics, 1998.

7

<!-- page 8 -->

14.

The panchayats should seek the help of community opinion makers to communicate the benefits
of smaller, healthier families, the significance of educating girls, and promoting female
participation in paid employment. They should also involve civil society in monitoring the
availability, accessibility and affordability of services and supplies.
Operational strategies are described in the Action Plan at Appendix I (pages16-17).

(iii)
15.

Empowering Women for Improved Health and Nutrition

The complex socio-cultural determinants of women's health and nutrition have cumulative
effects over a lifetime. Discriminatory childcare leads to malnutrition and impaired physical
development of the girl child. Undernutrition and micronutrient deficiency in early adolescence
goes beyond mere food entitlements to those nutrition related capabilities that become crucial
to a woman's well-being, and through her, to the well-being of children. The positive effects
of good health and nutrition on the labour productivity of the poor is well documented. To the
extent that women are over-represented among the poor, interventions for improving women's
health and nutrition are critical for poverty reduction.

16.

Impaired health and nutrition is compounded by early childbearing, and consequent risk of
serious pregnancy related complications. Women's risk of premature death and disability is
highest during their reproductive years. Malnutrition, frequent pregnancies, unsafe abortions,
RTI and STI, all combine to keep the maternal mortality ratio in India among the highest globally.

8
17.

Maternal mortality is not merely a health disadvantage, it is a matter of social injustice. Low
social and economic status of girls and women limits their access to education, good nutrition,
as well as money to pay for health care and family planning services. The extent of maternal
mortality is an indicator of disparity and inequity in access to appropriate health care and
nutrition services throughout a lifetime, and particularly during pregnancy and child-birth, and
is a crucial factor contributing to high maternal mortality.

18.

Programmes for Safe Motherhood, Universal Immunisation, Child Survival and Oral Rehydration
have been combined into an Integrated Reproductive and Child Health Programme, which
also includes promoting management of STIs and RTIs. Women's health and nutrition problems
can be largely prevented or mitigated through low cost interventions designed for low income
settings.

19.

The voluntary non-government sector and the private corporate sector should actively
collaborate with the community and government through specific commitments in the areas of
basic reproductive and child health care, basic education, and in securing higher levels of
participation in the paid work force for women.
Operational strategies are described in the Action Plan at Appendix I (pages 17-20).

<!-- page 9 -->

(iv)
20.

Child Health and Survival

Infant mortality is a sensitive indicator of human development. High mortality and morbidity
among infants and children below 5 years occurs on account of inadequate care, asphyxia
during birth, premature birth, low birth weight, acute respiratory infections, diarrhoea, vaccine
preventable diseases, malnutrition and deficiencies of nutrients, including Vitamin A. Infant
mortality rates have not significantly declined in recent years.

21.

Our priority is to intensify neo-natal care. A National Technical Committee should be set up,
consisting principally of consultants in obstetrics, pediatrics (neonatologists), family health,
medical research and statistics from among academia, public health professionals, clinical
practitioners and government. Its terms of reference should include prescribing perinatal audit
norms, developing quality improvement activities with monitoring schedules and suggestions
for facilitating provision of continuing medical and nursing education to all perinatal health care
providers. Implementation at the grass-roots must benefit from current developments in the
fields of perinatology and neonatology. The baby friendly hospital initiative (BFHI) should be
extended to all hospitals and clinics, up to subcentre levels. Additionally, besides promoting
breast-feeding and complementary feeds, the BFHI should include updating of skills of trained
birth attendants to improve new born care practices to reduce the risks of hypothermia and
infection. Essential equipment for the new born must be provided at subcentre levels.

22.

Child survival interventions i.e. universal immunisation, control of childhood diarrhoeas with
oral rehydration therapies, management of acute respiratory infections, and massive doses of
Vitamin A and food supplements have all helped to reduce infant and child mortality and morbidity.
With intensified efforts, the eradication of polio is within reach. However, the decline in standards,
outreach and quality of routine immunisation is a matter of concern. Significant improvements
need to be made in the quality and coverage of the routine immunisation programme.
Operational strategies are described in the Action Plan at Appendix I (pages 21-22).

(v)
23.

Meeting the Unmet Needs for Family Welfare Services

In both rural and urban areas there continue to be unmet needs for contraceptives, supplies
and equipment for integrated service delivery, mobility of health providers and patients, and
comprehensive information. It is important to strengthen, energise and make accountable the
cutting edge of health infrastructure at the village, subcentre and primary health centre levels,
to improve facilities for referral transportation, to encourage and strengthen local initiatives for
ambulance services at village and block levels, to increase innovative social marketing schemes
for affordable products and services and to improve advocacy in locally relevant and acceptable
dialects.
Operational strategies are described in the Action Plan in Appendix I (page 22).

9

<!-- page 10 -->

(vi)

Under-Served Population Groups
(a)

24.

Urban Slums

Nearly 100 million people live in urban slums, with little or no access to potable water,
sanitation facilities, and health care services. This contributes to high infant and child mortality,
which in turn perpetuate high TFR and maternal mortality. Basic and primary health care,
including reproductive and child health care, needs to be provided. Coordination with municipal
bodies for water, sanitation and waste disposal must be pursued, and targeted information,
education and communication campaigns must spread awareness about the secondary and
tertiary facilities available.
Operational strategies are described in the Action Plan in Appendix I (pages 22-23).
(b)

Tribal Communities, Hill Area Populations and Displaced and Migrant
Populations

25.

In general, populations in remote and low density areas do not have adequate access to
affordable health care services. Tribal populations often have high levels of morbidity arising
from poor nutrition, particularly in situations where they are involuntarily displaced or resettled.
Frequently, they have low levels of literacy, coupled with high infant, child, and maternal mortality.
They remain under-served in the coverage of reproductive and child health services. These

10

communities need special attention in terms of basic health, and reproductive and child health
services. The special needs of tribal groups which need to be addressed include the provision
of mobile clinics that will be responsive to seasonal variations in the availability of work and
income. Information and counseling on infertility, and regular supply of standardised medication
will be included.
Operational strategies are described in the Action Plan at Appendix I (pages 23).
(c)
26.

Adolescents

Adolescents represent about a fifth of India's population. The needs of adolescents, including
protection from unwanted pregnancies and sexually transmitted diseases (STD), have not
been specifically addressed in the past. Programmes should encourage delayed marriage
and child-bearing, and education of adolescents about the risks of unprotected sex. Reproductive
health services for adolescent girls and boys is especially significant in rural India, where
adolescent marriage and pregnancy are widely prevalent. Their special requirements comprise
information, counseling, population education, and making contraceptive services accessible
and affordable, providing food supplements and nutritional services through the ICDS, and
enforcing the Child Marriage Restraint Act, 1976.
Operational strategies are described in the Action Plan in Appendix I (page 24).

<!-- page 11 -->

(d)
27.

Increased Participation of Men in Planned Parenthood

In the past, population programmes have tended to exclude menfolk. Gender inequalities in
patriarchal societies ensure that men play a critical role in determining the education and
employment of family members, age at marriage, besides access to and utilisation of health,
nutrition, and family welfare services for women and children. The active involvement of men
is called for in planning families, supporting contraceptive use, helping pregnant women stay
healthy, arranging skilled care during delivery, avoiding delays in seeking care, helping after
the baby is born and, finally, in being a responsible father. In short, the active cooperation and
participation of men is vital for ensuring programme acceptance. Further, currently, over 97
percent of sterilisations are tubectomies and this manifestation of gender imbalance needs to
be corrected. The special needs of men include re-popularising vasectomies, in particular noscalpel vasectomy as a safe and simple procedure, and focusing on men in the information
and education campaigns to promote the small family norm.
Operational strategies are described in the Action Plan in Appendix I (page 24).

(vii) Diverse Health Care Providers
28.

Given the large unmet need for reproductive and child health services, and inadequacies in
health care infrastructure it is imperative to increase the numbers and diversify the categories
of health care providers. Ways of doing this include accrediting private medical practitioners
and assigning them to defined beneficiary groups to provide these services; revival of the
system of licensed medical practitioner who, after appropriate certification from the Indian
Medical Association (IMA), could provide specified clinical services.
Operational strategies are described in the Action Plan at Appendix I (pages 24-25).

(viii) Collaboration With and Commitments from Non-Government Organisations and
the Private Sector
29.

A national effort to reach out to households cannot be sustained by government alone. We
need to put in place a partnership of non-government voluntary organizations, the private
corporate sector, government and the community. Triggered by rising incomes and institutional
finance, private health care has grown significantly, with an impressive pool of expertise and
management skills, and currently accounts for nearly 75 percent of health care expenditures.
However, despite their obvious potential, mobilising the private (profit and non-profit) sector to
serve public health goals raises governance issues of contracting, accreditation, regulation,
referral, besides the appropriate division of labour between the public and private health
providers, all of which need to be addressed carefully. Where government interventions or
capacities are insufficient, and the participation of the private sector unviable, focused service
delivery by NGOs may effectively complement government efforts.
Operational strategies are described in the Action Plan in Appendix I (pages 25-27).

11

<!-- page 12 -->

(ix)

Mainstreaming Indian Systems of Medicine and Homeopathy

30.

India's community supported ancient but living traditions of indigenous systems of medicine
has sustained the population for centuries, with effective cures and remedies for numerous
conditions, including those relating to women and children, with minimal side effects. Utilisation
of ISMH in basic reproductive and child health care will expand the pool of effective health
care providers, optimise utilisation of locally based remedies and cures, and promote lowcost health care. Guidelines need to be evolved to regulate and ensure standardisation, efficacy
and safety of ISMH drugs for wider entry into national markets.

31.

Particular challenges include providing appropriate training, and raising awareness and skill
development in reproductive and child health care to the institutionally qualified ISMH medical
practitioners. The feasibility of utilising their services to fill in gaps in manpower at village
levels, and at subcentres and primary health centres may be explored. ISMH institutions,
hospitals and dispensaries may be utilised for reproductive and child health care programmes.
At village levels, the services of the ISMH "barefoot doctors", after appropriate training, may
be utilised for advocacy and counseling, for distributing supplies and equipment, and as
depot holders. ISMH practices may be applied at village maternity huts, and at household
levels, for ante-natal, natal and post natal care, and for nurture of the new born.
Operational strategies are described in the Action Plan in Appendix I (page 27).

(x)
12

Contraceptive Technology and Research on Reproductive and Child Health

32.

Government must constantly advance, encourage, and support medical, social science,
demographic and behavioural science research on maternal, child and reproductive health
care issues. This will improve medical techniques relevant to the country's needs, and strengthen
programme and project design and implementation. Consultation and frequent dialogue by
Government with the existing network of academic and research institutions in allopathy and
ISMH, and with other relevant public and private research institutions engaged in social science,
demography and behavioural research must continue. The International Institute of Population
Sciences, and the population research centres which have been set up to pursue applied
research in population related matters, need to be revitalised and strengthened.

33.

Applied research relies upon constant monitoring of performance at the programme and project
levels. The National Health and Family Welfare Survey provides data on key health and family
welfare indicators every five years. Data from the first National Family Health Survey (NFHS1), 1992-93, has been updated by NFHS-2, 1998-99, to be published shortly. Annual data is
generated by the Sample Registration Survey, which, inter alia, maps at state levels the birth,
death and infant mortality rates. Absence of regular feedback has been a weakness in the
family welfare progamme. For this reason, the Department of Family Welfare is strengthening
its management information systems (MIS) and has commenced during 1998, a system of
ascertaining impacts and outcomes through district surveys and facility surveys. The district
surveys cover 50% districts every year, so that every 2 years there is an update on every
district in the country. The facility surveys ascertain the availability of infrastructure and services
up to primary health centre level, covering one district per month. The feedback from both
these surveys enable remedial action at district and sub-district levels.
Operational strategies are described in the Action Plan in Appendix I (page 27).

<!-- page 13 -->

(xi)
34.

Providing for the Older Population

Improved life expectancy is leading to an increase in the absolute number and proportion of
persons aged 60 years and above, and is anticipated to nearly double during 1996-2016, from
62.3 million to 112.9 million5 . When viewed in the context of significant weakening of traditional
support systems, the elderly are increasingly vulnerable, needing protection and care.
Promoting old age health care and support will, over time, also serve to reduce the incentive
to have large families.

35.

The Ministry of Social Justice and Empowerment has adopted in January 1999 a National
Policy on Older Persons. It has become important to build in geriatric health concerns in the
population policy. Ways of doing this include sensitising, training and equipping rural and
urban health centres and hospitals for providing geriatric health care; encouraging NGOs to
design and implement formal and informal schemes that make the elderly economically selfreliant; providing for and routinising screening for cancer, osteoporosis, and cardiovascular
conditions in primary health centres, community health centres, and urban health care centres
at primary, secondary and tertiary levels; and exploring tax incentives to encourage grown-up
children to look after their aged parents.
Operational strategies are described in the Action Plan in Appendix I (page 28).

(xii)

Information, Education, and Communication
13

36.

Information, education and communication (IEC) of family welfare messages must be clear,
focused and disseminated everywhere, including the remote corners of the country, and in
local dialects. This will ensure that the messages are effectively conveyed. These need to be
strengthened and their outreach widened, with locally relevant, and locally comprehensible
media and messages. On the model of the total literacy campaigns which have successfully
mobilised local populations, there is need to undertake a massive national campaign on
population related issues, via artists, popular film stars, doctors, vaidyas, hakims, nurses,
local midwives, women's organizations, and youth organizations.
Operational strategies are described in the Action Plan in Appendix I (pages 28-29).

D.

LEGISLATION

37.

As a motivational measure, in order to enable state governments to fearlessly and effectively
pursue the agenda for population stabilisation contained in the National Population Policy,
2000, one legislation is considered necessary. It is recommended that the 42nd Constitutional
Amendment that freezes till 2001, the number of seats to the Lok Sabha and the Rajya Sabha
based on the 1971 Census be extended up to 2026.

5

Source: Technical group on Population Projections, Planning Commission.

<!-- page 14 -->

E.

PUBLIC SUPPORT

38.

Demonstration of strong support to the small family norm, as well as personal example, by
political, community, business, professional and religious leaders, media and film stars, sports
personalities, and opinion makers, will enhance its acceptance throughout society. The
government will actively enlist their support in concrete ways.

F.

NEW STRUCTURES

39.

The NPP 2000 is to be largely implemented and managed at panchayat and nagar palika
levels, in coordination with the concerned state/Union Territory administrations. Accordingly,
the specific situation in each state/UT must be kept in mind. This will require comprehensive
and multisectoral coordination of planning and implementation between health and family welfare
on the one hand, along with schemes for education, nutrition, women and child development,
safe drinking water, sanitation, rural roads, communications, transportation, housing, forestry
development, environmental protection, and urban development. Accordingly, the following
structures are recommended:

(i)
40.

National Commission on Population

A National Commission on Population, presided over by the Prime Minister, will have the
Chief Ministers of all states and UTs, and the Central Minister in charge of the Department of
Family Welfare and other concerned Central Ministries and Departments, for example

14

Department of Woman and Child Development, Department of Education, Department of
Social Justice and Empowerment in the Ministry of HRD, Ministry of Rural Development,
Ministry of Environment and Forest, and others as necessary, and reputed demographers,
public health professionals, and NGOs as members. This Commission will oversee and review
implementation of policy. The Commission Secretariat will be provided by the Department of
Family Welfare.

(ii)
41.

State / UT Commissions on Population

Each state and UT may consider having a State / UT Commission on Population, presided
over by the Chief Minister, on the analogy of the National Commission, to likewise oversee and
review implementation of the NPP 2000 in the state / UT.

(iii)
42.

Coordination Cell in the Planning Commission

The Planning Commission will have a Coordination Cell for inter-sectoral coordination between
Ministries for enhancing performance, particularly in States/UTs needing special attention
on account of adverse demographic and human development indicators.

<!-- page 15 -->

(iv)
43.

Technology Mission in the Department of Family Welfare

To enhance performance, particularly in states with currently below average socio-demographic
indices that need focused attention, a Technology Mission in the Department of Family Welfare
will be established to provide technology support in respect of design and monitoring of projects
and programmes for reproductive and child health, as well as for IEC campaigns.

G. FUNDING
44.

The programmes, projects and schemes premised on the goals and objectives of the NPP
2000, and indeed all efforts at population stabilisation, will be adequately funded in view of
their critical importance to national development. Preventive and promotive services such as
ante-natal and post-natal care for women, immunisation for children, and contraception will
continue to be subsidised for all those who need the services. Priority in allocation of funds will
be given to improving health care infrastructure at the community and primary health centres,
subcentre and village levels. Critical gaps in manpower will be remedied through redeployment,
particularly in under-served and inaccessible areas, and referral linkages will be improved. In
order to implement immediately the Action Plan, it would be necessary to double the annual
budget of the Department of Family Welfare to enable government to address the shortfall in
unmet needs for health care infrastructure, services and supplies (in Appendix IV, page 36).

45.

Even though the annual budget for population stabilisation activities assigned to the Department
of Family Welfare has increased over the years, at least 50 percent of the budgetary outlay
is deployed towards non-plan activities (recurring expenditures for maintenance of health care
infrastructure in the states and UTs, and towards salaries). To illustrate, of the annual budget of
Rs. 2920 crores for 1999-2000, nearly Rs 1500 crores is allocated towards non-plan activities.
Only the remaining 50 percent becomes available for genuine plan activities, including
procurement of supplies and equipment. For these reasons, since 1980 the Department of
Family Welfare has been unable to revise norms of operational costs of health infrastructure,
which in turn has impacted directly the quality of care and outreach of services provided.

H.

PROMOTIONAL AND MOTIVATIONAL MEASURES FOR
ADOPTION OF THE SMALL FAMILY NORM

46.

The following promotional and motivational measures will be undertaken:
(i)

Panchayats and Zila Parishads will be rewarded and honoured for exemplary
performance in universalising the small family norm, achieving reductions in infant
mortality and birth rates, and promoting literacy with completion of primary schooling.

(ii)

The Balika Samridhi Yojana run by the Department of Women and Child Development,
to promote survival and care of the girl child, will continue. A cash incentive of Rs. 500
is awarded at the birth of the girl child of birth order 1 or 2.

15

<!-- page 16 -->

(iii)

Maternity Benefit Scheme run by the Department of Rural Development will continue. A
cash incentive of Rs. 500 is awarded to mothers who have their first child after 19 years
of age, for birth of the first or second child only. Disbursement of the cash award will in
future be linked to compliance with ante-natal check up, institutional delivery by trained
birth attendant, registration of birth and BCG immunisation.

(iv)

A Family Welfare-linked Health Insurance Plan will be established. Couples below the
poverty line, who undergo sterilisation with not more than two living children, would
become eligible (along with children) for health insurance (for hospitalisation) not
exceeding Rs. 5000, and a personal accident insurance cover for the spouse undergoing
sterilisation.

(v)

Couples below the poverty line, who marry after the legal age of marriage, register the
marriage, have their first child after the mother reaches the age of 21, accept the small
family norm, and adopt a terminal method after the birth of the second child, will be
rewarded.

(vi)

A revolving fund will be set up for income-generating activities by village-level self help
groups, who provide community-level health care services.

(vii)

Crèches and child care centres will be opened in rural areas and urban slums. This will
facilitate and promote participation of women in paid employment.

16
(viii)

A wider, affordable choice of contraceptives will be made accessible at diverse delivery
points, with counseling services to enable acceptors to exercise voluntary and informed
consent.

(ix)

Facilities for safe abortion will be strengthened and expanded.

(x)

Products and services will be made affordable through innovative social marketing
schemes.

(xi)

Local entrepreneurs at village levels will be provided soft loans and encouraged to run
ambulance services to supplement the existing arrangements for referral transportation.

(xii)

Increased vocational training schemes for girls, leading to self-employment will be
encouraged.

(xiii)

Strict enforcement of Child Marriage Restraint Act, 1976.

(xiv) Strict enforcement of the Pre-Natal Diagnostic Techniques Act, 1994.
(xv)

Soft loans to ensure mobility of the ANMs will be increased.

<!-- page 17 -->

(xvi)

The 42nd Constitutional Amendment has frozen the number of representatives in the Lok
Sabha (on the basis of population) at 1971 Census levels. The freeze is currently valid
until 2001, and has served as an incentive for State Governments to fearlessly pursue the
agenda for population stabilisation. This freeze needs to be extended until 2026.

I.

CONCLUSION

47.

In the new millenium, nations are judged by the well-being of their peoples; by levels of health,
nutrition and education; by the civil and political liberties enjoyed by their citizens; by the
protection guaranteed to children and by provisions made for the vulnerable and the
disadvantaged.

48.

The vast numbers of the people of India can be its greatest asset if they are provided with the
means to lead healthy and economically productive lives. Population stabilisation is a multisectoral endeavour requiring constant and effective dialogue among a diversity of stakeholders,
and coordination at all levels of the government and society. Spread of literacy and education,
increasing availability of affordable reproductive and child health services, convergence of
service delivery at village levels, participation of women in the paid work force, together with a
steady, equitable improvement in family incomes, will facilitate early achievement of the
socio-demographic goals. Success will be achieved if the Action Plan contained in the NPP
2000 is pursued as a national movement.

17

<!-- page 18 -->

Appendix I

NATIONAL POPULATION POLICY, 2000
ACTION PLAN
Operational Strategies
(i) & (ii) Converge Service Delivery at Village Levels
1.

Utilise village self help groups to organise and provide basic services for reproductive and
child health care, combined with the ongoing Integrated Child Development Scheme (ICDS).
Village self help groups are in existence through centrally sponsored schemes of: (a)
Department of Women and Child Development, Ministry of HRD, (b) Ministry of Rural
Development, and (c) Ministry of Environment and Forests. Organise neighbourhood acceptor
groups, and provide them with a revolving fund that may be accessed for income generation
activities. The groups may establish rules of eligibility, interest rates, and accountability for
which capital may be advanced, usually to be repaid in installments within two years. The
repayments may be used to fund another acceptor group in a nearby community, who would
exert pressure to ensure timely repayments. Two trained birth attendants and the aanganwadi
worker (AWW) should be members of this group.

2.

Implement at village levels a one-stop integrated and coordinated service delivery package for
basic health care, family planning and maternal and child health related services, provided by

18

the community and for the community. Train and motivate the village self-help acceptor groups to
become the primary contact at household levels. Once every fortnight, these acceptor groups
will meet, and provide at one place 6 different services for (i) registration of births, deaths,
marriage and pregnancy; (ii) weighing of children under 5 years, and recording the weight on a
standard growth chart; (iii) counseling and advocacy for contraception, plus free supply of
contraceptives; (iv) preventive care, with availability of basic medicines for common ailments:
antipyretics for fevers, antibiotic ointments for infections, ORT /ORS1 for childhood diarrhoeas,
together with standardised indigenous medication and homeopathic cures; (v) nutrition
supplements; and (vi) advocacy and encouragement for the continued enrolment of children in
school up to age 14. One health staff, appointed by the panchayat, will be suitably trained to
provide guidance. Clustering services for women and children at one place and time at village
levels will promote positive interactions in health benefits and reduce service delivery costs.
3.

Wherever these village self-help groups have not developed for any reason, community
midwives, practitioners of ISMH, retired school teachers and ex-defence personnel may be
organised into neighbourhood groups to perform similar functions.

4.

At village levels, the aanganwadi centre may become the pivot of basic health care activities,
contraceptive counseling and supply, nutrition education and supplementation,

as well as

pre-school activities. The aanganwadi centres can also function as depots for ORS/basic
medicines and contraceptives.

1

Oral Rehydration Therapy /Oral Rehydration Salts

<!-- page 19 -->

5.

A maternity hut should be established in each village to be used as the village delivery room,
with storage space for supplies and medicines. It should be adequately equipped with kits for
midwifery, ante-natal care, and delivery; basic medication for obstetric emergency aid;
contraceptives, drugs and medicines for common ailments; and indigenous medicines/supplies
for maternal and new-born care. The panchayat may appoint a competent and mature midwife, to look after this village maternity hut. She may be assisted by volunteers.

6.

Trained birth attendants as well as the vast pool of traditional dais should be made familiar with
emergency and referral procedures. This will greatly assist the Auxiliary Nurse Midwife (ANM)
at the subcentres to monitor and respond to maternal morbidity/emergencies at village levels.

7.

Each village may maintain a list of community mid-wives, village health guides, panchayat
sewa sahayaks, trained birth attendants, practitioners of indigenous systems of medicine,
primary school teachers and other relevant persons, as well as the nearest institutional health
care facilities that may be accessed for integrated service delivery. These persons may also
be helpful in involving civil society in monitoring availability, quality and accessibility of
reproductive and child health services; in disseminating education and communication on the
benefits of smaller and healthier families, with emphasis on education of the girl child; and
female participation in the work force.

8.

Provide a wider basket of choices in contraception, through innovative social marketing schemes
to reach household levels.

19
Comment : Meaningful decentralisation will result only if the convergence of the national
family welfare programme with the ICDS programme is strengthened. The focus of the ICDS
programme on nutrition improvement at village levels and on pre-school activities must be
widened to include maternal and child health care services. Convergence of several related
activities at service delivery levels with, in particular, the ICDS programme, is critical for extending
outreach and increasing access to services. Intersectoral coordination with appropriate training
and sensitisation among field functionaries will facilitate dissemination of integrated reproductive
and child health services to village and household levels. People will willingly cooperate in the
registration of births, deaths, marriages and pregnancies if they perceive some benefit. At the
village level, this community meeting every fortnight, may become their most convenient access
to basic health care, both for maternal and child health, as well as for common ailments.
Households may participate to receive integrated service delivery, along with information about
ongoing micro-credit and thrift schemes. Government and non-government functionaries will
be expected to function in harmony to ensure integrated service delivery. The panchayat will
promote this coordination and exercise effective supervision.
(iii) Empowering Women for Improved Health and Nutrition
1.

Create an enabling environment for women and children to benefit from products and services
disseminated under the reproductive and child health programme. Cluster services for women
and children at the same place and time. This promotes positive interactions in health benefits
and reduces service delivery costs.

<!-- page 20 -->

2.

As a measure to empower women, open more child care centres in rural areas and in urban
slums, where a woman worker may leave her children in responsible hands. This will encourage
female participation in paid employment, reduce school drop-out rates, particularly for the girl
child, and promote school enrolment as well. The aanganwadis provide a partial solution.

3.

To empower women, pursue programmes of social afforestation to facilitate access to fuelwood and
fodder. Similarly, pursue drinking water schemes for increasing access to potable water. This will
reduce long absences from home, and the need for large numbers of children to perform such tasks.

4.

In any reward scheme intended for household levels, priority may be given to energy saving
devices such as solar cookers, or provision of sanitation facilities, or extension of telephone
lines. This will empower households, in particular women.

5.

Improve district, sub-district and panchayat-level health management with coordination and
collaboration between district health officer, sub-district health officer and the panchayat for
planning and implementation activities. There is need to:
v

Strengthen the referral network between the district health office, district hospital and
the community health centres, the primary health centres and the subcentres in
management of obstetric and neo-natal complications.

v

Strengthen community health centres to provide comprehensive emergency obstetric
and neo-natal care. These may function as clinical training centres as well. Strengthen
primary health centres to provide essential obstetric and neo-natal care. Strengthen

20

subcentres to provide a comprehensive range of services, with delivery rooms,
counseling for contraception, supplies of free contraceptives, ORS and basic medicines,
together with facilities for immunisation.
v

Establish rigorous problem identification mechanisms through maternal and peri-natal
audit, from village level upwards.

6.

Ensure adequate transportation at village level, subcentre levels, zila parishads, primary health
centres and at community health centres. Identifying women at risk is meaningful only if women
with complications can reach emergency care in time.

7.

Improve the accessibility and quality of maternal and child health services through:
v

Deployment of community mid-wives and additional health providers at village levels;
cluster services for women and children at the same place and time, from village level
upwards, e.g. ante-natal and post-partum care, monitoring infant growth, availability of
contraceptives and medicine kits; and routinised immunisations at subcentre levels.

v

Strengthen the capacity of primary health centres to provide basic emergency obstetric
and neo-natal health care.

v

Involve professional agencies in developing and disseminating training modules for
standard procedures in the management of obstetric and neo-natal cases. The aim
should be to routinise these procedures at all appropriate levels.

v

Improve supervision by developing guidance and supervision checklists.

<!-- page 21 -->

8.

Monitor performance of maternal and child health services at each level by using the maternal
and child health local area monitoring system, which includes monitoring the incidence and
coverage of ante-natal visits, deliveries assisted by trained health care personnel and postnatal visits, among other indicators. The ANM at the subcentre should be responsible and
accountable for registering every pregnancy and child birth in her jurisdiction, and for providing
universal ante-natal and post-natal services.

9.

Improve technical skills of maternal and child health care providers by:
v

Strengthening skills of health personnel and health providers through classroom and
on-the-job training in the management of obstetric and neo-natal emergencies. This
should include training of birth attendants and community midwives at district-level
hospitals in life-saving skills, such as management of asphyxia and hypothermia.

v
10.

Training on integrated management of childhood illnesses for infants (1week - 2 months).

Support community activities such as dissemination of IEC material, including leaflets and
posters, and promotion of folk jatras, songs and dances to promote healthy mother and
healthy baby messages, along with good management practices to ensure safe motherhood,
including early recognition of danger signs.

11.

Programme development, comprising:
v

Partnership in family health and nutrition. The aanganwadi worker will identify women
and children in the villages who suffer from malnutrition and/or micro-nutritional
deficiencies, including iron, vitamin A, and iodine deficiency; provide nutritional
supplements and monitor nutritional status.

v

Convergence, strengthening, and universalisation of the nutritional programmes of the
Department of Family Welfare and the ICDS run by the Department of Women and
Child Development, ensuring training and timely supply of food supplements and
medicines.

v

Include STD/RTI and HIV/AIDS prevention, screening and management, in maternal
and child health services.

v

Provide quality care in family planning, including information, increased contraceptive
choices for both spacing and terminal methods, increase access to good quality and
affordable contraceptive supplies and services at diverse delivery points, counseling about
the safety, efficacy and possible side effects of each method, and appropriate follow-up.

12.

Develop a health package for adolescents.

13.

Expand the availability of safe abortion care. Abortion is legal, but there are barriers limiting
women's access to safe abortion services. Some operational strategies are:
v

Community-level education campaigns should target women, household decision makers
and adolescents about the availability of safe abortion services and the dangers of
unsafe abortion.

21

<!-- page 22 -->

v

Make safe and legal abortion services more attractive to women and household decision
makers by (i) increasing geographic spread; (ii) enhancing affordability; (iii) ensuring
confidentiality and (iv) providing compassionate abortion care, including post-abortion
counseling.

v

Adopt updated and simple technologies that are safe and easy, e.g. manual vacuum
extraction not necessarily dependant upon anaesthesia, or non-surgical techniques which
are non-invasive.

v

Promote collaborative arrangements with private sector health professionals, NGOs
and the public sector, to increase the availability and coverage of safe abortion services,
including training of mid-level providers.

v

Eliminate the current cumbersome procedures for registration of abortion clinics. Simplify
and facilitate the establishment of additional training centres for safe abortions in the
public, private, and NGO sectors. Train these health care providers in provision of clinical
services for safe abortions.

v

Formulate and notify standards for abortion services. Strengthen enforcement
mechanisms at district and sub-district levels to ensure that these norms are followed.

v

Follow norms-based registration of service provision centres, and thereby switch the
onus of meticulous observance of standards onto the provider.

v

Provide competent post-abortion care, including management of complications and
identification of other health needs of post-abortion patients, and linking with appropriate
services. As part of post-abortion care, physicians may be trained to provide family

22

planning counseling and services such as sterilisation, and reversible modern methods
such as IUDs, as well as oral contraceptives and condoms.
v

Modify syllabus and curricula for medical graduates, as well as for continuing education
and in-house learning, to provide for practical training in the newer procedures.

v

Ensure services for termination of pregnancy at primary health centres and at community
health centres.

14.

Develop maternity hospitals at sub-district levels and at community health centres to function
as FRUs for complicated and life-threatening deliveries.

15.

Formulate and enforce standards for clinical services in the public, private, and NGO sectors.

16.

Focus on distribution of non-clinical methods of contraception (condoms and oral contraceptive
pills) through free supply, social marketing as well as commercial sales.

17.

Create a national network consisting of public, private and NGO centres, identified by a common
logo, for delivering reproductive and child health services free to any client. The provider will
be compensated for the service provided, on the basis of a coupon, duly counter-signed by the
beneficiary, and paid for by a system to be devised. The compensation will be identical to
providers across all sectors. The end-user will choose the provider of the service. A group of
management experts will devise checks and balances to prevent misuse.

<!-- page 23 -->

(iv) Child Health and Survival
1.

Support community activities, from village level upwards to monitor early and adequate antenatal, natal and post-natal care. Focus attention on neo-natal health care and nutrition.

2.

Set up a National Technical Committee on neo-natal care, to align programme and project
interventions with newly emerging technologies in neo-natal and peri-natal care.

3.

Pursue compulsory registration of births in coordination with the ICDS Programme.

4.

After the birth of a child, provide counseling and advocacy about contraception, to encourage
adoption of a reversible or a terminal method. This will also contribute to the health and wellbeing of both mother and child.

5.

Improve capacities at health centres in basic midwifery services, essential neo-natal care,
including the management of sick neo-nates outside the hospital.

6.

Sensitise and train health personnel in the integrated management of childhood illnesses.
Standard case management of diarrhoea and acute respiratory infections must be provided at
subcentres and primary health centres, with appropriate training, and adequate equipment.
Besides, training in this sector may be imparted to health care providers at village levels,
especially in indigenous systems.

23
7.

Strengthen critical interventions aimed at bringing about reductions in maternal malnutrition,
morbidity and mortality, by ensuring availability of supplies and equipment at village levels,
and at sub centres.

8.

Pursue rigorously the pulse polio campaign to eradicate polio.

9.

Ensure 100 percent routine immunisation for all vaccine preventable diseases, in particular
tetanus and measles.

10.

As a child survival initiative, explore promotional and motivational measures for couples below
the poverty line who marry after the legal age of marriage, to have the first child after the
mother reaches the age of 21, and adopt a terminal method of contraception after the birth of
the second child.

11.

Children form a vulnerable group and certain sub-groups merit focused attention and
intervention, such as street children and child labourers. Encourage voluntary groups as well
as NGOs to formulate and implement special schemes for these groups of children.

12.

Explore the feasibility of a national health insurance covering hospitalisation costs for children
below 5 years, whose parents have adopted the small family norm, and opted for a terminal
method of contraception after the birth of the second child.

<!-- page 24 -->

13.

Expand the ICDS to include children between 6-9 years of age, specifically to promote and
ensure 100 percent school enrolment, particularly for girls. Promote primary education with
the help of aanganwadi workers, and encourage retention in school till age 14. Education
promotes awareness, late marriages, small family size and higher child survival rates.

14.

Provide vocational training for girls. This will enhance perception of the immediate utility of
educating girls, and gradually raise the average age of marriage. It will also increase enrolment
and retention of girls at primary school, and likely also at secondary school levels. Involve
NGOs, the voluntary sector and the private sector, as necessary, to target employment
opportunities.
(v) Meeting the Unmet Needs for Family Welfare Services

1.

Strengthen, energise and make publicly accountable the cutting edge of health infrastructure
at the village, subcentre and primary health centre levels.

2.

Address on priority the different unmet needs detailed in Appendix IV, in particular, an increase
in rural infrastructure, deployment of sanctioned and appropriately trained health personnel,
and provisioning of essential equipment and drugs.

3.

Formulate and implement innovative social marketing schemes to provide subsidised products
and services in areas where the existing coverage of the public, private and NGO sectors is
insufficient in order to increase outreach and coverage.

24
4.

Improve facilities for referral transportation at panchayat, zilla parishad and primary health
centre levels. At subcentres, provide ANMs with soft loans for purchase of mopeds, to enhance
their mobility. This will increase coverage of ante-natal and post natal check-ups, which, in
turn, and will bring about reductions in maternal and infant mortality.

5.

Encourage local entrepreneurs at village and block levels to start ambulance services through
special loan schemes, with appropriate vehicles to facilitate transportation of persons requiring
emergency as well as essential medical attention.

6.

Provide special loan schemes and make site allotments at village levels to facilitate the starting
of chemist shops for basic medicines and provision for medical first aid.
(vi) Under-Served Population Groups
(a) Urban Slums

1.

Finalise a comprehensive urban health care strategy.

2.

Facilitate service delivery centres in urban slums to provide comprehensive basic health,
reproductive and child health services by NGOs and private sector organisations, including
corporate houses.

<!-- page 25 -->

3.

Promote networks of retired government doctors and para-medical and non-medical personnel
who may function as health care providers for clinical and non-clinical services on remunerative
terms.

4.

Strengthen social marketing programmes for non-clinical family planning products and services
in urban slums.

5.

Initiate specially targeted information, education and communication campaigns for urban
slums on family planning, immunization, ante-natal, natal and post-natal check-ups and other
reproductive health care services. Integrate aggressive health education programmes with
health and medical care programmes , with emphasis on environmental health, personal hygiene
and healthy habits, nutrition education and population education.

6.

Promote inter-sectoral coordination between departments/municipal bodies dealing with
water and sanitation, industry and pollution, housing, transport, education and nutrition,
and women and child development, to deal with unplanned and uncoordinated
settlements.

7.

Streamline the referral systems and linkages between the primary, secondary and tertiary
levels of health care in the urban areas.

8.

Link the provision of continued facilities to urban slum dwellers with their observance of the
small family norm.
(b) Tribal Communities, Hill Area Populations and Displaced and Migrant Populations

1.

Many tribal communities are dwindling in numbers, and may not need fertility regulation. Instead,
they may need information and counseling in respect of infertility.

2.

The NGO sector may be encouraged to formulate and implement a system of preventive
and curative health care that responds to seasonal variations in the availability of work,
income and food for tribal and hill area communities and migrant and displaced
populations. To begin with, mobile clinics may provide some degree of regular coverage
and outreach.

3.

Many tribal communities are dependent upon indigenous systems of medicine which
necessitates a regular supply of local flora, fauna and minerals, or of standardised medication
derived from these. Husbandry of such local resources and of preparation and distribution of
standardised formulations should be encouraged.

4.

Health care providers in the public, private and NGOs sectors should be sensitised to
adopt a "burden of disease" approach to meet the special needs of tribal and hill area
communities.

25

<!-- page 26 -->

(c) Adolescents
1.

Ensure for adolescents access to information, counseling and services, including reproductive
health services, that are affordable and accessible. Strengthen primary health centres and
subcentres, to provide counseling, both to adolescents and also to newly weds (who may also
be adolescents). Emphasise proper spacing of children.

2.

Provide for adolescents the package of nutritional services available under the ICDS programme.

Comment: Improvements in health status of adolescent girls has an inter-generational impact.
It reduces the risk of low birth weight and minimizes neo-natal mortality. Malnutrition is a
problem that seriously impairs the health of adolescent and adult women and has its roots in
early childhood. The causal linkages between anaemia and low birth weight, prematurity, perinatal mortality, and maternal mortality has been extensively studied and established.
3.

Enforce the Child Marriage Restraint Act, 1976, to reduce the incidence of teenage pregnancies.
Preventing the marriage of girls below the legally permissible age of 18 should become a
national concern.

Comment: It will promote higher retention of girls at schools, and is also likely to encourage
their participation in the paid work force.

26

4.

Provide integrated intervention in pockets with unmet needs in the urban slums, remote rural
areas, border districts and among tribal populations.
(d) Increased Participation of Men in Planned Parenthood

1.

Focus attention on men in the information and education campaigns to promote the small
family norm, and to raise awareness by emphasising the significant benefits of fewer children,
better spacing, better health and nutrition, and better education.

2.

Currently, over 97 percent of the sterilisations are tubectomies. Repopularise vasectomies, in
particular the no-scalpel vasectomy, as a safe, simple, painless procedure, more convenient
and acceptable to men.

3.

In the continuing education and training at all levels, there is need to ensure that the noscalpel vasectomy, and all such emerging techniques and skills are included in the syllabi,
together with abundant practical training. Medical graduates, and all those participating in "inservice" continuing education and training, will be equipped to handle this intervention.
(vii) Diverse Health Care Providers

1.

At district and sub-district levels, maintain block-wise data base of private medical practitioners
whose credentials may be certified by the Indian Medical Association (IMA). Explore the
possibility of accrediting these private practitioners for a year at a time, and assign to each a

<!-- page 27 -->

satellite population, not exceeding 5,000 (depending upon distances and spread), for whom
they may provide reproductive and child health services. The private practitioners would be
compensated for the services rendered through designated agencies. Renewal of contracts
after one year may be guided by client satisfaction. This will serve as an incentive to expand
the coverage and outreach of high quality health care. Appropriate checks and balances will
safeguard misuse.
2.

Revive the earlier system of the licensed medical practitioners who, after appropriate
certification from the IMA, may participate in the provision of clinical services.

3.

Involve the non-medical fraternity in counseling and advocacy so as to demystify the national
family welfare effort, such as retired defence personnel, retired school teachers and other
persons who are active and willing to get involved.

4.

Modify the under/post-graduate medical, nursing, and paramedical professional course syllabi
and curricula, in consultation with the Medical Council of India, the Councils of ISMH, and the
Indian Nursing Council, in order to reflect the concepts and implementation strategies of the
reproductive and child health programme and the national population policy. This will also be
applied to all in-service training and educational curricula.

5.

Ensure the efficient functioning of the First Referral Units i.e. 30 bed hospitals at block levels
which provide emergency obstetric and child health care, to bring about reductions in Maternal
Mortality Ratio (MMR) and Infant Mortality Rate (IMR). In many states, these FRUs are not
operational on account of an acute shortage of specialists i.e. gynaecologist/obstetrician,
anaesthetist and pediatrician. Augment the availability of specialists in these three disciplines,
by increasing seats in medical institutions, and simultaneously enable and facilitate the
acquisition of in-service post-graduate qualifications through the National Board of Medical
Examination and open universities like IGNOU in larger numbers. As an incentive, seats will
be reserved for those in-service medical graduates who are willing to abide by a bond to serve
for 5 years at First Referral Units after completion of the course. States would need to sanction
posts of Specialists at the FRUs. Further, these specialists should be provided with clear
promotion channels.
(viii) (a) Collaboration with and Commitments from the Non-Government Sector

1.

There remain innumerable hurdles that inhibit genuine long-term collaboration between the
government and non-government sectors. A forum of representatives from government, the
non-government organisations and the private sector may identify these hurdles and prepare
guidelines that will facilitate and promote collaborative arrangements.

2.

Collaboration with and commitments from NGOs to augment advocacy, counseling and clinical
services, while accessing village levels. This will require increased clinic outlets as well as
mobile clinics.

27

<!-- page 28 -->

3.

Collaboration between the voluntary sector and the NGOs will facilitate dissemination of efficient
service delivery to village levels. The guidelines could articulate the role and responsibility of
each sector.

4.

Encourage the voluntary sector to motivate village-level self-help groups to participate in
community activitie.

5.

Specific collaboration with the non-government sector in the social marketing of contraceptives
to reach village levels will be encouraged.
(viii) (b) Collaboration with and Commitments from Industry

1.

The corporate sector and industry could, for instance, take on the challenge of strengthening
the management information systems in the seven most deficient states, at primary health
centre and subcentre levels. Introduce electronic data entry machines to lighten the tedious
work load of ANMs and the multi-purpose workers at subcentres and the doctors at the primary
health centres, while enabling wider coverage and outreach.

2.

Collaborate with non-government sectors in running professionally sound advertisement and
marketing campaigns for products and services, targeting all segments of the population,
from village level upwards, in other words, strengthen advocacy and IEC, including social
marketing of contraceptives.

28
3.

Provide markets to sustain the income-generating activities from village levels upwards. In
turn, this will ensure consistent motivation among the community for pursuing health and
education-related community activities.

4.

Help promote transportation to remote and inaccessible areas up to village levels. This will
greatly assist the coverage and outreach of social marketing of products and services.

5.

The social responsibility of the corporate sector in industry must, at the very minimum, extend
to providing preventive reproductive and child health care for its own employees (if >100
workers are engaged).

6.

Create a national network consisting of voluntary, public, private and non-government health
centres, identified by a common logo, for delivering reproductive and child health services,
free to any client. The provider will be compensated for the service provided, on the basis of a
coupon system, duly counter-signed by the beneficiary and paid for by a system that will be
fully articulated. The compensation will be identical to providers, across all sectors. The end
user exercises choices in the source of service delivery. A committee of management experts
will be set up to devise ways of ensuring that this system is not abused.

7.

Form a consortium of the voluntary sector, the non-government sector and the private corporate
sector to aid government in the provision and outreach of basic reproductive and child health
care and basic education.

<!-- page 29 -->

8.

In the area of basic education, set up privately run/managed primary schools for children up to
age 14-15. Alternately, if the schools are set up/managed by the panchayat, the private corporate
sector could provide the mid-day meals, the text -books and/or the uniforms.
(ix) Mainstreaming Indian Systems of Medicine and Homeopathy

1.

Provide appropriate training and orientation in respect of the RCH programme for the
institutionally qualified ISMH medical practitioners (already educated in midwifery, obstetrics
and gynaecology over 5-1/2 years), and utilise their services to fill in gaps in manpower at
appropriate levels in the health infrastructure, and at subcentres and primary health centres,
as necessary.

2.

Utilise the ISMH institutions, dispensaries and hospitals for health and population related
programmes.

3.

Disseminate the tried and tested concepts and practices of the indigenous systems of medicine,
together with ISMH medication at village maternity huts and at household levels for ante-natal
and post-natal care, besides nurture of the newborn.

4.

Utilise the services of ISMH 'barefoot doctors' after appropriate training and orientation towards
providing advocacy and counseling for disseminating supplies and equipment, and as depot
holders at village levels.

29
(x) Contraceptive Technology and Research on RCH
1.

Government will encourage, support and advance the pursuit of medical and social science
research on reproductive and child health, in consultation with ICMR and the network of
academic and research institutions.

2.

The International Institute of Population Sciences and the Population Research Centres will
continue to review programme and monitoring indicators to ensure their continued relevance
to strategic goals.

3.

Government will restructure the Population Research Centres, if necessary.

4.

Standards for clinical and non-clinical interventions will be issued and regularly reviewed.

5.

A constant review and evaluation of the community needs assessment approach will be pursued
to align programme delivery with good management practices and with newly emerging
technologies.

6.

A committee of international and Indian experts, voluntary and non-government organisations
and government may be set up to regularly review and recommend specific incorporation of
the advances in contraceptive technology and, in particular, the newly emerging techniques,
into programme development.

<!-- page 30 -->

(xi) Providing for the Older Population
1.

Sensitize, train and equip rural and urban health centres and hospitals towards providing
geriatric health care.

2.

Encourage NGOs and voluntary organizations to formulate and strengthen a series of formal
and informal avenues that make the elderly economically self-reliant.

3.

Tax benefits could be explored as an encouragement for children to look after their aged parents.
(xii) Information Education and Communication

1.

Converge IEC efforts across the social sectors. The two sectors of Family Welfare and Education
have coordinated a mutually supportive IEC strategy. The Zila Saksharta Samitis design and
deliver joint IEC campaigns in the local idiom, promoting the cause of literacy as well as family
welfare. Optimal use of folk media has served to successfully mobilize local populations. The
state of Tamil Nadu made exemplary use of the IEC strategy by spreading the message through
every possible media, including public transport, on mile stones on national high ways as well
as through advertisement and hoardings on roadsides, along city/rural roads, on billboards,
and through processions, films, school dramas, public meetings, local theatre and folk songs.

2.

Involve departments of rural development, social welfare, transport, cooperatives, education
with special reference to schools, to improve clarity and focus of the IEC effort, and to extend

30

coverage and outreach. Health and population education must be inculcated from the school
levels.
3.

Fund the nagar palikas, panchayats, NGOs and community organizations for interactive and
participatory IEC activities.

4.

Demonstration of support by elected leaders, opinion makers, and religious leaders with close
involvement in the reproductive and child health programme greatly influences the behaviour
and response patterns of individuals and communities. This serves to enthuse communities to
be attentive towards the quality and coverage of maternal and child health services, including
referral care. Public leaders and film stars could spread widely the messages of the small
family norm, female literacy, delayed marriages for women, fewer babies, healthier babies,
child immunization and so on. The involvement and enthusiastic participation of elected leaders
will ensure dedicated involvement of administrators at district and sub-district levels.
Demonstration of strong support to the small family norm, as well as personal example, by
political, community, business, professional, and religious leaders, media and film stars, sports
personalities and opinion makers, will enhance its acceptance throughout society.

5.

Utilise radio and television as the most powerful media for disseminating relevant sociodemographic messages. Government could explore the feasibility of appropriate regulations,
and even legislation, if necessary, to mandate the broadcast of social messages during prime
time.

<!-- page 31 -->

6.

Utilise dairy cooperatives, the public distribution systems, other established networks like the
LIC at district and sub-district levels for IEC and for distribution of contraceptives and basic
medicines to target infant/childhood diarrhoeas, anaemia and malnutrition among adolescent
girls and pregnant mothers. This will widen outreach and coverage.

7.

Sensitise the field level functionaries across diverse sectors (education, rural development,
forest and environment, women and child development, drinking water mission, cooperatives)
to the strategies, goals and objectives of the population stabilisation programmes.

8.

Involve civil society for disseminating information, counseling and spreading education about
the small family norm, the need for fewer but healthier babies, higher female literacy and later
marriages for women. Civil society could also be of assistance in monitoring the availability of
contraceptives, vaccines and drugs in rural areas and in urban slums.

31

<!-- page 32 -->

Appendix II

MILESTONES IN THE EVOLUTION OF
THE POPULATION POLICY OF INDIA
v

1946
Bhore Committee Report

v

1952
Launching of Family Planning Programme

v

1976
Statement of National Population Policy

v

1977
Policy Statement on Family Welfare Programme

Both statements were laid on the Table of the House in Parliament, but never discussed or adopted.
v

1983
The National Health Policy of 1983 emphasized the need for "securing the small family norm,
through voluntary efforts and moving towards the goal of population stabilisation". While adopting
the Health Policy, Parliament emphasized the need for a separate National Population Policy.

32
v

1991
The National Development Council appointed a Committee on Population with Shri Karunakaran
as Chairman. The Karunakaran Report (Report of the National Development Council (NDC)
Committee on Population) endorsed by NDC in 1993 proposed the formulation of a National
Population Policy to take a " a long term holistic view of development, population growth and
environmental protection" and to "suggest policies and guidelines (for) formulation of programs"
and "a monitoring mechanism with short, medium and long term perspectives and goals"
(Planning Commission, 1992). It was argued that the earlier policy statements of 1976 and
1977 were placed on the table, however, Parliament never really discussed or adopted them.
Specifically, it was recommended that "a National Policy of Population should be formulated
by the Government and adopted by Parliament".

v

1993
An Expert Group headed by Dr. M.S. Swaminathan was asked to prepare a draft of a national
population policy that would be discussed by the Cabinet and then by Parliament.

v

1994
Report on a National Population Policy by the Expert Group headed by Dr. Swaminathan. This
report was circulated among Members of Parliament, and comments requested from central
and state agencies. It was anticipated that a national population policy approved by the National
Development Council and the Parliament would help produce a broad political consensus.

<!-- page 33 -->

v

1997
On the 50th anniversary of India's Independence, Prime Minister Gujral promised to announce
a National Population Policy in the near future. During 11/ 97 Cabinet approved the draft National
Population Policy with the direction that this be placed before Parliament. However, this
document could not be placed in either House of Parliament as the respective Houses stood
adjourned followed by dissolution of the Lok Sabha.

v

1999
Another round of consultations was held during 1998, and another draft National Population
Policy was finalised and placed before the Cabinet in March, 1999. Cabinet appointed a Group
of Ministers (headed by Dy Chairman, Planning Commission) to examine the draft Policy. The
GOM met several times and deliberated over the nuances of the Population Policy. In order to
finalise a view about the inclusion/exclusion of incentives and disincentives, the Group of
Ministers invited a cross-section of experts from among academia, public health professionals,
demographers, social scientists, and women's representatives. The GOM finalised a draft
population policy, and placed the same before Cabinet. This was discussed in Cabinet on 19
November, 1999. Several suggestions were made during the deliberations. On that basis, a
fresh draft was submitted to Cabinet.

33

<!-- page 34 -->

Appendix III

DEMOGRAPHIC PROFILE
India is following the demographic transition pattern of all developing countries from initial levels of
“high birth rate - high death rate” to the current intermediate transition stage of “high birth rate - low
death rate” which leads to high rates of population growth, before graduating to levels of “low birth
rate - low death rate”.

1. Age Composition
1. (i) The age distribution of the population of India is projected to change by 2016, and these
changes should determine allocation of resources in policy intervention. The population below
15 years of age (currently 35 percent) is projected to decline to 28 percent by 2016. The
population in the age group 15 - 59 years (currently 58 percent) is projected to increase to
nearly 64 percent by 2016. The age group of 60 plus years is projected to increase from the
current levels of 7 percent to nearly 9 percent by 2016.
Table 4 : Age Composition as Percentage of the Total Population2
Year

Below

Between

Between

+ 60 years

5 years

0-15

>15 -59 years

1991

12.80

37.76

55.58

6.67

2001

10.70

34.33

58.70

6.97

2011

10.10

28.48

63.38

8.14

2016

9.7

27.73

63.33

8.94

34

2.

Inter-State Differences

2. (i) India is a country of striking demographic diversity. Substantial differences are visible between
states in the achievement of basic demographic indices. This has led to significant disparity in
current population size and the potential to influence population increases during 1996-2016.
There are wide inter-state, male-female and rural-urban disparities in outcomes and impacts.
These differences stem largely from poverty, illiteracy, and inadequate access to health and
family welfare services, which coexist and reinforce each other. In many parts, the widespread
health infrastructure is not responsive.
2. (ii) At least 9 states and union territories in India have already achieved replacement levels of
fertility. These are ranked in accordance with their total fertility rates. Additionally, in each of
the three tables below, the current population of each state/union territory, the ratio of this
population to the country population, the infant mortality rate and the contraceptive prevalence
rate of the state / union territory is also indicated:
2

Technical Group on Population Projections, Planning Commission.

<!-- page 35 -->

Table 5 : Population Profile of 9 States and Union Territories of India
with TFR less than or equal to 2.1
State

Population
Size (in millions)
as on
1 March 1999*

INDIA

981 .3

Percent of
Total
Population

Total
Fertility
Rate
1997

Infant
Mortality
Rate
1998

Contraceptive
Prevalence
Rate
1999

3.3

72

44 %

23
NA
36
16
21
30
53
32
23

27.1
7.8
28.8
40.5
56.9
39.9
50.4
35.0
34.6

Group A (TFR less than or equal to 2.1)
Goa
Nagaland
Delhi
Kerala
Pondichery
A&N Islands
Tamil Nadu
Chandigarh
Mizoram

1.5
1.6
13.4
32.0
1.1
0.4
61.3
0.9
0.9

0.2
0.2
1.4
3.3
0.1
0.04
6.2
0.09
0.09

1.0@
1.5@
1.6@
1.8
1.8@
1.9@
2.0
2.1@
NA

@ Three year moving average TFR1995-97
*Population Projections by Technical Group on Population Projections,1996
Source: Registrar General of India
2.(iii) There are 11 states and union territories that have a total fertility rate of more than 2.1 but less

35

than 3.0, ranked accordingly :
Table 6 : Population Profile of 11 States and Union Territories of India
with TFR > 2.1 but < 3
State

Population
Size (in millions)
as on
1 March 1999*

Percent of
Total
Population

Total
Fertility
Rate
1997

Infant
Mortality
Rate
1998

Contraceptive
Prevalence
Rate
1999

25
51
58
66
64
52
53
49
54
47
37

20.1
30.2
55.4
50.3
48.2
21.9
32.9
50.1
66.0
14.0
9.1

Group B (TFR > 2.1 and < than 3.0)
Manipur
Daman & Diu
Karnataka
Andhra Pradesh
Himachal Pradesh
Sikkim
West Bengal
Maharashtra
Punjab
Arunachal Pradesh
Lakshadweep

2.21
0.1
51.4
74.6
6.5
0.5
78.0
90.1
23.3
1.2
0.07

0.2
0.01
5.2
7.6
0.7
0.06
7.9
9.2
2.4
0.1
0.01

2.4@
2.5@
2.5
2.5
2.5
2.5
2.6
2.7
2.7
2.8@
2.8@

@ Three year moving average TFR1995-97
*Population Projections by Technical Group on Population Projections,1996
Source: Registrar General of India

<!-- page 36 -->

2. (iv) However, there are at least 12 states and union territories that have a total fertility rate of over 3.0.
These have been listed below:
Table 7 : Population Profile of 12 States and Union Territories of India with TFR greater
than or equal to 3
State

Population Size
(in millions)
as on
1 March 1999*

Percent of
Total
Population

Total
Fertility
Rate
1997

Infant
Mortality
Rate
1998

Contraceptive
Prevalence
Rate
1999

3.0
3.0
3.2
3.4
3.5@
3.9@
4.8@
4.0
4.2
4.4
4.8
NA

98
64
78
69
61
49
52
98
83
67
85
45

39
54.5
16.7
49.7
29.1
25.2
4.6
46.5
36.4
19.7
38.2
15.0

Group C (>3.0)
Orissa
Gujarat
Assam
Haryana
Dadra & Nagar Haveli
Tripura
Meghalaya
Madhya Pradesh
Rajasthan
Bihar
Uttar Pradesh
Jammu & Kashmir

35.5
47.6
25.6
19.5
0.2
3.6
2.4
78.3
52.6
98.1
166.4
9.7

3.6
4.8
2.6
2.0
0.02
0.3
0.2
8.0
5.4
10.0
17.0
1.0

@ Three year moving average TFR1995-97
*Population Projections by Technical Group on Population Projections,1996
36

Source : Registrar General of India
2.(v) The five states of Bihar, Madhya Pradesh, Orissa, Rajasthan and Uttar Pradesh that currently
constitute nearly 44 percent of the total population of India, are projected to comprise 48 percent
of the total population in 2016. In other words, these states alone will contribute an anticipated 55
percent increase during the period 1996-2016. Demographic outcomes in these states will
determine the timing and size of population at which India achieves population stabilisation.

3.

Maternal Mortality

3.(i)

With 16% of the world's population, India accounts for over 20% of the world's maternal deaths.
The maternal mortality ratio, defined as the number of maternal deaths per 100,000 live births,
is incredibly high at 408 per 100,000 live births for the country (1997), which is unacceptable
when compared to current indices elsewhere in Asia.
Table 8 : Maternal Mortality Ratios in Asia 3

3

Sri Lanka

China

Thailand

Pakistan

Indonesia

India

Bangladesh

Nepal

30

115

200

340

390

437

850

1500

UNFPA, The State of World Population, 1999, 6 Billion : A Time for Choices, 1995 estimates.

<!-- page 37 -->

3. (ii) Within India, the inter-state differentials are a matter of concern.
Table 9 : Inter-State Differences within India in Maternal Mortality Ratios4
Kerala

Bihar

Madhya Pradesh

Rajasthan

Uttar Pradesh

Orissa

87

451

498

607

707

739

4.

Infant Mortality

4.

It is estimated that about 7 percent of new-born infants perish within a year. Poor maternal
health results in low birth weight and premature babies. Infant and childhood diarrhoeal diseases,
acute respiratory infections and malnutrition contribute to high infant mortality rates. Additionally,
in India, across the board (rural or urban areas), there are more female deaths in the age
group of 0-14 than elsewhere5. Although the Infant Mortality Rate (IMR) has decreased from
146 per 1000 births in 1951 to 72 per 1000 births (1997), and the sex differentials are narrowing,
again there are wide inter-state differences recorded in 1998, as is clear from Table 4-6. In
comparison, we note the infant mortality rates in South Asia and elsewhere:
Table 10 : Infant Mortality Rates in Asia6

5.

Sri Lanka

Thailand

China

Indoneisa

India

Pakistan

Bangladesh

Nepal

18

29

41

48

72

74

79

83

Sex Ratio

5. (i) India shares a distinctive feature of South Asian and Chinese populations as regards the sex
ratio, with a century's old deficit of females. The (female to male) sex ratio has been steadily
declining. From 1901 to 1991, the sex ratio has declined from 972 to 927. This is largely
attributed to the son preference, discrimination against the girl child leading to lower female
literacy, female foeticide, higher fertility and higher mortality levels for females, in all age
groups up to 45.

4

Registrar General of India.
UNICEF, The Progress of Indian States, 1995. India Country Office, New Delhi.
6
UNFPA, The State of the World Population, 1999, 6 Billion : A Time for Choices.
5

37

<!-- page 38 -->

Appendix IV

UNMET NEEDS & DEFICIENCIES IN CONTRACEPTIVES
SERVICES, HEALTH INFRASTRUCTURE, SPECIALISTS AND
TRAINED MANPOWER WITH IMPLICATIONS FOR FUNDING
The unmet need for contraceptive services is estimated at 28%, necessitating an additionality of
approx. Rs. 150 crores (for contraceptives, laproscopes, tubal rings, vaccines and RCH drugs).
Health infrastructure is inadequate, with estimated shortages as:
v

7,683 subcentres (1991), now estimated at 23,190 subcentres for the projected population in Year
2002. Capital cost of one subcentre is Rs. 3 lacs, with a recurring cost of Rs. 0.5 lacs. The Finance
Minister in his Budget Speech, 1999-2000, announced a scheme for strengthening rural health
infrastructure, to be implemented with responsibility for funding shared between the panchayat,
state and central governments. Accordingly, the Department of Family Welfare is formulating a
scheme for opening new subcentres where required, providing buildings and equipment to existing
subcentres, wherever necessary.

v

A shortage of 1,513 primary health centres (1991), now estimated at 4,212 PHCs for the
population projected in 2002. Capital cost of one PHC is Rs. 24.50 lacs, with a recurring
liability of Rs 13 lacs. These expenditures are met by the State Governments under the basic
minimum services (BMS) programme. However, the financial position of the State Governments

38

does not enable them to make these investments in health infrastructure.
v

A shortage of 2,899 community health centres (1991), now estimated at 3,776 CHCs for the
projected population for the year 2000. CHCs serve, mostly, as the First Referral Units and are
critical for reducing the MMR and IMR, besides serving as operating theatres for family planning
services. Capital cost of one CHC is Rs. 80.5 lacs, with a recurring liability of 27 lacs, currently
met by State Governments under the BMS programme.

v

The Department of Family Welfare funds 5,435 Rural FW Centres, some of which are being
used as First Referral Units. Others are functioning as block-level PHCs.

The estimated additionality towards infrastructure is:
(Rs. In crores)
A/C

1991

2002

Subcentres

Cap
Rec

230
38

695
116

PHCs

Cap
Rec

370
196

1032
547

CHCs

Cap
Rec

2320
783

3021
1020

TOTAL

Capital
Recurring

2920
1017

4748
1683

<!-- page 39 -->

Inadequacies in Trained Manpower
v

Shortage in manpower is estimated as 27,501 ANMs, 64,860 male muti-purpose workers, and
4,224 LHVs, 5,126 Health Assistants (male), 2,475 medical officers in PHCs, 1,429 surgeons,
1,446 gynaecologists, 1,525 physicians, 1,774 pediatricians, and an overall shortage of 6,635
specialists.

v

Other health manpower reflects a shortfall of 1,171 radiographers, 6,045 pharmacists, 12,793
Lab Technicians, and 18,851 nuse mid-wives, in the rural primary health care delivery system.
The financial requirement to address these unmet needs for trained manpower is approximately
Rs. 2,300 crores.

v

For safe abortion services, no MTP kits have been made available since 1997. However,
during the CSSM programme, 1,748 MTP kits were distributed to the FRUs. Most of these are
lying unused, on account of shortage of trained manpower. This year an additional 180 MTP
sets are being procured.

Training
v

For training, since the population policy emphasises convergence of training requirements as
well as decentralisation to sub-district and village levels, the estimated additionality for the
present is Rs. 10 crores.

39
