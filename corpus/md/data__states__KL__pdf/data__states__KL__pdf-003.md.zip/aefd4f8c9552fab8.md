---
doc_id: "aefd4f8c9552fab8"
source_url: "https://www.kase.in/assets/admin/notificationattach/notify_1062985552.pdf"
ministry: "Kerala Academy for Skills Excellence (KASE), Kerala"
title: "Download Attachment"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0a8fdaeebf852fd6"
---

<!-- page 1 -->

KERALA ACADEMY FOR SKILLS EXCELLENCE
Department of Labour and Skills, Government of Kerala

RECRUITMENT FOR SELECTION TO VARIOUS POSTS IN
KERALA STATE INSTITUTE OF DESIGN
RANK LIST
Post I: Assistant Professor (B. Des)
Rank
1

Roll No.
16007

Name
PRASHANA PRASHANTH

2

16003

DARSHAN K

3

16008

KIRAN G

4

16006

ANEENA ALEX

5

16011

SREERAM S P

6

16015

ARUN T R

7

16009

MITHRA SREEKUMAR

Rank

Roll No.

1

13002

STALIN C

2

13003

RESSAL VINEETH R

Post II: Male Warden
Name

Post III: Administrative Officer
Rank
1
2

Roll No.
NAME
17002 AJAYAKUMAR G
17001

JOY S
