---
doc_id: "e6d1ddeda384cd7b"
source_url: "https://adak.kerala.gov.in/eng/images/pdf/bylaw/Amendment%20as%20per%20G.O.%20Rt%20591-2022-FP.pdf"
ministry: "Agency for Development of Aquaculture (ADAK), Kerala"
title: "Amendment as per G.O. (Rt) 591-2022-F&P"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0ed65e7d378bce3a"
---

<!-- page 1 -->

A\p_Ôwþ6
GP³kn t^mÀ sUhe¸vsaâv Hm^v AIzmIÄ¨À, tIcf-bpsS ‘sat½mdm­w
Hm^v Atkmkntbj³’, ‘\nba§fpw N«§fpw’ t`ZKXn.
sat½mdm­w Hm^v Atkmkntbj³- þ t`ZKXn
(i)

GP³knbpsS kpKaamb \S¯n¸n\v \nehnse C\w 6. `cWkanXnbpsS LS\
Xmsg¸dbp¶coXnbnÂ t`ZKXn sN¿p¶p; AXmbXv,
\nehnepffXv

t`ZKXn hcp¯nbXv

6. `cWkanXn

6. `cWkanXn

F-þ Hut±ymKnI AwK§Ä
1. ^njdokv hIp¸v a{´n (sNbÀam³)

F þ Hut±ymKnI AwK§Ä
1. ^njdokv
hIp¸v
(sNbÀam³)

2. ^njdokv hIp¸v
sNbÀam³)
3. ^njdokv
UbdIvSÀ)

sk{I«dn

UbdIvSÀ

(sshkv

2. ^njdokv
hIp¸v
(sshkv sNbÀam³)

(s{]mPIvSv

3. ^njdokv UbdIvSÀ

a{´n
sk{I«dn

4. Kh¬saâv
sk{I«dn
[\hIp¸v
AsÃ¦nÂ At±l¯nsâ {]Xn\n[n

4. tPmbnâv
sk{I«dn
dm¦nÂ
Ipdbm¯, Kh¬saâvs{k{I«dn,
[\hIp¸nsâ, {]Xn\n[n

5. Kh¬saâv sk{I«dn dh\yq hIp¸v
AsÃ¦nÂ At±l¯nsâ {]Xn\n[n

(\o¡w sNbvXp).............................

6. Kh¬saâv
sk{I«dn
\nbahIp¸v
AsÃ¦nÂ At±l¯nsâ {]Xn\n[n

(\o¡w sNbvXp).............................

7. sIm¨nbnse kapt{ZmÂ¸¶ IbäpaXn
hnIk\
AtXmdnän
sNbÀam³
AsÃ¦nÂ At±l¯nsâ {]Xn\n[n
8. UbdIvSÀ, CIBA, a{Zmkv
At±l¯nsâ {]Xn\n[n

AsÃ¦nÂ

9. sNbÀam³,
aen\oIcW
\nb{´W
t_mÀUv
AsÃ¦nÂ
At±l¯nsâ
{]Xn\n[n

5. {]knUâv, cmPohv KmÔn skâÀ
t^mÀ AIzmIÄ¨À AsÃ¦nÂ
At±l¯nsâ {]Xn\n[n
6. UbdIvSÀ,
CIBA
AsÃ¦nÂ
At±l¯nsâ {]Xn\n[n
(\o¡w sNbvXp)..............................

10. sU]yq«n P\dÂ amt\PÀ, \_mÀUv
AsÃ¦nÂ At±l¯nsâ {]Xn\n[n

7. sU]yq«n
\_mÀUv

P\dÂ

amt\PÀ,

11. amt\PnwKv UbdIvSÀ, aÕys^Uv

8. amt\PnwKv UbdIvSÀ, aÕys^Uv

<!-- page 2 -->

12. No^v
FIvknIyq«ohv
F©n\obÀ,
lmÀ_À F©n\obdnwKv hIp¸v
13. Uo³ (^njdokv ^m¡Âän)
ImÀjnI kÀÆIemime (KAU)

(\o¡w sNbvXp)..............................

tIcf

9. Uo³,
^njdokv
^m¡Âän,
bqWnthgvknän Hm^v ^njdokv
Bâv Hmjy³ ÌUokv (KUFOS)

14. GP³knbpsS FIvknIyq«ohv UbdIvSÀ

10. GP³knbpsS amt\PnwKv UbdIvSÀ
11. sNbÀam³ kwØm\ aÕy hn¯v
tI{µw (SFSC)

_n.\ma\nÀt±iw sN¿s¸Sp¶ AwK§Ä
1. tIµ Irjn hIp¸v sk{I«dnbpsS
{]Xn\n[n

12. UbdIvSÀ, CMFRI AsÃ¦nÂ
At±l¯nsâ {]Xn\n[n
_n.\ma\nÀt±iw sN¿s¸Sp¶ AwK§Ä
(\o¡w sNbvXp)..................................

2. tI{µ [\Imcy hIp¸v sk{I«dnbpsS
{]Xn\n[n
3. imkv{XRvP·mcnÂ
\n¶v
\ntbmKn¡p¶ {]Xn\n[n

kÀ¡mÀ

4. tÌäv
sehÂ
_mt¦gvkv
t\mant\äv sN¿p¶ Hcp sa¼À

I½än

5. tIcf kÀ¡mÀ \ma\nÀt±iw sN¿p¶
c­v hyànIÄ

(\o¡w sNbvXp)..................................

1.

tIcf
kÀ¡mÀ
t\mant\äv
sN¿p¶ aÕy¡rjn taJebnÂ
\n¶papff Hcp imkv{XRvP³
(\o¡w sNbvXp)..................................

2. tIcf
kÀ¡mÀ
\ma\nÀt±iw
sN¿p¶ c­v hyànIÄ

<!-- page 3 -->

\nba§fpw N«§fpw þ t`ZKXn
(i) \nehnse C\w 1 \nÀhN\w JÞnI 7,9 F¶nh GP³knbpsS kpKaamb
\S¯n¸n\v Xmsg¸dbp¶ coXnbnÂ t`ZKXn sN¿p¶p; AXmbXv,
\nehnepffXv

t`ZKXn hcp¯nbXv

7. FIvknIyq«ohv UbdIvSÀ F¶mÂ
GP³knbpsS FIvknIyq«ohv
UbdIvSÀ

7. amt\PnwKv UbdIvSÀ F¶mÂ
GP³knbpsS amt\PnwKv UbdIvSÀ

9. tPmbnâv FIvknIyq«ohv UbdIvSÀ
F¶mÂ GP³knbpsS tPmbnâv
FIvknIyq«ohv UbdIvSÀ

9. tPmbnâv UbdIvSÀ F¶mÂ
GP³knbpsS tPmbnâv UbdIvSÀ

(ii) \nehnse C\w 2, `mchmlnIÄ JÞnI 4,5 F¶nh GP³knbpsS kpKaamb
\S¯n¸n\v Xmsg¸dbp¶ coXnbnÂ t`ZKXn sN¿p¶p; AXmbXv,
\nehnepffXv

t`ZKXn hcp¯nbXv

4. FIvknIyq«ohv UbdIvSÀ : kwØm\
kÀ¡mÀ \nban¡p¶ Hcp Dt±ymKØ³
FIvknIyq«ohv UbdIvSÀ Øm\w
hln¡pw

4. amt\PnwKv UbdIvSÀ : kwØm\
kÀ¡mÀ \nban¡p¶ Hcp
Dt±ymKØ³ amt\PnwKv
UbdIvSÀ Øm\w hln¡pw

5.tPmbnâv FIvknIyq«ohv UbdIvSÀ:
kwØm\ kÀ¡mÀ \nban¡p¶ Hcp
Dt±ymKØ³ tPmbnâv FIvknIyq«ohv
UbdIvSÀ Øm\w hln¡pw

5.tPmbnâv UbdIvSÀ : kwØm\
kÀ¡mÀ \nban¡p¶ Hcp
Dt±ymKØ³ tPmbnâv UbdIvSÀ
Øm\w hln¡pw

<!-- page 4 -->

(iii) \nehnse C\w 3, `mchmlnIfpsS AhImi§fpw NpaXeIfpw A[nImc§fpw
JÞnI 4, 5, 5(kn), 7 F¶nh GP³knbpsS kpKaamb \S¯n¸n\v
Xmsg¸dbp¶ coXnbnÂ t`ZKXn sN¿p¶p; AXmbXv,
\nehnepffXv

t`ZKXn hcp¯nbXv

4. FIvknIyq«ohv UbdIvSÀ

4. amt\PnwKv UbdIvSÀ

(5). tPmbnâv FIvknIyq«ohv UbdIvSÀ

5. tPmbnâv UbdIvSÀ

(5) (kn). GP³kn \nba§fpw N«§fpw
A\pkcn¨pw `cWkanXnbpw I½änbpw
NpaXes¸Sp¯p¶X\pkcn¨pw Dff
NpaXeIÄ \nÀÆln¡pIbpw
FIvknIyq«ohv UbdIvSsd
klmbn¡pIbpw GP³knbpsS
ssZ\wZn\ {]hÀ¯\§Ä
D¯chmZn¯t¯msS \S¯pIbpw
sN¿pI.

5 (kn). GP³kn \nba§fpw N«§fpw
A\pkcn¨pw `cWkanXnbpw I½änbpw
NpaXes¸Sp¯p¶X\pkcn¨pw Dff
NpaXeIÄ \nÀÆln¡pIbpw
amt\PnwKv UbdIvSsd
klmbn¡pIbpw GP³knbpsS
ssZ\wZn\ {]hÀ¯\§Ä
D¯chmZn¯t¯msS \S¯pIbpw
sN¿pI

(7). ss^\m³kv Hm^okÀ:
GP³knbpsS IW¡pIÄ
kq£n¡pIbpw km¼¯nI
Imcy§fnÂ FIvknIyq«ohv UbdIvSsd
klmbn¡pIbpw sN¿m³ NpaXes¸«
Cu Dt±ymKØs\ kÀ¡mÀ
\nban¡p¶XmWv.

7. ss^\m³kv Hm^okÀ:
GP³knbpsS IW¡pIÄ
kq£n¡pIbpw km¼¯nI
Imcy§fnÂ amt\PnwKv UbdIvSsd
klmbn¡pIbpw sN¿m³ NpaXes¸«
Cu Dt±ymKØs\ kÀ¡mÀ
\nban¡p¶XmWv.

<!-- page 5 -->

(iv) \nehnse C\w 6 FIvknIyq«ohv I½än JÞnI 2 FP³knbpsS kpKaamb
\S¯n¸n\v Xmsg¸dbp¶ coXnbnÂ t`ZKXn sN¿p¶p; AXmbXv,

\nehnepffXv
6. FIvknIyq«ohv I½än

1. Xmsg¸dbp¶ F«v AwK§fpff Hcp

FIvknIyq«ohv I½än D­mbncn¡pw

2. Hut±ymKnI AwK§Ä
1.

Kh¬saâv sk{I«dn, ^njdokv
hIp¸v (sNbÀam³)

2. ^njdokv UbdIvSÀ,
s{]mPIvSv UbdIvSÀ (sshkv
sNbÀam³)

t`ZKXn hcp¯nbXv
6.FIvknIyq«ohv I½än

1. Xmsg¸dbp¶ A©v AwK§fpff
Hcp FIvknIyq«ohv I½än
D­mbncn¡pw

2. (a). Hut±ymKnI AwK§Ä
1. Kh¬saâv sk{I«dn, ^njdokv
hIp¸v (sNbÀam³)
2. ^njdokv UbdIvSÀ

3. Kh¬saâv sk{I«dn, ^n\m³kv
(FIvkvs]³Un¨À)

3.^n\m³kv hIp¸nÂ \n¶pw
tPmbnâv sk{I«dn XkvXnIbnÂ
XmsgbÃm¯ Hcp {]Xn\n[n

4. Kh¬saâv sk{I«dn, \nba
hIp¸v

\o¡w sNbvXp.................................

5. amt\PnwKv UbdIvSÀ,
aÕys^Uv

\o¡w sNbvXp.................................

6. No^v F©n\obÀ, lmÀ_À
F©n\obdnwKv Un¸mÀ«vsaâv

\o¡w sNbvXp.................................

7. GP³knbpsS FIvknIyq«ohv
UbdIvSÀ

4.

GP³knbpsS amt\PnwKv
UbdIvSÀ

.
b. \ma\nÀt±iw sN¿s¸Sp¶
AwK§Ä

(b). \ma\nÀt±iw sN¿s¸Sp¶
AwK§Ä

FIvknIyq«ohv I½änbntebv¡v
FIvknIyq«ohv I½änbntebv¡v `cWkanXn AwK§fnÂ \n¶v kÀ¡mÀ
`cWkanXn AwK§fnÂ \n¶v kÀ¡mÀ \ma\nÀt±iw sN¿p¶ HcwKw
\ma\nÀt±iw sN¿p¶ HcwKw

<!-- page 6 -->

(v). \nehnse C\w

8,

tbmK§Ä JÞnI 3,5 F¶nhnS§fnÂ “FIvknIyq«ohv

UbdIvSÀ” F¶ hm¡pIÄ
sN¿p¶p.

“amt\PnwKv UbdIvSÀ” F¶ hm¡pIfmbn t`ZKXn

(vi). \nehnse C\w 9, ‘Izmdw’, JÞnI 2 GP³knbpsS kpKaamb {]hÀ¯\¯n\v
Xmsg¸dbp¶ coXnbnÂ t`ZKXn sN¿p¶p; AXmbXv,

\nehnepffXv

9.Izmdw

9.Izmdw

2.I½nän tbmK¯nsâ Izmdw 4
Bbncn¡pw

(vii). \nehnse C\w

t`ZKXn hcp¯nbXv
2.I½nän tbmK¯nsâ Izmdw 3
Bbncn¡pw

10 AwKXzw JÞnI 2, 3 F¶nhnS§fnÂ “FIvknIyq«ohv

UbdIvSÀ” F¶ hm¡pIÄ “amt\PnwKv UbdIvSÀ” F¶ hm¡pIfmbn t`ZKXn
sN¿p¶p.
