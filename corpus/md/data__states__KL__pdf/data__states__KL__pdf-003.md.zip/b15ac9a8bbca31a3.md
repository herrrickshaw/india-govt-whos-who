---
doc_id: "b15ac9a8bbca31a3"
source_url: "http://spb.kerala.gov.in/wp-content/uploads/2026/01/notification.pdf"
ministry: "Kerala State Planning Board, Kerala"
title: "കേരള സ്റ്റേറ്റ് കൗൺസിൽ ഫോർ സയൻസ്, ടെക്നോളജി ആൻഡ് എൻവയോൺമെന്റിന്റെ (കെഎസ്‌സിഎസ്ടിഇ) എക്സിക്യൂട്ടീവ് വൈസ് പ്രസിഡന്റ് (ഇവിപി) സ്ഥാനത്തേക്കുള്ള വിജ്ഞാപനം"
date: ""
pages: 1
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "ba2f82903c1820cf"
---

<!-- page 1 -->

Kerala State Planning Board
SPB-EST/76/2026-E1.
Pattom Palace P.O
Thiruvananthapuram
Dated: 2nd March 2026
Notification
The Government of Kerala invites applications and nominations for the position of ~
Executive Vice President (EVP) of the Kerala State Council for Science, Technology
and Environment (KSCSTE). The Executive Vice President is the Chief Executive of
the KSCSTE.
The candidate should be a distinguished scientist / technologist with a PhD in a
science or technology-related area with a proven track record and adequate
administrative experience.
The candidates should preferably be 60 years of age or less as on | January 2026. The
age criterion may be relaxed for exceptional candidates.
Persons interested should send a resumé to the Member Secretary, Search cum
Selection Committee (Member Secretary, Kerala State Planning Board, Pattom,
Thiruvananthapuram 695004) by post or to the email 1Dms_spb.ker@nic.in
(alternate email ID- vkr@kerala.goy.in). The Committee will also consider
nominations by senior scientists. Nominators are requested to send resumes of the
nominees to the address/email ID above.
The last date of receipt of resumes shall be 15 days from the date of publication of this
advertisement.
Dr. Sharmila Mary Joseph IAS
Member Secretary, Kerala Sate Planning
Board
&
. . “Member Secretary of Search cum Selection
Committee
Email: ms_spb.ker@nic.in
