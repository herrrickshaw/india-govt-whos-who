---
doc_id: "6d21bccfd1b699da"
source_url: "https://keralartc.com/storage/downloads/IMG_12.pdf"
ministry: "Kerala State Road Transport Corporation, Kerala"
title: "Notification"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "08ea25612dbc840f"
---

<!-- page 1 -->

ee,oEc cqBP' co3ft.p" (Scoacolcosf ce,cdq-.lcoosjoa
mo.or1.ogoE.p2l009729l2014(A&V

D4)

o".ro.rtdoco0 & occrnslorn" RDeo)oqqos
6i3oJ3ere)o, s3o0ccrSc6$ reoLad,

o'r'lotocnnor";oo, or"lcocofl. 30.l 1 .2022
&c(o5rDo acerrr"laerol ccncS"lmr"

d,caooeJEo corJerolgloa oolnDojoce0) iuol.oji.anilu) oOCm o'rcauA 09.02.2014
a]o-rroE rarocnufla5<oloco,l esceLlao)ed ooceoco,;crri1R. a0)Lacm)oo)o Grdojordo]tsts GIoGoJ63i

olodgil{ coacr.la,co1*gfloE crllcm;o o;o0a35il GrdmJo.rceo o.tccsBcoo) asceilqJsd
a;pa,oacerd. 21.05.201 3 oE o'udglmild e,ooro1co rolca,sa
"ocsroce,croflolaer;cmoi

oloicceuosiai eselaDgojl(fr olocm ol5;5ilaolro6 cnlcm;o on5l cplaf,ea:cmor" grilcooaso)
oflgo6rr caEox:ra" &4,ga"oruga:.;ei'' '. roloeqos Grdecoro ca,cdgcoouoa! au;cnrzocora
cru<0g1ar5 cnsororlgpo5 o.lsqol6rBo€o;ee)jo cacdgcontcd croatolooco5acco) turDcDodsomjloi
gQS ololorDJacorJo oaJaJ0,)J. GDeiQ)coE tcol.oil.arj'1s]
rocao66o- 1960-oa G6r@9c
"6)cm
(ooooflo1qo.
cnlorqgemqo
eraglqo)
mfloild nudqlru"
-'l5oo:gJoer "-r5o 15 Glecoo
&goJ(Q)o mnf,a,].

e,g"-rgrorrrlcri o)cacra ojluoGloosrDo mafo'lori$fl. gs6cm" 5]S@esoqgg
orlsoacccrr_J"e,,am<orolmcorl oeogo qerrlcgcn-olmJoo iJo(Delo.lq@6qQo tooaqos e3u)o
ofl,oa1aeloecrnoilmco,tl Qmr" c;orsrD ercss3do" G'ool.rroc mdojlocc;sJ1qo rocsud
oJlocoomo;loE o:oaqrororlq. 09.42.24L4 qolcfr rarocnuilgroocol csceLlaotlafr cr.,lcrroo o.t13
colcm" eacdgcooucri eruoro)o crrlcoslqrdacm crrceog a,geococncao"l aoererotorl cncgcd5i
rroadg[4[oles:cnc. o1cgc6$ocrfl -1o64[ o)cauA6o" oooococci rolcorccol4 poEcrubarqd
o'rcsu8 ni-la$"cilqofloE oogcor csceJl er"rqcmorcoo;1 cnc.gcd5i o-alqfo'1oocno. mllcrioro
erceo,ofim- cojencl oq;cceru"vod acaco;go:1d orocm srocnujlgolaceorl csceiloolicf crrlcnoo otig
mlcm" cacd"tconsjcn" 09.02.2014 qclrcfr cm-lorrno cD'lc.ejoroacrn o>3BoE 1960'oe: eeog3
rulojloE ru6g1nlr" (ooororlo'1qo. cnlco4gomoJo @oq"Rqo)
":5ra:ploa ".igo 11(vii) @&ccoo
cru6q1 m;1 tt$ crfl oro o cn1 aeio er"rqco? p cqrol eocno.

pae uol6,ei too1.oj1.err.r1u; o6)cm olcagfo8 djoororogscrol1o1aoco-r;gg
ogofidclcomr:gsrunlor olcegos oikoelaosmo p.D ecncglm5 a,lgJcm orlotoJl o;alo8 15
elocruoroilcDa,o cruadtilcdo6rTeo)oocrD(m" crildcgooloocm;. cd}.rc:ilor elolrDoroilrnao a1glcm
o6Jo0.)co) oiluor:"laoemoJo e'rooo'lo o"loSaccnoas;eo]rmo'i1oi a3oaoj
"-Lolcnarrlleo;cmorcer6.

"go'jlrEacoeungsro:1oor

o.lce,gJos ojlcroB"lao6rrlo crjlcoilror e1ocrDoroilcnao aelaer;odqlcoco;aloE

o')ce,u6ad ogrorlrdo:cr:eancgc ojloos"lao6rncac rnroEa;cr:ccn1q;

ogrmcoSoccnl6ojcm(o..)lo

GEff)Oo.)(0(r)SdJSl OOA OAer C g q cmo)io C6m".

ocruqgol)

(

alo;oqd (oJlmlaodru)
m;Jl odoroc o-ii gco1. oL1. errila;, oolftDo:6. 6rc ao o ei go
(e1 gc crau.fl e,co1, roger.4e qer:oof oc)

orodgl - elq{c rroure,col. oqerqe - sl ccncglcnl" slorgrr"
ooe,raco'l ooa gql co o'rca, oo g c(B

"radqil <S

a,lorcrarl o.rloloe Grio;q o'rcoar'pocsro""
cggceo"

Ad

"nco-)(fr

/

"lcor<rf

cl1 oorl c cra c Agsl co;
