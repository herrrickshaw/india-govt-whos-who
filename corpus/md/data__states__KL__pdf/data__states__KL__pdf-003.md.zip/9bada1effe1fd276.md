---
doc_id: "9bada1effe1fd276"
source_url: "https://www.cusat.ac.in/act/amendments.pdf"
ministry: "Cochin University of Science and Technology, Kerala"
title: "Amendents"
date: ""
pages: 20
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "264898e888e1fa81"
---

<!-- page 1 -->

UNIVERS ITY OF COCHIN

l

'"

NOT IFICA T ION

No.Ac.B3/105/82

16th

May 1 98.3

In exercise
of th(~ powers cOrJferred
on it under Section
31 (2) and 31(3) of the Cochin University:Act(Act 30 of 1971)7
the Senate has made the following amendments to the First
Statutes 1980. These amendments are effective from the 18th
day of April 1983, thG date of assent by the Chancellor.

1.
"That the following additional statutes be incorpoT3t2G
as Statut8s
93 (viii)
and 93 (ix),respectively under 'chapter
VFacultias.
II

93 (viii)

"93

({x)

Faculty of Env-i,ronmental
Studies1l
Such

other Faculties as may be ,instituted by

the Senate from time to ti~en.

With the addi tions ihcorporat~:d,

thus:

"93

.

statute 93 will 1'8::<\

- Faculties:
The

.. ...

following shall be the Faculties in the Univ;,":r;:lty

namely:(.i) T;i.'! FetCu::' ty of Humanities
(ii) ,Th~ Faculty of Law
(iit) The Fac~lty of MarinQ Scienc0s
(iv) The Faculty
of Scionce
(v) Th~ Faculty
of Social
Sciencos
(vi) Th~ Faculty of Tochnology
(vii) Th~Faculty
of Engin20ring
(viii) Th~ Faculty of Environm0htal Studies
(ix) Such oth0r Facultios as may b~ institut~d by th 2
$2n2te
from tirn\3 to timdY''

2,*

(a)

'''Th;'lt

th...

following

n2W St2tut2.

Ch<.lpter XII--A 'Chapt2r

XII-A.
EnvironmEmtQlStudi8St H.
,(b)

!lThat

The DQgrees

Statutes

154(a),

154(b)

and

154(c)1I.

und,::):" the

(i)

Doctor

"154(b)

"

.

Faculty

of Environmental

Studi0S

be:

of Philo90phyPh.D.

(ii) Doctor of Science

....

.1S

11154 (a) Degrees:

s1)a11

r .

incorpo1'at8d

the following statute be incorporat2d und,=-T

Chaptc'T XII-A,

-

be

Faculty of

Other'DegrE,ies

D.Sc.
or Diplomas

or Certificates~

The UDiv9rs i ty may award any other DegreD or D iplorDa
or CertificstG 2S rney be Llstitqt0d
from~ime
to time' in thG
Facul ty'of
Envi+,oftmental
Studi~'9it.
,
I "
\

2)

<!-- page 2 -->

-2. ..' j,.

ii154(c)

'stipu12t~din

The

t~0

Dcgr:'::t:::

sh.:-.ll

R0gulations

for

wll+ re-:ld.as

.Cha.pt(cT XII-A

b<::~aW.:lrd<Jd

tho

;}$ p,.:r

aW2rd of such

.follows

cQn;_;i.i-~-

d2gr

'"

.:3'.

:

ilChapt~;r ,XII-A
FACULTY OF ENVIRONMENTAL STUDIES

R154 (a) Degrcis:
The Dcgro0s

.

Studio.s:.

und0r

(i)

Doctor

of Philosophy

(ii)

Doctor

of
Oth.:;r

The Univ0rsity
C::rtificlt.}

Faculty

Faculty

,bo:

\1154 (b)

or

tho

shall,

35

fit)]'

;)f Environm-,ntJ.l

Ph.D.
D..Sc.

SCi8nCG
D2grQ\.~s

of EnvironmentaL

or Diplomas

or C,:::rtific.:1t

:s~

may 3w3rd any oth0r Dagr2' or Diplo~~
institut.'d
from tim2 to tiITL~ in th'"

I')}

StudL'!sll.

n154 (c) Th~ p.~gr0ds sh~11 be nwarded as p0I co~diti0~~
s tiDU 1'3t . d in j:h2 R,,~gul::1tions
for tr~~. av.nrd of such d0qr ':5:i
~

Sd/....
REG ISTRAR ,

UNIVERSITY OF COCHIN

T ripuni thura

,.

<!-- page 3 -->

..

?

-

UNIVERSITY

3 -

OF

.COCHIN

NOTIFIC.Zl.TION
No..I-,>C. B3/105

11th October

/82

1983.

In exercise of powers conferred on itl vide Section
31 of the Cocbin Universit'y Act (Act 30 of 1971) the Senate
has made the following amendments to the Cochin University
Firsf Statutes 1980.
These amendments have reCeiVE;(J th8 assent of the
Chancellor as provided for under subsection 8 of Section 31
of the Cochin university Act, 1971.. These amendments will
have effect from October 41 1983, ths date of assent by the

Chancellor.

.

Dr.C.N.SATYpFl-L:~
REGISTRAR

Cochin university
Cochin-682 022

P..O.,

B.

to statutes

(i) Amendments

XXII

0-

201 to 225 under

Statute 226 under Chapter XXIII
Statutes of February 1980.

~.

Chap.ter

Convocation for conferring Degrees and
of the First

I.. That Statutes 201 to 225 under Chapter
First Statutes, 1980 be deleted.

XXII

of the

II.. That the title of Chapter XXII "Convocation Eor conferring Degrees II be replaced by "AvJard of Degrees ".
III. That the following

201.

Award

new statutes

be made:

of Degrees:

1) Degrees
meeting

shall be awarded
of th!? S?natc.

at any ordinary

2) All degrees except Honorary
be awarded in absentia.

202.

Date

degrees

shall

6f application:

Candidates for degrees must submit to the
Registrar their applications
for degrees in the
prescribed form with the prescribed feE,
remitted in the prescribed manner 30 clear days
before any meeting of the Senate.

203.

FeEs:
A candidate applying for a degree shall pay a f88
of ~.20/-, which shall be in addition to the
fees prescribed for the various Diplomas.

,204.
Lhas

l

Applications
1)

No

to be made

in ths prescribed

candidat:-c; 'IThoLapplied

prescribed or who
manner prescribed
for submission of
the degree at the
concerned.

",vi
thout

tbe

manner:
£~"e

has not applied in the
befor''?the: prescribed date
applications
shall be awarded
meeting of the Senate

<!-- page 4 -->

4 :

:

Provided that applications with a fine of Reo. One per
day may be accepted for fivet days after the date
prescribed for receipt of applications:
provided also that intervening holidays, if any,
between the last date prescribed for receipt of
applications
and the last date fixed for receipt of
applications with fine shall be reckoned for calculc.-t--

ing the fine.

'

Provided further that, if the last date prescribed for
of applications
or the last dat? fixed for receipt of
applications with fine falls on a holiday fbr the
university OfficE, all ,applications received on the
next vlOrking day shall be ch:;sft1cd to have been r8cEiv::;d
on the prescribed date.

rec'.=ipt

2) For

pur po s,:;of

these

statute

,S r

205. validity

datr2 of

thE:

applications
in thG University
sidersC as thp date of rec~ipt

r.,oc:::ipt
of

Offic2 shall bc conof the applicatio~8.

of Diplomas:

The Diplomas of the Unjv~r8ity shall b~ valid
only if: they bsar thr. SSol of th;:.Uni.v:rsity and
arc signed by tlv2 Vic8:-Chanc2llor.

IV.

That Statute 226 undsr
Statut? 206".
ChaptET

XYJI

thus

Chapter

XXIII

am-:'ndsd"(.'muld

read

be renumbsrec

as

dB

follo'itlS:

CHl~.PTER :XXI I .

AWard
201.

of Degrees.
J.~vard of

Degr2ss:

1) D::'grses shall
m<.=eting

of

the

be

awarded

at any

ordinary

S::-nat8.

2) hll DegreEs except Honorarydegr~8s
awarded "in
absentia.
,--~~~
~~ ..,_,~,' s--- -=.-~
202.

shall 08

Date of applica€ion:
Candidates for dGgrs8s must submit to the
Registrar their applications
for degrees
in the prescribed
form with th,,"prescribed
f0e, remitted in ths prescribed manner
30 clear days before any meeting cf the
Senate.

203. FeES:
~ candidate applying for a degree shall
pay a fEe of Ib.20/--,which shall be in
addition
to this fE':':.s pre scr ibeo for the

various Diploma~.

<!-- page 5 -->

'r

--

-~ '" -

'ii

- ---: 5 :

204.

Applications to be made i~ the prescribed manner:
1\'

1)

-<

-~"-'

0

;->

CcluUl()CF..c-

."

\,

~vno

lIas

l J..., Q
~'"

app

,o''''''

WlL

h,OUL-'- th

""

f38S prsscribed or who ~as not applied in

the
bS::=0:;:8 thE prsscribed date

mannt:;;r
pre scrj.bcd

for submission of applications
811<)11 be
awarded th::.. degree at the meeting of the
Senate

concerned.

providEd that applications with a fine of Re.One
day may be a,cc-::ptEd
for fiv8'daY3 after the date

per

prescri}.)<:,c

for

r;::.c:::ipt
of

applications:

Provic'sd also that intervening holidays, if any,
bebvsen the last dat:::::
prcscrHx:d for r0c'0:iptof appli.~
cations and the last date fixed for receipt of applications with fins sl1all
be reckonGd for calculating
the £ in,:.:: :
if 'chs lust dab.:- prescribed
or the last dats fixed for
receipt of applications I.-lith
firh-, falls on a holiday
for the univ'='Tsity Office I all application~~ receivf::o on
th,=:;
nExt working day shall h:: c3(:.;smed to [laVe
been
rccE:'ivcd 0n thco prescribed c1ats.
providsd further that,
for r2csipt of applications

2) -For purpose
of thssc statute
s I the d ate of
rsceipt of the applications in tho::; University Offic(~
shall be considered as th,::;
date: Gfreceipt
o:E the
applications.
205. Validity

of Diplomas:

The Diplomas of ths university shall be valid
only if they bear the seal of the university
and
are signed by the Vics-Chancellor.
stc:ltutes 226 of
read as follows:

would

CHAPTER
Departmental

Cha.pter

XXIII

as

amended

XXIII

Council

be a Departm,mtal
Council
from time: to ,time for Gach

"206.,
There:,
shall
thE; Vice'-Chancellor

constituted

DEp<lrtmcnt
of Study or School of Studies and shall function under the f
Rules to be- prEscribed".

by

B. (ii)

lIITlcndment 'to

168 under

I.

statute 132 under Chaptsr X and

Chapt2r

XIV of th~ First

statutes

statute
1980.

"That tb8 follo\-jingDegree be added to the Degrees
under the Faculty of Social Sciences listcod in
Statute :).32.Chapter X of the First Statutes 1980
as 132 (1)' ( a)

.

"132.

j

'.:II
:I

De gre c;s :
1

1)

a)

Master of

Business ?dministration

(Banking and

F in0.nc8)

H.B."',. (Bankinq

&: Finance)

"

I

<!-- page 6 -->

: 6 :
.

3t~tJt~

~32

t~~E'

"132. Degr ':'88:

lv."

r

d

-'
-"" o
7.7,--,,1,1.:;
h., ,.,-,-,-,
f -

Thee DsSr:;cs

i:1

d

o'S

t:,h~: Filcul

lloV.
lS '
T'

.Cl1
.L

-

,..

ty

c:c

Soci2l

shall be

Sci~nccs

,

l"~r'('

1)

Has'c::r of Business

l.dministrCltion

1)

a) Master of Business
hdministriltion (D'anking &"1d
Finance)

i'1.B.l..

M . B. 1..
(Banking

H.B.H.

2)

I'1astsr

3)

NasL3r of Comrnc:rcE

H.Com

4)

Doctor
Doctor

Pr-J.D.

5)
"That

th(::

of

Dank

IvIanagcrncDt

of Philosophy
of Lstters

following D'2:qres

D. Litt. II
b:.? acJd(~d

to

the;

the University provided for the, Statute
t "'-<.ll..
S +-~I L! Le:'~c> 1 :::>0,0
XIV
0 .L t1 j c .t:.'--.:..
.
..
)..
,,;>
Chap L cr
-'-

""'

"-

'-'

'"'''

ry~~"..

~

168.

Degre

(iv)

(2)

s of

the

Ec

)

17inance

of

D2grC'-E

168,
a
- '::J (lV)
.

'"

(Cl
)

.

Un.iversj.ty.

Must~r of Business l~ministration (Banking
2P..d F in.=:mci.:;)

3tatut:: 168 thus
"168. Dsgr?cs
conf'3r

H. B. ~.. (Banking & F inanc2 ) .

amend;,x1

vwUlcl

read as

follov-lS:

of the Univr"rsity:~
,The univc:rsity may
ths following Degrees: o.

B.Sc. (Engg.)

i) Bach~lor of Science in
Enqinc20xing
ii) Bachelor of Technology
of r,rts
iii) ~lastGr
iv) Master of Business

B. Tceh .
!vI.A.
~.1
. B. :..

l..c1ministration

iv) a) Master

of Business

Ivl . B . l> .

(Banking
&
Financ'" )
M.B.M.

l.c1minist:cation(Banking
and r inancc)'

v) MastEr ~;f Bank Management
vi) Master of Commcrc8
vii) iVlastsr of I LaT/lS
viii) Master of Scisnce
ix) Master of Sci~ncE in Engg.
x) Master of Technology
xi) Master of Philosophy
xii) Doctor of La\vs
xii i) Doctor of philosophy
xiv) Doctor of Science
xv) Such other Degrees as may
be instituted by the Senate
from tbu8 to tim8.

.

M. Com.

LL.H.
M.Sc.

N.Sc.

(Engg.)

M. Tech.

M.phil.
LL.D.
ph.D.
D.Se.

,

<!-- page 7 -->

-

NOT
-~

7

....

I ,---~,_._,,--"'-~
F I C ~ T ION

No.Ac.B3.1058/82

f

8th

r1arch

1984.

In exerciso of tho powers conferred on it vidB
Section 31 of ths
Co chin Univ2~sity ~ct(Ac~ 30 of 1J71) the
SGnat e has me do the f 0 ].low ing cmoildm::;nt 8 tot
he Co cilin
Statutos 1980.
University
First
These
Chancellor
0f

th8

8moncJmonts
havo i'OC8 i va c: t hu assont
of t hs
as provided for undGr sub soction 8 of Section

Co chi nUn

havo affoct
Chancollor.

i vcr

:d.t y

,;c t,

19 7 1 .

T iJe S 8

D li1
C n

cJ m:: n t s

from February 21, 1984 th~ dctc of ossont

CochinUniv~rsity

p.O.,

31

\J i 11

by ~h~

Or. C .I\! .SF;TYAP,',L{;J';

Cochin-682

022

That
publishoo

in -~hu Coci-iin ,Univ:Jrsity
vide
Gazf;tttj'Vol.XXVuNo.84

~

Rogistror.

following 8mcndmunts

be

Fi:i.'s:~, Stqtutos
19130
18-2-1980 tho
dated

Elado:-

--- onE NT s
!~f'1EN

I

1.

Amandmont

to Statute 168 undor

thriptor XIV-Ocgrcos~

Dipl6mas, Ccrtificatus 2nd Titl~s.
"That under Statute 1GB-Degrces of tho Univ8rsity-th~
fallowing 009r38s bo added, und the list of dogrcGs be
'

8ppropriatoly
(i)
(ii)
(iii)
(iv)

r8~umberod:

Statute
"168.

(~~
/
.

/

~Vl.
(vii
(viii
(ix I
(x)

(

168 as 8mondod

would

Dbgrscs of thD Ur.ivsrsity:
confer

(i)
(ii)
(iii~

B.8 .C.

88chclor of 88nkinD and Commerce
Bachelor of Educotion
Oach8lor of Goneral Lows
Bachelor of Industrial Law

tho following

8.Ed'.8..G...L.' B.I.t.'n'
road thus~

The

Bacholor of Bankin~ and Co~murc8

88chclorof Educction

-

Bachalor of Gonsra1 Laws

Bcch81Dr of Industrial

Law

Bachelor Gf Scicnc6 in Engineering
gcc~clor of Technulogy
nosJ,;.:r

of Arts

Moster of Busin2ss Administrction
Master of Business ~dministrction
(Bonking & FinancE)
f.j8 s t 1J r a f 8 2.II k. f1.::;n at;-:2
rlkn t

(xi)
(xii)

Mastor
of Comm~rc3
of Lows
f:1astGr

xi i i )

rbstcr

of Philosophy

Univc:;:'si-i.:;y

[,lCY

cegrees:

8.8.C.
G.EJ.
8..G..L.
B..I.L.
G.Se. (En~)g.)
8.Tsch.
rl..P,-o
r~...B...i;..
f'l.B.i;.
(Sankine:
&- FincncL)

f'l.B.M.
fl. Coin

LL.n.
Pl. Phil -

.

.-.,;.2/

--

<!-- page 8 -->

8
(xi v)
(xv)
(xvi)
(xv i i)
(xviii)
(xi x)
(xx)

f\'lasc.;

l~ (J f

f.1uster
~2st~r
!)oct or
Doctor

c,-;

Enginc:;nring

)'

t.:

L,.

'

"

"

nl-

,-II.

Sci,nco
Such . JothE,r
d;::'91'i:;;::';S;JS mcy b:J
~ . b \ ' J. h ' S ,- . J. - J'> l'
;
~ t
... n
~ t. U t
0
n G
0m
~-;

f'I.;] c ( En -,r'
~',::J. J
LL.D.

DoctuI' of
;;,

r'l..S" c .

t.;. T;Jch.

of Philosophy

Jei rr.;j tot
r;
....

Sci::m

of Sci""i:cU
in
Df Tschnolcgy
of Lcws

;

(,

,;:

I

,-.

U.

D.Sc.

~

i (j}[) .

Amundmont

to Stutut~ 169

Diploii12s

Gnd C:;;l'tificotss

- Under Chcpt~r XIV-

r:ThGt
un::1!.JI'
169 - . Jiploff1<:1s,
.2nC: Csrtif.lc"l.;CS
. StGtuto
',
'
". C QnCi.
1
r U roc., ~ "1-l. C:', JGus b 8 8 C.DC
TilO
f 0- 1 ...iJW
DJ. p..lomas
~ng'
an [j
'

the

list uf

renumberEd:

(i )

'c:iploli18S

,:,11:::1c;.,l,tific,:t:':8

ilppJ. io d Hin di
,;r8bic
'

(ii)
(iii). \
( lV)

Ling uisti

-

be; DrJp:"::Jpriat:;ly

C3

i

Banking

Company Law
Financo Management
Mcrk~ting Man2gcmont
,

(v)

(vi)
(vii)
(viii)
(ix)
(x)
(xi)
(xii)
( xi i i )
(xi v)
(xv)

Mat0rials

f':1ancg c;f!]snt

Offics
Mon8gsmant
Operations RosGarch & Computc~ Applications
Porsonnel Management and In~ustrial Relations

PlantationManagemont

"

Production Ganbgcmont
Shipping one Foreign Trade
TechnolDgy
Tou~ism Mnnogcmont"

Statute ~69 as amended would r~ad -3$ folJ..pws~
"169.0iplomcs end Cortific2tcs:- The Unlv':'l'Sl.-CY fdO}'
in tho following
subjects
grant diplomas ond certificates
of study:,

(i) ~ppliod HinJi Linguistics
r.l'ebic
(ii)
(ii i)
Bank1ng
Business ~dministratiDn
(iv'
(v)
Co.mPDny Low
(vi)
Finance Managoment
(Vii
fronch
(viii
,GCJrm21n
LabDur Lcw
(ix
j
(x ' nark:>c ing nans£' ~'mc~nt
(xi)
f12 t (J ria
1. [:) n G nag
c "i C 11 t
(xii)
Office MQn3gsm~nt
( xi i i ) Oporatiuns RGs~arch & Comput~r Applications
(XiV
PQrsonnal M2nagomcnt and Industrial Relacions
(xv
Plantation Management
(xvi
]
Pro duct
ion
nGn 8g ~.IIi.;nt
I
..
'I

\XV~l<

Russian
Shipping end Foreign
Technology
Tourism Management

Trsdc
()(vi ii )
(xix)
(xx)
(xxi)
'TrenslL,tionGnl]
SCC1'Ct21'iclDrafting in
(xxi i) Such other Diplomas and CDrtificutcs, 28
S c f1 C tt.:;, may

fro In t i rn[} tot

riindi
th~

i mer] ~}c i ~ elf.
..

.2/

<!-- page 9 -->

- -- - - - ----

- 93.

to statute 107 undur

f.m8ndmont

Ch2ptCJ1' VI - F3culty

of

it i oJs

f-!wiwn

"That under
107 Degr~e:
Master of Philosophy

statuto 107
11107.
shall
I .

2S

t~e foll~wing bc added:
r'1. Phil

woul~ read t~us:

amended

OC:;g1:'88:
bc:-

The Dogroos

in tho Faculty

naster uf Arts
r13st:Jr of rh i1080 phy
Doctor
cf Philosophy

\1 )
(ii)
(iii)

r'1

of Humanities

. r\ .

rTt.Phil

Ph.D.
~.

4. Amendment to statute 110 -

Ccrtific~tcs

"That under
stQtutc 110 - Ccrtificctcs~
tho following
certificates b~ add~d befo~; !Translation und Sccrct8rial
Drafting if1 iiindi r~ and tho
appropriately
runumbcr3d:
(i)
(ii)
(iii)
(iv)
(v)

Applied Hindi
(,i' a b

list

ccrtific;:.Ls

be:

Linguistics

i c

Fr~nch
G8rman
:iussicl:

statute 110 2S arl~,;ndQd
and
\'lho

of

would

I'Gad

ti-;U3:

"110.
C8r<:ificat::.;s:
The Unlv,,;,rsity
Inc:~y grant Oiplc.m::s
of study to thos:-:
Ccrtificat2s
in the following subj;:~cts
have
undergono the [JI'cscribc:cl
course of stuc.:/
and
PC:1S::;CiG

th~ prcscrib=d =x2minetions:
(i)
(ii)
(. . . ,
~111

<

(iv
(v

<
I

~pplicd
i"i :C:',

~indi

-

Linguistics

Fr.:mch
Gormon

0
.
"U881..8n

(vi)

5.

bi c

Translction

end 5ccrotcrial

P.mcndril~~nt .co Statute}
Faculty
of Law
"That
Faculty
the

(i)
(ii)

in

(i)
(ii)
(iii)
(iv)
(v)

-

0091'80S

in Hindi."

- undcr

Chcptc.r

- D~grocs - under Ch2pt~r VIr

of L2W, tho following

(~U9I'ULS

b(j

OGOi.G,

\JII-

-

ond

list of ~cgrc~s, be o~pr0prictoly r~numborod:
6cchl...lor of
EJochslor
of

Statuto

"112.

112

Stctuto

112

D~Qfting

112

DcgI'f~CS

Bachelor
Bachelor
f\las-ccr of

:

G.::mcrol

Laws

2 '.G

.L

..

In'::ustrial

Lc:;w

B.I.Lt;

as

would

~e2d thus:

arn~n~od

Ths.DogrcGs

in the Fcculty

of Gcnsr21 L~ws
of Industrial Law
Laws

Doctor
of Philosophy
OuctDr .of L8ws

of Law sholl

8...G..L..

B.LL.

LL.n.
Ph. 0 .
LL.D.

"I

bc:-

<!-- page 10 -->

:

10

Amundmcnt to Statuto 116.

6.

"That in St2tutC 116 the words tin Lobour Law' bo
'''
CO
;-;
'":O l teoJ f "om
b w '-'u L..v-.d to (Dip Jom
tl C1
1 u l ,.i"-"o"',,,'
C,,'"t. 'J ~-~,
,""
',"

.~

'-

'C"

,

to;

,

''''

ll
...
~

...

u

J.

.

Law'

anci cboVG
'LabGur
Compon y LC1Wn

statute

The

'

,-,..f'-'

"""

~,'-"

in

thu

sc'cund

p8ragl'oph

be .adrJod -

f

116 as C1ffi2ndc(
would

reod thus:

n 116. Oiplofil<JS
g Th:.:; Univ81'sity [;Jay grant DiplofnDS ,ancJ
C:J rt if icnt:.:.; s ill 'che follow1ng subje c'Gs uf at ucJy t [) those
who
have undorgon~ the pruscribod courso of study _and passed
tilG pr.scribce GX2minotions
of' this
UF11v'c!.'sity.
. '\
( ~I

Company LQu
LGbour LuwIT.

(ii)

7.

~. "That
be

- undsr Choptor VIII -

Amendment to StatutL 118 08gr~8s
Fcculty
of Marine Scicncus:

-

in statute

Gnd the list

addod

of

118 Dogrc~s
tbo follouing
degroe
be approprict8ly r3numbcr2dg

d8gr~cs

['1. Philif

Mostcr of Philosophy

B. statute 118 shall bc substituted uith the followino:.;
tlStatutu 118 Dcgrsosg
Scionc~s
shall b~:
. \
~.

(i ii )
(i (v ~

i',m::.;nrJmunt tc
Dog

Ch::ptur

under

acc~CJd, and
Mcstur
The;

S'c;,;tuto

list of

i:lhj

as

"

.

. '\ 0 \'.i -T"c-,-'"
L.J,j':1rcn)

rl. Ph i 1
PI-;.D.
J.Scn.

- Faculty c..f SclcmcG - st:::,tut:, 127

g

Mastor
Mastsr

4.

127 OCJ9r~;cs g th~; fOllowing
[~:Jg:i:',-;GS b:.:; oppropriiJ-Gc:J:'

a'Jl:-_;nd(~r~ uoul;'-:

DcgrGcs:
81'1211

"J
..J.

f.

ef Philusophy

ststuto

"127.
1.
2.

IX

~

~'I.. :Jc.
1,0 c::c

ree s

rlThiJt

be

r'o

Mastar of 5ci~ncG
M8St2~ of Scienco
(by research)
r1cstcJr
uf Pililcsophy
Doctor of Phi:oscphy
Dcctorof _Science

-( . <
( ~~I

8.

Tho dcgro8s undsr the Faculty of M~~ins

rJ.Phil"

rC::;G

:::s fOL'.cus:

ThJ Ocgr~cs in the Faculty of Scl8nc-

bo:-

of
of

Scioncu
Philosophy

Doctor uf

Philosophy

Doctor

Scicnco

of

C:cgr8G
r-:Jnumb'.~rt]C::

r:l. Sc
fl.PhiJ.
Ph.D
D.Sc

132 Dogrucs:
th:::; ['o11ouiilg
uegrcos
." ..:!,h.g.t unJ.er
St2tUto.
renumberod:
bo adccd 2nd the list of d3Qrscs be 2ppropriotcly
(i)
(ii)

9.

B::,:::cl18lor of uDnking
,Jnc; Cemlilcrce
l.'uf
Ph iloSGphy
rk:st :.~

Amendment to St~tute 132 under Chapter X
3:)cial

sciences-

.

.

8.3.C.
f'l.fhil"

- F~culty

of

<!-- page 11 -->

Th,,'SJcctut:
it "I 2.;::.

:,:8

Dc"9 1";"~;c; ;

(i)
(ii)
(iii)

10.

u u u 1 c1 r:; ('1c; t;-, us:
iil tllu
Faculty of

C,ni[."r;

T:',:j
shall

DegrcGs
bc:-

Suci21

~mGndmcnt

1"1..8 . Iq.
.
,

n.8.PI.

Dr Philosophy

(Banking
&
- Fil=1C::nce)
1"1~8.n.
f\1.Cmil
1'1.Phil

of Pililosopl'I;'
uf Lcttors

,O.Littlt

of 82nk ~8nagcm~nt
of Commerce

to statute

"Thot the existing

Dnd ~hc fOllowing

SCi8iiCOS

8..8..C.

132chc;lol.'
of 80nking
oncl CCf.ifi1Gl'Cl:C
MastGr
of 8usiness Administration
!"iastc-.: 1:~ 0 f Bus i n c s s {.c.:mi(\ istcratlion
(8anking
and
FinancoJ

. 'I
( lV;
Mastcr
M2st3r
(V)
(vi)
,{"lDster
(vii)
Coctor
Doctur
(viii)

Ph.D.

138

statute

138 bc renumbered

as 138(0)

bc ~ddcd os stotuto 138:

-

"138. DiplomDS ond Certificates
Tho University may
Oiplor.!as
and Certificates
in tho following subjocts ''of
study to ti'WSG uho hov.G undergone the pl.'Gscr'ib:Jd
:course
of
study
and passed
thG prescribed
Gxa~Ln2tions

gr2nt

(i)
(ii)
(ili)
(i v)
(v)
(vi)
(vii)
(viii)
(ix)
(x)

l
f

.....

.

: 11

11.

62nidng
F if Iail c~ r'bnagcmcnt
r'br!wc ing rl.::.:nog rnf"nt
~1storials
r'12n2ig,,~n;ccnt

Offica Management
Parsonnol Managumcnt
Plantation

"Tf.,...:.;

r,
L, '"

a

LJ

," ,;; 0

c:nrJ Foreign

,

an u

S"tatuts

st

.ki<
~'L""

Relations

Trsdo

XI - Foculty of

139 un[;,~rCh8pt8I'

1-"J-,,, 1 -:>(
9 Oogr

n
a ",-,I., "
l - ""':.. r '"
L.n LJ -'..l w,", .J I

Mastct
B ..

Industrial

Tourism ~anngsmcnt. n

Tcchnulogy

"e,

and

Management

Productiun f\'janog;;rii~;nt
Shipping

,;rn:cndrnunt to

,.-,.
. .-,.-:~ {

,",

"

-- LU"s

.

F O.1 lo w i' no ( '~r>'l'~-'r,
- t lie;.,
"".c.J
J,;;L.L:':'.J
" . 'f. ,'
'''orO
,-, '" T"n
-~ l' -,~' ;-" .1
"~
.,'.
L L. a i .',.' - up .L '-. l" '" y. I "n U [;1b LJr B 0 .

of Technolegy

st c,t ute

1 39

b C

S LJb s tit

'

-

"~"

'

"J
J,
,.1",-,
r"'~
u w j - L;w S

fl.Tccllll.

u t .::;
d w it h

tho

foIl

[)win

g :

"St2tutO 13~. Degrees-The Ocgroos under tho Faculty
of Tcchnulogy shnl! bc:
(i)
(ii)

G. Ie cn
0

B'Bchelor uf Tcchnulog y
Mast2r of Tcchnology

~1. Tcc h

Ph.D.
o.Sc."

(iii) Doctor o,f Philosophy
(iv)

12.

Doctor

-.',

of. Sciancs

~mcndmcnt to statute 140
(1)

nn1C1t

in Statuto 1'1,[) in

the

words

given

in

bl'GC!(ct

line, till, words
'PuJ.j'nJor
Science
and be inserted before 'Rubb~r' und the words'
'Processing and' occuring b8foru 'Tochnology' be

2ncj~

in

-e;I::; first

rJolctcd.
(?
\...

)

Ths words 'Polymer Science and' bu inserted
bofors
'~ubbcr' occuring in statute 140 and the words
'Processing

&' bc dclutc~

fro~ the same

sentence.

<!-- page 12 -->

'~

.

,

. i,

be
t"'

'; c. "~'

140 as amond

:...~."
,,~
0 og-,.c;,o
.
or
(Polymer, Scicn.:::~

Cendid3tcs' fer

taken

Univcrsit\/J

would

s 5. )( t h

1 in

C)

rood thus:

0'::31]1'0,:: of Bcchclor

the

'.

ol Jv mn~ r Sel ";l,,' ne n'-' '-'" fl r"u"

novo

t: : '-

\0,. T ,-,CI1.)

'"
i... 1 ,<,,'0
T ~,
;'..
~'1
'
bOC'IL_,-,r
uT
I<,C,,},o...og)-'
and RubboI' Technology)

I

r

5.",

'

~

f"1

C.:;
.:::C lJ:,-' r .i.n g

'It'
l X
..0
.

" 40
'

". r

~ule~e~ ond inst60d substituted with thu wdrd
'

statute

l f1

!;c.,

-

')

R uu '"
iJ

T--:'C ll 1l0 '

~~

~ .L

Ll DcgrtJc

of 8Qchelor

i'n 'India

or other

"~

, ,

ur'

"

( n

!

'\

of L;chnology
"'

looy~'w

h '-'...,11
- .L

(8. Tech)
"

nr:
1""""i'i
~ C"'..J'- -- r w '..:

'L n
,

'-

of a Stotutory

Science.;

[:;eccotc;d os
.

iJualific:::tions
,
'

I";)
,..J,~

,

GCiui,

valent thereto 'by this University and to havo subso~uently
undergone the pr~scribDd ceurse of study for 0 period of not
them

1 c s s

s i )( sum

cst

L rs

in

Ei d o'p ~}r '(:
m G n t

(jf

s t u [1/

u f

t 1'1
i s

Univ::rsity or on institution l'ocognisuj by this Univc.,rsity Gnp
to have:;possed tile:; prc;scd.be;cJ lJxarni:lcticins
of this University."

Amendment to statute j42

13.

(i)
"That ,in statute 1429 first line' in the wurc:s glVGn
in brocket 2nd f the words
'P~Jlyr:l:;r
Scioilc:,:;
ond' be
inscrtod befure 'Rubber' 2nd the words
'procGssing&'
occur-ing
before 'Tcchnolog;,'
I be:; dclc",:::d.
.
.
~, t
. - ",'- - J- ,..~. 1 4 ?
~ -':
,.
~
,'.!. -, " -!
' p ' 1 .,
(
,ll ) T!1,".1
f I .:J L <; L.LJ L ...;
-- ,
,j J. (j -,_1 n cO9 (,11 u
\.1c.. L: S
U ~ Yfl, C l'
Science ond' be inscrtod boforo
fprocessing &' be dalotod".

statute 142

amendod

23

'Rubber'

2nd the words,

w~uld

rood 2S folluws:
'
~ c
of
T 0L..c! '~~fI, u' Jo
(I~ '. T c,
-"~"nv
h)
r,', -:
;,J h
r"
! \
",r,co "UcJ b ' 1' j ",cllnu J.l-';:J) ).
'

"142.

~' ~

~~nrn~
u'-~-~~,

wI

l'
( 0,O__yf,,,,,r
" ",

1~~Q~~r
'G~~~,~,

r"
~
5 c 1. ~ncl.,

')

. ' !. )

,

,-

'
., J- :
r rl
,... n n
,..,.p'
.; L--j' ~
'" i' "<"
r ,.,n ~:
r,oJ c.0" c:-,I.
I "~ C 'r1, r10.. 1-- C'" 9 Y (r.1
w ...
~ o~.;:) .p
, ,.- J. v I.l c U " 0-' .LL;'" ~J'
..;;)'-' n,'
'" ~~. n f
, " . T .' C Il )
in Pclymc1:' Sci~,:nc;:::;::nli
Rubber
TC:c!1nulogy
ond in ['Jevel (,rcl1ishall be r~qui~c~ to have token Q
t~cturc
ond Ship Building

.

~

. j

~~,

dC~jl'cC

of

Bech:'lo1'

of Tuchnnlcgy

in the subjc:ct

'

,',

uf' stueJy

,

cuncc:I'nco
from this
U'1iv~,rsit~'
or (em ~c:CJuivclunt
qucJ.5,fic2ticJn
by this University
2nd hevG SUb3D~ucntly
undorgon~
recognizud
the
[JI':;scl'ibc::cJ
cc::,u~sc uf study
feE' 0 p::riDc
of n:::d:; less then
fuur semesters in tho Deportment
of Study
of this Univs1'sity
['1' in ;,::n institut.ion 1'c:cognizLicJ
by the. Univ. r~;ity
one1 to
Ii c:V8 P 3 21S Gd t Ii
[Jreo s CI' i t C~ci C )(8 mi n E:t i (jn 0 f t his -U11i v ~;r sit Y ;;

.

14.

r,mcnc.:mc,r,-(:; to

Stet

n I I-,'. ,.

<;
1 6,L,;
be ~JC:c..:DcJ
as 3catutc

~

1,,-,,-,

onc;

the

':- '-, ,"
vi,,,,

'i "ni
""" "'"
'-' l J-' _. O,I, 1'-' ~J

'.

grcnt

.. ': J' "':. -;
~/'
-..:::~-ng

folloL:ifi:;'!

tt 1Li. 6

Dip:i.omds

ute

anu

146
r- '. -, ,-

.:Jl'uGUc.,,,,

,'-, ,

c."

0,,,,

.', "
... h C" '" ., ..'
J.c;nl"iilL,.".L.,;'-"

.. '"

ci""

~I Li C

,U

(8 )

146"

" r i--i foi c "i-r,,,,o
li '';'
'''T''''
'':-\
''''1/
T !..~..
C,,~
_. ~,' v w.::) 0
" ~
l-',l .c' ! ,- -.::> l v J/ 1"
,. C, J
C,:l:l:ific[;'c:::s
in the, fol1o\..Jing
subjc:;ct:s

"",'

, ,J j w

of , study to thusc who hove undergone tho prsscriboJ courso
of stucy anc; P2.:;SCu 'eh:.: ;iroscl'ibcc.:
cXL:rr:.in2.ticfl
uf this
UnivGrsityll.
,

(

.,
liI

.. '
'\

( II

. . .~

( lll;

(i v)

Ch:-illicol
Engin",~rJ-nG.i
Civil Enginecring
EIGc~riccl Engin~Gring
rkci::,~.i1ic::~.l
EnJinccringn

. '. . 7/

<!-- page 13 -->

-13 15. Amendment tu stotutc 175 undor ChaptaE XVI-Institution
of Fellowships, Scho18rships,
Studentship otc..
rIT h

<0::

tin

S t :::
t ut 0

17 5 ,

fir

st

1 i n G,

the

u u 1:'
d s

J

S

t u d i s s

fm e

'

be ins8rtG~ Gft~r 'post-groduate'
and before 'rQseorch' ond
in tho second line the word 'four' occurring, after 'of' anu
boforo tkinds' bu substituted with 'five', one the following
be added 2S (V): Merit scholsrshipsrl.
Statute

175 os amendod

woulct'rsad thus:

"175.
AWatds~
Awards by the UrtivGI'sity in oid of
Post-g1'8duate studies Lmd rasODrci1 sh3ll bE")of fivo kinds:
(i) Univ~~sity Research Fellowships
(ii)
Enduwsd Rsssorch Scholarships
or Fellowships
(iii)
Sp~ci3l grants and Prizes
(iv)
Special purpose fellowships
(v} f\lcritScholarships".

16.

stotu-cc 184 (8)
"That

under

8 s

(8)

184

Statute

184, the fbllowing

statute

bo added

.

"184(2) r1arit

Scholarships

(i) Ths f1Ufiibel.'
of Scholarsilips
by the Syndiccto

that may be awardod 8v~ry ~DaI' sh2J.1 bodccidcd
from time tot imo
.

(ii)

The

vc:lu3 uf

th:, Scilo12I's;.iip$the

i.:ionfor the ai.Jards::.~nc1 othcr t,jl'filS
prG3c:cibclJ

by

-ell:;8Ggulf.1"l:iuns".

rliinimum qUQlifica-

and cunditions sh311 bo

<!-- page 14 -->

-,

UNIVERSITY OF COCHIN

N OTIFICATIO,N

---'--'_'_,__,'-'-'~..~.~.~'..~._-'

,..=-,

22nd October 1984

No.Ac.B3/105j82

In exercise of the ~owers conferred on it vide
Section 31 of the Cochin University-Act. (Act 30 of 1971)
the Senate has made the followina amendments to Statutes
154 (a)(b) and (c) under Chapter~XIIA - Faculty Environ~
mental Studies and Statute 169, Diplomas and Certificates
under Chapter XIV~ of the Cochin University first Statutes9
1980.

These amendments have received the assent of th? .
Chancellor as provided for under Sub Section 8 of Section
31 of the Cochin University Act~ 1971. These amendments
will have effect from October 12~ 1984 the date of assent
by the Chancellor.
Dr.C.N.SATYAPALAN,
Registrar

Cochin University.P.O.~
Cochin
682 022.
...

AMENDMENT S
'1. That in Statute 154(a) Degrees under the Faculty
of Environmental
Studies, the following be added as (i) and
the list of degrees be appropriately
renumbered:
t

~

(i) "Master

of Science

- NI.Sc. (By Research)"

2. That the existing Statute 154(b) be substituted
with the new Statute as given below:
"154(b) 1?iplomas and Certificates; The University
may grant the Diplomas and Certificates in the
followingwsubject of studies to whose who have
undergone the prescribed course of study and
passed the prescribed examination.
Post-Graduate Diploma in Environmental Studies;;.
154 (c) the words
Diplomas/
after ;:Degrees" and before "shall

3. That in Statute
Certificates a be inserted
be awarded i; .

CHAPTER XII A.

:;

AS AMENDED 'NOULD READ

THUS
CHAPTER

XII~.A.

FACULTY OF ENVIROMAErITAL STUDIES
154(a} Degrees:

i

ii
iii

Master of Science
Doctor

The degrees under the Faculty
of Environmental Studies shall
be:
-.

of Philosophy

M. Sc.
- Ph.D

Doctor of Science- D.Sc.
2/-

l

-

<!-- page 15 -->

'';

-15 154

(b) Diplomas

and Certificates:
.

The University may grant the Diplomas and
Certificates in the following subject of studies to those
who have undergone khe prescribed course of study and passe~

the prescribed examination.
.

.

Post-Graduate Diploma in Environmental Studies.
154 (c). The 'Degrees/Diplomas/Certificates shall
be awarded as pet conditions stipulated in the
Regulations for their awardn.

4. That under Statute 169, Diplomas and Certificates:
Environmental Studies' be-incorDorat(?d as S.No.(vi) and tile
list of Diplomas/Certificates be appropriately renumbered.
STATUTE 169 THUS AMEI'IDED~ILL

READ AS FOLLO;S.

';169~ Diplomas and Certificates~..The University
may grant Diplomas and G9rtificates In the f.:;llowi,;g
subject~ of study.

it~
i~i)
~v)
v)
Vi
vii
viiij
ix)
x)
xi)
xii)
xiii)
xiv)
XV
xvi
xvii j
xviii)
xix)
xx)
xxi)
xxii)
xxiii)

Applied Hindi Linguistics
Arabic
Banking
Business Administration

Company Law

.

Environmental Studies
Fin§nce Management
French
German
Labour Law
Mark~ting Manageme~t
Materials Management
Office Management
Operations, Res.?arch and Computer Applications
Personnel Management & Industrial Relations

Plantation Management

.

Production Management
Russian
Shipping and Foreign Trade
Technology

Tourism Management

.

Translation and Secretarial Drafting in Hindi
Such other Diplomas and Certificates as the
Senate may from ti~e to time decide~.

<!-- page 16 -->

--

- ..,.. - f 0

UNIVllli.SITY

OF COCI1TN

NOTIFICJC.T::::ON

~:'c"B 3/1 05/82

30th October
f

1984.

,

In exercise of the pOvlers conferred on it vid8
section 31 of th~ Cochin University J~ct (J~ct 30 of 1971)
the senate has made the following amendments to Statutes 107,
168, 139 and 169 of the Cochin University First Statutes, 1930.
ThE:se amendments hav8 received' the assent of the
Chancellor as provided for under sub-section 8 of section 31
of the Cochin University hct, 1971.
These amendments will
havi::; effect from October 19, 1984 the date of assent_by
the

Chane

ell or.
hl'1E ND t1E NTS

I..

Amendment to statute 107 under Chapter
Faculty of H~~anities

VI-

"That
the degree of Doctor
of Lett:?rs (D~ Litt.) be
incorporated
und,~ statute 107 as item No.( iv).."
Statute

107 as amended

!l107 Degrees

~ The Degrees

Humanities shall be
(

i)

(ii)

would

read thus~

in the Faculty

~-

of

Master of

,-:oxts

. .

M. Z..

Mastr

Philosophy

. .

HoFhil

of

(iii)

Doctor of Philo.ophy

...

Ph.D

( iv)

Doctor

LGttcr s

..

D.Litt."

II..

of

l..m.;.;;ndment
to statute

Degrees,

Diplomas,

168

und.;;:rChapb3r

Certificates

XIV

-

and Titl0.s

-

aThat under statute 168
Degrees of the University, the
Degree of Doctor of LettGrs be added as item No. (xx) and
the list' of degr'~es be appropriately
renumbered. II
Statut~

168 as amended

would

read

thus:

i1168. DogreGs of the Univ(:rsity. The
confer the following degrs8s.-

(i)
, (ii)
(

iii)

(iv)
(v)
(vi)
(vii)
(viii)
(ix)

Bachelor of Banking and Commerce
Bachelor of Education
Bachelor of General Laws
Bachelor of Industrial Law
Bachelor of Science in Engineering
Bachelor of Technology
Master of Arts
Master of Business Administration
Master of Business Administration
(Banking and ~inance)

(x} Master of Bank Manageme~t
(xi) Master of Commerce'
(xii) Hastdr:' of Laws

Univ0rsity may
0
0

B.D.C.

~

B..Ed
B.G"L..

..
::

B"I.L.

;:
::

B. Sc..
B..Tech

::

M. BoA.

.0

N..BoT:.o

:;

l"'IoBoN.

n0

M. C om.
LL.
[.1.

( E ngg.

)

:: . '" H.l\.

"0,

.
.
(B an k l.ng

-

;::
v; -,-- " vi: .1.' l~ _.c,',,~ - )

<!-- page 17 -->

"

.

" 1

(~iii)

Mast~r

7~
..
..

of Pholosophy

(xvi)
(xvii)
(xviii)

(xix)

j'::':'.
s t.~.r:' of

sci..:

E.St2~

of

SC1'.;:lC<')

Mastar
Doctor
Doct<pr
Doctor

of T8chnology
of Lm'Js

nCIJ

in Li19in~(,;ring

(.l:.ngg. )
T""

H. Tech.
'::',,L..

of Philoso:phy

~

of Science

0
..

Fha 0.
D..Sc.
Da Litt..

to

by the

time

,.

as

lJ

.

may be

Scn2tc

from

I!

Amendment to statute 139 und0r Chapt~r
F3cul-ty of Technology

Fi~st

-

l'i. oC.

c

instituted
time'

'..
.'
..

s
(xx) Doctor of L2tti.::r
(xxi) Sucb oth""r Dc"gr8C:s

II1.

f1.Phil
M. SCo

~

(;;~,;tv)
\X7)

"That thE.:,;
followins; bS' add"",d
Statut2s
1980, aftsr statut8s

to th.:.;

XI -

Cochin Univ(~rsity

139.

139 (a) Diploma:;
The Univsrsity may grant Diploma in
the f9110.,vingsubject to those who have undergone the prescrib(3d
coursc- of study
and pc,sscod the.; prescribed
,,:,xaminations
::

Diploma

IV.

in Consumer

hmc:ndment

to

statute

De grees, DiDlomas,
~

El~ctronics
169

2nd T'l Technology.

11.nd8r Chapt<~r

Certificates
,

XIV

It

-

and Titles

"That the Diploma in. consumer Electronics
and TV
Technology p8 add:::-:o,
under statut,,~169 as item No.. (vi)
and th8 list' of. Diplomas and c~rtificatos
be accordingly
.
rcnumb,-;rcd.
..

The Statute .169 as am8nded
{1169. Diplomas

and

would

Certificates

read thus;
~;...

'l'heUniversity may grant Diplornas and Ccrtifi'catds
in the following subj~cts of Study ~-

(i) Applied Linguistics
(ii) l~rabic
.
\
(loll;
B anki ng
(iv{ Bus~nOss ~d~inistration
'

.

.

('1'-.,Company
Law
~ons'I.JII1er
El~.ctronicsof TV Technology

(vi)
(vii)
(viijJ

£nvironmenta+
studies
E'iD>ancc Nana9\~!nent
"
( :i,x} Fr~~ch
(x)
Gt;rw~n
(xi)
Labq~
Lmv
(xii) Mark~\ing Management
Materiqls Management
( :x:iii)
Office 'Management
, (xiv)
(xv, Op2ratio~$ Resear@h & Computer Applications
(xvi) Personal M-anagement and Industrial Relations

"'"

3

<!-- page 18 -->

:; 1£

.. \

( XVllj.~
( X\T

i i i )

(xix)
( x..x )

(xxi)
(xxii)
( xxiii)

( xxi\~)

Cochin

Cochin
....

'

D'~ n ~~~
n
t- ,-'-0,.<:..
, ~ -, '- l o
'"

:;

W~~~0>
m ~n t
'; k,'"J.,'(~;1 c; ':'- <-

'Product.ionr13Bdg0m{::;nt
Russi:::,n

.
For,.=:ign

Shipping and
'I:r:ade
'Technology
'Tourism
Management
Translation
ansi secretariat
Drafting
in Hindi
other Diplomas
and Certificates,
,'lS the
$uch
Senat-.::,
may from time
to time
institut,c:":

Univer

- 682

si ty

022.

P ,,00

I

DR..

C..N~ Sl.:.TYhP.i.L.hN"
RBGI STRZ.fz

<!-- page 19 -->

.>

COCHIN

UNIVERSITY

OF

$C1SNCE

AND TECHNOLOGY

NOT Ii' TCAT ION

GA&Elh 7218/99 (A)

NO.

10th

February

2000

In.exercise of the. powers conferred on it under stili
(2) of section 39 of the Cochin University of Sciene:;
and Technology Act; 1986 (Act 31 of 1986)
the syndicate at :>::'5
meeting held on 19.6..1999
amended statute 93 in Chapter V o:'~
section

and added a new

the Cochin University First ,statutes 1980

Chapter, Chapter XII B after Chapter XII A of the Cochin
University First Statutes 1980..
Th~,se amendments are effectJ.'J8

from 15th day of December 1999,
Chancellor
of

the

as' required

said'

I~endments/New
statutes 1980.

1.

(a)

(b)

Statutes

4 and 5 of

to the Cbchin

That the existing

section

University

First

provision in (IX) under
93 Faculties f be
replaced by m The Faculty of Medical Science
and Technology".
f

I

the date of assent by the

sub section

Act..

II"

i?

under

Chapter.v Faculties

-

The following be added as 93 (x)"
Such other Faculties" a.smay be insti tuted from time to
time"

.

with

the additipns

incorporated,
CHAPTER

93.

93vJill

read thus:

V

Faculties::

The following
namely:

(1.;\
.

(ii)
(ii1)
(iv)
(v)
(vi)
i ii

(ix)
(x)

(a)

shall be the faculties

,tn the Universi,ty

The Faculty of Humanities
The Faculty of Law
The Faculty of Marine sci~nces
The FaCtllty of science,
Th9 Facul ty of social; sciences
ty of Technology
The Fac'll
The Faculty of Engineering
The Faculty of Environmental
studies
The Facul ty of Medical Science and Technology
such other Facul ties as may be instituted
from time to time.
".

(v i i )
(v

2.

statute

)

That,i:tnew
Faculty
of

Chapter
Medical

be incorporated

viz " CHI\PTER XII-B.
Science
and Technology"

after

If
CRI\PTER XII-A".

39

<!-- page 20 -->

~

(b)

20

:

'fhat
the follovTing
new statutes
be incorporat.:,d
under
CHAPTER, <II-B.
Facult~o
of Medical
Science
Cti1Q '-,-cCLllOlogy
as 154- (d) I 154 (e) and
1 54 (f)
' ,

.

154 (d)

Degrees~
The Degrees
under
the
Faculty
of Medical
Science
a];1d Technology
shall
be Gr2duate
and post' 'Graduate,
in emerging
areas
of MedicCiI
Sciences"
and Technology.

154 (e)

Other

De"grees

or

Diplomas

'or

Certifi~ates~

The universitymay'award,
any at,he r Degr<2es
or Diplomas
or Certificates
as may he
instituted
from time to time in the
Faculty of Medical Science and Technology
154(f) Award of Degrees or Diplomas or Certificat?s~
The Degrees or Diplomas or Gartificates
shall be award~d as per the conditions
stipulated in the Regulations for the
award

Chapter

XII B will

of

thus

such

degree/diplomas/certific,c:rt,:,e:;.

read as follows:

CHAPTER

XII B

-FACULTY OF M3DlCAL SClZNCE AND TECHNOL03Y
154 (d)

Degrees:
The Degrees

under

the Faculty

of Medical

scienc2

and Technology shall be graduate -and post graduat,-;
degrees in emerging
Technology.
154 (:a) Other

Degrees

or

areas

Diplomas

of Medical

SCienc2s

and

or Certificates:

The University
may award any other Deg-r,::a or
Diplomas or Certificates
as may be instituted
from time ~o time in the ~aculty of Medical
Science. and Technology.
'

154(f)

Award of Degrees
or Diplomas or certificates
shall-he awarded as per the condi tiobs stipulated
in the re-gulations for the award of such Degrees/

Diplomas/Certificates-.

DR.
KOCHl

---~--

.

A.

ARAVINDAKSHAN
R~G I ST RAI(

j

J
