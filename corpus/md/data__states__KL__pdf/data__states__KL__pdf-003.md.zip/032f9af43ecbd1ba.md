---
doc_id: "032f9af43ecbd1ba"
source_url: "https://kshb.kerala.gov.in/storage/2026/08/NIT-etender-retender.pdf"
ministry: "Kerala State Housing Board, Kerala"
title: "Details"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f5f1c926331df89f"
---

<!-- page 1 -->

KSHB-HO/164/2026-CE

I/58203/2026

KERALA STATE HOUSING BOARD
Office of the Chief Engineer, Santhi Nagar, Thiruvananthapuram -1
No: KSHB-HO/164/2026-CE

Dated17-08-2026

NOTICE INVITING TENDER
e-Government Procurement (e-GP)
TENDER NO: 2026_CE_KSHB_04(W)
The Chief Engineer, Kerala State Housing Board (KSHB), Head Office,
Thiruvananthapuram for and on behalf of the KSHB invites online bids for
the work detailed below from the Registered Bidders of Kerala
PWD/Central PWD/Other Central or State Government Departments/State
or Central Public Sector Undertakings etc who have successfully completed
at least one similar work costing more than 40% (Forty percentage) of the
estimated cost of the work within the last five years. A certificate to this
effect from the agreement executing authority of the completed similar work
shall invariably be submitted along with the tender documents failing which
the tenders will not be accepted. The certificate should contain the details
such as name of work, agreement number, date of start and completion as
per agreement, completed amount of work etc.
Name of
1
Work

Maintenance work of Upper and Lower Zone building of Housing
Board at Santhinagar, Thiruvananthapuram -Civil and Electrical
works-Phase 1

Location
Thiruvananthapuram District
of Work
Estimated
3 Cost of the ₹ 5,49,10,758/-(Excluding GST)
Work
Civil works- Wall paneling and its frame work, demolishing works,
Brief
false ceiling, tiling, doors and fittings, truss work, new toilet
4 description construction, sanitary installations and plumbing works
of work
Electrical work- panel board, lift, electrical works, light protection
system, DG etc
Bidding
5
E tender – Two cover system
procedure
Bid
6
₹2,00,000
Security
Bid
submission
7
₹11,025+(1985)GST
fee(tender
fee)
2

<!-- page 2 -->

KSHB-HO/164/2026-CE

I/58203/2026

8
9

Period of completion
Classification of Bidder
Last date and time for submission
10
of bids
Pre Bid meeting – Date, time and
11
place

8 months
A Class
05/09/2026 5.00 pm
24/08/2026 11.00 AM
Chief Engineer's office KSHB,
Trivandrum

Date and time of opening of
07/09/2026 11.00AM
Technical Bid
Bid documents including the Bill of Quantities (BoQ) can be downloaded free of cost
from the e- Government Procurement (e-GP) Website www.etenders.kerala.gov.in.
All bid documents are to be submitted online only and in the designated cover(s)/
envelope(s) on the e-GP website. Tenders/ bids shall be accepted only through online
mode on the e-GP website and no manual submission of the same shall be entertained.
Late tenders will not be accepted. A bid submission fee shall be remitted online
during the time of bid submission.
All bid documents mentioned in Clause 4.3 shall be submitted through online. Also,
Price Bid shall only be submitted through online. Details regarding remittance of Bid
Submission Fee, Bid Security, Bid preparation and submission are mentioned in the
bid document.
The technical bids shall be opened online on 07/09/2026 , 11.00 AM at the office of
the Chief Engineer, KSHB, Head Office, Thiruvananthapuram in the presence of
the Bidders / their authorized representatives who wish to attend at the above address.
If the tender opening date happens to be on a holiday or non- working day due to any
other valid reason, the tender opening process will be done on the next working day at
same time and place. The technical bids submitted by the Bidders will be evaluated as
per the terms and conditions set out in the bid document for pre-qualification and the
price bid of only the pre-qualified Bidders shall be opened. The date and time of
opening of the Price bid will be intimated by e- mail to the Bidders who are Prequalified after evaluation of Technical Bids and will be published on the notice board
at the office of the Tender Inviting Authority.
Online Tenders/ bids are to be accompanied by a scanned image of the preliminary
agreement executed in Kerala stamp paper worth Rs.200/-. Tenders/ bids received
online without the details mentioned in clause 4.4 of Part-I Instructions to the Bidders
will not be considered and shall be summarily rejected.
More details can be had from the NIT or Office of the Chief Engineer, Kerala State
Housing Board (KSHB) Head Office, Thiruvananthapuram during working hours.
All other existing conditions related to bidding in force in the Kerala Public Works
Department will be applicable in this tender also unless expressly defined in the
bidding document. The Tender Inviting Authority/Employer shall not be responsible
for any failure, malfunction or breakdown of the electronic system while downloading
or uploading the documents by the Bidder during the e-procurement process.
Details required for e-payment (Details of bank account having core banking facility
and e- mail address of the contractor) shall be furnished along with the tender. Tenders
12

<!-- page 3 -->

KSHB-HO/164/2026-CE

I/58203/2026

not accompanied by these details will be rejected. All subsequent Government orders
connected to tenders and any revision in the rates of taxes would also be applicable to
this tender.
T h e Chief Engineer, Kerala State Housing Board (KSHB) Head Office,
Thiruvananthapuram reserves the right to accept or reject any or all tenders without
assigning any reason thereof.

CHIEF ENGINEER
Kerala State Housing Board (KSHB)
Head Office
Thiruvananthapuram
(For and on behalf of KSHB)
