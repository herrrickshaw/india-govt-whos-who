---
doc_id: "acd0388a6d25efdd"
source_url: "https://www.keralaenergy.gov.in/images/go/kcecf_financialscheme.pdf"
ministry: "Energy Management Centre, Kerala"
title: "KERALA STATE ENERGY CONSERVATION FUND (KSECF) FINANCING SCHEMES"
date: ""
pages: 34
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6a3223af5f7c780c"
---

<!-- page 1 -->

Kerala State Energy Conservation Fund

KERALA STATE ENERGY CONSERVATION FUND (KSECF)
FINANCING SCHEMES
FINAL REPORT

Report Prepared for
Energy Management Centre
Department of Power, Kerala

Prepared by
Dilip R. Limaye
Dr. Bhaskar Natarajan
B. Anil Kumar
Swati Lal
Dr. Pradeep Tharakan
International Resources Group, Ltd.

For
ECO Asia Clean Development and Climate Program
www.usaid.eco-asia.org/programs/cdcp

November 2009

<!-- page 2 -->

Kerala State Energy Conservation Fund

Table of Contents

SECTION 1 - INTRODUCTION ................................................................................................................... 2
BACKGROUND ......................................................................................................................................... 2
WHY THE ENERGY CONSERVATION FUND? ....................................................................................... 2
RATIONALE FOR KSECF ......................................................................................................................... 2
OBJECTIVES AND SCOPE OF KSECF ...................................................................................................... 3
DESIGN OF THE KSECF............................................................................................................................ 3
PROPOSED FINANCING SCHEMES......................................................................................................... 4
BUDGET ALLOCATION ........................................................................................................................... 4
SECTION 2 - ENERGY AUDIT SUBSIDY SCHEME ................................................................................. 7
INTRODUCTION ....................................................................................................................................... 7
WHAT IS AN ENERGY AUDIT? ................................................................................................................ 7
DESCRIPTION OF KSECF ENERGY AUDIT SUBSIDY SCHEME ........................................................... 7
Eligibility ................................................................................................................................................ 7
Amount of Funding Provided ................................................................................................................... 8
Maximum Amount ................................................................................................................................... 8
Total Budget............................................................................................................................................ 8
Requirements .......................................................................................................................................... 8
Application Deadline............................................................................................................................... 9
Application and Review Process .............................................................................................................. 9
SECTION 3 - INTEREST BUY-DOWN SCHEME FOR COMMERCIAL/INDUSTRIAL CUSTOMERS
...................................................................................................................................................................... 11
INTRODUCTION ..................................................................................................................................... 11
WHY INTEREST BUY-DOWN?............................................................................................................... 11
HOW WILL THE IBD SCHEME WORK? ................................................................................................. 11
DESCRIPTION OF THE INTEREST BUY-DOWN SCHEME ................................................................... 11
Facility Eligibility ................................................................................................................................. 11
Eligibility of Project .............................................................................................................................. 12
Participating Financial Institutions ....................................................................................................... 12
Project Size ........................................................................................................................................... 12
Amount of Interest Buy-Down ................................................................................................................ 12
Payment to the Financial Institution ...................................................................................................... 12
Total Budget.......................................................................................................................................... 12
Application Deadline............................................................................................................................. 13
Application and Review Process ............................................................................................................ 13
Calculation of Lump-sum Payment for Interest Buy-Down ..................................................................... 14
Application Form .................................................................................................................................. 14
SECTION 4 - ENERGY ............................................................................................................................... 16
INTRODUCTION ..................................................................................................................................... 16
WHY ENERGY EFFICIENT APPLIANCE FINANCING? ........................................................................ 16
HOW WILL THE EEAF SCHEME WORK? .............................................................................................. 16
DESCRIPTION OF THE EELF SCHEME ................................................................................................. 17
Customer Eligibility .............................................................................................................................. 17
Eligibility of Appliances ........................................................................................................................ 17
Participating Financial Institution ......................................................................................................... 17
Interest Rate .......................................................................................................................................... 17
Loan Term ............................................................................................................................................ 17
Participating Manufacturers.................................................................................................................. 17
Fund Size .............................................................................................................................................. 17

<!-- page 3 -->

Kerala State Energy Conservation Fund

Application Deadline............................................................................................................................. 17
Application and Review Process ............................................................................................................ 18
Calculation of Payment for Interest subsidy to FI................................................................................... 18
Application Form .................................................................................................................................. 18
SECTION 5 - ENERGY EFFICIENCY GRANT SCHEME FOR PUBLIC SECTOR PROJECTS ......... 20
INTRODUCTION ..................................................................................................................................... 20
DESCRIPTION OF KSECF ENERGY EFFICIENCY GRANT SCHEME .................................................. 20
Eligible Organizations........................................................................................................................... 20
Eligibility of Project .............................................................................................................................. 20
Amount of Funding Provided ................................................................................................................. 21
Maximum Amount ................................................................................................................................. 21
Total Budget.......................................................................................................................................... 21
Application Deadline............................................................................................................................. 21
Application and Review Process ............................................................................................................ 21
Application Form .................................................................................................................................. 21
SECTION 6 - PERFORMANCE CONTRACTING SCHEME FOR PUBLIC SECTOR PROJECTS..... 23
INTRODUCTION ..................................................................................................................................... 23
WHAT IS PERFORMANCE CONTRACTING? ........................................................................................ 23
BENEFITS OF PERFORMANCE CONTRACTING .................................................................................. 23
DESCRIPTION OF KSECF’S PERFORMANCE CONTRACTING SCHEME ........................................... 24
Eligible Organizations........................................................................................................................... 24
How will the Performance Contracting Scheme be carried out? ............................................................. 24
Project Size ........................................................................................................................................... 25
Funding ................................................................................................................................................ 25
Budget .................................................................................................................................................. 25
Selection of Agencies and Schedule........................................................................................................ 26
SECTION 7 - PARTIAL CREDIT GUARANTEE SCHEME .................................................................... 28
INTRODUCTION ..................................................................................................................................... 28
PARTIAL CREDIT GUARANTEES ......................................................................................................... 28
CREDIT GUARANTEE TRUST FUND FOR MICRO AND SMALL ENTERORISES (CGTMSE) ............ 29
KSECF CREDIT GUARANTEE SCHEME ............................................................................................... 29
DESCRIPTION OF THE PARTIAL CREDIT GUARANTEE SCHEME .................................................... 30
Facility Eligibility ................................................................................................................................. 30
Eligibility of Project .............................................................................................................................. 30
Participating Financial Institutions ....................................................................................................... 30
Project Size ........................................................................................................................................... 30
Total Budget.......................................................................................................................................... 31

<!-- page 4 -->

Kerala State Energy Conservation Fund

SECTION 1
INTRODUCTION

Financing Schemes

Page 1

March 2009

<!-- page 5 -->

Kerala State Energy Conservation Fund

SECTION 1 - INTRODUCTION

BACKGROUND
In May 2008, the ECO-Asia Clean Development and Climate Program (ECO-Asia
CDCP) entered into a partnership agreement with the Energy Management Centre,
Department of Power, Government of Kerala, to support the creation and
implementation of the Kerala State Energy Conservation Fund (KSECF) in response
to India’s national Energy Conservation Act of 2001 which requires Indian states to
establish energy conservation funds at the state level to facilitate implementation of
energy efficiency projects. While many states have considered the establishment of
such funds, Kerala is the first to take the initiative to establish the KSECF.
WHY THE ENERGY CONSERVATION FUND?
A State energy conservation fund is needed to overcome the major financing barriers
in Kerala that include the following:


The relatively small size of energy efficiency (EE) projects makes them
less attractive for conventional bank financing.



The concept of “project financing” has not yet been accepted for EE
projects.
Conventional lenders do not have sufficient knowledge and understanding
of EE technologies and their economic and financial characteristics.
Financial institutions may perceive EE projects as more risky than their
other conventional lending.
The transaction costs for EE projects are relatively high.
EE projects have a relatively high proportion of “soft costs.”






In addition, Kerala has to comply with the requirements of the Energy Conservation
Act, 2001 (EC Act). The EC Act is the most important legislative initiative related to
energy efficiency in India’s history. Its purpose is to “provide for efficient use of
energy and its conservation and for matters connected therewith or incidental thereto.”
The Act empowered the Central Government, State Governments and the newly
established Bureau of Energy Efficiency (BEE) with certain powers and functions.
One of the key elements of the Act as it related to the States is the mandatory
requirement for the establishment of a designated agency “to coordinate, regulate and
enforce provisions of this Act within the State.”
In response to these requirements Kerala has nominated the EMC as the designated
agency for the purposes of the EC Act. EMC has developed the preliminary structure
of the Kerala State Energy Conservation Fund (KSECF) and drafted the rules for the
KSECF.
RATIONALE FOR KSECF
The KSECF will:


Facilitate increased implementation of energy efficiency (EE) projects by
large energy users

Financing Schemes

Page 2

March 2009

<!-- page 6 -->

Kerala State Energy Conservation Fund



Facilitate engagement of commercial financial institutions to participate in
EE project financing



Facilitate ESCO industry development and participation in EE project
implementation
Demonstrate leadership in EE through implementation of EE projects in
the public sector
Alleviate the power shortage and related impacts on the state economy
Meet the mandated requirements of the EC Act, 2001





OBJECTIVES AND SCOPE OF KSECF
The objectives and scope of the KSECF are summarized below 1:










Support the financing of specific EC projects using a variety of options
such as debt financing, equity financing, grants, and credit or risk
guarantees to financial institutions.
Contribute to the development of the EE market in Kerala by financing
projects with private sector implementation through energy service
delivery organizations (such as ESCOs).
Develop and demonstrate model financial transactions.
Develop typical financing agreements that can be used by the private
sector.
Build the capacity of local financial institutions in EE project transactions
to increase their knowledge, interest and capability for financing such
projects
Leverage commercial funds and create a sustainable market for EC project
financing.

The KSECF shall provide financing for all energy consuming sectors, including
industrial, SME, commercial, domestic, street lighting, and agriculture sectors.
DESIGN OF THE KSECF
The KSECF will initially be managed by the EMC. As the fund size grows, EMC will
have to add substantial capacity in the area of financing and financial management.
Therefore, it has been recommended that the Government of Kerala (GOK) consider
the engagement of a professional fund manager under the direction of the EMC. Other
options that may be considered by GOK for fund management include a newly
created Trust or Agency similar to the Energy Trust of Oregon or the New York State
Energy Research and Development Authority (NYSERDA). The KSECF shall have a
Steering Committee comprised of representatives of the major stakeholders.
There is a wide range of potential funding sources for the KSECF. These may include
funds from Kerala Electricity Surcharge, budget allocation from the State

1

See Limaye et al, Establishment of the Kerala State Energy Conservation Fund: Design Report,
Submitted to the Energy Management Centre, Department of Power, Kerala, by ECO Asia CDCP,
November 2008.

Financing Schemes

Page 3

March 2009

<!-- page 7 -->

Kerala State Energy Conservation Fund

Government, special taxes or levies, government bonds, funds from the Bureau of
Energy Efficiency (BEE), bilateral and multilateral donor agencies, commercial
financial institutions, and international financial institutions; fees from certification
and labeling; and carbon financing2.
The Government of Kerala will initially provide funds amounting to about Rs. 1 crore
for the KSECF from the State budget. It is anticipated that the Bureau of Energy
Efficiency (BEE) shall provide matching funds for the KSECF. The total size of the
Fund in the Fiscal Year 2009-2010 is therefore assumed to be Rs. 2 crores.
PROPOSED FINANCING SCHEMES
In the initial design of the KSECF3, a number of schemes were identified which may
be used in a variety of ways to finance EC projects. The design and funding of the
KSECF, including the various financing mechanisms, were discussed at a
Consultative Meeting with Kerala State government officials representing a number
of stakeholder departments in October 2008. Based on the results of these discussions,
the following financing schemes were selected as candidates for initial
implementation.







Energy Audit Subsidy Scheme
Interest Buy-Down Scheme for Commercial and Industrial Customers
Energy Efficiency Loan Fund for Domestic Customers
Energy Efficiency Grant Scheme for Public Sector Projects
Performance Contracting Scheme
Partial Credit Guarantee Scheme

This report provides a description of these financing schemes including the rationale
for their use and the implementation rules and procedures. Additional financing
schemes will be developed and implemented as the Fund size grows in future years.
BUDGET ALLOCATION
The budget allocation for the various schemes implemented in the Fiscal Year 20092010 is shown in Table 1-1.

2

See Limaye, et al, op cit.

3

Ibid.

Financing Schemes

Page 4

March 2009

<!-- page 8 -->

Kerala State Energy Conservation Fund

Table 1-1 - Budget Allocation

SCHEME

TARGET MARKETS

BUDGET
(RS. LAKHS)

Energy Audit Subsidy Scheme

Industrial, Commercial
and Public

25.0

Interest Buy-Down Scheme

Industrial & Commercial

50.0

Energy Efficient Appliance
Financing Scheme

Residential

30.0

Energy Efficiency Grant Scheme

Public (incl. Municipal)

20.0

Performance Contracting Scheme

Public (incl. Municipal)

20.0

Partial Credit Guarantee Scheme

Industrial & Commercial

30.0

Management and Administration

-

15.0

Contingency Fund

-

10.0

TOTAL BUDGET

Financing Schemes

Page 5

200.0

March 2009

<!-- page 9 -->

Kerala State Energy Conservation Fund

SECTION 2
ENERGY AUDIT SUBSIDY SCHEME

Financing Schemes

Page 6

March 2009

<!-- page 10 -->

Kerala State Energy Conservation Fund

SECTION 2 - ENERGY AUDIT SUBSIDY SCHEME

INTRODUCTION
The first important step in the implementation of energy efficiency measures is the
identification of cost-effective opportunities for energy savings and related costreduction. A facility energy audit (also known as an energy feasibility study) includes
such identification and assessment of energy efficiency measures (EEMs) and
provides the facility owner and/or manager an overview of the economic benefits
from implementing the EEMs. It has been generally recognized that obtaining funds
for conducting energy audits has often been a barrier. KSECF will offer the Energy
Audit Subsidy scheme (EAS) to facilitate the conducting of energy audits.
WHAT IS AN ENERGY AUDIT?
An energy audit is a systematic assessment of opportunities for improvement of
energy efficiency through the implementation of EEMs in a facility. The energy audit
typically consists of the following steps:









Collection of information of facility characteristics, including major
energy using equipment, physical characteristics, and operating
characteristics
Collection and organization of data on facility energy consumption energy
Development of a Baseline defining the key facility and energy
characteristics
Identification of the applicable EEMs
Technical and economic assessment of the EEMs
Development of economic and financial parameters such as payback, ROI,
NPV, and preliminary financing plan
Preparation of the Detailed Project report (DPR)

DESCRIPTION OF KSECF ENERGY AUDIT SUBSIDY SCHEME
KSECF offers a subsidy for energy audits to encourage and promote the conducting
of energy audits for industrial, commercial and institutional facilities in Kerala. A
description of the Energy Audit Subsidy scheme is provided below:

Eligibility
The following types of facilities are eligible to apply for funds under the EAS scheme







Industrial plants
Commercial buildings
Hospitals and health care facilities
State and local government buildings
Municipal pumping facilities (water treatment, waste water, etc.)
Municipalities operating street lighting

Financing Schemes

Page 7

March 2009

<!-- page 11 -->

Kerala State Energy Conservation Fund





Universities and colleges
Schools
Religious facilities

Amount of Funding Provided
KSECF will provide 50% of the cost of the energy audit subject to the terms and
conditions defined herein

Maximum Amount
The maximum amount of funding provided by KSECF for an audit of a single facility
shall be the lesser of Rs. 1 lakh or 15% of the facility’s annual energy consumption
during the prior year.

Total Budget
The total budget for this scheme during the fiscal year 2009-2010 is Rs. 25 lakhs.

Requirements
The following are the requirements to obtain funds under the EAS scheme.
1. The facility must be eligible according to the eligibility criteria stated
above
2. The energy audit must be conducted by an Energy Auditor or Manager
certified by the Bureau of Energy Efficiency (BEE).
3. KSECF shall select and maintain lists of certified energy auditors and
managers for industrial, commercial and public sector projects.
4. Applications for funding must provide documentation of the source of
funds for the applicant’s share of 50% of the total costs.
5. Upon receipt of the customer application, KSECF shall solicit bids from its
list of auditors, and select and assign the auditor to the applicant.
6. The energy audits must be completed within 3 months of authorization by
KSECF.
7. KSECF will reimburse 50% of the actual cost of conducting the energy
audit up to the maximum as defined above. A payment of 25% shall be
made by KSECF to the auditor at the initiation of the audit. KSECF shall
pay the auditor the remaining 25% upon completion and submission of the
audit report and acceptance by KSECF and the customer.
8. Any costs incurred prior to the approval of the application under the EAS
scheme shall not be eligible for 50% reimbursement.
9. Detailed engineering design is considered a part of the implementation
process and will not be eligible for 50% reimbursement.
10. Equipment purchases are not eligible for 50% reimbursement.
11. No single organization will receive more than 20% of the total funds
available under this scheme.

Financing Schemes

Page 8

March 2009

<!-- page 12 -->

Kerala State Energy Conservation Fund

12. The facility or the energy auditor will be required to submit a Detailed
Project Report (DPR) documenting the audit results as specified by
KSECF, before cost reimbursement is made.

Application Deadline
Applications for funding under the EAS scheme should be submitted to KSECF by no
later than December 31, 2009. However, applications will be considered on a first
come first served basis as they are received, until the total budgeted funds are
committed. If the available funds are exhausted while applications have been received
and are still under review, these applications will be held in an “application pipeline”
and will be processed if additional funds become available. At the discretion of
KSECF, these applications may be considered or requested to be resubmitted under
the subsequent year funding. However, no applications received after December 31,
2009 will be considered for funding under this year’s budget.

Application and Review Process
Any eligible facility may submit an application using the EAS Application Form.
Upon receipt of the application, KSECF shall review the submitted information to
assess whether the application meets the eligibility requirements. If it does not meet
the requirements it shall be returned to the applicant. If it meets the requirements,
KSECF shall inform the applicant that the application is under review.
After completion of the review KSECF may seek clarifications from the applicant or
negotiate certain elements of the application. When the application is approved,
KSECF shall send an Approval Letter to the applicant.
The applicant may then initiate the energy audit and upon completion, submit the
Detailed Project Report to KSECF, along with the documentation of all of the costs of
conducting the audit and preparing the DPR.
KSECF shall review the DPR, and upon approval, shall reimburse the applicant for
50% of the documented costs.
.

Financing Schemes

Page 9

March 2009

<!-- page 13 -->

Kerala State Energy Conservation Fund

SECTION 3
INTEREST BUY-DOWN SCHEME
FOR COMMERCIAL AND INDUSTRIAL CUSTOMERS

Financing Schemes

Page 10

March 2009

<!-- page 14 -->

Kerala State Energy Conservation Fund

SECTION 3 - INTEREST BUY-DOWN SCHEME FOR
COMMERCIAL/INDUSTRIAL CUSTOMERS
INTRODUCTION
Most energy efficiency projects require a capital investment to be made in energyefficient products, technologies and/or equipment. The implementation of the project
leads to energy savings which in turn provide energy costs savings, which can be used
to pay off the investment costs. Many energy efficiency projects are financed using
loan funds from financial institutions. The economic attractiveness of the project is
therefore influenced by the interest rate at which the project financing has been made
available. The economics of the EE project (discounted payback, cash flow, and net
present value) can therefore be improved if the financing can be made available at a
low interest rate.
WHY INTEREST BUY-DOWN?
A low interest loan can be provided for EE projects by simply making available funds
from the KSECF to the project developer or implementer as a direct loan from
KSECF. However, this approach will require the KSECF to have a large pool of funds
available for the program, since KSECF would have to provide all the financing. An
alternative approach that has been adopted by KSECF is to work with commercial
financial institutions and provide them an “interest buy-down” that wil enable them to
reduce the interest charged to the borrower. This Interest Buy-Down Scheme (IBD)
will allow KSECF to provide financing for a larger number of projects with the
available resources.
HOW WILL THE IBD SCHEME WORK?
KSECF shall select a number of participating financial institutions (FIs) to implement
this scheme and negotiate the terms of the scheme including any interest reduction
offered by the FIs. The participating FIs will sign agreements with KSECF, the format
of which is provided later in this Section. A borrower interested in obtaining financing
for an EE project will simultaneously submit an application to KSECF and to one of
the participating FIs. KSECF will be responsible for validating that the project meets
the criteria for energy efficiency as established by KSECF. The FI will conduct the
usual due diligence including credit evaluation and other assessments to determine the
eligibility of the borrower to get the loan. The FI will then approve the loan terms in
accordance with its commercial lending practices. KSECF will provide funds to the FI
to reduce the interest rate to the borrower. The FI will then issue the loan at a lower
interest rate than the commercial borrowing rate. Details are provided below.
DESCRIPTION OF THE INTEREST BUY-DOWN SCHEME
The Interest Buy-Down Scheme will operate as follows:

Facility Eligibility
The following types of facilities are eligible to apply for funds under the EAS scheme

Financing Schemes

Page 11

March 2009

<!-- page 15 -->

Kerala State Energy Conservation Fund








Industrial plants
Commercial buildings
Hospitals and health care facilities
Universities and colleges
Schools
Multifamily buildings

The facility needs to meet the criteria for commercial borrowers established by the
financial institution.

Eligibility of Project
Any EE project that provides energy and cost savings in an eligible facility is eligible
for the IBD scheme provided that:




It is supported by an energy audit conducted by an accredited energy
auditor
The DPR is submitted with the application
The simple payback for the project (capital costs divided by average
annual cost savings) is not less than two years and not more than seven
years.

Participating Financial Institutions
Any financial institution may participate in the IBD program by signing a
Participation Agreement with KSECF. A list of participating FIs will be published by
KSECF.

Project Size
The minimum project size shall be established by the participating FIs. The maximum
project size may also be established by the FI, but KSECF will provide interest buydown for only the first Rs. 1 crore of investment.

Amount of Interest Buy-Down
KSECF shall provide an interest buy-down of 4% below the standard commercial
borrowing rate of the FI, which will be negotiated and specified in the Agreement
between the FI and KSECF. The KSECF IBD will only apply for the first 5 years of
the loan. If the loan period is longer than 5 years, the interest rate will revert to the
standard commercial borrowing rate after 5 years.

Payment to the Financial Institution
KSECF shall make a one-time front-end payment to the FI at the time of the closing
of the loan financing to enable the FI to offer an interest rate 4% below its standard
commercial borrowing rate for the first five years of the loan. The methodology for
calculation of the payment from KSECF to the FI is shown later in this Section.

Total Budget
The total budget for this scheme during the fiscal year 2009-2010 is Rs. 50 lakhs.

Financing Schemes

Page 12

March 2009

<!-- page 16 -->

Kerala State Energy Conservation Fund

Application Deadline
Applications for funding under the IBD scheme should be submitted to KSECF and
one of the FIs by no later than December 31, 2009. Applications will be reviewed on a
first come first served basis as they are received, until the total budgeted funds are
committed. If the available funds are exhausted while applications have been received
and are still under review, these applications will be held in an “application pipeline”
and will be processed if additional funds become available. At the discretion of
KSECF, these applications may be considered or requested to be resubmitted under
the subsequent year funding. However, no applications received after December 31,
2009 will be considered for funding under this year’s budget.

Application and Review Process
1. Any eligible facility may submit an application for an eligible project to
KSECF using the IBD Application Form
2. The facility shall simultaneously submit an application to one of the
participating FIs using the FI’s application form.
3. Upon receipt of the application, KSECF shall request the FI to confirm
that the project is considered eligible for a loan from the FI and that the FI
is proceeding with the due diligence for the borrower and the project.
4. Upon receiving such confirmation from the FI, KSECF shall review the
submitted information to assess whether the application meets the
eligibility requirements.
5. If the project does not meet the requirements, KSECF shall return it to the
applicant and inform the relevant FI that the project does not meet the
eligibility requirements of the IBD scheme.
6. If the project meets the requirements, KSECF shall so inform the applicant
and the FI, and request the FI to complete the credit analysis and other due
diligence for the application.
7. Once the FI approves the loan for the project and determines the terms and
conditions of the loan, KSECF shall calculate the amount of payment to be
made to buy down the interest rate by 4% for a period of no more than 5
years. An example of the calculation is shown below.
8. KSECF shall then sign a project agreement with the FI to provide a frontend lump sum payment to the FI at the time of the loan closing to buy
down the interest rate. The Agreement shall also specify that the FI shall
use the lump sum payment to reduce the interest rate on the loan and shall
NOT provide the payment directly to the borrower.
9. The borrower shall be required to provide to KSECF a Certificate of
Completion within 60 days of the completion of installation of the EE
measures verifying that the EE measures proposed in the Application have
been installed. Failure to provide such a Certificate of Completion shall
constitute an Event of Default and the Interest Buy-Down shall be
forfeited by the borrower.
10. The FI shall be required to provide to KSECF a “Return Payment” in case

Financing Schemes

Page 13

March 2009

<!-- page 17 -->

Kerala State Energy Conservation Fund

the Certificate of Completion is not provided by the borrower, or if the
borrower’s loan is retired at a date earlier than five years.

Calculation of Lump-sum Payment for Interest Buy-Down
KSECF shall calculate the lump-sum front-end payment to the FI by calculating the
net present value, using a discount rate equal to the FI’s standard commercial
borrowing rate, of the difference between the monthly payment of the approved loan
amount at the standard commercial borrowing rate and the reduced interest rate
offered to the customer under this scheme (4% lower rate), with the calculation period
being five years. An example of the calculation is provided below.

Loan Amount:

Rs. 80,00,000

Standard Borrowing Rate:

12%

KSECF Interest Buy-Down:

4%

Reduced Rate under IBD Scheme:

8%

Loan Term:

7 years

Monthly Payment at 12%:

Rs. 1,41,222

Monthly Payment at 8%:

Rs. 1,24,690

Difference:

Rs.

NPV of Difference over 5 years:

Rs. 9,36,521

16,532

In this example, with the loan amount at Rs. 80 lakhs and the standard borrowing rate
of 12% annually, the 4% interest buy-down by KSECF amounts to a lump-sum
payment to the FI of about 9.4 lakhs. The customer monthly payment is reduced from
Rs. 1.41 lakhs to Rs. 1.25 lakhs.

Application Form

Financing Schemes

Page 14

March 2009

<!-- page 18 -->

Kerala State Energy Conservation Fund

SECTION 4
ENERGY EFFICIENT APPLIANCE FINANCING SCHEME
FOR DOMESTIC CUSTOMERS

Financing Schemes

Page 15

March 2009

<!-- page 19 -->

Kerala State Energy Conservation Fund

SECTION 4 - ENERGY EFFICIENT APPLIANCE FINANCING
SCHEME FOR DOMESTIC CUSTOMERS
INTRODUCTION
There is significant potential for energy savings in the domestic sector. Since much of
the energy consumption in residences is for domestic appliances, the use of energy
efficient appliances can contribute significantly to energy savings. However, since
energy efficient appliances are more expensive than inefficient ones, domestic
consumers are often not willing to invest their own funds to achieve the energy
savings that will provide costs savings. The Bureau of Energy Efficiency has devised
an energy efficiency rating program for domestic appliances and published a “star
rating” scheme for refrigerators and air conditioners. Appliances with four or five
stars are considerably more efficient than those with lower star ratings.
In this scheme, KSECF will create, in cooperation with a local financial institution
and manufacturers of energy efficient refrigerators and air conditioners, an Energy
Efficient Appliance Financing (EEAF) scheme that will provide zero interest
financing and manufacturer rebates on four and five start rated refrigerators and air
conditioners.
WHY ENERGY EFFICIENT APPLIANCE FINANCING?
The higher rated (four or five star) refrigerators and air conditioners may cost 30% to
50% more than inefficient appliances. While the higher efficiency appliances
consume less energy and therefore are less expensive to operate, consumers are
unwilling to pay the higher cost of the efficient appliances. KSECF will facilitate the
purchase of efficient refrigerators and air conditioners by providing zero interest loans
through a local financial institution (FI). In addition KSECF shall initiate a
cooperative program with manufacturers of EE refrigerators and air conditioners
under which the manufacturers will provide rebates for purchases of these appliances
sin Kerala.
HOW WILL THE EEAF SCHEME WORK?
KSECF will select a financial institution (FI) interested in and willing to provide
financing to domestic customers for purchase of four and five star refrigerators and air
conditioners. KSECF will provide funds from the EEAF scheme to the FI to allow the
customer to obtain one year zero interest loans for the appliance purchases. The FI
will invite applications from customers for purchase of qualifying energy efficient
appliances (initially four and five star refrigerators and air conditioners). The FI will
conduct the appropriate credit analysis and due diligence of the proposed customer.
The customer will get a zero interest loan payable over a one year period. KSECF will
reimburse the FI for the interest cost of the loan.
In addition, KSECF will select using a competitive process a group of manufacturers
and/or suppliers of four and five star refrigerators and air conditioners and promote
these efficient appliances in cooperation with the selected manufacturers throughout
Kerala. The manufacturers participating in the program will provide a rebate or
Financing Schemes

Page 16

March 2009

<!-- page 20 -->

Kerala State Energy Conservation Fund

discount to the customer purchasing the appliance. Thus the customers will get a
double benefit from choosing to buy the efficient appliances - rebates plus a zero
interest loans.
DESCRIPTION OF THE EELF SCHEME
The EEAF will operate as follows:

Customer Eligibility
The EELF scheme will be available to any domestic customer in Kerala.

Eligibility of Appliances
The EEAF scheme is applicable to four star and five star rated refrigerators and air
conditioners.

Participating Financial Institution
KSECF will select a financial institution (FI) and sign a Participation Agreement with
the FI. KSECF shall inform customers of the participating FI.

Interest Rate
The FI shall offer a zero interest loan to the customer. KSECF shall provide the FI
with a lump-sum payment to cover the interest costs.

Loan Term
The term of the loan shall be one year.

Participating Manufacturers
KSECF shall select, using a competitive bid process, a group of manufacturers and
suppliers of the eligible appliances and conduct a cooperative marketing and
promotion campaign for the efficient appliances with these manufacturers/suppliers.
The manufacturers and suppliers will be selected based on their willingness to offer a
rebate or discount to customers in Kerala.

Fund Size
KSECF shall provide a fund of Rs. 30 lakhs as the initial financing for the EEAF
scheme. Of this amount 20 lakhs will be for the interest subsidy to the FI and 10 lakhs
for the cooperative marketing and promotion program. The size of the EEAF will be
increased in future years.

Application Deadline
Applications for funding under the EEAF scheme should be submitted to the FI by no
later than December 31, 2009. Applications will be reviewed by the FI on a first come
first served basis as they are received, until the total budgeted funds are committed. If
the available funds are exhausted while applications have been received and are still
under review, these applications will be held in an “application pipeline” and will be
processed if additional funds become available. However, no applications received
after December 31, 2009 will be considered for funding under this year’s budget.

Financing Schemes

Page 17

March 2009

<!-- page 21 -->

Kerala State Energy Conservation Fund

Application and Review Process
The application and review process will follow the rules and procedures of the
selected FI. These will be published by KSECF when the FI is selected.

Calculation of Payment for Interest subsidy to FI
KSECF shall calculate the lump-sum front-end payment to the FI by calculating the
net present value of the interest costs, based on a negotiated commercial borrowing
rate (negotiated with the FI at the beginning of the scheme). An example of the
calculation is provided below.

Cost of Appliance:

Rs. 15,000

Negotiated Borrowing Rate:

12%

Interest Rate to Customer:

0%

Loan Term:

1 year

Monthly Payment at 12%:

Rs. 1,333

Monthly Payment at 0%:

Rs. 1,250

Difference:

Rs.

NPV of Difference:

Rs. 931

83

In this example, with the loan amount for the appliance is Rs. 15,000. The monthly
payment at a rate of 12% annually would be Rs. 1,333. At a zero interest the monthly
payment is Rs. 1,250. The NPV of the difference is Rs. 931, and this is the amount
paid by KSECF to the FI.

Application Form
The Application Form for the EELF scheme will be prepared and published by the FI.

Financing Schemes

Page 18

March 2009

<!-- page 22 -->

Kerala State Energy Conservation Fund

SECTION 5
ENERGY EFFICIENCY GRANT SCHEME
FOR PUBLIC SECTOR PROJECTS

Financing Schemes

Page 19

March 2009

<!-- page 23 -->

Kerala State Energy Conservation Fund

SECTION 5 - ENERGY EFFICIENCY GRANT SCHEME FOR
PUBLIC SECTOR PROJECTS

INTRODUCTION
Many public sector energy efficiency projects can provide high social value but the
agency or organization sponsoring the project may not have access to funds for
implementing the project or the economic payback from the project may be too long.
In such situations it would be desirable to provide a grant to cover a portion of the
project cost to facilitate the implementation of the project. One example of such a
project is energy efficiency improvement in low-income housing where the residents
do not have sufficient funds to invest in efficient equipment. Another example is
energy efficiency improvement in public facilities such as public libraries, museums,
etc. A portion of the KSECF funds shall be set aside for providing grants to such
projects.
DESCRIPTION OF KSECF ENERGY EFFICIENCY GRANT SCHEME
KSECF offers grants for energy efficiency projects in the public sector to encourage
and promote the implementation of energy efficiency projects in the public sector in
cases where the project has a high social value and the project sponsor is not able to
obtain funding for the project without some assistance in the form of a grant. A
description of the Energy Efficiency Grant scheme is provided below:

Eligible Organizations
The following types of facilities are eligible to apply for funds under the EAS scheme









Public hospitals and health care facilities
State and local government buildings
Municipal pumping facilities (water treatment, waste water, etc.)
Municipalities operating street lighting
Public universities and colleges
Public schools
Religious facilities
Low income housing

Eligibility of Project
Any EE project that provides energy and cost savings in a facility is eligible for the
Energy Efficiency Grant (EEG) scheme, provided that:




The energy efficiency project demonstrates high social value.
It is supported by an energy audit conducted by an accredited energy
auditor
The DPR is submitted with the application

Financing Schemes

Page 20

March 2009

<!-- page 24 -->

Kerala State Energy Conservation Fund



The simple payback for the project (capital costs divided by average
annual cost savings) is not less than one years and not more than seven
years.

Amount of Funding Provided
KSECF will provide up to 50% of the cost of the public sector energy efficiency
project as a grant up to the maximum specified herein.

Maximum Amount
The maximum amount of funding provided by KSECF as a grant for a single project
shall be the lesser of Rs. 2 lakhs or 30% of the facility’s annual energy consumption
during the prior year.

Total Budget
The total budget for this scheme during the fiscal year 2009-2010 is Rs. 20 lakhs.

Application Deadline
Applications for funding under the EEG scheme should be submitted to KSECF by no
later than December 31, 2009. However, applications will be considered on a first
come first served basis as they are received, until the total budgeted funds are
committed. If the available funds are exhausted while applications have been received
and are still under review, these applications will be held in an “application pipeline”
and will be processed if additional funds become available. At the discretion of
KSECF, these applications may be considered or requested to be resubmitted under
the subsequent year funding. However, no applications received after December 31,
2009 will be considered for funding under this year’s budget.

Application and Review Process
Any eligible facility may submit an application using the EEG Application Form.
Upon receipt of the application, KSECF shall review the submitted information to
assess whether the application meets the eligibility requirements including the
statement of social value provided. If it does not meet the requirements it shall be
returned to the applicant. If it meets the requirements, KSECF shall inform the
applicant that the application is under review.
After completion of the review KSECF may seek clarifications from the applicant
with respect to technical, economic or financial aspects of the application, including
the source of the funds for the portion of the project cost not covered by the Grant.
When the application is approved, KSECF shall send an Approval Letter to the
applicant.

Application Form

Financing Schemes

Page 21

March 2009

<!-- page 25 -->

Kerala State Energy Conservation Fund

SECTION 6
PERORMANCE CONTRACTING SCHEME
FOR PUBLIC SECTOR PROJECTS

Financing Schemes

Page 22

March 2009

<!-- page 26 -->

Kerala State Energy Conservation Fund

SECTION 6 - PERFORMANCE CONTRACTING SCHEME FOR
PUBLIC SECTOR PROJECTS

INTRODUCTION
Many public sector buildings offer excellent opportunities for energy efficiency
improvement because they have generally not been built efficiently, do not have
energy efficient equipment, and have not invested in proper maintenance and
operational practices. Often this situation arises due to limited budgets of public
agencies. Even if assistance is provided to the agencies responsible for these facilities
to identify energy efficiency opportunities, limitations of budget and staff skills and
capabilities prevent these agencies from implementing EE projects. In such situations,
the approach of performance contracting using energy service companies (ESCOs)
can be an effective mechanism to implement EE projects.
WHAT IS PERFORMANCE CONTRACTING?
Performance contracting refers to energy efficiency implementation services offered
by private sector organizations Known As Energy Service Companies (ESCOs) that
are characterized by the following key attributes:


ESCOs offer a complete range of implementation services, including design,
engineering, construction, commissioning, and maintenance of the energy
efficiency measures, and monitoring and verification of the resulting energy and
cost savings.



ESCOs also offer financing (often 100%) and undertake “shared savings”
contracts, such that the payments to the performance contractor are less than the
cost savings resulting from the project implementation.



ESCOs offer specific performance guarantees for the entire project (as opposed to
individual equipment guarantees offered by equipment manufacturers or
suppliers) and generally will guarantee a level of energy and/or cost savings.



Payments to the ESCO are contingent upon demonstrated satisfaction of the
performance guarantees.



Most of the technical, financial, and maintenance risk is assumed by the ESCO
thereby substantially reducing the risks to the municipality.

A number of public agencies in India have implemented the performance contracting
approach. Examples include the Gujarat Energy Development Agency, Pune
Municipal Corporation, and the Tamil Nadu Urban Development Fund.
BENEFITS OF PERFORMANCE CONTRACTING
The potential benefits for public agencies to use the performance contracting
approach include:


Such an approach will provide performance guarantees to assure the successful
implementation of the efficiency measures.

Financing Schemes

Page 23

March 2009

<!-- page 27 -->

Kerala State Energy Conservation Fund



The ESCOs will be prepared to provide operation and maintenance services to
assure that the installed equipment continues to perform at a high level of
efficiency.



A mutually agreed upon monitoring and verification (M&V) scheme will be
established to allow for actual measurement and demonstration of the energy and
cost savings.



The ESCOs provide breadth and depth of capabilities as well as training to public
agency staff.



The public agency will be able to access external capital for project
implementation.



The public agency will substantially reduce its risks.

DESCRIPTION OF KSECF’S PERFORMANCE CONTRACTING SCHEME
KSECF will provide assistance to public agencies in Kerala to adopt the performance
contracting process for implementing energy efficiency projects in public agencies.
KSECF will develop the rules and procedures for engaging ESCOs under
performance contracts to implement EE projects in the public sector in Kerala.
KSECF will assist interested public agencies in Kerala in developing the Requests for
Expressions of Interest for qualifying and short-listing ESCOs and the more detailed
Requests for Proposals to select the ESCO as a performance contractor. KSECF will
provide the technical assistance, funding and other needed resources for implementing
the performance contracting process.

Eligible Organizations
Any public sector agency in Kerala is eligible to apply to KSECF for assistance under
this scheme. Examples include:







State and local government buildings
Municipal pumping facilities (water treatment, waste water, etc.)
Municipalities operating street lighting
Public universities and colleges
Public schools
Public hospitals and health care facilities

How will the Performance Contracting Scheme be carried out?
During the fiscal year 2009-2010, KSECF will work with one or two public agencies
to design and implement the performance contracting scheme. The key steps are as
follows:
1. KSECF shall develop the performance contracting process, including the
sample Request for EOI and RFP documents.
2. KSECF shall solicit interest from public agencies in Kerala who are interested
and willing to carry out the performance contracting process.
3. KSECF shall meet and discuss with interested agencies the specific potential
projects that may be suitable for performance contracting.

Financing Schemes

Page 24

March 2009

<!-- page 28 -->

Kerala State Energy Conservation Fund

4. Based on these discussions, KSECF shall select one or two agencies to
implement the pilot performance contracting approach.
5. Working with these agencies KSECF shall select the facility or facilities that
in which the energy efficiency projects will be implemented.
6. KSECF shall announce to the ESCO industry that it is planning to use the
performance contracting approach for EE [projects in public facilities in
Kerala, and that the first pilot projects will be implemented in the current
fiscal year.
7. KSECF shall fund energy audits of the selected facilities to identify the EE
projects and measures.
8. In cooperation with the selected agency (ies), KSECF shall develop the
evaluation and selection process and criteria for ESCOs.
9. KSECF shall issue a Request for Expressions of Interest (EOI) from ESCOs
and other energy service providers who are interested and willing to enter into
performance contracts for these projects.
10. KSECF and the cognizant agency shall review the EOIs using the preestablished evaluation criteria and develop a short list of ESCOs for issuing
the Request for Proposals (RFP).
11. KSECF shall issue the RFP o the short listed ESCOs.
12. KSECF and the cognizant public agency shall review the proposals submitted
by the ESCOs an select the best proposal for contract negotiation.
13. KSECF shall assist the agency in negotiating then performance contract.
14. KSECF shall provide technical assistance in the monitoring and evaluation of
the project performance.
15. KSECF shall document the results of the process and encourage other public
agencies to participate in the Performance Contracting Scheme in future years.

Project Size
In order to encourage a number of ESCOs to participate in the competitive selection
process, KSECF shall select projects that are between 1 to 5 crores in terms of total
project investment.

Funding
KSECF shall fund the costs of the technical assistance and the energy audits for the
current fiscal year program. KSECF shall also absorb the costs related to the process
of issuing and evaluating EOIs and RFPs and selecting and negotiating a contract with
the winning ESCO.

Budget
The KSECF budget for the fiscal year 2009-2010 for the Performance Contracting
Scheme is Rs. 20 lakhs.

Financing Schemes

Page 25

March 2009

<!-- page 29 -->

Kerala State Energy Conservation Fund

Selection of Agencies and Schedule
KSECF shall solicit interest form public agencies for participating in this scheme by
June 2009 and select one or two agencies by July 2009. The audits of the selected
facilities shall be completed by September 2009 and contracts with the selected
ESCOs concluded by February 2010.

Financing Schemes

Page 26

March 2009

<!-- page 30 -->

Kerala State Energy Conservation Fund

SECTION 7
PARTIAL CREDIT GUARANTEE SCHEME

Financing Schemes

Page 27

March 2009

<!-- page 31 -->

Kerala State Energy Conservation Fund

SECTION 7 - PARTIAL CREDIT GUARANTEE SCHEME

INTRODUCTION
The interviews and assessments conducted with project hosts, energy service
providers, equipment suppliers, and financial institutions in Kerala during the design
of the KSECF pointed out that most industrial and commercial facilities in Kerala do
not have adequate capital or are unwilling to invest their own capital for EE projects.
There is no ESCO industry in Kerala, and the fledgling ESCO industry in India is
substantially undercapitalized and not capable of mobilizing sufficient financial
resources to implement many EE projects. At the same time, financial institutions are
reluctant to fund EE projects (or hosts) that they either do not understand or perceive
to be too risky. Discussions with financial institutions also pointed out the following
perceptions:


Many industrial companies in Kerala may be considered to be financially
“stressed”.



ESCO sponsors have limited equity raising and debt abilities and limited
balance sheets.



Because a substantial track record of EE projects has not yet been built up,
project implementation skills of ESCOs and hosts are viewed as potential risks.



Financial transaction costs are relatively high as most projects are small, and
there has not been sufficient activity for streamlined processes to have been
developed.



Energy savings monitoring and verification protocols have to be standardised
and made as objective as possible.



Standardised financing and project agreements need improvement.

The Consultative Meeting with financial institutions ion Kerala held as part of the
design of the KSECF in October 2008 demonstrated the FIs’ view that liquidity is not
an issue in financing EE projects. What is needed is risk sharing to reduce the
perceived risk of the financial institutions. In addition to conventional risk sharing
mechanisms through project contracts, there is a strong need for credit enhancement
to provide comfort to lenders.
PARTIAL CREDIT GUARANTEES
The situation in Kerala with respect to commercial financing of EE projects is
analogous to what has been faced in a number of developing countries. A scheme that
has been successfully utilized to address the financing issue in these situations is the
partial credit guarantee. Under such a scheme, an organization interested in promoting
EE project implementation provides a risk sharing facility through a partial credit (or
risk) guarantee (PCG) to a commercial financial institution (FI) that provides loans to
project proponents. By offering a mechanism to share the risk of loan default, the
PCG scheme reduces the FI’s financing risk. This approach has been very
successfully used by the International Finance Corporation (IFC) in cooperation with
the Global Environment Facility (GEF) to substantially stimulate the market for
commercial financing of EE projects in a number of Eastern and Central European
Financing Schemes

Page 28

March 2009

<!-- page 32 -->

Kerala State Energy Conservation Fund

countries and is currently being implemented in China, Russia and other countries.
The credit guarantee approach has also been applied successfully in a number of other
economic sectors in many countries, particularly for small and medium size
industries. An excellent example in India is the Credit Guarantee Trust Fund for
Micro and Small Enterprises (CGTMSE).
CREDIT GUARANTEE TRUST FUND FOR MICRO AND SMALL
ENTERORISES (CGTMSE)
With a view to resolving the problem of collaterals, and to induce banks to gradually
move away from a completely risk-averse stance towards SSIs, Ministry of Micro,
Small & Medium Enterprises (MSME), Government of India launched Credit
Guarantee Scheme (CGS) so as to strengthen credit delivery system and facilitate
flow of credit to the MSE sector. To operationalize this scheme, the Government of
India and the Small Industries Development Bank of India (SIDBI) set up the Credit
Guarantee Fund Trust for Micro and Small Enterprises (CGTMSE) for ensuring
collateral security free loans to Small Entrepreneurs and SSIs.
The main objective of CGTMSE is that the lender should give importance to project
viability and secure the credit facility purely on the primary security of the assets
financed. The other objective is that the lender availing guarantee facility should
endeavor to give composite credit to the borrowers so that the borrowers obtain both
term loan and working capital facilities from a single agency. The Credit Guarantee
scheme (CGS) seeks to reassure the lender that, in the event of a MSE unit, which
availed collateral free credit facilities, fails to discharge its liabilities to the lender, the
Guarantee Trust would make good the loss incurred by the lender up to 75 / 80/ 85 per
cent of the credit facility.
Any collateral / third party guarantee free credit facility (both fund as well as non
fund based) extended by eligible institutions, to new as well as existing Micro and
Small Enterprise, including Service Enterprises, with a maximum credit cap of Rs.100
lakh (Rupees Hundred lakh only) are eligible to be covered. The guarantee cover
available under the scheme is to the extent of 75% / 80% of the sanctioned amount of
the credit facility, with a maximum guarantee cap of Rs.62.50 lakh / Rs. 65 lakh. The
extent of guarantee cover is 85% for micro enterprises for credit up to Rs.5 lakh.
The extent of guarantee cover is 80%(i) Micro and Small Enterprises operated and/or
owned by women; and (ii) all credits/loans in the North East Region (NER). In case of
default, Trust settles the claim up to 75% (or 80%) of the amount in default of the
credit facility extended by the lending institution.
KSECF CREDIT GUARANTEE SCHEME
The KSECF Credit Guarantee Scheme for Energy Efficiency Projects will provide
guarantee cover on loans made by participating financial institutions for EE projects
without collateral/third party guarantees in a manner similar to that provided under the
Credit Guarantee Fund for Micro and Small Enterprises (CGTMSE). The KSECF
Credit Guarantee Scheme for Energy Efficiency Projects (CGS) will be patterned
along the same lines but with some modifications. A higher level of guarantee cover
will be provided to give greater comfort to lending institutions. The guarantee cover
provided by the Fund will be separate and in addition to that available to small
industries under CGTMSE so that the benefit of availing CGTMSE for their normal
Financing Schemes

Page 29

March 2009

<!-- page 33 -->

Kerala State Energy Conservation Fund

business needs is not affected. The guarantee cover will also be made available to
medium and smaller large enterprises that are not covered under CGTMSE.
KSECF will work closely with CGTMSE, and would request the CGTMSE to
administer the scheme for which KSECF would pay a processing fee for all
transactions (for providing guarantee cover and making guarantee payments, if
necessary).
Under this scheme, assistance will be available to SME units and smaller large units
in the industrial sector, and owners of commercial buildings. It will also be available
to ESCOs for EE projects in SME units and smaller large industrial units, EE projects
in privately or government owned buildings, and street-lighting and water pumping
EE projects in Urban Local Bodies.
DESCRIPTION OF THE PARTIAL CREDIT GUARANTEE SCHEME

Facility Eligibility
The following types of facilities are eligible to apply for funds under the EAS scheme







Smaller Industrial plants
Commercial buildings
Hospitals and health care facilities
Universities and colleges
Schools
Multifamily buildings

The facility needs to meet the criteria for borrowers established by the financial
institutions participating in the PCG scheme.

Eligibility of Project
Any EE project that provides energy and cost savings in an eligible facility is eligible
for the PCG scheme, provided that:




It is supported by an energy audit conducted by an accredited energy
auditor.
The DPR is submitted with the application to the FI.
The simple payback for the project (capital costs divided by average
annual cost savings) is not less than two years and not more than seven
years.

Participating Financial Institutions
KSECF shall work with a number of participating financial institutions, who will sign
a Risk Sharing Facility Agreement (RSFA) with KSECF. A list of participating FIs
will be published by KSECF.

Project Size
The minimum project size shall be established by the participating FIs. The maximum
project size may also be established by the FI, but KSECF will provide a guarantee of
no more than Rs. 10 lakhs per project in the first year of the scheme.
Financing Schemes

Page 30

March 2009

<!-- page 34 -->

Kerala State Energy Conservation Fund

Total Budget
The total budget for this scheme during the fiscal year 2009-2010 is Rs. 30 lakhs.
.

Financing Schemes

Page 31

March 2009
