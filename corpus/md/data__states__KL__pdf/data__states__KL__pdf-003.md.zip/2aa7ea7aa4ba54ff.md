---
doc_id: "2aa7ea7aa4ba54ff"
source_url: "https://www.keralaprisons.gov.in/userfiles/act-and-rules/kerala_prisons-rules_1958.pdf"
ministry: "Kerala Prisons & Correctional Services, Kerala"
title: "കേരള പ്രിസണ്‍ റൂള്‍സ് 1958"
date: ""
pages: 284
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "628be8e0f05e1fa0"
---

<!-- page 1 -->

H

H
F.-

H

THE KERALA PRISONIRULES
J958/

7

(AMENDMENT (RULES)U."

(As on 204-1997)4.

/

1

16/3274/95/Mc

-

<!-- page 2 -->

•

THE KERALA PRISONS RULES, 1958
CONTENTS
Chapter I

F.

1.
2.
3.

4

4.
5.
6.
7.
8.

•

THE CENTRAL PRISONS

Page
1

Title and extent of applicability
The Central Prisons
Classes of prisonsers confined in the Central Prisons

'I
1

.

Chapter U
INSPECTOR-GENERAL OF PRISONS
Control of expenditure
Power to sanction expenditure
Power to sanction contracts.
Power to sanction institution of civil suits
inspection ofJails
Specialrepertincertaincases
Transfer of Prisoners.
Powers of appointment

4
5
5
5
7

.
.

7

.
-

.

-

Chapter III
VISITORS
.

Ex-officio visitors
Appointment of non.ofiicial vistors

-

IS.
16.
17.
18.
19.
20.
21.
22.
.23.

.

.

Visits by vistors
Powers and duties of visitors
Record to be made of inspection
Disposal of complaints to vistor by prisoners
Disposal of record made by visitor.
Admission to Jail of others than the officers specified
Admission of Pnlice Officers to the Jail
Grant of pass to the Police to visit the Jail
Interrogation of prisoners by the Police
.

'

.

-

.

•

Escort to accompany visitors.

11
11
12
12
12
12
12

-

-

•
.

.

•

..

9
9
10
10
10

Chapter IV
THE SUPERINTENDENT
24.

•

25.

Appointment ofJail Superintendent
Executive Management of Jail by the Superintendent
.

General Duties, of Superintendent.
Daily visit of Jail
•

23.

Maintenance of Journal.

-

-

•

•
•
.

-

•

•

.

•

IS
13
13
13
13

<!-- page 3 -->

S
11

29.
30.
31.
32.
33.
34.
35.
36.
37.
38.
39.
40.

Jail business to be transacted on Jail prerhises.
Weekly inspection of Prisoners.
Control over receipts and expenditure
Procedure regarding Civil Suits.
Maintenance of records

-

Submission of reports and return,.
Control of Ocpenditure
Report of Important occurrences.
Intimntiouofserio
illness or death of a priosner.
Superintendent to furnish copy to Inspector-Geneni of Communications
sent to be rceeived from Government.
Presencccflnspectiom
Superintendents powers of appointment, suspaniion and punishment.

Page
14
14
14
15
15
15
16
16
16
16
17
17

a

Chapter V
THE MEDICAL OFFICER
41.
42.
43.
44.
45.
46.
47.
48.
49.
50.
51.
52.
53.
54.
55;
56
57.

Appointment of Medical Officers
Coqtrolof Medical Officer
Channelof Communication
Daily visit to Jail.
Duties generally stated.

.

Attendance of weekly inspection.
Attendance orijail Officers.

-

-

.

Maintenace ofjournaj.
Submjssionofretui-ns
Maintenance of registers.
Local and Nonpracticc allowance to Medical Officer.
Residential quarters of the Medical Officer.
Terms of appointment.
Duties further defined.
Local allowance to the Compounder.
Residential quarters of the Compounder.
Terms of krvice of the Compounder.
Duties of the Compounder.
The District Medical Officer to visit theJail.
Conveyance allowance to the District Medical Officer
PsychiatricServices
Visitof Psychiatrist.

•

Who is the Psychiatrist for each Jail.
Allowance to the Psychiatrist

.
-

18
IS.
18
18
18
18
19
19
19
19
20
20
20
20
21
21
21
21
21
21
21
22
22
22

4

<!-- page 4 -->

111

-

Chapter VI
SUBORDINATE OFFICERS GENERALLY

Page

p

V

•
•

65.
66.
67.
68.
69.
70.
71.
72.
73.
74.
75.
76.
77.
78.
79.
80.
81.
82
83.
84.
85.
86.
87.
88.
89.
90.
SI.
92.
93.
94.
95.
96.
97.
98.
99.
100.
101.
102.

103 •

Divsion of staff into two parts

22

Constitution of the upper subordinate establishment
Qualification for appointment to upper subordinate establishment.
Liability to serve in any Jail.
Training in drill and musketry.
Confidential Personal sheet
Supply of vegetables from the Jai] garden to subordinate establishment.
Knowledge of rules.
Th ties towards superior officers
Not to be absent without permission.
Dress and personal appearance
No Officer to smoke or drink in the Jail.
Officer to rcceive visitors.
Conditions as to residence.
:Prohibition against quarrelling.

j.

Officers to pievent escape and intriatiGn/f prohibited articles.
Prohibition against visiting priso
Responsibility of warder for cia
'of Aug.
.
Duties of Officer in charge of ga
V
Careofkeys.

-

Care of Government property.
'Officon to instruct their successors.
Prisoners to be treated with gond temper.
Prohibition against punishihg or abusing prisonth. Prisoner not to be struck.

-.

.

Immediate report of misconsuct to be made.
Familiarity with prisoners forbidden.
Officers not to have dealing with prisoners or their friends.
Officer to receive prisoners property.
intercourse with discharged prisoners forbidden.
Officers not to be interested in Jail contract.
Officers not to engage in trade.
Keeping of farm stock, or cattle.
Superintendent to decide when prosecution should be instituted.
Offences to be dealt with judicially.
.
Acquitted officers to be reinstated.
Offences ordinarily punishable by dismissal.
Procedure prior to inflicting punishment
Record of punishments inflicted,

22
22
22
22
23
23
23
23
23
23
23
24
24
24
24
24
24
25
25
25
25
25
25
26
26
26
26
26
26
26
27
27
27
27
27
27
28

<!-- page 5 -->

iv

104.
105.
106.
107.

Page
23
29
29
29

Officer to quit the jail on termination of appointment
Caution to Officers under suspension.
Re-employment of dismissed Officers
Prohibition against employment of convicted person.
Chapter WU
UNIFORM OFJAIL OFFICERS

108.
109.
110.
ill.
112.

115..
116.
117.
118.
119.
120.
121.
122.
123.
124.
125

29
30
31
SI
32
32
32
32
32

Uniform of Inspector.General and Superintendcnt.
Uniforn& to be worn on duty.
Uniform of.Jailor.
Uniform of Deputyjailers and Assistant Jailers.
UniforthofChiefWarder.
Uniform of Head Warders
Uniformof WaIders.
Warders to carry whistle
Uniform of female warders.
Chief and head warder to be provided with cane, and warders with
batons or lathies.
Supply of extra suits.
Responsibility for Unifi,rm supplied by Government.
Arms to be carried on duty.

32
33
33
33
33
36
36
36
37

Articles of Uniform.
Surrender of Uniform.
Surrender of Uniform ofJail Officer quiting station on leave.
Jail Officers to be smartly dressed.
Uniform to be looked upon as badge of service.

'C

Chapter VIII
SECURITY DEPOSITS
126.
127.
128.
129.
130.
131.
132.
133.
134.
135.
136.
137.

-

Securit, of Executive officers and clerks.
Scurity of Technical Officers
Superintendents responsibility in other cases
Method of depositing security.
Record of deductions from salary.
Investments of deposits.
Post Office fivc year cash certificates.
Deposit receipts of Banks
Custody of promissory notcs.
Annual count and check of securities by Superintendent.

-

-

Execution of security bond.
Submission of statement regarding security.

-

J

37
37
37
38
38
38
38
39
39
39
39
39

<!-- page 6 -->

V
Chapter IX
THE JAILER
General duties of Jailer.
Maintenance of discipline
Jailor to be present in absence of Deputy Jailer.
Daily Inspection.
Attentiónofpersonofprisoners.
Search of prisoners
Labour of prisoners
141.
145.' Supply of food
146. Supervision of guard.
147. Enforcement of terms cf warrant.
148. Check of warrants and property.
149. Supervision of jail Office.
150. Maintenance of report book.
151. Superintetident to peruse report book.
152. Execution of Medical Officers orders.
153. Holiday to the Jailer.
138.
139.
140.

'

-

-

--

-

•

.

-

Paga
39
40
40
40
40
40
40
40
40
40
40
41
41
41
42
42

Chapter N
THE DEPUTY JAILER

•
•

•

154. General duties of Deputy Jailer.
155. Deputy Jailer. to officiate for Jailer.
156. Inspectionof Guard.
157. Duties in detail.
158. Delegation to Deputy jailer of Jailcr's duties.
Joint responsibility with jailer.
Deputy Jailer to check valuable property in his pussQssion once a year.

-

42
42
42
42
43
43
43

Chapter XI
ASSISTANT JAILERS

Appointment of Assistant Jailer.
Duties ot Assistant jailers.
Relation of Assistant jailers to jailer.
Executive work and drill.
• Seniormost Asistant jailer when to function as Deputy Jailer.

43
43
43
44
44

<!-- page 7 -->

vi
Chapter Xli
THE WARDER ESTABLiSHMENT
166.
167.
168.
169.
170.
171.
172.
173.
174.
175.
176.
177.
178.
179.
180.

Page

Classification of Warders.
Government to fi, permanent strength.
Power to sanction temporary addition.
When Inspector-General may sanction temporary establishment.
When Superintendent may sanction temporary establishment.
Division of Warder establishment.
Physical qualification of Warden.
Duties of the Chief Warder.
His responsibilities to the charge of arms etc.
Assignment of duty to Warden.
Summary of duties of W3rder.
Dhty of Warders on relief.
Duty of Warden in charge of work shed.
Duty to dsiclose relations with prisoners.
Award of good conduct stripes and rewards.

44
44
44
44
45

-

Chapter

45
45
45
45
45
46

.

-

47
47
47
47

xm

THE GATE-KEEPER
181. A gate-keeper to be on duty.
182. Persons allowed to enter and leave the Jail.
183. Power to search such persons.
184. General duties of gate-keeper.
185. Record of persons and things entering and leaving Jail.
186. Particulars of record.
187. Conict officer to assist grate-keeper.
188. Gate-keeper responsible for condition of main gate.
189. Working of double gate system.
190. Method of passing prisoners into or out of Jail.
191. Gate register to be submitted tothe Jailer.
192. Powers to detain persons committing offence.
193. Delivery of Keys at lock up.
194. Keys to be kept in bunch.
195. Bright light at night.
196. Articles to be kept between gates.

-

.

-

.

.

-

49
49
49
50
51
51
51
51
51
52
52
52
52
52
52

Chapter XIV

-

CLASSIFICATION AND SEPARATION QF PRISONERS
197.
198.
199.

Convicts to be separated.
Occupation of vacant cells.
Procedure when separation by day is not feasible..
I

53
53
53

ci
7'

<!-- page 8 -->

I

vi'
-

Division of convicts into habitua.ls and others.
Definition of habitual criminals.
Classification of convicts as habitual criminals.
Duty of Superintndent in regard to classification.

200.
201.
202.
203.
204

-

.

Separation of habituals.
205. Employment of habitual convicts.
206.Transfer of prisoners.
207. Distinction between a habitual and recoavicted convict.
Superintendent to discover and report previous convictions of undertrials.

.

.

.

-

Classification of casual offetiders.
-

-

.

Page
54
54
54
55
56
56
56
56
56
57

ChapterX%

ADMISSION OF PRISONERS
Proper warrant to accompany prisonei
Procedure if warrant is irregular.
Warrant to contain particulars of fine.
Method of calculating sentence.
Commencement of and breaks in imprisonment how reckoned.
Imprisonment in default of giving security plus a substantive sentence.
Date of release when two or more sentences run consecutively.

210.
211.
212.
213.
214.
215.

...i

•

234.
235.
236.
237.
238.

.

.

216.
217.
218.
219.
220.
221.
222.
223.
224.
225.
226.
227.
228.
229.
230.
231.
232.
233.

.

Effect of annulling the first of two sentences.
Calculation of date of release in certain cases.
Counting of time spent in another State for trial etc.
Date of release of prisoner sentenced for escape.
Date of release from imprisonment in default of payment of fine.
Date of itlease when fine is partially paid.
Calculation of sentence awarded to prisoner undergoing imprisonment
in default.
Calculating sentence modified on appeal.
Procedure when sentence is suspended.
-.
Time for admitting prisoners.

,

Check of prisoners propert'.
Prisoriers to wash themselves and their clothing.
Search of prisoners on admission.
Removal of articles from prisoners.
I
Quarantine on admission.
Medical examination of prisoners from sub jails etc., before admiMioa
Medical examination before prisoners are transferntd.
Transfer of prisoners during epidemics.
Provisions and contents of History Tickets.
Custody of History Tickets and weighment char'
Registering and serial number of Prisoners.
the of Register Number.

16/3274/95/MC.

.

.

-

.

59
60
60
61
61
62
62
62
62
62
63
63
63
63
64
64
64
64
64
65
65

.

'.

57
59
59

•

65
65
67
67
67

<!-- page 9 -->

viii

239.
240.
241.
242.
243.
244.
245.
24.

Page
67
68
68
68
68
69
69
70

Record of date of release etc.
Superintendent to check entries.
Arrangement and custody of warrants.
Medical Officer to examine and weigh prisoners on admission.
And to certify appropriate class of labour.
-

Tickets to be worn by convicts.
Rules regarding the cutting of hair-exceptions.
Prisoners to be instructed in Jail Ruje,.
Chapter XVI
• GENERAL DISCIPLINE AND DAILY ROUTINE

247.
248.
249.
250.
251.
252.
253.
254.
255.
256.
257..
258,
259.
260.
261.
262.
263.
264.
265.
266.
267.
268.
269.
270:
271.
272:
273.

Unlocking wards at day-break.
Jailer to be present.
Treatment of bedding.
Cleansing of wards and cells.
Wards and cells to be ventilated and locked.
.

Counting of prisoners.
Latrine and bathing parade.
Early meal and formation of gangs.
March, to work, Jailer to distribute tasks.

j
70
70
70
70
70

-

'
-

70

.

-

Procedure in cases of illness.
Mid-day meal.
Resumption of work in afternoon.
Procedure on cessation of work.
Evening meal and lock-up. 1
Men to work together, to sleep together.
Searching of prison&s when leaving or entering the jail.
.

.

.

Strict discipline to be enforced.
Conduct of gangs.
Search before lock.up.
Disposal of keys.
Custody of the keys at night.
Wards to be opened during night only in the presence of an Officer.
.

.

.

.

.

.

.

Lctting out cooks to prepare early meals.
Lighting of wards and cells at night.
Latrine accommodation in wards and cells.
Use of night latrine to be discouraged.
Visits to latrine out of hours.
Matters affecting caste or religion.

,

.

.

-

Use of books by prisoners.
Lights for reading.
Recreation rooms.

.

- -

-

.

. -

.

71
71
71
72
72
72
72
72
72
72
73
73
73
73
.73
73
73
74
74
74
74
74
.75
75
76

C

S

<!-- page 10 -->

ix
Page

a

Religious instructions and moral lectures.

76

Change of religion in prison.

76

Education.

76

•

281.

Washing of dloths.

282.

Fortnightly weighment.

78
78

.

$ 283. Record of wèighments.
284.

4

-

Treatment of prisoners losing weight.

78
78

285.

Check by Medical Officer.

79

286.

Hunger-strikes.

79
Chapter

XVII

OFFENCES AND PUNISHMENT
287.

Acts declared to be prison offence under section 46 of the T.C. Prisons
Act XVIII of 1950 and 45 of the Central Act IX of 1894.

79

288.

What are prohibited articles.

82

289.

Reference to Magistrates in certain cases.

82

290.

Power of Superintendent in other cases.

82

291.

Loss of privileges under remission system.

83

292.

Description of handcufl.

83

293.

Handcuffs may be imposed.

83

294.

Scale of Penal Diet.

83

- 295.
•

Imposition of Penal Diet.

84

296.

Imposition of Solitary or Separate Confinement.

84

297.

Classification of Punishment—Minor.

298.

Major.

-

84

-

85

Chapter X'VW

•

THE RZMISSION.SYSTEM
299.

Definition in these rules

86

300.

Exclusion of certain sentences.

86

301.

Forfeiture of remission.

86

302.

Re.admission of excluded prsioner.

87

303.

Scale ofordinary remission.

87

304.

Scale applicable to convict officers.

305.

Date from which remissioncalculated.

-

88
83

<!-- page 11 -->

x
Page

-

Additional remission to prison servants.

88

Award of remission for good conduct.

88

08.

Who may award ordinary remission.

88

309.

Proceduredaaward.

88

310.

Record of award.

89

311.

Exclusion of last calendar month.

89

312.

Qualification for special remission.

89

313.

Who may award special rem ission.

90

314.

Record of special remission.

90

SI 5.

Maximum remission awardable.

90

Method of calculating date of release.

9.0

Releaseofprisoner.

91

318.

Endorsement of remission on warrant.

91

319.

Procedure. on Transfer.

91

320.

Preservation of Remission sheets or Cards.

91

m

1

c
I
14

Chapter CIX
GRADING OF CONVICTS AND CONVICT OFFICERS
321.

General discipline.

91
N

322.

Employment of convict officers.

323.

Threeclassesofeonvicts.

324.

Gratuity to ordinary convicts.

93

325.

Remissioh in lieu of gratuity when sentenced for two years and less.

93

326.

Remission in lku ofgratutity when sentenced for periods abovetwo years.

93

327.

Lapse of gratuity.

94

328.

Three gradesofconvictofficers.

94

329.

Appointment, privileges and dutiesof ConvictNight Watchmen.

94

330.

Appointment and privileges of Convict Overseen.

94

331.

Duties of convict overseers.

94

332.

AppointmentofConvictWarders.

95

92

-

-

-

92

44

<!-- page 12 -->

xi
Page

•

338,

Inspector General to fix No. of Convict Warden in each Jail.

95

Qrant of wages and gratuity to convict warden.

95

Half the money earnings may be spent on catables.

95

Privileges ofoonvictW3thers.

96

Duties of Convict Warden.

96

Equipmentofconvictwarderl.

96

Appointment of unqualified convicts as Warder,.

96

Chapter XX
DIETAItY

•

.351.

Ordinarydietscalet.

96

Food to be cooked at main kitchen.

109

AppoIntment ofcoolcs.

109

Duties of cooks.

110

Cooking vçsseLs, etc.

110

Protection offood from flies.

110

Allqwances of fuel.

110

Eatthg and drinking vessels.

110

Daily inspection of food supplies.

110

Inspection of cooked food.

111

Weighment of articles offood.

111

Disposal ofconiplaihtbyprisoner.

111

Power to sanction change in dietary.

111

Controlof hospital diet.

Ill

Hospitaldiets.
3.55.

112

Diet scale for State prisoners.
Chapter XXI
CLOTHING AND BEDDING
Convicts tawearJail clothing.
Material of PrSscn's clothing.
Clothing of Indian 'C"class male convicts.
Period of clothing should last.

115
125
115
116
•1

is.-,

<!-- page 13 -->

xli
Page
Clothing to be marked on issue.

116

Clothing of convict Warden.

116.

Clothing and bedding of A and B class male convicts.

117

ClothingofA and B Class Female Convicts.

119

Clothing of convicts attendingCourt.

119

.365. Clothing of convicts when under trial.

119

Grant of remission for economy in wearing ofclothing.

119

Supply of extra clothing for work.

120

Instruction regarding the wearing of clothing.

120

Issue of water-proof hoods.

120

Issue of extra clothing to invalids.

120

Supply of bedding to Indian prisoners.

120

Charge of clothing store.

120

Repair and inspection of clothing and bedding.

120

Disposal of unserviceable clothing.

120

Disposal of clothing of.discharged prisoner..

121

Submission of clothing indents.

12!
Chapter XXII

CONVICT LASOUR AND JAIL INDUSTRIES
-

Classes of labour and scale of tasks.

121

. Amountbf wages for tasked labour.

121

Amount of wages for untasked labour.

124

Wages for work on Sundays.

135

Wages for convict Warders.

135

Hours of work.

135

Howtofixthctask.

135

How to utilisc the wages earned.

136

384A. Rethission in lieu of wages.
Acknowledgments to be obtained.

t

4.

a

136
186

<!-- page 14 -->

-

*

xlii
Page

386.

Gratuity for prisoners unable to work.

136

387.

Disposal of special variety article manufactured.

136

388.

Providing of labour.

389.

WhomaygranttheWges.

390.

Not to be employed on prison services.

391.

Whomatcheckthetask.

392.

Extra work, restrictions.

393.

Debit of expenditure.

394.

Superintendent to determine the employment.

395.

Allowance for social status.

396.

Avoiding frequent change of work.

138

397.

Labour not to be exacted on certain days.

138

398.

Restriction on employment on public works.

399.

Employment of convicts with free labourers.

138

400.

Employment ofconvictson dangerous works.

138

401.

Restriction on extramural cmployment of prisoners.

139

402.

Female convicts not to workoutside female enclosure.

139

403.

Tat for femalesjuveniles and convicts attending school.

139

136

.

136
'.

137
137
137

-

137

-

IS?
138

138

.

139

404,

Allotment of labour in cases not tirovided for.

405.

Time to be given to acquire skill.

406.

New industry to receive Inspector General's sanction.

407.

Disposalof manufacturers.

140

408.

Advice on technical matters.

140

409.

Purchase fromjail obligatory on consuming departments.

410

Specifications of articles to be standardised.

141

411.

Committee to decide difference of opinion as to s&ndard..

141

412.

Uniform of Government Deparunent Officers.

141

If uniform of Govermnent departments undertaken byjailall works to be done:

141

Penalty clause in the event offailure to complete supplies within stipulated time.

141

Standing price lists to becompiled.

141

140

-

140

-

141

<!-- page 15 -->

xiv

Intimation ofrequirements by consuming departments.

Page
141

Reports of heads of departments as to the characterof supply.

242

Selection of industries.

142

Jail labour tosupplyjail needs.

142

Performance of menial offices.

142

Sweepers and water carriers for official quarters.

142

Employment of prisoners as clerks, typists, etc.

143

Chapter XXW

S

4

1

PRISONERS PROPERTY
Disposal of property and money.

143

Disposal of money.

44

Record otprioners' property.

144

List of pr9perty to be read over to prisoner.

245

Disposal or transfer on release ofprisoner.

145

Property may be made over to friend of prisoner.

145

Use of private cash.

145

Provision of clothing on release.

145

Disposal of property of deeeasd prisoner.

146

Disposal olproperty found afteroriginal searcl.

146

Chapter XXIV
RELIGIOUS MINISTERS
146

Condition of admission of religious ministers.
-

Refusalof admission to religious ministers.

146
S

Chapter XXV
INTERVIEWS AND COMMUNICATIONS WITH PRISONERS
146

Reasonable facilities to be allowed for interviews and letters.
436; Subsequent interviews and letters.

147

.

Superintendent's discretion to grant privileges at shorter intervals.

147

--

447

Superintendent's permission for interviews requirod.

<!-- page 16 -->

xvii

(]hapter XXX
TRANSFERS
Page
496.
497

4

Powers of Inspector-General.
Transfer of sick prisoners.
Transfçr pending appeal.
Prisoners convicted in the same case.
500, Transfer of habitual prisoners.
501.. Raciprocál arrangement of transfer.
502. Transfer during epidemics.
503. Grounds of retransfer to be stated.
504. Escort of prisoners.
Application for escort.
Provision of female warden.

164
165
165
165
165
165
166
166
166

.

.

.

-

41

166

.

.

Intimation of prisoners transferred to be given.
Procedure prior to transfer.
Disposal of prisoners property.
Doâuments to accompany prisoners.
Supply of food and clothing on journey.
Custody of females and juveniles.
Search during transfer.
Transferbyrailorsteamer.
Transfer by road.
Procedure if prisoner falls sicks.
Proceduse if a prisoner escapes.
Admission of trans erred prisoners.
Verification of accompanying prisoners.Return"of clothing etc.

.

,

.

510.
511.
512.

.

'

,

.

.

515.

518.
519.

I

.
.

.

-.

Chapte

-

,

'

166
166
167
167
167
168
168.
168
168
169
169
169
169
169

XXXI

RELEASES
Names of convicts due for release be read out at parade.
When date of release falls on a holiday.
Procedure prior to releasing convict.
Time and method of release.
Compliance with orders received late or on a holiday.
Relea,c of prisoners in Superintendent's absence.
Grantoftravellingdxpenses.
After-care Association.
Return of warrant to Court.
When prisoner is undergoing more than one sentence.
Whenprisonerdies.
.

523.

.

528.,
529.
530.
531.

-

.

,

.
.

-

.

.-

.

-

169
170
170
170
171
171
171
172
172
173
173

<!-- page 17 -->

xviii

552.
533.
534.
535.
536.
537.
538.
539.
540.
541.
542.

Return of warrant of commitment for trial.
Treatment of telegraphic orders of release.
Treatment of order of High Court.
Intimation to Police of impending releases.
Report to Police of Convict's death.
Release of blind or decrepit prisoners.
Release of sick prisoners.
Release of prisoners in dangers of death.
Release of prisoners convicted under security proceedings in danger of death.
Conditions of release on grounds of health:
Conditional release for treatment outside hospital.

-

Page
174
174
174
174
175
175
175
176
176
177
177

S

4
0

Chsptci XXXII
ADVISORY BOARD
178

543.

AdvisoryBoard.

544.

Constitution of the Board.

545.

Functions of the Board.

179

546.

Records and information to be made available to the Board.

180

547.

Release on probation.

181

548.

Discharge.

183

'.

-

178

Cbapter X)DCW
GUARDING
549. Armed Reserve Guardt
'
550. Posting of sentries by night.
551. Duties of sentry.
552. Relief and supervision of sentries.
553. Night watch by convict officers.
554. Salutes.
555. Duties of Warder Guard.
556. Classes of Warder Guards, day duties.
557. Combination of night duty with day duty.
558. Duties assigned not to be frequently changed.
559. Custodyofarms.
560. Custody of articles facilitating escape.
'
561. Use of weapons against prisbners.
562. Arms and ammunition Warder Escorts.

:
•
.

-

183
183
184
184
184
185
185
185
185
186
186186
186
186

4.

<!-- page 18 -->

xix
Chapter XXXZ%
CONFINEMENT IN IRONS FOR SECURITY

•

%
4

563.
564.
565.
566,
567.
568.
569.
570.
571.

Page
187

Inwosition of fetters when permissible.
Record of imposition of fetters.
Imposition of fetters on transfer.
Imposition of handcufl.
Prisoners exempted absolutely.
Prisoners ordinarily exempted.
Removal of fetters.
Supply of leather or Cloth Gatters when fetters are used.
Examination ofetters.

187
187
187
188
188
188
188
188

Chapter XXXV
ESCAPES-

.
.
572. - Alarm to be given of escape.
573. Procedure thereupon.
.
574. Duty of Jailer.
575. Duty of Superintendent.
576. Report to Inspector General of Prisons.
577. Publication of escape.
578. Power of Superintendent to sanction rewards with previous sanction
of the Inspector General of Prisons.
579. Rewards to private persons etc., to a limit of its, 200.
50. /-Reward of prisoners preventing an escape.
581? Punishment of conduct facilitating an escape.
582. Procedure on recapture.
583. Recaptured prisoner to wear'wrist ring.
4 584. Procedure regarding disposal of warrant of escaped prisoners.

188
189
189
189
189
189
189
190
I 91)
190
190
191
191

Chapter XXXVI
OUT-BREAKS
685. Alarm to be sounded on .otrt'break.
586. Procedure when alarm is sounded.
587. Drty of convicts on hearing alarm.
588. Method of quelling disturbances.
589. Defence of main gate.
590, Disturbance, within wards.
591. Treatment of extramural gangs.
592. Alarm Parade.

-

191
191
191
192
192
192
192
192

<!-- page 19 -->

xx
Chapter XXX%U
ACCIDENTS AI'U) flTICIDES
593,
594.
595.
596.
597.
598.
599.

Page
193
193
193
194
194
194
194

Procedure when unnatural death occurs.
Intimation to inuiring Magistrates and Police Officers.
Report by Superintendent.
Custody of articles facilitating suicie.
Custody of poisons.
Precaution against drowning.
The prevention of fires.

Chapter XXX'vW

4

MEDICAL ADMINISTRATION AND HOSPITAL MANAGEMENT
600.
601.
602.
603.
604.
605.
606.
607.
600.
609.
610.
611,
612.
613.
614.
615.
616.
617.

Examination of prisoners doniplaining of illness.
Medical treament of sick prisoners.
Detentionof*prisonerforobservation.
MedicalOfficertosupervisetreatnlentofoutpatients.
Medical Officer to treat sick in Hospital.

'

.
Hisdaily visit.
Record of sick in Hospital.
Maintenance of case book.
Control of hospital diets.
Medical Officer may direct prisoficr to be forcibly fed during hunger strike.
Indent for Hospital diets.
PreparatiOn of Hospital diets.
Precautions regarding milk.
Supply of hospital clothing and bedding:
Indent for clothing and &dding.

-

Reference Library.
Indent for other articls.
Local purchase of medicines.
618.' Appointment of attendants, selection and training of nursing orderlies.
619, Appointment of Hospital menials.
620. Bed head ticket.
.
621. Bathing foul labour of patients.
622: Segregationof infectious cases.
623. Disinfection of ward.
624. Hospital to be elran.
625. rrocedm'e on death of a prisoner.
Treatment
of
malingerers.
626.
627. Treatment of prisoner discharged from hospital.
.
628. Composition of invalid gang.
629.
630.

Treatment df invalid gang.
Special dieting of prisoners not in Hospital.

'

194
195
195
195
196
196
196
196
196
196
197
197
197
197
197
198
198
198
198
198
198
198
199
199
199
199
199
199
199
200
200

1
4

<!-- page 20 -->

xxi

631.
632.
633.
a

1~

.1!
E l,

Vaccination of prisonets on admission.
Vaccination register.
Precautions against outbrcal<.
Provision of camping ground for each jail.
Selection of camping shed.
Camping ground to be ready.
Removal to segregation sheds..
Treatment of prisoners after contact with infection.
Disposal of Jail officers clothing if infected.
Treatment of infected barrack.
Accommodation of patients.
Boiling of water.
Observation of healthy prisoners.
'Scrupulous care of latrines.
Treatment of segregation hospital.
Disposal of dejecta.
Attention to person of prisoners.

634.
635.
636.
637.
638.
639.
640.
641.
642.
643.
644.
645.
646.
647.
648.
649.
650.
651.
652.
653.
654.
655.
656.
657.
658.
659.
660.
661.

Treatment of clothing and bedding.
Disposal of infected corpse.
Report of first occurrence.
When disease shouldbe deemed epidemic.
Prompt removal to camp uecessary.
Use of tents.

Page
200
200
200
201
201
201

/

201
201..
201
202
202
202
202
202
202
202
202
'203
203
203
203
203
203
204
204
204
204
204
204
204

H

/

Sleeping arrangements in camp.
Precautions against lire.
Hospitals in camp.
Conservancy in camp.

-

Transfer of camp to another site.
Entry of Camp Prohibited.
Rules generally applicable to epidemics.
Daily return during epidemic.

204

Chapter XXXIX

662.
663.
664.
665.
666.
667.
668.
669.
670.
671.

I. SANITATION
Capacity of ward to be inseribed near door.
Minimum allowance of superficial and cubic area in wards.
Minimumdimensionsofaeell.
Accomrnodationin hospital.
'

.

Responsibility for preventing over-crowding.
Measures to relieve over-crowding.
Location of prisoners in sheds or tents.
Ventilation of wards.
Walls tobe colour washed or white washed.
Namesofblockstobeshown.

-

:

.

204
205
205
205
..205
205
205
205
206
206

<!-- page 21 -->

xxii
II. CONSERVANCY
Page
206
206
206
206
206
206
207
207
207
207
208
208

-

672. Responsibility of all officers.
673. Jail area to be kept clean.
674. Prohibition of cesspools and drains.
675. Precautions against Malaria.
676. Medical Officer to approve drainage.
677. Injurious conditions in neighbourhood.
678. Construction and use of latrines.
679. Cleaning oflatrines.
680. Sanitation in wards and cells.
601. Disposal of-night soil and urine.
682. Disposal of urinein garden.
683. Precautions against polluting water supply.
-

-,

-

A1

III. WATER SUPPLY
684.
685.
686.
687.
688.
689.
690.
691.
692.
693.

.

Selection of sources of water supply.
Wellstobeprotected.
Wells to be periodically cleaned.
Depth of water to be tested.
Filteration of water.
Boiling of water.
Distribution ofwater.
Supply of water to prisoners.
Analysis of water.
Disinfection of wells.

.

-

208
208
208
208
208
208
208
209
209
209

IV. BURIAL OF THE DEAl)
694.
695.
696.

Particulars of next of kin of prisoners.
Disposal of corps.
Burial ground.

.

.

209
209
210

.

a

Chapter XL
JAIL GARDENS AND FARM
697.
698.
699.
700.
701.
702.
703.

Garden to supply vegetables.
Cultivationofgarden.
Chargeofgardcfl.
Water supplyto garden.
Utilization of ajail LandS.
Dairy.
Debit of Expenditure.

-

210
210
210
211
211
211
211

<!-- page 22 -->

ill
Chapter XLI

WnBOD OF PROCURTNG RATIOS

704,

"

Rationrequired forjail to be raised on jail ground.

Page
211

705,

Method of procuring ration from outside.

211

706.

Notice inviting tenders for dietary articles.

212

707.

Recommendation of tenders.

708.

Acceptance of tenders and execution of agreement therefor.

,

212

709. Procedure on contractor's default.
'4* 710.
Resale of contract on his responsibility.

212

.

212
212

Chapter flU
CIVIL PRISONERS

-/

•

.

212
212

711.
712.

ApplicationofRu1aforcivilprisoners.
Ctothingtobeclean.

713.

Scaleofelotbing supplied byjail.

714.

Disposal ofclothing supplied by decree-holder.

213

7151

Bathing of civil prisoners.

213

-

.

212

716,

Restrictions on supply offood from outside.

213

717.

Supplyoffood onmcdicalground

213

718.

Supplyof food byjail.

719.

Donation to civil nrisoner.

720.

Use of Books by Civil Prisoners.

214

721.

Release on grounds of illness.

214

722,

Detention dependent on payment of subsistence allowance and cost of return
journey home.

214

723.

Release of civil prisoners transferred from which jail to be effected.

215

724.

Scales of subsistence allowance.

.

213

.

725.

Payment of first instalment. -

726.

Subsequent payment.

727.

Latest date for payment.

213

215

.
.

215
215

.

. -

728.

Release ofjudgmertt debtor.

729.

Disposal of subsistence allowance.

,

,

.

215
216

.

.

216

730

Release on non-payment of allowance.

216

731.

Disposal of money on debtor's release.

216

732.

Duty of escorting Civil Debtors.

216

16/3274/95/Me,

.••-

1..

-

-,

<!-- page 23 -->

xxiv
Chapter XLW
UNDERTRIAL PRISONERS
Page
Treatment of approvers.

217

Classifications.

217

rrovidrngof Labour.

217

Ap1icaiionofotherRules.

217

Convict Officers not to guard undertrialprisoners.

218

.738. Hair cutting

218

Use of books

218

Other privileges.

219

General discipline

219

Classification and segregation of uodertrial prisoners.

219

Cleansing of apartments and bedding.

219

Production before Cour.

219

Roll to accompany prisoners.

220

Procedure when undertrial prisoneis are unduly detaincd.

220

Food arrangement during trial.

220

Release on bail.

220

Superintendent to report if prisoner is seriously ill.

220

Visitors

221

Facilities for letter writing

221

•1

I

S

at
p

Chapter XLIV
PRISONERS SENTENCED TO FINE
Paymentoffinesto Jail.

221

Liability of Prisoners to payment

222

Intimation of payment of fine.

222

Prisoner to be informed.

222

<!-- page 24 -->

xxv

Chapter XL%

•
•

•

*

.

CLASSES OF CONVICTED PRISONERS AND ThEIR TREATMENt
•

756.

Class A, B and C.

Page
222

757.

Classifying authority

223

758.

Treatmentof"A" class prisoners

224

759.

Treatment of "B" class prisoners

226

760.

Duties and privilege of A and B c!ass prisoners

226

761.

A and B class prisoners to be • allowed to exercise in open air.

227

762.

Copy of rules to be placed in each cell.

227

-

Chapter XLVI
PRISONERS SENTNCED TO SIMPLE IMPRISONMENT
769.

Application of remission and labourrules.

227

164.

Disciplinary restrictions.

227

765.

Exercise

227

766.

Ha!r cutting and clotlung

227

767.

Applicntionofother rules.

227
Chapter XLVII

PRISONERS SENTENCED TO SOLITARY CONFINEMENT
768.

Method of executing sentence.

769.

Caleulationofterrn

770.

When two sentence are imposed

771.

Restriction

772.

Prisoner tobe medically examined

773.

Search of prisoner and cells.

774.

Ticket outside cell rloor.

775.

Exercise

776.

Airing of bedding:

777.

Occupant to clean cell

on

228
228

-

.

228

-

228

similnr,Jail Punishment

778.

Precautions for prisoner's safety.

779.

Recodofconfinement

228

-

228
228
229

•

229
.

...

229

.
'

.

229
229

<!-- page 25 -->

Chapter XLVW
PRISONERS SENTENCED TO DEATH
Page
Search of prisoner.

229

Confinement in a condemned cell.

229

Provision of guard

230

Source of guard.

230

Restriction on communications with prisoner.

230

Precuations against suicide.

230

-

- Supervision of guard.

230

Guard over several condemned prisoners.

230

Daily search of prisoner

230

Diet

231

Exercise

231

Application of rules to females.

231

AdmSion of visitors.

231

Intimation to the prisoners of the juagernent of the Appellate Court.

231

Where convict petitions the Supreme Gburt for special leave to appeal.

232

Intimation 0 the prisoners of the decision of the Supreme Court.

232

Where no petition to Government.

233

Submission of petition for mercy to Government.

233

Petition for mercy submitted after the prescribed period.

233

Exceptional circumstances, to be reported.

233

Acknowledgement of telegrams communicating orders on mercy petitions.

233

Execution to be stayed if prisoner found insant

234

Where female prisoner found pregnant

234

Or alleges pregnancy.

234

204. Orders of Government to be taken.

234

805. Prisoner's attendance as withss.

234

8O, Place

234

WWMUQAI

4.

C

<!-- page 26 -->

,çxvll
Page
235

Attendanceof Spectators.
Preparation of mechanical appliances.

3.

7 235
-235

Scale of drop.
810.. Hour of execution—Presence of Officers

235

Oil.

Security of Prisoner

236

Reading of warrant and identification.

236

Limbs to be secured

236

Examination of body.

236

Disposalof body.

236

Certificate of execution.

236

Money rewards

236
Chapter XLIX
FEMALE PRISONERS

Classification and segregation of female prisoners

236.

Restriction of females to female enclosure.

237

Exclusion otmales

237

Locks of female enclosures.

287

Treatment of hair

237

Females not tobe fettered

237

Application of Rules

237

Menial duties.

238

Release of female prisoners.

238

Released women prisoners to be provided with connveyances

238

Prisoner's children

238
ChapterL
YOUTHFUL PRISONERS

.

Segregation of youthful prisoners

239

Diet and discipline

239

Application of rules to youthful prisoners.

239

Punishment under Act.

239

Transfer to certified school.

240

834, Notice of rçleasç

?40.

-

<!-- page 27 -->

a'v111
•

ChapterL!
LUNATICS

-

Page
835.

Classification of Luhatics

240

836.

Medical histor of civil lunatics to beient to jail

240

837.

Maximum period of detention of a lunatic.

638.

Lunacties of classs TX rcportof insare convicts' case and removal pending orders.

241

Documents accompanying report.

241

A

241

-

-

Transfer to Mental Hospital

242

841.

Prisoners confined under certain provisions of the Cl.

842.

Medical Certificate under Lunacy Act to be s'nt to nieutal hospital

-

243

843.

Certificate tinder Section 473, Criminal Procedure Code

-

243

844.

Halfyearly return.

244

845.

Lunatict of Class V documents to accompany lunatic.

Y44

846.

Retr\nsfer to Mental Hospitil

244

847.

Employment to criminal lunatic.

244

848.

Special precautions in confining Lunatics,

244

849.

Precautions on trathfer.

245

850.

Clothing on transfer

851.

Food.

852.

Procurcincasesofillness

853.

Female to accompany female Itinatic.

245

854.

Property of lunatic

245

P.C. howdealt with.

It

243

on relapse

245
-

245
245

-

Chapter LII
LEPERS
855.

Submission of case to Inspector General

856.

Order of transfer

857.

Segregation of the leper convict not titus

246

-

246

-

858, Medical Officer to be fl-Officio
Wardt under the Prison Act.

transferrerl.

247

Superintendent of the

2+7

-

preventions.

-

859.

Other

8 60.

Certain documents to accompany the leper convict.

247

-

-

247

ait

<!-- page 28 -->

xxix
Chapter LW

-

T. B. PATIENTS

•

-

Page•

-*

861.

Submission of case to

862.

Order of transfer

248

863.

Transfer in urgent cast

248

864.

Medical Officer to be cx-officio Superintendenh

248

865.

Documents to accompay ihe TB. Convict.

249

Segregation of the T.B. convict not thus transferred.

249

Other preventions.

249

* 866.

867.

•

the Inspector-Genera! of Prison,.

247

ChapterUV
CORRESPONDENCES AND RECORDS
868.

System of filing order

- 249

069.

Prohibition of ensures.

249

Initials to be dated.

249

Maintenance of accounts.

250
Chapter LV

THE MANUFACTURING DEPARTMENT

Y

872.

A first grade Aisistance Jailer to function as Store- kpeper.

250

873.

Sale amountt to be remitted to Treasury once a week oroftener.

250

874.

Procedure regarding large payments which cannot be met from
the permanent advance

250

875.

PurchaseofRaw4teria!s

250

876.

Purchase of Articles how arranged.

877.

Budget Grant, application for increased grant, etc.

878.

Payment of work done or articles surplied by the Jail for
Government Departments
-

*

251

.

S

879.

Receipts—Head of charge

880.

Price of, the Manufactured articles.

881. Depreciation charge.
882.

251

-

251
-

252

-

-\
•

Raw materials, purchase, receipt and stock—Duties of Store-keeper.

•

252
252
252

<!-- page 29 -->

rn
Pge
'

•

983.

EiuryinStok-book

252

884.

Raw materials nottobe issued exception indent.

252

885.

Frequency, of

252

886.

indents to be issued in book-fbrm counterfoils to be preserved.

253

887.

Accounting manufactured articles received baèk from Workshops:

253

888.

Balance to be struck off stock remaining.

253

889.

Superintendent to check indents and counterI'oils once a week.

253

890.

And tosatisfy issues are duly aecountedfor.

253

891

Unsatisfied indents.

253

892.

Register of orders for goods

254

893.

Contract to be entered after • approval of samples and acceptance of the rates.

254

894.

Defect in Workmanship to be brought to notice of Superintendent.

254

895.

Stock-Book of manufactured

896.

Day Book of sales and individual Ledger.

254

897.

Store-keeper to issue pass for articles sold or sent out of Jail.

254

898.

Receipt for cash received.

-

indents.

articles.

46
*

254

-

254

Half-yearly statement, of Profit and Loss and outstanding dues.

254

Annual stock taking.

1

255

901.

Procedure before stock taking.

255

902.

Report to Inspector-General after stock-taking in regard to
depreciation in value of Manufactured articles or Raw Materials.

255

903.

Annual return of Manufacturing Plants.

S
.

255

ChapterL'vI.
WELFARE OFFICER
904. - Appointment of Welfare Officers.

- 255

05. Functions of Welfare Officer.

255
256

Special training.
Appointmeat of Chief Welfare Officer
- Duties and responsibili4es

•

or Chief Welfare Officer

257
•

25,7

<!-- page 30 -->

CHIEF SECRETARIAT (HOME-B) DEPARTMENt
NOTIFICATION

Dated, Trivandrurn, 26th July, 1958.

G. 0. (MS.)No. 925.

i%

In exercise of the powers conferred by section 59 of the TravancoreCochin Prisons Act 1950 (Act XVIII of 1950) and Section 59 of the Prisons
Act 1894 (Central Act IX of 1894) and in supersession of the existing rules
on the subject, the Government of Kerala hereby make the following rules,
namely:THE KERALA PRISONS RULES, 1958
CHAPTER I
tTHE CENTRAL PRISONS
1. Title and Extent.—(a) These Rules may be called the Kerala Prisons
Rules 1958.
(b) These Rules shall extend to the whole of Kerala.

Central Prjgon.—There shall be three Central Prisons in Kerala, one
at Trivandrum, one at Viyur in Trichur District and another at Cannanore.
t2A. District Jail.—There shall be a District Jail at Kozhikode, having
it upgraded the Special Sub Jail, Kozhikode.
"2B. Open Prison J'[ettukaltheri.—There shall be an Open Prison at
Nettukaltheri'!..
**2C Prisonfor Women._There shall be a Prison for womn at Neyyattinkara.

Classes of prisoners confined in the Central Prisons.—(a) All prisoners convicted and sentenced to imprisonment for whatever terms by the Several
Criminal Courts in the District of Trivandrum and all non-habitual prisoners
sentenced to more than one month by the Criminal Courts in the Districts
of Quilon, Kottayam and Alleppey shall ordinarily be confined in the Central
Prion, Trivändrum.
in the Central Prison, Trivand.rum shall also be confined all civil prisoners
committed to that Jail by the Civil Courts in the Districts of Trivandnun,
Quilon, Kottayam and Alleppey and prisoners committed by the Criminal
*See G.O. (Rt.) 2173174.
tSee G.O. MS. 190169 Home. dated 16-6-1966.
tG.O. Rt. No. 2727177 H dated 31-12-1977.
'G.O. (MS) 71/95 Home dated 17-5-1995.

161327415'MC

<!-- page 31 -->

Courts in th&Districts of Trivandrum, Kottayam, Quilon and Alleppey
for detention in a Civil Prison and all female undertrial and remand
prisoners in the District of Trivandrum.
(b)
All non-habitual prisoners sentenced to imprisonment for.
periods of more than three months by the Criminal Courts in the Districts
of Ernakulam, Trichur, Paighat, Kozhikodc and Cannanore, all habitual
priosners convicted and sentenced to one month and less by the Criminal
Courts in the Cannanorè District and all priosoners sentenced to whatever
term by the Criminal Courts in the Town of Cannanore shall ordinarily
be confined in the Central Prison, Cannanore.
In the Central Prison, Cannanore shall also be confined all civil prisoners
committed to that Jail by the Civi] Courts in the Districts of Palghat,
Kozhikode and Cannanore and prisoners committed to a Civil Jail by the
Criminal Courts in the Districts of Palghat, Kozhikode and Cannanpre.

a

£

(c) All habitual prisoners sentenced to imprisonment for more than
one month by the several Criminal Courts in the State of Kerala. All
habitual prisoners sentenced to imprisonment for whatever term by the
Criminal Courts in the Towns of Trichur and Wadakkancherry and civil
p;isoners- committed to thtt Jail by the civil Courts in the Trichur District
and prisoners committed to that jail by the Criminal Courts in the Trichur
District for detention in a Civil Prison shall be confined in the Central Prison,
Viyyur.
(d) The following classes of prisoners shall also be confined in the
Central Prisons :prisoners sent by transfer under orders of the Inspector General
of Prisons;
prisoners convicted by a Court martial and transferred by a
competent authority;

.

prisoners transferred under section 3 of the Transfer of Prisoners
Act, 1950 (Central Act XXIX of 1950);
security prisoners;
such other prisoners by general or special order of Covernment
or Courts to be detained; and
criminal lunatics detained for observation,
(e) All prisoners convicted and sentenced to imprisonment for periods
ranging from above one to six months by the Criminal Courts in the Distric
of Kozhikode and all non-habitual prisoners sentenced to more than one
month and not exceeding six months by the criminal Courts in the Districtst
of Palghat and Trichur shall be confined in the District Jail, Kozhikode.

1

<!-- page 32 -->

S
*14. Admission to Open Prison—WeIl behaved 'C' Class male prisoners
sentenced to imprisonment for three years and above, preference being
given to those sentenced for longer periods may be selected from the cloed
prisons of the State and transferred to and cothned in the Open Prison,
if those sexnenced to three years have served one year of the actual sentence
and those sentthced to more than three years have served three years of
actual sentence. The filial "selection of such prisoners shall be made by
the Inspector General of Prisons. But no prisoners can claim such transfer
as a matter ofright:

•

Provided that no person convicted and sentenced to imprisonment for
any of the full wing offences shall be selected for confinement in the Open
Prison, namely:/
Offence:
I. against the state;
relating to armed forces;
relating to counterfeiting of Currency, Coins etc;
against publid tranquility;
relating to kidnapping, abduction, slavery and forced labour;
relating to rape;'
relating to unnatural offence; or
.8. relating to robbery, dacoity, cheating and house breaking.

T

.*t3B Admission to Prison for Women.—All 'C' class female prisoners
sentenced to imprisonment for three months or more by Courts in the Distrkts
of Thiruvananthapuram, Kpllam, Pathanamthi.tta, Alleppey and Kottayam
Districts shall be confined in the Prison for Women at Neyyattinkara. The
female prisoners sentenced to imprisonment for one year or more including
imprisonment for life by the Courts in other districts shall be transferred
to the prison for women. In no case female prisoners sentenced to death
shall be transferred to the Prison for Women.
CHAPTER II
INSPECTOR GENERAL OF PRISONS

4. Control of expenditure.--(l) Subject to the rules and orders of
Government in the Finance Department and to the requirements of the
Comptroller the expenditure of the jails department shall be controlled
the Inspector General of Prisons.
YO. Ri. No. 2727/77/Fl. dated 31-12.1977.
G.O. (MS).NO. 71/95/Home, dated 17+1985.

<!-- page 33 -->

9
He shall annually submit to Government in the Finance and Administration Departments the prescribed budget of charges and receipts despatching the same on the dates and in the manner prescribed in the
Travancore Financial andAccount Code.
At the commencement of each official year he shall distribute
the total budget allotment among the several jails and other institutions
under him.
5. Power to sanctionexpenditure..(a) The Inspector General of Prisons
is authorised to sanction all expenditure within the budget allotment.

4

He may sanction the payment of a reward to any subordinate
Jail Official up to a limit of Its. 25 for any service or special merit.
*(bb) He shall be competent to sanction purchase of spectacles and
dentures for the use of the prisoners at Govermnent cost, on the recommentation of the medical officer of the Prison concerned and on the
strength of the report from the Superintendent of the Prison, when the
prisoner concerned has neither wages amount nor private cash to meet the
€ofl thereof.
*

*

*

*

*

*

- (d) He is authorised to countersign all contingent bills of subordinate
officers.
He is authorised to c9untersign travelling allowance bills of all
the subordinate officers.
He is authorised to sanction petty purchases not exceeding Es. 250.
He may also sanction rewards to private persons effecting or
assisting the recapture of an escaped prisoner as follows:—
lithe sentence was one of death or life imprisonment Its. 50, if the
sentence was 2 years and upwards or confinement in security for the same
period Its. 20. lithe prisoner was an undertrial a reward equal to what
would be payable where the prisoner convicted of the offence charged
and sentenced to the maximum penalty.
He is authorised to sanction the purchase of books for the use
of the department if the expenditure will be covered by provision in the
budget.
*G.O. (MS) No. 85/77jHome dated 28.6-1977. Sub Rule (C) of Rule 5 deleted as per
Doverament Notification No. 38173fB3/65.2/Honie dated 24-12-1965.

1

S

-'

<!-- page 34 -->

S
He is authorised to sanction to subscribe for dailies for prisoners
at the rate of one daily for every fifty prisoners.
He is authorised to sanction to write off, of accounts or petty
losses due to breakage of articles the book value of which does not exceed
Rs. 500 in each case subject to an annual limit of Ks. 5000.
He is authorised to sanction the sale by auction or use in the
Jails of the dead trees standing in the Jail compound, the auction
sale being conducted after due publicity by notification in the
Government Gazette.
*

(I) To sanction purchase of stores and raw materials required for the
industries of the Jails up to Rs. 500 at a time observing Store Rules subject
to budget provision and an annual limit of Rs. 3,000.
To sanction purchase of seeds, seedlings and manures for the Jail
Gardens upto an amount of *Rs. 25,000 at a time subject to budget provision
purchase being made from agricultural farms if they are available there.
To sanction purchase of livestock upto an amount of Rs. 500 at
a time subject to budget provision and an annual limit of Rs. 3,000 purchase
being arranged through the Animal Husbandry Department and to dispose
of the useless animals in public auction after obtaining a certificate from the
District Veterinary Officer concerned regarding the unserviceableness of the
animals.
**6. Power to sanction contracts.—"The Tnspector-General of Prisons is
authorised to sanction all contracts for provision and miscellaneous articles
required for each Jail subject to budget provision and subject to the financial
limits prescribed in the Stores Purchase Manual, as amended from time to
time."
-

S

He may also sanction the other contracts subject to ratification by the
Government. Every contract for the supply of articles required for the
Jails or which imposes a recurring liability on the Jails shall be drawn up in
proper form. No contract or agreement can be considered valid unless
executed by the Tnpector-General of Prisons.
7. Power to sanction institution of civil suits.—The Jnspector-General is
authorised to sanction the institution of any Civil Suit for money due to the
manufacturing department of the Jails, provided that he is satisfied that the
claim is well founded and that the debtor is possessed of property against
G.O. MS. No. 491921Home dated 29-2.1992.

**Rulc 6 substituted as per G.O. (MS.) 425/67/Home dated 1st December
1967.

<!-- page 35 -->

which a decree, if obtained, could be executed. He may also sanction the
institution of Civil Suits against defaulting contractors and others, provided
that no such suit shalj be instituted except on the advice of the Government
Pleader to whom a concise and clear statement of the case shall be submitted
for opinion. No Civil Suit shall be instituted until all other means of obtaining satisfaction have been tried and have failed. Every case in which notice
of suit against the Jail Department or against any Jail Officer for acts done
in his official capacity is received shall be reported to Government,for orders.
8. Imspection of Jails.—(l) The Tnspector-General of Prisons shall visit
the Jails at least twice in every calendar year and on each such visit shall
carry out a full inspection of the Jails in accordance with the questionnaire
•
approved by Government. (See questionnaire in Appendix III).

•

4

During each inspection he shall personally see every prisonerthen
in confinement in the Jail; he shall give every prisoner a reasonable opportunity
of making any application or complainf and shall investigate and dispose of
such application or complaint as relate to Jail discipline.
He shall inspect the yards, wards, cells. workshed and other
enclosdres, shall examine the gardens, enquire into the character of the water
supply, the conservancy arrangements and the medical administration, shall
see the food and ascertain that it is of proper quality and quantity and generally
satisfy himself that the building and premises are in proper order.
He shall inspect all journals, registeis and books maintained in
every department of the Jail and initial or countersign therein in token that
he is satisfied that they are maintained in accordance with the rules. He
shall satisfy himself that the orders of Government regarding the arrangement
and periodical destruction of records are observed.
He shall inspect the Warder establishment, satisfy himself as to
its proficiency in drill and musketry, inspect its arms and accoutrements and
test the ability of the Superintendent, Jailer, Deputy Jailer, Assistant Jailers,
Chief Warder and Head Warders to drill the guard.
He shall examine whether the Jail staff is adequate and whether
discipline amongst the staff has been properly maintained.
He shall examine whether sufficient labour has been available for
prisoners sentenced to rigorous imprisonment, and if so whether adequate
tasks have been ecacted; and if not what the reasons are for the insufficiency
of the labour available. Immediately after the inspection the InspectorGeneral shall forward to the Superintendent a copy of the questionnaire
dulyfll1ed up together with such further suggestions as he thinks fit for the
remarks of the Superintendent. He shall also submit a copy of the same with
the remarks of the Superintendent to Government. The orders of Government thereon shall be communicated to the Superintendent for guidance.

•

<!-- page 36 -->

(8) The Inspector-General of Prinsohs shall submit to- Government
annually as soon after the 1st April as possible and not later than the 30th
August of the same year or other date fixed by the Government a detailed
report on the administration of Jails of the previous financial year together
with such statistical and other, statements, returns and information as Government may from time to time require. The report shall show the inspections
made during the year by the Inspector-General of Prisons and shall state
wther the orders of Government have been observed.
(9) The Inspector-General of Prisons shall be the channel of communication between the Government and officers of the Jails Department.

.

*

s

(10) The Inspector-General of Prisons is included in the list of Departmental Heads and authorities who exercise the powers of Heads of Departments (Vide Appendix I of the Travancore Financial and Account Code).

9. Special report in certain cases—The Inspector-General shall submit
to Government a special, report regarding any Jail which he considerj to be in
- an unsatisfactory state(vith the explanation of the officer-in-charge.
-

10. (1) Transfer of prisoners.--The Inspector-General or Prisons shall
have the power to order the transfer of any prisoner from one Jail to another
Jail within the State and shall also have authorily to order the removal of
prisoners from the-permanent buildings of any Jail into temporaxy accominodation during epidemics.

(2) Report of important occurrences—Any outbreak of epidemic disease
or unusual sickness, all serious breaches of Jail discipline, escapes, attempts to
escape, re-captures, accidents, suicides, attempts at suicide or death from
/ violent or un-natural causes shall be at once reported to Government by the
Inspector-General of Prisons.
11. Powers of appointnthnt.—It shall be competent to the Inspector-General
• of Prisons: (a) To make any appointment on the sanctioned establishment of
non-gazetted officers, in any of the institutions under his administrative
control, subject to the Public Service Commission Recruitment Rules and the
Public Service Commission Consultation Regulations. All other appointments shall be made in accordance with rules and orders issued by Government
from time to time laying down the qualifications for such appointments.
To sanction promotions of all subordinates whom he is competent
to appoint and to make initial appointments to such posts in Vacancies of
not more than one month's duration.
To grant all kinds of leave other than study leave and special
disability leave to all non-gazetted subordinates and gazetted officers under
Jails Department below the rank of Superintendent of Central Jails and casual leave to all the gazetted officers,

<!-- page 37 -->

(4) to permit all officers to whom he is empowered to grant leave
and to return, to duty before the expiry of any kind of leave granted to them.
(e) To sanction incre'ments to all non-gazetted staffof the department.
(F) To appoint contingent female warders in emergent cases in the
Sub-Jails for guarding female prisoners, for periods not exceeding three
months.
To countersign pension papers of the gazetted officers of the
department and grant pension to all non-gazetted officers after being verified
by the Comptroller, Kerala State.
To sanction subsistence allowance to officers placed under suspension subject to the rules.
To sanction temporary withdrawals from the provident fund deposits
by subordinates of the Department up to a maximum of its. 1,000 in each
case in normal cases, and Rs. 500 in special cases, subject to the other conditions and limitations under the Rules of the fund.
To permit non-gazetted officers whom he is competent to appoint
to accept employment while on leave.
To retire officers who have completed 25 years of service.
(1) To sanction refunds of amoi nts remitted into treasuries by mistake.
To dismiss, degrade, suspend, discharge or accept the resignation
of any officer whom he is competent to appoint.
To fine any officer belonging to the last grade service and warders
first and second grade as per provisions in the Kerala Civil Service (Classifi- •
cation, Control and Appeal) Rules.
It shal' be open to a subordinate punished by the Inspector-General
of Prisons to appeal against the order of punishment within two months
after the receipt by him of the copy of the order appealed against, subject
to the provisions of the Kerala Civil Services (Classification, Control and
Appeal) Rules.
Every appeal must be forwarded through the Inspector-General of
Prisons who shall forward the same with his remarks and any necessary
records.
The Inspector General of Prisons is competent to transfer between
the Jails under his control subordinates he is competent to appoint.

<!-- page 38 -->

91
CHAPTER III
VISITORS
12. Ex-ofcio visitors.—The following officers shalt be ex-ofllcio visitors
of Jails in their respective jurisdiction:The Sessions Judges of Trivandrum, Trichur and Gannanore.
The Collectors of Trivandrum, Trichur and Cannanore.
The District Magistrates (Judicial) of the Districts of Trivandrum,
Trichur and Gannanore.

is situated.

The District Educational Officer of the District in which the ptison
-

The following officers shall be ex-officio visitors of all the Central
Prisons:The Inspector-General of Police;
The Director of Health Services;
The Director of Industries;
The Director of Agriculture;
The Director of,Public Instruction; and
The Chief Inspector of Factories.
1-3. Appointment of non-official visitors.—The Government may appoint
and fix at such figure as they may think fit the number of persons to be non- official visitors in respect of each Jail. The visitors shall includeAll M.L.As. and M.Ps. of the District in which the Jail is situated;
Any responsible person of the locality;
One Doctor practising in the District;
One Lawyer practising inthe District and "one senior Lawyer of
standing at ihe Bar nominated by Sessions Judge of the District; and
One Woman Social Worker.
Every non-official visitor shall be appointed for a period of two years
and shall be eligible for reappointment on the expiry of each term of office:
Provided that Government may, if they so consider necessary cancel
the appointment of any or all of the non-official members at any time during
such term for good and sufficient reasons, or for their failure to visit the Jail
concerned consecutively for three months. But in the case of concellation of
appointment of the senior lawyer the Sessions Judge of the District shall be
consulted.

1613274/95/MC.

<!-- page 39 -->

I0
The official and non-official visitors of each
14. Visits by visitors.—(l)
Jail shall constitute a Board of winch the Collector of the District shal.1 be the
Ex-Officio Chairman. It shall be the duty of the Chairman to arrange
the roster for monthly visits to the Jails so as to give each visitor, official and
non-official, his due turn, and to send out a notice by Post card intimating
whoseturn it is to visit the Jail in the coming fortnight. There shall not be a
fixed day of the month for these visits, but the visitor shall be left free to visit
the Jail on any working day that suits him. There shall also be a quarterly
meeting ,
ofthe Board of visitors on such day as the Chairman may deermin;
which shall he attended by the official and non-official visitors.
Except in exceptional circumstances a visitoF shall not visit the
Jail after lock-up or on Sundays.

a

10
*

A non-official visitor who is about to absent himself for a period
of six months or more from the station shall report the circumstances to the
authority who appointed him in order that a substitute may, if necessary,
be appointed and in the event of his failure so to report he shall be regarded
as having vacated office on the expiry of three months from the date of his
departure.
Nothing in these rules shall prevent visitors visting the Jail on
dates other than those fixed by the Chairman of the Board.
*15. Powers and duties of visitors—It is the duty of a visitor to satisfy
himself that the law and rules regulating the management of the Prison and
prisoners are duly carried out in a Jail, to visit all parts of the Jail and to
see all prisoners, and to hear and inquire into any complaint or representation that any prisoner may make to him. A visitor may call for and inspect
any book or other record in the Jail provided that the Superintendent may
decline to produce any book, paper or record for the inspection of any nonofficial visitor, if, for reasons to be recorded in writing, he considers their
production undesirable. The Board sh4ll meet at the Jail inspect all buildings and prisoners
hear any complaints and petitions that may be preferred, inspect the prisoners
food and see that it is of good quality and properly cooked and examine the
punishment book and satisfy themselves that it is up-to-date. A list of
questions indicating some of the points to which the Board and visitors may
direct their inquiries is printed in Appendix II. A copy of the list of questions
hall be given to each visitor on appointment.
16. Record to be made of inspection.—(l) Every visitor shall, after he has
completed his visit to the Jail, record in the visitors book prescribed by
Section 12 of theTravancore-Cochin Prisons Act (XVIII of 1950) and Section
12 of the Central Act, 1894 the date and hour of his visit and may enter
* Note—It is not part of we duty of avisitor to examine the correctness
of convictions and sentences that are being undergone by prisoners.

it

<!-- page 40 -->

11
therein any remarks or suggestions he may wish to make. Entries in the
visitors book shall be made in the visitor's own handwriting and the book shall
not except with the express permission of the Superintendent be removed
from the Jail for this or for any other purpose.

*"16A. Inspection by Senior Lawyer and Sessions Judge.—(l)

Notwithstanding

the provisions contained in rule 16(a) The Senior Lawyer nominated under clause (d) of the rule 13
shall while making his monthly visit to jails, entertain grievances, if any,
from the prisoners and report the matter to the Sessions Judge of the District.
•

(b) The Sessions Judge shall during his monthly visits to the jails
entertain grievances if any, from the prisoners.
2. The Sessions Judge shall recommend to the High Court such action
as is necessary to be taken by the Ihspector General of Prisons or by the
Government and the High Court may, after considering such recommendation
communicate its views to the Government with a view to enable them to act
upon".
-

A visitor may reord any remarks or suggestions he may desire
to make and the Superintendent shall place a copy of such record with his
remarks thereon before the Board of visitors and the Inspector-General of Prisons immediately. The Board shall consider them in detail and if found
necessary they mhy forward the same to Government with their remarks.
A copy of any order passed by the Government shall also be placed before
the Board.
No visitor may issue any order or instruction to any subordinate
Jail Officer.

4

Disposal of complaints to visitor by prisoners—The remarks recorded
by a visitor in the visitors book should include any complaint made to him by
a prisoner which in his opinion deserves notice. When the Superintendent
is of opinion that a prisoner has made a groundless complaint to a visitor andshould be punished he shall record a brief- statement of the facts and note
what punishment he proposes to award and send it to the visitor, who if he
u that the case
dissents from the conclusion of the Superintendent, may reqest
be submitted to the Inspector-General for orders. A copy of the InspectorGeneral's orders will be communicated to the visitpr who may r then, if he
thinks fit, address Government regarding the case.
Disposal of record made by visitor—A copy of any remarks recorded
by a visitor together with the Superintendent's reply and a note of any action
taken thereon, shall be forwarded to the Inspector-General who may, if in
G. 0, MS, No. 140I83/1. dated 18-10-1983.

<!-- page 41 -->

12
his opinion it is necessary, forward the correspondence for the information and
orders of Government. A copy of the orders (if any) of Government or the
Inspector-General shall be forwarded to the visitor through the Superintendent of the Jail.

Admission to the Jail of others than the officers specijled.—With
the
exception of the Ministers, the Chief Engineer and the Executive Engineer
of the District in connection with the duties of their Department, the official
and non-official visitOrs and Jail officers, no person shall be allowed to enter
the Jail ynless accompanied by the Inspector-General of Prisons or .the
Superintendent or furnished with the written permission of the Ghief Secretary
to Government, the Inspector-General of Prisons or the Superintendent.
Admission of Police Officers to the Jail.—In order to give the Police

•
*

the oppo' tunity of recognizing habitual convicts, they shall be permitted
to visit the Jail both at the weekly inspection parade and at other times, if
desired, provided that such visits shall not be allowed to interfere with the
labour or routine oftheJail.
21 . Grant of pass to the Police to visit the Jail.—The Superintendent shall
grant a written pass permitting a fixed number of police to enter the Jail
at the hoursj stated. This pass shall not be given up at the gate, but shall be
retained by the Police for the period specified therein.

Interrogation of prisoners by the Police.—The Police shall be permitted
to ask any prisoner any question directly bearing on his identity or previous
history, but shall not be allowed to hold any further communication than is
necessary for purpose of such identification. Every such question shall be
put in the presence of a responsible Jail Officer not below the rank of an
Assistant Jailer and no prisoner shall be liable to punishment for refusing
or omitting to answer. Except as provided in this Rule; no Police Officer shall
be permitted to examine or make enquiries of any prisoner without the
written order of the District Magistrate (Judicial) or District Superintendent
of Police.
Escort to accompany visitors .—The Superintendent shall arrange
that every visitor to the Jail shall be attended by some responsible Jail Officer.
as well as by an escort of from 2 to 4 warders. The escort and the officer
accompanying a visitor shall withdraw out of hearing but not out of sight,
if required to do so by the visitor, when he is questioning a prisoner.

II

<!-- page 42 -->

13
CHAPTER IV
THE SUPERINTENDENT

Appointment of jail Superintendent.—( I) The Superintendents of the
Jails shall be officers specially appointed by name.

•

(2) During the absence of a Superintendent appointed under this
rule, the powers and duties conferred on him by law shall be exercised and
performed by the Jailer of the Jail. No such Superintendent shall quit the
station or make over charge of his jail to any person or officer without having
obtained the previous sanction of the Inspector-General of Prisons.

Executive management of jail by the Superintendent—The executive
management of the Jail in all matters relating to internal economy, discipline, labour, expenditure, punishment and control generally shall be vested
In the Superintendent subject to the orders of the Inspector-General of
Prisons and the Rules sanctioned by Government.

1(

M. General duties of Superintendent.—(l) The Superintendent shall make
himself thoroughly acquainted with these Rules and with the Prisons Act
and shall be strictly responsible for the due carrying out of all such Rules
and statutory provisions and the execution of all sentences on prisoners
committed to his charge.
-

I

(2) Every order of the Superintendent shall be subject to the
revision of the Inspector-General of Prisons and Government. -

p- '
-

Daily visit of jail.—The Superintendent shall visit the Jail at least.
once in the forenoon and once in the afternoon of every working day and
on Sundays and holidays also whenevtr special circumstances render it
desirable that he should do so. If from any cause, he is prevented from
visiting the Jail on any day on which he is by this rule required to do so, he
shall record the fact and the cause of his absence in this journal. At least
twice a month he shall visit the Jail at night and satisfr P himself that the
guarding is being properly performed and that everything is in brder.
Maintenance of journaL—(I) The Superintendent shall maintain
on half-margin foolscape and in his own handwriting, a journal, in which
he shall record as soon after the event as pos4ble,the times at which he enters and leaves the Jail daily, and the
result of his weekly inspection of the prisoners, guard and premises;
the special reasons for the imposition of fetters on prisoner
ordinarily , exempted (Rule 568);
the matters referred to in Rules 349 and 669;

<!-- page 43 -->

14
(d) every occurrence of importance connected with the management of the Jail which is not otherwise disposed olin the registersor correspondence and which it is desirable to note for future reference.
(2) The Journal shall be fojwarded to the Inspector-General of
Prisons on the first day of the month following that to which it relates or as
soon after as possible and shall be returned after perusal by him, with such
remarks as he may find necessary.

.

29. Jail business to be trausacted on Jail premises—The Superintendent
shall, as a rule, transact.all business connected with the jail within its precincts. He shall not eccept in case of necessity, require the attendance of
the Jailer or other subordinates beyond the Jail limits.
30. Weekly inspection of prisoners.—( 1) On one morning in every week,
which thall usually be Monday, the Superintendent shall hold an inspection
parade of all prisoners, at which the Medical Officer shall also he present.
(2) At each such parde the Superintendent shall satisfy himself ;that every prisoner is properly classified as provided in the
rules in that behalf;
that every prisoner is provided with proper clothing and
bedding;
that the provisions of the Remission Rules are understood by
the prisoners;
generally that the rules and orders applicable, to prisoners
are being duly carried out.
(3) The Superintendent shall at every such parade, hear and inquire
into any complaints that the prisoners may wish to make, it shall be his duty
to listen to complaints and petitions of prisoners in a patient and considerate
manner, and to afford prisoners reasonable facilities for making such representations.
(4) Nothing 'to this rule shill debar a prisoner from making a corn-C
plaint or application to the Superintendent at other times than the weekly
parade and it shall be the duty of every Jail official to produce before the
Superintendent without delay any prisoner desiring to see him.
31. ContrOl over receipts and expenditure--The Superintendent shall be
responsible for the economical working of the Jail; he shall carefully consider
the necessity for all expenditure before ipcurring it, and shall satisfr himself
that all rates paid are the, lowest compatible with efficiency. He shall be

,g

<!-- page 44 -->

15
responsible for the satisfactory conduct of the manufacturing department,
the punctua1 execution of orders, the due credit of all sums - collected and
generally for the financial administration of the Jail. He shall he answerable
for all Jail property, stores and moneys, and shall be held responsible for any
defalcations on the part of the Jail establishment, if it be shown that such
defalcations were rendered possible by negligence on his part.
The Superintendent is authorised to incur expenditure on account of
Kerosene oil for daily use not exceeding 21.720 ml. a day and to keep always
in stock one tin of kerosene oil and four dozen hurricane lamps.
*The Superintendent shall be competent to sanction purchase of specacles and dentures for the use of the prisoners on the recommendation of
the Medical Officer concerned, meeting the cost thereof from the amount of
wages at credit of the prisoner concerned or from the Prisoner's cash property
available in the Prison.

u

1

Procedure regarding civil suits.—No civil suit shall be instituted or
defended by the Superintendent on behalf of Government without the previous sanction of the Inspector-General of Prison. Upon the Superintendent receiving notice of suit, lie shall immediately forward the notice
with a full statement of the facts of the case, to the Inspector-General of
Prisons.
MaintEnance of records.---(]) The Superintendent shall be responsible
for the correct maintenance of the records prescribed in Section 12 of the
Prisons Art, 1950 (XVIII of 1950) or Central Act IX of 1894 and of such
other records as are prescribed by these Rules, and at least once a month
shallexamine every such record and shall satisfy himself that it is up-to-date.

S

(2) When no provision exists in these Rules prescribing the Officer
by whom any register or record shall be maintained, the Superintendent
shall by order recorded in the order-book from time to time, assign the
maintenance of every such register or record to a specified subordinate.

Submission of reports and returns. —The Superintendent shall submit
punctually to the Inspector-General of Prisons such yearly and other returns,
statements, bills and vouchers as may be, from time to time prescribed. As
soon as possible after the close of each year he shall furnish the InspectorGeneral of Prisons with a report on the. administration of the Jail in which
all matters of importance or possessing a bearing on the Jail statistics of the
year shall be noticed. He shall be generally responsible for the due - carrying
out of 41 rules hereinafter contained relating to account books and records
of all kinds.
*GO(Ms) No. 85/77 dated 286-1977.

<!-- page 45 -->

16
35. Control of expenditure.—(l) Subject to the rules and orders of
Government in the financial department, and the directions of the InspectorGeneral of Prisons, the expenditure of the Jail shall be controlled by the
Superintendent.
He shall annually subnlit to the Inspector-General of Prisons
the prescribed budget within the time limit prescribed thérefor.
The Superintendent may sanction expenditure subject to budget
provision not exceeding Rs. 25 at a time.
36. Report of important occurrences—Any outbreak of epidemic disease
or unusual sickness, all serious breaches of Jail discipline, escapes, attempts
to escape, re-captures, accidents, suicides, attempts at suicide or deaths from
violent or unnatural causes shall be at once reported by the Superintendent
to the Inspector-General of Prisons.
All communications from a Member of Parliament or of a State .Legislature under arrest or detention or imprisonment, addressed to the Presiding Officer of either Hoise of Parliament or of a State Legislature, Chairman of a Parliamentary Committee or of a Joint Committee of both Houses
of Parliament or Chairman of a similar Committee of a State Legislature,
as the case may be, shall immediately be forwarded by the Superintendent
of the Jail to the State Government, through the Inspector-General of
Prisons, so as to be dealt with by them in accordance with the rights and
privileges of the prisoner as a Member of the House of Legislature as the case
may be to which he belongs.
37. Intimation of serious illness or death ,of a prisoner.—When a prisoner
die 'or is eriousIy ill, the Superintendent shall immediately intimate the fact
of such death or illness to the relatives of such prisoner, either by wire or
express message and the fact reported to the Inspector-General of Prisons. *
38. Superintendent to furnish copy to Inspector-General of communications sent
to or received from Govenzment.—Whenever the ' Superintendent receives a
communication direct from Government or sends a communication direct to
Government either by telegram or by letter, a copy thereof, together with a
copy of the reply shall be furnished by him to the Inspector-General of Prisons
direct, in the cage ofpetitions for mercy from and on behalf of prisoners under
sentence of death, it shall not be necessaryto furnish the Inspector-General of
Prisons with of copics such orders of Government as are also furni'hed direct
to him by Government. Any specific action taken by the Superintendent on
any order or communication received direct from Government shall at once
be reported to the Inspector-General.
*proccedings order No. E41 7240/69 dated 17-6-1993 of I.G. of Prisons.

<!-- page 46 -->

17
Presence of inspections.—The Superintendent shall accompany the
Inspector-General during his inspection of the Jail and shall also accompany
official visitors they request his presence during their visits.
Superintendent's powers of appointment, suspension and punishment.—(l)

It shall he competent to the Superintendent to grant all kinds of leave except
study leave and special disability leave to all non-gazetted gubordinates
employed under him and casual leave to all subordinates.

16

It shall be competent to the Superintendent to make appointment of all
warders on the sanctioned establishment subject to the Public Service
Commission Recruitment Rules and Public Service Commission Consuhation
Regtilations.
-

All questions of pay, eligibility for leave and allowance shall be disposed of
in accordasce with 'the Service Regulations. When the Superintendent has
any doubt as to the application of the Regulation, lie shall refer the matter
to the Finance Secretary to Govermnent through the Inspector General of
Prisons and comply with instructions issued by that officer.
(2) It shall he .ompetcnt to the Superintendent to place any officer
of the warder staff, under suspension wherean inquiry into his conduct is contemplated or is pending; or
a complaint agaitist him of any criminal offence is under
investigation or trial.
The Superintendent should in such cases conduct an enquiry into the
charges against the Warders and pass final orders expeditiously. The final
• order passed by the Superintendent shall state, firstly the chaiges against such
officer, secondly the evidence in support of such charges, thirdly the finding on
each charge and fourthly the previous punishments if any, imposed on the
offier, and the latter is entitled to have on application a copy of it duly attested
by the Superintendent.
(3) The Superintendent rpay fine any member of the warder staff
below the rank of Headwarders in accordance with the provisions of the
Kerala Civil Services (Classification, Control and Appeal) Rules.
(4) It shall be open to a subordinate pi,mished by the Superintendent
to appeal against the order of punishment to the Inspector General of Prisons
within thirty days after the receijn by him of the copy of the order appealed
against.
(5) Every appeal must be forwarded through the Superintendent
who shall forward the same with his remarks and any necessary records.

16/3274/95/MG

<!-- page 47 -->

F.
(6) It shall be competent to the Superintendent to sanction
temporary withdrawals from the provident fund deposits of subordinate
officers up to a maximum Rs. 10,000* each in ordinary cases.
CHAPTEÜ V
THE MEDICAL OFFICER

Appointment of Medical
Officers.—A member of the Medical
Department not below the rank of an Assistant Surgeon shall be Medical
Officer of a Central Prison.

c

Control of Medical Officer.—The Medical Officer shall except as
regards the medical treatment of the sick act in immediate subordination to the
Superintendent and shall be subject to the general control of the Inspector
General.
Channel of coinmunjcation.—The Medical Officer shall ordinarily
correspond with the Inspector General through the Superintendent. He
shall accompany the Inspector General durings his inspection of the Jail.
Daily visii to-jail--The Medical Officer shall visit the Jail and shall
see the sick daily except on Sundays, and on those days also whenever necessary
and shall, inspect every part of the Jail at least once a week and make an
entry of his inspection in his journal and often in times of sickness. if he is
prevented from doing so by • sickness or any other cause, he shall record the
fact and the cause of it in his journal. If any epidemic or unusual sickness
prevails, or when the seriousness of the ease requires it, he shall visit the Jail
as many times daily as may be tiecessary.
Duties generally stated.—Thc duties of the Medical Officer generally
stated shall be to attend to the health and cleanliness of the prisoners, the
treatment of the sick the sanitation of the Jail, the supervhion of the hbcKl, raw
and cooked, the fortnightly, weightizents, and all oilier matters connected
directly or indirectly with the health of the staff and the inmates of the Jails.
Attendance of weekly inspection.—(l)
The Medical Officer %hall be
present at the Superintendcnt 5 s weekly inspection and shall then see every
prisoner and carefully examine each one, paying special attention to any
signs of a scorbutic or anaemic tendency of any falling off in condition, or of
skin disease. He shall also examine the prisoner's clothing and bedding to see
that they are adequate, as well as the buildings, drainage, ventilation, drinking
watbr and conservancy arrangemnentsof the Jail.
(2) He shall at, the same time examine the record of prisoner's weighments satisfy himself that the weight test is being properly applied and see that
thepHsoners' losing weight in any matérial degrees are sena,ratelv na.raderL
(F) 356194/Fin. thsted 612-1994.

P

<!-- page 48 -->

19
Attendance on jail Officers.—(l) The Medical Officer shall attend all
subordinate jail Officials and their families if they seek his a4vice whether in
the Iiospiai or in his quarters and give then' free treatmenL He shall bring
to the notice o.1 the Superintendent any fact respecting the causes of illness that
may he of importance in enabling hint to determine as to the fitness or otherwise
of the subordinate for contained employment in the jail.

4

(2) The Medical Officers shall examine all candidates for employment.
and all jail Officers who may be sent to him by the Superintendent for that
purpose, and shall certify in writing regarding the physical capacity and state
nt 1i eall h
The Medical Officer shall keep
Maintenance of Journal.—( 1)
a journal in Form No. 3 in which he shall record every visit paid to the jail,
ihe hour at which he entered and left the Jail daily, the portidnf of the jail
or classes of prisoners visited, I h number of sick in hospital an&any matter
which he considers should be brought to the notice of the Superintendent,
especially,(a) any defects in the food, clothing or bedding of prisoners or.
in the cleanliness sanita,tion, water supply or other arrangements of the jail
which the. Medical Officer considers likely to be injuries to health, together with
suggest ions for the remedy of such defects in addition to his report on weekly
inspection on sanitation
- (h) an occurrence of intpoltarlce connected with the hospitals
adsniststration, any marked incredse in the number of inpatients or outpatients
and the apparent causes of the same; and
(c) any recommendations regarding individual prisoners.
(2) This journal shall be sent daily or more often if necessary, to
the Superintendent fo1 the immediate issue of such orders as he irtay see fit to
pasr.
Submission of Returns.—The Medical Officer shall submit punctually
the prescribed returns, and shall furnish any other information fegarding the
medical administration of the jail which the Inspector General may call for.
*5Q
Maintenante f Registers.—The Medical Registers and forms other
than the journal shall be kept under the orders of the Medical Officer who is
responsible for their correctnesS. At the inspection of the Inspector Geueralof
Prisons every register and record connected with the Medical Department of the
jail shall be produced before him.
Note:— For other rutes to the Medical Officer's duties sec the fo1ioving viz., Examination
of -prisoner on admission etc., rules 232 and 233 Examination Article of Food Ruics
348 and 349. Examination of prisoners with reference to Labour Rule 394,
-General duties in regard to hospital m a nagement rule UItt) to 632. General dudS
in regud sanitadon rules 662 to 683.

<!-- page 49 -->

20
*51 . Non-practice allozuance and special pay to Aledical 0fficers. r**Tl1e Tvledical.
Officer employed in a Central Prison slusH he given a non-practice a]lowance
of Rs. 200 per mensem and a special pay of Ra. 60 pin. considering ihe
dang&ous and arduous nature of his duties.

Residential quarters of the Medical Officer.--The Medical Officer shall
reside in the rent free quarters provided by Government for the purpose.
Term, of appointment--Subject to the discretion of the Director of
Health Seavices and the exigencies of public ser\ -ice, the Medic'al Officer
appointed to the Jail shall continue to be in charge of his office for a
period ofthree years, exclusive of any long leave that he may avail himself of.
Duties further &fined.—It shall be the duty of the - Medical Officerto examine all newly admitted 'priscncrs and to record in the
admission registers and history tickets the particulars as regards health, labour
and the like;
to attend to all prisoners who compain or appear to be ill and
have them removed to hospital for examination as each case may require;
to inspect the convalescent gang and any prisoner kept under
observation every morning.
to be responsible that order, cleanliness and discipline are thaintamed in the hospital and its enclosure and that the compounder and attendants
perform their duties properly;
to bring to the notice of the Superintendent any female whom he may suspect to be pregnant;
to bring promptly to the notice of the Superintendint any case
of suspected cholera or other contagious or infectious disease that may appear
amongst the staff or the inmates of the Jail;
to examine the wells and other sources of water supply to bring
to notice any defects with regard to its quantity or quality, to examine all
tanks and vessels daily in which water is stored or conveyed and to send samples
for analysis;
*Rulc 51—Substituted as per G.O. MS. 4J63 Home datàd 15-2-1963.
**Amowit"enlianced vide G.O.(P) 480/89)Fin. dated I-I 1-1989.

ç

4

p

<!-- page 50 -->

21
(Ii) to inspect at least once a week the surroundings of the Jail and
especially the place and the manner in which filth and the like are trenched
or otherwise disposed of, and
(i) to attend to the ventilation, with due regard to the sealon of
the hospital, sleephg wards and work shops!; and to satisfy himself that the
prioners are not unnecessarily exposed to drought or to rain.
755. Local allowance to the Compounder—The Compounder on duty in
the Jail Hospital shall be given a local allowance of Rs. 25* per mensem.

•1

Residential Quarters of the Compounderr—The
Compounder shall
* reside in the quarters provided by Government 1 hr th purpose.
Term of Service of the Compounder.—Subject to the discretion of the
Director of/Health Services and exigencies of public service the Compounder
appointed to the Central Prison shall continue to be in charge of his office
for a period of two years exclusive of any long leave that he may avail
himself of.
Duties of the cornpounder.---The Compounder shall obey the lawful
orders of the Medical Officer in all matters cdtanected with the medical work
oftheJail and of the Superintendent and Jailer in other matters.
(2) His duties shall be to help the Medical Officer in the maintenance
of the health of the staff and prisoners by compounding . and distributing
medicines, weighing prisoners, performing clerical work maintaining order
and discipline in the hospital and by carrying but such other duties-of a like
character as may be imposed on him by the Medical Officer.

The District Medical Officer to visit the Jail.—"The District Medicai
y Officer of the District in which a Central Prison is situated shall visit'that
Jail at least twice a month usually at the time when the weekly i.nspectidn
4
parades
of prisoners are conducted by the Superintendent, see every prisoner .
and hear and enquire into any complaint of sickness:
t60. Conveyance allowance to the District Medical Officer—The District
Medical Officer, shall be given a conveyance allowance of Rs. 10 per visit
subject to sum of Rs. 40 per mensem for his visits to the Central Jails mentioned
in rule 59".
61.. Psychiatric service.—Prisoners requiring Psychiatric Examination
and Treatment shall be given the services of the Psychiatrists.
*c,P (P) 480189/Fin. dated 1-11-1939
tRuic 50 amended as perG. 0. (MS) 225/61/Home dated 174-1961.

<!-- page 51 -->

22
Visit of Psychiatrist.—The Psychiatrist shall visit the Jail at least
once a month and examine and treat the prisoners who require such examination and treatment.
Psychiatrist of the
Who is the Psychiatrist for each Jail.—The
Mental Hospital, Trivandrum shall be the Psychiatrist of the Central Prison,
Trivandruni and the Psychiatrist of the Mental Hospital, Kozhikode shall
be the Psychiatrist of the Central Prison, Cannanore. Till a Psychiatrist
is appointed at or near Trichur the Psychiatrist of the Mental Hospital,
Kozhikode shall function as the Psychiatrist of the Central Prison, Viyyur
also.
'
Allowance to the Ps,ychiatrist.—The Psychiatrist shall be paid a
monthly allowance of Rs. 30 for his visit to each Central Prison.
Cn&pmR VI
SUBORDINATE OFFICERS GENERALLY

Division of staff into two parts—The subordinate establishment of
the Jails Department exclusive of the Medical Branch is divided into two
parts, the upper subordinate and the Warder Establishments.
C'onstitution of the upper subordinate establishment. --The upper .subormate estkblishment shall consist of the Jailer, Deputy Jailer and AssisLant
dailers.
*67. Qualification for appointment to upper subordinate Establishinent.—Person
whether an officer of the Department or not shall be eligible for appoinlment
to the Grade of Jailer Deputy Jailer, or Assistnt Jailer unless he possesses
the general educational qualification prescribed by Government from time
to time. A person appointed to any of the above post should also pass the
Jail Officers Test within the period of his probation unless he has already
passed the test. This amendment shall be deemed to have come into force
with effect from the 11th December 1939. .
63. Liability to serve in a;y jail.—Every subordinate officer shall be
liable to be employed wherever it seems fit to the Inspector General to employ
him. Whenever a Warder is recommended for transfer the names of the
Jails in which lie has previously served shall be stated.

69. Training in drill and muskctry.—(l) Every Subordinate 'Executive
Officer shall undergo a thorough training in squad and company drill and
the use of arms and members of the upper subordinate establishment shall be
able to drill the guard and give instruction in musketry.
Ruie67 Substituted as per G. 0. (Ms) No. 153/7211 -Iome dated 10.10.1972

*

<!-- page 52 -->

23
(2) Ball pdctice shall he held once in alternate months and blank
firing shall be practised once in three months. The results of ball practice
shall be recorded in the Practice Register.

4

confidential personal sheet.—The Superintendent shall maintain
for every subordinate above the rank of Head Warder a confidential personal
sheet in which the entries shall be made in his own hand, half yearly; the
entries shall deal with the officer's physique, character, activity, knowledge
of drill, if required power of command, work generally and fitness for promotion. A copy of the Superintendent's remarks on the jailer, Deputy
Jailer, Assistant Jailers and Technical subordinates shall be submitted confi* dentially not later than the 15th February and 15th July to the lnspectgr
General of Prisons.

Supply of begetablee from Jail gardn to subordinate establishment. - -With
the permission of the Superintendent,, the Jailer, Deputy Jailer, Msita at
Jailers and other Jail subordinates may be allowed a reasonable supply of
vegetables for their own consumption from the Jail garden free of charges
provided that no such permission shall be given unless the entire supply of
vegetables required forjail use is being obtained from theJail garden.
Knowledge of rules.—Evei-y subordinate officer shall make liiutself
fully acquinted with the rules and regulations relating to his office, and no plea of ignorance will be accepted as an excuse for neglect. The rules prescribed by Government regulating the conduct of public officers are applicable
to all subordinate officers.
Duties towards Superior Officers—Every subordinate officer shall
yield prompt and strict obedience to all orders of the superior officers and shall
treat all superior officers at all times with respect.
-

•
•

Not to be absent without perinission.—No subordinate officer shll be
absent during the hours fixed for his attendance without the permission of the
Superintendent or Jailer. Any subordinate officer disabled from the performance of duty by illness shall give or send immediate notice to the Jailer
who shall make such arrangements as may be necessary for the performance
of the duty of the disabled officer.
Dress and Personal appearances .—Ail subordinate officers shall be
clean in person and dress and those for whom a uniform is prescribed shall at
all times wear it while on duty and shall further conform to such regulations
concerning their personal appearance as may be establisbed by authority.
No Officer to smoke or drink in the ,7ail.—No subordinate officer shall
smoke, and drink while on duty or without authority introduce liquor, tobacco.
or any other prohibited articles into the Jail.
-

<!-- page 53 -->

24

77. Officer to receive visitort—No subordinate ofii&r shall receive any
private visitor within the Jail, except with the sanction of the Superintendent.
78. Gonditithis as to residencer—( I) Every subordinate officer of a Jail
for whom residentia.l ren'free quarters are provided shall reside therein.
When free quarters are not provided, the subordinate shall reside
in such quarters as may he approved by the Superintendent.
A subordinate officer shall not except with the written permission
of the Superintendent, allow any person ttUer titan his parents, wife or children,
to reside with him either temporarily or per'iianently, in his quarters on the
Jail premIses.

79.

4'

Prohibition against qaarreliarg-4Ml quarrelling between Jail officers

is stridly pr( , hibited and disagreement between subordinates relative to their
duiics shall be relCrred to the Jailer or the Superintendent. A complaint by
one officer against an equal or superior shall be made to the Superintendent.
Frivolous or fuilse complaints will be severely punished.

80. Officers to 'prevent escapes and introduction of prohibited articles—Every
Jail Officer hahi;
Exert the utmost vigilance. to prevent escape;
Prrven( to the best of his power the introduction into the Jail, and
the giving to any prisoner of any prohibited articles; and
Prevent an)' communication between prisoners and outsiders except
as rntrnutted by Rules.
Under Section 44 of the Travancore-Cochili Prisons Act, 1950 (XVIII
any Jail Officer
of 1950) and 43 of the Prisons Act (Central Act IX of 1894)
may arrest any person conl3uitting in his presence any offence specified in 0
Sections .43 and 42 respectively of the said Acts and refusing to give his name
and address.
81. Prohibition against visiting prisoners.—Except as elsewhere provided,
no subordinate officer shall enter at ward cr cell at night unless accompanied
by another autliorised officer, and then only in cas. of sickness or other
emergency; the Superintendent may, by order in writing relax this rule during
the presence in jail of a epidemic disease.
82. Responsibility. of Warder for charge of gdng.—No warder shall he deemed
to be free of responsibility for the charge of a gang of priscners until he is
relieved by another warder detailed for the duty in the presence and under
the signature made at the time of relief of the Head Warder whose duty it is to
conduct such relief.

<!-- page 54 -->

25
83. Duties of Officer in charge of gang.—Every Officer in charge of a gang
shall Make his prisoners march in file and shall prevent all straggling and
disorderly conduct, the holding of unauthorised communications with each
other or with any unauthorised person or the procuring of prohibited articles.

-

- 84. Care of/cej's.—No subordinate officer entrusted with Jail keys shall
remove them from the Jail, leave them lying about or lend them to any person
on any pretence whatever, but shall when leaving the Jail or going off duty,
deliver them to such officer as may be authorised to receive them. The keys
of wards, cells or outer-gates are not on any account to be delivered to any
prisoner other than a convict warder. -

*

85. Care of Government property— When an officer entrustedwith gthe care
of Goveinment property, such as warrants, cash., slores, machinery, etc., is
transferred, proceeds on leave (other than casual leave) resigns, is suspended
or discharged, he shall make over all property in his care to the officer appointed
F' to relieve hint and tile relieving officer shall compare all articles
i hus wade over with the entries in the prescribed registers and satisfytiniself
that they are correct, and shall then initial ecl-ijcgister in its properplace
in token of having correctly received chatg& of the articles enterc tlreiu.
Until charge is thus taken and the registrsinitiàlied by- tltrelie%'ing oicer,
the officer relieved shall kbe wholly resporible for all e$¼k and defiçncies
in the property. \
1,:--;-3i
All Officers shall, on relief, hand
- 'i-illAcurrent files, accothts and
registers in their charge and obtain the sign tires othe relieving officçs in the
list iiiaintamed by thcn, in toktn of the con t hahcJn o -vei and taking over
of the various records.

fr

8G. Officers to instinct their successors—All officet4it'ihg relieved from
y particular duty or transferred to another part of the Jail, shall point out
to their successors, all matters of special importance connected with their
charge and explain any directions of any superior officer iffecting any particular
prisoner or matter. -

Prisoners to - be treated with good temper—The aim of handling of
prisoners, is correction for rehabilitation. All Jail Officer shall treat prisoners
with good temper, humanity and strict impartiality, and shall listen patiently
and without irritability to any complaint or grievance, while at the same,time
mamtining strict discipline and enforcing observance of the Rules and Regulations. It is important that every complaint made by a prisoner should be
heard with attention, in order that grievances ma y be redressed and that no
cause for discontent may be allowed to remain.
Prohibition against punishing or abusing prisoners—No Jail Officer shall
in any circumstances, punish any prisoner except under the Superintendent's,
order or threaten any prisoner with punishment or use violent, abusive or
insulting language to any prisoner. All conduct intended inerejy to irritate or
annoy any prisoner shall be avoided. Prisoners shall be addressed by their
proper names or numbers.
- 16/3274/95/MC.
. .

<!-- page 55 -->

26
89. Prisoner not to be struck.—No jail Officer shall on any pretext strike
a prisoner except in self-defence or in the repression of disturbance, and
no more force Thail then be used than is absolule]y necessary.
90 * Immediate report of misconduct to be made—No subordinate Officer
shall, either through favour or a mistaken notion of kindness, fail to make an
immediate report to his superior officer of any miscondudt or wiliful disobedience
the Jail Regulations.
-

Familiarity with prisoners forbidden—No jail Officer shall unnecessarily
converse with a prisoner or treat him with familiarity or allow any familiarity *
between a prisoner and any other officer in the jai) nor shall be discuss
matters of discipline, or jaibduties or arrangements with or in the hearing .of
prisoners.
0

Officers not to have dealings with prisoners or their frnds.—No Jail Officer
shall lend money to, borrow money froim or incur any obligation in favour of any other Jail Officer or any prisoner, or correspond with or hold any
intercourse with friends or relatives of any prisoner or have any unauthorised
communication with any prisoner or With any pClsops whatever as to matters
concerning the jail.
-

Officer to receive prisoners' property.—No Jail Officer or other person in
any way connected with the Jail shall receive or use any article belonging
to a personwho either, is or has been, confined in the Jail.
t93A. The Superintendent shall sent to the Chief Probation Superintendent quarterly lists of inmates to he released three months in advance,
requesting 1 to arrange for the after care of the inmates on their release. The
Chief Probation Superintendent after getting pre-release enquiry reports from
the concerned Probation Offibers shall arrange for the after care of the inmatcs
whenever released.".

Intercourse with discharged prisnerc forbidden—No Jail Officer shall
correspond with or hold any intercourse with any discharged prisoner or with
the friends or relatives of such prisoner, or allow any such prisoner friend or
relative, to visit or remain in his quarters except with thg special pennission
of the Superintendent.
Officers not to be interested in Jail contract.—No Jail Officer shall directfr
or indirectly be concerned in any contractor agreement for the supply of any
article for the use of the Jail nor receive, directly or indirectly, any fee, gratuity
present or loan, from any contractor or person tendering for any contract with
the Jail, or from any prisoner, prisoner's friend or any person visiting the Jail.
Rule 93 as per 0.0. (Ms.) 200/69/Home dated 1st July 1969.

<!-- page 56 -->

27
Officers not to e,gage in trade—No Jail Officer shall cithS directly or
indirectly engage in any trade, business or employment other than his legitimate
jail duties.
Keeping of farm stock or cattle.- —No Jail Officer below the rank of
Chief-Warder shall be permitted to keep cattle or other fann stock within the
Jail premises.
Superincndent to decide when prosecution should be instituted.—The Superintendent shall decide whether or not a prosecution shall be instituted in
respect of any offence punishable under Section 55 of the i'ravancore.Cochin
Prisons Act (XVIII of 1950) and section 54 of the Prisons Act; 1894 (Central
Act IX of 1894). Whenever a prosecution is determined on, the Officer
concerned shall be suspended from duty.

-)
4

the following ofienccs, a
99. Offimces to be dealt with judicially.—For
prosecution shall be instituted unless the Inspector_Generalof Prisons otherwise
order, in which case tlw offender shall be punished departmentally:

•

Wilfully or negligently permitting an escape;
•

committing any offence purtishable under sècdon 43 of the
Travancore-Cochin Prisons Act XVIII of 1950 or 42 of the Prisons
Act IX of 1894 (Central Act IX of 1894);
immoral conduct with regard to any prisoner;

-

4. any offence punishable under Chapter IX of the Indian Penal Code.

Acquitted Officers to be refrestated.—A Jail Officer acquitted of charg
by a Criminal Court shall be -reinstated in the service unless the Inspector
General of Prisons for reasons to be recorded in writing, otherwise directs.
Offences ordinarily punishable by dismissal.—The following offences
shall be punished by dismissal unless the previous character of the offender
and the circumstances of the case render a milder punishment sufficient:
U appearing on duty in a state of intoxica4on;
•
- striking a prisoner;
sleeping on duty;
entering or permitting any person to enter the female - enclosure
without proper authority;
committing or conniving at irregularities - in - the supply or
-•-distribution of food; •

<!-- page 57 -->

being concerned, directly or indirectly, in ajaij contract or receiving
a present from a contractor;
having dealings with any prisoner or prisoner's friend;
insubordination towards any superior officer;
any other breach of Prison Rules.
102. Procedure prior to inflicting Punishment.—
(I) In every case where it
is proposed to inflict on a member of the service any punishment in the form
of censure, fine, withholding of increments or promotion including stoppage
at efficiency bar, Jiecovery from pay of the whole or any part of any pecuniary loss caused to Government by negligence or breach of orders and
reduction of pension, he shall be given a reasonable opportunity of making
any representation that he may desire to make and such representation if
any, shall be taken into consideration before the orders imposing the penalty
is passed:

•'

Provided that the requirement of this sub-rule may, for sufficient reasons,
to be recorded in writing, be waived when there is genuine difficulty in
observing them and they can be waived without injustice to the person
concerned.
(2) In every case where it is proposed to inflict on a member of the
service any punishments in the form of reduction to a lower rank in the
seniority list or to a lower post of time-scale or to a lower stage in the times
scale, compulsory retirement, removal from the service and dismissal from
the service the grounds on which it is proposed to take action shall be
reduced to the form of a definite charge or charges, which shall be communicated to the person charged together with a statement of the allegations on
which each charge is based and of any other circumstances, which it is proposed to take into consideration in passing orders on the case. He shall be
required, within a teasonable time to put in a written statement of his defence
and to state whether he desires an oral enquiry or only to be heard in person. *
If he so desires or if the authority concerned so directs an enquiry shall be
held.

Record of punishments inflicted.—Eveiy punishment inflicted on a
Jail Officer shall be recorded in the Jail Officers' misconduct book, and in
the Jail Officers' appointment and history book. Admonition is not a punishment but any formal warning shall be recorded.

Offi€er

to quit the' Jail on termination of appointment__Every subordinate officer or servant suspended, dismissed, discharged or allowed to
resign his appointment, shall be required at once to quit the Jail and the
quarters occupied by him, and shall give up any uniform or other property
of tovernmcnt, entrusted to him.
-

<!-- page 58 -->

29
Caution to officers under suspension.—( 1) When a Government
servant is suspended he may go where he likes but he must leave his address
with the head of his office and also with the officer if, any, holding an inquiry
into his conduct.
(2) He must obey all orders to attend any inquiry into his conduct,
and if he fails to do so, the inquiry may be held in his absence.

*

Re-emplqyinent of dismissed officers—No subordinate officer once
dismissed or discharged from or who has resigned his appointment in the
department, shall be employed again in the jail without the sanction of the
Inspector-General of Prisons to whom all the circumstanc - s shall be r ported.
Frohibitio, against employment of convicted fterson.—No person who
has been convicted and punished with imprisonment shall be employed in
the Jail without the special sanction of the Inspector-General of Prisons.
CHAPTER VII

UNIFORM OF JAIL OFFICERS

Unbrnz of I.G. and Superintendent.—(l)

The Uniform of the

Inspector-General of Prisons shall be(a) CEREMONIAL:

e

Tunic—Khaki serge, military pattern, turn down collar with Silver
Asoka Lion, on the lappets.
Breeches or trousers—Khaki serge
Shirt—khaki.
Collar—khaki fastened with plain gold tie pin.
Tie—dark blue silk.
6. Shoes—brown parade.
Forage c ap_* ("Police •Pattern") embroidered peak one silver
Asoka Lion in floral wreaths and letters "K.J." on either side and'S'
between.
Belt—Sambrown regulation pattern with silver mountings.
Sword—Infantry Officer's pattern with silver hilt.
Whistle—metropolitan with khaki silk cord.
Shoulder Badges—K.S.J. with two stars and Asoka Lion in silver.
Buttons—Silver with State emblem at the centre and "Kerala
- jails" inscribed around.
Socks
Scabbard—brown leathçr with silver mountings.
G. 0. (Rt.) No 2259177/H. dated 27-10-1977.

<!-- page 59 -->

30
t(b) WORKING DRESS:
Khaki shirt with soft collar and dark blue tie fastened with plain gold
tie pin, two breast pocket with flap and button, shoulder straps with badges,
khaki shirts, khaki woollen stockings, brown boots or shoes, sambrown belt,
whistle with cord, forage cap. Bush coats can also be used in place of shirt.
(2) The Unjform of the Superintendent shall be(a)

CEREMONIAL:

Tunic—Khaki serge, military pattern, tuth down collar with
silver stars on the lappets.
Breeches or trousers—khalci serge.
Shirt—khaki
Collar—khaki fastened with plain gold tie pin.
Tie—dark blue silk.
Shoes—brown parade.
7.. Forage cap—"(police pattern)" embroidered peak silver Asoka
Lion in floral wreaths and letters "K.J." on either side and "5"
between.
8.' Belt.—sarnbrown regulation pattern with silver mounthigr
9. Sword—Infantry Officer's pattern with silver hilt.
to. Whistle—metropolitan with khaki silk cord.
Shoulder badges K.S. J. with one Asoka Lion.
Buttons—silver with State emblem of the centre and 'Kerala
Jails" inscribed around.
Socks.
Scabbard—brown leather with silver mountings.

-

I.

-

(b) WORKING DRESS:
Khaki Shirts with soft collar and dark blue tie fastened with plain gold
tie pin, two breast pocket with flap and button, shoulder straps with badges,
khaki shorts or trousers, khaki woollen stockings, brown boots or shoes, sambrown bclt, whistle with cord forgage cap. Bush coats can also be used
in place of shirt. 109. Unforrn to be worn on duty.—Al1 Jail Officers shall, when on duty
always appear in the uniform, prescribed for and supplied to them by
Government.
* Note :—Busb coats may also be used for working dress in place of shirts.
-.

-

<!-- page 60 -->

81
110.

Uniform of Jai1er.—TheUniform of the Jailer shall be--

(a) CEREMONIAL:

*

Tunic—Khaki drill military pattern, Pint down collar.
Trousers—Khaki drill.
Shirt—Khaki, collar khaki fastened with plain gold tie pin.
Tie—Dark blue silk.
- Shoes—Brown parade.
6. Belt—Sambrown with brass mountings (I slitig only)
7. Whistle—Metropolitan with khaki silk cord.
B. Shoulder badge—K.S.J. with two silver stars.
• 9. Forage cap—"(police pattern)" and silver embroidered Moka
Lion in front and letters K.S.J.
Buttons—Silver with State emblem at the centre and "Kerala.
Jails" inscribed around.
Socks.
*(b) WORKING DRESS:

*

-

Forage cap "(police pattern)"
Khaki trousers or sliort.
Khaki shirt, open neck, half arm with pockets and shoulder scraps.
Brown Shoes.
Sambrown belt without frog.
Metropolitan w1stle with khaki silk cord and K.S.J. shoulder badge
(as in ceremonial dress)
Badges as per ceremonial wear.
Ill . Uniform of Deputy Jailers and Assistant Jailers.—Deputy jailers and
Assistant Jailers shall wear uniform simi!ac to the Jailer with the following
exceptions:-

DEPUTT .74JLERS:
Tunic—Closed double collar, shoulder badge K.S.J. with one star
Sambrown belt with brass fittings (without frog).
•

ASSISTANT JAILERS:
•

Tunic—Close double collar, shoulder badge K.S.J. with silver State
emblem with wreaths.
Sambrown Belt with brass fittings (without frog)
'Bush coals may also be used working dress in place of sbirt.

<!-- page 61 -->

32
112. Unjfonn of C'hief' Warder.—The Uniform of the Chief Warder shall
be as follows:• Tunic—Kliaid drill, military pattern without side pockets.
Trousers—Khaki drill, shorts for ordinary wear.
Boots—Black.
Putties—Khaki woollen.
Turban—Brown, with gold lace I .3 cm. broad or Pith hat.
Belt—Brown leather waist belt waist hook to be worn to support •
the belt.
*
Shoulder Badge—K.S.J. in gilt and one gilt five points star on the
shoulder straps.
I

113. Uniform of Head Warders.—Head Warders shall wear khaki shirt
with open front havipg brass buttons 7.6cm. apart down front, 2 breast pocket
with brass buttons and pointed laps. The shirt shall be made loose enough
at the back to allow of free movement. *CcThey shall wear silk cloth waist
belt (red colour) with buckles having the words". "Kerala State Jails
Department inscribed on them and black leather Boots".

f 114. Unilbrm of Warders.—Warders shall wear a khaki open collar
shirt having 3 brass buttons and 2 press buttons apart down the front, two
breast pockets with brass buttons and pointed laps shoulder straps of khaki
to be fastened with small buttons and to have the Jail badge. The blouse will
he made loose enough at the back to allow of free movement. They will
wear khaki shorts. The putties shall be khaki woollen. They will wear felt
hat with blue ribbon around and Asoka State Emblem (brass) in front. They
will wear a brown leather waist belt.
115. Warden to carry whistle.—Every Head Warder and Warder shall
carry a brass whistle with chain and be provided with water proof cap with
hood and sandals.
** "116. Female Warders shall wear white Sarees with Green Border
and White Blouse. They shall wear Badges of brass or white metal fixed on
the left side of their breast. They shall also be provided with sandals".
117. Chief and Head Warder to be provided with cane and Warden With batons
or lathies.—( I) Chief Warder and Head Warders shall be provided with a cane
of approved quality and size and the Warders with wooden baton or male
bamboo not more than 76.2 cm. long not wieghing more than 622 gr.
•GO. (MS) 156/79 dated 19-11-1977.
fist Sentence of ruie 114 substituted as per G. 0. (P) 170167/Home dated 1-9-1967.
**Su bstituted as per [0.0. (MS) No. 154/75/Home dated 27-12-19751.

<!-- page 62 -->

33
(2) A register of articles of udiform shall be maintained by the Chief
Warder in Form No. 22.

Supply of Extra Suits.—The Chief Warder, Head Warders and
Warders will be required if the Superintendent considers it necessary to supply
themselves with extra suit of uniform at their own cost. Warders shall be
requirdd to supply themselves with hanians or jerseys at their own expenses
and always to wear them under their uniform.
* J iRA. Every Warder attending night duty in Jails shall be provided
with one grass mat of superior quality at Government cost to take rest at the
time when he is relieved of hiis duties during the night But the number of
mats so supplied shall be limited to the number of Warders on night duty at
each shift. The mats supplied will be treated as Jail property and may be
replaced a.fter a year or when worn out whichever is later. -

Responsi.biiiy for UnfOTnZ supplied by Govemne
,nt.—Oflicers supplied
with uniform at Government cost are prohibited from selling the same and
any unauthorised attempt to dispose of it will render the offender liable to
prosecution. All suits and turbrts shall be clearly and permanently stamped
with the date of issue and this date shall he reRewed when necessary. At
every kit inspection Warders and Head Warders shall produce the water
proof caps. If any article is lost or rendered unfit for use before the date
fixed for issue of a new supply it shall be replaced at the Officer's expense.
Arms to be carried on dzqy.—Every member of the Warder establishment shall, when on duty inside the Jail carry a baton or a male bamboo
lathi not more than 76.2 cm. long.
Articles of ut4ftrm.—The following articles of uniform are to'be
provided at Government cost:A. INSPECTOk GENERAL OF PRISONS:

V-0
S.

One complete set of the
ceremonial uniform
Khaki suit (working dress)
Bluetie
Khaki woollen stockings
Brown Boots or shoes
Forage Cap
Belt
Whistle and badges and 12
Buttons
Whistle cord
Water-proof coat
Pig sticker topee
Woollen socks
Bush coat

On appointment and till
worn Out
2 every year4
I every year
2 every year
2 pairs every-year
I every two years
1 every 5 years
Till worn out.
I every 2 years
1 every 5 years
1 every year
pair every year
I every year in lieu of a shirt

RuIe IIBA inserted as per GD. (MS) 265J59 Home dated 5-8-1975.

16/3274/95/MC. - -

<!-- page 63 -->

34
B. SUPERINTENDENT:

2.
8.

9
10
11
12

One complete set of the
ceremonial uniform
Khaki suit (working dress)
Blue tie
Khaki Woollen stockings
Brown boots or shoes
Forage cap
Belt
Whistle and badges and 12
Buttons
Whistle cord
Water-proof coat
Woollen socks
Bush coat

On appointment and till
worn out.
2 every year
1 every year
2 every year
2 pairs every year
1 every year
I every 5 years
Till worn out.

k

'I
0

1 every 2 years
1 every 5 years
1 pair every year
1 every year in lieu of a shirt.

C. JAILER, DEPUTY JAILER AND ASSISTANT JAILER:
14

2
3
4
5
6
7
8
9
10
ii

One complete set of the
ceremonial uniform
Khaki drill shorts or
trousers
Khaki shirt' (working dress)
Forage cap (police pattern)
Brown shpes
Socks
Stockings
Badges button and whistle
Belt
Rain Coa.t
Bush coat

On appointment and till
worn out.
12 every year
12 every year
1 every year
2 pairs every year.
I pair every year.
2 pairs every year
Till worn out
Till wor* out
I cvery 5 years
1 every year in lieu of I shirt

D. CHIEF WARDER:
Jacket
Trousers or shorts
Boots
Socks
Putties

2 every year
2 every year
2 pairs every year
1 pair every year
1 pair every year.

I
a

<!-- page 64 -->

3S

-

4

,

Till worn Out.
I every year.
Till worn out.
Till worn out.
I every 5 years.
Tillwornout.
2 tins everyyear.
2 tins every year.

Belt
Turban or ht
Whistle
Button and badge•
Rain coat
(Jane
Metalpolish
Leather polish

HEAD WARDERS:

E.

2 every year.
2 every year.
2 pairs every year.
I pair every year.
2 pairs every year.
2 pairs every year.

Khaki Shirt
Khaki shorts
Half putties
Boots
4 (a). Hose Thp'
4 (b). S ocks**

"5. Silk cloth waist belt red colour The cloth portion to be renecd
with buckles (white metals) having every year and the buckles to be
the words. "Kerala State Jail renewed only when it is worn out"
Department" inscribed on them. Buttons, whistle, chain, badge and
cane.

-

V

*
•

Ghevrons
Rain coat
9. Felt Hat
10. Metalpolish
11. Leather polish

4

F.

do;
I set every 2 years

- 1 set every 5 years.
-

I every year
2 tins every yeay-2 tins every yeai.

WARDERS:
Open wllar shirts
Khaki shorts

4

2 ew,ry year.
2 every year.

G.O. (MS) 42/76 dated 30th March, 1976 of Home (B) Department. •

Amended with effect from 1-4-1976 as per G. 0. (MS) 42176/Home dated 30.34976.

<!-- page 65 -->

36
Half patties
Boots (Anintunition)
4 (a). Hose Top*
4(b). Socks*
Felt'h'at
Belt, whistle, chain, button,
badges and numbers
Ghevrons
Baton or lathi
Rain coat
Metalpolish
Leather polish

-.

2 pairs every ycar *
1 pair every year.
2 pairs every year.
do.
1 every year.

Till worn out.
1 set every year.
Till worn out.
1 every 5 years.
2 tins eVery year.
2 tins every year.

*

./
G. FEMALE WARDERS:
I.

White cloth of gpod quality for
8 blouses.
White sarees with 6 G.m. green
border.
White cloth for under garthents.
Brass or white metal badge with
leteers (K.S.J.)
Sahdls.

7 mtrs. per year.
4 Nos. per year.
B mtrs. per year.
Till worn out.
2 pairs Svery year.

122. Surrender of unj/br;n.—Every article of uniform supplied to a Jail
Officer at Government cpst should be immediately delivered up when lie or
she ceases to belong to the Jail estahlithment or has been, suspended. If
such artides have in the opinion of the authorities been improperly used or
damaged the cost of the article shall be made good from the pay or allowance
due to the officer.

121 Surrender of unfirrn of Jail Officer quitting station on lecwe.—A Jail
Officer who quits the station on leave for more than- one mohth shall surrender
the articles of uniform before he enters on such leave.
124. Jail Officers to be smartly dressed.—The Superintendent shall always
see that the Jail Officers arc smartly dressed and that their uniform is kept
clean and property put on.

•

with effect from 1.4-1976 as per G. 0. (MS) No. 43/76 Home. dated 30th
March 1976.
'tG. 0. (MS) No. 30/77 dated 14.3.1977 Inserted as per G. 0. (MS) No. 154/75 Home
datedd.27.12$985.

4

<!-- page 66 -->

37
Unjforrn to be looked upon as badge of service—The Superintendent
will impress upon the staff that they, should look upon their uniform as the
badge of thcii- service and not as a penal dressto be thrown aside the moment
the duty• is over.

CHAPTER VIII
p

SECURITY DEPOSITS

Security of executive Officers and Clerks--Every jailer, Dputy Jailer,
Assistant jailer or Clerk who is appointed either permanently or on probation
or to act for a period of more than 6 months shall furnish security in the following
amounts:—
ftc. 300
300
100

jailer—Permanent, probationary or acting
Deputy jailers--Permanent, probationary or acting
Assistant Jailers and Clerks—Probationary or acting
Time Assistjmpt Jailer or Clerk working as Accountant
and Cashier---Perrnanent, probationary or acting

-500

Assistant jailer or Clerk working as Store-keepth' in Jail
Manufactory—Permanent, probationary or acting

500

- 127. Security of Technical Officers.—The manufactqry and agricultural
employees mentioned below shall be required to ftmrnish the following amounts
as securitydeposits:_r_
£5.

Weaving Instructor, Central Prison, Trivandrum
Industrial Instructor, Central Prison, Virur
Weaving Foreman, Gannanore Central Prison
Boot Foreman, Central Prison, Trivandrum
Carpentry Instructor
Tailoring Instructor
.
Blacksmithy Instructor
.
Agricultural Demontrator

-

200
200
200
100
100
100
100
100

128. Superintendents' responsibility in other cases.—The Superintendent
shall be responsible for bringing to the notice of the Inspector General any
other cases, in which he considers that security should be taken, for consideration
and determination of the amount as well a the month1r instalments, if
any to be fiked.
.
-

<!-- page 67 -->

RE
'WJ 29. Method of depositing securiy.—Ordinarily Government servants
who are required to furnish security should deposit the whole amount of
security within one month after the date of appointment and no salary is to be
passed to a Government servant i.ntil he has furnished the prescribed
security. In the case of securities of its. 5Q0 or less, however,
they may be allowed at the discretion of the head of the department, the
option of binding themselves by two responsible sureties for the whole amount
and agreeing to deposit the same by monthly deductions at a fixed rate not
exceeding a moiety of their pay, provided, however that such monthly deductions shall not extend over a period exceeding two years. As an alternative,
the following procedure may be adopted:-

(i) The officer may give a fidelity bond of an insurance company
approved by Government for the full amount of the required security guaranteeing Govermnent against losses through dishonesty, negligence or disregard
of rules.

*

a.

(ii) Deduction will then be made at the rate of 10 per cent of the
officer's pay and the fidelity bond will he cancelled only after the full amount
of the security bond has been deposited in cash.

Record of deductions from sdlary.—The deductions made under the
last preceding rule shall he recorded in a special columu of the acquittance
roll.
Investments of deposits.—.An Officer reqdired to furnish security
shall invest the amount of such security in the nearest Government Savings
Bank pledging the amount to the Superintendeut as required by the provisions
of the Travancore Financial and Account Code.
Post Office Five Tear Gas/i Certificates.—Post Office five year cash
certificates may be accepted at their present, i.e., surrender value, provided
that the certificates are formally transferred to the pledgee with the sanction
of the Head Post Master concerned in accordance with paragraph 5, Section
VII of the Post and Telegraph Guide.
*Jsiote l. Fidelity bonds with approved firms may be accepted in lieu of personal sureties
and not in lieu of cash or Government securities subject to the form of the
bond in individual cases beingS accepted by heads of departments in consultation with the Law Officers when necessary.
2. Officers accepting fidelity bonds as security should take care to see that they
are kept alive.

-v

<!-- page 68 -->

39
133. Deposits receipt of Banks—Deposit receipt of the State Bank of India
and of Central Co-operative Banks approved by the Registrar of Co-operative
Societies may he accepted, provided:
that the deposit is made n the name of the Government Officer
who is authorised to receive such deposits, or that the Banks certify on the
deposit receipt, if it is in the name of the pledger, that the deposit can be
withdrawn only on the demand or with the santion of the officer to whom
it is pledged; and
that the subordinates agree in writing to undertake any risks
involved in the investment.
notes
134. Gustoqj' of Promissory .iVotes.—Government promissory
deposited as security shall be lodged for safe custody with the Reserve Bank
of India in accordance with the rules in Chapter VIII of the Government
Securities ManuaL

Custody of pass books and b6nds.'—'A11 security pass books hall be kept in
the personal custody of the Superintendent to whom they are pledged. The
same rule applies also to the security agreement or bonds. 135. Annual count and check of sectirities by Superintendents.—Al1 securities
received shall be counted and checked by the Superintendent periodically at
least once a year.
In the case of securities lodged with the Reserve Bank of India the
Superintendent will watch for the annual list published by the Rese?ve Bank of
India of the notes in its custody and bring to its notice any omission or
error in which he is concerned.
"p-

136. Execution of Securiy Qond.—Officers furnishing security shall
execute security bond as required by the ruics of the Financial and Account
Code for the time being in force.

Submission of Statement regarding Securityc—The Superintendent shall
maintain a register of security deposited by each officer in Account Form
No. 188 and, shall submit to the Inspector General an extact of it in Form
No. 188 not later than the 20th April in each year.
ChAPTER

IX

THE JAILER

General duties of Jailer.—The Jailer is the Chief Executive Officer
of the jail and is immediately subordinate to the Superintendent. He is
generally responsible for the observance of all prescribed rules and orders
and for the supervision of the subordinate staffi

<!-- page 69 -->

40
Maintenance of discipliner—The Jailer's firt duty is the maintenance
of discipline among prisoners and subordinates. For this pw'pose he must
be always pfesent at the Jail during the day exceptwhcn lie leaves it, for
his meals, to attend a Court of Justice, or on permission from the Superintendent.
jailer to be present in absence of Deputy jailer—The Jailer and Deuty
Jailer shall not be absent from the Jail at the same time during the day.
The hours for meals should be so arranged that either the one or the other is
present at the Jail.
Daily inspection.—The Jailer shall visit every part of the Jail 4aily
and shall see avery prisoner at least once in every 24 hours.

•

- 142. Attention of person ofprisoners.-'—The Jailer shall see that prisoners
are clean in their person and cloths, that they have the authorised amount of
clothing andbedding and nomore, and that those who are liable to be fettered
fettered.
I
are securely

Search of prisoners—He shall at uncertain times, but at least once
a week cause every prisoner, and all clothing, bedding, workshops, wards
and cclis to be thorOughly searched.
Labour of prisoners—He shall be responsible for the execution of
all orders regarding the labour of pris9ners, shall assign to each prisoner
his work and see that the prescribed tasks are performed.
Supply offood—He shall supervise the cultivation of the garden
and be responsible for the adequacy of the supply of vegetables. He shall
likewise supervise the jail farm and all the other outside operations.
He is,
jointly with the Medical Officer, responsible for the proper preparation and
distribution of the food..
Supei-vision of guard—He shall supervise the working of the Warder
Guard. At least once a week, at uncertain times, he shall visit the jail
after 9 p.m., and satis' himeIf that the, standing guard is present, the sentries
posted and on the alert, and that the rounds are being properly maintained.
Enfordement of terms of warrants.—He shall h& responsible for the
the custody of all warrants and for the strict enforcement of their terms and
that no prisoner is on any account released before his time or kept in jail
beyond the termination of his sentence.
Checks of warrants and property—The Jailer shall, once a year usually
in December, go through all the warrants and valuable property in his
possession, compare them with the registers and satisfy himself that they are

-.

't

<!-- page 70 -->

41
coyrect. He shall enter a certificate to that effect in his repoit book and
a copy of it shall be submitted to the Inspector Geüeral of Prisoners by the
15th January next.
149. Supervision of Jail Office.—.Thouglt the jailer's main duties relate
to the direct control of prisoners and staff, lie Thail also exercise general
supervision of the Jail Office.
150. Maintenance of report booic.—(l)
book in which he shall duly record:-

,

The Jailer shall keep a report

(a) the hour of unlocking and locking and by what officers they were
performed;
(h) the number of prisoners admitted, discharéed and locked up;
all reports made against subordinates and prisbners, the offence
charged, the time of its occurrence and other circumstances
connected with it;
all cases in which lie may have found iUnecessary to use restraint
to any prisoner;
(d) how far he has omitted any of the duties required by these
Rules• and the reason thereof;
the absence of any subordinate officer from the duty and requests
for leave of absence;
request for sanction of unusual expenditure; request for the employment of prisners in any special manner;

4.

(i) any representations or recommendations he may deem proper to
make;
(j) any unusual occurrence or matter ofthipqrtance;

*

(k) any matter on which he may require orders.
(2) Each day's report shall be dated and a consecutive serial
number running through the calendar year shall be given to the subjects

dealt with.

151. Superintendent to peruse report book.—The jailers report book shall
be laid daily and ofl'tener if necessary, before the Superintendent for his
perusal and the issue of such orders as may he necessary. If the Superintendent has no remarks to make or orders to give, he shall append in
initials with the date.
16/3274/95/MC.

<!-- page 71 -->

42
152. Execution of Medical Officer's Orders:---The Jailer shall carry out forthwith emergent written orders of the Medical Officer regarding the sick in
hospital or regarding sanitary arrangements entering all such orders and the
action taken thereon in his report book for the information of the
Superintendent.
*155. Holiday to the Jailer,—The Jailer may be allowed a weekly
holiday on every Sunday.
CHAPTER X

THE DEPUTY JAILEI

General duties of Deputy ,Jailer.—The Deputy Jailer is the Jailer's
immediate subordinate and assistant, whose duty it is to take his place
whenever he is absent and to undertake whatever portions of the Jailer's
duties are delegated to him under proper authority and shall make an entry
of the petformance of his duties in his report book which he shall maintein
in form similar to that of the Jailer (Form No.4) and shall submit if daily to
the Superintendent.
Deputy Jailer to Officiate ffir jailer.—'On every alternate Sunday,
and oil other occasions when the Jailer through illness or other cause is
absent the Deputy Jailer shall officiate for him keeping the report book
for the day and performing allother prescribed duties. On every occasion
on which the Deputy Jailer officiates for the Jailer he shall possess all
the powers and responsibilities of that officer.
Itupection of guard.—The Deputy Jailer .shall visit the guard at
night at least once week, in the manner provided in Rule 146.
Duties in detail.—The following duties -appertain to the Deputy
Jailer:The admission and search of newly received . prisoners, the
removal of private clothing and issue of Jail clothing and bedding;
the correct marlóhg of neck tickets and the placing of such prisoners in quarantine;
,
The custody of prisoners' private clothing;
The custody of the Jail clothing store, the issue of fresh clothing
and maintenance of the clothing registers;
The examination, weighment, and storing of all grain and other
rations purchase;
The supervision of the cleaning of grain, vegetables and other
articles, of diet;
* A ncnded as per G. 0. Ms. 591701Rome. dated 5-3-1970.

4.

<!-- page 72 -->

43
The wthghinent and issue of rations;
The maintenance of the ration accounts and ration register5
in the prescribed forms;
The Supervision of punishnient diets.

Delegation to Deputy Jailer of Jailer's duties.--In addition to the
duties specified in Rule 157, the Superintendent may; byan order to be
recorded in the Jail order book allot to the Deputy jailer any specified portions
of the jailer's duties other than those referred to in Rules 138, 139, 140,141,
147 and 150. If for instance the Deputy jailor is better fitted than the
Jailer for the Supervision of the garden or farm (Rules 689 to 703) that duty
• may be entrusted to him.
Joint respousibility with Jailer—The Deputy Jailer shall share the
- Jailer's responsibility for the carrying outof Rule (138) add for the mamtenance
of discipline (Rule 139). He shall not be absent from his quarters at
night without the written permission of the Superintendent. /

Deputy Jailer to check valuable property in his possession once a 5/AT.—
The Deputy Jailer shall once a year usually in January go through all the
valuable property in his possession, compare them with the registers, and
satisfy himself that they are coriect. He shall furnish a certificate to the
Superintendent to this effect and a copy of it shall be submitted to the
Inspector General of Prisons by the 15th February.
t160A. The Deputy Jailer may be allowed a weekly holiday on any
one of the week aays each week as fixed by the Superintendent.

CUAPThR XI

*

ASSISTANT JAILERS

Appointment of Assistant Jailer.—There shall be such number and
grade of Assistant Jailers appointed to each of the Central Prisons as the
Government may, from time to tinle t direct.
Duties of Assistant Jailers.—Thi Superintendent shall, by -order
to be recorded in the Jail order book lay down what Officer shall undertake
the work of the Head Clerk, the Remission Clerk etc.
Relation of Assistant Jaiiers to Jailer.—The Assistant Jailers shall be
executive assistants and shall oeeupy the same relation to the jailçr as
the Deputy jailer does.
Rule 160A inserted as pdrG. 0. Ms. ,9/70/Hom edated 5-2-1970.

<!-- page 73 -->

44
Executive work and drill.—E very Assistant Jailer shall be liable to be
required to undertakc executive functions and shall learn the drill:
Senior most Assistant Jailer when to function as Deputy Jailer.—JS there
is no Deputy Jailor in a Jail the senior most Assistant Jailer shall function as
Deputy Jailer.

Cs-rAPPER

xir

THE WARDER ESTABLISHMENT

*

Classification of Warders.—There shall be two classes of Warden,
viz., Male Warders and Female Warden.

çovernment to fix permanent strength.—The permanent strength of the
warder establishment in each Jail shall be determined from time to time by
the Government in accordance with ordinary requirements.
68. Power to sanction trnporary addition.—The
Inspector General of
Prisons may sanction the entertainment of such temporary establishment
in addition to the permanent establishment provided for in the last preceding
Rule as may, at any time, be urgently necessary, provided that all temporary
establishments sanctioned otherwise than in accordance with the next following rule shall be so sanctioned subject to the approval of Government and
that no such establishment shall be sanctioned in any case in which previous
reference to Government can without risk or inconvenience be made.
169. 14'hen Inspector-General may sanction temporary establishment—
The
Inspector General may without reibrence to Government, sanction the
temporary entertainment of additional establishment in the following special '7
cases where the ordinary Jail establishment is insufficient to supply the *
necessary guards.
A staff not exceeding one Head Warder and three Warden to
guard a prisoner under sentence of death provided that when there is more
than one such prisoner in the Jail at the same time one extra Head Warder
shall suffice for all;
A sSff of one more Warder, as may be necessary, to guard any
lunatic, Civil or Criminal, or other persons required to be kept under
observation or specially guarded,
A staff not exceeding one Head Warder and three warders in
all to guard a prisoner or prisoners removed to segregation sheds outside
the Jail.

<!-- page 74 -->

,1

5

When Superintendent may sanction temporary establishment.—Where
(1)
the Superintendent coitsideis that itis necessary for any reason to entertain
any riiuitber of warders in excess of the sanctioned scale and the matters so
urgent and unavoidable that the previous 1 sanction of the Inspector General
of Prisons cannot be obtaiDed, lie may subject to iinitiediate reference to the
Inspector General of Prisons entertain such a number of temporary ordinan
grade warders as may be necessary.
(2) The Superintendent ma.vtubject to ratification by the inspector
General of Prisons, appoint in emergent cases, kniale warders, on daily wages
at such rate as the Govcrumefit may from tithe to lime specify in this behalf.

Division of warder establishment—The Male Warder establishment is
divided into three classes namely Chief Warder, Head Warders and Warderss
172. - Physical qualification of Wan-lets--The minimum height for Warders
shall be 1.651 metres and the minimum girth of chest 0.813 nt with
an expansion of 5.1 cm. but men of better physique should; ifpossible, be
obtained.

Duties of the Chief Warder.—(l) The Chief Warder Subject to the
general control of the Jailer, is th head of the Warder establihnient and
responsible for its work and for the due carrying out of all Rules telating to
it and to the guarding of the Jail.

'

(2) He shall assist the Jailer at unlocking and lock up. He shall
visit the guards ajtd eitfles frequently by day and at least twice a week at
night, and shall make an entry of the hours of these visits and of any,
irregularities he may discover in his report book which he shall maintain
in form sin il?r to that of the Jailer (Form No. 4) and shall submit it daily
to the Superintendent. H e shall keep the attcrdance duty and other rosters
and registers of the Warder establishment. He shall perform such other
duties as the Superintendent inay by order to be recorded in the Jail crder
book assign to him.

His ;crponsibilities, to the charge of arms etc—The Cinef Warder
shall have charge - of the whole 'if the anits, ammuniron, uniform and equipment of every description of the Warder estabhi,hment and pf the accounts
relating thereto. He shall supervise the drill and practice in musketry of
the melt, the attendance of the standing guard, the mounting of sentries,
relief, etc. He shall be responsible for the smartness and cleanliness of the
Warders and for their being at all tinith properly dressed. He shall also
perform the duties provided in clause (2) of Rule 236.
AssLn,ncnt of duty to Wa;ders.—Every, 'Warder shall havq a particular duty assigned to hint by the Superiittndent, Jailer cr Chief Warder
such as the charge of a particular ward or set of wards, or a particular workshop or set of workshops or of a particular gang - of prisons inside or outside
the Jail.

<!-- page 75 -->

46
Note :-----Jn this and the following rules warder includes Head Warder.
176. Summary of dutiei or Wardcn—IIt is

(he duty of all Warders,-

ça) to see that all convicts sentrnced to labour in their charges ar'e
steadily at work, andto report to higher authority all cases of i cli eness,s hort
work, or breaches of Jail Rules;
(h) to preent all unnecessary talking, laughing, siging, playing,
quarlling and oth.r unseen!)' behaviour .nd to report the offender;
to see that the prisoners keep ordcr in moving about and do not
loiter about the jail;
to see that no prosier leaves his own enclosure or conirnuritcates in any way with any prisoner in a different enclosure, or with any
pers1}n. outside the jail;
to abstain froni all Iàiniharities and unnecessaiy communications
with prisoners;
).
to see that there is no dirt or litter any part of the Jail of which
hey are in charge and thai the drains are kept properly clean;
torce to the cleanliness of the persons and clothes of the prisoners
in their gangs, that the prisoners bath as often and at such hours as may
be ordered and that the bedding and clothing are well aired according to order
(ii) to bring at once to (he notice of the jailer any signs of sickness
or any prisoner complaining of sickness;
(i) to prevent any breaking up of the gang of the prisoners entrusted !
to their special charge, exctpt only when necessary, to make over to a
convict officer - any prisoner desiring to go to . the laterine and to see that
he is not too long away from his work and is not permitted to go to any
place hidden, from view whence he may effect his escape, to report any
prisoner urinating in or otherivise befouling any drain or any part, of the Jail
not set apart for the purpose;
(j) to report . any case or wilful . injury to clothing or materials for
work or other Government property;
(1<) to prepare the prisoner for morning and evening muster by the
Jailer, to report at once to that officer any • prisoner who may re absent to
see that each prisoner comes to his proper place in propeç. order and behaves
well and keeps silent during meals;

-

<!-- page 76 -->

4.7

0)

to examine the wards, cells, bedding and clothing directly the'
prisoners have turned out, and to report at once any prohibited articles
found;
.

I

(m) to see that the cooks supply each prisoner with a prot the cooks
of food, and that no food is secreted by the prisoners, to report the co iks.
whenever they neglect their work.

'

Duty of warder,c on relief—No warder shall, in any circumstances,
leave his post till properly relieved, and his responsibility shall continue till
' so relieved provided that he may leave his beat to prevent or to assist in subduing a disturbance taking place within his sight when he is on main wall
patrol duty, or when he is in charge of prisoners, if he can do so without
serious risk to the safe custody of those prisoners. If the warder concerned
fails to do all in his power to prevent an escape or to assist in subduing a dis-:
turbance taking place within 1115 sight it rests with him to show that the' circunstances were ed' exceptional as to justify his abstaining from preventing
such an escape or refusing to assist in subduing such a disturbance. - Awarder
relieved by another warder shall explain to his successor his duties and any
special orders that may have been given to him by his superior officers. The
relieving officer shall satisfy liiiriself that the property or number of prisoners
made over to him is correct.

-4.

Duty of warders in chage of work slzed.—,-Warders in charge of work
sheds shall see that all todls and prqperty kept in them are carefitlly put away
or stored on cessation of labour that no ropes, bamboos, ladders or other thing
likely to- facilitate escape, are left: about.
Duty to disclose relations witfi pri.one;s.—If any warder has relation
or connections among she prisoners, or has had any pecuniary dealings are
%Y close acquaintance with any of them, it is his duty to, informthe Superin* tendent or jailS of the fact.
Award of good conduct stripes and rewards—Head Warders and
Warders will be eligible for good conduct stripes and rewards under the
following conditions viz.-

Good conduct stripes will be granted either for conspcuotuly ,
good service in, particular cases for uninterrupted good conduct;
The first category will include cases, in which escapes are prevented by special intelligences or alertness, or in which jail ofences of a
serious itature are detected. Not more than one such stripe shall We awarded
for each such service and the award shall be made by the inspector-General
of Prisons;

<!-- page 77 -->

(c) Uninterrupted good conduct will entitle a Warder or a Head
Warder to good conduct stripes on th following scales:For two years of uninterrupted good conduct

i stripe

For every two further ycars of uninterrupted good
conduct

1 stripe

ProvIded that not more than three stripes shall be worn. The s&ipes
will b of red or white cloth and will be worn, on the left upper arm.
(d) Good conduct allowances,To a warder or head warder who has earned three good conduct stripes
under the last preceding'elausc, a good conduct allowance of one rupee per
mensem shill be granted with the sanction ol the Inspeetoi-Gcnei'al of
Prisons which should be duly obtained, and he shall with the like sanction
receive an additional allowance of Rs. 10 (ten)* per mensem when six stripes have been secured.
**(e ) Interruptions of good conduct are of two,classes, namely, first
the accumulation of two black marks or punishment by fine more than once
within twelve months, second, withholding of increments or promotion or
recovery from 'pay or reduction to a lower rank. Each interruption of good
conduct of the firt class shall involve the loss of one stripe viz., the one last
earned, while each interruption of good conduct of the second class shall
involve loss of two stripes, viz., those last earned. If the officer possesses
less than thfee stripes, all stripes will be lost. The lost of good conduct stripes
under this clause will not debar an officer from future award of good conduct
stripes under the conditions laid down in clauses (a) to (c) (1) As soon as the number of good conduct stripes is reduced below • six and three respectively, the second, and first good conlnct allowance,
respectively shall be withdrawn.
Good-conduct allowance shall be treated as personal allowances
not counting for person and will he passed for periods of duty or of absence
on previlege leave, but not for other periods of leave.
The grant and withdrawal of good conduct stripes and rewards
all be recorded in the Jail Officers service book.
* G. 0. (MS) 36/91 Homc dated 27-2-1991.

** Rule 110(e) Ameaded as per G.O. (MS) 1 75/68J1-io,nc dated 31-5-1968.

-

<!-- page 78 -->

49
CHAPTER XIII
THE GATE-KEEPER
+181. A Gate-keeper to be on duty.—( 1) In every Jil, a literate Head
Warder shall be constantly on duty at the main gate between the hours of
opening the Jail in the morning and closing it at night, his place being taken
during temporary absence for meals, etc., by either the Chief Warder or another
Head Warder. The Gate-keeper will be under the general control of the
Jailer.
(2) Record of re!iefc.—At every relief of a Gate-keeper, a note of the
S hour of such relief.shall be recorded in Register No. 26 and signed by both
the relieved and relieving officers.
182. Persons allowed to enter and leave the Jail.—(1) The gate-keeper
shall admit or pass out of the Jail as the case may be
The Ministers, all official and Non-official visitors, Police
Officers and Officers of the Public Works Department on duty;
Officers of the Jail going on, or coming off duty inside; and
Prisoners duly authorised to enter and leave.
(2) With the exception of the persohs mentioned in sub-rule(l) no
person shall be permitted to enter or leave the Jail, unless under a written
order from or when accompanied by the Superintendent, Inspectbr-General
of Prisons, Minister or Chief Secretary to Government.

(S) A list of the official and non-official visitors entitled to admission
shall be posted between the gates.
'7

-' .

o

-

183. Power to search such persons.—( I) All Official and Non-official
visitors and casual visitors admitted with or under the order of the Superintendent, respectable merchants, pleaders and the superior subordinates of
other Departmenth visiting the Jail on business or on duty and Jail Officers
of the rank of Head Warder and aboveç shall ordinarily be exempt from
being searched:
Xote:— I. A printed copy of these Rules shul be posted in uie main gate way of the Jail
close to the gate-keepers desk.

f 2. For the purpose of these Rules in the officer in charge of the night guard is to
be considered a gate-keeper during the absence of that officer at night.

t- This rule must be worked with circumsp&tion so as not to offend the feelings
of officers- and others.

16132741951MG.

<!-- page 79 -->

50
Should the gate-keeper have reason to suspect that any persofl,
ordinarily exempted .from search is introducing or removing prohibited
articles, he shall detail such person between the gates and send notice to-the
Jailer who shall himself, if he thinks necessary conduct the search.
- Female hall only be searched by a female warder in private and
without the presence of any male officer.
The Jailer shall occasionally, and at least once a week, at unexpected times, search some of the officials of the Jail subordinate in rank to
himself and who are ordinarily, exempt from search on their way into or out
of or when inside the Jail and shall report the circumstance that he has done •
so with results, in his report book.
The search of all officers, of the rank of Head Warder and above
shall be conducted by the Jailer with as much privacy as possible.

$-.

Should any person other than a Jail Officer or prisoner decline
to submit to be searched of decline the deliver up any transferable articles
in his possession to the thmporary custody of the gate-keeper when required
to do so, he shall be denied admission.

General duties of gate-Iceeper.---(l) In addition to the duty prescribed for gate-keeper in Section 21 ol the Travancore-Cochin Prisons Act
XVIII of 1950, or ip Section 21 of the Central Act IX of 1894 the gate-keeper
shall maintain such registers and enter therein such particulars as the Inspector General of Prisons may from time to time prescribe in that behalf.
(2) The gate-keeper shall domply with all Rules, Regulations, directions and orders for the time being in fbrce, regulating the persons who may
be permitted ingress to and egress from and the articles which may be taken
into, and brought out of, the Jail. .
' Record of persons andthings entering and leaving jail.—(l) The gate-keeper
shall keep a record in the prescribed register of the name of every person and
a sufficient description of every article of whatever kind, that passess into or
out of the jail, with hour and minute of such passage and in the case of
articles, the name of the person in whose custody they passed through.
(2) He shall rcquire the production of a pass signed by competent
authority, by every person not entitled to admission without one, and in
respeét of every attick without exception that he allows into or out of the
Jail ,and shall file all such passess as his authority for- action.

S

<!-- page 80 -->

51
186. Particulars or record.—(l) The record or all persons who pass into
or out oftheJail prescribed by the preceding rule shall be kept in two separate
books namely:(a) a register of all prisoners, with the names of the officers in
charge of them, and
(b) a registqr of all other persons.
(2) "Sufficient descriptio'n of every article" means the name, number
or weight, as the case may be and such other particulars as may be necessary
4 of all goods, tools, stores or other articles passed into or out of the Jail.
(3) All entries relating to peisons or articles shall be made at the time
of their passage through the gate way and in consecutive order.

187. Convict officer to assist Gate-keeper.-----A convict officer, able to read
and write, may with the sanction of the Superintendent recorded on his
history ticket, be employed to assist the gate-keeper. He should not be allowed
to make any entries in the gate books.
188. Gate-keeper responsible for condition of main gate.—The gate-keeper
shall be responsible,for the cleanliness and tidiness of the passage between the gates
and the security of all the articles placed therein, which shall, for the time
being be in his charge;
that the gates and wickets of the main gate, except when it is
necessary to open them for the purpose of passing any person or thing into or
out of the Jail, are kept shut and locked; and
for the safety correctness of the keys entrusted to his charge.
189. Working of double gate system.—Where double gates are provided
with or without wickets, the gate-keeper shall open only one gate or wicket
at a time and before doing so shall satisfy himself that the other means of
entry and exit are secure. Ingress and egress for ordinary purposes shall
take place through the wicket doorway.
190. Method of passing prisoners into or out of Jail.—(l) On passing
prisoners out of the Jail the Gate-keeper shall first let them through the inner
gate or wicket and having locked it, shall write in full in the register provided
for the purpose the names or register numbers of all the prisoners, the warders
in charge and the convict officers (f any) assisting them. He shall then ppen
the wicket in the outer gate and count the prisoners as they pass out, to verify
the total.
