---
doc_id: "b62973b7abcefffc"
source_url: "https://milma.com/storage/tendernotices/October2026/fui9cCt3touw2nDHlOhN.pdf"
ministry: "Kerala Co-operative Milk Marketing Federation, Kerala"
title: "File 1"
date: ""
pages: 5
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "0c9bd4ca8995d4c1"
---

<!-- page 1 -->

milma
Kerala Co-operative Milk Marketing Federation Limited
Cattle Feed Plant, Malampuzha, Palakkad - 678651 =i
Phone: 0491-2816316/317 Website: www.milma.com,
E-mail: cfmprod@milma.com GST: 32AAAAK5375M6ZB(PAN: AAAAK5375M)

QUOTATION NOTICE No: KCMMF/CFP-M/PROD/173/ES(F)/2026/4455_

ക 19.10.2026
QUOTATION NOTICE

Sub: Inviting sealed competitive price quotations for the supply of

Electrical items for FPG conveyors at Cattle Feed Plant, Malampuzha

Kerala Co-Operative Milk Marketing Federation Limited (MILMA), Cattle

Feed Plant, Malampuzha, Palakkad - 678651 invites your sealed competitive

price quotations for the Supply of Electrical Items for FPG conveyors

within a shortest delivery period as per the technical specification and schedule of
quantities mentioned in Annexure enclosed herewith. The bidding shall be
subjected and binding to the following terms and conditions

I. General Terms & Conditions:

1. PRICE BASIS: All prices must be quoted as FOR site basis, including all
Taxes cum duties and freight, packing, forwarding, transit ,
risk insurance, loading, miscellaneous incidental charges
etc. for the safe delivery of the items at our end. Nothing

“ extra will be paid on this account for any reason. Special
discount offered if any shall be mentioned separately.

2. PRICE VALIDITY: The competitive price offered shall remain valid for 3
Months for acceptance from the date of your offer. Any
deviation in your price validity period shall be clearly
mentioned in your quotation itself.

3. PAYMENT MODE: 100% payment will be released against invoice within 30
Days of delivery. Advance payment will not be
entertained.

4. DELIVERY: The items shall be supplied within 30 days from the date of
receipt of the confirmed purchase order at the following

» address: Kerala Co-Operative Milk Marketing
Federation Limited (MILMA), Cattle Feed Plant,
Malampuzha, Palakkad - 678651.
e =

<!-- page 2 -->

However, early delivery will be appreciated. In case the
supplier fails to deliver the items within the stipulated
Period, the Federation reserves the right to terminate the |
order without assigning any reason.
5. LIQUIDATED DAMAGES ള്‌
CLAUSE: In case the supply of ordered items is not completed
within the stipulated delivery period, liquidated damages
@1% of total purchase value per week will be charged for
the items so delayed subject to a maximum of 5% of the
total value. =
21. Specific Terms & Conditions: .

1. Essential Documents: The bidder shall furnish the following
details/documents (as copy) for becoming eligible to technically qualify
in the bid

a. Name of the Bidder / Enterprise entitled to supply
b. Company Registration certificate

(ce Address proof of the Enterprise

d. Valid ID proof of the Bidder (such as Adhar)

രം PAN copy

3 GST registration certificate copy (if registered)

2. Any deviations in the specifications of the items quoted shall be clearly
specified.

3. Any deviations in the price quote, validity period, payment mode from as
stipulated above shall be clearly specified.

4. Rates shall be quoted only in Indian Rupees. Rates shall be fixed during the
entire validity period and Price quotations with dynamic pricing and including,
any other conditional clauses will be summarily rejected.

5. Right of Acceptance: The undersigned reserves the right to accept the offer

a either in full or in part, or to reject it entirely, without assigning any reason.

6. When quoting the price for each item, it is mandatory to add the item code of
the respective item.

7. Bid Opening: Only sealed quotations received by postal are valid and
considered for evaluation. Open quotations submitted in hand or sent by
email will be treated non-responsive and will be totally rejected. Hence the
bidders are requested to send their valuable sealed quotations by postal well
in advance before the date of opening. Sealed quotations shall reach our
office on or before 3:00 PM of 03.11.2026 and the received quotations will
be opened on the same day at 3.30 PM in the presence of bidders if any
available. Quotations received after 3:00 PM will be rejected.

8. Bidder Confirmation: Technically qualified bids will only be considered for
financial evaluation. Price bids will be assessed in accordance with the Least
Cost Based Selection System. All the bids will be evaluated on the basis of
the eligibility criteria through verification of all the essential documents

. submitted along with the terms & conditions complied by bidder. Though the
L1 bidder will be the preferred bidder, simply quoting of lowest rate does not
confer any right for selection of the bidder at the rate quoted. KCMMF
reserves the right to confirm and finalize the bidder. Quoting of same rates ~
os

<!-- page 3 -->

(L1 only) by more than one bidder could be construed as an exceptional
circumstance. In such cases, all the bidders who have quoted the same
lowest rates shall be called for and one more chance will be given for on spot
quoting if bidders are present or negotiated quote may be collected via mail
with a closing time for rate finalization. If the negotiated quotes are still the
same, KCMMF reserves the right to award the purchase order to that party at
its discretion subject to the reputation/performance of the party based on,
their business volume, providing extended guarantee period, prompt service,
customer satisfaction etc. or to cancel the tender for proceeding with re-
tender.

III. Details of the items required to be supplied <
Details of items to be supplied with specifications and quantity are as
mentioned in the Annexure enclosed herewith and also available at our official
website https://www.milma.com/tender/tendernotices

IV. Submission Details:

The quotation must be submitted in a sealed cover clearly super
scribed: “SUPPLY OF ELECTRICAL ITEMS FOR FPG CONVEYORS AT
MILMA CATTLE FEED PLANT, MALAMPUZHA” and addressed to:
The Manager
Milma Cattle Feed Plant
Malampuzha
Palakkad - 678651
iy NAN രിദ്‌
. Copy to: HOD-P&M,FO, Office File Xe
To be displayed/ published at
1. All Notice Boards, CFPM
2. Panchayath Office, Malampuzha
3. ITI, Manthakkad
4. Village Office, Malampuzha
5. Milma website
6. Milma Dairy, Kalleppully
Encl: Annexure - List of Items with specifications
oo .

<!-- page 4 -->

milma
Kerala Co-operative Milk Marketing Federation Limited
Cattle Feed Plant, Malampuzha, Palakkad - 678651
Phone: 0491-2816316/317 Website: www.milma.com,
E-mail: cfmprod@milma.com GST: 32AAAAK5375M6ZB(PAN: AAAAK5375M)
é
QUOTATION SUBMISSION FORM
QUOTATION NO: KCMMF/CFP-M/PROD/173/ES(F)/2026/ 19/10/2026
Date & Time of Opening: 03.11.2026 at 3.30.pm
1 Name & Address of the
Quotationer.
2 Phone Number(Mob)/ Land
Phone Number
Email ID
Aadhaar Card Number |
4 | (linked with PAN):
“= Documents to be enclosed
5 GST Registration Number
Documents to be enclosed
’ PAN card Registration
Number (Documents to be
enclosed
e .

<!-- page 5 -->

ANNEXURE
(List of Items with description, specifications, Quantity)
Technical Specifications & Price Bid Format with schedule of
quantities
aa
SSS
| sl aT . Rate Amount
| No Item Description Quantity (Rs.)
|
Junction Box :
(Minimum IP65 protection, dimensions 140 x 200 * 100
7° mm (H x Wx D), suitable for electrical connections.
Complete with 20 Nos. of connectors suitable for 25 sq.
mm conductors and rated for 32 A)
McB
2 (3-pole, 6 A, C-curve type, suitable for 415 voltage and 50
Hz frequency)
Industrial Socket
(3 phase 32 A industrial-grade socket, suitable for 415
3 6 റ 10 nos
| voltage, complete with appropriate enclosure and
L accessories)
DOL Starter
4 (3 phase with 5A overload relay (OLR), suitable for the 2 nos
415 voltage, with necessary protection and accessories)
Packing and Forwarding a a
GST
Fs es eee
GRAND TOTAL (INCLUDING ALL)
Name and Address of the Bidder with Seal & Signature
ളം
ി s
2 — ae
