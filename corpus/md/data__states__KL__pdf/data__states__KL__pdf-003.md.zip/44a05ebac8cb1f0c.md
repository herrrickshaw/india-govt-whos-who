---
doc_id: "44a05ebac8cb1f0c"
source_url: "https://keralacseb.kerala.gov.in/wp-content/uploads/2024/02/Circular_No_15_2011.pdf"
ministry: "Kerala Co-operative Services Examination Board, Thiruvananthapuram, Kerala"
title: "PDF"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e6417d1f8a4937be"
---

<!-- page 1 -->

ffu.Io6o6mffuo.1€lo og]o-rjLs c d @Oon1rrJ.
: oe o2 2orl

P.".$o.(r) ll78i20li

."."r,.. m;:r?;i['

'lor"]orcr,

- 1969 os c6op ffu.'cl6o6.D ffuoo€ro a5o 185(2). (3) cruoo6(o6m cruoo€ro PlotcDdocoJos pc6jc(r.)66.)co)80 - ccoccDJ(Dc "lo"log acdrS m'16cq eBB uE "l;o o gsloJ ooJcm mr' ruo erumj-r'1 i.
cruoo6o6rt oroli

QL'lo9z cQ) o:

cro

o-U]-al(T): 1.
2.

-

.

3.

ffunod,o6m(ruoo€ro oelm;lsco;os 29 I 1992, 301 1999 comlr6 mlrdoole,]o;otd.
2b10 og G6og o'ur,rl6o6rt ffuooero (creocnorl) orlcoroo.
2010 oo eeicop mioo6o6rD cruoo€lo (olcmco creocnrorl) "-LgoaaoE.

Gdl)OC CrUclO6O5m ffUoo€lo ol5o 185 p.'loi5esBUa (2). (3) oOCrO']OiCOiO8 aOCO<6OO]AO;Cm
oronrco.lrolav
otmloiaaplcerccFad' oL,.-tccoc,-,sicr6 o)eorcn cnlcorocoo cnsoro;cmro'icri
msoloemoomi olJclcru-o o"loiofl5;sr=cor'lolcrnrolo, <o.rocoror'1oQ rsrds'loucm(dro1o8 crul4:cD 1

oo;

oer mr6oo;ero;aUd loacoo cnTdcgc,oeanr.d oj;oogslojieoleco)lo odc0iot5J6nd.
.6cmcoE 1969 os c&op mr.loeo6'm ffuoclelo colcoroo cla1.j S0(eru1)qr'lel1o, 4l5o I 85(7)
erlo, a;cpfoo.,ncor1ord "6yei'm.lcolcmosj.IE msoroccd cec-ccgcogloi crudcglmi "61dmrcolcm
,,sjcrd c6ilCdrutool etlaroelogs;ororT m-r;"-.lm 2 Lotocoo ajlcCUocreaOor'l m'leLo,;loE clolaCCu;o,
o'u)e-lm 3 t &coo dso 185 ello csoto.jarcoo GG€coG' CLlO'lOOr;o O"-lOiOr'l51end. pLolecoo
cco)ccnlor.lrolae (Qualifling Examination)otcqca;cmclrflad o3LoGo r6rdsl6lo cso,uoTcsaiad
2G6Jc0ooocogo moEelaor;gpi "ocm)o o5aorocoerlcoi5;end.
cao)coJao .']olasQfloE 6)alccol€o6rn ol'],-,ejco)or)o, orce'1otri, acccns"]ro1o.roE mio,To8, ceop
o1Jo.(]&io6rDffuoo€io m'l(o)oojlo 4t56sr3elo, af rc'oml0rml cri'l"9ico6BEU8 al;seoalccucr.l gv8oaocg
glao;aco.r;o, s'1 cco;ccn5or .lolasjc msoro;cmni' oloerumlrlgj rocoe .'loco)lffn crllr8cquoeonrd
o.r;oogs;cl1oo)6@Jo oerg]cmJ.
i. co)coJcoc .,tolasic msoror;cm<orlcri accoc slormaocolot crlcrn;o .lo1a'sc.l1mi cacacgcogloi m,rr6qla'J .41d'mlcolccn.'vnE cerucrarui p(9socdoarBcolo, s'l ol1mi
{sD€J(OOr5m (Tuooero Cl"OlCAOenaolocenY.
z. cco,c-tn5,oc-o"la,vcol;os m.ieterum,r" ouoerucrul2i cac-acgcoolol crudqlmi "6er,"mlso1
cm"sjfr cen-rcrdn-rj rsacteolc€o6n3collo, oro1€:gic mscoroarie- ojioo, .,lo1agcol;os ocrdad'
ro; seoalcorcrt sT cncioiotToE p crder aoc g g'lcaoeneal; oc eni.

eac-acgeooloi mjdq1mi "41druco1cmosio'E
s. cccucojotc.lolasl acdpcogcmclrEad'
genrcrdn-ri cru651"n1aof moScoerre<orceni. mlooo,osm ffu o oelscn uE / 5ni c o,1o ud por;
ruodnlflut4 oncncond. 6rucruog5 silclmaocdod moSolocor;o, ceoctn5roc "io1asjc

corCorocO; 6co5llolC/OcelJo pccJcoeOCOgo mrdAecnd .loSlgcOrO<o;
otC(ruCer'OOTDol6Ad'
a9

acfill-

ei{,
(Tuoo&o6rD ffuooelo oPlcrJtscd

;e<E{,- r "OHc ceccorl{ oslmjrscrd (*moo8)ocrioo;o,^o4g[> ee2,ailr4irL.an{rt r,rbes"

z. occm=locd n-ucoroqr6. filoffunccn ffuorl6o6m 6tuce (€?loiolo).
s. occcoslor.d ,*-n{4, ffuocrunccD ffu.}o6o6tD ocr6"s4# Locoolom)co alcd'(gljmo)
a. iam-fluQ'/*cnoo8 accmed, o0)Rc slHs ffu.'o6o5lD 6rrcFrl6Plo.
s. om-,gagcii. coc ocgcogloi nu 6,!1od ,'4dm.,ca'lccn^+rnf, ceucdn-ri.
o.
cranulggQ' odlmitscd (*mno8)acdarorSo. ,:=ccoil( osTmitscd(emooE)olaccrurToo

y. "ORc nu*r## a,rlu-.t- .'J"o g.'6t t86l
"gf",glp,tt,

(3roedocmlcruo6rDo

t effilt6ls'er.'6e,rzre"6\*,\:,,tk.-

W

cercoil crO ci osilrgrd ("6cit". mn/"61cru: fl )
