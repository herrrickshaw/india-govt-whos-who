---
doc_id: "73aa2bf8cdb24f9f"
source_url: "https://gecskp.ac.in/pdf/ksrvol-i-2.pdf"
ministry: "Government Engineering College Palakkad, Sreekrishnapuram, Kerala"
title: "KSR Rules Part 1"
date: ""
pages: 236
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "012b2969c0e131b5"
---

<!-- page 1 -->

GOVERNMENT OF KERALA

THE KERALA SERVICE RULES
VOLUME I
PARTS I & II

SIXTH EDITION
(Embodying corrections up to 31st August 1999)

ISSUED BY THE AUTHORITY OF THE GOVERNMENT OF KERALA

FINANCE DEPARTMENT

• Government will not be responsible for any unauthorised alteration in the
original text of the Volume .

<!-- page 2 -->

PREFACE TO THE FIRST EDITION
The service personnel of the State of Kerala comprise officers of the
former Travancore-Cochin State, those transferred from the former
Madras State on the date of reorganization of the States and those
appointed to the service of the new State on or after 1st November 1956.
The officers of the former Travancore – Cochin State themselves consist of
officers who belonged to the former States of Travancore and Cochin. The
service conditions of these different categories of officers are now governed
by three different sets of Rules, viz., (1) The Travancore Service
Regulations, (2) The Cochin Service Regulations and (3) The Fundamental
Rules (Madras), the Madras Pension Code and the Madras Manual of
special Pay and Allowances. The need for a unified set of rules to regulate
the service conditions of the employees of the State of Kerala is obvious.
Accordingly Government are pleased to issue these new unified rules under
the proviso to Article 309 of the Constitution of India.
2. The rules are set forth in three parts as follows :Part I - Rules relating to the General Conditions of Service, Pay
fixation, Leave, Joining time, Foreign Service, etc.
Part II - Rules relating to Travelling Allowance
Part III - Pension
These rules shall be deemed to have come into force from the
1 November 1959.
st

3. These rules are applicable to all officers who entered the service of
the Kerala State on or after the 1st November, 1956. The rules are also
applicable to those who came into the service of this State from the former
State of Travancore – Cochin and the former Madras State and who elect
to be governed by these rules. No option will however be given in regard
to the T.A. Rules. All officers will be governed by the new rules in the
matter of Travelling Allowance.

<!-- page 3 -->

Any officer who finds any error or omission in these rules or any
difficulty in implementing them is requested to bring it to the notice of the
Secretary to Government, Finance Department.

TRIVANDRUM ,
7TH NOVEMBER 1959.

P.S . PAD MANABHA N
Finance Secretary

<!-- page 4 -->

PREFACE TO THE SECOND EDITION

Since the issue of the First Edition, there have been several
amendments to these rules; very many ‘Rulings’ and ‘Government
Decisions’ have also been issued there under. These ‘Rulings’ and
‘Government Decisions’ have been furnished under the relevant Rules
to make their application easy. All the amendments issued upto 31 st
March 1964 have been incorporated in this Edition.

C. TH OMAS
Finance Secretary

<!-- page 5 -->

PREFACE TO THE THIRD EDITION
More than six years have elapsed since the issue of the Second
Edition of the Kerala Service Rules. During this period there had been
considerable changes in the service conditions of Government
employees necessitating the issue of a series of amendments to the
Rules. All the amendments, rulings and decisions introduced after the
issue of the Second Edition have been incorporated in this Edition.
A change has been made in this Edition. This volume contains
only Parts I – (Rules relating to the General conditions of Service, Pay,
Leave, Joining time, Foreign Service, etc.) and II – (Rules relating to
Travelling Allowance) of the Kerala Service Rules and the relevant
Appendices and Forms. Part III – (Pension) will be issued as a separate
volume.
The arrangement of the rules followed in the previous editions
has been retained in this Edition also.
The Preface to the previous Editions have been reproduced and
the instructions contained in the concluding paragraph of the Preface to
the First Edition continue to apply.

TRIVANDRUM ,
st

31 August, 1970.

P .V ELAYU DHAN NAIR
Finance Secretary

<!-- page 6 -->

PREFACE TO THE FOURTH EDITION
The present edition comprises of Parts I and II of the Kerala
Service Rules and follows the form and order adopted in the third
edition. Part III Kerala Service Rules has since been issued as a
separate Volume in 1974. This edition incorporates all amendments,
rulings and decisions ordered by Government since the last edition
covering the period upto 31 st August 1976.
Any officer who finds any error or omission in these rules or any
difficulty in implementing them is requested to bring it to the notice of
the Secretary to Government, Finance Department.

TRIVANDRUM ,
19TH O CTOBER, 1976.

K .V. RA BIN DRAN NAI R
Finance Secretary

<!-- page 7 -->

PREFACE TO THE FIFTH EDITION
The present edition comprises of Parts I and II of the Kerala
Service Rules and follows the form and order adopted in the fourth
edition. Part III Kerala Service Rules has since been issued as a
separate Volume in 1974. This edition incorporates all amendments,
rulings and decisions ordered by Government upto 31st December 1985.
Any officer who finds any error or omission in these rules or any
difficulty in implementing them is requested to bring it to the notice of
the Secretary to Government, Finance Department.

TRIVANDRUM .

K.V. RA BIN DRAN NAI R
Commissioner & Secretary (Finance)

<!-- page 8 -->

PREFACE TO THE SIXTH EDITION
This Sixth edition of Kerala Service Rules, Volume I is published
after a lapse of 14 years since the last edition. All amendments and
modifications upto 31 st August 1999 have been incorporated in this
edition.
A number of changes have been made in this new edition. The
traditional format has been changed. Referencing is made easy as the
number and date of the Government Orders incorporating
amendments/ modifications are shown on the right side along with the
relevant portion of the text, instead of the foot notes followed in the
past.
This Volume will be available for sale on CD ROM also from
the Finance Department.
Comments, if any, for improving this volume are welcome.

THIRUVANANTHAPURAM ,
18TH NOVEMBER, 1999

V IN OD RAI
Principal Secretary (Finance)

<!-- page 9 -->

TABLE OF CONTENTS
PART I
Pay, Leave, Joining time, etc.
Chapter
I
II
III
IV
V
VI
VII
VIII
IX

General Scope
Definitions
General conditions of service
Pay
Additions to pay
Combination of Appointments
Dismissal, Removal and Suspension
Compulsory Retirement
Leave
Section
,,
,,
,,
,,
,,
,,
,,
,,
,,
,,
,,
,,
,,
,,
,,

X
XI

I

Extent of application
II General Conditions
III Grant of leave
IV Commutation of leave
retrospective effect
V Leave salary
VI Overstayal
VII Special disability leave
VIII Study leave
IX
X
XI
XIA
XIB
XIC
XID
XII

Rules
1-1 1
12
13-24A
25-43
44-52
53-53A
54-59
60-60A

Pages
1
3
10
18
39
43
46
53

61-63
64-76
77-88

58

89-91A
92-95
96-96A
97-98
99

69
72
73
74
75

100-102
103-106
107-110
110A

75
76
78
79

110B
110C
110D
111

79
79
79
79
79
83
87

59
63

with

Maternity leave
Hospital leave
Leave to part-time officers
Leave to Radiation workers
Leave for taking up employment
Abroad or within India
Leave for the purpose of study
Leave for joining spouse
Casual leave

,,
XIII Procedure relating to leave
Joining time
Foreign Service

112-124
125-138
139-159

PART II
Travelling Allowances
Chapter I
Section I

Grades of officers

,,
,,

II
III

General
Permanent traveling allowance

,,
,,
,,
,,

IV
V
VI
VII

Conveyance allowance
Mileage allowance
Daily allowance
Actual Expenses

5-5A

1-4

97
98

6-8
9-1 1
12-36
37-40
41

99
101
101
112
113

<!-- page 10 -->

T RAVELLING ALLOWANCE FOR DIFFERENT KINDS OF JOURNEY
Chapter II
Section I
,,
II
,,
III
,,
IV
,,
,,
,,
,,

,,
,,

,,
,,
,,

General

42-45

Journeys on tour
Journeys on transfer
Journey to join New Appointment

46-64
65-73

113
115
124

74-76

131

77-79

131

80-83

131

84

132

85-87A

132

88-95

135

96
97-98

137
137

99

138

99A-99B

138

V Journey to attend an examination
VI Journey when proceeding on or
returning from leave
VII Journey
for
joining
first
appointment
VIII Journeys during suspension or to
give evidence or to attend a
court of law
IX Journeys
to
obtain
medical
treatment, etc.
X Journeys in attendance on an
incapacitated officer or member
of his family
XI Journeys on a course of training
XII Journeys of the family of an officer
who dies in service
XIII Journey of an officer after
retirement

Travelling allowance admissible when means of transport are supplied

Chapter III
Section I
,,
,,
,,
,,
Chapter IV
Chapter V

II
III
IV
V

Journeys by Railway

100 -102

139

Journeys by Sea or River Steamer
Journeys by Air
Other journeys
Method
of
calculating
daily
allowance
Grant of Travelling Allowance to
those who are not in regular
Government service
Controllin g Officers
Appendices and Forms

103 -104
105 -106
107 -109

140
140
141

110

141

111-112A
113 -116

142
144
145-207

<!-- page 11 -->

THE KERALA SERVICE RULES
PART I
PAY, LEAVE, JOINING TIME, ETC.
CHAPTER I
GENERAL SCOPE

1.

(i)

These rules may be called the Kerala Service Rules.

(ii)

The rules in Part I and Part II shall be deemed to have come into
st
force with effect from 1 November 1959 and those in Part III shall
st
be deemed to have come into force from 1 November 1956.

2.

Subject to the provisions of Rule 3,(i)

the rules in Part II relating to Travelling Allowance shall apply to
every person in the whole time employment of the Government
(other than a person so employed in the contingent or work
establishment);

(ii)

the remaining rules shall apply to every person in the whole time
employment of the Government (other than a person so employed
in the contingent or work establishment),(a) who was not in the service of the Government of Travancore Cochin or the Government of Madras on 31st October 1956, or
(b) who was in the service of the Government of Travancore st
Cochin or the Government of Madras on 31 October 1956
and who continued to be in the service of the Government of
Kerala, but has opted to be governed by these rules in
accordance with such conditions as may be laid down by the
Governm ent in this behalf; or
(c) who was absorbed to Government service on or after 1st
November 1956, but who prior to such date was in the service
of any quasi-Government or other institution and whose
appointment and conditions of service were governed by any
law or rule made under any law for the time being in force, if
such person exercises his option to be governed by these
rules, subject to such conditions as may be laid down by
Government in this behalf.
Ruling
The rules in Part II, Kerala Service Rules relating to
Travelling Allowances shall apply to the persons appointed to the
service of the Government temporarily under Rule 9 of Part II of the
Kerala State and Subordinate Service Rules also.

3.

(i)

These rules shall not apply to,(a) persons for whose appointment and conditions of employment
special provision is made by or under any law for the time being
in force;
(b) persons in respect of whose conditions of service, pay and
allowances, pension, leave or any of them, special provision
has been made by agreement entered into before these rules
were made or entered into thereafter in pursuance of the
provisions of Rule 8:
Provided that in respect of any matter not covered by the
provisions special to him, his service or his post, these rules shall
apply to any person coming within the scope of clauses (a) and (b)
above, to whom but for those clauses the rules would otherwise
1

[G.O.(P)1082/87/Fin.,
dt. 16-12-1987]

<!-- page 12 -->

KERALA SERVICE RULES

[PART I

apply.
(ii)

Notwithstanding anything contained in Rule 2 the Government may,
by notification in the Gazette, exclude wholly or in part from the
operation of these rules any officer or any class of such officers to
whom the Government shall declare that the rules cannot suitably
be applied, and these rules shall thereupon to the extent of such
exclusion, cease to apply accordingly.
Note. —These rules as a whole shall not apply to the persons appointed to the
service of the Government temporarily under Rule 9 of Part II of the Kerala
State and Subordinate Service Rules , 1958, except to the extent specified
by the Government.

[G.O.(P) 77/87/Fin.,
dt.22-1-1987]

Government Decision
The direct recruits to the personal staff of the Ministers will
be governed by the service conditions specified in the Special
Rules applicable to them and in respect of any matter not covered
by the provisions in such Special Rules, the provisions in the Kerala
Service Rules will apply.
4.

If any doubt arises as to whether these rules apply to any person,
the matter shall be referred to the Government and the decision of
the Government shall be final.

5.

Nothing in these rules or in any rule made thereunder shall operate
to deprive any person of any right or privilege to which he is
entitl ed,-

6.

(a)

by or under any law, or

(b)

by the terms of any contract or agreement subsisting between
such person and Government on the date these rules come
into force.

Subject to the provisions of Rule 5, nothing in these rules or any
rule made under these rules shall operate to affect to the
disadvantage of any person holding a substantive post under
Government to whom these rules apply, the conditions of service in
respect of pay, leave, allowances, pension or any other matter
which are applicable to him (a)

on the date these rules came into force, or

(b)

by virtue of any order or rule made by the Government, unless
such person gives his consent.

7.

Where Government are satisfied that the operation of any rule
under these rules caus es undue hardship in any particular case,
the Government may dispense with or relax the requirements of
that rule to such extent and subject to such conditions as they may
consider necessary for dealing with the case in a just and equitable
manner.

8.

When in the opinion of the Government, special provisions
inconsistent with any of these rules or of any rules made
thereunder are required in respect of conditions of service, pay and
allowances, leave and pension or any of them, with reference to
any particular post, it shall be open to the Government,
notwithstanding anything contained in these rules, to provide by
agreement with the person appointed to such post for any of the
matters in respect of which in the opinion of the Government
special provisions are required to be made, and to the extent to
which such provisions are made in the agreement, nothing in these
rules or in any rules made thereunder shall apply to any person so
appointed in respect of any matter for which provision is made in
the agreement :
2

[G.O.(P) 68/65/Fin.,
dt.16-2-1965]

<!-- page 13 -->

CHAP.I]

GENERAL SCOPE

Provided that in every agreement made it shall further be
provided that in respect of any matter in respect of which no
provision has been made in the agreement, the provisions of these
rules or of rules made thereunder shall apply. (For model form of
agreement See Appendix I).
9.

The Government may delegate to any of its officers subject to any
conditions which it may think fit to impose any power conferred
upon it by these rules with the following exceptions :(a) power to make rules;
(b) [Deleted];
(c) power to regulate the terms and conditions for grant of
compensatory allowances;
(d) to determine the standard rent of buildings and the rent
recoverable from an officer occupying the residence;
(e) to remit leave and pension contributions in respect of an officer
transferred on foreign service; and
(f) to permit an officer on foreign service to receive pension or
gratuity from foreign employer.

10.

No powers may be exercised or delegated under these rules except
after consultation with the Finance Department. It shall be open to
that Department to prescribe, by general or special order, cases in
which its consent may be presumed to have been given.

11.

The Government reserve to themselves the power to modify these
rules as may from time to time seem expedient and to interpret
them in case of doubt.
Ruling
An officer’s claim to pay and allowances is regulated by the
rules in force at the time in respect of which the pay and allowances
are earned; to leave, by the rules in force at the time the leave is
applied for and granted; and to pension, by the rules in force at the
time when the officer resigns or is discharged from the service of
the State.
Persons governed by the Kerala Service Rules who were
st
on leave on the crucial date, i.e. 1 November 1959, the leave
having been sanctioned in good faith and availed of from a date
st
prior to 1 November 1959 will be treated to have come over to the
leave rules in the Kerala Service Rules on the expiry of the first
spell of leave originally sanctioned. Any further extension of such
st
leave after 1 November 1959 should be regulated only in terms of
the rules in Kerala Service Rules. No arrears will, however, be paid,
nor amounts drawn in excess recovered as a result of such
readjustment of leave.

CHAPTER II
DE FI NI T IO NS

12.

Unless there be something repugnant in the subject or context the
terms defined in this chapter are used in the rules in the sense here
explained :(1)

Actual travelling expenses.-means the actual cost of transporting an
officer and his personal luggage including charges for ferry and
other tolls and for carriage of camp equipment, if necessary. It does
3

<!-- page 14 -->

KERALA SERVICE RULES

[PART I

not include charges for hotels, travellers bungalows or refreshments
or for the carriage of stores or conve yances or for presents to
coachmen and the like, or any allowance for such incidental losses
or expenses as the breakage of crockery, wear and tear of furniture
and the employment of servants.
(2)

Apprentice.- means a person deputed for training with a view to
employment in Government service, who draws pay at monthly
rates from Government during such training, but is not employed in
or against a substantive vacancy in the cadre of a department.

(3)

Audit Officer .- means the Head of the Office of Accounts and Audit
subordinate to the Comptroller and Auditor General of India,
whether designated as Comptroller or Accountant General or by
any other designation.

(3A)

Average Pay.- [Deleted].

(4)

Cadre.- means the strength of a service or part of a service
sanctioned as a separate unit.

(5)

Compensatory Allowance.- means an allowance granted to meet
personal expenditure necessitated by the special circumstances in
which duty is performed. It includes Travelling Al lowance.

(5A)

Competent Authority.- Competent authority in respect of any officer,
in so far as any power delegated under these rules is concerned,
means the authority to which such power has been delegated and
where no such specific delegation has been made, the competent
authority is, unless otherwise stated, the authority in whom the
power to appoint such officer has been or is vested from time to
time by the State Government.

(6)

Day.- means a calendar day, beginning and ending at midnight; but
an absence from headquarters which does not exceed 24 hours
shall be reckoned for all purposes as one day, at whatever hours
the absence begins or ends.

(7)

Duty .- Duty includes-

[G.O.(P) 491/75/Fin.,
dt.24-10-1975]

(i) Service as a probationer or apprentice, provided that
such service is followed by confirmation.
(ii) Joining time.
(iii) A course of instruction or training which an officer
undergoes specially ordered by Government to be
treated as duty.
Note 1.- A student, stipendiary or otherwise, who is entitled to be appointed to the
service of Government on passing through a course of training at a
University, College or School shall unless in any case it be otherwise
expressly provided in the terms of his appointment, be treated as on duty
during the interval between the satisfactory completion of the course and
his assumption of duties.
Note 2.- An officer required or permitted to attend an obligatory departmental
examination may be treated as on duty during the day or days of the
examination and during the reasonable time required for the journey, if
any, to and from the place of examination.
Explanation.
The term ‘obligatory departmental examination’ means(i) any test a pass in which is prescribed for the successful
completion of probation or training of an officer, whether
recruited direct or by transfer;
4

[G.O.(P) 366/76/Fin.,
dt. 26 -11-1976]

<!-- page 15 -->

CHAP.II]

DEFINITIONS

(ii) any test a pass in which is prescribed for the purpose of making
an officer eligible for increment or for confirmation in any post;
(iii) any test a pass in which is prescribed for promotion to any
higher post coming in the line of promotion in the department
concerned ;
(iv) any test a pass in which is prescribed as a qualification for
continuance in the post;
(v) any test a pass in which is newly prescribed for persons already
in the service concerned.
Note 3.-The period spent on training by officers who are reservists of the Defence
Forces and the period of their journey to and from the training centre may
be treated as duty.
Ruling
In all cases of deputation of officers for a course of
instruction or training under these rules, the period of such training,
if treated as duty under sub-clause (iii) of the above rule, should be
specified as such in the orders sanctioning such deputation. A
separate clause that the period will count for increment, leave and
pension is not necessary in such cases. In case where an officer
selected for training is found unsuitable on medical examination or
otherwise, the period spent by him in India for journey for medical
examination, etc. in connection with the training will be treated as
leave and no Travelling Allowance will be allowed for such
journeys.
Note 4.- When a Government Servant on return from leave, training, foreign
service or on termination of previous appointment, has compulsorily to wait
for orders of posting, the interval between the date of report and the date
on which he takes charge of his duties shall be treated as ‘duty’ provided
that the interval between the date of receipt of orders and his assumption
of duties shall not in any case exceed the amount of joining time
admissible under Rule 125 (a). During such period of duty, he will be
entitled to pay according to Rule 26. Avoidable delay caused in giving
posting orders in such cases shall render the authorities concerned, liable
for the excess expenditure, if any, caused thereby.

[G.O.(P)475/75/Fin.,
dt. 9 -10 -1975]

Note 5.- The period spent on training by teachers (both stipendiary and nonstipendiary) deputed for training from departmental Schools to Training
Colleges/Training Schools may be treated as duty.

[G.O.(P) 322/67/Fin.,
dt. 29-7 -1967]

This amendment shall be deemed to have come into force with
effect from 1st November 1959.
Note 6.- When a Government Servant is deputed by Government to participate in
a Civil service Tournament as a member of the team or to participate in
the coaching camps organised in connection thereto, the period spent for
participation in such tournaments/coaching camps, including the time
taken for to and fro journeys will be treated as duty.
Explanation.- The term ‘Civil Service Tournament’ shall mean India
Civil Services Tournaments organised by (a) the
Central Civil Service Sports Control Board, (b) State
Governments on behalf of the above Board and (c)
Sports Councils or Associations authorised by the
State Government, on behalf of the Central Civil
Service Sports Control Board.
The note shall be deemed to have come into
force with effect from 1 st July 1980.
(8)

Fee.- means a recurring or non-recurring payment to an officer from
a source other than the General Revenues whether made directly
5

[G.O.(P) 211/82/Fin.,
dt. 5-5-1982]

<!-- page 16 -->

KERALA SERVICE RULES

[PART I

to the officer or indirectly through the intermediary of Government
but does not included—

(a) unearned income, such as income from property, dividends
and interests on securities ; and
(b)

income from literary, cultural or artistic efforts, if such efforts
are not aided by the knowledge acquired by the officer in the
course of his service.

(9)

Foreign Service.- means service in which an officer receives his
pay with sanction of Government from any source other than the
Consolidated Fund of India or of a State.

(10)

General Revenues.- General Revenues of Kerala include the
Consolidated Fund, the Contingency fund and the Public Account of
Kerala and exclude the revenues of Local Funds.

(11)

Government.- means the Government of Kerala.

(12)

Gratuity.- (See Pension)

(13)

Heads of Departments.- The term includes -

(14)

(a)

Officers who have been declared by the Government to be
Heads of Departments. (See Appendix II)

(b)

Any other authority to which the Government may delegate the
powers of a Head of Department.

Holiday.- means (a)

a holiday prescribed or notified by or under section 25 of the
Negotiable Instruments Act, 1881; and

(b)

in relation to any particular office, a day on which such office is
ordered by notification of Government in the Gazette to be
closed for the transaction of Government business without
reserve or qualification.

(15)

Honorarium.- means a recurring or non -recurring payment granted
to an officer from the General Revenues of the State as
remuneration for special work of an occasional or intermittent
character.

(16)

Joining Time.- means the time allowed to an officer to join a new
post or travel to or from a station to which he is posted.

(16 A)

Last Grade Service.- means service in any post included in the
Kerala Last Grade Service constituted by the Special Rules for the
Kerala Last Grade Service, published under G.O.(P) 82/Public
th
(Rules) Department, dated the 8 March 1966, in Part I of the
Kerala Gazette No.14, dated the 5th April 1966, as amended from
time to time, and includes *all other posts carrying the lowest scale
of pay in the schedule of pay scales in force from time to time and
service in any post declared by the Government to be a post in the
Last Grade Service.

(17)

Leave salary.- means the monthly amount paid by Government to
an officer on leave.

(18)

Lien.- means the title of an officer to hold substantively, either
immediately or on termination of a period or periods of absence, a
permanent post to which he has been appointed substantively.

(19)

Local fund.- means (a)

revenues administered by bodies which by law or rule having
the force of law come under the control of Government,
whether in regard to proceedings generally or to specific
6

[G.O.(P) 1060/79/Fin.,
dt. 6 -12 -1979]
*[G.O.(P) 626/93/Fin.,
dated 4-10-1993]

<!-- page 17 -->

CHAP.II]

DEFINITIONS

matters, such as the sanctioning of their budgets; sanction to
the creation or filling up of particular posts, or the enactment
of leave, pension or similar rules; and
(b)

the revenues of any body which may be specially notified by
the Government as such.

(20)

Ministerial Officer.- means an officer of a subordinate service
whose duties are entirely clerical, and any other class of officer
specially defined as such by general or special orders of
Government.

(21)

Month.- means a calendar month.
In calculating a period
expressed in terms of months and days, complete calendar months,
irrespective of the number of days in each, should first be
calculated and the odd number of days calculated subsequently.
Note. - Whenever it is necessary to calculate a period in calendar months, the
period shall be taken to end either on the day of the month corresponding
to the day before the day on which the period begins or if there is no such
corresponding day in the month, then on the last day of the month.
th

Example.-A period of six calendar months beginning on the 28
th
st
February ends on the 27 August, 31 March ends on the
th
th
st
th
30 September, 30 or 31 August ends on the 28
th
February or 29 February, if leap year.
th

In calculating a period of 3 months and 20 days from 25
th
January, 3 months should be taken as ending on the 24 April and
th
th
the 20 days on 14 May. In the same way the period from 30
nd
January to 2 March should be reckoned as 1 month and 2 days,
th
th
because one month from 30 January ends on 28 February. A
st
period of one month and 29 days commencing from 1 January will
expire in an ordinary year (in which February is a month of 28 days)
on the last day of February because a period of 29 days cannot
obviously mean to exceed a period of full calendar month and leave
st
for two months from 1 January would end on the last day of
February. The same would be the case if February were a month of
29 days or if the broken period were 28 days (in an ordinary year).
(22)

Officiate.- An officer officiates in a post when he performs the duties
of a post on which another person holds a lien. The appointing
authority may, if it thinks fit, appoint an officer to officiate in a vacant
post on which no other officer holds a lien.

(23)

Pay.- means the amount drawn monthly by an officer as(i)

the pay, other than special pay or pay granted in view of his
personal qualifications, which has been sanctioned for a post
held by him substantively or in an officiating capacity or to
which he is entitled by reason of his position in a cadre, and

(ii)

personal pay and special pay, and

(iii) any other emoluments which may be specially classed as pay
by the Government.
(24)

Pension.-Except when the term ‘Pension’ is used in
contradistinction to gratuity or ‘Death-cum -retirement gratuity’,
‘Pension’ includes ‘gratuity’ and ‘Death-cum -retirement gratuity’.

(25)

Permanent Post.- means a post carrying a definite rate of pay
sanctioned without limit of time.

(26)

Personal Pay.- means additional pay granted to an officer-

(a) to save him from loss of substantive pay in respect of a
permanent post due to a revision of pay or to any reduction o f
such substantive pay otherwise than as a disciplinary measure
7

<!-- page 18 -->

KERALA SERVICE RULES

[PART I

; or

(b) in

exceptional
considerations.

circumstances,

on

other

personal

Note. - All cases in which it is proposed to grant personal pay under clause (b) of
the above rule should be referred to the Finance Department by the
Administrative Department concerned. No case will be entertained which
is not of an entirely exceptional character and in submitting cases for the
grant of personal pay, this should be carefully borne in mind.
(27)

Presumptive Pay of a Post.- When used with reference to any
particular Government servant, means the pay to which he would
be entitled if he held the post substantively and were performing its
duties; but it does not include special pay unless the Government
servant, performs or discharges the work or responsibility in
consideration of which the special pay was sanctioned.
Note. - The first part of the definition is intended to facilitate the use of the term in
relation to an officer who has been absent from a post for some time but
still retains a lien on it.

(28)

Probationer.-means an officer employed on probation in or against
a substantive vacancy in the cadre of a department.
Note 1.-The term ‘Probationer’ does not cover an officer who holds substantively a
permanent post in a cadre and is appointed ‘on probation’ to another
post.
Note 2.-No person appointed substantively to a permanent post in a cadre is a
probationer unless definite conditions of probation have been attached to
his appointment such as the condition that he must remain on probation
pending the passing of certain examinations.
Note 3.-The status of a probationer is to be considered as having the attributes of
a substantive status except where the rules prescribe otherwise.
Note 4.-The instructions in Notes 1 and 2 above are to be taken as complementary
and not as mutually exclusive. Taken together, they contain the essence of
the tests for determining when an officer should be regarded as a
“Probationer” or as merely “on Probation”, irrespective of whether he is
already a permanent officer or is merely an officer without a lien on any
permanent post. While a probationer is one appointed in or against a post
substantively vacant with definite conditions of probation, a person on
probation is one appointed to a post (not necessarily vacant substantively)
for determining his fitness for eventual substantive appointment to that
post.

(29)

Public Conveyance.-means a train, steamer, bus, boat or other
conveyance which plies regularly for the co nveyance of
passengers.

(30)

Qualify.-‘Qualify’ and ‘Count’ means qualify and count for pension,
from the General Revenues or for leave of absence, as the case
may be.

(31)

Special Pay.- means an addition of the nature of pay to the
emoluments of a post or of an officer granted in consideration of the
following :-

(a)

where a post would call for a higher scale of pay in view of the
additional and/or higher responsibilities attached to it, or

(b)

where the nature of work is specially arduous ;
or
(c)

where an officer has to attend to work in addition to
normal duties attached to his post.
8

<!-- page 19 -->

CHAP.II]

DEFINITIONS

Note . - When special pay is granted in lieu of a higher time-scale of pay such
special pay will count for purposes for fixation of pay on promotion to a
higher post prov ided the Officer was drawing it continuously for a
minimum period of three years on the date of promotion. Special pay in a
tenure post or special pay drawn on deputation will not, however, be
considered for such fixation of pay.
(32)

Subsistence Allowance.-means a monthly grant made to an officer
who is not in receipt of pay or leave salary.

(33)

Substantive Pay.- means the pay other than special pay, personal
pay or emoluments classed as pay by Government under Rule 12
(23) (ii) and (iii) above to which an officer is entitled on account of a
post to which he has been appointed substantively or by reason of
his substantive position in a cadre.
Note .-When a special pay is granted in lieu of a higher time scale, such special
pay will also count as substantive pay, provided the officer holds a lien on
the post to which the special pay is attached.

(34)

Temporary Post. -means a post carrying a definite rate of pay
sanctioned for a limited time.

(35)

Time-scale of Pay.- means pay which, subject to any conditions
prescribed in these rules, rises by periodical increments from a
minimum to a maximum. It includes the class of pay hitherto known
as progressive:(a)

Time-scales are said to be identical if the minimum, the
maximum, the period of increment and the rate of increment of
the time-scales are identical.

(b)

A post is said to be on the same time-scale as another post on
a time-scale if the two time-scales are identical and the posts
fall within a cadre or a class in a cadre, such cadre or class
having been created in order to fill all posts, involving duties of
approximately the same character or degree of responsibility,
in a service or establishment or group of establishments, so
that the pay of the holder of any particular post is determined
by his position in the cadre or class and not by the fact that he
holds that post.

Note. -Method of calculation of average pay of a post on a time-scale of pay (1) In the case of gazetted appointments on time-scales of pay the following
formula may be applied for ascertaining the average pay :Average pay = (A+B)/2 + (B-A)/2 [1-(R+1) {.014+1- .01R/F-E }]
Where

A = Minimum pay,
B = Maximum pay,
R = Period of rise,
E = Average age at entry in the Grade, and

F = Average age at retirement on superannuation pension.
This may be taken to be 55 in almost every case unless there are
special reasons to take it either at a lower or a higher figure.
(2) In the case of non-gazetted post on time scales of pay, the following
formula is to be applied :Average pay = (A+B)/2+(B-A)/2[1-(R+1) {.021+ (1-.015R /F–E )}]
Where A = Minimum pay,
B = Maximum pay,
R = Period of rise,
9

[G.O.(P) 393/75/Fin.,
dt. 30-8 -1975]

<!-- page 20 -->

KERALA SERVICE RULES

[PART I

E = Average age at entry in the Grade, and
F = Average age at retirement on superannuation pension. This
may be taken to be 55 in almost every case unless there are
special reasons to take it either at a lower or a higher figure.
(3) In cases where one grade is the channel of promotion to another grade,
that is to say where everybody in the lower grade is ultimately promoted
to the higher grade, the following formula may be adopted to find the
average cost of appointments in the lower grade :-

[G.O.(P) 52/65/Fin.,
dt. 3-2-1965]

Average pay =A+C/2+(C -A)/2[1-(S+1) {0.006+(1-0.004S)/G - E }]
Where A = Minimum pay,
C = Pay just before promotion to the higher grade,
S = Period of rise from A to C,
E = Average age at entry in the lower grade, and
G = Average age at the time of promotion to the higher grade.
(4) If the average pay worked out by any of the methods prescribed, falls
below the minimum of the time-scale plus one forth of the difference
between the minimum and maximum of the time scale, the average of
the minimum and the maximum of the time-scale shall be taken as the
average pay.

[G.O.(P) 359/76/Fin.,
dt. 23 -11-1976]

Government Decision
A scale of pay is reckoned as higher time-scale on the
following principles : according to the higher maximum,
if the maximum is the same, according to the higher minimum,
and
if the maximum and the minimum are the same according to
the rate of increment.
(36)

Transfer.- means the movement of an officer from one headquarter
station in which he is employed to another such station, either,
(a) to take up the duties of a new post, or
(b) in consequence of a change of his headquarters.

(37)

Travelling Allowance.- means an allowance granted to an officer to
cover the expenses which he incurs in travelling in the interest of
the public service. It includes allowances granted for the
maintenance of conveyances.
Government Decision
The expressions ‘road mileage’ and ‘mileage allowance’
wherever they occur, shall be assigned meaning as referring to
‘distance in kilometres’.
CHAPTER III
GEN ER AL CO NDI TIO NS O F S ERV ICE

13.

Except as provided by this rule, no person may be appointed to a
post in Government service without his producing a medical
certificate of health in the form annexed below. The Government
may, in individual cases, dispense with the production of a
certificate, and may by general orders exempt any specified class
of officers from the operation of this rule.

10

[G.O.(P) 36/64/Fin.,
dt. 20-1 -1964]

<!-- page 21 -->

CHAP.III]

GENERAL CONDITIONS OF SERVICE

FORM
I do hereby certify that I have examined A B, a candidate
for employment in the ……………………… Department, and cannot
discover that he has any disease, constitutional affection or bodily
infirmity except…………… I do not consider this a disqualification
for employment in the office of………………………..
A B’s age is according to his own statement x years and
by appearance y years.
A B
smallpox.

has

been

re-vaccinated/vaccinated

or

has/had

Note 1. -The certificate prescribed above must ordinarily be signed by a Civil
Medical Officer of rank not lower than a Civil Surgeon or Honorary Medical
Officer of Civil Surgeon’s rank or the Director of Indigenous Medicine,
but in the case of a person whom it is proposed to appoint to a post the
maximum pay of which is not more than *Rs.1050 and who cannot
conveniently be brought before an officer of higher rank, a certificate from
an Assistant Surgeon with M.B.B.S. degree may, at the discretion of the
appointing authority, be accepted.
*This amendment shall be deemed to have come into force with
effect from 1st April 1985.
Note 2.- An officer, in whom a defect has been noticed by the Medical Officer who
granted him his first certificate of health, may not be transferred from the
office to which he was originally appointed, to another office, the duties of
which are different in character, except on production of another
certificate from a competent authority to the effect that the defect will not
materially interfere with the discharge of his new duties by reason of such
transfer.
Note 3. -The following classes of officers are exempted from producing a medical
certificate of health :(1) an officer recruited through a competitive examination who had to
undergo medical examination in accordance with regulations prescribed
for appointment to service under Government;
(2) an officer in service other than the last grade appointed in a temporary
vacancy of less than three months duration;
(3) an officer in the last grade appointed in a temporary vacancy of less
than six months duration ;
(4) a temporary officer who has already been medically examined in one
office if transferred to another office without a break in service subject to
the provision of Note 2 above;
(5) a retired officer re-employed immediately after retirement.
Note. - 4-(a) The production of a medical certificate is necessary when(i) an officer is promoted from non-qualifying service paid from a
Local Fund to a post in Government service other than last grade;
(ii) a person is re-employed after resignation or forfeiture of past
service;
(b) when a person is re-employed in circumstances other than those
referred to in clause (a) (ii) above the appointing authority will decide
whether a medical certificate should be produced.
Note 5.-Once a person is asked to produce a medical certificate of fitness for entry
into Government service whether in a temporary or permanent capacity
and has actually been examined and declared unfit, it is not open to the
appointing authorities subordinate to Government to use their discretion to
ignore the certificate that has been produced.
11

[G.O.(P) 1109/87/Fin.,
dt. 23 -12-1987]

<!-- page 22 -->

KERALA SERVICE RULES

Government Decision
The question of laying down appropriate rules to govern
the Medical Examination of candidates recruited to Government
service was considered by Government. After taking into account
all the relevant aspects of the question, the following rules have
been laid down in this behalf:
1. Normally a candidate should be medically examined before his
first appointment. In certain cases, however, when a candidate
is required to join immediately for work or for training, the
appointment may be made without first obtaining the medical
certificate, though the appointment should be subject to the
officer being declared medically fit. In all such cases, if an
officer is declared unfit on medical examination and he prefers
an appeal he should be retained in service till the case is finally
decided.
2. Similarly, in the case of a Government servant whose
appointment is made on a temporary basis on the strength of a
medical certificate issued by a lower authority or without such a
certificate, it may be necessary to get a certificate of fitness
from the appropriate medical authority. If the appropriate
medical authority finds that the person is not fit for retention in
service at all and if an appeal for a second medical examination
from the Government servant concerned is accepted the person
concerned should be allowed to continue in service till the
verdict of appropriate medical authority is known. In case it is
decided not to accede to the request for further medical
examination, the services of the officer should be terminated
forthwith.
3. The intimation regarding unfitness of a candidate should
immediately on receipt be communicated to the person
concerned with a note that appeal, if any, must be made by the
candidate/ Government servant concerned within one month of
the communication of the findings of the Medical Officer and
that, if any, Medical certificate is produced as piece of evidence
about the possibility of an error of judgement in the decision of
the Medical Officer who examined him, in the first instance, the
certificate must contain a note by the Medical Officer concerned
to the effect that it has been given in full knowledge of the fact
that the candidate has already been rejected as unfit for service
by a Medical Officer.
4.

In case no appeal (with requisite evidence in support of his
case) is preferred by the candidate/ Government servant within
one month of the date of communication to him of the findings
of the Medical Officer, his services should be terminated
forthwith on the expiry of the period of one month and ordinarily
no appeal should be allowed after the expiry of that period.

5. In case where a Government servant or a candidate for
Government service is declared unfit for retention in
Government service or appointment in the Government service
by a Medical Officer, the grounds for rejection may be
communicated to him in broad terms without giving minute
details regarding the defects pointed out by the Medical Officer.
Cases where the grounds of rejection have not been clearly
stated by the Medical Officer, in his report, may be referred to
the Government for advice.
6. For the first Medical Examination of the candidate/ Government
servant as well as the subsequent examinations found
necessary by the appointing authority on account of an appeal,
12

[PART I

<!-- page 23 -->

CHAP.III]

GENERAL CONDITIONS OF SERVICE

the appointing authority shall give suitable requisition to the
Medical Officer concerned.
7. No appeal shall lie against the adverse findings of a Medical
Officer to whom the case is referred on appeal.
Note 1. - Certificate of physical fitness for entry into Government service should
always be from Medical Practitioners of Modern Medicine or from Doctors
of Indigenous Medicine.
Note 2. - The Medical Authority who is to issue a medical certificate a second time
on appeal shall be of a higher status than the other who issued the first
medical certificate.
Note 3. - When a final certificate has been issued either by the Director of Health
Services, or by the Director of Indigenous Medicines, that certificate will
be final and no appeal will be permitted [Vide G.O.(P) 1034/61/Pub.
(Ser.D), dated 2nd December 1961 and G.O.(P) 570/62/Pub. (Ser. D),
dated 25th October 1962]
14.

[G.O.(P) 343/63/Fin.,
dt. 7-6-1963]

Unless in any case it be otherwise distinctly provided, the whole
time of an officer is at the disposal of the Government which pays
him and he may be employed in any manner required by proper
authority, without claim for additional remuneration, whether the
services required of him are such as would ordinarily be
remunerated from the General Revenues of India or of the States or
the Revenues of a Local Fund or from the funds of a Body,
incorporated or not , which is wholly or substantially owned or
controlled by the Government.
Note 1. -Every officer must attend the office punctually. For every three day’s late
attendance without permission, an officer will forfeit a day’s casual leave
for which he is eligible. The computation of the forfeiture of a day’s casual
leave will be with respect to the calendar year and late attendance without
permission for less than three days at the end of a calendar year will be
ignored.
Note 2. -No other kind of leave except casual leave shall be forfeited for late
attendance without permission. Disciplinary action under the Kerala Civil
Services (C.C and A.) Rules, 1960 may be taken against the officers
concerned for late attendance without permission if there is no casual
leave to be forfeited.

14 A.

[Deleted]
This amendment shall be deemed to have come into force
with effect from 3rd February, 1988.

15.

[G.O.(P) 593/70/Fin.,
dt. 20-8 -1970]

(a)

Two or more officers cannot be appointed substantively to the
same permanent post at the same time.

An officer cannot be appointed substantively, except as a
temporary measure, to two or more permanent posts at the same
time.
An officer cannot be appointed substantively to a post on which
(c)
another officer holds a lien.
(b)

16.

Unless in any case it be otherwise pro vided in these rules, an
officer on substantive appointment to any permanent post acquires
a lien on that post and ceases to hold any lien previously acquired
on any other post.

17.

Unless his lien is suspended under Rule 18 or transferred under
Rule 20 an officer holding substantively a permanent post retains a
lien on that post(a) while performing the duties of that post;

13

[G.O.(P) 549/88/Fin.,
dt. 31-8 -1988]

<!-- page 24 -->

KERALA SERVICE RULES

[PART I

(b) while on foreign service or holding a temporary post, or officiating in
another post;
(c) during joining time on transfer to another post, unless he is
transferred substantively to a post on lower pay, in which case his
lien is transferred to the new post from the date on which he is
relieved of his duties in the old post;
(d) while on leave;
(e) while under suspension; and

18.

(f) while under training.
The Government shall suspend the lien of an officer on a
(a)
permanent post which he holds substantively if he is appointed in
a substantive capacity—
(1) to a permanent post outside the cadre on which he is borne, or
(2) provisionally to a post on which another officer would hold a
lien had his lien not been suspended under this rule.
(b) The Government may, at their option, suspend the lien of an officer
on a permanent post which he holds substantively, if he is
transferred to foreign service or in circumstances not covered by
clause (a) of this rule, is transferred, whether in a substantive or
officiating capacity to a post in another cadre, and in any of these
cases there is reason to believe that he will remain absent from the
post on which he holds a lien for a period of not less than three
years.
Ruling
The lien of an officer on a permanent post should not be
suspended when he is appointed to a higher post in a different
cadre, in case the higher post falls within the regular line of
promotion from the lower post.
(c) if an officer’s lien on a post is suspended under clause (a) or (b) of
this rule, the post may be filled substantively, and the officer
appointed to hold it substantively, shall acquire a lien on it; provided
that the arrangements shall be reversed as soon as the suspended
lien revives.
Note. -When a post is filled substantively under this clause, the appointment will be
termed a provisional appointment, the officer appointed will hold a
provisional lien on the post and that lien will be liable to suspension under
clause (a) but not under (b) of this rule.
(d) an officer’s lien which has been suspended under clause (a) of this
rule shall revive as soon as he ceases to hold a lien on a post of
the nature specified in sub-clause (1) or (2) of that clause.
(e) an officer’s lien which has been suspended under clause (b) of this
rule shall revive as soon as he ceases to be on foreign service or to
hold a post in another cadre, provided that a suspended lien shall
not revive because the officer takes leave, if there is reason to
believe that he will on return from leave, continue to be on foreign
service or to hold a post in another cadre and th e total period of
absence on duty will not fall short of three years or that he will hold
substantively a post of the nature specified in sub-clause (1) or
(2) of clause (a).
Note. -When it is known that an officer on transfer to post outside his cadre is due
to retire on superannuation pension within three years of his transfer, his
lien on the permanent post cannot be suspended.

14

[G.O.(P) 102/66/Fin.,
dt. 25-3 -1967]

<!-- page 25 -->

CHAP.III]

19.

GENERAL CONDITIONS OF SERVICE

(a) An officer’s lien on a post may in no circumstances be terminated,
even with his consent, if the result will be to leave him without a lien
or a suspended lien upon a permanent post.
(b) In a case covered by sub-clause (2) of clause (a) of Rule 18, the
suspended lien may not, except on the written request of the officer
concerned, be terminated while the officer remains in Government
service; provided that it shall be open to the competent authority to
refuse consent for the confirmation or retention of an officer in a
permanent post outside the cadre on which he is borne unless he
makes a written request that his lien on the permanent post in his
parent office should be terminated.

20.

Subject to the provisions of Rule 21 the Government may transfer
to another permanent post in the same cadre the lien of an officer
who is not performing the duties of the post to which the lien
relates, even if that lien has been suspended.

21.

(a) The Government may transfer an officer from one post to another;
provided that, except(1) on account of inefficiency or misbehavior, or
(2) on his written request,
an officer shall not be transferred substantively to, or
except in a case covered by Rule 58, appointed to officiate in a
post carrying less pay than the pay of the permanent post on which
he holds a lien, or would hold a lien had his lien not been
suspended under Rule 18.
(b) Nothing contained in clause (a) of this rule or in clause (18) of Rule
12 shall operate to prevent the transfer of an officer to the post on
which he would hold a lien, had it not been suspended in
accordance with the provisions of clause (a) of Rule 18.
Note. - Permanent transfers from a higher to lower scale in anticipation of the
abolition of a post are not transfers within the meaning of the above rule.

22.

An officer may be required to subscribe to a provident fund, a
family pension fund or similar fund in accordance with such rules as
the Government may by order prescribe.
Note 1. - An officer who has entered service before the 19th August, 1976, may,
however, opt to subscribe for a policy in the official Branch of the State
Life Insurance instead of the Provident Fund.
Note 2. -Officers who are subscribers to the Family Benefit Scheme, going on
deputation/foreign service shall continue to subscribe to the Family Benefit
Scheme and they themselves shall arrange for effecting recovery and
remittance of the amount from their pay.

22A.

th

Every person who enters Government service on or after the 19
August 1976, shall within a period of one year from the date of his
entry in Government service, subscribe to a policy in the official
branch of the State Life Insurance at such rate as may be
determined by the Government from time to time and shall continue
to subscribe till he ceases to be in Government Service.
Note. - When an employee crosses one pay range to the next higher range, he
shall take additional policy within 2 years of his coming to the next higher
pay range. But this condition shall not apply to an employee who has
attained the age of 45 years at the time of crossing over to the next higher
range.

22 B.

[G.O.(P) 83/80/Fin.,
dt. 23-1 -1980]

Every person who enters Government service on or after the 1st
day of September, 1984 shall enrol as a member of the Group
Insurance Scheme.
15

[G.O.(P) 83/80/Fin.,
dt. 23-1 -1980]

<!-- page 26 -->

KERALA SERVICE RULES

This amendment shall be deemed to have come into force with
effect from 1 st September 1984.
23.

[PART I

[G.O.(P) 962/86/Fin.,
dt. 30 -12-1986]

(a) Subject to any exceptions specifically made in these rules, an
officer shall begin to draw the pay and allowances attached to his
tenure of a post with effect from the date he assumes the duties of
that post, and shall cease to draw them as soon as he ceases to
discharge those duties. If the charge is transferred afternoon, the
transfer does not affect pay and allowances until the next day.
Exception.-An officer deputed for a course of instruction or training
which is ordered to be treated as duty, if promoted to a
higher post in the regular line during such course of
instruction or training, may draw the pay thereof,
without joining it, the benefit of promotion being given
from the date his junior assumes charge of the higher
post.
(b) If, however, the substantive appointment of an officer is changed
while he is officiating in an appointment, or if, while so officiating,
an officer is appointed for the first time, to some substantive office,
then, provided that the tenure of his officiating appointment is not
interrupted by his new substantive appointment, he may draw the
pay thereof without joining it from the date on which he is appointed
thereto, or from any later date on which the substantive office
becomes vacant.
(c) Promotions which do not involve a change of duties shall have
effect from the date of the vacancy which occasions the promotion.
Note. - The detailed procedure to be followed when an officer assumes or
relinquishes charge of an office is contained in Appendix III.
Government Decision No. 1
Questions have been raised regarding the authority
competent to accept a resignation, the circumstances under which
resignation should be accepted, the date when a resignation
becomes effective, and the authority competent to permit a
Government servant to withdraw a resignation which he has
already tendered. The following instructions will be followed :
(a)

Authority competent to accept resignation.—The appointing
authority in respect of the service or post in question is the authority
competent to accept the resignation of the Government servant.

(b) Circumstances under which resignation should be accepted.- It is
not in the interest of Government to retain an unwilling officer in
service. The general rule, therefore, is that resignation from service
should be accepted after settling the liabilities outstanding against
the Government servant, except in the circumstances indicated
below:(i)

Where the officer concerned is engaged on work of importance
and it would take time to make alternative arrangements for
filling the post, the resignation should not be accepted
straight away, but only, when alternative arrangements for
filling the post have been made.

(ii) Where a Government servant who is under suspension submits
a resignation, the competent authority should examine with
reference to the merits of the disciplinary case pending
against th e Government servant whether it would be in the
public interest to accept the under suspension. Exceptions
to this rule would be where the alleged offences do not
involve moral turpitude or where the quantum of
16

[G.O.(P) 434/65/Fin.,
dt. 17-1 1-1965]

<!-- page 27 -->

CHAP.III]

GENERAL CONDITIONS OF SERVICE

evidence against the accused officer is not strong enough to
justify the assumption that if the departmental proceedings
were continued, the officer would be removed or dismissed
from service or where the departmental proceedings are likely
to be so protracted that it would be cheaper to the Public
Exchequer to accept the resignation.
(c) Date when a resignation becomes effective.—The competent
authority should decide the date with effect from which the
resignation should become effective. In cases covered by (b) (i)
above the date should be that with effect from which alternative
arrangements can be made for filling the post. Where an officer is
on leave, the competent authority should decide whether he will
accept the resignation with immediate effect or with effect from the
date following the termination of the leave. There is also no
objection to a Government servant on leave being permitted to
resign his post without rejoining duty after leave, provided the
appointing authority so decides with due regard to the
administrative convenience of the department. Where a period of
notice is prescribed which a Government servant should give when
he wishes to resign from service the competent authority may
decide to count the period of leave towards the notice period. In
other cases also it is open to the competent authority to decide
whether the resignation should become effective immediately or
with effect from some prospective date. In the latter case, the date
should be specified.
(d) Authority competent to permit withdrawal of resignation.- A
resignation becomes effective when it is accepted and the officer is
relieved of his duties. Where a resignation has not become
effective and the officer wishes to withdraw it, it is open to the
authority which accepted the resignation either to pe rmit the officer
to withdraw the resignation or to refuse the request for such
withdrawal. Where, however, a resignation has become effective,
the officer is no longer in Government service and acceptance of
the request for withdrawal of resignation would amount to re employing him in service after condoning the period of break.

[G.O.(P) 98/65/Fin.,
dt. 22-3-1965]

Concurrence of ‘Finance’, and the Public Service
Commission, wherever necessary, should be obtained before a
request for withdrawal of resignation which has already become
effective, is accepted.
Government Decision No.2
Condonation of the period of break and revival of past
service in such cases will be for the purpose of pension only, if it is
otherwise admissible. The Government servant’s earlier service will
not count for fixation of pay, increment or leave. His pay will be
fixed at the minimum of the scale of pay of the post to which he is
re-employed after resignation and the period of break will be
treated as a period spent out of employment.
24.

[G.O.(P) 82/66/Fin.,
dt. 3-3-1966]

Unless the Government in view of the special circumstances of the
case, otherwise determine, after five years’ continuous absence
from duty, an officer shall be removed from service after following
the procedure laid down in the Kerala Civil Services (Classification,
Control and Appeal) Rules, 1960, * except in cases covered by
Rule 24A.
*This amendment shall be deemed to have come into force
with effect from 16 th December, 1983.

17

[G.O.(P) 953/86/Fin.,
dt. 27 -12-1986]

<!-- page 28 -->

KERALA SERVICE RULES

*24A.

Notwithstanding anything contained in these rules, if an officer who
availed himself of leave without allowances to take up employment
abroad or within the country **[or for joining spouse] for a total
period of †fifteen years, whether continuously or in broken periods,
does not return to duty immediately on the expiry of the leave, his
service shall be terminated after following the procedure laid down
in the Kerala Civil Services (Classification, Control and Appeal)
Rules, 1960.

[PART I

**[G.O.(P) 1002/97/Fin.,
dt. 6 -11 -1997]

Note. - This rule shall have effect from the 16th day of December, 1983 and shall
apply to all cases of grant of leave without allowances on or after that
date, for taking up employment abroad or within the country, in extension
of the leave already granted or otherwise, and such leave granted before
that date shall be reckoned for applying the †fifteen years limit.
*This amendment shall be deemed to have come into force
th
from 16 December 1983.

*[G.O.(P) 953/86/Fin.,
dt. 27 -12-1986]

†This amendment shall be deemed to have come into
force from 27th December 1986.

† [G.O.(P) 20/93/Fin.,
dt. 5-1-1993]

CHAPTER IV
P AY

25.

26.

Except in the case of personal pay granted in the circumstances
defined in Rule 12 (26) (a), the pay of an officer shall not be so
increased as to exceed the pay sanctioned for his post without
the sanction of Government.
When an officer is treated as on duty under Rule 12 (7) (iii), the
Government may, at their option, authorise payment to him of the
pay of his substantive appointment or of any lower rate of pay
which they may consider suitable, provided that the pay admissible
may, if the Government so direct, be instead of either of the rates
just specified, the pay of any officiating appointment which the
officer would have drawn but for undergoing such training, subject
however to the condition that this rate of pay shall not be allowed
for a period longer than that for which the officer would have held
the officiating appointment had he not been placed on such course
of training.
Note 1.- A reservist of the Defence Services in the employment of the State
Government, when called up for periodical training, receives the pay and
allowances to which he is entitled under the Defence Services. He will also
receive the excess, if any, of his pay under the Government over the pay
under Defence Department. The periods spent in training and on the
journey to and from the place of training will be treated as duty for
purposes of leave, increments and pension.
Note 2.- The expressions “the pay of his substantive appointment” and “the pay of
any officiating appointment” occurring in the above rule should be taken to
mean “the pay which the officer would have drawn in the post which he
holds substantively” and “the pay which the officer would have drawn in
the officiating appointment but for undergoing the training’’. In neither
case, is there any restriction to draw the following kinds of emoluments
which the officer would have drawn in the substantive or officiating
appointment but for the training :
(i)

Basic pay

(ii)

Special pay granted in lieu of a higher time-scale of pay

(iii)

Personal pay
18

[G.O.(P) 434/65/Fin.,
dt. 17 -11-1965]

<!-- page 29 -->

CHAP.IV]

PAY

(iv)

Any other emoluments specially classed as pay and which are
specifically al lowed to be drawn during training

(v)

Dearness pay

(vi)

Dearness allowance

(vii)

House rent allowance

Ruling

An officer holding a provisional appointment deputed for
training where the period of training is treated as duty will be
allowed to draw for the period of training the pay and allowances
attached to the provisional appointment, if it is certified by the
competent authority that the officer would have held the provisional
appointment but for his deputation for training.
27.

Rules 28 to 37 apply to time-scale of pay generally. They do not,
however apply to any time-scale sanctioned by the Government in
so far as they are inconsistent with terms specially so sanctioned
for such time-scale.

28.

The initial substantive pay of an officer who is appointed
substantively to a post on a time-scale of pay is regulated as
follows :
If he holds a lien on a permanent post or would hold a lien
on such a post had his lien not been suspended, he will draw as
initial pay the stage of the time-scale next above his substantive
pay in respect of the old post :
Provided that except in cases of re-employment after
resignation or removal or dismissal from public service, if he either
has previously held substantively or officiated in (i) the same post,
or (ii) a permanent or temporary post on the same time-scale, or (iii)
a permanent post on an identical time-scale or a temporary post
(including a post in a body, incorporated or not, which is wholly or
substantially owned or controlled by the Government) on an
identical time-scale then the initial pay shall not, except in cases of
reversion to the parent cadre governed by item (iii) above be less
than the pay which he drew on the last such occasion and he shall
count the period during which he drew that pay on such last and
any previous occasions for increment in the stage of the time-scale
equivalent to that pay. The service rendered in a post referred to in
item (iii) shall, on reversion to the parent cadre, count towards initial
fixati on of pay, to the extent and subject to the conditions indicated
below:(a)

The officer should have been approved for appointment to the
particular grade/post in which the previous service is to be
counted;

(b)

All his seniors, except those regarded as unfit for such
appointment, were serving in posts carrying the scale of pay in
which the benefit is to be allowed or in higher posts, whether
in the department itself or elsewhere, and at least one junior
was holding a post in the department carrying the scale of pay
in which the benefit is to be allowed; and

(c)

the service will count from the date his junior is promoted and
the benefit will be limited to the period the officer would have
held the post in his parent cadre had he not been appointed to
the ex-cadre post.

Note 1. - The provisions in the above rule apply in cases of substantive
appointments to higher time-scales of pay only. In other cases the officer’s
pay in the new appointment shall be fixed at his pay in the previous
19

<!-- page 30 -->

KERALA SERVICE RULES

[PART I

appointment, if it is a stage in the new scale or at next lower stage, if it is
not a stage in the new scale, the difference being treated as personal pay,
such personal pay, being absorbed in future increases of pay. This will
not, however, apply to cases of reversions.

28A

Note 2.- The provisions in item i(ii) of the proviso to the above rule in respect of
protection of pay and period of increment shall be applicable to
Government servants on their appointment directly or on transfer from a
post carrying identical time-scale of pay w ithout fulfilment of the conditions
indicated thereunder subject to the condition that this benefit will not be
admissible to an individual who enters Government service for the first
time from a post in a body incorporated or not which is wholly or
substantially owned or controlled by Government.
Notwithstanding anything contained in these rules, where an officer
holding a post in a substantive, temporary or officiating capacity is
promoted or appointed in a substantive, temporary or officiating
capacity to another post carrying a higher time-scale of pay, his
initial pay in the higher time-scale of pay, shall be fixed at the stage
next above the pay notionally arrived at in the lower time-scale of
pay by increasing the actual pay drawn by him in the lower timescale by one increment. A refixation of pay will be allowed
whenever there is a change of pay in the lower time-scale.
This rule shall be deemed to have come into force with
rd
effect from 3 February 1962.
Provided that the provisions of this rule shall not apply to
promotions from posts carrying a scale of pay the minimum pay of
which exceeds *Rs.2,640
*This amendment shall be deemed to have come into force
st
with effect from 1 July, 1988.

[G.O.(P) 1005/92/Fin.,
dt. 27 -11 -1992]

The limit of Rs.550 has been revised to Rs.650 with effect
from 1st January 1966 [G.O. (P) 261/67/Fin., dated 4th July 1967,
G.O.(P) 91/68/Fin., dated 5th March 1968] and Rs.650 to Rs.900
st
th
with effect from 1 July 1968 [G.O. (P) 173/70/Fin., dated 20
st
March 1970] and from Rs.900 to Rs.1200 with effect from 1 July
st
1973 [G.O. (P) 136/75/Fin., dated 1 April 1975 and from Rs.1,200
st
to Rs.1,550 with effect from 1 July 1978[G.O.(P) 493/79/Fin.,
th
dated 28 May 1979] and from Rs.1550 to Rs.2100 with effect from
st
rd
1 July, 1983 [G.O.(P) 1109/87/Fin. dated 23 December 1987]
st
and from Rs.2100 to Rs.2640 with effect from 1 July 1988
th
[G.O.(P) 1005/92/Fin. dated 27 November, 1992]

[G.O.(P) 624/84/Fin.,
dt. 29 -10 -1984]

Provided also that where a Government servant is
immediately before his promotion or appointment to a higher post,
drawing pay at the maximum of the time-scale of the lower post, his
initial pay in the time-scale of the higher post shall be fixed at the
stage next above the pay notionally arrived at by increasing his pay
in respect of the lower post by an amount equal to the last
increment in the time-scale of the lower post.

[G.O.(P) 348/75/Fin.,
dt. 1-8-1975]

Effective from the date of orders.
Provided that if he has either previously held substantively
or officiated in (i) the same post or (ii) a permanent or temporary
post on the same time-scale or (iii) a permanent post on an
identical time-scale or a temporary post on an identical time-scale,
such post being on the same time-scale as a permanent post, then
the initial pay shall not be less than the pay which he drew, on the
last such occasion and he shall count for increment the period
during which he drew that pay on such last or any previous
occasions.
This amendment shall be deemed to have come into force
20

[G.O.(P) 710/70/Fin.,
dt. 5-10-1970]

<!-- page 31 -->

CHAP.IV]

PAY
st

with effect from 21 July 1964.
Ruling No.1
In cases where the application of the rule would give rise to
anomalies in as much as an officer officiating in a higher post coul d
get his pay refixed at a stage higher than the pay drawn by another
who stands confirmed in the higher post on the same scale of pay,
the anomaly will be removed by refixing the pay of the senior officer
at the stage equal to that fixed for the junior officer in the higher
post, the orders of refixation being issued by the competent
authority under Rule 34, Part I, Kerala Service Rules. The refixation
of pay in such cases will be made subject to the following
conditions:
(a)

Both the junior and senior officers should belong to the same
cadre and the post in which they have been promoted or
confirmed, as the case may be, should be identical and in the
same cadre.

(b)

The scale of pay of the lower post in which they would have
drawn their pay but for their promotion or confirmation should
be identical.

(c)

The anomaly should be directly as a result of the application
of Rule 28A. For example, if the junior officer draws from time
to time a higher rate of pay than the senior by virtue of fixation
of pay under the normal rules or any advance increment
granted to him, the provision contained in this ruling should
not be involved to step up the pay of the senior officer.
The refixation of pay of the senior officer should be done with
effect from the date of refixation of pay of the junior officer.
The next increment of the senior officer will however be drawn
on the date on which it would have fallen due but for this
refixation of pay.

(d)

Ruling No.2
In the case of a Government servant, officiating in a pos t
and whose pay had been refixed under this rule, if he is confirmed
in that post with effect from a retrospective date, the refixation of
pay done after the date of confirmation will have to be revised. The
over payments consequent on such revision will first be set off
against the arrears, if any, that might become payable to the
Government servant for a portion of the period from the date of
confirmation to the date of issue of orders of confirmation. The
balance of overpayments that cannot be set off against the arrears,
if any, shall be waived.

[G.O.(P) 24/65/Fin.,
dt. 13-1-1965]

This Ruling will be deemed to have come into force with
rd
effect from 3 February 1962.
Ruling No. 3
The refixation of pay in the higher officiating post on the
date of change of pay in the lower time-scale contemplated in this
rule cannot be allowed during the period of bar on increment with or
without cumulative effect. But, in the cases of bar on increment
without cumulative effect there is no objection to give the refixation
on a notional basis and to give the monetary benefit after the expiry
of the period of bar. Increments accruing in the lower
substantive/officiating post from time to time cannot also be allowed
during the period of bar.

[G.O.(P) 650/72/Fin.,
dt. 12 -12-1972]

Ruling No 4
Increments barred with or without cumulative effect in the
lower substantive officiating post shall not be reckoned for
21

[G.O.(P) 150/77/Fin.,
dt. 17-5 -1977]

<!-- page 32 -->

KERALA SERVICE RULES

[PART I

fixation/refixation of pay in the higher time-scale. But in the case of
bar on increment without cumulative effect, there is no objection to
grant the barred increments notionally for fixation/refixation of pay
and to give the monetary benefit after the expiry of the period of
bar.
Ruling No. 5
A revision of pay as contemplated in Ruling No. 2 shall not
be necessary in the case of retrospective confirmation ordered after
the date of retirement of an officer.

[G.O.(P) 79/75/Fin.,
dt. 3-3-1975]

rd

This ruling will be deemed to have taken effect from 3
February 1962.
Government Decision No. 1

1. The provisions of this rule will not apply to cases of revision of
scales of pay referred to in Rule 30 ibid.
2. An officer officiating in a post, when appointed to a higher post
on the advice of the Public Servi ce Commission or otherwise is
eligible for his initial pay being fixed under this rule and is also
entitled to the benefit of a refixation contemplated in the last
sentence of the rule.

G.O.(P) 475/90/Fin.,
dt. 25-9-1990]

st

Effective from 31 October, 1986.
3. When a person who holds a post in a regular capacity is
appointed to a post on a higher time-scale in the same service
under Rule 31 or in a different service under Rule 9 of Kerala
State and Subordinate Services Rules, fixation of pay under
this rule is permissible with reference to the pay drawn in the
regular appointment.
4. When a fresher is appointed provisionally to a post otherwise
than on the advice of the Public Service Commission, under
Rule 9 of Kerala State and Subordinate Service Rules and
again appointed to a still higher post under the same rule, a
fixation of pay in the higher post with reference to the pay drawn
in the lower post is not admissible.
5. A person holding a post in a regular capacity is appointed
provisionally to a post in the same service under Rule 31 of the
Kerala State and Subordinate Service Rules. He is again
appointed to a still higher post in the same service under Rule
31 or to a post in another service under Rule 9 of Kerala State
and Subordinate Services Rules. Fixation of pay with reference
to the provisional pay drawn in the post to which he was
appointed provisionally at first is not admissible in the other
posts.
[The decisions 1,3,4 and 5 above will be deemed to have taken
rd
effect from 3 February 1962, the date on which the rule came
into force]

[G.O.(P) 6/65/Fin.,
dt. 4-1-1965]

6. The pay drawn by an officer in an ex-cadre post can be counted
for purpose of initial fixation of pay on promotion in the parent
department. But the benefit of refixation of pay contemplated in
the rule is not admissible to him as he loses connection with the
ex-cadre post on appointment to the parent department.

[G.O.(P) 580/70/Fin.,
dt. 13-8 -1970]

7. The benefit of pay drawn in an ex-cadre post for purpose of initial
fixation will not be admissible, if an officer is reverted to the
parent department, to a post carrying a scale of pay lower than
that of the ex-cadre post.

[G.O.(P) 223/77/Fin.,
dt. 14 -7- 1970]

22

<!-- page 33 -->

CHAP.IV]

PAY

Government Decision No. 2
The benefit of refixation of pay contemplated in the last
sentence in the first para of the rule is admissible even in cases
where the change of pay is due to fixation of pay on account of
revision of scale of pay. If both the lower and the higher time-scales
are revised, the benefit will be restricted to the cases of options
exercised in respect of both the posts simultaneously.
Government Decision No. 3
Notional increment at the biennial increment shall be
reckoned in the lower scale for fixation of pay in the higher scale
under Rule 28A.

[G.O.(P) 458/75/Fin.,
dt. 26-9 -1975]

This decision shall be deemed to have come into force with
st
effect from 1 July 1973.
Government Decision No. 4
The benefit of reckoning notional increment beyond the
maximum of the scale of pay of the lower post will also be
admissible in cases where an employee reaches the maximum of
the post in the lower time-scale of pay before he gets an increment
in the scale of pay of the higher post and in such cases, he will be
eligible for a refixation consequent on the change of pay in the
lower time-scale.

[G.O.(P) 274/78/Fin.,
dt. 14 -3 -1978]

This decision shall be deemed to have come into force with
effect from 1st August 1975.
Government Decision No. 5
[Deleted]
The amendment shall be deemed to have come into force
th
with effect from 25 June, 1986.
29.

The initial substantive pay of an officer who is appointed
substantively to a post on a time-scale of pay which has been
reduced for reasons other than a diminution in the duties or
responsibilities attached to posts thereon and who is not entitled to
draw pay on the time-scale as it stood prior to reduction, is
regulated by Rule 28.

30.

The holder of a post, the pay of which is changed, shall be treated
as if he were transferred to a new post on the new pay; provided
that he may at his option retain his old pay until the date on which
he has earned his next or any subsequent increment in the old
scale, or until he vacates his post or ceases to draw pay in that
time-scale. The option once exercised is final.
Note 1.-This rule applies to an officiating holder of a post as well. But any break in
the officiating period such as that due to transfer to another post, or nonemployment would operate as vacating of the post and the pay during a
subsequent officiating period in the same post will be fixed only as if the
officer was then appointed to the new scale of pay. ‘The holder of a post’
occurring in this rule applies also to a person who is not actually holding
the post, the pay of which is changed, provided he has a lien or a
suspended lien on that post.
The words ‘his old pay’ in the proviso of the rule should be
held to include not only the rate at which the individual was drawing
his officiating pay on the crucial date but also the time-scale of pay
in which he was drawing that pay. Thus for the period of option the
old scale of pay in which he was drawing his officiating pay should
be treated as continuing for the individual concerned.
23

[G.O.(P) 475/90/Fin.,
dt.25-9-1990]

<!-- page 34 -->

KERALA SERVICE RULES

[PART I

Note 2.- Option under the proviso of the rule to officers under suspension is
governed by the following :Cases in which the revised scale of pay takes effect from a date prior to the
date of suspension.
In such cases the officer should be allowed to exercise the option under
Rule 30 even if the period, during which he is to exercise the option, falls within
the period of suspension. He will be entitled to the benefit of increase in pay if any,
in respect of the duty period before suspension, and also in the subsistence
allowance, for the period of suspension, as a result of such option.
1.

2.

Cases in which the revised scale of pay takes effect from a date falling within
the period of suspension—
(a) Under suspension an officer retains a lien on his substantive post. As
the expression ‘holder of a post’ occurring in Rule 30 includes also a
person who holds a lien or a suspended lien on the post even though he
may not be actually holding the post, such an officer should be allowed
option under Rule 30 even while under suspension. The benefit of
option will however, practically accrue to him in respect of the period of
suspension, only after his reinstatement, depending on the fact whether
the period of suspension is treated as duty or not.
(b) An officer, who does not retain a lien on a post the pay of which is
changed, is not entitled to exercise the option under Rule 30. If,
however, he is reinstated in the post and the period of suspension is
treated as duty, he may be allowed to exercise the option after such
reinstatement. In such cases, if there is a time-limit prescribed for
exercising the option and such period had already expired during the
period of suspension, a relaxation may be made in each individual case
for extending the period during which the option may be exercised.

Government Decision
The following principles will be followed for fixation of pay
when the scale of pay of a post held on a provisional basis is
revised :(i) If the pay drawn in the previous scale is less than th e
minimum of the revised scale then the pay in the
revised scale may be fixed at the minimum.
(ii) If the pay drawn in the previous scale is a stage in the
revised scale the pay in the revised scale may be fixed
at that stage.
(iii) If the pay drawn in the previous scale is not a stage,
then the pay in the revised scale may be fixed at the
next lower stage, the difference being treated as
personal pay to be absorbed in future increase in pay.
2.

3.

The above principles will also be adopted for regulating the pay
of an officer holding a post on a provisional basis when
appointed to a higher or a lower post provisionally, except in
cases of reversion.
Past cases settled otherwise, will not be re-opened.

[G.O.(P) 297/66/Fin.,
dt. 5-7-1966]

Ruling No.1
If an officer earns increment earlier than or after the original
date on which he was supposed to get it at the time of exercise of
option under the above rule due to revision of the date of
increment, his pay should automatically be re-fixed with effect from
the revised date of increment with reference to the original option
exercised by him under this rule and there will be no need for
exercising a fresh option and issue of special orders for this.
Ruling No.2
24

[G.O.(P) 364/67/Fin.,
dt. 14 –8-1967]

<!-- page 35 -->

CHAP.IV]

PAY

The pay of an officer when the post held by him is
upgraded will be regulated as follows :

31.

(i)

If the competent authority specifically orders that the
appointment of an officer to the upgraded post involves
an enhancement of duties and higher responsibilities
and is therefore a promotion, pay will be fixed under
Rule 28, 28A or 37 (a) of Part I, Kerala Service Rules,
as the case may be.

(ii)

In other cases, pay will be fixed under Rule 37 (a), Part
I Kerala Service Rules.

[G.O.(P) 522/81/Fin.,
dt. 21 -8 -1981]

An increment shall ordinarily be drawn as a matter of course unless
it is withheld. An increment may be withheld from an officer by the
Government or by any authority to whom the Government may
delegate this power under Rule 9 if his condu ct has not been good
or his work has not been satisfactory. In ordering the withholding of
the increment, the withholding authority shall state the period for
which it is withheld and whether the postponement shall have the
effect of postponing future increments.
Note 1.- An officer shall not be eligible for an increment unless he has acquired
the obligatory departmental test qualifications, if any, prescribed by
Government from time to time to earn the increment.
Note 2.- A competent authority may order the deferring of the increment of an
officer, pending investigation into his conduct or performance of work, in
disciplinary cases. Such deferring of increment will not be construed as
‘withholding of increments’ under the Kerala Civil Services (Classificati on,
Control and Appeal) Rules, 1960.
Government Decision No. 1
An increment shall be granted from the first day of the
month in which it falls due.

[G.O. (P) 154/74/Fin.,
dt. 8-7-1974]

This decision shall be deemed to have come into force with
effect from 1st April 1974.
Government Decision No.2
Increment accruing consequent on declaration of probation
shall be drawn only with effect from the date of completion of
probation but subsequent increment shall be drawn on the first day
of the month in which they fall due.

[G.O. (P) 133/75/Fin.,
dt. 31-3-1975]

This decision shall be deemed to have come into force with
st
effect from 1 April 1974.
Ruling
In cases where penalties of withholding of increments are
imposed on an officer, one after another, in separate disciplinary
cases, the effect of the first order withholding increment will
continue for the period specified in that order. There after, the pay
will be fixed by granting the increments which would have been
admissible, but for the imposition of penalty and only then will the
second order withholding increment be implemented, which will
continue to be in force for the period specified therein, and so on.
32.

Where an efficiency bar is prescribed in a time-scale, the increment
next above the bar shall not be given to an officer without the
specific sanction of the authority empowered to withhold
increments.
Note 1.- On each occasion on which an officer is allowed to pass an efficiency bar
which had previously been enforced against him, he should come over to
the time-scale at such stage as the authority competent to declare the bar
25

[G.O.(P) 329/84/Fin.,
dt. 5-7-1984]

<!-- page 36 -->

KERALA SERVICE RULES

[PART I

removed, may fix for him, subject to the pay admissible according to his
length of service.
Note 2.- The cases of all officers held up at an efficiency bar should be reviewed
annually with a view to determine whether the quality of their work has
improved and generally, whether the defects for which they were stopped
at the bar have been remedied, to an extent sufficient to warrant the
removal of the bar.
33.

The following provisions prescribe the conditions on which service
counts for increments in a time-scale :(a)

All duty in a post on a time-scale counts for increments in that timescale.
Ruling
Periods of service in a post on a time-scale at the same
stage of pay only will count for increment in that time-scale.

[G.O. (P) 235/80/Fin.,
dt. 7-4-1980]

The above ruling will be deemed to have come into force
st
with effect from 1 November 1959.
(b)

(1)

Service in another post other than a post carrying less pay
referred to in clause (a) of Rule 21, whether in a substantive or
officiating capacity, service on deputation and leave except
leave without allowances taken otherwise than on medical
certificate shall count for increments in the time-scale
applicable to the post on which the officer holds a lien as well
as in the time-scale applicable to the post or posts, if any, on
which he would hold a lien had his lien not been suspended.

All leave except leave without allowances taken otherwise
than on medical certificate and service on deputation count for
increments in the time-scale applicable to a post in which an
officer was officiating at the time he proceeded on leave or
deputation and would have continued to officiate but for his
proceeding on leave or deputation:
Provided that the leave without allowances under Rule 91 A
shall count for increments subject to the following conditions :-

[G.O.(P) 544/62/Fin.,
dt. 8-11-1962]
&
G.O.(P) 81/64/Fin.,
dt. 21-2-1964]

(2)

1.

The period qualifying for increments shall be restricted
to the normal period required for completion of the
course, and

2.

Increments shall be granted only on production of the
diploma or degree or completion of the course.

[G.O.(P) 204/76/Fin.,
dt. 15-7-1976]

Provided further that the Government shall have power in
any case in which they are satisfied that the leave without
allowances was taken for any cause beyond the officer’s control, to
direct that leave without allowances shall be counted for
increments under sub -clause (1) or (2).
*Provided also that leave without allowances taken by
teachers for completion of training courses such as B.Ed., Hindi
Teachers’ Training, Language Teachers’ Training and Teachers’
Training Certificate Course shall count for increment.
*This proviso shall be deemed to have come into force with
effect from 17th June 1980.

[G.O.(P) 305/82/Fin.,
dt. 18-6 -1982]

*Provided also that leave without allowances taken without
production of medical certificate in continuation of maternity leave
in accordance with the proviso to Rule 102 will count for increment’.
*This proviso shall be deemed to have come into force with
effect from 5 th June, 1978.
26

[G.O.(P) 14 5/86/Fin.,
dt. 11-2 -1986]

<!-- page 37 -->

CHAP.IV]

PAY

Note. - In cases coming under sub-clause (2) the appointing authority should certify
that the officer would have actually continued to officiate in the post but for
his proceeding on leave and the period of leave will count for increments
only to the extent it is covered by the certificate. Where no officiating
arrangement is made in a leave vacancy and where the incumbent is likely
to return to the same post after the expiry of the leave the authority
sanctioning the leave may issue such a certificate at the time of grant of
leave. In all cases where the certificates are issued the fact should be
recorded in the Service Book as and when such certificates are issued
along with the leave particulars.
(c)

If an officer, while officiating in a post or holding a temporary post
on a time-scale of pay, is appointed to officiate in a higher post or to
hold a higher temporary post, his officiating or temporary service in
the higher post shall, if he is re-appointed to the lower post or is
appointed or re-appointed to a post on the same time-scale of pay,
count for increments in the time-scale applicable to such lower
post.
If an officer on reversion from an ex-cadre post to the
parent cadre is appointed to a post on a scale lower than that of the
ex-cadre post but not on the same time-scale as the post held at
the time of his transfer to the ex-cadre post, the service rendered
on the higher scale in the ex-cadre post shall count for increments
in the time-scale applicable to the cadre post subject to the same
conditions as are laid down for cases falling under item (ii) of
proviso to Rule 28.
Exception -. In cases where the appointment is to officiate in a
higher post or to hold a higher temporary post, in the
regular line, the officiating and temporary service in the
higher post shall count for increments in time-scale
applicable to the lower post, even if the officer is not re appointed to the lower post or is not appointed or re appointed to a post on the same time-scale of pay.
The period of officiating/temporary service in the higher post
which counts for increment in the lower is, however, restricted to
the period during which the officer would have officiated in the
lower post but for his appointment to the higher post. This clause
applies also to an officer who is not actually officiating in the lower
post, but who would have so officiated in such lower post or in a
post on the same time-scale of pay had he not been appointed to
the higher post.
Note. - For the purpose of this rule, the officiating and temporary service in the
higher posts will include the period of leave which counts for increments
under clause (b).

[G.O.(P) 97/70/Fin.,
dt. 3-2-1970]
&
[G.O.(P)56/72/Fin.,
dt. 1-3-1972]

(d)

If an officer’s substantive tenure of a temporary post is interrupted
by duty in another post other than a post carrying less pay referred
to in clause (a) of Rule 21 or by leave other than leave without
allowances or by foreign service, such duty or leave or foreign
service counts for increments in the time-scale applicable to the
temporary post if the officer returns to the temporary post:
Provided that the Government may in any case in which
they are satisfied that the leave was taken on account of illness or
for any other cause beyond the officer’s control, direct that leave
without allowances shall be counted for increments under this
clause.
27

<!-- page 38 -->

KERALA SERVICE RULES

(e)

[PART I

Foreign service counts for increments in the time-scale applicable
to—
(i)

the post in Government service on which the officer concerned
holds a lien as well as the post or posts, if any, on which he
would hold a lien had his lien not been suspended, and

(ii) any post in which he would have officiated or to which he may
receive officiating promotion under Rule 143 below for the
duration of such promotion.
(iii) any post in the parent cadre on a lower scale of pay to which
the officer is appointed on reversion from the ex-cadre post
subject to the fulfilment of the conditions mentioned in item (iii)
of proviso to Rule 28.
Note 1.- Joining time counts for increments :(i) If it is under clause (a) of Rule 125, in the time-scale applicable to the
post on which the officer holds a lien or would hold a lien had his lien not
been suspended as well as in the time-scale applicable to the post, the
pay of which is received by the officer during the period, and
(ii) If it is under clause (b) of Rule 125, in the time-scale applicable to the
post/posts on which the last day of leave before commencement of the
joining time counts for increments.

[G.O. (P) 544/62/Fin.,
dt. 8-11-1962]

Explanation.- For the purposes of this rule, the period treated as
duty under sub-clause (ii) of clause (7) of Rule 12
shall be deemed to be duty in a post if the officer
draws pay of that post during such period.
Note 2.- In the case of an officer who, while officiating in a post proceeds on
training or to attend a course of instruction and who is treated as on duty,
while under training, the period of such duty will count for increment in
the post in w hich he was officiating prior to his being sent for training or
instruction if he is allowed the pay of the officiating post during such
period.
Government Decision No. 1
A Government servant thrown out of service for want of
vacancy and again reappointed after a break in the same post or in
another post carrying the same time-scale of pay can count his
prior service for purposes of increment under Rule 33 (a) read with
Rule 12 (35) (b).
Government Decision No. 2

[G.O.(P) 540/94/Fin.,
dt. 30-9-1994]

[Deleted]

34.

[Circular No.
32532/RAI/61/Fin.,
dt. 12-1 -1962]

This deletion shall be deemed to have come into force with
st
effect from 1 October, 1994.
The Government may grant a premature increment to an officer on
a time-scale of pay.
Note. - In the case of increments granted in advance, it is usually the intention that
the officer should be entitled to increments in the same manner as if he
had reached his position in the scale in the ordinary course and in the
absence of special orders to the contrary he should be placed on exactly
the same footing, as regards future increments as an officer who has so
risen.
Government Decision No. 1
In Rule 34 of Kerala Service Rules, Part I, it is laid down
that Government may grant a premature increment to an officer on
a time-scale of pay without prejudice to his normal increment. At
present there is no ruling or Government decision as to the
circumstances under which the rule regarding the grant of advance
28

<!-- page 39 -->

CHAP.IV]

PAY

increments could be invoked in individual cases.
2.

Good service entries and incentive awards are possible variants to
advance increments for the recognition of meritorious service
rendered by Government servants. In G.O.(Ms.) 849/59/PD, dated
24th September 1959, it has been provided that incentive awards
could be made for outstanding performance of officers in the
discharge of their duties and responsibilities. Under this system,
cases of extraordinary originality, imagination or brilliance, or rare
devotion to duty deserving recognition in a special way and
suggestions for reduction of expenditure without affecting efficiency
can all be considered for incentive awards. Government, therefore,
consider that the system of awarding good service entries and
incentive awards are eminently suited for recognising specific or
individual cases of meritorious service/work on the part of
Government servants; the grant of advance increment being
restricted to cases of sustained merit and continuous record of
good work. In other words, good service entries, incentive awards
and advance increments will be in an ascending order in the matter
of recognition of meritorious services of Government servants.

3.

Government also wish to emphasise that there should be more or
less uniform standards in recognising merit for the award of
advance increments. The confidential report of the officer to whom
advance increment is proposed to be given should, therefore, be
looked into. All proposals for the grant of advance increments in
recognition of the meritorious work of Government servants shall be
scrutinised by the concerned Administrative Department, the Public
Department and Finance Department before placing the cases for
sanction before the Council of Ministers.

[G.O.(P) 283/75/Fin.,
dt. 1-7-1975]

This amendment shall be deemed to have come into fo rce
nd
with effect from 22 February 1974.
4.

The above procedure will not apply to the grant of advance
increments on notional basis for purposes of fixation of pay due to
considerations other than of meritorious services of Government
servants.

[Circular No. 8/64/Fin.,
dt. 23-1-1964]

Government Decision No. 2
Incentive awards in the nature of cash awards for
meritorious services shall not be given to Gazetted Officers.

[G.O.(P) 283/75/Fin.,
dt. 1-7-1975]

The above amendment shall be deemed to have come into
nd
force with effect from 22 February 1974.
Government Decision No . 3
Advance increments for meritorious service may be
granted to both Gazetted and non-Gazetted Officers.

[G.O.(P) 33/76/Fin.,
dt. 23-1-1976

Government Decision No. 4
Good service entries, incentive awards and advance
increments shall not be granted to officers deputed for training
courses.
35.

[G.O. (P) 17/87/Fin.,
dt. 6-1-1987]

The authority which orders the transfer of an officer as a penalty
from a higher to a lower grade or post may allow him, to draw any
pay, not exceeding the maximum of the lower grade or post which it
may think proper :
Provided that the pay allowed under this rule shall not
exceed the pay which he would have drawn under Rule 28 read
with clause (b) or clause (c) as the case may be, of Rule 33.
29

[G.O.(P) 146/77/Fin.,
dt. 16-5-1977]

<!-- page 40 -->

KERALA SERVICE RULES

36.

[PART I

If an officer is, on account of misconduct or inefficiency, reduced to
a lower grade or post or to a lower stage in his time-scale, the
authority ordering such reduction shall state the period for which it
shall be effective and whether on restoration, it shall operate to
postpone future increments, and, if so, to what extent.
Ruling
1. Every orde r passed by a competent authority imposing on a
Government servant the penalty of reduction to a lower stage in
a time-scale should indicate :(i) The date from which it will take effect and the period (in
terms of years and months) for which the penalty shall be
operative.
(ii) The stage in the time-scale (in terms of rupees) to which
the Government servant is reduced in the following form :
“The ……………………………………. has decided that Sri
…………………should
be
reduced
to
a
pay
of
Rs……………………………… for a period of …………………..
w ith effect from…… …… ……..” and
(iii) The extent (in terms of years and months), if any, to which
the period referred to at (i) above should operate to
postpone future increments.
It should be noted that reduction to a lower stage in a timescale is not permissible under the rules either for an
unspecified period or as a permanent measure. Also when a
Government servant is reduced to a particular stage, his pay
will remain constant at that stage for the entire period of
reduction. The period to be specifi ed under (iii) should in no
case exceed the period specified under (i).
2. The question as to what should be the pay of a Government
servant on the expiry of the period of reduction should be
decided as follows :-

(i) If the order of reduction lays down that the period of
reduction shall not operate to postpone future increments,
the Government servant should be allowed the pay which
he would have drawn in the normal course but for the
reduction. If, however, the pay drawn by him immediately
before reduction was below the efficiency bar he should not
be allowed to cross the bar except in accordance with the
provision of Rule 32, Part I, Kerala Service Rules.
(ii) If the orders specifies that the period of reduction was to
operate to postpone future increments for any
specified period, the pay of the Government servant
shall be fixed in accordance with (i) above, but after
treating the period for which the increments were to be
postponed as not counting for increments.
37.

(a)

Subject to the provisions of Rule 33 (c) and Rule 39, an officer
holding a permanent or officiating post, if appointed to officiate on a
higher time-scale of pay, will draw as initial pay the stage next
above his pay in the lower time-scale irrespective of whether the
pay in the lower time-scale is a stage in the higher time-scale or
not. A refixation will be allowed whenever there is change of pay in
the lower time-scale, i.e., when his pay therein becomes equal to
or greater than the pay which he draws in the higher time-scale.
30

[G.O. (P) 659/64/Fin.,
dt. 14 -9-1964]
&
[G.O.(P) 262/66/Fin.,
dt. 16-6 -1966]

<!-- page 41 -->

CHAP.IV]

PAY

(b)

In the case of officiating appointments other than those
contemplated in the above rule, the officer’s officiating pay in the
new appointment shall be fixed at his o fficiating pay in the
previous appointment if it is a stage in the new scale, or at the next
lower stage, if it is not a stage in the new scale, the difference
being treated as personal pay to be absorbed in future increases.
This will not apply to cas es of reversions:
Provided that in cases covered by sub-rules (a) and (b)
other than cases of re-employment after resignation, removal or
dismissal from public service, if he has previously either held
substantively or officiated in (i) the same post, or (ii) permanent or
temporary post on the same time-scale, or (iii) a permanent post on
an identical time-scale or a temporary post (including a post in a
body, incorporated or not, which is wholly or substantially owned or
controlled by the Government ) on an identical time-scale, then the
initial pay shall not, except in cases of reversion to the parent cadre
governed by item (iii) above, be less than the pay which he drew
on the last such occasion and he shall count the period during
which he drew that pay on such last and any previous occasions
for increment in the stage of the time-scale equivalent to that pay.
The service rendered in a post referred to in item (iii) shall, on
reversion to the parent cadre, count towards initial fixation of pay to
the extent and subject to the conditions indicated below:
(a) the officer should have been approved for appointment to the
particular grade/post in which the previous service is to be
counted;
(b) all his seniors, except those regarded as unfit for such
appointment, were serving in posts carrying the scale of pay in
which the benefit is to be allowed or in higher posts, whether in
the department itself or elsewhere, and atleast one junior was
holding a post in the department carrying the scale of pay in
which the benefit is to be allowed ; and
(c) the service will count from the date his junior is promoted and
the benefit will be limited to the period the officer would have
held the post in his parent cadre had he not been appointed to
the ex-cadre post.
Ruling No. 1
When a person in a post (whether within the cadre of his
service or not) is for any reason prevented from officiating in his
turn in a post on a higher scale or grade borne on the cadre of the
service to which he belongs, he may be authorised by special order
of the appropriate authority proforma officiating promotion into such
scale or grade and thereupon be granted the pay of that scale or
grade if that be more advantageous to him on such occasion on
which the person immediately junior to him in the cadre of his
service (or if that person had been passed over for reasons of
inefficiency or unsuitability or because he is on leave or serving
outside the ordinary line or forgoes officiating promotion of his own
volition to that scale or grade, then the person next junior to him
not so passed over) draws officiating salary in that scale or grade.
But in case, where the person immediately junior to him happens to
assume charge of the post on a later date than that of another
junior, the senior who is outside the ordinary line shall be eligible
for the benefit of proforma officiating promotion with effect from
such date as the other junior assumes charge of the post:
Provided that all persons senior to the persons to whom
the benefit under the substantive part of this rule is to be allowed
31

[G.O.(P) 417/78/Fin.,
dt. 12-4 -1978]

<!-- page 42 -->

KERALA SERVICE RULES

[PART I

are also drawing, unless they have been passed over for one or
other of the reasons aforesaid, officiating salary in the said or some
higher scale within the cadre :
Provided further that not more than one person (either the
senior most fit person in a series of adjacent persons outside the
ordinary line, or if such a person either forgoes the benefit on his
own volition or dues not require benefits by virtue of his holding a
post outside the ordinary line which secures him at least equivalent
benefits in respect of salary and pension then the next below the
series ) may be authorised to draw the salary of the higher scale or
grade in respect of any one officiating vacancy within the cadre
filled by his junior under this rule.
Note 1.- A fortuitous officiating promotion given to a person who is junior to one
outside the regular line does not in itself give rise to a claim under the
‘Next Below Rule’.
Note 2.- The provisions in item (iii) of the proviso to the above rule in respect of
protection of pay and period of increment shall be applicable to
Government Servants on their appointment directly or on transfer from a
post carrying identical time-scale of pay without fulfilment of the conditions
indicated thereunder subject to the condition that this benefit will not be
admissible to an individual who enters Government service for the first
time from a post in a body incorporated or not which is wholly or
substantial ly owned or controlled by Government.

[G.O.(P) 393/63/Fin.,
dt. 2-7-1963]

Ruling No. 2
1.

Scope of the term “outside the ordinary line”.-The expression
“outside the ordinary line” occurring in Ruling No.1 is not
intended to be rigidly interpreted as necessary involving a post
either “outside the cadre” or “outside the ordinary time-scale”.
For instance there are cases of officers deputed for postgraduate, etc., training and paid training allowances on the
basis of the pay and allowances they would have drawn had
they continued in the Department. Training posts are also
created in the Department to accommodate them during the
period of training. If an officer so deputed gets a promotion in
the Department it cannot be strictly stated that the officer is
outside the ordinary line, as a training post has already been
created to accommodate him within the cadre.

2. Seniority for purpose of the Next Below Rule.- If Government
have approved in any Department a list of officers in the order
of merit for promotion to administrative rank or a selection
grade, then that order will prevail as the order of seniority for
the purpose of the Next Below Rule, over the order of seniority
of the officers in the ordinary gradation list of their cadre.
3.

Promotions effected prior to the date of the Next Below Rule.nd
In G.O.(P) 393/63/Fin., dated 2 July 1963 it has been ordered
that the Next Below Rule would not apply to cases of
promotions already effected. It has been laid down in the
second proviso to the rule that not more than one person may
be authorised to draw the salary of the higher scale or grade in
respect of any one officiating vacancy within the cadre filled by
his junior. A doubt may arise as to the application of this
proviso in respect of promotions effected before the date of the
rule. This is made clear by the following illustration. Suppose
eight persons had been given the benefit of promotion before
nd
2
July 1963 outside the ordinary line against only 3
promotions within the ordinary line. In this case, the question
of giving further promotion to the persons outside the ordinarily
line will arise only after five more persons are given promotion
32

[G.O.(P) 610/64/Fin.,
dt. 27-8-1964]

<!-- page 43 -->

CHAP.IV]

PAY

within the ordinary line so that all the eight persons outside are
sustained. But those 5 persons who were given promotion
nd
outside the ordinary line before 2 July 1963 will continue to
nd
get the benefit even after 2 July 1963 notwithstanding the
second proviso to the ruling.

Ruling No. 3
In the case of a Government servant officiating in a post
and whose pay had been re-fixed under this rule, if he is confirmed
in that post with effect from a retrospective date, the re-fixation of
pay done after the date of confirmation will have to be revised. The
over payments consequent on such revision will first be set off
against arrears, if any, that might become payable to the
Government Servant for a portion of the period from the date of
confirmation to the date of issue of orders of confirmation. The
balance of overpayments that cannot be set off against the arrears,
if any, shall be waived.

[G.O.(P) 24/65/Fin.,
dt. 13-1-1965]

This Ruling shall be deemed to have come into force with
st
effect from 1 November 1959.
Ruling No. 4
The refixation of pay in the higher officiating post on the
date of change of pay in the lower time-scale contemplated in this
rule cannot be allowed during the period of bar on increment with
or without cumulative effect. But, in the cases of bar on increment
without cumulative effect, there is no objection to give the refixation
on a notional basis and to give the monetary benefit after the expiry
of the period of bar. Increments accruing in the lower
substantive/officiating post from time to time cannot also be
allowed during the period of bar.

[G.O.(P) 650/72/Fin.,
dt. 12 -12-1972]

Ruling No. 5
Increments barred with or without cumulative effect in the
lower substantive/officiating post shall not be reckoned for
fixation/refixation of pay in the higher time-scale. But in the case of
bar on increment without cumulative effect there is no objection to
grant the barred increments notionally for fixation/refixation of pay
and to give the monetary benefit after the expiry of the period of
bar.

[G.O.(P) 150/77/Fin.,
dt. 17 -5 -1977]

Ruling No. 6
A revision of pay as contemplated in Ruling No. 3 shall not
be necessary in the case of retrospective confirmation ordered
after the date of retirement of an officer.

[G.O.(P) 79/75/Fin.,
dt. 3-3-1975]

The ruling shall be deemed to have come into force with
st
effect from 1 November 1959.
Government Decision No. 1
The rules governing fixation of pay on transfer from one
appointment to another contained in the service regulations [as
th
modified by G.O. (P) 95/58/Fin., dated 16 April, 1958 and G.O.
nd
(P) 379/59/Fin., dated 22 July 1959] are applicable to all cases of
transfers irrespective of whether the transfer is on the basis of the
advice of the Public Service Commission or not. The initial
pay/salary of an officer, who while in Government service but not in
a provisional appointment is recruited by the Public Service
Commission for appointment to a post in the same department or
another department will accordingly be fixed applying the above
rules. No special sancti on is necessary in such cases.
33

[G.O.(P) 89/69/Fin.,
dt. 20-2-1960]

<!-- page 44 -->

KERALA SERVICE RULES

[PART I

Government Decision No. 2
st

The above order will take effect from 1 November 1959
the date on which Kerala Service Rules took effect.

[G.O.(P) 536/60/Fin.,
dt.9 -11-1960]

Government Decision No. 3
In the case of re-fixation of pay in the higher officiating
appointment in respect of purely officiating hands without any
substantive appointment under Government a certificate should be
recorded in the fixation statement/bill that the government servant
concerned would have continued in the lower officiating
appointment had he not been promoted to the higher officiating
appointment .

[Circular
R A1/53436/60/Fin.
dt.17-10-1960]

Government Decision No. 4
An officer officiating in a post, when appointed to a higher
post on the advice of the Public Service Commission or otherwise
is eligible for his initial pay being fixed under this rule and is also
entitled to the benefit of refixation contemplated in the last
sentence o f the sub-rule (a).

[G.O.(P) 475/90/Fin.,
dt. 25-9-1990

This order will be deemed to have come into force with
st
effect from 31 October 1986.
Government Decision No. 5
The following principles will be followed for fixation of pay
when the scale of pay of a post held on a provisional basis is
revised :
(i)

If the pay drawn in the previous scale is less than the
minimum of the revised scale, then the pay in the revised
scale may be fixed at the minimum.

(ii)

If the pay drawn in the previous scale is a stage in the
revised scale, the pay in the revised scale may be fixed at
that stage.

(iii) If the pay drawn in the previous scale is not a stage, then
the pay in the revised scale may be fixed at the next lower
stage, the difference being treated as personal pay to be
absorbed in future increase in pay.
2.

The above principles will also be adopted for regulating the pay
of an officer holding a post on a provisional basis when
appointed to a higher or a lower post provisionally, except in
cases of reversions.

3.

The pay of an officer holding a post on a provisional basis
when appointed provisionally to another post on identical timescale will be fixed in the new appointment at a stage equal to
the pay he was drawing in the previous appointment but the
period during which he drew pay at that rate in the previous
appointment will not count for increment.

[G.O.(P) 558/75/Fin.,
dt. 17 -12-1975]

4.

Past cases settled otherwise, will not be reopened.

[G.O.(P) 297/66/Fin.,
dt. 5-7-1966]

Government Decision No. 6
The pay drawn by an officer in an ex-cadre post can be
counted for purpose of initial fixation of pay on promotion in the
parent department. But the benefit of refixation of pay
contemplated in the rule is not admissible to him as he loses
connection with the ex-cadre post on appointment to the parent
department.
34

[G.O.(P) 580/70/Fin.,
dt. 13-8 -1970]

<!-- page 45 -->

CHAP.IV]

PAY

The benefit of pay drawn in an ex-cadre post for purpose
of initial fixation will not be admissible, if an officer is reverted to the
parent department, to a post carrying a scale of pay lower than that
of the ex-cadre post.

[G.O.(P) 223/77/Fin.,
dt. 14-7 -1977]

Government Decision No. 7
The re-fixation of pay contemplated in the last sentence of
sub-rule (a) is admissible even in cases where the change of pay in
the lower time-scale is due to fixation of pay on account of revision
of the scale of pay. If both the lower and higher time-scales are
revised, the benefit will be restricted to cases of options exercised
in respect of both the posts simultaneously.
Government Decision No. 8
The principles enunciated in paragraph (1) of
the
Government Decision No. 5 above will be adopted for regulating
the pay of an officer holding a post on a provisional basis when
appointed to a higher or a lower post on a regular basis also,
except in cases of reversions.

[G.O.(P) 811/71/Fin.,
dt. 21 -12-1971]

Effective from 5 th July 1966.
Government Decision No. 9
(i) The pay of an officer holding a post on a provisional basis and
appointed on regular basis to another post on identical timescale will be fixed at a stage equal to the pay he was drawing
in the provisional appointment. The period during which the
officer has drawn pay at that rate on the provisional
appointment will not count for increment.
(ii) The pay drawn by an officer in a post held by him on a
provisional basis on initial appointment to Government service
through the employment exchange or otherwise will not be
reckoned for regulating his pay on appointment to another post
carrying lower time-scale on a regular basis. Cases of persons
appointed to a post on a provisional basis while holding regular
posts and subsequently appointed to another post carrying a
lower time-scale on a regular basis except cases of reversions,
and cases of provisional hands appointed to higher posts on a
regular basis will continue to be regulated by the Government
Decision No. 8.
Government Decision No. 8 will stand modified to the
above extent. This decision will take effect from 5th July 1966.
Cases already settled otherwise will not be reopened to the
disadvantage of the persons concerned.

[G.O.(P) 137/73/Fin.,
dt. 9-5-1973]

Government Decision No. 10
The pay of a provisional appointee/promotee when reappointed/re-promoted provisionally to the same post shall be fixed
at the same stage at which he was drawing pay on the last such
occasion and the period during which he drew pay at that stage on
such last and any previous occasions will count for increment.

[G.O.(P) 50/77/Fin.,
dt. 4 –2-1977]

Government Decision No. 11
The pay of an officer holding a post on a regular basis and
appointed on a provisional basis to another post on identical timescale will be fixed at a stage equal to the pay he was drawing in
the regular appointment. The period during which the officer has
drawn pay at that rate on the regular appointment will count for
increment in the provisional appointment.
The above decision shall be deemed to have come into
35

[G.O.(P) 218/80/Fin.,
dt. 24 –3 -1980]

<!-- page 46 -->

KERALA SERVICE RULES
rd

force with effect from 3 May 1963.

37 A.

Notwithstanding the provisions contained in these rules, the pay of
a Government servant whose promotion or appointment to a post
is found to be or to have been erroneous, shall be regulated in
accordance with any general or special orders issued by the
Government in this behalf.
Government Decision
The following provisions shall govern the pay and
increments of a Government servant whose promotion or
appointment in a substantive or officiating capacity to a post is later
found to be erroneous on the basis of facts :1.

The orders of promotion or appointment of a Government
servant should be cancelled as soon as it is brought to the
notice of the appointing authority that such a promotion or
appointment has resulted from a factual error and the
Government servant concerned should, immediately on such
cancellation, be brought to the position which he would have
held but for the incorrect order of promotion or appointment.

2.

Service rendered by the Government servant concerned in the
post he was wrongly promoted/appointed as a result of the
error should not be reckoned for the purpose of increments or
for any other purpose in that grade/post to which he would not
normally be entitled but for th e erroneous promotion/
appointment.

3.

Any
consequential
promotions/appointments
of
other
Government servants made on the basis of the incorrect
promotion/appointment of a particular Government servant will
also be regarded as erroneous and such cases also will be
regulated on the lines indicated in the preceding paragraph.

4.

Except when the appointing authority is the Government, the
question whether the promotion/appointment of a particular
Government servant to a post was erroneous or not should be
decided by an authority next higher than the appointing
authority in accordance with the established principles
governing promotions/appointments. In cases of doubt
Government may be consulted.

5.

Cases of erroneous promotion/appointment should be viewed
with serious concern and suitable disciplinary action taken
against the officers and staff responsible for such erroneous
promotion/appointment under the Kerala Civil Services
(Classification, Control and Appeal) Rules, 1960.

6.

In the case of a Government servant who has been
erroneously promoted/ appointed to a post in a substantive
capacity, the following procedure may be followed for
deconfirming the Government servant in that post and only
thereafter, the Government servant concerned should be
brought down to the position which he would have held but for
the erroneous promotion/appointment.
(a) An order of confirmation which is clearly contrary to the
relevant statutory rules may be cancelled by the competent
authority straight away. Here the order of confirmation was
ab initio void as it was ultra vires of the relevant rules and
cancellation of the order would be justified on the ground
that there was no valid subsisting order at all and the act of
cancellation is a mere formality. The effect of cancellation
36

[PART I

<!-- page 47 -->

CHAP.IV]

PAY

would be to put the employee concerned in a position of
never having been confirmed.
(b) An order of confirmation which is contrary to executive
orders or administrative instructions may be cancelled by
the competent authority, if such erroneous order of
confirmation has operated to the prejudice of some
identifiable person who would otherwise have been
confirmed, if the orders had been correctly applied.
Here the order of cancellation would be just and equitable
as the confirmation of the employee concerned operates unfairly to
the detriment of another employee who would have otherwise been
confirmed. Such cancellation will not have the effect of doing any
injustice to the employee whose confirmation is cancelled, since he
was under the executive orders or administrative instructions in
force, not entitled to confirmation.
It would, however, be in consonance with the principles of
natural justice that a notice to show cause why the orders of
confirmation should not be cancelled be given to the affected party
in both the types of cases specified above.
7.
37 B.

(a)

The orders re -fixing the pay in all the above cases should be
issued expressly under Rule 37A, Part I, Kerala Service Rules.

[Memorandum No.
87/63, dt. 30 -11 -1963]

Probationer in any servi ce shall draw initial pay as follows :(i) while undergoing a course of instruction or training the pay, if
any, specified in the ‘Special Rules’ in that behalf or by
special orders of Government, and
(ii) after completion of the course of instruction or training and
when there is no course of instruction or training, the
minimum of the time-scale of the probation post.

(b)

(i)

A probationer whose, period of probation is two years and
whose increment is annual shall be entitled to draw the first
increment in the time-scale of the probation post after putting in
the service required to earn an increment. The second
increment shall be drawn only with effect from the date from
which he is declared to have completed his probation. Delay in
completing probation will not however, affect his future
increments and these will accrue on the normal incremental
dates.

(ii) In the case of a probationer whose period of probation is one
year and whose increment is annual, the first increment in the
scale of pay of the prob ation post shall be drawn only with
effect from the date on which he is declared to have completed
his probation. Delay in completing probation will not, however,
affect his future increments and these will accrue on the
normal incremental dates.
Not e. - If any period of the service of a probationer does not count for probation, he
shall complete the period of probation of one year or two year’s duty, as
the case may be, by being on duty for an equal period from the date of
expiry of one year or two years as the case may be after the
commencement of the probation. In cases where the above period is
expressed in terms of months and days, then such period shall be
calculated as provided in Rule 12 (21) of Part I, Kerala Service Rules. In
cases where the absence is expressed in days, the date of completion of
probation shall be extended by the number of days of such absence.
Effective from 4th April 1983.

37

[G.O.(P) 163/83 Fin.,
dt. 4 - 4 - 1983]

<!-- page 48 -->

KERALA SERVICE RULES

(c)

Subject to the provisions of Rule 39 and notwithstanding the
provisions of sub-rules (a) and (b) of this rule, an officer shall be
entitled to draw in the probation post the pay for which he would be
eligible from time to time under the provisions of Rule 28A, Rule 33
(c) or Rule 37, as the case may be.

38.

When an officer officiates in a post, the pay of which has been
fixed at a rate personal to another officer the Government may
permit him to draw pay at any rate not exceeding the rate so fixed
or, if the rate so fixed be a time-scale, may grant him initial pay not
exceeding that lowest stage of that time-scale and future
increments not exceeding those of the sanctioned scale.

39.

The Government may in individual cases fix by special order the
pay of an officiating officer at an amount less than that admissible
under these rules.

40.

The Government may issue general or special orders allowing
acting promotions to be made in place of officers who are treated
as on duty under Rule 12 (7) (iii).

[PART I

[G.O.(P) 153/64/Fin.,
dt. 8-4-1964]

Note. - Acting arrangements may be allowed by competent authority if the period of
training of an officer is one month or more. If it is less than a month, no
arrangements can be made except under the special sanction of
Government.
Government Decision
In the cas e of deputation of a Government Servant for
training or a course of instruction which is treated as duty under
Rule 12 (7) (iii), Part I, Kerala Service Rules it is not necessary to
create a new post in order to accommodate him during such
training or course of instruction, since the very order sanctioning
the deputation for training would be a sanction in this behalf.
Effective from 2

nd

September 1964.

41.

Personal Pay.- Except when otherwise ordered by Government
personal pay shall be reduced by any amount by which the
recipient’s pay may be increased and shall cease as soon as his
pay is increased by an amount equal to his personal pay.

42.

Pay of Temporary Posts.- When a temporary post is created which
may have to be filled by a person not already in Government
Service, the pay of the post shall be fixed with reference to the
minimum that is necessary to secure the services of a person
capable of discharging efficiently the duties of the post.

43.

When a temporary post is created which will probably be filled by a
person who is already in the service of Government its pay should
be fixed with due regard to (a) the character and responsibility of the work to be performed,
and
(b) the existing pay of officers of a status sufficient to warrant their
selection for the post.
Note. - Temporary posts by this criterion should be considered as temporary
additions to the cadre of a service should be created in the time-scale of
the service ordinarily without extra remuneration. Incumbents of these
posts will therefore draw their ordinary time-scale of pay. If the posts
involve decided increases in work and responsibility in comparison with
the duties of the parent cadre generally it may be necessary to sanction a
special pay in addition.

38

[G.O.(P) 632/64/Fin.,
dt. 2-9-1964]

<!-- page 49 -->

CHAP.V]

ADDITIONS TO PAY

CHAPTER V
ADDI TI ONS T O P AY

44.

Compensatory Allowances.- Subject to the general rule that the
amount of compensatory allowances should be so regulated that
the allowance is not on the whole a source of profit to the recipient
the Government may grant such allowances to any officer under its
control and may make rules prescribing their amounts and the
conditions under which they may be drawn. (For rules made under
the above Rule See Appendix IV).
I.

Unless otherwise ordered by Government, a compensatory
allowance shall ordinarily be drawn only by a Government servant
actually on duty, but the authority competent to sanction leave may
in writing permit it to be drawn by the officer on earned leave, if the
whole or a considerable part of the expense to meet which the
allowance was granted continues to be incurred by him during the
leave:
Provided the Government Servant certifies that he
continued for the period for which the allowance is claimed, to
incur the whole or a considerable part of the expense for which the
allowance was granted:
Provided further that the officer is due to return after leave
to the same post or station, as the case may be from which he
proceeded on leave or to a similar post or station for which the
allowance at the same or a higher rate is admissible:
Provided further when the Government servant on return
from leave is posted to a post other than the one from which he
went on leave and both the posts carry similar allowances but at
different rates, the Government servant shall during leave draw
the lesser of the two rates.
I.

(A) Subject to the second and third provisions to clause I
above, compensatory allowance granted under class VI (c) in
Appendix IV may be drawn during periods of earned leave:

This clause shall be deemed to have come into force with
effect from 12th January 1965.
II. A compensatory allowance granted under class IV, Appendix
IV may be drawn during temporary transfer, if(i)

the authority sanctioning the transfer certifies that the
Government servant is likely, on the expiry of the
temporary duty, to return to the station from which he is
transferred ;

(ii) the Government servant draws no allowance of the same
kind in the post to which he is transferred;
and
(iii) the Government servant certifies that he kept his family,
for the period for which the allowance is claimed, at the
station from which he proceeded on transfer.
III. A compensatory allowance granted under class
Appendix IV may be drawn during temporary transfer, if(i)

VI,

the authority sanctioning the transfer, certifies that the
Government servant is likely on the expiry of the transfer,
to return to the post to which the allowance is attached or
to another post carrying a similar allowance; and
39

[G.O.(P)302/66/Fin.,
dt. 7-7-1966]

<!-- page 50 -->

KERALA SERVICE RULES

(ii)

[PART I

the Government servant certifies that he continued for
the period for which the allowance is claimed to incur the
whole or a considerable part of the expenditure for which
the allowance was granted.

Note. -The certificate under clause (ii) above will be dispensed with when it is
inapplicable.
IV. If a Government servant in his old post drew compensatory
allowance granted under Class IV, or Class VI of Appendix IV
(but not in an individual capacity) and is transferred to another
post, he may be allowed the compensatory allowance during
joining time as applicable to the old station from which he was
transferred. He may also be allowed house rent allowance
during transit as applicable to the old station from which he
was transferred. He shall not be allowed conveyance
allowance or Permanent Travelling Allowance.

[G.O.(P) 1010/87/Fin.,
dt. 27-11-1987]

Government Decision No. 1
Notwithstanding anything contained in the second and third
provisos to Rule 44 I, Part I Kerala Service Rules, House Rent
Allowance and City Compensatory Allowance admissible under
orders issued from time to time will be payable during periods of
leave with allowances including leave preparatory to retirement, if
the total periods of such leave at a time does not exceed four
months or if the actual duration of the leave exceed four month, for
the first four months of such leave.
Government Decision No.2

[G.O.(P) 378/91/Fin.,
dt. 1-6-1991 ]

[Deleted]
45.

The Government may make rules or issue orders laying down the
principles governing the allotment to officers, for use by them as
residences, of such buildings owned or leased by it, or such
portions thereof, as the Government may make available for the
purpose. Such rules or orders may lay down different principles for
observance in different localities or in respect of different classes
of residence, and may prescribe the circumstances in which such
an officer shall be considered to be in occupation of a residence.

46.

Fees.The Government may permit an officer, if it be satisfied
that this can be done without detriment to his official duties or
responsibilities, to perform a specified service or series of services
for a private person or body or for a public body including a body
administering a local fund or for another Government and to
receive as remuneration therefore, if the service be material a non
recurring or recurring fee.
Note. - This rule does not apply to the acceptance of fees from private persons by
medical officers in Government employ for professional attendance which
is regulated by separate orders of Government.

47.

[G.O. 512/92/Fin.,
dt. 26 -8 -1992]

No officer may undertake work for another Government, or a
private or public body or a private person, or accept fee therefore,
without the sanction of the Government.
Note. - Heads of department, while forwarding their recommendations in such
cases shall unless the officer is on leave, specifically state whether the
work can be undertaken by the officer concerned without detriment to his
official duties and responsibilities.

40

<!-- page 51 -->

CHAP.V]

ADDITIONS TO PAY

Government Decision
In respect of examinations conducted by the Education
Department, the Public Service Commission, the University etc., it
is not necessary to accord individual sanction for acceptance of
remuneration in every case of Government servant undertaking
such work. Any officer of Government, who is called upon to
undertake work in connection with the examination, conducted by
the following examining bodies, will be permitted to accept such
st
assignment and the remuneration therefore with effect from 1
November 1959:1.

The Kerala University and other Universities.

2.

The Union Public Service Commission, the Public Service
Commission of the States and the Secretarial Training School,
Cabinet Secretariat of the Government of India.

3.

The London Chamber of Commerce.

4.

The Departments of this Government.

5.

The Forest Research Institute and Colleges, Dehra Dun and
Coimbatore.

6.

The Kerala State Co-operative Union in respect of Cooperative Subordinate Personnel Training Examination.

(G.O.(P) 193/60/Fin.,
dt. 12 -4 -1960,
G.O.(Ms) 45/61/Fin.,
dt. 3-2-1961
&
G.O.(P) 386/71/Fin.,
dt. 5-7-1971)

[G.O.(P) 296/66/Fin.,
dt. 4 -7-1966.

The item No.6 shall be deemed to have come into force
with effect from 10th May 1966.
48.

Unless the Government by special order otherwise direct, one -third
of any non-recurring fee exceeding †Rs.2000 or one-third of any
recurring fee exceeding †Rs.1250 a year, paid to an officer, shall
be credited to the General Revenues.

[G.O.(P) 389/65/Fin.,
dt. 11-10-1965]

Note 1.- If any fee to which this rule applies exceeds †Rs.2000 non-recurring or
†Rs.1250 a year recurring one-third of the total amount payable should
be credited to the General Revenues, provided that the amount retained
by the officer concerned will not, merely owing to the operation of this
rule, be reduced below †Rs.2000, if non-recurring or †Rs.1250 a year if
recurring.
Non-recurring and recurring fees should be de alt with
separately and should not be added for the purpose of crediting
one-third to General Revenues under this rule. In the case of the
former, the limit of †Rs.2000 prescribed in this rule should be
applied in each individual case, and in the case of the latter the
limit of †Rs.1250 should be applied with reference to the total
recurring fees for the financial year.
†This amendment shall be deemed to have come into
th
force with effect from 26 July 1995.
Note 2.-The above rule does not apply to fees received by officers from a
University or other examining body in return for their services as
examiners or from the revenues of another Government in return for their
services to that Government* and also to the royalties received by officers
from the publishers for the sale of the books written by them even with the
aid of knowledge acquired during the course of their service.
* This amendment shall be deemed to have come into force with effect
from 11th October 1971.
49.

Honoraria.- The Government may grant or permit an officer to
receive an honorarium as remuneration for work performed which
is occasional in character and either so laborious or of such special
merit as to justify a special reward. Except when special reasons,
which should be recorded in writing exist, for a departure from this
41

[G.O.(P) 1248/97/Fin.,
dt. 10-12-1997]

<!-- page 52 -->

KERALA SERVICE RULES

[PART I

provision, sanction to the grant or acceptance of an honorarium
should not be given unless the work has been undertaken with the
prior consent of the Government and its amount has been settled
in advance.
Government Decision No. 1
The following allowances will be classified as honoraria
under this rule :

[G.O.(P) 576/63/Fin.,
dt. 7-11 -1963]

1. Overtime allowance.
2. Allowance given to Wardens and Assistant Wardens of
hostels.
Government Decision No. 2
When State Government Officers required to attend the
meetings of the Interview Board of the Kerala Public Service
Commission are not eligible for Travelling Allowance under the
rules, they shall be paid an honorarium equivalent to the daily
allowance admissible under Rule 39, Part II, Kerala Service Rules.
Effective from 22

nd

January 1969.

Government Decision No. 3
The conditions of prior consent and the settlement of the
amount in advance referred to in the last sentence of this rule will
not apply to any work ordered to be done at Government level.
Government Decision No. 4
When members of the Boards for various examinations
conducted by the Commissioner for Government Examinations
required to attend to the meetings of the Boards are not entitled to
Travelling Allowance and Daily Allowance under the rules, they
shall be paid an honorarium equivalent to the Daily Allowance
admissible under Rule 39, Part II, Kerala Service Rules.
This decision will be deemed to have come into force with
th
effect from 17 January 1972.
50.

Fees and Honoraria.- In the case of both fees and honoraria the
sanctioning authority shall record in writing that due regard has
been paid to the general principle enunciated in Rule 14 and shall
record also the reasons which in his opinion justify the grant of the
extra remuneration.

51.

Any officer is eligible to receive without special permission-

(a) the premium awarded for an essay or plan in public
competition;

(b) any reward offered for the arrest of a criminal or for information
or special service in connection with the administration of
justice;

(c) any reward payable in accordance with the provisions of any
Act or Regulation or Rules framed thereunder;
(d) any reward sanctioned for services in connection with the
administration of the customs and excise laws;
(e) any fees payable to an officer for the duties which he is
required to perform in his official capacity under any special
law or by order of Government; and
(f) any remuneration paid by the All India Radio for professional
performances in its programmes, such as music, drama and
the like.
42

[G.O.(P) 155/70/Fin.,
dt. 7-3-1970]

<!-- page 53 -->

CHAP.V]

ADDITIONS TO PAY

Note. -Sanction of the authorities mentioned below is, however, necessary for
accepting remuneration for giving talks over the All India Radio by
Government Officers:
Name of Officers giving the talk
Chief Secretary
Secretaries

52.

and

Name of authority whose permission is
required
Minister concerned

Heads of department

Secretaries concerned

Officers subordinate to
Heads of Departments

Heads of Departments

An officer whose duties involve the carrying out of scientific or
technical research shall not apply for or obtain, or cause or permit
any other person to apply for or obtain, a patent for an invention
made by such officer save with the permission of the Government
and in accordance with such conditions as the Government may
impose.

CHAPTER VI
COMBINATION O F APPOINTMENTS
53.

(a)

A competent authority may appoint an officer to hold substantively
or to officiate in two or more independent posts at one time.

(b)

The competent authority who appoints an officer to hold or to
officiate in a second post in addition to his own, will declare
whether he officiates in or holds full charge of the additional post or
is appointed merely to discharge the current duties. It should also
specify in each case the amount of additional pay and allowances,
if any, to be granted, the amount being subject to the following
limits :(1)

If an officer is appointed to officiate in a second post and to
hold in addition full charge of his own post, he may be allowed
to draw the highest pay to which he would be entitled if his
appointment to one of the posts stood alone and in addition
pay which should not exceed 20 percent of the minimum of
the scale of pay of the other post. The highest pay referred to
above may be specifically reduced by the competent authority
at its discretion.
If compensatory allowance is attached to one of the posts,
he may be permitted to draw it in full and if compensatory
allowances are attached to more than one of the posts, the
allowance which may be granted to him should not exceed the
larger allowance.

(2)

If the officer is appointed to hold full charge of one or more
posts in addition to his own, the additional pay which may be
granted to him in respect of each additional post should not
exceed 20 percent of the minimum of the scale of that post.
The drawal of compensatory allowances will be regulated as
in the sub-para under clause (1) above.

(3)

If the officer is appointed to discharge only the current duties
of one or more posts in addition to his own, the additional pay
which may be granted to him in respect of each additional
post should not exceed 10 percent of the minimum of the
scale of pay of that post, in addition to the pay and
compensatory allowances, if any, admissible in his regular
43

[G.O.(P) 342/65/Fin.,
dt. 31 -8-1965]

<!-- page 54 -->

KERALA SERVICE RULES

[PART I

post.
(c)

No additional pay should be granted unless the previous
incumbent of the additional post held, has actually given over
charge thereof under orders of competent authority and unless the
period of additional charge exceeds fourteen working days in the
case of full additional charge and one month in the case of
discharge of current duties only. The drawal of additional pay
should not normally be allowed for a period exceeding three
months.

(d)

[Deleted].

(e)

Additional remuneration should not be allowed as a matter of
course or granted when the extra duties to be performed are only
nominal or comparatively light. Additional remuneration should not
be allowed during any period of vacation unless the additional duty
is actually performed during such period.

[G.O.(P) 132/87/Fin., dt.
10-2-1987]

Ruling
The term ‘independent’ occurring in the above rule should
be interpreted as meaning separate or distinct involving
independent duties and responsibilities and the post subordinate to
the one held by the officer should not be taken as independent
under the rule.
Government Decision No. 1
At present charge allowance of the non gazetted officer for
his holding additional charge of a gazetted post is being authorised
by the office of the Accountant General based on the sanction of
competent authorities, in the same way as pay and allowances of a
gazetted officer is concerned. This practice has since been
reviewed in the light of the procedure followed in some of the Audit
and Account offices of other States. It has been decided that no
authorisation from the office of the Accountant General is
st
necessary in case of additional charge arrangements from 1 April
1963 onwards, as holding of additional charge of a gazetted post
does not alter the status of a non gazetted officer to that of a
gazetted officer.

[G.O.(P) 312/63/Fin.,
dt. 29 -5-1963]

According to the changed procedure, the additional charge
allowance will be drawn and paid by the Head of Office in the
same manner as his regular pay and allowances are drawn. The
Drawing Officer should however satisfy himself that there is proper
sanction of the competent authority for the additional charge
arrangements and that the officer has actually held the additional
charge of the post during the period for which the charge
allowance is drawn and also that the rate of allowance sanctioned
and drawn is as per rules etc. The charge allowance thus drawn
may be continued to be debited to the same head of account to
which the pay of the non-gazetted officer is debited.
In the case of a non gazetted officer holding additional
charge of the duties of the Head of an Office, who is a gazetted
officer and also a drawing and disbursing officer, the procedure
adopted for the drawal of his normal pay and allowances may be
followed for the drawal of charge allowance also.
Government Decision No. 2
The following criteria will be followed to distinguish between
‘full additional charge’ and ‘discharge of current duties’:-

(i)

An officer appointed to hold ‘full additional charge’ of a post
44

[G.O.(P) 319/72/Fin.,
dt. 31 -7-1972]

<!-- page 55 -->

CHAP.VI]

COMBINATION OF APPOINTMENTS

has to perform all the administrative, financial and statutory
functions and duties in respect of that post.

(ii)

53A.

An officer appointed to discharge current duties of a post
need attend only to the work of a routine nature in respect of
that post.

The posts in respect of which additional charge arrangements may
be ordered shall be as classified below:(I)

Posts not in the same office, establishment or line of promotion or
cadre.-Where the duties and responsibilities are clearly
independent and are eligible for additional pay, e.g., Labour
Commissioner, holding charge of the post of Registrar of Cooperative Societies and Joint Secretary to Government holding
charge of post of a Head of Department.

(II)

Posts in the same office, establishment or line of promotion or
cadre.- Cases of this nature shall further be divided as follows :(a)

When the additional post is subordinate to the regular post,
additional pay shall not be admissible e.g., Superintendent of
Police holding charge of the post of Assistant Superintendent
of Police or Deputy Superintendent of Police and District
Collector holding the charge of the post of Revenue Divisional
Officer under him.

Note. -The reason for the non-grant of additional pay in the above cases is that the
superior officer is expected to supervise the work of the subordinates and
the additional charge arrangements should not entitle him to extra
remuneration. The work of the additional post should be redistributed
among other subordinates in such a way that each one’s load of work is
increased to a small extent that no one need be given additional pay.
(b)

When the additional post is of equivalent and of the same
rank as that of the regular post the following principles shall
apply:
(1)

If additional char ge arrangements are in respect of
different territorial jurisdictions, the posts are definitely
independent and in such cases additional pay shall be
admissible, e.g., Revenue Divisional Officer of one
district/division holding charge of another district/division
and one Block Development Officer holding charge of
another block.

(2)

If additional charge arrangements are in respect of posts
in the same office and of the same rank, additional pay
shall not be admissible if the duties of the additional post
are identical in nature and if the responsibilities are such
as can easily be spread out among others holding the
same post, e.g., if a Deputy Collector goes on leave and
if the Collector has a number of Deputy Collectors
working under him, he should consider whether he can
distribute the responsibilities of the Deputy Collector on
leave to the other Deputy Collectors so as not to
increase substantially each one’s load of work.

(3)

If the additional charge arrangements are in the same
office and if the responsibilities attached to the post are
indivisible and cannot be distributed to more than one
officer, additional pay shall be admissible. In such
cases, a certificate to the effect that the responsibilities
of the post held in additional charge are not divisible,
should be furnished by the competent authority, e.g.,
Secretary to Government of one department holding
charge of the post of Secretary of another Department
45

[G.O.(P) 132/87/Fin., dt.
10-2-1987]

<!-- page 56 -->

KERALA SERVICE RULES

[PART I

and Deputy Director of Animal Husbandry (Key Village)
or Deputy Director of Animal Husbandry (Veterinary) or
Deputy Director of Animal Husbandry (Extension)
holding charge of the other post.
(c)

When the additional post is superior to the regular post and is
carrying higher scale of pay additional pay shall be
admissible, e.g., Deputy Secretary or Joint Secretary to
Government holding charge of the post of Additional
Secretary or Secretary to Government and a Superintendent
of Police or Assistant Inspector General of Police holding
charge of the post of Deputy Inspector General of Police.

CHAPTER VII
DISMISSAL, REMOVAL AND SUSPENSION

54.

The pay and allowances of an officer who is dismissed or
removed from service cease from the date of such dismissal or
removal.

55.

An officer under suspension or deemed to have been placed
under suspension by an order of the appointing authority is
entitled to the following payments: -

[G.O.(P) 573/78/Fin.,
dt. 14 -7-1978]

For the first year of suspension, subsistence allowance at
an amount equal to *the leave salary which the officer would have
drawn had he been on leave on half- pay on the date of
suspension; but the benefit of any increase in pay due to
increment falling due during the period of suspension will not be
admissible during the period, and

*[G.O.(P) 158/77/Fin.,
dt. 24 -5-1977]

This amendment shall be deemed to have come into force
with effect from 1st April 1973.

[G.O.(P) 547/78/Fin., dt.
26-6-1978]

For any period subsequent thereto at three-quarters of such
amount.
In addition, he may be granted to such extent and subject to
such conditions as the authority ordering his suspension may
direct(i)

Dearness allowance and Dearness pay not exceeding the
amount admissible as such had he been on leave on leave
salary equal to the rate of subsistence allowance payable
from time to time.

(ii)

Any other compensatory allowance of which he was in
receipt on the date of suspension.
Note 1. - If an officer under suspension is dismissed with retrospective effect no
recovery is necessary of the subsistence grant already paid to him.
Note 2. -(a)

Deductions shall be made from the subsistence allowance on
account of the following :-

(i) Income Tax and Super Tax (provided the employees annual
income calculated with reference to subsistence allowance is
taxable).
(ii) House rent and allied charges i.e., electricity, water, furniture etc.
(iii) Repayment of loans and advances, taken from Government at such
rates as the Head of the Department deems appropriate.
(iv) Amounts due to Co-operative Stores and Co-operative Credit
Societies.
46

[G.O.(P)141/72/Fin.,
dt. 12 -5-1972]

<!-- page 57 -->

CHAP.VII]

DISMISSAL, REMOVAL AND SUSPENSION

(v)

Subscription to the Family Benefit Scheme, if the officer is a
subscriber to the scheme.

(b)

Deduction on account of the following shall be optional: (i)

[G.O.(P) 83/80/Fin.,
dt. 23 -1-1980]

Premia due on Postal Life Insurance Policies and State
Life Insurance Policies -Official Branch.

(ii) Refund of advances taken from General Provident Fund.
The written consent of the officer should be obtained in the
case of these optional deductions.
(c)

Deductions of the following nature should not be made from the
subsistence allowance:(i)

Subscription to a General Provident Fund.

(ii) Amount due to Court attachments.
(iii) Recovery of loss to Government for which an officer is
responsible.
(d)

As regards recovery of overpayments, there is no bar to effect
the same from the subsistence allowance, but such recoveries of
overpayments should not ordinarily be made at a rate greater
than one-third of the amount of the subsistence allowance i.e.,
exclusive of dearness allowance if any, admissible to him.

Note 3.- No payment under the rules shall be made unless the officer furnishes a
certificate that he is not engaged in any other employment, business,
profession or vocation. In the case of non-gazetted officers, the certificate
signed by the officer should be countersigned by a gazetted officer, in
token of acceptance. It should then be attached to the bill in which
subsistence allowance for the period covered by the certificate is
claimed. In the case of gazetted officers payment of subsistence
allowance will be authorised by the Accountant General on the basis of
the sanction issued by the competent authority and the Treasury Officer
will pay the allowance only if a similar countersigned certificate is
attached to the bill claiming it.
Note 3A.-Compensatory allowance under clause (ii) above may be granted
provided the officer certifies that for the period for which the allowance is
claimed, he continued to incur the whole or a considerable part of the
expense to meet which the allowance was granted. The maximum
period for which the compensatory allowance may be paid shall be
limited to 120 days.

[G.O.(P) 320/68/Fin.,
dt. 26 -6-1968]

Note 4. - In the case of an officer under suspension before 27th July 1962
recovery of House Construction Advance shall be limited to 1/3 of the
subsistence allowance or the usual rate of monthly instalment whichever
is lower. No penal interest shall be levied on the defaulted portion of the
instalment.
55A.

[Deleted]
This amendment shall be deemed to have come into force
with effect from 3rd February 1988.

55B.

(i)

Notwithstanding any thing contained in Rule 55, when an officer is
placed under suspension while on leave without allowances, he
shall not be eligible for any subsistence allowance during the
period of the leave. On the expiry of the leave if he continues to
be on suspension, he shall be entitled to the subsistence
allowance. If he is reinstated before the expiry of the leave, he
shall continue to be on leave till its expiry, unless the officer other
wise desires.

(ii)

In the case of an Officer on leave with allowances, the orders of
47

[G.O.(P) 549/88/Fin.,
dt. 31 -8-1988]

[G.O.(P) 907/97/Fin.,
dt. 24-1 0-1997]

<!-- page 58 -->

KERALA SERVICE RULES

suspension shall have the effect of cancelling the leave for the
period of suspension.
He shall be entitled to subsistence
allowance.
56.

(1)

When an officer who has been dismissed, removed or
compulsorily retired including an officer who has been
compulsorily retired under Rule 60A, is reinstated as a result of
appeal or review or would have been so reinstated, but for his
retirement on superannuation while under suspension or not, the
authority competent to order reinstatement shall consider and
make a specific order(a)

regarding the pay and allowances to be paid to the officer for
the period of his absence from duty including the period of
suspension preceding his dismissal, removal, or compulsory
retirement, as the case may be,

( b ) whether or not the said period shall be treated as a period
spent on duty, and
(c)

(2)

in the case of an officer who was compulsorily retired under
Rule 60A and subsequently reinstated, for the recovery of the
relevant benefits, if any, already paid to him.

Where the authority competent to order reinstatemen t is of opinion
that the officer who had been dismissed, removed or compulsorily
retired, has been fully exonerated, the officer shall, subject to the
provisions of sub-rule (6) be paid the full pay and allowances to
which he would have been entitled had he not been dismissed,
removed or compulsorily retired or suspended prior to such
dismissal, removal or compulsory retirement as the case may be:
Provided that where such authority is of opinion that the
termination of the proceedings instituted against the officer had
been delayed for reasons directly attributable to the officer, it may,
after giving him an opportunity to make his representation and
after considering the representation, if any, submitted by him,
direct, for reasons to be recorded in writing, that the officer shall
subject to the provisions of sub-rule (7), be paid for the period of
such delay, only such amount (not being the whole) of such pay
and allowances as it may determine.

(3)

In a case falling under sub-rule (2), the period of absence from
duty including the period of suspension preceding dismissal,
removal or compulsory retirement as the case may be, shall be
treated as a period spent on duty for all purposes.

(4)

In cases other than those covered by sub-rule (2) including cases
where the order of dismissal, removal or compulsory retirement
from service is set aside by the appellate or reviewing authority
solely on the ground of non -compliance with the requirements of
clause (2) of Article 311 of the Constitution and no further enquiry
is proposed to be held, the officer shall, subject to the provisions
of sub-rules (6) and (7) be paid such amount (not being the
whole) of the pay and allowances to which he would have been
entitled, had he not been dismissed, removed or compulsorily
retired or suspended prior to such dismissal, removal or
compulsory retirement as the case may be, as the competent
authority may determine, after giving notice to the officer of the
quantum proposed and after considering the representation, if
any, submitted by him in that connection within such period as
may be specified in the notice:
Provided that except in the case of such officers as are
governed by the provisions of the Payment of Wages Act, 1936
(Central Act 4 of 1936), any payment under this sub-rule shall be
48

[PART I

<!-- page 59 -->

CHAP.VII]

DISMISSAL, REMOVAL AND SUSPENSION

restricted to a period of three years immediately preceding
reinstatement or retirement on superannuation, as the case may
be.
(5)

In a case falling under sub-rule (4), the period of absence from
duty including the period of suspensio n preceding his dismissal,
removal or compulsory retirement, as the case may be, shall not
be treated as a period spent on duty, unless the competent
authority specifically directs that it shall be so treated for any
specified purpose:
Provided that if the officer so desires such authority may
direct that the period of absence from duty including the period of
suspension preceding his dismissal, removal or compulsory
retirement, as the case may be, shall be converted into leave of
any kind due and admissible to the officer.
Note1.- The order of the competent authority under the preceding proviso shall
be absolute and no higher sanction shall be necessary for the grant of (a) Leave without allowances in excess of three months in the case of
a temporary officer; and
(b) Leave of any kind in excess of five
permanent officer.

years in the case of a

Note2.-The leave of any kind due and admissible referred to in the proviso shall
include commuted leave also.

56A.

(6)

The payment of allowances under sub-rule (2) or sub-rule (4) shall
be subject to all other conditions under which such allowances are
admissible.

(7)

The amount (not being the whole) of such pay and allowances
determined under the provision to sub -rule (2) or under sub-rule
(4) shall not be less than the subsistence allowance and other
allowances admissible under Rule 55.

(8)

Any payment made under this rule to an officer on his
reinstatement shall be subject to adjustment of the amount, if any,
earned by him thr ough an employment during the period between
the date of removal, dismissal or compulsory retirement, as the
case may be, and the date of reinstatement.
Where the
emoluments admissible under this rule are equal to or less than
the amounts earned during the employment elsewhere, nothing
shall be paid to the officer.

(1)

Where the dismissal, removal or compulsory retirement of an
officer is set aside by a Court of Law and such officer is reinstated
without holding any further inquiry the period of absence from duty
shall be regularised and the officer shall be paid pay and
allowances in accordance with the provisions of sub-rule (2) or
sub-rule (3) subject to the directions, if any, of the court.

(2)

Where the dismissal, removal or compulsory retirement of an
officer is set aside by the court solely on the ground of noncompliance with the requirements of clause (2) of Article 311 of
the Constitution, and where he is not exonerated on merits, the
pay and allowances to be paid to the officer for the period
intervening between the date of dismissal, removal or compulsory
retirement including the period of suspension preceding such
dismissal, removal or compulsory retirement, as the case may be,
and the date of reinstatement shall be determined by the
competent authority and the said period shall be regularised, in
accordance with the provisions contained in sub-rule (4), (5) and
(7) of Rule 56.

(3)

If the dismissal, removal or compulsory retirement of an officer is
49

[G.O.(P) 839/92/Fin.,
dt. 4-11-1992]

<!-- page 60 -->

KERALA SERVICE RULES

set aside by the court on the merits of the case, the period
intervening between the date of dismissal, removal or compulsory
retirement including the period of suspension preceding such
dismissal, removal or compulsory retirement, as the case may be,
and the date of reinstatement shall be treated as duty for all
purposes and he shall be paid the full pay and allowances for the
period, in which he would have been entitled, had he not been
dismissed, removed or compulsorily retired or suspended prior to
such dismissal, removal or compulsory retirement, as the case
may be.

56B.

(4)

The payment of allowances under sub-rule (2) or sub -rule (3) shall
be subject to all other conditions under which such allowances are
admissible.

(5)

Any payment made under this rule to an officer on his
reinstatemen t shall be subject to adjustment of the amount, if any,
earned by him through an employment during the period between
the date of dismissal, removal or compulsory retirement and the
date of reinstatement. Where the emoluments admissible under
this rule are equal to or less than those earned during the
employment elsewhere, nothing shall be paid to the officer.

(1)

When an officer who has been suspended is reinstated or would
have been so reinstated but for his retirement on superannuation
while under suspension, or has retired from service on
superannuation before the conclusion of the disciplinary
proceedings against him the authority competent to order
reinstatement shall consider and make a specific order.
(a)

regarding the pay and allowances to be paid to the officer for
the period of suspension ending with reinstatement or the
date of his retirement on superannuation, as the case may
be; and

(b)

whether or not the said period shall be treated as a period
spent on duty.

(2)

Notwithstanding anything contained in Rule 55, where an officer
under suspension dies before the disciplinary, or court
proceedings instituted against him are concluded, the period
between the date of suspension and the date of death shall be
treated as duty for all purposes and his family shall be paid the full
pay and allowances for that period to which he would have been
entitled had he not been suspended, subject to adjustment in
respect of subsistence allowance already paid.

(3)

Where the authority competent to order reinstatement is of the
opinion that the suspension was wholly unjustified, the officer
shall, subject to the provisions of sub-rule (8) be paid the full pay
and allowances to which he would have been entitled, had he not
been suspended:
Provided that where such authority is of the opinion that the
termination of the proceedings instituted against the officer had
been delayed owing to reasons directly attributable to the officer, it
may after giving him an opportunity to make his representation
and after considering the representation, if any, submitted by him,
direct, for reasons to be recorded in writing, that the officer shall
be paid for the period of such delay only such amount (not being
the whole) of such pay and allowances as it may determine.

(4)

In a case falling under sub-rule (3), the period of suspension shall
be treated as a period spent on duty for all purposes.

(5)

In cases other than those falling under sub-rules (2) and (3), the
officer shall subject to the provisions of sub -rules (8) and (9) be
50

[PART I

<!-- page 61 -->

CHAP.VII]

DISMISSAL, REMOVAL AND SUSPENSION

paid such amount (not being the whole) of the pay and allowances
to which he would have been entitled had he not been suspended,
as the competent authority may determine, after giving notice to
the officer of the quantum proposed and after cons idering the
representation, if any, submitted by him in connection within such
period as may be specified in the notice.
(6)

Where suspension is revoked pending finalisation of the
disciplinary or court proceedings, any order passed under sub-rule
(1) before the conclusion of the proceedings against the officer
shall be reviewed on its own motion after the conclusion of the
proceedings by the authority mentioned in sub -rule (1) who shall
make an order according to the provisions of sub -rule (3) or subrule ( 5), as the case may be.

(7)

In a case falling under sub-rule (5), the period of suspension shall
not be treated as a period spent on duty unless the competent
authority specifically directs that it shall be so treated for any
specified purpose:
Provided that if the officer so desires, such authority may
order that the period of suspension shall be converted into leave
of any kind due and admissible to the officer.
Note1.-The order of the competent authority under the preceding proviso shall be
abs olute and no higher sanction shall be necessary for the grant of(a)

leave without allowances in excess of three months in the case of a
temporary officer, and

(b)

leave of any kind in excess of five years in the case of a permanent
officer.

Note2.-The leave of any kind due and admissible referred to in the proviso shall
include commuted leave also.
(8)

The payment of allowances under sub-rule (2), sub-rule (3) or
sub-rule (5) shall be subject to all other conditions under which
such allowances are admissible.

(9)

The amount (not being the whole) of such pay and allowances
determined under the proviso to sub-rule (3) or under sub-rule (5)
shall not be less than the subsistence allowance and other
allowances admissible under Rule 55.

[G.O.(P) 839/92/Fin., dt.
4-1 1-1992]

[G.O.(P) 573/78/Fin., dt.
14-7-1978]

Note1.- The amount of subsistence allowance already drawn should be adjusted
against the pay and allowances or proportion of them granted under
Rules 56, 56A or 56B or leave salary which may be granted to the officer.
Note2.- The orders of revocation of suspension or of reinstatement after
dismissal, removal or compulsory retirement from service take effect form
the date of the order and the intervening period, i.e., the period from the
date of order to the date of joining duty shall be regularised by granting
joining time and/or leave due and admissible to the officer concerned.
However, cases where there is an abnormal time-lag between the date of
such order and the date on which the officer concerned reports for duty
shall be decided by Government, on merits.
Note 3. - When a period of suspension is ordered to be converted into leave, the
amount of subsistence allowance and compensatory allowances already
received in excess of the leave salary and allowances admissible on
such conversion, shall be refunded.

[G.O.(P) 442/81/Fin.,
dt.10-7-1981]

Effective from 10th July 1981.
Note 3A.- If the officer is a subscriber to the Family Benefit Scheme who has
received the payment due under the scheme and desires to avail himself
of the benefit of the scheme, he shall refund the entire amount received.
In addition, he shall also make the contribution for the period of service
51

[G.O.(P) 83/80/Fin.,
dt.23-1-1980]

<!-- page 62 -->

KERALA SERVICE RULES

[PART I

from the date of dismissal, removal or compulsory retirement to the date
of reinstatement, in case the period is ordered to be counted as duty for
all purposes including pay and allowances. In cases however where the
period is ordered to be treated as eligible leave, the subscriber need
make his contribution only for period of eligible leave for which he is
entitled to get full or half pay.
Note 4. - A permanent post vacated by the dismissal, removal, compulsory
retirement or reduction of a Government servant to a lower service, grade
or pos t or to a lower time-scale should not be filled substantively until the
expiry of the period of one year from the date of such dismissal, removal,
compulsory retirement or reduction, as the case may be. Where on the
expiry of the period of one year, the permanent post is filled and the
original incumbent of the post is reinstated thereafter, he should be
accommodated against any post which may be substantively vacant in
the grade to which his previous substantive post, belonged. If there is no
such vacant post, he should be accommodated against a supernumerary
post which should be created in this grade with proper sanction and with
the stipulation that it would be terminated on the occurrence of the first
substantive vacancy in that grade.
Note 5.- I f an officer under suspension is dismissed *or removed with
retrospective effect from the date of suspension, no recovery should be
made of the subsistence allowance already paid to him, and arrears of
subsistence allowance, if any, due to him upto the date of the order
dismissing *or removing him should be paid to him. The arrears of
subsistence allowance due to the officer should not be adjusted against
any amounts due from him to Government.

*[G.O.(P) 46/80/Fin.,
dt.15-1-1980]

Note 6. - If an officer under suspension is compulsorily retired with retrospective
effect from the date of suspension, the pension due to the officer from the
date of such retirement to the date of the order compulsorily retiring him
shall be with held if the rate of pension is lower than or equal to the rate
of subsistence allowance granted to him. In case the pension happens
to be higher than the subsistence allowance granted the difference shall
be paid to the officer. (Note 6 shall be deemed to have come into force
with effect form 22nd August 1960).
G OVERNM ENT DECISION
The term ‘Pension’ used in Note 6 does not include deathcum-retirement gratuity.

[G.O.(P) 73/66/Fin., dt.
1-3-1966]

Effective from 22nd August 1960.
Ruling No. 1
Notwithstanding the provision contained in clause (4), an
officer who is reinstated under clause (1) and who would have
been eligible for promotion to a higher post during the period of
suspension but for the suspension will be entitled to the pay and
allowances of the higher post only from the date on which he
assumes charge of that post.

[G.O.(P) 593/63/Fin., dt.
21-11-1963]

Ruling No. 2

57.

It is not necessary to create an additional post to draw the
pay and allowances of an officer who has been placed under
suspension and is rei nstated in service, treating the period of
absence as duty.

[G.O.(P) 273/73/Fin.,
dt. 11 -7-1973]

An officer who is detained in custody, whether on a criminal
charge, or otherwise, for a period exceeding forty-eight hours, or
is undergoing imprisonment, shall be deemed to be under
suspension with effect from the date of commencement of the
detention or imprisonment, as the case may be, and shall not be
allowed to draw any pay and allowances during such period of

[G.O.(P) 266/67 /Fin., dt.
6-7-1967]

52

<!-- page 63 -->

CHAP.VII]

DISMISSAL, REMOVAL AND SUSPENSION

suspension other than any subsistence allowance and other
allowances that may be granted in accordance with Rule 55, until
he is reinstated in service. An adjustment of his pay and
allowances for such periods should thereafter be made according
to the circumstances of the case, the full amou nt being given only
in the event of the officer being acquitted of blame or (if the
proceedings taken against him were for his arrest for debt) of its
being provided that the officer’s liability arose from circumstances
beyond his control.
58.

An officer against whom a criminal charge or a proceeding for
arrest for debt is pending in a court of law should also be placed
under suspension by the issue of specific orders to this effect
during periods when he is not actually detained in custody or
imprisoned (e.g., whilst released on bail) if the charge made or
proceeding taken against him is connected with his position as an
officer or is likely to embarrass him in the discharge of his duties
as such or involves moral turpitude unless there are exceptional
reasons for not adopting this course. In regard to his pay and
allowances the provisions of the rule above shall apply.

59.

Leave may not be granted to an officer under suspension.

[G.O.(P) 266/67/Fin.,
dt. 6 -7-1967]

CHAPTER VIII
COMPULSORY RETIREMENT

60.

(a)

Except as otherwise provided in these rules the date of
compulsory retirement of an officer shall take effect from the
afternoon of the last day of the month in which he attains the age
of 55 years. He may be retained after this date only with the
sanction of Government on public grounds which must be
recorded in writing, but he must not be retained after the age of
60 years except in very special circumstances.

[G.O.(P) 344/75/Fin.,
dt. 31-7-1975]

(a a)

An Officer in the Kerala Judicial Service or the Kerala State
Higher Judicial Service shall ordinarily retire when he attains the
age of 60 years; but he shall have the option to retire when he
attains the age of 58 years. His continuance in service beyond
the age of 58 years shall however be subject to review by the
High Court as per the provisions of the Kerala Judicial Service
Rules and the Kerala State Higher Judicial Service Rules.

[G.O.(P) 457/95/Fin.,
dt. 28-7-1995]

This amendment shall be deemed to have come into force
st
with effe ct from 31 December , 1992.
(b)

(c)

Officers in the Last Grade Service on 7th April 1970 will retire on
the afternoon of the last day of the month in which they attain the
age of 60 years provided that this benefit will be available to them
only as long as they continue to be in the Last Grade Service as
defined in Rule 12 (16-A).

[G.O.(P) 344/75/Fin.,
dt. 31-7-1975]

Note. - Ex-servicemen who were in armed force prior to 7th April, 1970 and who
have been appointed as Last Grade Employees in the Last Grade
Service in the State after 7th April 1970 will also be eligible for the benefit
of the above rule provided they continue to be in the Last Grade Service.

[G.O. (P) 535/90/Fin.,
dt. 25-1 0-1990]

The teaching staff of all educational institutions (including
Principals of Colleges) who complete the age of 55 years during
the course of an academic year shall continue in service till the
last day of the month in which the academic year ends. *[They
shall be entitled to the benefits of increments and promotion
which fall due, before the last day of the month in which they
attain the age of 55 years. But they shall not be eligible for
53

<!-- page 64 -->

KERALA SERVICE RULES

increment or promotion during the period of their service beyond
such date]. If they are on leave on the day they attain the age of
55 years and if there is no prospect of their returning to duty
before the closing day of the academic year for vacation they
shall be retired with effect from the last day of the month in which
they attain the age of 55 years. But in cases where officers
coming under this rule are under suspension on the date of
superannuation or thereafter but before the closing day of the
academic year, they shall be retired from service on the date of
superannuation or on the date of suspension whichever is later.
*Effective from 30th March 1982.
If, however, the day on which the teaching staff (including
Principals of Colleges) attain the age of 55 years falls withi n the
period of one month beginning with the day of reopening of the
institutions they shall cease to be on duty with effect from the date
of such reopening and they shall be granted additional leave from
the date of reopening to the last day of the month in which they
attain the age of 55 years. They shall be entitled to the benefit of
increment if it falls due before the actual date on which they attain
the age of 55 years.

[PART I

*[G.O.(P) 109/82/Fin.,
dt. 8-3-1982]
[G.O.(P) 1005/79/Fin.,
dt. 15-1 1-1979]

nd

Effective from 22 May 1970.
If they are eligible to continue in service till the close of the
academic year under the 1st paragraph of this sub-rule they shall
be granted additional leave from the date of closing for vacation
till the last day of the month when the date of closing is earlier
than the last day of the month.

[G.O.(P) 344/75/Fin.,
dt. 31-7-1975]

The additional leave granted under this sub-rule will not be
counted against the eligible leave and will count for pension.
During the period of leave they will draw leave allowance at the
same rate as the pay and allowances they would have drawn if
they were on duty.
Exception.- [Deleted]
st

Effective from 1 April 1990.
Explanation.- For the purpose of this sub-rule, ‘teaching staff’
includes (1) Assistant Educational Officers, including Deputy Inspectors of
Malabar area.
(2) District Educational Officers and officers belonging to the
cadre, but working in other assignment.
(3) The following officers of the State Institute of Education,
namely :(a) Junior Evaluation Officer,
(b) Special Assistant in English,
(c) Technical Assistant,
(d) Text Books Research Officer,
(e) Education Techniques Officer,
(f)

Junior Science Consultant,

(g) Instructors in Science, and
(h) Staff drafted from the teaching staff of Education
Department, provided the continuance of this staff in
service till the closing day of schools is absolutely
54

[G.O. (P) 229/90/Fin.,
dt. 29-3-1990]

<!-- page 65 -->

CHAP.VIII]

COMPULSORY RETIREMENT

essential in the interest of work and that they are entitled
to this benefit in their parent Department.
Items (1) and (2) above shall be deemed to have come into
force with effect from 9th August 1968 and item No (3) shall be
deemed to have come into force with effect from 8 th May 1969.

[G.O.(P) 344/70/Fin.,
dt. 22-5-1970]

(4) (a) Director of Collegiate Education.

[G.O.(P) 622/71/Fin.,
dt. 12-1 0-1971]

th

Effective from 9 June 1971.
(b) Additional Director of Collegiate Education.
(c) Deputy Director of Collegiate Education.
Note1.- Item (b) shall be deemed to have been added with effect from the 26th
November 1980 and item (c) shall be deemed to have been added with
effect from 21st August 1974.

[G.O.(P) 264/81/Fin.,
dt. 2-5-1981]

(d) Assistant Director of Collegiate Education.
(e) Special Officer (University Grants Commission Schemes)
Note2.-The items (d) and (e) shall be deemed to have come into force with
effect from the 8th July 1981.

[G.O.(P) 122/82/Fin.,
dt. 18-3-1982]

(5) Special Officer for Direct Payment in the Department of
Collegiate Education.

[G.O.(P) 248/73/Fin.,
dt. 22-6-1973]

This amendment shall be deemed to have come into
th
force with effect from 11 December 1972.
(6) The following Officers appointed from the teaching
department of the Medical College Service, namely :-

[G.O.(P) 961/86/Fin.,
dt. 30-1 2-1986]

(a) Director of Medical Education, and
(b) Joint Director of Medical Education
This amendment shall be deemed to have come into force
with effect from 29th August, 1984.
(7) The following officers appointed from the Teaching Staff of
the Technical Education Department:(a) Director of Technical Education.
(b) Joint Director of Technical Education.
(c) Professor (Direct payment).
(d) Deputy Director of Technical Education.
(e) Joint Controller of Technical Examinations.
(f)

Training Officers.

(g) Technical Officer.
(h) Stock Verification Officer.
(i)

Assistant Director of Technical Education.

(j)

Special Officers appointed for starting of Technical
Educational Institutions.

(k) Director, Kerala State Science
Museum, Thiruvananthapuram.
(l)

and

Technology

Director, Institute of Human Resource of Development
for Electronics.

(m ) Public Relations Officer, Directorate
Education, Thiruvananthapuram.

of

Technical

Note. - The benefit of Rule 60 (c) part I Kerala Service Rules will be available to
the above officers only if the incumbents holding the posts descent from
the teaching faculty.
55

[G.O.(P) 1034/97/Fin.,
dt. 12-1 1-1997]

<!-- page 66 -->

KERALA SERVICE RULES

[PART I

The items (a) to (j) above shall be deemed to have come
into force on the 2nd day of July 1990 and items (k) to (m) shall be
deemed to have come into force on the 19th day of October 1990.
Note 1. - All officers other than those in the Last Grade Service, who are past the
age of 55 years on the 4th day of May 1967 or who attain the age of 55
years in a period of three months from that date will retire only on the
date of expiry of three months from the said date.
Note 2. - The teaching staff referred to in the above rule who are past the age of
55 years on the 4th day of May 1967 or who attain the age of 55 years
within a period of three months from that date will continue in service till
the cl osing day of the academic year 1967-68 (Notes 1 and 2 shall be
deemed to have come into force with effect from the 4th day of May
1967).
Note 3. -Even in cases where it is found absolutely necessary to retain the
services of an officer who has attained the age of 55 years as far as
possible only re-employment after retirement should be resorted to,
which shall not ordinarily be sanctioned for more than one year at a
time.
Note 4. -In the case of an officer whose year of birth is known but not the exact
month and date the first July shall be taken as the date of birth; where
the year and month are known but not the exact date, the 16th day of the
month shall be taken as the date of birth.
Note 5. -Except when extension of service is specifically sanctioned the
retirement of an officer is automatic and no separate sanction is
required.
Note 6. - For the purpose of this rule as well as the rules in Appendix X, in the
case of an officer who entered service prior to first January 1950 and
whose date of birth has been noted in Malabar Era in the Service
Records, the age may be calculated in the Malabar Era.
Note 7. - Completion of 55 years of age in service is in the afternoon and not in
the forenoon. A person whose date of birth is first of July completes his
55th year on 30th June, and that date (30th June) is the last day of the
month in which he completes the 55th year. On first of July he is on his
56th year and that day is a non-working day for him. He shall cease to
be in service on and from 1st July.
Note 8.- A teacher whose date of birth is first July and who attains the age of 55
years shall not continue in service till the end of the academic year.
However, such of those who continue in service during the academic
year 1974-75 under the practice hitherto in vogue shall be allowed to
continue in service till the end of April 1975.
Note 9. -The benefit contemplated in sub-rule (b) above will not be available to
those reverted to the Last Grade Service, other wise than for want of
vacancy. (This will take effect from the date of orders).
The above amendments (Except Notes 1 to 6 and 9 above) shall
be deemed to have come into force with effect from 5th April 1974.

[G.O.(P) 344/75/Fin.,
dt. 31-7-1975]

Note 10. - In this rule the words “Last day of the month” used mean the last day
of the month in Christian Era. In cases where the date of
superannuation is calculated in the Malabar Era in accordance with Note
6, the corresponding date in the Christian Era shall be reckoned for
arriving at the last day of the month.

[G.O.(P) 11/76/Fin.,
dt. 13-1-1976]

This amendment shall be deemed to have
come into force with effect on and from 5th April
1974.
56

<!-- page 67 -->

CHAP.VIII]

COMPULSORY RETIREMENT

Note 11. - In cases where the academic year in respect of the institutions under
the Director of Public Instruction is extended beyond the 31 st of March in
any year, the teaching staff of such institutions who are allowed to
continue in service beyond the date of superannuation under sub-rule
(c) shall retire on the last day of March itself.

[G.O.(P) 150/84/Fin.,
dt. 13-3-1984]

Note12: -The benefit contemplated in sub-rule (b) above will be available to the
following categories of employees also from the dates indicated against
each.

[G.O.(P)11/96/Fin.,
dt. 1-1-1996]

TABLE
Sl
No.

Category

1.(i)

Full time Contingent Employees who were
appointed as provisional employees for the period
from 1.4.1965 to 31-3-1968 and absorbed as Last
Grade Employees of regular establishment with
effect from 7.4.1970.

(ii)

2
3

*4

Date from which
the benefit shall
be deemed to
have come into
force.

27.10.1988

Full time Contingent Employees who were
appointed as provisional employees for the period
from 1.4.1968 to 7.4.1970 and absorbed as Last
Grade Employees of regular establishment with
effect from 7.4.1970

29.11.1989

Villagemen who were in service on 7.4.1970 and
who are continuing as such

11.3.1976

Ex-Servicemen who had been in Armed Forces
prior to 7-4-1970 and appointed as Village men in
the State Service after 7.4.1970 and continuing as
such.

1.1.1992

Ex-Assam Rifles personnel who were in Assam
Rifles prior to 7th April, 1970 and who have been
appointed as Last Grade Employees in the Last
Grade Service in the State Service after the 7th
April, 1970 and continuing as such.

* [G.O.(P) 904/97 /Fin.,
dt. 22-10-1997]
19.9.1995.

Ruling No. 1
The term “educational institution” mentioned in the above
rule will include besides the institutions coming under the
Education Department, Institutions such as Medical Colleges,
Agricultural Colleges, Veterinary Colleges, Engineering Colleges,
Law Colleges, Training Colleges, Polytechnics, Industrial Schools,
Fisheries Schools and such other Educational Institutions which
have regular authorised vacations.
Ruling No. 2
The teaching staff of educational institutions who are
allowed to continue in service beyond the date of superannuation
till the end of the academic year will not be eligible for any leave
other than casual leave during the period of their service beyond
the date of superannuation and if they apply for any leave other
than casual leave during the period, they shall be retired from
service from the date of such application for leave.
57

[G.O.(P) 296/72/Fin.,
dt. 18 -7 -1972]

<!-- page 68 -->

KERALA SERVICE RULES

60A.

[Deleted]
rd

Effective from 3 February, 1988

CHAPTER IX
LEAVE
SECTION 1 – E XTENT O F APPLICATION
61.

62.

Unless in any case it be otherwise distinctly provided, the rules in this
Chapter apply to all officers to whom these service rules as a whole
apply.
(1)

Unless in any case it be otherwise distinctly provided by or under
these rules, an officer transferred to a service or post to which these
rules apply, from a service or post to which they do not apply, is not
ordinarily entitled to leave under these rules in respect of duty
performed before such transfer:
Provided that in the case of an officer who holds a
substantive, officiating or temporary post on the day previous to the
one on which these rules come into force, the maximum limit of
accumulation of earned leave specified in Rule 78 shall not apply
during the period of the first five years from the date of his
appointment to the service or from that of the commencement of
these rules whichever is later and such an officer may be allowed
during the said period of five years to avail himself of the accumulated
leave to his credit:
Provided further that on the expiry of the said period of five
years the leave at the credit of the officer in excess of the normal
maximum limit of accumulation of leave laid down in Rule 78 shall
lapse:
Provided also that he shall not earn leave during that period
unless the accumulated leave at his credit falls below 180 days.

63.

(2)

Subject to the provisions contained in Rule 77(vi), the half pay leave
to be carried forward will be the balance of furlough leave or leave on
half average pay for which an officer is eligible on the date on which
these rules come into force diminished by the leave on medical
certificate taken before such date, under the old rules governing him.

(a)

If an officer, who quits the public service on compensation or invalid
pension or gratuity, is re-employed and if his gratuity is thereupon
refunded or his pension held wholly in abeyance, his past service
thereby becoming pensionable on ultimate retirement, he may, at the
discretion of the Government and to such extent as the Government
may decide, count his former service towards leave.

(b)

An officer who is dismissed or removed from the public service, but is
reinstated on appeal or revision, is entitled to count his former service
for leave.
Note 1.- The re-employment of a person who has retired on a superannuation or
retiring pension is generally an exceptional and temporary expedient. In such
cases, the service of the re-employed pensioner should be regarded as
temporary and his leave during the period of re-employment regulated by the
rules in Appendix VIII.
Note 2.- Resignation of public service even though it is followed immediately by reemployment entails forfeiture of past service and constitutes an interruption of
duty. But resignation to take up another appointment does not constitute an
interruption.
58

[PART I

[G.O. (P) 549/88/Fin.,
dt. 31 -8 -1988]

<!-- page 69 -->

CHAP.IX]

LEAVE

SECTION II – GENERAL C ONDITIONS
64.

The Government may issue orders specifying the authority by
whom leave other than study leave and leave without allowances
exceeding a period of four months at a time, may be granted.

[G.O.(P)481/70/Fin.,
dt. 6 -7-1970]

th

Effective from 6 March 1968.
The power to sanction leave without allowances exceeding a
period of four months at a time will rest with Government.

65.

66.

[G.O.(P)313/76/Fin.,
dt. 5-10-1976]

This amendment shall be deemed to have come into force
with effect from 14 th November 1966.
Leave cannot be claimed as a matter of right. When the
exigencies of the public service so require, discretion to refuse or
revoke leave of any description is reserved to the authority
empowered to grant it.
Note. - The nature of the leave due and applied for by an officer cannot be altered
at the option of the sanctioning authority and while it is open to the
sanctioning authority to refuse or revoke the leave due and applied for, it
is not open to him to alter the nature of such leave.
Leave ordinarily begins on the day on which transfer of charge is
effected and ends on the day preceding that on which charge is
resumed. When the day immediately preceding the day on which
an officer’s leave begins or immediately following the day on which
his leave expires is a holiday or one of a series of holidays, the
officer may leave his station at the close of the day before, or
return to it on the day following such holiday or series of holidays;
provided that(a)

(b)

(c)

his transfer or assumption of charge does not
involve the handing or taking over of securities or
of money other than a permanent advance;

his early departure does not entail a correspondingly early
transfer from another station of an officer to perform his
duties; and
the delay in his return does not involve a corresponding delay
in the transfer to another station of the officer who was
performing his duties during his absence or in the discharge
from Government service of a person temporarily appointed
to it.

Ruling
A restricted holiday enjoyed with the permission of the
competent authority shall be treated as holiday for the purpose of
this rule.
67.

On condition that the departing officer remains responsible for the
money in his charge, a competent authority may declare that
proviso (a) under Rule 6 is not applicable to any particular case.

68.

Unless the competent authority in any case otherwise directs (a)

if holidays are prefixed to leave, the leave and any
consequent re-arrangement of pay and allowances takes
effect form the first day after holidays; and

(b)

if holidays are affixed to leave, the leave is treated as having
terminated on, and any consequent re-arrangement of pay
and allowances takes effect from, the day on which the leave
would have ended, if holidays had not been affixed.
The following procedure is prescribed when vacation or
gazetted holidays are permitted to be prefixed or affixed to
leave :59

[G.O.(P) 458/66/Fin.,
dt. 13-1 0-1966]

<!-- page 70 -->

KERALA SERVICE RULES

Note 1. -(i)

When they are prefixed to leave, the officer proceeding on leave will
report before leaving the station, or if for urgent reasons the leave is
granted during vacation or gazetted holidays, as soon as it is
granted that he will cease to discharge the duties of his post with
effect from the end of vacation or holidays. The relieving officer will
then assume the duties of the post at the end of the vacation or
holidays in the ordinary course.

[PART I

[G.O. (P) 482/82/Fin.,
dt. 26 -8-1982]

(ii) When a vacation or holidays are affixed to leave, the officiating
officer will be relieved in the ordinary way before the vacation, or
holidays, and the officer on leave will return at the end of the
vacation or holidays, but will be regarded as having assumed the
duties of the post with effect from the commencement of the
vacation or holidays.
(iii) Except in cases covered by (i) and (ii) above, transfer of charge
certificates should be signed by both the relieved and relieving
officers on the day on which charge is transferred.
Note 2. - (i)

When a Government Servant is certified medically unfit to attend
office, holiday(s) if any immediately preceding the day he is so
certified shall be allowed automatically to be prefixed to leave and
the holiday(s) if any immediately succeeding the day he is so
certified (including that day) shall be treated as part of the leave;
and

[G.O.(P) 482/82/Fin.,
dt. 26 -8-1982]

(ii) When a Gov ernment Servant is certified medically fit for joining duty,
holiday(s) if any, succeeding the day he is so certified (including
that day) shall automatically be allowed to be suffixed to the leave,
and holiday(s) if any, preceding the day he is so certifi ed shall be
treated as part of the leave.
(iii) Except in cases covered by (i) and (ii) above, transfer of charge
certificates should be signed by both the relieved and relieving
officers on the day on which charge is transferred.
The note shall be deemed to have come into force with effect
from 26th August 1982.
Ruling No. 1

A restricted holiday enjoyed with the permission of the
competent authority shall be treated as holiday for the purpose of
this rule.

[G.O.(P)458/66/Fin.,
dt. 13-1 0-1966]

Ruling No.2
There is no objection to an officer in a vacation
Department being permitted to suffix holiday (s) to leave and also
to enjoy the vacation in continuation of the holiday so suffixed to
leave.
69.

An officer on leave may not take any service or accept any
employment
without obtaining the previous sanction of the
authority empowered to fill up the post held by him.
Note:

70.

This rule does not apply to casual literary work, or to service as an
examiner or similar employment; nor does it apply to acceptance of
foreign service, which is governed by the rules under Chapter XI.

All orders recalling an officer to duty before the expiry of his leave
should state whether the return to duty is optional or compulsory.
If the return is optional, the officer is entitled to no concession. But
if it is compulsory he is entitled to be treated as on duty from the
date on which he starts for the station to which he is ordered, and
to draw Travelling Allowance under rules made in this behalf for
the journey, but to draw until he joins his post, leave salary only.
60

[G.O.(P) 109/81/Fin.,
dt. 9 -2-1981]

<!-- page 71 -->

CHAP.IX]

LEAVE

71.

No officer who has been granted leave on medical certificate may
return to duty without first producing a medical certificate of fitness
in the following form from a Medical Officer not below the rank of
an Assistant Surgeon or the Director of Indigenous Medicine.
Signature of applicant
We, the members of a Medical Committee
I, Civil Surgeon/Assistant Surgeon of
Registered Medical Practitioner of
Director of Indigenous Medicine
do hereby certify that I / we have carefully examined ABC of the
………. Department, whose signature is given above and find that
he has recovered from his illness and is now fit to resume duties in
Government Service. I/we also certify that before arriving at this
decision I / we have examined the original medical certificate(s)
and statement(s) of the case (or certified copies thereof) on which
leave was granted or extended, and have taken these into
consideration in arriving at my/our decision.
Place:…………
Date:………….
The original medical certificate(s) and statement(s) of the
case on which the leave was originally granted or extended shall
be produced before the authority asked to issue the above
certificate(s).
Note. - If the officer on leave is not a Gazetted Officer the authority under which
the officer will be employed on return from leave may, in its discretion
accept a certificate signed by any registered medical practitioner. For
this purpose original certificate(s) of the case should be prepared in
duplicate, one copy being retained by the officer concerned.

72.

(1)

An officer on leave may not return to duty before the expiry of the
period of leave granted to him, unless he is permitted to do so by
the authority which granted him leave.

(2)

Notwithstanding anything contained in sub-rule (1) an officer on
leave preparatory to retirement shall be precluded from
withdrawing his request for permission to retire and from returning
to duty, save with the consent of the authority empowered to
appoint him.
Note 1. - No formal cancellation of the unexpired portion of leave is necessary
when an officer returns to duty before the expiry of his leave. The
cancellation will be effected by the Audit Officer in the case of Gazetted
Officers and by the Head of office in the case of non- gazetted officers.
Note 2. - (a) and (b) [Deleted]

[G.O.(P) 645/81/Fin.,
dt. 13-1 0-1981]

Ruling

When the officer proceeds on leave from the post in which
he is re-employed and avails of the refused leave during the
period of re-employment or after, the leave salary would be same
as would have been admissible in the normal course but for reemployment reduced by the amount of pension and/or pension
equivalent of gratuity and other retirement benefits.

61

[G.O.(P) 218/68/Fin.,
dt. 15 -5-1968]

<!-- page 72 -->

KERALA SERVICE RULES

[PART I

Government Decision
Initial pay on re-employment should be fixed at the
minimum stage of the time-scale of pay prescribed for the post in
which an individual is employed.
In cases where it is felt that the fixation of initial pay of the
re-employed officer at the minimum of the time-scale will cause
undue hardship, the pay may be fixed at a higher stage by
allowing one increment for each year of service which the officer
has rendered before retirement in a post not lower than that in
which he is re-employed subject however to the proviso to
Rule 119, Part III of these rules.

[G.O.(P) 426/64/Fin.,
dt. 20 -6 -1964
&
G.O.(P) 218/68 /Fin.,
dt. 15-5- 1968]

Effective from 20th June 1964.

73.

Note 2.-(c) The leave salary of an officer who is permitted during leave
preparatory to retirement before attaining the age of superannuation, or
during leave under Rule 75 to take up employment under any other
Government under a private employer or employment payable from a
local fund, will also be restricted during such employment as in (b) above.
Any kind of leave under these rules may be granted in
combination with or in continuation of any other kind of leave
except leave under Appendices XII A, XII B and XII C. However,
leave under Appendices XII A and XII C may be granted in
combination with or in continuation of the leave under Appendices
XII A and XII C.

[G.O.(P)1002/97/Fin.,
dt. 6-11-1997]

This amendment shall be deemed to have come into force
th
with effect from 12 April 1984.
Ruling
The eligibility for leave is determined with reference to the
eligibility on the date on which an officer proceeds on leave.
74.

[G.O.(P) 309/76/Fin.,
dt. 29 -9-1976]

Vacation may be taken in combination with or in continuation of
any kind of leave, provided the total duration of vacation and
earned leave taken together, whether the earned leave is taken in
combination with or in continuation of other leave or not, shall not
exceed the amount of earned leave due and admissible to the
officer at a time under Rules 78 and 79.
The combination of
earned leave and commuted leave will be limited to 240 days.
There will be no limit on the half-pay leave that can be availed of
at a time on medical certificate or private affairs. This will apply
even when such leave is taken preparatory to retirement.
Government Decision No. 1
It is permissible to allow a vacation to intervene between
two periods of leave. Similarly vacation may be prefixed or
suffixed to leave or both prefixed and suffixed. The only restriction
is that the total duration of vacations and earned leave together
should not exceed the amount of
earned leave due and
admissible to the officer under Rules 78 and 79, Part I, Kerala
Service Rules and that the duration of the total period of vacation,
earned leave and commuted leave taken together shall not exceed
240 days.

[Circular No. 90/63/Fin.,
dt. 16-1 2-1963]

Government Decision No. 2

75.

Special casual leave may be combined with vacation, but
in such cases combination of special casual leave with ordinary
casual leave will not be permitted.

[G.O.(P) 216/76/Fin.,
dt. 24 -7-1976]

No leave shall be granted beyond the date on which an officer
must compulsorily retire:

[G.O. (P) 645/81/Fin.,
dt. 13-1 0-1981]

62

<!-- page 73 -->

CHAP.IX]

LEAVE

The provisos, the explanations and the Notes 1 to 7
omitted with effect from 13 th October 1981.
76.

Any leave granted under these rules may be retrospectively
commuted into any other kind of leave admissible to the officer at
the time the original leave was granted:
Provided that earned leave shall not be commuted into
leave of a different kind, *except as provided in the Note below
Rule 1, Appendix XII C .
*This amendment shall be deemed to have come into
th
force with effect from 12 April 1984.
SECTION III – G RANT OF LEAVE

77.

In these rules :(i)

‘Ordinary leave’ includes earned leave, half-pay leave,
commuted leave, leave not due and leave without
allowances.

(ii)

‘Special leave’ includes disability
maternity leave and hospital leave.

leave,

study

leave,

(iii) ‘Earned leave’ means leave earned in respect of periods
spent on duty.
(iv) ‘Half-pay lea ve’ means leave earned in respect of completed
years of service.
(v)

‘Earned leave due’ means the amount of privilege
leave/earned leave to the credit of an officer under the rules
previously in force on the day immediately preceding the date
on which these rules came into force plus the earned leave
calculated as prescribed in these rules diminished by the
amount of earned leave taken after the date on which these
rules came into force.

(vi) ‘Half-pay leave due’ means the amount of half-pay leave
calculated as prescribed in Rule 83 for the entire service
diminished by the amount of leave on private affairs and
leave on medical certificate taken before these rules came
into force and half-pay leave taken on or after the date:
Provided that in the case of officers who are given credit
for the half- pay leave admissible to them as on the date of coming
into force of these rules in accordance with the provision contained
in Rule 62 (2), the half-pay leave according to these rules will be
calculated only on the service rendered from the date on which
these rules come into force:
Provided also that where such leave on private affairs and
leave on medical certificate already availed of is in excess of the
period of half-pay leave due, reckoned under this rule as on the
date on which these rules come into force, such excess shall be
wiped off,
(vii)‘Commuted leave’ means leave taken under Rule 84.
(viii)‘Officer in permanent employ’ means an officer who holds
substantively a permanent post or who holds a lien on a
perman ent post or who would hold a lien on a permanent
post had the lien not been suspended.
(ix) ‘Completed years of service’ and ‘one year’s continuous
service’ mean continuous service of the specified duration
under the Government of Kerala and include periods spent
on duty as well as on leave including leave without
allowances.
63

[G.O.(P) 1002/97/Fin.,
dt. 6-11-1997]

<!-- page 74 -->

KERALA SERVICE RULES

[PART I

Ruling
The period of leave without allowances availed of under
Appendix XIIA for taking up employment will be excluded in
reckoning completed years of service for purposes of calculating
half-pay leave to be earned under Rule 83 Part I Kerala Service
Rules.

[G.O.(P) 1171/87/Fin.,
dt. 30-1 2-1987]

Government Decision No.1
Under Article 195, Travancore Service Regulations and
Article 130 (4) of the old leave Rules in the Cochin Service
Regulations, privilege leave on half salary can be granted in case
of urgent necessity to an officer serving in a vacation department
who enjoys the benefit of vacation. As the privilege leave is not
earned but only granted in cases of urgent necessity, neither credit
towards leave on this account need be made in the leave account
of the officer as on 1st November 1959 under Kerala Service Rules
for such leave already availed of prior to 1st November 1959
reduced from the half-pay leave admissible under Rule 77 (vi),
Kerala Service Rules.

[Fin, CR.17422/60,
dt. 30 -3-1960]

st

Furlough on average salary taken prior to 1 November
1959 is to be reduced from the half-pay leave by twice the amount
of such leave for purposes of Rule 77 (vi) Kerala Service Rules.
Government Decision No.2

78.

According to G.O.(MS) 101, dated 22nd January 1958 of
the Madras Government, the benefit of Rule 27 of the Madras
Leave Rules, 1933 to certain approved probationers stand
extended upto 31 st December 1962. In the case of those officers
allotted from Madras, governed by Madras Leave Rules and who
were eligible for the above concession and who have opted to be
governed by the Kerala Service Rules from 1st November 1959,
the accrued leave reckoned on the basis of the concession but not
availed of by them on 1st November 1959 will be treated as leave
standing to their credit for purposes of Rule 77 (v) Kerala Service
Rules.
The earned leave admissible to an officer in permanent employ is
one-eleventh of the period spent on duty, provided that he will
cease to earn such leave when the earned leave due amounts
*240 days.
*This amendment shall be deemed to have come into
force with effect from 1 st July 1986.

79.

[G.O.(MS) 477/60/Fin.,
dt. 11-1 0-1960]

[G.O.(P) 837/92/Fin.,
dt. 4-11-1992]

Subject to the Provisions of Rules 65 and 75 the maximum earned
leave that may be granted at a time to an officer shall be *180
days.
* This amendment shall be deemed to have come into
force with effect from 18 th May 1991.

[G.O.(P) 908/97/Fin.,
dt. 24-1 0-1997]

Exception.- In the case of an officer applying for leave preparatory
to retirement, the maximum earned leave that may be
granted at a time shall be *240 days.
*This amendment shall be deemed to have come into
st
force with effect from 1 July 1986.
80.

Earned leave is not admissible to an officer in permanent employ
serving in a vacation department in respect of duty performed in
any year in which he avails himself of the full vacation.
Ruling
Officers undergoing training in institutions which have
64

[G.O.(P) 837/92/Fin.,
dt. 4-11-1992]

<!-- page 75 -->

CHAP.IX]

LEAVE

regular vacations and who enjoy vacations of those institutions,
will be treated as officers serving in a vacation department for the
purpose of Rule 80 Par t I, Kerala Service Rules.
81.

The earned leave admissible to an officer in permanent employ
serving in a vacation department, in respect of any year in which
he is prevented from availing himself of the full vacation, is such
proportion of 30 days as the number of days of vacation not taken
bears to the full vacation.
If in any year the officer does not avail himself of the
vacation, earned leave will be admissible to him in respect of that
year in accordance with the provisions of Rules 78 and 79 above .
Note 1. - A vacation department is a department or part of a department to which
regular vacations are allowed during which the officers serving in the
department are permitted to be absent from duty.
Note 2.-The Principal, the Superintendent, the entire office staff, sergeant (if any)
and the gardeners of the following institutions will be treated as nonvacation officers with effect from the dates specified against each:
1.

Government Arts Colleges

: 1.11.1959

2.

Law Colleges, Training Coll eges and

3.

Physical Education Colleges
Engineering Colleges and Polytechnics

4.

Junior Technical Schools

:

8.3.1960
: 13.6.1960
: 18.5.1963

The Teaching staff in the Hindi Teachers’ Training Institutes at
Trivandrum and Trichur will be treated as non-vacation officers with effect
from 4th June 1970.

[G.O.(P) 205/72/Fin.,
dt. 16 -6-1972]

The headmasters of schools and non-teaching staff of the schools
under the Director of Public Instruction will be treated as non-vacation
officers with effect from the date noted against each:-

[G.O. (P) 39/73/Fin.,
dt. 5 -2-1973]

Headmasters of schools

:

9.6.1969

Non teaching staff

:

22.4.1960

Exception.- The Superintendents of the Junior Technical Schools
attached to the Polytechnics at Kannur, Calicut and
Trichur will be treated as vacation officers.

G.O.(P) 78/70/Fin.,
dt. 29 -1-1970.

This amendment shall be deemed to have come into force
st
with effect from 1 April 1967.
The Senior Agricultural Officer/Veterinary Surgeon and
Attenders in High Schools where Vocational Higher Secondary
Courses were introduced, will be treated as non-vacation officers
with effect from 13th August 1984.
The Assistant Director of Fisheries and Attenders in the
High Schools where Fisheries have been introduced as vocational
subject, will be treated as non-vacation officers with effect from
th
28 May 1986.
Note 3. -The term “Year” should be interpreted to mean, not a calendar year in
which duty is performed, but twelve months of actual duty in a vacation
department.
Note 4. - When an officer is transferred from a vacation department to a nonvacation department, his period of service in the former will, for the
purpose of calculation of leave, be considered to have terminated with
effect from the close of the last vacation enjoyed by him.* [But if the
transfer is effected during the course of vacation, he will be deemed to
have been transferred to the non-vacation department on the close of the
vacation which he has partly enjoyed and he will be credited with
65

[G.O. (P) 95/89/Fin.,
dt. 24 -2-1989]

[G.O. (P) 95/89/Fin.,
dt. 24 -2-1989]

<!-- page 76 -->

KERALA SERVICE RULES

[PART I

proportionate amount of earned leave under this rule for the period of
vacation which he was prevented from enjoying on account of such
transfer]. When an officer is transferred from a non-vacation to a
vacation department, his period of service in the latter will be held to
have commenced from the date of expiry of the last vacation previous to
such transfer.
* This amendment shall be deemed to have come into force with
th
effect from 6 August 1982.

[G.O.(P) 409/82/Fin.,
dt. 6 -8-1982]

Government Decision
The above Note shall apply to appointments of
Government Officers in a vacation Department through the Public
Service Commission while working in non-vacation Department in
the course of the academic year and vice versa.

[G.O.(P) 573/81/Fin.,
dt. 2 -9-1981]

Note 5. - The Library staff of Arts and Science, Training and Law Colleges shall
be treated as non-vacation staff.

[G.O.(P) 553/75/Fin.,
dt. 11-1 2-1975]

This amendment shall be deemed to have come into force with
effect from 7th November 1974.
Note 6. - The Heads of Nursery Schools shall be treated as non-vacation staff.
This amendment shall be deemed to have come into force with
effect from 11th February 1976.

[G.O.(P) 230/76/Fin.,
dt. 3 -8-1976]

Note 7. - In the case of an officer of non-vacation department sent on deputation
for training to an institution having regular vacation, his eligibility for
earned leave shall be decided as follows:(i)

if the officer is not permitted to enjoy the vacation and is retained by
the institution for duty, and if the head of the institution so certifies,
the officer shall be considered as on duty during that period and
earned leave for that period shall be admissible to him in accordance
with the provisions of Rules 78 and 79.

(ii) if the officer enjoys only part of the vacation, deduction of earned leave will
be in such proportion of 30 days as the number of days of vacation
enjoyed bears to the full vacation.

[G.O.(P) 887/80/Fin.,
dt. 21-1 1-1980]

Effective from 1st July 1975.
Ruling No. 1
An officer serving in a vacation department when put in full
additional charge of the duties of a post in a non-vacation
department shall be considered to have been denied the benefit of
vacation if that charge arrangement falls within a vacation period.

[G.O. (P) 366/70/Fin.,
dt. 27 -5-1970]

Ruling No. 2
Teachers deputed for training under the Summer School
Training Programme during vacation shall be considered to have
been prevented from availing themselves of the vacation provided
such period of training has been treated as duty under Rule 12 (7).

[G.O. (P) 366/70/Fin.,
dt. 27 -5-1970]

Ruling No. 3
Teaching staff who are N.C.C. Officers in Colleges,
Polytechnics and Schools, when detailed to undergo training or
refresher course or for duty in connection with the conduct of
N.C.C. training or refresher course, during periods of vacation, will
be treated as on duty and allowed the benefit of earned leave
under the above rule.
The ruling shall be deemed to have come into force from
th
15 February 1972.

66

[G.O.(P) 364/72/Fin.,
dt. 16 -8-1972]

<!-- page 77 -->

CHAP.IX]

LEAVE

Ruling No.4
Teaching Staff attending the work of Valuation and
Tabulation of S.S.L.C. and Higher Secondary Public Examination
during vacation shall be considered to have been prevented from
availing themselves of the vacation and such period will be treated
as duty and allowed the benefit of earned leave under the rule.

[G.O.(P) 3113/98/Fin.
dt.15-12-1998]

82.

Half-pay leave.- Half-pay leave as provided in Rule 83 may be
availed of on private affairs or on medical certificate.

83.

The half-pay leave admissible to an officer in permanent employ in
respect of each completed year of service is 20 days.

84.

Commuted Leave.- Commuted leave not exceeding half the
amount of half-pay leave due may be granted to an officer in
permanent employ. When Commuted Leave is granted twice the
amount of such leave shall be debited against the half-pay leave
due.

[G.O. (P) 540/87/Fin.,
dt. 20 -6-1987]

Ruling No. 1

[G.O. (P) 685/87/Fin.,
dt. 19 -8-1987]

[Deleted]
Ruling No. 2

[G.O. (P) 685/87/Fin.,
dt. 19 -8-1987]

[Deleted]
85.

Leave not due.- Save in the case of leave preparatory to
retiremen t leave not due may be granted to an officer in
permanent employ for a period not exceeding 360 days during his
entire service out of which not more than 90 days at a time and
180 days in all may be otherwise than on medical certificate. This
will be debited against half-pay leave which the officer earns
subsequently. Leave not due should be granted *[only when no
other leave with allowance is available at credit of the officer and if
the authority empowered to sanction leave] is satisfied that there is
a reasonable prospect of the officer returning to duty on the expiry
of the leave and earning an equal amount of half pay leave
thereafter.

*[G.O.(P) 409/77/Fin.,
dt. 24-1 0-1977]

Note 1. - Where a Government servant who has been granted leave not due
under this rule, applies for permission to retire voluntarily, the leave not
due shall, if the permission is granted, be cancelled.
Note 2. - Except as provided in Note 1, leave not due when granted should in all
cases (subject to the officer’s wishes) be allowed to stand, including
cases in which the officer fails to earn it by subsequent duty.
Government Decision
A question has been raised whether in cases where the
officers whose credit in half-pay leave account results in a minus
balance on 1st November 1959 can be granted a further period of
360 days leave not due under Rule 85, Part I, Kerala Service
Rules.
This has been examined by Government and they
consider that in view of the second proviso to the amendment to
clause (vi) of Rule 77, Part I, issued in
G.O.(P) 261/Fin.,
dated 23r d May 1960, the half-pay leave availed of prior to 1st
November 1959 in excess of the half-pay leave reckoned under
Kerala Service Rules has been wiped off. Therefore such officers
should be treated as leaving a nil balance of half-pay leave on 1st
November 1959 and they should get the same consideration in
regard to the grant of leave not due as in the case of those who
had not enjoyed half-pay leave in excess of what is admissible
under Kerala Service Rules. The Government accordingly direct
that officers whose credit on half-pay leave account results in a
67

[G.O.(Ms) 524/60/Fin.,
dt. 7-11-1960]

<!-- page 78 -->

KERALA SERVICE RULES

[PART I

st

‘nil’ balance on 1 November 1959 consequent on the wiping off of
the excess half-pay leave already available shall be eligible for a
further period of 360 days, leave not due under Rule 85, Part I,
Kerala Service Rules, provided they otherwise satisfy the
requirements of the rules.
86.

The provisions of Rules 78, 80, 81, and 83, apply also to an officer
not in permanent employ except that in respect of the first year of
service the earned leave admissible is 1/22 of the period spent on
duty:
Provided that no earned leave shall be admissible to such
an officer in a vacation department in respect of the first year of his
service.
Note1.-The leave of an officer appointed as a probationer (for a certain period
before confirmation of his appointment) will be regulated under the rules
prescribed for permanent officers. If for any reason it is proposed to
terminate the services of a probationer any leave which may be granted
to him shall not extend beyond the date on which the probationary period
as already sanctioned or extended expires, or any earlier date on which
his services are terminated by the orders of the authority competent to
appoint him.
Note 2. -Whenever the rate of earning leave changes, the fraction in the earned
leave accumulated at the earlier rate should be rounded off to the
nearest day i.e., fraction below half should be ignored and that of half
and more should be reckoned as a day. *Similarly, the fraction, if any, in
the leave earned in accordance with the provisions of the first paragraph
of Rule 81 by an officer serving in a vacation department should also be
rounded off to the nearest day.

*[G.O.(P) 230/67/Fin.,
dt. 20 -6-1967]

Ruling
When a full -time teacher is appointed to a part-time post,
the leave earned by him prior to becoming part-time cannot be
granted to him while holding the part-time post. Such leave may,
however, be granted when he is reappointed to a full-time post.
86A.

Notwithstanding anything contained in Rules 84, 88 (ii) and 90, an
officer not in permanent employ who has completed three years of
continuous service shall be eligible for (i) commuted leave and (ii)
leave without allowances as would be admissible to him if he had
held his post substantively.

87.

An officer not in permanent employ appointed without interruption
of duty substantively to a permanent post will be credited with the
earned leave which would have been admissible if his previous
duty had been duty as an officer in permanent employ diminished
by any earned leave already taken. Leave is not an interruption of
duty for the purpose of this rule.

88.

Leave without allowances.- (i) Leave without allowances may be
granted to any officer in special circumstances(a) when no other leave is by rule admissible, or
(b) when other leave is admissible, but the officer concerned
applies in writing for the grant of leave without allowances.
(ii)

Except in the case of an officer in permanent employ, the
duration of leave without allowances shall not exceed
3 months on any one occasion.

Exception 1.-When a period of suspension is retrospectively
treated as leave without allowances by the revising or
appellate authority the limitation of admissible leave
without allowances to three months to officers not in
68

[G.O.(P) 275/65/Fin.,
dt. 5 -7-1965]

<!-- page 79 -->

CHAP.IX]

LEAVE

permanent employ will not apply.
Exception 2.-The limitation in sub-rule (ii) shall not apply to the
grant of leave without allowances regulated by the
rules in *Appendices XIIA, XIIB and XIIC.

[G.O.(P) 654/95/Fin.,
dt.10-10-1995]
[G.O.(P) 953/86/Fin.,
dt. 27-1 2-1986]
*[G.O.(P) 1002/97/Fin.,
dt. 6-11-1997]

Section IV- Commutation Of Leave With
Retrospective Effect

89.

(i)

The authority which granted leave to an officer can commute it
retrospectively into leave of a different kind which may be
admissible but the officer concerned cannot claim it as a matter of
right:
*Provided that earned leave shall not be commuted into
leave of a different kind †except as provided in the Note below
Rule 1, Appendix XIIC .
*Effective from 22nd November 1971.
†This shall be deemed to have come into force with effect
th
from 12 April 1984.

(ii)

Commutation of one kind of leave into another automatically
carries with it the drawal of arrears of leave salary or recovery of
amounts overdrawn.

(iii)

Commutation of leave with out allowances taken during temporary
service when no other leave was due, into earned leave on
confirmation without interruption of service, by giving retrospective
effect to the benefit of Rule 87 would be irregular and not in
accordance with the intenti on of Government. The real intention of
Rule 87 is to provide only for a retrospective recalculation of leave
at credit on the date of confirmation with a reduction on account of
the earned leave already taken. Except for the carry-forward of the
recalculated credit on confirmation, leave earned and taken should
be a closed chapter at that point and no readjustment of any leave
taken is automatically permissible as a consequence of such
recalculation. The closed chapter may however properly be reopened, for instance, to correct a miscalculation of leave earned or
taken or to readjust leave earned and taken when confirmation is
ordered with retrospective effect or at the discretion of the
sanctioning authority to convert leave of any one kind already
taken into leave due of any other kind admissible at the time leave
was originally taken.
Government Decision
When confirmation is given retrospectively with effect from
a date earlier than the date on which leave was already
sanctioned, such leave can be commuted and readjusted as
provided in Rule 89 (iii). Such cases do not come within the
purview of the ruling under Rule 11. What has changed is only the
status of the officer and not the rule in force at the time the leave
was sanctioned. The position will be clear from the following
illustration:Illustration
Entry in service of an officer- 1st November 1960.
69

†[G.O.(P)1002/97/Fin.,
dt. 6-11 -1997]

<!-- page 80 -->

KERALA SERVICE RULES

[PART I

Date of his confirmation - 1st November 1961 (orders issued
on 1 November 1962).
st

90.

Leave without allowances taken at any time during the
st
st
period from 1 November 1960 to 31 October 1961 cannot be
retrospectively commuted into any other kind of leave. But leave
st
earned and taken after 1 November 1961 can be retrospectively
commuted.

[G.O. (P) 204/66/Fin.,
dt. 17 -5 -1966]

In addition to any leave which may be admissible to him, an officer
in temporary employ, who contracts tuberculosis and undergoes
treatment in a recognised sanatorium or under a qualified T.B
Specialist or a Civil Surgeon or who is suffering from leprosy and
undergoes treatment in a recognised Leprosy institution or under a
Civil Surgeon or a Specialist in Leprosy, recognised as such *or
who is suffering from cancer and undergoes treatment in a
recognised Cancer Institute or under a Civil Surgeon or a Specialist
in cancer or who is suffering from mental disease and undergoes
treatment in a recognised Mental Hospital or under a Civil Surgeon
or a Specialist in mental disease may be granted leave without pay
upto a maximum period of 18 months [including 3 months leave
without allowances authorised under Rule 88 (ii) above] on any one
occasion subject to the following conditions:-

*[G.O. (P) 570/78/Fin.,
dt. 11 -7 -1978]

(i)

the officer is likely to continue in service till his return to duty;

(ii)

the leave without all owances shall be granted subject to the
production of a certificate from the Medical Officer-in -charge of
the Sanatorium or qualified T.B. Specialist or a Civil Surgeon *
or a Specialist in Leprosy, Cancer or Mental disease as the
case may be specifying the period for which leave is
recommended; and

(iii) the medical officer in recommending leave shall bear in mind
the provisions of Rule 115.
90A.

(a)

A Government officer, whether gazetted or non gazetted, drawing a
basic pay not exceeding †Rs.2500 per mensem who is granted
leave without allowances for the treatment of T.B., *Leprosy,
Cancer or Mental disease may be granted an ex-gratia allowance
equal to 35 per cent of the basic pay he was drawing immediately
before the commencement of the leave, subject to a maximum of
†Rs.875 and minimum of †Rs.580 per mensem. **In respect of
cases relating to treatment of cancer and mental diseases, the Rule
th
shall be deemed to have come into force with effect from 11 July
st
1978 and in respect of other cases, with effect form 1 July 1978.

*[G.O.(P) 570/78/Fin.,
dt. 11 -7-1978]

**This amendment shall be deemed to have come into
force with effect from 1st July 1978.

[G.O.(P) 373/83/Fin.,
dt. 7-7-1983]

†This shall be deemed to have come into force with effect
st
from 1 March 1992.

[G.O.(P)149/96/Fin.,
dt. 30 -1-1996]

(b)

The allowance will be admissible only when the officer is not
eligible for any other leave with allowances.

(c)

The allowance will be granted irrespective of whether the patient
undergoes treatment as an inpatient or as an outpatient under the
direction of a Civil Surgeon.

(d)

The payment of the allowance will be made only on the production
of a certificate issued by the Medical Officer-in -charge of the
Sanatorium/Hospital or by one not below the rank of a Civil
Surgeon to the effect that the patient has been under his treatment
for T.B., *Leprosy, Cancer or Mental disease during the period for
which the allowance is claimed.
70

*[G.O.(P) 570/78/Fin.,
dt. 11 -7 -1978]
