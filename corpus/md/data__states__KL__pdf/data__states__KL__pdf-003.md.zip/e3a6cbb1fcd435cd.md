---
doc_id: "e3a6cbb1fcd435cd"
source_url: "https://ceconline.edu/wpdata/tender/alumniserver.pdf"
ministry: "College of Engineering Chengannur, Kerala"
title: "Purchase of Supply & Installation of Rack Server"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2b3522a680e57cac"
---

<!-- page 1 -->

COLLEGE OF ENGINEERING, CHENGANNUR, KERALA – 689 121.

(Managed by IHRD, A Govt. of Kerala undertaking)

Fax
No. Alumni/01/22

Phone : 0479 –
2451424, 2454125
: 0479 – 2451424
Dated: 28.02.22

SHORT TENDER NOTICE
Tender No. 01/2021-22, Supply & Installation of Rack Server
Last date and time for receipt of

:

17.03.22, 1.00 pm

of

:

17.03.22, 3.00 pm

Date upto which the rates are to be

:

18.04.22

Price of tender form

:

Rs. 1,200/- + ST Rs. 216/-

Price of Duplicate copy

:

Rs. 600/- + ST Rs. 108/-

Address of Purchasing Officer from
whom tender forms are to be
obtained and to whom tenders are
to be sent

:

The Principal
College of Engineering,
Chengannur
Kerala 689 121

EMD

:

1% of amount quoted

tender
Date

and

time

for

opening

tender
firm

Tender documents can be had from the Principal on payment of the
prescribed cost at the counter in cash or by post (postage extra Rs.
35/- for one tender form) sending a DD for the amount payable at
Chengannur in favour of the Principal, College of Engineering,
Chengannur - 689 121. Details will be available in College website:
http://www.ceconline.edu

PRINCIPAL

<!-- page 2 -->

Tender No. 01/2021-22, Supply & Installation of Rack Server
SI
No
1

Item

Description

Qty

Supply and
installation of 2U
- 2P Rack Server

Intel Xeon Silver 4210R 2.4G,
10C/20T, 9.6GT/s, 13.75M Cache,
Turbo, HT (100W) DDR4-2400 16
DIMMS 2 x 16GB RDIMM Up to 8,
3.5" Hot Plug Hard Drives 1.2TB 10K
RPM SAS 12Gbps 512n 2.5in Hotplug Hard Drive PERC H750 Adapter,
Low Profile, 8GB Cache Dual, Hotplug, RPS, 750W(1+1)
iDRAC9, ,Enterprise, RAID 1, Nvidia
Quadro T1000 4GB GDDR6 GPU ,
Warranty :- 5 years comprehensive
onsite , OS: latest Ubuntu server LTS

1 No.

1.2TB 10K RPM SAS 12 Gbps 512n
2.5 in Hot-plug Hard Drive, 3.5 in
HYB CARR, CK

1 No.

1. Rate: Should be inclusive of all taxes and duties.
2. Delivery should be made at site College of Engineering, Chengannur
3. Warranty :- 5 years with after sales support
4. Payment : 100% after successful testing
5. Security Deposit : 5% of the contract amount

PRINCIPAL
