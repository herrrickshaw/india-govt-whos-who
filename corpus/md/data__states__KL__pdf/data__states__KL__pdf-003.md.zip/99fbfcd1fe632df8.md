---
doc_id: "99fbfcd1fe632df8"
source_url: "https://www.cusat.ac.in/uploads/nodal_officer.pdf"
ministry: "Cochin University of Science and Technology, Kerala"
title: "Nodal Officer - University Order"
date: ""
pages: 1
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "f033a62223a10924"
---

<!-- page 1 -->

COCHIN UNIVERSITY OF SCIENCE AND TECHNOLOGY
(Abstract)
Establishment - Kerala State Right to Services Act, 2012 - Deputy Registrar,
UGC (S) Cell for SC/ST - Nominated as the Nodal Officer - Sanctioned -
Orders issued.

ADMINISTRATION ‘A’ SECTION
No.Ad.A1/KSRTS-2012/2013 Dated, Kochi - 22, 10.04.2015
Read: ൮.0. of even No. dated 25.02.2015.

ORDER

The University, vide paper read above has implemented the Kerala
State Right to Services Act, 2012 in the University and has brought
34 services offered by the University under the purview of the Act.

As per the directions received from the Government at the one day
Workshop to review the progress on implementation of the Kerala State Right
to Services Act, 2012 held on 12.06.2014 at the Institute of Management in
Government, Thiruvananthapuram, monthly reports are to be furnished to the
Personnel and Administrative Reforms Department, Government of Kerala,
before 5 working day of each month.

In light of the above, orders are issued nominating the Deputy
Registrar, UGC(S) Cell for SC/ST as the Nodal Officer for the Kerala State
Right to Services Act, 2012. The Deputy Registrar, UGC (S) Cell for SC/ST
shall be responsible for collecting and consolidating the reports on the services
provided under the Kerala State Right to Services Act, 2012 from various
Departments/Sections of the University on a monthly basis and to furnish the
same to the Personnel and Administrative Reforms Department, Government
of Kerala before the 5" working day of each month, in compliance with the
Government directions in this regard, in the format to be received from the
Government.

Orders are issued accordingly.

Sd/-
RAMLA P.A
DEPUTY REGISTRAR (ADMN.II)
