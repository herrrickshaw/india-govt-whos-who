---
doc_id: "9b7cbc5e81fbdbf5"
source_url: "https://sdma.kerala.gov.in/wp-content/uploads/2025/12/GO140Laptop.pdf"
ministry: "Kerala State Disaster Management Authority, Kerala"
title: "GO (Rt) No. 140/2025/DMD"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "df2fbb5a79f03405"
---

<!-- page 1 -->

DMA2/18/2025-DMD

G.O.(Rt)No.140/2025/DMD

GOVERNMENT OF KERALA
Abstract
Disaster Management Department- Procurement of 250 Laptops for the
School Children affected by the landslide at Meppadi Panchayath on
30-07-2024– Administrative Sanction Accorded – Orders Issued.
DISASTER MANAGEMNET (A) DEPARTMENT
G.O.(Rt)No.140/2025/DMD Dated,Thiruvananthapuram, 18-03-2025
Read 1 Letter No.DCWYD/5692/2024-DM4, dated 08/10/2024 &
20/12/2024 from District Collector, Wayanad
2 Letter No.MTO VII/2094/2024/Admin dated 04/01/2025
from Member Secretary, KSDMA
3 Minutes of the State Executive Meeting of KSDMA held
on 31/01/2025
Letter No.MTO VII/2094/2024/Admin dated 24/02/2025
4
from Member Secretary, KSDMA
ORDER
As per the letter read as 1st paper above, District Collector, Wayanad
requested for 250 laptops to distribute to school children who have been
affected by the landslide occurred on 30-7-2024 at Meppadi Panchayath
in Wayanad district.
2) As per the letter read as 2nd paper above, Member Secretary,
KSDMA reported that Communication Engineer of KSDMA had
evaluated various configurations of laptops considering their use and
longevity and requested M/S Keltron to submit suitable models for the
use of school children with onsite 3 year warranty for the laptop, battery
and adapter. Accordingly, M/S Keltron submitted a proforma invoice
containing the costing of two models of laptops.
The makes, models and the costs proposed by M/S Keltron was
evaluated by DDMA Wayanad and recommended the make and
model:Dell VOSTRO 3250 + onsite 3 year warranty for the laptop,
battery and adapter. The cost of one laptop is Rs. 42,810/- and the total

<!-- page 2 -->

DMA2/18/2025-DMD

G.O.(Rt)No.140/2025/DMD

cost for 250 units will be Rs. 1,07,02,500/-(inclusive of GST).
3) The State Executive Committee of KSDMA held on 31/01/2025
considered the matter and in principal approval was given for meeting
the expenditure for the procurement of laptop from the CSR fund of
KSDMA. The SEC has also directed to examine the offer of HCL and
ITC for procuring Chrome book or laptop before effecting the
procurement and submit the revised proposal to the Disaster
Management Department.
4) As per letter read as 4 th above Member Secretary has informed that
the proposed specifications are not available in CPCRS and has
requested to accord sanction to purchase laptops of make and model
"Dell VOSTRO 3250" for a total cost of Rs. 1,07,02,500/-.
4) Government have examined the matter in details and are pleased
to accord sanction for the procurement of 250 laptops of make and
model "Dell VOSTRO 3250" with an onsite 3-year warranty for the
laptop, battery, and adapter through M/S Keltron, for a total cost of Rs.
1,07,02,500/- by utilizing funds from the State Disaster Mitigation
Fund (SDMF-CSR Contribution). The final price shall be negotiated
and fixed with M/s Keltron by KSDMA, before placing purchase order.
(By order of the Governor)
ANURADHA K C
ADDITIONAL SECRETARY
To:
The Commissioner, Land Revenue, Thiruvananthapuram.
The Commissioner, Disaster Management.
The Member Secretary,KSDMA
The District Collector, Wayanad
M/s Keltron, Keltron House, Vellayambalam, Thiruvananthapuram.
General Education Department
The Accountant General(Audit)(A&E) Kerala, Thiruvananthapuram.
The Information Officer, Web & New Media, I&PRD.
Stock File/Office Copy.
Forwarded /By order

<!-- page 3 -->

DMA2/18/2025-DMD

G.O.(Rt)No.140/2025/DMD

Section Officer
