---
doc_id: "ccec8a98fed7ef37"
source_url: "https://keralacseb.kerala.gov.in/wp-content/uploads/2025/05/Notification-4_2018-Data-Entry-Operator-2003_19-Exam-Date-27-04-2019_compressed.pdf"
ministry: "Kerala Co-operative Services Examination Board, Thiruvananthapuram, Kerala"
title: "Notification 4_2018 – Data Entry Operator – 2003_19 (Exam Date 27-04-2019)"
date: ""
pages: 14
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "24f5d17a328be6a9"
---

<!-- page 1 -->

॥॥॥॥॥॥
Code.No. 2003/1 9
Question Booklet
Alpha Code
Total No, of Questions : 160
Time : 2 Hours
Each question carries half mark < Marks ; 80 (16൩൭)
1. Delhi is situated on the banks of the river,
A) Brahmaputra B) Yamuna
C) Godavari D)..None of these
2. The Governor General who abolished the practice of Sati was
A) Dalhousie B)..Lord Curzon,
C) William Bentinck va, 4D) None of these .
3. India borrowed concurrent list from which country ? ee
൧) Australia B). USA. : .
C) Russia ; -*.D)-None ofthese റ
4. Who was the first President of Travancore Devaswam Board 2
A) Chatiamdi Swamikal രു) “Sree Narayana Guru
C).Mannathy Padmanabhan a ൬) -None.of these
5. Grey Revolution in India is related to° [ : :
A) Fruit B) Leather |
C) Fertilizer D) Oilseeds !
6. The first planned and organised agitation for denied rights in the history-of Kerala i
A} Malabar Rebellion B) Vaikkom Satyagraha |
C) Bardoli Satyagraha D) Guruvayoor Satyagraha . i
7. Albert Einstein received Nobel Prize in 1921 to which subject? :
A) Physics ; 8) Literature ഴു
C) Medicine D) None of these :
a @
8. Hydrophobia or fear of water is related with which disease ? :
A) Leprosy B) Rabies : :
C) Tuberculosis : D) None of these i
9. Aco-operative leader has to be a :
A) Autocrate B} Democrate i
C) Politician D) None of these a
16. The vitamin which is not present in any vegetables ര
A} Vitamin B B) Vitamin D C) Vitamin C D) None of these :

<!-- page 2 -->

മ്‌ ॥॥॥॥॥
13. Which temple in Ocisha is known as “White pagoda” ? vA Des [
A) Jagannath Temple B) Padmanabha Temple
C) Madhura Meenakshi Temple D) None of these
12. The Agricuttural Loan Act of 1884 and Land improvement Loans Act of 1885 are together called
A) Co-operative Laws 8) Civil Laws :
G) . Taecavi Laws D) Consumer Laws
13. The firsl Co-operalive Deposil Mobilization Campaign in Kerala was launched in the year
A) 1974 B) 1975 C) 1976 D) 1977
14. Linking of credit with marketing is recommended by Committee.
A) Gorwala B) Karve റ) Khusroo 2) None of these
15. Which insect recognises sweetness through legs 2 ന
A) Spider B) -Housefly
റ) Grasshopper 2) “Louse .
16. Indira Sagar Dam is built across the river : ന
A) Krishna ൫ Brahmaputra
©) Narmada ൬) .Mahanadi ഴ്‌
17. [൧ Brand is the trade name of milk and allied product of i
. A) Italy 8) Denmark )
C) Germany D) -None of these :
18. Which place is called as “The Religious Capital of india” ? : i
A) Madhura പു Varanasi i
C) Kasi D), Rameswaram : |
19. in Roman numeration, സ്‌ indicates | i
A) 500 B) 100 C) 1000 2) None of these :
20. In which State is Dona Paula Port situated ? : |
A) West Bengal B) Tamil Nadu i
C) Goa D) None of these i
21. First Co-operative Minister of Kerala os ; :
൧) GC. Achutha Menon B) Prof. Joseph Mundassery _ A
C) 5.0. ട. Namboothiripad D) 6. R. Kurup 7
22. World Ozone Day is observed on ലം :
A) September 16 B) November 16 :
i
റ May 16 D) None of these ടഃ
23. Which disease is known as “Black death”:?. . : . :
A) Cholera B) Leprosy C) Anthrax D) Plague :
A 4 : ഷ്യ |

<!-- page 3 -->

SMU
ലം Which wood is used for making Veena and Thamburu ?
A) Jack tree wood B) Teak wood ‘
C) Rubber wood D) None of these
25. Where is the Rajiv Gandhi Centre of Biotechnology situated ? ന
A) Ermakuiam B) Alappuzha
C) Thiruvananthapuram D) Kollam
26. COBANK Towers is situated at ന
A) Thiruvananthapuram B) Kollam
C) Idukki D) Alappuzha
27. Which mountain ranges of India run parallel to the Bay of Bengal ? . a
A) Vindhya B) Satpura
C) Western Ghat D) Eastern Ghats i
28. Numismatics is the study of i
A) Numbers B) Stones. C) Coins 2. D) None ofthese i
29, Who.was the author of “Poverty and un-British.rule in India’? 5 ॥ :
ഗു Re Sankar പ) -Dadabhai Naoroji 5 i
C). Lala Lajpat Rai : ൭) None of these :
30. ; NCDC.was-set up in the year 1963 with headquarter at 4 : |
A) Mumbai ന ന > 8) Chennai 2 )
C) New Delhi ; 2) Pune : :
31. NDDB Act was passed in the year ര ം
A) 1980 : 8). 1987 Cc) 1985 D) 1990 [ ;
32. Who was the first Chairman of-the Planning Commission of India 7 [
A) Jayaprakash Narayan B) Or. Ambedkar : :
൮ Jawaharlal Nehru D) Mahatma Gandhi ലെ
33. Which Indian State is known as “The land of festivais” ? ലം
A) Mizoram B) Manipur ൮ Nagaland D) Goa .
34. The first bird sanctuary in Kerala is
A) Wayanad B) Thattekkad
C) Thenmala D) None of these £
35. What is the colour of the aircralt’s “Black box”.? L
A) Black B) Orange C) Red D) White... | c
36. Name the atmospheric layer where Ozone layer occurs. .
A) Thermosphere 8) Exosphere .
C) Stratosphere D) Mesosphere : .
A 5 NT jo 200319

<!-- page 4 -->

800
37. Which is the first indian Communication Satellite ? | ee
A) HAMSAT B) APPLE ൮ EDUSAT D) GSAT
38. Who has been appointed as the new Chairman of Railway Board 7
A) VK. Yadav B) A. K. Prasad on
൮ Sunil Kumar. D) Arun Kumar
39. Global Aviation Summit, 2019 will be heldin_ = swith the theme “Flying forall’,
A) New Delhi : B) Mumbai :
൮ Pune D) Chennai
40. NASA was the space agency of
A) America : B) France
C) Britain D) None of these
41, Which will be the host country of G 20 Annual Summitiin 2022 2 [
A) Brazil B) italy C) Canada D) india :
42, Who won the Gandhi Peace Prize of the year 2018 ? ൪ ന
൧) Yohei Sasakawa va : B) Ekal Abhiyan Trust :
C) Vivekananda Kendra : D) Desmond Tutu i
43. Who is the first Law Minister of independent india? : : j
A) Jawaharlal Nehru : ൭) Dr: BOR. Ambedkar ; : )
൭ Dr. 3. Radhakrishnan D) None of these j
44. Where is ISRO headquarters located ? :
4) Bengaluru B) New Delhi |
C) Chennai D) None ofthese : :
45. Which is the Green coloured planet in the solar system .? . ;
A) Uranus B) Venus i
C) Mercury പ) -None‘of these . : i
46. Which Indian city is aiso known as the city of Prime Ministers 7 :
A) Paina “ B) Pune : a
C) Allahabad D) New Delhi : |
47. In which State is “Silent Valley” situated 7 |
A) Gujarat | B) Kamataka : _ 5 2
C) Uttar Pradesh റ 2). Kerala . :
48. Which is the acid present in Tea ? . ; |
A) Tannic acid B) Latic acid :
9 Citric acia : ൩) Malic. acid 5
Ross ന 6 20309 |

<!-- page 5 -->

॥॥॥
49, Who is known as “indian Bismark’ ? ന
A) Balagangadhar Tilak 8) Sardar Vallabhbhai Patel
C) N. Gopalaswamy 2) None of these
50, Who is appointed as the new Chief Election Commissioner of India ? .
A) Sunil Arora ഒ) V. R. Krishna lyer
C) സ. Seshan ഇ) M.S. K. Ramaswami .
51, industrial Co-operatives in Kerala are mostly follow... system.
A) Stier. B) 2 tier റ) Atier , D) None of these
52. The famous “Gayathri Mantra” is from
A) Yajurveda 8) Samaveda
C) Rigveda D) Atharvaveda :
53. . Red Fort of Delhi was built by
A) Akbar . 2 B)-Babur .
റു Shah Jahan D) None of these
54. The Vice-Chancollors ofthe Universities in a State.are. appointed by : ര
A) Prime Minister B) ‘Governor — ന
| C) Chief Minister 0) None of these
55. Which Articla of Indian Constitution prohibit employment of children in factories, mines etc. 7 .
A) Article 20 | 8) Article 24.
C) Article 21 D) None of these !
56. Part XV of the Indian Constitution deals.with ‘ |
A) Election ഇ) Finance Commission |
C) Planning Commission D) ‘None of these :
57. 97" Constitutional Amendment relates to. :
A) Co-operative Societies B) Fundamental Duties ന i
C) Official Languages D) None of these :
58. Who is called the father of Loca! Self Government in India ? :
A) Lord Curzon B) Lord Lytton .
C)..Lord Ripon : : D) None of these | ല്‍
59. National Girl Child Day is celebrated in India on ല്‍
A}. a January 00: നം 83) 25" January
പസ 5 Bane BOS 2) 23".January :
60. Which is known as “Solar City":? .
A) Amritsar ; ses ; B) Allahabad ; | a
CG) “New Delhi Bos See B) None of these. - | .
A en “7 . 200318

<!-- page 6 -->

ന ॥॥॥॥॥॥
61. Where are you likely find an embedded Operating system ? : ന
A) On a desktop operating system 8) On a networked PG
C) Ona network server >: 5 D) Ona PDA
62. What displays the contents of the active cell in MS Excel ? ;
A) Namebes a B) Row Headings 0) Formula bar D) Task pane
63. In MS Excel, allows users to bring together copies of workbook that other users
have worked on independently.
A) Copying B) Merging ൭) Pasting... D} Compiling...
64. In PowerPoint, the Header and Footer button can be found on the Insert tab in what group ?
A) illustrations group 8) Object group C) Text group. . ൧) Tables group
65. A typical slide in a slide presentation of PowerPoint would not include
A) Photo images, charts and graphs 8) -Clip art and audio clips
൭) Full motion video D) Content templates
66. Which PowerPoint view displays each -slide-of the presentation as a thumbnail and is/useful'for
rearranging slides ? Pe eo
A) Slide sorter B) Slide show C) Slide master 2) Slide design
&7. To tind Paste Special option, you use the Clipboard group on the erence tab of. ന
PowerPoint, an | :
ശു Design B) -Slide.show ©). Insert D) -Horne i
68. Which.of the following can be used to. Select the entire document in MS Word ? : :
A) Ctrl eH ചി 2) 022 VES :
69. The keyboard shortcut for:hiding ‘entire rows in MS Excel is :
A) Ctrl+4 : B) ബം. C). മേഡ . D) 7-9 '
70. The OOPs concept in കേ, exposing only necessary information.to users or-clients is known-as :
A) Abstraction 48) Encapsulation C) Data hiding D) Hiding complexity :
71. In digital data transmission നി : us ;
A) Baud rate is equat to bit rate B) Baud rate is always smalier.than the. bit rate L
‘ é
C) Baud rate is always higher than the bit rate D) None of the above © i
72, What is a path vector routing ? . ;
A) Network routing proteco! B) Inter-domain routing A
C) Exterior gateway protoco! D) None of the above :
73. From the following sorting algorithms which needs ihe minimum number of swaps ? — fy
A) Bubble sort B) Quick’sort ൭) Merge sort D) Selection sort
74. An on-line commercial site such as Amazon.com is an example of a(n) i
A) Single-user database application 8) Multi-user database application |
C) @-commerce database application © D). Data mining database application &
ക: 8 2003/19 P

<!-- page 7 -->

॥॥॥॥॥॥॥
"75, DED stands for
A} Data Flow Document B) Data File Diagram .
C) Data Flow Diagram | D) None of the above
76. A top-to-bottom relationship among the items in a database is.established by a
A) Hierarchicat schema B) Network schema
C) Relational schema D) All of the above
77. Grant and revoke are - statements.
A) DDL B) TCL C) DCL D) DML
78. Related fields in a database are grouped to form a i :
A) Data file B) Data record C) Menu ഇ Bank ന
79, നട ഭം way data Is organized in and accessible from DBMS.
A) Database hierarchy 8) ‘Data organization റ Data sharing Dy Data mode!
80. The memory which allocates space for DOS and application is called :
A) Expanded memory B) Cache memory :
C)} Virtual memory D) Conventional memory . i
81. You can_use the bar to type URL and display. Web ‘page, or type a key. word to : :
display a list of required Web pages. റ
oA) Menu. B) Search C) Title D) Web : | i
82. :- Which of-the following computer janguages is a mathematically oriented. language used for scientific !
problems.? : . 5
A) FORTRAN B) LISP. C) COBOL ൮ PROLOG... . i
83, Acomplete electronic circuit with transistors and other electronic components ona small silicon chip. i
is called a(n) by :
A) Workstation: :~ B).-CPU-. C) Integrated circuit... 2) Magnetic disk. :
84. Which of the following is used to write a Web page ? |
മു URL 8) HTML ൮ HTTP os ൧.൩... 5 . Q
85. DNS can obtain the : of host if its domain name is known and vice. versa. : .
A) Station address B) IP address G) Port address D) Checksum. റ
86. The earliest software was developed.using ലി ി
A) The Waterfall Model 8) Prototyping Model ©) Spiral Model D) Incremental Model ഴു ലു
87. Which of the following is wrong ? : ,
A) Clients can store information _ B), WAN is faster than LAN ന
൮ Servers only provides network resources ൧) Peer.to ടല network have.peor securing |
88. The time between programme input and ‘output is called : .
A) Execution time. B) Turn around നട C) Waiting time D) Allof-the above © .
A 9 2003/19.

<!-- page 8 -->

1,
89. In a computer, clipboard stores :
A) Entered text B) Copied text C) Deleted text 2) Repeated text . «
90. Ina computer, page number can be inserted from menu bar by using .
A) Insert menu B) Format menu C) Window menu’ D) File menu :
91. The Key F2 opens a ട്‌
A) Open dialog box B) Save As dialog box
C} Close diatog box D) None ‘of the above
82. VSAT stands for
൪) Very Small Aperture Terminal B) Varying Size Aperture Terminal
C) Very Small :Analog'Terminal : .. D) Very Small Access Terminal
93. Bluetooth is.an‘example of : on 5
ന; ൧) ടാലി 5 B).-Local Area Network
C) Virtual Private Network D) Wide Area Network
94. Streaming is 7. : eet : :
A)."A technique for transferring data - ;
8) What the.processor.givés to the user :
C). Sequential:access provided by storage media i
ഴ്‌ ൧) Quickest way to tocate a particular word or phrase 5 }
95. -RFID. stands for 7 a പു : പ :
A): Radio:Frequency.tdentification cB) RAM Field Identification... |
C): Read only File Identification D): Recycle Folder jdentification te i
“96, മാസ്തി landscape are : [ 4
A). Page orientation B): Paper:size C) മറ്റ layout D) Both 8) and.C) i
97, SMTP-stands for aa i
A): Simple Mail ‘Tracking Protoco! 4) Simple Mail Transport Protocol : ന
©) Simpie Mail Transfer Protocol :D) -Sample Mail Tracking Protocol :
98. Most application software today came with an interface called a(n): i
A). Barcode reader. 8) Voice instruction system
C) Chatacter'user interface a : 0) Graphical user interface .
99. Information travels between. components of the motherboard through :
ഗു CMOS : 8) Buses ©) “Petipherais* ‘D) Flash memory. :
100. Which of the following you will use to move selected text from one place to another ? :
A) Cut and Paste B) Move and Save _-C). Copy and Paste D).-Move and Paste ‘
പി. How do you save a presentation under new. file name Deer es [ en ee - :
കു) Select the File. menu and choose Save As : ലു . | :
B) When you close PowerPoint, the file will automatically saved Q
C). Select the File menu and choose Save. : [ )
_ ൧) The file will automatically saved under the new name if you.change.the title E
Aes 10° ; 2003/19

<!-- page 9 -->

॥॥॥॥॥
102. What term describes explanatory text attached to a cell ? : . |
A) Context B) Callout ൮) Comment D) Dialog ന
103. In MS-Excel, what does SUMIF function do. 2 ഴ്‌
A) Adds up cell values based on a condition B) Adds all the numbers in a range of ceils
റ Returns a subtotal in a list or database D) Both A) and B)
104. Who designed the first electronics computer - ENIAC ഴു .
A) Van-Neumann B) Joseph M. Jacquard
C) J. Presper Eckert and John W. Mauchly D) 41 of above a
105. The shortout key Ctrl+Y in MS Word will . .
A) Redo last action performed 8) Undo Jast activities :
C) Cut selected text D). Insert link. ch &
106, ഗലി one is not a system tool 7 : >
A) Backup. B) Disk defragment C) Virus scanning D) Formatting :
107. Where-have:the program and data to be iocated before. the ALU and control-unit.of-a‘computer.can i
‘operate ൨/7. : a : Saye BAY :
A) Internal: memory : B) Secondary memory. od
C) Microprocessor 4 D) “Magnetic tapes: = ‘ :
108. . in MS. Word, borders can be applied to | പ ട്‌ :
A). Cells. B) :Paragraph C). Text D) Alb of the above... q |
108, Which of the following is not the layer of TCPAP protocol? Mee ; : \
൧) Application layer B). Session layer °°. °C) “Trarisport layer D) ‘Internetwork layer L
110. A feature-of MS Word that saves the document automatically.after certain interval.is. available ‘on ലു
A) Save tab.on options dialog box B): Save As dialog box aaa .
C). Both of the above : D) നദ ന
111. JPEG stands for L& : : : E
A) Joint Photographic. Expert Group 8) Joint Photographic Expert Graphics ര
C) Join Photographic Expert Group D). Join Photographic Expert Graphics :
112. The Word Wrap feature ~* . a
A) automatically moves text to the next line when necessary | ലു;
B) appears at the bottom of the document : ന .
C) allows you to type over text was : .
D) Is the short horizontal line indicating the end of document 7 ലി ക
113... Which key is used to “Goto” tab in. MS Excel? : 2 rns .
A) FS B) F7 C) F6 D) FS a
114. Select font in MS Excel 7 ല്‍
A) വട B) Ctr Shift+F C) CtrlaShift+J D) None of these a
A i 200319

<!-- page 10 -->

FAA
115. What type of chart is useful for comparing values over categories ? . |
A) Pie Chart B) Column Chart C) Line Chart D) Dot Graph
116. What type of chart is good for single series of data 7
A) Pie Chart B) Column Chart C) Line Chant D) Cone Chart
117. You can set page border in Excel.
A) From border tab in format cells dialog box 8) From border tool in formaiting toolbar
C) From line style tool in drawing toolbar D) You can not set page border in Excel
118. Where can you set the shedding color for a range of celts in Excel ? j
A) Choose required color form patterns tab of format cells dialog box |
8) Choose required color on fill color too! in formatting toolbar :
9) Choose. required color.on fill color tool in drawing toolbar H
D) All of the above ഴു
119, Ctrl+D ധി in Excel wiil :
A) -Open.thefont-dialog box .- B):. Apply double underline. for.the active cell :
C). Fil down in the selection 1D) :None of.the above :
120. Which of the following you can paste selectively using paste special command 9-20... :
A). Validation B) Formats ©) Formulas ൧) -All_of.the above :
121. In MODEMS! °° = us : : :
A). several digital signals are multiplexed : .
B),.a digital signal.changes some characteristics of a carrier wave . ,
: C) digital ‘signal is amplified : : :
D) all ofthe above: ; e
122. If you heed to remove only.the formatting done ina range (numbers and formula typed there should :
not be removed), you must റ S
A) From Edit menu choose Clear and then Formats .
B) From Edit menu choose Delete ~
C) Click on Remove Formatting tool on Standard Toolbar ന
D) Double click the Format Painter and then press Esc Key in keyboard 4
123. Where can you find the horizontal split bar on MS Word screen ? : ലി
. A) On the leit of horizontal scroll bar [ [
B) On the right of horizontal scroll bar .
C) On the top of vertical scroll bar E
D) On the bottom of vertical scroll bar .
124. if you want to keep track of different editions of a document which features will you use ? ലി
A). Editions. B). Versions C) Track change D) All of the above
Ae, 12 20030
