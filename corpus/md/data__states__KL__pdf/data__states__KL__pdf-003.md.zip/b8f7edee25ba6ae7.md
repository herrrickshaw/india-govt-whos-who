---
doc_id: "b8f7edee25ba6ae7"
source_url: "https://gecskp.ac.in/pdf/NISP.pdf"
ministry: "Government Engineering College Palakkad, Sreekrishnapuram, Kerala"
title: "National Innovation and Startup Policy"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c06e7433642342a0"
---

<!-- page 1 -->

Govt. Engineering College, Palakkad
National Innovation and Startup Policy

Objective:

To nuture the innovative and creative talents of the youth and channelise them
towards the realization of useful products and services for the welfare of the society.

GEC Palakkad, which was ianugurated in 1999 took its first step towards innovation
in 2010 with the setting up of the satellite center of CERD (Center for Engineering
Research and Development), affiliated to CERD Trivandrum. The center supports
students innovations, by way of routing their fund requests to the Head office,
arranging training programs, and providing tools and technical support for innovative
projects through the Innovation Centre and Centre of Excellence in Advanced
Computing that have been set up under CERD. The activities of CERD unit is
managed by the Coordinator under the guidance of the CERD Executive Committee
consisting of the Principal, Heads of Departments and the Coordinator.
When the project ideas pass the initial stage (proof of concept) in the respective labs/
Departments, the next stage is IEDC (Innovation and Entrepreneurship Development
Cell), which was set up with the initial funding and guidance from the Kerala Startup
Mission. This cell can provide small seed funding to viable prototypes if the
concerned students express willingness to pursue entrepreneurship through startups.
Another unit that closely works with IEDC is the ED Club (EDC in short), which
channelises some funds from the District Industries Center Palakkad for projects that
have good business potential.
The next stage is the Technology Business Incubator (TBI), which functions as
follows:
TBIGECS is a prominent facility in GEC Sreekrishnapuram, Palakkad under the
Directorate of Technical Education, Kerala. Its aim is to bring Technology and
Business under one umbrella. Proposals are invited from young entrepreneurs with
innovative ideas to start new venture in different areas of technology. The incubatees
can use the facility provided in TBIGECS for a maximum period of three years

<!-- page 2 -->

(maturation time). A nominal rent will be charged from the incubatees while they are
in TBIGECS. The selected start-up companies will be provided with office space,
broadband internet, IPR protection and technical advice to develop their ideas into
marketable products. Depending on the progress, support for marketing, branding,
technology transfer, securing IPR, etc. may also be extended by TBIGECS. The TBI is
managed by a committee consisting of:


The Principal (Chairperson)



Heads of Departments



TBI Coordinator

The screening process of aspiring startups for slots in the TBI is done once per year
by a Screening Committee consisting of the Manager of the nearest public sector
bank, Representative of the Department of Industries/ District Industries Center and
the members of the TBI Management committee.
Applications from prospective entrepreneures will be invited annually, after notifying
in the college website (www.gecskp.ac.in). The screening of the applications will be
done by an expert panel chosen by the TBIGECS management committee. The
applicants of the selected proposals will be intimated within 15 days of selection.
Once the offer is accepted by a startup, it will be allotted a cubicle with power and
connectivity. Technical help, tool sets, meeting space, IPR related advise, interaction
with external experts and customised training are offered to the incubatees. Each
startup unit is required to set up a website for it, update the TBI in charge with
their progress periodically and follow the general code of conduct and discipline.
After one year, the progress will be evaluated and the next course of action
(continuation, successful exit, technology transfer or winding up) will be advised by
the TBI Management Committee.
Students, staff and the members of the TBI will be assisted by the IPR Cell to file
patents, copy rights, etc., to secure IPR through the Patent Information Centre (PIC)
of the Keralal State Council for Science, Technology and Environment (KSCSTE),
Trivandrum.
Responsibility for implementing NISP in the institution has been fixed on the joint
team of CERD, IEDC, IPR Cell and TBI Executive/Management Committees.

<!-- page 3 -->

The process followed in NISP implementation is shown as a flowchart below:
NISP Implementation Process

Market
Patents

Products

TBI
IPR Cell
Prototype+Business Plan
IEDC/EDC

Patent Applns
Prototype/Proof of Concept
CERD

Projects

Projects

Dept n
Dept1

Dept2
