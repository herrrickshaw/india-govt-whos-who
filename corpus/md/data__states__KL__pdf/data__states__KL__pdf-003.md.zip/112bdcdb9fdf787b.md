---
doc_id: "112bdcdb9fdf787b"
source_url: "https://www.cethalassery.ac.in/files/Guidelines-for-admission-to-working-Professionals-Clause-10.pdf"
ministry: "College of Engineering Thalassery, Kerala"
title: "Guidelines for admission to working-Professionals Clause-10"
date: ""
pages: 2
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "0b1a46919cfdea61"
---

<!-- page 1 -->

not-send_the_printout-of the-page_and_supporting documents tothe Office പ്‌ Director, LBS
heir i
4
4.
applicable.
5, Scanned copy-of Community Certificate if applicable.
&
നം
8.
a
candidates, claiming EWS reservation).
40. Any-other- documents-mentioned-in-the Notification-of the Director,LBS- Centre for Science
and Technology,
Application)
Coritficate
Cortifi in th listriet fi lob റി
WARNING: Incomplete applications with defective or incomplete certificates or without
10.ADMISSION GUIDELINES FOR’ B.TECH PROGRAM FOR WORKING
PROFESSIONALS
The candidate those who wish to apply for B.Tech Working Professional program shall qualify
the entrance examination for B.Tech Lateral Entry (BLET) conducted by LBS Centre. Candidates
©DTE-BLET 2025 Page 15

<!-- page 2 -->

interested in applying for the B.Tech program for Working Professionals must be employed in a
registered industry, organization, or MSME within a distance radius (as per University /AICTE
Regulations published from time to time) of the institution where they seek admission. Applicants
should have relevant work experience and meet the prescribed academic qualifications, including
a diploma or B.Sc. degree or D. Voc with the required marks. Admissions will be based on merit,
with eligibility criteria and ranking methods outlined in the guidelines issued by the University/
AICTE. For B.Tech working Professionals program, no centralized allotment will be conducted
by LBS Centre and the candidate those who have qualified the B.Tech Lateral Entry Entrance
examination shall apply to the respective college which offers B.Tech Working Professional
program. The tuition fees and other fees will be as fixed by the respective colleges. The colleges
shall conduct admissions transparently, ensuring compliance with AICTE and university
regulations. The list of colleges offering the B.Tech Working Professionals program will be
published on the LBS Centre website and the respective college websites. Reservation policies
will be as per this prospectus.

Eligibility Criteria

¢ The applicant seeking admission to the course should be a professional/ employee working in
Registered Industry / Organization (Central / State) / Private/ Public Limited Company/ MSMEs
located within 75 Km radial distance from the institute in which admission is sought. The
applicant shall submit proof of employment from the Employer in the form of an Employment
and No Objection Certificate as per Annexure 13 to the college at the time of admission.

& The applicant should have been employed in the Registered Industry / Organization (Central /
State) / Private/ Public Limited Company/ MSMEs for a minimum continuous period of ONE
Year on Full time basis. The applicant shall submit proof of continuous employment and conduct
from the Employer in the form of an Experience and Conduct Certificate as per Annexure 14 to
the college at the time of admission.

«The applicant should have passed Diploma examination with at least 45% marks (40% marks in
case of applicants belonging to reserved category) in ANY branch of Engineering / Technology.

OR

൫ Passed B.Sc. Degree from a recognized University as defined by UGC, with at least 45% marks
(40% marks in case of applicants belonging to reserved category) and passed 10+2 examination
with Mathematics as a subject, provided that the applicants belonging to B.Sc stream shall clear
the subjects Engineering Graphics/ Engineering Drawing and Engineering Mechanics of the First
Year Engineering Programme along with the Second Year subjects. These subjects can be done as
Audit courses.

OR

൫ Passed D. Voc. Stream in the same or allied sector.

¢ There shall be no age limit to apply for admission to the course.

11.ENTRANCE EXAMINATION

A State level OMR based objective type Entrance Examination for duration of two hours will be

conducted by The Director, LBS Centre for Science and Technology, Thiruvananthapuram for

the selection.
©DTE-BLET 2025 Page 16
