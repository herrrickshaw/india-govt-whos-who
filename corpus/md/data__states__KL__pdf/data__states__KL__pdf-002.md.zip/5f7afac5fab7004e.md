---
doc_id: "5f7afac5fab7004e"
source_url: "https://www.kfc.org/wp-content/uploads/2026/03/Whistleblower-policy-Vigil-Mechanism-of-the-Corporation.pdf"
ministry: "Kerala Financial Corporation (KFC), Kerala"
title: "Vigil Mechanism"
date: ""
pages: 9
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "095aa5de011b0af7"
---

<!-- page 1 -->

ഇത്ഞമനു്ത്്ഞ്ത്ഞ്ഞ്തുട പ ae
(Cr
Corporation
WHISTLE BLOWER POLICY & VIGIL MECHANISM ‘
February 2023
This Policy is the property of Kerala Financial Corporation and shall not be
reproduced in full or part without the written permission from the Managing
Director of the Corporation
Kerala Financial Corporation
(Incorporated under the State Financial Corporations Act of 1951)
Head Office, Vellayambalam, Thiruvananthapuram - 69503, Kerala, India

KERALA FINANCIAL CORPORATION 20F9

<!-- page 2 -->

. SRE RST RSE SRT OT
INDEX |
INTRODUCTION y
2. DEFINITION 3
2, SCOPE 2
3. GOVERNING LAWS 4
4. ഠേശ OF POLICY 5
ട. DISQUALIFICATIONS 5
6. PROCEDURE 5
: 7. INVESTIGATION 6
8. DECISION 7
9. REPORTING 8
10. PROTECTION : 8
11, ESCALATION MATRIX 8
22. RETENTION OF DOCUMENTS 9
23. SECRECY/ CONFIDENTIALITY 9
14. VALIDITY 9
KERALA FINANCIAL CORPORATION 30F9

<!-- page 3 -->

ത്താ്തോത്ഞത്ത്തുള്‍െ

INTRODUCTION 5

This Whistle Blower Policy provides a framework to promote responsible and

secure whistle blowing. Accordingly, this Whistle Blower Policy (“the Policy”) and

Vigil Mechanism as part of this Policy has been formulated with a view to provide

a mechanism for Directors, employees as well as other stakeholders of the

Corporation to approach the Whistle Officer/ Chairman of the Audit Committee of

the Corporation. The Audit Committee shall review the functioning of the Whistle

Blower Mechanism, at least once in a financial year. The Whistle Blower Policy &

Vigil Mechanism will be displayed on the Website of the Corporation. The Policy

neither releases Directors and employees from their duty of confidentiality in the

course of their work nor is it a route for taking up a grievance about a personal
situation. This policy is in addition to the provisions of the KFC Staff

Regulations, 1966. If there is any contradiction in the provisions of this Whistle

Blower Policy and Vigil Mechanism, the provisions of KFC Staff Regulations, ss

1966, shall prevail. ട്‌

1. DEFINITION

The definitions of some of the key terms used in this Policy are given below:

൦ ‘Audit Committee’ means the Audit Committee of Directors constituted by
the Board of Directors of the Corporation under Section 18(3) of the State
Financial Corporations Act, 1951 and Regulation 18 of the SEBI(LODR)
Regulations, 2015.

« ‘Employee’ means every employee of the Corporation (Regular or Part time
or Contractual).

* ‘Whistle Officer’ is the Whistle Officer of KFC. The Executive Director of the
Corporation is designated as the Whistie Officer. Any subsequent change in
the Whistle Officer will be made by the Board on the recommendation of the
Managing Director of the Corporation.

e ‘Director’ means the director of the Corporation, past and present.

« “Investigator/s’ mean those person/s authorised, appointed, consulted or
approached by the Whistle Officer/ Chairman of the Audit Committee.

« ‘Stakeholders’ means and includes shareholders, bondholders, other
investors, lenders and customers of the Corporation.

« ‘Subject’ means a person against or in relation to whom a Protected
Disclosure has been made or evidence gathered during the course of an
investigation.

൦ ‘Whistle Blower’ means an employee or director or any stakeholder making
a protected disclosure under this policy.

« ‘Vigilance Officer’ means an officer posted to the Corporation on deputation
from Home Department, Govt. of Kerala.

KERALA FINANCIAL CORPORATION 40F9

<!-- page 4 -->

* ‘Disciplinary Action’ means any action that can be taken on the completion
of/during the investigation proceedings as is deemed to be fit considering the
gravity of the matter as per Regulation 39 of KFC Staff Regulations, 1966. |

¢ ‘Protected Disclosure’ means a concern raised by a written communication
made in good faith that discloses or demonstrates information that may
evidence unethical or improper activity. Protected Disclosure should be
factual and not speculative in nature.

* ‘Good Faith’ A Whistle Blower may communicate in "good faith" if there is a
reasonable basis for communication of unethical and improper practices or
any other alleged wrongful conduct. Good Faith shall be deemed lacking
when the Whistleblower does not have personal knowledge on a factual basis
for the communication or where the employee knew or reasonably should
have known that the communication about the unethical and improper
practices or alleged wrongful conduct is malicious, false or frivolous.

2. SCOPE =
« The Whistle Blower’s role is that of a reporting party with reliable

information. He is not required or expected to act as an investigator or
finders of facts, nor would he/ she determine the appropriate corrective or
remedial action that may be warranted in a given case.

e Whistle Blowers should not act. on their own in conducting any
investigative activities, nor do they have a right to participate in any
investigative activities other than as requested by the Whistle Officer(WO)
or the Chairman of the Audit Committee or the Investigators.

* Protected Disclosure will be appropriately dealt with by the WO or the
Chairman of the Audit Committee, as the case may be.

3. GOVERNING LAWS ക

Whistle Blower Mechanism is governed by the provisions of Section 177 of the

Companies Act, 2013; guidelines dated 17.04.2014 issued by Securities and

Exchange Board of India (SEBI) regarding Clause 49 of Listing Agreement

between the listed entity and the Securities and Exchange Board of India (SEBI)

regarding clause 49 of Listing Agreement between the listed entity and the Stock
Exchange; and guidelines/directions dated 01.07.2016 issued by Reserve Bank
of India under section 35 (A) of Banking Regulation Act etc., as the case may be,
which specifically provide for a “Whistle Blower Mechanism” for the employees
of the organizations, to report allegations of corruption or misuse of office by the
authorities of that organisation.

KERALA FINANCIAL CORPORATION : 5069

തത്തന്ന

<!-- page 5 -->

55s SL SE
my te) Ste Msi belowee boners ick veces fi Peal
4. COVERAGE OF POLICY
All Employees, Directors and stakeholders of the Corporation are eligible to
make Protected Disclosure under the Policy. The Protected Disclosure shall be in
relation to matters concerning the Corporation. The Policy covers malpractices
and events which have taken place/ suspected to take place like:
¢ Abuse of Authority. _ :
൫ Manipulation of Corporation’s data/records.
e Financial irregularities including fraud or suspected fraud.
« Any unlawful act whether criminal or civil.
¢ Pilferage of confidential/ proprietary information.
« Deliberate violation of laws/regulations.
« Wastage/mis-appropriation of Corporation’s funds/assets.
« Any other un-ethical/biased/favored/imprudent event.
« Breach of Employee Code of Conduct or KFC Staff Regulations, 1966. r
¢ Governance weaknesses. =
However, the policy should not be used for raising baseless allegation against
other employees/ Management with malafide or political motives.
5. DISQUALIFICATIONS |
Whistle Blowers are accorded complete protection from any kind of unfair
treatment as herein set out. However any abuse of this protection will warrant
disciplinary action as per KFC Staff Regulations, 1966.
6. PROCEDURE
e Protected Disclosure concerning the Whistle Officer, General Managers
and Directors of the Corporation shall be addressed to the Chairman of
“the Audit Committee while protected Disclosure concerning all other
employees should be addressed to the Whistle Officer.
« The Protected Disclosure should contain details like
(a)Name, address and contact details of the Whistle Blower in the
covering letter
(b) Brief description of the malpractice, giving names of those alleged to
have committed or about to commit a malpractice. Specific details
such as time and place of occurrence are also important.
(c) Whistle Blower shall lodge the complainant by way of a letter which
shall be sealed in an envelope marked “Whistle Blower” and
addressed to the Whistle Officer.
KERALA FINANCIAL CORPORATION 6009

<!-- page 6 -->

നി ലം ത ന Fa Fee Te eS eee, Se res ee Te :്്ന
¢ The Protected Disclosure should be forwarded under a covering letter ]
which shali bear the identity of the Whistle Blower. The Chairman of the
Audit Committee / WO, as the case may be shall detach the covering
letter and forward only the Protected Disclosure to the Investigators for
investigation.

¢ Protected Disclosure should be factual and not speculative. It should
contain as much specific information as possible with document/s (if
available) to allow for proper assessment of the nature and extent of the
concern and the urgency of a preliminary investigative procedure.

« Concerns expressed anonymously will not be investigated.

7. INVESTIGATION

ഭ Investigations will be launched only after a Quick Verification which
establishes that:

* (a)the alleged act constitutes an improper or unethical activity or conduct,
and

(b)either the allegation is supported by information specific enough to be
investigated, or matters that do not come within the purview of the
Whistle Blower Policy.

* The Whistle Officer/ Chairman of the Audit Committee may at his/ her
discretion, consider involving any of the Senior Management Personnel/
Vigilance Officer of the Corporation as investigators for the purpose of
investigation.

ച € Protected Disclosure involving or relating to employees will be
investigated by an officer to be decided by the Managing Director based
on the recommendation of the Whistie Officer. Protected Disclosure
involving or relating to the Whistle Officer/ General Managers/ Directors of
the Corporation will be investigated by an officer to be decided by the
Managing Director based on the recommendation of the Chairman of the
Audit Committee. Protected Disclosure involving or relating to the
Chairman of the Audit Committee will be investigated by an officer to be
decided by the Managing Director based on the recommendation of the
Chairman of the Board.

* Subjects shall be informed of the allegations at the outset of a formal
investigation and shall be opportunities for providing their inputs during
the investigation.

KERALA FINANCIAL CORPORATION 7069
പ്രിക്‌ .. പാത്തു

<!-- page 7 -->

പോേ്തത്ങപ്യത്തു്ത്ത്തത്ത.

൭ Subjects shail have a duty to co-operate with the WO / Chairman of the
Audit Committee or any of the Investigators during investigation to the
extent that such co-operation will not compromise self-incrimination
protections available under the applicable laws.

൭ Subjects have a right to consult with a person or persons of their choice,
other than the WO /Investigators and/or members of the Audit Committee
and/or the Whistle Blower.

« Subjects have a responsibility not to interfere with the investigation.
Evidence shall not be with held, destroyed or tampered with, and
witnesses shall not be influenced, coached, threatened or intimidated by
the Subjects.

൭ Subjects have a right to be informed of the outcome of the investigation. r
If allegations are not sustained, the Subject should be consulted as to -
whether public disclosure of the investigation results would be in the best
interest of the Subject and the Corporation.

¢ Investigators are required to conduct a process towards fact-finding and
analysis. Investigators shall derive their authority and access rights from
the Competent Authority when acting within the course and scope of their
investigation.

e Investigators have a duty of fairness, objectivity, thoroughness, ethical
behavior, and observance of legal and professional standards.

* The investigators shall submit their report to Whistle Officer/ Chairman of
the Audit Committee, as the case may be in a closed and sealed envelope,
to ensure that the matter is kept confidential.

8. DECISION

If an investigation leads the Whistle Officer/ Chairman of the Audit Committee to
conclude that an improper or unethical act has been committed, he/ she shall
advice the management of the Corporation to take such appropriate action under
the provisions of KFC Staff Regulations, 1966 or any other law in force for the
time being.

KERALA FINANCIAL CORPORATION 80F9

<!-- page 8 -->

9. REPORTING

The Whistle Officer shall submit a report half yearly to the Audit Committee
about all Protected Disclosure referred to him/ her since the last report together
with the results of investigations, if any. The Chairman of the Audit Committee
shall submit a report half yearly to the Board about all Protected Disclosure
referred to him/ her. since the last report together with the results of
investigations, if any. :

10. PROTECTION

e The identity of the Whistle Blower shall be kept confidential to the extent
possible given the legitimate needs of the investigation and permitted
under law.

« Permission need to be obtained from the Audit Committee for disclosing
the name of the Whistle Blower, in case of inquiry compulsions, during the
course of investigation. On obtaining permission from the Audit
Committee, authorised officials may interview relevant person to seek
information. :

e The Corporation, condemns any kind of discrimination, harassment,
victimization or any other unfair employment practice being adopted
against Whistle Blowers. In case the identity of the Whistle Blower is
revealed inadvertently or by design complete protection will, therefore, be
given to Whistle Blowers.

¢ If any person is aggrieved by any action on the ground that he/she is
being victimized due to the fact that he/she had filed a complaint or
disclosure, he/she may seek redressal before the MD.

11. ESCALATION MATRIX

e If the complaint is found out to be frivolous or not coming within the
ambit of this Policy or Corporation is not taking any action, then the same
will be intimated to the Whistle Blower by the Whistle Officer/ Chairman of
the Audit Committee by updating the status of the complaint by letter
addressed to whistle blower.

« If the Whistle Blower/Complainant is not satisfied with the response of the
Whistle Officer/ Chairman of the Audit Committee with the decision of the
Investigations/ decision of the Audit Committee he/she is free to take up
the matter with the Chairman of the Board through written
communication for reconsideration.

KERALA FINANCIAL CORPORATION : 9OF9

<!-- page 9 -->

GEES ii ES a Ree
12. RETENTION OF DOCUMENTS
a6 RETENTION OF DOCUMENTS
All Protected Disclosure and document/s collected along with the results of
investigation relating thereto shall be retained by the Corporation for a minimum
period of seven years.
13. SECRECY/ CONFIDENTIALITY ട്‌
| The Whistle Blower, the Subject, the Whistle Officer and everyone involved in
the process shall:
* maintain complete confidentiality/ secrecy of the matter;
* discuss only to the extent or with the persons required for the purpose of
completing the process and investigation;
* not to keep the papers unattended anywhere at any time; and
¢ keep the electronic mails/ file under password. &
14. VALIDITY
The Whistle Blower Policy & Vigil Mechanism shall remain in force for one year or
till a revision of this Policy is approved. This Policy is to be read along with the
related policies, KFC Staff Regulations, 1966 and extant regulatory guidelines.
Chairman and Managing Director
KERALA FINANCIAL CORPORATION 10 OF 9
