---
doc_id: "ac9ead080c1b83ab"
source_url: "https://www.keralaenergy.gov.in/images/pdf2017/Highlights_of_Two-day_Workshop_on_Energy-2222.pdf"
ministry: "Energy Management Centre, Kerala"
title: "Highlights of Two-day Workshop on Energy Conservation Building Code – Business and Policy Development"
date: ""
pages: 19
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6abeb42c32f27a85"
---

<!-- page 1 -->

Draft Highlights of
Two-day Workshop on
Energy Conservation Building Code - Business and Policy Development

29, 30 June 2010

Energy Management Centre- Kerala (EMC)

Environment Management Agency Kerala

Department of Power, Government of Kerala

Department of Environment, Government of Kerala

<!-- page 2 -->

Preamble
The programme was designed to transform behavior by educating and motivating the
professionals involved in building transactions to alter their course toward improved energy
efficiency in buildings through Energy Conservation Building Code (ECBC).

Further to detail discussions between Environment Management Agency Kerala and Energy
Management Centre regarding Energy Conservation Building Code (ECBC) during January
to June 2010, as part of implementing Energy Conservation Building Code in Kerala State,
Energy Management Centre- Kerala (EMC) & Environment Management Agency Kerala
(EMAK) jointly organized a two day Workshop on Energy Conservation Building Code
Business and Policy Development at Thiruvananthapuram for Policy makers and Design
engineers and execution agency representatives in the State.

Kerala has the third highest overall population density of 819 persons per sq.km. (next only
to west Bengal and Bihar) in 2001. But the density pattern in our major cities and towns
shows that, the increase in density is due to the overall population increase over the entire
spread of Kerala, which is occasionally accentuated in the urban areas with nominal
variations. Urbanisation trend in the state of Kerala shows marked peculiarities.

In Kerala, total commercial sectoral energy sales is 1900 MU which is about 15.7% of
gross electricity sales in the State and consumption of 45 energy intensive Commercial
Buildings amounts to 506 MU.

Different Categories of Commercial Buildings

<!-- page 3 -->

Energy saving potential in commercial category is about 20% with the growth of commercial
sector the quanta of savings are bound to increase further.

EMC has already identified buildings as a potential area for energy efficiency improvement
and the first workshop on ECBC was held in 2007 and the second in 2010 intended to
implement ECBC with the inputs from the various stakeholders. Prior to the programme a
copy of ECBC was send to all the implementing agencies to equip and orient with the ECBC
compliance matrix.
Background
The Energy Conservation Act 2001 (Central Act 52 of 2001) empowers the Central
Government under section 14 (p) read with Section 56(2)(1) to prescribe Energy
Conservation Building Code(ECBC). The Code defines norms and standards for the energy
performance of building and their components based on the climate zone in which they are
located. ECBC provides minimum requirements for energy – efficient design and
construction of buildings. ECBC covers building envelope, heating, ventilation, and air
conditioning system, interior and exterior lighting system, service hot water, electrical power
system and motors.
Chapter VI of the EC Act 2001 in Section 15 (a) provides the State Government to amend
the energy conservation building codes to suit the regional and local climatic conditions and
may , by rules made by it, specify and notify energy conservation building codes with
respect to use of energy in the buildings. It also allows the state government to direct every
owner or occupier of a building or building complex being a designated consumer to comply
with the provisions of the ECBC. Section 15 (b) of the EC Act also gives powers to direct
every owner or occupier of a building or building complex being a designated consumer to
comply with the provisions of Energy Conservation Building Code.

Date and Venue of programme


29th & 30th June 2010: Government Guest House, Thycaud, Thiruvananthapuram

Inauguration of Workshop
The Workshop inauguration was held on 29th June 2010 at Government Guest House,
Thycaud, Thiruvananthapuram. Mr. Dharesan Unnithan, Director, EMC gave the welcome
speech in which he briefed and spoke on necessity of Energy Conservation Building Code.
The session was presided by Dr S. K. Khanduri, IFS, Director, EMAK and emphasized on

<!-- page 4 -->

the necessity of ECBC. Mr. Paul Antony, IAS, Principal Secretary, Power Department,
Government of Kerala formally inaugurated the programme and Mr. A. M. Narayanan,
Head Energy Efficiency Division, EMC proposed vote of thanks.

Faculty and resource support
The programme faculties and resource support professionals comprised of the following:


Mr. Narayanan A M, EMC



Mr. Fahid Rahim, Saint Gobain Glass India



Mr. Anand, CII



Mr. Steve Belkin, Sunflower Solutions



Mr. R. Harikumar, EMC



Mr. Vivek Jain, Philips Electronics India Ltd



Mr. Rajeev R V, Schneider Electric India Pvt. Ltd.



Mr. Sivakishan, TERI



Mr. Salim, TCS



Mr. Shivakumar & Mr. Shanavaz, KSPC



Ms. S Kumar Deepa, EMC



Mr. Johnson Daniel, EMC



Mr. Subash Babu, EMC



Mr. Sandeep T R, EMC



Mr. Sandeep K, EMC



Mr. Viju P M, EMC

<!-- page 5 -->

Summary of interactive deliberations
Mr. A.M. Narayanan, EMC

The presentation spoke on all the aspects of ECBC, from its relevance to the various
criteria as well as the compliance checking options. The entire presentation covered a gist
of ECBC, providing a glance to the participants of all the sessions that were to follow. The
session as it was meant provided the right mood and spirit to the participants. The building
envelope, the heating ventilation and air conditioning, the electric power systems, lighting
systems with respect to the compliance matrix were deliberated in detail.
Mr. Fahid Rahim, Saint Gobain Glass India

The presentation touched upon the contents of ECBC with respect to fenestration
and spoke on the mandatory requirements explaining the terms such as Wall to Window
ratio, the Solar Heat gain, the U factor as well as the whole body performance method,
prescriptive method and trade-off method in the ECBC. He spoke on glass as a fenestration
material its scope as well as the solution Saint Gobain as a company will be able to provide.
Mr. Anand, CII

The Indian Green Building Council Rating systems and minute intricacies of the
same were introduced. The presentation covered every aspect which a building comprises
of and also the requirements and benefits of such a rating system. The major areas in IGBC
rating are Sustainable Sites, Water efficiency, Energy and Atmosphere, Materials and
Resources, Indoor Environmental quality and Innovation and Accredited Professional
points. There is a varying weightage for each of these six points are given for rating from
IGBC.
Mr. Steve Belkin, Sunflower Solutions

The increase in efficiency in roof top systems solar photovoltaic systems with
tracking systems with emphasis to manual tracking system which is more user friendly was
discussed. It was also explained that the manual tracking system is less expensive at the
same time very easy to use as well. The tracking system was reported to increase the
efficiency of the system by 30-40 %.

<!-- page 6 -->

Mr. R. Harikumar, EMC

The Indian Scenario as applicable to the building sector on renewable energy and
the government policies and programme towards the various renewable options viz. solar
thermal, wind solar hybrid and biogas were explained.
Mr. Vivek Jain, Philips Electronics India Ltd

The session covered the various aspects of illumination systems such as Lighting
Controls, Space Control, Control in day lighted areas, Exterior Lighting Control, Additional
Control for Display/Accent Lighting, Case Lighting, Hotel and Motel Guest Room Lighting,
Task Lighting, Non Visual Lighting, Demonstration Lighting, Interior Lighting Power, Building
Area Method and Space Function Method were discussed. The session was focused on
Energy Conservation Building Code, with a through explanation not only the retrofits but
also the illumination system as a science.
Mr. Rajeev R V, Schneider Electric India Pvt. Ltd.
The various aspects of Building Management System and their relevance on ECBC

were detailed. The systems that come under the subtitle of electrical power in ECBC were
well covered in the session.
Mr. Sivakishan, The Energy & Resource Institute

GRIHA, an acronym for Green Rating for Integrated Habitat Assessment, is the
National Rating System of India. It has been conceived by TERI and developed jointly with
the Ministry of New and Renewable Energy, Government of India. It is a green building
'design evaluation system', and is suitable for all kinds of buildings in different climatic
zones of the country. The session covered indepth aspects of (GRIHA) rating.
Walk through of a Green Building - Peepul Park, Tata Consultancy Limited (TCS),
Technopark, Thiruvananthapuram - Mr. Salim, AGM, TCS.

On the second day of the workshop, the participants were taken to TCS, Peepul
Park, Technopark, Thiruvananthapuram for site visit and further discussions. Mr. Salim,

<!-- page 7 -->

TCS gave a brief idea about the TCS facility, LEED star rating in buildings, regarding their
“Silver rated” building and procedures and criterion for attaining LEED rating for buildings.
After the presentation, the participants were taken for a comprehensive walk through of the
“Silver rated” building to show them the design & practices.
Mr. Shiva kumar & Mr. Shanavaz, Kerala State Productivity Council

The session covered the various aspects of Energy Audit with a focus on Energy
Conservation Building Code (ECBC). The session took the crowd towards the compliance
matrix in a manner sufficient to orient the group into ECBC compliance check &
implementation. The session covered energy audit case studies in detail.

Break-out session
After the interactive sessions, the participants were divided into six groups for group
discussion. Mr. A M Narayanan, Head of Energy Efficiency Division, EMC briefed the
participants on the session. After the group discussions, each group came up with
recommendations/ inferences on how to implement Energy Conservation Building Code in
the State. Each group leader presented their inferences. The session had Mr S K Khanduri,
IFS, Director, Environment Management Agency Kerala and Mr Shivakumar, Director,
Kerala State Productivity Council as panelist.

Salient points emerged from the break-out sessions
The major points brought up in the brain storming of breakout sessions are listed down
below group wise.

Group 1
1. Buildings with contract demand greater than 600 kVA are part of the ECBC limit.
However considering the large numbers of building are coming up in the range of
100-200kVA contract demand in Kerala, all HT and EHT building consumers may be
brought under ECBC.
2. Monitoring Committee

<!-- page 8 -->



Yearly compliance audit to be done by a third party assessor and not the
agency who gives building permit or certification such as the local self
government agency or Electrical Inspectorate.

3. ECBC Implementation Phases
Phase 1: Intensive awareness campaign for all building sector professionals ie;
all stakeholders in ECBC
Phase 2: Voluntary Implementation for 1 year in Energy Intensive Buildings ( ie;
buildings with more than or equal to 500kW connected load or 600kVA
contract demand) and to be made mandatory from the second year
Phase 3: Voluntary implementation for 5 years for all commercial buildings
(other than the energy intensive buildings mentioned above) and to be
made mandatory from the sixth year onwards.
4. Incentives & subsidy to be introduced during the voluntary implementation phase.
5. If existing Buildings are made into ECBC complaint subsidies & incentives should be
allowed.
6. Standardization of basic energy efficiency requirements in electrical equipments
such as Standards and Labeling Programme of Bureau of Energy Efficiency
7. Training and certification of concerned officials of Local self government Institutions
(LSGI) involved and responsible for building scheme in ECBC compliance
verification. Training and certification may be preferably conducted by the State
Designated Agency (SDA).

Group 2
1. ECBC code may be implemented as such. Any modifications required may be
treated in a case to case basis.
2. During the compliance all electrical systems may be inspected by Electrical
Inspectorate; and all other aspects including building envelope by the Chief Town
Planner/ District Town Planner. Inspection report should be filed to the SDA with a
copy to the LSGI.

<!-- page 9 -->



LSGI should scrutinize these compliance reports and attach with their pre
commission/ commission approval. A copy of the compliance reports by these
agencies may also be forwarded to the SDA.

Group 3
1. Training and certification of concerned officials of Local self government Institutions
(LSGI) involved and responsible for building scheme verification and approval shall
be conducted preferably by the State Designated Agency (SDA) under the Bureau of
Energy Efficiency.
2. A similar code for the residential building segment may also be taken up
subsequently.
3. Embodied energy assessment & material used in the construction also should be
taken into account.

Group 4
1. The ECBC may be reviewed further with respective to the geoclimatic conditions in
the various regions in the state.
2. The applicant may send the building scheme with ECBC compliance matrix to the
building verification and approval authority with a copy to EMC. Approving authority’s
trained personal may confirm the compliance or furnish deficiency report if any for
resubmission. EMC will also undertake compliance verification and preparation of
report. EMC will forward its report/approval to the applicant as well as to the
approving authority. EMC will provide compliance certificate to the approving
authority with a copy to the owner within a period of one month. In the wake of no
deficiency in the compliance matrix provided by the applicant, EMC will provide
compliance certificate to approving authority with a copy to the building owner.
3. Necessary inclusion may be made in Kerala Building Rule regarding ECBC.
4. Compliance Auditing shall be done in 3 stages


Scheme Submission

-

Preliminary stage



Compliance Check

-

Intermediately stage



Building Construction

-

Execution stage

<!-- page 10 -->

5. Training and certification of concerned officials of Local self government Institutions
(LSGI) involved and responsible for building scheme verification and approval shall
be conducted preferably by the State Designated Agency (SDA) under the Bureau of
Energy Efficiency ie; Energy Management Centre in case of Kerala.

Group 5
1. Local climate variations should be accounted in ECBC. There may be multiple zones
in Kerala like coastal, plateau and high range.
2. Due consideration shall be made for local traders and locally available materials
while undertaking ECBC compliance check.
3. Regional local committee shall be constituted with stakeholders of Govt. like LSGI,
TP, PWD, KSEB, Electrical Inspectorate, EMC etc. for periodical review.
4. Green building concept may be incorporated in Building rules.
5. Use of energy intensive materials to be discouraged.
6. Energy Performance Index in terms of units per square meter may be benchmarked
for small. Medium and even large buildings and incentives based on the same may
be proposed / given.
7. The benchmark of 500kW shall be brought down to 100kVA contract demand in
Kerala.

8. ECBC complaint materials may be included in the Government material schedule.
Group 6
1. ECBC Compliance: Modifications to be made


Due considerations for climate of Kerala



Check to be in place at the design stage rather than large scale retrofit at
later phase.

2. All buildings above 1000m2/10000sqft built-up area to mandatorily follow ECBC
without connected load consideration.
3. Tax rebate/incentives to be given to motivate.
4. Initiative to implement in government buildings.

<!-- page 11 -->

5. All developments below 1000m2 to be taken up for energy conservation on voluntary
basis with tax rebates & incentives. Prioritize requirements & give incentives that
consider such applicants.
6. Architects to ensure that basic planning comply with energy & environment friendly
design.
7. For buildings up to 1000m2 KBR to be amended for ECBC compliance and approval
check to be at local body level. For buildings above 1000m2 approval from EMC to
be mandatory. EMC to develop a core body competent to certify energy efficiency.
8. Retrofit to be provided within a specified compliance period- phase out period.
Penalty to be imposed, for exceeding time limit for compliance.

Emerged Specific Recommendations & Way Forward

The workshop was intended to be an eye opener to the fact that energy efficiency can be
substantially improved with existing technologies. Also with an understanding that progress
must be made well in time to vastly improve the energy efficiency of both new and existing
buildings.

The two day deliberations were intended to create awareness on the various aspects of ECBC
compliance and also to equip the licensing and designing architects and engineers for the
enforcement of the Energy Conservation Act, 2001. The Workshop as per the feedback of the
participants enabled to develop a basic system wise understanding on ECBC and compliance
matrix.

The recommendations of the Workshop can be summarized as


Implement ECBC in the State



ECBC needs to be amended to include all HT Commercial Buildings



ECBC compliance may be issued by LSGI in consultation with EMC. The compliance
approval shall be within one month from the date of submission of the plan and
compliance matrix.



Developing accredited professionals for ECBC compliance check in LSGs needs to be
taken up by EMC; LSGIs may have budgetary provision to impart training and certifying

<!-- page 12 -->

its concerned personnel.EMC shall train the existing building scheme verifying team for
compliance check.



A similar code for the residential building segment may also be taken up
subsequently.

In addition to the above recommendations the followings may also be included in the preview of
the ECBC.


Harnessing Renewable Energy for Electricity Generation in the building.



Energy Efficiency of IT Hardware may also be included in the ECBC compliance check
list.

Kerala has been able to provide leadership in almost all aspects of sustainable development
and building sector provides yet another means to improve the energy efficiency. The Kerala’s
economy is also dependent of service industry such as IT industry, Hotel Industry, Hospitals etc.
With more than 100 MU of identified savings (NPC Study in 2009) through retrofitting of existing
buildings and an even higher from energy efficiency at design stage (which is exactly the aim of
ECBC), the state can definitely pave its own path in the field.

The programme enabled to encourage interdependence by adopting holistic, integrated
approaches among the stakeholders that assure a shared responsibility and accountability
toward improved energy performance in buildings and their communities.

<!-- page 13 -->

Annexure
The following are given as Annexure for reference and records:
A. Program schedule
B. List of Participants
C. Photograph

<!-- page 14 -->

Annexure A
Program Schedule - Workshop on Energy Conservation Building Code Business and Policy
Development jointly organized by Energy Management Centre-Kerala & Environment
Management Centre-Kerala
DAY 1
29 June 2010
Registration 9.30 am – 10.00 am
Session

Handled by

Time

Morning Session 10.45 am - 1.00 pm
Introducing ECEC

Mr. A. M. Narayanan, EMC
Mr. Fahid Rahim, Saint Gobain Glass
India

Fenestration
Green Building and LEED Certification

Mr.Anand, CII

Renewable Energy Application_ BIPV,
Solar Roof tops systems

Mr. Steve Belkin,
Sunflower Solutions, USA

Other Renewable Energy Application

Mr. R. Harikumar, EMC
Afternoon Session 2 pm - 5.15 pm

Illumination System

Mr.Vivek Jain, Philips

Electrical Power

Mr. Rajeev R V, Schneider Electric

GRIHA Rating

Mr. Sivakishan, TERI
DAY 2
30 June 2010
Morning Session 10.00 am – 12.00 pm

Session
Site Visit and Discussions at TCS,
Technopark, Trivandrum

Handled by
Mr. Salim, TCS
Afternoon Session 1.45 pm – 4.00 pm

Energy Audit in ECBC Perspective &
Compliance
Break Out Session and Group
Presentation

Mr. Shanavaz, KSPC
Chair: Mr. A.M. Narayanan, EMC

Time

<!-- page 15 -->

Annexure B
List of Participants for the Workshop
SN

Name

1

Ramesh R

2

Sreekumar M B

Designation & Organization
Assistant Executive
Engineer, KSEB

Telephone

Email ID

9447110750

Executive Engineer,
KSRTC
Assistant Engineer,

3

Unnikrihnan Nair K

National Games

9497570481

Secretariat
4

Haridas H V

Team Head, National
Games Secretariat

0471-243000

Superintendent Engineer,
5

Raveendranath T C

National Games

9446568181

Secretariat
6

Priyalal J

7

Dharmakeerthi P P

Assistant Executive
Engineer, LSGD
Assistant Executive
Engineer, LSGD

9567364254

9447001127

Assistant Engineer,
8

Ansar m

National Games

9446553310

josephpriyalal@yahoo.com

gopalppd@yahoo.co.in

mkanzar@gmail.com

Secretariat
9

G Vijayakumar

Director, Ajit Associates

10

Dr. Salim A

11

Renjith C

12

Sarikala D

13

Sasikumar T

Executive Engineer, PWD

14

Sadananda Pai

Executive Engineer, PWD

8086395215

15

Chandrachoodan

Executive Engineer, PWD

9447101819

Professor & Head, Govt.
Engg. College, Tvm
Dy. Project Manager, CES,
Trivandrum
DPM, CES, Trivandrum

999586874

9447119307

9847572147

9444170286

ajit@ajitassociates.com

profasalim@yahoo.co.in

Renjithc_75@yahoo.com

cestrivandrum@yahoo.com

8086395176,
0487-2330010

gcp8888@gmail.com

<!-- page 16 -->

Pillai
16

Manoj Kumar

Manager (Admin-Ele), The

Mahapatra

Federal Bank Ltd.

9847914490

Assistant Engineer, Kochi

9447127668,

Municipal Corporation

0484-2369007

17

Suma P Surendran

18

Mohankumar M A

19

Ajayakumar P

20

Sarojadevi T O

21

Chinchu S

22

Jayakumar K

23

Unnilrishnan V

EE (Planning), KSHB

9447048509

24

Padmakumar R S

AEE (Electrical), KSHB

9446144771

25

Navakumar S R J

26

Anitha Selin A B

27

Salihan

Assistant Engineer, LSGD

9446706816

28

Bijimole E R

Assistant Engineer, LSGD

9656372569

PWO I, Kollam Municipal
Corporation
PWO I, Kollam Municipal
Corporation
PWO I, Kollam Municipal
Corporation
PWO I, Kollam Municipal
Corporation
PWO I, Kollam Municipal
Corporation

Chief Engineer (BOTProjects), KTDFC
Lecturer, Marian
Engineering College

Senior Architect, L&T
29

Sherin Joseph

Global Engineering
Services

30

Mercy Star
Parimalam

Aparna Sathish

Manager, L&T Global
Engineering Services

32

Shailaja S

33

Radhamohan P K

9447334860

9446256442

9847047161

9349892031

9446007571

srjnavakumar@gmail.com

9446750083

anithanavakumar@yahoo.com

9841075367,
044-22433905

044-22337034

Services
Assistant Engineering

31

9446112813

Senior Architect, L&T
Global Engineering

Senior Manager (Utilities),
SFS

manojmahapatra@federalbank.co.in

9952016524,
044-22337027

9847741546

Secretary, Payyannur

04985-

Municipality Corporation

2202067

bijishanti@gmail.com

sherin.joseph@Lnties.com

MERCY.PERIMALAM@LNTIES.CO
M

aparna.sathish@LNTies.com

shailaja@sfstvm.com

secpynr@gmail.com

<!-- page 17 -->

Secretary, Koothuparambu

34

Vinayan K P

35

Radhakrishnan P

36

Vijayakumar A

37

Liya E

Assistant Engineer, LSGD

9447696866

38

Indu R

Chief Engineer, KSRTC

944707193

39

Rajendra Babu K

AEE, KSPCB

9446557504

Municipality Corporation
Secretary, Thaliparambu

9447964037,

Municipality Corporation

0460-2205340

Secretary, Varkala
Municipality Corporation

0470-2609358

secthaliparamba@gmail.com

secyvarkala@yahoo.com

Assistant Professor, Govt.
40

Anilkumar P S

Engineering College,

9847302217

Thrissur
41

Sathish K

Secretary, NGO TVM

0471-2435207

Dr. Venugopal Reddy
42

S

43

Kannan K

44

Rdhakrishnan P

45

Chandra Shekaran K
G

9497758595

G M, Voltech Global
Trading (P) Ltd, Chennai

9566002303

Advisor, Voltech Global
Trading (P) Ltd, Chennai
Consultant

46

Sunilkumar B

Lecturer, TKM College

9387313924

beesunil@gmail.com

47

Bismi Mani

AE, LSGD

9895830032

bismimani@gmail.com

48

Shobana Kumari

9447795388

Sobha.maniveena@gmail.com

49

Rose Milan Daniel

AE, LSGD

9497781492

50

Elizabeth A Baby

AE, LSGD

9496252395

51

Joy Ashok

AE, LSGD

9447961947

52

Radhakrishnan Nair

AE, LSGD

9446564113

53

Ashraf Khan

AE, LSGD

9387778886

54

Gopakumar V S

AE, LSGD

9447245862

55

Vinod M K

AE, LSGD

9895192550

56

Dileep M S

Assistant Executive
Engineer, LSGD

Assistant Executive
Engineer, LSGD

9497568277

khansetagon@yahoo.co.in

Vinod.m.krishnan@gmail.com

<!-- page 18 -->

57

Antony M Vattoly

58

Ajith Kumar G S

59

Krishnankutty N

60

Arun T S

AE, LSGD
Assistant Executive
Engineer, LSGD
BI, Corporation of Kochi
Public Relations Officer,
High Court of Kerala

9447577020
9446968050
9995522616
04842562020,
9447090134

General Manager, KSIDC

9847064348,

Ltd.

0471-2318922

61

Krishnamoorthy T A

62

Padmakuar R D

63

Beena Philipose

64

Sudhamony S V

65

Sreedevi R

66

Rajeev Kumar K

Executive Engineer, KSEB

9447124847

67

Sheeja T C

Executive Engineer, KSEB

9446008970

68

Salim M

Executive Engineer, KSEB

69

Sreekumar K

Assistant Engineer, KSEB

70

Abdul Malik K V

71

Anil Kumar P

72

Isha P A

Deputy Chief (Projects),

khcpro@rediffmail.com

krishnamoorthy@ksidc.com

9446551260

rdpadma@gmail.com

DGM, HUDCO Ltd.

9446810860

beena.philipose@gmail.com

Assistant Executive

9745180779,

Engineer, KSEB

0471-2514282

HUDCO Ltd.

Assistant Executive
Engineer, KSEB

Deputy Town Planner,
Town Planning Department
Town Planner, Town
Planning Department
Deputy Town Planner,
Town Planning Department

9495975238

944652712,
0471-2514282
9447696479

sreekseb@gmail.com

9447193838

kvmalik69@gmail.com

9496412181

anilkumarp111@gmail.com

9846247448

ishahaneef@gmail.com

<!-- page 19 -->
