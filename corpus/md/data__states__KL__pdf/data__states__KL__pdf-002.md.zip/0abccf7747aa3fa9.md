---
doc_id: "0abccf7747aa3fa9"
source_url: "https://lc.kerala.gov.in/sites/default/files/inline-files/document%20-%202026-02-03T151138.869_1.pdf"
ministry: "Labour Commissionerate, Kerala"
title: "Minimum Wages-Employment in Online delivery Service in schedule-Preliminary Notification-reg"
date: ""
pages: 2
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "13d1b743941b9b63"
---

<!-- page 1 -->

[
൭ ആ KERBIL/2012/45073
കേരള സര്‍ക്കാര്‍ Os ഞു) fated 05-09-2012 with RNI
Government of Kerala | ഗ്ല vals Reg No.KL/TV(N)/634/2021-2023
കേരള ഗസ്റ്റ്‌
Za
KERALA GAZETTE
| അസാധാരണം
EXTRAORDINARY
| ആധികാരികമായി പ്രസിദ്ധപ്പെടുത്തുന്നത്‌
| PUBLISHED BY AUTHORITY
തിരുവനന്തപുരം, 2025 ഒക്ടോബര്‍ 09
ന ന വ്യാഴം 09th October 2025
se 1201 കന്നി 23 സ്ര 3602
Vol. XIV Thiravan 23rd Kani 1201 °
iruvananthapuram, _
Thursday 1947 ആശ്വിനം 17
17th Aswina 1947
GOVERNMENT OF KERALA
Labour and Skills (E) Department
NOTIFICATION
No.LBRD-E1/1/2023-LBRD. Dated, Thiruvananthapuram, 8" October, 2025
22" Kanni, 1201.
WHEREAS, minimum rates of wages has not been fixed under the Minimum Wages Act,
1948 (Central Act 11 of 1948) in respect of the employment in 'Online Delivery Services' in the State;
AND WHEREAS, the Government of Kerala are of the opinion that minimum rates of
wages shouid be fixed under the Minimum Wages Act, 1948 (Central Act 11 of 1948) in respect of the
employment in ‘Online Delivery Services' in the State;
PRI
Authenticity may be verified through https://compose.kerala.gov.in/ pes na
|
a ee ആത്ത ത്‌ ത്തം അ്തതതത്തത്ത്ത്‌ ആ

<!-- page 2 -->

’
2 Ss

Now, THEREFORE, in exervise of the powers conferred by section 27 of the said Act, the
Government of Kerala hereby declare their intention to add the Employment in 'Online Delivery
Services' to Part-I of the schedule to the said Act;

Objections or suggestions, if any. in respect of the said proposal which may be received from
any person likely to be affected thereby, \-ithin three months from the date of the publication of this
notification in the Official Gazette, will be :onsidered by the Government. Objections or suggestions, if
any, shall be addressed to the Special Sec retary to Government, Labour and Skills (E) Department,
Government Secretariat, Thiruvananthapurem - 695 001.

By order of the Governor,
SHANAVAS S.,
Special Secretary to Government.
|
aoa | PUBLISHED BY THE SUPERIN TENDENT. OF GOVERNMENT PRESSES me വ re

AT THE GOVERNMENT CENTRAL PRESS, THIRUVANANTHAPURAM, 2025 RE

This is a digitally signed Gazette. Beas ne
Authenticity may be verified through https://compose kerala, gov.in Nene
വ]
