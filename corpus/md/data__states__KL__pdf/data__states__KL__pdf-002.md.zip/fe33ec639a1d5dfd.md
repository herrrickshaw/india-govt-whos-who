---
doc_id: "fe33ec639a1d5dfd"
source_url: "https://www.kase.in/assets/admin/notificationattach/notify_177998559.pdf"
ministry: "Kerala Academy for Skills Excellence (KASE), Kerala"
title: "Download Attachment"
date: ""
pages: 6
method: "pdftotext"
script: "MALAYALAM"
needs_ocr: false
sha1: "0ed9e2fbe54e97ae"
---

<!-- page 1 -->

KASE/279/2025-OM

I/1820368/2026

േകരള അ ാദമി േഫാർ

ിൽസ് എ ലൻസ്

സം ാന ൈന ണ വികസന മിഷൻ & ിൽ െസ റിേയ ്
ഔേദ ാഗിക വിലാസം◌ഃ
ാം നില, കാർ ൽ ടേവ ്, വ ത ാട്

ക േ ഷൻ േനാ ീസ്
ക േ ഷൻ ന ർ: KASE/279/2025-OM
തീയതിഃ 11-03-2026
വർ

ി െട േപര്◌ഃ Supply and Installation of 65" Interactive Panel at KASE HQ

േകരള അ ാദമി േഫാർ ിൽസ് എ ലൻസിെ െഹഡ് ക ാർേ ിൽ വർ ി
ഓഫീസിേല ് 65"
Interactive Panel (Supply and Installation) െച
തിനായി Original Equipment Manufacturers/Authorized
Partner െ പ ൽ നി ം ക േ ഷ കൾ സ ീകരി
. അ ബ ം 1 ആയി േചർ ി
Specifications
ഉ Interactive Panel ആണ് ആവശ
ത്. െതരെ
െ
ഏജൻസി വർ ് ഓർഡർ ലഭി ് 7
ദിവസ ി
ിൽ specification കാര
Interactive Panel, KASE െ HQ ൽ എ ി ് വർ ന
മമാേ
താണ്. അ ബ ം 2 ആയി സമർ ി ി
േഫാർമാ ിൽ ആണ് ക േ ഷൻ സമർ ിേ
ത്.
അ ബ ം 3 ആയി സമർ ി ി
േഫാർമാ ിൽ OEM/Authorised Partner ആെണ ് െതളിയി
തി
േരഖകൾ സമർ ിേ
താണ്. അ ബ ം 4 ആയി സമർ ി ി
േഫാർമാ ിൽ സർ ീസ് െസ കൾ
സംബ ി വിവര ൾ ടി സമർ ിേ
താണ്.
മാേനജിങ് ഡയറ ർ

<!-- page 2 -->

KASE/279/2025-OM

I/1820380/2026

അ ബ

ം - 1 65" Interactive Panel െ Specification

1

Screen Size (Diagonal) 65"

2

Response Time (G to
G)
8ms

3

Aspect Ratio

16:09

4

Display Dimensions

1709 x 1020 x 88 mm

5

Resolution

3840 x 2160 (4K UHD)

6

Refreshing Frequency 60HZ

7

Display Color

1.07(10 Bit)

8

Contrast Ratio

1,200:1 & Dynamic Contrast Ratio : 5,000:1

9

Viewing Angle (H x
V)

178 x 178

10

Back Light Unit

DLED (IPS LCD)

11

Brightness with Glass
(NITS)
440nit(w/o Glass, max),

12

Life Time

30000 hrs min & Max 50000 Hrs

Essential Features

Including Note application for Whiteboard
functionality, Annotate, Stopwatch, Spotlight Screen
Capture, Screen Recording, Screen Share, Browser,
PIP, Multiwindow Screen, Remote Monitoring on
Cloud using DMS Cloud Solution

14

Screen Glass

Zero Bonding Toughened Glass Technology

16

Touch Tool

Finger, Passive Infrared Pen

Touch

Max 40 points (Windows),
Max 20 points (Android)

18

Processor

CPU Quad Core A55 & GPU Mali G52MP2

19

RAM

8GB

20

Flash Drive

64GB

System

Windows 7/8/10/Linux/Mac/Android, (Linux/Mac
Support one point touch)

22

Surface Hardness

3T(Anti-Glare)

23

Output Power - Audio 15W x 2

24

HDMI In

3

25

HDMI Out

1

13

17

21

<!-- page 3 -->

KASE/279/2025-OM

I/1820380/2026

26

USB 2.0

1

27

USB 3.0

4

28

Touch Port

2

29

VGA IN

1

30

Audio IN

1

31

Audio Out

1

32

RS 232

1

33

RJ45 IN

1

35

Bluetooth

Bluetooth 5.0

36

Wi-Fi

802.11a/b/g/n/ac/ax (WiFi 6)

37

Ethernet

Gigabit LAN

38

Power Cord

1 x 3 Meter Cable

39

USB A to B Cable

1 x 5 Meter Cable

40

HDMI Cable

1 x 3 Meter Cable

41

USB C Cable

1 x 3 Meter Cable

42

Wall Mount

1

43

Writing Pen

2

44

Remote Control

1

45

Operation
Temperature

0 °C to 40 °C

46

Operation Humidity

10% to 90%

47

Power Supply

100V-240V

48

Power Consumption

225 W Typical/ 430W Max

49

Net Weight

47.3 kg

50

Warrantty

5yrs

<!-- page 4 -->

KASE/279/2025-OM

I/1820381/2026

അ ബ

ം2(

ാപന

ിെ െല ർ െഹഡിൽ സമർ ി ണം)

11-03-2026 െല KASE/279/2025-OM ന ർ ക േ ഷൻ കാരം ആവശ െ specification അ സരി
65"
Interactive Panel നൽ
തിന് Original Equipment Manufacturer(OEM)/Authorised Partner ആയ
( ാപന ിെ േപര്) വെട പരാമർശി ി
ക ് ക േ ഷൻ േനാ ീസിെല നിബ നകൾ അംഗീകരി ്
ക േ ഷൻ സമർ ി
.
മ നം Supply െച
സാധന
1
65” Interactive Panel
GST
Total

െട വിശദ വിവര ൾ

ക

അധികാരി െട േപര്
ഒ ്

<!-- page 5 -->

KASE/279/2025-OM

I/1820383/2026

അ ബ
െതളിയി

ം 3 - Original Equipment Manufacturer അെ
തി
സത വാ ലം

11-03-2026 െല KASE/279/2025-OM ന ർ ക േ ഷൻ സമർ ി ി
Equipment
Manufacturer/Authorised
(ബാധകമ ാ ത് െവ ികള ക) ആെണ ് സാ െപ
.

* Original Equipment Manufacturer ആെണ ിൽ സ യം സാ

െ

ിൽ Authorised Partner ആെണ ്

(

ാപന

സാ

െ

ിെ

േപര്) Original
Partner**

ിയ ആളിെ േപര്
ഉേദ ാഗ/ ാനേ ര്
ഒ ്
ാപന ിെ സീൽ

ിയാൽ മതിയാ ം.

** Authorised Partner ആെണ ിൽ Original Equipment Manufacturer െട സർ ിഫി േ ാ, അ ബ
കാര
സർ ിഫി േ ാ സമർ ിേ
താണ്.

ം3

<!-- page 6 -->

KASE/279/2025-OM

I/1820385/2026

അ ബ ം 4 - തി വന രം ജി യിെല അംഗീകൄത സർ ീസ് േക
( ാപന ിെ െല ർ െഹഡിൽ സമർ ിേ
താണ്)
മ നം അംഗീ ത സർ ീസ്
േക
ിെ േപര്

അംഗീ ത സർ ീസ്
േക
ിെ വിലാസം

െട വിവര ൾ
ഇെമയിൽ േഫാൺ ന ർ

1
2
3

ാപന േമധാവി െട േപര്
ഒ ്
ാപന

ിെ സീൽ
