---
doc_id: "6dbdaced96fed82b"
source_url: "https://www.gecidukki.ac.in/upload/27_07_2024_1722097231.pdf"
ministry: "Goverment Engineering College Idukki, Kerala"
title: "Instructions and Fees details"
date: ""
pages: 2
method: "tesseract:mal+eng"
script: "MALAYALAM"
needs_ocr: false
sha1: "d59080c779accc5c"
---

<!-- page 1 -->

7 $1 GOVERNMENT ENGINEERING COLLEGE,
g Fis OR IDUKKI. PAINAVU - 685 603
gi ലം Phone. No. 04862 233250 Fax No. 04862 - 232477
& ae Website. www.gecidukki.ac.in E-mail: info@gecidukki.ac.in
ബി1/3218/2023 27/07/2024

ബി.ടെക്‌ ലാറ്ററല്‍ എന്‍ട്രി ഡിഗ്രി കോഴ്‌സ്‌ അഡ്മിഷന്‍ 2024

പ്രവേശനം ലഭിച്ച വിദ്യാര്‍ത്ഥികള്‍ 29/7/2024, 30/7/2024, 31/7/2024
തീയതികളില്‍ 9.30 AM ന്‌ റിപ്പോര്‍ട്ട്‌ ചെയ്യേണ്ടതാണ്‌. കൂടാതെ താഴെ
തന്നിരിക്കുന്ന ലിങ്ക്‌ സന്ദര്‍ശിച്ച്‌ വിദ്യാര്‍ത്ഥികള്‍ അവരുടെ പ്രൊഫൈല്‍
രജിസ്റ്റര്‍ ചെയ്യേണ്ടതാണ്‌. യോഗ്യത തെളിയിക്കുന്ന സര്‍ട്ടിഫിക്കറ്റുകളും
അവയുടെ സാക്ഷ്യപ്പെടുത്തിയ പകര്‍പ്പുകളും പ്രവേശന സമയത്ത്‌
ഹാജരാക്കേണ്ടതാണ്‌.

പ്രവേശന സമയത്ത്‌ സമര്‍പ്പിക്കുന്ന സര്‍ട്ടിഫിക്കറ്റുകളുടെ
ആവശ്യമായ പകര്‍പ്പുകള്‍ വിദ്യാര്‍ത്ഥികള്‍ കൈവശം
സൂക്ഷിക്കേണ്ടതാണ്‌.

+ പ്രവേശന. സമയത്ത്‌ വിദ്യാര്‍ത്ഥിയോടൊപ്പം നിര്‍ബന്ധമായും
രക്ഷിതാവ്‌ ഉണ്ടായിരിക്കേണ്ടതാണ്‌.

+ അഡ്മിഷന്‍ സമയത്ത്‌ ഒടുക്കേണ്ട ഫീസുകളുടെ വിവരങ്ങള്‍
ഇതോടൊപ്പം നല്‍കുന്നു. എല്‍.ബി.എസ്‌ ല്‍ ഫീസ്‌ അടച്ചവർ
ബാലന്‍സ്‌ ഫീസ്‌ ഈ സ്ഥാപനത്തില്‍ അടക്കേണ്ടതാണ്‌.
(അഡ്മിഷന്‍ സമയത്ത്‌ കോളേജില്‍ ഒടുക്കേണ്ട പി.റ്റി.എ
ഫീസിന്റെ വിവരങ്ങളും, ലേഡീസ്‌ ഹോസ്റ്റല്‍ സംബന്ധിച്ചുള്ള
ഫീസ്‌ വിവരങ്ങളും ഇതോടൊപ്പം നല്‍കിയിട്ടുള്ളതാണ്‌.)
പ്രവേശന സമയത്ത്‌ അപ്‌ ലോഡ്‌ ചെയ്ത എല്ലാ രേഖകളുടെയും  —

ഒറിജിനല്‍, അലോട്ട്‌മെന്റ്‌ മെമ്മോ, സ്കോര്‍ കാര്‍ഡ്‌, മെഡിക്കല്‍
സര്‍ട്ടിഫിക്കറ്റ്‌, Transfer Certificate & Conduct Certificate, 2 പാസ്പോര്‍ട്ട്‌
സൈസ്‌ ഫോട്ടോ എന്നീവ കൊണ്ടുവരേണ്ടതാണ്‌. പ്രോസ്പെക്റ്റസ്‌ ക്ലോസ്സ്‌
13. പ്രകാരമുള്ള രേഖകള്‍ അഡ്മിഷന്‍ സമയത്ത്‌ നിര്‍ബന്ധമായും
ഹാജരാക്കേണ്ടതാണ്‌. നോണ്‍ ക്രിമിലെയര്‍/ ജാതി/ ഇ.ഡബ്ലു.എസ്‌/
വരുമാന സര്‍ട്ടിഫിക്കറ്റ്‌ ബാധകമെങ്കില്‍, കാലാവധിക്കുള്ളില്‍
തന്നെയുള്ള സര്‍ട്ടിഫിക്കേറ്റുകള്‍ കൊണ്ടുവരേണ്ടതാണ്‌.

<!-- page 2 -->

Part1
Si.No | ITEM GENERAL | ST/OEC/SC | MODE OF
PAYMENT
3160 a
2__| Admission Fee | 240 |
3 Special Fee (R 1740
4 | Special Fee (PD) 370 [| |
5 [Caution Deposit | 1000 | 1000 _|
6 University Fee 2330 On line
mode
(Administration Fee-
1050,Sports and Arts
fee-530, Affiliation
fees-750)
ea ജാ | അഃ |
|
Part 2
റ Bus Fee 4000 4000 Online
Mode
Ladies Hostel Fee
Admission Fee (Only
at the time of |
admission Online
| 2 [Rent/Semester 1860 Mode
3 | HDF/Semester 750
PTA & OTHER FEE
ITEM GENERAL SCISTIOEC/
Category Rs. Rs.
ra [renews |e [me
ref rann | ef
DEVELPOMENT FUND Online
ps | corcree | te | tm
a ae
(s 7 “SON പിരി ളി
of ആ 11:11:
CANS Lae eg
രാ
