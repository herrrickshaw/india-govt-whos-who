---
doc_id: "c5feaeca5249f5ea"
source_url: "https://www.cet.ac.in/wp-content/uploads/2025/06/JRF_Notification_CET_ECE.pdf"
ministry: "College of Engineering Trivandrum, Kerala"
title: "Applications are invited for the positions of Junior Research Fellows (JRFs) /Project Associate in sponsored project of Ministry of Electronics & Information Technology (MeitY)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "46cc9c31a961ceb3"
---

<!-- page 1 -->

COLLEGE OF ENGINEERING TRIVANDRUM
Thiruvananthapuram, Kerala PIN 695016
Email: cettvm@cet.ac.in

Dated: May 31, 2025
Applications are invited from highly motivated candidates for the positions of Junior
Research Fellows (JRFs) /Project Associate in sponsored project of Ministry of
Electronics & Information Technology (MeitY) under Chip to Startup (C2S) initiative for
the project entitled “A SHAKTI CPU based Smart Vision System on Chip (SoC)" to
be implemented jointly by College of Engineering Trivandrum and M/s Netrasemi Private
Limited, Thiruvananthapuram.
1. Name of Position: Junior Research Fellow/Project Associate.
2. Duration: One year. The initial appointment is for a period of one year and may be
extended based on project requirements. The position is purely temporary and coterminus with the project.
3. Emoluments: Consolidated pay of ₹37,000/- for Junior Research Fellow (JRF) and
₹25,000/- for Project Associate.
4. Minimum Essential Qualifications: ● B.E./B.Tech. in CSE/IT/ECE/allied branches
+ GATE or equivalent examination qualification. OR ● M.E./M.Tech. in
CSE/IT/ECE/allied branches + GATE or equivalent examination qualification.
Note: Non-GATE applicants are eligible to apply for the position of Project Associate.
5. Age limit: 30 years (5 years relaxation for female/SC/ST/ Physically Handicapped, 03
-years for OBC-NCL Candidate or as per GoI norms)
6. Last date of receiving the application: 09/06/2025.
Desirable skills: Strong knowledge in RTL coding, computer architecture, SoC design,
testing and debugging, and back-end flow. Experienced in ASIC/FPGA implementation
(preferably FPGA), with proficiency in programming languages such as Verilog, VHDL,
C, and C++, as well as scripting languages/tools like Python, Perl, and Shell for design
and test automation. Familiar with industry-standard process lifecycles.
How to apply?
Please send your resumes to sreelathag@cet.ac.in.
