---
doc_id: "deaaf0311fbf329b"
source_url: "https://www.handicrafts.kerala.gov.in/images/tender/Qts_Kottayam_24-9-26.pdf"
ministry: "Handicrafts Development Corporation of Kerala Limited, Kerala"
title: "കേരള കരകൗശല വികസന കോർപ്പറേഷൻ ചുവടെ ചേർക്കുന്ന പ്രവത്തികൾക്ക് പരിചയ സമ്പന്നരായ വൃക്തികൾ/സ്ഥാപനങ്ങളിൽ -നിന്നും ക്വട്ടേഷൻ ക്ഷണിക്കുന്നു. 1. Name Board & lumination, 2. Spot light with rail ,3. Air Conditioner & Invertor എന്നിവ സ്ഥാപിക്കുന്നതിലേക്കുള്ള ഇലെക്ട്രിക്കൽ പണികൾ"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "141af37be743ca1d"
---

<!-- page 1 -->

Handicrafts Development Corporation of Kerala Ltd.
Kairalıj

(AGovt. of Kerala Undertaking)

Kegd Ofice: Post Box No, 171i.Puthenchanthai, Near Govt. Segetariat, Thiruvananthapuralm,
Phone: 0471-2331358/2778400 Email:hdckerala @gmail.com
Website: www.handicrafts.kerala.gov.in

TENDER ID: HDCKIP&A/TENDERI2026-27

23-09-2026

GbOgAOADUOAilemm
JaKÕoolos Gaổ :
Dam CSl G»Jogld
1.

gsoolů, AoADUOE

gGgolesBM

66)Ab0

Name Board & lumination

2. Spot light with rail

3. Air Conditioner & Invertor agmk munonlesTpolsesg DOeIAles lmlb8
lGgMCỔOlGoleam GOOITUOm okooo mODQo -30.09.2026 66IAGMMOO

4 D6mlQNOO.

iCŞoHTÖ 9OBM oloolo UDDQJ: - 30.09.2026 6906DOo 4:30 MSrl.

Ga0960 :0471-2331358,2T78400

Managipg Directo
