---
doc_id: "e82fe9aef6f8ac83"
source_url: "https://gecskp.ac.in/pdf/Guideliens_Four_Funds.pdf"
ministry: "Government Engineering College Palakkad, Sreekrishnapuram, Kerala"
title: "Guidelines for Funds"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "13e70738dc2d99e1"
---

<!-- page 1 -->

GOVERNMENT ENGINEERING COLLEGE PALAKKAD, SREEKRISHNAPURAM
Selected under Sub Component 1.1
Technical Education Quality Improvement Programme Phase II
GUIDELINES FOR THE EFFECTIVE UTILISATION OF FOUR FUNDS
1. SUMMARY OF AVAILABLE FOUR FUNDS AND ITS UTILISATION
Corpus fund










Conducting BoG meetings -minimum two in each year
Salary expenses of contract staff in the post clerk cum Accountant (One post) as per
Government norms.
TEQIP Office Expenses
TA/DA for attending meetings(deputed by the Principal)
Hiring professional services for TDS filing, financial auditing
Student Support activities.
Conducting high intensity training (of at least 2weeks duration) for student development of
soft and professional skills.
Presenting papers in Conferences / Seminars.
One day Industrial visit, placement related activities etc. under IIIC

Faculty Development Fund





Expenditure on faculty members attending training in subject domain
Expenditure on organizing in-house subject area training Programs, Workshops/
seminars/symposium /conferences.
Expenditure on participation by faculty in Seminar/ Conferences/ workshop, etc.
Expenditure on short term programs with industry.

Equipment Replacement Fund
 Replacement of obsolete furniture and equipment including computers and related devices.
 Upgradation of software purchased under TEQIP-II.
Equipment Maintenance Fund
 Maintenance of furniture and equipment including computers and related devices.
 Purchasing of consumables for the training activities in connection with the TEQIP
Equipment.
 AMC and repair for items procured under TEQIP II

2. GUIDELINES FOR THE CONDUCT OF FSD PROGRAMMES USING FOUR FUNDS
2.1 In-house Program
1. The program proposal with the activity plan and brochure must be submitted through the
department, with clear recommendations indicating the experts, expected benefits and beneficiaries
of the program. The program proposal will be verified and approved by the Academic committee
and Finance Committee before submitting to the BoG for approval/ratification. The decision of the
BoG will be final.
2. The minimum qualification of experts for the programs will be (i) PhD/M Tech for those from
academic institutions and (ii) For resource persons from industries: designated as Manager or above
in the working industry or has minimum 5 years of industrial experience in the related area with
basic engineering degree OR (iii) a distinguished professional as recommended by the Academic
committee. However, the academic committee can decide the qualifications/experience judiciously
for the academic and industrial experts wherever necessary, subject to the ratification of BoG.

<!-- page 2 -->

3. The TA/DA for experts will be as per GoK/TEQIP-II norms.
4. In case of Revenue Generating Programs, 20% of the IRG generated will be paid as remuneration to
the coordinator of the program subject to a maximum of Rs.5000/- per program (of minimum three
days duration).
5. Settlement of the programs must be done within 3 weeks by the coordinator; failing interest will be
levied from the coordinator as per the Government of Kerala (GoK) rules.
6. It is desirable that at least 50% of the participants of the programs are from other institutions. The
fee to be collected can be fixed by the coordinator and the department, with approval from academic
committee.
2.2 External Programs
1. Importance of course should be scrutinized by concerned departments. (Justification by HoD/
Department Committee needed)
2. The faculty deputed for the program has to conduct an in-house program on the subject area in
which he/she received training or assist in purchasing equipment for the department lab in the area of
specialization or guide the students in doing projects under TEQIP or schemes like DST/CERD, etc.
3. While selecting courses, courses from premier institutions shall be preferred. Academic Committee
has to evaluate the relevance of the program and give directions on how the course can be made
beneficial for other faculty and staff in the institution.
4. Settlement of the programs must be done within 3 weeks of completion of the programme by the
faculty/staff deputed, failing which, interest will be levied from the faculty/staff deputed as per the
Government of Kerala (GoK) rules.
5. The Faculty/Technical/Administerial staff will be permitted to attend an external program, if the
department strongly recommends the program stating the benefits to the students, department and the
institution.
6. The maximum number of participants for a particular program from the institution is limited to two.
7. The number of programs that can be attended by a faculty is limited to one per semester and by a
staff to one per annum. However, in cases when a faculty/staff is deputed by the institution under
special circumstances, that course is not counted to the number of permissible courses.
8. The total expenditure including registration fee, TA/DA for attending program etc per program using
Faculty development fund is limited to Rs.10,000/- for faculty and Rs.7,000/- for staff.
9. Air journey will be permitted to eligible faculty, only if the Principal and Finance committee
recommend based on fund availability considering the nature of the program/meeting to be attended,
intimating to the BoG Chairman for endorsement. Final approval will be given only after obtaining
the ratification of the subsequent BoG.
10. The faculty will be permitted to present papers in reputed conferences using the faculty development
fund, with the approval of R & D Committee. The support received from TEQIP-II FOUR FUNDS
must be acknowledged in the paper presented. Only oral presentations in the conferences will be
funded. The citation of the institution in the paper is mandatory for this funding.
11. The TA/DA for the faculty and staff to attend programs will be as per GoK rules and subject to the
actual produced. The room rent for the faculty/staff are limited as follows considering the shortage
of fund.
Grades
Metro cities
Other cities
(In rupees)
(In rupees)
Grade 1
1500
1000
Grade II (a)
1500
1000
Grade II (b)
1000
750
Grade III
1000
750
Grade IV
750
600

<!-- page 3 -->

3. GUIDELINES FOR THE CONDUCT OF STUDENT SUPPORT PROGRAMMES
Remedial/Bridge Course, Students Training Programs, Internship, Conference, etc.
1. The remedial class shall be offered by a faculty other than the one who taught the subject. However,
exemption in this regard may be given by the committee in special cases.
2. The number of students in a class getting benefitted using remedial classes should be at least15% of
the class strength. However, the EAP committee can make a judicious decision, based on the
recommendations of the HoD wherever the number of students is less, subject to the ratification of
BoG. The attendance of students enrolled for the program must be compulsory and monitored by the
HoD.
3. The department has to monitor the results of the benefitted students and the HoD has to submit a
report to the TEQIP office as and when the results are published.
4. Bridge courses may be conducted in mathematics for Lateral Entry (LET) students, subject to a
maximum of 10 hours.
5. External subject experts can be hired for conducting remedial / bridge classes at Rs.600/hour, if
found necessary. For internal experts the amount is limited to Rs.500/hour. No TA/DA will be
admissible for the experts.
6. Remedial classes shall be arranged only for helping the students in understanding difficult topics,
which was already covered by the Instructor. The maximum number of remedial hours is limited to
15% of the total number of hours as per the university curriculum.
7. Counseling experts can be invited to the campus for interacting with needy students under this
scheme. The remuneration payable for the experts is as per FSD norms. The expert TA/DA will be
as per GoK/TEQIP-II rules and as per the norms under FSD program. The expert selected must be a
reputed person with a minimum experience of 5 years in the area of counseling. However, the EAP
committee can make a judicious decision on the experience of the expert available and recommend
to the Principal. The effectiveness of the program should be reported to the TEQIP office for every 6
months, by the program coordinator.
8. Coaching classes for appearing in competitive examinations like GATE, CAT, MAT, etc can be
conducted subjected to a maximum of 20 hours per branch per year, recommended by EAP
committee.
9. Students attending reputed conferences for oral presentation can be funded through this scheme. The
maximum amount payable is Rs. 2000/-. The support received from TEQIP-II FOUR FUNDS must
be acknowledged in the paper presented. The citation of the institution in the paper is mandatory
for this funding.
10. A paper published, from the project work done in the institution, in an SCI index journal may be
awarded an amount of Rs. 5000/- to the faculty subject to the recommendation of the R &D
Committee and approval of BoG.
11. Training programs / workshops from industries, placement related training programmes may be
conducted by the approval of the III Cell committee and the subsequent approval of BoG. For
training programmes/workshops from industries, The expert should be an engineering graduate with
minimum five years experience or a post graduate with three years experience in the relevant area.
12. High intensity skill development programs (a minimum of two weeks duration) for development of
soft and professional skills can be conducted. The IIIC committee has to decide judiciously and
recommend the program for approval of the Principal and intimate the same to the BoG chairman.
Final approval will be given subject to the ratification of subsequent BoG.
13. Financial support may be granted to a maximum of two R & D projects in each department, with the
recommendation of the HoD and approval from R&D committee. The permissible support will be
decided by the committee, subject to a maximum of Rs.5000/- as seed money per project.
14. Industrial visit to Govt. /Semi Govt. /Public Sector/Premiere private industries will be funded based
on the recommendations of the department, IIIC and the finance committee. Only the days of
industrial visit will be considered for funding subject to a maximum of Rs.5000/- per batch (of
minimum 10 students).
