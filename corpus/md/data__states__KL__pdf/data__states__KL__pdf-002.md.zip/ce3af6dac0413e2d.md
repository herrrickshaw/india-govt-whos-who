---
doc_id: "ce3af6dac0413e2d"
source_url: "https://www.cethalassery.ac.in/files/eoa/Provisionalorder_45-2022-23.pdf"
ministry: "College of Engineering Thalassery, Kerala"
title: "Download"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "171b6e7ae6e8ce47"
---

<!-- page 1 -->

APJ ABDUL KALAM TECHNOLOGICAL UNIVERSITY
CET Campus, Thiruvananthapuram -695016
Ph:0471 2598122, Fax: 2598522 www.ktu.edu.in Email:university@ktu.edu.in

Provisional Affiliation/Extension of Provisional Affiliation of UG / PG courses for the Academic Year 2022
- 2023 in COLLEGE OF ENGINEERING, THALASSERY , Eranholi P.O. KANNUR - Orders Issued.

ADMINISTRATION SECTION
No: KTU/A/456/2015

Dated, Thiruvananthapuram,30/08/2022

Read:1.

Application of COLLEGE OF ENGINEERING, THALASSERY in the e-governance platform of APJ Abdul
Kalam Technological University, seeking Provisional Affiliation/Extension of Provisional Affiliation of
Engineering Courses.

2.

APJ Abdul Kalam Technological University Act 2015 (Act No.17 of 2015).

3.

APJ Abdul Kalam Technological University First Statutes, 2020.

4.

Affiliation Manual of the APJ Abdul Kalam Technological University.

5.

Notification No.KTU/A/456/2015 dated: 11/07/2022

ORDER
st

The, COLLEGE OF ENGINEERING, THALASSERY vide paper read as 1 above submitted an application
seeking affiliation/extension of affiliation of courses for the Academic Year 2022 - 2023.
st

The application submitted by the institution vide reference read as 1 above seeking affiliation of courses
approved by the All India Council for Technical Education (AICTE) for the Academic Year 2022 - 2023 and the
College has satisfied the conditions for provisional affiliation / extension of provisional affiliation stipulated in the
papers read (2) to (5) above.

In the above circumstances, sanction is hereby accorded in accordance with the provisions contained in the
APJ Abdul Kalam Technological University Act and the Statutes thereunder for the conduct of the following courses
as per the details shown alongside for the Academic Year 2022 - 2023.

No

Program Type

Level

Branch/Stream

Approved
Intake

1

Engineering and
Technology

UG

INFORMATION TECHNOLOGY

60

Page No: 1

Full/Part
Time

NRI

Full Time No

FN/Gulf
Quota
/OCI

No

<!-- page 2 -->

2

Engineering and
Technology

UG

ELECTRONICS &
COMMUNICATION ENGG

120

Full Time Yes

No

3

Engineering and
Technology

UG

ELECTRICAL AND
ELECTRONICS ENGINEERING

60

Full Time Yes

No

4

Engineering and
Technology

UG

MECHANICAL ENGINEERING

60

Full Time Yes

No

5

Engineering and
Technology

UG

COMPUTER SCIENCE &
ENGINEERING

60

Full Time Yes

No

6

Engineering and
Technology

UG

CIVIL ENGINEERING

60

Full Time Yes

No

The provisional affiliation shall be for the academic year 2022 - 2023 or till further orders of the University.The
provisional affiliation/extension of affiliation granted above, is subject to the verification of the compliance of the
provisions in references 1, 2 and 3 by the University or its competent bodies/authorized officers at any time during
the Academic year 2022 - 2023 and subject to the following conditions.

1. Verification of facts submitted by the institution in the e-Governance platform by the University.

2. The Institution shall observe the provisions in the APJ Abdul Kalam Technological University, APJ Abdul Kalam
Technological University First Statute, 2020 the norms and standards prescribed by the AICTE / Council of
Architecture and the guidelines issued by the University from time to time.

3. Strict compliance of Anti-Ragging Regulation notified vide F.No.37-3/Legal/AICTE/2009 Dated July 1,2009 for
Prevention, and Prohibition of Ragging in Technical Institution /UGC regulations. In case institution fails to take
adequate steps to prevent Ragging or fails to punish perpetrators or incidents of Ragging, it will be liable to take
any action as defined under clause 9(4) of the said Regulation.

Non -compliance with any of the conditions will result in the withdrawal of the affiliation
without any notice.

Sd/Dr.A Praveen *
Registrar

To,

1. The Principal, COLLEGE OF ENGINEERING, THALASSERY,Eranholi P.O. KANNUR.
2. The Chairman/Secretary, Co-operative Academy of Professional Education,CO BANK TOWERS,VIKAS

Page No: 2

<!-- page 3 -->

BHAVAN Po THIRUVANANTHAPURAM.
3. PS to Honble Vice Chancellor.
4. PS to Honble Pro Vice Chancellor.
5. The Secretary, Higher Education Department, Govt Secretariate, Govt of Kerala.
6. The Commissioner for Entrance Examinations, Housing Board Jn, Thiruvananthapuram.
7. Member Secretary, AICTE, New Delhi.
8. PA to Registrar, Dean (Academic), Dean (Research), CoE, FO.
9. Academic Section.
*** This is a computer system generated letter. Hence there is no need for a physical signature.

Page No: 3
