---
doc_id: "035e6dfde6df5adb"
source_url: "https://dhs.kerala.gov.in/wp-content/uploads/2022/06/Post-creation-2nd-phase-FHCs-new-posts-GO-2019.pdf"
ministry: "Directorate of Health Services, Kerala"
title: "കുടുംബാരോഗ്യകേന്ദ്രങ്ങളിലേക്ക് തസ്തികകള്‍ അനുവദിച്ച് ഉത്തരവ്"
date: ""
pages: 29
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9bca8ad6989d98d3"
---

<!-- page 1 -->

di
Campa Cwdmod
(mJownoo)
øOWoThG&i0 C1Ir - 374 ancrOUl mi3n8, 400 c1orT m, 200 Pjomr ØSLdC1
(WöCIbQJG14 m(n8al powaaoce3o-Ta.

CPMcr8 051051W &o6flJOCøO(J)

(t3IOCD&io6flJCôhdZ (ng)o) OJ&3CUJ'

ufkoimnmp0, MI@xu, 14.11.2019

o..(ø&) cn0. 171/2019hni.o3.oi

)mo.98/2019/cm.aoi nlanl 05.07.2019

nJ(b36Ubo 1. m

aup.(cruowo)mo.2151/2019/an?.&.oi ascloxuq 02.09.2019
rro.p.(cr))owa) mo. 2366/2019k3m3.&,.QJ cnxucI 01.10.2019
Y{kn516i do3.6nfl2-

r®ow üJn woqs 31.08.2019
90820/2016/ai.oi.cw cnmnS e

fioi nRny&6Q12-

cow fl!&u cwcoqs 05.11.2019
90820/2016/an.oi.cw mcnic oa,io

ai6s @owoxifl 6b

cgo
mocnMq4 cmcBci

6nJg

400

06m000w

i1c8&)U3 cin4 nJøOthCBUbo

400 cjocr cn, 200 PJO&nI &sIqj(IB nQ)CTfll

1 (J&Oøo (UIU)Cb0JOOfl(B(TTO. SSO6)(ö) ctht(8 1c6)J &6fl140(3, nJOQiI(8 r4flCflil (OLS1&OC(63U)
Gcffio6MCr3 ce cuce,coo a&&0, c&,jpioo rifffl
y&go nU5l6S cO6nW0
nomn
&Jo Tö(0)36)SOr0

2J5(ZWYfl(Z58 nJ(O3(3Uôo 2 l&,Oøo
(w6)(oTo) 6mJQ&cTr'

Q&3Cflt J3LD2i1&3aøOW\

iqjC& nGTho, acrqpo (otooøow c&tio 6miq&3cn5 (co)

nJin)4Cfl5I. n)Cflbo nJøOth(ZUbo 3 (JcD3(öo a(g(3u)6 6Th9 pøaOcDto 6ThJ(O3Cnb. n)Cfl)OC3
63(ö) mqoJoldftB (o6m
ctiim

crtqn' cnio1s araa

500

csm øomeGm.00 BwTacruJ
aiufl
374 rom&j4 mxBt
i&eo

nQ)m møocn OJcO3cLJ cw©o,cZ 0j®oac3ua0 5 caco0
osmomöSB
oW14(ufl6)C
)øØO 0i33fl$I
mAcMA
iflc (mono6nJcru)a3ofl
(UfS1(3 &io6flJOøOCfl c
TO51
(bGfl3Oo
mno0jcn6uiIa 374

n(Jfl6)s
oou

nq'c mx8ci3, 400 cpgond mg, 200 @JOGnr 6)sIno3 nQyIi51

(MVC8)CffiU8 öiociooiift.q,j cn8Ce1 PMOO=63M
(wcw66mQ6s oimoofl08 &o(bo)
øoaS mo0anciT ciojwcnn
cjc&nilp8 ocno1
uibyøow oice4 cwwoc3, a$kmoimcimpo.
(ö6nc'

cncxoB (

ui1çf/n&), Th3oJmnmnjøo.

tti3 & nJ6nfho' 01c9ino8cnY (øoj&nT&cn 1cu) QhOnj
()ncwas3 / 633LflCflY aB39j].
asim®aflc QthOøo

e1d 6)od1croc8

<!-- page 2 -->

S1.No

1
2
3
4
5
6
7
8
9

10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29

30
31
32
33
34
35

Thiruvananthapuram
Posts proposed
Institution
doctors
1
CHC Kattakada
1
Thiruvallom
1
Vettoor
1
Thonippara
1
Madavoor
1
Chettivilakam
1
Chenkal
1
Kulathoor
1
lKarode
1
Chemboor
1
Kollayil
1
Amboori
1
Kallikadu (new)
1
Uzhamalakkal
1
Kuttichal
1
Kallikadu (old)
1
IMukkola (Vizhinjam New)
1
Veli
1
Mudakkal
1
Perumathura
1
Puthukurichi
1
Mangalapuram
1
Peringammala
1
Anakudi
1
Pullampara
1
Panavoor
1
Anad
1
Adayamon
1
Karavaram
1
IPulimath
1
Cheruniyur
1
Vilavoorkkal
1
Maranalloor
1
Vembayam
1
Manikal
Total Posts to be
35
created
Kollam

Sl.No

Institution

1

Munroe Island
Madathara
Pooyapally
Paravur Pozhikkara
Neduvathur

2
3
4
5

Posts proposed
doctors
1
1
1
1
1

<!-- page 3 -->

6
7
8

g
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33

Ezhukcrie
Piravanthur
Mancode Pathanapuram
Thatachira
Melila
Aryancavu .
Edamulakkal
lKaravaloor
Thevalakara
Sakthikulangara
Alayamon
Mancode Chithara
Elamad
Ittiva
IThrikkaruva
Kilikalloor
Kunnathoor
East Kallada
Ezhukone
Pavithraswaram
ISooranadu South
West Kallada
Alappad
Azheekal
Vallikavu
Thodiyoor
jPerayam
Thrikovilvattom
Perinad
Total Posts to be
created

1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
33

Pathanamthitta
SI.
No.

Institution

1

Kunnamthanam
Chittar
Mezhuveli
Omalloor
Naranamoozhy
Ranni Pazhavangadi .
Erathu
Ezhamkulam
Kokkathodu
Mylapra
Seethathodu
Puramattom
Kaviyoor

2
3
4
5
6
7
8
9
10
11
12
13

Post proposed
Doctors

1
1
1
1
1
1
1
1
1
I1
1
1
1

<!-- page 4 -->

14
15

Anicadu
Kuttoor
Total Posts to be
created

1
1

15

Alappuzha
Post proposed
Doctors

SI.
No.

Institution

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32

Cherthala South
Pallithode
Thakazhi
Karthikapally
Karuvatta
Aryad
Thottappally
Purakkad
Punnapra South
Ambalapuzha North
IMararikulam North
Vallethodu
Panavally
Thuravoor South
Kadakkarappally
Thazhakara
Thamarakulam
Bharanikavu
Krishnapuram
Devikulangara
Pathiyoor
Kavalam
Veeyapuram
Ramankari
Kuppapuram
Venmony
Eramallikkara
1130yoor
Mulakuzha
Kadampur
Chingoli
GFD Arattupuzha

1
1
1
1
1
2
1
1
1
1
2
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1

Total Posts to be
created

34

Kottayam
SI.
No.

Institution

1
2
3

Aymanam
Meenadam
Onamthuruthu

Post proposed
Doctors

1
1
1

<!-- page 5 -->

4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20

Nattakom
Kadariadu
Mutholy
Moonilavu
Maravanthuruthu
Udayanapuram
Thalayazham
Parathbdu
Koruthodu
Vellavoor
Vizhikkithodu
Pallickathodu
Kanakkary
Kattamak
Kallara
Velloor
Paippad
Total No of posts to be
created

L
-

1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
20

ldukki
-

S1.No

Institution

1

Kamakshy
Arakkulam
Senapathy
Chembakappara
Thattakuzha
Alakodu
Deviar Colony
Vellathooval
Chinnakanal
Bison Valley
Elappara
Kokkayar
Vazhathopu
Kudayathoor
Total No of Posts to be
Created

2
3
4
5
6
7
8
9
10
11
12
13
14

Posts proposed
doctors
1
1
1
1
1
1
1
1
1
1
1
1
1
1
14

Ernakulam

S1.No

Institution

1

Nettoor
Eloor
Kumarapuram
Udayamperur
Edavannakkadu
Alangad
lChoornikkara
lEdathala

2
3
4
5
6
7
8

Posts proposed
doctors
1
1
1
1
1
1
1
1

<!-- page 6 -->

9
10
11
12
13
14
15
16
17
18
19

Thiruvankulam
Mudakkuzha
Okkal
Parakadavu
Malayattoor
lAyyampuzha
Cheruvattoor
Kottapady
Punnekkad
Kandakadavu
Avoly

1
1
1
1
1
1
1
1
1
1
1

Total No of Posts to be
Created

19

Thrissur
SI.No
1
2
3
4
S
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34

Institution
Patikkad
Nadathara
Vaniyampara
Madakkathara
Ayyanthole
Engandiyur
Orumanayoor
Pookkode
Andathathodu
Parappukkara
Methala
Chowanoor
Perumpilavu
Arthat
Porkulam
Kadangodu
Thaikkad
chamakala
Padinjare Vemballoor
Edavilangu
Nalukettu
Meloor
Vettilappara
Poomala
Adat
Mullurkkara
Kuthampully
Thonoorkara
Vallatholnagar
Elavally
Thrikkur
Varandarapilly
Padiyur
Vellorkkara
Total no of Posts to be
created

Posts proposed doctors
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
34

Palakkad
S1.No

1
2

Institution
Parali
Keralassery

Posts Proposed
1
1

<!-- page 7 -->

3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
21
24
25
26
27
28
29
30
31
32
33
34

Peringottukurissi
Kavassery
Kunissery
Kumbidi
Pattithara
Nallepilly
Perumatty
Elevancherry
Ayilur
Muthalamada
Pallassena
Kannadi
Puthucode
Kottopadam
Thenkara
Kanhjrapuzha
Karakurussy
Mannur
Perur
Pookottukavu
Vaniyamkulam
Vellinezhy
Thrikkadeeri
Marutha road
Puthussery
Mundur
Akathethara
Malampuzha
Muthuthala
Vallapuzha
Kottayi
Kannampara
Total No of posts to be
created

1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
34

Malappuram
S1.No

Institution

1

Vazhakkad
Karulai
Angadipuram
Koottilangadi
Nannammukku
Veliyancode
Edakkara
Moothedam
Kalady
GFD Koottayi
Triprangode
IChaliyar
j0dakkayam

2
3
4
5
6
7
8
9
10
11
12
13

Posts proposed
doctors
1
1
1
1
1
1
1
1
1
1
1
1
1

<!-- page 8 -->

14
15
16
17
18
19
20
21
22
23
24
25
26
27
28

Trikkalangode
Elamkulam
Chemmalasseri
Cherukavu
Thalakkad
Marakkara
Thehippalam
Moonniyur
Ponmuridam
Thanalur
Porur
Thiruvaly
Thuvvur
Chelembra
Vazhayur
No of Posts to Be
created

1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
28

Kozhikode
S1.No

Institution

1

Kodenchery
Beypore
Thiruvambady
Karassery
Koodaranhi
Eramangalam
Panangad
lKayanna
Atholy
Naduvennur
Changaroth
Azhiyoor
Madappally
Chorode
Peruvannamoozhy
Keezhriyur
Pannikottur Colony
Purameri
Naripatta
Vanimel
Chekkyadu
Maruthankara
Perumanna
Madavoor
Kattipara
Kolathur
IPuthiyappa
lirivalloor
Maniyoor
Villiappaly
Moodadi
Chengottukavu

2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
132

Posts proposed
doctors
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1

<!-- page 9 -->

33
34

Challyam
GBD Velimadakunnu
Total no of posts to be
created

1
1
34

Kannore

Proposed Posts
doctors

S1.No

Institution

I

Cherukunnu Punnacheri
Ettikkulam
Ulikkal
A'ralam (Tribal area)
Muzhakunnu
Peralassery
Vengad
Anjarakandy
Kadachira
Kuttiyattoor
Erammam-Kuttor
Pattuvam
Kadannappally
Puthiyangadi Fisheries
Cherukunnu (Thara)
kalllyasseri
Eranholi
Kodiyeri
New Mahe
Chokli
Chelora
Peruva
Mangattidom
Maloor
Chapparapadavu
Kurumathur
Morazha Fisheries
Pariyaram
Edakkad
Elayavoor
Mokeri
Kunnothuparamba
Thrippangottur
Kottayam Malabar
Peringalam
Mekunnu

2
3
4

5
6
7
VI
'8
9

10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36

Total no of posts to be
created

1
1
1

2
1

2
2
1

2
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1

2
1
1
1

2
2
2
1

2
2
46

Wavanad

S1.No

Institution

1

Vellamunda
Kurukanmoola

2

-

Posts proposed
doctors
1
1

<!-- page 10 -->

3
4
5
6
7
8
9
10

Thondernad
Begur (Forest)
Sugandhagiry
Pozhuthana
Kottathara
Padinjarathara
Pakkom
Chethalayam
Total no of posts tobe
created

1
1
1
1
1
1
1
10

Kasargodu
S1.No

Institution

1

Valiyaparamba
Padna
Maucode
Thaikadapuram
Thuruthi
Olat
Mavilakadappuram
Udumbunthala
Ajanur
Madikkai
Anadashram
Pallikkare
Chattamchal
Adoor
Belloor
Kumbadaje
Puthigai
Perla
Total No of Posts To
be created

2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18

Posts proposed
doctors
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
1
18

<!-- page 11 -->

Thiruvananthapuram

S1.No

Institution

No of Posts of Staff nurses Proposed

1

Tholikkodu

1

2

Thiruvallom

1

3

Edava

1

Vettoor

2

Chettivilakam

I

2

6

Chenkal

1

7

Kulathoor

1

8

Karode

1

g

Kollayil

1

10

Amboori

1

11

Kuttichal

1

12

Kallikadu (old)

13

Mukkola (Vizhinjam New)

1

14

Veli

1

15

Perurnathura

1

16

Puthukurichi

17

Mangalapuram

1

18

Peringammala

1

19

Panavoor

1

20

Karavaram

1

21

Vilavoorkkal

1

22

Vembayam

1

23

Manikal

1

Total Posts to be
created

25

I

1

I

1

Kollam

No of Posts of Staff nurses Proposed

S1.No

Institution

1

Kulathupuzha

1

2

Pooyapally

1

3

Paravur Pozhikkara

1

4

Neduvathur

1

<!-- page 12 -->

I

15

Ezhukone

6

Piravanthur

1

7

Thalachira

1

8

Melila

1

9

Aryancavu

1

10

thevalakara

1

11

Sakthikulangara

1

12

Mancode Chithara

1

13

Elamad

1

14

Ittiva

1

15

Thrikkaruva

2

16

East Kallada

1

17

Soorariadu South

1

18

Alappad

1

19

Azheekal

1

20

Thodiyoor

1

21

Thrikovilvattom

1

22

Perinad

1

Total Posts to be created

23

1

Pathanamthitta
S1.No

Institution

No of Posts of Staff nurses Proposed

1

Vethoochira

i

2

Kunnamthanam

1

3

Vallana

1

4

Chittar

1

5

Chandanappally

1

6

Koipuram

1

7

Mezhuveli

1

8

Kadammanitta

1

9

Cherukole

1

10

Ranni Pazhavangadi

2

11

Kadampanadu

1

12

Koodal

1

13

Kokkathodu

1

<!-- page 13 -->

14

Seethathodu

1

15

Kaviyoor

1

16

Anicadu

1

17

Kuttoor

1

_____ Total Posts to be created

18

Alappuzha

S1.No Institution

No of Posts of Staff nurses Proposed

1

Pallithode

1

2

Thakazhi

1

3

Cheriyanad

1

4

Karthikapally

1

Karuvatta

1

6

Aryad

1

7

Thottappally

1

8

Purakkad

1

9

Punnapra South

1

10

Ambalapuzha North

1

11

Mararikulam North

1

12

Vallethodu

1

13

Kadakkarappally

I

1

14

Thazhakara

I

1

15

Bharanikavu

I

1

16

Devikulangara

1

17

Pathiyoor

1

18

Kavalam

1

19

Ramankari

1

20

Kuppapuram

1

21

Mulakuzha

1

22

Kadampur

1

23

Chingoli

1

24

Ezhupunna

25

GFD Arattupuzha

1

Total Posts to be created

25

I

1

Kottayam

S1.No Institution

jNo of Posts of Staff nurses Proposed

<!-- page 14 -->

1

Thrikodithanam

1

2

Meenadam

1

3

Onamthuruthu

1

4

Nattakom

1

Kadanadu

1

6

Mutholy

1

7

Moonilavu

1

8

Maravanthuruthu

1

g

Udayanapuram

1

10

Thalayazham

1

11

Parathodu

1

12

Koruthodu

1

13

Vellavoor

1

14

Vizhikkithodu

1

15

Kattampak

1

Total No of posts to be
created

15

I d u kki

S1.No

Institution

No of Posts of Staff nurses Proposed

1

Devikulam

1

2

Karunapuram

1

3

Kodikulam

1

4

Kamakshy

1

Pampadumpara

1

6

Senapathy

1

7

Chembakappara

2

8

Thattakuzha

1

g

Aiakodu

1

10

Deviar Colony

2

11

Vellathooval

2

12

Chinnakanal

2

13

Bison Valley

2

14

AyyappanFcovil

15

Elappara

1

2

<!-- page 15 -->

16

Kokkayar

1

17

Vazhathopu

2

18

Kudayathoor

1

Total No of Posts to be
Created

25

Ernakulam
S1.No

Institution

1

Neriyamangalam

1

2

Palakuzha

1

3

Mulavukad

1

4

Arakkunnam

2

5

Udayamperur

1

6

Edavannakkadu

1

7

Alangad

1

8

Choornikkara

1

9

Okkal

1

10

Malayattoor

1

11

Ayyampuzha

1

12

Cheruvattoor

1

13

Kottapady

2

14

Kandakadavu

2

15

Avoly

1

Total No of Posts to be
Created

18

No of Posts of Staff nurses Proposed

Thrissur
SI.14o

Institution

No of Posts of Staff nurses Proposed

1

Mambara

2

2

Vellangallur

1

3

Pamboor

1

4

Kondazhi

1

5

Niadathara

1

6

Vaniyampara

1

7

Ayyanthole

2

8

Engandiyur

1

Orumanayoor

1

<!-- page 16 -->

10

Andathathodu

1

11

Parappukkara

1

12

Vallachira

1

13

Kuzhur

1

14

Perumpilavu

1

15

Porkulam

1

16

rhaikkad

2

17

Kaipamangalam

1

18

Chamakala

2

19

Padinjare Vemballoor

1

20

Vettilappara

1

21

Adat

1

22

Thonoorkara

2

23

ElavaIly

2

24

Varandarapilly

1

25

Vellorkkara

1

Total no of Posts to be
created

31

Palakkad
S1.No

Institution

No of Posts of Staff nurses Proposed

1

Chalavara

1

2

Nanniyodu

1

3.

Parali

1

4

Sholayur

1

5

Elumbilassery

1

6

Keralassery

1

7

Pallipurarri

1

8

Peringottukurissi

1

9

Kavassery

1

10

Kunissery

1

11

Kappur

1

12

Kumbidi

1

13

Pattithara

1

14

Peruvemba

1

15

Vannamada

1

<!-- page 17 -->

16

Nallepilly

2

17

Perumatty

1

18

Elevancherry

1

19

Ayilur

1

20

Vadavannur

1

21

Muthatamada

1

22

Pallassena

1

23

Thenkurussi

I

1

24

Kannadi

I

1

25

Puthucode

1

26

Kottopadam

1

27

Thenkara

1

28

Kanhjrapuzha

1

29

Karakurussy

30

Mannur

1

31

Perur

1

32

Pookottukavu

2

33

Vaniyamkulam

1

34

Vellinezhy

1

35

Thrikkadeeri

2

36

Marutha road

1

37

Puthussery

1

38

Mundur

1

39

Akathethara

40

Malampuzha

1

41

Muthuthala

1

42

Vallapuzha

1

43

Kottayl

1

44

Kannampara

1

Total No of posts to be
created

48

I

2

I

1

MalappUram
1

Puzhakkattiri

1

2

Kavannoor

1

3

Palapetty

1

<!-- page 18 -->

f

akkad

1

arkadappuram

1

Nannambra
f
1

mannaklari

8

Moorkkanad

1

g

Nannammukku

1

10

Veliyancode

2

11

Marancherry (New)

2

12

Edakkara

1

13

Moothedam

2

14

Triprangode

1

is

Chaliyar

1

16

Odakkayam

2

17

Trikkalangode

1

18

Elamkulam

1

19

Chemmalasseri

1

20

rhalakkad

1

21

Marakkara

1

22

Moonniyur

1

23

Ponmundam

1

24

Thanalur

1

25

Thuvvur

1

26

Chelembra

1

No of Posts to Be
created

30
Kozhikode

No of Posts of Staff nurses Proposed

S1.No

Institution

i

Kodenchery

1

2

Kodlyathoor

1

3

Thiruvambady

1

4

Karassery

i

Koodaranhi

2

6

Eramangalam

1

7

Panangad

1

<!-- page 19 -->

Atholy

1

Naduvennur

1

10

Changaroth

1

11

Azhiyoor

12

Madappally

2

13

Chorode

2

14

Pannikottur Colony

is

Purameri

16

Naripatta

17

Vanimel

18

Chekkyadu

1

19

Maruthankara

2

20

Madavoor

1

21

Kolathur

2

22

Puthiyappa

1

23

Irivalloor

1

24

Maniyoor

1

25

Moodadi

1

26

Chengottukavu

1

27

Challyam

2

28

GRD Vellimadakunnu

1

Total no of posts to be
created

35

8

i

1

F

1

I

1
2

I

1

Kanflur
No of Posts of Staff nurses Proposed

S1.No

Institution

1

Ettikkulam

2

Ulikkal

2

3

Narath

1

4

Chirakkal

2

Kelakam

1

6

Aralam (Tribal area)

2

7

Vallithodu

I

1

8

Muzhakunnu

I

2

g

Dharmadom

i

1

1

<!-- page 20 -->

10

Peralassery

1

11

Vengad

1

12

Anjarakandy

1

13

Kadachira

2

14

Kuttiyattoor

2

15

1 Erammam-Kuttor

1

16

- Kunhimangalam

1

17

Pattuvam

2

18

Kadènnappally

2

19

PuthI'yangadi Fisheries

2

20

Cherukunnu (Thara)

2

21

Eranholi

1

22

Kodiyeri

1

23

New Mahe

1

24

Chokli

2

25

Chelora

2

26

Peruva

2

27

Mangattidom

1

28

Maloor

1

29

Chapparapadavu

1

30

Kurumathur

1

31

Morazha Fisheries

1

32

Pariyaram

2

33

Edakkad

2

34

Elayavoor

1

35

Mokeri

2

36

Kunnothuparamba

1

37

Thrippangottur

2

38

Peringalam

1

39

Mekunnu

2

40

BPHC Chittariparamba

2

Total no of posts to be
_____ created

59

I

<!-- page 21 -->

Wayanad
SI.No

Institution

No of Posts of Staff nurses Proposed

1

Vellamunda

1

2

Kurukanmoola

1

3

Thondernad

2

4

Begur (Forest)

1

Sugandhagiry

1

6

Pozhuthana

1

7

Kottathara

2

8

Padinjarathara

2

Pakkom

2

Chethalayam

2

Total no of posts tobe
created

15

10

Kasargod u
S1.No

Institution

No of Posts of Staff nurses Proposed

1

Chittarickal

1

2

Narkilakad

1

3

Valiyaparamba

2

4

Padna

1

Bayar

1

6

Maucode

1

7

Thaikadapuram

2

8

Thuruthi

1

g

Olat

2

10

Mavilakadappuram

2

11

Udumbunthala

1

12

Ajanur

2

13

Madikkai

2

14

Anadashrarn

2

15

Pallikkare

1

16

Chattamchal

2

<!-- page 22 -->

2

17

kdoor

.18

Belloor

19

Kdmbadaje

2

20

Puthigal

2

21

Perla

2

.

1

- Total No of Posts To be
_____ created

33

<!-- page 23 -->

Thiruvananthapuram

S1.No

Institution

No of LTs Proposed

I

Thiruvallom

1

2

Madavoor

1

3

Uzhamalakkal

1

4

Veli

1

5

Puthukurichi

1

6

Cheruniyur

1

7

Vilavoorkkal

1

8

Manikal

1

Total Posts to be created

8

Kollam

No of LTs Proposed

S1.No

Institution

1

Paravur Pozhikkara

1

2

Njeduvathur

1

3

Ezhukone

1

4

Thalachira

1

5

Melila

1

6

Alayamon

1

7

East Kallada

1

8

Ezhukone Pavithraswaram

1

West Kallada

1

10

Alappad

1

11

Thodiyoor

1

12

Thrikovilvattom

1

Total Posts to be created

12

Pathanamthitta

S1.No

Institution

No of LTs Proposed

1

Koipuram

1

2

Thelliyoor

1

3

Cherukole

1

4

Erathu

1

5

Kadampanadu

1

6

Kokkathodu

1

7

Mylapra

1

<!-- page 24 -->

8

Seethathodu

1

Arilcadu

1

Total Posts to be created

9

Alappuzha
S1.No

Institution

No of LTs Proposed

1

Pallithode

1

2
3
4

Chettikulangara
Karthikapally
Karuvatta

lly
zha North

6
7

m North

8
g

ularn

10
11
12
13
14
15
16
17

1
1
1
1
1
1

GFD Arattupuzha

1
1
1
1
1
1
1
1
1

Total Posts to be created

17

vu
Krishnapuram
M
iVeeyapuram
Venmony
Kadar-npur
Chingoli
lEzhupunna

Kottavam
S1.No

Institution

No of LTs Proposed

1

Meenadam

2
3
4

Udayanapuram

1
1
1
1
1
1
1
1
1
1

Thalayazham
Koruthodu
Vellavoor

6
7
8
g

Vizhikkithodu

10

Kadanadu
Total No of posts to be
created

Pallickathodu
Kanakkary
Kattampak

10

<!-- page 25 -->

Idukki

SI.No

Institution

No of LTs Proposed

1

Senapathy

1

2

Chembakappara

1

3

Thattakuzha

1

4

Alakodu

1

Chinnakanal

1

6

Bison Valley

1

7

Ayyappankovil

1

Total No of Posts to be
Created

7

Ernakulam

S1.No

Institution

No of LTs Proposed

1

Edappally

1

2

Pothanicad

1

3

Palakuzha

1

4

Valakom

1

Chittattukara

1

6

Koonamavu

1

7

Mulavukad

1

8

Pindimana

1

g

Kadavoor

1

10

Udayamperur

1

11

Edavannakkadu

1

12

Edathala

1

13

Thiruvankulam

1

14

Mudakkuzha

1•

15

Okkal

1

16

Parakadavu

1

17

Ayyampuzha

1

18

Punnekkad

1

19

Avoly

1

Total No of Posts to be Created

19

Thrissur
S1.No

'Institution

No of LTs Proposed

1

Kakkad

1

<!-- page 26 -->

2

Panjal

1

3

Patikkad

1

4

Madakkathara

1

Ayyanthole

1

6

Engandiyur

1

7

Orumanayoor

1

8

Parappukkara

1

g

Chowanoor

1

10

Arthat

1

11

i

Kadangodu

1

12

Padinjare Vemballoor

1

1.3

Nalukettu

1

14

Poomala

1

15

Mullurkkara

1

16

Kuthampully

1

17

Thonoorkara

1

18

Vallatholnagar

1

19

Elavally

1

20

Thrikkur

1

21

Varandarapilly

1

22

Padiyur

1

Total no of Posts to be created

22

Palakkad
S1.No

Institution

No of LTs Proposed

1

Keralassery

1

2

Elevancherry

1

3

AyiIur

1

4

Vadavannur

1

5

Pallassena

1

6

Kannadi

1

7

Puthucode

1

8

Thenkara

1

9

Pookottukavu

1

10

Vaniyamkulam

1

11

Marutha road

1

12

Puthussery

1

13

Akathethara

1

<!-- page 27 -->

14
15

Muthuthala

1

I

Kottayi

1

Total No of posts to be
created

15

Malappuram
S1.No

Institution

No of LTs Proposed

Narinambra

1

2

Iringalloor

3

Angadipuram

1

4

Veliyancode

1

Edakkara

1

Moothedam

1

Kalady

1

8

GFD Koottayi

1

9

Odakkayam

10

Elamkulam

1

11

Cherukavu

1

12

Thanalur

1

13

Porur

1

14

Thiruvaly

15

Thuvvur

16

Chelembra

6

I

1

1

I

j

1
1

1

I

Total no of posts to be created

16

KozhiKode
S1.No

Institution

No of LTs Proposed

1

Beypore

1

2

Madappally

3

Keezhriyur

4

Pannikotwr Colony

I

1

5

Naripatta

I

1

6

Vanimel

7

Chekkyadu

8

Maruthankara

g

Perumanna

10

Kattipara

1

11

Puthiyappa

1

12

lirivalloor

1

I

1

1
I

1
1

I

I

1

1

<!-- page 28 -->

13

lVilliappaly

1

14

Moodadi

1

15

Chengottukavu

1

Total no of posts to be
created

15

Wavanad
No of LTs Proposed

S1.No

Institution

1

Edavaka

1

2

Kurukanmoola

1

3

Begur (Forest)

1

4

Sugandhagiry

1

Pozhuthana

1

6

Kottathara

1

7

Padinjarathara

1

8

Pakkom

1

Total no of posts tobe created

8

-

Kannur
S1.No

Institution

No of LTs Proposed

1

Udayagiri

1

2

Parassinikadavu

1

3

Ettikkulam

1

4

Ulikkal

1

Narath

1

6

Dharmadom

1

7

Peralassery

1

8

Vengad

1

9

Kadachira

1

10

Kuttiyattoor

1

11

Kunhimarigalam

1

12

Puthiyarigadi Fisheries

1

13

ICherukunnu (Thara)

1

14

kalliyasseri

1

15

Eranholi

1

16

Kodiyeri

1

17

Peruva

1

18

Mangattidom

1

19

Imaloor

1

<!-- page 29 -->

20

Chapparapadavu

1

21

Kurumathur

1

22

Morazha Fisheries

i

23

Edakkad

1

24

Elayavoor

1

25

Mokeri

1

26

Kunnothuparamba

1

27

Thrippangottur

1

28

Kottayam Malabar

1

29

Peringalam

1 -

30

Mekunnu

1

Total no of posts to be
created

30

Kasargodu
S1.No

Institution

1

Bayar

1

2

Maucode

1

3

Thuruthi

1

4

Olat

1

Mavilakadappuram

1

6

Udumbunthala

1

7

Ajanur

1

8

Madikkai

1

g

Pallikkare

1

10

Adoor

1

11

Belloor

1

12

Kumbadaje

1

Total No of Posts To be
created

12

No of LTs Proposed
