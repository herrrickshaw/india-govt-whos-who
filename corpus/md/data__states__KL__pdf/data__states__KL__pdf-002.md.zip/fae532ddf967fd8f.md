---
doc_id: "fae532ddf967fd8f"
source_url: "https://www.cusat.ac.in/uploads/CUSAT-PL(B).SO-78993-2024-1.pdf"
ministry: "Cochin University of Science and Technology, Kerala"
title: "e-tender Circular"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c8632b39f2d5f2f8"
---

<!-- page 1 -->

No. CUSAT/PL(B).SO/78993/2024
KOCHI-22
Dated: 14.08.2024
CIRCULAR

Sub:- e-Tender- Submission of documents-Additional guidelines intimated-reg.
All Heads of Departments/Directors of Schools/Centres/Principal, SOE/CUCEK/ Principal
Investigators/University Engineer/Head of Offices are hereby informed to submit the following
documents without fail, for floating e-tenders.
(I) Mandatory Files required for uploading e-tender.
1. Notice inviting tender (NIT)-PDF format
2. Tender document- PDF format
3. Agreement form- PDF format
4. E_payment form- PDF format
5. Bill of quantity (BOQ)- Excel format (.xls format)
6. Etender data sheet- Word/PDF format
7. Copy of the University Order according administrative sanction for the purchase/work etc.
(II) In the Notice inviting tender (NIT), Tender Fee and GST should be shown separately.
(III) Tender opening date may be fixed as- After 3 to 5 working days from the bid submission
end date.

Zaida K M *
PLANNING AND DEVELOPMENT
OFFICER
To
1. The Heads/Directors of Departments/Schools/Centres
2. Principal Investigators in all Departments/Schools and Working under various sponsored
schemes/projects
3. Finance Officer/Deputy Director, KSAD CUSAT
4. Director, CIRM/University Engineer
5. Joint Registrar (Finance)

<!-- page 2 -->

6. PS to Vice Chancellor/ PS to Pro-Vice Chancellor/ PA to Registrar/ PA to Controller of
Examinations/PA to Finance Officer
7. Assistant Registrar(Finance/Audit/Accounts/Cash)
8. Audit (A/B/C/D)/Accounts (I/II)/Cash (A/B)/ Planning A/C/UGC) Sections
9. Day file/ Stock file/File Copy)

* This is a computer generated document. Hence no signature is required.
