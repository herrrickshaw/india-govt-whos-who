---
doc_id: "01a2ec25eacac00b"
source_url: "https://www.handicrafts.kerala.gov.in/images/pdf/memorandum.pdf"
ministry: "Handicrafts Development Corporation of Kerala Limited, Kerala"
title: "Click for Memorandum and Articles of Association"
date: ""
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1a42023cbcabe12e"
---

<!-- page 1 -->

Hdckltdhdckltdhdckltdhdckltdhdckltd
handicraftsdevelopmentcorporationof
keralaltdhdckltdagovernmentofkerala
HANDICRAFTS DEVELOPMENT
undertakinghdckltdhdckltdhdckltdhdc
CORPORATION OF KERALA LTD
kltdhdckltdhdckltdhdckltdhdckltdhdc
kltdhdckltdhdckltdhdckltdhdckltdhdc
MEMORANDUM AND ARTICLES OF
ASSOCIATION
kltdhdckltdhdckltdhdckltdhdckltdhdc
kltdhandicraftsdevelopmentcorporati
onofkeralaltdagovernmentofkeralaltd
dhandicraftsdevelopmentcorporation
ofkeralaltdagovernmentofkeralaltdme
morandumandarticlesofassociationha
ndicraftsdevelopmentcorporationofke
ralaltdagovernmentofkeralaundertaki
nghdckltdhdckltdhdckltdhdckltdhdckl
tdhdckltdhdckltdhdckltdhdckltdhdck
(A GOVERNMENT OF KERALA UNDERTAKING)

2017

<!-- page 2 -->

HDCK LTD- Memorandum and Articles of Association

2

<!-- page 3 -->

HDCK LTD- Memorandum and Articles of Association

3

<!-- page 4 -->

HDCK LTD- Memorandum and Articles of Association

4

<!-- page 5 -->

HDCK LTD- Memorandum and Articles of Association

MEMORANDUM OF ASSOCIATION
OF HANDICRAFTS DEVELOPMENT CORPORATION OF KERALA LTD
I.
II.
III.

Name of the Company is “ HANDICRAFTS DEVELOPMENT
CORPORATION OF KERALA LTD”.
The Registered Office of the Corporation will be situated in the State of
Kerala.
(a) The main objects for which the Company is incorporated will be:
(1) To develop and promote Handicrafts within the State of Kerala.
(2) To provide financial, technical, marketing, development or any other
assistance and guidance to any establishment, undertaking or enterprise
of any description whatsoever which is likely to facilitate or accelerate the
development of Handicrafts in the State of Kerala.
(3) To promote, establish and operate sales offices such as Emporia, Show
Rooms, Publicity Offices, Stalls and Centres with the object of improving
the marketability of Kerala handicrafts anywhere within and outside India.
(b) To object incidental or ancillary to the attainment of the above main object
will be:
(1)
To undertake the development and marketing of Kerala Handicrafts
products within and outside the State and the supply of raw materials
controlled commodities required for development of handicrafts industries,
whether owned or run by Government, Statutory body, Company, Firm,
Industrial Co-operative or Individual;
(2)
To undertake export of Handicrafts products from Kerala directly or in
collaboration with exporting business Corporations, Companies or agencies –
Government or Private –to establish trade connections, sales depots, selling
agencies, offices for distributing agents, etc. to undertake directly or in
collaboration with specialised domestic or foreign agencies market surveys to
explore possibilities of Indian Handicrafts in foreign markets, to open publicitycum-information centres, showrooms, sales depots and warehouses at
suitable places in foreign countries, exchange delegation of foreign buyers
and domestic exporters, to participate in foreign fairs and exhibitions and to
undertake special promotional measures in countries whose import potential
for Kerala Handicrafts has not been adequately tapped;

5

<!-- page 6 -->

HDCK LTD- Memorandum and Articles of Association

(3) To acquire and take over from the Government of Kerala, the goodwill
and business in Handicrafts emporia and/or other handicrafts units run by the
Government of Kerala and all or any of the assets of such business on such
dates and such terms and conditions specified under agreements, deeds,
instruments, and assurances as may be necessary or as may be deemed
advisable or proper;
(4) To enter into contracts with and take up indents from Government of
India and the State Governments in all their departments and corporations
and
other
subsidiaries
and
branches,
statutory
and
local
bodies,railways,steamer companies,muncipalities and local boards, and from
any agency of officer thereof, having the necessary power for manufacture
and supply of goods,materials,articles and equipment of every description
and to arrange for the performance of such contracts and indents by sub
contracting them to or placing orders in respect thereof with manufacturers for
the manufacture or supply of such goods,materials,articles or equipment or
parts thereof or servicing or processing in connection therewith, or such
materials,services as may be necessary for the due performance of such
contracts and indents and to have the goods,materials,articles and equipment
manufactured,fabricated,assembled and supplied.
(5)
To implement any scheme which the Government of India or the
Government of Kerala may formulate for the development of the Handicrafts
industry.
(6)
To aid,advise,assist,finance and protect the interests of Handicrafts
Industries in Kerala and to provide them with capital credit,means,resources
and technical and managerial assistance for the execution of their work and
business to enable them to develop and improve their methods of
manufacture,managemnet,marketing and technique of production.
(7) To introduce schemes of standardisation and quality control according to
specifications fixed by the Indian Standards Institution the All India
Handicrafts Board, and the Government of Kerala whenever possible and to
make available technical and other assistance to handicrafts units and to
establish a system of inspection;
(8) To undertake market survey, market research within the state and
important markets in other states in India and to collect and compile statistics,
to give publicity of the information and to contact foreign buyers for the export
of handicrafts products.

6

<!-- page 7 -->

HDCK LTD- Memorandum and Articles of Association

(9) To prepare and publish price lists, catalogues, folders, pamphlets,
brochures and such other publicity materials for promotion of sales within the
State and outside.
(10) To aid or assist Handicrafts industries Units, whether Co-operative or
private enterprises, by supplying credit, giving financial assistance against
finished products either by outright purchases at an agreed price or on
warehouse principle with nominal interest charges.
(11) To guarantee loans to Co-operatives, manufacturers, dealers or
exporters of Handicrafts industries products to enable them to step up
production and execution against specific orders contracted or subcontracted
through the Corporation or directly and for other promotional measures
(12) To effect Co-ordination between large industries and small scale and
handicrafts industries by suitable methods similar to those aforesaid, enabling
the manufacturers to produce such parts, goods, accessories, ancillaries and
components as may be required by other industries.
(13). To effect Co-ordination between the Corporation and the National small
Industries Corporation, the Handicrafts and Handlooms Export Corporation of
India Ltd. and the show room of the All India Handloom Board and the All
India Handicrafts Board to help promotion of sales and exports of the
products of the aforesaid industry and the expansion of the business of the
company.
(14) To take up supply of machinery, tools and equipments on hire purchase
system to the Handicrafts industries in Kerala.
(15) To procure, manufacture, buy, sell, import, export, install, work and
generally deal in any plant, machinery, tools, materials, goods of things of any
disposition which in the opinion of the Corporation may be conveniently dealt
with by the Corporation in connection with any of its objects.
(16) To carry on any other allied trade or business(whether manufacturing or
otherwise) which may appear to the Corporation capable of being
conveniently and/ or advantageously carried on in connection with the
expansion of business of the aforesaid corporation.
(17) To apply for and take out, purchase or otherwise require any trade mark,
patents, patent rights, inventions, copy-right or designs which may be useful
for the Corporation’s object.

7

<!-- page 8 -->

HDCK LTD- Memorandum and Articles of Association

(18) To receive grants, loans advances or other moneys on deposit from the
Central Government or State Government, Banks, Companies, Co-operative
Societies, Trusts, or individuals with or without allowance of interest thereon,
but the Corporation will not carry on banking business within the meaning of
the Banking Companies Act 1949;
(19) To lend or advance money either upon or without security and to borrow
or raise or secure the payment of money in such manner as the Board of
Directors of the Company may deem fit, and in particular, by the issue of
debentures , debenture stock, bonds, deposits obligations, and securities, of
all kinds, and to frame, constitute and secure the same, as may seem
expedient, with full power to make the same transferable by delivery or by
instrument of transfer or otherwise and either perpetual or terminable and
either redeemable or otherwise on the undertaking of the Company or upon
any specific property, and rights, present and future, of the Company or
otherwise howsoever, and collaterally or further to secure any securities of
the company by a trust deed or other assurance.
(20) To establish agencies in India and elsewhere and to regulate and
discontinue the same.
(21) To apply for, tender, purchase or otherwise acquire contracts and
concessions for or in relation to the construction, execution, carrying out,
equipment, improvements, management, administration or control of works.
(22) To invest the capital of the Corporation in or to deal with Shares, Stocks,
Bonds, Debentures, Obligations and other securities of any Company or
association formed for establishing, executing of working any production unit
approved by the Corporation.
(23) To collaborate with any company or association or concern formed for
carrying on any manufacture or business within the objects of the Corporation
or to direct the management, control and supervision of any company,
association, or concern by nominating Directors, Controllers, Supervisors and
Advisors.
(24) To enter in to any partnership or arrangements for joint working in
business, sharing of profits, pooling of any production unit joint ventures or
reciprocal concession with any other company carrying on or engaged in any
manufacture or business within the objects of this corporation or similar
thereto;

8

<!-- page 9 -->

HDCK LTD- Memorandum and Articles of Association

(25) To sell, dispose off, let on lease or on hire or transfer the business,
property and undertaking of the Corporation or part thereof, for cash stock or
shares of any other company or for any other consideration which the
Corporation deems fit to accept;
(26) T obtain any order enabling the Corporation to carry its objects into
effect or for effecting any modification of the Corporation’s constitution or for
any other purpose by lawful means and to oppose any proceedings or
applications which may seem calculated directly, or indirectly to prejudice the
Corporation’s interest.
(27) To pay all costs, charges and expenses incurred or sustained in or
about the promotion and establishment of the Corporation or which the
Corporation may consider to be in the nature of preliminary expenses
including therein the cost of advertising, commission for underwritings,
brokerage, printing and expenses attendant upon the formation of branches
and agencies;
(28) To construct, maintain and alter any buildings or works necessary or
convenient for the purpose of the Corporation.
(29) To make, draw, accept, endorse, discount, execute, issue and negotiate
cheques, bills of exchange, promissory notes, debentures and negotiable or
transferable instruments.
(30) Generally to do all such matters and things as may appear to be
incidental to the interest of and attainment of the objectives of the
Corporation.
III

(c) Other objects:To organise, take up or introduce schemes for imparting training in
Handicrafts, to sponsor candidates for such training wherever available.

IV

The liability of the members is limited.

9

<!-- page 10 -->

HDCK LTD- Memorandum and Articles of Association

V

“The capital f the company is Rs.3,00,00,000 divided in to 3,00,000 shares of
Rs.100/- each with power to issue any of the shares in the capital, original or
increased, with or subject to any preferential, special or qualified rights or
conditions, as regards dividends, repayments of capital, voting or otherwise”.

We, the several persons, whose names and addresses are subscribed are desirous of
being formed in t a company in pursuance of this Memorandum of Association,and we
respectively agree to take the number of shares in the capital of the company set
opposite to our respective names.
Names,addresses,
Description and

Signature

No.of shares taken

Signature of witnesses and

by each subscriber

their address description &

Occupation of subscribers

occupation

Sarala Gopalan
Deputy Secretary to Government
Industries Department
Secretariat,Trivandrum
sd/For and on behalf of the
Governor,Kerala state.
(Government Servant)

1

K.R.Damodaran Pillai
Superintendent
Secretariat,Trivandrum
(Government Servant)

sd/-

1

P.Sambasivan Achari
Assistant
Secretariat,Trivandrum
(Government Servant)

sd/-

1

Total Shares taken

sd/G.Rajasekharan Nair,Assistant
Industries Department
Secretariat,Trivandrum

3

____________________________________________________________________________________
Date the 15th day of November 1968

10

<!-- page 11 -->

HDCK LTD- Memorandum and Articles of Association

AS AMENDED ON 06.04.2017

11

<!-- page 12 -->

HDCK LTD- Memorandum and Articles of Association

ARTICLES OF ASSOCIATION
OF HANDICRAFTS DEVELOPMENT CORPORATION OF KERALA LIMITED
PRELIMINARY
1. “The Regulations contained in Table A in the first schedule to the Companies Act
1956 so far as the same may be applicable to a private company as defined in
the Act shall apply to this company in the same manner as if all such regulations
of Table A are specifically mentioned in these Articles, subject to the
modifications herein contained”.
2. “The Governor “ means the Governor of Kerala
3. The company shall be a private limited company having share capital and
accordingly:
(a) The right of transfer of share of the company is hereby restricted in the
manner provided herein;
(b) The number of members shall not exceeds fifty not including(i) Persons who are in the employment of the company;
(ii) Persons who having been formerly in the employment of the company
were members of the company while in that employment and have
continued to be members after the employment ceased;
(c) No invitation shall be issued to the public to subscribe any shares in or
debentures of the company.
(d) Prohibits any invitation or acceptance of deposits from persons other than
its members,directors or their relatives.
4. “The Authorized share capital of the Company shall be Rs.3,00,00,000 divided
into 3,00,000 equity shares of Rs.100/- each”.
5. Subject to the prior approval of the Governor, the company shall have the power
to increase or reduce the share capital in accordance with the provisions of the
Act.
6. Subject to the provisions of the Act, the Board of Directors subject to the
approval of the Governor shall have the power to issue the shares of the
company upon such terms and conditions and with such rights and priorities and
privileges as to payment of allotment money, calls etc. as the Board may
determine.
7. The Board may at its discretion refuse to register any transfer of shares for
reasons deemed fit and proper.

12

<!-- page 13 -->

HDCK LTD- Memorandum and Articles of Association

BORROWING POWERS
8. Power to borrow: Subject to the approval of the Governor the Board may,from
time to time, borrow and/or secure the payment of any sum or sums of money for
the purposes of the company, subject to the provisions of the Act.
9. Conditions on which money may be borrowed: The Directors may, subject to the
approval of the approval of the Governor secure the repayment of such moneys
in such manner and upon such terms and conditions in all respects as they think
fit and in particular by the issue of bonds, perpetual or redeemable debentures or
debenture stock or any mortgage charge or other security on the undertaking of
the whole or any part of the property of the company (both present and future)
including its uncalled capital for the time being.
10. Securities may be assignable free from equities: Debentures, debenture stock,
bonds or other securities, may be made assignable free from any equities
between the Company and the person to whom the same may be issued.
11. Issue at discount, etc. or with special privileges: subject to the provisions of
section 117 of the Act and the approval of the Governor, any debenture
,debenture stock, bonds or other securities may be issued at a discount,
premium or otherwise, and with any special privilege as to redemption,
surrender, drawings and allotment of shares.
12. Quorum: Two members present in person of whom one shall be representative of
the Governor shall be a quorum for a general meeting.
The Governor, so long as he is a shareholder of the company, may from time to
time appoint one or more persons(who need not be a member or members of the
company), to represent him at all or any meeting of the company and the
persons so authorised shall be entitled to exercise the same powers on their
behalf as if they are individual share holders of the company personally present.
DIRECTORS
13. The number of Directors shall not be less than two and shall not be more than
eleven. However , the Directors representing financing institutios,when appointed
will be in addition to the above.
The first Directors and all subsequent Directors shall be appointed either by the
Governor or in the manner decided by him. Subject to the provisions of the Act,
the Directors shall hold office during the pleasure of the Governor.

13

<!-- page 14 -->

HDCK LTD- Memorandum and Articles of Association

14. The Directors are not required to hold any qualification shares.
15. Quorum of a Board Meeting shall be subject to the provisions of the Companies
Act 1956; provided that such quorum shall not be deemed to be complete unless
atleast one official representing the administrative development or the finance
department of the Government of Kerala, who is a Director for the time being is
present.
The decisions taken at any Board meeting shall be on the basis of decision by
majority. For purpose of majority each Director including the Chairman shall have
one vote. In case of equality of votes the Chairman shall have an additional or
casting vote.
REMUNERATION OF DIRECTORS
16.

Subject to the provisions of the Act,

(a) The remuneration of the Directors shall from time to time be determined by
the Governor, such reasonable additional remuneration as may be fixed by
the Governor, may be paid to any one or more of the Directors for extra or
special services rendered by him or them or otherwise.
(b) In addition to remuneration, if any, payable to the Directors under class(a)
above, the Directors, may also be paid travelling allowance for attending
meetings of the Board or of any Committee thereof or in connection with the
business of the Company, rates to be prescribed by the Company in general
meeting.
MANAGING DIRECTOR
17.
Appointment of Managing Director: Subject to the provisions of the Act,
the Governor may appoint, on such terms and at such remuneration as he may
think fit, one of the Directors to be the managing Director who shall be a whole
time employee f the Company for the conduct and management of the business
of the company subject to the control and supervision of the Directors. The
Governor shall have the power of termination and reappointment of Managing
Director (s) in accordance with the provisions of the Act.
The following matters shall require the prior approval of the Governor.
(i)

Any programme of capital expenditure for an amount which exceeds
Rs.10 Lakhs in cases which do not form part of the sanctioned estimates.

14

<!-- page 15 -->

HDCK LTD- Memorandum and Articles of Association

(ii)
(iii)
(iv)
(v)
(vi)
(vii)
(viii)
(ix)
(x)

Appointment to posts carrying a maximum pay of Rs.10000 (Rupees ten
thousand) or more per month.
Sale, lease or disposal otherwise of the whole or substantially the whole of
the undertaking of the company.
Division of capital into different class of shares.
Formation of subsidiary company.
Winding up of the company.
Sub-division and consolidation of shares.
Allocation of profits and declaration of dividend.
Any other matter which in the opinion of the Chairman be of such
importance as to be reserved for the approval to Government.
Foreign tour of officials of the Corporation including members of the Board
of Directors such as Chairman, Managing Director and other Directors on
business matters or for study purposes lasting more than four weeks or
involving more than one person or involving an expenditure of more than
Rs.10000/THE SEAL

18.
The seal of the company shall not be affixed to any instrument except by
the authority of a resolution of the Board and in the presence of at least one
Director or of such other person as the Governor or Board may appoint for the
purpose and any such Director or other authorised person as aforesaid shall sign
every instrument to which the seal of the company is so affixed in his presence.
19.
The company shall be a Government company within the meaning of
section 617 of the Act and the provision of the Act in so far as they are applicable
to a Government company, shall be applicable to this company.

20.
Notwithstanding anything contained in any of these articles the Governor
may from to time subject to the provisions of the Act, issue such directives or
instructions as he may think fit in regard to the finances and the conduct of the
business and affairs of the company and in like manner may vary or annual any
such directives. The Directors shall give immediate effect to such directive or
instructions.
21.
The principles of reservation as applicable to Government appointments
should be followed in the matter of all appointments.

15

<!-- page 16 -->

HDCK LTD- Memorandum and Articles of Association

22.
The company shall submit a copy of the Balance sheet and profit & Loss
Account with a copy of the Auditors Report to the Finance Secretary to
Government of Kerala who shall have the right to comment upon or supplement
the auditor’s report in such a manner as he may deem fit. Any such comment
upon or supplement to the Auditors report shall be placed before the Annual
General meeting of the Company at the same time and in the same manner as
the audit report. The Governor may call for such returns,accounts and other
information with respect to the property and activities of the company as may be
required from time to time.
Names,addresses,
Description and

Signature

No.of shares taken

Signature of witnesses and

by each subscriber

their address description &

Occupation of subscribers

occupation

Sarala Gopalan
Deputy Secretary too Government
Industries Department
Secretariat,Trivandrum
sd/For and on behalf of the
Governor,Kerala state.
(Government Servant)

1

K.R.Damodaran Pillai
Superintendent
Secretariat,Trivandrum
(Government Servant)

sd/-

1

P.Sambasivan Achari
Assistant
Secretariat,Trivandrum
(Government Servant)

sd/-

1

Total Shares taken

sd/G.Rajasekharan Nair
Assistant, Industries Department
Secretariat, Trivandrum

3

____________________________________________________________________________________
Date the 15th day of November 1968

16
