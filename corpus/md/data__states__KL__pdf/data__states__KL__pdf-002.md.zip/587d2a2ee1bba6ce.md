---
doc_id: "587d2a2ee1bba6ce"
source_url: "https://www.keralafeeds.com/uploads/tender/2026/10/09/035032690/file/Tender-Document-1-merged.pdf"
ministry: "Kerala Feeds Limited, Thrissur, Kerala"
title: "Download"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a1ed6101388bcaeb"
---

<!-- page 1 -->

uIcj ^pUmhm doaoÊUm
ItÃ-äpwIc- - 680683

(õnKw - I, tS9
9o·² _oUm)

<!-- page 2 -->

uIcj ^pUmhm doaoÊUm
(Hç uIcj h±·n± Ùn]\w)
IuÈe
ewIc, JJ± PoÈ.
]o° 680 683
u^n® x 0480-- 2713555, ^nO
Om x 04802720194
07.10.2026
Z±Lnhm u^nlw
IÄ\oboêÉ Furnace oil – Fired, Horizontal - Fire Tube (2000 kg/hr - Thermax
make, 3000kg/hr – IAEC make) t_m-bv-edpIfpsS ASp¯ c−v hÀ-j-Im-e-b-f-

hnÂ h-cp-¶ IBR \nba{]-Im-c-ap-f-f hmÀjn-I operational license ]p-Xp-¡p-¶Xn\pw A-Xn-sâ `m-K-am-bn sN-t¿-−n-h-cp-¶ sa-bvâ-\³-kv {]-hr-¯n-IÄ \S-¯n
hmÀjn-I ]-cn-tim-[-\-bv-¡v t_m-bn-e-dpI-sf k-Ö-am-¡p-¶-Xn\pw Hydraulic &
Open test \S-¯n license e-`y-am-¡p-¶-Xn\pw th-−n X¿m-dm¡n-b ZÀ-Lm-kv
t^m-dw
Z±Lnhm u^nlw dõo%Á XobXo

x 08.10.2026 ®X² 21.10.2026

Z±Lnhm ha±Ãou·¾ Aehn\ XobXo x 21.10.2026, 2.00 aWo
Z±Ln»I³ Hl%Á XobXo

x 21.10.2026, 2.30 aWo

Z±Lnhm ha±Ão%Á B;tS u]cm

x

eodnhw

x

u^n®

x

Z±Ln»InctÂ u]cm, HÃm

<!-- page 3 -->

uIcj ^pUmhm doaoÊUm
(Hç uIcj h±·n± Ùn]\w)
IuÈe
ewIc, JJ± PoÈ.
]o° 680 683
u^n® x 0480--- 2713555, ^nO
Om x 04802720194
07.10.2026
dxZ±Lnhm
IÄ\oboêÉ Furnace oil – Fired, Horizontal - Fire Tube (2000 kg/hr - Thermax
make, 3000kg/hr – IAEC make) t_m-bv-edpIfpsS ASp¯ c−v hÀ-j-Im-e-b-fhnÂ h-cp-¶ IBR \nba{]-Im-c-ap-f-f hmÀjn-I operational license ]p-Xp-¡p-¶Xn\pw A-Xn-sâ `m-K-am-bn sN-t¿-−n-h-cp-¶ sa-bvâ-\³-kv {]-hr-¯n-IÄ \S-¯n
hmÀjn-I ]-cn-tim-[-\-bv-¡v t_m-bn-e-dpI-sf k-Ö-am-¡p-¶-Xn\pw Hydraulic &
Open test \S-¯n license e-`y-am-¡p-¶-Xn\pw th-−n X¿m-dm¡n-b ZÀ-Lm-kv
t^m-dw.

Z±Lnhm ha±Ão%
%ÁXoÌ
ÌÉ \o_á
á\I³
1. ÈßøÄdÆÕcæJ Ø¢Ìá
áoºîíí
1. Z±Lnhm ha±Ão%Á IcncInc° 1100/-è] \ocX¼eyanbo \²uI¾XnWm.

\ocX¼eyw kaÀ-¸n-¡m¯ Z±Ln»I³ IÄ\o ]coKWo%ÁXÈ.
2. Z±Lnho² Icn± dõo·n¿e±·m \n-c-X-{Z-hy¯pI aS·o \ÂIp¶Xv Z±Lnhm

dõo»bn³·m e±·m ¨±U± \²Iob ufganbocn¡pw.
3. \ocX¼ey¿o\m IÄ\o ]dof \²!ÁXÈ.
2. çÏÞ·cÄÏíAáU ÎÞÈÆmBZ
1. Icm-dp-Imc-\v

Approved Boiler Erecting Certificate AsÃ-¦nÂ t_m-bv-e-dp-I-fp-sS

sa-bvâ-\³-kv tPm-en-IÄ Ip-dª-Xv 3 hÀ-s¡-¦nepw sN-bv-X ap³-]-cn-N-bw D-−m-bn-cnt¡-−-XmWv.
2. Icm-dp-Imc-\v Pn.F-kv.Sn sc-Pn-kv-t{Sj³ \nÀ-_-Ô-ambpw D-−m-bn-cn-t¡-−-XmWv.
3. Z±Lnhot\nÃw µøÞùáµÞøX ha±Ãou·¾ ucJI³
1.

Approved Boiler Erecting Certificate sâ ]-IÀ¸v AsÃ-¦nÂ ®°]coNbw
tXjobo%ÁXoÌÉ ucJI³ (Copy of Work order/ Completion Certificate)

2.

Tender form fee, EMD F¶nh A-S-¨ c-ko-Xn-sâ ]-IÀ¸v

<!-- page 4 -->

3.

Pn.F-kv.Sn sc-Pn-kv-t{Sj-sâ ]-IÀ¸v(Ds−-¦nÂ), (CsÃ-¦nÂ Pn F-kv Sn CÃ

F-¶p ]-d-ªn-«p-Å k-Xy-hm-Mv-aqew)
4.

]m³ ImÀ-Un-sâ ]-IÀ¸v

5.

{]kv-Xm-h-\IÄ (Declarations) (A\p_-Ôw þ 2, A\p_-Ôw 3 F¶nh Icm-dpImc-sâ se-äÀ sl-UnÂ k-aÀ-¸n-t¡-−-XmWv.)

4. _nUnæÈ Ø¢Ìá
áßºîíí
Z±Lnhm ha±Ãou·¾Xm tS9o·² _oUm, tt5hm _oUm FÁoºt\ c¾nbo
Xoco»nboco·Ww. tS9o·² _oìw tt5hm _oìw 5uXyIw IecIjo² ®¼
tNÇmXm IeloÌ®Ijo² ucJtÃâ¿o \²uI¾XnWm. AÈn¿ _oìI³
]coKWo%ÁXÈ.
a. t¿µíÈßAW ÌßÁíí:
µøÞùáµÞøX Z±Lnhose \n-_-Ô-\ 3 Â ]dªn-«p-Å-Xp-t]mse (Z±Lnhot\nÃw
µøÞùáµÞøX ha±Ãou·¾ ucJI³) dÉçÄcµ¢ µÕùßW ØÎVMßçAIÄÞWm.
b. tt5hm _oUm:
µøÞùáµÞøX tt5hm _oUm dÉçÄcµ¢ µÕùßW ØÎVMßçAIÄÞWm. tS9o·²
_oUo² ubnKyX u\Sob Z±Ln»I³ an^ua tt5hm _oUo\m ]coKWo%IÆ=.
tS9o·² _oUm ubnKyX u\SobeçtS tt5hm _oìI³ Hl%Á Zoehw
Alobo%ÁXnboco%w.
5. ÈßøAßæÈ Ø¢Ìá
áoºîí (A\p_-Ôw þ 1)
1. ¨ucn

u_nbodcI³ Hç XeW tNåÁXoÌÉ HI teuFtl uIn½m
tNuÇ¾XnWm.
2. I-cm-dp-Imc-s\ (L1) \n-Ý-bn-¡p¶-Xv sam¯w Xp-I-bpsS (GST DÄs¸sS, Ds−-¦nÂ)
Ip-d-hnsâ A-Sn-Øm-\¯nem-bn-cn¡pw
3. tIm-«v sN-¿p-¶ \n-c-¡nÂ c−v-v hÀ-j-t¯-¡v am-ä-ap-−m-bn-cn-¡p-¶XÃ.
4. \oc%I³ \²uI¾Xm ]n.F-^v, C-kv.sF D³tÃtS FÈn \o!XoI;w, Pn.F-kv.Sn

D³tÃtS GtXnt· SnPI;w
\oc·nboco·Ww \²uI¾Xm.

BefyanuWn

AtXÈnw

D³tÃtSÆÉ

6. Icm-dn-sâ Im-emh-[n
Cu I-cm-dn-sâ Im-em-h-[n 2 hÀ-j-t¯-¡m-bn-cn¡pw. hÀ¡v \-S-t¯-− Xn-¿-Xn-bpw
Im-em-h-[nbpw I-¯v ap-Jm-´n-cw A-dn-bn-¡p-¶-XmWv.

<!-- page 5 -->

7. {]Xn-^e-s¯ kw-_-Ôn¨v
1. Hmtcm

sa-bvâ-\³kv

hÀ¡v

Xr-]vXn-I-c-am-bn

]qÀ-¯n-bm-¡n-

_átÃ½

UoÃn±½taÂo² \oèw {]hÀ¯\ km£y-]{Xw enºoX¶Xn\p ti-jw _nÂ
k-aÀ-¸n-¡mhp-¶Xpw, 10 Zn-h-k-¯n\-Iw \n-b-am-\p-kr-Xam-b Xp-I-IÄ In-gn-hp
h-cp-¯n-b-Xn-\p ti-jw Xp-I \Â-Ip-¶-Xm-bn-cn¡pw.
8. ZÀLm-kns\ kw-_-Ôn-¨ hn-i-Zhn-h-c-§Ä
1. hÀ¡n-s\ kw-_-Ôn-¨ hn-i-Zhn-h-c-§Ä A\p-_-Ôw (1) Â hn-h-cn-¨n-cn-¡p¶p.
2. e±·m \È cpXobo² ]qÀ-¯n-bm-t¡-−Xpw _átÃ½ UoÃn±½taÂo² \oèw
km£y-]{Xw enºo¿uc¾Hw IcncInctÂ _n[yXbnWm.
3. Icm-dnÂ kqNn¸n¨ FÃm tPmenIfpw sN¿phm³ IcncInc° _n[yÙ\nWm.
CXo² epG eçKÁ ]¸w Icn±!lta IÄ\o%¾n!Á Iw \wº³·m
IcncInc\o² \oèw ]ok ¤Sn%ÁHw B!è.

4. ]-cn-tim-[-\-bv-¡m-bn _Ôs¸-« Un-¸mÀ-«v-saânÂ \n¶pw h-cp-¶ D-t²ym-K-Ø-cp-sS
bm-{Xm-Nne-hv (Ds−-¦nÂ) I-cm-dp-Im-c³ h-ln-t¡-−-XmWv.
9. A]ISºtj hw_á
áo»m
uPndo ÙdK¾n!Á A]ISº³·m D¿cenZoXzw IcncInc° an^anboco%w.
IcncIncu\n Abn³ G±tÃâKÁ tXnkodnjou·n hwõeo%Á A]ISº³%w
aew IÄ\o bntXnç D¿cenZoX|=w GtÊâ%ÁXÈ.

uPndo habK¾n!Á

»c¸n epkm»I³%w AXp°dw hwõeo%Á A]ISº³%w, \nf\wº³%w
IcncInc° D¿cenZobnWm I¼\n-bv¡v CXnÂ bm-sXm-cp _m-[y-Xbpw D−-m-bn-cn-¡p¶-XÃ.

ua² ]l¼ Incyº³ °dw GtX¹oêw cpXoboêÉ \nf\wº³

IÄ\oÏíæAÞ,

µÄÈßÏßæÜ

¼àÕÈAÞVæAÞ,

µøÞùáµÞøæa

ÎçxæÄCßÜá¢

¦{áµZæAÞ

D¾n!IbntW¹o²

IcncInc°

¼àÕÈAÞVæAÞ,
AXoÌÉ

\w

]coincw \²uI¾XnWm. I-cm-dp-Imc-sâ sXm-gn-em-fn-IÄ-¡v B-h-iyam-b kpc-£m D]-I-c-W-§Ä \Â-tI-−Xpw, tPm-en k-ab-¯v kpc-£m D-]-I-c-W-§Ä D-]-tbm-Kn¡p¶p-−v F-¶v D-d-¸p-h-cp-t¯-−Xpw I-cm-dp-Im-c-sâ D-¯-c-hm-ZnXzam-bn-cn-¡pw IqSm-sX
I-cm-dp-Im-c³ sXm-gn-em-fn-IÄ-¡v A-h-iy-am-b sc-Pn-kv-{S-j³, C³-jq-d³-kv I-h-td-Pv
F¶n-h F-Sp-t¡-−-Xpw tI-c-f kwØm-\ k-À-¡m-cp-I-fp-sS \n-b-a-{]-Im-c-ap-Å sXm-gn-emfn t£-a \n-[n ^-−p-IÄ b-Ym-ka-bw A-S-t¡-−-Xp-amWv.

<!-- page 6 -->

10. t]nH
Henb an\Z>º;w \o_á
á \ I ;w
1. çµø{ ËàÁíØßæÜ ¼àÕÈAÞæøÞ, çÜÞÁß¢·í
¼àÕÈAÞæøÞ

¥Õøáæ¿

¥¿áJ

_âAtfm

¥YçÜÞÁß¢·í

Õßõn·JßæÜ

Z±Lnho²

ÉæC¿áAáÕÞX

ÉÞ¿áUÄÜï.

2. Icnc·nctÂ

uPndoIjo²
u\cou½n
AÈntXubn
]t¹â%Á
FÈn
uPndo·nçtSÆw BucnKyw, ueX\w, »c¸,te²t^b±, \w]coincw
FÁoetb hw_áo®É uIÞ hwÙn\ h±·nçtSÆw aÊm N½5Inc®É aÊm
GP°hoI³
FÁoeÆtSÆw
\obaº³
Icnc·nc°
\o±_áanÆw
]ndou·¾XnWm.

3. tS¾± \S]So?aº³%É habw ]coKWo®tIn¾m Z±Lnhm HlÁXoÌ ufgw
90 Zoehu¿·m XÁoco%Á Z±Ln»I³·m hn¿XÆ¾nbocou·¾XnWm.

4. Z±Lnhotd eyeÙI³ uõZKXo eçKÁXoÌw "½o uN±%ÁXoÌw \p·w
tNåÁXoÌw Z±Lnhm õnKoIanubn "±Banubn l¥n%ÁXoÌw \oc%I³
hw_áo»m Z±Ln»Inçanbo "SobnudnN\ \S¯p¶-Xn-\p-apÅ A[oIncw
anu\PowKm

Ubl+lo²

\o¸o'anüm.

anu\PowKm

Ubl+ctS

Xpçan\w

AÐoaanboco%w. C¯c-W-¯nÂ IcncInc\m bm-sXm-cphn[ \w]coinc¿oÌw
AeInf®¾nboco%ÁXÈ.

5. I-¼-\nbnÂ tPm-en sN-¿p-¶ I-cm-dp-Imc-sâ sXm-gn-em-fn-I-fp-am-bn tI-c-fm-^o-Uv-kv
en-an-ä-Un-\v sXm-gnÂ Zm-Xmhv, sXm-gn-em-fn F-¶ _-Ô-apm-bn-cn-¡p-¶-XÃ. I-cm-dp-Imcsâ sXm-gn-em-fn-I-fp-sS \n-b-a]-c-am-b A-h-Im-i-§Ä-¡v (C.F-kv.sF, ]n.F-^v ap-Xembh) I-cm-dp-Im-c³ am{Xw D-¯-c-hm-Zn-bm-bn-cn-¡p-¶Xpw A-Xn-se-s´-¦nepw hogv-N
h-cp-¯p-¶ ]£w B\p-]m-Xn-Iam-b XpI I-cm-dp-Im-c-\nÂ \n¶pw I¼-\n Cu-Sm-¡p¶-Xm-bn-cn-¡pw. I¼-\n B-h-iy-s¸-Sp-¶ ]-£w I-cm-dp-Imc-sâ sXm-gn-em-fn-I-fp-sS
\n-b-a-]-cam-b FÃm ]-W-an-S-]m-Sp-I-fp-sSbpw tc-J-IÄ lm-P-cm-t¡−XmWv.

6. uIn®çn+m
Wages

(ud_±

tlYudg° & Au_njog°)

BSotdÆw Minimum

Act udÆw eyeÙI;w ]ndou·¾Hm IcncInctÂ _n[yXbn!è.

AHu]ntd

ae

_n[Ianb

tXnko²

\obaº;w,

eyeÙI;w,

N½º;w

]ndo%en° IcncIncÌm _n[yXbp1m. sXm-gn-em-fn-IÄ kp-c-£m-km-a-{Kn-IÄ D-]tbm-Kn-¡p-¶p-s-−¶v D-d-¸p-h-cp-t¯−-Xpw Bb-Xv I-¼-\n-bn-se \nÀ-±n-ã D-tZym-KØs\ A-dn-bn-t¡-−Xpw {]-kv-Xp-X-I-cm-dp-Im-sâ D-¯-c-hm-Zn-Xz-am-bn-cn¡pw.

7. IcncInctÂ 5?¿oI³ J'oIcaÈn¿ ]¸w ®Álobo/ "SntX XtÁ Icn±
l¦

tNåÁHw

AS¦Â

XpI

I1tIåÁH³tÃtSÆÉ

\S]SoI³

<!-- page 7 -->

h|pIco%ÁHanboco%w. 5uXyI hniNcyº³ IW·otdâ¿m Hç anh¿o²
!lbn¿ Indbjeo² u\n½p» \ío Icn± Aehn\oÃo%ÁXoÌw IÄ\o·m
A[oInc®¾nboco%w.

8. 5ÓX Icnlot\ hw_áo%Á FÈn \oba]canb \S]SoI;tSÆw ]co[o
Ccoºnd%S ®°ho^m uInSXobodnbocoÍw.

9. ua²]l¼ uPndoIjo² ®°]coNb®É ey2oIjo² / Ùn]\ºjo² \oèw,
"coÃo» I|u½gÌI³ 21.10.2026 \m 2.00 pm Ìjjo² dõou·¾XnWm.
I|u½gÌI³ AuÁ Zoehw 2.30 pm \m Hl%ÁXnboco%w. \oLoX hab¿oÌm
ufgw \²!Á I|u½gÌI³ h|pIco%ÁXÈ.

10. CHanbo _átÃ½ FÈn eoecº³%w t5nU¸° UoÃn±åtaøanbo
_átÃuS¾XnWm.

<!-- page 8 -->

Annexure – I

Sl. No

Description of work

2 Ton & 3 Ton Boiler
1. Fittings dismantling, cleaning & re-fixing
2. Fire tube cleaning
3. Water and Fire side opening, cleaning & closing
4. All valves reconditioning and re-fixing
5. Brick and clay work inside Boiler (If necessary)
Fusible plug changing as per recommendation of Boiler
6.
Inspector (If necessary)
7. Painting (If necessary)
8. Open test and Hydraulic test (by Boiler Inspector)
9. Obtaining License
10. Duct Cleaning
11. Chimney Cleaning

Technical Details :
 IAEC: 3000kg/hr, 74m2 , Max. Pre : 10.7kg/cm2 , 70 Fire Tube
 Thermax: 2000kg/hr, 46m2, Max. Pre. 10.54kg/cm 2 , 90 Fire Tube

<!-- page 9 -->

Annexure - II
DECLARATION
(To be given separately by each constituent firm in the case of Partners / Associates)
1. I, the undersigned do hereby certify that all the statements made in the

attachments are true and correct.
2. The undersigned hereby authorized and requests any Bank, person, Firm or

Corporation to furnished pertinent information deemed necessary and requested
by KFL.
3. The undersigned understands and agrees that further qualifying information may

be requested, and agrees to furnish any such information at the request of KFL.
4. The undersigned also hereby certifies that neither our Firms /Companies / Joint

Ventures / Associates have abandoned any work in India nor any contract
awarded to us for such work has been rescinded in the past Two years.
5. The undersigned also hereby authorize KFL and their authorized representative to

conduct any inquiries or investigation to verify the statements, documents and
information submitted in connection with this application, and to seek
clarification from our bankers and KFL regarding any finical and technical
capability. This will also serve as authorization to KFL representative to contract
in person or otherwise, any individual or authorized representative of any
institution referred to in the supporting information and obtain such information
as may be required by him to verify statements and information provided in this
application, or with regard to the resources, experience and competence.
6. The undersigned understands that furnishing of false information could result in

my disqualification.
7. The undersigned also hereby commit that I am not a KFL Employee / Loading /

Unloading worker. I also I am not an immediate relative of any of the above
mentioned people.

Name & Signature of Bidder :
Date :

<!-- page 10 -->

Annexure - III

DECLARATION

I/We, ________________________________, hereby solemnly declare that we have
obtained and possess all statutory registrations, licences, permits and approvals required
for the execution and performance of the Contract with the Company.

I/We further undertake to take all necessary measures to ensure that such registrations,
licenses, permits and approvals remain valid and in force throughout the period of the
Contract.

I/We also undertake to promptly inform the Company in writing in the event of any such
registration, licence, permit or approval being cancelled, suspended, revoked, expired or
otherwise rendered invalid during the currency of the Contract.

Date :

Signature:

Place :

Name:

<!-- page 11 -->

KERALA FEEDS LIMITED

uIcj ^pUmhm doaoÊUm
ItÃ-äpwIc- - 680683

(õnKw - II, èdÉØí _oìm)

1

<!-- page 12 -->

KERALA FEEDS LIMITED

KERALA FEEDS LTD.
(A Govt. of Kerala Undertaking)
Kallettumkara, Thrissur Dist. Pin: 680 683.
Phone : 0480-2713555, Fax : 0480 -2720194

07.10.2026
To
THE MANAGING DIRECTOR,
KERALA FEEDS LIMITED
Kallettumkara
Thrissur

h±,
Rn°/ Rº³, IÄ\oboêÉ Furnace oil – Fired, Horizontal - Fire Tube (2000 kg/hr Thermax make, 3000kg/hr – IAEC make) t_m-bv-edpIfpsS ASp¯ c−v hÀ-j-Im-e-b-fhnÂ h-cp-¶ IBR \nba{]-Im-c-ap-f-f hmÀjn-I operational license ]p-Xp-¡p-¶-Xn\pw A-Xn-sâ
`m-K-am-bn sN-t¿-−n-h-cp-¶ sa-bvâ-\³-kv {]-hr-¯n-IÄ \S-¯n hmÀjn-I ]-cn-tim-[-\-bv-¡v
t_m-bn-e-dpI-sf k-Ö-am-¡p-¶-Xn\pw Hydraulic & Open test \S-¯n license e-`y-am-¡p-¶Xn\pw ue¾oÆÉ Z±Lnho² \²Ioboco%Á \o_á\I³ ]ndo®tIn¾m I|u½g°
ha±Ão®tIn=è.
Rn°/ Rº³, ZÀ-Lm-kv t\m-«o-kv {]-Im-cw ASp¯ 2 hÀ-j-¯n-\p-ÅnÂ h-cp¶ t_m-bv-e-dp-I-fpsS \nb-a-]-cam-b hmÀjn-I ]-cn-tim-[-\-bv-¡v th-−n-bpÅ sa-bvâ-\³-kn-\v th-−n-bp-Å \n-c-¡vv
Rm³ / R-§Ä k-aÀ-¸n-¡p¶p.

{Ia
\-¼À
1.
2.

XpI

hÀ-¡v

(Hcp hÀ-j-t¯¡v)

2 Ton Boiler
3 Ton Boiler

sam-¯w XpI (GST DÄs¸sS)
(A¡¯nÂ ...................................................................................................................................)
Thanking you,
Yours faithfully,
Name & Address
:
Signature of Tenderer / Authorized representative

Date:

2
