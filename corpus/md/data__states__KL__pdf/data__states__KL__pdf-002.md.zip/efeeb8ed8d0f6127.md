---
doc_id: "efeeb8ed8d0f6127"
source_url: "https://www.cetkr.ac.in/uploads/Tender.pdf"
ministry: "College of Engineering Trikaripur, Kerala"
title: "New    Tender Notice for Electrification of Additional Classrooms"
date: ""
pages: 1
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "40f7d039390309e5"
---

<!-- page 1 -->

NOTICE INVITING TENDER (e- tender]
Name of work: Electrification for additional class rooms in existing Academic Block No.
3 at College of Engineering, Trikkaripur
Tender no. :01/2024-25/CAPE dated 01.08.2024
Tender reference No : 2024_CAPE_683178_1
Competitive bids (Percentage rate) are invited on behalf of the Principal,
College of Engineering, Trikkaripur) (THE OWNER) for the Electrification for
additional class rooms in existing Academic Block No. 3 at College of Engineering,
Trikkaripur possessing appropriate class of registration in Kerala State Electrical
Inspectorate /CPWD/Kerala PWD for executing this work. The details of contract
together with the estimate cost are given under
1.01 Owner /Employer -Principal, CE, Trikkaripur
1.02 Engineer - Project Director/Assistant Engineer
(Electrical), CAPE
Consultant - CAPE
Site Engineer - Assistant Engineer (Civil) College of
Engineering, Trikkaripur
1.03 The Project contract mainly include the following
ab Electrification of additional class rooms in Academic "| Rs. 5,30,335/-
Block No. 3 at College of Engineering, Trikkaripur
1.04 Location of work and site conditions
Tender No. Location and Terrain Type of soil and subsoil
condition
W-01/2024-25/CAPE Trikkaripur Laterite
dated 01.08.2024
2. Brief description of work ; — Electrification of additional class rooms in Academic
: ; Block No. 3 at College of Engineering, Trikkaripur
2. Bid Security + Rs. 13,300/-
3. Bid submission fee (tender fee)
: Rs. 600+ GST
4. Period of completion :  30days
5. Classification of Bidder : ആഞ്ഞ
6. Last date and time for :
submission of bids >, $2108:2026 4.00 pm
7-seteand time of + 16.08.2024 at 3.00 PM
opening of tender
Prince.
College’of | ngineering
Trikaripur, P.O Cneemeni
Pin 671313 ;
Ke
