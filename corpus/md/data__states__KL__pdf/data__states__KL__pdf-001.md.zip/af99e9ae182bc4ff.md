---
doc_id: "af99e9ae182bc4ff"
source_url: "https://keralaagriculture.gov.in/wp-content/uploads/2022/11/Agri-Dev-Policy_compressed-1-1.pdf"
ministry: "Agriculture Development and Farmers Welfare Department, Keral"
title: "Agri Policy"
date: ""
pages: 214
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0d68e86837c29c0a"
---

<!-- page 1 -->

<!-- page 2 -->

<!-- page 3 -->

<!-- page 4 -->

GOVERNMENT OF KERALA

AGRICULTURAL
DEVELOPMENT

POLICY

2015

<!-- page 5 -->

Agricultural Development Policy
2015
Prepared by:
Sri. K. Krishnankutty, Chairman, Sub- Committee
Sri. R. Hali, Director of Agriculture (Rtd.) - Member
Dr. P. Rajasekharan, Chief (Agri.), State Planning Board - Member
Dr. P.V. Balachandran, Director of Extension, KAU - Member
Dr. K.G. Suma, Director of Animal Husbandry - Member
Sri. R. Ajithkumar, Director of Agriculture - Convenor
Sri. A.K. Madhavachandran, Joint Director (Agri. Farms) - Joint Convenor

Officers on duty:
Sri. G. Ajithkumar, Agricultural Officer
Sri. Manoj S., Agricultural Officer
Dr. E.G. Prem Jain, Assistant Director (AH)
Sri. Arun T.T., Agricultural Officer
Design & typeset:
Manoj S., Agricultural Officer
Media Support

Greentouch Farm Media,
Agri - Clinic & Agri - Business Centre
Thiruvananthapuram

<!-- page 6 -->

CONTENTS
Preface - Towards a dynamic agriculture...

1

01. Introduction

15

02. General background of the State

18

03. A new wave policy for agriculture

20

04. Definitions

21

05. Introduction to policy reforms

22

06. Policies related to land

23

6.2 Policy 1: The farm lands are to be protected and should not be put for any other
use than farming activities.
6.3 Policy 2: The agriculturally potential land is to be identified and demarcated
with the help of modern technologies such as remote sensing, satellite
imagery, etc., and a database is to be made.
6.4 Policy 3: The transactions on farmlands are to be made more transparent for
protecting the interests of farmers
6.5 Policy 4: Cultivable wastes should be brought under plough with immediate
effect for augmenting the food production.
6.6 Policy 5: Land owned by Kerala Agricultural University, Department of
Agriculture, Department of Animal Husbandry, Department of Dairy,
Veterinary University etc., should not be put for any other use than the
purposes for which it was intended for.
6.7 Policy 6: Appropriate legislative mechanism may be evolved for the promotion
of 'Rent a Land for Farming' programmes.
6.8 Policy 7: Necessary administrative mechanism may be evolved for bringing the
different agencies connected with land related activities under one coordination agency.
6.9 Policy8: The Government should have the aim of employing InformationTechnology
to transform the existing system of land records maintenance and thereby
ensuring efficient, accurate and transparent delivery mechanism and conflict
resolution in ownership of land.
07. Water related policies
7.6 Policy 9: Preservation and sustainable use of water should be the motto of all crop
production programmes of the state.
7.7 Policy 10: Water budgeting should be adopted in a watershed basis.
7.8 Policy 11: Rain water harvesting and aquifer recharge would be given priority
for ensuring the stability and supply of water.
7.9 Policy 12: The micro-irrigation technology is to be popularised in the state with
adequate share of state budget.

26

<!-- page 7 -->

7.10 Policy 13: Farm ponds and Thalakkualams needs to be promoted and protected.
7.11 Policy 14: Sub surface dykes are to be constructed at possible places for the
ground water recharge
7.12 Policy 15: The irrigation canals of Kerala are to be structurally reset for the
prevention of seepage loss of water.
7.13 Policy 16: The activities of the Committee on the release of irrigation water
should be in deeds than in words.
7.14 Policy 17: Pumping subsidy provided to the Kuttanad and Kole land farmers
are to be routed through the Department of Agriculture.
7.15 Policy 18: All interstate water sharing g agreements have to be timely reviewed
to promote thrust areas of irrigation development.
7.16 Policy 19: Irrigated agriculture being the largest water demanding sector,
special attention has to be given for creating and sustaining irrigation
infrastructure.
08. Soil related policies

31

8.3 Policy 20: Bio-Manure production is to be enhanced for reviving the soil health
and should be one of the primary activities of the Department of
Agriculture.
8.4 Policy 21: The production potential of the soil is to be improved.
8.5 Policy 22: The first week of June of every year shall be observed as 'Green
Manure Week' by the State Government for the promotion of green
manuring methods and green manure crops.
8.6 Policy 23: A cadastral Level soil information system is to be launched
8.7 Policy 24: Make every effort to reduce soil erosion on a watershed basis.
8.8 Policy 25: Steps should be take to develop regional nutrient plans on a watershed
basis preferably.
09. Climate & environment related policies
9.4 Policy 26: Research & Development initiatives are to be strengthened in climate
change adaptation for sustenance of agricultural production in the State
of Kerala.
9.5 Policy 27: Network of meteorological observatories should be increased.
9.6 Policy 28: There is a need to train skilled personnel in the field of climate
change adaptation and mitigation.
9.7 Policy 29: Optimize the ecological load on the natural systems as well as building
up the State's economy while minimizing environmental degradation.
9.8 Policy 30: The Government should make a focussed approach to facilitate the
possibility of strategic planning for systematic Disaster Management,
as well as for contingency planning at District, Block and Grama
Panchayat levels against all emergencies, pro-actively (for preparedness,
prevention and mitigation) and responsively (for response, relief,
repatriation, rehabilitation, reconstruction, the whole way to recovery
in the full Disaster Cycle).

33

<!-- page 8 -->

10. Policies related to watershed development approach

35

10.2 Policy 31: Agriculture planning and development programmes of the state
shall be based on watershed.
10.3 Policy 32: It is the responsibility of the state for water management / water
poverty.
10.4 Policy 33: The watershed development plans are made to improve rural
livelihoods and reduce poverty by developing and strengthening
community based approaches.
11. Policies to address farmers in distress

36

11.6 Policy 34: The Government should take earnest steps to instill confidence in
the debt-ridden farmers for the prevention of farmer suicides for ever
by the introduction of 'relief funds' or 'relief loans' so that the immediate
financial requirement can be met by them.
11.7 Policy 35: The approach of the financial institutions needs to be changed
while attempting for recovery from the debt ridden farmers and an
integrated resource base analysis and separate fringe credit support
for them should be extended so that they would be brought above the
repayment threshold level.
11.8 Policy 36: The loans taken by the real and full time farmers for their needs like
housing, medical treatments, marriages, children's education and other
unavoidable consumption needs are also to be treated as agricultural
loans as the repayment is to be made from farming.
11.9 Policy 37: There is a need to strengthen the Mental Health Programmes at
primary health care level, involvement of extension officials and
institutions so as to offer support and counselling to vulnerable farmers.
12. Farmer & farm labourer welafare related policies
12.3 Policy 38: The Pension Scheme for farmers will continue
12.4 Policy 39: As agricultural development and farmer welfare are inseparably
linked, a farmer welfare fund board is to be established.
12.5 Policy 40: There is a need to promote comprehensive health insurance schemes
for farmers.
12.6 Policy 41: Agriculture labour banks will be started at Panchayat level to
address the issue of shortage of agricultural labourers.
12.7 Policy 42: A production incentive should be awarded to the farm laboures
who works in the agriculture sector for not below than 100 days.
12.8 Policy 43: Sufficient number of seats in professional courses should be reserved
for the children of farmers so as to improve their social status.

40

<!-- page 9 -->

13. Policies related to human resource development in farm sector

42

13.4 Policy 44: Improved agricultural productivity depends on agricultural education
and competency-based trainings and are essential for building the human
resource capacity.
13.5 Policy 45: Develop the extension personnel of the state to meet the knowledge
& skill requirements of farmers as self-reliant agri-prenures.
13.6 Policy 46: Empowering the small farmers in order to have say in policy matters
of government in agriculture sector would pave a way for better
development.
13.7 Policy 47: It will be required to make necessary changes in the systems to
provide scientific and technical knowledge and skills in agricultural
operations to the input dealers, so that they may advise farmers in right
direction & provide valuable extension services to farmers specially to
small & marginal farmers
13.8 Policy 48: Extension personnel of the state will have to acquire latest knowledge
as well skills in use of various electronic devices such as computers,
multimedia, internet etc.
13.9 Policy 49: The Human Resource Development of the extension functionaries is
to be done scientifically and time bound.
14. Policies related to ICT application
14.5 Policy 50: Immediate steps are to be taken to materialise the concept of
'Paperless Offices' in the case of Krishi Bhavans to assure services
with 100% fastness and accuracy.
14.6 Policy 51: The planning process should be based on the real-time data
generated with the help of modern ICT tools and State Agriltural
Plan is to be developed every year
14.7 Policy 52: When ICT enabled technologies are made popular, Concentrate
on the demand, not on the technology.
14.8 Policy 53: The Call Centers are to be made efficient.
14.9 Policy 54: Farmer databases are to be made perfect.
14.10 Policy 55: Provide need-based ICT training at all levels, but especially to
youth, women and marginal farmer groups.
14.11Policy 56: Necessary mechanism should be evolved for providing the
market information to the farmers on a realtime basis with the help
of ICTs
14.12 Policy 57: The modern ICT tools are to be modelled in such a way that it
should provide information about rural development programmes
and subsidies to farmers.
14.13Policy 58: ICT enabled weather forecasting services, input prices and
availability, early warning of diseases and pests and soil testing &
soil sampling information are to be provided by SMS services.
14.14 Policy 59: There should be initiatives for the application of technologies
such as 'Tele Presence' and 'Google Glass' for the conferences ,
technology refinement and transfer.

45

<!-- page 10 -->

15. Policies related to technology dissemination and management

50

15.2 Policy 60: Extension Services are to be made more efficient
15.3 Policy 61: Demand led extension is the need of the hour.
15.4 Policy 62: Group approach should be the motto in all the extension activities of the
state.
15.5 Policy 63: The development of close co-operation between extension agencies
and formal research institutes is essential if farmers are to be provided with
the services they require.
15.6 Policy 64: The existing system of extension activities are to be put under one single
body so that the services to farmers can be done efficiently.
15.7 Policy 65: The new face extension should provide integrated environmental support
15.8 Policy 66: Improved productivity of livestock and improved quality of the livestock
keepers are possible only if policies focus directly on people and policy
instruments are directed towards building their capacities for vibrant,
competitive, informed and responsible participation in very aspect of the
livestock sector.
16. Policies related to markets and marketing

54

16.4 Policy 67: Efficient marketing infrastructure such as wholesale, retail and assembly
markets and storage facilities is essential for cost-effective marketing, to
minimise post-harvest losses and to reduce health risks.
16.5 Policy 68: Reforms needs to be made in such a way that common marketing
infrastructure is created in all major production centres under the direct
control of producer organizations
16.6 Policy 69: The twin goals of ensuring justice to farmers in terms of a remunerative
price for their produce and to consumers in terms of a fair and affordable
price for food would be achieved through the establishment of 'AMUL'
model outlets for the procurement and distribution of agricultural produces.
16.7 Policy 70: A separate Agricultural Marketing wing may be set up under the
Department of Agriculture for the better infrastructural developments.
16.8 Policy 71: A perfect market intelligence system should be developed with the help
of modern ICT tools and techniques.
17. Policies on international trade related issues
17.4 Policy 72: The WTO cell of the Department of Agriculture needs a reorganisation
and made funcionally and professionally independent.
17.5 Policy 73: Equipping the farmers to produce the products with international standards
and value added products to get an uniformity in production will sort out
problems faced by farmers FTAs to a greater extent.
17.6 Policy 74: Terminal markets are to be watched carefully for the entry of restricted
agro-produces in the disguised forms and strict ban on such items should
be executed to protect the interests of the farmers.
17.7 Policy 75: Create Programmes supportive of small farmers and sustainable
agriculture to save the livelihood of farmers.

58

<!-- page 11 -->

18. Policies related to FPOs

61

18.3 Policy 76: FPO must be a body registered and administered by farmers and
the organisation must be focused on activities in the agriculture and
allied sectors.
18.4 Policy 77: State Government should take up formation of FPOs on a large
scale through Centrally-sponsored and State-financed programmes and
schemes.
18.5 Policy 78: FPOs must be based on the values of self-help, self-responsibility,
democracy, equality, equity and solidarity.
18.6 Policy 79: The Government should make 'Hand Holding Support' to FPOs by
taking policy decisions and providing expert management man power.
18.7 Policy 80: The FPOs are to be designed in such a way as to provide 'end to
end' services to its members.
18.8 Policy 81: The State Government may appoint SFAC as the Resource Institution
(RI) for the promotion of FPOs.
18.9 Policy 82: The formation of FPOs are to be done in a scientifically organised
basis so that sustainability of the same should be ensured.
19. Policies related farm mechanization
19.4 Policy 83: Encourage custom hiring operation of tractors, power tillers and farm
machinery through training, financial incentives, subsidized loans and
adequate financing to allow procurement of high capacity equipment by the
custom operator to ensure sufficient turn over and income.
19.5 Policy 84: Financial incentive should be provided for replacement of inefficient
equipments by improved tools and implements
19.6 Policy 85: The State should develop strategies and approaches for optimum
involvement of extensionists, researchers, development agents, and the
eventual users of the technology as a unified body for the fast and effective
farm mechanisation.
19.7 Policy 86: Developing human resources and generation of self-employment by way
of providing skill-oriented training in the farm mechanisation sector is
important.
19.8 Policy 87:Agricultural mechanization strategy ought to clearly define the roles of the
private sector and that of the state.
19.9 Policy 88: Availability of machinery, equipment, spare parts and other supplies is
essential for successful and sustainable mechanization.
19.10 Policy 89: To reduce drudgery and improve human labour productivity, there is a
need to improve the design of existing tools and machineries.
19.11 Policy 90: Pollution free mechanization practices that conserve natural resources
such as land, water and soil nutrients need to be promoted.
19.12 Policy 91: Farm mechanisation is a part of agricultural extension.
19.13 Policy 92: The agricultural machineries and implements shall be exempted from
import duty and value added tax (VAT) in order to reduce the cost.
19.14 Policy 93: The installation of solar, wind and hybrid technology based high volume
output pumps along the bunds of these Padasekaharams so that the power
consumption and cost of cultivation could be minimised.

67

<!-- page 12 -->

20. Policies related to income assurance and crop insurance

71

20.5 Policy 94: An Actio Apportum is to be introduced for the first time for assuring the
farmers a legal demand of right for sharing revenue or profit generated out of
the farm produce when it is traded.
20.6 Policy 95: A price fixation authority should be formed for fixing the price of the
agricultural commodity in the state, so that protection from price falling
would be enabled.
20.7 Policy 96: Minimum Support Price (MSP) for paddy, vegetables, banana and
spices may be announced during the commencement of the season by
the state Government with the help of the Price Fixation Authority.
20.8 Policy 97: An Agricultural Risk Fund may be formed with the objective of
providing immediate assistance to farmers at the time of emergency.
20.9 Policy 98: The Agricultural Prices Board will be strengthened with broader
guidelines.
20.10Policy 99: Government should adopt 'Income Guarantee' programmes for the
farmers as the main agricultural support instrument and an Act in this
line should be passed.
20.11. Policy 100: The views of the farmers should also be taken in to account while the
regulations on the management of threspassing animals in the farm lands
causing crop loss.
21. Agricultural credit policies
21.4 Policy 101: Increase flow of credit to farmers including small and marginal,
triggering agricultural growth led economic progress, which can lead to
opportunities for a healthy and productive life to rural families.
21.5 Policy 102: The SHG Bank Linkage programme is the most appropriate financial
mechanism to extend credit to marginal farmers.
21.6 Policy 103: All the District co-operative banks functioning in the state should
apportion a sizeable portion for agricultural loans.
21.7 Policy 104: Interest free loans will continue.
21.8 Policy 105: Livelihood finance, which is a comprehensive approach to promoting
sustainable livelihoods for the poor, is the need of the hour.
21.9 Policy 106: The loans taken for poultry, dairying and animal husbandry are also
to be treated as agricultural loans.
21.10 Policy 107: An 'Agricultural Credit Relief Fund' is to be formed for addressing
the waiver of loans in the event of natural calamities.
21.11Policy 108: Take an integrated credit requirement approach combining farm
and consumption needs and has to be adopted by the financial institutions.
21.12 Policy 109: Necessary mechanism should be evolved from the part of the
state Government in the light of restrictions imposed on Primary
Agricultural Co-operatives (PACs) in dealing with agricultural credit very
recently by the Reserve Bank of India (RBI).
21.13 Policy 110: The agricultural credit must be monitored from the time of disbursal to
the repayment.

75

<!-- page 13 -->

22. Policies for crop husbandry
22.8 Policy 111: Kerala cannot afford any more conversion of paddy lands, ecologically
or economically.
22.9 Policy 112: Among the strategies for increasing rice production in the State,
area expansion needs immediate attention.
22.10 Policy 113:The current productivity of 2.30 t / ha of rice has to be increased to
4.0 t / ha so as to achieve the production target of 12.0 lakh tonnes of
rice from 3.0 lakh ha. within a span of five years
22.11 Policy 114: Rice farming has to be made more remunerative to attract more
farmers for which measures to augment income from rice based farming
has to be formulated
22.12 Policy 115: Considering the food security point of view and the environmental
benefits of paddy cultivation, the land area ceiling of 2 ha. has to be
raised to 5 ha. for availing the input and financial assistance of the
Government Schemes
22.13 Policy 116: Paddy farmers are to be provided with incentives comparable to
that of fruit plants and industrial crops.
22.15 Policy 117: Since the import of edible oils affects the price of the coconut adversely,
the State Government has to pressurize the Central Government for setting
up a frame work, so that the farmers would get remunerative price for coconut
oil, even if the import of edible oil is happening.
22.16 Policy 118: Introducing dwarf varieties in at least 25% of the new trees or
through under-planting in the existing coconut gardens for meeting the
ever growing requirement of the State's Official Drink - the tender coconut
water.
22.17 Policy 119: The long cherished dream of producing 'Neera' by the coconut
farmers of the State is to be materialised for improving their income.
22.18 Policy 120: A new platform that would bring farmers, processors and retailers
together have to be launched to link agricultural production to the market,
to maximise value addition, minimise wastage and boost farmers' income.
22.20 Policy 121: 'Safe to eat' branding programme for vegetables is to be introduced
for assisting the domestic production and attracting more consumers so
that the farmers get more demand for their produce
22.21 Policy 122: Homestead farming of vegetables and popularisation of vegetable
gardens in schools proved the impact on the increased vegetable
production in the state and the programmes should continue.
22.23 Policy 123: Since more than 70 per cent of banana cultivation is done on
leased lands by resource-poor farmers, obtaining maximum income from
a unit area under cultivation assumes utmost importance.
22.24 Policy 124: By-product utilisation and product development should be given
preference for assuring steady income from banana cultivation.
22.26 Policy 125: The government should develop a 'Mango Export Zone' in
Muthalamad due to the early bearing nature, it could be exported at high
prices.
22.27 Policy 126: Kerala is well known for some traditional mango varieties and the
germplasm of them are to be protected and a research station under KAU
should be set up for mango at Muthalamada.

78

<!-- page 14 -->

22.28 Policy 127: Since climate plays an important role in the production of quality
mangoes, an advisory system should be developed to protect the quality
and production.
22.29 Policy 128: A separate insurance and supporting scheme for mango in the event
of crop loss has to be built up.
22.31 Policy 129: Promoting tubers as an alternative to cereals will augment
food security.
22.32 Policy 130: Tuber 'minikit' programmes are to be introduced for promotion
of roots and tubers in the homesteads.
22.33 Policy 131: Tubers could be used to produce quality cattle-feed, thus
bringing more profit to the farmers.
22.34 Policy 132: Exploit the new technologies, new variety of crops and biopesticides developed by institutions such as the CTCRI based on tuber
crops so that the State can be self-sufficient in food and can reduce
its dependence on other States
22.35 Policy 133: Demonstration of improved production technologies such yam
minisett technique, yam staking methods, root/tuber based crops
mixtures are to be adopted in departmental farms and farmers' fields.
22.36 Policy 134: Nucleus planting material production of improved varieties of
tubers are to be carried out at Departmental farms.
22.37 Policy 135: Processing and value addition of tuber crops is to be treated as
a priority area.
22.40 Policy 136: Area under pepper crop in the state is to be extended on a war
footing to cater the domestic and international demand
22.41 Policy 137: Availability of sufficient quality planting material is to be assured
for guaranteed production and productivity.
22.42 Policy 138: A serious attention as until new and diversified export markets
are not exploited, the farmers would face crash in farm gate price
due to the surplus stock.
22.43 Policy 139: A support price mechanism for the pepper crop is to be
introduced for meeting the vagaries of price volatility.
22.45 Policy 140: The area expansion programme of nutmeg is to be done with
caution, since the price of the produce began to show a declining
trend.
22.47 Policy 141: If measures are not initiated soon, Cochin ginger and Alleppey
turmeric will soon be crops of the past.
22.48 Policy 142: Measures for encouraging ginger cultivation should be oriented in
the context of regional disparities and location specific strategies are to
be made.
22.49 Policy 143: Institutional arrangements should be made to provide quality seeds
and other package of inputs to the farmers to boost the output of ginger.
22.50 Policy 144: Since there is only limited scope for increasing area under ginger in
Kerala as a monocrop, the existing potentialities of cultivating ginger as
an intercrop in coconut, arecanut and young rubber plantations may also
be exploited to the maximum possible extent.
22.51 Policy 145: To protect cultivators from incurring loss the Government should
announce a support price for ginger.

<!-- page 15 -->

22.52 Policy 146: Technological upgradation of processing is very much essential to improve
the quality of dry ginger.
22.55 Policy 147: The policy initiatives towards promotion of cashew growers' FPOs (for
procurement of raw nuts, supply of inputs, credit and infrastructure, small
scale processing, value addition and marketing), and cashew apple processing
will definitely widen the perspective of cashew growers.
22.56 Policy 148: The Cashew Corporation should enter the market to prevent owners of
private cashew processing units from controlling the procurement price.
22.57 Policy 149: There is a need to increase domestic production to substitute imported
raw nuts in order to derive the maximum benefits from a strong processing
and marketing capability developed over the years by the cashew industry.
22.58 Policy 150: Value addition and product diversification should receive adequate
attention of the Government for having competitive edge and higher
returns in the years to come.
22.59 Policy 151: Production and productivity of cashew in the state can be enhanced
through a phased replanting programme.
22.60 Policy 152: All the Cashew development agencies are to be effectively co-ordinated
under the Department of Agriculture.
22.62 Policy 153: Standardization of technology to bring down cost of production of
fresh pineapple and its adoption by growers, and technology to produce
pineapple throughout the year may go a long way in promoting pineapple
cultivation in Kerala.
22.63 Policy 154: Steps should be taken to popularise pineapple cultivation as an intercrop
in the coconut gardens and rubber plantations to increase the production and
income of the farmers.
22.64 Policy 155: The marketing of pineapple needs immediate attention as to improve
the export potential of the crop for assuring better returns to farmers.
22.66 Policy 156: Establishment of model nurseries should be done in the state either
in the public and or in the private sector to address the issue of shortage
in the availability of new and good quality planting materials which is the
most important limiting factor in the development of floriculture in Kerala.
22.67 Policy 157: Traditional Flower FPOs are to be established like cut flower
growers' association for traditional flower growers.
22.68 Policy 158: Specific attention is to be given to the development of traditional
flowers by assisting traditional farmers in terms of bank loans, proper
marketing facilities, and dissemination of information through training
and media support on improved varieties.
22.69 Policy 159: An insurance mechanism for the floriculturists against natural
calamities of the state is to be formulated.
22.70 Policy 160: It is emphasized that the subsidies on poly/green-house, planting
materials and specialized equipments should continue.
22.71 Policy 161: Efforts should be made to encourage small stakeholders to patronize
flower cultivation for enhancing their income and employment avenues.
22.73 Policy 162: New avenues like contract farming and forest farming are to be explored
as sustainable way to ensure the steady and constant supply of quality raw
materials for drugs.
22.74 Policy 163: In order to initiate systematic cultivation of medicinal and aromatic
plants high yielding varieties have to be selected.

<!-- page 16 -->

22.75 Policy 164: Efforts to develop, use and promote the green technology for a
sustainable production system of Medicinal and Aromatic Plants are to be
made.
22.76 Policy 165: Small and marginal farmers will be organised into Self Help Groups
and cooperative societies of medicinal plants growers or as producer
companies to enable them to take up medicinal plants cultivation
22.78 Policy 166: Increasing fodder production and availability within the state through
the intervention of co-operatives, SHGs and FPO's should be explored.
22.79 Policy 167: The State Government, in collaboration with agricultural universities
and research institutes, will be responsible for developing, promoting and
extending nutritious and high yielding varieties of fodder species for cultivation
on agricultural lands.
22.81 Policy 168: There must be programmes to reintroduce minor millets to regions
where they were once more popular.
22.83 Policy 169: There must be programmes for promoting pulses in the traditional as
well as no traditional tracts utilising the paddy fallows.
22.85 Policy 170: There should be programmes to increase the number of bee hives
from the present 6 lakh numbers to 30 lakh numbers in five years.
22.86 Policy 171: Bee keeping should be promoted as a vocation for women, youth,
marginal farmers and self help groups and the number of bee keepers
are to be doubled to two lakhs from the present one lakh and the concept
of 'Honey Villages' has to be put in to reality.
22.88 Policy 172: On no account area under plantations should be used for growing any
crop which is not notified before.
22.89 Policy 173: The rate of lease on Government land given for plantation purpose
should be scientifically revised in every five years.
23. Policies for livestock development
23.2 Policy 174: The farmers of the state would be helped for the improvement of
their present resources by assessing the present potential of the livestock
status and employing an 'Animal Performance and Control' mechanism
to monitor, evaluate and upgrade the livestock population of the State.
23.3 Policy 175: All the livestock farmers of the state should be provided with 24
hour Veterinary Emergency Assistance Service.
23.4 Policy 176: The farmers of the State would be assured with a livestock
population free of all the contagious diseases by universal vaccination
and necessary steps would be taken to declare as Animal Disease Free
Zone.
23.5 Policy 177: The farmers of Kerala are to be provided with yield and sex
assured animals as a result of the cross breeding Programme.
23.6 Policy 178: The low yielding animals of the State must be used as Foster
Mothers' for the production of improved breed by the embryo transfer
technology.
23.7 Policy 179: The farmers of the State may be allowed to rear indigenous and
accepted breeds of cattle for conservation purpose with guidelines from
the Department of Animal Husbandry.
23.8 Policy 180: The farmers of the state are to be assured with one calf per year per
animal.

109

<!-- page 17 -->

24. Policies related to animal nutrition

114

24.2 Policy 181: Every calf born in the state out of cross breeding programme should be
guaranteed a well balanced feed to utilise the genetic potential of the calf for
converting in to economic value.
24.3 Policy 182: Male calf fattening programmes are to be taken up by the Government for
assuring nutrition to the male calves and for assuring wholesome meat to the
consumers and thereby assuring better returns to the farmers.
24.4 Policy 183: The farmers of the state must be assured of getting quality cattle feeds and
feed for other classes of livestock.
24.5 Policy 184: Fodder cultivation should be promoted on a mission mode on a commercial
scale to ensure its availability to the farmers at affordable cost.
24.6 Policy 185: Area specific mineral mixture for dairy cattle should be formulated and
made available to the farmers in order to correct mineral deficiency and effect
production enhancement.
25. Policies related to mechanization in animal husbandry and dairy

118

25.3 Policy 186: Portable milking machines should be provided to milkers and farmers for
the production of better quality milk in a shorter period and preventing the
spread of contagious and managemental diseases.
25.4 Policy 187: Chaff cutters are to be provided to farmers for the better utilisation of crop
residues and minimising the cost of production.
25.5 Policy 188: Automatic drinkers are to be established in each and every farm for ensuring
production and improving animal health.
25.6 Policy 189: There must be steps at least to prevent the hoof ailments and accidents
happening to cattle in their sheds thereby reducing the veterinary costs and loss
of production.
26. Policies for quality improvements in animal food production

120

26.4 Policy 190: The potential for milk purchasers to misrepresent the quality of the milk and
cheat farmers out of a fair price would be eliminated by the introduction of the
Automatic Milk Collection System.
26.5 Policy 191: The meat sold in Kerala should originate from an approved slaughter house.
Cleanliness at slaughter minimises the potential risk to human health, contributes
to the production of safe meat, improves the shelf life of the meat, and consumer
confidence.
27. Policies for increasing profitability in animal husbandry
27.4 Policy 192: The dairy cooperatives and Departments of the Government related to
dairy development have to plan programmes to attract youth and sustain the
present farmers towards dairy farming and dairy based enterprises.
27.5 Policy 193: A good incentive plan recognizes that individuals can make a real difference
in the operation and its profitability

122

<!-- page 18 -->

27.6 Policy 194: Since the farm sector aims at food security of the state, there must be an
immediate end to the "division" of people on the lines of below poverty line (BPL)
and above poverty line (APL) for receiving the financial assistances in the Animal
Husbandry sector.
27.7 Policy 195: Input allocation plans of the Animal Husbandry sector must be in line
with the holding capacity of the locality so as to develop a sustainable strategy
for 'zonation of inputs'.
27.8 Policy 196: The present method of calculation of loss in the event of a natural calamity
like flood, landslip, lightning, drought, disease outbreak, manmade disaster
should be modified in such a way that the farmer gets the real value / market
value as compensation rather than a token amount.
27.9 Policy 197: Financial assistance for feeding is necessary to bring down the cost of
production and improving the profit of the farmers.
27.10 Policy 198: An advisory and technical Committee at Local Self Government level
should be constituted for increasing the profitability of different enterprises
connected with animal husbandry and assuring better returns to farmers.
27.11 Policy 199: Pricing of milk is to be done in a more scientific manner that the farmers
should receive a remuneration well above the cost of production as their
profit.
28. Polices related with dairying
28.6 Policy 200: Provision for loans to dairy farmers for purchase of animals considering
it as a farming activity.
28.7 Policy 201: Electricity on reduced rate than the industrial tariff should be provided to
milk co-operative societies for chilling of milk.
28.8 Policy 202: Providing Insurance coverage to all dairy farmers and their milch animals
28.9 Policy 203: Utilisation of unutilised land under Local Self Government for fodder
cultivation
28.10 Policy 204: Providing production incentives to dairy farmers on every litres of milk
produced
28.11 Policy 205: An appeal committee with experts from Dairy Development Animal
Husbandry and pollution control board shall be constituted to dispose of
disputes regarding License and Pollution Certificate for Dairy Farming
28.12 Policy 206: Enhancement of cattle feed subsidy rate to 25% of cattle feed cost
28.13 Policy 207: Provision for financial assistance to dairy co-operatives for running
milk chilling plant/Bulk Milk Coolers.
28.14 Policy 208: Strengthening of Dairy Advisory Services and Restructuring of Dairy
Department
28.15 Policy 209: Farmers having up to five animals and farmers who market the milk
through dairy co-operatives which is registered under co-operative law shall
be exempted from the registration under Food Safety and Standards Acts
28.16 Policy 210: Every Primary school children upt o 5th standard shall be provided
with a glass of (200 ml) of milk daily on schooldays.
28.17 Policy 211: Where ever possible new cooperative can be registered thereby more
farmers can be promoted to take up dairying.
28.18 Policy 212: Crossbred calves born out of AI Programme shall be purchased and
brought up by selected farmers or a milk co-operative societies in the area
under the heifer parks in every Block.

126

<!-- page 19 -->

29. Policies for poultry development

131

29.5 Policy 213: Kerala needs an action plan combining homestead and commercial
production to achieve self-sufficiency in eggs.
29.6 Policy 214: Considering the fact that demand for chicken meat registers 40 to
45% growth across the state annually, broiler farming can be a main source
of family income or can provide subsidiary income and gainful employment
to farmers throughout the year.
29.7 Policy 215: Promote and propagate farming of diversified poultry species
through technological development for their sustainable and profitable
production.
29.8 Policy 216: Entry tax should be levied on imports and domestic production be
exempted for broiler chicken.
29.9 Policy 217: Turnover tax per broiler chicken farmer of the state may be
fixed at Rs. 10 lakhs per annum.
29.10 Policy 218: Considering broiler farming as an agricultural activity, the
electricity rate shall be fixed at agricultural tariff.
30. Policies related to seeds and planting materials
30.5 Policy 219: The Government has to ensure that Quality Declared Planting Materials
(QDPMs) are produced and sold to farmers and treated as a right of
farmers.
30.6 Policy 220: The planting materials including seeds produced and distributed by
the Department of Agriculture, PSUs and other Government agencies
shall bear bar-coded tags for assuring the quality and traceability.
30.7 Policy 221: High-tech nurseries for the production of quality planting material are
needed in large numbers and standards for different planting materials
needs to be put in place.
30.8 Policy 222: It is important to produce quality planting material of pepper, banana
and ornamental crops through clonal multiplication and in vitro micropropagation. Sensitive diagnostic assays such as ELISA and PCR for
indexing and certification of clonally propagated and tissueculture plants
have to be used.
30.9 Policy 223: The production of quality seed of major vegetable crops and seed
spices should be given priority in collaboration with ICAR Institution,
SAU's and PSUs of vegetable seed industry.
30.10 Policy 224: The certification of quality seed based on quality parameter should
also be needed to advocate to progressive vegetable growers and farmers
engaged in production of vegetable crops and seed spices. There is need
to promote such farmers/vegetable growers for quality seed production.
30.11 Policy 225: Crop to crop seed quality control systems should be designed and
established and Seed coating and pelleting are essentially required to
protect the seeds from various diseases and pests as well as to enhance
germination.
30.12 Policy 226: Varieties/hybrids should be developed for protected cultivation
and protected production of seeds and planting materials should be
standardized.

134

<!-- page 20 -->

30.13 Policy 227: Nurseries growing and producing notified varieties should be exempted
from taxes.
30.14 Policy 228: Large scale integration of conventional and innovative techniques of
micro-propagation, aeroponics, etc is the need of hour to step up production
of disease free planting material.
30.15 Policy 229: For better disease diagnostics in vegetatively propagated crops,
cheaper alternative technologies in place of expensive chemicals should
be developed. Production of cheaper diagnostic kits for use at farmers'
level is the requirement of the day
30.16 Policy 230: Tissue culture should not become a tool for spreading of diseases,
and due care and regulations need to be in place. Cost effectiveness of
tissue culture plants needs focus of attention.
30.17 Policy 231: There is need to develop reproducible and efficient protocols for
recalcitrant plant species such as mango, cashew, and coconut.
30.18 Policy 232: Production of seedlings of specific varieties of coconut needs to
be strengthened for establishing gardens for promotion of product
diversification.
30.19 Policy 233: Establishment of mother gardens and scion block with high density
planting is highlighted in cashew, black pepper and tree spices and has to
be practiced for increasing the production of planting material.
31. Policies related to fertilizers and plant nutrients
31.3 Policy 234: For sustained agricultural growth and to promote balanced nutrient
application, it is imperative that fertilizers are made available to farmers
at affordable prices.
31.4 Policy 235: An appropriate policy that encourages balanced use of fertilizers
(organic and inorganic) including micro- and secondary nutrients is a
must.
31.5 Policy 236: The most critical issue concerns the quality of the fertilizers provided
to the farmers, and therefore, the quality control system that ensures
delivery of good quality fertilizers must be effective and efficient.
31.6 Policy 237: The use of single-nutrient fertilizers provides flexibility, lower cost
per unit of nutrient and the advantage of applying only those nutrients
that are needed and will generate an economic benefit.
31.7 Policy 238: In tune with the new subsidy regime of fertilizers, site specific
nutrient management needs to be promoted based on soil testing results
and Krishibhavan needs to be made as the centre to promote the concept
and soil testing labs needs to be equipped to take up the challenge.
31.8 Policy 239: The use of micro nutrients should be encouraged in food crop to
address the issues of micro nutrient deficiencies in soil, cattle as well as human
being.
31.9 Policy 240: As High Tech Farming and precision farming are gaining momentum in
the state, the specific fertilizers for the ventures should find a place in the
Government fertilizer subsidy programmes.

140

<!-- page 21 -->

32. Policies related to pesticides

143

32.4 Policy 241: A regular watch on computerized Online Pesticide Registration System
and take action against companies and products which are marketed in the
state without proper licensing under central Insecticides Board and strong
regulatory frame work needs to be created and monitored within state for
the same.
32.5 Policy 242: There is the need for an approach in the State which would minimise the
use of hazardous pesticides.
32.6 Policy 243: Health costs can be mitigated considerably by reducing the dose of
pesticides used and the approach of the extension workers should be oriented
in that way.
32.7 Policy 244: Cheap, quick and non-destructive methods of detecting pesticide residues
in raw fruits and vegetables should be made more popular
32.8 Policy 245: Kerala is having a well defined policy on 'Organic Farming' and on this
light, organic pesticides are to be made freely available and the recent
technology developed by CTCRI needs an intensified production.
32.9 Policy 246: Pesticide dealers should be made aware of the properties of the products
they sell and workers engaged in spraying of pesticides should be trained
and put through periodic and free medical examinations to determine their
health status.
32.10 Policy 247: The sale of pesticides and weedicides should made based on the
prescription issued by a competent officer of the Department of Agriculture.
32.11 Policy 248: A strong provision should be created to Monitoring of Pesticide Residues
in food and Department representatives should be a party of the food safety
team which is formed in the State to enact Food Safety Bill 2012.
32.12 Policy 249: Crop Health Management Centres should be taken up which can
also look into pest and disease surveillance.
33. Policies for revamping the Departmental farms
33.4 Policy 250: The infrastructure facilities of the farms are to be improved for meeting the
objective of mass production of quality planting materials and seeds for the
timely distribution to farmers.
33.5 Policy 251: Mechanising the Government owned farms to the fullest extent (100%
mechanisation) will be the only tool to tap the efficiency of the labourers in full.
33.6 Policy 252: A definite planting material production plan has to be developed taking in to
consideration the scheme of the Government and the local requirement through
an online system every year.
33.7 Policy 253: Demonstration of improved technologies are to be done in every farm.
33.8 Policy 254: Shortage of labourers in farms is to be addressed immediately by the
Government
33.9 Policy 255: Since there is the need for many emergency activities including the disposal
of perishable farm produces and immediate repair works, delegating more powers
to the sub officers would aid in the more speedy actions in Departmental farms.
33.10 Policy 256: The Orange and Vegetable Farm, Nelliyampathy and Horticulture
Development Farm, Malampuzha are to be elevated to the position of Centres
of Excellence.

147

<!-- page 22 -->

34. Policies related to value addition and processing

150

34.4 Policy 257: Enhancing income of farmers through value addition, product
diversification, and entrepreneurship development must be the thrust
areas of the development Departments.
34.5 Policy 258: Creation of a food chain starting from the farm gate to retail
outlets is inevitable for farmers to earn a greater share of the product
sale revenue after adding value to their own produce.
34.6 Policy 259: To meet the emerging challenges, agriculture must diversify in
favour of high-value enterprises and the pricing policy must be based
on the quality of the produce rather than quantity for motivating the
farmer to orient his production qualitatively.
34.7 Policy 260: Since marketing of processed products is more remunerative than
raw commodities, farmer processor linkages are needed to add value
as per demands of the consumers.
34.8 Policy 261: Storage and handling technologies and infrastructure should be
designed in a manner that losses are minimised and the produce retains
its original quality.
34.9 Policy 262: The New Generation Cooperatives (NGC) model and FPOs are
ideal since it binds both farmers and processors to honour commitments
and agreements.
34.10 Policy 263: There is a large potential for setting up of modern slaughter
facilities and development of cold chains in meat and poultry processing
sector.
34.11 Policy 264: It is high time we give the jackfruit its due recognition. The
versatile fruit of Kerala 'Jack', once Kerala's life-saver in months of
scarcity, has immense scope for value addition.
34.12 Policy 265: The provisions of the National Mission on Food Processing
(NMFP) has to be utilised for the evelopment of food processing sector,
which in turn would help in Increase in farm productivity thereby
increase in farmers' income.
34.13 Policy 266: Small Farmers Agri-business Consortium (SFAC) should be
strengthened to support the initiatives on value addition in the State.
35. Energy-smart agriculture related policies
35.5 Policy 267: The food sector both requires energy and can produce energy — an
energy-smart approach to agriculture offers a way to take better advantage
of this dual relationship between energy and food.
35.6 Policy 268: Using local renewable energy resources along the entire food chain
can help improve energy access, diversify farm and food processing
revenues, avoid disposal of waste products, reduce dependence on fossil
fuels and greenhouse gas emissions, and help achieve sustainable
development goals
35.7 Policy 269: The government should promote `conservation agriculture' which
replaces mechanical soil tillage by `biological tillage' for reducing the energy
requirement and making farming sustainable.

154

<!-- page 23 -->

35.8 Policy 270: Huge volumes of agricultural wastes in the form of livestock manure,
kitchen wastes, rice husks, etc., can be converted into potential sources of
energy and the resultant biogas can be plowed back into agricultural
production and processing activities.
35.9 Policy 271: The use of wind power for agricultural production activities is practically
adaptable for residents located along coastlines Kerala.
35.10 Policy 272: Establishment of solar and wind hybrid power generating equipments
wherever possible will reduce the power requirement for agriculture to a
great extent.
35.11 Policy 273: An incentive is to be provided for the farmers who runs an Energy
Smart Farm for the promotion of energy smart agriculture.
36. Policies related to High Tech farming

157

36.3 Policy 274: Promotion of high-tech agriculture is important as climatic extremes are
affecting normal cultivation.
36.4 Policy 275: Starting with a market study to determine the crops that will fetch a
good price in a particular season and go for Hi Tech Farming of the same
would assure huge profits to farmers.
36.5 Policy 276: The produces got from poly houses could be branded as safe to eat
since they are produced in insect free conditions which eliminates the chance
of using pesticides.
37. Policies for farm information and communication

159

37.5 Policy 277: The prestigious publication 'Kerala Karshakan' has to ensure greater
accuracy and coverage regarding the newer technologies and could be used
by the farmers for further reference.
37.6 Policy 278: Establishment of 'Virtual Class Rooms' to link Educational Institutions
like Agricultural Universities both within and abroad for dissemination of best
practices in agriculture.
37.7 Policy 279: Most of the extension services to farmers could be automated to reduce
weakness of human factors in communicating information with minimum
language, technical and socio-economic barriers.
37.8 Policy 280: Support to KISSAN KERALA.NET is to be extended to keep up its
professional standards.
38. Agricultural planning and budgeting related policies
38.2 Policy 281: Agriculture will continue to be the first priority for the Government.
38.3 Policy 282: A separate agricultural budget should be presented for greater thrust and
allocation of funds and schemes on agriculture.
38.4 Policy 283: While formulating the Departmental programmes, a regional plan at the
watershed basis should form the basis for planning every year.
38.5 Policy 284: Sufficient allocation for agriculture should be made in the LSG budgets
at least 40%, and that should be made mandatory for assuring the farmers,
the assistance they need.

162

<!-- page 24 -->

39. New policy guidelines, principles and strategies for the best service delivery by
the Department of Agriculture
39.3 Policy 285: The Department of Agriculture will be modernised and renamed as
‘Agriculture Development and Farmers’ Welfare Department’.
39.4 Policy 286: The Department of Agriculture must continue to rely upon the most
versatile form of decentralized Grama Panchayat level Krishibhavan offices
and staff support has to be re-organised based on work load and number
of farm families.
39.5 Policy 287: Make the Department a better place for employees to carry out their
jobs of serving farmers will result in a more productive and satisfied work
force.
39.6 Policy 288: The methods used for technology dissemination and personal approaches
are to be restructured in lieu of the changing face of the ICT based tools,
instruments and techniques.
39.7Policy 289:The state level monitoring of Decentralised planning programmes have
to be monitored by the Department of Agriculture by creating a separate
wing which work hand in hand with LSGD Department and KILA.
39.8 Policy 290: A 'Knowledge Centre' at the district level has to be constructed for
effective farm advisory services and empowering the small farmers with
technology.
39.9 Policy 291: The Department aims at establishing effective formal liaison and
cooperation with all institutions involved in agricultural development in the
State.
39.10 Policy 292: The staff pattern of the Assistant Directors' Office is to be strengthened
by providing additional man power support depending up on the work load
of the Office.
39.11 Policy 293: Modernization at all levels of the Department including administration,
communication, reporting, technology transfer, scheme administration,
implementation, feedback, monitoring and midterm correction should be
the motto of the Government.
39.12 Policy 294: The auditing system followed in the Department needs a thorough
reorientation for improving the Departmental Quality Management System.
39.13 Policy 295: A Department of Agriculture Manual is to be published by the
Government immediately to provide guidance and serve as a reference to
employees which will result in the efficiency improvement.
39.14 Policy 296: The District Soil Test Laboratories under the Department of Agriculture
play an important role in the soil test based nutrient application and they
have to be strengthened as Soil Plant Health Clinics for including the
diagnostic services along with analytical service.
39.15 Policy 297: Fertiliser Quality Control Laboratories are to be strengthened or
upgraded to give accurate results in minimum time so that the farmers are
assured of good quality fertilisers.
39.16 Policy 298: The bio control agents and parasites used in the biological control of
pests and diseases are to be made freely available to the farmers of the
State by strengthening the State Bio- Control Laboratory and developing
the Parasite Breeding Stations as its sub-centres for the mass multiplication.

164

<!-- page 25 -->

39.17 Policy 299: The The Bio-technology and Model Floriculture Centre (BMFC),
Kazhakuttam functioning under the Department of Agriculture is to be upgraded
as a Centre of Excellence with semi - autonomous powers.
39.18 Policy 300: Strengthening the Department'sAgricultural Engineering Division by providing
it the necessary technical and engineering support to carry out the smooth and
expeditious implementation of mechanisation, popularisation of improved
machinery and agricultural infrastructure projects.
39.19 Policy 301: An adaptive research mandate should be attributed to the Department of
Agriculture to carry out research on location specific technologies in the farmers
fields.
40. Revamping Animal Husbandry Department for better service delivery

173

40.5 Policy 302: It is proven beyond doubt that to maintain the quality of performance and
efficiency of key activities, staff attitude and behavior has a major contribution
and this principle is to be put in practice at the earliest.
40.6 Policy 303: The Animal Husbandry Department staff can be classified into general staff
and those having a specialized knowledge and skill, to maintain the quality of
performance and efficiency of key activities.
40.7 Policy 304: Establishment of Department level service providers at the Taluk level for
better monitoring and effective plan formulation and implementation
40.8 Policy305: Quality should be ensured in all Government purchases of drugs rather than
low cost to assure the farmers good drugs.
41. State agricultural research policy
41.5 Policy 306: The Kerala Agricultural University has to redefine its mission, taking into
consideration the present stage of agriculture scenario in the State.
41.6 Policy 307: The debt burden of the University has to be addressed by the Government by
providing a one time grant.
41.7 Policy 308: The present practice of proliferation of agricultural universities through creation
of new universities, campuses, colleges and through bifurcation of existing
universities is indeed counterproductive and not in the interest of quality education.
41.8 Policy 309: The state government must ensure proper financial support to the agricultural
university by allocating at least 15 per cent of the total budget of the departments
of agriculture, animal husbandry, fishery, social forestry and any other related to
agriculture additionally.
41.9 Policy 310: The disciplines and emerging areas must find a place in the teaching programmes
of the agricultural universities.
42.10 Policy 311: A favourable environment is to be created in the University for improving the
quality in research.
41.11 Policy 312: The research needs to be redefined based on the technological advancements
and farmers' requirements.
41.12 Policy 313: The University should focus on the new areas of research.
41.13 Policy 314: TheAgricultural University is to be made a goal oriented organization and the
autonomous nature of the institution is to be assured by making improvements in
the general administration focussing only on research accomplishments. ICAR
Model Act should be enacted soon.

176

<!-- page 26 -->

42. Policies for research prioritization in livestock sector

180

42.3 Policy 315: If past changes in demand for livestock products have been met by a
combination of conventional techniques, such as breed substitution, crossbreeding and within-breed selection, future changes are likely to be met
increasingly from new techniques
42.4 Policy 316: A considerable body of work exists associated with the dynamics of
digestion, and feed intake and animal performance and has to be undertaken
by the KVASU.
42.5 Policy 317: The infectious disease threat will remain diverse and dynamic, and
combating the emergence of completely unexpected diseases will require
detection systems that are flexible and adaptable in the face of change.
42.6 Policy 318: Compared with the biophysical environment, the social and cultural
contexts of livestock and livestock production are probably not that well
understood and an integrated research approach is needed on this line.
43. Policies for motivating farmers

182

43.3 Policy 319: The state agricultural awards must be distributed in the same week
along with the 'Farmers Day' celebration in every two years
43.4 Policy 320: The selection criteria should be modified and codified based on the
modern principles and assessment should be done impartially and flaw free.
44. Bio Technology and GM crops related policies

183

45. Policies for empowering weaker sections

184

45.4 Policy 321: The Government should soon take urgent steps for reviving traditional
agricultural sector of tribals by a massive programme combining the traditional
knowledge and modern technologies.
45.5 Policy 322: Appropriate farm tools, improved crops, integrated pest management
techniques, conservation agriculture, biological nitrogen fixation and other
context-specific technologies should be targeted for development and for
enhanced access by women.
46. Policies for streamlining PSUs in agriculture sector
46.2 Policy 323: Radical change is necessary to make PSU's functioning more farmer
and consumer friendly and no more PSUs are to be made in the light of
FPOs.

CONCLUSION

186

<!-- page 27 -->

<!-- page 28 -->

Preface

Towards a dynamic agriculture...
India today is hailed world over as a grain power capable to export and donate food grains
with magnanimity both in times of peace and disaster to any nation. No country will dare to
term India as a begging bowl as was done in fifties, sixties and early seventies. When Indian
grain harvest crossed 254 million tonnes, the food hungry importing countries were bubbling
with joy to welcome the breakthrough as it will help them also to attain a better food security
cover. Perhaps no achievement of Indian nation since independence is equivalent to this
shining accomplishment. The source providing perennial strength to the nation to bring a
Food Security Bill for making available the right of food to 80 crores people at a whopping cost
of 1.34 lakh crores annually is again the above bumper grain production. Once implemented
it will be more or less matchless model legislation to the world undertaken by a country with a
population of over 120 crores and 100 crores domestic animals.
Behind the scene....
The real heroes of the above fabulous achievement are our own untiring farmers, especially
the small and marginal farmers. Seventy percent of our population was engaged in farming at
the time of independence and now it has come down to 50 percent. But the real story has a
different saga to narrate. The population was only 35 crores at the dawn of independence and
now it is crossing 120 crores. So the number of people who earn their livelihood security from
the farming has really increased from 20 crores to 60 crores. The farmers of India during the
period has made India a very prosperous country by enhancing the production of not only
food grains but also commodities like milk, spices, egg, meat, fish, beverage crops, industrial
raw materials like cotton, export oriented crops like tea, coffee, cardamom etc., etc... India
has also succeeded in the area of storage trade and export of these produce. The success
accomplished in the sphere of developing value added products and manufacturing it for
internal and external trade has made the country an industrial force, producing quality products
and supplying around the world. But the sad fact is that farmers are getting only a meagre farm
gate price which provide a pathetic profit incapable to meet their growing needs. The real
profit makers of the above transformation of farm produce into value added high price materials
are the trade and industrial forces whose style of living and asset generation has helped the
country to ‘produce’ more billionaires in the list of economic giants of the world.

1

<!-- page 29 -->

Towards a dynamic agriculture.....

The Challenges...
Today as mentioned earlier India occupies a prominent position in the world for its agriculture.
The achievements made during the last six decades after independence has not only
succeeded and making big rise in the agriculture production which in its totality has also
helped to create a global image of self sufficiency in different spheres of agricultural production.
“But India still is the home of more that 27 % of world's undernourished population and 79.2%
of their children under the age of three, 56.2 % of women and 24.3% of men are malnourished
and anaemic. It is shameful that India has the largest number of hungry people than any other
country, 2.1 million of their children die every year before reaching 5 years of age, that over
60% of the children (under 5 years) are wasted, stunned underweight or a combination of these
and that about 30% of the babies are born under weighed. Despite poverty removal being an
important stake policy for a long time, the progress so far made towards having the number of
hungry by 2015 under the UN Millennnium Development Programme is of the track”. (M.S.
Swaminathan).
Mammoth challenges sighted above call for more vigilance and a visionary approach in framing
and implementing future agricultural programmes. Already official agencies have gone on record
that 40% of the farming population of the country are eagerly waiting for other opportunities to
leave the profession. Several studies also indicate that farmers as well as agriculture labour are
very particular not to lead or encourage the younger generation to take up farming as an enterprise
to earn a livelihood security. Farmer Producer Organizations (FPOs) may be the starting
programme for such a novel change. Our future approach should be to empower the small and
marginal farmer to take up farming, handling of the produce including processing product value
addition and marketing and generate maximum profit by getting them organized with the assistance
of the research development and funding agencies. The approach should not be to force the
farmer and farm labour to leave the farming by transferring the land to rich tenant or corporate
and work in the same as the paid labour or employees of the “new wave of cash rich tenant in
which ever sweet- name they appear”. The strength of Indian farmer must be assessed in a
different context certainly not as a raw material producer and leave the produce after primary
processing for a paltry profit and make the trade, technology and fund rich industrial force prosper.
Why a farmer oriented policy....?
National policies should become more small farmer friendly as farmers unrests are erupting in
the form of suicides, leaving villages en masse, large areas are left barren by calling “giving
holiday to cropping”, shortage of labour, escalation of wages, making production unprofitable
etc. must be seen as undesirable developments which will make the agricultural production in

2

<!-- page 30 -->

Preface

different sectors unsustainable. Quiet often market forces functioning at different levels are
free from the calamities like various price falls and damages whereas these two challenges
are making the farmer's capability to continuing the task impossible. But at the same time all
forces working in the farm front are free from the effects of disasters. This creates a condition
that when an agricultural calamity comes farmers are becoming the only group which is forced
to bear the entire loss.
Indian farmers have truly brought in enormous economic prosperity to the country during the
last six decades after independence. They could achieve the same due to the great progress
made in research, extension, development sectors and administrative changes done in different
areas of activities. But much more has to be done for the welfare of farmers to continue the
existing efforts and produce more results for providing all round prosperity. To accomplish
this ideal situation all the sectors assisting the farmers as listed above should be developed
so that the existing infrastructure and situation will enable the farming community to fulfil the
aspiration and trust expected from them by the nation. In short the effectiveness of the
accomplishment of the above various sections will be evaluated by the influence it provides in
enhancing the farmers income and profit and also their total prosperity. Farmers' prosperity
generation will be the most important theme and goal of all future farm development projects
since their welfare will keep the nation secure not only in the food front but also on all sectors
which require farm oriented products for the betterment of the life of Indian people.
Kerala’s Agricultural Development Policy....
Kerala produced its first policy on agriculture in the year 1992. It was a welcome document
providing a vision on the lines through which Kerala agriculture should be guided. As the first of
its kind the policy has given guidance to frame different programmes of great use to the state. I
take this opportunity to congratulate, Sri.K.Karunakaran, the then Chief Minister, Sri.P.P.George,
the then Minister for Agriculture and Sri.M.S.Joseph, the then Agricultural Production
Commissioner for producing and presenting such a valuable document. Since then 20 years
have gone introducing significant changes in our farming sector.
Kerala government took a very bold step when it decided to make a farmer as the chairman of
the committee to give shape to our future agricultural policy. I view it as a very welcome positive
indication of the great faith and confidence the administration has got in the farming communities
capability. I thank the Hon'ble Chief Minister Sri.Oommen Chandy, Hon'ble Minister for Agriculture
and Animal Husbandry Sri.K.P.Mohanan and all members of the cabinet for the great gesture
and it has enhanced the responsibility of the committee to produce a document of immense
value to the state.

3

<!-- page 31 -->

Towards a dynamic agriculture.....

The genesis...
We have interacted as stated in the introduction and several other pages in the report, with
farmers, farmer leaders, farmers associations, leaders of three tier LSGs, development
departments, corporations, scientists, academicians, media representatives, farm journalists,
extension specialists, economists, labour organizations, service organizations, award winners,
plantation representatives and several other agencies interested in agriculture to collect their
suggestions at length.
I am personally indebted to them for the whole hearted co-operation extended to the committee
for the suggestions, criticisms and visions presented before us. This has helped us in providing
an in-depth study on the real farming situation of the state and to make farming a very charming
enterprise of our state popularly described as 'Gods own Country'.
The background....
Kerala agriculture with all its critical tensions described at different quarters still continue to be
the number one among the Indian states in generating maximum monitory return from a hectare
of farm land. Kerala is producing over Rs. 53,000/- per ha of farm land now. No other state
could reach this level so far.
It is also a fact that, the farmers of Kerala irrespective of the
happenings of large scale conversion of wet land and garden land for unavoidable social and
community needs ranging from housing to transport, tourism and entertainment continue to
produce quality agro produce which still fetch very high price at the terminal and export markets.
For eg. when Palakkad Matta is sold in the upcountry metro markets for Rs.65/- to Rs.70/- per kg
the producer in Kerala is selling at Rs.22.6/-. The difference goes as profit to one or two middle
level trade agencies. Reason for the farmers' poor return from his very hard earned crop is the
pathetic fact that he continue to be a simple raw material producer and supplier. This holds good
in almost all the farm produce like pepper, rubber, cashew, coconut, vegetables, fruits, ginger,
milk, meat and egg. This is a very serious weakness of the farming sector of Kerala.
In short though the farmers are producing quality goods and consumers are paying premium
price to acquire them farmers are denied of the same and the market forces with very strong
trade network, technology support and cash rich fund pools are amassing wealth using the
farmers produce. No proper estimation on this trade secret is not even attempted. So the prime
need should be to give shape to farmers own producer companies which will handle storing,
processing, value addition, domestic marketing and export themselves or through their federation.
This will facilitate the farmer to get a substantial income hike which will empower him to develop
his enterprise and pass on the same to future generation and make them capable to have a
decent living with social acceptance and respect. Future policy of all agricultural programmes

4

<!-- page 32 -->

Preface

should have emphasis on these vital aspects i.e. the capacity of the project to provide more
economic gain and profit to the farmer. The success of each programme should be evaluated
based on its capacity to achieve the above objective.
Opportunities ahead...
Kerala agriculture offers a very wide range of opportunities. At present farming has a very
narrow interpretation as a profession. Large scale holdings has almost disappeared apart from
the plantations in the state. Statistics reveals that out of the 66.5 lakh holdings, 95.17% of the
same fall under the group of less than a hectare. Even in this group vast majority are with 5 to
25 cents. The topography of the land and the climatic condition of Kerala are conducive for
several avocations which need little or even no land, like beekeeping, mushroom culture,
floriculture, flower processing, stall fed goat rearing, cage layer poultry rearing system, two
cow dairy units and ornamental fish rearing. This will generate a new vision among the masses
especially those who with less or no land to become participants in production of quality food
and interior decoration materials of biological origin which enable them to have a link with
nature and earn an income with self respect. The idea is everybody who possess land or no
land should get involved in one farming practice or other. The present unhealthy trend among
the new generation is to go and buy everything from the market totally ignoring the health
hazards, should change. So also all those who desire to have quality food should be a
participant in producing any of the farm produce ranging from fruits and vegetables to egg and
meat. In future this will gain more momentum since quality deterioration in food items is getting
rampant and dreadful.
The approaches....
In a land hungry state like Kerala bringing more land under plough is very difficult to even
imagine. This calls for a very special approach regarding the plantation sector. Plantations are
really centres where large scale mono cropping is practised and the produce are processed,
packed and sent for domestic marketing and export. It was a creation of colonial rule and so
had a special stature since it is owned by foreign companies especially British. This kept it
aloof from the local farming population. Truly plantations come under the farming sector i.e.
crop culture division.
A new development approach is urgently required regarding the preservation of plantations.
Ecologically and climatologically all the conducive areas for growing plantation crops like tea,
coffee, cardamom and now rubber has been brought in the state. Considering the strategic
nature of the crops in its management and processing while passing the Land Reforms Act,

5

<!-- page 33 -->

Towards a dynamic agriculture.....

Kerala has given a special status to the plantations. In short they are exempted from the land
ceiling. In the present context through a policy it must be insisted that in all the cultivable land
belonging to the plantations the notified plantation crops should be planted since fresh planting
areas are unavailable. On no account it should be used for growing any crop which is not
notified before. Since land suited for cultivating the specific crops are unavailable it should not
be used even for large scale cattle rearing or tourism or entertainment related centres. This is
a must and plantations must be encouraged with soft loans, tax concessions and technology
upgradation for the purposes like replanting, water conservation and value added products.
Such an approach is necessary since the plant population in most of the estates has even
crossed its biological life span. In several estates one could see 100 year old tea bushes still
maintained.
Plantations provide great wealth to Kerala not as an agro produce alone, but also it provides
employment to several thousand common people and also as a money spinner since different
taxes the state and central government are getting over several crores of rupees annually. Hence
plantation must be treated as a part of agriculture in its real sense and it must be preserved and
helped to develop to meet the fast growing needs of the society, trade and exports, all bringing
wealth to the state and nation.
Need for administrative co ordination...
A review through the organization of support for helping the farmer to produce more generating
better cropping reveal that we have enough number of organizations engaged in the research,
development, extension, processing, marketing and even export. With all the infrastructure
providing agencies and availability of tolerably good financial support the physical production of
the crops, livestocks and other associated areas like bee keeping, floriculture, ornamental fish
farming and mushroom culture. But what is totalling lacking in the functioning of the various
agencies is co-ordination. Though much has been said it is a sad sight to observe that this is
lacking from the top most level of the centre of power to the micro level. For example, there are
about 30 agencies functioning in the state for the development of coconut culture and to help the
farmer to earn more. Central sector agencies, state sector agencies co-operative sector agencies,
financial agencies are the most important among the same, leave alone the voluntary agencies
and farmers organization. The present stage of coconut in the state of Kerala is one which
required no introduction for its sad and pathetic decline with all the agencies claiming to be
active participants in its development efforts. At no point a working co-ordination is attempted.
Huge sums of tax payers money though spent is not reflecting in the physical production hike of
coconut or improving the interest of the farmer in taking care of the palm. Perhaps the most and
neglected crop in Kerala after 6 decades of planned developed is coconut while technologies
are utilised for successful growth in several other countries in the world bringing more benefit to

6

<!-- page 34 -->

Preface

its producers. Hence producing co-ordinated efforts with committed reflection on production
and welfare fund should form the motto and disputed guideline of all programmes done in the
coconut sector. This may be treated as a warning coming from the intensive relationship the
committee has developed after assessing and hearing the farmers reaction in all part of the
state. This must be treated as a top priority hungry area.
Modern technology and growth...
Progress in the farm front accomplished in all part of the world have derived from technological
modernization and upgradation. These are mainly done not only to enhance the productivity
but also to take away the drudgery associated with the various farm activities and also to hasten
the speed of various associated jobs. Another area of modernization is the production of various
value added products suited to the fast changing lifestyle and its sound, safe and quick marketing
technologies to reach the needy client at his door step. Modernization is required at all levels
viz. Research, transfer of technology, information and communication, product development,
value addition, marketing, fund flow, co-ordination and administration at all levels. This also
must be treated as a top priority area in the policy making as the competition between the
countries and within the country becomes tight, swift and tactical. More is said than done in this
vital area and we have sour experiences of defeat of this front which should not be tolerated
and if allowed to continue may lead to more shocking experiences.
Prosperity due to livestock and dairy...
Livestock development sector of Kerala has made significant contributions to the state's economy
during the last 3 decades by equipping the farmers to accept and adopt modern technological
methods combining with their traditional skills. But it has reached a real take off stage and that
has to be exploited in a truly farmer welfare manner. The benefits of the livestock development
must provide a sustainable income to the producer facilitating a steep hike in his returns.
Productivity hike should be combined with product diversification, value addition and by-product
utilization. Livestock development programmes should not be seen as a simple attempt aimed
for poverty elevation. It should also be built up as a development vehicle by modernization,
product development and marketing including exports. The policy should be moulded with this
in view. At the same time the time tested, indigenous methods of livestock development must be
preserved, encouraged and empowered with technology and funding upgradation so that our
indigenous livestock wealth and different models of rearing them using the by-products of the
farm adding a supplementary income to the rural force and helping the elevation of the nutritional
status of their diet. This too must be given a place of importance in our future policy programmes
since we hold 66.56 lakhs tiny land holdings which also form the home of our livestock population.

7

<!-- page 35 -->

Towards a dynamic agriculture.....

The basic necessity required for implementing any modern day livestock development is the
availability of the livestock data and performance control mechanism. Many in Kerala is unaware
of the fact Kerala is ripe for introducing such a sophisticated animal husbandry technique into
our social system. Though it is sophisticated the information communication system developed
in our state is a boon for the collection and transformation of the data generated. Quality up
gradation of animals is a must for improving the productivity as well as profit from the minimum
quantity of feed that we provide. One such a system induction of hi-techs like quality up gradation
of animals, breeding performance, evaluation of returns and disease control measures could be
made available at the door step of the farmer. Livestock sector like all sectors are experiencing
very keen competition not from the organized producers alone. World over marketing of livestock
produce are becoming more and more sensitive and dear. India is seen by several countries as
a potential exporter meat, egg and even milk products. So there is every possibility of the
present suppliers of animal products of the state may prefer export rather than internal trade.
Kerala has to take very special care of this situation and so any investment done on this sector
will be doubly beneficial to us. It will help us to provide a safe internal market and in the same
time entire excess could be exported. The expenses required for the launching of such a
programme covering the entire state should be viewed not as a state development programme
by doing this we are creating a model for not only India but all developing countries. Hence
this programme should be considered as an area deserving high policy priority.
Hatching the eggs of income...
Kerala egg had a place of pride not only in India by the adjoining country like Sri Lanka. The
present modern egg and meat production though has made the material available more its quality
quiet often is in question. At the same time quality eggs produced in the traditional methods still
possess an edge over than the one done in the modern way. In this context the State Animal
Husbandry Department has come forward with a new programme for popularising Micro Cage
Layer as an associate to the traditional backyard poultry. This programme has got a special
significance as it will add to the income of the small and marginal farmer and even those who is
not have much land for agriculture purpose. A small family could earn a minimum of 1500
rupees by practicing this programme with lakhs of small holdings Kerala stands to gain very
much economically from this exercise.
The Actio Apportum...
The draft policy document contains 331 policy approaches which are elucidated from the
discussions, interactions, seminars, field visits and brain storming sessions with producer farmers,
people's representatives, farmer leaders, professionals, individuals, organizations working

8

<!-- page 36 -->

Preface

for the progress of the farm sector. One undisputed point which had total acceptance was the
urgent need to keep the farmer who carries unique asset of work experience generated through
several centuries needs more care and share of the enormous economic prosperity that he
delivers to the country fighting all odds ranging from unpredictable climatic changes to
uncontrollable price fluctuation. The economic prosperity generated and enjoyed by the society
in different form should also be made available to the producer farmer by introducing an Actio
Apportum* a new methodology under which farmer get a legal right of share of profit generated
out of his farm produce. This is a must to keep the farming and farmer active alive and productive
atleast during the next 5 decades. The committee finds this must be accepted as an uncompromising policy to bring the smile of real prosperity in the farm front.
It is estimated that over 40 lakh tonnes of rice is being sold in Kerala. State could propose a cess
of mere one rupee per kg of rice sold and can generate an amount of Rs.350 to Rs.400 crores
every year. This could be used as Actio Apportum (Avakasa Labham) a legal right for sharing
the profit generated out of the farm produce when it is traded at the terminal market. Every
farmer who has given their produce to the state will be eligible to have Rs.5 per kg of paddy as
Avakasa Labham. This may facilitate a farmer giving 3 tonnes of rice to earn a cheque for Rs
15,000 rupees as avakasa labham from the Department of Agriculture for every crop season.
Similar exercises could be worked out for rubber, milk and other crops after detailed study. This
will facilitate the farmer to invest more money to produce more paddy so that it offers a decent
return as a right without fail. The unspent amount will remain as a 'Nidhi' for future utilization.
The contribution of agriculture labour in the developing strong and sustainable farming sector
must be recognised. A farm labour working in the paddy culture for 50 days during a season
must be eligible for a Avakasa Labham of Rs.2500/-. This will be sent him by cheque through
Agriculture Department.
Farmlands as precious diamonds...
The committee made a sincere attempt to go through the novel efforts made by other states in
preserving farm lands for agriculture purpose since land is the most important input and an
unavoidable asset for sustainable agriculture. We find that our adjoining state Karnataka has
given a model act for land conservation and we very strongly recommend that a similar act
should be given shape in the state also. A land hungry state like ours blessed with conducive
climate for rising different types of crops of very great economic importance must take very
special care in preserving the farm land against unplanned and haphazard use. We propose a
clear cut policy on this aspect and its strict implementation. This is required even for the
sustenance of crop and animal husbandry in the state.

9

<!-- page 37 -->

Towards a dynamic agriculture.....

Income is guaranteed...
Fluctuations in the price of farm produce often cause havoc to the small farmer community
eroding away their entire profit. This was the universal compliant raised in all the meetings
wherever producer farmers participated. Farm economists and agronomist also suggested that
unless a solution is found the farmer will not invest his hard earn resources for agriculture and
livestock development. The committee after prolonged deliberations suggest that, a priority
policy should be given shape to form a Price Fixing Authority and for the same an Income
Guarantee Act may be passed.
Addressing the distressed...
One of the most unfortunate and highly undesirable development crept into the agriculture
development scenario of the country was the eruption of the new phenomina during the later
part of 1990's i.e. farmers suicide. During the colonial rule India was branded as a country of
starvation deaths and famine whereas this new phenomina has happened when the country had
enough food grains in stock and was also doing exports. Several reasons are attributed for the
shameful happenings but it remains a fact that farmer suicides are a reality and it has happened
in Kerala also and continues to happen even now, but showing a decreasing trend. India
today has the strength to put an end to this shock with its granaries full and various poverty
alleviation programmes implemented through out the country. We have made very sharp and
practical suggestions to face the challenge and certain methodologies and programmes for
preventing the occurrence of the same. Instead of rushing to the scene after the damage has
happened. This must be given a workable shape as early as possible since even official
records at the national level prove that the number of farmer suicides are increasing even
while the country holds over 60 million tonnes of grain as food reserve. If such a mechanism
could be added to the existing food security bill it may be more useful.
A separate agricultural budget...
The importance of farming sector in India is attaining new dimensions from a profession meant
for simple sustenance and subsistence it has undergone a lot of changes. In all fields from the
land ownership to ultimate sale of the produce at the export market this change is visible. Taking
this into consideration a lot of transformation has taken place in providing a stature to the agriculture
which was for beyond our imagination at the time of independence. Several States like Karnataka,
Andhra Pradesh, Bihar, etc., are presenting an exclusive agriculture budget in the legislature
every year and all the agriculture and allied activities are brought under very strict and highly
utilitarian scrutiny and support. Kerala with 80% of its agro produce finding market in other parts

10

<!-- page 38 -->

Preface

of the country and in other nations should emulate this approach of having a separate Agriculture
Budget and it will be a very bold and welcome step which will help us to hasten the efforts for
creating real agriculture prosperity.
Sustaining the agricultural research...
Agricultural education and farm research are two areas which deserve paramount importance
both at times of crisis and prosperity. It could give more help, assistance, guidance and break
through for the various problems erupted in the wide agricultural scenario of the state. In this
context Kerala Agriculture University with a history of over six decades deserve a very vital role
in finding solutions to the problems posed at present and the problems which may arrive in
future. The economic recession experienced both in the developing and developed countries
and its strangling effect in the farming sector needs a very purposeful strengthening of this vital
area of activity. The present difficulties experienced by the Agriculture University mainly due to
the acquired debt of above Rs. 265 crores should not be treated as an obstacle which could not
be erased out making the university self reliant result producing and as an institution which could
face any challenge and provides solution to the problems faced by farmers as well as the State.
We observe that its present financial burden though acquired due to undesirable and unfortunate
reasons must not be allowed to wither one of the resource rich institutions we have built up at a
huge cost.
Kerala's farming sector according to certain estimate is contributing physical produce worth
over Rupees one lakh crore. An institution like Kerala Agriculture University should be treated
as a part of this great effort and it should be made capable to help the farmers to make the
returns from farming sector cross two lakh crores in another two decades. The agricultural
university may not be treated as a commercial organization and its contributions must be
evaluated using different norms. It is an integral part of a development system that contributes
enormous energy for achieving new vistas of progress which ultimately strengthen the economy
both by physical, emotional and holistic manner. Our agriculture university today holds total
staff strength of 4600 personage from Vice Chancellor down to the farm labourer. Though the
agriculture university has been trifurcated the staff strength of the university till remains 4230
with 40% of it posts are still remaining vacant. At present the university is finding it extremely
difficult to push through the programmes which are capable to produce rich results and
breakthroughs due to the fund crisis. Delivery of vital contributions for the farming sector is still
continued by the institution and its stature as the best agriculture university maintaining high
teaching standards remains a well recognised national honour.

11

<!-- page 39 -->

Towards a dynamic agriculture.....

The state should take a positive view to wipe off the debt and provide enough fund to put it
back to rails to make rich contributions enabling the farming sector to progress faster, helping
the farmer, and State economy more prosperous. The agriculture university is an organization
which the farmers and all those who love farming, want to function and produce promising
results for the progress at present and in the days to come. The committee is of opinion that
the crisis faced by the university at present must be sorted out and it should be made courageous,
bold and capable to function as a provider, guiding spirit and friend in need to the farmers of
the state. This must be treated as a high priority area.
Improving the quality of research...
In this context Indian Council of Agriculture has given shape to Model Bill for agriculture
Universities of the country after assessing the various challenges and responsibilities facing in
the farming situation of the country. Our initial reaction is that the state may welcome the Model
Bill and accept the same with appropriate modification which may suit the peculiar agriculture
situation, crop and animal husbandry systems followed in the state and the marketing and
value addition prospects and above all farmer's welfare. This is an area were more intensive
studies are required and we hope government will take appropriate advises to give shape a
new agriculture / veterinary / fisheries University Bill.
‘Neera’ can tap income...
Neera has ultimately recognised by the Government of Kerala as a non alcoholic beverage it
must be popularised. The Committee from its very commencement of working, initiated steps
with Government to materialise the same. Neera according to experts as well as experienced
farmers is sure to give anew economic prosperity to coconut grower. In several other parts of
the world Neera has proved to be a very valuable expert earner both of Neera and a syrup and
a sugar. In Kerala it must be reiterated that the ultimate right on Neera production rest with
farmers this must be recognised without any doubt because farmer takes care of the palm from
the very first day of is farming and every products coming out of the same belongs him since
it is a products of his care and attention. The next should be a united effort by the Department
of Agriculture, coconut board and KAU for producing Neera and allied products and successfully
marketing the same for providing good income to the farmer good wages to the labour and
substantial income as taxes to the government. This area is also facing a lot of challenges like
production of planting materials, care of gardens, producing varieties and treatment to produce
more Neera and also its marketing and value added material production and even exports.
This calls for vigilance support to the FPO and its federation. The Neera business is opening
up a billion dollar business in the state if handle properly which appropriate policy support it
will bring an era a prosperity and welfare to the coconut growers and all those who are associated
with this production. Appropriate policy support perhaps the most vital input.

12

<!-- page 40 -->

Preface

Heartfelt gratitude....
I am very much indebted to the esteemed members of the committee senior officers of the
Agriculture University, Veterinary University, Fisheries University, Department of Agriculture,
and Animal Husbandry, Dairy, Soil Conservation and Soil Survey, Chairmen and Managing
Directors of all the corporations and boards in the farming sector of the state for the very kind
co-operation extended to the committee. Officers of Government of India, different commodity
boards, input agencies, farmers, farm leaders, farmer's organization representatives, farm
journalists, economists, both print and electronic media in the public and private domain for
the very active help given to us. Committee is extremely thankful to all the District Panchayat
Presidents, Block Panchayat Presidents, Grama Panchayat Presidents and the members and
officials who provided as a great forum in each district for open free and frank discussion with
the farmers and peoples representatives. The committee is very much indebted to all the
officers who provided wonderful and purposeful assistance to make this job a very fruitful one.
I have a word of very special thanks to the Department of Agriculture and State Agricultural
Management Extension and Training Institute (SAMETI) for providing the secretarial assistance
of high standards for completing the great work keeping a tight time schedule.
I wish to place heartfelt thanks to Sri. K.Divakaran, M.L.A., and Former Minister for Animal
Husbandry and Dairy for supporting the Committee with valuable suggestions.
The committee wish to submit its profound gratitude to the farming community and all those
who love farming for the patience, co-operation, help and suggestions extended to us. The
farmers and people representatives very realistic, though at times were “explosive” in narrating
the difficulties experienced compelling a few of them to woo even extreme steps of suicides
were kind enough to provide very sober suggestions of great practical value and credited the
utility value of this report is really due to their large hearted contribution.
I dedicate this humble document for the welfare and prosperity of the hardworking farming
community and their labour associates who keep Kerala evergreen, prosperous, progressive
and a biodiversity paradise.

K. Krishnankutty (Chairman)
Ezhuthani House
Perumatty
Palakkad.

13

<!-- page 41 -->

Towards a dynamic agriculture.....

14

<!-- page 42 -->

Agricultural Development Policy 2015

1. INTRODUCTION
1.1
Agriculture and allied sectors are the
most crucial sectors of the Kerala economy
as they provide livelihood to approximately
two-third of the population and contribute a
fourth of the SDP. Agriculture in Kerala has
passed through many changing phases. The
major change started from the later part of
1970s, when decline in rice production in
Kerala happened owing to the increased
availability of rice grains at a comparatively
cheaper price Consequently, investment in rice
production decreased and a major portion of
the land was shifted for the cultivation of
perennial tree crops and seasonal crops.
Profitability of crops is reducing due to the
high wages for farm labourers, the high price
of land and the uneconomic size of operational
holding areas.
1.2
The population pressure on land is
very high in Kerala and the land has become
shifted from the position of a resource for
production to the level of an asset. This made
the situations more complex and the farmers
are started shifting from cultivation and the
practice of putting the most valuable land to
other purposes than farming began. Many
farmers were forced to stop agriculture due
to these reasons and farming became a nonlucrative vocation.
1.3
Kerala is known as a consumer state.
This dependence is creating very serious
problems as the neighbouring states are
restricting the free flow of food materials
outside. The state is primarily depending on
the states like Tamil Nadu, Karnataka, Andhra
Pradesh etc., for the staple food, rice. But the
fact is that these states are announcing 'rice

holidays' for their farmers and the land is kept
fallow. For the unavoidable other food
materials like egg, milk and meat, the
dependency on other states is at its maximum.
If the present trend is allowed to continue,
the state of Kerala would become the most
food insecure part in the country.
1.4
This poses serious threat for not only
in the food security of the State, but also in
the environmental aspects which is the basis
for sustenance of life. Under these
circumstances, the Government of Kerala,
headed by the Hon'ble Chief Minister, Sri.
Oommen Chandy and Hon'ble Minister for
Agriculture, Animal Husbnadry, Printing and
Stationary Sri. K.P. Mohanan decided to
formulate an Agriculture Development Policy
with a view to bring safety and status to the
cultivators and assuring income from farming.
1.5
In May, 2012 The Government of
Kerala constituted an advisory committee
under the chairmanship of Hon'ble Minister
for Agriculture, Sri. K.P. Mohanan. The
advisory committee entrusted the task of
preparation of a draft policy document to a
Sub-Committee chaired by a renowned
farmer Sri. K. Krishnankutty. The other
members are Sri. M.S. Joseph, Retd.
Agricultural Production Commissioner, Sri.
R. Hali, Retd. Director of Agriculture, Dr.
Vadivelu, former Director of Extension, Tamil
Nadu Agricultural University, Dr. P.
Rajasekharan, Chief (Agri.), State Planning
Board, Dr.P.V. Balachandran, Director of
Extension, Kerala Agricultural University, Dr.
K.G. Suma, Director, Animal Husbandry
Department, Sri. R. Ajithkumar, Director of

15

<!-- page 43 -->

Agricultural Development Policy 2015

Agriculture as Convener and Sri. A.K.
Madhavachandran, Deputy Director of
Agriculture as Joint Convener. The Hon'ble
Chief Minister was kind enough to attend the
first meeting of the Sub-Committee along with
the District Panchayat Presidents and Political
Farmer Organisations (PFOs). He suggested
that considering the very important role, the
Sub-committee had to visit and gather in
formations from the farmers of the 14 districts
and all the stake holders while formulating the
Policy. As per his suggestion the SubCommittee conducted a series of sittings with
a participatory approach with all the
stakeholders of agriculture throughout the
state. It took a mission mode approach for
the generation of draft policy document.
1.6

1.6.2 In order to elicit responses from different
sections such as the important peoples'
representatives like MLAs, progressive farmers,
eminent personalities in the field of agriculture,
the Chairman wrote detailed letters to them and
their suggestions were sought. For the
participation of the public wide publicity for the
committee along with the contact numbers and
e-mail address were given in the leading news
papers of Kerala. As expected, it got a very good
quantum of responses.
1.6.3 A total of 48 sittings, 384 hours long
discussions and 128 days long document
writing were conducted for the policy
document generation. A total of 96 number
of organisations and 2650 number of people
attended for the policy document generation.

Formulation of the draft policy

1.6.1 A series of consultation meetings were
conducted to understand the needs of different
sections of the society as well as the design
and content. Meetings with farmers, farm
labourers, Local Self Governments, various
stake holders in the sector such as farmer
organisations,
agricultural
labour
organisations, Organisations of professionals
and extension workers engaged in the sector,
Non Governmental Organisations (NGOs),
representatives from public sector enterprises,
representatives from commodity boards and
national research institutions, meetings with
Managing Directors and Chairmen of Public
Sector Undertakings (PSUs) and state level
bodies which are promoting agriculture and
allied activities, the farm journalists, etc., were
conducted across the state. All the decisions
in the meetings, suggestions and opinions of
the participants were considered for the policy
document preparation.

16

1.6.4. The Government of Kerala (GOK)
headed by Sri. K.Karunakaran as Chief
Minister and Sri.P.P.George as Minister for
Agriculture, announced the first Agricultural
Policy for the state During March, 1992, and
as more than two decades passed by; there
needs a thorough reorientation of the policy
on the light of the present agricultural scenario
of the state. Further, the Government of India
approved a 'National Policy for Farmers'
submitted by the National Commission on
Farmers (NCF) under the chairmanship of
Prof. M.S. Swaminathan during September,
2007. The primary focus of this policy was
on the 'farmer' defined holistically and not
merely on agriculture. In that sense the policy
was regarded as more comprehensive than
merely an agricultural policy. The guidelines of
this policy are also taken for the manuscript
preparation of the State Agricultural Policy by
incorporating the primary production sectors

<!-- page 44 -->

Agricultural Development Policy 2015

such as Animal Husbandry, Dairy and Fisheries.
Lately, during 2010, the GOK also formulated
a thorough strategy for the adoption of organic
farming by amending the then exisitng organic
farming policy of the state. Since an organic
farming farming poicy has already been framed,
this document does not cover any policy related
to organic farming. However, the background
activities needed for setting up of organic farms
throughout the state is dealt in detail in the
respective heads.
1.6.5 With this background works, the
policy is designed with the primary view of
ensuring a respectable living to farmers and
those who are associated with farming of
Kerala by improving the net income earned
by them by the judicious utilization of available
resources of land, water, rural manpower and
technology with focus on increasing the
productivity and profit in a planned manner.

1.7.

Vision of the Policy document

1.7.1 The policy document encompasses a
vision of “ensuring a sizable income
from farming along with food, water,
livelihood security and modern living
amenities to every citizen of the State
by maintaining sustainability of the
agriculture production system and
develop agriculture as a worthwhile
occupation capable of assuring a
modern living with dignity and social
status to farmers so that the future
generation is attracted towards
farming which must be a charming and
challenging enterprise to them through
the primary sectors like Animal
Husbandry, Dairy, Inland Fisheries
along with Crop Husbandry including
harvesting and handling”.
1.7.2 As mentioned earlier the document
covers the primary production sectors such
as Crop Husbandry, Animal Husbandry,
Plantation sector, Dairy and environment.

17

<!-- page 45 -->

Agricultural Development Policy 2015

2. GENERAL BACKGROUND OF THE STATE
2.1
Kerala is characterised by the resource
richness such as rainfall, fertile soil, good
sunshine and humidity. It also possesses
different climatic conditions like tropic, sub
tropic and semi-temperate. The state is already
divided in to 26 different agro ecological
zones. It is well known for the plant and animal
diversity of the Western Ghats, which is heard
as a 'Biodiversity Paradise'.
2.2
Currently, agriculture in Kerala suffers
from characteristics such as declining
cultivable area, low productivity per unit of
labour, predominance of tiny and fragmented
holdings, aversion of agriculture sector by
young generation of farmers and agricultural
labourers due to the insecurity in income and
uncertainty in the agriculture production and
poor marketing channels. Emergence of
export-oriented cash crops over food crops has
resulted in the decline of food crop to non-food
crop area ratio from 64:36 (1960-61) to 16:67
(2009-10). The fact remains that 80% of the
agricultural products like rubber, tea, coffee,
spices etc., produced from Kerala are still
marketed outside the state. The impact of climatic
variations started affecting agricultural production
to a greater extent. The drought situations of
2003 and 2013 are very good examples for it.
2.3
Out of the total geographical area of
38.86 lakh hectares, net area sown is 20.71
lakh hectares which comprises of 53.3% of
the total area. The net area has decreased by
0.35% when compared with the 2009-10
statistics. Out of the gross cropped area of
26.47 lakh hectares; food crops, comprising
rice, pulses minor millets and tapioca occupy
only 12.05 % (Agricultural Statistics 2010-11).

18

Kerala is facing serious challenges in retaining
even this meagre area. Even though Kerala has
the least waste land available when compared
to the rest of India, (2.01 lakh hectares) area,
which can be put in agricultural purposes is still
to be exploited.
2.4
The general appearance of the green
lush of the state signifies the feed availability
for the livestock and thus it forms an integral
part of the production system.
2.5
The integrated farming combining live
stock, backyard poultry and inland fishery is
known as the 'homestead farming' which is
unique to Kerala.
2.6
The share of Agriculture in State
Domestic Product (SDP) during 19701971 was 49.44% which declined to 14%
in 2009-10 like in India. However, the
share of service sector during the same
period showed an increase to 61.3% from
34.23%.
2.7
Kerala was the pioneering state in
India in implementing the land reforms. But at
the present condition, those who own the land
leave it fallow because of many reasons such
as non availability and high cost of labour,
inputs, high production cost, very poor profit
margin and several other critical constraints.
Thus the situation is such that cultivable fallow
is available, but resources required for
cultivation is costly or not available to the
needy. Land owners also fear that their land
will be lost if given for others on rent for a
longer time.

<!-- page 46 -->

Agricultural Development Policy 2015

2.8
According to Government figures,
Kerala's total food grain requirement in 1997
was 48 lakh tonnes a year and internal production
accounted for only 10 lakh tonnes. Twenty four
lakh tonnes used to be provided under the PDS,
the rest of the requirement being met from the
open market. The present crop situation of the
state is as follows. The total area under paddy is
2.13 lakh hectares, vegetables 0.42 lakh
hectares, fresh fruit plants 2.83 lakh hectares,
tapioca and other tubers 0.93 lakh hectares,
pulses 0.004 lakh hectares, coconut is 7.7 lakh
hectares, sugarcane 0.0064 lakh hectares, spices
& condiments 3.54 lakh hectares, and plantation
crops 6.7 lakh hectares according to 2010-11
statistics.
2.9
Kerala agriculture is mainly dominated
by small, marginal and homestead farmers.
The average land holding size is smallest in
Kerala. Marginal farmers with an area less
than one hectare and dominated by home stead
farming of 10-20 cents is a special
characteristics of Kerala. The above category
constitutes 90.4% of the total small farmers
with 1-2 ha (4.3%) semi medium farmers with
2-4 ha (1.3%) large farmers with 4-10 ha
(0.3%) (Economics and Statistics, 2009).
2.10 Majority of livestock population in the
state is concentrated in villages. The biggest
contribution of livestock sector is the
provision of quality food materials like milk,
egg and meat. Mostly casual and agricultural
labourers are engaged in cattle rearing and
allied activities and hence any development
in the animal husbandry sector strengthens
rural livelihoods. Livestock sector in the state
is a major contributor to Gross State Domestic
Product (GSDP); it could be as high as 40
percent of the agricultural GSDP in Kerala.

Out of the total live stock keepers in Kerala,
about 14 % keep bovine, 23 % keep poultry
and 10% keep goats. According to the
livestock census data 2007, of animal
husbandry dept., cattle population in Kerala
is 17.31 lakhs, buffalo population is 58145,
goat population is 17.29 lakhs, pig population
is 59017 and poultry population is 118.2 lakhs.
Average milk yield of crossbred cows in
Kerala is 9.02 litres, buffalo is 6.5 litres and
egg per layer per year is 221. The total cross
bred population of cattle is 93% with exotic
blood limited to 50%.
2.11 The potential of inland water
resources for fish production have not been
utilized optimally till date because Kerala is
still depending on the marine fish. But the
marine fish population is also depleting at a
faster rate and there lies the possibility of
utilising the inland water resources for fish
production. The inland water bodies, including
44 rivers (85000 ha.), 53 reservoirs (44289
ha.), 53 back waters and brackish water bodies
(65213 ha.), the polders of Kuttanad having
a water spread area of 35000 ha., 17,000 ha.
of Kole lands of Thrissur and Malappuram,
12,000 ha. of Pokkali lands in Ernakulam and
Thrissur, 2500 ha. of Kaipad lands in Kannur
can be suitably utilized for production of fresh
water fish. Alarmingly, due to fast
urbanisation; invasion to these places are
taking place at a very faster rate and the area
has diminished to the extent that the Pokkali
lands decreased to 3000-3500 ha.

19

<!-- page 47 -->

Agricultural Development Policy 2015

3. A NEW WAVE POLICY FOR AGRICULTURE
3.1
The world is after food grains. The
traditional granaries of India are being
depleted at a faster rate. Many of the
traditional rice growing states have already
announced 'Rice Holidays'. Kerala is known
as a food hungry state. When the cereals are
not available or costly, people are depending
on the other unavoidable foods like pulses,
meat, egg and milk. Food has become costlier
in Kerala over the past few years. This is
actually inflicting in the wound. Price
escalation with non availability of food is a
serious concern of the state as this may lead
to the control of 'free flow of food grains'.
This gives ample scope for agricultural
production within the state, but the farmers
are still withdrawing from cultivation and the
pressure on land is very high in the state. The
cultivated area is shrinking day by day. Less
profit out turn of field crops compared to
industrial crops and labour availability are the
main issues faced by the agricultural
producers.
3.2
FAO admits that 1.02 billion people
are under nourished worldwide in 2009 which
represents more hungry people and worsening
of unsatisfactory trends. The increase in food
insecurity is not a result of poor harvest but
high domestic food prices, increasing
unemployment and lower incomes which
reduced the food for the poor. Financial crisis
of 2009 deepened the food insecurity. With
the shortfall in production, prices shot up. It
is worrisome that Kerala has the highest deficit
in food production (one per cent of total area,
but three percent of total population) and also
least waste land available.

20

3.3
The decline in agricultural growth
coupled with declining profitability in the
agriculture sector, in the face of rapid growth
of non-farm sector, is one of the major
concerns. The declining profitability is
partially due to fluctuating world prices of
agricultural commodities and the efforts to
keep the domestic prices low to protect
consumers' interest, which resulted in decline
in the terms of trade for the farm sector. This,
coupled with the stagnating and declining yield
levels, resulted in low income to the farmers.
In the present condition many are withdrawing
from cultivation and the land is put in to other
non-agricultural practices.
3.4
These situations and complexities are
to be addressed carefully so that a viable and
sustainable agricultural production system
would prevail and that require careful planning
and a new policy initiation from the part of
the Government. The research and extension
system of the state would be equipped on
these lines and definite bench marks are laid
down in the policy document.
3.5
This definitive approach needs
thorough understanding of the terms
frequently used to describe the content. They
are defined and attached with the policy
document for further clarifications and
strategy / project / scheme formulations and
implementations.

<!-- page 48 -->

Agricultural Development Policy 2015

4. DEFINITIONS
4.1
Definition of Farmer: It is suggested
that the definition given by the National
Commission for Farmers (NCF) may be
adopted for the state policy as the definition
is inclusive of all practitioners of farming. For
the purpose of this Policy, the term
“FARMER” will refer to a person actively
engaged in the economic and/or livelihood
activity of growing crops and producing other
primary agricultural commodities and will
include all agricultural operational holders,
cultivators, agricultural labourers,
sharecroppers, tenants, poultry and livestock
rearers, milkers, fishers, beekeepers,
gardeners, pastoralists, non-corporate
planters and planting labourers, as well as
persons engaged in various farming related
occupations such as sericulture, vermiculture,
and agro-forestry. The term will also include
tribal families / persons engaged in shifting
cultivation and in the collection, use and sale
of minor and non-timber forest produce.
(National Policy for Farmers 2007)
4.2
Kerala State Agriculture debt Relief
act 2006 defined Farmer as a person who
holds whether as owner, licensee or
mortgagee in possession oral lease,
Government land lease “Kuthakapattam” or
partly in one capacity and partly in another
with possession of an extent of land not
exceeding four hectares and whose principal
means of livelihood is agriculture and whose
annual income does not exceed rupees two
lakhs and includes an agricultural labourer,
Kudumbasree and self help group units doing
cultivation by taking over agricultural land on

lease agreement condition. For satisfying the
objective of certain aspects related to credit
and other issues this definition holds good.
The Self Help Groups (SHGs), Joint Liability
Groups (JLGs) and the like groups who are
involved in agriculture are also categorised
under ‘farmers’. The definition of farmer as
described under 4.1 and 4.2 is adopted for
the implementation of the Agricultural
Development Policy.
4.3
Agriculture: is the cultivation of
plants, animals, fungi, and other life forms
for food, fibre, bio-fuel and other products
used to sustain human life.
4.4 It can also be defined that agriculture
is the science, art, or practice of cultivating
the soil, producing crops, and raising livestock
and poultry and in varying degrees the
preparation and marketing of the resulting
products.
4.5
Farming is an activity of primary
production and processing type where by the
farmer derives income, mental satisfaction and
/ or environmental protection initiatives like
soil and water conservation measures in single
or in combination.
4.6
The term 'farm land' refers to the land
or space where cultivation of crops is being
done or capable of cultivation by any crop,
livestock maintenance and intentional
aquaculture is being practised and could be
made possible.

21

<!-- page 49 -->

Agricultural Development Policy 2015

5. INTRODUCTION TO POLICY REFORMS
5.1
The proposed agricultural growth and
prosperity could be made in to reality by
improving the livelihood capital and means
of production.
5.2
Accordingly, the livelihood capital
outlay is classified as natural capital, physical
capital, financial capital, human capital and
social capital. The concept here is to formulate
an agricultural policy that would assure the
fundamental requirements such as food, water,
livelihood, and minimum amenities of life to
all the citizens of the state.
5.3
In developing countries, where a
majority of families derive their livelihoods
from agriculture, sustainable agriculture
cannot be discussed in isolation of sustainable
rural livelihoods. Sustainable rural livelihood
is a multifaceted concept and refers to
maintenance or enhancement of access of rural
families to food and income-generating
activities on a long-term basis. It encompasses
secured ownership of, or access to, resources,
assets and income-earning activities to offset
risks, ease shocks and meet contingencies. In
the Kerala context, where average farm-size
is very small, and poverty and food-security
continue to be preponderant among small
landholders, the notion of sustainable
agriculture ought to be viewed in the context
of need for enhancement of productivity,
production and profitability of agriculture and
above all, for improvement in the economic
conditions of farmers. All these need a careful
and intentional policy interventions by the
Government.

22

5.4 Necessary legal provisions would be created
for the implementation of the Agricultural
Development Policy wherever the situation
demands creation, ammendment and / or
additions.

<!-- page 50 -->

Agricultural Development Policy 2015

6. POLICIES RELATED TO LAND
6.1
The best and most versatile farming
land is a valuable resource that should, in
general, be protected from irreversible
development. As described earlier, the
pressure on land in Kerala is very high. There
is a growing tendency that the land is being
put for purposes other than agriculture since
the status of the land has changed from the
concept as an input to an asset. Thus the value
of the land is on the rising and people expect
an out turn from that investment to more profit
like real estate. This made a steady decline in
our most blessed natural resource namely
land. Unless land is utilized for cultivation, it
becomes a commodity in the hands of land
traders, a situation already critical in Kerala.
This is also important in the context of climate
change and the price rise, globally and locally.
Reducing the 'food miles' is gaining popularity
even in the developed world and Kerala can
show a model in this regard.
6.2
Policy 1:
The farm lands are
to be protected and should not be put for
any other use than farming activities.
6.2.1 The primary requisite for agricultural
production is the farmland (as per section 4.6
of the policy document). For assuring the
production, the availability of the farm land is
to be assured first. The following policies
would help in the preservation of ideal
farmland.
6.2.2 The states like Punjab, Haryana, UP
etc., where agriculture occupies a prime
position with respect to the state's income are
now facing serious threats due to the declining
ground water table and land conversions.

Many of the Indian states like ours are
depending on these states for the food.
6.2.3 The farm land as per the definition
under as per section 4.6 of the policy
document must be conserved for agricultural
purposes alone. A farmer can develop his own
residence and care must be taken to see that
a residential colony should not be grown up
under any circumstances utilising this
provision. Farm lands at any cost should not
be converted other than for Government
purpose at unavoidable circumstances. When
farm lands are needed by the Government for
non agricultural purposes under these very
unavoidable circumstances, the agencies
which are receiving the land must develop
equivalent degraded / wastelands elsewhere
and make it potent for a profitable farming.
An act in this line is a must.
6.3
Policy 2:
The agriculturally
potential land is to be identified and
demarcated with the help of modern
technologies such as remote sensing,
satellite imagery, etc., and a database is to
be made.
6.3.1 Assistance of National Remote
sensing agency will be taken in this regard
and this area is to be notified as 'agriculturally
important'. The maintenance of this database
is the joint responsibility of Agriculture
Department and Revenue Department and
legal provisions for not putting the land for
other purposes are also to be made.
6.3.2 The land records needs to be made
perfect, digitalised and made it available for

23

<!-- page 51 -->

Agricultural Development Policy 2015

open references and official law enforcement.
The ownership of the land should be made
traceable with the help of the database made.
The Revenue Department and Agriculture
Department should see that the database is
updated correctly.
6.3.3 The existing system of land
classification by the revenue officials is only
wet land and garden land. This does not calls
for a detailed classification. The land is to be
classified in to different zones namely, ‘Green
Zone, Pink Zone and Brown Zone’ depending
upon the uses for which it has to be put. The
Green Zone will be marked exclusively for
agricultural purpose, the Pink Zone for
residential purpose and Brown Zone for
industrial purpose.Under no circumstances,
Green Zone would be converted for any other
purposes. Necessary legal provisions for this
has to be made by the Government urgently
to protect the farm land. An individual
approach should be mandatory and at no
circumstances, the least land owners be
affected in constructing house for his own
family requirement.

6.4.2 Since it was observed that huge
amount of farm lands were being purchased
by different Trusts and Organisations and there
must be a ceiling for all these type of activities.
Necessary legal provisions are also to be
incorporated so that the excess land taken by
them can be realised by the Government and
put for farming activities. In this context,
developing the satellite cities utilising the most
valuable farm land would prove to be suicidal
and that should be discouraged with the
enactment of a law.
6.5
Policy 4: Cultivable wastes should
be brought under plough with immediate
effect for augmenting the food production.
6.5.1 Less intensive crops like tubers, pulses
and coarse millet are to be grown in these
potential areas of food production. Schemes
for this type of interventions should be
formulated so that every possible extent of
arable land is put under crops.

6.4
Policy 3: The transactions on
farmlands are to be made more
transparent for protecting the ineterests of
farmers

6.6
Policy 5: Land owned by Kerala
Agricultural University, Department of
Agriculture, Department of Animal
Husbandry, Department of Dairy,
Veterinary University etc., should not be
put for any other use than the purposes
for which it was intended for.

6.4.1 In order to protect the farmlands,
Karnataka Government has suitably amended the
THE KARNATAKA LAND REVENUE ACT,
1964 in 1995 enabling only the farmers for
purchase of notified farm land. But in the Kerala
condition it would be impracticable if the
transactions are restricted. In this context, it would
be desirable if a law could be made for the farm
land transactions making it more transparent.

6.6.1 ‘Keep off’ from the land owned by
Universities and Departments as it would
cause serious problems with regard to the
training and testing of different technologies
developed for the farmers. Considering the
food security point of view, the coming era
would of the type on intensive training and
testing of the technologies. In the research
and development front also there would be a

24

<!-- page 52 -->

Agricultural Development Policy 2015

boom and many developed nations are
investing on the lands of Africa based on this
prediction. So, the land owned by Universities
and Departments in connection with
agriculture should be protected.

6.8 Policy 7: Necessary administrative
mechanism may be evolved for bringing the
different agencies connected with land
related activities under one co-ordination
agency.

6.6.2 The land owned by Universities and
Departments are being put for non agricultural
purposes. As per the quick estimate made, it
was revealed that 22 ha of land was lost by
the KAU, 62 ha by the Department of
Agriculture and 31 ha by the Animal
Husbandry Department from the original
possession. This practice will be discouraged.

6.8.1 Land Development should be
recognised as the most important measure for
the effective up-gradation of production
possibilities of natural resource base. Within the
natural unit of a watershed, soil and water
conservation, agriculture development and
allied activities like animal husbandry,
pisciculture, etc, will be carried out in an
integrated manner with a full involvement and
participation of the farmers. The watershed
based activities will be brought under single
umbrella under the control of single coordination agency and implemented with the
support of various stake holders.

6.7
Policy 6: Appropriate legislative
mechanism may be evolved for the
promotion of ‘Rent a Land for Farming’
programmes.
6.7.1 Keeping the land fallow is a bad trend
observed in Kerala by the Sub-Committee. This
might be due to the fear of possession by the
people who take land for rent for doing
cultivation. This should be addressed with
immediate effect protecting the ownership of
the land and programmes for renting the land
for farming is to be launched by the
Government.
6.7.2 The fallow lands should be made available
to the SHG and JLG groups like ‘Kudumba
Sree’ for increasing the production as well as
improving the livelihood support. The rent on
these lands should be regulated so that the owner
and tenant will be getting remunerative out put.
6.7.3 The operationalisation of these
programmes should be in line with the Farmer
Producer Organisations as described under the
Chapter 18.

6.9 Policy 8: The Government should
have
the
aim
of
employing
InformationTechnology to transform the
existing system of land records maintenance
and thereby ensuring efficient, accurate and
transparent delivery mechanism and conflict
resolution in ownership of land.
6.9.1 The land records digitisation is a much
needed step in streamlining the entire system
pertaining to land transactions in the state. The
absence of an updated database is the major
reason behind land disputes. A central database
having a comprehensive link to all land-related
organisations under a single network is needed
for monitoring the land related transactions,
better service delivery etc. With such a set-up
the government officials sitting at their offices
can see any transformation of land or change
of ownership.

25

<!-- page 53 -->

Agricultural Development Policy 2015

7. WATER RELATED POLICIES
7.1
Water has become one of the most
abused resources in Kerala. The State is
blessed with 3000 mm of annual precipitation,
41 rivers running across the full breadth, 3
rivers in partial coverage and numerous
wetlands. But if the rivers are put together,
they may not carry water as Krishna River
carry.

Therefore, assuring ground water for all crop
production programmes is the need of the
hour. Therefore, the policies related to
water considering agriculture should have
the following dimensions. Apart from the
policy initiatives started as per the State
Water Policy ,1992 these would also be in
vogue.

7.2
As per the classical classification land
is the primary requisite for production and
when agriculture is concerned water also
forms an important component. All
households require water for consumption.
Farming households also require water for
producing crops and raising livestock.

7.6
Policy 9: Preservation and
sustainable use of water should be the
motto of all crop production programmes
of the state.

7.3
The ground reason for the nonavailability of water during the critical stages
of requirement as a part of its sustainable use
should be looked in to. The probable reasons
could be the increasing level of contamination,
the destruction of wetland ecosystems, and
over-exploitation of the remaining water for
domestic and industrial uses.
7.4
During March 1992, a state water
policy was announced by the then Hon’ble
Minister for Irrigation and Cultural Affairs Sri.
T.M. Jacob. The cropping pattern, land use,
hydrological status and environmental need
of the Kerala State are distinctly different from
those of the other states. That was the
background for formulating a state water
policy.
7.5
Substantial increase in area under
crops grown more than once in Punjab had
been primarily due to the availability of
assured ground water for irrigation.

26

7.6.1 Majority of farmers in the state
depend on groundwater for irrigation. This
resource, in which farmers may have
invested their hard-earned savings, is being
depleted and the water table is receding fast.
Therefore, rainwater harvesting and aquifer
recharge would be accorded priority for
ensuring the stability and sustainability of
water.
7.6.2 When the crop production schemes
of the Departments are formulated, it should
contain the different aspects of sustainable
use of water. Water-use efficiency can be
enhanced by generating synergy with seed
varieties, nutrients (macro and micro) and
farm implements. So a crop production
scheme is to be formulated with all these
aspects in mind and there should be a
sustainable water use component in every
such programmes.
7.7
Policy 10: Water budgeting should
be adopted in a watershed basis.

<!-- page 54 -->

Agricultural Development Policy 2015

7.7.1 Water budgeting could be defined as 'an
estimate of harvest of water resources and its
utilization for a set period of time'. The
requirement of water in a watershed is assessed
scientifically and a plan is to be made. The water
available from rains, irrigation requirement, water
holding capacity of the soil, irrigation frequency,
method of irrigation, crop duration etc., should
be taken in to account and a water budget is to
be formulated with the help of irrigation
engineers, NGOs, farmers and Agricultural
Officers. This would not only help to regulate
the water use but also in improving the per unit
productivity of the available water. The water
use can effectively be extended to other areas
which would therefore be helpful in assuring the
crops. This should be given priority in water
scarce areas of the state.
7.8
Policy 11: Rain water harvesting
and aquifer recharge would be given
priority for ensuring the stability and
supply of water.
7.8.1 Rain water harvesting is essential
because the surface water is inadequate to
meet the demand and the state have to depend
on ground water and due to rapid
urbanization, infiltration of rain water into the
sub-soil has decreased drastically and
recharging of ground water has diminished.
7.8.2 Artificial recharge to ground water is
a process by which the ground water reservoir
is augmented at a rate exceeding that obtaining
under natural conditions or replenishment.
Any man-made scheme or facility that adds
water to an aquifer may be considered to be
an artificial recharge system.

7.8.3 Kerala has over 6.60 million wells
according to a study conducted as early as
2007. This makes it the highest density of wells
in the world. With a simple method of rooftop
rainwater harvesting, keeping the roof clean,
providing a simple filter and leading the rainwater
into the dug-wells water security can be ensured
for the whole year. Fluoride toxicity seen in parts
of the State can also be address by this.
7.9
Policy 12: The micro-irrigation
technology is to be popularised in the state
with adequate share of state budget.
7.9.1 The largest share of energy is utilized
for pumping of irrigation water. Various
research studies have shown that water saving,
electricity saving, irrigation efficiencies and
yield of crops using drip irrigation are
substantially higher than crops irrigated by the
conventional flood irrigation method.
7.9.2 The modern irrigation systems, drip
and sprinkler can act as a mitigation measure.
Eventually with little water available, crop
can survive and can virtually come out the
over dependency on monsoon. Because,
whatever rain is available in arid regions can
be will be stored and water applied to root
zone with drip, will bring this region out ‘rain
feed’ clutches with increased productivity.
Apart from that the costly inputs such as
chemical fertilisers can be significantly
reduced which will in turn reduce the cost of
production and environmental damages
7.9.3 Micro Irrigation has following
advantages- 1. In this type of irrigation system
water is saved through different ways such as
- by reducing loss of water in conveyance - by
reducing loss of water through evaporation, run

27

<!-- page 55 -->

Agricultural Development Policy 2015

off, and by deep percolation. - A water supply
source with limited flow rates such as small water
wells or city/rural water can be used in this type
of irrigation system. 2. Energy savings up to 3040%– This type of irrigation system requires a
smaller power unit and consumes less energy. 3.
This type of irrigation system is helpful in inhibiting
growth of weeds as it keeps limited wet areas.
Under this condition the incidence of disease is
also reduced up to major extent. 4. Fertilizers
and chemicals can be applied with water through
micro irrigation system. This systems can be
automated which reduces labor requirements. 5.
Improved production on marginal land.

7.11 Policy 14: Sub surface dykes are to
be constructed at possible places for the
ground water recharge

7.10 Policy 13: Farm ponds and
Thalakkualams needs to be promoted and
protected.

7.11.2 Subsurface dike has many
advantages. It does not require additional
surface reservoir. There is no loss of
agricultural land. There is minimum
evaporation loss since the storage is
subsurface. There is no siltation and loss of
reservoir capacity. The cost of construction
is low and maintenance is negligible. It is
environment-friendly and it can be
implemented with locally available
materials.

7.10.1 It is estimated by CWRDM that about
910 farm ponds are there in the State with 0.5
ha area. About 50% of these need rejuvenation.
There are more than 20 artificial reservoirs and
2-3 large fresh water lakes in the state having
good quality water. There are numerous perennial
springs throughout the state with ample amount
of water which could be utilised for drinking and
irrigation.
7.10.2 The ‘Thalakkulams’ form the apex
irrigation source in a Padasekharam or a
cultivation area. They were usually fed from the
natural springs and the excess water would be
drained out through an out going channel. These
systems should be restored with Government
and people participation and that can reduce the
drought problem by 30%. The existing
programme of ‘Sahasra Sarovar’ should be
intensified. The LSGs should take a lead role in
this regard.

28

7.11.1 Subsurface dike is a structure that is
built in an aquifer with the intention of
obstructing the natural flow of ground water,
thereby raising the ground water level and
increasing the amount of water stored in the
aquifer. The ideal location for the dike is a
well defined, wide, greatly sloping valley with
a narrow outlet having limited thickness of
loose soil or porous rock on the top with
massive or impervious rock below.

7.11.3 In areas of a well defined watershed
with a narrow outlet and undulating
topography, which is typical of Kerala,
subsurface dike is an efficient system to
conserve and utilise the rainfall that is received
in a watershed. The water conserved in the
dike can be utilised for irrigation and other
purposes. It also allows for recycling of
irrigation water and nutrients in the catchment
area.
7.12 Policy 15:
The irrigation canals
of Kerala are to be structurally reset for
the prevention of seepage loss of water.

<!-- page 56 -->

Agricultural Development Policy 2015

7.12.1 Huge water loss is happening through
the old earthen irrigation canals throughout
the state. The technology suggested for
improving the irrigation efficiency by IDRB
is the spot delivery of irrigation water to the
fields through a covered water way
mechanism. This should be adopted in areas
where the tail-end plots does not receive
irrigation water at all.
7.12.2 The main irrigation canal where the
covered system of water delivery is not
possible, the top portion of it should be
covered with solar electric panels, so that
evaporation loss is minimised and at the
same time power is also generated. The
power thus generated could be very well
used for agricultural purposes and thus the
dependency on costly electric power could
be minimised.
7.13 Policy 16: The activities of the
Committee on the release of irrigation
water should be in deeds than in words.
7.13.1 The district level committee on the
release of irrigation water is to be recasted
at Panchayt level including the Agricultural
Officer of the area. Periodic meetings should
be made mandatory and only according the
recommendation by this committee the
regulation of irrigation water should be done.
At present, there are instances where the water
was released during the harvesting season and
no water was available during the critical
phases of crop growth.
7.14 Policy 17:
Pumping subsidy
provided to the Kuttanad and Kole land
farmers are to be routed through the
Department of Agriculture.

7.14.1 Kuttanad and Kole areas are part of the
‘Ramzar’ sites and globally protected areas of
agricultural heritage. The outlook on the
importance of these sites made the
Government to take the tax payers’ money
and utilise it for the sustenance of this Global
Agricultural Heritage. As a part of it for
conserving the rice cultivation followed here
a huge amount of money is being spent.
Considering the need for a single united
agency to look after the cultivation aspects
which is liable for invasion by pests and
diseases and to protect the global heritage,
all the interventions are to be routed through
a single agency. Agriculture Department may
be made the sole responsible agency for these
type of activities as per the mandate.
7.14.2 During the sittings at Alleppey and
Thrissur, the farmers vehemently made a plea
before the sub-committee that the pumping
subsidy should be routed through the
Department of Agriculture, so that, they can
approach only one agency for all the
cultivation aspects.
7.15 Policy 18: All interstate water sharing
g agreements have to be timely reviewed
to promote thrust areas of irrigation
development.
7.15.1 Joint Water Regulation Boards of
interstate river water agreements must have
agriculture experts also while negotiating the
sharing pattern for a particular season.
7.16 Policy 19: Irrigated agriculture being
the largest water demanding sector, special
attention has to be given for creating and
sustaining irrigation infrastructure.

29

<!-- page 57 -->

Agricultural Development Policy 2015

7.16.1 The possibility of increasing the storage
capacity of major and minor irrigation schemes
shall be explored and de-silting of dams and
canals has to be taken up as a priority area to
improve the water availability for crops in the
ayacut area.
7.16.2 Irrigation scheduling of all major and
minor irrigation projects shall be formally
completed and published before the
commencement of each irrigation season.
Agriculture Department and Water Resources
Department shall jointly coordinate the cropping
pattern after assessing the water availability in a
scientific manner.

30

<!-- page 58 -->

Agricultural Development Policy 2015

8. SOIL RELATED POLICIES
8.1
The soil is home to a large proportion
of the world's biodiversity. In a balanced soil,
plants grow in an active and steady environment.
The mineral content of the soil and its heartiful
structure are important for their well-being, but
it is the life in the earth that powers its cycles
and provides its fertility. Without the activities
of soil organisms, organic materials would
accumulate and litter the soil surface, and there
would be no food for plants. Natural Soil is often
referred to as living because it contains billions
of organisms that plants need for their health
and longevity.
8.2
In general, the soils of Kerala are acidic,
kaolintic and gravelly with low CEC(Cation
Exchange Capacity), low water holding capacity
and high phosphate fixing ability. Policy
initiatives are meant for improving the soil quality
aspects.
8.3
Policy 20: Bio-Manure and Bio
Fertiliser production is to be enhanced for
reviving the soil health and should be one of
the primary activities of the Department of
Agriculture.
8.3.1 Use of organic manure in the soil would
be the effective step in maintaining the health of
the soil. Composting, vermicomposting, use of
Farm Yard Manure, use of green manure crops,
green leaf manuring etc., would be promoted as
part of it. The availability of these types of natural
organic manures is to be assured by employing
effective mechanisms and logistic networks so
that the organic content of the soil is increased
to the level ideal for shifting towards 'Organic
Farming' without affecting the returns.

8.3.2 There will be initial decrease in the
production where ‘Organic Conversion’ is being
parctised. Appropriate financial support
programmes are to be launched by the
Government to bridge the loss sustained due to
the shift in to organic parctices.
8.3.3 The Bio Fertiliser production programmes
are to be taken up by the PSUs, following model
as that of FACT, done during the 1960s and
70s in input production.
8.4 Policy 21: The production potential of
the soil is to be improved.
8.4.1 pH regulation in the problem soils would
be an effective step in increasing the production
potential. Most of our paddy fields are in the
acidic range and it needs regular supply and
application of soil ameliorants like lime and
gypsum. Acidity regulation involves a
community based approach where the farmers
and LSGs can play their roles effectively. As the
availability of lime and gypsum are limited now
a day, the application of environmentally safe
industrial wastes such as basic slag would be
promoted.
8.5 Policy 22: The first week of June of
every year shall be observed as ‘Green
Manure Week’ by the State Government
for the promotion of green manuring
methods and green manure crops.
8.5.1 June is the starting month with respect
to agriculture in Kerala. This strategically
important period is to be treated as Green
Manure Week for the promotion of different
green manure crops of Kerala. Different

31

<!-- page 59 -->

Agricultural Development Policy 2015

planting materials such as Daincha seeds,
glyricidia branches are to be distributed to
farmers in a campaign mode. Different types of
composts are to be popularised and different
methods are to be employed in farmers fields.
However, a massive public participation
programme is a must in the case of promotion
of organic manure production. The aim of the
State is to produce the required quantity of
organic manure within the farm it self.
8.6 Policy 23: A cadastral Level soil
information system is to be launched
8.6.1 A database of the soils of Kerala State
is to be made indicating the different
characteristics of the soils and the crops suited
for them with the corrective measures needed
for introducing alternate crops. Farmers should
get these details at their fingertip through the
web and facilitated by Agricultural officer who
is the grass root functionary of the system. The
database on soils should be at Panchayath level
base and treated as baseline for any development
programmes.
8.7 Policy 24: Make every effort to reduce
soil erosion on a watershed basis.
8.7.1 Soil conservation is an effort made by
man to prevent soil erosion in order to retain
the fertility of soil.
8.7.2 Any erosion such as gullies already
formed should be tackled by construction of
dams or obstructions. Ploughing and tilling of
land should be done along contour levels so that
the furrows run across the slope of land. Bunds
should be constructed according to contours.
Trees reduce the force of straight winds and
obstruct blowing away of dust particles. Plants,

32

grass and shrubs reduce the speed of flowing water.
Therefore, such vegetable cover should not be
removed indiscriminately, where it dose not exist,
steps should be taken to plant it.
8.7.3 Measures suggested for soil conservation
for the prevention of soil erosion are
(i) Planting cover crops such as grasses, on
uncultivated land.
Trees should be planted along hill slopes.
(ii) Adoption of correct farming techniques such
as contour ploughing and strip cropping.
(iii) Terracing, the practice of cutting steps in
hillside, to create level land for cultivation.
(iv) Construction of check dams on steep slopes
which prevent gully erosion and spreading of
gullies.
(v) Creation of wind breaks by planting lines of
trees, hedges or fences which obstruct the path
of wind thereby reducing its speed and hence
reducing soil erosion.
8.8 Policy 25: Steps should be take to develop
regional nutrient plans on a watershed basis
preferably.
8.8.1 Even though different soils have some
properties that cannot be changed, such as
texture, soil quality can be improved by
implementing good management strategies. A
good management strategy includes the use
of nutrient plans by which nutrients to the soil
at the required level can be very effectively
be added.

<!-- page 60 -->

Agricultural Development Policy 2015

9. CLIMATE & ENVIRONMENT RELATED POLICIES
9.1
According to Indian Journal of GeoMarine Sciences “Climate Change is the
greatest ecological, economic and social
challenge of our time”. Therefore, it is high
time to have climate change adaptation
strategies to mitigate ill effects of weather
aberrations and sustain crop production under
projected climate change scenario because,
Kerala is the most vulnerable place as far as
the climate change is concerned.
9.2
Special attention is to be given in this
direction to the thermo-sensitive crops like
black pepper, nutmeg, cardamom, tea, coffee
and cocoa as temperature range is likely to
increase and rainfall is likely to decline along
with deforestation as these crops grow
under the influence of typical forestagroecosystems.
9.3
The potential impacts of global
climate change in coastal Kerala are salinity
intrusion into aquifers and rise in salinity of
wetlands. It has also been observed that
over exploitation of ground water in certain
stretches of Kerala coast has contributed
to the entry of salinity into the coastal
aquifers from the sea. Reports say that if
the ground water table goes beyond 600 ft.,
there would be increase in the concentration
of Na+ salts. With these backgrounds
Government should consider the following
policies.
9.4
Policy 26: Research & Development initiatives are to be strengthened in
climate change adaptation for sustenance
of agricultural production in the State of
Kerala.

9.4.1 As crops are more vulnerable to short
terms variabilities rather than long term
climate changes, the impact of climate
variability on crops has to be documented.
Detailed investigations are the need of the
hour to understand the short and long term
effects of climate change in the case of
plantation crops through crop-simulation
models. To understand the impact of climate
change on crops, simulation models need to
be developed and revalidated.
9.4.2 Crop species- specific and locationspecific crop weather relationships are to be
worked out based on long period experimental
data.
9.5 Policy 27:Network of meteorological
observatories should be increased.
9.5.1 Presently, the network of temperature
stations under IMD across the State is scarce,
though it has a good number of rain gauge
stations. Hence, there is urgent need to record
surface air temperature across the State. This
will provide a better picture of temperature
variability over the State under the projected
climate change scenario. This still holds good
across the high-ranges. A series of microweather stations at all the Departmental farms
are also to be established in collaboration with
competent agencies like ISRO.
9.6
Policy 28: There is a need to train
skilled personnel in the field of climate
change adaptation and mitigation.

33

<!-- page 61 -->

Agricultural Development Policy 2015

9.6.1 The changes in rainfall and thermal
regimes may result to shifting of climate from
wetter to drier zones within the humid type of
climate. Therefore, there is a need to study in detail
on rainfall and temperature trends across the State
on zone-wise. The climate shifts over Kerala, if any,
and occurrence of droughts and floods in the State
have to be brought out in projected climate change
scenario. The impact of climate change/variability on
crops grown in the State, including food security of the
Statehasnotbeenattemptedundertheprojectedclimate
changescenario.Trainedpersonnelinthisregardshould
be made available for mitigating the climate change
effect on crops and environment.

9.8.1 Disaster
Risk
Management
encompasses a full continuum from preparedness,
relief and rehabilitation, mitigation and prevention.
The Policy aims to increase and sustain resilience
of vulnerable communities (especially farmers) to
hazards through diversification of their livelihoods and
coping mechanisms. This entails a shift from the short
termreliefresponsestodevelopment.Themechanisms
in preserving livelihoods and minimising suffering by
providingsufficientandtimelyearlywarninginformation
on potential hazards that may result to disasters, are to
be done in a co-ordinated manner. It is also aimed at
alleviatingsufferingbyprovidingtimelyandappropriate
response mechanisms for disaster victims.

9.7
Policy 29: Optimize the ecological load
on the natural systems as well as building up
the State’s economy while minimizing
environmental degradation.

9.8.2 If needed, enactment of an enabling
comprehensive legislative framework which lays
down the legal foundation for collaborative
partnership in institutional (different Departments
of the Government) participatory management of
disasters, including mobilisation of the essential
wide range of resources (financial, material,
technological, professional and technical, human
and infrastructural) necessary for management
of all disasters should be done.

9.7.1 The Policy on Environment 2009 has been
designed to suit the specific local conditions of the
State of Kerala and to help re-orient its development
in conformity with environmental perspectives
so as to make the development sustainable. The
policy accepted in the same document is also
accepted here.
9.8 Policy 30: The Government should make
a focussed approach to facilitate the
possibility of strategic planning for
systematic Disaster Management, as well as
for contingency planning at District, Block
and Grama Panchayat levels against all
emergencies, pro-actively (for preparedness,
prevention and mitigation) and responsively
(for response, relief, repatriation,
rehabilitation, reconstruction, the whole way
to recovery in the full Disaster Cycle).

34

9.8.3 There is a need to bridge the current
gap between science, policy and practice. For
example, there has been a disconnect between
research and end users. Relevant climate
information is often inaccessible or not usable
or understandable by end users and decisionmakers. International organizations and
responsible national line departments should be
encouraged to be proactive in facilitating
collaboration among environment research
institutes working on climate change, service
providers such as extension services and
meteorological services, line departments and
humanitarian actors.

<!-- page 62 -->

Agricultural Development Policy 2015

10. POLICIES RELATED TO WATERSHED
DEVELOPMENT APPROACH
10.1 Effective use of land and water is
fundamental to growth and sustainable
development. The concept of watershed
management has evolved to ensure effective use
of both natural and social capitals. Thus, the
watershed development programmes include
land, water and human resources as essential
components.
10.2 Policy 31: Agriculture planning and
development programmes of the state shall be
based on watershed.
10.2.1 Local
self-government
level
decentralized water management plans to be
developed for long periods. Water resources
management plans with suitable watershed
measures, afforestation, eco – restoration of
catchments, rainwater recharging and
harvesting, storm water drainage, water
auditing, recycling and reuse etc. should be built
into it. These water management plans should
integrate into basin level management plans.

complicated than just too many people putting
their straws in the glass. The growing conflicts
over water use are about the broader questions
about ownership of common resources, and
equity of access to those resources.
10.3.2 Human race has taken water for granted
and massively misjudged the capacity of the
earth’s water systems to sustain the demands
made upon it. The supply of available fresh water
is finite and represents less than half of one
percent of the world’s total water stock. Thirtyone countries are facing water stress and scarcity
and over a billion people lack adequate access
to clean drinking water. It is anticipated that by
the year 2025, as much as two-thirds of the
world’s population will be living with water
shortages or absolute water scarcity.
10.4 Policy 33: The watershed development
plans are made to improve rural livelihoods and
reduce poverty by developing and
strengthening community based approaches.

10.2.2 Within the natural unit of a watershed,
soil and water conservation, agriculture
development and allied activities like animal
husbandry, pisciculture, etc, will be carried out
in an integrated manner with a full involvement
and participation of the farmers.

10.4.1 The programmes should aim at improving
water, soil, biomass and other natural resources
which would help the rural livelihoods and
institutionalizing and scaling up participatory
approaches and processes in natural resource
management with a focus on livelihoods.

10.2.3 While formulating the projects, the
pooling of available funds should be made and
the officials responsible for the implementation
of the different components should sit together
under a single co-ordination agency such as the
Grama Panchayats guided by the Block level
ATMA.

10.4.2 They also should facilitate diversification,
decentralization and devolution of decision
making powers in the management of natural
resources. One of the important objectives is to
focus on the future mode of optimum and
sustainable use of natural resources for
livelihoods.

10.3 Policy 32: It is the responsibility of the
state for water management / water poverty.

10.4.3 The theme of any watershed development
should be the improvement of agricultural and
livestock production and the well-being of local
inhabitants without degrading the fragile
environment.

10.3.1 While the world’s growing demand for
water is a serious problem, the story is more

35

<!-- page 63 -->

Agricultural Development Policy 2015

11. POLICIES TO ADDRESS FARMERS IN DISTRESS
11.1 In a period nearing twenty years, the
farmer suicides crossed a quarter million mark
in India. During this period, Kerala has also
witnessed a tragic scenario of many farmers.
This fact is alarming since the total number
of farmers is declining significantly. In other
words, farm suicides are rising through the
period of India's agrarian crisis, even as the
number of farmers is shrinking.
11.2 Crisis is now manifested in different
ways: non-remunerative prices, volatile
economy, absence of a protective market etc.
Even agrarian crisis also manifested in the
form of burning their farm fields, throwing
the agricultural produce on the roads etc. It
is true that forms of suicide is slowly
changing: earlier the suicide was confined to
swallowing pesticide/hanging or even
jumping into the well however now the shift
has taken place wherein farmers’ are now
committing suicide by jumping into the
burning field.
11.3 The suicides appear concentrated in
regions of high commercialisation of
agriculture and very high peasant debt. Cash
crop farmers seemed far more vulnerable to
suicide than those growing food crops. Yet
the basic underlying causes of the crisis
remained untouched. The predatory
commercialisation of the countryside; a
massive decline in investment in agriculture;
the withdrawal of bank credit at a time of
soaring input prices; the crash in farm incomes
combined with an explosion of living and
cultivation costs; the shifting of millions from
food crop to cash crop cultivation with all its
risks; the corporate hijack of every major

36

sector of agriculture including, and especially,
seed; growing water stress and moves towards
privatisation of that resource.
11.4 Kerala’s agriculture is hugely cash
crop-based and fragile at the best of times.
Cash crop prices are highly volatile, and often
rigged by powerful corporations at the global
level. This makes Kerala more vulnerable to
price shocks than any other State in India. In
the early years of the last decade, for instance,
vanilla fetched Kerala farmers prices of up to
Rs. 4,000 a kilogram. It then crashed to under
Rs. 80 a kg or less , wrecking farmers who had
invested huge amounts of mostly the borrowed,
money in its cultivation. Most plunged into debt,
several committed suicide in despair.
11.5 Kerala set up a debt relief tribunal in
2005, raised support to the farm sector and took
other steps to mitigate distress. Even its troubled
food crop sector received a boost. Between 2005
and 2013, Kerala doubled the support price for
paddy from Rs. 700 to Rs.1,700. Yet, it seems
that the State will take a worse hit than any other
due to the multiple free trade agreements the
Union government has signed or will enter. And
reports of rising farm suicides again in the cashcrop citadel of Wayanad signal which way
Kerala is now headed.
11.6 Policy 34: The Government should
take earnest steps to instill confidence in
the debt-ridden farmers for the prevention
of farmer suicides for ever by the
introduction of ‘relief funds’ or ‘relief
loans’ so that the immediate financial
requirement can be met by them.

<!-- page 64 -->

Agricultural Development Policy 2015

11.6.1 It was observed in the farm families in
Waynad district which were crushed by the
suicides of the farmers who were the only support
to them, observed that financial institutions,
including cooperative banks and scheduled
commercial banks, are unsympathetic to the
needs of farmers and were very much reluctant
in providing crop loans to them. As a result,
farmers were forced to take loans from private
financial institutions at a higher rate of interest.
In these types of cases Government intervention
is necessary to assure the farmers credit at the
time of emergency. The Governmental
mechanisms should act concurrently to build
confidence among the farmers that the situation
could be managed easily by them with the help
of the most powerful agency, the Government.
11.6.2 The landless farmers usually takes land
on lease to grow crops like ginger and
plantain. They borrows from banks,
cooperatives and money lenders for their
farming operations. But the price crash and
crop failure would shatter their dreams and
they will be forced to close the chapters of
their lives. The price is to be assured for the
produce and thereby building the confidence
has to be taken up by the Government by
employing multi disciplinary approach and
income from farming is to be assured. The
details of the same are presented in the
Sections 20.5 and 20.10
11.6.3 To boost up the level of confidence
among the farmers especially the debt ridden
ones who are at the edge of suicide the primary
financial requirement of them should be met
by the Government to save their and their
families’ lives. The immediate strategy of the

Government is to address this issue by providing
them ‘relief funds’ or ‘relief loans’ so that the
immediate requirement of money can be met and
the confidence level of the farmer can be raised
avoiding the suicidal attempts.
11.7 Policy 35: The approach of the
financial institutions needs to be changed
while attempting for recovery from the
debt ridden farmers and an integrated
resource base analysis and separate fringe
credit support for them should be extended
so that they would be brought above the
repayment threshold level.
11.7.1 There were few attempts made in this
regard in various parts of the State. The cases
of debt ridden farmers are to be taken and
addressed individually. The causes of
indebtedness is to be assessed as a farm family
basis. The farmers will possess different
income earning avenues in their family level
itself. Those have to be assessed before
attempting for the recovery of money. Many
farm families have opportunities for
developing themselves from the resources
they have; like adoption of improved
methodology in farming to get more income,
family members can go for additional
employment like providing tuition if they are
educationally qualified, can be engaged in
animal husbandry, dairying, poultry, inland
fisheries, food processing, marketing, part
time avocations like bee keeping, ornamental
aquaculture, pet animal rearing etc. These
possibilities are to be assessed and a
‘livelihood plan’ should be worked out for
those who are indebted.

37

<!-- page 65 -->

Agricultural Development Policy 2015

11.7.2 The livelihood plan is inclusive of the
crop plan and has to be worked out by a body
consisting of Local Body Head, Agricultural
Officer, Veterinarian, Dairy Development Officer,
Village Extension Officer and Bank Official. The
‘fringe financial assistance’ required for this
livelihood plan is to be arrived by the joint meeting
of the proposed body. This type of intervention
was adopted in the Perumatti Service Cooperative Bank during 2004-05 in the case of
indebted farmers and succeeded in implementing
it. The plan should be covering the aspects like
production plan and repayment plan. The
primary objective of giving a ‘fringe finance’ is
to make them capable of repaying the loan by
assuring livelihood support and income
generation from the unidentified resources a
farmer has.
11.7.3 Thus a detailed resource analysis has
to be carried out for making a livelihood
support plan for bringing the farmers above
the repayment threshold level.
11.7.4 In order to track the proper utilisation
of credit and to monitor the credit availed
farmers, the financial institutions should
communicate the month wise report on them
to the proposed body under Section 11.7.3.
The convenor of the proposed body should
be the Village Extension Officer. A proper
advice can be given to the farmers and an
effective monitoring mechanism can be
evolved for the credit mobility and
requirement. A statutory authority may be
given for this body for reporting the matter
to the District Collector at times of
intervention such as crop loss, natural
calamity, price fall etc.

38

11.7.5 Hence, a comprehensive intervention to
ensure self-reliance and capacity building of
farmers in modern farming techniques, a
monitoring and support system for vulnerable
farmers and a transparent, village-level system
for making a livelihood plan to derive income
from alternate sources along with farming is
required to prevent farmers’ suicides in the
near future.
11.8 Policy 36: The loans taken by the real
and full time farmers for their needs like
housing, medical treatments, marriages,
children’s education and other
unavoidable consumption needs are also
to be treated as agricultural loans as the
repayment is to be made from farming.
11.8.1 Like the other individual in the society
farmer is to be treated as a professional who
is deriving income from the ‘universal
profession’ of farming in the case of the credit
requirements of consumption such as housing,
marriages of his children, educational
requirements, medical treatments etc. He
is the ultimate producer and the
Committee is of the opinion that the
requirements of the producer is to be
treated as the requirement of production.
If he avails the loans for the purposes
other than farming, the repayment of the
same has to occur from the farming.
Considering his unique involvement in the
production process and the role of
supporting his own family, the credit
availed for immediate purposes other
than farming is to be treated as
agricultural credit. All the benefits and
formalities for availing credit for

<!-- page 66 -->

Agricultural Development Policy 2015

agricultural purposes are to be applied here
also. The Government should see that only full
time small and marginal farmers whose primary
income is from agriculture and allied activities
shall be entitled for this.
11.9 Policy 37: There is a need to strengthen
the Mental Health Programmes at primary
health care level, involvement of extension
officials and institutions so as to offer
support and counselling to vulnerable
farmers.
11.9.1 Many researchers found out that there
exists a strong correlation between the
incidence of natural calamities and price fall
of the produce with rate of farmer suicides.
The need for stress relief camps and
counselling services for farmers was expressed
in many sittings. Many psychologists believe
that even in the absence of psychiatric
morbidity, farmers are more likely to report
that life is not worth living compared with the
general population.
11.9.2 Hence, if a natural calamity is predicted,
there is the need for rapid mobilization of
extension workers, psychologists and
psychiatrists to the calamity hit region along with
other supportive measures. The Government
action most often is predominantly limited to
political announcement of exgratia benefits and
not towards prevention strategies.

39

<!-- page 67 -->

Agricultural Development Policy 2015

12. FARMER & FARM LABOURER WELFARE
RELATED POLICIES
12.1
In the past, advisory services was
being focused in the first place for optimizing
production and profitability while improving
the ecological and social status of the farms
received much less attention. New societal
demands now urge the Government to focus
on the welfare of farmers and farm labourers
so that the status of them in the society is
improved and the new generation is attracted
towards farming.
12.2 The only state in India where a pension
scheme for farmers is being operated is Kerala.
Apart from the monthly pension, other welfare
measures such as farmer insurance is also
being done. The following policy measures
are suggested for imparting a ‘human face’ to
the agricultural development initiatives of the
Government.
12.3 Policy 38: The Pension Scheme for
farmers will continue
12.3.1 It was a great thing from the part of
the Government during 2009 to include
farming community viz.,the paddy farmers
under pension scheme of the government. The
introduction of a State wide farmers pension
scheme in 2012 was also a landmark move. It
also acted as a recognition for the real farmers
of the State. The government should act to
restore young farmers' confidence in the
farmers pension scheme also by periodically
and sustainably improving the monetary
benefit.
12.3.2 The government should not be
reluctant to change the basic design to meet
the rapidly changing realities. The biggest

40

realities today are the ever-growing ruralurban gap - which has to be narrowed - and
recognizing that most of the farmers today
will not be farmers after two decades.
Improving the scheme will undoubtedly cost
more money now, but it will lay the foundation
of a more genuine self-sufficient pension
scheme for the future.
12.4 Policy 39: As agricultural
development and farmer welfare are
inseparably linked, a farmer welfare fund
board is to be established.
12.4.1 As the population engaged in farming is
getting reduced day by day due to various
reasons, it is very essential to attract and retain
more and more people in the sector, especially
younger generation. As per the National
Commission on Farmers, a farmer welfare
board is suggested as part of this initiative. The
benefits shall be restricted to farmers those who
derive income primarily from agriculture. The
small and marginal farmers should be given
preference for all the welfare measures initiated.
12.4.2 A fixed contribution, which is on a half
yearly or yearly basis from the farmers, cess
from spices/coconut and other trades,
contribution from the State and Central
Governments, contributions from Nationalised
and Cooperative banks, contributions from
trade houses and export houses in agribusiness
in the form of cess will form the operational
capital of the Board.
12.5 Policy 40: There is a need to promote
comprehensive health insurance schemes for all
the farmers of the state.

<!-- page 68 -->

Agricultural Development Policy 2015

12.5.1 Due to climatic changes and changes in
the environment, excessive per capita
expenditure on health rose to Rs. 92/- as per
the NSSO results. Health and life insurance
coverage up to 10 lakh, reasonable pension
amount, loan facilities for education of
children and marriages of children etc., should
be the prime focus of the welfare board. On
the job accidents, should also be made eligible
for pension. Family pension also should be a
major component.

12.7 Policy 42: A production incentive will
be awarded to the farm laboures who
works in the agriculture sector for not
below than 100 days.

12.5.2 Full time farmer with land area up to 2
ha and primary vocation is agriculture and the
only source of income will be brought under this
programme.

12.7.2 If the work is done by any labourer from
outside the state, the benefit shall be passed on
to them also for assuring the availability of labour
throughout the year.

12.6 Policy 41: Agriculture labour banks
will be started at Panchayat level to address
the issue of shortage of agricultural
labourers.

12.7.3 The details regarding fund generation is
detailed in the Section 20.5 of the Agricultural
Development Policy.

12.6.1 A labour bank at Panchayat level may
be formed with co-ordination at the Block
level and allocation of MGNREGS workers
for agricultural and related works is an
important aspect to address the shortage of
workers for agricultural activities.
12.6.2 This labour bank should act as a source
of all kinds of logistic support for agricultural
labourers and should provide all facilities include
ESI and Pension based on quantum of work
done by the labourer. A minimum of 100 days
per year should be worked by them in the
agricultural sector for this scheme. This
association of labourers shall be for the unskilled
persons only.

12.7.1 As the farm labourers who work in the
agricultural production front contributes directly
to the farm production they should be paid a
production incentive. The eligibility criteria should
be such that they should work in the farms at
least 100 days per year.

12.8 Policy 43: Sufficient number of
seats in professional courses should be
reserved for the children of farmers so as
to improve their social status.
12.8.1 By reserving sufficient seats in
professional educational courses for their
children, the society would feel that the
profession of farmers is an attracting one. This
would help in retaining the farmers in farming
and attracting others towards farming as this
profession is assuring a social security.

41

<!-- page 69 -->

Agricultural Development Policy 2015

13. POLICIES RELATED TO HUMAN RESOURCE
DEVELOPMENT IN FARM SECTOR
13.1 Human resources constitute the most
critical inputs relying on the use of science
and technology for development. It involves
a planned approach to learning aimed at
changes in knowledge, skills, understandings,
attitudes and values, and in the behaviour of
a learner or group of learners.
13.2 The size of the human resources of
the Department of Agriculture, Animal
Husbandry and Dairy put together, it will give
an mazing figure like 6117 number of field
assistants, 2481 field officers, 520 middle level
officers, 237 senior officers and 21 state level
officers. This huge resource has to be
genuinely designed to produce the output for
achieving the ever dreamt agricultural and
sustainable prosperity.
13.3 Human resource capacity building
encompasses aspects of awareness-raising,
education and training, attitude change,
confidence building, participation in decisionmaking and action. A critical goal of HRD is
that of maximizing people's potential to
contribute to development by participating
fully in all its activities. Through capacity
building, individuals and groups are
empowered to expand their abilities to more
fully participate in the development process.
As people increasingly direct and control the
process of change that they themselves are
bringing about, then the knowledge, skills,
attitudes and behaviors they require also
change. Based on these facts, the following
policies may be included.

42

13.4 Policy 44: Improved agricultural
productivity depends on agricultural education
and competency-based trainings and are
essential for building the human resource
capacity.
13.4.1 This is required to improve agricultural
productivity and to manage natural resources for
sustainable development. An urgent need is to
improve the quality and content of the agricultural
education provided to students. It was observed
by the sub-committee that often the subject
matter is minimally relevant to the agro-ecological
conditions, technological levels and socioeconomic circumstances of local farm
populations.
13.4.2 In order to attract the young
generation the curriculam is to be added
with agricultural subjects from the school
level. The curriculum should provide a
critical analysis of agricultural and food
systems and helps students understand
new concepts through hands-on
examples.
13.5 Policy 45: Develop the extension
personnel of the state to meet the
knowledge & skill requirements of
farmers as self-reliant agri-prenures.
13.5.1 To develop specially the small and
marginal farmers as agri-prenures and
making farming a profitable enterprise,
the state sponsored extension machinery
will have to take lead with completely
changed focus and attitude towards their
roles and responsibilities. A new agenda
of Human Resource Development for

<!-- page 70 -->

Agricultural Development Policy 2015

agricultural extension personnel in terms of
required competencies in technical,
organisational, managerial, communication
and business skills will be required to meet
these new challenges. The Human Resource
Development will not be confined to
competency building but providing congenial
working environment to extension
functionaries.
13.5.2 The extension personnel at all levels will
have to change their attitude and role from
manager of "files and subsidies" to manager
of "information generation and dissemination"
for different segments related with agricultural
extension.
13.6 Policy 46:
Empowering the
small farmers in order to have say in policy
matters of government in agriculture
sector would pave a way for better
development.
13.6.1 Farmers are to be empowered in the
following areas so that they may become a
part of the decision making process of the
Government which would ultimately reflect
in the production and productivity.
1. Technological skills related to production
2. Technological skills related to soil & water
management
3. Organisational and management skills in
working together as Farmer producer
Organisations (FPOs).
4. Business skills in analysis of cost and benefit
5. Marketing skills
6. Skill for value addition to agriculture
produce
7. Handling of Information Technology tools.
8. Credit management expertise.

13.7 Policy 47:
It will be required to
make necessary changes in the systems to
provide scientific and technical knowledge
and skills in agricultural operations to the
input dealers, so that they may advise
farmers in right direction & provide
valuable extension services to farmers
specially to small & marginal farmers.
13.7.1 Besides public sector extension
functionaries, there are a large number Non
government organizations, para extension
workers, traders and retailers of seed, fertilizer
and pesticide, providing technical advise to
their client farmers about the products as well
as its use.
13.7.2 The other players are Indian &
multinational companies in agri-business ,
which provide extension services to farmers
having business dealings like Buy-back
arrangement for farm produce. The agribusiness companies in organised sector take
care of Human Resource Development of
their extension personnel well. It will require
to make necessary changes in policy and
systems to provide scientific and technical
knowledge and skills in agricultural operations
to the input dealers, so that they may advise
farmers in right direction & provide valuable
extension services to farmers specially to small
& marginal farmers. They should act
according to the Government guidelines and
close supervision by the Department of
Agriculture.
13.7.3 All these initiatives are to be closely
monitored by the concerned departments to
assure 100% protection of the farmers’
interests and at any cost, the misuse of this
provision shall be allowed.

43

<!-- page 71 -->

Agricultural Development Policy 2015

13.8 Policy 48: Extension personnel of the
state will have to acquire latest knowledge
as well skills in use of various electronic
devices such as computers, multimedia,
internet etc.
13.8.1 In the era of information technology,
where information play a vital and decisive
role in taking strategic decision, extension
personnel will have to acquire latest
knowledge as well skills in use of various
electronic devices such as computers,
multimedia, internet etc. The day is not far
when tele/video conferencing will be common
means to interact with larger number of
farmers to extend extension messages or
sharing market information by extension
personnel. In coming years, the area of
Information Technology for developing
communication skills will be the largest
segment for competency building among
agricultural extension personnel for
supporting farming community.
13.9 Policy 49: The Human Resource
Development of the extension functionaries
is to be done scientifically and time bound.
13.9.1 Current recruitment process in the
department is immediate posting to a location
after issuing the appointment order both for
all officers and assistants in the respective
department. A class room training module should
be created both sets of professional staff and
mentoring system under senior officer for a period
of one month. Mandatory location specific on the
job modules also should be created as part of
technology up gradation of the staff.

44

13.9.2 The Agricultural Officers are those who
have secured a good position in the various
competitive examinations and the potential of them
should be tapped fully providing adequate inservice provisions for acquiring higher
qualifications such as MSc and PhD in
agricultural sciences so that a task force could
be formed with technologically sound persons
for improving agricultural productivity and to
manage natural resources for sustainable
development. An urgent need is there to
improve the quality and content of the
agricultural education provided to students.
Sometimes the subject matter is minimally
relevant to the agro-ecological conditions,
technological levels and socio-economic
circumstances of local farm populations.
13.9.3 This facility shall be extended to all
technical officers of the Department for
sharpening their expertise. At least 20 persons
per year have to go for higher studies in the
institutions inside Kerala, India and even out
side the country for assuring a technologically
sound manpower in the Government set up.
The vision behind this programme must be
to upgrade all the potential of the manpower
of the state to the fullest extent possible.

<!-- page 72 -->

Agricultural Development Policy 2015

14. POLICIES RELATED TO ICT APPLICATION
14.1 According to International Food
Policy Research Institute (IFPRI), the
generation and application of agricultural
knowledge is increasingly important,
especially for small and marginal farmers, who
need relevant information in order to improve,
sustain, and diversify their farm enterprises.
ICTs can directly support farmers‘ access to
timely and relevant information, as well as
empower the creation and sharing of
knowledge of the farming community itself.
The public, private, and non-governmental
organization (NGO) extension services will
be able to increase their effectiveness by using
these ICT tools.
14.2 The National Commission on Farmers
has noted that knowledge deficits constrain
agricultural productivity in India. It added that
the use of Information and Communication
Technologies (ICTs) for agricultural extension
is one way of addressing the information needs
of farmers.
14.3 As government is thinking and
formulating the policy for the betterment of
the agricultural community with special focus
on marginal and small farmers, ICT has to be
the key for that. It should be embedded in the
agricultural activities. With the advent of new
technologies, agricultural output has
increased, but it is not enough. Through ICT,
modernisation of the agricultura sector of
Kerala is the need of the hour.
14.4 The concept of ICT is still in nascent
stage, though Kerala has attempted some
pioneering
models
like,
KISSANKERALA.NET. More over, the state

has not tried different automation methods for
agricultural extension management. The
policies regarding ICTs are framed with these
backgrounds.
14.5 Policy 50: Immediate steps are to
be taken to materialise the concept of
‘Paperless Offices’ with the help of ICT in
the case of Krishi Bhavans to assure
services with 100% fastness and accuracy.
14.5.1 The Krishi Bhavans of Kerala were
originated with the model concept of
‘Paperless Offices’. But now the situation is
such that the system is tied with numerous
file works rather than the field works. If any
farmer wants an advice from the extension
officials, they have to come to the office and
discuss with them. The present approach is
to have an e- automated office, so that every
activity of the Krishi Bhavan is made online.
14.5.2 This will have advantages like cost
effectiveness, time saving, unified format for
the implementation of programmes
throughout the state, timely delivery of
services and above all the extension works of
the Department can be monitored very
efficiently from the top. The statistical data
can also be generated in a realtime basis.
14.5.3 An online software for the technology
management is to be developed without any
delay. Since, the current policy of the State
and Central Governments regarding subsidy
distribution is e-payments and the state had
already taken a lead role in this regard, an
online software with proper authentication
protocols at different levels are to be

45

<!-- page 73 -->

Agricultural Development Policy 2015

developed for saving the valuable time of the
extension officials and they can concentrate
on filed works effectively. A situation would
arise where the officials go to field instead of
farmer visiting the office for various assistance
and technology.
14.5.4 Hand held electronic gadgets such as
Tab Computers with connectivity are to be
provided to the Krishibhavans for updating
the data regarding the farmers and their crops
while visiting the field. A farmer can upload
the applications for various assistance online
with his unique registered identification
number and the extension officials with the
help of the Tab Computers the data regarding
the crop and farmers can be uploaded when
they visit the field. With the help of the GPS
locator, it is possible to identify the exact
location, while uploading the data and thus
accuracy of the system is assured. Moreover,
the authorities can have a state wide picture
of agriculture situation with the help of a
mouse-click.
14.5.5 The controlling officers can generate
the financial claims with the help of a mouse
click and that can be presented in the treasury
and money can be disbursed without any delay
by e-payment. The system gets transparent,
becomes smooth, efficient and time saving.
Automatically, with the help of electronic
administration, it would become field oriented
and unnecessary time delay in implementation
of different schemes of the Department can
be avoided.
14.6 Policy 51: The planning process
should be based on the real-time data
generated with the help of modern ICT
tools and State Agricultural Plan is to be
developed every year .

46

14.6.1 The modern technologies such as
cloud computing, GPS, android based
applications, mobile based technologies etc.,
assure accurate information over a short
period of time. As described in the Section 14
an online software for electronic
administration is mandatory. This can also help
in the data generation such as the following.
i. The current area under different
crops in the state.
ii. The present crop condition and
situation.
iii. The exact requirement of the State
with respect to produces.
iv. The accurate point at which the
Government is to intervene.
v. Requirement of financial resources
vi. Perfect market intelligence - What
to grow, Where to grow, How to grow,
When to grow, Where to sell, At what
price to sell etc.
14.6.2 The same online software developed
for electronic administration can also be used
for generation of State Agricultural Plan. The
data will be updated every time when the field
functionaries are in the field. Thus accurate,
real time and authentic data will be got for
the planning purpose and this will drive away
the un wanted pushing of programmes in the
non needy tracts and not getting the
programmes in the needy tracts of the state.
14.7 Policy 52:
When ICT enabled
technologies are made popular,
Concentrate on the demand, not on the
technology.
14.7.1 It is seen that a lot of touch screen
information KIOSKs are kept idle throughout
the state. Besides that a number of online
programmes are available in the internet where

<!-- page 74 -->

Agricultural Development Policy 2015

no farmers are seen directly operating it, though
it is claimed to have developed for the direct
use of even the illiterate farmers of the state.
A number of interactive CDs and programmes
were made utilising the taxpayers’ money but
no one is found to be used by the common
man. So any developed technology should be
based on the demand for the technology and
not on the merit of the information technology
at all.
14.7.2 The ICT enabled technology should
be such that it should empower the
extension official in bringing the targeted
technology to the targeted population rather
than addressing the targeted population
directly.
14.8 Policy 53: The Call Centers
are to be made efficient.
14.8.1 Many a time it was observed that
the Call centres are failing in providing
the right information. The Call Centre are
to be strengthened and reorganised with
the help of technical staff so that the
queries can be answered in the specific
moment and with accuracy.
14.8.2 Local people and their information
needs should be the driving force behind
ICT initiatives and not the technology.
Engage local people in the validation of
the various communication tools and let
them identify the most useful medium to
meet their needs.
14.9 Policy 54:
Farmer databases
are to be made perfect.
14.9.1 A novel approach initiated from the
part of the Government is the registration of

farmers for the building up of a database. But
due to many reasons the same could not be
materialised. In this context it is recommended
that an online registration which provides a
unique identity number for the registered
farmers and coupling with a permanent
identity proof so that a smart-card can be
issued to them in the due course. This database
must of the one used in many governmental
organisations like IRCTC, where frequent
updating and verification is possible and very
accurate database is got.
14.9.2 The database thus formed become the
part of the planning process, whereby the first
hand information on all aspects like the crop
profile, land use capability, extent of land that
can be put for additional production etc., can
be got.
14.9.3 Only the registered and validated
farmers will have eligibility for assistance
under different schemes of state, representing
them in different committees for development
and for voting for the selection of their
representatives. This will check the unwanted
entry of individuals in to the places reserved
only for real farmers.

14.10 Policy 55: Provide need-based ICT
training at all levels, but especially to
youth, women and marginal farmer
groups.
14.10.1 Farmer ICT basic training, site specific
Crop Management systems , GIS, GPS, eMarketing, crop models, ICT managed irrigation
and fertigation systems, greenhouse management
systems, process control pilots, distance learning,
etc are to be imparted to the client groups on a
need based format.

47

<!-- page 75 -->

Agricultural Development Policy 2015

14.11 Policy 56: Necessary mechanism
should be evolved for providing the market
information to the farmers on a realtime
basis with the help of ICTs
14.11.1 Marketing forms a key issue in any
agrarian development. So with the help of the
modern ICT tools the farmers are to be
provided with the latest market updated for
their products.
14.12 Policy 57: The modern ICT tools
are to be modelled in such a way that it
should provide information about rural
development programmes and subsidies to
farmers.
14.12.1 Many at times the farmers become
unaware of the developmental programmes
of the Government. In this context the reliable
tool can be the SMS services regarding the
launching of new programmes by the
department. The registered farmers would get
SMS relating to the programmes and they can
apply online as suggested in the Section
13.5.3.
14.13 Policy 58: ICT enabled weather
forecasting services, input prices and
availability, early warning of diseases and
pests and soil testing & soil sampling
information are to be provided by SMS
services.
14.13.1 When the databases of the farmers
are made perfect, it is possible to get a target
population capable or needed for receiving
these type of informations by Short Message
Services (SMS).

48

14.13.2 Farmers considers market information,
facilitation of access to land records, a questionand-answer service and detailed information on
the Government’s agricultural development
programmes most appropriate to their needs.
Information on the best packages of practices,
post-harvest technology, general agricultural
news and information on crop insurance schemes
were suggested by most of them as needy ones.
14.14 Policy 59: There should be initiatives
for the application of technologies such as
‘Tele Presence’ and ‘Google Glass’ for the
conferences , technology refinement and
transfer.
14.14.1 Telepresence refers to a set of
technologies which allow a person to feel as
if they were present, to give the appearance
of being present, or to have an effect, via
telerobotics, at a place other than their true
location. Telepresence requires that the users'
senses be provided with such stimuli as to give
the feeling of being in that other location.
Additionally, users may be given the ability to
affect the remote location. In this case, the
user's position, movements, actions, voice,
etc. may be sensed, transmitted and duplicated
in the remote location to bring about this
effect. Therefore information may be
travelling in both directions between the user and
the remote location. It would be useful in the
conferences and technology transfer. It is
expected to reduce the cost and time involved
for the travelling of officers to attend the
meeting.

<!-- page 76 -->

Agricultural Development Policy 2015

14.14.2 Google Glass is a wearable computer
with a head-mounted display (HMD) that is
being developed by Google in the Project Glass
research and development project with the
mission of producing a mass-market ubiquitous
computer. Google Glass displays information in
a smartphone-like hands-free format, that can
interact with the Internet via natural language
voice commands.
14.14.3 These ICT tools are of recent origin
and underway in the develeopment. But the
Government policy is to tap its potential as
and when it is come in to reality, without
making the situations compell to adopt them.

49

<!-- page 77 -->

Agricultural Development Policy 2015

15. POLICIES RELATED TO TECHNOLOGY
DISSEMINATION AND MANAGEMENT
15.1 Agricultural extension is a key
component of the strategies and objectives of
the Government’s agricultural policy. As part
of the Governmentís responsibility for the
establishment of policies,regulations and
projects that will ensure sustained agricultural
production, the need for developing a New
Agricultural Extension Policy was felt.
15.2 Policy 60: Extension Services are to
be made more efficient
15.2.1 The efficiency of agricultural
extension services will be improved through
training, skill development, institutional
strengthening and logistical support. Trained
extension agents will be provided to work
effectively with all categories of farmers, and
with all members of households, and to solve
basic production, management and marketing
problems in a wide range of crop, fishery,
livestock and household enterprises. The
focus of outreach activities is to provide the
most cost-effective services to farmers.
15.2.2 The extension agencies in the three
sectors (government, non-government
organisation and private) will continue to
work within their own organisational
structures and procedures, but the policy
seeks to ensure that effective co-ordination is
established to increase the efficiency of
agricultural extension. The new extension
reform in the country namely, ATMA can play
a vital role in this regard.
15.3 Policy 61: Demand led extension is the
need of the hour.

50

15.3.1 Extension programmes concentrate
on meeting the information needs of farm
households, in particular helping them solve
the key problems they face in their farming
activities. All extension activities and research
priorities are to be based on the needs,
problems and potential identified at farm level.
This may lead to the involvement of extension
agencies in local on-farm participatory
research in order to identify appropriate
solutions to farmers’ problems. Extension staff
will work closely with farmers to identify
agricultural problems, using participatory
methods and techniques such as Rapid Rural
Appraisal, Participatory Rural Appraisal and
Problem Censuses. Farmers’ problems will set
the extension agenda, and in this way,
extension services will be demand led, and
based on local situations and resources.
15.4 Policy 62: Group approach should
be the motto in all the extension activities
of the state.
15.4.1 For the extension services to provide
individual attention to the more than 7 million
farm families is beyond the resources available
in Kerala State. A group approach to extension
offers the opportunity for more effective use
of limited extension resources for problem
identification and solution, sharing of
information and cost-effective choice of
extension methodology.
15.4.2 A group approach to extension also
has the advantage of providing a forum for
participation, an area in which many nongovernment organisations have considerable
expertise.

<!-- page 78 -->

Agricultural Development Policy 2015

15.4.3 The New Agricultural Extension
Policy endorses the principle that extension
staff should work with groups of all kinds, in
order to bring maximum benefit to farmers.
It recognises that a very wide range of mutual
interest groups already exists in the field.
These groups range from extremely
temporary, such as a seasonal Kerasree group/
Cluster, to virtually permanent, such as the
Padasekhara Samithies, and may be affiliated
to a wide variety of agencies, including those
responsible for input supply, credit extension
and marketing. These existing groups would
be the focus of extension activity. New groups
will be encourage where there are none at
present or where key target farmer categories
are not included in the membership of existing
groups. Extension staff from different agencies
will work with groups to:
- bring extension staff into contact
with more farmers;
- help all categories of farmers (men,
women, large, small and marginal) to
benefit from extension;
- improve the learning and spread of
knowledge among the farming
population;
- enable farmers to fully participate in
the planning of extension programmes;
- provide a forum where decisions can
be taken for farmers to take coordinated action leading to selfreliance (for example, on pest
management, forest management,
livestock grazing and soil
conservation);
- promote a closer, participatory
working relationship between staff and
farmers.

15.5 Policy 63: The development of close
co-operation between extension agencies
and formal research institutes is essential
if farmers are to be provided with the
services they require.
15.5.1 Research
institutes
require
information from extension about the
problems farmers are facing, for which there
are no available solutions, in order to conduct
research programmes both on research
stations and on-farm with farmers. Extension
requires the findings from research
programmes, in order to provide farmers with
the most appropriate advice. Effective
mechanisms to ensure that there is a free flow
of information between extension and
research will be institutionalised.
15.5.2 The New Agricultural Extension
Policy also recognises that farmers themselves
are actively engaged in their own
experimentation, as part of their daily
agricultural lives. Efforts to learn from and
strengthen such informal research will be
made.
15.6 Policy 64: The existing system of
extension activities are to be put under one
single body so that the services to farmers
can be done efficiently.
15.6.1 To enhance the human capital,
Panchayath level extension strategy need to
be designed and devised. Under the chairman
ship of the Gramapanchayath President, a
Panchayath extension body should be
functional in Panchayath level in tune with the
ATMA Model. This should be under the

51

<!-- page 79 -->

Agricultural Development Policy 2015

leadership of agricultural officer and the
officers who support allied activities such as
veterinary, animal husbandry, fisheries,
sericulture and watershed management should
align their activities and extension strategies
in that model. This body should be structured
in such a way that any knowledge pertaining
to any field of agriculture can be transferred
to farmer. Formation of farmer clusters,
management of different commodity clusters,
training programmes, workshops, leadership
development of farmers to take up agricultural
related activities, etc should be the role of
these panchayath level bodies. The enhanced
role of Plan Coordinator of the Panchayath
and Convenor of the Panchayath level
watershed committee should enable the
Agricultural Officer to coordinate the
activities of the commodity groups formed
under ATMA Programme.
15.6.2 Current ATMA system of approach
can be more functional with extension focus.
The commodity based clusters can be
federated at block level and form producer
companies or cooperatives based on nature
of the commodities.
15.6.3 ATMA should act as the nodal
extension body which can play a greater role
in coordination of the activities of multi
disciplinary departments such as Agriculture,
Animal Husbandry, Diary, Fisheries, Soil
Conservation and Soil survey etc. The senior
most officers in the Department of Agriculture
Should head the ATMA project the entire
extension strategy should be implemented
through this body as envisaged in the national
level.

52

15.6.4 The current administrative set up of
ATMA will be made more functional for state
level coordination of integrated extension
approach.
15.7 Policy 65 : The new face extension
should provide integrated environmental
support.
15.7.1 The lives of more than 70 percent of
the population are almost totally dependent
upon the natural resource base which supports
agricultural production. However, it is
recognised that this critical resource base is
under threat. Among the concerns are
deforestation, water scarcity caused by
overabstraction, and an increased incidence
of pest damage due to introduction of
monoculture and inappropriate use of
pesticides. To maintain the ecological balance
in the natural environment, the Government’s
environmental objectives are to:
- control and prevent pollution and
degradation related to soil, water, and
air;
- promote environment-friendly activities;
- strengthen the capabilities of public and
private sectors to manage environmental
concerns
as a basic requisite for sustainable
development;
- create opportunities for people’s
participation in environmental
management activities.
15.7.2 The New Agricultural Extension Policy
therefore should support extension programmes
which seek to support and encourage farmers
and farmers groups to apply sustainable
agricultural practices. Through the sharing of

<!-- page 80 -->

Agricultural Development Policy 2015

information among all the agencies in the
agricultural extension system, it is expected that
the capacity of agencies to promote sustainable
agricultural development will be enhanced. It is
recognised that farmers own Indigenous
Technical Knowledge is often environmentally
sustainable, and efforts should be made to
support and learn from farmers, as well as the
formal research system. The policy recognises
that, inevitably, with increasing demand for higher
agricultural output due to a rapidly increasing
population, there may be a negative effect upon
the natural environment. However, the policy will
support extension efforts aimed at balancing the
demands for increasing production and
environmental preservation. This effort will be
integrated extension support for the whole
farming system.

15.8.2 There are five training centers under the
Department of Animal Husbandry by which the
routine mandate of trainings are undertaken. But
for a professional approach in participatory
process of planning, implementation and
monitoring of development, based on people’s
knowledge, access and control over resources
etc., an apex Institute which would be a centre
of excellence is a must. Hence the Government
should take immediate steps to materialise a
centre of excellence in veterinary trainings and
the present training institutes/ centres are to be
developed as its satellite units.

15.8 Policy 66: Improved productivity of
livestock and improved quality of the
livestock keepers are possible only if
policies focus directly on people and policy
instruments are directed towards building
their capacities for vibrant, competitive,
informed and responsible participation in
very aspect of the livestock sector.
15.8.1 Animal husbandry-extension is very
poor in the State and, if at all, is limited to giving
advice to farmers in a fashion not conducive for
secular livestock growth. The approach towards
livestock development will have to change from
delivery of pre- packaged services to
participatory process of planning, implementation
and monitoring of development, based on
people’s knowledge, access and control over
resources, their development aspirations and their
perceptions regarding what risks they are willing
and able to take as livestock entrepreneurs.

53
