---
doc_id: "e1aad33e8b1a8cc9"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0be51b499c06e053"
---

<!-- page 1 -->

GOVERNMENT OF KERALA Agriculture Department
O/o,Assistant Executive Engineer,
Office of the Assistant Executive Engineer Thiruvananthapuram
No :AGRI/DOA/207/2025-2026

Dated :16-01-2026

NOTICE INVITING TENDER
e-Government Procurement (e-GP)
TENDER NO. :AGRI/DOA/TR/169/2025_5_1_1/1
The Assistant Executive Engineer Agriculture Department, (AGRI)O/o Office of the Assistant
Executive Engineer ,Office of the Assistant Executive Engineer Thiruvananthapuramfor and
on behalf of the Governor of Kerala invitesonline bids for the work detailed below from the
Registered Bidders of Kerala PWD or from any State or Central Government Engineering
Departments which are having similar functionalities like Kerala PWD.
1

Name of Work

2

Location of Work

3

Estimated Cost of Work

Printed On 2026-01-16 17:00:23.874

GENERAL-Jilla Panchayath 2025-26 SSF
Ulloor-Renovation of compound wall and gate General Civil Work
Thiruvananthapuram
Rs.253848/1

<!-- page 2 -->

Name of work: Jilla Panchayath 2025-26 SSF
Ulloor-Renovation of compound wall and gate
General:
Estimate is prepared as per Administrative
sanction No: 6(1) dated 17/03/2025 of Rs. Three
lakhs of Secretary Thiruvananthapuram Jilla
Panchayath. Technical:
The estimate includes
1.
Raising the height of the existing
compoundwall for protection of boundary 2.
Repair and renovation of existing gates
3.
Construction of gate arch (steel work)
forornamental plants.
4.
constrtuction of
steps to provide
directaccess from office to field .
Financial :
The total cost of estimate comes to Rupees three
lakhs only. The estimate is prepared as per DSOR
2021 and a cost index of 47.66 % of Trivandrum
plain terrrain.

4

Brief Description of Work

5

Bid Security

Rs.6346/-

6

Bid Submission fee (Tender fee)

560+(0)GST

7

Period Of Completion

0 Days 0 Months 1 Years

8

Classification of Bidder

CIVIL-D

9

Last date and time for submission of
bids

24-01-2026 at 18:00

10

Date and time of opening of tender

27-01-2026 at 11:00

Bid documents including the Bill of Quantities (BoQ) can be downloaded free of cost from the
eGovernment Procurement (e-GP) Website www.etenders.kerala.gov.in. All bid documents are to be
submitted online only and in the designated cover(s)/ envelope(s) on the e-GP website. Tenders/ bids
shall be accepted only through online mode on the e-GP website and no manual submission of the
same shall be entertained. Late tenders will not be accepted. A bid submission fee shall be remitted
online during the time of bid submission.
Price Bid shall only be submitted through online.Details regarding remittance of Bid Submission Fee
and Bid Security, Bid preparation and submission are mentioned in the bid document.

The bids shall be opened online on 21-01-2026 at 11:00 at the office of the O/o Office of the Assistant
Executive Engineer,Office of the Assistant Executive Engineer Thiruvananthapuram in the presence
of the Bidders /their authorized representatives who wish to attend at the above address.If the tender
opening date happens to be on a holiday or non-working day due to any other valid reason, the tender
opening process will be done on the next working day at same time and place.
More details can be had from the Office of the Assistant Executive Engineer, Agriculture
Department(Agriculture Department) O/o Office of the Assistant Executive Engineer,Office of the
Assistant Executive Engineer Thiruvananthapuram during working hours.

<!-- page 3 -->

All other existing conditions related to bidding in force in the Kerala Public Works Department will
be applicable in this tender also unless expressly defined in the bidding document. The Tender
Inviting Authority/Employer shall not be responsible for any failure, malfunction or breakdown of
Printed On 2026-01-16 17:00:23.874

2

the electronic system while downloading or uploading the documents by the Bidder during the
eprocurement process.Details required for e-payment (Details of bank account having core banking
facility and email addressof the bidder) shall be furnished along with the tender.Tenders not
accompanied by these details will be rejected. All subsequent Government orders connected to tenders
and any revision in the rates of taxes would also be applicable to this tender.

The Assistant Executive Engineer, Agriculture Department (AGRI), O/o Office of the Assistant
Executive Engineer , Office of the Assistant Executive Engineer Thiruvananthapuram reserves the
right to accept or reject any or all tenders without assigning any reason thereof.

Assistant Executive Engineer
Agriculture Department(AGRI)
O/o Office of the Assistant Executive Engineer,
Office of the Assistant Executive Engineer Thiruvananthapuram
(For and on behalf of Governor of Kerala)

<!-- page 4 -->

Printed On 2026-01-16 17:00:23.874

3

Signature Not Verified
Digitally signed by SABU M S
Date: 2026.01.19 06:56:08 IST
Location: Kerala-KL
