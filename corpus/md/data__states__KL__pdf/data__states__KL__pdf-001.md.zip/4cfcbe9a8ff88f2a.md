---
doc_id: "4cfcbe9a8ff88f2a"
source_url: "https://dairydevelopment.kerala.gov.in/images/pdf/circulars/spark.pdf"
ministry: "Dairy Development Department, Kerala"
title: "Click Here.."
date: ""
pages: 4
method: "pdftotext"
script: "MALAYALAM"
needs_ocr: false
sha1: "012ffe04d6e168c4"
---

<!-- page 1 -->

File No.DDDKER/162/2022-A1

നം.

ക്ഷീരവികസന വകുപ്പ് ഡയറക്ടറററ്റ്
പട്ടം, തിരുവനന്തപുരം -695004
റഫോൺ :0471-2445749, 2445799
e-mail: dir.dairy@kerala.gov.in
cru.ddd@kerala.gov.in
തീയതി:-18/02/2022

ഡയറക്ടർ
ഡഡപ്യൂട്ടി ഡയറക്ടർർോർ
ജില്ലോ കോര്യാോയയ്ങ, ഡയറി ഡട്രെയിനിംഗ് ഡസെർ, റസ്റ്റേറ്റ് റഫോഡർ ഫോം
സർ,
വിഷയം:-

ക്ഷീരവികസന വകുപ്പ്- ഡയറക്ടറററ്റ്-അക്കൗണ്ട് ഡസക്ഷൻ - G
സ്പോർക്ക് - വകുപ്പിഡയ ജനറ് ട്രെോൻസ്ഫർ ഓൺലൈൻയൻ
പ്ലോറ്റ്റഫോർി് ന്പിപ്പിയോുനത് - സംബന്ധിച്

സൂചന :

1) ക്ഷീരവികസന വകുപ്പ് ഡയറക്ടറഡ്പി 07/01/2022-ഡയ നമ്പർ
DDDKER/4306/2021- ES1 ഉത്തരവ്
2)സ്പോർക്ക് ഓഫീസി് നിനുള് ഇ-ഡർയി് സറന്ദേശം

റർ് സൂചന (1) പ്രകോരം ക്ഷീരവികസന വകുപ്പിൻ കീലിള് ജീവനക്കോരുഡ്പി
ഡപോതുസ്ഥയംർോറ്റവും
ഓൺലൈൻയൻ
സംവിസ്ഥോനത്തിിലഡ്പി ർോ്നതിി്
ന്പിപ്പിികങക്കോയി
നിർറദശം
ന്കി
ഉത്തരവോയിരുനുള.
വകുപ്പിഡയ
ഡപോതുസ്ഥയംർോറ്റവും നിയർനവും ഓൺലൈൻയൻ സംവിസ്ഥോനം വലി ന്പി്നതിി
മുറനോ്പിിയോയി ഈു വകുപ്പിൻ കീലിള് എലല്ലോ ശോാാുളോ കോര്യാോയയ്ിിളം
ജീവനക്കോരുഡ്പി വ്യായിപരർോയ വിവര്ങ,അവസ്ഥി,അച്പിക്ക ന്പിപ്പിികങ ർ് റസവന
വിവര്ങ സ്പോർക്ക് റസോ്്ഡവയറി് അപ്റഡറ്റ് ഡച്് റയോക്കോക്കി സൂക്ഷിുനത്
സംബന്ധിച് സൂചന (2) പ്രകോരം spark ് നിന് കത്ത് യഭിചിടണ്ട് . ്പിി അിബന്ധ
വിവര്ങ അതോതു ഓഫീസകിിഡയ സ്പോർക്ക് സംവിസ്ഥോനത്തി് റവണ്ട
റരാാുളഡപ്പടുത്തളകങ ന്പി്നതിറയക്കോയി ഇറതോഡ്പിോപ്പം ഉ്്പിക്കം ഡചയനുള. പ്രസ്തുത
വിവര്ങ അപ്റഡറ്റ്
ഡച് വിവരം ഈു ഓഫീസി് അ്പിിയന്തിരർോയി
അറിയിറക്കണ്ടതോണ് .
വിശ്വസ്തതറയോഡ്പി,
Signature Not Verified
Digitally signed by V P
SURESHKUMAR
Date: 2022.02.18 13:23:23 IST
Reason: Approved

ഡയറക്ടർ
പകർപ്പ്ഃ-

1) ഇ 1, ഇ 2, ഇ 3 സീ്കങ ,ഡയറക്ടറററ്റ്
2)ഡയറക്ടറഡ്പി സി.എല, അഡ്മിനിറസ്ട്രേറ്റീവ് ഓഫീസറഡ്പി സി.എല

<!-- page 2 -->

File No.DDDKER/162/2022-A1

3) ഡവബ്ലൈൻസറ്റ്.

<!-- page 3 -->

1

102630t2022tFC DDO

,[r
Ple-rertuisites for on-boarding tlep:r rtment

l. The data in SPARK rv.r.to the employees profile and dreir service particulars
to be updated. verit'red and locked belbre it can be put to use lbr general

transfer. The applications cannol be tbnvarded fi'om the offrce. if the data is
not verifled and locked.

2. All leaves including LWAs. deputations, disciplinary actions. employees on
Postgraduate srudy(sen'ice quota) etc. to be updated.

3. The inter-transferable desigration of the departnent may be grouped as a
cadrelpost(Eg. There may be desigrations ' driver grade- I' and 'driver -smdeII'. but they are transferable and hence the cadre /post name is 'Driver'.)

4. The cadre name to be nrapped for each designation

.

5. Cadres that belong to district level recruitment (DRB) to be enlisted and
updated.

6. The sanctioned strengh of all posts may be updated in SPARK for each
establishment.

7. The.hard areas/ ditficult areas to be enlisted and updated in SPARK.
8. Oilices that thll within 1,5 Kms to be updated tbr each oft-rce.

9. State level oftice and district /zone level offices fol the purpose of handling
transt'er applicatiorx to be inlbmred to SPARK PN{U for rnaking in database.

l0 A nodal offrcer rnay be noninated from your departlrent to interact rvith
NICISPARK PML: and provide authenticated details as and rvhen required.
I 1. A state level Officer to be identified by Head Ofiice rvhose rvill be responsible

for processing of transfei and generating reports. The PEN of the offrcer to be
marked in SPARK through PMU.

12 The 'as on date' for transtbr eligibility . start date and end date for submitting
online applications. sane tbr fonvarding from the offrce. sarne for fonvarding
from district lerel office and same for accepting at state level office need to be
specified for updating in SPARK.

<!-- page 4 -->

t
102630t2022tFC OOD

1-1. C'adres that belong

to district level recruitment (DRB) to be enlisted and

updated.
14. The sanctioned strength of all posts may be updated in SPARK tbr each

establislunent.
15. The hard areas dilticult areas to be enlisted and updated in SPARK.
16. Offices that fall $'ithir l5 Kms to be updated fot'each ottjce.
17. State level ofice and district zone level oftices for the purpose of handling
transt'er applications to be infonrred to SPARK PMU tbr making in database.

l& A nodal officer may be nominated frorr your depar"tment to interact rvith
MC'SPARK PNILI and provide autheoticated detatls as and *'hen required.
19. A state level Officer to be identilied by Head Oftice lr hose rvill be responsible

for processing of trarnfer and generating reporls. The PEN of fte otlicer to be
narted in SPARK throueh PML-.
20. The 'as on date' for transter eligibility . slarl date and end date t'or submitting

online applications. sane tbl tbrwarding from the oftice. same for lbru.arding
frour district level office and same for accepting at state level office need to be
specified for updating in SPARK.
