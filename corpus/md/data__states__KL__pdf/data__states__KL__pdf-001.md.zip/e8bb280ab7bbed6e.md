---
doc_id: "e8bb280ab7bbed6e"
source_url: "https://keralaagriculture.gov.in/wp-content/uploads/2026/06/Tender-Maneed.pdf"
ministry: "Agriculture Development and Farmers Welfare Department, Keral"
title: "Click Here"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c3944110f471a9ee"
---

<!-- page 1 -->

GOVERNMENT OF KERALA
Agriculture Department
O/o,State Agricultural Engineer,
Directorate of Agriculture
No :AGRI/DOA/18/2026-2027

Dated :08-06-2026

NOTICE INVITING TENDER
e-Government Procurement (e-GP)
TENDER NO. :AGRI/DOA/TR/342/2024_5_1_1/1
The State Agricultural Engineer Agriculture Department, (AGRI)O/o Office of the State
Agricultural Engineer ,Directorate of Agriculturefor and on behalf of the Governor of
Kerala invitesonline bids for the work detailed below from the Registered Bidders of
Kerala PWD or from any State or Central Government Engineering Departments which
are having similar functionalities like Kerala PWD.
1

Name of Work

2
3

Location of Work
Estimated Cost of Work

Printed On 2026-06-08 12:29:35.183

NABARD-RIDF - Infrastructural Development
Works - Maneed Puncha Part II-Maneed
puncha Part II Recasted Estimate-General Civil
Work
Ernakulam
Rs.23712214/-

1

<!-- page 2 -->

4

Brief Description of Work

5
6
7
8
9

Bid Security
Bid Submission fee (Tender fee)
Period Of Completion
Classification of Bidder
Last date and time for submission of
bids
Date and time of opening of tender

10

The proposed work aims to improve the drainage
network and protect agricultural lands in Maneed
Puncha Part II through the deepening of existing
thodes and construction of RCC retaining walls
at vulnerable reaches. The work covers the
stretches from Kunnankulam to T-Junction (340
m), T-Junction to Tractor Way Bridge (40 m),
Tractor Way Bridge to Roadside (80 m), Bridge
near Toddy Shop to Kunnamkulam Canal (300
m), and Puthan Nada DR to VCB (170 m), with
single-side or double-side retaining walls
adopted based on site conditions and hydraulic
requirements.
The work includes earth excavation and channel
deepening (4,004.40 m³), site clearance,
temporary ring bund construction, and
dewatering arrangements for execution under
waterlogged conditions. Considering the weak
soil strata, coconut pile foundations totaling
3,620 m have been provided to ensure structural
stability. The estimate also includes quarry muck
filling, PCC bedding concrete, centering and
shuttering works, and PVC weep holes for
pressure relief.
The main structural component consists of M25
grade RCC retaining walls with toe, heel, and
shear key arrangements, requiring 784.525 m³ of
RCC and 48.395 MT of Fe-500D TMT steel.
Fifteen RCC walkway slabs have also been
provided to maintain accessibility across the
drainage channels.
The proposed design ensures improved hydraulic
efficiency, enhanced structural stability, and
long-term durability, thereby mitigating
waterlogging, protecting agricultural lands, and
providing a sustainable drainage solution for
Maneed Puncha Part II.
Rs.100000/8270+(1489)GST
0 Days 6 Months 0 Years
CIVIL-B
29-06-2026 at 13:00
30-06-2026 at 15:00

Bid documents including the Bill of Quantities (BoQ) can be downloaded free of cost from the eGovernment Procurement (e-GP) Website www.etenders.kerala.gov.in. All bid documents are to be
submitted online only and in the designated cover(s)/ envelope(s) on the e-GP website. Tenders/
bids shall be accepted only through online mode on the e-GP website and no manual submission of
the same shall be entertained. Late tenders will not be accepted. A bid submission fee shall be
remitted online during the time of bid submission.
Price Bid shall only be submitted through online.Details regarding remittance of Bid Submission
Fee and Bid Security, Bid preparation and submission are mentioned in the bid document.

The bids shall be opened online on 30-06-2026 at 15:00 at the office of the O/o Office of the State
Agricultural Engineer,Directorate of Agriculture in the presence of the Bidders /their authorized
representatives who wish to attend at the above address.If the tender opening date happens to be on
a holiday or non-working day due to any other valid reason, the tender opening process will be done

Printed On 2026-06-08 12:29:35.183

2

<!-- page 3 -->

on the next working day at same time and place.
More details can be had from the Office of the State Agricultural Engineer, Agriculture
Department(Agriculture Department) O/o Office of the State Agricultural Engineer,Directorate of
Agriculture during working hours.
All other existing conditions related to bidding in force in the Kerala Public Works Department will
be applicable in this tender also unless expressly defined in the bidding document. The Tender
Inviting Authority/Employer shall not be responsible for any failure, malfunction or breakdown of
the electronic system while downloading or uploading the documents by the Bidder during the eprocurement process.Details required for e-payment (Details of bank account having core banking
facility and email addressof the bidder) shall be furnished along with the tender.Tenders not
accompanied by these details will be rejected. All subsequent Government orders connected to
tenders and any revision in the rates of taxes would also be applicable to this tender.
Bonus will be paid to the bidder at the rate of 1% of the estimated PAC, subjected to a maximum of
Rs.5 lakhs (Five lakhs) in case of works which exceed TS power of Superintending Engineer and
also if and only if the work is completed within 85% of the original time of completion(TOC)
specified in the TS estimate which is calculated as per the guidelines issued by the Chief Engineer
of each wing.
The State Agricultural Engineer, Agriculture Department (AGRI), O/o Office of the State
Agricultural Engineer , Directorate of Agriculture reserves the right to accept or reject any or all
tenders without assigning any reason thereof.

State Agricultural Engineer
Agriculture Department(AGRI)
O/o Office of the State Agricultural Engineer,
Directorate of Agriculture
(For and on behalf of Governor of Kerala)

Printed On 2026-06-08 12:29:35.183

3

<!-- page 4 -->

1826018/2026/TG AGRIDIR

08/06/2026, 16:45

eTendering System Government of Kerala

eTendering System Government of Kerala
Tender Details
Date : 08-Jun-2026 04:45 PM
Print

Basic Details
Organisation Chain

Department of Agriculture||Directorate of Agriculture

Tender Reference
Number

ADFW/3121/2024-TGII(2)

Tender ID

2026_AGRI_854872_1

Withdrawal Allowed

Yes

Tender Type

Open Tender

Form of contract

Item Rate

Tender Category

Works

No. of Covers

2

General Technical
Evaluation Allowed

No

ItemWise Technical Evaluation
Allowed

No

Payment Mode

Online

Is Multi Currency Allowed For
BOQ

No

Is Multi Currency
Allowed For Fee

No

Allow Two Stage Bidding

No

Payment Instruments

Cover Details, No. Of Covers - 2

Online
Bankers

Cover No Cover

S.No
1

Bank Name
SBI MOPS

1

Fee/PreQual/Technical .pdf

2

Tender Fee Details, [Total Fee in ₹ * - 11,293]
Tender Fee in ₹

9,759

Processing Fee in ₹
(18.00% GST Incl.)

1,534

Fee Payable To

Nil

Tender Fee
Exemption Allowed

Yes

Fee Payable At

Document Type

Finance

Description
Forms of
Tender

.pdf

Preliminary
Agreement

.pdf

Integrity Pact

.pdf

Affidavit

.pdf

EPay

.pdf

Bid Remittance
details

.pdf

PWD
Registration
certificate and
GST Certificate

.pdf

nit

.xls

BoQ

EMD Fee Details

Nil

EMD Amount in ₹

1,00,000

EMD Exemption
Allowed

Yes

EMD Fee Type

fixed

EMD Percentage

NA

EMD Payable To

Nil

EMD Payable At

Nil

Click to view modification history

Work /Item(s)
Title

NABARD-RIDF - Infrastructural Development Works - Maneed Puncha Part II-Maneed puncha Part II Recasted
Estimate-General Civil Work

Work Description

NABARD-RIDF - Infrastructural Development Works - Maneed Puncha Part II-Maneed puncha Part II Recasted
Estimate-General Civil Work

Pre Qualification Details Please refer Tender documents.
Independent External
Monitor/Remarks

NA

Show Tender Value in
Public Domain

Yes

1

File No. ADFW/3121/2024-TG-II(2) (Computer No. 247601)

https://etenders.kerala.gov.in/nicgep/app?component=view1&page=ViewTenders&service=direct&session=T&sp=S3ST%2ByH0ky9eeF45S4Y5h5MfJ…

Generated from eOffice by Gouri Ganesh, AE-TG-AGRIDIR., AE-TG AGRIDIR, Agriculture Development and Farmers Welfare Directorate on 09/06/2026 12:33 PM

1/3

<!-- page 5 -->

1826018/2026/TG AGRIDIR

08/06/2026, 16:45

eTendering System Government of Kerala

Tender Value in ₹

2,37,12,214

Product Category

Civil Works - Sub category
Others

NA

Contract Type

Tender

Bid Validity(Days)

120

Period Of Work(Days)

180

Location

Maneed,
Ernakulam

Pincode

686664

Pre Bid Meeting Place

NA

Pre Bid Meeting Address NA

Pre Bid Meeting Date

NA

Bid Opening Place

O/o SAE, Directorate of
Agriculture,TVPM

Should Allow NDA
Tender

Allow Preferential
Bidder

No

Publish Date

08-Jun-2026 06:00 PM

Bid Opening Date

Document Download / Sale Start
Date

08-Jun-2026 06:00 PM

Document Download / Sale End Date 29-Jun-2026 01:00 PM

Clarification Start Date

08-Jun-2026 06:00 PM

Clarification End Date

29-Jun-2026 01:00 PM

Bid Submission Start Date

08-Jun-2026 06:00 PM

Bid Submission End Date

29-Jun-2026 01:00 PM

No

Critical Dates
30-Jun-2026 03:00 PM

Tender Documents
NIT
Document

Work Item
Documents

S.No Document Name

Description

1

NIT

Tendernotice_1.pdf

Document Size
(in KB)
49.11

S.No Document Type

Document Name

Description

1
2
3
4
5
6
7

BOQ_1444795.xls
PreliminaryAgreement.pdf
IntegrityPact.pdf
EPAYFORM.pdf
AFFIDEVIT.pdf
SBD.pdf
form.pdf

boq
Preliminary agreement
INTEGRITY PACT
EPAY
AFFIDEVIT
sbd
form of tender

BOQ
Other Document
Other Document
Tender Documents
Other Document
Tender Documents
Tender Documents

Document Size
(in KB)
315.50
81.72
51.34
63.49
273.85
4532.99
30.14

Bid Openers List
S.No
1.
2.
3.
4.

Bid Opener Login Id
aeeagriwayanad@gmail.com
rjayan71@yahoo.com
shinysamuel71@gmail.com
prabhadevpps@gmail.com

Bid Opener Name
Sumesh Kumar T
Jayarajan R
Shiny Lukose
Prabha Devi P S

Certificate Name
Sumesh Kumar T
JAYARAJAN R
Shiny Lukose
PRABHA DEVI P S

Tender Properties
Auto Tendering Process
allowed

No

No

Normal

Stage to disclose Bid Details in Public Technical Bid Opening
Domain
BoQ Compartive chart decimal places 2

L

Form Based BoQ

Show Finance bid status No
BoQ Comparative Chart
model
BoQ Comparative Chart
Rank Type

Show Technical bid status

No

Tender Inviting Authority
Name

State Agricultural Engineer

Address

O/o,State Agricultural Engineer, Directorate of Agriculture, Vikas Bhavan,Thiruvananthapuram

Tender Creator Details
Created By

Prabha Devi P S

Designation

Assistant Executive Enginner Agri

Created Date

08-Jun-2026 03:36 PM

2

File No. ADFW/3121/2024-TG-II(2) (Computer No. 247601)

https://etenders.kerala.gov.in/nicgep/app?component=view1&page=ViewTenders&service=direct&session=T&sp=S3ST%2ByH0ky9eeF45S4Y5h5MfJ…

Generated from eOffice by Gouri Ganesh, AE-TG-AGRIDIR., AE-TG AGRIDIR, Agriculture Development and Farmers Welfare Directorate on 09/06/2026 12:33 PM

2/3

<!-- page 6 -->

1826018/2026/TG AGRIDIR

08/06/2026, 16:45

eTendering System Government of Kerala

3
File No. ADFW/3121/2024-TG-II(2) (Computer No. 247601)

https://etenders.kerala.gov.in/nicgep/app?component=view1&page=ViewTenders&service=direct&session=T&sp=S3ST%2ByH0ky9eeF45S4Y5h5MfJ…

Generated from eOffice by Gouri Ganesh, AE-TG-AGRIDIR., AE-TG AGRIDIR, Agriculture Development and Farmers Welfare Directorate on 09/06/2026 12:33 PM

3/3
