---
doc_id: "bcc9df85e731dce2"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fbcad6b7832542d4"
---

<!-- page 1 -->

IN THE HIGH COURT OF KERALA AT ERNAKULAM
PRESENT
THE HONOURABLE MR. JUSTICE SATHISH NINAN
TUESDAY, THE 11TH DAY OF JANUARY 2022 / 21ST POUSHA, 1943
WP(C) NO. 65 OF 2022
PETITIONERS:

1

SANTHOSH T T
AGED 47 YEARS
THENNAPPALIYIL HOUSE, ENADI P.O, BRAHMAMANGALAM, KOTTAYAM,
FORMER PRESIDENT, BRAHMAMANGALAM, KSHEEROLPADAKA SAHAKARANA
SANGAM, LTD NO. K 530, APCOS, BRAHMANGALAM, KOTTAYAM 686 605

2

SUGUTHAN T.C
THADATHIMALAYIL HOUSE, BRAHMAMANGALAM, KOTTAYAM, FORMER
MANAIGING COMMITEE MEMBER, BRAHMAMANGALAM, KSHEEROLPADAKA
SAHAKARANA SANGAM, LTD NO. K 530, APCOS, BRAHMANGALAM,
KOTTAYAM 686 605

3

PRIYA SAJU
ARUKATTIL HOUSE, ANADI P.O, BRAHMAMANGALAM, KOTTAYAM, FORMER
MANAGING COMMITTEE MEMBER, BRAHMAMANGALAM, KSHEEROLPADAKA
SAHAKARANA SANGAM, LTD NO. K 530, APCOS, BRAHMANGALAM,
KOTTAYAM 686 605

4

MINI ASOKAN
ASWATHI BHAVAN, BRAHMAMANGALAM, KOTTAYAM, FORMER MANAGING
COMMITTEE MEMBER, BRAHMAMANGALAM, KSHEEROLPADAKA SAHAKARANA
SANGAM, LTD NO. K 530, APCOS, BRAHMANGALAM, KOTTAYAM 686 605

5

SARASWATHI AMMA
SARASWATHI BHAVAN, ENADI P.O, BRAHMAMANGALAM, KOTTAYAM,
FORMER MANAGING COMMITTEE MEMBER, BRAHMAMANGALAM,
KSHEEROLPADAKA SAHAKARANA SANGAM, LTD NO. K 530, APCOS,
BRAHMANGALAM, KOTTAYAM 686 605
BY ADVS.
P.N.MOHANAN
AMRUTHA SURESH
C.P.SABARI
GILROY ROZARIO

<!-- page 2 -->

-2-

WP(C) NO. 65 OF 2022

RESPONDENTS:
1

DEPUTY DIRECTOR
OFFICE OF THE DEPUTY DIRECTOR, DAIRY DEVELOPMENT DEPARTMENT,
KMC-13/1060, ERAYILKADAVU, KOTTAYAM 686 001

2

B.SAJAN
RESIDING AT MOOZHIYIL, BRAHMAMANGALAM, KOTTAYAM
ADMINISTRATIVE COMMITTEE CONVENER, BRAHMAMANGALAM,
KSHEEROLPADAKA SAHAKARANA SANGAM, LTD NO. K 530, APCOS,
BRAHMANGALAM, KOTTAYAM 686 605

3

P.P RAJASEKHARAN
RESIDING AT PADMAVILASAM, ENADI, KOTTAYAM, ADMINISTRATIVE
COMMITTEE MEMBER, BRAHMAMANGALAM, KSHEEROLPADAKA SAHAKARANA
SANGAM, LTD NO. K 530, APCOS, BRAHMANGALAM, KOTTAYAM 686 605

4

ANURAG V.P
RESIDING AT VADAKKEKALAYIL, BRAHMAMANGALAM, KOTTAYAM,
ADMINISTRATIVE COMMITTEE MEMBER, BRAHMAMANGALAM,
KSHEEROLPADAKA SAHAKARANA SANGAM, LTD NO. K 530, APCOS,
BRAHMANGALAM, KOTTAYAM 686 605

5

BRAHMAMANGALAM KSHEEROLPADAKA SAHAKARANA SANGAM LTD NO K 53D,
APCOS,
REPRESENTED BY ITS SECRETARY, BRAHMAMANGALAM, KOTTAYAM 686
605
BY SRI.BIMAL K. NATH, SR. GOVT. PLEADER

THIS

WRIT

PETITION

(CIVIL)

HAVING

COME

UP

FOR

ADMISSION

11.01.2022, THE COURT ON THE SAME DAY DELIVERED THE FOLLOWING:

ON

<!-- page 3 -->

SATHISH NINAN, J.
= = = = = = = = = = = = = = = = = =
W.P.(C) No.65 of 2022
= = = = = = = = = = = = = = = = = =
Dated this the 11th day of January, 2022
J U D G M E N T
Ext.P4 order of the first respondent, under Section
33 of the Kerala Co-operative Societies Act (hereinafter
referred to as “the Act”), holding lack of quorum for
the Managing Committee of the 5 th respondent Society,
and appointing an administrative committee, is under
challenge in this writ petition by five members of the
Managing Committee.
2. Heard Sri.P.N.Mohanan, learned counsel for the
petitioner

and

Sri.Bimal

K.

Nath,

learned

Senior

Government Pleader. In spite of service of notice on
respondents 2 to 5, there is no appearance.
3.

According

to

the

petitioners,

the

managing

committee hold sufficient quorum. The total strength of
the Managing Committee of the 5 th respondent Society is
9 (nine). The Managing Committee came into office on
04.10.2017. Thereafter, the following events transpired

<!-- page 4 -->

W.P.(C) No.65 of 2022

-: 2 :-

in relation to the strength of the Committee:-

Sl.
No.

Date

Event

a

24.11.2020

One member - Smt.Smitha Suresh disqualified.

b

17.06.2021

One member - Smt.Saraswathi Amma
- nominated to Committee

c

26.08.2021

Two members - Mr.Haridas
Mr.Deepesh - disqualified.

d

19.12.2021

Two members - respondents 2 and
3 - resigned.

4.

On

the

disqualification

of

two

and

members

on

26.08.2021 [Sl. no. (c) above], and the resignation of
respondents 2 and 3 on 19.12.2021 [Sl. no. (d) above],
the strength of the Managing Committee came down to
five. In terms of Section 28(5) of the Act, the quorum
for

the

Committee

is

just

above

50%

of

the

total

strength. It being so, five out of nine constitutes
sufficient quorum of the Committee;

hence Ext.P4 order

finding lack of quorum and appointing administrative
committee is bad in law, is the contention.

<!-- page 5 -->

W.P.(C) No.65 of 2022

-: 3 :-

5.

According

nomination

of

to

the

first

Smt.Saraswathi

Amma

respondent,
[Sl.No.(b)

in

the
the

tabular column above], alleged to have been made on
17.06.2021, is bad, and hence the Managing Committee
presently consists of only 4 members. The same being
less than 50%, lacks the quorum mandated under Section
28(5) of the Act, is the contention.
6. The reason why the first respondent contends
that the nomination made on 17.06.2021 is bad is that,
the Managing Committee in its meeting held on 27.03.2021
had relegated the issue regarding nomination of member
to the vacancy that arose on 24.11.2020, to the General
Body scheduled on 30.03.2021. Though the General Body
nominated

Smt.Saraswathi

Amma

towards

the

vacancy,

nomination of Committee member was not in the agenda of
the General Body meeting. Nomination not being one of
the items in agenda could not have been transacted in
the General Body and hence the nomination is bad, is the
contention.

<!-- page 6 -->

W.P.(C) No.65 of 2022

-: 4 :-

7. A perusal of Ext.P1, the minutes of the Managing
Committee

held

on

17.06.2021

indicates

that,

after

referring to the decision of the General Body, the
Committee

by

majority

Smt.Saraswathi

Amma

Section

gives

28(1J)

decision

as

a

resolved

member

authority

of

to

to

the

the

nominate

Committee.

Committee

to

nominate member in the contingency as mentioned therein.
The nomination of Smt.Saraswathi Amma is made by the
Committee in accordance with the powers granted under
the

Act.

The

nomination

having

been

made

by

the

Committee in terms of the Act, is legal and valid.
Therefore, the said contention fails.
8.
Managing

The

contention

Committee

of

consists

the

petitioners

of

5

members,

that

the

and

it

constitutes sufficient quorum in terms of Section 28(5)
of the Act is to be upheld and I do so. Ext.P5 order
holding that the Committee of the 5 th respondent lacks
quorum,

and

further

Committee is bad in law.

appointing

an

Administrative

<!-- page 7 -->

W.P.(C) No.65 of 2022

-: 5 :-

9. In the result, Ext.P4 order is quashed. The
administration of the Society shall forthwith be handed
over to the Managing Committee of the Society.
Writ petition is allowed as above.

Sd/SATHISH NINAN
JUDGE
kns/-

//True Copy//
P.S. to Judge

<!-- page 8 -->

APPENDIX OF WP(C) 65/2022
PETITIONER EXHIBITS
Exhibit P1

A TRUE COPY OF THE RESOLUTION DATED 17-062021 OF THE MANAGING COMMITTEE

Exhibit P2

A TRUE COPY OF THE RESIGNATION LETTER DATED
19-12-2021 TENDED BY THE SECOND AND THIRD
RESPONDENTS

Exhibit P3

A TRUE COPY OF THE LETTER DATED 22-12-2021 OF
THE FIFTH RESPONDENT

Exhibit P4

A TRUE COPY OF THE ORDER NO.
DDKTM/10733/2021-D DATED 22-12-2021 OF THE
FIRST RESPONDENT

Exhibit P5

A TRUE COPY OF THE JUDGMENT DATED 17-12-2020
IN W.P(C0 NO. 25091/2020

Exhibit P6

A TRUE COPY OF THE JUDGMENT REPORTED IN 1985
KLT 335

Exhibit P7

A TRUE COPY OF THE JUDGMENT REPORTED IN ILR
2001 (10 KER 62)

Exhibit P8

A TRUE COPY OF THE NOTICE DATED 20-12-2021
FOR THE COMMITTEE MEETING ON 22-12-2021 AND
THE PROCEEDINGS

Exhibit P9

A TRUE COPY OF THE NOTICE DATED 22-12-2021
FOR SPECIAL GENERAL BODY
----
