---
doc_id: "374fcdcccc35f4d5"
source_url: "https://dc.kerala.gov.in/wp-content/uploads/2023/02/Kerala-State-and-Subordinate-Services-Rules-1958.pdf"
ministry: "Drugs Control Department, Kerala"
title: "Kerala State and Subordinate Services Rules-1958"
date: ""
pages: 72
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ced67470a9fcafd7"
---

<!-- page 1 -->

1

GOVERNMENT OF KERALA

KERALA STATE AND SUBORDINATE
SERVICES RULES, 1958
PART I & PART II

ISSUED BY THE AUTHORITY OF THE GOVERNMENT OF KERALA

(incorporating corrections up to 30th June 2012)

PERSONNEL AND ADMINISTRATIVE
REFORMS DEPARTMENT

<!-- page 2 -->

2

PREFACE
Consequent on the formation of Kerala State in November 1956, the Kerala State and
Subordinate Services Rules was broughtout in 1958. Several Amendments have been issued
from time to time. It was therefore felt that there is need to update the KS & SSRs
incorporating subsequent amendments to meet the present day requirements. Review and
Publication of updated version of KS&SSRs was also one of the Actions/Objectives under
Result Framework Document (RFD) of Personnel and Administrative Reforms Department
for 2011-2012.
All amendments and modifications up to 30 th November 2012 have been incorporated
in this edition.
Any error, omission in any of the rules may be brought to the notice of the Secretary,
Personnel and Administrative Reforms Department, Government of Kerala.

T.J. MATHEW
Secretary (P&ARD)
Thiruvananthapuram
Dated :

<!-- page 3 -->

3

Table of Contents

Part I

-

Preliminary
Schedule

Part II

-

General Rules
Schedule

Page

<!-- page 4 -->

4
THE KERALA STATE AND SUBORDINATE SERVICES RULES, 1958
In exercise of the powers conferred by the proviso to Article 309 of the Constitution
of India and of all other powers hereunto enabling, and in supersession of the rules on the
subject the Governor of Kerala hereby makes the following rules in respect of the members
of the State and Subordinate Services.

PART I
PRELIMINARY

1.

Short title and commencement.____ (a) These rules may be called the

Kerala State & Subordinate Services Rules, 1958.
(b) They shall come into force at once.
2.

Definitions.____ In these rules unless there is anything repugnant in the

subject or context,___

(1)

Appointed to a Service.____ A person is said to be "appointed to a service"

when in accordance with these rules or in accordance with the rules applicable at the time
as the case may be, he discharges for the first time the duties of a post borne on the cadre
of such service or commences the probation, instruction or training prescribed for
members thereof:

Explanation.____

The appointment of a person holding a post borne on the cadre of one
service to hold additional charge of a post borne on the cadre of another
service or to discharge the current duties thereof does not amount to
appointment to the latter service.

(2) Approved candidate.____ "Approved candidate" means a candidate whose name

appears in an authoritative list of candidates approved for appointment to any service,
class or category.
(3) Approved Probationer.____ "Approved probationer" in a service, class or category

means a member of that service, class or category who has satisfactorily completed his
probation and awaits appointment as a full member of such service, class or category.
(4) Commission.___ "Commission" means the Kerala Public Service Commission.
(5) Discharge of a Probationer.____ "Discharge of a probationer" means, in case the
probationer is a full member or an approved probationer of another service, class or
category, reverting him to such service, class or category and in any other case, dispensing
with his services.
(6) Duty.____ A person is said to be "on duty" as a member of a service:____

<!-- page 5 -->

5
(a) When he is performing the duties of a post borne on the cadre of such service or
is undergoing the probation, instruction or training prescribed for such service;
(b) When he is on joining time;
(c) When he is absent from duty during vacation or on authorized holidays or
on casual leave taken in accordance with the instructions regulating such leave issued
by the State Government having been on duty immediately before and immediately after
such absence;
(d) When he is on deputation, during his period of probation, for training or for
acquisition of higher or additional qualification in public interest;
(e) When he is waiting for posting orders after reporting for duty;
(f) When he is given the benefit of notional promotion consequent on revision of
rank and seniority etc.; or
(g) In the case of a female member, when she is on maternity leave during her
period of probation.
This amendment shall be deemed to have come into force on the 15 th February,
1988 and shall apply to all cases in which the prescribed period of probation expired on or
after the 15th February, 1988.
(6A) Ex-Serviceman.____ "Ex-Serviceman" for the purpose of these rules shall

include any categories of service as may be defined by the Government of India as such,
from time to time.
(7) Full member.____ "Full member" of a service means a member of that service who

has been appointed substantively to a permanent post borne on the cadre thereof,
(8) General Rules.___“General rules" means rules in Part II of these rules.
(9) Member of a Service.____ "Member of a service" means a person who has been

appointed to that service and who has not retired or resigned, been removed or dismissed,
been substantively transferred or reduced to another service, or been discharged otherwise
than for want of a vacancy. He may be a probationer, an approved probationer or a full
member of that service.
(9A) Military Service.____ "Military Service" means service in the Armed Forces

under the Ministry of Defence, Government of India, whether as a combatant or a noncombatant, for a continuous period of not less than 6 months, but does not include service
in Para Military Forces, namely Assam Rifles, Defence Security Corps, General Reserve
Engineer Force, Jammu and Kashmir Militia, Lok Sahayak Sena and Territorial Army.
(10) Probationer.____ "Probationer" in a service means a member of that service

who has not completed his probation.
(11) Promotion.____ "Promotion" means the appointment of a member of any

category or grade of a service or a class of service to a higher category or grade of such
service or class.

<!-- page 6 -->

6
(12) Recruited direct.____ A candidate is said to be "recruited direct" to a service,
class, category or post when, in case his first appointment thereto has to be made in
consultation with the Commission, on the date of its notification inviting applications for
the recruitment, and in any other case, at the time of his first appointment thereto, he is
not in the service of the Government of India or the Government of a State.

(i)
he is not in the service of the Government of India or the Government of a
State; or
(ii)
being in the service of the Government of India or the Government of a State,
he satisfies all the qualifications (including age) and other conditions prescribed for such
recruitment to that service, class, category or post and is permitted to apply for such
recruitment by the competent authority; or
(iii)
he holds a post, the conditions of service of the holder of which have been
declared to be matters not suitable for regulation by rule.
(13) Recruited by transfer.____ A candidate is said to be "recruited by transfer" to a

service ___
(i)
if his appointment to the service is in accordance with the orders issued or
rules prescribed for recruitment by transfer to the service; and
(ii)
if at the time of his first appointment thereto ___

(a)
he is either a full member or an approved probationer in any other service,
the rules for which prescribe a period of probation for members thereof:
Provided that where the Special Rules for a service provide for recruitment by
transfer to any class or category thereof from any specified class or category of another
service, a candidate shall, unless the recruitment is made from a post carrying an identical
scale of pay`, be a full member or an approved probationer in the class or category so
specified; or
(b)
he is the holder of a post in any other service for which no probation has
been prescribed, and has put in satisfactory service in that post for a period of two years
on duty within a continuous period of three years.
(14) Scheduled Castes, Scheduled Tribes and Other Backward Classes .____

Scheduled Castes, Scheduled Tribes mean the Castes and Tribes declared as such by the
President of India under Article 341 (1) and 342 (1) of the Constitution of India and Other
Backward Classes mean the classes declared as such by the State Government under
Article 16 (4) of the Constitution of India. Lists of such castes, tribes and classes, so
declared are included as Lists I, II and III respectively in the Schedule to this Part.

Explanation.____

A member of a Scheduled Tribe, shall not cease to be a member of
that Scheduled Tribe on change of religion.

(15) Service.____ "Service means a group of persons classified by the State Government

as a State or a Subordinate Service as the case may be.
Note.__

Where the context so requires "service" means the period during which a
person holds a post or a lien on a post or is a member of a service as above defined.

(16) Special Rules.____ "Special Rules" shall mean the rules in Part III applicable

to each service or class of service.

<!-- page 7 -->

7
(17)
Pay, allowance, leave, leave salary, pension and other conditions of
service.- The Kerala Civil Services (Classification, Control and Appeal) Rules, the rules

regulating the pay of the services issued from time to time, the Government Servant's
Conduct Rules, the Travancore Service Regulations, the Cochin Service Regulations, the
Fundamental Rules, the Madras Leave Rules, 1933, Kerala Service Rules and the Pension
Rules for the time being in force shall, in so far as they may be applicable and except to
the extent expressly provided in those rules govern members of every service in the matter
of their pay, allowances, leave, leave salary, pension and other conditions of service:
Provided that the said rules and regulations shall, in their application to the
members of the Secretariat Staff of the Governor, be construed as if the functions of the
State Government under those rules and regulations were the functions of the Governor.
(18)

Cadre.____ The Permanent cadre of each service, class, category and grade

shall be determined by the State Government.

SCHEDULE
LIST I
SCHEDULED CASTES IN THE KERALA STATE

1.

Adi Andhra

2.

Adi Dravida

3.

Adi Karnataka

4.

Ajila

5.

Arunthathiyar

6.

Ayyanavar

7.

Baira

8.

Bakuda

9.

Bathada

10.

Bharathar (other than Parathar), Paravan

11.

Chakkiliyan

12.

Chamar, Muchi

13.

Chandala

14.

Cheruman

15.

Domban

16.

Gosangi

17.

Hasla

18.

Holeya

19.

Kadaiyan

20.

Kakkalan, Kakkan

21.

Kalladi

<!-- page 8 -->

8
22.

Kanakkan, Padanna, Padannan

23.

Kavara (other than Telugu speaking or Tamil speaking Balija,
Kavarai, Gavara, Gavarai,Gavarai Naidu, Balija Naidu, Gajalu
Balija or Valai Chetty).

24.

Koosa

25.

Kootan, Koodan

26.

Kudumban

27.

Kuravan, Sidhanar, Kuravar, Kurava, Sidhana

28.

Maila

29.
30.

Malayan (In the areas comprising the Malabar district as specified by subsection (2) of Section 5 of the State Reorganization Act, 1956 (37 of 1956)
Mannan, Pathiyan, Perumannan, Vannan, Velan

31.

Moger (other than Mogeyar)

32.

Mundala

33.

Nalakeyava

34.

Nalkadaya

35.

Nayadi

36.

Pallan

37.

Pulluvan

38.

Pambada

39.

Panan

40.

Paraiyan, Parayan, Sambavar, Sambavan, Sambava, Paraya,
Paraiya, Parayar

41.

Pulayan, Cheramar, Pulaya, Pulayar, Cherama, Cheraman,
Wayanad Pulayan, Wayanadan Pulayan, Matha, Matha Pulayan

42.

Puthirai Vannan

43.

Raneyar

44.

Samagara

45.

Samban

46.

Semman, Chemman, Chemmar

47.

Thandan

48.

Thoti

49.

Vallon

50.

Valluvan

51.

Vetan

52.

Vettuvan, Pulaya Vettuvan (in the areas of erstwhile Cochin State only)

53.

Nerian

<!-- page 9 -->

9

LIST II
SCHEDULED TRIBES IN THE KERALA STATE
1.

Adiyan

2.

Arandan, Aranadan

3.

Eravallan

4.

Hill Pulaya, Mala Pulayan, Kurumba Pulayan, Karavazhi Pulayan,
Pamba Pulayan

5.

Irular, Irulan

6.

Kadar, Wayanad Kadar

7.

Kanikaran, Kanikkar

8.

Kattunayakan

9.

Kochuvelan

10.

Koraga

11.

Kudiya, Melakudi

12.

Kurichchan, Kurichiyan

13.

Kurumans, Mullu Kuruman, Mulla Kuruman, Mala Kuruman

14.

Kurumbas, Kurumbar, Kurumban

15.

Maha Malasar

16.

Malai Arayan, Mala Arayan

17.

Malai Pandaram

18.

Malai Vedan, Malavedan

19.

Malakkuravan

20.

Malasar

21.

Malayan, Nattu Malayan,
Konga Malayan
comprising
the
Kasargode,
Cannanore,
Districts)

22.

Malayarayar

23.

Mannan (to be spelt in Malayalam script in parenthesis) (hKkmX)

24.

Muthuvan, Mudugar, Muduvan

25.

Palleyan, Palliyan, Palliyar, Paliyan

26.

Paniyan

27.

Ulladan, Ullatan

28.

Uraly

(excluding
the
areas
Wayanad
and
Kozhikode

<!-- page 10 -->

10
29.

Mala Vettuvan (in Kasargode and Kannur districts)

30.

Ten Kurumban, Jenu Kurumban

31.

Thachanadan, Thachanadan Moopan

32.

Cholanaickan

33.

Mavilan

34.

Karimpalan

35.

Vetta Kuruman

36.

Mala Panickar"

LIST III
OTHER BACKWARD CLASSES IN THE KERALA STATE
1. Throughout the State

1.

Agasa

2.

Ambalakkaran

3.

Anglo Indian

4.

** ** * * * *

5.

** ** * * * *

6.

Aremahrati

7.

Arya

8.

Bandari

9.

Billava

10.

Chakkala

11.

** ** * * * *

12.

Chavalakkaran

13.

Chetty/Chetties
Attingal
Chetties,

(Kottar

Chetties,

Chetties,

Pudukkada

Telugu

Parakka

Chetties,

Chetties,

Chetties,

Udayamkulangara

Chetties,

Sadhu

Chetties,

24

Kalavara

Chetties,

24

Telungu

Mana

Iraniel

Chetties,

Manai

Chetties,

Chetties,

Elur

Chetties,

Sri

Pandara

Chetties,Peroorkada
Wynadan

Moundadan

Chetties,

Chetty

and

Edanadan Chetty.)
14.

Devadiga

15.

Devanga

15A. Dheevara: (Arayan Acbu), (Valan hmeu), (Nulayan \pfbu), (Mukkuvan

ap¡phu), (Arayavathi AcbhmJn),

(Valinjar hfnuPnbmV), (Paniakkal

<!-- page 11 -->

11
]mWnbm¡v),

(Mukaya

apIb),

(Bovi

Mukayar

t_mhn

aqIbmV)

and

(Mukaveeran aqIhocu).
16.

Ezhavas and Thiyyas: (1) Izhavan (Cughu) Ishavan (Cughu) Ezhavan
(Cghu) (2) Ezhuva (Cgph) Izhuva (Cgph) Ishuva (Cgph)
(Cgphu)

Ishuvan (Cgphu)

Ezhuvan (Cgphu)

(3) Izhuvan

(4) Izhava (Cgh) Izhavan

(Cghu) Ishavan (Cghu) (5) Illuva (Cffph) (6) Illuvan (Cffphu) (7) Irava
(Cch) and (8) Iruva (Ccph)
17.

Ezhavathi

18.

Ezhuthachan

19.

Ganika

20.

Gatti

21.

Gowda

22.

Hegde

23.

…..............

24.

…..............

25.

Jogi

26.

Kaduppattan

27.

Kaikolan

28.

Kelasi (Kalasi Panicker)

29.

Kalari Kurup or Kalari Panicker

30.

Viswakarmas including Asari Chaptegra, Kallassari, Kalthachan, Kammala,
Kamsala, Kannan, Karuvan, Kitaran, Kollan, Malayala Kammala, Moosari,
Pandikammala, Pandithattan, Perumkollan, Thachan, Thattan, Vilkurup, Villasan,
Viswabrahmanan or Viswabrahmanar,Viswakarmala and Palisa Perumkollan.

31.

Kannadiayans

32.

Kanisu or Kaniyar Panicker, Kani or Kaniyar (Ganaka) or Kanisan or Kamnan

33.

Kavuthiyan

34.

Kavudiyaru

35.

Kongu Navithan, Vettuva Navithan and Aduthon.

35 A. The Kongu Vellala Gounder including Vellala Gounder, Nattu Gounder, Pala
Gounder, Poosari Gounder and Pala Vellala Gounder+
36.

Koteya

37.

Krishnanvaka

<!-- page 12 -->

12
38.

Kerala Mudalis

39.

Kudumbis

40.

Kusavan (Kulala, Kulala Nair or Andhra Nair or Anthuru Nair)

41.

Kumbarans

41A

Kuruba

42.

Latin Catholics (Latin Christians)

43.

Madivala

44.

…....................

45.

Maravans

46.

Maruthuvar

47.

…....................

48.

Muslim or Mappila

49.

Hindu Nadars

49A.

Nadars included in S.I.U.C

50

Naikkans

51.

Odans

52.

Scheduled Caste Converts to Christianity

53.

Pandithars

54.

Panniyar

55.

Pattariyas

56.

…..................

57.

Peruvannan (Varanavar)

58.

Pulluvan

59.

Rajapur

60.

Chakravar, Sakravar (Kavathi)

61.

Sourashtras

62.

Saliyas , Chaliya (Chaliyan)

63.

Senai Thalavar (Elavaniar)

64.

S.I.U.C. (excluding Nadars specified in item 49A)

64A.

Thachar

65.

Tholkollans

66.

Thottian

67.

Vaduvans, Vadugans, Vadukars and Vadukas (Vadukans

68.

…......................

69.

Velaans (Velaan, Velaar)

70.

Vanians (Vanika, Vanika Vaisya, Vanibha Chetty, Vaniya Chetty, Ayiravar,
Nagarathar and Vaniyan)

<!-- page 13 -->

13
71.

Vaniar

72.

Vakkaliga

73.

Veerasaivas (Yogis, Yogeeswara, Poopandaram/Maalapandaram , Jangam and
Pandaram)

74.

Veluthedathu Nair (Veluthedan and Vannathan)

75.

Vilakkithala Nair (Vilakkithalavan)

76.

Yadavas (Kolaya, Ayar, Mayar,Maniyani and Iruman)

77.

Mooppar or Kallan Mooppan or Kallan Mooppar

78.

Mahendra-Medara

2.

In Malabar District:
1. * * * * * * * *
2. Boyan
3. Ganjam Reddis
4. Vishavan

3.

Throughout the State except Malabar District :
1. Kammara
2 ** ** * * * *
3. Malayekandi
4. Reddiars

4.

Throughout the State except Kasaragod Taluk of Malabar

District :

Marati

Explanation.____
Reorganization

In this Schedule, Malabar District shall mean the Malabar District
referred to in sub-section (2) of Section
5 of the States
Act, 1956.

PART II
GENERAL RULES
1. Scope of the General Rules.______ The rules in this part shall apply to all State

and Subordinate Services and the holders of all posts, whether temporary or permanent in
any such service, appointed thereto before, or after the date on which these rules come
into force as provided in sub-rule(b) of rule 1 in Part I except to the extent otherwise
expressly provided, (a) by or under any law for the time-being in force, or (b) in respect of
any member of such service by a contract or agreement subsisting between such member
and the State Government:
Provided that the rules in this part shall also be applicable to holders of all posts in
Government Service eventhough the posts they hold are not classified as coming under a

<!-- page 14 -->

14
particular service by including in Schedule I or Schedule II of the Kerala Civil Services
(Classification, Control and Appeal) Rules, 1960.
2. Relation to the Special Rules.______ If any provision in the General Rules

contained in the Part is repugnant to a provision in the Special Rules applicable to any
particular service contained in Part III, the latter shall, in respect of that service, prevail
over the provision in the General Rules in this Part.
3. Approved Candidates.______ (a) All first appointments to the service shall be made

by the Appointing Authority on the advice of the Commission in respect of posts falling
within the purview of the Commission and in all other cases by the Appointing Authority
from a list of approved candidates prepared in the prescribed manner.
(b)
The inclusion of a candidate's name in any list of approved candidates for
any service (State or Subordinate) or any class or category in a service, shall not confer on
him any claim to appointment to the service, class or category.
(c)
Notwithstanding anything contained in these rules, the Commission shall
have the power to cancel the advice for appointment of any candidate to any service if it is
subsequently found that such advice was made under some mistake.
On such
cancellation, the appointing authority shall terminate the service of the candidate:
Provided that the cancellation of advice for appointment by the Commission and the
subsequent termination of service of the candidates by the appointing authority shall be
made within a period of one year from the date of such advice:
Provided further that, a cancellation of advice under this sub-rule shall be made
only after giving the candidate concerned a reasonable opportunity of being heard in the
matter.
The provisions in this sub-rule shall be deemed to have come into force on the 31st
July 1969.
4.
Every candidate for appointment to any service or for admission to any
suitability/eligibility test, whether a member of a service or not, who in response to a
notification issued by the Commission makes an application, shall make such application
in the form printed and distributed under the authority of the Commission. The cost of
such application shall be Rs. 5 (Rupees five only) for Scheduled Castes and Scheduled
Tribes candidates and Rs. 10 (Rupees ten only) for all other candidates.
4A.
Every candidate who applies for admission to the Special/Departmental
tests conducted by the Public Service Commission or for certificate of pass/attendance or
for mark lists thereof shall be required to remit a fee as may be prescribed by the
Commission with the prior approval of the Government, for each paper of these tests or for
certificate of pass as the case may be and such fee shall be specified by the Commission in
the notification inviting applications for admission to such tests.

Note.______

Photo copies of Optical Mark Recoginition (OMR) answer scripts shall
be made available to the candidates by the Kerala Public Service
Commission on request and subject to payment of a fee of Rs.200 (Two
hundred only) for each answer script. The candidates shall submit
separate application for each answer script to the Kerala Public Service
Commission after remitting the prescribed fee in the specified Head of
Account.

<!-- page 15 -->

15
5.
Method of recruitment.______ Where the normal method of recruitment to any
service, class or category is neither solely by direct recruitment nor solely by transfer, but
is both by direct recruitment and by transfer._____

(a) the proportion or order in which the Special Rules concerned may require
vacancies to be filled by persons recruited direct and by those recruited by transfer shall
be applicable only to substantive vacancies in the permanent cadre;
(b) person shall be recruited direct only against a substantive vacancy in such
permanent cadre, and only if the vacancy is one which should be filled by direct recruit
under the Special Rules referred to in clause (a); and
(c) recruitment to all other vacancies shall be made by transfer.
Note.__ (1)

All permanent vacancies and temporary vacancies except those of short duration
shall be treated as substantive vacancies.

(2)
The vacancies on account of leave and deputation with a duration of less
than six months shall be treated as vacancies of short duration, provided,
such
vacancies with a duration of three months to six months should not
be
treated as vacancies of short duration, if the vacancies are likely to
last
long or new vacancies are likely to arise.
(3)

Whenever a ratio or percentage is fixed for different methods of
recruitment/appointment to a post the number of vacancies to be filled up by
candidates from each method shall be decided by applying the fixed ratio or
percentage to the cadre strength of the post to which the recruitment/transfer
is made and not to the vacancies existing at that time.

5A.

Award of weightage marks in District-wise recruitments.______ Where the

method of recruitment to any post of any service, class or category is by direct recruitment
on district-wise basis, such candidate belonging to that district shall be given a weightage
of 5 marks for a selection:
Provided that candidates who are eligible to get the above weightage marks shall
produce a nativity certificate issued by a Competent Authority not below the rank of a
Tahsildar of the concerned District as and when called for

ANNEXURE
Technical Posts
1.

Driver (Heavy Duty Vehicle) : Various Departments including the Departments of
Excise, NCC, Sainik Welfare and Tourism.

2.

Driver (Light Duty Vehicle) : Various Departments including the Departments of
Excise, NCC, Sainik Welfare and Tourism.

3.

Mechanic

: Fisheries Department.

4.

Plumber

: Public Works Department.

5.

Dark Room Assistant

: Public Relations Department.

6.

Attender (Graining Plates)

: Survey and Land Records Department.

7.

Attender (Plate Cleaning)

: Survey and Land Records Department.

8.

Roller Cleaner

: Public Works Department.

<!-- page 16 -->

16
9.

Oil Engine Driver

: Agriculture Department.

10.

Power Laundry Attender

: Technical Education Department.

11.

Deckman

: Various Department.

12.

Boat Driver

: Various Department.

13.

Cinema Operator

: Public Relations Department.

14.

Driver-Cum-Operator

15.

Boat Syrang

: Scheduled Caste Development Department/
Scheduled Tribe Development Department.
: Various Departments

Non-Technical Posts
1.

Ayah

: Scheduled Caste Development Department/Scheduled
Tribe Development Department
: Ayurveda College

2.

Masseur

3.

Attender

: Judicial Department.

4.

Attender

: Survey and Land Records Department.

5.

Post in Last Grade Service

: Various Department.

6.

Last Grade Service

: National Cader Corps Department.

7.

Last Grade Service

: Sainik Welfare Department.

8.

Villageman

: Revenue Department.

9.

Gate Keeper Grade II/Lascar Grade II: Printing Department.

10.

Lascar

: Agricultural Income Tax and Sales Tax Department.

11.

Gallery Pressman Grade II

: Government Presses.

12.

Fisherman

: Fisheries Department.

13.

Gallery Attendant

: Sri Chitra Art Gallery.

14.

Helper, Pre-Primary Schools : Education Department.

15.

Excise Guards

: Excise Department.

16.

Forest Guards

: Forest Department.

17.

Projector Operator

: Education Department.

18.

Depot Watcher/Reserve Watcher

: Forest Department.

6.
Right of probationers and approved probationers to reappointment
.______ A vacancy in any service, class or category not being a vacancy which should be
filled by direct recruitment under the Special Rules referred to in clause (a) of rule 5 shall
not be filled by the appointment of a person who has not yet commenced his probation in
such service, class or category when an approved probationer or a probationer therein is
available for such appointment.

7.
Discharge and re-appointment of probationers and approved
probationers.______ (a)
The order in which probationers and approved probationers
shall be discharged for want of vacancies shall be: ______ first, the probationers in order
of juniority, and second the approved probationers in order of juniority.

<!-- page 17 -->

17
(b)
Approved probationers and probationers who have been discharged for want
of vacancies shall be re-appointed as vacancies arise in the inverse of the order laid down
in sub-rule (a):
Provided (1) that the said order may be departed from in cases where such order
would involve excessive expenditure on traveling allowance or exceptional administrative
inconvenience, and (2) that such order may be departed from in the case of Scheduled
Castes, Scheduled Tribes and other Backward Classes in accordance with the provisions
in the Special Rules contained in Part III relating to the relevant service:
Provided further that in the case of posts in more than one Department/
institution, for which a common selective list is prepared by the Commission, the
candidates discharged from service for want of vacancies may either re-register their
names in the Office of the Commission and get themselves re-appointed on the further
advice of the Commission, or they may await their turn for re-appointment to the posts
under sub-rule (b) in case they desire to continue as probationers in the posts from which
they were discharged.
This amendments shall be deemed to have come into force with effect from 17 th
December 1958.
Members absent from duty.______

The absence of a member of a service
from duty in such service, whether on leave, other than Leave Without Allowance granted
and availed of as per Appendix XII A, Appendix XII B or Appendix XII C of Part I of Kerala
Services Rules, on foreign service or on deputation or for any other reason and whether
his lien in a post borne on the cadre of such service is suspended or not, shall not, if he is
otherwise fit, render him ineligible in his turn, _____
8.

(a)
for re-appointment to a substantive or officiating vacancy in the class,
category, grade or post in which he may be a probationer or an approved probationer;
(b)

for promotion from a lower to a higher category in such service; and

(c)
for appointment to any substantive or officiating vacancy in another service
for which he may be an approved candidate;
As the case may be, in the same manner as if he had not been absent. He shall be entitled
to all the privileges in respect of appointment, seniority, probation and appointment as full
member which he would have enjoyed but for his absence:
Provided that subject to the provisions of rule 18 he shall satisfactorily complete
the period of probation on his return;
Provided further that a member of a service who is appointed to another service and
is a probationer or an approved probationer in the latter service, shall not be appointed
under the clause (c) to any other service for which he may be an approved candidate
unless he relinquishes his membership in the latter service in which he is a probationer or
an approved probationer.
Provided further that this rule shall not have retrospective effect so as to disturb
the decisions taken by the Travancore-Cochin Government in respect of the TravancoreCochin personnel:
Provided also that this rule shall not apply in the case of a member of a service
whose absence from duty in such service is by reason of his appointment to another

<!-- page 18 -->

18
service not being Military Service, solely on his own application, unless such appointment
is made in the exigencies of public service.
Note.__ (1)

An appointment made in pursuance of applications invited, sponsored or
recommended 1[by Government or other competent authority on behalf of the
Government] shall be deemed to be an appointment made in the exigencies of
Public Service for the purpose of this rule.

(2)

The benefit of the rule shall not be available to a person holding a post in any
class or category in a service if his appointment to that post was from a post in
another class or category in the same service.

2 [ (3)

A member of a service appointed to another service in the exigencies of public
service in the manner as specified in Note (1) above shall, unless otherwise
specified by the Government at the time of relief, be eligible for the benefits in
respect of seniority, probation and appointment as full member in such service
as envisaged under this rule, only in the event of his reappointment to such
service of the parent Department is before the confirmation of his service in the
latter Department or within five years from the date of his relief from the parent
Department whichever is earlier. In respect of reappointment after the said
period, he shall be eligible to rejoin the service of parent Department as the
junior most in the class, category, grade or post in which he was a probationer
or an approved probationer on the date of his relief.]

Temporary appointments.____ (a)

(i)
Where it is necessary in the public
interest, owing to an emergency which has arisen to fill immediately a vacancy in a post
borne on the cadre of a service, class or category and there would be undue delay in
making such appointment in accordance with these rules and the Special Rules, the
appointing authority may appoint a person, otherwise than in accordance with the said
rules, temporarily:
9.

Provided that before a person is appointed under this clause, persons who are
admittedly senior to him shall also be appointed, even if they are absent from duty,
whether on leave other than leave without allowances granted and availed of as per
Appendix XII A, Appendix XII B or Appendix XII C of Part I of the Kerala Services Rules or
on foreign service or on deputation or for any other valid reason, except due to suspension
and allowed to continue as such subject to the condition that persons so appointed shall
not be eligible for the higher time scale of pay by virtue of such appointments unless
otherwise specifically ordered by the Government.1
Note.____(1)

Even where it is considered necessary to sanction the higher time scale of pay
not more than one person (either the senior-most fit person in a series of
adjacent persons outside the ordinary line, or, if such a person either forgoes the
benefit of his own volition or does not require the benefit by virtue of his holding
a post outside the ordinary line which secures him at least equivalent benefits in
respect of salary and pension, then the next below in the series) may be

1

Substituted by G.O (P) No. 19/2013/P&ARD dated 14th June 2013 published as S.R.O. No. 479/2013 in Kerala
Gazette Extraordinary No. 1728 dated 17th June 2013.

2

Inserted as per G.O (P) No. 19/2013/P&ARD dated 14th June 2013 published as S.R.O. No. 479/2013 in Kerala
Gazette Extraordinary No. 1728 dated 17th June 2013.

<!-- page 19 -->

19

(2)

(3)

(4)

(5)

authorized to draw the salary of the higher scale or grade in respect of any one
officiating vacancy within the cadre filled by his junior.
A fortuitous officiating appointment given to a person who is junior to one
outside the regular line does not in itself give rise to a claim on the part of the
senior to the higher time scale of pay.
The expression "persons who are admittedly senior" in the above proviso shall
include persons appointed/promoted temporarily and continuing as such solely
due to administrative delay in regularizing their appointments.
A person who is on leave without allowances granted and availed of as per
Appendix XII A, Appendix XII B or Appendix XII C of Part I of the Kerala Services
Rules shall be given promotion to a higher post only on his return from such
leave. His rank and seniority in the higher post shall be determined with
reference to the date of promotion.
If a junior is appointed temporarily in preference to a senior under suspension,
at the time of reinstatement of the senior to duty fully exonerating him of the
charges for suspension the senior shall be given appointment to the vacancy in
the higher post to which he would have been appointed but for the suspension,
if necessary by reverting the junior who got appointment in that vacancy:

Provided further that a person appointed under this clause by direct recruitment to
a post other than teaching post and a post covered by the proviso to clause (iii) of rule 10
(b) shall not be allowed to continue in such post for a period exceeding one hundred and
eighty days:
Provided also that if a person belonging to any of the Scheduled Castes or
Scheduled Tribes appointed under this clause was in service as on 2 nd August, 1984, he
shall be allowed to continue in service even if the period of 180 days expires subject to the
conditions that,
(1)
the benefit shall not be available to a person belonging to any of the
Scheduled Castes or Scheduled Tribes appointed under this clause to a post reserved for
Scheduled Castes or Scheduled Tribes for Special Recruitment on the basis of the
instructions issued in Government Circular No. 88342/EC.A2/83/GAD dated the 21 st
January, 1984;
(2)
he shall not be allowed to continue in service in preference to a candidate
advised by the Kerala Public Service Commission; and
(3)
such continuance shall be allowed only if there is vacancy available for him
to continue:
Provided also that a person appointed under this clause by direct recruitment to a
teaching post shall be allowed to continue, subject to availability of vacancy ____

(a)
in case the institution is one to which regular annual vacations are allowed,
till the closing date of the institution for the annual vacation or till a candidate advised by
the Public Service Commission joins duty, whichever is earlier;
(b)
in case the institution is one to which regular annual vacation is not
allowed, for a period not exceeding one year or till a candidate advised by the Public
Service Commission joins duty whichever is earlier.
Explanation.____

For the purpose of the proviso, the institutions specified below shall
be deemed to be institutions to which regular annual vacations are
not allowed, namely:______

<!-- page 20 -->

20
-------------------------------------------------------------------------------------------------------------------Name of the Institutions
Heads of Departments in
respect of the Institutions
-------------------------------------------------------------------------------------------------------------------(1)
(2)
1.
Medical College, Trivandrum,
Principal
Kottayam, Calicut and Trichur
2.

T.D. Medical College, Alleppey

3.

Kerala Institute of Nautical
Studies, Vizhinjam

4.

Government Homoeopathic
Medical College, Calicut and
Trivandrum

Principal
Director of Ports

Principal

5.

Tailoring and Garment making
Training Centres

Director of Harijan Welfare

6.

Tailoring Trade Schools

Director of Harijan Welfare

7.

Vocational Training Centres

8.

Industrial Training Insitute,
Neyyattinkara

Director of Training, Trivandrum

9.

Industrial Training Institute.
Chackai

Director of Training, Trivandrum

10.

Industrial Training Institute for
for Women, Kazhakkoottam

Director of Training, Trivandrum

11.

Industrial Training Institute,
Chandanathope, Quilon

Director of Training, Trivandrum

12.

Industrial Training Institute,
Chengannoor

Director of Training, Trivandrum

13.

Industrial Training Institute,
Ettumannoor

Director of Training, Trivandrum

14.

Industrial Training Institute,
Kalamassery

Director of Training, Trivandrum

15.

Industrial Training Institute,
Chalakudy

Director of Training, Trivandrum

16.

Industrial Training Institute,
Malampuzha

Director of Training, Trivandrum

17.

Industrial Training Institute,
Calicut

Director of Training, Trivandrum

Director of Harijan Welfare

<!-- page 21 -->

21
18.

Industrial Training Institute,
Areacode, Malappuram

Director of Training, Trivandrum

19.

Industrial Training Institute,
Attingal

Director of Training, Trivandrum

20.

Industrial Training Institute,
Thottada

Director of Training, Trivandrum

21.

P.T. Chacko Memorial Industrial
Training Institute, Pallickathode,
Kottayam

Director of Training, Trivandrum

22.

Industrial Training Institute,
Kattappana

Director of Training, Trivandrum

23.

Related Instruction Centre,
Trivandrum

Director of Training, Trivandrum

24.

Related Instruction Centre,
Quilon

Director of Training, Trivandrum

25.

Related Instruction Centre,
Kottayam

Director of Training, Trivandrum

26.

Related Instruction Centre,
Alleppey

Director of Training, Trivandrum

27.

Related Instruction Centre,
Trichur

Director of Training, Trivandrum

28.

Related Instruction Centre,
Kalamassery

Director of Training, Trivandrum

29.

Related Instruction Centre,
Calicut

Director of Training, Trivandrum

30.

Poultry Training Institute,
Central Hatchery, Chengannoor

Director of Animal Husbandry

31.

Chick Sexing School at Central
Hatchery, Chengannoor

Director of Animal Husbandry

32.

Government Survey Schools
at Trivandrum, Kottayam, Trichur,
Kozhikode, Cannanore

Director of Survey and Land Records

33.

Sree Visakom Tirunal School
of Epigraphy

Director of Archeology

34.

Tailoring and Garment Making
Schools at Pattom, Thevally
Kanjikuzhy, Tripunithura,
Njarakkal, Trichur, Kalpathy,

Director of Technicial Education,
Trivandrum

<!-- page 22 -->

22
Kondotty, Badagara,Dharmadom,
Payyannur
35.

Tailoring Trade School, Harippad
and Devicolam

Director of Technicial Education,
Trivandrum

36.

Tailoring Training Centres at
Parassala, Pachallur, Karimkulam,
Kundala, Chirayinkil, Kanjiramkulam
& Chengannur

Director of Technicial Education,
Trivandrum

37.

Tailoring and Garment Making
Training Centres at Kumili,
Thodupuzha, Cheranallur,
Kadappuram, Mannarghat,
Mankada, Ponnani, Vengara,
Kuttichira, Sultan Battery
and Kasargod

Director of Technicial Education,
Trivandrum

38.

Weaving Training Centre
Aralamoodu, Trivandrum

Director of Technicial Education,
Trivandrum

39.

Composing & Printing Centre,
Vattiyoorkavu

Director of Technical Education,
Trivandrum

40.

Book Binding Centres, Manacaud
and Kulathoor

Director of Technicial Education,
Trivandrum

41.

Rattan Training Centre at
Paraneeyam

Director of Technicial Education,
Trivandrum

42.

Training Institute for Local
Administration, Trivandrum
and Calicut

Director of Panchayats, Trivandrum

43.

Trade School, Mundakayam
(Plantation Corporation's Control)

Labour Commissioner

44.

Training Institutions under
Health Department

Director of Health Services

45.

Home for the Mentally deficient
children, Trivandrum and
Calicut

Local Administration and Social welfare
Department

46.

Training Centre, Pallithura

Director of Industries and Commerce

47.

Government Children's Home
and Special School, Trivandrum
Trichur, Kottayam and Kozhikode

Inspector General of Prisons

48.

Borstal School, Cannanore

Inspector General of Prisons

49.

Five Fisherman Training
Centres, Ernakulam

Director of Fisheries

<!-- page 23 -->

23
50.

Staff Training Centres, Ernakulam

51.

Government Ayurveda College
Trivandrum and Tripunithura
(except Lectures in Sanskrit and
Physical Education)

Director of Fisheries

Principal

52.

Forest Training Schools at
Walayar & Arippa

Chief Conservator of Forests

53.

Industrial Training Institute
for Women, Quilon

Director of Training, Trivandrum

54.

Industrial Training Institute,
Cheneerkara, Pathanamthitta

Director of Training, Trivandrum

55.

Industrial Training Institute,
Mala

Director of Training, Trivandrum

56

Industrial Training Institute
for Women, Calicut

Director of Training, Trivandrum

57.

Industrial Training Institute
Kalpetta
Industrial Training Institute,
Quilandy

Director of Training, Trivandrum,

58.

Director of Training, Trivandrum

59.

Industrial Training Institute,
Kasaragod

Director of Training, Trivandrum

60.

Related Instruction Centre,
Palakkad.

Director of Training,
Thiruvananthapuram

61.

Industrial Training Institute
for Women, Chengannur

Director of Training,
Thiruvananthapuram

62.

Industrial Training Institute
for Women, Kalamassery

Director of Training,
Thiruvananthapuram

63.

Industrial Training Institute
for Women, Chalakkudy

Director of Training,
Thiruvananthapuram

64.

Industrial Training Institute
for Women, Malampuzha

Director of Training,
Thiruvananthapuram

65.

Industrial Training Institute
for Women, Kannur

Director of Training,
Thiruvananthapuram

66.

Industrial Training Institute
Aryanad

Director of Training,
Thiruvananthapuram

Provided also that Assistant Surgeons in the Health Services Department, lecturers
in the Medical Education Department, Medical Officers in the Departments of Indian

<!-- page 24 -->

24
Systems of Medicine and Homeopathy, Government Ayurveda Colleges, Government
Homeopathic Medical Colleges and employees State Insurance, Para Medical Staff of the
above Departments and Institutions and the Basic Health Workers/Health Assistants of
Health Service Department Veterinary Surgeons, Livestock Inspectors and Laboratory
Technicians in the Animal Husbandry Department appointed under this clause by direct
recruitment shall be allowed to continue for a period not exceeding one year or till a
candidate advised by the Public Service Commission joins duty, whichever is earlier.
Provided also that Medical Officers and Para Medical Staff in the Insurance Medical
Services Department appointed under this clause shall be allowed to continue for a period
not exceeding one year or till a candidate advised by the Public Service Commission joins
duty, whichever is earlier.
Provided also that the provisionally appointed Wardens in the Hostels for Scheduled
Caste/Scheduled Tribe students shall be allowed to continue in service till the closing date
of the institutions for annual vacation or till a candidate advised by the Public Service
Commission joins duty, whichever is earlier.
Note.____

Provisional appointment in the post of Warden shall be made only after reporting
the vacancies to the Public Service Commission and getting the report from the
Public Service Commission that there is no list of candidates readily available for
recruitment.

Provided also that no person who does not possess the qualifications, if any,
prescribed for the said service, class or category, shall ordinarily be appointed under
this clause. Every person who does not possess such qualifications and who has been or
is appointed under this clause shall be replaced, as soon as possible, by appointing a
person possessing such qualifications:
Provided also that a person appointed under this clause by direct recruitment to a
post and discharged from service after the admissible period, shall not be re-appointed to
the same post by the same appointing authority, except when fresh candidates are not
available for appointment through Employment Exchange, and such re-appointment shall
be made only with the prior concurrence of the Commission.
(ii)
Where it is necessary to fill a short vacancy in a post borne on the cadre of a
service, class or category and the appointment of the person who is entitled to such
appointment under these rules and the Special Rules, would involve excessive expenditure
on traveling allowance or exceptional administrative inconvenience, the appointing
authority may appoint any other person who possesses the qualifications, if any,
prescribed for the said service, class or category.
(iii)
A person appointed under clause (i) shall be replaced as soon as possible by
a member of the service or an approved candidate qualified to hold the post under the said
rules:
Provided that persons appointed under clause (i) shall be replaced in the order of
seniority based on length of temporary service in the unit.
Note.____

For the purpose of this proviso, posts within the jurisdiction of an Appointing
Authority shall be treated as a unit.

(iv)
A person appointed under clause (i) or (ii) shall not be regarded as a
probationer in such service, class or category or be entitled by reason only of such

<!-- page 25 -->

25
appointment to any preferential claim to future appointment to such service, class or
category.
(v)
There shall be paid to a person appointed under clause (I) or clause (ii) the
minimum pay in the time-scale of pay applicable to such service, class or category:
Provided that, if the person appointed is a member of another service, he shall be
paid the pay admissible to him in the higher time-scale based on the pay in the lower time
scale applicable to him under the rules regulating the fixation of pay, if such pay is higher.
He shall be paid increments in the time scale at the time intervals, as fixed by the
Government from time to time:
Provided further that persons appointed temporarily through Employment
Exchanges shall not be eligible for increment in the time-scale even if they complete the
prescribed period of service fixed for sanctioning such increment.
(b)
A person appointed to any part-time post created in lieu of a whole time
post borne on the cadre of a service, class or category shall not be regarded as a
probationer in such service nor shall he be entitled by reason only of such appointment to
any preferential claim to future appointment to such service, class or category.
(c)
Notwithstanding anything contained in these rules, if and when a temporary
post is created as an addition to the cadre of any service, class or category and the holder
thereof is required by the State Government to possess any special qualifications,
knowledge or experience, any person who possesses such qualifications, knowledge or
experience, and is considered to be the best fitted to discharge the duties of such post
may, irrespective of other considerations, be appointed to that post by the appointing
authority; but the person so appointed shall not, by reason only of such appointment, be
regard as a probationer in such service, class or category nor shall he acquire thereby any
preferential right to future appointment to such service, class or category.
(d)
Notwithstanding anything contained in these rules or in the Special Rules if
and when a vacancy arises in a post borne on the cadre of a service, class or category for
appointment to which knowledge of a particular regional language is necessary in the
opinion of the State Government and the person who is entitled to appointment to the post
under these rules and the Special Rules does not possess such knowledge, any other
person junior to him who had studied the respective regional language from Standard I to
Standard I0 as the medium of instruction and possesses such qualification and other
qualifications, if any, prescribed under the rules may be appointed to that post; but the
person so appointed shall not, by reason only of such appointment, be regarded as a
probationer in such service, class or category, nor shall he acquire thereby any preferential
right to future appointment to such service, class or category.
(e)
Notwithstanding anything contained in these rules the Government may by
order regularize the services of any person appointed directly under clause (i)of sub-rule
(a), if such person,____

(i)
has two years continuous service on 22 nd December 1973 in one category of
post in the same Department, or
(ii)
is physically handicapped and was in service on any day during the period
commencing on and from the 22 nd December 1973 and ending with the 1 st January
1974, or

<!-- page 26 -->

26
is physically handicapped and has put in a total service of one year or more
(iii)
(including broken periods) during the period commencing on and from the 1st January
1968 and ending with the 31 st December 1979, or
(iv)
1981. or

is physically handicapped and was in service on any day during the year

(v)
is physically handicapped and was in service for any day during the period
commencing on and from the 1 st January, 1983 and ending with the 31 st July 1994.
[(v)
is a member of the Scheduled Caste or Scheduled Tribe and was in service
as on 2 nd August 1984.
(vi)
is physically handicapped and has to his/her credit one year of total service
(including broken periods) as on 5 th January 1984, from I st January 1968. (excluding
1981) in one or more categories of posts in the same or different Departments.
Explanation.____

For the purpose of this sub-rule, a physically handicapped person
means a “person with disability” as defined in the Persons with
Disabilities (Equal Opportunities, Protection of Rights and Full
Participation) Act, 1995 ( Act No. 1 of 1996)

Note.____(1)

The medical certificates issued to physically handicapped persons to prove their
physical handicap shall, in the case of orthopaedically handicapped persons,
specify whether the handicap causes, interference with their normal functioning
of the bones, muscles and joints

Note.____(2)

For the purpose of reckoning the period of two years continuous service
prescribed in this sub-rule, the period during which a person continued in
service, after the date of receipt by him of the order of the competent authority
terminating his service, by virtue of any order of Court staying such order of
termination, shall not be taken into account unless such order of termination,
has been finally quashed by the Court.

Provided that the services of any person shall not be regularized under this subrule, unless he satisfies the conditions prescribed in sub-rule (b) of rule 10 of these rules.
9A.

Appointment by agreements._____ (1) When in the opinion of the State Government

special provisions inconsistent with any of these rules or of any other rules made under
the proviso to Article 309 of the Constitution of India or continued by Article 313 of that
Constitution (hereinafter referred to in this rule as the said rules) are required in respect of
conditions of service, pay and allowances, pension, discipline and conduct with reference
to any particular posts, or any of them, it shall be open to the State Government to make
an appointment to such post otherwise than in accordance with these rules or the said
rules and to provide by agreement with the persons so appointed for any of the matters in
respect of which in the opinion of the State Government special provisions are required to
be made and to the extent to which such provisions are made in the agreement, nothing in
these rules or the said rules shall apply to any person so appointed in respect of any
matter for which provision is made in the agreement:
Provided that in every agreement made in exercise of the power conferred by this
rule it shall further be provided that in respect of any matter in respect of which no

<!-- page 27 -->

27
provision has been made in the agreement the provisions of these rules or of the said rules
shall apply.
(2)
A person appointed under sub-rule (1) shall not be regarded as a member of
the service in which the post to which he is appointed is included and shall not be entitled
by reason only of such appointment to any preferential claim to any other appointment in
that or any other service.
9B.
Notwithstanding anything contained in these Rules or in the Special Rules,
the Government, may, in public interest and for reasons to be recorded in writing, depute
or transfer officers from one service to another or from one Department to another within
the same service or sent to or take in officers from other Governments or Statutory Bodies
subject to such conditions as the Government may in each case impose:
Provided that in the case of transfers in the interest of security of State, the reasons
need not be recorded if Government are satisfied that it is not expedient to disclose the
reasons for such transfer:
Provided further that the Commission shall be consulted in respect of such
deputations and transfers whenever such consultation has not been specifically excluded
by the provisions of the Kerala Public Service Commission (Consultation) Regulations,
1957.
Qualifications._____

(a) (i) The educational or other qualifications,
if any, required for a post shall be as specified in the Special Rules applicable to the
service in which that post is included or as specified in the executive orders of Government
in cases where Special Rules have not been issued for the post/service.
10.

(ii)
Notwithstanding anything contained in these rules or in the Special Rules,
the qualifications recognized by executive orders or standing orders of Government as
equivalent to a qualification specified for a post, in the Special Rules or found acceptable
by the Commission as per rule 13 (b) (i) of the said rules in cases where acceptance of
equivalent qualifications is provided for in the rules and such of those qualifications which
pre-suppose the acquisition of the lower qualification prescribed for the post, shall also be
sufficient for the post.
(aa)
The minimum general educational qualification of the S.S.L.C Standard
wherever referred to in the special Rules shall mean the qualifications specified in the
Schedule to this Part.
(aaa) Where the Special Rules for any service prescribe the possession of the
minimum general educational qualification of the S.S.L.C Standard referred to in clause
(aa) as a qualification for appointment as full member in such service, or in any class or
category thereof, or for promotion to any other class or category in such service, or for
appointment by transfer to any other service, a person already in service on 31.10.1956.
or a person who was advised for appointment by the Public Service Commission on or
before 31.10.1956, irrespective of the date of his joining duty on such advice and who does
not possess the above qualification but who is certified by the Head of the Department
concerned to be otherwise deserving of appointment as full member or promotion or, as
the case may be, transfer shall be deemed to possess the minimum general educational
qualification of the S.S.L.C Standard if he appears for the examination of the S.S.L.C
Standard conducted by the commission and secures the minimum percentage of marks to
be prescribed from time to time.

<!-- page 28 -->

28
(aaaa) Notwithstanding anything contained in these Rules or in the Special Rules,
persons belonging to linguistic minorities who take the recruitment test in a language
other than in Malayalam and are appointed to any service shall pass the language test in
Malayalam prescribed in G.O. (Ms) No. 142/PD dated, 31.03.1966 within a maximum
period of ten years from the date of appointment. In cases where the persons concerned
have to be on probation, passing of the test shall be a condition for successful completion
of probation, and their periods of probation shall, if necessary, be extended up to a
maximum period of ten years. Such extension of probation shall not however entail
postponement of increment. Persons who fail to pass the test within the period of ten
years from the date of appointment shall be discharged from service.
Persons in service belonging to linguistic minorities appointed to any service by
transfer or by promotion shall also pass the above language test in Malayalam, if they have
not already passed the test subject to the conditions specified above excepting condition
regarding discharge from service. Such persons who fail to pass the test within the
prescribed period of ten years shall be reverted to the posts held by them before their
appointment by transfer of promotion:
Provided that a person referred to in this sub-rule who has been in service for more
than 4 years on the date of commencement of the Kerala State and Subordinate Services
(Amendment) Rules, 1981, published under Notification No. G.O.(P) 194/81/GAD. Dated
12.06.1981 shall be allowed to pass the language test in Malayalam within a period of two
years from the said date, if he has not already passed the test.
Explanation.___ For the purpose of this sub-rule, a person shall be deemed to have passed
the language test in Malayalam prescribed in G.O. (Ms) No. 142/PD
dated, 31.03.1966 if he has taken Malayalam as Second language in the
High School Courses or Degree Courses.
(ab)
Where the Special Rules or Recruitment Rules for a post in any
service prescribe qualification of experience, it shall, unless otherwise specified, be one
gained by persons on temporary or regular appointment in capacities other than paid or
un paid apprentices, trainees and Casual Labourers in Central or State Government
Service or in Public Sector Undertaking or Registered Private Sector Undertaking, after
acquiring the basic qualification prescribed for the post:
Provided that the experience gained as factory workers on daily wages of a
permanent nature may be accepted, if the service is continuous and not of a casual
nature.
Explanation.____

For the purpose of this sub-rule, ‘Registered Private Sector
Undertaking’ means.____

(i)
Co-operative Societies registered under the Kerala Co-operative Societies
Act, 1969, Societies Registered under the Societies Registration Act 1860 or the
Travancore-Cochin Literary, Scientific and Charitable Societies Registration Act, 1955 or
Companies registered under the Companies Act, 1956 or any institution, firm or company
which has a legal entity under any law for time being in force;
(ii)
Small Scale Industrial Units registered with the Industrial Development
Commissioner; and
(iii)

Industrial Institutions wherein Government have investments.

<!-- page 29 -->

29
(abb) Experience for 179 days gained through temporary appointments under
rule 9(a) (i) in Departments under Government or Government/quasi Government
Institutions or Public Sector undertakings shall be considered as experience therein for six
months for appointment to posts for which qualification of experience for not less than six
months is prescribed.
(b)
No person shall be eligible for appointment to any service by direct
recruitment, unless ____
(i)
he satisfies the appointing authority that he is of sound health, active
habits and free from any bodily defect or infirmity rendering him unfit for such service;
(ii)
that he does not have more than one wife living or, if the person is a
woman, that she is not married to any person who has a wife living; and
(iii)
the State Government are satisfied that his character and antecedents are
such as to qualify him for such service:
Provided that, before the Government are satisfied of the character and
antecedents of a person selected/advised for appointment by direct recruitment, the
Appointing Authority may appoint him/her temporarily under clause (i) of sub-rule (a) of
rule 9 of these rules subject to the condition that his/her appointment shall be terminated
without notice if Government are not satisfied of his/her character and antecedents on
subsequent verification and that he/she shall be eligible for appointment in regular service
in accordance with the Rules only if his/her character and antecedents are found
satisfactory on subsequent verification.
Note.____ (1)

A person appointed under this proviso shall not be treated as a
member of the service to which he has been so appointed unless he/she
is appointed in regular service in accordance with the rules. In case
it is found that his/her character and antecedents are satisfactory,
his/her temporary appointment shall be treated as appointment in regular
service from the date to his/her temporary appointment to the service.
(2)

The Appointing Authorities shall get the necessary details for verification of
character and antecedents of the candidates advised by the Commission from
the candidates themselves before they are allowed to join duty and the
appointing authorities shall obtain the reports on the verification of character
and antecedents of the candidates so advised within a period not exceeding
six months from the date of joining duty of the candidates.

(c)
The upper age limit prescribed in the Special Rules shall, unless
otherwise stated, be raised by 5 years in the case of a candidate belonging to any of the
Scheduled Castes or adult members of such castes and their children when such adult
members are converted to other religions, or Scheduled Tribes and by 3 years in the case
of a candidate belonging to any of the Other Backward Classes:
Provided that the age limit shall not apply_____
(i)
to the appointment of a candidate belonging to any of the Scheduled
Castes or adult members of such castes and their children when such adult members are
converted to other religions, or Scheduled Tribes to a post included in a service for which
the Special Rules prescribe a qualification lower than a degree of a recognized University, if
such candidate possesses an educational qualification which is higher than that referred
to in sub-rule (a) and he is otherwise qualified for appointment; or

<!-- page 30 -->

30
(ii)
the appointment to a post included in a service of a candidate belonging
to any of the Scheduled Castes or adult members of such castes and their children when
such adult members are converted to other religions, or Scheduled Tribes who holds a
degree of a recognized University, if the degree he holds is not lower than the degree, if
any, prescribed in the Special Rules for appointment to such posts and if he is otherwise
qualified for appointment.
Explanation.____

The expression 'educational qualification' in clause (i) of
the proviso to sub-rule (c) of this rule, shall mean technical
qualification in the case of technical posts and general educational
qualification in the case of non-technical posts.

(cc)
The upper age limit allowed to a candidate belonging to any of the
Scheduled Castes or Scheduled Tribes under Rule 10 (c) and the provisos there under
shall up to 31 st March 1967, apply to persons actually engaged in the profession of
Goldsmiths or as lapidary workers for a period of at least six months prior to the issue of
the Gold Control Rules, viz; 10 th January 1963 and who are thrown out of employment,
irrespective of the community to which the person concerned belongs. Such persons
should produce certificates issued by Revenue Officers not below the rank of Tahsildars
showing that they were actually engaged in the profession of Goldsmiths or as lapidary
workers for a period of not less than six months before 10 th January 1963. The
concessions available under this sub-rule to the persons actually engaged in the
profession of Goldsmiths and lapidary workers will be available up to 31 st March 1967 to
such persons as are residing with and financially dependent on them also, provided they
produce certificates issued by Revenue Officers not below the rank of Tahsildars showing
that they were residing with and financially dependent on the persons actually engaged in
the profession of Goldsmiths or lapidary workers for a period of at least six months prior to
10 th January 1963.
(d)
The upper age limit prescribed in the Special Rules may be relaxed by
the commission in cases where the appointment has to be made in consultation with it
and by the State Government or by the Appointing Authority with the approval of the State
Government in other cases, if age alone stands in the way of appointment of a candidate
belonging to any of the Scheduled Castes or Scheduled Tribes to fill up the quota reserved
for the group.
(dd)
In the absence of qualified candidates within the age limit, the upper age
limit shall be relaxed up to 50 years for Special Recruitment.
(e)
In the case of a candidate who is an Ex-serviceman or Ex-General
Reserve Engineer Force person or a disembodied Territorial Army Person, the period of his
service in the Defence Forces or in the General Reserve Engineer Force or in the Territorial
Army, as the case may be and the period of unemployment on discharge up to a maximum
of five years shall be excluded in computing his age for appointment.
(f)
The upper age limit prescribed in the Special Rules as raised by the
Public Services (Raising of Upper Age limit for Appointment) Rules 1972, shall be further
raised by 3 years in the case of Land Verification Volunteers who were recruited during the
year 1973-'74 under the Half-a Million Jobs Programme and were subsequently
retrenched.
Note.____

In the case of former Land Verification Volunteers belonging to any of the
Scheduled Castes/Scheduled Tribes or Other Backward Clases to whom the

<!-- page 31 -->

31
provisions of this sub-rule are applicable, the upper age limit shall be further
raised as provided sub-rule (c)

(g)
In the case of an Ex-Home Guard Volunteer who has completed 3 years
of service in the Home-Guards' Organization and who had satisfactorily undergone the
Home-Guards' Training during the period, the entire period of his service in the HomeGuards' Organization and the period of unemployment thereafter, up to a maximum of 7
years shall be excluded, in computing his age for appointment in Public Services.
(h)
The entire period of service in the Personal Staff of Ministers/ Leader of
Opposition/Government Chief Whip/Speaker/Deputy Speaker/ Chairmen of Financial
Committees, rendered by a person (other than a Government Servant) shall be excluded in
computing his age for appointment in Public Services subject to the overall age limit fixed
in the Public Services (Raising of Upper Age Limit for Appointment.) Rules, 1978.
11. Special Qualifications to be acquired or Special Tests to be passed during
probation.____
Where a probationer has, before he commenced his probation, already

acquired any special qualification or passed any special test prescribed by the Special
Rules or has acquired such other qualification as may be considered by the State
Government or by the Appointing Authority with the approval of the State Government to
be equivalent to the said special qualification or special test, he shall not be required to
acquire such special qualification or to pass such special test again after the
commencement of his probation.
12. Qualifications for promotion.____
(a) Where general educational
qualifications, special qualifications or special tests are prescribed by the Special Rules of
the service for any category, grade or post therein, or in a class thereof, which are not
prescribed for a category or grade in such service or class carrying a lower rate of pay and
no member in the category or grade carrying the lower rate of pay is eligible for promotion
to such category, grade or posts a member in such lower category of grade may be
promoted to the category or grade carrying the higher rate of pay temporarily until a
member of the former category or grade qualified under this rule is available for
promotion. A member temporarily promoted under this rule shall not by reason only of
such promotion, be regarded as a probationer in the category or grade to which he has
been promoted, or be entitled to any preferential claim to future promotion.

(b)
A probationer in a category carrying a lower rate of pay who is promoted
temporarily under sub-rule (a) to a category carrying a higher rate of pay in the same
service shall be entitled to count towards his probation in the former category the period of
duty performed by him in the latter category during which he would have held a post in
the former category but for such temporary promotion.
13. Special Qualifications.____ No person shall be eligible for appointment to any
service, class, category or grade or any post borne on the cadre thereof unless he,____

(a) possesses such special qualifications and has passed such special tests as
may be prescribed in that behalf in the Special Rules, or
(b) possesses such other qualifications as may be considered to be equivalent to
the said special qualifications or special tests ____
(i) by the Commission in cases where the appointment has to be made in
consultation with it; or

<!-- page 32 -->

32
(ii) by the State Government or by the Appointing Authority with the approval of
the State Government, in other cases:
Provided that in the case of the Ministerial Staff of the different
Departments/Offices in the Kerala Judicial Ministerial Subordinate Service and in the
Kerala Ministerial Subordinate Service the unified tests prescribed in G.O.(P)22/63/PD.
dated the 14 th January 1963, as subsequently amended or clarified shall be applicable,
until the Special Rules for the Kerala Judicial Ministerial Subordinate Service or the
Kerala Ministerial Subordinate Service as the case may be come into force.
13A.
Special
and
Departmental
Tests.___Temporary
_____
(1) Notwithstanding anything contained in Rule 13,_____
promotion.

exemption

for

(a) Where a pass in a special or departmental test is prescribed by the Special
Rules of a service for any category, grade or post therein or in any class thereof, a member
of a service belonging to any of the Scheduled Castes or Scheduled Tribes who has not
passed the said test but is otherwise qualified and suitable for appointment to such class,
category, grade or post may be appointed thereto temporarily.
(b) Where a pass in a special or departmental test is newly prescribed by the
Special Rules of a service for any category, grade or post therein or in any class thereof, a
member of a service who has not passed the said test but is otherwise qualified and
suitable for appointment to such class, category, grade or post may, within 2 years of the
introduction of the test, be appointed thereto temporarily.
(2) If a member of a service appointed under clause (a) of sub-rule (1) does not
pass a test within 3 years from the date of such appointment or when the said test also
involves practical training, within three years after the first chance to undergo such
training after such appointment, or if a member of service appointed under clause (b) of
sub-rule (1) does not pass the test within two years from the date of introduction of the
said test or if the said test also involves practical training, within two years after the first
chance to undergo such training after the introduction of the said test, he shall be reverted
to the class, category, grade or post from which he was appointed and shall not again be
eligible for appointment under clause (a) or (b) as the case may be, of sub-rule(1):
Provided that the period of temporary exemption allowed under clause (b) of subrule (1) shall be extended by 3 years in the case of a person belonging to any of the
Scheduled Castes or Scheduled Tribes.
(3) If it is proposed to introduce any new test or tests of a higher standard the
passing of which may be a condition precedent for benefits like increments, promotion,
completion of probation, etc., such test or tests shall be introduced only subject to the
following conditions, namely:(i) double the ordinary permissible time shall be allowed to an allotted employee
for passing the test, in cases where tests of a higher standard are prescribed or where no
tests are prescribed in the parent State;
(ii) notwithstanding anything contained in sub-rule (b) of rule 37-B, Part I, K.S.R
and Rule 21 of these Rules penalties for not passing the test, such as denial of benefits
like increments, promotion, etc., shall be held in abeyance till the expiry of the time given
for passing the prescribed test under clause (i) and the officer shall continue to be on
probation till the expiry of the above period, if he has not passed the prescribed test by
that time. If a member of the service promoted under this clause does not pass the
prescribed test within the time given under clause(i), he shall be reverted to the class,

<!-- page 33 -->

33
category, grade or post from which he was promoted and shall not again be eligible for
promotion under this clause;
(iii) allotted employees of and above the age of 45 years shall not be required to
pass the tests and they shall be eligible for all benefits as if they had passed the tests.
This sub-rule shall be deemed to have come into force with effect from 16 th
March 1966.
(4) Notwithstanding anything contained in sub-rule (1), (2) and (3), the period of
exemption shall, if necessary, be extended taking into account the number of times the
prescribed test was conducted during the period so as to enable the members of the
service to get at least two chances to appear for the test for each year of exemption.
(4A). Civil Servants of the Kerala State who were permitted to take up military
service during the emergency and were allowed to retain their lien in their civil posts
during the period of their absence on military service as per the orders in G.O. (MS) No.
62/Public dated the 6 th February 1963 shall be granted temporary exemption from
passing departmental tests as long as they are in military service and for a further period
of 4 years from the date of rejoining in the civil posts on termination of the military service.
(5) A person reverted for not passing the tests within the period of exemption
shall not, by reason only of the appointment within the period of exemption be entitled to
any preferential claim of future appointment to the class, category, grade or post as the
case may be, to which he has been so appointed:
Provided that this rule shall not be applicable to tests prescribed for purposes of
promotion of the executive staff below the rank of Sub-Inspectors belonging to the Police
Department.
Note.___ This proviso shall be deemed to have come into force with effect from 23 rd
October 1962.
13AA.
Notwithstanding anything contained in these rules, the Government
may, by order, exempt for a specified period, any member or members, belonging to a
Scheduled Caste or Scheduled Tribe, and already in service, from passing the tests
referred to in rule 13 or rule 13 A of the said Rules:

Provided that this rule shall not be applicable to tests prescribed for purposes of
promotion of the executive staff below the rank of Sub-Inspectors belonging to the Police
Department.
Note.____ This proviso shall be deemed to have come into force with effect from 13th January
1972.
13AB. The orders exempting members of the Scheduled Castes and of the
Scheduled Tribes who were in service on the 13 th January 1972, issued under Rule 13AA
shall be and shall be deemed always to have been applicable to members of the Scheduled
Castes and of the Scheduled Tribes who entered service after the said date also.
13 B.
Notwithstanding anything contained in these rules or in the Special
Rules, persons in Government Service who attained the age of 50 years who have put in 25
years of service shall be eligible for permanent exemption from passing the obligatory
departmental tests, other than those prescribed as qualification in the Special Rules for all
purposes such as promotion, appointment as full member of a service etc.

<!-- page 34 -->

34
Provided that persons belonging to Scheduled Castes and Scheduled Tribes shall
be eligible for the permanent exemption when they attain the age of 50 years:
Provided further that this rule shall not be applicable to tests prescribed for
purposes of promotion of executive staff belonging to the Police Department:
Provided also that Ex-servicemen employees of the Rajya Sainik Board
Department who attain the age of 45 years and who have successfully completed
probation shall be permanently exempted from passing the tests prescribed for promotion
irrespective of the period of their service.
Note.____

Military Service and service rendered in Aided Schools, Local Bodies and
Universities, Work Establishment Service of Full Time Work Establishment
employees absorbed into Government Service or recruited by the Public Service
Commission, Private College Service to the credit of teachers of Government
Colleges, Palace Service to the credit of the former Palace Employees absorbed in
the Government Service and service rendered in posts which do not require test
qualification shall be counted for calculating the 25 years of service for granting
such permanent exemption.

Explanation.____ The expression ‘Palace Employees’ shall mean persons who were
employed in the Travancore Palace or in cochin Palace and who were
absorbed in Government Service by specific orders of Government and
recorded as such in their Service Books.
The Provisions in this rule shall be deemed to have come into force with effect
from
(i) the 16 th June 1963 for the proposes of drawl of increments; and
(ii) the 19 th of March 1968 for all other purposes:
Provided also that persons in Government service who attain the age of 50 years
on or after the 26 th day of August 1981, shall be eligible for permanent exemption from
passing the obligatory departmental tests other than those prescribed as essential
qualification in the Special Rules for all purposes such as promotion, appointment as full
member of a service etc., irrespective of their total period of service.
13 BB.

The provisions in rules 13A, 13AA and 13B of these Rules shall not
apply to the qualifying course/training prescribed for the members of the Kerala Fire
Service and the Kerala Fire Subordinate Service.
14. Reservation of appointments._____ Where the Special Rules lay down that the

principle of reservation of appointments shall apply to any service, class or category, or
where in the case of any service, class or category for which no Special Rules have been
issued, the Government have by notification in the Gazette declared that the principle of
reservation of appointments shall apply to such service, class or category, appointments
by direct recruitment to such service, class or category shall be made on the following
basis:_____
(a) The unit of appointment for the purpose of this rule shall be 20, of which 2
shall be reserved for Scheduled Castes and Scheduled Tribes and 8 shall be reserved for
the Other Backward Classes and the remaining 10 shall be filled on the basis of merit:

<!-- page 35 -->

35
Provided that out of every five posts reserved for Scheduled Castes and Scheduled
Tribes, one shall go to Scheduled Tribe candidate and the remaining four shall go to
Scheduled Caste candidates and in the absence of a candidate to fill up the post reserved
for Scheduled Tribe candidates, it shall go to a Scheduled Caste candidates and vice versa.
(b) The claims of members of Scheduled Castes and Scheduled Tribes and Other
backward Classes shall also be considered for the appointments which shall be filled on
the basis of merit and where a candidate belonging to a Scheduled Caste, Scheduled Tribe
or Other Backward Class is selected on the basis of merit, the number of posts reserved
for Scheduled Castes, Scheduled Tribes or for Other Backward Classes as the case may
be, shall not in any way be affected.
(c) Appointments under this rule shall be made in the order of rotation specified
below in every cycle of 20 vacancies.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.

Open Competition
Other Backward Classes
Open Competition
Scheduled Castes and Scheduled Tribes
Open Competition
Other Backward Classes
Open Competition
Other Backward Classes
Open Competition
Other Backward Classes
Open Competition
Scheduled Castes and Scheduled Tribes
Open Competition
Other Backward Classes
Open Competition
Other Backward Classes
Open Competition
Other Backward Classes
Open Competition
Other Backward Classes

Provided that the fourth turn in the third rotation and the twelfth turn in the fifth
rotation shall go to Scheduled Tribe candidates and the fourth and twelfth turns in the
first, second and fourth rotations, the twelfth turn in the third rotation and the fourth turn
in the fifth rotation shall go to Scheduled Caste candidates and in the absence of a
candidate for appointment against the turn allotted for Scheduled Tribe candidates, it
shall go to a Scheduled Caste candidate and vice versa:
Provided that the Rule shall not apply in the following cases:____
(i) appointment of near relatives of military personnel killed, permanently disabled or
reported to be missing in action, and near relatives of Government servants dying in
harness, if they are or have been wholly dependent on such military personnel or
Government servants, as the case may be, subject to the condition that priority in the
matter of appointment shall be given only to one relation in the case of each such
personnel or Government servant.
(ii) appointment of disabled Jawans who are to be rehabilitated on completion of their
medical treatment.

<!-- page 36 -->

36
Persons referred to in items (i) and (ii) above shall be given priority in the matter of
appointment to Government service provided they possess the prescribed qualifications.

Explanation._____

(1)

In the case of military personnel, the term ''near relatives”
means the widows/wives, sons, daughters, sisters, brothers,
father, mother nieces, and nephews.

(2)

Note._____

In the case of
Government
servants the
term ''near
relatives'' means the widows, sons, daughters, sisters,
brothers, father and mother.

This
amendment shall be deemed to have come into force from the 12th
March,1970. But this amendment shall not affect the appointments
already made under G.O. (Ms) No.20/70/PD, dated the 21 st January 1970
and appointments which may be made under the said G.O. on applications
received by the Government on or before the 8th March ,1973.

Provided also that in preparing the list of eligible candidates to be appointed under
this rule applying the rotations specified above in every cycle of 20 vacancies, the
candidates eligible to be selected on open competition basis, that is, turns
1,3,5,7,9,11,13,15, 17 and 19 shall be selected first and then the candidates for the
reservation turns, out of those available in the ranked list in the particular groups having
regard to their ranks. In finalising the select list any candidate of the same community
selected on open competition turns if found to be below in the order of the candidates
selected from the same community on the basis of reservation, for the fixation of ranks as
per rule 27 of these rules, candidates of the same community obtaining higher marks shall
be interchanged with the candidates of the same community in the reservation turn for the
purpose of ranking.
Note.__ This amendment shall be deemed to have come into force with effect from 17th
December 1958

(d) Notwithstanding anything contained in this rule, posts to which, appointments
are made by direct recruitment from a common ranked list prepared on the basis of a
common test or interview or both, shall be grouped together for the purposes of
observance of the rules relating to reservation of appointments.
[e) A supplementary list of sufficient number of suitable candidates, not less than
five times the reservation quota, if available, from each community or group of
communities for the purpose of satisfying the reservation quota, shall be prepared and
published.
Note. ____

'Suitable candidates' for the purpose of this rule shall mean candidates with
notified minimum qualifications and marks in selection procedure lowered to the
extent necessary.

(f) A provisional appointment chart, at the time of each advice, showing separately
the candidates eligible to be selected on open competition basis and candidate eligible to
be selected on reservation turns including details of non-joining duty,no candidates
available vacancies, and forfeited reservation turn vacancies pending, if any, to be
compensated shall be published:
Provided that a final appointment chart shall be published at the end of the
selection year showing the candidates selected on open competition basis and selected on
reservation quota.

<!-- page 37 -->

37
Note._____
'Appointment chart' for the purpose of this rule shall mean the list showing
the details of candidates advised based on merit and another list of
candidates advised based on reservation showing their community, group
of communities, turn, vacancy details, such as non-joining duty, no
candidate available, temporarily passed over, etc.
15. (a) The integrated cycle combining the rotation in clause (c) of rule 14 and the
sub-rotation in sub- rule (2) of rule 17 shall be as specified in the Annexure to this Part.
Notwithstanding anything contained in any other provisions of these rules or in the
Special Rules if a suitable candidate is not available for selection from any particular
community or group of communities specified in the Annexure, such vacancy shall be kept
unfilled, notified separately for that community or group of communities for that selection
year and shall be filled by direct recruitment exclusively from among that community or
group of communities. If after re-notification, repeatedly for not less than two times, no
suitable candidate is available for selection from the respective community or group of
communities, the selection shall be made from available Other Backward Classes
candidates. In the absence of Other Backward Classes candidates, the selection shall be
made from available Scheduled Castes candidates and in their absence, the selection shall
be made from available Scheduled Tribes candidates.
One 'selection year' for the purpose of this rule shall be the
Explanation.____
period from the date on which the rank list of candidates comes
into force to the date on which it expires.
Note.___
All pending uncompensated turns of vacancies such as temporarily passed
over, no candidate available and non-joining duty as on the 2nd February,
2006, shall be compensated.

(b) If a suitable candidate is not available for selection from the group of communities
classified as 'Scheduled Castes' in the turn allotted from such group in the Annexure,the
said group shall be passed over and the post shall be filled up by a suitable candidate from
the group of communities classified "Scheduled Tribes" and vice-versa.
(c) The benefit of the turn forfeited to Scheduled Castes or Scheduled Tribes
communities by reason of it being passed over under sub-rule(b) shall be restored to it, at
the earliest possible opportunity, if a suitable candidate from that particular community or
group is available for selection by making adjustment against the claims of the Scheduled
Caste or Scheduled Tribe community that derived the extra benefit by reason of such
passing over.
(d) Reservation to a category of posts shall not exceed 50 % of the total number of
vacancies for which selection is resorted to in a selection year:
Provided that the 50 % ceiling to reservation specified above shall not apply to the
filling up of any number of reserved vacancies kept unfilled and notified separately as per
sub-rule (a) of Rule 15 to be filled exclusively by direct recruitment from among a
community or group of communities:
Provided further that such class of vacancies to be filled up in that year or in any
succeeding year or years shall not be considered together with the vacancies of the year in
which they are being filled up for determining the ceiling of 50 % of the total number of
vacancies of that year.

<!-- page 38 -->

38
16.

There shall be sub-rotation among major groups of Other Backward Classes.

17. (1) The grouping of Other Backward Classes for the above purpose shall be
as indicated below:-

1. Ezhavas, Thiyyas and Billavas
2. Muslims
3. Latin Catholics and Anglo Indians
4. Hindu Nadars
4A.(Nadars included in S.I. U.C.
5. Scheduled Caste Converts to Christianity
6. Viswakarmas
7. Dheevaras
8. Other Backward Classes put together i.e., communities other than
those mentioned in items 1 to 7 above included in the list of "Other
Backward Classes".
(2) (a) The 40% reservation allowed to Other Backward Classes shall be distributed
among the different groups of Backward Classes in the following proportion:(i) For direct recruitment to posts included in the Kerala Last Grade Service.
Out of every 40 appointments, 11 shall be given to Ezhavas, Thiyyas and Billavas, 10
to Muslims, 4 to Latin Catholics and Anglo Indians, 1 to Hindu Nadars and 2 to Nadars
included in S.I.U.C 2 to Scheduled Caste Converts to Christianity, 2 to Viswakarmas, 2 to
Dheevaras and 6 to Other Backward Classes put together.
(ii) For direct recruitment to posts other than those included in the Kerala Last
Grade Service.
Out of every 40 appointments, 14 shall be given to Ezhavas, Thiyyas and Billavas,
12 to Muslims, 4 to Latin Catholics and Anglo Indians, 1 to Hindu Nadars and 1 to
Nadars included in S.I.U.C., 1 to Scheduled Caste Converts to Christianity, 3 to
Viswakarmas, 1 to Dheevaras and 3 to Other Backward Classes put together.
(b) The following shall be the rotation by which posts reserved for Other Backward
Classes will be distributed among the various groups coming under the class:(i) For direct recruitment to posts included in the Kerala Last Grade Service,____
1. Ezhavas, Thiyyas and Billavas
2. Muslims
3. Latin Catholics and Anglo Indians
4. Other Backward Classes
5. Ezhavas, Thiyyas and Billavas
6. Muslims
7. Dheevaras
8. Viswakarmas
9. Latin Catholics and Anglo Indians
10. Muslims
11. Ezhavas, Thiyyas and Billavas
12. Other Backward Classes
13. Ezhavas, Thiyyas and Billavas
14. Muslims
15. Nadars included in S.I.U.C

<!-- page 39 -->

39
16. Other Backward Classes
17. Ezhavas, Thiyyas and Billavas
18. Muslims
19. Scheduled Caste Converts to Christianity
20. Other Backward Classes
21. Ezhavas, Thiyyas and Billavas
22. Muslims
23. Ezhavas, Thiyyas and Billavas
24. Hindu Nadars
25. Scheduled Caste Converts to Christianity
26. Muslims
27. Latin Catholics and Anglo-Indians
28. Other Backward Classes
29. Ezhavas, Thiyyas and Billavas
30. Muslims
31. Ezhavas, Thiyyas and Billavas
32. Nadars included in S.I.U.C
33. Ezhavas, Thiyyas and Billavas
34. Muslims
35. Dheevaras
36. Other Backwards Classes
37. Latin Catholics and Anglo-Indians
38. Muslims
39. Ezhavas, Thiyyas and Billavas
40. Viswakarmas
Explanation._____

The expression "Other Backward Classes" referred to in items 4,
12,16,20 28 and 36 shall mean Backward Classes referred to in item
8 under sub- rule (1) of this Rule.

(ii) For direct recruitment to posts other than those included in the Kerala Last Grade
Service.
1. Ezhavas, Thiyyas and Billavas
2. Muslims
3. Latin Catholics and Anglo Indians
4. Other Backward Classes
5. Ezhavas, Thiyyas and Billavas
6. Muslims
7. Ezhavas, Thiyyas and Billavas
8. Viswakarmas
9. Latin Catholics and Anglo Indians
10. Muslims
11. Ezhavas, Thiyyas and Billavas
12. Muslims
13. Ezhavas, Thiyyas and Billavas
14. Muslims
15. Nadars included in S.I.U.C
16. Other Backward Classes
17. Ezhavas, Thiyyas and Billavas
18. Muslims
19. Scheduled Caste Converts to Christianity
20. Dheevaras
21. Ezhavas, Thiyyas and Billavas
22. Muslims

<!-- page 40 -->

40
23. Ezhavas, Thiyyas and Billavas
24. Hindu Nadars
25. Ezhavas, Thiyyas and Billavas
26. Muslims
27. Latin Catholics and Anglo-Indians
28. Viswakarmas
29. Ezhavas, Thiyyas and Billavas
30. Muslims
31. Ezhavas, Thiyyas and Billavas
32. Muslims
33. Ezhavas, Thiyyas and Billavas
34. Muslims
35. Ezhavas, Thiyyas and Billavas
36. Other Backwards Classes
37. Latin Catholics and Anglo-Indians
38. Muslims
39. Ezhavas, Thiyyas and Billavas
40. Viswakarmas
Explanation._____

The expression "Other Backward Classes" referred to in items 4, 16
and 36 shall mean Backward Classes referred to in item 8 under subrule(1) of this Rule.

17 A. Special Recruitment from among the Scheduled Castes and Scheduled
Tribes._____ Notwithstanding anything contained in these rules or in the Special Rules, the

State Government may reserve a specified number of posts in any service, class, category
or grade to be filled by direct recruitment exclusively from among the members of
Scheduled Castes and Scheduled Tribes
This Rule shall be deemed to have come into force with effect from 25.11.1959.
17B. Notwithstanding anything contained in rule 10 (c) or in any Special Rules, the
age limit for Special Recruitment from among the Scheduled Castes and Scheduled Tribes
under rule 17A, to the posts in the various Departments shall be such, as may be fixed by
Government, either by executive order or by Special Rules from time to time.
17C. The candidate claiming the benefit of age relaxation/reservation in
appointments/special recruitments by virtue of being a member of the Back ward
Classes/Scheduled Castes/Scheduled Tribes as provided for in sub-rules (c), (d) and (dd)
of rule 10, rule 14, rule 17A and rule 17B ibid shall produce to the satisfaction of the
Kerala Public Service Commission, certificates/ relevant documents as required by them,
to prove the claim in the application and in any case, before the finalization of the ranked
list for the post concerned.
18. (a) Date of commencement of probation of persons first appointed
temporarily._____If a person, having been appointed temporarily under sub- rule (a) or sub-

rule (c) of rule 9 to a post borne on the cadre of any service, class or category otherwise
than in accordance with the rules governing appointment thereto, is subsequently
appointed to the service, class or category in accordance with the rules, he shall
commence his probation from the date of such subsequent appointment or from such
earlier date as the appointing authority may determine, without prejudice to seniority of
others

<!-- page 41 -->

41
(b) Service in a different service counting for probation._____ A probationer in a
service or class or category of a service shall be eligible to count for probation, his service,
if any, performed otherwise than in a substantive capacity on regular appointment to
another service in accordance with the rules if the normal method of recruitment to the
latter service is according to the rules, by transfer from the former service or the class or
category thereof, as the case may be or, if the duties and responsibilities attaching to the
latter service, or the class or category thereof have been declared by the State Government
to be of equal or greater importance than those attaching to the post from which he has
been transferred.
(c) Service in a higher category counting for probation.____ A probationer in any

category or a service or class of service shall be eligible to count for probation, his service,
if any, performed otherwise than in a substantive capacity on regular appointment to a
higher category of the same service or class of service, as the case may be.
Nothing contained in this sub- rule shall be construed as authorising the promotion
of a probationer in a category to a higher category in contravention of rule 28.
(d) Temporary service counting for probation.____A probationer in one service who

is appointed temporarily to another service, Subordinate or State, under sub-rule (a) or
sub- rule (c) of Rule 9 shall be entitled to count towards his probation in the former service
the period of duty performed by him in the latter service during which he would have held
a post in the former service but for such temporary appointment.
(e) Service on temporary promotion counting for probation.____ A probationer in

any category of a service who is promoted temporarily under the provisions of Rule 31 to a
higher category in the same service shall be entitled to count towards his probation, if any,
in the former category the period of duty performed by him in the latter category during
which he would have held a post in the former category but for such temporary promotion.

(f) A member of a service or class or category of a service deputed in public interest
to discharge the duties of another post shall be eligible to count the period of such
deputation for probation in the service or class or category of the service in which he was a
probationer at the time of his deputation or would have been a probationer but for his
deputation.
(g) A probationer who before completing probation in the service, class or category
to which he is first appointed proceeds on leave without allowance granted and availed of
as per Appendix XII A, Appendix XII B or Appendix XII C of Part I of the Kerala Services
Rules shall commence probation afresh on his return from such leave.
(h) A person who got appointment in one Department of a service from a common
selective list prepared by the Commission and thereafter discharged from that department
for want of vacancy and got reappointed on re-registering his name with the Public Service
Commission, shall be entitled to count his service in the former Department for probation
in the latter Department.
(i) An inter-departmental transferee shall have to undergo probation in the new
department in accordance with the Special Rules. In the case of inter-departmental
transfer to the services for which Special Rules have not been issued, the transferee shall
not be allowed to count his service in the former service or unit for the purposes of
probation in the new department and in such cases the inter-departmental transferee
shall be on probation for a total period of two years on duty in the new Department within
a continuous period of three years.

<!-- page 42 -->

42
19. Suspension, termination or extension of probation.____
(a) Where the
Special Rules of any service prescribe a period of probation for appointment as a full
member of the service or where such period of probation has been extended under
General Rule 21, the Appointing Authority may, at any time before the expiry of the
prescribed period of probation or the extended period of probation, as the case may be-

(i)

suspend the probation of a probationer and discharge him for want of vacancy,
or

(ii)

at its discretion, by order, either, terminate the probation of a probationer and
discharge him or in case the probation has not been extended under General
Rule 21 extend the period of his probation, after giving him a reasonable
opportunity of showing cause against the action proposed to be taken in regard
to him:

Provided that where a probationer has been given a reasonable opportunity of
showing cause against the imposition on him of any of the penalties specified in items (iv),
(vii), (viii) and (ix) of Rule 11 of the Kerala Civil Services (Classification, Control and
Appeal) Rules and at the conclusion of the disciplinary proceedings, a tentative conclusion
is arrived at to terminate his probation, a further opportunity of showing cause specifically
against termination of his probation need not be given to him.
Explanation.-

An opportunity to show cause may be given after the Appointing Authority
arrives at a provisional conclusion on the suitability or otherwise of the
probationer for full membership of the service, either by such authority
himself or by a subordinate authority who is superior in rank to the
probationer.

(b) (i) If within the period of probation a probationer fails to acquire the special
qualifications or to pass the special tests, if any, prescribed in the Special Rules, or to
acquire such other qualifications as may be declared by the State Government or by the
Appointing Authority with the approval of the State Government to be equivalent to the
said special qualifications or special tests, the Appointing Authority shall, by order,
discharge him unless the period of probation is extended under rule 21.
(ii) If within the period of probation prescribed in the Special Rules, for the service
or within the extended period of probation, as the case may be, the probationer has
appeared for any such tests or for any examinations in connection with the acquisition of
any such qualifications and the results of the tests or examinations for which he has so
appeared are not known before the expiry of such period, he shall continue to be on
probation until the publication of the results of the tests or examinations for which he has
appeared or the first of them in which he fails to pass, as the case may be.
In case the probationer fails to pass any of the tests or examinations for which he
has so appeared, the appointing authority shall by order discharge him.
Provided that where a probationer has appeared for any tests or examinations
within the period of probation prescribed in connection with the acquisition of any such
qualifications and the results of the tests or examinations for which he has appeared and
passed are known only after the expiry of the prescribed period of probation, he shall be
deemed to have satisfactorily completed his probation on the date on which he has
completed the prescribed period of probation.

<!-- page 43 -->

43
Note. ____

(1)
(2)

This amendment shall be deemed to have come into force
with effect from 17 th December 1958.
Cases already settled or disposed of prior to the issue of this
amendment shall not be reopened.

Probationer's suitability for full membership.____

(a) At the end of the
prescribed or extended period of probation, as the case may be, the Appointing Authority
shall consider the probationer's suitability for full membership of the service, class or
category for which he was selected:
20.

Provided that in case the probation was extended under rule 21, solely to enable
the probationer to acquire the special qualifications or to pass the prescribed tests, the
Appointing Authority shall consider the probationers suitability for full membership of the
service, class or category as soon as the probationer has acquired the special
qualifications or has passed the prescribed tests.
(b) If the Appointing Authority decides that a probationer is suitable for such
membership, it shall as soon as possible issue an order declaring the probationer to have
satisfactorily completed his probation. On the issue of such order, the probationer shall
be deemed to have satisfactorily completed his probation on the date of the expiry of the
prescribed or extended period of probation:
Provided that in cases to which the proviso to sub-rule (a) applies the probationer
shall be deemed to have satisfactorily completed his probation on the day following the last
date of the whole examination or test in which the probationer has acquired the special
qualification or has passed the prescribed tests by passing one more subjects, if such date
is earlier than the date of expiry of the extended period of probation.

Note._

Where a person can choose between two examinations or tests or corresponding
subjects/papers of two examinations or tests and where the two examinations or tests
conducted during the same period end on two different dates, the benefit of passing
the examination or test shall be deemed to have accrued on the day following the last
date of the whole examination or test which ends on the later date.

(c) If the Appointing Authority decides that the probationer is not suitable for such
membership, it shall unless the period of probation is extended under Rule 21 by order
discharge him after giving him a reasonable opportunity of showing cause against the
action proposed to be taken in regard to him:
Provided that where a probationer has been given a reasonable opportunity of showing
cause against the imposition on him of any of the penalties specified in items (iv), (vii), (viii)
and (ix) of Rule 11 of the Kerala Civil Services (Classification, Control and Appeal) Rules
and at the conclusion of the disciplinary proceedings, a tentative conclusion is arrived at
to discharge him a further opportunity of showing cause specifically against such
discharge need not be given to him.
Explanation I.__

The decision of the Appointing Authority that the probationer is not
suitable for full membership may be based also on his work and
conduct till the date of the decision inclusive of the period
subsequent to the prescribed or extended period of probation.

Explanation II.__

An opportunity to show cause may be given after the appointing

<!-- page 44 -->

44
authority arrives at a provisional conclusion on the suitability or
otherwise of the probationer for full membership of the service,
either by such authority himself or by a subordinate authority who
is superior in rank to the probationer.
20 A. Delay in the order of probation.- Any delay in the issue of an order
discharging a probationer under clause (ii) of sub- rule (a) of rule 19, or clause (i) or (ii) of
sub-rule (b) of that rule or sub-rule (c) of rule 20, shall not entitle him to be deemed to
have satisfactorily completed his probation.
21. Extension of probation.____ In the case of any probationer falling under sub-

rule (b) of rule 19 or sub-rule (c) of rule 20, the Appointing Authority may extend his
probation for a maximum period of one year to enable him to acquire special qualifications
or pass the prescribed tests, as the case may be, or to enable the appointing authority to
decide whether the probationer is suitable for full membership or not. Extension of
probation beyond one year may, however, be ordered by Government if found necessary.
In cases where the probation of a probationer is extended a condition shall, unless there
are special reasons to the contrary, be attached to the order of extension of probation that
the probationer's increment shall be stopped until he is declared to have satisfactorily
completed his probation. Such stoppage of increment shall not be treated as a penalty but
only as a condition of extension of probation and shall not have the effect of postponing
future increments after he has passed the prescribed tests or examinations or after he is
declared to have satisfactorily completed his probation.
22. Exercise of certain powers of Appointing Authority by higher authorities.____

The powers conferred on the Appointing Authority, other than the State Government, may
be exercised also by any higher authority to whom the appointing authority is
administratively subordinate whether directly or indirectly, in the following cases:____
(1) Termination of probation of a probationer under Rule 19 (a) (ii).
(2) Discharge of a probationer under Rule 20 (c).
(3) Extension of probation under rule 19 (a) (ii) or rule 21.
23. Appeal against discharge.____ (a) A probationer who is discharged under clause

(ii) of sub- rule (a) of rule 19 or under sub- rule (c) of rule 20 shall be entitled to appeal
against the order of discharge passed by the competent authority to the authority to which
and within the period of limitation within which an appeal would lie against an order of
dismissal passed by the competent authority against a full member of his service, class or
category, as the case may be:
Provided that in the case of a probationer in a State Service who is discharged from
service by an authority subordinate to the State Government, an appeal shall lie to the
State Government.
(b) The authority competent to entertain an appeal under sub- rule (a) may, either
of its own motion or otherwise, revise any order discharging a probationer under any of the
provisions referred to in the said sub-rule within one year of the date of such order.
(c) (i) When an order discharging a probationer is set aside on appeal under subrule (a) or on revision under sub- rule (b) and the probationer is restored to the service, the
period on and from the date of discharge to the date of such restoration may, with the
previous sanction of the State Government, be treated as on duty except for purposes of

<!-- page 45 -->

45
probation, the period of probation undergone by such probationer at the time of his
discharge shall, however, count towards the period of probation prescribed by the rules
applicable to him.
(ii) Such probationer may, during the period on and from the date of his discharge to
the date of his restoration, be paid such pay and allowances not exceeding the pay and
allowances to which he would have been entitled if he had not been discharged, as the
authority passing the orders under sub-rule (a) or (b) may, with the previous sanction of
the State Government, determine.
24. Appointment of full members.____ (a) Subject to the provisions of rule 8 an

approved probationer shall be appointed to be a full member of the service in the class or
category for which he was selected, at the earliest possible opportunity, in any substantive
vacancy which may exist or arise in the permanent cadre of such class or category and if
such vacancy existed from a date previous to the issue of the order of appointment, he
may be so appointed with retrospective effect from the date or, as the case may be, from
any subsequent date from which he was continuously on duty as a member of the service
in such class or category or in a higher class or category:
Provided that where more than one approved probationer is available for such
appointment as full member, the senior most approved probationer on the date of the
vacancy shall be appointed:
Provided further that notwithstanding anything contained in this sub-rule, a
candidate who is recruited direct to a post in any service, class, category or grade reserved
for members of Scheduled Castes and Scheduled Tribes shall, on satisfactory completion
of probation, be appointed to any substantive vacancy which may exist in the permanent
cadre of such service, class, category or grade, or if no such vacancy exists, to the first
such vacancy which may arise after the satisfactory completion of probation.
Explanation.____

For the purposes of this sub- rule an approved probationer on leave
shall be deemed to be on duty as a member of the service in the class
or category concerned if he would have been on duty in such class or
category or in a higher class or category but for his absence on leave.

(b) Where appointment to any service, class or category is according to rules
normally both by direct recruitment and by transfer, vacancies against which persons
have been recruited direct shall be regarded as a distinct group, while all other vacancies
shall be regarded as another distinct group, and appointment of full members in
accordance with sub- rule (a) shall be made separately in each of these groups.
25.
Appointment as full member, discharge and re-appointment of members
who are not probationers or approved probationers.____ In regard to persons appointed to

any class or category of a service by promotion in respect of whom the Special Rules of the
service do not prescribe a period of probation in the class or category to which they have
been promoted, rule 6,7 and 24 of this Part shall be construed as if 'Probation' and
'probationer' or 'approved probationer' meant 'officiating service' and 'person officiating'
respectively.
26.

Membership of more than one service.____ No person shall at the same time

be a full member of more than one service.
A probationer, approved probationer or full member of one service who is appointed
to be a full member of another service shall cease to be member of the former service.

<!-- page 46 -->

46
27.

Seniority.____ (a) Seniority of a person in a service, class, category or grade

shall, unless he has been reduced to a lower rank as punishment, be determined by the
date of the order of his first appointment to such service, class, category or grade.
Explanation.____
For the purposes of this sub-rule, "appointment" shall not include
appointment under rule 9 or appointment by promotion under Rule
31.
This amendment shall be deemed to have come into force with effect on and from
the 17 th December, 1958, but shall not affect the seniority of any member of a service
settled prior to the date of publication of this amendment in the Gazette:
Provided that the seniority of persons on mutual or inter-unit or interdepartmental transfer from one Unit to another within the same Department or from one
Department to another, as the case may be, on requests from such persons shall be
determined with reference to the dates of their joining duty in the new Unit or Department.
In the case of more than one person joining duty in the same grade in the same Unit or
Department on the same date, seniority shall be determined, _____
(a)
(b)

if the persons who join duty belong to different units or different departments,
with reference to their age, the older being considered as senior, and
if the persons who join duty belong to the same category of post in the same
department, in accordance with their seniority in the Unit or Department from
which they were transferred

Note.____

(i)
(ii)

This amendment
shall be deemed to have come into force with
effect from 28-12-1960.
Cases already settled or disposed of prior to the issue of this amendment
shall not be re-opened:

Provided further that the seniority of persons advised for appointment to the same
category of post in a Department on the same date by different District Offices/ District
Units of the Public Service Commission and the seniority of persons advised for
appointment to different posts which constituted feeder categories of higher posts in a
Department on the same date by the Public Service Commission shall be decided as
follows:(i)

When not more than one person is advised for appointment from each
District, on the basis of their age, the older being declared senior to the
younger.

(ii)

When more than one person is advised for appointment the persons
having the same serial number in the various advice lists shall be grouped
together separately and the inter-se- seniority in each group shall be fixed
on the basis of their age, the older being declared senior to the younger.

Note.__ While determining seniority under this proviso, if the date of birth of two or more
persons happens to be the same, their seniority shall be fixed on the basis of the
alphabetical order of their names and if the date of birth and the names of two or
more persons happen to be the same, their seniority shall be fixed on the basis of the
alphabetical order of the Districts concerned as below:-

(1) Alappuzha
(2) Ernakulam

(8) Kozhikode
(9) Malappuram

<!-- page 47 -->

47
(3) Idukki
(4) Kannur
(5) Kasaragode
(6) Kollam
(7) Kottayam

(10) Palakkad
(11) Pathanamthitta
(12) Thiruvananthapuram
(13) Thrissur
(14) Wayanad

Provided also that the seniority of persons advised for appointment to a category of
post in a Department, where the methods of appointment to that post are by promotion,
by transfer and by direct recruitment in a fixed ratio or percentage, shall be determined as
illustrated below:Where the first vacancy in a category is for appointment by promotion or transfer
and the second vacancy is for appointment by direct recruitment and when the first two
vacancies arise in that category a departmental hand shall be appointed regularly by
promotion or transfer, as the case may be, in the first vacancy and in the absence of a
direct recruit reporting for duty in the second vacancy a departmental hand shall be
appointed temporarily by promotion or transfer, as the case may be, in that vacancy. In
case a direct recruit does not report for duty till a third vacancy arises in the Department,
the appointment of person temporarily by promotion or transfer in the second vacancy
shall be regularized from the date of occurrence of the third vacancy. Similarly if two more
vacancies arise in that cadre (totally five) the departmental hands are entitled for three
vacancies and hence the promotion or transfer of the third man shall be regularized from
the date of occurrence of the fifth vacancy. The direct recruit shall be entitled for rank and
seniority from the date of his first effective advice:
Provided also that the seniority of a person advised by the District Office of the
Public Service Commission for appointment in the vacancy in the Headquarters, without
obtaining his willingness and transferred after such appointment to the district of his
choice without insisting on the time limit of five years, shall be determined with reference
to the date of his original advice by the District Office of the Public Service Commission.
Note.____

The above proviso shall not apply to inter-unit or inter-departmental transfers.

(b) The Appointing Authority shall, at the time of passing an order appointing two or
more persons simultaneously to a service, fix the order of preference among them; and
seniority shall be determined in accordance with it:
Provided that nothing contained in sub-rules (a) and (b) above shall be deemed to
have superseded the orders of the Travancore-Cochin Government in R. Dis No.
8207/50/CS dated 7th May 1951 as subsequently clarified in respect of any person who
was a member of any service on the date of coming into force of these Rules:
Provided further that the above said order of the Travancore-Cochin Government
as subsequently clarified shall also be applicable to the persons appointed in the State of
Kerala before the coming into force of these Rules.
This amendment shall be deemed to have come into force with effect on and from
17-12-1958:
Provided also that persons referred to in the foregoing provisos shall be entitled to
restoration of seniority in accordance with the orders of the Travancore-Cochin
Government referred to therein as subsequently clarified over those who have been
appointed in the State of Kerala on or after the 17th day of December, 1958.

<!-- page 48 -->

48
The amendment hereby made shall be deemed to have come into force with effect
on and from the 17 th December 1958.
(c)
Notwithstanding anything contained in clauses (a) and (b) above, the
seniority of a person appointed to a class, category or grade in a service on the advice of
the Commission shall, unless he has been reduced to a lower rank as punishment, be
determined by the date of first effective advice made for his appointment to such class,
category or grade and when two or more persons are included in the same list of
candidates advised, their relatives seniority shall be fixed according to the order in which
their names are arranged in the advice list:
Provided that the seniority of candidates who have been granted extension of time
to join duty beyond three months from the date of the appointment order, except those
who are undergoing courses of study or training which are prescribed as essential
qualification for the post to which they are advised for appointment, shall be determined
by the date of their joining duty:
Provided further that the seniority of the persons appointed,(a) directly under the Compassionate Employment Scheme,
(b) through regularization of temporary or provisional hands, such as;
(i)

(ii)
(iii)

persons belonging to Scheduled Caste/Scheduled Tribes;
physically handicapped persons; and
others,

(c)
to the 3% of Class III and IV posts reserved for appointment by
physically handicapped persons through any other source than the Kerala
Public Service Commission.
(d)

to the sports quota.

(e)
through any other source other than recruitment through Kerala Public
Service Commission shall be determined as per sub-rule (a) and (b) as above. As between
persons appointed to the same category by the appointing Authority, on the advice of the
Public Service Commission under the normal method and persons appointed by any one
or more of the methods shown above, the former shall be treated as senior to the latter
subject to the provisions in the first proviso, if the date of effective advice of the
Commission for the appointment happens to be the same date or any other date earlier
than the date of appointment of the latter. The seniority of persons appointed, otherwise
than through the Kerala Public Service Commission, directly under any one of the
methods mentioned above, to the same category, by the same Appointment Authority, but
on different dates in a Unit/Department, shall be reckoned with reference to the date of
former appointment order issued by the concerned Appointing Authority. If more than one
person are allowed to be appointed directly by means of Government Order otherwise than
through Kerala Public Service Commission, under any one or more of the methods
mentioned above and are appointed to the same category, on the same date by the same
Appointing Authority in a Unit/Department, than their seniority shall be reckoned with
reference to their age, the older being reckoned senior to the younger. While fixing
seniority by applying the above principle, if the dates of birth of more than one person
happen to be the same, their seniority shall be fixed on the basis of the alphabetical order
of their names. When issuing the formal appointment orders in such cases, the Appointing
Authority shall determine the seniority and the order of precedence of the candidates to

<!-- page 49 -->

49
be appointed, using the aforementioned criteria and the same shall be specified in the
appointement orders.
Provided also that where the date of effective advice in respect of a person
appointed otherwise than in pursuance of rule 17A and a person appointed in pursuance
of rule 17A is the same, the former shall subject to the provisions in the first proviso be
treated as senior to the latter:
Provided also that the seniority of a person appointed in one service from a common
selective list, prepared by the Commission and thereafter discharged from service for want
of vacancy and got reappointed in another service or another Department/Institution on
further advice of the Commission, shall be determined by the date of first effective advice:
Provided also that in case where the date of joining duty of a person appointed on
mutual or inter-unit of inter-departmental transfer to a post on request and the date of
first effective advice of a person appointed to the same category of post on the advice of the
Commission are the same, the latter person shall be deemed senior to the former subject
to the provisions in the first proviso:
Provided also that the seniority of,____
(i)

(ii)
(iii)

persons advised by the Public Service Commission for appointment as Assistant
Surgeons other than Dental Surgeons in the Health Services Department after 145-1963 and before the issue of G.O.(P) No. 255/Public (SS) Department dated 2-31965;
persons advised for appointment as Dental Surgeons, Graduate Nurses and other
Para- Medical Personnel after 14-5-1963 and before 31-3-1965; and
persons advised for appointment as Tutors and Demonstrators in the Medical
Colleges after 7-12-1963 and before the issue of G.O. (P) 255/Public (SS)
Department dated 2-3-1965 excepting those advised in the specialties of
Anesthesiology and Radiology in the context of the National Emergency,

shall notwithstanding anything contained in any Judgment, Decree or Order of any Court,
be determined as follows.(a) Persons selected by the concerned Defence Selection Board to serve in the
Defence Force of India from among those candidates advised by the Public Service
commission from a particular advice list shall be placed in list 'A' and those not selected in
list 'B'. The candidates included in list 'A' shall be senior to those included in list 'B'. The
ranking of the candidates in list 'A' and list 'B' shall be done in accordance with the interse-seniority of the candidates as fixed in the order in which their names are arranged in
the relevant advice letters of the Commission and in accordance with the date of earliest
effective advice;
(b) Women candidates advised for appointment to the posts of Assistant Surgeons,
Tutors and Demonstrators from the ranked lists prepared after 4-8-1964 and who did not
express their willingness to serve in the Defence Forces shall be placed in list 'C'. The
candidates included in list 'C' shall be junior to those in list 'B'. The inter-se-seniority of
persons included in list 'C' shall be fixed according to the order in which their names are
arranged in the relevant advice letters of the Commission and in accordance with the date
of earliest effective advice.
Provided further that approved probationers/permanent officers who avail leave
without allowance for taking up employment abroad or within India or for study purpose
or for joining spouse abroad or within India as per the provisions in Appendix XII A,

<!-- page 50 -->

50
Appendix XII B, Appendix XII C respectively of Part I, of Kerala Service Rules, shall lose
their seniority in the service, class, category or grade with reference to their juniors in the
service, class, category or grade who might get promoted before they re-join duty.
Note.____

The date of effective advice in this Rule means the date of the letter of the
Commission on the basis of which the candidate was appointed.

27 A.
Notwithstanding anything contained in rule 27, in the case of a person
appointed as Lower Division Clerk or Lower Division Typist in a service prior to the 19th
October, 1962 and transferred thereafter from the Unit of the Department in which he was
appointed to another Unit of the same department, seniority in the Unit of the Department
to which he was transferred shall be determined with reference to the date of his
appointment in the Unit of the Department from which he was transferred subject,
however, to the condition that the seniority so determined shall not adversely affect the
seniority of any person who has been promoted on a regular basis in the unit to which he
was transferred prior to the date of his transfer.
27 B. In case of disputes regarding seniority and matters connected with it by
reason of any order of Government or any order of an authority subordinate to
Government, representations for reconsideration of such order shall be submitted to
Government by the aggrieved person within a period of six months from the date of receipt
of the order, or the date of publication of the order in the Kerala Gazette, whichever is
later.

28.
(a) Promotion.____(i) Except in the case of appointment to the posts of Heads
of Department no member of a service or class of a service shall be eligible for promotion
from the category in which he was appointed to the service unless he has satisfactorily
completed his probation in that category:

Provided that a probationer in a class, category or grade shall not be superseded for
promotion to a higher class, category or grade by his junior, if the vacancy in the higher
class, category or grade arises within the period specified in the Special Rules for
completion of probation in the class, category or grade in which he is probationer and if he
has passed the test or tests prescribed for successful completion of probation and is
otherwise eligible and suitable for such promotion; but his promotion shall be subject to
the condition that he satisfactorily completes the probation in the class, category or grade
from which he was promoted within the period prescribed thereof, and for this purpose the
period of service put in by him in the higher class, category or grade shall be reckoned
towards probation in the class, category or grade from which he was promoted and also in
the class, category or grade to which he was promoted:
Provided further that if a probationer promoted in pursuance of the above proviso
fails to complete his probation in the class, category or grade from which he was promoted
within the period prescribed thereof, his probation in the higher class, category or grade
shall be terminated and he shall be reverted to the class, category or grade from which he
was promoted, and any subsequent promotion of such person to the higher class, category
or grade shall not also entitle such person to claim seniority in the higher class, category
or grade by reason only of his previous promotion in pursuance of the preceding proviso
and he shall commence probation afresh in that class, category or grade from the date of
such subsequent promotion.

<!-- page 51 -->

51
(ii) Where the Special Rules for a service provide for appointment by promotion to
any class or category from a specified class or category of such service, no member shall
be eligible for such appointment unless he is a full member or an approved probationer in
the class or category so specified:
Provided that if he is the holder of a post in any service for which no probation has
been prescribed, he shall not be eligible for promotion unless he has put in satisfactory
service in that post for a period of one year on duty within a continuous period of two
years.
(iii)
Notwithstanding anything contained in these Rules or in the Special
Rules/Executive Orders, the period of probation for persons appointed by direct
recruitment or recruitment by transfer through Public Service Commission shall be two
years on duty within a continuous period of three years and for persons appointed in a
post or category from another post or category in the same service or appointed by transfer
from one service to another within the same Department or in another Department (where
direct recruitment is not resorted to) shall be one year on duty within a continuous period
of two years.
1[Provided that the period of probation for persons who were appointed on or after
the 1st April, 2010 to selection posts in the State Services, by promotion or by transfer
within the Department where direct recruitment is not one of the methods of appointments
as per the Special rules, shall be six months on duty within a continuous period of one
year.]

(b) (i) Promotion and appointment by transfer according to merit and ability.____

Appointments to posts in a selection category or grade in a service or class, other than
Heads of Departments which shall be made under Rule 28A, shall be made from a select
list prepared from among the members eligible for appointment to such category or grade
in accordance with these rules and the Special Rules, on the basis of merit and ability,
seniority being considered only when merit and ability are approximately equal. The select
list shall be prepared in the manner indicated herein.
(1) Selection of candidates for appointment to selection categories or grades shall be
made by Departmental Promotion Committees constituted for each Department.
(2) A Departmental Promotion Committee shall consist of a member of the Public
Service Commission and,__
(a) In the case of a Departmental Promotion Committee for selection to a post other
than the lowest post in the State Service, the Appointing Authority or in case the
Appointing Authority is the Government, a nominee of the Government, and the Head of
the Department concerned:
(b) In the case of a Departmental Promotion Committee for selection to the lowest
post in the State Service, the Appointing Authority for the post and a nominee of the
Government not below the rank of a Deputy Secretary who is in charge of the
administration of the Department concerned.
(3) The member of the Public Service Commission shall be the Chairman of the
Departmental Promotion Committee and the authority to initiate action and to function as
Convener of the Committee shall be the appointing authority.2

1

Proviso inserted by G.O. (P) No.7/2013/P&ARD dated 19th March 2013 published as S.R.O. No.7/2013/P&ARD
in Kerala Gazette Extraordinary No. 1068 dated 13th April, 2013.

<!-- page 52 -->

52
(4) The Committee shall meet periodically to prepare select lists,in the order of
merit, of the Officers selected for appointment. The Committee may also hold ad hoc
meetings for the purpose of making selections to particular vacancies whenever occasion
arises. The criterion for assessment of merit shall be the confidential reports of the
officers. The confidential reports of the officers for at least the preceding three years shall
be made available to the Committee for this purpose. Where remediable adverse remarks
recorded in the confidential report of a Government Servant are not communicated to the
officer concerned, such remarks shall be ignored by the Departmental Promotion
Committee while considering his case for promotion. The following procedure shall be
adopted by the Departmental Promotion Committee for the preparation of select lists:____
(a) Select lists shall be prepared during a calendar year for the vacancies estimated
to arise in the next calendar year;
(b) During the first six months of the year action shall be taken to make all the
Confidential Reports up-to-date, adverse remarks communicated, and orders for
expunging such remarks issued wherever necessary. Simultaneously seniority lists shall
also be made up-to-date and probation of officers in the field of choice declared.
Confidential Reports and seniority lists shall be made up to date before 30th June;
(c) *** *** *** *** *** ***
(d) During September/October the Departmental Promotion Committees will be
convened and select lists prepared which will be notified before 30th November and in any
case not later than December 31. If any officer becomes qualified after the preparation of
the select list, but, before the occurrence of the vacancy, the Departmental Promotion
Committee shall meet subsequently and his name shall be considered for inclusion in the
select list;
(e) At the time of change over from the existing system the number of vacancies for
the current year and the next year shall be considered together.
(4a)
Where confidential reports for the three years mentioned in sub-clause (4)
are not available in respect of an Officer who was under suspension but has been
reinstated or who was or is on long leave, the suitability of the officer shall be assessed,__
(i) in the case of an Officer who has been reinstated after suspension fully
exonerating him of the charges or in the case of an officer who was or is on long leave, on
the basis of the confidential reports for a period of three years (excluding the period during
which the officer was under suspension or on long leave or is on long leave, as the case
may be ) preceding the date of the meeting and if the Confidential Reports for the said
period are not available, on the basis of the Confidential Report for the one year
immediately after reinstatement or, as the case may be, immediately after rejoining duty
after leave;
(ii) in the case of an Officer who has been reinstated after suspension imposing a
penalty, on the basis of the confidential reports for the period after reinstatement (which
shall not be less than one year.)
(4b) where confidential reports for the three years mentioned in sub-clause(4) are
not available in respect of an officer for no fault of his up to a period of six months, the
Departmental promotion Committee shall consider, ignoring the non-availability of the
report for the said period, the suitability of the officer based on the available report or by
getting special confidential report from the Superior Officer/Higher Authority under whom
the Officer is working at the time of consideration of his case.

<!-- page 53 -->

53
(5) On matters in respect of which there is difference of opinion, the views of the
majority of the members of the Committee shall prevail. Provided that where the Member
of the Public Service Commission requires that the Public Service Commission shall be
consulted before final recommendation is made, such consultation shall be made.
(6) The Departmental Promotion Committee shall first decide the field of choice, that
is, the number of eligible officers awaiting appointment who should be considered for
inclusion in the "Select list". Provided, however, that an officer of outstanding merit, and
his seniors, if any, in the category or grade may be included in the list of eligibles even if
he or such seniors are outside the normal field of choice.
Note.-

The field of choice shall as far as possible be thrice and at least twice the number of
vacancies expected within a year plus the number of the superseded officers of the
previous year. For example, if there are two anticipated vacancies and the number of
superseded officers of the previous years is 4, the panel for the field of choice shall
normally contain 10 names (6+4) or at least 8 (4+4).

(7) The "Select List" shall be prepared from among the eligible officers on the basis
of merit and ability, seniority being a consideration only when all the qualifications are
equal. The number of names to be included in the "Select List" shall be the same as the
estimated number of vacancies likely to arise during the next year. Supplemental lists may
be prepared in case the lists already prepared get exhausted before the close of the year to
which they relate so as to obviate the necessity for convening meetings of Departmental
Promotion Committees at short notice or keeping of posts unfilled and thereby causing
administrative inconvenience. Persons selected for inclusion in the Select List shall be
ranked in the Select List according to their seniority in the feeder category. When the
Special Rules provide for a definite ratio or order of preference from the feeder categories,
persons from each feeder category shall be included in separate select lists and
appointment shall be made in accordance with the ratio or order of preference prescribed
by such Special Rules for each feeder category.
Note.- (i)

Officers under suspension and officers against whom criminal proceedings are
pending in a Sessions Court or in any other higher Court for grave offences
like murder, dacoity, etc; and Officers against whom departmental
proceedings are taken for the imposition of a major penalty under the
disciplinary rules applicable to them should not be included in the select list.
But the suitability of such an Officer for promotion should be assessed at the
relevant time by the Departmental Promotion Committee and a finding
reached whether, if the Officer had not been suspended or the criminal
proceedings/ departmental proceedings had not been pending against him,
he would have been recommended/selected for promotion. Where a select
list is prepared the Departmental Promotion Committee shall also make a
finding as to what the position of the Officer in that list would have been but
for the suspension or the criminal proceedings/ departmental proceedings
against him. "The findings as to the suitability and the place in the select list
of the officer should be recorded separately and attached to the proceedings.
The proceedings of the Departmental Promotion Committee need only
contain a note. “The findings are recorded in the attached sheet of paper".
The authority competent to fill the vacancy should be separately advised to
fill the vacancy only on a temporary basis. Officers against whom vigilance or
departmental proceedings are taken after the charges have prima facie been
established in a preliminary enquiry should not be included in the select list.
But, the cases of such Officers should also be assessed. The question of
including them in the select list shall be considered when the result of the

<!-- page 54 -->

54
enquiry is known. However Officers against whom departmental proceedings
are taken for the imposition of a minor penalty may be included in the select
list provisionally if they are found suitable but for the pendency of
disciplinary proceedings initiated against them.
(ii)

(iii)

The vacancy that would have gone to the Officer but for his suspension or
the criminal proceedings/departmental proceedings against him for the
imposition of a major penalty should be filled only on a temporary basis by
the next person in the approved list. If the Officer concerned is
completely exonerated, he will be promoted thereafter to the post filled on
a temporary basis, the arrangements made previously being reversed. If
the exoneration is not complete, the Departmental Promotion Committee
may decide each case on its merits. Where, however, the post which
would have gone to the Officer but for his suspension or the criminal
proceedings/ departmental proceedings against him, ceases to exist
before the conclusion of the disciplinary proceedings, he will be promoted
to the first vacancy that may be available in future if he is found fit for
promotion at that time.
If the officers against whom departmental
proceedings are taken for imposition of a minor penalty and who have
been provisionally included in the select list are fully exonerated of the
charges, their cases for promotion on the basis of such inclusion in the
select list shall be considered. If the Officers are not fully exonerated of
the charges, the Departmental Promotion Committee may decide each
case on its own merit.

Officers whose names are included in the select list but who are subsequently
placed under suspension or against whom criminal proceedings are taken in a
Sessions Court or in any other higher Court for grave offences and officers
against whom departmental proceedings are taken for the imposition of a major
penalty under the disciplinary rules applicable to them, shall not be promoted on
the basis of their inclusion in the select list until they are fully exonerated of the
charges against them. If the officer is fully exonerated of the charges, he shall
be promoted on the basis of his position in the select list to the post which has
been filled on a temporary basis pending disposal of the charges against him. If
the Officer is not fully exonerated, the Departmental Promotion Committee
may consider each case on its own merit. Officers whose names are
included in the select list but against whom departmental proceedings for
imposing a minor penalty are initiated subsequently, may be promoted on a
temporary basis pending disposal of the proceedings against them. If the
Officer
is fully exonerated of the charges the temporary promotion shall be treated as
regular promotion and if the Officer is not fully exonerated of the charges, his
case may be considered by the Departmental Promotion Committee on
merits.

(iii a) The inclusion of the names of Officers in the select list after decision by the
Departmental Promotion Committee on their cases on merits under Note (ii) or Note
(iii) and their consequent promotion shall be subject to further reassessment by the
Departmental Promotion Committee on the basis of orders passed in appeal or
review. If the Departmental Promotion Committee revises the select list on further
reassessment and if by that time the Officer has been promoted on the basis of his
inclusion in the earlier select list, the orders promoting the Officer shall be revised
in accordance with the revised select list. In such cases the appointment as per
the revised order only shall be considered as regular appointment. However, this
revision of order of appointment shall be made only if the orders in appeal or review
are passed within a period of one year from the date of order of promotion of the

<!-- page 55 -->

55
Officer. In the cases of those who are not included in the select list prepared after
reassessment under Notes (ii) or (iii) above, but who are fully exonerated of the
charges on appeal or review passed within a period of two years from the date of
publication of the select list, a further reassessment shall be made and the select
list as well as appointments ordered on the basis of it shall be revised including
such officers also in the select list if they are otherwise eligible for inclusion therein.
(iv)

Where while preparing a select list an officer has been superseded on account of his
confidential report for the one year referred to in sub- clause (4a) not being available
due to non-completion of the said period of one year, the select list shall be treated
as provisional to the extent it relates to the officers junior to the officer so
superseded, and as soon as the confidential reports in respect of such officer
relating to the said one year become available, the departmental promotion
committee shall review the list and make it absolute, after considering the claims of
the officer with reference to the confidential reports for the said one year.

(v)

A censure under Rule 11 (I) (i) of the Kerala Civil Services (Classification, Control
and Appeal) Rules, 1960 or a warning awarded or proposed to be awarded to an
Officer need not be taken into account while considering his case for promotion
under Note (ii), (iii) and (iii a) above.

(vi)

When there are more than one feeder category carrying different scales of pay, they
shall be shown in separate lists and persons in a lower scale of pay shall be
appointed only after appointing all persons on a higher scale of pay, unless the
Special Rules prescribe a ratio or any special order of preference for each feeder
category.

(vii)

When the posts in the feeder categories are on the same scale of pay and there is no
fixed ratio, appointment shall be made in accordance with their seniority in the
feeder category, the seniority being determined by the date of the order of first
appointment to that particular category, class or grade.

(8)(a) The select list prepared by the Department Promotion Committee in the
manner referred to above shall be published by the Convener of the Committee after
approval by the Government. Normally no revision of such select list shall be made under
Rule 29 on the basis of re-evaluation of the confidential reports. However, if any officer
who has been superseded and whose name has not been included in the list makes, within
one month from the date of publication of the list, a written representation to the convener
of the Departmental Promotion Committee requesting a revision of the list, the Committee
shall consider the representation.
After going through the representation, if the
Committee feels that some clarification should be obtained from the superseded officer by
personal hearing, if may do so and on the basis of such representation and personal
hearing if it is of the view that the list already prepared should be revised, it may make a
recommendation to the effect. The list shall then be revised accordingly and published by
the Convener after approval by the Government.
Note.--Promotions from the first list published by the Departmental Promotion
Committee shall be provisional and the list will be subject to revision, if,
after following the procedure, it is found that the list requires revision.

(b)
Wherever Government consider that there are exceptional circumstances
which warrant a departure from the advice of the Departmental Promotion Committee in
the public interest, the Departmental Promotion Committee shall be given a fresh
opportunity to consider the proposals of the Government to revise the select list. If on
receipt of the recommendation of the Departmental Promotion Committee, Government

<!-- page 56 -->

56
still feel that there are exceptional circumstances which warrant a departure from the
advice of the Departmental Promotion Committee in the public interest, they may take a
decision accordingly. In that case it will be open to the Public Service Commission to
include the matter in the Annual Report:
Provided that the power under this paragraph shall not be exercised after the expiry
of one year from the date on which the select list was prepared by the Departmental
Promotion Committee.
(9)
The "Select List" shall be reviewed annually and it shall remain in force until
it is revised. Names of those officers who have already been appointed shall be removed
from the list and the rest of the names along with those officers who may now be included
in the field of choice, shall be considered for the "Select List" for the subsequent period. A
person included in an earlier select list, shall, however, be ranked above a person
considered for a subsequent list, unless his conduct and work subsequent to such
inclusion renders it necessary that he should be placed lower in the list or his name my be
omitted from the list if there is definite deterioration in the work and conduct of the Officer
subsequent to his inclusion in the select list for the previous year, as the case may be.
(10)
The claims of a person who qualifies himself for a post, after the select list in
respect of that post has been prepared but before the date of occurrence of the vacancy in
the higher post shall not be over looked.
(11)
The select list shall be reviewed and revised for the purpose of sub-clause
(10) in cases where the acquisition of an extra qualification or the gaining of a prescribed
period of experience is insisted on as conditions precedent to the selection to the higher
post. In such cases the following procedure shall be followed:____
The Convener of the Departmental Promotion Committee concerned should bring to
the specific notice of the Committee the case of all senior hands who are being overlooked
in drawing up the select list for want of qualification or experience and who are likely to
acquire that qualification or experience during the pendency of the list. The select list
drawn up at the meeting shall be treated as provisional to the extent to which it relates to
the junior hands included in the select list whose seniors are likely to become fully
qualified during the pendency of the list.
When such senior hands acquire the
qualification and/or experience which would make them eligible for appointment, the
Convener shall take early steps for the convening of an ad hoc meeting of the
Departmental Promotion Committee and after considering the claims of such persons,
revise, if necessary, the provisional portion of the select list. The provisional portion of the
select list, if revised, shall be made absolute following the procedure laid down in subclause (8) above and the process repeated wherever necessary.
Note.- (i)

As a person included in the earlier select list shall be ranked above a person
considered for a subsequent list, unless his work and conduct subsequent to such
inclusion renders it necessary that he should be placed lower in the list the
calculation of anticipated vacancies for purpose of preparing annual or
supplemental select lists shall be done as accurately as possible.

(ii) Claims of persons previously
whenever new lists are prepared.

omitted

from

the

list

shall

be

considered

(12) The recommendations made by the Departmental Promotion Committees shall be
treated as recommendations having the approval of the Public Service Commission, and
the convention regarding acceptance of the advice of the Commission shall apply to them.
In cases where the Commission has been consulted, the convention regarding consultation

<!-- page 57 -->

57
with the Commission shall similarly apply to the final recommendations made by the
Commission.
(13) Candidates belonging to Scheduled Castes and Scheduled Tribes shall not be
superseded for appointment to Selection categories or grades by the application of too rigid
a standard of suitability. The Departmental Promotion Committees may consider the case
of such candidates sympathetically by relaxing the standard of suitability where possible,
and only the claims of those whom the committee considers unsuitable even by the
relaxed standards should be superseded for appointment to such selection categories or
grades.
(14) Notwithstanding anything contained under this rule, the Government may by
order effect promotion/appointments by transfer notionally without monetary benefit of
pay and allowances but with consequential pensionary benefits, to a pensioner without
having to follow the procedures such as preparation, publication and review of select list
by convening the Departmental Promotion Committee, if it is found later on after his
retirement that he would have become eligible at any time during the course of his service
for being promoted or appointed to such posts, categories or grades in that service had
due procedure according to the rule existing at that time or made applicable thereafter
been followed at the appropriate time.
(iA) Preparation of select list subsequent to the occurrence of vacancy.- When a
select list is prepared subsequent to the occurrence of a vacancy, no person who was not
qualified for inclusion in the select list at the time of occurrence of the vacancy shall be
included in the select list for appointment against that vacancy.

Note.-

If there are no qualified persons for promotion to a post on the date of occurrence of
the vacancy, the person who gets qualified first thereafter, shall be considered for
promotion to that post:

Provided that where the Special Rules in respect of the post provide that direct
recruitment shall be resorted to in the absence of qualified candidates for promotion on the
date of occurrence of the vacancy, recruitment to the post shall be made accordingly.
(ii) Promotion and appointment by transfer to higher posts according to
seniority:- All other promotions or appointments by transfer to higher posts shall, subject

to the provisions of these rules and the special rules, be made in accordance with seniority
subject to the person being considered suitable for the post. Punishments other than
censure awarded within a period of three years immediately preceding such promotion or
appointment by transfer shall be taken into account in determining the suitability of a
person for promotion or appointment by transfer.
Note.-

(i)
when there are more than one feeder category carrying different scales of
pay, persons in lower scale of pay shall be appointed only after appointing
persons in the higher scale of pay unless the Special Rules provide a ratio or
any special preference for each feeder category.
(ii)
When the post in the feeder category has the same scale of pay and the
Special Rules prescribe no fixed ratio or preference, appointment shall be
made in accordance with the seniority in the feeder category, the same being
determined in the manner as provided in the first proviso to clause (a) of rule
27 of the General Rules. If the length of service or seniority of persons in the
feeder categories are the same, the person senior in age may be given
preference over the other.

<!-- page 58 -->

58
(bb) Promotion which depends upon the passing of any examination.- Promotion
in a service or class which depends upon the passing of any examination (General or
Departmental) shall ordinarily be made with reference to the conditions existing at the
time of occurrence of the vacancies and not with reference to those at the time when the
question of promotions is taken up.

(bbb) Where a pass in any examination or test confers on a person the title to any
right, benefit or concession, such title to the right, benefit or concession shall be deemed
to have accrued-

(a) in the case of a person who has passed such examination or test before the
14th August, 1971, on the day following the last day of such examination or test in
the subject or subjects; and
(b) in the case of a person who has passed such examination or test on or after 14th
August 1971, on the day following the last day of the whole examination or test in
which he has successfully completed the examination or test by passing one or
more subjects.
Explanation.- (1) The principles in this sub-rule shall apply for the drawal of increment
and for promotion not involving change of duties against vacancies
remaining unfilled for want of test qualified persons;
(2)

Where a person can choose between two examinations or tests or
corresponding subjects or papers of two examinations or tests and
where the two examinations or tests conducted during the same
period end on two different dates, the title to the right, benefit or
concession conferred by the passing of the examination or test
shall be deemed to have accrued on the day following the last date
of the whole of the examination or test which ends on the latter
date;

(3)

The expression "the last day of such examination or test in the
subject or subjects " occurring in clause (a) of this sub- rule shall
mean the last day on which according to the schedule of the
examination or test first published by the Kerala Public Service
Commission, such examination or test in the subject or subjects
would have been conducted if the examination or test in any of the
subjects had not been postponed to a latter date;

(4)

The expression "the last day of the whole examination or test"
occurring in clause (b) of this sub-rule shall mean the day on which,
according to the schedule of the examination or test first published
by the Kerala Public Service Commission, the examination or test in
the last of the subjects comprising the whole examination or test
would have been conducted, if the examination or test in any of such
subjects had not been postponed to a later date.

(5)

The expression 'any examination or test' occurring in this sub - rule
shall mean any examination or test conducted by the Kerala Public
Service Commission, Government or Department which has a direct
nexus with the service matters like probation, promotion, increment

<!-- page 59 -->

59
etc., of an employee, and not an academic examination/ University
Examination.

Note.- Cases already settled or disposed of prior to the issue of this

amendment shall not be

reopened.

This amendment shall be deemed to have come into force with effect from 10 th
December 1984.
(c)

*****

******

********

(d) Duty in a different service counting for probation on promotion.- A member of a
service or a class of service promoted from one category to another shall be eligible to
count for probation in the higher category his service, if any, performed otherwise than in
a substantive capacity on regular appointment to another service, State or Subordinate, in
accordance with these Rules and the Special rules if the normal method of recruitment to
the latter service is according to such Special rules by transfer from the former service or
class thereof.
(e) Probation where there are more than one grade to the same category.- Not
withstanding anything to the contrary contained in the Special Rules where there are more
than one grade to the same category and duties and responsibilities attached to the
various grades are one and the same, and appointment to the higher grades are made by
promotion from the lower grades then probation shall be insisted only in the lowest grade
to such category.

28 A. Notwithstanding anything contained in these Rules or in the Special Rules, in
the case of appointment to the post of Heads of Departments, direct recruitment shall be
resorted to in the absence of suitable persons for appointment by promotion or by transfer.
Appointment by promotion or by transfer shall be made on the basis of merit and ability,
seniority being considered only when merit and ability are approximately equal. Merit and
ability shall be assessed by the authority competent in the Government to make such
appointments:

Provided that the lists for consideration for appointment by promotion or by
transfer to the posts shall not ordinarily consist of members of service who do not have at
least one year of service before the date of their superannuation after appointment to such
a post.
29.
Revision of orders of appointement to selection posts.- Subject to the
provisions of Note (iii a) of sub-clause (7) and Para (a)] of sub- clause (8) of clause (i) of
sub-rule (b) of rule 28 an order appointing a member of a service or class to a selection
category or grade by promotion or by transfer may be revised by the State Government.
Such revision may be made by the State Government either suo motu at any time or on a
petition submitted by any aggrieved member within six months from the date of passing
the order:

Provided that the said period of six months may be extended by the State Government
if sufficient cause is shown for the delay in the submission of the petition.

<!-- page 60 -->

60
30.

Revision of list of approved candidates for appointment or promotion.-

Notwithstanding anything contained in these Rules or in the Special Rules, the State
Government shall have power to revise in any manner they consider suitable, any list of
approved candidates, for appointment or promotion to any category, class or service,
prepared by the Head of a Department, in exercise of the powers conferred on him by the
Special Rules for any service.
31.
Temporary Promotion.- (a) (i) Where it is necessary in the public interest
owing to an emergency which has arisen to fill immediately a vacancy in a post borne on
the cadre of a higher category in a service or class by promotion from a lower category and
there would be undue delay in making such promotion in accordance with the rules, the
Appointing Authority may promote a person otherwise than in accordance with the rules,
temporarily:

Provided that before a person is promoted under this clause, persons who are
admittedly senior to him shall also be promoted, even if they are absent from duty whether
on leave other than leave without allowances granted and availed of as per Appendix XII A,
Appendix XII B or Appendix XII C of Part I of the Kerala Services Rules or on foreign
service or on deputation or for any other valid reason except due to suspension and
allowed to continue as such subject to the condition that persons so promoted shall not be
eligible for the higher time scale of pay by virtue of such promotions unless otherwise
specifically ordered by Government.

Note.-

(1)

Even where it is considered necessary to sanction the higher time scale of pay,
not more than one person (either the senior most fit person in a series of
adjacent persons outside the ordinary line, or, if such a person either foregoes
the benefit of his own volition or does not require the benefit by virtue of his
holding a post outside the ordinary line which secures him at least equivalent
benefits in respect of salary and pension, then the next below in the series)
may be authorized to draw the salary of the higher scale or grade in respect of
any one officiating vacancy within the cadre filled by his junior.

(2)

A fortuitous officiating promotion given to a person who is junior to one outside
the regular line does not in itself give rise to a claim on the part of the senior to
the higher time scale of pay.

(3)

The expression "persons who are admittedly senior" in the above proviso shall
include persons appointed/promoted temporarily and continuing as such,
solely due to administrative delay in regularizing their appointments.
(4)
A person who is on leave without allowances granted and availed
of as per Appendix XII A, Appendix XII B or Appendix XII C of Part I of the
Kerala Services Rules shall be given promotion to a higher post only on his
return from such leave. His rank and seniority in the higher post shall be
determined with reference to the date of promotion

(5)

If a junior is promoted temporarily in preference to a senior under suspension,
at the time of reinstatement of the senior to duty fully exonerating him of the
charges for suspension the senior shall be given promotion to the vacancy in
the higher post to which he would have been promoted but for the suspension,
if necessary by reverting the junior who got promotion in that vacancy.

<!-- page 61 -->

61
(ii) No person who does not possess the qualifications if any, prescribed for the
said service, class or category, shall ordinarily be promoted under clause (i). Every person
who does not possess such qualifications and who has been or is promoted under clause
(i) shall be replaced as soon as possible by promoting a person possessing such
qualifications.
(b) Where it is necessary to fill a short vacancy in a post borne on the cadre of
a higher category in a service or class by promotion from a lower category and the
appointment of the person who is entitled to such promotion under the rules, would
involve excessive expenditure on traveling allowance or exceptional administrative
inconvenience, the Appointing Authority may promote any other person who possesses the
qualifications, if any, prescribed for the higher category.
(c) A person promoted under clause (i) or clause (ii) of sub- rule (a) shall be
replaced as soon as possible by the member of the service who is entitled to the promotion
under the rules or by a candidate appointed in accordance with the rules, as the case may
be.
These amendments shall be deemed to have come into force with effect from
17.12.1958.
(d) A person promoted under sub- rule (a) or (b) shall not be regarded as a
probationer in the higher category or be entitled by reason only of such promotion to any
preferential claim to future promotion to such higher category.
(e)
If such person is subsequently promoted to the higher category in
accordance with the rules he shall commence his probation, if any, in such category from
the date of such subsequent promotion or from such earlier date as the appointing
authority may determine without prejudice to seniority.
(f) There shall be paid to a person promoted under sub- rule (a) or (b) either
the minimum of the higher time scale of pay, or the pay admissible to him in the higher
time scale based on the pay in the lower time scale applicable to him under the rules
regulating the fixation of pay from time to time, whichever is higher. He shall be paid
increments in the time scale at the time intervals, as fixed by Government from time to
time.
32. Postings and transfers:- (a) A member of a service or class of a service may
be required to serve in any post borne on the cadre of such service or class.

(b) All transfers and posting shall be made by the Appointing Authority.
33. Consequences of resignation:- A member of a service shall, if he resigns his
appointment, forfeit not only the service rendered by him in the particular post held by
him at the time of resignation but all his previous service under the Government.

The re-appointment of such person to any service shall be treated in the same way
as a first appointment to such service by direct recruitment and all rules governing such
appointment shall apply; and on such re-appointment he shall not be entitled to count any
portion of his previous service for any benefit or concession admissible under any rule or
order.
34. Reduction of full members:- (a) If a full member of any service, class, category
or grade is substantively reduced to a lower service, class, category or grade, he shall be

<!-- page 62 -->

62
deemed to be a full member of the latter and the permanent cadre thereof shall, if there is
no vacancy in which he could be absorbed, be deemed to be increased by one:
Provided that against every such addition an officiating or temporary vacancy, if
any, in such lower service, class, category or grade, shall be kept unfilled and such
addition shall be absorbed in the first permanent vacancy that subsequently arises in
such lower service, class, category or grade, as the case may be.
(b) Appointment in place of members dismissed, removed or reduced:-Where a
person has been dismissed, removed or substantively reduced from any service, class,
category or grade, no vacancy caused thereby or arising subsequently in such service,
class, category or grade, shall be substantively filled to the prejudice of such person until
the appeal, if any, preferred by him against such dismissal, removal or reduction is
decided and except in conformity with such decision, or until the time allowed for
preferring an appeal has expired, as the case may be.
35. Savings:- (a) (i) Unless a contrary intention is expressly indicated therein,
nothing contained in these rules shall adversely affect any person who was member of any
service on the date of the coming into force of the rules.

(ii) Unless a contrary intention is expressly indicated therein nothing contained in
any Special Rules governing a service, shall adversely affect any person who was a
member of such service on the date of the coming into force thereof.
(b) Subject to the provisions of sub-rules (c) and (d) where these rules or the Special
Rules would adversely affect in respect of any matter a person who was a member of any
service before the date of coming into force thereof, he shall, in respect of such matter, be
governed by the rules and orders, if any, which were applicable to him immediately prior

to such date.
(c) A person who was on duty otherwise than in a substantive capacity in a post
which was subsequently included in a service shall be regarded as a probationer or; as the
case may be, as an approved probationer in the service or the class or category thereof in
which the post is included and in the lower category, if any, in which he would have been
on duty but for his being on duty in a higher category, if he,(i) was on duty in such post on the date of issue of the Special Rules for that service,
or
(ii) was absent from duty in such post on that date on leave granted by a competent
authority having been on duty in such post immediately before and immediately
after such absence:
Provided that if there were no rules or orders prescribing the period of probation for
such post at the time of his first appointment thereto, the provisions of these rules and of
the Special Rules regarding probation shall apply to him and any period of duty rendered
by him in such post before the date of issue of such rules shall count towards probation if
and to the extent such service would have counted, had these rules and the Special Rules
come into force at the time of such first appointment.
(d) A person who, before the issue of the Special Rules for a service had officiated in
a post which was subsequently included in the service or a class or category thereof but
who is not entitled to be regarded as a probationer or as an approved probationer under
sub-rule (c) shall, if he is again appointed to such post after the issue of the Special Rules

<!-- page 63 -->

63
without contravening any orders of the State Government, be entitled to count his
previous service in such post towards the prescribed period of probation:
Provided that such previous service shall not count towards probation if there was
an interval of a continuous period of two years or more during which he was not holding a
post in the same or higher category.
Explanation:-

The re-appointment of a person under this sub-rule shall not, for the
purposes of rules regulating recruitment, be regarded as first
appointment to the service, class or category concerned.

(e) If, before the issue of the Special Rules, a person had been exempted under the
orders then in force from the possession of any qualification or the passing of any test and
the possession of such qualification or the passing of such test is prescribed by such
Special Rules they shall not apply to such person to the extent and in respect of the
category, grade or post, specifically covered by the order of exemption.

(f) Notwithstanding anything contained in these rules or in the Special Rules, in the
case of persons allotted to the State of Kerala from service under the Government of
Madras consequent on the Reorganization of States, pass in Account Test for Executive
Officers (Madras) and pass in Account Test for Subordinate Officers Part I (Madras) shall
respectively be accepted as sufficient qualification in lieu of pass in Account Test for
Executive Officers of the Kerala State and pass in Account Test (Lower).
36. Re-employment of pensioners:- Nothing in these rules or the Special Rules
shall be construed to limit or abridge the powers of the State Government and of
subordinate authorities to re-employ persons who have retired on a civil pension or
gratuity or who, while in service, were subscribers to a Contributory Provident Fund, in
any service. The re-employment of such a person in any service shall not be regarded as a
first appointment to that service.
37. Appointment of All India Service Officers to State posts:- Notwithstanding
anything contained in these rules or the Special Rules, an officiating or permanent officer
of an All India Service may be appointed to any State Service, or class or category thereof.
Such Officer shall not, by reason of such appointment, cease to be a member of an All
India Service.
38. Relinquishment of rights by members:- Any person may, in writing, relinquish
any right or privilege to which he may be entitled under these rules or the Special Rules, if,
in the opinion of the Appointing Authority, such relinquishment is not opposed to public
interest; and nothing contained in these rules or the Special Rules shall be deemed to
require the recognition of any right or privilege to the extent to which it has been so
relinquished.

Explanation:

The relinquishment of the right for promotion under this rule shall
entail loss of seniority and a relinquishment of the right for promotion
shall not be permissible unless such relinquishment entails loss of
seniority.

39. Notwithstanding, anything contained in these rules or in the Special Rules or in
any other Rules or Government Orders the Government shall have power to deal with the
case of any person or persons serving in a civil capacity under the Government of Kerala

<!-- page 64 -->

64
or any candidate for appointment to a service in such manner as may appear to the
Government to be just and equitable:
Provided that where such rules or orders are applicable to the case of any person or
persons, the case shall not be dealt with in any manner less favourable to him or them
than that provided by those rules or orders.
This amendment shall be deemed to have come into force with effect from 17th
December 1958.
SCHEDULE
Referred to in rule 10(aa)
(a) English School Leaving or Secondary School Leaving Certificate issued under the
authority of the Travancore, Cochin, Travancore-Cochin or Kerala State Government with
endorsement of eligibility for college admission or Public Service.
(b) Pass in the E.S.L.C or S.S.LC. Examination (Travancore-Cochin or Kerala) as a
private candidate after undergoing a prior selection examination conducted by the Director
of Public Instruction.
(c) Pass in two year Sanskrit Entrance Course, Sanskrit College, Trivandrum.
(d) Completed S.S.L.C issued under the authority of the Government of Madras with
endorsement of eligibility for College admission, or with marks not less than the
percentage of marks specified in column (2) of the table below against the subjects referred
to in column (1) thereof:TABLE
1

2

I. Academic Course:
1. First Language-Parts I and II
2. English
3. Mathematics (General or Composite)
4. Social Studies
5. General Science

Per cent
40 (80 marks out of 200).
40
35 each in any two of the subjects
and 30 in the third.

II Secretarial Course:
1. First Language – Part I
2. English
3. Commercial Arithmetic
4. Social Studies
5. Drafting, Precis-writing and Typewriting
6. Two of the following three items:-

40
40

(i) Commercial Practice
(ii) Shorthand
(iii)Book-keeping

35 in an one of the subjects and
30 each in the other three

III. Pre-Technological Course:
A. Engineering-

<!-- page 65 -->

65
1. First Language – Part I
2. English
3. Mathematics (General or Composite
4. Social Studies
5. Science and Drawing
6. Applied Science and Practical

40
40
35 in any one of the subjects and
30 each in the other three

B. Agriculture or any other subject1. First Language – Part I
2. English
3. Mathematics (General or Composite)
4. Social Studies
5. Agriculture (Theory)
6. Elementary Science and Practical

40
40
35 in any one of the subjects and
30 each in the other three

C. Textile Technology1. First Language – Part I
2. English
3. Mathematics (General or Composite)
4. Social Studies
5. Handloom Weaving (Written and
Practical)
6. Dyeing and Printing (Written and
Practical)

40
40
35 in any one of the subjects and
30 each in the other three

IV. Aesthetic and Domestic Course(The course consists of Three Parts)
Part I
First Language – Part I
Part II
English
In each of the other two subjects
under part II

40
40
30 in each

If additional language is taken under this Part the candidate should obtain a total
number of 80 marks in that language and in Part I of the First Language put together. If
General Science or Social Science is taken as a subject under this Part, 35 per cent
should be obtained in that subject.

Part III
Any one subject under this part

30

V. Teaching Practice Course1. First Language – Part I

40

2. English

40

3. Mathematics (General or Composite)
35 in any one of the subjects and

<!-- page 66 -->

66
4. General Science
5. Social Studies
6. Teaching Practice

30 each in the other three

Provided that in the case of a candidate belonging to the Scheduled Castes or
Scheduled Tribes, it shall be sufficient if he has obtained not less than 35 per cent in
English, not less than 35 per cent in Part I of the first language or 70 marks out of 200
when both Parts I and II of the First Language are taken, as the case may be and not less
than the percentage of marks specified in the table above in other subjects.
(i) A pass in a Government Technical Examination will be regarded as
equivalent to obtaining 35 per cent of the marks in the corresponding
subjects in the Secondary School Leaving Certificate Public Examination; for
this purpose where in the latter examination, the technical subject
comprises two subjects in the Government Technical Examination, passes in
at least the Lower Grade are required in both the subjects in the
Government Technical Examination.
(ii) A pass in a Part of the Intermediate Examination in Arts and Science or the
Pre-University Examination of any recognized university shall be regarded as
equivalent to obtaining the minimum numbers of marks prescribed for the
corresponding subject or subjects in the Secondary School Leaving
Certificate Public Examination.
(e) A completed Anglo-Indian School Leaving Certificate issued under the authority
of the Government of Madras, with either Tamil, Malayalam, Kannada, Hindustani or
Hindi as his compulsory second language and secured at the Anglo-Indian High School
Examination not less than the percentage of marks specified below in the subjects in
Group 'A' and not less than 35 per cent in each of three subjects in Group 'B'.
Group 'A'
English
Elementary Mathematics
A language

-

40
35
30 or

(f) Matriculation Examination of a recognized University or Board of Education or
any other Examination recognized by the Central or State Government as equivalent
thereto;
Note.- The following shall be regarded as equivalent to the minimum general
educational qualification prescribed in the Schedule to the General Rules
for the State and Subordinate Services:-

1. Indian Army-Special Certificate of Education;
2. A pass in the Higher Education Test of the Royal Indian Navy;
3. The Royal Indian Air Force Educational Test for re-classification of Leading Air
Craftsmen;
4. The Indian Army Certificate of Education I Class together with (i) a pass in the First
Language Papers of the S.S.L.C (Travancore -Cochin or Kerala) or (ii) a pass in the
V.S.L.C Examination (Travancore), or (iii) a pass in the mother tongue as Second
Language under the old E.S.L.C. Scheme (Travancore); or (iv) a pass in mother
tongue (Malayalam) in the S.S.L.C. Examination under the Madras S.S.L.C Scheme
of 1929 or 1948 or the Cochin S.S.L.C Scheme.
5. Post- Basic School Certificate awarded by a Post-Basic School in any State in India
recognized by the State Government concerned as equivalent to S.S.L.C /

<!-- page 67 -->

67
Matriculation/ Higher Secondary Certificate for purpose of employment under
them.
(g) Other qualification recognized by the State Government as equivalent to (a)
above.
ANNEXURE
(See rule 15)
1. For direct recruitment to posts included in the Kerala Last Grade Services.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29,
30.
31.
32.
33.
34.
35.
36.
37.
38.
39.
40.
41.
42.
43.
44.
45.

Open competition
Ezhavas, Thiyyas and Billavas
Open competition
Scheduled Castes
Open competition
Muslims
Open competition
Latin Catholics & Anglo Indians
Open competition
Other Backward Classes
Open competition
Scheduled Castes
Open competition
Ezhavas, Thiyyas and Billavas
Open Competition
Muslims
Open competition
Dheevaras
Open competition
Viswakarmas
Open competition
Latin Catholics and Anglo-Indians
Open competition
Scheduled Castes
Open competition
Muslims
Open competition
Ezhavas, Thiyyas and Billavas
Open competition
Other Backward Classes
Open competition
Scheduled Castes
Open competition
Ezhavas, Thiyyas and Billavas
Open competition
Muslims
Open competition
Nadars included in SIUC
Open competition
Other Backward Classes
Open competition
Ezhavas, Thiyyas and Billavas
Open competition
Scheduled Tribes
Open competition

<!-- page 68 -->

68
46.
47.
48.
49.
50.
51.
52.
53.
54.
55.
56.
57.
58.
59.
60.
61.
62.
63.
64.
65.
66.
67.
68.
69.
70.
71.
72.
73.
74.
75.
76.
77.
78.
79.
80.
81.
82.
83.
84.
85.
86.
87.
88.
89.
90.
91.
92.
93.
94.
95.
96.
97.
98.
99.
100.

Muslims
Open competition
Scheduled Castes converts to Christianity
Open competition
Other Backward Classes
Open competition
Scheduled Castes
Open competition
Ezhavas, Thiyyas and Billavas
Open competition
Muslims
Open competition
Ezhavas, Thiyyas and Billavas
Open competition
Hindu Nadars
Open competition
Scheduled Castes converts to Christianity
Open competition
Scheduled Castes
Open competition
Muslims
Open competition
Latin Catholics and Anglo-Indians
Open competition
Other Backward Classes
Open competition
Scheduled Castes
Open competition
Ezhavas, Thiyyas and Billavas
Open competition
Muslims
Open competition
Ezhavas, Thiyyas and Billavas
Open competition
Nadars included in SIUC
Open competition
Ezhavas, Thiyyas and Billavas
Open competition
Scheduled Castes
Open competition
Muslims
Open competition
Dheevaras
Open competition
Other Backward Classes
Open competition
Scheduled Tribes
Open competition
Latin Catholic and Anglo-Indians
Open competition
Muslims
Open competition
Ezhavas, Thiyyas and Billavas
Open competition
Viswakarmas

<!-- page 69 -->

69

Explanation I-

The expression “Other Backward Classes” referred to in items
10, 30, 40, 50, 70 and 90 shall mean Backward Classes referred to
in item 8 under sub-rule (1) of rule 17.

Explanation II-

The short fall in reservation for 'Nadars included in SIUC', and
'Hindu Nadars' occurred in the advice by the Commission from the
ranked lists published by the Commission on or after the 21st day of
November, 2009 during the period commencing on and from the 21st
day of November, 2009 to the date of publication of the Kerala State
and Subordinate Services (Amendment) Rules, 2010 in the Gazette,
i.e. till the date of commencement of this Explanation, shall be
adjusted in the future vacancies without disturbing the advices
already made.

II.
For direct recruitment in posts other than those included in the Kerala Last
Grade Service.
1. Open competition
2. Ezhavas, Thiyyas and Billavas
3. Open competition
4. Scheduled Castes
5. Open competition
6. Muslims
7. Open competition
8. Latin Catholics & Anglo Indians
9. Open competition
10. Other Backward Classes
11. Open competition
12. Scheduled Castes
13. Open competition
14. Ezhavas, Thiyyas and Billavas
15. Open competition
16. Muslims
17. Open competition
18. Ezhavas, Thiyyas and Billavas
19. Open competition
20. Viswakarmas
21. Open competion
22. Latin Catholics and Anglo-Indians
23. Open competition
24. Scheduled Castes
25. Open competition
26. Muslims
27. Open competition
28. Ezhavas, Thiyyas and Billavas
29. Open competition
30. Muslims
31. Open competition
32. Scheduled Castes
33. Open competition
34. Ezhavas, Thiyyas and Billavas

<!-- page 70 -->

70
35. Open competition
36. Muslims
37. Open competition
38. Nadars included in SIUC
39. Open competition
40. Other Backward Classes
41. Open competition
42. Ezhavas, Thiyyas and Billavas
43. Open competition
44. Scheduled Tribes
45. Open competition
46. Muslims
47. Open competition
48. Scheduled Castes converts to Christianity
49. Open competition
50. Dheevaras
51. Open competition
52. Scheduled Castes
53. Open competition
54. Ezhavas, Thiyyas and Billavas
55. Open competition
56. Muslims
57. Open competition
58. Ezhavas, Thiyyas and Billavas
59. Open competition
60. Hindu Nadars
61. Open competition
62. Ezhavas, Thiyyas and Billavas
63. Open competition
64. Scheduled Castes
65. Open competition
66. Muslims
67. Open competition
68. Latin Catholics and Anglo Indians
69. Open competition
70. Viswakarmas
71. Open competition
72. Scheduled Castes
73. Open competion
74. Ezhavas, Thiyyas and Billavas
75. Open competition
76. Muslims
77. Open competition
78. Ezhavas, Thiyyas and Billavas
79. Open competition
80. Muslims
81. Open competition
82. Ezhavas, Thiyyas and Billavas
83. Open competition
84. Scheduled Castes
85. Open competition
86. Muslims
87. Open competition
88. Ezhavas, Thiyyas and Billavas
89. Open competition

<!-- page 71 -->

71
90. Other Backward Classes
91. Open competition
92. Scheduled Tribes
93. Open competition
94. Latin Catholics and Anglo-Indians
95. Open competition
96. Muslims
97. Open competition
98. Ezhavas, Thiyyas and Billavas
99. Open competition
100. Viswakarmas
Explanation 1.-

The expression “Other Backward Classes” referred to in items 10,
40 and 90 shall mean Backward Classes referred to in item 8 under
sub-rule (1) of rule 17.

Explanation II.-

The short fall in reservation for 'Nadars included in SIUC' and 'Hindu
Nadars' occurred in the advice by the Commission from the ranked
lists published by the Commission on or after the 21st day of
November, 2009 during the period commencing on and from the 21st
day of November, 2009, to the date of publication of the Kerala State
and Subordinate Services (Amendment) Rules, 2010 in the Gazette,
i.e., till the date of commencement of this Explanation, shall be
adjusted in the future vacancies without disturbing the advices
already made.

.............x................x..................

<!-- page 72 -->

72
