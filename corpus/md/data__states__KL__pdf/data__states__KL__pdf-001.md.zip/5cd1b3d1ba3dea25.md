---
doc_id: "5cd1b3d1ba3dea25"
source_url: "https://dairydevelopment.kerala.gov.in/images/pdf/2021-22/SRO_639_of_2020_Muncipality_Rules_building_rules.pdf"
ministry: "Dairy Development Department, Kerala"
title: "Click Here.."
date: ""
pages: 39
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6f4aa3112c1158bb"
---

<!-- page 1 -->

Regn.No. KERBIL/2012/45073
dated 05-09-2012 with RNI
Reg No.Kl/TV(N)/634/2018-20

©
േകരള സർകാർ
Government of Kerala
2020

േകരള ഗസറ്
KERALA GAZETTE
അസാധാരണം
EXTRAORDINARY

ആധികാരികമായി ്പസിദെപടുതുനത

PUBLISHED BY AUTHORITY
തിരുവനനപുരം,
വ്ാഴം

വാല്ം 9

Vol. IX

2020 ഒകേടാബർ 01
01st October 2020
1196 കനി 15
15th Kanni 1196

Thiruvananthapuram,
Thursday

നമർ
No.

2258

1942 ആശ്ിനം 9
9th Aswina 1942

GOVERNMENT OF KERALA

Local Self Government (RD) Department
NOTIFICATION
G. O. (P) No. 57/2020/LSGD.

S. R. O. No. 639/2020

Dated, Thiruvananthapuram, 24th September, 2020.
8th Kanni, 1196
2nd Aswina, 1942.

In exercise of the powers conferred under sections 381, 382, 383A, 387, 398 and 406 of
the Kerala Municipality Act, 1994 (Act 20 of 1994), read with section 565 therof, the
Government of Kerala hereby make the following Rules to amend the Kerala Municipality
Building Rules, 2019 issued under notification G.O. (P) No. 77/2019/LSGD dated
2nd November, 2019 and published as S.R.O. No. 828/2019 in the Kerala Gazette
Extraordinary No. 2691 dated 8th November, 2019 namely:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 2 -->

2

RULES
1. Short title and commencement.—(1) These Rules may be called the Kerala
Municipality Building (Amendment) Rules, 2020.
(2) They shall come into force at once.
2.

Amendment of the Rules.— In the Kerala Municipality Building Rules, 2019,—
(1) In rule 2, in sub-rule (1), —
(a) in item (j), for the word “multiplexes”, the words “multiplex complexes”
shall be substituted;
(b) in clause (l), for the figures and words “75 centimetres”, the figures and
words “120 centimeters from the highest proposed ground level” shall be
substituted;
(c) in clause (n) the words “swimming pools, ponds” shall be omitted;
(d) in item (q), for the words, figures and brackets “under sub-rule (5) of rule
3”, the words, figures and brackets “under sub-rule (6) of rule 3 of the
Kerala Panchayat Building Rules, 2019” shall be substituted;
(e) for clause (ar), the following clause shall be substituted namely:—
“(ar) ‘floor space index (F.S.I.)’ means the quotient obtained by dividing
the total floor area by the area of the plot (This word is synonymous with
FAR).
F.S.I = Total floor area”;
Plot area
(f) after clause (aq), the following clause shall be inserted, namely:—
“(aqa) ‘total floor area’ means the built-up area of a building excluding the
following, namely:—
(i)

Towers, turrets, domes etc. projecting above the terrace;

(ii)

Fifty per cent of the area in the case of verandahs and balconies with
at least one of its sides open (other than parapets) to exterior or
interior open spaces;

(iii) Open platforms and terraces at ground floor and porches;
(iv) Plinth offsets (if the offset does not exceed 5cm) and projection of
columns;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 3 -->

3

(v)

Vertical sun breakers or box louvers, architectural bands, cornices
etc.

(vi) Area of loft, mandatory area used for parking of vehicles within a
building, area of electrical room, pump rooms, gas banks, battery
rooms for solar plants, room for air-conditioning plant, generator
room, internal sanitary shafts, air conditioning ducts. However, area
occupied by lift shall be included in any one floor.
(g) after clause (br), the following clause shall be inserted, namely:—
“(bra) ‘notified road’ means any road notified by the Corporation/
Municipality or Government;
(h) in item (cc), after the words “Persons with disability” the words and
symbols “/Differently-abled” shall be added;
(i) after item (ch), the following shall be added, namely:—
“(cha) ‘Podium’ means a horizontal projection (platform) extending
beyond building on one or more sides up to a limit of sixteen meters from
the average ground level.
(j) in item (cv), the words “central line or” shall be omitted;
(2) In rule 3 (a) after clause (c) of sub-rule (4) the following clauses shall be inserted,
namely:—
“(d) the Government shall grant additional FSI or any other incentive by way of
relaxation in these rules as deem fit for programs, schemes and projects meant for slum
improvement and redevelopment projects, affordable housing for weaker section and poor,
market redevelopment and relocation, construction of public infrastructure like road, water
supply, sewage and effluent treatment, waste management, open spaces and greening,
conservation measures, climate change mitigation, renewable energy, municipal common civic
infrastructure, public transport including multilevel parking structures, rainwater harvesting,
disaster management etc.”
(e) in case of road widening and/or creation of any facility as prescribed in clause (d)
above in accordance with any published / sanctioned District Town Planning Scheme or master
plan, or under any programme of Government or local body, the FSI permissible for abutting
plots shall be based on the size of the plot without deducting the area required for such road
widening or creation of any public facility. The restrictions related to number of floors,
coverage and height shall be waived in such case in order to avail the full FSI available on the
original plot size.”
Note:—The entitlement for full FSI utilization shall be available only for those plots, part of
which is acquired or reserved or surrendered for creation of public facilities.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 4 -->

4

(3) In rule 5,—
(a) in sub-rule (1), in clause (b), for the word “duplicate”, the word “triplicate”
shall be substituted;
(b) in sub-rule (4), under the table,—
(i) in Sl.No.12 after the words “and subsequent amendments”, the words and
figures “Provisions regarding the height of the building as specified in the
National Building Code of India 2016 shall not apply to multiplex
complexes” shall be added;
(ii) against Sl.No.13, under the heading Officer/authority after the words “Fire
Station”, the words “for information” shall be inserted;
(iii) in the third proviso, after the words “relevant Acts”, the words “Rules” shall
be added;
(iv) in the fourth proviso, the words “Provided that the provisions regarding the
height of building as specified in the National Building Code of India 2016
shall not apply to multiplexes” shall be omitted;
(c ) In sub-rule (5),—
(a)

in clause (1), after the word, letter and symbol “Group H : Storage”, the
word, letter and symbols “Group J: Multiplex Complex” shall be
inserted;

(b)

In clause (2), in the proviso, for the words “completion certificate”, the
words “occupancy certificate” shall be substituted;

(4) In rule 8, after item (xi), the following items shall be inserted, namely:—
(xii) Livestock building for keeping not more than 20 cows, 50 goats and poultry
farms for keeping not more than 1000 birds. For these constructions, 1.5 metre
clear open space shall be provided all around the building/structure. Biogas
plant or gober gas plant shall be provided for these constructions.
(xiii) Mechanical Parking Structures; For height of the structure up to 10 metres, it
shall be provided with minimum 1 metre open space all around the structure.
For height exceeding 10 metres, it shall be provided with minimum 1.5 metre
open space all around the structure;
(xiv) Electric Vehicle battery charging stations”;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 5 -->

5

(5) In rule 13, Proviso shall be omitted;
(6) in rule 17, after sub-rule (19), the following sub-rule shall be added, namely:—
“(20) The owner shall engage a licensee as per these rules. If the owner wishes to
change the licensee before obtaining occupancy certificate, it shall be intimated to
the Secretary in writing. Otherwise, the licensee who had certified the plans
submitted for obtaining permit shall be deemed as the licensee for the proposed
construction.”
(7) in Rule 18, in sub-rule (7), for the words “issuing”, the words “furnishing” shall be
substituted;
(8) in Rule 20,—
(a) in sub-rule (2), for the words, “signed by the Secretary”, the words “certified by
the Secretary” shall be substituted;
(b) in sub-rule (3),—
(i) after the word, letter and figure “Appendix F2”, the words “along with a
copy of the plans duly certified by the Secretary” shall be inserted;
(ii) in the first proviso, for the words, figure and brackets “sub-rule (5)” the
words, figure and bracket “sub-rule (6) ” shall be substituted;
(iii) after the first proviso the following proviso shall be inserted, namely:—
“Provided further that if any road widening project or public facilities project is taken up
by any public agency after the building permit is issued and before the completion of the
building as per the provisions of the Detailed Town Planning Scheme/Master plan or otherwise,
the deficiency in setback due to the road widening shall not be treated as a violation of these
rules and occupancy certificate shall be issued.”
(iv) after the words, deemed occupancy certificate, the following shall be
added, namely:—
“such deemed occupancy certificate shall be accepted by all the public
authorities as proof of completion of the building in compliance to these
rules and the municipality shall accept building tax from such date of
having the occupancy certificate deemed.”
(9) in rule 23, for the words, “Prohibition for constructions abutting public roads”, the
words and symbols “Prohibition for constructions abutting public roads/streets” shall be
substituted;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 6 -->

6

(10) In rule 25,—
(a) sub-rule (1) shall be substituted with the following, namely:—
“(1) All buildings existing or hereinafter proposed shall be classified, in one of
the following occupancies, according to the use or character of occupancy, namely:—

N
o
n
r
e
s
i
d
e
n
t
i
a
l

Group A1

Residential

Group A2

Lodging Houses and special residential

Group B

Educational

Group C

Medical/Hospital

Group D

Assembly

Group E

Office

Group F

Mercantile/Commercial

Group G1

Industrial I

Group G2

Industrial II

Group H

Storage

Group I

Hazardous

Group J

Multiplex Complex

(b) in sub-rule (2),—
(i) in clause (a), the word and symbol “, libraries” shall be omitted;
(ii) in clause (e), the proviso shall be omitted;
(iii) for the note under clause (g) , the following note shall be substituted,
namely;—
“Note:—Any building with not more than 200 sq.metres built up area accommodating the
uses under Group C, D and E and with not more than 300 sq. metres built up area
accommodating the uses under Group H shall be included in Group F ”;
(iv) in the note under clause (h)—
(a) for the word and figures “30 birds”, the word and figures “1000
birds” shall be substituted;
(b) after the word, figure and symbol “6 animals,”, the words, figures and
symbols “ 20 cows or 50 goats,” shall be added;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 7 -->

7

(c) for the words and figures “700 square meters” the words and figures
“1000 square meters” shall be substituted.
(v)

in the note (2) under clause (i) for the words and figures “700 square
metres” the words and figures “1000 square meters” shall be substituted;

(vi) in clause (j), after the words “any building or part thereof” the words
“exceeding 300 square metres of built up area” shall be added;
(vii) in clause (l), for the words “habitable areas like hotels and service
apartments”, the words “habitable areas like service apartments” shall be
substituted;
(viii) in clause (l), after the words and figures “shall not exceed 50 m” the words
and figures “The height restriction of 30 meters for buildings for the same
purpose under “Assembly Category” as specified in National Building Code
of India, 2016 and subsequent amendments shall not be applicable for
buildings under this occupancy group. The fire and Rescue norms/standards
as decided by Fire and Rescue Department shall be applicable for the height
beyond 30 meters” shall be inserted;
(11) In rule 26,—
(a) in sub-rule 4,—
(i) after the words “as per the Table 4”, the following shall be added,
namely:—
“and if the yards stipulated in Table 4 cannot be maintained laterally
throughout due to the peculiar shape of the plot, yards as per Table 4A
shall be provided for every building up to 10 metres in height”;
(ii) for Table 4, the following table shall be substituted, namely:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 8 -->

8

“TABLE 4
YARDS FOR BUILDINGS UNDER DIFFERENT OCCUPANCIES

(1)
Front
(in
metre)
Rear
(in
metre)
Sides
(in
metre)

200500 sq
meters

Group D

Group G1
Group F
built up
area
exceeding
200 sq.
metres

Above 500 200 – 500
sq.metres sq.metres

500 – 800
sq.metres

Above800
sq.metres

built up
area
upto200
sq.
metres

built up
area
exceeding
200 sq.
metres

Gro
up
G2

Buildings
in Group
H of built
up area
exceeding
300 sq.
metres

Group J

Buildings in Group
B, C & E of built up
area exceeding 200
sq. metres

Group I

Yards

Building
Buildings
in small
in Group plots under
A1 & A2
Group A1
of any
and F
built up
(built up
area and
area not
Buildings exceeding
in Group F
200 sq.
with built metres and
up area not plot area
exceeding
not
200 sq.
exceeding
metres
125 sq.
metres)

(2)

(3)

(4)

(5)

(6)

(7)

(8)

(9)

(10)

(11)

(12)

(13)

(14) (15)

3

1.8

5

6

6

7.5

10.5

3

3

3

5

6

7.5

10.5

1.5

1

2

2

2

3

3

1.5

2

3

5

3

7.5

5

1

0.6

2

2

2

4

5

1

2

3

3

2

7.5

5

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 9 -->

9

TABLE 4A
MINIMUM AND AVERAGE YARDS FOR BUILDINGS UNDER DIFFERENT OCCUPANCIES

Front
Average
(in
metre)
Front
Minimum
(in
metre)
Rear
Average

(in
metre)

(2)

Buildings in
Group B, C &
E of built up
area exceeding
200 sq. metres

200500
sq
meter
s

(3)

3

Group F
built up
area
exceeding
200 sq.
metres

Group D

Group
G2

Buildings
in Group H
of built up
area
exceeding
300 sq.
metres

built
up area
upto
200 sq.
metres

built up
area
exceedi
ng 200
sq.
metres

(9)

(10)

(11)

(12)

(13)

(14)

(15)

10.5

-

-

-

-

6

-

-

5

6

-

-

-

-

4.5

-

-

3

3

-

-

-

-

3

-

-

Above
500
sq.met
res

200
–
500
sq.m
etres

500 –
800
sq.metr
es

Above
800
sq.met
res

(4)

(5)

(6)

(7)

(8)

1.8

5

6

6

7.5

1.8

1.2

3

4.5

4.5

1.5

1

2

3

2

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

Group G1

Group J

(1)

Building in
small plots
under Group
A1 and F
(built up area
not exceeding
200 sq. metres
and plot area
not exceeding
125 sq.
metres)

Group I

Yards

Buildings
in Group
A1 & A2
of any
built up
area and
Buildings
in Group
F with
built up
area not
exceeding
200 sq.
metres

<!-- page 10 -->

10

(1)
Rear
Minimum
(in
metre)
Side
Average
(in
metre)
Side
Minimum
(in
metre)

(2)

(3)

(4)

(5)

(6)

(7)

(8)

(9)

(10)

(11)

(12)

(13)

(14)

(15)

1

0.5

1.5

1.5

1.5

1.5

1.5

-

-

-

-

1.5

-

-

NA

NA

2

2

2

4

5

-

-

-

-

2

-

-

1

0.6

1.5

1.5

1.5

1.5

1.5

-

-

-

-

1.5

-

-

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 11 -->

11

(iii) the first proviso the following proviso shall be substituted, namely:—
“Provided that for single family residential buildings in plots abutting un-notified road
with width less than 6 metres, the front yard shall not be less than 2 meters.”;
“Note:—Average yard shall be calculated based on the area of the yard between the
building and plot boundary.”;
(iv)

in the second proviso after the word “in Table 4”, the words “ and 4A
shall be added

(v) after the second proviso, the following proviso shall be inserted namely:—
“ Provided further that for buildings on podium, the minimum yards corresponding to
the height of the building including podium can be given at two levels, i.e. one at the
ground level and the other at the topmost level of the podium. For buildings upto 16
metres height, the height of podium shall be limited to 10 metres from ground level and
in such cases, the minimum yards as per these rules for the height of podium shall be
given at the ground level subject to a minimum of 2.5 metres. For buildings having more
than 16 metres height, the height of podium shall be limited to 16 metres from ground
level and in such cases, the minimum yards as per these rules for the height of podium
shall be given at the ground level subject to a minimum of 3.5 metres.”

(ii) after the fourth proviso, the following note shall be added “Note –

Average yard shall be calculated based on the area of the yard between
the building and plot boundary”;
(iii) in fifth proviso, for the words “upto two floors” the words and figures“

with height of building up to 7 metres above ground level” shall be
substituted
(12) In rule 27,-(a) in sub-rule (1), for the words and symbols

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 12 -->

12

“

” the words and symbols

“

” shall be substituted;

(b) in sub-rule (2),—
(i)

in Table 6, in Sl. No. 9 for the maximum permissible coverage of
Industrial-II G2 occupancy, for the figure “40”, the figure “60” shall be
substituted;

(ii)

in clause (vii), for the words “built-up area”, the words “floor area” shall
be substituted;
(13) in rule 28,—
(a) in sub-rule (1),—
(i) for the words and figures “Table 7 and 8” the words, figures and
symbols “Table 7, 8 and 8A” shall be substituted;
(ii) for Table 7 and 8, the following tables shall be substituted,
namely:—
(iii)“TABLE 7
ACCESS FOR GROUP A1 OCCUPANCY

Sl.No

Occupancy

Total floor area of
buildings in sq. meters

Minimum width of access
required in meters

(1)

(2)

(3)

(4)

1(a)

Single unit upto 300:

No minimum

Multiple unit upto 300:

1.20

Above 300 upto 600

2.00

Above 600 upto 1000
Group A1 Occupancy with
Above 1000 upto 4000
total floor area

3.00

Above 4000 upto 8000

5.00

Above 8000 upto 18000

6.00

Above 18000 upto 24000

7.00

Above 24000

10.00

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

3.60

<!-- page 13 -->

13

TABLE 8
ACCESS FOR OCCUPANCY GROUPS A2,B,C,D,E,F
Sl.
No.

Occupancy

Total floor area of buildings
in sq. meters

Minimum width of access
required in meters

(1)

(2)

(3)

(4)

1

A2,B,C,D,E,F Upto 300

1.20

Above 300 - 1000

3.00

Above 1000 - 1500

3.60

Above 1500 – 6000

5.00

Above 6000 - 12000

6.00

Above 12000 - 18000

7.00

Above 18000

8.00

TABLE 8A
ACCESS FOR OCCUPANCY GROUPS G1,G2,H,I,J
Sl.No Occupancy
(1)
1

Total floor area of buildings in
sq. meters

Minimum width of access required
in meters

(3)

(4)

(2)
G1,G2

Upto 300

3.00

Above 300 - 1500

3.60

Above 1500 - 6000

5.00

Above 6000

6.00

Above 300

7.00

2

H

3

I

7.00

4

J

12.00

(iii) sixth proviso shall be omitted;
(iv) in the tenth proviso, for the words and figures “Table 7 and 8” the
words, figures and symbols “Table 7, 8 and 8A” shall be
substituted;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 14 -->

14

(14) In rule 29,—
(a) For the sub-rule (1) the following sub rule shall be substituted namely:—
“Dimension of each off-street parking space provided for parking motor cars shall not be
less than 5.5 metres x 2.7 metres. The area requirements for each off-street parking space
for parking two-wheelers shall be 3 sq.metres and 1.5 sq. metres respectively ”;
(b) for Sub-rule (3) , the following sub-rule shall be substituted, namely:—
“(3) Parking requirement is calculated based on total floor area”
(c) for Table 9 and 10 the following tables shall be substituted , namely:—
“TABLE 9
OFF-STREET PARKING SPACE FOR APARTMENTS/FLATS UNDER GROUP-A1
Total floor area per Dwelling Unit
Upto 75 sq. metres
Above 75 sq. metresupto 185 sq. metres
Above 185 sq. metresupto 300 sq. metres
Above 300 sq. metres

Off-street Parking Spaces at the rate of
1 for every 3 dwelling units
1 for every dwelling unit
1.5 for every dwelling unit
2 for every dwelling unit

TABLE10
OFF-STREET PARKING SPACE FOR OCCUPANCIES OTHER THAN GROUP-A1
Sl. No Occupancy
(1)

One parking space for every or fraction of
(2)

(3)

1

Group A2-Lodging houses & special 90 sq. metres of floor area for total floor area
residential
upto 1200 sq. metres and at the rate of 60 sq.
metres for the additional floor area in excess of
1200 sq. metres.

2

Group B-Educational
(i) High Schools, Higher Secondary (i) 300 sq.metres of total floor area.
Schools, Junior Technical Schools,
Industrial Training Institute etc.
(ii) 120 sq.metres of total floor area
(ii) Higher educational institutions

3

Group C- Medical/Hospital

.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

90 sq.metres of total floor area

<!-- page 15 -->

15

4

Group D- Assembly

5

Group E- Office Building

6

20 sq.metres of total floor area
Note:(i) In the case of wedding halls and
community halls, for calculating the
floor area for the purpose of
parking, the floor area of either the
auditorium or the dining hall,
whichever is higher, alone need be
taken.
(ii) In the case of library, for calculating
thefloor area for the purpose of
parking, the area of the stacking
space for books shall be excluded.

90 sq. metres of floor area for total floor area
upto 1200 sq. metres and at the rate of 60 sq.
metres for the additional floor area in excess of
1200 sq. metres.
Group F- Mercantile/ Commercial 90 sq. metres of floor area for total floor area
building exceeding 90 sq. metres floor upto 1200 sq. metres and at the rate of 60 sq.
area
metres for the additional floor area in excess of
1200 sq. metres.

7

Group G1- Industrial-I Building

240 sq. metres of total floor area

8

Group G2- Industrial– II Building

240 sq. metres of total floor area

9

Group H-Storage

240 sq. metres of total floor area

10

Group J Multiplex complex

50 sq. metres of total floor area.”

(iv) in second proviso, for the words, figures and symbols “120 sq. metres of built-up
area” the words “100 sq. metres of total floor area” shall be substituted;
(c)

in sub-rule (4),—
(i)

in clause (ii), the following sentence shall be added at the end,
namely:—

“ But in case of A1 occupancy, if the number of parking is not more than 75
and in other occupancy the parking is not more than 25 the width of ramp for
driveway for two-way direction may not be provided.”;
(ii)

(in clause (iii) for the words and figures “4.5 metres” the words and
figure “4.0 metres” shall be substituted.

(iii)

clause (vi) shall be omitted;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 16 -->

16

(d) in sub-rule (7), for the words and symbols “built-up area”, the words “total floor
area” shall be substituted;
(e) after sub-rule (11) the following sub rule shall be inserted, namely:—
“(12) all buildings requiring parking shall have facility for charging electrical
vehicles. The government shall notify the number of charging points to be
provided in accordance with the size and occupancy of the building as required
from time to time.”
(15)

In rule 31, in sub-rule (1),—
(a) in clause (iii), in the first proviso, the following shall be added at the end,
namely:—
“and in the case of cul-de-sacs not exceeding 75 metres, it is sufficient if the
street (cul-de-sac) has not less than 3 metres width”;
(b) in clause (viii) for the figure, the following figure shall be substituted,
namely:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 17 -->

17

(c) in clause (x), the following shall be added at the end, namely:—
“ In case of layout for subdivision of land, where the number of residential plots is less than 10
and plot area less than 0.5 hectare, approval from the Secretary is not required.
(16)

in rule 34, in sub-rule (3), in clause (1), the following shall be added at the end,
namely:—
“Area of parking given inside the building can be deducted from the built-up area
for calculating sanitation facilities.”;

(17)

in rule 35,—
(a) in sub-rule (1), in clause (2) for the words “less than”, the words “greater
than” shall be substituted;
(b) in sub-rule (2), in clause (6) for the word “balustrades”, the word “balusters”
shall be substituted;

(18)

In rule 43, in sub-rule (2),—
(a)

for the words, figures and symbols “6% of the total built-up area”, the
words, figures and symbols “6% of the total floor area” shall be substituted;

(b)

for the words “shall be given in ground level”, the words “shall be given in
ground level and may be provided” shall be substituted;

(19)

In rule 44, in sub-rule (3), the words and symbol “toilets,” shall be omitted;

(20)

In rule 45, in sub-rule (6), the words “and toilets” shall be omitted;

(21)

In rule 54, in sub-rule (1), —

(22)

(a)

for the letter and figure “5m”, the letter and figure “6m” shall be
substituted;

(b)

the words and symbol “, PWD roads” shall be omitted;

In rule 61,—
(a)

in sub-rule(1),—
(i)

for the words and symbols “F.S.I permissible” wherever it occurs, the
words and symbols “maximum F.S.I permissible” shall be substituted;

(ii)

for the word, figures and brackets “rule 27(2)” , the words, figures and
brackets “27(2) of the respective occupancy” shall be substituted ;

(23)
in rule 67, the words and symbols “or cattle shed for keeping not more than six
cattle and their calves or cage/aviary for keeping not more than twenty hens or ducks” shall be
omitted;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 18 -->

18

(24)
in rule 74, in sub-rule (1), for the letter and figures “1.8m”, the letter and figures
“2.4m” shall be substituted;
(25)
in rule 76,—in sub-rule(2), in clause (1) after the words “hazardous occupancy
buildings”, the words figures and symbols, “storage occupancy buildings and single family
residential buildings constructed in plots having area less than 5cents and/or having built-up
area upto 300sq.metres” shall be inserted;
(26)
in rule 77,—for the words “so as to generate 5% of the connected load” the
words “covering a minimum of 50 % of the roof area” shall be substituted;
(27)

in rule 78,—

in sub-rule (6), the words and symbols “for at least 1/5 of the design capacity”
shall be omitted;
(28)

In rule 79,—
(a)

in sub-rule (4) the following shall be added at the end namely “for single
family residential buildings, this distance shall be reduced to 30
centimeters”

(b)

for sub-rule (6), the following sub-rule shall be substituted, namely:—
“Water Reuse for gardening etc.: All buildings under Group A1
(Residential apartments only) and A2 occupancy having total built-up area
more than 2000 sq. metres and all buildings under B, C, D, E, F and J
occupancies having total built-up area more than 5000 sq. meters and all
buildings under G1, G2 and I occupancy where there is industrial effluent
discharge shall incorporate in-situ liquid waste treatment plant and special
provision for reusing treated waste water generated out of the use of
water.”;

(c)

sub-rule (7) shall be omitted;

(29) after rule 79, the following rule shall be inserted namely:—
“79A Management of Construction and Demolition Waste—(1) Every permit
holder for construction of a building, and for demolition of an existing building or
concrete structure shall be responsible for safe disposal of waste generated during
the process of such
construction and demolition in accordance with the
Construction and Demolition Waste Management Rules, 2016.
(2) The Government shall from time to time fix the Waste disposal charges for
municipalities or a group of municipalities payable by applicants at the time of
submitting applications seeking permits. It shall be competent for Government to
fix differential charges depending on load and distance factor.
(3) The Government shall in consideration of the provisions of the said Rules by
notification provide for mechanisms for transportation, utilization, processing and

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 19 -->

19

downstream uses of the finished and intermediary products for construction and
other purposes including their mandatory usage in specific types of infrastructure.

(4) Municipalities shall establish or cause to establish waste processing facilities for
such wastes on Public Private Partnership mode or outsourced model or lease
franchise model or on any structure utilizing the funds accrued from the charges
and other receipts with them including plan fund.
(5) The Government shall provide technical and financial support to Municipalities
for the above purposes”.
(30) In rule 80, for the figure “4”, the figure “5” shall be substituted;
(31) In rule 81, in sub-rule (2), in clause (i), for the words, figures and symbols “1.50
metres”, the words, figures and symbols “1.20 metres” shall be substituted;
(32) In rule 90, in sub-rule (3), the following shall be inserted at the beginning, namely:—
“Where the owner or the person for whom the work is done fails to show cause to the
satisfaction of the Secretary, the Secretary may confirm the order or modify the same to
such extent as he may think fit to make, and such order shall then be binding on the owner
or the person for whom the work is done and on the failure to comply with the order, the
Secretary may himself cause the building or part thereof demolished or the well
dismantled, as the case may be, and the expenses thereof shall be recoverable from the
owner or such person:”;
(33) In Appendix E1, E2, E3, E4 for the word “certificate” the word “report” shall be
substituted;
(34) In these rules, for the words “completion certificate”, wherever it occurs the words
“completion report” shall be substituted;
(35) In these rules, for the word, “The Kerala Urban Arts Commission” the words, “The
Art and Heritage Commission” shall be substituted;
(36) In the Appendices—
(i) For ‘Appendix A1’, the following Appendix shall be substituted, namely:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 20 -->

20

APPENDIX- A1
[See rules 5(1)(b), 75(1), 87(1) and 93(1)]
APPLICATION FOR PERMIT/REGULARISATION
…………………………………………………………. Municipal Corporation / Municipal
Council / Town Panchayat
1. Name in capital letters

:

2. Address:
(i)

3.

Permanent address of the owner

:

(ii) To which communications are to be sent

:

Nature of development/construction:
(i)

Division of plot

:

(ii) New construction

:

(iii) Reconstruction

:

(iv) Alteration/Addition/Extension
(v) Digging of well
(vi) Change in occupancy
(vii) Demolition
(viii) Roof changing
4. Details of plot
(i) Revenue Village
(ii) (a) Survey No.
(b) Resurvey No.
(iii) Sub Division
(iv) Taluk
(v) District
(vi) Extent in Sq.m

:
:
:
:
:
:
:

(vii) Nature of ownership

:

(viii) Number and date of Deed/Document

:

(ix) Registrar’s Office

:

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 21 -->

21

(x)

5.

Ward No.

:

(xi) Authorised number of the nearest building

:

(xii)

:

Nearest Electric Post/Telecom Post number

Whether the land, if any, contiguous to this plot
of the owner shown in the site plan [Rule 6(4)(a)(i)]

: Yes /No

6. Usage of surrounding plots in general
North

:

East

:

South

:

West

:

7 . Whether Government or Quasi Government

:

8. Details of the Construction
(i) Details of Proposed Building(s)

Floors

Building No. 1

Building No. 2

Occupancy:
Height of the building — …………..m
Use
Built-up
Area
Floor
area
provided
area
(Sq.m.)
for
(Sq.m.)
parking
inside the
building
(Sq.m.)

Occupancy :
Height of the building — …………… m
Use
Built-up
Area
Floor
area
provided for
area
(Sq.m.)
parking
(Sq.m.)
inside the
building
(Sq.m.)

Basement
floor
Ground
floor

Total
Add separate sheet if required, duly signed by both the licensee and the Owner.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 22 -->

22

(ii) Details of Existing Building(s)

Floors

Building No. 1

Building No. 2

Occupancy:
Height of the building — …………..m
Use
Built-up
Area
Floor
area
provided
area
(Sq.m.)
for
(Sq.m.)
parking
inside the
building
(Sq.m.)

Occupancy :
Height of the building — …………… m
Use
Built-up
Area
Floor area
area
provided for
(Sq.m.)
(Sq.m.)
parking
inside the
building
(Sq.m.)

Basement
floor
Ground
floor

Total

Add separate sheet if required, duly signed by both the licensee and the Owner.
(iii) Total Built-up Area

:

(iv) Total Covered Area

:

(v) Total parking area provided inside the building(s):

9.

(vi) Total Floor Area

:

(vii) Estimated cost of construction

:

Basic KMBR Verification w.r.t. proposed plot
Sl.

Rule

No.

No.

Description

1

Access width to the plot

2

Coverage

3

Floor Space Index

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

Required/permissible

Provided

<!-- page 23 -->

23

10. Basic KMBR Verification w.r.t. proposed building(s)
(a) Building No. 1
Sl.
No.
1
2

3
4
5
6
7
8

9
10
11
12

Rule No.

Description

Required/permissible

Provided

Access width to the building (in
m)
Minimum distance from the
abutting road/access to other
building(s) (in metre)
No. of Four-wheeler parking
Area of Two-wheeler parking
No. of Parking for Differently
abled
No. of Parking for Visitors
Loading/unloading space (in sq.
metre)
Set Backs (in metre)
Front
Side 1
Side 2
Rear
Exit Width (in metre)
No. of Stair case(s)
No. of Fire Escape Stair case(s)
Rainwater storage capacity (in
litre)

Add separate sheet if required, duly signed by both the licensee and the Owner.

11. Provisions of Town Planning Schemes, if any, applicable to the construction
(i) Zoning
Sl.
No.

Name of the TP
Scheme

Stage
(Sanctioned/
Published)

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

Zone

Permissibility of proposed
construction as per the scheme

<!-- page 24 -->

24

(ii) Road Widening

Sl.
No.

Name of
the TP
Scheme

Existing
Proposed
Stage
Width of
Width of
(Sanctioned/
road
(in road (in
Published)
m)
m)

Building
Line
(in m)

Set Back
Required
from
Existing
road
boundary
(in m)

Set back
provided
(in m)

12. Permissibility with respect to Kerala Conservation
of Paddy Land and Wet and Act 2008 / KLU order 1967:

13.

(k) Type of land as per BTR
(iv) Type of land as per Data Bank
If the application is for regularisation,

:
:

(i) Whether construction completed or not

:

(ii) If not completed, the stage of construction

:

14. Details of permit/approved plan already obtained.
15. Details of fee paid:

Application fee

Layout scrutiny fee

(i) Amount
(ii) No. and date of receipt
16.

Details of documents, plans, certificate, etc. enclosed.

17.

Details of NOC obtained.

Sl.
No.

Required

Whether enclosed or not

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

Details of the NOC / Clearances

<!-- page 25 -->

25

18.

DECLARATION
I,…………………………………………………………….………………hereby declare

that the measurements, specifications and other details mentioned above are correct, complete
and true to the best of my knowledge and belief and that I shall abide by the approved plan and
the provisions in the Act and Rules in undertaking the construction.

Place:

Signature of the applicant with name

Date:

19.

CERTIFICATE
Certified that the site plan is prepared after verification of ownership document and site

and the measurements shown are found to be correct.

Signature:
Name:

Place:

Reg.No.:

Date:

Address:
(Registered Institution, Architect, Engineer,
Town Planner, Supervisor)

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 26 -->

26

20.

CERTIFICATE
Certified that the building plan is prepared in accordance with the provisions in the

Kerala Municipality Building Rules 2019, Kerala Municipality Act, 1994 and the provisions
contained in the sanctioned Town Planning Schemes, if any.

Place:

Signature:

Date:

Name:
Reg.No.:
Address:
(Registered Institution/Architect/ Engineer/
Town Planner/Supervisor)

21.

UNDERTAKING
I,………………………………………………..hereby

undertake

that

the

building

construction and/or land development will be carried on/ being carried on/ was carried on as per
the approved plan and permit in accordance with the rules in force.

Place:

Signature:

Date:

Name:
Reg.No.:
Address:
(Registered Institution/
Architect/Engineer/Town Planner/
Supervisor)

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 27 -->

27

For “Appendix A4”, the following “APPENDIX” shall be substituted namely:-

i.

Appendix-A4
[See rule 5(6)(2)]
APPLICATION FOR LAYOUT APPROVAL AND USAGEOF PLOT/CONCURRENCE
………………………………………………………….District
1. Name in capital letters

:

2. Address:

3.

(i) Permanent address of the owner

:

(ii) To which communications are to be sent

:

Nature of development/construction:
(i) Division of plot

:

(ii) New construction

:

(iii) Reconstruction

:

(iv) Alteration /Addition/Extension

:

(v) Change in occupancy

:

4. Details of plot
(i) Name of Local Self Government Institution

:

(ii) Revenue Village

:

(iii) (a) Survey No.

:

(b) Resurvey No.

:

(iv) Sub Division
(v) Taluk

:

(vi) District

:

(vii) Extent is Sq.m

:

(viii) Nature of ownership

:

(ix) Ward No.

:

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 28 -->

28

(x) Authorised number of the nearest building

:

(xi) Nearest Electric Post/Telecom Post number

:

5. Whether the land, if any, contiguous to this plot
of the owner shown in the site plan [Rule 6(4)(a)(i)]:

Yes /No

6. Usage of surrounding plots in general
North

:

East

:

South

:

West

:

7. Whether Government or Quasi Government

:

8. Details of the proposed construction

(i) Details of Proposed Building(s)

Floors

Building No. 1
Building No. 2
Occupancy:
Occupancy :
Height of the building—…………..m Height of the building—…………… m
Use
BuiltArea
Floor
Use
Built-up
Area
Floor
up area provided
area
area
provided
area
(Sq.m.)
for
(Sq.m.)
(Sq.m.) for parking (Sq.m.)
parking
inside the
inside the
building
building
(Sq.m.)
(Sq.m.)

Baseme
nt floor
Ground
floor

Total
Add separate sheet if required, duly signed by both the licensee and the Owner

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 29 -->

29

(ii) Details of Existing Building(s)

Floors

Building No. 1
Building No. 2
Occupancy:
Occupancy :
Height of the building—…………..m Height of the building—…………… m
Use
BuiltArea
Floor
Use
Built-up
Area
Floor
up area provided
area
area
provided
area
(Sq.m.)
for
(Sq.m.)
(Sq.m.) for parking (Sq.m.)
parking
inside the
inside the
building
building
(Sq.m.)
(Sq.m.)

Baseme
nt floor
Ground
floor

Total
Add separate sheet if required, duly signed by both the licensee and the Owner.
(iii) Total Built-up Area

:

(iv) Total Covered Area

:

(v) Total parking area provided inside the building(s)

:

(vi) Total Floor Area

:

(vii) Estimated cost of construction

:

9.

Basic KMBR Verification w.r.t. proposed plot

Sl. No.

Rule No.

Description

1

Access to the plot

2

Coverage

3

Floor Space Index

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

Required/Permissible

Provided

<!-- page 30 -->

30

10. Basic KMBR Verification w.r.t. proposed building(s)
(a) Building no. 1
Sl.
No.
1
2

Rule No.

Description

Required/Permissible

Provided

Access to the building (in metre)
Minimum distance from the
abutting road/access to other
building(s) (in metre)

3

No. of Four-wheeler parking

4

Area of Two-wheeler parking

5

No. of Parking for Differently
abled

6

No. of Parking for Visitors

7

Loading/unloading space
(in sq. m)

8

Set Backs (in m)
Front
Side 1
Side 2
Rear

9

Exit Width (in m)

10

No. of Stair case(s)

11

No. of Fire Escape Stair case(s)

12

Rainwater storage capacity (in
litre)

Add separate sheet if required, duly signed by both the licensee and the Owner.
11. Provisions of Town Planning Schemes, if any, applicable to the construction
(i) Zoning
Sl.
No.

Name of the TP
Scheme

Stage
(Sanctioned/
Published)

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

Zone

Permissibility of proposed
construction as per the scheme

<!-- page 31 -->

31

(ii) Road Widening

Sl.
No.

Name of
the TP
Scheme

Stage
(Sanctioned/
Published)

Existing
Width of
road(in
metre)

Proposed
Width of
road(in
metre)

Building
Line(in
metre)

Set Back
Required
from
Existing
road
boundary(in
metre)

Set back
provided
(in
metre)

12. If the application is for regularisation,
(i) Whether construction completed or not

:

(ii) If not completed, the stage of construction

:

13. Details of permit/layout approval already obtained.
14. Details of fee paid:

Application fee

Layout scrutiny fee

(i) Amount
(ii) No. and date of receipt
15. Details of documents, plans, certificate, etc. enclosed.
16.

Details of NOC / Clearances obtained.

SL .
No

Required

Whether enclosed or not

Details of the NOC / Clearances

17. Whether application for permit /regularisation is submitted to the Local Self Government
Institution: Yes/No
If Yes, file no. of the application in the Local Self Government Institution :
18.

DECLARATION

I,…………………………………………………………….………………hereby declare
that the measurements, specifications and other details mentioned above are correct, complete
and true to the best of my knowledge and belief and that I shall abide by the approved plan and
the provisions in the Act and Rules in undertaking the construction.
Place:

Signature of the applicant with name

Date:

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 32 -->

32

19.

CERTIFICATE

Certified that the site plan is prepared after verification of ownership document and site
and the measurements shown are found to be correct.
Signature:
Name:
Place:

Reg.No.:

Date:

Address:
(Registered Institution, Architect, Engineer,
Town Planner, Supervisor)

20.

CERTIFICATE

Certified that the building plan is prepared in accordance with the provisions in the
Kerala Municipality Building Rules, 2019, Kerala Municipality Act, 1994 and the provisions
contained in the sanctioned Town Planning Schemes, if any.
Place:

Signature:

Date:

Name:
Reg.No.:
Address:
(Registered Institution/Architect/ Engineer/
Town Planner/Supervisor)

21.

UNDERTAKING

I,………………………………………………..hereby undertake that the building
construction and/or land development will be carried on/ being carried on/ was carried on as per
the approved plan and permit in accordance with the rules in force.

Place:
Date:

Signature:
Name:
Reg.No.:
Address:
(RegisteredInstitution/ Architect/Engineer/Town
Planner/Supervisor)

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 33 -->

33

(iii)
namely:—

For “APPENDIX B2”, the following “APPENDIX” shall be substituted,

APPENDIX B2
[See rule 6(17)&9(4)]
SITE APPROVAL AND BUILDING PERMIT
…………………………………………………………………….Municipal Corporation/
Municipal Council / Town Panchayat
No. ……………………………………

Dated….…………

Ref.:—Application dated……………………….from Sri/Smt. ………...…………………
Site approval and permission is granted for the erection/re-erection/addition/alteration of
building/ hut/ digging of well/......…………………………(specify the construction) in building
No. ……………………or near the building No. ………………..............................in Survey/
Re-survey No. ……………………………………………. Village………………………………
Taluk…………………………………...……District…………….………………………………
for………………………………………(specify the occupancy) purpose subject to the
conditions stated below:
(1) Adequate safety measures shall be ensured for protection against damage to health, life,
buildings and property of the workers and inhabitants around, during and after building
construction. The owner and the developer shall be solely responsible for any such damages.
(2)

……………………………………………………………………….

(3)

………………………………………………………………………..

(4)

………………………………………………………………………..

(a) Set backs (m) (minimum & average)
Building 1 Front

Rear Side

Side - 1

Side 2

Building 2 Front

Rear Side

Side - 1

Side 2

Building 3 Front

Rear Side

Side - 1

Side 2

(b ) Plot Area (sq. m)—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 34 -->

34

(c) FSI:

Coverage:

(d) Details of proposed building

Floors

Building No. 1

Building No. 2

Occupancy:
Height of the building…………..m
Use
Built-up
Area
Floor
area
provided
area
(Sq.m.)
for
(Sq.m.)
parking
inside the
building
(Sq.m.)

Occupancy :
Height of the building…………… m
Use
Built-up
Area
Floor area
area
provided for
(Sq.m.)
(Sq.m.)
parking
inside the
building
(Sq.m.)

Basement
floor
Ground
floor

Total

Signature and name of Secretary.

(Seal)

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 35 -->

35

(iv) For “APPENDIX C”, the following APPENNDIX shall be substituted, namely—
APPENDIX C
[See rule 10 (7)]
Concurrence/Usage of Plot
No. ……………………………………….
Dated….……………….……
Name of the Local Self Government Institution:
____________________________________________________________________________
Ref.:— (1) Application dated…………..…………….from Sri/Smt. ……………………
……………………………………………….….…
(2) Permit No. ……………………………
Dated……………………
Concurrence is granted for proceeding with the construction above the ground level as
per the permit cited in ref (2) for…………………………………………………………
(specify the construction) in building No:……………………………..………………………or
near the building No. …………..…… in Survey No./Re-Survey No. …….…………………in
……………………………………..……Village in......................Taluk in……………………
District …………………………………for ………………………......……… (specify the
occupancy) purpose subject to the conditions stated below:
(i)
……………………………………………………………………….
(ii)
……………………………………………………………………….
(iii)
………………………………………………………………………..
(iv)
………………………………………………………………………..
(1) Built-up area and Floor area of the building are as follows:—
Floor
Basement Floor
Ground Floor
First Floor
…………………..……
………………………..
Total

Built-up area (sq.m.)

(2) FSI

Coverage

Floor area (sq.m.)

(3) Access width (m)

Place:
Date:

Signature and name of Secretary.
(Seal)

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 36 -->

36

(v) For “APPENDIX G1”, the following “APPENDIX” shall be substituted, namely :—
APPENDIX G1
[See rule 95 (3)]
……………………………………………………………………Municipal Corporation/
Municipal Council / Town Panchayat
Abstract
BUILDING CONSTRUCTION/LAND DEVELOPMENT WITHOUT PERMISSION OR
DEVIATION FROM APPROVED PLAN-REGULARISATION GRANTED—ORDERS
ISSUED
Ref.— Application dated…………………….from Sri/Smt………………..……………..
No. ………………………………………………………Dated …………………………

ORDER
WHEREAS the application submitted by Sri/Smt. ………………….……………………
for regularisation of a construction or reconstruction or alteration or addition of
………………………. (specify the use)building/hut/shed/wall/erection of telecommunication
tower or pole structure/ digging of well/ conversion of roof/conversion or erection of shutter or
door/ land development/ any other work (………………..………specify) commenced/being
carried on / completed in the land comprised in Sy. No/Resurvey No. ………………
Village......................…………………… Taluk……………………………………… District
……………………………………………in the building bearing No…………………………
/near the building

bearing No………………… has been duly considered by me and decision

to regularise the same has been communicated in letter No. ………………………….
dated…………………………
AND WHEREAS the said Sri/Smt………………………………………………has remitted
Rs. …………………….…as compounding fee …………………………………….……….vide
receipt No. ……………….…………..… dated………………………………………….and has
complied

with

the

directions/conditions

dated………………………………..

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

stipulated

in

the

letter

<!-- page 37 -->

37

NOW, THEREFORE, in exercise of the powers conferred by Section 406 of the Kerala
Municipality

Act

1994,

I

…………………………………. (name), Secretary of the

……………………………………………Municipal

Corporation/Municipal

Council/Town

Panchayat hereby order that the said person has been absolved from the liabilities in respect of
the construction or reconstruction or alteration or addition of ….................……………………..
(specify the use) building/hut/ shed/wall/erection of telecommunication tower or pole structure/
digging of well/ conversion of roof/conversion or erection of shutter or door/land development
/ any other work (………………..………specify)and that the construction or reconstruction or
alteration

or

addition

of

………………………..

(specify

the

use)

building/hut/shed/wall/erection of telecommunication tower or pole structure/digging of well /
conversion of roof / conversion or erection of shutter or door/ land development/any other work
(………………..………specify)has been regularised.
Built-up area and Floor area of the regularized part of the building are as follows:—
Floor
Basement Floor

Built-up area (sq.m.)

Floor area (sq.m.)

Ground Floor
First Floor
………………………..
………………………..
Total

(Continuation of the work, if any, as per the drawings submitted shall be subject to permit
No. ………….............. dated ………………………. being issued herewith.) (strike off if not
applicable)
Plans and details of the construction regularised are appended with this order.

Signature of Secretary.
(Seal)

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 38 -->

38

For “APPENDIX G2” the following “APPENDIX” shall be substituted namely:—
APPENDIX G2
[See rule 95 (3)]
REGISTER FOR REGULARISED CONSTRUCTIONS
…...............................………………………………………………… Municipal Corporation / Municipal Council / Town Panchayat
(vi)

Sl.
No.

Name and
address of
applicant/
owner

Date of
application
with date of
receipt

Details of
amount etc.
of
application
fee paid

1

2

3

4

Details of
Details of
total built-up total floor
area of
area of
building
building
existing/
existing/
regularised regularised

5

6

Area of land
survey No./
Re-survey No.
Village, Taluk,
etc.

7

Date and No. Amount, date
Details of
of intimation
etc, of
regularization
permitting
regularization order issued
regularization
fee paid
with date of
despatch

8

9

10

Remarks

11

(vii) In Appendix E3, E4, F1 and F2 , the words and symbols “Enclosure: Completion Plan” shall be added at the end;
(viii) In Appendix H2,—
(i) In Appendix-H2, in the qualifications for Engineer B the following shall be added at the end, namely.—
“(ii) Any person having 3 years of experience as Supervisor Senior”;
(ii) in the functions for the category Supervisor Senior, the words and symbols “(iii) To prepare and sign layout plans upto one
hectare” shall be added;
(iii) in the functions for the category Supervisor A, the words and symbols “(iii) To prepare and sign layout plans up to one hectare”
shall be added;
By order of the Governor,
BISHWANATH SINHA,
Principal Secretary to Government.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 39 -->

39

Explanatory Note
(This does not form part of the notification, but is intended to indicate its general purport.)
As per notification issued under G.O. (P)No.77/2019/LSGD dated 2nd November, 2019
and published as S.R.O. No. 828/2019 in the Kerala Gazette Extraordinary No.2691 dated,
8th November, 2019, the Government have framed the Kerala Municipality Building Rules, 2019,
for carrying out the purposes of the Kerala Municipality Act, 1994 (20 of 1994) by superseding
the notification issued under G.O. (Ms.) No.188/99/LSGD dated, 1st October 1999 and published
as S.R.O No. 777/99 in the Kerala Gazettee Extraordinary No.1786 dated 1st October, 1999. Now
the Government have decided to make suitable amendments to the said rules.
The notification is intended to achieve the above object.

____________________________________________________________________________________________________________________________
PUBLISHED BY THE SUPERINTENDENT OF GOVERNMENT PRESSES
AT THE GOVERNMENT CENTRAL PRESS, THIRUVANANTHAPURAM, 2020
This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/
