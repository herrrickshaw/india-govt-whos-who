---
doc_id: "e466dedaeeb01e9d"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 28
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f9f8805152af02e5"
---

<!-- page 1 -->

(To be published in the Gazette of India, Extraordinary, Part-II, Section 3, Sub-section (ii) of dated
the 6th January, 2011)
COASTAL REGULATION ZONE NOTIFICATION
MINISTRY OF ENVIRONMENT AND FORESTS
(Department of Environment, Forests and Wildlife)
S.O.19(E).- WHEREAS a draft notification under sub-section (1) of section and clause (V) of subsection (2) of section 3 of the Environment (Protection) Act, 1986 was issued inviting objections and
suggestions for the declaration of coastal stretches as Coastal Regulation Zone and imposing
restrictions on industries, operations and processes in the CRZ was published vide S.O.No.2291 (E),
dated 15th September, 2010.;
AND WHEREAS, copies of the said Gazette were made available to the public on 15th
September, 2010.;
AND WHEREAS, the suggestions and objections received from the public have been
considered by the Central Government.;
Now, therefore, in exercise of the powers conferred by sub-section (1) and clause (v) of
sub-section (2) of section 3 of the Environment (Protection) Act, 1986 (29 of 1986), the Central
Government, with a view to ensure livelihood security to the fisher communities and other local
communities, living in the coastal areas, to conserve and protect coastal stretches, its unique
environment and its marine area and to promote development through sustainable manner based on
scientific principles taking into account the dangers of natural hazards in the coastal areas, sea level
rise due to global warming, does hereby, declare the coastal stretches of the country and the
water area upto its territorial water limit, excluding the islands of Andaman and Nicobar and
Lakshadweep and the marine areas surrounding these islands upto its territorial limit, as Coastal
Regulation Zone (hereinafter referred to as the CRZ) and restricts the setting up and expansion of
any industry, operations or processes and manufacture or handling or storage or disposal of
hazardous substances as specified in the Hazardous Substances (Handling, Management and
Transboundary Movement) Rules, 2009 in the aforesaid CRZ.; and
In exercise of powers also conferred by clause (d) and sub rule (3) of rule 5 of Environment
(Protection) Act, 1986 and in supersession of the notification of the Government of India in the
Ministry of Environment and Forests, number S.O.114(E), dated the 19th February, 1991 except as
respects things done or omitted to be done before such supercession, the Central Government
hereby declares the following areas as CRZ and imposes with effect from the date of the
notification the following restrictions on the setting up and expansion of industries, operations or
processes and the like in the CRZ,(i) the land area from High Tide Line (hereinafter referred to as the HTL) to 500mts on the
landward side along the sea front.
(ii) CRZ shall apply to the land area between HTL to 100 mts or width of the creek
whichever is less on the landward side along the tidal influenced water bodies that are
connected to the sea and the distance upto which development along such tidal
influenced water bodies is to be regulated shall be governed by the distance upto which
the tidal effects are experienced which shall be determined based on salinity concentration
of 5 parts per thousand (ppt) measured during the driest period of the year and distance
upto which tidal effects are experienced shall be clearly identified and demarcated
accordingly in the Coastal Zone Management Plans (hereinafter referred to as the CZMPs).

<!-- page 2 -->

2

Explanation.- For the purposes of this sub-paragraph the expression tidal influenced water
bodies means the water bodies influenced by tidal effects from sea, in the bays, estuaries,
rivers, creeks, backwaters, lagoons, ponds connected to the sea or creeks and the like.
(iii)

the land area falling between the hazard line and 500mts from HTL on the
landward side, in case of seafront and between the hazard line and 100mts line in case of
tidal influenced water body the word ‘hazard line’ denotes the line demarcated by Ministry
of Environment and Forests (hereinafter referred to as the MoEF) through the Survey of
India (hereinafter referred to as the SoI) taking into account tides, waves, sea level rise and
shoreline changes.

(iv) land area between HTL and Low Tide Line (hereinafter referred to as the LTL) which
will be termed as the intertidal zone.
(v) the water and the bed area between the LTL to the territorial water limit (12 Nm) in case of
sea and the water and the bed area between LTL at the bank to the LTL on the opposite side
of the bank, of tidal influenced water bodies.
2.
For the purposes of this notification, the HTL means the line on the land upto which the
highest water line reaches during the spring tide and shall be demarcated uniformly in all parts of
the country by the demarcating authority(s) so authorized by the MoEF in accordance with the
general guidelines issued at Annexure-I. HTL shall be demarcated within one year from the date of
issue of this notification.
3.
Prohibited activities within CRZ,- The following are declared as prohibited activities
within the CRZ,(i) Setting up of new industries and expansion of existing industries except,(a) those directly related to waterfront or directly needing foreshore facilities;
Explanation: The expression “foreshore facilities” means those activities permissible under
this notification and they require waterfront for their operations such as ports and harbours,
jetties, quays, wharves, erosion control measures, breakwaters, pipelines, lighthouses,
navigational safety facilities, coastal police stations and the like.;
(b) projects of Department of Atomic Energy;
(c) facilities for generating power by non-conventional energy sources and setting up of
desalination plants in the areas not classified as CRZ-I(i) based on an impact assessment
study including social impacts.;
(d) development of green field Airport already permitted only at Navi Mumbai;
(e) reconstruction, repair works of dwelling units of local communities including fishers in
accordance with local town and country planning regulations.
(ii) manufacture or handling oil storage or disposal of hazardous substance as specified in the
notification of Ministry of Environment and Forests, No. S.O.594 (E), dated the 28th July
1989, S.O.No.966(E), dated the 27th November, 1989 and GSR 1037 (E), dated the 5th

<!-- page 3 -->

3

December ,1989 except,(a) transfer of hazardous substances from ships to ports, terminals and refineries and vice
versa;
(b) facilities for receipt and storage of petroleum products and liquefied natural gas as
specified in Annexure-II appended to this notification and facilities for
regasification of Liquefied Natural Gas (hereinafter referred to as the LNG) in the areas
not classified as CRZ- I(i) subject to implementation of safety regulations including
guidelines issued by the Oil Industry Safety Directorate in the Ministry of Petroleum and
Natural Gas and guidelines issued by MoEF and subject to further terms and conditions
for implementation of ameliorative and restorative measures in relation to environment as
may be stipulated by in MoEF.
Provided that facilities for receipt and storage of fertilizers and raw materials
required for manufacture of fertilizers like ammonia, phosphoric acid, sulphur,
sulphuric acid, nitric acid and the like, shall be permitted within the said zone in the
areas not classified as CRZ-I(i).
(iii) Setting up and expansion of fish processing units including warehousing except hatchery
and natural fish drying in permitted areas:
(iv) Land reclamation, bunding or disturbing the natural course of seawater except those,(a) required for setting up, construction or modernisation or expansion of foreshore
facilities like ports, harbours, jetties, wharves, quays, slipways, bridges, sealink, road on
stilts, and such as me ant for defence and security purpose and for other facilities
that are essential for activities permissible under the notification;
(b) measures for control of erosion, based on scientific including Environmental Impact
Assessment (hereinafter referred to as the EIA) studies
(c) maintenance or clearing of waterways, channels and ports, based on EIA studies;
(d) measures to prevent sand bars, installation of tidal regulators, laying of storm water drains
or for structures for prevention of salinity ingress and freshwater recharge based on
carried out by a n y a g e n c y t o b e s p e c i fi e d b y M o EF .
(v) Setting up and expansion of units or mechanism for disposal of wastes and effluents except
facilities required for,(a) discharging treated effluents into the water course with approval under the Water
(Prevention and Control of Pollution) Act, 1974 (6 of 1974);
(b) storm water drains and ancillary structures for pumping;
(c) treatment of waste and effluents arising from hotels, beach resorts and human settlements
located in CRZ areas other than CRZ-I and disposal of treated wastes and effluents;
(vi) Discharge of untreated waste and effluents from industries, cities or towns and other
human settlements. T he concerned authorities s h a l l i m p l e m e n t s c h e m e s for phasing
out existing discharge of this nature, if any, within a time period not exceeding two years
from the date of issue of this notification.
(vii) Dumping of city or town wastes including construction debris, industrial solid wastes, fly

<!-- page 4 -->

4

ash for the purpose of land filling and the like and the concerned authority shall implement
schemes for phasing out any existing practice, if any, shall be phased out within a period
of one year from date of commencement of this notification.
Note:-The MoEF will issue a separate instruction to the State Governments and Union territory
Administration in respect of preparation of Action Plans and their implementation as also
monitoring including the time schedule thereof, in respect of paras (v), (vi) and (vii).
(viii) Port and harbour projects in high eroding stretches of the coast, except those projects
classified as strategic and defence related in terms of EIA notification, 2006 identified by
MoEF based on scientific studies and in consultation with the State Government or the Union
territory Administration.
(ix) Reclamation for commercial purposes such as shopping and housing complexes, hotels
and entertainment activities.
(x) Mining of sand, rocks and other sub-strata materials except,(a)those rare minerals not available outside the CRZ area,
(b) exploration and exploitation of Oil and Natural Gas.
(xi) Drawl of groundwater and construction related thereto, within 200mts of HTL; except the
following:(a) in the areas which are inhabited by the local communities and only for their use.
(b) In the area between 200mts-500mts zone t h e d r a w l o f g r o u n d w a t e r shall be
permitted only when done manually through ordinary wells for drinking, horticulture,
agriculture and fisheries and where no other source of water is available.
Note:-Restrictions for such drawl may be imposed by the Authority designated by the State
Government and Union territory Administration in the areas affected by sea water
intrusion.
(xi) Construction activities in CRZ-I except those specified in para 8 of this notification.
(xiii) Dressing or altering the sand dunes, hills, natural features including landscape
changes for beautification, recreation and other such purpose.
(xiv) Facilities required for patrolling and vigilance activities of marine/coastal police stations.
4.
Regulation of permissible activities in CRZ area.- The following activities shall be
regulated except those prohibited in para 3 above,(i)(a) clearance shall be given for any activity within the CRZ only if it requires
waterfront and foreshore facilities;
(b) for those projects which are listed under this notification and also attract EIA notification,
2006 (S.O.1533 (E), dated the 14th September, 2006), for such projects clearance under
EIA notification only shall be required subject to being recommended by the concerned
State or Union territory Coastal Zone Management Authority (hereinafter referred to as the
CZMA).
(c) Housing schemes in CRZ as specified in paragraph 8 of this notification;

<!-- page 5 -->

5

(d) Construction involving more than 20,000sq mts built-up area in CRZ-II shall be considered in
accordance with EIA notification, 2006 and in case of projects less than 20,000sq mts built-up
area shall be approved by the concerned State or Union territory Planning authorities in
accordance with this notification after obtaining recommendations from the concerned CZMA
and prior recommendations of the concern CZMA shall be essential for considering the grant
of environmental clearance under EIA notification, 2006 or grant of approval by the relevant
planning authority.
(e) MoEF may under a specific or general order specify projects which require prior public
hearing of project affected people.
(f) construction and operation for ports and harbours, jetties, wharves, quays, slipways, ship
construction yards, breakwaters, groynes, erosion control measures;
(ii) t h e following activities shall require clearance from MoEF, namely:(a) those activities not listed in the EIA notification, 2006.
(b) construction activities relating to projects of Department of Atomic Energy or Defence
requirements for which foreshore facilities are essential such as, slipways, jetties, wharves,
quays; except for classified operational component of defence projects. Residential buildings,
office buildings, hospital complexes, workshops of strategic and defence projects in terms of
EIA notification, 2006.;
(c) construction, operation of lighthouses;
(d) laying of pipelines, conveying systems, transmission line;
(e) exploration and extraction of oil and natural gas and all associated activities and facilities
thereto;
(f) Foreshore requiring facilities for transport of raw materials, facilities for intake of cooling
water and outfall for discharge of treated wastewater or cooling water from thermal power
plants. MoEF may specify for category of projects such as at (f), (g) and (h) of para 4;
(g) Mining of rare minerals as listed by the Department of Atomic Energy;
(h) Facilities for generating power by non-conventional energy resources, desalination plants and
weather radars;
(i) Demolition and reconstruction of (a) buildings of archaeological and historical importance, (ii)
heritage buildings; and buildings under public use which means buildings such as for the
purposes of worship, education, medical care and cultural activities;
4.2
Procedure for clearance of permissible activities.- All projects attracting this notification
shall be considered for CRZ clearance as per the following procedure, namely:(i) The project proponents shall apply with the following documents seeking prior clearance
under CRZ notification to the concerned State or the Union territory Coastal Zone
Management Authority,(a) Form-1 (Annexure-IV of the notification);
(b) Rapid EIA Report including marine and terrestrial c o m p o n e n t e x c e p t f o r
construction projects listed under 4(c) and (d)
( c ) Comprehensive EIA with cumulative studies for projects in the stretches classified as low
and medium eroding by MoEF based on scientific studies and in consultation with the State
Governments and Union territory Administration;
(d) Disaster Management Report, Risk Assessment Report and Management Plan;
(e) CRZ map indicating HTL and LTL demarcated by o n e o f t h e authorized agency (as
indicated in para 2) i n 1:4000 scale;
(f) Project layout superimposed on the above map indicated at (e) above;

<!-- page 6 -->

6

(g) The CRZ map normally covering 7km radius around the project site.
(h) The CRZ map indicating the CRZ-I, II, III and IV areas including other notified
ecologically sensitive areas;
(i) No Objection Certificate from the concerned State Pollution Control Boards or Union
territory Pollution Control Committees for the projects involving discharge of effluents,
solid wastes, sewage and the like.;
(ii) The concerned CZMA shall examine the above documents in accordance with the
approved CZMP and in compliance with CRZ notification and make recommendations within
a period of sixty days from date of receipt of complete application,(a) MoEF or State Environmental Impact Assessment Authority (hereinafter referred to as the
SEIAA) as the case may be for the project attracting EIA notification, 2006;
(b) MoEF for the projects not covered in the EIA notification, 2006 but attracting para 4(ii) of
the CRZ notification;
(iii) MoEF or S E I A A shall consider such projects for clearance based on the
recommendations of the concerned CZMA within a period of sixty days.
(vi) The clearance accorded to the projects under t h e CRZ n otification shall be valid for the
period of five years from the date of issue of the clearance for commencement of construction
and operation.
(v) F o r Post clearance monitoring – (a) it shall be mandatory for the project proponent to
submit half-yearly compliance reports in respect of the stipulated terms and conditions of
the environmental clearance in hard and soft copies to the regulatory authority(s)
concerned, on 1st June and 31st December of each calendar year and all such compliance
reports submitted by the project p r o p o n e n t shall be published in public domain and its
copies shall be given to any person on application to the concerned CZMA.
(b) the compliance report shall also be displayed on the website of the concerned
regulatory authority.
(vi) T o maintain transparency in the working of the CZMAs it shall be the responsibility of the
CZMA to create a dedicated website and post the agenda, minutes, decisions taken,
clearance letters, violations, action taken on the violations and court matters including the
Orders of the Hon’ble Court as also the approved CZMPs of the respective State Government
or Union territory.
5. Preparation of Coastal Zone Management Plans.
(i) T he MoEF may obtain the CZMPs prepared through the respective State Government or
Union territory;
(ii) The CZMPs may be prepared by the coastal State Government or Union territory by
engaging reputed and experienced scientific institution(s) or the agencies including the
National Centre for Sustainable Coastal Management (hereinafter referred to as the
NCSCM) of MoEF and in consultation with the concerned stakeholders;
(iii)The hazard line shall be mapped by MoEF through SoI all along the coastline of the
country and the hazard line shall be demarcated taking into account, tide, waves, sea level

<!-- page 7 -->

7

rise and shoreline changes;
(iv)For the purpose of depicting the flooding due to tides, waves and sea level rise in the next
fifty and hundred years, the contour mapping of the coastline shall be carried out at 0.5m
interval n o r m a l l y upto 7km from HTL on the landward side, and the shoreline changes
shall be demarcated based on historical data by comparing the previous satellite imageries
with the recent satellite imageries;
(v) Mapping of the hazard line shall be carried out in 1:25,000 scale for macro level planning
and 1:10,000 scale or cadastral scale for micro level mapping and the hazard line shall be
taken into consideration while preparing the land use plan of the coastal areas;
(vi)The coastal States and Union Territory will prepare within a period of twenty four
months from the date of issue this notification, draft CZMPs in 1:25,000 scale map
identifying and classifying the CRZ areas within the respective territories in accordance
with the guidelines given in Annexure-I of the notification, which involve public
consultation;
(vii) The draft CZMPs shall be submitted by the State Government or Union territory to the
concerned CZMA for appraisal, including appropriate consultations, and recommendations in
accordance with the procedure(s) laid down in the Environment (Protection) Act, 1986;
(viii) The State Government or Union territory CZMA shall submit the draft CZMPs to
MoEF alongwith its recommendations on the CZMP within a period of six months after
incorporating the suggestions and objections received from the stakeholders;
(ix)MoEF shall t h e r e a f t e r consider and approve the CZMPs within a period of f o u r
months from the date of receipt of the CZMPs complete in all respects;
(x) All developmental activities listed in this notification shall be regulated by the State
Government, Union Territory Administration, the local authority or the concerned
CZMA within the framework of such approved CZMPs as the case may be in
accordance with provisions of this notification;
(xi) The CZMPs shall not normally be revised before a period of five years after which, the
concerned State Government or the Union territory may consider undertaking revision of the
maps following the above procedures;
(xii) The CZMPs already approved under CRZ notification, 1991 shall be valid for a period
of twenty four months unless the aforesaid period is extended by MoEF by a specific
notification subject to such terms and conditions as may be specified therein.
6. Enforcement of the CRZ, notification, 2011(a) For the purpose of implementation and enforcement of the provisions this notification and
compliance with conditions stipulated thereunder, the powers either original or delegated
are available under Environment (Protection) Act, 1986 with the MoEF, State
Government or the Union territory Administration N C Z M A a n d S C Z M A s ;
(b) The composition, tenure and mandate of NCZMA and State Government or the Union
territory CZMAs have already been notified by MoEF in terms of Orders of Hon’ble

<!-- page 8 -->

8

Supreme Court in Writ Petition 664 of 1993;
(c) the State Government or the Union territory CZMAs shall primarily be responsible for
enforcing and monitoring of this notification and to assist in this task, the State
Government and the Union territory shall constitute district level Committees under the
Chairmanship of the District Magistrate concerned containing atleast three representatives
of local traditional coastal communities including from fisherfolk;
(d) The dwelling units of the traditional coastal communities including fisherfolk, tribals as
were permissible under the provisions of the CRZ notification, 1991, but which have not
obtained formal approval from concerned authorities under the aforesaid notification shall
be considered by the respective Union territory CZMAs and the dwelling units shall be
regularized subject to the following condition, namely(i) these are not used for any commercial activity
(ii) these are not sold or transferred to non-traditional coastal community.
7. Classification of the CRZ – For the purpose of conserving and protecting the coastal areas and
marine waters, the CRZ area shall be classified as follows, namely:(i) CRZ-I,–
A. The areas that are ecologically sensitive and the geomorphological features which play a
role in the maintaining the integrity of the coast,(a) Mangroves, in case mangrove area is more than 1000 sq mts, a buffer of 50meters
along the mangroves shall be provided;
(b) Corals and coral reefs and associated biodiversity;
(c) Sand Dunes;
(d) Mudflats which are biologically active;
(e) National parks, marine parks, sanctuaries, reserve forests, wildlife habitats and other
protected areas under the provisions of Wild Life (Protection) Act, 1972 (53 of
1972), the Forest (Conservation) Act, 1980 (69 of 1980) or Environment (Protection)
Act, 1986 (29 of 1986); including Biosphere Reserves;
(f) Salt Marshes;
(g) Turtle nesting grounds;
(h) Horse shoe crabs habitats;
(i) Sea grass beds;
(j) Nesting grounds of birds;
(k) Areas or structures of archaeological importance and heritage sites.
B. The area between Low Tide Line and High Tide Line;
(ii) CRZ-II,The areas that have been developed upto or close to the shoreline.
Explanation.- For the purposes of the expression “developed area” is referred to as that area
within the e x i s ti n g municipal limits or in other e x i s t i n g legally designated urban areas
w h i c h a r e substantially built-up and has been provided with drainage and approach roads
and other infrastructural facilities, such as water supply and sewerage mains;

<!-- page 9 -->

9

(iii) CRZ-III,Areas that are relatively undisturbed and those do not belong to either CRZ-I or II which
include coastal zone in the rural areas (developed and undeveloped) and also areas within
municipal limits or in other legally designated urban areas, which are not substantially built
up.
(iv.) CRZ-IV,A. the water area from the Low Tide Line to twelve nautical miles on the seaward side;
B. shall include the water area of the tidal influenced water body from the mouth of the
water body at the sea upto the influence of tide which is measured as five parts per
thousand during the driest season of the year.
(v) Areas requiring special consideration for the purpose of protecting the critical coastal
environment and difficulties faced by local communities,A. (i) CRZ area falling within municipal limits of Greater Mumbai;
(ii) the CRZ areas of Kerala including the backwaters and backwater islands;
(iii) CRZ areas of Goa.
B. Critically Vulnerable Coastal Areas (CVCA) such as Sunderbans region of West Bengal
and other ecologically sensitive areas identified as under Environment (Protection) Act,
1986 and managed with the involvement of coastal communities including fisherfolk.
8. Norms for regulation of activities permissible under this notification,(i) The development or construction activities in different categories of CRZ shall be
regulated by the concerned CZMA in accordance with the following norms, namely:Note:- The word existing use hereinafter in relation to existence of various features or existence
of regularisation or norms shall mean existence of these features or regularisation or norms
as on 19.2.1991 wherein CRZ notification, was notified.
I. CRZ-I,(i) no new construction shall be permitted in CRZ-I except,(a) projects relating to Department of Atomic Energy;
(b) pipelines, conveying systems including transmission lines;
(c) facilities that are essential for activities permissible under CRZ-I;
(d) installation of weather radar for monitoring of cyclones movement and prediction by
Indian Meteorological Department;
(e) construction of trans harbour sea link and without affecting the tidal flow of water,
between LTL and HTL.
(f) development of green field airport already approved at only Navi Mumbai;
(ii) Areas between LTL and HTL which are not ecologically sensitive, necessary safety
measures will be incorporated while permitting the following, namely:-

<!-- page 10 -->

10

(a) exploration and extraction of natural gas;
(b) construction of dispensaries, schools, public rainshelter, community toilets,
bridges, roads, jetties, water supply, drainage, sewerage which are required for
traditional inhabitants living within the biosphere reserves after obtaining
approval from concerned CZMA.
(c) necessary safety measure shall be incorporated while permitting such
developmental activities in the area falling in the hazard zone;
(d) salt harvesting by solar evaporation of seawater;
(e) desalination plants;
(f) storage of non-hazardous cargo such as edible oil, fertilizers and food grain within
notified ports;
(g) construction of trans harbour sea links, roads on stilts or pillars without affecting the
tidal flow of water.
II. CRZ-II,(i) buildings shall be permitted only on the landward side of the existing road, or on the
landward side of existing authorized structures;
(ii) b uildings permitted on the landward side of the existing and proposed roads or existing
authorized structures shall be subject to the existing local town and country planning
regulations including the ‘existing’ norms of Floor Space Index or Floor Area Ratio:
Provided that no permission for construction of buildings shall be given on landward side
of any new roads which are constructed on the seaward side of an existing road:
(iii) reconstruction of authorized building to be permitted subject with the existing Floor
Space Index or Floor Area Ratio Norms and without change in present use;
(iv) facilities for receipt and storage of petroleum products and liquefied natural gas as
specified in Annexure-II appended to this notification and facilities for regasification of
Liquefied Natural Gas subject to the conditions as mentioned in sub-paragraph (ii) of
paragraph 3;
(v) desalination plants and associated facilities;
(vi) storage of non-hazardous cargo, such as edible oil, fertilizers and food grain in
notified ports;
(vii) facilities for generating power by non-conventional power sources and associated
facilities;
III. CRZ-III,A. Area upto 200mts from HTL on the landward side in case of seafront and 100mts
along tidal influenced water bodies or width of the creek whichever is less is to be earmarked
as “No Development Zone (NDZ)”,(i) the NDZ shall not be applicable in such area falling within any notified port limits;
(ii) No construction shall be permitted within N D Z except for repairs or
reconstruction of existing authorized structure not exceeding existing Floor Space Index,
existing plinth area and existing density and for permissible activities under the notification
including facilities essential for activities; Construction/reconstruction of dwelling units of
traditional coastal communities including fisherfolk may be permitted between 100 and 200
metres from the HTL along the seafront in accordance with a comprehensive plan prepared
by the State Government or the Union territory in consultation with the traditional coastal

<!-- page 11 -->

11

communities including fisherfolk and incorporating the necessary disaster management
provision, sanitation and recommended by the concerned State or the Union territory CZMA
to NCZMA for approval by MoEF;
(iii) however, the following activities may be permitted in NDZ –
(a) agriculture, horticulture, gardens, pasture, parks, play field, and forestry;
(b) projects relating to Department of Atomic Energy;
(c) mining of rare minerals;
(d) salt manufacture from seawater;
(e) facilities for receipt and storage of petroleum products and liquefied natural gas as
specified in Annexure-II;
(f) facilities for regasification of liquefied natural gas subject to conditions as
mentioned in subparagraph (ii) of paragraph 3;
(g) facilities for generating power by non conventional energy sources;
(h) Foreshore facilities for desalination plants and associated facilities;
(i) weather radars;
(j) construction of dispensaries, schools, public rain shelter, community toilets,
bridges, roads, provision of facilities for water supply, drainage, sewerage,
crematoria, cemeteries and electric sub-station which are required for the local
inhabitants may be permitted on a case to case basis by CZMA;
(k) construction of units or auxiliary thereto for domestic sewage, treatment and
disposal with the prior approval of the concerned Pollution Control Board or
Committee;
(l) facilities required for local fishing communities such as fish drying yards, auction halls,
net mending yards, traditional boat building yards, ice plant, ice crushing units, fish
curing facilities and the like;
(m) development of green field airport already permitted only at Navi Mumbai.
B. Area between 200mts to 500mts,The following activities shall be permissible in the above areas;
(i) development of vacant plot in designated areas for construction of hotels or beach
resorts for tourists or visitors subject to the conditions as specified in the guidelines
at Annexure-III ;
(ii) facilities for receipt and storage of petroleum products and liquefied natural gas as
specified in Annexure-II;
(iii) facilities for regasification of liquefied natural gas subject to conditions as
mentioned in sub-paragraph (ii) of paragraph 3;
(iv) storage of non-hazardous cargo such as, edible oil, fertilizers, food grain in
notified ports;
(v) foreshore facilities for desalination plants and associated facilities;
(vi) facilities for generating power by non-conventional energy sources;
(vii) construction or reconstruction of dwelling units so long it is within the ambit of
traditional rights and customary uses such as existing fishing villages and goathans.
Building permission for such construction or reconstruction will be subject to local town
and country planning rules with overall height of construction not exceeding 9mts with two
floors (ground + one floor);
(viii) Construction of public rain shelters, community toilets, water supply drainage,
sewerage, roads and bridges b y C Z M A w h o m a y a l s o permit construction of

<!-- page 12 -->

12

schools and dispensaries for local inhabitants of the area for those panchayats, the major
part of which falls within CRZ if no other area is available for construction of such
facilities;
(ix) reconstruction or alteration of existing authorised building subject to sub-paragraph
(vii), (viii);
(x) development of green field airport already permitted only at Navi Mumbai.
(IV) In CRZ-IV areas,The activities impugning on the sea and tidal influenced water bodies will be regulated except
for traditional fishing and related activities undertaken by local communities as follows:(a)No untreated sewage, effluents, ballast water, ship washes, fly ash or solid waste from all
activities including from aquaculture operations shall be let off or dumped. A
comprehensive plan for treatment of sewage generating from the coastal towns and
cities shall be formulated within a period of one year in consultation with stakeholders
including traditional coastal communities, traditional fisherfolk and implemented;
(b) Pollution from oil and gas exploration and drilling, mining, boat house and shipping;
(c) There shall be no restriction on the traditional fishing and allied activities undertaken by
local communities.
V. Areas requiring special consideration,1. CRZ areas falling within municipal limits of the Greater Mumbai.
(i) Developmental activities in the CRZ area of the Greater Mumbai because of the
environmental issues, relating to degradation of mangroves, pollution of creeks and coastal
waters, due to discharge of untreated effluents and disposal of solid waste, the need to
provide decent housing to the poor section of society and lack of suitable alternatives in
the inter connected islands of Greater Mumbai shall be regulated as follows, namely:A. Construction of roads - In CRZ-I areas indicated at sub-paragraph (i) of paragraph 7
of the notification the following activities only can be taken up:(a) Construction of roads, approach roads and missing link roads approved in
the Developmental Plan of Greater Mumbai on stilts ensuring that the free flow of
tidal water is not affected, without any benefit of CRZ-II accruing on the landward
side of such constructed roads or approach roads subject to the following conditions:( i ) All mangrove areas shall be mapped and notified as protected forest and
necessary protection and conservation measures for the identified mangrove
areas shall be initiated.
(ii) Five times the number of mangroves destroyed/cut during the construction
process shall be replanted.
B. Solid waste disposal sites shall be identified outside the CRZ area and thereafter
within two years the existing conventional solid waste sites shall be relocated outside
the CRZ area.
(iii) In CRZ-II areas(a) The development or redevelopment shall continue to be undertaken in accordance with
the norms laid down in the Town and Country Planning Regulations as they existed on
the date of issue of the notification dated the 19th February, 1991, unless specified

<!-- page 13 -->

13

otherwise in this notification.
(b) SLUM REHABITATION SCHEMES,1. In the Greater Mumbai area there are large slum clusters with lakhs of families
residing therein and the living conditions in these slums are deplorable and the civic
agencies are not able to provide basic infrastructure such as drinking water, electricity,
roads, drainage and the like because the slums come up in an unplanned and
congested manner and the slums in the coastal area are at great risk in the event of
cyclones, storm surges or tsunamis, in view of the difficulties in providing rescue, relief
and evacuation.
2. To provide a safe and decent dwelling to the slum dwellers, the State Government may
implement slum redevelopment schemes as identified as on the date of issue of this
notification directly or through its parastatal agencies like Maharashtra Housing and
Area Development Authority (MHADA), Shivshahi Punarvasan Prakalp Limited
(SPPL), Mumbai Metropolitan Region Development Authority (MMRDA) and the
like.:
Provided that,(i) such redevelopment schemes shall be undertaken directly or through joint
ventures or through public private partnerships or other similar models ensuring that
the stake of the State Government or its parastatal entities shall be not less than
51%;
(ii) the Floor Space Index or Floor Area Ratio for such redevelopment schemes shall
be in accordance with the Town and Country Planning Regulations prevailing
as on the date on which the project is granted approval by the competent
authority;
(iii) it shall be the duty of the project proponent undertaking the redevelopment
through conditions (i) (2) above along with the State Government to ensure that all
legally regularized tenants are provided houses in situ or as per norms laid down
by the State Government in this regard.
(c) REDEVELOPMENT OF DILAPIDATED, CESSED AND UNSAFE BUILDINGS:
1. In the Greater Mumbai, there are, also a large number of old and dilapidated, cessed and
unsafe buildings in the CRZ areas and due to their age these structures are
extremely vulnerable and disaster prone and therefore there is an urgent need for the
redevelopment or reconstruction of these identified buildings.
2. These projects shall be taken up subject to the following conditions and safeguards:
(i) such redevelopment or reconstruction projects as identified on the date of issue of this
notification shall be allowed to be taken up involving the owners of these buildings
either above or with private developers in accordance with the prevailing Regulation,
directly or through joint ventures or through other similar models.
(ii) the Floor Space Index or Floor Area Ratio for such redevelopment schemes shall be in
accordance with the Town and Country Planning Regulations prevailing as on the
date on which the project is granted approval by the competent authority

<!-- page 14 -->

14

(iii) suitable accommodation to the original tenants of the specified buildings shall be
ensured during the course of redevelopment or reconstruction of the buildings by
the project proponents, undertaking the redevelopment through condition 2(i) above.
(d) Notwithstanding anything contained in this notification, the developmental activities
for slums and for dilapidated, cessed and unsafe buildings as specified at paras (b) and (c)
above shall be carried out in an accountable and transparent manner by the project
proponents mentioned therein which shall include the following pre-condition
measures, wherever applicable;1. (i) applicability of the Right to Information Act, 2005 to all redevelopment or
reconstruction projects granted clearance by the Competent Authorities;
(ii) MoEF shall issue an order constituting the CPIO and the first Appellate Authority of
appropriate ranks in consultation with Government of Maharashtra;
(iii) details of the Slum Rehabilitation Scheme, including the complete proposal and the
names of the eligible slum dwellers will be declared suo-moto as a requirement of
Section 4 of compliance of the Right to Information Act, 2005 by the appropriate
authority in the Government of Maharashtra in one month before approving it;
(iv) the implementing or executing agency at the State Government with regard to projects
indicated at sub-item (b) and (c) of item (iii) of sub-paragraph V shall display on a large
notice boards at the site and at the office of the implementing or executing agency the
names of the eligible builders, total number of tenements being made, names of eligible
slum dwellers who are to be provided the dwelling units and the extra area available for
free sale.
(v) Projects being developed under sub-items (b) and (c) of item (iii) of sub-paragraph V
shall be given permission only if the project proponent agree to be covered under the
Right to Information Act, 2005.
2. MoEF may appoint statutory auditors, who are empanelled by the Comptroller and
auditor General (hereinafter referred to as the C&AG) to undertake performance and
fiscal audit in respect of the projects relating to redevelopment of dilapidated, cessed and
unsafe buildings and the projects relating to Slum Rehabilitation Scheme shall be audited
by C&AG.
3. A High Level Oversight Committee may be set up by the Government of Maharashtra
for periodic review of implementation of V(iii)(b) and (c) which shall include
eminent representatives of various Stakeholders, like Architects, Urban Planner,
Engineers, and Civil Society, besides the local urban bodies, the State Government
and the Central Government.
4. The individual projects under V(iii)(b) and (c) shall be undertaken only after public
consultation in which views of only the legally entitled slum dweller or the legally
entitled tenent of the dilapidated or cessed buildings shall be obtained in accordance with
the procedures laid down in EIA notification, 2006.
(e) In order to protect and preserve the ‘green lung’ of the Greater Mumbai area, all open
spaces, parks, gardens, playgrounds indicated in development plans within CRZ-II
shall be categorized as CRZ-III, that is, ‘no development zone’.
(f) the Floor Space Index upto 15% shall be allowed only for construction of civic
amenities, stadium and gymnasium meant for recreational or sports related activities and
the residential or commercial use of such open spaces shall not be permissible.

<!-- page 15 -->

15

(g) Koliwada namely, fishing settlement areas as identified in the Development Plan of 1981
or relevant records of the Government of Maharashtra, shall be mapped and declared as
CRZ-III so that any development, including construction and reconstruction of dwelling
units within these settlements shall be undertaken in accordance with applicable as per local
Town and Country Planning Regulations.
(h) Reconstruction and repair works of the dwelling units, belonging to fisher communities
and other local communities identified by the State Government, shall be considered and
granted permission by the Competent Authorities on a priority basis, in accordance with the
applicable Town and Country Planning Regulations.
2. CRZ for Kerala
In view of the unique coastal systems of backwater and backwater islands alongwith space
limitation present in the coastal stretches of the State of Kerala, the following activities in CRZ
shall be regulated as follows, namely:(i) all the islands in the backwaters of Kerala shall be covered under the CRZ notification;
(ii) the islands within the backwaters shall have 50mts width from the High Tide Line on the
landward side as the CRZ area;
(iii) within 50mts from the HTL of these backwater islands existing dwelling units of local
communities may be repaired or reconstructed however no new construction shall be
permitted;
(iv) beyond 50mts from the HTL on the landward side of backwater islands, dwelling units
of local communities may be constructed with the prior permission of the Gram panchayat;
(v) f oreshore facilities such as fishing jetty, fish drying yards, net mending yard, fishing
processing by traditional methods, boat building yards, ice plant, boat repairs and the like,
may be taken up within 50mts width from HTL of these backwater islands.
3. CRZ of Goa.In view of the peculiar circumstances of the State Goa including past history and other
developments, the specific activities shall be regulated and various measures shall be undertaken as
follows:(i) t he Government of Goa shall notify the fishing villages wherein all foreshore facilities
required for fishing and fishery allied activities such as traditional fish processing
yards, boat building or repair yards, net mending yards, ice plants, ice storage, auction hall,
jetties may be permitted by Grama Panchayat in the CRZ area;
(ii) reconstruction, repair works of the structures of local communities including fishermen
community shall be permissible in CRZ;
(iii) purely temporary and seasonal structures customarily put up between the months of
September to May;
(iv) t he eco sensitive low lying areas which are influenced by tidal action known as khazan
lands shall be mapped;
(v) the mangroves along such as khazan land shall be protected and a management plan for the
khazan land prepared and no developmental activities shall be permitted in the khazan
land;
(vi) sand dunes, beach stretches along the bays and creeks shall be surveyed and mapped. No
activity shall be permitted on such sand dune areas;
(vii) the beaches such as Mandrem, Morjim, Galgiba and Agonda has been designated as
turtle nesting sites and protected under the Wildlife Protection Act, 1972 and these areas

<!-- page 16 -->

16

shall be surveyed and management plan prepared for protection of these turtle nesting
sites;
(viii) no developmental activities shall be permitted in the turtle breeding areas referred to in
sub-paragraph (vii).
4. (a) Critical Vulnerable Coastal Areas (CVCA) which includes Sunderbans and other identified
ecological sensitive areas which shall be managed with the involvement of the local coastal
communities including the fisher folk;(b) the entire Sunderbans mangrove area and other identified ecologically important areas such as
Gulf of Khambat and Gulf of Kutchchh in Gujarat, Malvan, Achra-Ratnagiri in Maharashtra,
Karwar and Coondapur in Karnataka, Vembanad in Kerala, Gulf of Mannar in Tamil Nadu,
Bhaitarkanika in Orissa, Coringa, East Godavari and Krishna in Andhra Pradesh shall be
declared as Critical Vulnerable Coastal Areas (CVCA) through a process of consultation with
local fisher and other communities inhabiting the area and depend on its resources for their
livelihood with the objective of promoting conservation and sustainable use of coastal
resources and habitats;
(c) the process of identifying planning, notifying and implementing CVCA shall be detailed in
the guideline which will be developed and notified by MoEF in consultations with the
stakeholders like the State Government, local coastal communities and fisherfolk and the like
inhabiting the area;
(d) the Integrated Management Plans (IMPs) prepared for such CVCA shall interalia keep in view
the conservation and management of mangroves, needs of local communities such as,
dispensaries, schools, public rain shelter, community toilets, bridges, roads, jetties, water
supply, drainage, sewerage and the impact of sea level rise and other natural disasters and the
IMPs will be prepared in line with the para 5 above for preparation of Coastal Zone
Management Plans;
(e) till such time the IMPs are approved and notified, construction of dispensaries, schools,
public rain shelters, community toilets, bridges, roads, jetties, water supply, drainage,
sewerage which are required for traditional inhabitants shall be permitted on a case to case
basis, by the CZMA with due regards to the views of coastal communities including
fisherfolk.

[F.No.11-83/2005-IA-III]
J. M. MAUSKAR, Addl. Secy.

<!-- page 17 -->

17

ANNEXURE I
GUIDELINES FOR PREPARATION OF COASTAL ZONE MANAGEMENT PLANS
I. A. Demarcation of High Tide Line
1. Demarcation of High Tide Line (HTL) and Low Tide Line (LTL) shall be carried out by one of
the agencies authorised by MoEF based on the recommendations of the National Centre for
Sustainable Coastal Management (NCSCM).
2. Demarcation of the High Tide Line or LTL shall be made on the Coastal Zone Management
(CZM) Maps of scale 1:25,000 prepared by the agencies identified by the MoEF.
3. Local level CZM Maps shall be prepared for use of officials of local bodies for determination of
the CRZ.
4. The local level CZM Maps shall be prepared on a Cadastral scale in accordance with the CZM
Maps approved by the Central Government.
B. Preparation of CZM Maps
5. Base Maps of 1:25,000 scale shall be acquired from the Survey of India (SOI) and wherever
1:25,000 maps are not available, 1:50,000 maps shall be enlarged to 1:25,000 for the purpose of
base map preparation and these maps will be of the standard specification given below:
Unit
:
7.5 minutes X 7.5minutes
Numbering
:
Survey of India Sheet Numbering System
Horizontal Datum
:
Everest or WGS 84
Vertical Datum
:
Mean Sea Level (MSL)
Topography
:
Topography in the SOI maps will be updated using latest
satellite imageries or aerial photographs
6. The High Water Level (HWL) and Low Water Level (LWL) marked on the Base maps will be
transferred to the CZM maps.
7. Coastal geomorphological signatures in the field or satellite imageries or aerial photographs will
be used for appropriate adjustment, in the HWL or LWL for demarcating HTL or LTL in
accordance with the CRZ notification.
8. The following geomorphological features shall be considered while demarcating in HTL or LTL:
Landward (monsoonal) berm crest in the case of sandy beaches
Rocks, Headlands, Cliffs
Seawalls or revetments or embankments
9. 500 meter and 200 metre lines will be demarcated with respect of HTL.
10. HTL (as defined in the CRZ notification) and LTL shall also be demarcated in the CZM maps
along the banks of tidal influenced inland water bodies with the help of the geomorphological
signatures or features.
11. Classification of different coastal zones shall be done as per the CRZ notification
12. Standard national or international colour codes shall be used to highlight sub-classification of
data.
C. Local level CZM Maps
Local level CZM Maps are for the use of local bodies and other agencies to facilitate
implementation of the Coastal Zone Management Plans
13. Cadastral (village) maps in 1:3960 or the nearest scale, shall be used as the base maps.

<!-- page 18 -->

18

14. These maps are available with revenue Authorities and are prepared as per standard norms.
15. HTL (as defined in the CRZ notification) and LTL will be demarcated in the cadastral map based
on detailed physical verification using coastal geomorphological signatures or features in
accordance with the CZM Maps approved by the Central Government.
16. 500metre and 200metre lines shall be demarcated with respect to the HTL thus marked.
17. HTL (as defined in the CRZ notification, 1991) and LTL will also be demarcated along the banks
of tidal influenced inland water bodies with the help of geomorphological signatures or features.
18. Classifications shall be transferred into local level CZM maps from the CZM Plans.
19. Symbols will be adopted from CZM Maps.
20. Colour codes as given in CZM Maps shall be used.
21. Demarcation of cadastral maps will be done by local agencies approved by the Central
Government. The local agencies shall work under the guidance of the concerned State
Government or Union Territory Coastal Zone Management Authorities.
D. Hazard mapping:II. Classification of CRZ areas
1. The CZM Maps shall be prepared in accordance with para 5 of the CRZ notification demarcating
CRZ I, II, III, IV and V.
2. The CZM Maps shall clearly demarcate the land use plan of the area and lists out the CRZ-I
areas. All the CRZ-I areas listed under para 7(I)A and B shall be clearly demarcated and colour
codes given so that each of the CRZ-I areas can be clearly identified.
3. Buffer zone along mangrove areas of more than 1000sq mts shall be stipulated with a different
colour distinguishing from the mangrove area.
4. The buffer zone shall also be classified as CRZ-I area.
5. The hazard line to be drawn up by MoEF shall be superimposed on the CZM maps in 1:25,000
scale and also on the cadastral scale maps.
6. The CRZ-II areas shall be those areas which have been substantially built-up with a ratio of builtup plots to that of total plots is more than 50%.
7. In the CRZ areas, the fishing villages, common properties of the fishermen communities, fishing
jetties, ice plants, fish drying platforms or areas infrastructure facilities of fishing and local
communities such as dispensaries, roads, schools, and the like, shall be indicated on the cadastral
scale maps. States shall prepare detailed plans for long term housing needs of coastal fisher
communities in view of expansion and other needs, provisions of basic services including
sanitation, safety, and disaster preparedness.
8. No developmental activities other than those listed above shall be permitted in the areas between
the hazard line and 500mts or 100mts or width of the creek on the landward side. The dwelling
unit of the local communities including that of the fishers will not be relocated if the dwelling
units are located on the seaward side of the hazard line. The State Government will provide
necessary safeguards from natural disaster to such dwelling units of local communities.
9. The water areas of CRZ IV shall be demarcated and clearly demarcated if the water body is sea,
lagoon, backwater, creek, bay, estuary and for such classification of the water bodies the
terminology used by Naval Hydrographic Office shall be relied upon.
10. The fishing Zones in the water bodies and the fish breeding areas shall be clearly marked.
11. The water area shall be demarcated indicating the pollution levels as per Central Pollution Control
Board standards on water quality.
12. In the CRZ V areas the land use maps shall be superimposed on the Coastal Zone Management
Plan and clearly demarcating the CRZ I, II, III, IV.
13. The existing authorized developments on the sea ward side shall be clearly demarcated.

<!-- page 19 -->

19

14. The features like cyclone shelters, rain shelters, helipads and other infrastructure including road
network may be clearly indicated on the CZM Maps for the purpose of rescue and relief
operations during cyclones, storms, tsunami and the like.
III. CZMPs approved by MoEF in accordance with CRZ notification, 1991
1. While preparing the CZMPs under CRZ notification, 2011, the CZMPs that have been approved
under the CRZ Notification, 1991 shall be compared. A justification shall be provided by the
concerned CZMA in case the CZMPs prepared under CRZ notification, 2011 varies with respect
to the approved CZMP prepared under CRZ notification, 1991.
IV. Public Views on the CZMP.
a) The draft CZMPs prepared shall be given wide publicity and suggestions and objections received
in accordance with the Environment (Protection) Act, 1986. Public hearing on the draft CZMPs
shall be held at district level by the concerned CZMAs.
b) Based on the suggestions and objections received the CZMPs shall be revised and approval of
MoEF shall be obtained.
c) The approved CZMP shall be put up on the website of MoEF, concerned website of the State,
Union Territory CZMA and hard copy made available in the panchayat office, District collector
office and the like.
V. Revision of Coastal Zone Management Plans
1. Whenever there is a doubt the concerned State or Union territory Coastal Zone Management
Authority shall refer the matter to the National Centre for Sustainable Coastal Management who
shall verify the CZMP based on latest satellite imagery and ground truthing.
2. The rectified map would be submitted to MoEF for its record.

****

<!-- page 20 -->

20

Annexure-II
List of petroleum and chemical products permitted for storage in [CRZ except CRZ-I(A)]
(i) Crude oil;
(ii) Liquefied Petroleum Gas;
(iii) Motor spirit;
(iv) Kerosene;
(v) Aviation fuel;
(vi) High speed diesel;
(vii) Lubricating oil;
(viii) Butane;
(ix) Propane;
(x) Compressed Natural Gas;
(xi) Naphtha;
(xii) Furnace oil;
(xiii) Low Sulphur Heavy Stock;
(xiv) Liquefied Natural Gas;
(xv) Fertilizers and raw materials for manufacture of fertilizers.
****

<!-- page 21 -->

21

Annexure-III
Guidelines for development of beach resorts or hotels in the designated areas of CRZ-III and
CRZ-II for occupation of tourist or visitors with prior approval of the Ministry of
Environment and Forests
I. Construction of beach resorts or hotels with prior approval of MoEF in designated areas of CRZ-II
and III for occupation of tourist or visitors shall be subject to the following conditions, namely:(a) The project proponent shall not undertake any construction within 200 metres in the landward
side of High Tide Line and within the area between Low Tide Line and High Tide Line;
(b) The proposed constructions shall be beyond the hazard line or 200mts from the High Tide Line
whichever is more;
(c) live fencing and barbed wire fencing with vegetative cover may be allowed around private
properties subject to the condition that such fencing shall in no way hamper public access to the
beach;
(d) no flattening of sand dunes shall be carried out;
(e) no permanent structures for sports facilities shall be permitted except construction of goal posts,
net posts and lamp posts;
(f) Construction of basement may be allowed subject to the condition that no objection certification
is obtained from the State Ground Water Authority to the effect that such construction will not
adversely affect fee flow of groundwater in that area;
(g) the State Ground Water Authority shall take into consideration the guidelines issued by Central
Government before granting such no objection certificate;
(h) though no construction is allowed in the no development zone for the purposes of calculation of
Floor Space Index, the area of entire plot including the portion which falls within the no
development zone shall be taken into account;
(i) the total plot size shall not be less than 0.4 hectares and the total covered area on all floors shall
not exceed 33 percent of the plot size i.e., the Floor Space Index shall not exceed 0.33 and the
open area shall be suitably landscaped with appropriate vegetal cover;
(j) the construction shall be consistent with the surrounding landscape and local architectural style;
(k) the overall height of construction upto the highest ridge of the roof, shall not exceed 9metres and
the construction shall not be more than two floors (ground floor plus one upper floor);
(l) groundwater shall not be tapped within 200metre of the High Tide Line; within the 200metre
500metre zone it can be tapped only with the concurrence of the Central or State Ground Water
Board;
(m) extraction of sand, leveling or digging of sandy stretches except for structural foundation of
building, swimming pool shall not be permitted within 500metres of the High Tide Line;

<!-- page 22 -->

22

(n) the quality of treated effluents, solid wastes, emissions and noise levels and the like, from the
project area must conform to the standards laid down by the competent authorities including the
Central or State Pollution Control Board and under the Environment (Protection) Act, 1986;
(o) necessary arrangements for the treatment of the effluents and solid wastes must be made and it
must be ensured that the untreated effluents and solid wastes are not discharged into the water or
on the beach; and no effluent or solid waste shall be discharged on the beach;
(p) to allow public access to the beach, atleast a gap of 20metres width shall be provided between any
two hotels or beach resorts; and in no case shall gaps be less than 500metres apart; and
(q) if the project involves diversion of forestland for non-forest purposes, clearance as required under
the Forest (Conservation) Act, 1980 shall be obtained and the requirements of other Central and
State laws as applicable to the project shall be met with; and
(r) approval of the State or Union territory Tourism Department shall be obtained.
II. In ecologically sensitive areas (such as marine parks, mangroves, coral reefs, breeding and
spawning grounds of fish, wildlife habitats and such other area as may be notified by the Central
or State Government Union territories) construction of beach resorts or hotels shall not be
permitted
****

<!-- page 23 -->

23

Annexure-IV
Form-I for seeking clearance for project attracting CRZ notification
Basic information:
Name of the Project:Location or site alternatives under consideration:Size of the project (in terms of total area) :CRZ classification of the area :Expected cost of the project:Contact Information:(II) Activity
1. Construction, operation or decommissioning of the Project involving actions, which will cause
physical changes in the locality (topography, land use, changes in water bodies, and the like)
S. No.

Information/Checklist confirmation

1.1

Permanent or temporary change in land use,
land cover or topography including increase in
intensity of land use (with respect to local
land use plan)
Details of CRZ classification as per the
approved Coastal Zone Management Plan?
Whether located in CRZ-I area?
The distance from the CRZ-I areas.
Whether located within the hazard zone as
mapped by Ministry of Environment and
Forests/National
Disaster
Management
Authority?
Whether the area is prone to cyclone, tsunami,
tidal surge, subduction, earthquake etc.?
Whether the area is prone for saltwater
ingress?
Clearance of existing land, vegetation and
buildings?
Creation of new land uses?

1.2
1.3
1.4
1.5

1.6
1.7
1.8
1.9
1.10
1.11

Pre-construction investigations e.g. bore hole,
soil testing?
Construction works?

Yes/No Details
thereof
(with
approximate quantities /rates,
wherever possible) with source
of information data

<!-- page 24 -->

24

1.12
1.13
1.14

1.15
1.16
1.17
1.18
1.19
1.20
1.21
1.22
1.23
1.24

1.25

1.26
1.27

1.28
1.29
1.30
1.31
1.32
1.33

1.34
1.35
1.36
1.37

Demolition works?
Temporary sites used for construction works
or housing of construction workers?
Above ground buildings, structures or
earthworks including linear structures, cut and
fill or excavations
Underground works including mining or
tunneling?
Reclamation works?
Dredging/reclamation/land filling/disposal of
dredged material etc.?
Offshore structures?
Production and manufacturing processes?
Facilities for storage of goods or materials?
Facilities for treatment or disposal of solid
waste or liquid effluents?
Facilities for long term housing of operational
workers?
New road, rail or sea traffic during
construction or operation?
New road, rail, air waterborne or other
transport infrastructure including new or
altered routes and stations, ports, airports etc?
Closure or diversion of existing transport
routes or infrastructure leading to changes in
traffic movements?
New or diverted transmission lines or
pipelines?
Impoundment,
damming,
culverting,
realignment or other changes to the hydrology
of watercourses or aquifers?
Stream and river crossings?
Abstraction or transfers of water form ground
or surface waters?
Changes in water bodies or the land surface
affecting drainage or run-off?
Transport of personnel or materials for
construction, operation or decommissioning?
Long-term dismantling or decommissioning or
restoration works?
Ongoing activity during decommissioning
which could have an impact on the
environment?
Influx of people to an area in either
temporarily or permanently?
Introduction of alien species?
Loss of native species or genetic diversity?
Any other actions?

<!-- page 25 -->

25

2. Use of Natural resources for construction or operation of the Project (such as land, water,
materials or energy, especially any resources which are non-renewable or in short supply):
S. No.
Information/checklist confirmation
Yes/No Details
thereof
(with
approximate quantities /rates,
wherever possible) with source
of information data
2.1
Land especially undeveloped or agricultural
land (ha)
2.2
2.3
2.4
2.5
2.6

2.7

Water (expected source & competing
users) unit: KLD
Minerals (MT)
Construction material – stone, aggregates,
sand/soil (expected source – MT)
Forests and timber (source – MT)
Energy including electricity and fuels
(source, competing users) Unit: fuel (MT),
energy (MW)
Any other natural resources (use appropriate
standard units)

3. Use, storage, transport, handling or production of substances or materials, which could be harmful
to human health or the environment or raise concerns about actual or perceived risks to human
health.
S. No.

Information/Checklist confirmation

3.1

Use of substances or materials, which are
hazardous (as per MSIHC rules) to human health
or the environment (flora, fauna, and
water supplies)
Changes in occurrence of disease or affect disease
vectors (e.g. insect or water borne diseases)
Affect the welfare of people e.g. by changing
living conditions?
Vulnerable groups of people who could be
affected by the project e.g. hospital patients,
children, the elderly etc.,
Any other causes, that would affect local
communities, fisherfolk, their livelihood,
dwelling units of traditional local communities
etc

3.2
3.3
3.4

3.5

Yes/
No

Details
thereof
(with
approximate quantities/rates,
wherever
possible)
with
source of information data

4. Production of solid wastes during construction or operation or

decommissioning (MT/month)

S.
No.

Details
thereof
(with
approximate
quantities/rates,
wherever possible) with source
of information data

Information/Checklist confirmation

Yes/
No

<!-- page 26 -->

26

4.1
4.2
4.3
4.4
4.5
4.6
4.7
4.8
4.9
4.10
4.11

Spoil, overburden or mine wastes
Municipal waste (domestic and or commercial
wastes)
Hazardous wastes (as per Hazardous Waste
Management Rules)
Other industrial process wastes
Surplus product
Sewage sludge or other sludge from effluent
treatment
Construction or demolition wastes
Redundant machinery or equipment
Contaminated soils or other materials
Agricultural wastes
Other solid wastes

5. Release of pollutants or any hazardous, toxic or noxious substances to air (Kg/hr)
S.
Information/Checklist confirmation
Yes/
Details
thereof
(with
No.
No
approximate quantities/rates,
wherever
possible)
with
source of information data
5.1
Emissions from combustion of fossil fuels from
stationary or mobile sources
5.2
Emissions from production processes
5.3
Emissions from materials handling including
storage or transport
5.4
Emissions from construction activities including
plant and equipment
5.5
Dust or odours from handling of materials
including construction materials, sewage and waste
5.6
Emissions from incineration of waste
5.7
Emissions from burning of waste in open air (e.g.
slash materials, construction debris)
5.8
Emissions from any other sources
6. Generation of Noise and Vibration, and Emissions of Light and Heat:
S. No.
Information/Checklist confirmation
Yes/
Details
thereof
(with
No
approximate quantities/rates,
wherever possible) with
source of information data
with source of information
data
6.1
From operation of equipment e.g. engines,
ventilation plant, crushers
6.2
From industrial or similar processes
6.3
From construction or demolition
6.4
From blasting or piling
6.5
From construction or operational traffic
6.6
From lighting or cooling systems

<!-- page 27 -->

27

6.7

From any other sources

7. Risks of contamination of land or water from releases of pollutants into the ground or into sewers,
surface waters, groundwater, coastal waters or the sea:
S.
Information/Checklist confirmation
Yes/
Details
thereof
(with
No.
No
approximate quantities/rates,
wherever possible) with source
of information data
7.1
From handling, storage, use or spillage of
hazardous materials
7.2
From discharge of sewage or other effluents to
water or the land (expected mode and place of
discharge)
7.3
By deposition of pollutants emitted to air into the
land or into water
7.4
From any other sources
7.5

8.

Is there a risk of long term build up of pollutants
in the environment from these sources?

Risk of accidents during construction or operation of the Project, which could affect human health or
the environment
S.
No.

Information/Checklist confirmation

8.1

From explosions, spillages, fires etc from storage,
handling, use or production of hazardous
substances
From any other causes
Could the project be affected by natural disasters
causing environmental damage (e.g., floods,
earthquakes, landslides, cloudburst etc)?

8.2
8.3

Yes/
No

Details thereof (with approximate
quantities/rates,
wherever
possible)
with
source
of
information data

9. Factors which should be considered (such as consequential development) which could lead to
environmental effects or the potential for cumulative impacts with
other existing or planned
activities in the locality
S. No.

Information/Checklist confirmation

9.1

Lead to development of supporting.
lities, ancillary development or development
stimulated by the project which could have
impact on the environment e.g.:
Supporting infrastructure (roads, power
supply, waste or waste water treatment, etc.)

Yes/
No

Details thereof (with approximate
quantities/rates,
wherever
possible)
with
source
of
information data

<!-- page 28 -->

28

housing development
extractive industries
supply industries
other
Lead to after-use of the site, which could have an
impact on the environment
Set a precedent for later developments
Have cumulative effects due to proximity to other
existing or planned projects with similar effects

9.2
9.3
9.4

III. Environmental Sensitivity
S.
No.

Areas

1

Areas protected under international conventions,
national or local legislation for their ecological,
landscape, cultural or other related value
Areas which are important or sensitive for
ecological reasons - Wetlands, watercourses or
other water bodies, coastal zone, biospheres,
mountains, forests
Areas used by protected, important or sensitive
species of flora or fauna for breeding, nesting,
foraging, resting, over wintering, migration
Inland, coastal, marine or underground waters
State, National boundaries
Routes or facilities used by the public for access
to recreation or other tourist, pilgrim areas
Defence installations

2

3

4
5
6
7

Name/
Identity

8
9

Densely populated or built-up area
Areas occupied by sensitive man-made land uses
(hospitals, schools, places of worship, community
facilities)
10 Areas containing important, high quality or scarce
resources
(ground water resources, surface resources,
forestry, agriculture, fisheries, tourism, minerals)
11
Areas already subjected to pollution or
environmental damage. (those where existing
legal environmental standards are exceeded)
12
Areas susceptible to natural hazard which could
cause the project to present environmental
problems
(earthquakes, subsidence, landslides, erosion,
flooding or extreme or adverse climatic
conditions)
****

Aerial distance (within 15
km.)
Proposed project location
boundary
