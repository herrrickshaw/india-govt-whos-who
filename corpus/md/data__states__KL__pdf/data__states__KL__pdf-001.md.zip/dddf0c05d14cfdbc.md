---
doc_id: "dddf0c05d14cfdbc"
source_url: "https://cooperation.kerala.gov.in/wp-content/uploads/2019/04/The-Kerala-Co-Operative-SocietiesAmendment-Act-2023.pdf"
ministry: "Co-operation Department, Kerala"
title: "The Kerala Co-Operative Societies(Amendment) Act, 2023"
date: ""
pages: 61
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7e54ef2d88893326"
---

<!-- page 1 -->

Regn.No. KERBIL/2012/45073
dated 05-09-2012 with RNI
Reg No.KL/TV(N)/634/2021-2023

©
േകരള സർകാർ
Government of Kerala
2024

േകരള ഗസറ്
KERALA GAZETTE
അസാധാരണം
EXTRAORDINARY

ആധികാരികമായി ്പസിദെപടുതുനത

PUBLISHED BY AUTHORITY
തിരുവനനപുരം,
വാല്ം 13

Vol. XIII

2024 ജൂണ 07
07th June 2024

െവളി

1199 ഇടവം 24
24th Idavam 1199

Thiruvananthapuram,
Friday

നമർ
No.

1829

1946 േജ്ഷഠം 17
17th Jyaishta 1946

GOVERNMENT OF KERALA

Law (Legislation-H) Department
NOTIFICATION
No. 142/Leg.H2/2022/Law.

Dated, Thiruvananthapuram, 7th June, 2024
24th Idavam, 1199
17th Jyaishta, 1946.

The following Act of the Kerala State Legislature is hereby published for general
information. The Bill as passed by the Legislative Assembly received the assent of the
Governor on the 26th day of April, 2024.

By order of the Governor,

K. G. SANAL KUMAR,
Law Secretary.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 2 -->

2

ACT 9 OF 2024
THE KERALA CO-OPERATIVE SOCIETIES (AMENDMENT) ACT, 2023
An Act further to amend the Kerala Co-operative Societies Act, 1969.
Preamble.—WHEREAS, it is expedient further to amend the Kerala Co-operative Societies
Act, 1969 (Act 21 of 1969) for the purposes hereinafter appearing;
BE it enacted in the Seventy-fourth Year of the Republic of India as follows:—
1. Short title and commencement.—(1) This Act may be called the Kerala Co-operative
Societies ( Amendment) Act, 2023.
(2) It shall come into force at once.
2. Amendment of section 2.— In section 2 of the Kerala Co-operative Societies Act, 1969
(Act 21 of 1969) (hereinafter referred to as the principal Act),—
(i) in clause (ab), the following sentence shall be added at the end, namely:—
“It includes the verification of accounts through software solutions, auditing of
information system and migration of data, in the case of societies whose accounts are
computerized”
(ii) after clause (ac), the following clause shall be inserted, namely:—
“(ad) “administrative audit” means a close assessment of all affairs of the society,
including constitution, management and establishment, maintenance of books and accounts and
other records and internal control systems of the society and the extent to which its activities
were useful in promoting the economic welfare of the members in accordance with the cooperative principles, and it includes Compliance Audit, Performance Audit as well as IT
Audit;”.
(iii) after clause (da), the following clauses shall be inserted, namely:—
“(db) “common software for Primary Agricultural Credit Societies” means an
effective software solution that covers the complete day-to-day functions of Primary
Agricultural Credit Societies through a centralised architecture.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 3 -->

3

(dc) “consortium” means a formal association of co-operative societies formed
based on a common objective for establishing a new entity for raising funds for providing
financial assistance for public purpose with the approval of State Government;”.
(iv) for clause (ib), the following clause shall be substituted, namely:—
“(ib) “Federal Co-operative Society” means a society having more than one
district as its area of operation and having the State Government, individuals and other cooperative societies as its members. But the number of individual members in the society shall
not exceed twenty five per cent of the total membership in the society:
Provided that the condition regarding number of individual members shall not be
applicable to societies which are in existence before the commencement of the Kerala Cooperative Societies (Amendment) Act, 2023;”.
(v) for clause (oaa), the following clause shall be substituted, namely:—
“(oaa) “Primary Agricultural Credit Society” means a service co-operative
society, a service co-operative bank, a farmers' service co-operative bank or a rural bank having
its area of operation confined to a Village, Panchayat or Municipality and the primary object
or principal business of which is to provide financial accommodation to its members for
agricultural purposes or allied agricultural activities, the rate of interest on such loans and
advances and the area of operation shall be fixed by the Registrar:
Provided that the restriction regarding area of operation shall not apply to societies or
banks which are in existence on 1st January, 2000.”.
(vi) for clause (ob), the following clause shall be substituted, namely:—
“(ob) “Primary Credit Society” means a co-operative society other than Primary
Agricultural Credit Society, the primary object or principal business of which is to accept
deposit from its members for the purpose of lending to its members or investments and the
bye-laws of which do not permit admission of any other co-operative society as its member;”.
(vii) for clause (od), the following clause shall be substituted, namely:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 4 -->

4

“(od) “Primary Co-operative Society” means a society having jurisdiction over
any specified area in one revenue district or more than one districts in the State and having
individuals, other societies, State Government and Local Self Government as its members;”.
(viii) in clause (p), for the words “any person”, the words “any other officer of the
State Government” shall be substituted.
(ix) after clause (qb), the following clause shall be inserted, namely:—
“(qba) “Social Co-operative Societies” means primary co-operative societies
formed for the welfare of social classes like differently abled persons, aged persons,
transgenders, depressed persons or mentally challenged persons;”.
(x) in clause (ra), before the words “State Co-operative Agricultural Rural
Development Bank”, the word “Kerala” shall be inserted.
(xi) after clause (u), the following clause shall be added, namely:—
“(v) “Youth Co-operative Societies” means co-operative societies which are
registered to promote entrepreneurship, new technology, innovations and start-ups with the
objective to generate employment and income and the welfare of youth and having its area of
operation within one district.”.
3. Amendment of section 3.—In section 3 of the principal Act,—
(i) in sub-section (1), for the words “a person”, the words “an officer of the State
Government” shall be substituted.
(ii) in sub-section (2), for the words “any person”, the words “any officer of the State
Government” shall be substituted.
4. Amendment of section 7.— In section 7 of the principal Act,—
(i) in sub-section (1),—
(a) in clause (d), the word “and”, coming after the word and symbol “rules;” shall
be deleted.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 5 -->

5

(b) in clause (e) for the words and symbols “, he may register the society and its
bye-laws within a period of ninety days from the date of receipt of the application.”, the symbol
and word “; and” shall be substituted.
(c) after clause (e), the following clause shall be inserted, namely:—
“(f) that the proposed credit societies have collected two lakhs and fifty
thousand rupees and non-credit co-operative societies have collected one lakh rupees as the
minimum share capital;
he may register the society and its bye-laws within a period of sixty days from the date of
receipt of the application:
Provided that the requirement of minimum share capital in this clause shall not be
applicable to co-operative societies of Scheduled Castes/ Scheduled Tribes, Fisheries, Vanitha,
Transgenders, Primary Anand Pattern Milk Co-operative Societies, Schools, Colleges and
Traditional Industrial co-operative societies.”.
(ii) in sub-section (2), for the words “seven days”, the words “fifteen days” shall be
substituted.
(iii) in sub-section (3), for the words “ninety days”, the words “sixty days” shall be
substituted.
5. Amendment of section 8A.—In sub-section (2) of section 8A of the principal Act, for
the words “sixty days” wherever it occurs, the words “forty five days” shall be substituted.
6. Amendment of section 14.— In section 14 of the principal Act,—
(i) in marginal heading of section 14, after the word “Amalgamation”, the word and
symbol “merger,” shall be inserted.
(ii) in sub-section (1),—
(a) after the words and symbol “A society may,”, the words and symbol “with the
prior approval of the Registrar,” shall be inserted;
(b) for the words “two third”, the word “simple” shall be substituted.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 6 -->

6

(iii) in sub-section (2) , after the words and symbol “societies may,”, the words and
symbol “with the prior approval of the Registrar,” shall be inserted and for the words “two
third”, the word “simple” shall be substituted.
(iv) after sub-section (2), the following shall be added as sub-section (2A),—
“(2A) Notwithstanding anything to the contrary contained in any other law in
force or in the rules or in the bye-laws of any society, one or more societies may merge with
any other society by a resolution passed by simple majority at the general body meeting of each
such society:
Provided that before effecting such merger a resolution of the society with whom it has
to merge shall give its approval permitting such merger by a resolution passed by simple
majority of the general body meeting of such society.”.
(v) in sub-section (3) , for the words, figure and symbol “ or sub-section (2)”, the
symbol, words and figure “, sub-section (2) or sub-section (2A)” and for the words and symbol
“transfer, division or amalgamation”, the words and symbol “amalgamation, merger, transfer
or division” shall be substituted.
(vi) after sub-section (7), the following sub-section shall be added, namely:—
“(8) Detailed scheme of transfer of assets and liabilities and the scheme of
merger, as the case may be, prepared by the society and approved by the Registrar as per subsection (1), sub-section (2) or sub-section (2A) shall be published by the Registrar and the
Society.”.
7. Amendment of section 14AA.— In section 14AA of the principal Act,—
(i) after sub-section (2), the following sub-sections shall be added, namely:—
“(2A) The share capital contribution or financial assistance to the subsidiary
institution shall be met from the balance net profit of the society, as provided under sub-section
(2) of section 56 and any further investment in subsidiary institutions from the society/bank
other than share capital shall be released as loan as per the norms as may be specified by the
Registrar.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 7 -->

7

(2B) Any society/bank which had availed any financial assistance from
Government, shall include nominees of Government of Kerala in the board of directors of the
subsidiary institutions, as may be prescribed.
(2C) The Registrar shall conduct audit, inspection and verification of records in
the subsidiary institutions, as may be prescribed.
(2D) Any share capital contribution or financial assistance to the subsidiary
institutions from the society/bank shall be allotted with the prior approval of the Registrar based
on the resolution passed by the general body of the society/bank concerned.
(2E) Transferring funds or leasing of assets of the society to its subsidiary
institutions shall be made with the prior approval of the Government based on the resolution
passed by the general body of the society/bank.”.
(ii) after the existing sub-section (3), the following sub-section shall be added,
namely:—
“(4) Notwithstanding anything contained in the foregoing provisions of this
section, no subsidiary institution shall be promoted under this section on or after the
commencement of the Kerala Co-operative Societies (Amendment) Act, 2023 and the existing
subsidiary institutions registered and working immediately before the commencement of the
Kerala Co-operative Societies (Amendment) Act, 2023 shall continue its operation subject to
the foregoing provisions in sub-sections (1) to (3) and in the manner as may be prescribed.”.
8. Amendment of section 14B.—In section 14B of the principal Act,—
(i) after the existing sub-section (1), the following sub-sections shall be inserted,
namely:—
“(1A) Detailed project report for the formation of such partnership of co-operative
societies shall be prepared by the societies concerned and the same shall be submitted to the
general bodies of such societies for approval.
(1B) The project report approved by the general bodies of the societies shall be
submitted to the Government through the Registrar for the approval of the formation of such
partnership of co-operative societies, in the manner as may be prescribed.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 8 -->

8

(1C) The Registrar shall conduct audit, inspection and verification of records in
such societies, in the manner as may be prescribed.
(1D) In the case of raising of fund for such partnership prior sanction of the
Government shall be obtained by the partnership of co-operative societies, in the manner as
may be prescribed.”.
9. Amendment of section 15.—After sub-section (3) of section 15 of the principal Act, the
following sub-section shall be inserted, namely:—
“(4) Where one or more societies are merged with another society in accordance with
the provisions of section 14, the registration of each of the merging society shall stand cancelled
and shall be deemed to have been dissolved and shall cease to exist as a corporate body.”.
10. Amendment of section 16.—In section 16 of the principal Act, after the existing
proviso to item (i) of clause (a) of sub-section (1), the following item and proviso shall be
added, namely:—
“(ia) in the case of Youth Co-operative Societies, who has not attained the age of
forty-five years:
Provided that on attaining forty-five years, the membership of such members shall cease
to exist and they shall become associate members of the society.”.
11. Amendment of section 18.—In section 18 of the principal Act, sub-section (3) shall
be substituted as follows,—
“(3) Save as provided in this section, a nominal or associate member shall have such
privileges and rights of a member and be eligible to enjoy various services including credit
facilities provided by the societies and be subject to such liabilities of a member, as may be
specified in the bye-laws of the society.”.
12. Amendment of section 19.—In section 19 of the principal Act,—
(i) the existing section shall be numbered as sub-section (1);
(ii) after sub-section (1) so numbered, the following sub-section shall be inserted,
namely:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 9 -->

9

“(2) If the general body of a society has decided to enhance the share value, the
right of a member to continue in membership will remain for a period of five years from the
date of enhancement of value of share but shall be allowed to exercise his rights as a member
only upon remitting the enhanced value of the shares held.”.
13. Amendment of section 19B.—In section 19B of the principal Act,—
(i) in clause (e), the word “and” shall be omitted;
(ii) in clause (f), for the symbol “.”, the symbol and word “; and” shall be substituted;
(iii) after clause (f), the following clause shall be inserted, namely:—
“(g) summary of defects included in the latest statutory audit report along with
the rectification report approved by the Committee and general body of the society.”.
14. Amendment of section 20.—In section 20 of the principal Act, in clause (d), after the
word “election” the words “and removal” shall be inserted.
15. Amendment of section 22.—In sub-section (1) of section 22 of the principal Act, after
the existing proviso, the following proviso shall be inserted, namely:—
“Provided further that the maximum amount of share capital that an individual
member can hold in an Urban Co-operative Bank having Reserve Bank of India licence is
limited to five per cent of the value of total paid-up share capital of the bank.”.
16. Amendment of section 26.—In section 26 of the principal Act, in clause (b) of
sub-section (1), for the word “two”, the word “three” shall be substituted.
17. Amendment of section 28.—In section 28 of the principal Act,—
(i) in the third proviso to sub-section (1),—
(a) for the words “the committees of the”, the words “the committees of all
Primary Agricultural Credit Societies and all primary” shall be inserted;
(b)for the words “any society”, the words “such society” shall be substituted.
(ii) provisos to sub-section (1A) shall be omitted.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 10 -->

10

(iii) in sub-section (1C), for the words “ten thousand rupees”, the words “twentyfive thousand rupees” shall be substituted.
(iv) after sub-section (1C), the following sub-section shall be added,—
“(1CA) Notwithstanding anything contained in the Act, rules or the bye-laws of
the society, two seats in the Committee of each society shall be reserved for members who shall
not exceed the age of forty years on the date of filing of nomination for election, of whom one
shall be from the non-reserved category and one shall be a woman from the reservation
category provided in sub-section (1) of section 28A.”.
(v) for item (iii) of sub-section (1E), the following item shall be substituted,
namely:—
“(iii) such bifurcation shall be completed within a period of one year from the
date of issue of bifurcation order by the Registrar.”.
(vi) for sub-section (1G), the following shall be substituted, namely:—
“(1G) Notwithstanding anything contained in the bye-laws of a society, the
Committee in office shall co-opt two persons or representatives who are/were in paid service
of a Commercial Bank, Kerala State Co-operative Bank, an Urban Co-operative Bank, Kerala
State Agriculture and Rural Development Bank, a Primary Co-operative Agricultural and
Rural Development Bank, erstwhile District Co-operative Banks or a Service Co-operative
Bank in the Managerial Cadre or Specialization in Co-operation/ Co-operative Management,
Management, Agriculture, Economics, Commerce, Public Finance, Law, Rural Development
and Information Technology as members of the Committee of such society:
Provided that the number of such co-opted members shall not exceed two in addition to
the maximum limit specified in sub-section (1A):
Provided further that such co-opted members shall not have the right to vote in any
election of the co-operative society in their capacity as such member and is not eligible to be
elected as office bearers of the board:

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 11 -->

11

Provided also that such co-opted members of a co-operative society shall also be
members of the board and such members shall be excluded for the purpose of counting the total
number of directors specified in sub-section (1A):
Provided also that if the Committee does not co-opt the persons as specified within a
period of six months from the date on which the Committee is constituted, the Government or
the Registrar, as the case may be, with due notice as may be prescribed shall make such
nominations as specified in the sub-section.”.
(vii) after sub-section (2), the following shall be added as sub-section (2A),—
“(2A) Notwithstanding anything to the contrary contained in the Act, rules or in
the bye-laws of a credit society, no member of the Committee of a society shall be eligible for
election to the Committee for more than three consecutive terms, irrespective of whether the
term is in full or in part.
Explanation.—For the purpose of this sub-section, “credit society” means the Kerala
State Co-operative Bank Limited, Primary Agricultural Credit Societies, Service Co-operative
Banks, Regional Co-operative Banks, Rural Banks, Farmer's Service Co-operative Banks,
Urban Co-operative Banks, The Kerala State Co-operative Agricultural and Rural
Development Bank Limited, Primary Co-operative Agricultural and Rural Development Bank,
Urban Co-operative Societies, Agricultural Improvement Co-operative Societies, Employees
Credit Societies, Rural Co-operative Societies, Primary Housing Co-operative Societies and
Kerala State Housing Federation.”.
(viii) in the proviso to sub-section (3), the words “or more than two societies of
different types” shall be added at the end.
18. Amendment of section 28AB.—In section 28AB of the principal Act, in sub-section
(2), after the words “or any other officer of the committee”, the words “or a delegate of the
society who has been appointed by the committee” shall be inserted.
19. Amendment of section 28B.—In section 28B of the principal Act,—
(i) In sub-section(1), after the word “societies”, the symbols and words “, the state
co-operative union and the circle co-operative unions” shall be inserted.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 12 -->

12

(ii) In sub-section (2) of section 28B, for the words “Special Secretary to
Government” the words and symbol “Special Secretary to Government, Law Department” shall
be substituted.
20. Amendment of section 29.—In section 29 of the principal Act,—
(i) in sub-section (1),—
(a) in clause (cc), for the word “accounts”, the words “audited accounts” shall be
substituted;
(b) for clause (ce), the following clause shall be substituted, namely:—
“(ce) consideration of detailed list of all liabilities of members of the
Committee and the employees of the society, and their family members, due to the society for
the previous financial year.
Explanation.— For the purpose of this clause, “family members” means husband, wife,
their children including adopted children and parents ; and”.
(ii) sub-section (2) shall be substituted as follows, namely:—
“(2) The Registrar or any person deputed by him and the Director of Co-operative
Audit or any person deputed by him may have the right to attend in the committee and in the
general body meeting of any society.”.
21. Amendment of section 31.—In sub-section (3) of section 31 of the principal Act, after
the words “take part”, the words “in the voting for the election of office bearers and” shall be
inserted.
22. Amendment of section 32.— In section 32 of the principal Act,—
(i) in sub-section (1),—
(a) after clause (b) the following clause shall be added as clause (ba), namely:—
“(ba) willful disobedience of execution of orders etc., referred to in section
76 of the Act ; or ”;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 13 -->

13

(b) in clause (d), for the words “who need not be members of the society”, the
words “who shall be from among the members of the society” shall be substituted and the third
proviso and Explanation I shall be omitted and in Explanation II the number “II” shall be
deleted;
(c) in clause (e), for the words “two consecutive terms”, the words “next one
term” shall be substituted.
(ii) in sub-section (4), the following words shall be added at the end, namely:—
“including enrollment of members, provided such members shall not have voting
rights unless an elected committee ratifies the membership.”.
23. Amendment of section 33.—In section 33 of the principal Act,—
(i) in sub-section (1), in clause (b), for the words “who need not be members of the
society”, the words “who shall be from among the members of the society” shall be substituted.
(ii) in sub-section (2),—
(a) after the words “any officer of the society”, the words “including enrollment
of members” shall be inserted;
(b) the following sentence shall be inserted at the end, namely:—
“The members so enrolled shall not have voting right unless an elected
Committee ratifies such membership and if the Committee does not ratify any such
membership, shall specify the reasons thereof for such denial.”.
24. Insertion of new section 34A.—In the principal Act, after section 34, the following
section shall be inserted, namely:—
“34A.

Maintenance of accounts and adoption of common software.—(1) All

co-operative societies shall prepare and keep the books of accounts and financial statements in
the form in the generally accepted accounting principle for preparing profit and loss account
and balance sheet, which enable double entry book keeping system, as may be prescribed.
(2) The Registrar shall issue necessary guidelines for installation, maintenance
and use of common software to all co-operative societies, as may be prescribed.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 14 -->

14

(3) A technical cell with professional and technical team as prescribed shall be
established in the office of the Registrar, in consultation with the Government, to inspect the
security, reliability, data protection and other aspects connected with software and hardware.”.
25. Amendment of section 36A.— In section 36A of the principal Act, for the figures,
words and symbol “10 to 15 (both inclusive)”, the figures, words and symbol “9 to 15 (both
inclusive) and 19 to 28 (both inclusive)” shall be substituted.
26. Amendment of section 56.— In section 56 of the principal Act,—
(i) in sub-section (1), after clause (c), the following clause shall be inserted,
namely:—
“(d)

credit five percent of net profit to the Professional Education Fund

maintained by the Registrar.”.
(ii) in sub-section (2), clause (cc) shall be deleted.
27. Amendment of section 56A.—In section 56A of the principal Act, the following
proviso shall be added, namely:—
“Provided that, if the immovable property is to be utilized for activities connected
with the objectives of the society, it shall seek the prior approval from the Registrar based on
the resolution of the general body of the society.”.
28. Amendment of section 57C.—In section 57C of the principal Act, in sub-section
(1), after the words “providing loans for”, the words “public purposes and for” shall be inserted.
29. Insertion of new section 57E.—In the principal Act, after section 57D, the following
section shall be inserted, namely:—
“57E. Co-operative Revival Fund Scheme.—(1) The Government may, by
notification in the Gazette, frame a scheme to be called “the Co-operative Revival Fund
Scheme” for establishing a fund for the purpose of reviving societies which are weaker or
remain in dormant position due to certain extraordinary situation by providing financial
assistance subject to such terms and conditions to be specified in the scheme and shall be
administered in such manner as may be prescribed.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 15 -->

15

(2) There shall be earmarked to the fund,—
(a) an amount which is not more than fifty percent of the reserve fund,
referred to in clause (a) of sub-section (1) of section 56; and
(b) not more than fifty per cent of the Agriculture Credit Stabilization Fund
set apart by Agricultural Credit Societies from their net profit; as and when required;
(c) such fund that may be granted by Government from time to time; and
(d) any other amount which under the provisions of the scheme may be
credited to the fund.”.
30. Amendment of section 59.—In section 59 of the principal Act, after the existing subsection (2), the following sub-section shall be inserted, namely:—
“(2A) A society shall not sanction loans or advances exceeding the individual
maximum borrowing power fixed by the Registrar and as provided in the bye-laws of the
society. For any contravention of this provision, the Chief Executive and the Committee of the
co-operative society concerned shall be liable for punishment, provided in sub-section (7A) of
section 94 of the Act.”.
31. Insertion of new sections 59A and 59B.—In the principal Act, after section 59, the
following sections shall be inserted, namely:—
“59A. Valuation of property.—The valuation of immovable property to be pledged
as security to a co-operative society shall be valued by an officer/officers authorised by the
Committee in cases where the loan amount is below ten lakhs and where the loan amount
exceeds ten lakhs, by a panel of five members consisting of two officers including the Chief
Executive Officer of the society and two members of the Committee and an independent valuer
authorised by the Committee.
59B. Purchase of movable and immovable properties by the societies.— Societies
shall follow the norms, as may be prescribed, while acquiring movable and immovable
properties by utilizing the own fund of the society.”.
32. Amendment of section 63.—In section 63 of the principal Act,—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 16 -->

16

(i) in sub-section (4), after the first proviso, the following proviso shall be added,
namely:—
“Provided further that in the case of those societies which are liable to file income
tax returns, financial statements for that purpose shall be duly certified by the Auditor, within
three months from the end of the financial year.”.
(ii) for sub-section (9) and the proviso thereto, the following sub-section shall be
substituted, namely:—
“(9) Every co-operative society shall cause to be audited by a team of auditors
appointed by the Director of Co-operative Audit in accordance with the scheme approved and
notified by the State Government. The composition, structure of the team, mode of conducting
audit, mode of processing and preparing audit report shall be included in the scheme approved
by the State Government.”.
(iii) sub-section (10) shall be substituted as follows, namely:—
“(10) The financial accounts of all apex societies and all urban co-operative banks
shall be audited by auditing firms, from among the panel approved by the Director of
Co-operative Audit and the administrative matters and related accounts of assisted apex
societies shall be audited by the departmental auditors and submit the audit reports to the
Director of Co-operative Audit. If the audit discloses any misappropriation or fraud or
defalcation of money or property or assets of the society, audit team shall prepare a special
report and forward the same to the Director of Co-operative Audit and the Registrar. The
Registrar himself, or the Director of Co-operative Audit in consultation with the Registrar, shall
forward the special report to the Vigilance Officer appointed under section 68A for detailed
inquiry.”.
(iv) in sub-section (12), for the words “who need not be”, the words “who shall be
from among the” shall be substituted.
(v) after sub-section (12), the following sub-section shall be inserted, namely:—
“(12A) No auditor or auditing firms or team of auditors shall be entrusted with
the audit of a co-operative society for more than two consecutive audits.”.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 17 -->

17

33. Amendment of section 64.—In section 64 of the principal Act,—
(i) after sub-section (1), the following sub-sections shall be added, namely:—
“(1A) In the case of co-operative societies whose accounts are prepared using a
common software or any other software approved by the Registrar, the audit includes the audit
of information system and evaluation of software as well as hardware.
(1B) If during the audit of information system and evaluation of software and
hardware, any manipulation of records or manipulation in the working of the software or
hardware is revealed, the auditor/auditors/audit firms shall inform the manipulations to the
Director of Co-operative Audit and the Registrar.
(1C) The Registrar himself, or the Director of Co-operative Audit in consultation
with the Registrar shall inform the manipulations in the system to the Police or Vigilance
officer, as the case may be, for investigation.”.
(ii) in sub-section (4A), for the words “one month”, the words “fifteen days” shall
be substituted and for the words “who need not be”, the words “who shall be from among the”
shall be substituted.
(iii) in sub-section (4B), for the words “three months”, the words “forty five days”
shall be substituted.
(iv) in sub-section (5),—
(a) after the words “The auditor”, the words “or team of auditors” shall be
inserted;
(b) for the words “four months”, the words “ninety days” shall be substituted.
(v) after sub-section (5), the following sub-section shall be inserted, namely:—
“(5A) On completion of audit and before submission of audit report to the
Director of Co-operative Audit, the auditor or audit team or audit firm, as the case may be, shall
discuss the audit findings with the Managing Committee of the society concerned and get their
reply in writing.”.
(vi) sub-section (9) shall be substituted as follows, namely:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 18 -->

18

“(9) If the result of the audit held under this section discloses any defect in the
working of the society, the Committee shall take steps to rectify the defects and irregularities
pointed out in the audit report, if any, and place the audit report along with the action taken
report before the general body meeting to be held every year and explain therein the said defects
or the irregularities. The Committee shall continue to take steps for rectification of all the
defects and the irregularities in the audit report and appraise the general body meetings every
year till all the defects and the irregularities are rectified. The Committee shall send a report
of action taken to the Director of Co-operative Audit and to the Registrar within fifteen days
from the date of the general body meeting.”.
(vii) after sub-section (9), the following sub-section shall be added, namely:—
“(9A) If the Director of Co-operative Audit or the person authorized by him to
carry out the audit of a society is of the opinion that any person had attempted to destroy or to
tamper with the records or documents so as to evade legal action on the mischief committed in
the society, he shall report the matter to his controlling officer for filing a complaint to the
Police or the Vigilance Officer in consultation with the Registrar or the person authorized by
him, as the case may be.”.
34. Amendment of section 65.—In section 65 of the principal Act,—
(i) in sub-section (1),—
(a) clause (b) shall be omitted;
(b) for clause (d), the following clause shall be substituted, namely:—
“(d) on an application by the majority of the members of the committee of the
society or by not less than one third of the total members of the society or the number of
members required for quorum for the General Body meeting, whichever is less; or”;
(c) in clause (f), after the words “by a person”, the words “or persons” shall be
added.
(ii) in sub-section (2), after clause (c), the following clause shall be added, namely:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 19 -->

19

“(d) The person/persons related to or involved in the inquiry shall be issued a
notice, indicating the matter of inquiry and he/they shall be provided an opportunity of being
heard, with proper notice by registered post or in person.”.
(iii) after sub-section (2), the following sub-section shall be inserted, namely:—
“(2A) When an inquiry made under this section reveals any defect, the Registrar
or the person or the persons authorized by him to conduct the inquiry, shall prepare a detailed
inquiry report regarding the defects, amount of misappropriation and other losses to the society,
with quantification of individual liability. If the inquiry reveals any offence under section 94,
the enquiry officer shall prepare a special report and submit it to the Registrar and he shall
forward a copy simultaneously to the Police or the Vigilance officer, as the case may be, for
further detailed investigation.”.
(iv) in sub-section (5), for the words “six months”, the words “four months” shall be
substituted.
(v) in sub-section (6), for the words and figure “provisions of section 32”, the words
and symbol “he may initiate action in accordance with the provisions of this Act.” shall be
substituted.
(vi) after sub-section (6), the following sub-section shall be added, namely:—
“(7) If any inquiry reveals that any irregularity, misappropriation or fraud or
defalcation of money or property or assets of the co-operative society is committed or that any
loss is incurred to the society, the Registrar or any officer specifically empowered or authorised
by the Registrar in this behalf shall take immediate necessary steps to recover the
misappropriated or defalcated money or property or assets of the society through legal actions
after assessing the loss.”.
35. Amendment of section 66.—In section 66 of the principal Act,—
(i) after sub-section (2), the following sub-sections shall be inserted, namely:—
“(2A) The Registrar may authorize special team of officers under his control for
the inspection of apex, central and federal co-operative societies and all other primary
co-operative societies.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 20 -->

20

(2B) The report of such inspections shall be communicated in writing to the apex,
central and federal societies and all primary co-operative societies concerned, within a period
of thirty days and the Committee and the chief executive of the society concerned shall be
under an obligation to file a para-wise satisfactory compliance report before the Registrar
within a period of forty five days from the date of such communication.”.
(ii) sub-section (6) and the proviso thereto shall be deleted.
36. Amendment of section 66C.—In section 66C of the principal Act, —
(i) the existing section shall be numbered as sub-section (1).
(ii) the clause (f) in sub-section (1) so numbered, shall be re-lettered as clause (g).
(iii) before clause (g) so re-lettered, the following clause shall be inserted, namely:—
“(f) rectification reports approved by the Committee on audit report and the
resolution of the General Body of the society.”.
(iv) after sub-section (1), the following shall be inserted as sub-section (2),
namely:—
“(2) Every co-operative society shall submit quarterly returns on the credit
activities, duly certified by the chief executive of the co-operative society, which will be duly
reviewed by the Registrar and the rectification report shall be submitted on the basis of the
report evaluated by the Registrar after each quarter. If any society fails to submit the returns on
time, the Registrar shall have the power to impose fine not exceeding Ten Thousand Rupees
based on the classification and category of the Society as may be prescribed.”.
37. Amendment of section 68.—In section 68 of the principal Act,—
(i) in sub-section (1), after the words “winding up of the society”, the words “or on
the basis of the report of the Vigilance Officer” shall be inserted.
(ii) in sub-section (3),—
(a) after the figure and symbols “(2),”, the words “within a period of sixty days”
shall be inserted;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 21 -->

21

(b) the following proviso shall be added, namely:—
“Provided that such period may, at the discretion of the Registrar and for
reason to be recorded in writing, be extended from time to time, however that the extended
period shall not exceed sixty days.”.
38. Insertion of new section 68B.—After section 68A, the following may be added as
section 68B, namely:—
“68B. Power of Government or Registrar to deal with irregularities etc.—(1) The
Government or the Registrar, as the case may be, may forward the cases of misappropriation
or irregularities or corruption in the society which comes under the provisions of the Indian
Penal Code, 1860 or/and of the Prevention of Corruption Act, 1988, to the Police or Vigilance
and Anti-Corruption Bureau, as the case may be, for investigation and further action.
(2) The Registrar shall be the authority to accord sanction for inquiry/enquiry or
investigation and also for taking cognizance of an offence under the Prevention of Corruption
Act, 1988 against the members of the Committee and/or officers and servants of the society.
(3) In the case of Chief Executive Officers appointed by the Government, the
Secretary to Government, Co-operation Department shall be the sanctioning authority.”.
39. Amendment of section 69.—In section 69 of the principal Act, in sub-section (1),—
(i) for clause (h), the following clause shall be substituted, namely:—
“(h) between the society and a creditor of the society; or”.
(ii) after clause (h), the following clauses shall be added as clause (i) and (j),
namely:—
“(i) between the co-operative society and its subsidiaries under section 14AA; or
(j) between the members of the partnership formed under section 14B, such
dispute shall be referred to the Co-operative Arbitration Court constituted under section 70A in
the case of non-monetary disputes and to the Registrar, in the case of monetary disputes; and
the Arbitration Court, or the Registrar, as the case may be, shall decide such dispute and no

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 22 -->

22

other court or other authority shall have jurisdiction to entertain any suit or other proceedings
in respect of such dispute.”.
40. Amendment of section 69A.—In section 69A of the principal Act, in sub-section (1),
the words “dealing with banking business” shall be omitted.
41. Amendment of section 70.—In section 70 of the principal Act, in sub-section (6), after
the words “pass an award”, the words “within a period of one year in cases where monetary
matters are involved” shall be inserted.
42. Amendment of section 70A.—In section 70A of the principal Act, for sub-section (2),
the following sub-section shall be substituted, namely:—
“(2) The presiding officer of the Arbitration Court shall be an officer of and above
the rank of a Munsiff-Magistrate of the judicial service.”.
43. Amendment of section 73.—In section 73 of the principal Act,—
(i) in sub-section (2A) and its Explanation, for the words “three years”, the words
“two years” shall be substituted.
(ii) in sub-section (2A), after the Explanation, the following provisos shall be added,
namely:—
“Provided that if the winding up proceedings cannot be completed within a period
of two years from the date of appointment of liquidator under sub-section (1) of section 72, the
liquidator shall submit a report to the Government through the Registrar stating the procedural
constraints which prevent him to complete the proceedings and in such cases issue the final
order with the permission of the Government, within the time stipulated by the Government as
may be prescribed:
Provided however that such extension shall not exceed a period of one year.”.
44. Amendment of section 74C.—In section 74C of the principal Act,—
(i) the existing section shall be numbered as sub-section (1);
(ii) after sub-section (1) so numbered, the following sub-section shall be added,
namely:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 23 -->

23

“(2) The Registrar shall suggest remedial action to Government to restructure the
activities, if necessary, based on the report of inspection.".
45. Amendment of section 76.—In section 76 of the principal Act, after the words, figures
and bracket “sub-section (2) of section 68”, the words, figures and letter “or every order of the
Ombudsman, provided under section 69A, or an order” shall be inserted.
46. Amendment of section 80.—In section 80 of the principal Act,—
(i) in sub-section (3), the following sentence shall be added at the end, namely:—
“The appointment shall be regularised only after verifying his/her character and
antecedents on subsequent police verification, as may be prescribed.”.
(ii) in sub-section (3A),—
(a) after the words “servants of the societies”, the words “except the chief
executive of the societies” shall be inserted;
(b) the following sentence shall be added at the end, namely:—
“The appointment of Chief Executive of apex societies shall be made by the
Government after fixing qualifications.”.
(iii) in sub-section (5),—
(a) for the words "three percent", the words “four per cent” shall be substituted;
(b) in the proviso, for the words “thirty three”, the words “twenty five” shall be
substituted.
47. Amendment of section 80A.—In section 80A of the principal Act, in sub-section (1),
after the words “of this Act”, the words “and for the employees of Co-operative Unions in the
State” shall be inserted.
48. Amendment of section 80B.—In section 80B of the principal Act, for sub-section (1),
the following shall be substituted, namely:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 24 -->

24

“(1) Notwithstanding anything contained in this Act or the rules made thereunder or
in the bye-laws of any society relating to the recruitment of officers and servants thereof, but
subject to section 80BB, the Government shall, by notification in the Gazette, constitute a
Co-operative Examination Board for the conduct of written examination for all direct
recruitment to the posts of and above the category of Junior Clerks in all co-operative societies,
Boards and other institutions under the control of the Registrar:
Provided that the Registrar may, taking into consideration the financial capacity and
viability of such society, exempt any society or class of societies from the provisions of this
sub-section, in the manner as may be prescribed.”.
49. Amendment of section 88.—In section 88 of the principal Act, for clause (e) of subsection (1), the following clause shall be substituted, namely:—
“(e) the Assistant Director of Co-operative Audit having jurisdiction over the circle,
ex-officio;”.
50. Amendment of section 88B.—In clause (iii) of section 88B of the principal Act, after
the words “an officer”, the words “or an administrator or an administrative committee
consisting of not more than three persons, one among them shall be the convenor” shall be
inserted.
51. Amendment of section 89.—In section 89 of the principal Act, in sub-section (4),—
(i) in clause (d), for the word, letter and bracket “clause (c)”, the word, letter and
bracket “clause (b)” shall be substituted.
(ii) in clause (e), for the word, letter and bracket “clause (d)”, the word, letter and
bracket “clause (c)” shall be substituted.
(iii) in clause (f), for the word, letter and bracket “clause (e)”, the word, letter and
bracket “clause (d)” shall be substituted.
52. Amendment of section 89B.—In clause (iii) of section 89B of the principal Act, after
the words “Co-operative Department”, the words “not below the rank of Additional Registrar
or an administrator or an administrative committee consisting of three persons, one among
them shall be the Convenor” shall be inserted.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 25 -->

25

53. Amendment of section 91.—In section 91 of the principal Act, in clause (c) of subsection (1), before the words “to spread”, the words “to establish educational institutions and”
shall be inserted.
54. Amendment of section 94.—In section 94 of the principal Act,—
(i) in sub-section (2), for the words “two thousand”, the words “five thousand” shall
be substituted.
(ii) in sub-section (3), for the words “two thousand”, the words “five thousand” shall
be substituted.
(iii) in sub-section (4), for the words “five thousand”, the words “ten thousand” shall
be substituted.
(iv) in sub-section (4A), for the words “five thousand”, the words “ten thousand”
shall be substituted.
(v) in sub-section (4B), for the words “one thousand”, the words “five thousand”
shall be substituted.
(vi) in sub-section (5), in clause (b), for the words “five thousand”, the words “ten
thousand” shall be substituted.
(vii) in sub-section (6), for the words “five thousand”, the words “ten thousand” shall
be substituted.
(viii) in sub-section (7), for the words “five thousand”, the words “ten thousand”
shall be substituted.
(ix) after sub-section (7), the following shall be added as sub-section (7A),
namely:—
“(7A) Any Chief Executive and the Committee of the Co-operative society who
contravenes the provisions of sub-section (3) of section 59 shall be punishable with fine which
may extend to ten thousand rupees.”.
(x) in sub-section (10), for the brackets, figures, symbols and word “(6) and (7)”, the
brackets, figures, symbol, word and letter “(6), (7) and (7A)” shall be substituted.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 26 -->

26

55. Amendment of section 95.—In sub-section (4) of section 95 of the principal Act, for
the brackets, figures, symbols and word “(2), (3), (4), (5), (6) and (7)”, the brackets, figures,
symbols, word and letter “(2), (3), (4), (5), (6), (7) and (7A)” shall be substituted.
56. Insertion of new section 106A.—In the principal Act, after section 106, the following
section shall be inserted, namely: —
“106A. Power to remove difficulties.—(1) If any difficulty arises in giving effect to
the provisions of this Act, as amended by the Kerala Co-operative Societies (Amendment) Act,
2023, the State Government may, by general or special order published in the Official Gazette,
make such provisions not inconsistent with the provisions of this Act as which appear it to be
necessary or expedient for removing the difficulty:
Provided that no such order shall be made after the expiry of a period of two years from
the commencement of the Kerala Co-operative Societies (Amendment) Act, 2023.
(2) Every order made under this section shall be laid, as soon as may be after it is
made, before the Legislative Assembly.”.
57. Amendment of Schedule I.—In the Schedule I of the principal Act, after serial number
15, the following serial numbers and entries shall be added, namely:—
“16. Kerala State Women Co-operative Federation Limited (VANITHAFED).
17. Kerala State Co-operative Tourism Federation Limited (TOURFED).
18. Kerala State Labour Co-operative Federation Limited (LABOURFED).
19. Kerala State Co-operative Hospital Federation Limited (HOSPITALFED).”.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 27 -->

27

കേരള സര്‍ക്കാര്‍ക്
നിയമ (നിയമനിര്‍മ്മാണം-എച്ച്) വകുപ്പ്

വിജ്ഞാപനം
നമ്പര്‍മ് 142/ടേഗ്.എച്ച്2/2022/നിയമം.

തിരുവനന്തപുരം, 2024 ജൂൺ 7
1199 ഇെവം 24
1946 കജേഷ്ഠം 17.

കകരള സംസ്ഥാന നിയമസഭയുടെ താടെപ്പറയുന്ന ആക്റ് ടപാതുജനങ്ങളുടെ
അറിവികേയ്കായി

ഇതിനാല്‍

പ്പസിദ്ധടപ്പെുത്തുന്നു.

നിയമസഭ

പാസ്സാകിയ

പ്പകാരമുള്ള ബില്ലിന് 2024 ഏപ്പില്‍ 26-ാം തീയതി ഗവര്‍മ്ണറുടെ അനുമതി േഭിച്ചു.
ഗവര്‍മ്ണറുടെ ഉത്തരവിന്‍പപ്പകാരം,

ടക. ജി. സനല്‍ കുമാര്‍മ്,
നിയമ ടസപ്കട്ടറി.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 28 -->

28

2024-ലെ 9-ാാം ആേ്റ്

2023-ലെ കേരള സഹേരണ സാംഘ (കേദഗതി) ആേ്റ്
1969-ടേ കകരള സഹകരണ സംഘ ആക്റ്
വീണ്ും കഭദഗതി ടെയ്യുന്നതിനുള്ള
ഒരു
ആക്റ്
പീഠിക.—1969-ടേ കകരള സഹകരണ സംഘ ആക്റ് (1969-ടേ 21-ാം ആക്റ്)
ഇതിനുകേഷം

കാണുന്ന

ആവേേങ്ങള്‍ക്കായി

വീണ്ും

കഭദഗതി

ടെയ്യുന്നത്

യുക്തമായിരികുകയാല്‍;
ഭാരത റിപ്പബ്ലികിടെ എെുപത്തിനാോം സംവത്സരത്തില്‍ താടെപ്പറയും പ്പകാരം
നിയമമുണ്ാകുന്നു:—
1. െുരുകകപ്പരും പ്പാരംഭവും.—(1) ഈ ആക്റിന് 2023-ടേ കകരള സഹകരണ
സംഘ (കഭദഗതി) ആക്റ് എന്ന് കപര് പറയാം.
(2) ഇത് ഉെന്‍പ പ്പാബേേത്തില്‍ വരുന്നതാണ്.
2. 2-ാം വകുപ്പിടെ കഭദഗതി.—1969-ടേ കകരള സഹകരണ സംഘ ആക്റിടെ
(1969-ടേ 21-ാം ആക്റ്) (ഇതിനുകേഷം പ്പധാന ആക്റ് എന്നാണ് പരാമര്‍മ്േികടപ്പെുക)
2-ാം വകുപ്പില്‍,—
(i) (എബി) ഖണ്ഡത്തില്‍ താടെപ്പറയുന്ന വാെകം അവസാന ഭാഗത്തായി
കൂട്ടികച്ചര്‍മ്കകണ്താണ്, അതായത്:—
“അകൗണ്ുകള്‍ക് കമ്പേൂട്ടര്‍മ്വത്കരിച്ചിട്ടുളള സഹകരണ സംഘങ്ങളുടെ
കാരേത്തില്‍,

അകൗണ്ുകളുടെ

കസാഫ്റ്റടവയര്‍മ്
്

ടസാേേൂഷന്‍പസ്

മുകഖനയുള്ള

ഒത്തുകനാകേും ഇന്‍പഫ്റര്‍മ്കമഷന്‍പ സിസ്റ്റത്തിടെ ആഡിറ് ടെയ്യേും ഡാറാ മമകപ്ഗഷനും
ഇതില്‍ ഉള്‍ക്ടപ്പെുന്നു.”.
(ii) (എസി) ഖണ്ഡത്തിനു കേഷം താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 29 -->

29

“(എഡി)

“അഡ്മിനിസ്കപ്െറീവ്

ആഡിറ്”

എന്നാല്‍

സംഘത്തിടെ

രൂപീകരണം, നെത്തിപ്പും സ്ഥാപനവും, ബുകുകളുടെയും അകൗണ്ുകളുടെയും മറ്
കരഖകളുടെയും സൂക്ഷികല്‍, ആഭേന്തര നിയപ്ന്തണ സംവിധാനം ഉള്‍ക്ടപ്പടെയുളള
സംഘത്തിടെ എല്ലാ കാരേങ്ങളും, സഹകരണ തതവങ്ങള്‍ക്കനുസരിച്ച് അംഗങ്ങളുടെ
സാമ്പത്തിക

കക്ഷമം

കപ്പാത്സാഹിപ്പികുന്നതിന്

അതിടെ

പ്പവര്‍മ്ത്തനങ്ങള്‍ക്

എപ്തകത്താളം ഉപകയാഗപ്പദമായിരുന്നു എന്നതിടെയും സസൂക്ഷ്മമായ വിേയിരുത്തല്‍
എന്നര്‍മ്ഥമാകുന്നതും ഇതില്‍ കംപ്ലയന്‍പസ് ആഡിറും ടപര്‍മ്കഫ്റാര്‍മ്മന്‍പസ് ആഡിറും
ഐ.റി. ആഡിറും ഉള്‍ക്ടപ്പെുന്നതുമാകുന്നു;”.
(iii)

(ഡിഎ)

ഖണ്ഡത്തിനു

കേഷം,

താടെപ്പറയുന്ന

ഖണ്ഡങ്ങള്‍ക്

കെര്‍മ്കകണ്താണ്, അതായത്:—
“(ഡിബി) “പ്പാഥമിക കാര്‍മ്ഷിക വായ്പാ സംഘങ്ങള്‍ക്കുളള ടപാതു
കസാഫ്റ്റടവയര്‍മ്”
്
മുെുവന്‍പ

എന്നാല്‍

മദനംദിന

പ്പാഥമിക

പ്പവര്‍മ്ത്തനങ്ങളും

കാര്‍മ്ഷിക

വായ്പാ

ഉള്‍ക്ടകാള്ളുന്ന,

സംഘങ്ങളുടെ

ഒരു

കകപ്രീകൃത

രൂപകല്‍പ്പനയിേൂടെയുളള, ഫ്റേപ്പദമായ ഒരു കസാഫ്റ്റടവയര്‍മ്
്
ടസാേേൂഷന്‍പ എന്ന്
അര്‍മ്ഥമാകുന്നു.
(ഡിസി)

“കൺകസാര്‍മ്ഷേം”

എന്നാല്‍

ടപാതു

ആവേേത്തിനായി

ധനസഹായം േഭേമാകുന്നതിനുളള ഫ്റണ്് സവരൂപികുന്നതിനു കവണ്ി ഒരു പുതിയ
സ്ഥാപനം ഉണ്ാകുക എന്ന ടപാതു ഉകേേേത്തിടെ അെിസ്ഥാനത്തില്‍, സംസ്ഥാന
സര്‍മ്കാരിടെ അംഗീകാരകത്താടെ, രൂപീകൃതമായ സഹകരണ സംഘങ്ങളുടെ ഒരു
ഔപൊരിക കൂട്ടായ്മ എന്നര്‍മ്ഥമാകുന്നു;”.
(iv) (ഐബി) ഖണ്ഡത്തിനു പകരം താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(ഐബി)

“ടഫ്റഡറല്‍

സഹകരണ

സംഘം”

എന്നാല്‍

അതിടെ

പ്പവര്‍മ്ത്തന കമഖേയായി ഒന്നില്‍ കൂെുതല്‍ ജില്ലകളുളളതും സംസ്ഥാന സര്‍മ്കാകരാ
വേക്തികകളാ മറ് സഹകരണ സംഘങ്ങകളാ അതിടെ അംഗങ്ങളായിട്ടുളളതുമായ ഒരു
സഹകരണ

സംഘം

എന്നര്‍മ്ഥമാകുന്നു.

എന്നാല്‍,

സംഘത്തിടേ

വേക്തിഗത

അംഗങ്ങളുടെ എണം സംഘത്തിടെ ടമാത്തം അംഗസംഖേയുടെ ഇരുപത്തിയഞ്ച്
േതമാനത്തില്‍ അധികരികാന്‍പ പാെുളളതല്ല:

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 30 -->

30

എന്നാല്‍, വേക്തിഗത അംഗങ്ങളുടെ എണം സംബന്ധിച്ചുളള വേവസ്ഥ
2023-ടേ കകരള സഹകരണ സംഘ (കഭദഗതി) ആക്റ് പ്പാബേേത്തില്‍ വരുന്നതിനു മുമ്പ്
നിേവിേുണ്ായിരുന്ന സംഘങ്ങള്‍ക്ക് ബാധകമാകുന്നതല്ല;”.
(v) (ഒഎഎ) ഖണ്ഡത്തിനു പകരം താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(ഒഎഎ) “പ്പാഥമിക കാര്‍മ്ഷിക വായ്പാ സംഘം” എന്നാല്‍, കാര്‍മ്ഷിക
ആവേേങ്ങള്‍ക്കകാ അനുബന്ധ കാര്‍മ്ഷിക പ്പവര്‍മ്ത്തനങ്ങള്‍ക്കകാ കവണ്ി അതിടെ
അംഗങ്ങള്‍ക്ക് സാമ്പത്തിക സഹായം നല്‍കുക എന്നത് പ്പാഥമിക േക്ഷേകമാ പ്പധാന
ബിസിനകസ്സാ ആയിട്ടുള്ളതും, പ്പവര്‍മ്ത്തന കമഖേ ഒരു വികല്ലജികോ, പഞ്ചായത്തികോ,
മുനിസിപ്പാേിറിയികോ ആയി പരിമിതടപ്പെുത്തിയിട്ടുള്ളതുമായ ഒരു സര്‍മ്വീസ് സഹകരണ
സംഘം, സര്‍മ്വീസ് സഹകരണ ബാങ്ക്, ഒരു കാര്‍മ്ഷിക സര്‍മ്വീസ് സഹകരണ ബാങ്ക്
അടല്ലങ്കില്‍ ഒരു പ്ഗാമീണ ബാങ്ക് എന്നര്‍മ്ഥമാകുന്നതും അത്തരം വായ്പകളുടെയും
അഡവാന്‍പസുകളുടെയും പേിേ നിരകും പ്പവര്‍മ്ത്തന കമഖേയും രജിസ്പ്ൊര്‍മ് നിശ്ചയിച്ച
പ്പകാരമായിരികുന്നതുമാണ്:
എന്നാല്‍,
2000

ജനുവരി

1-ന്

പ്പവര്‍മ്ത്തന

കമഖേടയ

നിേവിേുണ്ായിരുന്ന

സംബന്ധിച്ചുളള

സംഘങ്ങള്‍ക്കകാ

നിയപ്ന്തണം

ബാങ്കുകള്‍ക്കകാ

ബാധകമാകുന്നതല്ല.”.
(vi) (ഒബി) ഖണ്ഡത്തിനു പകരം താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(ഒബി) “പ്പാഥമിക വായ്പാ സംഘം” എന്നാല്‍ അതിടെ അംഗങ്ങള്‍ക്ക്
കെം

നല്‍കുന്നതിനും

നികക്ഷപത്തിനും

കവണ്ി

അതിടെ

അംഗങ്ങളില്‍

നിന്നും

നികക്ഷപം സവീകരികുക എന്നത് അതിടെ പ്പാഥമിക േക്ഷേകമാ പ്പധാന ബിസിനകസ്സാ
ആയതും അതിടെ ഉപനിയമങ്ങള്‍ക് പ്പകാരം മറ് സഹകരണ സംഘങ്ങടള അതിടെ
അംഗങ്ങളാകാന്‍പ അനുവദികാത്തതുമായ പ്പാഥമിക കാര്‍മ്ഷിക ടപ്കഡിറ് സംഘം
ഒെിടകയുളള സഹകരണ സംഘം എന്നര്‍മ്ഥമാകുന്നു;”.
(vii) (ഒഡി) ഖണ്ഡത്തിനു പകരം താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 31 -->

31

“(ഒഡി) “പ്പാഥമിക സഹകരണ സംഘം” എന്നാല്‍ സംസ്ഥാനടത്ത ഒരു
റവനേൂ ജില്ലയികോ ഒന്നിേധികം ജില്ലകളികോടപെുന്ന, ഏടതങ്കിേും വിനിര്‍മ്കേേികടപ്പട്ട
പ്പകദേത്ത് അധികാരിത ഉളളതും വേക്തികളും, മറ് സംഘങ്ങളും, സംസ്ഥാന സര്‍മ്കാരും,
തകേേ സവയംഭരണ സ്ഥാപനങ്ങളും അതിടെ അംഗങ്ങളായിട്ടുളളതുമായ ഒരു സംഘം
എന്നര്‍മ്ഥമാകുന്നു;”.
(viii) (പി) ഖണ്ഡത്തില്‍ “ഏടതാരു ആളും” എന്നീ വാകുകള്‍ക്കു പകരം
“സംസ്ഥാന

സര്‍മ്കാരിടെ

മകറടതാരു

ഉകദോഗസ്ഥനും”

എന്നീ

വാകുകള്‍ക്

കെര്‍മ്കകണ്താണ്.
(ix) (കേുബി) ഖണ്ഡത്തിനു കേഷം താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(കേുബിഎ)

“സാമൂഹേ

സഹകരണ

സംഘങ്ങള്‍ക്”

എന്നാല്‍

ഭിന്നകേഷികാര്‍മ്, പ്പായമായവര്‍മ്, പ്ൊന്‍പസ്ടജെറുകള്‍ക്, വിഷാദം ബാധിച്ച ആളുകള്‍ക്,
മാനസിക

ടവല്ലുവിളികള്‍ക്

കക്ഷമത്തിനു

കവണ്ി

കനരിെുന്നവര്‍മ്

കപാേുള്ള

സാമൂഹിക

വിഭാഗങ്ങളുടെ

രൂപീകരിച്ച

പ്പാഥമിക

സഹകരണ

സംഘങ്ങള്‍ക്

എന്നര്‍മ്ഥമാകുന്നു;”.
(x)

(ആര്‍മ്എ)

വികസന ബാങ്ക്”

ഖണ്ഡത്തില്‍,

എന്നീ

“സംസ്ഥാന സഹകരണ കാര്‍മ്ഷിക-പ്ഗാമീണ

വാകുകള്‍ക്കു

മുമ്പായി

“കകരള”

എന്ന

വാക്

കെര്‍മ്കകണ്താണ്.
(xi) (യു) ഖണ്ഡത്തിനു കേഷം താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(വി) “യുവജന സഹകരണ സംഘങ്ങള്‍ക്” എന്നാല്‍ ഒരു ജില്ലയ്കകത്ത്
പ്പവര്‍മ്ത്തനപരിധിയുളളതും ടതാെിേവസരവും വരുമാനവും സൃഷ്ടികല്‍, യുവജനകക്ഷമം
എന്നീ േക്ഷേങ്ങകളാടെ സംരഭകതവം, പുതിയ സാകങ്കതികവിദേ, നൂതന വിദേകള്‍ക്, സ്റ്റാര്‍മ്ട്ട്അപ്പുകള്‍ക് എന്നിവ കപ്പാത്സാഹിപ്പികുന്നതിനുമായി രജിസ്റ്റര്‍മ് ടെയ്തിട്ടുള്ള സഹകരണ
സംഘങ്ങള്‍ക് എന്നര്‍മ്ഥമാകുന്നു.”.
3. 3-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 3-ാം വകുപ്പില്‍,—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 32 -->

32

(i) (1)-ാം ഉപവകുപ്പില്‍ “ഒരു വേക്തിടയ” എന്നീ വാകുകള്‍ക്കു പകരം
“സംസ്ഥാന സര്‍മ്കാരിടെ ഒരു ഓഫ്റീസടറ” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
(ii) (2)-ാം ഉപവകുപ്പില്‍ “ഏടതാരാള്‍ക്കും” എന്ന വാകിനു പകരം “സംസ്ഥാന
സര്‍മ്കാരിടെ ഏടതാരു ഓഫ്റീസര്‍മ്കും” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
4. 7-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 7-ാം വകുപ്പില്‍,—
(i) (1)-ാം ഉപവകുപ്പില്‍,—
(എ) (ഡി) ഖണ്ഡത്തില്‍ “െട്ടങ്ങള്‍ക്” എന്ന വാകിനും െിഹ്നത്തിനും കേഷം
വരുന്ന “ആെ്” എന്ന വാക് നീകം ടെകയ്യണ്താണ്;
(ബി) (ഇ) ഖണ്ഡത്തില്‍, “രജിസ്പ്ൊര്‍മ്ക് കബാദ്ധേമായാല്‍ അകേഹത്തിന്
അകപക്ഷ സവീകരിച്ച തീയതി മുതല്‍ ടതാണൂറ് ദിവസത്തിനകം ആ സംഘവും അതിടെ
ഉപനിയമങ്ങളും രജിസ്റ്റര്‍മ് ടെയ്യാവുന്നതാണ്.” എന്നീ വാകുകള്‍ക്കും െിഹ്നത്തിനും
പകരം “; കൂൊടത” എന്ന െിഹ്നവും വാകും കെര്‍മ്കകണ്താണ്;
(സി) (ഇ) ഖണ്ഡത്തിനു കേഷം താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(എഫ്റ്) ഏറവും കുറഞ്ഞ ഓഹരി മൂേധനമായി നിര്‍മ്േിഷ്ട വായ്പാ
സംഘങ്ങള്‍ക് രണ്ു േക്ഷത്തി അന്‍പപതിനായിരം രൂപ സമാഹരിടച്ചന്നും വായ്കപതര
സഹകരണ സംഘങ്ങള്‍ക് ഒരു േക്ഷം രൂപ സമാഹരിടച്ചന്നും;
രജിസ്പ്ൊര്‍മ്ക് കബാദ്ധേമായാല്‍ അകേഹത്തിന് അകപക്ഷ സവീകരിച്ച
തീയതി മുതല്‍ അറുപത് ദിവസത്തിനകം ആ സംഘവും അതിടെ ഉപനിയമങ്ങളും
രജിസ്റ്റര്‍മ് ടെയ്യാവുന്നതാണ്:
എന്നാല്‍, ഈ ഖണ്ഡത്തിടേ ഏറവും കുറഞ്ഞ ഓഹരി മൂേധനം
സംബന്ധിച്ച വേവസ്ഥ പട്ടിക ജാതികള്‍ക്/പട്ടിക വര്‍മ്ഗങ്ങള്‍ക്, മത്സേബന്ധനം, വനിത,
പ്ൊന്‍പസ്ടജെറുകള്‍ക്,

പ്പാഥമിക

ആനര്

മാതൃകാ

ക്ഷീകരാല്‍പ്പാദക

സഹകരണ

സംഘങ്ങള്‍ക്, സ്കൂളുകള്‍ക്, കകാകളജുകള്‍ക്, പരമ്പരാഗത വോവസായിക സഹകരണ
സംഘങ്ങള്‍ക് എന്നിവയ്ക് ബാധകമാകുന്നതല്ല.”.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 33 -->

33

(ii) (2)-ാം ഉപവകുപ്പില്‍ “ഏെ് ദിവസത്തിനകം” എന്നീ വാകുകള്‍ക്കു പകരം
“പതിനഞ്ച് ദിവസത്തിനകം” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
(iii) (3)-ാം ഉപവകുപ്പില്‍ “ടതാണൂറ് ദിവസത്തിനകം” എന്നീ വാകുകള്‍ക്കു
പകരം “അറുപത് ദിവസത്തിനകം” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
5.

8എ

വകുപ്പിടെ

ഉപവകുപ്പില്‍

കഭദഗതി.—പ്പധാന

“അറുപത്

എവിടെടയാടകയാകണാ

ആക്റിടേ

8എ

ദിവസത്തിനുളളില്‍”
വരുന്നത്

വകുപ്പിടെ

എന്നീ

അവിടെടയല്ലാം

(2)-ാം

വാകുകള്‍ക്

“നാല്‍പ്പത്തിയഞ്ച്

ദിവസത്തിനുള്ളില്‍” എന്നീ വാകുകള്‍ക് പകരം കെര്‍മ്കകണ്താണ്.
6. 14-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 14-ാം വകുപ്പില്‍,—
(i) 14-ാം വകുപ്പിടെ മാര്‍മ്ജിനല്‍ േീര്‍മ്ഷകത്തില്‍ “കൂട്ടികച്ചര്‍മ്കുകയും” എന്ന
വാകിന് കേഷം “േയികുകയും” എന്ന വാക് കെര്‍മ്കകണ്താണ്.
(ii) (1)-ാം ഉപവകുപ്പില്‍,—
(എ) “സംഘത്തിന്,” എന്ന വാകിനും െിഹ്നത്തിനും കേഷം “രജിസ്പ്ൊറുടെ
മുന്‍പകൂട്ടിയുളള

അംഗീകാരകത്താെു

കൂെിയും,”

എന്നീ

വാകുകളും

െിഹ്നവും

കെര്‍മ്കകണ്താണ്;
(ബി) “മൂന്നില്‍ രണ്ു ഭാഗത്തിടെ” എന്നീ വാകുകള്‍ക്കു പകരം “കകവേ”
എന്ന വാക് കെര്‍മ്കകണ്താണ്.
(iii) (2)-ാം ഉപവകുപ്പില്‍, “സംഘങ്ങള്‍ക്ക്,” എന്ന വാകിനും െിഹ്നത്തിനും
കേഷം “രജിസ്പ്ൊറുടെ മുന്‍പകൂട്ടിയുളള അംഗീകാരകത്താെു കൂെിയും,” എന്നീ വാകുകളും
െിഹ്നവും കെര്‍മ്കകണ്തും “മൂന്നില്‍ രണ്ു ഭാഗത്തിടെ” എന്നീ വാകുകള്‍ക്കു പകരം
“കകവേ” എന്ന വാക് കെര്‍മ്കകണ്തുമാണ്.
(iv)

(2)-ാം

ഉപവകുപ്പിനു

കേഷം

(2എ)

ഉപവകുപ്പായി

താടെപ്പറയുന്നവ

കെര്‍മ്കകണ്താണ്,—
“(2എ) നിേവിേുളള മകറടതങ്കിേും നിയമത്തികോ െട്ടങ്ങളികോ ഏടതാരു
സംഘത്തിടെയും ഉപനിയമങ്ങളികോ വിരുദ്ധമായി എന്തുതടന്ന അെങ്ങിയിരുന്നാേും
അങ്ങടനയുള്ള സംഘത്തിടെ ജനറല്‍ കബാഡി കയാഗത്തില്‍ കകവേ ഭൂരിപക്ഷത്തില്‍

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 34 -->

34

പ്പകമയം

പാസ്സാകി

ഒകന്നാ

അതിേധികകമാ

സംഘങ്ങള്‍ക്ക്

മറ്

ഏടതങ്കിേും

സംഘവുമായി േയികാവുന്നതാണ്:
എന്നാല്‍, അങ്ങടനയുള്ള േയനം നെപ്പിോകുന്നതിന് മുമ്പ്, പ്പകമയം
പാസ്സാകിടകാണ്് ഏടതാരു സംഘവുമായാകണാ േയനത്തില്‍ ഏര്‍മ്ടപ്പകെണ്ത് ആ
സംഘം അതിടെ ജനറല്‍ കബാഡി കയാഗത്തില്‍ കകവേ ഭൂരിപക്ഷകത്താടെ പാസ്സാകിയ
ഒരു പ്പകമയത്തിേൂടെ അത്തരം േയനത്തിന് അംഗീകാരം നല്‍കകണ്താണ്.”.
(v) (3)-ാം

“(2)-ാം

ഉപവകുപ്പില്‍,

ഉപവകുകപ്പാ”

എന്ന

െിഹ്നത്തിനും

അകത്തിനും വാകിനും പകരം “(2)-ാം ഉപവകുകപ്പാ അടല്ലങ്കില്‍ (2എ) ഉപവകുകപ്പാ”
എന്ന െിഹ്നങ്ങളും അകങ്ങളും വാകുകളും കെര്‍മ്കകണ്തും “മകമാറകമാ, വിഭജനകമാ,
കൂട്ടികച്ചര്‍മ്കകോ” എന്നീ വാകുകള്‍ക്കും െിഹ്നത്തിനും പകരം “കൂട്ടികച്ചര്‍മ്കകോ,
േയനകമാ, മകമാറകമാ അടല്ലങ്കില്‍ വിഭജനകമാ” എന്നീ വാകുകളും െിഹ്നങ്ങളും
കെര്‍മ്കകണ്തുമാണ്.
(vi) (7)-ാം ഉപവകുപ്പിനു കേഷം താടെപ്പറയുന്ന ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(8) (1)-ാം ഉപവകുകപ്പാ (2)-ാം ഉപവകുകപ്പാ അടല്ലങ്കില്‍ (2എ) ഉപവകുകപ്പാ
പ്പകാരം പ്പസ്തുത സംഘങ്ങള്‍ക് തയ്യാറാകിയതും രജിസ്പ്ൊര്‍മ് അംഗീകരിച്ചതുമായ
ആസ്തികളും
േയന

ബാദ്ധേതകളും

പദ്ധതിയും,

അതതു

മകമാറുന്നതിനുളള
സംഗതികപാടേ,

വിേദമായ
രജിസ്പ്ൊറും

പദ്ധതിയും
സംഘങ്ങളും

പ്പസിദ്ധീകരികകണ്താണ്.”.
7. 14എഎ വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 14എഎ വകുപ്പില്‍,—
(i)

(2)-ാം

ഉപവകുപ്പിനു

കേഷം

താടെപ്പറയുന്ന

ഉപവകുപ്പുകള്‍ക്

കെര്‍മ്കകണ്താണ്, അതായത്:—
“(2എ) അനുബന്ധ സ്ഥാപനങ്ങളികേയ്കുളള ഓഹരിമൂേധന വിഹിതകമാ
സാമ്പത്തിക സഹായകമാ 56-ാം വകുപ്പിടെ (2)-ാം ഉപവകുപ്പില്‍ വേവസ്ഥ ടെയ്തിട്ടുള്ള
പ്പകാരം സംഘത്തിടെ മിച്ച അറാദായത്തില്‍ നിന്നും വഹികകണ്തും അനുബന്ധ
സ്ഥാപനങ്ങളികേയ്കുളള ഓഹരി മൂേധനം ഒെിടകയുള്ള ഏടതാരു തുെര്‍മ് നികക്ഷപവും,

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 35 -->

35

രജിസ്പ്ൊര്‍മ് നിര്‍മ്കേേികുന്ന മാനദണ്ഡങ്ങള്‍ക്ക് വികധയമായി സംഘം/ബാങ്കില്‍ നിന്നും
വായ്പയായി അനുവദിച്ചു നല്‍കകണ്താണ്.
(2ബി) സര്‍മ്കാരില്‍ നിന്ന് സാമ്പത്തിക സഹായം സവീകരിച്ച ഏടതാരു
സംഘവും/ബാങ്കും

അനുബന്ധസ്ഥാപനങ്ങളിടേ

ഡയറക്ടര്‍മ്

കബാര്‍മ്ഡില്‍

കകരള

സര്‍മ്കാരിടെ കനാമിനികടള, നിര്‍മ്ണയികടപ്പട്ട പ്പകാരം, ഉള്‍ക്ടപ്പെുകത്തണ്താണ്.
(2സി) രജിസ്പ്ൊര്‍മ്, അനുബന്ധസ്ഥാപനങ്ങളുടെ ആഡിറ്, കരഖകളുടെ
പരികോധനയും ഒത്തുകനാകേും നിര്‍മ്ണയികടപ്പട്ട പ്പകാരം, നെകത്തണ്താണ്;
(2ഡി) അനുബന്ധസ്ഥാപനങ്ങള്‍ക്ക് സംഘം/ബാങ്കില്‍ നിന്നും ഏടതങ്കിേും
ഓഹരി

മൂേധന

വിഹിതകമാ

സാമ്പത്തിക

സഹായകമാ

നല്‍കുന്നത്,

ബന്ധടപ്പട്ട

സംഘം/ബാങ്കിടെ ടപാതുകയാഗം പാസ്സാകിയ പ്പകമയത്തിടെ അെിസ്ഥാനത്തില്‍
രജിസ്പ്ൊറുടെ മുന്‍പകൂര്‍മ് അംഗീകാരകത്താടെ ആയിരികകണ്താണ്.
(2ഇ)

സംഘം

അതിടെ

അനുബന്ധസ്ഥാപനങ്ങള്‍ക്ക്

ഫ്റണ്്

മകമാറുന്നതും ആസ്തികള്‍ക് പണയടപ്പെുത്തുന്നതും പ്പസ്തുത സംഘം/ബാങ്കിടെ
ടപാതുകയാഗം

പാസ്സാകുന്ന

പ്പകമയത്തിടെ

അെിസ്ഥാനത്തില്‍,

സര്‍മ്കാരിടെ

മുന്‍പകൂട്ടിയുളള അനുമതികയാടെ ആയിരികകണ്താണ്.”.
(ii) നിേവിേുളള (3)-ാം ഉപവകുപ്പിനു കേഷം താടെപ്പറയുന്ന ഉപവകുപ്പ്
കെര്‍മ്കകണ്താണ്, അതായത്:—
“(4)

ഈ

വകുപ്പിടേ

മുന്‍പപറഞ്ഞ

വേവസ്ഥകളില്‍

അെങ്ങിയിരുന്നാേും, 2023-ടേ കകരള സഹകരണ സംഘ

എന്തുതടന്ന

(കഭദഗതി)

ആക്റിടെ

പ്പാരംഭത്തികനാ അതിനുകേഷകമാ യാടതാരു അനുബന്ധസ്ഥാപനടത്തയും ഈ വകുപ്പ്
പ്പകാരം കപ്പാത്സാഹിപ്പികാന്‍പ പാെില്ലാത്തതും എന്നാല്‍, 2023-ടേ കകരള സഹകരണ
സംഘ

(കഭദഗതി)

ആക്റിടെ

പ്പാരംഭത്തിനു

ടതാട്ടുമുന്‍പപ്

രജിസ്റ്റര്‍മ്

ടെയ്ത്

പ്പവര്‍മ്ത്തികുന്ന നിേവിേുളള അനുബന്ധസ്ഥാപനങ്ങള്‍ക് മുന്‍പപറഞ്ഞ (1) മുതല്‍ (3)
വടരയുള്ള ഉപവകുപ്പുകളിടേ വേവസ്ഥകള്‍ക്ക് വികധയമായി നിര്‍മ്ണയികടപ്പട്ട പ്പകാരം
അതിടെ പ്പവര്‍മ്ത്തനം തുെകരണ്തുമാണ്.”.
8. 14ബി വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 14ബി വകുപ്പില്‍,—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 36 -->

36

(i) നിേവിടേ (1)-ാം ഉപവകുപ്പിനു കേഷം താടെപ്പറയുന്ന ഉപവകുപ്പുകള്‍ക്
കെര്‍മ്കകണ്താണ്, അതായത്:—
“(1എ) സഹകരണ സംഘങ്ങളുടെ അത്തരം പങ്കാളിത്ത രൂപീകരണത്തിന്
കവണ് വിേദമായ കപ്പാജക്ട് റികപ്പാര്‍മ്ട്ട് ബന്ധടപ്പട്ട സംഘങ്ങള്‍ക് തയ്യാറാകകണ്തും
ആയത്, അംഗീകാരത്തിനായി, അങ്ങടനയുളള സംഘങ്ങളുടെ ടപാതുകയാഗങ്ങളില്‍
സമര്‍മ്പ്പികകണ്തുമാണ്.
(1ബി) സഹകരണ സംഘങ്ങളുടെ അത്തരം പങ്കാളിത്ത രൂപീകരണം
അംഗീകരികുന്നതിനായി, സഹകരണ സംഘത്തിടെ ടപാതുകയാഗങ്ങള്‍ക് അംഗീകരിച്ച
കപ്പാജക്ട് റികപ്പാര്‍മ്ട്ട്

നിര്‍മ്ണയികടപ്പട്ട പ്പകാരം,

രജിസ്പ്ൊര്‍മ്

മുകഖന,

സര്‍മ്കാരിന്

സമര്‍മ്പ്പികകണ്താണ്.
(1സി) രജിസ്പ്ൊര്‍മ്, അങ്ങടനയുള്ള സംഘങ്ങളുടെ ആഡിറ്, കരഖകളുടെ
പരികോധനയും ഒത്തുകനാകേും നിര്‍മ്ണയികടപ്പട്ട പ്പകാരം നെകത്തണ്താണ്.
(1ഡി) അത്തരം പങ്കാളിത്തത്തിന് പണം സമാഹരികുന്ന സംഗതിയില്‍,
സഹകരണ സംഘങ്ങളുടെ പങ്കാളിത്തം, നിര്‍മ്ണയികടപ്പെുന്ന പ്പകാരം സര്‍മ്കാരിടെ
മുന്‍പകൂര്‍മ് അനുമതി കതകെണ്താണ്.”.
9. 15-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 15-ാം വകുപ്പിടെ (3)-ാം
ഉപവകുപ്പിന് കേഷം താടെപ്പറയുന്ന ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്, അതായത്:—
“(4) 14-ാം വകുപ്പിടേ വേവസ്ഥകള്‍ക്കനുസൃതമായി ഒകന്നാ അതിേധികകമാ
സംഘങ്ങള്‍ക്
ഓകരാ

മടറാരു

സംഘവുമായി

സംഘത്തിടെയും

േയികുകമ്പാള്‍ക്

രജിസ്കപ്െഷന്‍പ

േയനത്തില്‍

റോകുന്നതും

അത്

ഏര്‍മ്ടപ്പട്ട

പിരിച്ചുവിട്ടതായി

കരുതടപ്പകെണ്തും ഒരു കകാര്‍മ്പ്പകററ് നികായം അല്ലാതായി തീരുന്നതുമാണ്.”.
10.
(1)-ാം

16-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 16-ാം വകുപ്പില്‍, നിേവിടേ
ഉപവകുപ്പിടെ

ക്ലിപ്തനിബന്ധനയ്കു

(എ)
കേഷം,

ഖണ്ഡത്തിടേ
താടെപ്പറയുന്ന

(i)

ഇനത്തിടെ

ഇനവും

നിേവിേുള്ള

ക്ലിപ്തനിബന്ധനയും

കെര്‍മ്കകണ്താണ്, അതായത്:—
“(iഎ) യുവജന സഹകരണ സംഘങ്ങളുടെ സംഗതിയില്‍, നാല്പത്തിയഞ്ച്
വയസ്സ് പൂര്‍മ്ത്തിയാകാത്ത വേക്തി:

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 37 -->

37

എന്നാല്‍,

നാല്പത്തിയഞ്ച്

വയസ്സ്

പൂര്‍മ്ത്തിയാകുകമ്പാള്‍ക്

അങ്ങടനയുള്ള

അംഗങ്ങളുടെ അംഗതവം നിേവിേില്ലാതാകുന്നതും അവര്‍മ് സംഘത്തിടെ അകസാസികയറ്
അംഗം ആകുന്നതുമാണ്.”.
11. 18-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 18-ാം വകുപ്പിടെ (3)-ാം
ഉപവകുപ്പ് താടെപ്പറയും പ്പകാരം കെര്‍മ്കകണ്താണ്, അതായത്:—
“(3) ഈ വകുപ്പില്‍ വേവസ്ഥ ടെയ്തിട്ടുളളടതാെിടക, ഒരു നാമമാപ്ത അടല്ലങ്കില്‍
അകസാസികയറ് അംഗത്തിടെ അങ്ങടനയുള്ള വികേഷാവകാേങ്ങളും, അവകാേങ്ങളും
ഉണ്ായിരികുന്നതും സംഘങ്ങള്‍ക് നല്‍കുന്ന വായ്പാ സൗകരേങ്ങളും ഉള്‍ക്പ്പടെയുള്ള
വിവിധ

കസവനങ്ങള്‍ക്ക്

ഉപനിയമങ്ങളില്‍

അര്‍മ്ഹതയുണ്ായിരികുന്നതും

വിനിര്‍മ്കേേികുന്ന

പ്പകാരം

പ്പസ്തുത

ഒരംഗത്തിടെ

സംഘത്തിടെ
അങ്ങടനയുള്ള

ബാദ്ധേതകള്‍ക്ക് വികധയനായിരികുന്നതുമാണ്.”.
12. 19-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 19-ാം വകുപ്പില്‍,—
(i) നിേവിേുളള വകുപ്പിടന (1)-ാം ഉപവകുപ്പായി അകമികെണ്താണ്;
(ii) അപ്പകാരം

അകമിട്ട

(1)-ാം

ഉപവകുപ്പിനു

കേഷം

താടെപ്പറയുന്ന

ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്, അതായത്:—
“(2) ഒരു

സംഘത്തിടെ ടപാതുകയാഗം

ഓഹരി മൂേേം

ഉയര്‍മ്ത്താന്‍പ

തീരുമാനിച്ചാല്‍, ഒരു അംഗത്തിന് അംഗതവത്തില്‍ തുെരാനുള്ള അവകാേം ഓഹരി മൂേേം
ഉയര്‍മ്ത്തിയ തീയതി മുതല്‍ അഞ്ച് വര്‍മ്ഷ കാേയളവികേയ്ക് ഉണ്ായിരികുന്നതും
എന്നാല്‍, മകവേമുള്ള ഓഹരികളുടെ ഉയര്‍മ്ത്തിയ മൂേേം ഒെുകുന്ന മുറയ്ക് മാപ്തം ഒരു
അംഗടമന്ന

നിേയിേുള്ള

അയാളുടെ

അവകാേങ്ങള്‍ക്

വിനികയാഗികാന്‍പ

അനുവദികകണ്തുമാണ്.”.
13. 19ബി വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 19ബി വകുപ്പില്‍,—
(i) (ഇ) ഖണ്ഡത്തില്‍ “ആെ്” എന്ന വാക് ഒെിവാകകണ്താണ്.
(ii) (എഫ്റ്) ഖണ്ഡത്തില്‍, “.” എന്ന െിഹ്നത്തിനു പകരം “; കൂൊടത” എന്ന
െിഹ്നവും വാകും കെര്‍മ്കകണ്താണ്.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 38 -->

38

(iii) (എഫ്റ്) ഖണ്ഡത്തിനു കേഷം, താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(ജി) പ്പസ്തുത സംഘത്തിടെ കമിറിയും ടപാതുകയാഗവും അംഗീകരിച്ച
തിരുത്തല്‍ റികപ്പാര്‍മ്ട്ടികനാടൊപ്പം ഏറവും പുതിയ സ്റ്റാറേൂട്ടറി ആഡിറ് റികപ്പാര്‍മ്ട്ടില്‍ ഉള്‍ക്ടപ്പട്ട
കപാരായ്മകളുടെ സംപ്ഗഹവും;”.
14. 20-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 20-ാം വകുപ്പില്‍, (ഡി)
ഖണ്ഡത്തില്‍

“ടതരടഞ്ഞെുകുന്നതില്‍”

“ടതരടഞ്ഞെുകുന്നതിേും

നീകം

എന്ന

വാകിനു

ടെയ്യുന്നതിേും”

എന്നീ

പകരം
വാകുകള്‍ക്

കെര്‍മ്കകണ്താണ്.
15. 22-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 22-ാം വകുപ്പിടെ (1)-ാം
ഉപവകുപ്പില്‍,

നിേവിടേ

ക്ലിപ്തനിബന്ധനയ്കു

കേഷം

താടെപ്പറയുന്ന

ക്ലിപ്തനിബന്ധന കെര്‍മ്കകണ്താണ്, അതായത്:—
“എന്നുമാപ്തമല്ല, റിസര്‍മ്വ് ബാങ്ക് ഓഫ്റ് ഇന്തേയുടെ മേസന്‍പസുളള ഒരു
അര്‍മ്ബന്‍പ സഹകരണ ബാങ്കില്‍, ഒരു വേക്തിഗത അംഗത്തിന് മകവേം വയ്കാവുന്ന
പരമാവധി ഓഹരി മൂേധന തുക, ബാങ്കിടെ ആടക അെച്ചുതീര്‍മ്ത്ത ഓഹരി മൂേധന
മൂേേത്തിടെ അഞ്ച് േതമാനമായി നിജടപ്പെുത്തിയിട്ടുള്ളതാണ്.”.
16. 26-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 26-ാം വകുപ്പില്‍, (1)-ാം
ഉപവകുപ്പിടെ (ബി) ഖണ്ഡത്തില്‍, “രണ്ു” എന്ന വാകിന് പകരം “മൂന്ന്” എന്ന വാക്
കെര്‍മ്കകണ്താണ്.
17. 28-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 28-ാം വകുപ്പില്‍,—
(i) (1)-ാം ഉപവകുപ്പിടെ മൂന്നാം ക്ലിപ്തനിബന്ധനയില്‍,—
(എ) “സംഘങ്ങളിടേ കമിറികളികേയ്കുളള” എന്നീ വാകുകള്‍ക്ക് പകരം
“എല്ലാ

പ്പാഥമിക

കാര്‍മ്ഷിക

വായ്പാ

സംഘങ്ങളിടേയും

എല്ലാ

പ്പാഥമിക

സംഘങ്ങളിടേയും കമിറികളികേയ്കുളള” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്;
(ബി) “ഏടതങ്കിേും സംഘത്തിടെ” എന്നീ വാകുകള്‍ക്ക് പകരം “അത്തരം
സംഘത്തിടെ” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 39 -->

39

(ii) (1എ) ഉപവകുപ്പിടെ ക്ലിപ്തനിബന്ധനകള്‍ക് ഒെിവാകകണ്താണ്.
(iii)

(1സി)

“പതിനായിരവും”

ഉപവകുപ്പില്‍,

എന്ന

വാകിന്

പകരം

“ഇരുപത്തയ്യായിരവും” എന്ന വാക് കെര്‍മ്കകണ്താണ്.
(iv) (1സി) ഉപവകുപ്പിന് കേഷം താടെപ്പറയുന്ന ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(1സിഎ) ആക്റികോ െട്ടങ്ങളികോ സംഘത്തിടെ ഉപനിയമങ്ങളികോ
എന്തുതടന്ന അെങ്ങിയിരുന്നാേും, ഓകരാ സംഘത്തിടെയും കമിറികളിടേ രണ്ു
സീറുകള്‍ക് ടതരടഞ്ഞെുപ്പിന് നാമനിര്‍മ്കേേം ഫ്റയല്‍ ടെയ്യുന്ന തീയതിയില്‍ നാല്പത് വയസ്സ്
അധികരികാത്ത അംഗങ്ങള്‍ക്കായി സംവരണം ടെകയ്യണ്തും അതില്‍ ഒടരണം
സംവരകണതര വിഭാഗത്തില്‍ നിന്നും മടറാന്ന് 28എ വകുപ്പിടെ (1)-ാം ഉപവകുപ്പില്‍
വേവസ്ഥ

ടെയ്തിട്ടുള്ള

വനിതാ

സംവരണ

വിഭാഗത്തില്‍

നിന്നും

ആയിരികകണ്തുമാണ്.”.
(v) (1ഇ) ഉപവകുപ്പിടേ (iii)-ാം ഇനത്തിനു പകരം താടെപ്പറയുന്ന ഇനം
കെര്‍മ്കകണ്താണ്, അതായത്:—
“(iii) അത്തരം വിഭജനം രജിസ്പ്ൊര്‍മ് വിഭജന ഉത്തരവ് പുറടപ്പെുവിച്ച തീയതി
മുതല്‍ ഒരു വര്‍മ്ഷത്തിനകം പൂര്‍മ്ത്തിയാകകണ്താണ്.”.
(vi)

(1ജി)

ഉപവകുപ്പിന്

പകരം

താടെപ്പറയുന്നവ

കെര്‍മ്കകണ്താണ്,

അതായത്:—
“(1ജി)

ഒരു

സംഘത്തിടെ

ഉപനിയമങ്ങളില്‍

എന്തുതടന്ന

അെങ്ങിയിരുന്നാേും, അധികാരത്തിേുള്ള കമിറി, ഒരു വാണിജേ ബാങ്കികോ കകരള
സംസ്ഥാന സഹകരണ ബാങ്കികോ ഒരു അര്‍മ്ബന്‍പ സഹകരണ ബാങ്കികോ കകരള
സംസ്ഥാന കാര്‍മ്ഷിക പ്ഗാമീണ വികസന ബാങ്കികോ ഒരു പ്പാഥമിക സഹകരണ കാര്‍മ്ഷിക
പ്ഗാമീണവികസന ബാങ്കികോ മുന്‍പ ജില്ലാ സഹകരണ ബാങ്കികോ ടപയ്ഡ് സര്‍മ്വീസില്‍
ഉളളകതാ ഉണ്ായിരുന്നകതാ അടല്ലങ്കില്‍ ഒരു സര്‍മ്വീസ് സഹകരണ ബാങ്കില്‍ മാകനജര്‍മ്
കകഡറികോ അടല്ലങ്കില്‍ സഹകരണം/സഹകരണ മാകനജ്ടമെ്, മാകനജ്ടമെ്, കൃഷി,
സാമ്പത്തിക ോസ്പ്തം, വാണിജേം, പബ്ലിക് ഫ്റിനാന്‍പസ്, നിയമം, പ്ഗാമവികസനം,
വിവരസാകങ്കതികവിദേ എന്നിവയില്‍ മവദഗ്ദ്്ധേമുള്ള രണ്് വേക്തികള്‍ക് അടല്ലങ്കില്‍
പ്പതിനിധികടള സംഘത്തിടെ കമിറിയില്‍ അംഗങ്ങളായി കകാ-ഓപ്റ് ടെകയ്യണ്താണ്:

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 40 -->

40

എന്നാല്‍, അപ്പകാരം കകാ-ഓപ്റ് ടെയ്യടപ്പട്ട അംഗങ്ങളുടെ എണം (1എ)
ഉപവകുപ്പില്‍

വിനിര്‍മ്കേേിച്ചിട്ടുളള

പരമാവധി

പരിധിയ്ക്

പുറടമ

രണ്ില്‍

അധികരികാന്‍പ പാെുളളതല്ല:
എന്നുമാപ്തമല്ല,

അപ്പകാരം

കകാ-ഓപ്റ്

ടെയ്യടപ്പട്ട

അംഗങ്ങള്‍ക്ക്,

സഹകരണ സംഘത്തിടേ ഏടതാരു ടതരടഞ്ഞെുപ്പിേും അങ്ങടനയുളള അംഗങ്ങടളന്ന
നിേയില്‍ കവാട്ടവകാേം ഉണ്ായിരികുന്നതല്ലാത്തതും

കബാര്‍മ്ഡിടെ ഔകദോഗിക

ഭാരവാഹിയായി ടതരടഞ്ഞെുകടപ്പൊന്‍പ അര്‍മ്ഹതയുണ്ായിരികുന്നതുമല്ല:
എന്നിരുന്നാേും, ഒരു സഹകരണ സംഘത്തിടേ അപ്പകാരം കകാ-ഓപ്റ്
ടെയ്യടപ്പട്ട

അംഗങ്ങള്‍ക്

കബാര്‍മ്ഡിടേ

അംഗങ്ങള്‍ക്

കൂെിയായിരികുന്നതും

(1എ)

ഉപവകുപ്പില്‍ വിനിര്‍മ്കേേിച്ചിട്ടുളള ആടക ഡയറക്ടര്‍മ്മാരുടെ എണം കണകാകുന്ന
ആവേേത്തികേക് അങ്ങടനയുളള അംഗങ്ങടള ഒെിവാകകണ്തുമാണ്:
കൂൊടത, കമിറി രൂപീകരിച്ച തീയതി മുതല്‍ ആറ് മാസകാേയളവിനുളളില്‍,
നിര്‍മ്കേേിച്ച പ്പകാരം ആളുകടള കകാ-ഓപ്റ് ടെയ്യാത്തപക്ഷം സര്‍മ്കാകരാ രജിസ്പ്ൊകറാ,
അതതു സംഗതികപാടേ, നിര്‍മ്ണയികടപ്പട്ട പ്പകാരം മതിയായ കനാട്ടീസ് നല്‍കിടകാണ്്
പ്പസ്തുത

ഉപവകുപ്പില്‍

വേക്തമാകിയിട്ടുളള

പ്പകാരം

അത്തരം

നാമനിര്‍മ്കേേം

ടെകയ്യണ്താണ്.”.
(vii) (2)-ാം ഉപവകുപ്പിനു കേഷം, താടെപ്പറയുന്നവ (2എ) ഉപവകുപ്പായി
കെര്‍മ്കകണ്താണ്, അതായത്:—
“(2എ)

ആക്റികോ

െട്ടങ്ങളികോ

ഒരു

വായ്പാസംഘത്തിടെ

ഉപനിയമങ്ങളികോ വിരുദ്ധമായി എന്തുതടന്ന അെങ്ങിയിരുന്നാേും ഒരു സംഘത്തിടെ
കമിറിയിടേ യാടതാരു അംഗത്തിനും, കാോവധി പൂര്‍മ്ണമാകണാ ഭാഗികമാകണാ
എന്നുളളത് പരിഗണികാടത, തുെര്‍മ്ച്ചയായ മൂന്നിേധികം തവണ കമിറിയികേയ്ക്
ടതരടഞ്ഞെുകടപ്പൊന്‍പ അര്‍മ്ഹതയുണ്ായിരികുന്നതല്ല.
വിേദീകരണം.—ഈ ഉപവകുപ്പിടെ ആവേേത്തികേയ്കായി, വായ്പാ സംഘം
എന്നാല്‍ കകരള സംസ്ഥാന സഹകരണ ബാങ്ക് േിമിറഡ്, പ്പാഥമിക കാര്‍മ്ഷിക വായ്പാ
സംഘങ്ങള്‍ക്, സര്‍മ്വീസ് സഹകരണ ബാങ്കുകള്‍ക്, പ്പാകദേിക സഹകരണ ബാങ്കുകള്‍ക്,
പ്ഗാമീണ ബാങ്കുകള്‍ക്, കര്‍മ്ഷക സര്‍മ്വീസ് സഹകരണ ബാങ്കുകള്‍ക്, അര്‍മ്ബന്‍പ സഹകരണ
ബാങ്കുകള്‍ക്, കകരള സംസ്ഥാന സഹകരണ കാര്‍മ്ഷിക-പ്ഗാമീണ വികസന ബാങ്ക് േിമിറഡ്,

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 41 -->

41

പ്പാഥമിക സഹകരണ കാര്‍മ്ഷിക-പ്ഗാമീണ വികസന ബാങ്ക്, അര്‍മ്ബന്‍പ സഹകരണ
സംഘങ്ങള്‍ക്,

അപ്ഗികള്‍ക്ച്ചറല്‍

ഇംപ്പൂവ്ടമെ്

കകാ-ഓപ്പകററീവ്

ടസാമസറികള്‍ക്,

എംകപ്ലായീസ് വായ്പാ സംഘങ്ങള്‍ക്, പ്ഗാമീണ സഹകരണ സംഘങ്ങള്‍ക്, പ്പാഥമിക
ഹൗസിംഗ് സഹകരണ സംഘങ്ങള്‍ക്, കകരള സംസ്ഥാന ഹൗസിംഗ് ടഫ്റഡകറഷന്‍പ എന്ന്
അര്‍മ്ഥമാകുന്നു.”.
(viii)

(3)-ാം

ഉപവകുപ്പിടെ

ക്ലിപ്തനിബന്ധനയില്‍

“ഒന്നില്‍കൂെുതല്‍

സംഘത്തിടെ” എന്നീ വാകുകള്‍ക്ക് പകരം “ഒന്നില്‍ കൂെുതല്‍ സംഘത്തിടെകയാ
വേതേസ്തങ്ങളായ

രണ്ില്‍

കൂെുതല്‍

സംഘത്തിടെകയാ”

എന്നീ

വാകുകള്‍ക്

കെര്‍മ്കകണ്താണ്.
18. 28എബി വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 28എബി വകുപ്പിടെ
(2)-ാം

ഉപവകുപ്പില്‍,

“കമിറിയിടേ

മകറടതങ്കിേും

ഉകദോഗസ്ഥടനകയാ”

എന്നീ

വാകുകള്‍ക്കു കേഷം “അടല്ലങ്കില്‍ കമിറിയാല്‍ നിയമികടപ്പട്ട സംഘത്തിടെ ഒരു
പ്പതിനിധികയകയാ” എന്നീ വാകുകള്‍ക് കൂട്ടികച്ചര്‍മ്കകണ്താണ്.
19. 28ബി വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 28ബി വകുപ്പില്‍,—
(i) (1)-ാം ഉപവകുപ്പില്‍, “സഹകരണസംഘങ്ങളികേക്” എന്ന വാകിന് പകരം
“സഹകരണ സംഘങ്ങളികേകും സംസ്ഥാന സഹകരണ യൂണിയനികേയ്കും സര്‍മ്കിള്‍ക്
സഹകരണ യൂണിയനുകളികേയ്കും” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
(ii)

28ബി

വകുപ്പിടെ

(2)-ാം

ഉപവകുപ്പില്‍,

“സര്‍മ്കാരിടെ

സ്ടപഷേല്‍

ടസപ്കട്ടറിയുടെ” എന്നീ വാകുകള്‍ക്ക് പകരം “സര്‍മ്കാര്‍മ് നിയമ വകുപ്പ് സ്ടപഷേല്‍
ടസപ്കട്ടറിയുടെ” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
20. 29-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 29-ാം വകുപ്പില്‍,—
(i) (1)-ാം ഉപവകുപ്പില്‍,—
(എ) (സിസി) ഖണ്ഡത്തില്‍, “കണകുകളുടെയും” എന്ന വാകിനു പകരം
“ആഡിറ് ടെയ്ത കണകുകളുടെയും” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്;
(ബി)

(സിഇ)

ഖണ്ഡത്തിന്

കെര്‍മ്കകണ്താണ്, അതായത്:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

പകരം

താടെപ്പറയുന്ന

ഖണ്ഡം

<!-- page 42 -->

42

“(സിഇ) മുന്‍പ സാമ്പത്തിക വര്‍മ്ഷം സംഘത്തിടേ കമിറി അംഗങ്ങളുടെയും
ജീവനകാരുടെയും

അവരുടെ

കുെുംബാംഗങ്ങളുടെയും

സംഘത്തികേയ്ക്

കുെിശ്ശികയായ എല്ലാ ബാധേതകടളയും സംബന്ധിച്ച വിേദമായ േിസ്റ്റിടെ പരിഗണന.
വിേദീകരണം.—ഈ ഖണ്ഡത്തിടെ ആവേേത്തികേയ്കായി “കുെുംബാംഗങ്ങള്‍ക്”
എന്നാല്‍ ഭര്‍മ്ത്താവ്, ഭാരേ, ദത്ത് കുട്ടികള്‍ക് ഉള്‍ക്ടപ്പടെയുളള അവരുടെ കുട്ടികളും
മാതാപിതാകളും;”.
(ii)

(2)-ാം

ഉപവകുപ്പ് താടെപ്പറയും

പ്പകാരം

പകരം

കെര്‍മ്കകണ്താണ്,

അതായത്:—
“(2)
സഹകരണ

രജിസ്പ്ൊര്‍മ്കകാ

ആഡിറ്

അകേഹം

ഡയറക്ടര്‍മ്കകാ

നികയാഗികുന്ന

മടറാരാള്‍ക്കകാ

നികയാഗികുന്ന

മടറാരാള്‍ക്കകാ

അകേഹം

ഏടതാരു സംഘത്തിടെയും കമിറിയികോ ടപാതുകയാഗ മീറിംഗികോ ഹാജരാകുവാന്‍പ
അവകാേമുണ്ായിരികുന്നതാണ്.”.
21. 31-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 31-ാം വകുപ്പിടെ (3)-ാം
ഉപവകുപ്പില്‍,

“െര്‍മ്ച്ചയില്‍

“ഭാരവാഹികളുടെ

പടങ്കെുകാകനാ”

ടതരടഞ്ഞെുപ്പിനുളള

എന്നീ

കവാടട്ടെുപ്പില്‍

വാകുകള്‍ക്ക്

കേഷം

പടങ്കെുകാകനാ”

എന്നീ

വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
22. 32-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 32-ാം വകുപ്പില്‍,—
(i) (1)-ാം ഉപവകുപ്പില്‍,—
(എ) (ബി) ഖണ്ഡത്തിനു കേഷം താടെപ്പറയുന്ന ഖണ്ഡം (ബിഎ) ഖണ്ഡം
ആയി കെര്‍മ്കകണ്താണ്, അതായത്:—
“(ബിഎ) ആക്റിടെ 76-ാം വകുപ്പില്‍ പരാമര്‍മ്േികുന്ന ഉത്തരവുകള്‍ക്
മുതോയവ നെപ്പിോകുന്നതിനുള്ള കബാധപൂര്‍മ്വമായ വീെ്െകയാ; അടല്ലങ്കില്‍”;
(ബി) (ഡി) ഖണ്ഡത്തില്‍, “അവരില്‍ ഒരാടള കൺവീനറായും, അവര്‍മ്
സംഘത്തിടേ അംഗമായിരികണടമന്നില്ല” എന്നീ വാകുകള്‍ക്കും െിഹ്നത്തിനും പകരം
“, അവര്‍മ് സംഘത്തിടേ അംഗങ്ങളായിരികകണ്തും, അവരില്‍ ഒരാടള കൺവീനറായും”
എന്നീ

വാകുകളും

െിഹ്നവും

കെര്‍മ്കകണ്തും

മൂന്നാം

ക്ലിപ്തനിബന്ധനയും

വിേദീകരണം I-ഉം ഒെിവാകകണ്തും വിേദീകരണം II-ടേ “II” നീകം ടെകയ്യണ്തുമാണ്;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 43 -->

43

(സി) (ഇ) ഖണ്ഡത്തില്‍, “രണ്് തുെര്‍മ്ച്ചയായ കാോവധികളികേയ്ക്” എന്നീ
വാകുകള്‍ക്ക്

പകരം

“അെുത്ത

ഒരു

കാോവധിയികേയ്ക്”

എന്നീ

വാകുകള്‍ക്

കെര്‍മ്കകണ്താണ്.
(ii) (4)-ാം ഉപവകുപ്പില്‍,—
“സംഘത്തിടെ താത്പരോര്‍മ്ഥം ആവേേമായി വരാവുന്ന പ്പകാരമുള്ള
എല്ലാ

നെപെികളും

എെുകുന്നതിനും

അധികാരമുണ്ായിരികുന്നതാണ്.”

എന്നീ

വാകുകള്‍ക്കും െിഹ്നത്തിനും പകരം “അംഗങ്ങളുടെ എന്‍പകറാള്‍ക്ടമെ് ഉള്‍ക്ടപ്പടെ,
സംഘത്തിടെ

താത്പരോര്‍മ്ഥം

ആവേേമായി

വരാവുന്ന

എല്ലാ

നെപെികളും

എെുകുന്നതിന് അധികാരം ഉണ്ായിരികുന്നതും, എന്നാല്‍ ടതരടഞ്ഞെുകടപ്പട്ട ഒരു
കമിറി പ്പസ്തുത അംഗതവം സാധൂകരികാത്തിെകത്താളം അങ്ങടനയുള്ള അംഗങ്ങള്‍ക്
കവാട്ടവകാേം

വിനികയാഗികുവാന്‍പ

പാെില്ലാത്തതുമാണ്.”

എന്നീ

വാകുകളും

െിഹ്നങ്ങളും കെര്‍മ്കകണ്തുമാണ്.
23. 33-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 33-ാം വകുപ്പില്‍,—
(i) (1)-ാം ഉപവകുപ്പിടേ (ബി) ഖണ്ഡത്തില്‍, “അവര്‍മ് സംഘത്തിടേ അംഗങ്ങള്‍ക്
ആയിരികണടമന്നില്ല”
അംഗങ്ങളില്‍

എന്നീ

വാകുകള്‍ക്ക്

നിന്നുമായിരികണം;

പകരം

അവരില്‍

“അവര്‍മ്

ഒരാള്‍ക്”

സംഘത്തിടേ

എന്നീ

വാകുകള്‍ക്

കെര്‍മ്കകണ്താണ്.
(ii) (2)-ാം ഉപവകുപ്പില്‍,—
(എ) “ഏടതങ്കിേും ഉകദോഗസ്ഥടെകയാ” എന്നീ വാകുകള്‍ക്കു കേഷം
“അംഗങ്ങളുടെ എന്‍പകറാള്‍ക്ടമെ് ഉള്‍ക്ടപ്പടെ” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്;
(ബി) താടെപ്പറയുന്ന വാെകം അവസാന ഭാഗത്തായി കെര്‍മ്കകണ്താണ്,
അതായത്:—
“ടതരടഞ്ഞെുകടപ്പെുന്ന

ഒരു

കമിറി

അപ്പകാരമുളള

അംഗതവം

സാധൂകരികാത്ത പക്ഷം അപ്പകാരം കെര്‍മ്കടപ്പട്ട അംഗങ്ങള്‍ക്ക് കവാട്ടവകാേം
ഇല്ലാത്തതും കമിറി അത്തരം അംഗതവത്തിന് സാധൂകരണം നല്‍കുന്നില്ലാടയങ്കില്‍
അപ്പകാരം നിരസികുന്നതിനുള്ള കാരണങ്ങള്‍ക് വേക്തമാകകണ്തുമാണ്.”.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 44 -->

44

24. 34എ എന്ന പുതിയ വകുപ്പ് കെര്‍മ്കല്‍.—പ്പധാന ആക്റിടേ 34-ാം വകുപ്പിനു
കേഷം താടെപ്പറയുന്ന വകുപ്പ് കെര്‍മ്കകണ്താണ്, അതായത്:—
“34എ. കണകുകളുടെ സൂക്ഷിപ്പും ടപാതു കസാഫ്റ്ടറവയര്‍മ് സവീകരികേും.—(1)
എല്ലാ

സഹകരണ സംഘങ്ങളും

ബാേന്‍പസ്

ഷീറും

നിര്‍മ്ണയികടപ്പട്ട പ്പകാരം ോഭനഷ്ട

തയ്യാറാകുന്നതിന്

ടപാതുവായി

കണകും,

അംഗീകരികടപ്പട്ടിട്ടുള്ള

അകൗണ്ിംഗ് തതവത്തില്‍ നിര്‍മ്കേേിച്ചിരികുന്ന ഫ്റാറത്തില്‍ ഡബിള്‍ക് എന്‍പപ്െി ബുക്
കീപ്പിംഗ് സിസ്റ്റം സാധേമാകുന്ന തരത്തില്‍ അകൗണ്് ബുകുകളും സാമ്പത്തിക
കസ്റ്ററ്ടമെുകളും തയ്യാറാകി സൂക്ഷികകണ്താണ്.
(2) എല്ലാ സഹകരണ സംഘങ്ങളികേയ്കുമുള്ള നിര്‍മ്ണയികടപ്പട്ട ടപാതു
കസാഫ്റ്റടവയറിടെ
്
സ്ഥാപനവും സൂക്ഷിപ്പും ഉപകയാഗവും സംബന്ധിച്ച് ആവേേമായ
മാര്‍മ്ഗനിര്‍മ്കേേങ്ങള്‍ക്, രജിസ്പ്ൊര്‍മ്, നിര്‍മ്ണയികടപ്പട്ട പ്പകാരം പുറടപ്പെുവികകണ്താണ്.
(3) കസാഫ്റ്റടവയറും
്
ഹാര്‍മ്ഡ്ടവയറുമായി ബന്ധടപ്പട്ട സുരക്ഷ, വിേവാസേത,
ഡാറാ സംരക്ഷണവും, മറു സംഗതികളും പരികോധികുന്നതിനായി, സര്‍മ്കാരുമായി
കൂെിയാകോെിച്ച് നിര്‍മ്ണയികടപ്പട്ട പ്പകാരം ടപ്പാഫ്റഷണല്‍ ടെക്നികല്‍ െീം ഉള്‍ക്ടപ്പട്ട
ഒരു ടെക്നികല്‍ ടസല്‍ രജിസ്പ്ൊറുടെ കാരോേയത്തില്‍ സ്ഥാപികകണ്താണ്.”.
25. 36എ വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 36എ വകുപ്പില്‍, “10 മുതല്‍ 15
വടരയുള്ള വകുപ്പുകളിടേ (രണ്ും ഉള്‍ക്ടപ്പടെ)” എന്നീ അകങ്ങള്‍ക്കും വാകുകള്‍ക്കും
െിഹ്നങ്ങള്‍ക്കും പകരം “9 മുതല്‍ 15 വടരയും (രണ്ും ഉള്‍ക്ടപ്പടെ) 19 മുതല്‍ 28
വടരയുമുള്ള (രണ്ും ഉള്‍ക്ടപ്പടെ) വകുപ്പുകളിടേ” എന്നീ അകങ്ങളും വാകുകളും
െിഹ്നങ്ങളും കെര്‍മ്കകണ്താണ്.
26. 56-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 56-ാം വകുപ്പില്‍,—
(i) (1)-ാം ഉപവകുപ്പിടേ (സി) ഖണ്ഡത്തിനു കേഷം താടെപ്പറയുന്ന ഖണ്ഡം
കെര്‍മ്കകണ്താണ്, അതായത്:—
“(ഡി) അറാദായത്തിടെ അഞ്ച് േതമാനം രജിസ്പ്ൊര്‍മ് സൂക്ഷിച്ചുകപാരുന്ന
ടപ്പാഫ്റഷണല്‍ എഡേൂകകഷന്‍പ ഫ്റണ്ികേയ്ക് വകയിരുകത്തണ്താണ്.”.
(ii) (2)-ാം ഉപവകുപ്പിടേ (സിസി) ഖണ്ഡം വിട്ടുകളകയണ്താണ്.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 45 -->

45

27. 56എ വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 56എ വകുപ്പിന് താടെപ്പറയുന്ന
ക്ലിപ്തനിബന്ധന കെര്‍മ്കകണ്താണ്, അതായത്:—
“എന്നാല്‍,

സംഘങ്ങളുടെ

ഉകേേേേക്ഷേങ്ങളുമായി

ബന്ധടപ്പട്ട

പ്പവര്‍മ്ത്തനങ്ങള്‍ക്ക് സ്ഥാവര വസ്തുകള്‍ക് ഉപകയാഗികകണ്തുടണ്ങ്കില്‍ ഇതിനായി
സംഘം ടപാതുകയാഗത്തിടെ പ്പകമയത്തിടെ അെിസ്ഥാനത്തില്‍ രജിസ്പ്ൊറില്‍ നിന്ന്
മുന്‍പകൂര്‍മ് അംഗീകാരം കതകെണ്താണ്.”.
28. 57സി വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 57സി വകുപ്പിടേ (1)-ാം
ഉപവകുപ്പില്‍, “സംഘങ്ങളുടെയും തകേേ സവയംഭരണസ്ഥാപനങ്ങളുടെയും വികസന
അകതാറിറികളുടെയും
സൗകരേത്തിനായി”

അതുകപാേുളള

എന്നീ

വാകുകള്‍ക്ക്

സംഘങ്ങളുടെയും

തകേേ

അകതാറിറികളുടെയും

അതുകപാേുളള

സ്ഥാപനങ്ങളുടെയും
പകരം

“ടപാതു

അെിസ്ഥാന

ആവേേങ്ങള്‍ക്കായും

സവയംഭരണസ്ഥാപനങ്ങളുടെയും
സ്ഥാപനങ്ങളുടെയും

വികസന

അെിസ്ഥാന

സൗകരേ

വികസനത്തിനായും” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
29. 57ഇ എന്ന പുതിയ വകുപ്പ് കെര്‍മ്കല്‍.—പ്പധാന ആക്റിടേ 57ഡി വകുപ്പിനു
കേഷം താടെപ്പറയുന്ന വകുപ്പ് കെര്‍മ്കകണ്താണ്, അതായത്:—
“57ഇ. സഹകരണ പുനരുദ്ധാരണ ഫ്റണ്് പദ്ധതി.—(1) സര്‍മ്കാരിന്, ഗസറ്
വിജ്ഞാപനം

വെി

അസാധാരണ

സാഹെരേം

നിമിത്തം

ദുര്‍മ്ബേമായകതാ

സുഷുപ്താവസ്ഥയികോ ആയ സംഘങ്ങടള പുനരുദ്ധരിപ്പികുന്നതിനായി സാമ്പത്തിക
സഹായം

നല്‍കുന്നതിനായി

പദ്ധതിയില്‍

അത്തരം

നിബന്ധനകള്‍ക്കും

വിനിര്‍മ്കേേികാവുന്ന

വേവസ്ഥകള്‍ക്കും

വികധയമായി

അങ്ങടനയുളള
“സഹകരണ

പുനരുദ്ധാരണ ഫ്റണ്് സ്കീം” എന്ന കപരില്‍ ഒരു പദ്ധതി രൂപീകരികാവുന്നതും
നിര്‍മ്ണയികടപ്പട്ട പ്പകാരം അതിടെ ഭരണം നെകത്തണ്തുമാണ്.
(2) ഫ്റണ്ികേക്,—
(എ)

56-ാം

വകുപ്പ്

(1)-ാം

ഉപവകുപ്പിടേ

(എ)

ഖണ്ഡത്തില്‍

പരാമര്‍മ്േികുന്ന കരുതല്‍ ഫ്റണ്ിടെ അമ്പത് േതമാനത്തില്‍ കവിയാത്ത ഒരു തുകയും;
(ബി) കാര്‍മ്ഷിക വായ്പാ സംഘങ്ങള്‍ക് തങ്ങളുടെ അറാദായത്തില്‍ നിന്ന്,
വകമാറിയ

അപ്ഗികള്‍ക്ച്ചര്‍മ്

ടപ്കഡിറ്

ടസ്റ്റബിമേകസഷന്‍പ

േതമാനത്തില്‍ കവിയാത്തത്; ആവേേമായി വരുകമ്പാള്‍ക്;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

ഫ്റണ്ിടെ

അമ്പത്

<!-- page 46 -->

46

(സി)

സര്‍മ്കാര്‍മ്

കാോകാേങ്ങളില്‍

അനുവദികച്ചകാവുന്ന

അങ്ങടനയുളള ഫ്റണ്്; കൂൊടത
(ഡി)

പദ്ധതിയിടേ

വേവസ്ഥകള്‍ക്

പ്പകാരം

ഫ്റണ്ികേക്

ടപ്കഡിറ്

ടെയ്യാവുന്ന മകറടതാരു തുകയും,
നീകിവയ്കകണ്താണ്.”.
30. 59-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 59-ാം വകുപ്പില്‍ നിേവിേുളള
(2)-ാം ഉപവകുപ്പിനു കേഷം താടെപ്പറയുന്ന ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്, അതായത്:—
“(2എ) ഒരു സംഘം, രജിസ്പ്ൊര്‍മ് നിശ്ചയിച്ചിട്ടുളളതും പ്പസ്തുത സംഘത്തിടെ
ഉപനിയമങ്ങളില്‍ വേവസ്ഥ ടെയ്തിട്ടുള്ളതുമായ വേക്തിഗത പരമാവധി കെടമെുകല്‍
അധികാര പരിധിയില്‍ കവിഞ്ഞ യാടതാരു തുകയും അഡവാന്‍പസാകയാ വായ്പയാകയാ
അനുവദികാന്‍പ
േംഘനത്തിനും
കമിറിയും

പാെില്ലാത്തതാകുന്നു.
ബന്ധടപ്പട്ട

ആക്റിടേ

സഹകരണ

94-ാം

വകുപ്പിടേ

പ്പസ്തുത

വേവസ്ഥയുടെ

സംഘത്തിടെ
(7എ)

ഏടതാരു

െീഫ്റ്

എക്സികേൂട്ടീവും

ഉപവകുപ്പില്‍

പ്പതിപാദിച്ചിട്ടുളള

േിക്ഷയ്ക് അര്‍മ്ഹരായിരികുന്നതുമാണ്.”.
31. 59എ, 59ബി എന്നീ പുതിയ വകുപ്പുകള്‍ക് കെര്‍മ്കല്‍.—പ്പധാന ആക്റിടെ
59-ാം വകുപ്പിനു കേഷം താടെപ്പറയുന്ന വകുപ്പുകള്‍ക് കെര്‍മ്കകണ്താണ്, അതായത്:—
“59എ.

സവത്തുകളുടെ

മൂേേനിര്‍മ്ണയം.—ഒരു

സഹകരണ

സംഘത്തിന്

ഈൊയി പണയടപ്പെുത്തുന്ന സ്ഥാവര സവത്തിടെ മൂേേനിര്‍മ്ണയത്തില്‍ വായ്പാ തുക
പത്ത് േക്ഷത്തില്‍ താടെയായിരികുന്ന സംഗതിയില്‍ കമിറി അധികാരടപ്പെുത്തിയ ഒരു
ഉകദോഗസ്ഥന്‍പ/ഉകദോഗസ്ഥരും,

വായ്പാതുക

പത്ത്

േക്ഷത്തില്‍

അധികരികുന്ന

സംഗതിയില്‍ സംഘത്തിടെ െീഫ്റ് എക്സികേൂട്ടീവ് ഓഫ്റീസറും കമിറിയിടേ രണ്്
അംഗങ്ങളും കമിറി അധികാരടപ്പെുത്തിയ ഒരു സവതപ്ന്ത മൂേേനിര്‍മ്ണയം നെത്തുന്ന
ആളും

ഉള്‍ക്ടപ്പടെയുളള

അഞ്ച്

അംഗങ്ങളെങ്ങുന്ന

ഒരു

പാനേും

മൂേേനിര്‍മ്ണയം

നെകത്തണ്താണ്.
59ബി. സംഘങ്ങള്‍ക് സ്ഥാവരജംഗമ വസ്തുകള്‍ക് വാങ്ങുന്നത്.—സംഘങ്ങള്‍ക്,
സംഘങ്ങളുടെ

തനത്

ആര്‍മ്ജികുകമ്പാള്‍ക്,

ഫ്റണ്്

ഉപകയാഗിച്ച്

നിര്‍മ്ണയികടപ്പട്ട

പാേികകണ്താണ്.”.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

സ്ഥാവരജംഗമ
പ്പകാരമുള്ള,

വസ്തുകള്‍ക്
മാനദണ്ഡങ്ങള്‍ക്

<!-- page 47 -->

47

32. 63-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടെ 63-ാം വകുപ്പില്‍,—
(i) (4)-ാം ഉപവകുപ്പില്‍, ആദേ ക്ലിപ്തനിബന്ധനയ്കു കേഷം താടെപ്പറയുന്ന
ക്ലിപ്തനിബന്ധന കെര്‍മ്കകണ്താണ്, അതായത്:—
“എന്നുമാപ്തമല്ല,

ആദായനികുതി

റികട്ടണുകള്‍ക്

ഫ്റയല്‍

ടെയ്യാന്‍പ

ബാദ്ധേസ്ഥരായ സംഘങ്ങളുടെ കാരേത്തില്‍, പ്പസ്തുത ആവേേത്തികേകുളള ധനകാരേ
കസ്റ്ററ്ടമെ്, സാമ്പത്തിക വര്‍മ്ഷം അവസാനിച്ച് മൂന്ന് മാസത്തിനകം ആഡിറര്‍മ് യഥാവിധി
സാക്ഷേടപ്പെുകത്തണ്താണ്.”.
(ii)

(9)-ാം

ഉപവകുപ്പിനും

അതിടെ

ക്ലിപ്തനിബന്ധനയ്കും

പകരം,

താടെപ്പറയുന്ന ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്, അതായത്:—
“(9) ഏടതാരു സഹകരണ സംഘവും സംസ്ഥാന സര്‍മ്കാര്‍മ് അംഗീകരിച്ച്
വിജ്ഞാപനം ടെയ്തതുമായ പദ്ധതിക് അനുസൃതമായി സഹകരണ ആഡിറ് ഡയറക്ടര്‍മ്
നിയമികുന്ന ആഡിറര്‍മ്മാരുടെ ഒരു െീമിടനടകാണ്് ആഡിറ് നെത്തികകണ്താണ്.
െീമിടെ രൂപീകരണവും, ഘെനയും, ആഡിറ് നെത്തുന്ന രീതി, ആഡിറ് റികപ്പാര്‍മ്ട്ടിടെ
കപ്പാസസ് ടെയ്യേിടെയും തയ്യാറാകേിടെയും രീതി എന്നിവ സര്‍മ്കാര്‍മ് അംഗീകരിച്ച
പദ്ധതിയില്‍ ഉള്‍ക്ടപ്പെുകത്തണ്താണ്.”.
(iii) (10)-ാം ഉപവകുപ്പ് താടെപ്പറയും പ്പകാരം പകരം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(10) എല്ലാ അടപ്പക്സ് സംഘങ്ങളുടെയും എല്ലാ പ്ഗാമീണ സഹകരണ
ബാങ്കുകളുടെയും
അംഗീകരിച്ച

ധനപരമായ

പാനേില്‍

ടെയ്യികകണ്തും

കണകുകള്‍ക്

ആഡിറ്

ഡയറക്ടര്‍മ്

ആഡിറിംഗ്

കഫ്റമുകടളടകാണ്്

ആഡിറ്

അടപ്പക്സ്

സംഘങ്ങളുടെ

നിന്നുളള

സഹായം

േഭിച്ച

സഹകരണ

ഭരണപരമായ

വിഷയങ്ങളും അനുബന്ധ കണകുകളും വകുപ്പുതേ ആഡിറര്‍മ്മാടര ടകാണ്് ആഡിറ്
ടെയ്യികകണ്തും

ആഡിറ്

സമര്‍മ്പ്പികകണ്തുമാണ്.

റികപ്പാര്‍മ്ട്ടുകള്‍ക്
പ്പസ്തുത

സഹകരണ

ആഡിറില്‍

ആഡിറ്

ഡയറക്ടര്‍മ്ക്

സംഘത്തിടെ

പണകമാ

വസ്തുവകകകളാ സവത്തുകകളാ തിരിമറി നെത്തിടയകന്നാ എടന്തങ്കിേും ദുരുപകയാഗകമാ
തട്ടികപ്പാ പണാപഹരണകമാ ടെയ്ടതകന്നാ ടവളിടപ്പട്ടാല്‍, ആഡിറ് െീം ഒരു പ്പകതേക
റികപ്പാര്‍മ്ട്ട്

തയ്യാറാകകണ്തും

രജിസ്പ്ൊര്‍മ്കും

അത്

സഹകരണ

അയച്ചുടകാെുകകണ്തുമാണ്.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

സംഘ

രജിസ്പ്ൊര്‍മ്

ആഡിറ്

ഡയറക്ടര്‍മ്കും

കനരികട്ടാ

അടല്ലങ്കില്‍

<!-- page 48 -->

48

സഹകരണ ആഡിറ് ഡയറക്ടകറാ രജിസ്പ്ൊറുമായി കൂെിയാകോെിച്ചുടകാകണ്ാ ഒരു
വിേദമായ അകനവഷണ വിൊരണയ്കായി വകുപ്പ് 68എ പ്പകാരം നിയമിതനായ
വിജിേന്‍പസ് ഓഫ്റീസര്‍മ്ക് പ്പകതേക റികപ്പാര്‍മ്ട്ട് അയച്ചുടകാെുകകണ്താണ്.”.
(iv) (12)-ാം ഉപവകുപ്പില്‍ “അവര്‍മ് സംഘത്തിടേ അംഗങ്ങളായിരികണടമന്നില്ല
അവരില്‍ നിന്നും” എന്നീ വാകുകള്‍ക്ക് പകരം “അംഗങ്ങളില്‍ നിന്നും” എന്നീ
വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
(v) (12)-ാം ഉപവകുപ്പിനു കേഷം താടെപ്പറയുന്ന ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(12എ) ഒരു സഹകരണ സംഘത്തിടെ ആഡിറില്‍ തുെര്‍മ്ച്ചയായ രണ്ില്‍
കൂെുതല്‍ ആഡിറുകളില്‍ ഒരു ആഡിറടറകയാ, അടല്ലങ്കില്‍ ആഡിറിംഗ് കഫ്റമുകടളകയാ
അടല്ലങ്കില്‍ ആഡിറര്‍മ്മാരുടെ െീമിടനകയാ െുമതേടപ്പെുത്താന്‍പ പാെില്ലാത്തതാകുന്നു.”.
33. 64-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടെ 64-ാം വകുപ്പില്‍,—
(i)

(1)-ാം

ഉപവകുപ്പിന്

കേഷം

താടെപ്പറയുന്ന

ഉപവകപ്പുകള്‍ക്

കെര്‍മ്കകണ്താണ്, അതായത്:—
“(1എ)
മകറടതങ്കിേും

ഒരു

ടപാതു

കസാഫ്റ്റടവയകറാ
്

കസാഫ്റ്റടവയകറാ
്
ഉപകയാഗിച്ച്

രജിസ്പ്ൊര്‍മ്

അകൗണ്ുകള്‍ക്

അംഗീകരിച്ച
തയ്യാറാകുന്ന

സഹകരണ സംഘങ്ങളുടെ സംഗതിയില്‍, ഇന്‍പഫ്റര്‍മ്കമഷന്‍പ സിസ്റ്റത്തിടെ ആഡിറും
കസാഫ്റ്റടവയറിടെയും
്

ഹാര്‍മ്ഡ്ടവയറിടെയും

പരികോധനയും

ആഡിറില്‍

ഉള്‍ക്ടപ്പെുന്നതാണ്.
(1ബി) ഇന്‍പഫ്റര്‍മ്കമഷന്‍പ സിസ്റ്റത്തിടെ ആഡിറിേും കസാഫ്റ്റടവയറിടെയും
്
ഹാര്‍മ്ഡ്ടവയറിടെയും പരികോധനാ കവളയിേും ഏടതങ്കിേും കരഖകളുടെ കൃപ്തിമതവം
അടല്ലങ്കില്‍

കസാഫ്റ്റടവയറിടെകയാ
്

കൃപ്തിമതവം

ടവളിടപ്പട്ടാല്‍,

ഹാര്‍മ്ഡ്ടവയറിടെകയാ

ആഡിറര്‍മ്/ആഡിറര്‍മ്മാര്‍മ്/ആഡിറ്

പ്പവര്‍മ്ത്തനത്തിേുളള
കഫ്റമുകള്‍ക്

പ്പസ്തുത

കൃപ്തിമങ്ങള്‍ക് സഹകരണ ആഡിറ് ഡയറക്ടടറയും രജിസ്പ്ൊടറയും അറിയികകണ്താണ്.
(1സി) രജിസ്പ്ൊര്‍മ്

കനരികട്ടാ,

സഹകരണ

ആഡിറ്

ഡയറക്ടര്‍മ്

രജിസ്പ്ൊറുമായി കൂെിയാകോെിച്ചുടകാകണ്ാ സിസ്റ്റത്തിേുളള കൃപ്തിമങ്ങള്‍ക് സംബന്ധിച്ച്

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 49 -->

49

അകനവഷികുന്നതിനായി,

അതതു

സംഗതികപാടേ,

കപാേീസികനാ

വിജിേന്‍പസ്

ഓഫ്റീസറികനാ വിവരം നല്‍കകണ്താണ്.”.
(ii) (4എ) ഉപവകുപ്പില്‍, “ഒരു മാസത്തിനകം” എന്നീ വാകുകള്‍ക്ക് പകരം
“പതിനഞ്ച്

ദിവസങ്ങള്‍ക്കകം”

അംഗങ്ങളായിരികണടമന്നില്ല

എന്നീ

അവരില്‍

വാകുകള്‍ക്
നിന്നും”

കെര്‍മ്കകണ്തും

എന്നീ

വാകുകള്‍ക്ക്

“അവര്‍മ്
പകരം

“അംഗങ്ങളില്‍ നിന്നും അതില്‍” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്തുമാണ്.
(iii) (4ബി) ഉപവകുപ്പില്‍, “മൂന്ന് മാസത്തിനകം” എന്നീ വാകുകള്‍ക്ക് പകരം
“നാല്‍പത്തിയഞ്ച് ദിവസങ്ങള്‍ക്കകം” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
(iv) (5)-ാം ഉപവകുപ്പില്‍,—
(എ) “ആഡിറകറാ” എന്ന വാകിനു കേഷം “അടല്ലങ്കില്‍ ആഡിറര്‍മ്മാരുടെ
െീകമാ” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
(ബി) “നാേ് മാസത്തിനകം” എന്നീ വാകുകള്‍ക്ക് പകരം “ടതാണൂറ്
ദിവസങ്ങള്‍ക്കകം” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
(v) (5)-ാം ഉപവകുപ്പിനുകേഷം താടെപ്പറയുന്ന ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(5എ) ആഡിറ് പൂര്‍മ്ത്തിയാകി സഹകരണ ആഡിറ് ഡയറക്ടര്‍മ്ക് ആഡിറ്
റികപ്പാര്‍മ്ട്ട് സമര്‍മ്പ്പികുന്നതിനുമുമ്പായി, ആഡിറര്‍മ്, ആഡിറര്‍മ്മാരുടെ െീം, അടല്ലങ്കില്‍
ആഡിറ് കഫ്റം, അതതു സംഗതികപാടേ, ആഡിറിടേ കടണ്ത്തേുകള്‍ക് ബന്ധടപ്പട്ട
സംഘത്തിടെ മാകനജിംഗ് കമിറിയുമായി െര്‍മ്ച്ച ടെകയ്യണ്തും അവരുടെ മറുപെി
കരഖാമൂേം വാകങ്ങണ്തുമാണ്.”.
(vi) (9)-ാം ഉപവകുപ്പ് താടെപ്പറയും പ്പകാരം പകരം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(9)

സംഘത്തിടെ

പ്പവര്‍മ്ത്തനത്തില്‍

ഉടണ്ന്ന് പ്പസ്തുത വകുപ്പ് പ്പകാരം

എടന്തങ്കിേും

നെന്ന ആഡിറില്‍

കപാരായ്മകള്‍ക്

ടവളിടപ്പട്ടാല്‍,

ആഡിറ്

റികപ്പാര്‍മ്ട്ടില്‍ െൂണ്ികാണിച്ച കപാരായ്മകളും പ്കമകകെുകളും, ഏടതങ്കിേും ഉടണ്ങ്കില്‍
അത് പരിഹരികുന്നതിനു കമിറി നെപെികള്‍ക് സവീകരികകണ്തും ഓകരാ വര്‍മ്ഷവും
കെരുന്ന ടപാതുകയാഗത്തിടെ മീറിംഗിനു മുമ്പാടക സവീകരിച്ച നെപെി സംബന്ധിച്ച

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 50 -->

50

റികപ്പാര്‍മ്ട്ട് സഹിതം ആഡിറ് റികപ്പാര്‍മ്ട്ട് വയ്കകണ്തും അതില്‍ പ്പസ്തുത കപാരായ്മകളും
പ്കമകകെുകളും

വിേദീകരികകണ്തുമാണ്.

കപാരായ്മകളും

പ്കമകകെുകളും

പരിഹരികുന്നത്

എെുകുന്നത്

തുെകരണ്തും

എല്ലാ

പരിഹരികുന്നതുവടര

എല്ലാ

ആഡിറ്

റികപ്പാര്‍മ്ട്ടിേുളള

വടര

കമിറി

കപാരായ്മകളും

വര്‍മ്ഷവും

അത്

എല്ലാ

നെപെികള്‍ക്

പ്കമകകെുകളും

ടപാതുകയാഗത്തിടെ

മീറിംഗില്‍

ധരിപ്പികുകയും ടെകയ്യണ്താണ്. ടപാതുകയാഗ മീറിംഗ് നെന്ന തീയതി മുതല്‍ പതിനഞ്ച്
ദിവസങ്ങള്‍ക്കകം

സഹകരണ

ആഡിറ്

ഡയറക്ടര്‍മ്കും

രജിസ്പ്ൊര്‍മ്കും

എെുത്ത

നെപെിയുടെ റികപ്പാര്‍മ്ട്ട് കമിറി അയച്ചുടകാെുകകണ്താണ്.”.
(vii) (9)-ാം ഉപവകുപ്പിന് കേഷം താടെപ്പറയുന്ന ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(9എ)

ഏടതങ്കിേും

ആള്‍ക്,

സംഘത്തിനുണ്ാകിയിട്ടുളള

നാേനഷ്ടങ്ങളികേേുളള നിയമനെപെികളില്‍ നിന്ന് ഒെിവാകുന്നതികേയ്ക് കരഖകകളാ,
റികാര്‍മ്ഡുകകളാ നേിപ്പികാകനാ തിരുത്താകനാ പ്േമിച്ചിട്ടുടണ്ന്ന് സഹകരണ ആഡിറ്
ഡയറക്ടര്‍മ്കകാ അകേഹം സംഘത്തില്‍ ആഡിറ് നെത്താനായി െുമതേടപ്പെുത്തിയ
ആളികനാ അഭിപ്പായമുളളപക്ഷം പ്പസ്തുത വിവരം തടെ കൺകപ്ൊളിംഗ് ഓഫ്റീസര്‍മ്ക്
രജിസ്പ്ൊകറാ, അകേഹം അധികാരടപ്പെുത്തിയ ആളുമാകയാ കൂെിയാകോെിച്ചുടകാണ്്
അതതു സംഗതികപാടേ, കപാേീസികനാ വിജിേന്‍പസ് ഓഫ്റീസര്‍മ്കകാ പരാതി ഫ്റയല്‍
ടെയ്യുന്നതിനായി റികപ്പാര്‍മ്ട്ട് ടെകയ്യണ്താണ്.”.
34. 65-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 65-ാം വകുപ്പില്‍,—
(i) (1)-ാം ഉപവകുപ്പില്‍,—
(എ) (ബി) ഖണ്ഡം ഒെിവാകകണ്താണ്;
(ബി) (ഡി) ഖണ്ഡത്തിനു പകരം താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(ഡി)

സംഘത്തിടെ

കമിറിയിടേ

ഭൂരിപക്ഷം

അംഗങ്ങളാകോ,

അടല്ലങ്കില്‍ സംഘത്തിടേ ആടക അംഗങ്ങളുടെ മൂന്നിടോന്നില്‍ കുറയാത്തകതാ
അടല്ലങ്കില്‍ ടപാതുകയാഗ മീറിംഗിടെ കവാറത്തിനാവേേമായ എണം അംഗങ്ങകളാ,
ഏതാകണാ കുറവ്, അവരുടെ അകപക്ഷയികേകോ; അടല്ലങ്കില്‍”;

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 51 -->

51

(സി) (എഫ്റ്) ഖണ്ഡത്തില്‍, “ആള്‍ക് മുകഖനകയാ” എന്നീ വാകുകള്‍ക്ക്
പകരം “ആകളാ ആളുകള്‍ക് മുകഖനകയാ” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
(ii) (2)-ാം ഉപവകുപ്പില്‍, (സി) ഖണ്ഡത്തിനുകേഷം താടെപ്പറയുന്ന ഖണ്ഡം
കെര്‍മ്കകണ്താണ്, അതായത്:—
“(ഡി) അകനവഷണവുമായി ബന്ധടപ്പട്ടകതാ അതില്‍ ഉള്‍ക്ടപ്പട്ടിരികുന്നകതാ
ആയ

ആളിന്/ആളുകള്‍ക്ക്

രജികസ്റ്റര്‍മ്ഡ്

തപാല്‍

അകനവഷണത്തിടെ

മുകഖനകയാ

കനരികട്ടാ

വിഷയം

മതിയായ

സൂെിപ്പിച്ചുടകാണ്്

കനാട്ടീസ്

നല്‍കകണ്തും

അയാളുടെ/അവരുടെ ഭാഗം കകള്‍ക്കുന്നതിന് ഒരവസരം നല്‍കകണ്തുമാണ്.”.
(iii) (2)-ാം ഉപവകുപ്പിനു കേഷം, താടെപ്പറയുന്ന ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(2എ) ഈ വകുപ്പ് പ്പകാരം നെത്തിയ അകനവഷണ വിൊരണയില്‍
എടന്തങ്കിേും

കപാരായ്മ

നെത്തുന്നതിന്
വേക്തിഗത

ടവളിടപ്പട്ടാല്‍,

അകേഹം
ബാധേത

രജിസ്പ്ൊര്‍മ്കകാ,

അധികാരടപ്പെുത്തിയ
തിട്ടടപ്പെുത്തുന്നത്

അകനവഷണ

വിൊരണ

വേക്തികയാ/വേക്തികള്‍ക്കകാ,

ഉള്‍ക്ടപ്പടെ,

സംഘത്തിനുണ്ായ

കപാരായ്മയുടെയും അപഹരികടപ്പട്ട തുകയും, മറ് നഷ്ടങ്ങളും സംബന്ധിച്ച വിേദമായ
ഒരു അകനവഷണ റികപ്പാര്‍മ്ട്ട് തയ്യാറാകകണ്താണ്. അകനവഷണത്തില്‍, 94-ാം വകുപ്പിന്‍പ
കീെില്‍ വരുന്ന എടന്തങ്കിേും കുറം ടവളിടപ്പട്ടാല്‍, അകനവഷണ ഉകദോഗസ്ഥന്‍പ ഒരു
സ്ടപഷേല്‍ റികപ്പാര്‍മ്ട്ട് തയ്യാറാകി രജിസ്പ്ൊറിന് നല്‍കകണ്തും അകതാടൊപ്പം അയാള്‍ക്
ഒരു പകര്‍മ്പ്പ് വിേദമായ അകനവഷണത്തിനായി, അതതു സംഗതികപാടേ, കപാേീസികനാ
വിജിേന്‍പസ് ഓഫ്റീസര്‍മ്കകാ അയച്ചുടകാെുകകണ്തുമാണ്.”.
(iv) (5)-ാം ഉപവകുപ്പില്‍, “ആറുമാസകാേയളവിനുളളില്‍” എന്ന വാകിന്
പകരം “നാേുമാസകാേയളവിനുളളില്‍” എന്ന വാക് കെര്‍മ്കകണ്താണ്.
(v) (6)-ാം ഉപവകുപ്പില്‍, “32-ാം വകുപ്പിടേ വേവസ്ഥകള്‍ക്കനുസൃതമായി”
എന്നീ വാകുകള്‍ക്കും അകത്തിനും െിഹ്നത്തിനും പകരം “ബന്ധടപ്പട്ട കക്ഷികള്‍ക്ക്
വാദം കകള്‍ക്കാനുളള അവസരം നല്‍കിയ കേഷം നിയമപരമായ” എന്നീ വാകുകള്‍ക്
കെര്‍മ്കകണ്താണ്.
(vi) (6)-ാം ഉപവകുപ്പിന് കേഷം, താടെപ്പറയുന്ന ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്,
അതായത്:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 52 -->

52

“(7) ഏടതങ്കിേും അകനവഷണ വിൊരണയില്‍ സഹകരണ സംഘത്തില്‍
ഏടതങ്കിേും പ്കമകകകൊ പണാപഹരണകമാ പണകമാ വസ്തുവകകകളാ ആസ്തികകളാ
തട്ടികപ്പാ ടവട്ടികപ്പാ നെത്തിയതാകയാ അടല്ലങ്കില്‍ സംഘത്തിന് എടന്തങ്കിേും നഷ്ടം
ഉണ്ായതാകയാ
പ്പകതേകമായി

ടവളിടപ്പട്ടാല്‍,

രജിസ്പ്ൊര്‍മ്കകാ

അധികാരടപ്പെുത്തിയകതാ

രജിസ്പ്ൊര്‍മ്

െുമതേടപ്പെുത്തിയകതാ

ഇതികേയ്കായി
ആയ

ഏടതാരു

ഉകദോഗസ്ഥകനാ, നഷ്ടം തിട്ടടപ്പെുത്തിടകാണ്് നിയമനെപെികളിേൂടെ സംഘത്തിടെ
അപഹരികടപ്പട്ട

അടല്ലങ്കില്‍

ടവട്ടിച്ച

പണം,

വസ്തുവകകള്‍ക്,

ആസ്തികള്‍ക്

വീടണ്െുകുന്നതിനാവേേമായ സതവര നെപെികള്‍ക് എെുകകണ്താണ്.”.
35. 66-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 66-ാം വകുപ്പില്‍,—
(i)

(2)-ാം

ഉപവകുപ്പിന്

കേഷം

താടെപ്പറയുന്ന

ഉപവകുപ്പുകള്‍ക്

കെര്‍മ്കകണ്താണ്, അതായത്:—
“(2എ) അടപ്പക്സ,് ടസന്‍പപ്െല്‍, ടഫ്റഡറല്‍ സഹകരണ സംഘങ്ങളുടെയും
മടറല്ലാ പ്പാഥമിക സഹകരണ സംഘങ്ങളുടെയും പരികോധനയ്കായി, രജിസ്പ്ൊര്‍മ്ക്
അകേഹത്തിടെ

നിയപ്ന്തണത്തിന്‍പകീെിേുള്ള

ഓഫ്റീസര്‍മ്മാരുടെ

പ്പകതേക

െീമിടന

അധികാരടപ്പെുത്താവുന്നതാണ്.
(2ബി) ഇത്തരത്തിേുളള

പരികോധനകളുടെ

റികപ്പാര്‍മ്ട്ട്

ബന്ധടപ്പട്ട

അടപ്പക്സ്, ടസന്‍പപ്െല്‍, ടഫ്റഡറല്‍ സംഘങ്ങള്‍ക്കും, എല്ലാ പ്പാഥമിക സഹകരണ
സംഘങ്ങള്‍ക്കും മുപ്പത് ദിവസത്തിനുളളില്‍ കരഖാമൂേം നല്‍കകണ്തും അറിയിപ്പ് േഭിച്ച
തീയതി

മുതല്‍

നാല്പത്തിയഞ്ച്

ദിവസകാേയളവിനുളളില്‍

രജിസ്പ്ൊര്‍മ്

മുമ്പാടക

ഖണ്ഡിക തിരിച്ചുളള തൃപ്തികരമായ ഒരു നെപെി റികപ്പാര്‍മ്ട്ട് ഫ്റയല്‍ ടെയ്യാന്‍പ കമിറികും
സംഘത്തിടെ െീഫ്റ് എക്സികേൂട്ടീവിനും ബാധേത ഉണ്ായിരികുന്നതുമാണ്.”.
(ii) (6)-ാം ഉപവകുപ്പും അതിടെ ക്ലിപ്തനിബന്ധനയും വിട്ടുകളകയണ്താണ്.
36. 66സി വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 66സി വകുപ്പില്‍,—
(i) നിേവിേുളള വകുപ്പിടന (1)-ാം ഉപവകുപ്പായി അകം ഇകെണ്താണ്.
(ii) അപ്പകാരം അകമിട്ട (1)-ാം ഉപവകുപ്പിടേ ഖണ്ഡം (എഫ്റ്)-ടന (ജി)
ഖണ്ഡമായി പുനരക്ഷരം ടെകയ്യണ്താണ്.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 53 -->

53

(iii) അപ്പകാരം

പുനരക്ഷരം

ടെയ്ത

(ജി)

ഖണ്ഡത്തിനു

മുന്‍പപായി

താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്, അതായത്:—
“(എഫ്റ്) കമിറി അംഗീകരിച്ച ആഡിറ് റികപ്പാര്‍മ്ട്ടികേേുളള തിരുത്തല്‍
റികപ്പാര്‍മ്ട്ടുകളും സംഘത്തിടെ ടപാതുകയാഗത്തിടെ പ്പകമയവും.”.
(iv) (1)-ാം

ഉപവകുപ്പിനു

കേഷം

താടെപ്പറയുന്നവ

(2)-ാം

ഉപവകുപ്പായി

കെര്‍മ്കകണ്താണ്, അതായത്:—
“(2) ഏടതാരു സഹകരണ സംഘവും, സഹകരണ സംഘത്തിടെ െീഫ്റ്
എക്സികേൂട്ടീവ്
മപ്തമാസ

യഥാവിധി

സാക്ഷേടപ്പെുത്തിയ

ടപ്കഡിറ്

റികട്ടണുകള്‍ക്

സമര്‍മ്പ്പികകണ്തും,

അത്

പുനഃപരികോധികകണ്തും
അവകോകനം

നെത്തിയ

ഓകരാ
റികപ്പാര്‍മ്ട്ടിടെ

മപ്തമാസം

പ്പവര്‍മ്ത്തനങ്ങളികേേുള്ള
രജിസ്പ്ൊര്‍മ്

യഥാവിധി

കെിയുകമ്പാെും

രജിസ്പ്ൊര്‍മ്

അെിസ്ഥാനത്തില്‍

തിരുത്തല്‍

റികപ്പാര്‍മ്ട്ട്

സമര്‍മ്പ്പികകണ്തുമാണ്. ഏടതങ്കിേും സംഘം യഥാസമയം റികട്ടണുകള്‍ക് സമര്‍മ്പ്പികാന്‍പ
പരാജയടപ്പെുന്നപക്ഷം രജിസ്പ്ൊര്‍മ്ക് നിര്‍മ്ണയികടപ്പെുന്ന പ്പകാരമുളള സംഘങ്ങളുടെ
തരംതിരിവും

കാറഗറിയും

അെിസ്ഥാനടപ്പെുത്തി

പതിനായിരം

രൂപയില്‍

അധികരികാത്ത പിെ െുമത്താന്‍പ അധികാരമുണ്ായിരികുന്നതാണ്.”.
37. 68-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടെ 68-ാം വകുപ്പില്‍,—
(i) (1)-ാം ഉപവകുപ്പില്‍, “അതിടെ പ്പവര്‍മ്ത്തനം അവസാനിപ്പികുകകയാ
ടെയ്യുന്നതിനിെയില്‍”

എന്നീ

വാകുകള്‍ക്ക്

കേഷം

“അടല്ലങ്കില്‍

വിജിേന്‍പസ്

ഓഫ്റീസറുടെ റികപ്പാര്‍മ്ട്ടിടെ അെിസ്ഥാനത്തില്‍” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
(ii) (3)-ാം ഉപവകുപ്പില്‍,—
(എ)

“നഷ്ടപരിഹാരകമാ”

എന്ന

വാകിനു

കേഷം

“അറുപത്

ദിവസകാോവധികുളളില്‍” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്;
(ബി) താടെപ്പറയുന്ന ക്ലിപ്തനിബന്ധന കെര്‍മ്കകണ്താണ്, അതായത്:—
“എന്നാല്‍ അത്തരം കാേയളവ്, രജിസ്പ്ൊറുടെ വികവെനാധികാരം
പ്പകയാഗിച്ചുടകാണ്് സമയാസമയങ്ങളില്‍ എെുതി കരഖടപ്പെുത്തിയ കാരണത്താല്‍
ദീര്‍മ്ഘിപ്പികാവുന്നതും യാടതാരു കാരണവോേും ദീര്‍മ്ഘിപ്പിച്ച കാേയളവ് അറുപത്
ദിവസത്തില്‍ അധികരികാന്‍പ പാെില്ലാത്തതുമാകുന്നു.”.

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 54 -->

54

38. 68ബി എന്ന പുതിയ വകുപ്പ് കെര്‍മ്കല്‍.—പ്പധാന ആക്റിടെ 68എ വകുപ്പിനു
കേഷം താടെപ്പറയുന്ന 68ബി വകുപ്പ് കെര്‍മ്കകണ്താണ്, അതായത്:—
“68ബി.

പ്കമകകെുകള്‍ക്

മുതോയവ

മകകാരേം

ടെയ്യുന്നതിന്

ഗവൺടമെികനാ അടല്ലങ്കില്‍ രജിസ്പ്ൊര്‍മ്കകാ ഉളള അധികാരങ്ങള്‍ക്.—(1) 1860-ടേ
ഇന്‍പഡേന്‍പ േിക്ഷാ നിയമസംഹിതയികോ 1988-ടേ അെിമതി നികരാധന ആക്റികോ
അടല്ലങ്കില്‍ രണ്ിേുകമാ ഉളള വേവസ്ഥകള്‍ക് പ്പകാരം ഒരു സംഘത്തിടേ പണാപഹരണകമാ
പ്കമകകെുകകളാ അെിമതികയാ സംബന്ധിച്ച കകസുകള്‍ക്, സര്‍മ്കാരികനാ രജിസ്പ്ൊര്‍മ്കകാ,
അതതു സംഗതികപാടേ, അകനവഷണത്തിനും തുെര്‍മ്നെപെികള്‍ക്കുമായി കപാേീസികനാ
വിജിേന്‍പസ്

ആെ്

ആെികറപ്ഷന്‍പ

ബേൂകറായ്കകാ,

അതതു

സംഗതികപാടേ,

അംഗങ്ങള്‍ക്കകാ,

ഉകദോഗസ്ഥര്‍മ്കും

അയച്ചുടകാെുകാവുന്നതുമാണ്.
(2)

ഒരു

സംഘത്തിടെ

കമിറി

ജീവനകാര്‍മ്കുകമാ, അടല്ലങ്കില്‍ രണ്ിനും എതിടരകയാ 1988-ടേ അെിമതി നികരാധന
ആക്റ് പ്പകാരമുളള ഒരു കുറത്തിന് അകനവഷണ വിൊരണ, എന്‍പകവയറി അടല്ലങ്കില്‍
അകനവഷണം

നെത്തുന്നതിനും

കുറം

നെപെിയ്ടകെുകേിനും

അനുമതി

നല്‍കുന്നതിനുളള അധികാരി രജിസ്പ്ൊര്‍മ് ആയിരികുന്നതാണ്.
(3)

സര്‍മ്കാര്‍മ്

നിശ്ചയികുന്ന

െീഫ്റ്

എക്സികേൂട്ടീവ്

ഓഫ്റീസറുടെ

കാരേത്തില്‍ അനുമതി നല്‍കകണ് അധികാരി സര്‍മ്കാര്‍മ് സഹകരണ വകുപ്പിടെ
ടസപ്കട്ടറി ആയിരികുന്നതാണ്.”.
39. 69-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 69-ാം വകുപ്പിടെ (1)-ാം
ഉപവകുപ്പില്‍,—
(i) (എച്ച്) ഖണ്ഡത്തിനു പകരം താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(എച്ച്) സംഘവും സംഘത്തിടെ ഒരു ടപ്കഡിററും തമില്‍; അടല്ലങ്കില്‍”.
(ii) (എച്ച്) ഖണ്ഡത്തിനു കേഷം, താടെപ്പറയുന്ന (ഐ), (ടജ) എന്നീ ഖണ്ഡങ്ങള്‍ക്
കെര്‍മ്കകണ്താണ്, അതായത്:—
“(ഐ) സഹകരണ സംഘവും 14എഎ വകുപ്പ് പ്പകാരമുളള അനുബന്ധ
സ്ഥാപനങ്ങളും തമില്‍; അടല്ലങ്കില്‍

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 55 -->

55

(ടജ) 14ബി വകുപ്പ് പ്പകാരം രൂപീകരിച്ച പങ്കാളിത്തത്തിടേ അംഗങ്ങള്‍ക്
തമില്‍,

അങ്ങടനയുളള

തര്‍മ്കങ്ങളില്‍

പണസംബന്ധമല്ലാത്ത

തര്‍മ്കങ്ങളുടെ

സംഗതിയില്‍ 70എ വകുപ്പിന്‍പ കീെില്‍ രൂപീകൃതമായ സഹകരണ ആര്‍മ്ബികപ്െഷന്‍പ
കകാെതികും പണസംബന്ധമായ തര്‍മ്കങ്ങളില്‍ രജിസ്പ്ൊര്‍മ്കും റഫ്റര്‍മ് ടെകയ്യണ്തും,
ആര്‍മ്ബികപ്െഷന്‍പ കകാെതികയാ രജിസ്പ്ൊകറാ, അതതു സംഗതികപാടേ, അങ്ങടനയുളള
തര്‍മ്കം തീര്‍മ്പ്പാകകണ്തും, അപ്പകാരമുളള തര്‍മ്കടത്ത സംബന്ധിച്ച് ഏടതങ്കിേും
വേവഹാരകമാ അഥവാ മറു നെപെികകളാ സവീകരികാന്‍പ മറ് യാടതാരു കകാെതികകാ
അധികാരസ്ഥാനത്തികനാ അധികാരിതയുണ്ായിരികുന്നതല്ലാത്തതുമാകുന്നു.”.
40. 69എ വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 69എ വകുപ്പിടേ (1)-ാം
ഉപവകുപ്പില്‍,

“ബാങ്കിംഗ്

ഇെപാെുകള്‍ക്

നെത്തുന്ന”

എന്നീ

വാകുകള്‍ക്

ഒെിവാകകണ്താണ്.
41. 70-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 70-ാം വകുപ്പിടേ (6)-ാം
ഉപവകുപ്പില്‍,

“ഒരു

അവാര്‍മ്ഡ്

പാസ്സാകകണ്തും”

എന്നീ

വാകുകള്‍ക്ക്

കേഷം

“പണപരമായ പ്പേ്നങ്ങള്‍ക് ഉള്‍ക്ടപ്പെുന്ന സംഗതികളില്‍ ഒരു വര്‍മ്ഷത്തിനകം” എന്നീ
വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
42. 70എ വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 70എ വകുപ്പിടെ (2)-ാം
ഉപവകുപ്പിനു പകരം താടെപ്പറയുന്ന ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്, അതായത്:—
“(2) ആര്‍മ്ബികപ്െഷന്‍പ കകാെതിയുടെ പ്പിമസഡിംഗ് ഓഫ്റീസര്‍മ് ജുഡീഷേല്‍
സര്‍മ്വീസിടേ മുന്‍പസിഫ്റ് മജിസ്കപ്െറ് റാങ്കികോ അതിനു മുകളികോ ഉളള ഒരു ഓഫ്റീസര്‍മ്
ആയിരികകണ്താണ്.”.
43. 73-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 73-ാം വകുപ്പില്‍,—
(i) (2എ) ഉപവകുപ്പിേും അതിടെ വിേദീകരണത്തിേും ഉളള “മൂന്നു വര്‍മ്ഷം”
എന്നീ വാകുകള്‍ക്ക് പകരം “രണ്് വര്‍മ്ഷം” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
(ii)

(2എ)

ഉപവകുപ്പില്‍,

വിേദീകരണത്തിനു

കേഷം

താടെപ്പറയുന്ന

ക്ലിപ്തനിബന്ധനകള്‍ക് കെര്‍മ്കകണ്താണ്, അതായത്:—
“എന്നാല്‍, 72-ാം വകുപ്പിടെ (1)-ാം ഉപവകുപ്പ് പ്പകാരം േികവികഡറടറ
നിയമിച്ച

തീയതി

മുതല്‍

രണ്്

വര്‍മ്ഷകാേയളവിനുളളില്‍

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

സമാപന

നെപെികള്‍ക്

<!-- page 56 -->

56

പൂര്‍മ്ത്തീകരികാന്‍പ

കെിയാത്തപക്ഷം

േികവികഡറര്‍മ്

നെപെിപ്കമങ്ങള്‍ക്

പൂര്‍മ്ത്തീകരികുന്നതിന് അകേഹത്തിടന തെസ്സടപ്പെുത്തുന്ന നെപെികളിടേ തെസ്സങ്ങള്‍ക്
വിവരിച്ചുടകാണ്് രജിസ്പ്ൊര്‍മ് മുകഖന ഒരു റികപ്പാര്‍മ്ട്ട് സമര്‍മ്പ്പികകണ്തും അങ്ങടനയുളള
സംഗതികളില്‍

നിര്‍മ്ണയികടപ്പെുന്ന

സമയപരിധിയ്കുളളില്‍

സര്‍മ്കാരിടെ

പ്പകാരം

സര്‍മ്കാര്‍മ്

അംഗീകാരകത്താെുകൂെി

നിശ്ചയിച്ചിട്ടുളള
അന്തിമ

ഉത്തരവ്

പുറടപ്പെുവികകണ്തുമാണ്:
എന്നാല്‍,

യാടതാരു

കാരണവോേും

അത്തരം

ദീര്‍മ്ഘിപ്പികല്‍

ഒരു

വര്‍മ്ഷകാേയളവ് അധികരികാന്‍പ പാെില്ലാത്തതാണ്.”.
44. 74സി വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 74സി വകുപ്പില്‍,—
(i) നിേവിേുളള വകുപ്പിടന (1)-ാം ഉപവകുപ്പായി അകമികെണ്താണ്.
(ii) അപ്പകാരം

അകമിട്ട

(1)-ാം

ഉപവകുപ്പിനു

കേഷം

താടെപ്പറയുന്ന

ഉപവകുപ്പ് കെര്‍മ്കകണ്താണ്, അതായത്:—
“(2)

രജിസ്പ്ൊര്‍മ്,

പരികോധനാ

റികപ്പാര്‍മ്ട്ടിടെ

അെിസ്ഥാനത്തില്‍,

ആവേേടമങ്കില്‍, പ്പവര്‍മ്ത്തനങ്ങള്‍ക് പുനഃസംഘെിപ്പികുന്നതിനുള്ള പരിഹാരനെപെികള്‍ക്
സര്‍മ്കാരികനാെ് നിര്‍മ്കേേികകണ്താണ്.”.
45. 76-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 76-ാം വകുപ്പില്‍, “68-ാം വകുപ്പ്
(2)-ാം ഉപവകുപ്പ്, പ്പകാരകമാ” എന്നീ വാകുകള്‍ക്കും അകങ്ങള്‍ക്കും പ്ബാകറിനും
കേഷം “69എ വകുപ്പില്‍ വേവസ്ഥ ടെയ്യുന്ന ഓംബുഡ്സ്മാടെ ഏടതാരു ഉത്തരകവാ”
എന്നീ വാകുകളും അകങ്ങളും അക്ഷരവും കെര്‍മ്കകണ്താണ്.
46. 80-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 80-ാം വകുപ്പില്‍,—
(i)

(3)-ാം

ഉപവകുപ്പില്‍

അവസാന

ഭാഗത്തായി

താടെപ്പറയുന്ന

വാകേം

കെര്‍മ്കകണ്താണ്, അതായത്:—
“പ്പസ്തുത നിയമനം നിര്‍മ്ണയികടപ്പട്ട പ്പകാരം പിന്നീെുളള കപാേീസ്
പരികോധനയിേൂടെ

അകേഹത്തിടെ/അവരുടെ

സവഭാവവും

പരികോധിച്ച കേഷം മാപ്തകമ നിയമനം പ്കമടപ്പെുത്തുവാന്‍പ പാെുളളൂ.”.
(ii) (3എ) ഉപവകുപ്പില്‍,—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

പൂര്‍മ്വെരിപ്തവും

<!-- page 57 -->

57

(എ)

“സംഘം

ജീവനകാരുടെയും”

എന്നീ

വാകുകള്‍ക്ക്

പകരം

“സംഘങ്ങളുടെ െീഫ്റ് എക്സികേൂട്ടീവ് ഒെിടകയുളള സംഘം ജീവനകാരുടെയും” എന്നീ
വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്;
(ബി)

താടെപ്പറയുന്ന വാകേം അവസാന ഭാഗത്തായി കെര്‍മ്കകണ്താണ്,

അതായത്:—
“അടപ്പക്സ്

സംഘങ്ങളിടേ

െീഫ്റ്

എക്സികേൂട്ടീവിടെ

നിയമനം

കയാഗേതകള്‍ക് നിശ്ചയിച്ചുടകാണ്് സര്‍മ്കാര്‍മ് നെകത്തണ്താണ്.”.
(iii) (5)-ാം ഉപവകുപ്പില്‍,—
(എ)

“മൂന്നു േതമാനം” എന്നീ വാകുകള്‍ക്ക് പകരം “നാേ് േതമാനം”

എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്;
(ബി)

ക്ലിപ്തനിബന്ധനയില്‍, “മുപ്പത്തിമൂന്നില്‍” എന്ന വാകിന് പകരം

“ഇരുപത്തിയഞ്ചില്‍” എന്ന വാക് കെര്‍മ്കകണ്താണ്.
47. 80എ വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 80എ വകുപ്പിടെ (1)-ാം
ഉപവകുപ്പില്‍,
പകരം

“കബാര്‍മ്ഡുകളിടേ

“കബാര്‍മ്ഡുകളിടേയും

ജീവനകാര്‍മ്കും”

സംസ്ഥാനത്തിടേ

എന്നീ

സഹകരണ

വാകുകള്‍ക്ക്
യൂണിയനുകളിടേ

ജീവനകാടരയും” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
48. 80ബി വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 80ബി വകുപ്പില്‍, (1)-ാം
ഉപവകുപ്പിന് പകരം താടെപ്പറയുന്നവ കെര്‍മ്കകണ്താണ്, അതായത്:—
“(1) ഉകദോഗസ്ഥടരയും ജീവനകാടരയും റിപ്കൂട്ട് ടെയ്യുന്നതുമായി ബന്ധടപ്പട്ട്,
ഈ

ആക്റികോ

സംഘത്തിടെ

അതിന്‍പകീെില്‍

ഉപനിയമങ്ങളികോ

ഉണ്ാകിയിട്ടുളള
എന്തുതടന്ന

െട്ടങ്ങളികോ

ഏടതങ്കിേും

അെങ്ങിയിരുന്നാേും,

എന്നാല്‍,

80ബിബി വകുപ്പിന് വികധയമായും സര്‍മ്കാര്‍മ് ഗസറ് വിജ്ഞാപനം വെി, എല്ലാ സഹകരണ
സംഘങ്ങളിേും കബാര്‍മ്ഡുകളിേും രജിസ്പ്ൊറിടെ നിയപ്ന്തണത്തിന്‍പ കീെിേുളള മറ്
സ്ഥാപനങ്ങളികേയ്കും, ജൂനിയര്‍മ് ക്ലര്‍മ്കും അതിനു മുകളിടേ വിഭാഗങ്ങളിേുമുളള
തസ്തികകളികേയ്കുമുളള കനരിട്ടുളള എല്ലാ നിയമനങ്ങള്‍ക്കും കവണ്ി എെുത്തുപരീക്ഷ
നെത്തുന്നതിനായി ഒരു സഹകരണ പരീക്ഷാ കബാര്‍മ്ഡ് രൂപീകരികകണ്താണ്:

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 58 -->

58

എന്നാല്‍,

രജിസ്പ്ൊറിന്,

ഇത്തരം

സംഘങ്ങളുടെ

സാമ്പത്തിക

കേഷിയും

പ്പവര്‍മ്ത്തനക്ഷമതയും കണകിടേെുത്ത് ഏടതങ്കിേും സംഘടത്തകയാ സംഘങ്ങളുടെ
വിഭാഗടത്തകയാ നിര്‍മ്ണയികടപ്പെുന്ന പ്പകാരം ഈ ഉപവകുപ്പിടെ വേവസ്ഥയില്‍ നിന്നും
ഒെിവാകാവുന്നതാണ്.”.
49.

88-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 88-ാം വകുപ്പിടേ (1)-ാം

ഉപവകുപ്പിടെ (ഇ) ഖണ്ഡത്തിനു പകരം താടെപ്പറയുന്ന ഖണ്ഡം കെര്‍മ്കകണ്താണ്,
അതായത്:—
“(ഇ)

സര്‍മ്കിളില്‍

അധികാരിതയുളള

സഹകരണ

ആഡിറ്

അസിസ്റ്റെ്

ഡയറക്ടര്‍മ്, എക്സ് ഒഫ്റികഷോ;”.
50. 88ബി വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 88ബി വകുപ്പിടേ (iii)-ാം
ഖണ്ഡത്തില്‍, “ഒരു ആഫ്റീസടറ” എന്നീ വാകുകള്‍ക്കു കേഷം “അടല്ലങ്കില്‍ ഒരു
അഡ്മിനിസ്കപ്െറടറ

അടല്ലങ്കില്‍

മൂന്നില്‍

കുറയാത്ത

അംഗങ്ങളുള്ള

ഒരു

അഡ്മിനിസ്കപ്െറീവ് കമിറിടയ, അതില്‍ ഒരാള്‍ക് കൺവീനര്‍മ് ആയിരികകണ്തും” എന്നീ
വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
51. 89-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 89-ാം വകുപ്പിടേ (4)-ാം
ഉപവകുപ്പില്‍,—
(i) (ഡി) ഖണ്ഡത്തില്‍, “(സി) ഖണ്ഡപ്പകാരം” എന്ന വാകിനും അക്ഷരത്തിനും
പ്ബാകറിനും പകരം “(ബി) ഖണ്ഡപ്പകാരം” എന്ന വാകും അക്ഷരവും പ്ബാകറും
കെര്‍മ്കകണ്താണ്.
(ii) (ഇ) ഖണ്ഡത്തില്‍, “(ഡി) ഖണ്ഡപ്പകാരം” എന്ന വാകിനും അക്ഷരത്തിനും
പ്ബാകറിനും പകരം “(സി) ഖണ്ഡപ്പകാരം” എന്ന വാകും അക്ഷരവും പ്ബാകറും
കെര്‍മ്കകണ്താണ്.
(iii) (എഫ്റ്)

ഖണ്ഡത്തില്‍,

“(ഇ)

ഖണ്ഡപ്പകാരം”

എന്ന

വാകിനും

അക്ഷരത്തിനും പ്ബാകറിനും പകരം “(ഡി) ഖണ്ഡപ്പകാരം” എന്ന വാകും അക്ഷരവും
പ്ബാകറും കെര്‍മ്കകണ്താണ്.
52. 89ബി വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 89ബി വകുപ്പില്‍, ഖണ്ഡം
(iii)-ല്‍ “ഒരു ആഫ്റീസടറ” എന്നീ വാകുകള്‍ക്ക് പകരം “അഡീഷണല്‍ രജിസ്പ്ൊറുടെ

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 59 -->

59

പദവിയില്‍ കുറയാത്ത ഒരു ഓഫ്റീസടറ അടല്ലങ്കില്‍ ഒരു അഡ്മിനിസ്കപ്െറടറ അടല്ലങ്കില്‍
മൂന്ന് ആളുകള്‍ക് അെങ്ങുന്ന ഒരു അഡ്മിനിസ്കപ്െറീവ് കമിറിടയ, അതില്‍ ഒരാള്‍ക്
കൺവീനര്‍മ് ആയിരികകണ്തും” എന്നീ വാകുകള്‍ക് കെര്‍മ്കകണ്താണ്.
53. 91-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 91-ാം വകുപ്പിടേ (1)-ാം
ഉപവകുപ്പിടെ
മുന്‍പപായി

(സി)

ഖണ്ഡത്തില്‍,

“വിദോഭോസ

“സഹകരണതതവങ്ങടളയും”

സ്ഥാപനങ്ങള്‍ക്

സ്ഥാപികുകയും”

എന്ന

എന്നീ

വാകിനു
വാകുകള്‍ക്

കെര്‍മ്കകണ്താണ്.
54. 94-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 94-ാം വകുപ്പില്‍,—
(i) (2)-ാം ഉപവകുപ്പില്‍, “രണ്ായിരം” എന്ന വാകിന് പകരം “അയ്യായിരം” എന്ന
വാക് കെര്‍മ്കകണ്താണ്.
(ii) (3)-ാം ഉപവകുപ്പില്‍, “രണ്ായിരം” എന്ന വാകിന് പകരം “അയ്യായിരം”
എന്ന വാക് കെര്‍മ്കകണ്താണ്.
(iii) (4)-ാം ഉപവകുപ്പില്‍, “അയ്യായിരം” എന്ന വാകിന് പകരം “പതിനായിരം”
എന്ന വാക് കെര്‍മ്കകണ്താണ്.
(iv) (4എ) ഉപവകുപ്പില്‍, “അയ്യായിരം” എന്ന വാകിന് പകരം “പതിനായിരം”
എന്ന വാക് കെര്‍മ്കകണ്താണ്.
(v) (4ബി) ഉപവകുപ്പില്‍, “ആയിരം” എന്ന വാകിന് പകരം “അയ്യായിരം” എന്ന
വാക് കെര്‍മ്കകണ്താണ്.
(vi) (5)-ാം ഉപവകുപ്പിടേ (ബി) ഖണ്ഡത്തില്‍, “അയ്യായിരം” എന്ന വാകിന്
പകരം “പതിനായിരം” എന്ന വാക് കെര്‍മ്കകണ്താണ്.
(vii) (6)-ാം ഉപവകുപ്പില്‍, “അയ്യായിരം” എന്ന വാകിന് പകരം “പതിനായിരം”
എന്ന വാക് കെര്‍മ്കകണ്താണ്.
(viii) (7)-ാം ഉപവകുപ്പില്‍, “അയ്യായിരം” എന്ന വാകിന് പകരം “പതിനായിരം”
എന്ന വാക് കെര്‍മ്കകണ്താണ്.
(ix)

(7)-ാം

ഉപവകുപ്പിനു

കേഷം

കെര്‍മ്കകണ്താണ്, അതായത്:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

താടെപ്പറയുന്നവ

(7എ)

ഉപവകുപ്പായി

<!-- page 60 -->

60

“(7എ) ഏടതങ്കിേും സഹകരണ സംഘത്തിടെ െീഫ്റ് എക്സികേൂട്ടീകവാ
കമിറികയാ 59-ാം വകുപ്പ് (3)-ാം ഉപവകുപ്പിടേ വേവസ്ഥകള്‍ക് േംഘികുകയാടണങ്കില്‍
പതിനായിരം രൂപ വടരയാകാവുന്ന പിെേിക്ഷ നല്‍കി േിക്ഷികടപ്പൊവുന്നതാകുന്നു.”.
(x) 10-ാം ഉപവകുപ്പില്‍, “(6), (7)” എന്ന പ്ബാകറുകള്‍ക്കും അകങ്ങള്‍ക്കും
െിഹ്നത്തിനും പകരം “(6), (7), (7എ)” എന്ന പ്ബാകറുകളും അകങ്ങളും െിഹ്നങ്ങളും
അക്ഷരവും കെര്‍മ്കകണ്താണ്.
55. 95-ാം വകുപ്പിടെ കഭദഗതി.—പ്പധാന ആക്റിടേ 95-ാം വകുപ്പിടെ (4)-ാം
ഉപവകുപ്പില്‍, “(2), (3), (4), (5), (6), (7)” എന്നീ പ്ബാകറുകള്‍ക്കും അകങ്ങള്‍ക്കും
െിഹ്നങ്ങള്‍ക്കും പകരം “(2), (3), (4), (5), (6), (7), (7എ)” എന്നീ

പ്ബാകറുകളും

അകങ്ങളും െിഹ്നങ്ങളും അക്ഷരവും കെര്‍മ്കകണ്താണ്.
56. 106എ എന്ന പുതിയ വകുപ്പ് കെര്‍മ്കല്‍.—പ്പധാന ആക്റിടേ 106-ാം വകുപ്പിനു
കേഷം താടെപ്പറയുന്ന വകുപ്പ് കെര്‍മ്കകണ്താണ്, അതായത്:—
“106എ. മവഷമേങ്ങള്‍ക് നീകം ടെയ്യുന്നതിനുളള അധികാരം.—(1) 2023-ടേ
കകരള സഹകരണ സംഘ (കഭദഗതി) ആക്റ് പ്പകാരം കഭദഗതി വരുത്തിയ ആക്റിടേ
വേവസ്ഥകള്‍ക് നെപ്പിോകുന്നതിന് എടന്തങ്കിേും

മവഷമേങ്ങള്‍ക്

ഉണ്ാകുന്നപക്ഷം,

സംസ്ഥാന സര്‍മ്കാരിന്, ഔകദോഗിക ഗസറില്‍ പ്പസിദ്ധടപ്പെുത്തിയ ടപാതുവായകതാ
പ്പകതേകമായകതാ ആയ ഉത്തരവ് മുകഖന പ്പസ്തുത മവഷമേം നീകം ടെയ്യന്നതിന്
ആവേേടമകന്നാ യുക്തടമകന്നാ അതിന് കതാന്നുന്ന ഈ ആക്റിടേ വേവസ്ഥകള്‍ക്ക്
വിരുദ്ധമല്ലാത്ത തരത്തില്‍ വേവസ്ഥകള്‍ക് ഉണ്ാകാവുന്നതാണ്:
എന്നാല്‍, 2023-ടേ കകരള സഹകരണ സംഘ (കഭദഗതി) ആക്റിടെ പ്പാരംഭം
മുതല്‍ രണ്് വര്‍മ്ഷ കാോവധി അവസാനിച്ച കേഷം അങ്ങടനയുളള യാടതാരു ഉത്തരവും
പുറടപ്പെുവികുവാന്‍പ പാെുളളതല്ല.
(2) ഈ വകുപ്പിന്‍പ കീെില്‍

പുറടപ്പെുവികുന്ന ഏടതാരു

ഉത്തരവും

പുറടപ്പെുവിച്ചാല്‍ ഉെന്‍പ തടന്ന നിയമസഭ മുമ്പാടക വയ്കകണ്താണ്.”.
57. 1-ാം പട്ടികയുടെ കഭദഗതി.—പ്പധാന ആക്റിടെ 1-ാം പട്ടികയില്‍, പ്കമനമ്പര്‍മ്
15-നു കേഷം താടെപ്പറയുന്ന പ്കമനമ്പരുകളും ഉള്‍ക്കുറിപ്പുകളും കെര്‍മ്കകണ്താണ്,
അതായത്:—

This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/

<!-- page 61 -->

61

“16.

കകരള സംസ്ഥാന വനിതാ സഹകരണ ടഫ്റഡകറഷന്‍പ
േിമിറഡ് (വനിതാടഫ്റഡ്).

17.

കകരള

സംസ്ഥാന

സഹകരണ

െൂറിസം

ടഫ്റഡകറഷന്‍പ

േിമിറഡ്

സഹകരണ

ടഫ്റഡകറഷന്‍പ

േിമിറഡ്

(െൂര്‍മ്ടഫ്റഡ്).
18.

കകരള

സംസ്ഥാന

ടതാെില്‍

(കേബര്‍മ്ടഫ്റഡ്).
19.

കകരള

സംസ്ഥാന

സഹകരണ

കഹാസ്പിറല്‍

ടഫ്റഡകറഷന്‍പ

േിമിറഡ് (കഹാസ്പിറല്‍ടഫ്റഡ്).”.

(േരിത്തര്‍മ്ജമ)

രഹ്ന വി. എം.,

നിയമ വകുപ്പ് അഡീഷണല്‍ ടസപ്കട്ടറി.

____________________________________________________________________________________________________________________________
PUBLISHED BY THE SUPERINTENDENT OF GOVERNMENT PRESSES
AT THE GOVERNMENT CENTRAL PRESS, THIRUVANANTHAPURAM, 2024
This is a digitally signed Gazette.
Authenticity may be verified through https://compose.kerala.gov.in/
