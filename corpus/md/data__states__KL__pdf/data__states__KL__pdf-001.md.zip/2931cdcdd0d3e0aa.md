---
doc_id: "2931cdcdd0d3e0aa"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "02777b2c9844a8ed"
---

<!-- page 1 -->

*THE FOREST SETTLEMENT RULES, 1965
[Section 76(b)(c)]
Under Section 76(b)(c) of the Kerala Forest Act, 1961 (Act IV of 1962), the
Government of Kerala make the following rules to regulate the procedure of the Forest
Settlement Officers and Forest Officers.
RULES
1. These Rules may be called the Forest Settlement Rules, 1965.
2. Definition.- (a) The Act" means the Kerala Forest Act, 1961 (Act IV of 1962).
(b) "Form" means a form annexed to these rules.
3. After Government have published the notification under Section 4 of the Forest
Act, the map of the land which has been stamped with the Government seal, shall
be forwarded to the Forest Settlement Officer, who shall use that map and no
other throughout the settlement enquiry and resubmit the same to the Government
with his final report under Section 14 of Forest Act.
4. On the issue of the notification by the Government the Forest Settlement Officer
shall publish, as required by Section 6 of the Forest Act, a proclamation in the
Government Gazette, embodying the provisions of the section. The proclamation
shall be in the Form 'A' appended o these rules.
1

[5. The Forest Settlement Officer shall within sixty (60) days from the data of the
publication of the proclamation serve
notice in Form D on every known or reputed owner or occupier of any land
included in or adjoining the land proposed
to be constituted a Reserved Forest or on his recognised agent or manager after
obtaining lists of such owners or
occupiers from the Tahsildars of the Taluks concerned].
6. The Forest Settlement Officer, shall, as soon as possible, after the expiry of the
period prescribed in the proclamation issued under Section 6 of the Act, inspect
the proposed reserve and verify whether the map is drawn correctly. If any change
is found necessary he may record it separately. The services of the Divisional
Forest Officer shall be made available for such inspection:
Provided that where no claim or dispute as to the boundaries exists, the local
inspection by the Forest Settlement Officer may be dispensed with.
7. When claimants appear and verbally state the nature of their rights, the Forest
Settlement Officer shall record the substance of the statements and when
completed, shall be read over and if he admits it to be correct, shall be signed by

<!-- page 2 -->

him. Written statements specifying the nature of the rights claimed must be
prepared on stamped paper under the Kerala Court Fees Act.
8. The Forest Settlement Officer shall open a Register of Claims, in Form 'B'
appended, giving therein details as to the nature, extent, position, etc., of each
claim and the evidence adduced in support of such claim. A copy of the same
shall be furnished to the Forest Officer attending the enquiry to enable the latter to
prepare and submit his replies to the claims.
9. Claims on behalf of a family may be presented by any member of the family, on
behalf of a tribe or community, by any member of the tribe or community; on
behalf of joint claimants or pattadars, by any one of them; and on behalf of a kara,
by any man of that kara. In all these cases, notice of the claim shall be given by
the Forest Settlement Officer to the other members or persons jointly or severally
interested and they must be made parties if they wish.
10. The Forest Settlement Officer may, at any time, join any number of claims,
provided that they are all situated in the same proposed Reserve, in order to hold a
common enquiry, by reason of the same evidence being adduced or he may sever
any claims joined or jointly made in order to hold separate enquires at his
discretion. It shall not be necessary to take a second time evidence already
recorded in an enquiry relating to another claim, provided the parties are the same
or their representatives in interest. But, if, in deciding upon the claim of any
person, the Forest Settlement Officer admits previously recorded evidence or
documents, or recites a previous decision in disposing of a case, the person whose
claim is thus treated shall be entitled to obtain a copy of such previous evidence,
document or decision, as if it had been recorded during the enquiry into his own
claims.
11. When the subject of a claim is so vaguely or indefinitely described by a claimant
as not to be identifiable on the existing authenticated Revenue Survey maps, it
shall be open to the Forest Settlement Officer to call upon the claimant to produce
a map, showing the boundaries of the land claimed and the existing landmarks as
noted on the Revenue Survey maps. If the claimant is unable to procure a
professional surveyor for the purpose, the Forest Settlement Officer may appoint a
surveyor for the purpose provided the claimant deposits a sufficient sum of money
to cover the cost of the survey, including the remuneration for the surveyor.
12. Claimants may employ legal practitioners on their behalf. In such cases, the
Forest Settlement Officer shall require the production of the usual stamped
authority.
13. Copies of statements or o documents filed and of the decisions recorded by the
Forest Settlement Officer may be granted to claimant under the Rules regulating
the grant of copies in Civil cases. Such copies must be stamped under the Kerala
Court Fees Act.
14. The Forest Settlement Officer shall examine claimants and witnesses upon oath or
on solemn affirmation. Process fees, according to the scale laid down in the Code
of Civil Procedure, shall be required from claimants, if application is made to the
Forest Settlement Officer to compel the attendance of witnesses or production of
documents.

<!-- page 3 -->

15. The Forest Officer attending an enquiry shall have powers similar to those of a
defendant in a Civil Suit. He may crose-examine witnesses who support the
claims, amy produce evidence to rebut claims or to prove his case, and may
comment on any documents produced. He may peruse and take copies of any
documents or evidence and no court fees shall be required of him; and if he
desires to prefer an appeal against any decision, the Forest settlement Officer shall
give him a duly stamped and certified copy of such decision, meeting the cost
from the contingencies of the Forest Settlement Officer. The Forest Officer
attending an enquiry may employ a legal practitioner to assist him.
16. If the Forest Officer is unable to attend the enquiry before the Forest Settlement
Officer, he may forward to the latter any statement he may wish to make in
writing, with any document which he may wish to produce. The Forest Officer
may, in such cases, if he wishes, depute a subordinate not below the rank of a
Ranger to explain the statements and documents submitted by him.
17. The Forest Settlement Officer shall, at all times, gives the Forest Officer attending
the enquiry all reasonable information regarding the posting of claim for hearing,
and shall, as far as is convenient, meet the wishes of the Forest Officer in
adjourning enquiries, so as to give him time to consult higher officers in the
Forest Department or Collector through the Conservator of Forests.
18. The Forest Settlement Officer shall keep a diary of his proceedings from day to
day, which shall be clearly written up and shall be initialled by himself daily. The
claims on which he will have to adjudicate shall usually be of two classes:(1)
(2)
the Forest Act.

Claims to lands.
Claims to rights of the nature of easements, specified in Section 10 of

He shall record the evidence and decide on the claim in each case in the manner
prescribed by the Code of Civil Procedure for adoption in appealable cases. He will also
maintain, in addition to the Register in Form 'B' referred to in Rule 8 another Register in
Form 'C' appended, for all claims that are disposed of. A true copy of the register in Form
'C' shall be forwarded to the Government along with his report under Section 14 of forest
Act.
When a claim refers partly to a land and partly to any right specified in Section 10 of
Forest Act, the Forest Settlement Officer shall separate the claim into two parts and shall
enter them in his Register as distinct claims.
The description of claims admitted shall be clear and definite and shall give, in the case
of land, their survey numbers and sub-numbers, exact extent, names of claimants in
whose favour they are admitted and access thereto from outside the Reserve, In the case
of admitted rights of way, their lengths and widths, and direction in the Reserve points at
which they enter and leave it, and purpose for which they are admitted, i.e., whether for
men only, or for men and cattle, or for men, cattle and carts; shall be clearly stated.

<!-- page 4 -->

Similarly in respect of temples, the space admitted, and the seasons during which they are
visited, and the number of persons that usually gather for worship, shall be given.
In cases in which appeals are preferred against his decision, the Forest Settlement
Officer shall obtain copies of the appellate decisions which shall form part of the Forest
Settlement record. A brief abstract of each appellate judgment shall also be prepared and
entered in the appropriate column of the Register in Form 'C' reference being made in the
'Remarks' column to the number and data of such judgment.
19. When the Forest Settlement Officer has admitted a claim to lands, he shall
ascertain from the Forest Officer attending the enquiry, which course of those laid
down in Section 15 of the Forest Act it is desirable to follow, and he shall if
necessary, grant an adjournment, to enable the Forest Officer to consult the Chief
Conservator of Forests for submitting his reply. The Forest Settlement Officer
shall also hear the claimant whose claim has been admitted, before making his
report to the Government under Section 14 of the Forest Act.
20. The Forest Settlement Officer may correct verbal or clerical errors.
21. The Forest Officer may, with the previous sanction of the Government, move the
Forest Settlement Officer to exclude from his enquiry, claims to rights within any
portion of the proposed Reserve, when such portion is decided to be excluded
from final reservation and the Forest Settlement Officer may strike such claims
off his file.
22. It shall be the duty of the Forest Officer attending an enquiry before the Forest
Settlement Officer to take special care that all customary tights known or believed
to be enjoyed by any Forest Tribe, and important public rights of way in any of
the forests or lands in respect of which the enquiry is being held, are brought to
the notice of the Forest Settlement Officer, with a view to their being recorded
and admitted by him. Such rights and privileges shall be entered in the Registers
prescribed in Rules 8 and 18 as claims preferred on behalf of the public by the
Divisional Forest Officer.
23. On the completion of the Forest Settlement enquiry into all claims preferred, and
after disposal of all appeals if any, against the Forest Settlement Officer's
decisions, the Forest Settlement Officer shall forward to the Forest Officer a
detailed and complete list of claims he has admitted, together with the map of the
Reserve, showing thereon all admitted claims and any changes of boundary which
he may consider desirable. The map and the list of claims shall be signed by the
Forest Settlement Officer. The Forest Officer shall then sign and return the map,
for submission to the Government, with the report under Section 14 of the Forest
Act.
24. After the final orders of the Government in regard to the claims admitted by the
Forest Settlement Officer are passed under Sections 15, 16, 17 and 18 of the
Forest Act, the Chief conservator of Forests shall prepare and submit to the
Government a draft Notification under Section 19 of the Forest Act. The
boundary description therein given should refer to the following features:
(a) Surveyed and demarcated village boundaries and their marks;

<!-- page 5 -->

(b) Surveyed and demarcated field boundaries and Khandom marks;
(c) roads, paths, rivers, canals and railways;
(d) natural features, such as ridges or spurs of well-known hills, banks of rivers,
of streams, etc., and
(e) in the absence or other marks of features, forest boundaries and their marks,
such as cairns, giving
approximately the direction and distance from point to point or cairn to cairn.
The description of boundaries should start from the northwest corner and go round
the land along the northern, eastern, southern and western sides, in order. The list of
admitted claims which are finally treated as enclosures within the Reserved Forest should
be embodied in the Notification under Section 19 of the Forest Act at the foot of the
boundary description.
25. The original records of all Forest Settlement enquires shall be carefully sorted,
arranged, stitched and kept under seal in the District Collector's General Record
Room, but apart from other Records. A correct copy of the Settlement map of the
Reserve showing the boundaries notified under Section 4 of the Forest Act, the
final boundaries notified under Section 19 of the Forest Act and all rights
admitted during Settlement, duly signed by the Forest Settlement Officer, shall
form part of the Record.
26. When a notification under Section 19 of the Forest Act has been published in the
Gazette and the land becomes finally reserved the Chief Conservator of Forests
shall immediately take necessary steps in demarcating the boundaries of the land
permanently. The permanent marks of the boundary shall occupy the exact
positions of the temporary marks as finally notified under Section 19 of the Forest
Act. The boundaries shall be cleared to a width of 20 feet all round the reserve,
and permanent cairns shall be constructed at every point
27. The Chief Conservator of Forests shall send a true copy of the final map of the
Reserved Forest to the Survey Office for printing. He shall arrange with the
Survey Department to print the required number of copies of the map.
28. If the boundaries of the Reserved Forests are not surveyed by the Survey
Department, the Chief Conservator of Forests shall make arrangements with the
Survey Department to conduct a detailed Revenue Survey along the finally
notified boundary of the Reserved Forests.
APPENDIX
Form of Proclamation under Section 6 of the Forest Act referred to in Rule 4
FORM 'A'

<!-- page 6 -->

Whereas, by a notification published at page .................................................... of
the Kerala Government Gazette of the ..................................................... (here enter date)
it is proposed to form in to a Reserved Forest all the land comprised within the limits
specified in the schedule given below, it is hereby notified for general information that
during the interval between the date of this Proclamation and the date fixed by
Notification under Section 19 of the Act, hereafter to be published by the Government
declaring the said land to be Reserved Forest:(a) no new right shall be acquired in or over any of the lands included therein
except under a grant or contract in
writing made or entered into by or on behalf of the Government or on
behalf of some person in whom such
right or power to create the same was vested when this Proclamation is
published.
(b) no clearings shall be made for cultivation or any other purpose on the said
land, nor shall any person remove
any forest produce or set fire to such land or kindle or leave burning any
fire in such manner as to endanger
the same; and
(c) no patta shall be granted for any part of the said land;
(d) All persons, therefore, claiming any right in or over any of the said lands
or to any of the forest produce
thereof, are hereby required to state to the undersigned either personally
and orally or by written statement
within a period of six months from the date of publication of this
Proclamation in the Gazette, the exact
position or situation, extent and nature of the right claimed, specifying the
Revenue Survey numbers and
sub-numbers where such claims are for land, and to produce all the
documents in support of such claims,
which they possess.
(2) All rights in respect of which no claims are preferred within the period
specified above will, after the lands have been declared by Notification in the
Government Gazette under Section 19 of the Forest Act to be a "Reserved Forest",
become extinguished.
Forest Settlement Officer.
SCHEDULE
Name of the land
District

<!-- page 7 -->

Taluk
Village
Extent
Sy. No.
Boundaries
(Register referred to in Rule 8)
FORM 'B'
Register o claims to lands, rights to forest produce or easements in the
proposed........................................ reserved forest, as received.

Name of
claimant
Number
and his
residence

1

2

Nature
and
Date of
presentation extend of
claim
of claim
preferred

3

4

Brief
Divisional
statement
Forest
of ground
Officer's
for the
replies
claim

5

6

Brief
abstract
of
decisions,
if any, of
Remarks
Court of
final
appeal
and
settlement
7

8

(Register referred to in Rule 18)
FORM 'C'
Register of claims to lands, rights to forest produce or easements in the proposed
...................................................... reserved forest, as disposed of
Brief
Brief
Brief
abstract of Brief
summary summary decision abstract
Nature
of
of the
of the
and
and
Name Date of
evidence Forest
disposal decision,
Remarks
presentation extent of
Number of
adduced Officer's of claim if any, if
claim
claimant of claim
the
arguments by the
in
preferred
Court of
support and
Forest
of claim evidence Settlement appeal
Officer

<!-- page 8 -->

1

2

2

3

4

5

6

7

8

9

[From of notice to be issued after Proclamation under Section 6 of the Forest Act as
referred to in Rule 5
FORM 'D'

WHEREAS there is reason for the undersigned to believe that
you................................................ (here enter the name of the owner or person having
interest).............................................. are interested in the lands described in the
Proclamation published in the Gazette dated......................................... at
page........................................ of Part ...................................... Department
Sheet..................................... under Section 6 of the Kerala Forest Act, 1961 (Act 4 of
1962), notice is hereby given to you that on or
before...........................................................(here enter the date calculating the period
specified in the Proclamation) ................................................................ you should state
to the undersigned either personally and orally or by written statement, the exact position
or situation, extent ad nature of the right you claim, specifying the Revenue Survey
numbers and sub-division numbers where such claims are for land, and to produce all the
documents in support of such claims are for land, and to produce all the documents in
support of such claims which you possess;
(2) All rights in respect of which no claims are preferred within the period
within the period specified above will become extinguished on the issue of the
notification in the Government Gazette under Section 19 of the Kerala Forest Act, 1961
9Act 4 of 1962), declaring the land to be a Reserved Forest;
(3) During the interval between the date of the Proclamation and the date fixed
by the Notification under Section 19 of the above said Act hereafter to be published by
the Government, declaring the said land to be reserved forest,(a) no new rights shall be acquired in or over any of the lands included therein,
except under a grant or contract in
writing made or entered it by or on behalf of the Government or on behalf of
some person in whom such right or
power to create the same was vested when this Proclamation is published;
(b) no clearings shall be made for cultivation or any other purpose on the said
land, nor shall any person remove any
forest produce or set fire to such land or kindle or leave burning any fire in
such manner as to endanger the same;
and

<!-- page 9 -->

(d) no patta shall be granted for any part of the said land.
Station:
Date:
Forest Settlement Officer
