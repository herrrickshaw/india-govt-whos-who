---
doc_id: "6fcccc3048fbf2c5"
source_url: "https://keralaagriculture.gov.in/wp-content/uploads/2026/08/Etender.CRM_.pdf"
ministry: "Agriculture Development and Farmers Welfare Department, Keral"
title: "Click Here"
date: ""
pages: 4
method: "tesseract:mal+eng"
script: "LATIN"
needs_ocr: false
sha1: "9dc42576edc9b0b3"
---

<!-- page 1 -->

Agriculture Development & Farmers’ Welfare Department
ETENDER NOTICE
No. PT(1)104/2025/CRM-I/SN 21"August 2026
e-Tenders in single cover system are invited from competent dealers for
the Procurement of Certified Reference Material of Pesticides under the
scheme RKVY project for the Modernisation and Upgradation of the State
Pesticide Testing Laboratory to State Pesticide Testing Laboratory,
Parottukonam, Nalanchira P.O., Thiruvananthapuram, Kerala Pin-695015
of the Agriculture Development & Farmers’ Welfare Department. The
tender is to be submitted as e-tenders through https://etenders.kerala.gov.in.
2026_AGRI_866315_1
15,00,000/-
21.08.2026-02.00PM
Document sale end date 10.09.2026-05.00PM
Bid Submission start date 21.08.2026-02.00PM
Date & Time of opening of e- 14.09.2026-11.00AM
Tender
Cost 3 of e-Tender (online Rs.2300+ 18% GST
submission)
Date up to which the rates are to 31.05.2027
remain firm for acceptance
E.M.D. 1% of the PAC (through online
payment)
Security Deposit 5% of total contract amount
inclusive of E.M.D
Period of Supply | Within 30 days of receipt of supply
fore oh
SCHEDULE OF ITEMS TO BE SUPPLIED .
SL | Name of the item a Purity in
: ന : Required Remarks
No | with specification റ Percentage
(Approximate)
shown in the
approximate and
Carbosulfan 100mg may be
increased or :
Chlorantraniliprole 150mg decreased at the

<!-- page 2 -->

ee discretion of the
100m ae
Dinocap 100mg 295 minimum pack
Dion 295 availability of
| 8 | Fluopicolide 100mg fund.
ഇ
[റി
100%
Metals 200mg
Metalaxyl M 100mg
Mepiquat Chloride 100mg
Paclobutrazol 150mg
The quantity
18 | Profenophos 150mg shown in the
column 3 are
approximate and
19 fan ae 50mg >95 may be
ത്താ increased or
decreased at the
Propetamphos 100mg discretion of the
purchaser,
minimum pack
9 ; 5 size and
: fund.
Pyriproxyfen 100mg i
Sulfoxaflor 100mg ന
Tetraniliprole 100mg
; Accredited

<!-- page 3 -->

s (NABL/ISO:

*=IMPORTANT

The quantities shown in the column 3 are approximate and may be
increased at the discretion of the purchaser, subject to minimum pack size and
availability of fund.
I.General Requirements of Certified Reference Material of Pesticides
1. All reference materials supplied shall be Certified Reference Materials
(CRMs) traceable to SI units.
2. The CRMs shall be suitable for use in GC-FID and HPLC UV-Vis Detector
3. CRMs shall be required for Method validation, Routine sample analysis,
Calibration and quality control, Proficiency testing and internal quality checks.
II. Certification and Traceability
1. Each CRM shall be accompanied by a Certificate of Analysis (CoA) clearly
indicating Certified value / purity (%), Measurement uncertainty, Traceability
statement, Lot / batch number, Date of manufacture, Expiry or re-test date.
2. Electronic copies of CoA shall also be provided along with physical supply.
IIA. Certification and Traceability for SL. No.35; 36 & 37.
1. Each CRM shall be accompanied by a Certificate of Analysis (CoA) clearly
indicating Certified value / purity (%), Measurement uncertainty, Traceability
statement, Lot / batch number, Date of manufacture, Expiry or re-test date.
2. CRMs shall be produced by manufacturers aceredited to NABL/ISO 17034
or equivalent internationally accepted standard.
3. The certificate shall explicitly state compliance with NABL191 /ISO Guide
31 /150 17034.
4. Electronic copies of CoA shall also be provided along with physical supply.
ILI. Purity and Quality Specifications
1. Minimum purity of pesticide CRMs shall be = 95%, unless otherwise specified
for specific compounds.
2. Higher purity grades (> 98—99.5%) shall be preferred where available.
3. The uncertainty shall be clearly stated and acceptable for regulatory analysis.
4. CRMs shall be suitable for formulation analysis as per BIS/CIB&RC
specifications.
IV. Packaging and Quantity
1. CRMs shall be supplied in small analytical packs (typically 25 mg, 50 mg,
100 mg or equivalent).
2. Packaging shall be Airtight, Tamper-proof, Chemically compatible. ;
3. Each container shall be clearly labelled with Name of CRM, Lot number,
Purity, Storage conditions, Expiry / re-test date

<!-- page 4 -->

V. Shelf Life
1. At the time of supply, CRMs shall have the total shelf life is > 75% residual
shelf life.
2. CRMs nearing expiry shall not be supplied and will be rejected without any
negotiation.
VI. Storage and Transport
1. CRMs shall be transported under appropriate temperature-controlled
conditions, wherever required.
2. Suppliers shall ensure compliance with Manufacturer’s storage
recommendations, Safety and transport regulations
3. Any damage or deterioration during transit shall be the responsibility of the
supplier.
CERS On =
ta SO നി
OY 3 [ലി
* Se 5 Deputy Director of Agricultur
3 യ a} Cum or Chemist (I/c)
a Loy Deputy Director of Agriculture
OTIS Cum Senior Chemist
State Pesticide Testing Labomtory
Parottukonam, Nalanchira P.O,
Thiruvananthapurar-695015
