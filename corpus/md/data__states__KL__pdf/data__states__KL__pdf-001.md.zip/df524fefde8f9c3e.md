---
doc_id: "df524fefde8f9c3e"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4347b2445f059393"
---

<!-- page 1 -->

IN THE HIGH COURT OF KERALA AT ERNAKULAM
PRESENT
THE HONOURABLE MR. JUSTICE RAJA VIJAYARAGHAVAN V
TUESDAY, THE 30TH DAY OF JANUARY 2024 / 10TH MAGHA, 1945
WP(C) NO. 2752 OF 2024
PETITIONER:
BIJU PRASAD C
AGED 54 YEARS
S/O CHELLAPPAN PILLAI, AROMAL BHAVAN, THONDIYARA,
EROOR P.O, PUNALUR, KOLLAM., PIN - 691312
BY ADVS.
VISHNU BHUVANENDRAN
C.P.SABARI
B.ANUSREE
ABHILASH C.V.
VARUN JACOB
MIRAL K.JOY
RESPONDENTS:
1

STATE CO-OPERATIVE ELECTION COMMISSION
REPRESENTED BY STATE CHIEF CO-OPERATIVE ELECTION
COMMISSIONER, 3RD FLOOR, CO-BANK TOWERS, PALAYAM,
VIKAS BHAVAN P.O, THIRUVANANTHAPURAM., PIN - 695033

2

RETURNING OFFICER TO EROOR KSHEEROLPADAKA SAHAKARANA
SANGHAM- LTD
NO. Q. 32 (D) APCOS, DAIRY FARM INSPECTOR (A UNIT),
ANCHAL, OFFICE OF THE DAIRY EXTENSION SERVICE UNIT,
BLOCK PANCHAYATH BUILDING, ANCHAL P.O. KOLLAM.,
PIN - 691306

3

EROOR KSHEEROLPADAKA SAHAKARANA SANGHAM- LTD
NO. Q. 32 (D) APCOS, ALANCHERY, EROOR P.O.,
REPRESENTED BY ITS SECRETARY, PIN - 691312

<!-- page 2 -->

W.P.(C).2752 of 2024

2

SRI. P C SASIDHARAN, SC FOR EROOR KSHEEROLPADAKA
SAHAKARANA SANGHAM,
SRI. C M NAZAR, SC FOR STATE CO-OPERATIVE ELECTION
COMMISSION,
SRI A. S DHEERAJ, GOVERNMENT PLEADER

THIS WRIT PETITION (CIVIL) HAVING COME UP FOR ADMISSION ON
30.01.2024, THE COURT ON THE SAME DAY DELIVERED THE FOLLOWING:

<!-- page 3 -->

W.P.(C).2752 of 2024

3

JUDGMENT

The petitioner is a member of the Eroor Ksheerolpadaka Sahakarana
Sangham, the 3rd respondent herein. He contends that the election to the
Society is scheduled to be held on 3.2.2024. The nomination submitted by him
to stand for the election has been rejected on the ground that the petitioner,
while serving as a committee member of the society for the previous turn, had
earned a sitting fee at a rate beyond the prescribed rate for the same and the
petitioner is in default to the society.
2.

The petitioner contends that to acquire disqualification under Rule

44(1)(c)(i) of the Co-operative Societies Rules, the member should be in default
to the society or to any other society in respect of any loan or loans taken by
him or loan in which he had stood surety, for such period, as is prescribed in
the bye-laws of the society concerned or in any case for a period exceeding
three months or is a defaulter to the society or to any other society. In order to
be a defaulter, as defined under Rule 2(e) of the Rules, a decree has to be
passed against him. None of the above conditions are satisfied in so far as the
petitioner is concerned, and therefore, the rejection of the nomination is

<!-- page 4 -->

W.P.(C).2752 of 2024

4

improper, contends the petitioner. It is further contended that he has not been
informed of any such dues to enable him to make repayment. It is on these
assertions that this writ petition is filed seeking the following reliefs:
i). Declare that the rejection of nomination paper submitted by the
petitioner as per Ext. P1 notification, by the second respondent is
illegal, arbitrary and liable to be interfered with.
ii) Issue a Writ of Mandamus, any appropriate Writ order or direction to
the competent among the first and second respondents to accept the
nomination paper submitted by the petitioner to contest in the
election to the Committee of the third respondent society and include
the petitioner also in the final list of candidates by supplementation
and permit him to contest in the elections scheduled as per Ext. P1 on
3.2.2024.

3.

A counter affidavit has been filed on behalf of the 3rd respondent.

It is stated that the petitioner was an elected member and President of the
Managing Committee of the society for the period from 2009-2014 and from
2014-2019. During this period, the petitioner has committed financial
irregularity in the society, which includes excess drawal of honorarium. It is
stated that in terms of a resolution, Exhibit R3(a) notice was issued to the
Petitioner on 2/10/2018, directing him to repay the amount due to society. In
the audit report dated 3/11/2018 for the financial year 2017-2018, the
statutory auditor has noted an audit objection of excess drawal of a sum of

<!-- page 5 -->

W.P.(C).2752 of 2024

5

Rs.8800/-, as is evident from Ext. R3(b). The audit Certificate for the
subsequent financial year also notes the excess drawal on the part of the
Petitioner. It is further stated that the Deputy Director of Dairy Development
has issued Exhibit R3 (d) proceedings observing that the sum of Rs.17026/- is
to be recovered from the petitioner, who was the president of the society at the
relevant point of time. Finally, he was served with Ext.R3(e) notice on 5/4/2021
to recoup the amount payable by him. It is stated that the petitioner has not
remitted the amounts till now.
4.

It is further stated that under rule 44(1)(j) of the Co-operative

Societies Rules, no member of the society is entitled to be elected or appointed
as a member of the committee if he is disqualified under any of the provisions
of the bye-laws. It is stated that as per clause 5(2) of the bye-laws of the
Society, the member should not be in default of any amounts due to the
society. It is also stated that rejection of nomination is an election dispute, and
it is for the petitioner to approach the jurisdictional authority under Rule 69 of
the Co-operative Societies Rules.
5.

I have considered the submissions advanced.

6.

The contention of the petitioner is based on Rule 44(1)(c)(i) of the

Co-operative Societies Rules. He contends that he is neither a defaulter nor is

<!-- page 6 -->

W.P.(C).2752 of 2024

6

in default to the Society or to any other society in respect of any loan or loans
taken by him or loan in which he had stood surety, for such period, as is
prescribed in the bye-laws of the society concerned or in any case for a period
exceeding three months or is a defaulter to the society or to any other society.
For reasons best known to the petitioner, he has not chosen to produce the
byelaws of the Society. Clause 5.2 of the bylaws reads as under.

5.2

താഴെ

പറയുന്ന

യോഗ്യതകളുള്ള

അംഗംകൾക്കു

മാത്രമേ

ഭരണസമിതിയിലെ

അംഗങ്ങളായി

തെരഞ്ഞെടുക്കപ്പെടാനും തുടരാനും അവകാശം ഉണ്ടായിരിക്കുകയുള്ളൂ.

(i)

അയാളിൽ

നിന്നും

സംഘത്തിനുകിട്ടേണ്ടതും

അവധികഴിഞ്ഞതുമായ

ഏതെങ്കിലും

തുകയെ

സംബന്ധിച്ചിടത്തോളം അയാൾ വീഴ്ചവരുത്തിയിട്ടില്ലാതിരിക്കുക.

xxxx

(xi)

xxxx

xxxxx

കേരള സഹകരണ സംഘം ആക്ടിലും ചട്ടങ്ങളിലും തെരഞ്ഞെടുപ്പ് ചട്ടങ്ങളിലും ഈ നിയമാവലിയിലും
ഭരണസമിതിയിലേക്ക്

തെരഞ്ഞെടുക്കപ്പെടുന്നതിന്

കല്പിച്ചിട്ടുള്ള

അയോഗ്യതകളൊന്നും

തന്നെ

അയാൾക്കില്ലാതിരിക്കുക.

7.

The bye-laws clearly state that only persons who have not

acquired any default under the said provision are entitled to be elected as a
member of the committee and to continue as such.

<!-- page 7 -->

W.P.(C).2752 of 2024

8.

7

Exts.R3(a) to (d) clearly discloses that in terms of the resolutions

issued, communications have been issued to the petitioner calling upon him to
make payment of the amounts due to the Society from the petitioner. The
petitioner has no case that the said amount has been paid.
9.

Furthermore, under Rule 44(1)(j), no member of the society shall

be eligible to be elected or appointed as a member of the committee of the
society under S.28 if he is disqualified under any other provisions in the
bye-laws of the society. In the case on hand, the petitioner has in fact acquired
default in terms of the bye-laws.

In that view of the matter, the petitioner is

not entitled to any of the reliefs sought.
This writ petition is dismissed, reserving the right of the petitioner to
exhaust his statutory remedies.
Sd/RAJA VIJAYARAGHAVAN V,
JUDGE
IAP

<!-- page 8 -->

W.P.(C).2752 of 2024

8

APPENDIX OF WP(C) 2752/2024
PETITIONER’S EXHIBITS:
Exhibit P1

TRUE COPY OF THE ELECTION NOTIFICATION
DATED 21.12.2023 PUBLISHED BY THE STATE
CO-OPERATIVE ELECTION COMMISSION.

Exhibit P2

TRUE COPY OF THE ACKNOWLEDGEMENT RECEIPT
DATED 17.01.2024 FOR ACCEPTANCE OF FEES FOR
NOMINATION PAPER OF THE PETITIONER.

Exhibit P3

TRUE COPY OF THE DECISION IN SUKUMARAN NAIR
K. N. V. RETURNING OFFICER TO IDUKKI
DISTRICT EX-SERVICEMEN EMPLOYEES
CO-OPERATIVE SOCIETY LTD. REPORTED IN 2013
KHC 3318.

Exhibit P4

TRUE COPY OF THE LIST OF CANDIDATES WHO
HAVE SUBMITTED VALID NOMINATIONS, AS
PUBLISHED BY THE RETURNING OFFICER ON
18.01.2024.

Exhibit P5

TRUE COPY OF THE INSPECTION REPORT DATED
18.07.2020 ISSUED BY THE SENIOR DAIRY
EXTENSION OFFICER, ANCHAL BLOCK, DAIRY
DEVELOPMENT TO THE SOCIETY.

Exhibit P6

TRUE COPY OF THE LETTER DATED 04.04.2023
ISSUED BY THE JOINT DIRECTOR OF DAIRY
DEVELOPMENT DEPARTMENT, THIRUVANANTHAPURAM
TO THE PETITIONER.

Exhibit P7

TRUE COPY OF THE BYLAWS OF THE EROOR
KSHEEROLPADAKA SAHAKARANA SANGHAM LTD NO.
Q.32(D) APCOS.

<!-- page 9 -->

W.P.(C).2752 of 2024

9

RESPONDENTS’ EXHIBITS:
EXHIBIT R3(a)

The true copy of the notice dated 2/10/2018
with copy of the acknowledgement card
evidencing receipt of the registered post

EXHIBIT R3(b)

The true copy of the note in the audit
objection of the statutory auditor dated
3.11.2018

EXHIBIT R3(c)

The true copy of the note in the audit
objection of the statutory auditor dated
25.10.2021

Exhibit R3(d)

The true copy of the proceedings of the
Deputy Director of Dairy Development dated
29/03/2021

EXHIBIT R3(e)

The true copy of the notice dated 5/4/2021
