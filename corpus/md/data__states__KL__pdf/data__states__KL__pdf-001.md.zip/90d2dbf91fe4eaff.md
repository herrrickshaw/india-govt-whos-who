---
doc_id: "90d2dbf91fe4eaff"
source_url: ""
ministry: ""
title: ""
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "373129b56cbd274e"
---

<!-- page 1 -->

ADFW/474/2026-TG4

I/510288/2026

Directorate of Agriculture Development and Farmers’ Welfare
Vikas Bhavan, Thiruvananthapuram – 695033
e-mail:cru.agridir@kerala.gov.in, Phone: 0471-2304481
No:ADFW/474/2026-TG4/S
Date:15-01-2026
E Tender No :2026_AGRI_827962_1
NOTICE INVITING TENDER
1. Background
The Agriculture Development and Farmers' Welfare Department,
Government of Kerala, invites online bids (e-Tenders) from empaneled
agencies/firms of Information & Public Relations Department / Farm
Information Bureau/Department of Tourism for providing temporary
infrastructure facilities, electrification works, publicity arrangements,
Transportation, Food and accommodation and related all services for
VAIGA 2026, a premier agricultural exhibition, seminar, and cultural event
aimed at promoting agricultural innovations, farmer welfare, post harvest
technology and sustainable development. The event is scheduled at the
World Market Compound, Anayara, Thiruvananthapuram, for a duration of 5
days in February 2026 (exact dates to be confirmed).
This event is sanctioned vide Government Orders: GO (Rt) No.
528/2025/AGRI dated 31/05/2025, GO (Rt) No. 764/2025/AGRI dated
29/07/2025, decisions from the meeting convened by the Hon'ble Minister
for Agriculture on 18/09/2025 & 14/01/2026, and letter No. AGRIEB2/118/2025-AGRI dated 27/12/2025.
The works include site preparation, pandals, stalls, stages, electrification,
sound and lighting, publicity, food arrangements, transportation,
accommodation, cultural program, documentation, and other all ancillary
services.
Bids must be submitted
https://etenders.kerala.gov.in.

through

the

Kerala

e-Tender

portal:

2. Objective
To engage qualified and experienced agencies/firms for the timely provision

<!-- page 2 -->

ADFW/474/2026-TG4

I/510288/2026

of high quality temporary infrastructure and services for VAIGA 2026,
ensuring smooth execution, operation for 5 days, and dismantling/removal
from the site. The selected agency must comply with all statutory
requirements, safety standards, and departmental directions.
3. Scope of Work
The scope is divided into main categories: Infrastructure Facilities,
Electrification Works, Publicity, Event Coordination, Cultural Program,
Food Arrangements, Transportation, Accommodation, Documentation, and
Miscellaneous. All works must be temporary, suitable for the site, and
include site clearance, installation, operation, and dismantling. Detailed
specifications are based on the attached Bill of Quantity (BoQ) and
requirements outlined below. Quantities are tentative; payment will be based
on actual measurements/certification.
3.1 Event Coordination
Prepare an execution plan, coordinate with the organizing committee,
and ensure smooth conduct of all activities.
Prepare a detailed work schedule and deployment chart for manpower
and technical teams.
Liaisoning and license coordination for permissions from government
departments (e.g., electrical inspection, fire safety etc).
Artist management and coordination for cultural programs.
3.2 Venue & Stage Arrangements (Infrastructure Facilities - General
Civil Work)
Site preparation, clearing and levelling
German hanger structures (AC and Non-AC), Exhibition pavilions
seminar halls, VIP rooms, Stage, Auditorium, food court,
Sheet pandals, AC sheet pandals and raised platforms
Temporary stages, ramps, skirting, carpets and console masking
Fabrication and installation of approximately 250 exhibition stalls using
prefab octanorm system with furniture and electrical points
Pagodas, theme pavilion, ticket counters and nursery area
Seating arrangements, VIP furniture, fire extinguishers, E-toilets, water
tanks and drinking water dispensers

<!-- page 3 -->

ADFW/474/2026-TG4

I/510288/2026

Housekeeping, waste management, barricading and security
3.3 Electrification, LED & Technical Systems
Internal and external lighting, decorative illumination and power
distribution
Air-conditioning, air coolers, fans and ventilation
DG sets with sufficient capacity and diesel for uninterrupted power
supply
Professional sound systems, microphones and stage lighting
High-resolution LED walls (indoor and outdoor) with live feed
capability
CCTV surveillance and internet connectivity for live streaming
Internet Facility: For streaming on Facebook and YouTube live.
Professional PA system with wired, wireless, lapel microphones; digital
mixer, stage lighting including front wash lights, spotlights, decorative
effect lighting; adequate power backup.
3.4 Exhibition & Branding
Stall fabrication and layout execution
Floral décor, landscaping and aesthetic arrangements
Branding elements including flex boards, arches, standees, banners and
way-finding signage
Designing, fabrication and installation of professionally themed selfie
points at various strategic locations within the event venue, suitable for
public interaction and branding.
3.5 Cultural Programmes
Coordination with artists, performers, costumes and logistics.
Cultural performances and compering.
3.6 Food & Catering Arrangements
Lunch , Dinner, VIP Food, refreshment and snacks
Provision of crockery, cutlery, serving counters, handwash stations, and
drinking water arrangements.
Food court setup with seating, wash counters and waste disposal
Catering through FSSAI-licensed agencies under hygienic conditions

<!-- page 4 -->

ADFW/474/2026-TG4

I/510288/2026

3.7 Publicity, Media & Documentation
Design, printing and distribution of publicity materials
Social media promotion, teaser videos and live streaming
Photography, videography and preparation of event documentation
3.8 Transportation & Accommodation
Provide a well-maintained fleet comprising SUVs, Sedans, and
Traveller vans for the comfortable and timely transportation of VIP
guests, government officials, and invited artists.
Vehicles should be air-conditioned, clean, and equipped with
professional drivers familiar with local routes and event logistics.
Ensure round-the-clock availability of vehicles during the event period,
including provision for standby vehicles in case of breakdowns
Arrange pickup and drop facilities from airports, railway stations,
hotels, and event venues as per the approved movement plan
All fuel, toll, parking, and driver allowance costs shall be included in
the quoted rate.
Provision of vehicles for dignitaries, officials,VIPs and artists
Arrangement of accommodation in approved hotels with liaison
support.
Provision for early check-in and late check-out to accommodate varying
travel schedules.
Hotels must maintain high standards of cleanliness, safety, and service
quality, with dedicated liaison support to handle guest requirements.
3.9 Green Protocol & Environmental Sustainability Clause
The entire event VAIGA 2026 shall be conducted strictly in compliance
with the Green Protocol adopted by the Government of Kerala and as
per the directions issued from time to time by the State Government,
Suchitwa Mission, Local Self Government Department and other
competent authorities.
The selected agency shall ensure zero-use of single-use plastics
including flex banners with plastic backing, plastic bottles, disposable
cups, plates, straws, cutlery, carry bags and other non-biodegradable
materials within the event venue.
Eco-friendly and reusable materials such as cloth banners,
biodegradable plates and cups, steel/glass water dispensers, paper-based

<!-- page 5 -->

ADFW/474/2026-TG4

I/510288/2026

signage and sustainable décor materials shall be used wherever
applicable.
A comprehensive waste management system shall be implemented,
including:
Segregation of waste at source into biodegradable, recyclable and
non-recyclable waste
Adequate provision of colour-coded bins at strategic locations
Daily collection, transportation and scientific disposal of waste in
coordination with Suchitwa Mission / Local Body
Drinking water shall be provided through dispensers and refill stations.
Use of packaged plastic water bottles is strictly prohibited, except
where specifically permitted by the Department for VVIP protocol.
Food courts and catering arrangements shall follow green catering
practices, including use of reusable or biodegradable serving materials
and avoidance of food wastage. Leftover food, if any, shall be disposed
of responsibly through authorised agencies.
The agency shall nominate a Green Protocol Coordinator responsible
for implementation, monitoring and compliance of all Green Protocol
measures throughout the event period, including setup and dismantling
stages.
All materials must be high-quality, weather-resistant, and compliant with
directions. The agency is responsible for quality, safety, and timely
execution.
4. Eligibility Criteria
Agencies empaneled with the Information & Public Relations
Department / Farm Information Bureau/Department of Tourism,
Government of Kerala.
Minimum 3 years of experience in conducting similar large-scale events
(e.g., exhibitions, cultural programs).
The firm/agency should submit valid registrations certificate, GST
Number and PAN.
No blacklisting (affidavit required).
5. Tender Details
Name of Work: Providing Infrastructure and Related Services for

<!-- page 6 -->

ADFW/474/2026-TG4

I/510288/2026

VAIGA

2026

at

World

Market

Compound,

Anayara,

Thiruvananthapuram.
Earnest

Money

Deposit

(EMD):

Rs.

1,00,000/-

(online

payment/refundable).
Tender Fee: Rs. 7,500/- + 18% GST (non-refundable, online).
Period of Completion: Infrastructure works to be completed 2 days
before event, operation for 5 days, dismantling within 2 days post-event.
Bid Security: 5 % of Quoted amount.
Pre-Bid Meeting: January 20, 2026, at 11:00 AM, in Room No.203,
State Agricultural Engineer, Directorate of Agriculture, Vikas Bhavan,
Thiruvananthapuram.
Last Date & Time for Submission: January 27, 2026, 11:00 AM IST
(online via etenders.kerala.gov.in).
Date & Time of Opening (Technical Bid): January 27, 2026, 15:00
PM.
Date & Time of Opening (Financial Bid): To be notified to qualified
bidders.
6. Submission of Bids
Bids to be submitted online in two covers: Technical Bid (eligibility
documents, Empanelment order from concerned authority experience
certificates, Audited Annual Turnover Sheet of last 3 years,GST,PAN ,
Registration documents work schedule, affidavit) and Financial Bid
(item- rates based on attached BoQ, inclusive of all taxes/charges).
All prices in INR, inclusive of taxes, duties, levies, service charges,
manpower, materials, loading and unloading, transport, incidentals etc
complete.
Upload scanned copies of documents; originals to be produced on
demand.
Quantities tentative; final payment on actual basis.

<!-- page 7 -->

ADFW/474/2026-TG4

I/510288/2026

7. Other Conditions
The Director reserves the right to accept/reject any/all bids, or order
full/part quantity, without reasons.
The successful bidder shall, on receipt of the Work Order, execute an
Agreement with the Directorate of Agriculture in the prescribed format
on Kerala Government non-judicial stamp paper worth ₹200/- and shall
also furnish a Security Deposit equivalent to five percent (5%) of the
total contract value.
The Security Deposit shall be drawn in favour of the Director of
Agriculture, Directorate of Agriculture Development and Farmers’
Welfare, of which fifty percent (50%) of the Security Deposit amount
shall be remitted as Treasury Deposit, in accordance with Government
rules in force.
Selected agency must execute works as per directions, within timeline.
Payment after successful completion, bill submission, satisfactory
reports.
Agency responsible for damage to property (rectify at own cost).
Comply with labor laws, GST, safety regulations.
Disputes subject to Thiruvananthapuram jurisdiction.
For queries: Shri. Raj Mohan C K, State Agricultural Engineer Phone: +91471-2306748, 9383470065/9383470068 Email: saekerala@gmail.com,
cru.agridir@kerala.gov.in
Dr Sriram Venkitaraman IAS
DIRECTOR
