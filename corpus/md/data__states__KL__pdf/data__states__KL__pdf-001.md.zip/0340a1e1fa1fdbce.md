---
doc_id: "0340a1e1fa1fdbce"
source_url: "https://keralaagriculture.gov.in/wp-content/uploads/2026/09/Etender-Chemical-FQCL.pdf"
ministry: "Agriculture Development and Farmers Welfare Department, Keral"
title: "Click Here"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9548a4a5fc9b996a"
---

<!-- page 1 -->

rxpdf.nhr Lrbomroda :026 27 h ren iE Qu'ri! cmrrcr
Depdnd,ftelendn

cor or e-Ilnder (o hc
r

r. ofrhe PAc (hrcugh onrine

wilhitr30dl}sofrceiplofsnppl}

s.H.Dr r.E oF rr[!]ll!lt!l!

tMI]

<!-- page 2 -->

<!-- page 3 -->

']gr'el.i''0dqufutaid

"'ft[,k
