---
doc_id: "36658e7afe9fcdda"
source_url: "https://finance.kerala.gov.in/includeWeb/fileViewer.jsp?dNm=csfc!13!13-Memorandum.pdf"
ministry: "Finance Department, Kerala"
title: "Memorandum"
date: ""
pages: 73
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3089b7520ffa2ebf"
---

<!-- page 1 -->

1
Chapter 1
INTRODUCTION

1.1

The Thirteenth Finance Commission has the unique opportunity to review and draw inferences

from nearly six decades of federalism in public finance management of the nation. Based on such
inferences, a much needed course correction can be initiated, reversing a trend that has been eroding
the very concept of fiscal federalism. Government of Kerala would earnestly plead for such a focus in
the work of this Commission.
1.2

Articles of the Constitution between 268 and 275 have designed a well-structured system

whereby States get benefit from the Centre’s taxation power.

The purpose is clear from the wording

of Article 275 which is the final residual Article in this structure. Aid to the revenues of States is what
the makers of Constitution had in mind.

This really gives Finance Commission the authority to deal

with the entire area where States’ revenues are applied – not just one part like non-plan revenue
account expenditure.

But Commissions chose to confine themselves to that area (with only one

exception in recent times – Second report of the Ninth Finance Commission covering the period 199095).

Over the years, somehow it came to be accepted that Finance Commissions’ main task is to try

and balance the non-plan revenue account of Stat es.
1.3

Whenever Commissions chose (or were asked) to look into other aspects, it was either for

providing supplementary provisions for developmental expenditure (like special problem grants) or
admonish States and guide them out of what was perceived to be their fiscal imprudence.

The

administration of such condition based grants and debt relief schemes was entrusted with Central
Government Ministries.
1.4

All this led to the dilution of Finance Commission’s stature as the only body created by the

Constitution for assessing Centre’s and States’ needs comprehensively and evenhandedly.

The

transformation in its role tended to convert the Finance Commission, in some respects at least, into an
extension of the Central Government.

1.5

The terms of reference of the Thirteenth Finance Commission contain a further indication of

this.

The Commission has been authorised to look into plan expenditure commitments of the Central

Government.

Even some off budget commitments have been included in the purview of this part of

<!-- page 2 -->

2
the terms of reference.

The implication is that the quantum of revenue transfer to States should be

only out of what is left after Centre meets all such types of expenditure.

This seems to convey a

subtle hint that the present level of transfer should continue or even be curtailed and that any
increase is unacceptable.
1.6

Despite this ‘not too States friendly’ approach, Government of Kerala feels that this addition

to the terms of reference can be converted into an opportunity – an opportunity to restore the
Constitutional role of Finance Commission and do equal justice to Centre and States and also among
States. That is why we consider that the Thirteenth Finance Commission has a unique opportunity.
1.7

If the Commission is to look into plan expenditure of the Centre, in fairness, similar needs of

States should also be looked into.
requirements of each State.

Admittedly it is not practicable for the Commission to asses such

But it is possible to make an overall assessment of the funds needed for

at least the present level of plan expenditure and reasonable growth.

When that is done for both

States and Centre, the result may indicate that the aggregate of all plan and non-plan requirements of
States and Centre may add up to a dimension that cannot be handled by total revenue receipts of
Centre and States and even a reasonable level of borrowing.

There will be the further complication

that some States have surpluses which obviously cannot be used by others and so the real total
requirement will be even more than the simple aggregate.

This means that there is need for

optimising total expenditure and a rational approach to assessment of funds to be allocated to States.
Whether all the current level commitments are unavoidable, is there a transgression of areas between
Centre and States, what would be a fair arrangement for restricting Centre and States to their
Constitutional domain, how could States with good track record in improving quality of life be
rewarded and encouraged while doing justice to States which have fallen behind etc. are issues which
will have to be examined by the Finance Commission.
1.8

The recommendations submitted to the Commission in this memorandum have been designed

on this basis.

Before proceeding to present them, we would like to trace briefly the evolution of the

trend eroding fiscal federalism in the last few decades. We have attempted that in the next chapter.
Our idea is to identify the areas, which, in our perception, need intervention and correction by the
Finance Commission.

<!-- page 3 -->

3

<!-- page 4 -->

4
Chapter 2
DECLINE OF FISCAL FEDERALISM

2.1

Allocation of duties and responsibilities between States and Centre is based on a simple

principle.

Each responsibility is assigned to that level – Centre or State – where it can be discharged

more efficiently in public interest. Same is the principle in allocation of revenue raising powers. Each
item of taxation is entrusted with that level where it can be more efficiently and optimally levied and
collected.

Obviously in such an arrangement it is not possible to ensure that the two levels – Centre

and States – get exactly the same revenue as is necessary to discharge the responsibilities assigned to
them.

This apparent mismatch is adequately addressed in the Constitution.

Articles 268 and 269 lay

down how States can directly get the benefit of some of the taxation powers of the Centre, on a
continuing basis.

Article 270 (originally Articles 270 and 272) gives the benefit of Centre’s taxation to

States by passing on to them a prescribed share of the revenues raised. In respect of States which are,
even after receiving the benefit of these Articles, in need of further aid to their revenues, Article 275
provides such aid.

As there are both a value judgment and a quantum judgment involved in the

application of Articles 270 and 275, Constitution provides for a body of eminent experts who will make
that judgment every five years.

Once it is done, Centre and States can settle to their respective

domains and, in full cooperation with each other, adequately finance and efficiently administer their
respective levels of governance.

2.2

This excellent structure contained in Articles between 268 and 281, in its pure and undiluted

form, ensures that there is no need for States to approach Centre with repeated pleas for funds. Nor
would the Centre have the resources to respond to such pleas and condescendingly hand out funds.
Only extreme situations like devastation by massive floods, earthquakes etc. would have warranted
any other channel of providing help to affected States.
2.3

Almost as soon as this Constitutional order was put in place, deviations started taking shape.

With the advent of national planning, a new channel of funding was opened. Whether, in the context
of planning, it was necessary to equip the Planning Commission with funds to be given to States was
not seriously considered. It was assumed to be necessary. In fact, the Planning Commission would be
effective as an expert body which guides States and Centre in articulating development strategies,
formulating plans for that and steering both Centre’s and States’ administrations through the most

<!-- page 5 -->

5
important task of executing the plans.

In such a situation, handing over funds to that Commission to

be distributed among States would have been unnecessary.

However such a discussion is now futile as

the nation has accepted the arrangement. And, the economy has gained by the work of the
Commission, guided by the National Development Council.

Therefore, this deviation from the original

structure of fiscal federalism need not be subjected to a review at this stage. But that was the first
deviation from the original structure of fiscal federalism.
2.4

In the early days of planning, a good part of the funds handled by Planning Commission were

given on specified patterns (of grant and loan ratio) for different schemes.

This made States eager to

pick up schemes which would yield the best ratio for getting funds. Too much intervention by the
Planning Commission in execution of schemes also resulted from this.

This was recognised and at the

time of the Fourth Plan, a new system for financing State Plans was formulated.

The Five Year Plan

outlay, annual plan outlay and sectoral outlays would be finalised in discussions between States and
Planning Commission.
Gadgil formula.

For the annual plan so approved, an amount of assistance was fixed based on

If the States achieved that outlay, full assistance would be available.

Within the total

outlays, there were priority sector outlays and within such sectoral outlays, earmarked provisions. No
diversion for priority sectors was allowed and no reduction in earmarked provisions was allowed.

This

system ensured the continuance of the wholesome aspects of the earlier system of schematic funding.
Unlike the schematic assistance system, the new block assistance system fully accepted States’
legitimate right to fix their own priorities, consistent with overall national priorities.

It was also

decided that schemes of a pilot nature or schemes of inter-state importance should be implemented as
Centrally Sponsored Schemes provided for in Central budgets and routed through State Governments
who were to be the implementing agencies.
2.5

This arrangement, which supported the concept of federalism, soon gave way to a temptation

on the part of Central Ministries to expand their areas of influence.

The provision for Centrally

Sponsored Schemes steadily grew and the number of such schemes increased.
schemes were fully provided for in the Central Budget.

To begin with, the

Later, a share to be financed by States was

included in many of the schemes. That share had to be included in the State’s annual plan outlay. As
more schemes were taken up and the total requirement grew enormously, States’ share also
increased.

States were however eager to make full use of the Centrally Sponsored Scheme funds, for

two reasons.

One was the normal trend of trying to get as much as possible from the Centre.

The

<!-- page 6 -->

6
second was that Centrally Sponsored Scheme assistance was mostly as grant as against the pattern of
Central assistance for State Plans. So States tended to squeeze their normal plan scheme provisions to
find money to deploy as their share in Centrally Sponsored Schemes. Meanwhile, the component of
externally aided schemes in State Plan outlays was also growing.

There also a substantial share

(roughly 30 percent) had to be found by State Governments within their resources.

This put further

strain on other schemes in the States’ annual plan outlay.
2.6

Gradually, the importance of State Plan outlay and block assistance given under Gadgil formula

suffered.

With a good part of annual plan outlay predetermined as States’ share of Centrally

Sponsored Schemes or externally aided projects, States’ own priorities had to be accommodated
within the residual outlay.

System of bloc k assistance under Gadgil formula also lost its pre-eminent

position as the main channel of funds to States after Finance Commission transfer.
Budget of 2008-09, Central assistance for State Plans is Rs. 59858 crore.

In the Central

Assistance for Centrally

Sponsored and Central sector schemes and direct release under Central plan to State/District level
autonomous bodies add up to Rs. 83,303 crore. This may be viewed against the NDC decision at the
time of Fourth Plan that assistance through Centrally Sponsored Schemes should not exceed one-sixth
of the total Central assistance to States.
2.7

The adverse impact of unreasonable growth in Centrally Sponsored Schemes showed up on the

administrative side also.

Co -ordination of financial management in State Governments became

difficult.

Central Ministries established and encouraged direct linkage to implementing departments in

States.

Soon a situation developed where different departments of State Governments would ask for

substantial staff expansion and other facilities on the plea that money was coming from Centre and
the staff was for implementing Centrally Sponsored Schemes.

State Governments, already facing

financial difficulties, could not turn down such pleas. So the co-ordinating departments in States found
it difficult to finance the rest of State Plan outlays.

They also had to find funds for maintaining the

staff after the implementation of the Centrally Sponsored Schemes was completed.
2.8

Often it so happens that the budget expectation of assistance in Centrally Sponsored Schemes

does not materialise fully. Many of the conditions attached are evolved on a standardised scale for the
entire country. In some cases, some of the conditions may not be relevant to a particular State.

In

<!-- page 7 -->

7
such instances, implementation suffers and shortfalls in expenditure take place.

This is another

unsettling factor in States’ financial management.

2.9

However the most serious flaw in this trend of enormous growth in Centrally Sponsored

Schemes provision (including items directly implemented by agencies below the level of State
Governments) is that most of the schemes are in areas which are allocated to States under the
Constitution.

Why should Centre enter such areas is a question which has not been adequately

answered anywhere.

There is an unstated impression that unless the Centre directly intervenes with

funds and attached conditions, schemes in key areas of economic development coming within the
purview of States’ responsibilities would not be adequately funded and properly implemented by State
Governments.
2.10

This approach seems to be prevalent not only in relation to Centrally Sponsored Schemes, but

also in some Finance Commission recommendations.

The recent trend has been to tie Article 275

grants to what are assessed by the Commission as special problems. If a State has a special problem to
be tackled, it should normally figure in the deployment of funds in their plan budgets.

That is the

basic purpose of prioritisation of expenditure which is, after all, what planning is about.

If a State

has substantial surplus in the revenue account with or without devolution, why cannot that be put to
use in tackling a special problem which is of high priority to that State?

Further, when Finance

Commission gives grants for such purpose with conditions, Central Government comes to have a role in
implementation which is inconsistent with the division of duties and responsibilities between Centre
and States.

The obvious answer to the doubts mentioned above is again the unstated impression that

without such pressure imposed through conditionality, State Governments would not use the funds
properly.
2.11

The trend of viewing State Governments with scepticism has been evident also in another

important area of public finance management.

The overzealous approach to the issue of revenue

account deficit is an instance where a good idea is taken beyond its logical purview. It is necessary to
ensure that revenue account expenditure does not increase steeply while receipts do not grow
correspondingly.

So, eventual elimination of revenue account deficit was taken as one goal of good

public finance management.

This did not mean that States are mismanaging their finances or that the

Centre or the Finance Commission has to intervene and discipline them.

In fact if one looks at the

<!-- page 8 -->

8
overall position in the last four decades, it will be clear that States have managed their finances
without creating any net budget deficit.

If a Government can ensure that there is no budget deficit

(excess of disbursements over receipts), it will automatically mean efficient control of revenue deficit
or even fiscal deficit.

So, if deficit reduction is the ultimate goal of public finance management,

States cannot be faulted (though this achievement was mostly a result of the enforcement of the
overdraft regulation scheme).

During this period, in many years, Central Government had budget

deficits which were converted into RBI securities. So one can even say that States have done better
than Centre in this respect.

But mere reduction or elimination of deficit (of any type – budget,

revenue, fiscal or primary) is no conclusive evidence of good public finance management.
deficit is controlled is equally, if not more, important.

How the

If a State has substantial revenue account

surplus but the Centre has to formulate and directly finance a programme, say, of constructing toilets
in schools in that State, their revenue account surplus is hardly a commendable achievement.

If

another State which ensures relatively better tax administration, but takes up effective schemes in
social service sectors involving larger components of revenue account expenditure and ends up with a
revenue account deficit, that deficit is not something based on which they should be denied their due
share in, say, a debt relief scheme.

If a State gets unfairly low share of Central taxes, eliminating

revenue account deficit or managing fiscal deficit may be beyond their control.

In cases where

genuine plan requirements, as assessed jointly by the State Government and Planning Commission,
necessitate a high proportion of plan revenue expenditure, that may lead to a revenue deficit even if
non-plan revenue deficit is eliminated.

The point is that there are various factors, some beyond the

control of the State Government, which affect the size of revenue account deficit. Adherence to a
‘mantra’ of elimination of revenue account deficit shows up inadequate understanding of the
complexity of public finance management in a developing economy of over a billion people.
2.12

Similarly, in the context of fiscal deficit reduction, each State has to manage its fiscal

situation depending on various factors like its revenue earning capacity, committed items and pattern
of expenditure and overall debt position. While there can be no dispute that wasteful expenditure has
to be eliminated and unproductive expenditure curtailed, the spending priorities are unique to each
State depending upon the regional requirements and policy goals. As such, States should be free to
pursue their own self determined fiscal correction path, keeping in view their primary duty of public
welfare. Quite contrary to this position, uniform rigid fiscal targets have been imposed on States.

<!-- page 9 -->

9
2.13

The

ultimate

purpose

administration, is public interest.

of

public

finance

management,

like

in

any

other

aspect

of

So controlling revenue account deficit or managing fiscal deficit in a

manner detrimental to public interest should not be considered a desirable goal.
2.14

Here again the basic flaw is that States are viewed as errant boys who have to be kept in line

applying the classic strategy of ‘Sama, Dana, Bheda, Danda’.
federalism but even with the concept of democracy.

This is inconsistent with not only

Functionaries at policy levels of Centre and the

States both come from political parties which work at State and Central levels.

Governments at both

levels are guided by legislative bodies elected through the same democratic process.

Laws, rules and

procedures are same or similar.

Senior administrators who execute Government policies come from

the same services and sources.

Why should, in spite of all this, States be considered inherently

incapable of managing their finances?

If

the argument is that State Governments, being closer to

people, are liable to be influenced by local pressure groups and cannot therefore take decisions in
common public interest, the entire basis of our federal structure is being challenged in that
assumption.

2.15

The trend of weakening federalism has been evident not only in the vertical relationship of the

two levels of governance – Centre and States.

In the horizontal distribution of financial resources also

this seems to be happening. It arose from a genuine concern for helping weaker States.

Successive

Finance Commissions have considered this a major goal of revenue transfer from Centre to States.
This is in spite of the fact that one of the important aims of planning is regional balance in economic
development and that Planning Commission is eminently equipped to handle that aspect through
Central and State Plans. The well-intentioned zeal of Finance Commissions in this respect has created
a problem for States which have managed their economies relatively better.

Huge differences have

resulted in the per capita devolution of share of Central taxes to different States. For instance, in the
recommendation of the Twelfth Finance Commission, among non-special category States the per
capita share (1971 population) of Central taxes for the State which gets the lowest share is Rs. 5861
and the per capita share of the State which gets the highest share is Rs.19864 i.e. nearly 3½ times the
lowest. (If special category States are also included, the difference is fantastic, nearly 12 times.) How
does the Indian citizen living in the former State deserve such a grossly harsh treatment compared to
his brother in the latter State? The role of the Finance Commission is to achieve that degree of subtle

<!-- page 10 -->

10
balancing whereby the needs of the weaker States are met without making the others feel let down.
This is, no doubt, a difficult task.

But failure in achieving it may not be good for the integrity of the

nation, in the long run.
2.16

What we have tried to narrate in the preceding paragraphs is the decline of fiscal federalism in

the last four decades. This cannot be corrected at one go. But a definite move for correction has to
be initiated. The only body which can do so is the Finance Commission. That is the course correction
we have mentioned in the very first paragraph of this memorandum.
2.17

That course correction, in the perception of the Government of Kerala, should be on the lines

listed below.
•

Primacy of Finance Commission in steering Centre-State financial relations should be
reaffirmed.

•

As Finance Commission transfer is the manifestation of a Constitutional right of
States to get a share of Central revenues, it should not be loaded heavily with
conditions to be administered by Central Ministries.

•

Primacy of the State Plan (and Gadgil formula assistance) should be reasserted as the
vehicle for developmental efforts.

All priority areas and problems special to each

State should largely be tackled in the State Plan.
•

Central

plan

should

not

intrude

into

areas

responsibilities of States under the Constitution.

coming

within

the

duties

and

Developmental schemes in such

areas should be mostly left to be tackled by State Plans.
•

To achieve this, the size of State Plans would have to be increased. To enable States
to do this, more Central revenue should be given as Gadgil formula grants (Central
assistance should have no Central loan component – except back to back external
aid).

•

Revenue transfers and distribution among States should not cause heartburn either
to weak or to other States.

Both should feel the satisfaction of a fair deal. The

range of deviation from average per capita transfer, particularly share of Central
taxes, should be rationalised.

•

The new initiative containing these goals will not cause any substantial deterioration
in Centre’s revenue account.

2.18

Our suggestions regarding the matters being considered by the Thirteenth Finance Commission

have been formulated on the basis mentioned above. We are presenting our specific proposals for the
Commission’s consideration in the chapters following the next two chapters which give a factual

<!-- page 11 -->

11
account of Kerala Government’s fiscal situation and the methodology followed in preparing the
forecasts of receipts and expenditure.

<!-- page 12 -->

12
Chapter 3
FISCAL SITUATION

3.1
country.

In recent years, there has been a perceptible improvement in the fiscal situation in the
The consolidated Fiscal deficit of the Centre and the States together which stood at

9.9 percent of GDP in 2001-02 declined steadily to 5.34 percent in 2006-07 and is budgeted at
4.6 percent in 2008-09.

The aggregate revenue deficit declined from 7 percent of GDP in 2001-02 to 2

percent in 2006-07 and is budgeted at 0.5 percent in 2008-09.

Both Central and State Governments

have been able to significantly reduce their fiscal and revenue deficits during this period.

The

progress in fiscal consolidation has been to the extent that while both Central and State Governments
should overreach the fiscal deficit targets set by the Twelfth Finance Commission, the continuing
revenue deficit is likely to persist in 2008-09 and even beyond. However, the position in this regard is
likely to be impacted by the recent slowing down of the economy and financial crisis.

3.2

The Centre’s fiscal deficit as a ratio of GDP declined from 6.2 percent in 2001-02 to

4.5 percent in 2003-04 and is projected to decline to 2.5 percent in 2008-09.

Likewise, its revenue

deficit relative to GDP registered a decline from 4.4 percent in 2001-02 to 3.6 percent in 2003-04 and
is budgeted to further come down to 1 percent in 2008-09. Improvement in fiscal performance of the
Central Government has mainly come from higher buoyancy of tax revenue particularly personal and
corporate income taxes and service tax. Despite the appreciable fiscal consolidation, large and
growing off budget liabilities of the Central Government remain a matter of concern to fiscal stability
and sustainability.

3.3

States’ finances have also recorded an appreciable improvement in recent years.

The

aggregate revenue deficit of States which stood at 2.3 percent of GDP in 2003-04 has turned into a
marginal surplus of 0.5 percent in 2008-09. The fiscal deficit relative to GDP has improved from the
level of 4.4 percent in 2003-04 to 2.1 percent in 2008-09.

An analysis reveals that the reduction in

revenue deficit achieved by States is largely attributable to increase in revenues and expenditure
compression to an extent in some of the States. A significant portion of the increase in revenues has
come from higher Central transfers including sizeable non- plan revenue deficit grants given by the
Twelfth Finance Commission to some of the States.

States’ own tax revenue also recorded higher

growth mainly on account of Value Added Tax (VAT) reforms and rationalisation of stamp duties

<!-- page 13 -->

13
coupled with a boom in the real estate market.

The improvement in the expenditure side was mainly

due to lower interest payments which was on account of the debt swap scheme of 2004-05, lower
volume of borrowings from NSSF and debt restructuring as per the recommendations of the Twelfth
Finance Commission.

3.4

Kerala’s economy has recorded a buoyant growth in recent years.

GSDP in nominal terms has

been growing at over 11 percent since 2002-03. The sustained high growth in Kerala has contributed to
the increase in real per capita income of the State.

This trend of growth in the State’s economy is

likely to continue in the next few years, despite the recent economic and financial downturn.

3.5

The State of Kerala has been pursuing a fiscal correction path which can lead to fiscal

consolidation,

stability

and

sustainability.

The

State

has

been

able

to

achieve

remarkable

improvement in its fiscal performance through better own revenue mobilisation and improved fiscal
management, as measured through various fiscal parameters.

3.6

The revenue deficit of Kerala, which was as high as 3.43 percent of GSDP in 2004-05 declined

steadily to 1.99 percent of GSDP in 2006-07 i.e., a reduction of 1.44 percentage points in two years.
The fiscal deficit also declined from 4.16 percent to 2.88 percent of GSDP during the same period.
The primary deficit became surplus in 2006-07.

The ratio of revenue deficit to fiscal deficit, which

indicates the extent to which current spending is financed by borrowings, also came down to 69.02
percent from 82.41 percent during the same period.

It is expected to further come down to 59.85

percent in 2008-09 as against 62.04 percent in 2007-08. The fiscal consolidation process, however,
suffered a minor set back in 2007-08 as the revenue deficit grew to the level of 2.55 percent and the
fiscal deficit to 4.11 percent (Table 3.1).

Table 3.1 Fiscal Indicators Relative to GSDP

(%)

Year

Revenue Deficit

Fiscal Deficit

Primary Deficit

2001-02

3.37

4.22

1.01

2002-03

4.77

5.78

2.37

2003-04

3.83

5.77

2.30

2004-05

3.43

4.16

0.78

2005-06

2.63

3.51

0.32

2006-07

1.99

2.88

(-)0.28

<!-- page 14 -->

14

3.7

2007-08

2.55

4.11

1.19

2008-09 (BE)

2.04

3.41

0.29

The

fiscal

levels

in

2007-2008

were

largely

impacted

by

coming

into

effect

of

the

recommendations of the Eighth State Pay Commission for revision of salary and pension, payment of
pending Dearness Allowance/Dearness Relief, clearing up of arrears of works already done and
increase in developmental spending. If the revenue expenditure in 2006-07 and 2007-08 is adjusted for
this huge expenditure, the State would have substantially reduced the Revenue Deficit by March 2008.
The State’s Budget Estimates for 2008-09 have projected the revenue deficit at the 2006-2007 level of
2 percent of GSDP while the fiscal deficit will be at 3.41 percent of GSDP. The State's Medium Term
Fiscal Plan (2008-2009 to 2010-2011) presented to the State Legislature, as required under the Kerala
Fiscal Responsibility Act, 2003, along with the Budget Estimates of 2008-09 envisages elimination of
revenue deficit and reduction of fiscal deficit to 2.8 percent of GSDP by 2010-11.

3.8

The State has shown significant improvement in its revenue receipts. In recent years, the

composition of revenue receipts has been State’s Own Tax Revenue (65 percent), Non Tax Revenue (5
percent) and Central transfers (30 percent), though the comparative share of Central transfers to
Kerala in 2006-07 was low at 2.5 percent when compared to 6.42 percent of Andhra Pradesh, 4.92
percent of Karnataka and 4.56 percent of Tamil Nadu.

As can be seen from Table 3.2 below, the

State’s Own Tax Revenue as percentage of GSDP (Tax GSDP Ratio) has shown a steady increase,
coupled with increased Central transfers.

Year
2001-02

Table 3.2 Pattern of Revenue Receipts (as percent of GSDP)
State’s own
State’s own Non Tax
Central Transfers
Tax Revenue
Revenue
7.7
0.7
3.3

Total Revenue
11.7

2002-03

8.5

0.8

3.1

12.33

2003-04

8.4

0.8

3

12.31

2004-05

8.4

0.8

3.5

12.61

2005-06

8.2

0.8

3.8

12.85

2006-07

9

0.7

4

13.70

2007-08

9.2

0.8

4.2

14.21

2008-09 (BE)

9.6

0.8

4.8

15.11

<!-- page 15 -->

15
3.9

Increased tax revenue from 2005-06 is mainly attributable to increased sales tax collections

achieved through introduction of VAT and higher buoyancy in stamps and registration fee caused by
the upswing real estate sector.

The average tax GSDP ratio, which is considered a comprehensive

indicator of the capacity of the people to pay taxes, has increased to 9.21 percent in 2007-08
compared to 7.65 percent in 2001-02. The Medium Term Fiscal Plan of the State envisages further
improvement in the State’s Own Tax Revenue to 10.4 percent of GSDP in

2010-11. Also, State’s Own

Tax Revenue as percentage of its revenue expenditure has improved from 50.79 percent in 2001-02 to
52.21 percent in 2004-05 and to 54.91 percent in 2007-08 and is budgeted at 55.76 percent in 2008-09.

3.10

The State's Non - Tax Revenue constitutes on an average only 5 percent of the State’s Own

Revenue. The State's Own Non - Tax Revenue relative to GSDP in the last four years

(2004 -2005 to

2007-2008) has been of the order of 0.8 percent.

3.11

In this context, it is pertinent to point out that the State’s performance on tax effort should be

seen against the backdrop of a low primary and secondary sector contribution to the economy and a
sizeable tertiary sector (which contributes more than 60 percent to GSDP from 2003-04 onw ards) on
which the State does not have powers to levy taxes.

The composition of GSDP varies from State to

State. Further, the income distribution among various segments of the people in the State is such that
the scope to raise further tax revenue is limited. Therefore, it may not be fair or realistic to expect
Kerala to significantly improve its present level of tax buoyancy.

3.12

It is however hoped that the proposed Goods and Services Tax (GST) should enable Kerala to

mobilise more tax revenue from this growing sector of the economy.

But this will happen only if the

architecture of GST is such that the State’s revenue raising capacity and autonomy is appropriately
strengthened.

In this connection, the framework of GST arrived at by the Empowered Committee of

the State Finance Ministers is acceptable to Government of Kerala.

3.13

The State’s current focus is nonetheless, to accelerate the pace of industrial growth and

infrastructure development. The industrialisation process in the State is being oriented towards small,
environment friendly and energy efficient enterprises in areas such as IT, Tourism, Marine products,
Biotechnology, Health care etc. Integrated development of physical infrastructure in roads, airports,
seaports, power and urban infrastructure si also a priority. The State’s policy framework is aimed at

<!-- page 16 -->

16
fostering a robust investor friendly and growth oriented environment that would facilitate both private
and public – private initiatives, while strengthening the public sector and making it viable through
partnerships wherever necessary.

In pursuance of this policy, the State has taken a number of

measures, which have resulted in some of the Public Sector Undertakings turning around and also
private investment flowing into the State in IT and some infrastructure projects.

All these initiatives

are expected to lead to higher economic growth and attendant tax buoyancy over the medium and
long term.

This, coupled with the constant efforts being made to streamline tax administration,

particularly e-based information system and ensure tax compliance, will enable the State to further
improve its tax revenues.

3.14

The growing revenue expenditure is an area of concern in the State's fiscal consolidation

process.

As percentage of GSDP, revenue expenditure was 15.48 percent in 2005-06 which increased

to 15.69 percent in 2006-07 and 16.76 percent in 2007-08 and the same is estimated at 17.15 percent
in 2008-09 (BE).

The share of non-plan revenue expenditure compared to plan revenue expenditure

has also been on the increase. The salary and pension revision implemented by the State following the
8th State Pay Commission recommendations in 2005 had a substantial impact on the State’s revenue
expenditure in 2006-07 and 2007-08.

3.15

The major components of revenue expenditure are salary, pension and interest payments. The

three items together constituted 68.08 percent of the total revenue expenditure in 2007-08. Besides,
substantial

amounts

devolving

to

Local

Self

Governments

(LSGs)

Commission’s awards are also a significant part of revenue expenditure.

in

terms

of

State

Finance

However, over the years, the

State has been able to significantly contain the growth of expenditure on salary, pension and interest
payments.

The combined expenditure on these three items accounted for 93.15 percent of the State’s

total revenue receipts in 2002-03, which came down to 80.29 percent in 2007-08.
estimates of 2008-09 envisage this to be further reduced to 75.93 percent.

The budget

Also, expenditure on

account of interest payments has dropped to 20.51 percent of total revenue receipts in 2007-08
compared to 26.8 percent in 2004-05.

3.16

In this context, it is relevant to mention that Kerala has been incurring huge expenditure over

the years on social sector comprising education and health. In fact, the State’s per capita expenditure
in this area is among the highest in the country.

If the State has to sustain its achievements in social

<!-- page 17 -->

17
sector and human development, adequate funds have to be spent on the much needed maintenance
and upgradation of the social assets.

Further, given its deep commitment to the concept of welfare

State, the State continues to earmark significant outlays towards social security and welfare schemes
including pensions, particularly in the informal sector and for disadvantaged senior citizens, women
empowerment, subsidy on account of public distribution system including paddy procurement, market
intervention operations, etc. The commitment to devolve sufficient funds to Local Self Governments
also remains high on the agenda of the State.

All this has a major effect on the State's revenue

expenditure and the fiscal space available to Government to significantly contain revenue expenditure
is very limited.

3.17

The relatively reduced liability towards salary, pension and interest payments has enabled the

State to increase its capital expenditure in recent years. The State's capital expenditure which was in
the range of less than 1 percent of GSDP till recently had witnessed a substantial rise to the level of
1.6 percent of GSDP in 2007-08. The Budget Estimates of 2008-09 also project capital expenditure at a
level of 1.42 percent of GSDP. In the MTFP framework, the capital expenditure is projected to grow to
the level of 1.93 percent of GSDP in 2010-11.

3.18

The State has also been able to arrest the growth of its debt liabilities and to peg it at around

37 percent of GSDP since 2006-07.

The growth of debt stock during the period from 2001-02 to 2008-

09 is shown in Table 3.3 below.

Table 3.3

Growth of debt stock

(Rs. crore)

Year

Outstanding
debt

Growth
percent

Debt as percent
of GSDP

Debt as percent of Revenue
Receipts

2001-02

26951

12.67

34.83

297.58

2002-03

31063

15.25

36.00

291.99

2003-04

37452

20.58

39.01

316.98

2004-05

41877

11.82

39.12

310.99

2005-06

45929

9.68

38.60

300.30

2006-07

49875

8.59

37.57

274.24

2007-08

55410

11.10

37.32

262.52

2008-09(BE)

61975

11.85

37.56

248.54

<!-- page 18 -->

18
3.19

Debt liability is expected to come down to around 35.4 percent of GSDP by 2010-11. The debt

liability relative to revenue receipts was above 300 percent till 2005-06.

Debt to Revenue ratio has

dropped consistently over the last three years and is expected to reach a level of 215 percent by 201011.

The ratio of interest payments to revenue receipts, another debt sustainability indicator, has also

declined steadily.

It came down to 20.51 percent in 2007-08 compared to 28.17 percent in 2003-04

and 26.76 percent in 2004-05. It is expected to be at the level of 20.6 percent in 2008-09 and 17.6
percent by 2010-11. The State has also been able to maintain a nominal GSDP growth rate much above
the rate of interest paid on debt as shown in Table 3.4.

Table 3.4

3.20

Domar Gap

2004-05

2005-06

2006-07

2007-08

2008-09 BE

(1)

Nominal GSDP
growth rate

11.50%

11.16%

11.55%

11.86%

11.10%

(2)

Average cost of Debt

9.11%

8.65%

8.75%

8.22%

8.72%

(3)

Domar Gap (1-2)

2.39

2.51

2.80

3.64

2.38

When viewed from all these parameters, it is evident that the State has made a remarkable

improvement in the area of debt sustainability and this trend is likely to continue in the coming years
also.

We have made a few suggestions in chapter 8 on Debt for consideration of the Commission to

give relief to the State to further improve the debt situation.

3.21

The State has been able to adhere to the ceiling of Rs.14,000 crore on outstanding guarantees

set as per the Kerala Ceiling on Government Guarantees Act, 2003. The contingent liabilities on
account of guarantees extended by Government have consistently shown downward trends. The total
outstanding guarantees which stood at Rs.13,996 crore in 2003-04 have gradually declined over the
years to Rs.8,317 crore by the end of March 2008.

3.22

The State remains engaged in pursuing the various fiscal management measures in order to

sustain the fiscal improvement that has been achieved.

It may, however, be appreciated that the

fiscal space available is rather limited given the committed liabilities in terms of expenditure on
salary, pension and interest payments as also the continued focus of the State on sustainability of
social sector infrastructure, together with the need to further strengthen social security and welfare
measures for the marginalised segments of the society, particularly in the wake of the continued

<!-- page 19 -->

19
market economy environment.

Nevertheless, the State has to move further in the direction of

rationalisation of public expenditure wherever possible, additional resource mobilisation and revenue
reforms including inter-alia strengthening and streamlining of the tax administration.

These steps,

coupled with a reasonable level of devolution of funds and revenue account deficit grant (both plan
and non-plan) by the Thirteenth Finance Commission, should enable the State to further consolidate
the fiscal correction path and achieve the fiscal targets as set in the MTFP, while continuing to step up
capital expenditure which, in turn, is expected to lead to higher economic growth and capital
formation in the State.

<!-- page 20 -->

20
Chapter 4
FORECAST OF RECEIPTS AND EXPENDITURE

4.1

Kerala has always presented the forecasts of revenue and expenditure before the Finance

Commissions

as

realistically

as

possible.

But

the

successive

Finance

Commissions,

in

their

reassessments, have overestimated its revenue projections and underestimated the expenditure
forecasts with the result that in the recent past the State has not received non-plan revenue deficit
grants except a small amount in the first year of the Twelfth Finance Commission period.

This is

notwithstanding the fact that almost all the projections made by Kerala had always been closer to the
actual figures than the Finance Commissions’ assessments. In fact, such wide variations between the
projections made by the Eleventh and Twelfth Finance Commissions and the actuals are borne out by
Tables 4.1 and 4.2.

Table 4.1 11th FC Revenue and Expenditure Projections
2000-01
2001-02
2002-03
2003-04

2004-05

(Rs. crore)
2000-05

8159.29
10134.08
8088.77

9232.86
11836.61
8963.65

37019.25
44435.57
36148.63

793.46
984.24

827.46
1164.36

877.13
1441.08

3944.06
5100.24

543.38

677.76

806.98

819.08

3506.29

13.28

13.28

13.28

13.28

13.28

66.40

11.54
8.52

12.70
9.48

13.97
12.99

15.36
22.38

16.90
231.68

70.47
285.05

6587.45
7056.30

7252.63
8266.94

8066.33
9674.65

9000.03
11313.80

10123.27
13294.59

41029.71
49606.28

6537.86

6476.28

7993.29

8918.12

10014.42

39939.97

Projection of Government of
Kerala

2244.86

2613.22

2942.28

3471.89

4096.83

15369.08

EFC Projection
Actual

1806.74
2257.60

1987.41
2489.47

2186.15
2946.76

2404.77
3328.29

2645.25
3612.54

11030.32
14634.66

Pension
Projection of Government of
Kerala

1577.69

1893.23

2271.88

2726.26

3271.51

11740.57

No.

Particulars

A

Revenue Receipts
Own Tax Revenue
Projection of Government of
Kerala
EFC Projection
Actual

5864.62
6359.98
5870.25

6502.89
7428.46
5923.42

7259.59
8676.44
7302.54

Own Non tax Revenue
Projection of Government of
Kerala
EFC Projection

709.55
684.78

736.46
825.78

Actual

659.09

Other Non- plan Grants
Projection of Government of
Kerala
EFC Projection
Actual

1

2

3

4

B
1
(I)

(ii)

Total Revenue Receipts
Projection of Government of
Kerala
EFC Projection
Actual
Non-Plan Revenue
Expenditure
General Services
Interest Payments

<!-- page 21 -->

21

(iii)

(iv)

2

3

4

5

6

7

EFC Projection

1460.21

1606.23

1766.85

1943.53

2137.89

8914.71

Actual

1929.48

1837.93

2282.90

2408.83

2600.77

11059.91

Elections
Projection of Government of
Kerala

102.88

17.82

42.30

20.06

21.32

204.38

EFC Projection

18.80

90.94

23.85

26.36

98.46

258.41

Actual
Other General Services
Projection of Government of
Kerala
EFC Projection

33.62

27.50

11.06

20.98

31.84

125.00

945.00
955.57

1042.86
1006.26

1090.36
1059.69

1166.16
1116.01

1235.56
1175.38

5479.94
5312.91

Actual
Total General Services (I) to
(iv)
Projection of Government of
Kerala *

1229.93

1215.92

1359.21

1493.01

1588.10

6886.17

4870.43

5567.13

6346.82

7384.37

8625.22

32793.97

EFC Projection

4241.32

4690.84

5036.54

5490.67

6056.98

25516.35

Actual
Social Services
Projection of Government of
Kerala
EFC Projection

5450.63

5570.82

6599.93

7251.11

7833.25

32705.74

3070.86
3286.30

3221.57
3637.76

3388.24
4034.86

3566.90
4484.10

3759.74
4992.93

17007.31
20435.95

Actual

3466.80

3416.47

3966.87

4164.08

4776.82

19791.04

Economic Services
Projection of Government of
Kerala

1254.35

1354.66

1464.91

1586.17

1715.63

7375.72

EFC Projection

829.70

888.25

951.62

1020.20

1094.25

4784.02

Actual
Compensation and
Assignments to Local Bodies
Projection of Government of
Kerala
EFC Projection

964.94

842.20

1076.95

1612.63

1456.68

5953.40

102.48
62.15

117.85
70.23

135.53
79.36

155.86
89.68

179.24
101.33

402.75

Actual #

55.04

67.00

58.06

73.18

-2.64

250.64

1127.52

1217.72

1315.14

3660.38

858.19

944.01

1038.41

2840.61

690.96

Committed Liabilities
Projection of Government of
Kerala
EFC Projection
Actual - Booked under
different heads of account
Total Non- Plan Revenue
Expenditure (I to V)
Projection of Government of
Kerala **
EFC Projection

9298.12
8419.47

10261.21
9287.08

12463.02
10960.57

13911.02
12028.66

15594.97
13283.90

61528.34
53979.68

Actual
Pre-devolution Non-Plan
Revenue Deficit/Surplus
Projection of Government of
Kerala **

9937.41

9896.49

11701.81

13101.00

14064.11

58700.82

-2710.67

-3008.58

-4396.69

-4910.99

-5471.70

-20498.63

EFC Projection
Actual

-1363.17
-3399.55

-1020.14
-3420.21

-1285.92
-3708.52

-714.86
-4182.87

10.69
-4049.69

-4373.40
-18760.85

Source:- Finance Accounts, Forecast of Expenditure on Revenue Account 2000-05, Forecast of Revenue
Receipts 2000-05, Report of the Eleventh Finance Commission (2000-05)
*
Compensation and Assignments to LBs shown separately
#
Difference between GOK Projection and Actual is due to booking of major share of Local Bodies grant
under Plan
**
Excluding Fresh Expenditure

<!-- page 22 -->

22
Table 4.2 12th FC Revenue and Expenditure Projections
No.
A

Particulars

(Rs. crore)

2005-06

2006-07

2007-08

2008-09 BE

2009-10

2005-10

Own Tax Revenue
Projection of Government of
Kerala

10226.79

11549.56

13045.73

14738.44

16653.94

66214.46

TFC Projection

11124.82

12715.67

14534.01

16612.37

18987.94

73974.81

Actual
Own Non tax Revenue

9778.62

11941.82

13668.95

Projection of Government of
Kerala

916.49

1015.34

1125.93

1249.79

1388.66

5696.22

TFC Projection
Actual

1080.90
936.78

1271.84
937.57

1486.71
1209.55

1730.84

2010.76

7581.05

11143.29
12205.72

12564.90
13987.51

14171.67
16020.72

15988.23
18343.21

18042.60
20998.70

71910.68
81555.86

10715.40

12879.39

14878.50

Interest Payments
Projection of Government of
Kerala

4096.10

4677.21

5328.07

5996.34

6702.09

26799.81

TFC Projection

3814.25

4100.32

4407.84

4738.43

5093.81

22154.65

Actual
Pension
Projection of Government of
Kerala

3799.25

4189.70

4329.65

2889.58

3135.20

3401.69

3690.83

4004.55

17121.84

TFC Projection
Actual

2817.26
2861.18

3098.98
3294.58

3408.88
4924.53

3749.77

4124.75

17199.64

Elections
Projection of Government of
Kerala

40.13

44.12

14.31

15.08

15.90

129.53

2008.59

2057.16

10064.60

1785.30

1890.76

8513.83

Revenue Receipts
1

2

3

Total Revenue Receipts
Projection of Government of
Kerala
TFC Projection

B
1
(I)

(ii)

(iii)

Actual
Non-Plan Revenue
Expenditure
General Services

TFC Projection
(iv)

Actual
Other General Services

58.84

37.31

18.50

1870.70

2049.58

2078.57

1529.96

1622.13

1685.68

Actual
Total General Services (I) to
(iv)
Projection of Government of
Kerala

1858.93

2057.69

2704.31

8896.51

9906.10

10822.63

11710.84

12779.70

54115.78

TFC Projection

8161.47

8821.43

9502.40

10273.50

11109.32

47868.12

Actual

8578.20

9579.28

11976.99

Social Services
Projection of Government of
Kerala

5257.29

5481.53

5679.34

5968.57

6276.67

28663.39

TFC Projection

5348.92

5866.44

6434.61

7058.44

7743.42

32451.83

Projection of Government of
Kerala
TFC Projection (including
Election)

2

<!-- page 23 -->

23

3

4

5

6

Actual

4765.53

5438.12

6451.32

Economic Services
Projection of Government of
Kerala

2036.89

2257.59

2468.36

2686.31

2938.01

12387.16

TFC Projection

1512.79

1614.20

1722.95

1839.58

1964.70

8654.22

Actual
Compensation and
Assignments to Local Bodies
Projection of Government of
Kerala

1857.23

1587.43

2086.77

0.00

0.00

0.00

0.00

0.00

0.00

TFC Projection

89.89

101.13

113.77

127.99

143.99

576.77

Actual #

0.00

1911.28

2099.26

Committed Liabilities
Projection of Government of
Kerala

0.00

0.00

0.00

0.00

0.00

0.00

TFC Projection

0.00

0.00

1384.65

1488.49

1600.13

4473.27

Actual

0.00

0.00

0.00

1088.75

1121.27

1355.15

1600.01

1856.28

7021.46

424.37

467.51

598.10

747.51

918.00

3155.49

54.80

362.65

317.30

213.48

123.15

1071.38

Actual
Total Non- Plan Revenue
Expenditure ( I to V )
Projection of Government of
Kerala

17758.61

19596.65

21240.88

22926.71

24891.81

106414.66

TFC Projection

15113.07

16403.20

19158.38

20788.00

22561.56

94024.21

Actual
Pre-devolution Non-Plan
Revenue Deficit/Surplus
Projection of Government of
Kerala.

15200.96

18516.11

22614.35

-6615.32

-7031.75

-7069.21

-6938.49

-6849.21

-34503.98

TFC Projection

-2907.35

-2415.69

-3137.66

-2444.79

-1562.86

-12468.35

Actual

-4485.56

-5636.72

-7735.85

Commitment on DA
Projection of Government of
Kerala
EFC Projection
Actual

7

Commitment on DR
Projection of Government of
Kerala
EFC Projection
Actual

8

Fresh Expenditure
Projection of Government of
Kerala
EFC Projection

9

10

Source:- Finance Accounts, Forecast of Expenditure on Revenue Account 2005-10, Forecast of Revenue
Receipts 2005-10, Report of the Twelfth Finance Commission (2005-10)
#

Difference between GOK Projection and Actual is due to booking of Local Bodies grant under Plan

<!-- page 24 -->

24

These Tables underline the need to adopt realistic norms for assessing the forecasts of revenue and
expenditure. The vast variations between the assessment and the future realisation and consequent
strain on the finances of the State Government can be avoided if the Commission makes a realistic
assessment of the non-plan revenue account.

4.2

The forecast of revenue has been made taking into account the full potential for revenue

growth and the limited areas available to the State for raising resources. This generally conforms to
the guidelines issued by the Commission.

Variations, wherever seen, between the forecasts submitted

to the Planning Commission and the Thirteenth Finance Commission, have been justified in the
explanatory notes on the estimates separately submitted to the Commission. In general, the Trend
Growth Rate (TGR) for five years from 2002-03 to 2007-08 has been applied for projections of major
tax revenue items. The TGR has also included yield from the additional resource mobilisation
measures.

The periodic eventualities that affect the TGR during the forecast period have also been

taken into account and appropriate adjustments made wherever required. The Trend Growth Rates so
adjusted have been applied on 2007-08 figures of the Accountant General. Based on the projections in
individual items of major tax revenues, State’s Own Tax Revenue is assumed to grow at 13 percent
annually for the forecast period. In the case of Non-Tax Revenue, growth rate of 10 to 15 percent,
depending on the individual items, has been assumed. These realistic projections show total State’s
Own Revenue Receipts of Rs.1,38,221 crore for the forecast period of 2010-15. Achieving anything
more would be virtually impossible, more so in view of the present economic downturn, which is likely
to persist.

4.3

Expenditure under each item has been disaggregated as salary and non-salary components for

the purpose of arriving at realistic forecasts. The non-salary portion is further segregated into General
services, Social services, Economic services and Fresh expenditure.

4.4

A growth rate of 3 percent on salary for 2007-08 is applied for the estimates of 2008-09, 2009-

10 and for the forecast period from 2010 to 2015 to provide for annual increments. Since a portion of
the arrears in respect of the 2004 Pay and Pension revision was also paid in 2007-08, necessary
adjustments have been made while applying the growth rate to 2007-08 for both salary and pension.

<!-- page 25 -->

25
Two instalments of DA @ 6 percent (total 12 percent) are reckoned for each year of the forecast
period. Actually, this is likely to go up in view of the current inflationary pressures.

4.5

The Eighth State Pay Commission, in respect of 2004 pay revision (with effect from

01-07-2004), submitted its report in February 2006 and the Government Orders implementing the
recommendations were issued in March 2006. But due to administrative procedures the impact of this
salary and pension revision was fully absorbed only by the end of 2007-08. Kerala does not follow the
Central pay scales and allowances. The scales of pay and allowances are relatively on the lower side in
the State. Hence, the Central Pay revision is not adopted here as such. Instead, we have been
following the pattern of pay and pension revision every five years since 1973.This has become a fact of
life and the State has to live with it. The next Pay and Pension revision in the State is due in 2009-10
(with effect from 01-07-2009) but, given the past trend in this regard, its impact will be felt in the
State

finances

only

from

2010-11

onwards

because

of

the

administrative

procedures

in

implementation. Since Centre has allowed a rather liberal pay and pension revision, the State also will
be constrained to compensate its employees with due consideration of the scale of enhancement
allowed to the Central Government staff. The Commission may fully provide for the enhanced
committed expenditure estimated at Rs. 9603.80 crore during the award period on pay and pension
revision due from 1-7-2009. In case the normative formula for assessment does not provide for the
same, the State deserves to be fully compensated by way of a special problem grant under Article 275
on this account.

4.6

A growth rate ranging from 10 percent to 15 percent has been assumed in respect of the non-

salary components of General, Social and Economic services, depending on each item of expenditure
rather than following the flat rate method of projection.

4.7

The forecasts of compensation and assignments to Local Self Governments (LSGs) are based on

the recommendations of the Third State Finance Commission. The 73rd and 74th amendments to the
Constitution were designed by the Parliament to empower LSGs as a third tier of governance.

This

required not only delegation of adequate and appropriate powers by State Legislatures to these bodies
but also the assured transfer of financial resources to meet their traditional requirements and the new
functions entrusted with them. This means that the funds LSGs raise from their own sources will have
to be substantially augmented with funds from the State Government.

Kerala had been doing this by a

<!-- page 26 -->

26
combined system of transfer of some funds and provision of plan outlays to be implemented by LSGs.
The Third State Finance Commission brought in a comprehensive new scheme of devolution aimed at
ensuring

a

minimum

reasonable

level of funds transfer which, once approved by the State

Government, will not depend on the discretion of the State Government from year to year. The
Commission recommended that in the year 2006-07 an amount of Rs. 2050 crore should be transferred
by the State Government to the LSGs as their share of State tax collection.
roughly 17 percent of State’s Own Tax Revenue of that year.

This amount constituted

Here the 3rd State Finance Commission

was broadly following the same pattern as practised by Central Finance Commissions for vertical
transfer of share of Central taxes to State Governments.

The amount has to be provided as

Compensation and Assignments to Local Bodies through the major head of account 3604 under nonplan.

4.8

However, as the LSGs are yet to attain that level of capacity which would enable them to

properly, promptly and fully utilise such a high level of funds, the Commission indicated which
proportion of these funds should be spent for their traditional civic functions, for maintenance of
assets transferred by the State Government and for developing and expanding those services and
institutions.

4.9

Against this background, out of Rs. 2050 crore for the year 2006-07, Rs. 300 crore was to be

spent on traditional civic functions, Rs.350 crore for maintenance of assets and Rs.1400 crore for
developing

and

expanding

services

and

institutions.

The

3rd

State

Finance

Commission

also

recommended that if, as a matter of policy, State Government would like the developmental
expenditure of LSGs to be higher than what is warranted by the funds made available through the
State Finance Commission route, additional provisions could be made depending on availability of
State funds. But, in the forecast what has been included is only the minimum reasonable funds
transfer as recommended by the State Finance Commission.

4.10

As recommended by the 3rd State Finance Commission, devolution of funds to LSGs is provided

by the State Government in the budgets of the relevant years as Compensation and Assignments to
Local Bodies under non-plan revenue account under the major head of account 3604. Only the
provision for maintenance of road assets has been included in a different head of account 3054.

<!-- page 27 -->

27
4.11

For the period up to 2010-11, projections have been made as per the forecast of the 3rd State

Finance Commission at the rate of 10 percent growth each year. As the 4th State Finance Commission is
likely to recommend devolution of State tax revenues to LSGs at a rate more than the one
recommended by the 3rd State Finance Commission, 12.50 percent annual growth rate has been
applied for the remaining years (2011-12 to 2014-15) of the forecast period.

4.12

Over the years, Kerala has made huge investments in the area of public health with the result,

it has achieved far better health indices than the rest of the country.

Indeed, these are comparable

even with those in the developed world. Despite its excellent health outcomes, Kerala now faces some
major problems in the health care sector - continuing inadequacy of basic health facilities and out of
pocket expenditure for the poorer sections who cannot afford to pay, rapidly increasing diseases
associated with lifestyle and ageing, prevalence of environmental diseases and higher incidence of
mental health problems are a few. Considering the need to ensure sustainability of the achievements
made and to face the emerging second generation problems in this sector, a growth rate of 15 percent
is assumed under non-salary components for the estimates of 2008-09, 2009-10 and for the forecast
period of 2010-15.

4.13

Kerala’s achievements in the field of social development and high quality of life are mainly

attributed to the educational advancement the State has made over several years. The State is striving
hard for maintaining and sustaining the achievements made in the field of education and to cater to
the imperative need to improve qualitative aspects of education. There are at present 12,644 Schools
in the State out of which 35.57 percent are in government sector and 57.66 percent in private aided
sector, 1647 Higher Secondary Schools out of which 729 are Government Schools and 529 are in the
private aided sector and 389 Vocational Higher Secondary Schools, of which 261 are in the Government
sector and 128 are in the aided sector. Besides, there are 7 Universities in Kerala, out of which 4
Universities are offering various courses and are multi disciplinary. And the other 3 are Kerala
Agricultural University, Cochin University of Science and Technology and Sri Sankaracharya University
of Sanskrit.

The State Government has also recently approved the setting up of a medical university.

The State Government provides plan and non-plan grants to Universities, which have proved to be
inadequate despite being a major source of revenue for them. Considering the huge requirement of
funds for sustaining the achievements already made, and to improve the quality of higher education, a

<!-- page 28 -->

28
growth rate of 15 percent is assumed for the estimates of 2008-09, 2009-10 and for the forecast period
of 2010-15.

4.14

The pre-devolution revenue deficit projected for 2009-10 is Rs.12,215 crore while that for

2010-11 is Rs.19,426 crore. This wide variation is mainly due to the anticipated State pay revision due
in 2009-10 but its impact will be felt in 2010-11, as earlier explained, and the inclusion of maintenance
expenditure of rural roads for the first time.

Previously, maintenance of rural roads had not been

included in the forecast presented to the Twelfth Finance Commission. Out of the total road length of
1,82,836 km. in Kerala, the length of rural roads alone is 1,61,368 km. considering the enormity of
road length, the funds that are being released to the LSGs are very meagre and are grossly inadequate
to maintain these roads. The requirement of funds to carry out maintenance of PWD roads is Rs.6,798
crore and that for rural roads is Rs.16,182 crore during the award period.

4.15

The major subsidies provided by Government are under Agriculture, Food and Civil Supplies.

Supply of rice at subsidised rate, subsidy to Kerala State Civil Supplies Corporation for market
intervention operations, compensation to Civil Supplies Corporation for paddy procurement at the
Minimum Support Price fixed by the State Government, free supply of electricity to small & marginal
farmers, ‘punja’ dewatering by pump subsidy,

subsidy

to

co-operatives for conducting festival

markets, subsidy for creation of infrastructure in private sector and the recently launched subsidised
health insurance scheme are the main items of subsidies.

4.16

The State of Kerala has done far better than the rest of the country in ensuring a durable and

sustainable social security network. Successive Governments in Kerala have introduced social security
and welfare assistance schemes during the past few decades. At present, there exist more than 35
such schemes for which close to 3 percent of the State budget is being spent. In total, nearly 12 lakh
elderly persons are receiving financial assistance from the Government, which mainly comprise
agriculture workers (5.3 lakh), widows / destitutes (2.8 lakh), old age pensioners (1.4 lakh) etc.
Details are given in the explanatory notes on forecasts of revenue and expenditure.

If all this is

considered, one can state that Kerala has given a practical meaning to the concept of a welfare State.
The Commission should take into account the expenditure on subsidies and social security and welfare
schemes while reassessing the non-plan revenue account.

<!-- page 29 -->

29
4.17

The total Plan Outlay for the Eleventh Five Year Plan (2007-08 to 2011-12) is Rs.40,422 crore,

out of which Rs.4,780 crore is from the contribution of Power sector to State Plan, Rs.10,889 crore
from contribution of LSGs and remaining Rs.24,753 crore is through State Budget. Out of Rs. 24,753
crore for the State Plan, Rs.12,296 crore is estimated as Plan Revenue expenditure for the period from
2007-08 to 2011-12 by giving an annual growth rate of 20 percent over 2007-08 figures.

4.18

Many of the plan schemes at the expiry of plan period are carried over to the next five year

plan and these are to be continued as non-plan schemes.

Implementation of such schemes involves

huge expenditure liabilities on the part of the States. At present, 30 percent of such expenditures are
being allowed as ‘committed liability’.

Considering the number of schemes being shifted to the next

Plan, this is very much on the lower side. In any case, it is not clear as to how this percentage of 30
percent has been arrived at.

The Finance Commission may like to revisit this issue and suggest a

rational criterion on the basis of which such expenditures should be taken into account while
determining the non-plan revenue deficits of States.

4.19

Another related point in the terms of reference of the Thirteenth Finance Commission is that

the needs of the States are to be restricted to the non-salary component of maintenance and upkeep
of capital assets and the non-wage related expenditure on plan schemes to be completed by March 31,
2010.

In this context, it is pertinent to note that in recent years the salary component of plan

expenditure has shown considerable increase mainly due to shift in plan expenditure in favour of social
sectors like education and health, where the bulk of the expenditure is salary related.

Therefore,

restricting the committed expenditure on completed plan schemes to only non- salary component is
not correct.

Hence, the Commission should consider the entire revenue component of the plan for

arriving at committed expenditure.

4.20

The consideration of taking into account the expenditure on plan schemes to be completed by

March 31, 2010 also needs to be looked at.

Fiscal 2011-12 being the terminal year of the 11th Plan,

almost all of the ongoing plan schemes will continue till then when the completed schemes may be
shifted to Non-plan from the year 2012-13. Therefore, March 31, 2012 should be taken as the cut off
period for the purpose of providing funds for maintenance of completed plan schemes.

<!-- page 30 -->

30
4.21

The realistic estimates forecast by us bring out the total State’s Own Revenue of Rs.1,38,221

crore and the total non-plan revenue expenditure of Rs.2,25,499 crore leaving a pre-devolution nonplan revenue deficit of Rs.87,279 crore during the forecast period of 2010-15. The pre-devolution plan
revenue deficit during this period is Rs.29,582 crore. As mentioned in chapter 6 on Grants-in-aid,
revenue deficit grant should reckon the deficit on the Plan side also.

4.22

We have made a realistic assessment of all our revenue receipts and revenue expenditure on

both non-plan and plan side as per the guidelines issued by the Commission.
have given detailed explanatory notes.

Wherever necessary, we

We hope that the Commission will take due note of our

estimates and evolve a transparent and fair criterion and norms to work out revenue deficit grant due
to the State. In our perception, such norms must necessarily include full expenditure on salary and
pension revision, grants to local bodies, maintenance expenditure for roads, buildings and irrigation,
food and agriculture subsidy, the expenditure incurred on social sector such as education and health,
and social security and welfare schemes.

<!-- page 31 -->

31
Chapter 5
DEVOLUTION OF CENTRAL TAXES
5.1

In chapter 2 of this memorandum, a brief account of the decline of fiscal federalism has been

given. The lines on which a course correction should, in our perception, be attempted have also been
listed.

The first item in that list is the reassertion of the primacy of Finance Commission transfers in

the movement of resources from Centre to States.
Finance Commission transfe rs.

For this, it is necessary to improve the share of

In suggesting an appropriate share, certain basic facts about the

respective expenditure requirements as well as resource potential of Centre and States have to be
kept in view.
5.2

States’ Own Revenues relative to that of Centre have always been considerably lower. But this

disparity in relative revenues is not reflected in the expenditure patterns of Centre and States. Please
see Tables 5.1 and 5.2 below. The average gross revenue of Centre, including share of Central taxes to
States, was 62.48 percent of the combined total revenue receipts of Centre and States for the period
from 1999-2000 to 2006-07 whereas that of States, before devolution of taxes and grants, was 37.52
percent. During the same period the expenditure of the States, out of the combined total expenditure,
has increased from 56.08 to 58.67 percent while that of Centre has declined from 43.92 to 41.33
percent.

Table 5.1 Relative share of Centre and States in Combined Revenue Receipts (Rs. crore)
Year

Centre @

States #

Total

1999-00

224963

132457

357420
393986

% Centre
62.94
62.07

% States
37.06
37.93

2000-01

244550

149436

2001-02
2002-03

254834
288556

160378
178002

415212
466558

61.37
61.85

38.63
38.15

2003-04

331179

198111

529290

62.57

37.43
38.00
37.01

2004-05
2005-06

386151
442964

236669
260246

622820
703210

62.00
62.99

2006-07

556717

* 312737

869454

64.03

35.97

62.48

37.52

Average
Source: Centre - Union Budget, States-RBI
Note: @ Before devolution of Share of Central Taxes.

# States Own Revenue.

*RE

<!-- page 32 -->

32
Table 5.2 Relative share of Centre and States in Total Expenditure (Rs. crore)
Year

Centre #

States

Total

% Centre

% States

1999-00

245870

313889

559759

43.92

56.08

2000-01

266947

347198

614145

43.47

56.53

2001-02

295872

377312

673184

43.95

56.05

2002-03

342990

420462

763452

44.93

55.07

2003-04

396793

526023

922816

43.00

57.00

2004-05

418488

566303

984791

42.50

57.50

2005-06

424078

561682

985760

43.02

56.98

2006-07

484551

* 687946

1172497

41.33

58.67

43.26

56.74

Average
Source: Centre: Union Budget, States – RBI
Note # : Excludes FC devolutions, Plan and Non-Plan assistance to States & UTs,

5.3

* RE

Gross transfers to States as a proportion of gross receipts of Centre during the early seventies were in the

order of 45 percent. This has fallen over the years to just 30 percent in 2007-08. On the Plan side also the share
of Gadgil formula based Normal Central Assistance to States, out of the total Central assistance to State Plans, has
come down from 85 percent in 1991-92 to about 30 percent in 2008-09 (BE).

5.4

States have submitted a first ever common memorandum to the Thirteenth Finance Commission

requesting enhancement of States’ share of Central taxes in the divisible pool to 50 percent, instead of the 30.5
percent recommended by the Twelfth Finance Commission.

We believe that raising the share of taxes is a far

better option than relying more on grants as a means of devolution of resources from Centre to States. It will
rectify the vertical imbalance in resource mobilisation to a great extent. The relative share of Centre and States
in receipts and expenditure also justifies such a course of action. It will arrest the declining trend in gross Central
transfers relative to gross receipts.

5.5

Government

of

Kerala

strongly

endorses

the

suggestion

contained

in

the

all

States’

memorandum. The share of Central taxes to be devolved to States may be increased to the level of 50
percent of the divisible pool.

This will be the most effe ctive way to ensure that States’ right to get a

reasonable share of Central taxes is not indirectly circumvented through other kinds of transfer of
resources which can be subject to Centre’s discretion.
5.6

If the increase in States’ share of Central taxes fr om 30.5 percent to 50 percent cannot be

achieved in one year’s time, we suggest that it may be spread over a period of five years, from 2010-

<!-- page 33 -->

33
11 to 2014-15. That way, the impact of the increase on Centre’s revenue account will not be sudden.
Gradual increase over a five year period can be absorbed, with suitable realignment of the different
components of transfer to States, consistent with the spirit of fiscal federalism. We will go into details
and illustrate this new pattern in chapter 7 ‘Course Correction’.
Distribution of share of taxes among States
5.7

Certain basic facts have to be kept in view while discussing the manner in which each State’s

share is to be determined.

The first is that States’ share of Central taxes is not really any movement

of Centre’s resources to States. It is actually the tax revenue of States. As pointed out in chapter 2,
Centre’s taxation powers are not designed for exclusively meeting their expenditure but are based on
the fact that Centre can more effectively levy and collect them.

So the share of taxes mandatorily

going to States is not Centre’s revenue at all. This is evident from the fact that as per Article 270, this
share does not enter Centre’s consolidated fund. It goes into States’ consolidated fund. Had it been
the revenue of Centre it would have first moved into Centre’s consolidated fund and then moved out
by Parliament’s appropriation as resource transfer to States.
5.8

Another basic fact to be kept in view is that the most important factor influencing cost of

governance - both non-developmental and developmental - is population.

Normally the cost of

governance of a State with a population of 5 crore will be much higher than the cost of governance of
a State with a population of 2 or 3 crore.

5.9

The thir d basic fact is that Indian States vary vastly in the size of their population. The range is

between 2 lakh and 838 lakh (1971 census).
5.10

From these basic facts, it is evident that population of a State should be the main

consideration in distributing share of Central taxes.

It also means that the fairness of any scheme of

such distribution is to be judged on the basis of the per capita share of Central taxes going to each
State.
5.11

There are however some other factors which influence the cost of governance. Such factors are

of two types. The first type is factors antithetical to population. The best example is area. It has to
be admitted that area of a thinly populated State adds to cost of governance, though certainly
nowhere near the extent to which population size does.

The second type are factors which are

<!-- page 34 -->

34
deliberately chosen either on the principle of equity or efficiency.

No doubt they are also relevant.

However in respect of those factors, value of each State has to be adjusted to the size of the
population.

That is why Finance Commissions have been using the method of scaling to population

(vide paragraph 5.40 of the Report of the Tenth Finance Commission).

Once that is done, the net

value of each State in that factor, which could be different from the value under population factor,
will not differ too drastically from population ratio.

Unless such scaling is done, bizarre results might

ensue.
5.12

In the recent past, Finance Commissions have been using per capita GSDP as a major fac tor.

The weight given is too unreasonable; and we will explain that later. But even if such high weights are
considered reasonable, the way it is applied may result in strange outcome.

For instance, in the

Twelfth Finance Commission Report, among non-special category States, the highest per capita share
of taxes has gone to the State which has the lowest population and the highest per capita GSDP. We
have not been able to find out how this could take place while applying a weight of 25 percent for
population and 50 percent for per capita GSDP.

Perhaps while applying the weight for per capita

GSDP, no scaling to population was done.
5.13

It is necessary to go into the fairness of the trend of giving high weightage to per capita GSDP.

Apart from the fact that the issue of backwardness is essentially addressed through the instrumentality
of State annual plans and the Normal Central Assistance, there are mainly two reasons why this should
be reviewed.

Firstly it is a defective yardstick.

It does not capture all relevant elements of

backwardness.

For instance, the level of unemployment in a State does not seem to reflect in the

GSDP, except indirectly and remotely. The level of distribution of income also does not figure whereas
that is a clear indication of the performance of a State in handling economic inequity within their
population.

The second reason is that, this criterion and distribution based on that is not found

effective. States which have received higher share in this assessment through successive Finance
Commissions have not, necessarily, shown any improvement (in relative terms) in their position (Table
5.3). Obviously improving the economic status of a State or of the weaker sections of the people of
that State is not merely a function of money.

<!-- page 35 -->

35
Table 5.3 PER CAPITA GSDP (Comparable)

(In Rs.)

Non Special
Category States

X FC#

XI FC

XII FC

Special Category
States

X FC#

XI FC

XII FC

Andhra Pradesh

3455

11366

18869

Arunachal Pradesh

4670

10705

16579

Bihar

2135

5529

6539

Assam

3195

7968

12288

13710

Himachal Pradesh

3618

12154

24762

Chatisgarh
Goa

7364

25076

56599

Jammu & Kashmir

3534

10007

18132

Gujarat

4602

16332

22708

Manipur

3449

8799

17264

Haryana

5284

16927

26256

Meghalaya

3328

9824

16035

11717

Mizoram

4094

12378

21245

Jharkand
Karnataka

3810

2367

20703

Nagaland

3929

12933

20469

Kerala

3532

13091

22824

Sikkim

4846

11109

20929

Madhya Pradesh

299

9589

13340

Tripura

3163

7984

18974

Maharashtra

5369

19098

26994

Uttaranchal

Orissa

2945

7909

11234

Punjab

6996

18568

28030

Rajasthan

3092

10377

15059

Tamil Nadu

4093

13926

22587

Uttar Pradesh

2867

7702

10798

West Bengal

3750

10171

17377

16998

Source: Respective FC Reports
# Net State Domestic Product

Efficient and timely management of resources – both financial and physical - is the key. Merely giving
more funds to such States without even checking on what effect the previous Commissions’
recommendation in this regard yielded, can only lead to misapplication of scarce resources while
simultaneously denying funds to States which could put them to better use. So it is not proper to give a
high weightage to per capita income factor. However, Government of Kerala does recognise that
backwardness should be a factor in the horizontal distribution formula on the ground of equity but, in
view of the above reasons, its weightage should be 10 percent with its value scaled to population
(1971).
5.14

Fiscal discipline and Tax effort were the other criteria used by recent Finance Commissions.

As stated earlier, we are of the view that States should have the flexibility to manage their fiscal
situation depending on the policy goals and factors specific to individual States.

Hence, fiscal

performance as achieved by States due to their own revenue effort and expenditure management
needs to be recognised and suitable weightage given in inter-se distribution of Central taxes.

The

<!-- page 36 -->

36
fiscal self-reliance and improvement index adopted by the Twelfth Finance Commission may be used to
assess fiscal performance of States.

5.15

Tax effort is an important factor as it reflects the tax raising capacity and effort of States.

But while calculating the share of States on the basis of tax effort both effort and capacity may be
assessed. Tax effort may be taken as the ratio of effort relative (ER) to capacity relative (CR) where
ER is the ratio of per capita own tax revenue of the State to the average per capita tax revenue of the
relevant group of States (general/special) and CR is the ratio of the per capita GSDP of the State to
the average per capita GSDP for the relevant group of States.

If, however, the Commission decides to

continue with the method used by the two previous Commissions, we submit that the practice of
weighting the Tax-GSDP ratio with the inverse of per capita income may be done away with. The
weight weakens the connection between the tax effort actually made by a State and the criterion
values calculated as per the Finance Commission formula. Obviously the weight is given with a view to
compensating poorer States with weaker tax bases. But, one has to be clear as to what one wishes to
accomplish by bringing in the tax effort criterion into the devolution formula. If it is meant to
incentives revenue mobilisation by States, then the incentivise effects of the criterion should not be
mitigated by using such weights. Also, when Tax-GSDP ratio is being used for computing tax effort, the
case for additional compensation for weaker tax bases is without merit and such overcompensation
would defeat the purpose of the criterion in the formula.

5.16

Taking all aspects into consideration, Government of Kerala suggests that the share of Central
taxes may be distributed among States based on the following criteria and weights:
Population

70 %

Income distance

10 %

Area (adjusted)

5%

Tax effort

10 %

Fiscal performance

5%

5.17

Another major aspect to be dealt with is the range of difference in per capita share of taxes to

States.

Table 5.4 shows the position of special category States and non-special category States as per

Twelfth Finance Commission recommendation. The per capita shares vary from Rs.5,861 to Rs.69,647.

<!-- page 37 -->

37
Table 5.4 XII Finance Commission Per Capita shares of Central Taxes
Rs.)
Non Special Category States
Punjab
Maharashtra
Haryana
Kerala
Tamil Nadu
Gujarat
Karnataka
West Bengal
Andhra Pradesh
Rajasthan
Madhya Pradesh
Chatisgarh
Uttar Pradesh
Orissa
Jharkand
Bihar
Goa

5.18

(Amount

Special Category States
5861
6084
6596
7678
7901
8202
9339
9775
10377
13341
13727
14039
14106
14461
14524
16074
19864

Himachal Pradesh
Uttaranchal
Assam
Jammu & Kashmir
Tripura
Manipur
Meghalaya
Nagaland
Arunachal Pradesh
Mizoram
Sikkim
All S.C. States

9152
12805
13596
16178
16413
20195
22766
32273
35347
48884
69647
15316

All N.S.C. States

11038

All States

11289

Source: XII FC Report, Population 1971

Even among non-special category States the variation is too huge. The only way to correct this

trend is to determine a range for such variation. We strongly recommend that it should be a range of
80 to 120.

The per capita (1971 population) share of taxes of the State with the highest per capita

share should not be more than 150 percent of the per capita share of the State which gets the lowest
per capita share.

Necessary adjustments may be done while working out the percentage entitlements

of different States. This range may be applied strictly at least among the non-special category States.
5.19

In this context, we would like to point out that in any direct or indirect application of

population factor, population based on 1971 census should be taken.

This has the sanction of

Parliament, as a resolution to apply 1971 population to all transfer of resources to States had been
tabled there more than three decades ago.

Taking population based on any subsequent census for

even indirect application will be contrary to the spirit of that resolution.
5.20

It is also necessary to give an annexure showing how each State’s share in Central taxes has

been worked out. This is absolutely essential in the interest of transparency in deciding such an issue
of great national importance.

We are making this point in the light of the experience the State has

had with regard to its declining share in the divisible pool. To illustrate this point, the
succeeding paragraph is brought to the notice of the Commission.

position in the

<!-- page 38 -->

38
5.21

The allocation for Kerala in the shareable taxes and duties under

Table 5.5 Share of Centr al
Taxes
% share of
FC
Period
Kerala

various Finance Commissions can be seen in Table 5.5. Kerala’s share of
2.665

percent

of

the

divisible

pool

under

the

Twelfth

Finance

Commission was the lowest. In our memorandum to the Twelfth Finance
Commission

we

had

at

length

explained

the

reasons

for

treating

population as the most important parameter in inter-se distribution of
the divisible pool.

Population was the sole criterion used by the first

three Finance Commissions and it remained as the most important
parameter till the Seventh Commission, which drastically reduced the
weightage for population from 75 percent to 25 percent. Discarding the
original objective criterion, the Eleventh Finance Commission gave only

II
III
IV
V
VI
VII
VIII
IX
X
XI
XII

1955-60
1960-65
1965-70
1970-75
1975-80
1980-85
1985-90
1990-95
1995-00
2000-05
2005-10

3.640
3.550
3.590
3.830
3.920
3.950
3.760
3.729
3.875
3.057
2.665

10 percent weight to population. The criteria and weights given by the last three Finance Commissions
are shown in Table 5.6.

The State had requested the Twelfth Finance Commission to give up the

Table 5.6 Criteria and Weights
Weightage
Criteria
X
XII
XI FC
FC
FC
Population
20%
10%
25%
Backwardness
60% 62.5%
50%
Geographic
5%
7.5%
10%
Area
Index of
5%
7.5%
NIL
infrastructure
Tax Effort
10%
5%
7.5%
Fiscal
NIL
7.5%
7.5%
Discipline
100
TOTAL
100%
100%
%

criteria of backwardness and suggested giving 80 percent weight
for population (1971), 10 percent for tax effort and 10 percent for
commitment to fiscal reforms. When we compare this against the
weights given by the Twelfth Finance Commission for the various
criteria, it can be seen that the decision of the Twelfth
Commission in assigning weights to criteria was in a way beneficial
to Kerala vis-à-vis the formula of the Eleventh Commission except
for the sole criterion of geographic area. In the Twelfth Finance
Commission,

population

was

given

15

percent

more

weight,

backwardness got 12.5 percent less, index of infrastructure was
dropped as suggested by us, weight for tax effort was increased

by 2.5 percent and that of fiscal discipline remained at

7.5 percent. So going by the changes in the

choice of criteria and the weight given to each (particularly for population and backwardness),
Kerala’s share should have been higher than what its share was in the Eleventh Finance Commission
Report. But actually Kerala’s share was reduced from 3.057 to 2.665 percent. How exactly this
happened is not clear.

The absence of any worksheet in the Commission Report indicating the exact

calculation of the impact of each criterion as well as the composite percentage for each State makes it
difficult for States to feel sure that they have got what is really their due share as per the formula
adopted by the Commission.

Hence we strongly plead that the Thirteenth Finance Commission should

give an annexure to their Report clearly indicating the calculation arriving at the composite
percentage for each State.

<!-- page 39 -->

39
Chapter 6
GRANTS-IN-AID TO STATES UNDER ARTICLE 275
6.1

Every item of expenditure of State Governments comes either under non-plan or plan

classification in the budget.

At the time of preparing the annual Plan outlay, a detailed estimate of

resources availability is done by the State Government and the Planning Commission.

In that

assessment, first all revenue receipts (excluding plan grants) are assessed and then all non-plan
revenue account requirements are assessed.

The net of this is taken as resource available (positive or

negative) under the item ‘Balance from Current Revenues’.

A similar assessment of the non-plan

capital account is also made and a figure arrived as ‘Miscellaneous Capital Receipts’.

In these

assessments, it is expected that all genuine non-plan requirements are provided for adequately.
other resources are added to arrive at the quantum of plan resources for that year.

Then

Simultaneously,

developmental requirements within the framework of the five year plan are taken up according to
prioritisation. If this process is done thoroughly, there is no need for any non-plan or plan requirement
to be financed through tied grants under Article 275.
6.2

In our view, the approach to grants-in-aid under Article 275 should be based on the perception

mentioned above.

What it can do is (i) to fill the gap in availability of revenue account resource on

the non-plan side, after a vigorous but realistic assessment of the State’s efforts.

The next is (ii) to

fill gap, if any, in the revenue account on the plan side at the existing level.

As we have stated

earlier, there is absolutely no Constitutional or other reason to exclude the gap on plan side to be left
unattended to by Finance Commissions.
6.3

Once this exercise is completed, there will be two categories of States.

One would have

substantial surplus on the revenue account. The other would have either no per capita surplus or only
meagre surpluses.

They may be given additional grants under Article 275 to augment their revenue

account in order to ensure that adequate surplus is available for capital investment.

That would meet

the stipulation in paragraph 6 (iv) of the terms of reference.
6.4

Such second stage utilisation (after the first stage of filling non-plan and plan revenue account

gaps, as rigorously and realistically assessed by the Finance Commission) of grants under Article 275
should be in our view, norm-based. Tied grants under Article 275 should be mainly limited to calamity

<!-- page 40 -->

40
relief grants and grants for augmenting State’s consolidated fund to give assistance to Local Self
Governments.

6.5

It will also be prudent to fix a ceiling for the level of Article 275 grants. This ceiling may be

fixed keeping in view the primacy of share of Central taxes as the vehicle for resource transfer to
States.

It should therefore be only a minor fraction of the amounts transferred as share of Central

taxes.
6.6

This method of utilising the grants-in-aid under Article 275 will be fully consistent with and

supportive of the federal structure in our public finance management.

If however, the Thirteenth

Finance Commission chooses to continue with the system of utilising the grants for (i) gap filling and
(ii) for special needs as assessed by them, we would present our main proposals on the lines indicated
in the following paragraphs.
6.7

The State has its own specific needs arising out of special problems requiring particular

attention. We have identified a few of these needs to be brought before the Commission for
favourable consideration and assistance. The key areas are upgradation of standards of administration
in revenue earning departments viz. commercial taxes, registration, motor vehicles and revenue
administration. This is necessary for improving transparency and governance and for raising revenue
for the State.
ecology,

special

Maintenance of forests, inland waterways, coastal zone management, management of
problems

in

the

sectors

of

health,

education,

social

welfare

and

fisheries,

strengthening of police, jails and judicial infrastructure, upgradation of agriculture and veterinary
services, development of tribes and tribal areas, rehabilitation of beedi workers and application of IT
for transparency are some of the other specific problems, apart from deficit areas in local bodies and
natural calamity relief. If full expenditure on maintenance of roads, buildings and irrigation and on the
anticipated pay and pension revision due in 2009-10 is not reckoned in reassessment of the State’s
Non-Plan Revenue Expenditure, these may also be considered for grants under Article 275.
6.8

One of the terms of reference of the Thirteenth Finance Commission is to consider the need to

manage ecology, environment and climate change consistent with sustainable development.
context, the management of forests becomes an important priority.

In this

States have a predominant role in

enlarging and maintaining the forest cover. As per the National Forest Policy of 1988, Forests should
not be looked upon as a source of revenue.

Forests are a renewable national resource.

They are the

<!-- page 41 -->

41
national assets to be protected and enhanced for the wellbeing of the people and the nation.

All this

takes note of the fact that the States which have a large forest area have an opportunity cost in terms
of the foregone economic activity and lower tax revenues.
compensated for this cost disability borne by them.

Hence, such States need to be

Therefore, the Commission may consider giving

specific purpose grants under Article 275 to incentivise afforestation.
6.9

The extent of forests in Kerala is 29 percent of its geographical area providing a forest cover of

40.13 percent. Concerted steps have been taken to maintain and protect the forests.

The total

recorded forest area of the State in 2005 was 11,265 sq. km. This has now increased to 11,305 sq. km.
These forests are very rich in biodiversity. The State has stopped the clear felling and selection felling
of the natural forests from the mid 80s and thereby has been suffering substantial loss of revenue from
timber and other forest produce. In order to maintain the biodiversity and the environmental stability
of the region, the State is not harnessing the hydel energy to the extent required. For the last two
decades, there has been no new construction of any hydel project and the State is spending its
revenues to purchase the energy to meet part of its requirement. We have 4000 km of forest roads the
maintenance of which is done by the Forest Department itself and therefore not included under the
general road maintenance forecasts. The Commission should consider these factors also while
providing grant to the State for maintenance of forests.
6.10

Kerala, with its numerous lakes, rivers and backwaters, is one of the few States in India, where

waterways can be successfully used for commercial Inland Water Transport. Because of the excessive
demand on land due to high density of population, the cost disability factor adversely affects the
State’s efforts to widen the roads to ease the choking traffic congestion. Development of the inland
waterways is the only permanent solution to this problem. This will provide a more economical and
environment friendly mode of transport to supplement the road system. By improving the IWT canals a
major portion of the bulk cargoes transported through roads is expected to be diverted to the
waterways with the present and future pressure on the road network being reduced.
6.11

The coast of Kerala, extending 560 km, is characterised by a narrow longitudinal barrier strip

of low lying land, sand-witched between the Arabian Sea and a continuous chain of lagoons and
backwaters with connections to sea at several points. Out of the total coastal length of 560 km, the
length which is vulnerable to erosion and which requires protection is 478.14 km. The coastal zone has

<!-- page 42 -->

42
the maximum concentration of population and is even many times the State average at several places.
Maintenance of a long thickly populated coastline inevitably calls for protecting people, mostly
belonging to the deprived sections of the society, from the fury of the tidal waves. Also, the State has
to safeguard the coastline from the security angle also. Centre too has an obligation to meet at least
part of the expenditure on the coastal security. We hope the Commission would extend generous
assistance to the State for Coastal Zone Management.
6.12

The State’s other priority areas are special problems in the sectors of health, education, social

welfare, fisheries and those related to environment and climate change.
6.13

Due to demographic transition (fertility and mortality rates), the ageing scenario calls for

special attention.
years of age.

It is estimated that by 2020, 17 percent of Kerala’s population will be above 60

Therefore, the State merits a special grant under Article 275 to address the problems

related to geriatrics and ageing population in respect of the disadvantaged segments of the society.
6.14

Kerala being the tropical region of the country and flanked on its east by the Western Ghats,

the ecological significance of this region is immense. The physiographic profile of the State provides it
a unique environmental character wherein, the high Western Ghat’s mountainous catchment provides
all the ecological services not only crucial for its coastal region, but for the States of Tamilnadu and
Karnataka also.

Thus, 44 rivers eman ating from the hills, diversity of life forms and tropical climate

conditions underscore high productivity potential and the diverse agricultural potential.

6.15

The important concerns of climate change which need to be taken up at local level include

reducing carbon footprints in development, bringing in energy efficiency and improving ecological
resilience of the natural resources by optimising their productivity. Our proposals in this respect
(detailed proposals on climate change and ecology are separately submitted to the Commission) are
based on the following issues which are specifically relevant in the management of ecology,
environment and climate change:
•

Food insecurity is likely as the frequency of occurrence of floods and droughts is likely to
increase. Rise in sea surface temperature and sea level also adversely affects marine food.

•

The quality of drinking water along the coast may be poor.

•

Wayanad, Idukki and Kuttanad agro-eco-systems are likely to be threatened due to climate
change. Cropping field boundaries along the high ranges are likely to shrink.

<!-- page 43 -->

43
•

Monsoon behaviour may not be normal, leading to hydel power insecurity and available
water is likely to deplete. The findings of hydrologists that the intensity of rainfall will be
high, resulting in more precipitation in shorter duration with no major variation in the
annual quantum of flow, deserves serious consideration as far as Kerala is concerned.

•

Rich bio-diversity across the Western Ghats appears to be diminishing.

•

Human health is likely to be at risk.

•

Sea level rise will have serious consequences for the coastal zones of the State and the
country. Some of the major issues arising from sea level rise that need to be tackled are
(a) inundation of wetlands and low lying areas, (b) coastal erosion and modification of
morphology, (c) weakening of coastal protection structures, (d) increase in salinity of
rivers, bays and groundwater tables, (e) increase in storm surges and (f) inundation of
land.

•

The increase of green house gas concentrations in the atmosphere has been accepted as
the major driving force for climate change.

6.16

The detailed proposals in respect of all the special problems requiring grants under

Article

275, including those mentioned above, are submitted as a separate document (Volume- 4).
6.17

The high Human Development Index (HDI) achieved by the State is the outcome of heavy

investments consistently made in the social sectors from very early days, even before the formation of
the State of Kerala. This was done at the expense of much needed investments in agriculture, industry
and infrastructure. Even though Kerala model of development has been well recognised and
appreciated, the State is now faced with second generation problems like high rate of unemployment
of the educated youth, an ever increasing ageing population with the attendant issues of geriatric
care, alarming suicide rate, out-migration, inadequate infrastructure etc. Kerala does not have the
resources to sustain and enhance the quality and standards of services in sectors like education, health
and social welfare. At the same time, Central transfers for these critical areas have been dwindling
over the years because when norms are applied uniformly to all States, Kerala is either left out or has
to satisfy with a nominal provision on the ground that the State has already achieved the elementary
standards/goals set in these areas.

In other words, the State feels penalised for its excellent

performance in the social sector and the provision of effective social safety net for the weaker
sections of the society. This has to be corrected. Hence the importance of providing specific purpose
grants to the State as detailed above.

<!-- page 44 -->

44
6.18

Issues and proposals relating to grants in respect of Local Self Governments and Calamity

Relief are dealt with in separate chapters.

<!-- page 45 -->

45
Chapter 7
COURSE CORRECTION
7.1

As pointed out earlier in the memorandum, the mandate of the Thirteenth Finance Commission

enables the Commission to correct the declining trend in fiscal federalism, which has been gathering
momentum in the last forty years.

The suggestions we have made in the matter of share of taxes

(chapter 5) and grants-in-aid (chapter 6) are aimed at this.

In this chapter we propose to give our

suggestions regarding Central assistance for State plans and then tie up all our suggestions to show
that they do not imply any substantial deterioration in the revenue account of the Central
Government.
7.2

When the system of block assistance was introduced, that assistance based on Gadgil formula

was taken as the only (or by far the biggest) assistance for State’s annual plan.

Soon this position

changed. Special assistance, additional assistance etc. entered into the picture.

Over the years this

trend continued.

In the Central budget of the current year, out of the total Central assistance of

nearly Rs.60,000 crore, only an amount of Rs.18,000 crore represents normal assistance, presumably
distributed as per revised Gadgil formula.

It is necessary not only to arrest this trend but also to

reverse it.
7.3

Now, only grant portion of Central assistance is an outgo for Central budget. The loan portion

is given as share of market borrowing. (In the case of externally aided programmes taken up before
the advent of the ‘back to back’ type of arrangement, some loan component of additional assistance is
still available in Central budget, but that is not substantial).

Therefore, the purpose of reversing the

trend of reducing the role of Normal Central Assistance can be achieved by fixing a minimum limit for
block grants distributed solely as per Gadgil formula. That grant should be distributed among all the
twenty eight States on the basis of the different criteria and weights for each criterion under the
revised Gadgil formula.
7.4

This can be done as part of the revised pattern we have referred to in paragraph 5.6. As we

have mentioned there, the new pattern will be a realignment of the different components of transfer
of resources from Centre to States. That realignment will have to initiate a reversal of the trend of
erosion of fisc al federalism that has been taking place over the last few decades. To make such a

<!-- page 46 -->

46
course correction, the revised pattern will have to keep in view the goals we have indicated in
paragraph 2.17 of this memorandum.

7.5

In the Central budget of 2008-09, the total transfer to States is equal to a little over 61

percent of the divisible pool of Central taxes (divisible pool taken as roughly 85 percent of gross tax
revenue i.e. Rs.5,86,115 crore). The distribution is given in Table 7.1.

Table 7.1 Resource Transfer from Centre to States Budget - Estimates 2008-09
Item

Percentage to divisible
pool of Central Taxes

1. Share of Taxes

30.50

2.Grants under Article 275

5.95

3. Normal Central Assistance part of Central assistance to State
Plan

3.14

4. Sub To tal (1+2+3)

39.59

5.Other Non-Plan grants

1.36

6. Non-NCA part of Central assistance to State Plan

6.17

7.CSS including direct release to autonomous bodies

14.04

8. Sub Total (5+6+7)

21.57

9. Grand Total (4+8)
Source: GOI- Budget at a glance, Expenditure Budget Vol.1

61.16

Divisible pool is taken as roughly 85% of Centre's Gross Tax Revenue

7.6

The course correction that we are suggesting should start with reduction in the share of

Centrally Sponsored Schemes and direct releases to autonomous bodies as, now, many of these
schemes relate to areas of development which come within the purview of State Governments
according to the division of responsibilities between Centre and States. There will have to be a higher
emphasis on Gadgil formula grants compared to various types of adhoc Central assistance. This and the
increase in States’ share of Central taxes will enable States to take in a good part of the expenditure
that Centre incurs on Centrally Sponsored Schemes, including direct releases. Correspondingly, share
of the latter in Central budget will come down gradually over the five year period 2010 -15. In the year
2014 -15, the transfer of resources may be as in Table 7.2 (calculated as percentage of the divisible

<!-- page 47 -->

47
pool of Central tax revenue). This grand total will workout to only 55 percent of gross tax revenues
and 49 percent of the total revenue receipts of the Centre.

Table 7.2 Distribution Formula (2014-15)
Share of Taxes under Article 270

50%

Grants under Article 275

3%

Block grants distributed solely as per revised Gadgil
formula

7%

Sub Total (i)

60%

Other non-plan grants

1%

Plan grants of non-Gadgil formula type (special,
additional, purpose linked etc.)
Grants for Centrally Sponsored Schemes including
direct releases to autonomous bodies etc.

7.7

No conditions should
apply to this part.
(60 % of the divisible
pool)

Subject to
conditions as per
each scheme /
programme
(5 % of the divisible
pool)

1.25%
2.75%

Sub Total (ii)

5%

Grand Total

65%

In order to make this transition gradual (so that Central budget can absorb it without much

difficulty), we suggest the following spread indicated in Table 7.3 (over the five year period 2010-15)
of this realignment of the different components of transfer to States. (All percentages are linked to
the divisible pool of Central taxes.)

Table 7.3 Resource Transfer from Centre to States as Percentage of the Divisible Pool

Item

2008-09
Pattern

1. Share of Taxes

Revised Pattern
2010-11

2011-12

2012-13

2013-14

2014-15

30.50

40

42

44

47

50

2.Grants under
Article 275

5.95

3

3

3

3

3

3. Normal Central
Assistance part of Central
Assistance to State Plan

3.14

7

7

7

7

7

4. Total (1+2+3)

39.59

50

52

54

57

60

5. Other Non-Plan Grants

1.36

1

1

1

1

1

6. Non-NCA part of
Central Assistance to
State Plan

6.17

5

4.25

3.5

2

1.25

<!-- page 48 -->

48
7.CSS including Direct
release to autonomous
bodies

14.04

9

7.75

6.5

5

2.75

8. Total (5+6+7)

21.57

15

13

11

8

5

9. Grand Total (4+8)

61.16

65

65

65

65

65

Note: Divisible pool is reckoned as roughly 85 percent of Gross Tax Revenue.

7.8

In the realignment of transfer of resources as suggested in this chapter, the net increase in the

revenue expenditure of the Central Government (from 61.16 percent to 65 percent) will amount to less
than 4 percent of the divisible pool. This increase of 3.84 percent of the divisible pool is equal to only
3.26 percent of the gross tax revenues of the Centre. With the sustained economic growth and
attendant buoyancy in Central taxes, this increase in percentage terms will not mean any real
difficulty for Centre in financing its other commitments in revenue account.
7.9

In the first year (2010-11) there will be a relatively sharp reduction in the provision for other

non-plan grants, non-NCA part of Central assistance and Centrally Sponsored Schemes including direct
releases. However, in subsequent years, the reduction will not be sizeable. In the past, on various
occasions, National Development Council had suggested shift of a good part of Centrally Sponsored
Schemes and funds to States. But no serious attempt has been made yet. The studies which led to the
National Development Council decisions in this regard from time to time can give guidance in the
realignment of Centrally Sponsored Schemes in the first year

(2010-11). In subsequent years, there

will be no serious difficulty, as Table 7.4 would indicate.
Table 7.4 NP Grants, CSS & Direct Releases from Centre to States as Percentage of Divisible Pool
2008-09 Pattern
Item

2008-09

(Rs. crore)

Revised Pattern
2009-10

2010-11

2011-12

2012-13

2013-14

2014-15

Amount

%

Amount

%

Amount

%

Amount

%

Amount

%

Amount

%

Amount

%

Other N.P
grants

8000

1.36

9200

1.36

7751

1

8914

1

10251

1

11789

1

13557

1

Non-NCA
part of
Central
Assistance
to State
Plan

36144

6.17

41565

6.17

38757

5

37885

4.25

35879

3.5

23578

2

16946

1.25

CSS &
Direct
release to
autonomous
bodies

82313

14.04

94660

14.04

69762

9

69084

7.75

66633

6.5

58944

5

37282

2.75

Total

126457

21.57

145425

21.57

116271

15

115883

13

112763

11

94311

8

67786

5

<!-- page 49 -->

49
Note: Divisible pool is reckoned as roughly 85 percent of Gross Tax Revenue. GTR is projected assuming a very low 15% annual growth over
2008-09 B.E. The percentage of growth is not material here as the purpose is showing comparative proportions.

7.10

The distribution of percentages (and amounts) shown in Table 7.4 are indicative. The idea is

to illustrate our point that, under the revised pattern suggested, there will be no serious difficulty in
providing adequate funds for those three items subject, of course, to the basic idea that Centre should
withdraw from Centrally Sponsored Schemes

(including direct releases) relating to areas coming

within States’ powers. However we note the fact that at the time of preparation of Central budgets,
the distribution of funds among the three items (other non-plan grants, non-NCA assistance and
Centrally Sponsored Schemes) will depend on the requirement for each, as judged by the Centre.
When the aggregate for the three items is taken the reduction in the years after 2010-11 will be
nominal as the buoyancy will make good the fall in availability of funds.

7.11

To summarise, we suggest that Finance Commission may recommend increase in States’ share

of Central taxes from 30.5 percent to 50 percent of the divisible pool, spread over each of the five
years from 2010-11 to 2014-15 as 40 percent, 42 percent, 44 percent, 47 percent and 50 percent
respectively of the divisible pool. The Commission may also fix a cap of 65 percent of the divisible pool
of each year, for the total transfer of (non-loan) resources from Centre to States, as indicated in Table
7.3.
7.12

In this context, we would suggest that Finance Commission should also review the calculation

for arriving at the divisible pool from the gross tax revenue in the Central budget. Going by the figures
of gross tax revenue and States’ share as given in the Central budget 2008-09, the divisible pool is
roughly 85 percent of gross tax revenue. This difference between gross tax receipts and the divisible
pool does not, prima-facie appear reasonable. That is why we suggest that the Finance Commission
may review the calculation so that States do not lose revenue on account of any flaw in the method of
arriving at the amount in the divisible pool.
7.13

We also suggest that the Commission may recommend that every year Finance Ministry should

prepare a detailed statement of the amount given to each State under each of the categories and
present it in the National Development Council meeting.

It will be helpful if that statement would also

be discussed in Parliament so that Members of Parliament would get a clear idea about the allocation
to different States.

<!-- page 50 -->

50
7.14

Instead of indicating a cap on resources transferred to States on the basis of past actuals, the

system suggested in this chapter (linkage to the divisible pool as percentage) will be better.

That will

be much more transparent and can be operationalised while preparing the Central budget for each
year.
7.15

Above all, this system will initiate the much delayed process of course correction, which is the

main theme of this memorandum.

If that happens, the recommendations of the Thirteenth Finance

Commission will mark the beginning of a new era in the Centre-State financial relations and will alter
positively its course.

<!-- page 51 -->

51
Chapter 8
DEBT POSITION – CORRECTIVE MEASURES
8.1

Debt is the accumulated borrowings to finance fiscal deficits over the years. Rising debt levels

and the attendant interest payments reduce ability of States to open up fiscal space required for
enhancing outlays on essential services. States with manageable debt stock will, on the other hand, be
able to maintain budgetary control and balance, and also attract more private investment to
accelerate and sustain economic growth.

Thus, efficient management of debt constitutes an integral

part of fiscal discipline.
8.2

The debt profile of Kerala (Table 8.1) shows the composition of debt for the last five years.

The Open Market Borrowings (OMB) now constitutes nearly 30 percent of our total borrowings while
the share of small savings is close to 29 percent. The securities issued to the National Small Savings
Fund (NSSF) also come to 21.62 percent as at the end of 2008 though its share will increasingly decline
in the future due to negative net NSS collections, which will lead to a corresponding increase in OMBs.
The change in Central policy of withdrawing loan component from the plan assistance extended to
States, on the recommendation of the Twelfth Finance Commission, has naturally resulted in the
decline of the share of Central loans to just under 10 percent.

Table 8.1 Debt Profile of Kerala
Outstanding as on
31.03.2004

Outstanding as on
31.03.2005

Outstanding as on
31.03.2006

Outstanding as on
31.03.2007

Outstanding as on
31.03.2008

Amt.
Rs cr

%
Share

Amt.
Rs cr

%
Share

Amt.
Rs cr

%
Share

Amt.
Rs cr

%
Share

Amt.
Rs cr

%
Share

1. Internal Debt

17420.94

46.52

21676.22

51.76

25670.72

55.89

29969.15

60.09

34019.16

61.40

(a) Special
Securities
issued to NSSF

4253.35

11.36

7048.30

16.83

9697.75

21.11

11875.28

23.81

11982.02

21.62

(b) Negotiated
Loan

2946.61

7.87

3370.37

8.05

3504.54

7.63

3966.12

7.95

4401.53

7.94

(i) Loans
from LIC

1944.09

5.19

2282.26

5.45

2591.10

5.64

2870.69

5.76

3135.71

5.66

(ii) Loans
from GIC/
Subsidiaries

247.69

0.66

273.93

0.65

298.64

0.65

321.87

0.65

323.61

0.58

(iii) Loans
from NABARD

479.37

1.28

524.62

1.25

341.15

0.74

552.03

1.11

691.15

1.25

(iv) Loans
from NCDC

275.46

0.74

289.56

0.69

273.65

0.60

221.53

0.44

251.05

0.45

(c) Open
Market
Borrowings

8229.30

21.97

9605.69

22.94

11062.00

24.08

12847.33

25.76

16481.17

29.74

<!-- page 52 -->

52

8.3

(d) Others

1991.68

5.32

1651.86

3.94

1406.43

3.06

1280.42

2.57

1154.46

2.08

2. Loans from
GOI

5627.97

15.03

5410.83

12.92

5417.40

11.80

5371.77

10.77

5532.63

9.98

Of which
Share of NSS
collection

323.09

0.86

150.95

0.36

0.00

0.00

0.00

0.00

0.00

0.00

3. Small Savings

14403.33

38.46

14790.82

35.32

14840.93

32.31

14534.26

29.14

15857.77

28.62

(a) Loans
from PF

4904.98

13.10

5498.08

13.13

6104.98

13.29

6778.36

13.59

7904.85

14.27

(b) Treasury
SB

8776.26

23.43

8438.91

20.15

7713.94

16.80

6554.54

13.14

6535.63

11.80

(c) Trust,
Insurance etc.

722.09

1.93

853.83

2.04

1022.01

2.23

1201.36

2.41

1417.30

2.56

TOTAL

37452.24

100.00

41877.87

100.00

45929.05

100.00

49875.18

100.00

55409.57

100.00

Despite improvement in revenue of the State, the present aggregate debt stock remains rather

high. This is because the State, apart from huge expenditure on pay and pension, is committed to
spend more on social sectors and social security and welfare schemes meant for the poor and
marginalised sections of the society. Also, the Finance Commission transfer to Kerala, in terms of its
relative share in horizontal devolution, has been coming down sharply with the result that the State is
constrained to depend more and more on borrowings to keep these commitments.

However, due to

conscious efforts made by the State, debt sustainability indicators have shown improvement in the last
few years.
8.4

Kerala was also one of the first States to enact legislation to cap government guarantees in

order to contain contingent liabilities. The statutory limit fixed by the Legislature in 2003 was the
absolute amount of Rs.14,000 crore. The State has made conscious efforts to contain the liabilities
within this limit. In 2003-04 the total outstanding guarantees stood at Rs.13,996 crore but by the end
of 2006-07 it was gradually reduced to Rs.9496 crore and to Rs.8317 crore in 2007-08.
8.5

Table 8.2 shows that the annual growth rate of debt has declined from 20.58 percent in 2003-

04 to 11.10 percent in 2007-08.

State has been able to improve debt-revenue ratio from 317 percent

in 2003-04 to just 263 percent in 2007- 08. The debt/GSDP ratio has been declining and is presently at
37 percent. The ratio of interest payments to revenue receipts has shown a consistent improvement
with 20.51 percent level in 2007-08. The average rate of interest also remains lower than the GSDP
growth rate from 2002-03 onwards.

However, the overall debt liability of the State has to be further

<!-- page 53 -->

53
reduced to below 30 percent of GSDP for which the State needs further relief from the Finance
Commission.

Table 8.2 Fiscal Indicators of Debt Sustainability – Kerala

Indicators

1999-00

2000-01

2001-02

2002-03

R.D./G.S.D.P (%)

5.27

4.36

3.37

4.77

3.83

3.43

2.63

1.99

2.55

F.D./G.S.D.P (%)

6.60

5.38

4.22

5.78

5.77

4.16

3.51

2.88

4.11

R.D./F.D.(%)

79.87

81.16

79.70

82.54

66.44

82.41

74.83

69.02

62.04

Debt outstanding
/G.S.D.P.(%)

29.40

33.15

34.83

36.00

39.01

39.12

38.60

37.57

37.32

Debt outstanding /T.R.R.(%)

253.98

273.96

297.58

291.99

316.98

310.19

300.30

274.24

262.52

Interest/T.R.R. (%)

24.58

25.86

27.49

27.70

28.17

26.76

24.84

23.04

20.51

R.D./T.R.R. (%)

45.56

36.05

28.77

38.72

31.15

27.18

20.46

14.50

17.93

18.55

12.67

15.25

20.58

11.82

9.68

8.59

11.10

Growth rate of Debt (%)

2003-04

(Rs. crore)

2004-05

2005-06

2006-07

2007-08

Primary Revenue
Surplus/Deficit

-1666.89

-889.45

-116.17

-1171.89

-352.01

-56.38

670.10

1551.75

544.80

Primary Fiscal Deficit/
Surplus.

-2579.29

-1620.20

-779.94

-2043.27

-2210.76

-839.36

-382.45

367.82

-1770.56

Average Rates of Interest (%)

10.88

10.24

9.79

10.16

9.72

9.11

8.65

8.75

8.22

G.S.D.P.

68617.02

72143.42

77385.36

86275.16

96012.06

107053.67

118998.19

132738.53

148485.00

5.14

7.27

11.49

11.29

11.50

11.16

11.55

11.86

Growth rate of G.S.D.P.(%)
Source: Finance Accounts, Kerala budget documents

8.6

Previous Finance Commissions have recommended various measures to reduce the debt burden

of States but relief to States on this account has not been significant. The outstanding debt of all
States which stood at Rs.1,28,155 crore in 1991 had risen to Rs.13,78,663 crore at the end of March,
2008.

The total outstanding Central loans to all States during the same period went up from Rs.73,521

crore to Rs.1,65,502 crore.
8.7

The Twelfth Finance Commission suggested discontinuation of the Fiscal Reform Facility

recommended by the previous Commission as it failed to provide adequate relief to States. The
Commission felt that incentives for fiscal performance should be built into the debt write-off package
and therefore recommended the introduction of a debt write-off scheme linked to the reduction of
revenue deficit of States. The Debt Consolidation and Relief Facility (DCRF) consist of (a) a general
scheme of debt relief through debt consolidation and re-schedulement and (b) a debt write-off scheme

<!-- page 54 -->

54
based on fiscal performance. The general scheme of debt consolidation is applicable to all States that
enact Fiscal Responsibility Legislation (FRL) with prescribed clauses, inter alia, to eliminate revenue
deficit by 2008-09 and to reduce fiscal deficit to 3 percent of GSDP by 2008-09 whereas the debt writeoff scheme is linked to the absolute amount by which revenue deficit is reduced, in each successive
year during the award period, from the base level compiled by the Commission.

Consequently, the

total amount of loans of all eligible States thus consolidated stands at Rs.1,09,977 crore and the
benefit of debt waiver for all States together, as of 31-03-2008, is a mere Rs.13,285 crore only (i.e.
8.03 percent of the total outstanding debt to Centre).
8.8

These clauses prescribed in the FRL are applicable across all States alike regardless of their

initial levels of revenue and fiscal deficits and debt GSDP levels. This is not a correct approach. This
not only strikes at the root of fiscal autonomy and space available with States, divergent situations in
States in terms of fiscal capacity differentials, patterns of expenditure and development priorities are
not amenable to uniform fiscal reduction targets.

The basic fiscal principle that different States can

have different levels of sustainable fiscal and revenue deficits needs to be recognised.
Central government has not been able to adhere to their FRBM targets.
approach is neither desirable nor rational.

Even the

Thus, ‘one size fits all’

Hence, it is not fair and reasonable to bind States to rigid

fiscal targets and make the benefit of debt consolidation and waiver contingent on achieving such
targets.

Accordingly, States should be allowed to pursue their own fiscal correction strategy to

manage fiscal situation without prejudice to the imperative need for continued growth and socio
economic development.
8.9

So long as fiscal deficit is kept within manageable limits and the borrowed funds are utilised

for capital investments, States’ share in Open Market Borrowings can be enhanced appropriately,
though subject to prudent levels of sustainable debt. At present, States’ share of OMBs comes to only
about 20 percent while Centre retains the other 80 percent. Since this is often the cheapest source of
funds, States’ share may be fixed at 33.33 percent in 2010-11 which may be steadily increased to 50
percent by 2014-15. In the case of fiscally weak States facing difficulty in raising loans from the open
market, Centre can extend assistance through loans with interest aligned to the market loans.
necessary to enable States to spend and raise capital expenditure.

This is

<!-- page 55 -->

55
8.10

In paragraph 2.17 of this memorandum we have, as part of the course correction, suggested

that Central assistance to States should not have any loan component except back to back external
aid. The new pattern of Central transfers proposed in Chap ter 7 also does not envisage any loan
component. But if the Commission decides to continue with the existing pattern, we request that the
following suggestion on Central assistance may be considered favourably.

8.11

The prevailing grant-loan ratio of 30:70 in the Central assistance to State plan schemes was

fixed long ago when the revenue component of plan schemes was 30 percent. But now the proportion
of revenue relative to capital in plan expenditure of both Centre and States has increased
considerably. Table 8.3 shows the present composition of plan expenditure of all States.

Table 8.3 Revenue component of plan expenditure - All States

(Rs. crore)

Plan Expenditure

1999-00

2000-01

2001-02

2002-03

2003-04

2004-05

2005-06

Revenue Account

38308

41809

46715

47842

51349

60987

69626

Capital Account

32012

36806

33424

40761

51326

58825

74967

Total

70320

78615

80139

88603

102675

119812

144593

Rev /Plan
Expenditure (%)

54.48

53.18

58.29

54.00

50.01

50.90

48.15

Average

52.72

Source: State Finances- A study of budgets, RBI (various issues)

8.12

The average revenue component of the plan expenditure of all States from 1999-00 to 2005-06

is more than 52 percent. In Central plan expenditure, the revenue component has gone up from 61.43
percent in 1999-00 to 83.84 percent in 2005-06. Hence, it is high time that the ratio is refixed. It may
be recalled, the Twelfth Finance Commission recommended that in future the Central Government
should not act as an intermediary for raising loans for the States in respect of the loan component of
the Central plan assistance to States but instead should allow them to approach the market directly.
The Thirteenth Finance Commission may take the next logical step and recommend enhancing the
grant portion of Normal Central Assistance from 30 percent to 50 percent which will also help States to
reduce the debt burden to that extent.
8.13

As stated earlier, the Twelfth Finance Commission had recommended a general scheme of debt

relief through debt consolidation and reschedulement.

While this is a useful initiative taken by the

Commission and has helped many States to improve their debt position, some of the States continue to

<!-- page 56 -->

56
have huge negative borrowings in terms of net receipts from Centre mainly due to past Central loans
and accumulated interest thereon.

8.14

The Central loans are now a relic of the past as Centre no longer gives loans to States as

recommended by the Finance Commission.

In fact, States have over the years already made

repayments of principal and interest to Centre far in excess of what they have borrowed.

Kerala’s

position on net receipts on account of the borrowings from Centre had turned negative from as early
as 2000-01 onwards. It is evident from Table 8.4.

Year

8.15

Table 8.4 KERALA- Loans from Central Government
(Rs. crore)
Total payment
Net Receipt from
Gross
Repayments
Interest paid
to Centre
Centre
Receipts
(3+4)
(2-5)

(1)

(2)

(3)

(4)

(5)

(6)

1999-00

1072.97

246.95

703.77

950.72

122.25

2000-01

483.11

284.01

732.27

1016.28

-533.17

2001-02

780.70

536.12

778.56

1314.68

-533.98

2002-03

1192.86

1004.44

805.02

1809.46

-616.60

2003-04

968.17

1875.09

809.92

2685.01

-1716.84

2004-05

1482.11

1699.25

671.60

2370.85

-888.74

2005-06

603.29

596.71

436.44

1033.15

-429.86

2006-07

205.01

250.64

432.73

683.37

-478.36

2007-08

416.43

255.57

429.48

724.04

-307.61

TOTAL

7204.65

6748.78

5799.79

12587.56

-5382.91

Therefore, the Commission may take the next logical step to recommend waiver of all past

Central loans and interest thereon.

If this is not possible, at least 50 percent of this liability should be

waived. This will help States with high debt stock to further improve their debt position.
8.16

NSSF loan is another area the Commission should look at.

In the debt consolidation

recommended by the Twelfth Finance Commission, NSSF liabilities were not included, technically
these not being Central loans. In this context, it may be noted that States have pointed out earlier
that the funds they receive are out of the net NSS collections and not the gross collections.
Repayments and payments of interest to the depositors are taken care of by fresh deposits to the NSS
Fund and the process goes on perpetually.

Taking note of this, the 7th Finance Commission did

<!-- page 57 -->

57
recommend consolidation of small savings loan outstanding against each State at the end of 1978-79
and treating this as loan in perpetuity. However, this was not carried through subsequently.

It is in

this context that the Thirteenth Finance Commission may consider this issue and provide some relief to
States. We are of the view that such relief, if not in terms of complete waiver of past loans, could be
allowed in the form of alignment of rates of interest on the loans, including the past loans, with the
rates of interest being given to the investors after adjusting for cost of collection. This is particularly
necessary for those States which have to pay considerable amounts of repayments to NSSF whereas
receipts to them from the Fund are minimal. Table 8.5 indicates that Kerala will be required to repay
to NSSF an amount in the range of Rs.1400 – 1500 crore each year during the award period but no
receipts from the Fund will accrue to it during this period.

Table 8.5
Year
(1)
1999-00

KERALA - Loans from NSSF
Amount
Amount
Interest
repaid
received from
Paid to
to
NSSF
NSSF
NSSF
(2)
(3)
(4)
571.37

(Rs. crore)
Total
Net amount
payment to
received by
NSSF
State
(3+4)
(2-5)
(5)
(6)
0.00
571.37

2000-01

440.15

56.82

56.82

383.33

2001-02
2002-03

462.56
832.31

143.28
192.22

143.28
192.22

319.28
640.09

2003-04

1946.96

263.32

263.32

1683.64

2004-05

2794.95

455.39

455.39

2339.56

2005-06
2006-07

2678.02
2228.10

28.57
50.58

720.91
971.46

749.48
1022.04

1928.54
1206.06

2007-08

180.45

73.70

1164.60

1238.30

-1057.85

2008-09

0.00

115.32

1151.50

1266.82

-1266.82

2009-10
2010-11
2011-12

0.00
0.00
0.00

212.67
352.42
486.32

1139.81
1118.87
1084.65

1352.48
1471.29
1570.97

-1352.48
-1471.29
-1570.97

2012-13

0.00

597.72

1037.72

1635.44

-1635.44

2013-14

0.00

606.74

980.20

1586.94

-1586.94

2014-15
0.00
606.74
921.82
1528.56
-1528.56
Note : From 2008-09 onwards estimates/forecasts are based on the assumption that no
amounts are likely to be received from NSSF due to negative NSS Collection
8.17

The State Government therefore strongly urges that the Commission may look into these

aspects while reviewing the working of the DCRF as required by the terms of reference and suggest
corrective measures, as was done by the previous Commission, to enable States to maintain a
sustainable debt profile.

<!-- page 58 -->

58
Chapter 9
STRENGTHENING OF LOCAL SELF GOVERNMENTS

9.1

Local Self Governments (LSGs) are closer to the people and work in a context of face-to-face

democracy.

This confers on them a lot of advantages like proper delineation of people’s priorities,

greater congruence between needs and expenditure, better public participation in development,
exploitation of local production possibilities, use of cost effective and locally suitable technologies,
proper maintenance of assets, mobilisation of contribution from public in terms of manpower and
materials, greater transparency, accountability etc.
9.2

Strengthening of LSGs is essential to tap their full potential to achieve effective and efficient

governance especially in delivering minimum needs, public services and reduction of poverty.

Apart

from transfer of mandated functions and functionaries, adequate funds have to devolve to local bodies
commensurate with their responsibilities as a third tier of governance.

States are under an obligation

to do so in the light of the 73rd and 74th amendments to the Constitution.
Approach of the Central Finance Commissions
9.3

Even though Article 280 was amended after the Tenth Finance Commission was set up, it

considered the amended Article and took the following two approaches which have tended to
influence the later Finance Commissions.
(i) Decentralisation is fiscally neutral and does not entail any extra financial burden on States.
(ii) There is no need to transfer resources from Centre to States in view of decentralisation.
9.4

However, a grant at the rate of Rs.100 per capita of rural population as per 1971 census

was recommended.

Further, it debarred the use of this amount for salaries and wages and directed

States to prepare detailed guidelines for their utilisation. The Eleventh Finance Commission dwelt on
measures which States could adopt to strengthen LSG revenues. It recommended adhoc annual grants
to LSGs and focused on critical activities like maintenance of accounts, development of data base and
audit. The Twelfth Finance Commission enlarged the grant to Rs. 25,000 crore but it tended to limit
LSG fiscal needs to the traditional civic functions of water supply and sanitation.
Critique of the approach of the Finance Commissions

<!-- page 59 -->

59
9.5

The Finance Commissions have tended to view decentralisation as a zero sum game as if

the functions devolved on LSGs from the State Governments result in a simple displacement of preexisting functionaries and funds and do not involve additional expenditure needs.

This has not been

borne out by experience. The Finance Commissions have not recognised the role of LSGs in the
developmental sphere particularly in bringing about economic development and social justice; they
have more or less confined themselves to the traditional view of LSGs as civic bodies whereas the
Constitution

envisages

their

transformation

into

“institutions

of

self-government”

performing

predominantly developmental functions. They have not attempted to identify the additional staffing
requirements of LSGs even after the transfer of functionaries by the State Government.

Since LSGs

are fledgling institutions their capacity needs to be specially strengthened in the formative stages.
They have not succeeded in identifying what constitutes good decentralisation and what the features
of effective LSGs are.

This is evident in the formulae developed by the Finance Commissions for

distribution of grants. They have ignored the potential for incentivising States to decentralise in the
larger interests of good governance and efficient application of resources; simultaneously they have
failed to reward good performers which would have motivated others to move faster.
9.6

Thus, the Thirteenth Finance Commission has the rare opportunity to break new ground by

giving a push for decentralisation of the right kind to achieve the ultimate objective of value for
money in public expenditures, particularly those intended for the common man.

Kerala’s Decentralisation initiatives
9.7

Kerala followed a rare, unorthodox, big bang approach to decentralisation – devolving a

large basket of functional responsibilities along with staff and more than matching funds, all in a short
space of time.

This resulted in a series of reversals like giving responsibilities and then building

capacity, giving power and then setting up proper systems for its exercise and giving funds and then
putting in place procedures for their use and accounting.

Kerala is the acknowledged fore-runner in

the implementation of the constitutional mandate for strengthening LSGs and its decentralisation
approach and methodology have been rated as the best in the country. In fact, it is a national model
with tremendous scope for replicability.

The arduous and risky path-breaking exercise of the State can

be utilised by others for effortlessly going ahead with their decentralisation plans.

A separate

<!-- page 60 -->

60
document on Kerala’s decentralisation is submitted to the Commission.

However, its salient features

are enumerated below : -

(i)

Transfer of a wide range of functions to its Local Self Governments – these include: Primary and Secondary Health, Pre-primary, Primary and Secondary Education, Basic Technical
Education, Nutrition Security, Social Security other than Welfare funds, Poverty Reduction,
Women and Child Development (about 90 percent), Connectivity other than major district roads
and highways, Water Supply (about 50 percent), Agriculture Development (about 75 percent),
Social Justice (about 2/3 rds). Thus there is sharp mapping of functions and responsibilities among
different tiers of LSGs and a rational division of labour between the State and LSGs. In this
scheme of things, human development, poverty reduction, local economic development and
provision of minimum needs including housing, sanitation, power, water and connectivity are
now predominantly a Local Self Government responsibility.

(ii)

Devolution of funds matching expenditure responsibilities, in a largely untied manner facilitating
considerable local autonomy in prioritisation and allocation of resources – the State gives about
a quarter of its State plan in this fashion.

(iii)

Transferring staff to LSGs to discharge the transferred functions in a dual control system – even
while the State Government is the staff-creating and cadre-controlling authority, LSGs have full
freedom in assigning work, supervising its execution, reviewing performance and even imposing
minor punishments, if required.

(iv)

Setting up of independent umpiring institutions like Ombudsman and Appellate Tribunal to bring
about accountability even while reducing executive control over Local Self Government
functioning.

(v)

Enhancing financial and social accountability through due process in budgeting, transparency in
decision

making,

particularly

selection

of

beneficiaries

and

expenditures

and

mandatory

reporting of performance to constituents.
(vi)

Participatory planning to ensure incorporation of people’s priorities.

(vii)

Institutionalised space for formal people’s participation in governance – in priority setting, in
implementation and in monitoring.

9.8

From the point of view of the Finance Commission, the following features of fiscal

decentralisation of Kerala should be interesting.

<!-- page 61 -->

61
(i)

The Local Self Governments of Kerala, namely, the Village Panchayats, Municipalities and
Corporations have very strong own tax domain consisting of property tax, profession tax,
entertainment tax and advertisement tax.

A service tax is in the offing.

The Village Panchayats

of Kerala mobilise the highest own revenue in the country – more than Rs. 100 per capita.
(ii)

Kerala transfers funds to LSGs in three streams – Development Fund, Maintenance Fund and
General Purpose Fund (Table 9.1).
Table 9.1 Devolution to LSGs
Year
2003-04
2004-05
2005-06
2006-07
2007-08
2008-09 (BE)

(iii)

(Rs. crore)

Development
Maintenance
General
Expenditure
Expenditure
Purpose
1284
*415
991
174
192
1008
307
250
1400
350
300
1540
385
330
1671
398
363
* Includes maintenance expenditure also.

Total
1699
1357
1565
2050
2255
2432

It has to be specially mentioned that the funds transferred in the three streams are totally
investible and ar e practically untied and these constitute the highest level of fiscal transfers to
LSGs in the country, in relation to State Budgets.

Further, unlike other States, salaries and

pensions of transferred staff like teachers, doctors, engineers etc., are paid directly by
Government and do not constitute a charge on the transferred resources.
(iv)

Every single rupee is transferred in a non-discretionary manner through a formula which has
considerable weightage for backwardness, ensuring fairness and equitability.

(v)

There is absolute transparency in the transfer as LSG-wise allocations are indicated in a separate
budget document of the State Government and presented to the Legislature.

(vi)

There is total predictability of future resource flows as the Third State Finance Commission had
recommended an automatic 10 percent annual increase in each of the three streams and this has
been accepted and put into practice by Government.

(vii) The level of assuredness of funds is also very high as once budgeted they are non-divertible.
(viii) The smoothness of fund flow is also a special feature.

Development Fund is transferred in 10

monthly instalments, Maintenance Fund in 10 monthly instalments and General Purpose Fund in
12 instalments automatically at the beginning of every month.

<!-- page 62 -->

62
(ix)

The General Purpose Fund is non – lapsable; Development and Maintenance Funds can be carried
forward to the extent of 20 percent every year.

(x)

A highly participatory budgeting process is in vogue.

Costs of Decentralisation
9.9

The experience of Kerala shows that decentralisation involves additional costs by way of

the following:
(i)

The service areas of institutions like primary health centres, veterinary hospitals, and krishi
bhavans are coterminous with village Panchayats.
terms

This calls for provision of minimum level in

of infrastructure, personnel and services leading to a need for gap filling and

standardisation which is quite costly.
(ii)

The high degree of public participation has had a two-fold effect – increase in awareness leading
to increased access of public services and other entitlements and a greater outreach bringing out
the hitherto marginalised and excluded groups who need to be provided with services and whose
basic entitlements have to be met.

(iii)

The participatory systems increase public demand for proper upkeep of infrastructure and public
utilities which calls for regular maintenance.

(iv)

LSGs have been spending more on creation of capital assets thereby leading to a higher
requirement of funds for periodic maintenance.

(v)

Though Government took a firm policy decision that decentralisation should not lead to net
addition of staff as the principle of “work and worker going together” was adopted and put into
practice through placement of staff performing the transferred functions and redeployment of
surplus staff from certain non- transferred departments.

After a decade certain serious

deficiencies have been noted – in accounting staff, in audit staff both internal and external and
in engineering staff.

With computerisation, the need for an IT professional has arisen in all

LSGs.
(vi)

With the onset of new generation communicable diseases like Chickungunya and Dengue, waste
management has assumed special importance in rural and urban areas requiring substantially
increased effort on the part of LSGs, resulting in need for more resources in performing this
traditional civic function.

<!-- page 63 -->

63
(vii) LSGs meet the cost of public water supply standposts and street lights.

With reforms in

electricity and water utilities, market rates tend to be charged pushing up costs to LSGs.
(viii) In the Local Self Government system with five year rotations in reserved seats of women,
Scheduled Castes and Scheduled Tribes there is a high turnover rate touching 85 to 95 percent
every five years.

This coupled with the fact that decentralisation has enhanced the

responsibility of cutting edge staff, who combine in them the function of a Secretary as well as
Head of Department of a Local Self Government, has generated a need for intensive capacity
building.
(ix)

Kerala has now reached the institutionalisation stage in decentralisation, where proper systems
and procedures like office management system, procurement system, public work execution
system, financial, accounting and audit management systems, personnel management system,
data base management system, and the like have to be put in place.
rare chance for basic administrative and governance reform.

Decentralisation offers a

This implies that the existing

systems need to be fundamentally altered and modernised before adoption in the Local Self
Government system. This is a resource-intensive expert task.

9.10
that

These points prove beyond doubt that the basic assumption of the earlier Finance Commissions
decentralisation

does

not

generate

additional

costs

is

not

validated

by

experience.

Decentralisation is not a zero sum game; on the other hand, it introduces a kind of zoom effect
resulting in clear understanding of local requirements and sharper articulation of priorities by the
people calling for proper and better response from Local Self Governments for which they need to be
supported. The Thirteenth Finance commission may therefore recognise this basic fact.
Suggested Approach
9.11

Articles 243 I and 243 Y provide for constituting State Finance Commission to determine the

distribution of the net proceeds of the Stat e’s taxes, duties etc. between the State and the LSGs and
the allocation of such proceeds among the LSGs at all levels. Article 280 (3) (bb) & (c) of the
Constitution provides that it shall be the duty of the Central Finance Commission to recommend
measures needed to augment the Consolidated Fund of a State to supplement the resources of the
Panchayats and Municipalities on the basis of the recommendations made by the Finance Commission
of the State.

If decentralisation was to be a matter between States and Local Self Governments only,

<!-- page 64 -->

64
such an amendment to the Constitution would not have been necessary. Therefore, it is evident that a
portion of the resources to be devolved to the LSGs has to necessarily come from Centre through the
transfers recommended by the Finance Commission.

In this context, the Twelfth Finance Commission

had earmarked Rs.25,000 crore for augmenting the consolidated fund of States

for strengthening the

resources of LSGs. Currently, the total expenditure of LSGs of all States comes to only 1.5 per cent of
the GDP. In case the new pattern of fund transfer suggested in chapter 7 is not acceptable, the State
is of the view that this has to be raised to 5 percent and half of the additional funds should be
devolved to States for LSGs under Article 275.
9.12

Kerala has done commendable work in the area of decentralisation. The spirit behind the 73rd

and 74th amendments to the Constitution has been fully imbibed and functions, functionaries and funds
have been devolved to the Local Self Governments as per the provisions of the Constitution. In the
matter of financially empowering LSGs, Kerala Government has followed a system fully consistent with
the Constitutional provisions.

State Finance Commissions were constituted in time and release of

funds to LSGs was made on the basis of their recommendations. The Third State Finance Commission
prepared its report broadly based on the pattern indicated in paragraphs 8.30, 8.31 and 8.32 of the
Twelfth (Central) Finance Commission Report. It assessed the financial position of each of the 1215
LSGs in the State on the lines indicated in the Twelfth Finance Commission Report. On that basis it
prepared financial profiles for each LSG, showing pre and post devolution (of share of State taxes to
LSGs) position of each. The assessment in respect of one Panchayat is given in Table 9.2 as an
example. This assessment indicated the forecast of

Table 9.2 Financial Profile of Local Self Government
Thrikkakkara Grama Panchayat
Sl. No.

Item

(Rs. In Thousands)
2006-07

2007-08

2008-09

2009-10

2010-11

2006-11

1

Property Tax / Building Tax

8283

9005

9800

10674

11636

49398

2

Profession Tax

6522

7172

7887

8684

9539

39796

3

Entertainment Tax

82

86

91

95

100

454

4

Other Own Taxes

23

26

28

31

34

143

5

Total Tax Revenue

14911

16290

17806

19474

21309

89791

6

Non Tax Revenue

1483

1631

1794

1973

2171

9052

7

Total Own Revenues

16394

17921

19600

21448

23480

98842

<!-- page 65 -->

65
8

Management & Collection
Expre.

2825

3108

3419

3760

4136

17248

9

Civic Services Expenditure

12076

13284

14613

16074

17681

73728

10

Other Expenditure

0

0

0

0

0

0

11

Repayment of Debt

1205

1326

1459

1604

1765

7359

12

Total Expenditure

16107

17718

19490

21439

23582

98336

13

Deficit / Surplus

286

203

111

9

-103

506

14

Third SFC Funds ( Excluding
Maintenance Funds)

18579

20437

22480

24728

27201

113425

15

Net Position

18865

20640

22591

24738

27099

113932

16

ARM

1232

1355

1491

1640

1804

7521

24082

26337

28902

121453

Funds Available for
17
Developing and Expanding
20097
21995
Services and Institutions
Source: Third State Finance Commission (Kerala) Report - Appendix II

LSGs’ own revenue, their expenditure on civic functions, the impact of share of State taxes (as
recommended by the State Finance Commission) and reasonable yield from additional resource
mobilisation as well as prudent level of borrowing.

Following this pattern the Third State Finance

Commission arrived at an assessment of funds available with each LSG, after meeting their
requirements on discharging civic functions, for utilising in developing and expanding the institutions
and services transferred to them by the State Government. That, according to the Third State Finance
Commission, would be the amounts each LSG should generate (including tax share received from State
Government) for development, consistent with the State Government’s policy perception that LSGs are
not merely agencies to take care of civic services but are also agents of economic development at the
grassroots level.

However, the State Finance Commission had to limit devolution of tax share to what

the State Government could afford.

9.13

The declared policy of the State Government since 1995 has been to transfer at least 35

percent of the State Plan outlay (including State Sponsored Schemes or 1/3rd of State plan outlay
excluding such schemes) each year to LSGs as reported in the State Finance Commission Reports. The
Third State Finance Commission recommended transfer of about 25 percent of the total State tax
revenue of the year 2003-04 to LSGs during 2006-07. For the subsequent four years amounts derived by
applying the annual growth of 10 percent were recommended. But this is not enough to meet the
development expenditure of LSGs. Recognising this fact and the policy goal of the State Government it
further recommended that over and above the statutory transfer of funds to Local Self Governments
stipulated by it, the State might provide additional funds for developmental activities subject to

<!-- page 66 -->

66
availability (chapter 12 of its Report). The total amount required by LSGs for the five year period 200611 worked out by the Third State Finance Commission

is Rs.10,772 crore ( Table 9.3 ). The

aggregate amount in 2008-09 has been worked out to

Table 9.3 Fund availability with LSGs
2006-07

2007-08

2008-09

2009-10

2010-11

2006-11

1773

1945

2136

2345

2574

10772

Total amount available
with LSGs for development
expenditure, including
share of taxes

Rs. 2136 crore.

(Rs. crore)

If 35 percent of the State Plan of 2008-09 (plan size being Rs.7700 crore) is to devolve

to LSGs for development expenditure, the additional amount required will be Rs 2695 crore thus
leaving a gap of Rs. 559 crore in one year. On projecting a nominal 10 percent annual growth beyond
2010-11 up to the Thirteenth Finance Commission award period, this will add up to Rs 4129 crore.
Considering the extent of funds already being given to the LSGs and the availability of resources, the
State is certainly not in a position to provide such additional funds. Paragraph 8.30 of the Twelfth
Finance Commission Report concludes that such gaps that remain after the above exercise would then
constitute the basis for the measures to be recommended by the Central Finance Commission.
9.14

However, we do recognise that the Commission may not be able to give special grant under

Article 275 on the basis mentioned above as many of the States have not followed the Constitutional
amendments and put in place the credible mechanism of State Finance Commission.

In such a

situation, the State urges the Thirteenth Finance Commission to augment the consolidated fund of the
State for strengthening the resources of the LSGs through grants under Article 275 by using the
following formula:
Criteria

Weight (percentage)

Population (1971 census)

60

Geographical area (adjusted)

5

Income distance (scaled to 1971 population)

10

Index of decentralisation

25

The parameters of index of decentralisation should be (i) percentage of untied investible funds
devolved to LSGs as percentage of State Budget and (ii) percentage of own revenue of LSGs as
percentage of State’s Own Revenue.

<!-- page 67 -->

67
9.15

In addition, apart from the above grant that the State would be eligible for augmenting the

resources of the local bodies, we are of the view that Kerala needs to be suitably rewarded for its
trend setting role it has played in developing and strengthening its Local Self Governments at great
cost and effort. This has a two-fold justification – the processes, procedures and systems developed by
Kerala can be adopted at no cost by other States and such a reward could motivate them to perform
well in this regard. Moreover, Local Self Governments in Kerala have reached a stage of development
where they now need funds to ensure capacity building, one time maintenance and rehabilitation
expenditure for transfer of single Panchayat water supply schemes from Kerala Water Authority to
Village Panchayats, solid waste management and introduction of electronic voting machines to further
strengthen the grass roots democracy and enhancement of social security through a partnership of
Local Self Governments and Community Based Organizations of poor women under Kudumbashree
following the ‘Asraya’ model which has won the Prime Minister’s Award as a best practice in good
governance.

Hence the State would urge the Commission to provide additional special grants under

Article 275 in all these areas for which detailed proposals are submitted to the Commission separately.

<!-- page 68 -->

68
Chapter 10
DISASTER MANAGEMENT

10.1

Natural disasters are events of nature which cause sudden disruptions to the normal life of a

society.

They also invariably cause damage to property and life to such an extent that normal social

and economic mechanisms that are locally available to the society become inadequate to restore
normalcy.

The State of Kerala is vulnerable to a number of natural calamites such as coastal erosion,

floods, cloudbursts, droughts, lightning, landslides etc. with locational and geographical features
contributing to them. Almost all the districts in the State are multi-hazard prone. Most of the 560 km
coastline of Kerala is frequently subjected to coastal erosion of varying degrees.
10.2

Disaster management occupies an important place in the State's policy framework as it is the

poor and the under-privileged who are often worst affected on account of calamities/disasters.

A

paradigm shift in the approach to disaster management from response to preparedness is necessary
because investments in mitigation are much more cost effective than expenditure on relief and
rehabilitation.

Disaster Management is to be considered a multi-disciplinary function and integrated

into all sectors of development.
10.3

As per sub-section (1) of section 48 of the Disaster Management Act 2005, the State

Government is required to establish the Disaster Response Fund and the Disaster Mitigation Fund at the
State Level and Districts Level.

After establishing these funds, the State Disaster Management

Authority and the District Authority will have to avail of sufficient funds for managing the various
disasters.
10.4

At present, the State Government has the Calamity Relief Fund (CRF) for the natural calamity

relief activities in the State.

It consists of 75 percent Central share and 25 percent State share.

Experience has shown that the funds available for calamity relief operations have been insufficient
given the occurrence and magnitude of the natural calamities in Kerala.

The CRF earmarked for the

period 2005 - 2010 to Kerala is of the order of Rs.472.42 crore out of which the Central contribution is
Rs.354.32 crore.

For a State like Kerala which faces multiple calamities almost every year, the corpus

of the Fund is very meagre.

<!-- page 69 -->

69
10.5

The Calamity Relief Fund now available with the State is so inadequate that there is no money

left for constituting the Response and Mitigation Funds at the State Level and District Level.

Hence

the funds available for relief activities should be enhanced considering the natural calamities
frequently occurring in Kerala and the need for special attention to preventive and mitigating
measures.
10.6

In this backdrop, the State will urge the Commission to enhance the corpus of the CRF to 10

percent of the amount of the annual State Plan size of the concerned State and also increase the
contribution of the Centre to the Fund to 90 percent. In the case of severe calamities, advance drawal
up to 100 percent of next year’s provision may be allowed. The unspent balance of CRF at the end of
the five year plan period may be allowed to be used as a resource for the next plan. In view of the
regional disparities in terms of costs on account of labour, materials, terrain etc., States may be
permitted to fix their own norms for utilisation of the CRF. For instance, unit cost to determine the
quantum of loss, provision of debt relief to people affected by natural calamities in certain situations
etc. may be allowed from the CRF. Additional grants may also be provided to set up the Response Fund
and the Mitigation Fund at State and District levels.
10.7

Sea erosion is one of the recurring natural hazards affecting the coastline in the State.

Generally, it occurs as part of erosion - accretion cycle. It is feared that with the predicted rise in sea
level, as a result of the green house effect, the rate of beach erosion and loss of coastal properties are
going to increase. Kerala has 560 Km long coastline; more than half of the area of the State is only 4
meters above sea-level and encroachment by the sea severely affects the economy of the State.
Kerala has 44 rivers crisscrossing the State and most of them flow into the sea.
second largest density of population after West Bengal.

The State has the

A substantial part of population not only lives

close to the coastline but also lives off it and they belong to the vulnerable sections of the society.
With high density of population and major establishments along the sea coasts, large investments have
to be made to erect shore protection structures and take up other mitigating measures.
10.8

Similarly, lightning strikes also cause heavy loss of lives in the State.

Looking at the Statistics,

Kerala has high lightning incidence compared to nearby regions. On an average, 188 such incidents
occur every year in which 71 people die and 112 people are injured. The statistics was obtained as a
result of an investigation conducted by the Centre for Earth Science Studies, Thiruvananthapuram.

<!-- page 70 -->

70
Knowing that lightning cannot be prevented, the obvious choice for reducing personal injury is to find
ways to avoid it or take protective measures. It is clear that the people in the State bounded by the
Western Ghats have a problem different from elsewhere in regard to lightning and so we have to take
special efforts to combat this hazard.
10.9

Non-inclusion of sea erosion and lightning as natural calamities entails on the State a huge

expenditure to rehabilitate the victims and provide them with food and clothing.

In the last 20 years,

4000 deaths have occurred in the State due to lightning and sea-erosion, for which no financial
assistance under Calamity Relief Fund could be given or used. The State has recently witnessed a new
phenomenon of heavy unseasonal rains causing massive water logging and extensive damage to crops.
Therefore, the State earnestly urges the Commission to recommend including sea erosion, lightning
and waterlogging among natural calamities.
10.10

The National Calamity Contingency Fund (NCCF) was set up with an initial corpus of Rs 500

crore on the recommendation of the Eleventh Finance Commission. In view of the magnitude of the
severe calamities faced by various States, often at the same time, the corpus has proved to be
inadequate. Hence, there is a need to enhance the corpus. An annual rate of inflation of 8 percent
may be added for each year since the constitution of the Fund to peg the corpus at Rs.1000 crore
during the award period of the Thirteenth Finance Commission. The Commission may also recommend
suitable measures to avoid delay and discretion in providing assistance by Centre from the NCCF to the
needy States.

<!-- page 71 -->

71
Chapter 11
SUMMARY OF MAIN SUGGESTIONS
11.1

The Thirteenth Finance Commission has the unique opportunity to initiate a much needed

course correction reversing a trend that has been eroding the very concept of fiscal federalism (vide
Paras 1.6 & 1.7).
11.2

The steady decline of fiscal federalism over half a century as briefly narrated in chapter 2

should be reversed. It is also necessary to correct the impression that State Governments are
inherently incapable of managing their finances (vide Para 2.14).

With these two objectives, a course

correction has to be attempted on the following lines:
? Primacy of Finance Commission in steering Centre-State financial relations should be reaffirmed. ?
As Finance Commission transfer is the manifestation of a Constitutional right of States to get a share of
Central revenues, it should not be loaded heavily with conditions to be administered by Central
Ministries.
? Primacy of the State Plan (and Gadgil formula assistance) should be reasserted as the vehicle for
developmental efforts.

All priority areas and problems special to each State should largely be tackled

in the State Plan.
? Central plan should not intrude into areas coming within the duties and responsibilities of States
under the Constitution. Developmental schemes in such areas should be mostly left to be tackled by
State Plans.
? To achieve this, the size of State Plans would have to be increased and more Central revenue should
be given as Gadgil formula grants (Central assistance should have no Central loan component – except
back to back external aid).
? Revenue transfers and distribution among States should not cause heartburn either to weak or to
other States.

The range of deviation from average per capita transfer, particularly share of Central

taxes, should be rationalised.
11.3

States’ share of Central taxes should be increased from 30.5 to 50 percent of the divisible

pool. If this cannot be done in one year’s time it may be spread over five years from 2010-11. The
Commission may also indicate a cap of 65 percent of the divisible pool of each year, for the total
transfer of (non-loan) resources from Centre to States, as indicated in Table 7.3.

<!-- page 72 -->

72
11.4

New pattern suggested in chapter 7 for realignment of the different components of

transfer of resources from Centre to States may be recommended for implementation.
11.5

Fix a minimum limit for block grants distributed solely as per Gadgil formula. This should

be distributed among all the twenty eight States on the basis of the various criteria and weights
under the revised Gadgil formula.
11.6

In deciding horizontal devolution, population factor should have the highest weight for

reasons indicated in Paras 5.7 to 5.10.
11.7

When income distance is taken as a factor it should definitely be scaled to population and

that too 1971 population (vide Para 5.11).
11.8

The share of Central taxes may be distributed among States based on the following criteria

and weights: Population - 70 %, Income distance - 10 %, Area (adjusted) - 5 %, Tax effort -10 % and
Fiscal performance - 5 %.
11.9

The per capita (1971 population) share of taxes of the State with the highest per capita

share should not be more than 150 percent of the per capita share of the State, which gets the
lowest per capita share (vide Para 5.18).
11.10

In any direct or indirect application of population factor, population based on 1971 census

should be taken as this has the sanction of Parliament as part of the population control policy
(vide Para 5.19).
11.11

Every year Finance Ministry should prepare a detailed statement of the amount given to each

State under each of the categories and present it in the National Development Council and in the
Parliament.
11.12

It is also necessary to give an annexure showing how each State’s share in Central taxes has

been worked out.

This is absolutely essential in the interest of transparency in deciding such an issue

of great national importance.

11.13

The Commission may also review the calculation for arriving at the divisible pool from the

gross tax revenue in the Central Budget so that States do not lose revenue on account of any flaw in
the method of arriving at the amount.
11.14

The approach to grants-in-aid under Article 275 should be (i) to fill the gap in availability of

revenue account resource on the non-plan side (ii) to fill gap, if any, in the revenue account on the
plan side at the existing level.

(iii) after such gap filling, States with either no per capita surplus or

<!-- page 73 -->

73
only meagre surpluses may be given additional grants under Article 275, on the basis of norms, to
augment their revenue account in order to ensure that adequate surplus is available for capital
investment as required in Para 6(iv) of the ToR.
11.15

Additional grants for State specific needs arising out of special problems may be granted under

article 275 as proposed in chapter 6.
11.16

States’ share of Open Market Borrowings should be fixed at 33.33 percent in 2010-11 which

may be steadily increased to 50 percent by 2014-15. The grant portion of Normal Central Assistance
may be enhanced from 30 percent to 50 percent (vide Para 8.10). All past Central loans and interest
thereon should be waived. In the case of NSSF, rates of interest on the loans including the past loans
may be aligned with the rates of interest being given to the investors after adjusting for cost of
collection.
11.17

Local Self Government expenditure has to be raised from 1.5 to 5 percent of GDP and half of

the additional funds should be devolved to States for LSGs under Article 275 as proposed in

Para 9.11.

Inter-se allocation to States for strengthening LSGs may be determined using the following formula:
Population (1971 census) – 60 %, Geographical area (adjusted) – 5 %, Income distance (scaled to 1971
population) – 10 % and Index of decentralisation – 25 % (vide Para 9.14). Additional special problem
grant under Article 275 also sought for capacity building etc. for LSGs in the State (vide Para 9.15).
11.18

Enhance the corpus of the CRF to 10 percent of the amount of the annual State Plan size of the

concerned State and also increase the contribution of the Centre to the Fund to 90 percent. In the
case of severe calamities, advance drawal up to 100 percent of next year’s provision may be allowed.
States may be permitted to fix their own norms for utilisation of the CRF. Additional grants may also
be provided to set up the Response Fund and the Mitigation Fund at State and District levels. Include
sea erosion, lightning and water logging among natural calamities. Corpus of the NCCF may be raised
from Rs. 500 crore to Rs. 1000 crore.
