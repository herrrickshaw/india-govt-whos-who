---
doc_id: "ddcd6de4e081b1d1"
source_url: "https://sainikwelfare.kerala.gov.in/wp-content/uploads/2025/02/62024SWD.pdf"
ministry: "Department of Sainik Welfare, Kerala"
title: "G.O.(P)No. 6/2024/SWD, Dated 05 -12-2024"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "abfbe2384cbe8b74"
---

<!-- page 1 -->

c

4/

Y6

N,

c3H sl
l0_e_sO

GOVERNMENT'OF
KERALA
Ahrrrrrrrrrrrrrrritract

Sainik Welfare Department- Scheme for providing Employment
Assistance to the dependents of the Defence Personnel and General
Reserve Engineer Force (GREI) / Border Security Force (BSF)
Personnel and Central Armed Police Force Personnel (CAPF)-

Submission of affidavit for the Protection of other eligible
dependents is made mandatory for those who were already
employed under the scheme -Ord,:r's issued.

SAINIK WELFARIi, (A) DEPARTMENT
G.O.(P)N o. 6 120241 SWD Datecl,T'himvananthapuram, 05 -12-2024
Read I G.O(P) No.l l0/02lGAD dated 29.04.2002.
2 G.O(P) No.02/20201SV"D dated 11.03.2020.
3 G.O(P) No.3/2024iSWI) dated 05.08.2024.

4Lr No.DSWl496l2024.C2 dated 24.10.2024 from the
Director in Charge, Sair,ik Welfare Department.

08,;)ER
As per the Governr,rent Order read as lst paper above,
Government introduced a sch:rne for providing Employment
Assistance to the dependents of ihe Defence Personnel andGlneral
Reserve Engineer Force (GREi;) / Border Security Force (BSF)
Personnel attached to rnilitary du,y, killed/disabled/missing in action
or died/disabled/missing due r<, reasons attributable to rnilitary
service in peace time.
2. In the Governmell Orcler read as 3rd paper above it is
made mandatory that the dep,;udents ofDefence per.sonnel and
General Reserve Engineer Forcr: (Qf,lF) / Borcler Security Force
(BSF) Personnel who apply tbr :rnployrnent assistance shail sub,rit

an affidavit for protecting the deceasecl soldier's

rnother/father/widodwidorver thoughout their lil'e and unmarried
sister/ unmaried brother, till he/s[e attains the age of maturity. An

<!-- page 2 -->

dependent

amount equal to 25o/, of the basic pay of the employed violate the
will be recovered from the monthly .uLty of those, who this will
dependents and
condition for the p.o,"",ion of othei eligible
be disbursed to the eligible dependents'

in his letter read
3.The Director, Sainik Welfare Department
the conditions stipulated in
as 4th paper above has requested - that
shall be made
C'or"*ment Order read as -''rd paper above
who were already employed under the
to
Defence
"ppfi*Uf"
scheme for the dependents

ii"

those

ffiloyment assistance

personnel und G"n".oi Reserve Engineer Force (GREF) / Border

-of

Security Force (BSF) Personnel
and are

4.Govemment have examiued the matter in detail
Defence Personnel aml
pleased to order that the dependents
-"lll"
Force
b"n"ral Reserve Engineer Force (GR-EF) / Border Security
in.state service as per the
aBsFi-P;nnel whi were employed
before their
I*ptoy*"nt assistance scheme shait suUmit an affidavit
Office Head for protecting the deceased soldier's
their life and unmarried
mother/fatherlwldowfrviaower thioughout
age of maturity' An
,-i-Jr/ ,n nurried brother, till he/she attains the
the basic pay of the employed dependent
equal to ZSi,
it'" rnonthllz iuiuty of those who violate the
witl be recovered

r*p;;i;
"-"rrt

rt*

if

conditionforthep-,""'io"ofothe":eligibledependentsandthiswill
in the

be disbursea to tr" "rGiurt dep'endints'The instmctions
for taking
Government OrO". ,"uJ u1 third paper

shall be followed

action again* ,frot"- "-ptoy""t' who violate

conditions in the

affidavit.

as 2nd paper above'
5.As per the Govemment Order read
of employment.assistance
Govemment had extended the benefit
Central Armed Police Force
the
of
O"p"na"ntt
the
to
scheme
necessary to make the Protection
Personnel (CAPF) ' It is therefore
assistance scheme for the
employment
the
for
mandatory
statement
p""Lnt'"t (C-APF) also' H-ence the
pofi"""
Central Armed
(GAPF) who
c"*,"iat-"J poti"t Force Personnel
under the scheme shall submit an
apply for employment'ut^t-i*"t"
Central Armed Police Force
a"""used
it'"
protectrng
for
affidavit
iaower throughout their life and
Personnel's moth"r/futf;

;;;##;i

ftt""

"tl*iJ"*l*

tIl

<!-- page 3 -->

unmarried sister/ unmarried brother, till he/she affains the age of
maturity. An amount equal to 25Yo of the basic pay of the
employed dependent will be recovered from the monthly salary of
those, who violate the conditions for the protection of other eligible
dependents and this will be disbursed to the eligible dependents.The
instructions in the Government Order read as third paper shall be
followed for taking action against those employees who violate
conditions in the affidavit.
6.The dependents of the Central Armed Police Force
Personnel (CAPF) who were alrc.ady employed in state service as
per the employment assistance scheme shall submit an affidavit
before their respective office head for protecting the deceased

Central Armed Police Force Personnel 's

mother/father/widodwidower throughout their life and unmarried
sister/ unmarried brother, till he/she attains the age of maturity. An
amount equal to 25o/o of the basic pay of the employed dependent
will be recovered from the monthly salary of those, who violate the
condition for protection of other eligible dependents and this will be
disbursed to the eligible dependents.The instructicus in the
Govemment Order read as third paper shall be followed for taking
action against those employees who violate conditions in the
affrdavit.
(By order of the Governor)
BIru PRABHAKAR
SECRETARY
1. The Secretary, Government of India, Ministry of Defence, New
Delhi (with C.L)
2. The Secretary, Government of India, Ministry of Home Affairs,
New
Delhi (with C.L)
3. Adjutant General, Ceremonials irnd Welfare Army Quarters,
DHQPO , New Delhi (with C/L).
4. All District Collectors
5. All Tahsildars
6. TleHead of Departments

,f.fne Director, Sainik Welfare Dr::partment
S.The Principal Accountant Genenrl (Audit),Kerala,

<!-- page 4 -->

Thiruvananthapuram.
9. The Accountant General (A & E), Kerala, Thiruvananthapuram
10. The Station Commander, Military Station Head
euarters,

Pangode,
11. The Chairman, Welfare and Rehabilitation Board,Ministry of

Home Affairs, New Delhi.
12. The Informatuon Officer, Web and New Media, I &pRD
13. Stock File.

Forwarded/B

Section O

I
