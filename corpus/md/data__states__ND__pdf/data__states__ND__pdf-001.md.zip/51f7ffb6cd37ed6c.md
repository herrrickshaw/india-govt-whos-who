---
doc_id: "51f7ffb6cd37ed6c"
source_url: "https://cdn.s3waas.gov.in/s35878a7ab84fb43402106c575658472fa/uploads/2023/11/2023110718.pdf"
ministry: "Dadra And Nagar Haveli"
title: "DNH-RTI-Rules-2005"
date: ""
pages: 6
method: "tesseract:eng"
script: "LATIN"
needs_ocr: false
sha1: "edace31589467292"
---

<!-- page 1 -->

Che
Aadra And Nagar Hateli
Gazette
Wa West claw Ud aN each, uses
’ fy tng
arta uta / Government of india
STAT eaTaT
EXTRAORDINARY
Stoft-& / SERIES - 1
wiferarcot ART watiera
PUBLISHED BY AUTHORITY
eee SS ————————ee
Vol. No. XX_SILVASSA Friday 11th November, 2005 / Kartika 20, 1927 No. 150(A)
SE SS Sa ee
Administration of
Dadra and Nagar Haveli, U.T
Secretariat -Silvassa
(Personnel Section)
No. ADM/LAW/S5 1/2005/874-A Dated 11/11/2005
NOTIFICATION
In exercise of the powers conferred by sub- section (1) of Section 28 read with Section
2(e)(v) of the Right to information act, 2005 (22 of 2005). the Administrator of Dadra and
Nagar Haveli is hereby pleased to make the following rules, namely:-
1. Short title and commencement -(1) these rules may be called the Right to information
4 (Regulation of Fee and Cost) Rules, 2005.
‘
. (2) They shall come into force on the date of their publication in the official Gazette
2. Definitions- In the rules, unless the context otherwise requires:
(a) ‘Act’ means the Right to Information act, 2005
(b) “section” means the section of the Act:
(c) all other words and expressions used herein shall have the meanings assigned to
them in the Act.
3. A request for obtaining information under sub-section (1) of section 6 (i.e. Form of
Application) shall be made in Form-1 (A & B) and shall be accompanied by application fees of
Rs. 25/- through challan in Form-II, payable at treasury (i.e. Dena Bank, Silvassa.)

<!-- page 2 -->

SERIES -1 THE D. & N. H. EXTRAORDINARY GAZETTE 2

4. For providing the information under sub-section (1) of section 7, the fees shall be payable
through challan, at treasury (i.e. Dena Bank, Silvassa) as per the valuation made by the
concerned public information officer at the following rates:

(a) rupees two for each page (in A-4 or A-3 size paper) created or copied:
(b) actual charge or cost price of a copy in larger size paper;
(c) actual cost or price for samples or models;

5. Information through electronic device: For the information obtained in the form of floppy,
Rs. 50/- for each floppy and Rs. 100/- for each CD 1
Note:- Supply of information in Electronic Media Form will be subject to availability :

of necessary facility:

6. For Inspection of Records :

(a) For the purpose of inspection of records, the fees charged per day for the record of
preceding 10 years from the date of application at the rate of Rs.100/- per day.

(b) For each preceding ten years from the first preceding 10 years; additional fees of
Rs. 25/- per day.

Note:- No inspection shall be permissible for more than three hours a day. The inspection shall

be carried out in presence of an officer authorized by the concern public information authority.

7. For obtaining the benefit under proviso to sub- section (5) of section 7, the applicant
should furnish certificate from the appropriate authority that he falls below poverty line.

By order and in the name of the
Administrator, Dadra and Nagar Haveli.
(SATNAM SINGH)

Deputy Secretary (Personnel)

<!-- page 3 -->

SERIES - 1 THE D. & N. H. EXTRAORDINARY GAZETTE 3
PORM -}-A
APPLICATION FORM FOR INFORMATION
(To be filled in English/Hindi/Regional Language)
Dated:
To
The Public Information Officer,
Office of the.
- Department
DNH, Silvassa.
(a) Particulars of the applicant:-
Name:
Age: ‘
ADDRESS WITH PHONE NO. :
{b) Details of the information sought:-
Please indicate the subject matter/file/record etc.)
(i) The period of which the information pertains( years prior to
date of application).
(c) Form/format in which the information sought:
(i) Photo copy
(ii) Floppy; etc.
(d) INSPECTION OF RECORDS;
(i) Does the request pertain to inspection of record ? (Yes/No)
(ii) If yes, the number of days the applicant may take in inspecting the relevant record.
days.
Signature of the applicant.
FOR OFFICE USE ONLY
Date of receiving the application:
. Date of supplying the information:
Within( ) days. Valuation: Rs.
RECEIPT
I received the information as per my application and I am satisfied.
(Signature of Applicant)
Dated :

<!-- page 4 -->

SERIES - 1 THE D. & N. H. EXTRAORDINARY GAZETTE 4
FORM-I-B
FOR OFFICE USE ONLY
REASON FOR REJECTION:
The applicant may, if he so desires, prefer an appeal against this order to the Development
Commissioner/Appellate Authority within 30 days of this order.
Signature of the Public Information Officer
With name & Designation

Place:
Date:

<!-- page 5 -->

SERIES - I THE D. & N. H. EXTRAORDINARY GAZETTE 5
FORM-IL
Original C
Ss
FORM _T. R. 6
CHALLAN NO.
Challan of cash paid into the Sub Treasury/ Dena Bank at.
To be filled by the remitter To be filled by the Department
. Officer of the Treasury
By whom tendered Name or Full Amount {Head of| Account| Order in the
designation Particulars Account | Officer Bank
, and address of Of the by
the person on remittance whom
whose behalf & or adjusta-
money is paid authority ble
(if any)
Name Rs. Date____
Correct
Received
and receipt
Signature Total Signature
and full
designation
of the
Officer
ordering for
Money to be
paid
(in wards) Rupees. To be used only in the case of
remittances to Bank through and
Officer of the Government.
Received payment (in words) Rupees
Treasurer Accountant Treasury Officer

<!-- page 6 -->

SERIES - 1 THE D. & N. H. EXTRAORDINARY GAZETTE 6

OT [Amount
Cheques (with details) |

Ce

Note:

1. Inthe ease of payments at the treasury, receipts for sums less than Rs. 500/- do not
require the signature of the Treasury Officer, but only the Accountant and the Treasurer.
Receipts for cash and cheques paid for service postage stamps should be given in Form
T.R.S

2. Particulars of money tendered should be given on the reverse.

3. Incase where direct credits at the Bank are permissible, the column Head of Account will
be filled in by the Treasury Officer or the Accountant General as the case may be on
receipt of the Bank's daily sheet.

ee
Printed and Published by Asstt. Director, (Plg. & Statistics) at Govt. Printing Press. Silvassa-2005.
PRICE : Rs. 06-00
