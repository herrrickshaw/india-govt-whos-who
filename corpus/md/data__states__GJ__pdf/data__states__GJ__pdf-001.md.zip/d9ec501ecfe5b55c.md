---
doc_id: "d9ec501ecfe5b55c"
source_url: "https://gnlu.ac.in//Content/gnlu/pdf/press-notes/press-note-56-2019.pdf"
ministry: "Gujarat National Law University, Gujarat"
title: "16 GNLU alumni among 197 selected for appointment in Rajasthan Judicial Service"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e53713376adad849"
---

<!-- page 1 -->

GNLU PRESS NOTE No. 56/2019

16 GNLU alumni among 197 selected for appointment in Rajasthan Judicial Service
Gandhinagar, Nov 20, 2019: As many as 16 alumni of Gujarat National Law University (GNLU)
find a place among 197 candidates selected for appointment in the Rajasthan Judicial Service. The
final result of the Rajasthan Judicial Service Examination was declared by the Rajasthan High Court
yesterday.
It is noteworthy that more than 50 GNLU alumni are already working in judicial services across the
country and 10 of them are in Rajasthan Judicial Service. “It is a matter of pride for all of us at
GNLU that GNLU alumni are contributing to the judiciary in the country in such a large number,”
said GNLU Director, Dr S. Shanthakumar.
List of GNLU students who have successfully cleared Rajasthan Judicial Service Examination:
1. Harshita Rathore
2. Himmat Raj
3. Akshat Verma
4. Hanuman Meena
5. Digvijay Detha
6. Pramod Panwar
7. Aakansha Meena
8. Harsh Meena
9. Vijay Kumar Bakoliya
10. Narendra Meena
11. Pooja Meena
12. Monika Dhanol
13. Nidhi Poonia
14. Sonica Meena
15. Neha Khare
16. Naveen Meena
Media Contact:
Ashok Shah
Email: 9909960240, 8849110049

Attalika Avenue, Knowledge Corridor, Koba, Gandhinagar – 382426, Gujarat, India
Ph: +91-79-23276611/12, Fax: +91-79-7878186624, Email: contact@gnlu.ac.in, Website: www.gnlu.ac.in
