---
doc_id: "d58fb7d4ae8fcb67"
source_url: "https://gbu.edu.in/wp-content/uploads/2024/10/RC-2024-25-corrigendum-091024.pdf"
ministry: "Gujarat Biotechnology University"
title: "Rate Contract 24-25 corrigendum (Dated: 09-10-2024)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e724878c30e32c85"
---

<!-- page 1 -->

Corrigendum (Pre-Bid Meeting)
Gujarat Biotechnology University has published a tender on n-procure for a Rate
Contract for Laboratory Consumables, Chemicals, Glassware, Plasticware, Scientific Services,
and Gases, with tender Notice No.: GBU/PURCHASE/RC/2024/01 dated 12/09/2024 under
n-procure tender ID: 106944, dated 12th September 2024. The pre-bid meeting was scheduled
at GBU on 21-09-2024. There were some of the queries regarding the ATC clause and brand
addition requests from the potential participants and following corrigendum is published for
information of all bidders.
Sr. No.

1)

2)

Pre-bid Query
It is mentioned in the tender that the
rate contract will be valid for next
THREE years from the date of
award and the vendors will be
allowed to submit
updated
catalogue once in a year during the
Rate Contract period. How it is
going to be if the catalogue of the
company is updated in every
April/January/October (or any
month in a year)
Request to send Payment advice
after payment because it is difficult
to track the payment.

Response
Vendors are requested to submit the
document (along with other tender
documents) on OEM letter head mentioning
the date or the month when the catalogue is
going to be updated. Certification of the
OEM may be considered to update the
catalogue in the requested month each year.
Price can only revise only once in a year.

Payment advice will be sent for each
payment
List has been prepared according to
university requirement. Based on request
received from vendors in pre-bid meeting
following brand has been allowed to
participate.

3)

Request to add new brand names
in the list

JSGW, G-Biosciences, Shimadzu, Parse
Biosciences, Ott Scientific, GeNei Labs, Cole
Parmer, Advent, BLD, GenetoProtein,
TITAN Biotech, BIOSS and ROCKLAND
ANTIBODIES, Durasil/Durga Glass works,
ChromoSep, SolRes Lab
