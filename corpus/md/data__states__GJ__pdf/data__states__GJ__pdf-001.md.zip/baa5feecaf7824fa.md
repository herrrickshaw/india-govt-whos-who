---
doc_id: "baa5feecaf7824fa"
source_url: "https://cgm.gujarat.gov.in/uploads/publications/NotificationMinimumalternatepremium.pdf"
ministry: "Commissioner of Geology and Mining, Gujarat"
title: "Download"
date: ""
pages: 2
method: "tesseract:guj+eng"
script: "LATIN"
needs_ocr: false
sha1: "fda7a0d377985be4"
---

<!-- page 1 -->

| NOTIFICATION
Industries and Mines Department,
Sachivalaya, Gandhinagar.
Dated the 30" June, 2025
| Gujarat No. GHU/2025/28/GMR/102024/1402/CHH: - WHEREAS the Government of Gujarat,
Mal vide Government Notification. Industries and Mines Department. No.
| Concession GHU/2024/23/GMR/102024/1402/CHH. dated the 12" December. 2024 had notified that.
Rules, 2017. all the lease holders holding quarry lease for mineral Ordinary Sand. granted without
| auction, or under rule 29 of the Gujarat Minor Mineral Concession Rules, 2017 (herein
afer referred to as “the said rules”), shall pay an amount equivalent to hundred per cent. of
the royalty in addition to the royalty for mineral Ordinary Sand as specified under
Schedule IV of the said rules, towards minimum alternate premium, as specified under rule
58A of the said rules;
AND WHEREAS, the Government has now decided to levy minimum alternative
| premium, as specified under rule 58A, for all the remaining minor minerals specified under
Schedule IV of the said rules:
| NOW THEREFORE. in pursuance of rule 58A of the said rules the Government of
Gujarat hereby notifies that, all the lease holders holding quarry lease for minor minerals
granted without auction, or under rule 29 of the said rules shall pay, in addition to the
royalty, an amount equivalent to hundred per cent. of the royalty for minor minerals as
specified under Schedule IV of the said rules, towards minimum alternate premium, as
specified under rule 58A of the said rules :
Provided that no amount towards minimum alternate premium shall be required to
be paid by the lease holder of minor minerals granted under Chapter- IIA of the said rules.
By order and in the name of the Governor of Gujarat,
NG Patel)
Deputy Secretary to Government
To.
* Personal Secretary to Hon. Governor, Rajbhavan, Gandhinagar.(*By Letter)
- Additional Chief Secretary to Hon’ble Chief Minister, Office of Chief Minister, Swarnim
Sankul-1, Sachivalay, Gandhinagar
- Additional Secretary to Chief Secretary, Chief Secretary’s office, Sachivalay, Gandhinagar.
- Office of Principal Secretary, Industries and Mines Department, Sachivalay, Gandhinagar. |
Page 1 of 2

<!-- page 2 -->

» Office of Principal Secretary. Finance Department, Sachivalay. Gandhinagar
- The Commissioner, Geology and Mining, Block-15, Dr. Jivaraj Maheta Bhavan, Gandhinagar.
- All District Collectors. (By E-Mail).
- All Geologist/Assistant Geologist, Geology and Mining Department. (By E-Mail).
- The Manager, Government Central Press, Gandhinagar.
- With a request to kindly publish the said notification in Part-IV-B of an Extra Ordinary next issue
of the Government Gazette and to supply directly the copies of the said notification to the offices
mentioned below as shown against their names, viz.:-
Industries and Mines Department, CHH Branch, 50
સ
2 Commissioner of Geology and Mining, 200
mT
|
- Computer Cell, Industries and Mines Department, Sachivalay, Gandhinagar. .
(with a request to upload this notification on department’s website.)
- Select File.
ન
Page 2 of 2
