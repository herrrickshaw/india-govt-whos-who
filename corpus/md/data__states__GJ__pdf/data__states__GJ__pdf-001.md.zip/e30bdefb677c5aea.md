---
doc_id: "e30bdefb677c5aea"
source_url: "https://planning.gujarat.gov.in/images/Indian-Women-29-01-2018.pdf"
ministry: "General Administration Department, Gujarat"
title: "Legal / Financial aid Guidelines"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "40eacfad0c0f1887"
---

<!-- page 1 -->

ufiferu - r,r
Rts$qi t&aURBrll .r.[]ul qrru attiis'l tsqrle om.i],r +d]uil qD sL+.iUdrqus1,r ncr,r qrid] rtroiaffisr

uQrqr aoc.e.il u+nsil ridiRal :

1r.

t. Gg:
1.e. uLdtilscqQ &aq a,sL,t il. Gg orlQ,tLaria rilRa c*rLr.il,r +{lutl (ilui. irr+L FrieLqi rGaL / A?,eil
'.t.il?,ii qtLu atu)slB..tLrti, ?,tAq &)i rLldl il.rLi a,ti

{qrLq{.i dq.q.q.r qD uus rrLx.rql +rqLr*h a,sLr.1i[

.rLs"rrii &.

t.a utLdl il'LLu)'1i[ uLs+L qD R{a st tLq[ r,tLiq ari qn.[],r ulqd s{il. aLt .ii,rrL\q utitDa c*LLra1[.t
q[&qL {oLa.iV r*tLtil{ uLSaLRs risuil. i hqursLi[ titqLuii qrnL
{urLr+r.i uti sLgrl il.rLuil.1il uLs*ui,
lrtLq.ei..

a. sL.ifre ui,iiaydr.il eLe[ Qqq.{L qDdl qLxar
E.c. ?,ttdikotga,)q &aq +trsL,t dl{ eetRq eLra-li r,tL[Q+ A,il c*LLr.fl,r +dl{ii qqq.rqrx. ere] d?,ili irr+L

[4itLql tGaL / Fr?sil q.il?,D q+LtL a+u)s1B,q.Lq[ qLEe & r,terqr ti?ei[ rLq+Li qaL&sLdl sL{qLdt ii aLqil sil
tGet&:-

(t) ABeil ,,t1q,il.+L +lr.Lcttdl r,tL ,iluyct GacrL -rLqLu1,r acL.t.1il q[sc1.4t +iaaflqi "aru).s1!, r1r"Eii uei q.il
qtuL u)aLdl.r-[]+l $.Ftss ilf, st"tL+ti r,11Qq dr1c1a]q-[ rtq.Lq.[ r,tr.r|L. aa 6r+rla, u.il q.rLrLi f,+L c,iiqL\q
e,Lodi

i gaii q+LrL q-ili i+L u.il{ En uis"ud} i sl,ti "{L'/r,{} rLrqr [iaL qte{l 1r rGrLdl qroo, u3 irL

tioiicii'qi'?'fl.il i[i. q-il i..tLs[l ?4qcL erd cLd cit ]q uai iqil+) q.i] atuis.rL qD aitEa cLRrLel.aruis:! Q
aqj siliuac't-ict, diqdL uaj. ox"rtqetil r,tar nqLd] di{ & )ui .LLqLLilr iliaLrt.ii.4r uLsrLdl fruqcr1.
&,+lti['ta tqul uaa uL0 tG.tL qD [a$L ut].rqq[ii 6-BL?, +x'tuii uA r,rarqLri +taLr+q[[ uL0. uy-isLlq cir
&,illtl utL{i r,t.otLrtLr ii6 ti.tRt i t+urri d{ +Ie,t }tlil eLrL{ i{l gtaLd} c-irsr,{i+tr r+crqll +i.[l.qqL qD
qr
'{.'il i ii tic,it{a ut-,t !i6 "q.Ga .+t uer"r.L .[[ r,ud ]rLcLqft -L[is 1]ialcqra sLr$ u-il i ii ti,itQa a,t-,r
ii6 "{Gaqt qq.o/qil sr.rLq.[a,tA &.
(a1

'[oa+rii. sL,i [i+aLr : Fr?{rq[ ]tAe aqrq. Sqril s{fluii uti...{aLi,il4 "{Ga}il.

1:; u[&eu c*rLr.ih r{raq]i rrLtr Gidl oiirti.
(v) qGcrr4L qo+ R?.rLq[ rGaLi t4tseit.r.i] uL{ c*LLraqii [Q?erqi, t{A.pis rr1e,s]q.ru.r-itSal.
(q) ?,t1. E+ttL+t[ "[4ieLq[ t&aL r*tLr.ilr' e[r,Lq[ Gr-L-tiqL{} c*tLr.ih (ri.r.uLr..uL6.y ui c*rLr.[lt
({1. ?,u6. ?,ii. )-r-i uqgeL qql.

luLdl ",t6a

1t; +tlLeLi i.tL qo.LdL.l (aLa) "1,{dl u{ar r{Lraqti Fr?ril. rqr+i atui3'lB.qLqi, qL.il diq; qerqr
(.e; u-il-LL [i?.eLqi l&aLi tiieit ,{.il aLi ec-r+L e (Hrcr) .r,[.il dar rlzL&sLd] rL,i"rLGl

q ril ?..rLrri r,rLq'[

c-i,t.

i

(z) u-iI+L [iieLqi tGaL Friqil .{.fl rqr?r crc-r4t e (?u.r) .r,{.r'l dar ilsaq'l ili. qeL&sL tq..il Qq1qi
r,tp,tt dir r,ti...L-il qrLrL rrrqL.iiuqr ui
aL.,tq nq.rql a,tAq cir.

"iirLdliiiu

<!-- page 2 -->

qFfqIEs -BT

emtr+rfrirrcftq Z

Ct

Z@

(1frdfl, zorz tcrf,rE+dafrEe ,

1. u{ev:
1.1

mft qni{cif ,rRfi TrrRqT+fr3gqstenm
FFtlTilrqqr{sT{rt rfiqqffivr<{-qzfrtqftqfttrItr({rq-ft{rfitt

r

r. z r<rqq

7 qnfr<vg{rRifr z

@q(*qafrqt-qrq{nt
2

. ms{r+fufdrruafr,Twil-.

z.r@@,1;Wqz
Gtq
(i) frte

efto.,

ft}q

,,qftqq1q,,

tEq+qcTmt, qffi-

en-ffit-ffiqr*ffie

,

@,

Arqtffiqmurqrqr.{Rr

qatm*

,Wi+n
,

@fticRqr{.qETqE{

,ffi,
tiT
r

(

ii ) EtrrMq:

AeqrHqjffRqrnhffiqdr<{r{l

(iii) @
(iv)

r

(v) Wqr{+t "fr+rfuE+r" sqffi:f,r<ftq tfr+encqr€l eiT[R-frq{qh6qfr tfiqr€frt

ffiretr

(vi) qM

(vii)

,qr

/ Rtqffiarae@,

qr

<!-- page 3 -->

(

vi i i ) \rfrffi-fi@t+rcfi-q

Z

I

(ix) rr.ll@]M€@,

effifrqrilr-fr+rarrr+{i+@en+ffi.ft,
@
(x)

r

r

(xi)
(xii ) qrf,{++reEqffs(q +ooo

,

t

r

iqz

qQqrli-rd-{ z

{dfdat<-

@effiffirqmrqh

**e:

Zffirsr{rr+rrfrqrffitr
