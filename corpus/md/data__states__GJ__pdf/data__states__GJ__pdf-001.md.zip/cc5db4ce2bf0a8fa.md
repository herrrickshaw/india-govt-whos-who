---
doc_id: "cc5db4ce2bf0a8fa"
source_url: "https://home.gujarat.gov.in/Upload/ips_list_home03112025.pdf"
ministry: "Home Department, Gujarat"
title: "Present Posting of I.P.S. Officers"
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "01c51012050fece2"
---

<!-- page 1 -->

List of IPS Officers in Gujarat State as on 01/04/2026
D.G.P. Rank Post
Sr.
No.
1.
2.
3.
4.
5.
6.
7.

Post

Officer holding the Post

D.G.P., C.I.D. (Crime & Railways), Gandhinagar
Commissioner of Police,
Ahmedabad City
Commissioner of Police,
Vadodara City

Dr. K.L.N. Rao, IPS (1992)
Shri Gyanender Singh Malik, IPS
(1993)
Shri Narsimha N. Komar, IPS
(1996)

D.G.P., Police Recruitment Board,
Gandhinagar
D.G.P. (Armed Units), Gandhinagar
D.G.P. (Armed Units), Rajkot

Dr. Neeraja Gotru, IPS (1993)

Shri Raju Bhargava, IPS (1995)
Dr. Prafulla kumar Roushan, IPS
(1996)

D.G.P. (Law & Order), Gandhinagar

Dr. S. Pandia Rajkumar, IPS
(1996)

1

<!-- page 2 -->

Additional D.G. Rank Post
1.
2.
3.
4.
5.
6.
7.

Commissioner of Police,
Surat City
Commissioner of Police, Rajkot City

A.D.G.P. (ATS and Coastal Security),
Ahmedabad.
A.D.G.P. (Planning & Modernization),
Gandhinagar
A.D.G.P. (Women Cell), Gandhinagar

Pricipal Secretary, Home Department,
Sachivalaya, Gandhinagar
Director, Anti- Corruption Bureau, Gujarat
State, Ahmedabad

2

Shri Anupam Singh Gahlaut, IPS
(1997)
Shri Brajesh Kumar Jha, IPS
(1999)
Shri Amit Kumar Vishwakarma,
IPS (1998)
Shri Khursheed Ahmed, IPS
(1997)

Shri Ajay Kumar Choudhary, IPS
(1999)
Smt. Nipuna M. Torwane, IPS
(2000)
Shri Piyush Patel, IPS (1998)

<!-- page 3 -->

I.G.P. Rank post
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.

I.G.P., Surat Range, Surat
I.G.P., Border Range, Bhuj

Shri Prem Vir Singh, IPS (2005)
Shri Chirag Koradia, IPS (2006)

I.G.P., Vadodara Range, Vadodara,

I.G.P. Ahmedabad Range, Ahmedabad
Joint C.P. (Traffic), Ahmedabad City
Joint C.P. (Crime), Ahmedabad City
Joint C.P., Sector-1, Ahmedabad City
I.G.P., Bhavnagar Range, Bhavnagar

I.G.P., Banaskantha Range, Palanapur

I.G.P., CID (Intelligence), Gandhinagar
(Cadre post in A.D.G.P. Grade)
I.G.P (Intelligence-2), Gandhinagar
I.G.P. (Admin.), Gandhinagar

Additional Director, Anti- Corruption Bureau,
Ahmedabad
I.G.P, State Traffic Branch, Gandhinagar
I.G.P., CID (Crime), Gandhinagar

I.G.P., CID (Crime), Gandhinagar

Shri Sandeep Singh, IPS
(2004)
Shri Raghvendra Vatsa, IPS
(2005)
Shri A. G. Chauhan, IPS (2006)
Shri Sharad Singhal, IPS (2006)
Shri Neerajkumar Badgujar, IPS
(2008)
Shri R.V.Asari, IPS (2006)
Smt. P.V. Rathod IPS (2007)

Shri Ashok Kumar, IPS (2003)

Shri N.N.Chaudhari, IPS (2006)
Ms. Gagandeep Gambhir, IPS
(2004)
Shri P.L.Mal, IPS (2006)
Shri M.L.Ninama, IPS (2006)
Shri Gautam M. Parmar, IPS
(2004)
Shri K.N.Damor, IPS (2006)

J.C.P. (Sector-2, Crime and Law &
Shri Nilesh Jajadia, IPS (2006)
Order),Vadodara City
I.G.P., Cyber Center of Excellence, Gandhinagar Shri Bipin Shankarrao Ahire, IPS
(2006)
I.G.P. (Law & Order), Gandhinagar
Shri Makrand Chauhan, IPS
(2007)

3

<!-- page 4 -->

D.I.G.P. Rank Post
1.
2.
3.
4.
5.
6.
7.
8.

D.I.G.P., Panchmahal-Godhra Range,
Godhara
Additional C.P. (Crime, Traffic & Admin),
Rajkot City
D.I.G.P. (Armed Units), Gandhinagar
Additional C.P. (Special Branch),
Ahmedabad City.
D.I.G.P (Intelligence-1), Gandhinagar

Ms. Vidhi Chaudhary, IPS (2009)

Shri Chaitanya Mandlik, IPS (2011)

Smt. Sujata Mazamudar, IPS (2011)
Shri R.T.Sushra, IPS (2011)

Shri Hiteshkumar Hansraj Joysar, IPS
(2011)
Dr. Tarun Duggal , IPS (2011)

Additional C.P.(Administration),
Ahmedabad city
Addl C.P. (Crime), Surat City

D.I.G.P. (Coastal Security), Shahibaug,
Ahmedabad
9.
D.I.G.P., Gandhinagar Range,
Gandhinagar.
10. D.I.G.P., Rajkot Range, Rajkot
11. D.I.G.P., Junagadh Range, Junagadh

12. Additional Commissioner of Police,
Sector-2, Ahmedabad City
13. Addl. Commissioner of Police, Sector-1,
Surat City
14. Additional C.P., Sector-2, Surat City
15. Addl. C.P. (Traffic), Surat City
16. Addl. CP (Sector-1 &Traffic), Vadodara
City,
17. D.I.G.P., State Monitoring Cell,
Gandhinagar
18. D.I.G.P. (Operation), Ahmedabad.
19. Principal, Gujarat Police Academy, Karai,
Gandhinagar
20. Joint Director, Anti- Corruption Bureau,
Ahmedabad
21. D.I.G.P. (Prison), Ahmedabad
22. D.I.G.P. (Prison), Vadodara Region
23. D.I.G.P. (Prison), Rajkot Region
24. D.I.G.P. (Armed Units), Vadodara

4

Shri Karanraj Vaghela, IPS
(2012)
Shri A.M.Muniya, IPS (2012)

Shri Virendra Singh Yadav, IPS (2009)
Shri Nirlipt Rai, IPS (2010)
Shri Rajendrasinh Chudasama, IPS
(2011)
Shri Jaipal Singh Rathore, IPS (2010)
Shri Balram Meena, IPS (2012)

Shri Mahendra Bagria,IPS (2010)
Shri S.V.Parmar, IPS (2012)
Shri Sudhir Kumar Desai, IPS (2012)

Shri Vishal Kumar Vaghela, IPS (2009)
Shri Sunil Joshi, IPS (2010)
Dr. Leena Patil, IPS (2010)

Shri Dipakkumar Meghani, IPS
(2010)
Shri R.P.Barot, IPS (2011),
Ms. Saroj Kumari, IPS (2011)
Dr. G.A.Pandya, IPS (2011)
Ms. Sudha S. Pande, IPS (2011)

<!-- page 5 -->

S.P. Rank Post
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.
36.
37.
38.
39.
40.
41.

S.P., Ahmedabad Rural
S.P., Kheda
S.P., Anand
S.P., Mehsana
S.P., Sabarkantha (Himatnagar)
S.P., Gandhinagar
S.P., Surendranagar
S.P., Patan
S.P., Amreli
S.P., Bhavnagar
S.P., Porbandar
S.P., Jamnagar
S.P., Surat Rural
S.P., Bharuch
S.P., Panchmahal (Godhara)
S.P., Vadodara Rural
S.P., Valsad
S.P., Banaskantha (Palanpur)
S.P., Narmada
S.P., Dahod
S.P., Navsari
S.P., Dang (Ahwa)
S.P., Tapi (Vyara)
S.P., Aravalli (Modasa)
S.P., Gir-Somnath (Veraval)
S.P., Botad
S.P., Chhotaudepur
S.P., Mahisagar (Lunavada)
S.P., Morbi
S.P., Devbhumi Dwarka (Khambhalia)
S.P., East-Kutch (Gandhidham)
S.P., West-Kutch (Bhuj)
S.P., Rajkot Rural
S.P., Junagadh
D.C.P., Zone-1, Ahmedabad City
D.C.P., Zone-2, Ahmedabad City
D.C.P., Zone–3, Ahmedabad City
D.C.P., Zone-4, Ahmedabad City
D.C.P., Zone–5, Ahmedabad City
D.C.P., Zone-6, Ahmedabad City
D.C.P., Zone-7, Ahmedabad City

5

Shri Om Prakash Jat, IPS (2018)
Shri Vijay J. Patel, IPS (2017)
Shri Gaurav G. Jasani, IPS (2018)
Shri Himanshu I. Solanki, IPS (2017)
Dr. Parthrajsinh Gohil, IPS (2014)
Shri Vasamsetty Ravi Teja, IPS (2015)
Shri Premsukh Delu, IPS (2016)
Shri Vasantkumar K. Nayi, IPS (2021)
Shri Sanjay Kharat, IPS (2014)
Shri Nitesh Pandey, IPS (2017)
Shri Bhagirathsinh Jadeja, IPS (2017)
Dr. Ravi Mohan Saini, IPS (2014)
Shri Rajesh Gadhiya, IPS (2017)
Shri Akshay Raj, IPS (2014)
Shri Haresh Dudhat, IPS (2017)
Shri Sushil Agrawal, IPS (2017)
Shri Yuvrajsinh J. Jadeja, IPS (2018)
Shri Prashant Sumbe, IPS(2015)
Ms. Vishakha Dabral, IPS (2018)
Shri Ravirajsinh Jadeja, IPS (2017)
Shri Rahul B. Patel, IPS (2017)
Ms. Pooja Yadav, IPS (2018)
Shri Jashubhai N. Desai, IPS (2021)
Shri Manoharsinh Jadeja, IPS (2017)
Shri Jaydeepsinh Jadeja, IPS (2017)
Shri Dharmendra Sharma, IPS (2014)
Shri Imtiyaz Shaikh, IPS (2018)
Shri Safin Hasan, IPS (2018)
Shri Mukesh Patel, IPS (2017)
Shri Jairajsinh V. Vala, IPS (2017)
Shri Sagar Bagmar, IPS (2017)
Shri Vikas Sunda, IPS (2018)

Shri Vijaysinh Gurjar, IPS (2018)
Shri S. R. Odedara, IPS (2014)
Dr. Harshadkumar K. Patel, IPS (2017)
Shri Bharatkumar B. Rathod, SPS
Smt. Rupal Solanki, SPS
Shri Atul Kumar Bansal, IPS (2019)
Shri Jitendra Agrawal, IPS (2020)
Shri Bhagirath Gadhavi, IPS (2017)
Shri Shivam Verma, IPS (2019)

<!-- page 6 -->

42.
43.
44.
45.
46.
47.
48.
49.
50.
51.
52.
53.
54.
55.
56.
57.
58.
59.
60.
61.
62.
63.
64.
65.
66.
67.
68.
69.
70.
71.
72.
73.
74.
75.
76.
77.
78.
79.

D.C.P. (Traffic), Ahmedabad City
D.C.P. (Crime), Ahmedabad City
D.C.P., Control Room, Ahmedabad City
D.C.P., Zone-1, Surat City
D.C.P., Zone-2, Surat City
D.C.P., Zone-3, Surat City
D.C.P., Zone-4, Surat City
D.C.P, Zone-1, Vadodara City

Smt. B.R.Patel, IPS (2016)
Shri Ajit Rajian, IPS (2015)
Ms. Reema M. Munshi, SPS
Shri Alok Kumar, IPS (2019)
Dr. Kanan M. Desai, SPS
Shri Raghav Jain, IPS (2020)
Ms. Nidhi Thakur, IPS (2020)
Shri. Jagdish M. Chavda, IPS (2021)

D.C.P. (Head Quarter &
Administration), Vadodara City

Ms.Falguniben R. Patel, IPS (2019)

D.C.P., Zone-2, Vadodara City

D.C.P. (Crime Branch), Vadodara City
D.C.P. (Traffic), Vadodara City
D.C.P., Zone-1, Rajkot City
S.P. (Hon. C.M. & VIP Security),
Gandhinagar
S.P., C.I.D. (Crime), Gandhinagar
S.P., Vav-Tharad
D.C.P., Zone-8, Ahmedabad City
D.C.P. (Traffic), Ahmedabad City

Ms. Manjita K. Vanzara, SPS

Shri Himanshu Kumar Verma, IPS
(2018)
Ms. Tejal C. Patel, SPS
Smt. Hetal C. Patel, IPS (2021)
Shri Tejas V. Patel, IPS (2017)

Shri Lokesh Yadav, IPS (2021)
Shri Chintan J. Teraiya, IPS (2017)
Shri Mayur Patil, IPS (2014)
Shri Nareshkumar M. Kanzariya, IPS
(2019)
D.C.P., Traffic (Admin), Ahmedabad City Shri Chirag I. Patel, SPS
D.C.P., S.O.G., Ahmedabad City
Shri Rahul Tripathi, IPS (2013)
D.C.P. (Economic Wing), Ahmedabad
Shri Himkar Singh, IPS (2013)
City
D.C.P. (Cyber Crime), Ahmedabad City
Dr. Lavina V. Sinha, IPS (2017)
D.C.P. (HQ), Ahmedabad City
Ms. Banno D. Joshi, IPS
D.C.P., Zone-5, Surat City
Shri Lakhdheersinh A. Zala, IPS (2018)
D.C.P., Zone-6, Surat City
Shri Rajeshkumar T. Parmar, SPS
D.C.P., Zone-7, Surat City
Smt. Shaifali Barwal, IPS (2016)
D.C.P. (Crime-2), Surat City
Shri B. P. Rojiya, SPS
D.C.P. (Control Room), Surat City
Shri Ajitkumar M. Parmar, SPS
D.C.P., Head Quarter, Surat City
Ms. Bhaktiba Ajitsinh Dabhi, SPS
D.C.P. (Special Branch), Surat City
Ms. Julie C. Kothiya, SPS
D.C.P. (Traffic), Surat City
Ms. Anupam, IPS (2016)
D.C.P. (Traffic), Surat City
Ms. Panna Momaya, IPS (2017)
D.C.P. (SOG), Surat City
Shri Rajdipsinh Nakum, SPS
D.C.P. (Cyber Cell), Surat City
Ms. Bishakha Jain, IPS (2020)
D.C.P., D-Division, Surat City
Shri V. M. Jadeja, SPS
D.C.P. Zone-3, Vadodara City
Shri Abhishek Gupta, IPS (2019)
D.C.P., Zone-4, Vadodara City
Shri Andrews Mackwan, IPS (2017)
D.C.P. (Traffic), Vadodara City
Shri Rushikesh B. Upadhyay, IPS (2017)
6

<!-- page 7 -->

80.
81.
82.
83.
84.
85.
86.
87.
88.
89.
90.
91.
92.
93.
94.
95.
96.
97.
98.
99.
100.
101.
102.
103.
104.
105.
106.
107.

108.
109.
110.
111.
112.

D.C.P., Traffic (North), Vadodara City
D.C.P., Zone-2, Rajkot City
D.C.P. (Crime and Special), Rajkot City
D.C.P. (Traffic), Rajkot City
S.P., CID (Crime), Gandhinagar
S.P., Anti Economic Offences Wing, CID
(Crime), Gandhinagar
S.P. (DCI) I.B. , Gandhinagar Region
S.P.( Intelligence), Gandhinagar
S.P. (Intelligence), Gandhinagar
S.P. (Intelligence), Gandhinagar
S.P. (Intelligence), Ahmedabad
S.P. (Intelligence), Vadodara
S.P. (Intelligence), Gandhinagar
Dy.S.P. (Intelligence), Surat Region
S.P. (Intelligence), Bhuj
S.P., Marine Task Force Commander,
Hajira
Deputy Director, State Police Academy,
Karai, Gandhinagar
Staff Officer, D.G.P. office, Gandhinagar

S.P.,Technical Services, Gandhinagar
S.P., State Traffic Branch-1,
Gandhinagar
S.P., M.T., Gandhinagar
S.P. (ATS), Ahmedabad
S.P. (ATS), Ahmedabad
Superintendent, Central Prison,
Ahmedabad
Superintendent, Central Prison,
Vadodara
Superintendent, Central Prison, Lajpor,
Surat
Superintendent, Central Prison, Rajkot
Executive Director, Gujarat State Police
Housing Corporation Limited,
Gandhinagar
S.P. (Western Railway), Vadodara
S.P. (Western Railways), Ahmedabad
Deputy Director (Admin), ACB,
Ahmedabad
Deputy Director, ACB (HQ), Ahmedabad
Deputy Director, ACB, Rajkot
7

Shri J. I. Vasava, SPS
Shri Rakesh D. Desai, SPS
Shri Jagdish Bangarwa, IPS (2019)
Dr. Harpalsinh M. Jadeja, IPS (2017)
Smt. Amita Ketan Vanani, IPS (2021)
Shri Rohan Anand, IPS (2013)
Shri Bharatsang M. Tank, SPS
Shri Kishor Baloliya, IPS (2017)
Shri H. A. Rathod, SPS
Shri Praful Vaniya, SPS
Shri S. S. Raghuvanshi, SPS
Shri Umesh R. Patel, IPS (2017)
Shri M. J. Solanki, SPS
Shri L. D. Vaghdiya, DySP
Shri Anshul Jain, IPS (2021)
Ms. Shreya J. Parmar, SPS
Smt. Arpita Chintan Patel, SPS

Shri Valay Ankitkumar Vaidya, IPS
(2021)
Ms. Suman Nala, IPS (2021)
Ms. Sahitya V., IPS (2021)

Shri D. H. Desai, SPS
Shri K. K. Patel, SPS
Shri Korukonda Siddharth, IPS (2020)
Shri Gaurav Agrawal, IPS (2021)
Smt. Usha Rada, IPS (2013)

Shri Shripal Sheshma, IPS (2018)
Ms. Vagisha Joshi, IPS (2021)
Dr. Ravindra Patel, IPS (2016)

Shri Abhay Soni, IPS(2017)
Shri Yashpal D. Jaganiya, IPS (2013)
Ms. Bharati J. Pandya, SPS

Shri Hareshkumar D. Mevada, SPS
Shri Baldevsinh C. Vaghela, IPS (2018)

<!-- page 8 -->

113.
114.
115.
116.
117.
118.
119.
120.
121.
122.
123.
124.
125.
126.
127.
128.
129.
130.
131.
132.
133.

Deputy Director, ACB, Vadodara
S.P., Cyber Center of Excellence,
Gandhinagar
S.P., Cyber Center of Excellence,
Gandhinagar
S.P., Cyber Center of Excellence
Gandhinagar
S.P. (Coastal Security), Gandhinagar

Shri. Baldevbhai C. Desai, IPS (2018)
Dr. Rajdeepsinh N. Zala, IPS (2017)

Shri Sanjaykumar Keshwala, IPS (2021)

ADC to H.E. the Governor, Lokbhavan,
Gandhinagar
S.P., State Monitoring Cell, Gandhinagar
S.P., Keshod Division, Junagadh
S.P., Visnagar Division, Mehsana
Commandant, Metro Security-1,
Ahmedabad
Commandant, SRPF Gr.1, Vadodara
Commandant, SRPF, Gr.2, Ahmedabad
Commandant, SRPF, Gr.6, Mudeti, Dist:
Sabarkantha
Commandant, SRPF, Gr.7, Nadiad,
Kheda
Commandant, SRPF, Gr. 8, Gondal
Commandant, SRPF Gr. 12,
Gandhinagar
Commandant, SRPF, Gr.14, Kalgam
Dist:Valsad
Commandant, SRPF Group-17,
Jamnagar, Dist: Jamnagar
Commandant, SRPF Gr.18, Narmada
Battalion Kevdia
Commandant, SRPF Group-20,
Viramgam, Ahmedabad
Commandant (Adjutant), SRPF, Gr-7,
Nadiad

8

Shri Vivek Pravin kumar Bheda, IPS
(2021)
Shri Subodh Ramesh Mankar, IPS
(2021)
Shri Vikash Yadav, IPS (2023)

Shri M. J. Chavda, IPS (2013)
Shri B. C. Thakkar, SPS
Shri D. M. Chauhan, SPS
Ms. Neetaben Hargovanbhai Desai, SPS
Shri Vijaypalsinh R. Yadav, SPS
Ms. Shruti S. Mehta, SPS
Shri Pinakin S. Parmar, IPS (2017)
Shri Parag P. Vyas, SPS

Shri Kalpeshkumar M. Chavda, SPS
Shri P. D. Manvar, SPS
Shri A. M. Shaiyad, SPS

Smt. Komalben Shaileshkumar Vyas, SPS
Ms. Jyoti P. Patel, SPS

Ms. Megha R. Tewar, SPS

Shri Shashibhushan K. Shah, SPS

<!-- page 9 -->

Officers posted as ASP :
No.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.

Name of the IPS Officer
Ms. Simran Bhardwaj, IPS
Shri Ayush Jain, IPS
Shri Jayvir Gadhvi, IPS
Ms. Pratibha, IPS
Shri Rohit Kumar, IPS
Shri Ajay Kumar Meena, IPS
Ms. Ankita Mishra, IPS
Shri Ghanshyam Gautam, IPS

Designation
ASP, Dhoraji, Rajkot
ASP, Dahegam, Gandhinagar
ASP, Dhari, Amreli
ASP, Lalpur, Jamnagar
ASP, Visavadar, Junagadh
ASP, Jhaghadiya, Bharuch
ASP, Aslali, Ahmedabad Rural
ASP, Bhavnagar Rural,
Bhavnagar
ASP, Mandavi, Surat Rural

Shri Akshesh Mahendrabhai
Engineer, IPS
Shri Herrsh Sharma, IPS
Shri Gautam Vivekanandan, IPS
Ms. Vedika Bihani, IPS

ASP, Bodeli, Chhotaudepur
ASP, Mundra, Kutch
ASP, Surendranar,
Surendranagar
ASP, Jasdan, Rajkot Rural

Shri Naveen Chakravarthy Repudi,
IPS
Shri Sandeep T., IPS

ASP,Dharampur, Valsad

9

Batch
2022
2022
2022
2022
2022
2022
2022
2022
2022
2023
2023
2023
2023
2023
