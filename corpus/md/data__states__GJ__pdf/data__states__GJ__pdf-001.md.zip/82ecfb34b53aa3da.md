---
doc_id: "82ecfb34b53aa3da"
source_url: "https://boiler.gujarat.gov.in/images/boiler/online-appli-reg-Instr-12-10-2018-new.pdf"
ministry: "Directorate of Boilers, Gujarat"
title: "Instruction Regarding Online Apllication"
date: ""
pages: 3
method: "pdftotext"
script: "GUJARATI"
needs_ocr: false
sha1: "54b145caf4a91901"
---

<!-- page 1 -->

ુ ના
ઓનલાઈન અરજી માટે સચ
ુ બના સ્ટે પ ધ્યાને લેવા:
બોઇલરની અરજી કરવા માટે નીચે મજ
IFPની વેબસાઈટ પરથી કરવાની અરજીઓ (https://ifp.gujarat.gov.in)

1. Registration for Boiler/ Economizer
2. Registration/Recognition of Firm as per Indian Boiler Regulation 1950 for
Manufacturer/Erector/Fabricator/Repairer of Boiler and Boiler Components

3. NOC for Non-IBR Boilers
4. Renewal of Certification of Boiler/ Economizer
5. Inspection of Product Stage wise during manufacturing under IBR 1950
6. Ownership Transfer for Sell of Boiler
7. Ownership Transfer for Purchase of Boiler
બોઇલરની વેબસાઈટ પરથી કરવાની અરજીઓ

1. Change in Establishment Name

ુ રે www.ifp.gujarat.gov.in પર લોગીન કરવ.ુંુ
૧. IFP પર અરજી કરવા માટે દરે ક યઝ
ુ રે પહેલા કદી રજીસ્રે શન કરે લ નથી તેઓએ www.ifp.gujarat.gov.in ની સાઈટ
 જે યઝ
પરથી જ રજીસ્રે શન કરવાન ુંુ રહેશે.
ુ રને યઝ
ુ રનેમ કે પાસવર્ડ યાદ ના હોય તો IFP પર Forgot Password પર જઈને
 જો કોઈ યઝ
રીકવર કરવાનો રહેશે.
ુ રને Make Payment પર ક્લલક કયાડ પછી કોઈપણ પ્રોસેસ ના થાય તો પહેલા
 જો કોઈ યઝ
ુ રનાું બ્રાઉઝરમાું Pop allow nu setting કરવ ુંુ ત્યારબાદ Make Payment કરવ.ુંુ
કોમ્પ્યટ

 Registration for Boiler/ Economizer
 નવા બોઈલરની અરજી માટે લોગીન કરી Create Project -> Add Project કરવાન ુંુ રહેશે.
ુ રનેમ, પાસવર્ડ થી લોગીન/રજીસ્ટર્ડ કરી
 નવા બોઇલરની અરજીન ુંુ E Payment માટે યઝ
ર્ાબી સાઈર્ Create Project માું નીચે Make payment option પર જઇ કરવાન ુંુ રહેશે.

<!-- page 2 -->

 Renewal of Certification of Boiler/ Economizer
ુ લ બોઈલરની અરજી માટે IFP ની વેબસાઈટ પર લોગીન કરીને ર્ાબી સાઈર્માું
 રરન્યઅ
Renewal -> Renewal-> Renewal of Boiler/Economizer સસલેલટ કરીને સબમીટ આપવ ુંુ
ત્યારબાદ ok આપી એ્લાય પર ક્લલક કરી અરજી કરવી.

 Registration/Recognition of Firm as per Indian Boiler Regulation 1950 for
Manufacturer/Erector/Fabricator/Repairer of Boiler and Boiler Components
ુ લ વકડ શોપની અરજી માટે અરજી કયાડ પછી પ્રાયમરી અપ્રવ
ુ લ લેવાન ુંુ
 નવા અને રીન્યઅ
રહેશે. ત્યાર બાદ જ ફી ભરવાની રહેશે.
ુ લ વકડ શોપની અરજી માટે IFP ની વેબસાઈટ પર લોગીન કરીને ર્ાબી સાઈર્માું
 રરન્યઅ
Renewal -> Renewal-> Renewal of Firm as per Indian Boiler Regulation 1950 for

Manufacturer/Erector/Fabricator/Repairer of Boiler and Boiler Components
સસલેલટ કરીને સબમીટ આપવ ુંુ ત્યારબાદ ok આપી એ્લાય પર ક્લલક કરી અરજી
કરવી.
 નવા વકડ શોપની અરજી માટે IFP ની વેબસાઈટ પર લોગીન કરીને ર્ાબી સાઈર્માું other
approval -> other approval-> Registration of Firm as per Indian Boiler Regulation

1950 for Manufacturer/Erector /Fabricator /Repairer of Boiler and Boiler
Components સસલેલટ કરીને સબમીટ આપવ ુંુ ત્યારબાદ ok આપી એ્લાય પર ક્લલક
કરી અરજી કરવી.

 NOC for Non-IBR Boilers
 નોન બોઈલર ફોર એનઓસી અરજી માટે IFP ની વેબસાઈટ પર લોગીન કરીને ર્ાબી
સાઈર્માું other approval -> other approval-> NOC for Non-IBR Boilers સસલેલટ
કરીને સબમીટ આપવ ુંુ ત્યારબાદ ok આપી એ્લાય પર ક્લલક કરી અરજી કરવી.
 Inspection of Product Stage wise during manufacturing under IBR 1950.

 સ્ટેજ વાઈઝ ઇન્સપેક્ષનની અરજી માટે IFP ની વેબસાઈટ પર લોગીન કરીને ર્ાબી
સાઈર્માું other approval -> other approval-> Inspection of Product Stage wise

during manufacturing under IBR 1950 સસલેલટ કરીને સબમીટ આપવ ુંુ ત્યારબાદ
ok આપી એ્લાય પર ક્લલક કરી અરજી કરવી.

<!-- page 3 -->

 Ownership Transfer for Sell/Purchase of Boiler
 રાન્સફર બોઈલરની અરજી માટે IFP ની વેબસાઈટ પર લોગીન કરીને ર્ાબી સાઈર્માું
other approval -> other approval-> Ownership Transfer for Sell/Purchase of

Boiler સસલેલટ કરીને સબમીટ આપવ ુંુ ત્યારબાદ ok આપી એ્લાય પર ક્લલક કરી અરજી
કરવી. આ અરજીમાું કોઈ ફી ભરવાની આવતી નથી.

 અન્ય અરજીઓન ુંુ E Payment માટે:
ુ રનેમ, પાસવર્ડ થી લોગીન/રજીસ્ટર્ડ કરી ર્ાબી સાઈર્ Track Application માું ક્લલક કરી
 યઝ
Pending પર ક્લલક કરી App ID પર ક્લલક કરતા Make Payment કરવાન ુંુ રહેશે. Paymentની
રીસી્ટ MY Payment History પરથી Download કરવાની રહેશે.

 જો MY Payment History માું Pending Status હોય તો ૨૦ સમનીટ પછી ક્લલક કરી Fail
ુ ી પેમેન્ટ નવ ુંુ પેમેન્ટ થશે નહી.
થાય પછી જ ફરીથી પેમેન્ટ કરવ.ુંુ ત્યાું સધ
ુ ી
 જો પેમેન્ટ કરતી વખતે પેમેન્ટ કાપી જઈ અને રરસી્ટ જનરે ટ ના થાય તો ૭ રદવસ સધ
રાહ જોવી અથવા જે બેન્કમાુંથી પેમેન્ટ કયું ુ હોય તે બેન્કની બ્રાન્ચનો સુંપકડ કરવો.
જે તે અરજીઓના સટીફીકે ટ ર્ાઉનલોર્ કરવા માટે IFP પર લોગીન કરીને ર્ાબી સાઈર્
Track Application -> Approve-> click on app id -> Download Certificate. કરવ.ુંુ
 Online Grievances:
 Online Grievances માટે IFP ની વેબસાઈટ પર લોગીન કરીને ર્ાબી સાઈર્માું Register
Grievances માું જરૂરી સવગતો ભરી ઓનલાઈન અરજી બાબતે જે કોઈ ઇસ્ય ુ હોય તે
જણાવી સબમીટ આપવ.ુંુ

Online Application કરવા માટે ના સ્ટે પ બોઈલરની વેબસાઈટ પર (www.boiler.gujarat.gov.in) -> Eshram Seva પર જઈને Help Guide for User
(https://boiler.gujarat.gov.in/images/boiler/pdf/DOB-User-Manual-2018-new.pdf)પર ક્લલક
કરવ.ુંુ
If you have any query Mail to : dobahmedabad2015@gmail.com
