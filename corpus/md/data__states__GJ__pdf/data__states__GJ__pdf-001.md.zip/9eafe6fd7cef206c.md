---
doc_id: "9eafe6fd7cef206c"
source_url: "https://www.charusat.ac.in/assets/files/Research/2024/new/PGSF_Policy_CHARUSAT_2024.pdf"
ministry: "Charotar University of Science and Technology (CHARUSAT), Gujarat"
title: "Postgraduate Student Fellowship"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3376fb52ac51028c"
---

<!-- page 1 -->

CHARUSAT
Policy for CHARUSAT Postgraduate Student Fellowship
(PGSF)

(Effective from July 2024)

CHAROTAR UNIVERSITY OF SCIENCE AND TECHNOLOGY CHANGA
388 421
GUJARAT

<!-- page 2 -->

CHAROTAR UNIVERSITY OF SCIENCE AND TECHNOLOGY (CHARUSAT)
CHARUSAT Campus, Changa, Anand District,
Gujarat – 388421.
Policy for CHARUSAT Postgraduate Student Fellowship (PGSF)
(Effective from July 2024)
PGSF 1. Preface:
CHARUSAT offers Post graduate (PG) Programmes in all its Faculties. To enhance
the quality research output at CHARUSAT and to become an internationally acclaimed
research Centre, CHARUSAT has initiated PG fellowship students pursuing PG
Programmes at CHARUSAT.

The likely outcome of CHARUSAT PG Fellowship will be quality research papers,
quality research project and availability of prospective PhD research scholars at
CHARUSAT.
PGSF 2. Objectives:
The objectives of this policy are:
2.1. To encourage meritorious students at the Under graduate level for pursuing
postgraduate studies at CHARUSAT;
2.2. To build up academic excellence at Postgraduate level across CHARUSAT.
PGSF 3. Eligibility:
3.1. This policy shall be applicable to all the students pursuing PG Programmes
at CHARUSAT from third semester onwards.
3.2. A student to be eligible to apply for this scheme should have secured
minimum 7.5 CGPA (without any backlog or FF grades) at the end of second
semester of the PG Programme he/she is enrolled in
3.3. The students for the award of PGSF shall be selected based on merit and
subject to a maximum of 5% of the total PG students enrolled in that
particular programme (for eg., If M.Tech (EE) Programme has total 36
students enrolled under it, then 2 students will get the PGSF benefit).
However, there shall be minimum 1 fellowship available for each PG
programme subject to the compliance of the eligibility criteria.
CHARUSAT PGSF Guidelines 2024 (Approved by BOM)

Page 2 of 4

<!-- page 3 -->

PGSF 4. Application Procedure:
4.1. Within a month of declaration of second semester result, an Institute /
Department (Engg.) Committee & Fellow Selection Committee chaired by the
Principal / HOD (Engg.) and other members being PG Programme Coordinator
and a senior teacher shall recommend the names as per the merit to the
University. The Department (Engg.) / Institute shall maintain complete
transparency so as the applicants are aware of merit list and procedure in
general.
4.2. The selected student shall start getting the fellowship from the next month
of the beginning of third semester
PGSF 5. Fellowship amount & other terms:
5.1. The fellowship amount shall be INR 7,000/- per month.
5.2. The fellowship shall not be available during vacation months.
5.3. The fellowship will be terminated immediately and any amount paid in past
shall be recovered in case a student desires to leave the programme halfway.
5.4. The fellowship will be paid to the PG fellow on monthly basis subject to
satisfactory contribution by him/her in academic, research and development
activities of the Department (Engg.) / Institute.
5.5. A student shall have to maintain minimum 7.5 SGPA in third semester and be
active contributor to department / institute to continue his/her fellowship.
5.6. The student’s academic performance and contribution to research as well as
development / research activities will be reviewed at the end of third semester.
It is expected to have good R & D Project(s) / Research Publication(s) as an
outcome.
5.7. Any intellectual property generated shall be owned by CHARUSAT. Due
recognition will be given to the student intern based on significance of
contribution
5.8. Fellow student has to work in CHARUSAT only for the entire duration to avail
the fellowship.

CHARUSAT PGSF Guidelines 2024 (Approved by BOM)

Page 3 of 4

<!-- page 4 -->

PGSF 6. General Instructions:
6.1. The Fellow Selection Committee of the Department (Engg.) / Institute shall
allocate the PG fellows to the departmental faculty members (mentors) based
on their research activity and seniority. However, Principal / HOD (Engg.)
shall have the right to change the allocation as per institute / department need.
6.2. The Principal / HOD (Engg.) may allocate PGSF fellow for themselves also
6.3. The selected PG fellow shall have to contribute to Department (Engg.) /
Institute development, academic and research initiatives to the extent of
minimum six hours per week. This could include but not limited to tutorials,
lab conduction, development and maintenance, assistance in R&D activities,
assistance in academic activities like internal exams, presence, etc.
6.4. The PGSF fellowship is an initiative to reward brilliance of the PG students
and by no means shall be considered as employment of CHARUSAT.
6.5. The PG fellows shall be giving undertaking.
6.6. The PGSF fellowship will be terminated immediately if the PG fellow is found
to be indulging in unethical practices and/or misconduct like ragging, unruly
behaviour, etc.

CHARUSAT PGSF Guidelines 2024 (Approved by BOM)

Page 4 of 4
