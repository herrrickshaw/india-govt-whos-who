---
doc_id: "24b8aaaa4c9a9ec2"
source_url: "https://gad.gujarat.gov.in/Personnel/Images/pdf/posh-act-2013-order.pdf"
ministry: "General Administration Department, Gujarat"
title: "Click here for Order   (714 KB)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "060c0f6f03f861b7"
---

<!-- page 1 -->

ttB{

srirsrcrdt aerdt rfl€r*ilo{l
aatsgJl
a,ir)oil riioRc lllute atllGull ltrldn *?rrl
Gltotd,

5J1rild +t?8t?

alllloel qdlqa Ooit"t
alaqrcrq,qitjlotrt?.
I

ciafrd c{lur:(r) ar.q.[Q."r) dr.rg/ozleoeroi) srarlcr?,r rdtEqt silis:]tsti-loeolo-1oss-ul
srellcrer utBqt:cizr'd c{lOcr srerlc-iq. uttqr uoqO :r)rsrerol +eci ilfbar?a-]"fl fif?er adrur3fl(t{hrrelei Gqrzer darcr raet datqr aurzerr)
u [0 Grqil, eo r s tocn ersq ru i u Q cr la?.ra.r) l scr]r-T bgctl ?,r [Qc,rpr"fl uiafls af]t?"flzz"rr szqrui urQcr E. ur JlilG"rr
"f
eelrd 4larG ia.rln.glrft, orrqor afiq (aura)ofl Gr"rqls saqtui
u€rta cr{l} 4lldl r}u.r}ar. sre{l "l?.lq aflq(qdlqz)"1
urQ E delt ?,loq aoi.t) ?.lelqd zbq).
t

r

ut aGG"lt rlEaa e,rd ac,q'j"fl fQtrcr "fli gvc't B.
(r)

gtaltd ?Ia.u)r€?crl

otteJq afdq(dvta)

?'|EeIA

(a)

ql u2er \dl\n?

+l5Slol Ultl5l?l (dU lA lISa{ )

?lcR.l

(e)
(v)

qle{dl UYdl SlCll?
gla{dl eqlolol USPII

?lscror utgSrtl (cr-q1;t',

a(Rl

lolgcl?lgsd Ulqqgl

ollol A?8 r2t
aGel

(ql?ra u)cr)

isqtoruOrst{l
+iler ro?.r qdlqa (Qotttt

I

otSC{ ?qloll:I

trl lgw a Qrq{l"rt +igsc a tlc*l'l, at.q.fQ
(E) uCIs gw aCIu{l(5.ct.)ott ?,{et ?€zal af}q4l,at.q.[Q , aQlctcre],'titjl"t"lr.

(s) aOrqdl, ulbcr ud qtc4 fAsta [Qc,tt"t, allqtctel,'titjloqa.
(rr) sl}ga4l, arlbcrru] qrq fqsra"fl si{|, qitjloqa.

(q) 4ufa rla.dar.g}rfl, ouucr nllc(oura), ateloel qdlqa [Qott't.

(s) {lucfl r}u.r}u. stc,fl dte.rq aQrq(qdlca), illaitou qdlqa |,Ocrrt.t.
'(o) 4lucfl Ecfl tis.rr, eigscr af}a4l(Grga), ttr)a oi.-ere/e, ilsae-r, crr?idl liitz"fl aril, criEflacta.

(z) 4lulqr r'r"lraz, )sqtot ufOstfl(auta r]su), ]tdrou qdlqa f-Qott"t.
(e) 4lercfl +izorr srcr'la, *sqro ul0sr{l (q-qrrrrt),

(ro) 6u aferq4Goflda), +ttutoet qdlqa ldcrt't.

(rr) 6valtrc{l; durGts u} ziadhr qtqo)otl l'dst.t, alftqtctu, 'titJloqe.
(re[ aral'u qdlqa fQcrttrt, ad u[dst{|4]ul I ad qtrrrtu)
i

(rsf rrrr'rr Frc)sa $Llcr/orr?.rq *sqta u[0st{l firc)sa sralcr

-

Sionature Not Verified

r

\

Signed6y:Sf Patel
Date:2022{12.08
14;45:1S i$S:lO

File No : GADA4SM I e-f{e / | I 2022 I 5 5 44 lI<H - Section
{};rerr t.Ir.e docerneenf fte ,Ad*be Aerrzbolt DC to veri,fy tfie 5-sfgn
