---
doc_id: "21ddfd99abdf45d3"
source_url: "https://dppf.gujarat.gov.in/pdf/AdvisorytoallDDOforupdatingtheirdetailstoCRA-NSDL.pdf"
ministry: "Directorate of Pension and Provident Fund, Gujarat"
title: "Advisory to all DDO for updating their details to CRA-NSDL"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "703c2bac37563623"
---

<!-- page 1 -->

PENSION FUND REGULATORY AND DEVELOPMENT AUTHORITY
PFRDA/17/08/0001/2017-SUP-SG

Date: 21st March 2018

To,
Pr.AOs/PAOs/CDDOs/DDOs of CG ministries and CABs
DTAs/DTOs/DDOs of State Governments and SABs
Advisory to DDO for updating their office details to CRA-NSDL

As per recent reports received from NSDL/CRA, it has been observed that a huge number of
DDOs have not login into DDOs functionality provided by NSDL-CRA due to difficulty in generation
of passwords by them which require various details regarding registration of their office but
currently not available to them and consequently the underlying subscribers were not
benefitted/deprived of available features at DDO level.
Further, it has been observed that passwords for DDOs login are not sent /dispatched by CRANSDL due to non- availability of contact details (postal addresses, official email ids) all concerned
nodal offices are advised to direct their underlying DDOs to update their postal addresses, email
ids, contact number, etc with CRA-NSDL for getting ready to use passwords for easy login and
access DDO functionality which has following features:
The functionalities/menu available in CRA system for DDOs is listed below:

1. Security: This option is for DDOs to manage their log in credentials. With the help of
this option DDO offices can change password and change ‘Secret Question and Answer’
(required to reset password online in event of DDO forgetting password/password locked).
2. View: Following ‘views’ are available under this option
a) Subscriber details –All the details of subscribers can be viewed.
b) Subscriber List -The list of underlying subscribers can be downloaded
c) Statement of Transaction –New: Financial year wise view and print of the underlying
subscribers.
d) e-PRAN–View and print exact replica of PRAN card of the subscriber.
e) Statement of Voluntary Contribution under NPS –View the statement showing Voluntary
Contributions made by the subscriber in Tier I account.
3. Grievance: The DDO can raise the grievances against the any interfacing entities under NPS.
Grievances raised against the them as well as the associated PAO can also be viewed
through this option. Feedback can also be provided through this module to the concerned PAO
for resolution of the grievances.

1

<!-- page 2 -->

4.Processing Exit / withdrawal Requests: As per the guideline laid down by PFRDA, all
withdrawal requests needs to be mandatorily processed through online platform from April 1,
2016. In view of this, options have been enabled in Subscriber login to initiate the
withdrawal request online. However, if a Subscriber /claimant submit a physical form to the
associated DDO, the request needs to be captured in the CRA system by the DDO based on the
forms and documents submitted by the Subscriber/claimant. After the request is processed the
withdrawal form along with the documents need to be sent to the associated PAO/CDDO.
This information may be sent to CRA/NSDL officials Sh. Vijay Hegde at vijayh@nsdl.co.in
for CG sector & Sh. Abhishek Dhuri at abhishekd@nsdl.co.in for SG sector, latest by 20 th April
2018.

-SdAshish Kumar
General Manager

2
