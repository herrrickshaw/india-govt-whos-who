---
doc_id: "af6ddab891a8ed60"
source_url: "https://revenuedepartment.gujarat.gov.in/downloads/Social-Media-Policy-Revenue-Department.pdf"
ministry: "Revenue Department, Gujarat"
title: "Social Media Policy"
date: ""
pages: 4
method: "tesseract:guj+eng"
script: "LATIN"
needs_ocr: false
sha1: "9e40f3731b70962f"
---

<!-- page 1 -->

Guidelines for use of messaging

platform & Social.Media by the

officers of Revenue Department,

Government of Gujarat

Government of Gujarat,
Revenue Department
Circular No. ITP/102019/35/H2
Sachivalaya, Gandhinagar.
Dated: 21/01/2019
Read:
1. DST Circular no. SCM/10/2018/ 614021/ IT dated 29/11/2018
2. GAD GR no. CEL/102009/686/GH dated 9/2/2011

Circular
With the advancement of digital revolution, novel modes of communication have also emerged
such as emails, SMS, Video Conference and smart clients that provide for unified communication
across different communication channels. Peer to peer and group messaging platforms such as
WhatsApp, Telegram, and Skype etc. have increased efficiency of communication for various
functionaries.
As a part of digital revolution, as new means of communication platforms evolve, it is necessary
to dynamically evaluate available platforms for their effectiveness consistent with the need for
sufficient security and the need for maintaining official record in relation to the Government
communication. As the available platforms themselves emerge, mature and sometimes fade
away in view of the intense competition, it is necessary to prescribe appropriate guidelines for
the Government officials to ensure that they take the best advantage of available technologies
without compromising on the need for record keeping and security.
Science & Technology Department, Government of Gujarat has, vide Circular No. SCM/10/2018/
614021/IT provided guidelines for use of messaging platform & Social Media by the officers of
Government of Gujarat. In this regard, Revenue Department, Government of Gujarat issues
following guidelines in relation to the use of digital communication platforms:

1. Officials will use government provided email (.@gujarat.gov.in) or the NIC email for their
official communication and will not use email accounts provided by any other entity for
official communication.

2. For disaster co-ordination and for other co-ordination related work such as meeting
instruction or communicating for seeking information or for event co-ordination
messaging platform of ‘WhatsApp’ should be utilized. With reference to GAD GR

<!-- page 2 -->

CEL/102069/686/GH dated 09/02/2011 which makes provision for purchase of a smart
phone, it would be mandatory to keep such a smart phone for all Secretary & Officers in
Super Time Scale and above personnel of Revenue Department, who are directly involved
in Revenue ,elated functions. It is also highly recommended that officers such as Deputy
Collector and Mamlatdar level who are directly involved in Revenue related functions,
also keep such a smart phone for official use. All such personnel of Revenue Department
are to made part of following WhatsApp groups with their official numbers,
i. State Level —To be monitored/administered at the State Level by, ACS, Revenue and
Secretary, LR with District Collectors and other important functionaries as members.
ii. HoD Level — To be monitored /administered at the by respective HoDs, Settlement
Commissioner & Director of Land Records and Superintendent of Stamps &
Inspector General of Registration, with important functionaries of respective
Department as members.
iii. District Level for each District - To be monitored/administered at the District Level
by District Collector with important functionaries of respective District.
However, while using such platforms, care will be taken to ensure that confidential
information or policy proposals are not shared or discussed on such messaging platforms.

3. The social media platform of. ‘Twitter’ has been found useful in dissemination of
information to public at the time of any occasion/disaster etc. In order to further utilize
social media for citizen engagement, Secretaries, HoDs and Heads of Offices are
encouraged to use social media platform of ‘Twitter’ to increase reach of their respective
offices for connect and feedback with civic society. It is also strongly encouraged to have
official social media accounts for all Deputy Collectors and Mamlatdar level officers, who
are directly involved in Revenue related functions.

4. In relation to social media usage, Officials are encouraged to regularly post updates
related to their work such as official tours, field visits, programs related to Revenue work
and Government Resolutions/Notifications/important Policy related decisions by the
Government for the benefit of people. While posting content or sharing or circulating
content on social media platforms, such officials will take care to ensure that the content
being shared does not conflict with rule 9 and 10 of the Gujarat Civil Services (Conduct)
Rules, 1971or rule 6 and 7 of the AIS (conduct) Rules as applicable.

5. Inrelation to social media usage, officials are encouraged to use their official accounts as
separate from their personal accounts. The officers may take sufficient care for safe keep
of the passwords for official accounts and for scrutiny of content that may get posted on
the social media. Efforts should also be made to get the social media accounts verified by
the social media service provider.

6. While creating social media accounts, officers may keep official email ids/phone numbers
as credentials so that at the time of transfers of officials, credentials related official social
media accounts can be handed over easily.

7. For social media accounts, the concerned officers may also set up a feedback and
response mechanism in their office. Any factual inconsistency may be responded to with

<!-- page 3 -->

accurate facts. Policy criticism may be taken in as constructive criticism for improvement
of program or scheme. Deficiencies in delivery mechanism reported may be corrected
and a response to the critique be posted on the message trail where such deficiency has
been highlighted.

8. For social media usage, in relation to sharing or forwarding of content, officials may
exercise caution for the factual accuracy of the content as well as for the nature of
content. while officers in their discretion may decide on the content to be originally
created and shared as well as shared or forwarded out of the content created by others,
provisions of the Information Technology Act and other relevant penal laws may be kept
in mind to not share or forward any content that may be defamatory, may create enmity
or hatred among groups of people or may violate privacy or rights of other individuals. As
a good thumb rule, reference to specific names may be avoided and aggregate
information may be shared.

9. If any officer maintains his personal social media account then while posting on policy
issues, while adhering to the requirement under the applicable conduct rules, the
concerned officer may add disclaimer that the views are his/her own and not of the
Government.

10. The main communication platforms for the Government communication will continue to
be email and telephones. To ensure that use of social media or messaging platform by
officials does not impact program delivery due to time commitment required, only
occasional and need based use of messaging platforms or social media is permitted during
office hours.

By order and in the name of the Governor of Gujarat, :
ક 3,
Secretary to the Government of Gujarat
Revenue Department
To
1; *Principal Secretary to Hon'ble Governor, Raj Bhavan, Gandhinagar.
2. Chief Principal Secretary to Hon'ble Chief Minister
3: Principal Secretary to Hon'ble Chief Minister
4. Secretary to Hon'ble Chief Minister
5. Personal Secretary to Hon'ble Revenue Minister, Government of Gujarat _
6. *Deputy Secretary to Chief Secretary, Government of Gujarat
7. Additional Chief Secretary, Revenue Department, Government of Gujarat
8. *Registrar, Hon'ble Gujarat High Court, Ahmedabad
9. *Secretary, Gujarat Civil Service Tribunal, Gandhinagar

<!-- page 4 -->

૪
10. Secretary, Department of Science and Technology, Government of Gujarat
11. Settlement Commissioner and Director of Land Records, Government of Gujarat
42. Inspector General of Registration and Superintendent of Stamps, Government of
Gujarat
13. Gujarat State Disaster Management Authority (GSDMA), Government of Gujarat
14. Relief Commissioner, Government of Gujarat
15. Director of Relief, Government of Gujarat
16. Special Secretary, Dispute, Revenue Department, Government of Gujarat
17. Revenue Inspection Commissioner, Revenue Department, Government of Gujarat
18. All Collectors.
19. All AS/DS/US/SO of Revenue Department
20. DDG and SIO, NIC, Gujarat
21. Account General (A&E) Gujarat, Post Box No.2201, Rajkot
22. Account General (A&E) Gujarat Ahmedabad Branch, Ahmedabad.
23. Account General (Audit-1) Gujarat MS Building, Anmedabad.
24. Director, Account & Treasuries, Gujarat State, Gandhinagar
25. Pay & Account Offices, Anmedabad/Gandhinagar
26. —_ All District Treasury Offices
27. Resident Audit Officer, Anmedabad/Gandhinagar.
28. — Select File.
*By Letter
(Copy of this Circular can be downloaded from URL https://revenuedepartment.gujarat.gov.in/)
