---
doc_id: "4dbdcb61abad61a1"
source_url: "https://panchayat.gujarat.gov.in/panchayat/documents/Corrigendum-19102023.pdf"
ministry: "Panchayats and Rural Housing Department, Gujarat"
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "271d47dcfa6c3c7d"
---

<!-- page 1 -->

Corrigendum – Expression Of Interest
1. EoI new submission time line is 30th Oct 2023 by 12 Noon at Development Commissioner
Office, Gandhinagar.
2. No EMD is required to be submitted.
3. Profiling Form as attached required to be submitted by EoI responder compulsory.
4. Travel expense is not required to pay by EoI responder.
5. Attendance system software is owned by the Department and it will be free to use by EoI
responder.
6. Bill will be processed in monthly cycle with all valid proof of attendance including
attendance.
