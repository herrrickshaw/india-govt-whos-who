---
doc_id: "f1cfc679eab457ce"
source_url: "https://ic.gujarat.gov.in/documents/Viksit-Gujarat-Industrial-Policy2026_new.pdf"
ministry: "Industries Commissionerate, Gujarat"
title: "Gujarat Industrial Policy 2026"
date: ""
pages: 44
method: "tesseract:guj+eng"
script: "LATIN"
needs_ocr: false
sha1: "eb7356ade2210358"
---

<!-- page 1 -->

ક =)
જ છ coven arouse a 3
Viksit
પ Industrial
e
Policy 2026
ca ee oY
ક —_ \ :
Ree Fhe Zs keg li
Th સ ડા ge acd Industries and Mines Department
Y \ \ ‘ foe : = ત Government of Gujarat
Yen 52 ON

<!-- page 2 -->

~
ret
Le
a:
iy
a
x જક,
! / t ર!
ie rd
ie
(2
- જજન
I
-- 1! |-8 ‘| /
૫ હે
gcc 1 :
| કુર ન ગડ જ
ae ec eee Pere a
ત | 4 we mar A
deat | ee 3
જ. ડુ i » a ક. સુ neat 2 a. 4 ક
જેન જે ક પી hes રૂ૪. ૨5,
= 1 4 ચ થક iste. oe
ક —" { cones અડે શ તી ન. "
a: lee in es
. | Ri 1 કે - પર ક
. ઇળ દ: પ
ક“, દેજે 5 ~
if | 41... પ AN an .
ad aimee \ a

<!-- page 3 -->

Preface 4 Objective 22
Background 6 Regional Growth and Equitable Development 22
દ
conomic Overview 8 Setting up a State level SCALE Committee 24
Infrastructure Overview 8
Gujarat Industrial Development Promotion of Thrust Sectors 24
Corporation (GIDC) 11
Land Banks 1 Support for Startups 27
PM Gati Shakti 12 Empowered Women for a Viksit Gujarat 28
Reliable Green Power Enabling
Industrial Transition 13 Housing for Workforce 29
Ease of Doing Business 14 .
Promotion of Research & Development 30
State Jan Vishwas
(Amendment of Provisions) Act, 2025 15 Industrial Infrastructure for Competitive Growth 32
Gujarat MSME (Facilitation of Establishment
and Operation) Act, 2019 15 Project T.H.R.ILV.E 33
Gujarat Single Window Clearance Act, 2017 15
Investor Facilitation Portal 16 Promoting Environmental Stewardship 33
Vibrant Gujarat Global Summit and Nudging MSMEs to Go Global 35
Vibrant Gujarat Regional Conferences 17
Key achievements over the past decade 17 Catalyzing Large and Mega Scale Investments 37
The New Industrial Paradigm 18 Special Provision for Selected Thrust Sectors 39
From Jobs to Quality Lives 20 Towards a future ready workforce 40
Policy Period 21 Mukhyamantri Udyog Rojgar Sahay Yojna 40
Vision 21 Growth of Services Sector 41
Mission 21 Conclusion 42

<!-- page 4 -->

a ee CG ZW = 4 iiie, — હાં અય ડઝ
er Pa \ CS ZN \\\ jd am po અ 5 ઈ જ.
PENA WAS જ ૪. te ’
Wa” ap ૫ (\WRCGQZAN SSI WH + oS
hiya oe ig WAZ >: a. Cy
“Se 2. gto es ML \ > : LL oe
SS ES SS sr Lae 4
eS OS ep LY 5-43
“9-05 3 રૂ ઉ કસ
ર SSS — ee
Eee Se A374 a Meg) કકક
કે, = yeaa oN _
| ૨૨ કે 4 i Ye Koy; p\ eax
SI Vig SOS =~ 3 ૪૪%
55 ફિ ઈ 222% સ
BLS NOSES ત ક ક Pity ડઝ કકક કે
જ લ 9 મ હ a _2ZZ21 a fe
ata eZ ડ ~~ ts FEB BL
SASS ES ww ts —__=EEaAXWCq_<~«<_RQOXW
——— nD a a ee SEE — 33 E-Z—— y
ન બ YY ae LS SSS__ BZ Z
અ 755 ક ૮458ની =
“J — $= £ જે SSS —_BARZ DS
Ks --- ર ત્રિ સકત નજ = >
ન્ડ નક ક aS _2=DT™ZNK 2
Wy 7 7 7 SS FEO ખસ
Gy cs «૪૪૧ ૦ > A ie જુ
નક» (કડ == ‘Sey
ન્ન ર્ર KK WiessZess eee SSN છ
fe જે < SS 53535353 . S શ
જર સ કૂ 2S સ
હ 6 કઝ અક્કડ ક
” જે પડ SLL fee ad સ
re 7 ૨ ક્‌ ઝક ઝક સ ન્ન
ટું SD SESS eS o
Fal ને oY, od a
oday, Gujarat stands at a defining threshold, emerging technologies, changing nature of value
poised to unlock vast horizons of innovation, chains, growing need for energy transitions and a
ingenuity, and industriousness that promise renewed emphasis on economic self-reliance, have
to shape its future with resilience and progress. With encouraged countries to align their growth vision
its legacy of economic leadership, a forward-looking with the changing times. Gujarat, too, has embarked
vision and a proactive governance model, the state is on a journey with the larger ambition of realizing the
poised to drive transformative change in the country, Viksit Gujarat se Viksit Bharat @2047. The Viksit
across sectors. Over the past decades, the state has Gujarat Industrial Policy 2026 reflects this ambition.
demonstrated a unique ability to adapt to changing
economic landscapes, whether through pioneering The Viksit Gujarat Industrial Policy 2026 is a
sectoral hubs, large-scale infrastructure corridors, landmark and future-oriented policy framework that
port-led industrialization, or investor-friendly draws direct inspiration from the visionary leadership
governance. Gujarat has evolved from being an of the Hon'ble Prime Minister Shri Narendra Modi and
efficient manufacturing base to a diversified his clarion call for Viksit Bharat @2047, which can be
economic engine with strong trade connectivity, achieved by various initiatives like Atmanirbhar
logistics strengths and a globally recognized Bharat, Make in India, and the principles of Swadeshi.
entrepreneurial culture. The policy represents Gujarat’s long-term strategic
commitment to play a defining role in India’s journey
At the same time, shifting geopolitical contexts have towards becoming a developed nation. The policy
meant that the global industrial outlook also goes also aims to achieve the dual principles of “Living
through changes. Reshaping of trade routes, new Well” and “Earning Well” by promoting enterprises
o Viksit Gujarat Industrial Policy 2026

<!-- page 5 -->

ગોળના” ક. નર ૨ # ys (7 >
હાઇ ક ધા. ન હ “૩ AN Vj 1
= = 19 Ey ox aes > oe) ft | |
= =" કઇ”. જ: વ i. ae if
Lr 4 દ : ws, —a ne — = સ —" ન
55 3 છર
ક - ' જે ન.
જ os as | કરે 4A 2° A Wa જે >
a] os i “છ... ઝર J } , | ધો / રર
—_— i ન્‌ RY - =
| — > (Pe) ad iC ae દ દ ન
દ મ (6. 2777 - ળે કિ મિ ક
FF. Fay, = $ a Bt
fre a b ક
પ 1 11 દે -- ત
> Sy > પ્ર iil — a
રા Tits oe, Ls 7 i= ee |
Remap | hal? * હન ન
0 તણ ન ક. ણણ
ન દુ 4 es & —
7 ૧%
re પ | WER == a = ---. Ly = = i
સ Y i આ ી વડ ન. |
+ - i} ; a 5 5 |
ee ક | ક્ટ me = ક્રિ + 5.
મ, 1S . મુ ષ્ય
આ = RFs ણ ~
AV ear yy F . : 4
a 80 . N F 2 |
ere ” ના! શે
Sk —— cS
NTS Tone are en Rem Us
Hon’ble Prime Minister Shri Narendra Modi and his clarion call for
Viksit Bh t @2047
and providing quality employment opportunities for constituted. These deliberations have ensured that
the youth. It reflects a conscious shift from the policy is both aspirational and implementable,
incremental industrial expansion to a balancing global best practices with local strengths.
transformational growth model that prioritizes
innovation, value addition, employment generation, The principles of “Swadeshi” and “Vocal for Local and
sustainability and global competitiveness while Local to Global’, as given by the Hon'ble Prime
remaining firmly rooted in indigenous capabilities. Minister, Shri Narendra Modi and promoted by the
Through the Industrial Policy, Gujarat is committed to Hon'ble Chief Minister, Shri Bhupendra Patel, are also
nurturing future-ready industries, enhancing central to Gujarat’s industrial vision. By incentivizing
competitiveness and driving inclusive growth, local manufacturing, indigenous development of
while also focusing on enhancing its existing technologies and domestic value chains, the policy
industrial base, promote its sectoral strengths and aims to strengthen self-reliance and reduce
facilitate ease of doing business for the present and dependency on imports. Gujarat will promote
upcoming industries. artisans, MSMEs and local enterprises through
branding, market access, and capacity building. This
The formulation of this Policy has been underpinned approach not only supports economic resilience but
by an extensive, consultative process. Multiple also preserves cultural heritage and promotes
rounds of structured stakeholder consultations were inclusive development.
held to ensure that the policy is responsive to actual
needs and emerging national and global trends. In
addition, 11 dedicated sectoral committees were
Viksit Gujarat Industrial Policy 2026 G

<!-- page 6 -->

1!) i i. ધ. નર ઇ
\ i Economic overview ર
ર ~ કિ —- = સાકાર ણ
અક નન, ee સ nal
2 પે ઉ. 7 બ. ક ી હ
1 - ES 2 |
જ 181 ae ese! ણ. i |
meee AN IS I ર જિ ee ક loa
ath sa | ઝુ - કે fh || ay Pe se bes ક StS
ee mae 153191! દિ! જે. રર્દ ee vet
ES Bier i ae Mercere 21111 1101 is as ~
ગાન Te URE ah | cae aa
< se ઇઝ pe imtssieckeecee pe iatdee anes id
“૨9: a rh Se ow
ome અ પ જ “પય ત TT ) "lig ome મ્‌ al
4 ii | .? દ નકી ણ % "i
p ae j De જજન lg |
હ ર્‌ ક om 6 KA Dh ee tails ક 2 [ફુ દ.
Ve JAD 1 Dae So = ક કક. ke a
દ - a ae aa ર
eS ન સ -- મદદ ae = |
/ ન દિન aa ત અ.સ સક
(1 વ“. --ક ર ગ ક ન---- ઝુ
નદ —_ . SS a =e: 5
WI ન le ee te Fe rt
જ ર દ aft eet કે ન .-2-- 5% ક
કમ ર a5 =< 4: fe end ma
-}— > a ===:~
તન ક ——— : Se eas ; ie
ટ - a” eee
FX _ i .
= ~~ Bare == 7
st ; capes
77 - ટ a=. == ——
a 7 et ee
Gujarat’s industrial and economic journey over the \ GDP grew from
past two decades stands as a compelling example of
scale, speed and structural transformation driven by
strategic vision and policy consistencyGujarat’s USD e Bn to
industrial and economic journey over the past two (2002-03)
decades stands as a compelling example of scale,
speed and structural transformation driven by USD
strategic vision and policy consistency. Anchored by છ 811
a strong manufacturing base in textiles and apparels, (2024-25)
ceramics, engineering, chemicals and
petrochemicals, pharmaceuticals, and auto and auto- foreign direct investment.
components, coupled with development of Special a |
Investment Regions (SIRs), sector-specific parks, and From a GDP of USD 15.73 billion in 2002-03, Gujarat
world-class infrastructure has further enhanced entered a phase of rapid economic expansion to
Gujarat’s attractiveness to investors. The state's reach USD 8780 billion by 2012-13. This period
commitment to ease of doing business, digital marked a decisive shift towards industrialization,
governance and sector specific policies has resulted infrastructure-led growth and investor-centric
in high rankings in national indices and increased governance reforms, laying the groundwork for long-
term competitiveness.
06 | Viksit Gujarat Industrial Policy 2026

<!-- page 7 -->

20x Growth in last 22 years Gujarat's GDP vision for 2047
329.70
INR 435 Lakh Cr
267.07 ! (> USD 3.5 Tn)
810%
« દ
ક
ક
a
=
INR 55-60 Lakh Cr soa,
87.80 (> USD 630 Bn) પ
15.73 વ ઘણ 159%
- r= 46.51%
શરત તરારા 0043. morse <7 a 220
2029-30 2046-47 E
Source: Gujarat Socio-Economic Review 2025-26, 2024-25, "Tertiary =Secondary Primary
RBI Handbook of Statistics on Indian States
Building on this strong base, Gujarat maintained its the country, has enabled seamless trade
growth momentum over the next decade, with GDP connectivity. Gujarat is ranked under "High
expanding to USD 267.07 billion by 2022-23. The Performers" category in the Logistics Ease Across
further expansion to USD 329.70 billion in 2024-25 Different States (LEADS) ranking in 2025 maintaining
underscores the resilience and maturity of Gujarat’s its previous year (LEADS 2024) of "Achievers"
economy, highlighting its ability to sustain growth category. The State has consistently stood in leading
even amid global economic uncertainties. Taken position in previous years. (2018,2019,2021, 2022,
together, Gujarat’s trajectory positions it as one of 2023 and 2024). Gujarat’s total exports were USD
India’s most dynamic and competitive economic 100.7 Billion for FY 2025-26, accounting for 25% of
engines, underpinned by a robust industrial the country’s total merchandise exports’.
ecosystem, long-term policy stability and a clear
vision for inclusive and sustainable growth. In terms of Foreign Direct Investment (FDI), the
Furthermore, the per capita GSDP stood at INR cumulative inflows amounted to USD 73.9 Billion
3,36,875 (USD 3,806),' underscoring the strength of from April 2020 to December 2025.’ Notably, since
the state’s economy and the effectiveness of its 2019, Gujarat has been amongst the top states
industrial development and employment generation nationally in cumulative FDI. The State has attracted
policies. several strategic FDI investments over the past five
years in futuristic sectors including semiconductors,
The state has consistently demonstrated industrial specialty chemicals, green energy, electric vehicles,
leadership in India, evolving from a manufacturing aerospace & defence etc.
stronghold into a diversified and innovation-driven
economy. The state accounts for just 5% of India’s By 2047, Gujarat has potential to become ~USD 3.5
population and 6% of its geographical area but Tn economy. The population in 2047 will likely be 8-9
contributes 8.2% to the country’s GDP. In the past crores, with a median age of 38-40 years, of which
9 6
two decades, Gujarat has witnessed a transformation around 70% are likely to live in the urban areas.
in its industrial landscape. The state has built on its . . oo . .
રી ક. . With this aspiration, Gujarat is expected to grow at 14-
strengths in existing manufacturing sectors and
. . . 15% CAGR by 2030 and further at 12-13% CAGR till
embraced emerging domains such as electronics, 7
. રી 2047 on average’.
semiconductors, green hydrogen, electric mobility
and advanced textiles to name a few. This shift has
been supported by a robust ecosystem of over 4.2
million? MSMEs, globally competitive large Gujarat Socio-Economic Review 2025-26!
Gujarat Socio-Economic Review 2025-26
enterprises and a thriving startup culture. MSME Gujarat | Ministry of Micro, Small and Medium Enterprises’
Gujarat Socio-Economic Review 2025-26"
FDI Statistics, DPIIT?
Gujarat’s ports handle ~40% of India’s port cargo, and Report on Viksit Gujarat @ 2047*
ર ન, Report on Viksit Gujarat @ 2047’
its logistics infrastructure, ranked among the best in
Viksit Gujarat Industrial Policy 2026

<!-- page 8 -->

TSEC MONA)
woes
% 7 |_| | | | 1
| | દ પ, ae
કક = }
: “ર સઝ {
| ન તા. નું. =
all મ જન —
a ॥ ક
1 (ત - 14 7” “71 ઇ”નઇઇઇળ
“1” કડ શ ક: im I a
reper + — ee nN 1 —
ક! ન ગ (ea --
pean eee 1 ક N
So ae fa coe A ણ સઇ -
જ”! ન્ન: ડન ય. મ. i મી
3 a 31 | |
1 સઈ 7 i kt a Lan
ક. 17 ણા erm જલી કન લ... ના
| ના TN પા | imi Hu i Th
GE || 2 22822290 9. 28 ક ia awe ii, મ 1
ન, પા ir ee acs J —— ણણ
Pi te ગટ” — ઘા ણ. ન. hea \
ee a oa ણ 2 | યક a ml
es eee ક ક285. 7 ટ ક હયા સટ ઝઝ- 2 —* 221
ST ne eee eee
-ડ---ઃઝ- ક
જાઇ 5
The state’s industrial growth has been ecosystem at Jamnagar with major production and
underpinned by strategic infrastructure consumption centres across northern and western
investments as well. Gujarat has emerged as India. Within Gujarat, it significantly enhances
a leader in India’s renewable energy sector, with a connectivity to industrial clusters and ports, reduces
total installed capacity of around 50.38 GW, as of May logistics costs, and strengthens the state’s role as a
2026’, contributing over ~17.8% to the nation’s national gateway for trade, energy security, and
renewable energy capacity. In terms of ports, Gujarat export-led manufacturing.
has 48 minor ports and 1 major port. Additionally, 11
new ports are to be developed as “All Weather Deep 9 t ti 1
Water Direct Berthing Ports”. Gujarat also has 7 in ema 101 તો
international airports and 12 domestic airports’. e
Country's first High Speed Rail (Bullet train) will start airports and
between Ahmedabad and Mumbai. This bullet train
will cover the area of 508 Kms. from Ahmedabad to domestic
Mumbai and is expected to reduce the travel time to
close to 2 hours, which shall further bring a multiplier e rts
boost for Gujarat’s economy. In addition, The alrfpo
Amritsar-Jamnagar Expressway, developed under
Bharatmala Pariyojana, is a strategic access- State-wise (Location based) installed capacity of
controlled corridor linking Gujarat's port and refinery Renewable Power as on 31.05.2026, Official website of MNRE*
Gujarat Socio Economic Review 2025-26"
oo Viksit Gujarat Industrial Policy 2026

<!-- page 9 -->

In addition to this, the state’s next wave of growth will 3) Mandal Becharaji Special Investment Region

be driven by mega industrial infrastructure projects, (MBSIR): Emerging as the world’s largest Auto-

suchas hub, MBSIR is a base for Japanese automobile
and auto component manufacturing industries.

1) Kutch Railway Connectivity Enhancement: Globally recognized companies have already
The Government of India has approved a established their units. Located at around 90
strategic new railway line project in the Kutch kms. from Ahmedabad, the region is well
region to connect remote and far-flung areas, connected to leading ports, airport, railroads and
significantly strengthening regional rail National highway (NH) roads
infrastructure. The Deshalpar—Hajipir—Luna and
Vayor—Lakhpat new line will extend 4) Petroleum, Chemicals and Petrochemicals
approximately to the existing network. This Investment Region (PCPIR): Located at Dahej,
project will provide vital rail connectivity to the South Gujarat, PCPIR is India’s first specially
Rann of Kutch and facilitate the transportation of delineated investment region of 453 sq. km. for
key commodities including salt, cement, coal, manufacturing of petroleum products, chemicals
clinker and bentonite, thereby enhancing and petrochemicals. With the coming of DFC,
industrial logistics. In addition to freight benefits, DMIC, Bullet Train and the Express Highway
the new rail line will support tourism by linking linking Vadodara to Mumbai, the prospect in
culturally and historically significant sites such as PCPIR is further expected to boost. Three new
the Harappan site of Dholavira, Koteshwar LNG terminals and a greenfield airport have also
Temple, Narayan Sarovar and Lakhpat Fort, been planned in/ around the PCPIR. To meet the
through the addition of 13 new railway stations, increasing demands of land by industries, GIDC
benefiting approximately 16 lakh people across has developed a chemical zone in Saykha and is
866 villages”. developing additional estates near the region.

2) Dholera Special Investment Region (DSIR): 5) Gujarat International Financial Tech (GIFT) City:

Dholera SIR in Gujarat is India’s largest greenfield GIFT City is India’s 1" operational Smart City and
industrial investment region, spread over 920 sq. International Financial Service Centre (IFSC), with
km. DSIR will have smart & sustainable world class infrastructure for offshore and
infrastructure spanning transportation, water, international transactions in banking, insurance
power, wastewater, drainage and urban design. A and capital markets. It is a vertical city with
major recent development within DSIR is the integrated development spread across 886
emergence of Dholera Semicon City, being acres. GIFT is also home to India’s first
positioned as India’s first dedicated International Exchange (India INX). Over 1,034
semiconductor manufacturing ecosystem. This registered entities spanning banking, capital
initiative integrates plug-and-play industrial land, markets, asset management, fintech, insurance,
assured power and water supply, high-quality and leasing are currently operational at the GIFT
logistics connectivity, and robust social City. Due to IFSC, several international financial
infrastructure to support fabs, ATMP units, and institutions are setting up operations in GIFT City
allied electronics manufacturing. With the and will further enhance doing business in
operationalization of the Anhmedabad—Dholera Gujarat. With this, the GIFT city has emerged to
Expressway, progress on the international become a financial magnet in India. GIFT is also
greenfield airport, and advanced trunk providing facilities like Housing, School, Hospital,
infrastructure already in place, DSIR, anchored by Hotel and City club.
Semicon City is poised to become a global
manufacturing and innovation hub, driving high-
value investments, technology leadership, and
large-scale employment generation.

Official website of PIB"

Viksit Gujarat Industrial Policy 2026 oo

<!-- page 10 -->

6) Bhadbhut Project: The Bhadbhut Project is a well as 2029 World Police & Fire Games.
strategically important multipurpose Together, these initiatives, complemented by
infrastructure initiative on the Narmada River hosting other international championships and
aimed at strengthening Gujarat’s long-term water continuous upgrades to facilities and training
security and regional connectivity. The project ecosystems position Gujarat as a leading
will prevent saline water ingress from the Arabian destination for sports excellence, large-scale
Sea, ensure reliable availability of freshwater for global events, and sports-led development
drinking, industrial and irrigation purposes, and across the regions.
support sustainable development in water-
stressed regions of central and south Gujarat. 8) Kutch Railway Connectivity Enhancement: The
The integrated barrage and road infrastructure Government of India has approved a strategic
will also enhance connectivity across the new railway line project in the Kutch region to
Narmada corridor, contributing to economic connect remote and far-flung areas, significantly
activity and balanced regional growth. strengthening regional rail infrastructure. The

Deshalpar—Hajipir-Luna and Vayor—Lakhpat

7) Sports Infrastructure Development: Gujarat has new line will extend approximately to the existing
made sustained investments in developing network. This project will provide vital rail
modern, inclusive, and world-class sports connectivity to the Rann of Kutch and facilitate
infrastructure across the state to nurture sporting the transportation of key commodities including
talent, promote a culture of fitness, and support salt, cement, coal, clinker and bentonite, thereby
elite performance pathways. Large-scale enhancing industrial logistics. In addition to
facilities such as integrated sports complexes, freight benefits, the new rail line will support
stadiums, high-performance training academies, tourism by linking culturally and historically
and district- and city-level arenas ensure significant sites such as the Harappan site of
grassroots access and systematic athlete Dholavira, Koteshwar Temple, Narayan Sarovar
development. These infrastructure investments and Lakhpat Fort, through the addition of 13 new
underpin Gujarat’s ability to host global sporting railway stations, benefiting approximately 16 lakh
events, elevate its international sports profile, people across 866 villages.
and catalyze urban and economic development.

Gujarat will host 2030 Commonwealth Games as
ys AG". deh ~
ક = os Ti \
+ A 4 ae} ફે!
ર કે પ” | ie i
» = rl
ns nS
ah દ
9
ડડ ZA
| 10 | Viksit Gujarat Industrial Policy 2026
