---
doc_id: "5fba7bceefd7686a"
source_url: "https://gnlu.ac.in//Content/gnlu/pdf/press-notes/press-note-32-2019.pdf"
ministry: "Gujarat National Law University, Gujarat"
title: "Certificate Course on “Cross-Border Challenges in Corporate Law” inaugurated at GNLU"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "86f3980fe945afd6"
---

<!-- page 1 -->

GNLU PRESS NOTE No. 32/2019

Certificate Course on “Cross-Border Challenges in Corporate Law” inaugurated at
GNLU
Gandhinagar, Aug 30, 2019: A three-day Certificate Course on Cross-Border Challenges in
Corporate Law was inaugurated at Gujarat National Law University (GNLU), today.
In her inaugural address, Dr Mamta Biswal, Dean Academic Affairs said, “In view of the recent
developments like the Jet Airways cross border insolvency issue and cross borders mergers
announced by Reliance Industries & Shopsense Retail Technologies as well as Walmart & Flipkart,
the course provides a timely forum for discussion about legal issues highlighting the interface of the
company law with private international law.”
“In the era of globalization, with the markets, people and services crossing borders, the entire global
economy is expanding and the related legal issues are intensifying,” said Dr Umakanth Varottil,
resource person for the Course. Dr Varottil is an Associate Professor at Faculty of Law, National
University of Singapore and a visiting faculty in various leading law schools in Australia, India, Italy,
New Zealand and the United States.
The course has received an overwhelming response from the students, practitioners and
academics, with as many as 56 participants attending the course.
The course has been organized by GNLU’s Centre for Private International Law.
Media Contact:
Ashok Shah
Email: 9909960240, 8849110049

Attalika Avenue, Knowledge Corridor, Koba, Gandhinagar – 382426, Gujarat, India
Ph: +91-79-23276611/12, Fax: +91-79-7878186624, Email: contact@gnlu.ac.in, Website: www.gnlu.ac.in
