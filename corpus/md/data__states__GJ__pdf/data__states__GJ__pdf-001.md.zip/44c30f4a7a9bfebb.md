---
doc_id: "44c30f4a7a9bfebb"
source_url: "https://fed.gujarat.gov.in/writereaddata/Portal/News/339_1_19-12-25_Notification.pdf"
ministry: "Forests and Environment Department, Gujarat"
title: "Notification Under Air(Prevention & Control of Pollution Act), 1981 and Water(Prevention & Control of Pollution Act), 1971"
date: ""
pages: 6
method: "tesseract:guj+eng"
script: "LATIN"
needs_ocr: false
sha1: "fe484f98f53b4796"
---

<!-- page 1 -->

ક I { as
Extra No..149 ae, વાર્ષિક લવાજમનો દર ૪૦૦૦/-
| © ti
Hi (a7)
સત્યમેઘ ઝયતે
The Gujarat Government Gasette
EXTRAORDINARY .ઃ
PUBLISHED BY AUTHORITY .
a a ree રરર રર
Vol. LIX WEDNESDAY, DECEMBER 19, 2018/AGRAHAYANA 28, 1940 ક
Separate paging is given to this Part in order that it may be filed as a Separate Compilation.
Se a SRR cite
ee PART IV-A
૦9 Rule and Orders (Other than those published in Parts 1, I-A, and JL) made ..
ડ્ર S by the Government of Gujarat under the Central Acts
ર FOREST AND ENVIRONMENT DEPARTMENT
1 2, Notification
{
: . Sachivalaya, Gandhinagar, 19" December, 2018
: : Water (Prevention and Control of Pollution) Act, 1974
i
: No.GVN/2018/(23)/ENV/102017/1278/E. In exercise of the powers conferred by clause (p) of
sub-section (2) of section 64 of the Water (Prevention and Control of Pollution) Act, 1974-(6 of
= 1974) and pursuant to Hon’ble Supreme Court judgment dated 22/09/2017 in Civil Appeal
No. 1561/2017, the Government of Gujarat, after consultation with the Gujarat Pollution Control
; Board, hereby makes the following rules further to amend the Gujarat Water (Prevention and
i Control of Pollution) Rules, 1976, namely; હ
‘ 1) These rules may be, called the Gujarat Water (Prevention and- Control of Pollution)
(8 Amendment) Rules, 2018.
| ડુ જ
! 2) They shall come into force on and from the date of publication in the Official Gazette.
| 3) In the Gujarat Water (Prevention and Control of Pollution) Rules, 1976 (hereinafter referred
to as “the said rules”), after rule 31, the following shall be added, namely: -
32. Qualification, Experience and other criteria for nomination of Chairman.
: The Chairman of the Gujarat Pollution Control Board shall
(1) be of at least 45 years in age and not more than 65 years;
(2) possess a post graduate degree in Environmental Science or Environmental
Management or allied sciences or a graduate degree awarded after the successful
completion of a graduate degree course of a minimum of four years in
Environmental Engineering or Environmental Technology or an equivalent degree
thereto; or
IV-A Ex.-149 149-1

<!-- page 2 -->

ક] |
149-2 GUJARAT GOVERNMENT GAZETTE. EX., 19-12-2018 [PART 1-8 8 |
should be a serving government officer of Secretary or equivalent rank, and should
have worked for a total of at least 3 years in the departments of forests, environment,
3 * climate change, industries, mines, urban development, transport, energy and / or in |
one or more offices or institution or state public sector undertakings under the પ
aforesaid departments that handle the work of poliution control or C>vironment - i
protection or environmental management or- industrial development or urban. ર |
development or transport or energy or mining; or |
if the person is not a serving government officor than he should possess a graduate i
degree and have experience in one or more ‘sectors amongst the sectors of forests, fa
environment, industries, mines, urban development, transport or energy for. a દ
minimum period of 3 years. જમ i
33. Qualification, Experience and other criteria for appointment of Member Secretary. 2
The Member Secretary of the Gujarat Pollution Contrei-Board shall 4
(1) be of at least 35 years in age and not more than 60 years; કે
(2) possess a post graduate degree in Environmental Engineering or Environmentai: -..-
i Science or Environment Management or Earth Sciences or Sustainable Development Se ત
or Ecology or related subject, where poilution' control or pollution management! is“, nati} ન
part of academic assessment; and i
ક્ર
(3) have worked in a senior position in the Government of India or a State Government
or the Central Pollution Control Board or a Staté Pollution Control Board or a . : -
Central Public Sector Undertaking or a Siaic Public Sector Undertaking, or an office
or institution under the Centra] or State Government, where he has directly handled
the subject of pollution control for a minimum.cf 7 years. 7 re
By order and is the name of the Governor of Gujarat, aie
3. M. SATYAD, ન ?
Additiona! Secretary to Government i
FOREST AND ENVIRONMENT DEPARTMENT
Notification ૪ a
Sachivalaya, Gandhinagar x :
Dated 19/12/2018 i
Air (Prevention and Control! of Pollution) Act, 1981 te :
No.GVN/2018/(24)/ENV/102017/1278/E. In exercise of the powers conferred by clause (z) of sub- {
section, (2) of section 54 of the Air (Prevention and. Controi of Pollution) Act, 1981 (14 of 1981) |
and pursuant to Hon’ble Supreme Court judgment dated: 22-09-2017 in Civil Appeal no.1561/2017, ર
the Government of Gujarat, after consultation with the Gujarat Pollution Control Board, hereby :
makes the followings rules further to amend the Gujarat Air (Prevention and Control. of Pollution)
Rules 1983, namely. : :
1) These rules may be called the Gujarat Air (Prevention and Control of Pollution) ક
(4"" Amendment) Rules, 2018. ; :
2) They sha!l come into force on and from the date of publication in the Official Gazette. i
3) In the Gujarat Air (Prevention and Control of Pollution) Rules 1983, (herein after referred to
as “the suid rules”), after rule 25, the following shall be added namely: -

<!-- page 3 -->

: (2 / ce
ક 7601 10-64 ] GUJARAT GOVERNMENT GAZETTE, EX., 19-12-2018 149-3
26. Qualification, Experience and other criteria for nomination of Chairman.
‘The Chairman of the Gujarat Pollution Board Shall

(1) be of at least 45 years in age and not more than 65 years.

(2) possess a post graduate degree in Environmental Science or Environmental Management or
allied science or a graduate degree awarded after the successful completion of a graduate
degree course of a minimum of four years in Environmental Engineering or Environmental
Technology or an equivalent degree thereto, or.

Should be a serving government officer of Secretary or equivalent rank and should have
worked for a total of at least 3 years in the departments of forests, environment, climate
ક change, industries, mines, urban development, transport, energy and / or in one or more
offices or institutions or state public sector undertakings under the aforesaid departments
that handle the work of pollution contro] or environmental protection or environmental
management or industrial development or urban development or transport or energy of
mining, or
Paes If the person is not a serving government officer than he should possess a graduate degree
og and have experience in one or more sectors-amongst the sectors of forest;. environment,
industries, mines, urban development, transport’ or energy for a minimum period of 3 years:

27 Qualification, Experience and other criteria for appointment of Member Secretary.

The Member Secretary of the Gujarat Pollution Control Board shall. ;

(1) Be of at least 35 years in age and not more than 60 years,

(2 Possess a post graduate degree in Environmental Engineering or Environmental Science or
જ ae Environmental Management or Earth Science of Sustainable Development or Ecology or
ae related subject, where Pollution Control or Pollution Management is part of academic
i “ assessment.
+ (3) Have worked in a senior position in the Government of India or a State Government or the
Central Pollution Control Board or a State Pollution Control Board or a Central Public
Sector Undertaking or a State Public Sector Undertaking or an office or institution under the
Central or State Government, where he has directly handled the subject of pollution control
en for a minimum of 7 years.
@ By order and in the name of the Government of Gujarat,
S. M. SATYAD,
Additional Secretary to Government
FOREST AND ENVIRONMNT DEPARTMENT
Notification
Sachivalaya, Gandhinagar.
Dated 19/12/2018
Water (Prevention and Control of Pollution) Act,1974
No.GVN/2018/(25)/ENV/102017/1278/E. In exercise of the powers conferred by clause (e) of
sub-section (2) of section 64 of the Water (Prevention and Control of Pollution) Act,1974 (6 of
1974), the Government of Gujarat, after consultation with the Gujarat Pollution Control Board,
hereby makes the following rules further to amend the Gujarat Water (Prevention and Control of
Pollution) Rules, 1976, namely:

<!-- page 4 -->

149-4 GUJARAT GOVERNMENT GAZETTE, EX., 19-12-2018 {PART Iv-a- *,. !
1) These rules may be called the Gujarat Water (Prevention and Control of Pollution) = ;
o* Amendment) Rules, 2018.
2) They shall come into force on and from the date of Publication in the Official Gazette.
3) In the Gujarat Water (Prevention and Control of. Pollution) Rules, 1976 (hereinafter referred »|
to as “the said rules”) after rule 33, the Following shall be added, namely: - it
34, Tenure of Chairman. |
The Chairman of the Gujarat Pollution Control Board shall hold office for a term of three i
years from the date of nomination, which may be extended for one more term of three =
years. i
Provided that the Government may, if it thinks fit, remove the Chairman before the expiry થિ
of his term of office.
By order and in the name of the Governor of Gujarat, i
S. M. SAIYAD,
: : Additional Secretary to Government : :
a cs ૪
FORST AND ENVIRONMENT DEPARTMENT : I
Notification 2
ટ Sachivalaya, Gandhinagar. ન
Dated 19/12/2018
Air (Preveation and Control of Pollution), Act.493) .
No.G-YN/2018/(26)/ENV/102017/1278/E.  in-exezcise of the powers conferred by clause (aa}-of  *
-sub-section (2) -section of 54 of the-Air (Prevention und Control of Poilution) Act, 1981-(i4 of =. i
1981)..the Government of Gujarat, after consultation with the Gujarat Pollution Control Board, -* i
evhereby iiakes: the following rules:further to: ainend-the Gujarat Air (Prevention and Contre! of '
Pollution) Rules, 1983, namely: :
1) These rules may be called the Gujarat Air. (Prevention and Control of pollution)
(5 Amendment) Rules, 2018.
2) ‘They shall come into force on and from the date of publication in the official Gazette.
3) In. the Gujarat Air (Prevention and Control of Pollution) Rules, 1983 (hereinafter referred to
as “the said rules”), after rule 27, the following shall be added, namely:
28. Tenure of Chairman. ક ર
The Chairman of the Gujarat Pollution Control Board shall hold office for a term of three :
years from the date of nomination, which may be extended for one more term of three years. 1
Provided that the Government may, if it thinks fit, remove the Chairman before the expiry of
his term of office. ક
By order and in the name of the Governor of Gujarat,
S. M. SATYAD,
Additional Secretary to Government
i
|
|
{

<!-- page 5 -->

Yee
Lt Is / ra
ey PART IV-A ] GUJARAT GOVERNMENT GAZETTE, EX., 19-12-2018 149-5
i FOREST AND ENVIRONMENT DEPARTMENT
| Notification
! Sachivalaya, Gandhinagar.
Dated 19/12/2018
Water (Prevention and Control of Pollution) Act, 1974 ફે
No.GVN/2018/(27)/ENV/102017/1278/E. In exercise of the powers conferred by clause (e) of
sub-section (2) of section 64 of the Water (Prevention and Control of Pollution) Act, 1974 (6 of
1974), the Government of Gujarat, after consultation with the Gujarat Pollution Control Board,
જ hereby makes the following rules further to amend the Gujarat Water (Prevention and Control of
| Pollution) Rules, 1976, namely: જ
1) These rules may be called the Gujarat Water (Prevention and Control of Pollution)
i (10" Amendment) Rules, 2018.
: 2 2) They shall come into force on and from the date of publication in the Official Gazette.
‘of 2) In the Gujarat Water (Prevention and Control of Pollution) Rules, 1976 (hereinafter referred
to as “the said rules”), after rule 34, the following shall be added, namely: - *
35, Tenure of Member Secretary
d The Member Secretary of the Gujarat Pollution Control Board shall hold office for a term of
fe five years from the date of appointment, which may be extended.
i Provided that the State Government may, if it thinks fit, remove the Member Secretary
before the expiry of his term of office.
ક 5
2 By order and in the name of the Governor of Gujarat,
ક x
ert a S. M. SAIYAD,
ન ee Additional Secretary to Government
= oak ------------
‘ ; FOREST AND ENVIRONMENT DEPARTMENT
હ” Notification ક
| Sachivalaya, Gandhinagar. :
| Dated 19/12/2018
Air (Prevention and Control of Pollution) Act, 1981
No.GVN/2018/(28)/ENV/102017/1278/K. In exercise of the powers conferred by clause (f) of
sub-section (2) of section 54 of the Air (Prevention and Control of Pollution) Act, 1981 (14 of
1981), the Government of Gujarat, after consultation with the Gujarat Pollution Control Board,
hereby makes the following rules further to amend the Gujarat Water (Prevention and Control of
Pollution) Rules, 1983, namely:
i 1) These rules may be called the Gujarat Air (Prevention and Control of Pollution)
(6" Amendment) Rules, 2018.
1 2) They shall come into force on and from the date of publication in the Official Gazette.
3) In the Gujarat Air (Prevention and Control of Pollution) Rules, 1983 (hereinafter referred to
as “the said rules”), after rule 28, the following shall be added, namely: -

<!-- page 6 -->

149-6 GUJARAT GOVERNMENT. GAZETTE, EX., 19-12-2018 [PART IV-A . i I
-
હ 7”
29. Tenure of Member Secretary
‘The Member Secretary of the Gujarat Pollution Control Board shail hold office for a term of
five years from the date of appointment, which may be extended.
Provided that the State Govemment may. if it thinks fit, remove the Member Secretary
before the expiry of his term of office.
By order and in the name of the Governor of Gujarat, :
: S. M. SAIYAD, ae
Additional Secretary to Government ‘
‘
Government Central Press, Gandhinagar.
ટ
|
