---
doc_id: "f04fcfb3f137dc1d"
source_url: "https://www.gdchahmd.org/img/98/File/Curbingthemeananceofragging.pdf"
ministry: "Government Dental College & hospital, Ahmedabad, Gujarat"
title: "Anti Ragging Rules"
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a2d9eb79435ce515"
---

<!-- page 1 -->

Curbing The Menace Of Ragging
WHAT IS RAGGING?
Ragging means display of disorderly conduct, doing of any act which
causes or is likely to cause physical or psychological harm or raise apprehension
or fear or shame or embarrassment to a student in any educational institution &
includes:
a) Teasing, abusing, threatening or playing practical jokes on, or causing
hurt to such a student; or
b) Asking a student to do any act or perform something which such student
will not in the ordinary course willingly do ( Maharashtra Prohibition of
Ragging Act,1999).
c) The human rights perspective of ragging involves the injury caused to the
fundamental right to human dignity through humiliation heaped on junior
students by seniors; often resulting in the extreme step of suicide by the
victims.
Ragging has several aspects which include psychological, social,
political, economic, cultural and academic dimensions. The political aspect of
ragging is apparent from the fact that incidents of ragging are low in institutions
which promote democratic participation of students in representation & provide
an identity to students to participate in governance & decision making within
the institute bodies.
STEPS THAT MAY BE TAKEN BY STUDENT IN AN EVENT OF
INCIDENCE OF RAGGING
1) Contact number of wardens, all members of anti-ragging committee &
squads, relevant authorities have been issued on the notice board. In case
of any such occurrences, students may contact any of the above
2) Fresher or any other student, whether being victim, or witness, in any
incident of ragging are encouraged to report such occurrence, and the
identity of such informants will be protected & will not be subject to any
adverse consequence only for the reason for having reported such
incidents. Those who want to be anonymous can submit their complaints
to administrative office. The identity shall be kept undisclosed.

<!-- page 2 -->

3) The students can contact the members of anti-ragging committee or
squad, whose phone numbers are displayed along with the anti-ragging
poster or they can directly approach the dean who in turn will direct the
complaint to anti-ragging committee.
4) Those in hostel can also contact the hostel warden or any other staff
members who will in turn direct the case to relevant authorities.
5) Freshers who do not report the incidents of ragging either as victim or as
witnesses shall also be punished suitably.
A] PUNISHMENT FOR RAGGING:
a) Penalty for ragging (section 4): Whoever directly or indirectly
commits, participates in, abets or propagates raging within or outside
any educational institution shall on conviction be punished with
imprisonment for a term which may extend to two years and shall also
be liable to a fine may extend to ten thousand rupees.
b) Dismissal of student (section 5): Any student convicted of an offence
under section 4 shall be dismissed from the educational institution and
such student shall not be admitted in any other educational institution
for a period of five years from the date of order of such dismissal.
c) Suspension of student (section 6): Whenever any student or as the
case may be parent or guardian or a teacher of an educational
institution complains in writing of ragging to the head of the
educational institution, the head of the educational institution shall
without prejudice to the foregoing provisions, within seven days of
receipt of complaint,do enquiry in to the matter mentioned in the
complaint and if prima facie, it is found true shall suspend the student
who is accused of the offence, and shall immediately forward the
complaint to the police station having jurisdiction over the area in
which the educational institution is situated for further action.
d) Deemed abetment (section 7): If the head of the educational
institution fails or neglects to take action in the manner specified in
section 6 when a complaint of ragging is made, such person shall be
deemed to have abetted the offence of ragging and shall on conviction
be punished as provided in section 4.

<!-- page 3 -->

B] ADMINISTRATIVE ACTION IN THE EVENT OF RAGGING
The institution shall punish a student found to be guilty of ragging
after following procedure:
A) Anti ragging committee of the institution shall take an
appropriate decision following recommendations of the anti
ragging squad.
B) Anti ragging committee may depending on the nature and
gravity of guilt recommend one or more of the following
punishments namely:
i. suspension from attending classes and academic privileges
ii. withholding or withdrawing scholarship/fellowship & other
benefits
iii. Debarring from appearing in test or examinations
iv. withholding results
v. debarring from representing the institution in any regional ,
national , or international event
vi. suspension or expulsion from the hostel
vii. cancellation of admission
viii. rustication from institution for period ranging from 1-4
semesters
ix. expulsion from institution and consequent debarring from
admission to any other institutions for a specified period.
Prevention of ragging/anti ragging measures
The college has setup appropriate committees to actively
monitor,promote and regulate healthy interaction between the
freshers,juniors and seniors students to prevent ragging
1)Anti-ragging committee:The institution has nominated antiraggingcommittee headed by dean .It consists of faculty members,
representative of parents,representative of students from fresher’s
and seniors and non teaching staff .It shall be duty of antiragingcommittee to co-ordinate with various committees to
prevent ragging in the institution .
2)Anti-ragging squad: It is nominated by the principal.Theantiragging squad shall remain mobile ,alert and active all time to

<!-- page 4 -->

maintain vigilance and patrolling .It shall make surprise raids on
hostel and other places vulnerable to incident of ragging .It shall
investigate incidence of ragging and report anti ragging committee
3)Display: The names of anti ragging committee members ,anti
ragging squad members and hostel wardens are displayed on
notice board along with their contact number
4)Teacher –Guardian system: It should be implemented for 1st
B.D.S. students with the help of teachers involved in teaching
them. About 5-10 students will be allotted to one teacher. They are
to meet the concerned teacher every week to discuss various
problems faced by students.
5)Orientation programme : A joint ‘Sensitization’ and orientation
programme and counselling both fresher’s and seniors to be
addressed by the principal and professional counsellors. The
inmates of hostel shall be addressed by hostel warden.
6)Sensitization towards the ills of ragging and prevention of there
of and obtaining undertaking from every employee of the college
including teaching and non teaching members of staff, contract
labour employed in the premises. A provision shall be made in
service rules for issuing certificates of appreciation such member
of the staff who report ragging which will form part of their service
record.
7)The employers/employees of the canteens / mess shall be given
necessary instructions to keep the strict vigil and to report the
incidence of ragging to the college authorities, if any.
8)Wardens of the hostel are to take rounds of the hostel daily.
9)Affidavit from the student and parents: The affidavit from each
student and his/her parents is obtained and the copies are available
in the office.
10)Counselling of fresher’s: The professional counsellors shall
counsel fresher’s in order to prepare them for life ahead,
particularly in regard to life in hostel and to the extentpossible ,
also involved parents and teachers in counselling sessions.

<!-- page 5 -->

11)For Newly admitted students and for the students who want to
be anonymous in their complaints, the complaints should be
submitted to the administrative office.
12)Fresher’s welcome party: Fresher’s welcome party shall be
organized by the senior students and the faculty together after
admissions within two weeks of beginning of the academic session,
for proper introduction to one another and where the talents of the
fresher are brought out properly in the presence of faculty, thus
helping them to shed theirinferiority complex , if any , and remove
their inhibitions.

<!-- page 6 -->

SR.
NO.
1.
2.

3.
4.
5.
6.
7.
8.

9.

10.

1.
2.
3.
4.
5.

ANNEXURE C
ANTI-RAGGING COMMITTEE
Designation
Name
Phone No
Head of the
Institute
Police
Department
Representative
Local Media
Representative
NGO
Parents
Representative
New Student
Representative
Senior Student
Representative
Non Teaching
Staff
Representative
Revenue
Administration
Department
Representative
Faculty Member
Representative

Dr.GirishParmar (Dean) 9426006569
Shri P.K. Khant

9925790429

Shri R.R. Shukala
9904246195
(Amrutmanthan)
SonalbenModi
9825062644
ShriPravinbhaiSonagara 9725866246
DamorPankaj

9998119976

Swati Ranpara

7359291447

Mr. P.N. Patel

9925506061

(Mamlatdar)

079-27561970

Dr.GeetaAsthana

9925586956

Annexure B
Anti Ragging Squad
Designation
Name
Hostel Rector
Dr.GeetaAsthana
Senior student representative Patel Chintan
(boys)
Senior student representative Meet Dodiya
(girls)
New student representative
Hardik Shah
(boys)
New student representative
VasavaPriyanka
(girls)

Phone no.
99255586956
9879271403
9033609991
9974661221
9824715290

<!-- page 7 -->

OTHER IMPORTANT CONTACTS
Sr.no
1.
2.
3.
4.
5.
6.
7.
8.

Designation
Hostel Rector
Hostel warden
Hostel warden
Girls hostel warden
Girls hostel asst.
Warden
Girls hostel asst.
Warden
Administrative officer
Shahibaug police
station

Name
Dr.GeetaAsthana
Dr. Rajesh shah
Dr. Vishal Chauhan
Dr. Rachana Shah
Dr. Swati Goyal

Phone No
99255586956
9824669672
9824094872
9898111179
9909947117

Dr. SonalBedi

8000395412

DamorPankaj
-----

9998119976
079-25627187

<!-- page 8 -->

Undertaking By Parents/Guardians
1. I, ________________________________________ F/O , M/O, G/O Mr.
/ Ms. _______________________________________have carefully read
and fully understood the law of prohibiting ragging and directions of the
hon. Supreme court and the central/ state govt. in this regard as well as
the DCI regulations on curbing the menace of ragging in higher education
institutions 2009.
2. I assure you that my son / daughter / ward will not indulge in any act of
ragging.
3. I hereby agree that if he / she is found guilty in any aspect of ragging, he /
she maybe punished as per the provisions of DCI regulations.
Signed _________ day of __________ month of _________ year.

Signature
Address:____________________________________
____________________________________
____________________________________
____________________________________

Witness 1
Name
Contact Details
(Including Address
Proof)

Witness 2

<!-- page 9 -->

Undertaking By Candidate/Student
1. I, ________________________________________ S/O , D/O, W/O of
Mr. / Ms. _______________________________________have carefully
read and fully understood the law of prohibiting ragging and directions of
the hon. Supreme court and the central/ state govt. in this regard as well
as the DCI regulations on curbing the menace of ragging in higher
education institutions 2009.

2. I assure you that I shall not indulge in any act of ragging.
3. I hereby agree that if I am found guilty in any aspect of ragging ,Imaybe
punished as per the provisions of DCI regulations.
Signed _________ day of __________ month of _________ year.

Signature
Address:____________________________________
____________________________________
____________________________________
____________________________________

Witness 1
Name
Contact Details
(Including Address
Proof)

Witness 2
