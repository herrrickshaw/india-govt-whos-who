---
doc_id: "bacb7e7c67c4f5bc"
source_url: "https://www.bknmu.edu.in/uploads/assest/circularforph09042025110229215.D.Admission2024-2025.pdf"
ministry: "Bhakta Kavi Narsinh Maheta University, Gujarat"
title: "Admission in PhD Program 2024-2025"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1171ea4eaf137e90"
---

<!-- page 1 -->

પરિપત્ર :
ભક્તકવિ નરવસિંહ મહેતા યુવનિવસિટીમાાં પીએચ.ડી.પ્રિેશ-૨૦૨૪-૨૦૨૫ માટે GCAS
પોટટ લ મારફત ઓનલાઈન અરજી કરિાની રહેશ.ે પીએચ.ડી. પ્રિેશ ફોમટ ભર્ાટ બાદ
ઓનલાઈન ભરે લ ફોમટની વપ્રન્ટ તથા GCAS પોટટ લ પર અપલોડ કરે લા તમામ
ડોક્યુમેન્્સની સ્િપ્રમાણિત નકલ બે કોપીમાાં અને ઓરીજીનલ ડોક્યુમેન્્સ સાથે
વિદ્યાથીઓએ િેરીફીકેશન માટે ભકતકવિ નરવસિંહ મહેતા યુવનિસીટી, જુનાગઢ ખાતે
તા.૧૪/૧૦/૨૦૨૪ થી તા.૨૩/૧૦/૨૦૨૪ સુધીમાાં સિારે ૧૧:૦૦ થી બપોરે ૦૩:૩૦
દરવમર્ાન રૂબરૂમાાં આિિાનુ ાં રહેશે અને પ્રોસેવસિંગ ફી રૂ. ૧૦૦૦/- સાથે જમા કરાિિાની
રહેશે. ત્ર્ારબાદની પ્રક્રિર્ા હિે પછી જાહેર કરિામાાં આિશે.

ચેિમેન અને નોડલ ઓરિસિ

પીએચ.ડી. એડમીશન કમમટી

ભકતકમિ નિમસિંહ મહેતા યમુ નિસીટી
જુનાગઢ

િમાાંક : બીકેએનએમયુ/પીએચ.ડી./૮૩૪/૨૦૨૪
ભક્તકવિ નરવસિંહ મહેતા યુવનિવસિટી, જુનાગઢ
તા.૦૩/૧૦/૨૦૨૪

<!-- page 2 -->

BHAKTA KAVI NARSINH MEHTA UNIVERSITY
JUNAGADH.

Subject

Mapped subject/s

Open

SC

ST

SEBC

Total Seats

EWS

Overall Total
Vacant Seats

Ph. D. Admission-2024-2025
Vacant Seats

1

BOTANY

BOTANY

3

0

1

1

5

0

5

2

CHEMISTRY

CHEMISTRY

8

1

2

4

15

1

16

3

ZOOLOGY

ZOOLOGY

4

1

1

2

8

1

9

4

COMPUTER SCIENCE

COMPUTER SCIENCE

2

0

1

1

4

0

4

5

ECONOMICS

ECONOMICS

2

0

1

1

4

0

4

6

SOCIOLOGY

SOCIOLOGY

3

0

1

1

5

1

6

7

PSYCHOLOGY

PSYCHOLOGY

8

1

2

4

15

1

16

8

HISTORY

HISTORY

2

0

1

1

4

1

5

9

HINDI

HINDI

16

2

5

8

31

3

34

10

ENGLISH

ENGLISH

7

1

2

3

13

1

14

11

GUJARATI

GUJARATI

5

1

1

2

9

1

10

12

SANSKRIT

SANSKRIT

8

1

2

4

15

1

16

13

COMMERCE/ACCOUNTAN
CY

COMMERCE/ACCOUNTAN
CY

4

1

1

2

8

1

9

14

EDUCATION

EDUCATION

3

0

1

2

6

1

7

15

LAW

LAW

1

0

0

1

2

0

2

WILD LIFE SCIENCES

Botany, Zoology,
Microbiology, Biotechnology,
Forestry, Environmental
Science, Conservation Biology
or any allied subjects.

2

0

0

1

3

0

3

Total 78

9

22

38

147

13

160

16

Page 1 of 6

<!-- page 3 -->

INSTRUCTIONS, RULES AND REGULATIONS
1. A candidate shall be eligible to apply for Ph.D. admission only in the Subject in which he/she
has obtained Master's Degree (except wildlife sciences) with at least 55% without grace
marks in the respective subject. A relaxation of 5% of marks for reserved category will be
applicable.
2. The candidates can select only one subject for Ph.D.Admission. He/She cannot apply for
more than one subject.
3. Candidates for admission to the Ph.D. programme should have a Master's degree or a
professional degree declared equivalent to the Master’s degree in the concerned subject by
the corresponding statutory regulatory body, with at least 55% marks in aggregate or its
equivalent grade in a point scale wherever grading system is followed or an equivalent
qualification from a foreign educational Institution accredited by an Assessment and
Accreditation Agency which is approved, recognized or authorized by an authority,
established or incorporated under a law in its home country or any other statutory authority in
that country for the purpose of assessing, accrediting or assuring quality and standards of
educational institutions.
4. A relaxation of 5% of marks, from 55% to 50%, or an equivalent relaxation of grade, may be
allowed for those belonging to SC/ST/OBC (non-creamy layer)/Differently-Abled(as per
Govt. of Gujarat Rules), Economically Weaker Section (EWS) and as per the decision of the
Commission from time to time, or for those who had obtained their Master's degree prior to
19th September, 1991. The eligibility marks of 55% (or an equivalent grade in a point scale
wherever grading system is followed) and the relaxation of 5% to the categories mentioned
above are permissible based only on the qualifying marks without including the grace mark
procedures.
5. The University may increase or decrease availability of seats/subjects.
6. Central/State Government rules will be applicable for reservation policy.
7. Candidates who got degree in M.A. Education are not eligible to apply for Education subject.
8. Candidates should access University website regularly for updates.
9. The Processing fee is Rs. 1000/- (One Thousand Only) which is non-refundable and should
be paid at the time of physical verification.
10. All the communications will be sent to the candidates through their registered email ID only.
Hence the candidates are advised to write their email ID and mobile number carefully.
11. The candidates are to study the BKNMU Ph.D. ordinances-2023 which is uploaded
Page 2 ofon6

<!-- page 4 -->

University website.
12. If there is a grade point in your marksheet, you have to convert the grade into percentage and
upload the conversion certification duly attested by the competent authority along with your
marksheet.
13. After successful registration on GCAS portal, students should have to visit the Ph.D.Section,
Bhakta Kavi Narsinh Mehta University for physical verification of documents. Candidates
should visit the university website for dates of physical verification.
14. The candidates should have to submit two hard copies of application along with fee receipt and
all the documents uploaded on the GCAS portal at the time of physical verification of
documents. All documents should be self attested.
15. Syllabus of Ph.D. Entrance Test is as per UGC, CSIR NET/GSET/PG level. The syllabus of
Wildlife will be uploaded on the university website soon.
16. You

are

advised

to

visit

https://www.ugcnetonline.in/syllabus-new.php

and

https://gujaratset.ac.in/syll for syllabus of paper-1 and your concerned subject.
17. Paper style of the Ph.D. Entrance Test will be as follow:
There will be two papers:
Paper I: Research Methodology
This paper will have 50 multiple choice questions. It will be common for all subjects.
Examination time is 1:00 hour. Syllabus of this paper will be based on Research
Methodology/NET/GSET paper-1 contents of UGC, CSIR NET/GSET/PG Level.
Paper II: Subject Specific
This paper will have 50 multiple choice questions. Examination time is 1:00 hour. Contents
of this paper will be subject specific.
18. Total marks for PET will be 100 for 100 MCQs, each of them carries one mark.
19. The qualifying marks for the Ph.D. Entrance Test will be 50% - in aggregate (paper-1 &
Paper-II). A relaxation of 5% of marks, from 50% to 45% shall be allowed for those
belonging to SC/ST/OBC/SEBC(non-creamy layer)/Differently-Abled and Economically
Weaker Section (EWS) candidates.
20. A final merit list will be prepared after interview/viva-voce (RAC) as per following criteria
•

70 % of marks obtained in PET/NET/GSET (current year exam only) and

•

30 % marks of presentation cum interview/Viva Voce (RAC)

NOTE: If the marks are not displayed on the marksheet (For previous year students),
Page 3 of 6

<!-- page 5 -->

presentation/viva voce marks will be converted into 100.
21. A candidate who has cleared UGC/CSIR NET/SLET/GSET are exempted from PET-20242025, but such candidates must pay processing fee of Rs.1000/- (One Thousand Only). These
candidates shall have to appear in the RAC for presentation interview/ viva-voce.
22. If the candidate’s research proposal is not upto the mark, Research Advisory Committee can
summarily reject the proposal at the time of presentation/viva voce. Such candidates will be
treated as ‘Not Eligible’ for admission in Ph.D. Programme.
23. If any candidate raises any doubt about any item/question during PET, he / she should be
advised to answer the item/question as given in the paper and send a mail to
phd@bknmu.edu.in on the day itself. After the date of PET examination, such doubts will not
be considered.
24. There will be no negative marking system in PET.
25. A list of the qualified candidates of PET will be declared on University Website
http://bknmu.edu.in as well as on University Notice Board.
26. Qualifying PET-2024-2025 does not give guarantee to a candidate to be registered for Ph.D.
programme.
27. Visually Handicapped (as per the norms) candidates will be given 20 minutes extra time for
Paper-1 and 20 minutes extra time for Paper-2. Such candidates may be provided with the
services of an amanuensis (writer). The writer should be undergraduate, e.g. B.A.
/B.Sc./B.Com., level only. The writer must not be from the same subject (For other than
language subjects). For Language Subjects e.g. Hindi, Guajarati. Sanskrit and English, writer
may be from the same subject. His/her identity must be checked. Such candidates are not
allowed to bring their own amanuensis (Writer). Visually Handicapped candidates should apply
to the Chairman of PET before five days of the PET exam requesting for writer.
28. After completion of RAC, final merit list for admission in Ph.D. programme of the successful
candidates will be declared by the university on its website http://bknmu.edu.in and on
University Department Notice Board.
29. Validity of the PET and merit shall be only for the academic year 2024-2025.
30. Candidates should download his/her Hall Ticket before three days of PET from
www.bknmu.edu.in
31. Candidate will not be allowed to enter PET centre without Hall Ticket
32. Candidate should keep with him/her any one original Identity Proof (Aadhar Card/Voter Card/
Driving License/PAN card/Passport).
33. It is mandatory for all candidates to submit two hard copies of their online application
Page 4 ofform
6

<!-- page 6 -->

along with all supporting self-attested documents to the Chairman, PET-2024-2025, Academic
Section (Ph.D), Govt. Polytechnic Campus, BKNM University Road, Bhakta Kavi Narsinh
Mehta University, Khadiya, Junagadh-362 263 at the time of physical document verification.
34. International Scholars will be exempted from the PET, but they should pay processing fee of
Rs.1000/- (One Thousand Only) at the time of presentation/Viva Voce. Physical verification of
such candidates will be done at the time of presentation/viva-voce.
35. Without payment of due processing fee, your registration will be treated as cancelled.
36. The eligible candidates will be called for interview/viva voce, within one week after declaration
of PET result. The schedule will be uploaded on the university website. You should have to
submit Research Proposal in five hard copies within seven days after declaration of PET result
to Chairman, Ph.D.Admission Committee, Bhakta Kavi Narsinh Mehta University, Junagadh
either in person or through courier. This will be applicable to exempted candidates as well.
37. The schedule for physical verification of documents, PET date, PET venue etc will be uploaded
on university website.
38. In case of any dispute, decision of the Vice Chancellor, BKNMU will be final and binding to
all concerned.
Check-List
•

Latest Marksheet of PG

•

School Leaving Certificate

•

Caste Certificate (If Applicable)

•

Non-Creamy Layer Certificate (If Applicable) which should be valid for the year 20242025.

•

Differently Abled Certificate (If Applicable)

•

EWS Certificate (If Applicable)

•

Domicile Certificate (If Applicable) which is applicable for other states candidates

•

Two Latest passport size Photographs

•

Valid Passport & Visa for International Candidates

•

Application form along with GCAS fee receipt

•

Any other documents which are uploaded on the GCAS Portal.

*****************************************

Page 5 of 6

<!-- page 7 -->

Steps to be followed by the Universities and Students
for Admission Process in Ph.D. Program through GCAS
For affiliated and constituent colleges / Department of following Universities
(Bhakta Kavi Narsinh Mehta University, Children’s Research University, Dr. Babasaheb Ambedkar Open
University, Gujarat University, Hemchandracharya North Gujarat University, Indian Institute of Teacher
Education, Krantiguru Shyamji Krishna Verma Kachchh University, Maharaja Krishnakumarsinhji
Bhavnagar University, Sardar Patel University, Saurashtra University, Shri Govind Guru University, The
Maharaja Sayajirao University of Baroda, and Veer Narmad South Gujarat University)

Date and
Duration
01-10-2024 to
10-10-2024
As per each
University’s
schedule
11-10-2024
Onwards

Step

STEP 1

STEP 2

STEP 3

Process
Application fill up, choice filling, registration
Fee payment and submission by Students on
GCAS Portal
Verification of online application along with all
original documents at University’s PhD
Application Verification Center.
Admission Process as declared by Universities

Action to be
performed by
Students

Students and
Universities
University / College

Guidelines for STEP 2:
1. Students must verify their online applications along with all original documents at the PhD
Application Verification Center of each university to which they have applied, according to the
schedule declared by each university.
વિદ્યાર્થીઓએ દરે ક યુવિિવસિટી દ્વારા જાહે ર કરાયેલ સમયપત્રક અિુસાર, દરે ક યુવિિવસિટીિા પીએચડી એવલલકે શિ
િેરીફીકે શિ સેન્ટર પર તમામ મૂળ દસ્તાિેજો સાર્થે તેમિી ઑિલાઇિ અરજીિુું િેરીફીકે શિ કરાિિુું આિશ્યક છે .

2. In the event of any discrepancies or if any data needs correction during the verification process,
the university officials will unlock the student's GCAS application. The student must then rectify
the details as per the instruction of the university before resubmitting their application.
જો િેરીફીકે શિ પ્રક્રિયા દરવમયાિ કોઈપણ વિસુંગતતાિા ક્રકસ્સામાું અર્થિા કોઈપણ વિગતમાું સુધારાિી જરૂર હોય,
તો યુવિિવસિટીિા અવધકારીઓ વિદ્યાર્થીિી GCAS એવલલકે શિિે અિલૉક કરશે. ત્યારબાદ વિદ્યાર્થીએ
યુવિિવસિટીિી સૂચિા મુજબ તેમિી અરજીમાું જરૂરી સુધારા કરી અરજી ફરી સબવમટ કરિાિી રહે શે.

3. After resubmitting the application, the student must re-verify their application from the
respective university for it to be considered.
અરજી ફરીર્થી સબવમટ કયાિ પછી, વિદ્યાર્થીએ તેિી અરજી ધ્યાિમાું લેિા માટે તેમિી અરજીિુું સુંબવું ધત યુવિિવસિટી
દ્વારા ફરીર્થી િેરીફીકે શિ કરાિિુું આિશ્યક છે .

4. Students need to regularly check the GCAS portal and university’s portal for updates and further
instructions.
વિદ્યાર્થીઓએ અપડે ટ્સ અિે િધુ સૂચિાઓ માટે વિયવમતપણે GCAS પોટિ લ અિે યુવિિવસિટીિા પોટિ લિે તપાસિા
જોઈએ.

Important Points:
1. GCAS serves as a platform through which students can apply to PhD programs at multiple state
government universities using a single application.
Page 1 of 2

<!-- page 8 -->

GCAS એક લલેટફોમિ તરીકે સેિા આપે છે જેિા દ્વારા વિદ્યાર્થીઓ એક જ એવલલકે શિિો ઉપયોગ કરીિે રાજ્યિી
બહુવિધ સરકારી યુવિિવસિટીઓમાું પીએચડી પ્રોગ્રામ માટે અરજી કરી શકે છે .

2. Applying through the GCAS portal does not guarantee admission or confirm eligibility for the
selected PhD program. Students must review the eligibility criteria of each university to which
they are applying and ensure compliance with those requirements.
GCAS પોટિ લ મારફત ઓિલાઈિ અરજી કરિાર્થી પસુંદ કરે લ પીએચડી પ્રોગ્રામ માટે પ્રિેશ અર્થિા પાત્રતાિી ખાતરી
આપિામાું આિતી િર્થી. વિદ્યાર્થીઓએ તેઓ જેટલી યુવિિવસિટીિા પીએચડી પ્રોગ્રામમાું અરજી કરે છે તે તમામ
યુવિિવસિટીિા પાત્રતા માપદુંડોિી સમીક્ષા કરી તેિા જરૂક્રરયાતોિુું પાલિ સુવિવિત કરિાિુું છે .

3. Students will not be able to edit their online applications once submitted, unless the respective
university returns the application for editing and resubmission. Additionally, once online
application is submitted by students after selecting subjects and universities, they shall not be
allowed to make any changes.
વિદ્યાર્થીઓ એકિાર ઓિલાઈિ અરજી સબવમટ કયાિ પછી તેમિી ઑિલાઇિ અરજીમાું કોઈ પણ સુધારો કરી શકશે
િહીં, વસિાય કે સુંબુંવધત યુવિિવસિટી સુધારા અિે ફરીર્થી સબવમશિ માટે અરજી પરત િ કરે . િધુમાું, એકિાર
વિષયો અિે યુવિિવસિટીઓિી પસુંદગી કરી અરજી સબવમટ કયાિ પછી વિદ્યાર્થીઓ તેમાું કોઈ ફે રફાર કરી શકશે િક્રહ.

4. Since universities conduct an Entrance Test for the PhD program, students are required to pay
the Entrance Test fees and other Relevant Process fees for each university they have selected
separately as declared by the respective universities, in addition to the Registration Fee
(Rs. 300/-) for the GCAS portal.
યુવિિવસિટીઓ પીએચડી પ્રોગ્રામ માટે પ્રિેશ કસોટીિુું આયોજિ કરતી હોિાર્થી, વિદ્યાર્થીઓએ GCAS પોટિ લિી
િોંધણી ફી (રૂ. 300/-) ઉપરાુંત તેમણે પસુંદ કરે લ દરે ક યુવિિવસિટી માટે અલગર્થી પ્રિેશ કસોટી ફી કે અન્ય
લાગુ પડતી પ્રોસેસ ફી ચૂકિિી જરૂરી છે .

5. In case of students selecting Gujarat University, they shall have to pay Rs.700/- other Relevant
Process fees levied completely by the Gujarat University along with the GCAS registration fees.
This Rs. 700/- fees is solely collected by GCAS on request of Gujarat University and GCAS has no
other role in this fees.
વિદ્યાર્થીઓ દ્વારા ગુજરાત યુવિિવસિટી પસુંદ કરિાિા ક્રકસ્સામાું, તેમણે ગુજરાત યુવિિવસિટી દ્વારા સુંપણ
ૂ િપણે
િસૂલિામાું આિતી અન્ય સુંબુંવધત પ્રક્રિયા ફી રૂ.700/- GCAS િોંધણી ફી સાર્થે ચૂકિિાિી રહે શે. આ રૂ. 700/ફી માત્ર ગુજરાત યુવિિવસિટીિી વિિુંતી પર GCAS દ્વારા લેિામાું આિે છે અિે આ ફીમાું GCASિી અન્ય કોઈ ભૂવમકા
િર્થી.

6. Students should regularly check the GCAS portal and university’s portal for further updates
regarding the admission process.
વિદ્યાર્થીઓએ પ્રિેશ પ્રક્રિયા સુંબુંવધત િધુ અપડે ટ્સ માટે GCAS પોટિ લ અિે યુવિિવસિટીિા પોટિ લિે વિયવમતપણે
તપાસિુું જોઈએ.

7. Guidelines and timelines for each university's processes will be uploaded to the GCAS portal as
they are received from the respective universities.
સુંબુંવધત તમામ યુવિિવસિટીઓિી પ્રિેશ પ્રક્રિયાઓ માટે િી માગિદવશિકા અિે સમયરે ખા સુંબુંવધત યુવિિવસિટીઓ
તરફર્થી પ્રાપ્ત ર્થયેર્થી GCAS પોટિ લ પર અપલોડ કરિામાું આિશે.

**********

Page 2 of 2
