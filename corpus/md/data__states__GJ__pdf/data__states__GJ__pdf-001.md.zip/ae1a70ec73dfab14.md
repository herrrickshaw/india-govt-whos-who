---
doc_id: "ae1a70ec73dfab14"
source_url: "https://www.bknmu.edu.in/uploads/assest/notificationph09042025110151121.D.Ordinances_2023.pdf"
ministry: "Bhakta Kavi Narsinh Maheta University, Gujarat"
title: "Ph.D Ordinances 2023"
date: ""
pages: 42
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5584196f15bdf485"
---

<!-- page 1 -->

BHAKTA KAVI NARSINH MEHTA UNIVERSITY
JUNAGADH
Gujarat Public Universities Act No.15/2023

________________________________________________________
REF.:BKNMU/Academic/Ph.D./27/2024

Date: 30/01/2024

NOTIFICATION
It is notified that as per decision taken in the meeting of Academic Council
dated 19.10.2023 vide its resolution No.20.20, meeting of Executive Council dated
07.11.2023 vide its resolution No.39.31.02, and meeting of Board of Governors
dated 18.11.2023 vide its resolution No. 7.7, the Ordinances for Ph.D.Programme of
Bhakta Kavi Narsinh Mehta University, Junagadh has been made and annexed
herewith. These ordinances come into force from the date of its publication.

Officer on Special Duty
(Academic)
Copy to:
• Dr.Atul H.Bapodra, Professor and Head, Dept. of Chemistry and Forensic
Science, Bhakta Kavi Narsinh Mehta university, Junagadh
• Dr.Suhas Vyas, Professor and Head, Dept. of Life Sciences, Bhakta Kavi
Narsinh Mehta university, Junagadh
• Dr.Jaysinh B.Zala, Professor and Head, Dept. of Social Sciences and Social
Works (Sociology), Bhakta Kavi Narsinh Mehta university, Junagadh
• Dr.Vishal Joshi, Professor, Dept. of Social Sciences and Social Works
(History), Bhakta Kavi Narsinh Mehta university, Junagadh
• Dr.Bhavsinh M.Bodia, Professor and Head, Dept. of Commerce and
Management, Bhakta Kavi Narsinh Mehta university, Junagadh
• Dr.Firoz Shaikh, Professor, Dept. of English, Bhakta Kavi Narsinh Mehta
university, Junagadh
• Account and Finance Officer, Account Section, Bhakta Kavi Narsinh Mehta
university, Junagadh
• System Manager, IT Section, Bhakta Kavi Narsinh Mehta university,
Junagadh (For uploading on the website)
• Officer on Special Duty, Academic Section, Bhakta Kavi Narsinh Mehta
university, Junagadh
• Coordinator, IQAC, Bhakta Kavi Narsinh Mehta university, Junagadh
Copy forwarded to:
• P.S. to Hon.Vice Chancellor/Registrar, Bhakta Kavi Narsinh Mehta University,
Junagadh

<!-- page 2 -->

BHAKTA KAVI NARSINH MEHTA
UNIVERSITY, JUNAGADH

PH.D. ORDINANCES-2023
(With Effect from the Academic Year 2023-2024)

Bhakta Kavi Narsinh Mehta University Road
Khadiya, Junagadh-362 263
www.bknmu.edu.in
phd@bknmu.edu.in
Ph: 0285-2681400

BKNMU Ph.D. Ordinances, 2023

Page 0

<!-- page 3 -->

TABLE OF CONTENTS
ORD.

TITLE OF THE ORDINANCE

NO.

PG.NO.

1

SHORT TITLE, APPLICATION AND COMMENCEMENT

02

2

DEFINITIONS

02

3

GENERAL RULES FOR ADMISSION IN PH.D. PROGRAMME

05

4

ELIGIBILITY CRITERIA FOR ADMISSION TO THE PH.D
PROGRAMME

5

PROCEDURE FOR ADMISSION

6

ADMISSION OF INTERNATIONAL STUDENTS IN PH.D.
PROGRAMME

7

PROCEDURE FOR CONDUCT OF ENTRANCE TEST FOR PH.
D PROGRAMME

06
07
10

10

8

RESEARCH ADVISORY COMMITTEE (RAC)

11

9

PREPARATION OF MERIT LIST

15

10

RECOGNITION AND ALLOCATION OF SUPERVISOR/COSUPERVISOR

16

11

DURATION OF THE PROGRAMME

19

12

PROCEDURE FOR REGISTRATION

21

13

ISSUING A PROVISIONAL CERTIFICATE

21

14

FEE STRUCTURE

22

15

COURSEWORK

23

16

EVALUATION AND ASSESSMENT

25

17

AWARD OF PH.D. DEGREES

29

18

DEPOSITORY WITH INFLIBNET

29

19

CANCELLATION OF PH.D. REGISTRATION

30

20

RESPONSIBILITIES OF GUIDES

30

21

GUIDELINES FOR PREPARATION AND SUBMISSION OF
Ph.D. THESIS

BKNMU Ph.D. Ordinances, 2023

31

Page 1

<!-- page 4 -->

BHAKTA KAVI NARSINH MEHTA UNIVERSITY
JUNAGADH
Ph.D. ORDINANCES-2023
O. Ph. D. 1

SHORT TITLE, APPLICATION AND COMMENCEMENT
This Ordinance shall be called by name “Bhakta Kavi Narsinh Mehta University,
(Minimum Standards and Procedures for Award of Ph.D. Degree) Ordinances, 2023”.
It shall come into force on the date as notified by the Bhakta Kavi Narsinh Mehta
University, Junagadh. It is applicable to all candidates who want to register for
Ph.D.Programme at Bhakta Kavi Narsinh Mehta University.
These ordinances shall apply to the Ph.D. studies conducted in different disciplines
in the University Post Graduate Departments, Constituent Colleges, Affiliated Colleges,
Recognized Institutes or P.G.Centers established and/or maintained by the Bhakta Kavi
Narsinh Mehta University for the purpose of Ph.D. studies.

O. Ph.D.2:

DEFINITIONS:

1

‘Act’ means the Bhakta Kavi Narsinh Mehta University Act, 2015.

2

“Adjunct Faculty” means a part-time or contingent instructor, but not full-time faculty
member hired to teach by a Higher Educational Institution;

3

“Cumulative Grade Point Average (CGPA)” means a measure of the overall cumulative
performance of a student over all semesters. The CGPA is the ratio of total credit points
secured by a student in various courses in all semesters and the sum of the total credits of
all courses in all semesters. It is expressed up to two decimal places;

4

“Credit” means the number of hours of instruction required per week over the duration of
a semester. A three-credit course in a semester means three one-hour lectures per week,
with each one-hour lecture counted as one credit.

5

“Commission” means the University Grants Commission established under Section 4 of
the UGC Act1956;

6

‘Candidate for Ph.D. Study’ means a candidate, who has obtained Master Degree in any
recognized discipline and has submitted his candidature for the purpose to enroll and
pursue Ph.D. with required qualification.

7

“College" means an institution engaged in higher education and/or research, either
established by a University as its constituent unit or is affiliated with it;

8

‘Affiliated College’, ‘Recognized Institution’, ‘Self Finance Institution’, 9‘University
Centre', 'University College', 'University Department', respectively means the said college,
institution, Centre or Department as provided under Section 2(1), 2(7), 2(10), 2(15), 2(16),

BKNMU Ph.D. Ordinances, 2023

Page 2

<!-- page 5 -->

2(17) of Act, which are approved and engaged to conduct Ph.D.research in any discipline.
9

‘Blood Relation’ means a relation which relates the supervisor and the research scholar by
any relations mentioned hereunder:
1)

Father and Son/Daughter.

2)

Mother and Son/Daughter.

3)

Father-in-Law and Son-in-Law/Daughter-in-Law.

4)

Mother-in-Law and Son-in-Law/Daughter-in-Law.

5)

Husband and wife which includes divorcee spouse also

6)

Brothers

7)

Sisters

8)

Brothers and Sisters

9)

Children of brothers and sisters

10

“Course” means one of the specified units which go to comprise a programme of study;

11

‘Course Work’ means the courses of study prescribed by the university/department/centre
to be undertaken by a student registered for Ph.D. Degree.

12

“Direct Contact” means a live contact between research supervisor and research scholar
for the purpose of supervision, monitoring and guidance concerned with the Ph.D. study.

13

“Degree” means a degree awarded by a Higher Educational Institution in accordance with
the provisions of section 22 (3) of the UGC Act.

14

“External examiner” means an academician/researcher with published research work who
is not part of the Higher Educational Institution where the Ph.D. scholar has registered for
the Ph.D. programme;

15

“Foreign Educational Institution” means–(i) an institution duly established or incorporated
in its home country and offering educational programmes at the undergraduate,
postgraduate and higher levels in its home country and (ii) which offers programme(s) of
study leading to the award of a degree through conventional face-to-face mode, but
excluding distance, online, ODL mode.

16

“Grade Point” means a numerical weight allotted to each letter grade on a 10-point scale;

17

“Guide/Research Supervisor” means an academician/researcher recognized by Higher
Educational Institution to supervise the Ph.D. scholar for his/her research;

18

“Higher Educational Institution” means a university or institution specified under clause 2
of Regulation 1 of UGC Regulations-2022;

19

“Open and Distance Learning Mode” shall have the same meaning as defined under the
UGC (Open and Distance Learning Programmes and Online Programmes) Regulations
2020;

BKNMU Ph.D. Ordinances, 2023

Page 3

<!-- page 6 -->

20

“Online Mode” shall have the same meaning as defined under the UGC (Open and
Distance Learning Programmes and Online Programmes) Regulations 2020;

21

“Plagiarism” means the practice of taking someone else’s work or idea and passing them
as one’s own;

22

“Programme” means a higher education programme pursued for a degree specified by the
Commission under sub-section (3) of section 22 of the UGC Act;

23

“Prospectus” means any document, whether in print or otherwise, issued for providing fair
and transparent information relating to a Higher Educational Institution and programmes,
to the general public (including to those seeking admission in such Higher Educational
Institutions) by the Higher Educational Institutions;

24

“Research Proposal” means a brief write-up giving an outline of the proposed research
work which the Ph.D. Scholar shall submit along with the application for registration for
Ph.D. programme;

25

“University” means a Higher Educational Institution established or incorporated by or
under a Central Act, a Provincial Act, or a State Act, and shall include any institution for
higher education deemed to be a University under Section 3 of the UGC Act.

26

“Enrollment” means an enrollment of research scholar for the purpose to conduct research
study for the Ph.D. degree programme after fulfillment of relevant statutory requisites.

27

Inter/Multi-disciplinary research means research conducted by a Ph.D. Research Scholar
in two or more academic disciplines.

28

“Ordinance” means the Ph.D.Ordinances of the Bhakta Kavi Narsinh Mehta University.

29

“Ph.D. Degree” means the degree of ‘The Doctor of Philosophy’ in any discipline as
provided under the Statute of the Bhakta Kavi Narsinh Mehta University, Junagadh.

30

“Principal Supervisor” means Research Supervisor who supervises or guides Ph.D.
Scholar along with any other co-supervisor. In absence of co-supervisor, the research
scholar will be supervised only by one Research Supervisor and he/she will not be called a
“Principal Research Supervisor” but only “Research Supervisor”. Co-supervisor/Co-guide
means other than principal Research Supervisor/guide. In this document, the terms
Research Supervisor and Guide are used interchangeably.

31

“PET” means Ph.D. Entrance Test - an eligibility test conducted to determine the
eligibility of the candidate for Ph.D. study.

32

“Research Scholar” means a scholar, who satisfies all the mandatory requisites for the
purpose to enroll as Ph.D. scholar in any discipline and has been enrolled as a Ph.D.
Scholar at Bhakta Kavi Narsinh Mehta University.

33

“Statute” means the ‘Statutes’ of the University.

BKNMU Ph.D. Ordinances, 2023

Page 4

<!-- page 7 -->

34

“Teachers” means a teacher, as defined under section 2(12) of the University Act.

35

“University” means the ‘Bhakta Kavi Narsinh Mehta University’ established by the
Gujarat Act No.23 of 2015.

36

‘BKNMU’ means Bhakta Kavi Narsinh Mehta University, Junagadh

37

RAC means ‘Research Advisory Committee’ constituted for subjects as stated in UGC
NET/GSET examination and by University P.G. Departments/Academic/Ph.D. Section,
Bhakta Kavi Narsinh Mehta University to carry out evaluation of Ph.D. Studies and other
matters related to research.

38

R & D Cell means Research and Development Cell. This board will advise the authorities
of the University on all matters connected with the promotion of advanced studies and
research of the Universities.

O.Ph.D.-3:
3.1

GENERAL RULES FOR ADMISSION IN PH.D. PROGRAMME
The University shall not allow any student to register for Ph.D. programme through the
mode of distance education.

3.2

It shall be mandatory for the Ph.D. research scholar to conduct the Ph.D. study at their
respective Departments or affiliated Colleges/Institutions for the purpose to conduct
research study in any discipline.
Provided that such student has to get approval from the RAC and the concerned Principal
Supervisor/Co-Supervisor to conduct research in any other University or Department or
Institute or College, in case of no provision for such practicals and experiments in their
own Institute or Department or College.

3.3

It shall be mandatory for the Ph. D. research scholar to be in direct and fruitful contact
with his supervisor/s. Review of the related literature, review of published research in the
subject, laboratory work, field work, seminar/conference, teaching(online/offline) and
study of different contemporary and development issues in the subject/topic. etc. will be
considered as direct and fruitful contact hours. The research scholar is required to submit a
certificate issued by his Ph.D. supervisor (to the said effect) to the University when
university demands.

3.4

The determination of subject for PET will be conducted in subjects explicitly prescribed in
UGC/CSIR/NET/SET examinations. The subsequent RACs will also be constituted in the
same manner of the subjects prescribed in the said examination.

3.5

The scholars shall follow the ordinances/rules and regulations prescribed by the
University from time to time, even if they are not included in these Ordinances. The
University shall have the right to modify, change or add to the ordinances/rules and
regulations which shall be binding to the scholars.

BKNMU Ph.D. Ordinances, 2023

Page 5

<!-- page 8 -->

3.6

The

Ph.D.

scholars

shall

be

entirely

responsible

for

any

duplication

or

plagiarism/academic dishonesty or piracy occurring in the thesis. In case any such acts are
detected even after the award of the degree, the scholar shall be held accountable for the
irregularity and this may even lead to cancellation of the degree. The decision of the
University in this regard shall be final and binding to the scholar.
3.7

If any differences of opinion/ develop between the research scholar and the guide at any
time during the course of the research work, it should be put before RAC and the decision
of RAC in this matter shall be final and binding to the research scholar and the guide. If
guide is the member of RAC, he/she will have no right in final decision but he/she will be
allowed to present his/her case for such case/s.

3.8

The Vice Chancellor is the final authority to take final decision of any kind in case of
emergency.

O.Ph.D..4:
4.1

ELIGIBILITY CRITERIA FOR ADMISSION TO THE PH.D PROGRAMME
Candidates who have completed:
1) A 1-year/2-semester master's degree programme after a 4-year/8-semester
bachelor’s degree programme or a 2-year/4-semester master’s degree programme
after a 3-year bachelor’s degree programme or qualifications declared equivalent
to the master’s degree by the corresponding statutory regulatory body, with at least
55% marks in aggregate (without grace marks) or its equivalent grade in a point
scale wherever grading system is followed;
OR equivalent qualification from a foreign educational institution accredited by an
assessment and accreditation agency which is approved, recognized or authorized
by an authority, established or incorporated under a law in its home country or any
other statutory authority in that country to assess, accredit or assure quality and
standards of the educational institution.
A relaxation of 5% marks or its equivalent grade may be allowed for those
belonging to SC/ST/OBC (non-creamy layer)/Differently-Abled, Economically
Weaker Section (EWS) and other categories of candidates as per the decision of
the Commission from time to time.
Provided that a candidate seeking admission after a 4-year/8-semester bachelor’s
degree programme should have a minimum of 75% marks in aggregate or its
equivalent grade on a point scale wherever the grading system is followed. A
relaxation of 5% marks or its equivalent grade may be allowed for those belonging
to SC/ST/OBC (non-creamy layer)/Differently-Abled, Economically Weaker
Section (EWS) and other categories of candidates as per the decision of the

BKNMU Ph.D. Ordinances, 2023

Page 6

<!-- page 9 -->

Commission from time to time.
2) Candidates who have completed the M.Phil. programme with at least 55% marks
in aggregate (without grace marks) or its equivalent grade in a point scale
wherever grading system is followed or equivalent qualification from a foreign
educational institution accredited by an assessment and accreditation agency which
is approved, recognized or authorized by an authority, established or incorporated
under a law in its home country or any other statutory authority in that country to
assess, accredit or assure quality and standards of educational institutions, shall be
eligible for admission to the Ph.D. programme. A relaxation of 5% marks or its
equivalent grade may be allowed for those belonging to SC/ST/OBC (non-creamy
layer)/Differently-Abled, Economically Weaker Section (EWS) and other
categories of candidates as per the decision of the Commission from time to time.
O.Ph.D.5:
5.1

PROCEDURE FOR ADMISSION
All the eligible candidate should have to apply for PET in the subject and faculty in which
he/she possesses master's degree.

5.2

Subject to the provision of this ordinances, the University administration shall be required
to respect the reservation policy formulated and changed from time and again by the
Govt. of Gujarat in selection of the candidates for Ph.D. studies and their admission.

5.3

The University shall conduct an Entrance Test to be called Ph.D. Entrance Test (PET) and
Personal Interview/Viva Voce to determine the ‘eligibility’ of the candidate to conduct
Ph.D. study in the respective subject.

5.4

The PET examination shall be conducted only in the subjects in which
UGC/CSIR/NET/GSET conducts examination, subject to availability of recognized
supervisors in the Bhakta Kavi Narsinh Mehta University. This provision is for the Ph.D.
programme only and no inferences drawn from this would be applicable for any other
academic endeavour. Therefore, it shall have no implication on any type of academic
recruitment etc.

5.5

Exemption from Ph.D. Entrance Test (PET) shall be given to a candidate who are
qualified for fellowship/scholarship in UGC-NET,UGC-CSIR, GATE, GSET and similar
National level tests whose examinations are conducted / approved by UGC at the time of
last date of registration for PET. They may be admitted based on an interview i.e. they
should have to face RAC for Personal Interview/Viva Voce. These exempted candidates
must apply online within prescribed time limit with due fee.

5.6

Candidates for admission to the Ph.D. programme shall have a Master's degree only in the
subject in which he/she has obtained Master's Degree by the corresponding statutory

BKNMU Ph.D. Ordinances, 2023

Page 7

<!-- page 10 -->

regulatory body, with at least 55% marks in aggregate (without grace marks) or its
equivalent grade in a point scale wherever grading system is followed OR equivalent
qualification from a foreign educational institution accredited by an assessment and
accreditation agency which is approved, recognized or authorized by an authority,
established or incorporated under a law in its home country or any other statutory
authority in that country to assess, accredit or assure quality and standards of the
educational institution.
5.7

A candidate in the Faculty of Arts or Commerce who has taken his/her Master's degree in
Economics or Statistics may be registered for Ph.D. degree, in any one of these faculties
subject with the approval from RAC and R & D.Cell.

5.8

A candidate who has obtained the degree of Master of Engineering or M.Tech. with
Computer Science, Information Technology, Electronics, Environment, Bioscience,
Biotechnology as one of the subjects of this University or of any other University,
recognized as equivalent thereto, may be allowed to registered for the Ph.D. degree in
Science Faculty in the subject/s of Computer Science/Electronics/Environment
Science/Climate Change Impacts Management/Biotechnology/Life Science etc. subject to
the approval from RAC and R & D.Cell.

5.9

Multi/Inter

disciplinary

research

in

Science

/

Medical

/Paramedical/Arts/Humanities/Social Sciences /Education/Law/linguistics etc. shall be
encouraged, subject to the approval from RAC and R & D Cell.
5.10

Candidates who propose to carry out research work in Multi/inter disciplinary areas shall
be permitted to have a Co-Guide on the recommendation of the RAC and R & D.Cell. The
Co-Guide could be from the same or a different department/college/centre of Bhakta Kavi
Narsinh

Mehta

University

or

from

any

other

recognized

University/institution/industry/Govt. approved agency in India or abroad.
5.11

The university shall maintain/display the list of all the Ph.D. registered scholars on its
website on a year-wise basis. The list shall include the name of the registered candidate,
topic of his/her research, name of his/her Guide/co-Guide and date of registration.

5.12

There shall be two types of Ph.D. (1) Full Time and (2) Part-Time.
1) Full Time Ph.D. Programme
The full-time students are expected to work full time for their Ph.D. The students who
are receiving assistantship/scholarship/fellowship from UGC/ICSSR/SHODH or any
other agency and/or from industry sponsored projects shall be full time students. In the
case of full-time students, the Guide shall be from the same institution where the
student is pursuing the research work.

BKNMU Ph.D. Ordinances, 2023

Page 8

<!-- page 11 -->

2) Part-time Ph.D. Programme
Part-Time student refers to employed persons who are admitted to the Ph.D. studies. A
“No objection certificate” is to be submitted by the candidate from the appropriate
authority where the person is employed along with the Ph.D.Programme registration
form. No fellowship or assistantship of any kind shall be awarded to such candidates.
The “No Objection Certificate’ should clearly state that:
I)

The candidate is permitted to pursue studies on a part-time basis.

II) His/her official duties permit him/her to devote sufficient time for research.
III) If required, he/she will be relieved from the duty to complete the course work
Ph.D. degrees which are pursued either full time or part time will be treated as degrees
awarded through Regular Mode provided these are in conformity with the existing
Statutes/Byelaws/Ordinances of Bhakta Kavi Narsinh Mehta University.
5.13

Students who have secured 50 % marks in aggregate in the Ph.D. Entrance Test (PET) are
eligible to be called for the viva voce/interview. A relaxation of 5 % marks will be
allowed

in

the

entrance

examination

for

the

candidates

belonging

to

SC/ST/OBC/differently-abled category, Economically Weaker Section (EWS), and other
categories of candidates as per the decision of the State Government from time to time.
5.14

University may decide the number of eligible students to be called for an interview based
on the number of Ph.D. seats available.

5.15

Selection of candidates will be based on the entrance test conducted by the university, a
weightage of 70 % for the entrance (PET) test and 30 % for the performance in the
interview/viva- voce shall be given.

5.16

The university will notify a prospectus well in advance on the its website specifying the
number of seats for admission, subject/discipline-wise distribution of available seats,
criteria for admission, the procedure for admission, and all other relevant information for
the candidates.

5.17

The university shall maintain a list of Ph.D. supervisors (specifying the name of the
supervisor, his or her designation, and the department/school/centre/subject), along with
the details of Ph.D. scholars (specifying the name of the registered Ph.D. scholar, the topic
of his/her research and the date of admission) admitted under them on the website of the
university and update this list every academic year.

5.18

The candidate shall not be allowed to register simultaneously for any other
degree/diploma programme after registering for Ph. D. If, at any point of time, it is found
to be otherwise, his/her admission shall be cancelled, and all the fees and deposits paid by
the candidate shall stand forfeited. The university shall take legal and/or disciplinary

BKNMU Ph.D. Ordinances, 2023

Page 9

<!-- page 12 -->

action or both, as it may deem fit, in such cases.
O.Ph.D..6:
6.1

ADMISSION OF INTERNATIONAL STUDENTS IN PH.D. PROGRAMME
Each supervisor can guide up to two international research scholars on a supernumerary
basis over and above the permitted number of Ph.D. scholars as specified in clause 10.2 of
this ordinance.

6.2

The Ph.D. Entrance Test (PET) and personal interview/Viva Voce of (before RAC)
international candidates shall be conducted online/offline by the university.

6.3

For International candidates (those who have not obtained Master's degree or equivalent
degree from Indian Universities), the minimum percentage of marks shall be 55%
(Without Grace Marks) or equivalent grade in the Master's Degree or equivalent
qualification is mandatory. Such candidates should produce equivalence certificate.

6.4

No International Scholar will be admitted to Ph. D. programme in Bhakta Kavi Narsinh
Mehta University unless he/she has a valid VISA endorsed in favour of this University.
An International Scholar registered for Ph.D. as a full-time scholar should maintain 75 %

6.5

presence to be eligible for Ph.D.Viva Voce. An International Scholar registered for Ph.D.
programme as a part-time scholar should follow the clause 5.13.(2) of this ordinance.

6.6
O.Ph.D..7
7.1

International Scholar includes Foreign Nationals and NRIs.
PROCEDURE FOR
PROGRAMME
Structure of the Test

CONDUCT

OF

ENTRANCE

TEST

FOR

PH.

D

All the candidates who are not exempted from the Entrance Test are required to appear in
person for the Entrance Test. The PET can be conducted online/offline. It is mandatory for
exempted students to fill the Ph.D. Entrance Test application form along with prescribed
fee. The name of the papers and contents of the test shall be as follows:
Paper 1: Research Methodology Paper
•

This paper will have 50 questions with multiple choices. It can be set one for
all or stream/discipline/subject wise. Examination time is 1:00 hour.

•

Syllabus of this paper will be based on Research Methodology/NET/GSET
syllabus.

Paper II: Subject Specific Paper
•

This paper will have 50 questions with multiple choices. Examination time is
1:00 hour

•

Syllabus of this paper shall be of foundation of the relevant subject as per
UGC-CSIR/NET/SLET/GSET/PG level syllabus.

•

A researcher who is applying for Inter/multi-disciplinary Ph.D. Research
Programme shall be allowed to select any one subject of his choice i.e. subject

BKNMU Ph.D. Ordinances, 2023

Page 10

<!-- page 13 -->

from his/her combination of inter/multidisciplinary research.
7.2

Total marks for the Entrance Test will be 100 for 100 MCQs, each of them carries one
mark.

7.3

There will be no negative marking in Entrance Test.

7.4

To qualify in the Entrance Test, the candidate has to secure minimum 50% marks in the
aggregate in paper-I & Paper-II.

7.5

The eligibility of the candidate who cleared the Entrance Test is for one academic year
only.

7.6

The medium of PET and thesis writing will be English for all subjects which come under
the faculty of Science, Commerce, and Law; English or Gujarati for all subjects which
come under the faculty of Education; English or Gujarati for all subjects which come
under the faculty of Arts, but it should be English for English subject, Hindi for Hindi
subject, Gujarati for Gujarati subject and Sanskrit or Gujarati for Sanskrit subject. Paper-1
should be in English or Gujarati.

7.7

UGC/CSIR(JRF) examinations, NET/SLET/GSET/GATE/Teacher Fellowship holders
shall be exempted from the PET. But they have to apply online with due fee.

7.8

The University shall decide the mode/procedures of the conduct of PET examination and
other relevant things.

7.9

Subject to the overall guidance of the Academic Council, the Research and Development
Cell shall advise the authorities on all matters connected with the promotion of advanced
studies and research in the University.

O.Ph.D.-8:
8.1

RESEARCH ADVISORY COMMITTEE (RAC)
The RAC shall be constituted for all the subjects as prescribed in the NET/GSET
examinations and it shall consist of the following members:
(a) The Head of the P. G. Department as the Chairman of RAC
OR
Chairman of Board of Studies of Concern subject as the Chairman of RAC.
(b) Dean of Concern Faculty
(c) Two External Subject Experts (Not below the rank of Associate Professor) from
other Universities/Institutes of Repute.
(d)

Nominee of the Vice Chancellor

The head of the department will decide and invite the subject experts from other
University to remain present in the RAC. Where there is no subject offered in the
university department, the concern subject BoS Chairman will submit five names of
expert to the Academic Section of the university well in advance. The Vice Chancellor

BKNMU Ph.D. Ordinances, 2023

Page 11

<!-- page 14 -->

will nominate two names out of them who will be informed to remain present in the
RAC.
Proviso:
1) This committee shall be constituted by the Head of a University P. G. Department.
2) In case of any P.G.Programmes which are not offered by the university
department/s of the University, the RAC shall be formed by the Vice Chancellor.
3) All members of the RAC should be research supervisors.
4) In case the Chairman of BoS/Dean is not a research supervisor, Vice Chancellor
will nominate the Chairperson of RAC who should be a research Supervisor.
5) External Subject Experts may be Asst.Professor in special cases only.
6) At least one third members from the committee should be present to meet the
quorum
8.2

Functions of RAC

8.2.1

Functions of RAC for Conduction of Admission Process:
1) The RAC shall review the research proposal, finalize the topic of research and
declare the result on the basis of following criteria subject to the suitability of the
research work at the institution / availability of supervisor in the proposed research
area. Each criterion shall be of 20 marks.
a) Nature /Scope / Purpose and Present day relevance of the proposed work
b) Ability of Candidate to carry out proposed research.
c) Literature Review/Methodology.
d) New/Additional Knowledge/Significance of Study/Integration of IKS
e) Overall Performance (Presentation /ability to defend etc.).
2) The evaluation of the Research Proposal/Viva Voce will be done by all the
committee members.
3) Allotment of the candidate for Ph.D. study shall be subject to the approval of RAC.
4) Only those Ph.D. Research Supervisors who wish to fill his/her vacant seats are to
be invited for RAC. In case of Inter/Multi-disciplinary research one expert of the
concerned field may be invited in the meeting.
5) The eligible candidates for RAC will submit the research proposal to the University
(prior to RAC) for the purpose to initiate the process to call and coordinate the
meeting of the RAC.
6) Before registration of the candidate, the title can be modified/corrected with the
approval of the concern guide, but the entire title cannot be changed.

BKNMU Ph.D. Ordinances, 2023

Page 12

<!-- page 15 -->

7) After registration, a candidate shall be allowed to modify/correct the title of the
research problem without prejudice to the object and contents of the research study
up to RAC of Semester-3. However, this application has to be processed with
justifications approved and forwarded by the concerned Supervisor/Principal
Supervisor with the approval of the members of the concerned RAC.
8) The RAC shall be empowered to take appropriate decisions regarding allocation of
co-supervisor.
9) The results of the selected candidates for Ph.D. programme shall be displayed on
the university website/portal.
10) The Chairman should submit the brief report and relevant documents to the
Academic Section of the University after completion of the RAC.
8.2.2

Functions of RAC for Coursework
a) The RAC shall evaluate this course work, maintain proper records of teaching and
evaluation and take a decision on the continuance or otherwise of the research
scholar.
b) If university is not offering the subject in its department, these data have to be
maintained by the academic/Ph.D./PG Section of the university.
c) The course work contents of the specific subject shall be decided by the Chairman
of the concerned subject RAC.
d) The syllabus should be approval by Academic Council. The Academic/Ph.D./PG
section of BKNMU should keep the records of the same.
e) The Head of the Department will issue the coursework completion certificate.
Where there is no subject offered by the university department, the coursework
completion certificate would be issued by the Academic/Ph.D.Section or as decided
by the Vice Chancellor.
f)

The Dean of the concerned faculty will make necessary arrangements for setting the
question papers for coursework wherever necessary, conduct exam and its related
follow up work i.e. assessment, results etc.

g) To keep and maintain records of the work done. In case, where the department is
not offering the subject, the records should be kept and maintained by the
Academic/Ph.D. Section of the university.
h) The Chairman should submit the brief report/documents to the Academic Section of
the University after completion of the coursework.

BKNMU Ph.D. Ordinances, 2023

Page 13

<!-- page 16 -->

8.2.3

Functions of RAC for Six Monthly Progress Review Meetings
a) It will be the responsibility of the Head of the Department to arrange RAC in time.
The RAC of other than subjects offered by the University Department, the
Academic/Ph.D. Section will arrange the RAC.
b) For Sixth Monthly Progress Review Committee Meeting, only those Research
Supervisors are to be invited who has been allotted seats.
c) In Case of Six Monthly Progress Review Meeting and Pre-Ph.D.Presentation, the
Research Supervisor of the Ph.D. student will act as the convener of the committee.
d) The chairman of the RAC shall be empowered to decide about the date and time with
prior permission of the Vice Chancellor and shall also be responsible to inform the
other members of the RAC. The Chairman of RAC will have to submit the
documents to the academic/Ph.D. section for the further action/process after the
conduct of RAC. Where there is no university department, the above process is to be
completed by the academic/Ph.D.Section.
e) The RAC has authority to change supervisor and wherever necessary to allot/change
co-supervisor on recommendation of the RAC members with the consent of Research
Supervisor.
f) Reviewing periodically the progress report of the research scholar.
g) Assisting in the progress of the research work of the research scholar.
h) Giving suggestions for improving the quality of research.
i) Guiding the research scholar to develop the study design and methodology of
research and identify the course(s) that he/she may have to do.
j) Suggestions/Corrective measures are to be forwarded to the Research Scholar by the
Chairman of the RAC. If there is no subject offered by the department, the
academic/Ph.D.

Section

of

the

university

should

forward

the

suggestions/recommendations to the concern Research Scholar.
k) In case the progress of the research scholar is unsatisfactory, the Research Advisory
Committee shall record the reasons for the same and suggest corrective measures. If
the research scholar fails to implement these corrective measures, the Research
Advisory Committee may recommend to the University with specific reasons for
cancellation of the registration of the research scholar.
l) The Chairman should submit the brief report/documents to the Academic Section of
the University.

BKNMU Ph.D. Ordinances, 2023

Page 14

<!-- page 17 -->

8.2.4

Functions of RAC for Pre-Ph.D. Presentation
a) In Case of Pre-Ph.D.Presentation, the Research Supervisor of the Ph.D. student
should act as the convener of the committee.
b) Inviting subject expert for the Pre-Ph.D.Presentation.
c) Conducting Pre-Ph.D. Presentation
d) The Chairman of concerned RAC will issue the certificate.
e) Should submit the brief report to the Academic Section of the University.

8.3

There will be an RAC of selected subjects as prescribed in UGC NET/GSET examination
and availability of supervisor of the said subject.

8.4

The expenses incurred for the RAC meetings (including TA/DA, boarding, lodging,
snacks, stationery etc.) will be borne by the University. The committee members will be
given T.A./D.A./Honorarium/Seating Allowance as per prevailing norms. Each external
expert/s and the Chairman shall be paid an honorarium of Rs. 2000/day and other
members will be given Rs.1000/day besides the travelling allowance/Mileage Allowance
or the actual traveling expenses incurred. One committee member travelled by car will be
entitled for travel allowance as per university rule.

8.5

The Research Scholar should pay the due term fee within fifteen days from the date of
RAC. If he/she fails to pay the due fee within fifteen days from the day of RAC, due fee is
to be paid plus late fee of Rs.500/- within ten days. If he/she fails to pay due fee plus late
fee within ten days, due fee plus late fee plus penalty fee of Rs.1000/- is to be paid.

O.Ph.D.-9:

PREPARATION OF MERIT LIST

9.1

The qualifying marks for the Ph.D. Entrance Test (PET) will be 50% .

9.2

The University shall bring out merit list of successful candidates of PET for each subject,
based on the performance in 70 % written test of two papers and 30 % of interview/Viva
Voce Presentation. Validity of the merit list shall be only for the concerned academic
year.

9.3

The merit list of exempted candidates for Ph.D. Programme will be prepared based on
their performance in the personal interview/viva voce. They have to obtain 50 % marks to
qualify for admission in Ph.D. programme. 30 % marks of presentation cum
interview/Viva Voce will be considered while preparing the final merit list. This 30 % will
be converted into 100 marks.
Provided that if the research proposal of the exempted candidate is not upto the mark, the
RAC can summarily reject the proposal. Such candidates will be treated as ‘Not Eligible’
for admission in Ph.D.Programme.

BKNMU Ph.D. Ordinances, 2023

Page 15

<!-- page 18 -->

9.4

Admissions shall be given based on the merit list and available seats. The admitted
candidates shall have to pay the prescribed fees within 10 days from the date of offer of
admission, or as notified by the university, failing which the seat shall be allotted to the
next eligible candidate on the merit list.

9.5

In case of Inter/Multidisciplinary research, Ph.D registration shall be done in main (coreMajor) subject of PG.

O. Ph.D.10: RECOGNITION AND ALLOCATION OF SUPERVISOR/CO-SUPERVISOR
10.1

Subject to the other provisions of this ordinance, a teacher, who is a Professor, Associate
Professor or Assistant Professor/Principal/Adhyapak Sahayak in this University
department/affiliated college/constituent college/PG centre/recognized institution of the
Bhakta Kavi Narsinh Mehta University and employed as a Permanent Teacher or a
Scientist shall be eligible to apply for recognition to supervise Ph.D. study/Research
scholar in Bhakta Kavi Narsinh Mehta University subject to the following eligibilities.
a) Must have Ph.D. or an equivalent degree in the concerned subject.
b) Permanent faculty members working as Professor/Associate Professor in Bhakta
Kavi Narsinh Mehta University with a Ph.D., and at least five research publications
in peer-reviewed or refereed journals and permanent faculty members working as
Assistant Professors/Adhyapak Sahayak in Bhakta Kavi Narsinh Mehta University
with a Ph.D., and at least three research publications in peer-reviewed or refereed
journals may be recognized as a Research Supervisor in the university department
or in its affiliated colleges/Post-graduate Colleges/institutes. Such recognized
research supervisors cannot supervise research scholars in other university, where
they can only act as co-supervisors.
For Ph.D. scholars working in Central government/ State government research
institutions whose degrees are given by Higher Educational Institutions, the
scientists

in

such

research

institutions

who

are

equivalent to Professor/Associate Professor/Assistant Professor/Adhyapak Sahayak
can be recognized as supervisors if they fulfill the above requirements.
Provided that in areas/disciplines where there is no, or only a limited number of
peer-reviewed or refereed journals, the university may relax the above condition for
recognition of a person as Research Supervisor with reasons recorded in writing.
c) Must have permanent recognition as a UG and PG Teacher of BKNM university. It
is not required for teachers who are teaching in PG department of this university.
d) The Professor/Asso.Professor/Asst.Professor of other university cannot be the
guide of this university. However, they can act as a co-guide.

BKNMU Ph.D. Ordinances, 2023

Page 16

<!-- page 19 -->

e) In Multi/inter disciplinary areas (subjects), a candidate who has qualification/s or

experience/expertise in special or related discipline/s can apply for recognition as
Guide in an additional/different/allied subject, Vice Chancellor may recognize a
candidate as Ph.D. guide.
f) If any recognized research supervisor of BKNMU wants guideship in other allied

subject/s, he/she should have published two research papers in that allied subject
He should have to go through the process of fresh guideship recognition.
g) No teacher shall be allowed to seek permanent recognition as Ph.D. Supervisor
under this ordinance unless he is an employee of the University department, college
constituted and run by the university and affiliated to this university or institution
recognized by this university.
h) Only a permanent teacher of this University/Institution/affiliated college Deemed to
be a University/College can act as a supervisor. The external supervisors are not
allowed. However, Co-Supervisor can be allowed in inter/Intra-disciplinary areas
from other departments of the same institute or from other university/institution
with the approval of the RAC. The Research Supervisor’s consent/proposal is must
in these cases.
i) In case of Ph.D. topics which are of inter-disciplinary in nature or wherever the

RAC concerned feels that the expertise in the proposed research area needs to be
supplemented, then the RAC may recommend co-supervisor from BKNMU or
outside or from another University/institute which is to be approved by R.& D.Cell.
The co-supervisor should have expertise in the proposed field as evidence by
his/her research publications. The co-supervisor may be instructed at the time of
registration or even after registration, subject to recommendation by RAC.
j) The Academic Section of the University will process the fresh applications for
recognition as Ph.D. Research Supervisor. The Vice Chancellor will recommend
one subject expert subject wise for evaluating such applications. The Subject
Expert will evaluate the applications keeping in mind the criteria laid down in these
ordinances.
k) Research papers submitted by a candidate for recognition as Ph.D. supervisor will
be evaluated by an external expert not below the rank of Professor/Associate
Professor or equivalent eminent academician nominated by the Vice Chancellor.
The report must be positive. In case of negative opinion, the Vice Chancellor may
send his/her application for re-evaluation to the second expert. If the second
expert’s report is positive, he/she will be given guideship. If the second expert

BKNMU Ph.D. Ordinances, 2023

Page 17

<!-- page 20 -->

report is negative, the candidate can reapply only in the next academic year. The
external expert will be paid Rs.1000/- per application for evaluation.
10.2

A Research supervisor/Co-supervisor who is a Professor, at any given point of time,
cannot guide more than Eight (8) Ph.D. scholars, an Associate Professor as Research
Supervisor can guide up to a maximum of six (6) Ph.D. scholars and an Assistant
Professor as Research Supervisor can guide up to a maximum of four (4) Ph.D. scholars.
The Scholar who is a Research Assistant/Research Associate/JRF/SRF/WoS/Project
Fellow/Project Assistant or having any other fellowship and working in Research Project
of Research Supervisor shall be in addition to the above mentioned numbers of respective
Ph.D. Guide i.e. they will be considered as supernumerary. In any case, supernumerary
seats should not be more than two which includes the international students as well.

10.3

In case of relocation of Ph.D. woman scholar due to marriage or otherwise, the research
data shall be allowed to be transferred to the University to which the scholar intends to
relocate provided all the other conditions in these regulations are followed in letter and
spirit and the research work does not pertain to the project secured by the parent
institution/supervisor from any funding agency. The scholar will however give due credit
to the parent guide and the institution for the part of research already done.

10.4

In case of death of a supervisor, the student shall be transferred to other supervisor of
BKNMU on recommendation of RAC and R & D.Cell. In case, there is not vacant seats
with any research supervisor, such candidates’ seats can be allotted in addition to the
maximum number of seats to the research supervisor on temporary basis, but as the seats
become vacant, such candidates immediately be relocated to the concern research
supervisor.

10.5

In case of retirement of a teacher, the teacher shall continue as a supervisor till the
enrolled student(s) are awarded the degree.

10.6

In case of relocation of a teacher to another University/institute, the teacher shall continue
as a supervisor of that University/college till his registered students are awarded the
degree.

10.7

The university shall, on the recommendation of the RAC, transfer the scholars registered
under a Ph. D. Guide to another Ph.D. Guide in the same subject discipline if the original
Ph.D. Guide is unable to provide guidance due to unavoidable circumstances.

10.8

A Ph. D. Guide shall produce or register at least one Research Scholar during the last five
years of his/her recognition as a Ph. D. Guide, failing which his/her recognition as a Ph.
D. Guide shall automatically be derecognised and he/she shall be required to seek rerecognition as a Ph. D.Guide through due process.

BKNMU Ph.D. Ordinances, 2023

Page 18

<!-- page 21 -->

10.9

Executive Council of the University, at any time on the recommendation of the Academic
Council/Research and Development Cell, shall be empowered to withdraw the Guideship
of a recognised teacher. The Academic Council can make such a recommendation on the
ground of: (a) moral turpitude, and / or (b) plagiarism, and / or (c)any act harming the
interest/quality concerns of the University.

10.10

If a person is engaged in government/public undertaking/research institute/semi
government institution/Industry/NGO or any other institution of similar nature and having
specialization in the respective field with 10 years of experience can be a co-guide at
BKNMU with prior permission of the RAC and R.& D.Cell.

10.11

If any recognized research supervisor of BKNMU wants guideship in other allied
subject/s, he/she should have published two research papers in that allied subject and
should have total five years of teaching experience. He should have to go through the
process of fresh guideship recognition. But the total research scholars should not exceed
from the prescribed limit.

10.12

Adjunct Faculty members shall not act as Research Supervisors and can only act as cosupervisors.

10.13

Faculty members with less than three years of service before superannuation shall not be
allowed to take new research scholars under their supervision. However, such faculty
members can continue to supervise Ph.D. scholars who are already registered until
superannuation and as a co-supervisor after superannuation, but not after attaining the age
of 70 years.

10.14

It will be considered vacant seat when research supervisor’s research scholar submit
his/her Ph.D. Thesis or he/she discontinued or is removed.

10.15

At any point, the total number of Ph.D. scholars under a faculty member, either as a
supervisor or a co-supervisor, shall not exceed the number prescribed in clause 10.2.

O. Ph.D.11: DURATION OF THE PROGRAMME
11.1

A full time Ph.D. programme shall be for a minimum duration of six semesters/three years,
including course work and a maximum of twelve semesters/six years. A part time Ph.D.
Programme shall be for a minimum duration of eight semesters/four years, including course work
and a maximum of Twelve semesters/Six years. All candidates of both type of Ph.D. will have to
pay fees until the synopsis is submitted as per the guideline given in these ordinances.

11.2

A maximum of an additional two (2) years can be given through a process of re-registration;
provided, however, that the total period for completion of a Ph.D. programme should not exceed
eight (8) years from the date of admission in the Ph.D. programme. The fee for re-registration will
be as it is prescribed for registration fee.
Provided further that, female Ph.D. scholars and Persons with Disabilities (having more

BKNMU Ph.D. Ordinances, 2023

Page 19

<!-- page 22 -->

than 40% disability) may be allowed an additional relaxation of two (2) years; however, the total
period for completion of a Ph.D. programme in such cases should not exceed ten (10) years from
the date of admission in the Ph.D. programme.

11.3

The duration of the programme shall be from the date of registration in the
Ph.D.programme.

11.4

The research scholar who is getting any financial assistance from any government/Semi
Government

departments/agencies/

fellowships/scholarships/stipend

of

institutions,

the

leave

rules

of

respective

department/agency/institution/

government/Semi Government departments will be applicable. Prior permission for leave
should be taken from the Supervisor and Head of the Institution/Department.
11.5

A female Ph.D. Scholars may be provided Maternity Leave/Child Care Leave up to 240
days in the entire duration of the Ph.D. programme. For availing the maternity leave, a
medical certificate with leave report should be submitted to the Academic/Ph.D. Section
of the university with approval of Research Supervisor prior to starting the maternity leave
and joining report at the time of completion of the maternity leave. This leave should be
excluded from the period of active Ph.D. research.

11.6

For student exchanges, provided that they contribute significantly to the completion of the
thesis, leave of absence may be granted from the second year onwards on the following
basis:
a) research expeditions (less than one month): authorised by the supervisor and head
of the department;
b) research missions (more than one month): proposed by the department and
approved

by

the

Research

Advisory

Committee

for

working

in

National/International Research Laboratories or Centres of Excellence; and
exchange programmes: proposed by the department and approved by the Research
Advisory Committee for working in the Institutions in India/abroad.
11.7

a) Academic Leave of maximum 30 days in a calendar year is permissible for field
trips

such

as

data

collection,

survey

work,

attend

conferences/seminars/workshops/trainings/ short-term courses etc.
b) Academic leave exceeding 30 days should be approved by the Head of the
Department/Principal on recommendation of the Supervisor.
11.8

A candidate has to submit the thesis within one year after submitting the synopsis, failing
which he/she has to repay the synopsis fee and all skipped semester fees along with late
fee and penalty fee. In such cases, scholar should write an application stating that he/she
will submit the thesis within one year which should be countersigned by his/her guide.

BKNMU Ph.D. Ordinances, 2023

Page 20

<!-- page 23 -->

Maximum tenure for completion of the Ph.D. programme will be binding to scholar in
such cases.
11.9

The Ph.D. Scholar who got appointed in any institution after registration can apply for the
change from full time to part time with evidences such as appointment order, No
Objection Certificate and recommendation letter of the Research Supervisor which are to
be approved by the concerned RAC.

O.Ph.D. 12

12.1

PROCEDURE FOR REGISTRATION
As soon as the candidates are admitted to the Ph.D. programme by paying the registration fee,
they shall be provisionally registered for the programme. After completion of the coursework
successfully, their Ph.D. registration shall be considered as confirmed. This process shall be
completed within the First term/semester of provisional registration.

12.2

A candidate admitted to the Ph.D. programme as per the procedure described earlier shall
be registered as a Ph.D. scholar by the University.

12.3

The candidate shall be required to finalize and submit a brief research proposal of about
1000 words containing the title, significance and scope of the topic, rationale, objectives,
justification, national-international status, theory and research methodology/techniques
involved, references, bibliography, etc. in coordination with guide/co-guide at the time of
final registration.

12.4

Once the topic and the guide are finalized, the scholar will be required to fill up the
registration form along with prescribed registration and First Semester fee.

12.5

After the title clearance of the research proposal, the University shall notify the scholar
about approval of the topic of the thesis as registration certificate.

12.6

A registered Ph.D. scholar shall not be allowed to pursue any other course/programme
from any University simultaneously. If any such violation is noticed, the registration of
the scholar shall be cancelled automatically.

12.7

The date of registration of Ph.D. Scholar shall generally be done in the months of January
and if required in July of each year.

O.Ph.D. 13

13.1

ISSUING A PROVISIONAL CERTIFICATE.
Prior to the actual award of the Ph.D. Degree, Bhakta Kavi Narsinh Mehta University
may issue a provisional certificate to the effect that the Ph.D. is being awarded in
accordance with the provisions of these Regulations.

13.2

After completion of successful Viva Voce, the university will issue notification
containing the details of Ph.D.Scholar such as name, title, date of registration, date of
viva voce, name of guide etc.

BKNMU Ph.D. Ordinances, 2023

Page 21

<!-- page 24 -->

O. PH. D.14

FEE STRUCTURE

14.1

(1) Admission Form & Processing fees: Rs.1000/-.
(2) Registration fee to be paid (once):
Indian Scholars: Rs.1500/- (Re-registration: Rs.4000/-).
Foreign* Scholars:Rs.6000/-(Re-registration: Rs.12000/-)
(3) Coursework Fee:
Indian Scholars: Rs.4000/Foreign* Scholars: Rs.16000/(4) Other fees:

Indian
Sr.No

Fee Details

Scholars
(INR)

1

Tuition Fee

2

Laboratory Fee per term
(For Science Faculty)

3

Laboratory Deposit (Once at the time
of Admission)

4

Library Fee

5

Library Deposit (Once at the time of
Admission)

6

Caution Money (Once at the time of
Admission)

7

Identity Card Fee (Once at the time of
admission)

8

Six Monthly Progress Report Fee

Foreign* Scholars
(INR)

4,000

16,000

4000

16,000

1000

4000

1000

4000

500

2000

200

800

50

200

1000

4000

Note: Girl students have been exempted from tuition fees under the provision of (1)
Resolution MIS/1084/29657/85 Date: 01/05/85 (2) Resolution MIS/1088/
7844/88 Date: 01/11/88 issued by Education Department, Government of
Gujarat.
Synopsis Fee (To be paid at the time of submission):
•

Indian Scholars:

Rs. 2,000/- and

•

Foreign* Scholars

Rs. 6,000/-.

(*Foreign means students who is holding foreign passport and has completed qualifying
degree from the country other than India.)

BKNMU Ph.D. Ordinances, 2023

Page 22

<!-- page 25 -->

Ph.D. Examination Fee (to be paid at the time of submission of thesis)
•

Indian Scholars:

Rs. 6,000/- and

•

Foreign* Scholars

Rs. 18,000/-.

(*Foreign means students who is holding foreign passport and has completed qualifying
degree from the country other than India)
14.2

The candidate to be admitted to the Ph.D. programme shall have to pay the prescribed
fees as stated above or as modified by the university from time to time. The fees once
paid shall not be adjusted or refunded under any circumstances even if the candidate
cancels the admission. Any revision of fee shall be payable by the Ph.D. scholar during
the entire period of Ph.D. degree, but effective from the date of notification of the
ordinances. All Ph.D. scholars shall have to pay the prescribed fee for two terms every
year, till the date of submission of the Ph.D. synopsis.
Provided, the Research Scholars should have to clear at least six Semester for Full Time
candidates and Eight Semesters for Part Time Scholars.

14.3

A research scholar admitted to any of the Ph.D. Programmes in the University shall pay
fee as decided by the University from time to time. Failure to pay fee for three
consecutive terms may lead to cancellation of admission.

14.4

A registered Research Scholar shall submit his/her thesis within stipulated time, failing
which he/she has to take extension from the Vice-Chancellor and he/she shall be required
to pay fees up to the time he/she submits his/her thesis along with late fee and penalty fee.

14.5

University shall not make any correspondence pertaining to the payment of semester fees
to any Ph.D. candidate nor shall the University remind the same. It will be the
responsibility of the candidate to pay the fee in time. The odd semester fee is to be paid in
the month of January and even semester fee is to be paid in the month of July every year
within fifteen days from the date of RAC.

Ph.D.15:
15.1

COURSEWORK
All candidates admitted to the Ph.D. programmes shall be required to undertake the
coursework within one academic year designed and conducted by the concerned
department/UGC HRDC/RAC.

15.2

All Ph.D. scholars, irrespective of discipline, shall be required to train in teaching
/education/pedagogy/writing related to their chosen Ph.D. subject during their doctoral
period. Ph.D. scholars may also be assigned 4-6 hours per week of teaching/research
assistantship for conducting tutorial or laboratory work and evaluations.

15.3

The course work shall carry 12 credits (one credit=15 hours for offline mode and 10 hours
for online mode). The concerned RAC/Department shall decide the details of the course

BKNMU Ph.D. Ordinances, 2023

Page 23

<!-- page 26 -->

work, teaching schedule and evaluation within the broad framework given below:
I)

08 credits (120 hours for offline mode and 80 hours for online mode) for "Research
Skills" which includes research methodology, quantitative methods, computer
application, tools and techniques for research and experimentation, instrumentation,
communications skills, review of research and report writing. It will also include the
2 credits of “Research and Publication Ethics (RPE)” course notified by UGC as
compulsory for all the Ph.D. Scholars which is published in the Gazette of India on
31st July, 2018. Eight credits will be evaluated (online/offline/blended mode) out of
60 marks. The Research Advisory Committee can also recommend UGC
recognized online courses as part of the credit requirements for the Ph.D.
programme.

II)

04 credits (60 hours) for subject specific course work. 60 hours shall be devoted to
review of the related literature, review of published research in the subject,
laboratory work, field work, library work, seminar/conference, teaching and study of
different contemporary and development issues in the subject/topic. Four credits will
be evaluated (online/offline) out of 40 marks by the concerned research supervisor.
Bifurcation of marks/hours can be done by the University/RAC.

15.4

A Course Work Completion Certificate duly signed by the Head of the Department or
Competent authority as decided by the university would be essential before the
submission of the synopsis. The synopsis of the scholars would be accepted only after
such necessary certifications.

15.5

The detailed norms for evaluation of the course work shall be decided by the department.
At the end of the course work, all the scholars shall have to appear for examinations in
the prescribed papers. The examination may be conducted offline/online/blended or any
other mode as decided by the university.

15.6

A Ph.D. scholar must obtain a minimum of 55% marks or its equivalent grade in the UGC
10-point scale in the course work to be eligible to continue in the programme and submit
his or her thesis. Those who failed to get the minimum passing marks shall have to
reappear for such examination which will be decided as alternative arrangement made by
the university.

15.7

A research scholar shall be required to undergo a course work preferably in the first
semester and his failure in completion of his course work in the said semester will make
him liable to complete the course work in the succeeding academic semester only.
His/Her provisional registration will be final only after successful completion of the
coursework and the university will issue final registration certificate to the successful

BKNMU Ph.D. Ordinances, 2023

Page 24

<!-- page 27 -->

candidates. His/her term will be counted from the provisional registration, if he/she
succeeds to complete the coursework.
15.8

Attendance of the Ph. D. Scholar in coursework shall mandatorily be 90 % if it is
conducted offline.

15.9

The Ph.D. scholars migrated abroad may be permitted to earn due credits from their
respective country with prior permission of Chairman, RAC/Academic/Ph.D. Section.
The candidate has to submit the course work completion certificate to the
Academic/Ph.D. Section of the University.

15.10

The

Research

scholar

shall

attend

their

respective

department/school

laboratory/institute/college/library according to the pre-arranged time-table and
programmes provided by the concern scholar’s guide and it should be approved by the
Head/coordinator/director/principal. The records of their attendance shall be maintained
by the concerned Guide/s.
15.11

The University/HRDC/head of the Department shall notify the results of the course work
by a notification at the time of declaration of results of course work. A certificate of the
course work completion will be issued by the university/School/HRDC stating the
marks/percentage.

15.12

The teaching in the coursework shall be treated as part of the workload of the teacher.
Provided that if the teaching in course work is conducted on holidays/pre/post hours of the
time table, he/she may be paid due remuneration as per rules of the university.
If the experts are invited from outside university department, actual TA, DA and
honorarium should be given to them as per university rules. The hospitality of these
experts should also be provided by the university.

15.13

The RAC shall prepare a timetable for all papers and it shall be carried out in consultation
with the Chairman of RAC. The RAC chairman shall keep the records of the timetable,
attendance and examinations. The Chairman of respective RAC will submit the result of
coursework to the Academic/Ph.D. Section of the University.

O.Ph. D. 16
16.1

EVALUATION AND ASSESSMENT
A fulltime Ph. D. candidate shall be allowed to submit his/her synopsis after completion
of five semester/term successfully including coursework and a part time candidate shall
be allowed to submit synopsis after completion of seven semesters/term successfully
including course work.

16.2

If the research scholars publish the research paper related to his topic of Ph.D. research,
he/she should have to include the name of the Research Supervisor along with Research
Scholar’s name & the name of the concerned department, Bhakta Kavi Narsinh Mehta

BKNMU Ph.D. Ordinances, 2023

Page 25

<!-- page 28 -->

University in all of their publications.
16.3

All the research scholars will have to make a presentation of progress report at the end of
each semester in RAC. The Chairperson shall submit a copy of the report and PrePh.D.Presentation Certificate to the Academic/Ph.D. Section of the university. The
original copy of the Pre-Ph.D.Presentation should be given to the concern Ph.D.Scholar
for inclusion in the thesis.

16.4

A Ph.D. research scholar shall submit his synopsis to the Academic/Ph.D. Section duly
signed by the Research Supervisor and Research Scholar along with prescribed synopsis
form, fee and sealed prescribed referee panel form. This synopsis and referee panel
should duly be approved by the concerned subject Board of Study.

16.5

If the language of thesis is Gujarati, one copy of synopsis should mandatorily be in
English/Hindi. The referee panel list along with synopsis should be placed before the BoS
for approval and for further process. If the BoS is not going to meet in a short period of
time, the Chairman of concern Board of Study with consultation of the other members of
the concerned subject Board of Study can approve the synopsis and the referee panel list
which should be ratified in the next BoS.

16.6

The Guide shall suggest to the Board of Studies a panel of six referees. However, no
referee shall be from Bhakta Kavi Narsinh Mehta University PG department/affiliated
colleges/Institute. The referees should be Ph.D. and recognized Ph.D. supervisor/guide of
the concerned University/college/institution. The referees should not be below the rank of
an Associate Professor. He should be an academician with good record of scholarly
publications in the field. The Academic/Ph.D. Section/Chairman will place these six
names before the Vice Chancellor for approval. The Vice Chancellor will select two
external referees from the panel submitted to him for evaluation of the thesis. The Vice
Chancellor shall appoint the external referee for viva voce examination after receipt of
positive reports from the referees. In case of refusal by any external referee, the Vice
Chancellor shall appoint another referee from the panel list.

16.7

Out of the six external referees, three should be from Gujarat State (except from
BKNMU), and remaining three should be International/National level. For Gujarati
subject, these six referees may from Gujarat State. All referees should be from the panel
approved by the concerned subject Board of Study.

16.8

After completion of the research work, but prior to the submission of the thesis, the
scholar shall make a Pre-Ph.D. Presentation (Online/offline/blended mode) in the
University/Department before RAC of concerned subject which shall also be open to all
faculty members and other research scholars. The feedback and comments obtained from

BKNMU Ph.D. Ordinances, 2023

Page 26

<!-- page 29 -->

them may be suitably incorporated into the final thesis. The certificate of Pre Ph.D.
Presentation should be included in the thesis. Pre-Ph.D.Presentation can be arranged inbetween the RACs only in special cases with prior permission of the Vice Chancellor
with due justification.
16.9

The thesis can be sent for evaluation in soft copy as well. The referees can submit their
evaluation reports either in hard or in soft copy (from his/her email only) along with bills.

16.10

Two External Referees (External Examiners) with the supervisor and co-supervisor as
internal examiner will evaluate the thesis submitted by a research scholar. The internal
examiner/s, in case of co-supervisor as well, shall submit an evaluation report jointly. The
thesis can be accepted for the award of Ph.D. Degree only if the scholar secures 55 % or
more points in part – I followed by the detailed Evaluation Report in part – II.
Explanation 1: All the external referees/examiners who have evaluated the thesis must
have recommended unanimously for the award of Ph. D. Degree to ensure eligibility of
the candidate for viva-voce examination. One of the external examiners should be called
for the viva-voce.
Explanation 2: In case where one external referee/examiner recommends and the other
rejects, then the thesis will be sent to the third external referee/examiner. In case where
one external examiner recommends and other advises for revision then, the candidate will
have to revise as per the suggestions. If the third external examiner rejects, then the Ph.D.
enrollment shall get cancelled.
Explanation 3: No candidate shall be eligible for viva-voce examination required for the
purpose of Ph.D. degree unless all the external examiners have recommended to conduct
viva-voce examination to award the Ph.D. degree or the candidate has revised,
incorporated or rewritten the Ph.D. thesis as desired by the concerned examiner who has
evaluated the thesis and did said correction, revision, incorporation and/or rewritten the
thesis. In such a situation, the thesis must be re-examined by the same examiner who
recommended the said correction, revision or rewriting. Failure or negative result in this
regard will amount to the cancellation of Ph.D. enrolment and the candidate shall be
required to undergo the entire proceedings required for enrolment as a fresh candidate if
he/she desires to conduct the Ph.D. research.
Explanation 4: The rejection of the thesis of the candidate by all external examiners will
lead to the cancellation of enrolment.

16.11

The Supervisor/ Co-Supervisor of the concerned research scholar shall conduct
'open/public viva-voce' after receiving satisfactory evaluation reports of all the Examiners.
The Ph. D. viva-voce examination shall be conducted by the Supervisor/Co-Supervisor

BKNMU Ph.D. Ordinances, 2023

Page 27

<!-- page 30 -->

with one external examiner after getting permission from the university.
It is preferable to have both supervisor and co-supervisor for the conduct of viva-voce of
the concerned scholar. But principal supervisor can also conduct viva-voce with an
external examiner in absence/ non availability of co-supervisor. Online/blended mode
Viva Voce can be conducted.
The Supervisor should invite Chairman of the concerned subject Board of Study for
open/public viva voce, but it is not mandatory for chairman to remain present in the Viva
Voce examination. TA./DA should be given to Supervisor, Co-supervisor, external
Examiner and Chairman of the concerned subject Board of Study.
16.12

In case the online or offline Open Public Viva-voce (Open defence) Examination is not
satisfactory, the examiners may unanimously recommend with reasons that a fresh online
or offline Open Public Viva-voce (Open defence) Examination of the Ph.D. Thesis be
organized within a period of not less than one month. If the online or offline Open Public
Viva-voce (Open defence) examination is still not satisfactory, the panel for Viva- voce
Examination would record the reasons for the same and may recommend the
resubmission of the Ph.D. Thesis with suggested changes or recommend the rejection of
the Ph.D. Thesis, as the case may be. In this case, the Ph.D.Scholar should pay fee for
submission of Ph.D.Thesis again.

16.13

All the examiners (external and internal) shall be paid an honorarium of Rs. 2000/- each
for examining the thesis. The internal and external examiners who shall conduct the vivavoce shall be given an honorarium of Rs. 1500/- each. In case of principal supervisor and
co-supervisor, both shall be separately paid an amount of Rs. 2000/- for thesis evaluation
and Rs. 1500/- for viva-voce. The external examiner, research supervisor, co-supervisor
and Chairman of Board of Study shall be given Car/Air/Train travel allowance or actual
traveling expenses incurred. The DA will be paid as per the prevailing rules. Single
person journey by car is permitted for Ph.D.Viva Voce. The hospitality expenses will be
taken care of by the university. Boarding, Lodging and incidental expenses should be
taken care of by the university.

16.14

The research supervisor shall have personal responsibility to notify the date, time and
place of open/public viva-voce and extending invitations to the members of different
departments, colleges, research scholars and interested people. The viva-voce must be
conducted in the respective University department or a place determined by the
University at the university campus, preferably on working days.

16.15

Before submitting the thesis, a scholar has to produce Anti-Plagiarism clearance
Certificate for the content of the thesis. It will be the duty of the Research Supervisor to

BKNMU Ph.D. Ordinances, 2023

Page 28

<!-- page 31 -->

get his Research Scholar’s thesis checked by the university appointed Plagiarism
Checking Incharge. The certificate issued by the university should bear signatures of
Plagiarism Checking Incharge. Bhakta Kavi Narsinh Mehta University has accepted ‘The
University Grants Commission (Promotion of Academic Integrity and Prevention of
Plagiarism in Higher Educational Institutions) Regulations, 2018’ at par.
16.16

The report of Ph. D. viva-voce shall be prepared in a format prescribed by the university
and signed by the internal and examiner(s). It shall be submitted to the Academic/Ph.D.
Section of the University by the research supervisor for further process.

16.17

No candidate shall be awarded Ph.D. Degree unless the examiners conducting viva-voce
recommend the award of the Ph. D. Degree.

16.18

In normal circumstances, the entire process of evaluation of Ph.D. thesis shall be
completed within a period of six months from the date of submission of the thesis.

16.19

A Ph.D. Scholar shall include in the thesis a certificate from the Research Supervisor
attesting to the originality of the thesis and that the thesis has not been submitted for the
award of any other degree/diploma to any other Higher Educational Institution.

O.Ph. D. 17
17.1

AWARD OF PH.D. DEGREES
A candidate becomes eligible for the award of the Ph.D. degree after fulfilling all
the academic requirements prescribed by the University.

17.2

The Ph.D. degree shall be awarded in the discipline of the Faculty and subject in which
the scholar is registered for the Ph.D. programme. The title of the Ph.D. thesis and
subject/faculty shall be mentioned in the Notification.

17.3

If the thesis is recommended for award of the Ph. D. degree after the open viva voce, the
Registrar, with the approval of the Vice Chancellor, shall declare the result. A
certificate/notification with signature of the Registrar and seal of the university, to this
effect shall be issued by the Registrar to the successful research scholar.

17.4

Prior to the actual award of the Ph.D. degree, Bhakta Kavi Narsinh Mehta University shall
issue a notification to the effect that the Ph.D. is being awarded in accordance with the
provisions of University Grants Commission (Minimum Standards and Procedure for
Award of Ph.D. Degree) Regulations, 2022.

O. Ph.D. 18 DEPOSITORY WITH INFLIBNET
18.1

Following the successful completion of the evaluation process and before the
announcement of the award of the Ph.D. degree(s), the academic section of the University
shall submit an electronic copy of the Ph. D. thesis to the INFLIBNET, for hosting the
same on Shodhganga, so as to make it accessible to all Institutions/Colleges/Institutions.

BKNMU Ph.D. Ordinances, 2023

Page 29

<!-- page 32 -->

O. Ph.D. 19 CANCELLATION OF PH.D. REGISTRATION
19.1

The registration of a student is liable to be cancelled for any of the following reasons:
1) Consistent lack of progress in research.
2) Not implementing the corrective measures/suggestions/recommendations given by
the members during RAC meeting.
3) Violation of discipline and rules of the Department/College/Institution.
4) Non-submission of the thesis within the stipulated time period.
5) Non-conformity with the regulations of the programme.
6) Giving false information at the time of application/admission or in-between the
entire duration of Ph.D. Work.
7) Failing to pay prescribed fee consecutively for three terms.
8) Failing to submit Progress Report consecutively for three terms.
9) Misconduct/Misbehavior of the Research Scholar.

O. PH.D. 20

20.1

RESPONSIBILITIES OF GUIDES

The Ph.D. guide carries all the major responsibility of guiding/supervising the academic
planning/progress/execution of the plan of research throughout the period of study. He/she
counsels the scholar in academic matters, and provides guidance on the nature of course
work and research, the standards expected, the adequacy of progress, and the quality of
work. The moral/ethical values are to be followed by the Research Supervisor.

20.2

Faculty members with less than three years of service before superannuation shall not be
allowed to take new research scholars under their supervision. However, such faculty
members can continue to supervise Ph.D. scholars who are already registered until
superannuation and as a co-supervisor after superannuation, but not after attaining the age
of 70 years.

20.3

To ensure the successful and timely completion of the programme including the course
work, it is essential that Ph.D. guides and their scholars maintain regular contacts. The
guides must give their scholars advance notice, if they plan to be absent from the
University/college for an extended period of time, i.e. three months or more, and make
suitable arrangements for the continued guidance to the scholar during his/her absence.

20.4

The guides should keep all relevant documents of his/her Ph.D. Scholars.

20.5

He/She should remain present in the RAC meeting. He/She has to put Leave of Absence
Report if he/she is unable to remain present. If he/she remains absent for three RAC
consecutively, Vice Chancellor may withdraw his/her Ph.D. guideship with the
recommendation of Academic Council/Executive Council.

BKNMU Ph.D. Ordinances, 2023

Page 30

<!-- page 33 -->

20.6

He/She should have to declare the number of seats vacant, available and number of seats
he/she wants to fill in the current academic year.

20.7

It will be the responsibility of the Research Supervisor to ensure that the students prepare
a Progress Report as per the proforma given by the University which is to be signed by the
concerned guide. They should also inform the student/s to remain present in the RAC
meeting on given date, time and place.

O. PH.D. 21

GUIDELINES FOR PREPARATION AND SUBMISSION OF PH.D. THESIS

The Thesis is a treatise that represents the fulfilment of the scholarly aspiration of the
student. A good thesis should be clear and unambiguous and have a logical structure that
should assist the reader’s understanding of the argument being presented and not obscure
it. In order to achieve this objective, the layout and physical appearance of the thesis
should conform to a set pattern.
The purpose of this appendix is to outline the guidelines that a Ph.D. thesis submitted to
the BKNMU should adhere to. This provides an overview of the format for the
preparation of the Ph.D. dissertation and guidelines for the submission of the thesis.
❖ GENERAL INSTRUCTIONS
On completion of the research work, the Ph.D. thesis should be prepared according to the
format provided below.
•

The students are advised to strictly adhere to the format.

•

Three spiral with PDF and after the report of the external examiners, three hardbound
copies of the Thesis have to be submitted.

•

Softcopy of the thesis in Pen Drive (at least 62 GB) in PDF format will also have to
be submitted with the Thesis. Save thesis using a file name in the pattern “Author"
where author is the surname and name of the research scholar.

•

In case of co-supervisor the candidate should use the words Principal Supervisor and
Co-Supervisor on the front cover and other places in the thesis.

•

Text should be justified in every respect.

•

No ornamental bordering of the sides is permitted.

•

No dedication page in the thesis is permitted.

•

The thesis should be typewritten on A4 size paper in Times New Roman font with 12

❖ Fonts

मंगल

size). As far as possible, use the same font for the entire thesis but, if necessary,
different fonts may be used within Tables, Figures, and Appendices. The Thesis has
to be printed on both sides of the paper. Double-spacing should be used in the
Abstract and text of the Thesis. Single spacing should be used in long Tables, block
BKNMU Ph.D. Ordinances, 2023

Page 31

<!-- page 34 -->

quotations separated from the text, footnotes, and bibliographical entries. Paragraphs
should be indented, or an empty line left between paragraphs.
•

Larger size font may be used for the title of the Thesis and for Chapter headings, as
long as it is not larger than 18 point. Boldface type may also be used on the title page
and for headings, as well as in the text for special symbols or for emphasis. Reduced
type may be used within Tables, Figures, and Appendices, but it should be at least 9
point in size (partly because of microfilming requirements) and must be completely
legible.
• If the thesis is in Gujarati language, use shruti fonts with 12 size.
• If the thesis is in Hindi language, use Mangal fonts with 14 size.

❖ Chapter and Page Layout
• Begin each Chapter on a new page. Do the same with each element of the front
matter (list of Tables, Acknowledgments, etc.), the Reference section, and each
Appendix. Avoid typing a heading near the bottom of a page unless there is room
for at least two lines of text following the heading. The Chapters should begin on a
new page, but sections and subsections should not begin on a new page. A
"display" page (a page that shows only the Chapter title) can be placed at the
beginning of Chapters or Appendices.
• Pages should be numbered at the bottom in the centre, using Arabic numerals (1, 2,
3) beginning with 1 on the first page of the Introduction and continuing
consecutively to the end of the manuscript including References. The preliminary
pages are numbered in lower-case Roman numerals, beginning with the
declaration page.
❖ Margins
•

A margin of at least 1.5 cm must be left at the left side of each page and a margin
of 1.0 cm on the top, bottom and right side of each page.

❖ Captions and numbering (Tables and Figures)
•

Each Table should carry a number and a title clearly describing the data presented.
Similarly each Figure / Illustration should carry a number and caption that clearly
describes the nature of data presented. The caption should be at the bottom of the
Figure. Number them consecutively throughout, in the order in which they are
placed in the text.

•

The Figures, Graphs, Tables should be embedded in the text of the thesis,
immediately after the first mention of it in the text, on the same page if there is
room, or on the following page.

BKNMU Ph.D. Ordinances, 2023

Page 32

<!-- page 35 -->

•

Captions and titles of Figures and Tables should appear on the same page as the
material itself. Tables should be numbered consecutively with Arabic numerals
throughout the thesis. Figures and Illustrations should also be numbered
consecutively in the order of presentation. All Tables and Figures must be referred
to in the text by numbers and not by a phrase such as "the following table".

•

Tables or Figures of peripheral importance to the text may be placed in an
Appendix.

❖ Appropriate use of headings and subheadings
•

Headings should be distinguished from the surrounding text by a larger font size bold, italics, or a combination of these. All headings of the same level should use
the same style, and headings at lower levels should be less prominent than those at
higher levels.

•

All headings should be left aligned, except chapter headings, which may be
centred. The headings and subheadings can be numbered, if necessary.

❖ COLOUR OF THE THESIS
The colour of the thesis is specified below as per the faculty. The colour of the thesis
should be:
•

Maroon colour for Arts Faculty

•

Navy Blue colour for Commerce & Management Faculty

•

Black Colour for Science Faculty

•

Brown Colour for Education Faculty.

•

Silver Colour for Law Faculty

❖ FORMAT OF THESIS
The manuscript is to be arranged in the following sequence:
•

Cover Page

•

Title Page

•

Acknowledgements

•

Certificate by Research Guide

•

Declarations by Student

•

Anti-plagiarism certificate

•

Certificate for Pre-Ph.D. Presentation

•

Abstract of the thesis

•

Contents

•

List of Figures, Tables or Illustrations, if any

BKNMU Ph.D. Ordinances, 2023

Page 33

<!-- page 36 -->

•

List of Abbreviations, if any

•

Chapters i.e. Chapter-2: Review of Literature

•

Bibliography/References

•

Appendices

BKNMU Ph.D. Ordinances, 2023

Page 34

<!-- page 37 -->

Suggested Layout for the front cover page of Ph.D. Thesis

TITLE
(ALL CAPITALS)
A THESIS SUBMITTED
TO
BHAKTA KAVI NARSINH MEHTA UNIVERSITY
JUNAGADH

FOR THE AWARD OF THE DEGREE OF

DOCTOR OF PHILOSOPHY
IN
(NAME OF THE SUBJECT)
Submitted by:

Under the Supervision of:

Year of submission
Registration No.

Note: In case of co-supervisor the candidate should use the words Principal Supervisor and
Co-Supervisor on the front cover and other places in the thesis.

BKNMU Ph.D. Ordinances, 2023

Page 35

<!-- page 38 -->

LETTER FORMAT FOR PLAGIARISM CHECK
Date:
To
The Plagiarism Checking Incharge
Bhakta Kavi Narsinh Mehta University
Junagadh
Sub: Request to check plagiarism of my Research Scholar’s Ph.D.Thesis

Dear Sir,
The research work of my following Research Scholar is completed. We jointly
certify that the work is original and vouching that there is no plagiarism as per the rules
of Bhakta Kavi Narsinh Mehta University, Junagadh and notification of UGC dated 23rd
July, 2018 UNIVERSITY GRANTS COMMISSION (PROMOTION OF ACADEMIC
INTEGRITY AND PREVENTION OF PLAGIARISM IN HIGHER EDUCATIONAL
INSTITUTIONS) REGULATIONS, 2018.
As per the rule of Bhakta Kavi Narsinh Mehta University, you are requested to
check the plagiarism of the thesis of my research scholar and issue the certificate of
plagiarism check and oblige. The details are given below:
SN

Details

1

Name of the Research Scholar

2

Faculty and Subject

3

Title of the Thesis

4

Registration Number

5

Name of the Research Guide

6

Name of the Co-Guide, if any.

Signature of the Research Supervisor

BKNMU Ph.D. Ordinances, 2023

Inputs

Signature of the Research Scholar

Page 36

<!-- page 39 -->

DECLARATION BY RESEARCH SCHOLAR
I hereby declare that the research work embodied in this thesis entitled
___________________________________________________________________________
is prepared by me after studying various references related to the thesis. The analysis and
critical interpretation found in this thesis are entirely original. Hence, I state that I am
responsible for the critical opinions and the other details found in this thesis.
I declare that the work done and presented in this thesis is original and whenever
references have been taken from the work of others, they have been clearly indicted as such
and the source of the information is included in the bibliography.
I further declare that this research work is my original work and has not been
submitted to any any other university/institution for any degree/diploma, associateship,
fellowship. I also confirm that there is no plagiarism as per the rules of Bhakta Kavi Narsinh
Mehta University Junagadh and notification of UGC dated 23rd July, 2018 UNIVERSITY
GRANTS

COMMISSION

(PROMOTION

OF

ACADEMIC

INTEGRITY

AND

PREVENTION OF PLAGIARISM IN HIGHER EDUCATIONAL INSTITUTIONS)
REGULATIONS, 2018

Signature of Research Scholar

Place:
Date:

BKNMU Ph.D. Ordinances, 2023

Page 37

<!-- page 40 -->

DECLARATION BY RESEARCH SCHOLAR
(સંશોધક/વિદ્યાર્થીન ું વિિેદિ)
હ ં આર્થી વિિેદિ કરં છં કે _________________________________શીર્ષક
ધરાિતા આ ર્થીસીસમાં સમાયેલ ં સંશોધિ કાયષ સંબવં ધત વિવિધ સંદર્ભોિો અભ્યાસ કયાષ
પછી મારા દ્વારા તૈયાર કરિામાં આવ્ ં છે . આ ર્થીસીસમાં રહેલ વિશ્લેર્ણ અિે
વિિેચિાત્મક અર્થષઘટિ સંપ ૂણષપણે મૌલલક છે . આર્થી, હ ં જણાવ ં છં કે આ ર્થીસીસમાં મળે લ
વિિેચિાત્મક અલર્ભપ્રાયો અિે અન્ય વિગતો માટે હ ં જિાબદાર છં.
હ ં જાહેર કરં છં કે આ ર્થીસીસમાં કરિામાં આિેલ અિે રજૂ કરિામાં આિેલ કાયષ
મૌલલક છે અિે જ્યારે પણ અન્યિા કાયષમાંર્થી સંદર્ભો લેિામાં આવયા છે , ત્યારે તેઓિે
સ્પષ્ટપણે દશાષિિામા અવયા છે અિે માહહતીિા સ્ત્રોતિો સંદર્ભષસચીમા સમાિેશ કરિામાં
આવયો છે .
હ ં િધમાં જાહેર કરં છં કે આ સંશોધિ કાયષ મારં મૌલલક કાયષ છે અિે કોઈપણ
હિગ્રી/હિપ્લોમા, એસોવસએટવશપ, ફેલોવશપ માટે અન્ય કોઈપણ ્વિિવસિટી/સંસ્ર્થાિે
સબવમટ કરિામાં આવ્ ં િર્થી. હ ં એ પણ પષ્ષ્ટ કરં છં કે ર્ભક્ત કવિ િરવસિંહ મહેતા
્વિિવસિટી જૂિાગઢિા વિયમો અિે ્જીસીિી તારીખ 23મી જલાઈ, 2018િી સ ૂચિા
(્વિિવસિટી ગ્રાન્્સ કવમશિ શૈક્ષલણક સત્યવિષ્ઠાિો પ્રચાર અિે ઉચ્ચ શૈક્ષલણક સંસ્ર્થાઓમાં
સાહહત્યચોરી વિિારણ) મજબ કોઈ સાહહત્યચોરી (Plagiarism) િર્થી.

સંશોધકની સહી
સ્થળ:
તારીખ:

BKNMU Ph.D. Ordinances, 2023

Page 38

<!-- page 41 -->

DECLARATION BY RESEARCH SUPERVISOR
Certified

that

the

work

incorporated

in

the

thesis

……………………………………………………………………………………….……
(Title) submitted by Mr./Mrs./Ms. …….………………………………………………
was carried out by the candidate under my supervision/guidance. To the best of my
knowledge: (i) the Research Scholar has not submitted the same research work to any
other university/institution for any degree/diploma, associateship, fellowship (ii) the
thesis submitted is a record of original research work done by the student during the
period of study under my supervision, and confirms that there is no plagiarism as per the
rules of Bhakta Kavi Narsinh Mehta University Junagadh and notification of UGC dated
23rd July, 2018 UNIVERSITY GRANTS COMMISSION (PROMOTION OF
ACADEMIC INTEGRITY AND PREVENTION OF PLAGIARISM IN HIGHER
EDUCATIONAL INSTITUTIONS) REGULATIONS, 2018 and (iii) the thesis
represents independent research work on the part of the student.

Signature of Supervisor

Place:
Date:

BKNMU Ph.D. Ordinances, 2023

Page 39

<!-- page 42 -->

DECLARATION BY RESEARCH SUPERVISOR
(માર્ગદર્ગક શર્ક્ષકન ું વિિેદિ)
પ્રમાલણત કરે લ છે કે ……………………………………………………………………………… (શીર્ષક)
ર્થીસીસમાં સમાવિષ્ટ કાયષ શ્રી / શ્રીમતી / ક. ……………………………………………………………… દ્વારા
સબવમટ કરિામાં આવ્ ં છે જે મારી દે ખરે ખ/માગષદશષિ હેઠળ ઉમેદિાર દ્વારા હાર્થ ધરિામાં
આવ્ ં હત ં. મારી જાણકારી અનસાર: (i) સંશોધકે કોઈપણ હિગ્રી/હિપ્લોમા, એસોવસએટવશપ,
ફેલોવશપ માટે પ્રસ્તત સંશોધિ કાયષ અન્ય કોઈપણ ્વિિવસિટી/સંસ્ર્થાિે સબવમટ ક્ું િર્થી (ii)
સબવમટ કરે લ ર્થીસીસ એ મારી દે ખરે ખ હેઠળ અભ્યાસિા સમયગાળા દરવમયાિ વિદ્યાર્થી દ્વારા
કરિામાં આિેલ મ ૂળ સંશોધિ કાયષિો રે કોિષ છે , અિે તે પષ્ષ્ટ કરે છે કે ર્ભક્ત કવિ િરવસિંહ મહેતા
્વિિવસિટી, જૂિાગઢિા વિયમો અિે 23મી જલાઈ, 2018 િા ્જીસીિા (્વિિવસિટી ગ્રાન્્સ
કવમશિ શૈક્ષલણક સત્યવિષ્ઠાિો પ્રચાર અિે ઉચ્ચ શૈક્ષલણક સંસ્ર્થાઓમાં સાહહત્યચોરી વિિારણ)
રે ગ્્લેશન્સ, 2018 િી સ ૂચિા અનસાર કોઈ સાહહત્યચોરી (Plagiarism) િર્થી અિે (iii) ર્થીસીસ
વિદ્યાર્થીએ કરે લ સ્િતંત્ર સંશોધિ કાયષન ં પ્રવતવિવધત્િ કરે છે .

માર્ગદર્ગક શર્ક્ષકની સહી
સ્થળ:
તારીખ:

BKNMU Ph.D. Ordinances, 2023

Page 40
