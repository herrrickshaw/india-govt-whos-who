---
doc_id: "cfff338f8e2da4f7"
source_url: "https://gbu.edu.in/wp-content/uploads/2024/09/RC-Corrigendum-170924.pdf"
ministry: "Gujarat Biotechnology University"
title: "RC Corrigendum (Dated:17-09-2024)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ec154958056c8601"
---

<!-- page 1 -->

Corrigendum
Gujarat Biotechnology University invites online Bids in a two-bid format for “Annual
Rate Contract for Supply of laboratory Chemicals, Labware, Glassware, Plastic wares,
Lab Consumables and Gases” on Single Tender Enquiry (STE) Basis at the Institute as
per the list at Annexure-I to the Tender form. Only Brand or its authorised vendor or
both mentioned in annexure-1 is eligible to participate.

Annexure I
Sr
No

Category
1. Chemical

Brand Name

TCI, SD Fine Chem , Thermo Fisher Scientific, Merck , Sigma ,
NEB , Takara Bio , Himedia , Promega , Biolegend , Santa cruze ,
SRL , Qiagen , Biorad , Illumina , Twist , 10x , MP Bio , Roche ,
Norgen , Nanopore , Agilent , Megazyme ,GenScript , Solis
Biodyne , Qualigens , Miltenyi , Stem Cell Technologies ,
Prospecbio , VWR Scientific , Cell signaling technologies , Abcam ,
Jena Bioscience , Click Chemistry tools , Twist Biosciences ,
Plasmidsaurus , Creative Biogene , IDT , Labware , BD Bioscience
, Creative Diagnostic , ORIGENE , Lifeasible , Biochain
Incorporated , Genetix Biotech Asia Pvt Ltd , Celgen Biotech
(India) , Vitrogen (India) , IMV , Origio , Favorgen , Invitrogen ,
Fermentas , Novus Biologicals , R&D systems , Micro Master ,
Nice Chemicals , Genaxy Scientific ,
Duchefa , Finar , MagGenome , Cytiva , Lonza , Zelle , Labex , ILS
, NextGen , Addgene, Revvity, Tocris Bioscience , ABM , Canvax
, Abnova , Anaspec , Blueray Biotech , Oxford Nanopore ,
Sartorius , Loba , Oxford , Rankem
2. Plasticware
Genaxy , Tarsons , Polylab , Axiva , Himedia , Axygen , Pfact ,
Genetix , Thermo Fisher Scientific , Corning , Eppendorf , Microlit
, Abdos , Whatman ,IKA, Witeg , Agilent , ILS , NEB , Qiagen ,
Techno Plastic Products , Gilson
3. Glassware
Borosil , Riviera , Supertek , Glassco , Omson , Thermo Fisher
Scientific , Corning , Sabar Scientific , Rasayan , Axiva , Bluestar,
Witeg, Alpha
4. Gas
CO2 , N2 , Liquid Nitrogen , H2 , Argon, Mix Gas , O2 , Air ,
Helium
5. Service
Eurofins , IDT , Genotyping , Nucleome , ILS , Bionivid , HiMedia
, geneOmbio, Unipath , Barcode Bioscience , Qaigen
6. Miscellaneous Keltech Energies , Ugaoo , Trust Basket , Nippro , Dispovan ,
Sujay , One Prick , NEB, Premium , Solocare
