---
doc_id: "a95da7cfff5feed4"
source_url: "https://home.gujarat.gov.in/upload/01=15-04-2020MHAorderdt15.04.2020,withRevisedConsolidatedGuidelines_HD_100321.PDF"
ministry: "Home Department, Gujarat"
title: ""
date: ""
pages: 15
method: "tesseract:guj+eng"
script: "LATIN"
needs_ocr: false
sha1: "21acf381bb89b8a8"
---

<!-- page 1 -->

No. 40-3/2020-DM-I(A)
Government of India
Ministry of Home Affairs
North Block, New Delhi-110001
Dated 15" April, 2020
ORDER

Whereas, in exercise of the powers, conferred under Section 10(2)(I) of the
Disaster Management Act 2005, the undersigned, in his capacity as Chairperson,
National Executive Committee, has issued an Order dated 14" April, 2020 that the
lockdown measures stipulated in the Consolidated Guidelines of Ministry of Home
Affairs (MHA) for containment of COVID-19 epidemic in the country, will continue to

| remain in force upto 3 May, 2020 to contain the spread of COVID-19 in the country;

| Whereas, to mitigate hardship to the public, select additional activities will be
allowed, which will come into effect from 20" April, 2020. However, these additional
activities will be operationalized by States/ Union Territories (UTs)/ District
Administrations based on strict compliance to the existing guidelines on lockdown
measures. Before operating these relaxations, States/ UTs/ District Administrations

shall ensure that all preparatory arrangements with regard to social distancing in
offices, workplaces, factories and establishments, as also other sectoral
requirements are in place. The consolidated revised guidelines incorporating these
relaxations are enclosed;

Whereas, the consolidated revised guidelines will not apply in containment
zones, as demarcated by States/ UTs/ District administrations. If any new area is
included in the category of a containment zone, the activities allowed in that area till
the time of its categorization as a containment zone, will be suspended except for
those activities as are specifically permitted under the guidelines of Ministry of Health
and Family Welfare (MoHFW), Government of India;

Whereas, in exercise of the powers, conferred under Section 10(2)(I) of the
Disaster Management Act, 2005, the undersigned, in his capacity as Chairperson,
National Executive Committee, hereby issues directions to all the all Ministries/
Departments of Government of India, State/Union Territory Governments and
State/Union Territory Authorities for the strict implementation of enclosed
consolidated revised guidelines.

Pv guy
nion Home Secretary
To:
1. The Secretaries of Ministries/ Departments of Government of India
2. The Chief Secretaries/Administrators of States/Union Territories
(As per list attached)

<!-- page 2 -->

Copy to:
i. All members of the National Executive Committee.
ii, Member Secretary, National Disaster Management Authority.
ર

<!-- page 3 -->

Consolidated Revised Guidelines on the measures to be taken by Ministries/
Departments of Government of India, State/ UT Governments and State/ UT
authorities for containment of COVID-19 in the country

[As per Ministry of Home Affairs (MHA) Order No. 40-3/2020-DM-I (A) dated 15"

April, 2020]

1. With the extension of the lockdown period, the following activities will

continue to remain prohibited across the country until 3" May, 2020:
1. All domestic and international air travel of passengers, except for purposes
enumerated in para 4 (ix), and for security purposes.

ii. All passenger movement by trains, except for security purposes.

iii. | Buses for public transport.

iv. Metro rail services.

૪.  Inter-district and inter-State movement of individuals except for medical
reasons or for activities permitted under these guidelines.

| vi. All educational, training, coaching institutions etc. shall remain closed.

vii. All industrial and commercial activities other than those specifically permitted
under these guidelines.

viii. | Hospitality services other than those specifically permitted under these
guidelines.

ix. Taxis (including auto rickshaws and cycle rickshaws) and services of cab
aggregators.

x. All cinema halls, malls, shopping complexes, gymnasiums, sports complexes,
| swimming pools, entertainment parks, theatres, bars and auditoriums,
| assembly halls and similar places.

| xi. All social/ political/ sports/ entertainment/ academic/ cultural/ religious
| functions/ other gatherings.

xii. All religious places/ places of worship shall be closed for public. Religious
congregations are strictly prohibited.

xiii. In case of funerals, congregation of more than twenty persons will not be
| permitted.
| 2. Operation of guidelines in Hotspots and containment zones |
| 1. ‘Hotspots’, i.e., areas of large COVID-19 outbreaks, or clusters with significant
| spread of COVID-19, will be determined as per the guidelines issued by
| Ministry of Health and Family Welfare (MoHFW), Government of India (Gol).
| ii. 11 these hotspots, containment zones will be demarcated by States/ UTs/

District administrations as per the guidelines of MoHFW.

iii. In these containment zones, the activities allowed under these guidelines will
not be permitted. There shall be strict perimeter control in the area of the
containment zones to ensure that there is no unchecked inward/ outward
movement of population from these zones except for maintaining essential
services (including medical emergencies and law and order related duties)
and Government business continuity. The guidelines issued in this regard by
MoHFW will be strictly implemented by State/ UT Governments and the local
district authorities.

<!-- page 4 -->

3. Select permitted activities allowed with effect from 20" May, 2020:
| 1. To mitigate hardship to the public, select additional activities have been
allowed which will come into effect from 20" April, 2020. These limited
exemptions will be operationalized by States/ UTs/ district administrations
based on strict compliance to the existing guidelines. Also, before allowing
these select additional activities, States/ UTs/ district administrations shall
ensure that all preparatory arrangements with regard to the Standard
| Operating Procedures (SOPs) for social distancing in offices, workplaces,
factories and establishments, as also other sectoral requirements are in place.
ii. The consolidated revised guidelines incorporating these select permitted
activities have been enumerated in paras 5-20 below.
4. Strict enforcement of the lockdown guidelines
1. State/ UT Governments shall not dilute these guidelines issued under the
Disaster Management Act, 2005, in any manner, and shall strictly enforce the
same.
ii. | State/ UT Governments, may, however, impose stricter measures than these
guidelines as per requirement of the local areas.
5. All health services (including AYUSH) to remain functional, such as:
1. Hospitals, nursing homes, clinics, telemedicine facilities.
ii. Dispensaries, chemists, pharmacies, all kinds of medicine shops including
Jan Aushadhi Kendras and medical equipment shops.
iii. | Medical laboratories and collection centres.

iv. Pharmaceutical and medical research labs, institutions carrying out COVID-19
related research.

v. Veterinary Hospitals, dispensaries, clinics, pathology labs, sale and supply of
vaccine and medicine.

vi. Authorised private establishments, which support the provisioning of essential
services, or efforts for containment of COVID-19, including home care
providers, diagnostics, supply chain firms serving hospitals.

vii. Manufacturing units of drugs, pharmaceuticals, medical devices, medical
oxygen, their packaging material, raw material and intermediates.

viii. Construction of medical/ health infrastructure including manufacture of
ambulances.

ix. Movement (inter and intra State, including by air) of all medical and veterinary
personnel, scientists, nurses, para-medical staff, lab technicians, mid-wives
and other hospital support services, including ambulances.

6. Agricultural and related activities:
| A. All agricultural and horticultural activities to remain fully functional, such as:
i. Farming operations by farmers and farm workers in field.

ii. Agencies engaged in procurement of agriculture products, including MSP
operations.

iii. ‘Mandis’ operated by the Agriculture Produce Market Committee (APMC) or
as notified by the State/ UT Government (e.g., satellite mandis). Direct
marketing operations by the State/ UT Government or by industry, directly

; Spee |

<!-- page 5 -->

from farmers/ group of farmers, FPOs’ co-operatives etc. States/ UTs may
promote decentralized marketing and procurement at village level.

iv. Shops of agriculture machinery, its spare parts (including its supply chain) and
repairs to remain open.

v. ‘Custom Hiring Centres (CHC)’ related to farm machinery.

vi. | Manufacturing, distribution and retail of fertilizers, pesticides and seeds.
vii. | Movement (inter and intra State) of harvesting and sowing related machines
like combined harvester and other agriculture/ horticulture implements.
| B. Fisheries - the following activities will be functional:

i. Operations of the fishing (marine and inland)/ aquaculture industry, including
feeding & maintenance, harvesting, processing, packaging, cold chain, sale
and marketing.

. ii. Hatcheries, feed plants, commercial aquaria.
| iii. | Movement of fish/ shrimp and fish products, fish seed/ feed and workers for all
these activities.

c. Plantations- the following activities will be functional:
| i. Operations of tea, coffee and rubber plantations, with maximum of 50%
| workers.
| ii. Processing, packaging, sale and marketing of tea, coffee, rubber and cashew,
| with maximum of 50% workers.

D. Animal husbandry — the following activities will be functional:

1. Collection, processing, distribution and sale of milk and milk products by milk
processing plants, including transport and supply chain.

ii. Operation of animal husbandry farms including poultry farms & hatcheries and
livestock farming activity.

iii. Animal feed manufacturing and feed plants, including supply of raw material,
such as maize and soya.
iv. Operation of animal shelter homes, including Gaushalas.
7. Financial sector: following to remain functional:

i. Reserve Bank of India (RBI) and RBI regulated financial markets and entities
like NPCI, CCIL, payment system operators and standalone primary dealers.

ii. Bank branches and ATMs, IT vendors for banking operations, Banking
Correspondents (BCs), ATM operation and cash management agencies.

a. Bank branches be allowed to work as per normal working hours till disbursal
of DBT cash transfers is complete.

b. Local administration to provide adequate security personnel at bank
branches and BCs to maintain social distancing, law and order and
staggering of account holders.

iii. SEBI, and capital and debt market services as notified by the Securities and
Exchange Board of India (SEBI).
iv. IRDAI and Insurance companies. Na
3

<!-- page 6 -->

8. Social sector: following to remain functional:
1. Operation of homes for children/ disabled/ mentally challenged/ senior
citizens/ destitutes/ women/ widows.

ii. | Observation homes, after care homes and places of safety for juveniles.

iii. Disbursement of social security pensions, e.g., old age/ widow/ freedom
fighter pensions; pension and provident fund services provided by Employees
Provident Fund Organisation (EPFO).

iv. Operation of Anganwadis — distribution of food items and nutrition once in 15 '
days at the doorsteps of beneficiaries, e.g., children, women and lactating
mothers. Beneficiaries will not attend the Anganwadis.

9. Online teaching/ distance learning to be encouraged:
1. All educational, training, coaching institutions etc. shall remain closed.

ii. However, these establishments are expected to maintain the academic
schedule through online teaching.

iii. | Maximum use of Doordarshan (DD) and other educational channels may be

| made for teaching purposes.
10. MNREGA works to be allowed:
1. MNREGA works are allowed with strict implementation of social distancing |
and face mask.

ii. Priority to be given under MNREGA to irrigation and water conservation
works.

iii. Other Central and State sector schemes in irrigation and water conservation
sectors may also be allowed to be implemented and suitably dovetailed with
MNREGA works.

11. Public utilities: following to remain functional:
1. Operations of Oil and Gas sector, including refining, transportation,
distribution, storage and retail of products, e.g., petrol, diesel, kerosene, CNG,
LPG, PNG etc.

ii. Generation, transmission and distribution of power at Central and State/ UT
levels.

iii. | Postal services, including post offices.

iv. Operations of utilities in water, sanitation and waste management sectors, at
municipal/ local body levels in States and UTs.

v. Operation of utilities providing telecommunications and internet services.

12. Movement, loading/ unloading of goods/ cargo (inter and intra State) is
allowed, as under:
i. All goods traffic will be allowed to ply.

ii. Operations of Railways: Transportation of goods and parcel trains.

iii. Operations of Airports and related facilities for air transport for cargo
movement, relief and evacuation.

iv. Operations of Seaports and Inland Container Depots (ICDs) for cargo
transport, including authorized custom clearing and forwarding agents.

‘ Nw

<!-- page 7 -->

j eee eo eee

v. Operations of Land Ports for cross land border transportation of essential
goods, including petroleum products and LPG, food products, medical
supplies.

vi. Movement of all trucks and other goods/ carrier vehicles with two drivers and
one helper subject to the driver carrying a valid driving license; an empty
truck/ vehicle will be allowed to ply after the delivery of goods, or for pick up of
goods.

vii. | Shops for truck repairs and dhabas on highways, with a stipulated minimum
distance as prescribed by the State/ UT authorities.

| viii. | Movement of staff and contractual labour for operations of railways, airports/
air carriers, seaports/ ships/ vessels, landports and ICDs is allowed on passes
being issued by the local authority on the basis of authorizations issued by the
respective designated authority of the railways, airports, seaports, landports
and ICDs.

13. Supply of essential goods is allowed, as under:

1. All facilities in the supply chain of essential goods, whether involved in
manufacturing, wholesale or retail of such goods through local stores, large
brick and mortar stores or e-Commerce companies should be allowed to
operate, ensuring strict social distancing without any restriction on their timing
of opening and closure.

ii. Shops (including Kirana and single shops selling essential goods) and carts,
including ration shops (under PDS), dealing with food and groceries (for daily
use), hygiene items, fruits and vegetables, dairy and milk booths, poultry,
meat and fish, animal feed and fodder etc, should be allowed to operate,
ensuring strict social distancing without any restriction on their timing of
opening and closure.

iii. District authorities may encourage and facilitate home delivery to minimize the
movement of individuals outside their homes.

14. Commercial and private establishments, as listed below, will be allowed

to operate:

1. Print and electronic media including broadcasting, DTH and cable services.

ii. IT and IT enabled Services, with upto 50% strength.

iii. Data and call centres for Government activities only.

iv. Government approved Common Service Centres (CSCs) at Gram Panchayat
level.

૪. E-commerce companies. Vehicles used by e-commerce operators will be
allowed to ply with necessary permissions.

vi. Courier services.

vii. Cold storage and warehousing services, including at ports, airports, railway
stations, container Depots, individual units and other links in the logistics
chain.

viii. | Private security services and facilities management services for maintenance
and upkeep of office and residential complexes.

5
| |
Be |

<!-- page 8 -->

ix. Hotels, homestays, lodges and motels, which are accommodating tourists and
persons stranded due to lockdown, medical and emergency staff, air and sea
crew.

x. Establishments used/ earmarked for quarantine facilities.

xi. Services provided by self-employed persons, e.g., electrician, IT repairs,
plumbers, motor mechanics, and carpenters.

15. Industries/ Industrial Establishments (both Government and private), as .

listed below, will be allowed to operate:

i. Industries operating in rural areas, i.e., outside the limits of municipal
corporations and municipalities.

ii. Manufacturing and other industrial establishments with access control in
Special Economic Zones (SEZs) and Export Oriented Units (EoUs), industrial
estates, and industrial townships. These establishments shall make
arrangements for stay of workers within their premises as far as possible and/
or adjacent buildings and for implementation of the Standard operating
protocol (SOP) as referred to in para 21 (ii) below. The transportation of
workers to work place shall be arranged by the employers in dedicated
transport by ensuring social distancing.

iii. Manufacturing units of essential goods, including drugs, pharmaceuticals,
medical devices, their raw material and intermediates.

iv. Food processing industries in rural areas, i.e., outside the limits of municipal
corporations and municipalities.

v. Production units, which require continuous process, and their supply chain.

vi. | Manufacturing of IT hardware.

vii. Coal production, mines and mineral production, their transportation, supply of
explosives and activities incidental to mining operations.
viii. | Manufacturing units of packaging material.

ix. Jute industries with staggered shifts and social distancing.

x. Oil and gas exploration/ refinery.

xi. Brick kilns in rural areas i.e., outside the limits of municipal corporations and
municipalities.

16. Construction activities, listed as below, will be allowed to operate:

1. Construction of roads, irrigation projects, buildings and all kinds of industrial
projects, including MSMEs, in rural areas, i.e., outside the limits of municipal
corporations and municipalities; and all kinds of projects in industrial estates.

ii. | Construction of renewable energy projects.

iii. Continuation of works in construction projects, within the limits of municipal
corporations and municipalities, where workers are available on site and no
workers are required to be brought in from outside (in situ construction).

17. Movement of persons is allowed in the following cases:

1. Private vehicles for emergency services, including medical and veterinary
care, and for procuring essential commodities. In such cases, one passenger
besides the private vehicle driver can be permitted in the backseat, in case of

<!-- page 9 -->

four-wheelers; however, in case of two-wheelers, only the driver of the vehicle
is to be permitted.
ii. All personnel travelling to place of work and back in the exempted categories,
| as per the instructions of the State/ UT local authority.
| 18. Offices of the Government of India, its Autonomous/ Subordinate Offices
| will remain open, as mentioned below:
1. Defence, Central Armed Police Forces, Health and Family Welfare, Disaster
management and Early Warning Agencies (IMD, INCOIS, SASE and National
Centre of Seismology, CWC), National Informatics Centre (NIC), Food
Corporation of India (FCI), NCC, Nehru Yuva Kendras (NYKs) and Customs
to function without any restriction.

ii. Other Ministries and Departments, and offices under their control, are to
function with 100% attendance of Deputy Secretary and levels above that.
Remaining officers and staff to attend upto 33% as per requirement.

| 19. Offices of the State/ Union Territory Governments, their Autonomous
Bodies and Local Governments will remain open, as mentioned below:
i. Police, home guards, civil defence, fire and emergency services, disaster
management, prisons and municipal services will function without any
| restrictions.

ii. All other Departments of State/ UT Governments to work with restricted staff.
Group ‘A’ and ‘B’ officers may attend as required. Group ‘C’ and levels below
that may attend upto 33% of strength, as per requirement to ensure social
distancing. However, delivery of public services shall be ensured, and

| necessary staff will be deployed for such purpose.

iii. District administration and Treasury (including field offices of the Accountant
General) will function with restricted staff. However, delivery of public services
shall be ensured, and necessary staff will be deployed for such purpose.

iv. Resident Commissioner of States/ UTs, in New Delhi, only to the extent of
coordinating COVID-19 related activities and internal kitchen operations.

| v. Forest offices: staff/ workers required to operate and maintain zoo, nurseries,
wildlife, fire-fighting in forests, watering plantations, patrolling and their
| necessary transport movement.
| જુ
20. Persons to remain under mandatory quarantine, as under:
1. All such persons who have been directed by health care personnel to remain
under strict home/ institutional quarantine for a period as decided by local
Health Authorities.

ii. Persons violating quarantine will be liable to legal action under Section 188 of
the IPC, 1860.

iii. Quarantined persons, who have arrived in India after 15.2.2020, after expiry
of their quarantine period and being tested Covid-19 negative, will be released
following the protocol prescribed in the SOP issued by MHA.

21. Instructions for enforcement of above lockdown measures:
|
| i. All the district magistrates shall strictly enforce the National COVID 19
| directives as specified in Annexure |. Penalties prescribed shall be levied
) and collected from all persons and entities violating these directives.
ee 7 ell

<!-- page 10 -->

ii. All industrial and commercial establishments, work places, offices etc. shall
put in place arrangements for implementation of SOP as in Annexure Il
before starting their functioning.

iii. In order to implement these containment measures, the District Magistrate will
deploy Executive Magistrates as Incident Commanders in the respective local
jurisdictions. The Incident Commander will be responsible for the overall
implementation of these measures in their respective jurisdictions. All other
line department officials in the specified area will work under the directions of
such incident commander. The Incident Commander will issue passes for

enabling essential movements as explained.

iv. The Incident Commanders will in particular ensure that all efforts for
mobilization of resources, workers and material for augmentation and
expansion of hospital infrastructure shall continue without any hindrance.

v. Additional activities permitted in these guidelines shall be implemented
in a phased manner, after making all arrangements necessary for strict
implementation of the guidelines. These will come into force with effect
from 20" April, 2020.

22. Penal provisions

Any person violating these lockdown measures will be liable to be proceeded against

as per the provisions of Section 51 to 60 of the Disaster Management Act, 2005,
besides legal action under Sec. 188 of the IPC, and other legal provisions as

applicable. Extracts of these penal provisions are at Annexure Ill.

So
Union Home Secretary
ર
