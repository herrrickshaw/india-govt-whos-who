---
doc_id: "eac0c258f2e6c5fe"
source_url: "https://pnt.gujarat.gov.in/Downloads/VC_CEO_5_02072024.pdf"
ministry: "Ports and Transport Department, Gujarat"
title: "Inland Vessels Act, 2021(24 of 2021) ના સેક્શન ૧૦ તથા Inland Vessel (Survey and Certification) Rules, 2022 ના Rule 23 અને 24 હેઠળ ફાળવેલ સત્તા અન્વયે ગુજરાત સરકારશ્રી ચીફ નોટિકલ ઓફીસર, ગુજરાત મેરીટાઈમ બોર્ડ, હેડ ઓફીસ, ગાંધીનગરને ચીફ સર્વેયર તરીકેની ફરજનું વહન કરશે તે અંગેનું નોટીફિકેશન નં. G/PT/2024"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6d795d136068584b"
---

<!-- page 1 -->

Extra No. 97

©
The Gujarat Government Gazette
EXTRAORDINARY
PUBLISHED BY AUTHORITY
Vol. LXV ]
TUESDAY, JUNE 25, 2024 / ASHADHA 4, 1946
Separate paging is given to this Part in order that it may be filed as a Separate Compilation.
PART IV-A
Rules and Orders (Other than those published in Parts I, I-A, and I-L) made
by the Government of Gujarat under the Central Acts

PORTS AND TRANSPORT DEPARTMENT
NOTIFICATION
Sachivalaya, Gandhinagar, 25th June, 2024
INLAND VESSELS ACT, 2021.
No. G/PT/2024/8/PTD/MIS/e-file/22/2024/0899/GH-1 :- In exercise of the powers conferred by sub-section (3) section
5 of the Inland Vessels Act, 2021 (24 of 2021), the Government of Gujarat, hereby appoints the Vice Chairman and Chief
Executive Officer, Gujarat Maritime Board, for the purpose of exercising or discharging the powers, authority or duties
conferred by or under the said Act except granting of a certificate of survey by the surveyor or who made the declaration
of the survey under section 12 of the said Act.
By order and in the name of the Governor of Gujarat,
KETAN SUTHAR,
Joint Secretary to Government.

---------IV-A Ex.-97

97-1

Signature Not Verified

Government Central Press, Gandhinagar.

Signed by:BHOLUSINGH G THAKUR
Date: 2024.07.01 10:13:05 +05:30
Reason: Validate Document
Location: Government Central Press,
Gandhinagar
