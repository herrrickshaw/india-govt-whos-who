---
doc_id: "b7e5ffefd28c307f"
source_url: "https://home.gujarat.gov.in/upload/14=29-06-2020Unlock2_MHAOrder_29062020_HD_100321.pdf"
ministry: "Home Department, Gujarat"
title: ""
date: ""
pages: 8
method: "tesseract:guj+eng"
script: "LATIN"
needs_ocr: false
sha1: "3fe153f746cd4478"
---

<!-- page 1 -->

No. 40-3/2020-DM-I(A)
Government of India
Ministry of Home Affairs
North Block, New Delhi-110001
Dated 29 June , 2020
ORDER

Whereas, an Order of even number dated 30.05.2020 was issued for
containment of COVID-19 in the country, for a period upto 30.06.2020;

Whereas, in exercise of the powers under section 6(2)(i) of the Disaster
Management Act, 2005, National Disaster Management Authority (NDMA) has
directed the undersigned to issue an order to re-open more activities in a
calibrated manner, in areas outside the Containment Zones and to extend the
lockdown in Containment Zones upto 31.07.2020;

Now therefore, in exercise of the powers, conferred under Section 10(2)(1)
of the Disaster Management Act 2005, the undersigned hereby directs that
guidelines on Unlock 2, as annexed, will be in force upto 31.07.2020.

20L9
tears Jos
Union Home Secretary
and, Chairman, National Executive Committee (NEC)
To:
1. The Secretaries of Ministries/ Departments of Government of India
2. The Chief Secretaries/Administrators of States/Union Territories
(As per list attached)
Copy to:
i. All Members of the National Executive Committee
ii. Member Secretary, National Disaster Management Authority

<!-- page 2 -->

Guidelines for Phased Re-opening (Unlock 2)
[As per Ministry of Home Affairs Order No. 40-3/2020-DM-I (A) dated 29 June, 2020]
1. Activities permitted during Unlock 2 period outside Containment Zones
In areas outside Containment Zones, all activities will be permitted, except the
following:
(i) Schools, colleges, educational and coaching institutions will remain closed till
31 July, 2020. Online/ distance learning shall continue to be permitted and
shall be encouraged.
Training institutions of the Central and State Governments will be allowed to
function from 15 July, 2020, for which Standard Operating Procedure (SOP)
will be issued by the Department of Personnel & Training (DoPT).
(1) International air travel of passengers, except as permitted by MHA.
(iii) Metro Rail.
(iv) Cinema halls, gymnasiums, swimming pools, entertainment parks, theatres,
bars, auditoriums, assembly halls and similar places.
(v) Social/ political/ sports/ entertainment/ academic/ cultural/ religious functions
and other large congregations.
Dates for re-starting the above activities may be decided separately and necessary
SOPs shall be issued for ensuring social distancing and to contain the spread of
COVID-19.
Domestic flights and passenger trains have already been allowed in a limited
manner. Their operations will be further expanded in a calibrated manner.
2. Night curfew
Movement of individuals shall remain strictly prohibited between 10.00 pm to 5.00
am throughout the country, except for essential activities, including operation of
industrial units in multiple shifts, movement of persons and goods on National and
State Highways, loading and unloading of cargo and travel of persons to their
destinations after disembarking from buses, trains and airplanes. Local authorities
shall issue orders, in the entire area of their jurisdiction, under appropriate
provisions of law, such as under Section 144 of CrPC, and ensure strict
compliance.
3. National Directives for COVID-19 Management
National Directives for COVID-19 Management, as specified in Annexure I, shall
continue to be followed throughout the country.
4. Lockdown limited to Containment Zones
(i) Lockdown shall continue to remain in force in the Containment Zones till 31
July, 2020.
a ai
gajoel

<!-- page 3 -->

(ii) Containment Zones will be demarcated by the District authorities after taking
into consideration the guidelines of Ministry of Health & Family Welfare
(MoHFW) with the objective of effectively breaking the chain of transmission.
These Containment Zones will be notified on the websites by the respective
District Collectors and by the States/ UTs and information will be shared with
MOHFW.

(iii) In the Containment Zones, only essential activities will be allowed. There
shall be strict perimeter control to ensure that there is no movement of people
in or out of these zones, except for medical emergencies and for maintaining
supply of essential goods and services. In the Containment Zones, there shall
be intensive contact tracing, house-to-house surveillance, and other clinical
interventions, as required. Guidelines of MoHFW shall be effectively
implemented for the above purpose.

(iv) Activities in the Containment Zones shall be monitored strictly by the State/
UT authorities, and the guidelines relating to containment measures in these
zones shall be strictly implemented.

(v) States/ UTs may also identify Buffer Zones outside the Containment Zones,
where new cases are more likely to occur. Within the buffer zones, restrictions
as considered necessary may be put in place by the District authorities.

5. States/ UTs, based on their assessment of the situation, may prohibit certain
activities outside the Containment zones, or impose such restrictions as
deemed necessary.

However, there shall be no restriction on inter-State and intra-State movement of

persons and goods including those for cross land-border trade under Treaties with

neighbouring countries. No separate permission/ approval/ e-permit will be
required for such movements.

6. Movement of persons with SOPs
Movement by passenger trains and Shramik special trains; domestic passenger air
travel; movement of Indian Nationals stranded outside the country and of specified
persons to travel abroad: evacuation of foreign nationals; and sign-on and sign-off
of Indian seafarers will continue to be regulated as per SOPs issued.

7, Protection of vulnerable persons
Persons above 65 years of age, persons with co-morbidities, pregnant women, and
children below the age of 10 years are advised to stay at home, except for essential
and health purposes.

8. Use of Aarogya Setu
(i) Aarogya Setu enables early identification of potential risk of infection, and

thus acts as a shield for individuals and the community.

(ii) With a view to ensuring safety in offices and work places, employers on best
effort basis should ensure that Aarogya Setu is installed by all employees
having compatible mobile phones.

: \_ a
ov
તર્ક 9 બં

<!-- page 4 -->

(iii) District authorities may advise individuals to install the Aarogya Setu
application on compatible mobile phones and regularly update their health
status on the app. This will facilitate timely provision of medical attention to
those individuals who are at risk.

9. Strict enforcement of the guidelines

(i) State/ UT Governments shall not dilute these guidelines issued under the
Disaster Management Act, 2005, in any manner.

(ii) All the District Magistrates shall strictly enforce the above measures.

10. Penal provisions

Any person violating these measures will be liable to be proceeded against as per

the provisions of Section 51 to 60 of the Disaster Management Act, 2005, besides

legal action under Section188 of the IPC, and other legal provisions as applicable.

Extracts of these penal provisions are at Annexure II.

= 1,0
oO
[wre aloe \ મર
Union Home Secretary
and, Chairman, National Executive Committee
3

<!-- page 5 -->

Annexure I
National Directives for COVID-19 Management

1. Face coverings: Wearing of face cover is compulsory in public places; in
workplaces; and during transport.

2. Social distancing: Individuals must maintain a minimum distance of 6 feet (2 gaz
ki doori) in public places.

Shops will ensure physical distancing among customers.

Be Gatherings: Large public gatherings/ congregations continue to remain
prohibited.

Marriage related gatherings : Number of guests not to exceed 50.
Funeral/ last rites related gatherings : Number of persons not to exceed 20.

4. Spitting in public places will be punishable with fine, as may be prescribed by
the State/ UT local authority in accordance with its laws, rules or regulations.

5. Consumption of liquor, paan, gutka, tobacco ete. in public places is prohibited.
Additional directives for Work Places

6. Work from home (WfH): As far as possible the practice of WfH should be
followed.

7. Staggering of work/ business hours will be followed in offices, work places,
shops, markets and industrial & commercial establishments.

8. Screening & hygiene: Provision for thermal scanning, hand wash and sanitizer
will be made at all entry and exit points and common areas.

9, Frequent sanitization of entire workplace, common facilities and all points
which come into human contact e.g. door handles etc., will be ensured, including
between shifts.

10. Social distancing: All persons in charge of work places will ensure adequate
distance between workers, adequate gaps between shifts, staggering the lunch
breaks of staff, etc.

wee
૦
ne
za\e\
4

<!-- page 6 -->

Annexure IT
Offences and Penalties for Violation of Lockdown Measures
A Section 51 to 60 of the Disaster Management Act, 2005

51. Punishment for obstruction, ete —Whoever, without reasonable cause —

(a) obstructs any officer or employee of the Central Government or the State
Government, or a person authorised by the National Authority or State Authority
or District Authority in the discharge of his functions under this Act; or

(b) refuses to comply with any direction given by or on behalf of the Central
Government or the State Government or the National Executive Committee or
the State Executive Committee or the District Authority under this Act,

shall on conviction be punishable with imprisonment for a term which may extend to one
year or with fine, or with both, and if such obstruction or refusal to comply with
directions results in loss of lives or imminent danger thereof, shall on conviction be
punishable with imprisonment for a term which may extend to two years.

52. Punishment for false claim.—Whoever knowingly makes a claim which he
knows or has reason to believe to be false for obtaining any relief, assistance, repair,
reconstruction or other benefits consequent to disaster from any officer of the Central
Government, the State Government, the National Authority, the State Authority or the
District Authority, shall, on conviction be punishable with imprisonment for a term
which may extend to two years, and also with fine.

53. Punishment for misappropriation of money or materials, ete.—Whoever,
being entrusted with any money or materials, or otherwise being, in custody of, or
dominion over, any money or goods, meant for providing relief in any threatening
disaster situation or disaster, misappropriates or appropriates for his own use or disposes
of such money or materials or any part thereof or wilfully compels any other person so to
do, shall on conviction be punishable with imprisonment for a term which may extend to
two years, and also with fine.

54. Punishment for false warning.—Whoever makes or circulates a false alarm
or warning as to disaster or its severity or magnitude, leading to panic, shall on
conviction, be punishable with imprisonment which may extend to one year or with fine.

55. Offences by Departments of the Government.—(1) Where an offence
under this Act has been committed by any Department of the Government, the head of
the Department shall be deemed to be guilty of the offence and shall be liable to be
proceeded against and punished accordingly unless he proves that the offence was
committed without his knowledge or that he exercised all due diligence to prevent the
commission of such offence.

(2) Notwithstanding anything contained in sub-section (1), where an offence
under this Act has been committed by a Department of the Government and it is proved
that the offence has been committed with the consent or connivance of, or is attributable
to any neglect on the part of, any officer, other than the head of the Department, such
officer shall be deemed to be guilty of that offence and shall be liable to be proceeded
against and punished accordingly.

56. Failure of officer in duty or his connivance at the contravention of the
provisions of this Act.—Any officer, on whom any duty has been imposed by or under
this Act and who ceases or refuses to perform or withdraws himself from the duties of

5

<!-- page 7 -->

his office shall, unless he has obtained the express written permission of his official
superior or has other lawful excuse for so doing, be punishable with imprisonment for a
term which may extend to one year or with fine.

57. Penalty for contravention of any order regarding requisitioning.—If any
person contravenes any order made under section 65, he shall be punishable with
imprisonment for a term which may extend to one year or with fine or with both.

58. Offence by companies.—(1) Where an offence under this Act has been
committed by a company or body corporate, every person who at the time the offence
was committed, was in charge of, and was responsible to, the company, for the conduct
of the business of the company, as well as the company, shall be deemed to be guilty of
the contravention and shall be liable to be proceeded against and punished accordingly:

Provided that nothing in this sub-section shall render any such person liable to
any punishment provided in this Act, if he proves that the offence was committed
without his knowledge or that he exercised due diligence to prevent the commission of
such offence.

(2) Notwithstanding anything contained in sub-section (1), where an offence
under this Act has been committed by a company, and it is proved that the offence was
committed with the consent or connivance of or is attributable to any neglect on the part
of any director, manager, secretary or other officer of the company, such director,
manager, secretary or other officer shall also, be deemed to be guilty of that offence and
shall be liable to be proceeded against and punished accordingly.

Explanation.—For the purpose of this section—

(a) “company” means anybody corporate and includes a firm or other
association of individuals; and
(b) “director”, in relation to a firm, means a partner in the firm.

59. Previous sanction for prosecution.—No prosecution for offences
punishable under sections 55 and 56 shall be instituted except with the previous sanction
of the Central Government or the State Government, as the case may be, or of any
officer authorised in this behalf, by general or special order, by such Government.

60. Cognizance of offences —No court shall take cognizance of an offence under

this Act except on a complaint made by—

(a) the National Authority, the State Authority, the Central Government, the
State Government, the District Authority or any other authority or officer
authorised in this behalf by that Authority or Government, as the case may
be; or

(b) any person who has given notice of not less than thirty days in the manner
prescribed, of the alleged offence and his intention to make a complaint to
the National Authority, the State Authority, the Central Government, the
State Government, the District Authority or any other authority or officer
authorised as aforesaid.

કિ. Section 188 in the Indian Penal Code, 1860

188. Disobedience to order duly promulgated by public servant.—Whoever,
knowing that, by an order promulgated by a public servant lawfully empowered to
promulgate such order, he is directed to abstain from a certain act, or to take certain

6

<!-- page 8 -->

order with certain property in his possession or under his management, disobeys such
direction, shall, if such disobedience causes or tends to cause obstruction, annoyance or
injury, or risk of obstruction, annoyance or injury, to any person lawfully employed, be
punished with simple imprisonment for a term which may extend to one month or with
fine which may extend to two hundred rupees, or with both; and if such disobedience
causes or trends to cause danger to human life, health or safety, or causes or tends to
cause a riot or affray, shall be punished with imprisonment of either description for a
term which may extend to six months, or with fine which may extend to one thousand
rupees, or with both.

Explanation—it is not necessary that the offender should intend to produce

harm, or contemplate his disobedience as likely to produce harm. It is sufficient

that he knows of the order which he disobeys, and that his disobedience

produces, or is likely to produce, harm.

Illustration

An order is promulgated by a public servant lawfully empowered to promulgate

such order, directing that a religious procession shall not pass down a certain

street. A knowingly disobeys the order, and thereby causes danger of riot. A has

committed the offence defined in this section.

wake
7
