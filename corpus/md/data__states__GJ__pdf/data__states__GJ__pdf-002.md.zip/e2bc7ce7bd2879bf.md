---
doc_id: "e2bc7ce7bd2879bf"
source_url: "https://bknmu.edu.in/uploads/assest/circular-79-2026-culturalcell10282026060049047.pdf"
ministry: "Bhakta Kavi Narsinh Maheta University, Gujarat"
title: "શ્રી સરદાર વલ્લભભાઈ પટેલની જન્મજયંતી નિમિત્તે વિવિધ કાર્યક્રમોના આયોજન બાબત.      28/10/2026 (Cultural Cell)"
date: ""
pages: 1
method: "tesseract:guj+eng"
script: "GUJARATI"
needs_ocr: false
sha1: "3d48e4ad33147e6e"
---

<!-- page 1 -->

જ BHAKTA KAVI NARSINH MEHTA UNIVERSITY, JUNAGADH
છું Far te હે {Gujarat Public Universities Act No. 15/2023]
A ¢ લ યિ Government Polytechnic Campus, Bhakta Kavi Narsinh Mehta University Road,
pide | Khadiya, Junagadh+362263 (Gujarat) |
સ મે Ph: 0285-2681400 @ : www.bknmu.edu.in || (4 registrar@bknmu.edu.in
ક્રમાંક:બીકેએનએમયુ/કલ્યરલ સેલ/૭૯/ર૦ર૬ તા. ૨૮/૧૦/ર૦ર૬
વિષય :- શ્રી સરદાર વલ્લભભાઈ પટેલની જન્મજયંતી નિમિત્તે વિવિધ કાર્યક્રમોના આયોજન બાબત.
સંદર્ભ :- અધિક મુખ્યસચિવશ્રી, ઉચ્ચ શિક્ષણના અધ્યક્ષ સ્થાને તા. ર૭-૧૦-ર૦ર૬ન। રોજ મળેલ ઓનલાઈન બેઠક
પરીપત્ર :-
A ન. ૯? .
ભક્તકવિ નરસિંહ મહેતા | apa ।ચાર્યશ્રીઓ તેમજ માન્ય સંસ્થાઓના
વડાશ્રીઓને જણાવવામા અજ મ. સાર dell eer ai નિમિત્તે વિવિધ કાર્યક્રમોના
jj it > get ય
આયોજન બાબતે અધિ tate y Gay શિક્ષણના અધ્યક્ષ સ્થાને વે! જ ક રવ રહના#રોજ મળેલ ઓનલાઈન
ક દ મ es” : iw | j
બેઠકમાં થયેલ ea કેર નીયે મુજબની વિંગતેઝ્કાર્યક્રમોનું ,આ જન કર જણાવવામા આવ્યું છે.
યુનિવર્સિટી સંલઃ મે વિવિકોલેજોના આ welled dae ue we રોના વકાક્ીએ ન લેવલ પર દર્શાવેલ
કાર્યક્રમોનું. wedi (33 ઓકટોબરે, રબર દેરમ્ધાન કરવાનું રે શે. ays કાર્યકમન અહેવાલ તેમ ૪ ફોટોગ્રાફી
કલ્યરલ સેલા મેઇવ એડ્સપર : દતો છાઉજા 34 ai (છપ sito આપવાના રહેશે.
કમ. oy Wy
કટિ dll ee /
> uses (CAS an |
we ee
> રાષીય એકતા યાત્રા ન્ડ હક્ક, Ny [77
ર. ન દિ yy હહ noc
> dc \\ Wwe ee
an (કક Wy wy / કે
>. (Oe Pye VANS <I 7 \ a
> silo ryt 5 ઝુ સસ \
a કા સાયા કાર રા ઊડા દિ. દ પ. _
ઝે. શોર્ટ ફિ /ડોકયુંપ્રેન્ટરી _ me at :
> le 4 ાઇાઇઃ —_ 4 \ પ Ke શ
 »ે નિષ્ણાંત 1 wig JUN, IGADY, ક.”
ઝે કાર્યક્રમનું જીવ પાસ ન કુલસચિવ *
oe *
પતિ તાઈ ડિ
૧) યુનિવર્સિટી સંલગ્ન વિવિધ કોલેજોન! આચાર્યશ્રીઓ
ર) માન્ય સંસ્થાઓના વડાશ્રીઓ
ન નકલ સાદર રવાના :- :
માન. કુલપતિશ્રી/ કુલસચિવશ્રીના અંગત સચિવશ્રી
