---
doc_id: "faa5cca2ac48a90e"
source_url: "https://gnlu.ac.in//Content/gnlu/pdf/press-notes/press-note-57-2016.pdf"
ministry: "Gujarat National Law University, Gujarat"
title: "GNLU organizes Two-day Training Course on 'Babies crossing Borders - Surrogacy, Laws and Practice"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "aa4927cd14272dbe"
---

<!-- page 1 -->

G u j a ra t N a ti on a l La w U n i versi ty
Gandhinagar, Gujarat, India
Gandhinagar, Friday, September 30, 2016

GNLU PRESS NOTE
No. 57/2016
GNLU organizes Two-day Training Course on “Babies crossing Borders –
Surrogacy, Laws and Practice”
Dear Sir/Madam,
Greetings from GNLU!
Gujarat National Law University (GNLU) being a Research Based Teaching University with its
commitment to provide world class legal education and all round development of the students,
faculty and other professionals, offers various training programmes, workshops and courses in
different areas of law and allied fields. Towards this initiative, GNLU Centre for Private
International Law (GCPrIL), in collaboration with Malhotra & Malhotra Associates (International
Lawyers), in the light of the recent issue of Cabinet’s approval for introduction of the ‘Surrogacy
(Regulation) Bill, 2016’ is organizing a training course on “Babies crossing Borders – Surrogacy,
Laws and Practice” on 30 September – 01 October, 2016.
The Course has received an overwhelming response of 65 participants, 52 being external
participants from institutes like IIT Bombay; Samarpan School of Law, Gandhinagar; Amity Law
School, Delhi; R N Patel Ipcowala School of Law & Justice, Anand; Jagran Lakecity University,
Bhopal; Yashwantrao Chavan Law College, Pune; Faculty of Law, JLB School of Legal Studies,
Banasthali Vidyapith, Rajasthan; Faculty of Law, M. S. University, Baroda to name a few.
The Resource Persons for this training course includes Mr. Anil Malhotra, from Malhotra &
Malhotra Associates (International Lawyers), a practising Advocate in India since September 1983;
Mr. Ranjit Malhotra, from Malhotra & Malhotra Associates (International Lawyers), the first Indian
lawyer to be awarded the prestigious Felix Scholarship to read for the LLM Degree at the School
of Oriental and African Studies, University of London; Dr. Nayna Patel, Medical Director,
Akanksha Hospital and Research Institute,; and Ms. Heena Goswami, Assistant Professor of
Science and Technology, GNLU.

Attalika Avenue, Knowledge Corridor, Koba, Gandhinagar, Gujarat, India – 382007
Ph: +91-79-23276611/12,Fax:+91-79-23276613, Email: contact@gnlu.ac.in, Website: www.gnlu.ac.in

<!-- page 2 -->

G u j a ra t N a ti on a l La w U n i versi ty
Gandhinagar, Gujarat, India
This course also provides an internship opportunity whereby the first rank holder among the
students participants of the course shall get an opportunity to intern at Malhotra & Malhotra
Associates (International Lawyers) provided the winner is either a 3rd year, 4th year or a 5th year
student of the Five Year LL.B. programme or a 2nd year or 3rd year student of the Three
Year LL.B. programme.
The aim of the course is to explore the interface between Private International Law and
Surrogacy. Since surrogacy has become an increasingly popular method of reproductive
technology. With no harmonized Private International Law regulation on surrogacy per se, the
courts of any country deciding on the social legal issues connected with cross border surrogacy
are posed with difficulty to ascertain the questions of which law governs various legal issues
arising in connection with such cross-border relationship. The Private International Law issues
surrounding the status of children, including issues arising from international surrogacy
arrangements remains a source of worry for Courts and Legislatures.
This course examines Private International Law aspects of international surrogacy arrangements.
The course also addresses ethical questions surrounding surrogacy. The course will focus on legal
development and issues of Surrogacy in Indian Private International Law. The course adopts the
comparative teaching methodology to discuss developments in various jurisdictions on Cross
border Surrogacy. The Course will also discuss the recent Surrogacy (Regulation) Bill, 2016.
For any further information, please contact Mr. Soaham Bajpai, Assistant Professor – Research,
GNLU, at 8128650845 or sbajpai@gnlu.ac.in.

Attalika Avenue, Knowledge Corridor, Koba, Gandhinagar, Gujarat, India – 382007
Ph: +91-79-23276611/12,Fax:+91-79-23276613, Email: contact@gnlu.ac.in, Website: www.gnlu.ac.in
