---
doc_id: "8c405aafe671efec"
source_url: "https://panchayat.gujarat.gov.in/panchayat/documents/Notification-11-08-23.pdf"
ministry: "Panchayats and Rural Housing Department, Gujarat"
title: ""
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bfe0742e4c239e2a"
---

<!-- page 1 -->

Extra No. 31

©
The Gujarat Government Gazette
EXTRAORDINARY
PUBLISHED BY AUTHORITY
Vol. LXIV ]

FRIDAY, AUGUST 18, 2023 / SRAVANA 27, 1945

Separate paging is given to this part in order that it may be filed as a Separate Compilation.
PART I-A
CENTRAL SECTION
Orders and Notifications (Other than those published in Part IV-B)
under the Gujarat Local Boards, Village Panchayats, Municipal
Boroughs, District Municipal, Primary Education and Local Fund Audit Acts.

PANCHAYATS, RURAL HOUSING AND RURAL DEVELOPMENT DEPARTMENT
NOTIFICATION
Sachivalaya, Gandhinagar, 11th August, 2023.
GUJARAT PANCHAYATS ACT, 1993.
No. KP/37 of 2023/PRHRDD/MSM/e-file/14/2022/0760/KH:- In exercise of the powers conferred by sub-section
(5) of section 227 read with sub-section (5) of section 274 of the Gujarat Panchayats Act, 1993 (Guj.18 of 1993), the
Government of Gujarat hereby makes the following rules to provide for regulating the conditions of service of persons
directly recruited to the post of Research Assistant, Class III in the Superior Panchayat Service, in so far as they relate
to the Pre-Service Training and Post-training examination, namely:1.

Short title, commencement and extent.1.

These rules may be called the Research Assistant, Class III, in the Superior Panchayat Service
(Pre-service Training and Post-training Examination) Rules, 2023.

2.

They shall come into force from the date of their publication in the Official Gazette.

3.

Notwithstanding anything contained in any other rules governing appointment to the post of Research
Assistant, Class III, in the Superior Panchayat Service, these rules shall apply to the persons directly
recruited as Research Assistant, Class III, in the Superior Panchayat Services otherwise than by
promotion from a lower post.

I-A Ex.-31

31-1

<!-- page 2 -->

31-2
2.

GUJARAT GOVERNMENT GAZETTE, EX., 18-08-2023

[ PART I-A

Definitions.In these rules, unless the context otherwise requires:-

3.

(a)

“Appendix” means the Appendix appended to these rules;

(b)

“Contractual Post” means post of the Research Assistant, Class III, in the Superior Panchayat
Service on which direct recruits are appointed on the contractual basis;

(c)

“Development Commissioner” means the Development Commissioner, Gujarat State;

(d)

“Direct recruit” means a person appointed on the contractual basis on the post of Research Assistant,
Class III, in the Superior Panchayat Service in accordance with the provisions of Research Assistant,
Class III, in the Superior Panchayat Service Recruitment Rules, 2016;

(e)

“Institute” means the Panchayati Raj Training centers as specified in Appendix I;

(f)

“Examination” means Post-training Examination conducted by the Development Commissioner;

(g)

“Specified chances” means the number of chances specified in these rules within which a person is
required to pass the post-training examination;

(h)

“Specified period” means the period specified in these rules within which a person is required to
pass the post- training examination.

Institutional Training and examination.-Every direct recruits shall be required to undergo institutional training in the institute and pass the examination
conducted by the Development Commissioner in accordance with the following provisions, namely: -

4.

5.

(1)

The institutional training shall be for a period of Two Months. This training shall be imparted by the
institutes as shown in Appendix l.

(2)

The direct recruits shall be under the control of respective institutes as specified in Appendix-I during the
period of their Institutional training.

(3)

The examination shall be conducted by the Development Commissioner after the institutional training
period is over. The direct recruits who have completed the institutional training program shall be required
to pass the post-training examination. After completion of the institutional training, the direct recruits
shall be required to work in their respective offices, until their examination.

Eligibility to appear in examination. -(1)

In order to qualify for appearing at the examination, a direct recruit shall be required to attend a minimum
of 85% of the total number of lectures in the institutional training otherwise he shall be disqualified for
appearing in the examination and his service shall be liable to be terminated from his contractual
appointment.

(2)

During the period of institutional training, a direct recruit shall not be allowed any type of leave or
absence for more than three days. If the direct recruit remains absent for more than three days and the
principal of the Institute is satisfied that his absence is not due to any unavoidable circumstances beyond
his control, he may allow the direct recruit subject to the deduction of the pay for the days of his absence,
for appearing in the Post-training Examination.

Chances for passing examination.(1)

The direct recruit shall be required to pass the examination within maximum three chances during
their contractual period:
Provided that a person belonging to the Scheduled Castes or Scheduled Tribes who is unable to pass
the examination within three chances, shall be allowed one additional chance which shall have to be
availed of within a period of one year from the date of declaration of the result of the examination of his
third chance.

(2)

If a direct recruit fails to pass the examination within the specified period and specified chances as
required under these rules, his service shall be terminated:

<!-- page 3 -->

CENTRAL SECTION ]

GUJARAT GOVERNMENT GAZETTE, EX., 18-08-2023

31-3

Provided that, if the State Government is satisfied that a person could not pass the examination
within the specified period and specified chances for the reasons beyond his control, it may, after
recording reasons in writing allow him not more than two additional chances to pass such examination on
payment of such examination fees as may be determined by the Government from time to time:
Provided further that, if a person passes the examination after availing the additional chances, he
shall not be entitled to claim seniority over those persons who have passed such examination earlier than
him within the specified chances and specified period.

6.

7.

(3)

In the circumstances mentioned in sub-rule (1) and sub-rule (2) above, if the examinations are not
conducted in time or result thereof can not be declared before the contractual period of the direct recruits
is over, his contractual period shall be deemed to have been extended till the declaration of the result of
the examination of the last additional chance avail to him.

(4)

Not appearing in the examination shall be considered as a chance.

Standard for passing the examination.(1)

The standard for passing the examination shall be of fifty percent (50%) of the total marks assigned to
each paper.

(2)

An unsuccessful candidate who secures fifty percent (50%) or more marks in one or more papers shall be
exempted from appearing in that or those papers at the subsequent examinations.

(3)

If the candidate has obtained less than fifty marks in any one paper out of four papers and secures fifty or
more than fifty marks in three other papers, in such circumstance, maximum five (5) gracing marks shall
be given and he shall be declared pass in the examination.

Scheme of examination.(1)

The post-training examination shall consist of four papers. Each paper shall be of 100 (one hundred) marks.
The syllabus of each paper shall be as specified in Appendix II.

(2)

The Examination shall consist of Multiple Choice Questions (MCQS).

(3)

The candidate shall be allowed to answer the entire subject of Papers 1 to 4 with the help of books.

Explanation: - “With books” means original book of the subject approved by the Government or the Institute
from time to time which includes bare Acts and / or rules without any commentaries or case laws and includes
manuals issued under the Act published by the Government of Gujarat.
8.

Books for institutional training and examination.The Institute shall provide books for institutional training and examination to the direct recruits without
obtaining any security deposit during their institutional training in the Institute. The direct recruits shall be
required to return the books as soon as the examination is over. In case of their loss or damage, the price of the
books shall be recovered from the direct recruits by the Institute.

9.

Prohibition to use certain device in the examination hall.No direct recruit shall be allowed to carry with him any type of electronic communication devices like cellular
phone, laptop, or I - pad etc. in the examination hall.

10.

Publication of result.The Development Commissioner shall declare the result of the examination and shall submit the same to the
Government. The Government shall publish the same in the Official Gazette.

11.

Security and Surety Bond.Every direct recruit shall be required to execute a bond in the form as specified in Appendix III.

12.

Miscellaneous Provisions.(1)

The Development Commissioner is entitled to change or alter the schedule of Institutional training
and/or examination as per the prevailing circumstances.

<!-- page 4 -->

31-4

GUJARAT GOVERNMENT GAZETTE, EX., 18-08-2023
(2)

[ PART I-A

The direct recruit shall not be entitled to claim any travelling allowance for the journey performed by him
to attend institutional training and/or to appear in the examination.
APPENDIX I
(See rule 3)

Sr. No.

Details of Panchayati Raj Training Centers

1

Panchayati Raj Training Center, Sadara, Dist. Gandhinagar

2

Panchayati Raj Training Center, Sanosara, Dist. Bhavnagar.

3

Panchayati Raj Training Center, Samoda- Ganvada, Tal. Siddhpur, Dist. Patan

4

Panchayati Raj Training Center, Bardoli, Dist. Surat

5

State Rural Development and Panchayati Raj Bhavan, Shashikunj, Dist. Junagadh

6

Regional Training Center, Shashikunj, Dist. Junagadh

7

B. V. Maheta Panchayati Raj Training Center, Shashikunj, Dist. Junagadh

8

Panchayati Raj Regional Training Center, Bhadra Office, Pani Gate, Dist. Vadodara

9

Panchayati Raj Training Center, Indira Bhavan, Sector-17, Dist. Gandhinagar
APPENDIX II
(See rule 7)

Syllabus for the pre-service training and post-training examination for the direct recruits, Research Assistant,
Class III, Superior Panchayat Service.
Paper-1 Total-100 marks, duration 3 hours, with Books, MCQS.
1.

The Gujarat Panchayats Act, 1993

2.

The Prevention of Corruption Act, 1988

3.

The Right of Persons with Disabilities Act, 2016

4.

Gujarat State Disaster Management Act, 2003

5.

Important Schemes of Government of India & Government of Gujarat

6.

Right to Information Act, 2005 (With all amendments).

7.

Departmental exam rules/Recruitment rules.

8.

Manual of Office procedure for Non-Secretariat Offices.

9.

Secretariat and field relationship.

10.

Channel of submission

Paper-2 Total-100 marks, duration 3 hours, with Books, MCQS
1.

The Gujarat Budget Manual, Part 1 & 2

2.

The Gujarat Financial Rules, 1971

3.

The Gujarat Treasury Rules, 2000

4.

Current delegation of Financial Rules

5.

Purchase of state by the Industries and Mines department

6.

Bombay Contingency Expenditure Rules, 1959

7.

Constitution of India

Paper-3 Total-100 Marks, Duration 3 hours, With Books, MCQS
1.

Provision of Panchayat & Municipality- with focus on 73 and 74 amendments.

<!-- page 5 -->

CENTRAL SECTION ]

GUJARAT GOVERNMENT GAZETTE, EX., 18-08-2023

2.

The Gujarat Panchayat Service (Conduct) Rules, 1998

3.

The Gujarat Panchayat Service (Discipline and Appeal) Rules, 1997

4.

The Gujarat Panchayat Service (Classification and recruitment) 1998

5.

The Gujarat Taluka and District Panchayats (Procedure) Rules, 1997

6.

The Gujarat Gram and Nagar Panchayats (Procedure) Rules, 1997.

7.

The Gujarat Panchayat Service Selection Board (Functions) Rules 1998

8.

The Gujarat Panchayat Service Selection Board (Consultations) Rules 1998

9.

The Gujarat District Panchayat Service Selection Committee (Functions) Rules, 1998

10.

The Gujarat District Panchayat Service Selection Committee (Consultation) Rules, 1998.

11.

The Gujarat Panchayat Service (Appointing Authorities) Rules, 1996.

12.

The Gujarat Panchayat Service (Transfer of Servants) Rules, 1995.

13.

The Gujarat Village Panchayat Election (Manner of Allotment Reserved Seats by Rotation) Rules, 1994

14.

The Gujarat Panchayat Election of President of Taluka Panchayat (Manner of Allotment of Reserved
seats of President by Rotation) Rules, 1994.

15.

The Gujarat Taluka and Panchayat President and Vice President Election Rules, 1994.

16.

The Gujarat Panchayat Election Rules, 1994.

17.

The Gujarat Village Panchayats (Up-Sarpanch) Election Rules, 1994.

18.

Gujarat Panchayats Financial Account and Budget Rules, 2010.

19.

The Gujarat Land Revenue Code, 1879 and Gujarat Land Revenue Rules, 1972.

20.

The Gujarat Gram Panchayat (Gram Sabha Meeting and Function) Rules, 1964.

21.

The Gujarat Village Panchayats Election of Sarpanch (Manner Allotment of Reserved Seats of
Sarpanch by Rotation) Rules, 1994

Paper-4 Total-100 Marks, Duration 3 hours. With Books, MCQS
1.

Statistics:Mathematical Statistics:-

2.

31-5

1.

Frequency Distribution and Measurement of Central Tendency

2.

Dispersion – Skewness

3.

Principle of Set

4.

Probability

5.

Interpolation – Extrapolation

6.

Sampling methods (Simple, stratified systematic and Cluster sampling)

7.

Correlation and Regression

8.

Time Series

9.

Index Number

10.

Vital Statistics

Economics:Principles of Economics:1.

Economics and Basic Economic Problems

<!-- page 6 -->

31-6

3.

GUJARAT GOVERNMENT GAZETTE, EX., 18-08-2023
2.

Assumption of Economic and Methods of Analysis

3.

Principle of Consumer Behavior- Choice of Utility

4.

Indifference Curve Analysis and Choice

5.

Consumer’s Surplus

6.

Elasticity of Demand

7.

Rules of Production

8.

Production Cost

9.

Supply

10.

Price Determination in Market

11.

Competition

12.

Monopoly

13.

Monopolistic Competition

14.

Principle of Allocation

15.

Pay

16.

Rent

17.

Interest

18.

Profit

19.

Point of General Equilibrium

20.

Welfare Economics

Official Statistics
1.

Central and State Statistical Organization

2.

Planning

3.

National Sample Survey

4.

Economic Census and Survey

5.

Population Census

6.

Agriculture statistics

7.

Animal Husbandry Statistics

8.

Fisheries Statistics

9.

Irrigation Statistics

10.

National Income and State Income Estimates

11.

Capital Formation

12.

Price Statistics

13.

Transport Statistics

14.

Education Statistics

15.

Industrial Statistics

16.

Statistics of Municipal Towns and cities

17.

Socio-Economic Review

18.

Statistics of Co- operative activities

[ PART I-A

<!-- page 7 -->

CENTRAL SECTION ]

GUJARAT GOVERNMENT GAZETTE, EX., 18-08-2023

19.

Evaluation Process and its various stages

20.

Health Statistics

31-7

Reference books;Paper 4: Statistics, Economic and Official Statistics
Reference books:-

Mathematical Statistics, Author:- Prof. H.D.Shah, Fifth Edition:- 1994
(Published by the University Granth Nirman Board, Gujarat State, Ahmedabad)

-

Sampling Methods and Experimental Designs, Author :- Shri S.M.Shah Edition:-1992, (Published by the
University Granth Nirman Board, Gujarat State, Ahmedabad)

-

Business Statistics, T.Y.B.Com, Edition:- 1995(Published by the University Granth Nirman Board, Gujarat
State, Ahmedabad)

-

Principles of Economics, (Price and Allocation), Author :- Shri H.K.Trivedi, Edition :- 2005 (Published by
the University Granth Nirman Board, Gujarat State, Ahmedabad)

-

Official Statistics (Prepared by the Directorate of Economics and Statistics, Gujarat State, Gandhinagar)
APPENDIX –III
(See rule 11)
SECURITY BOND

Know all men by these presents that I ……………….. a candidate selected for appointment to the post of
Research Assistant (Grade II) Class III in the Superior Panchayat Service on Contractual basis in accordance with the
provisions of the Research Assistant, Class III, in the Superior Panchayat Service Recruitment Rules, 2016 contained in
Government Notification ……………………….. Department, No. ………………………… dated the ………………
(hereinafter referred to as "the rules ) and held and firmly bound up; to the Government of Gujarat exercising the
executive power of the Governor of the State of Gujarat (hereinafter referred to as "the Government" which expression
shall, unless the context otherwise requires, include his successors in office and assigns) in the amount equal to pay and
allowances paid to me by the Government during my training plus amount prescribed by the Government from time to
time towards the cost of training Imparted to me by the institute Being an expenditure incurred by Government to my
training and which is be paid to the Government for which payment well and truly to be made I bind myself, my heirs,
executors, administrators and legal representatives by these presents ………………………... Whereas I am required
under the rules to execute a bond for refund to the Government of the amount equal to pay are usual allowance drawn
by me during the training the event of my (a) failure to complete the institutional training or (b) failure to appear in the
post- training Examination or (c) failure to comply with any of the provisions of the contractual rules, if any, to the
satisfaction of the Government, my regular appointment on satisfactory completion of the and contractual period. Now,
the condition of the above written bond is that, if, I duly and faithfully observe and perform the stipulations and
conditions on my part to be observed and performed as contained in the said rules (which rules shall be deemed to form
part of these presents), then the above written shall be void, otherwise the same shall remain in full force and effect:
Provided that without prejudice to other right or rime dies, it shall be open to the Government to recover the
amount payable under this bond as arrears of land revenue.
In witness whereof I have hereto set my hand this day …………………... of ………………………20 …………………
Signature of Candidate.
Signed and delivered by the above named in the presence of
(1)

Signature and full address.

(2)

Signature and full address

<!-- page 8 -->

31-8

GUJARAT GOVERNMENT GAZETTE, EX., 18-08-2023

[ PART I-A

SURETY
We (1) …………………………………………And (2) ………………………………. Residing at …………… in
Taluka…………District…………declare ourselves sureties for the above named………………………… (hereinafter
referred "the candidate) and guarantee that the candidate shall do and perform all that he has undertaken to do and
perform and in case of his (1) failure to complete the institutional training or (2) failure appear in the post- training
Examination, or (3) failure to comply with any of the provisions of the contractual rules, if any, to the satisfaction of the
Government, or (4) quitting service before the completion of the period of 3 years from the date of his regular
appointment on satisfactory completion of the contractual period. We hereby bind ourselves jointly and severally to
forfeit to the Government of Gujarat exercising the executive power of the Governor of State of Gujarat (hereinafter
referred to as "the Government") the amount equal to the pay and allowances paid to him by the Government during his
training plus amount prescribed by the Government from time to time onwards the cost of training imparted to him by
the institute. Being an expenditure incurred by the Government on his training in which the candidate has bound himself
and we agree that the Government may, without prejudice to other rights or remedies available to the Government
recover the said amount from us as arrears of land revenue; and we also agree that any variation of the terms and
conditions specified in the said rules will not discharge us from our liabilities to pay the said amount and for the purpose
of enforcement of our ability under this agreement, our liability will be joint and several with that of the candidate.
Dated this day of 20………… Signed and delivered by the said.
Date :

Signature of Surety

Place :

Full address and occupation

Date :

Signature of Surety

Place :

Full address and occupation

In the presence of
Signature
Full address and
Occupation of witness:
Signature
Full address and
occupation of witness:
By order and in the name of the Governor of Gujarat,
NARENDRA VAGHELA,
Deputy Secretary to Government.
----------

Signature Not Verified

Government Central Press, Gandhinagar.

Signed by:BHOLUSINGH G THAKUR
Date: 2023.09.05 14:13:23 +05:30
Reason: Validate Document
Location: Government Central Press,
Gandhinagar
