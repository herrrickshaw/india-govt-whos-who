---
doc_id: "00baa97eaf56fb0f"
source_url: "https://boiler.gujarat.gov.in/Portal/Document/5_1953_1_5_279_1_02Notification-2_2020_Final-11092020.pdf"
ministry: "Directorate of Boilers, Gujarat"
title: "(392 KB)"
date: ""
pages: 16
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "5c6749925db40d7b"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. NO. D. L.-33004/99

सी.जी.-डी.एल.-अ.-14092020-221710
xxxGIDHxxx
CG-DL-E-14092020-221710
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 445]
No. 445]

नई दिल्ली, िुक्रवार, जसतम्रर 11, 2020/भार 20, 1942
NEW DELHI, FRIDAY, SEPTEMBER 11, 2020/BHADRA 20, 1942

वाजणज्य रर उ्योगग ंं्ालय
(उ्योगग संवधधन रर आंतररक व्यापार जवभाग)
(के न्‍दरीय र्यलसध रयोगडध)
अजधसूचना
नई दिल्ली, 11 जसतंरर, 2020
सा.का.जन. 551(अ).—कजतपय जवजनयंों का जनम्नजलजखत प्रारूप, भारतीय र्यलर जवजनयं, 1950 का संियोगधन
करने के जलए, भारत के रािप्, असाधारण, भाग II, खंड 3, उप-खंड (i) ंें भारत सरकार, वाजणज्य रर उ्योगग
ंं्ालय (उ्योगग संवधधन रर आंतररक व्यापार जवभाग), (कें रीय र्यलर रयोगडध) की तारीख 21 ंई, 2020 की
अजधसूचना सा.का.जन. 343(अ) द्वारा, भारतीय र्यलर अजधजनयं, 1923 (1923 का 5) की धारा 31 उपधारा (1)
द्वारा यथा अपेजित सभी संभाव्य प्रभाजवत व्यजियों से आपजियां रर सुझाव ंांगे िाने के जलए प्रकाजित दकया गया
था ियोग इन प्रारूप जनयंों की रािप् की प्रजतयां िनसाधारण िनता कयोग उपल्‍ध कराए िाने से पतताजलस दिन की
अवजध की संाजि के पश्चात उपल्‍ध कराया गया था;
रर िरदक, उि अजधसूचना की प्रजतयां 6 िून, 2020 कयोग िनता कयोग उपल्‍ध कराई गईं थीं;
रर िरदक, उि प्रारूप जवजनयंों के संरंध ंें दकसी व्यजि से कयोगई आपजियां रर सुझाव प्राि नहीं हुए थे;
4234 GI/2020

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

अत: अर, र्यलर अजधजनयं, 1923 (1923 का 5) की धारा 28 द्वारा प्रिि िजियों का प्रययोगग करते हुए, कें रीय
र्यलसध रयोगडध, भारतीय र्यलर जवजनयं, 1950 कयोग रर संियोगधन करने के जलए जनम्नजलजखत जवजनयं रनाता है,
अथाधत् 1. संजिप्त नां रर प्रारं म्भ.-(1) इन जवजनयंों का संजिि नां भारतीय र्यलर (िूसरा संियोगधन) जवजनयं,2020 है।
(2) ये रािप् ंें उनके प्रकािन की तारीख कयोग प्रवृि होंगे।
2. भारतीय र्यलर जवजनयं, 1950 (जिसंें इसके पश्चात इसे ंूल जवजनयं कहा गया है) के जवजनयं 4, खंड (ग),
उप-खंड (vi) ंें ‘रिप्पण’ कयोग जनम्नजलजखत ‘रिप्पण’ रखा िाएगा, अथाधत-्
“रिप्पण: िर तक दक राष्‍टरीय धातु जवन पान प्रययोगगिाला या भारत हेवी इलेज रकल जलजंिेड, हैिराराि की जनगं
अनुसंधान रर जवकास प्रययोगगिाला या कें रीय र्यलर रयोगडध द्वारा ंान्‍दयता प्राप्त दकसी अन्‍दय जव्‍यात धातु िांच
प्रययोगगिाला द्वारा िेि ंें उत्पादित जंर ध धातु इस्ट्पात के रे े हुए तापंान के आंकों ों के संरहणहण हेतु क्रीप िेटिस्ट्िंग हेतु या
राष्‍टरीय रूप से ंान्‍दयता प्राप्त िांच प्रययोगगिाला से िेि से राहर उत्पादित जंर ध धातु इस्ट्पात के जलए जवजनंाधण के िेि
ंें क्रीप िेटिस्ट्िंग हेतु अंेररकन सयोगसाइिी ऑफ ंैकेजनकल इं िीजनयसध (एएसएंई) या जिरिि स्ट्ित डडध (रीएस) या यूरयोगपीय
स्ट्ितडडध (ईएन) कयोगड के अनुसार 33,000 घंिे तक िांच करने पर इस्ट्पात के इन रहणेडों कयोग स्ट्वीकार दकया िा सके गा रर
िीघाधवजध रे े हुए तापंान की जविेाता/ अ अजधकतं अनुन पेय िार गुण ियोग अंेररकन सयोगसाइिी ऑफ ंैकेजनकल
इं िीजनयसध (एएसएंई) या जिरिि स्ट्ितडडध (रीएस) या यूरयोगपीयन स्ट्ितडडध (ईएन) कयोगड ंें दिए गए हत, िैसा भी ंांला
हयोग, का उपययोगग जडिाइन के जलए दकया िाएगा, ियोग यथा लागू जनम्नजलजखत िततों  कयोग पूरा दकए िाने के अ्‍यधीन है,
अथाधत् (क) इस्ट्पात के उत्पािक द्वारा इस प्रभाव का एक प्रंाण प् प्रस्ट्तुत कर दकया गया है दक इस्ट्पात का जवजनंाधण
स्‍ती से अंेररकन सयोगसाइिी ऑफ ंैकेजनकल इं िीजनयसध (एएसएंई) या जिरिि स्ट्ितडडध (रीएस) या
यूरयोगपीयन स्ट्ितडडध (ईएन) कयोगड की अपेिा/  के अनुसार दकया गया है तादक क्रीप रप्चर अपेिा/  का
अनुपालन दकया िाना सुजनजश्चत दकया िा सके ;
(ख)

इस्ट्पात जनंाधता अपेजित प्रंाण प् प्रस्ट्तुत करता है दक इस्ट्पात रासायजनक जव‍लेाण रर कि रर रे े
हुए तापंान की यांज्क जविेाता/  िैसा दक अंेररकन सयोगसाइिी ऑफ ंैकेजनकल इं िीजनयसध
(एएसएंई) या जिरिि स्ट्ितडडध (रीएस) या यूरयोगपीयन स्ट्ितडडध (ईएन) कयोगड ंें िी गई है, िैसा भी ंांला
हयोग, के अनुरूप है;

(ग)

1000 घंिों की लघु अवजध िार-रप्चर िांच, िैसा दक नीचे जववरण दिया गया है, राष्‍टरीय धातु जवन पान
प्रययोगगिालाअप्र्‍यात इस्ट्पात जनंाधता या कें रीय र्यलर रयोगडध द्वारा ंान्‍दयता प्राप्त दकसी अन्‍दय धातु िांच
प्रययोगगिाला द्वारा इस्ट्पात संयं्ों द्वारा िेि ंें उत्पादित जंर ध धातु इस्ट्पात के रे े हुए तापंान के आंकों ों के
संरहणहण हेतु क्रीप िेटिस्ट्िंग हेतु या राष्‍टरीय स्ट्तर पर ंान्‍दयता प्राप्त अथवा प्रत्याजसत िांच प्रययोगगिाला से िेि
के राहर उत्पादित जंर ध धातु इस्ट्पात के जलए जवजनंाधण के िेि ंें क्रीप िेटिस्ट्िंग हेतु इस प्रययोगिन के जलए
दकया िाता है दक या इस्ट्पात िीधाधवजध रप्चर िार गुण या अजधकतं अनुन पेय िार गुण ियोग अंेररकन
सयोगसाइिी ऑफ ंैकेजनकल इं िीजनयसध (एएसएंई) या जिरिि स्ट्ित डडध (रीएस) या यूरयोगपीयन स्ट्ितडडध (ईएन)
कयोगड ंें दिए गए हत, िैसा भी ंांला हयोग रर राष्‍टरीय धातु जवन पान प्रययोगगिाला या इस्ट्पात संयं् द्वारा इस
संरंध ंें दिया गया एक प्रंाण प्;

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

(घ)

भारत का रािप् : असाधारण

ट्यूटिरंग या पाइटिपंग या काटिस्ट्िंग या प्लेि रहणेड के जलए इस्ट्पात के प्रत्येक रहणेड के जलए 1000 घंिे के ियोग क्रीप
रप्चर िांच स्वधस तापंान 50 जडरहणी से अजधक के तापंान पर दकए िाएंगे; िर वे भट्टी या सुपर-हीिर
ियोगन ंें हों:

(ड.)

वाल्व ंें प्रयु त फ््िगग 1000 घंिे के जलए 550 जडरहणी सेंिीरहणेड पर िांच की िानी चाजहए तथा ितध (ग)
ंें जवजनर्िधष्‍टि उपयुध त तापंान पर 1000 घंिे ंें रप्चर करने का िराव-20 प्रजतित लाइन के राि ंास्ट्िर
कवध पर जलया िा सकता है;

(च)

1000 घंिे के न्‍दयूनतं रप्चर िीवन का अनुंान है तथा ियोगनों नंूनों कयोग उपयुध त िराव रर तापंान पर
1000 घंिे कयोग िांच पर पास करना चाजहए;

(छ)

भारत ंें, इन नंूनों कयोग संरंजधत राज्य के ंु्‍य र्यलर जनरीिक रर भारत के राहर जनरीिण
प्राजधकारी द्वारा क्रंरजहत तरीके से चुना िा सकता है, तथा नंूने अधध-जन्ंधत अवस्ट्था ंें हयोग सकते हत
िैसे, लगभग 25 वगध जंंी. के फयोगज्डध रार जिन्‍दहें संगत ्‍यौरे के अनुसार हीि रीिंेंि से गुिरना हयोगगा।”

3. ंूल जवजनयंों ंें, जवजनयं 4क ंें, उप-जवजनयं (1) कयोग जनम्नजलजखत उप-जवजनयं रखा िाएगा, अथाधत् “(1) गजतजवजध के एक ऐसे िे् जिसंें वे संलग्न हत, ंें सिं प्राजधकरण, जनरीिण प्राजधकरण, जव्‍यात सांरहणी
िांच प्रययोगगिाला, जव्‍यात इस्ट्पात जनंाधता, जव्‍यात फाउन्‍दरीअफयोगिध, जव्‍यात ट्यूरअपाइप जनंाधता रर जव्‍यात
रे ंनेंि लाइफ असेसंेंि ऑगधनाइिेिन के रूप ंें ंान्‍दयता प्राप्त करने के जलए आवेिन सजचव, कें रीय र्यलसध रयोगडध,
उ्योगग संवधधन रर आंतररक व्यापार जवभाग, वाजणज्य रर उ्योगग ंं्ालय कयोग भेिा िाएगा जिसंें वह फंध ंें
लगी है।”
4. ंूल जवजनयंों ंें, जवजनयं 4ख ंें, उप-जवजनयं (4) कयोग जनम्नजलजखत उप-जवजनयं रखा िाएगा, अथाधत् “(4) ंूल्यांकन सजंजत या आकलन सजंजत, िैसा भी ंांला हयोग, इस रारे ंें संाधान हयोगने के राि दक उपजवजनयं (1) रर (2) ंें जवजनर्िधष्‍टि अपेिाएं पूरी की गई हत, ंान्‍दयता िेने अथवा न िेने की जसफाररि के जलए
सिस्ट्य सजचव, कें रीय र्यलर रयोगडध कयोग ररपयोगिध प्रस्ट्तुत करे गी।”
5. ंूल जवजनयं ंें, जवजनयं 4ग कयोग जनम्नजलजखत जवजनयं रखा िाएगा, अथाधत् “4 ग. सिं प्राजधकरण, जनरीिण प्राजधकरणों के रूप ंें फंध कयोग ंान्‍दयता िेना ंूल्यांकन सजंजत या आकलन सजंजत, िैसा भी ंांला हयोग, की ररपयोगिध की िांच करके सिस्ट्य सजचव, कें रीय र्यलसध
रयोगडध दकसी फंध कयोग दक्रयाकलाप के िे् ंें लागू प्रप्ों (प्रप् XVI-क से XVI-झ) ंें से एक ंें ंान्‍दयता िेने का जनणधय
कर सकती है:
परं तु अगर वह दक ंान्‍दयता कयोग अस्ट्वीकार करने का जनणधय करती है तयोग उसे आवेिक कयोग कारण सजहत इसका
जलजखत उत्तर िेना हयोगगा।”
6. ंूल जवजनयं ंें, जवजनयं 4च कयोग लयोगप दकया िाएगा।
7. ंूल जवजनयं ंें, जवजनयं 4छ ंें, उप-जवजनयं (1) कयोग जनम्नजलजखत उप-जवजनयं रखा िाएगा, अथाधत् -

3

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

“(1) ंूल्यांकन सजंजत या आकलन सजंजत के ंान्‍दयता प्रिान न करने के जनणधय से असंतुष्‍टि फंध ंान्‍दयता प्रिान
करने से ंना करने के जखलाफ अ्‍यि, कें रीय र्यलसध रयोगडध के संि जलजखत अपील फाइल कर सकती है।”
8.

ंूल जवजनंयों ंें, जवजनयं 4ि ंें, उप-जवजनयं (7) क ंें, खंड (ii) कयोग जनम्नजलजख खंड रखा िाएगा, अथाधत् “(ii) कायधरत र्यलसध के जलए संरंजधत र्यलर जनरीिणालय से जनरीिण प्राजधकारी के िररए अथवा स्ट्वतं्
कायधकरण की जस्ट्थजत ंें सीधे ही जनरीिण पुजस्ट्तका न पापन की प्रजत प्राप्त की िाएगी ियोग अंजतं जनरीिण की
तारीख से एक सप्ताह के भीतर लौिाई िाएगी तादक उसंें आव‍यक प्रजवजटिययां की िा सकें ।”

9.

ंूल जवजनयं ंें, जवजनयं 5 ंें, उप-जवजनयं (ii) ंें ि्‍ि ‘ंु्‍य जनरीिक’ ि्‍ि िहां भी आए हत, उन्‍दहें ‘जनरीिण
प्राजधकारी’ ि्‍ि रखे िाएंगे।”

10. ंूल जवजनयंों ंें, जवजनयं 290 ंें, खंड (क) ंें “सभी चेस्ट्ि रर दफिंिं्‍स ..... से िुरू हयोगने वाले रर
“…….जिसके जलए उन्‍दहें रनाया गया है” से संाि हयोगने वाले ि्‍िों कयोग जनम्नजलजखत ि्‍ि रखे िाएंग,े अथाधत् “सभी चेस्ट्ि रर दफिंिं्‍स सही, ंिरूत रर दकसी भी खांी, िरार या अन्‍दय खरारी के जरना होंगी तथा इनके
पूरा हयोगने के राि चेस्ट्ि कयोग उस संचालनरत वाल्व के जलए अनुंेय अजधकतं कायधिील िराव के डेे  गुना िराव पर
हाइर्जलक रूप से िांचा िाएगा जिसके जलए उन्‍दहें रनाया गया है।”
11. ंूल जवजनयं ंें जवजनयं 361 के स्ट्थान पर जनम्नजलजखत जवजनयं रखा िाएगा, अथाधत् “361. र्ि रेंड्स - पाइप रेंड पर दकसी भी संय व्ल की न्‍दयूनतं ंयोगिाई जनम्नजलजखत ंें से दकसी एक तरीके से
नांत: (क) रर (ख) से जनधाधररत की िाएगी, अथाधत् (क) (क) तैयार रेंड ंें दकसी भी संय व्ल की न्‍दयूनतं ंयोगिाई जवजनयं 350 ंें दिए गए सू् 91 अथवा 91क
ंें अपेजित ंयोगिाई से कं नहीं हयोगगी।
(ख) जवजनंाधण प्रदक्रया के आधार पर रेंड जथटिनंग अलाउं स कयोग चुना िाएगा तादक रेंटिडंग के राि न्‍दयूनतं
ंयोगिाई की आव‍यकता कयोग सुजनजश्चत दकया िा सके ।
(ग) इस प्रकार चुने गए रेंड जथटिनंग अलाउं स कयोग अंजतं उत्पाि पर कयोगई भी हाजनकारक प्रभाव डाले जरना
पाइप की पररजध के क्र्स से िन के सभी जहस्ट्सों ंें उपल्‍ध कराया िाना है।
(ख) रेंटिडंग के राि इसके तैयार रूप ंें रेंड की अपेजित न्‍दयूनतं ंयोगिाई tm संीकरण (i) या (ii) के अनुसार
जनधाधररत की िाएगी, अथाधत् -

tm =

PxD

+C [संीकरण (i)]

2 x (f x e / I)+P

tm =

Pxd
2 x (f x e/I)-P

+C [संीकरण (ii)]

िर गणना का आधार राहरी
व्यास ‘D’ है।

िर गणना का आधार आंतररक
व्यास ‘d’ है।

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

भारत का रािप् : असाधारण

िहां, tm =रेंड के व्ल की न्‍दयूनतं ंयोगिाई जं.ंी. ंें,
P = अजधकतं कायधिील िराव दकरहणा./वगध सेंंी.,
D=

पाइप का राहरी व्यास जंंी. ंें,

d = पाइप का आंतररक व्यास जंंी. ंें,
f = जवजनयं 271 के तहत अनुंय
े िराव दक.रहणा.अवगध सेंंी.,
e = ििता कारक,
= सींलेस रर अ्‍याय II की अपेिा/  कयोग पूरा करते हुए इलेज रक रे जिस्ट्िेंस वेजल्डड स्ट्िील
पाइप्स रर इलेज रक ्यूिन वेजल्डड स्ट्िील पाइप्स के जलए 1.0 जिसंें वेल्ड पूरी तरह से
रे जडययोगरहणा्ड है अथवा अल्रास्जनक रूप से िांचा गया है,
= अ्‍याय II की अपेिा/  कयोग पूरा करते हुए इलेज रक ्यूिन वेजल्डड स्ट्िील पाइप्स के जलए
0.95,
= 22 जंंी. तक के t के गुण (पाइप की न्‍दयूनतं ंयोगिाई) के जलए वेजल्डड स्ट्िील पाइप के
जलए 0.90 ,
= 22 जंंी. से अजधक रर 29 जंंी. तक के t के गुण (पाइप की न्‍दयूनतं ंयोगिाई) के जलए
वेजल्डड स्ट्िील पाइप के जलए 0.85,
= 29 जंंी. के ऊपर t के गुण (पाइप की न्‍दयूनतं ंयोगिाई) के जलए वेजल्डड स्ट्िील पाइप के
जलए 0.80,
C = 0.75 जंंी.
I = [4x (R/D)-1]

{ इनरेडयोगस ंें (रेंड के अंिर)},

[4x (R/D)-2]
= [4x (R/D)+1]

{ ए सरेडयोगस ंें (रेंड के राहर)},

[4x (R/D)+2]
= 1.0

{ रेंड सेंिर लाइन की साइड व्ल पर},

िहां, R = पाइप रेंड का रेंड अधध-व्यास जंंी. ंें (नीचे जच् िेख)ें ,
D = पाइप का राहरी व्यास
(क) इं रेडयोगस से ए सरेडयोगस रर रेंड के अंत तक ंयोगिाई ंें धीरे -धीरे रिलाव हयोगगा।
(ख) ऊपर गणना न्‍दयूनतं ंयोगिाई आव‍यकता तैयार रेंड की ए सरेडयोगस, इं रेडयोगस रर रेंड सेंिर लाइन ंें पूरी
हयोगनी चाजहए (नीचे जच् िेख)ें ।

5

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(ग) रेंड्स के अंत ंें न्‍दयूनतं ंयोगिाई जवजनयं 350 ंें दिए गए संीकरण 91 अथवा 91क की अपेिा/  से
कं नहीं हयोगगी।
(घ) जवजनंाधण प्रदक्रया के आधार पर रेंड जथटिनंग अलाउं स कयोग चुना िाएगा तादक रेंटिडंग के राि न्‍दयू नतं
ंयोगिाई की आव‍यकता कयोग सुजनजश्चत दकया िा सके ।

.”.
12. ंूल जवजनयं ंें, जवजनयं 381 ंें उप-जवजनयं (1) ंें, खंड (ख) कयोग, जनम्नजलजखत खंड रखे िाएंग,े अथाधत् “(ख) ंु्‍य जनरीिक द्वारा प्रयु त दकए िाने वाली दकसी भी जववेकाधीन अजधकार के अधीन, वह प्रप्- II रर
प्रप्-III ंें जनरीिण प्राजधकारी द्वारा यथा प्रंाजणत र्यलर के अनुंत वर्कग ग प्रेिर कयोग स्ट्वीकार करे गा रर
र्यलर का जनरीिण करने के राि, जवजनयं 379 की अपेिा/  के अनुसार इसका हाइर्जलक रूप से िांच करे गा
रर हाइर्जलक िांच के राि प्रप्-V ंें धारा 9 के तहत एक अंजतं आिेि िारी दकया िाएगा।
(खक) यदि खंड (ख) के अंतगधत जवजनर्िधटिय अनंजतं आिेि की अपेिाएं पूरी नहीं हयोगती, तयोग इसके प‍चात् जरना दकसी
जनरीिण रर फीस के भुगतान के , अगले छ: ंहीने की अवजध के जलए नए अनंजतं आिेि िारी दकए िाएंगे ियोग
पहले अनंजतं आिेि िारी हयोगने की तारीख से अजधकतं 12 ंाह की कु ल अवजध से अजधक नहीं हयोगना चाजहए।”
13. ंूल जवजनयंों ंें, जवजनयं 382 के खंड (क) की राज्यों रर संघ राज्य िे्ों की सूची ंें (क) जहंाचल प्रिेि रर उससे संरंजधत प्रजवजटिय के राि, जनम्नजलजखत प्रजवजटिय अंत:स्ट्थाजपत दकया िाएगा, अथाधत् “िम्ंू रर क‍ंीर

िेके।”;

(2) ल कािीव, जंजनकयोगय रर अजंजनदिजव द्वीपसंूह रर उससे संरंजधत प्रजवजटिय के पश्चात जनम्नजलजखत अंत:स्ट्थाजपत
दकया िाएगा, अथाधत् “लिृिाख एलए।”

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

भारत का रािप् : असाधारण

14.ंूल जवजनयंों ंें, जवजनयं 391-क के , खंड (क) ंें, उपखंड (ii) के पश्चात, जनम्नजलजखत उप-खंड कयोग अंत:स्ट्थाजपत
दकया िाएगा, अथाधत् “(iii) िेल िाइप वेस्ट्ि हीि र्यलसध (अनफायडध): (क) िेल िाइप वेस्ट्ि हीि र्यलसध (अनफायडध) के प्‍चीस वाध के िीवनकाल के पूरा हयोगने पर, कें रीय र्यलर रयोगडध द्वारा
अनुंयोगदित रे ंन
े ेंि लाइफ एसेसंेंि ऑगधनाइिेिन (आरएलएओ) द्वारा उसका न्न-जडस्ट्रज िवली रूप से िांच की
िाएगी।
(ख) इस तरह के र्यलसध के प्रेिर पार्टसध िैसे िेल, एंडप्लेि, स्ट्ितड पाइप का जनरीिण अल्रासयोगजनक िांच, चुंरकीय कण
िांच रर डाई पेनेरेंि िांच द्वारा दकया िाएगा।
(ग) यदि इसके पररणां कें रीय र्यलसध रयोगडध द्वारा जनधाधररत ंानकों के अनुसार स्ट्वीकायध हत, तयोग र्यलरों के िीवनकाल कयोग आगे रारह वाध की अवजध के जलए या रे ंेनेंि लाइफ एसेसंेंि ऑगधनाइिेिन द्वारा यथा-संस्ट्तुत दकसी कं
अवजध के जलए रे ाने हेत,ु ंु्‍य जनरीिकअ जनिेिक र्यलसध द्वारा एक प्रंाण प् िारी दकया िाएगा।
(घ) रे ंेनेंि लाइफ एसेसंेंि ऑगधनाइिेिन की अनुिंसा पर इस तरह के र्यलर के वर्कग ग प्रेिर कयोग कं दकया िा
सके गा।
(ङ) न्न-जडस्ट्रज िव िांच द्वारा िेा िीवन-काल का यह ंूल्यांकन उसके राि हर रारह वाध राि कें रीय र्यलसध रयोगडध
द्वारा अनुंयोगदित रे ंनेंि लाइफ एसेसंेंि ऑगधनाइिेिन (आरएलएओ) द्वारा दकया िाएगा रर ऐिेंसी ंु्‍य जनरीिकअ
जनिेिक, िैसा भी ंांला हयोग, र्यलर कायाधलय के साथ संन्‍दवय करते हुए कायध करें गी।
रिप्पण: (1) इसंें स्ट्वांी के पास ऊपर पैरा (i) या पैरा (ii) के उपरंधों का चयन करने का जवकल्प हयोगगा या पैरा (iii) के
अनुसार र्यलर के िेा िीवन-काल आकलन का जवकल्प चुनना हयोगगा।
(2) िहां भी, िेा िीवन-काल ंूल्यांकन के जलए र्यलर के न्न-जडस्ट्रज िव िांच करना संभव नहीं है, वहां
पैरा (i) या पैरा (ii) के उपारंध लागू होंगे।”;
15. ंूल जवजनयंों ंें, जवजनयं 393 के , खंड (घ) ंें, जवजनयं 385क ंें जनधाधररत ि्‍िों, अिरों रर अंकों के राि,
जनम्नजलजखत ि्‍िों, अिरों रर अंकों कयोग अंत:स्ट्थाजपत दकया िाएगा, अथाधत् “ अजधकतं 50,000 रुपए के अधीन” .
16. ंूल जवजनयंों ंें, जवजनयं 395 के खंड (ख) ंें,─
(i) उप-खंड (i) ंें “5,000 रुपए ” अिरों रर अंकों कयोग जनम्नजलजखत अिर रर अंक अंत:स्ट्थाजपत दकया िाएगा,
अथाधत् “500 रुपए” ;
(ii) उप-खंड (ii) ंें “1,000 रुपए ” अिरों रर अंकों के स्ट्थान पर, जनम्नजलजखत अिर रर अंक रखा िाएगा,
अथाधत-्
“500 रुपए”

7

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

17. ंूल जवजनयंों ंें, जवजनयं 395ग के स्ट्थान पर, जनम्नजलजखत जवजनयं रखा िाएगा, अथाधत् “395ग. व्ल्व रर ्लत्‍स के जलए जनरीिण फीस (1) 600 रुपए प्रजत जनरीिण के न्‍दयूनतं जनरीिण फीस के
अधीन वाल्व ” के जनरीिण के जलए फीस जनम्नानुसार जलया िाएगा:
(क) 25 जंंी. तक

15 रुपए प्रजत ंा्ानुपाती

(ख) 25 जंंी. से ऊपर रर 100 जंंी. तक

45 रुपए प्रजत ंा्ानुपाती

(ग) 100 जंंी से ऊपर रर 250 जंंी. तक

270 रुपए प्रजत ंा्ानुपाती

(घ) 250 जंंी. से ऊपर

720 रुपए प्रजत ंा्ानुपाती

(2)्लैन्‍दिेस के जनरीिण के जलए प्रभारण जनम्नानुसार जलया िाएगा:
(i) फ्ज्डध रर कास्ट्ि ्लैन्‍दिेस के जलए:
(क) 50 या उसके जहस्ट्से के एक रैच के जलए 25 जंंी तक रर 25 225 रुपए
जंंी सजहत
(ख) 100 या उसके जहस्ट्से के एक रैच के जलए 25 जंंी तक रर 390 रुपए
25 जंंी सजहत
(ग) 50 या उसके जहस्ट्से के एक रैच के जलए 25 जंंी से अजधक 435 रुपए
रर 50 जंंी सजहत
(घ) 25 या उसके जहस्ट्से के एक रैच के जलए 50 जंंी से अजधक 435 रुपए
रर 100 जंंी सजहत
(ड.) 10 या उसके जहस्ट्से के एक रैच के जलए 100 जंंी से

465 रुपए

अजधक रर 250 जंंी सजहत
(च) 5 या उसके जहस्ट्से के एक रैच के जलए 250 जंंी से अजधक

540 रुपए

(ii) ्लैि ्लैन्‍दिेस के जलए: फ्ज्डध रर कास्ट्ि ्लैन्‍दिेस के जलए ली िाने वाली िर से आधा प्रभाररत
जलया िाएगा।”
18. ंूल जवजनयं ंें, जवजनयं 395-छ के स्ट्थान पर जनम्नजलजखत जवजनयं रखा िाएगा, अथाधत् “395छ. पुितों  रर र्यलर घिकों के जलए जनरीिण फीस– (1) सभी प्रकार के क्इल, अथाधत,् इकयोगनयोगंाइिर
क्इल्स, सुपरहीिर क्इल्स, ररहीिर क्इल्स के जलए जनरीिण फीस, सतह िे् के आधार पर जलया िाएगा,
िैसा दक जवजनयं, 385-क ंें उपारंध दकया गया है। (2) ट्यूर रर ट्यूर-रेंड के जनरीिण के जलए 10 रुपए
प्रजत ंीिर की िर से जलया िाएगा, ियोग दक न्‍दयूनतं 500 रुपए हयोगगा।”
19. ंूल जवजनयंों ंें, जवजनयं 525 के , खंड (ड.) के पश्चात, जनम्नजलजखत खंड कयोग अंत ंें अंत:स्ट्थाजपत दकया िाएगा,
अथाधत् “(च) यदि खंड (ङ) के अंतगधत जवजनर्िधटिय अनंजतं आिेि की अपेिाएं पूरी नहीं हयोगती हत, तयोग इसके प‍चात्
जरना दकसी जनरीिण रर फीस के भुगतान के नए अनंजतं आिेि िारी दकए िाएंगे ियोग पहले अनंजतं
आिेि िारी हयोगने की तारीख से 24 ंाह की एक अजधकतं अवजध से अजधक नहीं हयोगना चाजहए।”.

<!-- page 9 -->

[भाग II—खण्ड 3(i)]

भारत का रािप् : असाधारण

20. ंूल जवजनयंों के , प्रारूप-1 ंें, “से्िी व्ल्व के अपेजित िे्” िीाध के अधीन, “सुपरहीिेड स्ट्िीं के जलए” उपिीाध के तहत, जव्ंान प्रजवजटिय के स्ट्थान पर जनम्नजलजखत प्रजवजटिय रखी िाएगी, अर अथाधत:् “

.”.

21. ंूल जवजनयंों ंें, पररजिष्‍टि-ञख के स्ट्थान पर जनम्नजलजखत रखा िाएगा, अथाधत-्
“पररजिष्‍टि ञख
[जवजनयं 376 (चचच) िेख]ें
क. के वल जनरं तर प्रदक्रया संयं् ंें प्रयु त रीस वाध तक के िीवन-काल वाले वेस्ट्ि हीि र्यलसध (फायडध)।
(1) के वल जनरं तर प्रदक्रया संयं् ंें प्रयु त 20 वाध तक के िीवन-काल वाले वेस्ट्ि हीि र्यलसध (फायडध) के जलए, 12
ंहीने संाप्त हयोगने पर तथा जवजनयं 390 ंें िी गई प्रदक्रया के अनुसार दकए गए जनरीिण की तारीख से चौरीस
ंहीने पूरे हयोगने पर रर राज्य के संरंजधत सिं व्यजि द्वारा िारी ययोग्‍यता प्रंाण-प् जंलने तथा सम्यक रूप से भरे
गए प्रारूप XIX ंें आवेिन सजहत नीचे दिए गए अनुसार प्रचालन ररक्डध से संाधान हयोगने पर रर रारह ंहीनों के
जलए संचालन की अनुन पा िी िाएगी:(क) आंकों ा अजधरहणहण प्रणाली (डीएएस) के आउिपुि से सुपरहीिर रर रीहीिर ितपरे चर ए सकिधन्‍दस के जलए
प्रचालन आंकों े या ल्ग िीि तापंान ररक्डध ंें रखे गए सुपरहीिर ितपरे चर ए सकिधन के जलए प्रचालन
आंकों े;
(ख) कारणों रर की गई कारध वाई सजहत जपछले वाध के िौरान हुए ििडाउन का ्‍यौरा;
(ग) वाध के िौरान र्यलर प्रेिर पार्टसध पर दकए गए न्न-जडस्ट्रज िव िांच के ररक्डध;
(घ) र्यलर ंें पानी की गुणवत्ता ऐसे र्यलसध की आव‍यकता/  के अनुसार है तथा गुणवत्ता के ऑन लाइन
आंकों े, आंकों ा अजधरहणहण प्रणाली (डीएएस) के िररए या संय्
ं अथवा पानी के स्रयोगत के पास रखी गई ररक्डध
ल्गरुक के िररए उपल्‍ध कराए िाते हत;
(ड.) र्यलर ट्यूर फे जलयर ररक्डध (स्ट्थान, ठीकअ प्रजतस्ट्थाजपत दकए गए ट्यू्‍स की सं्‍या.
(2) जवजनंय 390 उपरंध के अनुसार छत्तीस ंहीने की अवजध संाप्त हयोगने के राि संरंजधत सिं व्यज त द्वारा
जनरीिण दकया िाएगा।
(3) यदि प्रंाणन अवजध की संाजप्त से पहले या प्रंाणन के छ: ंहीने राि दकसी भी संय पंरह दिन या उससे ज्यािा
संय के जलए ििडाउन रहता है तयोग सिं व्यज त कयोग सम्यक रूप से सूजचत दकया िाएगा तादक उ त ििडाउन अवजध
के िौरान जनरीिण दकया िा सके ।
ख. 20 वाध तक के वेस्ट्ि हीि र्यलसध (अनफायडध) के वल जनरं तर प्रदक्रया संयं् ंे प्रयु त
(1) के वल जनरं तर प्रदक्रया संयं् ंें प्रयु त 20 वाध तक के वेस्ट्ि हीि र्यलसध (अनफायडध) कयोग, जवजनयं 390 ंें िी गई
प्रदक्रया के अनुसार राज्य ंें संरंजधत सिं व्यजि द्वारा दकए गए जनरीिण रर ययोग्‍यता प्रंाण-प् के चौरीस ंहीने
राि तथा पैरा ‘क’ ंें संचालन ररक्डध से संाधान हयोगने पर उसे चौरीस ंहीनों की एक रर अवजध के जलए संचालन की
अनुन पा िी िाएगी।
(2) जवजनयं 390 ंें िी गई व्यवस्ट्था के अनुसार अों ताजलस ंहीने की अवजध संाप्त हयोगने के राि संरंजधत सिं
व्यजि द्वारा जनरीिण दकया िाएगा। (3) यदि प्रंाणन अवजध की संाजि से पहले या प्रंाणन के छ: ंहीने रात दकसी
भी संय पंरह दिन या उससे ज्यािा संय के जलए ििडाउन रहता है तयोग सिं व्यजि कयोग सम्यक रूप से सूजचत दकया
िाएगा तादक उ त ििडाउन अवजध के िौरान जनरीिण दकया िा सके ।

9

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

ग. 20 वाध से अजधक पुराने वेस्ट्ि हीि र्यलसध (फायडध) के वल जनरं तर प्रदक्रया संयं् ंें प्रयु त।
(1) जवजनयं 390 ंें िी गई व्यवस्ट्था के अनुसार रीस वाध से अजधक पुराने र्यलर प्रजतवाध जनरीिण के अ्‍यधीन होंगे
ियोग राज्य ंें संरंजधत सिं व्यजि संाधान के अनुसार हयोग। (2) यदि र्यलर का रे ंनेंि लाइफ असेसंेंि इन जवजनयंों
के उपारंधों के अनुसार दकया िाता है रर यदि यह संाधानप्रि पाया िाता है तयोग पैरा ‘क’ ंें िी गई प्रदक्रया लागू
हयोगगी।
घ. रीस वाध से अजधक पुराने वेस्ट्ि हीि र्यलसध (अनफायडध) के वल जनरं तर प्रदक्रया संयं् ंें प्रयु त।
(1) जवजनयं 390 उपरंध के अनुसार रीस वाध से अजधक पुराने र्यलर प्रजतवाध जनरीिण के अ्‍यधीन होंगे ियोग राज्य
ंें संरंजधत सिं व्यजि संाधान के अनुसार हयोग। (2) यदि र्यलर का रे ंनेंि लाइफ असेसंेंि इन जवजनयंों के
उपारंधों के अनुसार दकया िाता है रर यदि यह संाधानप्रि पाया िाता है तयोग पैरा ‘ख’ ंें िी गई प्रदक्रया लागू हयोगगी।”
[फा.सं.पी-30011अ1अ2020-र्यलसध]
िी.एस.िी. नारायणन, सजचव, कें रीय र्यलसध रयोगडध
रिप्पण:- ंूल जवजनयं का.आ.600 दिनांक 15 जसतंरर, 1950 के द्वारा भारत के रािप् ंें प्रकाजित हुए थे रर इनंें
संियोगधन सा.का.जन. 123(अ) तारीख 17 फरवरी, 2020 के द्वारा अंजतं दकया गया था।
MINISTRY OF COMMERCE AND INDUSTRY
(Department for Promotion of Industry and Internal Trade)
(CENTRAL BOILERS BOARD)
NOTIFICATION
New Delhi, the 11th September, 2020
G.S.R. 551(E).—Whereas certain draft regulations further to amend the Indian Boiler Regulations, 1950
were published as required under sub-section (1) of section 31 of the Boilers Act, 1923 (5 of 1923) vide
notification of the Government of India, Ministry of Commerce and Industry(Department for Promotion of
Industry and Internal Trade), (Central Boilers Board) number G.S.R. 343 (E), dated the 21st May, 2020 in the
Gazette of India, Extraordinary, Part II, Section 3, Sub-Section (i) inviting objections and suggestions from all
persons likely to be affected thereby, before the expiry of the period of forty-five days from the date on which the
copies of the said Gazette notification were made available to the public;
And whereas, the copies of the said notification were made available to the public on the 6th June, 2020;
And whereas, no objections and suggestions were received from the public on the said draft regulations;
Now, therefore, in exercise of the powers conferred by section 28 of the Boilers Act, 1923 (5 of 1923),
the Central Boilers Board hereby makes the following regulations further to amend the Indian Boiler Regulations,
1950, namely:1. Short title and commencement.-- (1) These regulations may be called the Indian Boiler (Second Amendment)
Regulations, 2020.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Indian Boiler Regulations, 1950 (hereinafter referred to as the principal regulations), in regulation 4, in
clause (c), in sub- clause (vi), for the Note, the following Note shall be substituted, namely:“Note: Until 33,000 hours tests are carried out by the National Metallurgical Laboratory or Corporate Research
and Development Laboratory of Bharat Heavy Electricals Limited, Hyderabad or any other wellknown material testing laboratory recognized by the Central Boilers Board for creep testing for
collecting elevated temperature data of alloy steel produced indigenously or from a Nationally
recognized/accredited testing laboratory for creep testing in the country of manufacture for alloy
steel produced outside India, against American Society of Mechanical Engineers (ASME) or British
Standards (BS) or European Standards (EN) Code, these grades of steel may be accepted and long
time elevated temperature properties/maximum allowable stress values given in American Society

<!-- page 11 -->

[भाग II—खण्ड 3(i)]

भारत का रािप् : असाधारण

of Mechanical Engineers (ASME) or British Standards (BS) or European Standards (EN) Code, as
the case may be, used for the purpose of design subject to fulfillment of the following conditions as
applicable, namely:(a) a certificate is furnished by the producer of the steel to the effect that the steel has been
manufactured strictly in accordance with the technical requirements of the American Society of
Mechanical Engineers (ASME) or British Standards (BS) or European Standards (EN) Code to
assure that the creep rupture requirements are complied with.
(b) the steel maker furnishes the necessary certificate that the steel conforms to the chemical analysis,
room and elevated temperature mechanical properties given in American Society of Mechanical
Engineers (ASME) or British Standards (BS) or European Standards (EN) Code as the case may be.
(c) the short-term stress-rupture tests for 1000 hours as described below are carried out by National
Metallurgical Laboratory or well known steel makers or any other material testing laboratory
recognised by the Central Boilers Board for creep testing for collecting elevated temperature data of
alloy steel produced indigenously or from a Nationally recognised or accredited testing laboratory
for creep testing in the country of manufacture for alloy steel produced out side India, for the
purpose of checking whether the steel is up to the specification and also to ensure that the steel is
capable of meeting the long-term rupture stress values or maximum allowable stress values given in
American Society of Mechanical Engineers (ASME) or British Standards (BS) or European
Standards (EN) Code, as the case may be, and a certificate is given by National Metallurgical
Laboratory or steel plant to this effect.
(d)
two numbers of 1000 hour creep rupture tests shall be carried out at a temperature 50°C above the
service temperature for each grade of steel for tubing or piping or castings or plates grades; when
in furnace or in superheater zone.
(e) forging to be used in valves shall be tested at 550°C for 1000 hours and the stress to cause rupture in
1000 hours at above temperatures may be taken from the master curve corresponding to - 20 per
cent line.
(f)
a minimum rupture life of 1000 hours is expected at this stress and both the samples should pass
1000 hour tests at the stress and temperature specified in condition (e).
(g)
in India, samples may be selected at random by the Chief Inspector of Boilers of the respective
State and outside India by an Inspecting Authority, and the samples could be in the form of semifinished products, say, forged bars of about 25 mm2 which will undergo heat treatment as
prescribed by the relevant specifications .”.
3. In the principal regulations, in regulation 4A, for sub-regulation (1), the following sub-regulation shall be
substituted, namely:“(1) An application for recognition as Competent Authority, Inspecting Authority, Well-known Material
Testing Laboratory, Well-known Steel Maker, Well-known Foundry/Forge, Well-known Tube/Pipe Maker
and Well-known Remnant Life Assessment Organisation, in one of the area of activity in which they are
engaged, shall be made by a firm to the Secretary, Central Boilers Board, Department for Promotion of
Industry and Internal Trade, Ministry of Commerce and Industry.”.
4. In the principal regulations, in regulation 4B, for sub-regulation (4), the following sub-regulation shall be
substituted, namely:“(4) The Evaluation Committee or the Appraisal Committee, as the case may be, after satisfying itself that the
requirements specified in sub-regulations (1) and (2) are fulfilled, shall submit a report to Member-Secretary,
Central Boiler Board recommending either to grant or refuse recognition .”.
5. In the principal regulations, for regulation 4C, the following regulation shall be substituted, namely:“4C. Recognition of a Firm as Competent Authority, Inspecting Authorities.—
On examining the report of the Evaluation Committee or the Appraisal Committee, as the case may be, the
Member-Secretary, Central Boilers Board may issue a certificate of recognition to the applicant in one of the
Forms (Forms XVI-A to XVI-I) applicable to the area of activity:
Provided that if it is decided to refuse recognition, it shall inform the applicant in writing giving reasons
therefor.”.
6. In the principal regulations, regulation 4F shall be omitted.
7. In the principal regulations, in regulation 4G, for sub-regulation (1), the following sub-regulation shall be
substituted, namely:-

11

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

“(1) Any firm not satisfied with the reasons given by the Evaluation Committee or the Appraisal Committee
for refusing to accord recognition may file an appeal in writing to the Chairperson, Central Boilers Board,
against the refusal to grant recognition .”.
8. In the principal regulations, in regulation 4J, in sub-regulation (7) A, for clause (ii), the following clause shall be
substituted, namely:“(ii) A copy of Memorandum of Inspection Book shall be obtained from the concerned boiler inspectorate
though the Inspecting Authority or directly if working independently, for in-service boilers which shall be
returned within a period of one week from the date of completion of final inspection for making necessary
entries therein.”.
9. In the principal regulations, in regulation 5, in sub-regulation (ii), for the words “Chief Inspector”, wherever
they occur, the words “Inspecting Authority ” shall be substituted.
10. In the principal regulations, in regulation 290, in clause (a), for the words beginning with “All chests and
fittings---” and ending with “---which they are intended”, the following words shall be substituted, namely:“All chests and fittings shall be smooth, sound and free from flaws, cracks or other injurious defects
and after completion, the chests shall be hydraulically tested at minimum one and half times the maximum
allowable working pressure of the valve for which they are intended.”.
11. In the principal regulations, for regulation 361, the following regulation shall be substituted, namely:“361. Wrought Bends.─ The minimum wall thickness at any point on the pipe bend shall be determined
according to either of the following methods, namely, :(A) (a) The minimum wall thickness at any point in the finished bend shall not be less than required by
equation 91 or 91A given in regulation 350.
(b) The bend thinning allowance shall be selected based on the manufacturing process to ensure the
minimum thickness requirements after bending.
(c) The bend thinning allowance thus selected is to be provided on all parts of the cross section of the
pipe circumference without any detrimental effects on the final product.
(B)The minimum required thickness tm of a bend, after bending, in its finished form, shall be determined in
accordance with equation (i) or (ii), namely:tm =

tm =

PxD
2 x (f x e / I)+P

Pxd
2 x (f x e/I)-P

+C [ equation (i)]

When outer diameter ‘D’ is
the basis for calculation

+C [ equation (ii)]

When Inner diameter ‘d’ is
the basis for calculation

where, tm = minimum wall thickness of a bend in mm,
P = maximum working pressure in Kgs./cm²,
D =outside diameter of pipe in mm,
d = inside diameter of pipe in mm,
f = allowable stress as provided under Regulation 271 in kg/cm²,
e = efficiency factor,
= 1.0 for seamless and for electric resistance welded steel pipes and for electric fusion
welded steel pipes complying with the requirements of Chapter II in which the weld is
fully radiographed or ultrasonically tested,
= 0.95 for electric fusion welded steel pipes complying with the requirements of Chapter
II,
= 0.90 for welded steel pipes for values of t ( minimum thickness of pipe) upto and
including 22 mm,

<!-- page 13 -->

[भाग II—खण्ड 3(i)]

13

भारत का रािप् : असाधारण

= 0.85 for welded steel pipes for values of t ( minimum thickness of pipe) over 22 mm
and upto and including 29 mm,
= 0.80 for welded steel pipes for values of t( minimum thickness of pipe) over 29 mm,
C = 0.75 mm.
I = [4x (R/D)-1]
{ at the intrados (inside of bend)},
[4x (R/D)-2]
= [4x (R/D)+1]
{ at the extrados (outside of bend)},
[4x (R/D)+2]
= 1.0
{ at the side wall of the bend centre line},
Where, R = Bend radius of pipe bend in mm (see figure below),
D = outside diameter of pipe
(a) Thickness variations from the intrados to the extrados and at the ends of the bend shall be gradual.
(b) The minimum thickness requirements calculated above should be met at the extrados, intrados and
bend centre line of the finished bend (see figure below).
(c) The minimum thickness at the ends of the bends shall not be less than the requirements of equation
91 or 91A given in regulation 350.
(d) The bend thinning allowance shall be selected based on the manufacturing process to ensure the
minimum thickness requirements after bending.
.

.”.
12. In the principal regulations, in regulation 381, in sub-regulation (1), for clause (b), the following clauses shall
be substituted, namely:“(b) Subject to any discretionary power exercised by the Chief Inspector, he shall accept the permissible
working pressure of the boiler as certified by the Inspecting Authority in Form-II and Form-III and after
inspecting the boiler, the Inspector shall hydraulically test it in accordance with requirements of regulations
379 and a provisional order under section 9 in Form V shall be issued after the hydraulic test.
(ba) If the requirements of provisional order specified under clause (b) are not fulfilled, fresh provisional order
shall be issued for a maximum of another six months subject to total period of twelve months from the date
of issue of first provisional order, without any subsequent inspection and payment of fee.”.
13. In the principal regulations, in regulation 382, in clause (a), in the list of States and Union territories.─
(a) after Himachal Pradesh and entries relating thereto, the following
“Jammu and Kashmir

JK .”;

shall be inserted, namely:-

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(b) after Laccadive, Minicoy & Aminidivi Islands and entries relating thereto, the following shall be inserted,
namely:“Ladakh

LA.” .

14. In the principal regulations, in regulation 391A, in clause (a), after sub-clause (ii), the following sub-clause
shall be inserted, namely:“(iii) Shell Type Waste Heat Boilers(un-fired) :(a) Shell type waste heat boilers (unfired), on completion of a life of twenty-five years, shall be non
destructively tested by a Remnant Life Assessment Organisation approved by Central Boilers Board.
(b) Pressure parts, including, shell, endplates, stand pipes, of such boilers, shall be inspected by ultrasonic
testing, magnetic particle testing and dye penetrant testing.
(c) If results are acceptable as per the standards laid down by the Central Boilers Board, a certificate shall be
issued by the Chief Inspector or Director of Boilers, as the case may be, for extending the life of the boiler
for a further period of twelve years or such less period as recommended by the Remnant Life Assessment
Organisation.
(d) The working pressure of such boilers may be reduced on the recommendation of the Remnant Life
Assessment Organisation.
(e) The assessment or remnant life by non destructive testing shall be carried out thereafter every twelve years
by a Remnant Life Assessment Organisation approved by the Central Boilers Board and the agency shall
work in close coordination with the office of the Chief inspector or Director of Boilers, as the case may be.
Note: (1) It shall at the option of the owner to opt for the provisions of Para(i) or para (ii) above or opt for the
Remnant Life Assessment of boiler as per para (iii).
(3) Wherever, it is not possible to carry out non destructively testing of boiler for Remnant Life
Assessment, provisions of para (i) or para (ii) shall be applicable.”;
15. In the principal regulations, in regulation 393, in clause (d), after the words, figures and letter “prescribed in
regulation 385A”, the following words, letters and figures shall be inserted, namely:“ subject to a maximum of Rs. 50,000.” .
16. In the principal regulations, in regulation 395, in clause (b) ,─
(i) in sub-clause (i) for the letters and figures “Rs 5,000 ”, the following letters and figures shall be
substituted, namely:“Rs. 500” ;
(ii) in sub-clause (ii) for the letters and figures “Rs 1,000 ”, the following letters and figures shall be
substituted, namely:“Rs. 500.” .
17. In the principal regulations, for regulation 395C, the following regulation shall be substituted, namely:“395C. Inspection fee for Valves and Flanges.─ (1) Subject to a minimum inspection fee of Rs. 600 per
inspection, the fees for inspection of valves shall be charged as under:(a) Upto 25 mm
Rs. 15 per piece.
(b) Above 25 mm and upto 100 mm
Rs. 45 per piece.
(c) Above 100 mm and upto 250 mm
Rs. 270 per piece.
(d) Above 250 mm
Rs. 720 per piece.
(2) Fees for inspection of flanges shall be charged as under:(i) For forged and cast flanges:
(a) upto and including 25 mm for a batch of 50 or part thereof
Rs. 225
(b) upto and including 25 mm for a batch of 100 or part
thereof
(c) over 25 mm upto and including 50 mm for a batch of 50 or
part thereof

Rs. 390
Rs. 435

<!-- page 15 -->

[भाग II—खण्ड 3(i)]

भारत का रािप् : असाधारण

(d) over 50 mm upto and including 100 mm for a batch of 25 or Rs. 435
part thereof
(e) over 100 mm upto and including 250 mm for a batch of 10
Rs. 465
or part thereof
(f) over 250 mm for a batch of 5 or part thereof
Rs. 540
(ii) For plate flanges: The fees shall be charged at half the rate as charged for forged and cast
flanges .”.
18. In the principal regulations, for regulation 395G, the following regulation shall be substituted, namely:“395G. The inspection fee for Spares and boiler components.-(1) The inspection fee for all types of coils,
namely, economiser coils, superheater coils, reheater coils, shall be charged on the basis of surface area as
provided in regulation 385A. (2) For inspection of tube and tube-bends, the fee shall be charged at the rate
of Rs. 10 per meter subject to a minimum of Rs. 500.”.
19. In the principal regulations, in regulation 525, after clause (e) the following clause shall be inserted at the end,
namely:“ (f) If the requirements of provisional order specified under clause (e) are not fulfilled, fresh
provisional order shall be issued subject to a maximum period of twenty four months from the date of
issue of first provisional order, without any subsequent inspection and payment of fee.”.
20. In the principal regulations, in Form I, under the heading “REQUISITE AREA OF SAFETY VALVES”,
under the sub-heading “ For superheated steam”, for the existing entry, the following shall be substituted, namely:“

.”.

21. In the principal regulations, for APPENDIX JB, the following shall be substituted, namely:“APPENDIX JB
[See regulation 376(fff)]
A. Waste Heat Boilers (Fired) upto twenty years of age used exclusively in continuous process plant.
(1) For Waste Heat Boilers (Fired) up to twenty years of age used exclusively in continuous process plant, at the
expiry of twelve months and at twenty four months from the date of inspection carried out in accordance with the
procedure provided in regulation 390 and certification of fitness issued by the concerned Competent Person in the
State, and having satisfied with the operation records as given below received alongwith application in Form XIX
duly filled in shall be allowed for running for another period of twelve months:—
(a) Operation data for superheater and reheater temperature excursions from the output of Data Acquisition
System (DAS) or operation data for superheater temperature excursions maintained in the log sheet
temperature record;
(b) History of shut downs during the previous year with their causes and actions taken;
(c) Records of any Non-Destructive test carried out on the boiler pressure parts during the year;
(d) Water quality to the boiler is maintained as per the requirement of such boilers and on line data of the
quality be provided through Data Acquisition System (DAS) or through water quality record logbook
maintained at plant or at source of water;
(e)

Boiler tube failure record (location, number of tubes repaired/replaced).

(2) Inspection shall be carried out by the concerned Competent Person at the expiry of thirty six months as
provided in regulation 390.
(3) In case of shutdown of fifteen days or more any time before the expiry of certification period and after six
months of the certification, Competent Person shall be duly informed so that inspection can be scheduled during
the said shutdown period.
B. Waste Heat Boilers (Unfired) up to twenty years of age used exclusively in continuous process plant.
(1) For Waste Heat Boilers (Unfired) up to twenty years of age used exclusively in continuous process plant, at the
expiry of twenty four months from the date of inspection carried out in accordance with the procedure provided in

15

<!-- page 16 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

regulation 390 and certification of fitness by the concerned Competent Person in the State, and having satisfied
with the operation records at paragraph “A”, shall be allowed for running for another period of twenty-four
months.
(2) Inspection shall be carried out by the concerned Competent Person at the expiry of forty-eight months as
provided in regulation 390.
(3) In case of shutdown of fifteen days or more any time before the expiry of certification period and after six
months of the certification, Competent Person shall be duly informed so that inspection can be scheduled during
the said shutdown period.
C. Waste Heat Boilers (Fired) more than twenty years of age used exclusively in continuous process plant.
(1) Boiler more than twenty years of age shall continue to be subjected to inspection as provided in regulation 390
every year to the satisfaction of the concerned Competent Person in the State.
(2) If Remnant Life Assessment is carried out on the boiler as per the provisions of these regulations and is found
satisfactory, then procedure as given under paragraph 'A' shall be applicable.
D. Waste Heat Boilers (Unfired) more than twenty years of age used exclusively in continuous process
plant.
(1) Boiler more than twenty years of age shall continue to be subjected to inspection as provided in regulation 390
every year to the satisfaction of the concerned Competent Person in State.
(2) If Remnant Life Assessment is carried out on the boiler as per the provisions of these regulations and is found
satisfactory, then procedure as given under paragraph 'B' shall be applicable.”.
[F. No. P-30011/1/2020-Boilers]
T. S. G. NARAYANNEN, Secy., Central Boilers Board
Note:- The principal regulations were published in the Gazette of India, vide, number S.O. 600, dated the 15th day
of September, 1950 and last amended vide G.S.R.123(E), dated the 17th February, 2020.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. SURENDER
MAHADASAM
Digitally signed by SURENDER
MAHADASAM
Date: 2020.09.14 16:58:15 +05'30'
