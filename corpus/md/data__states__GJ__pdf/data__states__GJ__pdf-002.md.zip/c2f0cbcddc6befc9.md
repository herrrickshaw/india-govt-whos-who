---
doc_id: "c2f0cbcddc6befc9"
source_url: "https://gshrc.gujarat.gov.in/writereaddata/images/pdf/GSHRC_Rules.pdf"
ministry: "Gujarat State Human Rights Commission"
title: ""
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "25dfd6a86abe3ba7"
---

<!-- page 1 -->

+tu-l.cl. utqsur,
?nRtct ?t%rt

uutiutt

:

ruh-ru$
au6.t due tru{, {.sat-to, c[r{[4c11
r{'t3 : dquudulo?oo -tlrt&g}t

rces {r u-r.cr, ufegn +iragr uttt}rqrr-ft 4qre\ ctlae, 3ct}t te 'ft ilLt seq
tar sert (e) ,.tttt *tqe ucrtt-fi gri, tt"rq ,tt-tct ulqsu ,'tt,ti.t'tlir 3"re'tr fqFttt*ti

r.

ag

p1,ob

q,o '{I

tti &

'

ui utat , (t) u htlrt'[ .jmrd ?r%q *tr.tct u[\grt utqi.r (srd q*+td)

t4t\.t*ti ?oo 5 g&.trt\ .

?.

i, tooS qt Ril*,"ft *tf.U.[ lt tft .tf,{t'te{I r{T e1[ Utttit

t.

crttr,qt: Utr Ftq*ritl u*tqt {to[ %A?'[ gitt i Rttttt '
(d

'btfq.Frqt' taA tcce 'il. *tt't't ulQsu {taeu r'tR[\tttt,

(q) 'a4ertQt' tad l1%rt utri1.t'tl r{e4qt,
(S) '?[%rt Ut,t'[.r' rtraA ?llrttd ?t%rt ]tt-lct U[Qgtt l,ttd.t,
(s) ,t[cu1' u]aA ?t%rt r,ttd.u-u. +tc]rt rrti t*ti, ,*raad u*ttQ.tt rrtq t].
3

.

x

tt%rt urqi.rg q$ rtetg : ?t%{ .,tr.qjtti cl$ te$

easg r{rq

cultil'tctt

"ttt fUir'

: ?r%rr urd.u +uru-q tla a{ Aasi ctlt{l-tcrt "tti ur,{e[l t'tl g{{[ti "r

qiryt'r. ?,trq Ecr[, il tar4 t\{rgtu+ }t$ttt?, cJ%?tctq.i qi.tr'tl, Qag'i,, fQqttgta'ls

.rioui q'[..t ettt il 1rr4.tis r6it.
q.

qa$-ittttttoruuit: ?[%rt r,ut.t, tt[]t[dt {lA, d.tt'tl Aair, alg \ttt'tt }tP{tt e4i
dl"rr, ua.rtsl.tr,ti trtu'l [ilqr.,t .tidt ttgiu. ut]t Ectl, u.atft

.iti ut+'tu tis ] qg untit

.r.1 gittqer fq,ltrr\a i{gt.tr-[I qtqa-fi h.rrtgrt t?ctt tD, ?t%rt I'tudtu'fl bt[?t Q.as
qieu.{I turi

(i \l )ocuntonls and Sotllngs\use^Desktop\GsHRC\Legal\MPHRC

doc

qet

<!-- page 2 -->

S

.

$[tqUe{ 11gtrt :

tth.tgft, ?[%q. Utq'i.t-tt ?,ttctt ?,t-rt ]tfqgL?'[uj uftct, UarAr{l

trtt?t Uqc4t U?rq ?4p{ctt %1il ?f$tq t 3tot, ?t%q utqi.t-fl tfldt.ilrti erqrt'l r'tr'{l
rust't

e. sr,[qft: ilh.r8{I, a4arfts{l{r quqrhl tsf i ?.t%q utd.t-ft als Qas qr)-[l
srd+1h qer ii.u?. s?.ii r,ri ttFr.treq qr?[ ut dJr t.tn sQ.t-u? -iuqi qet stt't. +tudl

-titir, rurr eq'r crl gt{I, .rE r t"tcla rl.t-tl eqi. sr.[Ut\-tL qrq.iri r,tt.ttl d.[l ii.ttl.
slcft brur +rdei ?r%rr qrq'[.ri +iec.[ trr) (lqeotr sttiu. gdqt\-tt gt.tuit ua.iri als
.ftdlcr. re prqr{r Q [E.ttt q&ei, u'tr-q r.'tt qR.{hc gt.turtl ut.tit. .t?O

r{ti ttla

g-tutsfl-tr 0gr'il *tr.){ quq.ti "r {gfl gt.tt'[I dr{ qltrl Qas{t tE [t'ru q&e[ i'.tl
qrd[ t.ut g?'ti

ii qRqDt.t gtFu.ql utq{t.

. t{Iqrdrqu ft*te u)'0 h[Q.
(t) ?.r%rr r*tq'[.r tru?t si$qer rqu*rl tQetl q{l r +t't,trdri -ritl.trttl ut.tit ui i.ti

e

:

r{lg ur.t.u.}t[ Ur.ttl dp{t +u.q.t*t r'|,i. Uu &g tu) rqrftc{l q uo.ir.tl +tfqR utA i
tcr,tr.[ ctuf'ltte{I Q qa.ttslqrp{I ri131 -tg't

i {a Ai €,tl'tet E?qt tr) lrtt*tl Ut.tr't.

ntu.*r {a '{lq qr$r{er ugrit. Srot-[I +{l.trti *rr) trry.t urd.r €rrnr itd r srr[qrel
Sa..rrt[ Ur.r{[ -re1[.

(u) tR.trdr s{ q&et a.\ ts .rde{l crg n}rrr erd .tqi ei.t t.rr rst?-tt q-uqi-[l
tR,+rdt d.],.

(q) *tr.trsil-r dr,t i.fi 61otcir.
(s) ctutdl-t, Q-tr*ft u,p{qt 6qrr.{I sr}cfl dt.t il.fl +r'[,ttt'[,
(s) u{e'[-r +{htei,
(tl) i[%rr r'uq'l.r-t Er.[&rt-[I qetr dr.t idl t{I.+tei,

C:\Documents and Settingsuser\Desktop\GSHRC\Legal\MPHRC.doc

<!-- page 3 -->

irf +'[ d.1*t[ r'1.+{r -rel.

(r)

+a'[.trd1 qr]

(e)

+r'tqra-[ qrqcr-fl ri.1ei lq.r.ti aqrlqqr-ft t&ir
Sr.[qre'[ S{t rupr

ui trr,t urt.r krr?r i r,iJr uatl

t 0g{l A;t ?'iildt }rEcrr grnr..[t[ gt.rr-ft t0e'r. ?'1"]r Ecr[, +r'|..rudr

g.rt.t[iU.r t1i *rtSe erd t&

i r11), ?t%q ,,tr,+i.r, t'itltter{r ?'15q,r qQQro3q[ 11qrfq\a

s'[6qer cruqrq.l ur4atl +tlruer srpr q? Air. urfr.ir-u )srq[ +rfe s?[-u? ui.la-uttr
de{r c{g tulgcft rtu) u"r,+

urd.A qi.,r ui qt'|, errr a, {[A A qrqt dqrtt stqr qr}

. retLdl trsit.
(y) ?r?rq ,,trt.r ii qit,r erii .ti, .ri.1-tl t{{ggtQ ?4$ur?, )eflurtt tcu?r ] $su trutr
r4etl + r't.uai r{Is rt ir .
(q)

?rqfrr utqi.ri., un[{|. *t'|,r+re stdl {.["r.u-[I q$ +t*u rUtl.

(s)

+tlqtei €,tr,tct S{ qdt, Uer+Adl / ftft otft.t, il-tf e.tttt ?'tt ol,otct .1UUIU tt)
tt"tqtq.l ut.tt) uerqr i*rl .r.u?r srp{ qt.trtrl urqr] il-il Frglq gtir.

(e) els +{l.tre fqrJ, } t rrr} uerasfl rrrr?r Iurqicr r4r?r a ?,irr \ret?E srdl u.Ecrr
ctltt+t eter qt.{I

I rtD-ir Fre[q Q.tr.t errl, tth.rrer,+ dt itQa trur? / trcrutQsr?'l .nilp{l

a d.j-ir l,r&qre / t)tusft ,ti€ir *riseqr .rr) qi..r nq,rr r,lqir a,ri t .tcrrdl lEir.

k)

+ic'lttrct tt..tthgutl qrile{l la.qg[I / -[eir. ]r@u .rtft, ur ]u-u q.scr-[ qrurr"it t\ri-ft

lQ.cro.tp -riq trf.t Uuqi.r-[I lealletr r11) ii.tp. St.rrrrl a,trq{i.

(a) ?t?rq uttd.t-tr R[rri d.e{r c{er\er'i, rioit\a iltgl? / urrut\sr?'l,i crp{r qrrerri
ulQt\.ttr-tl gcr]r rc ui. rc *ti ur *tr) srqrq.i ur4e ri.r.trd U%6r %rgr u{
*ilseqr\l urqqi.

C:\Doq.un€nts and Settangsbse^Desktop\GsHRC\LegalWpHRC.doc

<!-- page 4 -->

(ro) ?r%rt utd.t .ircti d..t ?r$tq .it, A'{I utta.ft +{lqtaqt t..t {|a [\:te tt)
?4?%e[?-[ r,ter.tt

ttt .t.t[ AtIq$ ?,t*t .rtp.r-[I ] qft.tuir.fl ulctct gtr+Sft ed trgql

e*i rql ?e? %$rrr eri eg r't&.treir .ictrdli r,tu itic'iit ure{}a,il.ft .tqt{eft qet s?'[

rurl. ?r%rr ur,+i.r, +{trtug-u. }srr[, dL si6 dr{ ai, ltre[I?,it-{l h.tqtuetl ulga
.trfofl fll g-1.tgft qet Stt.{l {B{t .tqt l.-tt, 811.1. i

",rft.t-[

qteqqclct dJt-tr )SL-tt

gtr.+qt u.p{crr urq'[.r.u uldutq U?tor urdl .rtBct-tl uttqSti .1.[uu-tr gtrei er[\
.{eiq.{I dr.t c{rl q$ U-uctefi g?.t.{l rus{t.

(tt) q'lori q'[..t r*t{, ?t%rt a'tr,t.r,-[ a3s'[ eqt?t ?4Eqt ?'t-rt s'i6 qBd Ectt?t rql ctqtn
s[?r q?crrrrl qudl siq

I .1e[ tu oilA tg aU.u$.u*ri uer.rr tr%tt utt.t tg u*tt-[l

.iU{ utt e{ gt{l*ti i-ti a't0get tgctl utq.u-t'[ i.U{i. ?t%.t I'ttd.ti ri {g er.t\ }
qi..r crl.un srqr'tl qr.{l -re{I etrt {c'ih.t }+r.ri, qg dqlil s?cu. qt) qriltt g{ trg{t
?'tp{c1. ?'tt ottotdrtl UAtCt.[ q'[S+tt6 Stqt

.tf] +g ctltttt .{et St ftge,l }t?tct1 Ut qtqa-ti

qi..r fli t\Sre Strdl tUg{r. U&.tLe r1ur.tr.rtf[, ?t%q Utr,ir.r I'tt ottotctttl q'l.tri d..t

et.i i. grtuel, i.-tr. Ectr?r. oqu+t-ti qtltu qet se.'|. rugtl ui ur..{[ ctqtil €,lrltt-t gtr"+ruir
qer {ur.{l ruii.

(tr) r.trl uu+Aaft trrrtr tE"i,{I Srqt*tl ur{ eul ?t11rt utqi.t uqctt iltt-tr Ei$qer ilc}{
?ttut q?q r Urclrl.+r ttr.) SetrS[d ere{ tt{t rUir ati "6.ti

tg } te{l +g +tc*,ti €4t?t ?,tc}r1.tt

erE q?cu{ uroir dr.r e+tl ur d,j\-[ u&.rre tr?tq urd.ri tuq laei +&eir r"6
sa.qrdr. l&r1.

e. (U) tftJlct'fi3tlqdt tt'ilei r ?t%rt r,ttt.t-[ elg tfldtcr.-ft srdqLsl.ft, *ftdtct
Ath.tU-t -titr EL.tt*t[ ]tuq{t ?4e{qt flr? qdl rttct "f tQ.tafl utttt ?4e{qt Utlqt qrtt

C:\Documents and Settings\useADesktop\GSHRC\LegalrlrPHRO.doc

<!-- page 5 -->

tt.

qst ltEt Eet? gt tStt-it crtctgt? : ?[%{ utqi.t uqcil. t-tr. }aels.. ttc*.ti', I'tt
r,rtQft.r*r }at, sittqer aqrilgft-1 {ac.[q[ ir qastrii nictq.tt-tt ei.t, .ir rto+astl'{l

"r,tul Ui etrl,.1.[.iq1l erdi t[%rr Utd.u-1. ctst r1tr3.[I qet?1t rgqitl iq-[
Stq.cft{l S{[ trsit Ui e,rt.rr &O U) lt"r.t ut,+i.t-tt ,,ittstrti Uitst Q Uc-.ir.tl qietl

"lsta dt.{I "ittSqi.

ts. W*it ui |iet il4 uf4laou:
(t) ?r%rr rrut.r-tr grt ui [\e[d, 6q +r[)t.rr[I-u Ltr"rte{l .fl{ { s'[rt t.rr
(qqa+[ r4r?L ut81.r stu{a) ?r%q utt.t-tt +th.tsft }tetqL ir,6qsr u[4gr{t
trtr?r.

t uttrga stu{et ei.tu d,6{i.

(r) ?r?rq r'nqi.r Errr?r urut] fisre gtL{eL utctt }+[-u ctqtueft u&.ttair ?4etqt
gs.ri-ft -rsei ottrar.t ] iltt-u qhtlthi t\-tr1e{.1{t urs.rttt ut.ttJ.

(e) ?rQrq .'uq'[.u r4r?r ri ,,tr-r.tt ar1] .tn.trl.e Srdqer arrtu4r dt.t .ir t-[l -tse
qagliti I'tt dtt{t er{et qali qei.{l ctulc{t ttt) {sA stt{e .ttrc'[l $t'{l
ap.tqfl S{e{[ ?,ttltctt]tl Ur,.t{t. tt3rt ilaafl $sq g{[i -tSei ?,ttltctt ttD a|.1tr

tnt

!t,1+ti gf.{rtt[ Ut.+iu Ui irdqeU E*tttti, I'ttd E,t[.ft ortl"tp{l tS
r,taqtsl.tre{I .t\ {e1 qtr1 a {|A *t4 l.tr u{ttit. grqLr1l utt.t{t.

tN. qtNg U&qte :

r4[\R,r.r-[ gqq to(t) *t[ qn$tortt ]tqte] ?[Qrq .,tt.t'[.t, ?.t%rt

ttgrri qd-ft t e[ rlt\asft rq srli qd[-u .rd-t[ el '[l tr.a[ g4-u +trt{ .u)-ir i-il
q,rNS U}.tte 1"6 Sffi. l'tt Uut U&qte ?t%rt e,Uq'[.t-tu Ueetqafl Aert i.-tt tto.+i i4t?t
+tel s?.uqe eiqi "ri6{t aeu il4 d.{

C:\Doorrnents and Settings\useADesktop\GSHRC\Legal\MPHRC.doc

rli rrc.reft.{st s?..u.[I t]t\.

<!-- page 6 -->

U%ot

gifqet u.rt a't[futr'l q,t?t Er.[.tte'[ -titt ii,tur st.ttrtl r'tu.r{t. uudl -[q

uertaatli ttt-tl .iatl *rD ttigeqttl i'tuq{u ui .i"411 }ttntt qdt .r&e{l .t} ?t%tt
utd.L-u. 6trrr r uc"rii .{Rrth.r st.r,t}t[ ut.tit ui sidqer ?'|,i t|lctt ]tt[tet{[ qtft'tl
*[d[.r-ru uttc*r q]ei

ii qQqh.t St.ttttt ?'tt.tti

(q) ?r%q ur.it.r sqr?r alE quq.ri dJt Aqr{e r'u"rfl t\eh utldtut.t-tt lstaqql -ittt.ttttl
a*r.t{t. dr. ger. ger uhurqi uuq.tu*il ur"u e{i.it a qsr a.{ qtct err't} t&ir. qi i
ttrd 6qf tr,,t.rtrrl qr.rt\. t'u S,{iS Si6 't.to\A ettrt .il otg*t.{I rtldptt.r-tt rttq.tl qcuetl
d.ruttl Ut.tit.
(g)

lltloluL'tt qotqi AqL : bun utQE t grqlti -t I'ttartt du.t e{ gtil, t[lJ[ct'[l stdqrel-fl

.rt€il.\ UatAa[ &tt?1 Ugtile-t ]ttl.tctL\l Ur{ { df,t ed gt{}, tt%rt .'tUdtU'tt
+tlt.+teq t'{t?t. gi6'er qctel d.tr.ttl ut.r{i, -td[.

1.o. st [qtd[.[.[irr-ti tit{ :

tts *[ldl.cr-tl srdqtdl,.ft -[q.tl tt*a? si.fl dett ?l.%rt

,"ut.r-tt uldurqi +r[}t.1*[L r.tut urttqtcld gttrtt otta % ili. rytq.t.ttrti ut.tr't ui els

qrq.ri ecr.ft sr.[qrsl.[ dq-tl {se .it..t q.te[?,it *tD {oi[\.t +ttSeql 6tl.u*rl
a,uqr1. uldrurqi rir'it\.t lirdurrl trr+qtrtl urt.tr'i

ui +tetctscl.t qt) i{.tscit titttt

Jq.LStu,? +t[g.t .tt{ *ttSeitttl tt"t.ttttl urqi[.

1.1.. 4qr{eqoteldu&que: urctut-[I srdqrdl-u.tcLeldt.ir u&.tta flt?6tt€, tq{tl
Als q.a3-u. ur{ ?[%rr urd.ti tilseqtr1l ut.t{r r*i itti tl3 qtqd r,ic't d..tt{e
q.re[]ir-[I sLe'ft qRtirrtt qer arr[qqr.*r[ ur.tr\ ] *tr 6.{a. rt'r.t ut.ti.j, ttu 6'{?,
Ur[o[u[-r[ qcrei |t.trtt -te{}

i.fi qtq.ti l*t.tt.t, A'{l rttcuq-fl ir.6qer *[lJt.rql ?t%rt

r"ud.\ [\s[q c{t€it si.t.

C :\Documents and Settingsuser\D6sktop\GsHRC\LegattMPHRG.tloc

<!-- page 7 -->

/1"

'\

t1t.

I'tttt ot&qtei :

?t?trt ?,ttttict, ufq[i.,trt-[l gqrt fo(t) -[l tt.ir. 3?rq r,tl

ql'[

%$rq gl t-[ qtil qtq.ti qD{r ulctt l,tttt u&.ttcti tqsl.l ru0t.

19.

t{tqrdr d?rr drrnrgft r,i5t'u u0qudr :

alg u}.ue } *.i uhhqtt-fl geq lc

er$ q3 d i., tr"tr,t a,ruqi.r iltft, A.{l srdqls'l .1r'[ t,tr .{'tft a,ls ua.usl.tt\[, * si.t

A, +ic'ittct at[QErtl ]tEctt "tftai *tseqt'tl a'ttqt\ ui dc'itha il.?3t? r48{qt
ut\Sr?'t.ft Jlgr-lZtqeft r1tnie{[, ?Lqfrt ."uqi.t, .ti.t {[A %tq1 ?rqt .{tit{l r}E

ua.tusl.tr{, t sirt i, 4r utQti.r*t-ft ser te(g) ?4ercu. q,c(e) ,ti terto,tt U%bt
u&.u.e tRtur gtti.

19.

u&cue.j Uier gr,[: ?nfrr .*r,qi.r{ +tR.ue.r e$q iaatl $sqe{l .rrNg u&.tte ae{t
l'u+r r4U.tre{L UiBr srd qr} ?rqrqat? t&ri,

ui sifqer Er*tttl u u3.trei ut"t{t

tstllt r,tqtqt qdl. tj qril{l qg rtl$ Uleu st'{ grqr{ ut'trl {dl.
1,C.

cqtnefl a'io].[ a3dt :

t[Qf4 utt.t .ttil t-tt t41?1 .[*tqrtt[ au{etr datlu

r1efl\te,B-tr efry"n{l -{I{-tr -t dr,+ ati fr."6{ Utt.u .t.'tcti c3'td -tgg[ gi i U%q
?'1.c{,t r't-rt UtQgr{[r,it-[I SftrP{I

F

-[{ -t ei.t il.{l atft.t-tt ctsltgt }aq qi.tt-tl aqt+tgfl

as$l rqri. ?[%rr r'tr.irJr, u[cu. sidqgr ]ilttl, ct,ttileflgl? t'tl{ctt [il.las.tr't].tqttte[l

+rtt +it'iha dr,t l.{I qert.{I otftauii t.{ +['r,r+t*tl .{t.fl q6r't.

rc. vqrl ui *ul uu fq.ti+.tirrl ur.tr.l dq.uttl t utdl dr,t il.fl g'[6.{et qtqd (lcnft qr.t
ettl ?t%rt ,'Ud.t d.,t gs.t 3?qt tt) UArt t&t\ dert ?tg,q qttot .t"t.iu ctl,td I'ttctt

Rt\.trri{ 6{ir, te, f{+cut } gtuti st'[ lusil.
nCU-

s[.uut.de.*[I'tL

ilhq.
C:\Doqrments and Settings\use^Desktop\GSHRC\Lega[MPHRC

a

doc

<!-- page 8 -->
