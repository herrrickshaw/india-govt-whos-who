---
doc_id: "12e9f68c5aa7ddad"
source_url: "https://gmscl.gujarat.gov.in/images/pdf/0020.pdf"
ministry: "Gujarat Medical Services Corporation Limited (GMSCL), Gujarat"
title: "પરિપત્ર: ટેન્ડર નં. GMSCL/DS-15/RI-DS-10/RC/2019-20 સીક્યોરીટી ડીપોઝીટ રીફંડ બાબત"
date: ""
pages: 2
method: "pdftotext"
script: "GUJARATI"
needs_ocr: false
sha1: "5af9be9c5cc6a928"
---

<!-- page 1 -->

Letter No: GMSCL/0020/06/2024 Dt: 03-06-2024

ગુજરાત મેડીકલ સિવસીસ કોપ રે શન લીમીટે ડ
(ગુજરાત સરકારનુ સાહસ)
માંક. .એમ.એસ.સી.એલ/ડાય ો ટીક સિવસીસ/એસ-ડી રીફંડ પ રપ /૨૦૨૪-૨૫/

તા:

અગ યનું/સમયમયાદા

પ રપ :
ગુજરાત મે ડકલ સિવસીસ કોપ રે શન લી. સાથે સંકળાયેલ સવ માંગણી અિધકારીઓને જણાવવામાં આવે છે કે , અ ેની ડાય ો ટીક સવ સીસ શાખા ારા ખરીદ
કરાયેલ રીએજ ટ, કીટ અને ક યુમેબલના ખરીદ ઓડર અ વયે એને ર – એ માં દશાવેલ પેઢીઓ પાસેથી લીધેલ સી યુરીટી ડીપોઝીટની મુદત પુણ થયેલ હોવાથી
ખરીદ ઓડર સામે પેઢીઓએ ભરે લ સી યુરીટી ડપોઝીટ પરત કરવાની થાય છે . એને ર – એ માં દશાવેલ કોઇ પણ ખરીદ ઓડર સામે આપની તરફથી કોઇ ફરીયાદ હોય
તો સદર પ રપ
હે ર થયેથી દન-૦૭ માં પ રપ સાથે સામેલ ફોમામાં ઓડર વાઈઝ તમામ િવગતો ભરીને મોકલી આપવી.
આપના તરફથી સમયમયાદામાં કોઇ યુ ર ન હ મળે તો પેઢી/પેઢીઓ સામે આપને કોઇ ફરીયાદ નથી, તેમ માની સી યુરીટી ડપોઝીટ પરત કરવામાં આવશે.
િનયત સમયમયાદા બાદ સદર બાબતે ભિવ યમાં વસુલાત કે ઓ ડટ પેરા સંબિધત
ો ઉભા થશે તો તે અંગેની સઘળી જવાબદારી જે તે સંબિધત અિધકારીની રહે શે. જે
યાને લેવા િવનંતી. ખરીદ
ીયામાં સદર કામગીરીની ગંભીરતા સમ રીએજ ટ, કીટ અને ક યુમેબલના ખરીદ ઓડર અ વયે પેઢી/પેઢીઓ સામે વાંધો હોય તો સામેલ
ફોમામાં જ રી િવગતો ભરી ફોમા રજુ કરવા અથવા વાંધાસરખું ન હોય તો “ના વાંધા માણપ ” સમયસર મોકલી આપવા અને સદર બાબતે ટોચ અ તા આપવા
િવનંતી છે .
ન ધ:- આપના “ના વાંધા માણપ ” અ ેની કચેરીના e-mail jrpharma2-gmscl-gnr@gujarat.gov.in મોકલવાના રહે શે.
જનરલ મેનેજર (ડી.એસ)
ગુજરાત મે ડકલ સિવસીસ કોપ રે શન લી.
ગાંધીનગર
િબડાણ: ઉપર મુજબ.
િત,
(૧) સવ માંગણી અિધકારી ી તરફ........
(૨) અિધક િનયામક ી, આરો ય તબીબી સેવાઓ અને તબીબી િશ ણ,(તબીબી િશ ણ) ગાંધીનગર
(૩) અિધક િનયામક ી, આરો ય તબીબી સેવાઓ અને તબીબી િશ ણ,(તબીબી િવભાગ) ગાંધીનગર
(૪) અિધક િનયામક ી, આરો ય તબીબી સેવાઓ અને તબીબી િશ ણ,(આરો ય િવભાગ) ગાંધીનગર
(૫) િવભાગીય નાયબ િનયામક ી, અમદાવાદ,વડોદરા,સુરત,ભાવનગર,ગાંધીનગર,રાજકોટ.
(૬) મેનેજર( વોલીટી ક ટોલ, લો
(૭)

ટીક એ ડ સ લાય),

.એમ.એસ.સી.એલ.ગાંધીનગર

.એમ.એસ.સી.એલ. વેરહાઉસ, અમરે લી, ભુજ, દાહોદ, હ મતનગર,

મનગર, નરોડા, પાટણ,

રાજકોટ, સુરત વડોદરા,વલસાડ
(૮) મેનેજર( એમ.આઇ.એસ) તરફ પ રપ

Signature Not Verified
Signed by:Dr. Jayesh Rupala
Incharge Deputy General
Manager
Date: 2024.06.03 15:41:54
+05:30

.એમ.એસ.સી.એલની વેબ સાઈટ પર મુકવા સા .

File No: GMSCL/SDR/e-file/143/2024/0782/Diagnostic
Approved By: Incharge Deputy General Manager,Diagnostic,GMSCL

<!-- page 2 -->

Letter No: GMSCL/0020/06/2024 Dt: 03-06-2024

ગુજરાત મેડીકલ સિવસીસ કોપ રે શન લીમીટે ડ
(ગુજરાત સરકારનુ સાહસ)

એને ર –એ
T.E No.GMSCL/DS-15/RI-DS-10/RC/2019-20

Sr
No

Item
Code

1
2
3

9061
9042
9105

Eosin ready to use 2% solution
Reagent kit for prothomin time
Platelet Diluting Fluid

4

9104

WMC Diluting Fluid

5
6

9009
9015

7
8

9075
9074

Methanol
Papanicolaou stain kit ready to
use
Aceton
Immersion oil for microscopy

9
10

9014
9019

11
12
13
14

9001
9005
9081
9095

15
16

9017
9059

17

9016

Xylene(sulphur free)
Formalin(40% Formaldehyde in
water)
Brilliant Cresyl Blue
Deionised water
Fouchet Reagent
Kit for stool Occult Blood with
benzidine powder & hydrogen per
oxide
Carbol fuschin(powder)
(Harris) Haematoxylin (Ready to
Use)
DPX

18
18

9076
9103

Sulphosalicylic Acid powder 5RBC Diluting Fluid

19

9084

Sodium nitroprusside

ર . ઓફીસ :

Item Name

લોક નં.૧૪/૧, ડા.

Signature Not Verified
Signed by:Dr. Jayesh Rupala
Incharge Deputy General
Manager
Date: 2024.06.03 15:41:54
+05:30

Name of bidder

RC
Validity

Last Order
Date

M/s. Hi Media Laboratory Pvt Ltd.
M/s. Tulip Diagnostics Pvt Ltd.
M/s. Biolab Diagnostics (I) Pvt
Ltd.
M/s. Biolab Diagnostics (I) Pvt
Ltd.
M/s. Molychecm
M/s. Biolab Diagnostics (I) Pvt
Ltd.
M/s. Molychecm
M/s. Biolab Diagnostics (I) Pvt
Ltd.
M/s. Molychecm
M/s. Molychecm

30/06/23
30/06/23
31/12/22

15/05/23
15/05/23
17/09/22

31/12/22

17/09/22

30/06/23
30/06/23

30/06/23
30/06/23

31/12/22
30/06/23

16/09/22
30/06/23

10/12/22
30/06/23

17/09/22
30/06/23

M/s. Molychecm
M/s. Reckon Diagnostic Pvt Ltd
M/s. Hi Media Laboratory Pvt Ltd.
M/s. Biolab Diagnostics (I) Pvt
Ltd.

31/12/22
30/06/23
30/06/23
31/12/22

17/09/22
15/05/23
15/05/23
17/09/22

M/s. Hi Media Laboratory Pvt Ltd.
M/s. Hi Media Laboratory Pvt Ltd.

31/12/22
31/12/22

17/09/22
16/09/22

M/s. Biolab Diagnostics (I) Pvt
Ltd.
M/s. Molychecm
M/s. Biolab Diagnostics (I) Pvt
Ltd.
M/s. Molychecm

31/12/22

17/09/22

31/12/22
31/12/22

07/12/22
17/09/22

31/12/22

07/12/22

વરાજ મહે તા ભવન, જુ ના સિચવાલય, સેકટર-૧૦, ગાંધીનગર-૩૮ર૦૧૦ફોન : (ઓ) ૦૭૯-ર૩ર પ૦૭૬૭, (ફે ) ૦૭૯-ર૩ર પ૭પ૮૬
`D:\Himanshu Data\e-Aushdhi GAD Note-1& Worksheet.docx

File No: GMSCL/SDR/e-file/143/2024/0782/Diagnostic
Approved By: Incharge Deputy General Manager,Diagnostic,GMSCL
