---
doc_id: "acf45ce1bdeb3078"
source_url: "https://legal.gujarat.gov.in/Documents/Notification/form-1-11082026012707.pdf"
ministry: "Legal Department, Gujarat"
title: "Application Form for appointment of Legal Officer (Legal Executive)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7c35f143b7a897be"
---

<!-- page 1 -->

Legal Department Government of Gujarat
Block 4, Sardar Bhavan, New Sachivalay, Gandhinagar.
Application Form for appointment of Legal Officer (Legal Executive) at
the Office of Govt. Law Officers, High Court Of Gujarat., Ahmedabad.

1.

Name: ___________________________________________________

2.

Address: _________________________________________________

Photo to be
affixed in
Passport Size

_________________________________________________
_________________________________________________
Mobile No.: _____________________, Alternate No. ______________________
E-mail: _____________________________________________________________
3.

Address of Native: ___________________________________________________
_______________________________________________________________________

4.

Date of Birth : ______________, Gender: _______________

5.

Nationality: _________________

6.

Age as on last date of application : _______ Year _____ Month.

7.

Education Qualification:
Sr.
No.
1

Name of Degree

Name of
University

Passing
Year

Percentage

Remarks

2
3
4
5
6
7

8.

Date of Registration of Advocate: ______________________________________

9.

Sanad No._________________

<!-- page 2 -->

10. Professional experience/Background: ___________________________________
_____________________________________________________________________
_____________________________________________________________________
_____________________________________________________________________
11. Information as regards conducting of cases for last five Years. (Attach Sheet)
12. Date of Certificate For CCC / CCC+ ______________
13. Since how long you are paying Income Tax? ______________
Information of Income-Tax paid at least one year. (Attach Sheet)
14. Any criminal complaint filed/ pending?
If yes please give details ______________________________________________
____________________________________________________________________
Have you been convicted at any time? _________________________________
____________________________________________________________________

I declare that all statements & details filled up in this form are true and
correct. If any information found to be untrue or incorrect, my candidature shall
be liable to be cancelled at any time, without any notice.

Date:

/08/2026

_______________________________

Place:

Note:

Name & Signature of Applicant

1. The prescribed application form must be submitted on or before
19th August, 2026 – 18:10 p.m.
2. All future communication will be conducted through Email; you
are requested to provide your valid and active Email Id.

For office use
Form received on :
Registration No. :

/08 /2026, Time: ___:___ A.M./P.M.
