---
doc_id: "a28ddcb0ea577cda"
source_url: "https://gujhealth.gujarat.gov.in/images/pdf/Application-forms-for-Establishment-of-New-Super-Specialty-Hospital-new.pdf"
ministry: "Health & Family Welfare Department, Gujarat"
title: "Health Policy 2016 Application form for Establishment of New Super Specialty Hospital"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3f699de0afb708e9"
---

<!-- page 1 -->

Application under Incentive Scheme for Establishment of New Super
Specialty Hospital in Private Sector.
Date:

To,

Commissioner of Health,

Medical Services & Medical Education,
Block No. 5, Dr. Jivraj Mehta Bhavan,
Gandhinagar, Gujarat.

Subject: Application for Establishment of New Super Specialty Hospital under Health
Policy 2016.

I / We___________________________________________________________________ (Hospital / Institute /

Person) hereby apply for assistance from Government of Gujarat to establish a New Super
Specialty Hospital under Health Policy 2016 at _____________ in Taluka____________
District__________________.

I/We are submitting the application with enclosed documents as per the prescribed

checklist and demand draft by Government.

Enclosure:
1) The Detailed Application Form is annexed.
2) Demand Draft.

(Signature & Stamp)

<!-- page 2 -->

APPLICATION FORM-A for registration under scheme for “Incentive Scheme for
Establishment of New Super Specialty Hospital in Private Sector”
1. Name of the applicant with complete address, contact details, phone no., e-mail and
Name of Contact person with his/her contact details : 2. Category of Applicant : (Individual (in case of doctor please attach registration details with Gujarat Medical
Council), Registered Partnership Firm, Institution Registered under Law, Company,
Charitable Trust, Society, Co-Operative Institution, Government Board, SemiGovernment Board Corporation, Panchayat, Municipality, Municipal Corporation.)
(Attach relevant supporting document like certified copy of Bye laws / Memorandum and
Articles of Association / Trust deed, if so.)
3. Details of proposed Hospital: a. No. of Beds.
b. Name of super-specialties with no. of beds.
c. Plan of Hospital.
d. Details of equipments.
4. Financial details : • Present financial capabilities of the applicant (Annual reports and audited balance
sheet for last 3 years, if so.)
•

Source of Funds with details (means for equipment or establishing super-specialty
hospital) :

(Contribution of the applicant / Grants / Donations / Equity / Term loans / other
sources, if any then documents to be attached.)
5. Place of proposed Super-specialty Hospital : 6. Broad proposed project report with Timeframe : 7. Details of Scrutiny Fee :a. Demand Draft No. & Date.
b. Name of Nationalized Bank.
c. Amount
(In favor of Commissioner of Health)

*Attach Annexure on Rs. 100 stamp paper as per GR of Government of Gujarat, Health and
Family Welfare Department, Resolution No. MCG-2016-SFS-6-J, Sachivalaya, Gandhinagar
dated- 13/12/2016 with the application form.

<!-- page 3 -->

APPLICATION FORM-B at every 6 months of progress of Project for “Incentive Scheme
for Establishment of New Super Specialty Hospital in Private Sector”

1. Name of the applicant with complete address, contact details, phone no., e-mail and
Name of Contact person with his/her contact details : 2. Submission date of first application : 3. Details of progress so far in terms of : a. Infrastructure
b. Equipments, etc…

<!-- page 4 -->

APPLICATION FORM-C at the time of ready to commencement of Project for “Incentive
Scheme for Establishment of New Super Specialty Hospital in Private Sector”

1. Name of the applicant with complete address, contact details, phone no., e-mail and
Name of Contact person with his/her contact details : 2. Submission date of first application : 3. Submission date of progress report : 4. Details of Hospital: a. No. of beds.
b. Equipments
• Name of equipments
• Specification.
• Supplier details.
• Cost(copy of Purchase order to be attached)
5. Estimated Electricity load : 6. Source of Funds with details (means for equipment or establishing super-specialty
hospital) :
(Contribution of the applicant / Grants / Donations / Equity / Term loans / other sources,
if any then documents to be attached.)
7. Legal Licenses to be submitted : • Building use permit
• License for lift and elevator (if so)
• Fire NOC from appropriate authority
• License for Biomedical waste
• AERB Approvals &BARC Radiation Protection certificate for each Radiological /
imaging equipment
• PNDT license
• License for storage of Medical gases
• Drugs & Cosmetics License
• Narcotic & Psychotic License
• Substance License
• Registration and NOC under Pollution Control Act
• Ambulance fitness certificate from RTO (if so)
