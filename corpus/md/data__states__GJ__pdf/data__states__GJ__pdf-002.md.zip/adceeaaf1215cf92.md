---
doc_id: "adceeaaf1215cf92"
source_url: "https://panchayat.gujarat.gov.in/panchayat/documents/Multi-Purpose-Health-Supervisor-Recruitment-Rules-2004.pdf"
ministry: "Panchayats and Rural Housing Department, Gujarat"
title: ""
date: ""
pages: 2
method: "tesseract:guj+eng"
script: "GUJARATI"
needs_ocr: false
sha1: "775ceb1a32589984"
---

<!-- page 1 -->

12-2. GUJARAT GOVERNMENT GAZETTEEX., 8-4-2004 [PART LA
૨ '_ પંચાયત, ગ્રામ ગૃહનિર્માણ અને ગ્રામ વિકાસ વિભાગ ક
. જાહેરનામું
; a સચિવાલય, ગાંધીનગર, ૮મી એપ્રિલ, ૨૦૦૪. a
જ ગુજરાત પંચાયત અધિનિયમ, ૧૯૯૩. .
ક્રમાંક : કેપી-૮-૨૦૦૪-પીઆરઆર-૧૦૯૯-૨ર૭૨-૯-ડ :- ગુજરાત પંચાયત અધિનિયમ, ૧૯૯૩ (સન. ૧૯૯૩ના
ગુજરાતના ૧૮મા)ની ક્લમ-૨ ૨૭ની સાથે વાંચતા, કલમ ૨૭૪ થી મળેલી સત્તાની રૂએ,ગજ્યાત સરકાર, આથી, મલ્ટી પરડઝ °F -
“હેલ્થ સુપરવાઇઝર, વર્ગ-૩ (પંચાયત સેવા)ની જગા પર ભરતીનું નિયમન કરવા માટે જોગવાઇ કરવા નીચેના નિયધો કરે છે :- શ
૧. આ નિયમો મલ્ટી પરપઝ હેલ્થ સુપરવાઇઝર, વર્ગ-૩ (પંચાયત સેવા) ભરતી નિયમો, ૨૦૦૪ કહેવાશે. | |
ર. મલ્ટી પરપઝ હેલ્થ સુપરવાઇઝર, વર્ગ-૩ (પંચાયત સેવા)ની જગા ઉપરની Pegs, FA ual wa ser વર્કર
વર્ગ-૩ (પંચાયત સેવા) તરીકે ઓછામાં ઓછા પાંચ વર્ષ કામ કર્યું હોય અને સરકારે વખતોવખત ઠરાવેલ ખાતાકીય પરીક્ષા ,
પાસ કરી હોય તેવી વ્યકિતઓમાંથી સિધ્ધ ગુણવત્તા અને કાર્યદક્ષતાવાળી વ્યકિતને બઢતી આપીને કરવી જોઇએ.
3. બઢતીયી ત્તિમાયેલ ઉમેદવારે, સરકાર વખતોવખત ઠરાવે તેવી તાલીમ, તેટલી મુદત માટે લેવાની રહેશે અને તાલીમાંત
પરીક્યા પાસ કરવાની રહેશે. _ *
ગુજરાતના રાજયપાલશ્રીના હુકમથી અને તેમના નામે,
. --“ * * કે.એમ.પટેલ, 7
સરકારના ઉપસચિવ. દ
1 | Co
\ "i
, ક
સરકારી મધ્યસ્થ મુદ્રણાલય, ગાંધીનગર, ી

<!-- page 2 -->

2
pa REGISTERED No. G/GNR/
Extra No. 12 Ghee
© a
(ep
સત્યમેવ ગયતે
#
The Gujarat Government Gasette
PUBLISHED BY AUTHORITY
* ..ક----------------કકકકક
tt Vol. XLV] THURSDAY, APRIL 8, 2004/CAITRA 19, 1926
ડડ
Drs Separate paging is given to this Part in order that it may be filed as a Separate Compilation.
Os
PART I-A
Orders and Notifications (Other than those published in Part IV-B)
under the Gujarat Local Boards, Village Panchayats, Municipal
Boroughs, District Municipal, Primary Education and Local
Fund Audit Acts.
PANCHAYATS, RURAL HOUSING AND RURAL DEVELOPMENT DEPARTMENT
Notification
: Sachivalaya, Gandhinagar, 8th April, 2004.
GUJARAT PANCHAYATS ACT, 1993.
2 < No.-KP/8 /2004/PRR/1099/2272/9/D :- In exercise of the powers conferred by section 274 read with
section 227 of the Gujarat Panchayats Act, 1993 (Guj. 18 of 1993), the Government of Gujarat hereby makes
જ the following rules to provide for regulating recruitment to the post of Multipurpose Health Supervisor, Class-
III (Panchayat Service), namely :- i
1. These rules may be called the Multipurpose Health Supervisor, Class-III (Panchayat Service)
Recruitment Rules, 2004,

7 2. Appointment to the post of Multipurpose Health Supervisor, Class-IIl (Panchayat Service) shall be
made by promotion of a person of proved merit and efficiency from amongst the persons who have worked
as Multipurpose Health Worker, Class-III (Panchayat Service) for not less than five years and who have
passed the departmental examination prescribed by the Government from time to time.

3. A candidate appointed by promotion shall have to undergo such training for such period and pass the
post-training examination prescribed by the Government from time to time.
By order and in the name of the Governor of Gujarat,
K. M. PATEL,
Under Secretary to Government.
I-A-Ex. 12-1 12-1
”
