---
doc_id: "2aef1ddb08c90ed9"
source_url: "https://haj.gujarat.gov.in/writereaddata/images/pdf/Haj-Policy-2027.pdf"
ministry: "Gujarat State Haj Committee, Gujarat"
title: "HAJ POLICY 2027   (132 KB)"
date: ""
pages: 11
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a952b88ba2b51c02"
---

<!-- page 1 -->

Haj Policy 2027
1. Division of Haj Seats between Haj Committee of India (HCoI) and Haj Group
Organisers (HGOs).
The Government of India (GoI) and the Kingdom of Saudi Arabia (KSA) sign the
bilateral Haj Agreement every year, in which the number of Haj seats allocated to India is
incorporated. Out of the total number of quota allocated to the Government of India (GoI),
70% will be allocated to the HCoI and the remaining 30% will be allocated to HGOs.
2. Once in a lifetime, Haj through HCoI
Those who have performed Haj earlier through HCoI will not be eligible to apply.
Haj is an arduous and strenuous pilgrimage involving walking up to 25 km in a day
in extremely harsh climatic conditions of KSA and hence it would be mandatory for
pilgrims aged 65 or above (including such LWM pilgrims) to be accompanied by a
companion.
In the case of "Mehram" for lady pilgrims and companions of the pilgrims aged 65
years or above, including Ladies Without Mehram (LWM) pilgrims aged 65 years or above,
repeaters will be allowed on payment of additional charges as applicable from time to time.
The age of the “Mehram” and companions accompanying pilgrims aged 65 years or
above must be 18 to 65 years as on the date specified by HCoI. However, companions
accompanying LWM pilgrims aged 65 or above must be female and between the age of 45
to 60 years.
A lady pilgrim or pilgrims aged 65 or above, utilizing the services of a repeater as
“Mehram” or companion as the case may be, must give a solemn undertaking to the effect
that no first time “Mehram” or companion, as applicable, is available in the family.
3. Haj Suvidha App
A dedicated ‘Haj Suvidha’ App has been launched during Haj-2024 with the objective
of leveraging Information Technology towards providing greater ease and convenience to
the Indian Haj pilgrims by facilitating access to training content, accommodation / flight /
baggage details, emergency helpline (SOS), grievance redressal, feedback, language
translation and miscellaneous information related to the pilgrimage.
All pilgrims are expected to familiarise themselves with this App. Advisories on the
functionality of the App will be issued from time to time by HCoI.
4. Availability of Haj Application Forms (HAFs)
The Haj Application Forms (HAF) can be filled and submitted by pilgrims online
through the website of the Haj Committee of India (hajcommittee.gov.in), or through the
'HAJ SUVIDHA' mobile application.

<!-- page 2 -->

5. Eligibility for Haj
As per general Saudi guidelines on eligibility to perform Haj or Umrah, Haj pilgrim
should be fit in all aspects: financial, physical, behavioral, and mental. As such, any Muslim
citizen of India can apply for Haj pilgrimage except:
a. Persons not in possession of machine-readable, valid Indian international passports
as per HCoI guidelines.
b. Ban on Repeaters: A person who has performed Haj earlier in his/her life through
HCoI except for permitted categories of “Mehrams” and those accompanying a
pilgrim aged 65 or above including such LWM pilgrims (details at Clause- 6) on the
basis of an appropriate solemn declaration and undertaking.
c. Any person found to have furnished false information shall not be allowed to
proceed for Haj. In such cases, he/she will be disqualified at any stage and deboarded even at the embarkation point. The entire amount deposited by him/her
shall also be forfeited. Besides, he/she may be prosecuted for making an incorrect /
false declaration. These restrictions will also apply for concealing the fact of having
performed Haj earlier as well as for Haj-e-Badal pilgrims.
d. Those with severe medical conditions such as advanced cardiac, respiratory, liver,
or kidney diseases; or senility, neurological or psychological disorders affecting
cognition or accompanied by severe motor disabilities, old age associated with
dementia, active cancer patients receiving chemotherapy, biological therapy, or
radiotherapy and active infectious diseases affecting public health (such as open
tuberculosis and hemorrhagic fevers).
e. Ladies not accompanied by Sharia Mehram, except ladies covered at Clause 6.
f.

Ladies in the advanced stage of pregnancy: In the case of pregnant women in the
advanced stages of pregnancy, international flying standards will be followed.

g. Children below 15 years of age, subject to Saudi guidelines.
h. Any person against whom a court order prohibiting travel abroad exists.
i.

Consent of parents / legal guardian is mandatory for undertaking Haj by any
applicant below the age of 18 years.

6. Ladies travelling without their Mehrams
Ladies aged 45 or above, who wish to go for Haj but do not have a male Mehram and
their school of thought (Maslak) permits, are allowed to travel in groups of 4 or more ladies.
Subject to the terms of KSA, single ladies may also apply, and HCoI may form a
grouping with the ladies who applied under the category. Consulate General of India,
Jeddah will also facilitate separate living arrangements for women traveling alone for the
Pilgrimage.
In order to bring parity between other pilgrims aged 65 and above with LWM pilgrims
in the same age bracket, and also in view of the arduous nature of the Haj pilgrimage, it has
been decided that a female companion aged 45 to 60 years is a must for LWM pilgrims aged

<!-- page 3 -->

65 or above and no LWM pilgrim aged 65 or above will be registered individually. Further,
the conditions mentioned in Clause 12(a), (b) & (c), as applicable to pilgrims aged 65 or
above, shall also apply to LWM pilgrims aged 65 or above.
7. Cover Size
The size of the Cover shall be minimum 1 (one) and Maximum 5 (five) Adults (If the
number of family members exceeds five, applications should be made in more than one
cover).
8. Composition of Cover – only Family Members & Near relatives
A maximum number of five (5) applicants comprising the family members or near
relatives can apply in a single cover. The head of the cover shall be responsible for payment
for the persons included in the cover. Under no circumstances, persons other than family
and near relatives should be included in the cover. It is in the interest of pilgrims to ensure
that only family members having blood relation or near relatives are included in the cover.
In case a few pilgrims under one cover intend to prepone/postpone the date of flight, it
would not be permitted. Accommodation would be allocated gender wise in conformity
with KSA’s laws and applicable guidelines. If the head of cover himself cancels his
application for Haj pilgrimage, he should indicate the name of another person from
amongst the male Members of such cover, as the head of the particular cover. If a male
applicant, who is Mehram of the female applicant of cover, cancels his application for Haj
pilgrimage, he must indicate the name of the other applicant from among the male
Members of the cover as “Mehram” along with his relation with the female applicant(s) of
that cover, otherwise, application(s) of the female applicant(s) shall also be treated as
cancelled. Change of Mehram is allowed only in specific cases on account of death/medical
grounds.
9. Solemn declaration and undertaking for applicants aged 65 or above
The applications received in 65 or above age category are given top priority allocation
of seats for that State/UT. However, in case more Haj applications are received in 65 or
above age category than the allotted quota for State/ UT, a draw of lots will be conducted
among the 65 or above age category applicants as explained in clause12 of the policy. This
is to enable and facilitate assured seats to elderly and aged senior citizens desirous of
performing Haj pilgrimage. Applicants in 65 or above age category shall submit a solemn
declaration and undertaking in the format prescribed by HCoI. If the solemn declaration
and undertaking is not enclosed or found incomplete or not in the format given, the Haj
application shall be summarily rejected.
10. Solemn declaration and undertaking for General Category
In view of the “once in a life time Haj through HCoI” policy, all general category
pilgrims shall submit a solemn declaration and undertaking in the format prescribed by
HCoI. Solemn declaration and undertaking should be in English only. If the solemn
declaration and undertaking is not enclosed or found incomplete or not in the format given,
Haj Application shall be summarily rejected.

<!-- page 4 -->

11. Order of Priority
While allotting seats of each state, the order of priority will be:
1. 65 or above Category including Ladies without Mehram (LWM) of 65 years or above
(applicant along with companion).
2. Ladies without Mehram (LWM) between 45 and 65 years of age.
3. General Category(Backlog)— Top 20% final waitlisted applicants of Haj-2026.
4. General Category - New Applicants of Haj-2027.
12. 65 or above aged Applicant
It is decided that considering the arduous nature of the Haj pilgrimage, a companion
is a must for pilgrims aged 65 or above and no pilgrim aged 65 or above will be registered
as a lone member under reserved category. The pilgrims of 65 years and above will be
registered under Reserved Category, subject to the following conditions:
a. Applicant who completes 65 years or more as per the cut off date which will be
specified by HCoI in the Haj Guidelines.
b. One companion is a must for pilgrims aged 65 or above and no pilgrim aged 65 or
above will be registered alone under reserved category. In case of LWM pilgrims
aged 65 or above, a female companion of the age 45-60 is a must.
c. For non-LWM pilgrims of the age of 65 or above, one companion is allowed who
should be immediate relative namely Husband / Wife / Brother / Sister / Son /
Daughter / Son-in-law / Daughter-in-law / Grandson / Grand Daughter and
Nephew / Niece. No other relation will be allowed to travel as companion. Neither
the pilgrims aged 65 or above nor the companion will be allowed to travel alone.
The age of the companion must be below 65 years on the date specified by HCoI.
d. If husband and wife are travelling in a cover under reserved category, and both are
aged 65 or above, they will be allowed two companions, who will be blood relation
of the pilgrims.
13. Distribution of Quota
The pilgrim quota for HCoI should be 70% of the total Haj Quota of India. The
following procedure for allocations will be followed by HCoI :
Stage - I
Out of the total quota allocated to India in the agreement between the Kingdom of
Saudi Arabia and the Government of India, 70% must be allocated to the HCoI and the
remaining 30% should be allocated to HGOs.
Stage - II

<!-- page 5 -->

Out of the total seats allocated to HCoI under Stage-I, quota for State Haj Inspectors
(SHIs) in the ratio of one SHI for one hundred and thirty five pilgrims shall be subtracted
from the overall Haj quota. The remaining seats shall be distributed across all the States
and Union Territories in proportion to their Muslim population.
Stage - III
The distribution of the different States and Union Territories quota shall proceed as
in the current policy through qurrah (draw of lots). In case there are surplus seats generated
by under-utilised quotas of States, the seats shall be distributed as provided in Stages IV
and V.
Stage - IV
The surplus seats shall first be utilised for providing up to 500 seats for Mehram. If
seats are still available after this, the UT of Jammu and Kashmir will be allocated up to 2,000
seats as a special measure. The remaining surplus seats will be used for groups of ladies
without Mehram and distributed among the States and Union Territories that received 500
or fewer Haj Application Forms (HAF) but were unable to accommodate all applicants, in
ascending order of the number of applicants. For the States/ Union Territories where there
is a marginal increase in the number of applications by up to 5% compared to previous year,
a quota restricted to 500 seats shall be provided.
Stage - V
The remainder of the surplus seats after Stage IV (if any) shall be allocated to the States
and Union Territories in proportion to their Muslim population.
14. Qurrah
Qurrah refers to computerized draw of lots. In the States/Union Territories where the
number of Haj Applications received exceeds their quota, pilgrims shall be selected
provisionally by Qurrah conducted on the Covers. The Qurrah shall be conducted by the
HCoI online based on randomisation. The date and other details of Qurrah shall be
publicized by HCoI. Immediately after Qurrah, the selected and waitlisted applicants will
be informed by HCoI.
15. Principles of Qurrah (Draw of Lots)
The order of priority for confirming the seats in a State/UT is as follows:
Category-1: 65 or above age category including such LWM;
Category-2: Ladies without Mehram below age of 65;
Category-3: General Category(Backlog)— Top 20% final waitlisted applicants of Haj-2026;
Category-4: General Category(Fresh)—New Applicants of Haj-2027
a. If the applications under Category-1 are more than the quota of the State/UT, then
the qurrah (draw of lots) will be conducted within Category-1, State/UT wise.
Pilgrims in Category-1 will be given first priority for allocation of seats. A waiting
list for Category-1 would be prepared in this case.

<!-- page 6 -->

b. The second priority would be given to Category-2. If the remaining quota, after
allocation to Category-1, is less than the applications in Category-2, then qurrah
shall be done for Category-2, State/UT wise. In this case, a separate waiting list shall
be prepared for Category-2.
c. After the Category-1 and Category-2 applications have been exhausted, the qurrah
(draw of lots) will be held State/UT wise among the general category applicants
who were top 20% final waitlisted applicants for Haj-2026 (Category 3) for the
remaining seats. Another waiting list, called as General Waiting List (Backlog)
(GWLBL) or Category-3 waiting list will be prepared by conducting qurrah (draw
of lots).
d. After the Category-1, Category-2 and Category-3 applications have been exhausted,
the qurrah (draw of lots) will be held State/UT wise among the general category
(fresh) applicants for the remaining seats. Another waiting list, called as General
Waiting List (GWLF) waiting list will be prepared by conducting qurrah (draw of
lots) among those applicants who applied under the general category (fresh) but
could not get a confirmed seat.
e. From among the four waiting lists, viz. Category-1 WL, Category-2 WL, GWLBL
and GWLF, the applicants from the Category-1 WL will be given confirmed status
first, followed by Category-2 WL, followed by GWLBL and thereafter, GWL against
any future available seats.
If the applications under Category-1 are equal to the quota of a particular State/UT, the
entire quota will be utilized for Category-1 and all other Category-2, category-3 and general
category applications will be put under Category-2 WL, GWLBL and GWLF respectively,
drawn on the basis of qurrah (draw of lots).
16. General Wait List
A separate Qurrah (draw of lots) of non-selected covers shall be held State- wise/UTwise in the State/UT that receives Haj applications in excess of its quota to allocate a wait
list number to all such covers. The confirmation of seats with respect to wait-listed pilgrims
shall be communicated by the respective State Haj Committee/UT Haj Committee as and
when a vacancy arises due to the cancellation of the journey by the selected pilgrims. If the
selected pilgrim wants to cancel the journey for any reason, he should submit a cancellation
letter to the concerned State Haj Committee /UT Haj Committee. The State Haj
Committee/UT Haj Committee should mark the cancellation and select the wait listed
pilgrim as per serial number on the basis of the first cancelled seat for the first wait-listed
applicant. The order of the waiting list will be strictly followed without any deviation. Once
marked, cancellation cannot be revoked for any reason. The wait-listed pilgrims should
remain in contact with the HCoI, State Haj Committee/UT Haj Committee about the current
status of their seat confirmation.
17. Rules of Cancellations and Refunds
All process pertaining to the performance of Haj have been made online by KSA. In
view of the Saudi Government policy for not permitting the changes in the pilgrims
information, only cancellations on the grounds of death or serious ailment of the person

<!-- page 7 -->

concerned will be allowed. In case of cancellation on any other ground, penalties will be
imposed as per guidelines and amendments thereto by HCoI.
The HCoI shall make arrangement for refund of amount deposited by applicant
preferably within a period of one month.
18. Payments by pilgrims
All provisionally selected pilgrims will be allotted a unique bank reference number,
which must be quoted compulsorily for depositing advance and balance Haj amounts in
the State Bank of India/authorized nationalized banks through the core banking system.
19. Cancellation
If the selected pilgrim wants to cancel the journey for any reason, he/she should
submit a cancellation letter to the concerned State Haj Committee/UT Haj
Committee/online through the Haj Committee of India’s portal/Haj Suvidha App. In case
of failure to submit any document/ information and/or payment in a timely manner, the
selection of the pilgrim will be summarily cancelled.
20. Accommodation
As per Saudi Regulations, accommodation has to be arranged for the pilgrims in
advance through the Consulate General of India, Jeddah. The detailed KSA regulations with
respect to accommodation would be communicated by HCoI.
Pilgrims who want and are entitled to stay in Rubat will be allowed to stay in Rubat,
subject to KSA norms, and no charges for their accommodation will be levied by HCoI, or
if charges are levied, they will be refunded to those pilgrims who use Rubat facility.
21. Medical Screening and Fitness Certificate for every Applicant
A medical check-up report for the pilgrims is mandatory. In order to ensure that only
healthy pilgrims proceed for Haj, a two-step medical screening has been introduced one at
the application stage (on the reverse of the Haj application) and another of the selected
pilgrims at the embarkation stage. Every applicant should fill out the medical history, get
examined, and obtain a Medical Screening and Fitness Certificate from Government
allopathic doctor, on the reverse of his/her Haj Application.
The Health Certificate to be issued to the pilgrims by Medical Officer shall have
information related to mandatory vaccinations. The digital medical health certificate will
be issued to selected Haj pilgrim in collaboration with Ministry of Health and Family
Welfare (MoHFW).
Haj is an arduous and strenuous pilgrimage involving walking up to 25 km in a day
in extremely harsh climatic conditions of KSA. In view of the same and looking at the higher
vulnerability and health risk to pilgrims aged 60 or above, a special screening shall be done
for every pilgrim aged 60 or above as per criteria to be prescribed by MoHFW in the interest
of the health of senior citizens.

<!-- page 8 -->

22. Health and Training (HAT) Card for Selected Pilgrims only
Every selected pilgrim shall obtain a Health and Training (HAT) Card and Haj Guide
from the State Haj Committee/Union Territory Haj Committee upon submission of pay-inslip for the advance Haj amount.
23. Vaccination Certificate: Inoculation of Meningitis /Quadruple Inoculation
All selected pilgrims are required to possess a certificate of inoculation with a single
dose of the cerebrospinal meningitis vaccine. Pilgrims, therefore, must get themselves
inoculated against meningitis and obtain a vaccination certificate on the Health and
Training (HAT) Card before proceeding to the Embarkation Point. The certificate should be
signed by the district health officer. Incomplete and bogus certificates shall not be
entertained. Arrangements are made every year by the State/UT Haj Committees for
inoculation and the issue of the certificate to individual pilgrims after they have been
examined by the Medical Officer. Similarly, the State/UT Haj Committee and District
Administration make such arrangements for the inoculation of the pilgrims in the
respective States/UTs throughout the country.
The HCoI, in coordination with the State/UT Haj Committees, will ensure that the
pilgrim gets dosages of all required vaccines as per medical protocol. The Ministry of
Minority Affairs, in collaboration with MoHFW, will ensure timely availability of all
vaccines for Haj pilgrims.
A contingent of medical personnel will be deputed in collaboration with MoHFW, to
Saudi Arabia to cater to medical needs of Haj pilgrims.
24. Oral Polio Vaccination
It is mandatory to give oral polio vaccine to all pilgrims six weeks before the start of
the Haj journey and obtain the oral polio vaccine certificate from the concerned health
authorities on the Health and Training (HAT) Card. They will be given another dose of oral
polio vaccine at the time of their disembarkation in KSA.
25. Embarkation Points(EPs)
The pilgrims will be required to give two preferences for EP in order of priority. The details
of EPs for Haj-2027 are as under:
1. Ahmedabad
2. Bengaluru
3. Calicut
4. Chennai
5. Cochin

<!-- page 9 -->

6. Delhi
7. Gaya
8. Guwahati
9. Hyderabad
10. Indore
11. Jaipur
12. Kannur
13. Kolkata
14. Lucknow
15. Mumbai
16. Nagpur
17. Patna*
18. Srinagar
19. Vijayawada
*subject to clearance from MoCA and MHA
In case of number of passengers travelling from an EP goes above or below the
economic operation of the air charter services, MoMA reserves the right to reallocate the
passengers to any other EP in the interest of smooth air charter operations and air safety
protocols.
In addition to 19 EPs, MoMA may also consider the requests for inclusion of other
Airports as EPs with the approval of competent authority and subject to approval of
Ministries such as Ministry of External Affairs, Ministry of Civil Aviation, Ministry of Home
Affairs and also authorities of Kingdom of Saudi Arabia (KSA).

MoMA in coordination with Ministry of Civil Aviation will ensure that selection of
Airlines for Haj operations is done through a transparent process following due process.

26. Duration of Stay in the Kingdom of Saudi Arabia
The duration of stay of pilgrims may be up to 40-45 days and may vary as per schedule
provided by the airlines and approved by General Authority of Civil Aviation, Kingdom of
Saudi Arabia. Accommodation units in Makkah Mukarramah are hired for the entire Haj
season. Buildings are not hired on daily rental basis. The rate charged is for the entire Haj
season irrespective of the duration of stay. Hence, all pilgrims are charged uniformly.
Therefore, no pilgrim is entitled for any refund based on the duration of stay.

<!-- page 10 -->

27. Short Haj Package
The HCoI may operate a Short Haj Package with a total stay of 20 days in the KSA
for a maximum of 10,000 pilgrims. An option for availing this package shall be provided to
all applicants at the time of submission of the Haj Application Form (HAF).
Pilgrims who opt for the Short Haj Package and are selected through Qurrah
(Randomized Digital Selection) shall be allotted the short-duration package, subject to the
availability of seats under this package. In case the number of selected applicants opting for
the Short Haj Package exceeds 10,000, a separate Qurrah shall be conducted for selection,
and a waiting list will be maintained for the remaining applicants. The package shall not
be changed after the submission of H.A.F.
Short Haj will be operated at the following Embarkation Points only:
1. Ahmedabad
2. Bengaluru
3. Chennai
4. Cochin
5. Delhi
6. Hyderabad
7. Kolkata
8. Mumbai
28. In Case of Death
In case of death, due to natural causes or accident during the Haj period, burial rituals
may be performed as per prevailing practice in Kingdom of Saudi Arabia.
The original Death Certificate is directly, sent to the next of kin of a deceased pilgrim
by the Consulate General of India (CGI), Jeddah, after the completion of Haj season.
29. Adahi (Qurbani)
Adahi (Qurbani) is permitted only through entities authorised by KSA for the same.
Pilgrims should not fall prey to fraudsters in the name of Qurbani. Adahi through
authorised entities will be arranged by HCoI for the covers who opt for it (all pilgrims of a
cover have to opt together). Once exercised, the option cannot be revoked. The Adahi
(Qurbani) coupons will be optional.
The HCoI will issue an advisory in format of dos & don’ts for pilgrims which will also
have information about Adahi coupon (how does it look, colour, features etc).

<!-- page 11 -->

30. Legal Status of the Pilgrim
The HCoI, constituted under the Act of Parliament (No.35 of 2002) renders service to
pilgrims without any consideration. HCoI works on a "no profit, no loss" basis. It collects
the exact amount from pilgrims required for payment of various facilities and services to
the concerned agencies. Nothing extra is being charged from the pilgrims except the
Miscellaneous dues towards Administrative Expenses including dues of the State/UT Haj
Committees as provided in the Guidelines. HCoI, as such, does not come under the purview
of the Consumer Protection Act, 2019. The pilgrims, therefore, cannot claim any
compensation against HCoI under the Consumer Protection Act or under any other law for
the time being in force for any deficiency in the service rendered and/or any act of
commission and/or omission beyond the control of HCoI.
31. State Haj Inspector (SHI)
Ministry of Minority Affairs sets apart seats to send SHIs from all States/ UTs to help
and assist the Consulate General of India in Jeddah in looking after the welfare of Indian
Haj pilgrims in an organized manner. The SHIs should be Government servants selected by
the State/UT Haj Committees as per the norms laid down by MoMA.
To optimise the facilitation of assistance to pilgrims, the CGI, Jeddah may hire locals
in KSA and women assistants from existing Indian diaspora.
32. Persons with Special needs
i.

The persons with benchmark disability/disabilities who cannot travel alone, as
certified by the medical authorities, applying for Haj must be accompanied by an
able-bodied person during all stages of the Haj journey. Repeaters may be permitted
to be companions.

ii.

He/ She should be the blood relative/ spouse of such a person.

Assistance to Divyangjan and elderly pilgrims will be provided by the Indian Haj
Mission on a need basis. In spite of the extra-territorial nature of the Haj pilgrimage, the
Government would endeavour to provide best possible accessibility to Divyangjan pilgrims
including on a payment basis.

The Supreme Court of India, in its judgment dated April 16, 2013, barred all courts and
authorities from interfering with the Haj process.

*****
