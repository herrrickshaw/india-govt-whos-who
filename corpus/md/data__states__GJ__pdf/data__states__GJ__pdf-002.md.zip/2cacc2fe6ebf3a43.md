---
doc_id: "2cacc2fe6ebf3a43"
source_url: "https://gmscl.gujarat.gov.in/images/pdf/D-13_1506.pdf"
ministry: "Gujarat Medical Services Corporation Limited (GMSCL), Gujarat"
title: "પરિપત્ર: ટેન્ડર નં. GMSCL/DS-13/RI-DS-08/RC/2019-20 સીક્યોરીટી ડીપોઝીટ રીફંડ બાબત"
date: ""
pages: 4
method: "tesseract:guj+eng"
script: "GUJARATI"
needs_ocr: false
sha1: "7ffeca3173326747"
---

<!-- page 1 -->

Letter No: GMSCL/0016/06/2024 101: 03-06-2024
Pre [ડે
CH) તો ગુજરાત મેડીકલ સર્વિસીસ કોર્પોરેશન લીમીટેડ
તિત! ૬ (ગુજરાત સરકારનુ સાહસ)
ક્રમાંક.જી.એમ.એસ.સી.એલ/ડાયગ્નોસ્ટીકસર્વિસીસ/એસ-ડી રીફંડ પરિપત્ર/૨૦૨૪-૨૫/ તાઃ
અગત્યનું/રામયમર્યાદા
પરિપત્ર:
ગુજરાત મેડિકલ સર્વિસીસ કોર્પોરેશન લી. સાથે સંકળાયેલ સર્વે માંગણી અધિકારીઓને જણાવવામાં આવે છે કે, અત્રેની ડાયગ્નોસ્ટીક સર્વીસીસ
શાખા દ્વારા ખરીદ કરાયેલ રીએજન્ટ, કીટ અને કન્‍્જ્યુમેબલના ખરીદ ઓર્ડર અન્વયે એનેક્ષર -એ માં દર્શાવેલ પેઢીઓ પાસેથી લીધેલ સીક્યુરીટી
ડીપોઝીટની મુદત yel થયેલ હોવાથી ખરીદ ઓર્ડર સામે પેઢીઓએ ભરેલ સીક્યુરીટી ડિપોઝીટ પરત કરવાની થાય છે. એનેક્ષર - એ માં દર્શાવેલ
કોઇ પણ ખરીદ ઓર્ડર સામે આપની તરફથી કોઇ ફરીયાદ હોય તો સદર પરિપત્ર જાહેર થયેથી દિન-૦૭- માં પરિપત્ર સાથે સામેલ પ્રફોર્મામાં ઓર્ડર
વાઈઝ તમામ વિગતો ભરીને મોકલી આપવી.
આપના તરફથી સમયમર્યાદામાં કોઇ પ્રત્યુત્તર નહિ મળે તોપેઢી/પેઢીઓ સામે આપને કોઇ ફરીયાદ નથી, તેમ માની સીક્યુરીટી ડિપોઝીટ પરત
કરવામાં આવશે. નિયત સમયમર્યાદા બાદ સદર બાબતે ભવિષ્યમાં વસુલાત કે ઓડિટ પેરા સંબધિત પ્રશ્નો ઉભા થશે તો તે અંગેની સઘળી
જવાબદારી જે તે સંબધિત અધિકારીની રહેશે. જે ધ્યાને લેવા વિનંતી. ખરીદ પ્રક્રીયામાં સદર કામગીરીની ગંભીરતા સમજી રીએજન્ટ, કીટ અને
કન્જ્યુમેબલના ખરીદ ઓર્ડર અન્વયે પેઢી/પેઢીઓ સામે વાંધો હોય તો સામેલ પ્રફોર્મામાં જરૂરી વિગતો ભરી પ્રફોર્મા રજુ કરવા! અથવાવાંધાસરખું ન
હોય તો “ના વાંધા પ્રમાણપત્ર” સમયસર મોકલી આપવા અને સદર બાબતે ટોચ અગ્રતા આપવા વિનંતી છે.
નોંધ:- આપના “ના વાંધા પ્રમાણપત્ર” અત્રેની SAsloi! e-mailid-jrpharma2-gmscl-gnr@gujarat.gov.in #sadlotl 2B). |
જનરલ મેનેજર (ડી.એસ)
ગુજરાત મેડિકલ સર્વિસીસ કોર્પોરેશન લી.
ગાંધીનગર
બિડ!ણઃ ઉપર મુજબ.
પ્રતિ,
(૧) સર્વે માંગણી અધિકારીશ્રી તરફ........
(૨) અધિક નિયામકશ્રી, આરોગ્ય તબીબી સેવાઓ અને તબીબી શિક્ષણ,(તબીબી શિક્ષણ) ગાંધીનગર
(૩) અધિક નિયામકશ્રી, આરોગ્ય તબીબી સેવાઓ અને તબીબી શિક્ષણ,(તબીબી વિભાગ) ગાંધીનગર
(૪) અધિક નિયામકશ્રી, આરોગ્ય તબીબી સેવાઓ અને તબીબી શિક્ષણ,(આરોગ્ય વિભાગ) ગાંધીનગર
(પ) વિભાગીય નાયબ નિયામકશ્રી, અમદાવાદ,વડોદરા,સુરત,ભાવનગર,ગાંધીનગર,રાજકોટ.
(૬) મેનેજર( ક્વોલીટી કન્ટ્રોલ, લોજીસ્ટીક એન્ડ સપ્લાય), જી.એમ.એસ.સી.એલ.ગાંધીનગર
(૭) જી.એમ.એસ.સી.એલ. વેરહાઉસ, અમરેલી, ભુજ, દાહોદ, હિમ્મતનગર, જામનગર, નરોડા, પાટણ,
રાજકોટ, સુરત વડોદરા,વલસાડ
(૮) મેનેજર, આઈ.ટી. શાખા જી.એમ.એસ.સી.એલ.ગાંધીનગર( પરીપત્ર વેબસાઈટ પર મુકવા)
એનેક્ષર -એ
T.E.No.GMSCL/DS-13/RI-DS-08/RC/2019-20
Isr [it IName of bidder IRC Validity|Last
Ne ode Item Name |Order
2; 9 Date
Beacon Diagnostics Pvt. [03/05/23 0/06/2.
Alanine Transaminase Ltd.
[8007 lestimation kit
|
Signature Malic File No: GMSCL/SDR’/e-file/143/2024/0779/Diagnostic અ
કવ હોન Fert” Approved By: Incharge Deputy General Manager,Diagnostic,GMSCL Ee
Manager, 15:37:32 ૯૦ the document in Adobe Acrobat DC to verify the E-sign ન
+05:30

<!-- page 2 -->

Letter No: GMSCL/0016/06/2024 Dt: 03-06-2024
Sp ar કક a
ay SE
CG, Hl) ગુજરાત મેડીકલ સર્વિસીસ કોર્પોરેશન લીમીટેડ
4 GMSEL
હ / sm) (ગુજરાત સરકારનુ સાહસ)
Beacon Diagnesrias 0/06/23 [03/05/23
Bt. Ubel.
2 [8 Creatinine Estimation Kit
Beacon Diagn sps0/0623 [0370523
Urea Estimation Kit based on PL. bel.
8 |GLDH,UV, two દ
reagents,R1:R2
Urea Estimation Kit based on|Transasia Bio-Medicals [30/06/23 [03705723
4 8 IGLDH,UV,Single Lyophilized |Ltd.
reagent bottle
5 [8007 | Triglyceride estimation Kit resco Diagnostics Pvt. [80/06/23 [03705723
6 8 Total protein estimation kit, [52૦ ૧૦૦૦૫૧૬૪ ૯૪લ30/06/23 03705723
| Put Ud
7 [0009 | Creatine Kinase Total pencon Diagnostics Pvt. [80/06/23 [03705728
5 Total cholesterol estimation [Beacon Diagnostics Pvt. [80706728 [03705723
Kit Ltd.
9 012 [irc Aciestimaton kr [222000 Diagnostics Pvt. [03/05/23 [80706723
10 [8013 | Amylase estimation Kit peal Diagnostics Pvt. [30/06/23 [03705723
Beacon Diagnostics Pvt. [30/06/23 03705723
11 8014 HDL reagent kit Ltd.
homogeneous method Reckon Diagnostics 38070672383 [03705723
P.Ltd
12 8016 LDL reagent kit Reckon Diagnostics (03705723 [30706723 |
lhomogeneous method P.Ltd |
કક Diagnostics Pvt. [03/05/23 [30706723 |
Ltd. |
Albumin: eetinjation Kit [ર90 ૫1010505 ગતિ. 30706723 [03705728
14 8022 Micro protein CSF Protein ransasia Bio-Medicals [81/12/22 [1670972
lestimation kit Ltd.
15 8079 LDH -Lactate Dehydrogenase Transasia Bio-Medicals [30/06/23 30/06/23)
Estimation kit Ltd.
Meril Diagnostics Pvt. [23/05/23 [30/06/23
Fe: ર Ltd.
[1 808 LIPASE E: ti
20080 Se Esumationsisit Beacon Diagnostics Pvt. [23/05/23 8070672:
Ltd.
ISerum Phosphorus. Beacon Diagnostics Pvt. |15/05/23 __[30/06/2)
[17 [8082 Estimation Kit based on Ltd. |
|phospho-molybdate |
18 8 Multi Asaay human sera ransasia Bio-Medicals [30/06/23 [80706723
lbased chemistry calibrators Ltd.
Multi Asaay human sera ransasia Bio-Medicals [30/06/23 [80706723
19 [8 lbased chemistry Ltd.
|calibrators (pathological level)
Signature yalid ae
ignature I . 7 : ea
a કન પો Pe File No: GMSCL/SDR/e-file/143/2024/0779/Diagnostic 2 ae
Signi yr. રુ . ere Maher
incharge પ ન Approved By: Incharge Deputy General Manager,Diagnostic,GMSCL Hees
a AES
Bea ONE 15:97:30 Open the document in Adobe Acrobat DC to verify the E-sign Bh -
+05:30

<!-- page 3 -->

ક કે [સીસ કોર્પોરેશન લીમી
frie eh
ર Tt ગુજરાત મેડીકલ સર્વિસીસ કોર્પોરેશન લીમીટેડ
અડ = (ગજરાત સરકારનું જાહેર સાહસ)
એનેક્ષર -એ
T.E.No.GMSCL/DS-13/RI-DS-08/RC/2019-20
] “| Name of bidder | RC Validity | Last Order Date
sr | Item
Item Name |
No code | |
Beacon 03/05/23 30/06/23
1 8001 Alanine Transaminase estimation kit Diagnostics Pvt.
| | Ltd.
Beacon 30/06/23 03/05/23 |
2 | $004 | Creatinine Estimation Kit Diagnostics Pvt.
| | | Ltd. |
| ae Beacon 30/06/23 03/05/23
Urea Estimation Kit based on . કિ
ડે 8005 | GLDH,UV,two reagents,RI:R2 rma Pee |
; |. | ભા Transasia Bio- | 30/06/ 37/05/23
| Urea Estimation Kit based on માત 00022 pai |
4 | 8006 | GLDH,UV,Single Lyophilized reagent :
| | bottle |
ene —
| Beacon 30/06/23 | 03/03/23
| 5 | 8007 | Triglyceride estimation Kit Diagnostics Pvt.
| | Ltd.
| Beacon 30/06/23 03/05/23
6 | 8008 | Total protein estimation kit Diagnostics Pvt.
| | Ltd,
| | Beacon 30/06/23 03705723 |
7 | 8009 | Creatine Kinase Total Diagnostics Pvt.
છ a Ltd.
| | Beacon 30/06/23 03/05/23
| 8 8011 | Total cholesterol estimation Kit Diagnostics Pvt.
Ltd.
Beacon 03/05/23 30/06/23 |
9 | 8012 | Uric Acid estimation Kit Diagnostics Pvt.
| | Ltd.
| | | Beacon 30/06/23 03/05/23
| 10 | 8013 | Amylase estimation Kit Diagnostics Pvt.
[| જડ Ltd. - |
| Beacon 30/06/23 03/05/23
Diagnostics Pvt.
| | Ltd.
| I . ee |
| 11 | 8014 | HDL reagent kit homogeneous method R55, 500623 OTS
| Diagnostics |
| P.Ltd | |
r દિ Reckon 03/05/23 30/06/23 |
| 12 | 8016 | LDL reagent kit homogeneous method | Diagnostics
[ | ક! 2.14
| Beacon 03/05/23 30/06/23
Diagnostics Pvt.
Ltd. |
| Beacon 30/06/23 03/05/23 |
| 13 8019 | Albumin estimation Kit Diagnostics Pvt.
| | | Ltd.
4 T 029 "Micro protein CSF Protein estimation | Transasia Bio- 31/12/22 16/09/22 |
| kit Medicals Ltd.
“ડત: ——
રજી. ઓફીસ : બ્લોક ન.૧૪/૧, ડૉ. જીવરાજ મહેતા ભવન, જુના સચિવાલય, સેકટર-૧૦, ગાંધીનગર-૩૮૨૦૧૦ ફોન: (ઓ) ૦૭૯-૨૩૨ ૫૦૭૭૭, ફે)
૦૭૯-ર૩ર ૫૭૫૮:
\\10.83.51.250\12 diagnosis branch\NIRAV\[7] SD\Annexure A Biochem.docx --- 1

<!-- page 4 -->

a. Ta NACA ay
8% જે
ર 2. ત ગૅજરાત મેડીકલ સર્વિસીસ કોર્પોરેશન લીમીટેડ
આટ (ગુજરાત સરકારનું જાહેર સાહસ) |
| | Transasia Bio- | 30/06/23 | 30/06/23 | |
lye LDH -Lactate Dehydrogenase Medicals Ltd. | |
| 15 | 8079 | દ |
| | Estimation kit | |
કા ost
| Meril 23/05/23 30/06/23 |
| Diagnostics Pvt, |
| 16 | 8080 | LIPASE Estimation Kit ms a
| | Beacon 23705723 | 30700723
Diagnostics Pvt. | |
Ltd. |
લિ - Beacon 15/05/23 30/06/23 |
17 | 8082 | Serum Phosphorus Estimation Kit Diagnostics Pvt. |
| based on phospho-molybdate Ltd. |
Transasia Bio- | 30/06/23 30/06/23
i icals Ltd.
18 | 8083.1 | Multi Asaay human sera based Medicals
chemistry calibrators
[- “| Transasia Bio- [ 30/06/23 30/06/23 |
| | Multi Asaay human sera based Medicals Ltd.
| 19 | 8083.2 | chemistry calibrators(pathological
| level)
|
ie | | Bio-Rad 16/09/22 317127. 1
: Laboratoris
| Multi Assay human sera based satan |
20 | S084 | chemistry CONTROLS(NORMAL) _| (India)Private | |
| Limited |
Bio-Rad 13/09/22 31/12/22 |
સ Laboratoris
Multi Assay human sera based ie |
21 | 8085 છ ર (India)Private
chemistry CONTROLS(pathological) Tiinited
Beacon 30/06/23 03/05/23
Sink tee દ Diagnostics Pvt.
22 8086 Urea Estimation Kit based on berthlot Lid.
if method
|
|
|
રજી. ઓફીસ : બ્લોક નં.૧૪/૧, ર્ડો. જીવરાજ મહેતા. ભવન, જુના સચિવાલય, સેક્ટર-૧૦, ગાંઘીનગર-૩૮૨૦૧૦ ફોન : ઓ) ૦૭૯ ર૩ર ૫૦૭૭૭, (ફે)
૦૭૯-૨૩૨ ૫૭૫૮
\10.83.51.250\12 diagnosis branch\NIRAV\[7] SD\Annexure A Biochem.docx -- 2
