---
doc_id: "9aefcf0fbda55506"
source_url: "https://ic.gujarat.gov.in/documents/policy/industrial-policy202029082020051704.pdf"
ministry: "Industries Commissionerate, Gujarat"
title: "Gujarat Industrial Policy 2020"
date: ""
pages: 23
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d91150233bcfd4a1"
---

<!-- page 1 -->

<!-- page 2 -->

Gujarat Industrial Policy 2020

Contents

Contents .............................................................................................................................................. 2
1.

Preface ......................................................................................................................................... 3

2.

Background .................................................................................................................................. 3
Industry Overview ........................................................................................................................... 3
Robust physical infrastructure ........................................................................................................ 4

3.

Policy Period ................................................................................................................................ 8

4.

Vision ........................................................................................................................................... 8

5.

Mission ........................................................................................................................................ 8

6.

Objectives .................................................................................................................................... 8

7.

Reforms in regulatory mechanisms for Ease of Doing Business ................................................. 9

8.

Focused approach for balanced regional development ............................................................ 10

9.

Land Banks ................................................................................................................................. 10

10.

Availability of Government land on lease for industrial purposes ........................................ 11

11.

Relocation Incentives: ........................................................................................................... 11

12.

Promotion of Micro, Small and Medium Enterprises (MSMEs) ............................................ 11

13.

Use of Rooftop Solar Power by MSMEs ................................................................................ 14

14.

Promote Startup & Innovation .............................................................................................. 14

15.

Support for Research & Development in state ..................................................................... 15

16.

Special focus on promotion of Service Sector MSMEs .......................................................... 16

17.

Promotion of Thrust Sectors: ................................................................................................ 16

18.

Attracting Large/Mega and Ultra-Mega Investments ........................................................... 17

19.

Conducive Industrial Infrastructure ...................................................................................... 18

20.

Support for Environmental Infrastructure & Initiatives for Sustainable Development ........ 19

21.

Skill enhancement ................................................................................................................. 20

22.

Export Promotion .................................................................................................................. 21

23.

Conclusion ............................................................................................................................. 21

24.

Abbreviations ........................................................................................................................ 22

2|P a g e

<!-- page 3 -->

Gujarat Industrial Policy 2020

1. Preface

Gujarat is the most industrialized state in India and has been recognized nationally
and globally for offering conducive business ecosystem that is supported by ease of
doing business and state-of-the-art infrastructure. The state has witnessed
unprecedented growth in terms of investments, both FDI and domestic. With a
vision to give additional thrust to “Atmanirbhar Bharat”, the New Gujarat Industrial
Policy 2020 is being introduced with added focus on key thrust sectors,
strengthening integrated value chains, innovation and research. Besides this, the
Gujarat Industrial Policy has provisions to promote industries focusing to adopt
sustainable & cleaner manufacturing and innovative Industry 4.0 practices. It also
lays objective to encourage entrepreneurship and strengthen MSMEs and facilitate
cluster development.

2. Background

Industry Overview
Gujarat is India’s most industrialized and urbanized state. With roughly 6% of
India’s geographical area and 5% of its population, the state accounts for almost 8%
of India’s Gross Domestic Product (GDP). As per the Annual Survey of Industries
(ASI) 2017-18, Gujarat stood first in India in terms of Industrial Output with ~17%
of India’s output.1 Gujarat contributes over 20% of India’s exports2 and Gujarat’s
ports handle over 40% of India’s cargo.

Additionally, Gujarat stands 1st in terms of nos. of IEMs filed & actual investment
reported for 2019. Gujarat had ~51% share (1st Rank in India) of IEMs filed in India
in terms of value with a proposed investment of USD 49 billion in 2019 as per the
data released by DPIIT. Gujarat recorded a growth of 333% over previous year in
proposed investments in 2019. 3
Gujarat received FDI worth USD 15.6 bn. between April 2015 – March 2020. In FY
2019-20; Gujarat saw highest national increment of 240% in FDI inflows from
previous year. With this, the FDI growth in Gujarat is 60 times that of the growth in
rest of India.
This can be attributed to Gujarat’s policy driven business ecosystem. The increasing
investments are also a testimony of state’s conducive business environment. Over
the last four years, more than twenty sector specific policies were announced by the
State Government. These policies focused predominantly on enhancing the
industrial ecosystem and on promoting R&D and innovation.
Gujarat has established itself as a manufacturing powerhouse for sectors such as
auto & auto components, chemicals & petrochemicals, drugs & pharmaceuticals,
cement, textiles, engineering, gems & jewelry and ceramics. The state is home to
some of the world’s largest companies including 100+ Fortune 500 companies.
MSMEs form an integral part of the entire supply chain of these large companies in
1 http://www.csoisw.gov.in;
2
3

DGCIS
DPIIT

3|P a g e

<!-- page 4 -->

Gujarat Industrial Policy 2020

the state. They act as ancillary units to large industries contributing significantly to
the industrial development of the state. There are over 100 MSMEs multiproduct
activity clusters spread across the state. The number of MSMEs in Gujarat grew by
60% from 2014-2015 and currently, Gujarat is home to over 3.5 million MSMEs which
are a major source of employment.
‘Make in India’ initiative launched by Government of India aims at enhancing
manufacturing through investment, innovation and best-in-class infrastructure.
Gujarat has been successfully contributing to the initiative’s objective of
transforming India into a global design and manufacturing hub supported by
conducive infrastructure and ease of doing business. The State Government has also
introduced notable reforms in order to create a conducive business environment in
the state.
The initiative ZED (Zero Defect in Manufacturing and Zero Effect to Environment)
was launched to enhance the quality of the manufactured goods with the end goal
of positioning India as the “World’s Manufacturing Hub”. Gujarat’s manufacturing
sector has imbibed ZED as a core pillar which has supported the Gujarat MSMEs
carve a niche for themselves in the global supply chain.
In terms of Startups, Gujarat has emerged as an important startup hub at a national
level. The state has been recognized as Best Performer State in State Startup
Ranking by DPIIT in 2018. According to NASSCOM, around 150 startups were
founded in emerging hubs between 2014 to 2019 and 43% of the funded startups
were launched in Ahmedabad.
Gujarat has implemented several reforms for improving and easing the environment
for doing business. The State Government is continuously implementing reforms to
further improve its “Ease of doing business” quotient. Key recent reforms include
The Gujarat Single Window Clearance Act 2017 and the Gujarat MSME Act 2019.
The Industrial Policy 2020 has been drafted with this agenda at its core and the policy
aims to further ease the regulatory mechanism and procedure by strengthening the
helpdesks, dissemination of information and a strong mechanism to collect investor
feedback.
Robust physical infrastructure
Besides being strategically located on the western coast of India, Gujarat’s main
value proposition to the industries is its world class infrastructure. The robust
infrastructure includes a wide network of connectivity and utility till the last mile.
The state provides industries with:
• 1,57,470 km roads which includes National Highways, State Highway and
District Roads
• Power surplus state, providing round the clock three-phase uninterrupted
quality power & > 30 GW installed power generation capacity providing 24x7
un-interrupted supply
• 49 large ports including 1 major port and 48 non-major ports
• 17 operational airports and airstrips with 2 International airports

4|P a g e

<!-- page 5 -->

Gujarat Industrial Policy 2020

• 2600 km state-wide Integrated Gas Grid
In addition to these, the state’s next wave of growth will be driven by mega
industrial infrastructure projects, such as:
(1) Delhi - Mumbai Industrial Corridor (DMIC)
Delhi - Mumbai Industrial Corridor is one of the world’s largest infrastructure
projects by Govt. of India with an estimated investment of USD 90 billion (~INR 6.4
lakh crore). It is planned as a high-tech industrial zone spread across six states over
a 1,500 km long Western Dedicated Freight Corridor (DFC) which serves as its
backbone. Around 36% of the DMIC will pass through Gujarat. 6 of the 24 industrial
nodes identified across the DMIC will be in Gujarat. They are enumerated below: 4
a) Ahmedabad-Dholera Investment Region
b) Vadodara-Ankleshwar Industrial Area
c) Palanpur-Mehsana Industrial Area
d) Bharuch-Dahej PCPIR and Investment Region
e) Surat-Hazira, Industrial Area
f) Valsad-Umbergaon Industrial Area
Development of Greenfield ports, augmentation of existing industrial estates,
establishment of sector specific manufacturing and services hubs and investment in
power projects are some of the key initiatives being planned in the DMIC & DFC
influence zone.
(2) Dholera Special Investment Region (D-SIR)
Dholera SIR in Gujarat is India’s largest greenfield industrial investment region,
spread over 920 sq. km. DSIR will have smart & sustainable infrastructure spanning
transportation, water, power, waste-water, drainage and urban design. Its focus
sectors include: Heavy Engineering, Automobiles & Auto ancillary, Defense,
Electronics, Hi-tech technologies, Agri & Food processing and Infrastructure. The
world’s largest solar park of 5 GW is also being developed at Dholera SIR. 6 TP
schemes are approved for development of Dholera SIR as smart city.
It will be connected with Ahmedabad by a 6-lane access-controlled expressway &
Metro Rail Transit System (MRTS) in one common corridor providing seamless
connectivity. An international airport is being developed at Dholera SIR giving swift
international and domestic connectivity to the region.
(3) Mandal Becharaji Special Investment Region (MBSIR)
Emerging as the world’s largest Auto-Hub, MBSIR is a hotbed for Japanese
automobile and auto component manufacturing industries. Companies such as
Suzuki Motor Corp., Honda Motorcycles, Scooter India Pvt. Ltd, and Toyota Tsusho
India have already established their units.
Located at around 90 kms. from Ahmedabad, the region is well connected to leading
ports, airport, railroads and National highway (NH) roads.
4

http://www.gidb.org/newprojectdmic

5|P a g e

<!-- page 6 -->

Gujarat Industrial Policy 2020

(4) Mumbai Ahmedabad High Speed Rail
India’s first high speed rail project between two mega cities – Ahmedabad &
Mumbai is being developed at an investment of over INR 80,000 crore (~USD 11.23
billion). Project is being implemented in association with Japan International
Cooperation Agency (JICA).
(5) Petroleum, Chemicals and Petrochemicals Investment Region (PCPIR)

Located at Dahej, South Gujarat, PCPIR is India’s first specially delineated
investment region of 453 sq. km. for manufacturing of petroleum products,
chemicals and petrochemicals. With the coming of DFC, DMIC, Bullet Train and the
Express Highway linking Baroda to Mumbai, the prospect in PCPIR is further
expected to boost.
Three new LNG terminals and a greenfield airport have also been planned in/
around the PCPIR. To meet the increasing demands of land by industries, GIDC has
developed a chemical zone in Saykha.
(6) Gujarat International Financial Tech (GIFT) City
GIFT City is India’s 1st operational Smart City and International Financial Service
Centre (IFSC), with world class infrastructure for offshore and international
transactions in banking, insurance and capital markets.
It is a vertical city with integrated development on 886 acres of land with 62 Mn sq.
ft. (5.5 million sq. mts.) of Built Up area. GIFT is also home to India’s first
International Exchange (India INX). Major institutions such as Oracle, World Trade
Centre, BSE, NSE, SBI, LIC, Tata Communications, New India Assurance, Singapore
IAC, Bank of America, GERC, Data Centre are currently operational at the GIFT City.
Due to IFSC, several international financial institutions are setting up operations in
GIFT City and will further enhance doing business in Gujarat. With this, the GIFT
city has emerged to become a financial magnet in India. GIFT is also providing
facilities like Housing, School, Hospital, Hotel and City club.
GIFT City has a committed investment of USD 1.57 Bn with a work force of 10,000
professionals across 225 companies.
(7) Diamond Research and Mercantile (DREAM) City
Diamond Research and Mercantile City - A Smart City being developed close to the
diamond capital of India – Surat, to promote diamond trading from Gujarat at an
estimated project cost of INR 2400 Crore (~USD 350 Million). Spread over 2,000
acres, DREAM City will house an International Diamond Trading Hub and a
Diamond Bourse.
(8) 30,000 MW Renewable Energy Target by 2022
The state has set a massive target to take the renewable energy installed capacity to
30,000 MW by 2022. This capacity shall not only cater to its own requirement of

6|P a g e

<!-- page 7 -->

Gujarat Industrial Policy 2020

renewable power but will also be helpful to other states to fulfill their renewable
purchase obligations.
The state as of July 2022, has an installed renewable capacity of 10,810 MW, which
is ~30% of the total power capacity, which the state aims to take to 40% by 2022.
Work has commenced for a 700 MW park in Raghenesda and land has been
identified for 5,000 MW park in Dholera. The state has also identified and allotted
land and capacity of 30,000 MW to set up a renewable energy park in Kutch district
for development in phases.

Other achievements:
• Ranked as the “Best Performer” in all India State Startup Ranking by Department
for Promotion of Industry and Internal Trade (DPIIT) in year 2018
• Ranked No. 1 in the Logistics Performance Index and LEADS Index by Ministry
of Commerce, Government of India in year 2019
• Ranked No. 1 in the “Composite Water Management Index” by NITI Aayog in
the year 2019
• Gujarat was awarded as the State with the Best Infrastructure, at the India Today
States Conclave 2018 5
• In 2020, 3 cities from Gujarat featured in the top 10 smart city projects of India by
Government of India. The cities included Ahmedabad (1st), Surat (3rd), Vadodara
(6th).
• Gujarat has consistently ranked among top 5 leading Indian states and Top
Achievers as per National EoDB rankings
• As per the study by Oxford Economics, Surat and Rajkot have been rated among
the top 20 fastest growing cities in the world 6
• Gujarat is the first power surplus state in the country. In a recent ranking
conducted in 2020, out of 19 DISCOMs across India, done by an independent
agency called Fitch Group, DISCOMs of Gujarat (UGVCL, PGVCL, DGVCL and
MGVCL) have ranked as the top 4 on key operational and financial performance
indicator. The 4 DISCOMs are also among the 6 DISCOMs of India that have been
awarded A+ credit rating by ICRA and CARE Ratings report prepared by the
Power Finance Corporation.

5
6

India Today State of the States 2018: rankings
Global economic research report, Oxford Economics

7|P a g e

<!-- page 8 -->

Gujarat Industrial Policy 2020

3. Policy Period

This policy shall be valid for a period of five years from 7th August 2020.

4. Vision

To make Gujarat a Global Business Destination for next-generation sustainable
manufacturing & service industry driven by state-of-the art infrastructure,
employment generation, inclusive & balanced regional development and
thereby contribute significantly to “Aatmanirbhar Bharat”.

5. Mission

To promote entrepreneurship & innovation in the state supported by:
• Inclusive & Balanced regional development
• World class infrastructure
• Competitive fiscal incentives
• Ease of doing business
• Strengthen Integrated Value Chains for an Aatmanibhar Bharat
• Employment generation: Direct & Indirect
• Export Competitiveness: Vocal for Local to become Global
• Effective policy implementation

6. Objectives

• To create an enabling business environment facilitated by a single window
system
• To enable industries to set high quality standards and enhance exports
• To have a focused approach for industrially underdeveloped areas & facilitate
inclusive & balanced regional growth
• To promote industries focusing to adopt sustainable, cleaner manufacturing
and innovative Industry 4.0 practices
• To strengthen MSMEs and facilitate cluster development
• To strengthen complete value chain across product segment with focus on the
objective of an “Atmanirbhar Bharat”
• To encourage R&D, innovation and entrepreneurship
• To provide increased impetus to certain Thrust Sectors with significant
potential for employment, exports, investments etc.
• To facilitate growth of Service sector industries in the state
• To facilitate state of the art, sustainable Industrial Infrastructure
• To increase productive employment opportunities in the state

8|P a g e

<!-- page 9 -->

Gujarat Industrial Policy 2020

7. Reforms in regulatory mechanisms for Ease of Doing
Business
The state has undertaken various measures to enhance the “Ease of Doing
Business” experience for existing and prospective enterprises:

a) Gujarat Micro, Small and Medium Enterprises (Facilitation of Establishment
and Operation) Act, 2019:
The main aim of this Act is to facilitate doing business for the MSME sector in the
state of Gujarat. An MSME in Gujarat can now start operation upon receipt of an
acknowledgement certificate from the state nodal agency by submitting the
'Declaration of Intent'. MSME sector is now exempted from taking various
approvals for the first three years. This initiative will smoothen the process of
setting up of MSMEs and this in turn will support in employment generation
within the State.
b) Gujarat Single Window Clearance Act, 2017:
The Act aims to facilitate a process for the speedy issuance of various licenses,
clearances and certificates required for setting up a business unit. The Act defines
four levels of the review committee i.e.
• State Level Facilitation Committee (SLFC) headed by Hon. Chief Minister
• Single Window Facilitation Committee (SWFC) headed by Chief Secretary
• District Level Facilitation Committee (DLFC) headed by Collector
• Investor Facilitation Agency set up at Industries Commissionerate headed
by Industries Commissioner.
The main features of the Act include provision to submit a combined application
form for more than one approval, prescribed timelines for processing of
applications, details of joint periodic inspections to be carried out by the
departments, power to call information etc.
c) Strengthening of the Investor Facilitation Agency (IFA)
Investor Facilitation Agency (IFA) is the nodal agency which operates at the state
level and District Industries Centre (DIC) operates at the district level (regional
offices) for supporting prospective investors in the state. The IFA monitors
applications and provides required information to all the concerned departments.
Nodal officers have been appointed at IFA to provide relevant information to the
investors about doing business in Gujarat. Additionally, the state will be
strengthening the Interactive Voice Response System (IVRS) facility at IFA to
provide necessary response to the investors within the prescribed time limit.
Dedicated “Relationship Managers” will be nominated by Industrial Extension
Bureau (iNDEXTb) for investors as single point of contact for all government
related queries & approvals.

9|P a g e

<!-- page 10 -->

Gujarat Industrial Policy 2020

Mega Online Permission: To further strengthen Ease of Doing Business
Environment in the state, a framework for mega permission is being prepared,
which requires investor to submit only one application form for 26 different state
related approvals and compliances.
Centralized Inspection System: The state has also initiated the process for
streamlining Central Inspection System to further bring transparency and
facilitate ease of doing business.
Besides this, a special committee will be formed at state level in order to accelerate
the process of land procurement and conversion for industries.

8. Focused approach for balanced regional development
Balanced regional development is quintessential to the growth agenda of the
government. It can be achieved by promoting industries in lesser developed areas
which will thereby facilitate optimal utilization of natural and human resources
available in that particular region. Balanced regional development supports
dispersal of industrial employment, reduction of disparity in per capita income
across regions and prevents concentration of industries in a few centers or cities.
Therefore, special enhanced incentives are being provided in the policy to encourage
enterprises to invest in industrially less developed areas. Enhanced package of
incentives will be provided on the basis of Taluka Categories for manufacturing and
service enterprises. This would in turn promote local job creation, infrastructure
redevelopment and thereby give an overall thrust to the local economy of these
areas.

9. Land Banks
The state government has earmarked
land parcels available for industrial
use across the state the details of which
are available on an online portal
https://gujarat.ncog.gov.in/indextb. The
portal provides details of GIDC land
parcels, Private Industrial Parks,
Logistics Parks, SEZs and SIRs.
Government will continuously update
the portal to facilitate the investors with respect to availability of land parcel.

10 | P a g e

<!-- page 11 -->

Gujarat Industrial Policy 2020

10. Availability of Government land on lease for industrial
purposes

In order to further attract industries to invest in Gujarat, the government will
facilitate industries in getting “Government Land” on lease to industrial enterprises
at 6% of market rate for long term upto 50 years for setting up an industrial project.
The lease can be further extended after 50 years based on the prevailing government
policy. The decision to grant government land will be taken by the High Power
Committee chaired by Chief Secretary to verify the strategic importance of the
project.

11.

Relocation Incentives:

In light of CoVID-19, several industries are planning to relocate their operations
and/or diversify supply chains. Gujarat will offer Special Incentives to such
companies planning to relocate from other countries on a case to case basis.

12. Promotion of Micro, Small and Medium Enterprises
(MSMEs)
MSMEs play a vital role in achieving balanced growth and in creating employment
opportunities. They also form an integral part of the value chain of the larger
industrial ecosystem. As part of this policy, a focused scheme has been developed to
further strengthen the MSME ecosystem in the state. Some of the initiatives already
taken by the Government are enlisted below:
a) Institutionalization of MSME Commissionerate
b) Implementation of Gujarat Micro, Small and Medium Enterprises (Facilitation
of Establishment and Operation) Act, 2019
c) Establishment of MSME facilitation desks in 11 districts
d) Online sanction of incentives
While the MSME growth has been commendable, interventions are required to be
explored in areas such as: sub-optimal scale of operation, need for increasing
exports, need for integration with the global supply chain, access to global markets,
effective management of working capital, availability of skilled manpower and
increasing domestic & global competition. The new definition for MSMEs as
introduced by the Government of India will encourage MSMEs to expand their
operations and increase investment, turnover and exports.
The following initiatives are being taken by the state government to reposition
Gujarat’s MSMEs on a global level & enhance competitiveness:
Capital and Interest Subsidy: Incentives to MSMEs will be provided in terms of
Capital and Interest Subsidy on term loans based on the category of talukas. As per
the revised definition of MSMEs by Government of India, enterprises investing upto
INR 50 crore in Plant & Machinery and turnover upto INR 250 crore have been
categorized as “Medium Enterprises”. Incremental incentives will be provided to
these Medium enterprises.

11 | P a g e

<!-- page 12 -->

Gujarat Industrial Policy 2020

Taluka
Category
Category 1

Capital Subsidy

Interest Subsidy

@25 % of eligible Term Loan @7% of term loan amount
Amount subject to a maximum disbursed with the maximum
amount of Rs. 35 lakhs;
amount of Rs. 35 lakhs per
If the Eligible FCI is over 10 Crores, annum for 7 years
additional INR 10 lakhs will be
given
Category 2
@20 % of eligible Term Loan @6% of term loan amount
Amount subject to a maximum disbursed with the maximum
amount of Rs. 30 lakhs;
amount of Rs. 30 lakhs per
If the Eligible FCI is over 10 Crores, annum for 6 years
additional INR 7.5 lakhs will be
given
Category 3 @10 % of eligible Term Loan @5% of term loan amount
(including
Amount subject to a maximum disbursed with the maximum
Municipal
amount of Rs.10 lakhs;
amount of Rs. 25 lakhs per
Corporation If the Eligible FCI is over 10 Crores, annum for 5 years
areas)
additional INR 5 lakhs will be
given
• 1% additional interest subsidy will be given to SC/ST Entrepreneur/
physically challenged entrepreneur/ Women entrepreneur/ Start Up in
manufacturing sector.
• 1% additional interest subsidy will be given to young entrepreneur below
the age of 35 years on the date of sanction of loan.
• Maximum interest subsidy to be capped at 9% for all the categories.
• The interest subsidy will be so given that in any case, the unit will have to
bear minimum 2% of total interest levied on term loan.
• For Existing units, who switch to Solar Power, Interest Subsidy will be
provided on term loan as per rates specified above.
Quality Certification: With a vision to encourage domestic products to be globally
competitive, the policy will promote quality certifications under Zero Defect Zero
Effect (ZED scheme) and also support to obtain ISI/WHO-GMP/Hallmark
certifications & other national/International certification from Quality Council of
India.
The policy will provide fiscal support upto 50% of fee payable to Recognized
International Certification Authority and 50% cost of testing equipment and
machinery required for that certification, totalling upto maximum amount of INR 10
lakhs. For ZED certification, MSMEs can avail assistance upto 50% of certification
cost maximum upto INR 50,000 after deducting the assistance received from
Government of India.
Information & communication Technology adoption: Financial assistance for
installation of Enterprise Resource Planning (ERP) System & Adoption of other ICT

12 | P a g e

<!-- page 13 -->

Gujarat Industrial Policy 2020

platforms & facilities. MSMEs can avail an assistance of upto 65% of capital cost upto
INR 1 lakh for implementing ERP system from the approved ERP service provider
by Industries Commisionerate. For implementing ICT facilities, the MSMEs can
obtain assistance upto 65% of capital cost upto INR 5 lakhs.
Technology Upgradation & Acquisition Support: In order to keep pace with the global
manufacturing trends, the manufacturing sector needs to adopt latest technologies. With
an aim to encourage innovation and adoption of sophisticated technologies by
MSME, the state will provide fiscal support to industries in acquiring technologies
from recognized institutions as well as in acquisition of patented technologies from
foreign companies. MSMEs will get assistance upto 65% of the cost payable to the
institution upto INR 50 lakhs for acquisition of technology.
Patent Support: The policy will provide financial support through partial
reimbursement of cost for filing of domestic patents and international patents upto
75% of the cost/expenditure incurred subject to a maximum of INR 25 lakhs.
Maximum fee for attorney for national patent is INR 50,000 and international patent
is INR 2,00,000 within the overall cap of 75% of the cost/expenditure. Process
Patents will also be made eligible under this benefit.
Market Development Assistance: For positioning of Gujarat based companies at a
global level, the policy will support domestic MSMEs & startups for participation in
national and international level exhibitions organized in India and abroad.
Category

Incentives

Can be applied directly by the individual exhibitor/association
Participation • State Level exhibition- assistance @75% of Stall rent upto Rs. 50,000
• National Level exhibition- assistance @75% of Stall rent upto Rs. 1 lakh
in exhibition
• International Level exhibition- assistance @75% of Stall rent upto Rs. 2 lakhs
within India This can be claimed a total of 5 times by individual unit/ association during the
policy period

Participation International Level exhibition Outside India
in exhibition
• Assistance @60% of Stall rent upto maximum of Rs. 5 lakhs
This can be claimed 3 times by an individual unit/ association during the policy
outside
period
India
Organizing
exhibition
60% of Bill electricity consumption
within
Gujarat
Raising capital through SME Exchange: This assistance would support in raising
funds through SME exchange on one time basis. SMEs can avail upto 25% of
expenditure incurred on raising of equity capital through SME exchange maximum
up to INR 5 lakhs on one time basis.
MSME Awards: The awards will be earmarked for achieving excellence through
Growth in production and profit, Quality improvement measures, Environment

13 | P a g e

<!-- page 14 -->

Gujarat Industrial Policy 2020

improvement measures and Innovation and new product/process/technology
development
Energy & Water Conservation: The assistance will be provided for conducting
audits for energy and water conservation as well as for purchase of equipment. The
policy will provide assistance upto 75% cost of energy / water audit conducted by a
recognized institution / consultant subject to maximum INR 50,000 and 25% of cost of
equipment recommended by the auditing authority subject to maximum INR 20
lakhs.
Collateral free loans: The policy will provide assistance for Collateral free loans
under CGTMSE scheme of Government of India.
Service line & Power connection charges: The policy will provide assistance for
service line and power connection charges, rent etc. at 35% of charges paid to
distribution licences for LT/HT service line, maximum limit up to INR 5 lakhs.
Promotion of Women entrepreneurs, SC/ST entrepreneurs, physically challenged,
young entrepreneurs and Startups: The State Government shall provide additional
incentives under new industrial policy for Women entrepreneurs, SC/ST
entrepreneurs, physically challenged entrepreneurs and startups.
In order to promote inclusive growth of industries and encourage SC/ST
entrepreneurs, a separate scheme “Bharatratna Dr. Babasaheb Ambedkar Udyog
Uday Yojna for SC/ST Entrepreneurs of MSMEs” will be continued with increased
incentives.

13.

Use of Rooftop Solar Power by MSMEs

14.

Promote Startup & Innovation

In order to encourage MSME for reduction of electricity cost, the state had
introduced a special Solar policy under which MSME are eligible to set-up rooftop
solar power and provision is made to purchase surplus power from them.
Considering the difficulties faced by MSME units, government with a view to
further ease the process of utilizing rooftop Solar Power in MSMEs, has increased
the power cycle for calculation of consumption of units from 15 minutes to 11 hours
i.e. 7 AM - 6 PM and has been increased the price for purchase of surplus solar power
from MSMEs, from INR 1.75/unit to INR 2.25/unit.

Gujarat, owing to its inherent strength of widespread entrepreneurial spirit has
gained a significant spot in the national startup ecosystem. The incentives under the
previous scheme created a strong network of nodal institutions. This supported
several startups in setting up/expanding their operations both in national and
international markets.
The new scheme aims to further accelerate and strengthen the startup ecosystem in
the state.

14 | P a g e

<!-- page 15 -->

Gujarat Industrial Policy 2020

Sustenance Allowance: Startups can avail sustenance allowance of INR 20,000 per
month for one year. Startups having at least 1 woman co-founder will be eligible for
sustenance allowance of INR 25,000 per month for one year.
Seed Support: Startups can avail seed support upto INR 30 lakhs for product
development, marketing and professional assistance. Additional grant of upto INR
10 lakhs may be availed by startups with significant social impact.
Soft Skill Assistance: In order to train the startups to compete at global level,
startups can avail reimbursement upto INR 1 lakh per startup for trainings in soft
skills.
For mid-level Pre-Series A funding of startups, a separate fund shall be created
under Gujarat Venture Finance Limited (GVFL) for smaller ticket funding between
INR 50 lakhs to INR 3 crore.
Acceleration Programs: Dedicated acceleration programs will be conducted in the
state as per the provisions of the scheme. Additionally, the policy would support
startups upto INR 3 lakhs to attend other national/international acceleration
programs. The policy will also support in organizing acceleration programs.
Promotional Events: The scheme aims to organize focused workshops, seminars,
bootcamps, hackathons, grand challenges etc. across the state with support from
various stakeholders. For this, the policy will provide support upto 75% of the total
expenditures upto INR 5 lakhs. However, in case of events specific to women
entrepreneurship, the policy will support upto 90% of total expenditures upto INR
5 lakhs.
Nodal Institutes and Mentoring Assistance: The Gujarat Startup Cell would also
identify and establish association with Nodal Institutes across the state. Fiscal
support to these Nodal institutes mentoring approved startups will also be given as
part of the policy. Mentoring assistance of INR 1 lakh per startup will be given to
Nodal institutes upto a maximum of INR 15 lakhs per annum.
In addition to this, a dedicated portal detailing the facilities of various nodal
institutes and Government bodies will be created for the startups to avail them.
These facilities include: testing labs, 3-D printing, library, co-working space etc. at a
subsidized rate. Moreover, “Gujarat e-marketplace” will be made operational on
the Startup Gujarat Portal, where the startups supported by state government can
promote their products and services.

15.

Support for Research & Development in state

In order to support the Research and Development in the state, the policy will
provide assistance to R&D institutions / laboratories set up with State Government
or Government of India including setting up of new R&D institutions /laboratories.
For Private Institutions/ Companies who wish to set up Research & Product
Development center in the state, the policy will provide assistance upto 30% of the
project cost of machinery and equipment maximum upto INR 5 crore.

15 | P a g e

<!-- page 16 -->

Gujarat Industrial Policy 2020

Policy will also provide assistance in setting up of laboratories established by
Industries Association with the help of Government up to 60% of the project cost of
machinery and equipment cost.
Besides this, in order to promote contract research, the government will provide
assistance for Contract/Sponsored research work from any industrial
enterprise/Industrial association to recognized R&D institution / technical collages
approved by AICTE, at 50% of project cost, excluding cost of land and building,
subject to maximum INR 50 Lakhs.

16. Special focus on promotion of Service Sector MSMEs

Service sector is a major contributor to the national GDP. Many services are key
inputs for facilitating primary and secondary industries. Thus, the service sector is a
critical lever for enhancing productivity, ease of living and livelihood. With the
establishment of several SEZs, IT parks and most importantly, GIFT City, a
conducive ecosystem exists for the service sector industries to expand operations in
the state. Hence, it is decided to extend incentives to Service sector covered in
MSME. In view of the potentiality of service sector, it has been decided to widen the
scope of service sector. Besides the 22 service categories already defined in the
Gujarat Industrial Policy 2015, following champion services are identified to cover
them under eligible service sector for incentives:
1. Financial services
2. Health services
3. Transport and logistics services
4. Audio Visual services
5. Construction related engineering services
6. Environmental services
Taluka Category
Category 1
Category 2

Interest Subsidy
@7% of term loan amount disbursed with the
maximum amount of Rs. 35 lakhs per annum for 7 years
@6% of term loan amount disbursed with the
maximum amount of Rs. 30 lakhs per annum for 6 years
@5% of term loan amount disbursed with the
maximum amount of Rs. 25 lakhs per annum for 5 years

Category 3 (including
Municipal Corporation
areas)
• Additional 1% subsidy will be given to SC/ST entrepreneurs
• The interest subsidy will be so given that in any case, the unit will have to bear
minimum 2% of total interest levied on term loan.

17. Promotion of Thrust Sectors:

•

In line with the mission of Atmanirbhar Bharat, the state has identified 15 thrust
sectors for industrial promotion. The sectors have been segregated in 2 categories:
Core sectors: These are sectors where Gujarat already holds a leadership position in
the country. The policy will give a further boost to these sectors to empower global
competitiveness of Gujarat’s industrial ecosystem in these sectors. It is realized that

16 | P a g e

<!-- page 17 -->

Gujarat Industrial Policy 2020

•

Gujarat’s strong position can be capitalized to have a multiplier effect and thus
achieve stronger growth.
Sunrise sectors: These are sectors that are upcoming/ niche sectors in India & around
the globe. This policy provides specific incentives and provisions for creating an
enabling ecosystem for their establishment in the state. The intention is to make the
state more competitive and lucrative than other similar regions/ geographies

Core
Sectors

Sunrise
Sectors

18.

1.
2.
3.
4.
5.
6.
7.
8.
9.
1.
2.
3.
4.
5.
6.

Electrical machinery & equipment
Industrial Machinery & equipment
Auto & Auto Components
Ceramics
Technical Textiles
Agro & Food Processing
Pharmaceuticals & Medical devices
Gems & Jewelry
Chemicals (in designated area)
Industry 4.0 manufacturing
Electric Vehicle and its components
Waste management projects
Green Energy (Solar & Wind Equipment)
Eco-friendly compostable material (substitutes to traditional plastics)
100% export oriented units, irrespective of sector

Attracting Large/Mega and Ultra-Mega Investments

Large industrial enterprises have an important role in development of industrial
ecosystem of an area. Besides generating revenue for the state government and
creating local employment, large industries are also beneficial in bringing high-end
technologies. They also aid in generation of ancillary industry around them thereby
having a multiplier effect on employment, revenue and overall growth.
Gujarat has been successful in attracting large sector investments in the states. The
state had ~51% share (1st Rank in India) of IEMs filed in India in terms of value with
a proposed investment of USD 49 Bn in 2019 as per the data released by DPIIT,
Government of India. This can be attributed to the proactive business friendly
approach of the Gujarat Government focusing on “Minimum Government –
Maximum Governance”.
Since GST has been implemented, companies are being compensated as per “Net
SGST” on goods sold within the state under the Industrial Policy-2015. There were
several complexities in calculation of the tax of goods consumed within the state and
procedure was very cumbersome to claim reimbursement every quarter.
Hence, Gujarat is the first state to undertake a bold decision to de-link incentives
from SGST. In order to bring transparency in calculation, it has been decided to
extend incentives based on eligible Fixed Capital investment (FCI) to large industries
for setting up manufacturing operations in the state in the form of capital subsidy.
Therefore, the incentive amount will now be more predictable and transparent and
thus it will help industry to estimate their future financial projections.
There is no upper ceiling on the amount of incentive to be given to any particular
unit. This will help in grounding major investments in the state.

17 | P a g e

<!-- page 18 -->

Gujarat Industrial Policy 2020

A graded incentive structure for General Sector and Thrust Sector is defined as per
the category of talukas as under:
Taluka Category

General Sectors

Thrust Sectors

Category 1

•

10%
of
eligible
(excluding land)

FCI •

12% of FCI
(excluding land)

eligible

Category 2

•

8%
of
eligible
(excluding land)

FCI •

10% of FCI
(excluding land)

eligible

Category 3

•

4%
of
eligible
(excluding land)

FCI •

6%
of
FCI
(excluding land)

eligible

•

The eligible cash subsidy will be given over a period of 10 years in equal annual
instalments subject to annual ceiling of INR 40 Crore.

•

If the total eligible cash subsidy could not be disbursed within period of 10 years
due to upper ceiling of INR 40 cr. per annum, the eligible period will be extended
further maximum upto 10 years additionally subject to the condition that annual
ceiling will remain INR 40 cr. per annum during additional period also.

•

In case, if the total eligible cash subsidy is not disbursable within period of 20
years due to upper ceiling of INR 40 cr. per annum, the total entitlement of cash
subsidy will be disbursed in equal installments of 20 years without any upper
ceiling.

•

The SME enterprises are entitled to opt for this scheme subject to condition that it
will not be eligible for cash subsidy and interest subsidy under the incentive
scheme of MSME under Gujarat Industrial Policy-2020.

19.

Conducive Industrial Infrastructure

Quality infrastructure is a key driver for industrial growth. Although Gujarat has
one of the best industrial infrastructures in place, concerted efforts will be made to
further strengthen state-of-the-art infrastructure in the industrial estates spread
across the state. GIDC will continue to be the dedicated agency for developing
necessary industrial infrastructure. For supporting industrial infrastructure &
developing last-mile connectivity, incentives have been formulated under Industrial
Infrastructure scheme.
A dedicated organization “GARUD” has been formed by the state government to
ensure easy movement of goods (inter & intra) state and increase exports. The
infrastructure created under this authority will support industries to incur less
production costs and therefore will have a competitive edge against other
developing economies.
Industrial infrastructure: The policy will support in setting up new infrastructure
or upgradation of existing infrastructure like roads, warehousing facilities, fire
stations, underground utilities etc. at 80% of the Project Cost upto INR 25 crore.

18 | P a g e

<!-- page 19 -->

Gujarat Industrial Policy 2020

Establishment of Industrial Parks by Private Investors: The state encourages the
establishment of Industrial Parks by private investors. Private participation in
infrastructure development helps bring the latest technologies and facilities. The
policy aims to incentivize cost of the building, infrastructure facilities and other
facilities as may be required for the development of such parks at 25% of Fixed
Capital Investment upto INR 30 crore for parks developed on minimum area of 20
hectares & minimum 10 units. For private investors setting up industrial parks in
Vanbandhu Talukas, incremental support will be provided at 50% of Fixed Capital
Investment upto INR 30 crore for parks developed on minimum area of 5 hectares
& minimum 5 units.
Dormitory Housing: In order to provide better living conditions to industrial
labourers, special incentives will be provided for the construction of “Dormitory
housing” for labourers in industrial clusters by Association. It will be encouraged by
inclusion of this facility under common infrastructure to extend financial assistance.
However. such association shall have to first avail incentives available under
different schemes of State government or Central government.

20.
Support for Environmental Infrastructure & Initiatives
for Sustainable Development

For long term sustainability, industrial development must be based on optimum use
of natural resources. The decoupling of environmental degradation from economic
growth is another key objective. In order to encourage greater compliance with
environmental standards & support development of latest sustainable industrial
infrastructure to reduce air and water pollution, the policy will provide incentives
for:
•

•

•

•

•
•

Common Environmental Infrastructure Facilities such as Common Effluent
Treatment Plant, Waste Management System, augmentation and technology
upgradation of existing CETPs, common spray dryer, common multiple effect
evaporator etc. at 40% of the project cost upto INR 50 crore. Total support by
Government of India and Government of Gujarat shall not exceed 75% of the
total fixed capital investment.
Industries practicing at least 50% waste recovery through Zero Liquid Discharge
as certified by GPCB shall be provided upto 50% of capital subsidy on cost of
relevant equipment upto INR 75 lakhs.
Development of Green Estate at 25% of project cost for set up/ relocation /
retrofitting of existing polluting industrial units into Green Industrial Estates
upto INR 25 crore. The policy will also provide assistance up to 75% of cost for
preparation of site master plan for relocation and retrofitting of existing pollution
industrial units into Green Industrial Estates upto INR 80 lakhs.
Common Boiler Project by SPV constituted by minimum 10 MSME’s, at 35% (in
case of solid fuel) and 50% (in case of cleaner fuel) of the fixed installation cost
upto INR 2 crore.
Strengthening the Regulation & Environmental Compliance
Implementation of cleaner production technology in place of existing process
such as substitution & optimization of raw material, reduction in water

19 | P a g e

<!-- page 20 -->

Gujarat Industrial Policy 2020

•

•
•
•
•
•

•

21.

consumption or energy consumption or waste generation, at 35% of cost of Plant
& Machinery to MSMEs and 10% of cost of Plant & Machinery to large enterprises
with maximum support upto INR 35 lakhs.
For environment management project with use of clean, Efficient and Innovative
Pollution Control Equipment the policy will provide assistance at 25% of cost of
Plant & Machinery to MSMEs and 10% of cost of Plant & Machinery to large
enterprises with maximum support upto INR 35 lakhs.
Encouraging “Green Practices & Environmental Audit to MSMEs” upto 75% of
fees of audit services upto INR 50,000
Installation of online Continuous Stack Emission Monitoring Systems (CEMS)
upto 25% of cost of system upto INR 25 lakh
Industrial Building with green rating under Indian Green Building Council upto
50% of consulting charges upto INR 2.5 lakh
Encourage existing industries to shift the unit outside the urban agglomerations
Setting Up of Environment Management System including setting up of
Environment Management Laboratory upto 50% of cost of equipment upto 10
lakh
Purchase of new equipment/system related to safety, occupational health or for
environment compliances for common use of industries located in cluster upto
35% of cost of equipment upto 35 lakh

Skill enhancement

The overall economic growth has increased the demand for skilled and trained
manpower. Therefore, the Gujarat Industrial Policy 2020 lays a strong emphasis on
expanding the skill base in the state. The State has attracted large number of
investments in the past, yet there has been a shortage of sector-specific high-quality
manpower. The State Government has taken proactive steps to train manpower for
focus sectors with greater investment from private sector. Therefore, the Industry
Policy aims to incentivize those investments which enhance the sector-specific
skilled manpower base. A large demand for skilled trained manpower is likely to
further emerge from manufacturing and services sector. The State Government
intends to introduce industry-specific short term/ long term/ modular courses in
the existing ITIs, Polytechnic and Engineering colleges with active participation of
the user industry in defining the training needs and formulating the course material.
Anchor institutes would be selected with a view of new emerging sectors to
formulate industry-responsive curriculum, need-based training and relevant skill
development for trainers. The policy encourages anchor institutes to impart
additional training programs with a minimum duration of 40 hours and minimum
number of 10 trainees.
Gap analysis of skill requirement of industries & available workers across various
sectors in the state will be carried out which will help the state in creating a roadmap
for training manpower in relevant skills. This will also help in training and retraining the workforce in line with shifting technological trends.

20 | P a g e

<!-- page 21 -->

Gujarat Industrial Policy 2020

22.

Export Promotion

Gujarat is one of the leading export states of India accounting for over 20% of the
national export basket. The state government will continue to promote exports by
facilitating & handholding the exporters and export-oriented units. The following
steps are being taken up by the Government to this effect:
Export Promotion Councils: The government will partner with leading national and
state level export promotion councils for a comprehensive facilitation and export
promotion initiative.
Awareness and trainings: A robust information dissemination mechanism will be
set up in partnership with Ahmedabad Management Association (AMA) to publish
informative documents, trade guides, promotional material and conduct
appropriate capacity building and orientation workshops for exporters and other
promotional seminars.
International Access: Exhibitions and trade fairs are an important platform for
companies, particularly MSMEs to network and promote their product(s)/ services
to a wider audience. The policy aims to support traders to participate in national and
international exhibitions and trade fairs.
Grievance Redressal: A robust grievance redressal mechanism will be set up under
the Export Commissioner to address the concerns of enterprises and to ensure timely
redressal of the same.
Logistics: Gujarat has been consistently ranked top state in Logistics Ease Across
Different States (LEADS) index by the Government of India. The state will continue
to take steps to have seamless good quality logistics infrastructure for promotion of
trade.
Infrastructure: The policy aims to support setting up of exhibition cum convention
centers at all product clusters for MSMEs and exporters to conduct exhibitions and
display their products.

23.

Conclusion

Gujarat Industrial Policy 2020 is indeed a game changer. Never before stand out
features like offering land on lease, de-linking of incentives from tax structure and
replacing it with capital subsidy without any upper ceiling will attract many a soul
to take the entrepreneurial path. Industrial Policy 2020 spearheads balanced regional
development and is the torchbearer for inclusive growth. The policy will ensure to
establish Gujarat on the world map as the best business destination, thereby making
Gujarat – “The Business Card of India”.

21 | P a g e

<!-- page 22 -->

Gujarat Industrial Policy 2020

24.

Abbreviations

AMA:
ASI:
CEMS:
CGTMSE:
CoE:
CRM:
DFC:
DGVCL:
DIC:
DISCOM:
DMIC:
DPIIT:
EoDB:
EV:
FDI:
GDP:
GEM:
GHG:
GIDC:
GIFT:
GoG:
GoI:
GSDP:
GVFL:
GW:
IFA:
IFP:
INR:
ITeS:
ITI:
IVRS:
JICA:
LEADS:
MBSIR:
MGVCL:
MSME:
PCPIR:
PGVCL:
PMG:
SEZ:
SIR:
UGVCL:
USD:
ZED:

Ahmedabad Management Association
Annual Survey of Industries
Continuous Stack Emission Monitoring Systems
Credit Guarantee Scheme for Micro and Small Enterprises
Centre of Excellence
Customer Relationship Management
Dedicated Freight Corridor
Dakshin Gujarat Vij Company Ltd.
District Industries Centre
Distribution Company
Delhi - Mumbai Industrial Corridor
Department for Promotion of Industry and Internal Trade
Ease of Doing Business
Electric Vehicle
Foreign Direct Investment
Gross Domestic Product
Gujarat e-Marketplace
Green House Gasses
Gujarat Industrial Development Corporation
Gujarat International Financial Tech City
Government of Gujarat
Government of India
Gross State Domestic Product
Gujarat Venture Finance Limited
Giga Watt
Investor Facilitation Agency
Investor Facilitation Portal
Indian National Rupee
IT enables Services
Industrial Training Institute
Interactive Voice Response System
Japan International Cooperation Agency
Logistics Ease Across Different States
Mandal Becharaji Special Investment Region
Madhya Gujarat Vij Company Ltd.
Micro, Small and Medium Enterprises
Petroleum, Chemicals and Petrochemicals Investment Region
Paschim Gujarat Vij Company Ltd.
Piped Natural Gas
Special Economic Zone
Special Investment Region
Uttar Gujarat Vij Company Ltd.
US Dollar
Zero Defect Zero Effect

22 | P a g e

<!-- page 23 -->

Gujarat Industrial Policy 2020

We welcome you to be our partners in progress.

Industries Commissionerate
Industries and Mines Department
Government of Gujarat
comind@gujarat.gov.in; 079-23252524
23 | P a g e
