---
doc_id: "fcefd924afc2edd5"
source_url: "http://incometaxgujarat.gov.in/uploads/documents/circular_585.pdf"
ministry: "Income Tax Department, Gujarat Region"
title: "Registration of Valuers under section 514 of the Income-tax Act,2025 updation of registration by existing Valuers registered under the Wealth-tax Act,1957 filing of Form No. 169 on or before 30.09.2026"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4194ecfc9153eb46"
---

<!-- page 1 -->

flT{A $G5TT /Go*.of India
ctrrrn TUq srrrlrFT 3n:ffi,zJilrd -,1 6.rqttq
Office of the Principal Chtef Commissioner of Income tax, Guiarat
}ifril, 3Trq?FT lrir?T,3TTrtrfr tlg, srrrqrqE -380 009.
6rilI i'. z0z,
Room No. 202, Aayakar Bhavan, Ashram Road, Ahmedabad - 380 009
({$Fr: Tele. : (079) 2969 SLz3trg rax z (O79) 2g6s 5023
.ln
E-mail Id: ahmeda
Datezl3/oBl2O26
No. PCCIT-GU[/HQ/DC-Co.ord./ Valuers-Sl4 /2026'27
g

qrt

S

S

CIRCULAR

Subiect Registration of Valuers under section 514 of the Income-tax Act,2025 updation of registration by existing Valuers registered under the Wealth-tax Act,
fiting of Form No. 169 on or before 30.09.2026 - regarding.
L957

-

Reference: Section 514 of the Income-tax Act, 2025; Rule 246 and Rule 247 of the
Income-tax Rules, 2026.

l.

Attention of all Valuers registered underthe Wealth-taxAct, '1,957 and holding a valid
certificate of registration as on 31.03.2026, is invited to the provisions of section 514
of the Income-tax Act, 2025, read with Rule 246 of the Income-tax Rules, 2026,
governing registration of Valuers.

Z, As per sub-rule ( ) of Rule 246 of the Income-tax Rules, 2026, every person who is

already registered as a Valuer under the Wealth-tax Act, t957, holding a valid
certificate of registration as on 31.03.2026, shall continue to be a registered Valuer
under section 51.4 of the Income-tax Act, 2025. However, such person is required to
update his/her details by filing a fresh application in Form No. 169 on or before
30.09.2026, and the registration shall be granted by the concerned authority under
section 5L4 upon such application being found complete in all respects'

3. As per sub-rule (5J of Rule 246 ibid, no fee is payable for filing of the said application
by existing valuers for the purposes of updation of registration.

4. AII Valuers registered under the Wealth-tax Act, 1957 and falling within the ambit of
this circular are accordingly required to file the updated application in Form No' 169,
complete in all respects along with the requisite documents, with the concerned
principal Chief Commissioner/Chief Commissioner or Principal Director
General/ Director General, latest by 30.09.2026'

S. It is hereby clarified that in case any Valuer fails to file the application in Form No'

169 on or before 30.09.2026, the registration of such Valuer under section 514 of the
Income-tax Act, 2025 shall be deemed to be cancelled with effect from 01.10.2026,
and such person shall thereupon cease to be a registered Valuer for all purposes
under the Act.

<!-- page 2 -->

6. All Valuers are, therefore, advised to take note of the above and ensure timely
compliance so as to avoid cancellation of their registration.

[Kalpesh Kavad)
Tax
of
Income
Dy. Commissioner
[HQJ(Co-ord)
For, Pr. Chief Commissioner of Income Tax,
Gujarat, Ahmedabad
Copy to:

1. The Chief Commissioner of Income Tax-1 Ahmedabad/Surat/Rajkot.
3. The Director General of Income Tax (lnv), Ahmedabad
4. The Pr. Commissioner of Income Tax-1. /3 Ahmedabad
5. The Pr. Commissioner of Income Tax -1 Rajkot/surat/vadodara
6. The Pr. Commissioner of Income Tax - lamnagar fValsad
T. Webmaster, Of o PT.CCIT, Gujarat - for uploading on the official website of the
Income Tax Department, Gujarat
7. Notice Board.
