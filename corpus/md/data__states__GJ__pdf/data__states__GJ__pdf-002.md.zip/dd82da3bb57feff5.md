---
doc_id: "dd82da3bb57feff5"
source_url: "https://www.cugujarat.ac.in/AllDocuments/Downloads/Notification/Notification_BoS_Physical-Education.pdf"
ministry: "Childrens University, Gandhinagar, Gujarat"
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "242ba2c83214931f"
---

<!-- page 1 -->

Ch@'a

u-N-t-v-E-R-s-t-T-Y

Formation of Board of
Studies for Physical
Education at CRU
No: CRU/Academic/2025/1 5
Datez 2910112025
Read: l) Approval of Competent Authority dated28l0l12025 on concerned file

'

'

Notification
It is hereby notified that Hon'ble Vice Chancellor accented to constitute the following Board of Studies
for Physical Education at Children's Research University.
Name of the Member

Sr.No.
I

Dr. Shilpa Vala, Assistant Professor,
Children's Research University,
Gandhinagar, M. 7 698961 096,
Email : smvala.vnk@cuguiarat.ac.in

2

Gandhinagar, M. 98250 1 61 62,
Email: mmpatel.vnk@cuguiarat.ac.in

Designation
Chairperson

Programme

Dr. Mahendra Patel, Assistant Professor, Not more than two faculty

Children's Research University,
3

Provision of the Constitution
The Head of the University
Departments in the concerned
subject or group of subjects or

Member

members nominated by the ViceChancellor by rotation from the

concerned subject or group of

Dr. Neeraj Silavat, Professor, Faculty of subjects/programme of
Physical Education and Sports Science University
Gujarat Vidyapith Sadra Ta. Dist.

the

Member

the
subject/programme or in subject's
cognate or allied to the subject/
programme; and

expert in

Member

One expert in the profession or
industry concerned with the

Member

Gandhinagar

M. 9 426021 84 5, 87 7 020127 9
Email nirai. silawat@suiaratvidyapith.org
Dr. Om Prakash Mishra
Associate Professor , Department of Physical
:

4

Education, Swarnim Gujarat Sports

University, Desar, Vadodara, M. 940901 0501
Email: dr.omprakashmishra@smail.com

5

Dr. Dinesh Parmar, Sr. PTI, IITGN,
Gandhinagar, M. 98987 5427 9,
Email : dparmar@iitgn.ac. in

6

One

subject/programme.

Ms. Shweta Malik, Assistant Professor,

Children's Research University,

Member

Concerned Subject Teacher

Secretary
Gandhinagar, M. 954 I 179464,
Emai I : swetamal ik@cuguiarat.ac. in
It is further notified that the term of the said Board of Studies for Physical Education is 03 years from
the date of notification.

AHux

Registrar (I/c)
Children's Research University
Gandhinagar
To

All the above Members of the Board of Studies for Physical Education

Subhesh Ch.ndm Bco Shakshan Sankul, Nr. Rajbhavan, CHH Road, S€ctor-2o, Gatrdhinaga.-382o21
Ph. 079-2321 4516 M.cugura6t.ac.ln
