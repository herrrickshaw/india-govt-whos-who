---
doc_id: "1be40f5f7ebc1f0e"
source_url: "https://panchayat.gujarat.gov.in/panchayat/documents/Deputy-Chitnis-Departmental-Examination-Rules-2002.pdf"
ministry: "Panchayats and Rural Housing Department, Gujarat"
title: ""
date: ""
pages: 29
method: "pdftotext"
script: "GUJARATI"
needs_ocr: false
sha1: "57de3b1ff6757ab8"
---

<!-- page 1 -->

Extra NG

REGISTERED No.

G/GNR/2

सत्यमेव जयते

The Gujarat Government Gazette
EXTRA ORDINARY
PUBLISHED BY AUTHORITY
Vol. XLIII

TUESDAY, AUGUST 20, 2002/SRAVANA 29, 1924

Separate paging is given to this Part in order that it may be filed as à Separate Compilation.
PART I-А
CENTRAL SECTION

Order and Notification (Other than those published in Part IV-B)
under the Gujarat Local Boards, Village Panchayats, Municipal
Boroughs, District Municipal, Primary Education and Local
Fund Audit Acts.

PANCHAYATS, RURAL HOUSING AND RURAL DEVELOPMENT DEPARTMENT
Notification

Sachivalaya Gandhinagar, 20th August, 2002.
GUJARAT PANCHAYATS ACT, 1993.
No. KP/53/2002/PER/1396/716/11-3/D.-In excrcise of the powers conferred by sub-section

(5) of section 227 read with section 274 of the Gujarat Panchayats Act, 1993 (Guj. 18 of 1993) and in
supersession of the existing rules made in this regard the Government of Gujarat hereby makes' the

following rules, for regulating the conditions of service of persons appointed to the post of Deputy
Chitnis in the Panchayat Service, namely:-

1. Short title, commencement and extent :- (1) These rules may be called the Deputy
Chitnis (Panchayat Service),-Departmental Examination Rules, 2002.

(2) They shall come into force at once.

2. Definitions :- In these rules unless the context otherwise requires:-

(a)

"Appendix" means the appendix appended to these rules;

(b)

"Board" means the Gujarat Panchayat Service Selection Board.

(c) "Direct Recruit" means a person appointed to the post of Deputy Chitnis
(Panchayat Service) otherwise than by promotion from a lower post;

(d)

"Examination" means the departmental examination prescribed under these

(e)

"Old Rules" means the Gujarat Panchayat Service Senior Clerk and Deputy

rules;

I-A-Ex.-78-1

78-1

く

<!-- page 2 -->

78-2

GUJARAT GOVERNMENT GAZETTE, EX., 20-8-2002

[PART I-A

Chitnis, deputy Mamlatdar, Assistant Taluka Development Officer, Deputy Taluka De-

velopment Officer and Taluka Panchayat Officer Qualifying Examination Rules, 1976.

"Specified Chances" means the number of chances specified in rule 5 in which

(f)
a person is

(g)

required to pass the examination;

"Specified Period" means the period Specified in these rules within which a

person is required to pass the examination.
3.
rules:-

Requirement of passing of the Examination :- (1) Subject to the provisions of these

>(a)

every direct recruit, appointed to the post of Deputy Chitnis (Panchayat Service) after commencement of these rules, shall be required to pass the examination dur-

ing probation period, within specified chances;

(b)

a direct recruit, appointed before commencement of these rules and who has

not passed the departmental examination held under the old rules; shall be required to

pass the examination within specified chances;

(c) a person who, before the commencement of these rules, is appointed by promotion to the post of Deputy Chitnis (Panchayat Service), and has not passed the

Departmental Examination held under the old rules, shall, unless he has been exempted

from passing such examination under these rules be required to pass the examination

within specified chances from the date of his completing five years' continuous service

from the date of promotion, or from the date of commencement of these rules, whichever
is later.

(2) If the specified period expires before the date of commencement of the examination in

which a candidate had his last chance, in such cases, such period shall be deemed to have been ex-

tended upto the date of the declaration of the result of the examination so held.

(3)

If the direct recruit fails to pass the examination within the specified period, such specі-

fied period may, if in the opinion of the Govermment, his services were otherwise satisfactory, be

extended to one year to enable him to pass the examination in not more than specified chances, including the chances exhausted earlier.

(4) Where a person does not seek permission to appear in, the examination or after granting
such permission, he does not appear in the examination held after commencement of these rules, he
shall be deemed to have exhausted a chance to appear at the examination.
(5)

A person appointed to the post of Deputy Chitnis (Panchayat Service) other than by direct

recruitment shall not be entitled to appear at the examination, if any, prescribed for Senior Clerks
(Panchayat Service), or has been exempted from passing such examination.

4.

Exemption :- A person who has passed the departmental examination heid under the old

rules or who was exempted from passing such examination under the provisions of the old rules, shall
be exempted from passing the examination under these rules.

5.

Specified chances: (1) A person shall be required to pass the examination in three

successive chances (four successive chances in case of persons belonging to Scheduled Castes or

Scheduled Tribes or Socially and Educationally Backward Classes).

(2)

The chances, already availed of under the old rules before the commencement of these

rules, shallbe counted as chances having been availed of under these rules.

Consequences of failure to pass the examination: If a direct recruit fails to pass the
examination within specified chances, his services shall be terminated forthwith from the date of
6.

declaration of the result of the examination:

<!-- page 3 -->

CENTRAL SECTION] GUJARAT GOVERNMENT GAZETTE, EX., 20-8-2002

78-3

Provided that if in the case of any such person, the State Government or such officer authorised

by Government in this behalf, is satisfied that he could not pass the examination, at which he had his
last chance, for the reasons beyond his control or that he failed to pass such examination, by a very
narrow margin of marks. the State Government or such officer authorised by Government in this
behalf may, after recording reasons in writing, give him two more chance to appear at the examination
on payment of the fee payable under rule 7:
Provided further that a direct recruit passing the examination in additional chance, shall not be
given seniority over those who were junior to him but had passed the examination earlier than him.

(2) If a person appointed to a post of Deputy Chitnis (Panchayat Service) by promotio
before:commencement of these rules fails to pass the examination within the specified chances, he
shall, subject to the provisions of rule 9, be reverted to his original post.
(3) Every person who does not pass the examination shall not be eligible for promotio
n to
the higher post subject to the provisions rule 9 and eligible and for confirmation
in the cadre or
Dy.Chi. until he passes the examination.
Additional chances to appear in the examination : Where a person other than-a

7.

direct

recruit, has failed to pass the examination within the specified chances he shall, notwiths
tanding such
failure, be eligible to appear at any time in such examination on payment of examination fees

as may

be prescribed by Government from time to time.

8.

Seniority: A person who fails to pass the examination in specified chances and within
specified period shall be eligible for promotion but shall not be eligible to claim seniority
over those

persons who have been promoted before he became eligible for promotion, an account of their having
passed the examination earlier than he notwithstanding that he was senior to the persons
so promoted
in the cadre from which promotions were given.
9.
Provisional Promotion: If a qualified person is not available for promotion to a
post of
Deputy Chitnis (Panchayat Service) and it becomes expedient to fill the
post in public interest, an
unqualified person belonging to the cadre of Senior Clerk who has not exhausted
specified chances to
pass the examination may be promoted to officiate as Deputy
Chitnis (Panchayat Service) subject to
the condition that-he shall be reverted on the date of the availability of a qualified person
for promotion or on his failurė to pass the examination within the specified period

and chances, whichever event

occurs earlier:

Provided that from the date of commencement of these rules, such unqualif

be granted increments in the time scale for the post from which

ied person shall not

he was promoted:

Provided further that the increments withheld under first proviso shall
be released from the
date of passing the examination but no arrears shall be paid for the
increments so withheld.

Note

"The date of passing the examination" means the date immediately following the date

on which the examination ended.

Explanation: In this rule "qualified person" means a Deputy Chitnis

who has passed the
examination or a person who is exempted from passing the said examination and the expressio
n "an
unqualified person" shall be construed accordingly.

10.

the year,

Holding of the Examinations : (1) The examination shall be held by the Board, twice

in

(2) The Board shall publish necessary notice regarding the date of
commencement of the
examination, detailed programme and venue and shall place it on the notice
board of the Board and
shall also send it to all District Development Officers for necessa
ry action.

<!-- page 4 -->

<!-- page 5 -->

2rg
CENTRAL ŠECTION] GUJARAT GOVERNMENT GAZETTE, EX., 20-8-2002

78-5

14. Appointment of Examiner and conduct of Examination :The Board shall decide all

matters relating to the appointment of examiners and conduct of examination in accordance with the

orders issued by the Government in this regard.

15.

Intimation of Examination :

The intimation regarding place and programme of the examination shall be communicated in:

time by the Secretary of the Board to the concerned car.didate through the concerned District Devel

opment Officer. The District Development Officer shall place the details of place and programme oi

the notice board.

16. Declaration of result of the examination :
The Board shall declare the result of the examination in the Gujarat Govemment Gazette ancd
communicate the same to the Government and the District Development Officers.

17.

Repeal and Saying :

The Gujarat Panchayat Service Senior Clerk and Deputy Chitnis, Deputy Mamlatdar, Assistant Taluka Development Officer, Deputy Taluka Development Officer and Taluka Panchayat officer.

Qualifying Examination Rules, 1976 are hereby repealed. Such repeal shall not affect anything done
or any action taken or initiated under the rules so

I-A-Ex.-78-2

repealed.

<!-- page 6 -->

78-6

GUJARAT GOVERNMENT GAZETTE, EX., 20-8-2002

[PART I-A

APPENDIX: A

(see Rule 11)
Form of Application

Application for appearing at the Deputy Chitnis (Panchayat Service) Departmental Examination to be held by the Gujarat Panchayat Service Selection Board on
19
1.

Applicant's name in full
(Surname first) in English and Gujarati.

2.

Designation
(In English and Gujarati)

3. (1)

Name of the District

Panchayat to which he belongs.
(2)

Name of the Office where he
is working at present.

4.

Birth date and age at the

time of the examination.

5.

Date of appointment and total
years of service.

6.

Whether he has appeared at

the examination previously?

If so.

(a)

Month and year of examination

:

at which he appeared.

(b)

Whether any exemption is earned?
If so details of marks month and
year of examination and subject

should be given.

(c)

Whether he intends to avail of

exemption earned (yes or no)

(The choice will be treated as

final and no change will be allowed).
7.

Authority or the Rules under which:
he has to appear for the examination.

8.

Number of chances and time limit
within which he is required to pass the
examination (date of eligibility and

expiry of the period for appearing at
the examination should be mentioned).
9.

Number of trials exhausted.

10.

Whether additional (Special)
chances have been granted

:

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

<!-- page 15 -->

<!-- page 16 -->

GUJARAT GOVERNMENT GAZETTE, EX., 20-8-2002

છે

78-16

[PART I-A

]h

[જુઓ નિયમ ૧૧]

અરજીનો નમૂનો
ગુજરાત પંચાયત સેવા પસંદગી બોર્ડની
A
/२०
(પંચાયત સેવા)ની ખાતાકીય પરીક્ષામાં બેસવા માટેની અરજી.

ના રોજ લેવાની નાયબ ચિટનીશ।

અરજદારનું પૂરેપૂરું નામ
(અટક પહેલી લખવી)|

(અંગ્રેજીમાં અને ગુજરાતીમાં)|

२.

૩.

હોદ્દો (અંગ્રેજી અને ગુજરાતીમાં)

(૧) તે, જે જિલ્લ પંચાયતમાં હોય તેનું નામ
(૨) હાલ જે કચેરીમાં કામ કરતો હોય તેનુંનામ

:

૪.

જન્મ તારીખ અને પરીક્ષા વખતે ઉંમર|

:

5.

નિમ કની તારીખ અને નોકરીનાં કુલ વર્ષ

૬.

તે અગાઉ પરીક્ષામાં બેઠા હતા કે કેમ? જો તેમ હોય તો-

(ક) જે પરીક્ષામાં તે બેઠા હોયતેનો મહિનો અને વર્ષ

(ખ)કોઈ મુકિત મળી છે કે કેમ?તેમ હોય,તે ગુણ,

પરક્ષાનું વર્ષ અને મહિનો અને વિષયની વિગતો।
આપવી.

(ગ) મળેલી મુકિતનો લાભ લેવા માગે છે કે કેમ?
(હકે ના જણાવો.)(પસંદગી છેવટની ગણાશે

અને તેમાં કોઈફેરફાર કરવાની છૂટ રહેશે નહિ.)

૭.

જે અધિકાર અથવા નિયમોથી તેણે પરીક્ષામાં

૮.

જે તકોમાં અને સમય મર્યાદામાં તેણે પરીક્ષા પાસ।
કરવી જોઈએ તે તકોની સંખ્યા અને સમયમર્યાદા।
(યોગ્યતાની તારીખ અને પરિીક્ષામાં બેસવા માટેની
મુદત પૂરી થયાની તારીખ જણાવવી).

બેસવાનુંહોય તે.

<!-- page 17 -->

2ue
CENTRAL SECTION]

૯.

GUJARAT GOVERNMENT GAZETTE, EX.,

કેટલી તકો પૂરી થઈ તેની સંખ્યા।

20-8-2002

૧૦. વધારાની (ખાસ)તક આપવામાં આવી છે કે
કેમ?(જે હુકમો હેઠળ તેને વધારાની(ખાસ)તક
આપવામાં આવી હોય તેનો નંબર અને તારીખ|

નિર્દિષ્ટ કરવા અને તેની નકલો જોડવી.

૧૧.

પરીક્ષા પાસ કરવાનો હેતુ (દા.ત. નોકરીમાં|
કાયમીથવા, સેવામાં ચાલુ રહેવા, બઢતી વગેરે).

૧૨. ખાતાકીય પરીક્ષાના નિયમોનુસાર તે પરીક્ષામાં
બેસવા માટે લાયક છે કે કેમ ?|

૧૩.

:

વિશેષનોંધ, જેો કંઈ હોય તો તે

સ્થળ:

તારીખ

(અરજદારની સહી)|

78-17

<!-- page 18 -->

[PART I-A

GUJARAT GOVERNMENT GAZETTE, EX., 20-8-2002

78-18

યોગ્યતાનું પ્રમાણપત્ર
“પ્રમાણિત કરવામાં આવે છે કેઉપરની વિગતો તપાસી છે અને ખરી જણાઈ છે.
..માહે।

.તારીખ।

…સન ૧૯

ના રોજ પરીક્ષામાં બેસવાને લાયક છે.

સહી

સ્થળ :

에

:

હોદ્દો

:

જિલ્લા વિકાસ અધિકારી,|
.જિલ્લો.

તારીખ :

R Fસ્વિu

h.,

(જુઓ નિયમ ૧૨)।
નાયબ ચિટનીશ (પંચાયત સેવા)ની ખાતાકીય પરીક્ષા માટેનો અભ્યાસક્રમ :।
પ્રશ્નનપત્ર-૧

૧૦૦ ગુણ (પુસ્તકો સાથે)|
સમય :.૩ કલાક.

ગુજરાત પંચાયત સેવા (વર્તણુક) નિયમો, ૧૯૯૮

૨.
૩.

ગુજરાત પંચાયત સેવા (શિસ્ત અને અપીલ) નિયમો, ૧૯૯૭|
ગુજરાત પંચાયત સેવા (વર્ગીકરણઅને ભરતી)નિયમો, ૧૯૯૮

૪.

ભ્રષ્ટાચાર નિવારણ અધિનિયમ, ૧૯૮૮।

ล

૧.

૨૫

૨પ
24

૨૫

કુલ...

૧૦૦

પ્રન્તત્ર-૨.।

૧૦૦ ગુણ (પુસ્તકો સાથે)
atc

સમય : ૩ કલાક.।

ગુજરાત બજેટ મેન્યુઅલ (વલ્યુમ ૧ના પ્રકરણ ૭ અને
પરિશિષ્ટ ઘ રિવાયના બંને વોલ્યુમ)|

:

૫

<!-- page 19 -->

282
CENTRAL SECTION} GUJARAT GOVERNMENT GAZETTE, EX., 20-8-2002

૨.

78-19

મુંબઈઆકસ્મિકિ ખર્ચનિયમો, ૧૯૫૯
પ્રકરણ ૧૨, ૨૧, ૨૫, (૨,૫, ૭, ૮, ૯, ૧૦, ૧૧, ૧૨,|

૨૫।

૧૩) ૨૬ (૨, ૩, ૪) ૨૮, ૨૯, ૩૧, ૩૨ અને ૩૩ સિવાય

આખું પુસ્તક.
3.

(ક) મુંબઈ રાજ્ય સેવા નિયમો, ૧૯૫૯

80

પુસ્તક-૧ (નીચેના નિયમો સિવાય આખુંપુસ્તક)

નિયમો, ૧૨, ૧૫, ૨૦, ૨૫, ૩૭, ૩૮-ક, ૩૮-ખ,

૩૮-ખખ, ૩૮-ઘ, ૩૮-ચ, ૪૨, ૬૮-ક અને ખ, ૮૬,

૧૦૫, ૧૦૬, ૧૧૪, ૧૧૫, ૧૧૮-૧૨૨, ૧૨૯, ૧૨૯-ક,
૧૩૦, ૧૩૧, ૧૪૦, ૧૪૨, ૧૪૪, ૧૪૯, ૧૭૦, ૧૭૫,

૧૭૮, ૧૯૧, ૨૦૧ થી ૨૦૬, ૨૦૯, ૨૧૦, ૨૨૩,૨૨૯,।

૨૫૫, ૨૭૯-ક, ૨૭૯-ખ, ૨૮૨-ખ, ૨૮૪, ૨૮૯, ૨૯૪r,
૩૦૦, ૩૦૯, ૩૦૯-ક, ૩૧૨, ૩૩૨, ૩૩૨-ક, ૩૪૩-ક,
૩૬૦-ખ, ૩૮૨-ખ, ૩૮૫-ક, ૩૯૪, ૪૦૧, ૪૦૭ થી ૪૧૦
૪૨૮, ૪૩૦, ૪૪૦, ૪૪૨-ક, ૪૫૯, ૪૬૩, ૪૬૭, ૪૮૨થી ૪૮૭,

‫زا‬

૪૯૬-૪૯૮, ૫૦૭ થી ૫૧૦, ૫૧૩, ૫૨૭, ૫૨૮, ૫૪૩-ક,
૫૪૫-ક, ૫૫૩, ૫૫૫, ૫૫૬-ખ, ૫૫૭, ૫૫૯-ખ, ૫૬૦-ક,

૫૬૦-ખ,૫૬૨-ખ, ૫૬૪, ૫૬૫-ક થી ૫૬૮ ૫૯૧, ૬૦૦,
૬૦૫, ૬૦૮, ૬૧૨,૬૪૨,૬૪૩, ૫૪૭, ૬૫૫, ૬૫૬, ૬૬૦,

૬૮૪, ૬૮૫, ૬૮૭, ૭૦૩, ૭૦૫-૭૩૬, ૮૧૧-૮૩૦,
૮૪૪ થી ૮૪૮, ૮૫૧,૮૫૪-૮૬૦, ૮૬૨-૮૬૩.

(ખ) મુંબઈ રાજ્ય સેવા નિયમો, ૧૯૫૯, પુસ્તક-૨ (માત્ર નીચેના

પરિશિષ્ટનો સમાવેશ થશે.)|

૧, ૩, ૫, ૭, ૮, ૧૪, ૧૪-ગ, ૧૪-ચ, ૧૫, ૧૬, ૧૭, ૧૮-ક,
૩૨, ૪૨, ૪૨-ક, ૪૨-ખ, ૪૪, ૪૪-ખ, ૫૦, ૫૧-ક
४.

ગુજરાત નાણાંકીય નિયમો, ૧૯૭૧ (નીચેના સિવાય આખુ પુસ્તક)

२०

નિયમો ૪૬, ૪૭, ૫૬, ૬૨, ૬૩, ૬૪, ૭૬, ૮૨, ૮૩, ૮૪, ૮૫,
૮૬, ૯૭, ૧૪૧, ૧૫૮ થી ૧૮૨ અને પરિશિષ્ટ નં.૪, ૧૩, ૧૪,
૧૫, ૨૧ અને ૨૪સિવાયના તમામ પરિશિષ્ટો.

१००

પ્રટત્ર-૩.

૧૦૦ ગુણ (પુસ્તકો સાથે)|
સમ્પય : ૩ કલાક.

atc

૧.
૨.

મુંબઈ જમીન મહેસૂલ અધિનિયમ, ૧૮૭૯ અને તે હેઠળ કરેલા નિયમો..
મીસ્ટર એન્ડરસનનુંરેવન્યુ એકાઉન્ટ મેન્યુઅલ..|

чо
чо

서

१००

પ્રિપત્ર-૪।

૧૦૦ ગુણ (પુસ્તકો સાથે)|
૧

ભારતનું સંવિધાન

at

સન્મય : ૩ કલાક.

२५

<!-- page 20 -->

41.30

78-20

GUJARAT GOVERNMENT GAZETTE, EX., 20-8-2002

પંચવર્ષીય યોજનાઓ.
(૧) ગુજરાત રાજ્યની ચાલુ પંચવર્ષીય યોજના
(તમામ સામાન્ય પ્રકરણો ફક્ત)

२.

[PART I-A
२०

૩.- પંચાયતીરાજ.

४०

(૧) પંચાયતી રાજની પ્રશ્ચાદ ભૂમિકા અને ઈતિહાસ
(૨) ગુજરાતમાંપંચાયતી રાજ
૪.

२०

२०

ગુજરાત સહકારી મંડળી અધિનિયમ, ૧૯૬૧

94

더:

१००

ભલામણ કરેલાં પુસ્તકો :–

(૧) ભારતનાં સમૂહ વિકાસ-મુખરજી, પ્રકરણ-૧ સમૂહ વિકાસ શુંછે?

(૨)
(૩)
(૪)
(૫)

સમૂહ વિકાસ કાર્યક્રમ
સમૂહ વિકાસ પ્રક્રિયા અને તેની લાક્ષણિકતાઓ
સમૂહ વિકાસ કાર્યક્રમનો અમલ
સમૂહ વિકાસ અને સ્થાનિક સરકાર

(૬) ગુજરાતમાં પંચાયતી રાજ
પ્રિ

- ।

૧૦૦ ગુણ (પુસ્તકો સાથે)|
સન્મય : ૩ કલાક

(06-lafc)

વિભાગ-૧।

atc

નીચેનાં પુસ્તકો ઉપરના પ્રશ્ન।
૧.

ગુજરાત પંચાયત અધિનિયમ, ૧૯૯૩...

그런

२.

નિચેના નિયમો..।

ur

(૧)

D

(૨)
(૩)

(૪)
(૫)
(૬)

ગુજરાત તાલુકા અને જિલ્લા પંચાયત (કાર્યરીતિ) નિયમો, ૧૯૯૭.
ગુજરાત ગ્રામ અને નગર પંચાયત (કાર્યરીતિ) બાબતના નિયમો, ૧૯૯૭.
ગુજરાત પંચાયત સેવા પસંદગી મંડળ (બોર્ડના કાર્યો) બાબતના નિયમો, ૧૯૯૮.।
ગુજરાત પંચાયત સેવા પસંદગી મંડળ (બોર્ડ) (વિચારવિનિમય)નિયમો, ૧૯૯૮.
ગુજરાત જિલ્લા પંચાયત સેવા પસંદગી સમિતિ(નાં કાર્યો) બાબતનેા

નિયમે, ૧૯૯૮.

ગુજરાત જિલ્લા પંચાયત સેવા પસંદગી સમિતિ (વિચારવિનિમય)બાબતને
નિયમો, ૧૯૯૮.

(૭) ગુજરાત ગ્રામ પંચાયત (ગ્રામ સભાબેઠકો અને કાર્યો બાબતના) નિયમો, ૧૯૬૪,
(૮) -ગુજરાત જિલ્લા પંચાયત (જમીન મહેસૂલ પર સ્થાનિક ઉપકર વસૂલ કરવાના ખર્ચ)|
બાબતના નિયમો, ૧૯૯૫.

(૯) ગુજરાત પંચાયત સેવા (ગુજરાતી ભાષા પરીક્ષા)નિયમો, ૧૯૬૪.
(૧૦) ગુજરાત જિલ્લા વિકાસ ફંડ નિયમો, ૧૯૬૪.

<!-- page 21 -->

‫اده‬
CENTRAL SECTION] GUJARAT GOVERNMENT GAZETTE, EX., 20-8-20

(૧૧) ગુજરાત પંચાયત સેવા (નિમણૂંક સત્તાધિકારીઓ) નિયમો, ૧૯૯૬.
(૧૨) ગુજરાત પંચાયત સેવા (નોકરીની બદલીઓ)નિયમો, ૧૯૯૫.
(૧૩) ગુજરાત તાલુકા અને જિલ્લા પંચાયત ચૂંટણી (અનામત બેઠકોની વારાફરતી

78-21

02

ફાળવણીની રત) નિયમો, ૧૯૯૪.|

(૧૪) ગુજરાત જિલ્લા પંચાયતના પ્રમુખની ચૂંટણી (પ્રમુખના અનામત હોદ્દાની વારાફરતી
ફાળવણીની રીત)નિયમો, ૧૯૯૪.

(૧૫) ગુજરાત ગ્રામ પંચાયત ચૂંટણી (અનામત બેઠકોની વારાફરતીફાળવણીની રીત)।
નિયમો, ૧૯૯૪.

(૧૬) ગુજરાત તાલુકા પંચાયતના પ્રમુખની ચૂંટણી (પ્રમુખના અનામત હોદ્દાની વારાફરતી
ફાળવણીની રીત) નિયમો, ૧૯૯૪.

(૧૭) ગુજરાત તાલુકા અને જિલ્લા પંચાયત પ્રમુખ અને ઉપપ્રમુખ ચૂંટણી નિયમો, ૧૯૯૪.|

(૧૮) ગુજરાત પંચાયત ચૂંટણી નિયમો, ૧૯૯૪.

(૧૯) ગુજરાત ગ્રામ પંચાયત (ઉપસરપંચ)ચૂંટણી નિયમો, ૧૯૯૪.|
(૨૦) ગુજરાત ગ્રામ પંચાયતના સરપંચની ચૂંટણી (સરપંચના અનામત હોદ્દાની વારાફરતી।
ફાળવણીની રીત) નિયમો, ૧૯૯૪.

(ગુણ-૩૦)

ચૂંટણી મેન્યુઅલ

เล

વિભગ-૨।

03

ગુજરાતના રાજ્યપાલશ્રીના હુકમથી અને તેમના નામે,|
આ૨. એન. નિનામા,
સરકારના ઉપસચિવ.

સરકારી મધ્યસ્થ પ્રેસ, ગંાંધીનગર.

<!-- page 22 -->

<!-- page 23 -->

<!-- page 24 -->

Extra No. 155

REGISTERED No. G/GNR/2

सत्यमेव जयते

The Gujarat Government Gazette
EXTRAORDINARY

Vol. LII}

PUBLISHED BY AUTHORITY

FRIDAY, SEPTEMBER 16, 2011/BHADRA 25, 1933

Separate paging is given to this Part in order that it may

be filed as a Separate Compilation.

PART IX

Gujarati translation of Bills, Acts and Notifications other than
those published in other parts.

વૈધાનિક અને સંસદીય બાબતોનો વિભાગ।

સચિવાલય, ગાંધીનગર, ૧૬મી સેપ્ટેમ્બર, ૨૦૧૧.

ગુજરાત ગેઝેટમાં અંગ્રેજીમાં પ્રસિધ્ધથયેલાતારીખ ઃ ૧૧મી ઓગસ્ટ, ૨૦૧૧ના ગુજરાત સરકારના પંચાયત,ગ્રામ

ગૃહનિર્માણ અને ગ્રામ વિકાસ વિભાગના સરકારી જાહેરનામાક્રમાંકઃ કેપિ/૭૮/૨૦૧૧/પીઈઆર/૧૦૨૦૦૭/૧૬૯૪/ડી.

નો ગુજરાતી અનુવાદ આથી સર્વ લોકોનીજાણ સારુંપ્રસિદ્ધ કર્યો છે.!

IX-EX.-155-1

આર. એમ.ાવસાર,|
સરકારના સંયુક્ત સચિવ.।
155-1

<!-- page 25 -->

158

155-2

[PART-IX

GUJARAT GOVERNMENT GAZETTE, Ex.. 16-9-2011
Notificatoin

Regarding
AMENDMENT TO THE DEPUTY CHITNIS (PANCHAYAT SERVIСE)
DEPARTMENTAL EXAMINATION RULES, 2002.

નાયબ ચિટનીસ (પંચાયત સેવા) ખાતાકીય પરીક્ષા નિયમો, ૨૦૦૨ સુધારવા સંબંધી જાહેરનામું.
પંચાયત, ગ્રામ ગૃહનિર્માણ અનેગ્રામવિકાસ વિભાગ,
સચિવાલય, ગાંધીનગર, ૧૧મી ઓગસ્ટ, ૨૦૧૧.

ગુજરાત પંચાયત અધિનિયમ, ૧૯૯૯૩
ક્રમાંક : કેપી/૭૮/૨૦૧૧/પીઈઆર/૧૦૨૦૦૭/૧૬૯૪/ડી.— ગુજરાત પંચાયત અધિનિયમ, ૧૯૯૩

(સન ૧૯૯૩ના ગુજરાતના ૧૮મા)ની કલમ-૨૭૪ સાથે વાંચતાં,કલમ-૨૨૭ની પેટા-કલમ (૫)થી મળેલી સત્તાની
રૂએ, ગુજરાત સરકાર, આથી, નાયબ ચિટનીસ (પંચાયત સેવા) ખાતાકીય પરીક્ષા નિયમો, ૨૦૦૨ વધુ સુધારવા
નીચેના નિયમો કરે છે :-9

આ નિયમો, નાયબ ચિટનીસ (પંચાયત સેવા) ખાતાકીય પરક્ષા (સુધારા) નિયમો, ૨૦૧૧ કહેવાશે.

૨. નાયબ ચિટનીસ (પંચાયત સેવા) ખાતાકીય પરીક્ષા નિયમો, ૨૦૦૨માં।

પરિશિષ્ટ-ખમાં, પ્રશ્નપત્ર પના (સેકશન) ભાગ-૨માં, “પંચાયત ચૂંટણી મેન્યુઅલ” એ શબ્દોને બદલે
“ચૂંટણી મેન્યુઅલ” એ શબ્દો મૂકવા
ગુજરાતના રાજ્યપાલના હુકમથી અને તેમના નામે,
ડી. કે. બારીયા,

સરકારન નાયબ સચિવ.

સરકારી મધ્યસ્થ મુદ્રણાલય,ગાંધીનગર.

<!-- page 26 -->

-

293
REGISTERED No. G/GNR/2

Extra No. 75

सत्यमेव जयते

The Gujarat Government Gazette
EXTRAORDINARY

PUBLISHED BY AUTHORITY
Vol. LII]

SATURDAY, AUGUST 20, 2011/SRAVANA 29, 1933

Separate paging is given to this Part in order that it may be filed as a Separate Compilation.
PART I-A

CENTRAL SECTION

Orders and Notifications (Other than those published in-Part IV-B)
under the Gujarat Local Boards, Village Panchayats, Municipal

Boroughs, District Municipal, Primary Education and Local
Fund Audit Acts.

PANCHAYATS, RURAL HOUSING AND RURAL DEVELOPMENT DEPARTMENT
Notification

Sachivalaya, Gandhinagar, 11th August, 2011.
THE GUJARAT PANCHAYATS ACT, 1993.
No. KP-78-2011-PER-102007-1694-D

.-

In exercise of the Power conferred by sub-section

(5) of section 227 read with section 274 of the Gujarat Panchayats Act, 1993 (Guj. 18 of 1993), the
Government of Gujarat hereby makes the following rules further to amend the Deputy Chitnis
(Panchayat Service), Departmental Examination Rules, 2002, namely :1.

These rules may be called the Deputy Chitnis (Panchayat Service), Departmental
Examination (Amendment), Rules, 2011.

2.

In the Deputy Chitnis (Panchayat Service), Departmental Examination Rules, 2002 in

Appendix-B, in section-II of paper V for the words "Panchayat Election Manual" the
words "Election Manual" shall be substituted.

By order and in the name of the Governor of Gujarat,
D. K. BARIA,

Deputy Secretary to Government.

I-A Ex.75-1

75-1
Government Central Press, Gandhinagar.

<!-- page 27 -->

<!-- page 28 -->

REGISTERED No. L 2/RNP/G/GNR-84

Extra No. 1

વાર્ષિક લવાજમનો દર રૂા. ૩૦૦0/-

सत्यमेव जयते

The Gujarat Government Gazette
EXTRAORDINARY

PUBLISHED BY AUTHORITY
Vol LIVTUESDAY, JANUARY 1, 2013/PAUSA 11, 1934

Separate paging is given to this Part in order.that it may be filed as a Separate Compilation.
PART I-А

CENTRAL SECTION
Orders and Notifications (Other than those published in Part IV-B)

under the Gujarat Local Boards, Village Panchayats, Municipal
Boroughs, District Municipal, Primary Education and Local
Fund Audit Acts.

PANCHAYATS RURAL HOUSING AND RURAL DEVELOPMENT DEPARTMENT
Notification

Scahivalaya, Gandhinagar 1st January, 2013

Gujarat Panchayats Act, 1993

No.KP/1/2013/PER/102011/893/D.-In exercise of the powers conferred by sub-section (5)

of section 227 read with section 274 of the Gujarat Panchayats Act, 1993 (Guj. 18 of 1993) the
Government of Gujarat hereby makes the following rules, to amend the Deputy Chitnis (Panchayat
Service) Departmental Examination Rules, 2002, Namely

1.
2.

These rules may be called the Deputy Chitnis: (Panchayat Service), Departmental
Examination (Amendment) Rules, 2012
In the Deputy Chitnis (Pamchayat Service) Departmental Exámination Rules, 2002 in rule-3,

(1),to clause (b-1), the following proviso shall be added, namely
"Provided that notwithstanding anything contained in these rules, where a Clerk or

in sub-rule

:-

Typist who is not promoted to the post of Senior Clerk or a Senior clerk who has not
completed thfee years service as a Senior Clerk and is entitled to get the Second Higher Pay
Scale of the Post of Deputy Chitnis, in such case, he shall be allowed to appear in the
Departmental Examination for promotion to the post of Deputy Chitnis."

Bu order and in the name of the Governiment of Gujarat,

S. B. CHAUDHARI,

Deputy Secretary to Government.
I-A Ex.-1

1-1
Government Central Press, Gandhinagar.

D

<!-- page 29 -->

9
NOTIFICATION

Panchayats, Rural Housing and Rural Development Department

Sachivalaya, Gandhinagar.
Dated the 16h june, 2017.

Gujarat

No. KP21of 2017/PER/102007/1694/KH :- In exercise of the powers conferred by section

Panchayats

227 read with sub - section 274 of the Gujarat Panchayats Act, 1993 (Guj.18 of 1993),

Act, 1993.

The Government

of Gujarat hereby makes the following rules further to amend

the Deputy Chitnis (Panchayat Service) Departmental Examination Rules, 2002, namely:-

1.

These rules may be called the Deputy Chitnis (Panchayat Service), Departmental
Examination (Amendment) Rules, 2017.

2. In the

Deputy Chitnis (Panchayat Service) Departmental Examination Rules,

2002

(hereinafter referred to as "the said rules"), in rule 9, in the Note, for the words "means
the date immediately following the date on which the examination ended", the words
"means the date on which the result of the examination declared" shall be substituted.
3.

In the said rules, in rule 11, in sub

-

rule (1), for the words "sixty days" and "thirty days",

the words "thirty days" and "fifteen days" shall be substituted, respectively.
4. In the said rules, for rule 12, the following rule shall be substituted, namely :-

"12. Syllabus and type of Examination:

(1) The syllabus of the examination shall be as specified in Appendix 'B'.

(2) The examination shall be of objective type with questions having multiple
choice answers."

By order and in the name of the Governor of Gujarat,

Ror

(R.C.Sathwara)

Under Secretary to Government.
Notification

Page 4
