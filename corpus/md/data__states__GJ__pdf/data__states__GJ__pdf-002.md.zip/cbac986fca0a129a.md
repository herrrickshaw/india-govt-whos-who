---
doc_id: "cbac986fca0a129a"
source_url: "https://gbu.edu.in/wp-content/uploads/2024/09/Corrigendum-II-050924.pdf"
ministry: "Gujarat Biotechnology University"
title: "Corrigendum II (Dated: 05-Sep-2024)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d18635feef489111"
---

<!-- page 1 -->

GUJARAT BIOTECHNOLOGY UNIVERSITY
GIFT City, Gandhinagar- 382355
Email: info-gbu.gujarat.gov.in
Website: www.gbu.edu.in/

Corrigendum II

Supply, Installation, Testing & Commissioning of Laboratory Infrastructure at
Gujarat Biotechnology University, Gandhinagar
Tender ID: 98300 | Date: 28.08.2024

1|Page

<!-- page 2 -->

Corrigendum II
S. No
1.

2.

3.

4.

5.

Clause
Milestone
Dates for
Tendering

Tender Downloading Date: From 17TH August 2024 to Tender Downloading Date: From 17TH August 2024 to 3rd September
28th August 2024
2024

Sl. 1
Milestone
Dates for
Tendering

Tender Online submission: On or Before 6:00 PM, 28th Tender Online submission: On or Before 6:00 PM, 3rd September 2024
August 2024

Sl. 2
Milestone
Dates for
Tendering

Modified Clause / New Clause

Submission of tender in physical form at Gujarat State Submission of tender in physical form at Gujarat State Biotechnology
Biotechnology University: On or Before 6:00 PM, 30th University: On or Before 6:00 PM, 5th September 2024
August 2024

Sl. 3
Documents
to be
submitted
ii

Hard Copies of Tender Fee & EMD should be submitted Hard Copies of Tender Fee & EMD should be submitted by speed
by speed post/RPAD only so that it will reach to the GBU post/RPAD only so that it will reach to the GBU office by 05-09-2024
office by 30-08-2024 before 6:00 pm.
before 6:00 pm.

The Terms
and
Conditions

The last date of submission of bid on website The
last
date
of
submission
of
bid
on
https://tender.nprocure.com is 28.08.2024 till 18.00 hrs. https://tender.nprocure.com is 03.09.2024 till 18.00 hrs.

1.

2|Page

Original Clause

website
