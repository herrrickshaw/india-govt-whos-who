---
doc_id: "7dad8c05fcc01cae"
source_url: "https://bknmu.edu.in/uploads/assest/184-nss-circular-2810202610282026014452499.pdf"
ministry: "Bhakta Kavi Narsinh Maheta University, Gujarat"
title: "રાષ્ટ્રીય એકતા દિવસ (૩૧ ઓક્ટોબર, ૨૦૨૬)ના આયોજન બાબત.      28/10/2026 (NSS Section)"
date: ""
pages: 3
method: "pdftotext"
script: "GUJARATI"
needs_ocr: false
sha1: "26287ccdb6645818"
---

<!-- page 1 -->

ESTSlJ GZl;\C DC[TF I]lGJl;"8L4 H]GFUsU]HZFT 5la,S I]lGJl;"8Lh VlWlGID G\P !5qZ_Z#f

BHAKTA KAVI NARSINH MEHTA UNIVERSITY, JUNAGADH
[ Gujarat Public Universities Act No. 15/2023 ]

----------------------------------------------------------------------------------------------------------------------------ક્રમ ક
ાં /BKNMU/NSS/184/2026

ત . 28/10/2026

વિષય :- રાષ્ટ્રીય એકતા દિવસ (૩૧ ઓક્ટોબર, ૨૦૨૬)ના આયોજન બાબત.

સાંદર્ભ :- યુવા બાબતો અને રમતગમત મંત્રાલયના તા. 27-10-2026ના પત્ર ક્રમાંક
પી.16/2/2020/રાસેયો/ગુજ/2296-2409 મુજબ.

પરીપત્ર :-

ભક્તકવવ નરવસિંહ મહેતા યુવનવવસિટી, જૂનાગઢ સંલગ્ન એન.એસ.એસ. યુવનટ ધરાવતી તમામ કોલેજોના

આચાયયશ્રીઓ તથા એન.એસ.એસ. પ્રોગ્રામ ઓદિસરને ઉપરોક્ત વવષય તથા સંિભય પરત્વે જણાવવાનુ ં કે, િર વષયની
જેમ આ વષે પણ ૩૧ ઓક્ટોબર, ૨૦૨૬ના રોજ આપણા મહાન નેતા સ્વ.શ્રી સરિાર વલ્લભભાઈ પટેલની જન્મજયંતી
વનવમતે “ર ષ્ટ્રીય એકત દદિસ” (National Unity Day) તરીકે ઉજવવામાં આવનાર છે . આ િરમ્યાન “એકત દોડ”
(Unity Run) આયોજીત કરવામાં આવશે જેમાં સમાજના તમામ વગયના લોકોનો સમાવેશ કરવામાં આવશે, જેથી એકતા

અને આઝાિીનો અમ ૃત મહોત્સવની ભાવનાનો સંિેશ ભારત ભરમાં પ્રસાદરત થશે. આ સાથે આ પ્રસંગે આયોજીત થનાર
કાયયક્રમમાં NSSના તમામ સ્વયંસેવકો, પ્રોગ્રામ ઓદિસર તેમજ સંસ્થા/કોલેજના અન્ય સિસ્યો દ્વારા “ર ષ્ટ્રીય એકત
દદિસ”ની પ્રવતજ્ઞા લેવી િરજીયાત છે , જે આ સાથે સામેલ છે .

આથી આ સબંધે એન.એસ.એસ. યુવનટના અવધકારક્ષેત્રમાં આ કાયયક્રમ આયોજીત કરવા, તેમજ ઉક્ત કાયયક્રમ

પ ૂણય થયા બાિ કાયયક્રમનો અહેવાલ, િોટોગ્રાફ્સ અને ટૂંકો વવડીયો રીજીયોનલ ડાયરે ક્ટરશ્રી, ક્ષેત્રીય કાયાયલય,

અમિાવાિને વોટ્સેઅપ તથા ઈ-મેઈલ nssahmedavad@gmail.com પર ખાસ તેમજ અત્રે યુનીવસીટી, NSS વવભાગ
ખાતે ઈ-મેઈલ – nss@bknmu.edu.in પર સમયસર મોકલી આપવા જણાવવામાં આવે છે .

પ્રો. કો- ઓડીનેટર

બિડ ણ :-

NSS Cell, BKNMU – જુ નાગઢ

સંિભય િવશિત પત્રની નકલ

પ્રવતજ્ઞા – રાષ્ટ્રીય એકતા દિવસ
પ્રવત,

ભક્તકવવ નરવસિંહ મહેતા યુવનવવસિટી, જૂનાગઢ સંલગ્ન એન.એસ.એસ. યુવનટ ધરાવતી
તમામ કોલેજોના આચાયયશ્રીઓ તથા એન.એસ.એસ. પ્રોગ્રામ ઓદિસર,
નકલ સ દર રિ ન :-

(૧) માન. કુ લપવતશ્રી/કુ લસચચવશ્રીના અંગત સચચવશ્રી
(૨) રાજ્ય એન.એસ.એસ. અવધકારીશ્રી, ગાંધીનગર

(૩) રીજીયોનલ ડાયરે ક્ટરશ્રી, એન.એસ.એસ. ક્ષેત્રીય કાયાયલય, અમિાવાિ

-------------------------------------------------------------------------------------------------------------------------------------;ZSFZL 5M,L8[SGLS S[d5;4
Government Polytechnic Campus,
ESTSlJ GZl;\C DC[TF I]lGJl;"8L ZM04
Bhakta Kavi Narsinh Mehta University Road,
B0LIF4 H]GFU-v#&Z Z&#4 U]HZFTsEFZTf
Khadiya, Junagadh - 362263 (Gujarat) OMG
G\P_Z(5vZ&(!$__ q O[S; G\P_Z(5vZ&(!5_#
Ph: 0285-2681400 Fax: 0285-2681503
: www.bknmu.edu.in ||
nss@bknmu.edu.in

<!-- page 2 -->

t.i-qar
fr.dqr: fr r olzlzozokrMr[sl 2 21 6- p t,t 01
q-r{itTafiR
gql 6r{-mc \r.{ t-"TqT54q
{rsfr-q Q-sr {rq-{r irfrq ft?srrdq
eTqTq,

zfiftywffi,

frqrq 3{r,{q hqm,
rr"rs u-6rcr+r< -380006

ffi1 2711g,r,r'
Tft",

t. s-{Fdtr.*.*. +rfm'q'Tr={Tfi 1fruR-*rem) n-wrm
z. ft-qrfslal Br[d-drtl, 1varil

ftq-q' <rfi{ \rd-dr fr+q (St 3rq{r 2026) + 3Trq}-s{ + q-<$ tt

rfr<mtrfr<r
w-fril Gq-q 3inrf{ qTqqir am qtn * e-< sq ft -.q qs +{ ft et q-+(+< zozo qir

6t 16r< tm q: fi qr<r< caorrrr€ qt-q fi q?q Rffi fr qfq rr+-m fu+q (Nationat
Unity Day)t sq ii r+rqr srqnn'l {fl a-T{ q-d-{r+s (UnityRun) 3rfrG-il fi qr++ Frq"i'
cqrq * qft q.ff + trt + qnft-q ftqr qrlqT Frq'+ q.*-+r *< qrvrfr +r Bryd q-&€-d fi
TFi-qT zrr s-tsr St tsl t s-flit-d frqr qr q+r {+ h {nq {q sl{w q-< qrfrR-< exrt-{ t s-ft
{rsq A-{r frw+r e{t-+qii,6r{frq qtffi 3t;q {rsrr{l-d s-qdi + ERr {rfiq fr+-m ft-+€'
cfrnl n-ir' 3rft-qrf t fr fi qq .rr * vrv dw {r
qri: Eq {"iil

t wvt argira t ft wq $r'i ffiffrR eirrtr qrw irsfiq +qr +q-ir

q-+rii frs-m n{-*;q qTmft'( s-Gtg fi?f-qrd {G sr sE +t q +rtm'c hsr{"d so +Ttrq
fi ffir8, g+rm fft, EY& AR:fr kc q 3nirfril +rtfi'c ff qrrf,rer 6-{Tqq ww gv e tte *
creqq

t H + fteRrd'st ilrfu {tff{ qr-+lt {Trf,q +1 yR-fr fi qr rT+r

rc-+q,

v(tr: gs-.kl

rftftft:-

1. rr"qn.t.*qfffi, fwtra

.;Ef,(5qr(6(
*frqfttqr+;

V'L L

<!-- page 3 -->

राष्ट्रीय एकता दिवस शपथ
मैं सत्यनिष्ट्ठा से शपथ लेता हूँ कक मैं राष्ट्र की एकता,
अखंडता और सुरक्षा को बिाए रखिे के ललए स्वयं को समर्पित
करं गा और अपिे िे शवालसयों के बीच यह संिेश फैलािे का भी
भरसक प्रयत्ि करं गा। मैं यह शपथ अपिे िे श की एकता की
भाविा से ले रहा हूँ जिसे सरिार वल्लभभाई पटे ल की िरिलशिता
एवं कायों द्वारा संभव बिाया िा सका। मैं अपिे िे श की
आंतररक सुरक्षा सुनिजचचत करिे के ललए अपिा योगिाि करिे
का भी सत्यनिष्ट्ठा से संकल्प करता हूँ।

RASHTRIYA EKTA DIWAS PLEDGE
I solemnly pledge that I dedicate myself to
preserve the unity, integrity and security of the
nation and also strive hard to spread this message
among my fellow countrymen. I take this pledge in
the spirit of unification of my country which was
made possible by the vision and actions of Sardar
Vallabhbhai Patel. I also solemnly resolve to make
my own contribution to ensure internal security of
my country.
