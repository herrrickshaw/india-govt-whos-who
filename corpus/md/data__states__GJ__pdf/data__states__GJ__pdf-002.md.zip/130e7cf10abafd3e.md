---
doc_id: "130e7cf10abafd3e"
source_url: "http://incometaxgujarat.gov.in/uploads/documents/Tender_Notice_15.10.pdf"
ministry: "Income Tax Department, Gujarat Region"
title: "Cancellation of Tender Notice for Data Extraction and Analysis Services, Ahmedabad"
date: ""
pages: 1
method: "tesseract:guj+eng"
script: "LATIN"
needs_ocr: false
sha1: "50c530ec22ced0af"
---

<!-- page 1 -->

9

ર, Office of the

ઝે

ઝે Principal Director of Income Tax (Investigation), Ahmedabad

11111 1st floor, Aayakar Bhavan, Ashram Road, Ahmedabad-380009

[પછ

ha ey Email: ahmedabad.pdit.inv@incometax.gov.in

reate wat
F.No. PDIT (Inv.) /Ahd/Forensic/Tender/2026-27 Date: 15.10.2026

Tender Notice
It is hereby notified that the Tender Notice No. DGIT(Inv.) AHD/Digital
Forensic/2026-27/01 dated 18.09.2026, inviting bids from eligible, bonafide,
reliable and resourceful service providers experienced in the field of Data
Extraction and Data Analysis Services. (GEM/2026/B/8061874 for Data
Extraction & Analysis Services dated 21.09.2026) for the office of the Director
General of Income Tax (Investigation), Ahmedabad, stands cancelled due to
technical reasons.
All bidders are advised to take note of this cancellation.
Any inconvenience caused is regretted.
A fresh tender will be issued separately in due course.
By Order
Qui ab Aree
sw) fs SO)

PDIT (Inv.), Anmedabad ug iis
In capacity of Chairman of Joint Tender Committee તન
