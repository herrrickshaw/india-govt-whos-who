---
doc_id: "bbd41e61dd57ac4d"
source_url: "https://www.gujaratmetrorail.com/wp-content/uploads/Reports/GMRCL_Higher-pension_-Circular-2.pdf"
ministry: "Gujarat Metro Rail Corporation (GMRC) Limited, Gujarat"
title: "GMRCL Circular for higher pension benefit."
date: ""
pages: 3
method: "tesseract:guj+eng"
script: "LATIN"
needs_ocr: false
sha1: "66b66315b6faf2b5"
---

<!-- page 1 -->

ક GUJARAT METRO RAIL CORPORATION (GMRC) LIMITED
fifi (SPV of Govt. of India & Govt. of Gujarat)
(Formerly known as Metro-Link Express for Gandhinagar And Ahmedabad (MEGA) Company Limited)
No. GMRCL/HR/EPF/EPS-95/03-2023 Dated: 18" March, 2023
CIRCULAR
Subject: Submission of Joint Option under pre-amended paragraph 11(3) and amended paragraph 11(4)
of Employees Pension Scheme, 1995 in pursuance of the Hon'ble Supreme Court's order dated
04/11/2022 passed in SLP No. 8658-8659 of 2019.
Reference:
1. Hon’ble Supreme Court’s Order in Special Leave Petition (C) Nos. 8658-8659 of 2019 dt. 04/11/2022.
2. EPFO Circular No. Pension/2022/54877/15149 dt. 29/12/2022.
3. EPFO Circular No. Pension/2022/54877/15238 dt. 05/01/2023.
4. EPFO Circular No. Pension/2022/56259/16541 dt. 20/02/2023.

1. This has reference to the Hon'ble Supreme Court’s Order dated 04/11/2022 regarding Employees’
Pension Scheme-1995 (EPS’95).

2. GMRCL Limited is unexempted establishment. As per para 44(ii) of the Order, amendment to the
Pension Scheme brought about by the notification No. G.S.R 609 (E) dated 22/08/2014 shall apply to
the employees of the unexempted establishments in the same manner as to the employees of the
regular establishments.

3. EPFO had issued internal instructions in compliance of the Orders of the Hon’ble Supreme Court dated
04/11/2022 vide Circular No. Pension/2022/54877/15149 dated 29/12/2022 read with Corrigendum
vide _ Circular No. Pension/2022/54877/15238 dated 05/01/2023. and Circular No.
Pension/2022/56259/16541 dated 20/02/2023.

4. Prima facie it emerges that EPFO Circulars referred at para 2 above is addressing only those employees
who have exited EPS, 1995 prior to 01/09/2014 (attained 58 yearsof age prior to the said date) and had
exercised option for Pension on higher salary under the erstwhile para 11(3) of the EPS 1995 and whose
Application / Option was declined by EPF Authorities. It is hereby informed that if any superannuated
/ retired ex-employee of GMRCL who are meeting the criteria specified in EPFO Circulars, if they so
desire, may submit their option to the concerned RPFC of EPFO (from where they are drawing Pension
under EPS, 1995) as per the procedure along with the supporting documents as indicated at Paras 6 &
7 of the EPFO Circular dated 29/12/2022 read with Corrigendum dated 05/01/2023 and dated
20/02/2023.

5. The Hon’ble Supreme Court Judgment dated 04/11/2022 also covers the employees of Exempted PF
Trusts who are members of EPS and had/would attain 58 years of age on or after 01/09/2014 to
exercise option for higher pension. The relevant operative portion of the Judgment in this regard is as
follows:

44(ii) Amendment to the pension scheme brought about by the notification no. G.S.R. 609(E)
Dated 22"4 August 2014 shall apply to the employees of the exempted establishments in the same
manner as the employees of the regular establishments.
44(iv) The members of the scheme, who did not exercise option, as contemplated in the proviso to
paragraph 11(3) of the pension scheme (as it was before the 2014 Amendment) would be entitled to
exercise option under paragraph 11(4) of the post amendment scheme . Thus, all the employees who
did not exercise option but were entitled to do so but could not due to flue interpretation on cut-off
date by the authorities, ought to be given a further chance to exercise their option. Time to exercise
option under paragraph 11(4) of the scheme, under these circumstances, shall stand extended by
a further period of four months.
Registered Office: Block No.1, First Floor, Karmayogi Bhavan, Sector 10/A, Gandhinagar-382010.

Ph.: +91-79-23248572 Fax: +91-79-23248573 Email: info@gujaratmetrorail.com font

Website: www.gujaratmetrorail.com CIN: U60200GJ2010SGC059407 “ત

<!-- page 2 -->

(= GUJARAT METRO RAIL CORPORATION (GMRC) LIMITED
<i fi (SPV of Govt. of India & Govt. of Gujarat)
(Formerly known as Metro-Link Express for Gandhinagar And Ahmedabad (MEGA) Company Limited)

6. Pending issue of further guidelines by EPFO specifying the mode and manner of deposit of amount,
exercising option and for submission of Joint Option as per Para 43 read with para 44(iv) of the
Judgment dated 04/11/2022 i.e. of eligible employees / ex- employees of Exempted Trusts, pending
receipt / issuance of the same by EPFO, the following instructions / guidelines are hereby notified,
in view of the timelines prescribed by the Hon’ble Court for exercising option:

(a) All serving / superannuated / retired / resigned (after attaining 58 years on or after
01/09/2014), etc. employees/ex-employees of the Company who are/were members of
EPS, 1995 as on 01/09/2014 and are willing to exercise option for contribution on actual
wages to the Pension Fund are hereby required to submit the requisite Joint Option Form,
to avail the benefit of pension on actual salary/wages, as directed by the Hon’ble Supreme
Court, as indicated below:

(i) Serving Employees and EPS Pensioners who are on the rolls of the Company (attained
58 years but not 60 years) shall exercise the Joint Option using given URL link
https://unifiedportalmem.epfindia.gov.in/memberInterfacePohw/member

(1) Ex-Employees shall exercise the Joint Option in the same given URL link
https://unifiedportalmem.epfindia.gov.in/memberInterfacePohw/member.

Note: The Joint Option form in URL link as referred above is subject to change/

modifications based on EPFO instructions, if any].

(b) All the eligible employees / former employees desirous of exercising the option are
required to fill the joint option through using URL link given by Regional P.F. Commissioner,
Regional Office, EPFO, Ahmedabad.

(c) Eligible & willing employees/ex-employees who opt for pension on actual salary will be
required to pay/transfer the past contribution @ 8.33% of PF Salary(Basic+DA etc.) along
with interest as required by EPFO i.e from 16-11-95 or from their date of joining whichever
is later, till the date of regularizing the future monthly contribution @8.33% to Pension
Fund based on the Joint Option in case of serving employees and in case of ex-employees
till the date of Superannuation.(58 Years).

(d) In addition to 8.33% of PF salary, eligible & willing employees / ex-employees may have to
pay / transfer additional amount /percentage, if any, notified by EPFO in view of the
direction of the Supreme Court as mentioned afore-said.

(e) In view of the timelines prescribed by the Hon’ble Court for exercising option i.e., four
months from the date of the Judgement, and thereafter considering the time period
required for scrutiny / onward submission to the RPFC concerned and to avoid any possible
rejection by the RPFC concerned on the ground of said timelines, willing employees / ex-
employees shall ensure receipt of the Joint Option using URL Link by the Provident Fund
Department, Corporate Office, Ahmedabad.

7. The Employees, who had exercised option under the proviso to Paragraph 11(3) ofthe 1995 Scheme and
continued to be in service as on 01/09/2014, will be guidedby the amended provisions of Paragraph
11(4) of the Pension Scheme. રૃ

0
Registered Office: Block No.1, First Floor, Karmayogi Bhavan, Sector 10/A, Gandhinagar-382010.
Ph.: +91-79-23248572 Fax: +91-79-23248573 Email: info@gujaratmetrorail.com
Website: www.gujaratmetrorail.com CIN: U60200GJ2010SGC059407

<!-- page 3 -->

હિ
સિ GUJARAT METRO RAIL CORPORATION (GMRC) LIMITED
હી fi (SPV of Govt. of India & Govt. of Gujarat)
(Formerly known as Metro-Link Express for Gandhinagar And Ahmedabad (MEGA) Company Limited)

8. Members of the Scheme, who did not exercise option but were entitled to do so but could not due to
the interpretation on cut-off date by the Authorities, ought to be given a further chance to exercise
their option. Time to exercise option under Paragraph 11(4) of the Scheme, under these circumstances
shall stand extended by a further period of four months from the date of Judgment i.e. 04/11/2022.

9. Project Office/ Corporate Office may take necessary actions accordingly and also may bring the contents
of this Circular to the notice of employees / ex-employees.

10.It may be noted that this Circular is being issued for implementation of the Hon'ble Supreme Court
Judgment only to adhere to the time limit and is subject to any ratification(s) / guidelines(s) that may
be issued by EPFO from time to time and/or any judicial pronouncements / statutory amendments.
Therefore, mere submission of the Joint Option Form by employees / ex-employees does not confer
any right to receive or obligation of GMRCL to pay higher pension to them.

11.The present Circular along with the Joint Option URL link is available on the website of GMRCL i.e.
www.gujaratmetrorail.com.

This Circular is issued is as per the approval of the competent authority.

For Gujarat Metro Rail Corporation (GMRC) Limited.

,
oN aay

Pankaj Kumar

Dy. General Manager (HR)

Copy to:

> PAto MD, GMRCL.

> All Directors, GMRCL.

> All HODs, GMRCL.

> HR File

> PF File

Registered Office: Block No.1, First Floor, Karmayogi Bhavan, Sector 10/A, Gandhinagar-382010.
Ph.: +91-79-23248572 Fax: +91-79-23248573 Email: info@gujaratmetrorail.com
Website: www.gujaratmetrorail.com CIN: U60200GJ2010SGC059407
