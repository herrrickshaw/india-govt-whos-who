---
doc_id: "237baa860b9decde"
source_url: "https://jami.tripura.gov.in/download/LR_AMENDMENT.pdf"
ministry: "Digital India Land Records Modernization Programme (DILRMP), Tripura"
title: "Land Revenue & Land Reforms Amendment"
date: ""
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "46602e5481962fa1"
---

<!-- page 1 -->

THE TRIPURA LAND REVENUE AND LAND REFORMS
(SIXTH AMENDMENT) ACT, 1994.

Published in the
EXTRAORDINARY ISSUE OF TRIPURA GAZETTE

Agartala, Friday, October 18, 1996 A.D. Asvina 26, 1918 S.E.

GOVERNMENT JOF TRIPURA
LAW DEPARTMENT
Dated, Agartala, the 18th October,

No. F. 9(15)-Law/Leg/96
1996.

NOTIFICATION
The following Act of the Tripura Legislative Assembly received the assent of the
President on the 11th February, 1996 and is hereby published for general information.

TRIPURA ACT NO. 2 OF 1996.
THE TRIPURA LAND REVENUE AND LAND REFORMS
( SIXTH AMENDMENT) ACT, 1994.
AN
ACT
Further to amend the Tripura Land Revenue and Land Reforms Act, 1960.
Be it enacted by the Legislative Assembly in the forty-fifth year of the republic of India
as follows;WHEREAS it is expedient to amend the Tripura Land Revenue and Land Reforms
Act, 1960:
1. (1) This Act may be called the Tripura Land Revenue and Land
Short title and
Reforms (Sixth Amendment) Act, 1994.
Commencement
(2) It shall come into force at once.
1. For Section 187 of the Tripura Land Revenue and Land Reforms Act, 1960 ( herein-after referred to as principal Act). the following Section shall be substituted,
namely:-

“Special
provision
regarding
Scheduled
Tribes”

1

<!-- page 2 -->

“187 (1) No transfer of land belonging to a person who is a member of the
Scheduled Tribes shall be valid unless—
(a) the transfer is to another member of the Scheduled Tribes; or
(b) where the transfer is to a person who is not a member of the Scheduled
Tribes, it is made with the previous permission of the collector in writing in
the manner to be prescribed by rule, or
(c) the transfer is by way of mortgage to a Co-operative Society or to a Bank
or to the Tripura Housing Board, or to the Central or the State
Government or any other financial institutions or Corporations as may be
notified by the Government in the Official Gazette from time to time for
the purpose.
Provided that the land so mortgaged in pursuance of Clause (c) shall not
be transferred by such mortgage to a person who is not a member of the
Scheduled Tribes.
Explanation—In this sub-section, the expression, ‘a bank’ shall have the same
meaning as in section 109.
(2) (a) Notwithstanding anything contained in the Transfer of Property Act,
1882, but subject to the provision of section 187A, no transfer of land
belonging to a person who is a member of the Scheduled Tribes shall be valid
unless made by a registered instrument.
(b) No transfer or instrument of transfer including a decree or order passed
by any court, Tribunal or Authority, made in contravention of sub-section (1)
shall be registered or in any way recognised as valid in any court, Tribunal or
Authority.
(3) No decree or order shall be passed by any court, Tribunal or Authority in
any case other than the cases as specified in Clause (c) of sub-section (1) for
the sale of the land or any portion thereof, of a person belonging to scheduled
Tribes nor shall any such land be sold in execution of any decree or order”
Insertion of
3. In the Principal Act, after Section 187 A, the following sections shall be inserted,
New
namely;Section
“Restoration
187B. (1) On or after the 1st January, 1969--of land:

(a) if a transfer of land belonging to a person who is a member of the
scheduled Tribes is made in contravention of the provisions of sub-section
(1) of section 187 to a person other than a member of the Scheduled
Tribes, a Revenue Officer specially appointed for this purpose by a
notification in the Official Gazette, and having local jurisdiction may,
notwithstanding anything contained in any other law for the time being in
force, on its own motion or on an application made in that behalf, and
after giving the transferee and the transferer an opportunity of being
heard, by an order in writing evict such or any person claiming under him
from such land or part thereof and shall restore the possession of the land
to the transferer, or his successor in interest and for this purpose the
Revenue Officer may use or cause to be used such force as may be
considered necessary.

2

<!-- page 3 -->

(b) if any land owned by person belonging to the Scheduled Tribes is
occupied by any person who is not a member of the Scheduled Tribes
without lawful authority, then the Revenue Officer in the same manner as
provided in Clause (a) may restore the possession of such land to the
person or successor in interest so dispossessed.
(c) if a person belonging to the scheduled Tribes is in occupation of
Government land and eligible for allotment of such land under Section 14
of this Act, parts with possession or is dispossessed there from by a
person not belonging to the Scheduled Tribes, then the Revenue Officer in
the same manner as provided in clause (a) may restore the possession of
such land to that person. Or his successor-in-interest as the case may be
and refer to the competent authority under Section 14 of this Act for
allotment of the land to such person.
Explanation—For the purpose of this sub-section, the successor-ininterst means heirs, transferee or assignee in accordance with law or
custom as applicable.
(2) If any person not being a member of the Scheduled Tribes occupies or
possesses the land held by or in occupation of a person belonging to the
Scheduled Tribes in any manner as specified in sub-section (1) after the
commencement of the Tripura Land Revenue and Land Reforms (Sixth
Amendment) Act, 1994 without any lawful authority he shall be
punishable with imprisonment for a term which may extend to two years
and also with a fine which may extend to three thousand rupees.
(3) Notwithstanding anything contained in the Code of Criminal Procedure
1973 every offence punishable under sub-section (2) shall be cognizable
and non-bailable and wherever any person is arrested and detained in
custody in pursuance of provision of this section, the officer-in-charge of
the Police Station or Police Officer making the arrest shall forward the
person to the Presiding Officer holding the special Court of the jurisdiction
and the provision of the Code of Criminal Procedure, 1973 shall apply
mutates mutandis for summary trail.
(4) For the purpose of speedy trial of offence under this section the State
Government may, after consultation with the High Court by notification
constitute as many special Courts s may be considered necessary, each
consisting of an Officer not below the rank of a Judicial Magistrate of the
First Class.
(5) For the cases referred to in sub-section (2), the Revenue Officer
immediately after restoration of land under sub-section (1) shall file a
complaint in the special Court constituted under sub-section (4) for action
as provided, in sub-section (2).
(6) An appeal shall lie to the High court from every order passed by a
special court under this section within sixty days of the passing of such
order.

3

<!-- page 4 -->

Onus of
Proving

187. C.

Notwithstanding anything contained in any other law for the time
being in force, the burden of proof for the purpose of section 187
B that transfer of land was not made in contravention of subsection (1) of section 187 or occupation of land was not made
without lawful authority shall lie on the transferee or occupier, as
the case may be.

Prevention of retransfer

187. D. Where the possession of any land is restored to a person belonging
to the scheduled Tribes under any of the above provisions is retransferred by the person belonging Scheduled Tribes in
contravention of section 187 and the Revenue Officer specially
empowered has reasons to believe that the land holder belonging
to Scheduled Tribes shall not be in a position to retain the land so
re-transferred even after subsequent restoration, the Revenue
Officer shall evict the person to whom the land was re-transferred
and entrust the management of the same to a Committee as
may be constituted by the State Government with scheduled
Tribes members and government Officials for a period of one year
and if, after the expiry of this period, the Committee holds that
the land holder belonging to the scheduled Tribes shall not be in a
position to retain the land if restored, then such land shall vest to
the Government free from all encumbrances and the Collector
shall allot the land to the eligible tribals of the area under such
condition as may be prescribed.
(2) The manner of constitution conduct of business, powers and
function of the committee referred to in sub-section (1) shall be
such as may be prescribed.
Explanation:- For the purpose of Section 187, 187B, 187C an
187D, the word ‘transfer’ shall mean sale, mortgage, lease,
exchange and gift as defined in Transfer of property Act, 1882 and
include parting with fully or partly of ownership or possession of
any land or any interest therein in any other manner whatsoever
but shall not include the requisition and acquisition of land under
any law for the time being in force.

Waiving of
limitation

187. E. Notwithstanding anything contained in any law for the time being
in force, a petition for restoration of possession of land by a
person belonging to the Scheduled Tribes against a person not
belonging to the scheduled Tribes shall lie at any time.

Jurisdiction of Civil
Court

187. F. Notwithstanding anything contained in any other law for the time
being in force, no suit for declaration of title over any land
belonging to the Scheduled Tribes shall lie in a civil Court and no
Civil Court shall pass a decree or order by which title of land
stands transferred from a person belonging to the Scheduled
Tribes to a person not belonging to the Scheduled Tribes.

4

<!-- page 5 -->

187. G. (1) Wherever an offence under this Act has been committed after
the commencement of the Tripura Land Revenue and Land
Reforms (Sixth Amendment) Act, 1994 by a company, every
person who at the time the offence was committed was in change
of, or was responsible to the company for the conduct of the
business of the company, as well as the company, shall be
deemed to be guilty of the offence and shall be liable to be
proceeded against and punished accordingly.
Provided that nothing contained in this sub-section shall render
any such person liable to any punishment under this Act if he
proves that the offence was committed without his knowledge
or that he exercised all due diligence to prevent the commission of
such offence.
(2) Notwithstanding anything contained in sub-section (1), where
an offence under this Act has been committed by a company and
it is proved that the offence has been committed with the
consent or a connivance of, or is attributable to any neglect on the
part of any director, manager, secretary or other officer of the
company, such director, manager, secretary or other officer shall
also be deemed to be guilty of that offence and shall be liable to
be proceeded against and punished accordingly.
Explanation:- For the purpose of this section (a) “company” means
any body corporate and includes a firm or other association of
individuals; and
(b) “Director”, in relation to a firm, means a partner in the firm”.

R.M.MAJUMDER
Deputy Secretary to the
Government of Tripura.

5

<!-- page 6 -->

THE TRIPURA LAND REVENUE AND LAND REFORMS
(SIXTH AMENDMENT) ACT, 1997.

GOVERNMENT OF TRIPURA
LAW DEPARTMENT
Dated, Agartala, the 1st April, 1997.

No. F. 9(15)-Law/Leg/96
NOTIFICATION

The following Act of the Tripura Legislative Assembly received the assent of the
President on the 27th March, 1997 and is hereby published for general in formation.

6

<!-- page 7 -->

“TRIPURA ACT NO. 1 OF 1997

THE TRIPURA LAND REVENUE AND LAND REFORMS
(SEVENTH AMENDMENT) ACT 1997.
AN
ACT

further to amend the Tripura Land Revenue and Land Reforms Act, 1960.
Be it enacted by the Legislative Assembly of Tripura in the Forty-eight Year
of the republic of India as follows: Short Title and
Commencement

1. (1) This Act may be called the Tripura Land Revenue and Land Reforms
(Seventh Amendment) Act, 1997.
(2) It shall be deemed to have come into force on the 11th day of
February 1996.

Amendment of
section 187

2. In Section 187 of the Tripura Land Revenue and Land Reforms Act,
1960 (hereinafter referred to as the Principal Act), sub-section (3) shall be
renumbered as clause (a) thereof and after clause (a) as
so
renumbered, the following clause shall be inserted, namely:“This sub-section shall come into force on such date as the State
Government may be notification in the official Gazette appoint.”

Amendment of
section 187 B

3. In Section 187B of the Principal Act, sub-section (2) shall be
renumbered as clause (a) thereof and after clause (a) as so renumbered,
the following clause shall be inserted, namely: “(b) This sub-section shall come into force on such date as the
state Government may by notification in the official gazette
appoint”

Repeal and
Saving

4. (1) The Tripura Land Revenue and Land Reforms (Seventh
Amendment) Ordinance 1996 (hereinafter referred to as the said
ordinance) is hereby repealed.
(2) Notwithstanding such repeal, anything done or any action taken under
the said Ordinance shall respectively be deemed to have been done or
taken under the corresponding provisions of this Act.”

B.K. Banerjee
Secretary to the
Government of Tripura.

7

<!-- page 8 -->

8th Amendment Act, 2000
Published in the
EXTRAORDINARY ISSUE OF TRIPURA GAZETTE

Agartala, Thursday, September 5, 2002 A.D. Bhadra 14, 1924 S.E.

GOVERNMENT OF TRIPURA
LAW DEPARTMENT
NO.F.8(19)-Law-1/2002

Dated, Agartala, the 14th August, 2002.

NOTIFICATION
The following Act of the Tripura Legislative Assembly received the assent of the
Governor on the 31st of May, 2000 and is hereby published for general information.

A.B. Paul
Secretary
Government of Tripura

8

<!-- page 9 -->

Tripura Act No. 12 of 2000.

THE TRIPURA LAND REVENUE AND LAND REFORMS
(EIGHT AMENDMENT) ACT, 2000.
AN
ACT
to amend the Tripura Land Revenue and Land Reforms Act, 1960.
Be it enacted by the Legislative Assembly of Tripura in the Fifty-First Year of Republic
of India as follows :

Short title &
Commencement.

1. (1) This act may be called the Tripura Land Revenue
and Land Reforms (Eight Amendment) Act, 2000.
(2) It shall come into force at once.

Amendment of
Section--20

2. In section 20 of the Tripura Land Revenue and Land
Reforms Act, 1960,-(a)

in sub-section (4), for the words “one hundred
rupees” the words “ten thousand rupees” shall
be substituted ;

(b)

in sub-section (5), for the words :One hundred rupees”
and “four rupees” the words “ten thousand rupees”
and “four hundred rupees” shall respectively be
substituted.

A.B.Pual
Secretary
Government of Tripura

9

<!-- page 10 -->

Published in the
ESTRAORDINARY ISSUE OF TRIPURA GAZETTE
Agartala, Monday, March 6, 2006 A.D. Phalguna 15, 1927 S.E.

Government of Tripura
Law Department
No.F.8(2)-LAW/Leg-I/2006.

Dated, Agartala, the 23rd February, 2006

The following Act of the Tripura Legislative Assemble received the assent of the
Governor on 20.02.2006 is hereby published for general information.

S.C. Das
Law Secretary
Government of Tripura

10

<!-- page 11 -->

Tripura Act No. 3 of 2006
THE TRIPURA LAND REVENUE AND LAND REFORMAS
(NINTH AMENDMENT) Act, 2006.
AN
ACT
to amend the Tripura Land Revenue and Land Reforms Act, 1960.
Be it enacted by the Tripura Legislative Assemble in the Fifty Seventh Year of the
Republic of India as Follows :-

Short Title &
Commencement

1.(1) This Act may called the Tripura Land Revenue and Land
Reforms (Ninth Amendment) Act, 2006.
(2) It shall come into force at once.

Insertion of Subsection (1) and (2)
in Section 4

2. In Section 4 of the Tripura Land Revenue and Land Reforms
Act, 1960 the existing provision shall be numbered as subsection (1) and after sub-section (1) the following shall be
inserted namely :“(2) Notwithstanding anything contained in Sub-section (1) of
Section 4 above, the State Government if it thinks expedient
to do so, may engage at any time private individuals to
undertake any of the activities under this Act. In the event of
such expediency the State Government, shall by notification
in the official gazette, prescribe the conditions under which
such engagement shall be made.”

S.C.Das
Law Secretary
Government of Tripura

11

<!-- page 12 -->

 POWER OF THE COMPETENT AUTHORITY TO ACT UNDER THE PROVISION OF
TLR & LR ACT 1960 :Sl
no
1.

Section
Subject/purpose
of
the
Act
11(3)
Power to decide dispute over property.

2.

14(1)

3.

15

4.

18

5.
6.

20
38

7.

45

8.

46

9.

46(A)

10.

52

11.

53(2)

12.

57

Allotment of land for the purpose of
agriculture and construction of dwelling
house
Summary
eviction
of
unauthorized
occupation

Revenue authorities with
which powers are vested
1. Collector
2. Settlement Officer ( during
revision)
1. Sub-Divisional Magistrate
2. Settlement
officer(during
revision)
1. Deputy Collector
2. Settlement officer ( during
revision)
1. Deputy Collector
2. Settlement officer
Deputy Collector
Settlement officer

Remission of revenue in respect of land lost
by diluvium
Permission of diversion of land
Assessment of revenue payable on each
holding
Revision of entries in the finally published Settlement officer
RoR within one year from the date of final
publication of records
To decide the disputed case of mutation
1. Deputy Collector
2. Revenue inspector
3. Asstt. survey officer
4. Kanungo(during
revisional
survey)
Disposal of objections against the entries in 1.Deputy Collector
the register of bargadars and to certify the 2.Revenue Inspector
transfer of entries in the RoR
3.Asstt. Survey Officer
4.Kanungo(during
revisional
survey
Demarcation of village boundaries
1. Deputy Collector
2. Asstt. Survey Officer( during
revisional survey)
Eviction of unauthorized occupiers after 1. Sub-Divisional Magistrate
fixing of boundary
2. Settlement Officer (during
Revenue Survey)
Measuring for construction , laying out, 1. Collector
maintenance and repair of boundary marks 2. Settlement officer
Revenue Survey)

13.

61(2)

Certification of the correctness of the Deputy Collector
accounts of arrears of land revenue

14.

63,64,65,6
6,
75&79
74

Realization of land revenue and other Deputy Collector
public
demands
through
certificate
proceeding
Confirmation of sale
Sub-divisional Magistrate

15.

12

(during

<!-- page 13 -->

16.

76

Certificate of purchase

17.

84

Power to transfer cases from one revenue
officer
to another
revenue officer
competent to deal with it.

18.

85

Power to take eviction, summoned witness
etc.

19.

93(1)

Hearing of appeals against order passed by
subordinate officer.

20.

93(2)

Hearing of second appeal

13

1.Sub-divisional Magistrate
2. Deputy Collector
1. Secretary
/Commissioner,
revenue from any revenue
officer to another revenue
officer competent to hear the
case.
2. Director land records from
any revenue officer of the
directorate of settlement to
another revenue officer of the
directorate competent to hear
the case.
3. Collector to another officer
exercising the power of
collector in the same district
and from any revenue officer
in the district to another
revenue officer competent to
hear the case.
4. Sub-divisional officer from any
revenue officer in the subdivision to another revenue
officer in the sub-division
competent to hear the case.
All revenue officers not lower in
rank than a circle officer are
empowered.
Appeal will lie do:1. Commissioner/Secretary,
revenue order if passed by
Collector
2. Collector, if the order passed
by the SDM
3. SDM, if the order passed by
an officer subordinate to him.
4. Settlement officer, if order
passed by the A.S.O
5. Director of Land Records and
Settlement
against
order
passed by settlement officer
including orders passed in
cases under sec-11(3) in
exercise of the power of
collector.
1.Commissioner/Secretary,
revenue against order passed
by the Collector/director of
land records and settlement.
2.Director of land records and
settlement
against
order
passed by settlement officer.
3.Collector against order passed

<!-- page 14 -->

by SDO and other subordinate
officers.
21.

95

22.

96

23.

107

24.

107(D)(1)

25.

110

26.

111A

27.

113

28.

114

29.

116A

Revision of orders
subordinate officers

passed

other 1. settlement
officer(during
revisional survey and before
final publication)
2. director of land records and
settlement
(after
final
piblication
and
before
consignment of records to
sub-divisional megistrate)
3. collector( for cases arising
after consignment of record
toSub-divisional megistrate)
N.B:- Settlement officer and
director
land
records
&
settlement will dispose of cases
pending with them at the time
of
final
publication
and
consignment
of
records
respectivelly)
Review of order
Revenueofficer before reviewing
any order will take permission
from:1. Commissioner / secretary,
revenue for any order
passed by collector.
2. Collector for any order
passed by a revenue officer
subordinate to him
3. Director of land records and
settlement for any order
passed by officer of the
settlement directorate.
Relinquishment of rights in respect of any 1.Sub-divisional magistrate
land in favour of the government
2.Deputy collector
Transfer of land within the second schedule 1.Sub-Divisional Magistrate
area
2.Deputy Collector
Permission to make improvement
1.Deputy Collector
2.Assistant
Survey
Officer(
during revision survey)
To determine the fixed produced rent
1.Deputy Collector
2.Assistant
Survey
Officer(
during revision survey)
Determination of reasonable rent
1.Deputy Collector
2.Assistant
Survey
Officer(
during revision survey)
Communication of rent payable in kind
1.Deputy Collector
2.Assistant
Survey
Officer(
during revision survey)
To receive rent from under raiyat of refusal 1.Deputy Collector
by the raiyats
2.Assistant
Survey
Officer(

14

by

<!-- page 15 -->

30.

118

Eviction of under raiyat

31.

120

Declaration of under raiyat as raiyat of the
land

32.

121 & 122

33.

123

34.

127

Determination
of
compensation
for
improvement
Restoration of possession of land of
bargadar(under raiyat)
Determination of compensation to raiyat

35.

130

36.

131

37.

143-146

38.

165

39.

166

40.

167

41.

169

42.

170

43.

171

44.

175

45.

187(3)

during revision survey)
1.Sub- Divisional Magistrate
2.Settlement
Officer(during
revision survey)
1.Sub- divisional magistrate
2.Settlement
Officer(during
revision survey
1.Deputy Collector
2.Assistant Survey Officer
Settlement
Officer
(during
revision survey
1.Deputy Collector
2.Assistant Survey Officer
1.Deputy Collector
2.Assistant Survey Officer
Deputy Collector
2.Assistant Survey Officer

Issue of certificate of ownership to under
raiyat
Determination of reasonable price and
issue of certificate of purchase to under
raiyat
Assessment of compensation payable to Collector
intermediaries
To receive return under section 165
1. Sub-Divisional Magistrate
2. Deputy Collector
3. Settlement Officer ( during
revision survey)
Penalty for non submission of returns
1. Sub-Divisional Magistrate
2. Deputy Collector
3. Settlement Officer ( during
revisional survey)
To determine excess land and publish the 1.Sub-Divisional Magistrate
list of excess land u/s 167
2.Deputy Collector
3.Settlement Officer ( during
revisional survey)
Excess land to vest in Government
1.Sub-Divisional Magistrate
2.Deputy Collector
3.Settlement Officer ( during
revisional survey)
Hearing of objection against determination Collector
of excess land
Director Land Records and
Settlement (during revisional
survey)
To determine compensation for excess land 1.Sub-Divisional Magistrate
2.Settlement Officer ( during
revisional survey)
Taking over possession of excess land
1.Sub-Divisional Magistrate
2.Deputy Collector
3.Settlement Officer ( during
revisional survey)
Restoration of alienated land to tribals
1.Sub-Divisional Magistrate
2.Addl.Sub-Divisional Magistrate

15

<!-- page 16 -->

16
