---
doc_id: "da7b97cf9faf140f"
source_url: "https://edistrict.tripura.gov.in/resources/pdf/Notification_e-District_01_04_2015.pdf"
ministry: "Digital Seva e-District Portal, Tripura"
title: "e-District Service Launch - Notification"
date: ""
pages: 4
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "c48cc69ffee91d92"
---

<!-- page 1 -->

F.No.19(5)/DIT/E-DIST/2013/Vol-II/ ৫৬7১ - 92
GOVERNMENT OF TRIPURA
DEPARTMENT OF INDUSTRIES & COMMERCE
(INFORMATION TECHNOLOGY)
errr
, ‘ Dated, Agartala, the af \tarch, 2015
NOTIFICATION , |
P
In persuasion to the state wide roll out of the e-District Mission Mode Project in
Tripura which is under the National e-Governance Plan (NeGP), 21(twenty one) services
have been identified to be delivered under the Project. The notification is issued to ensure that
the defined process of service delivery for the services offered through e-District Mission
Mode Project is followed. This would facilitate the electronic delivery of the service through
the instructions and guidelines as described in this Government order. Important components
, of service delivery process are listed below:-
1. Modes of Application
a. Application at Govt. Offices
The citizen can visit the Govt. offices for applying for the services along with all the
necessary supporting documents.
b. Application through internet
The applicant may also visit the e-District portal on the internet. The portal would facilitate
online submission of applications. The service application would be routed to the appropriate
authority by the software for necessary processing.
2. Supporting Documents
Citizen will bring in all the required Documents in original for scanning purpose at the Govt.
Offices. In online mode, citizen will do necessary scanning from originals.
3. Process for delivery of Service
i. After service request is completed and is saved into the Database, the applicant gets a
notification through SMS/email. It is hereby notified that all certificates would be
digitally signed by the Decision taking authority before disbursement. The digitally
signed certificate would be disbursed in the following modes :

<!-- page 2 -->

a. Through Govt. Offices
Applicant will visit any Govt. office with the original acknowledgement receipt
carrying service request number. The Authorized Operator at Govt. office will log
into e-District application and retrieves the Digitally Signed certificate or service
document, print it and hand it over to the applicant and update the status as delivered
in e-District application and if application is rejected he will be informed on reason of
rejection.
b. Through Online Mode
Citizen will log-in to the e-District Application with his registered user-id and
password. Citizen will take print out of the Digitally Signed certificate or service
document and if application was rejected he gets the reason of rejection.
4. General conditions
i. It is hereby informed that all the services to be delivered under e-District project
will be in compliance to “The Tripura Information Technology (Electronic
Service Delivery) Rules, 2015”.

ii. It is hereby informed that all such service requests shall be electronically
forwarded to all concerned.

iii. For all legal purposes, the validity of a digital signature shall be on par with a
manual signature. It shall be the responsibility of the officer with his digital
signature to safeguard it from misuse. |

iv. All departments should accept validity of a secure. digitally signed database as an
authentic and trustable source for verification.

v. The authenticity of a printed copy of a Digitally Signed certificate can be
established at e-District online portal through a unique application ID.

i 5. List of services to be delivered under e-District project is given at Annexure 4. In case of |
‘| Govt. offices, existing charges will be collected and will be deposited to the Government

Exchequer through appropriate Treasury Challan. ‘In case of Online mode, existing

charges to be collected under e-District project will be collected online through Payment

Gateway system and will be deposited to the Government Exchequer through appropriate

Treasury Challan.

<!-- page 3 -->

6. This notification will be in force from the date of launching of the services under e-
District project. Concerned departments will issue necessary Government Orders
indicating service levels for the services to be delivered under e-District project.

By order of the Governor,
Cad
(Puneet Agarwal)
Secretary to the
Government of Tripura
To:-
1. The Secretary to the Governor of Tripura for kind information of H.E. Governor.
2. The Principal Secretary to the Chief Minister, Tripura for kind information of the
Hon’ble Chief Minister.
3. The PS to all the Ministers, Govt. of Tripura for kind information of the Hon’ble
Minister.
4. The PPS to the Chief Secretary, Govt. of Tripura for kind information of the Chief
Secretary.
5. All the Principal Secretary/Secretary, Govt. of Tripura
6. The Director of , Govt. of Tripura for information.
7. Allthe DM & Collectors.
8. The SIO, NIC, Tripura State Unit, Govt. of India.
১১৯৭
(Puneet Agarwal)
Secretary to the
Government of Tripura
:
52 eee = এ সান —=

<!-- page 4 -->

Annexure I
List of Services to be delivered under e-District
1 Permanent Resident of Tripura Certificate
(PRTC)
Marriage Certificate
Survival Certificate Revenue Department
Land Valuation Certificate
7 Application and Disposal of Revenue Court
Cases
; 8 | Right to Information
Character Antecedent Verification
ST Certificate Tribal Welfare
Department
SC Certificate SC Welfare Department
OBC Certificate _ State OBC Welfare
OBC Certificate — Central Department
Issuance of License for Small Saving Agents ~ Directorate ofsmall
savings
Food Stuff License Food Department
i /।
Issuance of Pattas under Forest Rights Act Tribal Welfare
department
19 Scholarships (Dress Grant for Muslim School Education
Minority) department
20 | Unmarried Daughter Pension Durectorate Social
Welfare
Gun License Renewal Home Department I
2) "
