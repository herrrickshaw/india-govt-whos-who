---
doc_id: "746f4fe56cdcafba"
source_url: "https://ttaadc.gov.in/sites/default/files/2025-08/Guidelines_of_Article_275%281%29.pdf"
ministry: "Tripura Tribal Areas Autonomous District Council (TTAADC), Tripura"
title: "Guidelines of Article 275(1)"
date: ""
pages: 53
method: "tesseract:ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "44b4a1bef71f28a5"
---

<!-- page 1 -->

F. No. 11015 /0] / 2016 - SG-I
Government of India
Ministry of Tribal Affairs
Shastri Bhavan, New Delhi
Dated: 20.06.2016

To,

1. Chief Secretary to State Govt. / UT Administration (All States/UTs)

2. Principal Secretary / Secretary (in charge of) Tribal Development (All States)

3. Commissioner / Director, Tribal Development (All States)

Sub: Guidelines for Inter-State allocation of funds and implementation of
Programmes / Activities under Proviso to Article 275(1) of the Constitution of
India during 2016-17 and onwards.

Sir,

Following guidelines are hereby laid down for Inter-State allocation of funds and
implementation of programmes under Proviso to Article 275(1) of Constitution of India
during current fiscal, 2016-17 and afterwards.

1. Salient features of Constitutional Provision

1.1 Constitution of India provides as under:

“Article 275. Grants from the Union to certain States — (1) Such sums as
Parliament may by law provide shall be charged on the Consolidated Fund
of India in each year as grants-in-aid of the revenues of such States as
Parliament may determine to be in need of assistance, and different sums
may be fixed for different states.
Provided that there shall be paid out of the consolidated fund of India as
grants-in-aid of the revenues of a State such capital and recurring sums as
may be necessary to enable that State to meet the costs of such schemes of
development as may be undertaken by the State with the approval of the
Government of India for the purpose of promoting the welfare of the
Scheduled Tribes in that state or raising the level of administration of the
Scheduled Areas therein to that of the administration of the rest of the
areas of that State.” [=

75:০৩

1

<!-- page 2 -->

1.2 Grants-in-aid under Proviso to Article 275(1) of Constitution of India are 100%
annual grant from Government of India to States. It is charged to Consolidated Fund
of India (except grants for NE States, a voted item) and is an additive to State Plan
funds and efforts for Tribal Development.

2. Basic Objective

2.1 Following would be objectives for programmes / activities funded with Grants-in-

aid under Proviso to Art. 275(1) of Indian Constitution [Art. 275(1) Grants] to
bridge gap between Scheduled Tribe (ST) population and others by accelerating
development of STs by ensuring:
(i) Human resource development by enhancing their access to education and
health services,
(ii) Enhanced quality of life by providing basic amenities in tribal areas / localities.
(iii) Substantial reduction in poverty and unemployment, creation of productive
assets and income generating opportunities,
(iv) Enhanced capacity to avail opportunities, gain rights and entitlements and
improved facilities at par with other areas, and
(v) Protection against exploitation and oppression.
2.2 Art. 275(1) Grants must address need of plugging critical gaps. It is only an
additive to State efforts for tribal development, with fund flow under Tribal Sub
Plan (TSP) strategy.
3. Coverage:
3.1 27 States having notified STs are eligible to receive grants under this Programme.
These States are:-
Andhra Pradesh, Arunachal Pradesh, Assam, Bihar, Chhattisgarh, Goa, Gujarat,
Himachal Pradesh, Jammu & Kashmir, Jharkhand, Karnataka, Kerala, Madhya
Pradesh, Maharashtra, Manipur, Meghalaya, Mizoram, Nagaland, Odisha,
Rajasthan, Sikkim, Tamil Nadu, Telangana, Tripura, Uttar Pradesh, Uttarakhand
and West Bengal. (Punjab and Haryana have no ST population).
Union Territories are not funded under Art. 275(1) Grants. Ch
5০, পু
2

<!-- page 3 -->

3.2 Art. 27501) grants must be utilized for socio-economic development of following:
(a) Integrated Tribal Development Project (ITDP): It is an area of size of one
or more Development Blocks in which ST population is 50% or more of
total population of such Blocks. Complete development block(s) / panchayat
samiti(s) is the minimum constituent unit of an ITDP.

0). There can be more than one ITDP in a District.

(ii) | Area of an ITDP may even consist of Blocks of more than one
District. In such cases, ITDP will normally be named after its
headquarter location or district where its headquarter is located.
Integrated Tribal Development Agency (historically so called in
Andhra Pradesh, Odisha and Telangana amongst other States) /
Authority (ITDA) is concerned authority with jurisdiction for
administration of tribal development projects. Hence an ITDA (i.e.
agency or authority) should have jurisdiction over ITDPs (consisting
of full blocks / Panchayat Samitis), MADA and cluster pockets as
well. Even dispersed tribal population of a district can also be within
jurisdiction of concerned district ITDA. (In this matter, concerned
State Governments must decide the organizational structure.)

(b) Modified Area Development Approach (MADA): These are identified
pockets (consisting of one or more revenue villages) in contiguous areas
with a concentration of tribals 50% or more within total population 10,000
or more in such area.

(c) Clusters: These are identified pockets (with one or more revenue village(s)
being constituent units) with a concentration of tribals 50% or more within
total population 5,000 or more in such area.

In case of both MADA and Cluster Pockets, complete revenue village(s) is

constituent unit. A MADA pocket / Cluster for tribal development should be

named after the village in such area, which has maximum ST population

(2011 Census) in such MADA / Cluster Pockets. To illustrate it can be

identified as A-B (MADA / Cluster), where A is concerned District and B is

the revenue village having maximum ST population in such MADA /

Cluster pocket.

(d) Particularly Vulnerable Tribal Groups (PVTGs): Identified isolated
communities among tribals are characterized by a stagnant or declining rate

৩
2
3 wb

<!-- page 4 -->

of population growth, pre-agricultural level of technology and extremely low
level of literacy. [So far 75, PVTGs are identified. (Annexure 1)]
(e) Dispersed tribal population outside (৪), (b), (০) and (d) above.

3.3.1 Organizational structure (including district and field level set up) and
administrative jurisdiction of an ITDA (or any other designated authority) may be
decided by concerned State Government / UT administration.

3.3.2 Above areas need to be notified by Ministry of Tribal Affairs (MoTA), as proposed by
State Government, before these can be reckoned with, as basis for allocation of funds.
State Governments have to submit a proposal with details of identified area and
population (as per 2011 Census) along with a map to MoTA accordingly.

4. Criteria for Inter-State Allocation

4.1 From 2016-17 onwards, allocation of funds among above 27 States (Para 3.1)
under Art. 275(1) Grants shall be made in following manner:

a) 50% based on State ST population,

b) 25% based on tribal areas covered under ITDPs / ITDAs. A few States where
no ITDP / ITDA has been constituted, area of concerned Block / Panchayat
Samiti (Middle level PRI), where ST population is 50% or more would be
taken into account, and
From 2017-18 and onwards, above tribal area would include geographical area
of

(1) ITDPs
(2) MADA Pockets, and
(3) Cluster Pockets
as per 2011 Census basis.
Since these details are not readily available, only ITDPs / ITDAs area are
accounted for in current fiscal 2016-17. In absence of above, area as worked
out (Annexure 2) would be taken into account.
Total geographical area (in sq. kms) of Tribal Majority States i.e., Arunachal
Pradesh, Meghalaya, Mizoram and Nagaland would be taken into account.
oh
9৮০ b
4

<!-- page 5 -->

০) Remaining 25% of allocation would be as per an analysis of outcome-based
performance of concerned States.
Parameters for evaluation of performance would be notified separately.

4.2. Minimum Floor will be based on 75% of 2015-16 allocations made on ST
population basis. This floor allocation shall be subject to a minimum of Rs. 4.50
Crores (with 100% being Rs. 6.00 Crores).

4.3 A statement showing ST population of State, ITDP / ITDA area, and minimum
floor allocation is at Annexure 3.

5. Inter-District Allocation Criteria

5.1.1 Inter-District allocation of Art. 275(1) Grants funds shall be as follows:

(i) 66% % on population

(ii) 33% % on Area. (i.e., on 2:1 proportion based on population : area)

Only such area needs to be taken into account where ST population is more than
50% of total population of such District / Sub-Division / Block / revenue Village.
In case of tribal majority States (para 4.1 above), entire geographical area of
districts needs to be considered. (Since these States have > 50% ST population in
the State as a whole.)

5.1.2 In Project Appraisal Committee (PAC) meetings, State Government must submit
such area details. (With revenue village being smallest constituent unit for MADA,
Cluster Pockets and Blocks / Panchayat Samitis being the constituent unit of
ITDPs.) (Except for 4 tribal majority States.)

5.2.1 Districts having 25% or more STs (of district population) shall be focussed, for
implementation of tribal development programmes. List of 177 Districts with 25%
ST population or more (based on 2011 Census) is at Annexure 4. This also
includes Districts, affected by Left Wing Extremism (LWE) activities (where ST
population is even less than 25% floor). In case of such LWE affected areas, tribal
inhabited areas are normally localized (with ST population being 50% or more of
total population of revenue villages of such identified area) in a particular part of
District. Area of such Sub-Division / Block / Village can be taken into account for
area calculation. Oh

(b
=r
5

<!-- page 6 -->

Such details of identified areas and population (as per 2011 Census) along with a
map must be provided by concerned State Govt. in 2016-17 PAC meetings.

5.2.2 All MADA pockets / clusters shall be covered under some or the other
development programmes within every cycle of three years. (Starting from 2016-
17)

5.3.1 Within ST population, some ST communities count each more than 5% population
in every State. Details of such communities is at Annexure 5.

5.3.2. While doing inter-district allocation for tribal development programmes /
activities for such communities should be especially focussed.

In case where economic basis of tribal household economy of more than one ST
community is same, programmes can be common with such communities and
clubbed for fund allocation. For Example, in Himachal Pradesh, Gaddi and Gujjar
STs (both being livestock dependent households) can be covered with similar type
of development programmes / activities.

5.3.3 Fund allocation must be + 10 % of corresponding ST population share. That is, ifa
community counts for 20% of State ST population, then programmes should be for
18 % - 22 % band of total fund allocation for such a community.

If this community is more backward, then an increased allocation may be justified
based on human development index parameters. In any case, if the allocation
works out to lower than 18%, then total State allocation would be reduced
accordingly.

5.4. State Government may inform as to any discrepancy in calculation of area (with >
25 % ST population based on 2011 Census) or community-wise % data (2011
Census). Relevant information would be reviewed and accounted for after revision
of concerned data accordingly.

SA le
Sat
6

<!-- page 7 -->

6 Intra-State (Sectoral activities, community, area-wise) Prioritization and
Allocation:

6.1.1 Priority must be accorded as under:

a
(i) Education — 40-50%
(ii) Health — 10-15%
(iii) Agriculture, Horticulture, Animal Husbandry — 20 - 30%
(AH), Fisheries, Dairy & others in Primary
Sector
(iv) Other income generating schemes to — 10-15%
augment Tribal household economy
(ডে) Administrative structure (1001. 1090199/০)/  — <5- 10%
Institutional framework & Research studies
Total: 100%

6.1.2 Conjunctural use with dovetailing of financial resources from ongoing activities of
line departments must be resorted, to ensure larger spatial and higher demographic
coverage (under TSP flow concept or funds especially available under Central
Sector / Centrally Sponsored Schemes.)

6.1.3. Cluster (multiple beneficiaries in one location) approach on saturation (all
beneficiaries of an identified area are covered / benefitted by Government activity /
programmes) basis can be an excellent modus operandi, especially for districts
with > 50 % and even for > 25 % ST population.

6.1.4 Use of institutional finance should also be optimized.

6.1.5 Projects modelled on Public - Private (Sector) Participation (PPP mode) can go a
long way especially for Education and Health sectors and other human resource
development programmes.

6.2.1 Primarily activities of non-recurring nature (including infrastructure and equipment
with at least three years life time) shall be supported under Art. 275(1) Grants.
Fund for recurring component of such programmes / schemes shall be borne by
State funds / TSP allocation. An illustrative list of activities for Art. 275(1) Grants
funding is at Annexure 6. ¢ A \b

7

<!-- page 8 -->

6.2.2 ST Communities with similar livelihood pattern / traditional occupation (i.e.
income source same for tribal household economy) should be clubbed together for
the purpose of planning under Art. 275(1) Grants.

ST household, especially entitled land right under FRA, 2006 should be covered by
Programmes, Activities; especially designed for them.
So also should be coverage of women Self Help Groups (SHGs), beneficiaries.

6.3. Major infrastructure sector, like road connectivity, electricity, drinking water,
major irrigation projects, housing would not be funded under Art. 275(1) Grants, as
substantive part of State Plan funds go into these programmes.

6.4 It is relevant to emphasize that close to 80% of tribal households depend upon
agriculture and other primary sector economic activities. Guidelines of Ministry of
Rural Development (MoRD) especially provide for MGNREGA works on
individual tribal lands with State-funding. Such provision under extant guidelines
must be utilized to ensure better income and livelihood support to ST households.

6.5 Committed liability of approved programmes / activities (in previous years) would
be accorded priority for allocation of funds.

7. Plan Formulation:

7.1 State Tribal Development / Social welfare or other Department (in charge of tribal
development / activities) will be the nodal department for tribal development
programmes / activities (including under TSP flow of funds). The nodal
department will work in close coordination with all relevant line departments.

7.2 Secretary of the Nodal department will be Member-Secretary of the Executive
Committee (EC), chaired by Chief Secretary to State Government. The EC will be
responsible for appraisal and approval of perspective document as well as of TSP
schemes of different departments for inclusion in Annual TSP. The EC shall also
be responsible for monitoring and evaluation of TSP Plans, programmes and
activities.

7.3. Plan formulation necessarily must consist of following steps
i. Preliminary exercise,

ii. Selection of Schemes, Programmes and Activities, and
iii. Plan finalization under TSP, along with norms for TSP allocation.
Sh
22, \b
8

<!-- page 9 -->

Annexure 7 describes in detail above steps for plan formulation.

8. Plan Documentation

8.1 State Government shall prepare a comprehensive perspective TSP document,
taking into account all available sources of funding, to serve as a road map for
implementation. Funds available for TSP under Central Sector and Centrally
Sponsored Schemes as well as State Plans and Central Plans shall be pooled for
TSP planning.
This perspective document shall, inter-alia, reflect on:

0) Strategy to address gaps and deficits in terms of relevant schemes taking into
consideration strengths of tribal community, allocation of funds, fixing
physical targets to address inter-tribal and inter-habitation variance /
inequalities in their socioeconomic status, while adhering to an equity based
approach.

(2) Needs of Particularly Vulnerable Tribal Groups (PVTGs) will be accorded
priority with focused approach and special attention to improve their
conditions of food security, health and education for mainstreaming these
sections.

(3) The strategy should define priorities for TSP with a focus on long-term
sustained gains in relation to area development.

(4) Likely flow of benefits, in financial as well as physical terms, and specific
steps required for accessing benefits by tribals from each of national (and
State) level Flagship Schemes must be quantified.

Mechanism / surveillance system to ensure utilization of funds meant for the
intended purpose.

(5) Role and contribution of NSTFDC and State level STFDC and TRIFED etc
should be categorically provided for.

(6) Critical evaluation to assess whether ongoing schemes / programmes have
potential to accelerate pace of development of STs and result in bridging gap
in development in a time-bound manner. Ch

০৪71
9

<!-- page 10 -->

(7) Evaluation as to how TSP has and is likely to help STs in respect of
following key areas:
a) Prevention of land alienation and indebtedness;
b) Access and control over forest and effective implementation of
FRA Act, 2006 and PESA, wherever applicable; and
c) Involuntary displacement due to development projects to be
addressed with proper resettlement and rehabilitation support.
(8) Outcome Analysis with critical evaluation of implementation strategies in
terms of effectiveness of schemes / programmes.

8.2 The State shall break up Perspective Plan into doable annual Action Plans and
accordingly prepare annual plan documents taking into account all available funds
during year, including State Plan, Central Sector and Centrally Sponsored
Schemes.

9. TSP fund flow and Allocation of Art. 275 (1) Grants

9.1 Earmarking TSP funds and working out Art. 275(1) Grants for “Critical Deficit
Areas” is a must to ensure catalytic impact. Mechanism to do this is given at
Annexure 8.

9.2 These steps must be followed so as to formulate a proper proposal for funding
programmes, schemes and activities under Art. 275(1) Grants.

10. Institutional Structure

10.1 Nodal Department should be adequately strengthened through technical support
group, knowledge leadership, analytical functioning in areas pertaining to strategic
planning, demand assessment, gap analysis, long term impact of schemes /
programmes. Collection of related data is a must for evidence-based planning and
decision making and capacity building at all levels.

10.2 State Government shall establish (most already have) following institutional
structures and mechanism for effective formulation, implementation and
monitoring of TSP.

oh lb
10
