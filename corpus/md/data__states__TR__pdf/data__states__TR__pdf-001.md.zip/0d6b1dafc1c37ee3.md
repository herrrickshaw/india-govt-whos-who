---
doc_id: "0d6b1dafc1c37ee3"
source_url: "https://nursingcouncil.tripura.gov.in/sites/default/files/2026-01/Notification%20-5%20of%202026.pdf"
ministry: "Tripura Nursing Council, Tripura"
title: "Notification -5 of 2026."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "18e97fd7f7319e81"
---

<!-- page 1 -->

qr{*'q g-w,qf qRyE
t'{r, Ff-c e. mr{F&\
*q - r, c-{ ffi' "i. - fiao2o

arsd rra, q-rrff-S"S
t-.e?, cirsdr

INDIAN NURSING COUNCIL

CommunityCente
r.S/ SthFloor,NBCCCentre.PIotNo.t
Okhla
Phase
I,
New
- 110020
Delhi
\''n.r.*,ro 7
wrccs trf qR'qr* wrrsr riarqq d n-ro qifrmffi ft=o.rq

2,

lm

statutory Body r:nder the Ministry of Health & Family welfare
F.No 1 -6lRenewal-2025-INC

Dated:-

?ff Jfiru?$?$

Notification No- 5 of 2026
Sub:' Renerval of Suitrbilify of Nursing Educational Institutions for the Academic Year
2026-2027 reg.
Indian Nursing Council invites online applications: for Renewal of Suitability of Nursing
Edrrcational Institutions for tl're Academic Year 2026-2027,under Section 13 and t+ of tire nVC

Act 1947 . The applications can be subniitted vvith effect from 27tr, January, 2026 onwards via
online mode through INC rvebsite link:-r,vr,wv.indiannursingcouncil.org (uirder institute Login
S.No'1 URL:- https://renewal.indiannursingcounoii.org/Pages/Iogin.aqpx). The Iast date lor
submitting the application online is 30th April, 2826.It is also informed that the status of the
Applications/Suitability Reirewal letter wili be postecl online only and can be accessed by the
institution concerned by logging with the sarne application Id and password generated Uy tf..
institute rvhiie submitting tiie application.

In the above conuection, attention of al1 the Nursing Educational Institutions is invited
that same login Id and password to be used who have already applied in the previous years.
Horvever, the institute applying for the first time in the above URL shall create a new user Id
and password.

It is aiso notified as per Gazette Notification No. 149 datecl 07.05.2019, that all the
uursing teaching faculty shall be enrolled into Nurses Registration and Tracking Systern
(I{RTS) and have to enter their NUID number obtained ttuough NRTS while sgbmitting the
reterval application. If NUID is not allotted, their application number given while subrnitting
NRTS application has to be entered.
Note: - The last date for submitting the application onliue is 30rh April, 2a26,
This issues witli the approval of Competent Authority.

Col (Dr) Sarvjeet Kaur
Secretary
Copy forwarcled to:1. Registrar', All Universities
2. Registral, All State Nursing Corurcils
3. Principal. Schools/Colleges ofNur.sing
4. INC Website
sq-q{Tf frrEilr + !:6-crllrr qriEa rrFc.eq};} frc s-rne+
striving to Actriewe trrrifonrr standards of Ntrsing Edrrcatior:

'web site : vf r+rwjn

d i +rlp-ursin ge-o u ncir -

qrg

E-r:aai l : :s e cy" in e @ gow. in

Phone: O1 1-66616800, 666t6gZL, 666t6gZz
