---
doc_id: "6c70c2fbe4d8daae"
source_url: "https://farmersportal.tripura.gov.in/PDF/scheme/forest/Tree_form-I.pdf"
ministry: "Tripura Farmers Portal & Kisan Call Center (KCC), Tripura"
title: "Guidelines for extraction of trees from private plantations"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "156776b082784398"
---

<!-- page 1 -->

.....
1.3.2.8.

•

Guidelines for exiraciion of trees from private plantations

TREE Form-I

Application

Form for issuance of Registration Certificate
Extraction of Jote hind TImber

for

Through Range Officer (Concerned)

To
The Divisional Forest Officer (Concerned)
.
D'Ivlslon..............................
..
..............

li'
npura

Sub: Request for issuance of Registration Certificate for joteland Timber extration.

Sir,

1/ We'

inhabitant(s) of
in
PS
are the legal jotedar / allotter / owner of the land C. S.
plot No
Khatian No
:
Mouja
.
The CS plot No
has the standing
...................... No of trees boundaries are assiadet
j
North
South
East
West
The related certificate map, parcha and photograph of the undersigned is enclosed
for necessary joint verification. The registration certificate for the same CS plot may
kindly be issued for enabling me to apply for permission seeking extraction of tree
from my jote land.
Yours faithfully
Jotedar
Resident of

Enclo:
Certified copy of map
Certified copy of parcha
One photo fo jotedar
Photo Identity Card.
The signature of the jotedar are attested & done.in. my,presence,
Range Officer (Concerned)

185

.
