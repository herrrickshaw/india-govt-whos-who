---
doc_id: "0e35aad78d4dea8f"
source_url: "https://jica.tripura.gov.in/media/tenders/DNIT_North.pdf"
ministry: "Tripura JICA Project - Sustainable Catchment Forest Management (SCATFORM), Tripura"
title: "View / Download"
date: ""
pages: 35
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9f43853f583ac3c6"
---

<!-- page 1 -->

e-Tender for procurement of planting materials

Govt. of Tripura
Office of the District Management Unit Chief
North Tripura DMU, Dharmanagar, Tripura.

Bid Document of e-tender for
Supply of different types of Planting materials

Contractor/Bidder

<!-- page 2 -->

e-Tender for procurement of planting materials

Govt. of Tripura
Office of the District Management Unit Chief
North Tripura DMU, Dharmanagar, Tripura.

No.F. 10-50/Tender/DFO(N)/DMN-2026-27/2,565

Dated, 18-06-2026

Name of Work :- Supply of different types of Planting materials during 2026-27.
Sl No.

Section

Particulars

Page No.

1

Section - I

List of critical dates, Press Notice, NIT

3-11

2

Section – II

Instruction to Bidders

12-19

3

Section – III

Forms of Bids and Qualification information

20-22

4

Section – IV

Condition of contract

23-25

5

Section – V

Technical Specification

26-27

6

Section – VI

Forms of Security

28-30

7

Section – VII

Bidder Sheet

31-32

8

Section – VIII

Bill of Quantity

33-35

Certified that, this DNIT contains 35 pages numbered from 1 to 35 and schedule of the
e-Tender is shown in Section - I

(S. Malla, IFS)
District Management Unit Chief
(District Forest Officer)
North Tripura DMU, Dharmanagar

Contractor/Bidder

<!-- page 3 -->

e-Tender for procurement of planting materials

SECTION- I
LIST OF IMPORTANT CRITICAL DATES
PRESS NOTICE
NOTICE INVITING e-TENDER (NIT)

Contractor/Bidder

<!-- page 4 -->

e-Tender for procurement of planting materials

Critical Dates in connection with the bid
1
2
3
4
5
6
7

Completion of supply after issuing supply order
Tender publishing Date
Document Downloading Start Date
Bid Submission Start Date
Document Downloading End Date
Bid Submission End Date
Bid Opening Date

8

Place of Opening Bids:

9

Inviting Officer

Notes: All the above-mentioned
https://tripuratenders.gov.in

times

are

as

7 days
19.06.2026 at 10:00 PM
19.06.2026 at 11:00 AM
20.06.2026 at 11-30 AM
24.06.2026 at 05:00 PM
25.06.2026 at 05:00 PM
29.06.2026 at 11:00 AM
O/o the District Management Unit
Chief, North Tripura DMU,
Dharmanagar
District Management Unit Chief,
North Tripura DMU, Dharmanagar

per

clock

time

of

e-procurement

(S. Malla, IFS)
District Management Unit Chief
(District Forest Officer)
North Tripura DMU, Dharmanagar

Contractor/Bidder

<!-- page 5 -->

e-Tender for procurement of planting materials

Govt. of Tripura
Office of the District Management Unit Chief
North Tripura DMU, Dharmanagar, Tripura.

NOTICE INVITING E-TENDER
No.F. 10-50/Tender/DFO(N)/DMN-2026-27/2,565

Dated, 18-06-2026

Pursuant to the concurrence and approval of the competent authority the undersigned, as District
Management Unit Chief, North Tripura DMU, Dharmanagar under the Department of Forest,
Government of Tripura invites an e-Tender in Single Bid System (Technical & Financial) for determining
the single rate of for supply of different types Planting materials from the individual(s) having a valid
license issued by the competent authority to the Government for utilization under this District during the
Financial Year 2026-27 under Tripura SCATFORM Project & Tree Outside Forest (TOF) under District
Management Unit Chief, North Tripura, Dharmanagar. Bid may be submitted by eligible Bidders till
25/06/2026, 05:00 PM.

Name of
Work

1

Supply of
10,20,000
Nos. of
Pineapple
suckers

2,040,000.00

40,800.00
&
2,000.00

2

Supply of
91,000 nos.
Areca nut
seedlings.

728,000.00

14,560.00
&
2,000.00

3

Supply of
2,13,150 nos.
Agar
seedlings.

2,131,500.00

42,630.00
&
2,000.00

7 days

19.06.2026 at
11:00 AM &
25.06.2026 at
05:00 PM

Bid Opening Place of
Bidding
Date

29.06.2026
at 11:00
AM

https://tripuratenders.gov.in

Sl.

Document
Tender value/
EMD & Completion Download & Bid
Estimated cost Tender Fee
Period
Submission End
Date & Time

4,899,500.00
All the information of the above stated tender is available in https://tripuratenders.gov.in. Eligible bidders
shall participate in bidding, only in online mode, through website https://tripuratenders.gov.in.. Bidders are
allowed to bid 24x7 until the time of bid closing, with option for Re-Submission, wherein only their latest
submitted Bid would be considered for evaluation. The e-Procurement website will not allow any Bidder to
attempt bidding, after the scheduled date and time of Bid Submission. Submission of bids physically is not
permitted.
Earnest Money Deposit (EMD) and Tender Fee (TF)
is to be deposited as online mode only through
Net Banking as per e-tender procedures
Bid(s) shall be opened online by respective designated Bid
openers of the Department and the same shall be accessible by intending Bidder through website
https://tripuratenders.gov.in..
Contractor/Bidder

<!-- page 6 -->

e-Tender for procurement of planting materials

1. The finalized single rate will be utilized for procurement of Planting materials for raising of plantation
during the year 2026-27 under North Tripura DMU by the PIAs [Here in PIAs refers Project
Implementing Agencies i.e. Sub-Divisional Management Unit Chiefs (SDMUs)].
2. Bid documents consisting of qualifying information and eligibility criteria of bidders, specifications and
the set of terms and conditions of the contract to be complied by the bidder, is publicly visible in
the website https://tripuratenders.gov.in free of cost between Document Downloading Start date
19/06/2026 & Bid Submission End Date 25/06/2026.
3. Bid documents shall be uploaded in Single Bid System (Technical & Financial) with all Pre-Qualification
and other details. Bidder shall participate in bid online through website https://tripuratenders.gov.in, for
which they shall register/ enroll themselves in the same website. Submission of bids physically is not
permitted.
4. To participate in bid, the bidder shall have a valid Class 2/ Class 3 Digital Signature Certificate
(DSC), obtained from the certifying authorities enlisted by Controller of Certifying Authorities
(CCA) at http://cca.gov.in
5. Bid will be opened online through website https://tripuratenders.gov.in on tentative Bid Opening Date
29/06/2026 in the office of the District Management Unit Chief (District Forest Officer), North Tripura
DMU, Dharmanagar, Tripura but if the office happens to be closed on the date of opening of the
bids as specified, the bids will be opened on the next working day at the same time and venue.
6. If the amount quoted in the pre-defined Bill of Quantity (BOQ) by a bidder is found to be either
abnormally high or due to unethical practices adopted at the time of bidding process, such bids
shall or may be rejected.
7. Each Bidder shall submit only one bid for the work. A bidder who submits more than one bid
will cause disqualification of all the bids submitted by the bidder.
8. The suppliable stock against individual(s) will be at par the inspection report of the Inspection
team. Inspection will made by the Departmental officers before, during and after completion of the
supply of planting materials at frequent intervals.
9. The stock of the suppliable planting materials in the particular nursery is to be earmarked by
Inspection team and supply should be done from that particular stock.
10. Lifting should be done in presence of the representative of the concerned Project Implementing Officers,
North Tripura DMU, Tripura.
11. Latest renewal certificate of the license if applicable is to be uploaded along
Document.

with

the

Tender

12. During transportation, planting materials are to be kept in upright position positively in vehicle.
Planting materials brought in dumped condition in the vehicle will be rejected.
13. The supplier shall deliver the material within the delivery period mentioned in the supply order. In case of
any delay in executing the supply the supplier shall promptly inform the Project Implementing Agency i.e
the concerned SDFO in writing, the fact of delay and duration of extension for supply before the expiry
of the delivery period and extension of supply period would be subject to approval by the competent
authority of Department.
14. In the case of non acceptance of order, the Earnest Money will be forfeited.
15. The concerned PIAs i.e. SDMUs will issue supply order as per requirement wholly / partly and also
have the right to cancel the order, if the required items are not supplied in time.

Contractor/Bidder

<!-- page 7 -->

e-Tender for procurement of planting materials

16. In case of delay, more than specific period of supply, the supply order issuing authority (PIA) is authorized
to cancel the supply order & allot the supply to the next lowest eligible bidder on L1 rate at the risk and
cost of the defaulting bidder.
17. If the Planting materials supplied are not as per the required specifications mentioned in the tender
document then the payment will not be made & the supplier will lift the rejected Planting materials at his
own cost immediately.
18. Supply order of the planting material will be issued by the PIAs i.e. SDMU as per requirement to the
approved bidder, whose bid has been accepted by the Department. Supply should be completed in full
within the time period to be indicated in the supply order. Security money will liable to be forfeited by the
SDFOs on receipt of report/ complain if any from concerned PIAs in the event of failure to supply in full
as per supply order within the time schedule and the supply order(s) will likely be treated as cancelled.
19. The whole amount of security money will be liable to be forfeited to the Govt. in case of violation or
breach of any of the terms & condition.
20. No interest can be claimed in case of delay in making payment beyond the stipulated period of payment.
21. No conditional tender will be accepted whatever may be.
22. The undersigned reserves the right to reject or accept any tender including the lowest one partly or wholly
without assigning any reason or distribute the same to two or more tenderers, if necessary.
23. No need to participate in the tender who does not accept / fulfill the terms & conditions indicated.
24. Responsibility of stores during transit:Supplier shall be solely responsible for the stores in
transit. Any legal interference of police/ sales tax/ Income tax/ Transport/ Any other Government
agencies will be faced by the supplier. The transportation delay/ non availability of train/ trucks etc never
be considered by the tendering authority as reason of delay to supply and naturally no extension of delivery
period will be granted on this account.
25. The single FOR rate should be quoted for all the destination points mentioned in tender notice. The rate
quoted by the bidders shall be completed i.e. including the cost of planting materials, transporting, loading
and unloading, transit insurance, all taxes, charges and levies etc. and same rate will remain valid initially
up to one year from the date of acceptance of the rate and may be extended for a period of further 6 (six)
months if required.
26. Here in destination point refers to the Range Management Unit (RMU) Head quarter of two SDMUs
under DMU Chief, North Tripura DMU i.e.
(i) Dharmanagar and Panisagar Range Management Unit under Sub-Divisional Management Unit Chief,
Dharmanagar.
(ii) Kanchanpur Range Management Unit under Sub-Divisional Management Unit Chief, Kanchanpur.
27. The quantity of supply of Planting materials may increase or decrease according to actual
requirement of the PIAs (Sub-Divisional Management Unit Chief, Dharmanagar / Kanchanpur) at the
time of placing supply order.
28. While finalizing the rate through the tender process, the rate offered by the lowest bidder, if he is
from the district will be accepted as usual. But where the lowest bidder is from outside of the
district & the rate offered by him and the rate offered by the lowest bidder of the domestic district
falls within 15% higher of the rate offered by the lowest bidder of outside district, the domestic
bidder shall be given a chance to negotiate that if he shall be able to supply the planting
materials at the lowest rate offered by the L1 bidder who is from outside the district. Such
local bidder shall be given supply order up to 50% of the total order only.
29. There should be no cuttings/ over writings. The cutting, if any, should be duly attested. Unattested /
amended/ overwritten figures would not be considered.
Contractor/Bidder

<!-- page 8 -->

e-Tender for procurement of planting materials

30. The damage of planting materials during loading or transit to the destination point will be sole
responsibility of the supplier. Damaged/ defective Planting materials, if any must be replaced by
the supplier, PIAs (Sub-Divisional Management Unit Chief, Dharmanagar / Kanchanpur) will not entertain
such damaged/ defective over aged premature Planting materials.
31. No advance or part payment will be made. Payment shall be made electronically only by the
consignees (PIAs) as per tender terms and conditions and after satisfactory report received from the
recipient.
32. Supply order will be awarded to the lowest bidder for complete Planting materials as mentioned in this
tender who will fulfill all terms and conditions of tender documents along with quality criteria,
reasonability of rate.
33. TDS/ GST or any tax liable to PIAs for deduction (if applicable) will be deducted from the suppliers’ bill.
34. If an individual makes the bid, it shall be digitally signed by him/ her and the undertaking shall also be
signed with his/ her full name with his/ her address. If a bonafied nursery man makes the bid, he / she
should digitally sign it.
35. Jurisdiction: All question, dispute or difference in connection with the tender shall be subject to
exclusive jurisdiction of the court within the local limit of whole jurisdiction of Dharmanagar.
36. Any penal action imposed by the DMU Chief or authority for breach of terms & condition shall be
final and binding on the part of the supplier(s) / Tenderer(s) on receipt of report from PIAs.
37. In case of disputes, if any, the decision on the matter of dispute by the District Management Unit Chief,
Government of Tripura shall be the final and binding. It is also provided that the courts at North Tripura
DMUs in Tripura State only will have the jurisdiction to decide the dispute between the DMU Chief and
other party in respect of the matter arising out of the contract/ purchase order for the tender itself.
38. Dispute Resolution Mechanism (Arbitration): If any dispute or difference arises between the purchaser &
the supplier relating to any matter connected with the contract, the parties shall make every effort to resolve
the same amicably by mutual discussions. However, if the parties fail to resolve the dispute or difference
by such mutual discussion within 30 days, either the purchaser or the supplier may give notice to the other
party of its intention to refer the same to arbitration. The arbitration shall commence thereafter. The
arbitration shall be conducted by a sole arbitrator, who will be appointed by District Management Unit
Chief, North Tripura DMU, Dharmanagar, Tripura, the procedure to be followed in this respect will be as
per the Indian Arbitration & Conciliation Act, 1996. The venue of the arbitration shall be the place from
where the contract is issued.
39. District Management Unit Chief, North Tripura DMU, Dharmanagar, Tripura, reserves all right to accept
or reject any or all tender without assigning any reasons thereof.
40. Any documents in support of previous supply executed in this regard, if any, may be uploaded.
41. Documents to be uploaded:(a) Professional tax clearance Certificate.
(b) Photocopy of PAN Card.
(c) Skill Development Certificate, if any.
(d) Previous Experience Certificate, if any.
(e) Nursery Registration License (updated / validated).
(f) Notary attested copies of MOU, if any.
42. Rate Quotation:
BOQ should be downloaded from the e-procurement website https:// tripuratenders.gov.in and the same
BOQ should be filled up properly and uploaded as a part of bid with digital signing. Bidder shall
quote the Rate for each Planting materials in the Bill of Quantity (BOQ) which is in MS-Excel (macro
enabled) and Name of the bidder must be written in the appropriate field of Bill of Quantity (BOQ) by
Contractor/Bidder

<!-- page 9 -->

e-Tender for procurement of planting materials

bidder.
a) Bidder shall quote their rates in the prescribed format (BOQ) as per dimension/ requirement mentioned
in the Tender Document.
b) Rate(s) quoted by the Bidder is final for the period of contract. No subsequent escalation of price will
be accepted even in case of any increase of any material market price, increase in transport charges,
etc.
c) There shall be no separate
compensation in any ground.

re-imbursement

or

increase

of rate

or

payment

of

d) Amount of concession, transport subsidy etc. if applicable are to be reimbursed from Government
of India by the Tenderers themselves on the basis of certificate to be issued from the competent
authority.
43. Earnest Money Deposit (EMD) & Tender Fee:
43.1. Tender Fee and EMD are to be paid electronically using the Online Payment Facility provided in the
Portal. For online payment of Tender Fee and EMD, please follow the following process



After initiating the Bid Submission Process from "My Tender” option, an "OnlinePayment" page will
appear which will display the total TF & EMD amount.
On submission of TF & EMD payment option, system will redirect to the SBI Bank MOPS
window.
SBI MOPS will have two option for Net Banking- "SBI" & "Other Banks". Bidder can choose any
of the options as desired and can complete the Online Payment process.

43.2. The EMD amount shall be refunded to all the bidders including L1 (Selected)
respective Bank Account as per e-tender procedures.

bidder in their

43.3. No interest will be paid to the bidders on EMD submitted.
43.4. EMD of the bidder may be forfeited if in any case found to have made in false Declaration or Claims.
43.5. Bidders exempted under specific Government order/ rules from submitting EMD have to furnish
scan copy of the related Governments order/ rules in English language, along with the tender in
support of their claim exemption.
44. Agreement:
The successful tenderer shall have to execute an “AGREEMENT” with the District Management Unit
Chief, North Tripura DMU, Dharmanagar, Tripura for execution of work within 3 (three) days from
the date of intimating the awarded L1 Bidder (s) through mail/ telephone/ post. AOC will be issued
only after deposit of performance bank guarantee by the Li bidder. Failing which AOC (Award of
Contract) shall automatically stand cancelled and earnest money of the tenderer will be forfeited to
the Government account. At this situation appropriate decision taken by the Tender Inviting
Authority (the Undersigned) will be final.
45. Performance Security:
45.1. Successful bidder has to furnish “Performance Bank Guarantee” as per Performance Security for an
amount equal to 10% of the total contract value, issued by a Nationalized Bank in the format provided in
Annexure-VI in favour of Tender Inviting Authority. The successful bidder will be notified in writing to
deposit the said “Performance Bank Guarantee” within 3 (three) days of Notification regarding
successful bidder. The validity of Performance Guarantee shall be at least 180 days (One hundred eighty)
beyond the date of completion of the work, for completions of all contractual obligations of the bidder.
45.2. On receipt of the “Performance Bank Guarantee” from the selected Bidder, the office of the Undersigned
Contractor/Bidder

<!-- page 10 -->

e-Tender for procurement of planting materials

will scrutinize the received instrument for its authenticity and validity for the Amount and Period.
45.3. In the event of breach / violation or contravention of any terms and conditions contained herein by the
agency/bidders i.e., if the nursery man fails to execute the contract, the Performance Bank Guarantee,
part/ whole (as per decision of the Authority), will be forfeited from the guarantor.
45.4. The Performance Security will be released as per banking protocol on completion of the
successful execution of the task.
46. Signing:
If an individual nursery man makes the bid, it shall have to be digitally signed by him/ her and
the undertaking shall also be signed with his/ her full name and address. If a nursery man
makes the bid, a member of the firm shall digitally sign it and the undertaking shall be signed with
the co-partnership name by the same member of the firm, who shall also sign his/ her own
name, and the name and address of each member of the firm shall be given. If the bid is made
by a corporation, it shall be digitally signed by a duly authorized officer and the undertaking
shall also be signed by the same duly authorized officer who shall produce with his/ her bid
satisfactory evidence of his/ her authorization. Such corporation submitting bids may be
required to furnish evidence of its corporate existence, before the contract is executed.
47. Release of Payment:
a) No ADVANCE PAYMENT related to the work will be made under any circumstances.
b) The rate will remain valid and intact from the date of execution of the Deed of Agreement
till the end of work.
c) Payment will be made on the basis of completion and quality of planting materials supplied. Department
will not entertain any excuse for the delay and quality of work. In this scenario, Undersigned may impose a
penalty on the Bidder from Performance Security amount.
d) No interest can be claimed by the Bidder in case of delay in making payment beyond the stipulated
period of payment.
e) Department may include any item at any point of time beyond the scope of work mentioned, if necessary.
48. Bid Language: All documents to be uploaded by the Bidder shall be in English language only. In
case the Bidder intends to upload a document which is not in English but in any of the other
scheduled language in the country, the Bidder shall also submit a Notarized version of the English
Translation.
49. Force Majeure:
a) For purpose of this clause, “Force Majeure” means an event beyond the control of the supplier and not
involving the supplier’s fault or negligence and not foreseeable. Such events may include, but are not
restricted to, acts of the purchaser in its sovereign capacity, war or revolutions, fires, floods, epidemics,
quarantine restrictions and freight embargoes.
b) The supplier/ awardees shall not be liable for, forfeiture of its performance security, liquidated damages or
termination for default, if and to the extent that its’ delay in performance or other failure to perform its
obligations under the contract is the result of an event of Force Majeure.
c) If a Force Majeure situation arises, the supplier shall promptly notify the Undersigned in writing of
such conditions and the cause thereof. Unless otherwise directed by the Undersigned in writing,
the supplier shall continue to perform its obligations under t h e contract as far as reasonably
practical, and shall seek all reasonable alternative means for performance not prevented by the Force
Majeure event.
50. BOQ Tampering:
a) The provided BOQ in the Bid is meant for downloading in the Bidders machine, for entering the relevant
fields meant for rates & bidders particulars and finally uploading along with the Bid. The BOQ Excel
Sheet is Macro enabled and working with the Sheet requires the Macro to be allowed / enabled to run.
Contractor/Bidder

<!-- page 11 -->

e-Tender for procurement of planting materials

b) Bidders are hereby warned not to tamper with the MS-Excel Sheet, make copies and work in a
copied Sheet or break through the default Work-Sheet Security. Such BOQs with stated violations
will be treated as Tampered BOQs and Bids uploaded with Tampered BOQs will be summarily
rejected.
51. Financial Document to be uploaded
BOQ (Bill of Quantity)

Note: If any of the documents (Technical and Financial) contains multiple pages, bidder shall scan
and submit all the pages of the related documents. Missing of any pages of any type of any
documents will be considered as invalid documents and that bidder will be treated as rejected. Any
attempt to submit the missing pages physically will not be accepted/ processed.
52. During Technical Evaluation process, if any confusion arises in any of the technical documents,
bidder may be called to bring the original documents and produce the same in front of Tender
Screening Committee/ Tender Evaluation Committee.
53. The Tender as well as the Contract can be cancelled/ terminated at any point of time by the
Department without previous notice and without assigning any reason, whatsoever.

(S. Malla, IFS)
District Management Unit Chief
(District Forest Officer)
North Tripura DMU, Dharmanagar

Contractor/Bidder

<!-- page 12 -->

e-Tender for procurement of planting materials

SECTION - II

INSTRUCTIONS TO BIDDERS

Contractor/Bidder

<!-- page 13 -->

e-Tender for procurement of planting materials

INSTRUCTIONS TO BIDDERS
A. General
1. General
1.1.

To participate in the bid, the bidder shall have a valid Class 3 Digital Signature certificate (DSC),
obtained from either of the certifying authorities, enlisted by Controller of Certifying Authorities (CCA)
at http:// cca.gov.in.
1.2. The Bidder shall enroll himself/ herself in the e-procurement portal https: //tripuratenders.gov.in and
obtain User ID and Password for bidding.
1.3. On publication of the bid, bidder shall download the DNIT and all the work items from website as
mentioned in the DNIT and minutely go through the instructions/terms conditions/critical
dates/eligibility criteria of the DNIT.
1.4. The Bidders shall have to scan all the required documents mentioned in this DNIT into PDF format of
100 dpi resolution (black & white), for uploading as part of Bid. This is to reduce the size of the PDF
document and to prevent any java space issue.
1.5. Bill of Quantity (BOQ), which is in MS-Excel shall be downloaded, filled up properly and uploaded
with the bid after digital signing. The Bidder shall always open the BOQ sheet with Macro Enabled.
1.6. Bidders shall furnish a declaration (Annexure II) of pre-qualification information) as a part of bid that
they are not been blacklisted by any department in Tripura. Any wrong declaration in this regard which
comes to notice at a later date will disqualify them and the bids so received will be rejected.
1.7. If any of the certificates/documents furnished by the Bidder, found to be false / fabricated / bogus, the
bidder will be liable to blacklisted and their E.M.D. will be forfeited.
1.8. Rate Quotation: BOQ should be downloaded from the e-procurement application
https://tripuratenders.gov.in and the same BOQ should be filled up properly and uploaded as a part of
bid with digital signing. Bidder shall quote the Rate for all item/ selective item only in the Bill of
Quantity (BOQ) which is in MS-Excel (macro enabled) and Name of the bidder/company/firm must be
written in the appropriate field of Bill of Quantity (BOQ) by bidder.
1.9. Bidders are allowed to bid 24x7 until the time of Bid closing, with option for Re-Submission, wherein
only their latest submitted Bid would be considered for evaluation. The e-Procurement website will not
allow any Bidder to attempt bidding, after the scheduled date and time.
1.10. All the documents shall be submitted online at https://tripuratenders.gov.in only. Physical submission of
any document (hard copy) will not be entertained and will be liable for the rejection.
1.11. Downloaded DNIT document is to be uploaded back and digitally signed as a part of bid, and as a proof
of acceptance of all terms and conditions in the DNIT.
1.12. The dates stipulated in the bid notice are firm and under any circumstances, they will not be relaxed
unless officially extended.

2. Nurseries Eligible to Bid:
2.1.
i)
ii)
iii)

iv)
v)

The individual(s) who:
Are not blacklisted or debarred or suspended by the Government for Whatever the reason, prohibiting
them not to continue in the contracting business.
Have complied with the eligibility criteria specified in the NIT are the eligible bidders.
The individual(s) should have experience in the field of propagation of planting materials through
different mode of propagation i.e. through seed / vegetative mode etc of the sought after planting
materials and maintaining healthy scion bank of desired varieties and the produce is free from diseases /
pests etc.
All documentary evidence should be self-attested and digitally signed.
Suppliable quantity available for this season (2026-27) to be authenticated by the nursery Inspection
team/ Nursery Inspector/ Sector Officer/ SA/ SH of the concerned jurisdiction.

3. Pre-Qualification data of the Bidders
3.1.

3.2.

The bidder should satisfy the pre-qualification criteria as fixed under this NIT (Notice Inviting Tender)
and in case any bidder is not found satisfying any of such criteria as fixed, his/her bid will be summarily
rejected. The bidder shall furnish all the Technical and Financial particulars in the PDF of 100 dpi
resolution.
Even though the bidders meet all the qualifying criteria, they are liable to be disqualified / debarred /
Contractor/Bidder

<!-- page 14 -->

e-Tender for procurement of planting materials

3.3.

suspended / blacklisted if they have:
a) Furnished false/ fabricated particulars in the forms, statements and / annexure submitted in proof of
the qualification requirements and/or N
b) Not turned up for entering into agreement, when called upon.
c) Record of poor progress such as abandoning the work/ supply, not properly completing the contract,
inordinate delays in completion, litigation history or financial failures etc. and/or
d) Even while execution of the work, if found that the work was awarded to the Bidder based on false/
fake certificates of experience, the Bidder will be blacklisted and necessary action will be taken as
per rules.
Any definite attempt of profiteering by any bidder will render himself liable to be debarred permanently
from biding or for such period as the bid accepting authority may decide. The bidder overall rate should
be based on the controlled prices for the materials, if any, fixed by the Government

4. Number of Bid per Bidder : Each Bidder shall submit only one Bid for the work. A bidder who submits
more than one bid will cause disqualification of all the bids submitted by the bidder.

5. Cost of Bidding : The bidder shall bear all costs associated with the preparation and submission of his Bid
and the bid inviting authority will in no case be responsible and liable for those costs.

6. Site Visit : Inspection will be made by the Departmental officers before, during and after completion of the
supply of planting materials at frequent intervals.

7. Technical Specification :



Pineapple suckers
Areca nut seedlings

:
:



Agar Seedlings

:

Good and healthy quality ground pineapple sucker.
2 years old poly bag (collar girth: 3cm & seedling height: 2ft)
(Disease free).
At least 3 ft height (disease free) poly bag seedlings.

All the planting materials must be free of pest infestation.

B. BID DOCUMENT
8. Contents of Bid Documents.
One set of Bid document, comprises of the Technical documents and another set comprise of the Financial
Documents. In any circumstances if any Bidder upload the Financial documents in the Technical document
folder, then that bidder will be summarily rejected.
8.1.

One set of Bid document, comprises of the following:
i)
Notice Inviting Bids (NIT).
ii)
Instruction to Bidders.
iii)
Forms of Bid and qualification data of the bidder.
iv)
Conditions of Contract.
v)
Specifications.
vi)
Forms of Securities, i.e. EMD, Additional Security etc.
vii)
Bidder Sheet, Previous experience certificate, if any.
viii)
Bill of Quantities.

9. Clarification on Bid Documents.
9.1.

A prospective Bidder requiring any clarification on Bid documents may seek clarification through email- districtforestnorth@gmail.com. The Bid Inviting authority will also respond to such clarification
through e-mail. However, Bidder may contact the Bid Inviting Officer at the address indicated in the
NIT, for clarification on the bid document.
Contractor/Bidder

<!-- page 15 -->

e-Tender for procurement of planting materials

10. Amendment to Bid Documents
10.1.
10.2.

Before the last date for submission of Bids, the bid Inviting Officer may modify any of the contents of
the Bid Notice, Bid documents by issuing amendment / Addendum/ corrigendum.
Any addendum/ amendments/ corrigendum issued by the bid Inviting Officer shall be part of the bid
Document and it shall be published in the e-procurement portal at https://tripuratenders.gov.in
Registered Bidders shall be notified of the related Corrigendum(s) by e-mail. However, Directorate of
Horticulture & Soil Conservation, Tripura shall bear no responsibility or liability arising out of nonreceipt of the same in time or otherwise. Bidders are requested to visit the website frequently to check
whether there is any related Corrigendum(s) or not.

C. PREPARATION OF BIDS
11. Language of the Bid.
11.1.

All documents relating to the bid shall be in the English Language only.

12. Bid Offer: BOQ contains the quantities worked out by the Corporation and bidder shall quote the rate for
each planting materials.
13. Validity of Bids:
13.1.

Bids shall remain valid for a period of not less than 90 (ninety) days from the last date of bidding
specified in NIT.

13.2.

During the above-mentioned period, no plea by the bidder for any sort of modification of the bid based
upon or arising out of any alleged misunderstanding of misconceptions or mistake or for any reason will
be entertained.

14. Earnest Money Deposit (EMD)
14.1.
14.2.
14.3.

14.4.

The Bidder shall deposit EMD through online only.
The earnest money deposited by the successful bidder will not carry any interest and it will be dealt with
as provided in the conditions stipulated in the bid.
Tender Inviting Authority is liable to forfeit the 100% EMD amount and Cancellation of tender , if the
lowest bidder (L1) bidder does not appear after being awarded the Contract or unable to start the work/
start supply of item at stipulated time.
Successful bidder (L1) will have to executive a deed of Agreement with the tender inviting authority.

15. Alteration : Any alteration which is made by the bidder in the contract form, the conditions of the contract,
the drawings, specifications or statements / formats or quantities accompanying the same will be recognized;
and, if any such alterations are made the bid will be void.

D. SUBMISSION OF BIDS
This is a one stage Bidding Process which deals with only Technical Bid and Financial Bid. Below is
the workflow for Stage wise Tender
Create & Publish
Bidder will submit all Technical documents & shall quote the rate & submit the BOQ
Technical Evaluation done by Tender Inviting Authority
Bidder Financial Evaluation done by Tender Inviting Authority
Tender Inviting Authority shall select the L1 Bidder as per terms & conditions in DNIT.

Contractor/Bidder

<!-- page 16 -->

e-Tender for procurement of planting materials

The desirous participants shall submit all the technical documents online at http://tripuratenders.gov.in.
Note: If any of the above mentioned documents (List of the documents to he / she shall prepare a PDF
Document containing the remark as ‘NOT APPLICABLE’ WITH NAME OF THE BIDDER & ADDRESS
and upload the same in the relevant Folder.
If any of the certificates/documents furnished by the Bidder, found to be false / fabricated / bogus, the bidder will be
liable to blacklisted and their E.M.D. will be forfeited.
16. Submission of Bids:
16.1.

The Bidders, who are desirous of participating in bid, shall submit their Pre-Qualification and other
details etc., in the Standard formats prescribed in the bid documents through the website only
https://tripuratenders.gov.in.
16.2. List of documents to be scanned and uploaded:
A. Documents to be kept in "My Document” folder of Bidder: The following documents, as per standard
format detailed in bid document, or as per standard dictated by Regulatory/ Statutory bodies, shall be
scanned and uploaded along with the bid document as per requirements.
For ease of biding, the bidders shall scan the following documents at 100 dpi resolution and upload them as
per the folder structure provided in his/her “My Document”, which is provided free of cost to all bidders, post
his/her registration in the website only. This operation is expected to be completed, before commencement of
actual biding by the bidder.
Sl. No
Technical Documents to be uploaded
1
Declaration of the Bidder as per Annexure-II, III, IV
2

Scan copy of the PAN card

3

Specification of the all the quoted item

4

Professional Tax Clearance

5

Previous Experience

6

Renewal/latest valid License of Nursery

During actual bidding, the bidder shall select/ check these documents from his/ her My Document, which
will ensure completion of biding within the same session, even if the bidder is connecting to the application
over a slow speed network.
B. Technical Bid Documents required during actual Bidding :
In addition to the documents kept in “My Document” folder, the following documents are also to be
uploaded to the e-Procurement application during actual biding.
Sl. No Folder Name
1
2

Documents to be uploaded
Copies of documents relating to the license issued from the
License
competent authority to the Government.
Downloaded DNIT as a proof of acceptance of all terms &
DNIT document
Conditions in the DNIT signed on each page.

Note: Bidder shall fill the necessary information & put signature with stamp/seal, and then scan them into
PDF (in 100 dpi resolution). Finally those documents should be uploaded (with digital signing).
C. Financial Bid Documents required during actual Bidding: In addition to the technical documents, the
following are the documents also to be uploaded to the eProcurement application during actual biding.

Contractor/Bidder

<!-- page 17 -->

e-Tender for procurement of planting materials

16.3.

Sl. No

Financial Documents to be uploaded

1

Bill of Quantity

If any of the certificates/documents furnished by the Bidder, found to be false / fabricated / bogus, the
bidder will be liable to blacklisted and their EMD will be forfeited.

17. Last date / time for Submission of the Bids.
17.1.
17.2.

Bids must be submitted not later than the date and time specified in NIT.
The District Management Unit Chief, North Tripura DMU, Dharmanagar, Tripura may extend the dates
for issue and receipt of Bids by issuing an amendment and the bidders will remain same as previously.

18. Late Bids.
18.1.

The e-Procurement website https://tripuratenders.gov.in will not allow any Bidder to attempt bidding,
after the scheduled date and time prescribed in NIT.

D. BID OPENING AND EVALUATION
19. Bid Opening
19.1.

The bids will be opened online by the Bid openers on behalf of the District Management Unit Chief,
North Tripura DMU, Dharmanagar, Tripura at the time, date and venue as specified in the bid
documents. Bids shall be scrutinized in accordance with the conditions stipulated in the Bid document by
the constituted Scrutiny /Evaluation Committee. In case of any discrepancy of non-adherence
Conditions, the Bid accepting authority shall communicate the same which will be binding both on the
bid Opening authority and the Bidder. In case of any ambiguity, the decision taken by the Bid Accepting
Authority on bids shall be final.

20. Bid Evaluation and Comparison of Bids.
20.1.

All the statement, documents, certificates, demand draft, BOQ etc., shall be submitted/uploaded by the
bidder will be verified for evaluation of bids. The clarifications, particulars, if any, required from the
bidders, will be obtained by addressing the bidders. Bids will be evaluated against the specified
parameters / criteria same as in the case of conventional bids and the qualified bidders will be identified.
The result of bids evaluation can be seen in the e-procurement website https://tripuratenders.gov.in by all
the bidders who participated in the Bid.

20.2.

The ‘BOQ Comparative Chart’ generated & displayed by system through the e-procurement portal, after
the opening of Bid, will show the amount calculated based on percentage rate quoted by the bidders. The
bidder shown as lowest (L1) in the bid rank of the ‘BOQ Summary Details’, may not be the lowest
always. The prescribed authority (i.e. Bid Opening Committee) in the Corporation will prepare a
‘Comparative Statement’ considering all parameters as per conditions given in the bid document. This
‘Comparative Statement’, declaring lowest bidder (L1), will be displayed in the e-procurement portal
subsequently.

20.3.

NO NEGOTIATION WILL BE CONDUCTED WITH THE LOWEST BIDDER. However, while
finalizing the rate through the tender process that, the rate offered by the lowest bidder, if he is from the
district will be accepted as usual. But where the lowest bidder is from outside of the district & the rate
offered by him and the rate offered by the lowest bidder of the domestic district falls within 15% higher
of the rate offered by the lowest bidder of outside district, the domestic bidder shall be given a chance to
negotiate that if he shall be able to supply the planting materials at the lowest rate offered by the L1
bidder who is from outside the district. Such local bidder shall be given supply order up to 50% of the
total order only.

20.4.

Details of ‘Bid Evaluation Committee’ shall be uploaded in the e-procurement
https://tripuratenders.gov.in and all the bidders can access the same.

portal

Contractor/Bidder

<!-- page 18 -->

e-Tender for procurement of planting materials

20.5.

Tender Inviting Authority shall have the right to cancel the tender at any stage without any prior notice.

21. Discrepancy in Bid rate quoted.
21.1.

Bids shall be scrutinized in accordance with the conditions stipulated in the Bid document. Bidder shall
quote rate in figures only. BOQ (in MS-Excel format) shall be open with Macro Enabled for automatic
conversion from figures to words. In case of any ambiguity, the decision taken by the Bid Accepting
Authority on Bidders shall be final.

22. Process to be Confidential.
22.1.

Information relating to the examination, clarification, evaluation and comparison of Bids and
recommendations for the award of a contract shall not be disclosed to the Bidders or any other persons
not officially concerned with such process until the award to the successful Bidder has been announced
by the bid accepting authority. Any effort by a Bidder to influence the processing of Bids or award
decisions may result in the rejection of his Bid.

22.2.

No Bidder shall contact the higher authority concerned with finalization of bids on any matter relating to
its Bid from the time of the Bid opening to the time the Contract is awarded.

22.3.

Before recommending / accepting the bid, the bid recommending / accepting authority shall verify the
correctness of certificates submitted to meet the eligibility criteria and specifically experience. The
authenticated agreements of previous works executed by the lowest bidder may be called for.

E. AWARD OF CONTRACT
23. Award Criteria
23.1.

The Undersigned (District Management Unit Chief, North Tripura DMU, Dharmanagar, Tripura) will
award or recommend to the Competent bid accepting authority for award of the contract to the Bidder
who is found Technically Qualified as per the Bid conditions and whose Offer Rate is considered as final
by the Undersigned.

23.2.

The bid accepting authority reserves the right to accept or reject any Bid or all bids and to cancel the
Bidding process, at any time prior to the award of Contract, without thereby incurring any liability to the
affected Bidder or Bidders or any obligation to inform the affected Bidder or Bidders of the reasons for
such action.

23.3.

While finalizing the rate through the tender process that, the rate offered by the lowest bidder, if he is
from the district will be accepted as usual. But where the lowest bidder is from outside of the district &
the rate offered by him and the rate offered by the lowest bidder of the domestic district falls within 15%
higher of the rate offered by the lowest bidder of outside district, the domestic bidder shall be given a
chance to negotiate that if he shall be able to supply the planting materials at the lowest rate offered by
the L1 bidder who is from outside the district. Such local bidder shall be given supply order up to 50%
of the total order only.

24. Notification of Award and Signing of Agreement.
24.1.

The Bidder whose Bid has been accepted will be notified of the award of contract by any authorized
official, prior to expiration of the Bid validity period by publishing the Award of Contract in the Tripura
Tenders portal and also may send the same through registered letter.

24.2.

The successful bidder has to sign an agreement within a period of 15 days from the date of receipt of
communication of acceptance/ award of his bid. On failure to do so his bid will be cancelled duly
forfeiting the EMD, paid by him without issuing any further notice.
Contractor/Bidder

<!-- page 19 -->

e-Tender for procurement of planting materials

25. Corrupt or Fraudulent Practices
The Department requires that the bidders / suppliers / Bidders under Government financed contracts, observe
the highest standard of ethics during the procurement and execution of such contracts. In pursuance of this
policy, the Department:
(a) Define for the purposes of the provision, the terms set forth below as follows:
i)
“Corrupt practices” means the offering, giving, receiving or soliciting of anything of value to
influence the action of a Government official in procurement process or in contract execution: and
ii)
“Fraudulent practice” means a misrepresentation of facts in order to influence a procurement process
or the execution of a contract to the detriment of the Government and includes collusive practice
among Bidders (prior to or after Bid submission) designed to establish in Bid prices at artificial noncompetitive levels and to deprive the Government of the benefits of free and open competition.
(b) Will reject a proposal for award if it determines that the Bidder recommended for award has engaged in
corrupt or fraudulent practices in competing for the contract in question.
(c) Will blacklist / or debar a firm, either indefinitely or for a stated period of time, if at any time determines
that the firm has engaged in corrupt or fraudulent practices in competing for, or in executing a
Government Contract.
(d) Furthermore, Bidders shall be aware of the provisions stated in the General Conditions of Contract.

Contractor/Bidder

<!-- page 20 -->

e-Tender for procurement of planting materials

SECTION - III

FORMS OF BID
QUALIFICATION INFORMATION

Contractor/Bidder

<!-- page 21 -->

e-Tender for procurement of planting materials

QUALIFICATION INFORMATION
Annexure-I
CHECKLIST TO ACOMPANY THE BID
[Bidder should mark (

Sl. No
1
2
3
4
5
6
7
8

) on any of the option Yes or No w.r.t the respective description, sign, scan in ‘pdf’ format
and upload the same in the Tripura tenders portal]

Description

Submitted

Copies of documents relating to the Registration of the firm, Registration as Civil Bidder,
Partnership deed, Articles of Association
Copy of Professional Tax clearance certificate
Copy of valid GST Registration Certificate
Downloaded DNIT as a proof of acceptance of all terms conditions in the DNIT.
Declaration of the Bidder as per Annexure-II
Nursery License
Undertaking as per Annexure- V
Bank solvency as per Annexure- VI

Yes / No
Yes / No
Yes / No
Yes / No
Yes / No
Yes / No
Yes / No
Yes / No

Signature of the Bidder

Contractor/Bidder

<!-- page 22 -->

e-Tender for procurement of planting materials

[To be filled by Bidder- sign, scan in PDF format and upload the same in the Tripura tenders portal]

Annexure-II

DECLARATION

I / we

have gone through carefully all

the Bid conditions and solemnly declare that I / we will abide by any penal action such as disqualification or black
listing or termination of contract or any other action deemed fit, taken by, the Government/Corporation against us, if
it is found that the statements, documents, certificates produced by us are false / fabricated. I / we hereby declare
that, I / We have not been blacklisted / debarred / Suspended / demoted in any department in Tripura or in any State
of India due to any reasons.

Signature of the Bidder

Contractor/Bidder

<!-- page 23 -->

e-Tender for procurement of planting materials

SECTION- IV

CONDITIONS OF CONTRACT

Contractor/Bidder

<!-- page 24 -->

e-Tender for procurement of planting materials

[To be filled by Bidder- sign, scan in PDF format and upload the same in the Tripura tenders portal]

Annexure-V

Undertaking
Date: ..............
To,
The District Management Unit Chief,
(District Forest Officer)
North Tripura DMU,
Dharmanagar, Tripura.
Sir,
I / We
do hereby bid and if this bid be accepted,
under take to execute the work entitled “Supply of Arecanut seedlings to different destination points as called for. As
shown in the tender, with such variations by way of alterations or additions to, and omissions from the said works
and of payment as provided for in the “conditions of the contract” for the sum of Rupees
To
Be Filled In During Signing of Agreement) ................................................................. or such other sum as may be
arrived under the clause of the standard preliminary specifications relating to “Payment on lump-sum basis or by
final measurement at unit rates”
I/WE have also quoted the rate in Bill of Quantities (BOQ) in figures & letters, for which I/We agree to
execute the work when amount payment under the terms of the agreement is varied by payment on measurement
quantities.
I/WE have not tampered with the provided Bill of Quantity (BOQ) and I /WE have uploaded the same
downloaded BOQ after filling in the necessary fields.
I/WE agreed to keep the offer in this bid valid a period of ........ (......................................... ... ) days as
mentioned in the bid notice and not to modify the whole or any part of it for any reason within above period. If I/WE
withdraw the bid for any reasons whatsoever, the earnest money paid by me/us will be forfeited to the Tender
Inviting Authority.
I/WE hereby distinctly and expressly, declare and acknowledge that, before the submission of my/our bid
I/We have carefully followed the instructions in the bid notice and the preliminary specifications and that I/We have
made such examination of the contract documents and the plans, specifications and quantities and of the location
where the said work/supply is to be done, and such investigation of the work/goods/equipment’s required to be done,
and in regard to the material required to be furnished as to enable me/us to thoroughly understand the intention of
same and the requirements, covenants, agreements, stipulations and restrictions contained in the contract, and in the
said plans and specifications and distinctly agree that I/We will not hereafter make any claim or demand upon the
Government based upon or arising out of any alleged misunderstanding or misconception /or mistake on my/or our
part of the said requirement, covenants, agreements, stipulations, restrictions and conditions.
I/WE enclosed to my/our application for bid a crossed “Demand Draft/“Deposit at Call Receipt”
(No.............................................................. dated:.........................for Rupees.............................................................. as
earnest money not to bear interest.
I/WE shall not assign any Bidder or sublet any portion of the same.
If MY/OUR bid is not accepted the sum shall be returned to me/us on application when intimation is sent to
me/us of rejection or at the expiration of .............. (....................... ............................... ) days from last date of receipt
of this bid, whichever is earlier. If my /our bid is accepted, the earnest money shall be returned by the Tender
Contractor/Bidder

<!-- page 25 -->

e-Tender for procurement of planting materials

Inviting Authority. If upon awarded the contract to me/us by the District Management Unit Chief, North Tripura
DMUDharmanagar, Tripura and I/We fail to attend the said office on the date herein fixed or if upon intimation
being given to me/us by The District Management Unit Chief, North Tripura DMU, Dharmanagar, Tripura, or
acceptance of my/our bid, and if I/We fail to make the additional security deposit or to enter into the required
agreement as defined in condition-3 of the bid notice, then I/We agree the forfeiture of the earnest money. Any
notice required to be served on me/us here under shall be sufficiently served on me/us if delivered to me/us
hereunder shall be sufficiently served on me/us if delivered to me/us personally or forwarded to me/us by post to
(registered or ordinary) or left at my/our address given herein. Such notice shall if sent by post be deemed to have
been served on me/us at the time wherein due course of post it would be delivered at the address to which it is sent.
I/WE fully understand that the written agreement to be entered into between me/us and Government shall be the
foundation of the rights of the both the parties and the contract shall not be deemed to be complete until the
agreement has first been signed by me/us and then by the proper officer authorized to enter into contract on behalf of
Government.

UNDERTAKING OF THE BIDDER
1) I /WE have not been black listed in any department in Tripura due to any reasons.
2) I/WE have not been demoted to the next lower category for not filing the bids after buying the bid schedules
in a whole year and my/our registration has not been cancelled for a similar default in two consecutive years.
3) I/WE agree to disqualify me/us for any wrong declaration in respect of the above and to summarily reject
my/our bid.
Address of the Bidder:

Phone No.:

e-mail address (if any):

Note: If an individual makes the bid, it shall be digitally signed by him/her and the undertaking shall also be signed
with his/her full name and his/her address. If a firm makes the bid, a member of the firm shall digitally sign it and the
undertaking shall be signed with the co-partnership name by the same member of the firm, who shall also sign
his/her own name, and the name and address of each member of the firm shall be given. If the bid is made by a
corporation, it shall be digitally signed by a duly authorized officer and the undertaking shall also be signed by the
same duly authorized officer who shall produce with his/her bid satisfactory evidence of his/her authorization. Such
corporation submitting bids may be required to furnish evidence of its corporate existence, before the contract is
executed.

Signature of the Bidder

Contractor/Bidder

<!-- page 26 -->

e-Tender for procurement of planting materials

SECTION- V

TECHNICAL SPECIFICATIONS

Contractor/Bidder

<!-- page 27 -->

e-Tender for procurement of planting materials

Rate Sheet
e-Tender for supply of Seedlings.



Pineapple suckers
Areca nut seedlings

:
:



Agar Seedlings

:

Good and healthy quality ground pineapple sucker.
2 years old poly bag (collar girth: 3cm & seedling height: 2ft)
(Disease free).
At least 3 ft height (disease free) poly bag seedlings.

Signature of bidder with Date & Seal

Contractor/Bidder

<!-- page 28 -->

e-Tender for procurement of planting materials

SECTION- VI

FORMS OF SECURITY

Contractor/Bidder

<!-- page 29 -->

e-Tender for procurement of planting materials

[To be filled by Bidder - sign, scan in PDF format and upload the same in the Tripura tenders portal]

Annexure-VI

FORM OF SOLVENCY CERTIFICATE FROM A SCHEDULED BANK

This is to certify that to the best of our knowledge and information Mr. /Sri

.

having marginally noted address, a customer of our bank are/is respectable
and can be treated as good for any engagement up-to a limit of Rs..................................(Rupees
..............................................................................................).

This certificate is issued without any guarantee or responsibility on the Bank or any of the officers.

(Signature)
For the Bank

NOTE: In case of partnership firm, certificate to include names of all partners as recorded with the Bank.

Contractor/Bidder

<!-- page 30 -->

e-Tender for procurement of planting materials

[To be filled by Bidder - sign, scan in PDF format and upload the same in the Tripura tenders portal]
Annexure-IV
PERFORMANCE BANK GUARANTEE
To,
…………………………………………… (Name of the Employer)
…………………………………………… (Address of Employer)

WHEREAS........................................................................................................................... (Name and address of
Bidder)
(Herein
after
called
“the
Bidder”)
has
undertaken,
pursuance
of
contract
No................................................................................................
dated
...........................
to
execute.............................................................................................. ....................... (Name of contract and brief
description of works) herein after “The Contract.”
AND WHEREAS it has been stipulated by you in the said contract that the Bidder shall furnish you with a bank
guarantee by a nationalized bank for the sum specified therein as security for compliance with his obligation in
accordance with the contract.
AND WHEREAS we have agreed to give the Bidder such bank guarantee.
NOW THEREFORE, we hereby affirm that we are the Guarantor and responsible to you on behalf of the
Bidder,
up
to
a
total
of..............................................
(amount
of
guarantee)......................................................................................(in words), such sum being payable in the types
and proportions of currencies in which the contract price is payable, and we undertake to pay you, up on first
written demand and without cavil or argument, any sum or sums within the limits of.........................................
(Amount of guarantee) as aforesaid without your needing to prove or to show grounds or reasons for a demand
for the sum specified therein.
We hereby waive the necessity of your demanding the said debt from the Bidder before presenting us with the
demand. We further agree that no change or addition to or other modification of the terms of the contract for
supply or of the works to be performed hereunder or of any of the contract documents which may be made
between you and the Bidder shall in any way release us from any liability under this guarantee and we hereby
waive notice of any such change, addition or modification.
This guarantee shall be valid until a date (28 days) from the date of expiry of Defects Liability Period of 12
months after intended completion date.

Signature and Seal of the Guarantor..................................................................................
Name of the Bank............................................................................................................
Address.....................................................................................................................
Date......................

Contractor/Bidder

<!-- page 31 -->

e-Tender for procurement of planting materials

SECTION- VII

BIDDERS SHEET

Contractor/Bidder

<!-- page 32 -->

e-Tender for procurement of planting materials

[To be filled by Bidder - sign, scan in PDF format and upload the same in the Tripura tenders portal]

BIDDER SHEET
Bidders are requested to provide wanted information in this sheet.

1. Detailed Address of the Bidder along with Phone number, e-mail Id.
2. Detailed Address of nursery area of planting materials.
3. Details about the license/registration for production and supply of planting materials.
4. Details about the certified suppliable stock of planting materials for 2026-27 planting season.
5. Detailed address of the local agent, if any of the bidder along with Phone (Landline/ mobile), Fax
number with STD code, e- mail address if any.
6. If the bidder has any past experience of supply of such planting materials under the competent authority.
If yes, give details with documents.
7. Please justify how you will maintain the time schedule of the tendered quantity.
8. Detailed Address of the Government authorized Inspection Agency or any other leading Inspection
agencies under whose jurisdiction the production centre of the bidder belongs to.
9. Is there any court case or any other dispute related with production centre i.e. nursery(s) of the bidder or
their Principal firm is pending/under process? If so, please give details.

10. Please indicate production details:
11. Bidders may use this space to provide any further information to explain their bids (if required)

Signature of bidder with Date & Seal

Contractor/Bidder

<!-- page 33 -->

e-Tender for procurement of planting materials

SECTION- VIII

BILL OF QUANTITIES

Contractor/Bidder

<!-- page 34 -->

e-Tender for procurement of planting materials

NOTES ON BILL OF QUANTITIES
PREAMBLE
1. The Bill of quantity shall be read in conjunction with the NIT instruction to Bidder, conditions of
contract of Specifications.
2. Bill of Quantity (BOQ), which is the Rate quoting sheet in MS-Excel format shall be downloaded from
e-procurement portal, filled up properly and uploaded in the bid after digital signing.
3. The Bidder shall always open the BOQ sheet with Macros Enabled.
4. Name of bidder must be written in the appropriate field of rate quoting sheet by each bidder.
a) For the supply of the quantities given in the Schedule of quantities are estimated and given to
provide a common basis for bidding. The basis of payment will be the actual quantities of the
supply order.
b) At the rates bided in the Schedule of quantities in the case of item rate bids; and
c) At percentage rate above / below / at par of the schedule of rates as bided by the Bidder.
5. The rates bided in the priced bill of quantity (BOQ) shall, except in so far as it is otherwise provided
under the contract.
6. When percentage rate bids are invited, the schedule of quantities will show the rates used for different
items.
7. BOQ TAMPERING:
a) The provided BOQ in the Bid is, meant for downloading in the Bidders machine, for entering the
relevant fields meant for rates & bidders particulars and finally uploading along with the Bid. The BOQ
Excel Sheet is Macro enabled and working with the Sheet requires the Macro to be allowed /enabled to
run.
b) Bidders are hereby warned not to tamper with the MS-Excel Sheet, make copies and work in a copied
Sheet or break through the default Work-Sheet Security. Such BOQs with stated violations will be
treated as Tampered BOQs and Bids uploaded with Tampered BOQs will be summarily rejected.

Contractor/Bidder

<!-- page 35 -->

e-Tender for procurement of planting materials

Rate Sheet
Rate Quoted for supply of each Planting Materials.
Sl.
No.

1

Name of
the item

Amount quoted per no. (Should
Quantity (no.) be quoted in figure & letter)
including all charges

Total amount against
total quantity (Should be
quoted in figure & letter)
including all charges

Specifications
As specified in
the Technical
specification
section of the
concerned crop

Signature of the bidder

Contractor/Bidder
