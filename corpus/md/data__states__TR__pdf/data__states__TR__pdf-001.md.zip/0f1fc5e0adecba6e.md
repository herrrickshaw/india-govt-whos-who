---
doc_id: "0f1fc5e0adecba6e"
source_url: "https://jami.tripura.gov.in/download/LND_R_1961.pdf"
ministry: "Digital India Land Records Modernization Programme (DILRMP), Tripura"
title: "Land Reforms Rules 1961"
date: ""
pages: 138
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ea9278a9abaa455b"
---

<!-- page 1 -->

The Tripura Land revenue and Land Reforms Rules, 1961
ARRANGEMEMT OF RULES
CHAPTER I
PRELIMINARY
RULES:
1. Short Title.
2. Definitions
3. Distance of a nearby village for purpose of personal cultivation.

1
1
1

CHAPTER II
General Powers of revenue Officer
4. General powers of the Collectors.
5. General powers of Survey & Settlement Officer.
6. General powers of superior officers.

2
2
2

CHAPTER III
Land and Land Revenue
7. Decision of dispute referred to in section 11(5)
8. Preservation and disposal of trees, jungles, etc.
9. Survey and demarcation of pasturage.
10. Hearing of objection.
11. Disposal of objections.
12. Declaration of pasturage.
13. Use of pasturage.
14. Cancellation or modification of declaration under rule 12.
15. Setting apart of land for community purposes.
16. Setting apart of land for Forest Reserve.
17. Management of land by gram Panchayat.
18. Procedure for summary eviction.
19. Exemption from land revenue.
20. Deleted
21. Application for remission of land revenue.
22. Deleted.
23. Diversion of land to agricultural purpose.
24. Diversion of land other purpose.
25. Calculation of fraction.
26. Remission or suspension of land revenue
27. Remission when to be allowed.
28. Relief in widespread calamities.
29. Relief in local calamities.
30. Relief in case of orders, by court etc.

2
2
2
3
3
3
3
3
3
3
3
3
4
4
4
4
4
4
4
5
5
5
5
5

<!-- page 2 -->

ii
RULES :
31. Announcement of relief.
32. Stay orders by Collector.
33. Collection of suspended land revenue.
34. Remission of suspended.
35. From of receipt for land revenue.
CHAPTER IV
Survey and Settlement of Land Revenue
36. Profits of agriculture and value of land
37. Publication of table of profits of agriculture and value of land
38. Omitted.
39. Notification and proclamation of revenue survey.
40. Revenue survey and preparation of record of rights.
41. Assessment nit.
42. Maximum revenue rates.
43. Form of table of revenue rates.
44. Annexure to table of revenue rates.
45. Publication table of revenue rates.
46. Disposal of objections.
47. Alteration or revisions of revenue rates.
48. Ratio between old and new revenue rates.
49. Principles of apportionment of costs.
50. Liability of individual for costs.
51. Apportionment of liability of costs and notice thereof.
52. Settlement register.
CHAPTER V
LAND RECORDS
53. Record of rights.
54. Khasra.
55. Notification and proclamation.
56. Stages of revenue survey and preparation of record of rights.
57. Notification for assistance.
58. Village boundary demarcation.
59. Traverse survey.
60. Cadastral Survey.
61. Survey Number.
62. Preparation of preliminary record of rights.
63. Bujharat.
64. Attestation including ascertainment of rent and revenue.
65. Publication of the draft records of rights.
66. Disposal of objections.
67. Framing of final record.
68. Final publication of the records of tights.

6
6
6
6
6

7
7
8
8
8
8
9
9
9
9
9
9
9
10
10
10
10

12
12
12
12
13
13
13
13
13
13
13
14
15
15
15
15

<!-- page 3 -->

iii
RULES
69. Availability of copies of records and recovery of cost.
70. Revision of correction of records.
71. Intimation of correction.
71.A Preparation of field index (Khasra).
72. Register of mutations.
73. Rewriting of records of rights.
74. Report for mutation.
75. Mutation not to be in contravention of the Act.
76. Intimation about mutation.
77. Register of disputed cases.
78. Acknowledgement of objection.
79. Testing of entries.
80. Information to be supplied to Collector on requisition.
81. Alteration of registers on decree of court.
82. Inspection and grant of copies.

16
16
16
16
17
17
17
18
18
18
18
19
19
19

CHAPTER VI
Boundaries and boundary Marks
83. Determination boundary disputes.
84. Description of boundary marks.
85. Erection of boundary marks on requisition.
86. Maintenance of boundary marks.
87. Register of boundary marks.

19
19
20
20
20

CHAPTER VII
Realisation of Land Revenue and Other Public Demands
88. Land revenue when and how payable.
89. Notice of demand.
90. Distraint and sale of movable property.
91. Distraint of movable property other than the produce of the land.
92. Distraint of produce of land.
93. Custody of distrained property.
94. Leaving live stock in the charge of pound keeper.
95. Attachment of immovable property.
96. Management of attached property.
97. Claims of Third Persons.
98. Objection by defaulter.
99. Proclamation for sale.
100. Inspection and copy of sale proclamation.
101. Date of sale.
102. Absence or insufficiency of bid.
103. Sale Officer.
104. Auction sale when to stop.
105. Objection by purchaser.

20
20
21
21
21
22
22
22
22
22
23
23
23
23
23
24
24
24

<!-- page 4 -->

iv
RULES
106. Application for setting aside the sale.
107. Certificate of purchase.
108. Delivery of possession.
109. Intimation to the commanding officer of cantonment.
110. Cost of proclamation and other costs.
111. Recovery of other amounts recoverable as arrears of land revenue.
112. Fees to be charged for execution of processes.
113. Application of the code of civil procedure.

24
24
24
24
25
25
25
26

CHAPTER VIII
Procedure of Revenue Officer.
114. Form service of summons.
115. Balisble warrant of arrest.
116. Delivery of possession.
117. Obstruction of delivery of possession.
118. use of force against person putting restraint.
119. Dismissal of application for possession.
120. Transfer by judgement debtor.
121. Application by person wrongly dispossessed.
122. Order for re-delivery of possession.
123. A person other than a judgement debtor may institute a suit.
124. Procedure of revenue court and officers.
125. Extent of applicability of C.P.C.
CHAPTER IX
Rights of Raiyats in Land
126. Reservation of land for personal cultivation.
127. Notice to under raiyat.
128. Reply of under raiyat.
129. Disposal of the application.
130. Certificate.
131. Notice to issue when land left uncultivated.
132. Service of Notice.
133. Compliance of notice.
134. Lease by Collector.
135. Notice of relinquishment.
CHAPTER IX A.

26
26
26
26
27
27
27
27
27
27
27
27

28
28
28
28
28
28
29
29
29
29

Certain restrictions on the rights of transfer for the protection of the interests of the
scheduled tribes.
136.A Service of Notice for transfer.
30
CHAPTER X
Rights of under-raiyat.
137. Application for permission when raiyat refuses or its to consent.
31

<!-- page 5 -->

V
RULES :
138. When permission may be granted or refused.
139. Compensation for improvement.
140. Benefit of improvement to under-raiyat in certain cases.
141. Under raiyat to pay back the compensation.
142. Estimating the value of produce for purpose of rent.
142A Determination of the fixed produce rent.
143. Payment of rent.
144. Postal receipt and enclosures to be adminisible in evidence.
145. Payment of rent in certain cases.
146. Power to deposit rent in certain cases with circle officer.
147. Application for deposit.
148. Receipt to be granted.
149. Notice of deposit.
150. Payment of deposited rent.
151. Determination of reasonable rent.
152. Factors for determination of reasonable rent.
153. Date from which the order for reasonable rent to take effect.
154. Commutation of rent payable in kind.
155. Manner of inquiry.
156. Passing of an order.
157. Receipt for payment of rent.
158. Presumption regarding incomplete receipt.
159. Eviction of under-raiyat.
160. Application for restoration of possession of land to under-raiyat.
161. Disposal of application.
162. Declaration of non-resumable land of under-raiyat.
163. From and manner of application under section 123(1).
164. Application for surrender of land by an under-raiyat.
165. Compensation to raiyat.
166. Application for surrender of land by an under-raiyat.
167. Payment of compensation to raiyats.
168. Payment of compensation by nder-raiyat.
169. First option to purchase.

31
31
32
32
32
32
32
33
33
33
33
33
34
34
34
34
34
34
34
34
35
35
35
35
35
35
36
36
36
36
37
37
37

CHAPTER XI
Acquisition of estates and of the Rights of Intermediaries therein.
170. Manner of publication of notification under section 134.
171. Value of produce building and structures.
172. Service of the order of the Collector under section 137
and form as statement referred to therein.
173. Procedure for search and seizure.
174. Inspection.

38
38
38
39
39

<!-- page 6 -->

vi
RULES:
CHAPTER XII
Assessment and payment of Compensation.
175.
176.
177.
178.
179.
180.
181.
182.
183.
184.
185.
186.
187.
188.
189.

Collection of information by the Compensation Officer.
Procedure on return being filed.
Procedure when returns submitted to more than one officers.
Commutation of rents in kind.
Manner of payment perpetual annuity.
Manner of making claims by a creditor.
Preparation of compensation assessment roll.
Preliminary publication of compensation assessment roll.
Final publication of the compensation assessment roll.
Manner of payment.
Payment of compensation.
Register of payment.
Ad-interim compensation.
Application for ad-interim compensation.
manner of keeping in deposit disputed ad-interim compensation money.

39
39
40
40
40
40
41
41
2
42
42
42
42
43
43

CHAPTER XIII
Ceiling on Land Holdings.
190. Submission of return.
191. The agency through which information may be collected under section 166.
192. Verification etc.
193. Preparation of list.
193A. Consideration of any land so transferred or portioned.
194. Selection of excess land out of transferred land.
195. Publication of list for objection.
196. Application for restoration.
197. Manner of publication under sub-section 3 of section 170.
198. Calling information for determining compensation.
199. Verification of information furnished.
200. Omitted.
201. Compensation for structure and buildings.
202. Apportionment of compensation between the raiyat and under-raiyat.
203. Recovery of compensation from under-raiyat or mortgagee.
204. Determination of compensation.
205. Payment of compensation.
206. Application of Schedule IV.
207. Register of compensation.
208. Payment of compensation to charge holders.
209. Acquisition of excess land after endorsement of section 164.
210. Demarcation of excess land.
211. Application for exemption.

43
44
44
44
44
44
45
45
45
46
46
46
46
46
47
47
47
47
48
48
48
48
48

<!-- page 7 -->

vii

RULES;
CHAPTER XIV
Prevention of Fragmentation.

212. Declaration under section 182 (2).

49

CHAPTER XV
General and Miscellaneous.

213. Restoration of possession.
214. Court fees.
215. Procedure to be followed by the Collector under section 187.
216. Restoration of transferred land to the member of the Scheduled Tribe.

50
50
50
50

SCHEDULES.

I.
II.
III.
IV.
V.

Forms.
The inspection and grant of certified copies of Revenue Records.
Procedure of Revenue Courts.
Payment of compensation.
Court Fees.

52-112
113-117
118-128
128-130
131-133

<!-- page 8 -->

GOVERNMENT OF TRIPURA
REVENUE DEPARTMENT
LAND REFORMS
NOTIFICATION
No. 74(14)-Rev/60-13th April 1960-In exercise of the powers conferred by sections 98, 132,
161, 184 and 197 of the Tripura Land Revenue and Land Reforms Act, 1960 (Act 43 of
1960) and all other powers in this behalf, the state Government is pleased to make the
following rules, namely:THE TRIPURA LAND REVENUE AND LAN REFORMS RULES, 1961.
CHAPTER 1
PRELIMINARY
Short title
Definitions

Distance of a near by
village for purpose of
personal cultivation

1. these rules may be called the Tripura land Revenue and Land Reforms
Rules, 1961.
2. In these rules, unless there is anything repugnant in the subject or context:
(a) ‘Act’ means the Tripura Land Revenue and Land Reforms Act, 1960.
(aa) 2 ‘Competent authority’ shall have the same meaning assign to it as in the
Act.
(b) ‘From’ means any of the forms given in schedules 1, II and IV or a
translation thereof in the Bengali Language published under the
authority of the 3 [State Government]
(c) ‘Last settlement’ with reference to any local area means the last
general revision of the land revenue demand of that area carried out
in accordance with the provisions of the Act or any other act for the
time being in force:
(d) ‘Schedule’ mans any of the schedules to these rules; and
(e) ‘Section’ means section of the Act.
3. The distance of a nearby village referred to in explanation I to clause (p) of
section 2 shall not exceed 8 kilometres from the village in which the land is
situated, such distance being reckoned by the route normally used for journeys
between the two villages.
1. Substituted by the North-eastern Ares (Reorganisation) (Tripura)
Adaptation of laws order, 1973.
2. Inserted by 5th amendment vide notification No. F. 39(26)-Rev/74 dated
18.11.74.
3. Substituted by The North-Eastern Areas (Reorganisation) (Tripura)
Adaptation of laws order, 1973.

<!-- page 9 -->

CHAPTER II
General Power of Revenue Officers
General powers of the
Collector
General powers of Survey &
Settlement officer

Decision of dispute
referred to in section
11(3)

4. The Collector shall have the power of general superintendence and
control over al other officers subordinate to him and shall also have
power to all cater work among them.
5. The Survey and Settlement Officer shall, subject to the exercise of
powers by the Director of Settlement and Land Records have general
superintendence and control over other officers doing the survey and
settlement work and shall also provided for the distribution of work
among them. He may transfer any case or work from one such officer to
another having competence to dispose of that case or work.
6. Save as otherwise provided by the act, any revenue officer may exercise
any power pr discharge any function which may be exercised or
discharged, as the case may be, by any officer subordinate to him.
CHAPTER III
Land and Land Revenue

Decision of dispute
referred to in section
11(3)

Preservation and
disposal of trees,
jungles etc.

Survey and
demarcation of
pasturage

o

7. Any dispute referred to in sub-section (3) of section 11 shall be decided
after a summary inquiry in the manner laid down in schedule III.
8. Subject to the provisions of section 12,
(i)
all trees, brush wood, or other natural products growing on
the road side shall be preserved or disposed of by the forest
department or the authority having charge of the road as may
be directed by the 1[State Government] and
(ii)
all trees, brush wood, jungles and other natural products,
except in so far as the same may be the property of any
person, shall be preserved or disposed of by the Forest
Department in accordance with the forest rules for the time
being in force.
9.(1) Whenever it appears necessary to the Collector, that any land should
be set apart under section 13 for pasturage for cattle of any village or
villages, he shall cause such land to be demarcated with temporary
boundary marks and, if it has not been already cadastrally surveyed, shall
cause a map of it to be prepared on the scale of sixteen inches to a mile.
(2) The Collector shall then cause a notice in form 1 to be published
declaring his intention to set apart the land and inviting objection, if any,
within thirty days from the date of publication of the notice.
(3) The notice shall be published –
(i)
by beat of drum in the village;
(ii)
by affixing a copy in some conspicuous place in the village;
and
(iii) by affixing a copy on the notice board of the Court House of
the issuing officer.

1. Substituted by the North-Eastern Ares (Reorganisation) (Tripura)
Adaptation of laws order, 1973.

<!-- page 10 -->

Hearing of
objections

Disposal of
objetions

Declaration of
pasturage

Use of pasturage

Cancellation or
modification of
declaration under
rule 12
Setting apart of land
for community
purposes
Setting apart land
for Forest Reserve

Management of
land by Gram
Panchayat

Procedure for
summary eviction

10.The Collector shall receive and enquire into any abjection which may be
presented to him within the period prescribed in rule 9 and on such enquiry
may add any available adjacent land to the proposed pasturage of remove
any land from it or confirm the proceedings.
11. Any objection received under rule 10 shall be heard and disposed of after
a formal inquiry in the manner laid down in Schedule III;
Provided that the Collector may consolidate and hear all the objections
together.
12. As soon as may be after the disposal of the objections under rule 10, or
when no such objection has been received within the prescribed period,
after the expiry of that period, the Collector shall cause to be published
in the manner prescribed in sub-rule (3) of rule 9 a final notice declaring
the land to be set apart for pasturage for the cattle of the village or
villages. He shall also cause the pasturage specified in the notice to be
entered in the register of pasturage and the boundaries to be demarcated
with such boundary marks as he may deem suitable.
13. After the declaration under rule 12 the land may be used as pasturage for
the cattle of the village or villages for which it has been set apart;
provided that the Collector may, with a view to ensuring proper
utilization of the land, prescribe the conditions subject to which the
pasturage may be used.
14. The Collector may at any time modify or cancel the declaration under
rule 12 and the provisions of rules 9 to 12 shall mutates mutandis apply
to such proceedings.
15. The Collector may ordinarily set apart an area not exceeding 5% of the
land constituted within a village for community purposes and the
provisions of rule 9 to 14 shall mutates mutandis apply thereto.
16. The Collector may, in
consultation with the Head of the Forest
Department. Set apart land to be constituted as a Protected Forest or
Reserve Forest in the manner laid down in the Indian Forest Act, 1972
(XVI of 1927).
17. (1) Where the State Government has entrusted the management of any
land belonging to the Government to the Gram Panchayat of a village, an
appeal against the order of allotment of land passed by the gram
Panchayat shall lie to the Sub-divisional Officer in whose jurisdiction the
land is situated.
(2) The Sub-Divisional Officer may either on his 0wn motion or on the
application of any party call for the record of any proceedings of a Gram
Panchayrt for allotment of land for the purpose of satisfying himself as to the
legality or the propriety of any order passed by such Gram Panchayat and
may pass such order in reference thereto as he thinks fit.
18 (1) Before ordering eviction of a person under sub-section (1) of section
15 the competent authority shall issue a notice to him requiring him to
show cause within a period to be specified in the notice why he should not
be evicted from the land.
(2) If the person concerned filed an objection within the period specified in
the notice or such extended period as may be allowed by the competent
authority it shall hold a summary inquiry in the manner laid down in
Schedule III

<!-- page 11 -->

Exemption from land
revenue

Application for
remission of land
revenue
Diversion of land
to agriculture rural
purpose

Diversion of to
other purpose

Calculation of
fraction

Remission of
suspension of
land revenue

(3) If the person concerned files no objection within the time so allowed or
if after inquiry the competent authority finds that the person is a trespasser it
shall order his eviction and shall also require him to remove any building or
other construction erected of any ting deposited on the land within a time
specified in the order.
19. The 1[State Government] may subject to such conditions as he may
specify in the order to ensure for proper utilization of the concession,
exempt any land from the liability to the payment of land revenue in any of
the following cases:(i)
where the person holding land is a public body or an institution
established exclusively for a religious educational or a charitable
purpose, or a person holding under a trust or an endowment or other
legal obligation exclusively for a propose which is charitable,
educational or religious;
(ii)
Where waste or unproductive land is sought to be brought under
cultivation; and
(iii) Where in the opinion of the 2[State Government] exemption from
land revenue will be in public interest.
20. * Deleted.
21. An application for remission of land revenue for the land lost by diluvion
may be made to competent authority in plain paper within one year of
diluvion.
22. * Deleted.
23. (1) When land assessed for use for a purpose other than agriculture is
divert to an agricultural purpose the assessment shall be equal to the
assessment of the land for agricultural purpose, as fixed at the last
settlement.
(2) When there has been no such assessment for agricultural purposes, the
assessment shall be fixed at the rate adopted for similar soil class in the
same village or in a neighboring village at the last settlement.
24. If any land held for one purpose is diverted to any other purpose except
agriculture, the assessment theron shall be revised in accordance with any of
the methods specified below according to the circumstances of the case, viz:(i)
in the area in which the land is situated has an assessment rate for
the land used for that purpose as confirmed by the 1[State
Government] under sub-section (1) of section 34, then in accordance
with such revenue rate;
(ii)
if there be no revenue rate in force as aforesaid then the Collector
may assess the revenue at a rate not exceeding 3% of the value of
such land.
25. In fixing the actual assessment of a plot of land, the area thereof
measuring less than 2[0005 hectares shall be taken to be .0005 hectare.]
1&2 Substituted by the North-Eastern Areas (Reorganisation) (Tripura)
Adaptation of laws Order, 1973
* Deleted by 13th Amendment dated 29th January, 1981.
1. Substituted by the North-Eastern Area (Rorganisation) (Tripura)
Adaptation of laws Order, 1973.
2. Substituted by T.L.R. & L.R. (6th Amendment) Rules, 1961.
26. Remission or suspension of land revenue may be granted—

<!-- page 12 -->

Remission when
to be allowed
Relief in
widespread
calamities

Relief in local
calamities

Relief in case of
orders, by court
etc.

(a) in the event of failure of crops due do—
(b) widespread calamities such s famine, draught, etc.;
(c) local calamities such as hail, floods, locusts and similar visitation;
and
(d) in case in which crops could not be grown in any area in
consequence of an order made under any law by a competent
authority.
27. Ordinarily relief shall take the form of suspension of revenue. Remission may
be granted if later conditions justify such course.
28. (1) In cases of wider spread calamities, the degree of relief shall be the same in
each village or homogeneous tract, and no attempt shall be made to differentiate
between the circumstances of individuals.
(2) Relief shall be calculated according to A Scale or B Scale according to the
previous revenue history of the tract. A Scale shall be used in village whose
revenue history in normal and B Scale in those which have suffered from recent
crop failures.
A Scale
State of Crop
Degree of relief
(1)
(2)
40 percent or above
NIL
Less than 40 percent but
Not less than 25 percent but not
Half
less than 25 percent
Less than 25 per cent
Full
B Scale
50 percent or above Les than 50 percent but
Nil
not less than 40 percent
Less than 40 per cent
Full
In calculation the percentage of out-turn for each village, any shortage in the
cropped area as compared with the estimated normal shall be taken into
consideration.
29. The foregoing rule shall apply in the cases of local calamities subject to the
following modification, namely:(a) relief shall be granted to individuals varying according to the damage done to
the total holding of each; and
(b) relief shall be granted on B Scale, if any general suspension of revenue was
granted in respect of the previous year’s crops in the village, otherwise on A
Scale.
30. (1) Remission of land revenue in any area in which crop could not be grown in
consequence of an order made under any law by a competent authority may be
allowed according to the following scale, namely:-State of area allowed
Degree of
To remain fallow.
(2)
(1)
(i) if mare than half the area allowed to
remain fallow was cultivated during the
previous year.
Full
(ii)If less than half the area allowed to
Half
Remain fallow was cultivated during the Previous year.

<!-- page 13 -->

Announcement of
relief

Stay orders by
Collector

Collection of
suspended land
revenue

Remission of
suspended land
revenue

Form of receipt for
land Revenue

(2) Relief under sub-rule (1) shall be determined for individual holding separately.
31. The 1[State Government] may sanction suspension, remission or resuspension, as the case may be, to such extent as may be considered necessary on
receipt of sanction, the Collector shall cause the nature of relief to be announced
to all concerned before the installment of revenue, to which it related, falls due.
32. If it appears probable that orders of the 2([State Government] cannot be
received in time to allow announcement before due date the Collector may pass
orders staying the realization of the amount of land revenue pending orders of the
3
[State Government]
33. (1) No land revenue which has been suspended shall ordinarily be collected
until the next crop, corresponding to the one which failed, has been harvested in
the effect tract.
(2) As the character of each successive harvest becomes known, the State
Government shall determine the amount of the suspended land revenue to be
collected along with the ordinary demand and shall announce it before the date
fixed for the payment of revenue. The amount of suspended land revenue to be
collected, if any, shall be equal to one forth, one half or the whole of the year’s
demand as the circumstances may justify.
34. Suspended land revenue maybe remitted in whole or in part:-(a) when the revenue which it is sought to remit has been suspended for three
years; and
(b)in cases where it is clear from the conditions of the tract that it would be
inadvisable to collect the suspended or part of it.
1
[34(A)/ In addition to or in liew of the forms of relief here in before mentioned
the Administrator may, if the circumstances justify, direct that the arrears of land
revenue due for any past year or year or years in respect of any area or areas shall
be payable in such installments and as such times as may be specified in the
direction. On the receipt of such direction the Collector shall cause the nature of
relief to be announced to all concerned before the installment of revenue to which
it relates falls due]
35. (1) 2[for every amount of land Revenue Collected by a revenue officer, a
receipt along with a coupon in form 2 duly filled in shall be given to the person
from whom the amount is received.
(2) Carbon copy of every receipt under sub-rule (1) excluding the coupon shall be
maintained by the revenue officer and both the original and the carbon copy
thereof shall be signed by the person making payment and the revenue officer
receiving the amount.]
1. 2&3 Substituted by the North-Eastern Areas (Reorganisation) (Tripura)
Adaptation of laws Order, 1973.
1. Inserted by 3rd amendment vide notification No. 39 (167)-Rev/69 dated
17.9.79.
2. Substituted by 8th amendment vide notification No. F.39 (63)/Rev/75 dated
30.3.76.

<!-- page 14 -->

(3) The inspecting revenue officer whenever visits a village shall collect (at
random coupon attached to the receipt given to land owner under sub-rule (1)
and after verifying the coupons paste these at the blank space of the respective
carbon copies of the receipts.
CHAPTER –IV
Survey and Settlement of Land Revenue
Profits of
agriculture and
value of land

36.1[(1) For the purpose of determining the profits of agriculture and the value
of land used for agricultural and non-agricultural purposes, at such intervals as
the State Government may direct, the Collector or any other revenue officer as
may be authorized by the Government may devide an area in to units in
accordance with the provisions in this regard in section 32 of the Act and rules
made there under.
Provided that the units once formed either for the purpose of determination of
revenue rates or for the purpose of determination of profits of agriculture and
value of land used for agricultural and non-agricultural purposes may be treated
as unit for the purpose.
(2) The profits of agriculture of land in nit shall be the average profits of
agriculture for Nal and Lunga classes of land in nit, determined on the basis of
enquire on plots selected on samples base.

Publication of table
of profits of
agriculture and value
of land

(3) The profits of agriculture shall be computed after detucting the estimated
cost of cultivation from the market value of the products and bye-products, the
market value being calculated on the average of sale prices prevailing in
important markets in the neighborhood during the preceding three years or
during any shorter period for which information is available]
37. 2[(1). Collector or any other revenue officer, as may be authorized by the
Government shall, after determination of the profits of agriculture and value of
land in a unit, prepare a table of profits of agriculture and value of land in frok
4B and publish the same by placing it for public in form 4B and publish the
same by placing it for public inspection free of charge during a period jof thirty
days at such convenient place as he may determine and cause a public notice in
form 4C to be given to that effect in such village compressed in the unit to
which the table relates, stating the place at which the table will be open to such
inspection and inviting objections, if any, to be made within thirty days of the
date of publication of the notice.
(2) Any objection to any entry in the table of profits of Agriculture and value of
land filed within the prescribed period shall be heard in a summary manner after
giving an opportunity to the objector of being heard and decision recorded.
1. Substituted by 11th Amendment vide notification No. F.4(1)RCC.79 dated 28.8.79.
2. Ibid.

<!-- page 15 -->

(3)After disposal of all objection (s) under sub-rule (2) and after the entries of
the table are corrected where necessary in accordance with the orders passed in
the objections, the Collector or any other revenue officer authorized by the
Government shall finally publish the table by placing it for public inspection
free of charge during a period of fifteen days at such convenient place or places
as he may determine and he shall cause a notice in form 4D to be given to that
effect in each village to which the table relates stating the place where and the
period during which it will be open to public inspection.
(4) The Collector or any other revenue officer authorized by the government
shall maintain a register of value of land as well as of profits of agriculture on
the basis of finally published table under sub-rule (3).]
38. 1[Omitted]
Notification and
proclamation of
revenue survey

Revenue survey
and preparation of
record of right

Assessment unit

39. (1) Whenever the 2[State Government] 3[Omitted] decides under section 26
that a revenue survey be made of a local area with a view to settlement of land
revenue and to the preparation of record of rights connected therewith or the
revision of any existing settlement or record of rights, he shall publish in the
Official Gazette a notification in form 3.
(2) Thereafter, but before the survey starts in any village, proclamation in form
4 shall be made in that village and in village contiguous thereto.
40. After the proclamation has been made proceedings for revenue survey and
preparation of record of rights shall be taken in accordance with the provisions
of chapter V with the following modifications, namely:-(i)
Proceedings shall simultaneously be taken for the preparation
and publication of the table of revenue rates;
(ii)
For the purpose of determining the revenue rates, the area shall
be divided into units (hereinafter called assessment units) in
accordance with the provisions of section 32 and these rules;
and
(iii) Before the attestation mentioned at item (vi) of rule 56 starts,
the table of revenue rates shall be finally published and the
assessment of each holding shall be calculated in accordance
with that table and entered in the draft of the record-of-rights.
41. Subject to the provisions of section 32—
(a) the assessment unit shall as for as possible—
(i)
include a compact area;
(ii)
be homogeneous in geographical, agriculture and economic
conditions; and
(iii) be coterminous with a block of physical division; and
1. Omitted by T.L.R.& L.R.(11th Amendment) Rules 1979.
2. Substituted by the North-Eastern Areas (Reorganisation)
(Tripura) Adaptation of laws Order, 1973.
3. Omitted by 13th Amendment dated 29.1.81.

<!-- page 16 -->

Maximum
revenue rate

(b) The assessment nit of land within a municipality or cantonment, area shall
be the area comprised within a municipal ward or the cantonment, area shall
be the area comprised within a municipal ward or the cantonment as the case
may be:
Provided that the survey and Settlement Officer may combine the area under
two or more municipal wards into one assessment unit or sub-divide a
municipal ward or cantonment area into more than one assessment unit.
42. The revenue rate of any class of land shall not exceed—
(i)
(ii)

in case of agricultural land, one-eight value of the yield of the land.
In case of other land 3% of the market value of the land.

Form of table of
revenue rates.

43. The table of revenue rates of land revenue per acre again different classes
of agricultural and non-agriculture land in the unit and shall be in From 5.

Annexure to table of
revenue rates.

44. To the table of revenue rates shall be annexed—
(i)
(ii)

a map of the assessment unit showing the village;
a set of tabular statement, showing the results of crop cutting
experiments, costs of cultivation, present and past classification if any,
corps grown, and the proposed rates.

Publication table of
revenue rates

45. The Survey and settlement Officer or the assistant survey and Settlement
Officer shall publish the table of revenue fates under sub-section (1) of
section 33 by placing it for public inspection free of charge during a period of
thirty days at such convenient place as he may determine and cause at public
notice in Form 6 to be given to that effect in each village comprised in the
assessment unit to which the table relates, stating the place at which the table
will be open to such inspection and inviting objection, if any to be made
within thirty days of the days of publication of the notice.

Disposal of objection

46. Any objection to any entry in the table of revenue rates filed within the
prescribed period shall be hard in a summary manner and decision recorded.

Alteration or revisions of
revenue rates

Ratio between old and
new revenue rates

47. The 1[State Government] may by an order direct alteration of revision of
revenue rates under clause (a) of sub-section (2) of section 37 when in its
opinion the circumstances have so Changed as to cause substantial increase or
decrease in the yield or prices of crops generally or in a particular area.
48. The revised revenue rates of different classes of land shall bear the same
ratio to the old revenue rates of that corresponding class of land as—
(i) in case of agricultural land the average profits of agriculture of that
class of land during the preceding three years bear to the average
profits of agriculture of that or corresponding class of land at the time
of the last determination of revenue rates;
1. Substituted by the North-Eastern Areas (Reorganisation) (Tripura)
Adaptation of laws Order, 1973.

<!-- page 17 -->

(ii) in case of non-agricultural land the average market value of that class of
land obtaining during the preceding three years bears to the average
market value of that or corresponding class of land obtaining at the time
of the last determination of revenue rates;
Provided that the revenue payable in respect of any land shall not be
increased or enhanced under these rules so as to exceed by more than
twelve and a half per cent of the revenue previously payable in respect of
that land.
49. (1) As soon as the work of survey and settlement of land revenue has sufficiently
advanced to enable the survey and Settlement Officer to state approximately what will
be the total cost incurred and the cost leviable from persons holding land or having
interest therein and how in his opinion the share to be paid by persons holding land or
having intrest therein should be borne, he shall submit for orders of the 1[State
Government] the principles on which he proposes to make apportionment. The
proposals shall be submitted in good time before final publication of records of rights.
Liability on
individual for
costs

50. (1) Liability of individuals for costs shall be fixed on the basis of the
area of land held by them or in which they have interest and for this purpose
the fraction of an acre shall be deemed to be an acre.
(2) When the area of waste land or unoccupied land is extensive separate
rates per acre may be fixed for the land and the other land.

Apportionment of liability
of costs and notice
thereof

51. When the 1[State Government] has approved the principals of
apportionment of the cost, the survey and Settlement Officer shall cause
each person to be served with a notice in such manner s the 1[State
Government] may from time direct of the amount payable by him and the
period within which it should be deposited.
52.(1) A separate settlement register shall be prepared for village.
(2) It shall contain the following particulars:-(i)
Mark list (list of trijunction and boundary and survey marks);
(ii)
Index of plot numbers and khasra;
(iii) Assessment of each holding;
(iv) Rent Roll (List of revenue rates for different soil classes in the
village);
(v)
Classified statement of raiyats and their nder raiyats;
3
(vi) [Crop inspection Register in such Form as the State Government
may direct];
(vii) Register of lands held by Government and other local bodies;
(viii) Statement showing the classifications of cultivated lands and
culturable waste;

1. Substituted by the North-Eastern Areas (Reorganisation) (Tripura) Adaptation
of laws Order, 1973.
1. Substituted by the North-Eastern Areas (Reorganisation) (Tripura) Adaptation
of laws Order, 1973.
2. Substituted by 13th Amendment dated 29.1.81.

<!-- page 18 -->

(ix) Revenue free lands;
(x)
List of lands in which public hare common fight of easement;
(xi) Agricultural stock statement;
(xii) 1[Omitted]
(xiii) Cadastral village map;
(xiv) A village note containing the following:-(a) Situation and physical features;
(b) Soil classes;
(c) Tehsil, Circle Officer’s, Circle, Sub-division, District, Station, Post &
Telegraph Office to which attached);
(d) Human and cattle population;
(e) Customary rights of the villagers;
(f)
Main crops;
(g) Method of cultivation;
(h) Drinking water tanks wells and other sources of drinking water;
(i)
Schools and college;
(j)
Community festivals and religion;
(k) Hospitals and dispensaries;
(l)
Pasture land;
(m) Burial and cremation ground;
(n) Natural products and mines, if any,;
(o) Village officer;
(p) Trade, communication and marking facilities;
(q) Crafts and industries;
(r)
Temples, mosques and other notable objects;
(s)
Rural indebtedness, economic conditions, use of excisable goods;
(t)
Rain-fall;
(u) Such other information as may be considered necessary and usefull.

1. Omitted by 13th Amendment dated 29.1.81

<!-- page 19 -->

CHAPTER V
LAND REDORDS
Records of rights

53. (1) The record of right shall consist of a statement of rights in from 7,
hereinafter referred to as the ‘Khatian’
(2) There shall ordinarily be a separate Khatian for each person interested or
group of persons jointly interested in the land an the Khatian shall show the rights
and liabilities of each such person.

Khasra

Notification and
proclamation

Stages of revenue
survey and
preparation of
records of rights

54. There shall be prepared in Form 8 a Field Index or Khasra’ arranged
according to the serial numbers of the plots in the village.
55. Before the preparation of revision of record-of-rights is taken up there shall be
the notification and the proclamation as stated in rule 39.
56. (1) When a notification has been so published and the proclamation made, the
revenue survey shall be conducted and the record of rights shall be prepared
or revised by the following stages, namely:(i)
demarcation of village boundaries;
(ii)
traverse survey;
(iii) cadastral survey (or Kistwar);
(iv)
preliminary record writing (Khanapuri);
(v)
local explanation (or Bujharat);
(vi)
attestation including determination of rent or revenue of tenancies
and holding (or jamabandi);
(vii) publication of the draft record of rights;
(viii) disposal of objections under sub-section (1) OF section 43 and
(ix)
preparation and publication of the final record of rights under subsection (2) of section 43;
Provided that any of the stages referred to in items (i) to (v) may be
omitted or amalgamat with another by an order of the 1[State
Government]:
Provided further that if the Survey and Settlement Officer is of the
opinion that there has been a material irregularity of the draft of the
record of rights direct that the proceeding shall be taken denovo from such
stage as he may direct, but not so as to set aside any proceeding relating
to determination of revenue rates after the publication of the table under
sub-section (1) of section 33.

1. Substituted by the North-Eastern Areas (Reorganisation) (Tripura)
Adaptation of laws Order, 1973.
2. From No.7(khatian) is substituted by fifteenth amendment of rules,
1993 vide Notification No. F.4(37)-RCC/93 Dated Agartala, the 22nd
November, 1993.

<!-- page 20 -->

Notification for
assistance

57. Before each of the first four stages, namely, demarcation of village binderies,
traverse survey, kistwar and Khanapuri, a general notice shall be served in the
village in Form 9 informing the holders of land of the probable dates of
commencement of each of the stages and requiring their attendance to assist
the revenue officer employed on work in any matter incidental to any of the
above stages.

Village
boundary
demarcation

58. The revenue survey of an area notified under section 26 shall be based on
village boundary demarcation. Existing boundary of any village may also be
recognized with or without modification.

Traverse survey

59. The traverse survey of an area referred to in rule 58 shall ordinarily be carried
out by theodolite observations.

Cadastral
Survey

60. (1) The cadastral survey of the area shall be based on traverse survey.
(2) A detailed map of all the fields in a village shall be prepared on a scale map is
already in existence, it will not be necessary, unless the survey and Settlement
Officer so directs, of prepare a fresh map and the existing map may be brought
upto date.

Survey
Number

61. A separate number (hereinafter called the plot number) shall be allotted to
every plot i.e. a piece of land within one periphery which is possessed by one
person or a set of persons jointly, which is held under one title and which
consists of one class of land.

Preparation of
preliminary
records of rights

62. For the purpose of preparation 1[or revision] of a record of rights the survey
and settlement Officer shall cause to be prepared a preliminary record of
rights.

Bujarat

63. (1) When the preliminary record-of-rights, has been prepared, a general notice
in Form 10 shall be published in the village in forming the holders of lands of
the date of commencement of Bujharat and calling for their attendance with
relevant documents appertaining to their lands in the village.
(2) When the areas of the plots have been extracted and entered in the preliminary record,
a copy of each ‘Khatian’ shall be made over by the revenue officer to the person or
persons in whose name or names the ‘Khatian’ has been opened or to their
representatives. The cost of each copy of the ‘Khatian’ styled as ‘Parcha’ shall be twenty
five naya paisa. For every realization on account of the costs of parcha a receipt in form
11 shall be prepared, along with a carbon copy thereof, under the signature of the
Revenue officer receiving the amount and the signature of the person making the
payment shall also be obtained thereon. The original shall be given to the person making
the payment and the carbon copy shall be retained for record:-2
[Provided that in case of revision of records such of Khatian styled as parcha may be
made over after the completion of the Bujharat of a village instead of making over before
Bujharat].
1. Inserted by 10th amendment by notification No. F.4(52)-RCC/78 Date 5.12.78.
2. Inserted by 10th amendment by notification No. F.4(52)-RCC/78 Date 5.12.78.

<!-- page 21 -->

(3) Each Khatian shall then be examined of the field with reference to the
village map by a revenue officer and explained to the person or persons
concerned or their representative, if present.
In this process, the revenue officer shall make such corrections as may
be necessary in the map, in the preliminary records and in the copies of the
khatians where such copies have been distributed and produced for this
purpose.
(4) At this stage, preliminary entries of rent of revenue which is
payable according to the statement of the land holder and according to the
statement of the tenant, raiyat, under raiyat or occupant shall be made in the
preliminary Khatians and in the copies thereof, if produced. The revenue
officer shall dispose of all disputes arising at this stage as well as disputes left
undisposed of, if any, during preliminary record writing excepting those
relating to rent, revenue of status. Notice for hearing of disputes shall be
served on both parties in Form 12 at least three days before the date of
hearing.
(5) On completion of the bujharat of a village, the revenue officer shall
furnish a certificate in Form 13.
Attestation
including
ascertainment of
rent and revenue

64. (1) The attestation in the village shall be taken up at a convenient
place in or near the village as for as possible. A proclamation in Form 14 shall
be published at least thirty days before attestation begins in the village, giving
due notice to the raiyats, under raiyats, occupants and other land holders
calling upon them to appear before the revenue officer, on the date fixed with
relevant documents in support of their right, title and possession.
(2) When about a week is left before attestation, a reminder notice in form 15
shall be published in the village. Special notice may be served on the
Collector or other public bodies and summons may be served on land holders
and other persons, if the attendance of such persons may or their authorized
representatives is deemed necessary.
(3) The revenue officer shall take up the preliminary record of fights Khatian
by Khatian. As each person appears before him, the revenue officer shall
examine his Khatian, read out all the entries, make corrections where
required, and se that the Khatian is complete in all particulars. Disputes
regarding ownership of land or ownership of any interest in land shall be
decided by the revenue officer in a summary manner and on the basis of
present possession or possession during the year proceeding the year in which
attestation is done. In the khatian of each 1[holder or group holders of land] he
shall enter with his own hand the class to which each person or group of
persons belonging, the special conditions or incidents (if any) o the holding
or tenancy and the revenue or rent lawfully payable or deliverable to
Government or each land holder or group of land holder. In each of the
khatians attested the cesses lawfully payable shall also be recorded.
(4) The revenue officer shall then sign and date the Khatian and when he has
completed the attestation of all the Khatians of a village, he shall draw up a
formal proceeding to that effect.

<!-- page 22 -->

(5) The revenue officer doing attestation shall have a distinctive seal bearing
the ‘Attested’. As son as the attestation of each khatian has been completed,
the revenue officer shall affix to the attested Khatian this seal with his
signature and date.
Publication of the
draft record of
rights.

65. (1) After the completion of attestation is a village as foresaid, the revenue
officer shall publish the draft of the record of rights under sub-section (1) of
section 43 by placing it for public inspection free of charge during a period of
thirty days at such convenient place of places as he may determine and cause
a public notice in form 16 to be given to that effect in the village to which the
draft record of rights relates, stating the place at which the draft records will
be open to public inspection, the period for which they will be open to such
inspection and objection, if any to be made in Form 17 within thirty days of
the date of the publication of the notice.
(2) Notwithstanding anything contained in the notice, the survey and
settlement Officer may extend the period during which the draft record of
rights will be open to inspection and during which objections may be filed.

Disposal of
objections

66. (1) From 17 shall be made available by the revenue officer on payment of
a price of ten naye paise per form and objection shall, as for as practicable, be
made in such form. Along with the original objections, the objector shall file
copies of the same with copies of notices in Form 18 for service on persons
who are materially interested in the case and the revenue officer shall issue
notice informing the objector and all such persons to interested of the date,
time and place fixed for hearing of the objections. No objections shall be
disposed of without affording the parties materially interested of their
representative an opportunity of being heard.
(2) Objections shall be disposed of in a summary manner. The names of
witnesses examined and obstract of the reasons for decision shall always be
recorded in addition to the decision itself. The revenue officer disposing of
the objection shall record the final decision in the Bengali language,
specifying the changes, if any, which are required to be made in the Khatian
concerned. Necessary corrections in Khatians under objection shall be made
by the revenue officer himself.

Framing of final
record

Final Publication
of the records of
rights

67. When all objection under rule 66 have been finally disposed of and the
draft of the record corrected, wherever necessary, the Survey and Settlement
Officer shall frame the final record inconformity with the draft record thus
corrected.
68. The record of rights shall be finally published under sub-section (2) of
section 43 by the Survey and Settlement Officer by placing it for public
inspection free of charge during a period of thirty days at such convenience
place or places as he may determine, and he shall cause a notice in Form 19 to
be given to that effect in each village to which the record relates stating the
place where it will be open to public inspection and the period during which
it will be open to such inspection.
(2) When a record of rights is placed for final publication under sub-section
(2) of section 43, a certificate in the following form shall be attached to the
first volume of the record of rights of each village:--

<!-- page 23 -->

CERTIFICATE OF FINAL PUBLICATION
Village …….. ………. …….. …… ….. ………… …… ……… ………
Thana…… …… ……. …….. …….. ……… ……… ……… ……… …
District…….. ……….. ………. ………… …………. ……….. ………..
Volume……….. ……… ……….. ………… ……. ……….. ………… ..
Pages…….. ………… …….. …………. …………. ………… ……….. .
Certified that the record of rights of the interests as contained in the pages
noted above has been finally framed and published under sub-section (2) of
section 43 of the Tripura land Revenue and Land Reforms Act, 1960, on
this……………….day of…………….19
Survey and Settlement Officer
Or
Assistant survey and Settlement Officer.
The certificate shall be sealed with seal of the survey and Settlement Officer.
(3) Each page of the final record shall be stamped with a seal in the following
form:
“Record of rights finally framed and finally published under sub-section (2) of
section 43 of the Tripura Land Revenue and Land Reforms Act, 1960.”
Survey and Settlement Officer
[Government of Tripura]
Availability of
copies of records
and recovery of
cost

69. Copies of maps prepared under authority of the 2[State Government] and
copies of final record of rights after certification as aforesaid may be
made available to public officers, to land owners and tenants and to others
in such manner as the 3[State Government] from time to time, may by
general or special order, direct. The copies of maps and records which will
be made available on payment of such cost as the 4[State Government]
may direct.

Revision or
correction of
records

70. The record of rights and such other records as the 5[State Government]
may order shall be revised and corrected every year.

Intimation of
correction

71. Any officer correcting any entry in the record of rights under section 45
shall, as soon as may be, after the correction give intimation thereof to
the person or persons interested in the land to which the particular entry
relates.

71. (A) 1[The draft field index (Khasra) to be prepared under section 45A
shall be in form 8A
(2) Before taking up the preparation of the draft field index (Khasra) in
a village, a proclamation shall be issued in form 4A by the sub-Divisional
Officer.
----------------------------------------------------------------------------------------------------------------

Preparation of field
index (Khasra)

*1. Amendment by13th amendment vide notification No. F.4(47)/RCC/79 Dated 29.1.81. 2,3,4&5,
Substituted by the North Eastern Area (Reorganisation) adaptation of laws order 1973
1. Inserted by 6th amendment by Notification No. F.39 (26)-REV/74 Dated 18.11.74.

<!-- page 24 -->

(3) After the proclamation has been so made, a general notice shall be
served in the village and in the Tehsil Khachari in Form 9 informing the
holders of land of the probable dates of commencement of the work of the
preparation to assist the revenue officer employed on the said work.
(4) (a) After preparation of the draft field index (Khasra) in the village
aforesaid, the revenue officer shall publish the same ;under sub-section
(1) of section 45 (A) by placing it to public inspection for a period of
thirty days at such convenient place or places as he may determine and
cause a public notice on form 16 to be given to that effect in the village
to which the draft field index (Khasra) relates, station the place at which
the draft field index (Khasra) will be kept open to such inspection and
objection if any, to be made in Form 17 within thirty days of the date of
the publication of the notice.
(b) Notwithstanding anything contained in the notice, the revenue officer
may extend the period during which the draft field index (Khasra) will be
open to inspection and during which objections may be field.
(5) The revenue officer shall receive all objections field within the period
specified in the notice or within such extended period as the case may
be, under clauses (a) and (b) of sub rule (4) and dispose of them in a
summary manner.
(6) When all objections have been disposed of under sub rule (5) and draft
field index (Khasra) corrected, wherever necessary the Revenue officer
shall prepare the field index (Khasra) and publish the same under subsection (2) of section 15 A by placing it for public inspection free of
charge during a period of thirty days at such convenient place or places as
he may determine, and he shall cause a notice in Form 19 to be given to
that effect in each village to which the field index (Khasra) relates stating
he place where it will which it will be open to public inspection and the
period during which be open to such inspection.

Register of mutations

Rewriting of record of
right

Reports for mutation

(7) If there is a conflict in any entry in finally published field index
(Khasra) and in the record of rights, then the circle officer shall give a
certificate to that effect and thereupon the entries in the record of rights
shall be corrected.]
72. The register of mutations shall be in Form 20, there being a separate
register for each village.
73. The record of rights may by written after every five years or such longer
period as the Collector may decide after scrutiny of the record.
74. (1) All reports for mutation under section 46 shall be in Form 21. The
applicant, i.e. the person reporting shall fill up columns 1 to 8 and other
columns shall be filled in due course by the officer concerned.

<!-- page 25 -->

The applicant shall also submit sufficient number of spare copies of the report
for intimation to the persons interested.
(2) Any person who prays for mutation of name in record of rights shall also
state in his report the lands already held by him or any numbers of his family
as raiyat or mortagage with possession of otherwise.
(3) Village accountant shall acknowledge receipt of the report by making over
the counter-foil duly filed in, signed and dated.
Mutation not to be in
contravention of the
Act

75. Before sanctioning the mutation, the authority concerned shall satisfy
itself that the acquisition in pursuance of which mutation is sought is not
in contravention of any of the provisions of this Act.

Intimation about
mutation

76. The intimation under sub section (3) of section 46 shall be given by
sending a copy of the report along with a copy of the entry made under
the said sub-section.

Register of
disputed cases

77. The register of disputed cases of mutation shall be in Form 22.

Acknowledgement
of objection

78. The acknowledgement to be given of the objection made under subsection (4) of section 46 shall be given in From 23.

Testing of entries

79. (!) Entries in the register of mutations shall be tested by the circle officer.
(i)
in the case of entries in respect of which objections have
been decided under sub-section (5) of section 46, with
reference to the relevant record; and
(ii)
in other cases by making such local inquiry as the circle
officer may deem necessary.
(2) An entry when so tested shall be transferred to the record of
rights and shall be certified by the circle officer.
1

[79. A (1) The register of Bargadar shall be in form 20 A

(2) A report under sub-section (3) of section 46A of the Act and the
acknowledgement thereof shall be inform 21A. The person making a
report shall supply sufficient number of copies of the report for
service on the interested persons.
79B. (1) On receipt of reference from any civil or criminal court
under sub-section (2) of section 46B, the competent authority shall
cause to make necessary entries in the register of bargadars and
decide the case considering it as an objection under Sub-section (6)
of section 46A made against the entries I the register of bargadars.
(2) After disposal of the case under rule (1), the competent authority
shall forward a copy of his order to the court from which the
reference was made.]
1. Inserted by 12th Amendment vide notification No. F. 4(34)-EC/79,
Dated 17.1.80.

<!-- page 26 -->

Information to
be supplied to
collector on
requisition

80. Every land-holder and any person holding any interest in land, or
employed in the management of land, shall be bound on the requisition of
the revenue officer to furnish any I formation required by such officer for
the purpose of preparing, making or correcting any entry in the record of
rights or the register of mutations or to show to the satisfaction of such
officer that it is not in his power to furnish the required information.

Alteration of
registers o decree
of court

81. Whenever any court of competent jurisdiction makes a decree confirming
any transfer of possession of a transferable estate or holding or gives
effect to ant decree transferring any such possession, such court may
order the transfer to be registered in the mutation register and the
Collector shall cause necessary entries to be made in the mutation register.

Inspection and
grant of copies

82. The inspection and grant of certified copies of revenue records shall be
governed by the provisions of Schedule II.
CHAPTER VI
Boundaries and Boundary Marks

Determination
boundary disputes

Description of
boundary marks

83. (1) Whenever in the course of revenue survey or otherwise it comes to the
knowledge of a survey officer that any boundary dispute exists, he shall
decide it after enquiry at the spot.
(2) When a village has been cadastrally surveyed the boundaries shown in the
cadastral map shall be presumed to be correct unless contrary is proved.
84. (1) Boundary marks to be contracted and land out under the provisions of
the Act shall be of the following description namely:(i)
Marks erected to show the trijunction points of village (to be called
“trijunction marks”) shall be of re-inforced cement concrete, 76.20
cm in height, made in to a prism of triangular cross section, each side
of the being 15.24 cm in length;
(ii)
Marks erected to show demarcation of other village bondaries or for
other special purposes, viz. demarcation of disputed boundary,
Government land etc. shall also be of reinforced cement concrete,
60.96 cm I height made in to a prism of square cross section each side
of the square being 10.16 cm in length.
(iii)
Marks erected to show the demarcation of plot boundaries, shall if so
requested, be of reinforced cement concrete, 45.72 cm in height made
into a prism of square cross section each side of the square being 7.62
cm in length.
(2) Other boundary marks shall be of such description and of such dimension
and material as may be determinated by the Collector or other competent
authority.

<!-- page 27 -->

Erection of
boundary
marks on
requisition

85. (1) Every holder of land on the written requisition of a survey officer
empower under section 54 shall erect and repair such boundary marks on the
land as that officer directs.
(2) It shall fall due in two equal installments, one on the 15th rule (1) fails to
comply with it, the survey officer may cause to be repaired and realize the
cost so incurred from persons having interest in the land.

Maintenance
of boundary
marks

Register of
boundary
marks

86. The maintenance of boundary marks in all village shall be regulated as
follows:(i)
boundary marks of Government land shall be maintained by the
Government Department concerned;
(ii)
village boundary marks shall be maintained by the Collector; and
(iii) any other boundary marks erected in accordance with the directions of
the Collector or other competent authority shall be maintained in
accordance with such specifications and instructions as may be issued
by him, from time to time.
87. The revenue officer in charge of village boundary demarcation shall
maintain a register of all boundary marks so as to ensure that they are
properly maintained and kept in good condition.
CHAPTER VII
REALISATION OF LAND REVENUE AND OTHER PUBLIC DEMANDS

Land revenue when
and how payable

88. (1) Every sum on account of the land revenue shall be payable to the
tehsildar in his office.
(2) It shall fall due in two equal instilments, one on the 15th November, and
the other on the 15th of March every year though payment may be made at any
time before these dates.

Notice of demand

89. (1) A notice of demand under section 62 shall be issued in Form 24 by
and under the signature and seal of the circle officer of the circle in which the
holding to which the land revenue relates is situated. If such notices are
required to be issued against a defaulter residing in another circle the circle
officer may do so either direct or through the circle officer of such other
circle.
(2) A sub-Divisional officer or Collector any issue a notice of demand in
respect of the land revenue payable on account of any holding which is
situated within his jurisdiction.
(3) It shall be issued in duplicate and shall be served in the manner of a notice
as prescribed in Schedule III.
(4) The fee for the notice of demand shall be added to the arrears for which
the notice is issued and shall be included in the amount specified therein.

<!-- page 28 -->

Distraint and sale
of movable
property

90. (1) Any Collector, sub-divisional officer or circle officer may issue a
warrant of distraint of movable property including the produce of the land of
any defaulter in form 25 and sell the same thereafter by public auction.
(2) Such auction shall be held at the spot unless the officer ordering the
auction is of the opinion that the auction if held in any other place would
bring a higher price in which case auction may be held at such other place.
(3) If the auction is not held at the spot due publicity thereof shall be given by
issuing a proclamation in Form 26 which may also be proclaimed by beat of
drum, if the officer ordering the sale deems it necessary.

Distraint of movable
property other than
the produce of the
land

91. (1) When the property to be distrained is movable property (other than
the produce of the land) in the possession of the defaulter the distraint shall be
effected by actual seizure and the distrainig officer shall keep the property in
his own custody, of in the custody of any one of his subordinates who shall be
responsible for the due custody thereof.
Provided that when the property so distrained be subject to speedy or natural
decay, or if the expenses of keeping it in custody are likely to exceed its
value, the distraining officer may if so authorized by the officer issuing the
warrant of distraint sell it at once;
Provided further that if the property distrained consists of live stock,
agricultural implements or articles, which cannot be conveniently removed,
and the distraining officer does not act under the first proviso he may—
(i)

Leave it in the charge of any person claiming to be interested in such
property or of any other person, who is willing to under take to keep
and be responsible for the custody of such property on his entering
into a bond with one more sureties for an amount not less than the
value of the property that he will take proper care of the property and
produce it when called for or
(ii)
In the case of live-stock leave it in the charge of the pound keeper, if
any.
(2) The distraining officer shall make a list of the property distrined and
obtain thereon an acknowledgement from the person in whose custody the
property is left, and if possible, also of the defaulter and at last two other
persons in attestation of the correctness of the list.. If the property distrained
includes both live stock and other articles separate lists thereof shall be
prepared and got attested.
Distraint of
produce of land

92. (1) Where the property to be distrained is the produce of the land, the
distraint shall be made by affixing a copy of the distraint warrant—
(i)

Where such produce is growing, on the land on which the produce is
growing, or

(ii)

Where such produce has been cut or gathered o the threshing floor or
the place for treading out grins or the like in which it is deposited.
This service will be in addition to normal process of service provided
in the para 33 of schedule III

<!-- page 29 -->

(2) The distraining officer shall make such arrangements for the custody of
produce of the land as he may consider sufficient and also to tend, cut, gather,
and store the produce and do any other act necessary for maturing or
preserving it.
(3) The cost incurred under sub-rule (2) shall be payable by the defaulter.
Custody of
distrained
property

93. (1) Where the distrained live-stock is not left in the charge of the
defaulter the expenses of feeding it shall be charged at such reasonable rate as
the Collector may, by general or special order, fix.
(2) Where the property distrained is movable property, other than
produce of the land or live-stock, and has not been left in the charge of the
defaulter, the expenses for its safe custody shall be charged at such
reasonable rate as the Collector may, by general or special order, fix.
(3) The cost incurred under sub-rules (1) and (2) shall be a charge on
the sale price of the property.

Leaving livestock in the
charge of pound keeper

94. Where the disrtained live stock is left in the charge of the pound keeper,
the produce provided in paras 38 to 41 in Schedule III regarding live stock
attached in execution of decrees of attachment will be applicable.

Attachment of
immovable
t

95. (1) Where the property is immovable property, the attachment shall be
made by an order in Form 27 issued by the Collector prohibiting the defaulter
from transferring or charging the property in any manner and al persons from
having any transfer or charge from him.
(2) In addition to service provided for the service of a notice in
Schedule III, a copy of the prohibitory order shall be affixed at a conspicuous
part of the property and shall be proclaimed in the locality by beat of drum.
(3) The order shall take effect as against transferees for value in good
faith from the date when a copy of the order is affixed on the property and
against all other transferees from the date on which such order is made.
(4) No payment made after the making of the proclamation on account
of rent or any other asset of the estate or holding to any person other than the
Collector or his agent shall be credited to the person making the payment or
relieve him from liability to make the payment to the Collector or his agent.

Management of
attached property

Claim of third
persons

96. When the property attached consists of immovable property, the
attaching authority shall be entitled to manage the property so attached or
entrust its management to such person or authority on such conditions as it
deems fit and to receive all rents and profits accruing there from, to the
exclusion of the defaulter. The collection charges in respect of the property
so attached and managed shall after the costs of attachment and management
have been deducted there from be applied to the payment of arrears for which
the property was attached.
97. If any claim is set up a third person to the property attached or proceeded
against, the officer ordering the attachment or proceedings, shall enquire in to
the claim and may admit or reject it.

<!-- page 30 -->

Objection by
defaulter

Proclamation
for sale

98. If the defaulter files any objection against the attachment or proceeding
against the property it shall be disposed of by the officer ordering the
attachment or proceedings.
99. (1) When the sale of any immovable property is to be held, the
proclamation for sale shall be issued in From 28 it the property to be
auctioned is the holding on account of which the arrears are due and in Form
29 if it is some other property belonging to the defaulter.
(2) The officer conducting the sale shall cause wide publicity of the
proclamation of sale to be made and may, in addition to other processes
provided for such publicity in para 33 of schedule III, get it published in any
newspaper having circulation in the area.
(3) The proclamation of the intended sale shall state the date, time
and place of the sale and specify the following as clearly and accurately as
possible—
(i)
the property to be sold:
(ii)
estimated value of the property;
(iii) the amount for the recovery of which the sale ordered; and
(iv)
such facts which the authority considers material to note in the
proceeding in order to charge full and fair value of the property
including such other circumstances as a purchaser ought to know.
(4) The proclamation mentioned in sub-rule (3) shall be served under
sub-section (2) of section 66 on the defaulter as provided in paras 2 to 31 of
schedule III
(5) The authority issuing the proclamation may summon the defaulter
and examine him with respect to any matter, which is to be included in the
said proclamation.
(6) The place of sale to be specified under sub-rule (3) shall be either
the office of the circle or any place near the property to be sold.

Inspection and copy of
sale proclamation

Date of sale

Absence or
insufficiency of bid

100. The originals or copies of sale proclamations shall be open to
inspection to public on all working days free of charge at the office of the
officer issuing the proclamation within such office hours as the Collector
may, from time to time, fix.
101. No sale shall, without the consent in writing of the default take
place—
(i)
on Sunday or any gazetted holiday; and
(ii)
until after the expiry of at least 30 days from the date on which
proclamation thereof was made.
102. When property is being put to auction for arrears of land revenue
and there be no bid, the revenue officer conduction the sale may purchase the
same in the name of the administrator for one rupee or if the highest bid be
insufficient to cover the arrears due may purchase the property o behalf or the
State Government at the highest bid.

1. Substituted by the North-Eastern Area (Reorganisation) (Tripura)
Adaptation of laws order 1973.

<!-- page 31 -->

Sale Officer

Auction sale when
to stop

Objection by
purchaser

Application for
setting aside
the sale

Certificate of
purchase

Delivery of
possession

Intimation to the
commanding
officer of
cantonment

103. (1) If the officer ordering or conducting the sale is of the opinion
that there are sufficient grounds for such action he may adjourn the sale after
recording reasons therefore.
(2) Where the sale is postponed or adjourned under sub-rule (1) a fresh
proclamation shall be made unless the defaulter consents in writing to waive
it.
104. Auction sale shall be stopped if before the hammer is struck the
amount due including process fees and cost of attachment and sale are
tendered to the officer conduction the sale or proof is given to his satisfaction
that the amount with required costs has been paid to the officer, who ordered
the sale.
105. The purchaser may at any time within thirty days from the date
of the sale of the immovable property, apply to the collector to set aside the
sale on the ground that the defaulter had no interest in the property sold and
he shall after summary enquiry I the manner prescribed in Schedule III pass
such order on such application as he deems fit.
106. (1) An application for setting aside a sale under section 73 shall
be made to the Collector giving therein the grounds on which such sale is
sought to be set aside and documentary evidence, if any, in support thereof.
(2) Such an application shall be disposed of by the Collector after
giving notice to the parties interested in the sale and after affording such
parties an opportunity of being heard and producing evidence.
107. (1) When a sale has been confirmed, a certificate shall be given
to the purchaser in Form 30.
(2) The officer ordering the sale then depute an official to deliver
possession of the property for which sale certificate has been issued to the
purchaser.
(3) The title to the property shall vest in the purchaser from the date of
the certificate.
(4) A certificate granted to a purchaser under section 76 shall be
conclusive evidence I his favour and in favour of any person claiming under
him, that every publication, posting or any dispatch, notice or letter required
by the Act or these rules to be published, served, posted or dispatched has
been duly effected.
108. (1) Where the purchaser is resisted or obstructed by any person in
obtaining possession of the property, he may make an application to the
Collector complaining of such resistance or obstruction.
(2) Thereafter the matter will be proceeded with in accordance with
rules 116 to 123.
109. Whenever any house or other building situated within the limits
of a cantonment is sold the Collector shall, as soon as the sale is confirmed,
forward to the commanding Officer of such cantonment for his information
or for record in the brigade or other proper office, written notice that such
sale has taken place and such notice shall contain full part full particulars of
the property sold and of the name and address of the purchaser.

<!-- page 32 -->

Cost of proclamation
and other costs

110 (1) In calculating the cost of sale, the revenue office shall take in
to account the cost of notice of demand, attachment, and publication of the
sale and any other costs incurred in conducting the sale.
(2) If the proceeds of the sale fall short of such arrears for which it was
held, the balance remaining due from the defaulter may be recovered from
him by further proceeding under Chapter VII of the Act, or any other means
authorized by law.

Recovery of other
amounts recoverable of
land revenue

111 (1) Where any amounts are to be recovered as an arrear of land
revenue, the authority having jurisdiction to recover the amount shall send a
request to the collector with the following particulars:-(a) the authority t whom and the account on which the sum is due;
(b) the person from whom the sum is due;
(c) the sum due;
(d) the provision of law under which the sum is recoverable as an arrear of
land revenue;
(e) the process by which such sum may be recovered; and
(f) the property against which the process may be executed.

Fees to be charged
for execution of
processes

(2) On receipt of the application, the Collector shall proceed to recover
the amount like arrear of land revenue due from person mentioned in the
request.
112. The fees at the following rates shall be charged for serving and
executing processes issued under the Act or these rules.
(1) For every notice if sent
(a) by registered post…………Rupees two.
(b) By post……………..seventy five paise.
(c) Other wise…………… Rupee one.
(2) for a summons for appearance in respect of each person
Rupee one.
(3) for available warrant of arrest in respect of each person
Rupee one.
(4) for warrant of distraint of movable property
(a) for arrears upto Rs. 200
Rupees one and fifty naya paise.
(b) for arrears above Rs. 500 and upto Rs. 500
Rupee two.
(c) for arrears above Rs.500 and upto Rs. 1,000 Rupees two and fifty naya
paise.
(d) for arrears above Rs. 1,000
Rupees three.
(5) for a prohibitory order in cases of attachment
of immovable property
Rupee three.
(6) for proclamation of sale of movable or immovable property Rupee two.
(7) for a warrant for the delivery of immovable property
Rupee three.
(8) for any process not specified above

<!-- page 33 -->

Application of the
code of civil
procedure

113. Subject to the provisions of the Act and these rules, the
provisions of the Code of Civil procedure 1908 relating to the attachment of
sale of property shall as far as may be, apply to the proceedings under this
Chapter.
CHAPTER VIII
Procedure of Revenue Officer

Form and service of
summons

Bail able warrant of
arrest
Delivery of
possession

Obstruction of
delivery of
possession

114. Every summons to be issued by a revenue officer shall
(i)
in the case of a party, be in Form 31 or 32, as the case may be; and
(ii)
in the case of a witness, be in From 33, and shall be served in the
manner prescribed in Schedule III.
115. The warrant to be issued under section 86 shall be in Form 34.
116. Where an order is passed under the Act directing any person to deliver
possession of land or directing the eviction of any person from land, such
order shall be executed by the competent authority in the following manner:-(i)
Where the order is for delivery of any land possession thereof shall be
delivered to the party to whom it has been adjudged fudged, or to
such person as he may appoint to receive delivery on his behalf, and if
necessary, by removing any person who refuses or vacate the land.
(ii)
Where the order is for the joint possession of land, such possession
shall be delivered by affixing a copy of the warrant in some
conspicuous place on the property and proclaiming by beat of drum or
other customer mode at some convenient place the substance of the
order.
(iii) Where possession of any building or enclosure is to be delivered and
the person in possession, being bound by the order, does not afford
free access, the competent authority through its officer may, after
giving reasonable warning and facility to any woman not appearing in
public according to local custom to withdraw, remove or open any
lock or bolt or break open any door or do any other act necessary for
delivering possession.
(iv)
Where the order is for the delivery of land in the occupation of a
tenant to other person entitled to occupy the same and not bound by
the order to relinquish such occupancy, delivery shall be made by
affixing a copy of the warrant in some conspicuous place on the
property, and proclaiming to the occupant by beat of drum or other
customary mode at some convenient place, the substance of the order
in regard to the property.
117. (1) If resistance or obstruction to the delivery of possession is made by
any person, the person in whose in whose favour the order has been issued
make an application to the court complaining of such resistance or
obstruction . (2) The court shall fix a day for investigating the matter and
shall summon the party against whom the application is made to appear and
answer the same.

<!-- page 34 -->

Use of force
against person
putting restraint

Dismissal of
application for
possession

Transfer by judgment
debtor

Application by person
wrongly dispossessed

118. Where the court is satisfied that the resistance or obstruction was
occasioned without any just cause by the person against whom the order has
been issued or some other person at his instigation, it shall direct that the
applicant be put into possession of the property, by use of such force as may
be necessary.
119. Where the court is satisfied that the resistance or obstruction was
occasioned by any person (other than the person against whom the order has
been issued) claiming in good faith to be in possession of the party on his own
account or an account of some person other than the judgment debtor, the
court shall make an order dismissing the application.
120. Nothing in the last preceding rule shall apply to resistance or obstruction
in execution of an order for delivery of possession of land or directing
eviction by a person to whom the judgment debtor has transferred the
property during the pendency, of the proceeding.
121. (1) where any person other than the against whom an order has been
issued for delivery of possession is disposed of immovable property, he may
make an application to the court complaining of such dispossession.
(2) The court shall fix a day for investigating the matter and shall summon
the party against the application is made to appear and answer the same.

Order for re-delivery
of possession

A person other than a
judgment debtor may
institute a suit

Procedure of revenue
court and officers

Extent of applicability
of CPC

122. Where the court is satisfied that the applicant was in possession of the
property on his own account of some person other than the person against
whom the order for delivery of possession has been passed, it shall direct that
the applicant be put into possession of the property.
123. Any person not being a judgment debtor against whom an order is made
under rule 118 or rule 119 may institute a suit to establish the fight which he
claims to the present possession of the land; but subject to the result of such
suit (if any), the order shall be conclusive.
124. (1) The procedure for revenue courts and of proceeding before revenue
officer shall be governed by Schedule III.
(2) subject to the other previsions of these rules, any enquiry by a
revenue court, not specifically required to be held in the manner provided for
summary enquiry in Schedule III.
125. subject t the provisions of the Act and these rules the Code of Civil
Procedure 1908 shall, as far may be, apply to all or any of the proceeding
taken by any revenue court under the Act.
125A. (1) The 1[State Government] may either on its own motion or on the
application of any party at stage transfer any revision case arising under the
Act and pending before him or authority competent to dispose of the same.
The State Government may, however, recall any revision case at any stage
from the officers to whom it has been so transferred and hear it himself or
retransfer the same.
1. Insurted by the Tripura Land Revenue & Land Reform (5th amendment)
rules 1970.

<!-- page 35 -->

(2) Where any such case has been transferred under sub-rule (1) the officer
who thereafter hears it may subject to any special direction in the order of
transfer either re-here it or proceed from the point at which it was transferred.
CHAPTER IX
Rights of Raiyats in Land.
Reservation of land for
personal cultivation

126. (1) An application by a raiyat under section 100 shall be main
From 35 to the competent authority. The raiyat shall submit with the original
application as many copies of the application as there are under raiyats
holding land under him whose land he requires to the reserved for his
personal cultivation and two more copies to be sent for purpose of the
verification and report.
(2) The competent authority shall, from the entries in the record of
rights, ascertain, by such enquiry as may appear necessary the number of
under raiyats holding land under the said raiyat.
(3) A copy of the application shall be sent to the sub-registrar for
verification and to the tehsilder for report in form 36.

Notice of under
raiyat

127. The notice under sub-section (1) of section (2) of section 101
shall be in Form 38.

Reply of under raiyat

128. The details of lands to be furnished under sub-section (2) of
section 101 shall be in form 38.

Disposal of the
application

129. (1) Before disposing of the application for resumption the
competent authority shall examine the location, nature and quality of the lands
held by the raiyat and the under raiyat.
(2) In passing an order sub-section (3) of section 101, the competent
authority shall also determine the following:-(i)
what land, if any, the raiyat may reserve for personal cultivation;
(ii)
the location and extend of land to be left with the under raiyats; and
(iii) the right of the under raiyats to the use of source of irrigation in
respect of the land left with them.

Certificate

Notice to issue when
land left uncultivated

130. After determining the land to be reserved for personal cultivation
of the riayat and the land which each of the under raiyats may be allowed to
retain, the competent authority shall issue—
131. (1) Subject to the provision of sub-rule (2) where a raiyat has
allowed his land to remain uncultivated for a period of not less then 1[one
year] the collector may, by notice in form 41 call upon the raiyat of any such
land to use the land for purposes of agriculture by himself or through under
raiyats.
1. Substituted by the Tripura Land Revenue & Land Reforms (6th
Amendment) rules 1974.

<!-- page 36 -->

The Collector shall not issue notice under sub-rule (1):(a) in respect of land rendered unfit for cultivation through natural calamities,
or
(b) the cultivation of which has been prohibited by an order a competent
court, or
(c) the land which, under any law or custom or usage for the time being in
force is reserved in the year immediately preceding the date on which a
notice would otherwise issue for any of the following:-(i)
(ii)
(iii)
(iv)
(v)

threshing ground
irrigation tank
any public purpose;
any purpose for which permission has been obtained under section 20
of the Act;
religious purpose;

(3) Where the holder of any land satisfies the Collector within fourteen
days from the date of the service of a notice under sub-rule (1) that either his
case is covered by sub-rule (2) or he is already making full and efficient use
of land for cultivation, the Collector shall cancel the notice.
Service of notice

Compliance of notice

Lease by Collector

Registration of leases

Notice of
relinquishment

132. The notice may be served on the holder by delivering or
tendering to him a copy thereof.
Provided that where the holder of such land is not readily traceable or
refuses to accept a copy of such notice, the notice may be served by affixing a
coy thereof on the last known place of residence of such holder of land or on a
conspicuous part of the land to which it relates.
133. The notice under sub-rule (1) of rule 131 shall, subject to the
provisions of sub-rule (3) of the said rule, be complied with within a period of
three months from the date of the service of such notice or such extended
period as the Collector may, on sufficient cause being shown, from time to
time allow.
134. Where the raiyat of any such land has failed to comply with the
notice, the Collector may subject to the provision of the Act, grant a lease of
the land to such person as he may deem fit on such terms as may appear
reasonable.
135. A lese of the land by a raiyat shall be registered by the Circle
Officer on an application made in this behalf.
136. (1) The notice for relinquishment of a holding under sub-section
(1) of section 107 shall be made in Form 42 and shall be endorsed by two
witnesses.
(2) The notice shall contain particulars of each plot which the raiyat
wishes to relinguish and of the land revenue payable therefore.
(3) It shall also bear a certificate denoting that the holding or any part
thereof is not subject to any encumbrance or charge.

<!-- page 37 -->

CHAPTER—XA
Certain restriction on the rights of transfer for the protection of the interests of the
scheduled tribes.
Service of Notice for
transfer

**[136A. (1) A notice by a person not belonging to the scheduled
Tribe under section 107D shall be in Form 66 to the competent authority. The
original notice shall be accompanied by as many copies of the notice as there
are co-sharers of the land intended to be transferred and the members of the
scheduled Tribe owing land adjoining such land along with two more copies
to be affixed on such land and in the office of the competent authority.
(2) The notice shall clearly describe the property to be sold, the price to
be charged, the encumbrances to the land if any the name, address of the cosharers and the name, address of the members of the Scheduled Tribe owing
land adjoining to the land to be sold.
(3) In an application under sub-section (3) of section 107 D the cosharer and the member of the Scheduled Tribe shall indicate as to whether he
is ready to purchase the land at a price demanded by the intending transferor.
(4) If more one co-sharers or members of the Scheduled Tribe apply
under sub-section (3) of section 107D to purchase the land to be sold, the
competent authority shall selected a person entitled to purchase such land in
accordance either the provisions of sub-section (4) of section 107D and shall
communicate his decision to the person selected to purchase the land and to
the intending transferor.
(5) If no application is received under sub-section (3) of section 107D
within the time specified the competent authority shall invite applications by a
notice in Form 67 from the intending purchaser belonging to the landless
Scheduled tribe residing in the village or Tehsil, as the case may be, where the
land is situated.
(6) Notice in Form 67 under sub-rule (5) shall be served by affixing a
copy thereof in a conspicuous place of the village where the lands is situated
in the Tehsil office and in the office of the competent authority.
(7) On receipt of the applications under sub-rule (6) the competent
authority shall after examining the applications and after hearing the
applications and such other person or persons as he may to be heard, select a
landless member of the scheduled Tribe entitled to purchase the land to be
sold and shall communicate the same to the person selected and to the
intending transferor.
(8) If there is any dispute about the market value payable for the land
to be sold as referrer to in sub-sections (6) and (8) of section 107D the
competent authority shall determine the market value of the land after
examining the relevant documents and after hearing such person or persons as
he may like to be heard. The value of the land used for agricultural and
* The new chapter and new rule 136A inserted by the Tripura Land.
** Revenue and Land Reforms Act (Amendment) Rules, 1975.

<!-- page 38 -->

non-agricultural purpose shall be determined by the competent authority after
taking into consideration the market value of similar land devoted to similar
purpose in the neighborhood.
(9) The Selected intending purchaser shall deposit the consideration
money within 30 days from the date of order with competent authority under
sub-section (8) of section 107D.
(10) (a) The certificate under sub-section (9) of section 107D shall be
given to the purchaser in Form 68.
(b) The competent authority shall then depute an officer to deliver
possession of the property for which certificate had been issued to the
purchaser.
(c) The title to the property shall best in the purchaser from the date of
the certificate.
(11) If an expiry of the period prescribed under sub-rule (9) the
competent authority finds that the consideration money has not been
deposited, it shall intimate the Government to this effect and the Government
may purchase such landing accordance with the proviso to sub-section (10) of
section 107D.
(12) If the Government purchases the land to be sold then after so
purchase it may transfer the said land to the selected intending purchaser who
is a member of the Scheduled Tribe on condition of his repaying the
consideration money by such annual installments not exceeding twenty as
may be decided by the Government, with interest at the rate of two and half
percent per annum on the unpaid amount.]
CHAPTER—X
Rights of under-raiyats.
Application for
permission when raiyat
refuses or omits to
consent
When permission may
be granted or refused

Compensation for
improvement

137. If a raiyat fails or refuses to grant consent to the under Raiyat
may apply to the competent authority for permission to make such
improvement.
138. The authority to whom an application is made under rule 137
may, after hearing the parties and making such further inquiry as it thinks fit,
grant permission to make the improvement subject to such restrictions, if any,
as it may deem reasonable or may refuse permission altogether provided that
the authority—
(i)
shall not grant permission for a work which diminishes the value of
any other holding unless all the person interested in such other
holding agree in writing there and
(ii)
may refuse permission if the raiyat is prepared to make the
improvement within a time fixed by the competent authority and may
order that if the improvement is not so made the applicant shall be
entitled to make it himself.
139. An under raiyat ejected in ejected of an order for ejectment under
this Act or any other law for the time being in force, shall not be entitled to
compensation for any improvement begun by him after the termination of his
right to continue as under raiyat.

<!-- page 39 -->

Benefit of
improvement to
under raiyat in
certain cases

140. If the improvement has been made on the land from which the
under raiyat is to be ejected, the raiyat on payment of the compensation
awarded to such under raiyat shall become the owner thereof, provided that
the under raiyat shall be entitled to the benefit of the improvement in respect
of any other land held from the same raiyat remaining in his occupation, the
same extent and in the same manner as such land has hitherto benefited
thereby and this circumstance shall be taken into consideration by the
competent authority while determining compensation payable in respect of
the improvement.

Under raiyat to pay
back the
compensation

141.Where an under raiyat has been restored to possession of land
under section 119 or section 123 he shall pay back to the raiyat the amount of
compensation if any, received for improvement.

Estimating the value of
produce for purpose of
rent

142. The value of the produce of the land for the purpose of
determination of rent shall be estimated in the following manner, that is to
say:-(a) The total yield of the land shall be estimated on the basis of the actual
yield agreed upon between the raiyat AND the under raiyat, and failing
that, on the basis of the quantity of the average yield per acre of the crop
grown on that class of soil as determined during the last survey and
settlement operations for that assessment nit or on the bases of actual crop
cutting experiments undertaken by the Revenue or Agriculture
Department of the State Government or both in that year in or near that
area, where both the basis be applicable the one according to which the
yield is less shall be adopted.
(b) The value of the produce shall be determined on the average of the market
prices during the preceding year.
1

[142A. For the purpose of determination of the fixed produce rent under
section 111A the competent authority shall determine the normal produce of
the land in the manner prescribed in sub-rule (a) of rule 142 and shall fix the
produce rent at One-Fifth of such normal produce:
Provided that the competent authority may reduce or remit, as the case
may be, such produce rent in case crop be damage by pest, erosion the act of
God, etc.]
Payment of rent

143. When no agreement has been made between the raiyat and his under
raiyat regarding the time and manner of payment of rent, rent shall fall due
one month before the dates fixed for the payment of land revenue and shall
bee payable in two equal installments at the village in which the land is
situated, though the under raiyat may at his option and expense, pay it to the
raiyat at his place or send it by postal money order.
1. Inserted by Tripura Land Revenue & Land Reforms (6th Amendment)
Rules, 1974.

<!-- page 40 -->

Postal receipt and
enclosures to be
admissible in
evidance

144. Where rent is sent by postal money order, in the case of
acceptance, the payee’s receipt and in the case of refusal the endorsement of
such refusal on the money order duly stamped by the post office shall be
admissible in evidence without formal propf and shall, until contrary is
proved, be presumed to be a correct of such acceptance or refusal.

Payment of rent in
certain cases

145. (1) If two or more persons are raiyats of an under raiyat in respect
of the same holding, the under raiyat, may subject sub-rule (2) and to any
contract between the parties, by written notices to such persons require them
to appoint one of their number or some other person to receive such rent
within one month of the receipt of the notice.
(2) On failure of raiyat to comply with the notice the under raiyat may
move the circle officer in this behalf who shall thereupon call upon the raiyats
to make such an appointment and to intimate to him within one month the
name of the raiyat so appointed and shall communicate the same to the under
raiyat concerned.

Power to deposit rent in
certain cases with circle
officer

146. An under raiyat may apply to the 1[competent authority] f or
permission to deposit the amount of rent payable which he believes to be
due:-(a) if a raiyat refuses to accept the 2[rent or any installment thereof] when
tendered to him by an under raiyat; or
(b) if under rule 145 an under raiyat requires the appointment of a person to
receive the rent and such appointment is not made within 30 days of the
receipt of the notice; or
(c) if an under rayat has a reasonable doubt as to the person entitled to receive
rent.

Application for
deposit

147. The application under rule 146 shall contain.
(a) a statement of the ground on which it is made;
(b) the name of the person or persons to whose credit the deposit is to be
entered;
(c) the name of the person or persons to whom the rent is due; and
(d) the name of the person or persons to whom rent was last paid and of the
person or persons now claiming it.
148. (1) 1[ It appears to the competent authority than the applicant is
entitled to make the deposit under rule 146 he shall receive such deposit and
give a receipt therefore.]
(2) Such receipt shall operate as an acquaintance for the amount of the
rent in the same manner and to the same extent as if such amount has been
paid to the person to whom it was due.
1. 1. Inserted by Tripura Land Revenue & Land Reforms (6th
Amendment) Rules, 1974.
2.
Do

<!-- page 41 -->

Notice of deposit

Payment of deposited
rent

Determination of
reasonable rent

Factors for
determination of
reasonable rent

Date from which the
order for reasonable
rent to take effect
Commutation of
rent payable in
kind

Manner of inquiry

Passing of an order

149. The 1[competent authority] shall cause a notice of such deposit to be
served on every person who appears to him to be entitled to the deposit or
who claims any such title.
150. The 2[competent authority] may pay the amount of such deposit after
deduction the money order commission it any, to any person stated in the
application to be entitled thereto, or may retain it pending a decision of the
court of competent jurisdiction.
151. (1) An application under sub-section (1) of section 113 shall be in Form
43.
(2) The application shall be accompanied by a certified copy of the entry in the
record of rights relating to the holding and also documents, if any, in support
of the application.
152. In determining the reasonable rent the competent authority shall have
regard to the following factors also:(a) that the fertility of the land held by the under-raiyat has been decreased by
an action taken by the raiyat or by any cause beyond the under raiyat’s
control during the currency of the lease.
(b) That the fertility and the area of the land held by the under raiyat has been
increased or decreased by fluvial action;
(c) That the fertility and the area of the land held by the under raiyat has
been increased or decreased by fluvial action;
(d) That the rent is liable to abatement or enhancement or any ground
specified in a lease, agreement or decree under which the under raiyat
holds the land.
153. An order, determining the reasonable rent shall take effect from such date
as may be specified in the order.
154. (1) An application under sub-section (1) of section 114 shall be in Form
44.
(2) The competent authority on receipt of such application shall proceed to
dispose of the same after a summary inquiry.
(3) The competent authority shall, while determining the money rent, also
take into consideration the fact if the produce of the holding is liable to
exceptional fluctuation by reason of damage by wild animals, floods and the
like.
155. An application for determination of reasonable rent or for commutation of
rent may be filed by or against any number of under raiyats jointly, provided
that all such under raiyats are under raiyats of the same raiyat and all the
holding in respect of which the application is made are situated in the same
village.
156. (1) The competent authority may hear the cases of the under raiyats jointly
or separately as may appear convenient to it.
1. Substituted by Tripura Land Revenue & Land Reforms (6th
Amendment) Rules, 1974.
2.
Do
3.
Do

<!-- page 42 -->

(2) No order affecting the interest of any person, shall be passed on any such
application unless the person has been given an opportunity of being heard.
(3) The order shall separately specify the rent or the reasonable rent payable
by each under raiyat or group of under raiyats holding the land jointly.
Receipt for
payment of rent

Presumption
regarding
incomplete receipt

Eviction of under
raiyat

Application for
restoration of
possession of land to
under raiyat

Disposal of
application

Declaration of nonresunable land of under
raiyat

157. The raiyat shall give a separate receipt for rent paid either in cash
or in kind and shall prepare and retain a counterfoil of each receipt given by
him. Such receipt and counterfoil shall be in Form 45.
158. If a receipt does not contain substantially the particulars required
by the above rule, it shall be presumed, until the contrary is shown or is
contained in the receipt, to be an acquittance I full of all demands for rent
upto the date on which the receipt was given.
159. (1) An application for eviction shall include full particulars of the
ground or grounds on which the eviction is sought and shall be signed and
verified I the manner provided for a plaint in the Code of Civil Procedure,
1908.
(2) Such an application shall be heard and disposed of by the
competent authority in the manner provided I the Code of Civil procedure,
1908, for hearing and disposal of suits for immovable property.
160. An under raiyat who is entitled to restoration of possession under the
provisions of section 119, may apply to the circle for putting him back in
possession stating:-(a) the date on which the raiyat took over possession from him;
(b) whether the raiyat did not cultivate such land personally within one year
from the date he took possession;
(c) if was not cultivated by the raiyat within one year from the date of taking
possession, whether it was left fallow and if it was cultivated the name of
the person who actually cultivated it and his relationship with the raiyat
(i.e whether he is an under raiyat, servant, hired laborer or a member of
his family).
(d) Whether the land was not cultivated personally by the raiyat in any year
during a period of four years next following the date of his taking
possession and whether it was cultivated by any other person during that
year, if so the year and the name of the person who cultivated it and his
relationship, if any, with the raiyat.
161. The circle officer shall there after proceed to dispose of the
application after a summary inquiry as provided in Schedule III.
162. (1) An application of an under raiyat under section 120 shall include
such of the following particulars as may be applicable to the case:(a) land held by the under raiyat;
(b) land held by the raiyat;
(c) particulars of the order by which the land was declared reserved for
personal cultivation of the raiyat under section 101 and the particulars of
that land;

<!-- page 43 -->

(d) whether the raiyat has failed to move for eviction of the under raiyat from
the land within the period mentioned in sub-section (3) of section 118;
(e) whether the raiyat has failed to apply for reservation of any land within
the period prescribed in section 100 and the land is not deemed to have
been reserved under section 103;
(f) whether the under raiyat has been restored possession of any land under
section 119 and the particulars of the land and of the order restoring
possession.
(2) The competent authority shall, before passing an order under section 120
give notice to the raiyat concerned and hold a summary enquiry.
Form of manner of
application under
section 123(1)

163. (1) The application by an under raiyat to regain possession under
sub-section (1) of section 123, shall be I the form of a plain and shall contain
the following particular.
(a) Details of the land held by the applicant i.e. plot No. area village;
(b) the date on which the applicant was evicted;
(c) the circumstances in which the applicant was evicted;
(d) the name and address of the person now cultivation the land with his
relationship, if any, with the raiyat.
(2) The application shall be accompanied, wherever such record exist, by
certified extract of the Revenue Records and by as many extra copies of the
application as may be required for service on the interested parties.

Application for
surrender of land by
an under raiyat

164 (1) 1[Subject to the provisions of the Act the surrendered land under
section 125, nay be leased out by the collector to such person as he may
deem fit and on such terms as may appear reasonable.]

Compensation to
raiyats

165 (1) The land revenue payable for similar lands in the locality referred
to in sub-section (2) of section 127 shall be calculated on the basis of the
revenue rates confirmed under section 34.
(2) The value of the trees shall be determined on the basis of the market
yalue of such trees at that places neighbouring therto.

Application
compensation and
procedure therein

166. 1[The compensation under sub-section (3) of section 127 shall be
determined in the following manner:(1) The competent authority shall determine the compensation payable to
the raiyat after giving to the party/parties concerned, an opportunity of being
heard in the matter.
(2) A copy of the statement giving details of the compensation proposed
to be given to the person concern shall be pasted on the notice board of the
office of the competent authority to enable any one interested to file
objection and copies of the same shall also be served on the raiyat and under
raiyat concerned.
1. Substituted by Tripura Land Revenue & Land Reforms (6th
Amendment) Rules, 1974.

<!-- page 44 -->

Payment of
compensation to
raiyats

(3) The competent authority shall, thereafter decide the objections
after a summary inquiry.
(4) Separate compensation shall be assessed in respect of each holding
of an under raiyat or each joint hold of under raiyats.]
167. The competent authority shall be serving notice on every raiyat
tender payment of compensation. Payment of compensation shall be made I
accordance with the following table:First Rs. 500/- or less in one installment.
Balance if any-- in equated annual installment not exceeding 20
subject a minimum of Rs. 500/- per installment
except the last one.

Payment of
compensation by
under raiyat

(2) The provisions of Schedule IV shall, as for as may, apply to the
payment of compensation to raiyats and to the payment of annuities under
sub-section (4) of section 128.
(3) separate registers for payment of compensation to raiyats and for
payment of annuities under sub-section (4) of section 128 shall be maintained.
168. The under raiyat shall pay compensation according to the following
table:-Upto Rs. 50/Balance, if any

First option to
purchase

one installment.
in 15 equated annual installments,
subject t a minimum of Rs. 50/- per
installment except the last one.

(2) A register of payment of compensation by the under raiyats to the
Government shall be maintained.
(3) the certificate to be issued under section 130 shall be in form 48.
169. (1) A raiyat intending to sell the land held by an under raiyat shall
give a notice in Form 49 to the under raiyat ad offer sell the land to him. This
notice shall be given by registered post to the under raiyat or under raiyats, as
the case may be, occupying the land in question and such notice shall clearly
describe the property to be sold, the price to be charged and the encumbrances
o the land, if any.
(2) An application under sub-section (2) of section 131 for
determination of the reasonable price in case of any dispute may be made by
the raiyat or the under raiyat in Form 50.

<!-- page 45 -->

(3) When an application has been made to the competent authority under subsection (2) of section 131 it shall ordinarily determine the reasonable price
within a period of 30 days of the receipt of such application.
(4) After the determination of the reasonable price by the competent authority
the under raiyat shall deposit such price within one month or such further
period not exceeding one month as the competent authority may allow.
(5) In case of failure on the part of the under raiyat to deposit the reasonable
price within the time allowed under sub-rule (4) the raiyat concerned shall be
in formed by the competent authority.
(6) The certificate under sub-section (4) of section 131 shall be issued by the
competent authority in Form 51.

CHAPTER XI
Acquisition of Estates and of the Rights on Intermediaries therein.
Manner of
publication of
notification under
section 134

Value of produce
building and
structures

170. A notification under sub-section (2) of section 134 shall be published.

(a) in at least two issues of each of two newspapers (one of which must be in
the Bengali language)
(b) by affixing a copy of the notification together with a Bengali translation
of:
(i)
in the office of the Collector; and
(ii)
at each sub-divisional office, Police station and sub-Registry office
within the area specified in the notification.
171. (1) for the purpose of clause (d) of section 135 the value of the produce
shall be determined on the average of the market price during the preceding
year.
(2) In determining the market value of any building or structure referred to in
the proviso to clause (d) of section 135, first the present cost of construction
of the building or structure shall be worked out and then reasonable
allowances shall be made on account of depreciation during the period the
building or structure has been in existence.

Service of the order
of the Collector
under section 137
and form of
statement referred to
therein

172. (1) The order of the Collector referred to in sub-section (2) of section
137 shall be in form 52.
(2) The statement referred to in sub-section (2) of section 137 shall be
in form 53.
(3) the order may be served
(i)
by delivering the same to the intermediary or to the person to whom it
is directed or to the authorized agent of

<!-- page 46 -->

Such intermediary or person, or on failure of such service by delivering a coy
of the order to any adult member of the family of such intermediary or such
person or by affixing such copy on some conspicuous part of the premises in
which such intermediary or person resides or is known to have last resided,
or;
(ii)
by affixing a copy of the order on a conspicuous part of any
‘Kutchari’ of the intermediary; or
(iii) by sending by registered post to such intermediary or person at his
ordinary place of residence or at the place where he may be known t
reside.
Procedure for search
and seizure

173. (1) The Collector or an officer appointed by him this behalf shall not
ordinarily enter into any building for the purpose of seizing and taking
possession of bocks, account and other documents referred to in sub-section
(3) of section 137 before sunrise and after sunset.
(2) The Collector or the officer making the search shall allow the
occupier of the building or a person nominated by the occupier to watch the
search.
(3) A receipt for the books, accounts or other documents seized and
taken possession of shall be given (on the spot immediately after making the
search) by the person seizing them to the person from whose possession they
are seized.

Inspection

174. Inspection of document, registers and records referred to in sub-section
(4) of section 137, shall be allowed on application by the Collector at such
time and place and under, such conditions as the Collector may direct for the
purpose.
CHAPTER XII
Assessment and Payment of Compensation.

Collection of
information by the
Compensation
Officer

Procedure on return
being filed

175. (1) As soon as may be, after the vesting of estates in Government has
taken place in any area, the compensation officer shall issue notice in Form 54
to each intermediary having land within that area calling upon him to file a
return in Form 5 within a period of thirty days from the service of such notice
or such longer period as the compensation officer may allow time to time.
(2) The compensation officer may call f or any information or record
from Collector or survey and Settlement Officer which may appear to him
relevant for the purpose of assessment of compensation.
(3) The compensation officer will then proceed to determine the gross
income and net income of every estate in accordance with the provisions of
the Act and these rules.
176. (1) The compensation officer shall separate the returns of those
intermediaries whose compensation can be determined immediately from
those of the intermediaries whose compensation cannot be determined
immediately in view of the provisions of sub-section (4) of section 144.

<!-- page 47 -->

(2) Thereafter the compensation officer shall proceed:-(i)

(ii)

Procedure when
returns submitted
to more than one
officers

Commutation of
rents in kind

Manner of payment of
perpetual annuity

in the case of any intermediary whose compensation can be determined
immediately to determine the compensation payable to him and shall
enter it in the compensation assessment roll; and
in the case of an intermediary whose compensation cannot be
determined immediately, to estimate the probable amount of
compensation that might be payable to him in respect of the estate that
has vested in the government and enter it in a register.

177. Notwithstanding anything contained in rule 176, if the compensation
officer finds that the intermediary has submitted a return previously before of
that intermediary to the compensation officer before whom such return was first
submitted and thereafter such last named compensation officer will preceded in
accordance with the last preceding rule.
178. For the purpose of determining the commuted value of rents payable in
kind, the compensation officer shall first determine the amount of rent payable
by the tenant or the tenure holder for the previous year and then he shall
determine the value of that rent in kind at the average of prices prevalent for
that produce during that year and the two years immediately preceding.
179. (1) The annuity referred to in sub-section (2) of section 146 shall be paid
every year in cash to the person having authority to receive payment and to
grant discharge on behalf of the institution.
(2) Record of all such payments shall be kept in a register.

Manner of making
claims by a creditor

180. (1) A petition of claim by a creditor under sub-section (2) of section 147
shall state the following particulars;(i)
(ii)
(iii)
(iv)

(v)
(vi)

(vii)
(2)

name and address of the intermediary against whom the claim is
preferred;
name and address of the intermediary against whom the claim is
preferred;
amount of the principal advanced;
number of touzi and name of tehsil or such division of the estate or
tenure mortgaged or charged, (if a part of an estate or tenure is
mortgaged or charged, the chare charged or mortgaged should be
stated);
a true or certified coy of the document forming the basis of the claim;
the amount of interest or the total of the profits from the mortgaged
property already realized by the creditor and the time or times of the
realization of such interest or profits, and
any other particulars which may be necessary for determination of the
claim.
The petition shall be signed and verified in the maner

<!-- page 48 -->

Provided in the Code of Civil Procdure,1908, for signing and verification of
plaints.
(3) Such a petition shall be preferred by the claimant or his duly
authorized agent within six months of the date of vesting or the date on which
such a creditor is dispossessed under section 137 or within three months of
the appointment of the claims officer whichever date is the latest.
(4) On receipt of a petition the claims officer shall se if it is in order. If
it is nt in order he may allow the petitioner an opportunity to put in order
within such time or extend time as may be allowed by the claims officer in
default he may reject the petition.
(5) When the petition is in order the claim shall forward a copy thereof
to the compensation officer for his information and proceed with the claim in
the manner provided in the Code of Civil Procedure, 1908, for a suit for the
enforcement of a mortgage and shall, subject to the precisions of the Bombay
Money Lander’s Act, 1946 as extended to Tripura, determine the amount if
any due to the claimant.
(6) Where there are two or more creditors the claims officer shall after
allowing the creditors an opportunity of being heard, determine in accordance
with the provisions of the Transfer of Property Act, 1882 the order in which
each such creditor is entitled to receive the amount due to him.
(7) After the claims have been finally disposed of and the order, if
any, of their priority has been decided, the claims officer shall send a copy
each of his decisions and a copy each of the decisions, if any, of the appellate
court, to the compensation officer.
Preparation of
compensation
assessment roll
Preliminary publication
of compensation
assessment roll

181. The compensation officer shall prepare draft compensation
assessment roll in Form 56 for each estate and also for each intermediary.
182. (1) The Compensation officer will publish draft of the
compensation assessment roll by placing it open to public inspection free of
charge during a period of thirty days at such convenient place as he may
determine and a public notice shall be given in each village to which the
compensation roll relates stating the period during which it will be open to
public inspection and specifying the period within which objections may be
filed. A copy each of the notice and of the roll shall be served o the
intermediary or intermediaries concerned.
(2) Objections may be filed by the persons interested to the
compensation officer, as far as may be in Form 57. Along with the original
objection the objector shall file copies of the notice for service on persons
who are materially interested in the case and the compensation officer shall
issue notices informing the objector and such persons who are interested of
the date and place fixed for hearing of the objections. No objection shall be
disposed of without affording the parties materially interested or their duly
authorized representatives an opportunity of being heard:

<!-- page 49 -->

Provided that I any case, I which an order is made exparte against a
person, he may apply to the compensation officer by whom the exparte order
was made for an order to set it aside, and if he satisfies the compensation
officer that the notice of objection was not duly served on him or that he was
prevented by any sufficient cause beyond his control from appearing when
the case was hard, such officer may make an order to set aside the order as
against such a person and thereupon he may appoint another day for
proceeding with the matter;
Provided further that where the exparte order is of such a nature that it
cannot be set aside against such person only, it may be set aside as against
all or any of the order persons involved in the case.
(3) The draft of the compensation assessment roll shall be modified in
accordance with the final orders passed on the objections.
Final publication
of the
compensation
assessment roll

183 (1) After the expairy of the period specified for filing the
objections, or where any objection has been filed when all objections have
been finally disposed of an the draft of the compensation assessment roll has
been modified accordingly, the compensation officer shall cause such roll to
be finally published by affixing a copy thereof on the notice boards of the
Collector and sub-divisional officer within whose jurisdiction the land in
question is situated and also by affixing a coy on the notice board of the
compensation officer.
(2) A copy of the compensation assessment roll shall be sent by
registered post acknowledgement due to each intermediary whose name
appears in the roll as a person entitled to compensation.
(3) After such publication the compensation officer shall make a
certificate in Form 53 in token of the compensation assessment roll having
been finally published.

Manner of
payment

184. Subject to the provisions of sub-section (2) of section 155, the
balance remaining after deduction shall be paid in the following manner:(i)

Payment of
Compensation

Register of
payment

Ad-interim
compensation

in case the amount of such balance is rupees two thousand and five
hundred or less, the entire amount shall be paid in one installment;
(ii)
in case the amount of such balance is rupees two thousand and five
hundred, it may be paid in annual installments, to installment except
the last one being of less than rupees who thousand and five hundred.
185. (1) The compensation officer shall by serving notice on the person
entitled to compensation tender payment thereof.
(2) The provisions of Schedule IV shall as far as may be, apply to the
payment of compensation.
186. There shall be maintained a register of payment of compensation
intermediaries.
187. The amount entered in the register maintained under sub rule (2)
of rule 176 shall be deemed to be the probable amount of compensation for
the purpose of clause (a) section 154.

<!-- page 50 -->

Application for an –
interim
compensation

188. (1) Application for ad-interim compensation shall be made and
presented to the compensation officer. The application shall contain all
particulars of the estates and interests of the intermediary situated in the area
where vesting has taken place. Where the applicant holds estate or estates or
which are situated within the jurisdictions of more than one compensation
officer, such application shall be filed before the compensation Officer of the
area where the vesting has taken place earlier or where the largest estate lies.
Every such application shall be in Form 59.
Where there is a dispute about the right, title or interest of the
applicant, the compensation officer shall withhold payment until such time as
the dispute is decided by a competent court.
(2) No court fee shall be charged upon application for ad-interim
payment.
(3) The payment of annual ad-interim compensation shall be made
according to the year and the amount payable on such account for each year
shall be paid within three months after the close of the year.

Manner of keeping in
deposit disputed adinterim compensation
money

(4) The Collector shall maintain a register of all ad-interim payments.
189. The amount held in dispute and remaining undisbursed under
clause (c) of section 154 of the Act shall be kept in revenue deposit in the
Treasury with necessary particulars.
CHAPTER XIII
CEILING ON LAND HOLDINGS.

Submission of return

190. (1) Every return under section 165 shall be in form 60.
(2) Where a person or any member of his family holds any land jointly
with another person who is not a member of his family, the share held by him
or by the members of his family shall be shown distinctly in the return.
(3) Along with Form 60 further in formation shall be furnished in form
61 showing transfers, if any made after 24th January, 1971.
(4) The return shall ordinarily be submitted in triplicate, but as many
additional copies of From 60 and 61 shall be furnished as there are village in
which the land held by the person o any member of his family is situated.
(5) A member of a co-operative society shall furnish in Form 60 and
61 information in respect of his share of the land held by him in the cooperative society.
1. Substituted by Tripura Land Revenue & Land Reforms (6th Amendment)
Rules 1974.

<!-- page 51 -->

191. 1[If the return under the proceeding rule is not submitted within the
period prescribed by the State Government under section 165 or within the
time allowed under sub-section (2) of section 166 the necessary information
shall be collected by the competent authority through his circle officer or the
Assistant survey & Settlement Officer as the case may be]

The agency
through which
information may
be collected under
section 166
Verification etc

192 (1) Where a return is submitted under the rule 190, the information
contained therein shall be verified from the entries in the record of rights.
(2) Where necessary information has be collected under rule 191 the
competent authority shall give the person concerned an opportunity of being
heard.

Preparation of list

193. The competent authority shall, after the return furnished under rule 190 of
in formation collected under rule 191 has been verified, cause a notice to be
given to the persons concerned who may be in possession of the land or part of
the land and may call for such additional information, evidence or proof from
them s it considers necessary.
After considering such facts, circumstances and documents which the persons
concerned might bring to his notice, the competent authority may with or
without any further inquiry, determine the excess land as well as the land to be
retained by such person and thus prepare the list under sub-section 167 in form
62.

Consideration
of any land so
transferred or
partitioned

2

[ 193A—In determining the bonefide transfer or partitioned under clause (a) of
sub-section (1) of section 168B the competent authority shall hold such enquiry
as he deems fit after giving the transfer or an opportunity of being heard]
1. Substituted by Tripura Land Revenue & Land Reforms (6th
Amendment) Rules 1974.
2 Inserted by Tripura Land Revenue & Land Reforms (6th
Amendment) Rules 1974.

<!-- page 52 -->

Selection of excess land
out of transferred land

Publication of list for
objection

194. In case the competent authority proposes to select excess land out
of the land transferred, it shall do so after giving to the notice to the
transferee or transferees concerned and after giving them an opportunity of
being heard. It may also all for such additional information as may be
necessary for determination of the proportion in which the excess land is to be
selected out of the land transferred and the transferee or transferees concerned
shall be bound to furnish the information called for.
195. (1) The list prepared by the competent authority shall be
published in the office of the Collector, sub-Divisional Officer, circle officer
and the registration office and a coy thereof shall be served on the person or
persons concerned.
(2) The competent authority shall serve the list on the raiyat or under
raiyat or mortgagee with possession whosoever occupies the excess land by
tendering or delivering a copy thereof to him or to his duly authorized agent.
(3) If such person or his agent by not available, the list shall be
delivered to any adult member in the house in which the person ordinarily
resides.
(4) If the case covered by the sub-rule (2) and (3) above the serving
officer shall require the signature of the recipient to be given in the body of
the returnable copy in token of acknowledgement of receipt of the copy
served on him.
(5) If such person ordinarily resides the jurisdiction of the Union
Territory of Tripura, then the list may be served by posting a copy to him by
registered post, and such posting shall be deemed to be sufficient service.
(6) If such person or his agent or any adult member in his house be
found unwilling to accept the list or to sign acknowledgement or avoiding
service, or if he resides outside the Territory and his address is not known, the
list may be served by affixing a copy thereof in some conspicuous part of the
land to which the list relates.
(7) A report by the serving officer stating the manner and date of such
service attested by two person present at the time of service shall be
sufficient proof thereof.

Application for
restoration

Manner of
publication under
sub-section 3 of
section 170

196. An application for restoration possession under the proviso to
sub-section (4) of section 169 shall be made within thirty days of the
publication 170 the list in the official Gazette under section (3) section 167.
197. 1[(1) List s approved or modified under sub-section (2) of section
170 shall be published in the official Gazette in form 62A.
(2) The list published under sub-section (3) of section 170 shall be
served on the person or persons concerned in the manner laid down in rule
195 and copy thereof shall be pasted at the court house of the competent
authority.]
1. Substituted by Tripura Land Revenue & Land Reforms (6th
Amendment) Rules 1974.

<!-- page 53 -->

Calling information
for determining
compensation

Verification of
information
furnished

Compensation for
structure and
buildings

Appointment of
compensation
between the raiyat
and under raiyat

198. For the purpose of determining compensation, the competent
authority may, as soon as possible, as after the publication of the list under
section 170 call upon any person from whom excess land has been acquired
or transferred to furnish the following information within 30 days of the
receipt of its order.
(i)whether their is any building or structure or tree on the excess land
and if so, by whom were they constructed or planted;
(ii) whether the person from whom land has been acquired or
transferred held it as raiyat and, if so, whether there is any underraiyat of under raiyats o the land; in case there is any under raiyat, the
area occupied by each;
(iii) whether the person from whom the land has been acquired or
transferred held it as an under raiyat; in case it is so, the name of the
raiyat;
(iv)
whether the person from whom the land has been acquired or
transferred held it as a mortgagee in possession; incase it is so, the
name of the mortgaee ; and
(v)
any other information consistent with the above.
199. (1) The competent authority may verify the above information
through the Survey and settlement officer or the circle officer of the circle.
(2) It shall give the person, whose land has been acquired, or
transferred, a reasonable opportunity of being heard.
(3) It may call for such further information as it considers necessary.
200. 1[Omitted]
201. Save as otherwise provided in these rules the competent authority shall
determine the compensation in respect of any structure or building
constructed on excess land in accordance with the provisions of Chapter X.
202 (1) If the parties agree to an apportionment, the compensation shall be
apportioned accordingly, otherwise apportionment shall be made by the
competent authority.
(2) In determining the shares of the raiyat and under raiyat under subsection (2) of section 171, the following shall be taken into consideration.
(i)

50% of the value of the average yearly gross produce which may be
agreed l upon between the parties or as determined under rule 200,
minus the amount of annual rent payable for the year immediately
preceding the year in which section 164 is enforced shall be taken as
the under raiyats share of net income.

(ii)

The raiyats share of net income shall be equal to the aforesaid rent
minus the revenue payable by him in respect of the land for the said
preceding year.
1. Omitted by Tripura Land Revenue & Land Reforms (6th
Amendment) Rules 1974.

<!-- page 54 -->

(iii)

Recovery of
compensation from
under raiyat or
mortgage

Determination of
compensation

The compensation payable in respect of the excess land shall be
apportioned between the raiyat and the under raiyat proportion to
their respective shares in the net income determined as above.

203. (1) The compensation shall be recovered by the State Government
from the under raiyat or the mortgagee with possession as the case may be, in
such installments as may be determined by the competent authority keeping
in view the amount of compensation.
Provided that an under raiyat or mortgage with possession shall have
the right to set of any amount which he is entitled to receive as compensation
under the provisions of the Act.
(2) A register of all such amounts to be recovered will be maintained.
204. (1) On receipt of an application or on its own motion the
competent authority shall prepare a compensation statement for land of which
ownership has vested in the Government or in an under raiyat or mortgagee in
possession.
(2) A copy of the compensation statement shall be sent to the persons
interested along with a notice informing them to file objection, if any within
the period to be specified in the notice.
(3) A copy of the said compensation statement shall be affixed on the
notice board of the court house of the competent authority to enable any
other interested person to file objections.
(4) The competent authority shall issue notice informing the objector
and such persons who are interested, of the date and date and place fixed for
hearing of the objection. No objection shall be disposed of without affording
the parties materially interested or their duly authorized representatives an
opportunity of being heard.
Provided that in any case in which an order is made expert against a
person, he may apply to the competent authority by whom the experte order
to set it aside and if he satisfies the competent authority that the notice of
abjection was not duly served on him or that he was prevented by any
sufficient cause beyond his control form appearing when the case was heard
the competent authority may make an order to set aside the order as against
such a person and thereupon may appoint another day for proceeding with the
case.
Provided that where the exparte order is of such a nature that it cannot
be set aside against such a person only it may be set aside as against all or any
or the other persons involved in the case.
(5) After the expiry of the period for filing objection or where any
objection is filed when al the objections have been finally disposed of, a copy
of the compensation statement shall be sent by registered post
acknowledgement due to each interested person.

Payment of
compensation

205. (1) The competent authority shall by serving a notice on every person to
whom the compensation is payable tender the payment thereof.

<!-- page 55 -->

Payment of compensation shall be made in accordance with the
following table:First Rs. 1000/- of less-- In one instalment.
Balance, if any—In equated annual instalments not exceeding 20
provided that no instalment except the last shall be of less than Rs. 1000/Application of
Schedule IV
Register of
compensation

Payment of
compensation to
charge holders

Acquisition of excess
land after
enforcement of
section 164
Forms 60 and 61

Demarcation of
excess land

Application for
exemption

206. Compensation shall be paid as far as may be in accordance with
Schedule IV.
207. There shall be maintained a register of compensation paid under
this chapter.
208. Any person having a charge o the compensation amount under
sub-section (4) of section 171 may within 60 days of the notification under
section 170 prefer claim in writing to the competent authority dealing with the
compensation of the land in question and payment may be made in
accordance with such agreement as may be arrived at between the parties. In
case of dispute, the amount shall be kept in deposit in the government
Treasury till the dispute has been decided by a Court of competent
jurisdiction.
209. (1) If after the enforcement of Section 164, any person either by
himself or through any member of his family, as raiyat, under raiyat or
mortgagee with possession acquired land in any manner whatsoever, whether
by transfer, exchange, lease, agreement of succession, which with or without
the lands already held by him or any member of his family, exceeds in the
aggregate limit fixed under section 164, he shall within 60 days from the date
of such acquisition submit to the Collector a return in Forms 60 and 61 giving
the particulars of all has lands selecting the lands he desired to retain.
(2) If he fails to submit a retain and select the land within the period
mentioned in sub-rule (1), the competent authority may obtain information as
provided under rule 191 and select the land.
(3) Rules 192 to 200 shall thereupon apply mutates mutandis.
210. After such survey as may be considered necessary and by putting
temporary boundary marks, the Collector shall take steps to demarcate the
excess lands and shall require the persons holdings the excess land to give up
possession thereof within a period of 30 days of the demarcation.
211. (1) Application for exempted shall be made in duplicate.
1
[(2) In determining the lands to be exempted from the operations of section
164 under clause (a) of sub-section (1) of section 178 the following shall be
taken into consideration:
(a) Planted area that is to say, area actually being say for growing tea, coffee
or rubber;
(b) Programme, if any, for expansion during the next ten years and the area
of land to be covered thereby;

1. Substituted by Tripura Land Revenue & Land Reforms
(Amendment) Rules 1962.

<!-- page 56 -->

(c) area required for replantation;
(d) area of land under thatched or bamboo hutments;
(e) lands on which factories, labour quarters, play-grounds, hospitals,
schools, markets and other ancillary building of the plantation exist;
(f) lands used of required for provision of water supply and growing fuel
trees and grass for thatching purposes, for the use of factories and persons
employed in the plantation; and
(g) unplantable enclaves within the area which the area which may be
permitted to be retained for the purposes mentioned in clauses (a) to (f) if
the acquisition of such enclaves would interfere with the smooth working
of the plantation]
1

[(3) the state Government may for the purpose of determining the area of
lands to be exempted under sub-rule (2) appoint a Committee consisting of
three persons. One of the members of the Committee shall be a person having
expert knowledge of growing tea, coffee of rubber according as the area to be
determined relates to growing of tea, coffee or rubber and the other members
of the committee shall be person in the employ of Government, provided that
where the committee is to deal with lands used for growing tea, the person
having expert knowledge of tea growing shall be appointed in consultation
with the Chairman of the Tea Board establishment under the Tea Act, 1953
(29 of 1953). The committee shall take into consideration of the provisions of
sub-rule 92) and recommend the extent of land which may be exempted from
the operation of section 164.]
2

[(4) After consideration the findings of the committee and after haring the
persons concerned and such other person as he may like to be heard, the State
Government may, for reasons to be recorded, by order determine the area of
land to be exempted.]
1

[(5) Every area of land exempted form the operation of section 164 for
purpose mentioned in clause (b) or clause (f) of sub-rule (2) shall be used for
the said purpose within a period of ten years from the date on which the State
Government passes an order exempting that area under sub-section (1) of
section 178.]
CHAPTER XIV
PREVENTION OF FRAGMENTATION
Declaration under
section 182(2)

212. The declaration to be made under sub-section (2) of section 182
shall be filed in triplicate in form 63 before the competent registering
authority referred to in that sub-section.

1 & 2. Inserted by Tripura Land Revenue & Land Reforms
(Amendment) Rules 1962.

<!-- page 57 -->

CHAPTER XV
GENRAL AND MISCELANEOUS.
Restoration of
Possession

Court fees

Procedure to be
followed by the
collector under
section 187

213. The provisions of rule 163 shall mutates mutandis apply to proceedings
under sub-section (2) of section 186.
214. Every document mentioned in column 3 of Schedule V shall be
chargeable with court fee as specified against it in Column 4 of the said
schedule and no document so chargeable with fee shall be entertained or acted
upon by any officer or authority until the full amount of court fee chargeable
there o has been paid.
2

[215. Before giving any permission to the transfer of any land by a member
of the scheduled tribe under sub-section (b) of section 187 of the Act, the
Collector shall—
(a) inquire whether the member of the scheduled tribe can afford to meet his
wants without transferring the land;
(b) inquire whether after the transfer the transferer will be left with agricultural
land not less than the size of a family holding;
(c) 3(c) [obtain the recommendations of the District Tribal Advisory Committee
in all cases after apprising the committee of the result of his enquiry;]
4

[216. (1) The application for restoration of possession under sub-section (3) of
section 187 shall be in Form 64.
Restoration of
transferred land to
the member of the
Scheduled Tribe

(2) On receipt of any application or any information regarding transfer of any
land by a member of scheduled tribe made in contravention of sub-section (1)
of section 187, the revenue officer specially appointed for the purpose of subsection (3) of section 187 shall draw up a proceeding and issue notice in Form
65 to the transfere or any peso claiming through or under him to show cause
within the time specified in the notice why possession of the land should not be
restored to the transferer or his successor in interest, after objecting the
transfere or the person claming through or under him.
(3) If the transfer or a person claiming the land through or under him, files an
objection within the period specified in the notice or such extended period not
exceeding fifteen days in the aggregate allowed
2. Inserted by Tripura Land Revenue & Land Reforms (4th
Amendment) Rules 1979.
3. Substituted by Tripura Land Revenue & Land Reforms (6th
Amendment) Rules 1974.
4. Inserted by Tripura Land Revenue & Land Reforms (6th
Amendment) Rules 1974.

<!-- page 58 -->

By the revenue officer. The revenue l officer shall hold a summary enquiry I
the matter laid down in schedule III of the Tripura Land Revenue and Land
Reforms Rules, 1961.
(4) If the transfere or any person claiming through or under him files
no objection within the time allowed or if after enquiry the revenue officer
finds that the transfer of any land or part thereof was made in contravention of
sub-section (1) of section 187 he shall order the transferee or any person
claiming through or under him to make over possession of such land to the
transferer or to his successor in interest.
(5) If the transfere or any person claiming through or under him files to
comply the order passed against him under sub-rule (4) then the revenue
officer or any other officer authorized in this behalf may such step or use such
force as may be necessary to enforce compliance of the orders on any date
following the date mentioned in sub-rule (4) without any further notice to the
defaulting person and may also enter any building or place for the purpose.]

By order of the Governor.
Secretary
Revenue Department
Government of Tripura.

* Word ‘Administrator’ substituted by the word ‘State Government’ by North
Eastern Areas (Reorganisation) (Tripura) Adaptation of Laws order 1973.
** The expression “Tripura Administration” is proposed to be substituted by
“the words” The Govt. of Tripura by 13th Amendment of the Rules.

<!-- page 59 -->

SCHDULE—1

T.R.L.R. Form—1
(See rule 9{2})
Notice for allotment of land for pasturage/community purposes under section 13.
Whereas it appears necessary that land specified below may be set apart for pasturage
for the village cattle/community purposes, objection if any, may be made within thirty
days from the date of publication of this notice.

Village/ Tehsil
Sub-Division

Plot Number

Area

1

2

3

Date--

Purpose in case of
land to be set aside
for pasturage for
the cattle of any
village or villages
specify the village
or villages.
4

Collector

<!-- page 60 -->

1
2
3
4
5
6
7
8
10
11
12

9

Annual land revenue

Cess..
Total…..

This receipt is issued on receipt of Rs…………………………………
(in words Rupees………………………………………………………………)
Of Signature of the person making paymeny.

Signature of the Revenue Officer
13

By order of the Governor.
Under Secretary to the
Govt. of Tripura

of

the

Receipt Book No.
Signature and designation
receipient of coupon.

Serial No. of Receipt ……
Father’s Name…………...
Total amount paid……..

Name of PS……

COUPON

General Serial No.
Of receipt

Receipt Book No…...
Name of Mouja…….
Name of Raiyat…….
Date of collection…..
Date of collection of
coupon

Total of current and arear
demand (3+11)
Grand Total

Arrear Demand
Land Revenue

Total of arrears (7+10)

Current Demand

Total

Area of land
Accounts of revenue collected

Of 13:…..B.S
Of 13:…..B.S. and
previous years to that

No. of holding

Total

Father’s Name

Of 13:…..B.S. and
previous years to that

Name of raiyat

Of 13:…..B.S.

Name of Mouja

Of 13:…..B.S.

Name of Tehsil….

Total

Particulars of holding & raiyats

Cess

Collection No

Land Revenue

T.R.L.R. Form 3
(See rule 35)

<!-- page 61 -->

T.R.L.R. Form 3
(See rule 39)
NOTIFICATION
No………………..

Dated, the…………………….

It is hereby notified for general in formation under rule 39 of the Tripura Land Revenue and
Land Reforms Rules 1961 read with section 26 of the Tripura Land Revenue and land
Reforms Act, 1960 that a Revenue survey of the area specified in the schedule below shall be
made with a view to the settlement of land revenue and to the preparation of record of right
connected therewith/or the revision of any existing settlement or/record of rights.
Schedule
………………….
…………………..
……………………
Delete the words which are unnecessary

By order the Governor
Secretary,
Revenue Department
Government of Tripura

T.R.L.R From 4
[See rule 39 )2)]
PROCLAMATION
No………………

Dated, the…………

All land holders and members of public of the village mentioned in the schedule below and
of the village contiguous thereto are hereby informed that orders have been issued for
revenue survey and preparation/revision of the record of rights pertaining to the village on the
basis of and following the work of village boundary demarcation and other maters, relating to
survey and settlement of the said village according to the provisions of the Tripura Land
Revenue and Land reforms Act, 1960.
Schedule
……………
…………………
………………….
Survey and Settlement Officer,
Government of Tripura
(Delete the word which is unnecessary)
T.R.L.R FORM 4A
[See rule 71A (2)]
PROCLAMATION
No……
Dated, the…………..
All land holders and members of public of the village mentioned in the schedule below and
of the village contiguous thereto are hereby informed that preparation of Khasra pertaining
to the T.L.R & L.R. Act, 1960 will be taken up by the Revenue Officer with effect from the
date to be ntifid by him under sub-rule (3) 17A of the T.L.R & L.R rules, 1961.
Schedule
Sub-Divisional Officer

<!-- page 62 -->

T.R.L.R From 4 B
[See rule 37 (1)]

Table of profits of agriculture and value of land per hectare

Sub-Division

Revenue
Circle

Name,
number and
area of the
unit

1

2

3

Name of
villages/part
of villages
within the
unit
4

Class of land

Name of crop

5

6

Total average
value of yield
(Col.9a 9b)

Average cost
of cultivation

10

11

Annual average yield

Average mark price

Average value of yield

Main Crop. By-product

Main Crop By-product
(Col.7aX8a) (Col.7bX8b)
8a
8b

Main crop By-product

7a

7b

Average profits of agriculture
(Col-11)
12

9a

9b

Average value of land

Remarks

13

14

<!-- page 63 -->

T.R.L.R. FORM 4 C
[See rule 37 (1)]
NOTICE
Whereas the table of profits of agriculture and value of land relating to the
unit………………comprising the Villages mentioned in the schedule below has been
prepared under section 25, the same shall be opened to public inspection
at………………………for a period of thirty days from the date of publication of this notice,
Objection, if any, to any entry in the table may be filed before the undersigned within the
afore-mentioned period.
Collector/Revenue Officer
Date…………………
Place………………
SCHEDULE
Name and No. of the unit.

Name(s) of Village(s)

Revenue Circle and
Sub-Division

T.R.L.R. FORM 4D
[See rule 37 (3)]
NOTICE
Whereas all objections filed under rule 37 (1) of the Tripura Land Revenue and Land
Reforms Rules, 1961 have been finally disposed of and all orders thereof have been
incorporated in the table or profits of agriculture and Value of land relating to the
unit………………….comprising the Village(s) mentioned I schedule below, the said table as
modified,
if
any,
placed
under
final
publication
with
effect
from………………………………….and it shall opened to public inspection
at……………….. ………………….for a period of fifteen days from the date of final
publication of the table.

Date……………………….
Place……………………….

Collector/Revenue Officer
SCHEDULE

Name and No of unit

Name(s) of Village(s)

Revenue Circle and
Sub-Division

<!-- page 64 -->

T.R.L.R Form 5
(See rule 43)
SubThana Name, No.
Division
and area of
assessment
unit

1

2

3

Name
of
village
within
the
unit
4

Proposed revenue rate per acre for different classes Rem
of land within the unit
arks
Class For
For
Sites for For any
of
purposes
industrial
dwelling other
land of
or
houses
purpose
agriculture commercial
purposes
5(a)
5(b)
5©
5(d)
5(e)
6

<!-- page 65 -->

T.R.L.R Form 6

(See rule 45)

Whereas the table of revenue rates relating to the assessment
unit…………………………comprising the village mentioned in the schedule below has
been prepared in accordance with sub-section (1) of section 33, the same shall be open to
public inspection at…………………………………………………………for a period of
thirty days from the date of publication of this notice. Objection if any to any entry in the
table of revenue rates may be field before the undersigned within the aforesaid period.

Date……………..

Survey and Settlement Officer
Assistant Survey and Settlement Officer
Government of Tripura

SCHEDULE

Name of number of the
Assessment unit

Name of Village

Thana

<!-- page 66 -->

T.R.L.R. FORM—7
(See Rule 53(1))
KHATIAN NO.

Mouja………………………………………….Touzi No………………………………..
Tehsil…………………….Revenue Circle………………………Sub-Division…………….

Of Superior interests
Khatian
No.
1

Determination under section.

Description of interest &
name of possessors.
2

Share of
each
3

Revenue
4

Date from which revenue
will come into force.
5

This interest.
Name etc. of the
Land holder
(in detail)
6

Share

7

Class to which land
holder belongs with
particulars
8

Special condition and
incidents of the
tenancy or holding
9

Sub-ordinate interests.
List of separate khatians of subordinate interests
10

<!-- page 67 -->

Plot Number
Old
11

Present
12

LAND IN DIRECT POSSESSION OF THE INTEREST
North boundary
Remarks
Properties area of this interest within
Class of Land
the plot.
Plot No.
Occupier
Acre.
Dec.
Hectare
Acre
13
14
15
16
17
18

Total Plot………………….

Total area of Land owned
Total area of subordinate interest
Grand Total

<!-- page 68 -->

T.R.L.R. Form 8
(See rule 54)
KHASRA

Mouja…………………………………………………….
Tehsil……………………… Revenue Circle………………….

`Class of
Land

Plot Number

Old
1

Actual
possessor
(in brief)

Present
2

Remarks

8

9

Un-cropped
area

3

LAND IN DIRECT POSSESSION OF THE INTEREST
Khatian in
Total area of
Share of
Proportionate area of plot in khatian
which included
Plot
plot in
each
khatian
Acre
Dec.
Acre.
Dec.
4
5
6
7

Plot
No.

Bhadai crop

Winter crop

10

Name
of
crop
11

Name
of
crop
13

Area
A D
12

Cropped ares
Rabi crop
Other cropped
area

Area
A D

Name
of crop

Area
A D

14

15

16

Method of irrigation and what plot
Source, method & plot No.

Description of
Land

Area
A D

21

22

Sub-Division………..

Area
A D

23

24

Name
of
crop
17

Area
A D
18

Double
cropped
area

Triple
cropped
area

A

A

D

19

Use of fertilizer
Name of
Area
A D
fertilizer

25

26

D

20

<!-- page 69 -->

T.R.L.R. Form 8A
(See rule 71A)
Village…………….

Tehsil………………

Revenue Circle…………….

Sub-Division………..

District………………..

Plot No.

Northern boundary
Plot No

1

Total of the plot Name of parentage of
actual possessor
Hec.
Are.
with status &
share

7

Khatian in
which
included

3

4

Occupier
2

6

Class of
land

Condition of possession
and date from which
possessed

8

Name and status
of the recorded
person
5

Name of Head of
the family or possessor, relation with
he actual possessor
and number of
family members

9

Remark

10

<!-- page 70 -->

“T.R.LR. FORM 9
[See rules 57 and 71A (2)]
NOTICE
No………………

Dated, the……………….

Whereas the work relating to…………. In connection with survey and settlement
Preparation of field index (khasra)
Shall be taken up in the village mentioned in the schedule below from the……………………
day of …………19……………………………all holders of land are informed that they shall
either personally or through their duly authorized agents attend the fields for showing the
boundaries of the village and of their own land. They shall also furnish all such
information’s supported by relevant documents and other evidences as may be required in
this connection failing which according to law may be takes against them.

SCHEDULE
………………….
……………………
…………………..
REVENUE OFICER”
T.R.L.R FORM 10
[See rule 63(1)]

NOTICE
No………………
Pargana………………
Thana……………………

Date………………………
Sub-Division……………………
Village………………………

To
All land holders
Whereas the work of local explanation (Field Bujharat) of the preliminary record of right
which have been prepared after survey of the aforesaid village in pursuance of orders issued
under Section 26 of the Tripura Land Revenue and Land Reforms Act, 1960, will commence
on the………………………day of………………19………………..and whereas
it is
considered that your presence on the field in connection herewith would be necessary on the
above mentioned date or any subsequent date that may be fixed and notified later, a notice is
hereby given for your information that you should remain present yourself o the field
personally or through a duly authorized agent in connection with the aforesaid work and be
ready to furnish necessary information’s relating to the lands in which you may have right,
or title or over which you may have possession, otherwise action may taken in your absence
in accordance with the provisions of law.
Signature and full designation
Of the revenue officer.

<!-- page 71 -->

T.R.L.R. FORM 11
[See rule 63(2)]
Book No……………………………………..
Serial No…………………..
RECEIPT FOR THE PRICE OF PARCHAS
Year—19
Village……………………. Tehail………………. Division………………….
1. Khatian No………………………..
2. Name and address of the person recorded
in the Khatian.
3. Amount realized for Parcha (s)
Signature and designation of the officer
Realizing the price of Parchas
Date……………………
Received the above mentioned Parcha(s)
And also the receipt in connection there of
Signature of the receipient.
T.R.L.R. FORM 12
[See rule 63 (4)]
NOTICE
(Under Rule 63(4) of the Tripura Land Revenue and Land Reforms Rules, 1961)
No……………….

Dated the……………………..

Whereas the date of summary disposal of the under mentioned disputes filed in Mouja………
……………………….J.L. No…………………………..P.S………………………… has
been fixed on………………………………day the………………………….of……………..
….19…………notice is hereby given to the parties mentioned hereunder to be present at……
…………(Place) at……………………….(time) on the appointed date together with
witnessed and other documentary evidences in support of their claim. If they fail to turn up
accordingly, the disputes will be decided expert I their absence.
Sl. No. of Name, father’s
Name, father’s Subject matter
Dispute
name and address name and
of dispute, in
of the party filing address of the brief
the dispute
opposite party

Acknowledgement
receipt of notice
by the parties

Signature and full designation
Of the revenue officer
Government of Tripura

Service return
of the process
server

<!-- page 72 -->

T.R.LR FORM 13
[See rule 63 (5)]
Bujharat Certificate of Revenue Office
Name of Mouja …………

Sub-Division……………………………………….

J.L.No………………………………………………….Thana…………………………………
I hereby certify that I nave completed the bujharat of the above mouja according to
the rules. I have initialed all corrections brought to my notice and I nave prepared all
Khatians in the presence or landholder, tenant, raiyat, under raiyats and occupants. Further, I
have examined o the spot the survey and measurement of each plot correcting every mistake
which I was able to find in the map to the best of may knowledge the map of the above mouja
is now without mistake and flawless. All barat entries (i.e. reference entries relating to
holdings party lying in one village and party in another) have been written up after reference
to the record of the village where rent or revenue is recorded.
Signature and full designation
Of revenue Officer
Date

Halka

Circle

I have satisfied myself that the area of each plot has been correctly entered in the
Khasra and that the area I the khatian has been correctly totaled and the total area of the
mouja as given in the Khatians and khasra is the same in all and in
…………………………….………………..address.
Signature and full designation
of the Revenue Officer
Date
Circle
T.R.L.R.FORM 14
[See rule 64 (1)]
Proclamation for Attestation
Sub-Division

……………………………………….Thana………………………………..

Mouja……………………………………J.L.No…………………………………………..
To
All land holders and other interested persons.
This is to give notice that in exercise of the powers conferred on him by the Tripura
Land Revenue and Land Reforms Act. 1960, and the rules framed under the Act, a revenue
officer will begin to attest and to complete the record of rights of the said mouja
on……………….. (date) at…………………….(place).
You are therefore, directed to attend to attend at the appointed time and place at any time and
place which may be fixed by a subsequent notice and to bring with you Parchas and other
evidence oral or documentary, whatever you desire to produce. If you fail to attend action
may be taken in your absence in accordance with provisions of the Act and rules framed there
under.
Attestation Camp
Date

Assistant Survey and
Settlement Officer

<!-- page 73 -->

T.R.L.R.FORM 15
[See rule 64(2)]
NOTICE
Sub-Division……………………………………..Thana………………………………
Mouja…………………………………………….J.L. No……………………………….
To
All land holders and interested persons.
Whereas by proclamation under rule 64(1) of the Tripura Land Revenue and Land Reforms
Rules, 1961, you have already been informed of the date and place fixed for attestation, you
are hereby reminded that you should attend with your Parchas and other documents at………
………….(place) on…………………….(date). If you fail to attend attestation shall proceed
in your absence and proceedings may be drown against you in accordance with the provisions
of the Act.
Attestation Camp
Date

Signature and full designation
of the Revenue Officer

“T.R.L.R. FORM 16
[See rules 65(1) and71(4)(a)]
Publication of Draft record of rights/Draft Field Index (Khasra)
District…………………………………..Sub-Division………………………………
Revenue Circle…………………………….Tehsil…………………………………..
Village………………………………….
To
All land holders.
Whereas the attestation/preparation of the record of right/Field Index (Khasra) of the above
mentioned village has been duly completed, it is notified for your information that the said
record of right/Field Index (Khasra) will remain open for public inspection at……………..
(place) from…………………………………..for thirty days and that (date) is the last date f
or filing objection under sub-section (1) of section 43 and section 45A of the Tripura Land
Revenue and Land Reforms Act, 1960.
Signature and full designation of
The Revenue Officer
(Delete the words which are unnecessary)”

<!-- page 74 -->

T.R.L.R. FORM 17
(See rule 65(1) and 71(4)(a) )
Objection under section 43(1) and 45B of the Tripura Land Revenue and Land Reforms
Act,1960.
Village……………………………..
Revenue Circle……………………..
Sub-Division………………………….

Seventy five Paise court-fee
stamp to be affixed here.

1. Name, father’s name and address of objector
2. Name, father’s name and address of objector
person against whose Khatian objection is made
3. Khatian numbers under objection.
4. Plot numbers under objection.
5. Nature of objection e,g. status rent,
revenue, possession etc.
6. Matters objected to with details of
objection and relief sought.
Signature of objector and date
Objection duly received and entered

Objection No………………………………………..
Village name and No………………………………..
Signature and full designation
The Revenue Officer

Order Sheet

Date

Order

Present on behalf of the objector

Signature of the Officer

Present on behalf of the other party

GROUNDS FOR DECISION AND ORDER
ORDER IN BENGALI
Correction in field Index (Khasra/Khatian
under objection according to order
Signature of “tamil, Clerk
In token “tamil, and date

Signature of Peskar
in token of final
Junch and date

Resultant correction in corollary records

Signature of “tamil”
Clerk in token of
“tamil”, and date

Signature of Peskar
in token of final
junch and date.

<!-- page 75 -->

T.R.L.R.FORM 18
[See rule 66(1)]
Notice fixing date for hearing objection under Section 43(1) of the Tripura Land Revenue
and Land Reforms Act, 1960.
Objection No…………………………
Village Name and No…………………………
Thana………………………………………….
District……………………………………….
Objector……………………………………….
Other parties…………………………………
NOTICE
To
……………………………………………………
……………………………………………………
Whereas and objection has been filed under Section 43(1) of the Tripura Land Revenue and
Land Reforms Act, 1960, and………………………………………………….(date) has been
fixed for hearing you are hereby informed that you should be present before the undersigned
your self or through a duly authorized agent with evidence, oral and documentary
at………………………….(place) at………………………………………(time) on the said
date. If you fail to turn up at the appointed time, orders may be passed expert according to
law.
Signature and full designation of the
Revenue Officer
Date………………..19
N.B.—This should be accompanied by a copy of the objection.
T.R.L.R. FORM 19
[See rule 68/71 A (6)]
Notice for the publication of the final record of rights/ Field Index under Sec. 43(2) 45B.
District……………………………..Sub-Division………………………………..
Revenue Circle……………………….Tehsil………………………………..
Village………………………………………
To
All holders of land, raiyat, under raiyats,
Tenants and occupants.
Whereas all objections under Section 43(1)/45A(2) of the Tripura Land Revenue and Land
Reforms Act, 1960, having been finally disposed of and all the orders have been incorporated
in the record of rights. Field Index (Khasra0, the record of rights/field Index (Khasra) of
village mentioned above has been finally framed.
You are hereby informed that the said record will remain open for public inspection at
(place)…………………………..from (date)……………………….to (date)………………..
Signature and full designation of
The Revenue Officer.
Date…………………………
Place………………………….

<!-- page 76 -->

T.R.L.R. FORM 20
[See rule 72]

MUTATION REGISTER

Village……………Tehsil…………………..Thana………….Sub-Division…………………
Sl. Name of the
No. village and
Plot No
(with
Khatian
No.)

1

2

Year and date of
the issue of notice

10

Year and
date of
submission
of
application

Name and
address of
the applicant
and his
father’s
name

Gist of the
report giving
nature of
acquisition

Total
area of
the
holding

3

4

5

6

Year and date of the Sl. No. of register
return of the notice of disputed cases
after service
if any

11

12

Name of
the
recorded
per sons
with their
names,
parentage
and
addresses
7

Description of the amount paid, if
any
Date and year
Amount
of payment

Disposal

Remarks and
signature of the
certifying
officer

8

Year and
date of
sanction or
refusal

Abstract
order (Short
description
of particulars

Date of the
correction of
records

13

14

15

9

16

<!-- page 77 -->

(a) after the existing form 20, the following
new form shall be inserted, namely:T.R.L.R Form 20A
Register of Bargadar
Name of Village……………Tehsil…………Circle……………Sub-Division………………

Sl.No.

Name, parentage and
Address of the
Applicant Bargadar

1.

Area

2

Date from which the
Applicant is cultivating
The land

6

Date of disposal
of the objection

11

7

Order in brief

12

Name, parentage and
address of the
recorded raiyats

Khatian
No.

Plot No.

3

4

5

Conditions
if any

Date of service of
notice o the raiyat

Date of filing
objection, if any

8

9

10

Date of correction of
record of rights

13

Initial of the competent
authority

14

<!-- page 78 -->

T.R.L.R. FORM 21
[See rule 74(1)]
Report for Mutation
1. Name of the Village and No………………………………….2. Tehsil……………………………………
3.Serial No.
4. Date of report
5. Name of applicant
6. (a) Names of recorded persons with their
father’s names and dresses in whose
place mutation is sought
(b) Khatian No.
and class
7. Manner of acquisition with consideration
paid, if any, date
8. Date of sending the report to the Revenue
Officer
9. Date of entry in the mutation register by
Village Accountant
10. Date of sanction or refusal
11. Abstract order
12. Date if correction in record of rights
13. Signature with date of the officer verification the correction

COUNTER-FOIL
Receipt for application for mutation
Serial No

Name and no. of the Village

Received the marginally noted request
For mutation from Shri……………….
………………………………………..
of Village……………………………….
on………………………………………
Signature of the Village accountant
with date

(b) after the existing from 21, the flowing
new shall be inserted, namely:-

T.R.L.R. FORM 21A
Report of Bargadar
Name of Mouja…………………………………………Tehsil………………………………
Circle……………………………………………………Sub-Division……………………….
1. Sl. No. :2. Name, parentage and address of the claimant :3. Name, parentage and address of the raiyat
4. Description of land under cultivation as bargadar:Khatian
Plot No.
5.Date from which cultivating:6. Conditions, if any:-

Area

Signature of the claimant.

CONTER-FOIL
Sl. No…………………………………………..
Received the marginally noted report from
Shri………………………………………………..
S/O………………………………………………..
of Village…………………………………………
Village Accountant
By order of the Governor,”

<!-- page 79 -->

T.R.L.R. FORM 22
[See rule 77]
Register of disputed cases

Village…………J.L. No.......…Tehsil…………Thana……………Sub-Division…..............19
Serial No.
of dispute

1

Serial
No. in
the
mutation
register
2

Plot No.

Area
entered in
the record
of right

Date of
receipt of
objection

Name of
disputing
parties

Nature and
particulars
of dispute

3

4

5

6

7

Order passes
with date and
signature of the
officer passing
the order
8

<!-- page 80 -->

T.R.L.R. FORM 23
(See rule 78)
Received from……………………………………………………………….objection
under Section 46(4) of the Tripura Land Revenue and Land Reforms Act, 1960, specified
below regarding the acquisition of right over land situated in village……………………….
……………………………….J.L. No…………………………………………Tehsil………..
…………………..Thana……………………………………………………………………
Details of objection……………………………………………………..
Village Accountant
Village……………………
Tehsil…………………….
Thana…………………….

Date:

(or any other receiving official)
T.R.L.R. FORM 24
[See rule 89(1)]
Notice of demand under section 62 of the Tripura Revenue and Land
Reforms Act, 1960.
In the Court of…………………………………………………………….
………………………………………………………………………………………………..
To………………………………………….S/O……………………………………………..
Resident of village……………………………………Tehsil……………………………….
Thana………………………………………..Sub-Division………………………………….
You are hereby required to take notice that a sum of Rs………………………is due from
you on account of arrears of land revenue, and other dues realizable as land revenue, as per
details given below and that unless it is paid within……………………………..days from the
receipt of this notice further proceedings for the recovery of the dues shall be taken against
you according to law:Village with Plot No. with Amount of Year for
J.L.No.
Khatian No. arrears.
Which due.
1
2
3
4

Date………………….19
(Seal)

Interest
5

Process
fee
6

Total amount due
7

Circle Officer. Sub-Division Officer/
Collector.
