---
doc_id: "e6a13eeed99d16fc"
source_url: "https://jica.tripura.gov.in/media/tenders/Tender_short_video_films_on_different_topics_of_Tripura_JICA_Project_under_Sepahijala_Forest_District.pdf"
ministry: "Tripura JICA Project - Sustainable Catchment Forest Management (SCATFORM), Tripura"
title: "View / Download"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b3fea0ae12fa7d8a"
---

<!-- page 1 -->

F.11-42/Tender/SCATFORM/DMU-Sep/

I/1668847/2026

Government of Tripura
Forest Department

District Management Unit, Tripura JICA Project
(Project for Sustainable Catchment Forest Management in Tripura)

Sepahijala Tripura- 799102
E-mail: districtforestsepahijala@gmail.com ,
Dated: as per the e-sign

Short Notice Inviting Tender
Quotations in sealed cover are invited by the undersigned from the resourceful agencies for
providing “HD Audio visuals – short video films on different topics of Tripura JICA Project under
Sepahijala Forest District”. The technical bid and financial bid should be given in separate sealed envelopes
and the bidder will be disqualified if the technical bid and financial bid are not provided in separate sealed
envelopes. The financial bid shall be opened only for those bidders who satisfy the technical bid which will
be evaluated as per the eligibility criteria mentioned in the tender document.
The detailed terms and conditions with eligibility and list of topics shall also be available in DMU
Notice board and interested bidders may collect the documents from the DMU (DFO)-Sepahijala office. The
same can also be downloaded from the website jica.tripura.gov.in / forest.tripura.gov.in .
Quotation may be dropped in tender box kept at - District Management Unit (DFO), Sepahijala
Tripura, up to 3.00 p.m. on dated 05/11/2026. The authority will open the quotations at 4.00 p.m. on the
same date, if possible, in the presence of the bidder’s representatives who choose to be present at the
office of the District Management Unit (DFO), Sepahijala Tripura. The successful bidder will be considered
for issuing work order for making of the video films.
Enclo:- Details tender document.

Sd/(Jaymalya Bhattacharjee, IFS)
District Forest Officer (DMU Chief)
Sepahijala Tripura

Copy to:1. PS to the PCCF & HoFF (Tripura), for kind information of PCCF & HoFF (Tripura).
2. PS to the CEO & Project Director- Tripura JICA Project (SCATFORM), Hatipara, Gandhigram. With a
request for necessary arrangement to upload into JICA Tripura official website (jica.tripura.gov.in).
3. The DCF(IT), O/o the P.C.C.F, Tripura, Agartala for information, with a request to arrange display of
the detailed Tender Notice on the website of Forest Department (forest.tripura.gov.in). Detailed
Tender Notice is attached herewith.
4. The Director ICAT Department Gandhighat, Agartaia for kind information & with a request for wide
publicity in 3 nos. local daily newspaper. Abstract is attached herewith.
5. The Sub-divisional Forest officer Bishalgarh / Sonamura for information.
6. Office Notice Board, DFO- Sepahijala Tripura.

Page 1 of 10

District Forest Officer (DMU Chief)
Sepahijala Tripura

<!-- page 2 -->

F.11-42/Tender/SCATFORM/DMU-Sep/

I/1668847/2026

Tender documents for Providing HD audio visuals of different topics of Tripura JICA
Project (SCATFORM)
District Forest Officer-Sepahijala Tripura is floating a short notice inviting tender for providing “HD
audio visual - on the different topics of Tripura JICA Project” from resourceful agencies (herein after
refereed as “Vendor”). List of the topics with category and duration is listed in Annexure - I.
The technical bid and financial bid should be given in separate sealed envelopes and the Bidder will
be disqualified if the technical bid and financial bid are not provided in separate sealed envelopes. The
financial bid shall be opened only for those bidders who satisfy the technical bid which will be evaluated as
per the eligibility criteria mentioned in the tender document.
Quotation may be dropped in tender box kept at – O/o the District Management Unit (DFO),
Sepahijala Tripura up to 3.00 p.m. on dated 05/11/2026. The authority will open the quotations at 4.00
p.m. on the same date, if possible, in the presence of the bidder’s representatives who choose to be
present at the office of the District Forest Officer-Sepahijala Tripura. The successful bidder will be issued
work order for making of the HD audio visual coverage.

A.
i.

Eligibility Criteria
Essential

1. The bidder shall be reputed film production houses/film makers/firm/organization/documentary
film makers (herein after referred as “Vendor”) with a minimum of three years’ experience in providing
Videography coverage for relevant Projects/outdoor & indoor videography, exhibitions and
conferences/events etc. The firm shall enclose relevant documents for providing its Eligibility along with the
Annexure-II (technical Bid).
2. The vendor should have GST registration certificate.
3. Self-attested photocopies of the Registration Certificate/Trade License, other relevant document of
the vendor valid up to date duly issued by competent authorities has to be enclosed.
4. The vendor should have relevant field experience in providing videography and use of drone.
5. Vendor should submit sample videos and similar works done (in DVD/Drive) earlier for assessing
the quality of work.
6. Vendor should have dedicated video lenses (like 25mm to 85mm and wide angle).
7. Vendor should have a high-quality Drone camera
8. Vendor having the qualification/experience in Video editing & animation domain.
ii.

Desirable
1. Awards; State Level/National Level certificates of excellence received, if any.
2. Vendor having 4K videography with professionally trained cinematographers.

B. Terms and Conditions
1. The vendor should have competent and renowned video editor & animator.
2. The visual should be Minimum Full HD 1080p (30 FPS) quality.
Page 2 of 10

<!-- page 3 -->

F.11-42/Tender/SCATFORM/DMU-Sep/

I/1668847/2026

3. Areas (within the District- Sepahijala Tripura) that are to be covered during visual shoot will be
mentioned later on.
4. Vehicular arrangements have to be made by the vendor, after issue of work order.
5. The work has to be completed within 20 days and original DVDs/Drives (2 copies) have to be
submitted.
6. The quotations have to be submitted as Annexure-III (financial bid).
7. Pre- production should include:
a. Concept Designing.
b. 05 Raw Minutes clip for each Location
c. Research and Development.
d. Story Boarding.
e. Scripting.
f. Kokborok assistance in scripting.
g. Voice testing
h. Final voice recording in studio.
i. Final assembling.
8. Production should include:
a. Final research and development.
b. Direction.
c. Camera (with desired lenses) for visual shooting.
d. Camera accessories (trolley, jimmy jib, dolly, monopod, rolling tripped) where applicable.
e. Audio setup (mic, lepal mic, boom mic, boom mic stand).
f. Light setup (4 LED 100 watts, 2 keno flows and LED punch).
g. At least 03 crew members.
9. Post- production should include:
a. Editing in Premier Pro.
b. Visual effects.
c. Clips with Audio Input
d. Raw Clips
e. Frame 16: 9.
f. 3D/ 2D Animation if necessary.
g. Output in minimum Full HD 1080p.
h. Color correction.
i. Subtitling in English (mandatory).
j. Background scoring.
k. SFX.
10. Rates have to be submitted separately for basic cost, GST and any other applicable taxes in
prescribed format.
11. The firm has to submit TIN/ PAN and other registration papers.
12. Applicable taxes will be deducted as per rules.
Page 3 of 10

<!-- page 4 -->

F.11-42/Tender/SCATFORM/DMU-Sep/

I/1668847/2026

13. Previous alike work experience (minimum 1 similar projects) shall be submitted while submitting
quotation.
14. The vendor will have to submit, refundable earnest money deposit (E.M.D) of Rs. 10,000 /(Rupees Ten Thousand Only) in the form of a Bank draft/DD/Pay order of Scheduled Commercial
Bank drawn in favor of District Forest Officer- Sepahijala, Tripura. The DD should be kept separate
envelop mentioned EMD for HD audio visuals. The envelope would be submitted along with
technical and financial bids. Without EMD, bids will not be accepted.
15. The vendor shall not sublet whole or part of the work to any other agency, in case of award of
contract.
16. The vendor shall provide the video, in accordance with the contract to the complete satisfaction of
the concerned authority.
17. Vendors are advised to understand the magnitude of the job involved before submitting the bids.
18. In case of default on the part of the vendor in carrying out any order, apart from the legal remedy,
the authority shall be entitled to get the work done by any other persons and all expenses
consequent thereon or incidental thereto shall be borne by the vendor and will be deducted by the
concerned authority from any money due or it may become due to the vendor.
19. The decision of the District Forest Officer- Sepahijala, Tripura in the matter arising out of this
contract shall be final and binding in regard to all matters relating to the contract.
20. Canvassing in any form by the vendor directly or by any other agency/person on their behalf may
lead to disqualification of their bid.
21. Falsification/ suppression of information shall lead to the disqualification of the vendor.
22. All cases/ proceedings relating to any dispute or claim arising out of any cases of performance of
this contract shall be falling in appropriate court having jurisdiction in Sepahijala, Tripura.
23. In the event of the vendor committing breach of any of the above terms and conditions or the
services of the vendor being found to be unsatisfactory, the contract can be terminated by the
District Forest Officer- Sepahijala even before the expiry of the period of agreement by giving 5
day’s notice of the vendor. Even otherwise, the District Forest Officer- Sepahijala will have the
right to terminate the engagement of vendor by giving 10 day’s notice.
24. The agency needs to be under the control of official designated for the purpose authorized by the
District Forest Officer- Sepahijala.
25. Any financial expenditure or loss on account of any accidents during the service period will be the
sole responsibility of the successful bidder.
26. The District Forest Officer- Sepahijala shall have a right to issue addendum tendered documents to
clarify, amend modify supplement or delete any of the condition, clause or items stated therein.
Each addendum shall from a part of the original invitation to tender.
27. The undersigned reserves the right to accept or reject any quotation including the lowest one
without assigning any reasons.
28. The District Forest Officer- Sepahijala reserves the right to accept or reject bid or cancel without
assigning any reason thereof. No claim or complaint in this regard will be entertained by the
concerned authority.
29. The District Forest Officer- Sepahijala is under no obligation to accept the lowest or any tender
received in response to this tender notice.
Page 4 of 10

<!-- page 5 -->

F.11-42/Tender/SCATFORM/DMU-Sep/

I/1668847/2026

30. Technical and Financial bids should be signed on all the pages by the Authorized signatory along
with seal of the vendor.
31. In the event of the vendor committing a breach of the contract the Authority is entitled to receive
from the vendor compensation to the extent of loss incurred as determined by the District Forest
Officer- Sepahijala.
32. The sealed quotation may be dropped by hand in the tender box kept at – O/o the District
Management Unit (DFO), Sepahijala Tripura or may be sent by registered post so as to reach this
office within due date and time. No sealed quotation shall be entertained after due date and time
and the delay on any account shall not be condoned.
33. The sealed quotation must contain the name, address and contact number of the bidder.
34. In case of any doubt regarding contents and meaning thereof of the tender document, the bidder
may contact O/o the District Forest Officer- Sepahijala Tripura -799102 for clarification of such
doubt on or before 02/11/2026 at 11:00 AM to 12:00 PM (on working days) in O/o the District
Forest Officer- Sepahijala prior to submitting the sealed quotation.
35. Jurisdiction: The enforcement of the terms of the contract as well as all the transactions entered
into by the firms/ companies with the District Forest Officer- Sepahijala shall be deemed to have
been taken place within the jurisdiction of Agartala High Court and any cause of action arising to
the due performance or breach of contract by either of the parties hitherto shall be deemed to
have arisen within the jurisdiction of Agartala notwithstanding the residence or place of business
of the contractor.
36. ARBITRATION: Notwithstanding anything contained in any document under this contract, all
disputes and claims whatsoever, arising out of this contract between the parties shall be referred to
a sole arbitrator who shall be nominated and appointed by the District Forest Officer- Sepahijala
and the Arbitrator’s decision shall be final and binding. The place of Arbitration will be Sepahijala
and venue will be the Office of the District Forest Officer- Sepahijala Tripura.

Page 5 of 10

<!-- page 6 -->

F.11-42/Tender/SCATFORM/DMU-Sep/

I/1668847/2026

C. How to Apply
Application of agencies/bidder that fulfills the all criteria only would be considered by the District
Forest Officer- Sepahijala. Mere accepting the application by the organizers would not guarantee the
award of contract.
The application in sealed envelope super scribing “Bids for HD Audio Visuals for different topics of
Tripura JICA Project under Sepahijala DMU“ along with the copies of the relevant certificates and other
specified documents may be dropped in tender box kept at - District Management Unit, Tripura JICA Project
or may please be forwarded to the following address on or before the last date mentioned in the tender
document:
The District Forest Officer (DMU Chief)- Sepahijala,
District Management Unit,
Near Sepahijala Wild-life Sanctuary
Sepahijala Tripura- 799102

Jaymalya Bhattacharjee, IFS
District Forest Officer (DMU Chief)
Sepahijala Tripura

Page 6 of 10

<!-- page 7 -->

F.11-42/Tender/SCATFORM/DMU-Sep/

I/1668847/2026

Annexure -I

List of topics/visuals to be prepared

List of topics/visual to be prepared – Category – A
sl no
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26

Topic
Visit to a degraded patch of forest
Silted river bed stretch
Field Data Collection by LC/CO
Interview of DFO, SDFO and Range officer on Project activities under Sepahijala
Women carrying water in hills
Souvenir Shop
Mushroom Cluster of Pramodnagar Beat under Charilam RMU
Soft Toy making by kwatal Bodol SHG of Pramodnagar Beat under Charilam RMU
A good Tree Outside Forest plantation with success story
A transact walk with villagers and forest Staff in a degraded forest.
AR bamboo plantation Sanghati JFMC Kathalia Beat under Kathalia RMU
Story of JICA Bamboo Plantation Eradicating Cannabis Prone area under Bishalgarh SDMU
Interview with JFM beneficiaries
A pig farm - Surja SHG of Chandul Kami JFMC under Melaghar
Goat Rearing – Chiniyeakpai SHG, Chandul JFMC under Melaghar
A fish catching by net scene, release of fish fingering in a nice check dam
M-III Check Dam – Chandul Kami JFMC under Melaghar
M-II Check Dam – Chandul Kami JFMC under Melaghar
M-II Check Dam – Sanghati JFMC under Kathalia
M-I Check Dam – Agargami JFMC
A Brushwood Check Dam
SHG Success story of - Sabuj Sathi SHG and Baisaki SHG under Boxanagar RMU
A nursery (Manure mixing, polybag filling, pricking, sowing, green shade house)
Bamboo Jewellery & Mushroom
Hon’ble Forest Minister's byte (if required)
Implementation of FIGS and Achieving 1st Position among Districts

Signature of the Bidder

Page 7 of 10

Duratio
n
30 sec
30 sec
30 sec
2 min
30 sec
1 min
1 min
1 min
1 min
30 sec
2 min
1 Min
2 min
1 min
1 Min
30 sec

2 min

1 min
1 min
30 sec
30 sec

Signature of the DFO Sepahijala

<!-- page 8 -->

F.11-42/Tender/SCATFORM/DMU-Sep/

I/1668847/2026

Instruction:
1. The HD audio visuals of category –A of 2 minute, may have 10 -30 sec of drone videography with
background music/vocal artist (where as is required).
2. From category –A, assorted clips may be edited and together with narratives prepared by the
authority, and with fusion music can be made into HD audio visuals final clips of 1-2 minutes
section wise, and 5-8 minutes duration to cover whole video.

Signature of the Bidder

Page 8 of 10

Signature of the DFO Sepahijala

<!-- page 9 -->

F.11-42/Tender/SCATFORM/DMU-Sep/

I/1668847/2026

Annexure – II
Technical Bid

Details to be filled in by the
vendor

sl no

Particulars

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18

Name
Registered Office
Contact Person
Address
Phone/Mobile
Email
Year of Incorporation (if)
Trade Licence*
PAN CARD*
GST REGN *
Tax Clearance Certificate
Company Registration Certificate* (if registered)
Experience with Govt/PSU/Private Project details in no’s *
Awards/QC Certifications
Camera with specifications/Dedicated video lenses
Drone camera with a specification
Vfx certificates and animation domain
Sample video done before (Copy to be attached with DVD/Drive)
EMD of Rs. 10,000.00/= submitted

Yes/No
Yes/No
Yes/No
Yes/No

Yes/No
Yes/No
Yes/No

* Copies to be attached

Signature of the Bidder

Signature of the DFO Sepahijala

Annexure III

Page 9 of 10

<!-- page 10 -->

F.11-42/Tender/SCATFORM/DMU-Sep/

Sl
n
o

1
a
b
c
d
e
f
g
h
i
2
a
b
c

I/1668847/2026

Financial Bid for HD audio visuals
Phases for 26 no category-A HD audio-visuals
Quoted Amount in Rs. (Should
be quoted against all the
topics
inclusive
of
transportation cost, fooding &
accommodation.
Excluding
applicable GST/other tax.)
Pre- production should include:
Concept Designing.
05 Minute’s Raw clips for each Location
Research and Development.
Story Boarding.
Scripting.
Kokborok assistance in scripting.
Voice testing
Final voice recording in studio.
Final assembling.
Production should include:
Final research and development.
Direction.
Camera (with desired lenses) for visual shooting.

d Camera accessories (trolley, jimmy jib, dolly,
monopod, rolling tripped) where applicable.
e Audio setup (mic, lepal mic, boom mic, boom mic
stand).
f Light setup (4 LED 100 watts, 2 keno flows and LED
punch).
g At least 03 crew members.
3 Post- production should include:
a Editing in Premier Pro.
b Visual effects.
c Clips with Audio Input
d Raw Clips
e Frame 16: 9.
f 3D/ 2D Animation if necessary.
g Output in minimum Full HD 1080p.
h Color correction.
i Subtitling in English (mandatory).
j Background scoring.
k SFX.
Total quoted rate Rs.
Total Accumulated quoted rate for Category A (All items) Rs.
(Rupees

Signature of the Bidder
Page 10 of 10

Quoted
applicable
GST/other
tax.

Rs
)

Signature of the DFO Sepahijala
