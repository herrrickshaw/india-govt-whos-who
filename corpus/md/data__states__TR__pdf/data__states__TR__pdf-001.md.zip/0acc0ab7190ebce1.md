---
doc_id: "0acc0ab7190ebce1"
source_url: "https://ttaadc.gov.in/sites/default/files/rules_2006.pdf"
ministry: "Tripura Tribal Areas Autonomous District Council (TTAADC), Tripura"
title: "TTAADC Village Committee (Administration) Rules, 2006"
date: ""
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c8880ed453f984b7"
---

<!-- page 1 -->

TRIPURA TRIBAL AREAS
AUTONOMOUS DISTRICT VILLAGE COMMITTEE
(Administration) Rules, 2006.

TRIPURA TRIBAL AREAS AUTONOMOUS DISTRICT COUNCIL
KHUMULWNG : WEST TRIPURA.
’

<!-- page 2 -->

Published in the
EXTRAORDINARY ISSUE OF TRIPURA GAZETTE

Agartala, Saturday, January 21, 2006, A.D.
TRIPURA TRIBAL AREAS AUTONOMOUS DISTRICT COUNCIL,
OFFICE OF THE CHIEF EXECUTIVE OFFICER
4
KHUMULWNG : WEST TRIPURA.
No.F.40/ADC/DEVNC/O5lP_-I

I” '

Dated, the 21 st January, 2006.

NOTIFICATION

ln exercise of the power conferred by Section 40 of the Tripura Tribal Areas
Autonomous District (Establishment of Village Committee) Act 1994, the Executive

Committee hereby makes the following Rules.
G. Debnath
Principal Officer (Law)

T.T.A.A.D.C.
CHAPTER - 1
PRELIMINARY
Short title and commencement :
1. (1) These rules may be called the Tripura Tribal Areas Autonomous District Village
Committee (Administration) Rules, 2006.
(2) They shall come into force on the date of publication in the Tripura Gazette.
Deﬁnition and interpretation:
2. (1). ln these rules, unless the context othewvise- requires 1-

(a)

I

Act means the Tripura Tribal Areas Autonomous District (Establishment of
Village Committee) Act 1994.

(b)

Section means the Section of Act.

i

(c)
Form means a Form appended to these rules and includes a translation
thereof in Bengali.

(d)

“Village Sansad” means a body consisting of persons registered in the
electoral rolls relating to the area comprised within the Village Sansad area
as may be constituted by the Village Committee.

<!-- page 3 -->

(e)
(2).
(3).

2
“Village Sabha" means a body consisting of persons registered in the Electoral
Rolls relating to the area comprised within the area of the Village Committee.
The words expressions used but not defined in these rules shall have the meanings
respectively assigned to them in the Act.
The General Clauses Act, 1966 shall apply for the interpretation of these rules as it

applies for the interpretation of Acts.
PART - A
CHAPTER - II
CHAIRMAN I VICE-CHAIRMAN

Leave of Chairman and Vice-Chairman :3(1)

AVillage Committee by a resolution at a meeting may grant leave of absence from

time to time to its Chairman or Vice-Chairman for a total period not exceeding forty-ﬁve
days in a caiendar year. The Secretary of the Wlage Committee shall forthwith report sanction
of such leave to the Zonal Development Officer. Generally Chairman and Vice-Chairman
before proceeding on leave shall request for such leave. However in unavoidable
circumstances, the Chairman or, as the case may be, the Vice-Chairman may proceed on
leave without sanction but after handing over the charge and Village Committee regularise
the leave in its next meeting.
Provided that if the total leave period in the year exceeds forty-five days, no
honorarium and fixed T.A shall be paid for the period exceeding forty-five days. Provided

further that if the Chairman and Woe-Chairman hold charge or is expected to hold charge
for part of the year only, the maximum leave period of forty-five days shall be proportionately

reduced.

.

(2).
Whenever Chairman or, as the case may be, Vice-Chairman proceeds on leave
with or without prior grant of leave he shall invariably harid over charge to Chairman or
Vice Chairman as the case may be in Form -1.
(3).
lf the Chairman or \ﬁce Chairman remains absent from duties for more than three
months continuously without intimation, such absence shall be a good ground for a motion
for their removal.
(4).
lf both Chairman and Vice-Chairman proceed on leave simultaneously for period
exceeding fifteen days or in case temporary vacancy arises in offices of both Chairman and
Vice-Chairman simultaneously for a period exceeding fifteen days, the Secretary with a
prior approval of Zonal Development Officer shall call an emergency meeting of Village
Committee and for this meeting the members present shall select a Presiding Member from
amongst them. ln the said meeting the Village Committee shall take a resolution suggesting

the name of member who may act as temporary Chairman and temporary Vice-Chairman.
The Zonal Development Officer, on receipt of this resolution, shall appoint the temporary
Chairman and Vice-Chairman accordingly ;

<!-- page 4 -->

3
CHAPTER-III

Resignation or removal of Chairman or Vice-Chairman
4.(1) The Chairman or Vice-Chairman or a member of a Village Committee may resign
his ofﬁce writing under his hand addressed to the Zonal Development Ofﬁcer and handing
it over in person or by sending it by registered post to the Zonal Development Ofﬁcer. The

Zonal Development Officer may accept the resignation after such enquiry as he may deem
fit and inform the person concerned, the members of the concerned Village Committee and
C.E.O. within ﬁfteen days of such acceptance.
Provided that in case of simultaneous resignation of Chairman and Vice-Chairman,
the Zonal Development-Officer after such preliminaiy enquiry as he may deem ﬂt may
accept the resignation and on acceptance of such resignation, shall appoint a temporary

Chairman and \ﬁce Chairman in the manner as laid down in sub-rule (4) of Rule 3.
(2).

Chairman or Vice-Chairman vacating the office by resignation shall hand over the

charge of his office ordinarily within ten days after racceptance of his resignation provided
for reasons to be recorded in writing the Zonal Development Ofﬁcer, more than ten days.
may be allowed to hand over the charge.
Procedure for removal of Chairman, Vice-Chairman and members :
5.(1)

The Zonal Development Ofﬁcer shall be the prescribed authority for removal of a

member of a Village Committee under section 16 of the Act. He shall exercise this function
only on the basis of receipt of communication in this regard from the concerned Wlage
Committee. The Additional C.E.O. of TTAADC shall be the appellate authority under
sub-section (2) of Section16.
(2)
On receipt of a notice in Form 2 signed by at least one hird of the existing members
of a Village Committee, ZDO shall convene a meeting for removal of a Chairman under
section 17 of the Act. Such notice shall be delivered in person to the ZDO or shall be sent

by Registered Post.
(3)
In case of removal of both Chairman and Vice-Chairman in the same meeting, the
meeting shall presided over by an ofﬁcer authorized by the ZDO.
Provided that in case of removal of Chairman or as the case may be, the ViceChairman the ZDO may appoint can obsen/er for such meeting who shall submit a report in
writing to the ZDO immediately after completion of meeting.
Provided further that in case of removal of Chairman, if the Vice-Chairman remains
absent in the meeting of the Village Committee where quorum is present one of the
members present in the meeting shall be elected by other members present to preside over

the meeting. In case of removal of Vice-Chairman, if the Chairman remains absent in the
meeting where quorum is present, one of the members present in the meeting shall be
elected by other members present to preside over the meeting.

<!-- page 5 -->

4
(4)
At the beginning of the meeting the presiding Officer shall read out to the members
of the Village Committee present in the meeting the notice in Form-2. He shall then allow
the motion for removal to be read and discussed. Such discussions shall terminate before
expiry of one hour from the commencement of the meeting or such further time as may be
extended by the Presiding Officer. Upon the conclusion of the debate or upon expiry of said

period, the motion shall be put to Vote. Vote shall be by show of hands.
Provided that in case of absence of quorum, meeting shall be adjourned and the
adjourned meeting shall be convened in the same manner.
(5)
The Presiding Officer shall declare the result of voting. The motion for removal shall
be deemed to have been carried only when it has been passed by the majority .of the
existing members of Village Committee.
(6)
The Presiding Officer shall forthwith forward the minutes of the meeting to the ZDO.
The Z.D.O will issue the removal order and intimate the same to the Secretary of the Village

Committee and C.E.O.

"

(7)
In case of removal of both Chairman and Vice-Chairman the charges will be taken
over from the Chairman and Vice:-Chairman by the members appointed by the Z.D.O until
the new Chairman or Vice-Chairman is elected and resumes Office.
(8)
If the Chairman or, as the case may be the \ﬁce-Chairman fails or refuse to hand
over the charges, thetransfer of charges shall be effected by taking of possession through

police help all papers and properties by a person authorized by the Z.D.O and appropriate
legal action shall also be initiated against him.
CHAPTER - IV.

Preparation of the list of business:
6.(1) The list of business to be transacted at every meeting of Village Committee except
an adjourned meeting shall be prepared by the Secretary to the Wlage Committee under
instruction of the Chairman. The agenda shall be entered in the book of Agenda to be
maintained for this purpose. The first item of the list of business shall be the conﬁrmation of
minutes of the previous meeting and 2nd item shall be a report on the status on those
resolutions of all previous meeting on which action is yet to be taken. The last item of list of

business shall be to fix the date and time of next meeting.
(2) The Secretary to the Wlage Committee shall arrange delivery of notice to all members
either by post or by messenger or other wise. A copy of the notice shall be displayed on the
notice board of the Village Committee, Ofﬁce.
Notice of meeting to members:
7.(1) There shall be at least one meeting of the Wlage Committee in every month to
transact its business. The meeting shall be summoned by notice in Form 3. The notice shall

accompany a list of business. (2)

Notice to the members for the meeting may be issued by the Secretary under the

instruction of the Chairman at least seven days in advance of the date so appointed for the
meeting.

<!-- page 6 -->

5
Provided that an emergency meeting may be summoned after giving three days
notice to the members.
Attendance Register.

8.(1)

”

The Secretary to the Wlage Committee shall maintain an attendance register of

members and all members shall sign it before the meeting.

(2)
When a meeting of a Village Committee is not held for want of quorum, the Chairman
and the Secretaryjto the Village Committee shall make a note to that effect in the Attendance
Register. Minute Book of the Meeting.
9.

I

As far as practicable minutes of every meeting of a Wlage Committee shall be

entered in a minutes book to be kept for the purpose, which shall be read out before the
meeting is concluded, and the person who presides over the meeting shall sign the minutes.
Resolution pressed for division.
10.( 1) If there is difference of opinions in taking a resolution, it shall be put to vote and the
vote shall be by show of hands. Every such resolution shall be recorded in full in the minute's
book together with the number of members voting for or against the resolution.

(2) All questions at any meeting shall be determined by Majority of votes of the members
present and voting and the presiding member shall be entitled to vote.
Report on the work of Village Committee:
11. Every Village "Committee shall prepare the report of works done by it in the previous
year and work proposed to be done in the next year in such forms may be directed by the
Executive Committee and the report shall be prepared and passed by the Wlage Committee
in the form of resolution before 30th April of eveiy year and shall be submitted to the Z.D.O.

before 15th May of every year.
CHAPTER - V
SECRETARY AND STAFFS OF VILLAGEICOMMITTEE.

Sanction of leave etc. of Village Committee Secretary.

12.(1) Casual leave not exceeding twelve days in a calendar year may be granted to the
Village Committee Secretaries by the Chairman. Casual Leave for a period of seven days
at a time shall not be ordinarily granted.

g

(2)
Eamed Leave, Half Pay Leave, Commyuted Leave, Quarantine Leave and Maternity
Leave shall be granted by the Z.D.O. on the recommendation of the Chairman of the
concerned Village Committee.
_

<!-- page 7 -->

6
Duties of Secretary of Village Committee.
13.(1) Without prejudice to the duties and functions that may be assigned to him by

Chairman, Secretary of the Village Committee shall-a) Be responsible for collection of taxes, rates, duties, tolls and fees levied by the
Wllage Committee ;
b) Prepare the budget in due time ;
c) Be responsible for maintaining the Cash Book and other Books of accounts. He
shall also be responsible for preparing the monthly and quarterly statement of
accounts and placing the same before the Village Committee ;

d) Be responsible for keeping of records of the Village Committee in safe custody;
e) Be responsible for producing records before the Auditors or inspecting officer as
and when directed by the Chairman or any other authority of the T. T. A. A. D. C.

pf) Be responsible for bringing to the notice of the Chairman all important
information’s ;
g) Be responsible for preparation and maintenance of Ordinary Resident Register.

h) The Secretary of a Village Committee shall attend all meetings of the Village
Committee. He shall forward copies of such minutes of meeting to the concerned
officers of various departments as per directions of the Chairman.

(i) Be responsible to bring to the notice of the Chairman all matters relating to the
different schemes and their implementations ;
j)

Be responsible to prepare an Agenda paper as per direction of the Chairman ;

k) Be responsible to issue notice of the meeting as per direction of the Chairman ;
l)

Perform such other duties in respect of the work of Village Committee as the
Chairman the \ﬁce-Chairman may direct.

m) Be responsible for submission of utilization certificate for the fund placed to the
Village Committee after taking approval from the Chairman.
n) Be responsible for submission of bills to the appropriate authority in due time.

o) Be responsible to operate the joint'Bank account of the Wlage Committee. The
Chairman and the Secretary in the name of the \ﬁllage Committee shall open a joint
Bank account. All funds shall be credited to that account.

<!-- page 8 -->

7
CHAPTER - VI
MANNER OF CONDUCTING MEETING OF VILLAGE SABHA.

Annual meeting of Village Sansad

14. (1) The Village Committee shall, identify and constitute such number of Wlage Sansads
within the Wllage Committee area as may be convenient, not being less than three, with a
size of about three hundred voters have regard to the member of constituencies. Immediately
after constitution of Village Sansad the Village Committee shall give intimation in detail to
the ZDO.
(2)
The Village Committee shall hold within the local limits of the Wlage and annual
and halfyearly meeting for each Village Sansad at such place, on such date and at such
hour as may be fixed by it ;

Provided that the annual meeting of the Village Sansad shall be held ordinarily in
the month of April or May and the half-yearly meeting of the Wlage Sansad shall be held
ordinarily in the month of November or December every year.

Provided further that a Village Committee may, in addition to the annual and the
half-yearly meeting, hold extra-ordinary meeting of a Wlage Sansad at any time if the situation
so warrants or if the T.T.A.A.D.C., by otder, so directs.

(3)
The Wllage Committee shall ﬁx up the agenda for each meeting of Village Sansad
to be held on such date so ﬁxed by the \/illage Committee. A written notice duly signed by
the Chairman or, in his absence, by the Vice-Chairman of the Village Committee indicating
the date, time and place of meeting along with agenda shall be issued at least seven days
before the date of meeting. Copy of such notice shall have to be displayed/hung-up at
conspicuous places. Moreover, the Village Committee shall arrange publicity of the date,
time and place along with agenda of the meeting of Village Sansad as widely as possible
within the concerned Village Sansad area.
(4)
Every meeting of the Village Sansad shall be presided by the Chairman or, in his
absence by the Vice-Chairman. In case of absence of both the Chairman and the

Vice-Chairman, one member elected by the \ﬁllage Sansad shall preside overthe meeting.
(5)
One third of the total number of voters of the Wlage Sansad area shall form the
quorum for a meeting of the Village Sansad.
(6)

The Secretary to the Village Committee shall arrange recording of voters in the

attendance sheet in Form-3A.
(7)

The first item of agenda shall be to read over the minutes of the last meeting for

confirmation, the same shall be signed by the Chairman or in his absence by the
Vice-Chairman or in absence of both by the person presiding over the meeting.The second
item shall be report on the status of the resolutions of the previous meeting.Thereafter
discussion of the agenda ﬁxed for the day’s meeting shall be taken up and decision taken
thereon shall be recorded in the minute's book. While arriving at a decision, every voter
shall have the right to ask any question related and relevant to the agenda.

<!-- page 9 -->

8
(8)
In each meeting of the Village Sansad the Village Committee shall distribute a
printed booklet to each voter of the meeting. The printed booklet should contain information
about amount of fund received, the amount of fund spent, the work / project undertaken
with the fund, number and nature of project completed, number of beneﬁciaries selected
and beneﬁt given under different schemes, amount of unspent fund, number of maydays

generated, number and nature of assets created, number of site selected indicating the
name of the scheme and project etc.
(9)
The Village Committee shall place before the Village Sansad in the meeting the
matter relating to selection of beneficiaries of any scheme and selection of site of work of
public utility under any scheme or project pertaining to the Village Sansad area. The Village
Committee shall submit betore the Village Sansad a full report in respect of development
programmes relating to the concerned Village Committee area undertaken in the preceding
year and development programmes proposed to be undertaken during the current year.

Any matter referred to the Village Committee by the TTAADC, for decision of the people of
the Village Committee shall be placed before the meeting of Village Sansad for consultation
and decision.
(10)
The recording of minutes will be done by the Secretary to the Village Committee. lf
for any reason the Secretary to the Village Committee remain absent on the day of meeting
of the \ﬁllage Sansad any other official posted in the Wlage Committee as may be authorized
by the person presiding over the meeting, shall record the minutes of the meeting in the
minutes book. After recording of the minutes, the person presiding over the meeting shall

readout the minutes recorded in the meeting to the persons present in the meeting and
thereafter he shall sign in the minutes Book. The minutes Book shall be kept in Bengali.
(11)
Copy of the minutes of the meeting of the Village Sansad shall be sent to the
concerned Z.D.O.
(12)
Generally efforts should be made to take decision on the agenda by consensus. lf,
however, there is difference of opinion, it shall be put to vote by show of hands. Every such
resolution / decision shall be taken / adopted by simple majority and recorded in full in the
minute's book together with number of person voting for or against the resolution.

(13)

Individual beneﬁciaries under any scheme, receiving payment on any one occasion

in excess of the case equivalent of 20 man days, has to be approved by the Village Sansad.
(14)
The location of all works costing more than the case equivalent of hundred man
days are required to be approved by the Village Sansad.
(15)
The Village Committee shall take necessary steps to implement every resolution
adopted or decision taken in the meeting of the Village Sansad.
15.

Proceeding at the meeting of Village Sabha.

(1)

Every Village Committee shall hold within the local limits of the Village at least one

meeting for the \ﬁllage Sabha in a year at such place on such date and at such hour as may
be fix by the Village Committee having regard to the direction issued by the TT AADC for
the purpose.

<!-- page 10 -->

9
(2)
The Village Committee shall fix up the agenda for the Village Sabha meeting to be
held on such date so ﬁx by the Wlage Committee. The agenda ﬁxed by the Wlage Committee
shall be entered into the book of agenda. After recording in the book of agenda the Secretary
to the Wllage Committee shall put his signature in the page on the right hand side below the
agenda and the Chairman or in his absence the Vice-Chairman shall countersign it in the

page on the left hand side below the agenda. The written notice duly signed by the Chairman
or in his absence by the Woe-Chairman indicating the date, time and place of the meeting
along with agenda shall be issued at least 10 (ten) days before the date of the meeting. A

copy of such notice shall have to be displayed/hung up at conspicuous places. Moreover
the Village Committee shall arrange publicity of the date, time, place and agenda of the
meeting of \ﬁllage Sabha as widely as possible within the concerned Village Committee

area.
(3)
Every meeting of the Village Sabha shall be presided over by the Chairman or, in his
absence, by the Vice-Chairman. In case of absence of both an elected member to the
Village Committee shall be elected by the voters of the Village Sabha to preside over the
meeting.
(4)
One eighth of the total number of voters of the Village shall form the quorum for a
meeting of Village Sabha.

(5)
The Secretary to the Village Committee shall arrange recording of attendance of the
voters in the attendance sheet in Form-3A as soon as the voters enters the place of meeting.
(6)
When a meeting of the Village Sabha could not be held due to want of quorum, the
person presiding and the Secretary shall make a note to that effect under their signature in
the attendance sheet and in the minutes book.
(7)
The first item of agenda shall be “to read over the minutes of the last meeting" for
confirmation of the voters and on conformation ; the person residing over the meeting shall
sign the same. The second item shall be “report on the action taken on the resolution of the
previous meeting". Thereafter discussion on the agenda fixed for the day's meeting shall be
taken up and decision taken thereon shall be recorded in minutes book. While arriving at
decision every voters shall have the right to take part in the discussion relating to the agenda.
(8)
The Village Committee shall take necessary step to implement every resolution
adopted or decision taken in the meeting of the Village Sabha.
(9)

The agenda for the meeting shall include

(a)

Placement of the annual statement of account of the Village Committee, the
report of administration of the preceding financial year and the last audit note
and replies there to ;

(b)

The budget of the Village Committee for the financial year ;

<!-- page 11 -->

(c)

10
Broad report in respect of the development programmes of the Village
Committee undertaken during the preceding year and development programme
proposed to be under taken during the current year. Such report shall be

accompanied by a statement of fund made available during the last ﬁnancial
year and the fund likely to be available during the current financial year;
(d)

Such other business relating to the affairs of the Village Committee may also be
transacted at such meeting of the Village Sabha as may be agreed upon by the
persons present and also such other issues as referred by the T.T.A.A.D.C. from

time to time.
(10)

The Village Sabha shall deliberate upon, recommend for,.and adopt resolution on,

any matter placed before the Village Sabha meeting.
(11) The Secretary in Bengali shall record the minutes of the meeting of the Village
Sabha. lf for any reason the Secretary remains absent on the day of meeting of the Village
Sabha, any other official posted in the Village Committee as may be authorized by the
person presiding overthe meeting, shall record the meeting. After recording of the minutes,
the person presiding over the meeting, shall read out the minutes recorded in the meeting
to the persons present in the meeting and thereafter he shall sign in the minutes Books. No

portion of the minutes so prepared shall be left blank. Copy of the minutes of the meeting of
the Village Sabha shall be sent to concerned Zonal Development Officer.
(12) At the time of taking decision on any matter if difference of opinion arises, the matter
shall be put to vote by show of hands. The decision shall be taken by simple majority of
votes.
16(1) Subject to any rules or any order made by the TTAADC authority time to time in this

behalf there shall be a single Bank account in a Schedule Bank in the name of the Village
Committee which will be operated jointly by the Chairman and the Secretary to that Village
Committee.
(2) All receipts from the authority of the TTAADC or otherwise to the Village Committee
shall be credited to that account and all expenditure shall be made from that account only.
VIGILANCE COMMITTEE.

17.(1) The ZDO shall constitute a Vigilance Committee for the Zone. The Committee shall
consist of not less than three member and not more than ﬁve members and shall hold ofﬁce
for one year from the date of its constitution.
(2) The Committee may consist of both officials and non-ofﬁcials. One of the members
shall be designated as the Chairman of the said Committee.

<!-- page 12 -->

11
(3) The Committee shall submit a quarterly vigilance report to the ZDO. Provided that at

any time ZDO may direct the Committeeto submit a report on all or any speciﬁc aspects of
the functioning of a Village Committee. "
'5 _ . 2
(4) The Chairman of Wlage Committee shall place the report of vigilance committee in
the Vlllage Committee meeting within one month of its receipt for consideration. Wherever
the Village Committee agrees with the findings of the Vigilance Committee, it shall resolve
to take necessary corrective steps. ln case of disagreement with the ﬁndings of the vigilance
committee, detailed reasons for the disagreement shall be recorded.
Thereafter the minutes of the Village Committee shall be forwarded to the ZDO who
shall send it to the District Council for consideration.

G. Debnath
Principal Ofﬁcer (Law)

T.T.A.A.D.C.

<!-- page 13 -->

.

12
.
I
FORM -1
CERTIFICATE OF TRANSFER OF CHARGE.

Certiﬁed that we have in the forenoon /aftemoon of this day of................................ ..
............................ ..respectively handed over and taken over the charges of the ofﬁce of the
.................................... ..of.........................................\ﬁllage Committee.

Signature of the person handing over charge
(Name in Block Letters)
Name of Ofﬁce held...................................... ..
Handing over charge for proceeding on leave I for tendering resignation I having been
removed.
Signature of the person taking over charge.
(Name in Block Letters)
Name of office held...................................... ..

Place: ........................ ..Date......................... ..
Particulars of ﬁnancial charge.
(1)

Cash in hand

Signature of the person
handing over the charge.

(2)

Cash in Bank:

(3)

Security deposit with the
Village Committee.

Signature of the person
taking over the charge.

Copy to:

»

* Score out which is not applicable.

<!-- page 14 -->

13
FORM-2
From of notice for removal of Chairman/Vice-Chairman ............................................... ..
......................................... ..Block.

To

Notice is hereby given that a meeting of....................................................................... ..
.............................................. ..Village Committee may kindly be convened for removal of
Chairman Nice Chairman of the said Village Committee for reasons stated below:

Signature of Members of. ................................. ..

A ............................................ .. Village Committee.
* This notice is delivered to me by Sri ...................................................................... .., ....... ..
........................ ..Memberof..........................Village Committee at my ofﬁce on (date).............
....................................
and signed below before me.

Signature of the Member
delivering the notice.

Signature of Prescribed
Authority.

* Not applicable if sent by Register post.

<!-- page 15 -->

14
FORM-3

FORM OF NOTICE FOR ORDINARY! EMERGENT MEETING OF
VILLAGE COMMITTEE.
Notice is hereby given that to transact the under mentioned business, the next
Ordinary lemergent lspecial meeting of.................................................................... ..Village

Committee will be held at................................. ..(place) on the day of................................ ..
.200.............. ..at.............................. . .A.M.lP.M.
You are requested to make it convenient to attend the said meeting.
List of Business:
1'»
2:)

3)

4)

Secretary,

Village Committee.

*Score Out which is not applicable.

<!-- page 16 -->

15
FORM- 3A
Form of attendance sheet for recording attendance of the voters attended in the
meeting of Village SangsadNillage Sabha.
Name of Village Committee ............................... ..Under............................................. ..B|ock

I Sl. No.

Name of votersIFather’s name and address

1

2

Signature of voters
3

1.

2?
3.
4.
5.
6.

j

7.
8.

9.
L

Signature of Secretary

Person Presiding the Meeting

Village Committee.

of Village Sangsad/Sabha.
