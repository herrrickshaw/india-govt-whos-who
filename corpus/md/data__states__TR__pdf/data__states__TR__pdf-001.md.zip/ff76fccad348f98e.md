---
doc_id: "ff76fccad348f98e"
source_url: "https://ttaadc.gov.in/sites/default/files/ElectionofOfficeBearers2006.pdf"
ministry: "Tripura Tribal Areas Autonomous District Council (TTAADC), Tripura"
title: "TTAADC Village Committee ( Election of Office Bearers) Rules, 2006"
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "df08763c6c42e0b2"
---

<!-- page 1 -->

The Tripura Tribal Areas Autonomous
District Village Committee
(Election of Ofﬁce Bearers) Rules 2006

Khumulwiig : West Tripura

<!-- page 2 -->

Published in the
EXTRAODINARY ISSUE OF TRIPURA GAZETTE

Agaxtala, Saturday, March 4 2006 4.1).
.

TRIPURA TRIBAL AREAS AUTONOMOUS DISTRICT COUNCIL
OFFICE OF THE CHIEF EXECUTIVE OFFICER
KHUMULWNG : WEST TRIPURA.

No.F.40/ADC/VDC/05/P.II/3390

*I

Dated,2"" March,2006.

NOTIFICATION

Thefollowing Rules which have been made by the Executive Committee of the
Tripura Tribal Areas Autonomous District Council are hereby published in the Tripura
Gazette for general information.

(G. Debnath)

\

*

Principla Officer (Law)

‘"

TTAADC, Khumulwng

<!-- page 3 -->

TRIPURA TRIBAL AREAS AUTONOMOUS DISTRICT COUNCIL

In exercise of the powers conferred by sub-section (2) and (3) of section 4
read with section 40 of Tripura Tribal Areas Autonomous District Council (Establishment of Village Committee Act) 1994, Executive Cormnittee here by makes
the following Rules namely:
1. (1) Short title and commencement :
These rules may be called the Tripura Tribal Areas Autonomous District Village Council (Election of ofﬁce Bearers)‘ Rules, 2006.
(2) They shall come into force on and from the date of publication in the
official gazette.
2. (a) Deﬁnition :

.

Act means Tripura Tribal Areas Autonomous District Council
lishment of Village Committee ) Act, 1994. t

(Estab-

(b) "Form" means: Form appended to these rules.
(c) "Section" means: Section of the Act.
3.The expression used in these rules, but not defined, shall have the same
meanings assigned to them respectively in the Act.
4.Tripura General clauses Act, 1996 shall apply for interpretatitv. 1' these
rules as it applies for the interpretation of an Act of the Tripura Tribal \rcus Au-

tonomous District Council.

5. Rotational allotment of reserved seats :
I

Allotment of reserved seats for the post of Chairman of Village Committee
shall be done in the following manner namely:
.
A
2

’

<!-- page 4 -->

(1) Seats shall not be allotted for S.T. or S.C. in the ofﬁce of the Chairman in
a village Committee unless at least one seat has been reserved for Schedule Tribes
or Schedule Caste in that Village Committee as the case may be.
(2) After working out total number of seats of ofﬁces of the Chairman in a
Zone, all the villages shall be arranged in the order of Roman alphabet. Thereafter, all the villages shall be numbered in ascending order. And then reservation in
the ofﬁce of the Chairman shall be made in the following order as far as practicable.
(i) Firstly the required numbered of offices of village committee chairman
shall be allotted against S.C. category in ascending order from the arrangement
done in sub-rule (2) of this rule excluding the villages as has been indicated in

sub-rule (1).
(ii) Secondly the required number of offices of Chairman shall be allotted
against S.T. category in ascending order from the arrangement done in sub—rule
(2) of this rule excluding the ofﬁces already reserved for S.C. category.
(3). In the next general election reservation in the office of the Chairman for S.C
category shall be made from the next available villages in ascending order. Likewise reservation in the ofﬁce of the Chairman shall be made for S.T. category. The
same process of rotation shall continue in succeeding elections.
(4). Allotment of reserved seats for Women in the ofﬁce of the Chairman in
Village Coinmittees shall be done in the following manner: (i) After working out total number of ofﬁces of the Chairman in a Sub-Zone,
all the villages in that Sub-Zone shall be arranged in the order of Roman alphabet.
Thereafter, all the Villages shall be numbered in ascending order.
(ii) Reservation for Women in the ofﬁce of the Chairman shall thereafter be
made in every ﬁrst and then every third seat from the arrangement made in clause
(i) of Sub-Rule (4) of Rule 5. In the second general election the reserved seats for
Women shall rotate by allotting second and then every third seat commencing
from the second seat. Thus, the rotation of seats for Women shall be made by way
of allotting the ﬁrst and then the second seat. Thereafter every third seat shall be
allotted commencing from ﬁrst or as the case may be the second seat.
3

<!-- page 5 -->

Provided that the rotational allotment shall be made only from those Village
Committees which has at least one elected women member.
Provided further that if there is no women member available to that category
for which the ofﬁce of the Chairman is reserved in a village, the reservation for
women shall shift to the next available village in ascending order on exchange
basis to be taken into account for determining reservation in the next general
election.

6. .-\llotment by rotation done in the aforesaid manner shall be final and
binding on all.
7. Notwithstanding anything contained in the foregoing provisions of these
Rules, the Principle of rotation for the purpose of reservation in the ofﬁces of
Chairman's shall commence from the ﬁrst General Election and the roster for reservation by rotation shall continue for three successive terms to complete the full
rotation unless the Executive Committee, for reasons to be recorded in writing,
by notiﬁcation, directs fresh ,,commencement of the rotation at any stage excluding the earlier term or terms? of Elections from the operation of the rotation.

8 Election of Chairman and Vice Chairman:
(l). The Zonal Development Officer of a concerned Zone shall communicate
to the Secretary of a Village Committee, the date and time for convening the ﬁrst
meeting of that Village Committee. For the purpose, the Secretary shall give a
written notice of ﬁrst meeting in Form 1 to all members as far as practicable three
days before such meeting. The Members shall take oath before the meeting and
elect the Chairman and ViceChairman in the meeting. The Secretary to the Village Committeeshall administer oath to the memberswand preside over the meeting.
7
'
.
.
A
(2). Simple majority of the elected members of a Village Cormnittee shall
form the quorum for the ﬁrst meeting. The ﬁrst meeting shall be held after the
members present have taken oath. If there is no quorurnfor the ﬁrst meeting the
I

4

.

<!-- page 6 -->

Secretary shall adjourn the meeting and submit a report to the Zonal Development Officer. The adjourned ﬁrst meeting shall be convened within 10 (ten) days
by the concerned Secretary in the same manner as in the case of first meeting.

(3). The Secretary to the Village Committee shall, after taking of oath is over
and immediately after the commencement of the meeting call upon the members
present to propose the names of the candidates for election of the Chairman of the
Village Committee. One member only shall be required to propose name of a candidate. The Secretary shall record the name of each candidate proposed, name of
his party if any, together with the name of the proposer and name of his party. He
shall reject a proposal: -

I. If the seat is reserved, but the proposal does not conform to reservation
requirement;
_

II. He has ﬁnalized if the proposal has been made after the list of candidates
in Form 2. If the candidate, whose name is proposed, is absent, the proposer shall
submit the consent paper of the candidate to the Secretary in Form-3.

(4). If only one candidate is proposed, the Presiding Ofﬁcer shall in Form4 declare him to be duly elected Chairman of the Village Committee. If more than
one candidate have been proposed, the Presiding officer shall cause to be prepared a list of candidate in Form -5 and ask the members to cast their votes in
favour of their chosen candidate by showing hands-. The Presiding Ofﬁcer shall
call out names of candidates one by one serially as arranged in Form-5 in Bengali
alphabetical order and record the number, and names and political party, if any, of
the members who have raised their hands in favour of a candidate. He shall obtain
signature of the members who raised hands. No member shall cast more than one
vote. If any member casts more than one vote, all of his votes shall be liable to be
rejected. If any Member abstains from voting, it shall be recorded in Remarks
Column of Fonn -5 against the name of the members by the Presiding Ofﬁcer.
5

<!-- page 7 -->

After completion of vote the Presiding Officer shall, in Form -4 declare the candidate who has secured the largest number of votes to be duly elected Chairman
of the Village Committee. In case of equal number of votes being recorded in
favour of two or more candidate the Presiding Ofﬁcer shall decide the result of
the elections by lot in such a manner as the Presiding Officer shall deem ﬁt and
thereupon the candidate in whose favour the lot falls shall be deemed to have
received one additional vote and shall be declared to be duly elected as Chairman
of the Village Committee.

9.

Election ofVice Chairman:

Immediately after the election of the Chairman, the election of Vice Chairman be held in the same manner as provided in sub-rule (3) and (4) of Rule 8.
Provided that for the ofﬁce of the Vice Chairman there shall be no reservation.

/

10. Certiﬁcate of election :
(1) The Presiding Ofﬁcer shall forward the names of the Chairman and Vice
Chairman duly elected to the Zonal Development Ofﬁcer who shall grant a Certiﬁcate of Election in Form - 6 to the duly elected Chairman and Vice Chairman
and thereafter send the names to the Chief Executive Ofﬁcer to publish their names
in the official Gazette.

(2) The zonal development ofﬁcer shall retain all papers relating to the election of the Chairman and Vice- Chairman of a Village Committees for a period of
six months from the date of declaration of result which shall, there after be destroyed unless otherwise directed by the Executive Committee.

6

<!-- page 8 -->

ll. Qath_gf allegiance to be taken by the Chairman and vice

(1). Notwilllﬁtanding anything contained in the Indian Oaths Act, 1873 (X of
1873), every person who is elected as Chairman or Vice-Chairman shall before
entering upon his office make and subscribe, an oath or afﬁrmation of his allegiance to the C.OnS.tilt1t.iQn of India. A person authorized by the concerned Zonal
Development, Qfficer on a date, place and time to be ﬁxed by the concerned Zonal
Developmcm Ofﬁcer shall administer the Oath. The oath or affirmation shall be
in the following form, namely " I Shri/Smt/.._,.,.,._,,,,. ........... .. Having been elected a Chairman of the...

Village Committee do swear in the name of God/solemnly afﬁrrn that I will bear
true faith and allegiance to the Constitution of India as by law established and
that I will faithfully discharge the duties upon which I am about to enter.
(2).

Any person who having been elected as Chairman or Vice Chairman

fails to make within three months from the date of election to such ofﬁce the oath
or affirmation as laid down in the sub-rule (1) of_this Rule, shall cease to hold
such office and his seat shall be deemed to have become vacant and causal vacancy shall be deemed to have occurred in the ofﬁce of Chairman or Vice Chairman, as the case may be, on the date of expiry of three months which shall be
filled up in the manner prescribed in this rules unless the delay is condoned by
the Executive Committee for any special reason.

12. Casual Vacancy:
As soon as may be, but not later than (sixty days) from the date of any casual
vacancy in the ofﬁce of the Chairman or Vice-Chairman for reason speciﬁed in
section 16 and section 17, the Secretary shall convene a meeting of all the members of such Village Committee for the election of its Chairman or, as the case
may be, the vice-chairman in the same manner as provided in the rule 6.
7

<!-- page 9 -->

13. Procedure to deal with question regarding dis-qualification
on ground of defection:
(1) In any meeting of a Village Committee, where vote is taken for election or
for any other purpose, the Secretary shall, if his attention is drawn that any member has voted or abstained from voting contrary to the direction of the political
party to which he belongs and thereby has earned disqualiﬁcation under section
7, record the facts in the Remarks Column of the record of proceedings of the
meeting, obtain clariﬁcation from such member and then refer the question to the
Zonal Development Ofﬁcer in Form 6A .

(2) If the Village Committee received a written information from a political
party or from a member that, the member has voluntarily given up the membership of the party or the member having been elected otherwise than as a member
of a political party has joined a political party, the Chairman or the Vice-Chair-

man shall refer the question to the Zonal Development Ofﬁcer to decide whether
such member has earned disqualiﬁcation under section 7.

(3) Every such member who is alleged to have earned disqualiﬁcation by
reason of voting or abstaining from voting contrary to the direction of his political party, may submit letter or prior permission or condonation to the concemed
Zonal Development Ofﬁcer, within thirty days from the date of voting and such
authority shall take up the question of disqualification only after expiry of the
said period of thirty days and decide the same within ﬁfteen days from the expiry
of the said period of thirty days.

(4) If the authority, as aforesaid, is satisﬁed on the basis of the report of the
Secretary and after making such enquiry as he may consider necessary that airy
8

<!-- page 10 -->

such member has become disqualiﬁed under Section 7, record his decision, communicate it to the Village Committee concemed, and make declaration in Form
6B, that the member has ceased to be the member of the Village Committee.

14. Casual Vacancy in the ofﬁce ofthe Chairman and Vice-Chairman:
'
Whenever a vacancy occurs in the office of the Chairman of a Village Committee by reason of removal, resignation, death or otherwise, the Vice-Chairman
shall perform and discharge the functions and duties of the Chairman till a new
incumbent in the vacant ofﬁce is elected:
r

Provided that when such office of the Chairman of the Village Committee is
reserved for Scheduied Tribes, Scheduled Castes or Women and there is no eligible candidate for election to that ofﬁce, the Vice-Chairman shall continue to discharge the duties and perform the functions of the Chairman for the un-expired
term of the ofﬁce till ‘such members are elected through by-election.

15. Disputes, relating to the validity of theElection of Chairman &
Vice-Chairman:
(1) Any dispute relating to election to the ofﬁce of Chairman or Vice-Chairman of a village Committee shall be decided by the concerned Zonal Development Ofﬁcer.

(2) The authority, as aforesaid, shall give notice to the coritending parties,
call for all the records regarding the election in dispute, give the parties an opportunity of being heard in person and decide the dispute within a period of sixty

days from the date of raising the dispute.
(3) Notwithstanding anything herein contained, pendency of the dispute shall
not dis-entitle the incumbent declared to be elected to continue in his ofﬁce.
9

<!-- page 11 -->

16. intment oﬁﬂhairman 8: V
The Zonal Development Ofﬁcer’shall;when both
and Vice-Chairman are unable to act, temporarily appoint from among the members of the Village Committee to act as such, until the Chairman or Vice-Chairman is elected or
until the Chairman or Vice-Chairman resumes ofﬁce, as the case may be.

17. Removal of defects if any bythe'Ezge_Qtive Committee:
(1) The Executive Committee may issue such general or special direction as
may, in its opinion is necessary for the purpose. of giving effect to these rules.
(2) If any difﬁculty arises in giving effect to the provisions of these rules, the
Executive Committee may, as occasion requires, by order, do anything, which
appears to it to be necessary for the purpose of removing the difﬁculty.
I

(G.Debnath)
Principal Ofﬁcer(Law)
. TTAADC, Khumulwng.

l
I

i

l
I

i1
1
1
l

i
l4
i

»

4

i
,i

10

i
I

i

<!-- page 12 -->

> H w

.

FoRMJ1.'

1

NOTICE FOR FIRST /FIRST ADJOURNED MEETING.

Notice is herebygiven thatthe ﬁrstmeeting
Committee shall. be held on the date,

..... ........... ...,...village

and time speciﬁed below for the members to take

oath and to elect the Chairman (which is reserved for scheduled CasteslScheduled Tribes or
Scheduled Caste Women or Scheduled Tribes Women or Women) and the Vice Chairman.
Shrr ........ .... ........,,,,.....,.,,..,,.,..(desrgnatron)..........................
Who is a

-authority as speciﬁed by the Executive Committee to administer oath

vide Notiﬁcation, N0. . .. ..... .. ............ ..dated................ ..is hereby nominated to ad
.

'

-‘.2.

-.

-

»*;=

\

.

-'

i

'

minlsteroathand_,io‘prestde_,
koverthemeetrl"lag;

All menr_laer_§of_h._._. . ._. ........................................... ., ..... .. Village Committee requested to attend.

DATE

PLACE

TIME

Date:

SECRETARY T0 THE
Place;

VILLAGE COMMITTEE

*

out which is not applicable.
.

-

-

,

F.

-

.

11:

<!-- page 13 -->

FORM. - 2.

ELECTION OF CHAIRMANI VICE CHAIRMAN OF -----------------------------------------=—,=-====____§=.--a_.:: _— .:-_-----‘:;_,:, —__ --------_=:_---_=-_;:;_¢ _.

_¢-u__.-_-Q--_=:_.—_-=-;:_1-'-=== ——_ ; —_;_—a-__;------.-----

---»----..-------¢uq--_------¢-.---- --— _- ¢_ -Q-,-¢_--__-1,-%_—_-Q--_--u-~.__;— _— . ; ---_-at--_‘¢-p-3--w

...-Si

!J.

!3-'.i‘_..L!_l Q

‘Ii!

JILL

Sl.No. Name of the Candidates & party name, if any
S‘

1.

2.

I

'

kl‘ 'i..l.'

Names
I of the proposer &
party name, if any.

I

3.

I

Date:

Secretary to the village committee

Place:

Name & Designation--------------ill

Strike out which is not applicable.
12)

<!-- page 14 -->

FORM - 3.
CONSENT PAPER.

Electionof*Chairman/ *Vice-Chairman.............
~ - Q ¢ o - - . . - - -- ¢ - ¢ o Q - - - - » ~ ¢ o ~ - - Q CO

........................ . . Village Committee.

I I, Shril Smt.......................................................... .., a Member of ...............
Village Committee is hereby ex- ¢ - - ¢ u - - | - . - - . - .- - ¢ . . - ~ ----¢.¢.-- .......................
press my consent to be a candidate in the election of the*Chairman or the *Vrce-Chairman
ofthe said Village Committee.

Date:

Signature of Candidate

Place:
Member......... . Village Committee.

* Strike out which is not applicable.

13

<!-- page 15 -->

FORM - 4.

Form the declaration of result of * contested / uncontested election in the ofﬁce of
Chairman (Which is reserved for Scheduled Castes I Scheduled Tribes, or Scheduled Caste
Women/Scheduled Tribes Women/W0men)/vice Chairman of village committee.
In pursuance of the provision of sub-rule (4) of Rule 6 of the TTAADC(E1ection
of ofﬁce bearers) Rules,2005, Shri /Smti .................................. . .Members
.. . , . . , .......... . .i................. ..village committee is hereby declared as the duly elected
*Chairman I *vice Chairman of ..................... ..village committee of. . . . . . . . . ..

Date

Place :

2

Signature of the Secretary _

(Name & Designation of Presiding Ofﬁcer)

*Strike out which is not applicable.

14

<!-- page 16 -->

.__ ‘(H

Form - 5.

List of ‘contesting candidates and nurnber of votes scored by them for election of *
Chairman '( which is reserved for Scheduled Castesl Scheduled Tribes or Scheduled Caste
women or Scheduled Tribes Women or Women)/Vi¢6 Chairman-

3|
No,

Name Qfcandidafes
and pany if any

Number of
Name ofmembers who Signature or thumbs
votes secured. cast their votes by i'di5- nnpression of meming hands in favour of bers
the candidates and
party, ifany.

w w>gmw
3

l

4

Date I

5

Signature of Secretary
Name and Designation.

Place '

* Strike out which not applicable.

15

Qt

<!-- page 17 -->

FORM- 6

CERTIFICATE OF ELECTION.
~

Certiﬁed that Shri/Smt......................................... . ._ ...... ..
......... .

been
duly elected as *Chairman /*\/ice Chairman of. . . . . . . . . . . ..

.......................... ..Vil1age Committee in the meeting ofthe said Village Committee
held on ............................ . .at................................ ..and in token thereof, I have

granted to him/her this Certiﬁcate ofElection.

Date :

Zonal Development Ofﬁcer.

"

........ .; .............. ..Zone.

Place :

* Strike out which is not applicable. i

16
