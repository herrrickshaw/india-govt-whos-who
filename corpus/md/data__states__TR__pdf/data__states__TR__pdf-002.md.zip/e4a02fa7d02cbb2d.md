---
doc_id: "e4a02fa7d02cbb2d"
source_url: "https://ttaadc.gov.in/sites/default/files/Tender_71.pdf"
ministry: "Tripura Tribal Areas Autonomous District Council (TTAADC), Tripura"
title: "Inviting Tender Const. of 50/100 Seated Boys hostel"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2f227e9b6f182df8"
---

<!-- page 1 -->

TRIPURA TzuBAL AREAS AUTONOMOUS DISTRICT COUNCIL
PUBLIC WORKS DEPAtrTMENT
OF'FICE OF THE EXECUTIVE ENGINEER,
SEPAHIJALA DIVISION:: KHUMULWNG
NOTICE INVITING TENDER No:- . o4/EE/SPJ lADCl2o25 - 26/

Dated, 16lOgl2O25

The Executive Engineer, Sepahljala Division, TTAADC, Khumulwng invites on behalf of the 'Tripura Tribal
Areas Autonomous District Council" sealed percentage rate Bid(s) from the Central & State public sector
undertaking and approved and eligible Contractors/ Firms/Agencies of appropriate class registered with
ADC/ MES/CPWD/Railway/Other state PWD in form No. PWD-7 up to 3.OOpm on 16/lO/2O25 for the following
work.

I

e
Name of work & DNIT No

o

'd

E

E

F

6

r,l

a

cn

o

3

4

5

E

1

2

01

Construction of 50 seated ST Boys
Hostel attached to Bishramganj H.S
School under Charilam R.D Block,
Sepahijala, ADC areas during the year
2024-25 in/c Sanitary, water supply
and Boundary wall etc.

2O2s-26, Dt- 09 /O9 /2O2s.

o

o
o

N

to_
(\
q
(\

lh

a

F.

ac\

q
u

o
o
o

ob

q

o

dE

o

!..
cE!

; Eo E

E

tq

F

6

o
E

r-r)

d

o

o

o.
a

)
ro
!l

a

o
N

p

(\

o
(D

-,c
'-Yo
a= c
::9

'E
tr

& E!

o

9

(\

o
,ri

c.l

€3

o

ll

10

lr)

\o

l.)

th

8

7

o
q

\o

s

E:
9E ?
s-a

I
(?-

DNIT NO:- 74(O3\/CEIADC/PD-I /

E.u
't:

o.
E

o

o

z

q
,9

o
N
o

-.o
.,6
\it
!rq

o
c?
lf)

\o

o, (J

co
c<
Id r-

'a! <

(!

uF

tr
o.

x .a
HO
uo
o-C

o

o
a.

€;.:
-.: tr
OXj

d,Ff
02

Constructioo of 100 seated ST Boys Hostel
attached to south Takarjala H.S School
under Jampuijala RD Block, Jampuijala
Sub-Division, Sepahijala District within
built Wardetrs Quarter, boundary wall, site
development, Furniture and Utensils.

DNIT NO:- 76(03)/CE/ADC/ PD-lll/
2025-26, Dt- 11 / 09 12023.

,t
c
o

o
o

v-

q
\o

c\
n

n
\o
(\-

a

o
o
o
o
,n
u

i
I

o

E

\o

a

o

e
b
F
c.l

o.

)

a
q
c.l

o

9,

I

(\

o
q

N

o
9.

4.O

lf)

gL

N

I

\o

h0<

c<
oF

f

a

6(j

o

s
(!

-O

&

39
x.a

Ho uo
u-C

5t-a
O-c c
^d:
d,ts

f

TermE & condition "
l.Tender documents consisting of qualilication inlormation and eligibility criterion of bidders, plans,
specilications drawings, the schedule of quantities of the various classes of work to be done and the set of terms
and conditions of the contract to be compiled with by the bidder can be seen in the office of the Executive
Engineer, Sepahljala Division, TTAADC, Khumulwng between hours of f 1.00 A,M and 4.00 P.M on any working
days between L6lOg l2O2S and 1-3lLO|2O25, Tender docurnents will be issued from this of6ce during the hour
specified above, on paJ.ment of RS.SOOo/- (Rupees Five Thousand only). in cash/ Demand Draft(Non
Refundable) on any working days as specified above on production of documentary proof of registration of the
Iirm along with on application.

2. Receipt of applications and issue of render forms will be stopped by 16.00Hrs. on 13/1O/2O25 Tender
document s consisting of plans, specification the schedule of quantities of the various classes of work to be done
and the set of terms and conditions of conEacts to be compiled with by the contractor whose tenders may be
accepted and other necessary documents can be seen in the office oI the Executive Engineer, Sepahijala Division,
TTAADC, on any working day during office hours(except on Sunday and Public holiday.

3. Tender form will be issued on receipr of application and production of documentary prooi of his/her

o

o.
o.

<!-- page 2 -->

5. Tederers must submit his/her tender along with photo copy of his/her GST, Pan card , registration of

enlistment Iabour license etc. with current validiry duly self attested on both pages.
6. a. Tender documerts must be delivered to office of the Executive Engineer, Sepahijala Division, TTAADC, on
or before 15.00 hours on 16llO l2O2S if the office happens to be closed on the date of receipt oI the bids as
specified, the bids will be received on the next working day at the same time and venue.
b. Tenders will be opened at 15.30 hours on 16 / IO 12025 (if Possible) in the office oI the Executive Engineer,
Sepahijala Division, TTAADC. If the oflice happens to be closed on the date of opening of the bids as specified,
the bids will be opened on the next working day at the same time and venue.
6. The Earnest Money should be deposited in the form of "deposit- at -call" in favour ol Executive Engineer,
Sepahijala Division, TTAADC from any schedule bank guranted by the Reserve bank of lndia. Tender without
"deposit- at -call' receipt as stated above will not be considered to be valid an such tender shall be summarily
rejected

7. Any corrections in the tender should be initialed by the tenderer.
S.Tendering documents will not be sold to intending tenderer who are near relatives of Divisional Accountant or
Superintending Engineer or Executive Engineer or Assistant Engineer or Junior Engineer of the circle in which
the work is to be executed.
Note:- A near relative included wife, husband, parents, in-lows, children, brothers sisters, uncles , aunts and
cousins.
9. No Engineer or Gazatted rank or other office employed in the Engineering or administrative duties in on
Engineering Department of the state government/TTAADc is allowed to work as a bidder for a period of two
years after his retirement from Government service without Government permission. This contract is Iiable
to be cancelled if either the bidder or any of his employees is found any time to be such a person who has
not obtain lhe Permission of the Government as aforesaid before submission of the tender or engagement in
the bidders Service.
any/ all
10. The accepting authority reserve the right to accept tender other than Iowest one/ rej
tenders without assigning any reason,

v

eea
Executive
Sepahijala Division,

TIAADC, Khumulwng

No. F. 2(5)/EE(SPJ)/ADC/ 887-902

Duted. I 6/09/2025

Copy toi
l. i.S to the Hon blo ChiEfExecutivc Member, ]'TAADC, khukulwng for kind intbrmalion ofthe ChiefExecutive
member, I'TAADC khumulwng.
2. P.S ro the Hon'blc Executive Member (PWD,RD), TIAADC, khukulwng for kind inlbrmation to the Hon'ble
Executive member, (PWD,RD), TTAADC khumulwng
3. p.S to the ChiefExecurive Offic€r, TTAADC, ktukulwng for kind information ofthe ChiefExecutive Officer,

TTAADC khumulwng.
4.The ChicfEngineer TTAADC khumulwng for kind infomation.
5.The Superintending Engineer, Circle - tll, O/o the ChiefEngineer, TTAADC khumulwng for kind info.malion.
6. The Eiecutive Engineer west Div/Comati Div6ofth Div. Machmara/ South Div. B,C Maru,Dhalai Div.
Ambassa./tlnokoti Div/Ampura Div. I(]Iowai, TTAADC for kind information
7. The Zonal Development Officer, Sepahiiala Zone, TIAADC for kind information.
8-g.rlrdAssisranr Engineer, Takarjala /Bishrarnganj Sub-Division, TTAADC lor information and necessar) action
I.T ccll TTAADC, Khumulwng wilh rcquest for one insenion to displa) in thc llebsite of TTAADC.
L&fhe
I l-l2.secretary,President. Contraclor Association, Khumulwng/All Tripura Conlractor Association 2"" floor of
Orienl Book Sociery Akhaura Road, Agartala,
l3-14 The Accountan/Casbier ofthis otrtce for information.
l5-l6.Notice board i Cuard file.

Executive En
eer
Sepahijala Division,
1TAADC, Khumulwng

,i.''',4---

<!-- page 3 -->

TRIPURA TRIBAL AREAS AUTONOMOUS DISTRICT COUNCIL
OFFICE OF THE EXECUTIVE ENGINEE&
SOUTH DIVISION: BIRCHANDRA MANU: SOUTH TRIPUA
PRESS NOTICE INVITING TENDER No. OL/EEISD/ADC/BCM/2025"261

a

z

Name ofwork & DNIT No.

I

2

Consruction of50 seated ST Boy's hosrel
anached to Jolaibari H.S. school under
Jolaibari RD block, South Tripur4 during
the year 2025-26/SH:-Building portion ir/c
water supply & sanitary installation,

t,

boundary wall for 145.00mtr. long
fumiture, utensils, SBDTW installation, tRP
eac. and it's allied.
DNIT No.73(02)/CE I ADCIPD-1112025-26,
dated-08-09-2025

E
tr:*t

!
E

o.
iE
Lr.l

t!

3

4

5

CO

\o
o
o.

--i

f.--

r: -'
E5
&,e

L.-

ct

c.t

a

(,

o
\O^

,;

u

Dated, 15'09-2025

Y5

€g

€;
q.}+ EE
E _0.1

i .g
;!

:s
ddo

:b
4gr

I
oE
,4: E
o.9 E

EE
6

o

8

7

9. ,n

6
fo

9

Q

t0

9E
E_a

4-

€EE

9a riR

E#E

f

E*:
EZ=

^o

'c
o
c

q

&

For details please contacr to the omce ofthe Executive Engineec South Division, TTAADC, B.C Manu, South Tripura
during office hours and also details ofterm and condition etc. will be available ofTTAADC website.
Contents above to be published only.

vqn\fi,,

For and on behalf ofthe District Council

Executive Engineer
South Division, TTAADC.
B.C Manu, South Tripura

No.F,4t13)/EElSD/ ADc/BcM/ 467

-82

Dared. Ts /0e /202s

To,

The principal oflicer, ICA&T. TTAADC, Khumulwng with a request to make arrangement for publishing in 3(three) daily
Iocal leading Newspaper & at least 2(two) Nos. national news paper and display website ofTripura info.com. one
insertion and to request the respective editor to send a spare copyto the undersigned {Enclose:- 6(six)Nos. spare
copies.)
Copy to:-

l. P.S to the Hon'ble ChiefExecutive Member, TTAADC, khumulwng for kind information to the ChiefExecutive
member, TTAADC khumulwng.
2. P.S ro the Hon'ble ChiefExecutive Officer, TTAADC, khumulwng for kind information to the ChiefEx€cutive Officer,

TTAADC khumulwng.
3.TheChief Engineer, TTAADC, khumuhwg for kind information.
n cett,i'feAbq, Khumulwng with riquest for one insertion to display in thc website ofTTAADC.
-*rt
5-6.secretaryPresident, Contractor Aisociation, Khumulwng/All Tripura Contractor Association 2no floor of Orient Book
Society Akhaura Road, Agartala.
7-E. The Accountant/Cashier of this ofiice tbr infomation.
r,Q. ,\ o, -' " 'z'loL|
9-l0.Notice board / Guard fite.
Executive Erlgineer
South Division, TTAADC.
B.C Manu, South TriPura

<!-- page 4 -->

ct,;i

TRIPURA TRIBAL AREAS AUTONOMOUS DISTRICT
COL]NCIL
OFFICE OF TF{E EXECUTIVE ENGINEER
D
SI N
G
Id-eerdadc@gmail.com)
@mail

t
,f,

0Tt

E NVIT NG

NDE

05rc

N

RiD

25.202

ated

tcti tli

08-

oi lcE
c
F.

I-.

The Executive Engineer, R.D, Division,

TTAADC, Kiumulwn g invites on behalf of the .TRIP{jRA TRIBAI
SA UTONOMOUS Dl STRICT COUNCIL, sealed percentage
rate Tender(s) in Form-7 from the approved and eligibl
ffirms/Agenci es of appropriate class registered
with PWDiTIAADCAdES/CpWD/Railway/Orher Sta&
PWD/Central & Srare publ ic Sector undertaking
up to 3.00 p.M. on 24-09-2025 for the following work:_

c

F

q,

Name of work

c
o

oo)

E

E

0)

$

2

01

3

under Kakraban R.D Block,
Udaipur, Gomati wirhin Buitt
Warden Quarler, Boundary wall,
Site development, Fu rniture,
Utensils etc. during the year 2025_
26lSH:- Building porlion in/c Water
Supph', Sanitan, inst:rllation,
Boundar; uall for 145,00m long antl
it's allied.
DN-IT NO, 63(02) /CE

/PWD/

ADC tPD.tU 2025-26

Dated.28-O7-2O25
02

C onstruction of 100-seated
Maharani Kanchan prabha Devi S.T
Girls Hostel at Ambassa, Dhalai
District within Built Warden
Quafier, Boundary wall, Site
development, Furniture, Utensils
etc. during the year 2025-26lSHr
Building portion including Water
Supply and Sanilan installation
work, Site development etc.
DNIT NO 70(0 IC E /PWD/
ADC/P D.II/ 2025- 26

or6E

o

3EE

aQ
5F
(r)tr
oxo
-J .y o ao

0)

E

F

tlJ

u..J

C o n s t r II c o n o f 5 0-s clt tcd s T B oy s
H ostel il t(a c h e d to M I'ZA H S S c h oo

E
O

o

o

1

o

E

o

E

E

'o

q)

o
o

4

5

o
d)
OE
EC
.=o

(l.)

E

,9

6

oE

odb

it ,i
(,6

9o,
6

oc
lJ:>

:E

oo)
oE

o

9

10

s-c

9t.

-5E

7

po)
E
o

b rl)

8

tl!
iU

(E

N
l0

.:
I

(D

a
N
&

_o

o

.l

E

d

E

c

.9

a

:>

F

I

(o

o

+di
!o
ON

|
I

o-o)

c

o-{
lr)o
ON
o-

La)

o
N
q)
o
N
c!

00

<l

ur

I

".o

8l-

uJ
0)

E
F

!o)
sl
E
tu

.t
F
(o

Dated. 02-09j202b

Pase 112

o

;<
'F<
t-

{N

E,

'6i Y

curo

c,

00

o

oc
o5
c-c

N

1'

(D

E;
-5

/**

q)

o
o
o
o.

<!-- page 5 -->

03

Construction of 50-seated S.T Bovs
Hostel aflached to pabiachara H.S
School at Sukanta Palli under
Kumarghat RD, Block, Kumarghat
Sub-Division, Unakoti DistricVSH:Building portion, Water Supply &
Sanitary installation, Retaining wall
with boundary u.all (80.00m). etc.
DNITNO. 71 (02) /cE /PWD/

a!

t,
qr

N
N

o

!

,;

q.

E

ADC / PD- ilt 2025-26
Dated , 08- 09"2025
04

N
tl
o-

'6

{J
(u

F

i5

-o)
.\E

c
o

Construction of double storied 50seat€d Boys Hostel at Salema H.S
School (Maharani English Mediunr
High School) under Salema R.D
Block, Kamalpur Dhalai District
rr ilhin Built \t'ardens Quarler,
Boundary wall, Site development,
Furniture, Utensils etc./SH:Building portion inlc Water Supply
and Sanitation, Sit€ development,
Boundary wall (145.00rn).
DNIT NO. 72 @D ICE iPWD/

+N

(o

N
o

N
O)
N
t

<N

N

o

(!
o.

o

oo-

5!:

8rUJ

0)
E

N
E

i5

;<

F.

o

o

-f

oc
of
CE
'aY
cr.x o

Be

N
N

)

!;

,r:

N
o
N
O)
o

ON
Co)
rJ)o
ON
E

E;

I
'rN
_o
ON

lri Lo

F

!

c

o

o,

F

ADC IPD-III 2O25-26
Dated. 08-09-2 025

Detailed tender notice and terms and cond ition can be seen at the Office
of the u ndersigne,j during Ofrice hours on any working
day upto 15:00Hrs. of 20.09-2025 and web site of TTAADC

,'r

For details please visit

www.ttaadc.gov.in

\
(Er. S
Ex

a
VC Engineer

R.D, Division,
TT

DC.Kh umulwno

Contents above to be published.

No.F.3-l(7)/ /EE(R/D)/ADC/202y 8l? -

ll .

dated,08-09-2025

To

1) The Principal Officer (ICA), TTAADC, I(lumulwng with a requesr to make arrangement for publishing
4(four) dail y local leading N ews papers in one insertion, (Enclo-5(five)nos.
he Addl. Chief Executive Officer (l.T Cell) TTAADC, Khumulwng with

for publication in the -t-TA ADC web site (Enc lo- l(one)no. soft copy).

spare copies
a requesr to make arran gement

3) The Officer-in-Charge. Radhapur Police Station for information and he is requested to make neces sar]
security arrangement in and around the p.O (Agri), Building premises opposite

to Khu

Executi
R.

Park.

nglneer
lVlSrOn,

TTAADC.Khumulrme.
Paqe A2.

in
