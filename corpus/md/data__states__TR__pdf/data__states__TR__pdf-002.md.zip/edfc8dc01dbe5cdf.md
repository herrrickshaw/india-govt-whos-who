---
doc_id: "edfc8dc01dbe5cdf"
source_url: "https://ttaadc.gov.in/sites/default/files/Tender%201_0.pdf"
ministry: "Tripura Tribal Areas Autonomous District Council (TTAADC), Tripura"
title: "Tender 1.PDF"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "04ea3a3eb8a0a9ae"
---

<!-- page 1 -->

TRIPURA TRTBAL AREASAUTONOMOUS

DISTRICT COUNCIL

oFFrcE oF THE EXEcuTrvE erutrr,ri'in
PRESS NOT|CE tNVtTtNc TENDER

NO, 04/EE/GD tADCtBCt\At2024_25

E

€
(l,

!

Name of work & DNIT No.

E

(D

o
at
o

o

Dated,30-01-2024

og

'Eb.8;
5.p*
"E
d!(DCL

E s€€

3E-€E

Ed
qrE

EE
.=o

€b
9sr

t*g

JE

dE

3EC
E5
;'d
ft(,

E e=€

construction@
uuesr House at Raima Saima pilgrimage

ITMDC areas for nerV zOz3_.iq.""-vv

place in
r'e\

DNIT No:. 06(02yCElAD CtpD-It2024.25

Dated 11t07t2024

o

ro)

|r)-

@
O)
|.j

c\i

o
o

E5
(c;
€
=o
E^
O)
Fi
F€
9C

N
at>

(tt

E

ev,

E

-i(I'
5u,
o:
Ots

o

E

--"' -Y s'i
:1*!:ifiJ:lJ*siffii:{iiilJ::.:iT;:ff',,f,'J:i?rT3S'L.,.#jiDivision,
Contents above to be published

only.

For and on behalf of the District

o

'= (J
Ecci

EF

-€
-oE
Pg
_rs

e=
Q-c

Ex s'i(DF
-(\

9.+
-F
C\

s€
=o

-g'a->
\20

rr|<
F<

lr)o

=b
-Qcr)
(\I

TTMDC, B c Manu, GomatiTripura

Council.

Gomati Oivision, TtAnDc.
B.C Manu, Gomati Tripura

b.E

o.2

oE
durins office hours
