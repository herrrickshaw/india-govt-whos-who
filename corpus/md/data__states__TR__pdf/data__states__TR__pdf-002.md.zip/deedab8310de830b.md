---
doc_id: "deedab8310de830b"
source_url: "https://ttaadc.gov.in/sites/default/files/Tender_65%20%281%29.pdf"
ministry: "Tripura Tribal Areas Autonomous District Council (TTAADC), Tripura"
title: "Tender.PDF"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c1077eba01b68091"
---

<!-- page 1 -->

:rrs':::1.i.

i..

'.,,..,",,.,

: TRIPURA TRIBAL AREAS AUToNoMoUS DISTRICT CoUNCIL
""
OFFICE OF THE EXECUTI\/E ENGINEER
IVEST DIVISION :: KHU]\{UL\{NG.
NOTICE INYITING TENDER NO:- 17lEE(I{')/ADC/2024-ZS/Dare{t.

07_02_2024.

Sealc-d percerrtate rate tenders are iur,ited ir P\\'D Form-? bl the Ereculive Encineet.. West Division"

TfAADC on behalf of T.T.A.A.D.C. anthotitv tlonr bouafied resourceiul consh uction Ag'encies/ fimrs/ Enlisled
contractors r-egistered in appropriate class of TTAADCi anr, Stale P\\ID / CPWD / l\4ES/ Ra jl$,ar, p &T upto 3.00
P.\1. orr 20-02-2025 fol rlre follou irrl rrorks:
o-g
/ra

a
st.

l?

.<a

E

.=a
t=

r-arne of rr olk & DNIT No.
.=

^-o

3

lmp, of road from Khumulrmg-Belbari
Road[Point ludo HallJ to l(herengbar
CHC during the ]'ear 2024-25. lTotal
Length=0.698 fGl)./SH:- il ConslrucooD

of02 (tir.oJ Nos. RC.C. Box cell culrert of
clear span=1.00 m & clear beight =1.S0

m at Ch. 0.23 l.[l, Ch: 0.3-1 IOt

t..

respectively. iiJ ConsFuction of RC.C.
Retaining rvall [L=72.00 mtr. + 25,00
mtr.)=97.00 MF. at Ch. 0.112 lc\f & Ch:

f..
J'

0,58 Klll iii] ColsFuction of Katcha
Drain (L=0.663 KMl. iv) Providing &
Laying flat brick Soting, metalling &

= == -:
.E .Z E.=

(L=0.69SKMJandwidening(L=0.13

I ?=
'>z>

carpeting and Sand seal coat.
5

KM).

?

D\IT NO:- 37(02)/CE l.\D C lPD -IA 202 4 -25
Maintenance of Secretariat BuildiDs
INEW lltAB) at lGumult!'ng Under H/{
Complex, I'TAADC during tie yea 2024-

-i=

=i=
-';.

portron.

qi= =- i

DNIT NO:- 25lEEOl\ t AD C t 202 1-25

t-=

25./SH: Painting Building outside
Dt.07 t02/2025.

Detailed tender notice and terms and condition can be se:i a:::3 c=t: :.
any working day upto 1500 Hrs. 20-02.2025 and web site of T-tAADC.
For detailed please visit.

:: - --:r

--:!

For details please visn:

; :-:r- n6ro hnrrrc nn

;r'

.,

t ,',/'

.21')1ua.-)

!,'J\'/W.ttaad c. a ov. i;1 .

i- I l:::.-:

1:-:::,: irg'--:
Contentsabovetobepublished. 92

(W)/ADCI

-9A

oyf o ,l

No.F.30 (32) /EE
)
tdated,
To
1) The Principal Ofilcer, lCA, TTAADC, Khumulwng with a request to make
local leading News papers & in one inseriion,

?J Ile 19-dl'

"{.

anangement for publishing in g3(three) nos. da,..

{Enclo. 06(six) nos. spares copies.

c.E.o. (l.T cell), TTAADC Khumulwng wiih request io make arrangement for publication

3)' The officer - jn - Charge, Radhapur Police Station /Mandwi Police Station foi information

in web site.

and you are requested to

necessary security arrangemen{ in and around the pwD office premises at
Khumulwng tt l. tre o1{ ygnap.u..
Station),, Mandwi (for the O/C Mandwi, police

Slation).

\r,m
Execuiive

ra,:

i: ::

r>-

Encincs'

West Divis ci:
TTMDC, Khurn::n-=-
