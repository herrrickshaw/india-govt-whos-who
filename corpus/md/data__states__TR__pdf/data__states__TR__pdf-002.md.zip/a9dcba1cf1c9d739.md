---
doc_id: "a9dcba1cf1c9d739"
source_url: "https://ttaadc.gov.in/sites/default/files/Tender_69_0.pdf"
ministry: "Tripura Tribal Areas Autonomous District Council (TTAADC), Tripura"
title: "Tender.PDF"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e5cc2cd3d39d4367"
---

<!-- page 1 -->

COUNCII.'

AT]T'ON'}MOUS I]ISTITICT
:'49:'! |RIPLTRIT. T RIRAL AREAS
THF EXECI]TTVE EI'IGINEER
OFFICI, CT

L.SILCI-IIIYITING :ESprx r{o:- ori-eEl$1:\-D-cl2!2s-?6|-Dated'U-qaj4+

\nJest Division' TT'4A DC

Se;le. pei'entage 1ut" trnOuo iET*t"O in PWD Form-7 bt the Executive Engineer,

-l-.i,A.A.tt.C.
contractors reEistered
authority lrom bonafied rescurceful construclicn Agenciesi firms/-Enlisted
cn oelialf oi
08'05'2025 fcr the
M
on
P
pwo
3
00
upto
P
&T
t cptnio / MES, Railvray
iiui.
in appiopiiate ctass of TTAADC/

,.i

works:

rl
E

c)

l'lame o{ woi-k & DNIT No.

(E

.E

ul

(AStrc

c)

c
E

c)

a
(l)

C
c.)
F

(s

L!

o

=
.a

6 t: (o:
o
E

O

o
c)

c) -o

aq)

..:, (! lg
i;::
s:=
-1.
r

*

c)

C.)

(s(D

.E_

6

F

of Syntheiic Turf Footbali
-iUrf)

with monofiiament,
at Lefunga High

!-F

Ee
(I)F

-ta

"oB

c-

.D5

a

ec

s

C-

cd o)

., .E
'c

at

e)

(g ;'

(I)c)

6L

o_u

5 E= E

9.=
> E:
.a
=.=

of Svnthetic Turf, Fencing

",6t0412025.

(D

boa

a.t

Abhicharan Sub-Zone
under"'arn
ihe year 2025-261 SH:ali sicies oi the field,High Mast-12.5
in witn otre.sice lightino. '-ED flocdlighi,
Visiiors Shecj incluciilig Gcai postei:.
NC :'45(0?)/C E/AD Cl?D)U20?s'26i

g

d) c:

;hqi
Eq?E

o

E

r.l

al

a-] ;

al

tl)=

l-=

e.

.ti

c\

tr

?F!;
€F

1=

Detalled t"ndet totice and terms and condition can be seen at the ofirce
on any workilg day upto 1500 Hrs. 08-05'2025 and web site of TTMDC
For detailed please visit,
For details Please visit:

of the un6slsigned during ofi1ce hours

AD

,/-11 /'\

/

/'

THfo'i\')
(Er. D. Ddb6drma)
Executive Engineer
West Division,
TTA"qDC, Khumulwng.

Contents above to be PUblished.

No.F.30(32)/EE(W):ADC/

6q5'-q 4

nated,

gfoqlzF

To
1). The principal Of{icer, lCA, TTMDC, Khumulwng wlth a request to make arrangement

for publishing in 03(three) nos

daiMocal leadinq News papers & in one insertion, {Enclo.06(six) nos spares copies'

cettl TTAADC Khumulwng with requestlo make anangement for publicatron in web site.
--i{in" iaal. c.e.o. 1t.r
you are requested t0
3j, the Ofiicer - in -'Charge, Radhapur Police Station /Mandwi Police Station for information and
(for
the o/0 Radhapur,
make necessary seculty arangement in and around the PWD office premises at Khumulwng
Police Station),, Mandwi (forthe O/C Mandwi, Police Station).

/1) -'.. /'
-tft/otil+5'

(Er. D. Debbarma)
Executive Engineer
West Division,

TTMDC, Khumulwng.
