---
doc_id: "b8e3bd1b4ff73cd6"
source_url: "https://dmf.goa.gov.in/wp-content/uploads/2025/06/Goa-District-Mineral-Foundation-Trust-Rules-2018-Amended-upto-Feb.-2025.pdf"
ministry: "District Mineral Foundation, Goa"
title: ""
date: ""
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6b40dbbc49bdf3f4"
---

<!-- page 1 -->

1. The Goa District Mineral Foundation (Trust) Rules, 2018, published in the Official Gazette
Series I No. 41 dated 10-01-2019;
2. The Goa District Mineral Foundation (Trust) modification notification dated 13-2-2019
published in the Official Gazette Series I No. 47 dated 21-02-2019;
3. The Goa District Mineral Foundation (Trust) (Second Amendment) Rules, 2021;
published in the Official Gazette Series I No. 4 dated 22-04-2021; and shall come into force on
the date of their publication in the Official Gazette.
4. The Goa District Mineral Foundation (Trust) (Third Amendment) Rules, 2021, published
in the Official Gazette Series-I No.41 (Supplement) dated 6-1-2022
5. The Goa District Mineral Foundation (Trust) (Fourth Amendment) Rules, 2023,
published in the Official Gazette Series-I No.12 dated 22-6-2023.
6. The Goa District Mineral Foundation (Trust) (Fifth Amendment) Rules, 2025, published
in the Official Gazette Series-I No.48 dated 27-2-2025 and shall come into force on the date of
their publication in the Official Gazette.
.

Department of Mines
Directorate of Mines & Geology
__
Index of Rules
Rule
No.

Title

Modification
notification
dated
13-2-2019

2nd
Amendment,
2021

3rd
Amendment
2021

4th
Amendment
2023

5th
Amendment
2025

CHAPTER I
1
2
3

4
5
6
7
8

9
10
11
12
13

Short title and
commencement
Definitions
CHAPTER II
Objective of District
Mineral Foundation
(Trust)
Composition of District
Mineral Foundation
Appointment of the
Trustees
Management of Trust
Powers and functions of
Governing Council
Meetings of Governing
Council
CHAPTER III
Managing Committee
Powers and functions of
Managing Committee
Meetings of Managing
Committee
Trust Fund
CHAPTER IV
Scope of the District

Amended

Modified

Amended

Amended

Amended

Amended

Amended

Amended

1

<!-- page 2 -->

14

14A

15
15A.

16
17
18

19
20
21
22
23
24
24A
24B
25

Mineral Foundation
Trust
CHAPTER V
Utilization of Funds by
District Mineral
Foundation Trust
Restriction on transfer of
fund from District
Mineral Foundation
CHAPTER VI
Implementation of
projects
Constitution of State
Level Monitoring
Committee
CHAPTER VII
Five Years Perspective
Plan and Annual Plan
Annual Budget
Approval of the Annual
Plan and the Annual
Budget
Annual Report
Charging of Expenses
Financial Year
Accounts and Audit
Liability of Trustees
Remuneration
Grievance Redressal
Compliance Mechanism
Repeal and Savings

Substituted

Substituted

Inserted

Amended
Inserted

Amended

Substituted

Amended

Substituted

Inserted
Inserted
Amended

2

<!-- page 3 -->

Notification
DMG/MMDR/DMF/01/2015/7633
In exercise of the powers conferred by section 15 read with sub-sections (2) and (3) of section 9B
of the Mines and Minerals (Development and Regulation) Act, 1957 (Central Act 67 of 1957) and
all other powers enabling it in this behalf, the Government of Goa hereby makes the following rules,
namely:—
CHAPTER I
1. Short title and commencement.— (i) These rules may be called the Goa District Mineral
Foundation (Trust) Rules, 2018.
(ii) They shall be deemed to have come into force with immediate effect.
2. Definitions.— (i) In these rules, unless the context otherwise requires,—
(a) “Act” means the Mines and Minerals (Development and Regulation) Act, 1957 (Central Act 67
of 1957);
[(b) “Affected areas” means the areas which are affected by mining or mining related operations
and shall include;—
1

(i) Directly affected areas:- Villages and gram panchayats or Urban Local Bodies (ULBs) within
which mines (other than minor minerals) are situated and are operational. Such mining areas may
extend to neighbouring village/town, block or district or even State:
Provided that directly affected area is an area within such radius from a mine or cluster of mines as
may be specified by the Government, but shall not extend beyond 15km from the boundary of the
mines of mineral other than minor minerals.
(ii) Indirectly affected areas:- Those areas where local population is adversely affected on account
of economic, social and environmental consequences due to mining-related operations of minerals
other than minor minerals:
Provided that indirectly affected area is within such radius from a mine or cluster of mines as may
be specified by the Government, but shall not extend beyond 25km from the boundary of the mines of
mineral other than minor minerals:
Provided further that in cases of minor minerals quarrying, the affected areas shall be revenue
villages where the quarrying lease is situated.
The District Mineral Foundation shall prepare and maintain an updated list of such directly and
indirectly affected areas.]
(c) “Affected persons” means the persons residing in affected areas;
(d) “Auditor” means the auditor or Chartered Accountant appointed by the Governing Council and
includes the Accountant General of the State or other Auditors nominated by the State Government.
(e) “District Mineral Foundation” means a trust as established as a non-profit body, through a
notification by the State Government in terms of sub-section (1) of section 9B of the Act;

1
Clause (b) substituted vide Amendment Rules 2025. Original clause read as follows:- (b) “Affected areas” means the areas which are
affected by mining or mining related operations as identified by the district. This will include directly affected areas and indirectly affected
areas.

3

<!-- page 4 -->

(f) “Governing Council” means the Governing Council of the Foundation consisting of all the
trustees of the District Mineral Foundation;
(g) “Financial year” means a year commencing from the 1st day of April;
(h) “Government” means the Government of Goa.
(i) “Managing Committee” means the Committee formed by the State Government for the purpose
of day to day management of the affairs of the Foundation.
(j)Words and expressions used in these rules, but not defined, shall have the same meaning as
respectively assigned to them in the Act.
(k) “Trust” means the District Mineral Foundation Trust established by the State Government
under sub-section (1) of Section 9B of the Act.
CHAPTER II
3. Objective of District Mineral Foundation (Trust).— (a) The objective of the District Mineral
Foundation Trust is to work for the interests, benefits and sustainable development of persons and
areas affected by mining or mining related operations in the district;
(b) To utilize the funds accumulated in the District Mineral Foundation Trust in an effective,
transparent and accountable manner and at the same time ensuring the benefit of the funds are enjoyed
not only by the present generation but the future generation to come.
4. Composition of District Mineral Foundation.— (a) Every District Mineral Foundation (Trust)
as established under sub-section (1) of section 9B of the Act and as guided by provisions of subsection (2), (3) and (4) of section 9B shall consist of a Governing Council and Managing Committee.
(b) The Office of the District Mineral Foundation shall be situated at the Directorate of Mines and
Geology, Government of Goa, Ground Floor, Menezes Braganza Building, Panaji, Goa or at the
District Head Quarters or as may be determined by the Governing Council.
(c) All District Mineral Foundation Trusts may also set up an office at the district level for the
purposes of coordination, planning monitoring accounting and public disclosure of information. The
Governing Council shall ratify the appointment of staff members of District Mineral Foundation
office with prior approval from the State Government.
2

[(d) The Governing Council shall consist of the following members:—

Sr.
No.
1.
2.
3.

4.
5.
2

Designation
Collector/District Magistrate
Members of Parliament, Lok Sabha, of the respective
Districts of the State of Goa
Member of Parliament, Rajya Sabha, of the State of Goa
(The Rajya Sabha MP shall intimate name of the district
selected by him/her to the Secretary in-charge of Mining
Department of the State who in turn shall inform the
concerned District Magistrate/District Collector)
Members of the Legislative Assembly of Goa from the
directly affected areas in the State of Goa
Deputy Director of Mines and Geology

Designation in the Governing
Council
Ex Officio
Chairperson/Trustee
Members/ Trustees

Clause(d) substituted vide 4th Amendment Rules,2023 and thereafter vide Amendment Rules 2025.

4

Members/ Trustees

Members/ Trustees
Ex Officio Member

<!-- page 5 -->

6.
7.

The Executive/Assistant Engineer, Public Works
Department
The Deputy Director, Directorate of Health Services

Secretary/Trustee
Ex Officio Member/Trustee
Ex Officio Member/Trustee

8.

The Deputy Director, Directorate of Education or any
Officer not below the rank of Assistant Director/Deputy
Director nominated by the Directorate.

Ex Officio Member/Trustee

9.

The Deputy Director, Directorate of Social Welfare or any
Officer not below the rank of Assistant Director/Deputy
Director nominated by the Directorate.

Ex Officio Member/Trustee

10.

The Deputy Director, Directorate of Women and Child
Development or any Officer not below the rank of
Assistant Director/Deputy Director nominated by the
Directorate.

Ex Officio Member/Trustee

11.

The Deputy Director, Directorate of Agriculture

Ex Officio Member/Trustee

12.

The Executive/Assistant Engineer, Water Resources
Department
The Director, Department of New and Renewable Energy
or any Officer not below the rank of Assistant
Director/Deputy Director
The Representative of Finance Department (Budget), not
below the rank of Under Secretary.

Ex Officio Member/Trustee

15.

The Director/Deputy Director, Directorate of Panchayats

Ex Officio Member/Trustee

16.

Member Secretary, Goa State Pollution Control Board

Ex Officio Member/Trustee

17.

The Project Director/ Project Officer, DRDA

Ex Officio Member/Trustee

18.

The Deputy Director, Directorate of Animal Husbandry
and Veterinary Services or any Officer not below the rank
of Assistant Director/Deputy Director nominated by the
Directorate.

Ex Officio Member/Trustee

19.

Representative of the Centre for Environment Education

Member/Trustee

20.

Two Representatives of the mineral lease holders/industry
representative/Goa Mineral Ore Exporters Association as
nominated by the Government

Member/Trustee

21.

Any other Officials/persons as nominated by the State
Government
Two Representatives of the persons from the areas
affected by mining related operations as nominated by the
Government

Member/Trustee

13.

14.

22.

Ex Officio Member/Trustee

Ex Officio Member/Trustee

Member/Trustee

5. Appointment of the Trustees.— (a) The trustees appointed by official designation shall
continue as trustees during the period which they are holding the post and would be deemed to have
ceased to be the trustees once they cease to hold the office by virtue of which they were appointed and
their successors in office shall be deemed to have been appointed as trustees in their place with effect
from the date of acquiring such post.

5

<!-- page 6 -->

(b) The term of appointment for the nominated trustees shall be for three years with effect from the
date of their nomination as trustees and the Government may thereafter renew their appointment for
another term or may appoint other persons in their place:
Provided that the term of such nominated trustees shall in no case exceed two terms of three years
each.
(c) The Government may at any time increase the number of trustees in any of the categories and
for such terms as it may deem fit.
(d) The Government may at any time remove any of the trustees and may appoint any other person
as the nominated trustee at its sole discretion. The trustee so removed by the Government shall cease
to be a trustee with effect from the date of such removal.
6. Management of Trust.— The Management of the Trust shall vest in the Governing Council
which shall consist of Ex officio and nominated trustees. The day to day management will be by the
Managing Committee as defined under Rule 9.
7. Powers and functions of Governing Council.— The Governing Council, consisting of all the
members shall be responsible for–
(a) Laying down the broad policy frame work and approving the procedure for functioning of the
trust and review the working of the trust from time to time;
(b) Approving Perspective Plan, Annual Action Plan and the Annual Budget for the Trust which is
put up for approval by the Managing Committee. The Perspective Plan and Annual Action plan shall
be prepared by the Managing Committee and approved by the Governing Council at least one month
before commencement of the year;
(c) The Annual Action Plan shall contain the list of schemes and projects with the tentative
provisions thereof:
Provided that, while preparing the annual Plan for the next financial year, the sum total of the past
commitments and liabilities spilling over shall be assessed to maintain financial discipline and timely
completion of the projects. The subtotal of the past liabilities and commitments and the new schemes
being proposed shall not in any case exceed two times the expected inflow in the funds for the next
financial year;
(d) Approving expenditure, in furtherance of the objects of the Foundation from the available fund
in such manner provided by the State Government;
(e) Approving the recommendations of the Managing Committee;
(f) Approving the Annual Reports and Audited Accounts of the foundation within a period of sixty
days of the closure of the previous year;
(g) Ratifying the appointments of the Officers on deputation, contract or outsourcing basis as
decided by the State Government to run the Foundation.
(h) Constituting sub-committees for assisting in preparation of Annual Plans of the trust and for
smooth functioning of the trust;
(i)Undertaking any such other activities in furtherance of the objectives of the Foundation.

6

<!-- page 7 -->

8. Meetings of Governing Council.-3[ (a) The Governing Council shall meet as often as necessary
but at least twice in a year.”]
(b) The meeting of Governing Council shall be convened as desired by the Chairperson by giving
two weeks notice to the Members of the Governing council.
(c) The quorum for such meeting shall be one-third of the total members of the Governing
Council. If quorum for meeting is not fulfilled then meeting shall be postponed for half an hour and
shall be reconvened at the same place on the same day for which condition of quorum shall not be
applicable.
CHAPTER III
9. Managing Committee.— (a) The day to day affairs of the trust shall be managed by the
Managing Committee.
(b) The Managing Committee shall consist of all Ex Officio Members of the Trust and any other
nominated members who shall be nominated by the Government.
(c) Only ex officio Members shall have right to vote.
(d) Nominated Members shall not have any voting rights.
(e) The Chairperson of the Managing Committee shall be the respective District Collectors.
10. Powers and functions of Managing Committee.— The following are the powers and
functions of the Managing Committee namely:—
(a) To exercise due diligence in carrying out its duties for protecting the interests of the
foundation.
(b) To ensure timely collection of contribution from the concerned lease holders in accordance
with the provisions of the Act and in the manner provided by the State Government.
(c) To receive proposals or projects from the Village Panchayats, ZillaParishads and the Urban
Local Bodies in the District, Government Departments, Boards, Corporations and State or Central
Public Sector Undertakings or individual proposals routed through any of these agencies.
(d) To co-ordinate, consolidate and develop the Perspective and Annual Plans of the Trust and
Annual Budget of the Trust along with the proposed schemes and projects;
(e) To supervise and ensure the execution of the Annual Plan and the approved schemes and
projects;
(f) To accord sanction and issue sanction orders to the projects release and disburse the fund for
that purpose;
(g) To operate the trust fund and to invest the same in a diligent manner in fixed
deposits/Government Banks/Banks Bond and to open Bank Accounts in Scheduled, Commercial or
Nationalized Banks approved by the Reserve Bank of India in the Name of the Foundation and to
operate such accounts and investments;
(h) To monitor the progress of the utilization of funds;

3
Clause (a) substituted vide Amendment Rules 2025. Original clause read as follows:- “The Governing Council shall meet as often as
necessary but at least once in every quarter.”

7

<!-- page 8 -->

(i) To place the audited accounts along with an Annual Report before the Governing council for its
approval within a period of sixty days of the closure of the financial year;
(j) To lay down and approve procedures for the functioning of the Foundation;
(k) To appoint employees and auditors as per the directions of the State Government. However
these appointments shall require ratification by the Governing Council;
(l) To prepare and maintain a website on which inter–alia the following information shall be
hosted and kept updated–
(a) Details of composition of the foundation and bodies of the foundation.
(b) List of areas and people affected by mining;
(c) Quarterly details of all contributions received from lessees and others;
(d) All meeting agenda minutes and action taken reports of the Foundation;
(e) Annual Plans, budget, work orders and Annual Report;
(f) Online status of ongoing works, implementation status or progress of all the projects or
programmes being undertaken shall be made available on the website, including description of work
details of the beneficiaries, estimated cost, name of the implementing agencies, expected date of
commencement and completion of work, financial and physical progress up to the last quarter etc.;
(g) List of beneficiaries under various welfare programmes;
(h) Voluntary disclosures under Right to Information Act, 2005 (22 of 2005); and
(i) To do all other things that are necessary for the smooth functioning and management of the
Trust.
11. Meetings of Managing Committee.— (a) The meeting of the Managing Committee shall be
held at least four times in a financial year and it shall be convened as decided by the Chairperson.
(b) The quorum for such meeting shall be one–third of the total members of the Managing
Committee. If quorum for meeting is not fulfilled, then meeting shall be postponed for half an hour
and shall be convened at the same place on the same day for which condition of quorum shall not be
applicable.
(c) Meeting of the Managing Committee shall be presided over by the Chairman, in his absence
the ex officio Members may elect officiating Chairman from amongst themselves for that meeting.
12. Trust Fund.— (a) The initial settlement of Rs. 1,000/- (Rupees one thousand only) made by
the Government.
(b) Any grant, contribution or other money received from the Government or from any other
agency, institution or person;
(c) Every mineral concession holder shall pay the contribution fund in respect of any mineral
removed by him from and/or consumed within the areas allotted/permitted to him as follow:
(d) In case of major minerals, as prescribed in the Mines and Minerals (Contribution to District
Mineral Foundation) Rules, 2015 as amended from time to time.
CHAPTER IV
13. Scope of the District Mineral Foundation Trust.— The District Mineral Foundation Trust
shall work for the interest and benefits of person, and areas affected by the mining related operations

8

<!-- page 9 -->

and in particular shall focus on the following areas, as per priorities determined in the Perspective and
annual District Mineral Foundation plans.
(1) High priority areas.— (a) Drinking water supply— Centralized purification systems, water
treatment plants, permanent/temporary water distribution network including standalone facilities for
drinking water, laying of piped water supply system.
[(b) Environment preservation and pollution control measures – Effluent treatment plants,
prevention of pollution of streams, lakes, ponds, ground water, other water sources in the region,
measure for controlling air and dust pollution caused by mining operations and dumps, mine drainage
system, mine pollution prevention technologies, and measures for working or abandoned mines and
other air, water and surface pollution control mechanisms required for environment-friendly and
sustainable mine development. Identification of mineral-specific pollutants and their hazard potential
may be done by involving reputed educational institutes/research institutions. The funds may be
allocated for the identification of the hazards, setting up air quality monitors and displays, and
undertaking measures for the implementation of the recommendations of the research.
4

However, activities meant to be taken up under the “polluter pays principle” or as per the
obligations of the industries under the environment management plan or mines management plan
should not be taken up under the District Mineral Foundation Trusts.]
(c) Health care— The focus must be on creation of primary/secondary health care facilities in the
affected areas. The emphasis should not be only on the creation of the health care infrastructure, but
also on provision of necessary staffing, equipment and supplies required for making such facilities
effective. To that extent, the effort should be to supplement and work in convergence with the existing
health care infrastructure of the local bodies, State and Central Government. The expertise available
with the National Institute of Miners’ Health may also be drawn upon to design special infrastructure
needed to take care of mining related illnesses and diseases. Group Insurance Scheme for health care
may be implemented for mining affected persons.
[(d) Education – The focus shall be on augmentation and development of resources and
infrastructure for improving both secondary and elementary education. This may include construction
of school/college/vocational training institute buildings, additional classrooms, laboratories, libraries,
art and crafts rooms, toilet blocks, drinking water provisions, residential schools, residential hostels
for students of affected areas and teachers in remote areas, sports infrastructure, engagement of
teachers/other supporting staff, e-learning setup, other arrangement of transport facilities
(bus/van/cycles/rickshaws etc.) and nutrition related programs. Financial support to students of
affected areas for pursuing education in Government/Government aided institutions of higher
education.]
5

(e) Welfare of Women and Children— Special programmes for addressing problems of maternal
and child health, malnutrition, infectious diseases, etc. can be taken up under the PMKKKY.
4
Clause(b) substituted vide Amendment Rules 2025 . Original rules read as follows:- (b) Environment preservation and pollution
control measures—Effluent treatment plants, prevention of pollution of streams, lakes, ponds, ground water, other water sources in the
region, measure for controlling air and dust pollution caused by mining operations and dumps, mine drainage system, mine pollution
prevention technologies, and measures for working or abandoned mines and other air, water & surface pollution control mechanisms
required for environment friendly and sustainable mine development. However activities meant to be taken up under the “polluter pays
principle” or as per the obligations of the industries under the environment management plan or mines management plan should not be
taken up under District Mineral Foundation Trusts.
5
Clause(d) substituted vide Amendment Rules, 2025. Original clause read as follows:- (d) Education— The focus must be on
augmentation and development of resources and infrastructure for improving both secondary and elementary education. This may include
construction of school buildings, Additional class rooms, Laboratories, Libraries, Art and crafts room, Toilet blocks, Drinking water
provisions, Residential Hostels for students/teachers in remote areas, sports infrastructure, engagement of teachers/other supporting staff,
e-learning setup, other arrangement of transport facilities (bus/van/cycles/ rickshaws/etc.) and nutrition related programmes.

9

<!-- page 10 -->

(f) Welfare of aged and disabled people— Special programmes for welfare of aged and disabled
people.
(g) Livelihood & Skill development— Skill development for livelihood support, income
generation and economic activities for local eligible persons particularly around local resources such
as agri-based, forest resources, horticulture etc. The projects/schemes may include training,
development of skill development centers, self-employment schemes, support to vulnerable sections
such as women/ women groups/tribal groups, support to self help groups, placement oriented training
to youth and provision of forward and backward linkages for such self-employment economic
activities.
(h) Sanitation— Collection, transportation & disposal of waste, cleaning of public places,
provision of proper drainage & Sewage Treatment Plant, provision for disposal of fecal sludge,
provision of toilets and other related activities.
[(i) Housing –Provision of pucca housing for mining affected people who are not covered under
Central or State schemes.
6

(j) Agriculture – Activities related to agriculture, horticulture and agroforestry. Assistance to
farmers through trainings, support to FPOs/collectives/cooperatives, support for setting up of food
processing units, storage including cold storage, marketing facilities like market yards etc.,,
plantation, processing of medicinal herbs.
(k) Animal Husbandry – Promotion of livestock, poultry, piggery, fishery, feed and fodder
development and supporting innovation in animal husbandry, Farmers Producer Organizations
(FPOs), Self Help Groups (SHGs), Farmer Cooperative Organisations (FCOs).]
(2) Other priority Areas.— (a) Physical infrastructure — Providing required physical infrastructure
— road, bridges, railways and waterways projects with priority in directly affected areas.
(b) Irrigation— Developing alternate sources of irrigation, adoption of suitable and advanced
irrigation techniques.
(c) Energy and Watershed Development— Development of alternate source of energy (including
micro-hydel) and rainwater harvesting systems, augmentation of integrated watershed management
practices, development of orchards, integrated farming and economic forestry and restoration of
catchments.
(d) Any other measures for enhancing environmental quality in mining district. In addition to the
above, the scope will include implementing the objectives specified in Pradhan Mantri Khanij Kshetra
Kalyan Yojana which are not specifically enlisted herein;
CHAPTER V
7

[14. Utilisation of fund by District Mineral Foundation Trust.— (1) The entire amount
collected under sub-sections (5) and (6) of section 9B of the Act and under rule 22A of the Goa Minor
6

Clause (i),(j) and (k) inserted vide Amendment Rules,2025.
7
Rule-14 substituted vide 4th Amendment Rules 2023. Original rules read as follows:- 14. Utilization of Funds by District Mineral
Foundation Trust.— (a) Fifty percent of the amount received in terms of sub-sections (5) and (6) of section 9B during the financial year of
the Act shall be invested by the District Mineral Foundation in fixed deposits or Government bonds/bank bonds. The interest earned on such
investment to the extent of 90% may be utilized for carrying out the works specified in rule 13 and 10% of such interest shall be re-invested
in long term investment so that the corpus of such fund remains permanently enhanced surpassing the period of exploitation of mineral ore
and such fund shall be used in posterity for the benefit of generations to come thereby protecting the rights of the future generations and
creating the inter-generational equity.
(b) The remaining fifty percent of such amount shall also be utilized for carrying the works specified in rule 13, provided that 60% of
such amount shall invariably be utilized for High Priority Areas with emphasis on infrastructural and other projects of permanent nature so
that the benefits of such projects are enjoyed not only by the present generation but also by the generations to come.

10

<!-- page 11 -->

Mineral Concession Rules, 1985 including the interest generated thereon shall be utilized exclusively
for carrying out the works and activities as specified under rule 13, and such utilization shall be in
accordance with the Pradhan Mantri Khanij Kshetra Kalyan Yojana (PMKKKY) Guidelines.
(2) A minimum of 70% of the funds shall be spent in the High Priority areas as specified under
rule 13.
(3) A minimum of 70% of the funds shall be spent only in the directly affected area as specified
under clause (b) of rule 2.
(4) An amount not exceeding 5% of the total annual receipts or such upper limit fixed by the
Government, may be utilized for administrative, supervisory and overhead costs of the District
Mineral Foundation:
Provided that the amount collected under rule 22A of the Goa Minor Mineral Concession Rules,
1985 shall be utilised only in areas affected due to quarrying activities of minor minerals.]
[14A. Restriction on transfer of fund from District Mineral Foundation – (1) No fund shall be
transferred in any manner from the District Mineral Foundation to the State exchequer or State level
fund (by whatever name called) or Chief Minister’s Relief Fund or any other funds or schemes.
8

(2) No sanction or approval of any expenditure out of the fund of the District Mineral Foundation
shall be done at the State level by the Government or any State level agency.
(3) No fund shall be spent other than for directly or indirectly affected areas within a district or for
other than affected persons.
(4) No fund shall be transferred in any manner from one district to another district.
(5) The approval of expenditure of funds from District Mineral Foundation shall lie solely with the
Governing Council. The Government or State Level Monitoring Committee shall not have
overarching authority on sanction of projects, approval of funds/ expenditure and their function shall
be limited to monitoring effective implementation of projects sanctioned under District Mineral
Foundation.]
CHAPTER VI
15. Implementation of projects.— (a) The District Mineral Foundation Trust may implement the
projects consistent with its functions on its own accord or upon receipt of a project proposal from the
Government or upon request from any Government Department.
(b) In implementation of the projects referred to in sub-rule (a), the District Mineral Foundation
may devise its own procedure consistent with the provisions of the Act and the rules made there
under.
(c) The projects shall be executed through Public Works Department, Water Resources
Department, Forest Department, River and Navigation Department, Agriculture Department,
Department of Animal Husbandry and Veterinary Services, Goa State Infrastructure and Development
Corporation or any other Departments of the Government of Goa, as per the directions and decision of
the District Mineral Foundation Trust.

(c) An amount not exceeding 2.5% of the annual receipts of the Foundation subject to an upper limit fixed by State Government may be
utilized for administrative, supervisory and overhead costs of the Foundation.
Thereafter present provisions are substituted vide Amendment Rules, 2025.
8
Rule 14 A inserted vide Amendment Rules, 2025.

11

<!-- page 12 -->

(d) The District Mineral Foundation Trust shall periodically monitor implementation of the
projects either by itself or by engaging services of any Government Department or an approved
agency.
9

[(e) The Government shall set up a Project Management Unit (PMU) at the State level.
The Project Management Unit shall assist the District Mineral Foundation in planning,
supervising, monitoring works undertaken by the District Mineral Foundation.]
10

[15A. Constitution of State Level Monitoring Committee.— (1) The Government
shall constitute a State Level Monitoring Committee consisting of the following members,
namely:—
(i) Chief Minister
(ii) Minister for Mines/Minister from Mining affected Areas
(iii) Chief Secretary
(iv) Secretary (Mines)
(v) Secretary (Finance)
(vi) Director, Mines and Geology
(vii) Principal Chief Engineer, Public Works Department
(viii) Director, Environment and Climate Change
(ix) Director, Public Health Services
(x) Director, Education
(xi) Director, Higher Education
(xii) Director, Technical Education
(xiii) Director, Women and Child Development
(xiv) Director, Social Welfare
(xv) Director, Department of Empowerment of PwD
(xvi) Director, Skill Development and Entrepreneurship
(xvii) Director, Agriculture
(xviii) Director, Animal Husbandry and Veterinary Services
(xix) Chief Engineer, Water Resources Department
(xx) Director, Department of New and Renewable Energy
(xxi) Director, Panchayat
(xxii) Director, Urban Development
(xxiii) Director, Department of Rural Development
(xxiv) Representative of Ministry of Mines, Government of India

..Chairperson
...Member
...Member
...Member
...Member
...Member Secretary
...Member
...Member
...Member
...Member
...Member
...Member
...Member
...Member
...Member
...Member
...Member
...Member
...Member
...Member
...Member
...Member
...Member
…Member”]

(2) The State Level Monitoring Committee shall monitor the works undertaken by
the District Mineral Foundation.”
Note: The Principal Rules were published in the Official Gazette, Series I No. 41 dated
10-01-2019
and
subsequently
amended
vide
the
Government
Notification
No. DMG/MMDR/DMF/01/2015/8040 dated 13-02-2019, published in the Official Gazette, Series I
No. 47 dated 21-02-2019.]
CHAPTER VII
11

[16. Five Years Perspective Plan and Annual Plan.— (1) The District Mineral Foundation
shall conduct a baseline survey through Academic Institutions/Renowned organisations/agencies for
perspective plan formulation.
9

Inserted vide Se c ond Amendment Rules, 2021; published in the Official Gazette Series I No. 4 dated 22nd April, 2021.
Inserted vide Se c ond Amendment Rules, 2021; published in the Official Gazette Series I No. 4 dated 22nd April, 2021.and clause (1)
substituted vide Amendment Rules 2025.
10

12

<!-- page 13 -->

(2) Based on the findings and gaps as identified through the baseline survey or any such
survey/assessment, the District Mineral Foundation shall prepare a strategy for five years and the
same shall be included in the Perspective Plan.
(3) The Five Year Perspective Plan shall be prepared taking into account current balance available
and likely accrual to the District Mineral Foundation over a period of five years.
(4) The Five Year Perspective Plan shall be approved by the Governing Council.
(5) The Annual Plan of the District Mineral Foundation to be approved by Governing Council each
year shall be based upon the five year perspective plan and success achieved in fulfilling its targets in
earlier years. The Annual Plan may include some other works and expenditures considered urgent in
nature although not included in the perspective plan.
(6) The annual plan shall contain all the projects, programmes, activities proposed to be
undertaken by the District Mineral Foundation and shall have clearly demarcated milestones.]
17. Annual Budget.— The Managing Committee shall, at the beginning of each financial year,
cause preparation of an annual budget containing the details of the proposed income and expenditure
on activities covered in the annual plan for that particular financial year, including the legal,
administrative and other costs and expenditure proposed to be incurred by the District Mineral
Foundation Trust together with details of the funding requirements in this regard, to be referred as the
annual budget.
18. Approval of the Annual Plan and the Annual Budget.— (a) The annual plan and the annual
budget shall be laid before the District Mineral Foundation Trust for its approval.
(b) Without prejudice to the above provisions, the District Mineral Foundation Trust may
undertake expenditures for activities that are not approved in the annual plan subject to specific
approval by the Governing Council.
(c) The annual plan and related annual budget may be amended at any time subject to the approval
of the Governing Council.
19. Annual Report.— (a) The Managing Committee shall, within ninety days of the end of each
financial year, submit an annual report containing such information as deemed appropriate by the
District Mineral Foundation Trust.
(b) The annual report shall be approved by the District Mineral Foundation Trust and shall contain
details, inter alia, of the activities completed by the District Mineral Foundation Trust during the
financial year and the expenditure incurred by the District Mineral Foundation Trust during such
financial year.
(c) A copy of the annual report shall be sent to the Government within a period of thirty days from
the date of its approval by the District Mineral Foundation Trust.

11
Rule 16 substituted vide Amendment Rules 2025. Original rule read as follows:- 16. Annual Plan.— The Managing Committee shall,
at the beginning of each financial year, cause preparation of plans for short term projects and long term projects proposed to be undertaken
by the District Mineral Foundation Trust in the relevant financial year, to be referred as the annual plan, together with details of the
activities to be undertaken or completed by the District Mineral Foundation Trust during such time, the expected time for completion of the
projects and cost for such projects.
The annual plan shall contain all the projects, programmes; activities proposed to be undertaken by the District Mineral Foundation
Trust and shall have clearly demarcated milestones.

13

<!-- page 14 -->

12

[(d) The Annual Report of each District Mineral Foundation shall be laid before the State
Legislative Assembly]
20. Charging of Expenses.— The Trustees shall be entitled to charge the Trust fund with the
following expenses, namely:
(a) All expenses properly incurred in the operation or execution of the Trust and for the realization,
preservation or benefit of the investments and assets comprising the Trust fund and for the protection
of the interest of the Trust.
(b) All expenses (including expenses incidental to execution as and or registration of any
agreement or other deeds) incurred by the Trustees for obtaining the contributions and or any other
resources which may accrue.
(c) All expenses in connection with any legal proceedings by or against the Trustee concerning the
affairs of the Trust including professional fees and costs of any legal advisor.
(d) All legal and statutory expenses incurred in the operation or execution of the Trust including all
levies, duties and other charges paid/payable in connection with the affairs of the Trust.
(e) All expenses in connection with the holding of its meeting and other proceedings as per the
norms of the State Government.
21. Financial Year.— (a) The accounting or financial year of the District Mineral Foundation
Trust shall be from 1st April to the 31st of March.
(b) The first year of operations of the District Mineral Foundation Trust may be a partial year.
13

[22. Accounts and Audit.— (a) The Managing Committee shall maintain or cause to be
maintained proper books of accounts, documents and records with respect to the District Mineral
Foundation fund to give a true and fair picture of the affairs of the District Mineral Foundation.
(b) The accounts of the District Mineral Foundation shall be audited by the Comptroller and
Auditor General (CAG) as per the schedule decided by CAG.
(c) The accounts of the District Mineral Foundation shall be internally audited every year by a
Chartered Accountant appointed by the District Mineral Foundation, or in such other manner as the
Government may specify, and the report thereof shall be placed in the public domain along with the
Annual Report.
(d) The internal Auditors of the Foundation shall be appointed by the Governing Council from the
list of Chartered Accountants empanelled by the Comptroller and Auditor General of India on such
terms and conditions as decided by the Governing Council.
(e) The internal Auditors may be removed and replaced by the Governing Council.]

12

Clause(d) inserted vide Amendment Rules 2025
13
Rule 22 substituted vide Amendment Rules 2025. Original Rule read as follows:- ”22. Accounts and Audit.— (a) The Managing
Committee shall maintain or cause to be maintained proper books of accounts, documents and records with respect to the Foundation fund
to give a true and fair picture of the affairs of the Foundation.
(b) The accounts of the Trust shall be audited at least once on completion of a year by a qualified Auditor.
(c) All District Mineral Foundation Trusts should undertake both financial and performance audits to ensure optimal fiscal discipline
and transparency of operation.
(d) The Auditors of the Foundation shall be appointed by the Governing Council from the list of Chartered Accountants empanelled by
the Comptroller and Auditor General of India on such terms and conditions as decided by the Governing Council.
(e) The Auditors may be removed and replaced by the Governing Council.
(f) The State Government may appoint an auditor or auditors or may request the Accountant General of the State for audit of a particular
year or period on such terms as the State Government may so decide.

14

<!-- page 15 -->

23. Liability of Trustees.— (a) The Trustees shall not be liable on account of anything done in
good faith, bonafide with due diligence. The Trustees shall also not be liable or responsible for any
banker, broker, custodian or other person in whose hands the same may, in good faith, be deposited or
placed nor for deficiency or insufficiency in the value of any investments of the Trust fund nor
otherwise for any involuntary loss.
(b) The Trustees and every attorney or, agent appointed by the Trustees shall be entitled to be
indentified out of the Trust fund in respect of all liabilities losses and expenses incurred in execution
of the Trust or any of the powers, authorities and discretion vested in or delegated to them other than
those arising out of gross negligence and or wilfull misconduct, provided however that such
indemnity shall not in any event exceed the total of the contribution.
24. Remuneration.— The Trustees shall not be entitled to any remuneration for their services.
14

[24A. Grievance Redressal.—(1) The District Mineral Foundation shall devise and implement a
grievance redressal mechanism so that each grievance is redressed, and a suitable reply is given to the
complainant within 30 days of making a complaint to the Collector of the concerned District or any
other officer as may be appointed by the Government.
(2) The Collector of the concerned District or the officer appointed by the Government, on receipt
of any complaint/public grievance, shall ensure that each grievance is redressed by the District
Mineral Foundation and a suitable reply is given to the complainant within the stipulated timeframe.
(3) Upon receipt of any complaint/public grievance/reference from the Central Government
regarding improper utilization of District Mineral Foundation funds, poor implementation of projects
or violations of PMKKKY guidelines, the Government shall act in accordance with the PMKKKY
guidelines.
24B. Compliance Mechanism.—In case, a District Mineral Foundation
(i) fails to comply the provisions under rule 7 and 10;
(ii) transfers any fund in violation of rule 14A;
(iii) fails to prepare annual report as provided under rule 19;
(iv) fails to get the accounts audited as provided under rule 22;
(v) fails to comply the provisions under rule 24A;
the Government may direct suspension of sanction of any or all new works or execution of any or
all of already sanctioned works; and/or suspension of release of funds for any or all the works by the
bank(s) where District Mineral Foundation fund is deposited or the bank account of the executing
agencies where funds have been transferred from District Mineral Foundation:
Provided that the Government may, after being satisfied that necessary corrective measures have
been taken, withdraw such suspension.]
25. Repeal and Savings.— (a) 15[The Goa District Mineral Foundation Rules, 2016] are hereby
repealed.
(b) Notwithstanding such repeal, anything done or any action taken or orders passed under the said
rules shall be deemed to have been done or any taken or passed under the section 15 read with subsections (2) and (3) of section 9B of the Mines and Minerals (Development and Regulation) Act, 1957
14
15

Rule 24-A and 24-B inserted vide Amendment Rules,2025.
Substituted vide Amendment Rules 2021 published in the Official Gazette Series-I No. 41 (supplement) dated 6-1-2022

15

<!-- page 16 -->

(Central Act 67 of 1957) and all other powers enabling it in this behalf shall be deemed to have been
done, taken or passed under these rules.
By order and in the name of the Governor of Goa.
Prasanna A. Acharya, Director & Additional Secretary (Mines).
Panaji, 8th January, 2019.

16
