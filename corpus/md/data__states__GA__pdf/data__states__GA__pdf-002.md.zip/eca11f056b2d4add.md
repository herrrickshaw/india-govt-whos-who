---
doc_id: "eca11f056b2d4add"
source_url: "https://nhm.goa.gov.in/wp-content/uploads/2020/09/gpstender.pdf"
ministry: "Directorate of Health Services, National Health Mission, Goa"
title: "Tender Notice for GPS (Dated 15/09/2020)"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "e55baa51a5fa005c"
---

<!-- no text layer: pending OCR -->
