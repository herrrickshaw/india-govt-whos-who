---
doc_id: "5fbf05abecf148c3"
source_url: "https://dte.goa.gov.in/sites/default/files/boardruleshandbook.pdf"
ministry: "Directorate of Technical Education, Goa"
title: "Click here to download for more info"
date: ""
pages: 66
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b057200f73a85e83"
---

<!-- page 1 -->

INDEX
Contents

Pg.
Nos.

1. Introduction

1

2. Approved rules of Diploma in Engineering &

5

Technology

3. Approved rules of Diploma in Hotel Management
& Catering Technology

21

4. Approved rules of Diploma in Pharmacy

28

5. Guidelines & Procedures

36

6. Duties & Responsibilities of Officer-In- Charge
(Examination)

54

7. Duties & Responsibilities of Invigilator

56

8. Duties & Responsibilities of Officer-In- Charge
(Assessment Centre)

57

9. Duties & Responsibilities of Examiners

58

1

<!-- page 2 -->

INTRODUCTION
Establishment of Directorate of Technical Education, Goa
The Directorate of Technical Education, Goa was established in
the year 1986 to promote Technical Education in the state of Goa. The
primary function of the D.T.E. is giving permission to set up new
colleges, to introduce new Diploma course, admissions to Degree &
Diploma courses, administration & monitoring the functioning of
Engineering colleges, Polytechnics, Hotel Management, Pharmacy,
Architecture & Art colleges under its control.
Establishment of Board of Technical Education, Goa (formarly
Board of Technical Examination)
The cabinet approved the establishment of the Board of
Technical Education as a Government Department under Directorate
of Technical Education on 2nd July,1987 and the notification
regarding constitution of Board of Technical Education was issued on
5th February, 1988.
As per the said notification, Director of Technical Education is
the Ex-Officio Chairman of Board of Technical Education and
Secretary, Board of Technical Education is the Member Secretary and
the other members are drawn from various Institutions, Industries &
Private/Public sector organisations.
The

Board

of

Technical

Education

was

formed

as

an

administrative and executive body to frame the curriculum, to lay
dawn rules & regulations related to academic performance of students
of all Polytechnics and other Institutions affiliated to the Board and to
award Diploma certificates to successful candidates. At present there
are five Polytechnics, two Hotel Management Institutions & one
Institution conducting Diploma in Pharmacy course affiliated to the

2

<!-- page 3 -->

Board.

The

various

Diploma

programmes

conducted

by

the

Institutions are:
Sr.No. Name of the Institute
01

02

03

04

Govt. Polytechnic, Panaji

Agnel Polytechnic, Verna

Institute of Shipbuilding
Technology, Vasco.

Govt. Polytechnic, Mayem,
Bicholim.

Diploma Programme

Duration

Civil Engg.

3 yrs.

Mechanical Engg.

3 yrs.

Electrical Engg.

3 yrs.

Electronics &
Instrumentation Engg.
Electronics & Engg.

3 yrs.

Food Technology

3 ½ yrs.

Fabrication Technology &
Erection Engg.
Garment Technology

4 yrs.

Architectural Engg.

3 yrs.

Modern Office Practice

3 yrs.

Computer Engg.

3 yrs.

Mechanical Engg.

3 yrs.

Automobile Engg.

4 yrs.

Civil Engg.(Construction
Technology)
Computer Engg.

4 yrs.

Electronics & Engg.

3 yrs.

Electronics &
Communication Engg.
Medical Electronics

3 yrs.

Mechanical Engg.

3 yrs.

Shipbuilding Engg.

4 yrs.

Electronics &
Communication Engg.
Civil Engg.

3 yrs.

Mechanical Engg.

3 yrs.

Electrical Engg.

3 yrs.

Mining Engg.

3 yrs.

Electronics &
Communication Engg.

3 yrs.

3 yrs.

3 yrs.

3 yrs.

3 yrs.

3 yrs.

3

<!-- page 4 -->

05

Govt. Polytechnic, Kakoda,
Curchorem.

06

Goa College of Pharmacy, Panaji

07

Guardian Angel Institute of Hotel
Management
&
Catering
Technology, Curchorem
Fr. Agnel Institute of Food Craft &
Culinery Sciences,
Verna.

08

Mechanical Engg.

3 yrs.

Computer Engg.

3 yrs.

Electrical &
Electronics Engg.
Pharmacy

3 yrs.

Hotel Management &
Catering Technology

3 yrs.

Hotel Management &
Catering Technology

3 yrs.

2 yrs.

Admission to Diploma Programmes:
The

Directorate

of

Technical

Education

conducts

centralised

admission to various Diploma programmes. The details regarding the
eligibility of the candidates and the admission procedure are given in
the Prospectus published by the D.T.E. every year.
Mode of conduct of Examinations:
Diploma in
Engineering &
Technology
Programmes
Diploma in Hotel
Management &
Catering
Technology
Diploma in
Pharmacy

Semester Two examinations are conducted at
System
the end of every term (Odd & Even) in
addition to internal assessment (Test
& Term Work) conducted by the
Institution.
Annual
Two examinations are conducted every
System
year (Annual & Supplementary) in
addition to internal assessment (PAProgressive Assessment) conducted by
the Institution.
Annual
Two examinations are conducted every
System
year (Annual & Supplementary) in
addition
to
internal
assessment
(Sessional)
conducted
by
the
Institution.

4

<!-- page 5 -->

The examinations are conducted as per the prescribed Teaching
& Examination scheme. The medium of instruction for all Diploma
programmes is English.

5

<!-- page 6 -->

APPROVED RULES FOR DIPLOMA IN ENGINEERING & TECHNOLOGY

Rule1: ENROLLMENT WITH B.T.E.:
Candidates

provisionally

admitted

for

the

Diploma

Programmes by the Centralised Admission Committee/Directorate
of Technical Education, Goa only shall be eligible to enroll with
the Board.
Such candidates on reporting to the institution shall enroll
themselves with the Board and obtain the Enrollment Number
from the concerned institute by filling up the enrollment forms and
paying the prescribed fees within ten working days from the date of
grant of admission in the respective round of centralised
admission, failing which the admission granted is liable to be
cancelled.
The Enrollment form must be attached with attested copies
of documents indicated below.
Candidates

admitted

to Candidates admitted directly

I Semester/Year

to III Semester/II Year

1.X std. Board Marksheet

For candidates admitted under
Vocational Category:

2.XII std. Board Marksheet
[wherever
the
minimum 1.X std. Board Marksheet
qualification is XII]
2.XII std.(Vocational) Board
Marksheet
3.Admit Card
3.Admit Card
For candidates admitted under
I.T.I Category:
1.X std. Board Marksheet
2.N.C.V.T certificate
3.Admit Card

6

<!-- page 7 -->

Rule 2: REGISTRATION FOR EXAMS:
A candidate intending to appear for a semester examination
shall fill up the Examination form, pay the prescribed fees and
submit the same to the Institute before the due date notified by the
Board. Regular students are compulsorily required to fill up
the examination forms and register for examinations of the
semester in which they are currently studying. (pls. refer to
Annexure I for details of procedure for submission of Examination
form.)
Notwithstanding

the

submission

of

Examination

form,

payment of examination fees and allotment of examination seat
number, the admission to examination of the relevant semester
shall be cancelled if a candidate fails to fulfill the condition for
grant of term & admission to examination laid down in rule 4(i).
The examination fees paid by the candidate shall be non
refundable.
Notwithstanding the acceptance of Examination form and
fees, allotment of seat number by the Board, the performance/
result of the applicant at the examination would be cancelled if it is
later found that the applicant was not eligible for admission to the
relevant semester/year and for admission to the said examination.
Rule 3: GRANTING OF EXEMPTION:
A candidate who has passed the examination fully (i.e. in all
the passing heads) in a subject, the examination for which was
conducted by B.T.E., Goa, and declared to be equivalent to a
subject that is currently examined, by the Equivalence Committee of
the Board, shall at his/her option, claim exemption in the subject.
If a candidate has availed exemption in subject/s of a
semester, then he/she shall not be entitled for class to that
semester examination. Exemption so admissible will lapse if not

7

<!-- page 8 -->

claimed/availed at the time of enrollment.
Rule 4: GRANT OF TERM & ADMISSION TO EXAM:
i) A student will be granted term for a semester only when he/she
has:
1. Put in satisfactory attendance of atleast 75% of the total
lectures/ periods in Theory & Practicals separately in each and
every subject of the semester as prescribed in the Teaching and
Examination scheme.
In case the attendance falls short by not more than 10% due to
illness (certified by a Registered Medical Practitioner) or for any
other reasons considered valid, the Principal may condone such
deficiency and grant the term, if the candidate is otherwise eligible.
In any case, no candidate with less then 65% attendance in any
subject of a semester, shall be granted term.
2. Satisfactorily completed the Practicals, Term work, etc as
prescribed in the syllabus and secured the minimum percentage of
marks for passing in the term work.
3. Shown good conduct and character.
4. Registered for semester examinations in respect of the semester
in which he/she is currently undergoing study.
A student who does not fulfill the above conditions will be
declared as Term Not Granted (TNG) and shall not be permitted to
appear for the relevant semester examination. Such students shall
be required to repeat the entire term as a fresh candidate, and the
marks obtained by him/her, will stand cancelled automatically.
However, they can appear for examinations of the lower semesters.
ii) A student on grant of term automatically becomes eligible to
appear for the relevant semester examinations. Further, his/her
eligibility to go to higher semester is decided as per the ATKT rules
(rule 5).

8

<!-- page 9 -->

A student who has been granted term but could not appear at
the semester examination may appear for subsequent examination
as an ex-student.
Rule 5: ATKT RULES:
Non Sandwich

Sandwich

SemesterI- A student who has been granted A student who has been granted
SemesterII term in Semester-I, will be allowed term in Semester-I, will be
to keep
term
(go
to)
of allowed to keep
term (go to) of
Semester-II irrespective of the Semester-II irrespective of the
results of semester-I exams.
results of semester-I exams.
SemesterII- A student who has been granted A student who has been granted
SemesterIII term for Semester-II,will be allowed term for Semester-II, will be
to keep term (go to) of Semester- allowed to keep
term (go to) of
III provided he/she has not failed Semester-III
provided
he/she
in
more than
6
subjects of has not failed in more than 6
Semester-I &II taken together.
subjects of Semester-I &II taken
together.
SemesterIII- A student who has been granted A student who has been granted
SemesterIV term for Semester-III shall be term for Semester-III shall be
permitted to keep term (go to) of permitted to keep term (go to) of
Semester-IV and
also
answer Semester-IV and also
answer
Semester-IV
exams.
However, Semester-IV
exams.
However,
he/she shall not be permitted to he/she shall not be permitted to
answer more than 6 subjects of answer more than 6 subjects of
lower semesters.
lower semesters.
SemesterIV- A student who has been granted A student who has been granted
SemesterV term for Semester-IV shall be term for Semester-IV shall be
permitted to keep term (go to) of
permitted to keep term (go to) of
Semester-V
and
also
answer Semester-V
and also answer
Semester-V exams provided he/she Semester-V
exams.
However,
has not failed in more than 9 he/she shall not be permitted to
subjects of Semester-I,II,III & IV taken answer more than 10 subjects of
together. However, he/she shall not lower semesters.
be permitted to answer more than 6
subjects of lower semesters.
SemesterV- A student who has been granted A student who has been granted
SemesterVI term for Semester V shall be term for Semester V shall be
permitted to keep term (go
to)
permitted to keep term (go to) of
of Semester-VI andalso
answer Semester-VI and also answer
Semester-VI exams. However, he/she Semester-VI
exams.
However,
shall not be permitted to answer he/she shall not be permitted to
more than 6 subjects of lower answer more than 6 subjects of
semesters.
lower semesters.

9

<!-- page 10 -->

SemesterVISemesterVII

--------

SemesterVIISemesterVIII

---------

A student who has been granted
term for Semester-VI shall be
permitted to keep term (go to) of
Semester-VII and also answer
Semester-VII
exams
provided
he/she has not failed in more
than 9 subjects of Semester-I,II,III,
IV,V & VI taken together.
However, he/she shall not be
permitted to answer more than 6
subjects of lower semesters.
A student who has been granted
term for Semester VII shall be
permitted to keep term (go to) of
Semester-VIII and also
answer
Semester-VIII
exams.
However,
he/she shall not be permitted to
answer more than 10 subjects of
lower semesters.

For sandwich programmes, wherever it is a Training semester,
a student who has been granted term of the previous semester, will
be allowed to go for training and also answer the examinations of
the training semester. However, he/she shall not be permitted to
answer more than 10 subjects of the lower semesters.
Any student who is not a regular student (i.e. not keeping
terms for current semester), for whatsoever reason, shall be
permitted to answer not more than 12 subjects.
Rule 6: STANDARD OF PASSING:
I) "Theory", "Practical/Oral" and "Term Work" shall be separate
heads of passing.
i) To pass in the head "Theory" the following conditions will apply:
1.The marks under the head "Theory" shall be aggregate of
marks

obtained

in

theory

examination

conducted

by

the

Board (referred to as TH) and Test marks, which is the average of
the marks obtained in two tests to be conducted by the institute
during the semester (referred to as TM).

10

<!-- page 11 -->

2.The examination in theory paper (TH) shall be out of 75 marks
and Test marks (TM) shall be out of 25 marks. The total marks
under the head “Theory” shall be TH+TM=75+25=100.
3.To pass in the head "Theory", a candidate will be required to
obtain atleast 30 marks in theory examination and atleast 40
marks in aggregate of the theory marks and the test marks for that
subject.
4.There shall be no minimum marks for passing in tests.
5. A candidate obtaining less then 30 marks in the theory
examination inspite of obtaining 40 or more marks in aggregate of
theory examination and test will be declared as "Fail" in the head
"Theory".
ii) To pass in the heads "Practical/Oral" and "Term Work" a
candidate will have to obtain atleast 40% of the maximum marks
assigned to these heads. A candidate failing in Term Work of one
or more subjects shall not be granted term and he/she will have
to repeat the entire semester.
iii) Fraction of marks obtained shall be rounded off to the next
higher digit.
II) Candidates passing in all subjects of a semester examination
shall be awarded a class (pls. see rule 8 – award of class).
Candidates failing in one or more subjects of a semester
examination shall be declared Fails/ATKT or Fails as per the ATKT
rule (pls. see rule 5).
Candidates passing in the final semester examination but having
backlog shall be declared WFLS i.e. Withheld failing lower semester
examinations. (pls. refer to Annexure II for details of guidelines on
Internal assessment & Annexure III for details of guidelines on
Display & Maintenance of internal evaluation records.)

11

<!-- page 12 -->

Rule 7: CARRYING FORWARD OF MARKS:
A candidate declared to have passed in a subject/s of a
semester examination OR Declared to have failed in a subject/s
but obtained pass marks in one or more heads of the subject/s
(i.e.Theory, Practical/Oral, TW), shall not be allowed to reappear in
the subject/subject heads in which he/she has passed, but the
marks obtained in these subjects/subject heads in the previous
examination shall be carried forward for deciding his/her total
marks. The candidate shall also be entitled to get a class, as and
when he/she passes in all the subjects, prescribed for that
semester.
Rule 8: AWARD OF CLASS:
Class shall be awarded to a successful candidate based on the
percentage of aggregate marks obtained by him/her in a semester
examination as indicated below:
75% and above Distinction
60% and above First class
45% and above Second class
40% and above Pass class
While deciding the minimum marks required for Distinction,
First Class, Second Class, fraction of marks shall be rounded to
the next higher number.
For example, where the Max. marks is 975, minimum marks
required for Distinction will be 975 x 0.75 = 732. (731.25 rounded
to the next higher number)
Also, in case of semester examination for training only
(sandwich pattern), successful candidates shall be declared
“Passes”. No separate class shall be awarded.
Award of class leading to award of diploma will be determined
by the sum total of the aggregate marks obtained at the last two

12

<!-- page 13 -->

semester examinations. However for the Sandwich programmes,
sum total of the aggregate marks obtained at the last two semester
examinations excluding the Training semesters shall be considered
for the award of class leading to the award of diploma.
Rule 9: AWARDING MARKS TO GET A CLASS:
If a candidate falls short of maximum half percent (½ % of the
aggregate marks assigned to the examination) to obtain 75% marks
(i.e. Distinction) or 60% marks (i.e. First class) or 45% marks (i.e.
Second class), such deficiency will be made up by adding upto a
maximum of ½ % of the aggregate marks assigned to the
examination to the total marks obtained by the candidate.
While computing the value of ½ % of the aggregate marks,
fraction of marks shall be rounded to the next higher number.
Rule 10: AWARDING GRACE MARKS:
i) Grace marks will be limited to three subjects only, provided
he/she has passed in all other subjects of the semester
examination. If a candidate has failed in more than three subjects,
he/she shall not be entitled to get any grace marks in any subject.
ii) Grace marks upto a maximum of 3 shall be awarded for a theory
paper of 75 marks & above. The marks can be awarded either in
theory exam or in aggregate or split between both if required so
provided that the candidate has passed in all the other heads of
passing in the subject.
iii) No grace marks shall be given in Practical/ Oral, Term Work.
Rule 11: AWARDING CONDONATION MARKS:
A candidate who fails to pass a semester examination by not
more

than

10

marks,

his/her

deficiency

in

marks

(Theory/Practical heads) shall be condoned subject to the
following conditions:
1. Candidate has appeared in full examination.

13

<!-- page 14 -->

2. Candidate has not availed any exemption.
3. Candidate

has

secured

minimum

50%

marks

in

aggregate.
4. Candidate has failed in not more than two subjects.
A candidate who is getting benefit of condonation is also
eligible for class, such as Distinction, First class, Second class.
However, the total number of marks secured by a candidate
receiving benefit of condonation under the above rule shall remain
unaltered and a "+" sign, meaning condonation, will be shown
against the result.
Rule 12: IMPROVEMENT IN TEST MARKS:
i) Improvement of Test Marks is applicable only in case of failure
in the head "Theory" and hence the Board examination marks are
not carried forward.
ii) Appearance for Improvement of Test Marks is limited to one
chance

per

subject

only in

the

next

corresponding

term

immediately after the results of regular appearance. Thus
appearance for odd semester subject is permissible in odd
semester and even semester subjects in even semester.
iii) However, students granted term for the last two non training
semesters leading to award of diploma can appear for improvement
of test marks in the immediate next term.
iv) A student can appear for maximum of three subjects in any
semester for Improvement of Test marks. A Student should have
registered for the theory examination of the subject in which
he/ she is appearing for improvement of test marks.
v)The student having applied for Improvement of Test Marks shall
appear for two tests and the average of the marks obtained in the
two tests will be considered.
vi)The marks obtained in the test improvement will be considered

14

<!-- page 15 -->

in case of increase in marks only. Otherwise pre-existing marks
will be carried forward.
(pls. see Annexure IV for details of procedure for submitting
application for Improvement of Test marks.)
Rule 13A: GENERAL VERIFICATION OF MARKS BY BOARD
OFFICE:
Any candidate may apply to the Secretary for general
verification of marks in any theory subject within the period
notified by the Board.
(pls. see Annexure V for details of procedure for General
verification of marks.)
Rule 13B: ISSUE OF PHOTOCOPIES OF ANSWSERBOOKS FOR
INSPECTION:
Any candidate may apply to the Secretary for photocopies of
his/her own answer book (in Theory papers) for perusal only
within the period notified by the Board.
(pls. see Annexure VI for details of procedure for Issue of
photocopies of answer books for inspection.)
Rule 13C: VERIFICATION OF MARKS IN PRESENCE OF
CANDIDATE:
Any candidate may avail the facility of verification of marks in
theory papers in his/her presence by submitting an application
to the Secretary within the period notified by the Board.
(pls. see Annexure VII for details of procedure for Verification of
marks in presence of candidate.)
Rule 13D: REVALUATION OF ANSWERBOOKS:
Any candidate may apply to the Secretary for revaluation of
answer book in theory paper within the period notified by the
Board.
(pls. see Annexure VIII for details of procedure for Revaluation of
answer books)

15

<!-- page 16 -->

Rule 14: ISSUE OF STATEMENT OF MARKS:
A Statement of Marks shall be issued only to the successful
candidate after declaration of results.
(pls. see Annexure IX for details of procedure for Issue of
Statement of marks)
Rule 15: AWARD OF DIPLOMA CERTIFICATE:
A

candidate

who

successfully

passed

all

semester

examinations prescribed for that Programme, and completed the
prescribed practical training wherever applicable will be awarded
diploma through head of Institute after a period of six months
from the date of declaration of results provided there is no
complaint of malpractice, fraud, improper conduct etc. against the
candidate.
Rule 16: ISSUE OF DUPLICATE DIPLOMA:
In case of damage, loss or theft of diploma certificate a student
may submit an application along with prescribed fee for issue of
duplicate diploma.
(pls. see Annexure X for details of procedure for Issue of
duplicate diploma certificate)
Rule 17: IMPROVEMENT OF CLASS:
A candidate declared to have completed a Diploma Programme
will, at his/her option, be permitted to reappear in the subjects of
last two non training semesters leading to the award of diploma in
one and the same seating within a period of one year, to enable
him/her to improve his/her class, provided he/she applies in the
prescribed form for improvement of class through the Principal of
the Institute within two months from the date of declaration of the
results leading to award of Diploma. The candidate so permitted: Will be required to reappear and pass in all the theory subjects of
last two semester examinations (excluding training semesters).

16

<!-- page 17 -->

Such a candidate will be permitted to avail only one chance to
improve his/her class.
Will be required to reappear as an ex-student and his Term Work,
Test Marks, Practical/Oral, Project marks, etc wherever applicable
shall only be carried forward.
iii) Will be required to forfeit the Diploma awarded, statement of
marks of the last two semester examinations and other documents
he/she is entitled to, in case he/she improves the class.
Rule 18: IMPROVEMENT OF QUALIFICATION:
A candidate having completed any diploma programme from this
Board may take admission to another diploma programme. Such a
candidate will be awarded additional Diploma provided he/she
appears and passes in all prescribed subjects of the additional
diploma

programme.

However,

a

candidate

may

claim

for

exemptions in subjects as per rule 3.
Rule 19: TIME LIMIT TO COMPLETE THE DIPLOMA
PROGRAMME:
A student who is unable to complete the diploma within double
the duration of respective diploma programme will be exited from
the system. He/She shall be issued with final mark sheet subject
to submission of leaving certificate from the Institute.
Rule 20: ACTS OF MISCONDUCT AND/OR MALPRACTICE:
Students reported to have been involved/suspected to be
involved in misconduct and/or malpractice during the examination
shall be penalised with appropriate penalties as decided by the
Special Committee/Principal of the Institute, as per the case, as
prescribed in the schedule of Penalties for malpractice cases.
(pls. refer to Annexure XI for details of Unfair means/Malpractice,
Annexure XII for details of procedure for Dealing with Malpractice
cases &

Annexure XIII for details of Schedule of Penalties for

Malpractice cases.

17

<!-- page 18 -->

Rule21:
AMENDMENT
OF
RESULTS
AFFECTED
BY
MALPRACTICE:
In case where the result of an examination has been declared
and it is later found that the result had been affected by
malpractice, fraud or any other improper conduct, whereby a
candidate has been benefited or otherwise and candidate has
been party to malpractice, fraud or improper conduct, such cases
shall be placed before the Special Committee of the Board. The
Chairman of the Board, as per the decision of the Special
Committee, shall have the powers to amend the result of such
candidate at any time not withstanding the issue of Diploma and
make such declaration, as he shall consider necessary in the
matter.
Rule 22: MODERATION OF ASSESSMENT WORK:
Wherever necessary, the Board shall adopt suitable method
for moderation of assessment work.
Rule 23: ERROR IN RESULT:
Cases of errors in results, if any, shall be reported to the Board
through the Institute within shortest period after declaration of
result. However any complaint lodged after six months from the
date of declaration of the result will not be considered. All cases of
error in result shall be placed before the Chairman of the Board.
The Chairman of the Board shall have the powers to amend the
result in such a manner as shall be in accordance with the true
position. All such cases shall be placed in the Board meeting for
the post facto approval of the Board.
Rule 24: DEALING WITH DISCREPANCY IN QUESTION PAPER:
Cases of discrepancies in Question paper, if any, shall be
reported to the Board office through the Institute within 5 days of
such occurrence and if there is substance in the complaint,
Secretary shall put such matter before the Special Committee for

18

<!-- page 19 -->

appropriate decision. The decision of the Special Committee will
not be reviewed in any circumstances. In any case, complaints
received after one month of completion of examination will not be
considered.
Rule 25:
PRESERVATION OF RECORDS OF INTERNAL
ASSESSMENT AND PRACTICAL EXAMINATION BY THE
INSTITUTE:
The records of the internal assessment, practical examination,
project, etc. shall be preserved by the institute for a period of one
year from the date of conduct of such assessment/examination.
The records shall be made available for verification to the Board
officials or any individual or committee appointed by the Board.
The Board reserves the right to call for such records of assessment
and/or submission of photocopies.
Rule 26: PRESERVATION OF RECORDS OF EXAMINATION BY
THE BOARD OFFICE:
The following examination documents shall be preserved for a
period as specified below:
Sr. Document
No.
01 Assessed answer books
02
03

04
05

Period

One year from the date of
declaration of results.
Examiners marklists & One year from the date of
attendance sheets
declaration of results.
Exam Forms, Forms of Six months from date of
General
Verification/ declaration of results.
Verification in Presence/
Inspection/ Revaluation/
Improvement of marks
Manuscripts of Question Six months from date of
Papers, printed question declaration of results.
papers
Documents
related
to Six months from date of
malpractice
cases
& declaration of results.
discrepancies of question
papers
The above material shall be disposed off by selling to scrap

paper purchaser on the written agreement that such material shall

19

<!-- page 20 -->

be converted into pulp or tiny pieces which shall not be identifiable
and used again for some other purpose.
Rule 27: PROVISION OF WRITER DURING EXAMINATIONS:
Candidate who have filled examination forms but unable to
write on account of injuring or fracture to writing hand, shall be
allowed to take facility of writer during the exam subject to
following conditions:
i)Application shall be routed through the head of concerned
institute.
ii)The candidate shall produce a certificate from registered medical
practitioner indicating extent of injury and inability to write.
iii) Writer shall not be relative of the candidate and shall not be
technically qualified.
iv) Writer shall not be provided for practical and drawing
examination.
v) Separate sitting arrangement along with supervisor shall be
made by the institute.
vi)

No

additional

time

shall

be

provided

for

writing

the

examination.
Rule 28: DEALING WITH CANDIDATES WITH DISABILITIES:
The facility of the writer during examination shall be provided to
visually impaired candidate with extra time of 10 minutes per hour
subject to fulfillment of conditions i to v at rule 27.
Extra time for twenty minutes per hour will be allotted to
candidate with locomotor disability and cerebral palsy subject to
the following conditions:
1. Application shall be routed through the concern institute.
2. The

candidate

shall

produce

the

certificate

from

a

Registered Medical Practitioner indicating the nature of
disability.

20

<!-- page 21 -->

Rule 29: DEALING WITH CHANGE OF NAME:
The name of a candidate once enrolled as per SSC certificate
will not be altered under any circumstances. In case of change in
name the marksheet/certificate will be endorsed after verification
of documents as below:
1.

1. Attested copy of certificate issued by Registrar of Birth-Death in
For

Form B.
2. Attested copy of Marksheet/certificate issued by Goa Board of
Secondary and Higher Secondary Education.
Rule 30: CESSATION OF QUESTION PAPER PRINTING:
As and when the curriculum is revised and implemented the
question papers based on earlier curriculum shall be printed for
six consecutive examinations only; after which the candidates will
have to appear for equivalent/substitute papers as recommended
by Equivalence committee and approved by the Board.

Rule 33: CONDONATION MARKS FOR AWARD OF DIPLOMA:
( Refer Page No. 59)

21

<!-- page 22 -->

APPROVED RULES FOR DIPLOMA IN HOTEL MANAGEMENT &
CATERING TECHNOLOGY
Rule1: ENROLLMENT WITH B.T.E.:
Same as corresponding semester pattern rule
Rule 2: REGISTRATION FOR EXAMS:
A

candidate

intending

to

appear

for

annual/supplementary

examination shall fill up the Examination form, pay the prescribed fees
and submit the same to the Institute before the due date notified by the
Board. Regular students are compulsorily required to fill up the
Examination forms and register for examinations of the year in
which they are currently studying. (pls. refer to Annexure I for details of
procedure for submission of Examination form.)
Notwithstanding the submission of Examination form, payment of
examination fees and allotment of examination seat number, the
admission to examination of the relevant year shall be cancelled if a
candidate fails to fulfill the condition for grant of term & admission to
examination laid down in rule 3(i). The examination fees paid by the
candidate shall be non refundable.
Notwithstanding the acceptance of Examination form and fees,
allotment of seat number by the Board, the performance/result of the
applicant at the examination would be cancelled if it is later found that
the applicant was not eligible for admission to the relevant year and for
admission to the said examination.
Rule 3: GRANT OF TERM & ADMISSION TO EXAM:
i) A student will be said to have been granted term for a year only when
he/she has:

22

<!-- page 23 -->

1. Put in satisfactory attendance of atleast 75% of the total lectures/
periods in Theory & Practicals separately in each and every subject of
the year as prescribed in the Teaching & Examination scheme.
In case the attendance falls short by not more than 10% due to
illness (certified by a Registered Medical Practitioner) or for any other
reasons considered valid, the Principal may condone such deficiency
and grant the term, if the candidate is otherwise eligible. In any case,
no candidate with less then 65% attendance in any subject of a year,
shall be granted term.
2. Satisfactorily completed the Practicals, Term work, etc as prescribed in
the syllabus and secured the minimum percentage of marks for
passing in the Progressive Assessment.
3. Shown good conduct and character.
4. Registered for annual examinations in respect of the year in which
he/she is currently undergoing study.
A student who does not fulfill the above conditions will be
declared as Term Not Granted (TNG) and will not be permitted to appear
for the relevant year examination. Such students shall be required to
repeat the entire term as a fresh candidate, and the marks obtained by
him/her, will stand cancelled automatically. However, such candidates
can appear for examinations of the lower year.
ii) A student on grant of term automatically becomes eligible to appear for
the relevant year examination. Further, his/her eligibility to go to higher
year is decided as per the ATKT rules (rule 4).
A student who has been granted term but could not appear at the
annual examination may appear for subsequent examination as an exstudent.
Rule 4: ATKT RULES:
1. A candidate who has not failed in more than three subjects in the
Annual/Supplementary examination shall be eligible to keep term
for the subsequent year of study.
23

<!-- page 24 -->

2. Candidate should have passed in all subjects of First Year for
keeping term in Final year.
Rule 5: STANDARD OF PASSING:
"Theory", "Practical/Oral" and "Progressive Assessment" shall be
separate heads of passing.
1.

To pass in a subject the candidate should secure 40% marks in
each head of passing. Fraction of marks obtained shall be rounded
off to the next higher digit.

2.

Candidates passing in all subjects of annual examination in a single
attempt shall be awarded a class (pls. see rule 7 – award of class).
Candidates failing in one or more subjects of annual/supplementary
examination shall be declared Fails/ATKT or Fails as per the ATKT
rule (pls. see rule 4). Candidates passing in the final year
examination but having backlog shall be declared WFLY i.e.
Withheld failing lower year examinations.

Rule 6: CARRYING FORWARD OF MARKS:
A candidate who fails in theory or practical examination of a
subject shall re-appear in such theory paper or practical as the case may
be. The candidate will not be allowed to reappear in the subjects/subject
heads in which he/she has passed and the marks obtained in such
subjects/subject heads shall be carried forward for deciding his/her total
marks.
Rule 7: AWARD OF CLASS:
Class shall be awarded to a successful candidate based on the
percentage of aggregate marks obtained by him/her in a single attempt in
annual examination as indicated below:
75% and above Distinction
60% and above First class
45% and above Second class

24

<!-- page 25 -->

While deciding the minimum marks required for Distinction, First
Class, Second Class, fraction of marks shall be rounded to the next higher
number.
For example, where the Max. marks is 975, minimum marks required
for Distinction will be 975 x 0.75 = 732. (731.25 rounded to the next
higher number)
A candidate passing the examination by part shall not be entitled to
get a class. Award of class leading to award of diploma will be determined
by the marks obtained at the Final year examinations.
Rule 8: AWARDING MARKS TO GET A CLASS:
Same as corresponding semester pattern rule.
Rule 9: AWARDING GRACE MARKS:
1. Grace marks will be limited to three subjects only, provided he/she
has passed in all other subjects of the annual/supplementary
examination. If a candidate has failed in more than three subjects,
he/she shall not be entitled to get any grace marks in any subject.
2.

Grace marks upto a maximum of 2 shall be awarded for a theory
paper of less than 75 marks & upto a maximum of 3 for a theory
paper of 75 marks & above. The grace marks shall be awarded
provided that the candidate has passed in all the other heads of
passing in the subject.

3.

Grace marks shall be given in theory paper only. No grace marks
shall be given in Practical, Progressive Assessment, Project.

Rule 10: AWARDING CONDONATION MARKS:
A candidate who fails to pass annual examination by not more
than 10 marks, his/her deficiency in marks (Theory/Practical heads)
shall be condoned subject to the following conditions:
1.Candidate has appeared in full examination.
2. Candidate has not availed any exemption.
3. Candidate has secured minimum 50% marks in aggregate.
4. Candidate has failed in not more than two subjects.
25

<!-- page 26 -->

A candidate who is getting benefit of condonation is also eligible for
class, such as Distinction, First class, Second class.
However, the total number of marks secured by a candidate
receiving benefit of condonation under the above rule shall remain
unaltered and a "+" sign, meaning condonation, will be shown against
the result.
Rule

11A:

GENERAL

VERIFICATION

OF

MARKS

BY

BOARD

OFFICE:
Same as corresponding semester pattern rule.
Rule 11B: ISSUE OF PHOTOCOPIES OF ANSWSERBOOKS FOR
INSPECTION:
Same as corresponding semester pattern rule.
Rule

11C:

VERIFICATION

OF

MARKS

IN

PRESENCE

OF

CANDIDATE:
Same as corresponding semester pattern rule.
Rule 11D: REVALUATION OF ANSWERBOOKS:
Same as corresponding semester pattern rule.
Rule 12: ISSUE OF STATEMENT OF MARKS:
Same as corresponding semester pattern rule.
Rule 13: AWARD OF DIPLOMA CERTIFICATE:
A candidate who successfully passed all the annual examinations
prescribed for that Programme, and completed the prescribed practical
training wherever applicable will be awarded diploma through head of
Institute after a period of six months from the date of declaration of
results provided there is no complaint of malpractice, fraud, improper
conduct etc. against the candidate.
Rule 14: ISSUE OF DUPLICATE DIPLOMA:
Same as corresponding semester pattern rule.
Rule 15: IMPROVEMENT OF CLASS:
A candidate declared to have completed a Diploma Programme will,

26

<!-- page 27 -->

at his/her option, be permitted to reappear in the subjects of the Final
year in one and the same seating within a period of one year, to enable
him/her to improve his/her class, provided he/she applies in the
prescribed form for improvement of class through the Principal of the
Institute within two months from the date of declaration of the results
leading to award of Diploma. The candidate so permitted: i)Will be required to reappear and pass in all the theory subjects of
Final year examination. Such a candidate will be permitted to avail
only one chance to improve his/her class.
ii)Will be required to reappear as an ex-student and his Progressive
Assessment

Marks,

Practical/Oral,

Project

marks,

etc

wherever

applicable shall only be carried forward.
iii) Will be required to forfeit the Diploma awarded, statement of marks
of the Final year examination and other documents he/she is entitled
to, in case he/she improves the class.
Rule 16: TIME LIMIT TO COMPLETE THE DIPLOMA PROGRAMME:
Same as corresponding semester pattern rule.
Rule 17: ACTS OF MISCONDUCT AND/OR MALPRACTICE:
Same as corresponding semester pattern rule.
Rule 18: AMENDMENT OF RESULTS AFFECTED BY MALPRACTICE:
Same as corresponding semester pattern rule.
Rule 19: MODERATION OF ASSESSMENT WORK:
Same as corresponding semester pattern rule.
Rule 20: ERROR IN RESULT:
Same as corresponding semester pattern rule.
Rule 21: DEALING WITH DISCREPANCY IN QUESTION PAPER:
Same as corresponding semester pattern rule.
Rule 22: PRESERVATION OF RECORDS OF INTERNAL ASSESSMENT
AND PRACTICAL EXAMINATION BY THE INSTITUTE:
Same as corresponding semester pattern rule.

27

<!-- page 28 -->

Rule 23: PRESERVATION OF RECORDS OF EXAMINATION BY THE
BOARD OFFICE:
Same as corresponding semester pattern rule.

Rule 24: PROVISION OF WRITER DURING EXAMINATIONS:
Same as corresponding semester pattern rule.
Rule 25: DEALING WITH CANDIDATES WITH DISABILITIES:
Same as corresponding semester pattern rule.
Rule 26: DEALING WITH CHANGE OF NAME:
The name of a candidate once enrolled as per HSSC certificate will
not be altered under any circumstances. In case of change in name the
marksheet/certificate will be endorsed after verification of documents as
below:
1. Attested copy of certificate issued by Registrar of Birth-Death in
Form B.
2. Attested copy of Marksheet/certificate issued by Goa Board of
Secondary and Higher Secondary Education.
Rule 27: CESSATION OF QUESTION PAPER PRINTING:
Same as corresponding semester pattern rule.

28

<!-- page 29 -->

APPROVED RULES FOR DIPLOMA IN PHARMACY
Rule1: ENROLLMENT WITH B.T.E.:
Same as corresponding semester pattern rule
Rule 2: REGISTRATION FOR EXAMS:
A

candidate

intending

to

appear

for

annual/supplementary

examination shall fill up the Examination form, pay the prescribed fees
and submit the same to the Institute before the due date notified by the
Board. Regular students are compulsorily required to fill up the
examination forms and register for examinations of the year in
which they are currently studying. (pls. refer to Annexure I for details
of procedure for submission of Examination form.)
Notwithstanding the submission of Examination form, payment of
examination fees and allotment of examination seat number, the
admission to examination of the relevant year shall be cancelled if a
candidate fails to fulfill the condition for admission to examination laid
down in rule 3. The examination fees paid by the candidate shall be non
refundable.
Notwithstanding the acceptance of Examination form and fees,
allotment of seat number by the Board, the performance/result of the
applicant at the examination would be cancelled if it is later found that
the applicant was not eligible for admission to the relevant year and for
admission to the said examination.
Rule 3: Examinations:
There shall be an examination for Diploma in Pharmacy (part-I) to
examine students of the first year course and an examination for
Diploma in Pharmacy (Part-II) to examine students of the second year
course. Each examination may be held twice every year. The first

29

<!-- page 30 -->

examination in a year shall be the annual examination and the Second
examination

shall

be

supplementary

examination

of

Diploma

in

Pharmacy (Part-I) or Diploma in Pharmacy (Part-II), as the case may be.
The examinations shall be of written and practical (including oral)
nature. The maximum marks for theory and practical examinations
excluding sessional is 80 marks.
1. Eligibility for appearing at the Diploma in Pharmacy Part-I
examination:
Only such candidates who produce certificate from the Head of the
Academic Institution in which he/she has undergone the Diploma in
Pharmacy Part-I course in proof of his/her having regularly and
satisfactorily undergone the course of study by attending not less
than 75% of the classes held both in theory and in practical
separately in each subject shall be eligible for appearing at the
Diploma in Pharmacy (Part- I) examination.
2. Eligibility for appearing at the Diploma in Pharmacy Part-II
examination:
Only such candidates who produce certificate from the Head of the
academic institution in which he/she has undergone the Diploma in
Pharmacy Part–II course in proof of his/her having regularly and
satisfactorily undergone the Diploma in Pharmacy Part-II course by
attending not less than 75% of the classes held both in theory and in
practical separately in each subject shall be eligible for appearing at the
Diploma in Pharmacy (Part-II) examination.
3. Mode of examination:
1) Each theory and practical examination shall be of three hours
duration.
2) A candidate who fails in theory or practical examination of a
subject shall re-appear in such theory paper or practical as the
case may be.
3) Practical examination shall also consist of a viva-voce (Oral)
examination.

30

<!-- page 31 -->

Rule 4: Award of sessional marks and maintenance of records:
1) A regular record of both theory and practical class work and
examinations conducted in an institution imparting training for
Diploma in Pharmacy Part-I and Diploma in Pharmacy Part-II
courses, shall be maintained for each student in the institution
and 20 marks for each theory and 20 marks for each practical
subject shall be allotted as sessional.
2) There shall be at least two periodic sessional examinations during
each

academic

year.

The

highest

aggregate

of

any

two

performances shall form the basis of calculating sessional marks.
3) The sessional marks in practicals shall be allotted on the following
basis:i) Actual performance in the sessional examination

10 marks.

ii) Day to day assessment in the practical class work 10 marks.
Rule 5: Minimum marks for passing the examination:
A student shall not be declared to have passed Diploma in
Pharmacy examination unless he/she secured at least 40% marks in
each of the subject separately in the theory examination, including
sessional marks and at least 40% marks in each of the practical
examinations including sessional marks. The candidates securing
75% marks or above in aggregate in all subjects in a single attempt at
the Diploma in Pharmacy (Part-I) or Diploma in Pharmacy (Part-II)
examinations shall be declared to have passed with Distinction the
Diploma in Pharmacy (Part-I) or Diploma in Pharmacy (Part-II)
examinations as the case may be. Candidates securing 60% marks or
above in aggregate in all subjects in a single attempt at the Diploma
in Pharmacy (Part-I) or Diploma in Pharmacy (Part-II) examinations

31

<!-- page 32 -->

shall be declared to have passed in First class the Diploma in
Pharmacy (Part-I) or Diploma in Pharmacy (Part-II) examinations as
the case may be and Candidates securing 45% marks or above in
aggregate in all subjects in a single attempt at the Diploma in
Pharmacy (Part-I) or Diploma in Pharmacy (Part-II) examinations shall
be declared to have passed in second class the Diploma in Pharmacy
(Part-I) or Diploma in Pharmacy (Part-II) examinations as the case
may be.
Rule 6: Award of marks to get a class:
Same as corresponding semester pattern rule
Rule 7: Eligibility for promotion to Diploma in Pharmacy (Part-II):
All candidates who have appeared for all the subjects and passed
the Diploma in Pharmacy Part-I examination are eligible for promotion
to the Diploma in Pharmacy Part-II class. However, failure in more
than two subjects shall debar him/her from promotion to the Diploma
in Pharmacy Part-II class.
Rule 8: Improvement of sessional marks:
Candidates who wish to improve sessional marks can do so,
by appearing in two additional sessional examinations during the next
academic year. The average score of the two examinations shall be
basis for improved sessional marks in the theory. The sessional of
practical shall be improved by appearing in additional practical
examinations.

Marks

awarded

to

a

candidate

for

day-to-day

assessment in the practical class cannot be improved unless he/she
attends a regular course of study again.
Rule 9: Certificate of Passing examination for Diploma in Pharmacy
(Part-II):
Certificate to having passed the examination for the Diploma
in Pharmacy part II shall be granted by the Board to a successful
student.
Rule 10: Period and other conditions for Practical Training:

32

<!-- page 33 -->

1) After having appeared in Part-II examination for the Diploma in
Pharmacy conducted by Board a candidate shall be eligible to
undergo practical training in one or more of the following
institutions namely:
i) Hospitals/Dispensaries run by Central/State Government/
Municipal Corporation/Central Government Health Scheme and
Employees State Insurance Scheme.
ii) A Pharmacy, Chemist and Druggist licensed under the Drugs
and Cosmetics Rules, 1945 made under the Drugs and
Cosmetics Act, 1940 (23 of 1940).
iii) Drugs manufacturing Unit licensed under the Drugs and
Cosmetics Act, 1940 and rules made thereunder.
2) The institutions referred in sub-regulation (1) shall be eligible to
impart training subject to the condition that the number of
student pharmacists that may be taken in any hospital,
pharmacy, chemist and druggist and drugs manufacturing unit
licensed under the Drugs and Cosmetics Rules, 1945 made
under the Drugs and Cosmetics Act, 1940 shall not exceed two
where there is one registered pharmacist engaged in the work in
which the student pharmacist is undergoing practical training,
where there is more than one registered pharmacist

similarly

engaged, the number shall not exceed one for each additional
such registered pharmacist.
3) Hospital and Dispensary other than those specified in subregulation (1) for the purpose of giving practical training shall
have to be recognized by Pharmacy Council of India on fulfilling
the conditions specified in Appendix-D to these regulations.
4) In the course of practical training, the trainee shall have exposure
to:
i) Working knowledge of keeping of records required by various
Acts concerning the profession of Pharmacy, and
33

<!-- page 34 -->

ii) Practical experience in:
a)

The manipulation of pharmaceutical apparatus in common
use.

b) The

reading,

translation

and

copying

of

prescription

including checking of doses.
c)

The dispensing of prescription illustrating the commoner
methods of administering medicaments and

d) The storage of drugs and medical preparations.
5) The practical training shall be not less than five hundred hours
spread over a period of not less than three months, provided that
not less than two hundred and fifty hours are devoted to actual
dispensing of prescriptions.
Procedure to be followed prior to commencing of the Training:
1) The head of an academic training institution, on application,
shall supply in triplicate ‘Practical Training Contract Form for
qualification as a Pharmacist’ (hereinafter referred to as the
Contract Form) to candidate eligible to undertake the said
practical training. The contract form shall be as specified in
Appendix-E to these regulations.
2) The Head of an academic training institution shall fill section I
of the Contract Form, the trainee shall fill section II of the said
Contract Form and the Head of the institution agreeing to
impart the training (hereinafter referred to as the Apprentice
Master) shall fill section III of the said Contract Form.
3) It shall be the responsibility of the trainee to ensure that one
copy (hereinafter referred to as first copy of Contract Form) so
filled is submitted to the Head of the academic training
institution and the other two copies (hereinafter referred to as
the second copy and the third copy) shall be filed with the
Apprentice Master (if he so desires) or with the trainee pending
completion of the training.

34

<!-- page 35 -->

Rule 11: Certificate of passing Diploma in Pharmacy Part-III:
On satisfactory completion of the apprentice period, the
Apprentice Master shall fill SECTION IV of the second copy and third
copy of the Contract Form and cause it to be sent to the head of the
academic training institution who shall suitably enter in the first copy
of the entries from the second copy and third copy and shall fill
SECTION V of the three copies of Contract Form and thereafter hand
over both the second copy and third copy to the trainee.
This, if completed in all respects, shall be regarded as a
certificate of having successfully completed the course of Diploma in
Pharmacy (Part-III).
Rule 12A: GENERAL VERIFICATION OF MARKS
OFFICE:
Same as corresponding semester pattern rule.

BY

BOARD

Rule 12B: ISSUE OF PHOTOCOPIES OF ANSWSERBOOKS FOR
INSPECTION:
Same as corresponding semester pattern rule.
Rule 12C: VERIFICATION OF MARKS IN
CANDIDATE:
Same as corresponding semester pattern rule.

PRESENCE

OF

Rule 12D: REVALUATION OF ANSWERBOOKS:
Same as corresponding semester pattern rule.
Rule 13: ISSUE OF STATEMENT OF MARKS:
Same as corresponding semester pattern rule.
Rule 14: AWARD OF DIPLOMA CERTIFICATE:
A candidate who has passed the Diploma in Pharmacy Part-I and
Part-II and satisfactorily completed Practical Training for Diploma in
Pharmacy Part-III shall be awarded diploma through head of Institute
after a period of six months from the date of declaration of results
provided there is no complaint of malpractice, fraud, improper conduct
etc. against the candidate.
Rule 15: ISSUE OF DUPLICATE DIPLOMA:

35

<!-- page 36 -->

Same as corresponding semester pattern rule.
Rule 16: TIME LIMIT TO COMPLETE THE DIPLOMA PROGRAMME:
Same as corresponding semester pattern rule.
Rule 17: ACTS OF MISCONDUCT AND/OR MALPRACTICE:
Same as corresponding semester pattern rule.
Rule 18: AMENDMENT OF RESULTS AFFECTED BY MALPRACTICE:
Same as corresponding semester pattern rule.
Rule 19: MODERATION OF ASSESSMENT WORK:
Same as corresponding semester pattern rule.
Rule 20: ERROR IN RESULT:
Same as corresponding semester pattern rule.
Rule 21: DEALING WITH DISCREPANCY IN QUESTION PAPER:
Same as corresponding semester pattern rule.
Rule 22: PRESERVATION OF RECORDS OF INTERNAL ASSESSMENT
AND PRACTICAL EXAMINATION BY THE INSTITUTE:
Same as corresponding semester pattern rule.
Rule 23: PRESERVATION OF RECORDS OF EXAMINATION BY THE
BOARD OFFICE:
Same as corresponding semester pattern rule.
Rule 24: PROVISION OF WRITER DURING EXAMINATIONS:
Same as corresponding semester pattern rule.
Rule 25: DEALING WITH CANDIDATES WITH DISABILITIES:
Same as corresponding semester pattern rule.
Rule 26: DEALING WITH CHANGE OF NAME:
The name of a candidate once enrolled as per HSSC certificate will
not be altered under any circumstances. In case of change in name the
marksheet/certificate will be endorsed after verification of documents as
below:
1. Attested copy of certificate issued by Registrar of Birth-Death in
Form B.
2. Attested copy of Marksheet/certificate issued by Goa Board of

36

<!-- page 37 -->

Secondary and Higher Secondary Education.

GUIDELINES
&
PROCEDURES

37

<!-- page 38 -->

Annexure I
PROCEDURE FOR SUBMITTING EXAMINATION FORM:
1. A

candidate

intending

to

appear

for

a

semester/annual/

supplementary examination shall fill up the Examination form, pay
the prescribed fees and submit the same to the Institute before the
due date notified by the Board.
2. Forms submitted after the due date will be accepted at the
Institute on payment of prescribed late fees within a period notified
by the Board. Incomplete forms shall not be accepted by the Board.
3. The Chairman, Board of Technical Education, Goa, however, shall
be the competent authority to accept the form/s in special cases
even after the expiry of the last date with late fees.

38

<!-- page 39 -->

Annexure II
GUIDELINES FOR INTERNAL ASSESSMENT:
A. Assessment by Term Work:
1. It is good academic practice to prepare a schedule of works at
the start of the term to make the students aware of the works to
be completed during the term.
2. Such schedule needs to indicate the marks allotted for
assessment of each component for keeping full transparency.
3. Student shall prepare a journal consisting of all works done by
them towards completion of term work.
4. The

marks

allotted

to

each

component

during

periodic

assessment may be shown on the journal itself for immediate
knowledge of the students regarding their achievements.
5. A proper record of all such assessment shall be kept by the
subject teacher for the benefit of all stake holders.
6. Such records of assessment shall be preserved for a period of
one

year

from

the

date

of

conduct

of

such

assessment/examination and shall be open for verification to
the Board Officials or any individual or committee appointed by
the Board.
7. The student should be present and should have completed at
least 75% of the works prescribed for certification of successful
completion of term work. However marks will be proportionate
to the number of practical/assignments/works done by them.
8. If any student is absent for any practical class, he/she may
positively do the practical any other time in consultation with
the subject teacher.

39

<!-- page 40 -->

9. Students and subject teacher should be in the laboratory/
workshop/drawing hall for the full duration of practical hours to
facilitate completion and submission of journal.
10.The final term work marks shall be displayed on notice board
for ensuring information to the students before sending the
same to the Board Office for declaration of result.
B. Assessment by Test:
1. Two periodic tests at regular intervals shall be conducted in
each term.
2. Marks scored by the students in each test shall be made known
to the students and own answer books shall be made available
for clarity.
3. Average

of

the

two

test

marks

shall

be

considered

for

calculating final test marks.
4. In case of very poor performance in tests, one additional test
may be held at the discretion of subject teacher if there is
sufficient justification. Any such additional test shall be open
for all students desiring to appear.
5. The marks obtained in all tests along with the final test marks
shall be displayed on notice board for ensuring information to
the students before sending the marks to Board Office for
declaration of results.
6. The records as above shall be preserved for a period of one year
from the date of conduct of such assessment/examination and
open for verification to the Board Officials or any individual or
committee appointed by the Board.

40

<!-- page 41 -->

Annexure III
GUIDELINES FOR DISPLAY & MAINTENANCE OF INTERNAL
EVALUATION RECORDS:
1. The final marks of the internal assessment head "Term
Work" shall be displayed for ensuring information to the
students before sending the marks to Board Office.
2. The marks obtained in the two tests along with the final test
marks under the subhead "Test" of the head "Theory" shall
be displayed for ensuring information to the students before
sending the marks to Board.
3.

The records of all internal assessments held on behalf of
Board shall be maintained with full clarity understandable to
any interested stake holders.

41

<!-- page 42 -->

Annexure IV
PROCEDURE FOR SUBMITTING APPLICATION FOR IMPROVEMENT
OF TEST MARKS:
i)Students intending to appear for "Improvement of Test Marks" should
apply in the prescribed performa (Form No. 4) in the beginning of the
semester indicating their existing marks and other details, duly
recommended by respective Head of Dept.
ii)The institute shall send programmewise and semesterwise compiled
list of such applicants (Form No. 4A) to the Board while submitting
regular examination form. Applications (Form 4) shall be retained by
the Institute.
iii)The marks obtained in Improvement Tests shall be published on the
Notice Board for verification by concerned students as is the procedure
for test marks in regular semester.
iv)The marks obtained in "Improvement of Test Marks" shall be
forwarded to the Board in Form 4B alongwith the submission of regular
marksheets.
v)The records of internal assessments held by the institution on behalf
of Board of Technical Education, shall be preserved by the institute/
subject teacher for a period of one year from the date of conduct of
such assessment/examination.

42

<!-- page 43 -->

Annexure V
PROCEDURE FOR GENERAL VERIFICATION OF MARKS:
i) The candidate must submit his/her application form through the
Principal of the Institute within the period notified by the Board and must
be accompanied by the prescribed non-refundable fee. No application
form/fees shall be accepted by the Board directly.
ii)The verification will be restricted to checking whether all the answers
have been assessed and that there has been no mistake in the totaling of
marks for each question in that subject and transferring of marks at any
stage.
iii) In case any unassessed part is identified during verification, the
unassessed portion shall be assessed and additional marks obtained, if
any, shall be taken into consideration.
iv) In case the candidate's mark is changed on verification, result shall be
redeclared and fresh marksheet issued.

43

<!-- page 44 -->

Annexure VI
PROCEDURE FOR ISSUE OF PHOTOCOPIES OF ANSWER
BOOKS FOR INSPECTION:

44

<!-- page 45 -->

i) The candidate must submit his/her application form through the
Principal of the Institute within the period notified by the Board and
must be accompanied by the prescribed non-refundable fee. No
application form/fees shall be accepted by the Board directly.
ii) The photocopies of answer books masking examiner's/moderator's
name & signature will be made available at the Board Office on dates &
time as notified. In case the candidate does not report for inspection as
per schedule, it will be deemed that the candidate is no more interested
to inspect his/her answerbook.
iii)The candidate must prove his identity by means of identity card
containing photograph & signature for issue of photocopies.
iv) Inspection of photocopies shall be done in isolation under the
supervision of a Board official, and any comments, discussion,
arguments or other observation oral or written is strictly prohibited
during the inspection of photocopies. Any act of indiscipline during
inspection shall be treated as malpractice liable for appropriate penalty
as decided by Special Committee.
v) Normally no person other than the candidate shall be allowed to see
the photocopy. However one of parents, guardian or sibling may be
allowed with candidate, if specifically applied for, and identity is proved.
vi) Photocopies are issued for perusal only and shall be returned within
one hour alongwith a declaration that photocopies have been received,
inspected to the candidate's satisfaction, and the photocopy of paper
returned.
vii)Any application received after the schedule date prescribed, or
applications by anybody other than the candidate, or applications,
without the prescribed fee will be summarily rejected.
Annexure VII
PROCEDURE FOR VERIFICATION OF MARKS IN PRESENCE:

45

<!-- page 46 -->

i) The candidate must submit his/her application form through the
Principal of the Institute within the period notified by the Board and
must be accompanied by the prescribed non-refundable fee. No
application form/fees shall be accepted by the Board directly.
ii) The facility of verification of marks in presence of candidate shall be
made available at the Board Office on dates & times notified. In case
the candidate does not report for verification, it will be deemed that he
is no more interested in the facility.
iii) Photocopies of the answerbooks masking examiners/ moderators
name & signature will be made available for verification in presence
and changes, if any, shall be transferred to the original by the verifier.
iv) The verification of marks in presence shall involve the same checks
as described for General verification of marks.
v) Any discussion or argument beyond the scope of verification will not
be permitted. Any act of indiscipline during verification shall be
treated as Malpractice liable for appropriate penalty as decided by
special committee.
vi) If any unassessed part is identified during verification, the same
shall be assessed later and the additional marks obtained, if any,
shall

be

taken

into

consideration.

No

further

verification

is

permissible.
viii) The verification report shall be signed both by candidate and
verifier.
ix) In case the candidates mark is changed on verification, the result
shall be redeclared and fresh marksheet issued.

Annexure VIII
PROCEDURE FOR REVALUATION OF ANSWER BOOKS:
i) The candidate must submit his/her application form through the

46

<!-- page 47 -->

Principal of the Institute within the period notified by the Board and
must be accompanied by the prescribed non-refundable fee. No
application form/fees shall be accepted by the Board directly.
ii) Revaluation shall be done by two examiners and the average total
mark of two assessments will be considered.
iii) The marks obtained during revaluation shall be awarded in case of
upward change, and downward revision will be considered as no
change.
iv) In case the candidate 's mark is changed on revaluation, the result
shall be redeclared and fresh marksheet issued.
v)Revaluation will be final and further arguments, correspondence,
request for verification etc shall not be permitted.

Annexure IX
PROCEDURE FOR ISSUE OF STATEMENT OF MARKS:
i) The Statement of Marks shall be issued only to the successful
candidate after declaration of results. However, in case of W.F.L.S. result
(W.F.L.Y. in case of yearly pattern system), the candidate will not be

47

<!-- page 48 -->

issued the final semester marksheet. For such candidates the final
semester marksheet (final year in case of yearly pattern system) will be
issued only after passing all the backlog subjects. An application in Form
5A should be submitted to the Board for this purpose.
ii) Any candidate if unsuccessful in any examination, may be issued with
a Statement of Marks on specific application (in Form 5) through the
Head of Institute within one month of declaration of results.
i) There is no fees chargeable for such issue of Statement of Marks, if
applied within the schedule prescribed above.
ii) Any application submitted after the prescribed time limit as above and
application for issue of duplicate statement of marks shall attract
prescribed fees.
v) Any discrepancy in the name of the candidate on the result
sheet/Statement of Marks should be brought to the notice of Board
within one month of declaration of first examination results and BTE will
confirm the correction within one month of receipt of application.
vi) The spelling & sequence of names enrolled with Board will be as per
the entry in the certificate/marksheet of the qualifying examination
(SSCE/HSCE/other).
vii) Any complaint about the result or marksheet issued should be made
to BTE with appropriate justification within one month of declaration of
results.

Annexure X
PROCEDURE FOR ISSUE OF DUPLICATE DIPLOMA CERTIFICATE:
i) The application for duplicate Diploma shall be forwarded through the
institute only. Board Office may not accept any application directly.
48

<!-- page 49 -->

ii) Application should be substantiated by necessary proof of damage or
an affidavit (in case of loss or theft) on a stamp paper of appropriate
denomination.
iii) In case of an Institution, which had presented the candidate for an
examination, ceases to exist afterwards, duplicate Diploma will be issued
to the candidate on production of identity, certified by Gazetted Officer in
addition to above documents.
iv) A remark ‘Duplicate’ will be printed at top of right hand corner of the
certificate. The date of diploma awarded will be same as on original
diploma certificate and the date of re-issue will be shown on the
certificate.

Annexure XI
UNFAIR MEANS/MALPRACTICE INCLUDES ANY ONE OR MORE OF
THE FOLLOWING ACTS/OMISSIONS BY A CANDIDATES APPEARING
FOR AN EXAMINATION:

49

<!-- page 50 -->

i) Possessing any book, paper or any other copying material.
ii) Copying during exam.
ii) Communicating with any candidate or any other person in or outside
examination hall with a view to take assistance or aid to answer in the
examination.
iii) Carrying mobile phone in the exam hall.
iv) Receiving or giving assistance in any form during the course of the
examination.
v) Intimidating or using abusive language or use of violence against
Invigilator or any person on exam duty or causing disturbance in any
manner in the exam proceedings.
vi) Disobeying instructions issued by the Invigilator/Officer-in-charge of
examination.
vii) Smuggling-out either blank or written or smuggling-in of answer
book/supplements as copying material and/or smuggling-in blank or
written answer book/supplements and forging signature of the Invigilator
thereon.
viii) Interfering with or counterfeiting of Board/Institute seal or answer
books or office stationery used in the exam hall.
ix) Inserting or substituting in the answer book, answer sheets or any
other stationery not supplied in the Examination Hall or writing on any
material other than the answer books.
x) Running away from the exam hall with/without his/her

answer book

or leaving the exam hall without the permission of the supervisor.
xi) Approaching directly or indirectly the examiners or officers on exam
duty and bringing undue pressure or undue influence upon them for
favours in the examination.
xii) Disclosing deliberately his/her identity in the answer book and/or
writing abusive language or appeal in the answer book.
xiii) Impersonating or allowing any other person to impersonate for
him/her in the exam hall.
50

<!-- page 51 -->

xiv) Any other misconduct as would go to prove the candidate’s malafide
intentions in connection with the examination.

Annexure XII
PROCEDURE FOR DEALING WITH MALPRACTICE CASES:
I) If during examination a candidate is found to use or attempted to use
unfair means/misconduct or malpractice, the following steps shall be
followed:
51

<!-- page 52 -->

i) The answer books and all incrementing material/evidence should be
seized from the candidate.
ii) The matter shall be immediately reported to the Officer-in-charge of
examination.
iii)

All

such

material

shall

be

duly

signed

by

the

Hall

Supervisor/Invigilator, candidate, Officer-Incharge indicating the seat
number of the candidate and other details such as date of exam, subject,
etc. in the presence of officer-in-charge.
iv) The candidate will have to give under his/her signature an
undertaking with request to allow him/her to continue answering the
paper in a fresh answerbook and to appear for the remaining papers to be
held thereafter. The appearance in the examination shall be provisional
and subject to the decision of the authorities in the matter of disposal of
case of alleged use of unfair means. It shall be binding upon the
candidate that in the event of being found guilty, such provisional
appearance is liable to be treated null and void. In case he/she refuses to
give any undertaking, the candidate shall be expelled from the exam hall
and the same to be recorded.
v) The Hall Supervisor shall submit a detailed report on the incident,
explaining

the

time

&

the

actual

incident,

the

incriminating

material/evidence and any other related matter to the Officer-In charge of
examinations.

The

report

submitted

by

the

Supervisor

and

the

incriminating material/evidence shall be countersigned by the Officer-In
charge of examinations.
vi) The Principal of the institute shall submit the report of the Hall
Supervisor, the undertaking of the candidate, if any, together with the
first answerbook and all the incriminating material/evidence to the Board
in a sealed cover within three days of such occurrence.
vii) If the candidate refuses to hand over the incriminating material or
destroys or runs away with the material, the facts shall be noted by the
Hall Supervisor/Invigilator and reported to the Officer-in-Charge.
52

<!-- page 53 -->

viii) The cases of impersonation, violence or intimidation should be
immediately reported to the police by the institute.
II) In case an examiner, finds or suspects use of unfair means by a
candidate while assessing the answer book he/she shall report the matter
in detail to the officer-in-charge of the assessment center. The Principal of
the Institute shall submit the report to the board office within three days
of such occurrence.
III) The concerned student shall be called by the Secretary,B.T.E. to hear
his explanation and report of such disposal be prepared.
IV) It shall be verified whether all documents substantiating the incident
of malpractice/misconduct is submitted by the institute/examination
center.
V) All the above documents shall be placed before the Special Committee
for decision. The Special Committee shall be guided by a schedule of
penalties for awarding punishment in malpractice cases.

Annexure XIII
SCHEDULE OF PENALTIES FOR MALPRACTICE CASES:
Sr Type of Offence
No

Penalty

Action by

53

<!-- page 54 -->

a) Communicating with each other in
the examination hall.
b) Disobeying any instruction of the
hall supervisor/officer-in-charge.
c) Bringing in cell phone or any
other such electronic gadgets not
permitted in the examination Liable for expulsion from
the examination hall after
hall.
1 d) Exchanging
seat
without obtaining a report from
hall supervisor, endorsed
permission of hall supervisor.
by Officer-in-charge.
e) Refusing to give the prescribed
undertaking incase of suspected
malpractice.
f) Causing disturbance in the
examination hall
g) Misbehaviour
towards
any
member of examination staff.

Officer-incharge
in
consultation
with
Principal

a) Disclosing deliberately his/her
identity in the answer book.
b) Writing provocative/abusive
2
language or appeal in the answer
book.

Cancellation of result of
all subjects (theory) in the
relevant semester* of
appearance for
examination.

Special
Committee
on
report
from
examination/
assessment
centre

a) Detection of suspected assistance
to copying
at the time of
assessment and established by
enquiry
that candidate has
3
offered assistance to another
candidate for copying.
b) Exchanging answer books or
supplement in the exam hall.

Cancellation of
entire
appearance of all subjects
of all semesters (theory)*
in the concerned
examnination.

Special
Committee
on
report
from
examination/
assessment
centre

54

<!-- page 55 -->

4 a) Possession of copying material in
any form whether used or not.
b) Trying to destroy the proof of
possession of copying material by
swallowing or any other means.
c) Running away with the answer
book.
d) Incase of detection of suspected
copying at the time of assessment
and established by enquiry that
the candidate has actually copied
from any source.

Cancellation of entire
appearance of all subjects
of all semesters (theory)*
and not
permitted to
attend classes of the next
term and debarred from
appearing
in
the
immediate next exam.

Special
Committee
on
report

5 a) Smuggling out or smuggling in
the examination answer book
or supplement.
b) Suspected use of some other
stationary not supplied in the
examination
hall
detected
during assessment.

Cancellation of
entire
appearance of all subjects
of all semesters (theory)*
and not permitted to
attend classes of the next
two terms and debarred
from attending in the
immediate
next
two
examinations.

Special
Committee
on
report
from
examination/
assessment
centre

6 Candidate found impersonating
i.e. deputing or deputizing any
other
candidate when both
persons are from polytechnic
system.

Cancellation of
entire
appearance of all subjects
of all semesters (theory)*
and
disqualified
for
polytechnic education for
a period of five years for
both candidates.

Special
Committee
on
report
from
examination
centre

7 Impersonating
during
examination when impersonator
is not belonging to polytechnic
system
8 All other offence not covered in
the schedule
9 If the candidate is implicated in
pervious occasions

Lodging a Police complaint Officer-InCharge
To be decided as per the
gravity of the offence.
Penalty shall be most
stringent.

from
examination/
assessment
centre

Special
Committee
Special
Committee

* word ‘semester’ shall be replaced by ‘year’ in case of yearly pattern
system

55

<!-- page 56 -->

Annexure XIII (A)
AMENDMENTS IN SCHEDULE OF PENALTIES FOR MALPRACTICE CASES:
{ Refer Board Meeting dated 14/05/2015}
Sr
No

Type of Offence

Amendment in
Penalty

Existing Penalty

Action by

a) Communicating with each other
Liable for expulsion
Liable for
in the examination hall.
from the examination expulsion from
b) Disobeying any instruction of
hall supervisor/officer-in-charge. hall after obtaining a the examination
hall after obtaining
c) Exchanging
seat
without report from hall
supervisor, endorsed a report from hall
permission of hall supervisor.
by Officer-in-charge.
supervisor,
Officer-ind) Refusing to give the prescribed
endorsed by
charge
in
undertaking incase of suspected
1
Officer-in-charge.
consultation
malpractice.
with
e) Causing disturbance in
Principal
the examination hall
f) Misbehaviour
towards
any
member of examination staff.
a) Possession of copying material in Cancellation of entire
any form whether used or not.
appearance of all
Cancellation of
Special
b) Bringing in/use of mobile
subjects of all
entire appearance Committee
phones/ smart phones or any
semesters (theory)*
of all subjects of all on
report
other such electronic gadgets not and not permitted to
semesters (theory)*
permitted in the exam hall.
appear for ‘B’ Category and not permitted from
c) Trying to destroy the proof of
registrations, in the
to attend classes of examination/
possession of copying material by immediate next
the next term and assessment
4
swallowing or any other means. examination.
centre
debarred from
d) Running away with the answer
However, permitted to Appearing in the
book.
appear for ‘A’ Category immediate next
e) Incase of detection of suspected registrations, if
exam.
copying at the time of assessment otherwise eligible, in
and established by enquiry that the immediate next
the candidate has actually copied examination.
from any source.
a) Smuggling out or smuggling in
the examination answer book
or supplement.
b) Suspected use of some other
stationary not supplied in the
examination
hall
detected
during assessment.
5

Cancellation of entire Cancellation of
appearance of all
entire appearance Special
subjects of all
of all subjects of all Committee
report
semesters (theory)* and semesters (theory)* on
from
not permitted to attend and not permitted
classes of the next
to attend classes of examination/
term and debarred
the next two terms assessment
from appearing in the and debarred from centre
immediate next exam. appearing in the
immediate next two
examinations.

Note: The remainder part of “schedule of Penalties for malpractices” is unaltered.

56

<!-- page 57 -->

Rule 32: Industrial Training for 03 year Diploma
Programmes
a. Industrial Training for 03 years Diploma Programme shall be
offered in Semester V / Semester VI, as per curriculum, for
duration of 08 weeks.
b. Industrial Training shall commence from 1st or 9th week of the
Semester .
c. Student/s who are eligible to keep term for semester V /
semester VI, are only eligible to undergo Industrial Training.
d. Those Student/s, who are not eligible to keep term for semester
V and who have applied for Verification/ Revaluation of
answer books/ Verification in presence of answer books shall be
provisionally permitted to undergo the training. On declaration
of the above results, if the eligibility criteria are fulfilled, then
he/she shall continue the training or else, discontinue the
training with immediate effect.
e. For Industrial Training subject only Grade will be awarded and
marks will not be shown in the statement of marks. Grades will
be awarded based on marks scored (Fractions rounded off to
nearest integer) as follows:
A--- 80% & above
B--- 60 - 79%
C-- 40—59%
D— below 40%
f. For Industrial training, Heads of passing shall be TW & PR/OR
with minimum Grade ‘C’ obtained in each head.
g. Student/s undergoing Industrial Training shall secure at least
Grade ‘C’ in TW (For attendance, Industrial mentor’s
assessment and Institute mentor’s assessment, Training
Report), failing which he/she shall not be granted terms for the
respective semester.

57

<!-- page 58 -->

h. Any student, who does not fulfil the requirements of grant of
term in any of the subjects offered in the other half of the
semester in which Industrial Training is offered and therefore is
not granted terms of the said semester will be required to
undergo Industrial Training again while repeating the semester.
i. Any student remaining absent (with or without permission) for
more than 08 working days during Industrial Training is liable
to be declared Term not granted.
j. In case of circumstances leading to non-availability of seats for
placement in Industry for Industrial Training, student/s shall
be assigned Industry related project/s, with prior approval of
Board.
k. Student/s undergoing Industrial Training shall follow Rules and
Regulations of the Industry.
l. Industrial Training will generally be organised and conducted in
accordance with Industrial Training Manual duly prescribed by
the Board.

******************************************************************

58

<!-- page 59 -->

Rule 33: CONDONATION MARKS FOR AWARD OF DIPLOMA:
A candidate who has appeared for repeat examination and fails
to pass the Semester examination by not more than 10 marks, in
not

more

than

02

subjects,

his/her

deficiency

in

marks

(Theory/Practical heads), shall be condoned provided, with the
grant of this condonation marks, the candidate completes his/her
Diploma programme and becomes eligible for his/her Diploma .
A candidate who is getting the benefit of condonation is also
eligible for class, such as Distinction, First class, Second class.
However, the total number of marks secured by the candidate
receiving benefit of condonation under the above rule shall remain
unaltered and a "‡" sign, meaning condonation, will be shown
against the result.

59

<!-- page 60 -->

VIII. Duties and Responsibilities of Officer In Charge (Examination)
Successful Conduct of examination depends greatly on the
integrity, alertness and sincerity of the entire exam personnel functioning
under the leadership of the officer in-charge. As the person holding
overall charge of the exam, the officer in-charge shall be expected to
discharge his duties to the best of his abilities in a way to set an example
for his colleagues to follow and in the interest of the institution.
The Important Duties and Responsibilities of Officer In Charge are:
1.

To brief in advance each member of the exam personnel and to make them
aware of their respective duties and responsibilities.

2.

To collect the details of candidates, such as number of students appearing
for exam at various sessions (morning/afternoon) on different dates.

3.

To plan the seating arrangement for each session.

4.

To be available at the centre well in advance.

5.

To be available to any of the exam personnel whenever one needs his
guidance.

6.

To be arrange for the distribution of Question papers and blank
answerbooks to the invigilators in different rooms/halls.

7.

To arrange code stamping on each answerbook in accordance with the
confidential instructions of Board and ensure that exam day code stamp is
properly affixed.

8.

To inform the hall supervisor about the position of Board of Technical
Education code for each session.

9.

Before opening the packet containing Question papers it should be
ensured that BTE seal is intact on the envelope and it should be opened
only after opened only after obtaining the required signatures.

60

<!-- page 61 -->

10. To verify the correctness of Question paper packet opened Vis-à-vis the
course of examination.
11. To ensure the start of examination on time.
12. In case the candidate is unable to produce the admit card at the time of
examination: he/she may be allowed to write the exam based on available
records at the institute and the student may be instructed to produce it at
the earliest.
13. To personally supervise packing of answerbooks alongwith various relevant
statements for dispatch to BTE.
14. To take all other steps as may be necessary to maintain the sanctity of the
exam and the environment conducive to conduct the exam.
15. To verify whether answerbooks/supplementary answer sheets are duly
stamped and signed.
16. To ensure that the answer books are duly counted ant match with the
attendance sheet. The answer books must be placed in serial order of the
seat numbers.
17. To keep the answer books ready for collection by Board officials.

61

<!-- page 62 -->

IX. Duties and responsibilities of Invigilator (Exam hall Supervisor)
An invigilator is expected to be alert at every moment beginning
from the entry of the candidate till all answer books are collected from
them.
Important duties and responsibilities of invigilator are:
1.

To announce to the candidates to leave books, notes, coping material
mobile phones outside the exam hall.

2.

To distribute amongst the examinees the answerbooks/drawing sheets and
Question papers.

3.

If the Packet containing Question papers is not opened by officer-in-charge
it should be ensured that BTE seal is intact on the envelope and it should
be opened only after obtaining the required signatures.

4.

To check the candidates admit card and identity card.

5.

To confirm the seat Number written by the candidate.

6.

To

ensure

that

the

candidates

occupy

the

allotted

seats

in

the

Classroom/Hall.
7.

To make sure that each main answer book/ supplementary book issued in
the exam hall is countersigned in the space provided.

8.

To keep a correct record of main answer book and supplementary answer
sheets issued.

9.

To prepare the supervisors report correctly. Seats numbers of candidates
who are absent for the exam should be clearly mentioned on supervisor
report.

10. To verify that the answer book / drawing sheets carry confidential code of
Board of Technical Education seal at correct position.
11. To verify that seat No. and other examination details written by candidate
on the title page answer book are correct.

62

<!-- page 63 -->

12. To verify that the candidates has signed on the attendance sheet in the
correct position.
13. To ensure that the candidate do not indulge in any sort of activity, which
may be considered as a malpractice in the examination.
14. To report malpractice cases to the officer-in-charge of examination.
15. To announce to the candidates to attach the supplementary answer book to
the main answerbooks at the time of warning bell, and ask them to fill the
details of supplementary books attached on the title page of main
answerbooks.
16. To collect answerbooks/ drawing sheets from the candidates as soon as the
examination is over and to handover the same to the officer in charge in
sequential order of seat. No. duty counted.
17. To return the surplus copies of answer /drawing sheets to the officer incharge immediately after examination.

63

<!-- page 64 -->

X. Duties and Responsibilities of the Officer-In-Charge (Assessment
Centre)
1.

To Ensure complete secrecy, safe custody of answerbooks, marksheet,
marklist control on malpractice during assessment and smooth conduct of
assessment work by way of overall supervision.

2.

He/she is responsible for the smooth conduct of the assessment work.

3.

He/she is responsible to co-ordinate and monitor the assessment work.

4.

To be available at the assessment centrethrough out the assessment
period.

5.

To distribute the answerbooks to the examiners and collect them back at
the end of the day under acknowledgement.

6.

To exercise vigilance during assessment and try and maintain the
consistency in the speed of assessment.

7.

In case of unavoidable circumstances, additional qualified examiners may
be appointed or alternate arrangement to be made with instruction of the
Board office.

8.

To submit all reports to Board of Technical Education office without delay.

9.

Assessed packets alongwithmarklist should be sent regularly to the Board
office.

10. To check the assessed packet and get it properly sealed so that there is no
loss during transit.
11. To ensure the completion of assessment work within the stipulated time.

64

<!-- page 65 -->

XI. Duties and Functions of Examiners For Assessment Centre
1.

To maintain the confidentially of exam work all the time.

2.

The examiner shall strictly adhere to the rules of discipline in the
assessment centre and general secrecy and according to the instruction of
the officer in charge.

3.

Any absence or leave shall not be permissible during the period of duties.

4.

Use only red pen for assessment work.

5.

Before starting the assessment work, examiner shall get acquainted
thoroughly with the question paper, number of questions to be attempted.
And number of sub-question to be attempted.

6.

Examiner is strictly prohibited from away any answer-book or from
removing any supplements from the answer-book or from taking away the
abstract or copy of the mark-list, or any of the forms out of the assessment
hall or from handling it over to any other unauthorized person. At the end
of assessment every day, examiner shall submit the answer book packet to
the officer-in-charge.

7.

Do not write any thing or award marks on the matter written by students.
Marks shall be written in the markings and on top of the page so that they
can be easily masked.

8.

The marks obtained carry immense value for the student. So ve careful
and systematic during assessment.

9.

Verify whether all answer are assessed before entering the final marks in
the mark list.

10. The Marks obtained by the candidate for each question as recorded on the
front page of the answer-book shall be carefully recorded on the mark-list
against the seat number/code number of the candidate under the
signature of the examiner. Examiner shall be responsible for the entries
made.

65

<!-- page 66 -->

11. Verify carefully correctness of seat number against the marks awarded.
12. The examiner shall thoroughly check the answer books(main and
Supplements) and report the discrepancies in respect of seat number,
signature of the supervisor, number of supplements, or any unusual
things noticed in the answer books.
13. Rounding up of marks shall be done to next integer on the total marks of
each paper and not on the total marks of each question.
14. The examiner shall report the cases of malpractice, if identified by
examiner during assessment, immediately to the Officer-in-charge.
15. If unusually large number of students are failing or obtaining high mark
submit a report in seal cover to the Officer-In-charge.
16. In case of marginal marks such as 35-40% reverify correctness of
assessment.
17. In case of less than 40% marks obtained underling such marks with red
ink.
18. Fill the feedback form with utmost care.
19. Enclose the supervisors report, attendance sheet and the feedback form
along with marklist.
20. Ensure that the marklist with all other documents is properly sealed.
21. Write your name and affix your signature on the front page of the answer
book in the space provided.
22. Submit the assessed packet along with other documents to the Officer-incharge.
23. Submit your Remuneration bill in time.

66
