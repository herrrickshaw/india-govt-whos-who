---
doc_id: "3bae16da9b3dce7e"
source_url: "https://webassets.unigoa.ac.in/uploads/confg_docs/20240819.110549~BE_Exam_Nov-Dec_24.pdf"
ministry: "Goa University, Goa"
title: "Notification: Admissions to the B.E. (Sem V-VIII) programs for the examinations to be held during Nov/Dec 2024"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "6f79ed887e60d253"
---

<!-- page 1 -->

g ऱ्य
x ब
GOA UNIVERSITY
Established. hy State Legislature by Notification No. LD {10/7/84 (D) of 1984
Taleigao Plateau, Goa — 403 206 INDIA
Phone No: 8669609037 /8669609034 Fax: 2456108;
Email: coe@unigoa.ac.in, arexamprof@unigoa.ac.in Web: www.unigoa.ac.in
i
GU/11/230/Exam-(Prof} /2024/02$9- Date: 14/08/2024
NOTIFICATION
It is notified for the information of all concern that the following dates have been fixed for
receipt of offline application forms for admission to the following Bachelor of Engineering

(Semester V - VIII) programs for the examinations to be held during, November/ December,

2024. Colleges to decide on the dates of filling of exam forms for Semesters I - IV.
xe. |

on or before
.
ta
03/09/2024
Rs.340/-)

1. The Examinations for Theory shall be conducted from 18/11/2024. The detailed Time-Table
shall follow separately.

2. The examination fees shall be applicable as per the fee structure for the academic year 2024-
25 notified vide Notification No.GU/Exam Fee/20/ 2024/702 dated 27/03/2024.

3. The Principal of the college should ensure that the offline examination forms submitted by the
candidates are complete in all respects. Similarly, the eligibility of the respective candidates as
per the Rules/Ordinances applicable for appearing at the concerned examinations/semester
shall also be verified and checked by the College before sending the application forms to the
University.

4, Exam fees to be paid by the students to the college account. College to send consolidated
payment to the University along with the forms.

5. The Principal of the college shall forward NSS marks to NSS Coordinator and Sports marks to
Asst. Director of Sports, along with duly certified list of the students by 5/11/2024. NCC&
Cultural/Sports marks duly signed by the Principal to be sent to Examination Section by

। 08/11/2024.
6. Sessional marks to be sent in Excel format {compulsory) along with the hard copy signed by
| the Principal by 25/11/2024.

7. Incomplete forms and forms sent without the prescribed fee shall not be accepted by the
University.

8. A detailed statement showing the number of students appearing the examinations, subject-
wise in each semester (V to VIII}, is required to be forwarded to the University along with the
prescribed fees. Details of fees like Exam. Registration fee, Exam. Form fee, Examination fee,

| mark sheet fee etc, to be shown separatcly.

9. College should not accept any form after 06/09/2024.

10. The last date of submission of examination forms by the College to the University is

| 12/09/2024.
| cod BR Kona
|
To:
1. The Principal, Goa College of Engineering, Farmagudi, Ponda —Goa.
2. The Principal, Padre Conceicao College of Engineering, Verna-Goa.
3. The Principal, Shree Rayeshwar Institute of Engineering & Info. Tech., Shiroda, Goa.
4. The Principal, Don Bosco College of Engineering, Fatorda, Margao - Goa.
5. The Principal, Agnel Institute of Technology & Design, Assagao, Bardez — Goa.
C.C. To:
1. The Dean, Faculty of Enginecring, G.U.
2. Office Copy
