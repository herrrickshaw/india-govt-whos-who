---
doc_id: "44ae1336aef5ebbd"
source_url: "https://webassets.unigoa.ac.in/uploads/confg_docs/20260709.141935~ExamUG_Notific_Oct-Nov_25.pdf"
ministry: "Goa University, Goa"
title: "Notification: Semester End Examination (SEE) - Oct/Nov 2025 (UG)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "372dcf42d0c245b4"
---

<!-- page 1 -->

sEllt{"lEEUBBil&ltj
sSlflruU3UBUrE!$

rilqffi6

Goa University

ilr(iFiiE qart,

Taleigao Plateau, Goa-403 206

Tel :

+91-8669509048
registrar@unigoa.ac.in
Email :

rtrq -xol ?oe
q+{: +qq_4qqqqoioYZ

Website: www.unigoa.ac-in
(Accredited by I'{AAC)

Ref. No: GU/Exam-UG/20251 5

5+

Date: oJ /0912025
NOTIFICATION

It is hereby notified for the information of the Principals of the Affiliated Colleges that the date for filling
and submission of exam forms of the following UG Programmes for admission to the Semester End
Examination (SEE) to be held in October/November 2025 will be as follows:

1,. Programmes:
REGULAR

o B.A, B.Sc, B.Com, B.C.A (OA-38) [NEP]

REPEAT

o B.A, B.Sc, B.Com (OC-66)
o B.C.A (oC-47A & oC-67)
o B.Sc. Home Science (OC-39A)
o B.Sc Fashion and Apparel Design & lnterior Design (OC-74)
o B.S.W (oA-34)
REGULAR & REPEAT

. B.Ed (Oc-61)
. B.Sc.B.Ed./ B.A.B.Ed. (OC-54)
. B.P.Ed. (oc-62)
o B.Ed Special (OC-63)
o BVoc. (OA-23)

2. Date of Commencement of Examinations:25ltOl2O25.
3. lnstruct the students to register on ABC porta! for ABC tD
4. Steps lnvolved in Exam Registration (Students):

l.
ll.
lll.
lV.
V.

Submission of the Online Exam Form will begin on O3lO9l2O25.
Lin k: https://exam.unieoa.ac.in
Students registered in GUMS will have to fill the exam form in Physical Mode.
ABC lD is compulsory for exam registration
Students answering Semester V (Regular) & Vl (Repeat) will register on the University portal
but pay the exam fees to the respective colleges. Students are instructed to download & print
the exam form and submit it to the HOD for correctness of papers lno. of credits.
Exam Forms without late fees will be opened up until O8lO9l2O25 05:00 PM.
After 08/0912025 05:00 PM, a Late Fee of 1355/- will be applicable il L].loglz02s.
No Further Extension will be allowed.

<!-- page 2 -->

/

5. For Principals:

L

ll.

lll.
lV.
V.
Vl.
Vll.
Vlll.
lX.
X.

A list of Students who have submitted the exam form will be mailed to the principals at the
end of each day. A final consolidated list will be sent on L2lO9l2O25.
Discrepancies, if any, should be reported to the AR - Exam UG (arexamug@unigoa.ac.in) with a
CC to COE (coe@unigoa.ac.in) by L910912025. Even if no Discrdpancy is reported, the NIL
report is to be sent compulsorily, Changing the Subject/Papers will not be allowed. (format
enclosed).
Fees are to be collected by the college from students by L9lO9l2O25 based on the list sent by
Goa University on 12/09/2025.
College to report to the COE on or before 22/0912025 by email the list of students who have
not paid the fees as on 19/0912025 without fail.
9O% of fees are to be remitted to University on or before 04lL1-l2O25.
Physical Exam forms of Students registered in GUMS should be submitted by 221O912025 to
the office of AR - Exam UG.
List of ISA defaulters/lneligible candidates should be submitted by 3OlO9l2O25. Even if there
are no students, the NIL report is to be sent without fail.
The candidate list / Admit card will be generated only after the submission of the NIL
reports.
BV tLlnl2025, Candidate List and Admit Cards will be generated and sent to colleges by Goa
University. Changing the Subject/Papers will not be allowed once the Candidate List & Admit
Cards are generated.
Principals are advised to ensure that the marks are sent to the Exam Division on or before the

following days:
7. ISA Marks on or before23lLOl2O25.
2. NCC/Cultural Marks duly signed by the concerned, if any, on or before 23lLOl2O25.
3. NSS/Sports Marks to the concerned ln-Charge/Coordinator on or before 2OlLOl2O25.
NSS/Sports marks are not to be sent directly to COE or AR-Exam(UG).

6. The examination fees to be collected from the students will be as per university Circular No.
GU/Exam Feel 2O 12O25177, Dated LO 106I 2025.

7. No Forms beyond the dates mentioned will be accepted by the examination section.
Principals of the affiliated colleges are requested to kindly take note of the same and bring the content
of this notification to their concerned staff and students.

coNrRoLL

W^*rNAnoNs
\

To

L.
2.
3.
4.

Principals of the Affiliated Colleges.
On-Campus Deans & Programme Directors (BA & BVoc Programme)
AR-Exam (UG)

The HOCC ---l

s. PAtoR F
to VC -)
6.

For lnformation

PS

7. Finance Officer
8. IQAC (Publishing on Website)
9. Social Media Champion
10. Social Media Consultancy
