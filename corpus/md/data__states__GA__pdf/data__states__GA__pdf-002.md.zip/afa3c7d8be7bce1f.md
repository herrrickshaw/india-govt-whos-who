---
doc_id: "afa3c7d8be7bce1f"
source_url: "https://goacivilsupplies.gov.in/wp-content/uploads/2025/05/Corrigendum-to-The-Consumer-Protection-E-Commerce-Rules-2020.pdf"
ministry: "Civil Supplies and Consumer Affairs Department, Goa"
title: "Corrigendum to The Consumer Protection (E-Commerce) Rules, 2020"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1ed2213fd34148d0"
---

<!-- page 1 -->

जसरी ं. डी.ए.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-05082020-220863
xxxGIDHxxx
CG-DL-E-05082020-220863
xxxGIDExxx
अाधा
EXTRAORDINARY
भाग II—खणड 3—उ-खणड (i)
PART II—Section 3—Sub-section (i)
पाजधका े पकाजित
PUBLISHED BY AUTHORITY
ं. 383]
No. 383]

नई दली, बुधवा, अगसत 5, 2020/शाव 14, 1942
NEW DELHI, WEDNESDAY, AUGUST 5, 2020/SRAVANA 14, 1942
MINISTRY OF CONSUMER AFFAIRS, FOOD AND PUBLIC DISTRIBUTION
(Department of Consumer Affairs)

CORRIGENDUM
New Delhi, the 4th August, 2020
G.S.R. 488(E).— In the notification of the Government of India, Ministry of Consumer Affairs, Food and
Public Distribution, Department of Consumer Affairs, number G.S.R. 462 (E), dated the 23 rd July, 2020, published in
the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i), dated 23rd July, 2020 (Issue No. 358), –
(i)

in page 8, in line 40, for “(क)”, read “(a)”;

(ii)

in page 8, in line 41, for “(ख)”, read “(b)”;

(iii)

in page 8, in line 42, for “(ग)”, read “(c)”;

(iv)

in page 8, in line 43, for “(घ)”, read “(d)”;

(v)

in page 9, in line 52, for “(ङ)”, read “(e)”;

(vi)

in page 10, in line 1, for “(च)”, read “(f)”;
[F. No. J-10/3/2018-CPU]
ANUPAM MISHRA, Jt. Secy.

3498 GI/2020
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. SURENDER
MAHADASAM
Digitally signed by SURENDER
MAHADASAM
Date: 2020.08.05 20:46:27 +05'30'
