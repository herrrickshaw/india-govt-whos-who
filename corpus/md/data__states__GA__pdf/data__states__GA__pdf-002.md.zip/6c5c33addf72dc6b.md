---
doc_id: "6c5c33addf72dc6b"
source_url: "https://webassets.unigoa.ac.in/uploads/confg_docs/20261008.150424~MEd_Exam_Oct26.pdf"
ministry: "Goa University, Goa"
title: "Notification: Master of Education October 2026 Examination"
date: ""
pages: 2
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "685f14fcc4f579c9"
---

<!-- page 1 -->

गोय r sh ) G डु डू
गोंय विद्यापीठ का oa University
dante wet, = A Taleigao Plateau,Goa - 403 206
गोंय - ४०३ २०६ OX BD Tel : +91-8669609048
फोन : 4. ९९ - ८६६९६०९०४८ CES Email: registrar@unigoa.ac.in
PH Re ६0०९ Website: = www.unigoa.ac.in
(Accredited by NAAC with Grade A+)
Ref. No: GU/Exam-PG/2026/ 3 3 | Date: 0 10/2026
NOTIFICATION
It is hereby notified for the information of the Principal of GVM’s Dr. Dada Vaidya College of
Education that the date for filling and submission of application forms of the Master of Education
Programmes coming under OC-29 Ordinance for admission to the following examination at the Affiliated
College to be held in October, 2026 will be as follows:
1) Part -1/Il Examinations :-
COMMENCEMENT END DATE
ORDINANCE | PROGRAMMES OFEXAMINATION | OF EXAMINATION
|
| S.Y Master of Education 14" October 2026
{ sth
०८-29 | 28" October 2026
| F.Y Master of Education | 15" October 2026
2) For Students:-
_Steps Involved in Exam Registration :-
1. Online Paper Registration will begin from 07" October 2026. .
Link : - https://forms.gle/tx6nmNieYMGhqwq/76.
ll. Students have to complete the online paper registration by filling up the
google form.
ill Immediately after filling up the google form, student have to complete the
Exam Form by payment of fees through SB Collect by 11'* October 2026.
No Further Extension will be allowed.

IV. The receipt generated in SB Collect portal needs to be uploaded on google
form & download the acknowledgment receipt sent to their registered
email id, without which the form will be considered incomplete and form
will be rejected.

V. Students have to submit the acknowledgment receipt to their College
office.
3) For Course Co-ordinator of the College:-

|. Acknowledgement receipt hard copy collected from the student & Examinations
Time-Table to be sent to the University by the College by 13 October 2026.

Il. By 13" October 2026 , Candidate List and Admit Cards will be generated and sent to
the College.

Il. By 13 October 2026, Blank Marks Input Forms of ISA will be sent to the College.

<!-- page 2 -->

IV. ISA marks (Hard copy and Soft Copy) to be submitted to the University by 19"
. October 2026.
4) The Examinations Fees to be collected from the students will be as per university
Circular No. GU/Exam Fee/20/2026/80, Dated 29/06/2026.
5) No Forms will be accepted in the examination section beyond dates
mentioned.
Principal of the college is requested to kindly take the note of the same and bring the content of
this notification to their concerned staff and students.
Principal of the College is requested to widely publicize the Notification copy in order to ensure
all the students planning to appear for the examination are informed.
coma ea ळर
To
1. Principal of the GVM’s Dr. Dada Vaidya College of Education
2. Finance Officer :
3. ARPR (Publishing on Newspaper and Social Media)
4. IQAC (Publishing on Website)
