---
doc_id: "d03ff2e5e8d4cbf5"
source_url: "https://forest.goa.gov.in/sites/default/files/2024-08/Office%20of%20the%20Dy.%20Conservator%20of%20Forests.pdf"
ministry: "Forest Department, Goa"
title: "Tender regarding Supply of kits combat human wildlife conflicts, wlidlife rescue & forest fire"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "2f11553c8a6c9131"
---

<!-- page 1 -->

| }
| क शं
कु ठी
Wwe
- t
Government of Goa
i Office of the Dy. Conservator of Forests,
i South Goa Division,
Aquem, Margao-Goa, 403 601
! Phone/Fax: - 0832-2750246/2751462_E mail: defsouth-forest.goa@nic.in
No.7 /Accts/RES-Fire/ DCFS/2024-25/ 4-14 Dated: -O5 /08/2024,
QUOTATION,
To,
‘Sealed rate quotation is invited towards supply of kits to combat human wildlife conflicts,
wildlife rescue & forest fire. The quotation should be subscribed as “Supply of kits to combat
human wildlife conflicts, wildlife rescue & forest fire.” and should reach the undersigned on
or before 28,08,2024 at 3.00 p.m. and will be opened on the same day in the presence of tenders
ifany.
Sr. Specification Qty ‘Amount
No
Water bottles | Stainless Steel 1000ml Water Bottle | 1
Vacuum Insulated Non-Toxic BPA
Free
Bags 35 LTR Rucksack Travel Backpack | 1
Bag for ‘Trekking, Hiking with
Shoe/Water bottle Com, ent
Field note book | Spiral-Bound, Kraft Cover,
Lightweight, Pleasing Designs (AS,
160 Pages, 100 GSM,
Torch LED Rechargeable Torch Flashlight
with C Pin Mobile Charging
TERMS & CONDITIONS Lee el
1. The rate should be quoted on your own letter head and the same should be sent to this office
on or before 28.08.2024 Failing which the same will be rejected.
2. All the rates should be quoted exclusive of sales tax, any other taxes, duties charge ete. if
any such charges are chargeable on the basic price/rated then the same should be quoted
separately.
3. The rates quoted should remain valid from a period of 45 days from the date of opening of
quotation.
4. The work/supply should be completed within a period of 30 days from the date of receipt of
firm supply/work order from this office.
5. The full rights either to accept or reject all or any quotation are hereby reserved by the
undersigned without any reason thereof.
D (or ator of Borests;
Southi Goa Divisipn
Margao-Goa.
