---
doc_id: "bf2a7d65fca00e3d"
source_url: "https://fisheries.goa.gov.in/wp-content/uploads/2026/02/Guideline-d-SPF-Certification.pdf"
ministry: "Fisheries Department, Goa"
title: "Click Here"
date: ""
pages: 15
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "03b51cdf9f625667"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-20032024-253249
xxxGIDHxxx
CG-DL-E-20032024-253249
xxxGIDExxx

असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (ii)
PART II—Section 3—Sub-section (ii)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 1410]
No. 1410]

नई दिल्ली, मंगलिार, माचच 19, 2024/फाल्गुन 29, 1945
NEW DELHI, TUESDAY, MARCH 19, 2024/PHALGUNA 29, 1945

मत्सस्ट्यपालन, पिुपालन और डेयरी मंत्रालय
मत्सस्ट्यपालन जिभाग
अजधसूचना
नई दिल्ली, 15 माचच, 2024
का.आ. 1479(अ).—के न्द्रीय सरकार, तटीय िलीय कृ जि प्राजधकरण जनयम, 2024 के जनयम 3 के खंड (घ) के
साथ पठित, तटीय िलीय कृ जि प्राजधकरण अजधजनयम, 2005 (2005 का 24) की धारा 3 के अनुसरण में, जनम्नजलजखत
दििाजनिेि अजधसूजचत करती है, अथाचत् :1.
संजिप्त नाम और प्रारं भ. - (1) इन दििाजनिेिों का संजिप्त नाम भारत में तटीय िलकृ जि इकाइयों और स्ट्टॉकों की
स्ट्िास्ट््य जनगरानी, रोग जनगरानी और जिजिष्ट रोगिनक मुक्त (एसपीएफ़) प्रमाणन दििाजनिेि है ।
(2) ये रािपत्र में उनके प्रकािन की तारीख से लागू होंगे ।
भारत में तटीय िलकृ जि इकाइयों और स्ट्टॉकों के स्ट्िास्ट््य जनगरानी, रोग जनगरानी और जिजिष्ट रोगिनक मुक्त (एसपीएफ़)
प्रमाणन दििाजनिेि ।
1. प्राक्कथन - ये दििाजनिेि िोजखम जिश्लेिण, िोजखम िमन उपायों, जनरीिण और प्रमाणन के माध्यम से रोगों और
कीटों के प्रभाि से िेत्र की सुरिा के जलए भारत में तटीय िलीय कृ जि इकाइयों और स्ट्टॉक के स्ट्िास्ट््य जनगरानी, रोग
जनगरानी और जिजिष्ट रोगिनक मुक्त प्रमाणीकरण और भारतीय िलकृ जि िेत्र के जलए िमन प्रजतदिया व्यिस्ट्था के

2099 GI/2024

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

कायाचन्द्ियन के जलए व्यापक आिश्यकताओं तक ही सीजमत नहीं है, बजल्क यह उनके जलए व्यापक अपेिाओं की
रूपरे खा हैं ।
2. लागू होना - (1) ये दििाजनिेि सभी तटीय िलीय कृ जि इकाइयों पर लागू होंगे, जिनके जलए तटीय िलीय कृ जि
प्राजधकरण जनयम, 2024 के जनयम 19 के अधीन जिजिष्ट रोगिनक मुक्त प्रमाणीकरण आज्ञापक है :
परं तु ये दििाजनिेि हैचरी सजहत अन्द्य तटीय िलीय कृ जि इकाइयों को भी लागू होंगे, िो जनयम 19 के अधीन नहीं
आती है, ककं तु स्ट्िेच्छा से जिजिष्ट रोगिनक मुक्त प्रमाणीकरण का जिकल्प चुनती हैं ।
3. िैि सुरिा - (1) तटीय िलीय कृ जि इकाइयों में पयाचप्त िैि सुरिा होगी िो एक सामठरक और एकीकृ त एप्रोच
होगी िो संबंजधत पयाचिरणीय िोजखम और िलीय कृ जि में रोगों की रोकथाम सजहत प्रिाजतयों के िीिन और
स्ट्िास्ट््य में िोजखमों का जिश्लेिण और प्रबंधन करेगी ।
(2) तटीय िलीय कृ जि इकाइयों के संचालक प्रत्सयेक इकाई, कल्चर प्रणाली और स्ट्िच्छता िेत्र के जलए जिजिष्ट िैि
सुरिा उपायों को लागू करेंगे, जिसमें उच्च िोजखम का प्रजतजनजधत्सि करने िाली सभी रोगों के पठरणामों से सुजिधाओं
की सुरिा के जलए आिश्यक भौजतक, रासायजनक और िैजिक जिजधयां िाजमल हो सकती हैं ।
(3) किोर िैि सुरिा उपायों को प्राथजमकता िाले िेत्रों में जनम्नजलजखत िाजमल हैं, अथाचत् :(i)

साइट या अिस्ट्थान;

(ii)

पानी का इनटेक ;

(iii)

स्रोत िल उपचार ;

(iv)

िैि सुरिा के जिजभन्न स्ट्तरों के साथ जिभािन, जोनेिन और भौजतक पृथक्करण या जिलग करना ;

(v)

स्ट्िच्छता और कार्मचक साफ-सफाई ;

(vi)

प्रभागों और िोनों के बीच कर्मचयों का आिागमन ;

(vii)

िीजित या तािा या प्रिीजतत फीड स्रोत ;

(viii) नए िलीय कृ जि स्रोतों या आनुिंजिक सामजियों को लाना ;
(ix)

जडसपैच और लोडडंग ;

(x)

तटीय िलकृ जि इकाई के भीतर और बाहर िाहन, कर्मचयों और आगंतुकों का प्रिेि और बाहर
जनकलना; और

(xi)

अन्द्य िो प्राजधकरण द्वारा समय-समय पर जिजनर्िचष्ट दकए िाएं ।

4. सतत स्ट्िास्ट््य जनगरानी और रोग पयचिि
े ण - दकसी भी तटीय िलकृ जि इकाई या स्ट्टॉक को जिजिष्ट रोगिनक मुक्त
के रूप में प्रमाजणत दकया िाएगा, यदि (i) इसमें संलग्न िातािरण के भीतर उजचत िल उपचार के साथ िैि-सुरजित सुजिधाएं हैं ;
(ii) यह िैि-सुरजित फीड सजहत िैि-सुरजित प्रबंधन का पालन करता है ;
(iii) इसने जनगरानी कायचिम के माध्यम से कम से कम िो ििों की जनरं तर अिजध के जलए जिजिष्ट रोगिनकों के
जलए नकारात्समक परीिण पठरणाम प्राप्त दकया है ।
(2) जिजिष्ट रोगिनक मुक्त प्रमाणीकरण के जलए आिेिन करने िाली कोई भी तटीय िलकृ जि इकाई,(i) जनरं तर आधार पर प्रिाजतयों के जिजिष्ट रोगिनकों से मुजक्त सुजनजित करने के जलए जनरंतर स्ट्िास्ट््य
जनगरानी और रोग जनगरानी कायच हाथ में लेती है ;

<!-- page 3 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

3

(ii) आिश्यक आकजस्ट्मक योिना बनाना तादक रोगो के प्रकोप को जनयंजत्रत करने और रोगों को और फै लने से
रोकने के जलए त्सिठरत कारच िाई की िा सके ।
(3) स्ट्िास्ट््य जस्ट्थजत का आकलन करने के जलए तटीय िलीय कृ जि इकाई, िल, पिु, िैिाल और अन्द्य फ़ीड की
जनयजमत िांच करने के जलए तटीय िलीय कृ जि इकाई को िेट लैब और माइिोजबयल पैथोलॉिी प्रयोगिालाओं
से सुसजित दकया िाएगा।
(4) कें रीय सरकार, िलीय प्राणी रोगों के जलए राष्ट्रीय जनगरानी कायचिम की तकनीकी सलाहकार सजमजत के
परामिच से रोगिनकों, जिन पर ध्यान िेने की आिश्यकता है, को जनर्िचष्ट करेगी, िो प्रत्सयेक उम्मीििार प्रिाजत,
कायचप्रणाली या प्रदिया और परख के जलए जिश्व पिु स्ट्िास्ट््य संगिन द्वारा सूचीबद्ध नहीं हैं । उस रोगिनक या
उससे िुडे दकसी अन्द्य मामले का परीिण, प्रत्सयेक प्रिाजत-जिजिष्ट तटीय िलीय कृ जि इकाई के जलए सूक्ष्म
िीिजिज्ञानी सूचकांक के अनुसार दकया िाएगा ।
(5) स्ट्िास्ट््य जनगरानी और रोग जनगरानी और परीिण जिश्व पिु स्ट्िास्ट््य संगिन के रोग जनगरानी पर िलीय
प्राणी स्ट्िास्ट््य संजहता के अनुच्छेि 1.4.6 में अध्याय 1.4 में जनधाचठरत प्रदियाओं के आधार पर दकया िाएगा।
(6) जिश्व प्राणी स्ट्िास्ट््य संगिन के िलीय प्राजणयों के जलए नैिाजनक परीिणों के जनयमों में जनधाचठरत प्रदिया का
सभी परीिण प्रदियाओं में पालन दकया िाएगा ।
(7) सतत स्ट्िास्ट््य जनगरानी और रोग जनगरानी िो चरणों में होगी, अथाचत् :(i) एक सिक्त इन-हाउस स्ट्िास्ट््य जनगरानी और रोग जनगरानी कायचिम जिसमें स्ट्ियं प्रचालक द्वारा
सत्सयापन योग्य इन-हाउस िैि सुरिा संपरीिा सजम्मजलत है ; और
(ii) पैनलबद्ध अजभकरण द्वारा अजभरिा नमूनाकरण और परीिण की एक श्ृंखला ।
5. सत्सयापन की िा सकने िाली इन-हाउस िैि सुरिा संपरीिा.- (1) तटीय िलीय कृ जि इकाइयों के संचालक यह िांचने
के जलए एक सत्सयापन की िा सकने िाली इन-हाउस िैि सुरिा संपरीिा लागू करेंगे दक ऐसी तटीय िल कृ जि इकाई में
उन िैि सुरिा उपायों को दकतनी अच्छी तरह से दियाजन्द्ित दकया िाता है।
(2) तटीय िलीय कृ जि इकाइयों के संचालक सुजिधाओं के आकार और जडिाइन और ऐसी बीमाठरयों, जिन पर ध्यान
िेना आिश्यक है, के आधार पर तटीय िलीय कृ जि इकाई में िैि सुरिा के जलए जिजभन्न स्ट्तरों, िेत्रों, प्रभागों और
रणनीजतयों को जनयोजित करेंग।े
(3) तटीय िलीय कृ जि इकाइयों के संचालक एक जििेिज्ञ द्वारा तटीय िलीय कृ जि इकाई में कायाचजन्द्ित दकए िा रहे
िैि सुरिा उपायों का त्रैमाजसक इन-हाउस मूल्यांकन करेंगे और िैि सुरिा सुजनजित करने के जलए आिश्यक संपरीिा
ठरपोटच के आधार पर ऐसी आिश्यक सुधारकारी कारच िाई करेंगे और तटीय िलकृ जि इकाई की िैि सुरिा सुजनजित
करें गे ।
(4) त्रैमाजसक संपरीिा ठरपोटच तटीय िलीय कृ जि इकाई के जनरीिण और अजभरिा के नमूने की श्ृंखला के िौरान
अजधकृ त कर्मचयों द्वारा सत्सयापन के जलए उपलब्ध कराई िाएगी ।
(5) जिजिष्ट रोगिनक मुक्त प्रमाणीकरण के प्रमाण के रूप में िैि सुरिा संपरीिा और प्राजधकृ त कर्मचयों द्वारा इसकी
िांच का अजभलेख रखा िाएगा ।
6. इन-हाउस स्ट्िास्ट््य जनगरानी और रोग जनगरानी - (1) संबंजधत प्रसुजिधाएं नमूने और परीिण और पठरणामों के जलए
उजचत आिृजि के साथ अपने स्ट्टॉक की स्ट्िास्ट््य जस्ट्थजत और गुणििा की जनगरानी के जलए एक इन-हाउस स्ट्िास्ट््य
जनगरानी और रोग जनगरानी कायचिम लागू करेंगी । संबंजधत तटीय िलीय कृ जि इकाई में इन-हाउस जनगरानी उजचत
रूप से बनाए रखी िाएगी ।
(2) इन-हाउस स्ट्िास्ट््य जनगरानी और रोग जनगरानी में परीिा के तीन स्ट्तर िाजमल हैं, अथाचत् :(क) सामान्द्य स्ट्िास्ट््य जस्ट्थजत, डलंग जनधाचरण, जडम्बिंजथ जिकास की स्ट्टेडिंग, मोल्ट स्ट्टेडिंग, रोगी
या अस्ट्िस्ट्थ को हटाने के जलए स्ट्टॉक की िांच ;

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(ख) माइिोस्ट्कोप द्वारा लािाच चरणों की िांच, सामान्द्य या मरणासन्न प्राजणयों के िीिाणु
िनस्ट्पजतयों की िांच करना ; और
(ग) ब्रूड स्ट्टॉक और पेरेंट पोस्ट्ट लािाच की रोग िांच पॉलीमरे ज चेन ठरएक्िन, जहस्ट्टोपैथोलॉिी और
या कोई अन्द्य प्रासंजगक उन्नत तकनीक ।
(3) स्ट्िीडनंग निीनतमजिश्व पिु स्ट्िास्ट््य संगिन - िलीय िीिों के जलए नैिाजनक परीिणों के मैनअ
ु ल में
जनधाचठरत प्रदियाओं के अनुसार निीनतम पॉलीमरे ज चेन ठरएक्िन (पीसीआर) या रीयल-टाइम ठरिसच
रांसदिपटेस पॉलीमरे ज चेन ठरएक्िन (आरटी-पीसीआर) तकनीक का उपयोग करके योग्य और प्रमाजणत
प्रौद्योजगकीजििों द्वारा संचाजलत की िाएगी। ।
(4) प्रत्सयेक प्रिाजत के जलए नमूने की आिृजि और नमूना आकार प्राजधकरण द्वारा घोजित दकया िाएगा।
(5) इन - हाउस रोग जनगरानी प्रोटोकॉल के रखरखाि के जलए प्रत्सयेक नमूने के िौरान बीस नमूनों के आकार
के साथ नमूने की आिृजि पर सामान्द्य मागचजनिेि नीचे िी गई सारणी में दिए िाएंगे :
सारणी 1

1
2
3.
4.
5.

स्ट्िीडनंग
आिृजि
(प्रचालन के
दिन)
(2)
30
60
90
120
150

(3)
2 से 3
13 से 15
22 से 28
33 से 37
42 से 48

6.

180

50 से 53

स्ट्िीडनंग
नंबर
(1)

भार की
संभाजित रें ि
(िाम)

परीिण दकए िाने िाले पैरामीटर

पुजष्टकारक स्ट्िीडनंग

(4)
िल्डच ओरगनाईिेिन फॉर एजनमल हेल्थ
द्वारा सूचीबद्ध सभी रोगिनकों और
संबंजधत प्रिाजतयों के जलए कें रीय
सरकार द्वारा जनर्िचष्ट डचंतायुक्त गैरसूचीबद्ध रोगिनकों की िांच की
िाएगी ।

(5)
पुजष्टकरण
स्ट्िीडनंग
जहस्ट्टोपैथोलॉिी
के
माध्यम से और पॉलीमरे ज
चेन ठरएक्िन उत्सपािों का
पता लगाने के बाि
अनुिमण के माध्यम से
की िाएगी

(6) दकसी भी रोग या रोगिनक के घठटत होने की जस्ट्थजत में, तटीय िलीय कृ जि इकाई संचालक तुरंत ऐसे किों
को अलग कर िेगा और उनके संचालन को इस तरह जनयंजत्रत करेगा दक तटीय िलीय कृ जि इकाई के अन्द्य
िेत्र िूजित न हों और इसकी ठरपोटच तुरंत प्राजधकरण की िी िाएगी ।
7. नमूने और परीिण की प्रदिया :
क. नमूने और परीिण की प्रदिया के जलए पैनलबद्ध अजभकरण - (1) प्राजधकरण रोगों या रोगिनकों जिन पर
ध्यान िेने की आिश्यकता है, के जलए नमूने और परीिण की प्रदिया के प्रयोिन के जलए भारतीय कृ जि
अनुसंधान पठरिि - सेंरल इंस्ट्टीट्यूट ऑफ ब्रैदकििॉटर एक्वाकल्चर, नेिनल ब्यूरो ऑफ दफि िेनेठटक
ठरसोसेि, रािीि गांधी सेंटर फॉर एक्वाकल्चर, दफिरीि यूजनिर्सचटीि औरजिश्व पिु स्ट्िास्ट््य संगिन
रेफरल प्रयोगिालाएं और जनिी अजभकरणों सजहत दकसी भी सरकारी या अधच-सरकारी संगिनों को
सूचीबद्ध और अजधकृ त करेगा, यदि (i) िे परीिण और अंिांकन प्रयोगिालाओं के जलए राष्ट्रीय प्रत्सयायन बोडच द्वारा मान्द्यता प्राप्त हैं
(ii) िे एकाजधक रोगजनकों की स्ट्िीडनंग के जलए राष्ट्रीय या अंतराचष्ट्रीय ररंग टेस्ट्ट में अर्हचत हैं ।
(iii) ऐसे पैनलीकरण के जलए प्राजधकरण द्वारा जनर्िचष्ट जनयमों और ितों और अन्द्य मानिंडों को पूरा करते हैं ।
(2) प्राजधकरण संबंजधत इकाइयों से जनर्िचष्ट अंतराल पर परीिण के जलए नमूने एकत्र करने के जलए रोस्ट्टर
प्रणाली का पालन करते हुए सूचीबद्ध और प्राजधकृ त अजभकरणों को अजधकृ त करेगा, परंतु दकसी भी तटीय
िलीय कृ जि इकाई से नमूनाकरण और परीिण में पारिर्िचता सुजनजित करने के जलये लगातार िो बार
एक पैनलबद्ध अजभकरण द्वारा नमूने का संिह और परीिण करिाने से बचा िाएगा ।

<!-- page 5 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

5

(3) नमूने और परीिण की प्रदिया के जलए सूचीबद्ध और प्राजधकृ त अजभकरण अपने परीिण के पठरणामों की
गोपनीयता बनाए रखते हुए प्राजधकरण को िल्ि से िल्ि ठरपोटच करेगी ।
(4) नमूने प्राजधकृ त कार्मचकों या सूचीबद्ध और प्राजधकृ त अजभकरण की प्रयोगिाला द्वारा जनकाले, संगह
ृ ीत और
परीिण दकए िाएंगे और ऑपरेटर दकसी भी तरह से नमूना नहीं लेगा और इस कायचिम के अधीन तृतीय
पि को परीिण के जलए प्रस्ट्तुत नहीं करेगा।
(5) पैनलबद्ध अजभकरणों को त्रैमाजसक इन-हाउस िैि सुरिा संपरीिा, इन-हाउस रोग स्ट्िीडनंग और उनकी
ठरपोटच को सत्सयाजपत करने के जलए भी प्राजधकृ त दकया िाएगा।
(6) प्राजधकरण अजभरिा नमूना संिह और परीिण की श्ृंखला के जलए एक िुल्क तय करेगा और पैनल में
िाजमल अजभकरणों को इसका भुगतान करेगा ।
ख. रोग जनगरानी प्रदिया.- (1) नमूने की आिृजि, नमूना आकार और अजभरिा में के नमूने और परीिण
प्रोटोकॉल की श्ृंखला के रखरखाि पर सामान्द्य मागचििचन नीचे िी गई सारणी के अनुसार होगा :सारणी - 2
स्ट्िीडनंग नंबर

स्ट्िीडनंग आिृजि
(ऑपरे िन के दिन)

(1)

(2)

नमूना सेट

(3)

ििन की
संभाजित सीमा.
(िाम)

परीिण दकए िाने
िाले पैरामीटर

पुजष्टकारक स्ट्िीडनंग

(4)

(5)

(6)

िल्डच ओरगनाईिेिन
फॉर एजनमल हेल्थ
द्वारा सूचीबद्ध सभी
रोगिनकों
और
संबंजधत प्रिाजतयों के
जलए कें र सरकार
द्वारा
जनर्िचष्ट
डचंतायुक्त
गैरसूचीबद्ध रोगिनकों
की िांच की िाएगी।

पुजष्टकरण
स्ट्िीडनंग
जहस्ट्टोपैथोलॉिी
के
माध्यम
से
और
पॉलीमरे ज
चेन
ठरएक्िन उत्सपािों का
पता लगाने के बाि
अनुिमण के माध्यम से
की िाएगी

1.

30

60

2 से 3

2,

90

60

22 से 28

3.

180

60

50 से 53

4.

360

60

5.

540

60

6.

720

60

जिजिष्ट रोगिनक मुक्त मान्द्यता
7.

900

20

8.

1080

20

(2) नई तटीय िल कृ जि इकाईयां या प्रसुजिधाओं को 1, 3, 6, 12, 18 और 24 मास के िौरान नमूनों के जलए
अनुसूजचत दकया िाएगा और पहले, तीसरे और छिे मास के िुरुआती 3 नमूनों का प्रत्सयेक नमूना आकार 60 नमूनों
के सेट में होगा ।
(3) जिजिष्ट रोगिनक मुक्त प्रमाणीकरण प्राप्त करने के जलए या जिश्व पिु संगिन द्वारा जनधाचठरत या प्राजधकरण द्वारा
जनर्िचष्ट अनुसार िलीय प्राजणयों के जलए नैिाजनक परीिणों के मैनुअल में जनर्िचष्ट अनुसार प्रत्सयेक नमूने के िौरान 60
नमूना सेटों के साथ स्ट्िास्ट््य 12िें, 18िें और 24िें महीनों में जनगरानी और परीिण िारी रखा िाएगा।
(4) नमूना आकार, नमूना लेने की आिृजि, नमूने एकत्र करने के जलए मानक संचालन प्रदिया, प्रकार, पद्धजत या प्रदिया
और परीिण की परख जिश्व पिु स्ट्िास्ट््य संगिन द्वारा जनधाचठरत िलीय प्राजणयों के जलए नैिाजनक परीिणों के
मैनुअल में जनर्िचष्ट होगी । प्रत्सयेक प्रिाजत को प्राजधकरण द्वारा जनर्िचष्ट दकया िाएगा और इस तरह के नमूनाकरण
िासन में तटीय िलीय कृ जि इकाई में उपलब्ध सभी िीिन चरण िाजमल होंगे।
(5) तटीय िल कृ जि इकाई के जिजिष्ट रोगाणुमुक्त प्रत्सययन के सफलतापूिचक होने पर, िो अजभरिा संप्रेिण की श्ृंखला
के पिात् स्ट्टाक और िो ििच के जलए सतत कालािजध परीिण पर इसे प्रत्सयेक नमूनाकरण के िौरान बीस नमूना

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

सेटों के साथ प्रत्सयेक छह मास में एक बार या जिश्व पिु स्ट्िास्ट््य संगिन या जिजनिचष्ट प्राजधकरण द्वारा अजधकजथत के
अनुसार, िैसा दक िलीय प्राजणयों के नैिाजनक परीिम मैनुअल में जिजनर्िचष्ट दकया गया है, दकया िाएगा ।
(6) दकसी रोग के घठटत होने की जस्ट्थजत में, या सूचीबद्ध अजभकरण या प्रचालक द्वारा ठरपोटच दकए गए सकारात्समक
नमूने पर, रे फरल प्रयोगिाला को पुजष्ट करने के जलए ऑपरे टर या पैनलबद्ध अजभकरण या प्राजधकरण द्वारा
यथासंभि कम से कम समय में सूजचत दकया िाएगा । रे फरल प्रयोगिाला द्वारा पुजष्ट होने तक यूजनट का संचालन
प्राजधकरण द्वारा जनलंजबत कर दिया िाएगा ।
(7) दकसी भी रोग की घटना की पुजष्ट होने पर या रे फरल प्रयोगिाला द्वारा जनधाचठरत पुजष्टकरण सकारात्समक नमूने पर,
प्राजधकरण तकनीकी सलाहकार सजमजत के साथ संबद्ध होगा और यह सुजनजित करने के जलए जििेिज्ञों की उपसजमजत द्वारा जनरीिण के जलए संिजमत तटीय िलीय कृ जि इकाई को अधीन करे गा। िैि सुरिा व्यिस्ट्था और
तटीय िलीय कृ जि इकाई को पूरे संिजमत स्ट्टॉक को नष्ट करने और संिमण के प्रसार को रोकने के जलए अपनी
उपजस्ट्थजत में उसे नष्ट करने के जलए कहा िाएगा ।
(8) रोग की घटना या दकसी जििेि प्रभाग में रे फरल प्रयोगिाला द्वारा जनधाचठरत पुजष्टकरण सकारात्समक नमूने की
जस्ट्थजत में, प्राजधकरण यह सुजनजित करने के जलए अजभरिा में के नमूने और परीिण की पुष्ट श्ृंखला के संबंध में
जनणचय लेगा दक तटीय िलीय कृ जि इकाई में अन्द्य प्रभाग उक्त संिमण से मुक्त हैं, परं तु ऐसे संिि
ू ण को रोकने के
जलए पयाचप्त िैि सुरिा उपाय है और इसके जलए प्राजधकरण द्वारा तय दकया गया कोई भी अजतठरक्त िुल्क या िुल्क
तटीय िलीय कृ जि इकाई के प्रचालक से संगृहीत दकया िाएगा ।
8. प्रमाणीकरण का तरीका - (1) तटीय िलीय कृ जि इकाइयों या स्ट्टॉक को जिजिष्ट रोगिनक मुक्त प्रमाणीकरण के उद्देश्य
से रोग जनगरानी के अधीन दकया िाएगा िैसा दक इस दििाजनिेि के उपाबंध में उपिर्िचत दकया गया है ।
(2) मत्सस्ट्य या िलीय िीिों के जिजिष्ट रोगिनक मुक्त स्ट्टॉक के उत्सपािन में लगे दकसी भी तटीय िलीय कृ जि इकाई के
संचालक, तटीय िलीय कृ जि इकाई और उसमें जनजहत स्ट्टॉक के जिजिष्ट रोगिनक मुक्त प्रमाणीकरण के जलए
आिेिन करें गे ।
(3) जिजिष्ट रोगिनक मुक्त प्रमाणीकरण के जलए िुल्क या चािच प्राजधकरण द्वारा तय दकया िाएगा और संबंजधत तटीय
िलीय कृ जि इकाई प्रचालक द्वारा प्राजधकरण को अजिम भुगतान दकया िाएगा ।
(4) इस तटीय िलीय कृ जि इकाई में भंडारण के जलए उपयोग की िाने िाली प्रिाजतयों की उत्सपजि प्रमाजणत जिजिष्ट
रोगिनक मुक्त तटीय िलीय कृ जि इकाई से होनी चाजहए ।
(5) यथाजस्ट्थजत, नई तटीय िलीय कृ जि इकाई की ििा में, एक इकाई िो संिमण के कारण बंि होने के पिात् अपना
संचालन दफर से िुरू करती है, तटीय िलीय कृ जि इकाई को उच्च स्ट्िास्ट््य के रूप में प्रिाजतयों का जििय या भेिने
या जनयाचत करने की अनुमजत िी िाएगी। पहले, तीसरे और छिे महीने के िौरान 60 नमूनों के सेटों के साथ तीन
नकारात्समक ठरपोटच िाले नमूना के सेटों के सफल समापन पर स्ट्िास्ट््य िस्ट्तािेिों के साथ भंडार करें , लेदकन ऐसे
स्ट्टॉक को जिजिष्ट रोगिनक मुक्त स्ट्टॉक के रूप में प्रमाजणत नहीं दकया िाएगा ।
(6) प्रत्सयेक 60 नमूनों के सेट के साथ 12िें, 18िें और 24िें मास के सफल समापन पर, िो साल की जनरं तर अिजध के
भीतर नकारात्समक ठरपोटच के जलए परीिण करने के उपरांत, स्ट्टॉक और तटीय िलीय कृ जि इकाई को जिजिष्ट
रोगिनक मुक्त जस्ट्थजत के साथ मान्द्यता िी िाएगी ।
(7) तटीय िलकृ जि इकाई को जिजिष्ट रोगिनक मुक्त जस्ट्थजत की मान्द्यता और स्ट्टॉक को उच्च स्ट्िास्ट््य या जिजिष्ट
रोगिनक मुक्त के रूप में जििय करने का प्राजधकरण कें रीय सरकार द्वारा िारी दकया िाएगा ।
(8) दकसी रोग की घटना या पुजष्टकारक सकारात्समक नमूना सेट की जस्ट्थजत में, तटीय िलीय कृ जि इकाई और स्ट्टॉक की
जिजिष्ट रोगिनक मुक्त जस्ट्थजत स्ट्िचाजलत रूप से िापस ले ली िाएगी ।

<!-- page 7 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

7

(9) पुजष्टकारक सकारात्समक नमूना सेट के साथ तटीय िलीय कृ जि इकाई संचालन बंि कर िेगी और एक मास की अिजध
के जलए, यथाजस्ट्थजत, प्रभाग या संपूणच तटीय िलीय कृ जि इकाई की कीटाणुिोधन और सुखाने की प्रदिया का
पालन करे गी और रोग जनगरानी का संचालन और प्रदिया जिजिष्ट रोगिनक मुक्त प्रमाणीकरण के जलए स्ट्िास्ट््य
जनगरानी नए जसरे से आरं भ करेगी ।
9. जनगरानी एिं जिजनयमन :
क तटीय िलकृ जि प्राजधकरण - प्राजधकरण जनम्नजलजखत मामलों के जलए सिम प्राजधकारी होगा, अथाचत् :(i)

नमूने और परीिण की प्रदिया के जलए अजभकरण का पैनल बनाना ;

(ii)

पैनल में िाजमल होने के जनयम और ितें ;

(iii)

नमूने और परीिण की प्रदिया के जलए पैनलबद्ध अजभकरणों के रोस्ट्टर का जनमाचण ;

(iv)

इस कायचिम के अधीन दकसी िुल्क या चािच का जनधाचरण ;

(v)

नमूनों के संिह के जलए नमूना आकार, नमूने की आिृजि, मानक संचालन प्रदियाएं ;

(vi)

परीिण ठरपोटों और जसफ़ाठरिों की िांच ;

(vii)

रोग उत्सपन्न होने या सकारात्समक नमूना सेट होने की जस्ट्थजत में समन्द्िय और अनुिती उपाय ;

(viii)

दकसी रोग की घटना या पुजष्टकारक सकारात्समक नमूना सेट की जस्ट्थजत में तटीय िलकृ जि इकाई की
गजतजिजध का जनलंबन ; और

(ix)

कोई अन्द्य प्रिासजनक एिं पठरचालन संबंधी मामले ।

(ख) रे फरल प्रयोगिालाएँ. (1) कें रीय सरकार समय-समय पर रे फरल प्रयोगिालाओं की सूची अजधसूजचत करेगी ।
(2) जिजिष्ट रोगिनक मुक्त प्रमाणन कायचिम में भाग लेने के जलए अर्हचत होने के जलए, प्रयोगिाला परीिण
प्रयोगिाला राष्ट्रीय प्रत्सयायन बोडच और प्रत्सयजयत अंिांकन प्रयोगिालाएं होंगी और िह मत्सस्ट्यों और िलीय िीिों
के बहुल रोगाणुिनक स्ट्िीडनंग के जलए, िब तक दक के न्द्रीय सरकार द्वारा उन्द्हें ऐसी ितों से छू ट प्रिान न कर िी
िाए, राष्ट्रीय और अंतरराष्ट्रीय ररं ग टेस्ट्ट में अहचता प्राप्त करे गी ।
(3) नमूना संिह और परीिण के जलए रे फरल प्रयोगिाला के प्राजधकृ त कर्मचयों द्वारा यात्रा की लागत संबंजधत
संस्ट्थानों द्वारा िहन की िाएगी ।
(ग) तकनीकी सलाहकार सजमजत.- (1) तटीय िलकृ जि प्राजधकरण जनयम, 2024 के जनयम 19 के अधीन कें रीय सरकार
द्वारा गठित तकनीकी सलाहकार सजमजत स्ट्िास्ट््य जनगरानी, रोग जनगरानी और जिजिष्ट रोगिनक मुक्त
प्रमाणीकरण कायचिम के कायाचन्द्ियन की जनगरानी करे गी।
(2) तकनीकी सलाहकार सजमजत नमूना आकार, नमूने की आिृजि, मानक संचालन प्रदियाओं के जनधाचरण से
संबंजधत मामलों पर जनणचय लेने में प्राजधकरण की सहायता करेगी । इस कायचिम के अधीन नमूनों का संिह, िुल्क
या चािच का जनधाचरण, जनरीिण और संिजमत स्ट्टॉक को हटाने के जलए उप-सजमजतयों का गिन, रोग का पता
चलने की जस्ट्थजत में तटीय िलीय कृ जि इकाई की गजतजिजध को आंजिक या पूणच रूप से जनलंजबत करना, जिकायत
और जििाि जनिारण िाजमल हैं ।
(3) प्राजधकरण के जनणचय पर अपील, यदि कोई हो, कें रीय सरकार को की िाएगी और कें रीय सरकार का जनणचय
अंजतम होगा।
[फा. सं. िे-1903336/2/2024-डीओएफ (ई-23648)]
नीतू कु मारी प्रसाि, संयुक्त सजचि

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

<!-- page 9 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

9

MINISTRY OF FISHERIES, ANIMAL HUSBANDRY AND DAIRYING
(Department of Fisheries)
NOTIFICATION
New Delhi, the 15th March, 2024
S.O. 1479(E).—In pursuance of section 3 of the Coastal Aquaculture Authority Act, 2005 (24 of 2005), read
with clause (d) of rule 3 of the Coastal Aquaculture Authority Rules, 2024, the Central Government hereby notifies
the following guidelines, namely:1. Short title and commencement. – (1) These guidelines may be called the Guidelines for the health
monitoring, disease surveillance and Specific Pathogen Free certification of coastal aquaculture units and stocks in
India.
(2) They shall come into force from the date of their publication in the Official Gazette.
Guidelines for the health monitoring, disease surveillance and Specific Pathogen Free certification of
coastal aquaculture units and stocks in India.

1.

Introduction. - These guidelines are not limited to but outlines broader requirements for the health
monitoring, disease surveillance and specific pathogen free certification of coastal aquaculture units and stocks
in India for safeguarding of the sector from the impact of diseases and pests, through risk analysis, risk
mitigation measures, inspection and certification, and implementation of mitigation response arrangements for
Indian aquaculture sector.

2.

Application. – (1) These guidelines shall apply to the coastal aquaculture units for which specific pathogen
free certification is mandatory under the rule 19 of the Coastal Aquaculture Authority Rules, 2024:
Provided that these guidelines shall also apply to other coastal aquaculture units including hatcheries which are
not covered under rule 19, but voluntarily opt for the specific pathogen free certification.

3.

Biosecurity.- (1) The coastal aquaculture units shall have adequate biosecurity which shall be a strategic and
integrated approach that analyse and manage risks in the life and health of candidate species including
associated environmental risk and the prevention of diseases in aquaculture.
(2) The operator of the coastal aquaculture units shall implement biosecurity measures, specific for each unit,
culture system and sanitary zone which may include the physical, chemical and biological methods necessary
to protect the facilities from the consequences of all diseases that represent a high risk.
(3) The priority areas of strict biosecurity measures include the following, namely: (i)

site or location;

(ii)

water intake;

(iii)

source water treatment;

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY
(iv)

[PART II—SEC. 3(ii)]

compartmentalisation, zonation and physical separation or isolation with different levels of
biosecurity;

(v)

sanitation and personnel hygiene;

(vi)

movement of personnel between compartments and zones;

(vii)

live or fresh or frozen feed sources;

(viii)

introduction of new aquaculture sources or genetic materials;

(ix)

dispatch and loading;

(x)

entry and exit of vehicle, personnel and visitors within and into the coastal aquaculture unit;
and

(xi)

others as may be specified by the Authority from time to time.

4. Continuous health monitoring and disease surveillance.- (1) Any coastal aquaculture unit or stock shall be
certified as specific pathogen free, if(i) it has bio-secure facilities with appropriate water treatment within enclose environment;
(ii) it follows bio-secure management including bio-secure feeds;
(iii) it has tested negative for specific pathogens for a continuous period of at least two years through a
surveillance programme.
(2) Any coastal aquaculture unit applying for specific pathogen free certification shall,(i) undertake continuous health monitoring and disease surveillance, to ensure freedom from specific
pathogens of the candidate species on a continuous basis;
(ii) put in place necessary contingency plan so that prompt action can be carried out in controlling disease
outbreak and for preventing further spreading of disease.
(3)

The coastal aquaculture unit shall be equipped with a wet lab and microbial pathology laboratories for
undertaking routine screening of the coastal aquaculture unit, water, animal, algae and other feeds to assess
the health status.

(4)

The Central Government shall in consultation with the Technical Advisory Committee of the National
Surveillance Programme for Aquatic Animal Diseases, specify the pathogens of concern which are not
listed by World Organisation for Animal Health for each candidate species, methodology or procedure and
assay of testing of that pathogen or any other matter connected therewith, and Microbiological Index for
each species-specific coastal aquaculture unit.

(5)

Health monitoring and disease surveillance and testing shall be done on the basis of procedures laid down
in Chapter 1.4 in Article 1.4.6 of Aquatic Animal Health Code on Disease Surveillance of World
Organisation for Animal Health .

(6)

The procedure laid down in the Manual of Diagnostic Tests for Aquatic Animal of the World Organisation
for Animal Health shall be followed in all the testing procedures.

(7)

The continuous health monitoring and disease surveillance shall be in two stages, namely: -

<!-- page 11 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

11

(i) a robust in-house health monitoring and disease surveillance programme including a verifiable in-house
biosecurity audit conducted by the operator himself; and
(ii) a chain of custody sampling and testing by the empanelled agency.
5. Verifiable in-house biosecurity audit.- (1) The operator of coastal aquaculture units shall implement a verifiable
in-house biosecurity audit to examine, how well those biosecurity measures are executed in such coastal
aquaculture units.
(2)

The operator of coastal aquaculture units shall employ various levels, zones, compartments and strategies
for biosecurity at the coastal aquaculture unit depending on the size and design of the facilities and the
diseases of concern.

(3)

The operator of the coastal aquaculture units shall undertake a quarterly in-house evaluation of the
biosecurity measures being implemented in the coastal aquaculture unit by an expert and take such
necessary corrective action based on the audit report, required to ensure the biosecurity of the coastal
aquaculture unit.

(4)

The quarterly audit report shall be made available for verification by the authorised personnel during
inspection and chain of custody sampling of the coastal aquaculture unit.

(5)

A record of the biosecurity audit and the vetting of the same by the authorised personnel shall be
maintained as proof for specific pathogen free certification.

6. In-house health monitoring and disease surveillance.- (1) The respective facilities shall implement an in-house
health monitoring and disease surveillance programme to monitor the health status and quality of their stocks with
appropriate frequency for sampling and testing and the results of the in-house monitoring shall be maintained
appropriately at the respective coastal aquaculture unit.
(2) The in-house health monitoring and disease surveillance involves three levels of examination, namely:(a) examination of stock for general health condition, sex determination, staging of ovarian development,
moult staging, removal of sick or moribund individuals;
(b) examination of larval stages by microscope, checking bacterial flora of normal or moribund animals; and
(c) disease screening of brood stock and Parent Post Larvae by Polymerase Chain Reaction, histopathology
and or any other relevant advanced technique.
(3) The screening shall be conducted by qualified and certified technologists using latest Polymerase Chain Reaction
(PCR) or Real-time Reverse Transcriptase Polymerase Chain Reaction (RT-PCR) technique in accordance with the
procedures laid down in the latest World Organisation for Animal Health - Manual of Diagnostic Tests for Aquatic
Animals.
(4) The frequency of sampling and sample size for each candidate species shall be as declared by the Authority.
(5) The general guide on the frequency of sampling with a sample size of twenty samples each during every sampling
for the maintenance of in house disease surveillance protocol shall be as given in the table below:

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

Table-1

Screening
Number

Screening
frequency
(Days of
Operation)

Probable
range of
Weight. (g)

Parameters to be tested

Confirmatory
screening

(1)

(2)

(3)

(4)

(5)

1st

30

2 to 3

2nd

60

13 to 15

3rd

90

22 to 28

4th

120

33 to 37

All pathogens listed by World
Organisation for Animal Health
and non listed pathogens of
concern specified by the Central
Government for the candidate
species concerned shall be
screened.

Confirmatory
screening shall be
through
Histopathology and
sequencing of
Polymerase Chain
Reaction products
following detection.

5th

150

42 to 48

6th

180

50 to 53

(6)

In the event of occurrence of any disease or pathogen, the operator of the coastal aquaculture unit shall
immediately isolate and contain the operation of such compartments in such a way as not to contaminate the
other areas of the coastal aquaculture unit and report the same to the Authority immediately.

7. Chain of custody sampling and testing:
A. Empaneled agencies for chain of custody sampling and testing.- (1) The Authority shall for the purpose of
chain of custody sampling and testing for specific diseases or pathogens of concern empanel and authorise any
Government or semi- Government Organisations including Indian Council of Agricultural Research - Central
Institute of Brackishwater Aquaculture, National Bureau of Fish Genetic Resources, Rajiv Gandhi Centre for
Aquaculture, Fisheries Universities, and World Organisation for Animal Health referral laboratories and private
agencies, if –
(i) they are accredited by National Accreditation Board for Testing and Calibration Laboratories;
(ii) they are qualified at the national or international ring test for multiple pathogens screening;
(iii) fulfill the terms and conditions and other criteria specified by the Authority for such empanelment.
(2)

The Authority shall authorise the empaneled and authorised agencies following a roaster system to collect
samples for testing at specified intervals from the concerned units provided such collection of sample and
testing by an empanelled agency for two consecutive times from any coastal aquaculture unit shall be
avoided to ensure the transparency in the sampling and testing.

(3)

The empanelled and authorised agency for chain of custody sampling and testing shall report their test results
as soon as available to the Authority, maintaining the confidentiality of the same.

(4)

The samples shall be drawn, stored and tested by the authorised personnel or laboratory of empanelled and
authorised agency and the operator shall not in any way draw the sample and submit for third-party testing
under this programme.

(5)

The empanelled agencies shall also be authorised to verify the quarterly in-house biosecurity audit, the inhouse disease screening and their reports.

(6)

The Authority shall fix a fee for chain of custody sample collection and testing and pay the same to the
empanelled agencies.

B. Disease surveillance process.- (1) The general guide on the frequency of sampling, sample size and maintenance
of in chain of custody sampling and testing protocol shall be as given in the table below:

<!-- page 13 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

13

Table-2
Sample
Sets

Screening
Number

Screening frequency
(Days of Operation)

(1)

(2)

(3)

1st
2nd
3rd
4th
5th

30
90
180
360
540

60
60
60
60
60

6th

720

60

7

th

8th

specific pathogen free accreditation
900
20
20
1080

Probable
range of
Weight. (g)

Parameters to be
tested

Confirmatory
screening

(4)

(5)

2 to 3
22 to 28
50 to 53

All pathogens listed
by World
Organisation for
Animal Health and
non listed
pathogens of
concern specified
by the Central
Government for
the candidate
species concerned
shall be screened.

(6)
Confirmatory
screening shall be
through
Histopathology and
sequencing of
Polymerase Chain
Reaction products
following detection.

(2) The new coastal aquaculture units or facilities shall be scheduled for sampling during the 1st , 3rd , 6th , 12th,
18th, and 24th months and the sample size of initial 3 samplings of the 1st, 3rd and 6th months shall be with
60 sample sets each during each sampling.
(3) Surveillance and testing shall be continued at the 12th, 18th, and 24th months with 60 sample sets during each
sampling to acquire specific pathogen free certification or as specified in Manual of Diagnostic Tests for
Aquatic Animals laid down by the World Organisation for Animal Health or as specified by the Authority.
(4) The sample size, frequency of sampling, Standard Operating Procedure for collection of samples, type,
methodology or procedure and assay of testing shall be as specified in Manual of Diagnostic Tests for Aquatic
Animals laid down by the World Organisation for Animal Health, to be specified by the Authority for each
candidate species and such sampling regime shall include all life stages available at the coastal aquaculture
unit.
(5) Upon successful specific pathogen free accreditation of the coastal aquaculture unit and the stock following
the chain of custody surveillance and testing for a continuous period of two years, it shall be scheduled once
in every six months with 20 sample sets each during each sampling or as specified in the Manual of
Diagnostic Tests for Aquatic Animals laid down by the World Organisation for Animal Health or as specified
by the Authority.
(6) In the event of occurrence of a disease, or on affirmative positive sample set reported by the empanelled
agency or by the operator, the referral laboratory shall be notified at the shortest time possible by the operator
or empanelled agency or the Authority to confirm the same and the operation of the unit shall be suspended by
the Authority pending confirmation by the referral laboratory.
(7) On confirmation of occurrence of any disease or of a confirmative positive sample set by the referral
laboratory, the Authority shall engage with the Technical Advisory Committee and shall subject the infected
coastal aquaculture unit for inspection by a sub-committee of experts to ensure the biosecurity arrangements
and shall cause the coastal aquaculture unit to destroy the entire infected stock and incinerate the same in their
presence to contain the spread of the infection.
(8) In the event of occurrence of disease or of a confirmative positive sample set by the referral laboratory in a
particular compartment, the Authority shall decide on the vigorous chain of custody sampling and testing to
ensure that the other compartments in the coastal aquaculture unit are free from the said infection, provided
there are sufficient biosecurity measures in place to prevent such contamination and any additional fee or
charges as decided by the Authority for the same shall be collected from the operator of the coastal
aquaculture unit.
8. Manner of certification.- (1) The coastal aquaculture units or stocks shall be subjected to the disease surveillance
for the purpose of specific pathogen free certification as illustrated in the Annexure to this Guidelines.
(2) The operator of any coastal aquaculture unit engaged in the production of specific pathogen free stocks of
finfish or shellfish or any aquatic organisms shall apply for the specific pathogen free certification of the
coastal aquaculture unit and stocks contained in it.

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(ii)]

(3) The fee or charge for health monitoring, disease surveillance and specific pathogen free certification shall be
fixed by the Authority and shall be paid in advance by the operator of the coastal aquaculture unit concerned
to the Authority.
(4) Candidate species used for stocking in this coastal aquaculture unit must originate from a certified specific
pathogen free coastal aquaculture unit.
(5) In the case of new coastal aquaculture unit or, as the case may be, a unit which resumes its operation after
stoppage due to infection, the coastal aquaculture unit shall be allowed to sell or ship or export the candidate
species as high health stock with health documents on successful completion of three negative sample sets
during the 1st, 3rd and 6th months with 60 sample sets each but such stocks shall not be certified as specific
pathogen free stocks.
(6) On successful completion of the 12th, 18th and 24th months with 60 sample sets each, tested negative within a
continuous period of two years, the stock and the coastal aquaculture unit shall be accredited with specific
pathogen free status.
(7) The accreditation of specific pathogen free status to the coastal aquaculture unit and authorisation to sell the
stocks as high health or specific pathogen free shall be issued by the Central Government.
(8) In the event of occurrence of a disease or confirmatory positive sample set, the specific pathogen free status
of the coastal aquaculture unit and stocks shall automatically stands withdrawn.
(9) The coastal aquaculture unit with a confirmatory positive sample set shall shutdown the operation and follow
the disinfection and dry out process of the compartment or the entire coastal aquaculture unit, as the case may
be, for a period of one month and shall start the operation and the process of health monitoring and disease
surveillance for specific pathogen free certification afresh.
9. Monitoring and regulation :
(A). Coastal Aquaculture Authority.- The Authority shall be the competent authority for the following matters,
namely: (i)

empanelment of agencies for the chain of custody sampling and testing;

(ii)

terms and conditions of empanelment;

(iii) creation of roaster of empaneled agencies for chain of custody sampling and testing;
(iv) fixation of any fee or charges under this programme;
(v)

the sample size, frequency of sampling, Standard Operating Procedures for collection of samples;

(vi) scrutiny of test reports and recommendation;
(vii) coordination and follow up measures in case of a disease occurrence or a positive sample set;
(viii) suspension of the activity of the coastal aquaculture unit in the event of a disease occurrence or confirmatory
positive sample set; and
(ix) any other administrative and operational matters.
(B). Referral laboratories.(1)

The Central Government shall notify the list of referral laboratories from time to time.

(2)

In order to qualify for participating in the specific pathogen free certification programme, the laboratory shall
be National Accreditation Board for Testing and Calibration Laboratories accredited and shall qualify in the
national or international ring test for multiple pathogen screening of fish and aquatic organisms, unless it is
exempted from such conditions by the Central Government.

(3)

The cost of the travel by the authorised personnel of the referral laboratory for the sample collection and
testing shall be incurred by the respective institutions or organisation.

(C). Technical Advisory Committee.- (1) The Technical Advisory Committee constituted by the Central
Government under rule 19 of the Coastal Aquaculture Authority Rules, 2024 shall oversee the implementation
of the health monitoring, disease surveillance and specific pathogen free certification programme.
(2) The Technical Advisory Committee shall assist the Authority in deciding on the matters relating to fixation of
the sample size, frequency of sampling, Standard Operating Procedures for collection of samples, fixation of
fee or charges, constitution of sub-committees for inspection and culling of the infected stocks, suspension of
activity of a coastal aquaculture unit in part or full in the event of disease detection, grievance redressal and
dispute under this programme.

<!-- page 15 -->

[भाग II—खण्ड 3(ii)]

भारत का रािपत्र : असाधारण

15

(3) Appeal, if any, on the decision of the Authority shall be made to the Central Government and the decision of
the Central Government shall be final.
[F. No. j-1903336/2/2024-DOF (E-23648)]
NEETU KUMARI PRASAD, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ KUMAR
VERMA

Digitally signed by MANOJ
KUMAR VERMA
Date: 2024.03.20 18:04:01
+05'30'
