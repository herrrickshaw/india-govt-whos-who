---
doc_id: "fa83acd20edc1dfa"
source_url: "https://forest.goa.gov.in/sites/default/files/2024-08/Installation%20of%20antivirus.pdf"
ministry: "Forest Department, Goa"
title: "Tender regarding Installation of antivirus for computers and laptops of the office of Dy. Conservator of Forest, South Goa Division"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "f5c1073d7895eb7e"
---

<!-- page 1 -->

णा >
fi /
IN
X &
ree
22%
Sa
We
Government of Goa
Office of the Dy. Conservator of Forests,
South Goa Division,
Aquem, Margao-Goa, 403 601 7
_ Phone/Fax: - 0832-2750246/2751462_E mail: dc/Sou - 0832-2750246/2751462_E mail: dofsouth-forest.goa@nic.in
No.7/8/Accts/SGF/Ant-Vir/2024-25/602. Dated: 24/08/2024.
Quotation
To,

Sealed rate quotation is invited towards installation of antivirus for computers and
laptops of the office of Dy. Conservator of Forest, South Goa Division. ‘The quotation should be
super scribed as “Installation of antivirus for computers and laptops of the office of Dy.
Conservator of Forest, South Goa Division.” and should reach the undersigned on or before
sevsrseseesvessesee &t 3,00 p.m. and will be opened on the same day in the presence of tenders if any.
[Sr.No | Description of work/item | Amount
| | ‘Quick heal Internet Security 3-year

Subscription
=
CGST @9%
SGST @9% |
Others
—_ Grand Total| )
TERMS & CONDITIONS.

1. The rate should be quoted on your own letter head and the same should be sent to this
office on or before ..........++.+-failing which the same will be rejected.

2, All the rates should be quoted exclusive of sales tax, any other taxes, duties charges ete. if
any such charges are chargeable on the basic price/rated then the same should be quoted
separately.

3. The rates quoted should remain valid for a period of 45 days from the date of opening of
quotation.

4. The work/supply should be compieted within a period of 30 days from the date of receipt of
firm supply/work order from this office.

5. The full rights either to accept or reject all or any quotation are hereby reserved by the
undersigned without any reason thereof,

Sige
9-2
Dy. Conservator Ss,
South Goa Division
Margao-Goa.
ce च
OS... 0 0२022”
