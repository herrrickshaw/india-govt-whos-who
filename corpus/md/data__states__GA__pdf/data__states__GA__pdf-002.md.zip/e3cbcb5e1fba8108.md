---
doc_id: "e3cbcb5e1fba8108"
source_url: "https://www.goaelectricity.gov.in/wp-content/uploads/2026/01/CIRCULAR_dt06062017.pdf"
ministry: "Electricity (Power) Department, Goa"
title: "Updating Planned Power Outages"
date: ""
pages: 2
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "c4ef3f3b760bda33"
---

<!-- page 1 -->

GOVERNMENT OF GOA
ELECTRICITY DEPARTMENT
OFFICE OF THE CHIEF ELECTRICAL ENGINEER .
“Head Office, 3 Flor, एकुण Bhavan, Tiswadi, GOA 403001 Tel.2234155.2224680/EBAPX.2426421 2420353 2426020] Fax2426086,
2222354\||: Email::cee-clec goa@nic.in: website:: http://www.goaelectricity.gov.in/http://59.90.104.90
"नपम स्स्स सम ण २ २ 0 0क ०.
No.8/2(GEN)/CEE/Tech/PLG/2017-18/ 2 ¢3
Dated:- G/06/2017
Cc C
IRCULAR
Sub: Publishing of Planned Power Outages shall be the responsibility of the Division.
Officer.

In order to streamline the process of publishing various schedules for planned power
outages and to bring all such power outages under a scanner for monitoring the activities, it is
decided that the SubDivisional Officers should compulsorily avail the utility provided in the
SAP for arrangement of planned power outages and escalate it to their respective Divisional Of-
ficers for authorization and who shall inturn shall arrange the publishing of such notices in a
consolidated manner, which is automatically created by the system in pdf format, in the desig-
nated local dailies as per the prevailing procedure and a soft copy (in the prescribed proforma
intimated) emailed to the Head Office. The creation of such notices utilizing the SAP is auto-
mated to link to the Department Website which will be displayed in the “power outages” tab for
the real time information of the consumers.

It is also requested to furnish on weekly basis, all the major unplanned power outages
for the week ended in the beginning of the next week and in the prescribed proforma specified
in order to enable to upload these records on to the website for the information of the consumers
from time to time as per the requirements of the Business Reforms Action Plan 2017 (BRAP
2017) for States.

This instructions are with immediate effect.

(NN bao
Chief Electrical Engiteer
To,
1. Additional Chief Electrical Engineer I/II, Vidyut Bhavan, Margao/ 5'" Floor, CEE Of-
fice, Panaji

<!-- page 2 -->

yw
GOVERNMENT OF GOA
ELECTRICITY DEPARTMENT
OFFICE OF THE CHIEF ELECTRICAL ENGINEER
Head Office, 3 Floor, Vidyut Bhavan, Tiswadi, GOA 403001 Tel:2234155,2224680/EBAPX:242642 2422353,2426022I| Fax:2426986,
2222354: Emailces-lec goa@nicin: website hutpl/wwe.goaclectricty.gov.inMhtep59.90.10490 Jectricity.gov.in/http://59.90.104.90

2. Superintending Engineer, Circle I/1/Commercial/Planning, Margao/Panaji/ CEE office ,
Panaji

3. Executive Engineer(Commercial) --- he is requested to arranged to compile the reports
of the power outages received from the Division offices from time to time and furnish
the soft copy for upload on to the webpage.

4, Executive Engineer, Div 1, Panaji/IIEHV), Ponda/IV, Margao/V, Bicholim/VE, Ma-
pusa/VII, Curchorem/IX(EHV), Tivim/X(EHV), Ponda/XI, Vasco/XH(EHV),
Xeldem/XIII(EHV), Kadamba/XIV(EHV), Verna/XVI, Margao/ XVII, Mapusa

5. Master file

6. Gaurd file
