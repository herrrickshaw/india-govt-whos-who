---
doc_id: "b0c05afdca9db906"
source_url: "https://www.goa.gov.in/wp-content/uploads/2022/09/Guidelines-International.pdf"
ministry: "COVID-19 Information & Updates, Goa"
title: "Download"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "34b712ba1ab2b6f2"
---

<!-- page 1 -->

Dated the 2nd September 2022
Government of India
Ministry of Health and Family Welfare
Guidelines for International Arrivals
(in supersession of guidelines issued on the subject on 10th February 2022)
Introduction
The global and Indian growth trajectory of COVID-19 pandemic continues with regional variations. The
need to monitor the continuously changing nature of virus and evolution of SARS-CoV-2 variants of
concern (VOCs) thus, must still remain in focus. The extant guidelines for international arrivals in India
continue being formulated taking a risk-based approach. While monitoring the nature and spread of
infection in the country and across the globe, cognizance is also given to the fact that economic
activities need to be taken up in an unhindered manner.
Scope
This document provides protocols to be complied by international travellers as well as those to be
followed by airlines and all points of entry (airports, seaports and land border).
This Standard Operating Procedure shall be valid w.e.f. 3rd September 2022 (00.01 Hrs IST) till further
orders. Based on the risk assessment, this document shall be reviewed from time to time.
A.1.

Planning for Travel

i.

All travellers should
a.
Submit complete and factual information in self-declaration form on the online Air
Suvidha
portal
(https://www.newdelhiairport.in/airsuvidha/apho-registration)
before the scheduled travel, including last 14 days travel details.
b.
Submit details of negative COVID-19 RT-PCR report* (The test should have been
conducted within 72 hrs prior to undertaking the journey)
or
Submit details of full primary vaccination schedule of COVID-19 vaccination**.
c.

ii.

Each passenger shall also submit a declaration with respect to authenticity of the
report and will be liable for criminal prosecution, if found otherwise.
They should also give an undertaking on the portal or otherwise to Ministry of Civil Aviation,
Government of India, through concerned airlines before they are allowed to undertake the
journey that they would abide by the decision of the appropriate government authority any
post arrival requirement to undergo home/institutional quarantine/ self-health monitoring,
as warranted.

A.2.

Before Boarding

iii.

Do’s and Don'ts shall be provided along with ticket to the travellers by the airlines/agencies
concerned.
Airlines to allow boarding by only those passengers who have filled in all the information in
the Self Declaration Form on the Air Suvidha portal and submitted details of negative RT-PCR
test report or completed Covid -19 vaccination **.
At the time of boarding the flight, only asymptomatic travellers will be allowed to board after
thermal screening.

iv.

v.

Page 1 of 3

<!-- page 2 -->

vi.

All passengers shall be advised to download Aarogya Setu app on their mobile devices.

A.3.

During Travel

vii.

In-flight announcement about COVID-19 including precautionary measures to be followed
shall be made at airports and in flights and during transit.
During in-flight crew shall ensure that COVID appropriate behaviour is followed at all times.
If any passenger reports symptoms of COVID-19 during flight, he/she shall be isolated as per
protocol.
Proper in-flight announcements should be made by the airlines regarding the testing
requirements and people who need to undergo such testing to avoid any congestion at the
arrival airports.

viii.
ix.
x.

A.4.

On arrival

xi.
xii.

De-boarding should be done ensuring physical distancing.
Thermal screening would be carried out in respect of all the passengers by the health officials
present at the airport. The self-declaration form filled online shall be shown to the airport
health staff.
The passengers found to be symptomatic during screening shall be immediately isolated and
taken to medical facility as per health protocol. If tested positive, their contacts shall be
identified and managed as per laid down protocol#.
The following protocol post arrival shall also be followed
a.
A sub-section (2% of the total passengers in the flight) shall undergo random postarrival testing at the airport on arrival.
b.
Such travellers in each flight shall be identified by the concerned airlines (preferably
from different countries). They will submit the samples and shall be allowed to leave
the airport.
c.
If such travellers are tested positive, their samples should be further sent for genomic
testing at INSACOG laboratory network.
d.
They shall be treated/isolated as per laid down standard protocol.
All travellers will self-monitor their health for next 14 days of arrival.
If travellers under self-health monitoring, develop signs and symptoms suggestive of COVID19, they will immediately self-isolate and report to their nearest health facility or call National
helpline number (1075)/ State Helpline Number.

xiii.

xiv.

xv.
xvi.

International travellers arriving at seaports/land ports
xvii.

xviii.

International travellers arriving through seaports/land ports will also have to undergo the
same protocol as above, except that facility for online registration is not available for such
passengers currently.
Such travellers shall submit the self-declaration form to the concerned authorities of
Government of India at seaports/land ports on arrival.

* Children under 5 years of age are exempted from both pre- and post-arrival testing. However, if
found symptomatic for COVID-19 on arrival or during the period of self-monitoring period, they shall
undergo testing and treated as per laid down protocol.
** There are Countries which have agreement with India on mutual recognition of vaccination
certificates of Nationally recognised or WHO recognised vaccines. Similarly, there are Countries which
Page 2 of 3

<!-- page 3 -->

presently do not have such an agreement with India, but they exempt Indian citizens fully vaccinated
with Nationally recognised or WHO recognised vaccines. On the basis of reciprocity, the travellers
from only such Countries which provide quarantine-free entry to Indians will be allowed for relaxation
under Certificate of completing full primary vaccination schedule of COVID-19 vaccination. The listing
of such Countries is available on website of Ministry of Health & Family Welfare (mohfw.gov.in) and
the link of the same will be available at website of Ministry of External Affairs and Air Suvidha Portal.
This is also a dynamic list and will be updated from time to time. The travellers from such countries
only are considered for allowing entry based on vaccination certificate & shall submit details of their
completed primary vaccination against COVID-19 on the Air Suvidha portal.
# Contacts of the suspect case are the co-passengers seated in the same row, 3 rows in front and 3
rows behind along with identified Cabin Crew.

Page 3 of 3
