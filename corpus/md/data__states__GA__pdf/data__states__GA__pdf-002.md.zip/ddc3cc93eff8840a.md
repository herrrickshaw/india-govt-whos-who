---
doc_id: "ddc3cc93eff8840a"
source_url: "https://forest.goa.gov.in/sites/default/files/2024-08/Tender%20-%20Supply%20of%20Desktop%20Computer.pdf"
ministry: "Forest Department, Goa"
title: "Tender regarding Supply of Desktop Computer in the office of Dy. Conservator of Forest, South Goa Division"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "2f50ae15b31a7950"
---

<!-- page 1 -->

&
a,
“ep
Weg
Se
= Government of Goa
Office of the Dy. Conservator of Forests,
South Goa Division,
Bh | Aquem, Margao-Goa, 403 601
TNocTRTRe/SGF/ COMPIGampe are pa ious soutien नं one/Fax: - 0832-2750246/2751462. E mail: defsouth-forest.goatanic.in
(0.7/8/Accts/SGF/ COMP/Campa/2024-357 Gil Dated: &-V08/2024,
QUOTATION.
To,
Sealed rate quotation is invited towards Supply of Desktop Computers in the office of
Dy. Conservator of Forest, South Goa Division. The quotation should be super scribed as
“Supply of Desktop Computers in the office of Dy. Conservator of Forest, South Goa Division.”
and should reach the undersigned on or before O2|0q| 2024 at 3.00 p.m. and will be opened on
the same day in the Presence of tenders if any. |
St.No Particulars of Items Quantity Total
Specification Amount
01 HP COMMERCIAL DEKTOP PRO 280G9 MT 8GB RAM रित
512GB M2 PCI NVME TOWER CABINET 21.5” TFT 3
YEAR WARRENTY WIN 11 PRO KB AND MOUSE
02 HP PROONR 240G10 AIO CORE 17-13" GEN 16GB
DDR4 1TB HDD +512 GB SSD 23.8 FHD WIN 11 PRO USB
KB AND MOUSE WIFI + BT 3 YEARS WARRENTY
1) The sealed rate should be quoted on your own letter head and the same should be sent to
this office on or before Al pet filing which the same will be rejected.
2) All the rates should be quoted exclusive of sales tax, any other taxes, duties charges etc. if
any such charges are chargeable on the basic price/rated then the same should be quoted
separately. र भं
3) The rates quoted should remain valid for a period of 45 days from the date of opening of
juotation. र डी
4) ths work/supply should be completed within a period of 30 days from the date of receipt
of firm supply/work order from this office. ;
5) The full rights either to accept or reject all or any quotation are hereby reserved by the
undersigned without any reason thereof. 2
oN
rf an
Dy. Conservator of Norests, |
South Goa Divisipn
Margao-Goa.
