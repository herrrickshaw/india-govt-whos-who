---
doc_id: "1cacb2cb89b03f4b"
source_url: "https://goaspcb.gov.in/Media/Default/River-action-plan/ORDER%20FROM%20DEPARTMENT%20OF%20SCIENCE%20AND%20TECHNOLOGY.pdf"
ministry: "Goa State Pollution Control Board, Goa"
title: "Nodal Officer – Science & Technology"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "ae7c0465c9ee7e15"
---

<!-- page 1 -->

ate
Taek
७*३4०७१
ऐ.८०9/
व्या
Government of Goa
Department of Science and Technology
1* Floor, Pandit Deendayal Upadhay Bhayan,
Behind Pundalik Devasthan, Near Sanjay School,
Porvorim, Bardez Goa
Phone Nos.: 0832-2416581 / 2416583 / 2416584
e-mail: dir-ste.goa@nic.in

ee
No. 331-10-2019/S&T/DIR/=FO Dated: +6 /04/2019

ORDER

Shri Sanjeev joglekar, Officer on Special Duty (Science & Technology) shall be the
Nodal Officer for River Rejuvenation Action Plan, for Department of Science and Technology,
Government of Goa
र
ey
(Levinson J* Martins)
Director (S&T) & Ex-Officio
Jt. Secretary to Government.
To,
Shri Sanjeev Joglekar,
OSD (S&T),
Department of Science and Technology,
Porvorim Goa
Copy to
1. The Director, Department of Environment, Porvorim - Goa.
_2+The Member Secretary, Goa State Pollution Control Board, SAligao - Goa.

3. Guard File
4. Order File
5. Office Copy.
