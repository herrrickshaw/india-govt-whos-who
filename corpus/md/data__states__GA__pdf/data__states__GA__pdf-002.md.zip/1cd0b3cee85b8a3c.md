---
doc_id: "1cd0b3cee85b8a3c"
source_url: "https://dmg.goa.gov.in/PDFs/Notifications/DMF/Minutes-Meeting-Governing-Council-South-Goa-DMFT-held-23-12-2024.pdf"
ministry: "Directorate of Mines and Geology, Goa"
title: "Minutes of the Meeting of the Governing Council of the South Goa DMFT held on 23-12-2024"
date: ""
pages: 14
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "72b63b71c4e15455"
---

<!-- page 1 -->

जि SOUTH GOA DISTRICT MINERAL FOUNDATION (TRUST)

GB): O/o - DIRECTORATE OF MINES AND GEOLOGY

aN ८, bs GROUND FLOOR, INSTITUTE MENEZES BRAGANZA BUILDING
GY
“ee PANAJI-GOA

. Website:www.dmg.goa.gov.in  dmfsouthgoa@gmail.com Phone Nos. (0832) 2425291/2426431

No. DMF Admin/09/2024/Mines/South/99 9 6 Date:06 /02/2025

To,

1. Shri Sadanand Shet Tanavde, Hon’ble Member of Parliament (Rajya Sabha) H.
N. 1502/69 Saikunj, Housing Board Colony, Madel Thivim-Bardez-Goa.

2. Captain Viriato Fernandes, Hon'ble Member of Parliament (Lok Sabha) South
Goa.

3. Shri. Subhash Shirodkar, Hon’ble Minister for Water Resource Development,
Co-Operation & Provedoria, MLA-Shiroda Constituency.

4. Shri. Subhash Fal Dessai, Hon’ble Minister for Social Welfare, River Navigation,
Archaeology & Archives, MLA - Sanguem, Constituency.

5. Shri. Ganesh Gaonkar, MLA - Sanvordem, Constituency.

@. ‘Shri. Nilesh Cabral, MLA - Curchorem, Constituency. 5

7. Shri. Altone D'Costa, MLA - Quepem Constituency.

8. The Dy. Director, Directorate of Health Services, Campal, Panaji Goa.

9. The Dy. Director, South Education Zone, Directorate of Education, Margao,
Goa.

10. The Dy. Director, (South), Directorate of Panchayats, Margao — Goa.

11. The Under Secretary, Finance Department (Budget), Secretariat, Porvorim — /
Goa.

12. The Ex. Engineer, WD-XX, (PHE), PWD, Margao, Goa.

13. The Ex. Engineer, WD-XII, Water Resources Dept. Gogal, Margao Goa. ,
14. The Ex. Engineer, Department of Electricity, Margao- Goa.

15. The Dy. Director (South), Directorate of Social Welfare, New Collectorate
Building, Ground Floor, Margao Goa.

16. The Dy. Director, Directorate of Women & Child Development, South, Margao -
- Goa. :

17. The Dy. Director, Directorate of Agriculture, South, Margao -Goa. क

18. Shri. Glenn Kalavampara, Goa Mineral Ore Exporters Association, 1st Floor,
Velho Building, Opposite Municipal Garden, Panaji, Goa- 403001.

19. 19.The Member Secretary, Goa State Biodiversity Board (GSBB), C/O
Department of Science, Technology and Environment, Opp. Saligao Seminary,
Saligao, Bardez-Goa.

<!-- page 2 -->

os
MINUTES OF THE 9'* GOVERNING COUNCIL MEETING OF SOUTH GOA DISTRICT MINERAL FOUNDATION,
HELD ON 23/12/2024 UNDER THE CHAIRPERSONSHIP OF THE COLLECTOR, SOUTH GOA AT ROOM NO.
438, MATHANY SALDANHA ADMINISTRATIVE COMPLEX, MARGAO GOA AT 3.00 PM
The Governing Council (GC) meeting of the South Goa District Mineral Foundation Trust was convened by
the Collector South/Chairperson (DMF-South). The meeting was attended by the following members:
Srno[Members | Designation eS
1 |Ms.EgnaCleetus!AS __| Collector/Chairperson South Goa District Mineral
_______ Foundation (Trust), South Goa
Capt. Viriato Fernandes | Member of Parliament, Lok Sabha, South Goa 9975259670
| Dr. Ganesh Gaonkar Chairman GTDC, MLA Sanvordem Constituency,
| Shri. Subhash Phal Desai Minister of Social Welfare of Goa/MLA Sanguem
| | Constituency, 9527968691 ______ SS
isa) MLA Curchorem Constituency, 9822103292
| Shri. Abhir Hede DD II/ Member Sectretary, Directorate of Mines and
Pe | Geology/District Mineral Foundation (Trust), South
Goa,9764214183
| Shri.Prasiddh P. Naik Dy. Director of Panchayat, South Goa, 9923274585 i
| [8 | Dr. Rupa Naik Dy.Director, DHS , 9011025066
ls _ | Shri. Sujeetkumar Dongre Scientist CEE, 9422063917
Shri. Lester D’ Souza Ex. Engineer, WD, PWD, 9271144520
Shri. Glenn Kalvampara Secretary, GMOEA,9822103191
i ‘Smt. Tereza Maria D’ Souza __| Jt. Secretary, GMA, 9822121451
| Shri, Rajesh B. Desai Dy. Directorate of Agriculture, 7972252477
18 Asst. Director, GIPARD, 982216734
EE, WOXI WRD 9325637345
Shri. Eueledes F. Desouza EE, WDXIX PWD, 9271144519
Dr Sunita Perni MO, NHM, Directorate of Health Services, 9011025037
Shri Sadanand K Naik Asst. Engineer, WRD, 9764973621
23__| Shri Shantaram Gaonkar JE. 7972969582 =
Smt Shilpa Naik CDPO, WCD Quepem, 9823262792 _
‘Smt .Ekrupa Mahale MS. WCD Quepem, 9922701230
[28 ['Smt.Krutika Naik |
|? | Rodrigues
| 32__| Shri, Paresh L. Kunkolickar
9423058974
The Meeting started with the Collector presiding over the meeting. The Member Secretary guided the
discussion with the help of Project Management Unit on the following agenda.
AGENDA NO, 1
Review of Sanctloned Projects under DME (Trust) — South Goa;

<!-- page 3 -->

काड | —
| review of the progress of the works sanctioned earlier of the following departments was
ander:
11. Directorate of Education:

a) A proposal towards the repairs/ upgradation and maintenance of 4 Government schools
was discussed. The members were informed that the payment of 3 RA bills amounting
Rs.2,33,18,723/- was done in the past and for a long time no fresh bills were received
despite repeated reminders to DoE and GSIDC. Hence the GC had suggested in past that the
balance money sanctioned for the said project be reverted to the available funds of the
Education Department. The GSIDC has submitted fresh bills for balance amount of
Rs.2,19,88,942/ on 14" March 2024 through DoE which is within the amount sanctioned
earlier. The MS, SGDMF informed that the bills are in process of payment and that the
payment will be done within a month to GSIDC/Contractor.

Decision: - The Governing Council directed the SGDMF to settle the final bills within 1 month
of time and close the project.
| (Action: SGCDMF)
| |
|b) A proposal was received from Info Tech Corporation of Goa Limited (ITCGL) routed through
| the Education Department. In this proposal ITCGL had proposed for upgradation of ICT
| | Infrastructure for the implementation of Smart Classrooms along with Robotic Steam labs
at mining-affected schools in the state of Goa. The proposal was sanctioned in the GC dated
27/12/2023. The amount sanctioned was Rs. 1,77,09,000. Administrative approval was
| already issued to the Directorate of Education. But DoE in its letter dated 09/07/2024
| informed the SGDMF that they want to withdraw the proposal and submit an alternative
proposal with similar developmental works. DoE submitted the alternate proposal with
revised school list including Government High School (GHS), Maina & Xeldem (Quepem
Block), GHS at Ganje Usgao, Dhaushire, Usgaon Tisk (Ponda Block), GHS at Valkini,
Zambaulim, Colomb (Sanguem Block), GHS at Shigao, Collem, Dharbandora,
Dayanandnagar, Dharbandora, & Government Higher Secondary School, Sanguem. The
revised list was sanctioned in GC dated 30/08/2024. The Admin approval is issued to DoE.
The representative of DoE stated that the project is outsourced to ITGL and they have
floated the tender and the execution shall be done by the end of January, 2025. Shri.
Subhash Phaldesai , Honourable MLA Sanguem informed the GC that he has facilitated
Smart Board in few school and higher secondary of his constituency from other sources and
the same should not be duplicated. The GC was of opinion that smart board wherever exist
should not be duplicated and instead alternate and important asset within the same budget
can be considered, PMU to cross check the schools and higher secondary meant to benefit
and prepare latest report.
Decision: The GC directed that the project to be executed within a month and even stated
that any service charges levied by the ITCGL or Department/Corporation must be borne by
| proponent.
| Action: - (DoE/ PMU)
|
| ©) The proposal for financial provision for purchase of 5 School buses was sanctioned in the
| Governing Council dated 27/12/2023 for an amount of Rs.1.75 Cr, The SGDMF has issued
| the Admin approval to the DoE and the DoE has placed the requirement on GEM portal for
the purchase of buses. The representative of DoE had assured that the purchase order will
be issued within month of September 2024. Considering the Monthly Progress Report
| १.

<!-- page 4 -->

requirement, the DoE was asked to provide the beneficiaries details every month. Also, the
Fleet Management System through GPS provided on the bus should be active and
accessible. The member of DoE stated that the project will be executed by Kadamba
Transport Co-corporation limited (KTCL) and they have floated a tender, and procurement
will be done by 15 January 2025.
The GC members expressed their strong resentment at the delay in procurement of buses
and desired that the project be completed at the earliest. The Honourable Minister for
Social Welfare Shri. Subhash Phal Desai brought to the notice of GC members that students
of Government Higher Secondary, Sanguem coming from various areas are facing difficulty
in travel and desired that a bus be sanctioned for Higher Secondary, Sanguem.
Decision: The GC desired that the 5 buses should be purchased within next one Month and
One bus to be sanctioned for Government Higher Secondary Sanguem.
(Action: - KTCL, DoE)
2. Directorate of Women and Child Development and Child Development:
a.The project proposed by the DWCD for the purchase of water purifiers, preschool kits,
equipment, awareness etc. by the department was sanctioned on 27/11/2019. The MS
informed the members that the DWCD Dept. had earlier submitted estimate of Rs. 15,56,755/-
dated 22.02.2023 and the same was sanctioned and Administrative Approval was given. Later
DWCD submitted revised quotation of Rs. 27,80,403 and the same was sanctioned and were
asked to follow E Tendering process and procure the items within the previously sanctioned
amount of Rs. 47.20 Lakh. The member of DWCD informed the GC that in North Goa they had
procured the items from Goa State Coop Marketing and Supply Federation would want to
follow the same while procuring the item in South which was agreed by GC dated 30/08/2024.
Decision: - The GC directed the DWCD to submit the fresh quotation of the items from Goa
State Coop Marketing and Supply Federation and get the financial approval from office of MS,
SGDMF and procure the items and distribute it to AWCs within 30 days.
(Action: - DWCD/SGDMF)
b. Construction of AWCs in Quepem Taluka under District Mineral Fund South Goa with cost
of Rs. 93,74,328. The original proposal consisting of 5 anganwadi namely AWC Ghanemorod,
Karaymaddi, Taki, Tilamol and Subdolem were submitted to SGDMF to take up for construction
and renovation. The Chairperson had desired that the AWCs must be model Anganwadi and
should consist of all facilities. Since Subdolem falls out of the mining affected area, it was not
taken up under SGDMF funds. The GC had opined then that only 3 AWC will be considered
under SGDMF so as to ensure uniform distribution of similar works in other areas. Accordingly,
the 3 AWCs Karymaddi, Taki and Tilamol were given the Admin/Expenditure after ascertaining
with DWCD about any cost enhancement. The PWD informed in Nov, 2024 that the proposal
cost had escalated by Rs.3.56 lakhs, Since adequate opportunity was given to the DWCD, the
MC had suggested that the enhanced amount should be borne by the DWCD. and complete the
work, Further, the GC was informed that DWCD can avail of Central Govt. funds of Rs. 12 Lakh
for construction of new Anganwadi and whatever shortfall is there can be bridged by DMF
amount under convergence. The DWCD was requested to explore such possibilities for this and
other future proposals. The Managing Committee had directed the DWCD to bear the
additional cost of Rs. 3.56 Lakhs and get the work done within sanctioned amount. But DWCD
member informed GC that additional cost cannot be borne by their department due to
insufficient funds. ७.

<!-- page 5 -->

Decision: - The GC sanctioned the additional amount of Rs.3.56 lakhs and directed the MS,
SGDMF to issue necessary sanction. The GC directed the representative of the DWCD to come
with new and repair proposal of Anganwadi across mining affected area with focus on
developing this infrastructure across affected area.

(Action: PWD/DWCD)

3. Directorate of Social Welfare: The proposal for the purchase of 42 Nos. of scooters with side
wheels was sanctioned in the GC meeting dated 20.07.2021. After due verification process 19
beneficiaries were approved of which 2 beneficiaries have already received the scooter with
side wheels through MPLAD. Hence it was suggested that only 17 beneficiaries should be given
the scooters with side wheels. The Department for Empowerment of Persons with Disabilities
had informed SGDMF in past that they are not registered on GeM portal and once they get GEM
portal registration they would procure and distribute the motorized tricycle. The GC expressed
its concern on the time-consuming process of departments and was of opinion that the SGDMF
should develop Standard Operating Procedure to facilitate quick procurement of any such
components and should do it through the office of the Chairman, SGDMF.

Decision: - The members of the GC directed DEPW to complete the GeM portal registration and
procure the bikes within 2 months.
(Action: - DSW/ DEPW)

4. Goa State Biodiversity Board: Board: - The Go-Van Project of the Goa State Biodiversity Board was
approved by the GC dated 20.07.2021 for an amount of Rs.1.96 Cr. The members were informed
that the multiprocessing units will be located at Sanguem, Rivona, Sacorda, Dabal and Sulcorna.
The GSBB had submitted the status of work in past and had assured to complete three centres
by 31% July 2024, one by 15'* August 2024, and last by 15'* September 2024. The GSBB
representatives during GC dated 30/08/2024 had assured to make operational four centres by
November 2024. However, the GSBB had not been able to meet the timeline. The GC
disapproved the absence of GSBB representative for MC and GC and expected that GSBB be
informed about need of speedy completion of the project.

Decision: - The GC desired that the project should be operational by end of February, 2025.
(Action: -GSBB)
5. Directorate of Panchayat (DoP):

a) Material Recovery Facility for the Village Panchayat of Panchawadi with revised estimated cost
of Rs. 31,23,447/- was discussed. The Member secretary informed that the said proposal was
received and sanctioned earlier. The DoP member informed that the L1 is finalised, and the
communication is sent to SGDMF and once they get financial approval, they will issue the work
order.

Decision: -The GC directed SGDMF to issue the financial approval once the report of the tender
is received and DoP to issue the work order as soon as SGDMF issues approval.
(Action: -SGDMG/ DoP)

b) BDO, Dharbandora had approached SGDMF for providing a rickshaw for the collection of
Garbage in V.P. Mollem of Dharbandoda taluka costing Rs. 6,75,000/-. The original proposal for
vehicle chassis was sanctioned in GC dated 27/12/2023. The panchayat later came with a request
for funding of body building and had submitted 3 quotations for the same with the lowest bidder
bidding Rs.44,840/ (Metal Craft Engineering, Kundaim). The Governing Council dated
30/08/2024 approved the additional cost of mg 45000 with budget totalling Rs.

<!-- page 6 -->

7,20,000 and directed the SGDMF to issue the Financial Approval. The DoP was asked to ensure
that the vehicle is appropriately branded with SGDMF logos. The SGDMF stated that the
additional cost if any will be borne by respective panchayat or by DoP. Since there was
administrative issue with the invoice submitted by VP Mollem the bill payment is delayed.
Decision: - The GC desired that the VP Mollem should ensure proper invoice copy so that
payment can be immediately done by SGDMF.
(Action: SGDME/DoP)
¢) Proposal to provide Garbage Collection vehicle to Sanvordem panchayat under DMF fund for Rs.
9,27,257/ was made. The E-Rickshaw provided by DoP is not suitable for the topography of
Sanvordem. Vehicle requested is TATA Intra V30 HD BS VI PH-2 non-AC white. The panchayat
member informed that the proposed cost is exclusive of fabrication. The proposal was
sanctioned in GC dated 30/08/2024. The Admin/Financial approval is issued to the DoP/VP
Sanvordem. The invoice received by from the Department/Panchayat is under scrutiny in
Accounts section of SGDMF.
Decision: - The GC directed SGDMF to pay the dealer after scrutinizing the bill and the additional
cost if any has to be borne by the DoP. Action: - (DoP/SGDMF)

4) Aproposal for construction of Material Recovery Facility (MRF) Shed in Village Panchayat Kirlapal
Dabhal was received from BDO, Dharbandora. The Deputy Director Panchayat had mentioned
that the proposal cannot be taken up under regular funds of the panchayat. SGDMF has received
the plan and estimates amounting to Rs. 33,59,929 done by PWD. The proposal was sanctioned
in GC dated 30/08/2024. The Admin/Expenditure Sanction are already issued to the DoP. The
DoP member assured that project will by completed by Feb 2025.

Decision: - The GC agreed to the timeline assured by the DoP and directed them BDO/ Panchayat

to complete the work.
Action: - (००?)
6. Info Tech Corporation of Goa limited:

The proposal was received from Info Tech Corporation of Goa Limited (ITCGL) for providing free
IT education/upgradation of IT skills for citizens residing in mining affected areas/regions in the
state of Goa under Goa District Mineral Foundation Funds with estimated cost amounting to
Rs.1,06,30,000/-. After deliberations in previous GC a pilot project was sanctioned Rs. 50 Lakh
with a condition that the courses taught in this project should benefit the candidates to earn
livelihood and supplement the income. Also, the age group should be within 15 to 35 years and
the long duration course to be charged a refundable deposit of Rs. S00 ensuring satisfactory
attendance. It was also desired that the list of candidates selected for the benefit to be shared
with SGDMF in advance and final exam to be conducted and certificate to be awarded by ITCGL.
The scheme is applicable for the candidates from mining affected areas. The ITCGL was asked
to reformulate the proposal within the sanctioned amount with clear eligibility criteria,
awareness schedule across the mining panchayat and other aspects and submit it to the
SGDMF. ITG has reworked the proposal and submitted the same for the consideration of GC
which after discussion was approved. Accordingly, the ITCGL project will benefit a minimum of
770 students with an average fee of Rs. 6490 per student. Of the total fund 80% of the fund will
be paid to empanelled training institutes and 20% funds will be for ITG. Since the project is
taken by ITCGL on their own the GC was of the opinion that the service charges of 20% are
very high. GC was of the opinion that service charges should not be levied by the proponent.
Courses will be monitored, and certificates will be issued by ITCGL. SGDMF informed GC that
the administrative approval is already issued to ITCGL. The GC was of ye that if the project

<!-- page 7 -->

is not started within next 45 days, then the same should be withdrawn as people in affected
area are not able to benefit from sanction project. The GC also desired that only one single
Nodal Person be identified to deal with the projects in each department helping to maintain
continuity and avoid confusion.
Decision: The GC directed to expedite the codal formalities and complete the project within 45
days and instructed to give wide publicity about training in mining affected areas and to submit
the progress report to SGDMF.
Action: (ITCGL)
7. Public Works Department: -
a. Proposal was received from PWD for extension of the pipeline from Ambeudak to Dukarkond
in V. P. Sanvordem in Sanguem taluka costing Rs.41,44,846 and the project was sanctioned in
GC dated 27/12/2023. PWD had submitted details along with the detailed break up of work.
The PWD had also budgeted for departmental charges which after clarification were withdrawn
as the project was proposed by PWD themselves. SGDMF sanctioned the budget without
departmental charges. The Admin/Financial approval was issued to the PWD for Rs.
37,00,756(exclusive of Dept Charges). The member of PWD (water supply) informed GC that
the tender opening is in process and the L1 will be finalised shortly and communicated to the
SGDMF.
Decision: - The GC directed the PWD (Water Supply) to finalize the tender, issue the work order
with proper timeline and commence the work before 15" January 2025.
(Action: PWD/ SGDMF)
b. The PWD had submitted a proposal for construction of 300cu.m Over Head Reservoir
including providing and laying 150mm diameter Ductile Iron conveying main at Pedamol,

Shirvoi in V.P. Xeldem in Curchorem with an estimated cost of Rs. 2,22,31,085. The project was

sanctioned in GC dated 27/12/2023 for just OHR construction at a budget of Rs. 1 CR and the

remaining work to be undertaken by PWD under its budget head. The PWD was asked to

submit a detailed estimate of only this work which PWD submitted to MC and the cost had

escalated to Rs. 1.33 Cr without inclusion of any departmental charges. The amount was
enhanced to Rs.1.33Cr by Governing Council dated 30/08/2024 and the Admin/Financial
approval was already issued to the PWD. The member of PWD informed GC that the tender is

set to be opened on 13/12/2024 and soon they will issue the work order based on L1. |

Decision: - The GC directed PWD to complete the process and issue the work order and

commence the work by 15 January 2025.

(Action: PWD)
8. Department of Animal Husbandry and Veterinary Services, Goa:

a. The Goa State Cooperative Milk Producers Union Ltd had submitted a proposal for an
ambulance for Veterinary Dispensaries in the mining belt costing up to Rs. 12,00,000/- The
ambulance will stock medicines and other required instruments and will provide service in
field to treat the animals, The proposal was approved by the GC in a meeting dated
27/12/2023. Proponent submitted the quotation for vehicle along with additional
componentsi.,e. Vehicle Eeco Ambulance (Rs.701346), Surgical, Gynaecological & Obstetrics
Kit (Rs.389830), LN2 Container (Rs.51330), Mini Refrigerator (Rs. 10000), Vet Medicine
(Rs.20000) taking the total to Rs.11,72,506. The Codal procedure for all other components

<!-- page 8 -->

was carried out by AHVS and report is submitted to SGDMF recently. The Ambulance is
procured and will be made operational after fitting the accessories mentioned above.
Decision: - The GC stated that SGDMF can issue the financial approval for other components
those are mentioned in above in details.
(Action: Goa State Cooperative Milk Producers Union Ltd/ AVHS/SGDMF)

9. Department of Animal Husbandry & Veterinary Services had submitted the proposal for skill
development in animal husbandry practices for livelihood support to mining-affected people of
South Goa costing up to Rs. 6,30,000/-. The project was sanctioned in the GC dated
27/12/2023. The project intends to give exposure to livestock farmers from mining-affected
and train young Dairy farmers from mining-affected areas of South Goa by taking them outside
Goa to places where there is good dairy activity. Out of the selected 60 farmers, two batches of
30 farmers each will travel outside Goa for training. The administrative approval is already
issued but the Department has not yet submitted the detailed breakup of the training cost and
other components. It was telephonically communicated by the representative that the file is
moved to Director of AHVS for further process. The Governing Council took note of the delay in
executing the project and desired that in case if AHVS is not able to initiate action by चि
January 2025 then the associated agency of Milk Producer i.e. Goa Dairy can be considered to
implement the project.

Decision: - The Governing Council directed AHVS to complete all the procedure by 15" January
failing which the Goa Dairy can train the farmers in active collaboration with SGDMF.
(Action: AHVS)
10. Directorate of Health Services:
a. The proposal regarding the extension of Pharmacy and repairs of the well at PHC Pillem
with an estimated cost of Rs. 17,64,317/- was received. The proposal was sanctioned in
GC dated 27/12/2023. Later the DHS submitted enhanced estimate of Rs. 18,09,450/
which had exceeded the sanctioned amount by Rs. 45,133. The GC dated 30/08/2024
had approved the proposal with enhanced cost of Rs. 18,09,450/-. The member of the
DHS informed GC that the Health Officer and PWD will finalise the work and the tender
will be floated. The Honourable MLA, Sanvordem constituency desired the details of the
letter sent by DHS to PWD to follow up on matter. The DHS representative assured to
submit the reference.
Decision: - The GC directed the DHS to complete the codal formalities and get the work
done as per requirements.
(Action: DHS/PWD)

b. DHS had requested SGDMF to provide 2 advanced Cardiac life-saving Ambulances for
Mining-affected areas in the vicinity of Dharbandora, Mollem, Curchorem and Quepem
with estimated cost of Rs.98,82,000. The project was sanctioned in earlier GC and the
DSH had procured the ambulance. The SGDMF informed that the branding is done, and
the Ambulance is handed over to DHS on 11/10/2024 in formal inauguration ceremony
in Panaji. It was informed to DHS that the ambulance bought through DMF funds and
meant for mining affected area should be necessarily inaugurated in the mining belt and
ideally the inaugural function should not be clubbed with any other function for more
visibility to DMF works in mining belt. The GC also desired that a report of ambulances
stationed at different places with their registration number, cases attended by each
ambulance month wise be provided by DHS for compiling the Monthly Progress Report.

<!-- page 9 -->

Decision: DHS to ensure that the assets created through DMF funding are given due

publicity and acknowledged at the appropriate public platform. Also monthly calls

attended by each ambulance be provided.

(Action: DHS)
11, Goa State Pollution Control Board: -
GSPCB had proposed real time Ambient Air Quality Monitoring (AAQM) in identified mining
areas at 14 places Codli Tisk, Kirlapale, Sanvordem, Capxem, Curchorem, Sanguem, Tilamol,
Rivona, Ambaulim, Quepem, Caurem, Dharbandora, Savargal GP School, Usgaon Junction for
Rs.1.82Cr at 13lakh per station. The project was considered in GC dated 30/08/2024 after GC
was informed that CDAC & IIT, Kharagpur had developed, tested and had certified an indigenous
monitoring device named Air Pravah to monitor different parameters real time. Based on the
directions from GC, the GSPCB had submitted the undertaking that the said project does not
qualify to be taken up/ funded by the leaseholders/transporters under the Polluters Pay
Principle. SGDME informed the Governing Council that the approval is under process and will
be issued to GSPCB shortly. The GC deliberated the issue and as the AAQM would be essential
to conduct a baseline study of air quality in mining affected areas and further considering that
air quality monitoring is one of the sub sectors mentioned in the revised guidelines of the
PMKKKY 2024 at clause 3.1(b), It was decided to consider only 9 stations.
Decision: - The GC approved the setting up of the Ambient Air Quality Monitoring (AAQM) in
identified mining areas at 14 places Codli Tisk, Sanvordem, Capxem, Sanguem, Tilamol,
Ambaulim, Caurem, Dharbandora, Usgaon Junction for Rs.1.17Cr at 13lakh per station for 3
years.
Action (GSPCB/SGDMF)

12. Directorate of Technical Education through its Project Management Unit had proposed for
Coding and Robotic Education in Schools (CARES) Scheme costing Rs. 3.70 Cr. The original
proposal included 2 CARES maker spaces for South Goa. (15 lakhs each) 2 Experiential Centres
(1.25 Cr each), 1 ICT Lab on wheels (50 lakhs), 2 Proctored Training & Testing Centers (20 lakhs
each). The Governing Council dated 30/08/2024 agreed to initially approve the project, only to
the extent of 1 CARES maker space for South Goa. (15 Lakhs), 1 Experiential Centre (1.25 Cr), 1
ICT Lab on wheels (SO lakhs) to be made operational at Govt. Polytechnique, Curchorem -
Cacora. The PMU of CARES communicated through an e-mail that the file is moved to Govt for
implementing the project through ITCGL. The GC desired that the delay in execution of the
sanctioned project be addressed immediately by devising SoP and since the sanctioning
authority of the project is Chairman, SGDMF the files can be moved to Chairman, SGDMF after
sanctioning of the project instead of moving to Govt.

Decision: - The GC directed the DTE to complete the codal procedure and submit the report to
Chairman, SGDMF to obtain necessary approvals.

13. Department of Tourism: - The proposal was received from Tourism Department for skill
Development Training and placement program in mining affected areas. The training program
would involve Tourism and Hospitality sector and providing training for the positions as Front
office Associate, Food and Beverages Associate, Pastry/Bakery Commis, Street Food Vendor.
The training Centres are proposed to be established at Dharbandora, Mollem, Sacordem,
Collem, Kirlapal Dabal. The proposed project budget was Rs.2,80,97,000/ for 1200 trainee to be
trained. A pilot proposal was approved by GC initially for Rs. 50 lakhs. The GC was informed that

a substantial fund for capacity building and training in Tourism sector was available and also

<!-- page 10 -->

the formal courses are provided at the educational institute in Goa and also in the mining belt
and hence there will be duplication.
Decision: - The GC decided to withdraw the project and asked the SGDMF office to
communicate the decision to the concerned authorities.

Action (DOT/SGDMF)

14. Fencing of Abandoned Laterite Quarries: It was informed that as per the directives of the
Honourable Court it is required that all the abandoned Laterite queries be fenced to prevent
deaths due to drowning. The Disaster Management Cell of Collectorate South Goa presented a
proposal to carry out barbed wire fencing at 35 identified abandoned quarries located in mining
affected areas to prevent death of persons and livestock. The project cost would partly be borne
under the disaster management funds (Rs 75 Lakhs) and an amount of 2.25 crores is sought
from the DMF. The work would be carried out by PWD. The amount proposed is Rs. 2.25 Cr @
1240.80/meter. The Governing Council dated 30/08/2024 approved the project for Rs. 2.25 Cr
from the funds earmarked under the environmental preservation sector. The list of the quarries
was shared by the Disaster Management Cell.

Decision: The GC directed the Disaster Management Cell to submit the detailed estimates from

Pwo.

Action (Disaster management cell)
AGENDA NO. 2
Status update on the budget (provisional) of South Goa Distric Mineral Foundation Trust
The revised fund position in terms of revised PMKKKY guidelines 2024 of the DMF was informed in
detail with provisions made to the notified sectors as categorized into High Priority (75%) and Low
Priority (25%). Further, the status of the allotted amount, sanctioned amount, disbursed amount, and
available funds that can be utilized in future, was explained in a detailed manner to the members of
Mc.
soy Sanctioned Amount | p:.sursed amount Tbedisbursed Available Fund status as on
(Rs.) | ut amount 31/November/24
Drinking Water supply(9%) _210,62,795 = 36,17,999 1, 74,44,846 8, 60,87,868
Environmental Preservation & pollution | |
Control Measures(3%) | = .820000 800,000, 63 10,905,
Heattheare(iom) | 1 89,35,736, 1 68.42,419. __2093317 9,61,00,614
Education(108) | 9०,७9५ 2.7960274______ 82005.922 2,40,70,154
| | |
Welfare of Woman & Children (9%) | 1,75,23,367, 0 1,75,23,367, ___ 8,60,09,348
| | |

Welfare of Aged & Disabled people (5%), 41,16,000,__ 0______ 4116000 -_________534,02175
Skill Development (10%) | saree - 0 __3,07,81,000 ____6,52,55,350
Sanitation (5%) | ____97,98333________17,11,340 80,86,993, 4,77,19,842
णल १00 rc a en G8 EO acy = 3,A5,10,905
Agriculture (6%) ! } 0 ण 6,90,21,810
Animal Hustandary (5%) 12,00,00¢ © 12,00,000 5,63,18,175
Physical infrastructure (7°3} 2,25,00,000 © 2,25,00,000 5,80,25,288
Irrigation (756) ० 0 0 8,05,25,4a¢
Erergy & Watershed Development (8) © ° 0 9.2029,09
Any othe Measures (35) , 1,37,05,226, 1,37,85.236, 0 2.07,25.66
000000 ळा ; —14.10,00,000,_14,10,00,000, ee
PROJECT FUND प 56,57,50,715, 2049172218 _36,08,33,497_ ___88,94,12,78!
amin 74,05.828 30,38,235 43.67,593 6.05.60.67.
TOTAL FUND 56,57,50,715 21,13,91,033 11,86,71,983 1,17,02,66,98:
