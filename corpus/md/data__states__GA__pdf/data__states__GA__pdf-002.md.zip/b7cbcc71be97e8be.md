---
doc_id: "b7cbcc71be97e8be"
source_url: "https://ghb.goa.gov.in/notices/storage/2025/06/Corrigendumambajiext.pdf"
ministry: "Goa Housing Board"
title: "View Notice   PDF 316 KB  →"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9b336e62ac5cd619"
---

<!-- page 1 -->

GOA HOUSING BOARD
New Market Complex, Porvorim, Goa

C ORR I G E N D U M
Corrigendum No: - GHB/TECH/EE/481/2024
Ref: - NOTICE NO. GHB/EE/357/2024

Date: 04/07/2024

Date: 14/06/2024

The Bid Submission End Date for the tender for the work of “Construction of
Residential Cum Commercial Complex at Ambaji-Fatorda, Salcete, Goa.” has
been extended till 19/07/2024 upto 1.00 p.m. and the Bid Opening Date shall
be 22/07/2024 after 3.30 p.m.. For more details visit GHB Website and Goa
Online Portal.

S.d/Executive Engineer
