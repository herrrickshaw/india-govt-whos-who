---
doc_id: "adf8eb391ad7cfd6"
source_url: "https://goaonline.gov.in/Downloads/EODB_Notifications/IPB-letter.pdf"
ministry: "Goa Online Services, Goa"
title: "Timeline details associated with Excise"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "cee1718cd65a5def"
---

<!-- page 1 -->

t
र
wey
Government of or :
ffice of the Commissione: xcise
पय M G. Road, Panaji Goa-403001 eee
Website:- https://gonexcise,goy,in! Email:- exci-comm.goa@nic,in
Ph.no.:- 0832 2425593 Fax No:- 0832 2428333
WETIMANENCRMTI TOL aT
No.CE'1 1-02/2019-20/EXCi(Partfile) Q OG 2_ 021
To,
The Chiel Executive Officer,
Goa Investnent Promotion & Facilitation Board,
Panaji, Goa.
Sub: Information on: License for Setting up Distilleries and License for
Setting up Bottling Plant र
Madam, erty
With reference to the above cited Subject, the information sought by
you with regards to license for setting up distilleries and license for setting bs
up bottling plant is furnished hercbelow: १ a
1. The timeline for issuing licence for Fstablishment of Disti lery/ ae
Brewery/ Winery is 90 days, <i sie ee 4
2. The timeline for issuing licence for Manufacture and)ticenee thea
Bottling is 45 days, sy न Ace for :
"his issues with the approval of the Commi sioner of Excise,
; ae
Scanned by CarbonScanner
