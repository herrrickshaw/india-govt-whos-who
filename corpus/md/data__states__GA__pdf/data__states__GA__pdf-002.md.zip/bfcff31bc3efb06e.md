---
doc_id: "bfcff31bc3efb06e"
source_url: "http://nhm.goa.gov.in/wp-content/uploads/2019/07/Tender-Notice-Tn-703_704.pdf"
ministry: "Directorate of Health Services, National Health Mission, Goa"
title: "E-Bid – Proposal for Supply of Medical Equipments & Instruments under NHM for"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "03ae3acff2ee0ff4"
---

<!-- page 1 -->

STATE HEALTH SOCIETY-GOA
NATIONAL HEALTH MISSION
DIRECTORATE OF HEALTH SERVICES
CAMPAL PANAJI GOA – 403001
Email: sfwbgoa@hotmail.com
Tel No:- 0832- 2225985

No. DHS/NHM/PROCUREMENT/2019-20/ 1061

Date: 23/07/2019

TENDER NOTICE

SUB: E-Bid – Proposal for Supply of Medical
Equipments & Instruments under NHM for 2019-20 .
E-Bid is invited regarding proposal for supply of Medical Equipments and
Instruments under NHM for 2019-20 as under:
1) Tender No. 02/DHS/NHM/PROCUREMENT/PT/2019-20/703 – for medical
equipments.
2) Tender No. 03/DHS/NHM/PROCUREMENT/PT/2019-20/704 – for medical
instruments.
Tender documents along with details/terms and conditions can be downloaded from
the website: www.tenderwizard.com/GOA.
In case of any queries, please email at sfwbgoa@hotmail.com or contact on the
phone number 0832- 2225985.
