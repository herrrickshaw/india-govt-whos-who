---
doc_id: "f07d6d47ed9fdee6"
source_url: "https://gcarch.goa.gov.in/wp-content/uploads/2026/08/Notification-OC-88.pdf"
ministry: "Goa College of Architecture, Goa"
title: "Ordinance OC-88"
date: ""
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "999caf2c1b72d00f"
---

<!-- page 1 -->

GOA UNIVERSITY
Taleigao Plateau, Goa
No. 217 53 12026-Legall(Vol. XXXDI

2-? g

+h
Date: 1t August,2026

To"

l. The Secretary to Hon'ble Governor of Goa & Chancellor of Goa University, Lok Bhavan,
Dona Paula, Goa.

2. The Director, Directorate of Higher Education, Govt. of Goa, Goa Education Complex,
Alto-Porvorim-Goa.
3. All the Deans of Schools of Studies
4. All the Directors of recognizedinstitutions.
5. All the Vice Deans of Schools of Studies.
6. All the Deans/Principals of affiliated Colleges.
7. All the Divisional/Sectional Heads of University Offices.
8. The President, University College Teachers Association, Goa C/o Fr. Agnel College of

Arts and Commerce, Pilar, Goa - 403 601.
9. The Secretary, Goa University Teacher's Association.
10.The Registrar, High Court of Bombay at Goa, Penha De Franca, Porvorim, Bardez
Goa - 403 521.
ll.Senior Adv. A. A. Agni, University Counsel, Navelkar Trade Centre,2nd Floor, Opp.
Azad Maidan, Panaji, Goa.
12.The Assistant Registrar - office of the Vice-Chancellor
l3.The PA to Registrar
l4.The Office copy
l5.The Guard File

Sub: New Ordinance OC-88 governing the five-year choice based credit system
Programme for Bachelor of Architecture Degree of Goa University based on the

Council of Architecture (Minimum Standards of Architectural Education)
Regulations,Z02D (effective from the academic year 2026-2027).
Sir/Madam,

I am to forward herewith a copy of the New ordinance oC-88 governing
the five-year choice
based credit system Programme for Bachelor of Architecture Degree
of 6oa University based
on the Council of Architecture (Minimum Standards of Architectural
Education) Regulations,
2020 (effective from_ the academic year 2026-2027). This ordinance
oc-gg has been
approved by the Hon'ble Chancellor of Goa University on
l lth August, zizi under Statute
54-2(6) as amended. The Ordinance oC-88 is approved by the Academic
Council in its
meetings held on 12: & l3th May, 2026. The diecutive
Louncil has approved the said
Ordinance in its meeting held on29thMay,2026.

Yours sincerely,

t/ttu",rn4, \Aro*

(Prof. Sunder N. Otruri;

REGISTRAR
Encl: As above

<!-- page 2 -->

New ordinance OC-88 governing the five-year choice bas€d credit system programme for
Bachelor of Architectune Degree of Goa University bas€d on the Council of Architecture
(Minimum Standards of Archite€tural Education) Regulations, 2O2O (Effective from the
Academic Year 2026-2027),

oc-88

ORDINANCE RELATING TO THE FIVE-YEAR CHOICE BASED CREDIT SYSTEM
PROGRAMME FOR BACHELOR OF ARCHITECTURE (B.ARCH.) OEGREE OF
GOA UNIVERSITY (EFFECTIVE FROM THE ACADEMIC YEAR 2026-2027).

OC-88.1.O GENERAL Choice Eased Credit System (CBCS) provides choice for students to select
from the prescribed courses, Under the CBCS, the requirement for awarding a degree
is prescribed in terms of number of Credits to be completed by the students.

oc-88.1.1 DEFIT{ITIOI{S
In these Rules, the terms used shall have the following definitjons:

(i)

'Applicant' shall mean an individual who applies for admission to B.Arch
Programme of the Institute.

(iD 'Audit Course'shall mean the courses a migrating student from other institute
has to undertake for establishment of equivalence to the Course curriculum of

host institute

(iii) 'Carry-Over' of a course shall mean that a student may carry over the course in
which they were awarded less than 4.5 cumulative grade point average, to the
examination of that course in a subsequent academic year.
(iv)

'CGPA'shall mean Cumulative Grade point Average of the student

(v)

'Council of Architecture /CoA'shall mean the Statutory body for approval of
Architectural education

(vi) 'Course Coordinato/ shall mean a faculty member who shall have responsibility

for the course coordinating with other faculty membeE involved teaching the
course including internal assessments and award of grades

(vii) 'Course'shall mean curricular component identified by a designated code and a
title in the curriculum document

(viii) 'Degree'shall mean B.Arch degree alvarded to a student after achieving the
requisite credit in all courses of all Semesters.

(ix) 'Time bar' shall mean the number of years allowed for the course to be
completed by the student.

(x) 'Zero yead shall mean that year in a student,s academic record which may not
be considered for purpose of ijme-Bar.

(xi) 'Programme structure'shal mean curricurum of B. Arch programme with list of
couBes, credits and the structure.

(xii) 'S€mester' shall mean Semester as notified in Academic calendar of the
Institute

<!-- page 3 -->

(xiiD 'SGPA' shall mean Semester Grade Point Average of a student
simultaneous application of inputs of multiple
(xiv)
'' 'studio'shall mean a class for
'-a*rs". in a comprehensive planning and/ or design of a project or case study'
offer

In studio exercises the teachers shall take the lead to provide tasks and

or in
guidance for finding solutions. The students shall work either individually
Assessment (IsA)
6iorpt u"o shall bie evaluated by periodic Intra Semester Assessment and
Ind semester End Assessment (sEA) by a ProiecvPortfolio
Viva-Voce,

(xv) 'Lecture' shall mean a class for theoretical inputs for a course' Lectures are

knowledge
held to teach basic connections and the systemization of theoretical
presented
in a
and the methodotogy of scientiflc work' Specific courses are
shall be
wellstructured form, incorporating new research results The results
End
evaluated through periodic assessment of sessional work or semester
Assessment or both.

(xvi) "Project/Portfolio Assessment and Viva-Voce" shall mean a comprehensive

evaluation of a student's proiect or portfolio, together with an oral examination
conducted before a panel of examiners. Students are required to present and
defend their work, which may include drawings, portfolios, physical or digital
models, graphics, reports, research papers, and seminar presentations'

(xvii) 'seminars'shall mean where contents in a class shall be taught in dialogue and
discussion phases between the teacher and the student.

(xviii) 'Laboratory or workshops' shall mean where the contents of the course shall be
delivered through hands on work and experiments.

(xix) 'Design studios or construction studios or projects' shall mean where the
students contribute to the processing, analysis and the solving of problems of
direct professional practice, attended by faculty(s) entitled to condud the
studio and examine problems of direct professional practice, attended by
faculty(s) entitled to conduct the studio and examine. The results shall be
defended through drawings; models and reports and evaluated through
periodic assessment ISA and SEA.

(xx) 'study Tou/ shall be part of the course and conducted periodically, to help
consolidate course contents by acquainting students not only with professional
practice but also the culture and context of a region.

oc-88.1,2

NOII.IENCLATUR,E OF THE DEGREE

i) The nomenclature of the degree to be awarded after completion of 5 years
or 10 Semestec shall be Bachelor of Architecture (8. Arch.), as stipulated by
the Council of Architecture.
ii) In case the candidate exercises the exit option after completing and earning
all credits for the first three years of study, the degree shall be called Bachelor
of Science in Building Design (B.Sc. in Building Design).

2

<!-- page 4 -->

oc-88.1.3

DURATION OF THE DEGREE PROGRAMME
(i)The Bachelor of Architecture Programme shall be of minimum duration of 5
academic years (10 semesters of 15-18 working week) of 90 work days for
each Semester, inclusive of one semester (Semester VIII) of Practical Training
of minimum 18 working weeks.
(ii)The Academic Session of the Programme each year is divided into two
Semesters, i.e., Odd Semester and Even Semester.
(iii)The dates of First year (Semester I) will be based on the admission
schedule declared by the Admission Authority for Govt. of Goa.
(iv)The Academic calendar pertaining to commencement of Semester,
examination, result. vacations, mid-Semester breaks etc. for each
Semester/year will be based on the approval from the Goa University,
(v)A student shall be awarded the degree of Bachelor in Architecture by the
tjniversity for having earned the minimum credits as specifled in OC-88.2.1.
(vi)The Bachelor of Architecture Programme shall be completed in a maximum
period of 8 years. However? in special circumstances a candidate may be
granted an extra 1 year by the Principal to complete the course.
(vii)A student may exercise the exit option, if they have completed and earned
all credits (168) for the flrst three years (6 Semesters) of study. The degree to
be awarded after the successful completion of three years shall be Bachelor of
Science in Building Design (B.Sc. in Building Desjgn) or as recommended by
the Council of Architecture.
(viii)A student may be allowed to enter/re-enter after his exit only at Odd
Semester and must fulfill criteria of maximum 8 years to complete the Course
to be awarded the degree of Bachelor in Architecture by the University,
(ix) A student can withdraw from the course anytime by submitting his
withdrawal form along with 'No Dues Form' and his candidature will be
cancelled after recommendation and obtaining necessary approvals from the
Principal, who shall intimate the university.

oc-88.1.4

ADMISSIOI{ AND ELIGIBIUTY TO THE B. ARCH. PROGRAMME
(i)No candidate shall be admitted to the first year of architecture course unless
she/he has passed 10+2 or equivalent examination with physics and
I'lathematics as compulsory courses along with ejther Chemistry or Biology or
Te-chnical Vorational cou6e or Computer Science or Information Technology or
Informatics Practices or Engineering Graphics or Business Studies with atleast
45% marks in aggregate or passed 1O+3 Diploma Examination with
Mathematics as compulsory course with at least 450/0 marks in aggregate or as

notified by CoA from time to time,
(ii)The candidate shall obtain a valid score in Nabonal Aptitude Test in
Architecture (NATA) notified and conducted by the Council of Architecture.
(iii)The admission process will be carried out by the competent authority (as
notified by Government of Goa) which shall prepare the Merit List oi t'he
applicants with 50 per cent weightage of marks from aptitude tests and 50 per
cent marks in the qualin/ing examination as provided in (i) above, or as
prescribed by the Council of Architecture, from time to time,
(iv)Reservation of seats and relaxation in percentage of marks obtained in
the
qualirying examinatlon for admission shall be ai per the
reservation and
admission policy of Government of Goa.

3

<!-- page 5 -->

oc-88.r.5

INTAKE AND MIGMTION

(i)

(ii)

(iiD
(iv)

The institution shall admit candidates at the first-year level as per the
intake sanctioned by the Council of Architecture, subject to a maximum
of forty (40) candidates in a class. If candidates admitted are above
forty as per sanctioned intake, separate division(s) shall be organized
for each 40 candidates or part thereol
Supernumerary quota of admissions as notified by the Government of
India shall be over and above the sanctioned intake. The institutions
must create additional physical and academic infrastructural facilities, as
may be required, for the same in case such admissions exceed 10 per
cent of the sanctioned intake.
A unique Student Enrolment Number issued by the CoA to a student
admitted to Architecture Degree course is mandatory, Similarly, unique
ABC number issued by e-Samarth to a student admitted to Architecture
Degree course.
Migration of a student with valid CoA Student Enrolment Number from

one institution to another institution is permitted with prior approval
from the competent authority subject to the number of students not
exceeding the permitted maximum intake in that class in the receiving
institution and the same shall be notified by the receiving institution to

the Council of Architecture.

(v) The Equivalence Committee constituted by the University will establish
the equivalence for the Courses from the migrating jnstitution.
(vi) The Equivatence Committe€ may recommend th; migrating student to
undertake audit courses in order to complete pre+iquisite for

admission in the desired semester.

oc-88.2.0

PROGRAMME STRUCTURE
Courses,- Periods of Study and Examination under Credit System for
the Architecture
Degree Course.

Courses
Each Semester shall consist of various courses with each one

beinq assiqned a certain

number of credits, as stated below in the Scheme of er"mi-n"tiori
ioi'g. lr.t
Programme. The Choice Based Credit System is a learner centric
systeir and the
courses of study in the Architecture Degree programme shall
be as under:
(i) Professional Core (pC) Course: A course, which
shall compulsority be studied by a
candidate as a core requirement is termed as a Core
course.
(ii) Building Sciences and Applied Engineering (BS
and AE) Course: A course
- which
intorms (allied to) the professional core and stratt iomputsority
Ue ,trOi"J.

(iii) tlective Course: A course which can be chosen

a)

*-

from a pool of courses and are of two

Professional Elective (pE) which shall be very speciflc
or sDecialized or
supportive to the disciptine or course of stu;y
or which

:::li::o
provroes an"|.
extended scope,
b)

Open Elective (OE) which enables an exposure to some
or course or domain or nurtures the candidate,s proRciency

1

other dis.intinp
-- . "'oi sfiif ,-

<!-- page 6 -->

(iv)Professional Ability Enhancement Courses (PAEC) which shall be of two kinds:
Professional Abillty Enhancement Compulsory Courses (PAECC) and Skill Enhancement
Courses (SEC).

All Semesters shall have an Architectural Design course as the Professional Core (PC)
Course and a student must achieve the minimum cumulative GPA of 4.5 for passing to
be promoted to the next semester.
The Architectural Design Thesis in Semester X shall be prepared under the guidance of
a core Faculty member and the continuous internal assessments shall be conducted
with internal faculty members and the guide as a co-assessor.

A student shall not be permitted to attempt Architectural Design Thesis in Semester X
unless they have successfully completed Practical Training or Internship of Semester

VIII.

OC.88.2.1 CREDITSTRUCTURE
The Weightage in terms of Credits for each of the above in the prescribed curriculum of
the Programme shall be as follows:
1.

Professional Core Courses (PC)

149 credits

2.

Building Sciences and Applied Engineering (BS
and AE)

45 credits

3.

Elective Courses

4.

(i) Professional Electives (PE)

21 credits

(ii) Open Electives (OE)

9 credits

Professional Ability Enhancement Courses
(PAEC)

(i) Professional Ability Enhancement

41 credits

Compulsory Courses (PAECC)

(ii) Skill Enhancement Courses (SEC)

15 credits

Total Credits = 2gO
A credit shall consist of 16 clock hours of theory/tutorial/studio/seminar/lab/

workshop.

While calculating credits the following guidelines shall be adopted, namely: -

(i) 1 lecture hour per week shall have I credit;
(ii) 1 lab/workshop or studio exercises or seminar hour per week shall have 1 credit
and

(iii) 1 architectural design studio or construction studio or project or thesis hour per

week shall have 1 credit.

<!-- page 7 -->

Note:

a)

Assessment of each course based on Table 1 as per OC-88.2.2 would be done
by Intra Semester Assessment (ISA) and Semester End Assessment (SEA)
which shall be in the form of Written Examination Paper or Project/Portfolio
Assessment and Viva-Voce.

b)

The Credit for the particular course will be awarded only if both ISA and SEA
are attempted and cleared.

c)

The SEC and Elective courses will be assessed through ISA and SEA with
Project/Portfolio/Report Assessment by panel/s of examiners approved by Goa
University.

OC-88.2.2 PROGRAMSTRUCTURE

Semest

er

Professio
nal
Core
Course

Building
Science &
Applied
Engineerin

Professio Open
Elective
al
Elective

TOTAL
skill
Enhanceme

Ability

nt

Enhance

ment
Compul
sory

g

PC

Profess
ional

BS&AE

PE

OE

Course
PAECC

sEc

Credit
s

I

II
UI
ry
V

VI

vII

12(1)
3(1)
3(1)
12(1)
3(1)
3(1)
12(1)
3(1)
12(1)
3(1)
12(1)
3(1)
12(1)
3(1)
16(1)
3(1)

4(1)
3(1)

3(1)

28

4(1)
3(1)

3(1)

28

3(1)

28

4(1)
3(1)
4(1)
3(1)
3(1)
4(1)
3(1)
4(1)

3(1)

3(1)

28

3(1)

3(1)

3(1)

3(1)

3(1)

3(1)

28

3(1)

3(1)

28
28

3(1)

28(1)
7(1)

VIII

il

x

12(1)
3(1)
1e(1)

TOTAL

t49

3(1)

3(1)

45

2L

6

28

9

2A

3(1)

3(1)

28

44

12

280

<!-- page 8 -->

oc-88.3.0
ri)
(ii)
(iii)
(iv)

(v)
(vi)

oc-84.3.1

SCHEME OF EXAMI ATION
The performance of a student in each course shall be evaluated through ISA and SEA,
SEA shall be conducted at the end of each Semester.
Minimum attendance requirement for the Semester End Assessment (SEA) shall be
based on the Goa University Ordinance OA-17.
A student who has attempted at least 5070 of all Intra Semester Assessment (ISA)
conducted for the particular course shall be eligible for attempting Semester End
Examination (SEA) of the particular cours€.
The Credit for the particular course will be awarded only if both ISA and SEA are
attempted and cleared, attendance in ISA and SEA is mandatory
The SEC and Elective courses will be assessed through ISA and SEA to achieve the
Credit for the subject.

II{TRA SEMESTER ASSESSMEI{T (ISA)
(|)ISA shall be a continuous assessment throughout the semester with minimum 3
internal assessments for every course.

(ii)When more than one teacher is involved in teaching a Course, one teacher
preferably a regular teacher shall be identifled as the Course Co-ordinator.
(iii)The teacher of the Course shall be the Course Co-ordinator/lnstructor. The Course
Coordinator shall coordinate the teaching, examination and evaluation of ISA of the
Course. Each examiner shall award marks separately and hand over to course
coordinator for the purpose of averaging for the final marksheet at every stage who
shall maintain records of all the assessments at least for the period of one year.

(iv)Architectural design studio projects shall have a minimum of four (4) and a
maximum of six (6) stages of continuous assessment. The Studio Coordinator shall
declare the studio Programme, including the stages and their respective assessment
weightages, within the first week of the semester. The Studio Coordinator shall
maintain records of the Programme and all assessments for a minimum period of one
(1) year. No stage shall have assessment weightage more than 40 percent.
(v)Cumulative crade of ISA of all the courses including Electives shall
ordinarily be
announced and submitted by the course coordinator to the Examination
Committee at
least 1 week before the start of Semester End Assessment.

oc-88.3.2

SEMESTER END ASSESSMENT (SEA)
(i)SEAs shall be conducted as notified by Goa University from

time to time.

(ii)The Examiners for the SEA of all the SemesteG would

be appointed by the Goa

University as per Ordinance OB-4.

(iii)All extemal examiners shall have a minimum of 5 years
teaching professional
experience in a field of study relating to the course of examination
or is piescribed by
the Council of Architecture from time to time. However, an external
examiner for
Sem::tel X of Architectural Design Thesis course shall have a minimum
oi to y""o
teaching/ professional experience or as prescribed by the Councit
of nrcnitectuie.

/

(iv)SEA
Exam Type ,'projecq/portfolio Assessment and Viva_Voce,, and
-examiners
"Project/Reporvportforio Assessment" wifl be assessed oy a paneys
or ttrree
to be appointed by the University, of which two wiff be internaf
aJ onu- rrt"rnuf

-of

<!-- page 9 -->

Examiner. Ordinarily, Course Coordinator/instructor shall be the Convenor for the
panel of
Examination and other internal faculty selected from that particular Course
examiners
given
internal
by
teachers shall be the other Internal Examiner. The grades
will have 500/o
examiner
given
external
by
shall have 25olo weightage each and those
weightage.

(v)SEA of Dissertation (Semester IX) and SEA of Architectural Design Thesis (Semester

X) shall be assessed through a Project/Portfolio Assessment and Viva-Voce by a
panel/s of three examiners to be appointed by the University, of which one will be
Internal, one will be the guide and one External Examiner. Ordinarily, the Course

Coordinator/instructor shall be the Convenor for the Examination, The grades given by
convenor shall have 250lo weightage, that given by the Guide shall have 25olo
weightage and that given by external examiner will have 50o/o weightage.
(vi)The SEA Written Examination of courses conducted by the College as stated in the
Scheme of Examination, one convener and one paper setter shall be appointed by the
process of OB-4. The Convener shall scrutinize the two sets of question papers along
with answer keys submitted by the paper setter.

(vii)Any malpractice at the SEA examination, shall be reported to the examination
section of Goa University.
(viii)Goa University shall constitute panel/s of examiners for the SEA of Architectural
Design Studio. Each panel shall have two internal and one external member. One of
the internal examiners shall be the Convener of the panel. Ordinarily, each panel shall
assess not more than 20 students per day.

oc-88.3.3

PRACTICAL TRAINING
(i)A student shall undergo Practical Training during Semester VIII for a period of
minimum 18 Weeks in the office of an architect or an organization operating in an
allied field of practice or research, duly approved by the Principal, under mentorship of
an architect having experience of at least 5 years and having a valid CoA registration.
(ii)The practical training shall be supervised and evaluated through periodic
assessment by the mentoring architect and SEA as part of curricular studies. The
evaluation report submitted by the mentoring architect shall be considered by the
panel of examiners.
(iii)Training in Foreign Country shall be done under the Registered Architect of that
Country and duly approved and monitored by the Principal.

oc-88.3.4

GRADES AND GRADE POINTS
The assessment of the work of students for ISA shall be awarded grades on the basis
of a ten-point Gradinq System with Grade Value from 0 :o 10, which shall be as follows:

Numerical Grade value

Letter Grade

Description of Grade

10

o

Outstanding

9

A

Excellent

8

B

Very Good

7

C

Good

6

D

Average

<!-- page 10 -->

5

E

Satisfactory

Below 5

F

Poor

0

NA

No attempt

0

AC

Audit Course

written Testfiheory papers conducted as pad of IsA/sEA shall be awarded mark out
of 100, which shall then be conveted into Grade points for inclusion in the
grading/result using the following formula:
Grade Point =

Percent Marks
10

Grade Point Average (GPA), sGpA and cumulative Grade point Average shall be
convetted to Letter Grade as shown h table below:

GPA

Letter Grade

9-<10

O Outstanding

8-< 9

A (Excellent)

7-<B
6 -<7

C (Averaqe)

5.0-<6

D (Satisfactorv)

4.5 - < 5.0

P (Pass)

B (Good)

Below 4.5
F (Fail)
Formula for conversion of Grade point Average/SGpA/CGpA to percentage:
Percentage = GPA/SGPA/CGPAx 10

oc-88.3.5

MINIMUM GRADE FOR PASSING A COURSE
A student shall require a minimum cumulative grade point score of 4.5 together
in ISA
and SEA, to earn assigned credits of any course. A student scoring bllow +.5-is
cumulative score shall be declared failed in that course.

A student declared failed in an Architectural Design studio course shall have
to answer
supplementary semester End Assessment (ssrA) for that course to earn the assigned
credit.

9

<!-- page 11 -->

oc-88.3,6

PROMOTION TO THE NEXT HIGHER SEMESTER AND CARRY OVER
(i)A student not passing Architectural Design Studio Courses with cumulative grades of
ISA and sEA and also in the Supplementary Semester End Assessment (SSEA) in a
semester shall be detained and shall have to repeat the course along with the next
regular batch.
(ii)For the Architectural Design cours€, a supplementary SEA shall ordinarily be
conducted within fifteen days from the date of declaration of results. For all other
courses, the repeat examinations shall be conducted along with the subsequent SEA
examinations.
(iii)A student who has earned the credits for Architedural Design Studio courses but
has not earned the credit of other Courses shall be allowed to carry over not more
than three courses from the previous s€mesters at any given point in time to be
admitted for the next Semesters.
(iv)Student failing elective course will have an option to choose from the elective
courses from the same category of courses offered in the subs€quent semesteG,
(v)If a student desires to improve the Internal Assessment (ISA) in a course, the
student shall be required to re-register for the course in the respective semester along
with the regular batch of students.

oc-44.3.7

COMPUTATION OF GRADE PIOINT AVEMGE (GPA), SEMESTER GRADE FOINT
AVERAGE (SGPA) & CUMUI-ATIVE GRADE POINT AVERAGE (CGPA):
The GPA, SGPA, & CGPA shall be calculated as follows:
(i)The GPA for ISA of a student obtaining grades at different stages shall be calculated
as shown in the Illustration below
(ii) In any cou6e in a semester, the Grade Points awarded shall be multiplied by the
Credits assigned. This produd divided by the total credits earned in that semester
shall be the SGPA.
SGPA (Si) =

: (Ci x Gi) / > ci

Where "Ci" is the number of Credits of the i6 Course and Gi is the grade point scored
by the student in the is Course.

(iii)The Cumulative Grade point Average (CGPA) shall be calculated as
CGPA =

I (ci x sD/Eci

Where Si is the SGPA of the is Semester and Ci is the total number of credits eamed in
that Semester.

oc-88.3.8

ILLUSTRATION FOR COMPUTATION OF GPA, SGPA & CGPAI
A,I Calculation of GPA
Illustration 1
For Studio based courses, the GpA for the ISA of a student obtaining grades
at
different stages shall be calculated as shown in the Illustration below:

l0

<!-- page 12 -->

Weightage
o/o

Stage

of each
staqe

Grade
Point

Grade Obtained

Total Stage-wise Value

Stage I

10

7

C

Stage II

15

5

E

L0x7 =70
15x5=75

Stage III

20

6

D

2Ox6 =l2O

Stage IV

25

9

A

25 x9 = 225

Stage V

30

6

D

30x6=180

Grand

Total

100

670

Shall obtain a GPA of 6.70 in ISA as shown:

Total GPA in Sessional

Assessment

-!! = 6.79

The student obtaining a Grade of'B' with a Grade Point value of 8.00 in the SEA for
that Course, then the GPA of that Course shall be calculated as follows:

Intra
Semester
Assessment
(rsA)

Semester End Assessment
(SEA) Grade value

Average GPA

GPA

6.70

6.70 +8.00= 14.70 l2=7.35

8.00

(i)The SGPA and CGPA shall be rounded off to 2 decimal points and reported in the
grade certificate.
(ii)For each Course a student securing less than 4.5 grade point CF) in cumulative ISA
and SEA in the Course shall not be entitled to earn any credits for that Course.
(iii)SGPA for a given semester shall not be calculated, in case a student has not earned
the credits for any of the course/s of that Semester.

OC-88.3,9 DECLARATION OF RESULTS
(i)Result of SEA/SSEA of any semester shall be declared by the College/ University no
later than 45 days after the last day of examinations

(ii)The college/University will declare the dates of the ssEA within 15-days of

declaration of the result and announce the results of ssEA within 15 days thereof.

1l

<!-- page 13 -->

OC-88.3.T0 VERIFICATION OF MARKS FORWRITTEN EHMINATION ONLY

(i)Verification of SEI/SSEA answer books shall be permitted'
(ii)For Verification of mark of all the Semester End Assessment the student shall make
an application through the Princlpal of the College along with payment of requisite fee
within 10 days of declaration of the result to the authority conducting SEA/SSEA as
notified by the University from time to time.
(iii)All grievances pertaining to ISA marks shall be dealt with by the College Grievance
Committee within one week of declaration of ISA grades before sending the ISA marks
to the University. After one week of declaration of ISA grades, no Grievance shall be
entertained.

OC-88.4.0 REQUIREMENT FOR AWARD OF DEGREE

A student should have secured a minimum Cumulative Grade Point Average (CGPA) of
4.5 along with all the required earned credits.

OC-88.4.1 AWARD OF CLASS IN THE DEGREE CERTIFICATE
The CGPA shall determine the award of class in the Degree Certificate.
The categories of classification shall be as follows:
First Class Distlnction

CGPA of 7.75 and above and should have

3

First Class
Second Class

4

Pass Class

cleared every subject in a single attempt
CGPA below 7 .75 and not less than 6.50
CGPA below 6.50 and not less than 5.50
CGPA below 5.50 and not less than 4.50

1

2

OC.88,4.2 STUDENT EXCHANGE AND CREDIT TRANSFER
(i)If the College has signed a MoU with another College/University for the B.Arch
course for exchange of students for a particular Semester then any student selected
under the same is permitted to go on an exchange Programme for that semester.
(ii)A student enrolled in the College undergoing an exchange Programme elsewhere
can earn credits equivalent to exchanged semester's credits in the host institute.
Equivalence of courses will be approved prior to the exchange by the Board of Studies.

12

<!-- page 14 -->

oc-88.4.3

ZERO YEAR

(i)A student who is unable to pu6ue studies during a semester or appear in an
External Examination due to unforeseen/ extraordinary circumstances viz. prolonged
illness or accident, death or critical illness or severe injury of immedi;te fa;ily
members or natural disasters etc., beyond the control of the student, may request in
writing to the Principal for Zero year.
(ii)The application shall be evaluated and recommended by the committee appointed
by the principal and approved by him/her.
(iii)Zero Year will not be counted as a year for the purpose of .T.ime Bar and
will not

affect the eligibility of students for any scholarships or awards.
(iv)Zero Y-ear can be availed by undergraduate students only once in the entire
duration of the Programme.
(v)A student, having availed of the Zero year, shall repeat the full semester not
completed due to the unforeseen/ extraordinary circumstances in the next academic
year. All other conditions for the semesters, fees, attendance
and evaluation in all the
courses shall be the same as for a regular student.

oc-88.4.4

TIME BAR:
The Architecture Course shall be completed in a maximum period of years.
8
However, in special circumstances a candidate shall be granted an
extra l year
by.the Institution to complete the course subject to riaximum oi nin" y""o

(i)

(ii)
oc-88.4,5.0

oc-88.4.5.1

including zero year.
Students successfully compleung three academic years (six semesters),
but
unable to complete the B. Arch. programme shall be awarded u 0"9r."
u,
Bachelor of Science in Building Design (B.Sc. in Building Design).

COLLEGE COMMITTEES
The following Committees shall be constituted by the principal
of the College for a
duration of three years:

COLLEGE EXAMINArION COMMITTEE;
(i) The Pnncipal sharr constitute an internar three-member Examination committee
... from among the tull-time faculty as the Cottege Examination

Co;.itti.
(I) rne sentor-most faculty among the members not below
the position ot

Associate professor will be the ln-charqe of Examjnations.
(iii) In case of his absence during the conduct of
ur"rin"tion

members will take up the charge as In_charge of

one of the other
eraminations fol,

and other purposes related to the ex-am section.
. communications ma.y
opt

.
(,")

other facutty members with prior approvat from
]J:^:9_11IS
me pnnclpat tf required!o;for specific purposes.

(v) The tenure of this Committee shall 6e ior a period of
Erree vears.
(vi) This Committee sha undertake the fottowinb

tasLi

a) Working out the schedules for a[ SEA and SSEA examinations
conducted by
the College
b) Conducting the examinations with the help of Intemal
Faculty and
- Externat
-"''
Examiners for all the Semester examinations in
various cours"J.
c) Co-ordination with the Controller of Examination, Coi
UniversiW for ttre
condud of sEA sendins rsry'sEry'ssEA-sruaes,
li j"i,igil";,"",

-

"

-"' "'
conducting examinatjons and dispatch of-an*"i "fpointrn;i
U'o'oL.

13

'"''r""

<!-- page 15 -->

d) Final tabulation, verification and preparation of Result.

oc-88.4.5.2

COLLEGE UNFAIR MEAI{S INQUIRY COMMITIEE (CUMIC)
(i) The college Unfair Means Inquiry Committee shall be constituted by Ere
Principal with the following members:
a. Associate Professor /senior hculty member as ChairpeBon.
b. Two regular faculty members, preferably not members of the College
Examination Committee or the College Grievance Committee.
(ii) The CUMIC shall inquire into the cases of unfair means and malpradices
reported in writing by the examination committee, Invigilator, Senior
Supervisor during the examination to be conducted by college as notified by
the University from time to time. The examination committee will report to
CUMIC within 7 daYS.
(iii) The following procedure shall be followed for inquiring into the cases of
students alleqed to have used unfair means at the Examinations.
(iv) The student shall be served with a Show-Cause notice and made aware of
the charges/allegations reported against him/her and a written reply sought
for the same to be presented at the time of his/her appearance before the
CUMIC

(v) The student shall be informed during the hearing about the propos€d adion

to be taken in the case and the broad category of malpractice and the

quantum of punishment shall be as per OA-5.14.19.
(vi) The reply received by the Committee from the student and his statements
before the Committee shall be considered and the final recommendation in
the matter shall be taken and the recommendations per OA-5.14.19 shall be
submitted to the Principal.
(vii) The punishment finally awarded shall be equal to, or less than, what is
mentioned in the show cause notice, but not more than what is mentioned
therein.
(viii) The CUI4IC shall act as a recommending body to the Principal.
(ix) The Principal of the College under the provisions of statute sB-13(iv) of the
University shall issue the final order and send it to the Examination
Committee for implementation before the declaration of the Result,

oc-88.4.5.3

COLLEGE GRIEVANCE COMMITTEE
(i) The College Grievance Committee shall be constituted by the Principal and will
have three members as under: a. Associate Professor /Senior faculty member as Chairman, provided that
s/he is not the Chairman of CUMIC.
b. Two regular faculty members, preferably not membeB of CUMIC or the
College Examination Committee.
(ii) In case the grievance is conceming any member of the Grievance Committee,
the Principal shall reconstitute the Committee for the concerned grievance,
excluding the concemed member.
(iii) This Committee shall investigate into specific written complaints from the
students regarding the conduct of ISA and SEA of written examinations, and
recommend a course of action to the Principal of the College as per the
relevant University Ordinance.
The said written complaint by the student should be submitted to the Principal
within 15 days after the declaration of results/grade or within 7 days after the
personal verification of the answer books as the case may be and should be
accompanied with a fee of Rs. 200/- (refundable jf the complaint is found
genuine).
The Committee shall seek a reply to the allegations, if any, wihin 1o-days

(iv)

t4

<!-- page 16 -->

made by the student from the concerned teacher/examiner.

(v) The Committee after considering the reply of the concerned teacher/examiner,
shall recommend a course of action in writing to the Prlncipal.

(vi) The Principal may inform the students of the findings/recommendations of the
Committee and shall take appropriate actlon including reassessment of the
said answer book.

(vii) If the said allegation(s) is (are) found to be a deliberate attempt of casting
aspersions on the teacher(s) concemed. If the allegations are found to be
genuine and the same is recorded giving reasons, the action shall be taken as
provided under OA-5.2.6.

xxxxxxx

l5
