---
doc_id: "8fac71c50fec14ce"
source_url: "https://dsya.goa.gov.in/wp-content/uploads/2019/01/Sports-Equipment-Domestic-Hockey-CorrigendumVII.pdf"
ministry: "Directorate of Sports and Youth Affairs, Goa"
title: "Sports Equipment-Domestic (Hockey) CorrigendumVII"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e1c5826b121d6499"
---

<!-- page 1 -->

Government of Goa
Directorate of Sports and Youth Affairs
Campal, Panaji-Goa
Fax: - (0832) 2464787

Phone: - (0832) 2463212

E-Mail:- dir-spor.goa@nic.in

Date:-04/06/2019
Ref: Tender No. 21/NGOC/Sports FA/Domestic/2018-19
Dated: 09/03/2019
Corrigendum VII
Reference is invited to Domestic Tender enquiry dated 09/03/2019 for
procurement of Sports equipment for the Sport discipline of Hockey.
The following are the amendments to the Tender:
i)

Read, Section II (iii)- Pre-Qualification Criteria for Participation

Sr.
No
1

RFP
Clause
Section II,
(iii) (b)

Existing Criteria

Amended Criteria

The Bidder should have a
minimum average annual
turnover of ₹80,00,000/-,
specifically from the sale of
sports goods and equipment
in the last 3 financial years.

2

Section II,
(iii) (c)

The Bidder should have been
in the business of
Manufacturing/ Distribution
of Equipment and
Accessories for the past 5
years for equipment of
similar nature to that as

The Bidder should have a
minimum average annual
turnover of ₹40,00,000/,specifically from the sale
of Sports goods and
equipment in the last 3
financial years.
The Bidder should have
been in the business of
Manufacturing/
Distribution of Equipment
and Accessories for the
past 3 years for equipment
of similar nature to that as

<!-- page 2 -->

3

Section II,
(iv) (d)

detailed in Annexure 5.
The Bidder must have
successfully supplied
majority of the tendered
items, listed in the RFP, for at
least 3 major
National/International
Sporting Event, recognized
by the respective
International Sports
Federation/ National sports
Federation of India, during
the past 5 years.

detailed in Annexure 5.
The Bidder must have
successfully supplied
majority of the tendered
items, listed in the RFP, for
1 major
National/International
Sporting Event,
recognized by the
respective International
Sports Federation/
National sports Federation
of India, during the past 7
years.

Accordingly, Annexure 2- Form II- Pre-Qualification Response Sheet also
stands amended to this effect.

ii)

The last date for the Bid submission may now be read as 17th June, 2019.

iii)

The Date and Time for Technical Bid opening for the Sport of Hockey
may now be read as 25th June, 3.00 pm and Financial Bid opening may
be read as 3rd July, 4.00 pm

Director
Directorate of Sports & Youth Affairs
Govt. of Goa
