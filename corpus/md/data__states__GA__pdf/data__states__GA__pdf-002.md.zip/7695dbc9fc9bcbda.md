---
doc_id: "7695dbc9fc9bcbda"
source_url: "https://gcarch.goa.gov.in/wp-content/uploads/2025/01/20240803-Advisory-Committee.pdf"
ministry: "Goa College of Architecture, Goa"
title: "Arch_Advisory Committee 03-08-2024 onwards"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ec45f1161a1ade1b"
---

<!-- page 1 -->

RNI No. GOAENG/2002/6410

Reg. No. RNP/GOA/32/2024-2026

Panaji, 10th October, 2024 (Asvina 18, 1946)

SERIES II No. 28

PUBLISHED BY AUTHORITY

GOVERNMENT OF GOA

“5. To examine and to deduce the authenticity in

Department of Archives

respect of Notary records and other Land

––
Addendum

registration records which are allegedly
tampered or forged or any other form.”

No. 4/1/83/2023/Man ‘B’-986
Read:

By order and in the name of the Governor of

Order No. 4/1/83/2023/Man ‘B’-831 dated
27th August, 2024 published in the Official
Gazette, Series II No. 23 dated 5th
September, 2024.

In continuation to the order mentioned in the
preamble, following point shall be added under
the scope of the Committee:

Goa.
Shri Rohit A. Kadam, Director, Department of
Archives & ex officio Joint Secretary.
Ribandar, 27th September, 2024

——————

District Rural Development Agency, South Goa
––
O rd e r
No. DRDA-S/Mon.Sec/DISHA/7/2024-25/678
In terms of the Order issued by the Ministry of Rural Development, Department of Rural Development,
Government of India, New Delhi vide No. Q-13016/02/2019-DISHA dated 08th August, 2024, the District
Development Co-ordination and Monitoring Committee (DDCMC) ‘DISHA’ is being constituted for South Goa
District for monitoring and implementation of the programmes and schemes sponsored by Government of
India in accordance with the prescribed procedure and guidelines.
The composition of the South Goa District DISHA Committee is as under:
1. Shri Captain Viriato Fernandes, Member of Parliament (Lok Sabha),
South Goa District

— Chairperson.

2. Shri Sadanand Shet Tanawade, Member of Parliament (Rajya Sabha)

— Co-Chairperson.

3. All Members of the State Legislative Assembly (MLAs) of South Goa
District

— Members.

4. District Collector, South Goa District

— Member Secretary.

5. All Chairpersons of Municipalities of South Goa District

— Members.

6. Chairperson, Zilla Panchayat, South Goa District

— Member.

7. Chief Executive Officer, Zilla Panchayat, South Goa District

— Member.

Suggestions are welcomed on e-mail: dir-gpps.goa@nic.in

559

<!-- page 2 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 28

10TH OCTOBER, 2024

14. Vivekanand Kantak, Utorda, Goencho Ekvott (NGO)

— Member.

15. Yatish Govind Parawar, Avedem, representative of the (SC) Community

— Member.

16. Umesh Tolu Gaonkar, Cotigao, Canacona, representative of the (ST)
Community

— Member.

17. Tara Kerkar, Dabolim, Women Representative

— Member.

The Committee shall meet once every quarter to monitor and review progress made by implementing
Departments/Agencies.
By order and in the name of the Governor of Goa.
Sanjay Goel, IAS, Secretary (Rural Development).
Margao, 30th September, 2024.
——————

Department of Education
Directorate of Technical Education
College Section
––
Ord e r
No. 16/26/86-EDN/Vol.I/1715
Government is pleased to re-constitute a
Governing Committee/Advisory Committee for Goa
College of Architecture, Altinho, Panaji consisting
of the following members with effect from
23-08-2024, for a period of 03 years:-

12. Dr. Vishvesh Kandolkar

— Internal
Faculty
Member.

13. Ar. Salvin Dias

— Internal
Faculty
Member.

14. General Secretary, Student
— Member.
Council or a representative
of Student body of the College
15. Dr. Leon Angelo Morenas,
Principal, Goa College
of Architecture

— Member
Secretary.

1. Prof. K.T. Ravindran,
Former Director, SPA,
New Delhi

— Chairman.

2. Secretary (Education),
Government of Goa, Porvorim

— Member.

i. To monitor the academic activities of College.

3. Director, Directorate of
Technical Education,
Porvorim

— Member.

ii. To advice in curriculum development,
Co-curricular and Extra-curricular activities.

4. Nominee of Vice Chancellor,
Goa University, Taleigao

— Member.

Roles & Responsibilities:

5. Ar. Marwin C. Gomes, Chief — Member.
Architect and CoA, Goa State
Nominee
6. Shri Vivek Belokar, Assistant
Director, Directorate of
Technical Education,
Porvorim

— Member.

7. Ar. Chandan Parab

— Member.

8. Ar. Manguesh Prabhugaonkar — Member.
9. Ar. Rohit Andrade

— Member.

10. Ar. Narayan (Sunil)
Sardessai

— Member.

11. Ar. Pallavi Satadekar

— Member.

iii. To assist in collaboration with industry/
/company/professional for faculty training,
knowledge exchanges, consultancy activities,
etc.
iv. To advice/recommend on teaching aids,
equipment, machinery, studio, apparatus, IT
infrastructure, computers, library facilities,
etc.
v. To identify training needs of students, faculty
and staff, propose plan for implementation
and follow-ups.
vi. To assist to organize seminars, workshops and
exhibitions for benefit of students, faculty
and industry/company/professionals.
vii. To assist and monitor the placement, formulate
plan and guide students of College on career
prospects, job opportunities and internship.

561

<!-- page 3 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 28

10TH OCTOBER, 2024

viii. To assist College to conduct visits to Industries
live project and also guide students for final year
project work.
ix. To generate funds through various projects from
Industry/Company/Business Organizations/
/Professions and encourage donors to donate as
per requirement of College and utilize the same
for upgradation of College.
x. To advise on institution upkeep, maintenance
and infrastructural needs.
The Hon’ble Chairman, Prof. K.T. Ravindran, New
Delhi, outstation member shall be entitled for TA/
/DA as Non-Official Member on account of travel in
India at par with that of Principal, Goa College of
Architecture, in terms of primary unit of
appropriation (Rule 70 of GDFPR, 1997 under Sub
Head 11—Domestic Travel Expenses for days of
meetings and travel).
This issues with the approval of Government vide
U.O. No. 2078/F dated 12-08-2024.
By order and in the name of the Governor of
Goa.
Dr. Vivek B. Kamat, Director (Technical Education)
& ex officio Addl. Secretary.
Porvorim, 23rd August, 2024.
————

O rd e r
No. 8/1/103/PF/AGS/GCA/DTE/24/1716
Read: Memorandum No. 8/34/86/EDN/Vol.IV/897
dated 02-07-2024.
On the recommendations of the Goa Public
Service Commission conveyed vide their letter
No. COM/I/5/6(2)/2023/59 dated 22-05-2024,
Government is pleased to appoint Shri Atmaram
Gurunath Sawant on temporary basis to the post of
Assistant Professor in Fine Art (Applied Art) (Group
‘A’ Gazetted) at Goa College of Art, Altinho, Panaji-Goa, under General category on an initial pay at
Level 10 [i.e. on an initial pay of Rs. 15,600/- (pre-revised) in Pay Scale of Rs. 15,600-39,100 (pre-revised) + Academic Grade Pay of Rs. 6,000/- (pre-revised)] w.e.f. the date of joining as per terms and
conditions contained in the Memorandum cited
above.
The appointment is against the post of Assistant
Professor in Fine Art (Applied Art) vacated with
effect from 01-05-2015, by Smt. Rohini Kakode,

562

subsequently revived vide Order No. 8/1/84/
/Revival/GCA/DTE/2020/1726 dated 26-10-2020.
Shri Atmaram Gurunath Sawant will be on
probation for a period of two years.
He should join duties within 30 days of the receipt
of this order, failing which this order is liable to be
cancelled without further notice.
He has been declared fit by Medical Board, Goa
Medical College & Hospital, Bambolim vide letter
No. 4/105/85-H/GMC/2024/535 dated 27-07-2024.
His character and antecedents have been verified
and nothing adverse is reported against him as
conveyed by the Additional Collector & Additional
District Magistrate, North Goa, Office of the District
Magistrate, North Goa, Magisterial Branch, Collectorate
Bldg., Panaji, vide letter No. 2/6/2013-MAG/VCA/Vol.I/
/2380 dated 19-08-2024.
By order and in the name of the Governor of
Goa.
Dr. Vivek B. Kamat, Director (Technical Education)
& ex officio Addl. Secretary.
Porvorim, 26th August, 2024.
————

O rd e r
No. 8/1/104/PF/NSN/GCA/DTE/24/1717
Read: Memorandum No. 8/34/86/EDN/Vol.IV/898
dated 02-07-2024.
On the recommendations of the Goa Public
Service Commission conveyed vide their letter
No. COM/I/5/6(2)/2023/59 dated 22-05-2024,
Government is pleased to appoint Shri Navjyot
Suryakant Naik on temporary basis to the post of
Assistant Professor in Fine Art (Applied Art) (Group
‘A’ Gazetted) at Goa College of Art, Altinho, Panaji-Goa, under O.B.C. category on an initial pay at
Level 10 [i.e. on an initial pay of Rs. 15,600/- (pre-revised) in Pay Scale of Rs. 15,600-39,100 (pre-revised) + Academic Grade Pay of Rs. 6,000/- (pre-revised)] w.e.f. the date of joining as per the terms
and conditions contained in the Memorandum cited
above.
The appointment is against the post of Assistant
Professor in Fine Art (Applied Art) vacated with
effect from 01-05-2015, by Shri A. F. D’Souza,
subsequently revived vide Order No. 8/1/84/
/Revival/GCA/DTE/2020/1726 dated 26-10-2020.
Shri Navjyot Suryakant Naik will be on probation
for a period of two years.
