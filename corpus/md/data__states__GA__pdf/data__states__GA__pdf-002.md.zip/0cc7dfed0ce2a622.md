---
doc_id: "0cc7dfed0ce2a622"
source_url: "https://dmg.goa.gov.in/PDFs/Notifications/Orders/Inspecting-officers-for-purposes-Rule-2-e-GMMCR-1985.pdf"
ministry: "Directorate of Mines and Geology, Goa"
title: "Order - Inspecting Officers for the Purposes of Rule 2(e) of the GMMCR,1985"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "4bcb666400f3e238"
---

<!-- page 1 -->

न्हे.
कं
ny Government of Goa
irectorate of Mines & Geology
Institute Menezes Braganza,
Email: dir-mine.goa@nic.in Panaji - Goa 403001.
Website: www.dmg.goa.gov.in Tel : (0832) 2426421
No. 01/21/2025/Notification’AdmalMinggppeo नि" 392 २5पिवलळळार्‍ाार्‍ार्‍ा
fo. 01/21/2025/Ni i .
ee कट 2000000.
ee ती
Read: (1) Noti i :
(1) 0) No. 5/5/90-Mines dated 29/10/1997 published in the
(2) Order N ‘azette, Series INo. 44 dtd. 29/01/1998
a ण 44/1/Policy/80-Mines/Vol.VI/Part/2198 dtd. 20/11/2012
published in the Official Gazette, Series II No. 34 dtd. 22/11/2012
ORDER
| In pursuance of clause (e) of Rule 2 of the Goa Minor Mineral Concession Rules, 1985
(hereinafter referred to as the “said Rules”), and in supersession of the Government
Notification/Order read in the preamble at serial number (1) and (2) above, the Government
of Goa hereby authorizes the following officers to exercise the powers of the Inspecting
Officers under rule 46, 47(4), 48, 62(3), 62(4), 62(5), 62(6), 62(7), 62(8), 63 and 64 of the
said Rules within the limits of their respective jurisdiction with immediate effect namely:-
(i) the officers not below the rank of (Assistant) Motor Vehicle Inspector in the
Directorate of transport;
(ii) Revenue officers not below the rank of Mamlatdar / Joint Mamlatdars of the
respective taluka; |
(iii) the police officers not below the rank of the Assistant Sub- Inspector; |
उ (iv) the Hydrographic Surveyors, Radio officers, Marine Engineers, Deputy
| Hydrographic Surveyors and Marine Inspectors in the office of the Captain of Ports; and
(v) the officers of the Water Resources Department not below the rank of the Junior
Engineer.
By Order and in the name of
the Governor of Goa
(Narayan Gad)
Director & Ex-officio Joint Secretary
Mines & Geology |
To,
The Director, Printing and Stationery, Government Printing Press, Panaji for favour of
publication in the next Official Gazette.
|
| Copy to:- i
| 1. The District Collector — North, Panaji;
|. 2. The District Collector — South, Margao; _
| 3. The Director General of Police, HQ, Panaji;
4. The Director of Transport, Panaji;
5. The Captain of Ports, Panaji;
| 6. The Chief Engineer, Water Resources Department, Porvorim;
t 7. Office copy;
| 8. Guard file.
| 1
क न
