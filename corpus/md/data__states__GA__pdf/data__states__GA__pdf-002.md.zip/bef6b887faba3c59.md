---
doc_id: "bef6b887faba3c59"
source_url: "https://goa-tourism.com/wp-content/uploads/2023/12/Caravan-Tourism-Policy.pdf"
ministry: "Goa Tourism Development Corporation (GTDC), Goa"
title: "Caravan Tourism Policy (English, PDF, 285 KB)"
date: ""
pages: 15
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "173f2052bbdb0afd"
---

<!-- page 1 -->

<!-- page 2 -->

Caravan Tourism Policy

Department of Tourism
Government of Goa

2

<!-- page 3 -->

Contents
1

DEFINITION ................................................................................................................................4

2

INTRODUCTION ..........................................................................................................................5

3

OBJECTIVE OF THE POLICY...........................................................................................................5

4

APPLICABILITY OF THE POLICY .....................................................................................................5

5

THE TOURISM CARAVAN .............................................................................................................6

I.

Registration of Tourism Caravan .................................................................................................6

II.

Caravan specifications for registration.........................................................................................6

III.

Registration Process...................................................................................................................7

IV.

Incentives by Government to attract caravan operators in Goa ...................................................7

V.

Eligibility of Caravans for availing incentives ...............................................................................9

VI.

Procedure of availing incentives .................................................................................................9

6

CARAVAN PARKS ..................................................................................................................... 10

3

<!-- page 4 -->

1

DEFINITION

GoG or Government : State Government of Goa
DOT

: Department of Tourism, Government of Goa (responsible for the
implementation of the policy)

Caravan

: The specifically built vehicles being used for the purpose of hospitality
travel, leisure and accommodation would be termed as ‘Caravan’ or
Campervans and would include vehicles viz. RVs, Campervans, Motor
Homes, Trailer caravan (T2 type), etc. with minimum features as mentioned
in clause 5.(II) of this policy.

Caravan Park

: A Caravan Park is an area not within any restricted zone, and shall only be
the area designated for parking of Caravans which have accommodation
facility for the tourists to stay inside the respective caravan vehicle during
day and night. Moreover, such Caravan Parks must be equipped with
minimum infrastructure facilities like standard 230V power points,
wastewater discharge connection pipes, freshwater inlet connection pipes,
convenience facility and recreational space for the tourists.

Applicant

: Caravan Tour Operators with their caravans registered in Goa.

4

<!-- page 5 -->

2

INTRODUCTION

Goa has been one of the most prominent tourist destinations in India and is considered as a global
tourism brand name. Owing to its picturesque territory ensconced between the fertile coastal strip of
the Arabian Sea and the breathtaking mountain ranges of the Western Ghats, Goa is a renowned tourist
destination in the world. Due to its natural setting, the state is bestowed with scenic beauty, lush green
surroundings, splendid mountains, diverse flora & fauna, pristine backwaters, and the most fascinating
beaches. With over 104 km of vast coastline, six major rivers and various inland lakes the landscape of
Goa is very diverse, ranging from sandy seafronts to lush green hinterlands, from estuaries to mangrove
fringed creeks, from river islands to traditional Khazan lands. Goa’s rural landscape complimented by its
colonial heritage, gives the state an inherent cultural strength, making it an ideal destination for Caravan
Tourism.
Goa has recently developed the tourism master plan and policy, which focuses on reinventing itself as a
year-round responsible tourism destination. Also, as part of the strategy Goa also wishes to showcase its
pristine hinterlands, backwaters and rich biodiversity of the western ghats along with its already worldrenowned beaches. In order to explore new tourism products in the State and cater to the changing
preferences of the tourists/ visitors, Department of Tourism, Government of Goa is introducing “Caravan
Tourism Policy”. The concept of Caravan Tourism which gained popularity all over the world with its
nonintrusive mode of development will enhance the potential and attractiveness of Goa as a tourism
destination.
Caravan Tourism can effectively meet the growing demand, while ensuring adherence to quality,
standards, and safety norms. The Caravan Tourism Policy for Goa intends to provide fiscal & non-fiscal
assistance for the procurement/ development of Caravan Vehicles in the State.

3

OBJECTIVES OF THE POLICY

The Caravan Tourism Policy provides the flexibility with respect to itineraries and accommodations and
has the potential to add a new dimension to tourism in the State of Goa. This Policy is aimed to:







4

Introduce and regulate caravan tourism in Goa
Incentivize the tourism industry for introduction of caravan tourism in Goa
To provide an alternate experience to travel enthusiast
To promote tourism in remote areas of Goa, where there is shortage of decent and affordable
accommodations or where a permanent construction may neither be permissible nor feasible
Create job opportunities for local population
Promote the development of Caravans and Caravan Parks in Goa, away from the congested
beaches and traditional tourist Chokepoints. Yet, ensure that tourists have the best experience
at an affordable cost.

APPLICABILITY OF THE POLICY

The Caravan Tourism Policy is applicable to all existing and upcoming Caravans, Caravan parks and
Caravan operators in Goa.
I.
II.

All Caravans operating in Goa shall mandatorily be registered at a regional transport office (RTO) in
Goa.
Any kind of Caravan operations whether intra-state or inter-state shall be regulated by this policy.

The Caravan Tourism Policy is valid for a period of 3 years from the date of notification in the official
gazette and can be further extended as per the discretion of the Department of Tourism, Government of
Goa.
5

<!-- page 6 -->

5

THE TOURISM CARAVAN

I.

Registration of Tourism Caravan

As per “The Goa, Daman and Diu Registration of Tourist Trade Act, 1982 and Rules 1985” all entities or
individuals undertaking any kind of tourism service in Goa, shall be required to register with Department
of Tourism, Government of Goa. Therefore, the caravan operators shall be required to mandatorily
register all their Caravans (to be utilized for the purposes of tourism), with Department of Tourism,
Government of Goa to commence the commercial operations. The Department shall register only the
first 50 caravans. However, considering the holding capacity of the state and the demand for Caravan
tourism, the department reserves the right to increase the limit further.
Caravan should comply with Central Motor Vehicles Rules, issued by Ministry of Road Transport and
Highways, Government of India and the Automotive Industry Standards AIS-124/AIS-113 for Type
Approval and Certification of Caravans vehicles. Moreover, these caravan vehicles and standalone
caravan parks must have all necessary licenses/ NOCs/ from the relevant local authorities, as may be
applicable to ply in Goa. Such approvals shall include:
i.
S.No.

For Caravan vehicle operators:
Tentative List of NOCs / licenses /
approvals

Department
Department of Transport, (Govt. of
Goa)
Department of Tourism, (Govt. of
Goa)

Requirement

1.

Registration of Caravan Vehicle

2.

Registration of Caravan tour operator

ii.

For Standalone Caravan Park operators (The policy does not incentivize and promote
standalone caravan parks. Following tentative permissions shall be required, if private sector
wishes to develop such standalone parks. However, actual permissions may vary on specific case
basis) :

S.No.
1.
2.
3.
4.
5.
6.
7.

Tentative List of NOCs / licenses /
approvals
Trade License / NOC of the Gram
Panchayat/Municipal Council to run
the premises as Caravan park.
Electricity Department for Electrical
connection
Public works Department for water
connection
Goa coastal Zone Management
Authority for approval of plans

Bar License/ Excise license for sale of
foreign/ Indian liquor
Health NOC (for Septic tank / soak pit
etc.)

8.

Fire Safety NOC

9.

Pollution NOC

Requirement

Respective Municipal Council /
Village Panchayat

Mandatory

Electricity Department

Mandatory

Public Works Department

Mandatory

Department Of Excise
Health Department, Urban Health
Center / Primary health Center
Directorate Of Fire And Emergency
Services
Goa State Pollution Control Board
6

Mandatory

Department

Goa coastal Zone Management
Authority
Directorate of Food and Drugs
Administration

Foods and Drugs

Mandatory

If applicable
If applicable
If applicable
If applicable
If applicable
If applicable

<!-- page 7 -->

II.

Caravan specifications for registration
1. Mandatory Specifications for a Caravan
a. Caravan should comply with Central Motor Vehicles Rules, issued by Ministry of Road Transport
and Highways, Government of India or by the state transport commissioner and or the
Automotive Industry Standards AIS-124/AIS-113 for Type Approval and Certification, and shall
have a minimum of four wheels.
b. Caravan at the time of first registration with Goa Tourism with old chassis, should not be older
than 3 years
c. Sofa and bed for minimum two people.
d. Kitchenette with cooking facility,fridge, and microwave oven.
e. Toilet cubicle with hand shower and sufficient freshwater and waste-water storage.
f. 230V single phase internal power system with UPS and external plug point
g. Motorised Caravan Vehicle to be Bharat Stage VI compliant.
h. GPS: Caravan would enable themselves with GPS facility
i. Hygiene & Safety and Environment-Friendly Practices
j. Eco-Friendly Caravans shall be given preference.
2. Desirable Specifications for a Caravan
a. Air Condition
b. Audio/ Video Facility
c. Partition behind driver

III.

Registration Process
1. The applicant can apply for registration with Department of tourism, government of Goa:
a. Offline Mode: submitting the hardcopy of the requisite documents at, 1st floor,
registration desk, Paryatan Bhavan, Patto, Panajim, 403001
b. Online Mode:uploading and submitting the scanned copy of the requisite documents on
www.goaonline.gov.in
2. The Applicant shall be required to getthe caravan(s) registered with the regional transport office
in Goa and shall pay the applicable motor vehicle tax to Transport Department, Government of
Goa as per extant laws.
3. Post registration with Transport Department, the Applicant shall submit the following documents
for registration with the Department of Tourism, Government of Goa:
a. Registration Form as per Annexure-I
b. Annual Registration fee of INR 1000/- per caravan (the fee may be revised by Department
of Tourism, Government of Goa)
c. Registration Certificate (RC) by Transport department
d. Copy of Insurance certificate
e. KYC document (Aadhar card / Driving License / Passport / PAN Card)
4. Post applying for registration, the Department of Tourism, Government of Goa may conduct an
inspection of the respective tourism Caravan.
5. Applications that are incomplete in any respect or any deviation found during the inspection,
shall be liable to be summarily rejected by the department of tourism, Government of Goa.

IV.

Incentives by Government to attract caravan operators in Goa

FISCAL BENIFITS
1. Reimbursement of Capital investment made towards purchase / development of Caravan:
Department of Tourism, Government of Goa to encourage and promote the Caravan Tourism in
7

<!-- page 8 -->

the State of Goa will provide incentive opportunities. The incentive opportunities are as follows
(Second-hand motorized vehicles purchased and re-registered in Goa shall not be considered):





First 10 Caravans - Rs. 20.0 lakhs OR 25% of the total expenditure, whichever is lesser.
11th to 30th Caravans -Rs.10.00 lakhs OR 15% of the total expenditure, whichever is lesser.
31st to 50th Caravans -Rs.5.0 lakhs OR 10% of the total expenditure, whichever is lesser.

2. Reimbursement of Road Tax: Department of Tourism, Government of Goa shall reimburse the
motor vehicle tax of the caravans registered in Goa, in the following manner (Second-hand
motorized vehicles purchased and re-registered in Goa shall not be considered)





First 10 Caravans - 25% of the motor vehicle tax, up to a maximum of INR 1,57,500/- per
vehicle
11th to 30th Caravans -15% of the motor vehicle tax, up to a maximum of INR 94,500/- per
vehicle
31st to 50th Caravans - 10% of the motor vehicle tax, up to a maximum of INR 63,000/- per
vehicle

3. Reimbursement of Annual Registration Fee for 3 years: Department of Tourism, Government of
Goa shall reimburse the annual registration fee or INR 1000/- per annum, whichever is less, for
first 50 caravan vehicles for 3 years of commercial operation (annual registration fee shall be
reimbursed for 3 years of operation post successful submission of the annual fee, year on year).
The aforesaid reimbursements shall be disbursed on first-come-first-serve basis and those registering
first shall have an opportunity to complete 1 year of operations earlier and thereby becoming eligible
for claiming the incentives. Second-hand vehicles purchased and re-registered in Goa shall not be
considered for any kind of incentives and benefits.
Department of Tourism, Government of Goa, at its discretion and upon review of the extant situation
from time to time, may suitably alter the proposed limit of beneficiaries as specified in the aforesaid
clause 5.IV or extend the tenure of the policy or both, as the case may be, for the purposes of
promotion or furthering the objectives of this policy and depending on the extant rules, regulations
and market scenario.
OTHER BENIFITS
a. Job opportunities for the local community
Department of Tourism, Government of Goa through the policy encourages the participation of
the local community in Caravan tourism related activities by facilitating the following:





The local community shall brief the tourists about the local socio - cultural traditions of Goa
and thereby operators are encouraged to appoint local population.
Priority to be given to local youths for providing support services and products.
the operator shall tie-up with the local community for the experiences and engage local
work force for seamless introduction and operations of the caravans.
Capacity building of the local youths, artisans and craftsmen and appropriate skill
development trainings shall be imparted from time to time on need basis.

b. Promotion by Department of Tourism, Government of Goa
The Authority shall on best effort basis market the service through its website, various channels,
forums, establishments, outlets and related entities to try and secure success of caravan
tourism. This includes but is not limited to publicity for the service in its advertisements,
8

<!-- page 9 -->

website, printed material at travel marts and exhibitions attended by Goa Tourism. The
Department of Tourism may assist the operator in marketing and promotion activities across its
various channels depending on their annual marketing budgets.

V.

Eligibility of Caravans for availing incentives

The Caravans registered with Transport Department & Department of Tourism, Government of Goa shall
only be eligible for availing any incentive under this policy. Further the following clauses shall be adhered
by the applicant to be eligible for availing the incentives:
1. The caravan should be operational in Goa for at least 1 year from the date of registration with
Department of Tourism, Government of Goa.
2. The aforesaid incentives will be extended to a maximum of 10 (ten) caravans per entity/operator.
3. All vehicles for which reimbursement on motor vehicle tax is being claimed must have been
purchased during the operative period of this Policy and should comply with the Central Motor
Vehicles Rules, issued by Ministry of Road Transport and Highways, Government of India.

VI.

Procedure of availing incentives

The eligible applicants shall be required to apply for availing the incentive / reimbursement by
submitting the following hardcopy documents to Department of Tourism, Government of Goa:
a. Reimbursement of Capital investment made towards purchase / development of Caravan:
• Reimbursement form as per Annexure - II
• A CA certificate along with proofs and supporting documents of capital expenditure /
investment made on purchase / development of a Caravan
• Invoice of Caravan purchase (if applicable)
• Cancelled cheque
• Copy of registration certificate with Department of Tourism, Government of Goa
b. Reimbursement of Road Tax:
• Reimbursement form as per Annexure - II
• Cancelled cheque
• Copy of registration certificate with Department of Tourism, Government of Goa
• Receipt of the Road tax submitted to Transport Department of Goa
c. Reimbursement of Annual Registration Fee for 3 years:
• Reimbursement form as per Annexure - II
• Cancelled cheque
• Copy of registration certificate with Department of Tourism, Government of Goa (year on
year)
Department of Tourism, Government of Goa shall carry out the necessary scrutiny for all the
reimbursement forms received with respect to the Policy and may undertake inspection of the
caravan or enquire the applicant for any further clarifications.

VII.

Withdrawal of incentives:

Department of Tourism, Government of Goa reserves the right to withdraw the incentives or cancel the
registration, if the applicant is found to default/ violate/ breach any of the terms and conditions of the
Policy or any other violation as prohibited under prevailing laws.
The incentives provided to the applicant shall be forfeited and necessary action may be takenby the
Department.
9

<!-- page 10 -->

6

CARAVAN PARKS

As Caravan tourism is a new tourism product for the state, thereby Goa Tourism encourages the private
operators to tie-up with existing branded Hotels / resorts / guest houses / jungle lodges and develop caravan
parks in the premises of the accommodation unit (“hybrid caravan park”). The private operators can also
develop stand-alone caravan parks at scenic locations, post receiving adequate licenses & NOC (refer clause
5.I.ii of this policy) from extant government authorities (“standalone caravan park”).
For the below mention points related to Caravan Parks, Policy for Development and Promotion Caravan and
Caravan Camping Parks of Ministry of Tourism, Government of India shall be considered as guiding
document.
o
o
o
o
o
o

Operational Requirements of Caravan Parks:
Safety and Security
Site Development and Land Requirement
Movement and Parking
Tourist Facilitation Centre (TFC)
Waste Management infrastructure

10

<!-- page 11 -->

Government of Goa
Department of Tourism
2nd Floor, Paryatan Bhavan
Patto Plaza, Panaji,
Goa – 403 001
ANNEXURE I
(REGISTRATION FORM WITH DEPARTMENT OF TOURISM, GOVERNMENT OF GOA UNDER
CARAVAN TOURISM POLICY)
To,
The Director,
Department of Tourism
2nd Floor, Paryatan Bhavan, Patto Panaji, Goa - 403001

Sir,
I/We request that I/We may be registered as Caravan Tour Operator with Caravans within the meaning of
Goa Registration of Tourist Trade Act, 1982 for the year
, The other particulars are as under
New Registration Renewalin case of renewal, enter certificate no.
Renewal

for Years (Maximum renewal up to 5 years)

Operated by Individual
Company
If Company
Private Ltd.
Public Ltd.
1. Details of Person/ Company with Address intending to operate or is already operating as Caravan Tour
Operator
NAMEDESIGNATIONADDRESS-

VILLAGE/ TOWNTALUKAPIN CODE
MOBILE NO.
AADHAR CARD

,

TELEPHONE NO.
,
PAN CARD

EMAIL ID
2. Name of the firm and its registered address with Tel No.:
NAME OF THE FIRM
11

<!-- page 12 -->

ADDRESS OF THE FIRM
VILLAGE/ TOWN
TALUKA
WEBSITE
OFFICE NO.
EMAIL ID

PIN CODE
MOBILE NO.

3. Year of establishment of firm
4. Details of caravan
Number of Caravan in operation
The Caravan is:
a. New Caravan
b. Customized Caravan
Type of Body
Chassis No. (Affix Pencil Print)
Type of Vehicle
Maker’s Name
Month and Year of manufacturer
Maker’s classification or if not known, Wheelbase
Engine Number or Motor Number in case of Battery-Operated Vehicle
Fuel used in the engine
Unladen weight
Particulars of previous registration and registered number (if any)
Colour or colours of body wings and front end
HMV
LMV

_

For Office Use Only
Inward ID
Inward Date

Data Entry
Application Verified

Doc Uploaded

Declaration by Applicant
I/ We
hereby state that I have read and shall strictly abide
by the “Caravan Tourism Policy” governing the registration with Department of Tourism,
Government of Goa and all other orders relating to the registration as Caravan Tour Operator with
Caravan in Goa from Department of Tourism, Government of Goa time to time.
In case of default/ violation or breach of non- compliance by me to any of the terms and conditions
of the Act/ Rules/ Policy or any violation as are prohibited under prevailing laws, will lead to
immediate cancellation of the Registration/ License/ NOC and Fees would be forfeited to
Government treasury and necessary action would be taken up against me by the Department.
12

<!-- page 13 -->

Place:
Signature of the Applicant:
Designation of the Applicant:
Date:

13

<!-- page 14 -->

Government of Goa
Department of Tourism
2nd Floor, Paryatan Bhavan
Patto Plaza, Panaji,
Goa – 403 001
ANNEXURE II
(REIMBURSEMENT FORM FOR AVAILING INCENTIVES SUBSIDY UNDER CARAVAN
TOURISM POLICY)
Sr No.
1

Particulars
Reimbursement Form No.

Details
(As provided by Department of Tourism, Government of Goa)

2
3
4
5
6

Name of the Applicant
Authorized Person for the Applicant (if any)
Contact Number of the Applicant
Email ID of the Applicant
Full Address of the Applicant
Full Address of the Applicant
Details of the Caravan bought for tourism related activities during the operative period of the Policy for the
incentive as per clause 5. (iv)
(Note: Investment Subsidy shall be extended to a maximum of ten caravans per entity)
Class of
Date and
Purchase
Date and Place
Proposed
SI No. Registration
Number
Vehicle
Place of
Invoice
of Registration
Tourism
Purchase
Number
related
(Supporting
(Supporting
activity for
document to be
document to be
vehicle
enclosed)
enclosed)

7
8

9
SI No.

10
11
Note:
1.
2.
3.

Copy of Purchase Invoice and Registration Documents to be enclosed for each vehicle
Details of payment of Motor Vehicle Tax for vehicles listed in Sl. No. 8 –
Registration Class of
Date and
Purchase
Date and Place
Proposed
Number
Vehicle
Place of
Invoice Number
of Registration
Tourism
Purchase
related
(Supporting
(Supporting
activity for
document to be
document to be
vehicle
enclosed)
enclosed)

Total Amount paid as Motor Vehicle Tax for which
reimbursement is being claimed:
Other relevant information:

INR

All the supporting documents related to the details of particulars provided above should be enclosed.
All documents / authorizations / approvals / clearances / licenses / NOCs etc. should be in the name of the Applicant or the
Applicant Entity
The caravan vehicle details should be of a new purchased vehicle only. Second-hand vehicles initially registered outside Goa
and re-registered in Goa shall not be considered.

Declaration by Applicant
14

<!-- page 15 -->

(To be provided on letterhead of Applicant)
I/We
(full name) at present
(designation) M/s
hereby state that have been allocated the registration number
Government of Goa.

(name of Applicant)
by the Department of Tourism

I/we undertake that I/we intend to avail exemption on Caravan as per the provisions of Caravan Tourism
Policy, Department of Tourism, Government of Goa. The total amount of exemption sought under the
aforesaid is INR
.
I/we hereby undertake that the vehicles which receive exemption on Caravan shall be utilized only for
tourism related activities.
I/we certify that the information furnished with our application is true and correct to the best of my
knowledge and belief. I hereby undertake to abide by the terms and conditions prescribed under the
provisions of Caravan Tourism Policy.
I have read and understood all the terms and conditions mentioned in the Caravan Tourism Policy and
hereby agree to abide by them. I further confirm that I shall abide by the same and such other conditions as
may be laid down time to time by the Department of Tourism, Government of Goa under Caravan Tourism
Policy.

Signature(s)
Name & Designation
Seal of Applicant
Place:
Date

15
