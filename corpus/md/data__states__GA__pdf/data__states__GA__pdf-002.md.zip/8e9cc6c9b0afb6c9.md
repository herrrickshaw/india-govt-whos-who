---
doc_id: "8e9cc6c9b0afb6c9"
source_url: "https://ghb.goa.gov.in/notices/storage/2025/06/8-The-Goa-Housing-Board-Registration-Allotment-and-Sale-of-Tenements-First-Amendment-Rules-2016.pdf"
ministry: "Goa Housing Board"
title: "View Document   PDF 631 KB  →"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "1a78d8a2908cc3cf"
---

<!-- page 1 -->

OFFICIAL GAZETTE — GOVT. OF GOA
‘SERIES Noe eT NOR,
except the educational and other qualification _1. Short title and commencement.— (1) These
specified in rule 3 and 6 with respect to any rules may be called the Goa Housing Board
class or category of persons. (Registration, Allotment and Sale of
प a carne af the Govern Jenements) (First Amendment) Rules, 2016.
of Goa. (2 They shall come into force from the date

Srinet N. Kothwale, Director, ex officio Joint of their publication in the Official Gazette.
Secstery Bavioumeay: 2. Amendment of rule 6:— In rule 6 of the

Saligao, 21st November, 2016. Goa Housing Board (Registration, Allotment

and Sale of Tenements) Rules, 2016

——+44—_ (hereinafter referred to as the “principal

: Rules”), in sub-rule (/), the expression “and

Department of Housing also a resident of State of Goa for the last
= twenty five years” shall he omitted

NotiSestion: 3. Amendment of rule 13.— In rule 13 of the

2/59/2016/HSG/Part principal Rules, in sub-rule (9, in the proviso,

for the figures “10%” and “15%”, the figures

Whereas certain draft rules which the “2%" and “5%” shall be respectively
Government of Goa proposes te make so 2S subsiiiuied.
to amend the Goa Housing Board (Registration,

Allotment and Sale of Tenements) Rules, 2016 4, Amendment of rule 19.— In rule 19 of the
were pre-published as required by sub-section _ principal Rules, after sub-rule (/), the following
() of section 128 of the Goa Housing Board sub-rule shall be inserted, namely:—

Act, 1968 (Act No. 12 of 1968) (hereinafter

referred to as the “said Act”), under “(1A) where the Government is of the
Notification No. 2/59/2016/HSG/Part dated opinion that it is necessary or expedient
16-09-2016, published in the Official Gazette, _ so to do, it may, by order, for reasons to be
Series I No. 25, dated 22-09-2016 inviting recorded in writing, relax any of the
objections and suggestions from all persons _ provisions of these rules.”

likely to be affected thereby. before expiry of

fifteen days from the date of publication of By order and in the name of the Governor
the said Notification in the Official Gazette; of Goa.

‘And whereas, the said Official Gazette was 7 5. Sawant, Joint Secretary (Housing).
made available to the public on 22nd porvorim, 16th November, 2016.
Sepiember, 2016;

——¢¢o——_

And whereas, the objections and
suggestions received from the public on the Department Public Works
said draft rules have been considered by the a = : E
Conciente fice of the Principal Chief Engineer

Now, therefore, in exercise of the powers Order
conferred by sub-sections (1) and (2) of section
128 read with section 58 of the Goa Housing 37/7/2016/PCE-PWD-ADM (I1)/177
Board Act, 1968 (Act No. 12 of 1968), and all
other powers enabling it in this behalf, the Approval of the Government is hereby
Government of Goa hereby makes the accorded for the revival of 9 posts of Junior
following rules, namely:— Stenographer, Group “C”, Non-Gazetted in

1347
