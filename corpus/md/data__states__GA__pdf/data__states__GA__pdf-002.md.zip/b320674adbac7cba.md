---
doc_id: "b320674adbac7cba"
source_url: "https://webassets.unigoa.ac.in/uploads/pocket/tender-document_15420261030.155153.pdf"
ministry: "Goa University, Goa"
title: "Tender Document"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f4b71291680ae3bf"
---

<!-- page 1 -->

Goa University invites quotations (through e-tender mode only) for supply of
High Performance Audio/Video Workstation and Accessories from eligible
suppliers and manufacturers under a two-bid system comprising a Technical Bid
and a Financial Bid.
Interested suppliers/parties are requested to visit https://eprocure.goa.gov.in to
participate in the tender/bidding process. The detailed Tender Notice is provided
below.

<!-- page 2 -->

GU/DDLI/Cam/17144/26-27/13

Date: 29/10/2026
TENDER DOCUMENT
(E-Tendering mode only)

Supply of High Performance Audio/Video Workstation and Accessories
Goa University invites quotations (e- tender mode only) for the items detailed below.
Interested bidders may apply through e-tender process only.

Sr.
No.

Name of the item

Qty.
Earnest Money Tender Processing fee
in nos.
deposit
Non- Refundable
Mode of payment: E-Payment only

1 High Performance Audio/Video
Workstation

01

2 Monitor for above Workstation

01

Wireless Keyboard for above
Workstation

01

3

4 Wireless Mouse for above Workstation
5

₹ 14,000.00

₹3,000.00

01

USB-C Hub Docking Station with
01
integrated M.2 NVMe SSD Enclosure
Detailed specifications are given at Annexure- I
Tender Schedule

1. The last date of online submission of tender is 19/11/2026 up to 12:00 hrs.
2. The date and time of online opening of Technical Bid is 20/11/2026 after 10:00 hrs.
3. Price Bid will be opened after completion of administrative and technical
procedure.
Mode of Payment towards e-Tender Processing Fee (TPF) & Earnest
Money Deposit (EMD) to be paid online through e-Payment mode via:

1) National Electronic Fund Transfer (NEFT) / Real-Time Gross Settlement (RTGS).
1

<!-- page 3 -->

Tenderer requires downloading the pre-printed Challan on e-tender website and
making its payment through any of their Bank.
Note: Any Payments made through NEFT/RTGS will take 24 hours for its
reconciliation. Hence the payments through NEFT/RTGS should be made at least
TWO BANK WORKING DAYS in advance before any due date.

2) Net Banking: Payment can be made through the Internet Banking of Any Bank.
Important Notes to the Bidder:
1. The duly constituted committee appointed by the competent authority of Goa
University reserves the right to select certain items (in single or multiple units) or reject
any or all mentioned in the schedule.
2. The Bid shall be treated as a 2 Bid System. The Technical Bid will be considered only
for applicants whose Earnest Money Deposit (EMD) is found in order. Price Bid shall
be opened for only those bidders who have qualified in Technical Evaluation.
3. For technical related queries, may contact Directorate for Digital Learning and
Initiatives (DDLI) on phone no. 8669609039/40 and email - ddli@unigoa.ac.in. For
other queries may contact Purchase Section on phone nos. 8669609072/24.
4. The Vendor should clearly state the make/brand, model and the year of manufacturing
of the items proposed to be supplied in response to the tender.
5. Vendor shall enclose the list of accessories to be provided with the equipment in the
Technical bid.
6. Bidders seeking exemption from payment of EMD under MSME scheme must ensure
that their company/organisation is registered with the Directorate of Industries, Trade
and Commerce (DITC), Goa, in accordance with the provisions of Notification No.
3/40/2003-IND(Pt.II)(Vol.III)/132 issued by the Department of Industries, and
published in the Official Gazette of Goa, Series I No. 13, dated 30/06/2022, under the
Preferential Purchase Incentives for Micro, Small and Medium (MSME) Enterprises
Scheme, 2022.
7. For assistance on e-Tender please contact Support Helpdesk- 91-7972854213, 917822039673, 91-7972871944 Email: e-tender.goa@gov.in

Sd/(Prof. Sunder N. Dhuri)
REGISTRAR
2

<!-- page 4 -->

TERMS AND CONDITIONS OF THE TENDER:
1)

Price /Taxes:
Prices stated in this tender are firm and shall remain firm until required deliveries
have been completed unless otherwise expressly agreed to, in writing by both
parties.

2)

Delivery:
The equipment should be delivered to Goa University within 30 days of placing of
order & installation be completed within next 15 days. If any material is not
delivered by the date specified therein, the University reserves the right, without
liability, to cancel the order for undelivered material not yet supplied and to
purchase the same from another vendor and to charge the defaulting Vendor for any
loss incurred in this transaction. Any provisions thereof for delivery by instalment
shall not be construed as obligatory unless agreed upon by both the parties.

3)

Reproduction of Documentation:
The University shall have the right at no additional charge to use or incorporate all
or portions of material found in the Vendor's literature and/or reproduce the
Vendor's applicable literature such as operating and maintenance manuals, technical
publications, prints, drawings, training manuals and other similar supporting
documentation and sales literature.

4)

Shipping, Packaging and Labelling:
All Material purchased hereunder must be packed and packaged to ensure its safe
delivery in accordance with good commercial practices. It shall be the sole
responsibility of the vender to provide/replace the item/goods, if it is lost or broken
during the shipping or transportation due to whatever may be the reason. Vendor is
responsible to ensure, by contacting the University, that the shipping has been
properly done i.e., all the items/goods have properly reached the University.

5)

A) Terms of Payment and Conditions:
i) For Indigenous/Indian equipment/stores on DDP Destination basis: -100%
of the total payment shall be released on submission of proof of delivery and on
certification of satisfactory installation of the equipment at the University
premises.
ii) For Foreign Equipment on CIP GOA: If preferred mode is Letter of
Credit (LC), the payment will be through Bank on receipt of documents. In
case of credit payment, 100% will be made by Telegraphic Transfer (TT)
after receipt and successful installation/demonstration of the equipment.
3

<!-- page 5 -->

B) Price Fall Clause: If at any time prior to delivery of the equipments/stores, the bidder/supplier reduces
the sale price of such equipments/stores as covered under this tender enquiry, to any
organisation (including Central/State/Deemed university) at price lower than the
price quoted under this contract, he shall forthwith reduce the price payable under
this tender for the equipments/stores being supplied after the date of coming into
force of such reduction, the price of equipments/stores shall stand correspondingly
reduced.
6)

SPECIFICATIONS:
i) Specifications are the basic essence of the item/contract. It must be ensured that
the offers strictly adhere to our specifications. A tender has to be supported with
the printed technical leaflet/literature of the quoted model of the item.
ii) In case of authorised dealers/distributor certificate in prescribed format from
Original Equipment Manufacturers (OEM), on the same should be enclosed for
participation in the said tender.
iii) It is only when the information about the company/Goods in quotation in
technical bid is found satisfactory; the commercial part will be opened.

7)

Price Bid:
a) The Cost of the equipment should be inclusive of all taxes and statutory levies.
Labour/installation charges, packing, insurance, freight etc. should be
mentioned separately (inclusive of all taxes leviable on them). For
imported/indigenous goods price to be quoted FOR Goa University. Unit price
of each product and accessories should be quoted separately.

b) In case of receipt of the material in short supply or damaged condition the
supplier will have to arrange the supplies/ replacement of goods free of cost
pending the settlement of the insurance case wherever applicable on FOR at the
University or CIF basis for satisfactory installation of the system.
c) No commitment to accept lowest or any bid: University shall be under no
obligation to accept the lowest or any other offer received in response to this
tender notice and shall be entitled to reject any or all offers including those
received late or incomplete offers, without assigning any reason what so ever.
University reserves the right to make any changes in the terms and conditions of
the bid. University will not be obliged to meet and have discussion with any
vendor and or to listen to any representations.
d) Short listing of Vendors: University will create a shortlist of technically
qualifying vendors and the financial bid of only these vendors will be opened.
University reserves the right to decide whether the items being quoted are as per
the requirement of the University and are of standard/leading brands in the
4

<!-- page 6 -->

market. University reserves the right to decide which offer best suits the
requirement of the University.

e) Installation and Commissioning: Free of cost at University. The OEM must
ensure timely installation of the complete unit with necessary support to the
indenters.
f) Conditional Offer will not be accepted and technical/financial bids in such cases
may be rejected.
g) Past Performance of the Vendors will be judged at the time of Technical
Evaluation.
h) All items proposed to be supplied should be of recent manufacture, preferably
manufactured in the last three months, and not exceeding six months.
8)

Insurance: In case of item requiring import kindly note the following:
a) Please quote CIP value for clearance up to Dabolim Airport, Goa, India.

b) Item must be insured from warehouse of manufacturer to warehouse of Goa
University, Taleigao, Plateau, Goa, India.
c) Vendors are advised to declare the commission if any, so that the same shall be
paid to the party in Indian currency after successful installation/demonstration of
the equipment.
9)

Rejection of Bids:
a) If bidders give wrong information in their bid, University reserves the right to
reject such bids at any stage and forfeit the Earnest Money Deposit /
Performance Bank Guarantee and cancel the order, if awarded.

b) Incomplete bids are liable to be rejected.
c) If the technical offer contains any price information, the offer is liable to be
rejected.
All annexures to the tender document should be duly stamped and signed by the
bidder and submitted along with the tender bid.
d) The bidder shall provide a self-attested certificate stating that, they have not been
disqualified/debarred from submission of tender/quotation under Rule
151 of GFR 2017 by any Government/Ministry/any organisation like
University etc. who is funded by State or Central Government.

5

<!-- page 7 -->

10) Warranty:
Refer Annexure-I for warranty. Statement of warranty of goods against any
manufacturing defects and also give the warranty declaration that everything to be
supplied by us hereunder shall be free from all defects and faults in material,
workmanship, transportation hazards, and shall be of the highest quality and
material of the type ordered, shall be in full conformity with the specifications.
During the warranty period, replacement of any part of equipment’s or rectification
of defects of works will be free of cost.
11) Performance Security:
(a) The successful bidder who has been awarded the contract shall submit a
performance security of 5% of the Contract Value.
(b) The performance security shall be deducted from the invoice payable.
(c) The Performance security shall be returned to the bidder within 60 days after
completion of contractual obligations and warranty period.
12) Consumables/spares: All hardware & software including drivers, device interface
cards/network adaptor card must be pre-configured in the computer equipment
provided. Licensed version of system software should be provided in CD (with up
gradable version). Manual Hard copies of instruction/operation/service manuals
should be supplied. List of important Consumables/ Spares and parts having
sufficient shelf life for trouble free operation of four years should also be provided.
13) Training/installation:
a) Installation testing: suppliers of the instrument must provide free installation,
commissioning and testing of the equipment in the laboratory at the current
temporary site and thereafter at permanent site.

b) Comprehensive training of faculty & staff after installation should be provided,
wherever deemed appropriate and an update in every six months (3-4 days) for the
first two years and every year (1 week) for the next three years.
14) A.M.C.: A separate annual maintenance contract may be executed after completion
of the warranty period.
15) Law of the Contract: The agreement entered with vendor shall be governed by and
interpreted in accordance with the laws in existence and within the Jurisdiction of
the court of Panaji, Goa.
16) Site preparation:
The supplier shall inform the University about the site preparation, if any, needed
for installation, along with the technical bid. Suppliers must provide complete
details regarding space and all infrastructural requirements needed for the
equipment, which University should arrange before the arrival of equipment to
ensure its early installation and smooth operation thereafter. The supplier may offer
6

<!-- page 8 -->

his advice and render assistance to University in the preparation of the site and other
pre-installation requirements.
17)

The successful bidder has to communicate the acceptance of the purchase order
within five days of the receipt of the order.
18) The quantity of items in the tender form may increase or decrease as per
requirement.
19)

Vendors may quote all/Any Items.

Certified that:
I/We have read all the enclosed Terms and Conditions carefully and ready to
accept and according to that I/We are submitting herewith the tender.

Date:

Seal & Signature of Vendor

7

<!-- page 9 -->

TECHNICAL BID FORM

I.

II.

Addressed to:
a.
b.

Name of the Bidding authority
Address

c.

Telephone

Registrar, Goa University
Goa University,
Taleigao Plateau, Goa
– 403 206
8669609072/24

Other related details:
1.
2.
3.
4.

Name of Bidder/Party
Name & Designation of
Authorised Signatory
Year of Establishment
Type of Firm

Put Tick ( √ ) mark
5. Telephone Number (s)/
Mobile
6. Website URL
7. Fax No.
8. Email Address
9. GST number and
validity
10. Pan card number
11. Registered Office
Address in Goa

12. Service Centre (s) in
Goa

Public
Ltd.

Private Ltd. Partnership

Proprietary

Address

Phone
Contact
Person
Address

Fax:

Phone
Fax:
Contact
Person
(Enclose list of Service Centre consisting name of contact person, telephone
number, e-mail address, office address.)
8

<!-- page 10 -->

III. Clientele list: List of the institutes/organisations, where the similar order has
been executed during the last three years, and work done list should be
enclosed.
IV. The rates quoted are applicable up to 3 months from the date of opening of
bid. The validity period can be extended with mutual agreement. Following
documents are attached towards the proof of earnest money deposited in
favour of ITG.
Sr.
No.
1.

V.

Earnest Money
deposited through
E-payment mode

Number

Dated

We agree to abide by all the conditions mentioned in this Bid Document issued
by the Bidding Authority.

Signature:
Name:
Designation:
Place:
Date:
Note: If the Technical offer contains any price information, the offer is liable to be
rejected.

9

<!-- page 11 -->

ANNEXURE – I

SR.
NO.

ITEM

1

High
Performance
Audio/Video
Workstation

SPECIFICATION

1) Architecture : System on a Chip (SoC) architecture

2)

CPU : Minimum 30 core

3) GPU : Minimum 64 core with hardware-accelerated ray tracing.
4)

AI Engine : Dedicated neural processing unit
(minimum 32 cores)

5)

Media Engine : Hardware acceleration for video
encoding/decoding (H.264,
HEVC, ProRes, and ProRes RAW).

6)

System Memory (RAM) :
● Minimum 96 GB of high-bandwidth unified memory.
● Minimum memory bandwidth of 1.2 TB/s to ensure zero
bottlenecking during 4K/8K multi-stream video playback.

7)

Internal Storage :
● Minimum 1 TB integrated Solid State Drive (SSD)

8)

Connectivity and Ports :
● Minimum six Thunderbolt 5 (USB‑C) ports with support for:
Thunderbolt 5 (up to 120 Gbps), USB 4 (up to 120
Gbps), USB 3 (up to 10 Gbps), DisplayPort 2.1
● Minimum Two USB 3 (USB‑A) ports (up to 5 Gbps)
● One or more HDMI 2.1 port (supporting up to 8K @ 60Hz or 4K
@ 240Hz)
● One or more 10Gb Ethernet port (RJ-45)
● One or more 3.5 mm headphone jack
● One or more SDXC card slot (UHS-II)
● Wi-Fi 7 or newer
● Bluetooth 6 or newer.

9)

Display Support :
● Must support a minimum of up to Six simultaneous displays

10) Operating System :
● Vendor to Specify
● Optimized support for industry-leading digital audio
workstations (DAWs) and NLE software.
10

QTY.

1

<!-- page 12 -->

11) Warranty :
● Manufacturer's standard warranty (Vendor to specify duration)

2

Monitor for
above
Workstation

1)

Display Size : 27 inch or higher

2)

Panel Type : IPS

3)

Backlight Technology : LED Backlight

4)

Resolution : 3840 x 2160 or higher

5)

Brightness (Typical) : 350 nits or higher

6)

HDR : Yes, HDR 10, Vesa Display HDR 400

7)

Viewing angle (H/V) : 1780/1780 or better

8)

Response time (GtG) : 5 ms or less

9)

Refresh Rate (Hz) : 60 Hz or higher

10) Contrast Ratio : 1200:1 or better
11) Colour Gamut : 100% sRGB, 100% Rec.709, 95% P3
12) Colour Space : DCI P3
13) Colour Mode : Support for Mac, DCI-P3, Display P3, Rec.709,
sRGB, HDR
14) Aspect Ratio : 16:9
15) Display Colours : 1.07 billion colours
16) PPI : 163 or better
17) Matte Display screen coating
18) Colour Temp. : 5000K, 6500K, 9300K, User Define
19) Gamma : 1.8 - 2.6, sRGB
20) Aspect Ratio : 16:9

11

1

<!-- page 13 -->

21) Factory Calibrated with Delta E < 3
22) HDCP 2.2
23) Built in 2.5W x 2 Speakers
24) Built in Headphone out
25) Vesa wall mount support
26) Articulating Ergonomic Stand (Height, Tilt, Swivel, Pivot)
27) Connectivity (Minimum) :
1 x HDMI 2.0, 1 x Display Port (1.4),
1 x USB C(PowerDelivery 90W, DisplayPort Alt Mode, Data),

1 x USB C ( Downstream ), 1 x USB Type B ( Upstream ),
3 x USB 3.2 ( Downstream),

28) Certification : TUV Certificate, Calman Verified, Pantone and
Pontone SkinTone validated
29) Built-in KVM Switch, Picture-in-Picture (PIP), Picture-by-Picture (PBP)
30) Warranty :
● Manufacturer's standard warranty (Vendor to specify duration)
3

Wireless
Keyboard for
above
Workstation

1)

Form factor : Full-size keyboard layout including an integrated

1

numeric keypad and standard function row.

2)

Wireless Connectivity: Dual wireless connectivity supporting both
Bluetooth Low Energy and a secure 2.4 GHz
USB Type-A wireless receiver.

3)

Multi-Device Pairing: Capability to pair with up to 3 separate devices
simultaneously, with dedicated hardware keys
to seamlessly switch between them.

4)

Auto-adjusting LED backlighting featuring hand-proximity sensors

5)

Form factor : Full-size keyboard layout including an integrated
numeric keypad and standard function row.

4

Wireless Mouse

6)

Built-in rechargeable Li-Po battery via USB-C port. Must support
minimum 10 days of battery life with backlighting enabled

7)

Multi-OS support including Windows, macOS

8)

Support for Keyboard customization app

9)

Warranty :
● Manufacturer's standard warranty (Vendor to specify duration)

1)

Advanced optical tracking sensor with a resolution of 1000 DPI or more

12

1

<!-- page 14 -->

for above
Workstation

5

USB-C Hub
Docking Station
with integrated
M.2 NVMe SSD
Enclosure

2)

3 buttons (Left-click, Right-click, and Middle-click/Scroll Wheel)

3)

Engineered for quiet (Silent) operation

4)

2.4 GHz wireless connection via a USB Type-A receiver, ensuring a stable
connection with a range of 10 meters or more

5)

Powered by 1x AA battery

6)

Universal plug-and-play compatibility across Windows and macOS

7)

Warranty :
● Manufacturer's standard warranty (Vendor to specify duration)

1)

Host Connection : 1 x USB Type-C upstream port

2)

1 x Built-in M.2 NVMe SSD slot supporting M.2 NVMe solid-state drives (M
Key / B+M Key) in 2230, 2242, 2260, and 2280 form factors

3)

1 x HDMI 2.0 port supporting external display resolutions up to 4K Ultra HD at
60Hz

4)

1 x USB-C PD Input port supporting up to 100W power input, capable of
delivering up to 85W of pass-through charging to the host device

5)

1 x USB-C port and 1x USB-A port operating on the USB 3.2 Gen 2 standard,
supporting data transfer speeds up to 10Gbps.

6)

2 x USB-A ports supporting data transfer speeds up to 5Gbps.

7)

1 x RJ45 Gigabit Ethernet port supporting 10/100/1000 Mbps wired network
connections.

8)

1 x SD Card slot and 1x TF (MicroSD) Card slot, supporting read/write speeds
up to 170MB/s (SD 3.0 standard).

9)

Universal Plug-and-Play operation (no drivers required) across Windows and
macOS.

1

10) Warranty :
● Manufacturer's standard warranty (Vendor to specify duration)

 Make, Model and year of manufacture of the item quoted shall be specified.
 “Service and Support Facility in Goa: The bidder shall either have its own
service/support centre in the State of Goa or have a formal arrangement with an
authorised service provider for providing service and support within Goa. The
bidder shall submit a letter/certificate specifying the details of its service/support
centre or the collaborating service provider in Goa, along with the bid.”

13
