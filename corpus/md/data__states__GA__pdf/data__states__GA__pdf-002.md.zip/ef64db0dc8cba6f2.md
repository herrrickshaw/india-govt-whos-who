---
doc_id: "ef64db0dc8cba6f2"
source_url: "https://gazetteer.goa.gov.in/wp-content/uploads/2026/07/13.Recipients-of-Concessions-permits-or-authorization.pdf"
ministry: "Gazetteer Department, Goa"
title: "Click Here"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "78d87ec3fb012d77"
---

<!-- page 1 -->

Manual - XIII
Particulars of Recipients of Concessions, permits or authorization
Granted by it
[Section 4 (b) (xiii)]

NOT APPLICABLE

Updated as on 31/3/26
