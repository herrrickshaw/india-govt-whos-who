---
doc_id: "e51ddad0e02a79bf"
source_url: "https://forest.goa.gov.in/sites/default/files/2024-01/Notification%20regarding%20Tree%20Felling%20Fees.pdf"
ministry: "Forest Department, Goa"
title: "Notification regarding Tree Felling Fees"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "39f09ffa5ed8ce3a"
---

<!-- page 1 -->

oe Se __
ab t AS i Othex af the Bee ण
78 “कै, , रन]
ee ®, eee |
2७7२० य {Bo कटी
Government of Goa | Date Ah M24 r@22,
Forest Department neem aon
Secretariat, Porvorim — 403 521
Tel Nos: (0832) 2419443/2419792/2419697_ e-mail: usforest-sect.goa@nic.in Nos: (0832) 2419443/2419792/2419697 e-mail: No. 7207023-FOR [33 ated ळी
No. 7/2/2023-FOR [33 Dated:- 22/12/2023
NOTIFICATION
In exercise of the powers conferred by section 36 read with sub-section (5)
of section 9 of the Goa Preservation of Trees Act, 1984 (Act No.6 of 1984), the
Government of Goa hereby makes the following rules so as to further amend the
Goa, Daman and Diu Preservation of Trees Rules, 1983, namely :-
1, Short, title and commencement.- (1) These rules may be called the Goa
Preservation of Trees (Third Amendment) Rules, 2023.
(2) They shall come into force on the date of their publication in the Official
Gazette.
2. Amendment of rule 6A.- In rule 6A of the Goa, Daman and Diu
Preservation of Trees Rules, 1983, for clause (a), the following clause shall
be substituted, namely :-
“(a) Tree felling fee %1,000/- per tree.”. ~
|| By Order and in the name of
“a the Governor of Goa
OW,
ye te
x? MG (2) — & ०-५
पि (Nathine S. Araujo)
Af; Under Secretary(Forest)
5 We
gq 10 Aw
The Director, Printing and Stationery, Government Printing Press, Panaji, Goa for
J publication in the Official Gazette.
>” Copy to: -_
* The Principal Chief Conservator of Forests, Goa Forest Department, Altinho,
Panaji — Goa.
od KC 2. The Conservator of Forest(Conservation), Office of the Principal Chief
ee 3S Conservator of Forests, Goa Forest Department, Altinho, Panaji - Goa.
oN 3. The Director of Accounts, Panaji — Goa.
ले N 4. All the Deputy Conservator of Forests... through the Office of the Principal Chief
Conservator of Forests.
5. Guard file.
6. Ofc:
Nae ul
a श्रे
