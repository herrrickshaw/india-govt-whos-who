---
doc_id: "8df8ec26262dffbc"
source_url: "https://fisheries.goa.gov.in/wp-content/uploads/2024/01/11.-Goa-Marine-Fishing-Regulation-Fourth-Amendment-Rules-2014.pdf"
ministry: "Fisheries Department, Goa"
title: "गोवा सागरी मासेमारी नियमन (चौथी दुरुस्ती) नियम, (2014)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "46a18132a19a5ed8"
---

<!-- page 1 -->

Reg. No. GR/RNP/GOA/32

RNI No. cOAxNG/2002l6410

Panaji, 1Oth February, 20_11 Nagha 21, 1935)

SERIES I No. 45

ffi

OTFICIAL-W.fi GAT.,ETTE
GOVERNMENT OF GOA
PUBLISHED BY AUTHORITY

EXTRAORDINARY
No. 2
9OVERNMENT OE GO4
Department of Fisheries

(ri) against serial number (2), in column
(3), for the letters and figures ,,Rs. 300/_",
the letters and figures "Rs. 600/-,' shall be
substituted;

Notification

(ru) against serial number (3), in column
(3), for the letters and figures ,,Rs. 100/_",
the letters and figures ,,Rs. 200/-" shall be

DF/ENF/ICSRDS GOW86

qt rhqtitr

In exercise of the powers conferred by
section 28 of the Goa, Daman and Diu Marine
Fishing Regulation Act, 1980 (3 of 19g1), the

Government of Goa hereby makes the
following rules so as to further amend the
Goa, Daman and Diu Marine Fishino
Regulation Rules, 1982, namely:1. Short title and commencement._ (1)
Jh-ese rules may be calledrthe Goa Marine
Fishing Regulation (Third Amendment) Rules,
2014.

(2) They shall come into force at once.
2. Amendment of rule 3.- In rule 3 of the

Goa, Daman and Diu Marine Fishing

Regulation Rules, 1982 (hereinafter referred
to as the "principal Rules"), in sub_rule (1),
in the table,-

(i) againsr seriai number (l), in column
(3), for the letters and figure ,,Rs. 500/_',,
the letters and figures ,,Rs. 1000/_" shall
be substituted;

rf orl.

(iv) against serial number (4), in column

(3), for the letters and figures

"Rs. 50/-", the letters and figrr-ues ,,Rs. 200/-"
shall be substituted;

3. Substitution of rule 6.- For rule 6 of the
principal Rules, the following rule shall be
substituted, namely:-

6. Registration of yessel.- (1) Every
application for registration of a vessel under
sub-section (2) of section 12 shall be made
in Form E hereto.
(2) Every application under sub-rule (1)
shall be accompanied with the fees as
specified in the table beiow namelv._
TABLE
No.

Class of Fishing Vessel

Fees

(1)

(2)

(3)

(i) Mechanical fishing vessels fitted

with an engine having horse

Rs. 3,000/-

power exceeding b0 Hp
151 1

<!-- page 2 -->

OFFICIAL GAZETTE _ GOVT. OF GOA

SEF/ES I No. 45
(1)

(EXTRAORDINARy No. 2)
(2)

(3)

(ii) Mechanised fishing vessels fitted Rs. 1,000/with an engine having horse
power not exeeeding 50 Hp

(iii)Non-Mechanisedfishingvessels Rs.400/-

(7) The authorized officer shall, after
making such inguiry as he deems fit, issue a
registration certificate in Form F.
(2) The authorized officer shall maintain a
register in Form G in respect of all vessels
registered under this rule.
(3) Every vessel regiistered under this rule
shall display the registration nurnber allotted
to it by the authorized of6.cer on both sides of
the bow and aft side of the vessel.

(4) Every application for transfer of
registration of fishing vessel shall be
accompanied with the fees as specified in

the table below, namely;-

|OTH FEBRUARY 2014

(5) Every application for issue of duplicate

registration certificate shall be supported with
the copy of FIR from the Police in case of loss
of registration certificate and the mutilated
registration certificate in case of damage of
the registration certificate and shall be
accompanied with fees of Rs. 300/-.
(6) Every vessel registered under this rule
which is venturing into the sea for fishing
shall adopt the color code assigned to the
State of Goa and possess,-

(a) the photo identity cards of alt the
crew members as issued by the Director of
Fisheries;

(b) fishing vessel licence issued under
sub-rule (3) of rule 3 of these Rules:

(c) fishing net licence issued under
sub-rule (2) of. rule 4 of these Rules:

(d) certificate of,registration of fishing
vessel issued under sub-rule (3) of rule 6

TABLE
No.

Class of Fishing Vessel

Fees

(1)

(2)

(3)

of these Rules; and

(e) sufficient number of the safety

(i) Mechanical fishing vessels fitted Rs. 1,000/having HP exceedingr 50 Hp

equipments like "Iife jackets, life bouys".

(ii) Mechanised fishing vessels having Rs.500/HP not exceeding 50 Hp

Dr. Smt. Shamila Monteiro, Director-cum-ex officio Joint Secretary (Fisheries).

(iii) Non-Mechanised fishing vessel

Rs.200/-

Panaji, LOth February, 2014.

www. goaprintingpress. gov. in
Published and Pdnted by the Director, printing & Station€ry,
Government Printing press,
Mahatma candhi Road, panaji-Goa 403 00I.

Price-Rs. 2.00
PRINTED AT GOVERNMENT PRINTING PRESS, PANAJI-GOA 342/380-2/2014.
LC tZ
