---
doc_id: "d5c1e21aae2c3a7b"
source_url: "https://dmg.goa.gov.in/PDFs/Notifications/green-tax-sanction-order/Green-Tax-Sanction-order-8.pdf"
ministry: "Directorate of Mines and Geology, Goa"
title: "Sanction Order 8 dated 30/06/2025"
date: ""
pages: 6
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "3650015cd7b003c7"
---

<!-- page 1 -->

| | | | i -
. | ल |
पदक
- - en oe
र Government of Goa न
Directorate of Mines Geology |
| | Institute Menezes Braganza, Panaji-Goa .
Website:dmg.goa.gov.in e-mail:dir-mine.goa@nic.in oo
No.03/01/2023/Technical/Mines/Part-! /(७०% Date: 20/06/2025
ORDER |
| Sanction is hereby accorded to incur an expenditure of %’32,17,87 5/- (Thirty
Two Lakh Seventeen Thousand Eight Hundred and Seventy Five only) for
making payment as reimbursement of Green-Tax and Fitness Fee to the
following mining affected truck owners under the scheme “Reimbursement of
Green Tax and Fitness Fees to the mining allected truck ownets पपप पी the mining affected truck owners scheme 2023”
वि notified in the official gazette series 1 No. 46 dated 16 February, 2023 and
7 further extended vide Notification no. 03/01/2023/Technical/ Mines / Part-
| - 1/1197 dated 22/07/2024.
_ | No Owner name nO. Eligible amount (%)
Ashok © Gavwas |
|
|
GA09U0788
| 0409011779 | 18400.00
| 6 | GA04T1929. 18100.00 |
| Amir H Shaikh | |
8 | AmitGawas _|___(7801 15535 18400.00
र 18725.00
0७075
| Gaoiu76ss छळ00 |
|
| ळण 110750
| Babuso R. Gawas 27325.00
| 18400.00
1790.00 |
a 24775.00
—~caoiu2sss | 1840000]
. Deepak Kothambikar 18400.00
| (|| - Page 1 of 6 |

<!-- page 2 -->

ee का कक
_ Sr T .
|
|
oe
a
GA09U0089
|
|
|
न
|
|
Mascarenhas
|
|
|
न
|
|
.
-
60 |
|
|
| 66 |
(i
a Page 2 of 6
OO श््ाग्क्ग््ग्गययययय. .आयााकाकााकााारवााााााााशााााााशाशा

<!-- page 3 -->

|
/_GA02TT347
Fes | Maya SNaik
| 69
| GA02T7318
Molu Gaonkar 690995 [37750
|
7 Navlo G. Zore
|
|
Prakash Naik
|
क
क 0900955 |
क
| 1857500
Fas [7 Ramesh VShet | _GA01U2720_
[|
न
| 00७७७७७
| 60०
|
(96 | _Roshan$ Chari | GAO4TI2N1
- Rupesh Malik
p98 | SacruGawli __|
(99 |
-
| 08010७5242 _|
0890७79002
|
|
|
. शं _ Page 3 of 6

<!-- page 4 -->

r T , 1.
| |
|
|
|
|
|
1282558
|
Parsekar |
-
7
|
|
|
|
|
_ गुट्वाणणजारवा'
|
|
| Vishnu R एक
|
|
|
-
Cf gi Page 4 of 6

<!-- page 5 -->

- Sr Truck Registration गारा न
न No Owner name no ligible amount (%) |
| Vinayak N. Samant | GAO4T1121_ | 18400.00
Mainudi GA04T147
| 155 Xec Mainucin A04T1479 36475.00
Mamolecar :
| fora | 827.875.00
The expenditure shall be debited to the Budget Head 2853 - Non- Ferrous
_ Mining and Metallurgical Industries; 02 — Regulation and Development of
Mines; 001 — Direction and Administration; O07 — Reimbursement of Green Tax
and Fitness Fee Scheme; 00- General; 33 - Subsidies under Demand Number
| 83. | न
. This issue with the Administrative approval of the Government vide U.O.
| No. 8294/F dated 20/01/2025 and concurrence of Finance (Expenditure) _
Department vide FMS No. 1400093941 dated 05/02/2025 for Financial Year
__ 2025-26. _ |
| - The above beneficiaries are from all over the State of Goa who had applied to
१ the benefit under the scheme by making an online application on the portal
and as such, it is not possible to obtain the pre-receipt from each one of them.
Hence obtaining of pre-receipts have been exempted from the claimants.
a By Order and in the name of ©
| . | the “(hs of Goa
(Narayan M. Gad)
Director &
Ex-officio Joint Secretary (Mines)
. न Page 5 of 6

<!-- page 6 -->

° To, | | |
| न 1. All the beneficiaries. |
_2-Accounts Section, Directorate of Mines &, Geology, Panaji. -
| 3. The Director, Directorate of Accounts, Panaji- Goa |
4, The Under Secretary Finance (Expenditure) Secretariat. |
वि - 5, The Under Secretary to Chief Secretary. | |
| 6. Guard File. | |
7. P.A to Secretary Mines. इ
8. Office of the Pr. Account General, Audit Bhavan, Alto- Porvorim.
I. .
| | ट Page 6 of 6
