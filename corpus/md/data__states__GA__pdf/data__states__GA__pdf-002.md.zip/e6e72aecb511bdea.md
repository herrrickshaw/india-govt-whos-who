---
doc_id: "e6e72aecb511bdea"
source_url: "https://www.goa.gov.in/wp-content/uploads/2022/03/Circular-South-DJC.pdf"
ministry: "COVID-19 Information & Updates, Goa"
title: "Download"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "d53d3037fbe9c182"
---

<!-- page 1 -->

४१८०३०७, MARGA O.
£ 4 ट NO: DSC/MAR/ADM-60(COVID-19)/2022/200-
£ ot aah % Establishment Code: GASGO1
3 मिलर आता 3 Dated: 04.03.2022.
Read: This office Circular No.DSC/MAR/ADM-60(COVID -
19)/2022/1305 datd 11.02.2022.
CIRCULAR

In view of letter No. Insp-I/36/2022 dated 03.03.2022 of the
Hon'ble Registrar General, High court of Bombay, conveying the
directions of the Hon’ble the Chief Justice and other Hon’ble Judges of the
Hon’ble Administrative Committee to continue with normal physical
functioning of all the Subordinate Courts w.e.f 05.03.2022, all the
District and Subordinate Courts in the South Goa District will start
functioning as per pre-pandemic days with 100% attendance of
Judicial Officers and staff in both sessions in supersession of
earlier Circular/SOPs w.e.f. 05.03.2022.

All the Covid-19 safety and precautionary measures (i.e. wearing
masks, sanitization, social distancing norms, vaccination etc.) set forth by
the Central Governments, State Governments and Local Authorities etc.
from time to time, shall be adhered scrupulously by all the District &
Subordinate Courts in South Goa District.

buch
Sy \o शी
(IRSHAD AGHA)
Principal District & Sessions Judge,
South Goa, Margoa.

Copy to:
1. The Registrar General, High Court of Bombay, Appellate Side, Mumbai.
2. The Registrar (Inspection-l), High Court of Bombay, Appellate Side

Mumbai.
3. The Registrar (Inspection-lI), High Court of Bombay, Appellate Side

Mumbai.
4. The Registrar (Adm), High Court of Bombay at Goa, Porvorim.
5. The Principal District & Sessions Judge, North Goa, Panaji.
6. The Superintendent of Police, South Goa, Margao, with a request to

circulate it to the Concerned Police Station.
7. The Collector, South Goa, Margao.
8. The Inspector General of Prisons, Panaji, Goa.
9. The Directorate of Prosecution, Panaji, Goa.
10. The Superintendent of Police, CBI, ACB, Bambolim, Goa.
11. The President, Advocates Bar Association, South Goa, Margao.
