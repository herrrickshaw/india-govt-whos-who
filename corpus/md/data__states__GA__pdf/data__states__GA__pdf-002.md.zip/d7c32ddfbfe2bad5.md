---
doc_id: "d7c32ddfbfe2bad5"
source_url: "https://www.goa.gov.in/wp-content/uploads/2022/01/Revised-Home-Isolation-Guidelines.pdf"
ministry: "COVID-19 Information & Updates, Goa"
title: "Revised Guidelines For Home Isolation Of Mild / Asymptomatic COVID-19 Cases"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8e7050f6b07bfd0d"
---

<!-- page 1 -->

5th January 2022

Government of India
Ministry of Health & Family Welfare
Revised guidelines for Home Isolation of mild /asymptomatic COVID-19 cases
1. Background
Over the past two years, it has been seen globally as well as in India that majority of cases of
COVID-19 are either asymptomatic or have very mild symptoms. Such cases usually recover with
minimal interventions and accordingly may be managed at home under proper medical guidance
and monitoring.
Ministry of Health & FW has thus issued and updated guidelines for home isolation from time to
time to clarify selection criteria, precautions that need to be followed by such patients and their
families, signs that require monitoring and prompt reporting to health facilities.
The present guidelines are applicable to COVID-19 patients who have been clinically assessed and
assigned as mild /asymptomatic cases of COVID-19.
2. Asymptomatic cases; mild cases of COVID-19
The asymptomatic cases are laboratory confirmed cases who are not experiencing any symptoms
and have oxygen saturation at room air of more than 93%.
Clinically assigned mild cases are patients with upper respiratory tract symptoms with or without
fever, without shortness of breath and having oxygen saturation at room air of more than 93%.
3. Patients eligible for home isolation
i.

ii.
iii.

The patient should be clinically assigned as mild/ asymptomatic case by the treating
Medical Officer. Further a designated control room contact number at the district /sub
district level shall be provided to the family to get suitable guidance for undertaking
testing, clinical management related guidance, assignment of a hospital bed, if warranted.
Such cases should have the requisite facility at their residence for self-isolation and for
quarantining the family contacts.
A caregiver (ideally someone who has completed his COVID-19 vaccination schedule)
should be available to provide care on 24 x7 basis. A communication link between the

Page 1 of 7

<!-- page 2 -->

iv.

v.

vi.

caregiver and a Medical Officer is a prerequisite for the entire duration of home
isolation.
Elderly patients aged more than 60 years and those with co-morbid conditions such as
Hypertension, Diabetes, Heart disease, Chronic lung/liver/ kidney disease, Cerebrovascular disease etc shall only be allowed home isolation after proper evaluation by the
treating medical officer.
Patients suffering from immune compromised status (HIV, Transplant recipients, Cancer
therapy etc.) are not recommended for home isolation and shall only be allowed home
isolation after proper evaluation by the treating Medical Officer.
While a patient is allowed home isolation, all other members in the family including other
contacts shall follow the home quarantine guidelines available at:
https://www.mohfw.gov.in/pdf/Guidelinesforhomequarantine.pdf.

4. Instructions for the patient
i.

ii.
iii.

iv.
v.
vi.
vii.
viii.
ix.

x.
xi.

Patient must isolate himself from other household members, stay in the identified room
and away from other people in home, especially elderly and those with co-morbid
conditions like hypertension, cardiovascular disease, renal disease etc.
The patient should stay in a well-ventilated room with cross ventilation and windows
should be kept open to allow fresh air to come in.
Patient should at all times use triple layer medical mask. They should discard mask after 8
hours of use or earlier if the mask becomes wet or is visibly soiled. In the event of Caregiver
entering the room, both Caregiver and patient may preferably consider using N-95 mask.
Mask should be discarded after cutting them to pieces and putting in a paper bag for a
minimum of 72 hours.
Patient must take rest and drink lot of fluids to maintain adequate hydration.
Follow respiratory etiquettes at all times.
Undertake frequent hand washing with soap and water for at least 40 seconds or clean
with alcohol-based sanitizer.
The patients shall not share personal items including utensils with other people in the
household.
Need to ensure cleaning of frequently touched surfaces in the room (tabletops, doorknobs,
handles, etc.) with soap/detergent & water. The cleaning can be undertaken either by the
patient or the caregiver duly following required precautions such as use of masks and
gloves.
Self-monitoring of blood oxygen saturation with a pulse oximeter for the patient is advised.
The patient shall self-monitor his/her health with daily temperature monitoring (as given
below) and report promptly if any deterioration of symptom is noticed. The status shall be
shared with the treating Medical Officer as well as surveillance teams/Control room.

Page 2 of 7

<!-- page 3 -->

Patients Self -health monitoring Chart
Date
time

and Temperature

Heart
rate SpO2 % (from Feeling:
Breathing:
(from pulse pulse
/
(better /same (better
oximeter)
same/ worse)
oximeter) *
/worse)
**

*For self-monitoring blood oxygen saturation with a pulse oximeter, place the index finger
(after cleaning hands and removing nail polish, if any) in the pulse oximeter probe and take
the highest steady reading after a few seconds.
**The patient may self-monitor breathing rate/respiratory rate in sitting position, breathe
normally and count the number of breaths taken in 1 full minute.
5. Instructions for Care Giver
i. Mask:
o The caregiver should wear a triple layer medical mask. N95 mask may be considered
when in the same room with the ill person.
o Front portion of the mask should not be touched or handled during use.
o If the mask gets wet or dirty with secretions, it must be changed immediately.
o Mask should be discarded after cutting them to pieces and putting in a paper bag for
a minimum of 72 hours.
o Perform hand hygiene after disposal of the mask.
o He/she should avoid touching own face, nose or mouth.
ii. Hand hygiene
o Hand hygiene must be ensured following contact with ill person or his immediate
environment.
o Use soap and water for hand washing at least for 40 seconds. Alcohol-based hand
rub can be used, if hands are not visibly soiled.
o After using soap and water, use of disposable paper towels to dry hands is desirable.
If not available, use dedicated clean cloth towels and replace them when they
become wet.
o Perform hand hygiene before and after removing gloves.
iii. Exposure to patient/patient’s environment
o Avoid direct contact with body fluids (respiratory, oral secretions including saliva) of
the patient. Use disposable gloves while handling the patient.

Page 3 of 7

<!-- page 4 -->

o Avoid exposure to potentially contaminated items in his immediate environment
(e.g. avoid sharing eating utensils, dishes, drinks, used towels or bed linen).
o Food must be provided to the patient in his room. Utensils and dishes used by the
patient should be cleaned with soap/detergent and water while wearing gloves. The
utensils may be re-used after proper cleaning.
o Clean hands after taking off gloves or handling used items. Use triple layer medical
mask and disposable gloves while cleaning or handling surfaces, clothing or linen
used by the patient.
o Perform hand hygiene before and after removing gloves.
iv. Biomedical Waste disposal
Effective and safe disposal of general wastes such as disposable items, used food
packets, fruit peel offs, used water bottles, left-over food, disposable food plates etc.
should be ensured. They should be collected in bags securely tied for handing over to
waste collectors.
Further, the used masks, gloves and tissues or swabs contaminated with blood / body
fluids of COVID-19 patients, including used syringes, medicines, etc., should be treated
as biomedical waste and disposed of accordingly by collecting the same in a yellow bag
and handed over to waste collector separately so as to prevent further spread of
infection within household and the community. Else they can be disposed of by putting
them in appropriate deep burial pits which are deep enough to prevent access to
rodents or dogs etc.
6. Treatment for patients with mild /asymptomatic disease in home isolation
i.

Patients must be in communication with a treating Medical Officer and promptly report in
case of any deterioration.
ii. The patient must continue the medications for other co-morbidities/ illness after consulting
the treating Medical Officer.
iii. Patient may utilize the tele-consultation platform made available by the district/state
administration including the e-Sanjeevani tele-consultation platform available at
https://esanjeevaniopd.in/
iv. Patients to follow symptomatic management for fever, running nose and cough, as
warranted.
v. Patients may perform warm water gargles or take steam inhalation thrice a day.
vi. If fever is not controlled with a maximum dose of Tab. Paracetamol 650 mg four times a
day, consult the treating doctor.

Page 4 of 7

<!-- page 5 -->

vii.

Information floating through social media mentioning non-authentic and non-evidencebased treatment protocols can harm patients. Misinformation leading to creation of panic
and in-turn undertaking tests and treatment which are not required has to be avoided.
Clinical management protocol for asymptomatic/mild patients as available on the website
of Ministry of Health & FW
(https://www.icmr.gov.in/pdf/covid/techdoc/COVID_Management_Algorithm_23092021
.pdf) may be referred to by the treating Medical Officer to aid management of the case.
viii. Do not rush for self-medication, blood investigation or radiological imaging like chest X ray
or chest CT scan without consultation of your treating Medical Officer.
ix. Steroids are not indicated in mild disease and shall not be self-administered. Overuse &
inappropriate use of steroids may lead to additional complications.
x.
Treatment for every patient needs to be monitored individually as per the specific condition
of the patient concerned and hence generic sharing of prescriptions shall be avoided.
xi. In case of falling oxygen saturation or shortness of breath, the person may require hospital
admission and shall seek immediate consultation of their treating Medical
Officer/surveillance team /Control room.
7. When to seek medical attention
Patient / Care giver will keep monitoring their health. Immediate medical attention must be
sought if serious signs or symptoms develop. These could includei.
ii.
iii.
iv.
v.
vi.

Unresolved High-grade fever (more than 100° F for more than 3 days)
Difficulty in breathing,
Dip in oxygen saturation (SpO2 ≤ 93% on room air at least 3 readings within 1 hour) or
respiratory rate >24/ min
Persistent pain/pressure in the chest,
Mental confusion or inability to arouse,
Severe fatigue and myalgia

8. Monitoring of the Patient during Home Isolation
The concerned district administration under the overall supervision of State Health Authority
shall be responsible for monitoring the patient under home isolation.
8.1.

Responsibilities of grass root level Surveillance Teams

Page 5 of 7

<!-- page 6 -->

i.

The Surveillance Teams (ANM, Sanitary inspector, MPHW etc) shall be responsible for
initial assessment of the patient and whether the requisite facilities are there for home
isolation.
ii. The health worker should contact the patient daily preferably in-person or over
telephone/ mobile and obtain the details of temperature, pulse, oxygen saturation,
patients overall wellness and worsening of signs/ symptoms.
iii. The Surveillance Team may provide Home Isolation Kits to the patient/ caregiver as per
the policy of the State Government. The Kit may contain masks, hand sanitizers,
paracetamol along with a detailed leaflet to educate patients and family members in local
language.
iv. If there is reported worsening of signs/ symptoms and/or fall in oxygen saturation, the
Surveillance team shall re-assess the patient and inform the Control Room for shifting the
patient to hospital.
v. The surveillance Team shall also undertake the patient education on the disease, its
symptoms, warning signs, COVID appropriate behaviour and need for vaccination for all
eligible members.
8.2.

Responsibilities of the District/ Sub-District Control Room.
District and sub-district control rooms will be made operational and their telephone
numbers should be well publicised in public so that people under home-isolation may
contact the control rooms for seamless transfer of patients through ambulance from
home to the dedicated hospital.
These Control Rooms shall also make outbound calls to the patients under home isolation
to monitor their status.

8.4.

Role of District Administration
The district administration should monitor all cases under home isolation on a daily basis.

9. When to discontinue home isolation
Patient under home isolation will stand discharged and end isolation after at least 7 days have
passed from testing positive and no fever for 3 successive days and they shall continue wearing
masks. There is no need for re-testing after the home isolation period is over.
Asymptomatic contacts of infected individuals need not undergo Covid test & monitor health in
home quarantine.

Page 6 of 7

<!-- page 7 -->

Page 7 of 7
