---
doc_id: "8a2fb185ec4dc9bd"
source_url: "https://goacivilsupplies.gov.in/wp-content/uploads/2025/05/The-Consumer-Protection-Direct-Selling-Rules-2021.pdf"
ministry: "Civil Supplies and Consumer Affairs Department, Goa"
title: "The Consumer Protection (Direct Selling) Rules, 2021"
date: ""
pages: 15
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "5e4dc49e9a0383a4"
---

<!-- page 1 -->

स ं. .ए.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-28122021-232214
xxxGIDHxxx
CG-DL-E-28122021-232214
xxxGIDExxx
ऄाा
EXTRAORDINARY
ा II—ण 3—ई-ण (i)
PART II—Section 3—Sub-section (i)
ाा  ा
PUBLISHED BY AUTHORITY
ं. 730]
No. 730]

इ द, ंा, द 28, 2021/ौ 7, 1943
NEW DELHI, TUESDAY, DECEMBER 28, 2021/PAUSA 7, 1943

ईा ा, ा औ ा  ंाय
(ईा ा ा)

ऄूा
इ द, 28 द, 2021
ा.ा.. 889(ऄ).— य ा, ईा ं ऄय, 2019 ी ाा 101 ी ई-ाा (2) 
ं (यछ)  ा ठ ाा 94 ाा त य ा य  हए, म य ा , ऄा:् 1. ंप ा औ ा – (1) आ य ा ंप ा ईा ं (य ी) य, 2021 ।
(2) य ा  ा ी ा  ृत ।
2. ाू ा – (1) ऄव   ा ऄया ईं , ई ाय य य म  ाू :
() य ी  ाधय   या  इ इ  ा औ ाएं;
() य ी   ॉ;
() ा  ईा   ा ा ा औ ाओ ी  य ी आाइयां; ा
(घ) य ी   ॉ  ऄु वाा    ।
ं ु ा य ी आाइयां ा  आ य  ा ी ा  ब द   आ
य  ईं ा ऄुा  ।

7617 GI/2021

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(2) ई-य (1)  ऄं द  ा   हए , य य ई य ी आाइ   ाू ,
 ा  सा  ै कु ा  ईाओ  ा या ाओ ी साा  ै;
3. ठााएं – (1) आ य ,   ं  ऄया ऄ  :() “ऄय”  ईा ं ऄय, 2019 (2019 ा 35) ऄ ;
() “ई ऄ”  ऐ या ऄ ,  द ंा  ं  ठा या ास 
ई  ा, ा ाा य ी वाय  ा   ए दए ए ा 
   ए ई ा ी इ ;
() “य  ा”  ऐा व ऄ   द य ी आाइ ाा ू अा  य
ी वाय   ए    ाू  यय  ंा  ाधय  ाृ 
दया या ;
(घ) “य ी आाइ”   ू आाइ ऄ ,  य  ा  ाधय  ा या ा ी
ी   या ी ी साा   कु आ ऐ आाइ     ा
सी औ/या  ठा सी ा ंा  ;
(ङ) “ ठा सी”  ऐ सी ऄ   आा ट औ  ठा सी (ां)
ऄय, 1978 (1978 ा 43) ी ाा 2  ं ()  ठा ;
() “छ-ी”  द ी  फाू ूा     द ुव ाा ईा या
ा  सु  हए आी ी ा ऄ  औ आ ईाओ  द ईा या
ा  ा  भा ाा ा ा या आ द ईा  ा  ू ाा
 छडा या ऐ ाा ा ा    ईा ु छ ऐा  ा  
  ।
(छ) “ा गा”  ऐा व ऄ   य  ा ाा य ी आाइ  
 ी साा ा या सा दया ाा ;
() “ा सी”  द सी  ऄठ ऄाा(ओ)  ाां या ाय या  
ठास य या ऄय   ा ाप   ए ए या ए  ऄ ऄााओ
 ाांद  हए ऄाा(ओ) ाा ाइ इ सी  ए ऄााओ ा ए हसय
ट ऄ ,  ऄठ ऄाा (ओ)  ाांद  ा ऄाा ईच सा 
बा ाप ै औ ाांद ऄाा  सा  बा ाप ,   ाां 
ठए ऄााओ ा ह-सय ट ा ;
(झ) ा या ाओ  ंं  “ी यय”  ऐ ऄयु औ यय ा या ाएं ऄ
ै  ईय ी ा ाप  हइ  या  या  ै,  ं  दया या  या
  ं  ए ईय ी इ ै;
(ञ) “ं य ाटा”  ऐा ं ाटा या ाा ऄ   ूा ौी
ऄय, 2000 (2000 ा 21) ी ाा 43 ()  ऄ य-य  र ी इ ;
(ट)

“ाजय”  ंघ ाजय   ।

2. ऐ ब औ ,  आ यु दया या  औ ठा  दया या  कु ऄय 
ठा दया या ,   ऄ   ऄय  दए ए ै।
4. ठा ा अा ा -य य ी आाइ ऄ सृ  ायाय  
सा ठा/ य ृत द    ऄ या सा  ुऄ   या
आॉ   ाए  :
.  ा;
. ं ा औ ं ऄुछ;

<!-- page 3 -->

ा ा ा : ऄाा

[ा II—ण 3(i)]

3

. साय ाा ंखया औ  टौ औ ंग ाा ंखया;
घ. ा औ ा  स;
ङ. ा औ ा  ;
. अय ;
छ.  ट, अट ठट औ ऐ ऄय ं ठटे;
. य  ाओ ी ंा;
झ. अयाया  ा- (अया ा  ा );
ञ. ा ाो  ा या ी  य  ाय ा ुा औ ा ा
ऄय, 2006 (2006 ा 34)  ऄ ा ऄुप;
ट. अयुद, ा औ यूा ाओ औ य औय  औय  ा या ी
 य  ए औ औ ा ाग ऄय, 1940 (1940 ा 23)  ऄ ा
ऄुप औ स ा;
. वाा  स ा ा।
5.

य ी आाइओ  ाय(1) य य ी आाइ ()

यद ं , ं  ऄय, 2013 (2013 ा 18)  ऄ  , यद ाा फ,
ाा ऄय, 1932 (1932 ा 9)  ऄ सृ  , या यद  ाय
ाा फ,  या ाा ऄय, 2008 (2009 ा 6)  ऄ सृ 
;

()

ा   ऄ सृ  ायाय       ए ौ सा ।

()

आ अय ी सघा - द आ आ य  ईं ा ऄुा दया  ा द
ा सी या  ठा सी    ;

(घ)

य 4  र सा या ठाो, ं ()  ऄ रट स-घा, ं
ाा  ा औ ऄ , ऄ  ऄा, ाय  ऄा ा
, आ ं, ईा, ईा ूा, ी, ा ईा  ए ाय ा
ं   आाइ ी  ां   ा ई औ ऄ ाआट ा ा;

(ङ)

य ी आाइ ाा  ा ा या अू ी ा ा ा या ाओ  ए ईी
ा  ा द याा , ा  या द ऄय ा  ी सा,
ा या ऄुपा  कु ऐ ईा/ाओ ी ी  इ ,  या
ा  ा    ए  आाइ द वाा , ा  या द ऄय
ा  ी सा, ा या ऄुपा  ;

()

साय ाा ंखया औ ा औ ा    ाू याा स औ ऄुप
ा ा;

(छ)

ं   ाा  ा ऄ ाआट  ा ी इ  ाा;

स: आ ं  य  ए ं    ऐा व ऄ   ं  
ऄय, 1980 (1980 ा 56) ी ाा 2 ी ई-ाा (1)  ं ()  ठा ;
() आ य  ा  ा ई ऄ ा या ाओ ी ी या ी ी साा  ए
ाृ      ू  ऄुं  ा ा ी े यायं, ई औ 
।

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(झ) य ुि ा द आ  य  ाओ  ा या ा औ ौ   औ
  ऐ य  ाओ औ सा   ा  ा  ;
(ञ) ऄ य  ाओ ाा साा दए ए ा औ ाओ  ाू य  ऄु ा
ुि   ए याप ुाय ृ ा;
(ट)

य  ाओ ाा ा या ाओ ी ी  ईन  ा ाय  ए ा
ा;

(2)
य ी  ा य आाइ ऄ ाआट  म ूाएं स औ ु  
ईब ाए,  आ याओ  ुखय    , ऄा-्
() य ी  ा आाइ ा सृ  ा;
() य ी आाइ औ आी ााओ ा सृ  ा;
() गा ा औ ाय ा ऄा  इ- ा, फ , ूा औ ाआ 
 ं बयौ ;
(घ)  ी इ य ाय  ए ए ठटट   ाधय  ाया ाय ी
स    ा ;
(ङ) ा, ठफं , य, ां ट औ ां ट, ुु
  औ ाइ, ुा ी , ाय
ा ं  ंं  ूाएं औ ऐ ऄय ूाएं,  ु य   ए ईा 
ए अय ;
() ुा ी ईब य, ुा ी ई य ी ुा, याओ ाा ुा ी
ा ा फी औ ा, ई य  ऄ य ुा  स  ी दया,
ा  , यद इ ,  ंं  ूाएं ा ं ुा ा ाा  ं  
ंं  ाा;
(छ) द ा या ा ा ए ऄं  ूय  ा-ा ईा बयौा-ा ूय (ऄ-ऄ ूय)
 ुु
  ा, ा औ ैल ा, ा ा औ ाू    ऄाय औ
सछ ा ाए ए ै;
()   ू  औ ू ूा ा ा   ा ा  ंं  ु य 
 औ ऐ ाा   ा ा (ं ा) य, 2011  ऄठ म
ूाएं  :(i)

 ा औ  ा ा ा;

(ii)

ा या ाओ ा ;

(iii)

ा या ाओ ा ाा;

(iv)

ा या ाओ ी ऄुा ुु
  ा;

(v)

ठफं  ी दया;

(vi)

ा ी ां ट;

(vii)

ा  ू   आा य या सा;

(viii)

य ृत द   ऄ ईाठट ी ा  ए ऄ ंा ंं
 ूाएं।

(3)
य ी  ा इ  आाइ, ऄ ाा    या ऄया इ ऄु वाा ा
 ऄाए औ य ृत द   र ऄाओ ा ा ा ा।

<!-- page 5 -->

[ा II—ण 3(i)]

ा ा ा : ऄाा

5

(4)
य ी  ा द आाइ   ईा,  ा ा ऄय, 2009 (2010 ा 1) 
ऄ ी ा ा घाओ ा ा  ।
(5)
य ी  ा य आाइ य ृत ाू   ऄुा ा  ऄा   
ं य ाटा  ए   औ द ईा ाा दए ए ऐ ाटा ी ुा ुि  
ए ईयु  ईाए औ द ऄाृ  व ाा हं या ुय    ए याप ुाय 
ुि  ।
(6)
य ी  ा य आाइ, ााया ा  द व  ाप  ा ाय ी
ंखया  ंं  याप ाय ा ं सा   औ ईाओ  ाप ाय  ा  ए
ए या ई ऄ ाय ा ऄाठय ी यु   औ ऄ ाआट  ई ऄा  ा
औ ऄ ा औ ं ू  ूा ंखया, इ- औ ई ऄा ा ा  ा, 
  औ ऄ ाआट  बयौ  ुखय   ईा ूा ट या ंफट  स ऄ  छा।
(7)
य ी  ा य आाइ य ुि   द ई य (6)  र ाय ा
ऄा द ईा ाय  ाप   ऐ ाय ी ाप  ऄडा घंट   ईी ा
ा  औ ाय ाप  ी ा  ााया ए ा ी ऄ   ाय ा ाा ा 
औ ए ा  ऄ ं   ा , ं  ा औ ाय  ी इ ा ाइ ी ूा 
  ाया   ा ।
(8)
य ी  ा य आाइ ए  ऄा ी यु    ऄय औ ई ऄ
ाए ए य  ईं  ा ऄुा ुि  औ य ृत द ऄय  या ई ऄ
ाए ए य  ईं  ऄु  दए ए अ औ ऄु ा ऄुा ुि   ए
ईताय ा।
(9)
य ी  ा य आाइ ईाओ ाा आ ायाय या ााओ या य  ाओ 
ाधय , व   या ा, ूा, इ- या ाआट  ाधय  ाय     ए ए ं
सा  ।
(10) य ी  ा य आाइ, आ  य  ाओ ा ठॉ   ई ा ;
 ा ाय, इ- ा ं  ुड ऐ ऄय ूाएं  ।
(11) य ी  ा य आाइ द ईा ाा द ा या ा ी    िा्
   ऄु   ई द य  ा ंं ूाएं ा    ई ईा  ऐ
ा ी  औ ऐ ूा  ईा ा, ा, इ- ा औ ा ा ा ं  ाा   ए
ऐ य  ा  ाा   ए अय इ ऄय ूा  ।
(12) य ी  ा य आाइ य ुि   द ा या ाओ    ए दए ए
ा, ऐ ा या ा ी ास ाओ, ुा औ ईय ी सय  ऄं  ।
(13) य ी  ा इ आाइ सयं  य या ऄय   थया व  ईा   
सु    या ऄ ा या ाओ  ा  ा सट    या द ा या ा ी ुता या
ाओ ा ुव
    ।
(14) य ी  ा इ आाइ  सयं ाा  ए ा या ाओ  ाा  ा ाा 
 या ां ट   द  ा या ाएं ा ै,  ई ऐ ा या ाओ ी ााा  ंं  ी ा
ा द ा ाइ ा ईताय ा ा।
(15) य ी आाइ ाा ऄाइ इ  ा   हए , य ी  ा आाइ आ
य  ा ाा ऄाइ इ य ी ा   औ ऐ य  ा  ा ः ाधया ंा
 ाधय  आ य ा ऄुा ुि  ।
(16) य ी  ा य आाइ, ं ूाओ ा ठॉ   य ी  ा आाइ
ाा ू  टाए ए  य  ाओ ी ा ी ा  औ ऐ ू आी ाआट  ा  
 ाझा ी ाए।

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(17) य ी  ा य आाइ ी,  य ा ी ाय ईा ाआ ी ं े दया 
ाा ।
6. य  ा  ाय - (1) य य  ा ()  ा य ी आाइ  ा ी इ ू- ंा  ाद ऐ आाइ  द ा या ा ी
ी या ी ा सा दया ा  ;
() इ ी ऄया ु   या   औ स   ऄ ा  ा, य ी 
ा आाइ ी ा, ाा स  , य दए ए ा या ाओ ी ृ  औ ऐ ऄया
 ा य ा ट  ा;
() ा गा  ट औ ंू ूा ा  ा सा  ा औ ा औ ाओ, ी, ईा ी
ो, ुा ी ो, ा, य, ठफं  , ा  ी  ां ट ा ी िा् ा ी
ो    ा;
(घ) ा ी  य या ई  ईा  ए अ  ा  ा  य ी  ा
आाइ औ य  ा ी ा  ा औ आ य  ा ा ा, ा, स ंखया या
ाां ंखया, ा ा औ ं ू, अू ी ा ा ा या  ा ू , ा 
ा ा , ऑ ी ा, ईा ाा ुा ी ा ा ु  ा, ा  ू 
 औ ठा ा य औ सा, ऑ  स  या ी  यय ा  ईा ी
ा  ा ू ी ा ाप  ा ईा ा ऄा ा य ी  ा आाइ
 ाय ा ं  ा  ूा  दया या ा;
(ङ) ा औ ा  स, साय ाा ंखया स,  ाू वााठ स औ
ऄुप ाप  ा औ द ईा ी ी  ए ाू य, य औ य ी ऄाओ ा
ऄुा  ा;
() य ुि  ा द  ा  ा दया या ास ईा दए ए ईा     ाा ;
(छ) ईा ाा ा ी इ  ं य ूाओ ा ं ुि   ए य
ृत य  ऄुा ई  ईाएा औ ऄाृ  यय ाा अंड (ाटा) ा  या
ईा ुय     ए या ुाय ुि  ा।
(2) इ य  ा()

ा  औ ू ऄु या ऄु  ा द ईा  ठ   ाएा;

()

द ा गा  इ ाय  ा  य ी आाइ  ऄुद  दया ;

()

द ा गा  इ ाय या ी  ईस  ी ऄा   ा।

(घ)

ी  ऄु  ऐा इ ाा   ा  य ी  ा आाइ ाा ाृ  ा 
ऄं  ।

7. य ी आाइ या य  ा  य -ऄय  ऄधयाय VI  ईं  ऄधय,  ईा
ाय  ंं , य ी  ा आाइ औ य  ा  म य ,  ाू
, ऄा्:(i)

य ी  ा य आाइ औ य य  ा य ुि  ा द () सा ी े सट  ाद ईा  सा दए ा ा ईा या ा ी स ृ  औ
इ अ   ा ा ी ाा ा   ;
() य ी  यु दए ा ा सु ा ऄय ऄया  ईा ा ऐा इ ,
ाा, ृटां या ऄय   ा   ौ  या  ा ईा  ुा 
ी ंाा ;

<!-- page 7 -->

[ा II—ण 3(i)]

ा ा ा : ऄाा

7

() सा दए ए ा या ाओ     ी  ंं  औ यद ाू     
ईा ी ो, ुा ी ो, ई ऄ या ा   ऄा, ां ट ी े, य-िा्
ा औ ठा ट औ ू ;
(घ) याय थय  ंं , ा, ृां या ऄय  ऐ  द ई ा दया ा  ;
(ङ) इ भा, टू या ऄु वाा वा ा य  दया ाए;
() य ी  ाा ऄुंा    ईा  ा  दया ाए;
(छ) ढाा  ाा ाय, ा या   य ी  ा ं  ा ा औ ा या ूा
ंखया दया या  औ ई य  ा ा ाआ   ा ;
() य ी    य ई  दया ाएा या ऄ  ा द  ऄ  ा
ां ट, ां ट या ऄय    ाा ईं सा  ऄठ द ऄय ऄा ा सा 
दया ाए,  ऐा ाा  ;
(झ) द  ां ट या ां ट ी े  ां ट  ा ा ा औ ा  ा ईा 
अा  ईब  औ  ाा ऄु ईा ऄा या ाएं या ईा सट औ
ृय ;
(ञ) ईा  ु ईा ा ाइ ा  अ फा या ा या ाओ  ा  ा ा
ऄय ाय   सट   दया ाएा;
(ट) सा  सु  इ ंा, ृषां या ाय ं ाग  या ं   
 य ई, याय या ं  ;
()  ी  िा् ी ा ी साा ी ा    ा  बयौ ां ट  ा दया ाए या
सा  ऄय आा ई दया ाए औ यद ईा सा  सा ा   आ अय
ी ूा ईब ाइ ाए द ईा ा    ाय ा ा  औ  एट 
ाा  ा ;
() ां  ाू , ईयु सासथय औ ुा ा  ऄु  ू  ईा  ईा
 ुु  औ ंा ा  ए ई ं  बां दया ाएा;
()   सा  ऄया य  दया या ,   य  य ईा  सा ुु ी
ा   ी  ा आाइ या ंं य  ा  ंा  अ  या सट  
ऄय ं  ा  ईा  ू दया ाएा;
() ं ()  ऄ   ा , ईा ाा अ    ंं  ऄु  ऄु 
ाए, ऐा  य आ ा  धया  दया ाएा द ईा  ू दया या  या 
औ ा  य ईा  सा  ी ो  ऄुा ाा, यद इ ,
ा   ाए औ यद ुु
  () ा ं    ईा  य ी 
ा आाइ या य  ा ी ा  ा य ईा  सा ा  ा ी
दया  ऄुा ईा  ा   ऄा  ा  ू दया ाएा;
() आाइ ाा सा दए ा ा ा  ऄा    ा;
() ां सा  ए ुा ा ी या द  अा  ,   सा  ी औ ुा
ी ो ा सट ई दया ाएा  ा द ऄठ ा  ा, ैल औ  अद
ी ृ   ा सा  स  दया ाएा औ   ं , ऐ ा ी ा  ाए;
() द  ी ा ा ी  ा , ईा ी ो,  द ा ी ा या ा  ुा
ऐ द ी ंखया, ा या अा ा ा य ूय, यद इ , ी ुा  ु  ी
 सा  सट   ाया ाएा;

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

() द ऄय ा  ईा ी ा, बया औ ो  झा  ए ईा  ए अय इ
ऄय ूा या  सा  ा ी ा  या  ईा ( ट) ी साा ी ा ;
()   सा ी ऄ औ ूय ा सट   ई  दया ाा   ई या 
ए ूय स  ाएं;
() द  ंा  सा दए ा  ू ुा औ ऋ ू ी दया ाठ ी ाए
औ  आ ा ी  द  ईा  ऄु ऄुा  , ईा  यं 
ा  ं  ए ई ता दया ाएा;
(फ)  ाा ऄय, 2009 (2010 ा 1) औ ई ऄ ाए ए य  ईं ा
ा दया ाएा।
(ii) य ी  ा इ आाइ या य  ा() द टू  या ी    ा औ य ुि   ए ई  ईाा
ुि  ा द ा झू या भा ऄया या द ा ा ट, ड, ईड या
ाा या ऄ ा    ।
() द ऐ अ    ा या ऐा इ अ   ा  ुा  ाा  या द
ऐ ाग     य ी ाा या य ी आाइ ाा सयं य  ा ाा
 ा  ,  ंं  ुा दए ा ी ंाा ;
() ईा    ईा या ाएं   ं  ा;
(घ) ऄ ा या ाओ ी ी  ए या ऄ य ी ाा  ढाा   ए ट, ड,
ाा या ऄ ा    ा या ईड   ा;
(.)  ा या ुठटू ाओ  ा   आा   ा औ दए ए ा या ाओ  ए
दए ए ुा  ा  ा;
() इ  फी या ंा  ूा;
(3) ्य ी  ा इ आाइ या य  ा  ं य,   ा ुा औ
टौ  , ी ऄाओ ा ऄुा  ा।
(4) य ी  ा इ आाइ या य  ा आ अा  गा  ा   ए
  ा द  ा गा  य  ाओ  ा  ऄ ूय     ै
या ूय ी ू   ै।
8. ऐ य  ाा या य ी  ं  दया ाा - इ  ऐा य,  य ी 
ाा  ं    छ ां ो  ौा  या दाया ा  या ृ त य
 य ी  ाा  ं  दया ाएा।
सट: आ य  या ‘’दाया’’ ब ा  ऄ ा  दाा औ  ऄा
ंा 2016 (2016 ा 31) ी ाा 79  ं (3)  दया या ।
9.

इ-ाजय य ी ऄुयजया:- ी  ए इ-ाजय टफाो ा य  ा य  ा औ
य ी  ा आाइयां, ईा ं (इ-ाजय) य, 2020 ी ऄाओ ा ऄुा
 ।

10.

ा सी औ  ठा सी ा - इ  य ी  ा आाइ या या
 ा –
() ा सी  ढाा ा या द य  ऐ सी  ाांद  ा या य ी
ाा        ऐ यसा  ा  ा;
()  ठा सी  य ी ाा    ा  ा।

<!-- page 9 -->

[ा II—ण 3(i)]

9

ा ा ा : ऄाा

11.

ाजय ा ाा ा: य ी आाइ औ य  ाओ ाा आ य ा ऄुा
ुि   ए, य ाजय ा य  ाओ औ य ी आाइ ी य ी
ा या य  ए ए ं सा  ।

12.

य  ऄंा: यद आ य  ऄ ा द य ी आाइ  ाय ठ ै
ऄय, 1934 (1934 ा 2)  ऄ ाए ए इ य ाू  ै,  ऐ य  ईं
आ य  ाा , ऄंा ी ा  ऄा ।

13.

य ा ईंघ: आ य  द  ईंघ  ए, ऄय  ईं ाू ।
[फा. ं. -10/9/2018-यू]
ऄु शा, ंयु 

MINISTRY OF CONSUMER AFFAIRS, FOOD AND PUBLIC DISTRIBUTION
(Department of Consumer Affairs)
NOTIFICATION
New Delhi, the 28th December, 2021
G.S.R. 889(E).—In exercise of the powers conferred by clause (zg) of sub-section (2) of
section 101 read with section 94 of the Consumer Protection Act, 2019, the Central Government hereby
makes the following rules, namely:1. Short title and commencement. –– (1) These rules may be called the Consumer Protection (Direct
Selling) Rules, 2021.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. Application. –– (1) Save as otherwise expressly provided, these rules shall apply to––
(a) all goods and services bought or sold through direct selling;
(b) all models of direct selling;
(c) all direct selling entities offering goods and services to consumers in India;
(d) all forms of unfair trade practices across all models of direct selling:
Provided that existing direct selling entities shall comply with the provisions of these rules within ninety
days from the date of publication of these rules in the Official Gazette;
(2) Notwithstanding anything contained in sub-rule (1), these rules shall also apply to a direct selling entity
which is not established in India, but offers goods or services to consumers in India.
3.

Definitions. –– (1) In these rules, unless the context otherwise requires,––

(a) "Act" means the Consumer Protection Act, 2019 (35 of 2019);
(b) "cooling-off period" means a period of time given to a participant to cancel the agreement he has
entered into for participating in the direct selling business without resulting in any breach of contract or
levy of penalty;
(c) "direct seller" means a person authorized by a direct selling entity through a legally enforceable written
contract to undertake direct selling business on principal to principal basis;
(d) "direct selling entity" means the principal entity which sells or offers to sell goods or services
through direct sellers, but does not include an entity which is engaged in a Pyramid Scheme or money
circulation scheme;
(f) "money circulation scheme" means the schemes defined in clause (c) of section 2 of the Prize Chits and
Money Circulation Schemes (Banning) Act, 1978 (43 of 1978);

<!-- page 10 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(g) "mis-selling" means selling a product or service by misrepresenting in order to successfully complete a
sale and includes providing consumers with misleading information about a product or service or omitting
key information about a product or providing information that makes the product appear to be something it
is not;
(h) "prospect" means a person to whom an offer or a proposal is made by a direct seller to join a direct
selling entity;
(i) "Pyramid Scheme" means a multi layered network of subscribers to a scheme formed by subscribers
enrolling one or more subscribers in order to receive any benefit, directly or indirectly, as a result of
enrolment or action or performance of additional subscribers to the scheme, in which the subscribers
enrolling further subscribers occupy a higher position and the enrolled subscribers a lower position,
resulting in a multi-layered network of subscribers with successive enrolments:
(j) "saleable", in relation to goods or services, means unused and marketable goods or services which have
not expired, and which are not seasonal, discontinued or used for special promotion;
(k) "sensitive personal data" means the sensitive data or information as specified from time to time under
section 43A of the Information Technology Act, 2000 (21 of 2000);
(l) "State" includes a Union territory;
(2) Words and expressions used herein and not defined, but defined in the Act shall have the meanings
respectively assigned to them in the Act.
4. Mandatory maintenance of records.–– Every direct selling entity shall maintain at its registered office,
either manually or electronically, all such documents as are required under any law for the time being in
force, including the following documents or records, as may be applicable, namely:–
(a) Certificate of Incorporation;
(b) Memorandum of Association and Articles of Association;
(c) Permanent Account Number and Tax Deduction and Collection Account Number;
(d) Goods and Services Tax registration; (e) Goods and Services Tax Returns;
(f) Income Tax Returns;
(g) Balance Sheet, Audit Report and such other relevant reports; (h) Register of direct sellers;
(i) Certificate of Importer-Exporter code (in case of imported goods)
(j) License issued under the Food Safety and Standards Authority of India Act, 2006 (34 of 2006) for the
purposes of manufacture or sale of food items;
(k) License and Registration Certificate issued under the Drugs and Cosmetics Act, 1940 (23 of 1940) for
the purposes of manufacture or sale of drugs, including Ayurvedic, Siddha and Unani drugs and
Homoeopathic Medicines;
(l) Certificate of Registration of Trademark.
5. Obligations of direct selling entity.–– (1) Every direct selling entity shall–
(a) if a company, be incorporated under the Companies Act, 2013 (18 of 2013) or if a partnership firm,
be registered under the Partnership Act, 1932 (9 of 1932) or if a limited liability partnership, be registered
under the Limited Liability Partnership Act, 2008 (6 of 2009);
(b) have a minimum of one physical location as its registered office within India;
(c) make self-declaration to the effect that it has complied with the provisions of these rules and is not
involved in any Pyramid Scheme or money circulation scheme;
(d) maintain proper and updated website with all relevant details of that entity, including the documents
or records specified in rule 4, the self-declaration specified in clause (c), contact information which is
current and updated, details of its nodal officer, grievance redressal officer, its management, products,
product information, price and grievance redressal mechanism for consumers;

<!-- page 11 -->

[ा II—ण 3(i)]

ा ा ा : ऄाा

11

(e) own, hold or be the licensee of a trademark, service mark or any other identification mark which
identifies that entity with the goods or services to be sold or supplied, but shall not give commissions,
bonus or incentives on sale of goods or services of which it is not the owner, holder or licensee of
trademark, service mark or other identification marks;
(f) obtain all applicable trade registrations and licenses, including Permanent Account Number and Goods
and Services Tax Registration;
(g) get all information provided by it on its website duly certified by a Company Secretary.
Explanation.––For the purposes of this clause, "Company Secretary" means a person as defined in
clause (c) of sub-section (1) of section 2 of the Company Secretaries Act, 1980 (56 of 1980);
(h) have a prior written contract with its direct sellers in order to authorize them to sell or offer to sell its
goods or services, and the terms of such agreement shall be just, fair and equitable;
(i) ensure that all its direct sellers have verified identities and physical addresses and issue identity cards
and documents only to such direct sellers;
(j) create adequate safeguards to ensure that goods and services offered by its direct sellers conform to
applicable laws;
(k) be liable for the grievances arising out of the sale of goods or services by its direct sellers.
(2) Every direct selling entity shall provide the following information on its website in a clear and
accessible manner, which shall be displayed prominently to its users, namely:––
(a) registered name of the direct selling entity;
(b) registered address of the direct selling entity and of its branches;
(c) contact details, including e-mail address, fax, land line and mobile numbers of its customer
care and grievance redressal officers;
(d) a ticket number for each complaint lodged through which the complainant can track the status of the
complaint;
(e) information relating to return, refund, exchange, warranty and guarantee, delivery and shipment, modes
of payment, grievance redressal mechanism and such other information which may be required
by the consumers to make informed decisions;
(f) information on available payment methods, the security of those payment methods, the fees or charges
payable by users, the procedure to cancel regular payments under those methods, charge-back options, if
any, and the contact information of the relevant payment service provider;
(g) total price of any goods or service in single figure, along with its break-up price showing all compulsory
and voluntary charges, including delivery charges, postage and handling charges, conveyance charges and
the applicable tax;
(h) provide correct and complete information at pre-purchase stage to enable buyers to make informed
purchase decisions, and such information shall, in addition to the mandatory declarations to be provided
under the Legal Metrology (Packaged Commodities) Rules, 2011, contain the following information,
namely:––
(i)

the name of purchaser and seller;

(ii)

description of goods or services;

(iii)

quantity of goods or services;

(iv)

the estimated delivery date of goods or services;

(v)

the process of refund;

(vi)

warranty of the goods;

(vii) exchange or replacement of goods in case of it being defective;
(viii) all contractual information required to be disclosed by or under any law for the time being in
force.

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(3) No direct selling entity shall adopt any unfair trade practice in the course of its business or
otherwise, and shall abide by the requirements specified in any law for the time being in force.
(4) All products of a direct selling entity shall comply with the declarations to be made under the Legal
Metrology Act, 2009 (1 of 2010).
(5) Every direct selling entity shall store sensitive personal data within the jurisdiction of India, in
accordance with the applicable law for the time being in force and shall take appropriate steps to ensure
protection of such data provided by a consumer and also ensure adequate safeguards to prevent
access or misuse of such data by any unauthorized person.
(6) Every direct selling entity shall, having regard to the number of grievances ordinarily received by
such entity from persons in India, establish an adequate grievance redressal mechanism and appoint one or
more grievance redressal officers for redressal of consumers' grievances and display the current and
updated name, contact details including telephone number, email address and designation of such officer on
its website, and the details of its website shall also be prominently printed on the product information sheet
or pamphlet.
(7) Every direct selling entity shall ensure that the grievance redressal officer referred to in sub-rule (6)
acknowledges the receipt of any consumer complaint within forty-eight working hours of receipt
of such complaint and redresses the complaint normally within a period of one month from the date of
receipt of the complaint and in case of delay of more than a month, reasons for the delay, and
the actions taken on the complaint, are informed to the complainant in writing.
(8) Every direct selling entity shall appoint a nodal officer who shall be responsible for ensuring
compliance with the provisions of the Act and the rules made thereunder, and to ensure compliance with
any order, or requisition, made in accordance with the provisions of any other law for the time being in
force or the rules made thereunder.
(9) Every direct selling entity shall establish a mechanism for filing of complaints by consumers through
its offices or branches or direct sellers, either in person or through post, telephone, e-mail or website.
(10) Every direct selling entity shall maintain a record of all its direct sellers, including their identity proof,
address proof, e-mail and such other contact information.
(11) Every direct selling entity shall, on the request in writing made by a consumer after the purchase of
any goods or services, provide him with the information regarding any direct seller from whom such
consumer has made a purchase, and such information shall include the name, address, e-mail, contact
number and any other information which is necessary for making communication with such direct seller for
effective dispute resolution.
(12) Every direct selling entity shall ensure that the advertisements for marketing of goods or services are
consistent with the actual characteristics, access and usage conditions of such goods or services.
(13) No direct selling entity shall, directly or indirectly, falsely represent itself as a consumer and post
reviews about its goods or services or misrepresent the quality or features of any of its goods or services.
(14) A direct selling entity which explicitly or implicitly vouches for the authenticity of the goods or
services sold, or guarantees that such goods or services are authentic, shall bear the liability in any action
related to the authenticity of such goods or services.
(15) Notwithstanding the distribution system adopted by it, a direct selling entity shall monitor the
practices adopted by its direct sellers and ensure compliance with these rules by means of legally binding
contract with such direct sellers.
(16) Every direct selling entity shall maintain a record of relevant information allowing for the
identification of all direct sellers who have been delisted by the direct selling entity and such list shall be
publicly shared on its website.
(17) Every direct selling entity shall become a partner in the convergence process of the National
Consumer Helpline of the Central Government.
6.

Obligations of direct seller.–– (1) Every direct seller shall––

(a) have a prior written contract with the direct selling entity for undertaking sale of, or offer to sell, any
goods or services of such entity;

<!-- page 13 -->

[ा II—ण 3(i)]

ा ा ा : ऄाा

13

(b) at the initiation of any sale representation, truthfully and clearly identify himself, disclose the identity
of the direct selling entity, the address of place of business, the nature of goods or services sold and the
purpose of such solicitation to the prospect;
(c) make an offer to the prospect providing accurate and complete information, demonstration of goods
and services, prices, credit terms, terms of payment, return, exchange, refund policy, return policy, terms of
guarantee and after-sale service;
(d) provide an order form to the consumer at or prior to the time of the initial sale, which shall identify the
direct selling entity and the direct seller and shall contain the name, address, registration number or
enrollment number, identity proof and contact number of the direct seller, complete description of the
goods or services to be supplied, the country of origin of the goods, the order date, the total amount to be
paid by the consumer, the time and place for inspection of the sample and delivery of
goods, consumer's rights to cancel the order or to return the product in saleable condition and avail full
refund on sums paid and complete details regarding the complaint redressal mechanism of the direct selling
entity;
(e) obtain goods and service tax registration, Permanent Account Number registration, all applicable trade
registrations and licenses and comply with the requirements of applicable laws, rules and regulations for
sale of a product;
(f) ensure that actual product delivered to the buyer matches with the description of the product given;
(g) take appropriate steps to ensure the protection of all sensitive personal information provided by the
consumer in accordance with the applicable laws for the time being in force and ensure adequate safeguards
to prevent access to, or misuse of, data by unauthorized persons.
(2) A direct seller shall not––
(a) visit a consumer's premises without identity card and prior appointment or approval;
(b) provide any literature to a prospect, which has not been approved by the direct selling entity;
(c) require a prospect to purchase any literature or sales demonstration equipment;
(d) in pursuance of a sale, make any claim that is not consistent with claims authorized by the direct selling
entity.
7. Duties of direct selling entity and direct seller .––Subject to the provisions of Chapter VI of the Act,
relating to Product Liability, the following shall be the duties of direct selling entity and direct seller, as
may be applicable, namely:––
(i) Every direct selling entity and every direct seller shall ensure that––
(a) the terms of the offer are clear, so as to enable the consumer to know the exact nature of offer
being made and the commitment involved in placing any order;
(b) the presentations and other representations used in direct selling shall not contain any product
description, claim, illustration or other element which, directly or by implication, is likely to mislead the
consumer;
(c) the explanation and demonstration of the goods or services offered are accurate and
complete, particularly with regard to price and, if applicable, to credit conditions, terms of payment,
cooling-off periods or right to return, terms of guarantee, after-sales service and delivery;
(d) the descriptions, claims, illustrations or other elements relating to verifiable facts are capable of
substantiation;
(e) any misleading, deceptive or unfair trade practices are not used;
(f) direct selling is not represented to the consumer as being a form of market research;
(g) the promotional literature, advertisement or mail contain the name and address or telephone number of
the direct selling company, and include the mobile number of the direct seller;

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(h) direct selling shall not state or imply that a guarantee, warranty or other expression having substantially
the same meaning, offers to the consumer any rights in additional to those provided by law, when it does
not;
(i) the terms of any guarantee or warranty, including the name and address of the guarantor, shall be easily
available to the consumer and limitations on consumer rights or remedies, where permitted by law, shall be
clear and conspicuous;
(j) the remedial action open to the consumer shall be clearly set out in the order form or other
accompanying literature provided with the goods or service;
(k) the presentation of the offer does not contain or refer to any testimonial, endorsement or supportive
documentation unless it is genuine, verifiable and relevant;
(l) when after-sales service is offered, details of the service are included in the guarantee or stated
elsewhere in the offer and if the consumer accepts the offer, information shall be given on how the
consumer can activate the service and communicate with the service agent;
(m) products, including, where applicable, samples, are suitably packaged for delivery to the consumer and
for possible return, in compliance with the appropriate health and safety standards;
(n) unless otherwise stipulated in the offer, orders shall be fulfilled within the delivery date proposed to the
consumer at the time of purchase and the consumer shall be informed of any undue delay as soon as it
becomes apparent or comes within the knowledge of the direct selling entity or the concerned direct seller;
(o) in cases of delay under clause (n), any request for cancellation of the order by the consumer shall be
granted, irrespective of whether the consumer has been informed of the delay, and the deposit, if any, shall
be refunded as per the cancellation terms proposed to the consumer at the time of purchase, and if it is not
possible to prevent delivery, the consumer shall be informed of the right to return the product at the direct
selling company's or the direct seller's cost as per the procedure for return of the goods proposed to the
consumer at the time of purchase;
(p) right of return offered by that entity shall be in writing;
(q) whether payment for the offer is on an immediate sale or installment basis, the price and terms of
payment shall be clearly stated in the offer together with the nature of any additional charges such as
postage, handling and taxes and, whenever possible, the amounts of such charges;
(r) in the case of sales by installment, the credit terms, including the amount of any deposit or payment on
account, the number, amount and periodicity of such installments and the total price compared with the
immediate selling price, if any, shall be clearly shown in the offer;
(s) any information needed by the consumer to understand the cost, interest and terms of any other form of
credit is provided either in the offer or when the credit is offered;
(t) unless the duration of the offer and the price are clearly stated in the offer, prices shall be maintained for
a reasonable period of time;
(u) the procedure for payment and debt collection shall be determined in writing before any contract is
signed and it shall be such as to avoid undue inconvenience to the consumer, making due allowance for
delays outside the consumer's control;
(v) the provisions of the Legal Metrology Act, 2009 (1 of 2010) and the rules framed thereunder shall
be followed.
(ii)

A direct selling entity or direct seller shall not––

(a) indulge in fraudulent activities or sales and shall take reasonable steps to ensure that participants do not
indulge in false or misleading representations or any other form of fraud, coercion, harassment, or
unconscionable or unlawful means;
(b) engage in, or cause or permit, any conduct that is misleading or likely to mislead with regard to any
material particulars relating to its direct selling business, or to the goods or services being sold by itself or
by the direct seller;
(c) indulge in mis-selling of products or services to consumers;

<!-- page 15 -->

[ा II—ण 3(i)]

15

ा ा ा : ऄाा

(d) use, or cause or permit to be used, any fraudulent, coercive, unconscionable or unlawful means, or cause
harassment, for promoting its direct selling business, or for sale of its goods or services;
(e) refuse to take back spurious goods or deficient services and refund the consideration paid for goods and
services provided;
(f) charge any entry fee or subscription fee.
(3) A direct selling entity and a direct seller shall comply with the requirements of all relevant laws,
including payment of taxes and deductions thereunder.
(4) A direct selling entity and a direct seller shall not induce consumers to make a purchase based upon the
representation that they can reduce or recover the price by referring prospective customers to the direct
sellers for similar purchases.
8. Persons not to be engaged in the business of direct selling.–– No person who is convicted, or bankrupt
during the last five years prior to his association with the business of direct selling, or a person of unsound
mind, shall be engaged in the business of direct selling.
Explanation.––For the purpose of this rule, the term 'Bankrupt' shall have the same meaning as assigned to
it in clause (3) of section 79 of the Insolvency and Bankruptcy Code, 2016 (31 of 2016).
9. Application of e-commerce rules.–– The direct sellers as well as the direct selling entities using
e-commerce platforms for sale shall comply with the requirements of the Consumer Protection (eCommerce) Rules, 2020.
10. Prohibition of Pyramid Scheme and money circulation scheme.––No direct selling entity or direct
seller shall––
(a) promote a Pyramid Scheme or enroll any person to such scheme or participate in such arrangement in
any manner whatsoever in the garb of doing direct selling business;
(b) participate in money circulation scheme in the garb of doing direct selling business.
11. Monitoring by State Government.–– For ensuring compliance of these rules by direct selling entity
and direct sellers, every State Government shall set up a mechanism to monitor or supervise the activities of
direct sellers and direct selling entity.
12. Inconsistencies in laws.–– Where any regulation made under the Reserve Bank of India Act, 1934
(2 of 1934) is applicable to a direct selling entity governed under these rules, the provisions of such
regulations shall prevail over the provisions of these rules to the extent of inconsistency.
13. Contravention of rules.–– The provisions of the Act shall apply for any contravention of these rules.
[F. No. J-10/9/2018-CPU]
ANUPAM MISHRA, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
KUMAR
and Published by the Controller of Publications, Delhi-110054. MANOJ
VERMA
Digitally signed by MANOJ KUMAR
VERMA
Date: 2021.12.28 22:59:57 +05'30'
