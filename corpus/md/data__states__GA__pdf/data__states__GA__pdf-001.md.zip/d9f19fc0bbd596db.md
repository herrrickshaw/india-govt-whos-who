---
doc_id: "d9f19fc0bbd596db"
source_url: "https://edc-goa.com/wp-content/uploads/2024/10/CMRY-2023-Notification.pdf"
ministry: "EDC Limited, Goa"
title: "Download CMRY 2023 Notifications"
date: ""
pages: 10
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "45e96a000d85552f"
---

<!-- page 1 -->

i =
us |
| TW
11//2/2 at
शट
Government of Goa,
Finance Department,
Debt Management Division,
Secretariat, Porvorim, Bardez - Goa. 403521
Nota hone (0032) 2419695 Email: - usbud2-sectzoa@nicin Phone (0832) 2419695 Email: - usbud2-sect.zoa@nic.in
2 Od arial =e
9.2/6/2013-Fin(DMU)/5 5/ Dated:-08/12/2023
NOTIFICATION
Government of Goa is pleased to notify the "Chief Minister's Rojgar Yojana"
(CMRY-2023) Scheme. The eligibility criteria and the operational guidelines in
respect of the said Scheme are transcribed here overleaf for the ready reference of the
general public. The scheme shall be effective from 01/04/2023 to 31/03/2026
a Chief Minister’s Rojgar Yojana(CMRY)- 2023
PURPOSE OF To provide self-employment (rojgar) opportunities to
LOAN | Goan youth by way of financial assistance to new as
| well as expansion of existing units for setting up
| | projects for eligible activities.
1 | ELIGIBILITY | | शि
हिम >>. ame
a | Age : | 18 years to 50 years (Relaxable by 5 years in case of
widow, disabled person, scheduled caste, scheduled
| tribe. other backward class person).
। | ।
शिषषषक य | The loan repayment period should not exceed 60)
| years of the age of the borrower. ।
| |
b_ | Educational :| VII" passed: (Relaxable in deserving cases).
| fe 4 ive “ग av
| Qualification Preference will be given to those who have |
| | technical/professional qualifications. These will include
| | candidates trained by GHRSSIDC, Agriculture
| Department, Forest Department or = any other
| | Government Training Scheme.
| |
c | Family Income |: No income ceiling
व | Residence Proof : | Permanent resident of the area for at least 15 ‘years.
| | Documents required— Residential Certificate or School
| | Leaving Certificate or passing Certificate from Goa
| Board/Goa_ University or any document to the |
| satisfaction of the sanctioning aie
Those who do not fulfill the domicile condition, but are
LY cave | ermaatan scat | married to a person of Goan origin, and whose spouse
| | is a resident of Goa for atleast 15 years, shall also be
|
5४
> Vo \ pam (47-85 डी
Ax 7 1~\—
ps af
| र्तर _

<!-- page 2 -->

og N
| | |_| elizible for assistance, provided he/she is settled in Goa |
| | | fora minimum period of one year |
; प | ationalize |
e Detaulter/Non ‘} should not be a defaulter to any nationalized |
Eligibility bank/finaneial institution/cooperallve bank. |
|
| ; er other subsid
Further, a person already assisted under other su y |
linked scheme will not be eligible under this scheme, |
| unless otherwise relaxed / specified. ; |
| clivities execpt
2 | ACTIVITIES :) All economically viable/legal activities so |
COVERED dealing in alcohol & tobacco. The scheme sha
cover the following activities:
e CSC-VLE ( Common Service Centres ~ Village
Level Enterprises)
e Start-ups (for fixed assets only)
e Homestay, Bed and Breakfast (for fixed assets
| only) Ps
| © Civil/Electrical Contractors (for fixed assets
only) =
LOAN
ASSISTANCE
a Project Cost Professional Maximum
क मर 25.00 Lakhs
= 1.1.. Rs. 25.00 Lal
including those undergoing
| special training
| programmes conducted by
authorised Government
Departments/
Corporations. ®
Others. Maximum
Rs. 20.00 Lakhs
b DITC Share Capital
General 50% of Project
(Men) Cost
DITC Share | Women /OBC | 50% of Project
Capital /Disabled Cost
80% of Project
SC/ST Cost |
2
_ oe 7 |

<!-- page 3 -->

०3१०
0 क२फा
General(Men) | 40 f Pre t
Cost
Woman i of Project
11 lerm One Cost
toa Disabled
SC/ST 1 of Project
Cost
Promoter's |
Contribution | General [Ola oP Project
| | (Men) Cost
|] Promoter's | Woman/ 5% of Project
|| x OBC/ Cost
| Contribution Disabled
| | 15% of Project
| [SESE Cost SC/S1 Cost
= ¢ | Interest Rate : | Both EDC Term loan & DITC Share Capital @ 8%
< p.a. |
[Penal Interest. -: | Penal interest @ 2% p.a. on the defaulted amount for
the defaulted period of EDC Term loan & DITC share
capital shall be charged. =I
la | Margin for Loan : General (Men) 10%
Woman/ OBC/ | 5% |
| Disabled/SC/ST
1 | Moratorium Period Maximum one year (at the discretion of the Task Force
| | Committee)
f Security : | First charge of mortgage/hypothecation of fixed/current
| | | assets.
| Collateral : | 1) Loans upto Rs.2.00 lakh:
| Personal guarantee by the applicant & spouse. as a
~ Confirming Party, in case of married person and of
parent/relative, in case of unmarried person and also for |
non transport loans, where minimum 75% (50% in case
of SC/ST applicant) of the loan amount is secured 3
way of hypothecation / mortgage of the fixed assets
being financed.
2) Loans above Rs.2.00 lakh & upto Rs.6.00 lakhs: above Rs.2.00 lakh & upto Rs.6.00 lakhs:
The applicant has to provide third party personal
guarantee of one or more guarantors depending upon
the loan amount in addition to the guarantee of the
spouse in case of married person and parent/relative in
case of unmarried person. Such a guarantor could be
one of the following:-
(a An employee of the Government of Goa/
Corporations of Government of Goa/ Autonomous
| | Body/ Government Aided and other Institutions
ONES ATISUELONS |
3

<!-- page 4 -->

|. ett क १२२०२० ० २१ त ह अ... कीं
| | | | controlled by the Government of 0d |
| | | (2) Any other person with navable income of minions
| } | Ry 8.00 lakh for preceding J years with take-home |
1 | salary commensurate to the EME of the loan:
| | (9) An employee of Companies of repute to the |
| | satixfirction of the TRC: provided they are roger
| emplovees working for more than 10 yoars,
(QA person owning an nnencumbered immovable |
property in’ Goa, the value of which should |
commensurate to the loan amount
{
Notarised copy of ownership documents of the ।
unencumbered immovable property owned by the |
guarantor/s, commensurate lo the loan amount to be
produced,
~
The guarantor should not be a defaulter with any
। financial institution/bank and shall have suitable
capacity to service the loan being, extended,
Loans upto | :| The ‘Task Force Committee could consider proposals
lakh upto Rs.1.00 lakh depending, upon genuineness of the
applicant and the project, based on an affidavit of self”
declaration of having obtained/in the process of
obtaining all clearances from competent authorities, as
applicable to their proposed venture.
The Joint Managing, Director, EDC Limited or in his
absence General Manager, EDC Limited (Link
Officer) is authorized to sanction CMRY loans upto ~
Rs. 2.00 lakh and vehicle loans up to Rs. 6.00 lakhs.
4 | Disbursement : | Disbursement of loan is made to the “suppliers on the
basis of proforma invoice in respect of machinery,
furniture and furnishing, working capital, vehicle ete.
The supplier will have to furnish an undertaking, in the
prescribed format stating that the items/vehicle will be
delivered as specified in proforma invoice.
Physical verification of the assets acquired and
valuation of the furniture/furnishing will be carried out.
5 Repayment |! Vehicle — ग ‘Syears |
Schedule Other | Sto 7 years”
activities
ee Repayment schedule includes — the moratorium
| ‘
\

<!-- page 5 -->

चळ
| | | period of maximum L year in monthly EMIs, |
| |
। 6 Default in|: | [the borrower fails to repay the loan amount including |
| repayment interest thercon as per repayment schedule, the same |
| shall be recovered from the borrower/guarantor under
| | provisions of the Goa Public Monies (Recovery of
| | dues) Act, 1986 (PMRA)/ Land Revenue Code (LRC)
| | and/or section 29, 30, & 31 of SFC'’s Act, or
SARPFAESI Act or Recovery of Debts Due to Bank Act
LL | (DRT) and/or any other provisions of Law. _|
7 | Application 3
| form/fees | 7a | Application | Eligible persons shall apply in |
| | form prescribed — application form
| | priced at Rs.100/- giving |
details of their project along
with requisite documents. |
€ 7b ee Duly completed application |
form shall be submitted to
EDC Ltd. with ~~ non- |
refundable processing fee of :
Rs.500/- (plus GST
! applicable) for loans up to
Rs.5.00 lakh:
Rs.5,000/- (plus GST
applicable) for loans above
Rs.5.00 lakh.
(50% to be paid on
= submission of the form and
50% to be paid after sanction
of the loan).
However, SC/ST applicant
will be charged application
fee of Rs.200/- (plus GST
applicable) irrespective of
loan amount.
S
ie

<!-- page 6 -->

EE — अ... cost
8 Subsidy Interest rebate 75% (a) 6% p.a.) OF EDC Term loan
and DELC share capital shall be credited to the loar
account of the beneficiary a8 subsidy, subject to
fulfilling terms and conditions for availing the said
subsidy, This subsidy shall be subject to entitlement
and reimbursement of the amount — by the
Government as per the laid down norms
This Subsidy shall be cligible on all the fixed assets
and current assets
This subsidy shall be released to borrowers who pay
EMIs regularly & the unit being fully operational.
9 Training )s) The Scheme envisages compulsory entrepreneurship
training of upto 3 days for the beneficiary after the
| | Joan is sanctioned but before disbursement of the loan.
| This may be exempted and made optional based on
recommendations of Task Force Committee on case to
| case basis. TC | an)
10 | Other Terms & |: e Projects without fixed assets are not eligible,
Conditions working capital will be restricted to 40% of the
project cost.
¢ Cost of land cannot be covered under project
| cost.

e Existing units and the units that have already

availed any Government Subsidy (under PMRY,
| REGP, PMEGP, CMEGP or any other schemes
| of Government of India or State Government) |
| are not eligible.
|

e CMRY Loan will be restricted to one loan ~
(existing/new) per family. |

e For financial assistance of Rs.10.00 lakh or more

| the Applicant shall submit a project report.
| © No takeover of existing loans will be considered.

e TFC and EDC management shall decide on all
matters related to interpretation/implementation/
operation of the scheme and it will be referred to
the Government only if required.

e Incase the unit is found ineligible on account of
misrepresentation/ miscalculation, the amount of
interest rebate shall be repayable forthwith by
the unit/party if not shall become recoverable as
arrears of Land Revenue.

1 [Task Force | =| A Task Force Committee (TFC) comprising of the
6

<!-- page 7 -->

८
वेष”
Committee | | following will serutinize and sanction applications |
under the Scheme:
/ Vice Chairman of EDC or any Chairman
other Director of EDC, as
| | approved by the Government |
>| Director EDC Board Member |
| | |
i Representative of Directorate of | Member
| Industries, Trade & Commerce
| (not below the rank of GM
| ae DITC) | |
\|4 | Representative of Finance | Member \
| | | Department (not below the rank of
| | | Under Secretary) | |
| 115 | Technical person (Govt. Nomince), Member
6 Professional in the field -| Member
| Chartered Accountant.
7 |. M.D. ~ EDC Limited Member
12 | Validity a : | The scheme shall be valid for a period of 3 years w.e.f.
| 01/04/2023 to 31/03/2026.
Operational Guidelines for implementing the
Chief Minister's Rojgar Yojana (C. MR Y- 2023) Scheme
The CMRY 2023 Scheme shall become operational for the period from 01/04/2023 to

31/03/2026.

All the applications being sanctioned after 01/04/2023 shall be considered as per the
provisions of the CMRY-2023 Scheme.

1. Project cost — Normally the size of the projects to be considered for financing under
the scheme, should be within the prescribed limits of Rs.25.00 lakh for professionals
and technically qualified persons and Rs.2000 lakh for others.

The maximum amount considered under the scheme for financing purchase of premises
would be to the extent of 70% (for professionals and technically qualified persons) and
50% (for others) of the maximum eligible project cost limits. respectively. However, the
applicant in such cases would have to self fund the entire cost, beyond the respective
scheme limits of the project on their own, as additional promoter’s contribution, in
addition to raising normal promoter’s contribution, as per the Scheme.

For financial assistance of Rs.10.00 lakh or more the applicant shall submit a

project report.

Financial assistance towards commercial vehicles shall be considered only for self
driven vehicles by the applicant.

Projects without Capital Expenditure are not eligible.

Working capital will be restricted to 40% of the project cost.

7

<!-- page 8 -->

Cost of land cannot be covered under projcet cost
CMRY Loan will be restricted to one loan (existing/new) per family.
2 Collateral An ease of loans above Rs.6.00 lakh, the notarized copy of property ee
c/pure ne
of the immovable property owned by the puarantor or borrower! spouse/parent cou ce
accepted i
: , CIs S s adequate
The guarantor to be considered shall have adequate carnings and/or assets so 4 to adequ ly
; a र i as suarantors
service the credit facility in case of default, EDC shall serutinize and accept only guarantor
having servicing capacity commensurate to the loan extended.
a : क ८ three ths
3. Moratorium period - Initial moratorium period to be extended shall be three mon
ps, ३ > . ee oa
normally, ‘TEC shall have the discretion to extend any period beyond thr months upt
maximum of 12 months as recommended by the EDC Appraisal officer.

4 Repayment Schedule The maximum repayment period could be 5/7 years. However, the
Task Foree Committee may restrict the repayment period of certain specified er
based on past experience of financing such activities or of specific proposals based on the
connected documents submitted by the applicant.

5. Interest rebate shall be extended to all the loan accounts which are sanctioned under the
scheme subject to terms and conditions as below: ~

a) Should have satisfactory dealing with EDC.

b) Should avail the disbursement of sanctioned amount within 1 year from the date of
sanction of loan.

C) Verification report of unit being in operation from Recovery department. The
interest rebate shall be extended to the regular units which are in operation. In case
the units are found to be out of operation, the interest rebate extended to the
beneficiary shall be reversed and debited to the loan account.

d) Interest rebate will be calculated on the disbursed amount.

e) In case the beneficiary pre-closes the loan account within 3 years from the first date
of disbursement of loan, then the interest rebate extended to the beneficiary shall be ~
reversed and debited to the loan account.

f) In case of misrepresentation or miscalculation, the amount of interest rebate
extended shall be repayable. forthwith, by the borrower and the same shall be
recovered as arrears of land revenue.

6. Misrepresentation{alsification — If an applicant is found to have submitted
false/fraudulent/forged information/documents or misrepresented or found ineligible to be
fulfilling any of the provisions of the scheme, the entire loan along with the disbursed
DITC share capital shall be repayable immediately at the highest interest rate charged by
EDC for its term loan scheme during the loan period. In case of non-payment EDC shall
recover this amount along with interest and other charges from the borrower/guarantors
under the Goa Public Monies (recovery of dues) Act, 1986 (PMRA)/Land Revenue Code
(LRC) and/or section 29, 30 and 31 of SFC’s Act. or SARFAESI Act or Recovery of Debt
due to Bank Act (DRT) and/or any other provisions of law.

7 EDC shall report annually the performance and status of the scheme at the end of the
financial year to the Government afier placing the same before its Board of Directors.

8
|
|

<!-- page 9 -->

. on
2)
8, EDC reserves the right to carry out any modifications for effective and efficient operation
of the scheme
9. In case of any grievances arising out of the claims of the beneficiaries concerning the
scheme, the same shall be referred to the Task Force Committee (TFC) appointed by the
Government for suitable decision,
10. TFC and EDC management shall be authorized to decide on all matters related to
interpretation: implementation/operation of the scheme and it will be referred to the
Government only if required.
This supersedes all Notifications issued carlier in this regards.
By Order and in the name of the
82002. ‘oa,
Zar
e@ (Pranab G. Bhat)
Under Secretary Finance (Budget-II)
To,
The Director, Directorate of Printing & Stationery, Government Printing Press,
Panaji - Goa, with a request to publish the Notification in the forthcoming Official
Gazette.
Copy to:
The Managing Director, EDC Limited, EDC House, Panaji — Goa.
2. The OSD to Chief Minister, O/o Chief Minister, Secretariat, Porvorim Goa.
@ 3. Guard file.
4. 0/८.
{

<!-- page 10 -->

hes iyo

(९) 7/7/””
Wey x

Government of Goa,

Finance Departinent,

Debt Management Division.
Secretariat, Porvorim, Bardez — Gon. 403521
No.2/6/2013-Fin(DMU)/| 27 Dated:-06/03/2024
NOTIFICATION
Read: Notitication No. 2-6-2013-Fin(DMU)/S551_ dated 08/12/2023. -

In partial modification to Notification read in preamble. The Government of
Goa, further amends the “Chief Minister’s Rozgar Yojana” (CMRY-2023) Scheme
(hereinafter referred to as the “Scheme”) as follows:-

@ In clause No.10 “Other Terms and Conditions” of the scheme, the third expression
ie. “the Existing units and the units that have already availed any Government
° Subsidy(under PMRY, REGP, PMEGP, CMEGP or any other schemes of
Government of India or State Government) are not eligible”, may be read as “the
Existing units and the units that have already repaid earlier loans of PMRY, REGP.
PMEGP, CMEGP or any other schemes, by production of No dues for the said loan
may be considered under CMRY Scheme”.
The rest of the contents of the said Notification read in the preamble shall
remain unchanged.
न By Order Ws in ag
we Oe of Goa
CoN
o
A
(Pranab G. Bhat)
Under Secretary Finance (Budget-II)
To, .
The Director, Directorate of Printing & Stationery, Government Printing Press,
Panaji - Goa, with a request to publish the Notification in the forthcoming
Official Gazette.
Copy to:- ..
_ithe Managing Director, EDC Limited, EDC House, Panaji- Goa.
2. The OSD to Chief Minister, O/o Chief Minister, Secretariat, Porvorim Goa.
3. Guard file. Q
4.0 “pam — Gs MG Art pe
: ले
Ye 4
Sip 1 ती
