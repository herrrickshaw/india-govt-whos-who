---
doc_id: "571ecea8dfae70b1"
source_url: "https://gpb.goa.gov.in/documents/committees/eofc-composition-2025-28.pdf"
ministry: "Government Polytechnic, Bicholim, Goa"
title: "View the office order  ↗  PDF, 264 KB  (opens in a new window)"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "36f4e703becc10e0"
---

<!-- page 1 -->

SS ८  .
1 OEY
| GOVERNMENT OF GOA |
GOVERNMENT POLYTECHNIC :
MAYEM, BICHOLIM — GOA
e-mail:gpbicholim@rediffmail.com |
No. GPB/ADM/MISC/15/2023/ 1१ Date: -25709/2025. |
|
ORDER |
|
In order to facilitate inclusive education for all including Person with
Disabilities as per AICTE guidelines. Principal is pleased to constitute the “Equal
Opportunity Facilitation Cell” (EOFC) comprising of the following members for
the period of 03 years from 2025-26, 2026-27, 2027-28.
= Narayan Patil, Incharge Exam Section Nodal Officer /Co- |
ordinator of EOFC |
"2. ७. Renuka Figueiredo, Director of Owl House Member
|. _| Neurodiverse Skilling Center, Aldona-Goa |
13. | Ms. Vibha Shet Verenkar, Head Clerk Member |
la Ms. Anushka Manerkar, 1 year Electrical Engg. Member _
F |e Snehal Naik, I/e HOD (Civil Engg. Dept.) ——
6.} Ms. Sonam Pilgaonkar, Lecturer in Chemistry Member Secretary |
m4 The roles and responsibilities of the cell is enclosed herewith as contained in
Circular No. F. No. AICTE/P&AP/Misc/2022 dated 05/08/2022. ©
(Dr. गट. Naik)
Principal
Copy to:-
1. All the concerned. | H ov's] Te Hoy र
XX Personal files of the staff members.
3. Office file
4. Guard file.
