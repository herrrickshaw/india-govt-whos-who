---
doc_id: "c0dc2f9db036cd2a"
source_url: "https://www.gsidcltd.com/wp-content/uploads/2026/03/EOI-152-CorrigendumI.pdf"
ministry: "Goa State Infrastructure Development Corporation Limited (GSIDL), Goa"
title: "EOI-152 CorrigendumI"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bec8d052475145bd"
---

<!-- page 1 -->

GOA STATE INFRASTRUCTURE DEVELOPMENT CORPORATION LTD.

“DEVELOPMENT OF THE KOTI TIRTH CORRIDOR AT THE SITE OF SHRI.
SAPTAKOTESHWAR, DIVAR, TISWADI, GOA.”
NOTICE NO:- GSIDC/ENGG./EOI-152/2025-26 DATED 06TH MARCH 2026
CORRIGENDUM - I
Date: 23rd March 2026
SR.
NO.

CHAPTER
/ CLAUSE
NO.

1)

Notice for
Expression
of Interest

PRESENT CLAUSE /
CONDITION

The

interested

MODIFIED CLAUSE / CONDITION

Architectural/ The interested Architectural/ consultancy firms should

consultancy firms should submit submit the following details with documents so as to
the

following

details

with reach the GSIDC office latest by 06/04/2026 before

documents so as to reach the 16.00 Hours.
GSIDC

office

latest

by The Date and Time of opening of Expression of Interest

27/03/2026 before 16.00 Hours.

(EOI): 07/04/2026 at 16.30 hours in the Conference
Hall, 7th Floor, GSIDC, Panaji.

CONTRACTOR

Page 1 of 1

EMPLOYER
