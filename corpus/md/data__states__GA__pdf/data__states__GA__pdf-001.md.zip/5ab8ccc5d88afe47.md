---
doc_id: "5ab8ccc5d88afe47"
source_url: "https://dhs.goa.gov.in/cms-gov-be/storage/app/public/uploads/newsNotices/wV3ROC7z3zoDoeRCD0Uq0cdaTnw5BMn0YUQcWBBi.pdf"
ministry: "Health Services Department, Goa"
title: "corrigendum tender no 113PT"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "1bd7e30a9ed7da15"
---

<!-- page 1 -->

phe Be | a
9 ] @ \
GOVERNMENT OF GOA
- Medical Store Depot (MSD), ;
Directorate of Health Services, Campal, Panaji, Gos 403 00) .
Smail; msddhsgoa@yahoo.in /ddmsd-heal.gou@gov.in_Ph. NOS. EADS9TSS ल msddhsgos@yahoo.in /ddmsd-heal.goa@gov.in Ph. Nos. 2225646/5540/5668
CORRIGENDUM
The date of pre-bid mentioned on the tender notice 00 ;
113/PT/DHS/MSD/2026-27/913 dated: 23/07/2026 may be
read as 04/08/2026 at 10:30 am instead of 04/09/2026 1030
am 2 : प i lag
‘ च 7 | । 7
The new technical excel sheet may which Joes not have the
import license column since import license is not asked in the
tender notice may be kindly be utilized.
प्त 1)
- पसन एकी |
| af pees
