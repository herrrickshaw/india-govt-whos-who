---
doc_id: "c6fabbb98dc64c67"
source_url: "https://gazetteer.goa.gov.in/wp-content/uploads/2024/02/Order-of-Editorial-Board-of-Goa-Gazetteer.pdf"
ministry: "Gazetteer Department, Goa"
title: "Order of Editorial Board of Goa Gazetteer"
date: ""
pages: 28
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "845556ccebc9f2de"
---

<!-- page 1 -->

Reg. No. RNP/GOA/32/2021-2023

RNI No. GOAENG/2002/6410

SERIES II No. 5

Panaji, 4th May, 2023 (Vaisakha 14, 1945)

PUBLISHED BY AUTHORITY

Note:- There are two Extraordinary issues to the Official
Gazette, Series II No. 4 dated 27-04-2023 as
follows:—
(1) Extraordinary dated 27-04-2023 from pages
137 to 138 regarding Notifications from
Department of Finance.
(2) Extraordinary (No. 2) dated 28-04-2023 from
pages 139 to 140 regarding Notifications from
Department of Finance.

GOVERNMENT OF GOA
Department of Archives
–––

Order
No. 1/297/2014/HA-167
In pursuance to Clause 5 of the Right to
Information Act, 2005, Shri Rajiv Kudke, Asst.
Programming Officer and Smt. Vidhya Gaude, LDC
are hereby appointed as Public Information Officer
and Assistant Public Information Officer
respectively regarding matters related to Archives
in their respective jurisdiction for the Department
of Archives to deal with the applications received
from the public under the Right to Information Act,
2005.
The Public Information Officer shall be
responsible for the preparation and publication of
the manuals from time to time as per the said Act.
The Assistant Public Information Officer shall
ensure that the application received by him/her for
information under the Right to Information Act,
2005 are submitted on top priority to the Public
Information Officer concerned so as to furnish the
information to the Applicant within the stipulated
period and within the provisions of the Act.
Dipak Bandekar, Director (Archives) &
ex officio Addl. Secretary.
Panaji, 28th April, 2023.

Department of Co-operation
Office of the Registrar of Co-operative Societies
–––

Order
No. 15/223/2008/ADT/RCS/Vol. IV/302
Sub.:

Directives for verifying statutory
compliance by Societies under the Goa
Co-operative Societies Act, 2001 before
processing their proposals at Zonal
Offices.

[Under Section 69 of the Goa Co-operative
Societies Act, 2001 (Goa Act No. 36 of 2001)]
In exercise of the powers conferred upon the
undersigned Registrar of Co-operative Societies
under Section 69 of the Goa Co-operative Societies
Act, 2001 (Goa Act No. 36 of 2001) (hereafter referred
to as ‘Act’) and to ensure proper implementation of
Co-operative provisions, proper management of the
business of all the Co-operative Societies functioning
in the State of Goa, the following Directives for
verifying certain statutory compliances by Societies
under the Goa Co-operative Societies Act, 2001
before processing any type of proposals in respect of
such Societies at Zonal Offices are hereby issued for
strict compliance by all the authorities as under.
Whereas, every registered Society is required to
comply with the provisions of Sections 72, 73, 74 &
81 of the Goa Co-operative Societies Act, 2001 (Goa
Act 36 of 2001) in a time bound manner within the
time limits laid down under the Act and Rules.
And whereas, the aforesaid compliances are
utmost necessary to ensure smooth functioning of
the Society and to ensure transparency in
management of the affairs of the Society. Hence, noncompliance of these particular statutory provisions
is not at all tolerable and raises serious questions on
the continuation of legal existence and well being
of the Society.
In some cases it is observed that Societies have
failed to comply with the aforesaid statutory

Suggestions are welcomed on e-mail: dir-gpps.goa@nic.in

141

<!-- page 2 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
provisions within the given time limit. In such cases
it is necessary to ensure that defaulting societies
are forced to prepare the receipt & payment
statements/Trial balance, Trading/Manufacturing
Accounts, Profit & Loss Account, Income &
Expenditure Account, and Balance Sheet and
thereafter to complete Audit of their Books of
Accounts and place the Audit report before General
Body Meeting of the Society and file the annual
return.
Now therefore, in order to compel such
defaulting Societies to comply with the statutory
provisions of Sections 72, 73, 74 and 81 of the Act,
it is hereby directed as under.
1. The Unit Incharge (Assistant Registrar or
Co-operative Officer) of every Society shall,
before processing any request for amendment
of Bye Laws, change in classification, opening
of new branches, appointment/extension of
dedicated RCS Nominee, Authorisation/
/extension of authorization of sales and
recovery officer or any other proposal relating
to any subject, shall in the first place, verify
whether the applicant society has complied
with provisions of Sections 72, 73, 74 & 81 of
the Act and the proposal shall be processed
only if the aforesaid provisions are duly
complied with by the applicant Society.
2. The Unit Incharge (Assistant Registrar or
Co-operative Officer) shall, while forwarding
every proposal of any society under his/her
jurisdiction to the Head Office, shall
compulsorily record a Certificate in the
covering letter/proposal/checklist/note stating
that “This Society has duly complied with
provisions of Sections 72, 73, 74 and 81 of the
Act for the last co-operative/financial year
closed on 31-03-20___ for which the statutory
time limit for compliance ended on 30-09-20___.”
3. The year and date in such certificate shall be
incorporated by taking into consideration the
latest statutory time limit under the Act that
has expired. Like for processing proposals till
30-09-2023, the timeline of Co-operative/
/financial year 2021-22 ending on 31-03-2022
(timeline over on 30-09-2022) would be verified
for compliance, because although subsequent
year 2022-23 has closed on 31-03-2023, the
statutory timeline for filing of Audit report
would be over on 30-09-2023. Hence any
proposals taken up for processing on or after
01-10-2023, the compliance of latest year
2022-23 (timeline will be over on 30-09-2023)
will have to be checked.

142

4TH MAY, 2023
4. In cases where the Unit Incharge finds that the
applicant society has not complied with the
aforesaid statutory requirements, he/she shall
immediately follow the guidelines issued vide
Order No. 15/223/2008/ADT/RCS/Vol. IV/3245
dated 02-12-2022 read with Corrigendum
No. 15/223/2008/ADT/RCS/Vol. IV/3332 dated
12-12-2022 and shall immediately take steps to
complete Audit of concerned Society. In all
such cases, the reply to the Society shall be
sent within 7 days from the date of receipt of
proposal, bringing to their attention the non
compliance of statutory provisions and
informing that their proposals shall not be
processed till the aforesaid statutory provisions
are complied with by the Society.
5. In all cases where the defaulting Society is a
Urban Credit Society or is doing the business
of accepting deposits and granting loans, the
Unit Incharge shall immediately submit a
proposal to Head Office for imposing
restrictions u/s. 68 of the Act for prohibiting
the Society from accepting any deposits and
sanctioning any loans till they complete all
their pending Audits and statutory compliances.
The above directions shall be strictly complied
with by all Unit Incharge and any violation by
forwarding incomplete proposals without such
certificate or by allowing such defaulting Societies
to carry on the business of credit despite their
default shall be deemed as misconduct under the
C.C.S. (Conduct) Rules, 1964 and shall be liable for
disciplinary proceedings under the C. C. S. (C. C. A.)
Rules, 1965.
Given under the seal of this office.
Vishant S. N. Gaunekar, Registrar (Co-operative
Societies) & ex officio Joint Secretary (Co-operation).
Panaji, 26th April, 2023.
————

Order
No. 3/23/Urban Credit/TS-II/PZ/2021/RCS/319
Read: 1. Notification No. 3/3/Urban Credit/TS II/
PZ/2017/RCS/Suppl.5306
dated
10-02-2020.
2. Order No. 21-1-99-TS/Shiroda/RCS/2162
dated 29-09-2020.
3. Order No. 3/23/Urban Credit/TS-II/PZ/
/2021/RCS/377 dated 25-05-2021.
4. Order No. 3/23/Urban Credit/TS-II/PZ/
/2021/RCS/716 dated 06-06-2022.
5. Letter No. SUCCS/ASRO/2023-24/07
dated 24-04-2023.

<!-- page 3 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

[Under Section 91D of the Goa Co-operative
Societies Act, 2001 (Goa Act No. 36 of 2001)].

General Manager of their Society to act as
Sale-cum-Recovery Officer for their society.

Whereas, vide Notification read at No. 1 above
issued by the Government exercising the powers
under Section 126A of the Goa Co-operative
Societies Act, 2001 (Goa Act No. 36 of 2001) (hereafter
referred to as ‘Act’), the provision of sub-section (1)
of Section 91D of the Act was modified and the
Registrar of Co-operative Societies was authorized
to appoint Officers of Co-operative Credit Societies,
V. K. S. S. Societies having credit counters and
Multipurpose Societies as Recovery Officer/Sale
Officer upon receipt of individual proposals subject
to the terms and conditions as may be incorporated
in the Order.

And whereas, the Goa Co-operative Societies
(Amendment) Act, 2001 (Goa Act No. 34 of 2021) has
been brought into force w.e.f. 1st April, 2023 (except
few provisions) vide Notification No. 60/137/
/Amendment/2020/TS-I/RCS/4579 dated 28-02-2023
published in Official Gazette, Series I No. 47,
Extraordinary No. 3 dated 28-02-2023. By virtue of
amended provisions of Section 91D of the said Act,
the Registrar is competent to issue a special Order
to empower an Officer of Federal Institution or Chief
Executive as defined under Clause (9) of Section 2
of the said Act to effect recovery in accordance
with provisions of Section 91D of the Act.

And whereas, vide Order read at Sr. No. 2 above
issued by the Registrar of Co-operative Societies,
the General Manager of The Shiroda Urban
Co-operative Credit Society Ltd., [Reg. No. ARCS/
/CZ(8)60/ADM/91], Shiroda, Goa was delegated with
the powers to recover certain sums by attachment
and sale of property vested in Registrar of
Co-operative Societies under Section 91D of the Goa
Co-operative Societies Act, 2001 read with Rule 124
of the Goa Co-operative Societies Rules, 2003 subject
to the following conditions:-

Now, therefore in exercise of the powers conferred
under Section 91D of the Goa Co-operative Societies
Act, 2001, I, the undersigned Registrar of
Co-operative Societies do hereby further extend the
delegation of powers/empower the General
Manager of The Shiroda Urban Co-operative Credit
Society Ltd. [Reg. No. ARCS/CZ(8)60/ADM/91),
Shiroda, Goa vide above read Orders for a further
period of one year with effect from 26-05-2023 to
25-05-2024.

1. The Officer appointed and delegated with the
powers of Sales-cum-Recovery Officer shall
work under the general guidance, superintendence
and control of the Asstt. Registrar of
Co-op. Societies, Arbitration/Execution, South
Zone, Ponda-Goa.

All the terms and conditions mentioned in the
Order read at Sr. No. 2 above shall continue to apply.
The undersigned reserves the right to withdraw
this Order at any stage without assigning any
reasons.

2. The Board of Directors of the Society shall be
fully responsible along with the Chairman
for any acts in contravention of the Act, Rules
and Bye-laws.

Vishant S. N. Gaunekar, Registrar (Co-operative
Societies) & ex officio Joint Secretary (Co-operation).

3. The Board of Directors shall review the
performance of the Chairman of every month
and ensure compliance.
And whereas, the powers delegated vide order
dated 29-09-2020 read at serial No. 2 above
remained in force till 31-03-2021 and same was
extended from time to time last being extended
vide order read at serial No. 3 above for a period of
one year w.e.f. 26-05-2022 and ending on 25-05-2023.
And whereas, vide letter read at No. 4 above, The
Shiroda Urban Co-operative Credit Society Ltd.,
Shiroda, Goa has requested to grant further
extension to the said delegation of powers to the

Given under the seal of this office.

Panaji, 27th April, 2023.
————

Order
No. 9-26-2023/EST/RCS/5096
Read: 1. Order No. 43/2/2005/TS/RCS/1246 dated
26-06-2018.
2. Order No. 43/2/2005/TS/RCS/5931 dated
11-03-2020.
In supersession of the Orders read above and all
earlier orders to that effect and in exercise of the
powers conferred under sub-sections (1) and (2) of
Section 5 of the Right to Information Act, 2005
(Central Act 22 of 2005), I, the undersigned Registrar
of Co-operative Societies, Government of Goa do
hereby designate the following Officers as the
Public Information Officers (P.I.O.), Assistant Public

143

<!-- page 4 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

Information Officers (A.P.I.O.) and the First Appellate Authority (F.A.A.) in the respective offices for respective
subjects/wings/sections as below.
Sr.
No.

Name & Address
of the Office/
/Public Authority

Particular Wing/
/Section/Branch
of the office

Public Information
Officer (P.I.O.)
designated

Assistant Public
Information
Officer (A.P.I.O.)
designated

First Appellate
Authority
(F.A.A.)
designated

1

2

3

4

5

6

1) Establishment
Administration,
Accounts Sections
of the Zonal Office
2) All residuary
matters of Zonal
office not specifically
covered under other
PIOs

Assistant Registrar
of Co-operative
Societies who is
the Head of Office
incharge of Zonal
Office

Head Clerk

Deputy Registrar
of Co-operative
Societies (Admin.),
Head Office,
Panaji.

In respect of all
information
pertaining to
Co-operative
Societies held at
Zonal Office under
the provisions of the
Goa Co-operative
Societies Act, 2001
and Rules framed
thereunder

Officer who is
Unit Incharge
of concerned
Society at Zonal
Office

Officer/Official
who is sub-unit Incharge
of concerned
Society at
Zonal Office

Deputy Registrar
of Co-operative
Societies at Head
Office who is the
District Level
Incharge (D.L.I.)
of respective
Zonal Office.

In respect of all
Officer who is
information
Unit Incharge
pertaining to
of concerned
Co-operative
Society at Zonal
Societies held by
Office to whom
any
the information
a) Registrar’s
relates
Nominees
b) Auditors on
panel of
Auditors
c) Reconciliators
d) Administrators
e) Liquidators
f) Other such persons
or a committee
appointed or
constituted by the
Registrar under the
provisions of the Goa
Co-operative Societies
Act, 2001 and Rules
framed thereunder

Officer/Official
who is sub-unit Incharge
of concerned
Society at
Zonal Office
to whom the
information
relates

Deputy Registrar
of Co-operative
Societies at Head
Office who is
the District
Level Incharge
(D.L.I.) of
respective Zonal
Office.

1. O/o. Asst. Registrar of
Co-operative Societies,
North Zone, Government
building complex,
Mapusa, Goa

Given under the seal of this office.
Vishant S. N. Gaunekar, Registrar (Co-operative Societies).
Panaji, 31st March, 2023.

144

<!-- page 5 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

Office of the Asstt. Registrar of Co-operative Societies

Department of General Administration

–––

–––

Notification
In exercise of the powers vested in me under
Section 8 of the Goa Co-operative Societies Act,
2001, “The Shetye Plaza Ponda Co-operative
Housing Maintenance Society Limited, Upper Bazar,
Opp. Ponda Municipal Market, Ponda-Goa”-Goa is
registered under code symbol No. RCSPZ2023240028.

Notification

Pankaj V. Marathe, Asst. Registrar (Co-operative
Societies), Ponda Zone.
Ponda, 21st April, 2023.
Certificate of Registration
“The Shetye Plaza Ponda Co-operative Housing
Maintenance Society Limited, Upper Bazar, Opp.
Ponda Municipal Market, Ponda-Goa”-Goa has been
registered on 21-04-2023 and its bears registration
code symbol No. RCSPZ2023240028 and its classified
as “Co-operative Housing Society” under sub-classification “No. 7-(d)-Co-operative Housing
Maintenance Society” in terms of Rule 8 of the Goa
Co-operative Societies Rules, 2003.
Pankaj V. Marathe, Asst. Registrar (Co-operative
Societies), Ponda Zone.
Ponda, 21st April, 2023.
———uuu———

Department of Fisheries
Directorate of Fisheries
–––

Order
No. 2-1-81-FSH
In exercise of the powers conferred by
sub-sections (1) and (2) of Section 4 of the Goa
Marine Fishing Regulation Act, 1980 (Act No. 3 of
1981), the Government of Goa, having regard to the
need to conserve fish, hereby prohibits fishing by
fishing vessels fitted with mechanical means of
propulsion and by means of trawl-net and
purse-seine net, except fishing by registered
motorized canoes using gill nets only, and fitted
with outboard or inboard motors, of upto 10 HP
capacity, as a means of propulsion, along the sea
coast of the State of Goa and the territorial waters
of the State of Goa, with effect from 1st June, 2023
till 31st July, 2023 (both days inclusive).
By order and in the name of the Governor of
Goa.
Dr. Shamila Monteiro, Director and ex officio/Joint
Secretary (Fisheries).
Panaji, 27th April, 2023.

No. 2/1/2017-GAD-III/1530
In pursuance of Section (12) read with Section
(11) of the Goa Municipalities Act, 1968 (Act No.16
of 1968) read with the Notification No. U-11030/2/73-UTL dated 28-06-1973 of the Government of India,
Ministry of Home Affairs, published in the Gazette
of India, Extraordinary, Part II, Section 3, sub-section (ii),
the Government of Goa hereby declares Friday, the
05th May, 2023 (Vaisakha 15, Saka 1944) as a “paid
holiday” being the “Polling Day” for General
Election to Ponda and Sanquelim Municipal Council
for the voters of the said General Elections.
The aforesaid paid holiday shall be in addition to
the holidays indicated in the Government
Notification No. 37/3/2022-GAD-III/3661 dated
19-10-2022, published in the Official Gazette, Series
II No. 30 dated 27-10-2022, to the workers of the
following establishments, provided that they are
the voters for the aforesaid General Election.
(i) industrial workers of the State of Goa;
(ii) daily wage workers of the Government
Departments and State Government
Industrial Departments;
(iii) commercial and industrial workers of private
establishments in the State of Goa;
(iv) workers of all private establishments;
(v) daily wage/casual workers employed in any
business, trade, industrial undertakings or
any other establishments;
(vi) workers of the institutions governed under
the explanation to Section 25 of the
Negotiable Instrument Act, 1881 (Act 26 of
1881).
By order and in the name of the Governor of
Goa.
Shaila G. Bhosle, Under Secretary (GA-I).
Porvorim, 26th April, 2023.
———uuu———

Department of Goa Gazetteer
–––

Order
No. 1/5/2023-24/GAZ-402
Read: Government Order No. RD/EST/GAZ/295/
/69 dated 2nd May, 1970.
Government Order No. RD/EST/GAZ/215
dated 11th December, 1970.

145

<!-- page 6 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

Government Order No. RD/EST/GAZ/215
dated 3rd March, 1971.
Government Order No. RD/EST/GAZ/215
dated 24th June, 1971.
Government Order No. RD/EST/GAZ/215
6th March, 1972.
Government Order No. 10/2/80-82/WET
dated 19th June, 1982.
Government Order No. 10/2/80-82/EDN
dated 15th September, 1987.
Government is pleased to re-constitute Goa
Gazetteer Editorial Board under Chairmanship of
Chief Secretary, Goa consisting of following
Members:
1. Chief Secretary
—
2. Secretary, Goa Gazetteer
—
3. Executive Editor, Maharashtra —
Gazetteer Department
4. Chief Editor, Karnataka
—
Gazetteer Department
5. Prof. (Dr.) Kiran Budkuley,
—
Former Professor of English
6. Prof. (Dr.) Ganesha Somayaji, —
Goa University
7. Prof. Narayan B. Dessai,
—
Educationist
8. Prof. (Dr.) Varsha V. Kamat, —
Professor of History
9. Executive Editor,
—
Goa Gazetteer Department

Chairperson.
Member.
Member.

Order
No. 3/9/2023-IND/97
Government of Goa is pleased to appoint the
Director of Industries, Trade and Commerce, Panaji,
Goa as a “Nodal Officer” from Industries Department
to co-ordinate with Open Network for Digital
Commerce (ONDC) incorporated as non-profit
company under the Companies Act, 2013,
designated as a public digital infrastructure based
on open-source technologies and standards,
enabling wide-scale participation by digital
ecosystem players in India, in order to take forward
the remarkable digital commerce reform initiative
of the country.

Member.
Member.

By order and in the name of the Governor of
Goa.

Member.

Amalia O. F. Pinto, Under Secretary (Industries).
Member.
Member.
Member
Secretary.

Shri Balaji Sudas Shenvy, Archivist (Publication)
from Department of Archives holding additional
charge of The Executive Editor, Goa Gazetteer shall
be over all in-charge of the staff and administration
and other work connected with the preparation of
Gazetteers.
The non-official members of the Editorial Board
shall be entitled to T.A. at the rate admissible to
Class I Officers for attending the matters of the
Board.
This is issued with the approval of the
Government vide U.O. No. 2529/F dated 19-03-2023.
By order and in the name of the Governor of
Goa.
Shri Menino D’Souza, IAS, Secretary (Goa
Gazetteer).

146

–––

Nodal Officer may reach out to Shri Shireesh
Joshi (Mobile +919971849999) and Shri Saransh
Agrawal (Mobile +918975292381) for planning the
next steps and any clarification, if required.

The tenure of the committee shall be three years
from the date of publication in the Official Gazette.

Panaji, 21st April, 2023.

Department of Industries

Porvorim, 28th April, 2023.
———uuu———

Department of Labour
––
Notification
No. 28/02/2023-LAB/242
The following Award passed by the Labour
Court-II, at Panaji-Goa on 10-03-2023 in Case No.
LC-II/IT/28/12 is hereby published as required under
Section 17 of the Industrial Disputes Act, 1947
(Central Act 14 of 1947).
By order and in the name of the Governor of
Goa.
Amalia O. F. Pinto, Under Secretary (Labour).
Porvorim, 27th March, 2023.
––––

THE LABOUR COURT-II
GOVERNMENT OF GOA
AT PANAJI
(Before Shri Suresh N. Narulkar, Hon’ble
Presiding Officer)
Case No. LC-II/IT/28/12

<!-- page 7 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

Shri Anand G. Gauns,
H. No. 84, Nadora, via Colvale,
Nadora, Bardez-Goa.
…… Workman/Party I
V/s
The Goa Urban Co-op.
Bank Ltd., Margao-Goa.
…… Employer/Party II
Party-I/Workman represented by Shri A. V. Nigalye.
Party-II/Employer represented by Adv. Shri G. K.
Sardessai.
Panaji, dated: 10-03-2023.
AWARD
1. In exercise of the powers conferred by Clause
(c) of sub-section (1) of Section 10 of the Industrial
Disputes Act, 1947 (Central Act 14 of 1947), the
Government of Goa, by Order dated
28-05-2012, bearing No. 28/03/2012-LAB/263
referred the following dispute for adjudication to
the Industrial Tribunal of Goa. Pending the matter
for its adjudication before the Hon’ble Industrial
Tribunal-cum-Labour Court, Panaji-Goa, the Govt.
of Goa transferred the present reference for its
adjudication to this Labour Court II, vide its order
No. 28/02/2011-Lab/86 dated 09-02-2016.
“(1) Whether the action of the Goa State
Co-operative Bank Limited, Margao-Goa, in
terminating the services of Shri Anand G.
Gauns, Clerk, by way of dismissal vide letter
of Dismissal dated 01-06-2011, is legal and
justified?
(2) If not, what relief the Workman is entitled to?”
2. On receipt of the reference, a case was
registered under No. LC-II/IT/28/12 and registered
A/D notice was issued to the Parties. In pursuance
to the said notice, the Parties put in their
appearance. The Workman/Party-I (for short
‘Workman’), filed his Statement of Claim on
01-08-2012 at Exb-6. The facts of the case in brief as
pleaded by the Workman are that the Employer/
/Party II (for short, “Employer”) is an Apex
Co-operative Bank in the State of Goa. He stated
that the employees of the Employer Bank are
members of Goa State Co-operative Bank Employees’
Union, which is a registered union. He stated that
the Employer has entered into settlements with its
employees union from time to time on improving
wages and service conditions of its employees. He
stated that the Workman is employed as “Clerk”
with the Employer since 04-10-1985. He stated that
initially he worked in Head Office Branch of the
Bank and thereafter worked at Panaji and Margao
Branch of the Bank. He stated that he is the member
of the said union and also a treasurer of the said
Union since last for 4 years. He stated that the

wages and service conditions of the employees and
Officers of the bank are governed by settlements
signed between the Bank and its Union namely
Goa Urban Co-operative Bank Employees Union and
Goa Urban Co-operative Bank Officers Association
from time to time. He stated that the last wage
settlement has been signed with employees Union
has been signed on 03-10-2011 and earlier on
27-06-2001.
3. He stated that on 28-05-2011, he was instructed
by Asst. Branch Manager of Margao Branch of the
Employer Bank Shri Rebello that he should go to Axis
Bank Margao with cash to deposit in that bank. He
stated that as per the rotation of work in the branch,
it was not his duty to go to others bank with cash. He
stated that he informed the Asst. Branch Manager
that Shri Pradeep Chodnekar normally carries cash
to other bank and that this work should be allowed
to him and that he has a lot of work in his Department.
He stated that Shri Rebello informed him that Shri
Pradeep Chodnekar has gone for a meeting at the
Head Office of the bank at Panaji, and that he should
do the work of depositing the cash in Axis Bank.
4. He stated that there after a cash of Rs. 30,00,000/was removed from the safe in the strong room of the
bank by Shri Rebello and Cashier Mrs. Vandana Kane
and it was put in a briefcase by Sub-staff Shri Prasad
Shirodkar. He stated that the key of the briefcase
was given to him. He stated that however, the
physical possession of the briefcase was not given to
him. He stated that thereafter, he went to his
department to continue with his work. He stated
that there was heavy work in his department on that
day. He stated that the work in the department
consists of SND, Despatch, writing and withdrawing
of cheques of salaried employees, Day Book, sale of
loan application form, preparing establishment
expenses and salary vouchers/respective H.O. IBTS,
and entering liability of shares refund application
etc. He stated that SND agents were waiting for him
at that time. He stated that going to other bank with
cash or to deposit cash in other banks was not the
duty allotted to him as per the roster or rotation of
work that day. He stated that after the said briefcase
was locked, Shri Prasad Shirodkar brought it out of
the strong room. He stated that he sat in the same
row where he was sitting leaving two chairs vacant
in between and sitting on the forth chair to his left,
holding briefcase containing cash in his hand. He
stated that when the cash is to be taken to other
banks, it is taken in a taxi and the taxi is arranged by
the Branch Manager/Asst. Branch Manager. He

147

<!-- page 8 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
stated that he was therefore expecting the Asst.
Branch Manager to inform about arrival of Taxi. He
stated that he was busy doing his allotted work as
per the roster during that period. He stated that at
about 11.05 a.m., one person to whom he had never
seen before came to his department. He stated that
the said person was dark in colour, medium built, of
medium height and had a tilak on his forehead. He
stated that the said person asked him about
commission rates for purchasing demand drafts. He
stated that he informed him that his department was
not D/D department and asked him to go to D/D
department. He stated that after a few minutes, he
heard Shri Prasad Shirodkar saying as to where the
briefcase containing cash was. He stated that he
looked at him and around the place and found that
the briefcase was missing. He stated that no one
knew how it happened within a short time. He stated
that there was no commotion in the branch after the
theft.
5. He stated that though he is not involved in the
said theft, the Employer summarily dismissed him
from service by letter dt. 01-06-2011 on the false charge
of misappropriation of funds and other false charges
without even following the procedure prescribed in
the bi-partite settlement and in contravention of the
rules applicable to him. He stated that the amount
in the bank is insured with Oriental Insurance
Company Ltd. He stated that in case of theft while
cash in transit from one bank to another or from the
bank premises, the insurance company has to make
good the loss. He stated that the Employer has filed
his claim before Oriental Insurance Company for an
amount of Rs. 30,00,000/- to be paid to the bank on
account of the theft. He stated that the same is being
processed by the Insurance Company. He stated that
he has sought under Right to Information Act from
the said Insurance Company regarding details of the
same and whether the said amount of theft has been
paid to the bank. He stated that he has not yet
received information. He stated that as soon as the
same is available, he shall produce the same before
this Hon’ble Tribunal.
6. He stated that on 30-05-2011 at around 4.30 p.m.
the Branch Manager asked him to give a statement
in writing about the incident. He stated that he
informed the Branch Manager that he is not
conversant with how to write such matters and that
he needed help and that he would give the statement
in writing on the next day. He stated that on the
next day i.e. on 31-05-2011 at around 10.00 a.m. he
gave the Branch Manager a written statement as
desired by him. He stated that at around 5.00 p.m. on
31-05-2011,the Branch Manager returned the written
statement to him and asked him to change the

148

4TH MAY, 2023
statement as desired by him. He stated that he went
on changing the statement as dictated by the
Manager and the statement became shabby, so the
Branch Manager told him to re-write neatly and bring
the same on the next day. He stated that on
01-06-2011, he did not attend the duty as he was on
sick leave which has been sanctioned by the bank.
He stated that on 02-06-2011, he was refused the
employment by the bank. He stated that vide letter
dt. 31-05-2011, he submitted explanation as sought
by the Bank Manager regarding the incident that
had happened on 28-05-2011. He stated that the said
explanation was send by the Registered A/D to the
Branch Manager and a copy of which was send to
the Head Office, at Panaji which received on
04-06-2011.
7. He stated that on 02-06-2011, he reported for
work as usual at Margao Branch at around 9.45 a.m.
However, the Branch Manager refused him
employment stating that his services stood
terminated and that he need not report for work
hereafter. He stated that the Branch Manager did
not assign any reason for the same. He stated that
the said refusal of employment was in violation of
principles of natural justice. He stated that aggrieved
by the said decision of the Bank, he wrote a letter dt.
02-06-2011 to the Manager of the Bank at Margao,
with a copy to the Dy. Labour Commissioner, Govt. of
Goa, Margao-Goa stating the facts and the illegality
of the action of the Employer and demanding
reinstatement in service with full back wages and
continuity in services with costs. He stated that since
there was no response from the management, the Dy.
Labour Commissioner intervened in the dispute and
fixed a joint meeting with the Employer. He stated
that as there was no possibility of a settlement, the
Dy. Labour Commissioner sent a failure of conciliation
of proceedings report on dt. 01-11-2011.
8. He submitted that at the time of termination, a
notice of one month was not given nor was one
month’s pay in lieu of notice was paid. He submitted
that no charge sheet was issued before termination
alleging any acts of misconduct against him. He
submitted that no enquiry in accordance with
principles of natural justice was held before
termination of his service. He submitted that all
allegations levelled in dismissal letter dt. 01-6-2011
are false. He submitted that at the time of
termination, retrenchment compensation as required
under Section 25F of the I.D. Act, 1947 was not paid.
He submitted that at the time of termination,
principles of last come first go as per provisions of
Section 25G of the I.D. Act was not followed. He
submitted that the termination of his services is in

<!-- page 9 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
violation of principles of natural justice. He
submitted that since the date of termination w.e.f.
01-06-2011, he has not been paid wages and/or
subsistence allowance as per provisions of service
rules. He submitted that at the time of termination,
besides the salary for the month of May, 2011 he has
not been paid any money whatsoever such as notice
pay, retrenchment compensation, leave wages,
gratuity and subsistence allowance. He submitted
that the Bank Branch had no adequate security at
the time of incident which took place in the Bank
branch. He stated that there was no CCTV, no
emergency alarm system, no security personnel etc.
He stated that the cash was removed out of the strong
room of the Bank by Asst. Manager Mr. Alex Rebello
and kept in the Bank premises before he called for
Taxi to the branch for carrying cash to Axis Bank
instead of following security measures of first calling
the Taxi and then removing cash from the strong
room/safe deposit vault. He submitted that his
dismissal from service by the Employer w.e.f.
01-06-2011 is illegal and unjustified as it is in violation
of the principles of natural justice as well as violations
of the provisions of settlement dt. 27-06-2001 without
issue of charge sheet and without holding of enquiry.
9. He stated that since the date of his termination
he is unemployed and is supported by his family
members. He stated that he tried getting job at five
places but none of them called him for job after
coming to know that he has been dismissed by the
Employer. He stated that since the date of his
termination, he is facing severe hardships and is
finding difficult to sustain himself as well as to pursue
his case before this Hon’ble Tribunal. He stated that
he has tried to secure gainful employment, but he
has not been successful in spite of his efforts. He
stated that he is 53 years of age. The Workman
therefore prayed that he be reinstated in service with
full back wages plus interest and continuity in
service.
10. The Employer controverted the case of the
Workman by filing its written statement dt.
21-12-2012 at Exb. 7. The Employer, as and by way of
preliminary objections, stated that the present
reference filed by the Workman is bad in law and
hence not maintainable, that the present dispute of
the Workman is not an “Industrial Dispute” as
defined under the I.D. Act, 1947 and that there is
non-application of mind by the appropriate
Government while referring the present dispute.
11. The Employer stated that the Workman was
employed with them as a Clerk in Margao Branch.
The Employer stated that as a part of its routine
process is required to deposit excess cash in any of
the bank with which they have a Current Account.

4TH MAY, 2023
The Employer stated that on 28-05-2011 Mr. Alex
Rebello, Asst. Branch Manager of Margao Branch
and the joint custodian and the main Cashier Mrs.
Vandana Kane withdrew from the said deposit vault
a sum of Rs. 30,00,000/- for depositing the said
amount in the Current Account of the bank in Axis
bank, Margao Branch. The Employer stated that the
said amount was in the denomination of 500 notes of
Rs. 1,000/- each and 5000/- notes of Rs. 500 each.
The Employer stated that the said amount was
thereafter handed over by Mr. Alex Rebello and Mrs.
Vandana Kane to the Workman and Mr. Prasad
Shirodkar sub-staff. The Employer stated that the
Workman alongwith Mr. Prasad Shirodkar verified the
amount and placed the same in a gray colour
briefcase. The Employer stated that the said amount
was handed over to both of them within the enclosure
where the same deposit vault is situated. The
Employer stated that the said amount was found
missing from the custody of the Workman and Mr.
Prasad Shirodkar. The Employer stated that neither
of them could account for the said cash which was
entrusted to them. The Employer stated that the
Workman and Mr. Prasad Shirodkar also refused to
give a statement in spite of written instructions of
the Branch Manager vide his letter dated 30-05-2011
and 01-06-2011 respectively. The Employer stated
that the Workman alongwith Mr. Prasad Shirodkar
conspired to commit theft of Rs. 30,00,000/- of the
bank. The Employer stated that the theft took place
at around 11.00 a.m. on 28-05-2011. The Employer
stated that considering the gravity of misconduct
and in view of the fact that such acts of misconduct
which has placed the bank and institution which is
the custodian of public money into disrepute and
has obviously shaken the confidence of the public in
the ability of the bank to take care of their valuable
assets, they decided that it will not be in the interest
of the bank to retain the Workman in service any
longer and the interest of the bank and the public
will be best served by dismissing him with immediate
effect. The Employer stated that by letter
dt. 01-06-2011, the Workman was informed that in
view of gravity of misconduct committed by him, his
service stands terminated by way of dismissal with
immediate effect. The Employer submitted that the
commission of theft is a serious misconduct and
warrants punishment of dismissal. The Employer
therefore submitted that the termination is legal and
justified and warrants non interference with the
decision of its managements.
12. The Employer submitted that the reference of
the dispute of adjudication before this Tribunal of
the Workman was beyond the scope of powers of
appropriate Government in as much as the dispute

149

<!-- page 10 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
that was referred was not an industrial Dispute has
defined under the I.D. Act, 1947 nor was there any
application of mind by the appropriate of
Government while referring the Disputes and thus
the reference is ex-facto bad in law. The Employer
submitted that the last settlement was entered in
June, 2001 for the period effective from 01-01-1999
and was valid up to 31-12-2002. The Employer stated
that after the expiry of settlement period, the next
settlement was entered on 3-10-2011 with
retrospective effect from 01-01-2011 and for a period
of 4 years from 01-01-2011 till 31-12-2014 and is to be
continued to be remained in force thereafter until
such time as it is terminated by either party as
prescribed under the law for time being in force. The
Employer stated that as per settlement dt. 2001,
Clause XVI(5) it is stated that the termination of
services shall be in writing and shall be signed by
the manager. The Employer stated that as per the
settlement, the manager means the Officer managing
the bank. The Employer stated that Mr. Vilas M.
Narkar was earlier designated as the General
Manager/Secretary to the Board and the
nomenclature of the General Manager has been
changed to the Managing Director. The Employer
stated that the Managing Director is the Officer
managing the Bank. The Employer stated that the
letter of termination dt. 01-06-2011 was signed by
the Managing Director as per bye laws of the bank.
The Employer submitted that considering the nature
of offence, the gravity of misconduct had placed the
bank and the institution which is the custodian of
public money to disrepute and had obviously shaken
the confidence of the public in the ability of the bank
to take care of their valuable assets and that
conducting an enquiry could not be interest of the
bank and the public will be best served by dismissing
the employee immediately, it was decided to dismiss
the employee and accordingly by letter dt.
01-06-2011 the Workman was dismissed from the
service.
13. The Employer stated that as the theft by the
Workman was on 28-05-2011, though explanation was
sought from the Workman by the Branch Manager,
the Workman refused to give statement. The
Employer stated that in spite of written instructions
on 30-05-2011, the Workman declined to submit any
explanation. The Employer stated that thereafter the
Workman remained absent from duty on 01-06-2011
and on the morning of 02-06-2011 the Branch
Manager handed over the letter of dismissal dt.
01-06-2011 to the Workman in the presence of Mr. H.
D. Ghantkar from the Head Office of the Bank. The
Employer stated that the Workman read the copy of
the letter and refused to sign. The Employer stated

150

4TH MAY, 2023
that the Workman was informed that on his refusal,
the letter will be displayed on notice board of the
branch and the Head Office. The Employer stated
that thereafter, the Workman left the branch and the
said copy of dismissal letter was displayed on the
notice board of Margao Branch and also on the notice
board of Head Office. The Employer submitted that
as the Workman refused to accept the dismissal letter
on 02-06-2011, the said letter was posted by Regd.
A/D to the Workman on his available address with
the bank and a copy was posted on the notice board
of Margao Branch as well as Head Office of the Bank.
The Employer stated that in response to the letter dt.
30-05-2011 of the Branch Manager that he submitted
his explanation that was received by the
management on 10-06-2011. The Employer stated
that though the letter is dt. 31-05-2011 the same is
posted on 09-06-2011.
14. The Employer submitted that the investigation
by the Insurance Surveyor are still on. The Employer
submitted that even if the claim is settled, the party
cannot deny that he committed theft of the said
amount of Rs. 30,00,000/-. The Employer submitted
that there was a theft of 5,00,000/- at the Vasco
Branch and inquiry is being conducted into the
charges against certain Workmen involved in the
incident. The Employer stated that the inquiry which
were initiated in the year, 2010 and has been
concluded finally in September, 2012 and the
Workmen involved have been dismissed from service
w.e.f. 20-11-2012. The Employer stated that after
commission of theft of Rs. 5,00,000/- the current
incident of theft of Rs. 30,00,000/- took place that left
the bank shattered and led to queries from the
shareholders on the competency and stability of the
bank itself. The Employer stated that though the bank
suffered a loss of Rs. 5,00,000/- the bank has received
a payment of Rs. 4,60,000/- from the insurance
company in full and final settlement of the claim and
has further loss no claim bonus. The Employer stated
that mere reimbursement of the loss does not absolve
the Workmen involved in the theft of Rs. 5,00,000/from disciplinary action. The Employer denied that
there is violation of Section 25 of the I.D. Act as the
said section is not attracted in the present case and
therefore compliances of Section 25G of the I.D. Act
does not arise. The Employer denied that the
termination was is in violation of principles of natural
justice as well as is in violation of provisions of
settlement dt. 27-06-2001. The Employer submitted
that as the provisions of Section 25F are not attracted,
the question of Section 25G as well as 25H does not
arise. The Employer denied that the termination is
ab initio void or that it is in violation of principles of
natural justice or that it is in violation of procedure

<!-- page 11 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

laid down in service rules. The Employer denied the
overall case as pleaded by the Workman and
submitted that the Workman is not entitled to any
relief as prayed for in his claim statement and
therefore the reference be rejected.
15. Thereafter, the Workman filed rejoinder dt.
06-02-2014 at Exb. 14. The Workman, as and by way
of his rejoinder, affirms and confirms all statements
and submissions made by him in his statement of
claim and denies all averments made by the Employer
in its written statement as well as additional written
statements which are contradictory to or inconsistent
with his case as set out in his claim statement.
16. Based on the pleadings filed by the parties
hereinabove, the Presiding Officer, Industrial
Tribunal and Labour Court framed certain issues on
18-09-2014 at Exb. 17. The said issues has been
updated vide order dt. 05-10-2016.
1. Whether the Party-I proves that the termination
of his services by Party II is in violation of the
provisions of Sec.25-F, 25-G and 25-H of the
Industrial Disputes Act, 1947?
2. Whether the Party-I proves that he has been
dismissed from service by Party II on the false
charges without following the procedure
prescribed in the bi-partite settlement and
in contravention of the rules applicable to him?
3. Whether the Party-I proves that he is
unemployed from the date of dismissal from
service?
4. Whether the Party II proves that the present
dispute raised by Party I is not an “Industrial
Dispute” under the Industrial Disputes Act,
1947 and as such reference of such dispute
for adjudication is beyond the scope of the
powers of the Appropriate Government?
4A. Whether Party-II proves that its action in
terminating the services of the Party-I by way
of dismissal is legal and justified?
5. Whether the Party II proves that its action in
terminating services of the Party I by way of
dismissal is legal and justified?
6. What relief? What Award?
17. My answers to the aforesaid issues are as
under:
(a)

Issue No. 1

:

In the negative.

(b)

Issue No. 2

:

In the negative.

(c)

Issue No. 3

:

In the negative.

(d)

Issue No. 4

:

In the negative.

(e)

Issue No. 4A

:

In the affirmative.

(f)

Issue No. 5 and 6 :

As per final order.

I have carefully heard the submissions of Ld. Adv.
Shri A. V. Nigalye appearing for the Workman as well
as Ld. Adv. Shri G. K. Sardessai representing the
Employer. Both the parties have also filed the
synopsis of written arguments. I have carefully
perused the entire records of the present case which
includes the synopsis of written arguments. I have
also carefully considered the submissions advanced
before me.
REASONS
18. Issue No. 1:
Indisputably, the Workman has not laid any
evidence nor advanced any arguments to prove that
the termination of his services by the Employer in
violation of provisions of Section 25F, 25G and 25H of
the I. D. Act, 1947. Even otherwise the said issues are
not applicable to the facts and circumstances of the
present matter. Hence, it is held that the workman
failed to prove that the termination of his services by
the Employer is in violation of the provisions of
Section 25F, 25G and 25H of the I.D. Act, 1947. The
Issue No. 1 is therefore answered in the Negative.
19. Issue No. 2 and 4A:
I am deciding the issue No. 2 and issue No. 4A
simultaneously as both the said issues are co-related
to each other.
Indisputably, the services of the Workman has
been summarily dismissed by conducting an enquiry
without issuing any charge sheet alleging the acts
of misconduct. The Employer is governed by its
bipartite settlement signed between the Goa Urban
Co-operative Bank Employees Union and the
management of the Employer. The said bipartite
settlement is valid from 01-01-2011 till 13-12-2014.
Clause XIII of the said bipartite settlement lays down
the procedure for disciplinary actions and procedure
thereof. Similarly, Clause XIV of the said bipartite
settlement provides for subsistence allowance
during the period of suspension. Clause XVI of the
said settlement provides for procedure for
termination of services as well as designation from
the services.
20. In the case of Workman of M/s Firestone Tyre
Ltd., and Rubbarco of India Pvt. Ltd. (supra), the
Hon’ble Apex Court after relying its earlier judgment
in the case of Khardah Co. Ltd. V/s. there Workmen,
as well as Workmen of Moti Sugar Factory (P) Ltd.
V/s Moti Sugar Factory, held as under:-

151

<!-- page 12 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
(1) The right to take disciplinary action and to
decide upon the quantum of punishment are
mainly managerial functions, but a dispute is
referred to a Tribunal, the latter has power to
see if action if the employer is justified.
(2) Before imposing the punishment, an employer
is expected to conduct a proper enquiry in
accordance with the provisions of the Standing
Orders, if applicable and principles of natural
justice. The enquiry should not be an empty
formality.
(3) When a proper enquiry has been held by an
employer, and the finding of misconduct is
plausible conclusion flowing from the
evidence, adduced to the said enquiry, the
Tribunal has no jurisdiction to sit in judgment
over the decision of the employer as an
appellate body. The interference with the
decision of the employer will be justified only
when the findings arrived at in the enquiry
are perverse or the management is guilty of
victimization, unfair Labour practice or mala
fide.
(4) Even if no enquiry has been held by an employer
or if the enquiry held by him is found to be
defective, the Tribunal in order to satisfy itself
about the legality and validity of the order, had
to give an opportunity to the employer and
qemployee to adduce evidence before it. It is
open to the employer to adduce evidence for the
first time justifying his action, and it is open to
the employee to adduce evidence contra.
(5) The effect of an employer not holding an enquiry
is that the Tribunal would not have to consider
only whether there was a prima facie case. On
the other hand, the issue about the merits of
the impugned order of dismissal or discharge
is at large before the Tribunal and the latter, on
the evidence adduced before it, has to decide
for itself whether the misconduct alleged is
proved. In such cases, the point about the
exercise of managerial functions does not arise
at all. A case of defective enquiry stands on the
same footing as no enquiry.
(6) The Tribunal gets jurisdiction to consider the
evidence placed before it for the first time in
justification of the action taken only, if no
enquiry has been held or after the enquiry
conducted by the Employer is found to be
defective.
(7) It has been never recognized that the Tribunal
should straightaway, without anything more,
direct reinstatement of a dismissed or a
discharged employee once it is found that no

152

4TH MAY, 2023
domestic enquiry has been held or the said
enquiry is found to be defective.
(8) An Employer who wants to avail himself of the
opportunity of adducing evidence for the first
time before the Tribunal to justify his action,
should ask for it at the appropriate stage. If such
an opportunity is asked for, the Tribunal has
no power to refuse. The giving of an
opportunity to the employer to adduce evidence
for the first time before the Tribunal is in the
interest of both the management and the
employee and to enable the Tribunal itself to be
satisfied about the alleged misconduct.
(9) Once the misconduct is proved either in the
inquiry conducted by an Employer or by the
evidence placed before a Tribunal for the first
time, punishment imposed cannot be interfere
with by the Tribunal except in cases were the
punishment is so harsh as to suggest
victimization.
(10) In a particular case, after setting aside the order
of dismissal, whether a Workmen should be
re-instated or paid compensation is, as held by
this Court in the Management of Panitole Tea
Estate V/s the Workmen, 1971-1 SCC 742 within
the Judicial decision of a Labour Court or
Tribunal.
The principle laid down by the Hon’ble Apex
Court is well established and also applicable to the
case in hand.
21. In the case in hand, the Employer did not hold
enquiry against the Workman of alleged misconduct,
but terminated the services of the Workman by way
of summarily dismissal by alleging that the Workman
alongwith one Mr. Prasad Shirodkar, sub-staff were
handed over a sum of Rs. 30,00,000/- to deposit the
said amount in the current account of the Bank in
Axis Bank, Margao Branch and that the said amount
was found missing from their custody and neither of
them could account for the said cash which was
entrusted to them and that they refused to give
statement in spite of written statement of the Bank
Manager vide letter dated 30-05-2011 and
01-06-2011. The Management therefore concluded
that the Workman alongwith Shri Prasad Shirodkar
conspired to commit theft of Rs. 30,00,000/- of the
Bank. The Workman was therefore charged for the
major acts of misconduct such as misappropriation
of funds, doing any act prejudicial to the interest of
the Bank or gross negligence or negligence involving
or likely to involve the Bank in serious loss and willful
insubordination or disobedience of any lawful and
reasonable order of the Management or of a superior.

<!-- page 13 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
The Employer therefore led evidence before this
Tribunal to justify its action of dismissal of the
Workman.
22. To prove its case, the Employer has examined
two witnesses namely Mr. Nathkiran N. Dessai, its
Branch Manager and Mrs. Vandana Kane, Joint
Custodian and the main Cashier. On the contrary,
the Workman examined himself.
23. The evidence on record indicates that the
Workman was employed with the Employer bank as
a Clerk w.e.f. 4-10-1985. The evidence on records
indicates that on 28-5-2011, the Workman was
instructed by the Asst. Manager Mr. Alex Rebello,
that he has to go with cash to Axis Bank for depositing
the same. The Asst. Branch Manager of Margao
Branch Mr. Alex Rebello and the Joint Custodian and
the Main Cashier Mrs. Vandana Kane withdrew from
the safe deposit vault a sum of Rs. 30,00,000/- (Rupees
Thirty Lakhs only) and the same was thereafter
handed over to the Workman alongwith Mr. Prasad
Shirodkar, the sub-staff. The evidence on record
indicates that the Workman as well as the said Mr.
Prasad Shirodkar verified the cash and was put in a
grey colour briefcase by the said sub-staff Mr. Prasad
Shirodkar. The said briefcase was locked by Mr.
Prasad Shirodkar and the key of the said briefcase
was given to the Workman. They took signature of
the Workman of having received the cash on the cash
movement Register. Hence, both the Workman as well
as Mr. Prasad Shirodkar were entrusted with the said
cash and it was their duty to deposit the same in
Current Account of Axis Bank of the Employer. The
said briefcase containing cash of Rs. 30,00,000/- was
found to be missing from their custody. The evidence
on records indicates that neither the Workman nor
the said Mr. Prasad Shirodkar gave account of the
said amount of Rs. 30,00,000/- which were handed
over to them. The Employer bank therefore summarily
dismissed the Workman on account of charge of theft
and misappropriation of funds and doing act
prejudicial to the interest of the Bank as well as gross
negligence or negligence involving bank in a serious
loss. The testimony of both the management
witnesses that is Shri Nathkiran Dessai and Mrs.
Vandana Kane appears to be trustworthy.
24. Thus, the Workman has however failed to give
any justification nor has led any evidence as to why
he left the briefcase containing cash of Rs. 30,00,000/with Mr. Prasad Shirodkar alone and went away when
the custody of the cash was given to both of them
and it was the bounden duty of the Workman to take
precaution of the briefcase and to deposit in the Axis
Bank as was instructed. The aforesaid act/omission
on the part of the Workman clearly indicates that

4TH MAY, 2023
doing any act prejudicial to the interest of the Bank
or gross negligence or negligence involving or likely
to involve the Bank in serious loss to leave the
briefcase containing cash with Mr. Prasad Shirodkar.
25. The evidence on records indicates that the
Workman was directed to give statement, however
the Workman refused to do so in spite of written
instructions of the Branch Manager vide his letters
dated 30-5-2011 and 01-06-2011. The aforesaid acts
on the part of the Workmen amounts to wilful
in-subordination or disobedience of any lawful and
reasonable orders of the Management or of the
superior.
26. Though, the Employer charged the Workman
for an act of misconduct of misappropriation of funds,
they have filed an F.I.R. against unknown person and
as such the said misconduct of misappropriation of
funds has not been proved.
27. A Bank employee is required to exercise higher
standards of honesty and integrity. Every employee
of the Bank is required to take all possible steps to
protect the interests of the Bank and to discharge
his duties with utmost integrity, honesty, devotion
and diligence and to do nothing which is
unbecoming of a bank officer. Good conduct and
discipline are inseparable from the functioning of
every employee of the Bank. The very discipline of
an organization more particularly as bank is
dependent upon each of its employees and
employees acting and operating within their allotted
sphere.
28. The Workman contended that it was not his
duty to deposit cash in another Bank. However, it
has come on record that the Workman during the
period from 17-8-2009 to 28-5-2011 had on 26 times
deposited cash in other Banks such as Axis Bank,
Bank of Baroda, ICICI Bank where the Employer/Bank
had account and as such it cannot be said that
depositing cash in another bank was not part of his
duties.
29. Due to the said negligence, on the part of the
Workman, the Employer Bank has not only suffered
huge monetary loss but also lost the faith created by
its several customers by depositing their amount in
the custody of the Employer Bank. The misconduct
levelled against the Workman is a major misconduct
and as a result of commission of the grave
misconduct, the Employer lost confidence reposed
in the Workman. Thus, taking into consideration the
facts and circumstances of the entire case as well as
the seriousness of misconduct levelled against the
Workman, the punishment of dismissal imposed upon
him is just, fair, proper and proportionate to the

153

<!-- page 14 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

proved misconduct. The Issue No. 2 is therefore
answered in negative and Issue No. 4A is answered
in the affirmative.

2. It is held that the Workman Shri Anand G. Gauns,
Clerk is not entitled to any relief.
Inform the Government accordingly.

30. Issue No. 3:

Sd/-

While deciding the issue No. 4A is hereinabove, I
have discussed and come to the conclusion that the
action of the Employer bank in terminating the
services of the Workman by way of dismissal is just,
fair, proper and proportionate. Hence, the question
is as to whether the Workman is unemployed from
the date of dismissal from service does not arrive.
The issue No. 3 is therefore answered accordingly.
Issue No. 4:
31. The Employer Bank in its preliminary
objections filed in the written statement alleged that
the present disputes raised by the Workman is not
an industrial dispute as defined under the I.D. Act,
1947 and that there is a non-application of mind by
the appropriate Government while referring the
present dispute. The burden to prove the aforesaid
facts lies on the Employer. In the case in hand, it is
not in dispute that the Party I is a “Workman” as
defined u/s 2(s) of the I. D. Act, 1947 and the Employer
Bank is an “Employer” as defined u/s 2(j) of the I.D.
Act, 1947 and as such the present dispute raised by
the Workman pertaining to his non-employment
amounts to an “Industrial Dispute” as defined u/s
2(k) of the I.D. Act, 1947 and as such, the appropriate
Government has every right for adjudication of the
said dispute. Hence, it is held that the Employer has
failed to prove that the present dispute raised by the
Workman is not an industrial dispute under the I. D.
Act, 1947 and as such, reference of such dispute for
adjudication is beyond the scope of the powers of
the appropriate Government. The Issue No. 4 is
therefore answered in negative.
Issue No. 5:
32. While deciding the issue No. 4A hereinabove,
I have discussed and come to the conclusion that
the action of the Employer bank in terminating the
services of the Workman by way of dismissal is just,
fair, proper and proportionate. The Workman is
therefore not entitled to any relief. The Issue No. 5 is
therefore answered in the negative.
In view of the above, I proceed to pass the
following order:

(Suresh N. Narulkar),
Presiding Officer,
Labour Court-II.
————

Notification
No. 28/02/2023-LAB/Part-II/243
The following Award passed by the Labour
Court-II, at Panaji-Goa on 14-03-2023 in Case No.
Ref. IT/07/2015 is hereby published as required
under Section 17 of the Industrial Disputes Act,
1947 (Central Act 14 of 1947).
By order and in the name of the Governor of
Goa.
Amalia O. F. Pinto, Under Secretary (Labour).
Porvorim, 27th March, 2023.
––––

THE LABOUR COURT-II
GOVERNMENT OF GOA
AT PANAJI
(Before Shri Suresh N. Narulkar, Hon’ble
Presiding Officer)
Case No. Ref. IT/07/2015
Shri Arvind Pednekar,
C/o. Shri P. Gaonkar,
Goa Municipal Employees
Association, 328-01, Municipal
Quarters, St. Inez,
Panaji-Goa.
…… Workman/Party I
V/s
The Chief Officer,
Pernem Municipal Council,
Pernem-Goa.
…… Employer/Party II
Workman/Party-I represented by Adv. Shri D. Naik.
Employer/Party-II represented by Adv. Shri S. Sawal
Dessai.
Panaji, dated: 14-03-2023.

ORDER

AWARD

1. It is held that the action of the Goa Urban
Co-operative Bank Limited, Margao-Goa, in
terminating the service of Shri Anand G. Gauns,
Clerk by way of dismissal vide letter of dismissal
dt. 1-06-2011 is legal and justified.

1. In exercise of the powers conferred by Clause
(c) of sub-section (1) of Section 10 of the Industrial
Disputes Act, 1947 (Central Act 14 of 1947), the
Government of Goa, by Order dated
18-06-2015, bearing No. 28/18/2015-LAB/616

154

<!-- page 15 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
referred the following dispute for adjudication by
the Labour Court-II, of Goa at Panaji-Goa.
“(1) Whether the action of the Pernem Municipal
Council, Pernem-Goa, in refusing employment
of Shri Arvind R. Pednekar, Peon with effect
from 24-11-2009 is legal and justified?.
(2) If not, what relief the Workman is entitled for?”
2. On receipt of the reference, a Case was
registered under Ref. No. IT/07/2015 and registered
A/D notice was issued to the Parties. In pursuance
to the said notice, the Parties put in their appearance.
The Workman/Party-I (for short ‘Workman’) filed his
Statement of Claim on 28-09-2015 at Exb. 6. The facts
of the case, in brief as pleaded by the Workman are
that the Employer/Party-II (for short employer) vide
its office order dated 09-03-1990 initially appointed
him as a part time “Garden Worker” with immediate
effect on temporary basis. He stated that thereafter,
he was appointed by the Employer on full time basis.
He stated that by its office order dated 20-03-1992,
he was entrusted the work on full time basis for
supervision on the work assigned to him in the said
order. He stated that he was further directed to
supervise the work on Saturdays and Sundays also.
He stated that he used to sign the master roll. He
stated that vide office orders dated 16-06-1992 and
29-03-1993, the Employer rescheduled his work along
with others Group D officials. He stated that he was
posted to the library section w.e.f. 22-03-1994 until
further orders by its order dated 17-03-1994. He stated
that he was entrusted the work of supervising the
workmen on field duty apart from attending to the
office and other allied work assigned by the superiors
from time to time. He stated that he had to submit
daily working report of sweepers, vide its order dated
19-01-1994. He stated that further vide its office order
dated 02-11-1995, the Employer directed him to look
after the supervision work of the road. He stated that
he was directed to look after the supervisory work of
all the field sweepers of the Municipal council in
addition to his own office duty w.e.f. 01-03-1996. He
stated that vide its officer order dated April 1996 the
Employer entrusted the work to him of carrying out
the survey of the existing business establishment
and new establishment under the trade and
occupation licensing by laws in force. He stated that
he was further directed to commence the aforesaid
work with help of Shri Dnyaneshwar Gadekar. He
stated that by office order dated 25-02-1997, the
Employer directed him to look after the library duty
from 25-02-1997 onwards. He stated that by the said
order, he further directed to get the work done of
flagging the tricolor from Shri Namdev Pawar. He
stated that the Employer has directed the officials

4TH MAY, 2023
including himself to carry out the re-assessment work
of the house tax ward wise with immediate effect by
its order dated 04-06-1997. He stated that by its order
dated 30-04-1998, the Employer directed him to look
after the duty of library section. He stated that by
office order dated 30-03-2000, the Employer had
posted him in the library section w.e.f. 01-04-2000 to
look after the duties of the library section until further
orders. He stated that vide its order dated 21-03-2001,
the Employer allotted works supervision,
conservancy supervision, street lighting to him. He
stated that by order dated 30-04-2001, the Employer
has granted medical allowance of Rs. 250/- per month
to him amongst others w.e.f. 01-04-2001. He stated
that by order dated 22-05-2001, the Employer has
sanctioned Rs. 2300/- towards uniform allowance to
him amongst others for the year 2001-2002. He stated
that by order dated 05-07-2001, the Employer had
directed him to supervise the duties in the municipal
market. He stated that by its order dated 05-07-2001,
the Employer has granted medical allowance to him
of Rs. 200/- per month w.e.f. 01-10-1998 to 31-03-2001
and Rs. 250/- per month from April 2001. He stated
that by order dated 11-06-2001, the Employer has
directed municipal staff which included himself to
make the seating arrangement of fish vendors/
vegetable vendors in municipal market. He stated
that the Employer, through its Chief Officer, has also
issued identity card. He stated that by its order dated
05-06-2003 the Employer has re-allocated the staff
work and he has directed to look after the duties
attached to the library section of the council. He
stated that by order dated 05-05-2006, the Employer
has entrusted additional duties of maintaining
records of hearse van on holidays and non-working
days of the Municipal Council and to furnish the
information and report to Mr. Dayanand B. Navelkar
on next working day of the Council. He stated that
the Employer, vide its letter dated 27-02-2007,
addressed to the Additional Director of Municipal
Administration proposed to regularize and to get
approval for regularization of his services who was
working with Employer for more than sixteen years
without any break. He stated that by office order
dated 27-04-2007, the Employer made changes in the
duty in addition to the duties allotted to him and
directed to keep the duplicate keys of the hearse van
and ambulance in his custody with further direction
to handover the said keys to any driver of the council
on requisition of public on non-working days of the
council i.e Saturday, Sunday and shall give report/
/requisition of such demand on every Monday to Shri
Sanjay Palyekar, Supervisor of the council for
recording purpose. He stated that by its order dated
16-05-2007, the Employer made a modification to the
earlier order dated 27-04-2007 wherein he was

155

<!-- page 16 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
directed to submit a report on every Tuesday to Shri
Sanjay Palyekar being Monday was his weekly off
day, in respect of the facility of hearse van and
ambulance on Saturday and Sunday.
3. He stated that by order dated 20-06-2008, the
Employer gave him a superficial illegal break w.e.f.
23-06-2008. He stated that he raised an industrial
dispute and conciliation proceedings were held
before the Assistant Labour Commissioner wherein
the Employer undertook to revoke illegal termination
and accordingly he was reinstated in service with
continuity in employment and also undertook to pay
the wages from November 2009 till April 2010. He
stated that by its order dated 23-11-2009, the
Employer reinstated him with the terms and
conditions which are totally contrary to law and the
Employer misguided him being illiterate person. He
stated that by its judgment dated December 2009
allotted the duties to him amongst other employees.
He stated that by office order dated 13-01-2010,
the Employer has partially modified earlier office
order vide letter dated 29-10-2009 and re-allocated
the duties to the officials of the Municipal Council
including himself. He stated that the Employer
addressed a letter dated 03-08-2010 to the Director
of Municipal Administration, Panaji-Goa along with
a detailed report of previous service rendered by him
to the Employer/Council with request to convey the
approval to continue his services till his services were
regularized. He stated that by its order dated
29-10-2010, the employer has posted him in the
municipal library with immediate effect to look after
the library duties. He stated that the Employer has
re-allocated the duties of all the peons and workers
including himself by its office order dated 23-11-2010.
He stated that he was given a superficial break of
three days i.e. from 13-01-2011 to 15-01-2011 by office
order dated 22-12-2010. He stated that on 11-01-2011,
the Employer, by its circular dated 11-01-2011
entrusted the work of assessment/BPL survey to him.
He stated that the Employer again by its office letter
dated 20-01-2011, gave him superficial break to him
from 24-01-2011 to 02-02-2011 for a period of ten days
only. He stated that the Employer has issued
purported memo dated 18-01-2011 to him to harass
him without any reason. He stated that he replied to
the said memo by his reply 19-01-2011.
4. He stated that by letter/order dated 08-02-2011,
the Employer has abruptly changed his duties who
was a peon in the office and has directed him to look
after three garden as a gardener at three different
time schedules i.e. 2.00 p.m. to 4.00 p.m., 4.00 p.m. to
6.00 p.m. and 6.00 p.m. to 9.00 pm. and making things
difficult for him only to harass. He stated that by his
reply dated 17-02-2011, he replied to the said letter

156

4TH MAY, 2023
stating that it will be difficult for him since he got
physically and mentally challenged son who is
studying in Sanjay School for which he has to look
after him as per the instruction of the doctor after his
office hours. He stated that he has been in
continuous service of the Employer ever since he has
joined the service in March 1990 and has completed
240 days of continuous service in every year until his
services were illegally and arbitrarily changed as a
gardener and terminated by the Employer. He stated
that he used to work even on Sundays and holidays
as per the instructions given to him by his superiors
from time to time which is evident from the orders
(annexed herewith). He stated that he was shocked
and shattered that the Employer, without following
the principles of natural justice and without his any
fault, abruptly and illegally changed the services and
terminated his services. He stated that he has
completed 240 days of service in a period of 12
calendar month every year ever since he has joined
the service in the year March 1990. He stated that
the illegal and arbitrary action of the Employer
amounts to unfair labour practices. He stated that
he made several request to the officials of the
Employer to take him back in service, but no heed
was paid to his request.
5. He stated that he is unemployed and has a
dependent family to support including a son who is
physically and mentally challenged and is in great
financial difficulty to meet both ends. He stated that
the arbitrary action of the Employer is totally illegal,
unjustified and contrary to law and without following
the principles of natural justice and a procedure laid
down under the law. He stated that he also made
several requests to the Chief Officer and the
Chairperson of the Employer, however to his utter
dismay, no heed was paid to the request made by
him. He stated that he therefore approached the
Assistant Labour Commissioner Panaji-Goa which
ended in failure. The Workman therefore prayed that
the action of the Employer in terminating his services
be declared as illegal, unjust and contrary to law and
he be reinstated in service with full back wages and
continuity in service. The Workman also prayed for
regularization of his services.
6. The Employer controverted the claim of the
Workman by filing its written statement on
14-02-2015 at Exb.8. The Employer, as and by way of
its preliminary objections, submitted that the
reference made by the appropriate government is
bad in law and not maintainable as the Workman
was appointed on daily wages, that the Employer,
vide its order dated 08-02-2011, has entrusted the
work of maintenance of three municipal gardens to
the Workman however, he refused to accept the said

<!-- page 17 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
order till 14-02-2011 with his verbal reason that he is
not interested to perform the said duty, that
thereafter the Workman accepted the said order on
15-02-2011 and vide his letter dated 17-02-2011
informed them that he will not perform the said duty
and remained unauthorisely absent on duty till date,
that the Workman abandoned his service from
08-02-2011 and till date he has not resumed his duty
and therefore there is no employer-employee
relationship between themselves and the Workman
from 08-02-2011 till date, that the Workman did not
raise any demand before them but directly
approached the conciliation officer by raising alleged
“Industrial Dispute” and hence the alleged dispute
is not an industrial dispute as defined under the
industrial disputes act, that there is no termination
letter issued to the Workman and therefore the
question arise of refusing employment to the
Workman by them and that the Workman is
suppressing the material facts from this Hon’ble Court
and hence he is not entitled to any relief.
7. The Employer stated that the Workman was
appointed by them on daily wages. The Employer
stated that the Workman was given a break in service
by them vide its orders dated 20-06-2008, 22-12-2012
and 20-11-2011 and therefore the Workman was not
in continuous service with the Employer. The
Employer stated that vide its order dated 08-02-2011,
they entrusted the work of maintenance of three
municipal gardens to the Workman, however he
refused to accept the said order till 14-02-2011 with
his verbal reason that he is not interested to do the
said duty. The Employer stated that the Workman
has accepted the said order on 15-02-2011 and vide
his letter dated 17-02-2011, informed them that he
will not perform the said duty and remained
unauthorized absent from duty from the date of order
dated 08-02-2011 till date. The Employer stated that
they, on humanitarian ground, vide office
memorandum dated 18-08-2011, informed the
Workman to submit his unwillingness to refuse his
duty allotted vide order dated 08-02-2011 along with
explanation for unauthorized absentism from duty
from 08-02-2011. The Employer stated that the
Workman has however has not submitted his
willingness to resume duties till date neither any
explanation has been received from the Workman.
The Employer stated that the Workman has
approached the Conciliation Officer and during the
course of discussion, they have taken an initiative to
accommodate the Workman in service, however, the
Workman was not ready nor shown any willingness
to accept the proposal. The Employer stated that
vide its order dated 15-07-2014, they have decided to
re-employ the Workman on contractual basis on an

4TH MAY, 2023
amount of Rs. 6000/- per month till his
superannuation. The Employer stated that vide its
letter dated 26-09-2014, they also clarify that contract
agreement would be renewed every after six months
with applicable increase in payment. The Employer
stated that they have given several opportunity to
the Workman however he was not ready nor shown
his willingness to resume the duties till date. The
Employer stated that they have not illegally refused
employment to the Workman, but he himself remained
unauthorized absent from duty from 08-02-2011 till
date. The Employer submitted that they have not
issued any termination order to the Workman till date
and hence the question of illegal refusing of
employment to the Workman does not arise and
therefore the Workman is not entitled to any relief.
The Employer denied the overall case as pleaded by
the Workman and prayed that the reference made by
the Government be dismissed.
8. Thereafter, the Workman filed his rejoinder on
22-02-2016 at Exb. 10. The Workman, as and by way
of his rejoinder, affirms and confirms all statements
and submissions made by him in his statement of
claim and denies all averments made by the Employer
in its written statement which are contradictory to
or inconsistent with his case as set out in his claim
statement. He stated that the Employer, by its order
dated 23-11-2009, reinstated him with the terms and
conditions which are totally contrary to law and the
Employer misguided him being an illiterate person.
He stated that the Employer used to give superficial
break which is evident from the office order dated
22-12-2010 from 13-01-2011 to 15-01-2011 only for
three days and again by office order dated 20-01-2011
for the period from 24-01-2011 to 02-02-2011 for ten
days.
9. Based on the pleading filed by the parties herein
above this Hon’ble Court framed the following issues
on 15-03-2017 at Exb. 15.
1. Whether the Workman/Party-I proves that he
has been refused the employment by the
Employer w.e.f. 24-11-2009?
2. Whether the Workman/Party-I proves that the
action of the Employer in refusing him
employment w.e.f. 24-11-2009 is illegal and
unjustified?
3. Whether the Employer/Party-II proves that the
present order of reference is bad-in-law and not
maintainable in view of the reasons mentioned
in para 1 (a) to 1 (f) of its written statement?
4. Whether the Workman/Party-I is entitled to any
relied?

157

<!-- page 18 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

5. What order? What award?
My answers to the aforesaid issues are as under:
(a)
(b)
(c)
(d)

Issue No. 1
:
Issue No. 2
:
Issue No. 3
:
Issue No. 4 & 5 :

In the negative.
Does not arise.
In the affirmative.
As per final order.

I have heard the oral arguments of Ld. Adv. Shri D.
Naik appearing for the Workman as well as Ld. Adv.
Shri S. Sawal Dessai representing the Employer. Both
the parties also filed their synopsis of written
arguments.
10. Ld. Adv. Shri D. Naik appearing for the
Workman, during the course of his oral arguments,
submitted that initially the Workman was appointed
by the Employer on temporary basis vide its order
dated 09-03-1990. He submitted that subsequently,
vide its order dated 20-03-1992, the Employer
appointed the Workman on full time basis for
supervision on the works. He submitted that the
Workman was in continuous service of the Employer
from his initial appointment in March 1990 till he
was refused employment on 24-11-2009. He
submitted that the Workman was refused
employment by the Employer in the month of January
2011. He submitted that the refusal of employment
to the Workman is illegal, unjustified and bad in law
as it is contrary to the provisions of Section 25 F of
the I.D. Act, 1947. He submitted that the date of birth
of the Workman is 26-06-1960 and he would have
attended the superannuation on 26-06-2020. He
submitted that the action of the Employer in
terminating the services of the Workman be declared
as illegal unjust and contrary to law and the Workman
be compensated with full back wages till June 2020.
He submitted that the Workman was not allowed to
sign the muster roll. He submitted that the Workman
was not a daily wage worker.
11. Per contra, Ld. Adv. Shri S. Sawal Dessai
representing the Employer, during the course of his
oral arguments, submitted that the Workman was a
daily wage worker working with the Employer. He
submitted that the Workman was given break in
service from time to time. He submitted that the
Workman was entrusted the work of maintenance of
three municipal garden vide its order dated
08-02-2011. He submitted that the Workman however
refused to accept the said order. He submitted that
the Workman accepted the said order on 15-02-2011
and vide his letter dated 17-02-2011 informed the
Employer that he will not perform the said duty and
remained unauthorized absent from duty till date.
He submitted that there does not exist any employeremployee relationship between the Employer and

158

the Workman since the Workman refused to perform
his duties and he being daily wage worker. He
submitted that the Workman has not made any
demand for reinstatement of his services but directly
approached the Conciliation Officer. He therefore,
submitted that the dispute raised by the Workman is
not an Industrial Dispute as defined under Section 2
(k) of the I.D. Act, 1947 and the reference made by the
Government is incompetent. He submitted that the
Workman was not issued any termination letter
thereby terminating his services but he voluntarily
abandoned his services. He submitted that the
Workman has not shown his willingness to join the
duties. He submitted that the Workman was given
the break in service thrice and as such he is not in
continuous service. He therefore submitted that the
Workman is not entitled to any relief and the reference
be dismissed.
I have carefully perused the entire records of the
present case. I have also carefully perused the
submissions advanced before me and is of the opinion
as under:REASONS
12. Issue No. 1:
By office order dated 09-03-1990 (Exb. 17), the
Workman was appointed on purely temporarily basis
to the post of part time garden worker with immediate
effect. Thereafter, by office order dated 20-3-1992
(Exb. 18), the Workman, part time daily wage worker
has been entrusted the work on full time basis for
supervision on the works on the Municipal Area. The
Workman was also directed to supervise the works
on Saturdays and Sundays if needed. The Workman
was given the break in service from time to time.
Indisputably, the Workman was daily wage worker
working in the Employer Municipality. By order dated
08-02-2011 (Exb. 56), the Workman was entrusted the
duties as Peon, in the office and has directed him to
look after three Gardens of the Municipality as a
“Gardner” at three different times scheduled as 2.00
p.m. to 4.00 p.m., 4.00 p.m. to 6.00 p.m. and 6.00 p.m. to
9.00 p.m. The Workman replied to the aforesaid letter
of the Employer, by his letter dated 17-02-2011
(58-colly), stating that it will difficult for him since,
he got a physically and mentally challenged son who
is studying in Sanjay School, for which he has to look
after him as per instruction of the Doctor after office
hours and as such, it will be difficult for him to
perform his duties as per the time schedule and
requested for allotting him duties at office which will
help him to overcome the present situation. The
Workman refused to accept the order of the Employer
dated 08-02-2011 issued by the Employer and
remained absent from his duty. The Employer, by its

<!-- page 19 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
memorandum dated 18-08-2011 (Exb. 18), directed to
submit his willingness to resume duty allotted earlier
vide order dated 08-02-2011 and further directed to
submit his explanation for absence on duty w.e.f.
08-02-2011.
13. In the case of Dharmraj Vithoba Natekar V/s.
Unique Industries reportedly (1996) II LLJ 948 the
Hon’ble High Court of Bombay it has been held that
“By Now, it is well established that abandonment of
services is an inference which can be raised upon
consideration of the totality of the circumstances and
that the Court should raise that inference only if it is
satisfied that the circumstances do indicate that the
Workman was clearly not interested in continuing
with his service.”
The principal laid down by the Hon’ble High Court
of Bombay in its aforesaid case is well established
and also applicable to the case in hand.
14. In the case in hand, the Workman was
employed with the Employer as worker since the year
1990 on daily wage basis. By order dated 08-02-2011,
the Workman was entrusted with the work of
Gardener in the three municipal garden of the
Employer Municipality. The Workman refused to
accept the said order and since then the Workman
remained absent. Thereafter, the Workman accepted
the said order dated on 15-02-2011 and by letter
dated 17-02-2011 informed the Employer that it will
difficult for him to perform the duties. Therefore, the
Employer issued a Memorandum dated 18-08-2011
directing the Workman to submit his willingness to
resume his duties allotted vide office order dated
08-08-2011 and also submit his explanation for
absence from duties w.e.f. 08-02-2011. The Workman,
however did not send his willingness to the Employer
to resume his duties nor submit his explanation for
absence from duties. The Workman has however
raised a dispute before Asst. Labour Commissioner
and the Conciliation Officer, Panaji-Goa. The
aforesaid act on the part of the Workman indicates
that the Workman has abandoned his duties by
remaining absent and that he was not refused
the Employment by the Employer. Hence, it is held
that the Workman failed to prove that he was refused
the employment by the Employer. The Issue No. 1 is
therefore answered in the negative.
15. Issue No. 2:
While deciding the Issue No. 1 is hereinabove, I
have discussed and come to the conclusion that the
Workman was not refused the Employment, but the
Workman abandoned his duties and as such, the
question of the alleged action of the Employer in
refusing the Employment to the Workman w.e.f.
24-11-2009 is illegal and unjustified, does not survive.

4TH MAY, 2023
The Issue No. 2 is therefore answered as does not
survive.
16. Issue No. 3:
The Employer, as and by way of its preliminary
objections, submitted that the reference made by the
appropriate Government is bad in law and not
maintainable as the Workman was appointed on daily
wages, that the Employer, vide its office order dated
08-02-2011, has entrusted the work of maintenance
of three municipal gardens to the Workman however,
he refused to accept the said order till 14-02-2011
with his verbal reasons that he is not interested to
do his said duties and that thereafter the Workman
accepted the said order on 15-02-2011 and vide his
letter dated 17-02-2011 informed the Employer that
he will not performed the said duties and remained
unauthorisely absent on duties till date, that the
workman has abandoned his services from
08-02-2011 and till date he has not resumed his duties
and therefore there is no Employer-Employee
relationship between themselves and the Workman
from 08-02-2011 that the Workman did not raise any
demand before the Employer but directly approached
the Conciliation Officer by raising alleged the
Industrial Dispute and hence, the dispute is not an
industrial dispute as defined under the I.D. Act, 1947
and that there is no termination letter has been
issued to the Workman and therefore there is no
question of refusing the Employment to the Workman
does not arrive.
17. Indisputably, the Workman was appointed on
daily wage basis. The Workman was entrusted the
work of maintenance of three municipal gardens vide
its order dated 08-02-2011. However, the Workman
refused to accept the said order till 14-02-2011 with
his verbal reasons that he is not interested in
performing the said duties. Thereafter, the Workman
accepted the said order on 15-02-2011 and vide his
letter dated 17-02-2011 informed the Employer his
inability to perform the said duties and remained
unauthorized absent from duties till date. The
Employer, vide its memorandum dated 18-08-2011,
directed the Workman to submit his willingness to
resume his duties allotted vide its office order dated
08-02-2011 and also give explanation for his absence
on duty w.e.f. 08-02-2011. The Workman thereafter
directly approached the Conciliation Officer by
raising a dispute without raising a demand before
the Employer.
18. In the case of, the Sindhu Resettlement V/s.
The Industrial Tribunal reportedly 1968 AIR 529,
the Hon’ble Supreme Court held as under “It may
be that the Conciliation officer reported to the
Government that an industrial dispute did exist

159

<!-- page 20 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
relating to the reinstatement of respondent No.3 and
payment of wages to him from 21st February, 1958,
but when the dispute came up for adjudication before
the Tribunal, the evidence produced clearly showed
that no such dispute had ever been raised by either
respondent with the management of the appellant. If
no dispute at all was raised by the respondents with
the management, any request sent by them to the
Government would only be a demand by them and
not an industrial dispute between them and their
employer. An industrial dispute, as defined, must be a
dispute between employers and employers, employers
and workmen, and workmen and workmen. A mere
demand to a Government, without a dispute being
raised by the workmen with their employer cannot
become an industrial dispute. Consequently, the
material before the Tribunal clearly showed that no
such industrial dispute, as was purported to be referred
by the State Government to the tribunal had ever
existed between the appellant Corporation and the
respondents and the State Government, in making a
reference, obviously committed an error in basing its
opinion on material which was not relevant to the
formation of opinion. The Government had to come
to an opinion that an industrial dispute did exist and
that opinion could only be formed on the basis that
there was a dispute between the appellant and the
respondents relating to reinstatement. Such material
could not possibly exist when, as early as March and
July, 1958 respondents No. 3 and respondent No. 2
respectively had confined their demands to the
management to retrenchment compensation only and
did not make any demand for reinstatement. On these
facts, it is clear that the reference made by the
Government was not competent.”
The principle laid down by the Hon’ble Apex Court
is well established and also applicable to the case in
hand.
19. In the case in hand, the Workman did not raise
any demand for reinstatement in service on the
Employer after alleged refusal of the Employment,
but directly approached the Conciliation Officer.
Hence, the dispute raised by the Workman is not an
“Industrial Dispute” as defined u/s 2C (k) of the I. D.
Act, 1947 and the reference made by the appropriate
Government is bad-in-law and incompetent. Hence,
it is held that the Employer proved that the present
order of reference is bad-in-law. The Issue No. 3 is
therefore answered in the affirmative.
20. Issue No. 4:
While deciding the Issue No. 3 hereinabove, I have
decided and come to the conclusion that the

160

4TH MAY, 2023
reference made by the appropriate Government is
bad-in-law. The Workman is therefore not entitled to
any relief. The Issue No. 4 is therefore answered in
the negative.
In view of the above, I proceed to pass the
following order:
ORDER
1. It is held that whether the action of the
Pernem Municipal Council, Pernem-Goa, in
refusing employment of Shri Arvind R.
Pednekar, Peon with effect from 24-11-2009 if
legal and justified, does not survive.
2. The Workman, Shri Arvind R. Pednekar is
not entitled to any relief.
3. Inform the Government accordingly.
Sd/(Suresh N. Narulkar),
Presiding Officer,
Labour Court-II.
———uuu———

Department of Law & Judiciary
Law (Establishment) Division
–––

Order
No. 8/32/2020/LD(Estt)/700
Government approval is hereby conveyed to
delegate the powers to the Civil Registrars-cum-Sub Registrars to deal with such cases or cases
where the canonical marriage has taken place but
the registration has not been recorded at all in any
of the offices of the Civil Registrars-cum-Sub
Registrars, by incorporating the following:
a) the Civil Registrars-cum-Sub Registrars be
authorised to cancel the erroneous recording
of the marriage certificate and the marriage
be registered under the next entry number,
after the last entry for that corresponding
same year when the canonical marriage was
solemnised.
b) In case the canonical marriage was
solemnised in the month of December, then
the Civil Registrars-cum-Sub Registrars shall
register such a marriage at the next entry
number, after the last entry of the next year of
the canonical marriage solemnisation.
c) In cases where the canonical marriage has
been solemnised but not recorded at any of
the Civil Registrar-cum-Sub-Registrar Offices

<!-- page 21 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023
d) A nominal fee of Rs. 2000/- (Rupees two
thousand only) shall be levied on the
applicant/party for the above facilities.

(CRSR), then such a marriage must be
recorded at the last entry of that year. In case
the canonical marriage has been solemnised
In the month of December, then such a
marriage must be recorded by the respective
CRSR at the last entry of the next year.

By order and in the name of the Governor of
Goa.
Amir Y. Parab, Under Secretary (Law-Estt.).
Porvorim, 21st April, 2023.

————

Order
No. 2-3-21-LD(Estt)/733
The Government of Goa is pleased to order the transfer and posting of the following Civil Registrar-cum-Sub Registrars, Group ‘B’, Gazetted Officers of Registration Department, with immediate effect.
Sr.
No.

Name of the staff

Present posting

Posted as

1

2

3

4

1.

Shri Arjun Shetye

District Registrar (South)
holding additional charge
of Civil Registrar-cum-Sub
Registrar, Tiswadi in addition
to his duties as District
Registrar (South)

District Registrar (South)
with additional charge of
Civil Registrar-cum-Sub
Registrar, Pernem vice
Prachi Naik, CRSR
transferred.

2.

Smt. Prachi Naik

Civil Registrar-cum-Sub
Civil Registrar-cum-Sub
Registrar-Headquarters,
Registrar-Headquarters,
Panaji and holding charge of
with additional charge of
Civil Registrar-cum-Sub Registrar, Jt. Civil Registrar-cum-Sub
Pernem
Registrar-I, Tiswadi, thereby
relieving Smt. Aarti
Parvatkar.

3.

Smt. Aarti Parvatkar

Jt. Civil Registrar-cum-Sub
Registrar-I, Tiswadi

Civil Registrar-cum-Sub
Registrar, Tiswadi vice
Shri Arjun Shetye
transferred.

The above Officers shall draw pay and allowances against their respective transferred posts from the
date of taking charge. They shall complete the process of handing over/taking over of charge with effect
from 02-05-2023 b.n. and submit compliance.
By order and in the name of the Governor of Goa.
Amir Y. Parab, Under Secretary (Law-Estt.).
Porvorim, 27th April, 2023.
———uuu———

Department of Personnel
–––

Order
No. 13/07/2023-PER/1250
The Governor of Goa is pleased to grant extension in service to Shri Anil Naik, Block Development Officer
in the Directorate of Panchayats beyond the date of his superannuation for a period of one year w.e.f.
01-05-2023 or till the posts of Block Development Officers are filled on regular basis, whichever is earlier,

161

<!-- page 22 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

in public interest. This order is subject to Vigilance
Clearance from Vigilance Department, concurrence
of Finance Department and approval of Council of
Ministers.
The extension is further subject to termination
without assigning any reasons during the period of
extension.

of Section 12 of the Assisted Reproductive
Technology (Regulation) Act, 2021 (Central Act No.
42 of 2021), the Government of Goa hereby appoints,
the Appropriate Assisted Reproductive Technology
and Surrogacy Authority for the District of
South Goa, consisting of the following members,
namely:-

By order and in the name of the Governor of
Goa.

(1) Collector, South Goa District — Chairperson
(ex officio).

Eshant V. Sawant, Under Secretary (Personnel-II).

(2) Medical Superintendent
— Member
(South Goa District Hospital)
(ex officio).

Porvorim, 27th April, 2023.
———uuu———

Department of Public Health
–––

Order
No. 45/3/2009-I/PHD/604
Read: Memorandum No. 45/3/2009-I/PHD/60
dated 17-01-2023.
On the recommendation of the Goa Public Service
Commission as conveyed vide their letter No. COM/
/I/5/24(3)/2021/442 dated 17-01-2023, Government
is pleased to appoint Dr. Siddhant Suresh Shet to
the post of Junior Gynaecologist (Group “A”
Gazetted) under Directorate of Health Services in
the Level 10 of Pay Matrix [Pay Band-3 Rs. 1560039100+Grade Pay Rs. 5400/- (pre-revised)].
Dr. Siddhant Suresh Shet shall be on probation
for a period of two years.
Dr. Siddhant Suresh Shet has been declared
medically fit by the Medical Board.
The appointment is made subject to the
verification of the character and antecedents. In
the event of any adverse matter being noticed by
the Government on verification of their character
and antecedents, his services shall be terminated.
Consequent to above, Dr. Siddhant Suresh Shet is
posted at South Goa District Hospital, Margao.
By order and in the name of the Governor of
Goa.
Gautami Parmekar, Under Secretary (Health-II).
Porvorim, 24th April, 2023.
————

Notification

(3) Juliana Lohar (Aarz)

— Member.

(4) Shubhangi M. Humraskar,
Joint Secretary, Law

— Member.

(5) Senior Gynaecologist
(South Goa District Hospital)

— Member.

This Notification shall come into force from the
date of its publication in the Official Gazette.
This issues in supersession to Notification No.
25/1/2022-I/PHD/1179 dated 05-08-2022.
By order and in the name of the Governor of
Goa.
Gautami Parmekar, Under Secretary (Health-II).
Porvorim, 28th April, 2023.
————

Notification
No. 25/1/2022-I/PHD/636
Read: Notification No. 25/1/2022-I/PHD/1178
dated 05-08-2022.
In exercise of the powers conferred by
sub-section (2) read with Clause (b) of sub-section
(3) of Section 12 of the Assisted Reproductive
Technology (Regulation) Act, 2021 (Central Act No.
42 of 2021), the Government of Goa hereby appoints,
the Appropriate Assisted Reproductive Technology
and Surrogacy Authority for the District of North
Goa, consisting of the following members, namely:(1) Collector, North Goa District — Chairperson
(ex officio).
(2) Medical Superintendent
— Member
(North Goa District Hospital)
(ex officio).
(3) Prachi Khandeparkar (Sangath) — Member.
(4) Medhavani M. Sawaikar,
Joint Secretary, Law

— Member.

No. 25/1/2022-I/PHD/635
Read: Notification No. 25/1/2022-I/PHD/1179
dated 05-08-2022.

(5) Senior Gynaecologist
(North Goa District Hospital)

— Member.

In exercise of the powers conferred by
sub-section (2) read with Clause (b) of sub-section (3)

162

This Notification shall come into force from the
date of its publication in the Official Gazette.

<!-- page 23 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

This issues in supersession to Notification No.
25/1/2022-I/PHD/1178 dated 05-08-2022.
By order and in the name of the Governor of
Goa.
Gautami Parmekar, Under Secretary (Health-II).
Porvorim, 28th April, 2023.
————

Notification
No. 25/1/2022-I/PHD/637
Read: Notification No. 25/1/2022-I/PHD/1176
dated 05-08-2022.
In exercise of the powers conferred by
sub-section (2) read with Clause (b) of sub-section (3)
of Section 35 of the Surrogacy (Regulation) Act, 2021
(Central Act No. 47 of 2021), the Government of Goa
hereby appoints the Appropriate Authority for the
District of North Goa consisting of the following
members, namely:(1) Collector, North Goa District — Chairperson
(ex officio).
(2) Medical Superintendent
— Member
(North Goa District Hospital)
(ex officio).
(3) Prachi Khandepar (Sangath)

— Member.

(4) Pooja D. Phadte,
Joint Secretary, Law

— Member.

(5) Senior Gynaecologist
(North Goa District Hospital)

— Member.

This Notification shall come into force from the
date of its publication in the Official Gazette.
This issues in supersession to Notification No.
25/1/2022-I/PHD/1176 dated 05-08-2022.
By order and in the name of the Governor of
Goa.
Gautami Parmekar, Under Secretary (Health-II).
Porvorim, 28th April, 2023.
————

Notification
No. 25/1/2022-I/PHD/638
Read: Notification No. 25/1/2022-I/PHD/1177
dated 05-08-2022.
In exercise of the powers conferred by
sub-section (2) read with Clause (b) of sub-section (3)
of Section 35 of the Surrogacy (Regulation) Act, 2021
(Central Act No. 47 of 2021), the Government of Goa
hereby appoints, the Appropriate Authority for the
District of South Goa consisting of the following
members, namely:-

(1) Collector, South Goa District — Chairperson
(ex officio).
(2) Medical Superintendent
— Member
(South Goa District Hospital)
(ex officio).
(3) Juliana Lohar (Aarz)

— Member.

(4) Dnyaneshwar Raut Dessai,
Joint Secretary, Law

— Member.

(5) Senior Gynaecologist
(South Goa District Hospital)

— Member.

This Notification shall come into force from the
date of its publication in the Official Gazette.
This issues in supersession to Notification No.
25/1/2022-I/PHD/1177 dated 05-08-2022.
By order and in the name of the Governor of
Goa.
Gautami Parmekar, Under Secretary (Health-II).
Porvorim, 28th April, 2023.
———uuu———

Department of Public Works
Office of the Executive Engineer-Division VI
–––

Notification
No. PWD-VI/ADM/F-92/23-24/154
Whereas, the Council of Ministers, in its Vth
cabinet meeting held on 09-06-2022, vide Agenda
No. 13 resolved to approve among others shifting
part of existing internal public road leading from
Verna Industrial Estate to Verna village inside
precincts of Shree Mahalsa Narayani Devalaya,
Verna, to new location as per attached plan therein
denotifying and also surrendering old road area from
PWD to the Directorate of Archives and Archeology,
in lieu of new road to be constructed.
And whereas, the said new road as mentioned
has been constructed and commissioned for the
traffic by PWD.
Therefore in accordance with the said decision of
Council of Ministers and subsequent Government
approval, the stretch of old public road hereby stands
denotified and surrendered to Department of
Archives and Archeology.
By order and in the name of the Governor of
Goa.
Prasad Panandikar, Executive Engineer, Division VI
(Roads), PWD.
Margao, 26th April, 2023.

163

<!-- page 24 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

Department of Revenue

Department of Sports and Youth Affairs

–––

Directorate of Sports and Youth Affairs
–––

Order
Order
No. 35/2/2013-RD/562
In exercise of the powers conferred by Clause (b)
of sub-section (1) of Section 9 of the Indian Stamp
Act, 1899 (Act No. 2 of 1899), as in force in the State
of Goa, the Government of Goa hereby permits the
Life Insurance Corporation of India, Goa Divisional
Office, Panaji (hereinafter referred to as the “LIC
Goa”) to pay consolidated stamp duty of
Rs. 25,00,000/- (Rupees Twenty five lakhs only),
chargeable on sums to be insured in the insurance
policies issued by its offices in the State of Goa with
effect from 1st January, 2023 upto 31st December,
2023 in lieu of affixing stamps upon individual
insurance policies, which has been paid vide
cheque No. 000224 dated 06-02-2023, drawn on
HDFC Bank, Panaji, Goa, subject to the following
conditions, namely:(a) In case the stamp duty chargeable on the
insurance policies issued during the above
mentioned period falls short of the stamp duty
consolidated herein and paid to the
Government, the excess consolidated stamp
duty shall be adjusted for the next calendar
year 2024.
(b) In case the stamp duty chargeable on the
insurance policies issued during the above
period exceeds the stamp duty consolidated
herein and paid to the Government, the
balance amount due towards the stamp duty
shall be paid to the Government Treasury by
the LIC Goa latest by the first week of January,
2024.
(c) A detailed report of the total stamp duty
charged on the sums insured in the insurance
policies issued by the offices of the LIC Goa
in the State of Goa during the above period
shall be submitted to the Secretary (Revenue),
Revenue Department, Government of Goa on
or before 31-12-2023.
By order and in the name of the Governor of
Goa.
Durga Kinlekar, Under Secretary (Revenue-I).
Porvorim, 28th April, 2023.

164

No. 66/36th NG/ADM/DSYA/2018/268
The Government of Goa is hereby pleased to
re-constitute the Organizing Committee for the 37th
National Games Goa to decide on all the policy
making matters related to the organization and
conduct of the Games. The Organising Committee
will be the apex body. The composition of the
Organizing Committee is as follows:
Sr.
No.

Name

Designation

1

2

3

1. Hon’ble Chief Minister
2. President, Goa Olympic
Association

Chairman.
Vice-Chairman.

3. Hon’ble Minister
for Sports
4. Chief Secretary
5. Director General of Police
6. Secretary (Finance)
7. Secretary (Sports) & Chief
Executive Officer, NGOC
8. Secretary (Power)
9. Secretary (PWD)
10. Secretary (Health)
11. Secretary (Education)
12. Secretary (Tourism)
13. Secretary (Information
Technology)
14. Secretary (Transport)
15. Director (Tourism)
16. Principal Chief Engineer
(Public Works Department)

Vice-Chairman.
Member.
Member.
Member.
Member
Secretary.
Member.
Member.
Member.
Member.
Member.
Member.
Member.
Member.
Member.

17. Chief Engineer (Electricity
Department)

Member.

18. SIO (National Informatics
Centre)
19. Director of Sports & Youth
Affairs

Member.

20. Executive Director (Sports
Authority of Goa) & Jt. Chief
Executive Officer, NGOC

Member.

Member.

21. Director (Transport)

Member.

22. Additional Secretary
(Personnel)

Member.

<!-- page 25 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
1

4TH MAY, 2023

2

3

23. Additional Secretary
(Finance Expenditure)

Member.

24. Additional Secretary
(Protocol)

Member.

25. MD (Goa Tourism
Development Corporation
Ltd.)

Member.

26. Director (Health)

Member.

27. Director (Information
Technology)

Member.

28. CEO, Entertainment
Society of Goa

Member.

29. Dean (Goa Medical
College)

Member.

30. Chief Engineer (Sports
Authority of Goa

Member.

31. Secretary General (Goa
Olympic Association)

Member.

32. Representative of Indian
Olympic Association

Member.

Sr.
No.

Name

Committee
Designation

1

2

3

1.
2.
3.
4.
5.
6.
7.

8.
9.
10.

This order supersedes all earlier orders.
By order and in the name of the Governor of
Goa.
Rohit Kadam, Director (Sports & Youth Affairs) &
Jt. Secretary (ex officio).
Panaji, 24th April, 2023.

11.

Hon’ble Chief Minister
Hon’ble Sports Minister
Chief Secretary
Secretary (Finance)
Secretary (Sports) & Chief
Executive Officer, NGOC
Director of Sports & Youth
Affairs
Executive Director (Sports
Authority of Goa) & Jt. Chief
Executive Officer, NGOC
Additional Secretary
(Personnel)
Additional Secretary
(Finance-Expenditure)
Chief Engineer (Sports
Authority of Goa)
Secretary General (Goa
Olympic Association)

Chairman.
Vice-Chairman.
Member.
Member.
Member.
Member.
Member
Secretary.
Member.
Member.
Member.
Member.

This is issues with the concurrence of the Finance
Department vide FMS No. 1400091334 dated
09-03-2023.
This order supersedes all earlier orders.
By order and in the name of the Governor of
Goa.
Rohit Kadam, Director (Sports & Youth Affairs) &
Jt. Secretary (ex officio).
Panaji, 24th April, 2023.
————

————

Order

Order
No. 66/36th NG/ADM/DSYA/2018/269

No. 66/36th NG/ADM/DSYA/2018/270

The Government of Goa is hereby pleased to
reconstitute the Empowered Steering Committee for
the 37th National Games to be held in Goa to review
all the administrative and financial works, as well
as grant sanction for the appointment of the
required manpower for National Games Secretariat.
The Empowered Steering Committee will work
under the guidance of the Organizing Committee.
The Committee shall have the powers to approve
and grant the expenditure/financial proposal/
/sanction, upto Rs. 3 Crores. These proposals shall
be approved subject to the concurrence of the
Finance FA and Finance Department/Hon’ble Chief
Minister. The Committee will meet on regular basis.
The composition of the Empowered Steering
Committee shall be as follows:

The Government of Goa is hereby pleased to
reconstitute Executive Management Committee for
the 37th National Games Goa, to monitor the overall
works of the Games Secretariat. The Executive
Management Committee will meet on regular basis
and review the progress of the projects. The
composition of the Executive Management
Committee shall be as follows:
Sr.
No.
1

Name

Designation

2

3

1.

Chief Secretary

Chairman.

2.
3.

Secretary (Finance)
Secretary (Sports) &
Chief Executive
Officer, NGOC

Member.
Member.

165

<!-- page 26 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
1

4TH MAY, 2023

2

Public Service Commission vide their letter No.
COM/II/11/48(1)/2022/26 dated 13-04-2023, Shri
Jayesh Kankonkar, Assistant Tourist Officer is hereby
promoted to the post of Assistant Director of Tourism
(Group ‘B’ Gazetted) in the Pay Band of Rs. 9300-34800+Grade Pay Rs. 4600/- (Level-7 of the Pay
Matrix), plus usual allowances as admissible under
the Rules, on regular basis with immediate effect.

3

4.

Director of Sports &
Youth Affairs

Member.

5.

Executive Director
(Sports Authority of Goa)
& Jt. Chief Executive
Officer, NGOC

Member
Secretary.

The above Committee shall come into force with
immediate effect.

The above promotion is made against vacancy
occurred due to superannuation of Shri Gajanan
Mahale, Assistant Director of Tourism w.e.f.
1-12-2021.

This order supersedes all earlier orders.
By order and in the name of the Governor
of Goa.

Shri Jayesh Kankonkar shall be on probation for
a period of two years as per the Office Memorandum
No. 12/14/89-PER(Part) dated 12-8-2014.

Rohit Kadam, Director (Sports & Youth Affairs) &
ex officio Joint Secretary.

His pay and allowances shall be debited to the
Budget Head under Demand No. 78 3452—Tourism,
01—Tourist Infrastructure, 001—Direction &
Administration, 01—Directorate of Tourism,
01—Salaries.

Panaji, 24th April, 2023.
———uuu———

Department of Tourism
–––

By order and in the name of the Governor
of Goa.

Order
No. 1/2(44)/2023/DT/Part-I/434

Suneel Anchipaka, IAS Director (Tourism) & ex
officio Addl. Secretary.

On the recommendation of the Departmental
Promotion Committee as conveyed by the Goa

Panaji, 2nd May, 2023.

———uuu———

Department of Urban Development
(Municipal Administration)
–––

Order
No. 11/11/2022-2-DMA(MISC)/221
With reference to “The Prohibition of Employment as Manual Scavengers and their Rehabilitation Act,
2013 (MS Act, 2013)”, Ministry of Social Justice & Empowerment (MoSJE) and Ministry of Housing and
Urban Affairs (MoHUA) has jointly formulated a scheme “National Action for Mechanized Sanitation
Ecosystem” (NAMASTE) in 2022, and mandated the appointment of Responsible Sanitation Authority (RSA)
in every District and setting up of Sanitation Response Unit (SRU) in all the Urban Local Bodies (ULBs).
MoHUA has integrated Safaimitra Suraksha as an important parameter under Swachh Survekshan 2023
toolkit and mandated the requirement of establishment and operationalization of RSA in every district and
SRU in all ULBs.
As per the requirements of NAMASTE Scheme and Swachh Bharat Mission (Urban), the Additional
Collector-II, South Goa is designated as the “Responsible Sanitation Authority” for assisting South Goa
Municipal Councils i.e. Mormugao, Margao, Canacona, Cuncolim, Quepem, Cacora-Curchorem and Sanguem
in successfully implementing the aforementioned protocols.
The composition of the ERSU (Emergency Response Sanitation Unit) under Responsible Sanitation
Authority (RSA) is mentioned as under and the Officer/staff will perform the duty in addition to their
current duty with immediate effect:-

166

<!-- page 27 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5

4TH MAY, 2023

Sr.
No.

Officer/Staff

Designation

Nature of Appointment

1

2

3

4

1. Officer-in-charge of ERSU

Municipal Commissioner/Chief Officer

Additional Role.

2. Duty/Entry Supervisor

PWD Junior Engineer

Additional Role.

3. Administrative Supervisor/
/Nodal Officer

Junior Engineer, Municipal Council

Additional Role.

4. Call Centre Attendant

Helpline Operator, Municipal Council
on 24x7 basis

Full Time Duty.

5. Sewer Entry Professionals
(Sewer Commandos)

Staff available with PWD and additional
staff available with ULB

Full Time/Additional Role.

The following table shows role and responsibility of Emergency Sanitation Response Unit (ESRU).
1. To take care of emergency situations of blockages of sewers & septic tanks and thereby preventing
manual hazardous cleaning.
2. Establishing ‘Incidence Management System’ (IMS) for addressing the service and complaint requests
received from the citizens on the Helpline number-14420, through an online tracking system.
3. To ensure the closing of the complaints/tickets registered on the Web and Mobile Application for
‘Incidence Management System’ (IMS).
4. Monthly progress report to be updated by 5th day of the month on SBM portal by Administrative
Supervisor.
5. To co-ordinate with the Assessment Agency (Third Party) from the Ministry during evaluation process
& for submission of requisite documents.
Gurudas P. Pilarnekar, Director (Urban Development).
Panaji, 25th April, 2023.
————

Notification
No. 11/11/2022-2-DMA(MISC)/222
Whereas, with reference to the Prohibition of
Employment as Manual Scavengers and their
Rehabilitation Act, 2013 (MS Act, 2013), Ministry of
Social Justice & Empowerment (MoSJE) and Ministry
of Housing and Urban Affairs (MoHUA) has jointly
formulated a scheme “National Action for
Mechanized Sanitation Ecosystem” (NAMASTE) in
2022.
Whereas, one of the objectives of the NAMASTE is
the appointment of Responsible Sanitation Authority
(RSA) in every District and setting up of Sanitation
Response Unit (SRU) in all the Urban Local Bodies
(ULBs).
Whereas, Swachh Survekshan and Swachh
Certification protocol launches under Swachh Bharat
Mission Urban 2.0 the mandates the requirement of
establishment and operationalization of RSA in
every district and SRU in all ULBs.
Now therefore, in light of the above, the Additional
Collector-II, South Goa is hereby designated as the
“Responsible Sanitation Authority” (RSA) for
assisting all seven Municipal Councils in South Goa

district (i.e. Mormugao, Margao, Cuncolim, Quepem,
Curchorem-Cacora, Sanguem and Canacona) in
successfully implementing the NAMASTE scheme
and Swachh Bharat Mission (Urban) requirements.
The Responsible Sanitary Authority will be the
overall authority for ensuring the implementation of
NAMASTE and Swachh Bharat Mission (Urban)
Guidelines and ensure the proper functioning of the
SRUs established at ULB level in their jurisdiction.
The key responsibilities of RSA includes the
following:
1.

Overall supervision of the Emergency
Sanitation Response Unit (ESRU) at the ULB
level.

2.

Timely review of the progress made by the
Emergency Sanitation Response Unit (ESRU)
at the ULB level.

3.

Oversee maintenance of safety equipment
(personal and institutional) for use by
trained personnel and Safai mitras as part of
the Emergency Sanitation Response Unit.
Arrange to provide periodic upgradation,
and necessary equipment, vehicles and other
logistics and proper functioning of ERSU.

4.

167

<!-- page 28 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 5
5.

4TH MAY, 2023

Arrange for adequate training to employees
involved and sewer and septic tank
maintenance.

In addition to the above, RSA shall also be
responsible for all other functions as given under
guidelines of NAMASTE and MoHUA Advisory on
Emergency Sanitation Response Unit from time to
time.
By order and in the name of the Governor of
Goa.
Gurudas P. Pilarnekar, Director (Urban
Development).
Panaji, 25th April, 2023.
————

Addendum
No. 11/11/2022-2-DMA(MISC)/220
In partial modification of the Notification No. 11/
/11/2022-2-DMA(MISC)Part-I/4930 dated 25-01-2021,
the Additional Collector-II, North Goa is was
designated as the “Responsible Sanitation
Authority” for assisting Corporation of City of Panaji
in successfully implementing the national
competition “Safaimitra Suraksha Challenge”.
Whereas, Swachh Survekshan, RSA shall be
notified for all the other six Municipal Councils in
the North Goa District.
Therefore, the Additional Collector-II, North Goa
is hereby designated as “Responsible Sanitation
Authority” for six Municipal Councils in North
District i.e. Pernem, Mapusa, Bicholim, Sanquelim,
Valpoi and Ponda. The RSA shall assist all the seven
Municipal Councils “including Panaji Municipal
Corporation for the successful implementation of
the NAMASTE scheme and Swachh Bharat Mission
(Urban).
The responsible Sanitary Authority will be the
overall authority for ensuring the implementation
of NAMASTE and Swachh Bharat Mission (Urban)
guidelines and ensure the proper functioning of the
SRUs established at ULB level in their jurisdiction.

The key responsibilities of RSA includes the
following.
1. Overall supervision of the Emergency
Sanitation Response Unit (ESRU) at the ULB
level.
2. Timely review of the progress made by the
Emergency Sanitation Response Unit (ESRU)
at the ULB level.
3. Oversee maintenance of safety equipment
(personal and institutional) for use by trained
personnel and Safai mitras as part of the
Emergency Sanitation Response Unit.
4. Arrange to provide periodic upgradation, and
necessary equipment, vehicles and other
logistics and proper functioning of ERSU.
5. Arrange for adequate training to employees
involved and sewer and septic tank
maintenance.
The following table shows role and responsibility
of Emergency Sanitation Response Unit (ESRU).
1. To take care of emergency situations of
blockages of sewers & septic tanks and thereby
preventing manual hazardous cleaning.
2. Establishing ‘Incidence Management System’
(IMS) for addressing the service and complaint
requests received from the citizens on the
Helpline number-14420, through an online
tracking system.
3. To ensure the closing of the complaints/tickets
registered on the Web and Mobile Application
for ‘Incidence Management System’ (IMS).
4. Monthly progress report to be updated by 5th
day of the month on SBM portal by
Administrative Supervisor.
5. To co-ordinate with the Assessment Agency
(Third Party) from the Ministr y during
evaluation process & for submission of
requisite documents.
Gurudas P. Pilarnekar,
Development).

Director (Urban

Panaji, 25th April, 2023.

www.goaprintingpress.gov.in
Published and Printed by the Director, Printing & Stationery,
Government Printing Press,
Mahatma Gandhi Road, Panaji-Goa 403 001.
PRICE–Rs. 28.00
PRINTED AT THE GOVERNMENT PRINTING PRESS, PANAJI-GOA—38/80—05/2023.

168
