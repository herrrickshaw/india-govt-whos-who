---
doc_id: "dfd2a0c979c1bf4e"
source_url: "https://gcarch.goa.gov.in/wp-content/uploads/2023/06/20070202-Consultancy-Services-Order.pdf"
ministry: "Goa College of Architecture, Goa"
title: "DTE Consultancy Services Scheme"
date: ""
pages: 2
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "8ddf704514c19338"
---

<!-- page 1 -->

शी “je
ea
NA ._' GOVERNMENT OF GOA
ह DIRECTORATE OF TECHNICAL EDUCATION
; . - पास न OEE ली
ve ofc ol Arcaitecture No. DTE/52/Con.Serv./2006/ 27
i - SEG Dated 25-01-20
623 "| ORDER onfe2.
OSletlep te |
| | 7 ~“Approvat of the Government is hereby conveyed to the ‘Consultancy

Services Scheme’ for the teachers of technical institutes under the control ot

Directorate of Technical Education, in order to keep the teachers, students

and the institutes abreast with the innovations in the industry, and induce .

accountability required by the industry,

The ‘Consultancy Services Scheme’ for Technical ‘Teachers shall follow

the following guidelihes: - . न

1. Types of Projects; Consultancy projects shall be of two types, viz. Type
tellpatitutional and Type-II (Non-Institutional). The projects of Type-I
shall involve participation of teachers or group of teachers using the
institute’s infrastructure facilities, such as workshop, laboratories, .
computers, office space, electricity, ete. The Projects of type-II. shall
involve participation of teachers without using any of the institute’s

. infrastructures.

2. Assessment of fees/revenue: - While working out the fees/charges for
carrying out the consultancy project, suitable method of estimation may
be used. These would include either

- a. Fixing gascontags of the total cost Gi Eroject, as in the case of
architectural, structural engineering design projects, etc. OR
फण. Estimates worked out on the basis of required Manshourginput a
different levels and expenditure to’ be incurred Purchase of
material, use of outside labour, use of outside consultants,
computer charges, etc, भं
Suituble charges for Werheads upto 15% should be added to the cost
: estimated as above, to cover indirect costs such as use of electricity, building
‘ Space, stationery, etc. This amount should go to the revenue account of the
“यया institution. ‘

"3, Sharing of the Revenue:- After meeting all expenses and remitting
the 15% overhead to the revenue account of the institute, the revenue
earned from the consultancy work shall be shared as follows.

a. Consultancy project Type-I:
1. 5७% ७. 88 रय 9) Galland, of the Institute
ii, 50% to be bared ty he team involved with the work including
supporting stalt . .
b. Consultency Project Type-II:
i. शरद नयाय गि of the Institute
- \- fi. 0% to be shares apelin involved with the work
. } yale bg. Management: - To facilitate Proper distribution of the work amongst
. vy the faculty members, a committee consisting of (three members), viz.
: \c- iLO ee Se
‘ : Ae? DisthiSete 76 lacy Tac "५ Facucry र
DTE BUILDING, ALTO-PORVORIM, BARDEZ, GOA, 403521, PH./ FAX 2413571,
— OAR, een f few १ Ceuststleoeny " नशे “I .
_ 7. रश 7 1 u
Scanned with CamScanner

<!-- page 2 -->

w
rod . t
Principal, senior most faculty/Vice principal and head of the departmer
concerned shall be constituted. The senionmost faculty/Vice principal
(other than Principal) shall be the Chaizman of the committee. The
SQmunittcs shall be responsible for following as administrative work of
the institute, without taking any remuneration for the same
a. Distribution the work to the faculty members,
b. Receipt of the fees from the client,
c. Deposit of 15% of gross fees to revenue account (Govt. treasury),
d. Distribution of fees amongst the consultants and supporting staff,
,
e. Approval of the pattern/percentage or actual amount as permissible
expenses on the project,
f. Payment to development fund and consultants.
. 5. Coverage: - All teachers of technical institutes under control of the
Directorate of Technical Education, including teachers working in the
2 Directorate of Technical Education shall be covered in the scheme. For :
this purpose, the Directorate.shall also have a consultancy cell.

‘ 6. Higher Limit: - There would not be higher limit on the quantum of
consultancy work a teacher can take or remuneration he can earn,
provided that the same is physically possible after attending to the
duties and work load due in the institute as defined by the Government

. . for pay scales and service conditions. २७७७8७७४७७ concession shall
be ranted! dpsbbesduticnon account of consultancy work: nor any special
भन leave shall be granted to attend out station consultancy work,
7. Accounts & Audit: The institute shall open.a sgparateaccountsfor
: _ ५७25456 and dexlopmentfand, to be operated jointly by
the Principal and the Chairman of the committee. The Govt. norms/
‘ * guidelines prescribed for financial transactions should be followed. The
accounts of the consultancy shall be under preview ofthe. Audit.
. This issues with the concurrence of Finance Secretary, vide note No, 07
- dated 02-01-2007(F.No,DTE/52/Con.Serv./2006. .
ins
lo
. (Dr. J. Chandrasekhar)
Director of Technical Education &
aa Ex-Officio Additional Secretary
Copy to: - «
1.. The Director of Accounts, Panaji
2. The Joint Director ofAkccounts, South branch, Margaon, Goa, .
प 3. The Sr. Deputy Accountant General, Audit, Audit Bhavan, Green valley, Porvorim
xt -A.O., (P&A), Directorate of Technical Education, Parvarim, वि
. Principals, of all Degree Colleges (4), G-¢ + Axth. _ pony
6. Principals, of all Polytectinics (5) .
7. All officers working in Directorate of Technical Education, Porvorim. oY
8. Office file, Guard File . :
. —_— eee
DTE BUILDING, ALTO-PORVORIM, BARDEZ; GOA, 4013521, PH. / FAX 2413571,
Scanned with CamScanner
