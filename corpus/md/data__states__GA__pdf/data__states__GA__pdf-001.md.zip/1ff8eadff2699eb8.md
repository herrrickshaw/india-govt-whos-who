---
doc_id: "1ff8eadff2699eb8"
source_url: "https://gazetteer.goa.gov.in/wp-content/uploads/2024/02/Order-of-Taluka-Gazetteer-Committee.pdf"
ministry: "Gazetteer Department, Goa"
title: "Order of Taluka Gazetteer Committee"
date: ""
pages: 38
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f464345ff7d9e831"
---

<!-- page 1 -->

Reg. No. RNP/GOA/32/2021-2023

RNI No. GOAENG/2002/6410

SERIES II No. 51

Panaji, 23rd March, 2023 (Chaitra 2, 1945)

PUBLISHED BY AUTHORITY

Note:- There is one Supplement and one Extraordinary
issue to the Official Gazette, Series II No. 50 dated
16-03-2023 as follows:—
(1) Supplement dated 16-03-2023 from pages 3029 to
3030 regarding Notification from Department of
Town and Country Planning.
(2) Extraordinary dated 17-03-2023 from pages 3031
to 3032 regarding Notifications from Department
of Finance.

GOVERNMENT OF GOA
Department of Agriculture

5.

6.
7.

Shri Kishor K. Naik, r/o
— Member.
H. No. 155/26, Nr. Kamat
Nursing Home, Durghabhat,
Ponda-Goa
Shri Prasad Kundaikar, r/o
— Member.
Chodan, Mayem-Goa
Shri Divakar Anand Pagi, r/o — Member.
H. No. 50, Palolem,
Canacona-Goa
By order and in the name of the Governor of
Goa.

Nevil Alphonso, Director & ex officio Jt. Secretary
(Agriculture).
Tonca, Caranzalem, 15th March, 2023.

Directorate of Agriculture
–––
Order

Department of Co-operation

No. 3/3/Hort/SSS-GSHCL/1/2022-23/D.Agri/766

Office of the Registrar of Co-operative Societies

Read: Order No. 2/12/98-D.Agri/Part II/48 dated
20-04-2022.

Order

In pursuance of Article 76 (i) of Articles of
Association of the Goa State Horticulture
Corporation Ltd.; and further to above referred
Order, Government of Goa is pleased to appoint the
following as Members of Board of the Goa State
Horticulture Corporation Ltd.; in addition to those
appointed vide above referred Order dtd.
20-04-2022.
1.

Shri Vishwas Chodankar, r/o — Member.
Mayem, Bicholim-Goa

2.

Shri Santosh Malik, r/o
Cudnem, Bicholim-Goa

— Member.

3.

Shri Ramesh Ghadi, r/o
Saligao, Bardez-Goa

— Member.

4.

Shri Rupak Desai, r/o Flat
No. T-3, Bldg. No. 5-C,
Kurtarkar Nagari, St. Cruz,
Ponda-Goa

— Member.

———uuu———

–––

No. 19/01/2014/VUCCS/TS/RCS/part/Suppl./4814
Read: 1) This Office Order No. 19/01/2014/VUCCS/
/TS/RCS/part/1894 dated 29-09-2021.
2) This Office Addendum No. 19/01/2014/
VUCCS/TS/RCS/part/2466 dated 17-11-2021.
3) Letter No. VUCCS/Regis./letter/2022-23/
/184 dated 05-11-2022 from Vishwanath
A. Chodankar, Authorised Recovery and
Sales Officer of the Vasco Urban Co-op.
Credit Society Ltd., Vasco-da-Gama.
Whereas, vide order referred at Sr. No. 1 above,
Shri Vishwanath A. Chodankar, Branch Manager of
Margao Branch, the Goa State Co-operative Bank
Ltd., was empowered to recover certain sums by
attachment and sale of property and execution of all
recovery orders of decree holder viz. The Vasco Urban
Co-operative Credit Society Ltd., 3, Commerce
Centre, Vasco-da-Gama, Goa.

Suggestions are welcomed on e-mail: dir-gpps.goa@nic.in

3033

<!-- page 2 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023
after referred to as “Act”) and in furtherance of the
delegation of powers made vide Notification dated
30-09-2020 read at No. 1 above subjected to
conditions imposed on the exercise of delegated
powers vide Nos. 2 to 4 above, and in public interest
to further streamline the functioning of this office,
the following arrangements are hereby made as
under regarding the exercise of delegated powers of
Registrar by the Deputy Registrar of Co-operative
Societies (Tech.), Deputy Registrar of Co-operative
Societies (Admn.) and the Assistant Registrars of
Co-operative Registrars and the Co-operative
Officers posted at Head Office and working in
various sections at Head Office like Technical/
/Election/Audit/Inspection, etc. under the Head
Office situated at Panaji for the purpose of
discharging duties and functions under the Act and
Rules.

And whereas, the addendum to the aforesaid
order was issued vide Sr. No. 2 referred above.
And whereas, aforesaid order at Sr. No. 1 was in
force for one year from 29-09-2021 to 28-09-2022.
And whereas, vide letter read at Sr. No. 3 above,
the Authorised Recovery and Sales Officer of the
Vasco Urban Co-op. Credit Society Ltd., Vasco-da-Gama has informed that the period of the order
read at Sr. No. 1 above is expired on 28-09-2022 and
requested to extend the powers delegated to him
vide said order for further period with retrospective
effect from 29-09-2022.
Now therefore, I, the undersigned Registrar of
Co-operative Societies, hereby extend the powers
delegated to the Authorised Recovery and Sales
Officer vide order referred at Sr. No. 1 above, with
retrospective effect from 29-09-2022 to 28-09-2024.

1) The existing Sections at Head Office viz. Audit
(ADT), Inspection (INSP), Technical Section-I (TS I),
Technical Section-II (TS II) & Election Section (ELE)
stands re-organized in such a manner that all the
activities of the said sections are brought under a
single section (Wing) under which all aspects of the
monitoring/supervision over functioning of Societies
starting from its registration till winding up affairs
(if needed) in relation to all Societies registered
under a particular Zone shall be dealt with/
processed by a single Section/Wing at Head Office
level consisting of a sectional head and a dealing
hand.

The undersigned reserves right to withdraw the
said order at any time without assigning any reason
thereof.
Given under the seal of this office.
Vishant S. N. Gaunekar, Registrar (Co-operative
Societies) & ex officio Joint Secretary (Co.op.).
Panaji, 14th March, 2023.
————

Notification
No. 42/4/2022/GEN/TS/RCS/4895
Read: 1. Notification No. 42/4/2008/TS/RCS/2200
dated 30-09-2020 published in Official
Gazette, Series II No. 28 dated 08-10-2020.

2) Consequent to above re-arrangements, the
Nomenclature of the existing sections at Head Office
and the reference to sectional heads Assistant
Registrar of Co-operative Societies (ARCS) and
Co-operative Officers (C.O.) is hereby changed and
re-aligned as under. All the work, duties and
responsibilities/tasks at the level of Head Office
assigned to the respective wings shall be as given
in the Annexure appended to this Notification. All
Sectional Heads/Wing Incharge shall work and
discharge all the duties and attached responsibilities
under the general guidance and supervision of the
respective Deputy Registrar who is the District Level
Incharge (D.L.I.), subject to the overall control and
superintendence of the Registrar.

2. Notification No. 42/4/2022/GEN/TS/RCS/
/2504 dated 18-10-2022 published in
Official Gazette, Series II No. 30 dated
27-10-2022.
3. Order No. 42/4/2022/GEN/TS/RCS/3190
dated 30-11-2022 published in Official
Gazette, Series II No. 30 dated 27-10-2022.
4. Order No. RCS/Office order/TS/2001-02/
/Vol.I/Suppl/3248 dated 02-12-2022.
In exercise of the powers conferred under Section
4 read with Section 123B of the Goa Co-operative
Societies Act, 2001 (Goa Act No. 36 of 2001) (hereinSr.
No.

Existing Nomenclature
at H.O.

New Nomenclature
at H.O.

Nomenclature of Section &
Area at work allotted

1

2

3

4

1.

3034

Assistant Registrar (Audit)

Assistant Registrar (Wing I)

Wing I
All societies registered at Head
Office;
All proposals/correspondence of
Central Zone, Panaji.

<!-- page 3 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
1

23RD MARCH, 2023
2

3

4

2.

Assistant Registrar (HQ)

Assistant Registrar (Wing II)

Wing II
All proposals/correspondence of
South Zone, Margao;
All proposals/correspondence of
Quepem Zone, Quepem.

3.

Assistant Registrar
(Elections North)

Assistant Registrar (Wing III)

Wing III
All proposals/correspondence of
Ponda Zone, Ponda.

4.

Assistant Registrar
(Elections South)

Assistant Registrar (Wing IV)

Wing IV
All proposals/correspondence of
North Zone, Mapusa.

5.

Assistant Registrar
(Marketing)

Assistant Registrar (Wing V)

Wing V
All proposals/correspondence of
Bicholim Zone, Bicholim.

6.

Co-operative Officer/
/Special Auditor
(Technical I)

C. O. I

All proposals/correspondence of
South Zone, Margao and Quepem
Zone, Quepem.

7.

Co-operative Officer/
/Special Auditor
(Technical II)

C. O. II

All proposals/correspondence of
Head Office.
All proposals/correspondence of
and Ponda Zone, Ponda.

8.

Co-operative Officer/
/Special Auditor (Audit)

C. O. III

All proposals/correspondence of
North Zone, Mapusa.

9.

Co-operative Officer/
/Special Auditor (Inspection)

C. O. IV

All proposals/correspondence of
Central Zone, Panaji.

10.

Co-operative Officer/Special
Auditor, Election (North/South)

C. O. V

All proposals/correspondence of
Bicholim Zone, Bicholim.

3) The Registrar may on administrative grounds
and in exigencies of public work, re-allocate or
reshuffle/modify the work allotted to any or all
Wings at Head Office.
4) The files/proposals shall be moved by
respective dealing hands through the respective
Co-operative Officers assigned to each Wing and
onwards to the Assistant Registrar and then
through respective Deputy Registrar/District Level
Incharge to the Registrar as per the delegation of
powers.
5) The respective Sectional Incharge/Wing
Incharge and the C.O. placed in the respective wing
shall be responsible for preparing/compiling/
/collating all such consolidated reports on the
statutory and such other administrative
compliances/reports from the respective Zone
allotted to concerned Wing. Apart from this, the
work of compilation/consolidation at Head Office
level as mentioned in detail in the Annexure
appended hereto shall be the responsibility of each
Wing at Head Office to which such work is allotted.

6) The timelines laid down under the Act/Rules/
/Notifications/Circulars/Orders, etc. shall be strictly
followed and in cases where there is no statutory
timeline, it shall be ensured that each
correspondence shall be put up within 10 working
days from the date of receipt of Tapaal/Daak/
/correspondence by concerned Wing from the
Inward section.
7) The respective Co-operative Officers shall
monitor the functioning of the dealing hands under
their control by taking weekly review and ensure
that all the Tapaal/correspondence is replied/
/disposed within 10 working days, unless a shorter
period is prescribed under the Act/Rules or any
other standing instructions and fix responsibility/
/liability to that effect on each individual official/
dealing hand by issuing precise work orders with
the approval of the Registrar.
8) The Establishment section shall maintain
record of the inward and outward flow of all
correspondence/files/registers/applications, etc.
received in the Head Office and shall be responsible
for distribution of the same among all the Wings.

3035

<!-- page 4 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

The Assistant Registrar and Co-operative Officer of
the respective wing shall also maintain up-to-date
records of all correspondence and files in systematic
manner with proper inventory of all records.

/District Level Incharge (South) as the case may be
shall assess the work allotment of respective wings
under their control at the end of every financial
year and may recommend any changes as per need.

9) The numbering system of all files and
maintaining of records in the Wing shall be suitably
revised. While opening any new file, the file number
to be allotted shall contain the following details viz.
the subject head first, then year of opening file, the
wing number, followed by district abbreviation and
finally words RCS, separated using mark ‘/’. For
example, “No. 15/2023-24/Wing-I/North/RCS/”. The
specific subject head for giving file number shall be
defined in advance for handling different subjects.
The new files shall be opened accordingly as per
requirements and also by mentioning the details on
the file register. As far as practicable one separate
file for each society shall be opened/maintained to
deal with all correspondence of one particular
Society. The records of the society shall be
maintained as per provisions of the Act and time to
time weeding out procedure shall be followed to
avoid unnecessary pilling of records. The details of
indexing and file numbers shall be maintained by
EST/ADMIN Section.

12) The establishment Section, immediately
after the issue of this notification shall put up a
proposal for issue of a revised Order under
Provisions of the Right to Information Act, 2005
(Central Act No. 22 of 2005) for designating the
Assistant Registrar incharge of the respective Wing
as the P. I. O. for their respective section/wing and
the concerned Co-operative Officer as A.P.I.O. The
respective Deputy Registrar/District Level Incharge
shall be designated as the First Appellate Authority
(F.A.A.) under the R.T.I. Act, 2005.

10) The Asstt. Registrar and Co-operative Officer
of the respective wings shall ensure that all
correspondence is delivered to respective dealing
hands within shortest possible duration and in any
case within 3 working days from the date of receipt
at Inward Counter.
11) The Deputy Registrar (Tech.)/District Level
Incharge (North) and Deputy Registrar (Admin.)/

13) The concerned Assistant Registrar incharge
of the respective wing shall be responsible for
obtaining all the data/information/reports from the
Zonal offices and its compilation at State level for
submission to various authorities as may be needed
from time to time.
14) All the Assistant Registrar and Co-operative
Officers who are incharge of particular wing, shall
in addition to the above work assignment, perform
all additional responsibilities as per the Annexure
appended hereto.
Given under the seal of this office.
Vishant S. N. Gaunekar, Registrar (Co-operative
Societies) & ex officio Joint Secretary (Co-operation).
Panaji, 20th March, 2023.

ANNEXURE
Sr.
No.

Present
Nomenclature
of the
Section at H.O.

New
Nomenclature
at H.O.

Area allotted
for work

Statutory subjects
alloted as per
Goa Co-operative
Societies Act, 2001 &
The Goa Co-operative
Societies Rules, 2003
and statutory reports

Other additional
subjects allotted

1

2

3

4

5

6

1.

ARCS
(Audit)

ARCS
Wing (I)

All Societies
registered at
head office
and Central
Zone, Panaji

3036

1. All Statutory duties
and responsibilities
under the Act/Rules
(from Chapter I to
Chapter XIV of the Act)
2. All statutory reports
as required to be
prepared in respect of
Zones pertaining to the
wing
3. Compilation of all
State level reports after
obtaining information

(i) R.B.I. in respect of
Co-operative Banks
and other related
matter.
(ii) All correspondence
on State level Bankers/
/S H G C o m m i t t e es/
/Executive Committees/
/Consumer protection
Council etc.
(iii) All Officers meeting
before Deputy Registrar,
RCS, Secretary and
Hon’ble Minister and

<!-- page 5 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
1

2

23RD MARCH, 2023
3

4

5

6

from all wings in respect Hon’ble Chief Minister
of Sections 4 to Section Office, etc.
34 of the Act
(iv) All work relating
to amendment to G.C.S.
Act
and
Rules.
(v) Matter related to
d e v e l o p m e n tof
e-Co-operative
management system.
(vi) Monthly attendance
of staff.
(vii) Maintenance of
inventory, dead stock,
weeding of records,
stationery, dead stock
etc.
(viii) All matter on LAQ,
RSQ, LSQ Assurances
& cut motion, zero-hour
mention, calling attention,
any other matter, etc.
as and when allotted.
(ix) All R.T.I. matters
related to the WING
and on other subject
matter allotted.

2.

ARCS (HQ)

ARCS Wing
(II)

All societies
registered at
South Zone,
Margao and
Quepen Zone,
Quepem

(x) Any other duties
and responsibilities
assigned by the
superiors from time to
time
1. All statutory duties
(i) All court matters
and responsibilities
before various courts
under the Act/Rules
and report of cases
(from Chapter I to
thereof.
Chapter XIV of the
(ii) Para wise comments
Act)
and briefing of Advocates
2. All statatury reports
on all court matters.
as required to be
(iii) Multi State
prepared pertaining
Co-operative Societies.
to the wing.
(iv) Matter related to
3. All State level reports
Central Registrar of
after obtaining information Co-op. Societies.
from all wings pertaining (v) Co-operative Award.
from Section 35 to
(vi) Co-operative week.
Section 57 of the Act.
(vii) NABARD lead
bank and other.
(viii) DRDA South and
North. Programme and
submission of MPRS,
QPRS thereof.
(ix) Monthly attendance
of staff.

3037

<!-- page 6 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
1

2

23RD MARCH, 2023
3

4

5

6

(x) All R.T.I. matters
related to the WING
and on other subject
matter allotted.
(xi) SLCC, REIC, etc.,
and all such other
National/State level
committees constituted
by various authorities
from time to time,
meetings, proceedings
and related correspondence and followup action.
(xii) Matters related to
public grievances and
referred at grievance
portal, PM portal on
grievances.
(xiii)
Report
on
attendance of staff.
(xiv) Maintenance of
inventory, dead stock,
weeding of records,
stationery, dead stock
etc.

3.

ARCS
(ElectionNorth)

3038

ARCS
Wing (III)

All societies
registered at
Ponda Zone,
Ponda

(xv) All matter on LAQ,
RSQ, LSQ Assurances &
Cut motion, zero-hour
mention, calling attention
etc. as and when allotted.
(xvi) Any other duties
and responsibilities
assigned by the superiors
from time to time.
1. All statutory duties
(i) All correspondence
and responsibilities under received from other
the Act/Rules (from
Government and public
Chapter I to Chapter
undertaking Departments.
XIV of the Act)
(ii)Release of Advertisement
2. All statutory reports
and processing of its bills.
as required to be
(iii) All matters related
prepared pertaining
to training to
to the Wing
co-operative sectors by
3. All State level reports Vamnicom Pune and
after obtaining
all other correspondence
information from all
received from various
wings pertaining from
training institutes
Section 58 to Section 82 in India.
of the Act.
(iv) Matter on study
tours of various training
institute of India.

<!-- page 7 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
1

2

23RD MARCH, 2023
3

4

5

6

(v) All R.T.I. matters
related to the WING
and on other subject
matter allotted.
(vi) Maintenance of
inventory, dead stock,
weeding of records,
stationery, dead stock
etc.
(vii) All matter on LAQ,
RSQ, LSQ Assurances &
cut motion, zero hour
mention, calling attention
etc. as and when allotted.

4.

ARCS
(ElectionSouth)

ARCS
Wing (IV)

All societies
registered at
North Zone,
Mapusa

(viii) Monthly attendance
of staff.
(ix) Any other duties
and responsibilities
assigned by the superiors
from time to time.
1. All statutory duties
(i) OTS scheme for Bank
and responsibilities under and Societies.
the Act/Rules (from
(ii) Deposit protection/
Chapter I to Chapter
/Guarantee Scheme.
XIV of the Act)
(iii) Matter related on
2. All statutory reports
exemption of stamp duty.
as required to be
(iv) All matters on issuing
prepared pertaining
of Circulars, Notifications,
to the Wing
Guidelines under the
3. All State level reports provision of Act & Rules.
after obtaining
(v) Maintenance of
information from all
various funds:
wings pertaining from
a) Surplus Fund Account.
Section 83 to Section
b) Co-operative
100 of the Act
Development Fund
Account.
c) Election Fund
Account.
d) Account under
Deposit Guarantee
Scheme if any.
(vii) Matters related to
NCUI, IFFCO, NAFED,
bankers institute of
rural development, all
Government of India
undertakings, etc.
(viii) Monthly attendance
of Staff.
(ix) All R.T. I. matters
related to the WING
and on other subject
matter allotted.

3039

<!-- page 8 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
1

2

23RD MARCH, 2023
3

4

5

6

(x) Maintenance of
inventory, dead stock,
weeding of records,
stationery, dead stock
etc.
(xi) All matter on LAQ,
RSQ, LSQ Assurances &
cut motion, zero hour
mention, calling attention
etc. as and when allotted.
(xii) Any other duties
and responsibilities
assigned by the
superiors from time to
time.
5.

ARCS
(Marketing)

ARCS
Wing (V)

All societies
registered at
Bicholim Zone,
Bicholim

1. All statutory duties
and responsibilities under
the Act/Rules (from
Chapter I to Chapter
XIV of the Act)
2. All statutory reports
as required to be
prepared pertaining
to the Wing
3. All State level reports
after obtaining
information from all
wings pertaining from
Section 101 to Section
129 of the Act

(i) All matters related
to annual administrative
report.
(ii) All matter related to
money lending/Flat
ownership Act and any
other Act and Rules
and related
Correspondence.
(iii) All matters relating
to TAFCUB, TAFCUS of
all wings.
(iv) All matters pertaining
to observation of RAO,
House Committee,
Select Committee,
Public Account
Committee etc.
(v) Monthly, Quarterly
Departmental reports
submitted to Governor
other departments,
Report on developmental
activities and all other
state level reports to
be submitted to the
various authorities.
(vi) All R.T.I. matters
related to the WING
and on other subject
matter allotted.
(vii) Maintenance of
inventory, dead stock,
weeding of records,
stationery, dead stock
etc.

3040

<!-- page 9 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
1

23RD MARCH, 2023

2

3

4

5

6

(viii) All matter on
LAQ, RSQ, LSQ
Assurances & cut
motion, zero hour
mention, calling attention
etc. as and when allotted.
(ix) Monthly attendance
of staff.
(x) Any other duties
and responsibilities
assigned by the
superiors from time to
time.
———u———

Office of the Asst. Registrar of Co-operative
Societies
–––

Notification
In exercise of the powers vested in me under
Section 8 of the Goa Co-operative Societies Act, 2001,
“Valpoi Multipurpose Co-operative Society Ltd.,
Near Hanuman High School, Velus, Thane Road,
Valpoi, Sattari-Goa”-Goa is registered under code
symbol No. RCSBZ2022-230008.
Mahadev N. Kalangutkar, Asstt. Registrar
(Co-operative Societies), Bicholim Zone.
Sanquelim, 10th March, 2023.
Certificate of Registration
“Valpoi Multipurpose Co-operative Society Ltd.,
Near Hanuman High School, Velus, Thane Road,
Valpoi, Sattari-Goa”-Goa has been registered on
10-03-2023 and it bears registration code symbol
No. RCSBZ2022-230008 and its classified as “Resource
Society” under sub-classification “No. 10-(c)-Service
Resource Society” in terms of Rule 8 of the Goa
Co-operative Societies Rules, 2003.
Mahadev N. Kalangutkar, Asstt. Registrar
(Co-operative Societies), Bicholim Zone.
Sanquelim, 10th March, 2023.
———uuu———

Department of Education, Art & Culture
Directorate of Higher Education
–––

Order
No. ACADIII/GC/FILLING OF POST/50/2021/
/37891
Read: Memorandum No. ACADIII/GC/FILLING OF
POST/50/2021/30018 dated 13-12-2022.

On the recommendation of the Goa Public Service
Commission as conveyed vide their letter No. COM/
/I/5/78(3)/2020/307 dated 21-10-2022, Government
is pleased to appoint Ms. Jofa Anton Gonsalves to
the post of Assistant Professor in Konkani in
Government College of Arts, Science and
Commerce, Quepem-Goa under Directorate of
Higher Education on temporary basis in the UGC
Pay Scale Matrix Level 10 with immediate effect,
and as per the terms and conditions contained in
the Memorandum cited above. She shall be on
probation for a period of two years.
Ms. Jofa Anton Gonsalves has been declared
medically fit by the Medical Board.
The appointment of Ms. Jofa Anton Gonsalves is
made subject to the verification of character and
antecedents. In the event of any adverse remarks
noticed by the Government on verification of
character and antecedents, her services shall be
terminated.
She shall draw her salary against the newly
created post vide Order No. 1/5/2017-DHE/1024
dated 07-06-2018.
By order and in the name of the Governor of
Goa.
Avelina D’sa E Pereira, Under Secretary (Higher
Education).
Porvorim, 14th March, 2023.
————

Order
No. ACADIII/GC/FILLING OF POST/50/2021/
/37892
Read: Memorandum No. ACADIII/GC/FILLING OF
POST/50/2021/30020 dated 13-12-2022.
On the recommendation of the Goa Public Service
Commission as conveyed vide their letter No. COM/

3041

<!-- page 10 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

/I/5/78(1)/2020/(Part File I)/306 dated 21-10-2022,
Government is pleased to appoint Mrs. Sneha Shyam
Naik to the post of Assistant Professor in English
(OBC) in the Government College of Arts, Science
and Commerce, Quepem-Goa under Directorate of
Higher Education on temporary basis in the UGC
Pay Scale Matrix Level 10 with immediate effect,
and as per the terms and conditions contained in
the Memorandum cited above. She shall be on
probation for a period of two years.
Mrs. Sneha Shyam Naik has been declared
medically fit by the Medical Board. The character
and antecedents have been verified by the Addl.
Collector & ADM, South Goa, Margao and nothing
adverse has been reported against her.
She shall draw her salary against the newly
created post vide Order No. 1/5/2017-DHE/1024
dated 07-06-2018.
By order and in the name of the Governor of
Goa.
Avelina D’sa E Pereira, Under Secretary (Higher
Education).
Porvorim, 14th March, 2023.
————

Order
No. ACADIII/GC/FILLING OF POST/50/2021/
/37893
Read: Memorandum No. ACADIII/GC/FILLING OF
POST/50/2021/30019 dated 13-12-2022.
On the recommendation of the Goa Public Service
Commission as conveyed vide their letter No. COM/
/I/5/78(5)/2018/305 dated 21-10-2022, Government
is pleased to appoint Mr. Adrel Gomes to the post
of Assistant Professor in Geography in Sant
Sohirobanath Ambiye Government College of Arts
& Commerce, Pernem-Goa under Directorate of
Higher Education on temporary basis in the UGC
Pay Scale Matrix Level 10 with immediate effect,
and as per the terms and conditions contained in
the Memorandum cited above. He shall be on
probation for a period of two years.
Mr. Adrel Gomes has been declared medically fit
by the Medical Board.
The appointment of Mr. Adrel Gomes is made
subject to the verification of character and
antecedents. In the event of any adverse remarks
noticed by the Government on verification of
character and antecedents, his services shall be
terminated.

3042

He shall draw his salary against the newly
created post vide Order No. 1/5/2017-DHE/1024
dated 07-06-2018.
By order and in the name of the Governor of
Goa.
Avelina D’sa E Pereira, Under Secretary (Higher
Education).
Porvorim, 14th March, 2023.
————

Order
No. ACADIII/GC/FILLING OF POST/50/2021/
/37894
Read: Memorandum No. ACADIII/GC/FILLING OF
POST/50/2021/30019 dated 13-12-2022.
On the recommendation of the Goa Public
Service Commission as conveyed vide their letter
No. COM/I/5/78(5)/2018/305 dated 21-10-2022,
Government is pleased to appoint Mr. Vishal
Raghoba Gaonkar to the post of Assistant Professor
in Geography (ST) in the Government College of
Arts, Science and Commerce, Sanquelim-Goa under
Directorate of Higher Education on temporary basis
in the UGC Pay Scale Matrix Level 10 with
immediate effect, and as per the terms and
conditions contained in the Memorandum cited
above. He shall be on probation for a period of two
years.
Mr. Vishal Raghoba Gaonkar has been declared
medically fit by the Medical Board. The character
and antecedents have been verified by the Addl.
Collector & ADM, South Goa, Margao and nothing
adverse has been reported against him.
He shall draw his salary against the newly
created post vide Order No. 1/5/2017-DHE/1024
dated 07-06-2018.
By order and in the name of the Governor of
Goa.
Avelina D’sa E Pereira, Under Secretary (Higher
Education).
Porvorim, 14th March, 2023.
————

Order
No. ACADIII/GC/FILLING OF POST/50/2021/
/37970
Read: Memorandum No. ACADIII/GC/FILLING OF
POST/50/2021/30019 dated 13-12-2022.
On the recommendation of the Goa Public
Service Commission as conveyed vide their letter
No. COM/I/5/78(5)/2018/305 dated 21-10-2022,

<!-- page 11 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

Government is pleased to appoint Ms. Shradha
Gurudas Pagui to the post of Assistant Professor in
Geography (OBC) in the Government College of Arts,
Science and Commerce, Quepem-Goa under
Directorate of Higher Education on temporary basis
in the UGC Pay Scale Matrix Level 10 with
immediate effect, and as per the terms and
conditions contained in the Memorandum cited
above. She shall be on probation for a period of two
years.
Ms. Shradha Gurudas Pagui has been declared
medically fit by the Medical Board. The character
and antecedents have been verified by the Addl.
Collector & ADM, South Goa, Margao and nothing
adverse has been reported against her.

He shall draw his salary against the newly
created post vide Order No. 1/5/2017-DHE/1024 dated
07-06-2018.
By order and in the name of the Governor
of Goa.
Avelina D’sa E Pereira, Under Secretary (Higher
Education).
Porvorim, 16th March, 2023.
———uuu———

Department of Environment & Climate Change
–––
Order
No. 8-15-2019/ENVT/NGT/Part/1687

By order and in the name of the Governor
of Goa.

In pursuance of order dated 21-10-2022 passed
by the Hon’ble National Green Tribunal (NGT), in
M.A. No. 74/2022, Original Application No. 976/2019,
Gurinder Singh & Ors. V/s Union of India & Ors.,
Government of Goa hereby constitute the three
members High Powered Committee for utilization
of Environment compensation funds.

Avelina D’sa E Pereira, Under Secretary (Higher
Education).

The committee shall comprise of the following
members:

She shall draw her salary against the newly
created post vide Order No. 1/5/2017 DHE/1024
dated 07-06-2018.

Porvorim, 16th March, 2023.
————

Order
No. ACADIII/GC/FILLING OF POST/50/2021/
/37975
Read: Memorandum No. ACADIII/GC/FILLING OF
POST/50/2021/30021 dated 13-12-2022.
On the recommendation of the Goa Public Service
Commission as conveyed vide their letter No. COM/
/I/5/78(22)/2020/304 dated 21-10-2022, Government
is pleased to appoint Mr. Myron Pereira to the post
of Assistant Professor in Commerce (ST) in the Sant
Sohirobanath Ambiye Government College of Arts
& Commerce, Pernem-Goa under Directorate of
Higher Education on temporary basis in the UGC
Pay Scale Matrix Level 10 with immediate effect,
and as per the terms and conditions contained in
the Memorandum cited above. He shall be on
probation for a period of two years.
Mr. Myron Pereira has been declared medically
fit by the Medical Board. The character and
antecedents have been verified by the Addl.
Collector & ADM, South Goa, Margao and nothing
adverse has been reported against him.

1. Chief Secretary,
Government of Goa

— Chairman.

2. Secretary (Environment
& Climate Change),
Government of Goa

— Member.

3. Secretary (Revenue),
Government of Goa

— Member.

The Hon’ble NGT has directed to create a
separate account and may be opened under the
office of the Chief Secretary.
The Goa Coastal Zone Management Authority
(GCZMA) will open a separate account in terms of
the direction of Hon’ble National Green Tribunal
and all transaction will be with approval of the
above committee.
The Goa Coastal Zone Management Authority,
Goa State Pollution Control Board and Goa State
Environment Impact Assessment Authority may be
directed to deposit the Environment Compensation/
Polluter Pay Principle fines collected by them in
the account created by the Goa Coastal Zone
Management Authority.
Department of Environment & Climate Change
in consultation with the concerned Boards and
Authorities under its Administrative Control may
prepare a State Specific Action Plan for utilization

3043

<!-- page 12 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

Department of Finance

of the Environmental Compensation funds with
approval of the High Powered Committee.

Revenue & Control Division

By order and in the name of the Governor
of Goa.
Dr. Geeta S. Nagvenkar, Director (Environment &
Climate Change).
Panaji, 15th March, 2023.
————

Order
No. GSWA/2019-20/RTI/018/1700
In pursuance of Clause 5 of the Right to
Information Act, 2005 (hereinafter referred to as
“the said Act”), the following officers are hereby
appointed as Public Information Officer and
Assistant Public Information Officer in the Goa State
Wetland Authority (GSWA), to deal with the
applications received from the public under the said
Act.

––––

Order
No. 6/1/2022-Fin(R&C)/Part File/3282
On the recommendation of the Goa Public
Service Commission as conveyed vide its letter No.
COM/II/12/43(1)2013/501 dated 02nd March, 2023,
the Government of Goa is pleased to declare the
following Officers to have satisfactorily completed
their probation period and confirm them in the
post of State Tax Officer in the Office of the
Commissioner of Commercial Taxes from the date
of their completion of probation period:1.
2.
3.
4.
5.
6.
7.

Shri Gaurish V. Khedekar.
Smt. Sophia Lawrence Vaz.
Shri Naresh Kushta Gaude.
Smt. Ankita Anil Kamat.
Shri Rohan Arvind Loliyekar.
Shri Sirajuddin Gulamrasul Jamadar.
Smt. Shweta Rohan Harmalkar alias
Sweta Shankar Gurav.
8. Kum. Ashvita Ankush Goltekar.

Public Information
Officer

Ms. Urvee T. Kanekar,
Legal Assistant, GSWA.

Assistant Public
Information Officer

Ms. Shruti Salgaonkar ,
Project Assistant, GSWA.

By order and in the name of the Governor
of Goa.

The Public Information Officer shall be
responsible for preparation and publication of
information manual and its updating from time to
time as per the said Act.

Pranab G. Bhat, Under Secretary, Finance (R&C).

The Assistant Public Information Officer shall
ensure that the applications received under the said
Act are scrutinized and submitted to the Public
Information Officer for decision so as to furnish the
relevant information to the applicant as per the
said Act, on issues pertaining to the Goa State
Wetland Authority (GSWA).
The Member Secretary, Goa State Wetland
Authority (GSWA), will be the First Appellate
Authority under this Act against the decision of the
Public Information Officer/Assistant Public
Information Officer as far as the Goa State Wetland
Authority (GSWA), is concerned.
This order is issued in accordance to the
correspondence/decision of the Goa State Wetland
Authority (GSWA).
By order and in the name of the Governor of
Goa.
Dr. Geeta S. Nagvenkar, Director (Envt. & CC).
Panaji, 16th March, 2023.

3044

Porvorim, 17th March, 2023.
———u———

Debt Management Division
–––
Office Memorandum
No. 13/13/2023-FIN(DMU)/130
The Office Memorandum No. DPE/18(1)/2012-Fin
dated 08-05-2017 transcribed below regarding
Guidelines on Investment of Surplus Funds by the
CPSEs issued by Government of India, Ministry of
Heavy Industries & Public Enterprises, Department
of Public Enterprises, New Delhi has been adopted
by the State Government.
Pranab G. Bhat, Under Secretary, Finance (Bud-II).
Porvorim, 16th March, 2023.
———

F. No. DPE/18(1)/2012-Fin
Government of India
Ministry of Heavy Industries & Public Enterprises
Department of Public Enterprises
Public Enterprises Bhavan,
Block No. 14, CGO Complex,
Lodhi Road, New Delhi-110003
Dated: 08-05-2017

<!-- page 13 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

OFFICE MEMORANDUM
Sub.: Guideline on Investment of Surplus Funds by
the CPSEs-regarding
..........
The undersigned is directed to enclose herewith
a copy of the “Guidelines on Investment of Surplus
Funds by the CPSEs” for taking necessary action to
ensure compliance of these guidelines. This is in
supersession of all Guidelines on Investment of
Surplus Funds by the CPSEs issued by Department
of Public Enterprises from time to time.
2. This issues with the approval of Minister (HI & PE).
Sd/(Kalyani Mishra)
Director
Tel.: 24362061
Encl.: As above.
———

F. No. DPE/18(1)/2012-Fin
Government of India
Ministry of Heavy Industries & Public Enterprises
Department of Public Enterprises
Sub.: Guidelines on Investment of Surplus Funds
by the CPSEs-regarding
Guidelines on investment of surplus funds
essentially deal with the management of surplus
funds with CPSEs to prevent the funds from lying
idle, and instead, generate returns.
2. The details of Guidelines on Investment of
Surplus Funds by the CPSEs issued by Department
of Public Enterprises from time to time are annexed.
In supersession of all these guidelines and other
guidelines, if any, issued by any other Ministries/
/Departments on investment of surplus funds by
CPSEs earlier, the Guidelines on Investment of
Surplus Funds by the CPSEs are issued as follows:
Applicability:
3. These Guidelines shall be applicable to all
CPSEs. The definition of CPSE for the purpose of
these guidelines shall be same as defined vide O. M.
No. PP/14 (0005)/2016 dated 20-06-2016 regarding
Capital Restructuring of Central Public Sector
Enterprises (CPSEs) as reproduced below:
“All corporate bodies where Government of India
and/or Government controlled one or more body
corporate have controlling interest.
i) Body corporate shall include body
incorporated under the provisions of the
Companies Act, 1956 or the Companies Act,
2013, or under any other Act as may be
applicable except Limited Liability
Partnership.

ii) Controlling interest means control over the
composition of the Board of Directors; or
exercise or control over more than one-half of
the total share capital or able to exercise more
than 50 per cent voting rights in the meeting
of the members, Board of Directors or any other
similar executive structure, e.g., Governing
Body, Executive Committee, etc.
iii) A body corporate in which Government of
India and/or CPSEs including their
subsidiaries controls the composition of the
Board of Directors; or exercises or controls
more than one-half of the total share capital
shall be deemed to be a body controlled by
Government of India”.
3.1 However, these guidelines will not apply to
banks and insurance companies.
Scope:
4. These guidelines shall apply to surplus funds
available with CPSEs after meeting the business
requirements including operating expenses,
payment of taxes, working capital, debt servicing,
capital expenditure, replacement/revamping/
/renewal of business assets, etc. Cash surplus of
temporary nature including those available for a
few days or weeks would also come within the
purview of these guidelines. However, these
guidelines shall not apply to investments by CPSEs
in their core business activities or investment in
equity under disinvestment programme of the
Government and investments in subsidiaries/joint
ventures by way of equity capital.
5. CPSEs shall also ensure compliance with the
guidelines on “Capital Restructuring of CPSEs”
issued by Department of Public Enterprises on
20-06-2016 before investing the surplus funds
available with them in eligible instrument.
6. These guidelines shall apply to CPSEs subject
to the following:
i. If any statutory guidelines have been issued
by the sector regulatory authority like RBI,
SEBI, IRDA, etc., on investment of surplus
funds, these guidelines will be applicable to
CPSEs only to the extent these are not contrary
to the guidelines laid down by such regulatory
authority.
ii. If surplus funds have been earmarked for any
purpose under any scheme framed under
applicable laws/regulations, or Court
directions, these guidelines will be applicable
to the extent these are not contrary to the
provisions of the scheme made under such
laws/regulations or Court directives.

3045

<!-- page 14 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
iii. These guidelines will not apply to investment
of surplus funds kept outside India by CPSEs
or their overseas subsidiaries for normal
business purposes in compliance with
applicable Foreign Exchange Management
Act, 1999 (FEMA) regulations and the local
applicable laws.
iv. The CPSEs shall also comply with Section 186
of the Companies Act, 2013.
Principles of investment of surplus funds:
7. CPSEs shall invest their surplus funds as per
the following broad principles:
i. Investment shall be made in instruments
ensuring the safety of funds.

23RD MARCH, 2023
vii. Funds shall normally not be invested by a
CPSE at a particular rate of interest for a
particular period of time while the CPSE is
resorting to borrowing at an equal or higher
rate of interest for its requirements for the
same period. However, CPSEs may take
decisions on all matters relating to short term
cash management, as they would be the best
judge of asset-liability mismatch in the short
run.
viii. CPSEs shall put in place a centralized system
of liquidity management for optimum utilization
of liquidity for business operation.
Eligible Investments:

ii. There shall be no speculation on the yield
obtaining from the investment. It shall be
known at the time of making the investment
except for investment in debt mutual funds.
However, in case of investment in marketable
debt-instruments, (viz., mutual fund debt
instruments, Government securities and T bills)
there is a risk that final yield may differ from
yield estimated at the time of investment due
to movement in prices of the security, if such
debt-instruments are sold due to unforeseen
circumstances before final maturity date (i.e.,
they are not held to maturity). Such investment
will not be treated as having speculative yield.
Similarly, in case of premature encashment of
bank term deposits due to unforeseen
exigencies, the difference between fixed yield
at the time of investment and actual yield at
premature payment will not be speculative
yield.

8. CPSEs shall invest their surplus funds in one or
more of the following instruments, subject to
principles outlined above:

iii. Since investment in debt schemes of mutual
funds are subject to market risks, thI track-record of the scheme shall be taken into
account for taking investment decisions.

iii. Instruments issued by scheduled commercial
banks incorporated in India/all India term
lending and refinancing institutions including
their subsidiaries e. g. certificates of deposits,
deposits schemes, commercial paper or similar
instruments, which have been rated by any
two Credit Rating Agencies, registered with
SEBI and have been accorded the highest
safety credit rating.

iv. There shall be a proper commercial
appreciation and due diligence before any
investment decision of surplus funds is taken.
v. The forecast of surplus availability may be
worked out normally for a period of one year
at any point of time so as to deploy available
funds on longer term basis at better yields.
This forecasting exercise shall ideally be done
every month or quarter.
vi. In order to utilize the surplus funds effectively,
CPSE may also prepare best estimate of the
periods for which surplus funds would be
available to facilitate investment decisions for
such periods including on a day-to-day basis.

3046

i. Treasury bills and Government of India
securities.
ii. Term deposits with any scheduled commercial
bank incorporated in India and with a net
worth (i.e. the paid up capital plus free reserves
of the bank) of atleast Rs. 500 Crore, fulfilling
the capital adequacy norms as prescribed by
the Reserve Bank of India (RBI) from time to
time. Capital adequacy and net worth of Banks
may be assessed on the basis of their Annual
Accounts (audited) or as available on the
website of RBI, whichever is the latest. While
investing, CPSEs shall ensure that minimum
60% of funds placed in bank term deposits are
placed with public sector banks. Further, CPSEs
may obtain competitive quotations from Banks.

iv. Loans/Deposits with CPSEs (including those
under inter-corporate borrowing programme)
subject to availability of highest credit rating
from any Credit Rating Agency registered with
SEE! for borrowing for the corresponding period.
v. Investment in Collateralized Borrowing and
Lending Obligations (CBLOs) where Clearing
Corporation of India Ltd. (CCIL) acts as
counterparty.

<!-- page 15 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
vi. In mutual funds subject to the following
conditions:
a) Only Maharatna, Navratna and Miniratna
CPSEs are permitted to invest in debt based
schemes of SEBI regulated public sector
mutual funds.
b) Portfolio Management Schemes of any Asset
Management Company/or any other entity
will not be mutual funds for this purpose.
c) Investment in Mutual Funds shall not exceed
30% of the available surplus funds of the
concerned CPSE.
d) Public Sector Mutual Fund means the Mutual
Funds registered with and regulated by SEBI
where the Government of India, its financial
institutions and public sector banks holds/
/hold individually or collectively more than
50% of equity/shares in the Asset
Management Company of that Mutual Fund.
e) The mutual fund debt scheme should have
been accorded highest mutual fund rating by
any two of the Credit Rating Agencies
registered with SEBI.
f) The mutual fund debt scheme should have
corpus amounting to at least Rs. 1000 Crore
for the scheme at the time of investment. The
corpus may be reckoned from the latest
published information at the time of
investment.
g) The Board of Directors of the CPSEs should
decide the guidelines, procedures and
management control systems for investment
in such mutual funds and keep the
Administrative Ministry informed through the
Financial Adviser.
vii Any other debt instrument (including
commercial paper) of public sector entities,
subject to highest credit rating from any two
rating agencies approved by SEBI.

23RD MARCH, 2023
short-term surplus funds up to one year maturity to
a designated group of Director(s), which should
invariably include CMD/MD and Director (Finance)
of the CPSE concerned upto such financial limits as
the Board may decide.
11. In case of Maharatna/Navratana CPSEs,
decisions regarding investment of short-term
surplus funds up to one year maturity may be
delegated to Director (Finance) up to prescribed
limits of investment as may be decided by the Board
provided that (i) the proposals are examined and
put up by an internal investment committee and (ii)
guidelines, systems and proper procedures are laid
down with the approval of Board. All such
investment should be reported to CMD at least on
a fornightly basis.
12. Where such delegation is made, the
delegation order should spell out criteria for
selection of party, party exposure limits, etc., which
should be strictly observed. Further, there should
be a proper system of reporting to the Board at least
on a quarterly basis.
13. An annual report on surplus funds invested
in different instruments and the yield thereon may
be placed before the Board.
14. The projected surplus availability for the
ensuring year shall be informed to the
Administrative Ministry at the beginning of
financial year.
General:
15. CPSEs shall ensure that all investment
decisions are in accordance with the regulations as
per the Company Law and Government of India
instructions and any other relevant legislation and
rules as applicable. Any investment already made,
which is not in conformity with these guidelines
should not be renewed after maturity/or at the
earliest opportunity as may be decided by the Board
of CPSE.

Competent Authority for Investment and
Reporting:

16. The Board of every CPSE shall arrange to
formulate suitable procedure and management
control systems for investment of surplus funds to
be followed by the company. Boards of CPSEs may
also lay down guidelines, procedures and systems
for estimation of surplus funds and investment of
these funds keeping in view the above guidelines
and giving due consideration to safety of funds, risk
on yield, requirement of liquidity and applicable
laws.

10. Decisions on investment of surplus funds
shall be taken by the Board of CPSE. However, Board
may delegate powers regarding investment of

17. The operating instructions are to be
formulated keeping in view their suitability for
making financial investments.

Maturity Period of Investment:
9. The period of maturity, including cases of
residual maturity, of any instrument of investment
shall not exceed one year from the date of
investment. However, in the case of term deposits
with banks and GOI securities, it may be up to
three years from the date of investment.

3047

<!-- page 16 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

18. No agent/broker etc. in any form whatsoever
shall be involved on either side. Howerer, for
secondary market investment in Government
securities and treasury bills, invitation of quote/s
from a minimum of three primary dealers registered
with RBI may be obtained.
This issues in consultation with the Department
of Investment and Public Asset Management (DIPAM),
Ministry of Finance and has the approval of Ministry
of Finance communicated to DPE vide O. M. No.
7/13/2016-Policy dated 3rd April, 2017.
ANNEXURE
Details of Guidelines on Investment of Surplus
Funds by the Central Public Sector Enterprises
(CPSEs) issued by Department of Public Enterprises
from time to time.
Sr. No.

O. M. Nos.

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.

DPE/14(19)190-Fin.
DPE/4/3/92-Fin.
DPE/4(6)/94-Fin.
DPE/4(6)/94-Fin.
DPE/4(6)/94-Fin.
DPE/4(6)/94-Fin.
DPE/4(6)/94-Fin.
DPE/4(6)/94-Fin. G-XVII
DPE/4(6)/1994-Fin.
DPE/11/47/2006-Fin.
DPE/11/47/2006-Fin.
DPE/11/47/2006-Fin.
DPE/11/47/2006-Fin.
DPE/11/47/2006-Fin.
DPE/18(1)/08-Fin.
DPE/11(15)/08-Fin.
DPE/18(15)/08-Fin.
DPE/14(24)/2011-Fin.
DPE/18(1)/08-Fin.

Dated

3rd January, 1992.
27th June, 1994.
14th December, 1994.
1st November, 1995.
11th March, 1996.
2nd July, 1996.
14th February, 1997.
25th November, 1999.
29th September, 2005.
31st August, 2007.
4th December, 2007.
11th April, 2008.
15th April, 2008.
14th August, 2008.
15th December, 2008.
12th January, 2009.
24th February, 2009.
23rd April, 2012.
13th August, 2012.

———uuu———

Department of General Administration
––––

Notification
No. 37/3/2019-GAD-III/1009
In pursuance to sub-section (1) of Section 40A of
the Goa Panchayat Raj Act, 1994 (Goa Act No. 14 of
1994), the Government of Goa hereby declares
Saturday, the 25th March, 2023 (Chaitra 4, Saka
1944) as a “Paid Holiday” being the “Polling Day”
for the Bye Elections to Ward No. V of Village
Panchayat Velguem, Ward No. VI of Village
Panchayat Ona-Maulinguem Kudchirem, Ward
No. VI of Village Panchayat Orlim, Ward No. II of
Village Panchayat Calem, Ward No. IV of Village

3048

Panchayat Balli-Adnem, Ward No. VII of Village
Panchayat Barcem-Quedem and Ward No. I of
Village Panchayat Rachol.
The aforesaid holiday shall be a “paid holiday”,
in addition to the holidays indicated in the
Notification No. 37/3/2022-GAD-III/3661 dated
19-10-2022, published in the Official Gazette, Series
II No. 30 dated 27-10-2022, to the workers of the
following establishments, provided they are the
voters for the aforesaid Bye-election:(i) industrial workers of the State of Goa;
(ii) daily wage workers of the Government
Departments and State Government
Industrial Departments;
(iii) commercial and industrial workers of
private establishments in the State of Goa;
(iv) all private establishments;
(v) daily wage/casual workers employed in any
business, trade, industrial undertakings or
any other establishments.
By order and in the name of the Governor
of Goa.
Shaila G. Bhosle, Under Secretary (GA-I).
Porvorim, 15th March, 2023.
———uuu———

Department of Goa Gazetteer
–––

Order
No. 1/4/2022-23/GAZ-321
Government is pleased to constitute an Expert
Committee of following members for preparation of
the Pernem Taluka Gazetteer:
1) Dr. Rohit Phalgaonkar,
— Chaiperson.
Assistant Professor, History,
Sant Sohirobanath Ambiye
Government College,
Virnoda, Pernem
2) Dr. Ishani Roy, Associate
— Member.
Professor, Geography, Sant
Sohirobanath Ambiye
Government College,
Virnoda, Pernem
3) Ms. Priyanka Sitaram Parab,
— Member.
Assistant Professor, Konkani,
Sant Sohirobanath Ambiye
Government College, Virnoda,
Pernem
4) Shri Mayur Arolkar,
— Member.
Assistant Professor of History,
DCT’s Dhempe College of
Arts & Science, Miramar, Goa

<!-- page 17 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

5) Shri Balaji Shenvy, Executive
— Member
Editor, Goa Gazetteer Department Secretary.
Scope of the Committee:
The scope of the Committee shall be as follows:
1) To assist the Department of Goa Gazetteer in
compilation of the Taluka Gazetteer and publish
the same within one year from the date of
publication of the Notification order of the
constitution of the Expert Committee in the
Official Gazette.
2) To prepare an outline for the Taluka Gazetteer.
3) To advise and suggest for speedy completion of
the task and assist the Department in
authenticating the data/material for
publication.
4) Any other subject related to the speedy
completion of the Taluka Gazetteer.
5) The committee may co-opt any other member
for completion of the Taluka Gazetteer.
6) Any other subject as decided by the
Government from time to time.
Tenure of the Committee:- The tenure of the
Committee shall be one year from the date of
publication in the Official Gazette.
The non-official members may be entitled for the
Travelling Allowance as admissible by the
Government from time to time.
This order is issued with the approval of the
Government vide U.O. No. 2240/F dated 11-03-2023.
By order and in the name of the Governor of
Goa.
Balaji S. Shenvy, Executive Editor (Goa Gazetteer).
Panaji, 15th March, 2023.
————

Order
No. 1/4/2022-23/GAZ-327

4) Ms. Domitel D’Souza,
— Member.
Associate Professor of History,
Shree Mallikarjun & Shri Chetan
Manju Desai College, Delem,
Canacona-Goa
5) Shri Balaji Shenvy, Executive
— Member
Editor, Goa Gazetteer Department
Secretary.
Scope of the Committee:The scope of the Committee shall be as follows:
1) To assist the Department of Goa Gazetteer in
compilation of the Taluka Gazetteer and publish
the same within one year from the date of
publication of the Notification order of the
constitution of the Expert Committee in the
Official Gazette.
2) To prepare an outline for the Taluka Gazetteer.
3) To advise and suggest for speedy completion of
the task and assist the Department in
authenticating the data/material for publication.
4) Any other subject related to the speedy
completion of the Taluka Gazetteer.
5) The committee may co-opt any other member
for completion of the Taluka Gazetteer.
6) Any other subject as decided by the Government
from time to time.
Tenure of the Committee: The tenure of the
Committee shall be one year from the date of
publication in the Official Gazette.
The non-official members may be entitled for the
Travelling Allowance as admissible by the
Government from time to time.
This order is issued with the approval of the
Government vide U.O. No. 2240/F dated 11-03-2023.
By order and in the name of the Governor of
Goa.
Balaji S. Shenvy, Executive Editor (Goa Gazetteer).

Government is pleased to constitute an Expert
Committee of following members for preparation of
the Canacona Taluka Gazetteer:

Panaji, 15th March, 2023.

1) Dr. Pandurang Phaldessai,
— Chairperson.
Director, Thomas Stephens
Konknni Kendra, Porvorim-Goa
2) Shri Kamlakar Mhalshi,
— Member.
Former Principal, Balaram
Higher Secondary School,
Canacnona-Goa
3) Dr. Manoj Kamat, Professor
— Member.
& Principal, Shree Mallikarjun
& Shri Chetan Manju Desai
College, Delem, Canacona-Goa

Department of Handicrafts, Textile & Coir

———uuu———

–––
Notification
No. 2/19/2022-(HT&C)/26
Read: Notification No. 2/19/2022 (HT&C)/25 dated
19-04-2022, published in the Official Gazette,
Series II No. 4 dated 28-04-2022.
In pursuance of Article 65, read with Article 63,
of the Articles of Association of the Goa Handicrafts,
Rural and Small Scale Industries Development

3049

<!-- page 18 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

Corporation Limited and in supersession of the
Government Notification read above and any other
Notifications and Orders issued in this regard, the
Government of Goa hereby reconstitutes the Board
of Directors of the Goa Handicrafts, Rural and Small
Scale Industries Development Corporation Limited,
as follows, namely:1. Shri Pravin Arlekar, MLA,
Pernem

— Chairman.

2. Secretary (Handicrafts, Textile — Director.
& Coir)
3. Finance Secretary or his
— Director.
nominee not below the rank
of Under Secretary from
Finance Department

6. Smt. Achal Verekar, r/o
Khadpabandh, Ponda, Goa

— Director.

7. Shri Pramod Kamat, r/o
Merces, St. Cruz, Goa

— Director.

8. Shri Madhu Parab, r/o
Palye, Pedne, Goa

— Director.

9. Shri Subodh Mahale, r/o
Ugve, Pedne, Goa

— Director.

10. Shri Jayesh C. Naik, r/o
Karmali, Cumbharjua, Goa

— Director.

11. Shri Mahadev V. Gawandi,
r/o Devsu, Korgao, Goa

— Director.

12. Shri Satish Shankar
Korgaonkar, r/o Canca,
Siolim, Goa

— Director.

— Director.

This notification shall come into force with
immediate effect.

5. Managing Director, Goa
— Director.
Handicrafts, Rural and
Small Scale Industries
Development Corporation Limited

By order and in the name of the Governor of
Goa.

4. Director of Handicrafts, Textile
& Coir

A. S. Mahatme, Under Secretary (HT&C).
Porvorim, 14th March, 2023.

———uuu———

Department of Home
(F&CD)
G20 Cell
––––

Notification
No. G20 Cell/PoA/714/2022-23/75
Pattern of Assistance for the release of Grant-in-Aid to Home Department (F&CD), G20 Cell to meet
the expenditure towards G20 Summit events/meetings to be held in the State of Goa for the Financial
Year 2022-23 & 2023-24.
Background:
1. The Government is pleased to frame the Pattern of Assistance as Grant-in-Aid for the organization
of the G20 Summit events/meetings in the State.
2. Objective of the Scheme: India is holding Presidency of G20 from 1st December, 2022 to 30th
November, 2023. As per the G20 calendar, the State of Goa has been allotted following 08 events/meetings
by the G20 Secretariat, Ministry of External Affairs, New Delhi.
Sl.
No.

Track

Level

Nodal
Ministry/Agency

Meeting

1

2

3

4

1.

Sherpa

WG

MoHFW

2.

Finance

WG

MoF

3.

Sherpa

WG

MEA

4.

Sherpa

WG

Min. of Tourism 4th Tourism Working
Group Meeting

3050

Date

5

6.

2nd Health Working
Group Meeting
3rd International
Financial Architecture
Working Group Meeting
3rd Development
Working Group
Meeting

17-19 April, 2023.
5-7 June, 2023.

9-11 May, 2023.

19-20 June, 2023.

<!-- page 19 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

1

2

3

4

5

6

5.

Sherpa

Ministerial

Min. of Tourism Tourism Working
Group MM

21-22 June, 2023.

6.

EG

EG

CAG

SAI 20 Summit

12-14 June.

7.

Sherpa

WG

Min. of Power

4th Energy Working
Group Meeting

19-20 July, 2023.

8.

Sherpa

Ministerial

Min. of Power

Energy Working
Group MM

22 July, 2023.

* The dates of actual events/meetings may vary as per the instructions from G20 Secretariat, Ministry of External
Affairs, New Delhi.

3. Each of these events/meetings would be attended by around 250 delegates from various G20
Countries, International Organizations and other invites of Government of India. In addition, the recce
visits are also being organized by G20 Secretariat, Ministry of External Affairs, New Delhi as well as other
related Ministries of the Government of India.
4. All the events/meetings shall be organized as per requirements and directions of the G20 Secretariat,
Ministry of External Affairs, which has stated that hosting of G20 meeting would be an opportunity to
showcase the State’s level of development, infrastructure, culture and heritage to the world.
5. Therefore, in pursuance of sub-rule (1) of Rule 230 of the General Finance Rules, 2017, the Government
of Goa hereby prescribes the pattern of financial assistance to the tune of Rs. 2500.00 lakh as follows:
a) Purpose for which the grant-in-aid shall be sanctioned:
Sr. No.

Revenue Head

1

2

1.

Advertising, hoardings, banner etc.

2.

Advertising, Branding, Social Media (Print, electronic, local and national channels).

3.

Cultural presentations at airport during arrivals or at the meeting venue/lunch/dinner venue as
per ICCR approval.

4.

City Sprucing, civil works, roads, pavement, building, painting.

5.

Green spaces, horticulture, garden.

6.

Waste management, segregation of waste, waste disposal.

7.

Conservancy.

8.

Vehicles, transport arrivals, departures and site seeing excursions/tours/experiences (including
fuel).

9.

Health, Ambulance, Medical Facilities etc.

10.

Refreshment/Dinner/Lunch for all G20 meetings/events in the State for more than 400 people
(apprx.) at each meetings/events.

11.

Souvenirs/Kits/Bags/Gifts.

12.

Professional services, translation services including Regional language translation/translator etc.

13.

Honorarium, wages, salaries, hiring of staff and other services on contract, dress allowance, travel
allowance, stationery and other related office expenditure including setting up of office.

14.

Uninterrupted power supply arrangements to/at the venues.

3051

<!-- page 20 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
1

23RD MARCH, 2023
2

15.

Lighting up of prominent buildings and monuments.

16.

Facilitate high speed internet, essential for virtual attendance. Hiring/purchase of IT equipments
(Hardware & Software).

17.

Security during move and excursion (to also include police escorts etc.).

18.

Fire fighting arrangements.

19.

Creation/facilitation of stalls (for sale of specific products) at the venue/or any other places as per
instructions of G20 Secretariat, Ministry of External Affairs, New Delhi.

20.

Assistance in terms of transportation and accommodation facilities, if required beyond the planned
numbers.

21.

Co-ordination with the concerned institutions/organizations and other assistance (including English
speaking guides etc.) for conduct of excursion visit.

22.

Protocol/Hospitality, liaison officers/delegates accommodation, hotels and other amenities.

23.

Any other expenditure related to G20 Summit Event/Meetings.

6. The Drawing and Disbursing Officer shall maintain the register of the grant-in-aid sanctioned. Nodal
Officer for Overall Co-ordination G-20, Additional Secretary G20 and OSD (Accounts) shall be the cheque
signing authority. The Nodal Officer for Overall Co-ordination G20 Summit shall evolve its own procedure
and the manner in which the grants-in-aid are to be utilized for the purposes specified in this pattern of
assistance.
7. No grants-in-aid or part thereof shall be diverted or utilized for the purpose other than specified in
this pattern of assistance. Any portion which is not ultimately required shall be funded back to the
Treasury.
8. The grant-in-aid or part thereof shall be subject to audit by the Controller and Auditor General of
India and Directorate of Accounts of the Government.
9. The G20 Cell shall adhere to General Financial Rules (GFR), 2017, The Goa Delegation of Financial
Powers Rules (GDFPR), 2008 and such other Rules as followed by the Departments in the State Government.
10. The Home Department shall be the Budget Controlling Authority for the purpose of making budgetary
provision, release of grants, utilization certificate etc.
11. The funds once sanctioned in the grant-in-aid, shall be transferred to Bank Account opened in the
Nationalized Bank. The quantum of funds as grant-in-aid will be Rs. 2,500 lakhs. The funds under grant-in-aid shall be disbursed in two installment of Rs. 1500 lakh and Rs. 1000 lakh each. The funds sanctioned
shall be utilized for 02 financial years w.e.f. 2022-23, 2023-24.
12. The amount shall be drawn under Demand No. 23, Budget Head of Accounts 2070–Other
Administrative Services 00, 800–Other Expenditure, 01–G-20 Summit, 31–Grant-in-aid.
13. No grant shall be allowed to be paid to any other institutions/voluntary organizations out of this
grants sanctioned by the Government which is not related to G20 Summit.
14. The Grantee shall exercise reasonable economy, observe all financial propriety and the financial
rules as issued by the Government from time to time while incurring the expenditure.
15. This is issued with the concurrence of the Finance (Exp.) Department vide their U.O. No.
1510/F dated 16-02-2023.
By order and in the name of the Governor of Goa.
Anthony J. D’Souza, Additional Secretary/Director (G20 Cell Admin.).
Porvorim, 28th February, 2023.

3052

<!-- page 21 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

Department of Labour

(2) If not, what relief the workman is entitled to?

––

2. On receipt of the reference, a case was
registered under No. LC-II/IT/15/2016 and registered
A/D notice was issued to the parties. In pursuance
to the said notice, the parties put in their
appearance. The Workman/Party-I (for short
‘Workman’), filed his Statement of Claim on
30-01-2017 at Exhibit-4. The facts of the case in
brief as pleaded by the Workman are that the
Employer/Party-II (for short ‘Employer’) is a
Multinational Pharmaceutical Company engaged
in the production of tablets at its factory at Verna
Industrial Estate, Salcette, Goa. He stated that the
Employer was initially established at Verna in the
year, 2001 as Wyeth Lederle Ltd. which was
subsequently changed as Pfizer Ltd. in the year,
2009. He stated that he was employed with the
Employer as “Operator-Production” since
26-05-2002. He stated that he has not received a
single memo or a single charge-sheet except the
charge-sheet which is the subject matter of the
present reference. He stated that during his service
with the Employer, he received awards from the
Employer for his performance. He stated that he
also received several “employee of the month”
awards, long service awards, best nominee of the
month awards, certificates for improving
productivity and development, etc. He stated that
after formation of a trade Union in 2014, all the
workers of the Employer Company joined the said
union. He stated that he was elected as an office
bearer of the said union and as such he was a
Protected Workman as per the provisions of the I.D.
Act, 1947. He stated that initially all workmen
including himself were employed as Operator–
Productions. He stated that in the year, 2006, the
designations of all workmen were changed to that
of management associates Grade MA-01 and in year
2011, the grade of workers were changed to MA-02
although the duties performed by them remained
the same. He stated that all the workmen of the
Employer including himself were issued
appointment letters and all of them were confirmed
in the service of the Employer.

Notification
No. 28/02/2023-LAB/Part-II/151
The following Award passed by the Labour
Court-II, at Panaji-Goa on 30-01-2023 in Case No.
Ref. LC-II/IT/15/16 is hereby published as required
under Section 17 of the Industrial Disputes Act,
1947 (Central Act 14 of 1947).
By order and in the name of the Governor of
Goa.
Amalia O. F. Pinto, Under Secretary (Labour).
Porvorim, 24th February, 2023.
––––

IN THE LABOUR COURT-II
GOVERNMENT OF GOA
AT PANAJI
(Before Shri Suresh N. Narulkar, Hon’ble
Presiding Officer)
.

Case No. Ref. LC-II/IT/15/16

Shri Ramdas Mayenkar,
H. No. 689, Thorlim Bhat,
Dongrim-Goa.
…… Workman/Party I
V/s
The Managing Director,
M/s. Pfizer Ltd.,
Plot No. L-137, Phase III-A,
Verna, Industrial Estate,
Verna, Salcete-Goa.
…… Employer/Party II
Workman/Party-I represented by Ld. Rep. Shri
Subhash Naik.
Employer/Party-II represented by Ld. Adv. Shri G. K.
Sardessai.
Panaji, dated: 30-01-2023.
AWARD
1. In exercise of the powers conferred by Clause
(c) of sub-section (1) of Section 10 of the Industrial
Disputes Act, 1947 (Central Act 14 of 1947), the
Government of Goa, by Order dated 23-6-2016,
bearing No. 28/25/2016-LAB/438 referred the
following dispute for adjudication to the Industrial
Tribunal of Goa. The Government of Goa, vide its
addendum dated 18-10-2016, transferred the present
matter to the Labour Court-II, for its adjudication.
“(1) Whether the action of the management of
M/s. Pfizer Limited, Verna, Salcette, Goa, in dismissing
Shri Ramdas Mayenkar, Operator, with effect from
23-12-2015, is legal and justified?

3. He stated that in June, 2014, workers formed a
Trade Union for the first time, when all the workers of
the Employer factory became members of Gomantak
Mazdoor Sangh Trade Union. He stated that the
Employer was informed about the formation of a Trade
Union. He stated that names of seven Union office
bearers of the Union including himself were also
communicated to the Employer. He stated that the
Employer did not appreciate the decision of the
workers to form a Trade Union and started harassing
the workers by withdrawing existing benefits and

3053

<!-- page 22 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
existing facilities. He stated that with effect from
20-04-2015, the Employer did not allot any work to
workers inside the factory and kept them idle as the
Employer was not happy with the workers forming a
Trade Union. He stated that with effect from
24-04-2015, all workmen were kept outside the
factory gates and were not allowed to resume work
inside the factory. He stated that this continued for
several months and later the Employer stated that
they would not allow the workmen to report for work
unless they gave an undertaking, the contents of
which were not disclosed to them. He stated that
later on, the Employer allowed all workmen to report
for work without undertaking and all workmen
reported for work with effect from 17-08-2015. He
stated that the Employer has till date not paid wages
of the workers from 20-4-2015 to 16-08-2015. He stated
that however, eleven workmen, who were issued
suspension orders pending enquiry, were not allowed
to report for work. He stated that meanwhile, after
formation of a Trade union, the Employer suspended
the services of all office bearers of the Union namely,
himself, Sagar Dhume, Krishnakant Gawas, Navin
Gaude, Susen Jalmi, Suraj Kurtikar, and Suraj
Salgaonkar.
4. He stated that all the aforesaid workers were
issued charge-sheets on trumped up and fabricated
charges. He stated that he himself and others replied
to the charge-sheets denying the allegations levelled
against them. He stated that the suspension of seven
union office bearers including himself was from
21-04-2015. He stated that four more workmen were
also suspended from service with effect from
23-04-2015 pending enquiry namely, Ankush
Gaonkar, Mangaldas Gaude, Umakant Chari, and
Samesh Naik. He stated that all eleven workmen
were suspended and were issued charge-sheets
based on false and fabricated charges. He stated
that as the workers were not happy with Gomantak
Mazdoor Sangh Union because of the developments
which took place which workers least expected. He
stated that all the workers, after holding a General
Body Meeting decided to resign from the said Union
and became the members of Kamgarancho Ekvott
Trade Union of which Subhash Naik George is the
President with effect from 20-05-2015 after resigning
from Gomantak Mazdoor Sangh. He stated that these
developments were informed to the Employer in
writing. He stated that the said Union Kamagarancho
Ekvott raised several Industrial Disputes with the
Employer such as Charter of Demands on behalf of
the workers, illegal and unjustified refusal of work
with effect from 24-04-2015, unfair labour practice,
non-payment of bonus, illegal termination of services
of workmen and illegal imposition of punishments to

3054

23RD MARCH, 2023
workers etc. He stated that as the Employer did not
accept the demands, the union raised disputes
before Dy. Labour Commissioner who is also
Conciliation Officer of Government of Goa, where all
industrial disputes are pending conciliation and
some disputes have been referred to this Hon’ble
Tribunal for adjudication.
5. He stated that although all seven union office
bearers including himself were issued separate
charge-sheets, the Employer decided to hold
common enquiry. He stated that Shri Prashant
Agarwal, Advocate who was appointed as an Enquiry
Officer to conduct the enquiries in respect of charge
-sheets issued to seven union office bearers. He
stated that Shri Prasanna Chawadikar, Advocate was
appointed as Management Representative. He
stated that initially Puti Gaonkar was the Defense
Representative on behalf of charge-sheeted workmen
and later on, Subhash Naik George was appointed as
Defense Representative by himself and other charge-sheeted workers. He stated that on 02-06-2015 a
date was fixed by the Enquiry Officer Mr. Agarwal to
hold the enquiry. However, on that day Ld. Enquiry
Officer did not attend the enquiry at the hearing fixed
at Panaji-Goa. He stated that the Management
Representative, Shri Prasanna Chawadikar, who was
present for the enquiry, informed that Ld. Enquiry
Officer had gone to his native place to bring his wife
and he could not get tickets to return to Goa due to
vacation rush and that he is still travelling in the
train. He stated that the Management Representative
informed him and all other charge-sheeted workmen
as well as Defense Representative that Ld. Enquiry
Officer, Mr. Agarwal had resigned from the post of
Enquiry Officer and that he could not come for the
enquiry due to his personal reasons. He stated that
Management Representative informed that the next
date of enquiry would be communicated after the
management appointed a new Enquiry Officer.
6. He stated that after 5th June, 2015, no
communication either oral or writing was received
by him or his Defense Representative about the date
of enquiry or appointment of a new Enquiry Officer.
He stated that after few months, the Employer
dismissed the service of the four union office bearers
with effect from 16-06-2015 claiming that they held
enquiry against them and claiming that Ld. Enquiry
Officer held them guilty of the charges namely, Sagar
Dhume, Krishnakant Gawas, Navin Gaude, and Suraj
Salgaonkar. Aggrieved by the said blatantly illegal
and unjustified terminations, the Workman and three
other workmen raised an industrial disputes with
the Employer and later on with the Conciliation
Officer/Dy. Labour Commissioner which ended in
failure.

<!-- page 23 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
7. He contended that during the pendency of such
disputes as per provisions of Section 33 of the I. D.
Act, 1947, the Employer cannot terminate the services
of the workmen without prior permission or without
approval of action taken by them. He submitted that
the Employer, as an afterthought, terminated the
services of remaining three office bearers namely,
Ramdas Mayenkar, Susen Jalmi and Suraj Kurtikar
with effect from 23-12-2015. He submitted that with
these termination, Employer have terminated all
Seven office bearers who were elected after formation
of Trade Union which clearly proves that this is a
clear case of victimization for trade union activities.
He submitted that since he himself, Susen Jalmi and
Suraj Kurtikar were protected workmen as per
provisions of I.D. Act, prior permission before
termination ought to have been obtained from this
Hon’ble Tribunal and/or Dy. Labour Commissioner,
failing which the termination is bad-in-law. He
submitted that the charge-sheet issued to him and
six other office bearers of the union and four other
union members were fabricated and cooked up
besides being false. He submitted that the same were
issued to him and others to victimize them for their
trade union activities as they had formed a union for
the first time in the company. He submitted that
Shailesh Redkar, whom the Employer claims to have
been appointed as Enquiry Officer, was never
appointed as Enquiry Officer and no intimation to
that effect has been sent to him. He submitted that
no intimation of dates of enquiry by the said Enquiry
Officer if any, was sent to him. He submitted that the
records of enquiry proceedings alleged to have been
conducted by Shailesh Redkar have not been
supplied to him till date. He submitted that the
Employer, before terminating his service has not
issued him a show cause notice enclosing copy of
the findings of the Enquiry Officer, if any, and records
of enquiry proceedings if any, seeking his views
before dismissal which is mandatory. He submitted
that no enquiry was held in respect of charges
levelled against him in the charge-sheet issued to
him. He submitted that the copy of the findings of
the enquiry if any, were not supplied to him before
termination of his services. He submitted that since
the date of dismissal, he is unemployed and is
dependent on his family and friends on sustainance.
He submitted that his termination is illegal and
unjustified as he has been dismissed from service in
total violation of principles of natural justice. He
submitted that no opportunity whatsoever was given
to him to defend himself in the enquiry. He submitted
that the management witnesses were not allowed to
cross-examine by him. He submitted that the charges
levelled against him have not been proved in a fair

23RD MARCH, 2023
and impartial manner and in accordance with the
principles of natural justice. He submitted that his
dismissal from services is malafide, vindictive, and
by way of victimization for trade union activities,
besides the same being discriminatory. The
Workman therefore prayed that he be reinstated in
service with full back wages and continuity of service
with costs.
8. The Employer controverted the claim of
Workman by filing its written statement on
03-05-2017 at Exb. 5. The Employer, as an by way of
its preliminary objections, submitted that the
reference is not maintainable and it ought to be
rejected as there is no “Industrial Dispute” as defined
under the I.D. Act, 1947, that the Workman has
accepted all the legal dues arising out of termination
in full and final settlement and hence, the Workman
is estopped from raising the present dispute, that
there is non application of mind by the Appropriate
Government while referring the present dispute and
that the present reference is therefore null and void.
9. The Employer stated that it is a Private Limited
Company incorporated under the provisions of the
Companies Act, 1956, having its registered office at
the Capital, 1802, 1901 Bandra Kurla Complex, Bandra
(East), Mumbai and the factory located at Verna
Industrial Estate, Verna, Salcette-Goa. The Employer
stated that it is engaged in the manufacturing of
pharmaceuticals at its factory located at Verna
Industrial Estate, Verna-Goa.
10. The Employer stated that the Workman was
issued a charge-sheet dated 07-05-2015 alleging as
under:
“It has been observed that from the month of
December, 2014, the workmen have deliberately and
willfully reduced production as a result of which the
Management suffered heavy losses. The fall in
production which commenced from the month of
December, 2014 gradually reached to a stage where
during the preceding week the production was
reduced to around 25% of the normal. The
management has consistently requested the
workmen to stop the unfair practice of lowering the
production and to restore normalcy. However, the
workmen continue with the unfair Labour practice
of lowering the productive process.
Subsequent by Notice dated 7th February, 2015,
letter dated 14th April, 2015 and through various
communications, Management invited the attention
of the workmen to the fall in production and
requested the workmen to restore normalcy.
However, instead of restoring normalcy, to the utter
shock and surprise of the Management, the workmen

3055

<!-- page 24 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
in a concerted manner stopped production from the
commencement of Second shift of 20th April, 2015
and started squatting within the factory premises.
As a consequence thereto, the entire productive
process came to a grinding halt. The Management
has suffered huge losses till date and continues to
do so. As they were aware, engaged in the
manufacturing of drugs which include life-saving
drugs like Wysolone, Folvite, Pacitane, Overal-L etc.
All these products are listed in the National List
of Essential Medicines (NLEM), issued by Ministry of
Health, Government of India. Wysolone is a lifesaving steroidal drug with anti-inflammatory
properties and controls the painful symptoms of a
temporary autoimmune condition called Polymyalgia
Rheumatic (PMR), Folvite, essentially taken by
women during the first trimester of pregnancy for
development of the foetus and also used for all kinds
of anaemic conditions, Pacitane, drug used by
Patients suffering from early symptoms of Parkinson’s
Disease and Overal-L. You are fully aware that the
discontinuation due to non-availability of these
drugs can have an adverse effect on the patients and
the society at large.
They had received various communications from
their dealers, hospitals and doctors informing them
of the serious consequences arising as a result of
drugs not being available in the market and the
suffering of the patients, especially those who had
already been prescribed such drugs and consuming
the same. The consequence of sudden
discontinuation of supply to the patients had an
expected adverse consequences on the health of the
patients.
You are an office bearer of Gomantak Mazdoor
Sangh. The Management had been consistently
communicating with you and other workmen who
have been participating in the go slow/stoppage of
work to desist from the unfair labor practice of
reducing willfully and deliberately the production.
The fall in production was a consequence of the
instigation and incitement of the workmen to
commence and continue with the reduction of
production. It has also been observed that you have
been actively inducing the workmen to continue with
the go slow.
The participation in the willful go slow and the
instigation and incitement of the workmen to initiate
the go slow and continue as such amounts to a
serious misconduct under the Model Standing
Orders.
The Management had therefore decided to
conduct an enquiry into the misconduct alleged

3056

23RD MARCH, 2023
against you. You were suspended pending enquiry
by suspension order dated 21-04-2015.
Your above acts on your part constitute the
following Acts of Misconducts under the Model
Standing Orders:
a. Willful insubordination or disobedience,
whether alone or in combination with others,
to any lawful and reasonable order of a superior.
b. Willful damage to or loss of employer’s good or
property.
c. Habitual absence without leave or absence
without leave for more than 10 days.
d. Habitual breach of any law applicable to the
establishment.
e. Riotous or disorderly behavior during working
hours at the establishment or any act
subversive of discipline.
f. Neglect of work.
g. Striking work or inciting others to strike work
in contravention of the provision of any law, or
rule having the force of law”.
11. The Employer stated that the workmen was
suspended pending enquiry. The Employer stated
that Mr. Prashant Agarwal was appointed as Enquiry
Officer and Mr. Prasanna Chawadikar was appointed
as the Management Representative. The Employer
stated that Mr. Puti Gaonkar was appointed as
Defense Representative by the Workmen. The
Employer stated that Mr. Agarwal conducted the
enquiry on 15-05-2015 and 22-05-2015. The Employer
stated that thereafter the enquiry was fixed on
02-06-2015 at 3.30 p.m. The Employer stated that on
02-06-2015, Ld. Enquiry Officer was in personal
difficulty and hence, the enquiry could not held on
the said date. The Employer stated that in the mean
while Mr. Prashant Agarwal by his letter dated
04-06-2015 informed them due to prior commitments,
he is unable to continue with the conduct of the
enquiry and therefore has decided to withdraw from
the enquiry. The Employer stated that in view of
inability of Mr. Prashant Agarwal to continue with
the enquiry, Mr. Shailesh Redkar was appointed as
an Enquiry Officer vide appointment letter dated
05-06-2015. The Employer stated that on 05-06-2015,
by notice dated 05-06-2015 the Workmen were
informed that in view of the change of the Enquiry
Officer, and the appointment of new Enquiry Officer,
the enquiry was fixed on 06-06-2015 at 4.30 p.m. at
the same venue. The Employer stated that the letter
of appointment of new Enquiry Officer was also
served on the charge-sheeted workmen. The
Employer stated that the charge-sheeted workmen

<!-- page 25 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
however, refused to accept the notice of enquiry as
well as the letter of appointment and the amended
charge-sheet. The Employer stated that on
06-06-2015, none of the charge-sheeted workmen
were present. The Employer stated that the chargesheeted workmen stayed away from the enquiry
deliberately with the sole object of delaying the
enquiry proceedings in spite of being informed about
the enquiry fixed on 06-06-2015 at 4.30 p.m. The
Employer stated that Ld. Enquiry Officer on the basis
of documents on record and considering the
contentions of the Management Representative and
after being satisfied that it is a fit case to proceed exparte and held enquiry ex-parte against the chargesheeted workmen. The Employer stated that the
enquiry was conducted by the Ld. Enquiry Officer in
an impartial manner and every opportunity was
given to the Workman to defend the charge-sheet
levelled against the charge-sheeted workmen. The
Employer stated that Ld. Enquiry Officer submitted
his findings dated 13-06-2015 and after appreciating
the evidence on record held the Workman guilty of
charges levelled against him. The Employer stated
that they considered the proceedings of the enquiry,
the findings of the Enquiry Officer and concurred
with the same. The Employer stated that they
considered the past record and did not find any
extenuating circumstances for mitigation of
punishment of dismissal from its service. The
Employer stated that considering the gravity of
proved misconduct, the Workman was dismissed from
its service vide letter dated 23-12-2015.
12. The Employer stated that the Workman was
paid full and final settlement of all his dues vide
cheque bearing No. 106324 drawn on Deutche Bank,
Mumbai for an amount of Rs. 1,36,180/- alongwith
the full and final computation statement on
30-01-2016 that includes basic pay, P.L. encashment,
house rent allowance, conveyance allowance,
medical allowance and LTA along with gratuity. The
Employer stated that the said amount has been
received by the Workman and has been credited to
his account on 23-03-2016. The Employer stated that
the Workman has also collected all his provident fund
dues and for the purpose of employees Provident Fund
and Miscellaneous Provisions Act, 1952, is an
excluded employees. The Employer stated that, since
the Workman is prosecuting this matter after having
received benefits/full and final settlements of all legal
dues arising out of termination, it would be equitable
to direct the Workman to return the benefits so
received from them with 8.5% interest on the said
money for prosecuting the reference on merits on
the principle of “Who seeks equity must do equity”.
The Employer stated that in the event this Hon’ble

23RD MARCH, 2023
Court sets aside the enquiry on any of the grounds,
they may be permitted to lead evidence before this
Hon’ble Court to prove the charges levelled against
the Workman. The Employer denies the overall case
as pleaded by the Workman and prayed that the
reference may be summarily rejected.
13. Thereafter, the Workman filed his Re-joinder
on 12-05-2017 at Exb. 06. The Workman, by way of its
Re-joinder, confirms and reiterates all his
submissions, averments and statements made in his
Claim Statement to be true and correct and denies
all the statements, averments and submissions made
by the Employer in its Written Statement, which are
contrary to its Statement and averments made in his
Claim Statement.
14. Based on the pleadings filed by the respective
parties, this Court framed the following issues at
Exb. 7.
1. Whether a free, fair and proper enquiry was
conducted against the Workman/Party I in
respect of charge-sheet dated 07-05-2015 in
accordance with the principles of natural
justice?
2. Whether the charges of misconduct levelled
against the Workman vide charge-sheet dated
07-05-2015 have been proved to the satisfaction
of this court by acceptable evidence?
3. Whether the Workman/Party I proves that the
action of the Employer in dismissing him from
service w.e.f. 23-12-2015 is in violation of Section
33 of the I.D. Act, 1947?
4. Whether the Workman/Party-I proves that the
action of the Employer/Party II in dismissing
him from service w.e.f. 23-12-2015, is illegal and
unjustified?
5. Whether the Employer/Party II proves that the
reference is not maintainable and bad-in-law
in view of the reasons stated in para (i) to (iv) of
its written statement?
6. Whether the Workman/Party-I is entitled to any
relief?
7. What order? What award?
15. Thereafter, both the parties led their evidence
on the preliminary issues No. 1 and 2. Thereafter,
the Employer filed an application for amendment of
its written statement which was allowed by order
dated 17-3-2020 after hearing both parties. The
Workman also filed its synopsis in his written
arguments. On 12-3-2022, Ld. Rep. Shri Subhash Naik
appearing for the Workman as well as Ld. Adv. Ms. N.
Gaonkar representing the Employer submitted that
the matter is likely to be settled amicably between

3057

<!-- page 26 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

the parties. Accordingly, on 20-01-2023, Ld. Rep. Shri
Subhash Naik along with the Workman as well as Ld.
Adv. Mrs. M. Rao h/f Adv. G. K. Sardessai representing
the Employer along with its Director remained
present and filed an application for Award in terms
of settlement along with Memorandum of settlement
u/s 2(P) r/w Sec-18 of the I.D. Act, 1947 between the
Employer and the Workman which is on record at
Exb. 47-colly and submitted that the matter be
disposed of in terms of the settlement arrived at
between the parties hereinabove. The terms of
settlement as agreed between the parties
hereinabove are reproduced hereunder:
a. The Management agrees to pay the workman
Mr. Ramdas B. Mayenkar a sum of Rs. 21,00,000/(Rupees twenty one lakhs only), vide cheque
bearing No. 500004 dated 12-01-2023 drawn
on JPMorgan Chase Bank, N. A., Mumbai
400098 Branch, in full and final settlement of
all his claims.
b. It is agreed between the parties that the
Management shall not deduct TDS from the
Settlement amount and Mr. Ramdas B.
Mayenkar undertakes to pay the Tax on the
said amount.
c. Accordingly, Mr. Ramdas B. Mayenkar agrees
not to pursue the references No. LC-II/IT/15/
/2016 before the Labour Court II or any dispute
raised individually or through any union
before any Tribunal, Court, Authority or Forum
and treat the same as settled.
d. It is agreed between the parties that this
settlement filed shall be before the Labour
Court II under reference No. LC-II/IT/15/2016
for an Award in terms of the present
settlement.
I have gone through the terms of settlement
signed by the parties hereinabove and is of the
opinion that the said terms of settlement are
beneficial to both the parties. The said terms of
settlement also useful for the harmonious relation
between the parties. Hence, I approved the same.
In view of above and with regards to the facts and
circumstances of the present case, I proceed to pass
the following order.
ORDER
1. It is hereby held that the reference as to whether
the action of the management of M/s. Pfizer
Ltd., Verna Industrial Estate, Verna, Salcette,

3058

Goa, in dismissing Shri Ramdas Mayenkar,
Operator, w.e.f. 23-12-2015 is legal and justified,
does not survive.
2. Inform the Government accordingly.
Sd/(Suresh N. Narulkar)
Presiding Officer,
Labour Court-II.
————

Notification
No. 28/02/2023-LAB/Part-III/153
The following Award passed by the Labour
Court-II, at Panaji-Goa on 30-01-2023 in Case No.
Ref. LC-II/IT/34/16 is hereby published as required
under Section 17 of the Industrial Disputes Act,
1947 (Central Act 14 of 1947).
By order and in the name of the Governor of
Goa.
Amalia O. F. Pinto, Under Secretary (Labour).
Porvorim, 24th February, 2023.
––––

IN THE LABOUR COURT-II
GOVERNMENT OF GOA
AT PANAJI
(Before Shri Suresh N. Narulkar, Hon’ble
Presiding Officer)
.

Case No. Ref. LC-II/IT/34/16

Shri Navin Gaude,
H. No. 39, Pani Wada,
Borim, Ponda-Goa (403401)
…… Workman/Party I
V/s
The Managing Director,
M/s. Pfizer Ltd.,
Plot No. L-137, Phase III-A,
Verna Industrial Estate,
Verna, Salcete-Goa (403722) …… Employer/Party II
Workman/Party-I represented by Ld. Rep. Shri
Subhash Naik.
Employer/Party-II represented by Ld. Adv. Shri G. K.
Sardessai.
Panaji, dated: 30-01-2023.
AWARD
1. In exercise of the powers conferred by Clause
(c) of sub-section (1) of Section 10 of the Industrial
Disputes Act, 1947 (Central Act 14 of 1947), the
Government of Goa, by Order dated
22-07-2016, bearing No. 28/16/2016-LAB/546

<!-- page 27 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
referred the following dispute for adjudication to
the Labour Court-II, Panaji-Goa.
“(1) Whether the action of the management of
M/s. Pfizer Limited, Verna, Salcette, Goa, in
dismissing Shri Navin Gaude, Management
Associate, with effect from 16-06-2015, is legal
and justified?
(2)

If not, what relief the workman is entitled to?

2. On receipt of the reference, a case was
registered under No. LC-II/IT/34/2016 and registered
A/D notice was issued to the parties. In pursuance
to the said notice, the parties put in their appearance.
The Workman/Party-I (for short ‘Workman’), filed his
Statement of Claim on 19-08-2016 at Exhibit-5. The
facts of the case in brief as pleaded by the Workman
are that the Employer/Party-II (for short ‘Employer’)
is a Multinational Pharmaceutical Company engaged
in the production of tablets at its factory at Verna
Industrial Estate, Salcette, Goa. He stated that the
Employer was initially established at Verna in the
year, 2001 as Wyeth Lederle Ltd. which was
subsequently changed as Pfizer Ltd. in the year, 2009.
He stated that he was employed with the Employer
as “Operator-Warehouse” since 29-11-2001. He stated
that he has not received a single memo or a single
charge-sheet except the charge-sheet which is the
subject matter of the present reference. He stated
that during his service of the Employer, he received
awards from the Employer for his performance. He
stated that he also received several “employee of the
month” awards, long service awards, best nominee
of the month awards, certificates for improving
productivity and development, etc. He stated that
after formation of a trade Union in 2014, all the
workers of the Employer Company joined the said
union. He stated that he was elected as an office
bearer of the said union and as such he was a
Protected Workman as per the provisions of the I.D.
Act, 1947. He stated that initially all workmen
including himself were employed as Operator –
Warehouse. He stated that in the year, 2006, the
designations of all workmen were changed to that of
management associates Grade MA-01 and in year
2011, the grade of workers were changed to MA-02
although the duties performed by them remained the
same. He stated that all the workmen of the Employer
including himself were issued appointment letters
and all of them were confirmed in the service of the
Employer.
3. He stated that in June, 2014, workers formed a
Trade Union for the first time, when all the workers of
the Employer factory became members of Gomantak
Mazdoor Sangh Trade Union. He stated that the
Employer was informed about the formation of the

23RD MARCH, 2023
Trade Union. He stated that names of seven Union
office bearers of the Union including himself were
also communicated to the Employer. He stated that
the Employer did not appreciate the decision of the
workers to form a Trade Union and started harassing
the workers by withdrawing existing benefits and
existing facilities. He stated that with effect from
20-04-2015, the Employer did not allot any work to
workers inside the factory and kept them idle as the
Employer was not happy with the workers forming a
Trade Union. He stated that with effect from
24-04-2015, all workmen were kept outside the
factory gates and were not allowed to resume work
inside the factory. He stated that this continued for
several months and later the Employer stated that
they would not allow the workmen to report for work
unless they gave an undertaking, the contents of
which were not disclosed to them. He stated that
later on, the Employer allowed all workmen to report
for work without undertaking and all workmen
reported for work with effect from 17-08-2015. He
stated that the Employer has till date not paid wages
of the workers from 20-4-2015 to 16-08-2015. He stated
that however, eleven workmen, who were issued
suspension orders pending enquiry, were not allowed
to report for work. He stated that meanwhile, after
formation of the Trade union, the Employer
suspended the services of all office bearers of the
Union namely, Ramdas Mayenkar, Sagar Dhume,
Krishnakant Gawas, himself, Susen Jalmi, Suraj
Kurtikar, and Suraj Salgaonkar.
4. He stated that all the aforesaid workers were
issued charge-sheets on trumped up and fabricated
charges. He stated that he himself and others replied
to the charge-sheets denying the allegations leveled
against them. He stated that the suspension of seven
union office bearers including himself was from
21-04-2015. He stated that four more workmen were
also suspended from service with effect from
23-04-2015 pending enquiry namely, Ankush
Gaonkar, Mangaldas Gaude, Umakant Chari, and
Samesh Naik. He stated that all eleven workmen
were suspended and were issued charge-sheets
based on false and fabricated charges.
5. He stated that as the workers were not happy
with Gomantak Mazdoor Sangh Union because of the
developments which took place which the workers
least expected. He stated that all the workers after
holding a General Body Meeting decided to resign
from the said Union and became the members of
Kamgarancho Ekvott Trade Union of which Shri
Subhash Naik George is the President with effect
from 20-05-2015 after resigning from Gomantak
Mazdoor Sangh. He stated that these developments
were informed to the Employer in writing. He stated

3059

<!-- page 28 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
that the said Union Kamagarancho Ekvott raised
several Industrial Disputes with the Employer such
as Charter of Demands on behalf of the workers,
illegal and unjustified refusal of work with effect from
24-04-2015, unfair labour practice, non-payment of
bonus, illegal termination of services of workmen and
illegal imposition of punishments to workers etc. He
stated that as the Employer did not accept the
demands, the union raised disputes before Dy. Labour
Commissioner who is also Conciliation Officer of
Government of Goa, where all industrial disputes are
pending conciliation and some disputes have been
referred to this Hon’ble Tribunal for adjudication.
6. He stated that although all seven union office
bearers including himself were issued separate
charge-sheets, the Employer decided to hold
common enquiry. He stated that Shri Prashant
Agarwal, Advocate, was appointed as an Enquiry
Officer to conduct the enquiries in respect of chargesheets issued to seven union office bearers. He stated
that Shri Prasanna Chawadikar, Advocate, was
appointed as Management Representative. He
stated that initially, Puti Gaonkar was the Defense
Representative on behalf of charge-sheeted workmen
and later on, Shri Subhash Naik George was
appointed as Defense Representative by himself and
other charge-sheeted workers. He stated that on
02-06-2015 a date was fixed by the Enquiry Officer
Mr. Agarwal to hold the enquiry. However, on that
day Ld. Enquiry Officer did not attend the enquiry at
the hearing fixed at Panaji-Goa. He stated that the
Management Representative, Shri Prasanna
Chawadikar, who was present for the enquiry,
informed that Ld. Enquiry Officer had gone to his
native place to bring his wife and he could not get
tickets to return to Goa due to vacation rush and
that he was still travelling in the train. He stated
that the Management Representative informed him
and all other charge-sheeted workmen as well as
Defense Representative that Ld. Enquiry Officer, Mr.
Agarwal had resigned from the post of Enquiry
Officer and that he would not come for the enquiry
due to his personal reasons. He stated that
Management Representative informed that the next
date of enquiry would be communicated after the
management appointed a new Enquiry Officer.
7. He stated that after 5th June, 2015, no
communication either oral or writing was received
by him or his Defense Representative about the date
of enquiry or appointment of a new Enquiry Officer.
He stated that after few months, the Employer
dismissed the service of the four union office bearers
with effect from 16-06-2015 claiming that they held
the enquiry against them and claiming that Ld.

3060

23RD MARCH, 2023
Enquiry Officer held them guilty of the charges
namely, Sagar Dhume, Krishnakant Gawas, himself,
and Suraj Salgaonkar. Aggrieved by the said
blatantly illegal and unjustified terminations, the
Workman and three other workmen raised an
industrial disputes with the Employer and later on
with the Conciliation Officer/Dy. Labour
Commissioner which ended in failure.
8. He contended that during the pendency of such
disputes as per provisions of Section 33 of the I. D.
Act, 1947, the Employer cannot terminate the services
of the workmen without prior permission or without
approval of action taken by them. He submitted that
the Employer, as an afterthought, terminated the
services of remaining three office bearers namely,
Ramdas Mayenkar, Susen Jalmi and Suraj Kurtikar
with effect from 23-12-2015. He submitted that with
these termination, Employer have terminated all
Seven office bearers who were elected after formation
of Trade Union which clearly proves that this is a
clear case of victimization for trade union activities.
He submitted that since he himself, Susen Jalmi and
Suraj Kurtikar were protected workmen as per
provisions of I.D. Act, prior permission before
termination ought to have been obtained from this
Hon’ble Tribunal and/or Dy. Labour Commissioner,
failing which the termination is bad-in-law. He
submitted that the charge-sheet issued to him and
six other office bearers of the union and four other
union activists were fabricated and cooked up
besides being false. He submitted that the same were
issued to him and others to victimize them for their
trade union activities as they had formed a union for
the first time in the company. He submitted that
Shailesh Redkar, whom the Employer claims to have
been appointed as Enquiry Officer, was never
appointed as Enquiry Officer and no intimation to
that effect has been sent to him. He submitted that
no intimation of dates of enquiry by the said Enquiry
Officer if any, was sent to him. He submitted that the
records of enquiry proceedings alleged to have been
conducted by Shailesh Redkar have not been
supplied to him till date. He submitted that the
Employer, before terminating his service has not
issued him a show cause notice enclosing copy of
the findings of the Enquiry Officer, if any, and records
of enquiry proceedings if any, seeking his views
before dismissal which is mandatory. He submitted
that no enquiry was held in respect of charges
levelled against him in the charge-sheet issued to
him. He submitted that the copy of the findings of
the enquiry if any, were not supplied to him before
termination of his services. He submitted that since
the date of dismissal, he is unemployed and is
dependent on his family and friends on sustainance.

<!-- page 29 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

He submitted that his termination is illegal and
unjustified as he has been dismissed from service in
total violation of principles of natural justice. He
submitted that no opportunity of whatsoever was
given to him to defend himself in the enquiry. He
submitted that the management witnesses were not
allowed to cross-examine by him. He submitted that
the charges levelled against him have not been
proved in a fair and impartial manner and in
accordance with the principles of natural justice. He
submitted that his dismissal from services is
malafide, vindictive, and by way of victimization for
trade union activities, besides the same being
discriminatory. The Workman therefore prayed that
he be reinstated in service with full back wages and
continuity of service with costs.

Subsequent there to by Notice dated 7th February,
2015, letter dated 14th April, 2015 and various
communications, Management invited the attention
of the workmen to the fall in production and
requested the workmen to restore normalcy.
However, instead of restoring normalcy, to the utter
shock and surprise of the Management, the workmen
in a concerted manner stopped production from the
commencement of Second shift of 20th April, 2015
and started squatting within the factory premises.
As a consequence thereto the entire productive
process came to a grinding halt. The Management
has suffered huge losses till date and continues to
do so. The Employer/Party II is engaged in the
manufacturing of drugs which include life-saving
drugs like Wysolone, Folvite, Pacitane, Overal-L etc.

9. The Employer controverted the claim of the
Workman by filing its written statement on
02-12-2016 at Exb. 7. The Employer, as an by way of
its preliminary objections, submitted that the
reference is not maintainable and it ought to be
rejected as there is no “Industrial Dispute” as defined
under the I.D. Act, 1947, that the Workman has
accepted all the legal dues arising out of termination
in full and final settlement and hence, the Workman
is estopped from raising the present dispute, that
there is non application of mind by the Appropriate
Government while referring the present dispute and
that the present reference is therefore null and void.

All these products are listed in the National List
of Essential Medicines (NLEM), issued by Ministry
of Health, Government of India. Wysolone is a lifesaving steroidal drug with anti-inflammatory
properties and controls the painful symptoms of a
temporary autoimmune condition called Polymyalgia
Rheumatic (PMR), Folvite, essentially taken by
women during the first trimester of pregnancy for
development of the foetus and also used for all kinds
of anaemic conditions, Pacitane, drug used by
Patients suffering from early symptoms of Parkinson’s
Disease and Overal-L. You are fully aware that the
discontinuation due to non-availability of these
drugs can have an adverse effect on the patients and
the society at large.

10. The Employer stated that it is a Private Limited
Company incorporated under the provisions of the
Companies Act, 1956, having its registered office at
the Capital, 1802, 1901 Bandra Kurla Complex, Bandra
(East), Mumbai and the factory located at Verna
Industrial Estate, Verna, Salcette-Goa. The Employer
stated that it is engaged in the manufacturing of
pharmaceuticals at its factory located at Verna
Industrial Estate, Verna-Goa.
11. The Employer stated that the Workman was
issued a charge-sheet dated 07-05-2015 alleging as
under:
“It has been observed that from the month of
December, 2014, the workmen have deliberately and
willfully reduced production as a result of which the
Management suffered heavy losses. The fall in
production which commenced from the month of
December, 2014 gradually reached to a stage where
during the preceding week the production was
reduced to around 25% of the normal.
The management has consistently requested the
workmen to stop the unfair practice of lowering the
production and to restore normalcy. However, the
workmen continue with the unfair labor practice of
lowering the productive process.

We have received various communications from
our dealers, hospitals and doctors informing us of
the serious consequences arising as a result of drugs
not being available in the market and the suffering
of the patients, especially those who had already
been prescribed such drugs and consuming the same.
The consequence of sudden discontinuation of
supply to the patients has as expected adverse
consequences on the health of the patients.
You are an office bearer of Gomantak Mazdoor
Sangh. The Management had been consistently
communicating with the workmen who have been
participating in the go slow/stoppage of work to
desist from the unfair labour practice of reducing
willfully and deliberately the production. The fall in
production was a consequence of the instigation and
incitement of the workmen to commence and
continue with the reduction of production. It has
also been observed that the Party I have been
actively inducing the workmen to continue with the
go slow.
The participation in the willful go slow and the
instigation and incitement of the workmen to initiate

3061

<!-- page 30 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
the go slow and stoppage of work continued and as
such amounts to a serious misconduct under the
Model Standing Orders.
The Management had therefore decided to
conduct an enquiry into the misconduct alleged
against the Party-I. The Party-I was suspended
pending enquiry by suspension order dated
21-04-2015.
The above acts of the Party-I constituted the
following Acts of Misconducts under the Model
Standing Orders:
a. Willful insubordination or disobedience,
whether alone or in combination with others,
to any lawful and reasonable order of a
superior.
b. Willful damage to or loss of employer’s good
or property.
c. Habitual absence without leave or absence
without leave for more than 10 days.
d. Habitual breach of any law applicable to the
establishment.
e. Riotous or disorderly behavior during
working hours at the establishment or any
act subversive of discipline.
f. Neglect of work.
g. Striking work or inciting others to strike work
in contravention of the provision of any law,
or rule having the force of law”.
12. The Employer stated that the workmen was
suspended pending enquiry. The Employer stated
that management conducted an enquiry into the
above said charges. The Employer stated that the
enquiry was conducted by Mr. Shailesh Redkar the
Enquiry Officer who conducted the enquiry is an
impartial manner and every opportunity was given
to the Workman to defend the charges levelled
against him but the Workman failed to participate in
the inquiry. The Employer stated that the enquiry
was therefore, held ex-parte. The Employer stated
that Ld. Inquiry Officer submitted his findings dated
13-6-2015 and after appreciating the evidence on
records held the workman guilty of the charges
levelled against him. The Employer stated that they
considered the proceedings of the inquiry, the
findings of the Inquiry Officer dated 13-6-2015 and
concurred with the same. The Employer stated that
they considered the past records and did not find
any extenuating circumstances for mitigation of
punishment of dismissal from its service. The
Employer stated that considering the gravity of
proved misconducts, the Workman was dismissed
from its service vide letter dated 16-6-2015.

3062

23RD MARCH, 2023
13. The Employer stated that a cheque bearing No.
101980 drawn on Deutsche Bank, Mumbai for an
amount of Rs. 1,57,510/- (Rupees One lakh fifty seven
thousand five hundred and ten only) was sent to the
Workman at his home address by Registered A/D in
full and final settlement of all his dues. The Employer
stated that the statement to that effect was sent
through Registered Post at his correspondence
address on 10-7-2015 and the same has been received
by him. The Employer stated that the Workman was
paid full and final settlement of all his dues which
included basic pay, P.L. encashment, House rent
allowance, Conveyance allowance, Medical
allowance, LTA alongwith gratuity. The Employer
stated that the said amount has been received by
the Workman and has been credited to his account
on 29-9-2015. The Employer stated that the Workman
has also collected all his Provident Fund dues and
for the purpose of Employees Provident Fund and
Miscellaneous Provisions Act, 1952 is an excluded
employee. The Employer stated that since the
Workman is prosecuting this matter after having
received the benefits/full and final settlement of all
legal dues arising out of termination, it would be
equitable to direct the Workman to return the
benefits so received from Employer with 8.5% interest
on the said money for prosecuting the reference on
merits on the principle of “who seeks equity must do
equity. The Employer therefore prayed that the
Workman be directed to deposit the entire amount
in the Court and in the event the Workman fails to
deposit the amount within the period acquitted by
this Hon’ble Court, the defense of the Workman may
be struck off and the reference may be rejected or
the Workman may be stopped for mediating the
present reference.
14. The Employer stated that by notice dated
20-4-2015, the management informed the employee
that their act of stoppage of work from the second
shift amounts to willful stoppage and gross
indiscipline. The Employer stated that the
management advised the employees to report for
work as per the shift schedule. The Employer stated
that however, the employees continued with the
stoppage and continued squatting within the factory
premises. The Employer stated that, by notice dated
21-4-2015, invited the attention of the workmen in
the third shift of 20th April, and first shift of 21th
April, 2015, to the willful stoppage of work and again
advised them to report for work. The Employer stated
that however, they failed to report for duty and
continued to squat within the factory premises. The
Employer stated that the management also decided
to issue charge-sheets to some of the employees for
the misconducts committed by them. The Employer

<!-- page 31 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
stated that in view of the seriousness of the
misconducts alleged against them and in the interest
of conducting a proper inquiry, and to avoid any
interference with such inquiry, the management
decided to suspend them pending inquiry and formal
charge-sheets. The Employer stated that the said
workmen were suspended pending inquiry vide
letter of suspension dated 21-4-2015. The Employer
stated that in the letter of suspension, the
management informed the workmen that the
management has decided to institute an inquiry into
the acts of misconduct alleged against them. The
Employer stated that as the employees continued
with the work stoppage and failed to report for work
and on the contrary were sitting within the factory
premises, the management, by letter dated
23-4-2015, invited the attention of General Secretary
of the union Mr. Puti Gaonkar to the stoppage of work
by the employees from 20-4-2015 and to the notices
displayed on its notice board requesting the striking
employees to report for work. The Employer stated
that in the said letter, management informed the
union that the management is required to take
written undertaking from all the workmen that they
will perform their duties of manufacturing and
restored normalcy in the factory premises. The
Employer stated that the said letter was also
displayed on its notice board. The Employer stated
that alongwith the copy of the said undertaking, the
workmen was also required to sign a notice displayed
on its notice board and copies of the same were
placed at the security gate. The Employer stated
that on and from commencement of general shifts of
24-4-2015, the employees who had reported at the
security gate were advised to sign the undertaking.
The Employer stated that however, they refused to
do so and squatted outside the factory premises in
front of the security cabin from where all the
employees entered inside the factory premises
thereby, causing inconvenience to the employees
who reported for duty. The Employer stated that the
action of the employees of stoppage of work from
28-4-2015 is a concerted manner and continuing such
stoppage amounts to a strike which is illegal and
unjustified.
15. The Employer started that by notice dated
27-4-2015 displayed on 27-4-2015, the management
invited the attention of the workmen that stoppage
of work by way of illegal strike from 28-4-2015 and to
the undertakings which they declined to submit to
the management by giving an assurance of
restoration of normalcy. The Employer stated that
by the said notice, they were informed not to sit at
the security gate and squat outside the security gate
as it caused inconvenience as well as atmosphere of

23RD MARCH, 2023
fear and threat in the mind of managerial and other
employees as well as the customers, welders who
are entering the factory premises. The Employer
stated that the employees were therefore, advised
not to squat near the factory gate and to stay away
from the said place. The Employer stated that as the
workmen continued to commit illegalities, the
management filed a suit for permanent as well as
temporary injunction on 27-4-2015. The Employer
stated that in the meanwhile, the management, vide
its letter to the individual Workman dated 02-06-2015
called upon the workmen to withdraw the agitation
and report for work by giving declaration/
/undertaking as mentioned therein. The Employer
stated that the workmen however, did not responded.
The Employer stated that they again, by its letter
dated 23-6-2015, sent to individual Workman
requested to join the duties. The Employer stated
that the workmen did not respond. The Employer
stated that the management once again vide its
appeal dated 31-07-2015 sent to individual Workman
requested the workmen to report for work in their
shift as per their regular shift. The Employer stated
that on 16-07-2015, four employees who were the
members of “Kamgarancho Ekvott” resumed duties.
The Employer stated that thereafter, one more appeal
was sent to the workmen on 11-08-2015 wherein,
reference was given of the appeal of 23-06-2016,
3-07-2015, and 31-07-2015 to report for work in the
shift and the shift schedule was annexed thereto.
The Employer stated that finally on 17-08-2015 the
remaining workers resumed duties.
16. The Employer submitted that the Ld. Enquiry
Officer followed the principles of natural justice and
granted every conceivable opportunities to the
workmen to be present but however, failed to
participate in the enquiry and therefore Ld. Enquiry
Officer had no option but to conduct the inquiry exparte. The Employer submitted that Ld. Enquiry
Officer on the basis of the evidence on record
submitted reasoned findings holding the Workman
guilty of the charges levelled against him. The
Employer submitted that the management
considered the findings of the Enquiry Officer,
concurred with the same and considering the gravity
of misconduct decided to dismiss him from the
service and hence the present application for
permission for dismissal of the Workman. The
Employer denies the case of the Workman as pleaded
by him and prayed for rejection of the present
reference.
17. Thereafter, the Workman filed his Re-joinder
on 13-12-2016 at Exb.8. The Workman, by way of its
Re-joinder, confirms and reiterates all his
submissions, averments and statements made in his

3063

<!-- page 32 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
Claim Statement to be true and correct and denies
all the statements, averments and submissions made
by the Employer in its Written Statement, which are
contrary to its Statement and averments made in his
Claim Statement.
18. Based on the pleadings filed by the respective
parties, this court framed the following issues on
5-4-2017 at Exb. 12.
1. Whether a free, fair and proper enquiry was
conducted against the Workman/Party I in
respect of charge-sheet dated 07-05-2015 in
accordance with the principles of natural
justice?
2. Whether the charges of misconduct leveled
against the Workman vide charge-sheet dated
07-05-2015 have been proved to the satisfaction
of this court by acceptable evidence?
3. Whether the Workman/Party I proved that his
dismissal from service is in violation of Section
33 of the I.D. Act, 1947?
4. Whether the Workman/Party-I proves that the
action of the Employer/Party II in dismissing him
from service w.e.f. 16-06-2015, is illegal and
unjustified?
5. Whether the Employer/Party II proves that the
reference is not maintainable and bad-in-law
and in view of the reasons stated in para 1(a) to
1(d) of its written statement?
6. Whether the Workman/Party-I is entitled to any
relief?
7. What order? What award?
19. Thereafter, both the parties led their evidence
on the preliminary issues No.1 and 2. Subsequently,
the Employer filed an application for amendment of
its written statement which was allowed by order
dated 17-3-2020 after hearing both parties. The
Workman also filed its synopsis in his written
arguments. On 12-3-2022, Ld. Rep. Shri Subhash Naik
appearing for the Workman as well as Ld. Adv. Ms. N.
Gaonkar representing the Employer submitted that
the matter is likely to be settled amicably between
the parties. Accordingly, on 20-01-2023, Ld. Rep. Shri
Subhash Naik alongwith the Workman as well as
Ld. Adv. Mrs. M. Rao h/f Adv. G. K. Sardessai
representing the Employer alongwith its Director
remained present and filed an application for Award
in terms of settlement along with Memorandum of
settlement u/s 2(P) r/w Sec-18 of the I.D. Act, 1947
between the Employer and the Workman which is
on record at Exb. 47-colly and submitted that the
matter be disposed of in terms of the settlement
arrived at between the parties hereinabove. The
terms of settlement as agreed between the parties
hereinabove are reproduced hereunder:

3064

23RD MARCH, 2023
a. The Management agrees to pay the Workman
Mr. Navin Gaude, a sum of Rs. 21,00,000/(Rupees twenty one lakhs only), vide
cheque bearing No. 500007 dated 12-01-2023
drawn on JPMorgan Chase Bank, N. A.,
Mumbai 400098 Branch, in full and final
settlement of all his claims.
b. It is agreed between the parties that the
Management shall not deduct TDS from the
Settlement amount and Mr. Navin Gaude
undertakes to pay the Tax on the said amount.
c. Accordingly, Mr. Navin Gaude agrees not to
pursue the references No. LC-II/IT/34/2016
before the Labour Court II or any dispute
raised individually or through any union
before any Tribunal, Court, Authority or
Forum and treat the same as settled.
d. It is agreed between the parties that this
settlement shall be filed before the Labour
Court II under reference No. LC-II/IT/34/
/2016 for an Award in terms of the present
settlement.
I have gone through the terms of settlement
signed by the parties hereinabove and is of the
opinion that the said terms of settlement are
beneficial to both the parties. The said terms of
settlement also useful for the harmonious relation
between the parties. Hence, I approved the same.
In view of above and with regards to the facts and
circumstances of the present case, I proceed to pass
the following order.
ORDER
1. It is hereby held that the reference as to whether
the action of the management of M/s. Pfizer
Ltd., Verna Industrial Estate, Verna, Salcette,
Goa, in dismissing Shri Navin Gaude,
Management Associate, w.e.f. 16-06-2015 is
legal and justified, does not survive.
2. Inform the Government accordingly.
Sd/(Suresh N. Narulkar)
Presiding Officer,
Labour Court-II.
———uuu———

Department of Law & Judiciary
Law (Establishment) Division
––––

Order
No. 2/25/2014-LD(Estt)/494
Whereas, vide Order No. 15/02/2022-VIG/460
dated 04-04-2022 of the Director of Vigilance,

<!-- page 33 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
Altinho, Panaji, Shri Tushan Kunkolienkar, Civil
Registrar-cum-Sub Registrar, Bardez was placed
under suspension w.e.f. 04-04-2022 and ordered to
remain in the office of State Registrar-cum-Head of
Notary Services, Panaji, with entitlement of payment
of subsistence allowance, as per the Fundamental
Rule 53(1) (ii) (a), which shall be drawn against the
post of office of Civil Registrar-cum-Sub Registrar,
Bardez from 04-04-2022 to 30-09-2022.
Whereas, Shri Tushan Kunkolienkar has not
drawn the subsistence allowance for the period
from 01-10-2022 to 05-10-2022 from the Office of
Civil Registrar-cum-Sub Registrar, Bardez.
Whereas, Order No. 15/02/2022-VIG/Part-I/5 dated
06-10-2022, the suspension of Shri Tushan
Kunkolienkar has been revoked by the Director of
Vigilance, Altinho, Panaji w.e.f. 06-10-2022.
Whereas, vide joining letter dated 07-10-2022,
Shri Tushan Kunkolienkar has joined his duties w.e.f.
07-10-2022 (b.n.) in the office of State Registrar-cum-Head of Notary Services, Panaji.
Whereas, the post of Civil Registrar-cum-Sub
Registrar, Bardez has remained vacant from the
suspension period till the revocation period of
Shri Tushan Kunkolienkar.
And whereas, Shri Tushan Kunkolienkar was
transferred vide Order No. 2/25/204-LD(Estt)/1691
dated 21-10-2022 and posted as Joint Civil Registrar-cum-Sub Registrar, District Registrar, South and he
joined his duties on 25-10-2022 (b.n.).
Now therefore, in view of the facts in the forgoing
paras herein; the Government approval for the
following is hereby conveyed:
a) Shri Tushan Kunkolienkar to draw his
subsistence allowance for the period from
01-10-2022 to 05-10-2022 against the post of
Civil Registrar-cum-Sub Registrar, Bardez.
b) Considering the revocation of suspension vide
Order No. 15/02/2022-VIG/Part-I/5 dated
06-10-2022, Shri Tushan Kunkolienkar to draw
his salary w.e.f. 06-10-2022 to 24-10-2022
against vacant post of Civil Registrar-cum-Sub
Registrar, Bardez.
c) Vide Order No. 2/25/204-LD(Estt)/1691 dated
21-10-2022, Shri Tushan Kunkolienkar to draw
his salary against the post of Joint Civil
Registrar-cum-Sub Registrar, District Registrar,
South w.e.f. 25-10-2022.
By order and in the name of the Governor
of Goa.

23RD MARCH, 2023

Department of Panchayati Raj and
Community Development
Directorate of Panchayats
–––

Notification
No. 17/22/DP-ACCTS/IIISFC/2022-23/2482
Read: 1) Notification No. 17/22/DP-ACCTS/IIISFC/
/2021-22/8908 dated 31-12-2021.
2) Notification No. 17/22/DP-ACCTS/IIISFC/
/2022-23/271 dated 09-01-2023.
The Government of Goa is pleased to notify the
award period of 3rd State Finance Commission as
Financial Year 2024-25 to 2028-2029. The 3rd State
Finance Commission has been constituted vide
notification read in the preamble at Sr. No. (1) above
and further the term of its functioning is extended
vide notification at Sr. No. (2) above.
By order and in the name of the Governor of
Goa.
Siddhi Halarnakar, Director & ex officio Joint
Secretary (Panchayats).
Panaji, 15th March, 2023.
———uuu———

Department of Personnel
–––
Notification
No. 3/2/2012/PER/733
Read: Notification No. 3/2/2021-PER/302 dated
02-02-2023.
In exercise of the powers conferred by Section 3
read with Section 4 of the Goa Human Resource
Development Act, 2012 (Goa Act 12 of 2012), and in
supersession of the Government Notification No.
3/2/2012/PER/1544 dated 09-07-2020, published in
Official Gazette, Series II No. 17 dated 23-07-2020
and Notification No. 3/2/2021-PER/302 dated
02-02-2023 published in Official Gazette, Series II
No. 45 dated 09-02-2023, the Government of Goa
hereby re-establishes the Goa Human Resource
Development Corporation consisting of the
following Directors, namely:1. Shri Rudolfo Fernandes,
MLA, St. Cruz Constituency
2. Shri Deepak Dnyaneshwar
Naik, Vasco
3. Chief Secretary

— Chairman.
— ViceChairman.
— Director.

Amir Y. Parab, Under Secretary (Law-Estt.).

4. Additional Secretary
(Finance)
5. Joint Secretary (Personnel)

— Director.
— Director.

Porvorim, 16th March, 2023.

6. Director of Health Services

— Director.

3065

<!-- page 34 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

7. Commissioner, Labour and
Employment

— Director.

8. Shri Arun Naik, Bicholim

— Director.

9. Shri Mariano Araujo,
Cabesa, St. Cruz

— Director.

10. Managing Director, GHRDC

— Managing
Director.

Intelligence Bureau, at Directorate of Health
Services, Campal, Panaji, with immediate effect until
further orders.
Shri Sajjan A. Fatarpekar, shall be entitled to draw
additional charge allowance as per O.M. No. 2/38/
/75-PER (Vol. III) dated 09-06-2008 issued by
Personnel Department.

By order and in the name of the Governor of
Goa.

The period of service for holding additional
charge will not be considered for future promotions.

Nathine S. Araujo, Under Secretary (Personnel-II).

1. The Officer will be on probation for a period
of 02 years from the date of joining. During probation
period, the Officer shall be required to undergo
such training or pass such examination as
prescribed by the Controlling Authority for
satisfactory completion of probation. The probation
period shall be liable to be extended till the time
the aforesaid condition is not fulfilled by the Officer.

Porvorim, 15th March, 2023.
———uuu———

Department of Planning
Directorate of Planning, Statistics & Evaluation
––––

Order
No. DPSE/1/ADMN/Filling-Prom.SO/2022-23/3767
On recommendation of the Goa Public Service
Commission, as communicated vide their letter No.
COM/II/11/38(2)/2020/504 dated 02-03-2023,
Government is pleased to promote Shri Sajjan A.
Fatarpekar, Research Assistant (Group ‘B’ Gazetted)
of Common Statistical Cadre to the post of Statistical
Officer (Group ‘B’ Gazetted) in the Pay Scale of Level 7
(44,900-1,42,400) as per VIIth Pay Commission on
regular basis with immediate effect and is posted
at Directorate of Planning, Statistics & Evaluation,
Porvorim in Publication Division.
Shri Sajjan A. Fatarpekar, shall hold additional
charge of the post of Dy. Director, Health

2. The Officer shall exercise option to fix his pay
in terms of F. R. 22(I)(a)(1) within one month from
the date of promotion, if desire/applicable.
3. This issues with the Government approval vide
U.O. 2446/F dated 14-03-2023.
4. The Officer is required to submit joining report
to this Department for office record.
By order and in the name of the Governor
of Goa.
Vijay B. Saxena, Director & ex officio Joint
Secretary (Planning).
Porvorim, 17th March, 2023.

———uuu———

Department of Public Health
––––

Order
No. 47/1/2011-I/PHD/Part/417
Government is pleased to transfer the below mentioned Doctors under Directorate of Health Services,
with immediate effect:Sr. No.

Name of the Doctor

Present place of posting

Transferred at

1.

Dr. Dinesh Parab, Health Officer

Primary Health Centre,
Candolim

Community Health Centre,
Pernem.

2.

Dr. Vidhya Naik, Health Officer

Community Health Centre,
Pernem

Primary Health Centre,
Candolim.

By order and in the name of the Governor of Goa.
Gautami Parmekar, Under Secretary (Health-II).
Porvorim, 15th March, 2023.

3066

<!-- page 35 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023
Order
No. 44/16/2016-I/PHD/422

Government is pleased to transfer the following Medical Officer under Directorate of Health Services,
with immediate effect:Sr. No.

Name of the Medical Officer

1.

Dr. Shikandar Talwar, Medical
Officer

Present place of posting

Transferred at

North Goa District Hospital,
Mapusa
(deployed at Primary
Health Centre, Porvorim)

Primary Health Centre,
Porvorim
In place of Dr. Vikas Naik,
M.O.

By order and in the name of the Governor of Goa.
Gautami S. Parmekar, Under Secretary (Health-II).
Porvorim, 15th March, 2023.
————

Corrigendum
No. 25/15/2019-I/PHD/386
Read: Order No. 25/15/2019-I/PHD/106 dated 24-01-2023.
In the Government Order dated 24-01-2023 referred above, the details shown against Sr. No. 23 of
annexure in respect of Dr. Raksha Ratankumar Borkar, Medical Officer shall be substituted and read as
under:Name &
designation

Date of
joining

Present Grade Pay

Grade Pay to be made
applicable under DACP

1

2

3

4

Dr. Raksha Borkar,
Medical Officer

06-07-2012

G.P.- Rs. 6,600/- in PB-3 G.P.- Rs. 7,600/- in PB-3

Date of effect

06-07-2021.

By order and in the name of the Governor of Goa.
Gautami Parmekar, Under Secretary (Health-II).
Porvorim, 10th March, 2023.
———uuu———

Department of Tribal Welfare

Sr.
No.

Name of the
Official/Member

Designation

Directorate of Tribal Welfare
––––

1

2

3

Order

1.

No. 1-285-2022-23/ADMN/DTW/6108
2.
Read: Order No. 1-285-2021-22/ADMN/DTW/203
dated 09-04-2022.
In exercise of the powers under provision of
Clause 116(3) of the Article of Association of the
Goa State Scheduled Tribes Finance and
Development Corporation Ltd., and in continuation
to Order No. 1-285-2021-22/ADMN/DTW/203 dated
09-04-2022, Government of Goa is pleased to
re-constitute the Board of Director of the GSSTFDCL
and to appoint the following persons as Directors
on the said Corporation with immediate effect until
further order:-

3.
4.
5.

6.

7.

Shri Vishant Gaonkar,
r/o Canacona-Goa
Shri Pradip Gaude,
r/o Pale, Bicholim-Goa
Shri Anand Sawaikar,
r/o Savoi Verem, Ponda-Goa
Shri Camilo Barretto,
r/o Borda, Margao-Goa
Smt. Rajani Dayanand
Gaonkar, r/o Saljini,
Sanguem-Goa
Shri Shashikant Sonu
Gaonkar, r/o Kirlapal,
Sanvordem-Goa
Shri Narayan Kamat,
r/o Shiroda, Ponda-Goa

Director.
Director.
Director.
Director.
Director.

Director.

Director.

3067

<!-- page 36 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51
1

23RD MARCH, 2023
2

8.
9.

3

Shri Chandan Vargaonkar, r/o Cumbharjua, Tiswadi-Goa
Shri Khushali Kust Velip, r/o Morpirla, Quepem-Goa

Director.
Director.

The non-official Directors shall be entitled for sitting allowance as per the Government Notification/
Orders issued from time to time.
By order and in the name of the Governor of Goa.
Dasharath M. Redkar, Director (Tribal Welfare) & ex officio Joint Secretary (TW).
Panaji, 20th March, 2023.
———uuu———

Department of Water Resources
Office of the Chief Engineer
–––
Order
No. 3/25-15/90/CE-WR/1022
On the recommendation of the Goa Public Service Commission as conveyed vide confidential letter
No. COM/II/11/27(1)/2022/506 dated 03-03-2023, Government is pleased to order the promotion of the
following Assistant Engineers/Assistant Surveyor of Works (Civil) of the Water Resources Department,
Government of Goa to the post of Executive Engineers/Surveyor of Works/Engineering Officer (Civil),
Group-A Gazetted in Water Resources Department on regular basis in the Pay Scale of Rs. 15,600-39,100 +
Grade Pay Rs. 6,600/- (Matrix Pay Level No. 11 of 7th Pay Commission) with immediate effect and posted
them against the place indicated as below:Sr.
No.

Name of the
Officer

1

2

1. Shri Milind Gaude

2. Shri Sumant S. Nadkarni

3. Smt. Smita S. Dessai

4. Shri Menezes Jason
Damian
5. Shri Gipson Miranda
(ST)

6. Shri Yatin G. Shirodkar
(ST)

3068

Present designation
and place of posting

Designation and
new place of posting

3

4

Assistant Engineer,
Executive Engineer,
SD-I, WD-I, WRD, Porvorim Works Division VIII,
WRD, Karaswada-Goa
Assistant Engineer,
Surveyor of Works,
SD-I, WD-VII, WRD,
O/o the Superintending
Dhargal
Engineer, Circle-I,
WRD, Porvorim-Goa
Assistant Surveyor
Executive Engineer,
of Works, O/o the
Works Division XIV,
Superintending
WRD, Rawanfond,
Engineer, Circle IV,
Margao-Goa
WRD, Margao
Assistant Engineer,
Executive Engineer,
SD-II, WD-X, WRD,
Works Division X,
Sanguem
WRD, Sanguem-Goa
Assistant Engineer,
Executive Engineer,
SD-V, WD-III,
Works Division II,
WRD, Margao
WRD, Rawanfond-Goa
(he shall also hold
additional charge
of Executive Engineer,
WD-III, WRD, Ponda-Goa)
Assistant Surveyor
Surveyor of Works,
of Works, O/o the
O/o the Addl. Chief
Superintending
Engineer (IP), WRD,
Engineer, Circle (II), WRD, Porvorim-Goa
Karaswada

Remarks
5

Regular
Promotion.
Regular
Promotion.

Regular
Promotion.

Regular
Promotion.
Regular
Promotion.

Regular
Promotion.

<!-- page 37 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

The above Officers shall be on probation for the period of two years from date of joining as specified
in Column No. 9 of the Recruitment Rules notified in the Official Gazette, Extraordinary, Series I No. 28
dated 11-10-2001.
This is issued vide Government approval No. 2394/F dated 14-03-2023.
By order and in the name of the Governor of Goa.
Sd/-, Chief Engineer (WR) & ex officio Addl. Secretary.
Porvorim, 14th March, 2023.
————

Order
No. 3/25-15/90/CE-WR/Adm.I/1023
On the recommendation of the Goa Public Service Commission as conveyed vide confidential letter No.
COM/II/11/27(1)/2022/505 dated 03-03-2023, Government is pleased to order the promotion of Superintending
Engineer (Civil), Water Resources Department, Government of Goa to the post of Addl. Chief Engineer (IP)
& (MB), Group-A Gazetted in Water Resources Department on regular basis in the Pay Scale of
Rs. 37,400/- —67,000/-+ Grade Pay Rs. 8,700/- (Matrix Level No. 13 with immediate effect and posted
against existing vacancy indicated below:
Sr.
No.
1

Name of the Officers

Present designation
and place of posting

Designation and place of
posting on promotion

3

4

2

1. Shri Dnyaneshwar Y. Salelkar (ST)

Superintending Engineer,
O/o Superintending Engineer,
CO II, WRD, Karaswada

Additional Chief Engineer (I.P.),
Irrigation Project, WRD,
Porvorim (shall hold charge of
Superintending Engineer, CO II,
WRD, Karaswada).

2. Shri Ankush G. Gaunker (ST)

Superintending Engineer,
Additional Chief Engineer
O/o Superintending Engineer,
(M.B.), Mhadei Basin, WRD,
CO IV, WRD, Gogal, Margao-Goa Porvorim (shall hold charge of
Superintending Engineer,
CO-IV, WRD, Gogal, Margao-Goa).

This is issued vide Government approval No. 2393/F dated 14-03-2023.
By order and in the name of the Governor of Goa.
P. B. Badami, Chief Engineer (WR) & ex officio Addl. Secretary.
Porvorim, 14th March, 2023.
————

Order
No. 74-1-81/CE-WR/Adm.II/1024
Government is pleased to transfer Shri Nazareth Vaz, Surveyor of Works, O/o Superintending Engineer,
Circle I, WRD, Porvorim as Executive Engineer in the O/o Executive Engineer, Works Division I, WRD,
Porvorim against the existing vacancy, with immediate effect until further orders.
The concerned Head of Office shall relieve the above transferee and endorse the copy of the same to
this office.
This is issued with the approval of Government.
By order and in the name of the Governor of Goa.
P. B. Badami, Chief Engineer (W.R.) & ex officio Addl. Secretary.
Porvorim, 14th March, 2023.

3069

<!-- page 38 -->

OFFICIAL GAZETTE — GOVT. OF GOA
SERIES II No. 51

23RD MARCH, 2023

Government Printing Press
__

Official Gazette is now available through e-mail
for an annual subscription of Rs. 250/- (Rupees two
hundred and fifty only).

Subscription Rates
Notice
The subscribers to the Official Gazette are kindly
reminded that their present subscription term ends
on the 31st March, 2023, being the end of financial year.

The subscription charges are accepted either in cash,
postal order, demand draft or cheques (subject to
clearance) drawn only on State Bank of India, Panaji, in
favour of the Director, Printing and Stationery,
Panaji-Goa.

In case they wish to continue to be subscribers for the
ensuing financial year 2023-2024 they have to renew their
subscriptions from 1st April, 2023.

SUBSCRIPTION RATES
(Within the Union of India)
All 3
Series

Series
I

Series Series
II
III

Rs. P.

Rs. P.

Rs. P. Rs. P.

For any quarter .................. 1200.00
(Postage) ...........................
60.00

600.00
15.00

500.00 300.00
15.00 15.00

Subscriptions also can be opened for half year
i.e. from 1st April or 1st October or for any quarter,
beginning on 1st April, 1st July, 1st October or 1st January.
Renewal of subscription from 1st April should be
effected on or before 31st March, 2023 in order to avoid
interruption in the despatch of copies of the Gazette.
It should be noted that, in case the subscription is not
opened/renewed before the commencement of the period
to which it refers, the subscribers will be entitled to receive
copies of the Gazette only from the date the subscription
is actually opened/renewed.

For half year ........................ 2300.00 1200.00 1000.00 600.00
(Postage) ...........................
60.00
30.00
30.00 30.00
For any period exceeding
6 months up to one year... 4350.00 2300.00 1850.00 1150.00
(Postage) ............................
110.00
60.00
60.00 60.00

www.goaprintingpress.gov.in
Published and Printed by the Director, Printing & Stationery,
Government Printing Press,
Mahatma Gandhi Road, Panaji-Goa 403 001.
PRICE–Rs. 38.00
PRINTED AT THE GOVERNMENT PRINTING PRESS, PANAJI-GOA—458/100—03/2023.

3070
