---
doc_id: "649bad106ddafab3"
source_url: "https://ports.goa.gov.in/wp-content/uploads/2026/08/Notiifcation-Section-532-741-and-551.pdf"
ministry: "Captain of Ports Department, Goa"
title: "Gazette Notification Section 53(2), 74(1) and 55(1)"
date: ""
pages: 2
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "489d832a07bb531f"
---

<!-- page 1 -->

=
(32/2024-2026 RNI No. GOAENG/2002/6410
Panaji, 13th A\
Panal, 13th August, 2026 (Sravana 22, 1948)
9 (Sravana 22, 1948) SERIES II No. 20
F ot
a,
की
FICIAL © TT
९ श्री रह
han
PUBLISHED BY AUTHORITY
een“ “<<<
een SSS
Note: There are two Extraordinary issues to the Official Gazette, Series Il No. 19 dated 06-8-2026 as follows:-
1. Extraordinary dated 10-8-2026 from pages 941 to 942 regarding Notification from State Election Commission, Goa.
2. Extraordinary dated 12-8-2026 from pages 943 to 944 regarding Notifications from Department of Finance
GOVERNMENT OF GOA
Department of Captain of Ports
Notification
No. B-11039/IV ACT 2021/26-27/3130 Date : 11-Aug-2026
In exercise of the powers conferred by sub-section (2) of Section 53 of the Inland Vessels Act, 2021
(Central Act 24 of 2021), the Government of Goa hereby appoints the Captain of Ports, for the purposes of
the said section of the said Act.
This Notification shall come into force on the date of its publication in the Official Gazette.
By order and in the name of the Governor of Goa.
Shri Nikhil U. Dessai, IAS, Secretary (Ports).
Panaji.
Notification
No. B-11039/IV ACT 2021/26-27/3131 Date : 11-Aug-2026
In exercise of the powers conferred by sub-section (1) of Section 74 of the Inland Vessels Act, 2021
(Central Act 24 of 2021), the Government of Goa hereby appoints the Captain of Ports (Designated
Authority), for the purposes of chapter XIII of the said Act.
This Notification shall come into force on the date of its publication in the Official Gazette.
By order and in the name of the Governor of Goa.
Shri Nikhil U. Dessai, 1AS, Secretary (Ports).
Panaji.
Suggestions are welcomed on e-mail: ee ee 945

<!-- page 2 -->

SERIES II No. 20 OFFICIAL GAZETTE — GOVT. OF GOA
eect tet ett ed AUGUST 2020 2026
Notification
No. B-11039/I1V ACT 2021/26-27/3132 Date : 11-Aug-2026
in exerci; . : Vv
(Central hd क conferred by sub-section (1) of Section 55 of the Inland Vessels Act, 2021
section (1) of Secti 1 ), the Government of Goa hereby authorise the Surveyors appointed under sub-
Section 55 of the याती of the said Act to be the Surveyors for the purposes of said sub-section (1) of
This Notification shall come into force on the date of its publication in the Official Gazette.
By order and in the name of the Governor of Goa.
Octavio A. Rodrigues, Captain of Ports and ex officio Joint Secretary.
Panaji.
———. ¢¢¢—___
Department of Co-operation
Office of the Registrar of Co-operative Societies
Order
No. 3-5-10/ADT/STL/RCS/VOL-IX/Part-VII/1405 Date : 03-Jul-2026
Sub.: Time bound completion of computerisation of PACS.

In order to ensure effective implementation of the computerisation of Primary Agricultural Credit
Societies (PACS) in the remaining 11 PACS and to achieve 100% Dynamic Day End (DDE) in all 58
PACS by 31% October, 2026, it has been decided to deploy dedicated below mentioned officials for
providing continuous handholding support to the allotted PACS.

Accordingly, the officers/officials shown in Annexure-I (Annexed separately) are hereby assigned
specific PACS under their jurisdiction with immediate effect.

The assigned officers shall perform the following duties:

1. Provide regular on-site and remote technical and functional support to the allotted PACS;

2. Ensure completion of Dynamic Day End (DDE) on a daily basis and monitor compliance by the

PACS;
3. Identify and resolve operational issues relating to ERP/e-PACS implementation in co-ordination
with the System Integrator, PWC, System Intellect and Nodal Officer at Head Office;

4. Ensure that at least one staff member in every allotted PACS is adequately trained in each
functional module;

5. Conduct periodic follow-up visits and provide on-the-spot guidance to PACS officials;

6. Submit a daily and weekly progress report to the Head Office through the concerned zonal
Asstt. Registrars indicating the status of Dynamic Day End, pending issues, training conducted
and corrective measures taken; and

7 i ivity, ftware issues requiring

7. Immediately report any technical, connectivity, hardware or so’ र 1
intervention of the Head Office to Shri. Amay M. Dhakankar, Co-operative Officer/Special
Auditor and Shri Atish Redkar, Sr. Auditor/Inspector/SRO an ERP Coordination Officer.

To ensure focused implementation, the officers assigned under this Order shall primarily devote their
efforts towards the computerisation of PACS project and shall not ordinarily be entrusted with routine
office work, except where unavoidable and with the approval of the Head Office.

i i f the assigned officials
ed Zonal Asstt. Registrars shall closely monitor the performance o} ig) t ;
and रजत completion of Dynamic Day End, capacity building of PACS personnel and resolution of
all operational issued in respect of remaining 11 PACS so that the target of achieving 100% Dynamic Day
End in all 58 PACS is accomplished by 25" July, 2026.
946
