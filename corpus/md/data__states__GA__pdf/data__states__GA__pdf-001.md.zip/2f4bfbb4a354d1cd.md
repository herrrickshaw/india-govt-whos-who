---
doc_id: "2f4bfbb4a354d1cd"
source_url: "https://dhs.goa.gov.in/cms-gov-be/storage/app/public/uploads/newsNotices/cZsoovOU7Wf9CqffSpjVO3rgMgg1vRay1WJ5wdHc.pdf"
ministry: "Health Services Department, Goa"
title: "Public Tender No. 107/PT/DHS/MSD/25-26/1655 dated: 06/01/2026"
date: ""
pages: 37
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "848531836e918147"
---

<!-- page 1 -->

A
ee)
We
GOVERNMENTOF GOA
Medical Store Depot (MSD),
Directorate of Health Services, Campal, Panaji, Goa403001
(TOPS RISD टटका ES Ph.Nos. 2225640/S540/5668
No.107/PT/DI i JESS Date fo) (2026
AnnualE-Tender!Two Bid System)
MEDICINES, SURGICALS, CHEMICALS
The Director, Directorate of Health Services Panaji Goa, on bebelf of the Governor
of Goa invites E-tenders for the supply of medicines, surgical and chemical for the
~ period of three years as per Annexure A, B, C & D available online. Primary
manufacturer's, manufacturers, authorized distributors are invited to quote for the
tender

E-tender document will be available at https://eprocure.goa.gov.in, The tender form

with terms and conditions and list of the items can be viewed onlin: on the same and

No hard copies of tender forms will be made available,

Corrigendum modifications/corrections to the documents will only be published on the

same Website only. No newspaper notices will be published in this regards.

TERMSANDCONDITIONS:

1) In case of drugs, No Conviction Certificate of Manufacturer & Distributor issued by
FDA shall be not more than 01 year old at the time of submission.

2) The manufacturer should compulsorily have ISO /C.E. Certificate/In case of

- medicines, Manufacturer must have GMP certificate complying to Schedule M of
the Drugs and Cosmetics Rules 1945/WHO-GMP Certificate with Product List.

3) If bidder is Authorized Distributor, then he should have executed at least Rs.
15.00Cr.Consolidated Work order with Performance Certificate attached from
Charter Accountant& if bidder is Manufacturer, then he should have executed at
least Rs. 25 Crores Work Order with Performance Certificate for Last 3 Years
of Govt/Semi Govt PIU/ Private Hospital’ Laboratories,

4) ONE ENVELOPE MENTIONING TECHNICALBID DOCUMENTS OF THE
TENDERANDONEEN VELOPEMENTIONINGFINANCIALBIDDOCUMENTS
OF THE TENDER, THE TECHNICAL BID TENDER SHOULD CONTAIN IN
“SELF ATTESTED HARD COPIES"OF RELEVANT DOCUMENTSIN
ORDER _TO_ SUPPORT ONLINE CERTIFICATES ALONG WITH A
SEPARATE ENVELOPE CONTAINING EMD ONLY,

1

<!-- page 2 -->

5) TENDERS WHICH ARE NOT ACCOMPANIED WITH THE BELOW
MENTIONED ESSENTIAL DOCUMENTS WILL BE SUMMARILY REJECTED.
ALL CERTIFICATES SHOULD BE SELF ATTESTED, AND SUBMITTED IN
TECHNICALBID.

a) Copy of G.S.T- No, Certificate of the Tenderer

b) Earnest Money Deposit.

¢) In case of manufacturer, self-attested Photostat copies of valid manufacturing license
certificate and list of products issued by the licensing Authority. In case of

Distributor, in addition to manufacturing license certificate, a self-attested Xerox
copy of valid drug license issued by the competent authority i.e. state FDA. Original
copy shoukl be produced if at all asked for later.
se: d) In case of imported drug formulations, import license in form 10/10-A and
Registration certificate in form 41 issued to the firm by Drugs Controller General
(India) to be attached.

e) Certificate from the state FDA that the manufacturer is manufacturing and
marketing THE TYPE OF DOSAGE FORM FOR THE PRODUCT quoted in
technical bid, for 4 minimum period preceding three years, if manufactured in
India,

1) Certificate from the state FDA that the marketing compary in India is marketing the
type dosage form for the product quoted in technical bid, for a minimum period
preceding one year for imported products.

g) Certificate from the state FDA that the manufacturer is not convicted/ prosecuted
under the Drug und Cosmetics Act 1940, for manufacturing substandard or Spurious

. drugs. This certificate shall not be more than 01 year old on the date of
submission.

h) Every Manufacturer Drugs Dealer shall submit good manufacturing Practice (GMP)
Certificate as laid down under revised schedule M under the provision of the drugs
and cosmetic Rules issued by the State Drugs Licensing Authorities with respect to
cach drags quoted by the manufacturer where in the drugs are actually manufactured.
In case from Manufacturers holding a WHO GMP (Certificate of Pharmaceuticals
Product), the same certificate shall be considered to be co-mplying to Schedule M of
the Drugs and Cosmetics Rules 1945,

i) The Tender Offer should be firm, Conditional offer will not be accepted,

J) Certificate issued by the Chartered Accountant as per the format given below should
be submitted

2

<!-- page 3 -->

CERTIFICATE

This is to certify that (name of Mfg/ marketing company) whose products are being quoted in

the tender has a Minimum Average Annual Sales Turnover of Rs. 25 Cr for Last Three

financial years,

This certificate is required to be submitted by the drug Manufacturers/marketing companies

for MEDICINES AND SURGICALS AND NOT FOR CHEMICALS.

I) Affidavit from the "bidder" on stamp paper that all relevant documents mentioned from

Sr. no 5 (a) to Sr. No 5 (1) are duly enclosed in the technical bid and these have been self-

attested and are in order to the best of their knowledge. The Manu=acturing company is Hable

for being blacklisted as a future supplicr and will be debarred from participating in further

tenders of the government of Goa for a minimum peried of 5 years and the
is manu facturingcompany willalsobeliableforcriminalprosecutioninaccordancewiththelaw in

force, if the documents are found to be incorrect, forged, fabriczted and with misleading/

misrepresenting facts and information.

k) In case of those manufacturers who during the last 3years have recalled the drugs
quoted for quality defects, it is to be certified that the manufacturer has demonstrated
that after recall, has taken corrective measures and has studied the product for
stability and has developed stability profile for that drug quoted,

1) In case of authorized distributor! whole scller/ agent authorization letter from
Manufacturer for their product, they should also submi: certified copy of above
mentioned certificates from their manufacturers, alon2 with their valid drug
wholesale license issued by State FDA.

6) The tender form duly signed and accepted with terms ard conditions should be
es UPLOADED ONLINE WITH ACCEPTANCE, Also all relevant documents should
be uploaded online self-attested hard copies of the same should be submitted before
opening of Technical Bid,
7) The (EMD) of amount Rs.20,00,000 to be paid online through e-payment mode via. (as
mention below),

EARNEST MONEY DEPOSIT should be submitted as below,

i. National Electronic Fund Transfer (NEFT)/ Real Time Gross Settlement (RTGS
Axis Bank Over the-counter (OTC), Tenderer requires download pre-printed challan
towards credit of ITG available on e-tender website and make its payment through
any of their bank.

ii, Internet Payment Gateway (Debit/ Credit card of type VISA, MASTERCARD or
RUPAY.

iii एल Banking: Payment can be made through the Internet Banking of Any Bank.
NOTE: Any Payments made through NEFT/ RTGS/ OTC will take 48 hours for its
reconciliation. Hence the payments through NEFT/ RTGS/ OTC should be made at

3

<!-- page 4 -->

least TWO BANK WORKING DAYS in advance before any due date and upload
the scanned copy of the challans in the e-Tender website as a token of payment and
directly credit the amount to ITG account as generated by challan before 23/02/2026
by 5.00 pm and the copy of NEFT/ RTGS/ OTC/ debit card/ credit card/ net banking
(Axis Bank) challan is to be scanned and uploaded along with the bid on the website
prior to submitting the hard copies.
Note: For any query of FORM FEE, PROCESSING FEE and EMD (before doing the
payment) please contact ITG help desk line two days before closing of tender date, helpline
no-797285421 3, 7822039673, 797287 1944.
Made of payment towards cost of the tender form, EMD and tender processing fee — To
be paid online through e- payment mode via NEFI'/ RTGS/ OTC/ Debit card/ Credit card
Facility/ Net Banking with pre printed challans available on e-tendering website and directly
credit the amount to ITG account with Axis bank Ltd as generated by challans for NEFT/
. RTGS/ OTC.
Any deposits sent earlier for any other tender will not be considered even if the
supplies against the said tenders are completed.
The firms, which are registered with DGS & D, should also send earnest Money Deposit. If
an exemption in this behalf is required, they should produce an attested copy of the valid
certificate from DGS& D for the category of the items covered under the above tender
enquiry.
As per notification no.3/40/2003-IND\partytated8thSeptember201 lissued by Industries
Department Government of Goa, Secretariat, Porvorim, Goa ony those Micro and small
enterprises having minimum Average Annual Turnover of 10 Cr for Last Three
financial years and compulsorily registered under Directorate of Industries, Panaji Goa
should produce copy of Registration certificate for claiming following benefits
i) fee for purchase of tender form maximum up to Rs 200/- ii) sayment of carnest money
deposit shall be maximum up to Rs 500/- iii) Exemption from payment of Security deposit
and iv)price preference upto15%,ifquoted by the manufacturing company directly only,
os The benefits under the policy shall be extended to the registered (as mentioned above)
manufacturing units ONLY and not to any authorized dealer or firm representing the units.
The Micro and small enterprises which are registered with the NSIC (National small
Industries Corporation, Government of India Undertaking) should produce a copy of
Registration certificate claiming following benefits. i) Availability of tender sets free of cost,
ii) Exemption from payment Eamest Money deposit iii) Exemptior from payment af Security
Deposit ॥ to the monetary limit for which the unit is registered. -v) Price preference up to
15% over the lowest quotation of the large-scale units (merit). The benefits under the policy
shall be extended to the registered NSIC manufacturing units ONLY and not to any
authorized dealer or firm representing MSES. All other SSI units will be treated as on par
with other firms, Small Scale enterprises registered with NSIC in order to claim benefits of
the scheme will have to be registered with Directorate of Industries Trade & Commerce, Goa,
The Tender should be uploaded as per formats enclosed
1. Format A for Technical Bid(The technical bid should contai all the certificate item
wise duly numbered)
4

<!-- page 5 -->

2. Format B for Financial Bid.

8) The tender form duly signed and accepted with terms and conditions shoukd be
UPLOADED ONLINE WITH ACCEPTANCE. Also all relevant documents should
be uploaded online self attested hard copies of the same should be submitted before
opening of Technical Bid.

9) The bidders must specify full details of the product quoted namely generic name of the
Product contents of active ingredients, name of the manufacturer, type of packing, and
price per unit of the item quoted. Medicines, surgicals and other formulations should
comply with standards laid down in latest edition of LP, B.P U.S.P, and B.P.0 N.F1 ete.

10) The offer should be firm and valid fora PERIOD OF THIRTY SIX MONTHS FROM
THEDATE OF PLACEMENT OF THE FIRST PURCHSE ORDER. The tender is
Valid for 36 months from the placement of the first order,

a 11) No change in rates quoted shall be entertained after opening of Tender,

12) The rates should be quoted F.O.R.destinations,District Hospitels (North and South) Sub
District Hospital Ponda,Sub District Hospital Chicalim Medical Store Depot Ponda,
Medical Stores Depot Campal, Panaji, Community Health Centers, Primary Health
Centers,Urban Health Centers under this Directorate of Health Services Goa as and
when required,

13) The rates for which the GST will be charged should be specifically mentioned at the time
submission of quotation itself, failing which no claim for GST will be entertained at a
future date.

14)The Technical bid will be opened by Drug Purchase Committee in the Presence of
bidders or their authorized representatives. Based on scrutiny of Technical bid documents;
shortlisting of bidders will be done by Drug Purchase Committee. Technical bid
comparative chart displaying the Shortlisted bidders only will be uploaded on-line for
information. Objection if any may be raised within a week's time,

ss 15) The Financial bid will be opened by Drug Purchase Committee in the presence of
bidders. The comparative chart financial bid will be prepared and gradation will be done
of the Technical Bid shortlisted bidders only,

6. The bidders are requested to submit samples of all items in Annexure B & item no dand
5 of Annexure D if quoted by them in triplicate. Each of these s1ould be placed in three
different boxes, Each box should contain all the items quoted by them duly labelled
with Sr.No, name of the item. The three boxes containing these samples should contain
the name of the tenderer and tender no. The samples should be submitted before the
finalization of the Technical Bid of the tender, Bidders quoting for blood glucose
testing strips will be required to give demonstration of the rescective glucometers and
blood glucose testing strips before the finalization of the Technical Bid of the tender,
‘The sample should be submitted on or before 23/02/2026 by 5:00 p.m, to Medical Store
Depot, DHS, Campal, Panaji Goa.

16) Selection of L1 bidder will be done by Drug Purchase Committee based on gradation of

shortlisted bidders in Technical Bid and approval of samples.
5

<!-- page 6 -->

17) The Successful bidder has to payS% of the total value of the order as Security Deposit, in
form of Bank Guarantee with a validity of three years for due performance of the supply
order. This security deposit will be refunded only after the 2ompletion of the validity
period, Earnest money deposit will be refunded only after the receipt of the security
deposit in case of successful tenderers, If the successful tenJerer does not submit the
security deposit the bill/invoices will not process for the payment and the E.M.D. shall be
forfeited to the Government. All the application for the refund of B.M.D. and Bank
Guarantee (in view of Security Deposit) for the tender should be made only to the
Director of Health Services with all the details of e-payment along with the complete
detail for which it is submitted.

18) No representation from any of the bidders conveying their inability to execute the order at
the quoted rates will be entertained whatsoever, after the due date Opening of the tender,

19) The delivery of the goods should be made within a period of 30 DAYS from the date of
receipt of order in quantities of 40% initially followed by 20% each time or as per

~ requirement of the(MSD)(initial supply not to exceed 40%), For delay in supply, 4 penalty
of 1% per week but not exceeding 10% of the proportional cost of the specified drug/ item
not being supplied shall be imposed. However, any delay beyand four weeks will attract
cancellation of the order and the supply order for the said itere shall be placed before L2
and the difference in cost between L2 and LI rate will be recovered from L1 bidder,
However, an initial delay of 02 weeks from the stipulated dare mentioned in the supply
order on genuine and unforescen circumstances encountered by the manufacturers!
suppliers shall be condoned under exceptional circumstances.

20)The manufacturer may insure the goods at his own cost to safeguard the delivery of such
goods dispatched by him to the consignee as (MSD) will s0t be responsible for the
damage/ pilferage of goods during transit,

21)The price of the drugs quoted shall not be more than the ceiling price fixed by the
National Pharmaceutical Pricing Authority (NPPA) under the provisions of the DPCO.

22)THE REDUCTION IN PRICES UNDER THE DRUGS PRICE CONTROL ORDER
WILL BE ACCEPTED AND NEW REDUCED RATES SHALL BE THE BASIS OF

oN CONTRACT FROM THE DATE OF THE REDUCTION.

23)If it is brought to the notice of this department that a particular manufacturer/bidder is
blacklisted in a particular state, the manufacturer/bidder will be rejected.

24) The Director, Directorate of Health Services Panaji Goa, reserves the right to accept or
reject the supplies made by manufacturer/Distributor after the expiry of the stipulated
delivery period.

25)The supplies of Medicines should be accompanied with the company analytical report
from the manufacturer for each batch of items supplied.

26) Each packing shall confirm to the labelling provisions of the D-ugs & Cosmetics Act]940
and Rules there under. Any misbranded product is not only liable to be confiscated
without notice but also supplier is subject to penalty by recove-y of the difference in the
amount in obtaining it from another firm and appropriate actior as per rules in force will
be taken by the Director, Directorate of Health Services Panaji Goa for all the
consequences in the matter,

6

<!-- page 7 -->

27)The stock of any drug declared substandard (by the Food and Drugs Admn.) will be
freezed by FDA and kept in custody at the M.S.D DIRECTCRATE OF HEALTH
SERVICES until further directives and guidelines of FDA Goa, Any such substandard
drugs will not be returned to the firm. The concerned firms have to issue a Credit Note for
the value equivalent to the cost of freezed stock and this value of the cost of sub- standard
material will be deducted from the pending bill of the firm or from the E.M.D/ Security
Deposit, If the recovery cannot be made from the deposits and bills, it will be recovered
from the concerned manufacturer as if it is arrears of revenue,

28) Items should have not less than80% of its shelf life as on the date of supply.

29) Items that carry short expiry date which cannot be consumed before its expiry date, will
be returned to the manufacturer/ bidder three months prior to its expiry date and the firm
shall be responsible for replacement of this stock with that having longer shelf life or
issue credit note for the value of stock taken back.

e 30) Liquidated damages @ 10% of the value of goods riot supplied will be imposed for part
supply.

31) The Director, Directorate of Health Services Panaji Goa reserves the right to make interim
purchase, in case the successful bidder fails to supply any of the items within the time
limit specified in the order.

32)The quantities of the items mentioned in the list are for three year requirement, so the
rates should be valid for three years from the date of placement of Order.

33)The quantities of items quoted are likely to increase or decrease and orders will be
placed depending on the needs/ requirements at that point of time and also depending on
shelf life/consumption. The Directors decision in the matter will be taken as final.

34) Additional orders may be issued after total compliance of original order as per the
requirement as per the decision of the Purchase Committee.

35) All labels on container sand other wrappers will be imprinted with tae words—

“Goa Government Supply(G.G.S) NOT FOR SALE”IN BOLD RED LETTERS,
For D.H.S.requirement.

36)Companies that have not been able to supply on time the goods ordered, and have bad
records will be disqualified.

37) This tender form is not transferable.

38) Nationality of the bidder should be specifically mentioned in the tender.

39) The Director, Directorate of Health Services Panaji Goa, reserves the right to accept or
reject any tender without assigning any reasons thereof.

40)The Legal disputes, if any that may arise, will be subject to settkement within the
jurisdiction of the “C” Court of Panaji at Panaji. - Goa.

कू

<!-- page 8 -->

4I1)1£ the bidders require interpretation of any clause ,the decision of the Dy. Director
(Medical) Directorate of Health Services Panaji Goa should be taken as final,
42) Terms of Payment: In India Rupees vide ECS.
43) The last date of submitting the bids is 23/02/2026 uptoS:00pm. The Technical Bid of
the same will be opened on 25/02/2026 at 10:30am.
44) Date of Opening of Financial Bid will be declared at https://eprocure.goa.gov.in
hw
प
१ DIRECTORATEOFHEALTH
SERVICES
PANAJIGOA
T agree with the above terms and conditions.
Signature of the Bidder:
Name & address:
Nationality:
8

<!-- page 9 -->

XURE-—
ANNEXURE-A
DRUGSANDMEDICINES
1, ANAESTHETICS
INJECTABLES
= a DESCRIPTION OF THEITEM PACKING | eS

|. TINJ.ATROPINE SULPHATE--0.6MG/ML. [IMLAMP |
| 2.000 |

INJ. BUPIVACAINE 0.5% HEAVY IN DEXTROSE 5.000

(BUPIVACAINEHCL-3MG..DEXTROSE 4MLAMP

MONOHYDRATESOMG/ML) ॥
(4५ INTIGNOCAINE HCL 2%-30mal 5,000

INI. LIGNOCAINE HCL 2%WITHADRENALINE

5S. _ | [(1:2,00,000)EACH ML CONTAINS LIGNOCAINEHCLIP21.3 | 30ML¥IAL

MG +ADRENALINE IP 0.005MG]
ह TLIGNOCAINE HC LAaTOPICAT 1500]
INJ-MIDAZOLAM-IMGIML LSMLVIAL |
[x]

250 ML PEN
SEVOFLURANE(INHALATIONANAESTHETIC) ति
_ FILL-ECHNOLOGY
Lt IRPKETANIN HCL Sow GE इलत]
(1. IN-GCYCOPYRROLATE- 0.2MG/ML. [5.000
ORALSOLUTIONS/CREAMS/EARDROPS/SPRAYS TIONS/CREAMS/EARDROPS/SPRA YS
Quantity in

Eq DESCRIPTION OF THEITEM PACKING bottles/ tubes

ANAESTHETICS PRAY (LIGNOCAINENICLIOONG: =
[| Stianouaasoe vay NONOCANERCHONGS Vom aorne [Me
Lis. [MIDAZOLAM SPRAY ज्षाताहाााााणाणणणाज्िक्ााा]

9

<!-- page 10 -->

2. ANALGESICS,ANTIPYRETICS,NON-STEROIDAL
ANTI INFLAMMATORYMEDICINES (NSAIMs),
MEDICINES USED TO TREAT GOUT AND
DISEASE MODIFYING AGENTS IN
RHEUMATOID DISORDERS (DMARDs)
INJECTABLES
Ea DESCRIPTION OFTHEITEM PACKING ee | mre
| 14. |
| 15. |
| 16. | INPARACETAMOLINFUSIONIGM | «LOOMLBOTTIE | 5000]
7.500
~ 18. |_IN-TRAMADOL SOMGML [१७ | 6.000
TABLETS
0 | DESCRIPTION OFTHEITEM PACKING — | Quantity in
|_19._| TAB. DICLOFENAC SODIUM S0MG |__60000 |
| 20._|
TAB.SERRATIOPEPTIDASE SMG
TAB.FEBUXOSTAT-40MG | 000 |
(23. |
| 24. [TABIBUPROFEN400MG | STRIPPACK | ऊजळळ
| 25. | TABPARACETAMOL SQ0MG 400009
26._ | TAB.TRAMADOL SOMG [STRIPPACK |
SUPPOSITORIES
| DESCRIPTION OFTHEITEM PACKING .
27,_ | DICLOPENAC SUPPOSITORIES-100MG STRIP PACK [3000]
[ 23. [DICLOFENAC SUPPOSITORIES 23MiG_—- sri rack | 3.000
3. DICLOFENAC SUPPOSITORIES S0MG | STRIPPACK | 1,000]
[ 30. DICLOFENAC SUPPOSITORIES-125M@ | STRIPPACK | 3,000
| 31. | PARACETAMOL SUPPOSITORIES-170MG a
PARACETAMOL SUPPOSITORIES-80MG STRIP PACK 6,000
33._ | GLYCERINE SUPPOSTTORIES-ADULT STRIP PACK
GLYCERINE SUPPOSITORIES PAEDIATRIC | STRIP PACK
CONTAINING GLYCERINE USP |.2GMS
10
