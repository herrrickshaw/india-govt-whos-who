---
doc_id: "1dcdefa5f69fb6bb"
source_url: "https://nhm.goa.gov.in/wp-content/uploads/2023/11/Publication-of-e-Tender-Notice.pdf"
ministry: "Directorate of Health Services, National Health Mission, Goa"
title: "Publication of e-Tender Notice"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "af9acdc1f25c08ad"
---

<!-- page 1 -->

GOVERNMENT OF GOA
DIRECTORATE OF HEALTH SERVICES
CAMPAL PANAJI GOA
E‐Tender Notice No. DHS/FW/NBS/2023‐24/588

dated 25/10/2023

E‐TENDER NOTICE
(E‐TENDERING MODE ONLY)
Director of Health Services, Government of Goa, Campal, Panaji Goa on behalf of the
Governor of Goa invites online e‐tender under the two bid system from eligible service
providers for the following work:


“Performing New Born Screening Tests to detect inborn errors of metabolism
and other inherited disorders for live births in public Health facilities”



The last date and time of online application is fixed on 30/11/2023 upto 5.00pm
and online technical bid will be open on 01/12/2023 at 11.00 am.



The eligibility documents, Earnest Money Deposit, Cost of tender and tender
processing fee along with the tender may be submitted online from the date of
uploading till the last date of submission of the tender document. The hard
copies may be submitted (dropped in tender box) in the cabin of the Jt. Director
of Accounts (H), Directorate of Health Services, Campal, Panaji.



The details of tender can be downloaded from our website
https://eprocure.goa.gov.in



The tender is uploaded on the website on 01/11/2023.

(Dr. Geeta Kakodkar)
Director of Health Services
