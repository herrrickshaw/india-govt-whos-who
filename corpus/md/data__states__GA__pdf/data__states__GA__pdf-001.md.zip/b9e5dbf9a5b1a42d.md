---
doc_id: "b9e5dbf9a5b1a42d"
source_url: "https://www.goaelectricity.gov.in/wp-content/uploads/2026/01/Circular20170622_15425117.pdf"
ministry: "Electricity (Power) Department, Goa"
title: "Communication Through Proper Channel Only"
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "0c237d375ddec9cc"
---

<!-- page 1 -->

GOVERNMENT OF GOA
ELECTRICITY DEPARTMENT
OFFICE OF THE CHIEF ELECTRICAL ENGINEER, OFFICE OF THE CHIEF प ८१% ——_—_——___——
Head Office, 3" CE a atta gv Vidyut Bhavan, Tiswadi, GOA 403001 Tel:2234155,2224680/BBAPX:2426421,2422353,2426022I| Fax:2426986,
222354 Email de oxi. cbse. hatp/ we goaslectiity. gov inihttp/59.90 10890 ne -cee-elec goa(@nicin: website:: http /mvww.goaclectricity.gov.in/http//59.90-104.90
No.51(3)/CEE/Tech/PLG/2017-18/ 3 | 9
Dated:- 2\/06/2017
C C
TRCULAR
Sub: Correspondence to be made through proper channel onty. to be made through proper channel only.

It is observed that many officers are flouting the communication integrity by forwarding
copies of their communication to the higher officers other than their next superior for reasons
best known to them. This is a direct indisciplanary act of the officer endorsing such communica-
tions to higher officers other than his own superior when the matter can be addressed through
proper channel for sorting out the issue and which sometimes, involves procedures to be fol-
lowed for putting up to various levels of authorities within the Government for a concrete deci-
sion.

All the Officers are henceforth directed to strictly restrict their correspondence to their
next Superior only, refraining from endorsing copies to further levels unless and until the matter
is of utmost importance or called by higher authorities.

In view of the above, all officers, with immediate effect, are directed to follow the
standard code when any correspondence is to be made and use the proper channel route so that
discipline is maintained always. Failure to adhere to these instructions would be viewed serious-
ly and necessary disciplinary action as per the CCS rules will be initiated against such officer.

These instructions are with immediate effect.

(NN se
Chief Electrical Engineer
To,
1, Additional Chief Electrical Engineer I/II, Vidyut Bhavan, Margao/ 5" Floor, CEE Office, Panaji
2. Superintending Engineer, Circle Vll/Commercial/Planning, Margao/Panaji/ CEE office , Panaji
3. Executive Engineer(Commercial)/Planning/IPM/Training/Energy Monitoring/Vigilance & RTI/
QC&S/EHV/Contract Service Cell, Office of CEE, Panaji
4. Joint Director (Accounts), 4" Floor, Office of CEE, Panaji
5. Deputy Director (Adm), Establishment Section, 4% Floor, Office of CEE, Panaji
6. Executive Engineer, Div I, Panaji/I(S&W), Margao/IIKEHV), Ponda/IV, Margao/V, Bicho-
lim/VI, Mapusa/VII, Curchorem/V! TI(MRT), Margao/IX(EHV), Tivim/X(EHV), Ponda/X],
Vasco/XII(EHV), Xeldem/XIII(EHV), Kadamba/XIV(EHV), Verna/XV(Civil), 6" floor, Goa-
ots Complex, Patto, Panaji/XVI, Margao/ XVII, Mapusa/XVII(Civil), Ponda
os ter file
