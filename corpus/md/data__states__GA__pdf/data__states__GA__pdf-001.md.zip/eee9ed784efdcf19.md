---
doc_id: "eee9ed784efdcf19"
source_url: "https://statelotteries.goa.gov.in/wp-content/uploads/2026/10/Corrigendum-III.pdf"
ministry: "Directorate of Small Savings and Lotteries, Goa"
title: "Corrigendum-III for Selection and Appointment of a Marketing Agency for Marketing and Sale of Online or Paper or Both forms of Lotteries conducted by the Government of Goa for Set No. 3."
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "3a4724e62393ead9"
---

<!-- page 1 -->

&
Government of Goa
Directorate of Small Savings & Lotteries
Serra Building, Altinho,
Panaji — Goa, 403001
Ph: - 0832-2423864 Fax: - 0832 - 2432660 email: dir-lott.goa@nic.in
SR ICRI kk a oo ka a a a a OR dO aR ERE RR KEE
No. 1-8-2025/DSSL/Part/Corrigendum-III/ 2 ¢ 3 Dated: -9 3-/10/2026
CORRIGENDUM - II
Tender Reference No. | No. 1-8-2025/DSSL/685 dated 04/09/2026
2026 DSSL_31583_1 dated 04/09/2026
Selection and Appointment of a Marketing
WoreDescrotion Agency for Marketing and Sale of Online or
P Paper or Both forms of Lotteries conducted by
the Government of Goa for Set No. 3
With reference to above mentioned tender it is informed to all bidders that
the last date for submission of tender documents and opening of technical bids are
being extended. The revised dates are being stated below: -
Last Date for Submission of Bid: 25/11/2026 up to 04:30 P.M.
Opening of Technical Bid: 27/11/2026 at 04:00 P.M.
All other terms and conditions of the Tender, including those contained in
the RFB and Corrigenda issued, shall remain unchanged.
था
(Veera V. at ak)
9 Director
Directorate of Small Savings & Lotteries
