---
doc_id: "cb1ca358fc8eebed"
source_url: "https://goaspcb.gov.in/wp-content/uploads/2026/08/directions-13-8-26.pdf"
ministry: "Goa State Pollution Control Board, Goa"
title: "GANESH IDOL REGISTRATION LAST DATE 14-8-2026 ON WWW.GOAOCMMS.NIC.IN FOR MORE DETAILS CLICK HERE"
date: ""
pages: 4
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "20577f85d3c6a01f"
---

<!-- page 1 -->

|
»
र yf य
& Ae
Gute. १५ *
. \
as 12311
Sa : Hobo, 112
Nee 1210000008
Government of Goa
Department of Environment & Climate Change
4" Floor, Dempo Tower,
Patto, Panaji-Goa
Phone Nos.: 0832-2416581
e-mail: dir-env.goa@gov.in
No. 3-108-2005/STE-DIR/PART/ उर Date: (1/7/2026
DIRECTIONS UNDER SECTION 5 OF THE ENVIRONMENT(PROTECTION)
व “ACT, 1986 (CENTRAL ACT, 29 OF 1986),

Whereas,| it has been brought to the notice of the Government of Goa, that several
Plaster of Paris (PoP) idols are being imported from neighboring states for sale in Goa during
the annual Ganesh Chaturthi festival.

Whereas, such PoP idols are put up for display and sale in various permanent
establishments and other temporary establishments / “Chitrashallas” across the state during the
annual Ganesh Chaturthi festival.

Whereas, such PoP idols are made from hemi hydrated calcium sulphate manufactured
by calcination process and such PoP idols when immersed in water do not dissolve or
disintegrate fast, thereby causing irreversible environmental effects on the riverine / coastal
ecology or the ¢co-system of any water body, which in turn causes adverse environmental
effects.

Whereas, the chemical paints, colours and dyes applied for such PoP idols contain
poisonous chemicals / elements like Mercury, Zinc Oxide, Chromium, Lead, Cadmium ete
which causes harmful effects to marine / aquatic life, which when consumed by humans. leads
to the cause of formation of cancer and other diseases including respiratory ailments, skin
infections etc. The PoP also contains chemicals / elements like Gypsum, Sulphur, Potassium
and Magnesium which cause harmful effects to aquatic and marine life (flora & fauna) and in
turn causes harmful health effects, if such aquatic / marine life is consumed by human beings:

<!-- page 2 -->

T
"= N
=i) Discs anspert) to-check the entry. of vehicles / Goods carriers entering the State
carrying stich PoP idols as its cargo, prevent the entry of the vehicle and divert the same
back to thé source, failing which to attach the vehicle / goods carrier and hand it over
to the Police Authorities at the nearest Police Check Post / Police Station and allow
only thoselidols where the vendors have registered on the GSPCB Portal

(e) Director General of Police, to issue relevant directions to the Police Officers at the
Police Check Post / Police Station, to take appropriate action against the offenders
reported by the officials of Excise Department and Transport Department. Also, in case
of transport of such PoP idols by rail, the Police Officers should check the cargo on
arrival and ensure that.the same is not allowed to exit from the Railway Station and
allow only those idols where the vendors have registered on the GSPCB Portal.

(f) Commissioner (State Taxes) to ensure that all permanent and temporary registered
establishments in the State do not conduct any sale of PoP idols during Ganesh
Chaturthi festival, failing which the registration of such establishments shal] be
cancelled forthwith and allow only those idols where the vendors have registered on
the GSPCB Portal.

(g)’ Director|(Municipal Administration) & Director (Panchayats) to provide details of all...
the immersion/visarjan sites within their jurisdiction with GPS Co-ordinates, name of
wards, type of water body etc. on the GSPCB Portal on or before 30" May of the
concerned year.

(h) Director (Municipal Administration) & Director (Panchayats) to issue relevant 1
directions to all Municipal Councils / Corporation and Village Panchayats, directing
them to भ

(i) | Inform all the vendors / Chitrashalas to register on the GSPCB portal 30 days

prior to the commencement of the Ganesh Chaturthi festival and not grant any
licenses to such establishments / “Chitrashalla’s” who are not registered on the
GSPCB portal.

(ii) | Not to grant licenses / permissions to vendors / Chitrashalas for display and
sale of PoP idols, during Ganesh Chaturthi festival season and allow only those
vendors who have registered on the GSPCB Portal to display idols of Chikan
mati / Clay / Shadu mati idols having POP content up to 20% and painted using
eco-friendly water based, biodegradable and non-toxic natural dyes for paints.

ii) | Obtain an undertaking from each such establishments / “Chitrashalla’s” that
they shall not display or sell such PoP idols failing which the Chief Officers

of the Municipal Council / Commissioner of the Municipal Corporation
Secretary of Village Panchayat, shall forthwith cancel the license granted for
the said establishment / “Chitrashalla’s” and arrange for its immediate closure

(iv) All Chief Officers of the Municipal Councils / Commissioner CCP, Secretaries

of the Village Panchayats will provide the list of all Chitrashalla’s with
|

<!-- page 3 -->

— uerification by the GSPCR that the vendor has fully complied with
the prescribed disposal procedures.
In the event of any subsequent violation, the registration of the
vendor shall be liable to be cancelled, and the vendor may be
prohibited from manufacturing, selling, or otherwise dealing in idols
within the State of Goa
(i) District Gollectors and Additional Collectors Of the three Districts to enforce the above
directions by issuing relevant instructions to Dy. Collectors / Mamilatdars for
monitoring and enforcement of the directions and to file such complaint against any
such violator before the appropriate Court under relevant provisions of the
Environment (Protection) Act, 1986 and any other Act / rules as applicable. They are
also required to conduct inspections and order closure of such establishments /
Chitrashalla’s who continue to conduct display and sale of such PoP idols.

(j) Director (Industries, Trade & Commerce) to issue relevant directions to all industries /
manufacturing units registered in the State to stop manufacture of PoP idols / products, _..
failing which to cancel the registration of such Industry / Unit.

(k) Member Secretary, GSPCB to inspect and verify the various industries / units registered
in the State and issue directions to stop manufacture of PoP idols/products in State of

Goa, leading to withdrawal of consent to operate and issue appropriate closure
directions.

(1) The respective Incharge of Police Station/Police Inspector’s or any other Police Officer
not below the rank of Police Sub Inspector, within his jurisdiction, upon being informed
by any of the Authorities mentioned herein above from (c) to (k) or suo motu, about the

manufacturing, procurement, stocking, display, sale and transportation of PoP idols
within the jurisdiction of the Police Station; shall confiscate such PoP idols and seal
such premises used to manufacture, stock, display or sale of PoP idols, attach the
vehicle used for transportation and further take action to prosecute the violators in terms
of section 15 of the Environment (Protection) Act, 1986.
By Order and in the name of the
Governor6f Goa
Director / Ex-Officio Jt. Secy.

(Envt. &CC)

Toy
1) The District Collector (North), Collectorate of North Goa, Panaji-Goa.
2) The District Collector (South), Collectorate of South Goa, Margao-Goa.

<!-- page 4 -->

T
|
|
oo |
- न्य की. to) Secretary (Industries), Secretariat, Alto-Porvorim, Goa fav
information.
9) P.A. to Secretary (Home), Secretariat, Alto-Porvorim, Goa.......... for information.
