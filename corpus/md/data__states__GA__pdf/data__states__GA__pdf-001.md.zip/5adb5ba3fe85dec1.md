---
doc_id: "5adb5ba3fe85dec1"
source_url: "https://www.goaelectricity.gov.in/wp-content/uploads/2026/01/Scan20002.pdf"
ministry: "Electricity (Power) Department, Goa"
title: "Estimate of Government for Sanction"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9bb355b8270135bb"
---

<!-- page 1 -->

GOVERNMENT OF GOA

ELECTRICITY DEPART]ITENT
OFFICE OF THE CHIEF ELECTRICAL ENGINEER
Head Office, 3'd Floor, Vidyut Bhavan, Tiswadi, cOA 403001 TeI.:2234155222468018BAPX:2426421.2422353.242602211Fax:2126986,
2222354111. Email::cec-clecgoa(@nic.in:

website:: http://www.goaelectriqity.gor.idhttp://59.90.I04.90

No.51(3)/CEE/Tech/PLG 12017 -l8l 4q 3

Dared r- lq /oz /20L7

CIRCULAR
Sub: Submission of Estimates to Government for sanction.

A number of estimates are noticed being prepared and submitted on the instructions of
the Local MLA, Panchayat Members, and other local bodies and are mounting unnecessarily for
sanction from Government although there are already pending estimates submitted by your office and which inturn provides a false notion to the concemed that the estimates are being submitted. This also entertains uncalled for, queries from them from time to time, even though financial constraints restrict the number of estimates to be submitted.
In view of the above, all Divisional officers are directed not to prepare any such estimates without the prior instructions of the Undersigned. If any such estimate is found necessary
as per the Divisional Offrcers view, it may be brought to the notice of the Undersigned with
supporting facts and sketches from the technical point of view after which the Undersigned
would decide and convev the necessarv instructions for further action.
Further any sanctioned estimates pending at the Division level should be executed on
top priority and timely completion should be strictly ensured. No new estimates should be submitted for obtaining sanction from the Government unless the earlier backlog is cleared.
"These

instructions shall be implemented with immediate effect and the Divisional Engineers shall be held responsible, if not complied.

?l rl
Engineer
Chief Electrical Ensineer
To,

l. Additional Chief ElectricalEngineer VII, Vidyut Bhavan, Margao/ 5'h Floor, CEE Office, Panaji
2. Superintending Engineer, Circle IAVCommercial/Planning, Margao/Panaji/ CEE office, Panaji
3. Executive Engineer, CSC, 5th Floor, Office of the CEE, Panaji.
4. Executive Engineer, Div I, Panaji/II(S&W), MargaoAII(EHV), Ponda/IV, MargaoA/, Bicholim/Vl, Mapusa/VII, Curchorem/VII(I\4RT), MargaoAX(EHV), Tivim/X(EIIV), Ponda/XI,.
VascoDilI(EFIV), Xeldem/XIII(EHV), Kadamba.D(IV(EHV), Verna/XV(Civil), 6h floor, GoaIDC Complex, Patto, Panaj i/XV! Mar gaol XVII, Mapusa/XVll(Civil), Ponda
5. Master file
