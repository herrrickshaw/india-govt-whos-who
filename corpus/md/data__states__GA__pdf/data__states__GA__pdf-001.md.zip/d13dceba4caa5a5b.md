---
doc_id: "d13dceba4caa5a5b"
source_url: "https://www.goaelectricity.gov.in/wp-content/uploads/2026/06/Circular-Regarding-New-LT-Domestic-Electricity-connectoons-with-loadaq-5-KW-Ease-Doing-Business-initiatives.pdf"
ministry: "Electricity (Power) Department, Goa"
title: "Circular Regarding New LT Domestic Electricity connectoons with loadaq 5 KW Ease Doing Business initiatives"
date: ""
pages: 3
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "1a27818fc78db648"
---

<!-- page 1 -->

PAR
z GOVERNMENT OF GOA & 2025
LEE ELECTRICITY DEPARTMENT “Semele
> OFFICE OF THE CHIEF ELECTRICAL ENGINEER = 'niemrationat Year
= 3®°FLOOR, VIDYUT BHAVAN, PANAJI - GOA अमे कक
Phone No: (0832)2224680 Fax No :(0832)2222354 Email Id:cee-elec.goa@nic.in
No. CEE/Tech/Plg/Gen/2026-27/5 023 ~~~+‘Dated:-1% /06/2026.
CIRCULAR
Subject: Regarding release of New LT Domestic electricity connections with
loads upto 5 kW under Ease of Doing Business initiatives. (LTDS-I & LTDS-II
Categories)
With reference to the above, the Goa Electricity Department, as part of its Ease of
Doing Business initiatives, have simplified the procedure for release of new “Low
Tension (LT)” Single Phase electricity connections, with a sanctioned/contracted load
up to 5 kW.
Accordingly, with immediate effect, applicants seeking new 1ph LT electricity
connections upto 5 kW shall be required:
a. To submit only the following documents:
[ Sr.No. | Mandatory Documents
b. The submission of test report is not mandatory. The consumer shall, however, be
required to submit a self declaration while applying for a new connection (Format
enclosed).
c. Upon receipt of the application, the concerned Junior Engineer shall verify the
requirement for additional infrastructure if any from the utility end with minimal
inconvenience to the consumer, to assess the feasibility for release of the connection
and accordingly process application for the estimate/demand note.

<!-- page 2 -->

The concerned engineer shall check safety requirements such as physical condition of
the earthing, MCB capacity and location of the energy meter, at the time of releasing the
connection.
The above procedure shall also be applicable for applications received for increase of
load up to 5 kW.
The above procedure shall not be applicable for installations having any power
generating unit such as Generator, Inverter, Solar roof top unit etc. installed in the
system.
This is issued with the approval of the Competent Authority.
(Stephen Fernandes)
Chief Electrical Engineer
Copy to:
1. OSD to the Honorable Minister for Power, Mantralaya, Porvorim.
2. The Chief Secretary, Secretariat, Porvorim.
3. The Secretary, Power, Secretariat, Porvorim.
4. The Secretary, Industries, Trade & Commerce, Secretariat, Porvorim.
5. The Chief Executive Officer, Goa Investment Promotion & Facilitation Board.
6. The Superintending Engineer, Circle-I(S)/II(N) Margao/Panaji.
4. The Superintending Engineer, Commercial / Planning.
8. The Joint Director (Accounts), Office of the Chief Electrical Engineer, Panaji- Goa.
9. The Executive Engineer, Elect., Div-I/II/I/|V/V/VI/VII/VIIVIX/X/XUXI/XUVXIV/XVUXVI,
Panaji/ Margao/ Ponda/ Bicholim/ Mapusa/ Curchorem/ Tivim/ Vasco/ Xeldem/
Kadamba/ Verna.
10. The Executive Engineer, IT, Vidyut Bhavan Panjim....... For information and needful
for requisite changes in online acceptance of forms for mentioned category of
consumers/intending consumers.

<!-- page 3 -->

SELF-DECLARATION
(To be furnished in case no Test Certificate from a Licenced Electrical Contractor is furnished)

L Shri/Smt./Ms./M/s. an
applicant for new connection/increase of load, for a load of kW,do
hereby certify that the wiring of my premises, catering to the mentioned load, has
been completed in all respects and the works have been carried out conforming to
the CEA(Measures relating to safety and Electricity supply Regulations 2010) (as
amended till date). I, further certify that the requisite site tests have been carried
out, found to be in order and it is electrically safe to operate the apparatus free
from danger.

I, hereby indemnify and keep indemnified the Electricity Department or any
third party against any loss, damage, claim, liability or consequences that may arise
due to non-submission of Wiring Test Certificate from a Licenced Electrical
Contractor/Charted Electrical Safety Engineer for the load applied for by me.

NAME:
ADDRESS:
