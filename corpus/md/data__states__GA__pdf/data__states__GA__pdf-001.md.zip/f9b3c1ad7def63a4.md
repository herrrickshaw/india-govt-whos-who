---
doc_id: "f9b3c1ad7def63a4"
source_url: "https://goaspcb.gov.in/Media/Default/Rules/swmformI.pdf"
ministry: "Goa State Pollution Control Board, Goa"
title: "SWM Authorization Form"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "52fa61c3f6264abe"
---

<!-- page 1 -->

FORM – I
[ see rule 15 (y) 16 (1) (c), 21(3) ]
Application for obtaining authorisation under solid waste management rules
for processing/ recycling/ treatment and disposal of solid waste
To,
The Member Secretary,
State

Pollution

Control

Board

or

Pollution Control Committee, of….....
Sir,
I/We hereby apply for authorisation under the Solid Waste Management Rules,
2016 for processing, recycling, treatment and disposal of solid waste.
1.

Name of the local body/agency appointed by
them/ operator of facility

2.

Correspondence address
Telephone No.
Fax No.

e-mail:

3.

Nodal Officer & designation(Officer authorised by
the local body or agency responsible for operation
of processing/ treatment or disposal facility)

4.

Authorisation required for setting up and operation waste processing
of the facility (Please tick mark)
recycling
treatment
disposal at landfill

5.

Attach copies of the Documents
Site clearance (local body)
Proof of Environmental Clearance
Consent for establishment
Agreement between municipal authority and
operating agency
Investment on the project and expected return

<!-- page 2 -->

Processing/recycling/treatment of solid waste

6.

(i) Total Quantity of waste to be processed per
day
Quantity of waste to be recycled
Quantity of waste to be treated
Quantity of waste to be disposed into landfill
(ii)Utilisation programme for waste processed
(Product utilisation)
(iii)Methodology for disposal (attach details)
Quantity of leachate
Treatment technology for leachate
(iv)Measures to be taken for prevention and
control of environmental pollution
(v)Measures to be taken for safety of workers
working in the plant
(vi)Details on solid waste processing/recycling/
treatment/disposal facility (to be attached)
7.

Disposal of solid waste
Number of sites identified
Quantity of waste to be disposed per day
Details of methodology or criteria followed for site
selection (attach)
Details of existing site under operation
Methodology and operational details of
landfilling Measures taken to check
environmental pollution

8

Any other information.

Date:

Signature:

Place:

Designation
