---
doc_id: "42eae8a597eedfdd"
source_url: "https://statelotteries.goa.gov.in/wp-content/uploads/2026/10/Corrigendum-II.pdf"
ministry: "Directorate of Small Savings and Lotteries, Goa"
title: "Corrigendum-II for Selection and Appointment of a Marketing Agency for Marketing and Sale of Online or Paper or Both forms of Lotteries conducted by the Government of Goa for Set No. 3."
date: ""
pages: 1
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "ffd54d31fcd081a9"
---

<!-- page 1 -->

Sass
| aa
Government of Goa
Directorate of Small Savings & Lotteries
Serra Building, Altinho,
Panaji — Goa, 403001
Ph: - 0832-2423864 Fax: - 0832 - 2432660 email: dir-lott.goa@nic.in
JSS ORGS EEE AR EADIE ERIS ISSO OSSD ISBIEEIDD ISDE IGEES SIEGE ie
No. 1-8-2025/DSSL/Part/Corrigendum-II/ 76 2 Dated: -©) /10/2026
CORRIGENDUM - II
Tender Reference No. | No. 1-8-2025/DSSL/685 dated 04/09/2026
Tender ID 2026_DSSL_31583_1 dated 04/09/2026
1 Selection and Appointment of a Marketing
| on Agency for Marketing and Sale of Online or
कक Description Paper or Both forms of Lotteries conducted by
the Government of Goa for Set No. 3
With reference to above mentioned tender it is informed to all bidders that the
last date for submission of tender documents and opening of technical bids are being
: extended. The revised dates are being stated below: -
Last Date for Submission of Bid: 21/10/2026 up to 04:30 P.M.
Opening of Technical Bid: 23/10/2026 at 04:00 P.M.
All other terms and conditions of the Tender, including those contained in the
REB and Corrigenda issued, shall remain unchanged.
(Hoge —
(Veera V. Nayak)
Director
Directorate of Small Savings & Lotteries
