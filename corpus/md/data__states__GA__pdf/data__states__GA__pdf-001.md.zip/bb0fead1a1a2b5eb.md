---
doc_id: "bb0fead1a1a2b5eb"
source_url: "https://dslr.goa.gov.in/Notifications/Notification.pdf"
ministry: "Directorate of Settlement & Land Records, Goa"
title: "» Notifications"
date: ""
pages: 5
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "b65bee5f995022da"
---

<!-- page 1 -->

a
अ MARKeD /- ORIGINAL eT =:
ee .
of BEE? / ART -2. ou
' ०८-०० |09/ PY: I ae Be
‘os 4 as, १2५८
Ow ae = @
| लय, 19, > अ By 4
ws 4
jay no: 3°\ lie = टर (>
॥०७०५ जेण फस ;
i a — Revs — | Government of Goa y
home पया Revenue Department
see 8/2076 RD I jetariat, Porvorim-Goa. 403 521 0
_No: 26/24/2016-RD |\q% Dated: 25/01/2018
. | NOTIFICATION
\

Whereas, the draft vhs namely, the Goa Land Revenue (Issuance of
Identification and Corresponding Certificate) Rules, 2017 which the
Government of Goa proposed to make in exercise of the powers conferred by
sub-sections(1) and (2) of section 199 of the Goa Land Revenue Code, 1968(Act
No.9 of 1969)(hereinafter referred to as the “said Act”), were pre-published as
required by sub-section (3) of section 199 of the said Act, vide Notification No.
26/24/2016-RD dated 21/11/2017 of the Department of Revenuc,

_Severnment of Goa, in the Official Gazette, Series I No. 34, dated 23/11/2017,
~ | Inviting objections and suggestions from all persons likely to be affected
thereby within fifteen days from the date of publication of the said Notification

in the Official Gazette;

Ancl whereas, the said Official Gazette was made available to the public
on 23/11/2017;

i And whereas, objections/suggestions received from the public on
the said draft Rules have been considered by the Government,
क eae —

Now, therefore, in exercise of the powers conferred by sub-sections (1)
and (2) of section 199 read with section 108A of the Goa Land Revenue Code,
1968 (Act No. 9 of 1969) and all other powers enabling it in this behalf, the

~* » Government of Goa hereby makes the following rules, namely:-

"1, Short title and commencement.— (1) These rules may be called the
voa Land Revenue (Issuance of Identification and Corresponding
Certificate) Rules, 2018. व
(2) They shall come into force from the date of their publication in the
Official Gazette.

2. Definitions.— In these rules, unless the context otherwise requires, -
(a) “Code” means the Goa Land Revenue Code, 1968 (Act No. 9 of 1969);
(b) “Corresponding Certificate” means certificate issued by Directorate of
Settlement and Land Records to identify the new survey numbers
corresponding to old cadastral survey numbers; =

<!-- page 2 -->

| N
-2-
(d) “Inspector” means the Inspector of Survey and Land Records;
(e) “Identification Certificate” means the certificate issucd under thesc
rules to identify the property in respect of new survey plan;
()) “Old Cadastral Plan” means the plan prepared during Portuguesc
regime.
(g) “Survey Plan” means the plan prepared under the Code.
Words and expressions used herein but not defined shall have
same meaning as assigned to them in the Code. ह
3, Identification certificate or corresponding certificate to be issued
only for the purpose of Mutation and Partition.— The Identification
certificate or corresponding certificate shall be used only for the purpose
_ of carrying out mutation in survey records and partition and not for any
___..other purpose or before any authority of the Government and Court of
law.
-र a J
4. Form of Application and documents to be submitted.— (1) The
fapplication: for identification certificate: shall be tade in’ Form-I hereto *
along with a notarized copy of thesregistered title document having plan ग
‘attached thereto, certified copy of survey plan and Form I and XIV.
(2) The application for corresponding certificate shall be made in
pane pln} Ih alongwith the latest certified copy ‘of old Cadastral
plarf/Lote plan) ‘and new survey plan obiained within six’ months before,
the date of application, copy 6f Form Tand XIV and all the documents as
= specified in Form II. if the name of the applicant is fot figurirtg in Form 1
ह and XIV, then the applicant shall produce any document showing the
relationship with the person whose name is appearing in such Form.
5. Procedure for disposal of application.— (1) Inspector of Survey and
Land Records, after verification of records of the land available with him,
documents and plan submittéd along with the application, is satisfied
that an Identification Certificate-can be issued, ask the applicant to pay
fees as specified in these rules. Inspector of Survey and Land Records
shall not issue the certificate if there is any variance/discrepancy in the
records available with the office and the documents submitted by the
applicant.
(2) The Survey Officer in the office of Directorate of Settlement and
Land Records shall acknowledge the receipt of the application for
corresponding certificate. Thereafter, the Survey Officer shall scrutinize
the original old records of the property maintained by Directorate of
टक...

<!-- page 3 -->

-3- : yrtfe
If the necessary documents are not produced and the original
records of the property are not available with the office of Directorate of
Settlement and Land Records, the application shall be rejected and the
applicant be informed accordingly.
6, Fees for issuing Identification or Corresponding Certificate.— The
fees for Identification or Corresponding Certificate shall be as follows:
(i) For an area admcasuring 4000 sq.mts. or for one holding
irrespective of area,— Rs. 1500/-> .
(ii) For every additional area admeasuring 4000 sq.mts. or part thercof
or additional holding,— Rs. 500/-.
7, Site Inspection and Inspection Report.— Inspector of Survey and
Land Records after receipt of fees shall carry out or cause to carry out |
site inspection of the land in respect of which the Identification
. Certificate is applied through the surveyor to identify the property shown
by the applicant vis-a-vis, plan attached to title document in reference to
new survey plan to identify the survey number.
8. Issuance of Identification Certificate— Based on the report of site
inspection, and after verifying the records as required, the Inspector of
Survey and Land Records shall issue the Identification Certificate, in
Form III hereto.
9. Issuance of Corresponding Certificate.— If the office of the
Directorate of Settlement and Land Records after verifying the records
available decides to issue the Corresponding certificate than the
applicant shall be asked to pay the fees and Corresponding Certificate
a! shall be issued accordingly by the Superintendent of Surveys and Land
~~ Records, in Form IV hereto.
S By Order and in the name of
the By ॥ 01 008.
र (Sudii a
Under Secretary (Revenue-I)
10,
‘The Director (Printing & Stationery) Government Printing Press, Panaji,
with a request to publish the above notification in ncxt Government
Gazette and supply two copies of the same to this Department.
Copy To:
1. The Collector, North/ South Goa District, Panaji/Margao-Goa. ,
-2 The Director, Directorate of Settlement and Land Records; Panaji, Gos.
3. The O.S.D. to Hon. Chief Minister, Ministerial Block, Alto-Porvorim.
4. TheO'ST ta Han Revanie Minictar Minietario! Binnie Altm Dncvnnim

<!-- page 4 -->

y 4०
1246.
FORM No. IV
(see rule 9)
INO; asso
Government of Goa,
Directorate of Settlement &
Land Records, Panaji-Goa.
Date: =
CORRESPONDING CERTIFICATE

This is to certify that the New Survey Number/Sub-Division
Number of Village of Taluka specified in column
(2) corresponds to Old Cadastral Number/Lote Number of
= Village of Taluka as shown in column (3) hercin

_= below:

~~
1) | क 2 3
Sr.|New Survey Number/ Sub-|Old Cadastral Number / Lote
No | Division Number. Number. कि
AL.

| Of Village

of Taluka |OfVillage

| ‘of. a i taluka

=e The corresponding New Survey Number/ Sub-Division Number
oS with respect to the Old Cadastral Number/Lote Number is determincd
by superimposing new survey mgp on Old Cadastral/Lote survey map

and does not involve any field work.

This certificate is issued at the written request of
ee Ee, (Rion a ee _ for,
Mutation and Partition purpose only and same shall not be used as a
document to produce before any other Government authority or
Court of Law in Goa. ,

. >
Supdt. of Survey and Land Records
Panaji,Goa.
aN
y af ह

<!-- page 5 -->

f OTHER Cc ory ' TP er re
| > —
i
, OFFICIAL GAZETTE — GOVT. OF Goa
SE iNo my aan woven, 2017
FORM-1
i Application Form For Identification Certificate
: {See Rule 4\(1)] र
: et nl
| वै --:>>>-
j ———_
Det: eT
| b, \
१" The Inspector of Survey and Land Records, 2 |
| Panaji, Goa. | Pie
. Sub: Application for Identification Certificate. |
Sir, / } Ve
| { १
| I the undersigned request you ‘to Issue Identificdtion Certificate. The details of property are 4s
| under— } | 1.
hie 1, Village: 1 | ' 1.४
rs. 2. Taluka: i {
| L: 3, Purpose for which Identification Certificate isequired | |
tt 4. Documents showing how the applicant is entitled to the property| +
¢ 5, Whether any structure exists in suit property on the date of applicatio ___-__- |
भी भै rit
tt 6. Whether property belongs to Government/Comynidade or Private Land? Lease, hi : Fi
१ f 6(a). If yes, details to be prdvided including latest dider etc. oH {
3१ ठे { ‘ ry क:
क. ! vy . 1४४)
i ooh 5 र्त पू i eer “iii
Pod 9 (१ Ty ) Signature of Applicant 74) 4
१.१ i ae \ 790672
1) Bnctosures xh | | hi
\ 1. Certified Copy of new Surfey Plan. he ' त कर!
| j "| | 2 Notarised copy of Registeted title यन ing. copy attached thereto, a i HH
| "oF 3. Certfidd copy of Form I & XIV of property in quoptidn, as well as Form 1 & XIV of all the adjoining yy
tli ! survey numbers. an i i
4. Notarised copy of document showing applicant is entitled to the property. | ge
Vit र्‍या | ;
PES FORMAL I
| i Application Form for Cofresponding Certificate
{Seo Rule 4\(2)]
! : From:
$ ee
H Deve: Re
च्छ '
The Director, क
| Settlement and Land Records,
‘ Panaji, Goa. i
प Sub: Application for Corfesponding Certificate, \
‘Sir, 7
ब I, the undersigned request you to issue Corresponding Certificate stating that the New Survey
Nos. of Village of Taluka corresponds to Old Cadastral Nos./Lote
i Nos. Village of, Taluka. 2
. 1724 | {
i
ee = — |
