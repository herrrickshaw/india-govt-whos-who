---
doc_id: "79bdec4dacb44a9f"
source_url: "https://ghb.goa.gov.in/notices/wp-content/uploads/2025/09/Tender-Notice-no.-GHB_TECH_EE_1056_2025.pdf"
ministry: "Goa Housing Board"
title: "Tender Notice no: GHB/TECH/EE/1056/2025 Dated: 21/08/2025   (PDF 831 KB)"
date: ""
pages: 4
method: "tesseract:eng+mar"
script: "LATIN"
needs_ocr: false
sha1: "7cd9a5a4a8a7980b"
---

<!-- page 1 -->

आल. खडखड हलकासा
i] GOA HOUSING BOARD
oO
OFFICE OF THE at OF THE EXECUTIVE ENGINEER ENGINEER
SU EXECUTIVE ENGINEER
New Market Complex Porvorim Goa. Market Complex Porvorim Goa.
Ph:-0832-2412925
TENDER NOTICE NO: GHB/TECH/EE/ 10५७ /2025 Date: 2) /08/2025
DETAILED TENDER NOTICE
(E-TENDERING MODE ONLY)

The Executive Engineer, Goa Housing Board, Porvorim Goa, invites Percentage Rate E-Tenders on online mode only, from the valid
approved eligible contractors registered in appropriate Class and Categories of Goa PWD Possessing experience of similar works in
respect of the tender for the following work :-

Sr. : ट E. Cost of Tender | Tender Class of Time
No. Name of the work Estimated Cost . M.D. किता Processing Fee | contractor limit
[Moa ot Payment Payment Oni Ld
Setting up of Guest
House in commercial _| Rs.24,09,160.86 Rs. 48,184/- | Rs, 3,540/- Rs.4,818/- Class I1&
cum Residential fe ast (Non es dabl above (Buildings) | 90 days
Complex at Bordem- _| (without GST) refundable) refundable)
Bicholim Goa.

<!-- page 2 -->

TENDER SCHEDULE
Last date & Time of online application: - 18/09/2025upto1 pm.
te Last date of online submission of tender is: 18/09/202Supto 1 pm.
The date and time of openi i ie 7
Contplex, om Parvorin Gar of online tender is: 22/09/202S5after 3.30 pm in the Office of the Executive Engineer, Goa Housing Board, Market
The online application should accom; i
pany the following docu: ents (Si i ite):
a. Attested copy of valid Registration Certificate. द ments (Scan and Upload on the e Te able
b. Attested copy of valid PAN Card
८. Attested copy of valid GST Certificate
d. Mode of Payment towards the Tender Document Fee(TDF), Tender Processing Fee(TPF) & Earnest Money Deposit(EMD) to be paid
online through e-payment mode via :

i. National Electronic Fund Transfer(NEFT)/Real-Time Gross Settlement (RTGS)/Axis Bank Over-the-counter(OTC). Tenderer
requires download pre-printed Challan towards credit of ITG available on e-tender website and make its payment through any of
their Bank.

ii. Internet Payment Gateway (Debit/Credit card of type VISA, MASTERCARD or RTGS.
iii. Net Banking Payment can be made through the Internet Banking of Any Bank. ;
Note: Any Payments made through NEFT/RTGS/OTC will take 24 hours for its reconciliation. Hence the payments through
NEFT/RTGS/OTC should be made at least TWO BANK WORKING DAYS in advance before any due date
e. The applicant should submit a declaration giving the names of the works in hand in the above mentioned category on stamp paper
of Rs 100/-

<!-- page 3 -->

TTT ह ai
INSTRUCTIONS TO CONTRACTORS
1.The intending bidder must read the terms and conditions of CPWD-6 carefully, He should only submit his bid if he considers himself. eligible
and he is in possession of all the documents required.
2. Information and Instructions for tenderer posted on website shall form part of bid document.
3. The bid document consists of the schedule of quantity of various types of items to be executed and the set of terms and
conditions of the contract to be complied with and other necessary documents can be seen and downloaded from website
https://eprocure.goa.gov.in
4. Those tenderer not registered on the website mentioned above, are required to get registered beforehand. If needed they can be imparted training
on online bidding process as per details available on the website. For any of the assistance regarding participation may contact e-tender support
staff orhttps://eprocure.goa.gov.in
5. The intending tenderer must have / obtain a valid class II digital signature with signing and encryption to submit the bid.
6. On opening date, the contractor can login and see the competitor bid sheets.
7. It is the responsibility of tenderer to ensure the credit of tender document fees, tender processing fees and EMD into respective receiving bank
accounts of ITC via various modes of payments mentioned above, on or before last due date and time of tender.
8. The excel sheet uploaded is just for reference purpose only. No bid would be accepted via excel sheet. All the quoting should be done via
forms provided in the system itself.
9. The tenderer is required to ensure browser compatibility of the computer well in advance to the last date and time for receipt of tenders.
The department shall not be responsible for non-accessibility of e-tender portal due to internet connectivity issues and technical glitches at
the tenderers end.

<!-- page 4 -->

Neeeeeeeee aera e reer e errr
10. The tenderer shall be responsible for the correctness and genuiness of the documents uploaded during the tender submission. Any discrepancies
in the matter will be liable for rejection and suitable action.
11. No hard copies of the documents should be submitted in the tender box. However, the lowest tenderer shall submit the hard copies of
the documents scanned and uploaded and original copy of declaration on stamp Paper after opening of the tender.
Incomplete applications shall be summarily rejected and right to reject any or all the tenders including the lowest without assigning any reason
thereof is reserved.
For E-Tender help contact helpdesk: 1800230230
sy \
(S.D.Gaonkar)
EXECUTIVE ENGINEER
