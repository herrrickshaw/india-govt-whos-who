---
doc_id: "057ffd07cc8fcbba"
source_url: "https://ifbgoa.goa.gov.in/sites/default/files/List-of-the-candidates-qualified-for-the-written-test-based-on-skill-test-and-instructions-for-written-test-for-the-post-of-Junior-Stenographer.pdf"
ministry: "Inspectorate of Factories & Boilers, Goa"
title: "List of the candidates qualified for the written test based on skill test and instructions for written test for the post of Junior Stenographer(English)(1.5 MB)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "09b4e10c27523b02"
---

<!-- page 1 -->

Inspectorate of Factories and Boilers
Altinho-Panaii-G
written test based

List of can

on the skill test conducted on 2311012021.

Name of the Post: Junior Stenoqrapher
Name of the Candidate

Remarks

108

ANJEETA GHADI

Qualified for Written test

)

08

SONIA DSOUZA

Qualified for Written test

3

102

NEEMA RANE

Qualified for Written test

4

78

MAYRA FERNANDES

Qualified for Written test

5

58

BHAVESH PEDNEKAR

Qualified for Written test

6

42

TUSHAR SAWANT

Qualified for Written test

Sr.
No.

Roll

1

No.

Note: Written test of 2 hours duration will be conducted on 0410112022 for
shortlisted candidates.
Reporting time is 11.00 am at Government Polytechnic Panaji on04'01'2022'
Exam duration: 11.30 am to 1.30 Pm

Govt Polytechnic Panaji
Altinhio- Panaji-Goa

the

<!-- page 2 -->

ONS FOR
TENOGRAPH

OR

TORA
PANAJI. GOA

TEST

POST

TORIES & B8l

A

D?tg Fnd time of Written Teqt : - 04'01 '2022 from

-

Venue;- Government Polytechnic, Altinho, Panaji

carry photo lD proof, preferably EPIC card / Aadhar card / Driving

License in

will not be allowed to appear
original for verification at the time of skill test. candidate
photo lD proof;
for the written test if he / she fails to produce valid
2.

You should reach the skill test centre half an hour prior to

the start of test i'e' by

11:00 A.M.;
3.

4.

5.

Mobile phones / calculators or any other electronic

gadgets are not allowed'

to maintain social
wearing of mask lface shield is compulsory. candidate is advised
times'
dlstance and follow COVID-19 appropriate behaviour at all the
The medium of instruction will be English

type carrylng total
Further, it is informed that the written test paper will be objective
questions on General
100 marks and of two hours duration. The syllabus will include
affairs and events of
knowledge, Mathematics, Logical reasoning, English grammar, current
national & international importance'

the same shall
lf the eligible candidate has been tested positive for COVID-19, then
before 4:00
be intimated to this office vide e-mail at ifb.qoa@nic.in latest by 03.01 .2022
P.M. so as to make separate seating arrangements at the venue.
Please note that no TA/DA will be paid for appearing for the above
test.

mentioned written
