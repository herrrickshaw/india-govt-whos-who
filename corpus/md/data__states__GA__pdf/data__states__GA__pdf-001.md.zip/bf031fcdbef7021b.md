---
doc_id: "bf031fcdbef7021b"
source_url: "https://ifbgoa.goa.gov.in/sites/default/files/Order-regarding-online-submission-of-returns-under-The-Factories-Act-1948.pdf"
ministry: "Inspectorate of Factories & Boilers, Goa"
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "35a6f389a089c516"
---

<!-- page 1 -->

Government of Goa
Inspectorate of Factories and Boilers
Altinho, Panaji, Goa – 403 001
Ph no. 0832-2227670 / 2404852
Website: www.ifbgoa.goa.gov.in
Ref. No. CIF/20(Part)/S-II/2019/560

Fax no. 0832-2404853
Email: ifb.goa@nic.in / ci-ifb.goa@nic.in
Dated: 28.05.2019 (Jyaistha 07, 1940)

ORDER
In pursuance to the recommendations under the Business Reforms Action Plan for the States
under the Ease of Doing Business, issued by the Department of Industrial Policy & Promotion,
Ministry of Commerce & Industry, Government of India, the Government of Goa hereby makes
available online the following services of the Inspectorate of Factories and Boilers, Altinho, Panaji,
Goa and are mandated to be submitted through online mode only with immediate effect:
(i)

Submission of Half Yearly Returns (Form No.35) under The Factories Act, 1948;

(ii)

Submission of Annual Returns (Form No.34) under The Factories Act, 1948;

(iii)

Submission of Annual Returns of Accidents and Dangerous Occurrence (Form No.37)
under The Factories Act, 1948;

By Order and in the name of
the Governor of Goa
Sd/-

(ANANT S. PANGAM)
Chief Inspector of Factories & Boilers (I/C)

Copy to:
1. PS to Hon’ble Minister (Factories & Boilers), Secretariat, Porvorim, Goa for information.
2.

The Secretary (Factories & Boilers), Secretariat, Porvorim, Goa for information.

3.

The Director, Directorate of Industries, Trade & Commerce, Udyog Bhavan, 1 st floor, Panaji,
Goa for information.

4.

All the Inspector of Factories for information

5.

The Statistical Assistant, Inspectorate of Factories & Boilers for information & necessary action

6.

The Director, Department of Printing Press and Stationery, Panaji Goa with a request to publish
the same in the next issue of the Official Gazette.

7.

The Director, Department of Information and Publicity, Udyog Bhavan, 3 rd Floor, Panaji, Goa
with a request to issue a press release in the local newspapers for general information of the
public.

8.

Notice Board, Inspectorate of Factories & Boilers, Altinho, Panaji, Goa

9.

Office copy
