---
doc_id: "afda7b0df8fdb069"
source_url: "https://nims.edu.in/NIMSWP/upload/admission_uploads/2026-09-15/2026_MPTPGDMSC_Notification.pdf"
ministry: "Nizam's Institute of Medical Sciences, Hyderabad, Telangana"
title: "View"
date: ""
pages: 1
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "c9335ad7b933f730"
---

<!-- page 1 -->

ఓ PAINS
Woy,
NIZAM’S INSTITUTE OF MEDICAL SCIENCES
(A University Established Under the State Act)
PANJAGUTTA :: HYDERABAD.T.G.
File No. AC2/277/2026/MPT/PGD/M.Se(GC Date :o& -09-2026
NOTIFICATION
Applications are invited from eligible candidates of Telangana State only for admission
into Master of Physiotherapy (MPT)-15, PG Diploma in Nuclear Medicine Technology-08,
M.Sc.Program in Genetic Counselling-02 for the year 2026. The candidates are requested to
visit website: www.nims.edu.in for online application registration, prospectus and also for any
updates. The availability of online application from 15-09-2026 and last date for submission of
online application is before 5.00 PM of 30-09-2026. The hard copy of online application shall be
submitted along with supporting documents as detailed in prospectus (Annexure 1) in person or
by post (preferably by Indian postal service) so as to reach the Associate Dean, Academic-2,
2% floor, Old 0౧౦ Block, NIMS, Panjagutta, Hyderabad-500082 before 5.00 PM of 03-10-2026
wa
DEAN
Prof, P. Chandra Sekhar
MS (Orthopeadics)
oe DEAN
a itute of Medical Sciences
Punjagutta, Hyderabad-500 082.
