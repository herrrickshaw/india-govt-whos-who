---
doc_id: "a4bf8425dbbdca26"
source_url: "https://cdma.cgg.gov.in/cdma/Files/FeeGOs/GO_10.pdf"
ministry: "Commissioner and Director of Municipal Administration, Telangana"
title: "GO 10"
date: ""
pages: 2
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "edc6f778845bce73"
---

<!-- page 1 -->

Registered No. HSE~49/2003-2005. [Price : Re, 0-15 Palse. |
అటి అట
ఆంధ్రప్రదేశ్‌ రాజ పత్రము
RULES SUPPLEMENT TO PART - I
EXTRAORDINARY
OF
THE ANDHRA PRADESH GAZETTE
PUBLISHED BY AUTHORITY
No. 79 | HYDERABAD, MONDAY, DECEMBER 12. 2005.
ee
NOTIFICATIONS BY GOVERNMENT
——
GENERAL ADMINISTRATION DEPARTMENT
a& PR ID
AMENDMENT TO ANDHRA PRADESH INFORMATION
{REGULATION OF FEE AND COST) RULES 2005.
{G.0.Ms.No.545, General Administration (1 & PRIN),
12th December 2005]

In exercise of the powers conferred by clauses (b) and (c) of
sub-section (2) of Section 27 of the Right to Information Act, 2005 (Central
Act 22 of 2005), the Government of Andhra Pradesh hereby makes the
following amendment to the Andhra Pradesh Right to Information
(Regulation of Fee and Cost) Rules; 2005 issued in G.O.Ms.No. 454, General
Administration (1478. 1) Departmem dated 13th October, 2005 and
published in Rules Supplement to Part-1 Extraordinary issue of the Andhra
Pradesh Gazette dated 13-10-2005.

[1]
౪1170,

<!-- page 2 -->

AMENDMENT
In the said Rules, in rule 4, for clause (vi) under caption “(B) other
than priced material”, the following shall be substituted, namely:-
“(vi) for Inspection of records, no fee for the first hour; and a fee of
Rupees Five for each subsequent hour (or fraction thereof.”
K.V. RAMANACHARY, .
Ex-Officio Secretary to Government,
(1 & PR).
pk, ani
Printed and published by the Commissioner of Printing. Govermnenent of Andhra Pradesh
at Government Central Press, Hyderabad.
