---
doc_id: "bfe435bbff5a0bd0"
source_url: "https://cdn.s3waas.gov.in/s3da4fb5c6e93e74d3df8527599fa62642/uploads/2026/10/17924121738138.pdf"
ministry: "Medchal Malkajgiri"
title: "2. BDK Guidelines notification"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d5037b7f768ea4bf"
---

<!-- page 1 -->

GOVERNMENT OF TELANGANA
O/o. the District Medical & Health Officer,
Medchal Malkajgiri District
BDK GUIDELINES

(Guidelines issued fron time to time for recruitment and instructions

to candidates)

NOTIFICATION NO. 2765/E1/DMHO/MDCL/2026, DT: 19-10-2026
basis
The Applications are invited for the various post temporarily on contract
DM&HO,
the
of
control
the
under
District
Malkajgiri
under NUHM to work in Medchal
to 3:00
Medchal Malkajgiri District from 23-10-2026 to 28-10-2026(Excluding Sunday) at 11:00AM eligible
Interested
Shamirpet.
PM only at O/o. DM&HO, F-1 IDOC building Anthaipally,
candidates may downloaded application from the website

Interested eligible candidates may attend along with all Original certificates and filled in

downloaded

application

from

the

official

website

i.e.,

https//medchal

malkajgri.telangana.gov.in along with all the original certificates for verification purpose with
a set of self-attested copies of the following certificates and no application will be entertained
later.

ii
ii.
iv.

SSCor Equivalent examination (for date of birth proof)

Intermediate (or) 10+2 examination,

Latest Caste Certificate (in the father's name) issued by the concerned

Tahsildar /MRO,,Govt. of Telangana.

Community Certificate (SsC Group-l, Group-II and Group-II) issued by

the competent authority of Telangana Government (as applicable)

V.

Relevant certificates in respect of candidate claiming PH, ExServiceman and

other quota. The candidates who are seeking reservation under EWS quota shall

produce the latest relevant certificate for the financial year 2026-2027 from MRO

concerned.
Vi.

vii.

The candidates who are seeking reservation under disability has to obtain
SADAREM certificate issued by competent authority.

Bonafide certiffcates for the study from 1* to 7th class, are required for claiming

local status.
viii.

ix
X

xi

Xi.

Marks memos of concerned Board or University (Consolidated/Year wise)

Provisional Certificate from the board/university concerned,

Registration Certificate from the TSMC Board

One photograph duly pasted and signed across on the application form.
Registration fees @ Rs. 500/- of demand draft in favour of :"District Medical &
Health Officer, Medchal-Malkajgiri" from any Nationalized Bank.

Note: 1. Those who have not submited/produced the above required documents
will summarily be rejected and no further request will be entertained.
2. Candidates who have not submitted bonafide i.e. 1st to 7th class will be
treated as Non- local and those who has not submitted caste certificate
will be treated as 'OC.

The appointment is purely temporary on contract basis for a period of one year or
actual
need is seizes, whichever is earlier. Merit, RoR and presidential orders
will be followed. The
minímum age is 18 years and maximum age is 46 years as per G.O.Ms.No,
30, General
Administration (Ser.A) Dept., Dt: 08/02/2024 as on 30.06.2026 with the
following
relaxations
allowed for reckoning the maximum age limit as per existing rules:
i)
ii)

For SCs, STs & BCs 5 (Five) years
For ex-servicemen 3 (three) years in addition to
the length of service in armed
forces.

Disabled persons 10 (ten) years

<!-- page 2 -->

QUALIFICATION & REMUNERATION:
SI.
No.

Name of the

1

Medical
Officer

Post

No.of posts (BDs)

Qualification

(17) No.s

MBBS (Registered
with T.S. Medical

(Basthidawakhana

NUHM-PM ABHIM)

2

Staff Nurse

month

Rs. 52,000/

Council)

PM

B.Sc./GNM Nursing
/M.Sc. Nursing /

Rs. 29,900/

(32) No.s

GNM With Post B.Sc

NUHM PM-ABHIM)

Telangana State

(Basthidawakhana

Salary for

PM

Nursing with

concerned Council

Registration

Supporting
Staff

(8) No.s
(Basthidawakhana
NUHM PM-ABHIm)

SSC

Rs.15,600-PM

Qualification

Telangana Medical Council Registration certificate may be obtained till the date of

making application (there should be validity by MCI Registration, otherwise the

certificate will not be entertained)

For Medical officer - Multi Zone-II Districts

1) Suryapet, 2) Nalgonda, 3) Bhongir (Yadadri), 4) Jangaon, 5) Medchal-Malkajgiri,
6) Hyderabad, 7) Rangareddy, 8) Sangareddy, 9) Vikarabad, 10) Mahabubnagar,

11) Jogulamba (Gadwal), 12) Wanaparthy 13) Nagarkurnool 14) Narayanpet
For Staff Nurse -Zonal VI Districts

1) Hyderabad, 2) Ranga Reddy, 3) Medchal Malkajgiri, 4) Sangareddy,
5) Vikarabad.
For Supporting Staff - District

1) Medchal Malkajgiri
METHOD OF RECRUITMENT

Recruitment shall be done by the District Selection committee for the District Health

Society.The District Selection committee shall consist of the following members:
a) District Collector
b) DM&HO

c) Dy. Director, Social Welfare
d) DCHS

e) Any other member decided by
the chairman

Chairman

Member-convener
Member

Member
Member

<!-- page 3 -->

Selections will be done based on the following criteria.

1. For eligible applicants, recruitment will be made by awarding 90% of marks for marks

obtained in qualifying exanmination and 10% marks for ageweightage. After completion
of 18 years, 0.5 marks will be added for completion of every one year maximum 10
marks. Date of notification shall be cut off date of calculating the weightage marks.
(a)

(b)

If more than one applicant scores same marks, then the person with higher age
will be assigned better rank.

With respect to candidate who have done their graduate degree from foreign

countries, the percentage of marks obtained in Foreign Medical Graduates Exam
(FMGE) willbe taken into account and converted to a base of (90%).

2. All guidelines to recruit the contract employees as prescribed by Govt. from time totime
have to be followed.

3. Provisional merit list will be prepared based on the marks obtained in the qualifying
examination,age weightage and displayed fortransparency sake.

4. Provisional selection list will be prepared from the finalized provisional merit ist duly
following the rule of reservations, merit and presidential order according to the
availability of roster points ( the carried forward vacancies are brought forward from

previous recruitments / selections to such vacancies will be made first before the fresh
vacancies) and will be displayed in the District Official Website.

5. Local Reservation (95%) is applicable as per Para-8 of G.O. Ms. No. 124, GA (SPF-MC)
Dept.,Dt. 30.08.2018.

6. The particulars furnished by the applicant in the Application Form will be taken as final,

and data entry willbe processed, based on these particulars only. Therefore, candidates
are to be very careful in submitting the Application Form.

7. The District Selection Committee is not responsible for Incomplete/incorrect application
form and willbe summarily rejected. The information, if any furnished by the candidate
subsequently, in any other format of application will not be entertained by the District
Selection Committee under any circumstances. Applicants should be careful in filling-up
the application form and submission. If any lapse is detected during the scrutiny, the
candidature will be rejected even though he/she comes through the final stage of
recruitment process or even at a later stage.
8. Shortlisted applicants who are in the zone of selection only, will be called for certificate
verification.

9. The appointment for above posts on contract basis is purely on temporary basis for the
period of one year or actual need is seize, whichever is earlier from the date of
commencement of agreement/ or from the date of reporting and is liable to be
terminated at any time without any notice or assigning any reasons thereof. The
contract

period will be extended as per the discretion of the appointing authority.

10. This contract appointment does not confer any right for regular

appointment.

11. They are only eligible for Casual Leaves as per rules per year
and 120 days of Maternity
leave for women without any pay and they are not eligible for
Earned Leave, Half Pay Leave or Commuted Leave and in case ofany kind of Leave like
unauthorized absence
for more than one month, their services will be terminated
without any notice,
12. The temporary services for the above posts on
contract basis do not qualify for any
pensionery benefits.
13. That he/she has to discharge the duties for
above posts in the institution, to which
he/she is posted, to the entire satisfaction ofthethe
superiors and incase of any default,
he/she willbe liable for termination without any notice
14. That he/she has to maintain absolute integrity
and devotion to his/her duties.

<!-- page 4 -->

one month prior notice in
submit
should
he/she
to resign,
13. II the candidate is willing
advance, to the undersigned,
the place of posting to any other place during
16. That he/she will not be transferable from in view of only emergency, or discretion of the
the period of contract. However, keepingevery right to shift his/her services, wherever is
appointing authority, the Employer has
required, for administrative convenience.

17. That during their contract period, all the said original certificates
custody of this office till the date of completion of contract,

will remain under the

l5. That he/ she has to execute an agreement bond in the format on a non judicial stamp
of
Paper Worth Rs.100/- agreeing to the above terms and conditions, from the date

reporting for duty concerned.

19. Special Instructions to the applicants: Applicants are instructed to visit the District

Official Website i.e., https//medchal-malkajgiri.telangana.gov.in/ regularly to

know the latest developments / status of this recruitment and any changes /

modifications / calling of applicants for counseling etc. If the applicant does not see the
website when updates made regarding objections received, provisional seniority

displayed etc., it is not the responsibility of the administration and no applications /
appeal willbe entertained.

20. The Collector & District Magistrate, Medchal Malkajgiri & District Medical & Health

Officer, Medchal Malkajgiri has every right to decrease or increase the number of post
and have every right to postpone or cancel the recruitment at anytime without assigning

any reason thereof

District Medical Health Officer,

Medchal Malkajgiri, District.

4
