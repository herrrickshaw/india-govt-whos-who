---
doc_id: "ebab7b7998c4c3cb"
source_url: "https://cdn.s3waas.gov.in/s3e0ec453e28e061cc58ac43f91dc2f3f0/uploads/2024/06/2024062421.pdf"
ministry: "Jogulamba Gadwal"
title: "TENDER NOTIFICATION FOR EMPANELMENT"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6a2728bec5b6689f"
---

<!-- page 1 -->

Government of Telangana
District Outsourcing Committee
Jogulamba Gadwal.
File: No. A1/OSE/01/2020,

Dt: 22.06.2024

TENDER NOTIFICATION FOR EMPANELMENT,
OF OUTSOURCING AGENCIES.
Sub: DOSC- Jogulamba Gadwal District- Sealed Tenders calling for Empanelment of
Registered outsourcing agencies to provice outsourcing services in various Govt.
Departments in Jogulamba Gadwal District.
Ref: (1). G.O. Rt. No. 4459 Finance Dept. (SMPC),
(2). Note approved by the District Collector – Jogulamba Gadwal Dated: 19.06.2024.

@@@@@@
With reference to above 2nd cited, the District Collector, Jogulamba Gadwal has accorded
permission to Empanel registered outsourcing agencies to serve in various Government
Departments in Jogulamnba Gadawl District for 2024-25.
Accordingly tenders in sealed covers are being called for empanelment of outsourcing agencies.
1).Department (or) Institution calling tenders:- District outsourcing committee - Jogulamba
Gadwal, District Employment Office, F-30/1, IDOC, Gadwal.
2) Date of Publication of Notification:- 24.06.2024
3) Date of Publication of Notification in Newspaper:- 24.06.2024
4) Date of Sale of tender forms :- from 24.06.2024 to 08.07.2024 (Excluding Sundays).
5) Last date of Receipt of Sealed tenders:- 08.07.2024 Time : 3:00pm
6) Timings of sale of Tender forms:
(i) from 24.06.2024 to 06.07.2024 from 10:30 am to 5:00 pm
(ii) On 08.07.2024 : from 10:30 am to 3:00 pm
7) Cost of tender forms: 10,000/- (Rupees Ten Thousand) (to be submitted in the form of DD in
favour of Dist. Outsourcing committee Jogulamba Gadwal.) payable at Union Bank of India,
Nadi Agraharam road , Jogulamba Gadwal District. (Non refundable).
8) Opening of Sealed Tenders:- 08.06.2024, 4:00 pm at V.C Hall , IDOC , Gadwal.
9) EMD:- In the shape of DD for Rs. 5,00,000/- (Rupees Five lakhs Only) in favour of Dist.
Outsourcing committee Jogulamba Gadwal, Payable at Union Bank of India, Nadi Agraharam
road, Jogulamba Gadwal District.( While returning the EMD amount , No interest shall be
paid)
10) Security Bid: One month salary of employees for successful bidder.
11) Turnover: Bidders would have at latest 1 crore (One Crore) turnover in any one financial year
2021-22, 2022-23, 2023-24. (Turnover certificate should be submitted)
12) Experience: The bidder should have experience of having deployed at latest 60 human
Resource in any government, semi Govt. in any one year in last 3 years (2021-22 to 2023-24.)
13) Financial Bid & Technical Bid to be Submitted Separately.

<!-- page 2 -->

ANNEXURES INCLUDED ALONG WITH NOTIFICATION
14) Annexure-I:- Tender Notice
15) Annexure-II:- Tender form (Financial bid for quotation) (Part 1 and Part 2).
16) Annexure-III:- Other terms and conditions
17) Annexure-IV:- Documents should be submitted along with sealed tenders
18) Annexure-V:-Tender – Declaration form.
19) Annexure-VI:- General terms and conditions as per Govt. of Telangana

Sd/District Employment Officer,
Jogulamba Gadwal

Sd/District Collector & Chairman,
District Outsourcing Committee,
Jogulamba Gadwal

<!-- page 3 -->
