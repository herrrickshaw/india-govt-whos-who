---
doc_id: "ebb3f77a2e0a3bd0"
source_url: "https://cdn.s3waas.gov.in/s3e00da03b685a0dd18fb6a08af0923de0/uploads/2020/06/2020061624.pdf"
ministry: "Mahabubnagar"
title: "Expression of Interest for Supplying of Reinforced Plastic Tree Guards – Tender Notice"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a5c738ae06e891fb"
---

<!-- page 1 -->

EXPRESSION OF INTEREST FORM

1. Tender No. and Date:

:

2. Name of the Agency:

:

3. Address

:

4. As listed in the Expression of Interest Schedule-A with the dimensions
furnished therein for execution of Supply of self-supporting plastic tree guard
around the reserve forest blocks.
Sl.
No.

Item of work
Notice inviting tenders for supply of self –
supporting plastic tree guards.
With Specifications

1. Height of the Plastic tree guard – 1800
mm (6 feet)
2. Width of the Plastic tree guard – 1200 mm
(Normally these tree guards are supplied as
a sheet of interwoven plastic filaments and
hence producing a diameter of 375 mm
after folding).
1.

3. Thickness of filament – 4 to 5 mm
4. Joint thickness of filaments – 6 mm
5. Lateral reinforcement supported at
minimum 3 places for effective steadiness.
(However, it will be desirable to have lateral
reinforcement at six places, three vertical
and three horizontal at regular intervals).
6. Mesh gap of 45mm x 55mm
7. Weight of single tree guard – 1.2 Kgs
1. Length of the Plastic tree guard – 1830
mm (6 feet)

2.
2. Width of the Plastic tree guard – 1200 mm
(4 Feet) .

Rate quoted by
the contractor
(in Rs.)

<!-- page 2 -->

3. Thickness of filament – 4 to 5 mm
4. Joint thickness of filaments – 6 mm
5. All reinforcement thick filament (two bars)
thickness – Min 4MM.
6. Regular Mesh Gap Should
7. Mesh gap of 45mm x 55mm
8. Weight of single tree guard – 1.00 Kgs
(Tolerance 5%)

The Contractor hereby informed to quote the rate in the Expression of
Interest form for the supply of Self Supporting Plastic Tree Guards.
I/We agree with the above quoted rate of commission and other rules
and regulations and all statutory obligations with regard to the subject matter of
this Expression of Interest.
I/We agree to executive the contract in accordance with the provisions
of the Expression of interest document.
Place:

Signature:

Date:

Name:
Address:

<!-- page 3 -->

GOVERNMENT OF TELANGANA
OFFICE OF THE DISTRICT PANCHAYAT OFFICER :: MAHABUBNAGAR
Rc. No. DPO/A5/Misc/0081/2020
Expression of Interest Notice & Terms and Conditions
1.1.

Sealed tenders will be received in the office of the District Panchayat
Officer, Mahabubnagar up to 17.06.2020 up to 03.00 PM and the sealed
tenders will be opened by the Committee headed by Additional
Collector, Mahabubnagar on 17.06.2020 at 05.00 P.M. for the supply of self
–supporting plastic tree guards.

1.2.

The contractor shall submit sealed tenders during working hours on
17.06.2020 by 02.00 PM.

Specifications:
1.3.

Height of the Plastic tree guard – 1800 mm (6 feet)

1.4.

Width of the Plastic tree guard – 1200 mm (Normally these tree guards are
supplied as a sheet of interwoven plastic filaments and hence producing
a diameter of 375 mm after folding).

1.5.

Thickness of filament – 4 to 5 mm

1.6.

Joint thickness of filaments – 6 mm

1.7.

Lateral reinforcement supported at minimum 3 places for effective
steadiness. (However, it will be desirable to have lateral reinforcement at
six places, three vertical and three horizontal at regular intervals).

1.8.

Mesh gap of 45mm x 55mm

1.9.

Weight of single tree guard – 1.2 Kgs

DISTRICT PANCHAYAT OFFICER
MAHABUBNAGAR
