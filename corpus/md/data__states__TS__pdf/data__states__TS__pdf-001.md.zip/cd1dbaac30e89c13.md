---
doc_id: "cd1dbaac30e89c13"
source_url: "https://cdn.s3waas.gov.in/s3da4fb5c6e93e74d3df8527599fa62642/uploads/2026/07/17831446123722.pdf"
ministry: "Medchal Malkajgiri"
title: "Alwal PD Gazette-17"
date: ""
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "29cf44e7ea4d9d78"
---

<!-- page 1 -->

THE MEDCHAL - MALKAIGIRI DISTRICT GAZETTE
EXTRAORDINARY
PUBLISHED BY AUTHORITY
J1 .06.2026

MEDCHAL-MALKAJGIRI

No. MMD- |'J

FORMVII
(See 1fi-rule (1) of ntu-25

nntl Section-79(1) of the Act-302.013)

DECLARATION
whereas it appears to the Govemment of Telangana /Collector that a total of
27389,81Sq.Yds land is required in the Alwal Village & Mandal, Medchal-Malkajgiri
District for public purpose, namely, construction of Elevated Corridor from Paradise
Jn. to Shamirpet at ORR ln. on Raiiv Rahadari (SH-01).
Therefore, declaration is made that a piece of land measuling, more or less
29133.01 Sq.Yds of standard measurement under acquisition for the above said project
in the Alwal village & Mandal, Medchal - Malkajgiri District whose detailed
description is as following:

MANDAL: ALWAL

DISTRICT: MEDCHAL-MALKA]GIRI

VILLAGE: ALWAL

sl.
No

Sy
No.

Sketc
h No.

H,No./
Premises

No,

TyPe

of

Title

Typ.
of
Land

under
Acquis

ition

Borewells

Name & Ad&€ss of
the Person lnterested

PIinth
N

in

S

No.

E

Ivpe

l'il"

SqYds

in
Sq.ft

I

1

7

4

2

10

It

12

11
I

13
I

14

15

Function

l

293

/1

L-172

14-25/ 5

Maktha

137

N. Aruna W/o late N
Srihari

Itoact

N.Anup

Subha
293

/1

Rail*ay

Bore

Track

well

,orn.

"I

01

Road

I

2

a Hall

L-173

Functio
n Hall

Maktha
Inam

r.:. .e*na w7o t-ate r.:.
,*
'-' |I
srihari

Road

Nemuri

oPe
14:3s/2 L1-35/ t

16

I

1It.01

Compou
Plot nd waI

<!-- page 2 -->

3

293

/\

L-174

Maktha
Inanl

74-25/ 5

N. Anuradha W/o
Latc N. Srinivas

Road

11-28/6

Pama

N.Anupa

293

L-

/1

174_1

;

293

/1

L-175

L-

291

7

li

/1

't75/ 1

293

L-

/1

29i
/1

1425/ 5

PatLr

14:N/3

Patta

Iioad

r.l-x
/'t0

Iioad

113s/ 2 14-28/s 14-28/1.0

Goud

Iioad

14-35/2 NarayaIr
14-28/ 6
a Coud E

N- lnkshmi Narayana

Ito.td
ll:ntra

N. Srinivas

Maktha
Inanl

.t4-25/

Pa tL)

271

Maktha
Inam

tn kshmi

Coud

376 U

C&

11{X.16

t135/2 11-28/ 5 14-28/ 10

0l

299 02

ll
Opcn PIol
(Entrance

N.Siyanni)

I{oad

230..16

Open PIot

nca

Maktha

5

85d.r 3

RC

N. l-akhmi Namvana
Goud
N. l-akshmi NarayarE

Maktha
Inam

14-211/ 3

14-28/3.
175/ 2 14-35/2

t,176

N Anuradha W/o titc

Maktha

0l

ll

21)

{

Bor

RC

1125/5 Suryaday

Hall

C

industries

10

293

L-

/1

176/1

293

L.

/1.

176/2

293

L.

/1

176/ 3

N Sayarna

Maktl',r

11-25/ 5

Patta

1+25/ 5

Patta

Maktha
Inanr

1+25/ 5

Patta

Maktha
Inanr

l{oad

Inam
N.Sayanna

337

Itoad

Function

606 55

RC
C

11-25/5 11-25 / 5

llall

1209.13

woy

N.Sayanna

1t

14-25/'l 11-28/j

I Iall

Itoad

Side

llal

L4-25/5

1931

I

I1.1ll

't2

rl

29i

L.

/1

176/4

293

/1

L-',tn

N SayaruE

Maktha
Inam

1+25 / 5

11-28/ 2

Patta

l,-unction
Road

I Iall

Bor

part

Makth.
lnanl

N.Dayanand Coud
S/o BalrajCoud

Road

I

11-28/2 14-25/ 5

0l

15,l,6.77

u

11:28/2 't4-28/

Irunction
6

RC

I Iall

892.12

C

Part

Ila)

I{

293

L

/1

177 /1

L.

15

16

1+28/?

Patta

tl

Iload &

1n/2 aulvert
293

1--178

/1

part

Maktha
lnant

Maktha
Inam

1,1-20

N-Dayanand Coud

S/o llalraiGoud
111

Itond

11-28/ 6

Op."

Pnrt

Nala

Copal
Sri Sai
Canesh

301

N.Sayanna

Ro.td

Motors 11-23/1
Part(14-

0l

11-28/ 2

ll
Open
Nala

ll

I

I

797.6
I

I

I

Bor

0l

3227.5/'

tl

25/5)

I noad

77

l,o

106

I

Iload
M. Laxminarayara

1IJ5

L-272

Reddy S/o Buchi

t4/3 / 4/

1.7-5 / 6.

Reddy

Road

01

ll

5
I

1-13-5/ 6,

l9

185

L212/'l

tul Laxminarayana

Patta

1-12'l:13

1189

Iteddy S/o LJuchi
Ited(l),

13/5/
6.

/5

185

t,,
212/ 2

d

plot

12-

(kxmi 74/3/ 4/
Narayan

-.".i

C+1

1203.I9

C+1

.16u1) e

5

a)

& Open
20

Irn

Open

1 12113 / 1,

oP"

tior
Itoad

Op"^
Patt.r

M.Laxninarayana
Red(lv S/o Buchi
Iteddy

plot
Ito,rd

13-

(t-axmi 4/3/4/
Narayan

")

-""11

<!-- page 3 -->

Open

* ,r,i

ll

I

I

2)

M.LaxnnnaraYana
I{eddy S/o Lluchi

l']atta

I_-

185

I

I

plot

13-

(t xmi 14/3/ 4/ 14/3/13_4/5

t{oad

Reddy

f{arayan

M.l-arminarayana
Reddy S/o Buchi
Reddy

Open

1".,1-.'^'

5

la)

plot

212/4

13-

RC

14/4/5

C

13-

(t-axmi
14/4/s
Nalayan

1759.1t9

a)

l

Op"n
plot

M.laxminarayana

l1

L-

185

Reddy S/o Buchi
Reddy

Patta

212/5

Road

13-

13_

(Inxni 14/4/5

14/ 4/5

Narayan

1*"1

a)

ll

M.Laxminarayana
Reddy S/o Buchi

L-

I85

Roddv

712/ 6

Open

:6

1.117.39

14/3,4,5
Reddy

Open

M. LaxminaJayana

L

FI,

1!

plot

Road

Reddy S/o Buchi
Reddy

Patta

212/ 7

13-

oPc

plol

4/3/

(laxoi

4/5

Narayan

Itoa(l

Itoad

Lan
d

Open
M. Shiva Rcddy S/o
Latc Buchireddy

Maktha

I 213

165

Enam

plot
lload

(tnxmi

N_ur

I{oad

14-55.

Narayan
a)

972

plol
27

L.

185

Patta

273/1

1-13

2ll

L-2)1

I85

1/B/N

Patta

R

:q

I--

1lJ5

Enam

Mamidi Anasuya W/o

Maktha
Lnam

I -ate

M. I'rataP ltcc{dY

Roacl

lvlakdra

Late M. PrataP ReddY

L.

185

214 /2

Nursery

Patta

Road

11-52.

lioad

14-52.

I_-215

l)

I-ate M. Pratap Reddy

Road

Mamidi Anasuya w/o

192

I

L-216

open

Maktha

land

Enam

te M. Ptathap ReddY,
Shanker Reddy,
5.M. Padnraja W/o late
cnkat Rcdd

Mamidi. Shanker
Rcddy S/o
BuchiReddy

r85

I 217

land

M. Padrnaia Wo l-ate

Maktha

Venkat ReddY

Covt
Ii32

Patta,

I
18"1

217/1

land

Covl

Maktlla
Enanr

1063.32

01

ll
792 gti

11-52

52.(ope

d
Redd

/B/

orn
plot

Open
Irlot of

(tnxmi

M

Narayan
a)

Road

M. Padmaia w/o Inte
Vcnkat Reddy

Road

Ro.(t

op"
1-13-

Plot of
M

l']lol

Open Plot

Naresh
Redd

oPe

& 1-14-53.

I'lol

Opc" Open Plol

Nurs

Reddy

M,

ery,

Op"n
Plot

Open

Plot ol Plot o{
Naresh Naresh
Reddy Reddy

Open
PIol of

'l

1+53

PIot of
Naresh
Shankar
Reddy

Reddy
Open

Patta,

ll

Bor

Road

14-52.

Op.n
185

Plot

Ofn

Enam

Maktha
Enam

&
Op""

Rcddy ) Narayana

n Spacc)

.Shiva Itcddy,

I)atta

Shctl

14-

2. Laxminarayana ReddY,

oPen
lanrl

Shiva
Reddy

933

Maktha

orary

Open
5
Road(Sh
plot M.
(M.Laxmi

Mamidi Anasuya W/o
I'atta

271/ 1

M. Shiva Reddy S/ o
I-ate BuchireddY

Maktha

Iemp

13-14/3,4,

Mamidi Anasuya W/o

32

I

4

I

ope
1N
Reddy

Plot

N
Reddy

land

l

I

1.1-55

<!-- page 4 -->

35

llu

I

37

til

L217/2

1-13-

Patta,

1/1

Covt

l,-21a

1lr-l

M. Padmaja ryo Inte
Venkat Reddy

Maktha
llnam

Covl

Covt

Covt,

Covt,
Patta

Covt ITl. CovtT S land

I{l-1

li2

Can.'sh I'emplc

Rond

Road

ltoad

1l-55

II
L,\\ I)
Ganesh

lenrple

\

Covt

LANI)

PI()

Llor
01

920.tr

C
RCC
(2) &

HNIWS
Reddy
Itond

RC

u

lanl

CIIMC
I

I\llVS

1. Sandeep Reddy S/o

l-ate Prathap Reddy
2. taxmi Narayana

S/o
tate M. Buchi Reddy
3- Shankcr Reddy
4.Naresh Reddy S/o
tnte Vcnkat Reddy
5. Shiva Reddy,

6. Rama Krishna lteddy

I

S/o I-ate Veera Reddy
. Venugopal Reddy S/o
Late Veera Reddy
M. Srinivas Reddy S/o

}l

183

t.219

I-ate M

trte M.sai Reddy

Opu"

9.Avinash Reddy S/o

305.42

lan(t

I

Iiond

Buchi
Reddy

L-atc Ranga Reddy

Op"n

10.Harsha Vardhan

Plot

12-'t13

Canesh

tl

RCC

l'emple

Iteddy S/o tnte
M.RangaReddy,
1. Muthyam Reddy S/o
L-ate tnxma Reddy
12. Chandra Iteddy S/o
Late Lax u Reddy
l3.Narayan Rcddy S/o
Inte Iaxnra Reddy

l.l.Krishna Reddy S/o
Laxma Reddy
1s.Vecra Reddy S/o
t,axma Reddy
1-721lJ3

L.

113/3,

2't9 / 1

1-12143/ 2

Patta

I'}atta

267

l

l.MuthyamReddy,

t-ate M.

2-Chandra Reddy
3.Narayan Reddy
4. KrGhrla Reddy

Buchi
Reddy

Roatl

Op""

(Solls of lrxrnareddy)

L-ate M.

12-

tJuchi

t43 / 2.

Iieddy

Plot

Bor

t)l

ll

F 1,,,*,'

1.Sai Reddy 5/o

Srinivas Reddy

1-12,

l0

183

t. 224

2. M. Harsha Vardhan

144/ A,

267

1-12115/

^
ll

{2

Iu3

L-

Plot No

220/ 1

15

l']atta

7)

Rond

Vikranr Chow,dari

Ito,id

183

L-2).

Patta

I'atta

to 1't3/ 10

259

12141/ A

12

lM/ i

I'lot
No.45

12-143 / 2

12-129

Rc'ddy

C

RC
C

183t 02

106u lJ6

plot
(M.Lax

mi

12-139

t2-129

'r2139

Plot
No.{5

Ope"

2.Ilxmi Narayana

RC

oPo,

2.M.LaxDri Na-rayana
Reddy S/o Late Buchi
Reddy,
1. M. Shanker Reddy,

183

PlotSai
Reddy

l.Mamidi Shankcr
Itcddy
1-13 / 1-

i-

Op"n

Reddy 5/o Ranga
Reddy
3. M.Avanash Reddy
S/o Ranga Reddy

1,
13/ 1

IJlot of

M
Iledd

t{c
C

opc
Ian
d

2nh rlt

<!-- page 5 -->

.,1

L-2Zl

r lt3

1-12-i39

Ittta

Couri Shanker S/o
Narsimhaiah

267

T

'12-139

Ro.1(l

{l

r83

267

12:135,
1-12'131/ 1,

I,,

183

16

2) M.veera ReddY
3) M.Chandra Reddy

133, 1-

'l) tvl.Muthyam Reddy,
2) M.Veera Reddy

Iratta

224/ 1

3 M.Chandra Rcdd

t-'t3 /.1
TO 113/10

12-133

12,131

Road

/1.

l*

L-225

I ll3
I

.t8

:(l
5l

89

129/^/

225 /1

L.

l8l

135

r2-7v/1 145/A

Roa(l

12-1,15A t2e/ A/

"r29

Road

Naveen
Reddy

Naveen Reddy S/o Bal
Reddy S/o RajReddY

Itoad

Red dy

P.llta

l- l2128/ NR

)73

I'atta

I

I).1tta

I'atta

359

Patta

Pntta

r58

1-12-121

l.-228

1-12-118

1ll3

C

1195.11

l

l'ntta

Patta

12145/ A

L

't-12132 1-',I2-133

Opcn
land

1195.11

Road

1-12-129

ItCC

216.1.112

Road

1-12-130

0l

c+1

6917 olt

01

C+1

9lt2 nl

I

ITOAD

201

I

r83

RC

^/N

ll

Itaghmath Singh s/o

t-ate M.Shank€I Singh
2.Amarnath Singh 5/o

5.t

ll,oz:;

ln)r

1 .

L-227

C

RCC &

226/1

1li,?

RC
12-133

R

NIt

Naveen Reddy S/o lral
It€dd-v S/ o Rai Reddy

{01.28

ll

/ A/ 12-133 129/

Ro.rd

Itoad

5f

,*rrl

&

0l

12-

12Road

l.Prakash Chowdary,
2. Mangilal Chowdary

I

l:

RC
C

NR

1-17-

L-226

181

3tiu3.73

G+2

Bor
12-139

12-

Nt{

NR

t.-

Itcc

C+2
12-

12-

Reddy

129/A/

2 /2

1U3

Mamidi Rama Krishna
Rcddy 5/o Iate Veer

1-72-

t_-

183

I']atta

Reddy,
2. Avinash Reddy S/o
Ranga ReddY

75

l)atta

0l

ll

3

1. Harsha Vardhan

t-12131/A

Bor

12-

l) M.Muthyam ltcddy,
1-12-

12-135

trte M.Shanker SinBh
3.Sudesh Kurnari W/o
I-ate Ravin.ler Singh
a.Deenanath Singh S/o
I-ate Shanker Si

Srinivas Dhamani S/o
late Sathya Narayana

t5

Itoad

Shankar
SinBh Srinivas
Part

Roacl

T. Vijay Ilanuman

72-

Singh

120

12-116

Ito.td

Inclian

Road

Borr
well

lt

&)r

oil

Srlnivas

Geth

lt.

0l
ll

Shankar
Ck)Eda Singh

RC

(

2714.88

G+2

50

r{
]

ry

Ihtta

12-120

L-230

Mangilal Chowdari
S/o Jeev. Itam, Naiu
D€vi W/o Prakash
Choudary

t22

I

Ro,rd

12"I16

lndian Srini!as

oil

Bor
01

C+2

-1579.51

0l

C+'l

1320.1t.1

ll

1-12-

a7

I8l

I_-231

I']atta

1-12-119

Shoba Rani w/o

536

Devender
1. N,Iangilal Chowdari

S/o JL"eva Rarn,
2 Natu Dcvi w/o

plot
53

r83

1.232

No.7 &
1-72-

Prakash Choudary,
3-Gectha Devi

21

Patta

lE/B/

4. hakash Chowdary

NR

39

lll3

L-233

S/o Jeeva Ram

I ,,,"

I'atta

14

I

Navyam Re(ldY

Ilor

118/ 1/ F

Itoad

F/N&

Itoad

l2 r20
ll

Plot
No.7
7-12119

India

'I-12Roacl

118/ 1-

12-t 16

FT/NR

ll

oPr'

I

I

fetrol

Pu-p
1-72-

Plot No. 7

119

Naju
118/1- Devi &
}]F/ NR Prakash
Ehoudary

lndian
IJetrol

I'unlp

1-12-

Roa(t

i*,,1

<!-- page 6 -->

L-1.2-118 / 1,

lrl

t-12118/1/Nn,
L-L1{
t-12t18/ t/ FF

/

1-121. Chetar Chowdary,

2. Deepika Poonanr
,,"*1,,",,.1,,1 chand
choudary,

3 Suresh Chowdary

NR
61

62

183

7-t2Itond

&)r

1lt/ 1/

It(,n(1

l)l

C+l

1b7 7

/NR

Petrol

Pump

Itond
183

119

India

t70

Ro.rd

(r:lat
No.101)

Soma Shaker S/o K

Satyanarayana

SNL Bhatnagar S/o

(l'lat

Bhatnagar

(i lt

lilat
Irlat
Open to
No 102 No.1l6
skv

skv

Op.n

Manoharl,al

Patta

No.l13)

()pcn

skv

llat

Open to

Flat

No.112

sl9

No.11.l

'1296 ]

c+6
7367.12

i(l
1&3

65

183

183

(Flat
No.l1,1)

Clat
No.115)

I'.tta

l'.ilta

Archana ratil

Ragini Kumar. Raiu
Babu Lingam

Patta

Pntta

No.116)

(FIat

No 201)

and

llat

Flat

Spacc

Ope"

No.113

No.'115

Opcn

Corridor
and

Flat

IIrt

Op."

No.114

No.116

Space

Reddy S/o Y. Yadi
Reddy

,,"*1,,*l

l
921 07
I

flnt

Op€n to No 115

Skl

B.Venkateswar ltao

92.1 3

Space

Op"" Corridor

(Il.rt

I

1rJ3

Open

l-lat
No 101

skv

936 7rl
I

I

S/o Narayan Rao &

Op."

Flat

Flat

Sumati B.Rao w/o

skv

No.202

No.216

1303 {

Open Sky

B.Venkateswar Rao
t,8

183

183

(lilat

M.Srinivasa Rao

No.213)

(Ilat

C Srikanth

No.21.t)

Open

Flat

Flat

skv

No.212

No.214

Opcn

Flat

sl9

No.213

l-lat
No 215

Op."

Opon

skv

sky

FIat
No.214

No.216

Road

Road

I

966.t]9
7tl

l8l

(l.lat
no.2f5)

Patta

Cudipati Gopi
Krislma S/o C.Murali
Krishna & Mandava
Ramya W/o Gudipati

r t67.t2l

921 3

Flat

92t.0i
]

Copi Krishna
71

72

1lJ3

181

(I:lat

I'atta

No.2'16)

| ,' u,

Konda.Naveen S/o K
Venu Murthy

lNo.301)
73

7.t

75

7b

l83

I lJ3

Iti3

181

183

7u

1u3

lasti.Radhika w/o

( Flat

No.313)
(Flar
No.31a)

Venkata Satya Prasad

Ihrr.l

(l:lat

M.Shailaja

I',rlla

No.315)

(lrlat
No.316)

itoa(l
Op. n

5kv

oP.n
to

skv
Road

it(rrLl

D Srinivas Iiao

(rlat

Patta

l'alta

Ihrra

Minesh Uttarkar S/o
Sripad Uttarkar

Open

Flat

skv

No.215

1;lat

lilat

No 302 No.315
FIal

flat

No.312

No.314

Skv

qlh 78

Open Sky

1 ro.1

Open Sky

FLrr

r-lil

No.313

No.315

oP.,

llat

skv

No.314

Flat
No.316

Flat

Flat
No.315

Flai

No.402 No.4l6

K.Vidhya liarli w/o

Op""

Prahalad Rao

sb,

FIat
No-412

.l
I

sky

Space

Opon

Flat
No.201

Open

Corridor
& Opcn

I).Pravecn Kumar S/o

No. 401)
(Flat
No. 113)

K.Surekh.l

r.,oz r r

ll

]

92.1

l

921 07

Flat
No.301

936.78

Open Sky

1r0r.l

Flat
No.414

rt6712

<!-- page 7 -->

l'l'"1
181
I

KatiyarS/o Raia Ram
Kat

lNo.4l4)

K-Shankunthnla
(FIat
No.415)

D€viw/o
ana Rao

Sa

sky

op.n

Flat

Flat

Spa.c

No.413

No.4:15

Open

Irlat

Flat

skv

No.41,1

No.416

orn

Flat
No.415

No.401

(Flat
No.416)

S.Vijay S/o S.
ManoharSwamy

Flat

Open

183

(Flat
No.501)

Flat

s:

No.5O2

No.516

Space

Yadlapati.sathwik S/o
Radha Krishna

Flat

Open

Flat

183

(FlatNo

83

No.512

Space

No.51't

lil

1iu

Open
sls,

& Open

Flat
No 513

No.515

,*l

Op.!l

Op."

Flat

L,,,

Si

Spacc

skv

No.514

J*.""

513).

(FIat
No.514)
( Ilal

No.515)
(Flat
No.516).

Pattl

l)atta

I). Pitcheswari

Patta

I'atta

U.RaBhu S/o B Mohan

183

l

I

(Flat
No.613)

1&1

No.614

r8i

R.Siddnrdha

flat

(

Patta

R.Jayachandra

Patta

Khagga. Durga Rao

Ilat

Patta

No.615)

(rlat

9l

181

E.Srinivas

No.616)

ltil
I

1367 t2

,l-

!lat

opcn I Flat

Flat

I

llll

No.

1,,.1
trr.o,
I

92.1.1

No.501

rht
Flat
No 6tl2 No.616

Open

Op"n
skv

FIat
No.614

1367.72

Space

Opcn

Open

FIat

Flat

9271

Spacc

Space

No.6l3

No.615

Op.n

Ope"
sky

Flat
No-61-l

No.616

Open
sky

Flat

Flat

No.615

No.601

72-97

Ito.1d

1319 0r

12-98

Road

.123.13

,r-rr.

i **o

12-98

Road

Spn..
Op.n

Space

Opcn
Spa(e

Iratta

Manju Agarwal

Roa(l

ltl

Shop
No.2'1

Patia

I'atta

K Llala Chari

Rond

Patt.1

Narender Agarwal

Roa(l

Patta

Sanjay Agarwal,
Derpak Agarwal,

Road

Shop
1ii I

No.
21,25,26

,?j
95

13031

FIat
No.612

Space

Parl

I

1.*.4

l-lat

L

921.07

936 78

21,22

I

,).1

916.7S
I

-t-72-91\

Shop

ol

Arnar Singh S/o
Kundan Singh

sky

sky lNo.sls

I

601)

,ra I

Road

Methku.Madhava lO*.
Reddy s/o Bal Reddy sky

Patta

(Flat.No

87

8.,

Rajesh Kumar

927 07

Flat

183

Patta

In,,'
L

lil

r83

I

Ramesh.Chand

I rrtut

183

Shop
No.28,2
9,30

Sand

1-12-9tl

1-12-98
Parl
"t-12-98

Part

1{t1.1.l5

I

, z-,0:

I

I

<!-- page 8 -->

Ccllar
1.K.S Itadhika Rao (Ilat

No. 503)
2.I,.Satya Shekar (FIat

No. 504)
3.

I .Victoria Alexandar

I

( Flat No. s10)

4.Moses Cristopher
Alexandar (Flat No. 511)
Raghu.B ( nat No.515)
6.M.Madhava Reddy
(Flat No. 516)
A.Rai€sh ( Flat No. 60{)
8.Ritesh Tripathi
( FIat No.609)
.P, laxmi ( Flat No.614)
I

l0.Minesh Uttarkar
( Flat No.401)
1l.Ritesh Uttarkar

CLLLAI{

I Il3

i""-,.i

12,94

I<odrl

3505 16

(Flat No.402)
12. M.Shreesha Holla

( Flat No. 4(E)
13.R.C.Katiyar

I

(lilat No.414)
l,l.A.Dcvika
( Ijlar No. 307)

15.B.V.Rao & Sunurh;
(201)

16-A.Satya Dev
( Flat No. 205)

ll

I

17. S.N.L.Bhatn:lgar

97

Conlmo

183

9ll

1U2

( r.lat No.113)
18.u.V.Itan luohan Rao
t No. 103
Common Area

L-236

( SaiSathya

182

Narayana

r82

101

t.-

R.Srinivas S/o Satya

Narayani)

t2a1/
L.
237 /7

1244

/

Iload

102

.{59.1.0b

lioad

1- r2-98

1-12-98

1,',t7-

RC

Part

Part

26/ 13

C

Rond

1-12-9it.

11-55.

Itod(l

12-63

Rod(i

3,221.)7

220

2s6/ 1

tlt2

I00

Rcsidency

R.Sri vas S/o Satya

I'atta
l-12,98

I

l

Ir.rtta

Patta

1.10

.15

Patta

138.3

1-12-87

&89

Ii.ltuknini Dai W/O Late Itoa
Damodhar

R.ltukmini Bai W/O
Late Damodhar

RC

C

Part

d
1-12-

1)8/3
I'art

1"12.11.8/ 3

RC
C

I'arl

12/1/1
lJ4

2t l 9li

oP.

Bor

1,930 72

01

ll

Ro.rd

{16.12 3

plot

I

1. T. Anasuya W/o latc
'182

10r

L-238

8-101/3.
l-12-61.

l',1tta

t37

SathyaNarayana Coud,
2 N1unni dcvi,

Roa
!t

l2n3

12{0

12/'r / 198

RC
C

.{

2,269 15

3. Siddartha

1(II

182

L-239

1243.

l'atta

113

'l'ejpalSingh S/o
Bah,anth Singh
S. I']uspalatha W/o S

105

182

L-2r0

12-60

Srinivas Itao &
Siddarth

K.
1155.

Ito
n(l

11-55

I'art

juna
Coud
K

r2,60

j-.

I

L-241

I'.rtta

727

\l,,llikarjul.t Coud

I

2657.t6

01

lt
11-55

RC
C

1,312 t9

Coud
K

r82

lLrr,

Bor

lioad

Ilo

llika

ad
Couci

AIt
12-60.

h

RC

C

3629.8

<!-- page 9 -->

K.

Malli
r07

Mallikarjuna Coud

l.212

IU2

katu
ud

1. A I'Hema [.atha,

l0s

l- 2,t3

I tt2

Covt

12-36-

1.19

2. S Neela Dcvi

w/o

Srinivasa

K,
Bor

Malikar
12-141

iuna
C,oud
(Part)

AIt

12-61.

I

K.

Ranr,

K

109

,,,1.,*l

Iratta

82

A I) Henu Latha

t2-56

l.BNKeshavRao
r l0

,115.5

l,-24)

182

2. Ram Bhoopal

3.BNAjitnag

C

ll

K,
Ram,

Hema

flth

Coud

Roa

Hemant

d

MaUikai

Keshav una coud
(Part)

AR
h Part

N

Sr har

lr,zsz.n

RC

lvlall ik.r rj
Iload He ant
Keshav
una Goud
h

AR
l)atta

RC
01

I

C

Bor
01

RC
C

0l

king 49*,.99

ll

s.
Neeladev

Bor

i

ll

3,5u1 .15

3716 78

Par

iantl

1. N. Shakunthala Devi

w/o late Sravan
kumar
2. N. Srinivas S/o late

t11

I :16

I Ir2

Open

plot

136

I)atta

Sravan kunlar
3. N. Sridhar 5/o late
Sravan kurnal
4. N. Srihari S/o late
Sravan kumar
1. N. Shakunthala Devi
W/o late Sravan
2. N. Srinivas S/o late

I

I2

ls2

1..217

Ope"
plot

55

Sravan kumar
3. N. Sridhar S/o late

Sravan kumar

Ilo.r

N

tl

Sridhar

N.

sridh
AI

part

N

Sridh.r
parl

1248 /1

N,
Sridhar

Ra r,

Op.,

Keshav

plot

Ilan1,

Keshdv

llor'
01

c-, lz.,r=l

lt

4. N. Srihari 5/o late

Sravan kumar
1. N. Shakunthala Devi

w/o late Sravan
kumar
N-

2. N. Srinivas S/o late
113

I l{2

l-247

/-l

t

Opc"
plot

1248/"r.
114

lii2

L ]{E

L

I]5

67

Patta

I

1248/3,

1.1.t

1-724a/ 2.

lr*lru
11/-

182

t.-250

llE

182

t.-2i1

l1-118

779-2

112lNR

Pd(n

Patt.r

n)

Surekha Durgi w/o
B.Narsing Rao

357

Surekha Durgi W/o
I].Narsing Rao

I'atta
245

119

120

1U2

r82

Patt.r

L-252

t.-251

1-11106,

107,108

N

Sr har

lhr
0t

c+1

Patta

Pattn

262

3905.21

LI

l

Road

1. ti. Narender Reddy,

1-11-

570_27

Iloa(i

Cunashekar

I<oad

l_,2.19

N,

Sravan kumar
Jagan ishakunt Sddhar
Parl
ala Devi
3. N. Sridhar S/o late
Sravan kumar
4. N Srillari S/o late
Sravan kunrar
1. Kalu Rani Choudary,
N,
2- Jagan Mohan sahini
S/o Madhan lrl Sahini Road Shakunl Iiond
ala Dcvi
3. G. Meena W/o

S/o E. Ven-kat R€ddY
2 Mahipal Reddy S/o
l-ate Narshima Reddy

3.I.Va,aramrna W/o
Late Narshima Red4y
1. M.Anuradha W/o
M. Nagender Rao,
2. R Himabindu W/o
Sri Nara Ha Rabu

Itoa
d
11118

/3
Roa

1-1111-111t/-',r

112lNIt
1-11-

l1-1llt/3 112lNR
-l-11-

E,

d
Roa

1-11-106,
112lNR 107, 108

Roa

d

Road

Narende 1l 118/3

112l NR

Ll

Ito,rlt

r Reddy

1-11-

tl-

t-'11-707, 1
112l Nn
108

1-11-

112lNR
P.R

Rao

RC

c
Itc
C

i3{)6 L

978 33

RC
C
RC
C

4$ r4

Crl

7857.68

I

<!-- page 10 -->

121

182

o"*lo*"l,un

l_-254

1-11-r02

r2

166

r.,255

Patta

Patta

43

1.1'.Jayapradha W/o Lat(

llao

S/o t ate l,.ts.Venl(at Rao
4.P Anjlha W/o Irte

I-11-

1-11,
166

I -256

e8lNr{,

rutt

1-11-9.

P.Ramch

Bor
t -11,106

10t/1

P.Ravichander
r23

P,B

P.B.Venlat Rao
Iloir
2. I'.Itamchander Rao S/ o d
tate P.lr.Venkat Rao
3. I'.Raghu Chander Rao

0l

Rao
P. Laxmi

885-1..r7

C

op.

R

narayan Chandra
a
Rao

Lan
d

I rortu I lrr,*'nin,.nyana. l;;Fq;;I;
,ii),
l
| '' l"',I"1:#fl-""'it"
[4"*i:ll
Dilpr€et
culati
1.

RC

tl

Bor

Ccll
0t

u

I 6U12

i

C+3

Singh

2. S.Srinivas S/o

l2l

166

Patta

l

770

11 97

Kristuia Swany

Llaldev

3. E. Pushpa,

Ito,rd

patel

Road

1-10',t41
I

5. K Raieshwari

Bor
125

r66

t. 258

lPall,r

171

Baldev Patel

11 97

Itoad

Road

t-10-1.11

Iloa(l

127

t66

1.,159

i -1196/ 2

1 1,1

0""" o"u'

I

Ramesh Ahuia,
3.Shoba Ahuja W/o
Ramesh Ahuja

1-11128

t66

L 260

96/ A,
1-11-

Rodd

Kcshav
Rao

1-11Pal tir

10t)

RC

t2657.69

L

tl

Rodcl

l.Sunil Ahuja ,
2.Iarun n huja S/o
11-l

C+2
01

I

I

126

,1017.9.r

C+1

4. Vishweshwar Rao

1. K€shav Rao

96/2

2. Sujatha

/R

Kcshav
Rao 1-

1-11l<oad

v Rao

RC
C

Roa(i

11-96/B

e6/ B
Keshav
Rao

BoI
Roacl

01

c.r

ll

2192 1t)

lxrr

z
I

I-11-

t29

166

L-261

1,11-96.

I'atta

Vinodh kumar

Road

96/ 2

lal patel 1-1't-96/ 2

CIIMC
lal

166

L-262

1-11-96.

l'att.l

Patta

1t2

Vasanth tnl Patel

Iioi(i

96/ 2

] ',.r, I c"'
I
lt
t,t 6

167

135

122

5-l

t. 265

Covt

Covt

Roatl

Cov

L,.

old

t

t.-266

Road

Gov
t

L-

Ol(l

2$/1

Iioad

Cov

t,l6

commity &udyoga

lur'L'seva

123.5

c

L-267

8

101/5 &
7-1245

01

b]55..15

ll
Bor

1i)ilets T.G.l.A.

(l'ltrt)

c+1

tlor

hl patel

01
l1

1620.82

C
I

CHMC

Iiord

ttc

She

l'oilets

t 57 2.t

d

T C.I

B.Ram

B.Ranl

A,C

Copal

Copal

lal patel

lt([d

B.Rani

1-8-98.

lioad

G+1

B.ltam lJ.llam
Copat Copal

t-&98.

Itoad

c+2

1-1r,98.

1-&98.

(l'art)

(l'art)

ll.Ram
Copal

Bor

RC
01

C

1939 8

ROND

Covt

Copal

tlt-1.29

l.BNKcshavRao

Covt

1-8-98

t37

Itond

Covl

51

136

SBNI loilet

]i'langana ioint action
Covt

l]-t
l

Covt

old
t. 25-1

7

r33

1-11-96.

Toilets

CIIMC
oki

1.253

Cov
1t2

lal patel 1-11-96/ 2
GI IMC

lal

3200.21

Toilets

1-11130

C+1

1-11-96.

770.06

2. Ram Bhoopal

Covt,
Ijatta

Maktha
Ilnanr

373

Road

Govt

366

I.toa(t

3.BNAiitnag

llor
01

ll

C+1
+1

5633.61

to 53
1-8-116

r8

Cov
t

I -268

1898

I<o.rd

itoarl

(,,S
Mohan
rai)

Ilond

Shc

d

,r*

*

I

<!-- page 11 -->

I li.S Nlohan r.rj,
n9

H0

Cov
t
Cov
t

I,-269

t-8-116

Road

Covt

267

I -270

18-115

Road

Covt

290

2. l).S Itavikishore,

3. P.S.Chittua,
1 I' S.Rajcsh KllnLrr

Road

Road

1&115

1-&98.(rl

D Subadramn1a

Ito,rd

Road

18114

1-8-116

T P Surcsh S/o latc

Ito,1(l

n,,,rn I 1-8-11,1

r,8-115

RC

01

N Ajith)

C

Cfl

01

ltr

L-2n

t

1-8-11.1

Itoad

Covt

271

I ( rurshothan)

S. Vijay

L.G N Sumathi

r0

L-272

Cov
I
t

l -&113

(272/

Road

Covt

121

1)

G)aughter ln L.aw of
Late S V Aniaiah)

Roacl

h I'^rt

Kunl.r

2, S,

Kunrar,

1.14

Cov
t

t.r5

Cov
t

r.16

r-i

Cov
t

272/ 2

1-8-112

Ope"
I

t.-273

L-274

1-8

110/6
I8-111

I.r7

ROAT)

l.rs

1-&
108/ 1A

t,-273

2.B.,ayanthi
3. Padmavathi

Ito.d

1-a-111

I)art

taxmi
Itoad

"-, lr,.rl

01

1-8-11.1
LL

Ii Vishnu

llorr

Murthy

scll

5031.17

01

RC

1161.58

c

,1. Vishnu

Plot

Cov
t

120

|

t.-272/

Cov

Govt

Roa(l

+1

I
t]or

l.llandari Nagamani
1,13

c+1

r)1

M
Vijaya

5711.68

I
Bor

Cov

3362.6-l

1l

Vijay Kumar

Road

Covl

Iload

Covt

B.Sunil kumarS/o
B.Suresh

Govt

l. P V Sharath Kumar
S/o P.S Vikram Kunlar

Road

2t)2

l0.l

ltl

r09

ih
lly

1-811O/6

RC

C

Iloacl

lloa.l

22 tt
Road

Plot No.7

200.2

C+1

llqr11

01

RC
C

3n3.39

01

RC
C

I)art
l -8-

"n0/6

Iino

Bor
11

ROI\D
Il.N.Chandm Swamy
S/o B.Narsimha

Covt

Itoad

1,8

t -8-

110/6

1-8-

Itoad

10{r/ 1

Ptlrt

Open

l,td
lagdesh
war Rao

Bor
Itoad
1l

2181 69
I

1.,Iagdcshwer S/o
Rangaiah

2.Ihota Anil Kufiar
1-t9

1.276

t

Plot
No.1

S/o T. Prabhakar
3 Choleti Naresh S/o

Covt

Rond

oP€
Itoad

Jagdesh JiBJesh 1-8-108/ 1
war Rao w.rr Rao

not

Ch. Naga Bhooshanam
1.lila Srinivas S/oJ
Raiesham

]

Part
150

r

n.za

sa

I

Plot No

181A,8-

rurtu

R1401

of&

nuttn

R1-

I

r51

r52

lll

158

Open

228/'l

PIot

R-229

158

R-230

158

l)urga I'rasad Agarwal

Patta

l{1-

8-R1002

8-Rr 003

Op.n

158

Patta

Charanjeet Kaur

of 8-

W/o ManMohan Singh

R1-

Plot

I

R'32

oPe

223

tn

Patta

72

Ashok Kumar Varma
& Vinod Kumat varma
5/o A.K.Varma

b2

P Iaxmi

of 8R1003.

Patta

15, 8-

R1-i)05

1q).6

I

d

Itoad

[*_.ffxil]

Road

8-R1{)02

fi)2

Plot No

15s

tt-R1{01
8,tt1-{102

G+2

I'art

3939.26

c+1
plot

1t 59 28

Road
1

001

232 PART

plot

L

115

Itoad

001

8,R1l5-1

I

l'art
of 8-

,**

o*

RailLny
plot

001

t0
It-

Road

232

Royal

P.Bharathi w/o'LV.S

Part

furnitur Open plol

Ilao

plot
16

Itoad

€ Plot

No.1sl1

&R1-004.

tlor
01

C+1

3257 -92

<!-- page 12 -->

I)amesh

233
156

l5E

n-233

I'.No 15/1,

Patt.l

&Rl-txr6

7t)

I'}eran L)evi W/o l"lte

M.Bala Krishna

Part
plot No

Iio.1!i

I'lot No
15

Bor
Danresh

ls/7
234

PlotNo
l17

l{-23,1

15 8R1407

I',rlln

Pattn

l uniki.Veflu Gopal

Part

Itoaci

plot

plot

Iioyal
furniturc

no14

Bor

lt

no 15.

Plotno
I3IJ

158

Part

It-215
221.7

14
r59

158

Itoad

plot
Plot No

R-236

Patta

C.Venkateslum

no 14.

236
Itoad

no 13

lo0

r58

l<-237

NO.13

I'}attn

PatLr

1t7 3

Chittaraiah

Merclur

12
pl(,1

I.load

No

foot

Kadanrbari kumari,
( Daughter of late
S.Rad hakristuu)
Pa tLr

211

Plot
no.12

i'"1

15 l-eo

Opticals

cYcle

RC
C

1737.7

RC
C

1492 71

Mart
I)lot No
13, Bal.rji

RC

oil

C

2892_27

Marchant

12

Pattn

Plot No

1. S.Savitha alias

I

R-238

,1".,1,,',,1

Vtaya

12

Traders
Irlot No

237

l. K.rnl.rhiah S/o

1508 9!)

Plot no Plot No14

Pbr

Plot

13 Balaii

t

pnrt

Pattn

C+l

01
11

I

t'lot No

238

2. S.Sunanda alias tlala

part

Kumari, ( Daughter of

l)lot

Late S.Radhakishna)

No12

I

12, Ualaji

Plot No

Mahade 12 Paint
va Mitai
Bandar

3. S.Nave€nChandra

shop

C+2

01

tl

l-"1

( Son oI tate.
S.Radhakrishna)

238
162

158

R238/ 1

105.2

I lanumarL Kacllawa

S/ o Giridarilal

Part

Itoad

I'lol

C+2

SBI

331.r.7{

Nol2
1i2

t<oAL)

163

ITOAD

l'art

lol

1;8 I R-239
I

&R1012

Patnr

Ilatta

27t)

t].S€etharam Reddy

S/o Narayan reddy

of lt-

Road

R1-

plot No
10

0t2

2N

Plot

t6i

t5lt

li 2,r0

No.10,

u-R]-

I'atLi

267

B Sripadri Rao S/o

PAIIT
PI,OT

NO

013

I(ond

Ir-].t1

Plot
No.9

PatLl

126

M.ltadha W/o L-atc.M
Sathyanarayana

PART

I'lot

Road

no9

167

r58

I<-2.12

Plot
No.9

Patl.r

116

.Shoguri SrinivasS/o
tc Satyanarayana,
Sheguri Srikanth S/o
te Sa tya na rayana,
C.Dinesh S/o

242

pnrt

plot

Plot no 9
Uombay It-R l -01 2

I

10
241
158

l']art of
SBI &Rl012

Iload

Plot No
9 rsw
I'aints
Plot No
8/1, Sri
d urga
saniters

CeI

Bor
01

G+2

tl

RC

8/1/ Cr
l6lt

] 5IJ

R,243

Plot No.
8/ 1/ 2,
PIot No.
8/ 2/ Ct'

1. Sanjay Kumar

"l

I

C

tNO
Sri sai

C+l

2513.1t3

Pooja

I,lot No
9 Ilombay

".,1,*,,1

Paints

Sithnram
Plot no.

lt663.7t)

l1

and
a. C Rajesh S/o

I

I

Plot No

Agarawal,
2. Mahcsh Kumar

plot

ngarawal (Sons of
Durga prasad

8/t

8/2

I,lot No

Ilor

9lsw
needs

bakery

paints

0l
1l

.-, ] ^*,

I

<!-- page 13 -->

Vardha

1. Sainandh Yadav S/o

Plot

Ii-2,11

15IJ

No.8

l)atta

Patta

211

2. Srikanlh Yadav S/o

part

Bank

a/7 243

plot No

Part

Roa(1
I

Sadanand Yadav
t75.5

ROAL)

170

2.11

l'lot No

Sadanand Yadav

C+1

5635.E8

8.

ItoAL)
a45

I;1

1- Manik Prabhu,

l..tta

R l.l5 I

153

'-l

l{-

158

172

New

B0r
01

Roa(l
Bakery

&R1-017

I

part
plot 8

2.

Srinivas,

3.

Ravinder,

C+1
tsank
245/11

I

parl
Road

4. Ramesh

245/'l

I{.K Skirl

o""o i

clinic

I ru"t
246

l'atta

I{-2.16

158

t73

Patta

112

Part

G.Yasodha W/o

Narahari

Itoad

It,K

It.KSkin

Itc

clinic

C

Skin
clinic

I)evi

Plot No
6

I

15IJ

171

I

1767 22

1

ll-

103

C.Narsing Itao S/o
I{,K
linic

246 /1

Ilond

child

R.k skin

RC

hospital
pl0l No

clinic

C

I

1332.1-l

5

247
153

175

1tr8

176

R 247

R-2.18

Plot No
5

Patta

Plot. No

325

269

l

v Kamal.Devi & Dr

part

Vidhya Devi

plot
no5

1. P.Ranlesh S/o Babu
Rao, 2. P. DileeP

Kumar 5/o P.Ramesh

Radha
Road

plot

15lJ

177

It-2,19

3

part
Patta

Patta

194

plot
no3

C*2

85.13.8-l

01

RC
C

luro,

Dcvi

plot no 3
Road

219

Plot No

01

plot no 4 skin clinic

248

part

Ror

dcntal

Road

prinivasa

child
shoppin hospital

ll

t"

plotno 5

plot no 2
plot no 4
suresh

Dental
hospital

r{c

medical

C

shop

u.,

I

2A76.97

1. Ramandith Singh

Chabda
2. I{ashmit Kaur
15rl

17ll

It-250

Ptot No 2

87

part

Chabda,

plot
no2

3.Jiivlyoth singh
Chabda

Rond

shop

4. Kirth Kaur s/o l-ate
l

Surender

tl

C

plot no 2
medical

T-tll',*l

251

part of
179

'I5ll

btN

It 251

lioad

t{c

plot no 1 plot no 2

plot no 1
shop

shop

I

1

Plot

No I
1iJo

I5ll

31.7

C. ShilPa D/o T.R

Ravindranath

I

252

part

plot
no1

t<-252

l-'"i

Itoad

Itoad

RC
C

plot no 1
shop

I

114.2-l

ti-R1o67
1. Suglnamma

I

W/o

late [.R VenkatReddy,
181

159

R-253

Plot
No.1

34

2. Jithendar Reddy S/o

Iixma Reddy tnte
3. E Vajramma W/o

late Il.Narcimha Redd

I.toad

Road

Traffic
signal
junction

llor
01

ll

C+1

1095.98

<!-- page 14 -->

1. I] V Malla Reddy,

Iri2

1)9

183

It,25-1

159

&R1-

2. E V Madhusudhan

2

071,

Iteddy S/o t3te E.M

Part

1/6,

1/7,'t/7

Venlet lteddy,

&Rl-

3. Nagalakshrni W/o

068

Plot No

Late E.PKondaReddy
l. D.Bhagi Reddy,
2. Chandra Reddy,
3. V€nkat Reddy S/o

191

1

E. Ual

lE-1

R-256

159

8-R1070

Patt.r

9,1

Brundhav
Road

rs

Tiffins
&lil- an
&R1-06tt

069

I'art

)f 255
&R1-

Bor

Itoad

It1

8-R1J6lJ

Road

1301 8

01

RC
C

1533..13

0l

c+t

2500 78

II

069

Lokcsh S/o Srinivas, l'art
cf 255
2. Veena ryo late
8-tt1,
Ilavi Kumar

C+l

0l

ll

lhr

ti-tt11)71

SlU])IO 8 R1-069

07t)

1&5

Pkn

159

1. E tlhagi Reddy,

302

No2
r86

PART
OF

Maktha
Inam

159

Maktha
Inam

R-258

2. Chandra Iteddy

3. Venkat Iteddy S/o
E. Ual

Iteddy

Patta

256 8-

I{-

IIomeo
Road

clinic & 8-R1{69

RC

0l

C

R1-072

1503 5.r

t)71

Part
o1257
8-R1-

Mcdicai
Road

072

In,r

shop & 8-R1 {171

RC

01

I -{)73

C

tl

283.1.36

1. E.M MohanReddy

159

R,259

8-R1-

Makdu

0n, a-

lnanr

R1{74

281

Patta

S/o Late E Ma aieddy
Part
2. il M Ranga Reddy
ol,259
S/o Iatc E Mallareddy
3. E. Marnatha Reddy

D/o Inte E.M Venkat

8-R1-

Il(r'
R0ad

8 Il] -071 8-R1-071

Itoad

Mega
Medical
BazarS- shop 8-

0l

C+1

718l- 67

0n

Rcddy
I)art
IrilJ

1ii9

R.

8-R',1-

259/ 1

075

It-260

160

Plot No
4 &R1-

I'atta

Maktha
Inanr

KCV Fnshions (Owner
Not identificd)

Patta

I'alta

075/ 3

Maktlla
Inanl

IA1

Patta

Aslanr Kllan S/o
Q,lnur Khan

of
2s9/ 1.
8-Rr 074

R1{75

Parl

I kxol

ot 2r,0

BiryaN
n.rl lF

{t-l<1-

Road

075

r90

R,261

160

Maktha
Inam

l'lot
No1

l5r

Patta

3. ltlanohar P. Rao,
4. Vijay Kumar P.Rao,
5. Jaya Pradha (Sons
anci Daughter of Late.

I'art
o1267

&R1-

C

0l

8-R1-74

RC

C

tl

Ii1476

l l.ryanth P Rao,
2. Llhaskar P. Rao,

RC

R1-071

.t3711.32

Mega
Road

Temple Ba.rar 8-

01

R'l-075

076

C+l

9121.31

I

I'Uabu Rao )
Sree Veera Anjayanam

Maktha
t91

1611

l<-262

femple

l').rlta

Swamy teorple
Hanunlan temple

lnanl
Patta

192

193

160

160

1{-263

,i-26.1

Maktha
lnanr

Plot
No.1

It-265

Plot

]'emple land

Maktha
Inam

I'lot
No.1

No.111,

724

Patta

Plot
I60

M.Shiva Reddy, Sai
baba, .J Mahesh.

I'.itta

Maktha
Inam

Tcmple Iand

lemp

Ito.1d

Ilightec

flotel

h

Bir, ani

ItC

Mall &

C

R1476

Icnrp
lc

lcnrp
lc

Road

lemple Temple
shop
-lenrple

Itoad

shop

'L Kishan I,lao alias
314

Patta

No.106

ot 262

Krishna ltao S/o Late

Gopalltao

265

RC
C

shop

Z,

Temple

hou

shop

Temple

I<oad

1591 t2

771\ /-

C+l

shop

pnrt
r95

tll

lt 266

8 05-0q)

12

Plot No.
111

l.t

-267

32/ 1.9,

8-05{80

I'.ttta

I']atta

6l

I'. Sri ltcddy

Chadalavada Indira

W/o Saryanarayana

f 266
8-5
090

Pi'rt
f 267

Iload

Plot

place

"., I

01

sho 12687 73

&5-079

]

I

&)r
Itoad

*r*

0l
ll

I

<!-- page 15 -->

8-5080

part

ll1

19i

R-268

ll

8-05{79

t 2t8
It-5-

Joseph Rozario CindY

part of

7.

267

Sho

&5-080

P

Road

Roari

.l.u.7l

079

Madigal

8-5-076

n_:l

Otat

Sarla l)evi W/o l-ate

No.1

lhakur l)ass

I

Shop
No. 1, Z

l,-1,',i

flmr

(Shop No.2),
3.Prabhakar ReddY

1,"-l

N

(stilt
Shop
No. 4, 5,

1. M.Su rekha (ShoP No.4

Flat
), No.1

M Maniula (ShoP No 5)
M.Hemalatha (ShoP

Patta

No.5)

6.

I

I

2. Sudhakar

3.

111

r55.03

OI

lt

|

(Shop. No.1),

Floor)
I

stilt

BLrr

l- Suna noli n"ady

ll

(stilt

["'",]
ccllar
I ot78

u shops

(stix

lloor
floor)

200

Roa(l

&

oP'n
Road

open

Placc of a 15-77 .

1,,,,,1

GaFnan &05-78

ll

d

P1a.lr

I

I

lr4Sure kna(ShoP No.a ),

t0l

I'arking

111

Ivl.Henlalatha (ShoP

No

L

(Flat

t0l

201

No.1,
111

Ground

Itcddy W/o NL

It-

11-l

M Nirmala & trxmi
Ranga Sai
I

8

Ashish Iain

Cround

floor
No 1, 2,
3

F'lot no 1

Grou
nd
floor

floor

Iload

Iloor

Floor

(lilat

(Flat

No.5)

No.1)

107

?08

209

11-l

M.llemalatha
(ShoP No.6)

Patt.

Shop
I

ll

First
(FIat
No.2

111

I

First
(Flat
No.3,

l-l I
I

lir$t
floor

C+2

M.Manjula w/o
M.Sudhakar Reddy

Patta

Patta

Paui
I

kl
L__l
l*,,,1

a-5-71,8

,74

H
l*-l

ltoad

Itoad

rl

I

Op"n
Place of 8-O5-n,
8-{}5-78

I

l'"*l
rl

,l

Atl Shops is in Ground
I loor

No4,5,6
(Flat
No.1,

,78

1. Salla RaiiReddy

M Manjula (ShoP No 5)

Cround
floor

111

Ground
floor

Iiloo

a,s-n,8I

.M.Surekha(ShoP No.4 ),

t06

&0i7lt

(Shop. No.r),
2. Sudhakar
(shoP No.2),
3-Prabhakar ReddY
(Shop No.3)

,r,ri

Shop

111

I

Stilt

:l:lat
no2

Cround
I'loo
221

205

l,',**l

Flat no a-o,-n,

Crountl Ground

( Elat
No.2,

269/ 1

Itoad llat no 2

Narendar ltcddY

Crcund
liloor)

269/1

20.1

MoSula I lenulatha
Iratta

(Irlat
No.5,

l1l

l"-l

M Manjula (ShoP No.s)

I'atta

Patt.1

I

lou"a lm",

R. Vi,aya w/o I-ate B.

Flat

Sudhakar ReddY

no2

li.Nimrala W/o

Flat

A.l'rabhakar Reddy

no1

flat
-:l opcn
plot

rkt
I

No.4

Roa(l

Flat.No1

plot

no 2

ltt

8-rn, g
5-79

!-lot no 4
first floor

!

L',r.noI

t_
I

I

uzrz

ll

I

i'-"i

<!-- page 16 -->

(Flat

,r,

210

No.4
I

f-irst
Floor)

1."*1,-*l

Madhdsani Ilamreddy

FIat
No. 5

Flat No

Itord

(r'irst

3 (|irst

I:loor)

F-loor)

I
I

8-177,8-

7.lt orJ

t79

rl

I

(1:lat

,,, I ,,,

No.5

Il. Vraya W/o Latc B.
Sudhakar lteddy

I:irst

floor)
(lilat
2r2

No.1,
S€cond

111

M- Surekha w/o

Balvanth Iicddy

I'loo4

Irlat

no2

l<oad

Flat
No.,l

Ilat.Nol

Flat

oPen

No.3

plot

I:lat
No.4

rht

vrn, s

No.1

,79

E

8-5-n, a-

,79

I

I l,:,r

lilat no 2

u"
/

(FIat

No.2 in

lll

213

lll
lt5

floor)
( r'lat
No.3

Pallay Pratap & Pallay

I']atta

Second

Viiaya Lakshmj

lT-_l

Kathula Sulachana

5c.ond
Floor)

(|lat
No.4
Second

111

W/o K Srinivas Rao

*,,1**l

Su(icsh Jain

Itoad

2snd
Road

Ilat.
No. 5

FIal no
3

plot no 2

plot

I

Road

Flat No3

l,.rlay l,ratap & Pallay

I'.ttta

Second

Vijaya Lakshnn

Iiodd

l-lat

floor)
217

111

2t lr

lll

ltl

1,,,.*l

5-79

Patta

Cornmon Area of Sai
Sadhan Apartment

Patt.r

2)K.Suhasini
3)R.Narcsh

flat

8-177,V

No1

,79

0n-5-76.

!'r Opon
PIot

*l

1)T.lrvanya

plot

oPcn

no 29

plot

I'atta

100

oPe

Iload

lioad

1)Y.Vcnkat Rao
2t9

!

a-+n, &
I

(Flat
No. 5 in

,r,l

2nd floor

I

floor)

2t6

E

l

plot

I

plot
oP('

no 2tl

130

Pbt

Khanrbdn Sug!n,'

lload

oa-5-76.

er Opcn

I'lot

plol

open
22()

tlt

plot
26e/2

(plot
|

No.24 &

"",,1r",,"1

135

S I'ushpa

l(oad

I.loa(i

Ope"
place

24
opcn
221

1

R.
269/ 1

plot
(Plot

I

i"r"l
t"
lpr.,

I'lo
ll.V.Anrarendcr S/o
Venknt S*,amy

P tla

No. 26)
Tota I

er Opcn
Plor

Road

Opon
Plot

aianand

I

redd

29113 0l

This declaration is made alter headng of objecrions of persons interested and
due enquiry as provided U/s 15 of the Act No-30/2013. The number of families likely
to be resettled due to Land Acquisition is Nil.
Mines of coal, iron-stone, slate or other minerals lying under the said land or
any particular portion of the said land, except such parts of the mines and minerals
which may be required to be dug or removed or used cluring the construction phase
of the project for the purpose of which the land is being acquired, are not needed.

plot

l

I

<!-- page 17 -->

AplanofthelandmaybeinspectedintheofficeoftheLandAcquisitionofficer

Hyderabad and in
& Speciai Grade Deputy Collector, Land Acquisition (Industries)'
any working day'
the O/o the District Collector, Medchal-Malkalgiri District on

118

NO

+

Cu^0

AC),
Dy.
LA(Inds), Hy at
Medchal-Malkai giri District.

spl

s

a

atoVc- \o.^d
+o [p

,11 No.

hr- &sPLu

.livd.d.."A

Addl.
Medchal-Malkaj giri District.

District. I

(.'{/t{)

<!-- page 18 -->
