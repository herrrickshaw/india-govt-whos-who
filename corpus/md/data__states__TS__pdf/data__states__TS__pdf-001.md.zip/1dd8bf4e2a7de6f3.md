---
doc_id: "1dd8bf4e2a7de6f3"
source_url: "https://mines.telangana.gov.in/MinesAndGeology/Documents/Circulars/DMG_HSRP_Circular.pdf"
ministry: "Mines & Geology Department, Telangana"
title: "Size 111KB"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f6d10966f11c303e"
---

<!-- page 1 -->

DMG-IT/IT/15/2025-IT

I/1022315/2026

GOVERNMENT OF TELANGANA
DEPARTMENT OF MINES AND GEOLOGY
Circular Memo No.3385773/IT-DM&G/2025 Dated:28-01-2026
Sub: Mines & Minerals-Mining & Quarry Leases, Mineral Dealers,
Temporary Permit holders etc-Fitment of High Security Registration
Plates (HSRP) for all Mineral Carrying Vehicles Registered with the
Department of Mines & Geology-Instructions issued-Regarding.
Ref: Word
Order
No.3385773/IT-DM&G/2025,
Dt:07.01.2026
to
Empaneled Agencies for ANPR Systems.
*****
The attention of all the DDM&Gs and ADM&Gs in the State is drawn
to the subject and reference cited. It has been observed that the
identiﬁcation and monitoring of mineral carrying vehicles operating from
mining & quarry leases, mineral dealer units etc is getting aﬀected due
to the absence of standardized registration plates on the vehicles. This
has resulted in diﬃculties in surveillance, enforcement, permit
validation, and tracking of vehicles involved in mineral transportation.
In order to ensure transparent operations, eﬀective monitoring,
prevention of illegal transportation, and accurate vehicle identiﬁcation, it
has been decided to mandate the ﬁtment of High Security Registration
Plates(HSRP) to all vehicles registered with the Department of Mines &
Geology, Govt. of Telangana.
1. This mandate applies to all mineral carrying vehicles including
lorries, tippers, dumping tippers, tractors etc from leasehold areas,
mineral dealer areas, temporary permit, stockyards etc.
2. All such vehicles must be ﬁtted with High-Security Registration
Plates (HSRP) on both front and rear, as prescribed by the Transport
Department.
3. The responsibility for HSRP ﬁtment and maintenance lies solely with
the
leaseholder,
mineral
dealer,
vehicle
owner/operator.
Registration plates must remain clearly visible, intact and free from
tampering or damage.
4. HSRP details will be veriﬁed at the permit issuance entry to
leasehold areas, mineral dealer areas, temporary permit areas,
stockyards etc and exit, using CCTV, ANPR, and other available
monitoring systems.
5. Vehicles operating without HSRP or with damaged, tampered or
fake plates are liable to be blocked in the ePermit online system. No
further permits or dispatches will be allowed until full compliance.
6. In addition to blocking, Department may impose penalties as
decided from time to time. Repeat violations will attract higher
penalties, including temporary or permanent blacklisting of the
vehicle or operator.
7. The contents of this Circular must be prominently displayed at all

<!-- page 2 -->

DMG-IT/IT/15/2025-IT

I/1022315/2026

leasehold areas, mineral dealer areas, temporary permit areas,
communicated to all transporters, vehicle owners, and lorry unions,
and treated as a mandatory condition for mineral carrying vehicles.
Timeline: All mineral carrying vehicles including lorries, tippers,
dumping tippers, tractors should install High Security Registration Plate
(HSRP) within one month (28.02.2026) from the date of this circular.
In view of the above, the DDM&Gs and ADM&Gs are directed to
take-up awareness campaign to all the leasehold areas, mineral dealer
areas, temporary permit areas, all transporters, vehicle owners and lorry
unions etc and strict instructions be issued to all ﬁeld staﬀ to ensure
absolute compliance without any deviation.

Director of Mines and Geology(FAC)

To
All the Deputy Directors of Mines & Geology in the State.
All the Asst. Directors of Mines & Geology in the State.
