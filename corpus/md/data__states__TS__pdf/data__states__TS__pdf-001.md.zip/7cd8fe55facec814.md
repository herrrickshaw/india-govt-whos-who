---
doc_id: "7cd8fe55facec814"
source_url: "https://www.braouonline.in/Notifications/Workshop/2025_PG_29_1Year_0_Workshops__07-10-2026-BEDODL_1STYR2026.pdf"
ministry: "Dr. B.R. Ambedkar Open University, Telangana"
title: "B.Ed. (ODL) Programme workshop Schedule I YEAR (2026-27 Batch)"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ce6e692917234ffe"
---

<!-- page 1 -->

Dr. RR. AMBEDKAR OPEN UNIVERSITY: HYDERABAD-500 033
Learner Support Services Branch (LSSB)
B.Ed. (ODL) Programme
I YEAR (2026-27 Batch)
Commencement of the programme in all Programme Centres

: September 2026

Workshop - I: During Vijayadashami Holidays

: 12-10-2026 to 17-10-2026 (6 days)

Internship programme - I (School Based Activities)

: 02-11-2026 to 19-11-2026 (15 days)

Workshop -II: During Sankranthi Holidays

: 09-01-2027 to 13-01-2027 (5 days)

S.No
1
2
3
4
5
6
7

Course Code
B.Ed. – O1T
B.Ed. - 02T
B.Ed. - 03T
B.Ed. - 04T
B.Ed. - 05T
B.Ed. – 06AT
B.Ed. – 06BT

Course Name
Philosophical and Sociological Foundations of Education
Learner, Learning and Teaching
School Management, Leadership and Action Research
Information and Communication Technology (lCT) in Teaching and Learning
Environmental and Disaster Management Education
Art and Drama Education
Health, Yoga and Physical Education

• Last date for Submission of Assignments - I in each course

: 11-01-2027

Last date for Submission of school based activities records
: 11-01-2027
(Students Has to do 5 activities in each Course and Submit all the Records of 1st year)
Note: 1. The Candidate is request to download the Assignments, which were kept in the University website
www.braouonline.in
2. 100% attendance during the Workshops, Teaching Practice and Internship Programme is compulsory.
Otherwise the candidate will not allow for submission of Assignments, Records, Theory, and Practical
examinations.

<!-- page 2 -->

Dr. B.R. AMBEDKAR OPEN UNIVERSITY: HYDERABAD
Learner Support Services Branch (LSSB)
Workshop Schedule
B.Ed. (ODL) Programme –Ist Year
Date: 29.09.2026

Dear Student,
Sub: BRAOU- B.Ed. - 1st Year- I and II Workshop for B.Ed. -Scheduled at programme centres – Reg.
***
It is to inform you that the Workshop for the students of B.Ed.(ODL) First year will be held at your

programme centre. Please note that 100%Attendance for the workshop classes is compulsory.
SCHEDULE OF B.Ed(ODL) 1st year - WORKSHOP-I.: 12-10-2026 to 17-10-2026 (6 days)),

Workshop -II: 09-01-2027 to 13-01-2027 (5 days)
Timings 9.30 am to 4.30 pm (With Lunch Break)

DAY
12.10.2026
13. 10.2026
14. 10.2026
15. 10.2026
16. 10.2026
17. 10.2026

1st HOUR
(9.30 to
10.30am)

2nd HOUR
(10.30am
to11.30am)

3rd HOUR
(11.30 to
12.30 pm)

4th HOUR
(12.30 to
1.30 pm)

B.Ed.-01T

B.Ed. 02T

B.Ed.-03T

B.Ed.04T

-do-do-do-do-do-do-

-do-do-do-do-do-do-

-do-do-do-do-do-do-

-do-do-do-do-do-do-

-do-do-do-do-do-

-do-do-do-do-do-

Workshop -II
09-01-2027
10-01-2027
11-01-2027
12-01-2027
13-01-2027

-do-do-do-do-do-

-do-do-do-do-do-

Last date for Submission of 1st Assignments in each course

1.30
to
2.30

5th HOUR
(2.30 pm to
3.30 pm)

6 th HOUR
(3.30 to 4.30
pm)

B.Ed.- 05T

B.Ed.- 06AT

L
U
N
C
H
B
R
E
A
K

-do-do-do-do-do-do-

-do-do-do-do-do-do-

-do-do-do-do-do-

-do-do-do-do-do-

: 11-01-2027

Last date for Submission of school based activities records
: 11-01-2027
(Students Has to do 5 activities in each Course and Submit all the Records of 1st year)
Note: I. The Candidate is request to download and submit the Assignments at programme centre only, (which
were kept in the University website www.braou.ac.in)
2.. 100% attendance during the Workshops, Teaching Practice and Internship Programme is compulsory.
Otherwise the candidate will not allow for submission of Assignments, Records, Theory, and Practical
examinations.

Sd/DIRECTOR (LSSB)

<!-- page 3 -->

Dr. B.R. AMBEDKAR OPEN UNIVERSITY: HYDERABAD
Learner Support Services Branch (LSSB)
Workshop Schedule
B.Ed. (ODL) Programme –Ist Year
Date: 29.09.2026

Sir/Madam,
Sub: BRAOU- B.Ed. - 1st Year- I and II Workshop for B.Ed. -Scheduled at programme centres – Reg.
***
It is to inform you that the Workshop for the students of B.Ed.(ODL) First year will be held at your

programme centre. Please note that 100%Attendance for the workshop classes is compulsory.
SCHEDULE OF B.Ed(ODL) 1st year - WORKSHOP-I.: 12-10-2026 to 17-10-2026 (6 days)),

Workshop -II: 09-01-2027 to 13-01-2027 (5 days)
Timings 9.30 am to 4.30 pm (With Lunch Break)

DAY
12.10.2026
13. 10.2026
14. 10.2026
15. 10.2026
16. 10.2026
17. 10.2026

1st HOUR
(9.30 to
10.30am)

2nd HOUR
(10.30am
to11.30am)

3rd HOUR
(11.30 to
12.30 pm)

4th HOUR
(12.30 to
1.30 pm)

B.Ed.-01T

B.Ed. 02T

B.Ed.-03T

B.Ed.04T

-do-do-do-do-do-do-

-do-do-do-do-do-do-

-do-do-do-do-do-do-

-do-do-do-do-do-do-

-do-do-do-do-do-

-do-do-do-do-do-

Workshop -II
09-01-2027
10-01-2027
11-01-2027
12-01-2027
13-01-2027

-do-do-do-do-do-

-do-do-do-do-do-

Last date for Submission of 1st Assignments in each course

1.30
to
2.30

5th HOUR
(2.30 pm to
3.30 pm)

6 th HOUR
(3.30 to 4.30
pm)

B.Ed.- 05T

B.Ed.- 06AT

L
U
N
C
H
B
R
E
A
K

-do-do-do-do-do-do-

-do-do-do-do-do-do-

-do-do-do-do-do-

-do-do-do-do-do-

: 11-01-2027

Last date for Submission of school based activities records
: 11-01-2027
(Students Has to do 5 activities in each Course and Submit all the Records of 1 st year)
Note: I. The Candidate is request to download and submit the Assignments at programme centre only, (which
were kept in the University website www.braou.ac.in)
2. 100% attendance during the Workshops, Teaching Practice and Internship Programme is compulsory.
Otherwise the candidate will not allow for submission of Assignments, Records, Theory, and Practical
examinations.

Thanking you,
Sd/DIRECTOR (LSSB)
