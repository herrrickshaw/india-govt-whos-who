---
doc_id: "d1da76814dcc5dea"
source_url: "https://horticulture.tg.nic.in/Downloads/2026/Tender/Pre-bid%20minutes.pdf"
ministry: "Horticulture Department, Telangana"
title: "Minutes of the Meeting of Pre-Bid"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ee40b0b3325de5c8"
---

<!-- page 1 -->

Request for Proposal for Selection of Project Management Consultancy (PMC)
Services for Setting up of Irradiation Unit and allied facilities
Tender Notice Number: TGHDCL082024
Response to the Pre-Bid Queries
S.
No

1

Section No,
Clause, Subclause No, Page
No of RFP
Eligibility
Criteria- Section
II, Clause 2.5,
page 13

Technical
Eligibility

Annexure-1
Form 8, page 37

Power of
attorney for
signing the
proposal (for
consortium only)

RFP documentClause 2.13,
page no:16

Validity Period of
Performance
Security (Bank
Guarantee)

2

3

RFP Clause
description

Query / Request

Reply / Clarification

Relaxation of
Technical Eligibility
(Irradiation PMC
Experience) - PMC for
Minimum One
Irradiation Project in
India as PMC
Mentioned as
“Telangana Health
and Diagnostics
Corporation Limited
(TGHDCL)” in place
of “Telangana
Horticulture
Development
Corporation Limited”

The request for
relaxation of the PMC
experience criteria is
not being
considered.

(a) The Project may
run beyond 24
months for reasons
outside the
Consultant's control confirm that the 27month validity is
intended as 24
months of services
plus a 3-month claim
period;
(b) confirm that if the
Project period is
extended, the
revised BG will be
sought only on
mutual consent, as
stated in Clause 2.13,
for the period
reasonably required,
and that no penalty
or invocation will
follow if the extension

(a) The 3 Month
additional period for
BG is for Claim
Period.
(b) No penalty will be
levied on the
Consultant if the
extension is not
attributable to the
Consultant. The
revised will have to
be submitted as per
clause 2.13
(c) The Condition will
be as mentioned in
RFP Document
Clause 2.13

Revised format of the
Annexure-1 Form 8,
Annexed to this
document.

1

<!-- page 2 -->

S.
No

Section No,
Clause, Subclause No, Page
No of RFP

Pg No 20 3.1.2
Scoring Criteria -

4

Page No 5 Point
No 4
5

Page No 6 Point
No 24
6

RFP Clause
description

Query / Request

is not attributable to
the Consultant;
(c) confirm that the
BG will be returned
within 30 days of
Project Closure, as
stated in Clause 2.13,
with Project Closure
taken as the date of
the final milestone
payment (Milestone
5, on the O&M
agency agreement
and final completion
report
PMC for any
It is not specified in
Industrial Project the RFP whether the
of State /
evaluation of projects
Central Govt or
will be based on a
any PSUs or any
particular time period
Private Parties - 4 (e.g., last 5 years, last
Marks for each
10 years, etc.).
Project PMC for
Further We need
any Industrial
clarity whether both
Project of State / completed and
Central Govt or
ongoing projects
any PSUs or any
executed for
Private Parties
Government as well
as Private Clients shall
be considered for
evaluation and
award of marks
Project Cost
Kindly provide details
of the EPC Project
Cost and the
Estimated Contract
Value / Estimated
PMC Fees for the
subject project
EMD – INR
5,00,000/through RTGS
Only

Request the Authority
to permit submission
of a Bank Guarantee
as an acceptable
mode of payment
towards the Earnest
Money Deposit (EMD)

Reply / Clarification

The Work Order /
Agreement issued on
or after 1 April 2016
shall be considered
for eligibility and
evaluation.
Completed projects
only considered for
evaluation and
awarding the marks
(Refer RFP document
page no: 68, point
no: 14 in FAQs)

The project cost
mentioned in the RFP
document is final. The
bidder has to assess
the PMC charges
based on the scope
of work and submit
the bid.
Request not
considered.

2

<!-- page 3 -->

S.
No
7

Section No,
Clause, Subclause No, Page
No of RFP
Pg No 2 Point
No 3

8

Page 54–55 –
Scope of work

9

Page 54, Scope
– Soil/Water
Tests, Page 66,
S. No2- Testing &
investigations.

10

Page 63, Sl. No.
9-

RFP Clause
description
Name of Work

Scope of Work The PMC is
required to
prepare tender
documents,
conduct
technical/financ
ial evaluation
and support
award of civil
and machinery
contracts
Scope –
Soil/Water Tests
and Testing &
investigations

Testing Fee &
expenses

Query / Request

Reply / Clarification

Kindly Confirm the
Name of Work to be
used for preparation
of Technical Forms
and legal documents
which include Power
of attorney, any
affidavits etc.
Kindly clarify that final
approval, bidder
selection, contract
award and
commercial decisions
shall remain solely
with TGHDCL, and
the PMC shall not
bear liability for
decisions taken by
the
Client/Committee.
The PMC scope
includes conducting
soil and water tests,
while FAQ Sl. No. 2
states that the cost of
investigations shall be
borne by TGHDCL.
Kindly confirm that
testing shall be
undertaken through
approved/ NABLaccredited
laboratories at Client
cost, with PMC
limited to
coordination,
supervision, review
and certification
The RFP states that
statutory fees, testing,
third-party
certification,
laboratory testing, soil
testing, utility
charges,
AERB/regulatory
processing fees and

Project Name :
Project Management
Consultancy (PMC)
Services for Setting
up of Irradiation Unit
and allied facilities
All decisions and final
approvals in respect
of the project shall be
issued by TGHDCL.
TGHDCL shall be the
final decision-making
authority for all
matters relating to
the project.

Yes, the role of PMC
include to conduct
the soil, water, any
other tests at NABLaccredited
laboratories of
TGHDCL and the cost
pertaining to those
will be borne by
TGHDCL

TGHDCL will bear all
the statutory fees,
testing, third-party
certification,
laboratory testing, soil
testing, utility
charges,
AERB/regulatory
processing fees and
3

<!-- page 4 -->

S.
No

11

Section No,
Clause, Subclause No, Page
No of RFP

Financial Bid

RFP Clause
description

Submission of
Financial Bid

Query / Request

Reply / Clarification

other out-of-pocket
expenses shall be
borne by the Client.
Kindly confirm that no
such expenditure
shall be required to
be initially funded by
the PMC
Submission of
Financial Bid

other out-of-pocket
expense and will be
directly paid to the
respective authority /
agency.

Submit the Financial
bid as per the
annexure-7 attached
with this document

4

<!-- page 5 -->

Annexure 1
Form – 8 – FORMAT FOR POWER OF ATTORNEY FOR SIGNING THE PROPOSAL
(For Consortium only)
(on a non-judicial stamp paper of Rs. 100 (hundred) and duly notarized)

We, M/s. ______________________________, having our registered office at
________________________________________, being a member of the Consortium
comprising
M/s.
______________________________
and
M/s.
______________________________, do hereby irrevocably constitute, nominate, appoint
and
authorize
Mr./Ms.
______________________________,
son/daughter
of
______________________________
and
presently
residing
at
________________________________________, who is presently employed with us and
holding the position of ______________________________, as our true and lawful attorney
(hereinafter referred to as the “Attorney”) to do in our name and on our behalf all
such acts, deeds and things as are necessary or required in connection with or
incidental
to
the
bid
of
the
Consortium
consisting
of
M/s.
______________________________ and M/s. ______________________________ for Selection
of Project Management Consultancy (PMC) Services for Setting up of Irradiation Unit
and Allied Facilities proposed by Telangana Horticulture Development Corporation
Limited (TGHDCL) (hereinafter referred to as the “Project”), including but not limited
to:
1. signing and submitting, on behalf of our firm, all applications, bids, proposals,
declarations, undertakings and other documents and writings forming part of
or relating to the Consortium's bid;
2. participating in bidders’ meetings, pre-bid meetings, conferences and
discussions and providing information and responses to TGHDCL;
3. representing our firm and, as a member of the Consortium, representing the
Consortium in all matters before TGHDCL in connection with the bid and the
Project;
4. signing and submitting all clarifications, correspondence, representations and
responses required by TGHDCL in connection with the Consortium bid;
5. signing and executing, on behalf of our firm, all contracts, agreements,
undertakings and other documents consequent to acceptance of the
Consortium's bid, including the Agreement with TGHDCL, to the extent
authorized under the Consortium arrangement; and
6. generally dealing with TGHDCL in all matters in connection with, relating to, or
arising out of the Consortium's bid for the said Project and/or upon award of
the Project to the Consortium and/or until execution of the Agreement with
TGHDCL.
AND we hereby agree to ratify and confirm all acts, deeds and things done or caused
to be done by our said Attorney pursuant to and in exercise of the powers conferred
by this Power of Attorney, and that all acts, deeds and things done by our said
Attorney in exercise of the powers hereby conferred shall and shall always be deemed
to have been done by us and shall be binding upon us in all respects.
In witness whereof we, . . . . . . . . . . . . . . . . . . . . . . . . .., The Above Named Organisation
Have Executed This Power Of Attorney On This . . . . . . . . . . . . . . . . . . . . . . . . . . . Day Of
. . . . . . . . . ., 2026.
5

<!-- page 6 -->

For. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
. . . ..
(Signature, name, designation and
address)
Witnesses:
1.
2.
//Accepted//
-------------------------Notarized
(Signature, name, designation and address of the
Attorney)
Notes:
The mode of execution of the Power of Attorney should be in accordance with the
procedure, if any, laid down by the applicable law and the charter documents of
the executant(s) and when it is so required, the same should be under common seal
affixed in accordance with the required procedure. Wherever required, the Bidder
should submit for verification the extract of the charter documents and documents
such as a board or shareholders resolution/ power of attorney in favour of the person
executing this Power of Attorney for the delegation of power hereunder on behalf of
the Bidder.

6

<!-- page 7 -->

Financial Proposal Format
Annexure 7
Financial Proposal - Cover Letter
(On Letter head)
{Location, Date}
To,
The Vice Chairman & Managing Director
Telangana Horticulture Dev. Corp. Limited
Redhills, Hyderabad
Telangana State
Sub : Financial Proposal for Selection of Project Management Consultancy (PMC)
Services for Setting up of Irradiation Unit and allied facilities
Dear Sir / Madam,
We, the undersigned, offer to provide consulting PMC services for Setting up of
Irradiation Unit and allied facilities for TGHDCL, Hyderabad, Telangana in accordance
with your Request for Proposal No. _______ dated [Insert Date].
Our attached Financial Proposal is in accordance with the Data Sheet and the terms
and conditions laid out at various places in the RFP document and Schedule of
Payment. We further accept the schedule of payment as per Clause 7 of Section VII
of the RFP Document. Our Financial Proposal shall be binding upon us subject to the
modifications resulting from Contract negotiations, up to expiration of the validity
period of the Proposal, i.e. before the date indicated in the Data Sheet.
We understand you are not bound to accept any Proposal you receive.
Yours sincerely,

Signature of Authorized Signatory:
Name:
Designation:
Name of Bidder:
Seal of the Firm:

7

<!-- page 8 -->

Annexure 7
Financial Proposal – Form 1 - Price Bid Form
(On Letter head)
Description of Work
Selection
of
Project Basic Cost in INR
Management
GST in INR
Consultancy
(PMC) Total Cost in INR
services as consultancy
firm for Setting up of
Irradiation Unit and allied
facilities
Rupees (In Word) ________________________________________________________________
In case of discrepancy between the amounts mentioned in Figure and Word, lower
of the amount would prevail.
Signature of Authorized Signatory:
Name:
Designation:
Name of Bidder:
Seal of the Firm:

8
