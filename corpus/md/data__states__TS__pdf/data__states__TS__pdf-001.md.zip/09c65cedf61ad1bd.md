---
doc_id: "09c65cedf61ad1bd"
source_url: "https://cdn.s3waas.gov.in/s34e732ced3463d06de0ca9a15b6153677/uploads/2026/10/17926653293489.pdf"
ministry: "Peddapalli"
title: "Ayush notification"
date: ""
pages: 4
method: "tesseract:tel+eng"
script: "TELUGU"
needs_ocr: false
sha1: "1f611bbd8f300a5b"
---

<!-- page 1 -->

తెలంగాణ ప్రభుత్వం
జిల్లా కలెక్టర్‌ కార్యాలయం, పెద్దపల్లి - ఆయుష్‌ శాఖ
పత్రికా ప్రకటన
Ref: NO 2835/E-1/RDDW/PDPL/2026 Date: \\10.2026
విషయం: ఆయుష్‌ శాఖ — జాతీయ ఆయుష్‌ మిషన్‌ - పెద్దపల్లి జిల్లాలో ఆయుష్‌ పబ్లిక్‌ హెల్త్‌ ప్రోగ్రాములను నిర్వహించడానికి,
GOSS, ఆయుష్‌ శాఖ, తెలంగాణ, సికింద్రాబాద్‌ వారి పరిపాలనా నియంత్రణలో పనిచేయుటకు అవుట్‌ఫోర్సింగ్‌ ప్రాతిపదికన
వివిధ కేటగిరిల సేవలను 31/03/2027 వరకు అవుట్‌సోర్సింగ్‌ పద్ధతిలో అర్హతగల అభ్యర్థుల నుండి దరఖాస్తులను
ఆహ్వానిస్తున్నాము.
ఖాళల వివరాలు: ఆయుష్‌ మెడికల్‌ ఆఫీసర్‌ (Medical officer) - 03, ఫార్మసిస్ట్‌ (Pharmacist)-1 -, సైకోఫోషల్‌
కౌన్సెలోర్‌ (Psychosocial Counselor)-1, యోగా ప్రొఫెషనల్‌ (Yoga Professional) -1.
Vacancy & Qualification Details
SLN Name of the Post No. of Qualification
0. & Remuneration: Posts
క్షే AYUSH Medical Officer 03 Must possess a Degree in Ayurveda or Unani or
Rs.40,000/- Homoeopathy or Naturopathy system awarded by a
University in India established or incorporated by or
under central Act or State Act or Provincial Act or an
institution recognized by the University Grants
Commission or any statutory Board of the State
Government after having undergone a regular course
of institutional study in the respective systems , both
in theory and practice for a period not less than 4 4
years duration in a teaching institution recognized by
the university or state government with one year
compulsory internship.
2 Pharmacist 01 i) Must possess any of the following qualifications:
Rs.15,000/-
a. D Pharmacy
b. B Pharmacy
c. Pharma D
ii) Must be registered with the Telangana Pharmacy
Council

<!-- page 2 -->

తెలంగాణ ప్రభుత్వం
జిల్లా కలెక్టర్‌ కార్యాలయం, పెద్దపల్లి - ఆయుష్‌ శాఖ
SI.N Name of the Post No. of Qualification
0. &Remuneration: Posts
ic) Psychosocial 01 Must possess a Post Graduate Degree in Master of
Counselor (on Call) @ Social Work (MSW) awarded by a University in India
Rs.500/- per session & established or incorporated by or under Central Act or
atleast 200 visits in a an Institution recognized by the University Grants
year (on Call) @ Commission.
Rs.500/- per session &
atleast 200 visits in a
year
4 Yoga Professional 01 Must possess any of the following qualifications;
Rs.28,000/- : గ్‌
i. Must possess a Degree in Naturopathy system
awarded by a University in India established or
incorporated by or under central Act or State Act
or Provincial Act or an institution recognized by
the University Grants Commission or any
statutory Board of the State Government after
having undergone a regular course of institutional
study in the respective systems , both in theory
and practice for a period not less than 4 14 years
duration in a teaching institution recognized by
the university or state government with one year
compulsory internship,
ii, Must possess a ‘Diploma in Naturopathy and
Yogic Sciences’ awarded by a University in India
established or incorporated by or under central
Act or State Act or Provincial Act or an institution
recognized by the University Grants Commission
or any statutory Board of the State Government.
అర్హతలు, వయోపరిమితి మరియు దరఖాసు విధానం
* _ఎయోపరిమితి: పైన సూచించిన ఖాళిలలో పనిచేయుటకు అర్హత కలిగిన అభ్యర్థులు 18 సం|| నుండి 44 సం|| వయస్సు
(SCs/STs/BCs/EWS 5 సం|| Ex-Service Men 3 %o| |., అంగవైకల్యము ఉన్నవారికి 10 సం! |ల మినహాయింపు) కలిగి
ఉండాలి.
* అవసరమైన సర్టిఫికెట్లు: తగిన విద్యార్హత సర్దిఫికటట్టలో దరఖాస్తుదారులు కుల ధృవీకరణ పత్రము, లోకల్‌ స్టేటస్‌ (1వ
తరగతి నుండి 7వ తరగతి) స్కూల్‌ స్టడి సర్జిఫికెట్‌, పాస్‌పోటోను దరఖాస్తులో జతపర్చవలెను.

<!-- page 3 -->

తెలంగాణ ప్రభుత్వం
జిల్లా కలెక్టర్‌ కార్యాలయం, పెద్దపల్లి - ఆయుష్‌ శాఖ
దరఖాస్తు చేయు విధానం
a) దరఖాస్తు పారమ్‌లు మరియు సూచనలను పెద్దపల్లి జల్లా అధికారిక ఎబ్‌సైట్‌ నుంది డౌన్‌లోడ్‌ చేసుకోవచ్చు.
b) నింపిన దరఖాస్తు ఫారమ్‌లను నేరుగా లేదా రిజస్టర్డ్‌ పోస్ట్‌ ద్వారా కలెక్టర్‌ & జల్లా మేజస్ట్రేట్‌ కార్యాలయం, పెద్దపల్లి జల్లా
వారికి సమర్పించాలి. నిర్ణయించిన గడువు తేదీ తర్వాత వచ్చే దరఖాస్తులను తిరస్కరించడం జరుగుతుంది. పోస్ట్‌ ద్వారా
జరిగే జాప్యాలకు జిల్లా ఎంపిక కమిటీ బాధ్యత వహించదు.
0) దరఖాస్తు ఫారమ్‌లో పాటు So సర్జిఫికెట్ల సెల్ఫ్‌-అటెస్టెడ్‌ జిరాక్స్‌ కాపీలను జతపరచాలి:
* పదవ తరగతి (SSC) లేదా తత్సమాన పరీక్ష సర్టిఫికెట్‌
* ఇంటర్మీడియట్‌ లేదా 10+2 పరీక్ష సర్జిఫికెట్‌
© అర్హత పరీక్ష పాస్‌ సరిఫికెట్‌
= అన్ని సంవత్సరాల అర్హత పరీక్ష మార్క్స్‌ మెమోలు
* బోర్డ్‌ ఆఫ్‌ ఇండియన్‌ మెడిసిన్‌ రిజస్ట్రేషన్‌ సర్జిఫికెట్లు (పీజీ అర్హత మరియు మెడికల్‌ ఆఫీసర్‌ పోస్టుల కోసం ఆయుష్‌ డాక్టర్లకు)
© తెలంగాణ పార్మనీ కౌన్సిల్‌ రిజస్ట్రేషన్‌ సర్దిఫికెట్‌ (ఫార్మసిస్ట్‌ పోస్టు కోసం)
= సంబంధిత తహశీల్దార్‌ / MRO జారీ చేసిన లేటెస్ట్‌ కుల ధృవీకరణ పత్రం (Caste Certificate)
* 4వ తరగతి నుండి 10వ తరగతి వరకు HE సర్జిఫికెట్లు మరియు ప్రైవేట్‌ స్టడి అయితే సంబంధిత తహశీల్దార్‌ / MRO నుండి
రెసిడెన్సీ సర్టిఫికెట్‌
© PH కోటా కింద రిజర్వేషన్‌ కోరే అభ్యర్థులకు సంబంధించిన PH సర్జిఫికెట్‌
+ ఎక్స్‌-సర్వీస్‌మెన్‌ కోటా కోరే అభ్యర్థులకు సంబంధించిన తగిన ధృవీకరణ పత్రాలు
+ దరఖాస్తు ఫారమ్‌పై అంటించిన 1 పాస్‌పోర్ట్‌ సైజ్‌ ఫోటోగ్రాఫ్‌
© అక్నాలెడ్డ్‌మెంట్‌ కార్డ్‌ (Acknowledgment card)
ఎంపిక విధానం:
1. అర్హత పరీక్షలో సాధించిన మార్కులు, వెయిటేజీ మరియు రూల్‌ ఆఫ్‌ రిజర్వేషన్‌ (ROR) ఆధారంగా ఎంపిక జరుగును.
2. మెరిట్‌ లిస్టు ఇదే ఎబ్‌సైట్‌లో ప్రమరించబడును.
దరఖాస్తు సమర్చణ వివరాలు:

<!-- page 4 -->

తెలంగాణ ప్రభుత్వం
జిల్లా కలెక్టర్‌ కార్యాలయం, పెద్దపల్లి - ఆయుష్‌ శాఖ
* పైన తెలిపిన పోస్టులకు సంబందించి దరఖాస్తులు స్వీకరించు తేదీలు. 22,23,24,26,27. అక్టోబర్‌ 2026 తేదీలలో జిల్లా
వైద్య మరియు ఆరోగ్య శాఖ అధికారి, పెద్దపల్లి గారి కార్యాలయంలో ఉదయం 10.30 గం|| నుంది సాయంత్రం 5.00 గంటల
BEL న్వీకరించబడును. తు A/c NO! 4543.9 749 079
* అప్లికేషన్‌ ఫీజు: రూ. 300/- చొప్పున డి. డి ని GOVT.HOMOEO DISPENSARY DHARMARAM గారి పేరున తీని
కార్యాలయంలో సమర్శించాలి.
బతక SMedigal Officer ప్రాంతీయ డిప్యూటీ BOK5, ఆయుష్‌ శాఖ,
పెద్దపల్లి. జిల్లా తం వరంగల్‌, మరియు కన్వనర్‌-జిల్లా ఎంపిక కమిట్‌
dose చేవాషహాదాలఅదూళ mag చక న ముం వత్రికల SOR,
89 G9 DIAS olin, SSI గార జలా IGS పొదువడుతుద $08
