---
doc_id: "7aa1cf64dbd5ed2a"
source_url: "https://cdn.s3waas.gov.in/s31c383cd30b7c298ab50293adfecb7b18/uploads/2026/10/17914417485841.pdf"
ministry: "Khammam"
title: "2)Notification for Applications are hereby invited to fill up the  (99)  vacant posts in various categories under (NHM) on contract/Out-sourcing basis, by the Khammam District Selection Committee-click here"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "288bf98eb9adf5e0"
---

<!-- page 1 -->

-GOVERNMENT OF TELANGANA
OFFICE OF THE DISTRICT MEDICAL & HEALTH OFFICER:; KHAMMAM
Rc.No E1/3682/2026, Dated. 07/10/2026
NOTIFICATION No.03/2026

Guidelines:
I.

2.

1.
Applications are hereby invited to fill up the (99) vacant posts in various
categories under (NHM) on contract/Out-sourcing basis, by the Khammam District
Selection Committee headed by the District Collector & District Magistrate from
the eligible candidates. As per the details enclosed in the District domain
(https://khammam. telangana.gov.in). W.e.f. 08.10.2026 to 13.10.2026.
Selection shall be done as per the following priority

1) Age:
The minimum age is 18 years and the maximum age is 44 years in terms of (Rule12(1) (a) (v) of Telangana State and Subordinate Service Rules 1996). The minimum and
maximum age shall be reckoned as on 01.07.2026 with the following relaxations
allowed for reckoning the maximum age limit as per rules in force:
1. For S.Cs., S.Ts & BCs & EWS Relaxation of (05) years.
2. For Ex-service men relaxation of (3) years and length of service in armed forces
3. (Applicable only for the posts of Medical Officers)
4. For NCC (who worked as Instructor in NCC) relaxation of (3) years
and length of service in NCC
5. For Physically challenged persons relaxation of 10 (ten) years.
2. Selection nn Merit Basis and based on the following criteria:
1. Merit Lists shall be prepared separately for each of the categories of posts.
2. Total marks are 100 of which 90 marks will be allotted basing on the marks
obtained in qualifying examination and 10 marks will be awarded for the age.
Weight-age for age will be reckoned from 18 years of age of the candidate. 0.5
marks will be awarded for one completed year of age with a maximum of 10
marks. The age will be reckoned as on 01-07-2026. (Example 1. If a candidate
completes 20 years as on 01-07-2026, he/she will be awarded 1.0 mark; Example
3. If a candidate completes 30 years of age as on 01-07-2026, he/she will be
awarded 6.0 marks; Example 3. If a candidate completes 38 years of age as on 0107-2026, he/she will be awarded 10.0 marks).
4. Merit list will be prepared based on the marks obtained with above criteria and
displayed on Official website of the concerned District Collector, for transparency
and also for calling objections.
5. Selections list will be prepared from the finalized merit list duly following the Rule
of Reservation (RoR) and Presidential Orders and also SC-ST reservation rules.
6. The Selected candidates shall maintain the Headquarters.
7. These positions are not transferable.

<!-- page 2 -->

3. Educational qualifications
No of
POSTs

Zone/
Multi
Zone

Name of the Post

1

OBG Specialist

1

Rs. 1,00,000/-

2

Anesthetist

1

Rs. 1,00,000/-

3

Urologist

1

Rs. 1,00,000/-

4

Pathologist

1

5

Pediatrician

6

Pediatrician

7

-

8

Physicians - MBBS
/ MD

9

Physicians - MBBS
/ MD

10

GDMOs

11

Multi
Zone- I

2

Rs. 1,00,000/Rs. 1,00,000/-

Qualifying Examination pass certificate
concerned Degree in PG

0

MLHP /CH/ MO
(PalleDawakhana)

Qualifications

Remuneration
(Per Month)

SL.

Rs. 1,00,000/-

2

Rs. 52,000//
Rs. 72,850/Rs. 52,000/Rs. 72,850/-

1

Rs. 52,000/-

36

12

Senior Dots plus
TB HIV Supervisor

1

13

-

0

14

Staff Nurse/
Nursing Officers

15

ANM

16

2nd ANMs

17

Lab Technician

14

18

Pharmacist

19

MBBS
(MULTI
ZONE- 1)

ZONE- IV

MBBS/ BAMS/ BSC (N), Who have
B.Sc.(N)/GNM Completed from the
academic year 2020 Before., should have
completed (6) months bridge programme in
community Health (CPCH)

Rs. 40,000/Rs. 29,900/-

1. Graduate
2. Computer Course (Minimum (2)
Months)
3. Permanent Two Wheeler driving
Licence & should be able to drive two
wheeler and at least (2) years of work
experience under RNTCP/ 5 years’
experience in any public health
Programme in a supervisory capacity .

Rs. 33,750/-

-

ZONE-IV
24

B.Sc. (Nursing)/ GNM

11

MPHW(F) Training

Rs. 29,900/Rs. 27,300/-

Rs. 27,300/-

MLT Vocational (With Apprenticeship) 0r
B.Sc-MLT

Rs. 27,300/-

3

D. Pharmacy / B Pharmacy

Rs. 27,300/-

Psychologist

1

P.G. Degree in Psychology

Rs. 22,750/-

Total

99

ZONE- IV

<!-- page 3 -->

4. Application Fee:
The prescribed application fee shall be paid through Demand Draft (DD) drawn in
favor of the “District Medical & Health Officer, Khammam”, payable at Khammam, and
the original Demand Draft shall be enclosed along with the duly filled-in application
form as per the following structure:
SL.

Designation

Remuneration
(Per Month)

1
2
3
4
5
6
7

OBG Specialist
Anesthetist
Urologist
Pathologist
Pediatrician
Pediatrician
Physicians - MBBS /
MD
Physicians - MBBS /
MD
GDMOs

Rs. 1,00,000/Rs. 1,00,000/Rs. 1,00,000/Rs. 1,00,000/Rs. 1,00,000/Rs. 1,00,000/Rs. 52,000/- /
Rs. 72,850/Rs. 52,000/Rs. 72,850/Rs. 52,000/-

11

MLHP / CHO / MO
(Palle Dawakhana)

Rs. 40,000/Rs. 29,900/-

36

12

Senior Dots plus TB
HIV Supervisor

Rs. 33,750/-

1

13

-

-

-

14

Staff Nurse/ Nursing
Officers

Rs. 29,900/-

24

15
16

ANM
2nd ANMs

Rs. 27,300/Rs. 27,300/-

11

17
18
19

Lab Technician
Pharmacist
Psychologist

Rs. 27,300/Rs. 27,300/Rs. 22,750/-

14
3
1

TOTAL

99

8
9
10

POSTs
1
1
1
1

FEES AMOUNT THROUGH
DD IN FAVOR OF DM&HO

Rs: 2500/-

2
2

MD- Rs: 2500/MBBS- Rs: 1500/-

1
MBBS- Rs: 1500/BAMS- Rs: 1500/B.Sc Nursing/GNM(CPHC)Rs: 1000/B.Sc Nursing/ GNMRs:1000/-

Rs: 500/-

5) How to Apply:
I.

Application forms along with instructions can be downloaded from the official
web site of the. W.E.F. 08.10.2026 to 13.10.2026

II.

The downloaded application shall be filled by the candidate, duly enclosing the
required copies of certificates and should be submitted in person or through
registered post to the O/o District Medical & Health Office, F1, I.D.O.C, V.
Venkatayapalem, Khammam, last date of application submission is 13.10.2026 till
5.00 PM. Applications which are received after due dates will be summarily
rejected. District Selection Committee is not responsible for postal delays.

<!-- page 4 -->

6).

Self-attested copies of the following Certificates should be enclosed along with the
Application form:

1

S.S.C/Dated of Birth Certificate issued by the Competent Authority of the
Government, for proof of age.
Intermediate or 10 + 2 examination.

2
3
4
5
6

8

Qualifying Examination Pass Certificate.
Marks Memos of all the years (qualifying examination)
Registration Certificates of respective Councils
Latest Community Certificate/EWC Certificate/Ex-Servicemen/NCC/Physically
Handicapped, whichever is applicable, issued by the Competent Authority
Study certificate for the years from 4th class to 10th class and in case of Private
study residence certificate from the Tahsildhar /MRO concerned to be submitted.
PH certificate in respect of candidates claiming reservation under PH Quota.

9

Relevant certificates in respect of candidates claiming Ex-service Men Quota.

10

Registration Certificate from the concerned Medical Council/ Nursing Council/
Para Medical Board / Other relevant authority.
1 Photograph duly pasted on the application form.

7

11

7) Rule of Reservation:
I.

II.

III.
IV.
V.

Rule of Reservations in respect of Community, Disability, Ex-Service Men/Women
shall be strictly observed as ordered by the Government of Telangana from time
to time.
33 1/3% reservations for women will be applicable as per the orders issued by
Government in G.O.Ms. No.3 Dept for Women, Children, Disabled & Sr. Citizens
(Prog.1) dated 10.02.2024 and in GO.Ms.No.35, Genl.Admn. (Ser D) Dept.,
dated 13.02.2024
The Rule of Reservations to local candidates is applicable as per the Presidential
order and also SC-ST reservation rules.
The districts should continue the existing Roster
The vacancies for the posts mentioned in G.0.68, falling in Scheduled Areas should
be filled exclusively with the Local Scheduled Tribes.

08) General Information to the candidates:
1) The District Collector reserves the right to change/modify/cancel the selection
process at any time during the process and the decision of the District Collector
will be final and binding.
2) The Mode of Appointment is on Outsourcing basis or Contract basis for a period
of 1 year or till the actual need ceases whichever is earlier.
3) No TA/DA will be paid to the candidates for attending the interviews.
4) Appointees will work under the overall administrative control of CH&FW and
MD, NHM.
5) The termination notice shall be (30) days period from either side.

<!-- page 5 -->

6) Candidates selected under Outsourcing mode shall be appointed through
Outsourcing Agency.
7) The posts notified are not permanent/regular Government posts and purely
temporary
8) The Panel of Candidates will be utilized for future vacancies, until a period of one
Year from the final date of Selection of Candidates, in this Notification.
9) The selected candidates will be intimated through email/official communication.
10) The selected candidates may have to perform tours.
11) Their performance will be evaluated from time to time and also the same will be
considered for Extension/Termination of their service, in case of future
requirements.
12) The employment is subject to disciplinary/codal rules and in case of any deviation,
employment is liable for termination

District Medical & Health Officer
Khammam
