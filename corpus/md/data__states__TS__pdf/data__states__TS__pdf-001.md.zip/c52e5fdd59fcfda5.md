---
doc_id: "c52e5fdd59fcfda5"
source_url: "https://industries.telangana.gov.in/Library/2015INDS_MS77.pdf"
ministry: "Industries and Commerce Department, Telangana"
title: "G.O.Ms.No.77-Operational Guidelines-T-IDEA"
date: ""
pages: 79
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c6c252e398858eab"
---

<!-- page 1 -->

GOVERNMENT OF TELANGANA
ABSTRACT
Industrial Policy – Incentives for setting up of New Industrial Enterprises in Telangana State– T-IDEA
(Telangana State Industrial Development and Entrepreneur Advancement) Incentive Scheme 2014 –
Operational Guidelines for implementing the Policy – Issued.

G.O.MS.No. 77

INDUSTRIES AND COMMERCE (IP & INF) DEPARTMENT
Dated: 09/10/2015
Read the following:-

1. G.O.Ms.No.28, Industries & Commerce (IP&INF) Dept. dated 29.11.2014.
2. From the Commissioner of Industries, Telangana State, Hyderabad Letter
No. 30 /2014 /3654-1, Dated: 18/03/2015.
3. G.O.Ms.No.62, Industries & Commerce (IP&INF) Dept. dated 08.09.2015.
******
ORDER
In the G.O. 1st read above, Government have issued orders for extending incentives/benefits to all
eligible new industrial enterprises set up in the State except in the Municipal Corporation limits of Greater
Hyderabad Municipal Corporation excluding existing Industrial Estates/Parks, Industrial Estates notified/ to
be notified and commence commercial production on or after 01/01/2015 but before 31-03-2019 under TIDEA (Telangana State Industrial Development and Entrepreneur Advancement) Incentive Scheme 2014.
However, the Industrial Enterprises located in Sanathnagar, Azamabad, Chandulal Baradari and Kattedan
Industrial Estates of Hyderabad and Rangareddy Districts are not eligible for any incentives/concessions.
Projects involving substantial Expansion / Diversification of existing industries in the eligible lines of
activities are also entitled for benefits offered under the policy.
2.
The Commissioner of Industries, Hyderabad in the references 2nd read above, has submitted
Operational Guidelines for implementation of T-IDEA (Telangana State Industrial Development and
Entrepreneur Advancement) Incentive Scheme, 2014 for approval of Government.
3.
In the G.O.3rd read above, the Government have notified the ineligible list of Industries/ Activates
under T-IDEA (Telangana State Industrial Development and Entrepreneur Advancement) incentive Scheme,
2014.
4.
Government, after careful examination of the matter, hereby issue the operational guidelines under TIDEA (Telangana State Industrial Development and Entrepreneur Advancement) Incentive Scheme, 2014 as
appended to these orders. Government have also considered that the time of six months period for filing
claim applications from the date of issue of operational guidelines for existing Enterprises/Industries which
have already commenced commercial production with effect from 01.01.2015. In case of all other
Enterprises/Industries commencing production after issue of operational guidelines claim applications can be
submitted as per the time limit prescribed in the operational guidelines.
5.
The Commissioner of Industries, Hyderabad shall take necessary further action in the matter
accordingly.
(BY ORDER AND IN THE NAME OF THE GOVERNOR OF TELANGANA)
ARVIND KUMAR
SECRETARY TO GOVERNMENT & CIP
To
The Commissioner/Director of Industries, Telangana, Hyderabad.
The Vice Chairman & Managing Director, TSIIC, Hyderabad
The VC & Managing Director,, TSIDC, Hyderabad.
The Managing Director, Telangana Pradesh State Finance Corporation, Hyderabad.
Copy to:
The Finance .(EBS.VII) Department
The Revenue (CT/LA/Registration) Department.
The Irrigation & CAD (Reforms) Department
The Energy Department.
PTO
::2::

<!-- page 2 -->

The LET & F (Employment) Department.
The Law Department.
The Scheduled Caste Development Dept.,.
The Tribal welfare Dept.,
The Y.A. &T.C. Dept.
The Accountant General, Hyderabad
The Convener, State Level Banker’s Committee, Andhra Bank Head Office, Secretariat Road, Saifabad,
Hyderabad - 500 004.
The General Manager, Small Industry Development Bank of India, (SIDBI), Hyderabad.
The Pay and Accounts Officer, Hyderabad
The Director of Treasuries and Accounts, Hyderabad.
All District Collectors through Commissioner of Industries, Hyderabad.
All Heads of Departments through Commissioner of Industries, Hyderabad.
All Govt. Companies/Corporations through Commissioner of Industries, Hyderabad.
The P.S. to Additional Secretary to Chief Minister.
The PS to Minister for Industries.
The P.S. to Chief Secretary to Government.
All Private Secretaries to the Ministers.
All General Managers, District Industries Centre through Commissioner of Industries, Hyderabad.
SF/SC .
//FORWARDED: BY ORDER//
SECTION OFFICER

<!-- page 3 -->

APPENDIX
(G.O.Ms.No.77, Industries & Commerce(IP & INF) Department, Dt.09.10.2015)
OPERATIONAL GUIDELINES FOR IMPLEMENTATION OF T-IDEA
(TELANGANA STATE INDUSTRIAL DEVELOPMENT AND ENTREPRENEUR ADVANCEMENT) INCENTIVE

SCHEME, 2014.

1.0.

INTRODUCTION:
To promote Telangana State as the best investment destination for investors in India, the State
Government has offered various incentives/benefits to all eligible new industrial enterprises set up in
the State. Projects involving substantial Expansion / Diversification of existing industries in the
eligible lines of activities are also entitled for benefits offered under the policy notified vide
G.O.Ms.No.28, Industries & Commerce (IP&INF) Department, dated: 29/11/2014.

2.0.

AREA OF OPERATION:
The Scheme covers in extending the incentives / benefits to all eligible Micro, Small, Medium, Large
and Mega projects in the whole State except in the Municipal Corporation limits of Greater
Hyderabad Municipal Corporation excluding existing Industrial Estates/Parks, notified/ to be
notified and commence commercial production on or after 01/01/2015 but before 31/03/2019.
However, the Industrial Enterprises located in Sanathnagar, Azamabad, Chandulal Baradari and
Kattedan Industrial Estates of Hyderabad and Rangareddy Districts are not eligible for any
incentives/concessions. However, the service activities set up in all Municipal Corporation limits as
appended in Annexure–I are eligible only for investment subsidy and all other service /Business
activities are not eligible for any incentives set up anywhere in the State.

3.0.

COMMENCEMENT AND DURATION.
The Scheme will be in operation from 01/01/2015 to 31/03/2019 (inclusive of both dates), with such
further modifications as may be brought from time to time.
DEFINITIONS:

4.0.

T-IDEA (Telangana State Industrial Development and Entrepreneur Advancement) Incentive
Scheme 2014: Telangana State Industrial Development and Entrepreneur Advancement Incentive
Scheme 2014 means, the Policy of State Incentives / Facilities announced by the State Government
vide G.O.Ms.No.28, Industries & Commerce (IP&INF) Department, dated: 29/11/2014.

4.1.

Industry or Enterprises: Industry/ Enterprises means any industrial undertaking and servicing
Enterprise/Industry, other than those run departmentally by Government of India / State Government
and other than those listed in ineligible list of T-IDEA incentive scheme 2014.

4.2.

NEW INDUSTRIAL ENTERPRISES/INDUSTRY:

4.2.1

New Industrial Enterprise/industry means and includes an eligible manufacturing / service industrial
Enterprise/industry which has been established in the State with new machinery/equipment and
commenced commercial production after 01/01/2015 and before 31/03/2019 (inclusive of both dates)
holding valid approvals from the respective authorities.
a) Micro Enterprises: Micro Enterprise means an enterprise in which Investment on plant and
machinery up to limit as defined by the Government of India from time to time.
b) Small Enterprises: Small Enterprise means an enterprise having the investment on plant and
machinery up to limit as defined by the Government of India from time to time.
c) Medium Enterprises Medium Enterprise means an enterprise in which Investment on plant
and machinery up to limit as defined by the Government of India from time to time.
d) Large Industries Large Industry means an industry in which the investment on plant and
machinery is above Medium Enterprises (as defined by Government of India from time to
time).
e) Mega Projects:
i) Mega Project means the Industrial unit, which sets up with a capital investment of Rs.200
Crores and above or a project that creates employment to more than 1000 persons.
ii) The Government will also extend tailor-made benefits to Mega Projects to suit to a
particular investment requirements on case to case basis.

4.3

Fixed Capital Investment: Fixed Capital Investment means investment on land, building, plant,
machinery & equipment assessed as per Para 8 of these guidelines.

4.4.

Production Capacity: Production Capacity of Original Enterprise/Industry is the highest annual
production achieved during preceding 3 financial years prior to expansion/diversification, will be
treated as production capacity of the original Enterprise/Industry.

<!-- page 4 -->

4.5.

Expansion Projects: Existing industrial Enterprises, in all eligible areas, setting up expansion
projects other than those listed in the ineligible list, involving enhancement of fixed capital
investment by at least 25% as well as enhancement of installed capacity by 25% for the same product
lines will be eligible for incentives.

4.6.

Diversification Projects: Existing industrial Enterprises, in eligible areas, making investment for a
new product other than those listed in the ineligible list, involving Diversification with an
enhancement at least by 25% of fixed capital investment as well as enhancement of turnover by 25%,
in value terms, will be eligible for incentives.

4.7.

Erection of additional machinery continuation in the policy period i.e. T-IDEA Incentive
Scheme 2014: Any industrial enterprise/industry availing incentives under T-IDEA Incentive
Scheme 2014 can add new machinery & power. However, incentives/concessions are limited up to
(5) years from the original date of commencement of commercial production. But the Date of
Commencement of Commercial Production (DCP) will be considered as DCP of the original
Enterprise/industry.

4.8.

Any Enterprise/Industry going for substantial expansion/diversification, should submit the claim
application separately subject to conditions stipulated at Para No. 4.5 and 4.6, otherwise the
Enterprise/industry will be treated as one and the incentives/concessions will be considered from the
DCP of the original Enterprise/Industry.

4.9.

Expansion/Diversification enterprise/industry should also obtain all the statutory/required approvals.

4.10.

Original Fixed Capital Investment: All original fixed capital investment prior to
Expansion/Diversification will be treated as original fixed capital investment. While computing this
original fixed capital investment, neither depreciation nor revaluation will be taken into account.

4.11.

Tax: Tax means Commercial Tax paid to State Government by the way of VAT and CST or State
Goods and Services Tax (SGST) on goods produced by the industrial enterprise.

4.12.

Date of Commencement of Commercial Production (DCP): The date on which commercial
production is started, as indicated in the EM Part - II in respect of Micro, Small & Medium
Enterprises and as confirmed through part-B of IEM/IL filed with Government of India in respect of
Large industries/Mega Projects. The General Manager, District Industries Centre concerned has to
confirm and certify the Date of Commencement of Commercial Production. In case of any dispute
with regard to date of commencement of commercial production, the SLC (State Level Committee on
Incentives) decision is final.

4.13.

Continuous Production: Continuous production means continuous working of an industrial
Enterprise engaged in the activity of manufacture of approved lines for a minimum period of six (6)
years for Micro & Small Enterprises and ten (10) years for Medium Enterprises & Large
Industries/Mega Projects, without any break in production. If there is any break in production, such
period will be extended. If any industrial enterprise is not in operation/working for more than 90 days
continuously, then the industrial enterprise will be treated as not in continuous working. This
condition is not applicable for seasonal industrial enterprises which must be working during the
season.

4.14.

Approved Project Cost: Approved project cost means that cost of the project on different
components of the project as approved by the term lending institution or in case of joint financing, by
the lead term lending institution. The appraised project cost by the Scheduled Commercial
Banks/Financial Institutions recognized by Reserve Bank of India for the purpose of sanction of
working capital limits would also be treated as the approved project cost. In respect of self-financed
projects, the approved project cost will be fixed by the Multi Disciplinary Committee in respect of
Micro, Small & Medium Enterprises. In case of self financed large scale industries which have not
availed any assistance from financing institutions, such projects shall be referred to Standing Scrutiny
Committee (SSC)/Sub-Committee of SLC for inspection and report on the reasonable investment
limits on different components of the projects i.e. land, building, plant & machinery and other assets
which are necessary to make the project viable. These figures shall be taken as approved project cost.

4.15.

REVISED PROJECT COST: The revised project cost for the self financed Industrial Enterprises
should be as certified by the Technical Committee consisting of representatives of Industries
Department, APSFC-Telangana Unit, APIDC-Telangana Unit and APITCO-Telangana Unit, as
mentioned in the G.O Ms No.193, & Ind. Com. (IP) Department Dated 25.11.1995.

4.16.

Aided Enterprise/Industry: Availing term loan from Scheduled Commercial Banks/Financial
Institutions recognized by Reserve Bank of India, A.P. State Financial Corporation (APSFCTelangana Unit) and Small Industrial Development Bank of India (SIDBI) for setting up the
Enterprise/Industry is treated as Aided Enterprise/Industry.

4.17.

Month: Month means Calendar months.

4.18.

Financial Year: 1st April to 31st March.

<!-- page 5 -->

5.0

PROCEDURE FOR CLAIMING VARIOUS INCENTIVES OFFERED UNDER THE
SCHEME:
MEESEVA
The Incentive Claim applications filed by the unit through the Mee seva centers started since July,
2013.This request can be accessed by the Department with the following required documents:
1) Mee seva application form
2) Department claim application form
The Service Level is 30 days for Micro and 60 days for remaining nature of enterprises / industries.
Competent authority will be changed based on Nature of enterprise / Industry. District Industries
Centre, General Manager is Competent for MICRO industries and Joint Director at COI level is
competent for other types of Enterprises / Industries.

5.1.0

Reimbursement of Stamp duty, Transfer duty, Mortgage & Hypothecation duty:

5.1.1 All eligible industrial Enterprises shall submit their claims in the prescribed application form given at
Annexure-VI for reimbursement of stamp duty, transfer duty, mortgages and hypothecation duty
within six months from the date of commencement of commercial production, to the General
Manager, District Industries Centre concerned through MEE SEVA.
5.1.2 100% reimbursement of Stamp duty and transfer duty paid by the industry on purchase of
land/shed/building meant for industrial use.
5.1.3 100% reimbursement of Stamp duty for Lease of Land/Shed/ Buildings and also mortgages and
hypothecations deeds.
5.1.4 The Stamp duty, Transfer duty, mortgages and hypothecations benefits shall be applicable to all
eligible (a) new industrial Enterprises and (b) Expansion/Diversification projects, subject to
fulfillment of the conditions stipulated at Para No. 4.5 or 4.6.
5.1.5 The above incentive shall be admissible to eligible Enterprises on the land area upto five times of the
plinth area of the factory building constructed within the approved project cost. However, in respect
of industries where the open land requirements would be larger due to the specific nature of industry,
SLC may consider allowing land in excess of five times plinth area on case to case basis.
5.1.6 Mortgages and hypothecations duty paid by an enterprise for availing Term loan from the financial
institutions on assessed fixed capital investment would only be eligible.
5.1.7 If any industrial enterprise had already availed stamp duty or transfer duty concession on land under
G.O.Ms.No.9, Industries & Commerce (IP) Department, dated: 05.01.2001, the concession would be
reduced proportionately.
5.2.0 Reimbursement of land cost in IE/IDA/IP’s:
5.2.1 All eligible industrial Enterprises shall submit their claims in the prescribed application form given at
Annexure – VI for Reimbursement of land cost within six months from the date of commencement of
commercial production, to the General Manager, District Industries Centre concerned through MEE
SEVA.
5.2.2 25% Reimbursement of land cost in IE/IDA/IP’s limited to Rs.10.00 Lakh to the industrial
enterprises located at Industrial Estates/Industrial Parks.
5.2.3 The above benefit shall be applicable to all eligible (a) new industrial Enterprises and (b)
Expansion/Diversification Projects, subject to fulfillment of the conditions stipulated at Para No. 4.5
or 4.6.
5.2.4 The above benefit shall be provided on purchase of land directly from TSIIC only.
5.2.4.1 Separate Guidelines will be issued for Reimbursement of Land Cost to the Industrial Enterprises
at Private industrial Estates/Industrial Parks.
5.2.5 The above benefits shall be admissible up to five times of the plinth area of the factory building
constructed within the approved project cost. However, in respect of industries where the open land
requirements would be larger due to the specific nature of industry, SLC may consider allowing land
in excess of five times plinth area on case to case basis.
5.3.0 Reimbursement of land conversion Charges.
5.3.1 All eligible industrial Enterprises shall submit their claims in the prescribed application form given at
Annexure- VI for reimbursement of land conversion charges within six months from the date of
commencement of commercial production, to the General Manager, District Industries Centre
concerned through MEE SEVA

<!-- page 6 -->

5.3.2 25% Land conversion charges for industrial use limited to Rs.10.00 Lakh for Micro, Small and
Medium Enterprises only.
5.3.3 The Reimbursement of Land conversion charges shall be applicable to all eligible (a) new Micro,
Small and Medium Enterprises and also (b) Expansion/Diversification of Micro, Small and Medium
Enterprises, subject to fulfillment of the conditions stipulated at Para No. 4.5 or 4.6.
5.3.4 The above incentive shall be admissible to eligible Enterprises on the land area up to five times of the
plinth area of the factory building constructed. However, in respect of industries where the open land
requirements would be larger due to the specific nature of industry, SLC may consider allowing land
in excess of five times plinth area on case to case basis.
5.4.0

Reimbursement of Power consumption Charges:

5.4.1

All eligible industrial Enterprises / industries shall submit their claims in the prescribed application
form given at Annexure - VII for Reimbursement of Power cost within six months after completion
of every half-year i.e., last date for filing claim application is 31st of March for first half -year and
30th of September for second half-year along with the documents mentioned in the Application to the
General Manager, District Industries Centre concerned on half-yearly basis through MEE SEVA.

5.4.2

Fixed power cost @ Rs.1.00 per unit on energy consumption charges as per G.O.Ms.No. 28,
Industries & Commerce (IP&INF) Department, dated: 29/11/2014 will be reimbursed for a period of
five (5) years from the date of commencement of commercial production.

5.4.3

This reimbursement is only on the energy consumption (KVAH) charges but not on Maximum
Demand or any other charges levied by DISCOMs. Residential & Colony power consumption are not
eligible for Reimbursement of Power Cost.

5.4.4

The Reimbursement of power cost shall be applicable to all eligible (a) new industrial Enterprises
and (b) Expansion/Diversification Projects, subject to fulfillment of the conditions stipulated at Para
No. 4.5 or 4.6.

5.4.5

The power cost reimbursement shall be applicable to the industrial enterprises, which are utilizing
power from DISCOM only and power connection should be in the name of the Enterprise/industry.

5.4.6

Reimbursement of power cost will be allowed in case of Expansion/ Diversification Projects over
and above base power consumed. For the purpose of reimbursement, annual power consumption will
be taken into account. The reimbursement will be made every six (6) months, but in case of actual
power consumed during the year is less than annual base consumption, reimbursement made during
any previous period will be adjusted in future reimbursement. If excess is paid and could not be
adjusted in future claims, will be recovered under Revenue Recovery Act.

5.4.7

The base annual consumption will be average annual power consumption of previous three financial
years of the Expansion/Diversification project as certified by Chartered Accountant or power
consumption. Power consumed over and above the base consumption will be eligible for
reimbursement of power cost. If the Enterprise/Industry taken up expansion/diversification in the
same year, the base power consumption will be calculated proportionately.

5.5.0

Investment subsidy:

5.5.1 All eligible industrial Enterprises shall submit their claims in the prescribed application form given at
Annexure – VIII for investment subsidy within six months from the date of commencement of
commercial production, to the General Manager, District Industries Centre concerned through MEE
SEVA.
5.5.2 15% investment subsidy on fixed capital investment subject to a maximum of Rs.20.00 Lakhs to
Micro & Small Enterprises.
5.5.3

Additional 10% investment subsidy on fixed capital investment subject to a maximum of Rs.10.00
Lakhs to Micro & Small Enterprises for Woman entrepreneurs.

5.5.4

All eligible industrial Enterprises shall submit their claims in the prescribed application form
Investment subsidy shall be applicable to all identified service activities related to industries setup in
all Municipal Corporation limits in the State as per the list appended as Annexure - I.

5.5.5

Investment Subsidy shall be applicable to all eligible (a) new Micro and Small Enterprises and
Expansion/Diversification of Micro and Small Enterprises, subject to fulfillment of the conditions
stipulated at Para No. 4.5 or 4.6.

5.5.6

In respect of existing Micro and Small Enterprises, going for expansion/ diversification, the capital
investment subsidy would however subject to upper limit of Rs. 20.00 Lakh including all earlier
availed capital investment subsidy. This limit however would be Rs.30.00 Lakh in case of Women.

5.6.0. Seed Capital Assistance:
5.6.1

All eligible industrial Enterprises shall submit their claims in the prescribed application form given at
Annexure – X for Seed Capital Assistance within six months from the date of sanction of term loan
by the Financial Institution, to the General Manager, District Industries Centre concerned through
Mee seva.

<!-- page 7 -->

5.6.2

The Seed capital assistance to First Generation Entrepreneurs to set-up Micro Enterprises, @10% of
the Machinery cost will be paid and the same will be deducted from the eligible investment subsidy.

5.6.3

This facility shall be applicable to new Micro Enterprises only. This facility is not applicable for
expansion/diversification program, since the assistance is mainly meant for the first generation
Entrepreneurs.

5.7.0
5.7.1

Reimbursement of Tax:
All eligible industrial Enterprises shall submit their claims in the prescribed application form given at
Annexure – XI for Reimbursement of Sales Tax within six months after completion of every half
year i.e., last date for filing claim application is 31st of March for first half-year and 30th of
September for second half-year along with the documents mentioned in the Application to the
General Manager, District Industries Centre concerned on half yearly basis through MEE SEVA.

5.7.2

In case of Micro & Small Enterprises, 100% VAT/CST or State Goods and Services Tax (SGST) will
be reimbursed for a period of five (5) years from the date of commencement of commercial
production.

5.7.3

In case of Medium Enterprises, 75% VAT/CST or State Goods and Services Tax (SGST) will be
reimbursed for a period of seven (7) years from the date of commencement of commercial production
or up to realization of 100% fixed capital investment, whichever is earlier.

5.7.4

In case of Large Industries, 50% VAT/CST or State Goods and Services Tax (SGST) will be
reimbursed for a period of seven (7) years from the date of commencement of commercial production
or up to realization of 100% fixed capital investment, whichever is earlier.

5.7.5

The above incentive shall be applicable to all eligible (a) new industrial Enterprises and (b)
Expansion/Diversification projects, subject to fulfillment of the conditions stipulated at Para No. 4.5
or 4.6.

5.7.6

Reimbursement on VAT/CST or State Goods and Services Tax (SGST) will be allowed in case of
Expansion/ Diversification Projects over and above base annual production capacity or base turn
over. For the purpose of reimbursement, annual production or turn over will be taken into account.
The reimbursement will be made every six (6) months, but in case of actual production or turn over
during the year is less than annual base annual production capacity or base turn over, reimbursement
made during any previous period will be adjusted in future reimbursement. If excess is paid and
could not be adjusted in future claims, will be recovered under Revenue Recovery Act.

5.7.7

The Expansion/Diversification projects will be allowed reimbursement on VAT/CST or State Goods
and Services Tax (SGST) paid on production made over and above the base annual production
capacity or base turn over as per applicability of the original Enterprise/Industry i.e. before
expansion/ Diversification. The base annual production is average annual production of previous
three financial years even in case of manufacturing single product (as certified by Financial
Institution/ Charted Accountant). If the Enterprise/Industry taken up expansion/diversification in the
same year, the base capacity will be calculated proportionately. In case of multi products, the average
annual sales turnover of previous three financial years will be taken as base turnover (as certified by
Charted Accountant).

5.7.7

The enterprise/industry shall obtain the details of the net commercial tax paid during the half-year for
which the claim is being made duly certified by Commercial Tax authorities in form prescribed at
Form-A for original/expansion / Diversification Enterprise/Industry separately as the case may be.

5.8.0

Reimbursement on the expenses incurred for quality certification/patent registration:

5.8.1

All eligible industrial Enterprises shall submit their claims in the prescribed application form given at
Annexure - XII for Reimbursement of the expenses incurred for quality certification/patent
registration within six months from the date of obtaining quality certification along with required
documents mentioned in Application, to the General Manager, District Industries Centre concerned
through MEE SEVA.

5.8.2

50% subsidy on the expenses incurred for quality certification/ patent registration limited to Rs.2.00
Lakhs for Micro, Small and Medium Enterprises will be reimbursed.

5.8.3

This facility shall be available to all eligible new and Existing Micro, Small and Medium Enterprises,
obtaining quality certification from BIS/ISO/HACCP/ O/o Controller General of patents ,designs and
trademark other national/international certification agencies.

5.9.0

Reimbursement on specific cleaner production measures:

5.9.1

All eligible industrial Enterprises shall submit their claims in the prescribed application form given at
Annexure - XIII for subsidy on specific cleaner production measures within six months from the date
of commencement of commercial production along with required documents mentioned in
Application, to the General Manager, District Industries Centre concerned through MEE SEVA.

5.9.2

25% subsidy limited to Rs.5.00 Lakh will be provided on the cost incurred on capital equipment
installation for specific cleaner production measures. However the equipment should not be included
for calculating eligible capital investment.

<!-- page 8 -->

5.9.3

Cleaner production measures are adoption of cleaner technologies and techniques within the industry
to reduce and avoid pollution and waste in the entire production cycle.

5.9.4

The Enterprise/Industry shall obtain a certificate from TSPCB on the specific cleaner production
measures adopted and the cost of the equipment involved therein.

5.9.5

This facility shall be applicable to all eligible new and expansion/ diversification projects.

5.9.6

A certificate from TSPCB on the cleaner production measures adopted with certified copy and
list of equipments.

5.10.0 Reimbursement of cost involved in skill up gradation and training:
5.10.1 All eligible industrial Enterprises shall submit their claims in the prescribed application form given at
Annexure - XIV for Reimbursement of cost involved in skill up gradation and training the local
manpower within six months after completion of such training programme along with required
documents mentioned in Application, to the General Manager, District Industries Centre concerned
through MEE SEVA.
5.10.2 50% Reimbursement of cost involved in skill up gradation and training only local manpower limited
to Rs.2000/- per person as a onetime facility will be provided.
5.10.3 After recruitment of the local candidates, in-plant training to be organized.
5.10.4 Reputed/Accreditation Agencies both Government and Private shall be engaged.
5.10.5 The eligible Enterprises/Industries have to inform the General Manager, District Industries Centre
concerned well in advance of the commencement of training program. The General Manager, District
Industries Centre concerned shall monitor the skill development training program.
5.10.6 The Enterprise/industry should submit the list of employees trained along with their appointment
letters duly certified by the promoter.
5.10.7 The training should be more practical oriented rather than pure theoretical one.
5.10.8 This facility should be utilized for training the local manpower so that the local manpower will be
readily suitable for employment.
5.10.9 The training should be aimed at up gradation of skill, which should be useful to the organization.
5.10.10 Detailed Guidelines will be issued on the subject separately in regard to skill up gradation, training
period and local employment
5.11.0 PAVALA VADDI
5.11.1

All eligible industrial Enterprises shall submit their claims in the prescribed application form given
at Annexure - IX for Pavala Vaddi within six months after completion of every half year i.e., last
date for filing claim application is 31st of March for first half-year and 30th of September for second
half-year along with the documents mentioned in the Application to the General Manager, District
Industries Centre concerned on half yearly basis through MEE SEVA.

5.11.2

Interest subsidy under Pavala Vaddi Scheme on the term loan availed on the fixed capital
investment by New Micro and Small Enterprises in excess of 3% per annum subject to a maximum
reimbursement of 9% per annum for a period of 5 years from the date of commencement of
commercial production.

5.11.3

This facility shall be applicable to the Term Loan availed on Fixed Capital Investment by all
eligible new Micro and Small Enterprises only.

5.11.4

a) Minimum 3% interest per annum should be borne by the Enterprise.
b) Over and above 3% interest per annum reimbursement will be done to the extent of 9%
maximum i.e. in case an interest up to 12% interest per annum for a period of 5 years from the
date of commencement of commercial production under Pavala Vaddi Scheme.
c) Over and above 12% interest per annum, the enterprise has to bear.

5.11.5

This facility is not applicable for expansion/diversification projects.

5.11.6

Eligible servicing and repairing enterprises for reimbursement of Interest Subsidy under
Pavala Vaddi Scheme:
(a) Auto Servicing and / or repairing units; (b) Retreading units; (c) Industrial material testing
laboratories; (d) General engineering machining workshops; (e) Common effluent treatment
plants; (f) CAD and/or CAM; (g) Cold storage; (h) Heat treatment, Electroplating and Galvanizing
units; (i) Seed processing units; (j) Xerox units set up with institutional finance only and (k) Desk
top printing units.

5.11.7

The new enterprises & industries under T-IDEA Incentive Scheme 2014, availing term loan
Scheduled Commercial Banks / Financial Institutions recognized by Reserve Bank of India,
A.P.State Financial Corporation (APSFC-Telangana Unit) and Small Industrial Development Bank
of India (SIDBI) only are eligible under this scheme.

<!-- page 9 -->

5.11.8

The Interest amount paid by the new eligible enterprises & industries to the Financial
Institutions/Banks on the term loan availed will be reimbursed with a maximum limit of 9% on half
yearly basis through the Financial Institutions/Banks concerned. Benefit will be available for a
period of five (5) years from the date of commencement of commercial production.

5.11.9

The sanctioned term loan disbursed within six months from the date of commencement of
Commercial production has to be part and parcel of original Term Loan sanctioned. Second Term
Loan is not eligible under the Scheme.

5.11.10 The reimbursement of interest will be considered only from the Date of Commencement of
Commercial Production onwards whatever the interest liability is for moratorium or regular
loan.
5.11.11 This reimbursement to the Enterprise/Industry shall not include penal interest, liquidated Damages
etc. paid to the Financial Institutions / Banks.
5.11.12 The benefit shall be extended only to the eligible new enterprises/industries which are
repaying the Loan installments of principal & interest.

Regularly

5.11.13 The loan accounts that are classified as overdue in the books of the bank at the time of half- Yearly
closing and that which are classified as Non-performing Assets at year-end closing are ineligible.
However, if they resume on-time repayments and regularize the arrears, they are eligible for the
incentive in the next half-yearly period. For this purpose the banker has to certify that the
repayment is regular and the Account is standard and the same certificate is to be enclosed along
with claim application.
5.11.14 After receipt of the Reimbursement of Interest amount through RTGS/NEFT by the Bank branch
concerned from Commissionerate of Industries account, the amount shall be disbursed to the
industrial Enterprise immediately.
6.1.0. INDUSTRIAL INFRASTRUCTURE DEVELOPMENT FUND (IIDF)
6.1.1. All eligible industrial Enterprises shall submit their claims in the prescribed application form given at
Annexure – XV for financial assistance before date of commencement of commercial production or
within six months from the date of commencement of commercial production along with required
documents, to the General Manager, District Industries Centre concerned through MEE SEVA.
6.1.2. Infrastructure like roads, power and water will be provided at door step of the industry for standalone
enterprises/industries by contributing 50% of the cost of infrastructure from IIDF with a ceiling of
Rs.1.00 Crore, subject to (a) the location should be beyond 10 kms from the existing Industrial
Estates/IDA/IP’s having vacant land/shed for allotment and (b) cost of the infrastructure limited to
15% of the eligible fixed capital investment made in the industry.
6.1.3. The General Manager, District Industries Centre will recommend the applications after placing
before the District Investment Promotion Committee (DIPC) Meeting to the Commissioner of
Industries with his specific remarks/recommendation on the proposed Infrastructure to be developed
together with the following information.
6.1.4. The Enterprise/Industry should give a declaration stating that they have not availed any financial
assistance from the Government earlier for the proposed Infrastructure to be developed:
6.1.5. Declaration from the line department concerned shall be obtained stating that the project is not
covered in the budgetary estimates of current year.
6.1.6. The Infrastructure estimates are to be confirmed by District head of the line department concerned
with certificate that no departmental funds are available for this purpose.
6.1.7. This assistance would be available for all eligible Medium Enterprises & Large Industries and Mega
projects only.
6.1.8. The State Government has provided financial assistance as a grant to the new Industrial Enterprises
for the development of following Infrastructure facilities up to the door step of the proposed
Industrial Enterprises.
a. Drinking Water and Industrial Water
b. Electricity – Power connection
c. Laying of drainage line from the Enterprise/Industry/Industrial Estate to the existing Point or
to the natural drainage point:
d. Approach Road to the Enterprise/Industry
e. Any other infrastructure facilities as approved by the Government/SLC.
6.1.9. The Industries which are declared as “in-eligible industries” under ineligible list of T-IDEA Incentive
Scheme 2014 are not eligible for financial assistance from Industrial infrastructure Development
Fund.
6.1.10. Before release of incentives amount, the General Manager, District Industries Centre concerned has
to ascertain the working condition of the enterprise/industry.

<!-- page 10 -->

6.1.11. The Enterprise/Industry should be in operation for at least six (6) years in respect of Micro & Small
Enterprises, ten (10) years in respect of Medium Enterprises & Large Industries/Mega Projects from
the Date of Commencement of Commercial Production, if not, the grant will be recovered. In this
regard, the General Manager, District Industries Centre should monitor the progress of these
Enterprises and submit report to the Commissioner of Industries on half-yearly basis.
6.2.0. STATE LEVEL SCRUTINY/VERIFICATION COMMITTEES FOR IIDF
6.2.1

Additional Director of Industries, Hyderabad.

6.2.2

President of Federation of Telangana & Andhra Pradesh
Chamber of Commerce and Industry or his nominee
Member

6.2.3

President of FETSIA (Federation of Telangana Small
Industries Associations or his nominee.
Member

6.2.4

Managing Director, Telangana State Financial Corporation,
Hyderabad or his nominee
Member

6.2.5

Convener, State Level Bankers Committee,

Member

6.2.6

Executive Director, T.S. Industrial Infrastructure Corporation,
Hyderabad or his nominee

Member

6.2.7

Chief Engineer, TSTRANSCO

Member

6.2.8

Engineer in chief Panchayat Raj or his nominee

Member

6.2.9

Chief General Manager of DISCOM concerned

Member

6.2.10

Engineer-in-Chief, R&B or his nominee

Member

6.2.11

Engineer-in-Chief, HMWS&SB or his nominee

Member

6.2.12

Nominee of Telangana Industrialist Welfare Federation(TIF)

Member

6.2.13

Nominee of Confederation of Indian Industry(CII)

Member

6.2.14

Joint Director of industries

Member
Convener

7.0.0

Chairman

TEXTILE SECTOR

7.1.0. The Modern Ginning Enterprises/Industries should fulfill of the Norms availing incentives as per
Technology Mission on Cotton Appended at Annexure – V.
7.2.0. Interest Subsidy

7.2.1. All eligible industries shall submit their claims in the prescribed application form given at Annexure
- IX for Interest Subsidy within six months after completion of every half year i.e., last date for filing
claim application is 31st of March for first half-year and 30th of September for second half-year along
with the documents mentioned in the Application to the General Manager, District Industries Centre
concerned on half yearly basis through MEE SEVA

7.2.2. The State will provide reimbursement of Interest Subsidy to Spinning / Textile industries in
addition to the TUF Scheme (Technology Up gradation Fund Scheme of Ministry of Textile,
Government of India).
7.2.3. Reimbursement of interest subsidy @ 4% for spinning activity (excluding Ginning) for period of (5)
years from the Date of Commencement of Commercial Production.
7.2.4. Reimbursement of interest subsidy @ 6% for Industries involved in composite activities i.e.,
Spinning and Weaving/Knitting/Dyeing/Garmenting (excluding ginning) for a period of (5) years
from the Date of Commencement of Commercial Production.
7.2.5. The total interest subsidy including under TUF Scheme should not exceed the rate of interest levied
by Financial Institutions on the sanctioned and disbursed term loan to the unit.
7.2.6. This facility shall be applicable to all new and expansion/ diversification projects involved in
composite activities i.e., Spinning and Weaving/Knitting/Dyeing/Garmenting (excluding ginning).

7.2.7. The industries under T-IDEA Incentive Scheme 2014, availing term loan from Scheduled
Commercial Banks / Financial Institutions recognized by Reserve Bank of India, Telangana
State Financial Corporation (TSFC) and Small Industrial Development Bank of India
(SIDBI) only are eligible under this scheme.

<!-- page 11 -->

7.2.8. The Interest amount paid by the industries to the Financial Institutions/Banks on the term
loan availed will be reimbursed on half yearly basis through the Financial Institutions/Banks
concerned. Benefit will be available for a period of five (5) years from the date of
commencement of commercial production.
7.2.9. The sanctioned term loan disbursed within six months from the date of commencement of
commercial production has to be part and parcel of original Term Loan sanctioned.
7.2.10.The reimbursement of interest will be considered only from the Date of Commencement of
Commercial Production onwards whatever the interest liability is for moratorium or regular
loan.
7.2.11. The Spinning/Weaving/Garmenting enterprises/industries commence commercial production
on or after 01/01/2015 but before 31/03/2019 are eligible for the benefits/concessions under T-IDEA
Incentive Scheme 2014.

7.2.12. As per the G.O.Ms. No.30 Industries & Commerce (IP & INF) Department, Dated:29/11/2014,
“Interest subvention provided under the new 2014 Telangana Industrial Development and
Entrepreneur Advancement (T-IDEA) policy for textile sector till 31/10/2019 (period under New
Policy).

7.2.13.The State will provide reimbursement of Interest Subsidy to Spinning / Textile industries in addition
to the TUF Scheme, which have commenced commercial production in the period of IIPP 2001015 scheme are eligible for above interest subsidy w.e.f. 01/01/2015 to 31/10/2019
irrespective of the date of commencement of production.
7.2.14.This reimbursement to the Industry shall not include penal interest, liquidated damages etc.
paid to the Financial Institutions / Banks.
7.2.15.The benefit shall be extended only to the eligible industries which are regularly repaying the
Loan installments of principal & interest.
7.2.16.The loan accounts that are classified as overdue in the books of the bank at the time of halfyearly closing and that which are classified as Non-performing Assets at year-end closing are
ineligible. However, if they resume on-time repayments and regularize the arrears, they are
eligible for the incentive in the next half-yearly period. For this purpose the banker has to
certify that the repayment is regular and the Account is standard and the same certificate is to
be enclosed along with claim application.
7.2.17. After receipt of the Reimbursement of Interest amount through RTGS/NEFT by the Bank
branch concerned from Commissionerate of Industries account, the amount shall be disbursed to
the industrial Enterprise immediately.
7.3.0. Reimbursement of Power cost.
7.3.1. As per the G.O.Ms. No.30 Industries & Commerce (IP & INF) Department, Dated:29/11/2014, “Power
subsidy at the rates of IIPP 2010-2015 previously approved till 31/10/2019 (period under New
Policy)”.
7.3.2. The benefits/concessions of T-IDEA 2014 will be applicable to the Enterprises/Industries which have
gone into commercial production on or before 01.01.2015.
7.3.3. Fixed power cost @ Rs.0.75 per unit (upper ceiling) on energy consumption charges as per G.O. Ms.
No. 61 Industries & Commerce (IP) Department, dated: 29/06/2010 will be reimbursed till
31/10/2019.
7.3.4. All eligible industrial Enterprises / industries shall submit their claims in the prescribed application
form given at Annexure - VII in T-IDEA 2014 for Reimbursement of Power cost within six months
after completion of every Half-year i.e., last date for filing claim application is 31st of March for first
half year and 30th of September for second half year along with the documents mentioned in the
Application to the General Manager, District Industries Centre concerned on half yearly basis
through MEESEVA.
7.4.0. Other Incentives
7.4.1. The operational guidelines of T-IDEA Incentive Scheme 2014 shall “ipso facto” apply in respect of
the enterprises/industries covered under Textile Sector.

<!-- page 12 -->

8.0.0. COMPUTATION OF FIXED CAPITAL INVESTMENT:
8.1.0. LAND :
8.1.1. Cost of land required for the successful working of the new industrial enterprise would normally be
computed by considering value of land equivalent to five times the plinth area of the factory building
constructed and not exceeding the approved project cost. However, in respect of
enterprises/industries where the open land requirements would be large due to the specific nature
industry, SLC may consider allowing land in excess of 5 times of plinth area on case to case basis.
However cost of site leveling, clearance, laying of roads, etc. will not be considered for capital cost.
8.1.2. Value of leased land will not be taken into account for capital cost.
8.1.3. Sale deed should be registered in the name of Enterprise/Industry/Proprietor as the case may be, for
sanction of any incentives / concessions.
8.1.4. Lands inherited would not be considered for capital cost computation.
8.1.5. Stamp duty and Transfer duty component will not be taken in to account while computing the fixed
capital investment for sanction of Investment Subsidy. But it will be taken in to account while
computing the fixed capital investment for sanctioning the tax based incentives.
8.1.6. In case of availing 25% land cost on lands purchased in TSIIC developed IEs/IDA/Industrial Parks,
the land cost will not be taken in to account while computing the fixed capital investment for
sanction of Investment Subsidy. But land cost will be taken in to account while computing the fixed
capital investment for sanctioning the tax based incentives.
8.2.0. FACTORY BUILDING:
8.2.1.

The value of factory building constructions will be limited to the approved project cost. Values of
leased building will not be taken into account. Cost of buildings will be computed as per the
APSFC-Telangana Unit approved rates of construction / year of construction or the actual cost,
whichever is lower. The items of civil works which are permitted for computation towards eligible
cost are:
(1)
(2)
(3)
(4)
(5)
(6)
(7)
(8)
(9)
(10)
(11)
(12)
(13)
(14)
(15)
(16)

Main Factory Shed.
Raw Material and finished products Godown.
Office room and Lab room.
Cooling water ponds.
Boiler shed and generator room.
Effluent treatment ponds, etc.
Overhead Tank, bore-wells, and pump house and sump.
Fencing and Gate.
Architect fee and supervision charges.
Compound wall.
Canteen.
Rest House.
Time Office.
Cycle / Vehicle Stand.
Security Shed and
Toilet room and sanitary fittings.

8.2.2 The total value of items at (10) to (16) and similar items shall not exceed 10% of the total value of
civil works. Total value of the civil works means items (1) to (9) only (within the approved project
cost). The plinth area of the civil works based on the construction made by the industrial enterprise
from items (1) to (9) only.
8.3.0. PLANT AND MACHINERY:
8.3.1.

The computable cost should be within the approved project cost, subject to limitations setout in the
following paras.

8.3.2.

Value of plant, machinery and equipment installed for undertaking production of approved items
and the value of tools (other than consumables) Jigs, Dies, Moulds necessary for production of
approved items will be taken into account. Leased plant and equipment is not eligible for
incentives.

8.3.3.

Enterprise/Industry setup with total second hand machinery would not be eligible for any
incentives/concessions. However in case of Enterprise/Industry setup with imported machinery,
value of 100% imported second hand plant, machinery and equipment will be considered as new
indigenous machinery, if it is imported directly by the industrial Enterprise. In case of indigenous

<!-- page 13 -->

second hand machinery purchased by the industrial enterprise, such value should not exceed 25%
of the total value of plant and machinery. The value of indigenous second hand machinery will not
be computed towards fixed eligible capital investment for incentives. To decide the percentage of
second hand machinery, market value as certified by Chartered Accountant (C.A.) will be taken
into account, subject to such machinery having a minimum of further six (6) years life for Micro,
Small Enterprises and twelve (12) years for Medium Enterprise and Large Industries certified by a
Licensed Engineer. New Enterprise/industry setting up with a mix up of new / second hand
machinery shall be subjected to these norms.
8.3.4.

Expenditure on Technical Consultancy / Feasibility study including turn-key charges will be
considered towards the fixed capital investment, provided they are part of the approved project
cost, capitalized and certified by a Chartered Accountant, but limited to 10% of the total cost of
plant machinery and equipment installed.

8.3.5.

The value of plant, machinery and equipment procured by new industrial Enterprise from APSFCTelangana Unit / Telangana State Industrial Development Corporation / Nationalized Banks
pertaining to disposed off Enterprise/industry will be taken into account, provided such machinery
has not enjoyed any incentives under any of the earlier incentive schemes. Only depreciated value
of such plant, machinery and equipment, as certified by Chartered Accountant subject to such
machinery having a minimum of further six (6) years life for Micro, Small Enterprises and twelve
(12) years for Medium Enterprise and Large Industries certified by a Licensed Engineer, will be
taken into account for computing towards eligible fixed capital investment.

8.3.6.

In respect of new industries Enterprises setup in the premises belonging to disposed off Enterprises
from any Financial Institution / disposed off enterprises/industries, if the earlier Enterprises availed
incentives, only new assets created with fresh investment would be eligible for incentives.

8.3.7.

Value of self-fabricated machinery by the new industrial Enterprise/Industry will have to be
certified by a Chartered Engineer or Engineer of the term lending institution concerned for the
purpose of computing the eligible fixed capital investment.

8.3.8

The new industrial Enterprises set up for "Heavy Structural Fabrications" will be considered for
grant of incentives only in case the following minimum plant, machinery and equipment are
installed.

8.3.9

(1)

Gantry 5/10 tons capacity with chain pulley block or EOT/HOT crane 5/10 tons capacity.

(2)

Arc welding Transformer with welding Generators or Rectifiers.

(3)

Gas welding and cutting equipment.

(4)

Electrical tools namely; Grinder, Rivettor or Drilling Machinery or Pneumatic tools with air
compressor.

(5)

Pillar type drilling machine 1" / 1.1/2" capacity.

(6)

Pug cutting equipment for cutting heavy sections viz. Angles, Plates and Channels.

(7)

Drafting machine and drawing office equipment (optional).

(8)

Any other latest equipment to perform heavy structural fabrication in lieu of any of the above
equipment.

ITEMS NOT COMPUTABLE TOWARDS FIXED CAPITAL INVESTMENT.
(1)

Working capital, raw material, stores and all consumables including spare tools, etc.

(2)

Value of the Motor Vehicles.

(3)

Pre-operative expenses, advances, expenditure not supported by payment of bills wherever
necessary.

(4)

Investment made outside the approved project cost and items not covered by approved
project.

(5)

Fixed assets which form part of project cost but not created within 6 months from the date of
commercial production or the date of filling the claim whichever is earlier, if it is financed
enterprises/industry.

(6)

Term loan sanctioned by the Financial Institution after the date of commencement of
commercial production.

(7)

In case of self-financed Enterprise/industry, the fixed assets created after the date of commencement
of Commercial Production and also payment made after date of commencement of Commercial
Production, such value.

<!-- page 14 -->

9.0.

GENERAL

9.1.

The claim applications filed after six months but before one year from the specified Date as defined
for sanction of incentives will be treated as belated claims and are eligible for 50% of all the
incentives. All claims filed beyond one year are not eligible for any incentives.

9.2.

All eligible Micro or Small Enterprise established in leased premises should furnish a registered
lease deed for a minimum period of ten (10) years covering the first six (6) years production period
from the date of commencement of production.

9.3.

All eligible Medium Enterprise or Large Industry should furnish a registered lease deed for a
minimum period of ten (10) years covering the first ten (10) years production period from the date
of commencement of production.

9.4.

If any Micro and Small Enterprise new or taking up expansion/diversification had availed
investment subsidy under any scheme i.e. any similar incentives of State Government /
Government of India/Institutions/Agencies already availed/ Government of India incentives which
may be announced from time to time and other such incentives extended by any other Government
Agency, the total subsidy amount would be limited to Rs.20.00 lakhs in case of general
entrepreneurs and Rs.30.00 lakhs in case of Women entrepreneurs as per the limits prescribed in
the T-IDEA Incentive Scheme 2014.

9.5.

In case of existing Industrial Enterprise setting up a new industrial Enterprise with separate
identifiable investment, the words 'SEPARATE IDENTIFIABLE INVESTMENT’ shall means that
the Enterprise/Industry should not have any production linkage with the existing manufacturing
process and the product should be a separate product itself with independent marketability. The
new Enterprise/Industry should be in a separate building, should maintain separate books of
accounts and the project should be appraised independently by financial institution as a viable
project. A new project will not, however, be regarded as a "Separate Identifiable Investment" if the
utilities of the existing Enterprise/Industry like water, electricity, steam and pollution control
systems are extended to the new Enterprise/Industry (Government Memo No.27099/IP/A2/97-2,
dated:15/06/1998).

9.6.

If any existing Industrial Enterprise setting up a new industrial Enterprise with separate identifiable
investment for the same end product/new product at different location in the same name it will be
treated as new Enterprise/Industry (separately identifiable investment), even though there is no
separate Sales Tax registration number (VAT) and separate marketability, since the Sales Tax
Department is issuing only one Sales Tax registration number (VAT) for one dealer even they have
more than one Enterprises/Industries within the state. However they have to maintain separate
books of accounts for each location.

10.0.

INELIGIBILITY :

10.1.

Enterprises/Industries listed as ineligible in G.O.Ms.No. 62, Industries & Commerce (IP&INF)
Dept. dated 08.09.2015 are not eligible for any incentives/concessions.

10.2.

New industrial Enterprise being set up within the limits of Grater Hyderabad Municipal
Corporation excluding existing Industrial Estates/Parks, Industrial Estates notified, Industrial
Estates to be notified and commence commercial production on or after 01/01/2015 but before
31/03/2019. However, the Industrial Enterprises set up at Sanathnagar, Azamabad, Chandulal
Baradari and Kattedan Industrial Estates are not eligible under T-IDEA Incentive Scheme 2014.

10.3.

New Industrial Enterprise/industry established with Plant and Machinery on lease is not eligible for
incentives/concessions.

10.4.

New Industrial Enterprise/industry established with second hand machinery is not eligible for
incentives/concessions except where the cost of such machinery does not exceed 25% of the total
cost of plant and machinery.

10.5.

Composites industrial enterprise set up for manufacture of an eligible item along with an ineligible
item are not eligible for incentives/concessions except when the proportion of ineligible items in
the total production is less than 10% in value of the total turnover.

10.6.

New Integrated Steel Plants which produces Steel Billets, Coils, Strips, Slabs or Alloy Steels
starting with iron ore / scrap and using the liquid metal produced to make Billets, Coils, Strips,
Slabs or Alloy Steels any melting Enterprises/Industries involved part production are eligible for all
other incentives / benefits under T-IDEA Incentive Scheme 2014 except power cost
reimbursement. However, manufacture of Sponge Iron and Pig Iron are eligible for reimbursement
of power cost including other incentives under T-IDEA Incentive Scheme 2014.

11.0.

CHANGE OF CONSTITUTION/MANAGEMENT/ NAME OR STYLE OF INDUSTRIAL
ENTERPRISE/INDUSTRY:
The Industrial Enterprise that availed incentives/concessions should obtain the No Objection
Certificate (NOC) from the financing institutions concerned in respect of aided Enterprise/industry
and Certificate of incorporation from Registrar of Companies (ROC) within the first six (6) years in

<!-- page 15 -->

respect of Micro & Small Enterprises and ten (10) years in respect of Medium Enterprises & Large
industries/Mega Projects from the date of Commencement of Commercial Production, before
seeking the approval of State Level Committee for any change of the
constitution/Management/name & style of the Industrial Enterprise.
12.0.

LEASE OF ENTERPRISE/INDUSTRY:
In case of the Industrial Enterprise that availed incentives/concessions whose management is not
able to run the Enterprise/Industry and intent to lease out to other management within the first six
(6) years in respect of Micro & Small Enterprises and ten (10) years in respect of Medium
Enterprises & Large industries/Mega Projects from the date of Commencement of Commercial
Production should obtain the No Objection Certificate (NOC) from the financing institutions
concerned in respect of aided Enterprise/industry before seeking the approval of State Level
Committee .In respect of self financed units ,the applications for approval should be submitted to
SLC through GM.

13.0.

CHANGE OF LOCATION OF
INCENTIVES/CONCESSIONS:

INDUSTRIAL

ENTERPRISES

SANCTIONED

13.1.

Any Micro/Small Enterprises proposing to shift their Enterprises within the District, they should
obtain No Objection Certificate from the financing institutions concerned in respect of aided
Enterprises/industries before seeking the approval of District Level Committee concerned. In case
of shifting of any industrial enterprise outside the District, they should obtain prior approval of the
financing institutions concerned in respect of aided Enterprises/industries before seeking the
approval of State Level Committee. In respect of Medium Enterprises & Large industries proposing
to shift within the District or outside the District should obtain prior approval of financing
institution if it is aided and then approach Commissioner of Industries for permission of the State
Level Committee. Shifting of Enterprise/industry outside the State is not allowed.

13.2.

In respect of Self Financed Enterprises/industries: In respect of Micro/Small Enterprises proposing
to shift their Enterprises within the District, they should obtain prior approval of District Level
Committee Concerned. In case of shifting of any industrial enterprise outside the District they
should obtain prior approval of State Level Committee through the General Manager, District
Industries Centre Concerned. In respect of Medium Enterprise and Large industry (unaided or Self
Financed) proposing to shift their enterprise/industry either within the District or outside the
District, should obtain prior permission from State Level Committee. Shifting of
enterprise/industry outside the State is not allowed.

14.0.

MERGER/AMALGAMATION OF THE INDUSTRIAL ENTERPRISES:

14.1.

Prior approval of the State Level Committee is necessary for any merger/amalgamation of
Enterprises/industries. The Public and Private Limited Companies seeking merger/amalgamation of
their group of companies shall submit an application to Commissioner of Industries through
General Manager, District Industries Centre concerned along with the necessary orders of
appropriate forum under Companies Act, NOC from the Financing Institution, amended Letter of
Intent/Industrial License/Industrial Entrepreneur Memorandum and Incorporation Certificate from
the Registrar of Companies.

14.2.

The Partnership Firm shall submit No Objection Certificate from their Financing Institution and
Firm Registration. The Proprietary concern shall submit NOC from the Financing Institution.

15.0.

CHANGE OF LINE OF ACTIVITY/INCLUSION OF ADDITIONAL LINE OF
ACTIVITIES:
If an enterprise/industry starts manufacturing new eligible items without any additional machinery
or equipment, with the same plant & machinery, then such items shall be permitted for availing sale
tax reimbursement within the period of five (5) years in respect of Micro & Small Enterprises and
seven (7) years in respect of Medium Enterprises & Large industries/Mega Projects from the Date
of Commencement of Commercial Production of the original product. They should obtain prior
approval of the State Level Committee before taking up production of such new items.

16.0.

BREAK IN PRODUCTION:
The Industrial Enterprises obtaining incentives should be in continuous production for a period of
six (6) years in respect of Micro & Small Enterprises and ten (10) years in respect of Medium
Enterprises & Large industries/Mega Projects from the Date of Commencement of Commercial
Production failing which all incentives/concessions sanctioned are liable to be cancelled and the
incentives/concessions already availed are liable for recovery. In this regard, the General Manager,
District Industries Centre concerned should monitor the progress of these Enterprises and submit
report to the Commissioner of Industries on half-yearly basis. Break-in-production up to a period of
three (3) years due to the reasons beyond its control such as shortage of raw-materials, power and
change of management, etc. may be condoned by State Level Committee (SLC) on merits. Any
break-in-production beyond three (3) years will result in extending the six (6) years in respect of
Micro & Small Enterprises and ten (10) years in respect of Medium Enterprises & Large

<!-- page 16 -->

industries/Mega Projects continuous production condition by the period of such break.
17.0.

PROCEDURE TO BE ADHERED BY THE GENERAL MANAGER, DISTRICT
INDUSTRIES CENTRES:

17.1.

The General Managers of District Industries Centers shall maintain a separate registers
a) Receipt of Incentive Applications, b) Sanctions & Releases

17.2.

All files pertaining to sanctioned District Level Committee cases and recommended State Level
Committee cases must be recorded and kept for a period of 10 years, and made available for
inspection of audit / inspecting authorities. Files pertaining to audit objection if any, shall be kept in
record till such objections are cleared/deleted from the audit paras.

18.0.

PROCEDURE FOR SANCTION OF INCENTIVES:

18.1.

On receipt of the incentive claim application from the industrial Enterprises through MEESEVA
for sanction of incentives, the DIC officials should provide an inspection Date for the
Enterprise/Industry in the portal which is sent as an SMS to the Enterprise/Industry.

18.2.

The DIC officials may collect &verify all the records/documents as per the PART-B of
ratification-cum-recommendation of the General Manager, District Industries Centre concerned &
Check List duly following the procedure at the Time of Inspection only:
(a)

Micro Enterprises should be jointly inspected by Assistant Director/Deputy Director &
Industrial Promotion Officer concerned.

(b) Small Enterprises should be jointly inspected by Assistant Director/Deputy
Director/General Manager along with Industrial Promotion Officer concerned.
(c)
18.3.

Medium Enterprises/Large Industries/Mega Projects should be jointly inspected by the
General Manager along with Assistant Director/Deputy Director concerned.

If it is an aided or self financed Enterprise/Industry, the inspecting officers should verify all the
machinery as per machinery list with bills, payment proofs and certify on the list of
machinery as follows:
“Verified Plant & Machinery. Found tallying with the list. Duly erected and put to use and is
required for manufacturing the approved lines of activities. There are no second hand
machinery items in the list”.
If any second hand machinery exists in the list, it can be certified accordingly.

18.4.

If it is an aided Enterprise/Industry, the financial institution & General Manager, District Industries
Centre concerned or Inspecting Officer should certify that “this is to certify that from the above list
of plant & machinery Sl. No. ____ to _____ are new and Sl.No._____ to _____ is second hand
machinery.

18.5.

After Field Inspection of the Unit, it will be placed in the District Investment Promotion Committee
meeting chaired by the District Collector for Rejection/Sanction of the Incentive.

18.6.

In respect of District Level Committee cases, while recommending sanctioned cases to
Commissioner of Industries for release of sanctioned Incentives amount, the General Manager after
updating information on the Meeseva portal should Certify the same in communication to COI
mentioning “Sanction information in respect of all units approved in District Investment
Promotion Committee in its meeting dated …. and is also updated on meeseva portal on……
(Date)”. Not complying the updating of information on the portal will result in non-inclusion of
the DIPC approved cases for release of incentives.

18.7.

In respect of State Level Committee cases, while forwarding/recommending the application to
COI, the General Manager, DIC while updating information on Meeseva portal ,should certify the
same in the forwarding letter stating “information in respect of the unit is updated on Meeseva
portal on …….(date.
)”. Not complying with updating of information on the portal will
result in return of application to the DIC without further processing.

18.8.0

At Commissioner of Industries Level

18.8.1 In respect of SLC cases, the Joint Director (II & Sub-Plan) will ensure updating of information on
the Meeseva portal as soon as the cases are approved in the SLC, so as to ensure availability of
sanctioned information to the unit holders as well as the General Managers Concerned.
18.8.2 Scrutiny/Verification Committees at the State Level and District Level are constituted for
Scrutinizing and recommending the claims for these incentives to the State Level/ District
Level Committees.
18.8.3 Committees at the State Level and District Level are constituted for sanction/rejection of the
Claims for these incentives.

<!-- page 17 -->

19.0.

STATE LEVEL SCRUTINY/VERIFICATION COMMITTEES

19.1.0

SCRUTINY/VERIFICATION COMMITTEE FOR INVESTMENT SUBSIDY
UNDER VARIOUS INCENTIVES/CONCESSIONS

19.1.1

Additional Director of Industries

Chairman

19.1.2

President of Federation of Telangana & Andhra Pradesh
Chamber of Commerce and Industry or his nominee.
Member

19.1.3

President of FETSIA or his nominee.

19.1.4

Convener, State Level Bankers Committee (SLBC) or his
nominee.
Member

19.1.5

General Manager, Telangana State Financial Corporation,
Hyderabad or his nominee.
Member

19.1.6

Nominee of Managing Director, Telangana State Industrial
Infrastructure Corporation, Hyderabad

Member

Member

19.1.7

Nominee of Inspector General, Registration & Stamps,
Revenue Department
Member

19.1.8

Nominee of Chief Commissioner, Land Administration

19.1.9

Nominee of federation of Small & Medium enterprises of
India
Member

19.1.10

Nominee of Telangana Industrialists Welfare Federation(TIF)

Member

19.1.11

Joint Director of industries

MemberConvener

19.2.0

Member

SCRUTINY/VERIFICATION COMMITTEE FOR REIMBURSEMENT OF
POWER COST

19.2.1

Additional Director of Industries, Hyderabad.

19.2.2

President of Federation of Telangana & A.P. Chamber of
Commerce and Industry or his nominee.
Member

19.2.3

President of Federation of Telangana. Small Industries
Associations (FETSIA) or his nominee.
Member

19.2.4

Convener, SLBC or his nominee.

19.2.5

General Manager, A.P. State Financial
(Telangana Unit), Hyderabad or his nominee.

19.2.6

Chairman

Member
Corporation

19.2.9

Nominee of Managing Director, Telangana State Southern
Power Distribution Company Ltd., (TSSPDCL), Hyderabad
Nominee of Managing Director, , Telangana State Northern
Power Distribution Company Ltd., (TSNPDCL), Warangal
Nominee of Federation of Small and Medium Enterprises of
India (FSME-India)
Nominee of federation of Small &Medium enterprises of India

19.2.10

Nominee of Telangana Industrialists Welfare Federation(TIF)

19.2.11

Joint Director of Industries

19.2.7
19.2.8

19.3.0

Member
Member
Member
Member
Member
Member

Member
convener
SCRUTINY/VERIFICATION COMMITTEE FOR REIMBURSEMENT OF
COMMERCIAL TAX

19.3.1

Additional Director of Industries, Hyderabad.

Chairman

19.3.2

Joint Secretary to Government, Finance Department

Member

19.3.3

President of Federation of Telangana & A.P. Chamber of
Commerce and Industry or his nominee.
Member

19.3.4

President of FETSIA or his nominee.

Member

19.3.5

Convener, State Level Bankers Committee or his nominee.

Member

<!-- page 18 -->

19.3.6

General Manager, Telangana State Financial Corporation
Telangana State), Hyderabad or his nominee.
Member

19.3.7

Nominee of Commissioner, Commercial Taxes Department

Member

19.3.8

Nominee of Telangana Industrialists Welfare Federation(TIF)

Member

19.3.9

Joint Director of industries

MemberConvener

19.4.0

DISTRICT LEVEL SCRUTINY/VERIFICATION COMMITTEES

19.4.1.0

SCRUTINY/VERIFICATION COMMITTEE FOR INVESTMENT SUBSIDY
UNDER VARIOUS INCENTIVES/CONCESSIONS

19.4.1.1

General Manager, District Industries Centre

Chairman

19.4.1.2

Representative from Chamber of Commerce and Industry.

Member

19.4.1.3

Representative from Federation
Industries Associations (FETSIA)

Member

of

Telangana.

Small

19.4.1.4

Lead District Manager or his nominee.

Member

19.4.1.5

Manager, Telangana State Financial Corporation concerned

District

Member

Zonal Manager, T.S... Industrial Infrastructure Corporation
concerned District or his nominee.

Member

District Registration & Stamps, Revenue Department or his
nominee.

Member

19.4.1.8

Nominee of Telangana Industrialists Welfare Federation(TIF)

Member

19.4.1.9

Deputy Director concerned District

MemberConvener

19.4.1.6
19.4.1.7

19.4.2.0

SCRUTINY/VERIFICATION
POWER COST

COMMITTEE

19.4.2.1

General Manager, District Industries Centre

19.4.2.2

Representative from Telangana
Commerce and Industry.

& A.P.

Representative from Federation
Industries Associations (FETSIA)

of

19.4.2.3

FOR

REIMBURSEMENT
Chairman

Chamber of
Member

Telangana.

Small
Member

19.4.2.4

Lead District Manager or his nominee.

19.4.2.5

Manager, Telangana State Financial Corporation concerned
District
Member

19.4.2.6

Representative from DISCOM concerned

Member

19.4.2.7
19.4.2.8

Nominee of Telangana Industrialists Welfare Federation(TIF)
Deputy Director concerned District

Member
MemberConvener

19.4.3.0

OF

Member

SCRUTINY/VERIFICATION COMMITTEE FOR REIMBURSEMENT OF
COMMERCIAL TAX

19.4.3.1

General Manager, District Industries Centre

Chairman

19.4.3.2

Representative from Telangana
Commerce and Industry.

& A.P.

19.4.3.3

Representative from Federation
Industries Associations (FETSIA)

of

19.4.3.4

Lead District Manager or his nominee.

19.4.3.5

Manager, Telangana State Financial Corporation, District
concerned District
Member

19.4.3.6

Commercial Tax Officer, Commercial Taxes Department or
his nominee.
Member

Chamber of
Member

Telangana.

Small Member
Member

<!-- page 19 -->

19.4.3.7

Nominee of Telangana Industrialists Welfare Federation(TIF)

Member

19.4.3.8

Deputy Director concerned District

MemberConvener

20.0

POWERS OF SCRUTINY/VERIVICATION COMMITTEES OF DLC/SLC.

20.1.

After verifying of claim application along with Part-B of verification-cum-recommendation, the
Member-Convener will prepare the appraisal note for each case with the approval of the Chairman
SVC in the form prescribed for placing before respective Scrutiny-cum-Verification Committee for
recommending to the State Level/District Level Committee, as the case may be.

20.2.

The Scrutiny-cum-Verification Committees will meet as often as required, but not less than once in
two months. The Member - Convener will arrange to record the minutes of each meeting, get them
duly approved by the Additional Director concerned/General Manager concerned and will be placed
before State Level/District Level Committee.

20.3.

After receipt of Scrutiny-cum-Verification Committee recommendations, the Member-Convener of
State Level/District Level Committee will prepare the agenda note for placing before State
Level/District Level Committee for taking decision.

21.0.

IN RESPECT OF SELF FINANCE ENTERPRISES:

21.1.

All the Self Financed Industrial Enterprises should be inspected by respective Multi Disciplinary
Committee / Standing Scrutiny Committee and the Committee should verify the genuineness of
machinery to avoid bogus or false claims.

21.2.

The Multi Disciplinary Committee at district level shall inspect the Industrial Enterprises with
investment on Plant & Machinery up to Rs. 1.00 Crore with the following members:
(a) Assistant Commercial Tax Officer (ACTO) from Commercial Taxes Department:
(b) Manager, APSFC (Telangana Unit) District concerned; and
(c) General Manager, District Industries Centre concerned – Member Convener.

21.3.

The Standing Scrutiny Committee (SSC) shall inspect the Industrial Enterprises with investment on
Plant & Machinery over and above of Rs.1.00 Crore with the following members:
(i) Commercial Tax Officer concerned (CTO) from Commercial Taxes Department;
(ii) General Manager, APSFC-Telangana Unit of concerned District; and
(iii) Additional Director from Industries Department – Member Convener

21.4.

The following Sub-Committee of State Level Committee (SLC) will assist by inspecting the units
referred by SLC for taking a decision.
(a) President, FETSIA
(b) General Manager, APSFC-Telangana Unit concerned District
(c) Any other member as decided by SLC based on the need.
(d) Additional Director from Industries Department – Member Convener

21.4.0.

STATE LEVEL COMMITTEE ON INCENTIVES – LIST OF MEMBERS:

21.4.1

Commissioner of Industries, Hyderabad.

21.4.2

Additional Secretary/Joint Secretary/Deputy Secretary to Member
Government, Finance & Planning (Fin. Wing) Dept., Dealing
with the subject

21.4.3

Additional Secretary/Joint Secretary/Deputy Secretary to Member
Government, Industries & Commerce (IP) Department

21.4.4

President of Federation of Telangana & A.P. Chamber of Member
Commerce and Industry

21.4.5

The Chairman of Confederation of Indian Industry (CII)

21.4.6

The President of Federation of Telangana. Small Industries
Member
Associations (FETSIA)
The Chairman, Telangana Spinning Mills Association, Member
Hyderabad.

21.4.7
21.4.8

Chairman

Member

Managing Director, Telangana State Financial Corporation, Member
Hyderabad or his nominee.

<!-- page 20 -->

21.4.9

Managing Director, T.S. Industrial Infrastructure Corporation, Member
Hyderabad or his nominee.

21.4.10

Commissioner of Commercial Taxes, Hyderabad or his Member
nominee.

21.4.11

Commissioner of Tribal Welfare, Hyderabad or his nominee.

21.4.12

Commissioner of Development of
Department, Hyderabad or his nominee.

Scheduled

Caste Member

21.4.13

Director, Commercial, TSTRANSCO or his nominee

Member

21.4.14

Commissioner & Inspector General, Registration & Stamps, Member
Revenue Department or his nominee.

21.4.15

Member Secretary, Telangana State Pollution Control Board
or his nominee.
Member

21.4.16

Commissioner, Transport or his nominee

Member

21.4.17

Chief Commissioner, Land Administration or his nominee

Member

21.4.18

Convener, State Level Bankers Committee (SLBC)

Member

21.4.19

Nominee of Syndicate Bank

Member

21.4.20

Nominee of State Bank of India

Member

21.4.21

Nominee of State Bank of Hyderabad

Member

21.4.22

Nominee of Andhra Bank

Member

21.4.23

Telangana Industrialists Welfare Federation (TIF)

Member

21.4.24

Federation of Small and Medium Enterprises of India (FSME- Member
India)

21.4.25

Additional Director of Industries

21.4.26

The above Committee shall scrutinize and sanction the claims of enterprises /
industries involving eligible fixed capital investment on Plant & machinery
above Rs. 25.00 lakhs in case of Manufacturing unit and above 10 lakhs in case
of Service enterprise

Member

Member
Convener

21.5.0. DISTRICT LEVEL COMMITTEE ON INCENTIVES – LIST OF MEMBERS:
21.5.1
District Collector
Chairman
21.5.2

Deputy Commissioner of Commercial Taxes

Member

21.5.3

District Treasury Officer

Member

21.5.4

Project Officer, Integrated Tribal Development Authority
(I.T.D.A.) of the concerned District
Member
OR
District Tribal Welfare Officers of other Districts
Executive Officer, District Scheduled Castes Co-op. Finance
Corporation
Member

21.5.5
21.5.6

Branch Manager, Telangana State Finance Corporation

Member

21.5.7

Zonal Manager, T.S. Industrial Infrastructure Corporation

Member

21.5.8

Nominee of the President of Federation of Telangana and
Andhra Pradesh Chamber of Commerce and Industry
Member

21.5.9

Nominee of the President of FETSIA

Member

21.5.10

Chief Environmental Engineer, TSPCB

Member

21.5.11

Representative of RDO

Member

21.5.12

Superintending Engineer, TSTRANSCO

Member

21.5.13

District Registrar, Registrations & Stamps

Member

21.5.14

Nominee of Regional Transport Authority

Member

21.5.15

Lead District Manager

Member

21.5.16

Telangana Industrialists Welfare Federation (TIF)

Member

<!-- page 21 -->

21.5.16

General Manger, District Industries Centre

Member
Convener

21.5.17

The above Committee shall scrutinize and sanction the claims of the Micro
Enterprises (as defined by the Government of India from time to time) of the
District concerned involving cost of plant & machinery not exceed Rs. 25.00
lakhs (including the original investment in case of expansions and
diversifications) in case of manufacturing enterprises and not exceeding 10
lakhs in case of Service enterprises.

22.0.

POWERS OF STATE LEVEL AND DISTRICT LEVEL COMMITTEES.

22.1.

The State Level and District Level Committees will meet as often as required, but not less than
once in two months. The Member- Convener will arrange to record the minutes of each meeting,
get them duly approved by the Chair-person and communicate attested copies to all the members.

22.2.

The decisions of the State Level Committee shall be final in scrutinizing, deciding the eligible
investment, sanctioning the incentives. It can also review the decisions wherever is necessary. In
case of any doubt/ambiguity on any issue or item covered by these guidelines for implementing
the scheme of T-IDEA, 2014, the decision/interpretation of State Level Committee is final and
binding on all concerned. The District Level Committee will adopt norms evolved by the State
Level Committee.

22.3.

The State Level Committee has the powers to condone the Break-in-production period of
industrial Enterprises up to three (3) years. However, such Break-in-production period should be
due to the reasons beyond the control of the Management such as shortage of raw-materials, power
and change of management, etc.

22.4.

State Level Committee will review the working of the scheme and release of funds.

23.1.0.

WORK TO BE ATTENDED BY THE MEMBER - CONVENOR (SLC)

23.1.1.

Convening the SLC meetings, drawing up the minutes of the meetings and communicating these
to the members with the approval of the Chairperson;

23.1.2.

Disbursement of funds to the Enterprises/Industries sanctioned observing the chronological order
of sanctions within the set pattern and norms approved by SLC, if necessary.

23.1.3.

Arranging maintenance of records of sanctions / disbursements in the manner prescribed. The
incentive sanction register should be in the form prescribed.

23.1.4.

Monitoring effective implementation of the scheme.

23.2.0.

WORK TO BE ATTENDED BY THE MEMBER - CONVENOR (DLC)

23.2.1.

Convening the District Level Committee meetings, drawing up the minutes of the meetings and
communication to the members and the Commissioner of Industries with the approval of
Chairperson.

23.2.2.

Maintaining necessary accounts and registers and furnish details as and when called for by the
State Level Committee / Commissioner of Industries and producing to the audit. The incentive
sanction register should be in the form prescribed.

23.2.3.

Arranging periodical inspections of the beneficiary Enterprises and send reports on continuity in
working etc. to the Commissioner of Industries.

24.0.

PROCEDURE FOR DISBURSEMENT OF SUBSIDY:

24.1.

After the sanction of subsidy by SLC, the Joint Director/Deputy Director concerned shall
communicate the sanction through intimation letters in the form prescribed to the individual
industrial enterprises.

24.2.

In respect of District Level Committee sanctions, the General Managers shall communicate the
sanction through intimation letters in the form prescribed to the individual industrial enterprises
and shall forward the details of sanctioned cases to the Commissioner of Industries in statement in
the form prescribed.

24.3.

In respect of State Level Committee sanction the General Managers after receipt of individual
proceedings preceded by consolidated proceedings shall obtain an agreement bond in prescribed
pro-forma, advanced stamped receipt and assignment letter and forward the same in original to the
Commissioner of industries
after satisfying himself on the physical verification that the
Enterprise/ Industry is working continuously, the assets are intact and there is no change in the
management, no change of financial institution and also the Enterprise/ Industry complying with
the conditions, if any, imposed in the consolidated proceedings.

24.4.

The General Managers shall ensure that in case no bridge loan is availed by the beneficiary
Enterprise/Industry, the assignment of investment subsidy must be in favour of the term lending
institution and in the case of joint financing it must be in favour of the lead institution or to the
account of entrepreneurs incase of self-financed unit.

<!-- page 22 -->

24.5.

In case of disbursements of Reimbursements of Stamp duty and Transfer duty, rebate in land cost
in Industrial Estates/Industrial Development Areas, Power consumption charges, Commercial Tax,
such reimbursement amounts will be paid to the industrial Enterprises concerned, in favour of the
Enterprise/Industry through Real Time Gross Settlement /National Electronic Funds Transfer to
account.
The General Manager, District Industries Centers on receipt of the individual
proceedings shall obtain a self certification, utilization certificates in prescribed proforma and
advanced stamped receipt from the Enterprise/Industry and forward the same in original to the
Commissioner of Industries after physically verifying the running of the Enterprise/Industry.

24.6.

Government will allocate the funds for disbursement of incentives under the scheme. The funds
so allocated will be drawn and kept in the P.D.Account of Commissioner of Industries.

24.7.

The disbursements are made in a bunch of cases through consolidated proceeding separately for
State Level Committee sanctions and District Level Committees sanctions observing the
chronological order of such meetings held. The consolidated proceedings indicating the name of
the industry, amount sanctioned and amount released.

24.8.

In respect of State Level Committee sanctions, after the issue of individual proceedings issued by
the Member Convener of State Level Committee, in favour of industrial enterprises in the form
prescribed under copies to the Managing Director, Telangana State Finance Corporation, the
Branch Manager of TSFC / Financial Institutions which have sanctioned term loans and the
General Manager, District Industries Centers concerned. After receipt of assignment letter and
advance stamped receipt, the Commissioner of Industries shall release the subsidy amount to the
individual Enterprises account through Real Time Gross Settlement /National Electronic Funds
Transfer (RTGS/NEFT) (in whose favour assignment letter was given by the beneficiary industrial
enterprise A/c) and send the same to the respective Financial Institution direct under intimation to
the beneficiary. In case of industrial Enterprises which have availed any bridge loans against the
anticipated subsidy, the subsidy amount shall be released first to the Financial Institution which
has sanctioned and released bridge loan, to discharge the liability in full against such sanction and
balance amount, if any, would be released in the manner prescribed above.

24.9.

In respect of District Level Committee sanctions, the General Managers, District Industries
Center shall be forwarding the sanctions of District Level Committees to the Additional Director
of Industries and Member-Secretary of SLC along with statement in the form prescribed,
individual proceedings sanctioning after the issue of consolidated proceedings, individual
proceedings are issued in favour of individual Enterprises in the form prescribed under copies to
the Financial Institutions which have sanctioned term loans and working capital loans and General
Manager, DIC concerned. After receipt of assignment letter and advance stamped receipt, the
Commissioner of Industries shall release the subsidy amount to the individual Enterprises account
through RTGS/NEFT (in whose favour assignment letter was given by the beneficiary industrial
Enterprise A/c). In case of industrial Enterprises which have availed any bridge loans against the
anticipated subsidy, the subsidy amount shall be released first to the Financial Institution which
has sanctioned and released bridge loan, to discharge the liability in full against such sanction and
balance amount, if any, would be released in the manner prescribed above. The subsidy amount
released under the scheme is treated as front end subsidy and Bank/ Financial institution can only
adjust the liability as on date i.e. overdue amount and release the balance amount as per the
procedure in vogue and total subsidy released shall not be adjusted towards outstanding loan
amount.

24.10.

Wherever the General Manager, DICs finds an industrial enterprise sick, closed, change of
management taken place, change of financial institution etc. or for any other reason not worthy
of receiving subsidy till further examination, the Commissioner of Industries shall not disburse
the subsidy to such Enterprise/industry on written intimation given to them by the General
Managers DICs. In case of above two situations, the subsidy shall be disbursed only after further
clearance given by the State Level Committee.

25.0.

FUNCTIONS TO BE ATTENDED BY GENERAL MANAGER, DICs.

25.1.

Receiving and processing of claim applications and to ensure for placing the same before the
District Level Committees within a month in respect of District Level Committee cases and
submission to the Commissioner of Industries within one month in respect of State Level
Committee cases, with all necessary documents along with inspection report.

25.2.

To obtain stamped receipts and assignment letters in the appropriate forms besides inspecting the
Enterprises/industries to ensure working of the Enterprise/industry with the assets intact, no
change in the management, no change of financial institution etc., before disbursement of
subsidies.

25.3.

To initiate action to recover the incentives wherever warranted. In respect of Break-in-production
of Enterprise and break in partnership of ownership of the unit, the General Manager, District
Industries Centre concerned should monitor the progress of these Enterprises and submit report to
the Commissioner of Industries on half-yearly basis.

<!-- page 23 -->

25.4.

The General Manger, District Industries Centre shall receive the incentive applications and issue
acknowledgement to the Enterprise / Industries.

26.0

RECOVERIES OF SANCTIONED INCENTIVES UNDER THE SCHEME.
Incentives/concessions granted to an industrial enterprise shall be liable to be recovered in the
following circumstances.

26.1.

If the incentives/concessions are obtained by the industrial enterprise by misrepresentation of
essential facts or by furnishing of false information or suppressions of facts or by submission of
false/fake documents etc.,

26.2.

If the industrial enterprise goes out of production within six (6) years in respect of Micro & Small
Enterprises and ten (10) years in respect of Medium Enterprises & Large Industries/Mega Projects
from the date of commencement of commercial production, except in case where the
Enterprise/Industry remains out of production for short period upto 12 months due to the reasons
beyond its control such as shortage of raw-materials, power and change of management, bills
receivables, recession in the market etc.

26.3.

If the industrial enterprise fails to furnish the prescribed statements and/ or information when it is
called upon to furnish.

26.4.

If the industrial enterprise effects change of management without prior approval from the
financing institution concerned and the State Level Committee.

26.5.

If the industrial enterprise shifts a part or whole of the industrial Enterprise/Industry, or lease out
the whole or part of premises or the plant and machinery after receiving a part or whole of the
incentives without prior approval of the District Level Committee/State Level Committee.

26.6.

If the whole or part of the industrial enterprise is sold without the prior approval of the State Level
Committee.

26.7.

If the industrial enterprise enters into a contract of any nature whatsoever by transferring the
Management, without the prior approval of the State Level Committee.

26.8.

If the industrial enterprise goes for additional power load/expansion or diversification of the
Enterprise/Industry or change of line of activity already considered for sanction of incentives
without prior approval of State Level Committee.

26.9.

In the event of recoveries for reasons arising mentioned above, they shall be recovered treating
them as arrears of Land Revenue under A.P. Revenue Recovery Act, 1864.

26.10.

In this regard, the General Manager, District Industries Centre concerned should monitor the
progress of the Enterprises and submit report to the Commissioner of Industries on half-yearly
basis.

27.0

FURNISHING OF STATEMENT
INDUSTRIAL ENTERPRISES:

OF

ACCOUNT/INFORMATION

BY

ELIGIBLE

Industrial Enterprises, which obtain incentives under the scheme, shall furnish certified copy of
audited accounts including Balance Sheet before 30th June of the succeeding year to the
disbursing agencies i.e. to the General Manager, District Industries Centre, of District concerned.
Such statement should be furnished for a period of minimum within six (6) years in respect of
Micro & Small Enterprises and ten (10) years in respect of Medium Enterprises & Large
Industries/Mega Projects. Further, industrial Enterprises should also furnish details of production,
sales, employment, etc., in the proforma prescribed to the General Manager, District Industries
Centre concerned as an Annual Return before 30th June of the succeeding year and obtain
acknowledgment thereof. However, Enterprises which are released capital subsidy not exceeding
Rs.1, 00,000/-may furnish only the Annual Performance Report in the proforma prescribed to the
General Manager, DIC concerned as an Annual Return before 30th June of the succeeding year and
obtain acknowledgment thereof for a period of within six (6) years in respect of Micro & Small
Enterprises and ten (10) years in respect of Medium Enterprises & Large Industries/Mega Projects
after going into commercial production.
28.0

INTERPRETATIONS:
When any matter arises for the purpose of interpretation on which State Level Committee (SLC)
could not take a decision or in case where any suggestions are made outside the scope of SLC in
regard to implementation of the scheme, such matters shall be referred to the Government in
Industries & Commerce Department, Government of Telangana and the decision of the
Government shall be final.

<!-- page 24 -->

ANNEXURE: V
NORMS AS PER TECHNOLOGY MISSION ON COTTON FOR MODERN GINNING
ENTERPRISES/INDUSTRIES
I.

ELIGIBILITY CRITERIA:

a)

This subsidy scheme is available for setting up of new G & P factories as well expansion of
existing enterprises/industries.

b)

A Composite Enterprise/Industry intending establishes Enterprise/Industry with machinery
and civil infrastructure:

c)

A ginning Enterprise/Industry desirous of installing a bale press to make it a composite
Enterprise/Industry or a pressing Enterprise/Industry interested in setting up ginning facility;

d)

A factory interested in capacity expansion by addition of more ginning machines.

e)

As per TMC factory should possess all Essential Machines and Essential Infrastructure listed
below and must satisfy all Essential Conditions. An Enterprise/Industry proposing
modernisation or being set up with TMC assistance should be willing to maintain all records
and furnish all returns to the authorities concerned. It is also necessary that the
Enterprise/Industry does not avail of assistance under TUF scheme or any other subsidy
scheme of the Government of India.

II.
1.

COMPONENTS OF A GINNING & PROCESSING ENTERPRISE/INDUSTRY:

Essential Machines:
a)

Saw gins or double roller gins with auto feeders (single roller gins not permitted)

b)

Precleaner

c)

Lint Cleaner

d)

Mechanical/Pneumatic Conveyor System for transfer of kapas from heaps to
Precleaner(s) and from Precleaner(s) to individual gins. Central platform system not
permitted unless it already exists.

e)

Mechanical / Pneumatic Conveyor System for carrying lint from Gin House to Lint
Cleaner, from Lint Cleaner to Pala Halls and from Pala Halls to Press Hall. In case of a
new Bale Press, direct feeding from Pala Halls to the Press box. In case a factory des
not need Pala Halls, lint can be directly taken from Lint Cleaner to Bale Press.

f)

Bale Press with the following characteristics (in case of new installation)
(i)

Single stage operation

(ii)

Built-in Autotramper

(iii)

Oil hydraulic system

(iv) Lint Slide and Pusher mechanism
(v)

Press box dimensions meeting BIS requirements Existing presses without the
first four features will, however, be permitted.

g)

Conveyor for carrying seed from Gins to seed platform outside

h)

Humidifiers/ Moisturizers to maintain standard moisture in kapas in the Gin Hall and in
lint in the Pala Halls and Press Hall/ Lint Slide

i)

Fire fighting system comprising Overhead Tank/ Sump, Pump with stand-by Diesel
pump and Hydrants with Hose pipe and Nozzles

j)

Underground wiring/cabling both inside and outside buildings

k)

Weigh bridge (need not be installed if the facility is available nearby)

<!-- page 25 -->

2.

3.

4.

5.

Essential Infrastructure:
a)

Storage space for kapas

b)

Storage space for lint (Pala House)

c)

Storage space for seeds

d)

Storage space for bales

e)

C.C. Road

f)

Boundary wall/fence

g)

Any other item/ items approved by TMC

Essential Conditions:
a)

Quality awareness boards to educate workers

b)

Headgear/ cap for workers

c)

Periodic training for gin operators/ technicians on maintenance and repair of machines

d)

Arrangements for regular disposal of rubbish as soon as it accumulates

e)

Gummed boards to stick human hair picked up from floor, cotton heaps etc.

f)

Variety-wise and grade-wise heaping and ginning of cotton

g)

Insistence on covering of cotton brought in carts, tractors and lorries

h)

Bale packaging as per BIS specification

i)

Gin/ Press fitters in each shift

Desirable Machines:
a)

HVI for cotton testing

b)

Generator(s)

c)

Laboratory model gin

d)

Ginning Percentage Balance

e)

Moisture Meter

f)

Workshop machines and tools

g)

Roller grooving machine

h)

Pod opener / Kala machine

i)

Any other machine subject to TMC approval

Desirable Conditions:
a)

Bales to be covered with cotton cloth

b)

Press house to be close to gin house

c)

G&P Enterprises/industries to be in co-operative sector

III. FACILITIES EXPECTED TO BE ALREADY AVAILABLE:
a)

Adequate land

b)

Adequate supply of electricity

c)

Telephone facility

<!-- page 26 -->

IV. MINIMUM STANDARDS TO BE MAINTAINED IN RESPECT OF MACHINERY
AND CIVIL STRUCTURES IN G & P PROJECTS
SNo
1

2

3

4

5

6

7

Item

Minimum Requirements
Large Industry
Small Industry
Ginning
24 DRs of normal size / 22 extra-long 12 DRs of normal size / 11 extraMachines
DRs/ 18 Jumbo DRs with Auto feeder/ 3 long DRs/ 9 Jumbo DRs with Auto
saw gins (90 saws) or equivalent, with a feeder/ 1 or 2 saw gins with
processing capacity of 6-8 bales per hour. equivalent processing capacity of 34 bales per hour.
Precleaner
Cleaner with 4 or more beater cylinders / Cleaner with 4 or more beater
rolls with capacity to suit the processing cylinders / rolls with capacity to suit
speed of the ginning machines.
the processing speed of the ginning
machines.
Lint Cleaner
Cleaner with 3 or more beater cylinders / Cleaner with 3 or more beater
rolls with capacity to suit the processing cylinders / rolls with capacity to suit
speed of ginning machines.
the processing speed of ginning
machines.
Kapas
(i)
Pneumatic conveyor with Stone (i) Pneumatic conveyor with Stone
Conveyor
Catcher for the first stage from heaps to Catcher for the first stage from
System
Precleaner; (ii) Mechanical/Pneumatic heaps
to
Precleaner;
(ii)
conveyor from Precleaner to individual Mechanical/Pneumatic
conveyor
gins. Central Platform system not from Precleaner to individual gins.
permitted unless it exists already.
Central Platform system not
permitted unless it exists already.
Lint
Mechanical/ Pneumatic Conveyor
Mechanical / Pneumatic Conveyor
Conveyor
(i) from Gins to Lint Cleaner;
(i) from Gins to Lint Cleaner;
System
(ii) from Lint Cleaner to each Pala Hall
(ii) from Lint Cleaner to each
and
Pala Hall and
(iii) from each Pala Hall to
(iii)from each Pala Hall to
a. Bale Press Hall in case of
a. Bale Press Hall in case of
existing Conventional Bale
existing Conventional Bale
Press
Press
b. Bale Press box through Lint
b. Bale Press box through Lint
slide & Pusher Mechanisms in
slide & Pusher Mechanisms
case of modern Bale Press
in case of modern Bale
(direct feeding of cotton from Lint
Press
Cleaner to Press box permitted)
(direct feeding of cotton from Lint
Cleaner to Press box permitted)
Bale Press
Single stage oil hydraulic, auto tramping Single stage oil hydraulic, auto
Bale Press with Lint Slide and Pusher tramping Bale Press with Lint Slide
mechanism for direct feeding of lint into and Pusher mechanism for direct
the press box. Conventional water feeding of lint into the press box.
hydraulic, two-stage presses without auto Conventional water hydraulic, twotramping facility will, however, are stage presses without auto tramping
permitted if they already exist.
facility will, however, are permitted
if they already exist.
Conveyor for Automatic Conveyor from gins to Seed Automatic Conveyor from gins to
Seed
Platform
Seed Platform

8

Humidifier/
Moisturizer

9

Fire
Fighting
System

In Gin Hall
In case of Central Platform,
2 Benson fans or adequate number of
nozzles.
In Pala Halls
2 Benson fans in each Hall or adequate
number of nozzles.
Overhead tank/ sump (capacity 1.25 lakh
litres) with a minimum of 10 hydrants
strategically located, hose pipes with
nozzles and a stand-by diesel pump
besides an electric pump.

In Gin Hall
In case of Central Platform,
2 Benson fans or adequate number of
nozzles.
In Pala Halls
2 Benson fans in each Hall or
adequate number of nozzles.
Overhead tank/ sump (capacity
65,000 litres), with a minimum of 6
hydrants strategically located, hose
pipes with nozzles and a stand-by
diesel pump besides an electric
pump.

<!-- page 27 -->

10

Underground
Wiring

All high tension and low tension All high tension and low tension
wires/cables to be under-ground
wires/cables to be under-ground

11

Weigh Bridge

Capacity: 20 tons/ 5 tons depending on Capacity: 20 tons/ 5 tons depending
local need (Not required if the facility is on local needs (Not required if the
available nearby)
facility is available nearby)

12

Pucca
Platform
Kapas

13

Covered
Hall(s) with a minimum area of 4000 sq. Hall(s) with a minimum area of 2000
Storage Space ft., pucca floor and preferably plastered sq. ft., pucca floor and preferably
for Lint
walls.
plastered walls.
(Pala Halls)

14

Seed Platform

15

Bale Storage Platform with cemented floor adjoining Platform with cemented floor
Space
Press Hall and admeasuring a minimum adjoining
Press
Hall
and
area of 600 sq. ft., preferably with roof
admeasuring a minimum area of 600
sq. ft., preferably with roof

16

Road

17

Boundary
Wall/ Fence

Raised platform (3” CC cover) with a
for minimum of 10,000 sq. ft. area
preferably with 10 ft. wide cemented
pavement all around/1 ft. wall around.

Raised platform (3” CC cover) with a
minimum of 5,000 sq. ft. area
preferably with 10 ft. wide cemented
pavement around/1 ft. wall around.

Raised, cemented (3” CC cover) Raised, cemented (3” CC cover)
platform of minimum 2000 sq. ft. area, platform of minimum 1000 sq. ft.
with 2 ft. high outer wall
area, with 2 ft. high outer wall

CC Road (4.5” CC cover) with at least
10 ft. width preferably elevated
Wire mesh fence or barbed wire fence
with less than 1 ft. gap between wires, or
masonry wall, all of a minimum height of
6 ft.

CC Road (4.5” CC cover) with at
least 10 ft. width preferably elevated
Wire mesh fence or barbed wire
fence with less than 1 ft. gap between
wires, or masonry wall, all of a
minimum height of 6 ft.

<!-- page 28 -->

ANNEXURE: VI
APPLICATION CUM VERIFICATION FOR CLAIMING REIMBURSEMENT OF STAMP DUTY
/ TRANSFER DUTY / MORTGAGE DUTY / LAND CONVESERSION CHARGES /
REIMBURSEMENT OF LAND COST PURCHASED IN IE/IDA/IP’s UNDER T-IDEA
(TELANGANA STATE INDUSTRIAL DEVELOPMENT AND ENTREPRENEUR
ADVANCEMENT) INCENTIVE SCHEME 2014
(G.O.Ms.No.28 Industries and Commerce (IP & INF) Department. dated.29/11/2014)
1.0.
Details of Enterprise/Industry:
1.1. Name of the Enterprise:

1.2

Name of the Proprietor/Managing Partner / Managing Director:

1.3

TIN No. of the Enterprise/Industry/ Proprietor / Managing Partner / Managing Director:

1.4

PAN No. of the Proprietor / Managing Partner / Managing Director:

2.0.
2.1

Address of the Enterprise:
Office:

2.2

Factory location:

3.0. Status:
3.1
Category: (Pl.
Micro Enterprise
3.2.

mark)

Small Enterprise

Medium Enterprise

Constitution of the Organisation (Pl.

Proprietary

Partnership

Large Industry

Mega Project

mark)
Pvt. Ltd.

Limited

Coop.

3.3

Date of Commencement of Production:
(Date of Commencement of Production is the date of First Sale Bill/Invoice)
3.4
EM Part - II/IEM/IL No:
Date:
4.
Status of the Industry: (Pl.
mark)
New
7.

Expansion

Fixed Capital Investment(in Rs.)
Nature of Assets
New /Existing
Enterprise

(1)
Land
Building
Plant & Machinery

(2)

Diversification
Expansion/
Diversification
Project
(3)

% of increase under
Expansion/
Diversification Project
(4)

<!-- page 29 -->

Total
(If it is a new enterprise/industry, then column (3) and (4) need not be filled and it may be strike off)
6. Line of Activity.
Line of activity
Units i.e.
Values in
Nos. / Tons/ Capacity
Rs.
Ltrs.
New /Existing
Enterprise
Expansion/
Diversification
Project
% of increase under Expansion/ Diversification Project
Note: Enterprise/Industry involving at least 25% enhancement on fixed capital investment as well as
Capacity are eligible for claiming incentives under Expansion/Diversification projects:
Note: Sale deed/Lease deed should be registered in the name of Enterprise/Industry or Proprietor of
the Industry/Enterprise.
(in Sq. Mtrs.)
(in Sq. Mtrs.)
7.0 Land purchased
Plinth area of the
Building
(as per the registered sale deed)
(as per the approved building plan by the
HUDA/DT&CP/IALA
7.1. 5 times of the plinth area of factory buildings:
Sq.Mtrs.
7.2.

Area required for the factory as per the appraisal:

Sq.Mtrs.

7.3.

Area required for the factory as per the norms
of TSPCB or any other State Government Department:

Sq.Mtrs.

8.0.

Nature of transaction/deed registered for Indl. use (sale / lease or lease-cum-sale Transfer
deed/financial deeds and mortgages etc.).

9.0.

Date of registration:

10.0. Name of Sub-Registrar Office, where registered:
11.0

Stamp Duty/Transfer duty / Mortgage and Hypothecations Duty / Land Conversion Charges & Land
cost in IE/IDA/IP’s Paid:

11.1 In case of Stamp Duty/Transfer Duty paid:

Rs.

11.2 In case of Mortgage and Hypothecations Duty:

Rs.

11.3 In case of Land Conversion Charges:

Rs.

11.4 In case of lands purchased in IE/IDA/IP’s cost of land:

Rs.

Total
12.0

Rs.

Amount Claimed for Stamp Duty/Transfer Duty / Mortgage Duty / Land Conversion Charges/ Land
Cost purchased in IE/IDA/IP’s :

12.1 Stamp Duty/Transfer Duty:

Rs.

12.2

Mortgage and Hypothecations Duty:

Rs.

12.3

25% Land Conversion Charges:

Rs.

12.4

25% Land Cost purchased in IE/IDA/IP’s:
Total:

Rs.
Rs.

.

<!-- page 30 -->

DECLARATION
I am authorized to file this application and I will take full responsibility of the information mentioned. I / We
hereby confirm that to the best of our knowledge and belief, information given herein before and other
papers enclosed are true and correct in all respects. We further undertake to substantiate the particulars
about promoter(s) and other details with documentary evidence as and when called for. I/We hereby
agree that I/We shall forthwith repay the amount to me/us under scheme, if the amount of Stamp
Duty/Transfer Duty / Mortgage Duty / Land Conversion Charges/ Land Cost are found to be disbursed in
excess of the amount actually admissible whatsoever the reason.
Authorisation by the other Partners/Board of Directors Resolution wherein the Name, Designation and
signature are attested.
Place :
Date :

Signature of Authorised Person
with Name, Designation &Firm /Office Seal.

•
i.
ii.
iii.

The following documents are to be furnished:
Registered Land Sale Deed/Lease Deed/Transfer Deed/Land conversion documents.
Payment proof.
All the required documents as per Check-Slip at PART – C, for the first time of the claim.

13.0

RECOMMENDATION OF THE INSPECTING OFFICER:

(not to be filled by the Enterprise/Industry, to be filled by inspecting Officer)
13.1

Whether the Enterprise has already availed any exemption on
purchase of land, if so amount in Rs.

13.2

Stamp Duty/Transfer Duty:

Rs.

13.3

Mortgage and Hypothecations Duty:

Rs.

13.4

25% Land Conversion Charges:

Rs.

13.5

25% Land Cost purchase in IE/IDA/IP’s:

Rs.

The claim application of the captioned Enterprise/Industry is verified as per the operational guidelines. The
Enterprise/Industry is eligible for availing incentives under T-IDEA 2014. The Enterprise/Industry did not
add or removed any Plant & Machinery and there is no change of line of activity and capacity. Further, the
Enterprise/Industry is in continuous operation, there is no break-in-production (if not the details of the breakin-production) and I recommend the above incentives to the captioned Enterprise/Industry.

Signature of Inspecting Officer with Name & Designation.
Remarks of the General Manager:
The applicant Enterprise/Industry is eligible for above incentives and the claim is in order. The
computation of capital cost has been done as per the provisions under the scheme. I recommend for
sanction of above incentives.
Signature of General Manager with Office Seal.

Note: This application form, if photo copied must be exactly as per original & it must be both sides of the
page.

<!-- page 31 -->

ANNEXURE: VII
APPLICATION CUM VERIFICATION FOR REIMBURSEMENT OF POWER TARIFF UNDER
T-IDEA (TELANGANA STATE INDUSTRIAL DEVELOPMENT AND ENTREPRENEUR
ADVANCEMENT) INCENTIVE SCHEME 2014
(G.O.Ms.No.28 Industries and Commerce (IP & INF) Department. dated.29/11/2014)
1.0. Details of Industry:
1.1. Name of the Enterprise:

1.2

Name of the Proprietor/Managing Partner / Managing Director:

1.3

TIN No. of the Enterprise/Industry/ Proprietor / Managing Partner / Managing Director:

1.4

PAN No. of the Proprietor / Managing Partner / Managing Director:

2.0.
2.1

Address of the Enterprise:
Office:

2.2

Factory location:

3.0.Status:
3.1

Category : (Pl.

Micro Enterprises
3.2

mark)
Small Enterprises

Medium Enterprises

Constitution of the Organisation (Pl.
Proprietary

Partnership

3.3 Status of the Industry: (Pl.
New Industry
3.4
3.5
3.6

Large Industry

mark)
Pvt. Ltd.

Limited

Coop.

mark)
Expansion

Diversification

Date of Commencement of Production:
(Date of Commencement of Production is the date of First Sale Bill/Invoice)
EM Part - II/IEM/IL No:
Date:
Employment in Nos.
a) Management & Staff
b) Supervisory
c) Workers

Male

Female

<!-- page 32 -->

4. Fixed Capital Investment(in Rs.)
Nature of Assets
New /Existing
Enterprise

Expansion/
Diversification
Project
(3)

% of increase under
Expansion/
Diversification Project
(4)

(1)
(2)
Land
Building
Plant & Machinery
Total
(If it is a new enterprise/industry, then column (3) and (4) need not be filled and it may be strike off)
5. Line of Activity.
Line of activity
Units i.e.
Values in
Nos. / Tons/ Capacity
Rs.
Ltrs.
New /Existing
Enterprise
Expansion/
Diversification
Project
% of increase under Expansion/ Diversification Project
Note: In respect of Expansion/Diversification projects, Enterprises involving at least 25%
enhancement on fixed capital investment as well as Capacity are eligible for claiming incentives:
6.

Employment:

Male
(Nos.)

Female
(Nos.)

Total units
consumed

Total amount paid
by the in Rs.

a) Management & Staff
b) Supervisory
c) Workers
7

Existing power connection in HP

8

New power connection in HP

9

Date of new power connection
released.
Power utilized during previous
three financial years before this
expansion/ diversification
project

10

Sl.
No.
1
2

Financial
Year

3
11 Details of Energy consumed from the date of commencement of production and amount
claimed for the Half year **
1st half year
2nd half year
st
th
st
1 April to 30 September
1 October to 31st March
No. of units
Amount paid in Rs.
No. of units
Amount paid in Rs.
Financial year
consumed

consumed

1.
2.
3.
4.
5.
** Half year means every six months from the financial year beginning from 1st April to 31st March.

12. Claim applied for (Amount in Rs.)

<!-- page 33 -->

DECLARATION
I / We hereby confirm that to the best of our knowledge and belief, information given herein and other
papers enclosed are true and correct in all respects. We further undertake to substantiate the particulars
about promoter(s) and other details with documentary evidence as and when called for.
I/We hereby agree that I/We shall forthwith repay the amount to me/us under scheme, if the amount of
Reimbursement of power tariff is found to be disbursed in excess of the amount actually admissible
whatsoever the reason.
Certified that this amount has not been claimed earlier. In case of a wrong claim I shall repay the entire
amount of concession(s) availed under T-IDEA Scheme 2014 in Lump sum with prevailing interest.
Station :
Date :

Signature of Authorised Person
with Firm /Office Seal.

• The following documents are to be furnished:
a) Power release certificate issued by DISCOM concerned for the first time of the claim.
b) Power Bill and payment proof/receipts from DISCOM concerned.
c) Self Certification prescribed at Form – B.
d) Power utilization Particulars for the last –3- years and Column No. 4 & 5 of the application duly
certified by Chartered Accountant for the first time of the claim if it is Expansion/Diversification
Project.
e) Valid Consent for Operation (CFO) from TSPCB/Acknowledgement from General Manager, District
Industries Centre concerned on pollution angle.
f) All the required documents as per Check-Slip at PART – C, for the first time of the claim.
13. RECOMMENDATION OF THE INSPECTING OFFICER:
(not to be filled by the Enterprise/Industry, to be filled by inspecting Officer)

a. Amount claimed in Rs.

:

b. Amount recommended in Rs.

:

The claim application of the captioned Enterprise/Industry is verified as per the operational guidelines. The
Enterprise/Industry is eligible for availing incentives under T-IDEA 2014. The Enterprise/Industry did not
add or removed any Plant & Machinery and there is no change of line of activity and capacity. Further, the
Enterprise/Industry is in continuous operation, there is no break-in-production (if so the details of the breakin-production) and I recommend the above incentives to the captioned Enterprise/Industry.

Signature of Inspecting Officer with Name & Designation.
Remarks of the General Manager:
The applicant Enterprise/Industry is eligible for above incentives and the claim is in order. The
computation of capital cost has been done as per the provisions under the scheme. I recommend for
sanction of above incentives.
Signature of General Manager with Office Seal.
Note: This application form, if photo copied must be exactly as per original & it must be both sides of the
page.

<!-- page 34 -->

ANNEXURE: VIII
APPLICATION CUM VERIFICATION FOR CLAIMING INVESTMENT SUBSIDY UNDER TIDEA (TELANGANA STATE INDUSTRIAL DEVELOPMENT AND ENTREPRENEUR
ADVANCEMENT) INCENTIVE SCHEME 2014
(G.O.Ms.No.28 Industries and Commerce (IP & INF) Department. dated.29/11/2014)
PART - A
CLAIM
To be filled by DIC/ Commissionerate of Industries.
Date of receipt in DIC:
DIC File No.:
Date of receipt in Commissionerate:
Commissionerate File No.:
To be filled by Applicant
1.0.
Details of Industry:
1.1. Name of the Enterprise:

1.2

Name of the Proprietor/Managing Partner / Managing Director:

1.3

TIN No. of the Enterprise/Industry/ Proprietor / Managing Partner / Managing Director:

1.4

PAN No. of the Proprietor / Managing Partner / Managing Director:

2.0.
2.1

Address of the Enterprise:
Office:

2.2

Factory location:

3.0.Status:
3.1

Category : (Pl.

Micro Enterprises
3.2.

mark)
Small Enterprises

Medium Enterprises

Constitution of the Organisation & Industry status (Pl.
Proprietary

3.3.

New Industry
3.4
3.5

Partnership
Expansion

Pvt. Ltd.

Large Industry

mark)
Limited
Diversification

Date of Commencement of Production:
(Date of Commencement of Production is the date of First Sale Bill/Invoice)
EM Part - II/IEM/IL No:
Date:

<!-- page 35 -->

4.0.
4.1.

Project Details:
New Enterprise.
Line of activity

4.2.

Unit

Installed capacity

Expansion/ Diversification Project
Line of activity

Value

Installed Capacity
(in Enterprises)

% of increase under
Expansion/ Diversification
Project

Existing Enterprise
Expansion/
Diversification Project
4.3.
Fixed Capital Investment(in Rs.)
Nature of Assets
Existing Enterprise
Land
Building
Plant & Machinery
Total
5.0. Social Status (Pl.
SC
5.1

Under Expansion/
Diversification
Project

% of increase under
Expansion/
Diversification Project

mark)

ST

Women

Others

Details of the Director(s) / Partner(s):
Name

Community

Share

%

i)
ii)
iii)
iv)
6.0.
6.1.

Power
Power released Date

6.2.

Contracted load

6.3.

Connected load

6.4

Employment:
a) Management & Staff
b) Supervisory
c) Workers

7.0.

Implementation Steps taken:

7.1.
7.2.

Project Finance:
Date of Application for term loan

7.3.

Name of the Instn. (with lead Institution in the event
of joint or consortium financing)

7.4.
7.5.

Term loan sanctioned reference No. :
Date:

Male
(Nos.)

Female
(Nos.)

<!-- page 36 -->

8.0.

Approved / Estimated Project cost, Term loan sanctioned
and released, assets acquired etc.
Name of
Approved Loan
Equity
Loan
Value of
Asset
Project
Sanct- from the
Amount
assets
Cost
ioned
promoters Released (as certified
by financial
institution).
1

8.1.
8.2.
8.3.
8.4
8.5.
8.6.

8.7.

2

3

4

5

Value of
assets
certified by
Chartered
Accountant

6

7

Land
Buildings
Plant &
Machinery
Machinery
contingencies
Erection
Technical
know-how,
feasibility
study
Working
capital
Total

Note : The data on the above should be prior to date of filing of claim or within 6 months of
Commencement of production, whichever is earlier in case of aided Enterprise/Industry. If it
is self financed Enterprise/Industry, the data on the above should be prior to date of
commencement of Commercial Production.
9.0

Total amount of subsidy already availed:
9.1.

Scheme

:

9.2.

Amount

:

10.0

11.0.

Second Hand
Machinery
value in Rs

New
Machinery
value in
Rs.

Total
Value in
Rs. (1+2)

% of Second
Hand Machinery
value in the
Total Machinery
value.

1

2

3

4

Value of the
Machinery
purchased from
APIDC(Telangana
Unit)/
APSFC(Telangana
Unit)/ Bank in Rs.
5

Total
value in
Rs.
(2+5)

6

Registration with Commercial taxes Department Registration,
VAT No.

:

Date

CST

:

Date

No.

Concerned Authority
:
ACTO/C.T.O./D.C.T.O./Dy Commissioner
Address
:
12.0.
Incentives applied for (in Rs.) on fixed capital investment:
12.1.

Investment Subsidy

12.2. An additional investment subsidy
for Women entrepreneurs.

: Rs.
: Rs.

<!-- page 37 -->

12.3. An additional investment subsidy
for SC/ST entrepreneurs

: Rs.

12.4. An additional investment subsidy for
Women entrepreneurs set up in
Scheduled areas

: Rs.

Total
13.1.

: Rs.

DECLARATION
I / We hereby confirm that the contents of the claim application are true to the best of my /our
knowledge.

13.2.

I / We abide by the provision under T-IDEA,2014,incentive scheme, State Incentives and
further abide by the changes / modifications made by the State Government under
G.O.Ms.No.28 Industries and Commerce (IP) Department., dated.29/11/2014. I / We also abide
by the decisions of Industries & Commerce Department.

13.3.

I / We shall not change the location of the whole or part of the industrial Enterprise or effect any
substantial contraction or disposal of substantial part of its total capital investment within a
period of six (6) years from the date of commencement of commercial production.

13.4.

I / We assure that the State incentives (Capital subsidy) applied for will be used solely for the
development of the Enterprise and shall produce utilisation certificate to the District Industries
Centre (DIC) within one year and furnish annual progress report and certified copy of audited
accounts to the DIC for a period of six (6) years.

13.5.

I / We confirm that subsidy was already availed under the Government schemes mentioned at
para No.9.0.

13.6.

If the amount of Investment Subsidy are found to be disbursed in excess of the amount actually
admissible whatsoever the reason, I/We hereby agree that I/We shall forthwith repay the amount
released to me/us under the scheme.

13.7.

I / We shall agree that apart from other consequences, I / We will forego the eligibility for the
continuance of incentives and other financial concessions for further years if these incentives /
financial concessions were obtained by misrepresentation of facts or in case of misutilisation. I
/ We not only agree to pay back these incentives / financial concessions but also authorise State
Government to call back the same through summary proceedings under the provisions of
R.R.Act 1864.

Station :
Date :

Signature of Authorised Person
with Firm /Office Seal.

CHARTERED ACCOUNTANT CERTIFICATE
I/We hereby confirm that I/We have examined the prescribed registers, books of account and the bank
statement in respect of the above Enterprise and Certified to be true the expenditure under Col(7) of
Sl.No. 8.0.
I/We fully understand that any submission made in this certificate if proved incorrect or false, will render
me/us liable to face any penal action or other consequences as may be prescribed in the law or otherwise
warranted.
Signature & Stamp/seal of the Signatory______________
Name___________________________________________
Membership No.__________________________________
Full address_____________________________________
Name and address of the Institution where registered.
Date:
Place:
Note: This application form, if photo copied must be exactly as per original & it must be both sides of the
page.

<!-- page 38 -->

FOR OFFICIAL USE IN DIC OFFICE
PART - B
VERIFICATION -CUM- RECOMMENDATION OF G.M, DIC
1.1.

Name and Address of the Industry

:

1.2.

Name of the Inspecting Officer

:

1.3.

Designation

:

1.4.

Date(s) of Inspection

:

1.5.

Constitution

:

1.6.

Person (from Industry) present at
the time of Inspection.

:

1.7.

Status of the Industry/Enterprises

:

2.0.

Verification certificate

Proprietary/Partnership/Pvt. Ltd./Limited/Coop.

New / Expansion / Diversification

Certified that contents of the claim under Part-A and the document indicated in Part-c of this claim
application were verified and found correct. The plant and machinery and equipment was physically verified
as per the statement of machinery and found them duly installed and put on work . Further certified that the
fixed assets claimed for incentives are essentially required for carrying the production in which the industry
is engaged in.
3.0.
3.1.

Project Details:
New Enterprise.
Line of activity

Unit

3.2. Expansion / Diversification Project
Line of activity

Installed capacity

Installed Capacity
(in units)

Value

% of increase under
Expansion/ Diversification
Project

Existing Enterprise
Expansion/
Diversification Project
3.3. Fixed Capital Investment of the Expansion / Diversification Project (in Rs.)
Nature of Assets
Existing Enterprise
Expansion/
% of increase under
Diversification
Expansion/
Project
Diversification Project
Land
Building
Plant & Machinery
Total
Date of commencement of production
3.4
3.5

Date of receipt of claim application

3.6

Date of issue of Regd. Notice calling
shortfall documents/information
Date of claim taken to call book due to
non Receipt of shortfalls documents
Date
of
receipt
of
shortfall
documents/information.

3.7
3.8

<!-- page 39 -->

4.0.0 Capital cost computed & recommended in Rs.
4.1.0 Land:
4.1.1. Extent in Sq.Mtrs
Built up area in
Sq.Mtrs

5 times built up
area in Sq.Mtrs

Extent eligible in
Sq.Mtrs

4.1.2 Claim application submitted by the Enterprise for reimbursement of Stamp Duty: Yes / No.
4.1.3 Claim application submitted by the Enterprise for reimbursement of Land Cost:
Yes / No.
(if, the Enterprise submitted the claim applications for sanction of 25% Land cost, the
GM, DIC concerned should not consider the land value for computation of fixed capital
investment)
(in Rupees)
4.1.4. Land cost
Regn. Fees Total
Approved Project
Proportionate eligible
cost
value
4.1.5
4.2.0
4.2.1
4.2.2

4.2.3

Computed cost

Rs.

Building and other civil works:
Approved Project cost :
Value of the items Plinth area
8.2.2 to 8.2.10 of
guideline

Rate as per
APSFC norms

the

Value

Total value of 100 % Items
Rs.
Value of the items 8.2.11 to 8.2.17 and similar items of guidelines not to exceed 10%
of the total value of the civil works.

4.2.4
4.2.5
4.2.6

Total Value 10% Items
Grand Total Value 100% + 10% Items
As per approved project cost
As per Civil
Certificate

4.2.7

Computed cost :

Rs.
Rs.
Engineer Computed value by
the GM

Rs.

4.3.0 Plant and Machinery and Equipment ( PM&E) :
4.3.1.
As
per As per list Tech.Know how 2nd
hand % of 2nd
approved
of Plant & and study and machinery hand
project cost Machinery
Machinery
turnkey charges Value
not to exceed
10% of PM & E
4.3.2
4.4.0.

Computed Cost:

Total

Rs.

Total Cost computed:
(In Rupees)

4.4.1

5.0

Land (4.1.5)
Buildings (4.2.7)
Plant & Machinery (4.3.2)
Total
Recommended for sanction of investment subsidy mentioned below:
Investment Subsidy
5.1.

Investment Subsidy

: Rs.

5.2.

An additional investment subsidy
for Women entrepreneurs.

: Rs.

<!-- page 40 -->

5.3.
5.4.

An additional investment subsidy
for SC/ST entrepreneurs

: Rs.

An additional investment subsidy for
Women entrepreneurs set up in
Scheduled areas
: Rs.

Total

: Rs.
Signature of inspecting Officer with Designation.

Remarks of the General Manager

:

The industrial entrepreneur acquired open land and established the industry/enterprise, hence
previously not availed any incentives by the any industry/enterprise on this land. The industrial
entrepreneur acquired the land and building on leased basis, previously not availed any incentives by
the any industry/enterprise in this location. If, any Enterprise/Industry availed incentives under any
scheme in the same location, may be sent details thereof.
The applicant Enterprise is eligible for said incentives and the claim is in order. The computation of
capital cost has been done as per the provisions under the scheme only. I recommend for sanction of
incentives.
Signature of General Manager with Office Seal.

<!-- page 41 -->

TO BE FILED BY APPLICANT
PART - C
CHECK – SLIP
1.0.

Document Enclosed

1.1.

Certificate from the financing institution concerned showing term loan released and the value of
assets acquired as on prior to filing of claim/within 6 months from the date of commencement of
commercial production whichever is earlier together with other details and machinery statement as a
statement of account in the form prescribed with attested copies of bills in case of institutionally
financed Enterprises/industries.
OR
List of Plant & Machinery & Equipment purchased and installed in the prescribed form with attested
copies of bills and payment proof in respect of self financed Enterprises/industries.

1.2.

2.1.

Caste Certificates issued by M.R.Os concerned
in case of SC/ST Entrepreneur
Certificate from the Chartered Accountant
and % of holding of equity in the company by
each partner/director.
Regd. Partnership Deed/Articles of Association and
Memorandum of Association in case of Pvt. Ltd and
Limited companies along with incorporation certificate/
Bye-laws in case of Indl. Cooperative along with
Registration Certificate.
Documents in original to be produced to the inspecting officer of DIC
for verification (tick appropriate)
Approval of Director of Factories

2.2.

Boilers Certificate

Yes/No/N.A

2.3.

Approval of Director of Town & Country Planning / UDA

Yes/No/N.A

2.4

Regular building plans approval of Municipality or
Gram Panchayat.

Yes/No/N.A

1.3.
1.4.

2.0.

2.5.

Yes/No/N.A
Yes/No/N.A
Yes/No/N.A

Yes/No/N.A

Consent for Operation from TSPCB/Acknowledgement from
the General Manager, DIC concerned

Yes/No/N.A

2.6.

Power release Certificate from TSTRANSCO/DISCOM

Yes/No/N.A

2.7.

Environmental clearance

Yes/No/N.A

2.8.

Other statutory approvals (specify)

Yes/No/N.A

2.9. EM Part – I full set/IEM/IL
2.10. EM Part – II full set/IEM/IL

Yes/No/N.A
Yes/No/N.A

2.11. Project Report
2.12. Term loan sanction letters
2.13 Board Resolution authorizing to sign and file claim etc.,
in case of Pvt./Ltd., Companies, Cooperatives and similar
authorization in respect of partnership firms.
2.14 Registered land Sale deed/Premises Lease deed
2.15 C.A. and C.E. Certificate regarding 2nd hand plant & machinery
2.16. C.E. Certificate for Self fabricated machinery
2.17. BIS Certificate
2.18. Drug License
2.19. Explosive License
2.20. VAT/CST/SGST Certificate
2.21. Form – A
2.22. Form – B

Yes/No/N.A
Yes/No/N.A
Yes/No/N.A
Yes/No/N.A
Yes/No/N.A
Yes/No/N.A
Yes/No/N.A
Yes/No/N.A
Yes/No/N.A
Yes/No/N.A
Yes/No/N.A
Yes/No/N.A

N.A: = Not Applicable

Signature of Authorised Person with firm / Office Seal

<!-- page 42 -->

REMARKS OF THE INSPECTING OFFICER
Verified all the above documents submitted by the Entrepreneur and found correct.

Signature of Inspecting Officer with Designation/ General Manager.

<!-- page 43 -->

ANNEXURE: IX
APPLICATION -CUM -VERIFICATION FORM FOR REIMBURSEMENT OF
INTEREST SUBSIDY UNDER 'PAVALA VADDI SCHEME' / INTEREST SUBSIDY UNDER TIDEA (TELANGANA STATE INDUSTRIAL DEVELOPMENT AND ENTREPRENEUR
ADVANCEMENT) INCENTIVE SCHEME 2014
(G.O.Ms.No.28 Industries and Commerce (IP & INF) Department. dated.29/11/2014)
1.0

Details of Enterprise:

1.1.

Name of the Enterprise:

1.2

Name of the Proprietor/Managing Partner / Managing Director:

1.3

TIN No. of the Enterprise/Industry/ Proprietor / Managing Partner / Managing Director:

1.4

PAN No. of the Proprietor / Managing Partner / Managing Director:

1.5. PAN no of the enterprise
1.6. Constitution of the Entrepreneur. (Pl.

mark)

Proprietary

Pvt. Ltd.

2.0.

Partnership

Social Status (Pl.

2.1 SC
2.2.

Limited

Coop.

mark)
ST

Women

Others

Details of the Director(s) / Partner(s):
Name

Social
status
SC/ST

Shares
value
in Rs.

% M/F

i)
ii)
iii
iv)
v))
2.3 If SC, ST & Women please indicate % Share in the equity :
3.0 .
3.1

Address of the Enterprise:
Factory location:

3.2

Office:

4.0 New Enterprise Details :
3.3

Date of Commencement of Production:
(Date of Commencement of Production is the date of First Sale Bill/Invoice)

<!-- page 44 -->

3.4

EM Part - II/IEM/IL No:
Date:

5. Line of Activity :
Line of activity

Installed Capacity

1
2
3
6. Fixed Capital Investment:
6.1 Nature of Assets
Land
(only 5 times the building area to be
considered)
Building
Plant & Machinery
Total

Units
(Nos./Tons/
KLts.)

Amount in Rs.

7. Details of Term Loan Sanctioned and Availed :
Name of the
Loan A/c
Sanction
Amount
Financial
No.
order
sanctioned
Institution
No & Date
( Rs.)
1
2
3
4
8. Pavala Vaddi claimed:
Interest on
Rate of interest
Term loan on
%
Half yearly
basis
1
2

Value in Rs.

Interest
paid (Rs)
excluding penal
interest
3

Rate of
Interest
%
5

Term loan
released ( Rs.)
6

Eligible
(maximu
m9%)

Amount claimed
(Rs.)

4

5

DECLARATION
I / We hereby confirm that to the best of our knowledge and belief, information given herein before and
other papers enclosed are true and correct in all respects. We further undertake to substantiate the
particulars about promoter(s) and other details with documentary evidence as and when called for.
I/We hereby agree that I/We shall forthwith repay the amount to me/us under scheme, if the amount of
Interest Subsidy are found to be disbursed in excess of the amount actually admissible whatsoever the
reason.
Station :
Date :

Signature of Authorised Person
with Firm /Office Seal.
CHARTERED ACCOUNTANT CERTIFICATE

I/We hereby confirm that I/We have examined the prescribed registers, books of account and the bank
statement in respect of M/s ....................................................................(enterprise).
I/ We hereby certify that the above figures furnished by the Enterprise holder are verified with the
records of the Enterprise /Enterprise as per the provisions stipulated in G.O.Ms.No.28 Industries and
Commerce (IP&INF) Department., dated.29/11/2014.
I/We fully understand that any submission made in this certificate if proved incorrect or
false, will
render me/us liable to face any penal action or other consequences as may be prescribed in the law or
otherwise warranted.
Signature & Stamp/seal of the Signatory______________
Name_________________________________________
Membership No.________________________________
Full address____________________________________

<!-- page 45 -->

Name and address of the Institution where registered.
Date:
Place:
• The following documents are to be furnished:
a) Term loan Sanction letter
b) Certificate from financial institutions in prescribed form.
g) Valid Consent for Operation (CFO) from TSPCB/Acknowledgement from General Manager, District
Industries Centre concerned on pollution angle.
d) All the required document as per Check-Slip at PART – C, for the first time of the claim.
9. RECOMMENDATION OF THE INSPECTING OFFICER:
(not to be filled by the Enterprise/Industry, to be filled by inspecting Officer)

a. Amount claimed in Rs.

:

b. Amount recommended in Rs.

:

The claim application of the captioned Enterprise/Industry is verified as per the operational guidelines. The
Enterprise/Industry is eligible for availing incentives under T-IDEA 2014. The Enterprise/Industry did not
add or remove any Plant & Machinery and there is no change of line of activity and capacity. Further, the
Enterprise/Industry is in continuous operation, there is no break-in-production (break-in-production, the
details there of) and I recommend the above incentives to the captioned Enterprise/Industry.
Signature of Inspecting Officer with Name & Designation.
Remarks of the General Manager:
The applicant Enterprise/Industry is eligible for above incentives and the claim is in order. The
computation of capital cost has been done as per the provisions under the scheme. I recommend for
sanction of above incentives.
Signature of General Manager with Office Seal.

Note: This application form, if photo copied must be exactly as per original & it must be both sides of the
page.

<!-- page 46 -->

ANNEXURE: X
APPLICATION CUM VERIFICATION FOR GRANT OF SEED CAPITAL ASSISTANCE UNDER
T-IDEA (TELANGANA STATE INDUSTRIAL DEVELOPMENT AND ENTREPRENEUR
ADVANCEMENT) INCENTIVE SCHEME 2014
(G.O.Ms.No.28 Industries and Commerce (IP & INF) Department. dated.29/11/2014)
1.0
Details of Industry:
1.1. Name of the Enterprise:

1.2

Name of the Proprietor/Managing Partner / Managing Director:

1.3

TIN No. of the Enterprise/Industry/ Proprietor / Managing Partner / Managing Director:

1.4

PAN No. of the Proprietor / Managing Partner / Managing Director:

1.5

Details of the Director(s) / Partner(s):
Name

Community

Share

%

i)
ii)
iii)
iv)
2.0
2.1

Address of the Enterprise:
Office:

2.2

Factory location:

3.0.Status:
3.1. Constitution of the Organisation (Pl.
Proprietary
3.2

Partnership

Pvt. Ltd.

mark)
Limited

Coop.

Date of Commencement of Production:
(Date of Commencement of Production is the date of First Sale Bill/Invoice)
3.3
EM Part - II/IEM/IL No:
Date:
3.4. Line of Activity.
Line of activity
Installed Capacity

<!-- page 47 -->

4.0.Status:
4.1. Social Status (Pl.
SC

mark)

ST

Women

If SC, ST & Women please indicate % Share in the equity.
4.2

Details of the Director(s) / Partner(s):
Name

Comm
E t
i

i)

Share

%

ii)
iii)
iv)
5.0.
5.1.

Power
Power Supply Date

5.2.

Enterprise Contacted load

5.3.
6.0.

Connected load
Approved / Estimated Project cost, Term loan sanctioned and
released, assets acquired etc.
Name of
Asset

6.1.
6.2.
6.3.
6.4

6.5.

6.6.
6.7.

1
Land
Building
Plant &
Machinery&
Equipment
Preliminary
& Pre
operative
expenses
Tech. know
how /
feasibility
study /
Turnkey
charges.
Working
Capital
Others.
Total

Approved
Project
Cost

Loan
Sanctioned

Equity from
promoters

Loan
Amount
Released

Value of
assets
acquired
( as certified
by financial
institution.

Value of
assets
certified by
Chartered
Accountant

2

3

4

5

6

7

7. Registration with Commercial taxes Department Registration,
VAT No.
:
Date
CST No.
:
Date
Concerned Authority
:
ACTO/C.T.O./D.C.T.O./Dy Commissioner
Address
:

<!-- page 48 -->

DECLARATION
I / We hereby confirm that to the best of our knowledge and belief, information given herein
before and other papers enclosed are true and correct in all respects. We further undertake to
substantiate the particulars about promoter(s) and other details with documentary evidence as
and when called for.
I/We hereby agree that I/We shall forthwith repay the amount to me/us under scheme, if the
amount of seed capital assistance are found to be disbursed in excess of the amount actually
admissible whatsoever the reason.
Station :
Date :

Signature of Authorised Person
with Firm /Office Seal.
CHARTERED ACCOUNTANT CERTIFICATE

I/We hereby confirm that I/We have examined the prescribed registers, books of account and the
bank statement in respect of the above Enterprise.
I/We fully understand that any submission made in this certificate if proved incorrect or false, will
render me/us liable to face any penal action or other consequences as may be prescribed in the law or
otherwise warranted.
Signature & Stamp/seal of the Signatory______________
Name___________________________________________
Membership No.__________________________________
Full address____________________________________
Name and address of the Institution where registered.
Date:
Place:
• The following documents are to be furnished:
a) Sanction letter of term loan and seed capital loan from Financial Institution.
b) Memorandum of Articles/Registered Partnership Deed
c) EM Part – I / Part – II full set.

8. RECOMMENDATION OF THE INSPECTING OFFICER:
(not to be filled by the Enterprise/Industry, to be filled by inspecting Officer)

a. Amount claimed in Rs.

:

b. Amount recommended in Rs.

:

The claim application of the captioned Enterprise/Industry is verified as per the operational guidelines. The
Enterprise/Industry is eligible for availing incentives under T-IDEA 2014. The Enterprise/Industry did not
add or removed any Plant & Machinery and there is no change of line of activity and capacity. Further, the
Enterprise/Industry is in continuous operation, there is no break-in-production (if so the details of the breakin-production) and I recommend the above incentives to the captioned Enterprise/Industry.
Signature of Inspecting Officer with Name & Designation.
Remarks of the General Manager:
The applicant Enterprise/Industry is eligible for above incentives and the claim is in order. The
computation of capital cost has been done as per the provisions under the scheme. I recommend for
sanction of above incentives.
Signature of General Manager with Office Seal.
Note: This application form, if photo copied must be exactly as per original & it must be both sides of the
page.

<!-- page 49 -->

ANNEXURE: XI
APPLICATION CUM VERIFICATION FOR REIMBURSEMENT OF SALES TAX UNDER TIDEA (TELANGANA STATE INDUSTRIAL DEVELOPMENT AND ENTREPRENEUR
ADVANCEMENT) INCENTIVE SCHEME 2014
(G.O.Ms.No.28 Industries and Commerce (IP & INF) Department. dated.29/11/2014)
1.0. Details of Industry:
1.1. Name of the Enterprise:

1.2

Name of the Proprietor/Managing Partner / Managing Director:

1.3

TIN No. of the Enterprise/Industry/ Proprietor / Managing Partner / Managing Director:

1.4

PAN No. of the Proprietor / Managing Partner / Managing Director:

2.0.
2.1

Address of the Enterprise:
Office:

2.2

Factory location:

3.0.Status:
3.1

Category : (Pl.

Micro Enterprises

mark)

Small Enterprises

3.2. Constitution of the Organisation (Pl.

mark)

Proprietary

Pvt. Ltd.

Partnership

3.3. Status of the Industry: (Pl.
New Industry

3.4
3.5
4.

Medium Enterprises

Large Industry

Limited

Coop.

mark)

Expansion

Diversification

Date of Commencement of Production:
(Date of Commencement of Production is the date of First Sale Bill/Invoice)
EM Part - II/IEM/IL No:
Date:
Employment:
e) Management & Staff
f) Supervisory
g) Workers

Male
(Nos.)

Female
(Nos.)

<!-- page 50 -->

5. Fixed Capital Investment(in Rs.)
Nature of Assets
New /Existing
Enterprise
(1)

Expansion/
Diversification
Project
(3)

(2)

% of increase under
Expansion/
Diversification Project
(4)

Land
Building
Plant & Machinery
Total
(If it is a new enterprise/industry, then column (3) and (4) need not be filled and it may be strike off)
6. Line of Activity.
Line of activity
Units i.e.
Values in
Nos. / Tons/ Capacity
Rs.
Ltrs.
New /Existing
Enterprise
Expansion/
Diversification
Project
% of increase under Expansion/ Diversification Project
Note: In respect of Expansion/Diversification projects, Enterprises involving at least 25%
enhancement on fixed capital investment and Capacity are eligible for claiming incentives
7
8

9

10

Sales Tax Regn. No & Date
APGST
CST
Installed capacity of the
existing Enterprise as
certified by the financial
institution/ chartered
accountant
Production details
preceding three years
1
before expansion/
diversification project as
certified by the financial
2
institution/ chartered
accountant
3
Sales Tax reimbursement
already
availed
by
Enterprise from the Date of
Commencement
of
Production.

Year

1st half year (201
nd

2 half year (201
1st half year (201
2nd half year (201
Total

11

Enterprises

Total production

– 20

)

Rs.

– 20
– 20
– 20

)
)
)

Rs.
Rs.
Rs.
Rs.

Claim application submitted by the Enterprise/Industry
for the 1st half Year / 2nd half year :
12 Tax paid by the Enterprise during the 1st half year/ 2nd
Rs.
half year as certified by Commercial Tax Department
100% / 75% / 50% Reimbursement amount claimed
13
Rs.
by the Enterprise
** Half year means every 6 months from the financial year beginning from 1st April to 31st March

<!-- page 51 -->

DECLARATION
I / We hereby confirm that to the best of our knowledge and belief, information given herein before and
other papers enclosed are true and correct in all respects. We further undertake to substantiate the
particulars about promoter(s) and other details with documentary evidence as and when called for.
I/We hereby agree that I/We shall forthwith repay the amount to me/us under scheme, if the amount of
Reimbursement of tax are found to be disbursed in excess of the amount actually admissible whatsoever
the reason.
Station :
Date :

Signature of Authorised Person
with Firm /Office Seal.

• The following documents are to be furnished:
a) Certificate from concerned CTO as prescribed at Form – A.
b) Production Particulars for the last –3- years and Column No. 5 & 6 of the application duly certified
by Chartered Accountant for the first time of the claim, if it is Expansion/Diversification Project.
c) Valid Consent for Operation (CFO) from TSPCB/Acknowledgement from General Manager, District
Industries Centre concerned on pollution angle.
d) All the required document as per Check-Slip at PART – C, for the first time of the claim.
14. RECOMMENDATION OF THE INSPECTING OFFICER:
(not to be filled by the Enterprise/Industry, to be filled by inspecting Officer)

a. Amount claimed in Rs.

:

b. Amount recommended in Rs.

:

The claim application of the captioned Enterprise/Industry is verified as per the operational guidelines. The
Enterprise/Industry is eligible for availing incentives under T-IDEA 2014. The Enterprise/Industry did not
add or removed any Plant & Machinery and there is no change of line of activity and capacity. Further, the
Enterprise/Industry is in continuous operation, there is no break-in-production (if so the details of the breakin-production) and I recommend the above incentives to the captioned Enterprise/Industry.
Signature of Inspecting Officer with Name & Designation.
Remarks of the General Manager:
The applicant Enterprise/Industry is eligible for above incentives and the claim is in order. The
computation of capital cost has been done as per the provisions under the scheme. I recommend for
sanction of above incentives.
Signature of General Manager with Office Seal.

Note: This application form, if photo copied must be exactly as per original & it must be both sides of the
page.

<!-- page 52 -->

ANNEXURE: XII
APPLICATION CUM VERIFICATION FOR REIMBURSEMENT OF CERTIFICATION
CHARGES FOR ACQUIRING QUALITY CERTIFICATION COST UNDER T-IDEA
(TELANGANA STATE INDUSTRIAL DEVELOPMENT AND ENTREPRENEUR
ADVANCEMENT) INCENTIVE SCHEME 2014
(G.O.Ms.No.28 Industries and Commerce (IP & INF) Department. dated.29/11/2014)
1.

(a) Name and Address of the Enterprise
(Office & Factory Location(s))

:

(b) Telephone No. Factory & Office

:

(c) E-mail & Fax No

:

2

EM Part – II/IEM/IL/EOU No
Date
(Enclose an attested copy)

:
:

3.

Item(s) of manufacture/processing as indicated in the EM Part
– II/IEM/IL/EOU registration

4.

Proof of functional status of the Enterprise as on the date of
submission of Application.
(A certificate (in original) from State GM, DIC Confirming
functional status of the Enterprise at the time of acquiring ISO9000/ISO 14001/HACCP – certificate)

5.

Details of ISO 9000/ISO 14001/HACCP Certificate
Name and address of certification agency:
The Certificate must have address of the site/location certified,
Scope of certification, Certificate No, date of issue & period of
validity (or date of expiry) Name & Logo & Number of the
Accreditation Body/Board.
(Enclose an attested copy of the Certificate)

6.

Details of expenditure incurred in acquiring ISO-9001/ISO14001/HACCP Certificate (excluding Hotel & Travel expenses
& Surveillance charges) Furnish a CA certificate of
expenditure (in original) giving the details along with bills,
vouchers and proof of payment.

7.

Details of reimbursement/grant/subsidy already received, if
any, from Centre Govt. (including DC(SSI) /State Govt./
Financial Institution etc. For acquiring
ISO-9001/ISO14001/HACCP
Certificate)
furnish,
an
Undertaking/declaration (in original) from the Managing
Director/ Proprietor/Partner of the Enterprise duly sworn
before a Notary.

DECLARATION
I(full name)...................S/o ........................... Managing Director / Partner / Proprietor bearing
......................(complete address) hereby declare that the particulars given in the application are correct. In
case any of the statement/information furnished in the application / documents later found to be wrong or
incorrect or misleading, I do hereby bind myself and my Enterprise to pay the full amount received as
reimbursement to the Government on demand in respect of above mentioned activity, within seven days of
the demand being made to me in writing.
I/We hereby agree that I/We shall forthwith repay the amount disbursed to me/us under the scheme, if the
amount of Quality certification charges are found to be disbursed in excess of the amount actually
admissible whatsoever the reason.
Station :
Date :

Signature of Authorised Person
with Firm /Office Seal.

<!-- page 53 -->

CHARTERED ACCOUNTANT CERTIFICATE
I/We hereby confirm that I/We have examined the prescribed registers, books of account and the
bank statement in respect of the above Enterprise.
I/We fully understand that any submission made in this certificate if proved incorrect or false, will
render me/us liable to face any penal action or other consequences as may be prescribed in the law or
otherwise warranted.
Signature & Stamp/seal of the Signatory______________
Name___________________________________________
Membership No.__________________________________
Full address____________________________________
Name and address of the Institution where registered.
Date:
Place:
Note :The copy of EM Part – II/IEM/IL/EOU Certificate, ISO -Certification /patent registration certificate if
applicable must be attested by General Manager, District Industries Centre concerned.
8. RECOMMENDATION OF THE INSPECTING OFFICER:
(not to be filled by the Enterprise/Industry, to be filled by inspecting Officer)

a. Amount claimed in Rs.

:

b. Amount recommended in Rs.

:

The claim application of the captioned Enterprise/Industry is verified as per the operational guidelines. The
Enterprise/Industry is eligible for availing incentives under T-IDEA incentive scheme 2014. The
Enterprise/Industry did not add or removed any Plant & Machinery and there is no change in line of activity
and capacity. Further, the Enterprise/Industry is in continuous operation, there is no break-in-production and
I further confirm that the unit has not availed any incentives from COI /recommend the above incentives to
the captioned Enterprise/Industry.
Signature of Inspecting Officer with Name & Designation.
Remarks of the General Manager:
The applicant Enterprise/Industry is eligible for above incentives and the claim is in order. The
computation of eligible cost has been done as per the provisions under the scheme. I recommend for
sanction of above incentives.
Signature of General Manager with Office Seal.
Note: This application form, if photo copied must be exactly as per original & it must be both sides of the
page.

<!-- page 54 -->

ANNEXURE: XIII
APPLICATION CUM VERIFICATION FOR REIMBURSEMENT ON EQUIPMENT
PURCHASED FOR CLEANER PRODUCTION MEASURES UNDER T-IDEA (TELANGANA
STATE INDUSTRIAL DEVELOPMENT AND ENTREPRENEUR ADVANCEMENT) INCENTIVE
SCHEME 2014
(G.O.Ms.No.28 Industries and Commerce (IP & INF) Department. dated.29/11/2014)
1.0. Details of Industry:
1.1. Name of the Enterprise:

1.2

Name of the Proprietor/Managing Partner / Managing Director:

1.3

TIN No. of the Enterprise/Industry/ Proprietor / Managing Partner / Managing Director:

1.4

PAN No. of the Proprietor / Managing Partner / Managing Director:

2.0.
2.1

Address of the Enterprise:
Office:

2.2

Factory location:

3.0.Status:
3.1

Category : (Pl.

Micro Enterprises

3.3
3.4

mark)

Small Enterprises

Medium Enterprises

3.2. Constitution of the Organisation (Pl.

mark)

Proprietary

Pvt. Ltd.

Partnership

Large Industry

Limited

Coop.

Date of Commencement of Production:
(Date of Commencement of Production is the date of First Sale Bill/Invoice)
EM Part - II/IEM/IL No:
Date:

4. Status of the Industry: (Pl.
New Industry

mark)
Expansion

Diversification

<!-- page 55 -->

5.

Fixed Capital Investment(in Rs.)
Nature of Assets
New /Existing
Enterprise

Expansion/
Diversification
Project
(3)

% of increase under
Expansion/
Diversification Project
(4)

(1)
(2)
Land
Building
Plant & Machinery
Total
(If it is a new enterprise/industry, then column (3) and (4) need not be filled and it may be strike off)
6. Line of Activity.
Line of activity
Units i.e.
Values in
Nos. / Tons/ Capacity
Rs.
Ltrs.
New /Existing
Enterprise
Expansion/
Diversification
Project
% of increase under Expansion/ Diversification Project
7
Sl.
No

1
1
2
3
4
8

Details of Equipment Purchased for Cleaner production measures:
Name of Name &
Bill
Cost of VAT/
Excise Freight
the
address No. &
the
CST in Duty in Charge
equipof the
Date
EquipRs.
Rs.
s in Rs.
ment
supplier
ment in
Rs.
2
3
4
5
6
7
8

Amount of subsidy claimed in
Rs.(25% limited to Rs. 5.00 Lakhs)

Other
Charge
s in Rs.

Total in
Rs.

9

10

Rs.

DECLARATION
I / We hereby confirm that to the best of my / our knowledge and belief, information given herein before
and other papers enclosed are true and correct in all respects. I / We further undertake to substantiate the
particulars about promoter(s) and other details with documentary evidence as and when called for.
I/We hereby agree that I/We shall forthwith repay the amount disbursed to me/us under the scheme, if
the amount of Reimbursement is found to be disbursed in excess of the amount actually admissible
whatsoever the reason.
Station :
Signature of Authorised Person
Date :
with Firm /Office Seal.
CHARTERED ACCOUNTANT CERTIFICATE
I/We hereby confirm that I/We have examined the prescribed registers, books of account and the
bank statement in respect of the above Enterprise.
I/We fully understand that any submission made in this certificate if proved incorrect or false, will
render me/us liable to face any penal action or other consequences as may be prescribed in the law or
otherwise warranted.
Signature & Stamp/seal of the Signatory______________
Name___________________________________________
Membership No.__________________________________
Full address____________________________________
Name and address of the Institution where registered.
Date:
Place:

<!-- page 56 -->

• The following documents are to be furnished:
a) Original purchase Bills and payment proof duly certified by the Financial Institution in case of Bank
Finance or C. A. in case of Self Finance.
b) Valid Consent for Operation (CFO) from TSPCB/Acknowledgement from General Manager, District
Industries Centre concerned on pollution angle.
c) The entire required document as per Check-Slip at PART – C, for the first time of the claim.
9. RECOMMENDATION OF THE INSPECTING OFFICER:
(not to be filled by the Enterprise/Industry, to be filled by inspecting Officer)

a. Amount claimed in Rs.

:

b. Amount recommended in Rs.

:

The claim application of the captioned Enterprise/Industry is verified as per the operational guidelines. The
Enterprise/Industry is eligible for availing incentives under T-IDEA. The Enterprise/Industry did not add or
remove any Plant & Machinery and there is no change in line of activity and capacity. Further, the
Enterprise/Industry is in continuous operation, there is no break-in-production (if not the details of the breakin-production) and I recommend the above incentives to the captioned Enterprise/Industry.
Signature of Inspecting Officer with Name & Designation.
Remarks of the General Manager:
The applicant Enterprise/Industry is eligible for above incentives and the claim is in order. The
computation of capital cost has been done as per the provisions under the scheme. I recommend for
sanction of above incentives.
Signature of General Manager with Office Seal.
Note: This application form, if photo copied must be exactly as per original & it must be both sides of the
page.

<!-- page 57 -->

ANNEXURE: XIV
APPLICATION CUM VERIFICATION FOR REIMBURSEMENT OF COST INVOLVED IN
SKILL UPGRADATION AND TRAINING UNDER T-IDEA (TELANGANA STATE INDUSTRIAL
DEVELOPMENT AND ENTREPRENEUR ADVANCEMENT) INCENTIVE SCHEME 2014
(G.O.Ms.No.28 Industries and Commerce (IP & INF) Department. dated.29/11/2014)
1.0. Details of Industry:
1.1. Name of the Enterprise:

1.2

Name of the Proprietor/Managing Partner / Managing Director:

1.3

TIN No. of the Enterprise/Industry/ Proprietor / Managing Partner / Managing Director:

1.4

PAN No. of the Proprietor / Managing Partner / Managing Director:

2.0.
2.1

Address of the Enterprise:
Office:

2.2

Factory location:

3.0.Status:
3.1

Category : (Pl.

Micro Enterprises

mark)

Small Enterprises

Medium Enterprises

3.2. Constitution of the Organisation (Pl.
Proprietary
3.3
3.4

4.

Partnership

mark)
Pvt. Ltd.

Limited

Coop.

Date of Commencement of Production:
(Date of Commencement of Production is the date of First Sale Bill/Invoice)
EM Part - II/IEM/IL No:
Date:

Status of the Industry: (Pl.

New Industry

mark)

Expansion

5. Fixed Capital Investment(in Rs.)
Nature of Assets
New /Existing
Enterprise
(1)
Land
Building

Large Industry

(2)

Diversification
Expansion/
Diversification
Project
(3)

% of increase under
Expansion/
Diversification Project
(4)

<!-- page 58 -->

Plant & Machinery
Total
(If it is a new enterprise/industry, then column (3) and (4) need not be filled and it may be strike off)
6. Line of Activity.
Line of activity
Units i.e.
Values in
Nos. / Tons/ Capacity
Rs.
Ltrs.
New /Existing
Enterprise
Expansion/
Diversification
Project
% of increase under Expansion/ Diversification Project
7.

The industry/Enterprise undergone infrastructure training of
any Government agency like DRDA etc.?
If yes ,the quantum of assistance & date:

8.

Name of the skill development Programme:

9.

Name of the training institute & duration.

Yes / No.

10 No. of skilled employees trained by the industry
11 Expenditure incurred for training Programme
12. Amount Claimed in Rs.
DECLARATION
I / We hereby confirm that to the best of our knowledge and belief, information given herein before and
other papers enclosed are true and correct in all respects. We further undertake to substantiate the
particulars about promoter(s) and other details with documentary evidence as and when called for.
I/We hereby agree that I/We shall forthwith repay the amount to me/us under scheme, if it is found to be
disbursed in excess actually admissible whatsoever the reason.
Station :
Date :

Signature of Authorised Person
with Firm /Office Seal.
CHARTERED ACCOUNTANT CERTIFICATE

I/We hereby confirm that I/We have examined the prescribed registers, books of account and the
bank statement in respect of the above Enterprise.
I/We fully understand that any submission made in this certificate if proved incorrect or false, will
render me/us liable to face any penal action or other consequences as may be prescribed in the law or
otherwise warranted.
Signature & Stamp/seal of the Signatory______________
Name___________________________________________
Membership No.__________________________________
Full address____________________________________
Name and address of the Institution where registered.
Date:
Place:
5. The following documents are to be furnished:
a) Copy of certificate of institute along with the list of participants with their signature.
b) EM Part - II/IEM/IL full set.
c) Form – C.
d) The entire required documents as per Check-Slip at PART – C, for the first time of the claim.

<!-- page 59 -->

13. RECOMMENDATION OF THE INSPECTING OFFICER:
(not to be filled by the Enterprise/Industry, to be filled by inspecting Officer)

a. Amount claimed in Rs.

:

b. Amount recommended in Rs.

:

The claim application of the captioned Enterprise/Industry is verified as per the operational guidelines. The
Enterprise/Industry is eligible for availing incentives under T-IDEA incentive scheme of 2014. The
Enterprise/Industry did not add or removed any Plant & Machinery and there is no change of line of activity
and capacity. Further, the Enterprise/Industry is in continuous operation, there is no break-in-production (if
not the details of the break-in-production) and I recommend the above incentives to the captioned
Enterprise/Industry.
Signature of Inspecting Officer with Name & Designation.
Remarks of the General Manager:
The applicant Enterprise/Industry is eligible for above incentives and the claim is in order. The
computation of capital cost has been done as per the provisions under the scheme. I recommend for
sanction of above incentives.
Signature of General Manager with Office Seal.
Note: This application form, if photo copied must be exactly as per original & it must be both sides of the
page.

<!-- page 60 -->

ANNEXURE: XV
APPLICATION CUM VERIFICATION FOR SANCTION OF INDUSTRIAL INFRASTRUCTURE
DEVELOPMENT FUND (IIDF) UNDER T-IDEA (TELANGANA STATE INDUSTRIAL
DEVELOPMENT AND ENTREPRENEUR ADVANCEMENT) INCENTIVE SCHEME 2014
(G.O.Ms.No.28 Industries and Commerce (IP & INF) Department. dated.29/11/2014)
1.0. Details of Industry:
1.1. Name of the Enterprise:

1.2

Name of the Proprietor/Managing Partner / Managing Director:

1.3

TIN No. of the Enterprise/Industry/ Proprietor / Managing Partner / Managing Director:

1.4

PAN No. of the Proprietor / Managing Partner / Managing Director:

2.0.
2.1

Address of the Enterprise:
Office:

2.2

Factory location:

3.0.Status:
3.1

Category : (Pl.

Micro Enterprises

mark)

Small Enterprises

Medium Enterprises

3.2. Constitution of the Organisation (Pl.
Proprietary

Partnership

3.3

Status of the Industry: (Pl.

New Industry

3.4

Expansion

mark)
Pvt. Ltd.

3.6
3.7

Limited

Coop.

mark)
Diversification

Whether it is located in Industrial Area declared by the
Government.
Justification for the location of Enterprise/Industry, if it is
located outside the Industrial Area declared by the
Government.

3.5

Large Industry

Date of Commencement of Production/Expected
date of Commencement of Production :
EM Part – I/EM Part II /IEM/IL No:
Date:

Yes / No.

<!-- page 61 -->

4.

Fixed Capital Investment(in Rs.)
Nature of Assets
New /Existing
Enterprise

Expansion/
Diversification
Project
(3)

% of increase under
Expansion/
Diversification Project
(4)

(1)
(2)
Land
Building
Plant & Machinery
Total
(If it is a new enterprise/industry, then column (3) and (4) need not be filled and it may be strike off)
5. Line of Activity.
Line of activity
Units i.e.
Values in
Nos. / Tons/ Capacity
Rs.
Ltrs.
New /Existing
Enterprise
Expansion/
Diversification
Project
% of increase under Expansion/ Diversification Project
6.

Expected Employment generation:

Male
(Nos.)

Female
(Nos.)

h) Management & Staff
i) Supervisory
j) Workers
7
8
9
10

11
12
13

Source of Finance
Description of the infrastructure
facilities required and its objective
How the proposed infrastructure is
critical to the Industrial Enterprise.
Estimates of Infrastructure
facilities and name of the
Chartered Engineer/Agency who
prepared the Estimates
Duration of the Project
Copy of the Project & its approval
report
Measures proposed to maintain the
infrastructure created and its
maintenance cost per annum.

SIGNATURE OF THE APPLICANT
COMPANY/ENTERPRISE

Note: This application form, if photo copied must be exactly as per original & it must be both sides of the
page.

<!-- page 62 -->

TO BE FILLED ALONG WITH CLAIM FOR AIDED ENTERPRISES
STATEMENT OF ACCOUNTS IN RESPECT OF AIDED ENTERPRISES:
Date:
1.
2.
3.

Name & Address of the
Enterprise
:
Name & Address of the
Financial Institution
Term loan sanction

:
:

Date of filling
of application

Date of
Sanction

Amount Sanctioned (in
Rs.)

1st Loan
2nd Loan
3rd Loan etc.
4.

Project cost, loan sanctions and release, assets acquired (in Rs.)
Nature of
Approved Quantum
InstituLoan
Assets
Asset
Project
of Loan
tion
Received
Acquired
Cost
SancMargin
to the
(Original)
tioned
%
extent of
Loan
Released

1
Land
Buildings
Plant &
Machinery
Machinery
contingencies
Erection
Technical
know-how,
feasibility
study
Working
capital
Total

2

3

4

5

6

Assets
which
form Part
of
approved
Project
Cost but
loan was
not drawn
7

Total
acquired.

8

a) Name of the Certifying Officer :…………………………………………..
b) Designation

:…………………………………………..
Signature of the Certifying Officer
Stamp with Designation
Bank Seal

<!-- page 63 -->

5.

If the Project cost is revised, the details. (in Rs.)
Nature of
Revised
Addl. Part Quantum
Quantu
Asset
Approved
of
of Addl.
m of
Project
Approved
Loan
Addl.
Cost
Project
Sanctione
Loan
Cost
d
Receive
d

1

2

3

4

5

ProporAssets
tionate which form
Asset
Part of
Acquire
approved
d to the Project Cost
Addl.
but loan was
Loan
not drawn
Release
d
6
7

Total
Assets
acquired
.

8

Land
Buildings
Plant &
Machinery
Machinery
contingencies
Erection
Technical
know-how,
feasibility
study,
Working
capital
Total
a) Name of the Certifying Officer :…………………………………………..
b) Designation

:…………………………………………..
Signature of the Certifying Officer
Stamp with Designation
Bank Seal

<!-- page 64 -->

TO BE FILLED ALONG WITH CLAIM FOR AIDED ENTERPRISES
LIST OF PLANT & MACHINERY
Statements on machinery including erection, freight transportation on which term loan was released and not
utilised but they form part of approved project cost of M/s. ……………………………………...
……………………………………………………………………………………………………………….
Sl. No.

Name of the
machine with
Specifications

Date of
Placement of
Order

Name of the
Supplier

Bill No. &
Date

Amount of the
bill including
freight,
insurance,
taxes, etc. (in
Rs.)

For self fabricated Machinery, certificate be affixed on the minimum life and cost reasonableness of
each item with specification of such machinery.
This is to certify that from the above list of plant & machinery Sl. No. ____ to _____ are new and
Sl.No._____ to _____ are second hand machinery

a) Name of the Certifying Officer : …………………………………………..
b) Designation

:…………………………………………..
Signature of the Certifying Officer
Stamp with Designation
Bank/TSFC Seal

Certification
b) Verified Plant & Machinery, found to tally with the list, duly erected and put to use and is
required for manufacturing the approved lines of activities.
c) There are no second hand machinery items in the list.

Signature of Inspecting officers with designation and seal

<!-- page 65 -->

TO BE FILLED WITH CLAIM APPLICATION BY ALL ENTERPRISES.
(CIVIL ENGINEER'S CERTIFICATE)
I hereby certify that M/s.
(Name of the industrial Enterprise with complete address)
as against the estimated cost of Rs.
(Rupees........................................................
....................................................... only) has completed the civil work
(address) as on
Under:1.

2.

Place :
Date :

Value of completed Civil works as per the estimate
(Item wise details) of the building and civil work
completed (With plinth area must be shown)
Rs.
a)
b)
c)
d)
Expenditure incurred on other items excluding the
item shown in (1) above pertaining to a factory
construction. Details of each item to be shown.
a)
b)
c)
d)
Total Rs.
Civil Engineer of the Financing Institution /
Chartered Engineer.

Note: In respect of Expansion / Diversification, the value of Civil works should be on the additional
constructions taken up for the purpose of Expansion / Diversification only.

<!-- page 66 -->

FORM – A
APPLICATION-CUM CERTIFICATION OF SALES TAX DEPARTMENT SHOWING THE TAX
PAID BY THE ENTERPRISE FOR AVAILING REIBURSEMENT UNDER TELANGANA STATE
INDUSTRIAL DEVELOPMENT & ENTREPRENEUR ADVANCEMENT INCENTIVE SCHEME
2014
(G.O.Ms.No.28 Industries and Commerce (IP) Department., dated.29/11/2014)
1st HALF YEAR/ 2nd HALF YEAR – 201

–

201

(1st half year means tax paid for the period from 1st April to 30th September & 2nd half year means tax
paid for the period from 1st October to 31st March)
To :

The Commercial Tax Officer,
______________
______________
______________ (Address)

Sir,
I hereby request you to Certify for reimbursement of 100%/75%/50% under new industrial policy
framework for Telangana i.e., T-IDEA Incentive scheme 2014
1. Name of the Enterprise/industry and Address
2. Name of the goods manufactured
in Telangana in his own Enterprise/industry.
3.

Item wise production details during the 1st
half Year/ 2nd half year :
a)
b)
c)
Total

: …………………………………………
…………………………………………
: .……………………………………….
Units

Qty/Value

4. Sales Tax (net VAT/CST or State goods and services tax) paid by the Enterprise/industry under the
State Sales Tax Act, for the 1st half year/ 2nd half year :
201
-- 201
(a) Tax paid on sales by it in
respect of goods manufactured
by the Enterprise/industry in
Telangana during the 1st half year/
2nd half year.

:

Rs. ……………………………..
(in figure)
(Rupees……………………………….………….)
(in words)

(b) Central Sales Tax paid by it on
:
Sales in the course of inter
State trade or commerce made
From/within Telangana state during
the 1st half year/ 2nd half year.

Rs. ……………………………………….
(in figure)
(Rupees …………..…..………………………….)
(in words)

5. Name of the Bank with its branch : ……………………………………………
Name and bank account No. through
……………………………………………
Which the payment was made.
6. Registration Certificate No. of the
: ……………………………………………
Dealer under the State Sales ……………………………………………
Tax Act. / the Central Sales Tax Act,
I duly verify that all the facts and figures furnished above are correct.
Station :
Date :

Signature of Authorised Person
with Firm /Office Seal.
(Proprietor/ Partner/Managing Director/ Director)
(Strike out whichever is not applicable)

<!-- page 67 -->

CERTIFICATE
It is certified that all the facts and figures furnished by the Enterprise is verified with the records and
found correct. The above Enterprise/industry has paid the Sales Tax amount of Rs.______________ and also
there is no due for the 1st half year/ 2nd half year – 201

– 201

.

Place:
Date:
COMMERCIAL TAX OFFICER
(concerned)
Office Seal.
Note: This application form, if photo copied must be exactly as per original & it must be both sides of the
page.

<!-- page 68 -->

FORM – B
FORMAT FOR SELF CERTIFICATION UNDER THE PROVISIONS OF
(G.O.Ms.No.28 Industries and Commerce (IP) Department., dated.29/11/2014)
1
2

Name of the Industrial Enterprise
Location

3

Part – II / IEM Acknowledgment/IL No.
& Date
Details of Power:
Existing Power
New / additional
connection in HP power connection
in HP

4

5

Date of new/addl.
power connection
released.

Name of the power supplying
company.

Date of commencement of regular
production
Line of Activity

6

CERTIFICATE
i.

Certified that we have complied / are complying with all the provisions of G.O.Ms.No.28
Industries and Commerce (IP) Department, dated.29/11/2014 made there under, in addition to
those specifically mentioned above.

ii.

I/We hereby confirm that the contents mentioned above are true to the best of my / our
knowledge.

iii.

I/We abide by the provisions under the T-IDEA Incentive scheme-2014 of Govt. of Telangana
and further abide by the change/modifications made by the State Government under
G.O.Ms.No.28 Industries and Commerce (IP) Department, dated.29/11/2014 and also abide by
the decisions of Industries & Commerce Department.

iv.

I/We am/are authorized person(s) to issue the above Certificate and the above Certificate is
issued with full knowledge of the Statue. I/We am/are severally/jointly responsible for any
information found incorrect subsequently and liable for prosecution under the provisions
Acts/Code and Rules.

v.

I/We undertake to Refund the concessions claimed if found were obtained by misrepresentation
of facts or in case of misuse.
AUTHORISED SIGNATIORY:
Name:………………………….
Designation:……………………
Date:……………………………
Seal:……………………………

<!-- page 69 -->

FORM – C
DETAILS OF THE EMPLOYEE
1.

Name of the Enterprise:

2.

Date of Commencement of Commercial Production:

1.

Age

2.

Social Status :

3.

Local / Non local (District as an unit)

4.

Educational Qualifications:

5.

Previous Experience

6.

a)

EPF No.

c)

ESI No.

SC/ST/Other

Women/Women-SC/Women-ST

ITI/Degree

7.

Date of Joining the Industry:

8.

Training Period

9.

Expenditure incurred for Training:

10.

Training Organisation :

11.

Whether any Government funds availed the Organisation for this training purpose. If so, details

:

From

to

I have verified the above facts & certify that they are true and correct.
AUTHORISED SIGNATIORY:
Name:………………………….
Designation:……………………
Date:……………………………
Seal:……………………………

<!-- page 70 -->

ADVANCED STAMPED RECEIPT
(Paras 24.3, 24.4 & 24.5 of Guidelines)
Received Rs._____ _ (Rupees________________________________only)
towards
___________________________________________ Sanctioned to M/s. _____________________vide
Proceedings No.________________Date ____________________of Additional Director of Industries /
General Manager, DIC, ______________under the New Scheme of T-IDEA, vide G.O.Ms.No.28
Industries and Commerce (IP) Department., dated.29/11/2014 cheque No.__________________
date._____________from the M.D., TSFC with thanks.
Date :
Authorised Signatory.
Place:

(on Re. 1/- Revenue Stamp)
// Attested //

GENERAL MANAGER. DIC.

TO BE FILLED ON RECEIPT OF SANCTION PROCEEDINGS.
Assignment letter.
(Paras 24.3, 24.4 & 24.5 of Guidelines
We wish to state that we have obtained bridge loan from _______________________________
_____________________________ (Name of the Financial Institution / Bank) / Not obtained Bridge loan
from any bank or financing Institution against the State Investment Subsidy sanctioned under
G.O.Ms.No.28 Industries and Commerce (IP) Department., dated.29/11/2014. We have availed the term
loan from _______________ (Name of the Financial Institution / Bank). Kindly send the cheque
towards payment of sanctioned _______________________________________, to
us
through
_____________________ (Bank / Branch Name) for being credited to our account.
Date:
Place:

Authorised Signatory
( on Re.1/- Revenue Stamp)
// Attested //

GENERAL MANAGER. DIC.

<!-- page 71 -->

UTILISATION CERTIFICATE
1.

Name of the Enterprise/Industry with address

:

2

EM Part – II / IEM/IL ( Registration No. and Date)

:

3

Type of sanctioned incentives/concessions

:

4

Proceedings No.

:
Date

:

Amount in Rs. :
5

______________________________________ sanctioned received Cheque No. :
Date

:

Amount

:

Certified that the said ________________________incentives/concessions received by us has been
fully utilised for the purpose for which it was sanctioned towards the development of the enterprise/industry as
detailed below.

Purpose

Amount utilised

1.
2.
3.
Signature of the Authorised Person with the Firm/Office Seal.

<!-- page 72 -->

ACKNOWLEDGMENT:
Received Incentives claim Application from
M/s…………………………………………………………………………………………….
………………………………………………………………………………………………….
…………………………………………………………………………………………………
……………………..Dated …………………………on……………………………….

Receiver's Signature with Date stamp of DIC.

<!-- page 73 -->

To be filed along with claim application for reimbursement of interest amount under (Pavala Vaddi scheme)
(Para 5.11.0 of Guidelines Certificate Term Loan)
CERTIFICATE FOR TERM LOAN
It is to certify that ------------------------------------- the Micro/Small Enterprise (industrial Enterprise) is engaged in the manufacture of
"--------------------" have been sanctioned Rs.---------------- Vide Sanction letter no. --------------------- and --------------------------------------------- as Term Loan with Loan Account No.------------------------- The Enterprise has repaid principal amount together with Interest
as detailed below.
Details of disbursements against the sanctioned loan.
Sl.No.
Date of Disbursements
Amount Disbursed
1
2
3
4
Total Amount Disbursed Rs.
Payment of Interest
Term
Loan

Total
Amount
disbursed
in Rs.

Rate of
Interest

No.
of
Installments
fixed
for
Repayment

Due date of
installment
of principal
amount.

Amount of
the
installment
of principal
amount
become due
in Rs.

Interest
chargeable
on the due
date of the
installment
of principal
amount
(interest
against each
installment
of be shown
separately)

Sl.No. of
installment

Date of
payment
of
Principal
Amount

Principal
Amount
paid in
Rs.

Date of
payment
of
Interest
Amount

Interest
Amount
paid in
Rs.

1

2

3

4

5

6

7

8
1
2
3
4

9

10

11

12

1
2
3
4

Eligible
interest
subsidy
amount
for
reimbur
sement
under
Pavala
Vaddi
Scheme

1. This is a new Enterprise with the EM No.
,Date
and date of Commencement of Commercial production -------------2. Certified that more than 75% of the plant and machinery is new and not second hand.
3. Penal interest is excluded and the Enterprise is paying regularly the interest as well as principal amount

<!-- page 74 -->

4. Reimbursement of interest will be eligible from the date of commencement of commercial production.
5.Certified that the interest shown under the demand column is calculated on the principal amount due only but not on loan amount outstanding which
includes interest not paid on due dates and added to the loan account i.e., compound in affect was not resulted in due to non payment of
interest/principal on due date(s) while calculating the interest.
6.The following condition has been taken into consideration while arriving the interest period paid :
" The loan accounts that are classified as overdue in the books of the bank at time of half yearly closing and that which are classified as non performing
assets at year end closing are ineligible. However, if their repayments are on-time and regularize the arrears they are eligible for the incentives in the
next half yearly period."

a) Name of the Certifying Officer :…………………………………………..
b) Designation

:…………………………………………..
Signature of the Certifying Officer
Stamp with Designation

Bank/TSFC Seal

Note: This application form, if photo copied must be exactly as per original & it must be both sides of the page.

<!-- page 75 -->

To be filed along with claim application by the self financed Enterprises/industries
Statement of new Plant, Machinery & Equipment (P.M.E) Purchased and installed by M/s…………………………………..…………
In the enterprise/industry located at ………………………………………………………………………………………...……………
NEW PLANT, MACHINERY & EQUIPMENT
Sl.No.
1

Name & Specification of
Machinery Equipment
2

Date of Placement
of Order
3

Name and Address of
Supplier
4

Freight
(Rs.)

Others
(Rs.)

Total
(Rs.)

Whether Cash /
Credit Purchase

Payments made against Credit
Purchase, Cheque/DD/ No. & Dt.

9

10

11

12

13

Station :
Date :
Certification

Bill No. & Date

Basic Cost
(Rs.)
6

5

Receipt No. & Date in token
of receipt of amount by
Supplier
14

Taxes Duties
(Rs.)
7

Insurance
(Rs.)
8

In respect of other than the
machines the purpose for which
used
15

Signature of Authorised Person
with Firm /Office Seal.

d) Verified Plant & Machinery, found to tally with the list, duly erected and put to use and is required for manufacturing the
approved lines of activities.
e) There are no second hand machinery items in the list.
Signature of Inspecting officers with designation and seal

Remarks
16

<!-- page 76 -->

To be filed along with claim application by the all industrial Enterprises/Industries
Statement of Second hand Plant, Machinery & Equipment (P.M.E) Purchased and installed by M/s………………………...…………
In the enterprise/industry located at ………………………………………………………………………………………...……………
SECOND HAND PLANT, MACHINERY & EQUIPMENT
Sl.No.
1

Name & Specification of
Machinery Equipment
2

Date of Placement
of Order
3

Name and Address of
Supplier
4

Bill No. & Date

In respect of other
than the machines the
purpose for which
used
14

Total
(Rs.)

Whether Cash /
Credit Purchase

Payments made against
Credit
Purchase,
Cheque/DD/ No. & Dt.

Receipt No. & Date in
token of receipt of
amount by Supplier

10

11

12

13

Station :
Date :

5

Basic Cost
(Rs.)
6

Taxes Duties
(Rs.)
7

Insurance
(Rs.)
8

Others
9

Depreciated
Value

Minimum
Life

Remarks

15

16

17

Signature of Authorised Person
with Firm /Office Seal.

CERTIFICATES:
i) Verified and certified that the depreciated value of
each purchase reflected at column “15” of the above
statement are correct

ii) Verified and certified that the minimum life of
each purchase of second hand machinery reflected
at column “16” of the above statement are correct

Signature of Chartered Accountant with Seal affixed

Signature of Chartered Engineer with seal affixed

<!-- page 77 -->

To be filed along with claim application by the all industrial Enterprises/Industries
Statement of Self Fabricated Machinery installed by M/s………………………...………………………………………………..……
In the enterprise/industry located at ………………………………………………………………………………………...……………
SELF FABRICATD MACHINERY (STATEMENT OF MATERIALS PURCHASED & WAGES PAID BE APPENDED)
Sl.No.

Name & Specifications of the Item Fabricated

1

2

Station :
Date :

Cost. (in Rs.)
3

Minimum Life

Remarks

4

5

Signature of Authorised Person
with Firm /Office Seal.
CERTIFICATE:
Verified and certified that the minimum life and
cost reasonableness of self fabricated machinery
reflected column 3 & 4 are of the above statement
are correct.

Signature of Chartered Engineer with seal affixed

<!-- page 78 -->

ANNUAL PERFORMANCE REPORT
1.

(T-IDEA – 2014 (G.O.Ms.No.28 Industries & Commerce (IP) Department, Dated:29/11/2014))
LSI / MSI / EM Part – II (Registration No. & Date.)

2.

Report for the Year

3.

Incentives received

Date of receipt.

a) Capital Subsidy

:

Rs.

b) Sales Tax Reimbursement

:

Rs.

c) Power Consumption Reimbursement

:

Rs.

d) Stamp Duty Reimbursement

:

Rs.

e) Land cost Reimbursement in IE/IDA/IPs :

Rs.

Name of the
industry with
full postal
address

Change in
location of
Enterprise or
change in
management if
any

If there is break
in production
period from
________ to
________ and
reasons

Production
Quantity /
Enterprise

Value
(Rs.)

1

2

3

4

5

Employment

Permanent Tempo
rary

Station :
Date :

6

7

Sales
Quantity /
Enterprise

Value
(Rs.)

Percentage
Capacity
Utilisation

Quantum
_______
utilised

Remarks

8

9

10

11

12

Signature of Authorised Person
with Firm /Office Seal.

CERTIFICATE:
Verified with records and found the above information is correct.
Signature of the General Manager, District Industries Centre,

<!-- page 79 -->

1
