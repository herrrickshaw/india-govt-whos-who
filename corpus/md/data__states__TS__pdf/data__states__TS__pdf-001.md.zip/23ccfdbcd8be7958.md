---
doc_id: "23ccfdbcd8be7958"
source_url: "https://forests.telangana.gov.in/Pages/Acts_Rules/Amendment%20to%20APFP%20Transit%20Rules,1970%20-%2006022010%20-%20G.O.Ms.No.35.PDF"
ministry: "Forest Department, Telangana"
title: "Amendment to APFP Transit Rules,1970"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "968d50f0b5c2dc41"
---

<!-- page 1 -->

GOVERNMENT OF ANDHRA PRADESH
ABSTRACT
Forest Department - Mining Leases – Regulation of transport of Major & Minor
Minerals from approved leases- Issue of transport permits – Amendment of sub
rule (5) of Rule 5 of Andhra Pradesh, Forest Produce Transit Rules, 1970 Orders – Issued
ENVIRONMENT FORESTS SCIENCE & TECHNOLOGY (FOR.I) DEPARTMENT

G.O.Ms.No. 35

Dated:06-02-2010
Read the following

1. GO.Ms No. 356 Food & Agriculture Dept. Dt: 4-03-1970
2. From the Principal Chief Conservator of Forests, A.P., Hyderabad,
Lr.Rc.No.56961/2009/EC, dated:16-12-2009.
***
ORDER:
The issue of Transit Permits by Forest Department is regulated under Rule
5 (5) of the Andhra Pradesh Forest Produce Transit Rules, 1970, which reads that
“for the supply of Form-I and Form-II permits in triplicate a rate of Rs.500.00
per 100 permits in triplicate shall be charged”.
2.
Principal Chief Conservator of Forests, Andhra Pradesh, Hyderabad, in
the reference 2nd read above, has stated that to keep a watch on the mining
activity and also to assess the quantity and the type of mineral being quarried, the
Forest officials have to carry out survey and also keep constant watch on the
movement of the produce. In view of the increased workload on the staff and to
augment the Forest Revenue commensurate with the cost of product mined the
rates of permit are being proposed for enhancement. For the reasons stated
therein the PCCF, has proposed for amendment of rule 5 of Andhra Pradesh
Forest Produce Transit Rules, 1970 issued vide G.O.Ms.No. 356 Food &
Agriculture Dt. 04-03-1970.
3.
Government after careful examination of the proposal have decided to
amend rule 5 of Andhra Pradesh Forest Produce Transit Rules, 1970 issued vide
G.O.Ms.No. 356 Food & Agriculture Dt. 04-03-1970, and published in Andhra
Pradesh Gazette R.S. part-II dt. 30-04-1970 and as subsequently amended from
time to time.
4.
The following notification will be published in the next issue of the
Andhra Pradesh Gazette.
NOTIFICATION
In exercise of the powers conferred by section-29 read with sub-section(1) of section-68 of the Andhra Pradesh Forest Act, 1967, (Andhra Pradesh Act
No. 1 of 1967) the Governor of Andhra Pradesh here by make the following
amendment to the Andhra Pradesh Forest Produce Transit Rules, 1970 issued
vide G.O.Ms.No. 356 Food & Agriculture Dt. 04-03-1970, and published in
Andhra Pradesh Gazette R.S. part-II dt. 30-04-1970, and as subsequently
amended from time to time.

<!-- page 2 -->

AMENDMENT
In the said rules for sub-rule (5) of Rule 5 the following shall be
substituted namely: - For the supply of Form – I & Form – II Permits in
Triplicate the following shall be charged per Permit:
Form-I Permits
Major Minerals/ Minor Mineral /Granite

Charge per permit
Rs.10.00/Tonne/Cmt.

Timber

Rs.5.00 per Cmt.

Fuel Wood

Rs.3.00 per Cmt.

Bamboo & other Forest Produce

Rs.50.00 per Lorry and Rs.20.00
per Cart.

Form-II Permits from Intermediate Depot Rs.20.00 per Permit.
to Destination for all Forest Produce

(BY ORDER AND IN THE NAME OF THE GOVERNOR OF ANDHRA PRADESH)

JANAKI R. KONDAPI
SPECIAL CHIEF SECRETARY TO GOVERNMENT
To
The Commissioner of Printing, Stationery and Stores Purchase (Printing),
Hyderabad. – With a request to publish the notification in the next issue of A.P
Gazette and supply 300 copies to the Government.
The Principal Chief Conservator of Forests,
Andhra Pradesh, Hyderabad.
SF/SC.
// FORWARDED :: BY ORDER //
SECTION OFFICER
