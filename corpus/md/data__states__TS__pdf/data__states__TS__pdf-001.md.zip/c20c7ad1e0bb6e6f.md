---
doc_id: "c20c7ad1e0bb6e6f"
source_url: "https://cdn.s3waas.gov.in/s32a38a4a9316c49e5a833517c45d31070/uploads/2026/07/17831628765439.pdf"
ministry: "Medak"
title: "Tender Invitation for Transportation of Laboratory Samples - Office of District Medical and Health Officer, Medak 2026  New"
date: ""
pages: 15
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "bb5231096be62462"
---

<!-- page 1 -->

DISCLAIMER |
The information contained in this Tender document or subsequently provided to |
న. verbally or in documentary form by or on behalf of the DISTRICT |
L AND HEALTH OFFICE MEDAK, NHM, Government of Telangana, or any t
c employces or advisors, provided to Firm(s) on the terms and conditions set out |
in this TENDER document and any other terms and conditions subject to which such i]
information is provided, |
|
This TENDER document is not an agreement and is not an offer or invitation by i
the Department or its representatives to any other party. The purpose of this TENDER i
1 y party. [౧
document is to provide interested parties with information to assist the formulation of
their Application and detailed Proposal. This TENDER document does not purport to
contain all the information each Firm may require. This TENDER document may not
be appropriate for all persons, and it is not possible for the Department, their |
employees or advisors to consider the investment objectives. Financial situation and |
particular needs of each party who leads or uses this TENDER document. i
To ensure that all the Firms have equal understanding of the proposed Project,
each Firm shall conduct their own investigations and analysis and shall check the |
accuracy, reliability and completeness of the information in this TENDER document |
and obtain independent advice from appropriate sources. Department, its employees i
and advisors make no representation or warranty and shall incur no liability under i
any law, statute, rules or regulations as to the accuracy, reliability or completeness of
the TENDER document. Department may in its absolute discretion, but without being
under any obligation to do so, update, amend or supplement the information in this
TENDER document.
TENDER FOR TRANSPORTATION OF LABORATORY SAMPLES
Tenders are invited farm eligible Firms for transportation of Lab samples daily
from different locations in the District (All Health Facilities) to Telangana Diagnostic |
Hub, District Hospital MEDAK for a period of (1) year. The contract will be awarded |
initially for a period of one (1) year only.
SCHEDULE OF BIDDING PROCESS:
SL.N DESCRIPTION DATE
వ
|
1 Public Notification 02/07/2026 |
| 1
2 11256 date & time of | 20/07/2026 | |
receipt of pre-bid
Queries
3 Last Date for 24/07/2026
submission of the |
Tender
\* | Opening of Technical | 25/07/2026
Bid ———________|
5 Opening of Financial | After evaluation of technical bid |
bid |
Contact person a) District Programme Officer (DPO-NHM) Ph No:-
80085 15360
e-mail id:-dmhomedaknew@gmail.com
b) District Accounts Officer (DAO-NHM) Ph No:- 97004
34339
7 Reterenice No! DISTRICT MEDICAL AND HEALTH OFFICE MEDAK
DISTRICT MEDAK Ref No: Re. No. 850-
DMHO/MDK/26 iN
a Sry —
Dist. Sagal f teatth Officer
Medak Distritt), Telangana,
scanned with OKEN Scanner

<!-- page 2 -->

AVAILABILITY OF TENDER DOCUMENT:
if Firms can receive Tender document from District Programme Management
Unit (DPMU-NHM),0/% DM&HO, MEDAK.
Il. Firms can obtain tender document from online site web site
http:/ /MEDAK.telangana.gov.in
PLACE OF ENQUIRY, SUBMISSION AND OPENING OF TENDER:
0/0 DISTRICT MEDICAL AND HEALTH OFFICE MEDAK, TELANGANA-502001.
Contact Person : D.KOTA, 80085 15360
E-mail - : dmhomedaknew@gmail.com
Contact Person : K.RAMESH, 9700434339
TELANGANA DIAGNOSTICS HUB & SPOKE MODEL
TENDER DOCUMENT FOR HIRING OF SAMPLE TRANSPORT VEHICLES
District Level Implementation
TELANGANA DIAGNOSTICS HUB SAMPLE ||
TRANSPORTATION VEHILCES |
Tender Reference DISTRICT MEDICAL AND HEALTH OFFICE MEDAK _
Number DESTRICT MEDAK,
Ref No: Re. No. 850-DMHO/MDK/26
[Issue Date | 02/07/2026 =
Last Date for Bid 28/07/2026 |
Tender Inviting District Medical & Health Officer (DM&HO), Medak,
Authority Telangana
Tender Accepting Distrikt Medical & Health Officer, Medak, Telangana
Authority
SECTION 1: INTRODUCTION AND OBJECTIVES
1.1 Overview
The District Medical & Health Officer, Medak, Telangana, invites sealed tender
bids from eligible and experienced Transport Logistics Operates for hiring of
specialized transport vehicles for sample transportation under the Telangana
Diagnostics Hub & Spoke Model program
The Telangana Diagnostics Initiative a flagship free diagnostic program
implemented through fully equipped in browse public laboratories in a hub-and-spoke
model. This model ensures quality diagnostic services are provided free of cost across
all levels of health facilities, including Primary Health Centers (PHCA), Urban Primary
Health Center (UPHC), Basti Dewakhanas , Community Community Heath Heal
Centers (CHC), Area Hospitals (AHs), Dist Hospitals (DHs), and Touching Hospitals
functioning functioning under the Directorate of Medical Educatioy (DME)
1.2 Objective of Tender / గు
Dist. (31 900
Medal Distriet angana.
ఆ Scanned with OKEN Scanner

<!-- page 3 -->

The primary objective of this tender is to engage a qualified and reliable transport
operate provide dedicated, fully equipped sample transportation sthickes that will |
1. Transport biological pathological samples thom all peripheral health facilities |
cal } gi 0] perip |
(Spokes) to the District Diagnostic Hub i
2. Maintain cold chain integrity as per Indian Public Health Standards (PHS) |
2022Requirements, ||
3. Ensure timely delivery of samples to maintain sample quality and |
Turnaround time targets. H
4. Maintain proper documentation and sample tracking throughout the |
Transportation cycle with GPS-enabled real-time tracking (ALS-140 i
Compliant) . 4
5. Transport of reagents/consumables from district hubs to spokes when
Required. if
1.3 Program Background వ
The Telangana Diagnostics Hub & Spoke Model has been implemented since 2018 as 2
part of the National Health Mission (NHM) free diagnostic initiative.
* One centralized diagnostic hub is established in each district. క
* The Hub connectivity a 60 km radius, connecting all PHCs, UPHCs, Basti
Dawakhanas, CHCs, AHs, DHs, and Teaching Hospitals. aS
* The current scope includes 134+ types of pathology, biochemistry, and
microbiology tests.
* Operating hours are 24/7, 7 days a week. |
* Daily sample volumes range from 1,000 to 5,000+ samples, depending on
district Coverage. +f
* Cold chain requirement is mandatory for sample integrity and test accuracy. s
SECTION 2: SCOPE OF WORK E
2.1 Primary Responsibilities of Service Provider
2.11 Vehicle Provision & Maintenance
The Service Provider shall:
A .Provide (99) Nine fully-equipped sample transport with A15-140 GPS tracking sas :
Specified in Section 4 each
b. Replace any defective vehicle within 24 hours with an equivalent standby vehicle.
2.1.2 Sample Transportation & Cold Chain Management 3
The Service Provider must:
a. Transport samples in insulated containers with adequate ice packs/cooling |
elements to maintain 2-8°C temperature,
b. Complete sample transportation within prescribed time limits (typically 2-4 |
hours from collection)
c. Prepare and transport samples in leak-proof, puncture-resistant, double-walled ర
containers. |
21. 3 .Sample Documentation & Tracking ||
Maintain sample recipe and dispatch registers detailing: Sample tracking ID/barcode, ;
Spoke facility name and code, Collection time and temperature, Dispatch time, |
Reception time at hub Driver name, and vehicle registration. |
|
21.4. Driver & staff responsibilities. | |
a. Ensure driver availability 24/7 for round-the-clock operations. im
Dist. M arth Oley
Medak Qistrict , ana.
ఆ Scanned with OKEN Scanner

<!-- page 4 -->

i
b. Provide drivers with basic training on sample handling, cold chain maintenance,
and biomedical waste safety.
2.1.3. 24x7 Service Availability.
a. Maintain minimum response time of 30 minutes for emergency sample
transportation.
2.1.6 .GPS Connectivity & Real-Time Tracking, (MANDATORY)
The provider must:
a. Install AIS-140 compliant OPS devices on all vehicles.
b, Ensure GSM/GPRSAINSS-enabled real-time location tracking.
c. Provide dashboard access to DM&HO and authorized officials with real-time data,
Route history, temperature logs, and alerts.
d. Ensure uninterrupted 4G/LTE connectivity.
అ. Use cloud infrastructure hosted within India.
f{, Submit automated movement and compliance reports.
g. Bear all GPS-related costs.
2.1.7 Performance Standards & Delay Management
« Target: All samples delivered within 4-5 hours + 1 hour grace.
¢ Penalties
a.10% delayed trips/month: 2-5% deduction.
b.25% delayed trips/month: 10% deduction+ warning.
C. Delays for 3 consecutive months: Contract termination.
* Sample damage cost recovered fully from provider.
* Temperature deviation recorded via GPS sensors results in penalty.
* GPS failure 4 hours results in daily penalty.
2.1.8 24x7 Service Availability & Emergency Response.
* Emergency response time: 30 minutes.
* Maintain a dedicated 24/7communication channel.
* Maintain at least one stanbdy vehicle.
* No service interruption on holidays/weekends +
2.2 Hub/Spoke Laboratory Responsibilities.

The District Diagnostic Hub/Spoke Laboratory shall provide the sample
collection insulated containers and consolidation schedule and ensure proper sample
labeling and packaging prior to transportation.

SECTION 3: TENDER SPECIFICATIONS & ELIGIBILITY CRITERIA
3.1 Eligibility Requirements for Bidders
312 Experience Requirements

* Minimum 3 years continuous experience in transportation/logistics services.

« Atleast 2 years documented experience in providing transport services to

Government departments/PSUs/ Healthcare institutions.
3.1.3 Financial Requirements
* Annual Turnover: Minimum Rs. 20 lakhs for the last 2 financial years.
* Solvency Certificate: Minimum Rs. 10 lakhs from a scheduled bank.
* Experience: Evidence of executed contracts of a similar nature worth at least Rs. 15
lakhs per annum.
3.2 Vehicle Specifications
3.2.1Vehicle Requirement
* Type: Commercial light vehicle, minivan, or sedan with air conditionifg.
* Vehicle Condition: Maximum 5 years old on the date of tender open}
Dist/Mediga id YP Price.
Medak 01511101, Telangana.
scanned with OKEN Scanner

<!-- page 5 -->

1
* Cargo Capacity: Minimum 150-200 liters insulated cargo space.
3.2.2 Safety & Regulatory Compliance
* Insurance: Comprehensive Liability policy covering goods-in-transit (minimum Rs. 5
lakhs) and third-party liability.
3.2.3 Safety Equipment (To be provided by Service Provider)
*Must include a spill kit for sample spillage management, a fire extinguisher
(minimum 1 kg), and personal protective equipment (PPE) for drivers
(Gloves,Marks,Aprons).
SECTION 4 TENDER PROCESS & SUBMISSION REQUIREMENTS
4.1 The tender Format: Two-Bid System
The Tender Comprises:
+ BID 1 (TECHNICAL BID): Technical qualifications, experience, and complicance
with specifications.
* BID 2 (TECHNICAL BID): Rate quotation (sealed sepaeately).
4.2 Tender fees & Earnest Money Deposit (EMD)
Item Amount Mode of Payment Bank Account
| Details
Tender Rs.2,360/- (Including | Demand Draft DM&HO,MEDAK
Document Fee GST) Payment to Account no
| DM&HO,Medak 36312680779
Earnest Money Rs.50,000/- Demand Draft or IFSC:SBINO011985
| Deposit (EMD) Bank Guarantee in | Branch Medak
Prescribed format
* The EMD of the successful bidder will be adjusted against the security deposit.
4.3 Technical Bid Requirements (BD 1)
Mandatory documents Include the Tender acceptance form (Annexure-A), waited
financial statement for the last 3 financial years, the solvency Certificate, and vehicle
documentation registration, insurance, PUC, and less certificates).
4.3 Bid Submission Procedure
1. Submission Venue: Office of District Medical & Health Officer, District Medical &
Health Officer, IDOC, Coleectorate,R.No:26, MEDAK.
2. Subenission Deadline: on Tacadcy by 5:00 pm.
3.Sealed Submission: Envelopes must be super - scribed clearly with "TECHNICAL
BID-SAMPLE TRANSPORT VEHICLE TENDER" and Tender Ref. No. DISTRICT
MEDICAL AND HEALTH OFFICE MEDAK DISTRICT MEDAK,
4.6 Bid Validity Period
Technical and Financial bids shall remain valid for 150 days from the data of bid
opening.
SECTION 5: EVALUATION & SELECTION CRITERIA
5.2 Technical Bid Evaluation
The evaluation criteria and maximum points are: |
015ఓమీ[00% Office.
కంర District , Telangana.
ఆ Scanned with OKEN Scanner

<!-- page 6 -->

|
Evaluation Criteria Maximum Points
Experience (3+ years in transport /logistics) 20
a
Previous Government contract (3+ in health sector) 20
— ee నా
Financial capability (Turnover, solvency) 1S లా
Vehicle specifications (cold chain, condition) 25
న?
Operating plan (routes, schedule, staff) 10
Quality Management (BIS compliance, certifications) 10 ii
Total : 100
The Minimum qualifying score in Technical Bid is 60/100. The final selection will be
the bidder with the lowest financial bid among technically qualified bidders.
SECTION 6: TERMS & CONDITIONS
6.2 Contract Period & Renewal
‘The Initial Contract Period is 1 year from the date of the work order. Renewal is
subject to satisfactory performance and mutually agreed terms.
6.3 Service Level Agreements (SLA)
6.3.1 Performance Parameters
5.20. | Performance Indicator Minimum Acceptable
Level/Standard
1 Sample Transportation 100% samples Minimum 95% on-time
Timeliness delivered within 2-4 delivery
| hours,
|2 | Cold Chain Maintenance 100% samples 100% compliance
| transported 2-8°C
I
3 Vehicle Availability 99% availability 99% availability
|
4 Response to Emergency Within 30 minutes Within 30 minutes
Requests
5 Vehicle Replacement (in Within 24 hours Within 24 hours
case of breakdown)
6.3.3 Incentive & Penalty Structure
Performance Level Monthly Incentive / (Penalty)
ee నా
95-100% compliance No incentive/penalty
90-94% compliance '-5% of monthly bill
55-89% compliance -10% of mentally bill స్ట్‌
Below 85% compliance -15% of monthly hill grounds for termination
Dist. sar Het ih Office:
Medak Districd\, Tefangana.
scanned with OKEN Scanner

<!-- page 7 -->

6.4 Payment Terms & Conditions
1. Monthly Payment: Service chargns payable monthly on fixed basis
2. Invoice Submission: By 5th of each month for previous month's service
3. Payment Processing: Within 15 days of invoice receipt and verification
4. Payment Mode: Direct bank transfer to Service Provider's account with all
approvals including Hub In-charge consultant/AO/DM&HO
5. Tax Compliance: GST as applicable :
6. No Escalation: Rates shall remain fixed throughout contract period
6. 6.5 Insurance & Liability
Required insurance includes: Comprehensive Vehicle Insurance (Third-party liability
minimum Rs. 50 lakhs; Goods-in-transit coverage minimum Rs. 5 lakhs) and Public
Liability Insurance (Minimum Rs. 10 12109). The Service Provider is responsible for
any loss or damage to samples during transportation and any costs of re-testing due
to sample damage /contamination.
6.6 Contract Termination
Termination for Default may occur immediately if there is a failure to maintain a 90%
performance level for 2 consecutive months, non-compliance or failure to maintain
the cold chain. In case of termination for default, the EMD shall be forfeited.
SECTION 8: IMPLEMENTATION & OPERATIONAL GUIDELINES
8.1 Sample Collection & Transportation SOP
1. Primary collection rounds: Once dally (morning).
2. Emergency collections: On-demand basis with 30-minute response time,
3. Cold Chain Maintenance: Samples must be maintained at 2-8°C throughout
Transportation, using per-cooled insulated containers and adequate ice packs.
8.2 Communication Protocol
Key emergency contact numbers must be maintained:
* Hub Laboratory Supervisor: [85008 64056]
* DM&HO Office: [98490 99985]
* Service Provider In-charge: [PHONE TO BE PROVIDED BY CONTRACTOR]
8.3 Quality Assurance & Inspection
Unannounced vehicle inspections by the Hub Laboratory Manager will be conducted
weekly (random).
8.4 Staff Training & Development
Initial training is mandatory for all staff, lasting a minimum of 3 days, covering sample
handling, cold chain, vehicle operation, and safety protocols, Annual refresher training
(minimum 1 day) is required.
SECTION 11: ANNEXURES
The DM&HO must ensure the following mandatory annexure are attached with the
tender document
* Annexure-A: Tender Acceptance Form
* Annexure-E: Financial Bid Quotation Format
* Annexure-G: Service Level Agreement (Detailed)
*  Annexure-H: Sample Transportation ROUTE MAPS along with th¢/SOP |
N
Dist.M area
Medak[istrict , Telangana.
ఆ Scanned with OKEN Scanner

<!-- page 8 -->

ANNEXURES
ANNEXURE A
Tender Acceptance Form
[1 | Proposal submitted for the project
Name and postal address of the organization
submitting Proposal PAN, Service Tex and Sales Tex
registration numbers with self-certified cop
Telephone No. ae
Fax Number |
2 | E-mall address |
Reference registration /incorporation of the
organization Ese
Name and address of the Chief Executive (with
telephone No's)
Proposal Addressed to |
4. Reference of the Notice for invitation of proposals Nowa |
Dt. =
5 Receipt/DD
———
Reference of deposit of document Charges | Sess
Rs.
Authority for signing and submitting the document
(power of Attorney, Resolution of the organization)
7 | Documents enclosed in support of the Request
1
2;
3.
4.
5. =
Total pages.
Name and signature of the authorized
Signature seal of the organization
Date
Dist. Medicale HealtpAlticer
Meddk District | Telangana.
అ. Scanned with OKEN Scanner

<!-- page 9 -->

ANNEXURE -E
Financial Bid Quotation Format
(Annual turnover Statement of the firm)

The Annual turnover of M/s. for the past three
financial years are given below and certified that the statement are true and correct.
ae
S.No Year turnover in Lakhs
త క
1.
2.
3.
Total - Rs. Lakhs
Avg z Rs. Lakhs

| |

కంట ee

pist. 1661102 క్రి
$18031 District, ‘Fajangana-
i
అ. Scanned with OKEN Scanner

<!-- page 10 -->

ACKNOWLEGEMENT & FINANCIAL PROPOSAL
FINANCIAL PROPOSAL (BOQ
To,
THE DISTRICT MEDICAL AND HEALTH OFFICE, Medak
DISTRICT: Medak
Sub: Request for Proposal for "Transportation of Laboratory Samples" in Medak,
Telangana
Sir,
1, Having carefully examined all the parts of the TENDER documents and having obtained
all the requisite information affecting this proposal and being aware of all conditions
and difficulties likely to affect the execution of the agreement, |We hereby propose to
implement the project as described in the TENDER document in conformity with the
conditions of agreement, technical aspects and the sums ind icated in this financial
proposal.
2. We declare that we have read and understood and that we accept all clauses, conditions and
any addendum thereof, and descriptions of the TENDER document without any change,
reservations and conditions.
3. If our proposal is accepted, we undertake to deposit security deposit/Bank Guarantee of Rs.
50,000/- (Rupees One Lakh Only) towards the Project before execution of the formal
agreement.
4. We agree to abide by this proposal/bid for a period of 150 days from the date of its opening
and undertake not to withdraw and to make any modifications unless asked for by you and that
the proposal may be accepted at any time before the expiry of the validity period or the
extended bid validity period.
5. Unless and until the formal agreement is signed, this offer together with your written
acceptance thereof shall constitute a binding contract between me/us and the Government of
Telangana.
6. The Financial Bid shall be inclusive of all the applicable taxes however Service Tax would be
extra as applicable and the government will not pay anything over and above the rate quoted in
the BOQ.
Yours faithfully
Dist AlodisighthteAtapiicer
Megartunteeta 6 ga.
|
|
ఆ Scanned with OKEN Scanner
