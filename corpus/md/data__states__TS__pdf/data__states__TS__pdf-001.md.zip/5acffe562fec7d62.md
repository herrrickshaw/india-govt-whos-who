---
doc_id: "5acffe562fec7d62"
source_url: "https://emunicipal.telangana.gov.in/etistmvcdfwefrzxczx/scsdvcxvcxvcvxc?adsjfasd=NEWS_15052026035925Circular%20No%20712531%20dt%2014.05.2026%20Transfers%20of%20Managers%20%26%20Revenue%20OfficersAO%20%26%20JAO%20-%20Options%20through%20online%20website%20only%20-%20extended.pdf"
ministry: "Commissioner and Director of Municipal Administration, Telangana"
title: "Circular No 712531 dt 14.05.2026 Transfers - Options through online website only - extended    Updated On 15-05-2026 15:59:25"
date: ""
pages: 2
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "ae0971c01047aee5"
---

<!-- page 1 -->

CDMA-M2/ESST/OTH/84/2024-M2 SEC-CDMA 171096002/2026
GOVERNMENT OF TELANGANA
MUNICIPAL ADMINISTRATION DEPARTMENT
O/o Commissioner & Director of
Municipal Administration,
T.G., Hyderabad.
CIRCULAR
Roc.No.712531/2024-26/M2, Dt.14-05-2026
Sub: Estt - Transfers and postings of employees - Lifting of ban on transfers -
Employees working Particulars, Clear Vacancies and list of employees to be
compulsorily transferred in respect of MC’s, Accounts officers, Junior
Accounts officer, Managers/Revenue officers, Sanitary Supervisors and
Sanitary Inspectors working in ULBs - Published - Options through online
web site - Called for Reg.
Ref: 1.G.0.Ms.No.38, Finance (HRM-I) Department, Dated:21.04.2026
2.T/o Cir.Roc.No.712531/2024-26/M2, Dt.01.05.2026 and Dt.08.05.2026.
సలల
The attention of all the MC’s of ULBs in the state & DCs of concerned circles of
GHMC/MMC/CMC and officers/staff mentioned in the address entry are drawn to the refs.,
wherein Govt., have issued orders for relaxation of the ban on transfers and issued
Specific guidelines and a stipulated schedule for implementation. Accordingly, this office
vide reference 2% cited has published Annexure |, II and III i.e. Tenure Particulars, list of
clear vacancies and the list of employees to be compulsory transferred in respect of all
the cadres under the control of C&DMA and called for options from the eligible
candidates in the prescribed form appended on or before 15.05.2026.
2. In order to ensure transparency, free and a fair transfer process, anonline web
site (https://98-130-141-217.nip.io/) has been developed by NIUM to process transfer
as per guidelines issued by the Government and the eligible candidates shall exercise
their options through online mode only.
3. In view of the above, all the MC’s of ULBs in the state & DCs concerned circles of
GHMC/MMC/CMC are hereby requested to communicate the above information to all the
Accounts officers, Junior Accounts officer, Managers/Revenue officers, Sanitary
Supervisors and Sanitary Inspectors working under their control and direct them to
furnish their options through the online application developed by the NIUM, Telangana.
4. The due date for employees to exercise their option has been extended to
18.05.2026 and the eligible employees are directed to exercise their online option on or
before 18.05.2026.
5. “Treat this as most urgent” and any deviations in the matter will be viewed
seriously.
6. The RDMA’s concerned shall issue similar instructions to Zonal/District cadres under
their jurisdiction.
Encl: As above.
T.S.V.N THRILLESHWAR RAO
JOINT DIRECTOR
To
All the MC’s in the State

<!-- page 2 -->

CDMA-M2/ESST/OTH/84/2024-M2 SEC-CDMA 171096002/2026
The Deputy Commissioners concerned of GHMC/MMC/CMC
All the Accounts officers, Junior Accounts officer Managers/Revenue officers, Sanitary
Supervisors and Sanitary Inspectors working in ULBs
(through the MC’s/DC’s concerned)
Copy placed at Department official website (https://emunicipal.telangana.gov.in.)
Copy placed at Display Board of this office.
Copy to the RDMAs, Hyderabad & Warangal region for n/a.
All the Additional Collectors (LB) in the state except Hyderabad
All the District Collectors in the state except Hyderabad.
Copy submitted to the Secretary to Govt., Municipal Administration Dept.,
Dr.B.R.Ambedkar Secretariat, Telangana, Hyderabad.
Digital signed by
TANNERU SAI VERKATA NAGA THRILLESHWAR RAO
Date: 1405-2026 13:57:36
