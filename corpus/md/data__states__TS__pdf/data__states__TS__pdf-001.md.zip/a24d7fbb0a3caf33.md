---
doc_id: "a24d7fbb0a3caf33"
source_url: "https://cdn.s3waas.gov.in/s389f0fd5c927d466d6ec9a21b9ac34ffa/uploads/2026/10/17929965173023.pdf"
ministry: "Mulugu"
title: "AYUSH Notification (598 KB)"
date: ""
pages: 5
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "4b3f1cc322a6ced8"
---

<!-- page 1 -->

1
GOVERNMENT OF TELANGANA
OFFICE OF THE DISTRICT COLLECTOR AND MAGISTRATE;
MULUGU DISTRICT
NOTIFICATION
Ref; No.2835/E-1/RDDW/MLG/2026 Date23/ 10/2026

Sub: Department of AYUSH - National AYUSH Mission - Engaging various
categories of services on outsourcing basis to carry out AYUSH
Public Health Programmes in Mulugu District on
outsourcing basis to work under the administrative control of
Director, Department of AYUSH, 7.G., Secunderabad up to
31/3/2027 -Regarding.

one

Government vide G.O.Rt.No.1508, Fin (HRM.VI) Dept., Dt:21/08/2026
have accord permission for (333) various categories of services i.e. , thirty eight
(38) services on contract and two hundred and ninety five (295) services on
outsourcing basis, the Director, Department of AYUSH, T.G., Secunderabad have
requested the Collector & District Magistrate, Mulugu District to fill up only (10)
posts in (5) categories which are sanctioned in Mulugu District through District
Selection Committee (DSC) as the posts are exclusively meant for AYUSH
Department under Public Health Programme in National AYUSH Mission,

Hence, Applications are invited for the following posts to work on
outsourcing basis under AYUSH Public Health Programmes in Mulugu District
up to 31.03.2027 under the administrative control of Director, Department of
AYUSH, T.G., Secunderabad,

The applications be received for the above said posts from
కమర. to Dt: 16. between 10:30 AM to 05:00 PM (on
working days). Applications are to be submitted in person or through i"
Registered Post at Cj Riiatticemigtamde Mulugu District, NOS CoN,
The applications, which are received after the due date (i.e., Dt: q poc- యొక
లాలా will be summarily rejected. District Selection Committee థ్రీ అ”
not responsible for the postal delays. Dme AA

The remuneration and educational qualifications prescribed for the
respective categories shall be as specified in the approved guidelines and
Government Orders,

1. METHOD OF RECRUITMENT:

The recruitment is to be made on outsourcing basis up to 31.03.2027 and
thereafter the services will be as per the need and also subject to satisfactory
performance,

The recruitment shall be done by the District Selection Committee of the
District Health Society.

The District Selection Committee shall consist of the following members:

[ a) [District Collector |: | Chairman |

Concerned Regional Deputy Director, Member /
Department of AYUSH Convener

ice) [OA aes le నాడా ew లు.

|) | Deputy Director Social Welfare |: [Member |

(9౨౦౫౩ [: [Member |

AYUSH District Nodal Officer [: [Member |

Resi Qed ఆయుపి DU ,
iN
Mm DMe HO office
వ

<!-- page 2 -->

2
Selections will be done based on the following criteria

a) Total Marks are 100 of which 90 marks will be allotted basing on the marks
obtained in qualifying examination for AYUSH Doctor with PG
Qualification, AYUSH Medical Officer, Pharmacists, Dieticians,
Psychosocial Counselor and Yoga Professional,

b) For Multi-Purpose-Worker, 90 marks will be allotted for written test
conducted by the concerned authorities.

0) For all the posts, (10) marks will be awarded for the age, Weightage for age
will be reckoned from 18 years of age of the candidate 0.5 mark will be
awarded for one completed year of age with a maximum of 10 marks. The
age will be reckoned as on 1.7.2026 (Example 1, If a candidate completes
20 years as on 1.7.2026, he will be awarded 1.0 mark; Example 2. If a
candidate completes 30 years of age as on 1.7.2026, he/she will be
awarded 6.0 marks, Example 3. If a candidate completes 40 years of age
as on 1.7.2026, he/she will be awarded 10,0 marks).

d) Merit list will be prepared based on the marks obtained with above
criteria and displayed on website for transparency.

6) Selection list will be prepared from the finalized merit list duly following
the rule of reservation and Presidential Order.

f) For Psychosocial Counselor, a panel of eligible candidates may be
empaneled. The empaneled candidates shall be engaged on a call basis,
as and when their services are required,

Il, Posts to be engaged:
The Mulugu District wise post position is shown below:
శే కైక క్షే #
mae "జ్ర టై. §
pitt oe | RR d LEE Be వీ
istrict as g ge E | ;
BS6 a పై g
= బ్‌ వ్‌ { ౯
Mangudmne [క్‌ 972 (0౪0
Total posts in the |
district in each 1 1 4 10కి
catego!
No, of
Name of the | persons Rem
Post fo ne Roster point aie
engaged
1, oC
AYUSH
1. Medical 2. SC(Group.II)
Officer ee
4. BC-A
[Pharmacist [i | oc TT
Psychosocial
[s | mong మమ | ec | |
District
ot. (peel ee
Professional ¥
Sea wilt a

<!-- page 3 -->

3
Ill. REMUNERATION:
Sl. Consolidated pay per
No. month (in Rs.)
[| AYUSH Medical Officer Rs.40,000/-
(al nese TE ఎ...
@ Rs,500/- per session &
3. Psychosocial Counselor atleast 200 visits in a year
{on Call)
Yoga Professional Rs,28,000/-
See ee |
IV. EDUCATIONAL QUALIFICATION:
| Name of the post Required qualification
Must possess a Degree in Ayurveda or Unani or
Homoeopathy or Naturopathy system awarded by
a University in India established or incorporated
by or under Central Act or State Act or Provincial
Act or an institution recognized by the University
గ్‌ Grants Commission or any statutory Board of the
1 aoe Medical State Government after having undergone a
. regular course of institutional study in the
respective systems, both in theory and practice for
a period not less than 4 % years duration in a
teaching institution recognized by the university
or state government with one year compulsory
internship.
i) Must possess any of the following *
qualifications: గ ?
mee Sse
a. D Pharmacy
Fs b. B Pharmacy ని 79 ie
Pharmacist 6 PharmaD ‘ Fi .
ii) Must be registered with the Telangana
Pharmacy Council
Psychosocial
Sus Must possess a Post Graduate Degree in Master of
easier ke హా Social Work (MSW) awarded by a University in
BOA Walla tn’a voor India established or incorporated by or under
(on Call) @ Rs. Mas /- Central Act or an Institution recognized by the
per session & atleast University Grants Commission.
200 visits in a year
Must possess any of the following qualifications:
i. Must possess a Degree in Naturopathy
Yoga Professional . system awarded by a University in India
శ established or incorporated by or under
central Act or State Aet or Provincial Act or
an institution recognized by the University
Grants Commission or any statutory Board

<!-- page 4 -->

4
of the State Government after having
undergone a regular course of institutional
study in the respective systems , both in
theory and practice for a period not less than
4 % years duration in a teaching institution
recognized by the university or state
government with one year compulsory
internship,

ii. Must possess a ‘Diploma in Naturopathy and
Yogic Sciences’ awarded by a University in
India established or incorporated by or
under Central Act or State Act or Provincial
Act or an institution recognized by the
University Grants Commission or any
statutory Board of the State Government.

reTichate meen యిల cmmlaton.
Vv. AGE
The minimum age is 18 years and the maximum age is 44 years. The
minimum and maximum age shall be reckoned as on 01/07/2026 with the
following relaxations allowed for reckoning the maximum age limit as per
rules;
i. For S,C’s, S.T’s & BC’s 5 (Five) years.
ii. For Ex-Service man 3 (Three) years in addition to the length of service
in armed forces.
iii. Disable persons 10 (ten) years.
VI. RULE OF RESERVATION:

Rules of Reservation in respect of Community, Disability, Ex-service Men
shall be strictly observed as per the Telangana State and Subordinate Service
Rules, 1996, read with the relevant Specific Rules applicable.

The Rule of Reservation of Local candidates is applicable as per *
Presidential order.

లి
Vil. UNIT OF APPOINTMENT:
Local
Name of the post Cadre | reservat Unit of appointment
ion (%)
Multi Can apply in any District in
/ the concerned Multi Zone,
AYUSH Medical Officer Chien but welsction shall’ be
restricted to one District.
2 Pharmacist | District |

Psychosocial

Counselor (on Call) @

Rs,500/- per session

& atleast 200 visits in లా

a year (on Call) @ సు

Rs.500/- per session

& atleast 200 visits in

a year
[@ | Yoga Professional [istrict

<!-- page 5 -->

5

Vill. HOW TO APPLY

a) Application forms along with the instructions can be downloaded from
official website of Mulugu District.

b) Filled in application forms shall be submitted in person or through
registered post to the O/o, the Collector & District Magistrate, Mulugu
District, Applications which are received after due dates will be summarily
rejected, District Selection Committee is not responsible for postal delays.

c) Self attested copies of the following certificates should be enclosed with
the application form,

a SSC or equivalent examination

[2 | Intermediate or 10+2 examination

[3 Qualifying Examination Pass Certificate

$ i Marks memos of all the years (qualifying examination) .
Registration Certificates of Board of Indian Medicine (for AYUSH
Doctor with PG Qualification and Medical Officer Posts)
Registration Certificate of the Telangana Pharmacy Council (for
Pharmacist post)

Latest Caste Certificates issued by the Tahsildar / MRO concerned |
Study Certificate for the years from 4th Class to 10th class and in
case of Private Study Residency Certificate from the Tahsildar /
MRO concerned
PH Certificate in respect of candidates claiming reservation under
PH Quota

10 Relevant Certificates in respect of candidates claiming Ex-service
“| man quota

1 Photographs duly pasted on the application form స

Acknowledgment card. %

pi strict anchaxge )w odal officey
“MEDICAL OFFICER
Govt. Homoeo Dispensary
= wane a ETURNAGARAM (), a
ve Mal; Eturnagaram, Dist: Mulugl
