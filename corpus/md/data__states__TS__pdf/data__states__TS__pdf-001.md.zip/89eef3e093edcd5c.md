---
doc_id: "89eef3e093edcd5c"
source_url: "https://cdn.s3waas.gov.in/s374071a673307ca7459bcf75fbd024e09/uploads/2023/07/2023071917.pdf"
ministry: "Nalgonda"
title: "THE NALGONDA DISTRICT GAZETTE NEW REVENUE DIVISION CHANDUR NOTIFICATION"
date: ""
pages: 371
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0b226cd16d82cf4d"
---

<!-- page 1 -->

<!-- page 2 -->

HAND BOOK OF STATISTICS
NALGONDA DISTRICT

2022

Compiled & Published by
THE CHIEF PLANNING OFFICER
NALGONDA

<!-- page 3 -->

<!-- page 4 -->

OFFICERS AND STAFF ASSOCIATED

WITH
THE PUBLICATION OF
HAND BOOK OF STATISTICS 2022

2.

SRI M. BALASHOWRY

:

CHIEF PLANNING OFFICER

SRI G. MUTHYAM

:

ASSISTANT DIRECTOR

SRI

D. VIJAY KUMAR

:

DEPUTY STATISTICAL OFFICER

SRI

T. SRIRAM

:

SCIENTIFIC OFFICER (TRAC)

SRI

A. RAGHAVENDRA

:

COMPUTER OPERATOR

<!-- page 5 -->

SALIENT FEATURES OF NALGONDA DISTRICT
HISTORICAL BACKGROUND:
Nalgonda District was not a homogenous administrative unit in the past and its
component parts were under the control of various dynasties at different periods of time.
Nalgonda district formed part of the Kakatiya kingdom and after its down fall it became part
of Bahamani kingdom and subsequently passed on to Qutub Shahi dynasty of Colonna and
on its fall was detached in the early part of 18th Century on the establishment of Hyderabad
state by the Asaf Jahi dynasty. In 1947 when the country attained Independence the princely
states were given a choice either to remain independent or to join the Indian union. The
Nizam’s dominions became part of the Indian union in 1948 as a part “B” state and in 1956
during the Reorganizations of states the Hyderabad state was trifurcated and the nine
predominantly Telugu speaking districts (of which Nalgonda is one among them) known as
Telangana.
PRESENT STATUS:
During the decade 1951 to 1961 the district under went certain territorial changes.
Nagarjunasagar project constructed in Miryalguda. The district at present is administered by
Three Revenue Divisions (1) Nalgonda (2) Miryalaguda and (3) Devarakonda with 31
Mandals in all since bifurcation of District from 11.10.2016 onwards.
BOUNDARIES AND TOPOGRAPHY:
Nalgonda was formerly known as Neelagiri (Blue hill). It is bounded on the north by
Medak and Warangal districts, on the south by Guntur of Andhra Pradesh State and partly by
Mahabubnagar districts, on the east by Suryapet district, on the west partly by Mahabubnagar
district and partly by Rangareddy district.
The district lies in southern part of Telangana region between 160 – 250 and 170 –500
of northern latitude and 780 – 400 and 800 – 500 of eastern longitude. The general scope of
the district is from west and northwest to southeast and the altitude of the district varies from
300’ to 900’ above sea level.

<!-- page 6 -->

RIVERS:
The district is drained and watered by the rivers Krishna, Musi, Dindi, Halia
(ruralised form of Ahalya) and Kanagal. The Krishna River, which is the most important
river, forms the southern boundary.

It first touches the district at Yelleshwaram in

Devarakonda Division/mandal and after a course of 85 Kilometers in the district in the
easterly direction it enters in Krishna district. The Musi is the next important river in the
district. Peddavagu and Dindi are the two other important rivers that flow in Devarakonda
Division and mandal and merge in to Krishna river. All these rivers are tapped for irrigation
purposes. The Nagarjunasagar project constructed across the Krishna River, Musi project
across the Musi river and Dindi project across the Dindi river are some of the important
irrigation projects.

FLORA AND FAUNA:
The total forest area in the district is 1,26,673 acres forming 7.20 percent of the
Geographical area. The forests belong to only fuel types.
SOIL TYPES:
The Soils of the District are mostly consisting of Red Soil. The fertile black cotton
soil forms only 9 percent and occurs on the banks of Krishna and isolated patches here and
there. Among the red soils 47% is dubba soil (Loamy sands), which has a very low moisture
retaining capacity, and the rest is chalka soil, forming 44 %.
CLIMATE AND RAINFALL:
The district is malicious from August to October and very hot during April and May,
the temperature ranging from 97F to 110F. The Rainfall of Nalgonda District is 940.8 m.m.
for the year 2021-22 as against the 704.2 m.m. of Normal Rainfall.
MAJOR CROPS GROWN IN THE DISTRICT:
The Major crops grown in Vanakalam season are Paddy, Groundnut, Cotton,
Redgram, Greengram, Chillies and during Yasangi Paddy, Horsegram, Blackgram,
Bengalgram, Groundnut and Chillies.

<!-- page 7 -->

PLACES OF HISTORICAL AND RELIGIOUS SIGNIFICANCE
PANAGAL:
The Historical place is situated near Nalgonda Town and it is now a part of Nalgonda
Town Municipality. It was once the capital of Kakatiya Kings who ruled over this territory.
Udayasamudram a biggest Tank, the Temples of Pachala Someswara and Chaya Someswara
are the ancient ones, which are worth seeing. Pachala Someswara Swamy appears to have
had costly jewels, made of pearls and precious stones. In the Chaya Someswara Swamy
Temple, 1/2 K.M. away from the village there is shadow on the wall behind the Lingam in
the form of a Pillar. This shadow pillar is always seen on the wall, standing steady in the
same position through out the day.
VIJAYAPURI:
The Township came in to existence on account of construction of Nagarjuna Sagar
Dam across River Krishna Near Nandikonda town of this District. The Ancient ruins and
relics of Budha were preserved in the Island Museum of Nandikonda in the midst of the
Reservoir of Nagarjuna Sagar Dam, which is a largest masonry Dam in the world. This has
been attracting tourists from far and near frontiers of our country.
WADAPALLY:
The village is situated on the left bank of the River Krishna, where river Musi join
Krishna river and it is 24 Kms away from Miryalaguda . Ancient Fort was built in the 14th
Century A.D. Prathap Rudra of Kakatiya Dynasty. Further, two temples are in existence with
in the fort area viz., Agasteshwara Swamy Temple (Siva Temple) and another Narsimha
Swamy Temple.
YADADRI THERMAL POWER PLANT:
Yadadri Thermal Power Plant is an upcoming 4000 megawatt, supercritical thermal
power project coming up at Veerlapalem Village Dameracherla mandal Nalgonda district in
Telangana. The project is second largest in South India.
CHERUVUGATTU TEMPLE:
Sri Jadala Ramalingeshwara Temple is one of the famous Lord Shiva temples in
Telangana which is known as Cheruvugattu temple is situated at Narkatpally mandal of the
district. The famous Mudu Gundlu (Three Stones) on which lord shiva lingam is there.
Devotees can go top by steps. There is a narrow passage to pass(if you don’t want you will
have steps). People belive that all their sins will be gone, by passing through passage. It feels
good and great to pass through narrow passage between stones.

<!-- page 8 -->

INDEX
CONTENT
1. POPULATION

Sl. No.

PAGE NO.

Introduction
1.1
1.2
1.3
1.4
1.5
1.6
1.7
1.8
1.9
1.10
1.11

1-4

Comparison of Demographic Characteristics of District
with State, 2011 Census
Administrative Divisions and Local Bodies by Mandals,
2022
Scheduled Castes Population by Gender, Sex Ratio, 2011
Census
Scheduled Tribes Population by Gender, Sex Ratio, 2011
Census
Child Population, Sex Ratio, Literates and Literacy Rate,
2011 Census
Distribution of Population by Main, Marginal, NonWorkers and Total Workers, 2011 Census
Category wise distribution of Main workers By Mandals,
2011 Census
Category wise distribution of Marginal workers By
Mandals, 2011 Census
Category wise distribution of Total workers By Mandals,
2011 Census
Ranking of Mandals by Population Size, Sex Ratio,
Density and Literacy Rate, 2011 Census
Urban Ward wise Total , SC, ST Population and Literacy
Rates

5-7
8-9
10
11
12
13-14
15
16
17
18
19

2. CLIMATE
Introduction

20-21
22

2.1

Weather Stations By Mandals, 2021-22

2.2

Season wise Rainfall from 2000-01 to 2021-22

23-24

2.3

Season wise Rainfall by Mandals, 2021-22

25-29

2.4
2.5
2.6

Season wise Deficiency of Rainfall from 2017-18 To 202122
Month wise Maximum and Minimum Temperatures,
2021 & 2022
Month wise Relative Humidity and Mean Wind Speed,
2021

30
31
32

2.7

Month wise Ground Water Levels, 2020-21 & 2021-22

33

2.8

Time series data on average Depth to Ground Water level

34

2.9

Mandal wise Average Depth to Ground Water Levels, 2021-22

35

<!-- page 9 -->

2.10

Mandal wise villages Falls in Different Categories By
Ground Water Assesment during previous and latest
Assesment year

36

2.11

Ground Water Quality Parameters by Mandals, 2021-22

37

3. AGRICULTURE
Introduction

38-39

3.1

Season wise Area, Yield and Production of Principal
Crops, 2021-22

40

3.2

Season Wise Cropped Area by Mandals, 2021-22

41-53

3.3

Factory wise Quantity of Sugarcane Crushed and Sugar
Produced, 2020-21 and 2021-22

54

3.4

Season wise Paddy Procurement by Mandals, 2021-22

55

3.5

Consumption of Chemical Fertilizers & Licences issued to
shops by Mandals,
2021-22

56-57

3.6

Consumption of Pesticides by Mandals, 2021-22

58-59

3.7

Area Cultivated for Seed purpose by Mandals, 2021-22

60-61

3.8

Agriculture Infrasructure by Mandals, 2021-22

62-63

3.9
3.10
3.11
3.12
3.13
3.14
3.15

Category Wise Rice Mills and Milling Capacity by
Mandals, 2021-22
Rythu Vedikalu and Rythu Bandu Samithis by Mandals,
2021-22
Category wise Total Operational Holdings and Extent,
2015-16 by Mandals
Category wise Scheduled Castes Operational Holdings
and Extent, 2015-16 by Mandals
Category wise Scheduled Tribes Operational Holdings and
Extent, 2015-16 by Mandals
Category wise Others Operational Holdings and Extent,
2015-16 by Mandals
Category wise Women Operational Holdings and Extent,
2015-16 by Mandals

64
65
66-67
68
69
70
71

<!-- page 10 -->

4. IRRIGATION
Introduction

72-73

4.1

Major Irrigation Projects, 2021-22

74

4.2

Medium Irrigation Projects, 2021-22

75

4.3

Classification of Water Bodies by mandals

76

4.4

Lift Irrigation Schemes, 2021-22

4.5
4.6

Implementation of Micro Irrigation Schemes by Mandals,
2021-22
Area Irrigated under Green Houses and Poly Houses by
Mandals, 2021-22

77-78
79-83
84

5. LIVESTOCK AND FISHERIES
Introduction

85-86

5.1

Veterinary Services At A Glance, 2020-21 & 2021-22

87

5.2

Veterinary Services available by Mandals, 2021-22

88-90

5.3
5.4
5.5

Comparison of Livestock and Poultry Population of
District with State according to Livestock Census, 2019
Livestock and Poultry Population by Mandals according to
Livestock Census 2019
Production of Milk, Meat & Eggs by Mandals,2020-21 &
2021-22

91
92-94
95

5.6

Dairy Development, 2020-21 & 2021-22

96

5.7

Milch Animals Distribution by Mandals, 2021-22

97

5.8
5.9
5.10
5.11
5.12
5.13

Production of Inland Fish and Prawn by Species, 2020-21
TO 2021-22
Production of Inland Fish and Prawn by Mandals, 202122
Information on Fisherman Cooperative Socities and
issuing of Kisan credit cards by Mandals, 2021-22
Implemantation of Integrated Fisheries Development
Scheme (IFDs) by Mandals
Implemantation of Pradhan Manthri Matsya Sampadha
Yojana (PMMSY) by Mandals
Information of Group accident insurance of Scheme
(GAIS) by Mandals

98
99
100
101
102-103
104

<!-- page 11 -->

6. HEALTH AND FAMILY WELFARE
Introduction
6.1
6.2
6.3
6.4

105-106

Comparison of Health Indicators of District with State

107

Government Medical Facilities (Allopathic) at a Glance,
108-109
2021-22
Government Medical Facilities (Allopathic) by Mandals,
110-116
2021-22
Deseases - Patients Treated (Allopathic) By Mandals, 202122
117-118

6.5

Government Hospitals, Dispensaries under Ayush, 202122

119

6.6

Family Welfare Achievements by mandals, 2021-22

120

6.7

Health Indices of Pregnant Women

6.8

6.9

Universal Immunization Programme by Mandals,
202122
Arogyasree, Janani Suraksha Yojana And Janani Shishu
Suraksha Kalyanam Schemes By Mandals,
202122

121-122
123

124

7. EDUCATION
Introduction

125-126

7.1

AT A GLANCE -Number of Educational Institutions in the District 2021-22 (Including Govt.Residential Institutions upto Higher
Secondary)

127

7.2

Management wise Number of Schools upto Higher Secondary by
Total Number of Schools, Teachers and Enrollment, 2021-22
(Including Govt.Residential Institutions upto Higher Secondary)

128-131

7.3

Management wise Primary Schools, Teachers and Enrollment By
Mandals, 2021-22

132

7.4

Facilities Available in Primary Schools By Mandals, 2021-22

7.5

Management wise Upper Primary Schools, Teachers and Enrollment
By Mandals, 2021-22

135

7.6

Facilities Available in Upper Primary Schools By Mandals, 2021-22

136-137

7.7

Management wise High Schools, Teachers and Enrollment By
Mandals, 2021-22

133-134

138

<!-- page 12 -->

139-140

7.8

Facilities Available in High Schools By Mandals, 2021-22

7.9

Management wise Higher Secondary Schools, Teachers and
Enrollment By Mandals, 2021-22

7.10

Facilities Available in Higher Secondary Schools By Mandals, 2021-22

142-143

7.11

Functioning of Bhavitha Centres , 2021-22

144-145

7.12

Government Hostels for Scheduled Castes by Mandals 2021-22

146-147

7.13

Government Hostels for Scheduled Tribes by Mandals, 2021-22

148-149

7.14

Government Hostels for Backward Classes Welfare by Mandals, 202122

150-151

7.15

Government Hostels for Minority Welfare by Mandals, 2021-22

7.16

Welfare Department wise Pre Metric & Post Metric Scholarships by
Mandals, 2021-22

153-155

7.17

Welfare Department wise Overseas Scholarships by Mandals, 2021-22

156

7.18

Management wise Functioning Residential Schools/Colleges by
Category, 2021-22

157

7.19

Gross Enrollment Ratio & Cohort Drop Out Rates, 2019-20 to 2021-22

158

Junior Colleges, Lecturers Employed and Students Enrolled by
Mandals, 2021-22
Results of Secondary School Certificate/Intermediate Examinations,
2017-18 to 2021-22
Colleges at Graduation Level (B.Sc., B.Com.,B.A . etc.) By Mandals,
2021-22

159

7.23

Post Graduation Colleges - By Mandals, 2021-22

162

7.24

Professional Colleges, 2021-22

163

7.20
7.21
7.22

141

152

160
161

8. FORESTRY
Introduction

164-165

8.1

Forest Area by Legal Status By Divisions, 2021-22

166

8.2

Classification of Forest Area by Divisions, 2021-22

167

8.3
8.4
8.5

Forest Blocks, Urban Lung Spaces and Urban Forest
Parks, 2019-20 To 2021-22
Amount realized on Sale of Major and Minor Forest
Produce By Divisions, 2021-22
Functioning of Wild Life Sanctuaries, Tiger Reserves and
Parks, 31-03-2022

167
168
170

<!-- page 13 -->

9. INDUSTRIES AND MINING
Introduction
9.1

9.2

171-172

Category wise No. of Working Units Registered Under
Factories Act, 1948 (Large, Medium & Small Scale
Industries), 2021-22
Working Units of Large, Medium & Small Industries
Registered Under Factories Act, 1948 by Mandals,
2021-22

173-174

175

9.3

Functioning of Micro, Small and Medium Enterprises
Registered under UDYAM by Mandals, 2021-22

176-177

9.4

Telangana State Industrial Project Approval and Self
Certification System (TS-iPASS) by Mandals, 2021-22

178

9.5

Incentives Sanctioned under T-IDEA & T-PRIDE Schemes

179

9.6
9.7
9.8
9.9

Implementation of Nethannaku Cheyutha and Chenetha
Mithra by District
Category wise functioning of Industries under PMEGP,
2021-22
Functioning of Industries under PMEGP by Mandals,
2021-22
Functioning of Trading Rice Mills and Seed Processing
Units by Mandals, 2021-22

180
181
182
183

9.10

Production of Principal Minerals, 2021-22

184

9.11

Mandal Wise industrial Units falls Under Different
Categories of Pollution

185

10. ENERGY
Introduction

186-187

10.1

Growth of Transmission and Distribution Lines from 201920 to 2021-22

188

10.2

Growth of Transmission and Distribution Lines by
Mandals, 2021-22

189

10.3

Category wise Number of Service Connections, Connected
Load and Electricity Consumption, 2020-21 and 2021-22

190

<!-- page 14 -->

10.4

Category wise Number of Service Connections, Connected
Load and Electricity Consumption by Mandals, 2021-22

191-196

10.5

Functioning of Electricity Transformers by Mandals, 202122

197

10.6

Functioning of Electricity Sub-Stations by Mandals, 202122

198

10.7

Flagship Schemes in Power Sector, 2021-22

199

10.8

Category wise Number of Solar Rooftops installed (GRID
Connection) by Mandals, 2021-22

200

11. TRANSPORT AND COMMUNICATIONS
Introduction
11.1
11.2
11.3
11.4

Functioning of Railway Stations and Route Length, 202122
Bus Depots and Employees Working in TSRTC, 2020-21
and 2021-22
Physical & Financial Performance of Telangana State
Road Transport Corporation, 2021-22
Cargo Services and Concessional Bus Passes Provided By
TSRTC, 2021-22

201-202
203
204
205-206
207

11.5

Registered Motor Vehicles of Different Categories

208

11.6

Registered Electric Vehicles of Different Categories

209

11.7

Motor Driving Licenses issued, 2020-21 and 2021-22

210

11.8

length of Roads By Category as on 31.03.2022

211

11.9(a) Roads under Roads & Buildings Department, 2021-22

212

11.9(b) Roads under Panchayat Raj Department, 2021-22

213

11.9(c)
11.10
11.11

Roads under Municipalities and Municipal Corporations,
2021-22
Functioning of Post Offices and Mee Seva Centers By
Mandals, 2021-22
Telephone and Mobile Connections of BSNL,
2019-20 to 2021-22

214
215
216

12. LABOUR AND EMPLOYMENT

12.1

Introduction

217

Applicants Registered and Placements by Employment
Exchanges 2020-21 and 2021-22

218

<!-- page 15 -->

12.2
12.3
12.4

Employment Provided through Job Melas, Pradhan
Mantri Kaushal Vikas Yojana and Deen Dayal Upadhyaya
Grameen Kaushalya Yojana Scheme
Employment in Shops and Commercial Establishments,
2021-22
Implementation of various welfare schemes by labour
department, 2021-22

219
220
221

13. PRICES
Introduction
13.1
13.2
13.3
13.5
13.6
13.7
13.8

222-223

Monthly Average Daily Retail Prices of Six Essential
Commodities, 2021-2022
Monthly Average Weekly Prices of 21 Essential
Commodities, 2021-2022
Daily Average Wages of Agricultural Labourers, 20212022
FARM HARVEST PRICES OF CERTAIN AGRICULTURAL
COMMODITIES FOR THE YEARS 2020-21 & 2021-22
Average Prices of Quarterly Building Materials and Wages
of Construction Labour, 2021-22
Consumer Price Index Numbers for Industrial Workers,
2021-2022
CPI-(R,U & C ) District wise General indicies from April,
2021-March-2022

224
225
226
227
228-230
231
232-234

14. PUBLIC FINANCE AND DISTRICT ECONOMY

14.1
14.2(a)
14.2(b)
14.3
14.4
14.5

Introduction

235

Demand, Collection and Balance from Principal Sources of Revenue,
2020-21 and 2021-22
Documents Registered and Revenue Generated by Stamps &
Registration Dept., 2020-21 and 2021-22
Documents Registered and Revenue Generated by Revenue Dept.,
2020-21 and 2021-22
Demand, Collection and Balance of Motor Vehicle Tax, 2020-21 and
2021-22
Demand, Collection and Balance of Mineral Revenue by Mandals,
2021-22

236

Target and Achievement of Excise Revenue by Mandals, 2021-22

237
238
239
240-241
242

15. BANKING
Introduction

243

15.1

Bank Branches by Mandals

244

15.2

Aggregate Deposits and Gross Bank Credits of Scheduled
Commercial Banks, 2021-22

245

<!-- page 16 -->

15.3
15.4

15.5
15.6
15.7
15.8

Loans Disbursed under Various Schemes, 2021-22
Functioning of Primary Agricultural Co-operative Societies
(PACS), including Farmers Service Co-operative Societies
from 2019-20 to 2021-22
Working of Primary Agricultural Co-operative Societies,
including Farmers Service Co-operative Societies by
Mandals, 2021-22
Working of Co-operative Central Bank from 2019-20 to
2021-22
Short, Medium and Long Term Agricultural Loans
Disbursed by the District Co-operative Central Bank,
2020-21 and 2021-22
Functioning of Mutually Aided Cooperative Societies,
2021-22

246
247

248
249
250
251

16. SOCIAL SECURITY
Introduction
16.1
16.2
16.3
16.4
16.5
16.6

252-253

Food Security Cards in Use and Allotment by Mandals,
2021-22
Consumption of Major Petroleum Products by Mandals,
2021-22
Performance of Mahatma Gandhi National Rural
Employment Guarantee Scheme by Mandals
Functioning of Self Help Groups and Bank Linkages
Provided and Streenidhi Scheme by Mandals, 2021-22
Implementation of Various Welfare Schemes under
various Corporations, 2021-22

256-257

Functioning of Various Groups by Mandals , 2021-22

264

254
255

258
259-263

17. FLAGSHIP SCHEMES
Introduction
17.1
17.2
17.3
17.4
17.5
17.6
17.7

265-267

Implementation of Rythu Bandhu Scheme by Mandals,
268-269
2021-22
Implementation of Rythu Bima Scheme by Mandals, 2021270
22
Achievement under KCR Kits by Mandals, 2021-22
Implementation of Kalyana lakshmi and Shadi Mubarak
Schemes by Mandals, 2021-22
Disbursement of Social Security Pensions under Aasara
by Mandals, 2021-22
Implementation of Sheep Rearing Development
Programme by Mandals, 2021-22
Implementation of Fish Seed Stocking Programme by
Mandals, 2021-22

271-272
273-274
275-277
278
279

<!-- page 17 -->

17.8

Implementation of Mission Bhageeratha by Mandals

280

17.9

Implementation of Mission Kakatiya by Mandals

281

17.10

Implementation of Double Bed Room Housing
programme by Mandals

282

18. WOMEN & CHILD WELFARE

18.1

Introduction

283-285

Functioning of Anganwadi Centres, 2021-22

286-288

Teachers working, Women and Children enrollment in
Anganwadi centres,2021-22
Category wise Malnutrition status of Children aged 5
years,2021-22
Mother & Children care and Supplementary Nutrition ,
2021-22

290-291

18.5

Implementation of Arogya Lakshmi Scheme, 2021-22

293

18.6

Comparison of Health Indicators of District with State

294-295

18.2
18.3
18.4

289

292

<!-- page 18 -->

18.7

Disbursement of Disable Aids,2021-22

296-297

18.8

Old Age Homes by Mandals, 2021-22

298

18.9

Schemes For Differently Abled Persons

299

18.10

Government Welfare Institutions for Children & Women

300

19. JUDICIAL AND POLICE
Introduction

301-302

Disposals and Pendency of Petitions, 2021-22

303

19.1 (a) Disposals And Pendency of Criminal Petitions, 2021-22

304-305

19.1

Court wise Pendency of Cases as on 31.03.2022

306-3010

19.2 (a) Court Wise Pendency of Criminal Cases as on 31.03.2022

311-313

19.2

19.3
19.4
19.5
19.6

Police Stations and Police Force as on 31.03.2022
Major Cognizable Crimes Reported from 2020-21 to 202122
Major Cognizable Crimes Reported by Mandals during
2021-22
Incidents of Fire Accidents by Mandals during

2021-22

314
315
316-317
318

20. RURAL LOCAL BODIES
Introduction
20.1
20.2
20.3
20.4

Building Permissions & Mutations, Trade License Issued
and Births & Deaths Registered, 2021-22
Income and Expenditure of Zilla Praja Parishad 2020-21
& 2021-22
Income and Expenditure of Mandal Praja Parishad 202021 & 2021-22
Income and Expenditure of Gram Panchayats 2020-21 &
2021-22

319
320-321
322
323
324

20.5

Drainage Facilities in Gram Panchayats, 2021-22

325

20.6

Drinking water facilities in GP's, 2021-22

326

20.7
20.8
20.9

Implementation of Swachh Bharat Mission (IHHL)s, 202122
Implementation of Telanganaku Haritha Haram,
202122
Implementation of Palle Pragathi in Gram Panchayats
(Phase I to IV)

327
328-330
331-335

<!-- page 19 -->

21. URBAN LOCAL BODIES
Introduction

336

21.1

Building Permissions & Mutations, Trade License issued
and Births & Deaths Registered by ULBs,
202122

21.2

Income and Expenditure of Urban Local Bodies, 2020-21 & 2021-22
339

21.3

Drainage Facilities in ULBs, 2021-22

340

21.4

Drinking water facilities in ULBs, 2021-22

341

21.5
21.6
21.7

Implementation of Swachh Bharat Mission (IHHL) in
ULBs, 2021-22
Implementation of Telanganaku Haritha Haram in ULBs ,
2021-22
Implementation of Pattana Pragathi in Urban Local Bodies

337-338

342
343-344
345-351

<!-- page 20 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

Chapter- 1
INTRODUCTION
The Government of India, in exercise of the powers conferred under the provisions of
the Census Act 1948, is responsible for conducting the population census across the country
once a decade and releasing the results in
different phases. Accordingly, the Government
of India conducted the population census in the
year 2011 and released the final results, up to
the village level, indifferent classifications.
The

District

is

bifurcated

from

the

residual District of Nalgonda on 11-10-2016
with (3) Revenue Divisions viz., Nalgonda,
Miryalaguda and Devarakonda (31) Mandals
including

(8)

Municipalities

i.e.,Nalgonda,

Miryalaguda, Devarakonda, Chandur, Chityala,
Nakrekal, Haliya and Nandikonda.
Madgulapally,Adavidevulapally,
Tirumalagiri

Sagar,

Kondamallepally

and

Neredugommu have formed as new mandals apart from the existing (26) Mandals. It is
bounded on the north by Medak and Warangal districts, on the south by Guntur of Andhra
Pradesh State, on the east by Suryapet district, on the west partly by Mahabubnagar district
and partly by Rangareddy district. The Geographical area of this district is 7122 Sq.Kms. The
district lies between 160 – 250 and 170 –500 of northern latitude and 780 – 400 and 800 – 500
of eastern longitude.

1

<!-- page 21 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

KEY HIGHLIGHTS
Total Population
The total population of Nalgonda District as of 2011 was 16,18,416.
This was nearly 4.62% of the population of Telangana in 2011.

Gender-wise Population
The total female population in Nalgonda 8,00,110 and 8,18,306 are males.
The shares of females and males in the total population of the state are 4.6%
and 4.64% respectively.
The sex ratio(the number of females per thousand males) of the state 978.

Urban and Rural Population
The urban and rural population of the Nalgonda District are 2,59,244 and 13,59,172
respectively.
The share of the urban and rural population out of the total population in the
District is 16.02% and 83.98% respectively.

Social Groups
The total SC and ST population of the Nalgonda District are 2,92,951, and 2,09,252
respectively.
The two social groups account for 18.10% and 12.93% of the district’s total population
respectively.

Literacy
14,36,420 persons (> 6years of age) in the Districts literate are 9,15,742 Out of
which 3,81,169 are females and 5,34,573 are males.
The total literacy rate of the district’s 63.75%.
The literacy rate among the females and males respectively is 53.46% and 73.90%


Literacy Rate
90

80

80
70
60

67 67

73

70
63 62

62 63

59 59 61

65 64

61 62

64

61

58
48 47

50

64
58 56

51

56

55 53

45

55
48

40
30
20
10

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet

0

2

<!-- page 22 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

POPULATION
Nalgonda
Miryalaguda
Devarakonda
Nakrekal
Chityala
Peddavoora
Narketpally
Chandur
Dameracherla
Pedda Adiserla Pally
Sali Gouraram
Kattangoor
Gundlapally
Munugode
Chinthapally
Nidamanur
Thripuraram
Gurrampode
Anumula
Kangal
Nampalle
Tirumalagiri Sagar
Kethepally
Marriguda
Madugulapally
Thipparthi
Chandampet
Kondamallepally
Vemulapally
Neradugommu
Adavi Devula Pally

207076
175838
67107
60758
55600
54877
50864
50338
49697
47294
47075

46831
46380
45477
45058
43848
43471
43280
42070
41615
39775
38694
37533
36968
36488
34333
32791
32277
26093
21661
17249
0

50000

100000

Population

3

150000

200000

250000

<!-- page 23 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

SC, ST and other Population
SC, 292951,
18%
SC
Others,
1116213,
69%

ST, 209252,
13%

ST
Others

Table

Content

1.1

Comparison of Demographic Characteristics of District with State, 2011
Census

1.2

Administrative Divisions and Local Bodies by Mandals, 2022

1.3

Scheduled Castes Population by Gender, Sex Ratio, 2011 Census

1.4

Scheduled Tribes Population by Gender, Sex Ratio, 2011 Census

1.5

Child Population, Sex Ratio, Literates and Literacy Rate, 2011 Census

1.6

Distribution of Population by Main, Marginal, Non-Workers and Total
Workers, 2011 Census

1.7

Category wise distribution of Main workers By Mandals, 2011 Census

1.8

Category wise distribution of Marginal workers By Mandals, 2011 Census

1.9

Category wise distribution of Total workers By Mandals, 2011 Census

1.10

Ranking of Mandals by Population Size, Sex Ratio, Density and Literacy Rate,
2011 Census

1.11

Urban Ward wise Total , SC, ST Population and Literacy Rates

4

<!-- page 24 -->

Municipalities

Zilla Praja Parishads
Mandal Praja Parishads
Gram Panchayats
Revenue Mandals
Census Villages (as per 2011 census)

Inhabited Villages
Un-inhabited Villages
Households
Household size
Density of Population (Persons per sq. km.)

Sex Ratio (Females for 1000 Males)
Population
Males
Females
Rural Population
Males
Females

Sex Ratio
Urban Population

Males
Females

Sex Ratio
No. of Households
Rural

4
5
6
7
8

9
10
11
12
13

14
15
a
b
16
a
b

c
17

a
b

c
18
a

Particulars
2

3

Sl. No.
1
1
Geographical Area
2
Municipal Corporations

5

970
83.04
51.69

69.07
67.02

Lakhs
Lakhs
Ratio
Lakhs
Lakhs

999
136.09

988
350.04
176.12
173.92
213.95
107.05
106.9

9,834
600
83,03,612
4
312

9
438
8,684
584
10,434

42

992
4.02
3.12

1.85
1.83

974
3.68

978
16.18
8.18
8.00
12.50
6.33
6.17

550
16
401,728
4
227

1
31
844
31
566

8

Telangana
District
4
5
112,077
7,122
6
0

Ratio
Lakhs

Ratio
Lakhs
Lakhs
Lakhs
Lakhs
Lakhs
Lakhs

Nos.
Nos.
Nos.
Nos.
Nos.

Nos.
Nos.
Nos.
Nos.
Nos.

Nos.

Unit
3
Sq. kms.
Nos.

COMPARISON OF DEMOGRAPHIC CHARACTERISTICS OF DISTRICT WITH STATE, 2011 CENSUS

TABLE - 1.1

11.11
7.08
9.72
5.31
5.42

19.05

6.35
0.00

102.27
4.84
6.04

2.68
2.73

97.50
2.70

98.99
4.62
4.64
4.60
5.84
5.91
5.77

5.59
2.67
4.84
100.00
72.76

6

% over State

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 25 -->

Urban
Total Literacy rate
Males
Females

Rural
Urban
Total SC Population
Males

Females

Rural
Urban
Sex Ratio

Total ST Population
Males
Females
Rural
Urban
Sex Ratio

Total Child Population
Males
Females
Rural
Urban

c
d
21
a

b

c
d
e

22
a
b
c
d
e

23
a
b
c
d

Urban
Average Household Size
Literates
Males
Females
Rural

d
20
a
b

Sl. No.
1
b
c
19
a
b
c

Particulars
2

6

Ratio
Lakhs
Lakhs
Lakhs
Lakhs
Lakhs

Lakhs
Lakhs
Lakhs

Ratio
Lakhs
Lakhs

Lakhs
Lakhs

Rate
Rate
Lakhs
Lakhs
Lakhs

Rate
Rate
Rate

38.99
20.18
18.81
23.69
15.3

31.78
16.08
15.7
28.3
3.48
977

40.72
13.37
1,008

27.16

57.3
81.09
54.09
26.93

97.95
66.54
75.04
57.99

Lakhs

1.82
0.95
0.87
1.43
0.39

2.09
1.09
1.00
1.94
0.15
915

2.44
0.49
1007

1.47

58.26
82.17
2.93
1.46

2.71
63.75
73.90
53.46

Telangana
District
4
5
31.35
0.90
4
4
206.97
9.16
117.02
5.35
89.95
3.81
109.02
6.45

Unit
3
Lakhs
Nos.
Lakhs
Lakhs
Lakhs
Lakhs

4.67
4.71
4.63
6.04
2.55

6.58
6.78
6.37
6.86
4.31
93.65

5.99
3.66
99.90

5.41

101.68
101.33
5.42
5.42

2.77
95.81
98.48
92.19

2.87
100.00
4.43
4.57
4.24
5.92

6

% over State

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 26 -->

7

Household Industries
Others
Main workers
Rural

Urban
Cultivators
Agriculture Labourers
Household Industries

Others

Marginal Workers
Rural
Urban

e
f
25
a

b
c
d
e

f

26
a
b

Particulars
2

c
Cultivators
d
Agriculture Labourers
e
Household Industries
f
Others
27
Non Workers
Source: Registrar General and Census Commissioner, India

Sex Ratio
Total Workers
Rural
Urban
Cultivators
Agriculture Labourers

Sl. No.
1
e
24
a
b
c
d

Lakhs
Lakhs
Lakhs

Lakhs
Lakhs
Lakhs
Lakhs
Lakhs

Lakhs
Lakhs
Lakhs
Lakhs

Lakhs
Lakhs
Lakhs
Lakhs
Lakhs

Unit
3
Ratio
Lakhs
Lakhs
Lakhs
Lakhs
Lakhs

1.57
13.25
1.41
9.99
186.62

26.22
17.77
8.45

55

41.68
29.94
45.9
6.36

7.77
64.99
137.2
95.52

932
163.42
113.28
50.14
31.51
59.15

Telangana
4

0.06
0.77
0.05
0.26
8.12

1.14
0.97
0.16

2.12

1.18
1.53
3.12
0.15

0.2
2.38
6.99
5.73

District
5
917
8.14
6.70
1.35
1.59
3.90
6

3.82
5.81
3.55
2.60
4.35

4.35
0.00
0.00

3.85

0.00
5.11
6.80
2.36

2.57
3.66
5.04
0.00

98.39
4.93
0.00
0.00
5.05
6.59

% over State

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 27 -->

2

8

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl No

239.45
241.21
191.67
224.73
152.41
151.58
184.88
357.93
225.12
233.96
213.37
2416.31
203.18
212.23
161.29
219.04
113.78
252.58
225.58
127.46
259.52
388.76
2163.42

3

(in Sq. Kms.)

Geographical
Area

28486
25916
23577
23616
30326
18836
17395
103757
21277
23396
25492
342074
21051
22088
21808
18322
13099
88440
25085
8827
19946
27466
266132

4

Male

27114
24948
23254
23459
30432
18697
16938
103319
20338
22081
24846
335426
21019
21760
21663
18166
12994
87398
24612
8422
18748
27411
262193

5

Female

Population

55600
50864
46831
47075
60758
37533
34333
207076
41615
45477
50338
677500
42070
43848
43471
36488
26093
175838
49697
17249
38694
54877
528325

6

Total

13937
12770
11451
12129
15588
9829
8636
50347
10391
11269
12459
168806
10847
11421
11245
9883
7009
45375
12600
4267
9634
13964
136245

7

Households

76
537

48
101
96

35
58
52
26
48
39
70
72
77
54
45
576
78
65
73

8

Habitations

16
19
18
19
16
13
13
34
24
21
17
210
17
15
15
21
13
24
11
6
14
19
155

9

2
6

1

1

1
1
4
2

1

1

10

Inhabited Un-Inhabited

Revenue Villages

TABLE - 1.2
ADMINISTRATIVE DIVISIONS AND LOCAL BODIES BY MANDALS, 2022

16
19
18
20
16
13
13
35
24
22
18
214
19
15
16
21
13
24
12
6
14
21
161

11

Total

18
29
22
24
17
16
26
31
31
27
23
264
21
29
32
28
12
46
35
13
34
26
276

12

Gram
Panchayats

1
3

1

1
4
1

1

1

1

13

Urban
Local
Bodies

(in Nos.)

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 28 -->

2

Name of the Mandal

3

(in Sq. Kms.)
4

Male
5

Female

Population

22
23
24
25
26
27
28
29
30
31

Marriguda
234.05
18784
18184
Chinthapally
274.31
22757
22301
Nampalle
290.44
20045
19730
Gurrampode
309.3
21824
21456
Pedda Adiserla Pally
297.49
24185
23109
Neradugommu
166.85
11432
10229
Kondamallepally
125.38
16755
15522
Devarakonda
238.01
34209
32898
Gundlapally
269.98
23168
23212
Chandampet
336.13
16941
15850
Devarakonda Division
2541.94
210100 202491
Total
7121.67
818306 800110
Source: Registrar General and Census Commissioner, India.

1

Sl No

Geographical
Area

36968
45058
39775
43280
47294
21661
32277
67107
46380
32791
412591
1618416

6

Total

9031
10907
9551
10521
11221
5043
7148
15207
10372
7676
96677
401728

7

Households

146
70
104
666
1779

48
74
70
68
86

8

Habitations

17
22
27
27
21
9
14
14
19
15
185
550

9

6
16

1
3

1

1

10

Inhabited Un-Inhabited

Revenue Villages

17
22
28
27
22
9
14
15
22
15
191
566

11

Total

20
34
32
37
31
19
26
39
38
28
304
844

12

Gram
Panchayats

1
8

1

13

Urban
Local
Bodies

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

9

<!-- page 29 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

TABLE - 1.3
SCHEDULED CASTES POPULATION BY GENDER, SEX RATIO, 2011 CENSUS
Scheduled Caste Population
Sl. No.

Name of the Mandal

1

2

(No.)

% of SC to
Total
Population

Sex Ratio
(Females per
1000 Males)

Male

Female

Total

3

4

5

6

7

1

Chityala

4865

4655

9520

17

957

2

Narketpally

5812

5675

11487

23

976

3

Kattangoor

5514

5445

10959

23

987

4

Sali Gouraram

5939

5856

11795

25

986

5

Nakrekal

5676

6220

11896

20

1096

6

Kethepally

5117

5163

10280

27

1009

7

Thipparthi

4095

4004

8099

24

978

8

Nalgonda

17349

17925

35274

17

1033

9

Kangal

4264

4283

8547

21

1004

10

Munugode

4944

4691

9635

22

949

11

Chandur
Nalgonda Division

4148

4122

8270

18

994

67723

68039

135762

20

1005

12

Anumula

3962

4054

8016

19

1023

13

Nidamanur

4835

4768

9603

22

986

14

Thripuraram

3635

3570

7205

17

982

15

Madugulapally

4258

4353

8611

24

1022

16

Vemulapally

3658

3628

7286

28

992

17

Miryalaguda

12588

12834

25422

14

1020

18

Dameracherla

2742

2757

5499

11

1005

19

Adavi Devula Pally

688

637

1325

8

926

20

Tirumalagiri Sagar

2111

2095

4206

11

992

21

Peddavoora

4494

4754

9248

17

1058

42971

43450

86421

16

1011

Miryalaguda Division
22

Marriguda

3430

3373

6803

18

983

23

Chinthapally

4464

4461

8925

20

999

24

Nampalle

4229

4408

8637

22

1042

25

Gurrampode

4610

4576

9186

21

993

26

Pedda Adiserla Pally

3745

3762

7507

16

1005

27

Neradugommu

1169

1124

2293

11

962

28

Kondamallepally

2194

2124

4318

13

968

29

Devarakonda

4271

4353

8624

13

1019

30

Gundlapally

4645

4928

9573

21

1061

31

Chandampet

2513

2389

4902

15

951

Devarakonda Division
Total

35270

35498

70768

17

1006

145964

146987

292951

18

1007

Source: Registrar General and Census Commissioner, India.

10

<!-- page 30 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

TABLE - 1.4
SCHEDULED TRIBES POPULATION BY GENDER, SEX RATIO, 2011 CENSUS
Scheduled Tribe Population
Sl. No.

Name of the Mandal

1

2

1
2

Chityala
Narketpally

3
4
5
6
7

Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi

8
9
10
11

(No.)
Male

Female

Total

3

4

5

% of ST
Sex Ratio
to Total
(Females per
Populatio
1000 Males)
n
6

7

509
630

1
1

878
957

744
545
900
254
211

2
1
1
1
1

1829
919
927
868
954

2990
732
288
533
8336
2481
947
11653
959
296

1
2
1
1
1
6
2
27
3
1

992
887
714
753
979
967
879
960
1058
1000

23500

13

937

41
46
53

963
922
895

271

238

322
263
284
467
136

308
481
261
433
118

108

103

Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division

1501
388
168
304
4212

1489
344
120
229
4124

12
13
14
15
16

Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally

1261

1220

17

Miryalaguda

504
5945
466
148
12134

443
5708
493
148
11366

18
19
20

Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar

10358

9971

4087
10834

3767
9692

20329
7854
20526

21

Peddavoora
Miryalaguda Division

6129
51866

5733
48541

11862
100407

22
19

935
936

22
23

Marriguda
Chinthapally

9
12

899
920

Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu

1642
2690
2087
771
6454
5546

3469
5615

24
25
26
27

1827
2925
2266
867
7477
6618

4353
1638
13931
12164

11
4
29
56

921
889
863
838

40
28
28
46
24
13

892
887
968
871
889
915

28
29
30
31

Kondamallepally
12761
6746
6015
Devarakonda
18791
9957
8834
Gundlapally
12804
6505
6299
Chandampet
14983
8006
6977
Devarakonda Division
53194 47315 100509
Total
109272 99980 209252
Source: Registrar General and Census Commissioner, India.

11

<!-- page 31 -->

Child (0-6 years) Population
(in Nos.)
Male
Female
Total
3
4
5

2973
2612
5585
Chityala
2824
2555
5379
Narketpally
2548
2387
4935
Kattangoor
2441
2191
4632
Sali Gouraram
3129
2957
6086
Nakrekal
1993
1917
3910
Kethepally
1914
1663
3577
Thipparthi
11474
10803
22277
Nalgonda
2468
2229
4697
Kangal
2605
2256
4861
Munugode
2713
2508
5221
Chandur
Nalgonda Division
37082 34078
71160
12 Anumula
2352
2287
4639
13 Nidamanur
2368
2205
4573
14 Thripuraram
2529
2228
4757
15 Madugulapally
1888
1803
3691
16 Vemulapally
1329
1295
2624
17 Miryalaguda
9399
8724
18123
18 Dameracherla
2965
2828
5793
19 Adavi Devula Pally
1193
1068
2261
20 Tirumalagiri Sagar
2890
2296
5186
21 Peddavoora
3437
3234
6671
Miryalaguda Division
30350 27968
58318
22 Marriguda
2160
1918
4078
23 Chinthapally
2924
2686
5610
24 Nampalle
2611
2496
5107
25 Gurrampode
2689
2623
5312
26 Pedda Adiserla Pally
3214
2940
6154
27 Neradugommu
1739
1424
3163
28 Kondamallepally
2409
2079
4488
29 Devarakonda
4262
3987
8249
30 Gundlapally
3085
2867
5952
31 Chandampet
2401
2004
4405
Devarakonda Division
27494 25024
52518
Total
94926 87070 181996
Source: Registrar General and Census Commissioner, India.

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

SNo.

879
905
937
898
945
962
869
942
903
866
924
919
972
931
881
955
974
928
954
895
794
941
922
888
919
956
975
915
819
863
935
929
835
910
917

Child Sex Ratio
(female
children per
6

19705
17824
15425
15404
21558
12165
11273
80399
13269
14567
16469
238058
14084
14538
13842
11752
8718
64709
15444
4592
10139
17227
175045
11603
13406
10910
12683
13423
5485
9729
22263
13332
8636
121470
534573

Male
7

13636
12526
10808
10804
16698
8616
8130
66795
8372
9587
11253
177225
10251
10494
9584
8461
6186
50879
10027
2570
5717
12224
126393
7343
8782
6845
8294
8292
2845
5724
15331
8985
5110
77551
381169

Literates
(in Nos.)
Female
8

33341
30350
26233
26208
38256
20781
19403
147194
21641
24154
27722
415283
24335
25032
23426
20213
14904
115588
25471
7162
15856
29451
301438
18946
22188
17755
20977
21715
8330
15453
37594
22317
13746
199021
915742

Total
9

TABLE - 1.5
CHILD POPULATION, SEX RATIO, LITERATES AND LITERACY RATE, 2011 CENSUS

77
77
73
73
79
72
73
87
71
70
72
78
75
74
72
72
74
82
70
60
59
72
74
70
68
63
66
64
57
68
74
66
59
67
74

Male
10

56
56
52
51
61
51
53
72
46
48
50
59
55
54
49
52
53
65
46
35
35
51
54
45
45
40
44
41
32
43
53
44
37
44
53

Female
11

Literacy Rate

67
67
63
62
70
62
63
80
59
59
61
68
65
64
61
62
64
73
58
48
47
61
64
58
56
51
55
53
45
56
64
55
48
55
64

Total
12

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

12

<!-- page 32 -->

60758
37533
34333

Nakrekal

Kethepally

Thipparthi

5

6

7

13

45477

42070
43848
43471
36488
26093
175838
49697
17249
38694

Kangal

Munugode

Chandur
Nalgonda Division

Anumula

Nidamanur

Thripuraram

Madugulapally

Vemulapally

Miryalaguda

Dameracherla

Adavi Devula Pally

Tirumalagiri Sagar

Peddavoora
Miryalaguda Division

9

10

11

13

14

15

16

17

18

19

20

21

22
54877
528325

50338
677500

41615

Nalgonda

8
207076

47075

27697
264113

22023

9879

26147

76274

13906

20051

23098

23611

21427

25436
326284

24363

23123

85102

18394

21132

28265

25700

24119

4

46831

4

Sali Gouraram

1
2
3
25771
24879

3

2

Total Workers

55600
50864

Total
Population

Name of the Mandal

Chityala
Narketpally
Kattangoor

1

Sl.No

23843
225347

19334

9020

22860

64631

11629

16437

18081

20725

18787

24094
285372

21270

20584

74639

15402

17783

22117

23469

20976

23111
21927

5

Main Workers

86
85

88

91

87

85

84

82

78

88

95
87
88

87

89

88

84

84

78

91

90
88
87

6

% of Main
Workers to Total
Workers

2992

3349

6148

2231

3143

2660
2952

3854
38766

2689

859

3287

11643

2277

3614

5017

2886

2640

1342
40912

3093

2539

10463

7

Marginal
Workers

14
15

12

9

13

15

16

18

22

12

5
13
12

13

11

12

16

16

22

9

10
12
13

8

% of Marginal
Workers to
Total Workers

27180
264212

16671

7370

23550

99564

12187

16437

20373

20237

20643

24902
351216

21114

18492

121974

15939

16401

32493

21375

22712

29829
25985

9

Non Workers

DISTRIBUTION OF POPULATION BY MAIN, MARGINAL, NON-WORKERS AND TOTAL WORKERS, 2011 CENSUS

TABLE - 1.6

50
50

43

43

47

57

47

45

47

46

49
52
49

46

44

59

46

44

53

45

54
51
48

10

% of Non
Workers to
Total
Population

(in Nos.)

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 33 -->

14

39775
43280
47294
21661
32277
67107
46380
32791

Nampalle

Gurrampode

Pedda Adiserla Pally

Neradugommu

Kondamallepally

Devarakonda

Gundlapally

Chandampet

25

26

27

28

29

30

31

32

1618416

806091

215694

18747

25266

30720

15017

12142

25856

23961

21569

23242

19174

4

Total Workers

691772

181053

15336

18840

24810

13469

10787

22893

22240

18577

19118

14983

5

Main Workers

Source: Registrar General and Census Commissioner, India.

Total

412591

45058

Chinthapally

24

Devarakonda Division

36968

3

Marriguda

2

1

23

Name of the Mandal

Sl.No

Total
Population

86

84

82

75

81

90

89

89

93

86

82

78

6

% of Main
Workers to Total
Workers

3411

6426

5910

1548

1355

2963

1721

2992

4124

4191

114319

34641

7

Marginal
Workers

14

16

18

25

19

10

11

11

7

14

18

22

8

% of Marginal
Workers to
Total Workers

812325

196897

14044

21114

36387

17260

9519

21438

19319

18206

21816

17794

9

Non Workers

50

48

43

46

54

53

44

45

45

46

48

48

10

% of Non
Workers to
Total
Population

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 34 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

TABLE - 1.7
CATEGORY WISE DISTRIBUTION OF MAIN WORKERS BY MANDALS, 2011 CENSUS
(in Nos.)
Classification of Main Workers
Sl.No

Name of the Mandal

1

2

Cultivators

Agricultural
Labourers

Household
Industry

3

4

5

Other
Workers

Total Main
Workers

6

7

1

Chityala

3593

7677

887

10954

23111

2

Narketpally

4296

9233

812

7586

21927

3

Kattangoor

3054

12764

919

4239

20976

4

Sali Gouraram

5500

14670

215

3084

23469

5

Nakrekal

3572

7386

1062

10097

22117

6

Kethepally

4282

10061

267

3173

17783

7

Thipparthi

4787

7486

200

2929

15402

8

Nalgonda

8536

14003

2145

49955

74639

9

Kangal

5105

11896

345

3238

20584

10

Munugode

4273

11753

713

4531

21270

11

Chandur

3846

12090

1121

7037

24094

12

GATTUPPAL

1015

3752

495

2649

7911

51859

122771

9181

109472

293283

13

Anumula

4465

9109

288

4925

18787

14

Nidamanur

4602

12535

375

3213

20725

15

Thripuraram

4413

10126

230

3312

18081

16

Madugulapally

5369

8149

253

2666

16437

17

Vemulapally

2243

7260

178

1948

11629

18

Miryalaguda

6515

17943

985

39188

64631

19

Dameracherla

4350

13390

165

4955

22860

20

Adavi Devula Pally

1924

6009

93

994

9020

21

Tirumalagiri Sagar

4519

12790

255

1770

19334

22

Peddavoora

6448

10573

222

6600

23843

44848

107884

3044

69571

225347

23

Marriguda

3701

8126

273

2883

14983

24

Chinthapally

4548

10030

319

4221

19118

25

Nampalle

6566

9452

280

2279

18577

26

Gurrampode

6537

12764

285

2654

22240

27

Pedda Adiserla Pally

8937

11450

263

2243

22893

28

Neradugommu

3920

5577

91

1199

10787

29

Kondamallepally

2683

6421

262

4103

13469

30

Devarakonda

6598

7806

405

10001

24810

31

Gundlapally

7126

7287

409

4018

18840

32

Chandampet

6401

6309

756

1870

15336

57017

85222

3343

35471

181053

153724

315877

15568

214514

699683

Nalgonda Division Total

Miryalaguda Division Total

Devarakonda Division Total
Total

Source: Registrar General and Census Commissioner, India.

15

<!-- page 35 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

TABLE - 1.8
CATEGORY WISE DISTRIBUTION OF MARGINAL WORKERS BY MANDALS, 2011 CENSUS
(in Nos.)
Classification of Marginal Workers
Sl.No

Name of the Mandal

1

2

Cultivators

Agricultural
Labourers

Household
Industry

Other
Workers

3

4

5

6

Total
Marginal
workers
7

1

Chityala

46

1802

109

703

2660

2

Narketpally

76

2182

162

532

2952

3

Kattangoor

102

2357

184

500

3143

4

Sali Gouraram

126

1774

56

275

2231

5

Nakrekal

72

4440

426

1210

6148

6

Kethepally

101

2605

51

592

3349

7

Thipparthi

152

2188

112

540

2992

8

Nalgonda

450

3928

795

5290

10463

9

Kangal

137

1797

55

550

2539

10

Munugode

152

2523

56

362

3093

11

Chandur

66

736

19

521

1342

1480

26332

2025

11075

40912

Nalgonda Division Total
13

Anumula

362

1647

121

510

2640

14

Nidamanur

160

2197

92

437

2886

15

Thripuraram

332

4094

104

487

5017

16

Madugulapally

221

2610

83

700

3614

17

Vemulapally

101

1830

75

271

2277

18

Miryalaguda

423

7288

370

3562

11643

19

Dameracherla

93

2349

85

760

3287

20

Adavi Devula Pally

91

656

15

97

859

21

Tirumalagiri Sagar

242

2040

182

225

2689

22

Peddavoora
Miryalaguda Division Total

175

2334

89

1256

3854

2200

27045

1216

8305

38766

23

Marriguda

109

3631

82

369

4191

24

Chinthapally

236

2985

257

646

4124

25

Nampalle

124

2311

39

518

2992

26

Gurrampode

110

1299

38

274

1721

27

Pedda Adiserla Pally

363

2195

47

358

2963

28

Neradugommu

107

851

30

367

1355

29

Kondamallepally

252

785

42

469

1548

30

Devarakonda

391

3287

331

1901

5910

31

Gundlapally

629

4741

168

888

6426

32

Chandampet

241

2034

285

851

3411

2562

24119

1319

6641

34641

6242
77496
Total
Source: Registrar General and Census Commissioner, India.

4560

26021

114319

Devarakonda Division Total

16

<!-- page 36 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

TABLE - 1.9
CATEGORY WISE DISTRIBUTION OF TOTAL WORKERS BY MANDALS, 2011 CENSUS
(in Nos.)
Classification of Total Workers
Sl.No

Name of the Mandal

1

2

Cultivators

Agricultural
Labourers

Household
Industry

Other
Workers

Total Workers

3

4

5

6

7

1

Chityala

3639

9479

996

11657

25771

2

Narketpally

4372

11415

974

8118

24879

3

Kattangoor

3156

15121

1103

4739

24119

4

Sali Gouraram

5626

16444

271

3359

25700

5

Nakrekal

3644

11826

1488

11307

28265

6

Kethepally

4383

12666

318

3765

21132

7

Thipparthi

4939

9674

312

3469

18394

8

Nalgonda

8986

17931

2940

55245

85102

9

Kangal

5242

13693

400

3788

23123

10

Munugode

4425

14276

769

4893

24363

11

Chandur

3912

12826

1140

7558

25436

53339

149103

11206 120547

334195

Nalgonda Division Total
13

Anumula

4827

10756

409

5435

21427

14

Nidamanur

4762

14732

467

3650

23611

15

Thripuraram

4745

14220

334

3799

23098

16

Madugulapally

5590

10759

336

3366

20051

17

Vemulapally

2344

9090

253

2219

13906

18

Miryalaguda

6938

25231

1355

42750

76274

19

Dameracherla

4443

15739

250

5715

26147

20

Adavi Devula Pally

2015

6665

108

1091

9879

21

Tirumalagiri Sagar

4761

14830

437

1995

22023

22

Peddavoora

6623

12907

311

7856

27697

47048

134929

4260

77876

264113

Miryalaguda Division Total
23

Marriguda

3810

11757

355

3252

19174

24

Chinthapally

4784

13015

576

4867

23242

25

Nampalle

6690

11763

319

2797

21569

26

Gurrampode

6647

14063

323

2928

23961

27

Pedda Adiserla Pally

9300

13645

310

2601

25856

28

Neradugommu

4027

6428

121

1566

12142

29

Kondamallepally

2935

7206

304

4572

15017

30

Devarakonda

6989

11093

736

11902

30720

31

Gundlapally

7755

12028

577

4906

25266

32

Chandampet

6642

8343

1041

2721

18747

59579

109341

4662

42112

215694

159966

393373

20128 240535

814002

Devarakonda Division Total
Total

Source: Registrar General and Census Commissioner, India.

17

<!-- page 37 -->

2

1

3

Total
4

% to District
Population

Chityala
55600
3
Narketpally
50864
3
Kattangoor
46831
3
Sali Gouraram
47075
3
Nakrekal
60758
4
Kethepally
37533
2
Thipparthi
34333
2
Nalgonda
207076
13
Kangal
41615
3
Munugode
45477
3
Chandur
50338
3
Nalgonda Division Total
677500
13 Anumula
42070
3
14 Nidamanur
43848
3
15 Thripuraram
43471
3
16 Madugulapally
36488
2
17 Vemulapally
26093
2
18 Miryalaguda
175838
11
19 Dameracherla
49697
3
20 Adavi Devula Pally
17249
1
21 Tirumalagiri Sagar
38694
2
22 Peddavoora
54877
3
Miryalaguda Division Total
528325
23 Marriguda
36968
2
24 Chinthapally
45058
3
25 Nampalle
39775
2
26 Gurrampode
43280
3
27 Pedda Adiserla Pally
47294
3
28 Neradugommu
21661
1
29 Kondamallepally
32277
2
30 Devarakonda
67107
4
31 Gundlapally
46380
3
32 Chandampet
32791
2
Devarakonda Division Total
412591
Total
1618416
Source: Registrar General and Census Commissioner, India.

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.No

Population

952
963
986
993
1003
993
974
996
956
944
975
998
985
993
991
992
988
981
954
940
998
968
980
984
983
956
895
926
962
1002
936

19
16
17
25
29
2
9
31
22
6
24
15
21
18
10
30
28
3
13
27

6

Ratio

5
7
12
11
4
23
26
1
20
14
8

5

Rank

18
20
17
14
15
24
31
30
22
2
29

3
13
7
10
9
11
16
25
28
4

26
21
12
6
1
8
19
5
23
27
18

7

Rank

Sex Ratio

(in Nos.)

70
68
63
66
64
57
68
74
66
59

75
74
72
72
74
82
70
60
59
72

77
77
73
73
79
72
73
87
71
70
72

21
22
27
25
26
31
23
7
24
30

6
8
13
17
9
2
19
28
29
14

4
5
10
11
3
15
12
1
18
20
16

45
45
40
44
41
32
43
53
44
37

55
54
49
52
53
65
46
35
35
51

56
56
52
51
61
51
53
72
46
48
50

21
22
27
24
26
31
25
8
23
28

6
7
17
12
9
2
20
29
30
14

4
5
11
13
3
15
10
1
19
18
16

55
58
64
59
62
72
61
50
60
67

47
48
52
50
48
38
55
67
68
53

45
45
49
49
41
50
49
32
54
52
50

12
10
5
9
6
1
7
17
8
4

26
24
16
20
25
30
11
3
2
14

28
27
22
21
29
19
23
31
13
15
18

Literacy Rate by Gender, 2011
Males
Females
Total
Rate
Rank
Rate
Rank
Rate
Rank
8
9
10
11
12
13

TABLE - 1.10
RANKING OF MANDALS BY POPULATION SIZE, SEX RATIO,DENSITY AND LITERACY RATE, 2011 CENSUS

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 38 -->

19

MIRYALAGUDA

DEVARAKONDA

CHIYAL

CHANDUR

HALIYA

NANDIKONDA

NAKREKAL

2

3

4

5

6

7

8
Total
252.29

22.86

38.80

42.84

25.01

29.97

32.45

28.36

32.00

3

Geographical
Area (in Sq.Kms)

182

20

12

12

10

12

20

48

48

4

No.of
Wards

Source: Registrar General and Census Commissioner, India.

NALGONDA

2

1

1

Name Of the Muncipality

Sl No

95392

7177

4254

4379

3128

3702

6433

26800

39519

5

Households

390236

29126

15887

17371

12889

14986

29731

104918

165328

6

Population

53343

4660

3086

2193

1237

2642

2894

11199

25432

7

SC
Population

URBAN WARDWISE SC, ST POPULATION & LITERACY, DENSITY , 2011 CENSUS

TABLE NO 1.11

14928

212

1003

860

144

212

3720

6295

2482

8

ST
Population

(In.No)

68

70

61

65

61

67

64

73

80

9

Literacy
Rate

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 39 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

Chapter - 2
INTRODUCTION
Nalgonda district is geographically located in a
semi-arid area and has a predominantly hot
and dry climate. Summer starts in March, and
reaches its peak in May with an average high
temperature of around 40.0°C (104.0°F). The
South-West

Monsoon enters the district

in

June and lasts until September with about 80
percent precipitation of annual normal rainfall.
A dry, mild winter starts in late November and lasts until early February with little humidity and
average temperatures in the range of 18.0–30.0°C (64–86°F).
KEY HIGHLIGHTS
1) The average or normal rainfall of the District is about 704.1 mm., and about 41% of annual
rainfall is being received from the South-West monsoon alone during June to September, every
year
2) During the period from 2011-12 to 2020-21, the annual actual rainfall received was lowest in
2011-12 with 404.6mm., whereas it was the highest in 2013-14 with 1077.8 mm.
3) During the Hot whether month May, the Maximum Temperature recorded in district as 38.3 c and
minimum temperature recorded in the District as 30.4 c in 2021-22.
4) During the 2021-22 winter seasons, the Minimum Temperature recorded in district is 17.8 c and
Maximum temperature recorded is 26.0 c.

20

<!-- page 40 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

NO.OF RAIN GAUGE STATIONS IN NALGONDA DISTRICT:
AWS

58

IMD

07

MANUAL

26

TOTAL

91

Automatic Weather station

Table

Content

2.1

Weather Stations By Mandals, 2021-22

2.2

Season wise Rainfall from 2000-01 to 2021-22

2.3

Season wise Rainfall by Mandals, 2021-22

2.4

Season wise Deficiency of Rainfall from 2017-18 To 2021-22

2.5

Month wise Maximum and Minimum Temperatures, 2021 & 2022

2.6

Month wise Relative Humidity and Mean Wind Speed, 2021

2.7

Month wise Ground Water Levels, 2020-21 & 2021-22

2.8

Time series data on average Depth to Ground Water level

2.9

Mandal wise Average Depth to Ground Water Levels, 2021-22
Mandal wise villages Falls in Different Categories By Ground Water Assesment
during previous and latest Assesment year
Ground Water Quality Parameters by Mandals, 2021-22

2.10
2.11

21

<!-- page 41 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

TABLE 2.1
WEATHER STATIONS BY MANDALS, 2021-22
(in No.s)
Sl.No.

Name of the Mandal

AWS (IMD)

AWS (TSDPS)

2

3

4

1

Manual
ARG (IMD) Raingauges
(DES)
5
6

Manual
Raingauges
(IMD)
7

Total
8

1

Chityala

-

1

-

1

-

2

2

Narketpally

-

3

-

1

-

4

3

Kattangoor

-

3

-

1

-

4

4

Sali Gouraram

-

1

-

1

-

2

5

Nakrekal

-

1

-

1

-

2

6

Kethepally

-

1

-

1

-

2

7

Thipparthi

-

2

-

1

-

3

8

Nalgonda

-

4

1

1

1

7

9

Kangal

-

1

-

1

-

2

10

Munugode

-

1

-

1

-

2

11

Chandur

-

2

1

1

-

4

Nalgonda Division

-

20

2

11

1

34

12

Anumula

-

3

-

1

-

4

13

Nidamanur

-

2

-

1

1

4

14

Thripuraram

-

2

-

1

-

3

15

Madugulapally

-

1

-

1

-

2

16

Vemulapally

-

1

-

1

-

2

17

Miryalaguda

-

2

-

1

1

4

18

Dameracherla

-

2

-

1

-

3

19

Adavi Devula Pally

-

1

-

1

-

2

20

Tirumalagiri Sagar

-

1

-

1

-

2

21

Peddavoora

-

2

1

1

1

5

Miryalaguda Division

-

17

1

10

3

31

22

Marriguda

-

2

-

1

1

4

23

Chinthapally

-

2

-

1

-

3

24

Nampalle

-

2

-

1

-

3

25

Gurrampode

-

2

-

1

-

3

26

Pedda Adiserla Pally

-

3

1

1

-

5

27

Neradugommu

-

1

-

-

1

28

Kondamallepally

-

1

-

1

-

2

29

Devarakonda

-

2

1

1

1

5

30

Gundlapally

-

3

-

1

-

4

31

Chandampet

-

3

-

1

-

4

Devarakonda Division

-

21

2

9

2

34

-

58

5

30

6

99

Total

-

Source: IMD: India Meteorological Dept., TSDPS: Telangana State Development Planning Society, DES:
Directorate of Economics & Statistics, AWS: Automatic Weather Stations, and ARG: Automatic Rain
Guage.
22

<!-- page 42 -->

Year

2

2004-05

2005-06

2006-07

2007-08

2008-09

2009-10

2010-11

2011-12

2012-13

2013-14

2014-15

2015-16

2016-17

2017-18

2018-19

2019-20

2020-21

2021-22

Sl.
No.

1

1

2

3

4

5

6

7

8

9

23

10

11

12

13

14

15

16

17

18

726.1

636.0

473.4

364.2

534.6

553.3

535.0

329.9

624.5

398.5

360.3

548.7

381.4

503.6

597.5

377.8

570.0

327.3

3

Actual

513.4

513.4

513.4

513.4

513.4

513.4

518.2

518.2

518.2

518.2

518.2

518.2

518.6

518.6

518.6

518.6

518.6

518.6

4

Normal

41

24

-8

-29

4

8

3

-36

21

-23

-30

6

-26

-3

15

-27

10

-37

5

126.4

226.8

122.0

12.0

113.5

39.9

45.7

82.7

482.2

136.7

14.2

185.4

124.9

60.1

89.9

79.2

342.6

168.9

6

Actual

141.3

141.3

141.3

141.3

141.3

141.3

141.9

141.9

141.9

141.9

141.9

141.9

142.0

142.0

142.0

142.0

142.0

142.0

7

Normal

-10

61

-14

-92

-20

-72

-68

-42

240

-4

-90

31

-12

-58

-37

-44

141

19

8

% Deviation

(October to December)

(June to September)
%
Deviation

North-East Monsoon

South-West Monsoon

49.2

0.9

18.4

36.4

0.0

0.0

1.2

0.1

0.0

72.4

7.4

11.8

23.4

0.0

11.8

5.0

0.0

7.7

9

Winter Period

(in mms.)

7.4

7.4

7.4

7.4

7.4

7.4

7.7

7.7

7.7

7.7

7.7

7.7

7.9

7.9

7.9

7.9

7.9

7.9

10

Normal

567

-88

149

393

-100

-100

-85

-99

-100

841

-4

53

197

-100

50

-37

-100

-3

11

% Deviation

(January and February)
Actual

TABLE - 2.2
SEASON WISE RAINFALL FROM 2004-05 TO 2021-22

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 43 -->

24

2004-05

2005-06

2006-07

2007-08

2008-09

2009-10

2010-11

2011-12

2012-13

2013-14

2014-15

2015-16

2016-17

2017-18

2018-19

2019-20

2020-21

2021-22

1

2

3

4

5

6

7

8

9

10

11

12

13

14

15

16

17

18

Source: ecostat, NIC

12

2

1

39.2

51.8

48.0

25.2

67.3

23.9

62.5

62.5

71.0

28.9

22.7

48.2

56.2

16.2

90.4

51.8

139.1

39.6

Actual

Year

Sl.
No.

42.0

42.0

42.0

42.0

42.0

42.0

42.3

42.3

42.3

42.3

42.3

42.3

42.4

42.4

42.4

42.4

42.4

42.4

13

Normal

-7

23

14

-40

60

-43

48

48

68

-32

-46

14

33

-62

113

22

228

-7

14

%
Deviation

Hot Weather Period
(March to May)
Normal
16

710.9
710.9
710.9
710.9
710.9
710.9
710.1
710.1
710.1

710.1
710.1
710.1
704.1
704.1
704.1
704.1
704.1
704.1

Actual
15

543.5
1051.7
513.8
789.6
579.9
585.9
794.1
404.6
636.5

1177.7
475.2
644.4
617.1
715.4
437.8
661.8
915.5
940.9

Annual Rainfall
(June to May)

TABLE - 2.2(concld.)
SEASON WISE RAINFALL FROM 2000-01 TO 2021-22

34

30

-6

-38

2

-12

-9

-33

66

-10

-43

12

-18

-18

11

-28

48

-24

17

% Deviation

(in mms.)

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 44 -->

25

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

1
2
3
4
5
6
7
8
9
10
11

1

Sl.
No.

District Average
133.7

85.2

2640.8

4143.9

District Total

5

4

219.1

6791.7

337.7
376.7
287.4
212.4
262.9
237.0
278.1
279.3
204.7
277.5
326.1
3079.8
126.6
231.3
230.6
305.2
300.0
262.5
246.9
156.5
160.5
99.6
2119.7
274.9
246.1
173.6
150.1
111.9
129.4
122.1
163.3
116.2
104.6
1592.2

Actual

145.2

4502.2

148.7
151.5
171.4
191.2
202.2
198.1
146.8
168.9
143.2
155.5
160.9
1838.4
143.8
139.9
167.7
152.7
154.7
173.1
162.3
162.3
138.2
131.2
1525.9
108.2
124.5
116.0
109.5
93.9
101.7
111.0
111.0
154.6
107.5
1137.9

6

Normal

July, 2021

Normal

101.4
78.8
94.2
103.6
105.0
94.3
76.9
80.6
88.9
102.6
105.1
1031.4
88.8
93.9
69.6
78.2
70.8
73.5
67.3
67.3
84.0
69.6
763.0
87.7
86.8
82.3
66.0
66.5
78.6
100.8
100.8
87.7
89.2
846.4

3

Actual

152.0
Chityala
141.2
Narketpally
90.1
Kattangoor
94.3
Sali Gouraram
70.6
Nakrekal
118.0
Kethepally
75.1
Thipparthi
197.7
Nalgonda
280.3
Kangal
212.4
Munugode
248.1
Chandur
Nalgonda Division Total
1679.8
150.0
Anumula
133.3
Nidamanur
96.2
Thripuraram
151.2
Madugulapally
124.1
Vemulapally
102.0
Miryalaguda
151.3
Dameracherla
91.4
Adavi Devula Pally
72.7
Tirumalagiri Sagar
72.4
Peddavoora
Miryalaguda Division Total 1144.6
122.6
Marriguda
110.5
Chinthapally
192.9
Nampalle
186.1
Gurrampode
92.9
Pedda Adiserla Pally
65.6
Neradugommu
162.0
Kondamallepally
157.3
Devarakonda
120.0
Gundlapally
109.6
Chandampet
Devarakonda Division Total 1319.5

2

Name of the Mandal

June, 2021

196.4

6088.9

268.9
225.5
233.8
245.5
281.6
328.4
130.3
228.5
291.3
234.1
288.3
2756.2
263.3
245.3
230.7
186.5
135.0
230.3
199.7
148.6
110.7
149.4
1899.5
159.5
176.3
143.1
178.1
126.8
96.4
159.1
144.1
128.8
121.0
1433.2

7

Actual

137.3

4257.5

127.2
142.1
150.8
153.0
184.1
191.7
165.8
164.0
128.7
150.9
132.2
1690.5
111.9
131.7
136.8
150.4
165.5
154.2
159.4
159.4
128.4
141.9
1439.6
112.9
100.7
123.7
103.0
102.6
104.1
109.2
109.2
157.7
104.3
1127.4

8

Normal

176.9

5483.0

170.8
185.5
183.7
139.2
163.5
210.5
203.4
232.2
236.9
238.1
325.8
2289.6
168.2
158.8
124.9
218.1
114.8
195.6
187.2
107.1
149.0
125.1
1548.8
251.2
155.4
179.9
231.1
108.2
159.4
101.4
129.0
191.4
137.6
1644.6

9

Actual

145.7

4516.1

126.0
124.2
161.5
168.2
194.9
165.3
143.2
169.7
174.0
139.8
161.0
1727.8
141.8
169.2
149.1
147.7
127.7
136.7
145.2
145.2
155.8
156.2
1474.6
126.0
108.9
144.2
131.7
122.5
123.8
144.1
144.1
144.8
123.6
1313.7

10

Normal

SOUTH - WEST MONSOON (in mms.)
August, 2021
September, 2021

TABLE - 2.3
SEASON WISE RAINFALL BY MANDALS, 2021-22

726.0

22507.5

929.4
928.9
795.0
691.4
778.6
893.9
686.9
937.7
1013.2
962.1
1188.3
9805.4
708.1
768.7
682.4
861.0
673.9
790.4
785.1
503.6
492.9
446.5
6712.6
808.2
688.3
689.5
745.4
439.8
450.8
544.6
593.7
556.4
472.8
5989.5

11

Actual

513.4

15916.6

503.3
496.6
577.9
616.0
686.2
649.4
532.7
583.2
534.8
548.8
559.2
6288.1
486.3
534.7
523.2
529.0
518.7
537.5
534.2
534.2
506.4
498.9
5203.1
434.8
420.9
466.2
410.2
385.5
408.2
465.1
465.1
544.8
424.6
4425.4

12

Normal

41

41

85
87
38
12
13
38
29
61
89
75
113
56
46
44
30
63
30
47
47
-6
-3
-11
29
86
64
48
82
14
10
17
28
2
11
35

13

Deviation
(%)

South-West Monsoon Total

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 45 -->

2

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
District Total
District Average

1

1
2
3
4
5
6
7
8
9
10
11

26

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Name of the Mandal

Sl.
No.

79.9
70.1
56.4
57.8
84.5
28.9
47.1
42.4
26.4
80.9
56.3
630.7
20.0
17.0
26.7
12.8
2.4
25.5
54.7
39.7
90.2
27.8
316.8
70.7
54.0
31.9
47.5
76.7
84.2
98.7
66.6
60.4
130.4
721.1
1668.6
53.8

14

Actual

119.5
101.9
97.4
124.9
105.1
106.1
98.5
106.9
86.9
98.8
104.8
1150.8
94.1
97.8
87.4
96.9
103.2
128.0
111.8
111.8
94.1
90.0
1015.1
89.9
90.5
86.8
80.4
62.9
76.0
84.1
84.1
91.1
87.9
833.7
2999.6
96.8

15

Normal

October, 2021

57.6
77.0
57.8
11.3
51.1
54.9
41.2
40.8
74.4
42.8
57.5
566.4
74.2
107.3
66.6
57.9
78.4
135.6
67.2
55.3
47.0
87.9
777.4
91.2
67.5
146.4
112.1
76.6
82.3
51.8
51.9
31.4
66.5
777.7
2121.5
68.4

41.6
43.8
37.5
37.4
34.7
34.4
42.0
38.5
44.1
42.3
39.0
435.3
43.2
42.1
39.8
39.7
33.6
32.3
37.8
37.8
45.4
50.3
402.0
40.9
39.2
40.8
37.4
43.0
41.7
39.6
39.6
52.0
39.6
413.8
1251.1
40.4

1.6
21.9
7.1
5.0
27.8
0.5
3.0
3.4
7.4
7.5
1.6
86.8
1.3
0.2
1.1
3.5
0.0
0.2
0.0
0.0
0.0
0.2
6.5
4.1
3.7
5.7
6.1
0.0
0.8
0.5
8.2
7.2
1.1
37.4
130.7
4.2

4.6
2.7
2.7
3.1
3.3
3.3
2.0
3.6
2.6
4.8
3.7
36.4
4.6
2.8
7.1
3.6
1.3
3.1
3.6
3.6
3.9
4.4
38.0
2.9
3.6
2.3
3.3
5.9
6.6
7.1
7.1
9.0
7.1
54.9
129.3
4.2

139.1
169.0
121.3
74.1
163.4
84.3
91.3
86.6
108.2
131.2
115.4
1283.9
95.5
124.5
94.4
74.2
80.8
161.3
121.9
95.0
137.2
115.9
1100.7
166.0
125.2
184.0
165.7
153.3
167.3
151.0
126.7
99.0
198.0
1536.2
3920.8
126.5

165.7
148.4
137.6
165.4
143.1
143.8
142.5
149.0
133.6
145.9
147.5
1622.5
141.9
142.7
134.3
140.2
138.1
163.4
153.2
153.2
143.4
144.7
1455.1
133.7
133.3
129.9
121.1
111.8
124.3
130.8
130.8
152.1
134.6
1302.4
4380.0
141.3

-16
14
-12
-55
14
-41
-36
-42
-19
-10
-22
-21
-33
-13
-30
-47
-41
-1
-20
-38
-4
-20
-24
24
-6
42
37
37
35
15
-3
-35
47
18
-10
-10

NORTH- EAST MONSOON (in mms.)
November, 2021
December, 2021
North-East Monsoon Total
Deviation
Actual
Normal
Actual
Normal
Actual
Normal
(%)
16
17
18
19
20
21
22

TABLE - 2.3(contd..)
SEASON WISE RAINFALL BY MANDALS, 2021-22

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 46 -->

2

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
District Total
District Average

1

1
2
3
4
5
6
7
8
9
10
11

27

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Name of the Mandal

Sl.
No.

48.0
59.0
140.0
109.0
168.3
113.4
37.3
91.5
113.3
112.5
78.1
1070.4
37.1
47.9
57.9
55.8
31.9
48.8
41.2
15.3
6.8
1.2
343.9
7.1
0.8
36.2
9.4
11.0
12.4
3.0
7.3
3.0
20.3
110.5
1524.8
49.2

11.7
13.1
11.9
13.5
16.0
11.4
4.0
5.6
3.4
3.3
6.0
99.9
3.8
3.3
7.0
5.2
5.7
6.5
2.9
2.9
4.3
5.8
47.4
0.3
2.2
1.1
0.5
4.8
3.4
1.7
1.7
1.7
1.7
19.1
166.4
5.4

January, 2022
Normal
Actual
24
23

0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0

0.9
0.5
1.6
1.6
2.0
1.3
2.3
1.5
0.9
2.2
3.6
18.4
3.1
2.4
1.5
2.4
3.1
1.2
0.7
0.7
3.0
3.5
21.6
1.3
0.7
5.5
0.7
1.7
1.8
3.4
3.4
1.9
1.9
22.3
62.3
2.0
48.0
59.0
140.0
109.0
168.3
113.4
37.3
91.5
113.3
112.5
78.1
1070.4
37.1
47.9
57.9
55.8
31.9
48.8
41.2
15.3
6.8
1.2
343.9
7.1
0.8
36.2
9.4
11.0
12.4
3.0
7.3
3.0
20.3
110.5
1524.8
49.2

WINTER PERIOD (in mms.)
February, 2022
Normal
Actual
Actual
26
25
27

TABLE - 2.3(contd..)
SEASON WISE RAINFALL BY MANDALS, 2021-22

12.6
13.6
13.5
15.1
18.0
12.7
6.3
7.1
4.3
5.5
9.6
118.3
6.9
5.7
8.5
7.6
8.8
7.7
3.6
3.6
7.3
9.3
69.0
1.6
2.9
6.6
1.2
6.5
5.2
5.1
5.1
3.6
3.6
41.4
228.7
7.4

281
334
937
622
835
793
492
1189
2535
1945
714
805
438
740
581
634
263
534
1044
325
-7
-87
398
344
-72
448
683
69
138
-41
43
-17
464
167
567
567

Winter Period Total
Normal
Deviation (%)
28
29

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 47 -->

2

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Ditrict Total
District Average

1

1
2
3
4
5
6
7
8
9
10
11

28

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Name of the Mandal

Sl.
No.

0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.3
7.3
0.0
0.0
0.0
0.0
0.0
3.3
0.5
1.6
13.0
13.0
0.4

2.7
5.9
8.1
1.5
3.6
3.5
4.4
8.4
9.0
3.6
9.4
60.1
12.9
8.3
4.0
5.2
4.1
3.5
7.0
7.0
10.1
9.3
71.4
4.2
3.5
2.8
2.5
6.3
7.1
7.6
7.6
7.6
7.6
56.8
188.3
6.1

March, 2022
Actual
Normal
30
31

0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.0
0.5
1.0
0.0
0.0
0.2
0.0
1.0
0.2
0.0
0.5
3.4
3.4
0.1

69.9
96.3
70.6
35.8
18.8
21.9
114.2
55.8
24.6
36.5
37.1
581.5
22.9
24.8
74.2
61.0
23.0
25.4
79.6
42.8
46.9
4.2
404.8
10.9
28.0
17.0
29.7
14.0
4.0
18.3
22.5
33.5
33.6
211.5
1197.8
38.6

23.4
27.0
50.0
34.0
54.5
53.3
28.2
33.0
29.5
25.4
32.1
390.4
35.3
29.5
22.0
30.6
42.4
46.2
35.6
35.6
26.1
13.6
316.9
23.1
6.4
10.2
10.6
19.1
21.4
25.3
25.3
23.2
23.2
187.8
895.1
28.9

69.9
96.3
70.6
35.8
18.8
21.9
114.2
55.8
24.6
36.5
37.1
581.5
22.9
24.8
74.2
61.0
23.0
25.4
79.6
42.8
46.9
4.2
404.8
11.7
36.3
17.0
29.7
14.2
4.0
19.3
26.0
34.0
35.7
227.9
1214.2
39.2

HOT WEATHER PERIOD (in mms.)
May, 2022
Actual
Normal
Actual
34
35
36

10.0
8.1
5.4
6.0
9.2
11.0
7.5
8.7
6.2
15.2
19.8
107.1
9.5
5.2
3.2
5.9
6.5
4.4
3.3
3.3
7.0
6.0
54.3
7.9
3.6
6.1
5.8
9.2
7.2
4.7
4.7
4.7
4.7
58.6
220.0
7.1

April, 2022
Actual
Normal
32
33

TABLE - 2.3(contd..)
SEASON WISE RAINFALL BY MANDALS, 2021-22

36.1
41.0
63.5
41.5
67.3
67.8
40.1
50.1
44.7
44.2
61.3
557.6
57.7
43.0
29.2
41.7
53.0
54.1
45.9
45.9
43.2
28.9
442.6
35.2
13.5
19.1
18.9
34.6
35.7
37.6
37.6
35.5
35.5
303.2
1303.4
42.0

94
135
11
-14
-72
-68
185
11
-45
-17
-39
4
-60
-42
154
46
-57
-53
73
-7
9
-85
-9
-67
169
-11
57
-59
-89
-49
-31
-4
1
-25
-7
-7

Hot Weather Period Total
Normal
Deviation (%)
37
38

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 48 -->

Sl.
Name of the Mandal
No.
1
2
1 Chityala
2 Narketpally
3 Kattangoor
4 Sali Gouraram
5 Nakrekal
6 Kethepally
7 Thipparthi
8 Nalgonda
9 Kangal
10 Munugode
11 Chandur
Nalgonda Division Total
12 Anumula
13 Nidamanur
14 Thripuraram
15 Madugulapally
16 Vemulapally
17 Miryalaguda
18 Dameracherla
19 Adavi Devula Pally
20 Tirumalagiri Sagar
21 Peddavoora
Miryalaguda Division Total
22 Marriguda
23 Chinthapally
24 Nampalle
25 Gurrampode
26 Pedda Adiserla Pally
27 Neradugommu
28 Kondamallepally
29 Devarakonda
30 Gundlapally
31 Chandampet
Devarakonda Division Total
District Total
District Average
Source: Chief Planning Officer

TABLE - 2.3(contd.)
SEASON WISE RAINFALL BY MANDALS, 2021-22
ANNUAL RAINFALL (in mms)
Normal
Actual
39
40
717.7
1186.4
699.6
1253.2
792.5
1126.9
838.0
910.3
914.6
1129.1
873.7
1113.5
721.6
929.7
789.4
1171.6
717.4
1259.3
744.4
1242.3
777.6
1418.9
8586.5
12741.2
692.8
863.6
726.1
965.9
695.2
908.9
718.5
1052.0
718.6
809.6
762.7
1025.9
736.9
1027.8
736.9
656.7
700.3
683.8
681.8
567.8
7169.8
8562.0
605.3
993.0
570.6
850.6
621.8
926.7
551.4
950.2
538.4
618.3
573.4
634.5
638.6
717.9
638.6
753.7
736.0
692.4
598.3
726.8
6072.4
7864.1
21828.7
29167.3
704.2
940.9
Deviation (%)
41
65
79
42
9
23
27
29
48
76
67
82
48
25
33
31
46
13
35
39
-11
-2
-17
19
64
49
49
72
15
11
12
18
-6
21
30
34
34

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

29

<!-- page 49 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

TABLE - 2.4
SEASON WISE DEFICIENCY OF RAINFALL FROM 2017-18 TO 2021-22
SOUTH - WEST MONSOON RAINFALL
No. of Mandals falls in

Sl No.

Year

Total
Mandals
(No.)

Scanty

Deficient

Normal

Excess

No Rain

1

2

3

4

5

6

7

8

1

2017-18

31

1

2

8

20

0

2

2018-19

31

3

17

10

1

0

3

2019-20

31

0

11

18

2

0

4

2020-21

31

0

0

13

18

0

5

2021-22

31

0

0

10

21

0

Sl No.

Year

NORTH- EAST MONSOON RAINFALL

Total
Mandals
(No.)

Scanty

Deficient

Normal

Excess

No Rain

3

9

10

11

12

13

No. of Mandals falls in

1

2

1

2017-18

31

3

10

15

3

0

2

2018-19

31

28

0

0

0

3

3

2019-20

31

4

11

12

4

0

4

2020-21

31

0

1

3

27

0

5

2021-22

31

0

14

11

6

0

TABLE - 2.4 (Concld.)
SEASON WISE DEFICIENCY OF RAINFALL FROM 2017-18 TO 2021-22
Sl No.

Year

WINTER PERIOD RAINFALL
No. of Mandals falls in

Total
Mandals
(No.)

Scanty

Deficient

Normal

Excess

No Rain

3

14

15

16

17

18

1

2

1

2017-18

31

0

0

0

31

0

2

2018-19

31

0

0

0

31

0

3

2019-20

31

4

4

4

16

3

4

2020-21

31

8

5

0

1

17

5

2021-22

31

2

1

2

26

0

Sl No.

Year

Total
Mandals
(No.)

1

2

3

1

2017-18

31

1

2

7

21

0

2

2018-19

31

9

13

4

5

0

3

2019-20

31

1

11

7

12

0

4

2020-21

31

2

5

11

13

0

5

2021-22

31

6

8

9

8

0

HOT WEATHER PERIOD RAINFALL
No. of Mandals falls in
Scanty
19

Deficient
20

Source: Chief Planning Officer

30

Normal
21

Excess
22

No Rain
23

<!-- page 50 -->

31.2
34.9

March

April

May

June

July

August

September

October

November

December

Annual Average

3

4

5

6

7

8

31

9

10

11

12

4

2021

33.8

31

30.7

33.6

32.2

33.1

32.9

35.1

38.6

38.4

35.6

32.6

31.4

Source: CEO., Telangana State Development and Planning Society

32.5

33.9

33.7

33.4

34.3

37.2

41

39.8

36.6

33.6

February

31.4

2

3

Normal

January

2

1

5

33.4

30.60

30.34

33.29

31.91

32.80

32.58

34.77

38.29

38.04

35.28

32.08

30.96

2022

Mean Maximum Temperature
(in Centigrade)

1

Month

Sl.
No.
6

22.5

17.2

19.6

22.7

24.3

24.9

25.7

26.7

27.3

24.5

21.4

18.4

17.2

Normal
7

2021

22.5

17.8

22.1

23.2

24.3

25

24.9

25.8

26.8

24.1

19.9

17.4

18.4

8

22.7

18.05

22.27

23.36

24.47

25.15

25.10

26.05

27.05

24.38

20.29

17.88

18.85

2022

Mean Minimum Temperature
(in Centigrade)

MONTH WISE MAXIMUM AND MINIMUM TEMPERATURES, 2021 & 2022

TABLE - 2.5

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 51 -->

51
52

March
April
May
June
July
August
September
October
November
December

Annual Average

3

4

5

6

7

32

8

9

10

11

12

91

95

95

94

95

92

92

84

81

85

86

92

96

at 17:30 Hrs.
4

Source: CEO., Telangana State Development and Planning Society

68

58

71

65

66

51

38

34

32

40

February

2

52

January

2

1

at 08:30 Hrs.
3

% of Relative Humidity

1

Month

Sl No.

4.1

2.6

2.7

2.8

4.3

4.9

5.7

6.0

5.5

4.1

3.6

3.7

3.2

5

Mean Wind Speed

(MWS/Kmph)

MONTH WISE RELATIVE HUMIDITY AND MEAN WIND SPEED, 2021

TABLE - 2.6

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 52 -->

July

August

September

2

3

4

3

2

33

February

9

7.3

Average

Source: District Ground Water Officer & Chief Planning Officer

87.1

7.7

Total

May

12

7.9

23.1

April

11

7.4

12.5

6.6

5.9

Hot Weather Period

March

10

Winter Period

January

14.5

North - East Monsoon

8

5.0

December

7

4.7

November

6

4.9

October

5

37.0

6.9

8.2

10.7

11.2

Ground Water Level (in
Mts.)

2020-21
Month

South-West Monsoon

June

1

1

Sl.
No.

66.6

798.6

13.9

0.7

7.1

6.1

7.4

2.0

5.4

141.4

4.2

40.4

96.8

635.9

199.3

173.2

157.1

106.3

4

Rainfall
(in mms.)

2021-22

5.7

68.1

19.9

6.7

6.7

6.4

10.2

5.5

4.7

12.8

4.6

4.1

4.1

25.3

4.9

6.3

6.4

7.7

5

Ground Water Level (in
Mts.)

MONTH WISE GROUND WATER LEVELS, 2020-21 & 2021-22

TABLE - 2.7

78.4

940.8

39.1

38.6

0.1

0.4

49.2

0.0

49.2

126.4

4.2

68.4

53.8

726.1

176.9

196.4

219.1

133.7

6

Rainfall
(in mms.)

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 53 -->

2

1

Pre Monsoon
3

4

Post Monsoon

27.40 20.83
1 CHITYAL
11.93
7.60
2 NARKETPALLY
20.16
6.08
3 KATTANGUR
17.78
7.01
4 SHALIGOWRARAM
14.00
6.73
5 NAKREKAL
13.99
4.36
6 KETHEPALLY
17.91
5.97
7 THIPPARTHY
13.37
4.89
8 NALGONDA
7.57
3.83
9 KANAGAL
11.84
7.07
10 MUNUGODE
18.69 17.95
11 CHANDUR
12.52
4.53
16 ANUMULA
13.02
4.67
17 NIDMANOOR
11.50
3.15
18 TRIPURARAM
12.76
4.13
19 MADUGULAPALY
8.65
4.38
20 VEMULAPALLY
7.31
2.19
21 MIRYALGUDA
6.77
0.64
22 DAMERACHERLA
21.63
8.13
23 ADAVIDEVULAPALLI
20.20 10.99
24 TIRMALGIRI (SAGAR)
10.87
6.23
25 PEDDAVOORA
21.80 16.34
12 MARRIGUDA
12.60
5.48
13 CHINTHAPALLY
17.07
7.37
14 NAMPALLY
11.10
3.41
15 GURRAMPODE
10.68
5.63
26 P.A.PALLY
16.45
8.57
27 NEREDUGOMMU
14.83
5.77
28 KONDA MALLEPALLY
11.94
8.05
29 DEVERAKONDA
9.96
8.26
30 GUNDLAPALLY
24.24 11.36
31 CHANDAMPET
Source: District Ground Water Officer

Name of the Mandal

Sl.No

2016

6

Pre Monsoon
7

2018
Post Monsoon
8

Pre Monsoon
9

2019
Post Monsoon
10

11

Pre Monsoon

2020

17.86 23.64 24.22 21.04 13.71 14.19
9.35 12.32 14.87 15.25
4.07 12.98
10.02 19.74 24.28 19.72 15.12 18.16
7.46 12.19 13.41 17.81
7.62 12.40
6.64
6.11
6.92
7.53
2.85
4.48
4.31 16.09 18.80 13.26 12.68 11.50
6.41
9.77 10.11 14.92
4.51
6.51
3.86
7.48
8.14 13.14
3.25
7.33
4.94
6.23
6.38
8.19
1.55
5.11
5.80
8.49 11.42 12.91
4.02
8.86
13.97 18.18 22.99 24.66
1.86 21.45
7.68
9.46
9.08 10.52
4.18
7.30
6.24
7.97
7.45
9.89
1.91
6.77
4.31
6.08
4.92
7.30
1.01
4.50
5.37
7.86
7.98 10.74
2.95
5.65
4.32
5.46
5.18
6.60
0.34
4.88
3.22
3.25
2.37
3.97
0.23
2.33
2.90
2.90
0.64
2.84 -0.13
1.58
8.57 15.40 13.30 12.95
8.29 11.72
8.63 12.52 11.67 13.59
4.47 10.05
10.30 11.64
8.92 12.00
4.88
5.13
11.79 17.51 20.33 27.30 -3.23 26.90
2.92 7.61 16.64 18.96 21.88
0.24 19.37
6.93 11.99
8.42 10.86
4.68
7.26
7.56
9.59
8.73 10.69
3.39
6.57
19.22 17.89 17.32 23.68
5.13 18.00
7.16 17.94 17.07 17.12 10.87 10.48
11.64 13.44 15.82 15.26
4.92 10.38
8.04
7.70
7.78
8.83 -0.42
7.88
15.48 23.84 18.35 19.25
7.53 16.80

Pre Monsoon

28.29
11.52
17.29
13.49
10.48
6.40
10.37
10.10
7.55
11.06
17.57
9.06
7.91
8.94
6.58
6.19
3.63
3.99
14.85
18.30
9.26
19.22
3.82
10.12
9.24
14.62
18.98
10.43
11.50
9.54
16.49

Post Monsoon

5

2017

12

Post Monsoon

7.13
5.81
7.27
3.11
1.55
5.27
3.21
3.75
3.03
3.72
9.54
2.19
3.50
2.42
2.57
3.57
1.92
0.67
2.94
3.08
2.16
8.31
4.05
7.31
1.69
2.72
6.23
2.39
7.88
4.54
5.84

13

Pre Monsoon

11.63
8.69
11.46
10.15
4.88
8.08
6.17
4.46
5.04
6.10
10.28
5.59
5.95
4.30
4.89
5.23
3.66
2.27
11.28
7.07
5.32
10.40
7.41
9.35
4.34
5.31
13.45
5.95
8.74
4.85
11.91

2021

14

Post Monsoon

5.49
4.76
5.47
4.14
2.20
4.86
3.64
3.49
3.42
2.29
4.65
3.54
3.91
2.73
2.85
4.06
2.35
0.89
3.86
3.08
3.14
3.62
4.12
4.00
2.42
3.48
5.52
2.67
7.22
3.53
9.48

Pre Monsoon

9.20
7.12
7.38
9.31
4.24
6.19
5.90
4.65
4.29
4.60
6.85
6.45
5.91
4.30
4.66
5.00
3.74
2.74
11.36
7.60
4.79
6.01
6.80
6.17
4.22
5.78
10.65
6.16
8.76
6.52
13.24

15

in (mbgl)
2022

6.43
4.80
5.10
2.75
2.42
5.63
3.27
2.84
4.00
3.33
5.51
3.91
4.34
2.58
3.06
4.11
1.92
0.66
5.19
3.04
2.67
4.83
3.98
5.22
2.33
3.11
6.59
2.51
4.08
2.14
8.03

16

Post Monsoon

TABLE-2.8
TIME SERIES DATA ON AVERAGE DEPTH TO GROUND WATER LEVEL

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

34

<!-- page 54 -->

2

1

May-21
3

Pre Monsoon

CHITYAL
11.63
NARKETPALLY
8.69
KATTANGUR
11.46
SHALIGOWRARAM
10.15
NAKREKAL
4.88
KETHEPALLY
8.08
THIPPARTHY
6.17
NALGONDA
4.46
KANAGAL
5.04
MUNUGODE
6.10
CHANDUR
10.28
MARRIGUDA
10.40
CHINTHAPALLY
7.41
NAMPALLY
9.35
GURRAMPODE
4.34
ANUMULA
5.59
NIDMANOOR
5.95
TRIPURARAM
4.30
MADUGULAPALY
4.89
VEMULAPALLY
5.23
MIRYALGUDA
3.66
DAMERACHERLA
2.27
ADAVIDEVULAPALLI
11.28
TIRMALGIRI (SAGAR)
7.07
PEDDAVOORA
5.32
P.A.PALLY
5.31
NEREDUGOMMU
13.45
KONDA MALLEPALLY
5.95
DEVERAKONDA
8.74
GUNDLAPALLY
4.85
CHANDAMPET
11.91
Dist.Average
Source: District Ground Water Officer

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31

Name of the Mandal

Sl.
No.

5.49
4.76
5.47
4.14
2.20
4.86
3.64
3.49
3.42
2.29
4.65
3.62
4.12
4.00
2.42
3.54
3.91
2.73
2.85
4.06
2.35
0.89
3.86
3.08
3.14
3.48
5.52
2.67
7.22
3.53
9.48
4.13

8.02
6.68
8.16
7.60
4.15
6.19
3.90
4.44
3.24
3.68
9.20
8.52
6.05
7.95
3.49
4.53
5.77
4.62
3.35
3.79
3.14
2.94
9.82
4.75
6.60
4.62
7.21
3.98
7.16
5.38
12.43
7.68

Average Depth to Water Level
(in m bgl)
Starting of
Post Monsoon
Water Year
Nov-21
Jun-21
4
5

9.20
7.12
7.38
9.31
4.24
6.19
5.90
4.65
4.29
4.60
6.85
6.01
6.80
6.17
4.22
6.45
5.91
4.30
4.66
5.00
3.74
2.74
11.36
7.60
4.79
5.78
10.65
6.16
8.76
6.52
13.24
6.73

Ending of Water
Year
May-22
6

-2.43
-1.57
-4.08
-0.84
-0.64
-1.89
-0.28
0.19
-0.75
-1.50
-3.43
-4.40
-0.61
-3.19
-0.12
0.86
-0.04
0.00
-0.23
-0.23
0.08
0.47
0.07
0.54
-0.52
0.47
-2.80
0.21
0.02
1.67
1.32
6.73

May-21
7

3.71
2.36
1.91
5.17
2.04
1.33
2.26
1.15
0.88
2.31
2.21
2.39
2.68
2.17
1.81
2.91
2.00
1.57
1.81
0.94
1.39
1.85
7.49
4.52
1.65
2.30
5.13
3.49
1.54
2.99
3.76
2.60

Nov-21
8

1.18
0.44
-0.78
1.71
0.08
-0.01
2.00
0.21
1.05
0.92
-2.35
-2.51
0.74
-1.79
0.73
1.92
0.14
-0.32
1.31
1.21
0.60
-0.20
1.53
2.85
-1.81
1.16
3.44
2.17
1.60
1.15
0.81
-0.95

Jun-21
9

Ground Water Level Variations with reference
to May 2022 m.bgl (+/-)

TABLE - 2.9
MANDAL WISE AVERAGE DEPTH TO GROUND WATER LEVELS , 2021-22

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

35

<!-- page 55 -->

3

Name of the Mandal

2

4

Safe

36

6

1

1

1

1

1
1

5

Semi-critical
6

Critical
7

Over-Exploited

Category wise no. of villages falls in previous
assessment year (2019-20)

Adavi devula palli
6
1
Anumula_Haliya
19
1
Chandampet
15
1
Chandur
18
1
Chinthapalle
22
Chityala
16
Damaracherla
12
1
Devarakonda
15
Gundlapalle
22
1
Gurrampode
27
1
Kangal
24
1
Kattangoor
18
1
Kethepalle
13
1
Kondamallapally
14
1
Madugulapally
21
1
Marriguda
17
Miryalaguda
24
1
Munugode
22
Nakrekal
16
1
Nalgonda
35
Nampalle
28
1
Narketpalle
19
1
Neredugommu
9
1
Nidamanur
15
1
Pedda_adiserlapalle
22
1
Peddavura
21
1
Saligouraram
20
1
Thipparthi
13
1
Thripuraram
16
1
Tirumalagiri_Sagar
14
1
Vemulapalle
13
1
Total
566
25
Source: District Ground Water Department

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31

1

Sl. No.

Total
No. of
Villages

1
1
1
1
1
1
1
1
1
1
1
25

1

1

1
1
1
1
1
1
1

1

1
1
1
1

6

1

1

1

1

1
1

Category wise no. of villages falls in latest
assessment year (2021-22)
OverSafe
Semi-critical
Critical
Exploited
8
9
10
11

TABLE - 2.10
MANDAL WISE VILLAGES FALLS IN DIFFERENT CATEGORIES BY GROUND WATER ASSESSMENT DURING PREVIOUS AND LATEST
ASSESSMENT YEAR

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 56 -->

2

1

Min
3

Min
9

0.57
0.33
0.32
0.52
0.45
0.51
0.63
0.27
0.58
0.55
0.48
1.25
2.68
0.61
1.92
1.03
0.55
0.37
0.68
0.4
0.59
0.58
0.33
0.76
0.5
0.3
0.5
0.48
0.27
0.63

260
640
940
1160
680
760
580
700
460
640
240
380
320
340
580
1180
580
540
480
620
800
600
380
280
440
440
380
520
320
360

37

1.11
2.26
2.9
2.06
0.95
0.89
0.6
2.13

0.57
2.61
2.21
3.51
3.16
1.82
2.15
2.8
2.41
2.55
0.48
1.38
2.79
1.55
1.92
4.78
2.19
3.07
2.81
2.84
2.89
2.94

Pre-Mansoon (May-2022)
TDS
Fluoride
PH
(mg/L)
(mg/L)
Max
Min
Max
Min
Max
10
11
12
13
14

1
7.33
7.33
791
791
1.13
1.13
8.07
8.07
260
Adavi devula palli
2
6.92
8.3
558
1542
0.23
1.17
7.46
8.29
200
Anumula_Haliya
3
7.19
8.29
245
1322
0.59
1.83
7.7
8.33
180
Chandampet
4
6.78
9.02
211
2445
0.23
5.96
7.38
8.78
60
Chandur
5
7.32
8.62
589
3366
0.62
5.05
7.65
8.27
60
Chinthapalle
6
7.09
8.09
204
1529
0.19
2.09
7.63
8.2
120
Chityala
7
7.4
8.21
573
1245
0.51
1.79
7.03
7.81
260
Damaracherla
8
6.32
7.81
328
1465
0.14
2.29
7.43
8.41
100
Devarakonda
9
7.63
8.2
291
1971
0.37
1.86
7.28
8.38
220
Gundlapalle
10
6.72
8.29
243
1196
0.24
1.16
7.64
8.32
100
Gurrampode
11
8.07
8.09
616
616
0.79
0.79
7.33
7.33
240
Kangal
12
7.57
7.98
936
2095
0.25
2.42
7.88
8.31
100
Kattangoor
13
7.79
8.54
1311
2358
0.49
0.49
7.89
8.36
100
Kethepalle
14
7.76
7.82
625
723
0.23
0.49
7.46
8.21
240
Kondamallapally
15
7.79
7.79
2170
2170
0.89
0.89
7.93
7.93
580
Madugulapally
16
7.21
8.69
333
2833
0.27
8.2
7.45
8.68
160
Marriguda
17
7.03
8.28
381
1973
0.32
1.9
7.33
8.77
220
Miryalaguda
18
6.94
8.73
317
2004
0.25
3.12
7.95
8.67
140
Munugode
19
7.09
7.9
697
1613
0.24
0.52
7.94
8.44
100
Nakrekal
20
6.93
8.27
315
1145
0.29
3.81
7.56
837
160
Nalgonda
21
6.49
8.65
316
2509
0.33
2.59
7.31
8.29
120
Nampalle
22
7.49
7.94
413
2177
0.79
2.62
7.37
8.35
240
Narketpalle
23
8.42
8.42
1151
1151
2.05
2.05
Neredugommu
24
7.35
8.47
416
1343
0.41
1.37
7.4
8.25
200
Nidamanur
25
6.89
7.75
557
1850
0.2
1.3
7.8
8.18
160
Pedda_adiserlapalle
26
7.59
8.01
318
1550
0.24
1.69
7.25
8.03
160
Peddavura
27
7.66
8.38
311
1301
0.09
1.13
7.61
8.11
180
Saligouraram
28
7.61
7.97
438
703
0.47
1.02
7.88
8.01
200
Thipparthi
29
7.95
8.82
628
1392
0.19
0.63
7.37
7.62
400
Thripuraram
30
8.02
230
719
0.43
0.72
7.12
7.92
240
Tirumalagiri_Sagar 7.82
31
7.7
8.02
1129
1339
0.39
1.58
7.29
7.95
60
Vemulapalle
Source: District Ground Water Department Note: pH: Potential of Hydrogene, TDS: Total Desolved Solids

Name of the Mandal

Sl. No.

Post-Mansoon (Nov-2021)
TDS
Fluoride
PH
(mg/L)
(mg/L)
Max
Min
Max
Min
Max
4
5
6
7
8

TABLE - 2.11
GROUND WATER QUALITY PARAMETERS BY MANDALS

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 57 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

Chapter - 3
INTRODUCTION
Agriculture is the backbone of the
Nalgonda district and plays a pivotal role
in the economy of the district and
boosting the performance of this sector
is vital for inclusive growth. Sustainable
growth in Agriculture continues to be the
core agenda of the Government and
occupies

centre

stage

in

district

economy embodying three thrust areas
viz., (i) to promote inclusive growth, (ii) to enhance rural incomes, and (iii) to sustain food
security.
The Government of Telangana has undertaken several initiatives to boost the sector’s
growth, increase farmers income and improve farmers welfare. To achieve these objectives, the
Government has implemented policy initiatives such as the flagship Mission Kakatiya to improve the
irrigation infrastructure, the supply of 24X7 free power to farmers, investment support to farmers
under the Rythu Bandhu scheme, access to inputs, markets & credit, and provisioning of life
insurance to make farmers under the Rythu Bhima scheme.

38

<!-- page 58 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

Rythu Vedikas:
Rythu Vedikas are the first of its kind in India
where a platform is being created for the farmers to
motivate and stabilize the farmers in attaining the
higher returns and making the farmers Rythe Raju.
There are 105 AEO clusters in Nalgonda accordingly,
140 Rythu Vedikas were constructed.
Rythu

Vedikas will

help in

mobilising

the

farmers to organise themselves into groups for attaining their ultimate objective of getting the
remunerative prices, better marketing facilities, higher productivity and ultimately making the
Agriculture profitable.
Table

Content

3.1

Season wise Area, Yield and Production of Principal Crops, 2021-22

3.2

Season Wise Cropped Area by Mandals, 2021-22

3.3

Factory wise Quantity of Sugarcane Crushed and Sugar Produced, 2020-21 and 2021-22

3.4

Season wise Paddy Procurement by Mandals, 2021-22

3.5

Consumption of Chemical Fertilizers & Licences issued to shops by Mandals, 2021-22

3.6

Consumption of Pesticides by Mandals, 2021-22

3.7

Area Cultivated for Seed purpose by Mandals, 2021-22

3.8

Agriculture Infrasructure by Mandals, 2021-22

3.9

Category Wise Rice Mills and Milling Capacity by Mandals, 2021-22

3.10

Rythu Vedikalu and Rythu Bandu Samithis by Mandals, 2021-22

3.11

Category wise Total Operational Holdings and Extent, 2015-16 by Mandals

3.12

Category wise Scheduled Castes Operational Holdings and Extent, 2015-16 by Mandals

3.13

Category wise Scheduled Tribes Operational Holdings and Extent, 2015-16 by Mandals

3.14

Category wise Others Operational Holdings and Extent, 2015-16 by Mandals

3.15

Category wise Women Operational Holdings and Extent, 2015-16 by Mandals

39

<!-- page 59 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

TABLE 3.1
SEASON WISE AREA,YIELD & PRODUCTION OF PRINCIPAL CROPS, 2021-22
(in Acres)
Season wise Sown Area
Sl
No.
1

1
2
3
4
5
6
7
8
9
10
12
13

15
16
17
18

Name of the Crop

2

Paddy
Jowar
Bajra
Maize
Ragi
Greengram
Blackgram
Redgram
Other Pulses
Total Pulses
Total Foodgrains
Chillies
Turmeric
Total Condiments and
Spices
Sugarcane (Cane+Gur)
Mango
Batavia
cashew nut

19 Other Fresh and Dry Fruits

21

24
25
26
27
28
29
30
31
33
34
35
36
37

Total Fresh and Dry
Fruits
Onions
Total Vegetables
Total Food Crops
Cotton (Lint+Kapas)
Groundnut
Sesamum
Safflower
Sunflower
Rape and Mustard
Soya been
Palm Oil
Total Oil Seeds
Tobacco (Desi+Verginia)
Fodder Crops
Flower Crops
Mulberry
Other Non Food Crops
Total Non Food Crops
District Total

Vanakalam

Yasangi

3

4

Total
5

462077 433023
187
272
26
90
168
312
3
4
330
2229
9
1227
10806
25
63
812
11208
4293
473669 437994
3702
374
0
0

895100
459
116
480
7
2559
1236
10831
875
15501

Gross
Yield
Production Value
(in
(in Tonnes) Outpot
kgs/Acr.)
(in Rs.)
6

2027
584
422
2585
571
352
519
239
1074
2184

7

911663

8373

4076
0

1919
0

964531
268
49
1241
4
901
642
2586
286
4415
970508
7821
0

3702

374

4076

1919

7821

188
2039
31254
24

0
0
0
0

188
2039
31254
24

40894
2241
10059
25

7688
4569
314379
6

10347

465

10812

75781

29163

10371

465

10836

75806

29169

81
9000
116574
6594

729
24152
1032379
918426
35910
22
19
124
3
36
6475
42589
0
0
0
0
0
0
1993394

16
65
2971
3623
490729 442521
653768
0
462 37152
11
69
0
47
0
226
2
5
52
0
628
0
1155 37499
0
0
0
0
0
0
0
0
0
0
0
0
1145652 480020

933250

211672

653768
37614
80
47
226
7
52
628
38654
0
0
0
0
0
0
1625672

638
955
275
404
549
429
692
10311
13615
0
0
0
0
0
0

Source: Directorate of Economics & Statistics, Hyderabad

40

8

<!-- page 60 -->

41

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

10608
15407
18518
16894
15413
18581
25737
31465
23582
7193
3708
187106
19120
33591
28075
27088
17924
40945
15648
2957
10393
12510
208251
4160
2659
2877
10664
19401
1447
6013
2280
16285
934
66720
462077

3

Vanakalam

8370
16921
18304
14217
14410
18832
26407
33194
25432
8902
4203
189192
18134
31842
26745
26209
17544
39679
15357
2889
11782
11213
201394
2863
1805
3262
7707
16348
1716
4520
1123
2819
274
42437
433023

4

Yasangi

Paddy

18978
32328
36822
31111
29823
37413
52144
64659
49014
16095
7911
376298
37254
65433
54820
53297
35468
80624
31005
5846
22175
23723
409645
7023
4464
6139
18371
35749
3163
10533
3403
19104
1208
109157
895100

5

Total

17
0
0
1
0
0
0
0
0
2
0
20
0
0
0
0
0
0
0
0
1
1
2
92
58
0
0
0
0
4
5
2
4
165
187

6

Vanakalam

2
4
6
13
1
0
0
0
0
7
8
41
5
0
0
0
0
0
7
0
29
2
43
25
34
32
8
0
35
37
12
1
4
188
272

7

Yasangi

Jowar

TABLE - 3.2
SEASON WISE CROPPED AREA BY MANDALS, 2021-22

19
4
6
14
1
0
0
0
0
9
8
61
5
0
0
0
0
0
7
0
30
3
45
117
92
32
8
0
35
41
17
3
8
353
459

8

Total

0
0
0
0
0
0
3
0
0
0
0
3
0
0
0
0
0
0
0
0
0
1
1
2
10
2
2
0
0
4
1
0
1
22
26

9

Vanakalam

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
4
0
0
0
0
2
0
6
0
44
1
0
0
0
0
22
17
0
84
90

10

Yasangi

Bajra

0
0
0
0
0
0
3
0
0
0
0
3
0
0
0
4
0
0
0
0
2
1
7
2
54
3
2
0
0
4
23
17
1
106
116

11

Total

(in Acres)

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 61 -->

42

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

9
0
0
74
0
0
0
0
0
0
0
83
0
0
0
0
0
0
0
0
0
0
0
0
72
6
0
4
0
3
0
0
0
85
168

12

Vanakalam

Maize

0
0
9
67
0
0
0
0
0
17
31
124
0
1
0
0
0
0
0
0
0
0
1
9
166
7
1
0
0
1
0
0
3
187
312

13

Yasangi

9
0
9
141
0
0
0
0
0
17
31
207
0
1
0
0
0
0
0
0
0
0
1
9
238
13
1
4
0
4
0
0
3
272
480

14

Total

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
3
0
0
0
0
0
0
0
0
0
3
3

15

Vanakalam

Ragi

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
3
0
0
0
0
0
1
0
0
4
4

16

Yasangi

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
3
3
0
0
0
0
0
1
0
0
7
7

17

Total

16
6
35
15
11
6
6
1
7
12
4
119
57
20
17
18
0
2
0
1
17
0
132
4
13
12
24
1
0
9
15
0
1
79
330

18

Vanakalam

3
3
17
7
5
2
2
2
10
13
11
75
85
0
0
1
0
2
21
626
1030
40
1805
0
19
14
260
4
9
7
3
10
23
349
2229

19

Yasangi

Greengram

19
9
52
22
16
8
8
3
17
25
15
194
142
20
17
19
0
4
21
627
1047
40
1937
4
32
26
284
5
9
16
18
10
24
428
2559

20

Total

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 62 -->

43

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

0
0
0
0
0
0
0
1
0
0
3
4
0
0
0
0
0
0
0
0
0
0
0
2
1
0
2
0
0
0
0
0
0
5
9

21

Vanakalam

62
131
220
70
18
9
12
38
25
48
23
656
62
25
0
3
0
8
93
26
97
19
333
3
22
33
112
4
10
6
26
19
3
238
1227

22

Yasangi

Blackgram

62
131
220
70
18
9
12
39
25
48
26
660
62
25
0
3
0
8
93
26
97
19
333
5
23
33
114
4
10
6
26
19
3
243
1236

23

Total

1006
353
383
494
225
140
111
192
214
326
459
3903
244
128
39
76
45
8
77
267
237
730
1851
137
1748
1602
780
128
103
151
284
36
83
5052
10806

24

Vanakalam

Redgram

6
1
3
0
3
0
1
1
3
0
0
18
0
0
0
0
0
0
1
0
0
0
1
0
0
1
5
0
0
0
0
0
0
6
25

25

Yasangi

1012
354
386
494
228
140
112
193
217
326
459
3921
244
128
39
76
45
8
78
267
237
730
1852
137
1748
1603
785
128
103
151
284
36
83
5058
10831

26

Total

37
0
0
0
0
0
0
2
0
0
0
39
0
0
0
0
0
0
0
0
0
7
7
2
5
5
2
0
0
2
1
0
0
17
63

27

2
0
10
5
2
15
1
5
3
35
38
116
25
4
0
0
0
0
24
68
315
18
454
11
73
23
112
5
0
11
7
1
0
243
813

28

Yasangi

Other Pulses
Vanakalam

39
0
10
5
2
15
1
7
3
35
38
155
25
4
0
0
0
0
24
68
315
25
461
13
78
28
114
5
0
13
8
1
0
260
876

29

Total

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 63 -->

44

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

1059
359
418
509
236
146
117
196
221
338
466
4065
301
148
56
94
45
10
77
268
254
737
1990
145
1767
1619
808
129
103
162
300
36
84
5153
11208

30

Vanakalam

73
135
250
82
28
26
16
46
41
96
72
865
172
29
0
4
0
10
139
720
1442
77
2593
14
114
71
489
13
19
24
36
30
26
836
4294

31

Yasangi

Total Pulses

1132
494
668
591
264
172
133
242
262
434
538
4930
473
177
56
98
45
20
216
988
1696
814
4583
159
1881
1690
1297
142
122
186
336
66
110
5989
15502

32

Total

11693
15766
18936
17478
15649
18727
25857
31661
23803
7538
4181
191289
19421
33739
28131
27182
17969
40955
15725
3225
10648
13251
210246
4403
4566
4504
11474
19534
1550
6186
2586
16323
1023
72149
473684

33

Vanakalam

8445
17060
18569
14380
14439
18858
26423
33240
25473
9022
4314
190223
18311
31872
26745
26217
17544
39689
15514
3609
13255
11292
204048
2911
2168
3373
8205
16361
1770
4582
1194
2867
307
43738
438009

34

Yasangi

Total Foodgrains

TABLE - 3.4 (Contd.)
SEASON WISE CROPPED AREA BY MANDALS, 2021-22

20138
32826
37505
31858
30088
37585
52280
64901
49276
16560
8495
381512
37732
65611
54876
53399
35513
80644
31239
6834
23903
24543
414294
7314
6734
7877
19679
35895
3320
10768
3780
19190
1330
115887
911693

35

Total

4
22
1
48
0
20
3
0
0
68
10
176
50
4
0
0
1
3
737
1534
266
314
2909
4
13
59
30
106
0
118
21
17
249
617
3702

36

Vanakalam

1
2
5
45
8
0
1
0
2
9
1
74
4
6
0
0
0
0
0
0
6
2
18
32
19
28
51
10
3
21
41
76
1
282
374

37

Yasangi

Chillies

5
24
6
93
8
20
4
0
2
77
11
250
54
10
0
0
1
3
737
1534
272
316
2927
36
32
87
81
116
3
139
62
93
250
899
4076

38

Total

(in Acres)

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 64 -->

45

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

39

Vanakalam

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

40

Yasangi

Turmeric

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

41

Total

4
22
1
49
0
20
3
0
0
68
10
177
50
4
0
0
1
3
737
1534
266
314
2909
4
15
59
30
106
0
118
21
17
249
619
3705

42

2
2
5
45
8
0
1
0
2
17
16
98
4
6
0
0
0
2
0
0
6
2
20
34
19
28
51
10
3
21
43
76
1
286
404

43

Yasangi

6
24
6
94
8
20
4
0
2
85
26
275
54
10
0
0
1
5
737
1534
272
316
2929
38
34
87
81
116
3
139
64
93
250
905
4109

44

Total

Total Condiments and Spices
Vanakalam

0
0
54
8
7
5
4
15
45
0
0
138
0
0
5
0
0
2
0
0
0
0
7
0
0
0
43
0
0
0
0
0
0
43
188

45

Vanakalam

0
2
22
2
3
3
6
2
390
0
6
436
0
0
0
0
0
2
0
0
0
0
2
0
0
1
101
0
0
0
0
0
0
102
540

46

Yasangi

Sugarcane

0
2
76
10
10
8
10
17
435
0
6
574
0
0
5
0
0
4
0
0
0
0
9
0
0
1
144
0
0
0
0
0
0
145
728

47

Total

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 65 -->

46

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

324
60
253
90
45
50
26
120
69
9
66
1112
18
23
0
39
19
17
4
4
0
65
189
214
286
97
41
116
0
4
35
65
8
866
2167

48

Vanakalam

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

49

Yasangi

Mango

324
60
253
90
45
50
26
120
69
9
66
1112
18
23
0
39
19
17
4
4
0
65
189
214
286
97
41
116
0
4
35
65
8
866
2167

50

Total

331
111
318
12
43
37
1604
2831
3704
215
393
9599
5058
4287
1105
2713
351
311
1133
356
624
5867
21805
517
426
972
4145
5516
87
329
87
21
49
12149
43553

51

Vanakalam

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

52

Yasangi

Batavia

331
111
318
12
43
37
1604
2831
3704
215
393
9599
5058
4287
1105
2713
351
311
1133
356
624
5867
21805
517
426
972
4145
5516
87
329
87
21
49
12149
43553

53

Total

0
0
24
0
0
0
0
0
0
0
0
24
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
24

54

Vanakalam

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

55

Yasangi

Cashewnut

0
0
24
0
0
0
0
0
0
0
0
24
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
24

56

Total

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 66 -->

47

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

1393
537
1535
1008
2523
553
2247
4080
4224
516
497
19113
5176
4378
1109
2885
400
379
1145
387
642
6058
22559
890
977
1750
4328
5775
87
372
189
88
67
14523
56195

57

3
8
27
43
2
6
8
0
3
91
35
226
4
2
0
29
0
0
11
0
15
0
61
8
3
95
45
0
0
5
7
15
0
178
465

58

Yasangi

1396
545
1562
1051
2525
559
2255
4080
4227
607
532
19339
5180
4380
1109
2914
400
379
1156
387
657
6058
22620
898
980
1845
4373
5775
87
377
196
103
67
14701
56660

59

Total

Total Fresh and Dry Fruits
Vanakalam

0
0
0
0
0
0
0
0
0
5
0
5
3
1
0
0
0
0
2
0
0
0
6
0
5
0
0
0
0
0
0
0
0
5
16

60

Vanakalam

Onions

2
3
4
0
0
0
0
0
0
39
3
51
0
0
0
0
0
0
2
0
0
0
2
0
7
4
0
0
0
0
1
0
0
12
65

61

Yasangi

2
3
4
0
0
0
0
0
0
44
3
56
3
1
0
0
0
0
4
0
0
0
8
0
12
4
0
0
0
0
1
0
0
17
81

62

Total

121
31
19
15
19
62
35
64
27
11
36
440
23
20
22
173
0
36
12
4
30
42
362
110
233
210
105
1343
1
113
56
0
23
2194
2996

63

51
9
41
41
29
84
120
86
110
103
99
773
2
21
0
491
0
44
15
5
80
26
684
114
223
284
76
1349
8
23
113
65
8
2263
3720

64

Yasangi

Total Vegetables
Vanakalam

172
40
60
56
48
146
155
150
137
114
135
1213
25
41
22
664
0
80
27
9
110
68
1046
224
456
494
181
2692
9
136
169
65
31
4457
6716

65

Total

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 67 -->

48

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

13211
16356
20545
18558
18198
19367
28146
35820
28099
8133
4724
211157
24670
38141
29267
30240
18370
41375
17619
5150
11586
19665
236083
5407
5791
6523
15980
26758
1638
6789
2852
16428
1362
89528
536768

66

Vanakalam

8501
17081
18664
14511
14481
18951
26558
33328
25978
9233
4470
191756
18321
31901
26745
26737
17544
39737
15540
3614
13356
11320
204815
3067
2413
3781
8478
17720
1781
4631
1357
3023
316
46567
443138

67

Yasangi

68

Total

21712
33437
39209
33069
32679
38318
54704
69148
54077
17366
9194
402913
42991
70042
56012
56977
35914
81112
33159
8764
24942
30985
440898
8474
8204
10304
24458
44478
3419
11420
4209
19451
1678
136095
979906

Total Food Crops

26406
28715
13527
23931
8573
8794
7102
22020
14876
40433
39764
234141
14377
4734
792
13331
2574
28
4953
9534
23968
30019
104310
31516
42999
46648
47822
23590
15260
11532
38927
21401
35622
315317
653768

69

Vanakalam

3
1
0
2
3
0
0
0
0
4
2
15
0
0
0
0
1
0
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
16

70

Yasangi

Cotton

TABLE - 3.4 (Contd.)
SEASON WISE CROPPED AREA BY MANDALS, 2021-22

26409
28716
13527
23933
8576
8794
7102
22020
14876
40437
39766
234156
14377
4734
792
13331
2575
28
4953
9534
23968
30019
104311
31516
42999
46648
47822
23590
15260
11532
38927
21401
35622
315317
653784

71

Total

3
13
33
15
15
34
28
5
29
5
6
186
2
4
0
6
0
0
30
3
6
1
52
11
94
4
18
0
0
49
20
22
6
224
462

72

Vanakalam

37
70
114
150
115
89
147
109
530
126
304
1791
426
36
0
48
0
14
136
702
1900
1812
5074
288
1905
1011
2024
2984
4734
1821
5226
4503
5791
30287
37152

73

Yasangi

Groundnut

40
83
147
165
130
123
175
114
559
131
310
1977
428
40
0
54
0
14
166
705
1906
1813
5126
299
1999
1015
2042
2984
4734
1870
5246
4525
5797
30511
37614

74

Total

(in Acres)

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 68 -->

49

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

2
0
1
0
0
0
0
0
0
0
0
3
0
0
0
0
0
0
0
0
0
0
0
0
3
2
0
0
0
3
0
0
0
8
11

75

Vanakalam

3
0
0
18
0
0
0
2
0
7
5
35
0
0
0
0
0
0
2
0
16
0
18
0
2
0
6
0
0
2
0
6
0
16
69

76

Yasangi

Sesamum

5
0
1
18
0
0
0
2
0
7
5
38
0
0
0
0
0
0
2
0
16
0
18
0
5
2
6
0
0
5
0
6
0
24
80

77

Total

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

78

Vanakalam

0
10
0
0
0
0
0
0
0
0
17
27
0
0
0
0
0
0
0
0
0
0
0
2
15
0
0
0
0
0
3
0
0
20
47

79

Yasangi

Safflower

0
10
0
0
0
0
0
0
0
0
17
27
0
0
0
0
0
0
0
0
0
0
0
2
15
0
0
0
0
0
3
0
0
20
47

80

Total

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

81

Vanakalam

0
0
0
0
0
0
0
0
0
0
5
5
4
0
0
0
0
0
0
0
0
0
4
20
20
149
2
0
0
0
11
15
0
217
226

82

Yasangi

Sunflower

0
0
0
0
0
0
0
0
0
0
5
5
4
0
0
0
0
0
0
0
0
0
4
20
20
149
2
0
0
0
11
15
0
217
226

83

Total

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 69 -->

50

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

2
0
0
0
0
0
0
0
0
0
0
2
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
2

84

0
0
0
2
0
0
0
2
0
0
0
4
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
1
5

85

Yasangi

Rape and Mustard
Vanakalam

2
0
0
2
0
0
0
2
0
0
0
6
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
1
0
1
7

86

Total

0
0
0
0
0
0
0
0
0
1
51
52
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
52

87

Vanakalam

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

88

Yasangi

Soya bean

0
0
0
0
0
0
0
0
0
1
51
52
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
52

89

Total

0
0
0
0
2
0
62
16
0
0
0
80
276
109
52
6
0
36
1
0
67
7
554
0
0
0
0
0
0
0
0
0
0
0
634

90

Vanakalam

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

91

Yasangi

Palm Oil

0
0
0
0
2
0
62
16
0
0
0
80
276
109
52
6
0
36
1
0
67
7
554
0
0
0
0
0
0
0
0
0
0
0
634

92

Total

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 70 -->

51

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

8
13
37
15
17
34
95
21
29
6
60
335
278
113
52
12
0
36
31
3
73
8
606
13
98
6
18
0
0
53
20
22
6
236
1177

93

Vanakalam

40
80
114
177
115
89
147
113
530
136
367
1908
430
36
0
48
0
14
138
702
1916
1812
5096
314
1961
1164
2037
2984
4734
1823
5253
4550
5791
30611
37615

94

Yasangi

Total Oil Seeds

48
93
151
192
132
123
242
134
559
142
427
2243
708
149
52
60
0
50
169
705
1989
1820
5702
327
2059
1170
2055
2984
4734
1876
5273
4572
5797
30847
38792

95

Total

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

96

Vanakalam

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

97

Yasangi

Tobacco

TABLE - 3.4 (Concld.)
SEASON WISE CROPPED AREA BY MANDALS, 2021-22

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

98

Total

12
0
0
0
0
8
0
1
0
0
1
22
0
0
0
0
0
0
0
0
0
0
0
0
29
2
0
0
0
9
1
0
0
41
63

99

Vanakalam

3
0
0
0
2
0
0
0
0
8
5
18
0
0
0
0
0
1
1
3
4
0
9
6
51
4
0
0
0
11
2
0
0
74
101

100

Yasangi

Fodder Crops

15
0
0
0
2
8
0
1
0
8
6
40
0
0
0
0
0
1
1
3
4
0
9
6
80
6
0
0
0
20
3
0
0
115
164

101

Total

(in Acres)

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 71 -->

52

22
23
24
25
26
27
28
29
30
31

12
13
14
15
16
17
18
19
20
21

Chityala
Narketpally
Kattangoor
Sali Gouraram
Nakrekal
Kethepally
Thipparthi
Nalgonda
Kangal
Munugode
Chandur
Nalgonda Division Total
Anumula
Nidamanur
Thripuraram
Madugulapally
Vemulapally
Miryalaguda
Dameracherla
Adavi Devula Pally
Tirumalagiri Sagar
Peddavoora
Miryalaguda Division Total
Marriguda
Chinthapally
Nampalle
Gurrampode
Pedda Adiserla Pally
Neradugommu
Kondamallepally
Devarakonda
Gundlapally
Chandampet
Devarakonda Division Total
Total

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

1
0
2
0
0
3
0
0
0
0
0
6
0
0
0
0
0
1
0
0
0
0
1
0
0
1
0
0
0
6
0
0
0
7
14

102

Vanakalam

0
0
2
0
0
0
0
0
0
0
0
2
0
0
0
0
0
1
0
0
0
0
1
0
0
0
0
0
0
0
0
0
0
0
3

103

Yasangi

Flower Crops

1
0
4
0
0
3
0
0
0
0
0
8
0
0
0
0
0
2
0
0
0
0
2
0
0
1
0
0
0
6
0
0
0
7
17

104

Total

24
12
2
7
15
5
1
7
5
0
5
83
0
0
0
0
0
0
0
0
6
2
8
0
1
8
6
0
0
5
10
0
0
30
121

105

Vanakalam

Mulberry

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

106

Yasangi

24
12
2
7
15
5
1
7
5
0
5
83
0
0
0
0
0
0
0
0
6
2
8
0
1
8
6
0
0
5
10
0
0
30
121

107

Total

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
6
0
0
0
6
6

108

Vanakalam

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

109

Yasangi

Other Crops

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
6
0
0
0
6
6

110

Total

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 72 -->

111

Vanakalam
112

Yasangi

26652
28861
13748
24209
8784
8989
7375
22234
15493
40602
40227
237174
15091
4902
844
13493
2575
93
5127
10263
25975
31864
110227
31918
45574
48173
49929
26582
19995
13456
44235
25973
41434
347269
694670

113

Total

Total Non Food Crops

Chityala
26606
46
Narketpally
28780
81
Kattangoor
13632
116
Sali Gouraram
24030
179
Nakrekal
8664
120
Kethepally
8900
89
Thipparthi
7228
147
Nalgonda
22121
113
Kangal
14963
530
Munugode
40452
150
Chandur
39853
374
Nalgonda Division Total
235229
1945
12 Anumula
14661
430
13 Nidamanur
4866
36
14 Thripuraram
844
0
15 Madugulapally
13445
48
16 Vemulapally
2574
1
17 Miryalaguda
77
16
18 Dameracherla
4988
139
19 Adavi Devula Pally
9558
705
20 Tirumalagiri Sagar
24055
1920
21 Peddavoora
30052
1812
Miryalaguda Division Total
105120
5107
22 Marriguda
31598
320
23 Chinthapally
43558
2016
24 Nampalle
47005
1168
25 Gurrampode
47891
2038
26 Pedda Adiserla Pally
23598
2984
27 Neradugommu
15261
4734
28 Kondamallepally
11622
1834
29 Devarakonda
38980
5255
30 Gundlapally
21423
4550
31 Chandampet
35643
5791
Devarakonda Division Total
316579
30690
Total
656928
37742
Source: Directorate of Economics & Statistics, Hyderabad

2

1

1
2
3
4
5
6
7
8
9
10
11

Name of the Mandal

Sl.
No.

39817
45136
34177
42588
26862
28267
35374
57941
43062
48585
44577
446386
39331
43007
30111
43685
20944
41452
22607
14708
35641
49717
341203
37005
49349
53528
63871
50356
16899
18411
41832
37851
37005
406107
1193696

114

Vanakalam

8547
17162
18780
14690
14601
19040
26705
33441
26508
9383
4844
193701
18751
31937
26745
26785
17545
39753
15679
4319
15276
13132
209922
3387
4429
4949
10516
20704
6515
6465
6612
7573
6107
77257
480880

115

Yasangi

Gross Area Sown

48364
62298
52957
57278
41463
47307
62079
91382
69570
57968
49421
640087
58082
74944
56856
70470
38489
81205
38286
19027
50917
62849
551125
40392
53778
58477
74387
71060
23414
24876
48444
45424
43112
483364
1674576

116

Total

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

53

<!-- page 73 -->

2

1

Nil

2021-22
4

Sugarcane Crushed
2020-21
3

Source: Commissioner, Sugarcane Dept.

Total

Name of the
Factory

Sl. No.
2020-21
5

2021-22
6

Sugar Produced

(in M.Tonnes)

FACTORY WISE QUANTITY OF SUGARCANE CRUSHED AND SUGAR PRODUCED, 2020-21 & 2021-22

TABLE - 3.3

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

54

<!-- page 74 -->

2

3

IKP

3
6
2
2
2
30
2
3
9
9
11
17
6
4
7
6
3
9
9
22
1
11
5
7
7
3
9
8
2
10
3
228

4

PACS

Vanakalam

0
2
0
2
0
2
0
0
0
0
0
0
0
0
0
0
0
0
2
2
0
0
0
2
0
0
0
2
2
0
0
16

5

3
21
2
12
2
32
4
3
9
15
52
28
25
4
18
6
3
21
22
50
2
39
5
11
7
5
20
34
10
11
5
481

6

4188
13240
378
5715
2677
20230
4449
1674
14540
13136
42227
28996
23947
4004
19110
2170
7442
14080
27159
48529
1080
30479
1565
22176
7090
4737
22527
28980
9394
22583
4746
453248

7

9

Procurement
(Tonnes)

0.00
2197.11
101.83
1476.67
742.97
3706.50
211.86
172.17
551.10
2573.55
7226.60
4699.57
3619.27
863.77
1498.47
791.30
64.39
3425.32
4739.30
9695.23
528.55
3814.79
484.53
644.63
1401.06
865.50
2478.11
4247.21
761.65
381.54
230.52
64195.08

10

Value of
Procurement
(Rs. in Lakhs)

Yasangi

820.91
0
2594.95
11210
74.09
520
1120.23
7534
524.68
3791
3964.92
18927
872.09
1081
328.17
878
2849.85
2812
2574.71
13130
8276.46
36870
5683.22
23979
4693.68
18467
784.78
4407
3745.58
7647
425.33
4037
1458.64
329
2759.59
17476
5323.18
24181
9511.45
49479
211.64
2697
5973.93
19464
306.67
2472
4346.50
3289
1389.59
7148
928.37
4416
4415.21
12643
5680.09
21670
1841.18
3886
4426.23
1947
930.22
1177
88836.15 327564.36

8

Civil supplies
Value of
Procuremen
department Total
Procurement
t (Tonnes)
(Others)
(Rs. in Lakhs)

No. of Procurement Centres

Adavidevulapally
0
Anumula
13
Chandampeta
0
Chandur
8
Chintha Palle
0
Chityal
0
Damercherla
2
Devarakonda
0
Gundla Palle
0
Gurrampode
6
Kangal
41
Kattangur
11
Kethepally
19
Konda Mallepally
0
Madugulapally
11
Marri Guda
0
Miryalaguda
0
Munugode
12
Nakrekal
11
Nalgonda
26
Nampally
1
Narketpalle
28
Neredugommu
0
Nidamanur
2
Peda Adisharla Palli 0
Peddavoora
2
Shaligouraram
11
Tipparthy
24
Tirumalagiri (Sagar) 6
Tripuraram
1
Vemulapally
2
Total
237
Source: DM(Civil Supplies)

1

1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31

Name of the Mandal

Sl.
No.

TABLE - 3.4
SEASON WISE PADDY PROCUREMENT BY MANDALS, 2021-22

4188
24449
898
13250
6468
39157
5530
2553
17352
26267
79097
52975
42414
8411
26757
6207
7771
31556
51340
98008
3776
49943
4037
25465
14238
9152
35170
50650
13280
24530
5923
780813

11

Procurement
(Tonnes)

820.91
4792.06
175.91
2596.91
1267.65
7671.43
1083.95
500.35
3400.94
5148.26
15503.06
10382.79
8312.95
1648.55
5244.04
1216.63
1523.03
6184.91
10062.48
19206.68
740.19
9788.72
791.20
4991.12
2790.65
1793.88
6893.33
9927.30
2602.83
4807.77
1160.74
153031.23

12

Value of
Procurement (Rs.
in Lakhs)

Total (Vanakalam + Yasangi)

( as on 31.05.2022)

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

55

<!-- page 75 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

TABLE - 3.5
CONSUMPTION OF CHEMICAL FERTILIZERS & LICENSE ISSUED TO SHOPS BY MANDALS, 202122
Sl.
No.

Name of the Mandal

1

2

Consumption Consumption Consumption
Others
of Urea
of NPK
of DAP
(in Tonnes)
(in Tonnes)
(in Tonnes)
(in tonnes)

Total
(in Tonnes)

Average
Consumption
per Acre
(in Kgs.)

3

4

5

6

7

8

1 Chityala

1736.07

823.89

158.83

145.65

2864.44

60

2 Narketpalle

1727.41

819.77

158.03

144.92

2850.14

41

3 Kattangoor

1116.46

529.83

102.15

93.67

1842.10

33

4 Saligouraram

1638.92

777.78

149.94

137.50

2704.15

45

5 Nakrekal

1079.04

512.07

98.72

90.53

1780.35

42

6 Kethepalle

1046.40

496.59

95.73

87.79

1726.52

38

7 Thipparthi

1009.71

479.18

92.38

84.72

1665.99

26

8 Nalgonda

2648.08

1256.70

242.26

222.16

4369.21

48

9 Kangal

1848.90

877.42

169.16

155.12

3050.61

43

10 Munugode

2684.22

1273.84

245.57

225.20

4428.83

75

11 Chandur

2551.67

1210.93

233.44

214.07

4210.12

85

Nalgonda Division

19086.90

9058.00

1746.21

1601.34

31492.44

49

12 Anumula_Haliya

1498.25

711.02

137.04

125.70

2472.01

44

13 Nidamanur

2040.08

968.15

186.64

171.15

3366.02

45

14 Thripuraram

1357.96

644.44

124.24

113.93

2240.58

39

15 Madugulapally

1612.19

765.09

147.49

135.25

2660.02

39

16 Vemulapalle

896.89

425.63

82.06

75.25

1479.83

38

17 Miryalaguda

1336.58

634.29

122.28

113.71

2206.86

27

18 Damaracherla

1336.58

634.29

122.28

112.14

2205.29

57

19 Adavi devula palli

1338.05

635.00

122.41

112.26

2207.71

113

20 Tirumalagiri_Sagar

1223.94

580.84

111.98

102.69

2019.45

41

21 Peddavura

1826.78

866.93

167.13

153.26

3014.09

49

Miryalaguda Division 14467.30

6865.69

1323.55

1215.33

23871.87

47

22 Marriguda

2592.23

1230.18

237.16

217.48

4277.05

101

23 Chinthapalle

2538.40

1204.64

232.23

212.96

4188.22

78

24 Nampalle

2356.06

1118.11

215.55

197.67

3887.39

65

25 Gurrampode

2709.29

1285.74

247.86

227.30

4470.20

59

26 Pedda_adiserlapalle

2200.66

1044.35

201.34

184.62

3630.97

55

27 Neredugommu

641.56

304.47

58.70

53.82

1058.54

49

28 Kondamallapally

1008.97

478.83

92.31

84.65

1664.76

63

29 Devarakonda

2281.22

1082.59

208.70

191.38

3763.89

76

30 Gundlapalle

1584.72

752.06

144.98

132.95

2614.71

56

31 Chandampet

1235.92

586.53

113.07

103.69

2039.22

61

Devarakonda Division 19149.04

9087.49

1751.91

1606.53

31594.96

66

25011.17

4821.66

4423.20

86959.27

55

Total

52703.24

56

<!-- page 76 -->

HAND BOOK OF STASTICS - 2022

NALGONDA DISTRICT

TABLE - 3.5(concld.)
CONSUMPTION OF CHEMICAL FERTILIZERS & LICENSE ISSUED TO SHOPS BY MANDALS, 2021-22
Sl.
No.

Name of the Mandal

1

2

No.of License issued ( as on 31.03.2022)
Fertilizer Shops
9

Pestiside Shops
10

1 Chityala

22

13

34

2 Narketpalle

22

9

23

3 Kattangoor

18

7

21

4 Saligouraram

20

16

26

5 Nakrekal

24

23

48

6 Kethepalle

22

17

22

7 Thipparthi

17

8

25

8 Nalgonda

45

34

62

9 Kangal

29

8

27

10 Munugode

37

36

44

11 Chandur
Nalgonda Division

25
281

20
0

191

Seed Shops
11

Nurseries
12

41
0

373

12 Anumula_Haliya

39

15

47

13 Nidamanur

21

12

24

14 Thripuraram

23

4

15 Madugulapally

28

38

16 Vemulapalle

22

26

17 Miryalaguda

74

61

18 Damaracherla

22

43

19 Information
to be
32
obtained
18
from
50 Horticulture
Dept
34

19 Adavi devula palli

17

15

12

20 Tirumalagiri_Sagar

14

1

10

21 Peddavura

38

10

48

Miryalaguda Division

298

0

225

0

294

22 Marriguda

19

41

29

23 Chinthapalle

37

38

49

24 Nampalle

7

19

48

25 Gurrampode

25

13

25

26 Pedda_adiserlapalle

27

32

32

27 Neredugommu

13

14

10

28 Kondamallapally

18

24

24

29 Devarakonda

47

72

87

30 Gundlapalle

19

26

26

31 Chandampet

6

17

8

Devarakonda Division

Total

218

0

296

0

338

797

0

712

0

1005

Source: District Agriculture Officer & District Horticulture Officer

57

<!-- page 77 -->

2

1

58

Total

1 Chityala
2 Narketpalle
3 Kattangoor
4 Saligouraram
5 Nakrekal
6 Kethepalle
7 Thipparthi
8 Nalgonda
9 Kangal
10 Munugode
11 Chandur
Nalgonda Division
12 Anumula_Haliya
13 Nidamanur
14 Thripuraram
15 Madugulapally
16 Vemulapalle
17 Miryalaguda
18 Damaracherla
19 Adavi devula palli
20 Tirumalagiri_Sagar
21 Peddavura
Miryalaguda Division
22 Marriguda
23 Chinthapalle
24 Nampalle
25 Gurrampode
26 Pedda_adiserlapalle
27 Neredugommu
28 Kondamallapally
29 Devarakonda
30 Gundlapalle
31 Chandampet
Devarakonda Division

Name of the Mandal

Sl.
No.

173577.60

6132.00
5785.50
4137.00
5407.50
4154.85
4343.85
4271.40
9384.90
6106.80
7103.25
7801.50
64628.55
5218.50
6960.45
4370.10
6841.80
3076.50
6040.65
4230.45
2910.60
4673.55
5947.20
50269.80
7991.55
7676.55
7799.40
8865.15
7124.25
1797.60
2901.15
6398.70
4721.85
3403.05
58679.25

Consumption of
Weedicides
(in kgs/Ltrs)
3

10380.30

374.85
353.85
252.00
330.75
25.20
265.65
261.45
573.30
372.75
434.70
476.70
3721.20
318.15
425.25
266.70
417.90
187.95
369.60
258.30
177.45
285.60
364.35
3071.25
488.25
469.35
476.70
541.80
435.75
110.25
177.45
391.65
288.75
207.90
3587.85

Consumption of Synthetic
Pyretgriuds
(In kgs/Ltrs)
4

202504.05

7152.60
6750.45
4825.80
6308.40
4847.85
5068.35
4982.25
10948.35
7124.25
8286.60
9101.40
75396.30
6086.85
8119.65
5098.80
7982.10
3587.85
7047.60
4935.00
3395.70
5452.65
6938.40
58644.60
9324.00
8956.50
9100.35
10342.50
8312.85
2096.85
3385.20
7465.50
5509.35
3970.05
68463.15

Consumption of Other
Pesticides
(in kgs/Ltrs)
5

In terms of Formulations

TABLE - 3.6
CONSUMPTION OF PESTICIDES BY MANDALS, 2021-22

7

386461.95

21.93

27.18
17.52
15.61
19.27
20.37
20.16
13.95
22.04
18.35
25.69
33.57
20.88
19.92
19.82
16.14
21.08
16.73
15.40
23.11
31.73
20.29
20.45
19.48
39.92
30.44
27.75
24.99
22.70
17.58
23.41
27.25
21.39
21.58
26.18

6

13659.45
12889.80
9214.80
12046.65
9027.90
9677.85
9515.10
20906.55
13603.80
15824.55
17379.60
143746.05
11623.50
15505.35
9735.60
15241.80
6852.30
13457.85
9423.75
6483.75
10411.80
13249.95
111985.65
17803.80
17102.40
17376.45
19749.45
15872.85
4004.70
6463.80
14255.85
10519.95
7581.00
130730.25

Average Consumption
per Acre (in Kgs.)

Total
(in kgs/Ltrs)

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

<!-- page 78 -->

2

1

1 Chityala
2 Narketpalle
3 Kattangoor
4 Saligouraram
5 Nakrekal
6 Kethepalle
7 Thipparthi
8 Nalgonda
9 Kangal
10 Munugode
11 Chandur
Nalgonda Division
12 Anumula_Haliya
13 Nidamanur
14 Thripuraram
15 Madugulapally
16 Vemulapalle
17 Miryalaguda
18 Damaracherla
19 Adavi devula palli
20 Tirumalagiri_Sagar
21 Peddavura
Miryalaguda Division
22 Marriguda
23 Chinthapalle
24 Nampalle
25 Gurrampode
26 Pedda_adiserlapalle
27 Neredugommu
28 Kondamallapally
29 Devarakonda
30 Gundlapalle
31 Chandampet
Devarakonda Division
Total
Source: District Agriculture Officer
374.85
353.85
252.00
330.75
25.20
265.65
261.45
573.30
372.75
434.70
476.70
3721.20
318.15
425.25
266.70
417.90
187.95
369.60
258.30
177.45
285.60
364.35
3071.25
488.25
469.35
476.70
541.80
435.75
110.25
177.45
391.65
288.75
207.90
3587.85
10380.30

9

8

6132.00
5785.50
4137.00
5407.50
4154.85
4343.85
4271.40
9384.90
6106.80
7103.25
7801.50
64628.55
5218.50
6960.45
4370.10
6841.80
3076.50
6040.65
4230.45
2910.60
4673.55
5947.20
50269.80
7991.55
7676.55
7799.40
8865.15
7124.25
1797.60
2901.15
6398.70
4721.85
3403.05
58679.25
173577.60

Name of the Mandal

Consumption of Synthetic
Pyretgriuds
(In kgs/Ltrs)

Consumption of
Weedicides
(in kgs/Ltrs)

Sl.
No.

7152.60
6750.45
4825.80
6308.40
4847.85
5068.35
4982.25
10948.35
7124.25
8286.60
9101.40
75396.30
6086.85
8119.65
5098.80
7982.10
3587.85
7047.60
4935.00
3395.70
5452.65
6938.40
58644.60
9324.00
8956.50
9100.35
10342.50
8312.85
2096.85
3385.20
7465.50
5509.35
3970.05
68463.15
202504.05

10

Consumption of Other
Pesticides
(in kgs/Ltrs)

In terms of Ingredients

TABLE - 3.6(concld.)
CONSUMPTION OF PESTICIDES BY MANDALS, 2021-22

13659.45
12889.80
9214.80
12046.65
9027.90
9677.85
9515.10
20906.55
13603.80
15824.55
17379.60
143746.05
11623.50
15505.35
9735.60
15241.80
6852.30
13457.85
9423.75
6483.75
10411.80
13249.95
111985.65
17803.80
17102.40
17376.45
19749.45
15872.85
4004.70
6463.80
14255.85
10519.95
7581.00
130730.25
386461.95

11

Total
(in kgs/Ltrs)

27.18
17.52
15.61
19.27
20.37
20.16
13.95
22.04
18.35
25.69
33.57
20.88
19.92
19.82
16.14
21.08
16.73
15.40
23.11
31.73
20.29
20.45
19.48
39.92
30.44
27.75
24.99
22.70
17.58
23.41
27.25
21.39
21.58
26.18
21.93

12

Average Consumption
per Acre
(in Kgs.)

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

59

<!-- page 79 -->

Sl.
No.
1
3

2

Total

Paddy

Name of the Mandal
4

Maize
5

Jowar

Nil

Red
gram
6

Green
gram
7

Bengal
gram
8
9

10

Ground nut

(in Acres)
Black gram

AREA CULTIVATED FOR SEED PURPOSE BY MANDALS, 2021-22

TABLE - 3.7

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

60

<!-- page 80 -->

Caster
11

Name of the Mandal

2

0
Chityala
0
Narketpalle
0
Kattangoor
0
Saligouraram
0
Nakrekal
0
Kethepalle
0
Thipparthi
0
Nalgonda
0
Kangal
0
Munugode
0
Chandur
Nalgonda Division
0
12 Anumula_Haliya
0
13 Nidamanur
0
14 Thripuraram
0
15 Madugulapally
0
16 Vemulapalle
0
17 Miryalaguda
0
18 Damaracherla
0
19 Adavi devula palli
0
20 Tirumalagiri_Sagar
0
21 Peddavura
0
Miryalaguda Division
0
22 Marriguda
0
23 Chinthapalle
0
24 Nampalle
0
25 Gurrampode
0
26 Pedda_adiserlapalle
0
27 Neredugommu
0
28 Kondamallapally
0
29 Devarakonda
0
30 Gundlapalle
0
31 Chandampet
0
Devarakonda Division
0
Total
0
Source : District Agriculture Officer

1
2
3
4
5
6
7
8
9
10
11

Sl.
No.
1

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

12

Soyabean

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

Other Oil
Seeds
13

3.33
21.17
0.32
47.38
0.00
19.09
3.06
0.02
0.00
67.23
9.25
167.79
50.11
4.18
0.00
0.00
1.13
3.03
736.28
1532.15
264.23
314.19
2905.30
4.10
11.31
58.12
30.07
106.17
0.00
118.20
20.15
17.17
249.27
614.56
3697.31

14

Chillies

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

15

Turmeric

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

16

Cotton

0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0
0

3.33
21.17
0.32
47.38
0.00
19.09
0.00
0.02
0.00
67.23
9.25
167.79
50.11
4.18
0.00
0.00
1.13
3.03
736.28
1532.15
264.23
314.19
2905.30
4.10
11.31
58.12
30.07
106.17
0.00
118.20
20.15
17.17
249.27
614.56
3697.31

18

Total

(in Acres)
Other
Crops(specify)
17

TABLE - 3.7(concld.)
AREA CULTIVATED FOR SEED PURPOSE BY MANDALS, 2021-22

HAND BOOK OF STASTICS - 2022
NALGONDA DISTRICT

61
