---
doc_id: "b714cdffed460ad5"
source_url: "https://cdn.s3waas.gov.in/s382cec96096d4281b7c95cd7e74623496/uploads/2026/06/17805732502010.pdf"
ministry: "Kumuram Bheem Asifabad"
title: "NOTIFICATION LT & STLS (254 KB)"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "94725418bb824f2e"
---

<!-- page 1 -->

GOVERNAMENT OF TELANGANA
DISTRICT HEALTH SOCIETY:: KUMURAM BHEEM ASIFABAD DISTRICT
WEB NOTIFICATION NO: 01/2026
RECRUITMENT FOR CERTAIN POSTS ON CONTRACT/OUT SOURCING BASIS UNDER
NHM IN KUMURAM BHEEM ASIFABAD DISTRICT

Applications are invited from eligible candidates for Recruitment of (2) lab Technician Gr.
II and (2) STLS in the Kumuram Bheem Asifabad District on Contract and out sourcing Basis
under
National
Health
Mission.
Format
of
application
may
be
available,
www.asifabad.telangana.gov.in in website of Office of the District Medical & Health
Officer, KB Asifabad. Filled it may be submitted in person or by Register post to this office,
along with all Xerox copies of certificates. The receiving applications commence from
_06_.06.2026 at 10:30 AM and ends on _12_.06.2026 by 5:00 PM. The selection committee is not
responsible for any postal delay.
Sl.N Programme Unit Name Name of the
No of Post Contract/
Remuneration
o
Name
post
notified
Out
sourcing
1
NTEP
District
STLS
2
Contract
Rs. 22,100/2
NTEP
Zone -1
Lab Technician Gr.II
3
Contract
Rs. 27,300/TOTAL :
5


No of vacancies in may be differ at the time of selection.

EDUCATIONAL QUALICATION:
Sl.No
Category
Qualification
1.
As per the Annexure -I
STLS( Senior TB
(Enclosed)
laboratory Supervisor)
2.
Lab Technician Gr.II
As per the Annexure -II
(Enclosed)
# Note : The applications already submitted to this prior to this notification
should not be entertained.
AGE :
The minimum Age is 18 years and the Maximum aged is 44 years, the Minimum and
Maximum Age shall be reckoned from 01.07.2026 with the following relaxations allowed for
reckoning the maximum age limit as per rules.
i)
For SCs & STs & BCs
: 05 years
ii)
For Ex Service men
: 03 years in addition to length of Service in
Armed Force.
iii)
Disabled
: 10 years.
The Rule of reservation in respect of Community, Disability, Ex- service Men/Women
shall be strictly observed as per the TS state and subordinate services Rules, 1996, read with
the relevant Specific Rules applicable.
The Rule of Reservation of Local candidates is applicable as per Presidential order, and
posts shall be filed among the candidates who belong to the State of Telangana only.

P.T.O

<!-- page 2 -->

METHOD OF RECRUITMENT:
Selection shall be made based on following Criteria.
1. Total Marks are 100 of which 90 marks will be allotted basing on the marks obtained in
the qualifying examination for compounders, 90 marks will be allotted for written test
conducted by the concerned authorities and 10 marks will be awarded for the age. Weight
age for age will be reckoned from 18 years of age of the candidate 0.5 mark will be
awarded for one completed year of age with a maximum of 10 marks. The age will be
reckoned as on 1.07.2026 (example I) If a candidate completes 20 years as on 1.07.2026,
he will be awarded 1.0marks; Example 2). If a candidate complete 30 years of age as on
01.07.2026, he/she will be awarded 6.0 marks, Example 3). If a candidate completes 40
years of age as on 01.07.2026, he/she will be awarded 10.0 marks)
2. Provisional Merit Lists will be prepared base on the above said criteria, and displayed on
Kumuram Bheem Asifabad district official website www.asifabad.telangana.gov.in
for transparency.
3. Selection List will be prepared from the finalized Merit list duly following the Rule of
Reservation (Roster Matrix) and 317 GO presidential order.
4. The Roaster Points starts from Point No.01 and continue sequentially.
HOW TO APPLY:
1. Application from along with the instructions can be download from website
www.asifabad.telangana.gov.in
2. Filled Application From shall be submitted in person or through registered post to O/o
District Medical & Health Officer, IDOC Complex F-25,KB Asifabad Application which
are received after due date will be summarily rejected by District Selection Committee is
not responsible for the posts delays.
3. Application/ Registration Fees to be paid in Form of Demand Draft (DD) in favor of the
District Medical & Health Officer, Kumuram Bheem Asifabad, pay bill at KB Asifabad as
details below.
METHOD OF RECURITMENT:
The Recruitment is made on contract basis and the contract is initially for a period
of one year and renewal will be as per the need and NHM yearly plan(PIP) and also subject
to satisfactory performance, However, every year new contract has to signed and valid
for the period as indicated in the contract. The Recruitment shall be done by the District
Selection Committee in behalf of the District Health Society. The District Selection
Committee shall consist the following:
1.
District Collector
- Chairman
2. District Medical & Health Officer
-Member Convener
3. Deputy Director Social Welfare
- Member
4. Superintendent Dist Hospital(TVVP) - Member
5. District Employment Officer
- Member
Applications unit of acceptance:
As per the Presidential Orders for each unit of appointment the reserved and
unreserved ratio as per G.O.Ms.No 124 GAD (SPF-MC) Dept., Dt 30.08.2018, for each
category will be applicable.
Sl.No
Category
Unit of appointment
1
STLS ( Senior TB laboratory
District
Supervisor)
Zonal post (Zone –I)
2
Lab Technician Gr. II

<!-- page 3 -->

P.T.O
FEES DETAILS:
Sl.No
Category
1.
STLS ( Senior TB laboratory
Supervisor)
2
Lab Technician Gr.II

Amount
300=00
300=00

Application/ Registration Fees are exempted for the SC & ST candidates.
Self Attested copies of the following certificated should be enclosed along with the
Application Form:
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.

S.S.C / Dated of Birth Certificate issued by the Competent Authority of the Government
for proof of age.
Intermediate or 10+2 examination
Qualifying Examination Pass certificate
Marks Memos of all the years ( Qualifying examination)
Registration Certificates of respective Councils
Latest Community Certificates/EWC Certificate/Ex- Servicemen/ NCC/physically
handicapped, whichever is applicable issued by the Competent Authority.
Study certificate for the year from 4th class to 10th class and in case of Private Study
residence certificate from the Tahsidhar /MRO Concerned to be submitted.
PH Certificate in respect of candidates claiming reservation under PH Quota
Relevant certificates in respect of candidates claiming Ex- service Men Quota
Registration Certificate from the concerned Medical Council/ Nursing Council/ Para
Medical board/ Other relevant authority.
1 Photograph duly pated on the application form.

S/dDistrict Medical & Health Officer,
Kumuram Bheem Asifabad District

S/dDistrict Collector
Kumuram Bheem Asifabad District

<!-- page 4 -->

Annexure-I

SENIOR TUBERCULOSIS LABORATORY SUPERVISOR(STLS)

Qualification
1. Graduate or
Diploma in
Medical
Laboratory
Technology or
equivalent
from a
Governmentrecognized
institution.

2. Permanent
two-wheeler
driving licence
and should be
able to drive a
two-wheeler.

3. Certificate
course in
computer
operations
(minimum two
months).
Experience:-Minimum one
year of
experience in
NTEP.

Duties & Responsibilities
1. Will be responsible for smooth functioning of laboratory services,
quality of sputum microscopy, NAAT and for sample collection and
transportation as per programme guidelines.
2. Organize smear examination at the microscopy centres of the
sub-district.
3. Organize regular training and continuing education of the
laboratory technicians.
4. Supervise all microscopy centres and NAAT facilities at least
once a month.
5. To support establishment of specimen collection centres and
establish sample transport network.
6. Promote microbiological testing for diagnosis of TB.
7. Check the record-keeping pertaining to sputum microscopy
services and NAAT.
8. Ensure proper disposal of contaminated laboratory material in
designated microscopy centres and NAAT facilities.
9. Ensure availability of consumables and reagents in microscopy
centres and NAAT facilities.
10. Implementation of all components of NTEP Laboratory Quality
Assurance for sputum microscopy and NAAT.
11. Enlist private laboratories, register them in NIKSHAY, visit these
laboratories and engage them for notification of TB patients.
12. Coordinate with private laboratories for free diagnostic services
to TB patients in the private sector and ensure quality assurance
in private laboratories.
13. Coordinate with STS to ensure that all TB patients diagnosed are
initiated on treatment and followed as per programme guidelines.
14. Co-ordinate with STS and Senior DR-TB TB-HIV Supervisor in
updating relevant NTEP records of DR-TB patients.
15. Ensure that sputum specimens of eligible patients are sent to
NAAT/Culture/DST Laboratories as per NTEP guidelines.
16. Ensure real-time NIKSHAY enrolment for presumptive TB,
presumptive DR-TB and other diagnostic and follow-up test
details.

<!-- page 5 -->

P.T.O

Annexure -II

Qualification &
Experience
1. Intermediate
(10+2) and
Diploma or
certified course
in Medical
Laboratory
Technology or
equivalent.
2. One year
experience in
NTEP or Sputum
smear
microscopy
3. Candidates with
Higher
qualification (for
example
Graduates) small
be preferred

LAB TECHNICIAN/ SPUTUM MICROSCOPIST.
JOB Specifications/Responsibilities.
1. Follow the standard operating procedures for sample collection,
sputum smear microscopy and NAAT.
2. Maintain the Laboratory Register and immediately submit the
results to the Medical Officer managing the patient and update
it in real-time in Nikshay.
3. Coordinate with other staff to ensure that presumptive TB
patients and symptomatic contacts of TB patients receive
sputum container, necessary instructions, undergo sputum
examination / NAAT.
4. Assist the MO-PHI in identification of presumptive DR-TB
patient and ensure collection and transportation of sputum
specimens for NAAT / Culture and DST as per guidelines.
5. Organize and supervise the disposal practices of contaminated
lab material as detailed in the Laboratory Manual.
6. Assist STLS in implementation of NTEP Lab Quality Assurance.
7. Assist in implementation of new TB Diagnostic Tools in NTEP.
8. To facilitate change management with respect to use of ICT &
NIKSHAY tools for concerned data entry, validation & its use
for public health action.
9. Any other job assigned by the reporting officer
