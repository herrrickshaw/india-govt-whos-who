---
doc_id: "bab04dc22edc61e6"
source_url: "https://www.ruraluniv.ac.in/files/includes/academics/faculties/dept/11/pdf/GONo102_16062026.pdf"
ministry: "The Gandhigram Rural Institute (Deemed to be University), Telangana"
title: "G.O.(Ms). No. 102 Dated: 16.06.2026"
date: ""
pages: 7
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "d517428f678ea820"
---

<!-- page 1 -->

నా
యు
q y
ABSTRACT
Public Services - Equivalence of Degrees — Equivalence of Degrees offered by various
Universities / Educational Institutions to the similar Degrees - Recommendations of 42°
Equivalence Committee - Approved —Orders—Issued.
HIGHER EDUCATION (J1) DEPARTMENT
G.0.(Ms).No.102 Dated: 16.06.2026
ఆన్‌ ౮౮౫౦౮౦ CUCL. Spoof] - 2
a SlapouciroHoutt త్వయా. 2057
Read:
1. 6.0. (Ms) No.93, Higher Education (K2) Department.
Dated 30.05.2019.
2. G.O.(Ms).No. 33, Higher Education (K1) Department,
Dated 15.02.2021.
3. G.O.(Ms).No. 111, Higher Education (K1) Department,
Dated 24.06.2024.
4. From the Member-Secretary [FAC], Tamil Nadu State
Council for Higher Education, Letter No. Rc.No.
1356/2026 A, Dated 15.06.2026.
ORDER:-
- In the letter fourth read above, the Member Secretary [FAC], Tamil Nadu State
a Council for Higher Education, has forwarded the resolutions passed in the 42
Equivalence Committee meeting held on 10.06.2026 under the Chairmanship of the
Secretary to Government, Higher Education Department, on the Equivalence of
Degrees offered by various Universities / Educational Institutions to the similar Degrees
for the purpose of employment in Public Services.
2. The Government, after careful consideration, approve the following
resolutions passed in the 42" Equivalence Committee meeting held on 10.06.2026,
under the Chairmanship of the Secretary to Government, Higher Education Department
and direct that the following degrees offered by various Universities / Educational
Institutions be equivalent to the similar degrees mentioned therein from the date of
issuance of such degrees:-
2

<!-- page 2 -->

os
Equivalence |
Si 1 Subjects Committee |
No No. i
| Recommendations
Public Services - Educational Qualification -
Consideration of B.Com., Actuarial Management |
1. 1. | offered by Dr.G.R. Damodaran College of Science |
| | | (Autonomous) affiliated to Bharathiar University as Equivalent |
| | | to whether Equivalent to B.Com., for the purpose of
| | | Employment in Public Services
| | Public Services - Educational Qualification —
| Consideration of M.Sc., Life Sciences (5 year |
| 2 14. Integrated) awarded by Central University of Tamil S )
| Nadu as to whether equivalent to M.Sc., Zoology Equivalent
I for the purpose of employment in Public Services
| Public Services - Educational Qualification —
| Consideration of M.Sc., Animal Biotechnology
| 3 17 awarded by Bharathidasan University as to whether
ఇ క equivalent to M.Sc., Zoology for the purpose of Equivalent
| employment in Public Services
| | Public Services - Educational Qualification —
| Consideration of M.Sc., Advanced Biochemistry |
4 18 awarded by University of Madras as to whether |
testis equivalent to M.Sc., Biochemistry for the purpose of Equivalent
| employment in Public Services
| |
| Public Services - Educational Qualification —
Consideration of B.Sc., Chemistry (Main)
Mathematics and Physics (Subsidiaries) awarded a |
| 5. 23 by University of Kerala as to whether equivalent to Equivalent వ్ర |
B.Sc., Chemistry for the purpose of employment in |
Public Services
Public Services - Educational Qualification —
Consideration of B.Sc., Chemistry and Physics |
awarded by Avinashilingam Institute for Home |
6 Science and Higher Education for Women : | .
(Deemed University) as to whether equivalent to Equivalent | |
| B.Sc., Chemistry for the purpose of employment in
| Public Services | |

<!-- page 3 -->

-3-

| a Services - Educational Qualification —
Consideration of B.Sc., Hotel Management and |

| 7 | 29 Catering Science awarded by Periyar University as

| | to whether equivalent to B.Sc., Hotel & Catering Equivalent

| | Management for the purpose of employment in

గం rece |
Public Services - Educational Qualification —
| Consideration of B.Sc., Hotel Management and
| Catering Science awarded by Bharathidasan

| 8. 30 | University 25-10 whether equivalent to B.Sc., Hotel Equivalent

| & Catering Management for the purpose of
employment in Public Services

త | Public Services - Educational Qualification — |

| Consideration of B.Sc., Catering Science and Hotel

| Management awarded by Bharathiar University as _

9. | 31. (0 whether equivalent to B.Sc., Hotel & Catering | Equivalent
Management for the purpose of employment in,
Public Services |

| Public Services - Educational Qualification - |

| | Consideration of B.Sc., Mathematics (Subject: |

| Accountancy) awarded by University of Madras as |

10 32. to whether equivalent to Accountancy Senior Grade |
Examination awarded by Directorate of Technical Equivalent
Education for the purpose of employment in Public

| Services

| Public Services - Educational Qualification -

| | Consideration of M.Tech., Environmental Science &

| | Technology awarded by National Institute 01 |

స fee Technology, Durgapur as to whether equivalent to | Equivalent
గ్‌. | M.E., Environmental Engineering for the purpose of
employment in Public Services |
|

i Public Services — Educational Qualification - | i _

| Consideration of PG Diploma in Sanitary Inspector

| Course offered by Water Sanitation and Hygiene |

| Institute, Kodaikanal affiliated to Madurai Kamara}

j 12. University as to whether equivalent to Multipurpose |
Health Worker (Male) Training 1 year Course | Equivalent
offered by Director of Public Health and Preventive
Medicine for the purpose of employment in Public
Services

4

<!-- page 4 -->

-4-
[7 | Public Services — Educational Qualification -
| | Consideration of Diploma in Polymer Technology
| awarded by State Board of Technical Education,
levee 41. | Kerala as to whether equivalent to Diploma in Equivalent
| | Plastic Technology for the purpose of employment
| | in Public Services
| Public Services - Educational Qualification
| Consideration of B.A, (Economics, Public
| Administration, Telugu Literature) awarded by |
) 14. ఉగ Dr.B.R. Ambedkar Open University, Hyderabad as
to whether equivalent to BA. Telugu for the Equivalent
purpose of employment in Public Services | ®
| | Public Services - Educational Qualification
| | Consideration of B.A., (Political Science, Public
| | Administration, Telugu Literature) awarded by
15 | 45. Dr.B.R.Ambedkar Open University, Hyderabad Equivalent
as to whether equivalent to B.A. Telugu for the
| purpose of employment in Public Services
Public Services - Educational Qualification -
' Consideration of B.Sc., B.Ed., (Chemistry, Botany
| and Zoology) awarded by Vels Institute of Science,
16. 46. Technology and Advanced Studies (VISTAS) :
| (Deemed to be University) as to whether equivalent Equivalent
| to B.Ed., Zoology for the purpose of employment in
| Public Services
| Public Services - Educational Qualification -
| Consideration of B.Sc., B.Ed., (Chemistry, Botany
| and Zoology) awarded by Vels Institute of Science,
{ 17 | 47. Technology and Advanced Studies (VISTAS) a
| (Deemed to be University), as to whether | Equivalent »)
| equivalent to B.Ed. Botany for the purpose of |
| | employment in Public Services
| Public Services - Educational Qualification -
Consideration of B.Sc., B.Ed., (Chemistry, Botany |
and Zoology) awarded by Vels Institute of Science,
18. 48 Technology and Advanced Studies (VISTAS)
(Deemed to be University) as to whether equivalent Equivalent
to B.Ed., Chemistry for the purpose of employment
in Public Services

<!-- page 5 -->

-5-
Public Services - Educational Qualification -| 7 7

Consideration of B.Sc., B.Ed., (Physics, Chemistry |

| ene Mathematics) awarded by Vels Institute of |

19 49. Science, Technology and Advanced Studies |
(VISTAS) (Deemed to be University) as to whether | Equivalent

equivalent to B.Ed., Mathematics for the purpose of |

| employment in Public Services |

| | Public Services - Educational Qualification - |

| Consideration of B.Sc., B.Ed., (Physics, Chemistry |

and Mathematics) awarded by Vels Institute of |

20. 50. | Science, Technology and Advanced Studies |
(VISTAS) (Deemed to be University), as to whether Equivalent

టి | equivalent to B.Ed., Chemistry for the purpose of |

employment in Public Services

Public Services - Educational Qualification - |

| Consideration of B.Ed., Integrated Programme

| 21 51 awarded by The Gandhigram Rural Institute
i | (Deemed to be University) as to whether equivalent Equivalent

| to BEd. except Hindi for the purpose of |

[ employment in Public Services |

| Public Services - Educational Qualification -

| Consideration of B.Ed., (English, Mathematics)
| 22. 52 awarded by Bangalore University as to whether ౬ ica
| equivalent to B.Ed., Mathematics for the purpose of క క

| | employment in Public Services |

| | | Public Services - Educational Qualification - |

| | Consideration of B.Ed., (a) Mathematics (b) |

' 93 | 53 | English awarded by Sri Venkateswara University, |
| ల Tirupati as to whether equivalent to B.Ed., | Equivalent

| | | Mathematics for the purpose of employment in |

6 | | Public Services |

| | Public Services - Educational Qualification

| | | Consideration of M.Sc. Organic Chemistry
24. | 58. | awarded by Bharathiar University as to whether Equivalent

| equivalent to M.Sc., Chemistry for the purpose of |

| employment in public services |

i | Public Services - Educational Qualification —

| | Consideration of B.E., Agricultural and Irrigation

1 25 59 | Engineering (R-2004 & R-2008) awarded by Anna
స ~ | University as to whether equivalent to 6.౬. Equivalent

| Agriculture Engineering for the purpose of |

| employment in Public Services to
al)

<!-- page 6 -->

-6-
Ee
Public Services - Educational Qualification -
Consideration of B.Tech., Textile Technology |
(Fashion Technology) offered by Bannari Amman |
26 60 Institute of Technology, (Autonomous) Erode i
: | Affiliated to Anna University as to whether Equivalent
| equivalent to B.Tech., Fashion Technology for the
| purpose of employment in Public Services
(BY ORDER OF THE GOVERNOR)
V. ARUN ROY
SECRETARY TO GOVERNMENT »
| To
The Vice-Chancellor, University of Madras, Chennai - 5.
The Vice-Chancellor, Anna University, Chennai - 25.
The Vice-Chancellor, Annamalai University, Annamalai Nagar — 608 002.
| The Vice-Chairman, Tamil Nadu State Council for Higher Education, Chennai — 5:
The Member-Secretary, Tamil Nadu State Council for Higher Education, Chennai - 5
The Registrars of all Universities under the aegis of Higher Education Department.
The Director of Technical Education, Chennai - 25.
| The Commissioner of Collegiate Education, Chennai - 15.
| The Chairman, Teachers Recruitment Board, Chennai - 6
1 The Secretary, Tamil Nadu Public Service Commission, Chennai - 3.
The Registrar, Central University of Tamil Nadu, Neelakudi, Kangalancherry (Post),
Thiruvarur — 610 005.
The Registrar, University of Kerala, Senate House Campus, Palayam,
Thiruvananthapuram, Kerala - 695034, India.
The Registrar, Avinashilingam Institute for Home Science and Higher Education for )
Women, Bharathi Park Road, Coimbatore-641 043.
The Registrar, National Institute of Technology Durgapur, Mahatma Gandhi Avenue,
Durgapur, West Bengal, India PIN - 713209.
The Chairman, State Board of Technical Education (SBTE) Kerala, Directorate of
Technical Education (DTE), Padmavilasom Road, Fort P.O., Thiruvananthapuram,
Kerala - 695023.
| The Registrar, Dr. B.R. Ambedkar Open University (BRAOU), Prof. G. Ram Reddy
Marg, Road No. 46, Jubilee Hills, Hyderabad, Telangana - 500033.
The Registrar, Vels Institute of Science, Technology & Advanced Studies
(VISTAS), Velan Nagar, P.V. Vaithiyalingam Road, Pallavaram, Chennai - 600 117.
The Registrar, The Gandhigram Rural Institute (Deemed to be University), Gandhigram,
Dindigul - 624 302.
| 7
|
|

<!-- page 7 -->

7.

The Registrar, Bangalore University, Mysore Road. Jnana Bharathi, Bengaluru.
Karnataka 560056

The Registrar, Sri Venkateswara University, Tirupati, Andhra Pradesh 517502

Copy to:-

The Special Personal Assistant to Hon'ble Minister (Higher Education), Chennai - 9

The Private Secretary to Secretary to Government, Higher Education Department.
Chennai - 9.

The Private Secretary to Additional Chief Secretary to Government, School Education
Department, Chennai - 9.

The Private Secretary to Principal Secretary to Government, Human Resources

a Management Department, Chennai -9.
Stock file / Spare copy.
(Clean Copy to File No efile. 1615/J1/2026)
/ FORWARDED BY ORDER //
& : ల్గ్‌ గ్ర G
ధం
SECTION OFFICER
Ww
@
