---
doc_id: "dbb367feb3d8adc4"
source_url: "https://cdn.s3waas.gov.in/s31c383cd30b7c298ab50293adfecb7b18/uploads/2025/10/17607667276486.pdf"
ministry: "Khammam"
title: "1) Notification E-Tenders for 5 civil works at Jamalapuram Eco Tourism park-click here"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "961a1706217dd83f"
---

<!-- page 1 -->

GOVERNMENT OF TELANGANA
FOREST DEPARTMENT
From:
Sri Siddharth Vikram Singh, IFS,
District Forest Officer,
Khammam District.

To,
The Collector &
District Magistrate,
Khammam.

Rc.No. 1494/2025/A3, Dt: 17.10.2025
Sir,
Sub:-

TGFD- Khammam District- Works- E-tenders called for the construction
of Watch Tower, Entrance gate, Viewing deck, Brick wall & Canteen at at
Jamalapuram Forest park, Madhira Range of Khammam Forest Division
of Khammam District during 2025-26 under Afforestation Fund scheme Request for publishing in Khammam District Official website
(https://khammam.telangana.gov.in/) – Report submitted- Reg.

Ref:-

1. CSO No.43/2025-26, dt. 08.09.2025 (for the work of Watch tower)
2. CSO No.44/2025-26, dt. 08.09.2025 (for the work of Entrance gate)
3. CSO No.45/2025-26, dt. 08.09.2025 (for the work of Viewing Deck)
4. CSO No.46/2025-26, dt. 08.09.2025 (for the work of Brick wall)
5. CSO No.47/2025-26, dt. 08.09.2025 (for the work of Canteen)
6. e-tenders called for (5) civil works from 18.10.2025 to 06.11.2025(1st call)
<><><>

It is submitted that, e-tenders were called for (5) Civil works i.e., Construction
of Watch Tower, Entrance gate, Viewing deck, Brick wall & Canteen at Jamalapuram
Forest park, Madhira Range of Khammam Forest Division of Khammam District during
2025-26 under Afforestation Fund scheme, as per the estimates sanctioned by Chief
Conservator of Forests, Bhadradri Circle, Warangal vide reference 1st to 5th cited. The
details are as follows.
Sl.
No
1.

2.

3.

4.

Name of the Work

SO order
details

Amount
Sanctioned
(in Rs)

Tender details

Construction of Watch tower
Rs.
at Jamalapuram Forest Park
16,18,000/CSO No.
in Madhira Range, Khammam
43/2025-26,
Division
of
Khammam
Dt.08.09.2025
District
during
2025-26
under Afforestation Fund
Scheme.

ECV : Rs. 13,48,498/-

Construction of Entrance
Rs.
gate at Jamalapuram Forest
18,63,000/CSO No.
Park in Madhira Range,
44/2025-26,
Khammam
Division
of
Khammam District during Dt.08.09.2025
2025-26 under Afforestation
Fund Scheme
Construction
of
Viewing
Rs.
Deck at Jamalapuram Forest
12,17,000/CSO No.
Park in Madhira Range,
Khammam
Division
of 45/2025-26,
Khammam District during Dt.08.09.2025
2025-26 under Afforestation
Fund Scheme
Construction of Brick wall at
Rs.
Jamalapuram Forest Park in
13,99,000/CSO No.
Madhira Range, Khammam
Division
of
Khammam 46/2025-26,
District
during
2025-26 Dt.08.09.2025
under Afforestation Fund
Scheme

Tender Id : 637047
Tender Opening: 18/10/2025
10:00 AM
Tender Closing: 06/11/2025
04:00 PM
ECV : Rs. 15,52,519/Tender Id : 637091
Tender Opening: 18/10/2025
10:00 AM
Tender Closing: 06/11/2025
04:00 PM
ECV : Rs. 10,14,521/Tender Id : 637101
Tender Opening: 18/10/2025
10:00 AM
Tender Closing: 06/11/2025
04:00 PM
ECV : Rs. 11,65,575/Tender Id : 637120
Tender Opening: 18/10/2025
10:00 AM
Tender Closing: 06/11/2025
04:00 PM

<!-- page 2 -->

5.

Construction of Canteen at
Rs.
Jamalapuram Forest Park in
18,31,000/CSO No.
Madhira Range, Khammam
Division
of
Khammam 47/2025-26,
District
during
2025-26 Dt.08.09.2025
under Afforestation Fund
Scheme.

ECV : Rs. 15,26,237/Tender Id : 637135
Tender Opening: 18/10/2025
10:00 AM
Tender Closing: 06/11/2025
04:00 PM

In this regard, it is requested the District Collector, Khammam to kindly issue
necessary instructions to the concerned staff for displaying the above e-tenders in Official
website of Khammam District (https://khammam.telangana.gov.in/) for wide publicity, so
that the bidders can participate in execution of development works at Jamalapuram Forest
park, Madhira Range of Khammam Forest Division of Khammam District. The related
tender documents are submitted herewith (through email) for kind information.
This is submitted for kind information and necessary action.
Encl: A/a.
Yours faithfully,
Sd/-.,
District Forest Officer,
KHAMMAM
Copy submitted to the Chief Conservator of Forests, Bhadradri Circle, Warangal for favour
of kind information.
Copy to the Forest Divisional Officer, Khammam for information and necessary action.
Sd/-.,
District Forest Officer,
KHAMMAM
// t.c.b.o //
Administrative Officer
