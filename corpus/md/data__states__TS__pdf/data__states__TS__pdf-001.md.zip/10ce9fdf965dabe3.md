---
doc_id: "10ce9fdf965dabe3"
source_url: "https://cdn.s3waas.gov.in/s38f14e45fceea167a5a36dedd4bea2543/uploads/2024/02/2024022963.pdf"
ministry: "Rajanna Sircilla"
title: "Guidelines for Old age home (728 KB)"
date: ""
pages: 19
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "424089f9212181a6"
---

<!-- page 1 -->

(Annexure to Govt. Circular. Memo.No.1314/Prog.II(1)/2022, Dt. 25-10-2022)
GUIDELINES FOR ESTABLISHMENT OF OLD AGE HOMES UNDER CO-MANAGEMENT APPROACH
1. BACKGROUND
Government of India has enacted the Maintenance and Welfare of Parents & Senior Citizens Act,
2007 in which a provision was made under section 19(1) to establish and maintain such number of Old
Age Homes at Accessible places as it may deem necessary in a phased manner beginning with at least
one in each phased manner beginning with at least one in each district to accommodate in such homes a
minimum of 150 senior citizens who are indigent.
Further as per the section 19(2) under Maintenance and Welfare of Parents & Senior Citizens Act,
2007, the State Government may prescribe a scheme for management of Old Age Home including the
standards and various types of services to be provided by them which are necessary for safety, wellbeing, medical care and means of entertainment to the inhabitants of such homes. There are about
32,69,579 number of senior citizens living in Telangana as per 2011 census. The Senior Citizens who are
in need of help and assistance, safety, protection, food and medical care are living in the state for whom
the Government is under obligation to provide such required need. There are certain non-government
organizations running the Old Age Homes and providing food, medical care and shelter besides other
facilities either with the support of Government fund or their own but there is still a lot of unmet need
senior citizens. Hence, this proposal is made to establish Old Age Homes in the districts by the
Government in collaboration with a reputed NGOs who are working for the cause of welfare of Senior
Citizens or otherwise by way of Co-management system.
2. PREAMBLE
Government of India has made a provision in Maintenance and Welfare of Parents & Senior Citizens
Act, 2007 for establishment and maintenance of Old Age Homes for the senior citizens who are indigent,
in all the districts. The very purpose of establishing the Old Age Homes in to provide various types of
services which are necessary for safe, healthy, happy & active ageing of the senior citizens.
3. OBJECTIVES OF ESTABLISHMENT OF OLD AGE HOMES UNDER CO-MANAGEMENT APPROACH
a. The very objective of setting up of Old Age Homes under co-management approach is to involve
both the government functionaries and NGOs to collectively deliver the services required for the
indigent senior citizens.
b. The Government provides financial support to an NGO to maintain the Old Age Home for the
Indigent senior Citizens under joint management system by which both the government
functionaries and the NGOs work together in providing all required needs to the indigent senior
citizens who are kept in the old Age Homes. The partner NGOs need to add certain percentage
of funds from their own resources in addition to the government share of financial support.
c. The Old Age Homes under Co-management approach ensures suitable accommodation in
suitable secured premises with proper protection with basic facilities, physiotherapy, periodic
medical checkups amenities with hygienic and sanitary conditions in entire premises.

<!-- page 2 -->

d. These homes provide recreational activities on regular basis and provide counseling wherever
required.
e. These homes ensure supply of age prescribed nutritious and wholesome diet besides providing
adequate clothing.
f. Executing various skill development initiatives for vocational training for physically and mentally
abled inmates and any other initiatives necessary for healthy & happy ageing.
g. These Old Age Homes shall ensure that the rights and entitlements of senior citizens under
various schemes/statutory provisions are availed & protected in all times.
4. FUNCTIUONS OF THE OLD AGE HOME UNDER CO-MANAGEMENT APPROACH
The Old Age Homes set up with the partnership of both the Government and NGO under comanagement approach shall have to perform the following functions:
a. Preparing micro plans for efficient functioning of the Old Age Homes including budget
management, personnel management, medical facility management, diet management,
recreation and well-being of inmate in all aspects.
b. Establishing and maintaining safety and security protocols for the Old Age Home.
c. Establishing, maintaining, and monitoring discipline, daily routine, task rotation, counseling,
physiotherapy, and health check-up for the inmate.
d. Preparing Individual Care Plans & Individual History Records for inmates and ensuring activities
as per the plan.
e. Arrangements with the nearest Government hospital for emergency medical care and with the
nearest Police Station for security requirements.
f. Executing various skill development initiatives for vocational training for the physically and
mentally abled inmates.
g. All inmates on admission shall be issued identity Cards containing the individual’s photo and
other personal details including Aadhar Number.
h. Taking up various initiatives necessary for healthy & happy ageing.
i. Shall make efforts to locate the family/relatives of the inmate who got admitted by rescue
process.
5. ELIGIBILITY CRITERIA FOR ADMISSION INTO HOMES
a. Only indigent men or women of age 60 years and above who shall ordinarily belong to the State
of Telangana, are eligible for admission into the Home. There can be exceptions to age up to 50
years & nativity with prior approval of the Assistant Director, WD & SC, Hyderabad/District
Welfare Officer and the reasons need to be recorded in writing.
b. An indigent person is a person who is not having anyone to take care of them.
c. Any senior citizen who is temporarily deserted by his family members and who has applied for
grant of maintenance on valid grounds under the Maintenance Act, may be given admission in
the Home till the maintenance relief is granted, or his/her application before the tribunal is
disposed, subject to the condition that the Assistant Director, WD & SC, Hyderabd/District
Welfare Officer is fully convinced with the information regarding his/her application before the
Tribunal.

<!-- page 3 -->

d. Assistant Director, WD & SC, Hyderabad/District Welfare Officer, WCD & SC Dept., of all the
districts, shall keep available sufficient number of applications to be supplied free of cost. The
application shall be supported by necessary documents. Only those applicants who satisfy the
eligibility criteria shall be considered for admission.
6. CONSTITUTION OF DISTRICT LEVEL COMMITTEE FOR SELECTION OF NGO AS A PARTNER IN COMANAGEMENT
The District Committee of senior citizens (as per Rule 23 of the state MWPSC Rules, 2011) shall acts
as Selection Committee for the selection of NGO duly adhering to the guidelines, which were issued
by the Government of India/State Government, and fulfilling the eligibility norms laid in rule 19 of
The Maintenance and Welfare of Parents and Senior Citizens Rules,2011.
The above Committee shall call proposals for Maintenance of Old Age Homes under comanagement approach by giving following priority:
1. Red Cross Society of the Concerned District.
2. In the absence of Red Cross Society in concerned District or Red Cross Society is not
active/unable/not interested to maintain Old Age Homes, due to various reasons, the
concerned District Collector shall invite proposals/applications from the eligible NGOs
running old age homes through notification for sanction of financial assistance for
maintenance of Old Age Home under co-management approach and select the best NGOs
who had been running the old age home for the past three years and have good track
record in maintenance of Old Age Homes and not receiving funds either from State
Government or Central Government or Other Agencies for the same purpose. The reputed
and registered NGO extending exemplary services for the welfare of the senior citizens may
also be considered in the districts where the Old Age Homes are not in existence. Newly
started NGOs may be selected in exceptional cases.
Wherever possible, the District Collectors o fall the districts in Telangana (except in the districts
where the Government has released fund for construction of buildings for Old Age Homes) shall
identify a suitable vacant government building under his/her jurisdiction and with minimum
renovation cost shall take necessary steps for renovation for establishment of Old Age Home. If
suitable government buildings are not available, a suitable building may be taken on rent. The
District Collector shall forward a proposal with detailed cost estimate needed for minimum
renovation of identified vacant government building or rented building to the Director, WD & SC
for release of funds.
The Districts which have received funds for construction of building for Old Age Home shall
mandatorily forward the proposal for maintenance of Old Age Homes under co-management
approach adhering to the above norms.
The aforesaid Committee shall forward the proposals to The Director, Welfare of Disabled and
Senior Citizens, Telangana, recommending the Red Cross Society(RCS)/NGO as partner under comanagement approach for maintaining Old Age Home and for sanction of grant-in-aid.

<!-- page 4 -->

7. SELECTION OF NGO AS A PARTNER IN CO-MANAGEMENT APPROACH FOR LOD AGE HOME(S)
The selected NGO will be eligible to become a partner in the Old Age Home(s) in the CoManagement approach. After awarding the selection of the NGO partner, an MOU shall be signed by
the person authorized by the Govt. (Assistant Director, WD & SC, Hyderabad/District Welfare
Officer, WCD & SC) and a representative from the partner NGO selected prior to commencement of
the Old Age Home(s) fixing time limit for maintaining the Old Age Home. The term of the MOU shall
be for 1 year. If any party commits any breach or default of the terms or conditions provided in the
MOU and such breach is not rectified within a period of thirty (30) days from the date of written
notice by the non-defaulting party to rectify such default, the MOU shall stand terminated.
The NGO selected for the grant in a particular year cannot claim for assistance in the subsequent
years also s a matter of right. Eligibility of NGOs to receive grant in aid depends upon their
performance and the availability of budget in a particular financial year.
8. MAINTENANCE OF ACCOUNTS
A joint account shall be opened authorizing the two joint signatories i.e. one from Government side at
district level i.e., District Welfare Officer/Assistant Director and one from concerned NGO to operate the
bank transactions relating to maintenance of the Old Age Homes. For withdrawal of funds, permission of
the competent authority i.e., District Collector at district level shall be obtained as recorded in the MOU.
The Director, WD & SC Dept., Hyderabad will formulate a uniform draft MOU proforma. In order to
follow the uniform procedure in the state, the Draft MOU is communicated along with the guidelines to
all the District Welfare Officers/Assistant Director, Hyderabad with a request to take necessary action
accordingly.
9. FINANCIAL SUPPORT BY WAY OF GRANT
The Old Age Homes established under co-management approach shall be funded by the Government by
way of grant to run and maintain the Old Age Homes with not less than 25 inmates in each old age
home.
After receipt of proposals with due recommendations from the District Level Committee, the Director
WD & SC, shall release the funds to the joint account of Old Age Home, subject to the availability of
funds, during that financial year.
The selected NGO will be provided Grant in aid from the State Government for maintenance of old age
home under co-management approach and the NGO shall bear of the expenditure (as per below
statement) as per the budget provided in point 13 & 14. However, after completion of process of MOU,
the NGO should deposit their share in the joint account every quarter and only after that government’s
share of funds will be released. The selected NGOs should also apply to Ministry of Social Justice &
Empowerment (MoSJE), Government of India (GoI) for maintenance of old age homes every year by
following all the relevant guidelines issued by GoI. Only the NGOs which could not get grants from GoI

<!-- page 5 -->

for maintenance of old age homes for reasons beyond their control will be eligible for funds by the state
government for that particular year.
STATEMENT SHOWING THE FINANCIAL SUPPORT BY WAY OF GRANT IN AID BY THE DIRECTOR, WD &
SC, HYDERABAD
S.No.
1
2

Particulars
25-Bedded OAH
50-Bedded OAH

Govt share
70%
75%

NGO share
30%
25%

Remarks

Budget for the first quarter shall be released in advance. Budget for the non-recurring expenditure will
be released as per the necessity. From the 2nd quarter, the budget shall be released to the selected
NGOs on quarterly basis based on the submission of expenditure particulars (audited statement of
expenditure) and utilization certificate signed by authorized signatory of the NGO and District Welfare
Officer/Asst Director along with Statutory Auditor. Budget for next quarter should be released within 15
days of receiving the above 2 documents if they are in proper format to enable smooth functioning. If
there is any lacunae, the concerned NGO should be informed about the same in writing.
10. STAFF REQUIRED FOR MAINTAING THE OLD AGE HOME WITH INTAKE CAPACITY OF 25 (13
FEMALE & 12 MALE) INMATES
S.No.
Designation
No.of
Remarks
posts
1
Home Coordinator
1
Full time
2
Doctor
1
On visit basis (at least 2 visits
per week)
3
Social worker cum Asst. Home 1
Full time
Coordinator
4
Nurse
1
On visit basis (2 hours per day
&
should
also
attend
emergency if any)
5
ANM
1
Full time
6
Accountant Cum Clerk
1
On visit basis (4-8 hours per
week)
7
Yoga Therapist
1
On visit basis (at least one hour
per day)
8
Cook
1
Full time
9
Multi-Tasking Staff
3
Full time
Total
11
11. STAFF REQUIRED FOR MAINTAINING THE OLD AGE HOME WITH INTAKECAPACITY OF 50 (25
FEMALE & 25 MALE) INMATES
S.No.
Designation
No.of
Remarks
posts
1
Home Coordinator
1
Full time

<!-- page 6 -->

2

Doctor

1

3
4

Social worker cum Asst. Home 1
Coordinator
Nurse
1

5
6

ANM
Accountant Cum Clerk

1
1

7

Yoga Therapist

1

8
9
10

Cook
Asst. Cook
Multi-Tasking Staff
Total

1
1
4
13

On visit basis (at least 2 visits
per week)
Full time
On visit basis (2 hours per day
&
should
also
attend
emergency if any)
Full time
On visit basis (4-8 hours per
week)
On visit basis (at least one hour
per day)
Full time
Full time
Full time

12. ELIGIBILITY CRITERIA FOR POSTS
S.No.
1

2

3

Designation
Home Coordinator

Eligibility Criteria
Minimum
Post-Graduation, Preferably in
Qualification
& Social work or Sociology. Not
Experience
less than two years working in
the
field
of
Senior
Citizens/Women’s/or
similar
homes.
Duties
Overall management of the
Home.
Doctor
Minimum
MBBS/BAMS/BHMS
Qualification
&
Experience
Duties
Doctor must visit the center at
least twice a week for health
check-up of all the beneficiaries.
The doctor is bound to attend
the beneficiaries in emergency.
As far as possible.
Doctor residing near the cener
should be engaged.
Social worker cum Minimum
Post-Graduation in Psychology
Asst.
Home Qualification
& or Social Work
Coordinator
Experience
Or
Diploma in Counselling Or
Degree with Diploma in
Counselling.
Not less than 2 years’
experience in relevant field.

<!-- page 7 -->

Duties

4

Nurse

Minimum
Qualification
Experience

Duties

5

ANM

Minimum
Qualification
Experience

Duties

6

Accountant

Minimum
Qualification
Experience

Duties

To assess the emotional status
of the residents and to render
counseling services as may be
required. Interacting with the
inmates and keeping efforts for
their reunions. Managing the
Home activities in the absence
of Home Coordinator.
BSC Nursing/GNM/JPHN Course
& Or
Retired hands from nursing
profession. Not less than two
years’ experience in Nursing
Homes, Hospitals, Palliative
Care Homes or Old Age Homes.
Nurse should visit the home for
a minimum of 2 hours per day
for 5 days in a week, for basic
medical check-up of the
residents and also to provide
nursing/basic geriatric care.
Should be qualified as Auxiliary
& Nurse Midwife (ANM) and
should have received training
from
recognized
government/private
medical
institution. Not less than two
years’ experience in relevant
field.
Monitoring the health status of
inmates as per guidance of
Doctor & Nurse. Providing
medicines on time prescribed by
the doctor. Maintaining the
medicines stock and medical
records of inmates.
Post& graduation/Graduation/Diploma
course in relevant subject.
Having the knowledge of
accounts
and
computer
operations.
Compilation
of
Accounts,
computerizing
collected
database
&
information,
maintaining records & files,
maintaining records of trainees,

<!-- page 8 -->

7

Yoga Therapist

8

Cook

Minimum
Qualification
Experience
Duties

Minimum
Qualification
Experience
Duties

9

Asst. Cook

Minimum
Qualification
Experience
Duties

10

Multi-Tasking
Staff(MTS)

Minimum
Qualification
Experience
Duties

resource persons, beneficiaries
and NGOs.
Diploma in Yoga from a
& recognized Institution
Yoga therapist should visist the
Centre at least three times in a
week for a minimum one hour
per day.
Should have passed 8th Standard
& and should have experience of
cooking local food for minimum
3 years.
Prepare the daily food for the
residents including Morning
Tea, Breakfast, Lunch Evening
Tea and Dinner.
Should have passed 8th Standard
& and should have experience of
cooking local food for minimum
3 years
Prepare the daily food for the
residents including Morning
Tea, Breakfast, Lunch, Evening
Tea and Dinner.
Should have passed 8th Standard
& and should have experience of
working for minimum 2 years in
similar capacity.
To
Perform
the
duties
Chowkidar, Helper, Cleaner.
Must clean all the rooms
veranda/courtyard and kitchen
at least 2 times a day, cleaning
of bathrooms and toilets at
least 3 times a day, and to
extend assistance as & when
required.

13. SANCTION OF BUDGET FOR MAINTENANCE OF OLD AGE HOME UNDER COMANAGEMENT APPROACH WITH INTAKE CAPACITY OF 25 (13 FEMALE & 12 MALE)
INMATES
S.No.
I

Designation

No.of
posts

Remarks

Recurring Expenditure total (a to d)

Monthly

Yearly

<!-- page 9 -->

(a)

X* Category

3335800.00

Y* Category

3287800.00

Z* Category

3251800.00

1

Staff Honorarium
Home
Coordinator

1

Full time

25000/-

300000.00

2

Doctor

1

On visit basis (at least 2
visits per week)

1000/-

104000.00

3

Social worker
cum Asst. Home
Coordinator

1

Full time

22750/-

273000.00

10000/22750/-

120000.00
273000.00

4
5

Nurse
ANM

1
1

On visit basis (2 hours per
day & should also attend
emergency if any)
Full time

6

Accountant
Cum Clerk

1

On visit basis (4-8 hours per
week)

4000/-

48000.00

7

Yoga Therapist

1

On visit basis (at least one
hour per day)

5000/-

60000.00

8

Cook
Multi-Tasking
Staff
Sub Total

1

Full time

15600/-

187200.00

3

Full time

15600/-

561600.00
1926800.00

9
Sl.No

Particulars

Amount

Inma
tes

Months

Total

(b)

i) Diet Charges @2000/- per inmate

2000

25

12

600000.00

ii) Cosme-soaps, comb, brush, paste,
shampoo, moistruizers, etc., )
@400/- per inmate
iii) Medicines @500/- per inmae

400
500

25
25

12
12

120000.00
150000.00

iv) Clothing (@3000/- per inmate.)
pairs- (for male-2 dhotis, 2 towels, 2
dresses, 3 inners & for female-3
sarees with blouse, 3 sarees
petticoat’s nighties, 2 towels, 3
inners) once in a year

3000

25

-

75000.00

v) Electricity, water, internet, etc.,

10000

-

12

120000.00

Sub-Total

1065000.00

<!-- page 10 -->

(c)

Miscellaneous & Unforeseen

( d)

Building Rent (or Maintenance @ 10% of rent in case of own building

Sl.No Particulars

80000.00

Category

Amount

Months

Total

Jurisdiction

X

22000

12

264000.00

ii)
Municipal corporations

Y

18000

12

216000.00

Z

16500

12

198000.00

i)

iii)

GHMC

Mandal

Head Quarters
Sub Total
Sl.No

678000.00

Particulars

Amount

Inmates

Total

II

Non-Recurring (a to c):

a)

Cot, Bed, Small Almirah, etc.

4000

25

100000.00

b)

Kitchen, utensils & equipment

-

-

40000.00

c)

TV & CC cameras

-

(a
to
Total

75000.00
215000.00

c)

Grand Total for
Non Recurring (II)

X*

category,

Recurring

(I)

+

3550800.00

Grand Total for
Non-Recurring (II)

Y*

Category,

Recurring

(I)

+

3502800.00

Grand Total for
Non-Recurring (II)

Z*

Category,

Recurring

(I)

+

3466800.00

NGO Share
30%

I)

Category
X* Category (GHMC Jurisdiction)

Governme
nt Share
70 %
2485560.00

1065240.00

II)

Y* Category (Municipal Corporations)

2451960.00

1050840.00

III)

Z* Category (Mandal Head Quarters)

2426760.00

1040040.00

14. SANCTION OF BUDGET FOR MAINTENANCE OF OLD AGE HOME UNDER
COMANAGEMENT APPROACH WITH INTAKE CAPACITY OF 25 (13 FEMALE & 12 MALE)
INMATES
S.No.
I

Designation

No.of
posts

Remarks

Monthly

Yearly

Recurring Expenditure total (a to d)
X* Category

4851200.

<!-- page 11 -->

00
4791200.
00
4731200.
00

Y* Category
Z* Category
(a)

Staff Honorarium

1

Home
Coordinator

1

Full time

(@25000/per month
X 12
months)

2

Doctor

1

On visit basis (at least 2 visits per
week)

1000/-

104000.0
0

3

Social worker
cum Asst. Home
Coordinator

273000.0
0

1

Full time

22750/-

10000/-

300000.0
0

4

Nurse

1

On visit basis (2 hours per day &
should also attend emergency if
any)

5

ANM

1

Full time

22750/-

120000.0
0
273000.0
0

6

Accountant
Cum Clerk

1

On visit basis (4-8 hours per
week)

4000/-

48000.00

7

Yoga Therapist

1

On visit basis (at least one hour
per day)

5000/-

8

Cook

1

Full time

15600/-

9

Asst. Cook
Multi-Tasking
Staff
Sub Total

1

Full time

15600/-

4

Full time

15600/-

Sl.No

Particulars

Amount

Inmates

Months

60000.00
187200.0
0
187200.0
0
748800.0
0
2301200
.00
Total

(b)

i) Diet Charges @2000/- per inmate

2000

50

12

1200000.
00

ii) Cosme-soaps, comb, brush, paste,
shampoo, moistruizers, etc., )
@400/- per inmate

400

50

12

iii) Medicines @500/- per inmae

500

50

12

10

240000.0
0
300000.0
0

<!-- page 12 -->

iv) Clothing (@3000/- per inmate.)
pairs- (for male-2 dhotis, 2 towels, 2
dresses, 3 inners & for female-3
sarees with blouse, 3 sarees
petticoat’s nighties, 2 towels, 3
inners) once in a year

3000

50

-

v) Electricity, water, internet, etc.,

15000

-

12

Sub-Total
(c)

Miscellaneous & Unforeseen

( d)

Building Rent (or Maintenance @ 10% of rent in case of own building

150000.0
0
180000.0
0
2070000
.00
120000.
00

Sl.No Particulars

Category

Amount

Months

i)

GHMC Jurisdiction

X

30000

12

Total
360000.0
0

ii)

Municipal corporations

Y

25000

12

300000.0
0

iii)

Mandal Head Quarters

Z

20000

12

Sub Total
Sl.No

Particulars

Amount

Inmates

240000.0
0
900000.
00
Total

II

Non-Recurring (a to c):

a)

Cot, Bed, Small Almirah, etc.

4000

50

200000.00

b)

Kitchen, utensils & equipment

-

-

50000.00

c)

TV & CC cameras

-

(a to c)
Total

75000.00
325000.00

Grand
Total
for
Non Recurring (II)

X*

category,

Recurring

(I)

+

5176200.00

Grand
Total
for
Non-Recurring (II)

Y*

Category,

Recurring

(I)

+

5116200.00

Grand
Total
for
Non-Recurring (II)

Z*

Category,

Recurring

(I)

+

5056200.00

I)

Category
X* Category (GHMC Jurisdiction)

Govern
ment
Share
70 %
388215
0.00

NGO Share
30%
1294050.00

<!-- page 13 -->

II)

Y* Category (Municipal Corporations)

III)

Z* Category (Mandal Head Quarters)

383715
0.00
379215
0.00

1279050.00
1264050.00

15. INFRASTRUCTURAL AND INSTITUTIONAL FACILITIES REQUIRED TO BE PROVIDED
1. For the home with 25 inmates in the Old Age Homes a minimum living area/carpet area of 3250
square feet including sleeping area and ancillary areas like kitchen, dining hall, recreation room etc.,
but excluding verandahs, corridors, stair case areas etc. Besides a space for separate sick room, first
aid, care givers accommodation rest room for nurses, visitors room, rooms for administrative use, 4
toilets & 4 bathrooms, necessary equipment for conducting skill development courses and
therapies, space for washing and drying of clothes. For the home with 50 inmates, space required
shall increase proportionately.
2. The Old age home should be barrier-free with provision of ramps and handrails, and where
necessary, lifts, etc.
3. Quality toilets with adequate water,
4. Lockers/storage facilities for inmates to keep their belongings,
5. Security facilities,
6. Plates, glasses and bed rolls/bed sheets for each inmate
7. Clean drinking water Separate facilities/accommodation
8. Separate facilities/accommodation for male & female inmates
9. Clothing, books, medicines, soap, oil, toothpaste/toilets, etc.,
10. Adequate lighting (electricity)
11. Phone facility
16. ROLES OF DIFFERENT COMMITTES SETUP FOR ESTABLISHMENT, MAINTENACE AND
MONITORING OF OLD AGE HOMES UNDER CO-MANAGEMENT APPROACH
1. Home management Committee
2. District Committee of Senior Citizens (Constituted under Rule 23 of the MWPSC Rules, 2011)
3. State Council of Senior Citizens (constituted under rule 22 of the MWPSC Rules, 2011).
1. Home Management Committee:

<!-- page 14 -->

The Home Management Committee shall have complete responsibility of the day-to-day
operations of the Home. The responsibilities include but are not limited to:









Preparing micro plans for efficient functioning of the Old Age Homes including budget
management, personnel management, medical facility management, and well-being of
inmate.
Establishing and maintaining safety and security protocols for the Old Age Home.
Establishing, maintaining, and monitoring discipline, daily routine, task rotation,
counseling, and health check-up for the inmate.
Preparing Individual Care plans & Individual History Records for inmates and ensuring
activities as per the plan.
Executing various skill development initiatives for vocational training for the physically
and mentally abled inmates.
Taking up various initiative necessary for health & happy ageing.
Shall make efforts to locate the family/relatives of the inmate who was admitted by
rescue process

Home Management Committee Composition:
a) Assistant Director, Welfare of Disabled & Senior Citizens, Hyderabad/District Welfare
Officer nominated as project in-charge or chief executive of the Home.
b) Home Coordinator (from the selected NGO) as OAH in charge.
c) Social Worker (from the selected NGO)
d) Doctor (from the selected NGO)
e) One senior citizen representing from District Committee for Senior Citizens (Constituted
under Rule 23 of the MWPSC Rules, 2011) to be nominated by the District Collector.
2. District Committee of Senior Citizens
The Committee would be responsible for overseeing the home committees and reviewing
the operations of the Old age homes on a regular basis. The responsibilities include but are
not limited to:
a. Evolution of functioning of the Old Age Homes in maintaining standards of care.
b. Review of the programs of the Homes, linkages and networking with other Government
and Non-Government agencies.
c. Proactive steps taken for indentifying the families for reunion of rescued elders.
d. Various skill development initiatives for vocational training for the inmate.
e. Review of Expenditure and release of the grants on a quarterly basis to the separate
bank account.
f. Ensuring rightful access to emergency care and any other entitlements from the
Government on time.
g. Taking up various initiatives necessary for healthy & happy ageing
h. The committee shall review the evaluation/inspection reports of Old Age Homes
inspected and prepared by the officer designated by the Government.

<!-- page 15 -->

3. State Council of Senior Citizens
The State Council of Senior Citizens is responsible for policy decisions, managing the overall
budget, and advising the District Committee on State-level decisions.

Monitoring
For effective monitoring of the Old Age Homes and their activities, the committees shall
meet regularly. The frequency and objective of the proposed meetings are mentioned
below.
Committee
State Council
Citizens

of

Frequency
Senior Half Yearly

District Committee of Senior Quarterly
Citizens

Objective
Update
on
budget,
entitlements, activities, policy
changes.
Review with District Old Age
Home(s),
acitivities,
inspection/evaluation reports,
linkages and coordination &
review of expenditure release
of grants.

Inspection /evaluation by Assistant Director, DW & SC, Hyderabad/District Welfare Officer
WCD & SC and CDPOs/supervisors in all districts:
The Assistant Director WD & SC , Hyderabad/ District Welfare Officer, WCD & SC of
concerned district either in Person or through concerned CDPOs/Supervisors respectively
shall make regular visits to the Home at least once in a month and shall record her/his
remarks in the visit register about the physical presence of inmates against on-roll
attendance, and also record the details of inspection/evaluation on status of OAH in the
prescribed format and Mobile Evaluation App (both Soft and Hard copy) and maintain the
same in their office, A copy of the inspection Report shall be submitted to the Concerned
District Collector & District Committee of Senior citizens at District Level and the director
WD & SC at State level.
17. ROLES OF BOTH GOVERNMENT AND NGO PARTNER UNDER CO- MANAGEMENT APPROACH
a. Role of the Government:
i. The proposed Homes may be given space by the government that is convenient, has a peaceful
atmosphere, and is accessible to senior citizen and accessible to all public services.

<!-- page 16 -->

ii. The NGO may propose a space owned/rented by them that is suitable for operating an Old Age Home
(as specified in point 14 in this guidelines) without any charges to the government. After careful
evaluation, the government may agree to the proposal.
iii. If the above 2 options are not readily available, rented accommodation may be acquired by the
Assistant Director, WD&SC, Hyderabad/District Welfare Officer concerned by following due procedure.
iv. The financial assistance shall be given to the selected NGO partner under co-management approach
for the maintenance of Old Age Home.
b. Role of the NGO partner:
I.

Provision of staff

II.

Trainings to Staff

III.

Health Care & Emotional Support facility

V

. Vocational Skills Training to physically & mentally able inmates.

VI.

Creation/Maintenance of Infrastructure facilities

VII.

The NGOs shall collaborate with the local Municipality/Municipal Corporation,Rural
Development Dept./Panchayath Raj Dept., Police Dept., Railway and Transport authorities/
departments, Health Department, UIDAI, Women, Children, Disabled & Senior Citizens Dept.,
like-minded
NGOs, State Council/District Committee for Senior Citizens, and Elder Line (National
Helpline for Senior Citizens) for utilizing the services more effectively.
VIII.
The following Registers/ Records shall be maintained by the NGO in the Home. The Registers/
Records shall invariably be kept with up to date information: The NGO shall produce the registers for
verification by any officer who may visit the Home in official capacity:
Registers to be maintained by the Old Age Home:
a. General Admission-discharge register
b. Attendance register of the Inmates
c. Staff attendance register
d. Movement register of the Inmates
e. Movement register of the staff
f. Medicines Stock Register & Issuance of
Medicines Register
g. Stock register/ Asset register.
h. General register for stores.
i. Cash-book, ledger, salary books,
purchase, bank statements and other relevant registers
j. Visitors book

<!-- page 17 -->

k. Register for donations (cash / kind / events
/ services) received from public/donors.
Records to be maintained by the Old Age Home:
a.

Individual Case History Record of the inmate

b.

Individual care plan (Health-record) of the inmate

IX.

Every Old age home will engage honorary services of a consultant Doctor. The consultant Doctor
shall visit the Home minimum two times per week to attend the inmates with general complaints
and shall be available to the Home at any time to attend to the inmates incases of emergency. The
consultant Doctor of the Home shall conduct medical checkup prior to admission of the inmate and
thereafter at intervals of not more than one month, every inmate of the Home shall be subjected
for a detailed medical examination and record his findings and shall without any delay bring to the
notice of the NGO/ DWO/Asst. Director on any matter of importance affecting the health of the
inmates for such action as may be deemed necessary.

X. The NGO shall without any delay seek admission of the inmate, who in the opinion of the Doctor
require further treatment, in the nearest Government hospital.
XI.

The NGO shall immediately after the occurrence of any death among the inmates/residents of the
home, send a written report to the Police, with a copy thereof to the concerned AD, WD & SC,
Hyderabad/District Welfare Officer, WCD & SC explaining the cause of death to the best of his/her
knowledge.

XII. In the event of death of any of the inmates, last rites will be undertaken by the home, may permit
interested inmates to participate. The required rites to be performed according to the religion or wish (if
any recorded earlier in writing) of the deceased person. Intimation shall be given to the nearest relative,
if any information is available, soon after death.
XIII.

The old age home shall ensure that rights and entitlements of senior citizens under various
schemes/statutory provisions are protected at all times.

XIV.

The NGO shall take all precautions for maintenance of complete safety and security in the
Home.

XV.

And any other standards laid down in the Act & Rules.

C.

Joint Responsibilities
Establishment of Protocols: The Govt. of Telangana and partner NGO in co-management will
jointly frame and establish the different protocols necessary for the management of the Old Age
Home. These Protocols will cover areas of safety, cleanliness, health, nutrition etc. The
Government of Telangana and partner NGO in co- management will also jointly draw up the job
description and requirements for the different personnel.

<!-- page 18 -->

Monitoring: The Parties will undertake monitoring visits to provide on- site support and guidance
to the staff, and monitor the financial management.
Management: The Government & NGO will jointly manage the home on a day-to-day basis.
18.

WHO CAN APPLY TO BE NGO PARTNER IN CO- MANAGEMENT FOR RUNNING THE OLD AGE
HOME
(i)

Shall be registered under the Telangana Societies Registrations Act, 2001 (A.P Act. No.35 of
2001, or the Companies Act, 1956 (Central Act 1 of 1956), or the Indian Trusts Act, 1882
(Central Act No.2 of 1882) or any other law for the time being in force providing for such
registration. Further, the registration should have been in force for at least 3 years at the
time of applying to be eligible as a partner i

(ii)
(iii)
(iv)
(v)
(vi)
(vii)

(viii)
(ix)

n Co-management. Newly started NGOs may be selected in exceptional cases.
It shall have proven capability of work in the area of social work preferably for senior
citizens welfare for a period of 3 years.
It shall have a recurring annual budget of at least 5 times the estimated budget of the old
age home for the preceding three years.
Preferred if recognized, aided, or approved by at least one department or agency
functioning under either State or Central Govt.
It shall have a properly constituted managing body with its powers, duties, and
responsibilities clearly defined and laid down in written documents as per the organization
type.
It shall not run for profit to any individual or a body of individuals and shall be registered
with the Income Tax Department under 12A.
It shall submit reports periodically and punctually as prescribed by the State Government.

19.

CRITERIA FOR SELECTION OF NGO PARTNER IN CO-MANAGEMENT FOR THE OLD AGE HOME

i.

The Governing Board members of NGO should not have any previous conviction record or had
been charge-sheeted.
Should not have been involved or convicted under any law, or any immoral act or in an act of
any abuse or committed any other human rights violations or unethical practices, etc.
Any member (He/she) of the Governing Board Members of NGO should not have been a
member of board /management of any institution/organization, which has been
blacklisted/adversely reported upon, besides shall not have any history of financial
fraud/mismanagement, etc.
Any member (He/she) of the Governing Board Members of NGO should be a person with an
unblemished record in rendering services for the disadvantaged communities preferably senior
citizens.

ii.
iii.

iv.

<!-- page 19 -->

v.
vi.
vii.

viii.
ix.

x.
20.

Preferred, if they have experience of working in collaboration with Government
departments/programs for a minimum of 3 years.
Should preferably have a network with other NGOS in districts/Government officials concerned
on issues related to senior citizens.
If it is brought to the knowledge of the Department that the credentials and experience of NGO
do not confirm to the norms prescribed in the MWPSC Act, 2007 & the State Rules, 2011,
NAPSRC and Guidelines for running Old Age Homes for Senior Citizens or any other laws or
government orders in force, after due inquiry and on the establishment of such fact, declare the
selection of such NGO as null and void and recommend the name of the next NGO from the list
prepared.
NGOs will be disqualified, if there is any attempt to bring any extraneous pressure or political
influence or unfair practices on the authorities/inspection teams.
The organization shall maintain a record of all assets acquired wholly or substantially out of
government grants and donations if any. Such assets shall not be disposed of, encumbered or
utilized for purposes other than those for which the grants were given without prior sanction of
the Government.
They shall also provide such information as required/called for by the authorities concerned.
REPORTS BY THE NGO PARTNER UNDER CO- MANAGEMENT APPROACH

The NGO shall submit annual report on the administration of the Home along with the Audit Report of
the preceding financial year and any reports asked by the government through the concerned Assistant
Director, WDSC, Hyderabad/District Welfare Officer, WCD&SC who in turn will submit the same to the
Director WD&SC Department.
21.

AMENDMENT TO THE GUIDELINES

The Commissioner/ Director, Welfare of Disabled and Senior Citizens shall send a proposal to
Government to make any amendment to these guidelines. The Commissioner/Director, Welfare of
Disabled and Senior Citizen Department have all the rights to discontinue the grants to the NGO at any
time whenever the service of the NGO is found not satisfactory.

D.DIVYA,
SPECIAL SECRETARY TO GOVERNMENT.
