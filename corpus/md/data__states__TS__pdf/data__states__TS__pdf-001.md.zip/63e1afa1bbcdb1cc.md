---
doc_id: "63e1afa1bbcdb1cc"
source_url: "https://cdn.s3waas.gov.in/s31c383cd30b7c298ab50293adfecb7b18/uploads/2025/03/2025032970.pdf"
ministry: "Khammam"
title: "1.NOTIFICATION"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4403942c1f29bcb1"
---

<!-- page 1 -->

GOVERNMENT OF TELANGANA
Rc.No E1/DMHO/1/2025

Office of the District Medical & Health Officer,
Khammam District, Date : 28 /3/2025
NOTIFICATION No.1/2025

Guidelines for recruitment of

Psychiatrist (NMHP) and Support Engineer under

National Health Mission
Recruitment shall be done for (1 Post) Psychiatrist and (3 Posts ) of Support Engineer
as per the details enclosed in the District domain (https://khammam.telangana.gov.in) and
these vacancies may be increased or decreased as on date, at the time of counseling
conducted.
1. Applications are hereby invited by the Khammam District Selection
Committee headed by the District Collector& District Magistrate from the
eligible applicants to the vacant posts.
PSYCHIATRIST

No. of Posts (1)

NAME OF THE DESIGNATI
PROGRAMME ON
NMHP
PSYCHIAT
RISTS

QUALIFICATIONS
REMUNERA
REQUIRED
TION
MD in Psychiatry or 1,00,000
equivalent
degree
from
institution
recognised by Medical
Council of India . 2
years experience of
working
as
a
specialist in a hospital

Unit
Appointment
Multi zone I

of

SUPPORT ENGINEER (3)
Name of the post

supporting Engineer

Qualification required

B.Tech (CSE,IT &ECE/MCA)

Experience

Minimum 4 years experience in the field of
Technical support

Remuneration

35,000/-

Mode of Recruitment

Outsourcing

Unit of appointment

Zone

IV

Kothagudem/Warangal
/Mahabubabad

(Khammam/Bhadradri
&

Hanamkonda

<!-- page 2 -->

Age limit

Minimum

18 Years

Maximum

44 Years

For SC/ST/BCs& EWS

(5) years relaxation permissible

Physically Handicapped persons

(10) years relaxation permissible

Selection Process
Psychiatrist post selection will be made by awarding 80% of marks for marks
obtained in qualifying examination and 20% marks for experience and interview.
For the post of Support Engineer selection will be done 90% of aggregate marks
obtained in all qualifying examination and 10% for Age limit with (.5 marks for every
completed year with a maximum of 20 years.
How to Apply
The application should be uploaded through online and

downloaded from the

official website https://khammam.telangana.gov.in W.E.F----2/4/2025 10.30 AM to
4/4/2025 5.00 PM
5. The downloaded application shall be filled by the Candidates, duly enclosing the
required copies of certificates and should be submitted in O/o DM&HO Khammam
Last date for submission of application is
downloaded offline application form shall

4/4/2025

till

5.00 PM. The

be submitted in person or through

registered post to the District Medical &Health Officer Khammam to which the
candidate is applying. Applications which are received after due dates will be
summarily rejected. District Selection Committee is not responsible for post delays.
(i)

Self attested copies of the following Certificates should be enclosed along

with the application form:
1

SSC / Date of Birth Certificate issued by the Competent Authority of the Govt., for
proof of Age.

2

Intermediate or 10 + 2 examination

3

Qualifying Examination Pass Certificate

4

Marks Memos of all the years (Qualifying Examination)

<!-- page 3 -->

5

Registration Certificates of respective Councils

6

Latest Community Certificate / EWC Certificate / Ex Servicemen / NCC/Physically
Handicapped, whichever is applicable, issued by the Competent Authority.

7

Study certificate for the years from 1st class to 7th class and in case of Private Study
residence certificate from the Tahsildhar /MRO concerned to be submitted.

8

PH Certificate in respect of candidates claiming reservation under PH Quota

9

Relevant Certificates in respect of candidates claiming Ex-service Men Quota.

10

Registration Certificate from the concerned Medical Council/Nursing Council/Para
Medical Board /Other relevant authority.

11

Photograph duly pasted on the application form

12

Acknowledgement Card

Application Fee:For OCs

candidates have to pay 500/-

and for

SC/ST/BC/EWS

candidates have to pay application fee of Rs.300 /- in the shape of Demand
Draft through any nationalized bank, in favour of DM&HO, Khammam.
Notification Schedule for filling up the positions
1

of Notification by District Collector

2

Start date of receipt of applications
(ONLINE & OFFLINE)
3
Last Date of receipt applications (ONLINE
& OFFLINE)
6. General information to the candidates:-

29/3/2025
2/4//2025 10.30 AM
4/4//2025 5.00 PM

1. The District Collector reserves the right to change/modify/cancel the selection

process at any time during the process and the decision of the District Collector
will be final and binding.
2. The Mode of Appointment is on Outsourcing basis or Contract basis for a period

of 1year or till the actual need ceases whichever is earlier.
3. No TA/DA will be paid to the candidates for attending the interviews.
4. Appointees will work under the overall administrative control of CH&FW and MD,

NHM.

<!-- page 4 -->

5. The termination notice shall be (30) days period from either side.
6. Candidates selected under Outsourcing mode shall be appointed through

Outsourcing Agency.
7. The posts notified are not permanent/regular Government posts and purely

temporary.
8. The Panel of Candidates will be utilized for future vacancies, until a period of

one Year from the final date of Selection of Candidates, in this Notification.
9. Theselectedcandidateswillbeintimatedthroughemail/officialcommunication.
10. The selected candidates may have to perform tours.
11. Their performance will be evaluated from time to time and also the same will be

considered for Extension/Termination of their service, in case of future
requirements.
12. The employment is subject to disciplinary/codal rules and in case of any

deviation, employment is liable for termination.
