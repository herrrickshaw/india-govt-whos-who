---
doc_id: "ad8615cdca5a2ef3"
source_url: "https://law.telangana.gov.in/fileShow?fileName=/Uploads/LawDepartment/pdf/ActNo5of2015.pdf"
ministry: "Law Department, Telangana"
title: "The Telangana (Agricultural Produce and Live Stock) Markets (Amendment), 2015 (Act No.5 of 2015)."
date: ""
pages: 4
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "375d4d1d8db93d4a"
---

<!-- page 1 -->

|

Registered No. HSE/49 | [Price : %. 0-30 Paise. |

v4 7
. తెలంగాణ రాజసత్రను | :
; THE TELANGANA GAZETTE to
PART IV-B EXTRAORDINARY | |

PUBLISHED BY AUTHORITY 7
; No. 5] HYDERABAD, WEDNESDAY, APRIL 15, 2015. ‘

TELANGANA ACTS, ORDINANCES AND : |

REGULATIONS Ete. :
The following Act of the Telangana Legislature received |
the assent of the Governor on the 13th April, 2015 and the | |
: said assent is hereby first published on the | i |
15th April, 2015 in the Telangana Gazette for general | |
information. ee :
ACT No. 5 OF 2015. | |
AN ACT TO AMEND THE TELANGANA (AGRICULTURAL ye :
. PRODUCE & LIVE STOCK) MARKETS ACT, 1966. | |
Be it enacted by the Legislature of the State of Telangana ; i
in the Sixty-sixth Year of the Republic of India as follows:- | | |
4. (1) This Act may be called the Telangana (Agricultural Shorttitte | |
‘Produce & Livestock) Markets (Amendment) Act, 2015. an en: |
. (2) it shall be deemed to have come into force with cement | ! /
effect from 01-01-2012. | |
Aa | |
. 4 |

<!-- page 2 -->

2 TELANGANA GAZETTE EXTRAORDINARY Part IV-B | |
Amend- 2. Inthe Telangana (Agricultural Produce & Livestock) 4 |
ment of. Markets Act, 1966 (hereinafter referred to as the principal | /
. Act), in section 5,- So |
. | (0101౧ sub-section (1),- |
: (a) in the opening paragraph, for the word “eighteen” . |
the word “fourteen” shall be substituted; :
: (b) in clause (i), for the word “eleven”, the word “eight”
and for the word “appointed”, the word “nominated” shall :
/ be substituted respectively; Ho
౨. (c) in the second proviso to clause (i) for the word |
“five”, the word “three” shall be substituted;

| " (6) in clause (ii) for the: word “three”, the word “two” .f |
and for the word “appointed”, the word “nominated” shail i
be substituted respectively; | |
(6) in clause (iii), for the word:“appointed”, the word |
. “nominated” shall be substituted.
(2) in sub-section (2), for the word “appointed”, " |
| occuring at two places, the word “nominated” shall be
‘substituted; : /
, (3) for sub-section (3), along with the first proviso there Lo |
* under, the following shall be substituted, narnely,- | |
|
“(3 Save as otherwise provided in this Act, the term :
of office of the members nominated under sub-section (1) |
shall be one year from the date of nomination: . :
Provided that a member nominated under clause (1) of | |
” sub-section (1) shall cease to hold office, if he/she ceases hoe |
. tobeatrader” - : i 7 |
(4) in sub-section (6), for the word ‘appointment’; >
7 the word “nomination” shall be substituted, © os :
(8) in sub-section (9), for the word “appointed” the : /
/ | word “nominated” shall be substituted; 7 : |
{
. ||
|

<!-- page 3 -->

| * April 15, 2015 TELANGANA GAZETTE EXTRAORDINARY 3 +
(6) in sub-section (10), for the word “appointed’, :
. the word “nominated” shall be substituted; :
(7) after sub-section (10), the following sub-section -
shall be inserted, namely,- ;
“(11) Notwithstanding anything contained in any.
provisions of this Act, members of the Committee including . 1 |
the Chairman and Vice-chairman shall hold the office during : |
| the pleasure of the Government”. : |
3. In the Principat Act, in section 5-A,-- Amend- | Po
. : ment of .
. Section 5-A. |
(1) in sub-section (1), the words “and appointed” shall | |
be deleted. | ॥ |
(2) in sub-section (2), for the word “appointed” |
occurring at two places the word “nominated” shall be _ | |
. substituted. ॥ |
(3) in sub-section (3),-~ : |
() for the word “appointed” the word “nominated”, i :
and for the word “appointment’, the word “nomination” shall |
be substituted, respectively; ” i |
(ii) inthe first proviso for the word “appointed” the | |
word “nominated” shail be substituted. |
4. In the Principal Act, in section 6, in sub-section (3),- Amend
: (i) in clause (a), for the words “may appoint” the section 6. Lo |
words “may nominate” shall be substituted; (|
(1 in clause (0), for the word “appointed” the word |
“nominated” shall be substituted; i |
(iii) in clause (c), for the word “appointed” the word
“nominated” shall be substituted; .. | i
(iv) in clause (d),-- : oy |
cee నాడా న. య. ee నాలానానాగ .
|.

<!-- page 4 -->

4 TELANGANA GAZETTE “EXTRAORDINARY Part IV-B i

7 {a) for the words. “appointment” the word oo
“nominatien’ shail be substituted; . |

(0) for the word “appointed” occurring at two places :

: “= the word “nominated” shail be substituted.
Amend- 5. Inthe Principal Act, in section 11, in'sub-section (1) : |
ment of for the word “appointed” the word “nominated” shall be . :

ion 11, న ’ |
substituted. |
Amend- 6. in the Principal Act, in section 22, in.-sub-section (3),
ment OF in clause (a), for the word “appoint” the word “nominate” -
shall be substituted.
Amend: 7. In the principal Act, in section 33, in sub-section (2), :
రసం. in clauses {i) and (ii), for the word “appointment” the :
word “nomination” shall be substituted. " : |
Validation. 8. Notwithstanding anything contained in any provisions : |
of this Act, the members of the Committee, including _ |
Chairman and Vice-Chairman, whose term expiring under |
the provisions of this Act, their continuation in the office, |
from the date of expiring of their term, are validated in all |
tespects, as if they deemed to have been validly |
nominated for the said period. | 1 |
Repea! of 9. The Telangana (Agricultural Produce and Livestock) |
pao Markets (Amendment) Ordinance, 2015 is hereby | |
repealed. | |
|
: A. SANTHOSH REDDY, |
॥ Secretary to Government,
Legal Affairs, Legislative Affairs & Justice, :
Law Department. . |
: |
; PRINTED AND PUBLISHED BY THE COMMISSIONER OF PRINTING + |
* AT LEGISLATIVE ASSEMBLY PRESS, HYDERABAD. ,/ . |
: :
|
