---
doc_id: "cb836d4a2ccad8b0"
source_url: "https://cdn.s3waas.gov.in/s3084b6fbb10729ed4da8c3d3f5a3ae7c9/uploads/2026/10/17931890762290.pdf"
ministry: "Nagarkurnool"
title: "నాగర్‌కర్నూల్ జిల్లా గెజిట్ - కరీఫ్ 2026 కరువు ప్రకటన (తెలుగు వెర్షన్)"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1055d8d62988c168"
---

<!-- page 1 -->

I
awru e,~.,-& (Telugu Version)
0~. ~o. <!3/1460/2026

NAGARKURNOOL DISTRICT GAZETTE
c,~g-dm ~o~•

~o~• ~o. Gl/167/2026 "'9ii6•m-ld, WQ .J-CSo, eft.>6 28, 2026.

-xl7~~~ ,~~~ ~css.::ra)

QDEU-t> !>~~d ~6;4>w 2026 - •m~ - ~mo moo~~~w 2026,

~6:, 2026 !>~~d ~ii6•m-ld IJf19d~ 13 ~od.v-v~ •m~ Qt,,-~o
~od.v-wn- Q•tJ~.

{&6.~.iJo. <!3/1460/2026, seJs6
& ~Vo
~~~6, ;;:;ot16sdJO,ef, ~§6&J6
~
~
B
~
~
28/2026.J
ilvo~tc) ~~050 ee6 ~~~ ~.t.,.~o.~~:>.~o.03, a~~S (!>~~ ~05~-II)

~o 24.10.2026 ~ru5v ~~do, sru~ ~05~ti) eeboo.:> ~~~c0O,
2016 (c~oe.>6 2020 ~oSl tv~Oo~e.>c~O) e,~tvO~, N°OOS6Y>J.o ~~

;ri~,

<!-- page 2 -->

~ogO :::J~o~~ ~e~tilv O~is• ~d:lU d:ltil~;)~w 2026, ~6~ 2026
~?11~6 ~OOS<iJoJ_O e~d:::i ~ §oO 13 (~O~t!>) ~o(}.v-vd Sd:l~

~o~oow ~e.,g ~ a~l®~ r;oo.>o»Y'vorr> ~Stlo ~~~~ o. !)t,6 1O
~o~tr tu b~ ~Cb~ ~Oai)J 3 ~ot!t rw ~t.1~~ ~Ci)~ ~e,J"!)d~~!).

.

b~/ ~QS~

s.@o.

e~

1

~t'iOSd.Y>leS

.
e.S'boc

ll~

2

~Mosd.Y>leS

~voe

ll~

3

~t'iOSd.Y>le5

~d§°oG'.

ll~

4

~Mosd.Y>le5

~oruoru

ll~

5

~Mosd.Y>le5

~~tJ0 6

ll~

6

~ti6S6Y>le5

~od

l,~

7

~Mosd.Y>le5

eJe.lYlru

beJ

8

~Mosd.Y>1

~OTT°V

9

~M6s6Y>le5

~~
~o§°d
G)

b~

10

~Mosd.Y>leS

s6cru

b~

11

~(iQSQ y>leS

!)e~~~
M

~o~~

12

~Mosd.Y>1e5

svs~9

~o~tv
4)

13

~oosa y,leS

~tJo!:>e..>

~o~tv
4)

~

~oa.v o

,M

v

G)

.

'

...Ill

(')

b~

~ ~o~e:r>e.,6:0 200w rue-a zy>soo~w OOoOJe..>~ ~Oo:ll) e~ ®og>o

t'io

1':>~ro.,s ~o~w ~~~e: ,&) ea ~se..>c:o ?;500 i5®eJCC:00. ~~® s i:Josve56 ~os.t
c:ooCSJ eJOl) (DBT) c-o5~ ~~eJC O'°Ol)~, aoru~ej tvd~~ ~o~, e~1vo~;o

Se:, ~~tr1vo ~~J~ ~Oall ) ~~~e. , ~i'.)oo~, ~Oo:il> VB-G RAM G
§oO &~O se.,J;o aotJoOJJ.

<!-- page 3 -->

i:?. ~o~oot> ;JO(:;leS'~ ~~~ tJ®t.)C~ tm':J~';JO / ~~c-a ~otr>W SOJ~
~t.JO!>O ~oOo ~oc !).)~~Q).)oijt.)c~:>. e90l)i1, ~r.u.~~ ~d~tr> e9~~tr>V

~:»go ~ ~o~v~ sru~ ~~:>a ~oc.eiov& ~~~orJI> ~Ooclo~~eJ~.
~oO)rJ1> &~~o~Oot:jt.)c:0$, ea ~Se.>~ e?,4!:r nez,66 ~~Oo~e..>c~ t)o ~oc.

egd) (6) ~t>t> 'S'°t>o ~~ e9t:,Jwe56 eot!:>cfu.

~vo: "1°00SOY>le5

ao: 2s.10.2026

~Q)o5 ~cy,~ 'S'°dSOO-d, o~~S (:)~~ :Od5;,ot'a) 11°.~, iJvonot"d, ~oove.J06

(nee.5 1o ~ruve6).
~D:

1.

~6 SeJgo ~tJo!)e.>, a~~~ c:)~~e5 60S°OJW sv5SJ9
,§°~~o ~Oal)J ~Ko SOJ'>le5 noos ;

2.

e~ ~S~~® 6¢sa0 & e~ eeos~~~ 605°0, ~oo SOJOJ.e5 ;

3.

e~ ~OCJOQ).)b ~OS°O & e~ ~:Oon 605°0, ~00 SOJOJ,e5;

4.

e~ ~~~o~gs 6¢S°O, ~~o SOY>leS;

s.

e~ rr~&cr>e';)~~~ 60S°O, cv°Mo s6Y>l_~;

6.

~ 13 ~oCeJOV o~~~~; ~oe..>oOd ~ocv ~s~~® ~¢S°OJW.
