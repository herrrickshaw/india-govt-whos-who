---
doc_id: "1e1b4fe39caea5af"
source_url: "https://endowments.ts.nic.in/images/Transfers_Memo.pdf"
ministry: "Endowments Department, Telangana"
title: "Transfers - List of those individuals who completed 4 Years and all EO Grade-III"
date: ""
pages: 20
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "1daa13c2738cab21"
---

<!-- page 1 -->

భా
OFFICE OF THE COMMISSIONER,
ENDOWMENTS DEPARTMENT, T.G., HYDERABAD.
Memo in Rc.No.A2/8147/2024, Dated: 04-07-2024.

Sub: Endowments Department - Transfers and postings of
employees - Lifting ban on transfer - Orders -- Issued ~
Communicated - Regarding.

Ref:- G.O.Ms.No.80, Finance (HRM-I} Dept., dt. 03-07-2024.

Pere

A copy of G.O. received in the reference cited is herewith
communicated to all the Officers mentioned at address entry for information
and necessary action.

The Zonal Deputy Commissioners and District Assistant Commissioners
are requested 10 communicate the said G.O. to all ihe employees working
under their jurisdictions including those working in Moffusil office and
Executive Officer Gr, Il & Ill cadres.

As per guidelines issued by the Government in the ref cited, the
following details pertain 10 State Cadre, Multi Zonal Cadre, Zonal Cadre, and
District Cadre posis, as well as the Committees for assessing transfers in these
posts and the competent authority for executing such transfers.

local Commiifee constituted Competent
Name of the post Cadre for considering authority for
transfers iransfers
Additional Commissioner | State | 1. Pr. Secretary. Government
cadre | 2. HOD. (Convener)
3. Addl. Secretar
2. | Deputy Commissioner State | 1. Pri. Secretary. Commissioner
Cadre | 2. HOD. (Convener) of Endowments.
3. Addl. Secretar
3. | Deputy Executive State | 1. Pri. Secretary. Commissioner
Engineer Cadre | 2. HOD. (Convener) of Endowmenis,
3. Addl. Secreta
4. | Assistant Commissioner Multi |, 1. HOD, Commissioner
Zonal | 2. Addl. Secretary of Endowments.
3. Addl. Commissioner
Convener)
5. | Executive Officer Gr-! Zonal | 1.HOD. Commissioner
2,460. Secretary of Endowments.
3. Addl. Commissioner
[Convener
Executive Officer Gr-Il Zonal | 1.HOD. Commissioner
2.466. Secretary of Endowmenis.
3. Addl. Commissioner
Convener
7. | Executive Officer Gr-lll District | 1. Dist. Collector. Commissioner
cadre | 2.Addl.Collector/DRO | of Endowments.
3. Asst. Commissioner.
Convener)
Superintendent Zonal | 1. HOD. Zonal Deputy
cadre | 2.Addl. Secretary Commissioner.
3. Addl. Commissioner
‘Convener,
P.T.O.

<!-- page 2 -->

. +
n2u
శ 7 Competent
Local | Committee constituted .
Name of the post ce క authority for
గా Cadre | for considering transfers iransfers
Endowmenis Zonal | 1. HOD. Zonal Deputy
Inspector cadre | 2.Addl. Secretary Commissioner
3. Adal. Commissioner
Convener)
Senior Assistant Zonal | 1, HOD. Zonal Deputy
cadre | 2.Addl. Secretary Commissioner.
3. Addl. Commissioner.
Convener)
Junior Assistant District | 1. Dist. Collector. Zonal Deputy
cadre | 2. Addl. Collector/ DRO | Commissioner.
3. Asst. Commissioner.
Convener}
12. | Typist District | 1. Dist. Collector. Zonal Deputy
cadre | 2. Addl. Collector/ DRO | Commissioner,
3. Assi. Commissioner.
[Convener]
13. | Record Assistant District | 1. Dist. Collector. Zonal Deputy
cadre | 2. Addl. Collector/ DRO | Commissioner.
| 3. Asst. Commissioner.
Convener,
14, | Office Subordinate | District | 1. Dist. Collector. Zonal Deputy
cadre | 2. Addl. Collector/ DRO | Commissioner.
3. Asst, Commissioner.
Convener]
15. | Night Watchmen District | 1. Dist. Collector. Zonal Deputy
cadre | 2. Addl. Collector/ DRO | Commissioner.
3. Asst. Commissioner.
Convener]

in pursuance of the guidelines issued by the Government, a statement
showing the details of cadre strength, working and vacancy position for the
post of Deputy Commissioner, Deputy Executive Engineer, Assistant
Commissioner, Executive Officer Gr-l, Il, and Ill (SILNo.5, 6 & 7) as well as details
of individuals who have completed 4-years of service in those posts at a
particular station, are enclosed herewith. The zonal Deputy Commissioners
and District Assistant Commissioners are requested 10 place the same on the
notice board of their respective offices for information of all the concerned.
The list of Institutions along with details of posts in Deputy Commissioner,
Deputy Executive Engineer and Assistant Commissioner are also enclosed for
reference of all 1౧9 concerned.

The Zonal Deputy Commissioners shall prepare similar statements
showing the details of cadre strength, working and vacancy position in
respect of Moffusil employees categories from SI.No.8 fo 15, as well as a list of
individuals who completed 4-years of service in those categories in a
particular Station interms of provision of Presidential Order-2018 and publish
the same on the notice board of their offices dlong with vacancy positions
and also forward it to District Assistant Commissioners for placing on their
notice boards for information of all the concerned Moffusil employees.

Conftd....3.

<!-- page 3 -->

- న్‌
nda
The zonal Deputy Commissioners after preparing the above
statements, shall also forward the details of zonal Moffusil cadre
employees i.e. from SI.No.8 10 10 to this office along with vacancy position
for taking further necessary action.
On receiving the above details, the District Assistant Commissioners
shall place the details of each category of employees working in District
cadre posts pertaining 10 their jurisdictions 1.6. Executive Officer Gr-lll,
Junior Assistant, Record Assistants, Typist, Office Subordinates, Night
Watchmen 910. and options exercised by them before the Committee for
approval of transfers. After approval, the District Assistant Commissioners
shall submit the recommendations of the District Committee to the their |
zonal Deputy Commissioners in respect of Moffusil Employees and
Commissioner in respect of Executive Officer Gr-lll post.
Sd/- M. HANUMANTHA RAO,
COMMISSIONER
//౬0.0.//
న్న SUPERINT@NDENT
To,
1] The Additional Commissioners, Endowments Department.
2) The Additional Commissioner & Member, Telangana Endowments :
Tribunal, Hyderabad. |
3) All the Deputy Commissioners, Endowments Department.
4) All the Deputy Executive Engineers, Endowments Department.
5) All the District Assistant Commissioners, Endowments Depariment.
6) Extra,

<!-- page 4 -->

Page 1 of 14
- Statement showing the particulars of individuals who completed 4-years of service
Date from IFany
which the | Total length Working in | Disciplinary
m incumbent lof service in Same / cases If any Allegations
Name of Employee Designation Present Place of working Is working in} Present Previous Stations Higher / Pending, if | cases pending Remarks
the Present | Station Lower cadre! 50,1016
Station detalls
Deputy Commissioners
Cadre Strength -07__ Working -05 _ Vacant - 02
40% of working strength = 2
Existing vacancy: E.0., Basara & ౬౦. Kondagattu Arising vacancies: D.C., Hyderabad, D.C. (S) in Head Office
5/1 M.Ramakrishna Deputy 0/0. the Deputy Commissioner, | 19.06.2017 7-Y¥ Executive Officer, Sri Same cadre Nil Nil
Rao Commissioner |Endowmenis, Hyderabad. Mattikarjuna Swamy
Devasthanam,
Komuravelly.
Sti D.Krishna Prasad = [Deputy 0/0. the Commissioner, 20.04.2018 | 6-Y, 1-M_ [Assistant Commissioner, [Lower cadre] Charges Nil
Commissioner [Endowments Dept., Hyderabad. Medak pending
Deputy Executive Engineer
Cadre Strength - 03 _ Working -03__ Vacant - 00
(40% of working strenath = 1)
Existing vacancy: Nil Arising vacancies: DE.E., Hyderabad, D.E.E., Warangal
1. |SriK. Omprakash Rao ;Deputy 0/0. the Deputy Executive 20.08.2019 5-Y [As Assistant Engineer in |Lower cadre} Nil Allegations pending | 0౧10౧10 be exercised
Executive Engineer. Hyderabad. 0/0. the Deputy vice versa
Engineer Executive Engineer,
Hyderabad.
2 |SriCh.Ramesh Babu |Deputy 0/0. the Deputy Executive 26.08.2019 5-Y As Assistant Engineer in |Lower cadre} Option to be exercised
Executive Engineer, Warangal 0/0. the Deputy vice versa
Engineer Executive Engineer,
Warangal

<!-- page 5 -->

: Page 2 of 14
Date from Ifany
which the | Total length Working In | Disciplinary |
Name of Employee Designation Present Place of working ని! ae of service In Previous Stations lg med pending, 1 కంకర
the Present | 5161100 Lower cadre} 50,116
Station detalls
Assistant Commissioners - M.Z.-1
Cadre Strength - 12__ Working - 05 __Vacant - 07
{40% of working strength = 2)
Existing vacancy: A.C., Khammam, A.C., Nizamabad, A.C., Medak, E.0., Jamalapuram, E.0., Kuravi, E.0., Medaram, ౬9. Dharmapurl
{Arising vacancies: A.C., Warangal, A.C., Adilabad
Smt. R. Sunitha Assistant 0/౦. the Assistant Commissioner, | 28.09.2016 | 7-Y,8-M_ |As Executive Officer Gr- |Lower cadre] Nil Nil
Commissioner |Endowments, Warangal 1. Sri Sammmakka
Saralamma Jathara,
Agrahampahad {V},
Warangal District.
2 | 51౮. Vijaya Rama — [Assistant 0/0. the Assistant Commissioner, | 29.06.2019 | 5, 1-04 |As Superintendent in O/o./Lower cadre) Charges Nil
' Rao Commissioner |Endowments, Adilabad the Assistant pending
Commissioner,
Endowments, Adilabad-
2013 onwards.
0/0. the Executive Officer, Sri 13.11.2022
Gnana Saraswathi
Devasthanam, Basara (on
working arrangement basis)
Assistant Commissioners - M.Z.-Il
Cadre Strength -15 Working - 08 _ Vacant - 07
(40% of working strength = 3)
Existing vacancy: A.C. (Head Office), A.C., Mahabubnagar, A.C., R.R., E.0., Ramgopal Trust, E.0., Chikkadapally, E.0., Cheruvugattu, £.0., Manyamkonda.
Arising vacancies: £.0., Cheruvugatty, J.V.O., Hyderabad.
Smt. A.Sulochana Assistant 0/0. the Executive Officer, Sri 28.09.2016 | 8-Y, 10-M సు Executive Officer Grl, |Lower cadre Nil
Commissioner {Parvathi Jadala Sri Renuka Yellamma
Ramalingeshwora 5.0. Temple, Darveshpuram
Cheruvugaitu. {V}. Nalgonda District,
0/0. the Assistant Commissioner, -11.2021
Endowments, Khammam
Smt. K.Anjana Devi Assistant Jewellary Verification Officer, 28.09.2016 | 7-Y,8-M_ |As Executive Officer Gr-l, |Lower cadre Nil Nil
Commissioner |Hyderabad Sri Bhadrakali
Devasthanam, Warangal

<!-- page 6 -->

లలనా TAT
Page 3 of 14
Date from If any
which the | Total length Working in | Disciplinary
శ incumbent |of service In Same / cases If any Allegations
Name of Employee Designation Present Place of working isworking In| Present Previous Stations Higher / Pending, f | cases pending Remarks
the Present} Station Lower cadre} 50,106
Station details
Zone-| - Kaleswaram
Cadre Strength - 04 Working -04__Vacant - 00
(40% of working strength = 2)
(Cadre Strength / Working - Manchiryal- 1/1, Peddapalli - 1/1, JBP. - 1/4_& Mulugu - 1/1)
Existing vacancy: Nil Arising vacancies: Bhupalapalli District - 1
5. Satyanarayana Executive Sti Hemachala Laxmi Narasimha} 15.06.2018 రా Executive Officer, Sri Same cadre Nil Option to be exercised
* Officer Gr-l Swamy Temple, Mallur (4. Marwadi Panchayati within Bhoopalapally
క | Jaishankar-Bhoopalapally Bhavan, Dharmashala, 7
District. Adilabad Town,
Zone-ll - Basara
Cadre Strength - 03 Working-01 Vacant - 02
{40% of working strength = 0)
(Cadre Strength / Working - Adilabad - 1/0, Nirmal - 1/1, Nizamabad - 1/0, Jagityal - 0
Existing vacancy: Adilabad - 1, Nizamabad - 1
Zone-Il - Rajanna
Cadre Strength -03__Working -03__ Vacant - 00
(40% of working strength = 1)
(Gadre Strength/Working = Karimnagar - 1/1, Siddipet - 1/1. Medak - 1/1)
Existing vacancys Nil Arising vacancies: Karimnagar - 1
IP. Visnwanatha Executive Sri Venkateshwara Swamy 15.06.2018 ఠా As Temple 50061. at Sri [Lower cadre Nil 1. Retirement on
Sharma Officer Gr-1 Temple, Siddipet Town & District. Yellamma Pochamma 30.06.2025.
Temple, Balkampet, 2. Option to be
Hyderabad exercised within
ddinet Dist
2 |K, Sudhakar Executive Sti Seetharama Chandra Swamy | 20.02.2020 | 4-Y,3-M_ |Newly recruited in the Nil Nil Option to be exercised
Officer Gr-l Temple, Ilanthakunta (V), year Dec-2019 within Karimnagar
Jammikunia (14). Karimnagar District
District.

<!-- page 7 -->

Page 4 of 14
Date from IFany
which the | Total length Working in | Disciplinary ~
A incumbent |of service in Same / cases If any Allegations
Name of Employee Designation Present Place of working Is working in| Present Previous Stations Higher / Pending, if cases pending
the Present | Station Lower cadre] 50,116
Station details
Zone-lV - Bhadradsl
Cadre Strength - 03__Working- 02 Vacant - 07
{40% of working strength = 1)
(Cadre StrengthiWorking - Kothadugem - 1/1, Khammam - 1/1, Hanamkonda - 1/0)
Existing vacancy: Hanamkonda - 1 Arising vacancies: Khammam - 1
K.Jagan Mohan Rao |Executive Sri Sthambhadri Laxmi Narasimha] 22.11.2016 | 7-Y,7-M_ |As Executive Officer Gr- |Lower cadre Nil Option to be exercised
Officer Gr-l Swamy Temple {Gutta}, ll, Sri Venkateshwara within Khammam /
Khammam Town. Swamy Temple, Kaman Hanamkonda Districis
bazar, Khammam Town,
Zone-V - Yadadri
Cadre Strength - 05 __ Working -@4_ Vacant - 07
(40% of working strength = 2)
(Cadre StrengthWorking - Yadadri = 1/1, Janagoan - 2/2, Nalgonda - 2/1)
Existing vacancy: Nalgonda - 1 Arising vacancies: Janagoan - 1, Nalgonda - 1
5. Naveen Executive Sri Kota Maisamma Ammavari 20.02.2020 , 4-Y,3-M_ |Newly recruited in the Nil Nil Option to be exercised
Officer Gr-l Temple, Indlakotaiahgudem (V), year Dec-2019 within Nalgonda &
Nidamanoor (14), Nalgonda Janagoan Districts
District.
2 |B.Lakshmi Prasanna =| Executive Sri Bugulu Venkateshwara Swamy] 20.02.2020 | 4-Y.3-M {Newly recruited in the Nil Nil Option fo be exercised
Officer Gr-l Temple, Chilpurgutta (V), Station year Dec-2019 within Nalgonda &
(Ghanpur (M), Janagoan District. Janagoan Districts

<!-- page 8 -->

Page 5 of 14
Date from fany
which the | Total length Working in | Disciplinary
incumbent |of service in Same / cases If any Allegations
Name of Employee Designation Present Place of working Isworking in| Present Previous Stations Higher / Pending, If | cases pending
the Present Station Lower cadre so, the
Station details
Zone-VI - Charminar
Cadre Strength -16 Working - 12_Vacant - 04
(40% of working strength = 5)
(Cadre Strength/Working - Medchal - 4/1, Hyderabad - 11/9, R.R. - 2/2, Sangareddy = 1/0, Vikarabad - 1/0)
Existing vacancy: Hyderabad - 2, Sangareddy - 41, Vikarabad = 1 Arising vacancies: R.R. = 1, Twin Cities = 4
1 |Snehalatha Executive Sri Maisamma Devatha, 27.09.2016 7-Y,8-M_ |As Executive Officer Gr- |Lower cadre’ Option to be exercised
Officer Gr-l Shivalaya, Ramalaya Temple, I), Sti Kalikadevl Temple, within Hyderabad, RR,
Maisigandi (V), Kadthal (M} Tandoor (M), Sangareddy &
Rangareddy District. Vikarabad Districts.
lV. Ambuja Executive Sri Katta Maisamma 04.01.2017 | 7-Y,5-M_ |As Executive Officer Gr- [Lower cadre] Charges Nil Option to be exercised
Officer Gr-l Mahalakshmi Temple, Begumpet, IL, Sti Kallappa Satram pending within Hyderabad, RR,
Hyderabad. Secunderabad. Sangareddy &
Vikarabad Districts,
A. Narender Executive sri Kanaka Durga Temple, 07.03.2019 | 5-Y,3-M_ |Temple Supdt., Sri Lower cadre Option to be exercised
చ్‌ Officer Gr-l Ameerpet, Hyderabad. 'Veerabhadra Swamy within Hyderabad, RR,
Temple, Bonihapally (V}, Sangareddy & ‘
Jinnaram (M), Vikarabad Districts.
Sangareddy District .
4 |M.Srinivasa Sharma = |Executive Sri Veera Hanuman Temple, 5.5. | 24.07.2019 | 4-Y,10-M |As Executive Officer Gr- [Lower cadre Nil Nil Option to be exercised
Officer Gr-l Road, Secunderabad. ll, ౬0.4. Trust, Abids, within Hyderabad, RR,
Hyderabad Sangareddy &
Vikarabad Districts.
5 |B. Jyothi Executive Sri Bhavani Shankar Temple, 20.02.2020 4Y,3-M_ |Newly recruited in the Nil Nil Option to be exercised
Officer Gr-} Bholakpur, Secunderabad. lyear Dec-2019 within Hyderabad, RR,
Sangareddy &
Vikarabad Districts.

<!-- page 9 -->

Page 6 of 14
Date from ifany ౯
which the 1016119౧9౧ Working in | Disciplinary ”
, incumbent |of service In Same / cases If any Allegations
Name of Employee Designation Present Place of working Isworking in) Present Previous Stations Higher / Pending, It | cases pending
the Present | Station Lower cadre] 50,106
Station detalts
P.Mahender Goud Execulive 5/4 Grain Bazar Dharmashala, 22.05.2020 ay Si Neela Kanteshwara = |Sare cadre Option to be exercised
Officer Gr-l Sajjanlal Street, Sec'Bad. Swamy Temple, within Hyderabad, RR,
Nizamabad Town & Sangareddy &
District Vikarabad Districts.
Zone-Vil - Jogulamba-Gadwal
Cadre Sirength-05 Working -04__Vacant - 01
{40% of working strength = 2)
(Cadre Strength/Working = Mahabubnagar - 2/2, Narayanpet - 1/0, Joqulamba-Gadwal - 2/2)
Existing vacancy: Narayanpet - 4 Arising vacancies: Mahabubnagar = 1
1 (C.Madhaneshwar Executive Si Maisamma Devatha Temple, | 20.02.2020 4-Y,3-M_ [Newly recruited in the Nil Option to be exercised
Reddy Officer Gr-l Kakarlapad (V), Nawabpet (M), year Dec-2019 within Mahabubnagar
Mahabubnagor Dist. & Narayanpet Districts.
Executive Officer Gr-ll
Zone-| - Kaleswaram
Cadre Strength -03__ Working - 03 _Vacant - 00
{40% of working strength = 1)
(Cadre Strength / Working = Asifabad-Komarambheem - 1/0, Manchiryal- 2/2)
Existing vacancy: Asifabad - 1 Arising vacancies: Manchiryal - 1
1 |B. Ramesh Executive [Sti Mallanna Swamy Temple, 21.04.2016 | 8-Y,2-M_ |As Senior Assistant, Sri Nil Option to be exercised
Officer Gr-ll Vellala (V), Jaipur (M), Marwadi Panchayath within Asifabad -
Mancherial Dist. Bhavan Dharmashala, Komarambheem &
Adilabad Town & District Manchiryal Districts.
2 |M. Ravi Executive sri Vishwanadha Alayam, 15.06.2018 ర్‌ Sri Chennakeshava same cadre} Charges Option to be exercised
Officer Gr-ll Mancherial Town - 6(b} Swamy Temple, pending within Asifabad -
Chinthakani (V & M), Komarambheem &
Sharamam Manchiryal Districts.

<!-- page 10 -->

| Page 7 of 14
Date from Ifany
which the | Total length Working in | Disciplinary
Incumbent | of service in Same / cases If any Allegations
Name of Employee Designation Present Place of working isworking In| Present Previous Stations Higher / Pending, If | cases pending Remarks
the Present | Station Lower cadre] 50,116
Station details
Zone-ll - Basara
Cadre Strength - 01 Working - 01 _ Vacant - 00
40% of working strenath = 0
(Cadre Strength / Working - Nizamabad - 1/1, Jagityal - 1/0)
Existing vacancy: Jagityal «1 Arising vacancies: Nizamabad = 1
1 |S. Ravinder Executive Sri Datta Saibaba Temple, 15.06.2018 తగ sri Kalabhairava Swamy |Same cadre Nil Option to be exercised
Officer Gr-ll Madhavangar (V}, Dichpally (M). Temple, lsannapally within
Nizamabad Dist.-6{a) (1). Ramreddy (V), Nizamabad/Jagityal
Sadashivnagar(M) Districts.
స 2006-11 - Rajanna
స ॥ Cadre Strength- 07 _1₹/01606%- 06 __ Vacant - 01
షా (40% of working strength = 2) .
(Cadre Strength/Working - Karimnagar ~ 4/3, Medak - 1/1, Kamareddy - 2/2) j
Existing vacancy: Karimnagar - 1 Arising vacancies: Karimnagar - 2
1 JN. Anil Kumar Executive [Si Hanuman, Santhoshi Matha 01.04.2016 | ఈ 244 |Inspector, Karimnagar Nil Option to be exercised
Officer Gr-ll temple, Karimnagar Town and within Karimnagar
District. Districts.
A. Maruthi Executive sri Vijaya Ganapathi Saibaba 15.06.2018 6-Y Sri Mallikarjuna Swamy |Same cadre Nil Nil Option to be exercised 2
Officer Gr-ll Temple, Karimnagar Town. Temple, Odela (V&M), within Karimnagar
Peddapally District Districts.
Zone-lV - Bhadradrt
Cadre Strength - 11__ Working - 10 Vacant - 01
(40% of working sirenath = 4)
(Cadre Strength/Working - Bhadradri-Kothadugem - 2/2, Khammam - 3/2, Warangal - 3/3, Hanamkonda - 3/3)
Existing vacancy: Khammam -1 Arising vacancies: Khammam - 1, Warangal - 1, Hanamkonda - 1
P.Narayana Charyulu |Executive Sri Venkateshwara Swamy 15.06.2018 ఈ Sri Seetha Rama Same cadre Under Suspenston Ni!
(౮/9) Officer Gr-ll Temple, Jeellacheruvu, Chandra Swamy charges pending
Kusumanchi (M), Khammam femple, Muttaram (V),
District. |Mudigonda (4).
Khammam Dist.
