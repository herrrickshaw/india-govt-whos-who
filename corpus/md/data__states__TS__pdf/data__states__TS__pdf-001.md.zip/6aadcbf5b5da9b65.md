---
doc_id: "6aadcbf5b5da9b65"
source_url: "https://cdma.cgg.gov.in/cdma/Files/FeeGOs/GO_22.pdf"
ministry: "Commissioner and Director of Municipal Administration, Telangana"
title: "GO 22"
date: ""
pages: 23
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "32a3d5b540315384"
---

<!-- page 1 -->

MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 21st June, 2005/Jyaistha 31, 1927 (Saka)
The following Act of Parliament received the assent of the President on the 15th June,
2005, and is hereby published for general information:—

THE RIGHT TO INFORMATION ACT, 2005
No. 22 of 2005
[15th June, 2005.]
An Act to provide for setting out the practical regime of right to information for
citizens to secure access to information under the control of public
authorities, in order to promote transparency and accountability in the
working of every public authority, the constitution of a Central Information
Commission and State Information Commissions and for matters connected
therewith or incidental thereto.
WHEREAS the Constitution of India has established democratic Republic;
AND WHEREAS democracy requires an informed citizenry and transparency of
information which are vital to its functioning and also to contain corruption and to
hold Governments and their instrumentalities accountable to the governed;
AND WHEREAS revelation of information in actual practice is likely to
conflict with other public interests including efficient operations of the Governments,
optimum use of limited fiscal resources and the preservation of confidentiality of
sensitive information;

<!-- page 2 -->

2

THE GAZETTER OF INDIA EXTRAORDINARY

[PART II—

AND WHEREAS it is necessary to harmonise these conflicting interests while
preserving the paramountcy of the democratic ideal;
NOW, THEREFORE, it is expedient to provide for furnishing certain
information to citizens who desire to have it.
BE it enacted by Parliament in the Fifty-sixth Year of the Republic of India as
follows:—

CHAPTER I
Preliminary
Short title,
extent and
commencemen
t

Definitions.

1. (1) This Act may be called the Right to Information Act, 2005.
(2) It extends to the whole of India except the State of Jammu and Kashmir.
(3) The provisions of sub-section (1) of section 4, sub-sections (1) and (2) of
section 5, sections 12, 13, 15,16, 24, 27 and 28 shall come into force at once, and the
remaining provisions of this Act shall come into force on the one hundred and
twentieth day of its enactment.
2. In this Act, unless the context otherwise requires,—
(a) "appropriate Government" means in relation to a public authority which is
established, constituted, owned, controlled or substantially financed by funds provided
directly or indirectly—
(i)
by the Central Government or the Union territory administration, the
Central Government;
(ii)
by the State Government, the State Government;
(b) "Central Information Commission" means the Central Information Commission
constituted under sub-section (1) of section 12;
(c) "Central Public Information Officer" means the Central Public Information
Officer designated under sub-section (1) and includes a Central Assistant Public
Information Officer designated as such under sub-section (2) of section 5;
(d) "Chief Information Commissioner" and "Information Commissioner" mean the
Chief Information Commissioner and Information Commissioner appointed under
sub-section (3) of section 12;
(e) "competent authority" means—
(i) the Speaker in the case of the House of the People or the Legislative
Assembly of a State or a Union territory having such Assembly and the
Chairman in the case of the Council of States or Legislative Council of a
State;
(ii) the Chief Justice of India in the case of the Supreme Court;
(iii) the Chief Justice of the High Court in the case of a High Court;
(iv) the President or the Governor, as the case may be, in the case of other
authorities established or constituted by or under the Constitution;
(v) the administrator appointed under article 239 of the Constitution;
(f) "information" means any material in any form, including records, documents,
memos, e-mails, opinions, advices, press releases, circulars, orders, logbooks,
contracts, reports, papers, samples, models, data material held in any electronic form

<!-- page 3 -->

SEC.1

THE GAZETTE OF INDIA EXTRAORDINARY
and information relating to any private body which can be accessed by a public
authority under any other law for the time being in force;
(g) "prescribed" means prescribed by rules made under this Act by the appropriate
Government or the competent authority, as the case may be;

(h) "public authority" means any authority or body or institution of selfgovernment established or constituted—
(a) by or under the Constitution;
(b) by any other law made by Parliament;
(c) by any other law made by State Legislature;
(d) by notification issued or order made by the appropriate Government,
and includes any—
(i)
(ii)

body owned, controlled or substantially financed;
non-Government organisation substantially financed,

directly or indirectly by funds provided by the appropriate Government;
(i) "record" includes—
(a) any document, manuscript and file;
(b) any microfilm, microfiche and facsimile copy of a document;
(c) any reproduction of image or images embodied in such microfilm (whether
enlarged or not); and
(d) any other material produced by a computer or any other device;
(j) "right to information" means the right to information accessible under this Act
which is held by or under the control of any public authority and includes the right
to—
(i) inspection of work, documents, records;
(ii) taking notes, extracts or certified copies of documents or records;
(iii) taking certified samples of material;
(iv) obtaining information in the form of diskettes, floppies, tapes, video
cassettes or in any other electronic mode or through printouts where such
information is stored in a computer or in any other device;
(k) "State Information Commission" means the State Information Commission
constituted under sub-section (1) of section 15;
(l) "State Chief Information Commissioner" and "State Information Commissioner"
mean the State Chief Information Commissioner and the State Information
Commissioner appointed under sub-section (3) of section 15;
(m) "State Public Information Officer" means the State Public Information Officer
designated under sub-section (1) and includes a State Assistant Public Information
Officer designated as such under sub-section (2) of section 5;
(n) "third party" means a person other than the citizen making a request for
information and includes a public authority.

3

<!-- page 4 -->

4

THE GAZETTER OF INDIA EXTRAORDINARY

[PART II—

CHAPTER II
Right to information and obligations of public authorities
3. Subject to the provisions of this Act, all citizens shall have the right to information.
4. (1) Every public authority shall—
a) maintain all its records duly catalogued and indexed in a manner and the
form which facilitates the right to information under this Act and ensure that
all records that are appropriate to be computerised are, within a reasonable
time and subject to availability of resources, computerised and connected
through a network all over the country on different systems so that access to
such records is facilitated;
b) publish within one hundred and twenty days from the enactment of this
Act,—
(i)
(ii)
(iii)

the par ticulars of its organisation, functions and duties;
the powers and duties of its officers and employees;
the procedure followed in the decision making process,
including channels of supervision and accountability;
(iv)
the norms set by it for the discharge of its functions;
(v)
the rules, regulations, instructions, manuals and records, held by
it or under its control or used by its employees for discharging
its functions;
(vi)
a statement of the categories of documents that are held by it or
under its control;
(vii)
the particulars of any arrangement that exists for consultation
with, or representation by, the members of the public in relation
to the formulation of its policy or implementation thereof;
(viii)
a statement of the boards, councils, committees and other
bodies consisting of two or more persons constituted as its part
or for the purpose of its advice, and as to whether meetings of
those boards, councils, committees and other bodies are open to
the public, or the minutes of such meetings are accessible for
public;
(ix)
a directory of its officers and employees;
(x)
the monthly remuneration received by each of its officers and
employees, including the system of compensation as provided
in its regulations;
(xi)
the budget allocated to each of its agency, indicating the
particulars of all plans, proposed expenditures and reports on
disbursements made;
(xii)
the manner of execution of subsidy programmes, including the
amounts allocated and the details of beneficiaries of such
programmes;
(xiii)
particulars of recipients of concessions, permits or
authorisations granted by it;
(xiv)
details in respect of the information, available to or held by it,
reduced in an electronic form;
(xv)
the particulars of facilities available to citizens for obtaining
information, including the working hours of a library or reading
room, if maintained for public use;
(xvi)
the names, designations and other particulars of the Public
Information Officers;
(xvii)
such other information as may be prescribed;
and
thereafter
update
these
publications
every
year;
c)

publish all relevant facts while formulating important
policies or announcing the decisions which affect public;
d)
provide reasons for its administrative or quasi-judicial

Right to
information

<!-- page 5 -->

SEC.1

THE GAZETTE OF INDIA EXTRAORDINARY

5

decisions to affected persons.
(2) It shall be a constant endeavour of every public authority to take steps in
accordance with the requirements of clause (b) of sub-section (1) to provide as much
information suo motu to the public at regular intervals through various means of
communications, including internet, so that the public have minimum resort to the use
of this Act to obtain information.
(3) For the purposes of sub-section (1), every information shall be disseminated
widely and in such form and manner which is easily accessible to the public.
(4) All materials shall be disseminated taking into consideration the cost
effectiveness, local language and the most effective method of communication in that
local area and the information should be easily accessible, to the extent possible in
electronic format with the Central Public Information Officer or State Public
Information Officer, as the case may be, available free or at such cost of the medium
or the print cost price as may be prescribed.
Explanation.—For the purposes of sub-sections (3) and (4), "disseminated" means
making known or communicated the information to the public through notice boards,
newspapers, public announcements, media broadcasts, the internet or any other means,
including inspection of offices of any public authority.
5. (1) Every public authority shall, within one hundred days of the enactment of
this Act, designate as many officers as the Central Public Information Officers or State
Public Information Officers, as the case may be, in all administrative units or offices
under it as may be necessary to provide information to persons requesting for the
information under this Act.
(2) Without prejudice to the provisions of sub-section (1), every public authority
shall designate an officer, within one hundred days of the enactment of this Act, at
each sub-divisional level or other sub-district level as a Central Assistant Public
Information Officer or a State Assistant Public Information Officer, as the case may
be, to receive the applications for information or appeals under this Act for forwarding
the same forthwith to the Central Public Information Officer or the State Public
Information Officer or senior officer specified under sub-section (1) of section 19 or
the Central Information Commission or the State Information Commission, as the case
may be:
Provided that where an application for information or appeal is given to a Central
Assistant Public Information Officer or a State Assistant Public Information Officer,
as the case may be, a period of five days shall be added in computing the period for
response specified under sub-section (1) of section 7.
(3) Every Central Public Information Officer or State Public Information Officer,
as the case may be, shall deal with requests from persons seeking information and
render reasonable assistance to the persons seeking such information.
(4) The Central Public Information Officer or State Public Information Officer,
as the case may be, may seek the assistance of any other officer as he or she considers
it necessary for the proper discharge of his or her duties.
(5) Any officer, whose assistance has been sought under sub-section (4), shall
render all assistance to the Central Public Information Officer or State Public
Information Officer, as the case may be, seeking his or her assistance and for the
purposes of any contravention of the provisions of this Act, such other officer shall be
treated as a Central Public Information Officer or State Public Information Officer, as
the case may be.

Designation
of Public
Information
Officers.

<!-- page 6 -->

6

THE GAZETTER OF INDIA EXTRAORDINARY

[PART II—

6. (1) A person, who desires to obtain any information under this Act, shall make
a request in writing or through electronic means in English or Hindi or in the official
language of the area in which the application is being made, accompanying such fee as
may be prescribed, to—
(a) the Central Public Information Officer or State Public Information Officer,
as the case may be, of the concerned public authority;
(b) the Central Assistant Public Information Officer or State Assistant Public
Information Officer, as the case may be,
specifying the particulars of the information sought by him or her:
Provided that where such request cannot be made in writing, the Central Public
Information Officer or State Public Information Officer, as the case may be, shall
render all reasonable assistance to the person making the request orally to reduce the
same in writing.
(2) An applicant making request for information shall not be required to give any
reason for requesting the information or any other personal details except those that
may be necessary for contacting him.
(3) Where an application is made to a public authority requesting for an
information,—
(i)
(ii)

which is held by another public authority; or
the subject matter of which is more closely connected with the
functions of another public authority,

the public authority, to which such application is made, shall transfer the application
or such part of it as may be appropriate to that other public authority and inform the
applicant immediately about such transfer:

Disposal of
request.

Provided that the transfer of an application pursuant to this sub-section shall be made
as soon as practicable but in no case later than five days from the date of receipt of the
application.
7. (1) Subject to the proviso to sub-section (2) of section 5 or the proviso to subsection (3) of section 6, the Central Public Information Officer or State Public
Information Officer, as the case may be, on receipt of a request undersection 6 shall,
as expeditiously as possible, and in any case within thirty days of the receipt of the
request, either provide the information on payment of such fee as may be prescribed or
reject the request for any of the reasons specified in sections 8 and 9:
Provided that where the information sought for concerns the life or liberty of a person,
the same shall be provided within forty-eight hours of the receipt of the request.
(2) If the Central Public Information Officer or State Public Information Officer,
as the case may be, fails to give decision on the request for information within the
period specified under sub-section (1), the Central Public Information Officer or State
Public Information Officer, as the case may be, shall be deemed to have refused the
request.
(3) Where a decision is taken to provide the information on payment of any
further fee representing the cost of providing the information, the Central Public
Information Officer or State Public Information Officer, as the case may be, shall send
an intimation to the person making the request, giving—
(a) the details of further fees representing the cost of providing the
information as determined by him, together with the calculations made

Request for
obtaining
information.

<!-- page 7 -->

SEC.1

THE GAZETTE OF INDIA EXTRAORDINARY

7

to arrive at the amount in accordance with fee prescribed under subsection (1), requesting him to deposit that fees, and the period
intervening between the despatch of the said intimation and payment of
fees shall be excluded for the purpose of calculating the period of thirty
days referred to in that sub-section;
(b) information concerning his or her right with respect to review the
decision as to the amount of fees charged or the form of access
provided, including the particulars of the appellate authority, time limit,
process and any other forms.
(4) Where access to the record or a part thereof is required to be provided under
this Act and the person to whom access is to be provided is sensorily disabled, the
Central Public Information Officer or State Public Information Officer, as the case
may be, shall provide assistance to enable access to the information, including
providing such assistance as may be appropriate for the inspection.
(5) Where access to information is to be provided in the printed or in any
electronic format, the applicant shall, subject to the provisions of sub-section (6), pay
such fee as may be prescribed:
Provided that the fee prescribed under sub-section (1) of section 6 and sub-sections (1)
and (5) of section 7 shall be reasonable and no such fee shall be charged from the
persons who are of below poverty line as may be determined by the appropriate
Government.
(6) Notwithstanding anything contained in sub-section (5), the person making
request for the information shall be provided the information free of charge where a
public authority fails to comply with the time limits specified in sub-section (1).
(7) Before taking any decision under sub-section (1), the Central Public
Information Officer or State Public Information Officer, as the case may be, shall take
into consideration the representation made by a third party under section 11.
(8) Where a request has been rejected under sub-section (1), the Central Public
Information Officer or State Public Information Officer, as the case may be, shall
communicate to the person making the request,—
(i)
(ii)
(iii)

the reasons for such rejection;
the period within which an appeal against such rejection may be
preferred; and
the particulars of the appellate authority.

(9) An information shall ordinarily be provided in the form in which it is sought
unless it would disproportionately divert the resources of the public authority or would
be detrimental to the safety or preservation of the record in question.

8. (1) Notwithstanding anything contained in this Act, there shall be no obligation to
give any citizen,—
(a) information, disclosure of which would prejudicially affect the sovereignty
and integrity of India, the security, strategic, scientific or economic interests of the
State, relation with foreign State or lead to incitement of an offence;
(b) information which has been expressly forbidden to be published by any court
of law or tribunal or the disclosure of which may constitute contempt of court;

Exemption
from
disclosure of
information.

<!-- page 8 -->

8

THE GAZETTER OF INDIA EXTRAORDINARY

[PART II—

(c) information, the disclosure of which would cause a breach of privilege of
Parliament or the State Legislature;
(d) information including commercial confidence, trade secrets or intellectual
property, the disclosure of which would harm the competitive position of a third party,
unless the competent authority is satisfied that larger public interest warrants the
disclosure of such information;
(e) information available to a person in his fiduciary relationship, unless the
competent authority is satisfied that the larger public interest warrants the disclosure
of such information;
(f) information received in confidence from foreign Government;
(g) information, the disclosure of which would endanger the life or physical
safety of any person or identify the source of information or assistance given in
confidence for law enforcement or security purposes;
(h) information which would impede the process of investigation or
apprehension or prosecution of offenders;
(i) cabinet papers including records of deliberations of the Council of Ministers,
Secretaries and other officers:
Provided that the decisions of Council of Ministers, the reasons thereof, and the
material on the basis of which the decisions were taken shall be made public after the
decision has been taken, and the matter is complete, or over:
Provided further that those matters which come under the exemptions specified
in this section shall not be disclosed;
(j) information which relates to personal information the disclosure of which has
no relationship to any public activity or interest, or which would cause unwarranted
invasion of the privacy of the individual unless the Central Public Information Officer
or the State Public Information Officer or the appellate authority, as the case may be,
is satisfied that the larger public interest justifies the disclosure of such information:
Provided that the information which cannot be denied to the Parliament or a
State Legislature shall not be denied to any person.

19 of 1923.

(2) Notwithstanding anything in the Official Secrets Act, 1923 nor any of the
exemptions permissible in accordance with sub-section (1), a public authority may
allow access to information, if public interest in disclosure outweighs the harm to the
protected interests.
(3) Subject to the provisions of clauses (a), (c) and (i) of sub-section (1), any
information relating to any occurrence, event or matter which has taken place,
occurred or happened twenty years before the date on which any request is made
under secton 6 shall be provided to any person making a request under that section:

Provided that where any question arises as to the date from which the said period
of twenty years has to be computed, the decision of the Central Government shall be
final, subject to the usual appeals provided for in this Act.

<!-- page 9 -->

SEC.1
Grounds for
rejection to
access in
certain cases.
Severability

THE GAZETTE OF INDIA EXTRAORDINARY
9. Without prejudice to the provisions of section 8, a Central Public Information
Officer or a State Public Information Officer, as the case may be, may reject a request
for information where such a request for providing access would involve an
infringement of copyright subsisting in a person other than the State.
10. (1) Where a request for access to information is rejected on the ground that it is in
relation to information which is exempt from disclosure, then, notwithstanding
anything contained in this Act, access may be provided to that part of the record which
does not contain any information which is exempt from disclosure under this Act and
which can reasonably be severed from any part that contains exempt information.
(2) Where access is granted to a part of the record under sub-section (1), the
Central Public Information Officer or State Public Information Officer, as the case
may be, shall give a notice to the applicant, informing—
(a)

that only part of the record requested, after severance of the
record containing information which is exempt from disclosure, is being
provided;
(b)
the reasons for the decision, including any findings on any
material question of fact, referring to the material on which those
findings were based;
(c)
the name and designation of the person giving the decision;
(d)
the details of the fees calculated by him or her and the amount
of fee which the applicant is required to deposit; and
(e)
his or her rights with respect to review of the decision
regarding non-disclosure of part of the information, the amount of fee
charged or the form of access provided, including the particulars of the
senior officer specified under sub-section (1) of section 19 or the
Central Information Commission or the State Information Commission,
as the case may be, time limit, process and any other form of access.
Third party
information.

11. (1) Where a Central Public Information Officer or a State Public Information
Officer, as the case may be, intends to disclose any information or record, or part
thereof on a request made under this Act, which relates to or has been supplied by a
third party and has been treated as confidential by that third party, the Central Public
Information Officer or State Public Information Officer, as the case may be, shall,
within five days from the receipt of the request, give a written notice to such third
party of the request and of the fact that the Central Public Information Officer or State
Public Information Officer, as the case may be, intends to disclose the information or
record, or part thereof, and invite the third party to make a submission in writing or
orally, regarding whether the information should be disclosed, and such submission of
the third party shall be kept in view while taking a decision about disclosure of
information:
Provided that except in the case of trade or commercial secrets protected by law,
disclosure may be allowed if the public interest in disclosure outweighs in importance
any possible harm or injury to the interests of such third party.
(2) Where a notice is served by the Central Public Information Officer or State
Public Information Officer, as the case may be, under sub-section (1) to a third party
in respect of any information or record or part thereof, the third party shall, within ten
days from the date of receipt of such notice, be given the opportunity to make
representation against the proposed disclosure.
(3) Notwithstanding anything contained in section 7, the Central Public
Information Officer or State Public Information Officer, as the case may be, shall,
within forty days after receipt of the request under section 6, if the third party has been
given an opportunity to make representation under sub-section (2), make a decision as
to whether or not to disclose the information or record or part thereof and give in

9

<!-- page 10 -->

10

THE GAZETTER OF INDIA EXTRAORDINARY

[PART II—

writing the notice of his decision to the third party.
(4) A notice given under sub-section (3) shall include a statement that the third
party to whom the notice is given is entitled to prefer an appeal under section 19
against the decision.

CHAPTER III
The Central Information Commission
12. (1) The Central Government shall, by notification in the Official Gazette,
constitute a body to be known as the Central Information Commission to exercise the
powers conferred on, and to perform the functions assigned to, it under this Act.
(2) The Central Information Commission shall consist of—
(a) the Chief Information Commissioner; and
(b) such number of Central Information Commissioners, not exceeding ten,
as may be deemed necessary.
(3) The Chief Information Commissioner and Information Commissioners shall
be appointed by the President on the recommendation of a committee consisting of—
(i) the Prime Minister, who shall be the Chairperson of the committee;
(ii) the Leader of Opposition in the Lok Sabha; and
(iii) a Union Cabinet Minister to be nominated by the Prime Minister.
Explanation.—For the purposes of removal of doubts, it is hereby declared that where
the Leader of Opposition in the House of the People has not been recognised as such,
the Leader of the single largest group in opposition of the Government in the House of
the People shall be deemed to be the Leader of Opposition.
(4) The general superintendence, direction and management of the affairs of the
Central Information Commission shall vest in the Chief Information Commissioner
who shall be assisted by the Information Commissioners and may exercise all such
powers and do all such acts and things which may be exercised or done by the Central
Information Commission autonomously without being subjected to directions by any
other authority under this Act.
(5) The Chief Information Commissioner and Information Commissioners shall
be persons of eminence in public life with wide knowledge and experience in law,
science and technology, social service, management, journalism, mass media or
administration and governance.
(6) The Chief Information Commissioner or an Information Commissioner shall
not be a Member of Parliament or Member of the Legislature of any State or Union
territory, as the case may be, or hold any other office of profit or connected with any
political party or carrying on any business or pursuing any profession.
(7) The headquarters of the Central Information Commission shall be at Delhi
and the Central Information Commission may, with the previous approval of the
Central Government, establish offices at other places in India.

Constitution
of Central
Information
Commission
.

<!-- page 11 -->

SEC.1

THE GAZETTE OF INDIA EXTRAORDINARY
13. (1) The Chief Information Commissioner shall hold office for a term of five years
from the date on which he enters upon his office and shall not be eligible for
reappointment:
Provided that no Chief Information Commissioner shall hold office as such after
he has attained the age of sixty-five years.
(2) Every Information Commissioner shall hold office for a term of five years from
the date on which he enters upon his office or till he attains the age of sixty-five years,
whichever is earlier, and shall not be eligible for reappointment as such Information
Commissioner:
Provided that every Information Commissioner shall, on vacating his office under this
sub-section be eligible for appointment as the Chief Information Commissioner in the
manner specified in sub-section (3) of section 12:
Provided further that where the Information Commissioner is appointed as the Chief
Information Commissioner, his term of office shall not be more than five years in
aggregate as the Information Commissioner and the Chief Information Commissioner.
(3) The Chief Information Commissioner or an Information Commissioner shall
before he enters upon his office make and subscribe before the President or some other
person appointed by him in that behalf, an oath or affirmation according to the form set out
for the purpose in the First Schedule.
(4) The Chief Information Commissioner or an Information Commissioner may, at
any time, by writing under his hand addressed to the President, resign from his office:
Provided that the Chief Information Commissioner or an Information Commissioner
may be removed in the manner specified under section 14.
(5) The salaries and allowances payable to and other terms and conditions of service
of—
(a) the Chief Information Commissioner shall be the same as that of the Chief
Election Commissioner;
(b) an Information Commissioner shall be the same as that of an Election
Commissioner:
Provided that if the Chief Information Commissioner or an Information
Commissioner, at the time of his appointment is, in receipt of a pension, other than a
disability or wound pension, in respect of any previous service under the Government of
India or under the Government of a State, his salary in respect of the service as the Chief
Information Commissioner or an Information Commissioner shall be reduced by the
amount of that pension including any portion of pension which was commuted and pension
equivalent of other forms of retirement benefits excluding pension equivalent of retirement
gratuity:
Provided further that if the Chief Information Commissioner or an Information
Commissioner if, at the time of his appointment is, in receipt of retirement benefits in
respect of any previous service rendered in a Corporation established by or under any
Central Act or State Act or a Government company owned or controlled by the Central
Government or the State Government, his salary in respect of the service as the Chief
Information Commissioner or an Information Commissioner shall be reduced by the
amount of pension equivalent to the retirement benefits:
Provided also that the salaries, allowances and other conditions of service of the Chief
Information Commissioner and the Information Commissioners shall not be varied to their

11
Term of
office and
conditions
of service.

<!-- page 12 -->

12

THE GAZETTER OF INDIA EXTRAORDINARY

[PART II—

disadvantage after their appointment.
(6) The Central Government shall provide the Chief Information Commissioner and
the Information Commissioners with such officers and employees as may be necessary for
the efficient performance of their functions under this Act, and the salaries and allowances
payable to and the terms and conditions of service of the officers and other employees
appointed for the purpose of this Act shall be such as may be prescribed.

14. (1) Subject to the provisions of sub-section (3), the Chief Information
Commissioner or any Information Commissioner shall be removed from his office only by
order of the President on the ground of proved misbehaviour or incapacity after the
Supreme Court, on a reference made to it by the President, has, on inquiry, reported that the
Chief Information Commissioner or any Information Commissioner, as the case may be,
ought on such ground be removed.

Removalof Chief
Information
Commissioner or
Information
Commissioner.

(2) The President may suspend from office, and if deem necessary prohibit also from
attending the office during inquiry, the Chief Information Commissioner or Information
Commissioner in respect of whom a reference has been made to the Supreme Court under
sub-section (1) until the President has passed orders on receipt of the report of the Supreme
Court on such reference.
(3) Notwithstanding anything contained in sub-section (1), the President may by order
remove from office the Chief Information Commissioner or any Information Commissioner
if the Chief Information Commissioner or a Information Commissioner, as the case may
be,—
(a) is adjudged an insolvent; or
(b) has been convicted of an offence which, in the opinion of the President, involves
moral turpitude; or
(c) engages during his term of office in any paid employment outside the duties of
his office; or
(d) is, in the opinion of the President, unfit to continue in office by reason of
infirmity of mind or body; or
(e) has acquired such financial or other interest as is likely to affect prejudicially his
functions as the Chief Information Commissioner or a Information
Commissioner.
(4) If the Chief Information Commissioner or a Information Commissioner in any
way, concerned or interested in any contract or agreement made by or on behalf of the
Government of India or participates in any way in the profit thereof or in any benefit
or emolument arising therefrom otherwise than as a member and in common with the
other members of an incorporated company, he shall, for the purposes of sub-section
(1), be deemed to be guilty of misbehaviour.

CHAPTER IV
The State Information Commission
15. (1) Every State Government shall, by notification in the Official Gazette,
constitute a body to be known as the ......... (name of the State) Information Commission to
exercise the powers conferred on, and to perform the functions assigned to, it under this
Act.
(2) The State Information Commission shall consist of—
(a) the State Chief Information Commissioner, and
(b) such number of State Information Commissioners, not exceeding ten, as
may be deemed necessary.

Constitution of
State Information
Commission.

<!-- page 13 -->

SEC.1

THE GAZETTE OF INDIA EXTRAORDINARY
(3) The State Chief Information Commissioner and the State Information
Commissioners shall be appointed by the Governor on the recommendation of a committee
consisting of—
(i)
the Chief Minister, who shall be the Chairperson of the committee;
(ii) the Leader of Opposition in the Legislative Assembly; and
(iii) a Cabinet Minister to be nominated by the Chief Minister
Explanation.—For the purposes of removal of doubts, it is hereby declared that where
the Leader of Opposition in the Legislative Assembly has not been recognised as such, the
Leader of the single largest group in opposition of the Government in the Legislative
Assembly shall be deemed to be the Leader of Opposition.
(4) The general superintendence, direction and management of the affairs of the State
Information Commission shall vest in the State Chief Information Commissioner who shall
be assisted by the State Information Commissioners and may exercise all such powers and
do all such acts and things which may be exercised or done by the State Information
Commission autonomously without being subjected to directions by any other authority
under this Act.
(5) The State Chief Information Commissioner and the State Information
Commissioners shall be persons of eminence in public life with wide knowledge and
experience in law, science and technology, social service, management, journalism, mass
media or administration and governance.
(6) The State Chief Information Commissioner or a State Information Commissioner
shall not be a Member of Parliament or Member of the Legislature of any State or Union
territory, as the case may be, or hold any other office of profit or connected with any
political party or carrying on any business or pursuing any profession.
(7) The headquarters of the State Information Commission shall be at such place in
the State as the State Government may, by notification in the Official Gazette, specify and
the State Information Commission may, with the previous approval of the State
Government, establish offices at other places in the State.

Term of office
and conditions
of service.

16. (1) The State Chief Information Commissioner shall hold office for a term of five
years from the date on which he enters upon his office and shall not be eligible for
reappointment:
Provided that no State Chief Information Commissioner shall hold office as such after
he has attained the age of sixty-five years.
(2) Every State Information Commissioner shall hold office for a term of five years
from the date on which he enters upon his office or till he attains the age of sixty-five
years, whichever is earlier, and shall not be eligible for reappointment as such State
Information Commissioner:
Provided that every State Information Commissioner shall, on vacating his office
under this sub-section, be eligible for appointment as the State Chief Information
Commissioner in the manner specified in sub-section (3) of section 15:
Provided further that where the State Information Commissioner is appointed as the
State Chief Information Commissioner, his term of office shall not be more than five years
in aggregate as the State Information Commissioner and the State Chief Information
Commissioner.
(3) The State Chief Information Commissioner or a State Information Commissioner,

13

<!-- page 14 -->

14

THE GAZETTER OF INDIA EXTRAORDINARY

[PART II—

shall before he enters upon his office make and subscribe before the Governor or some
other person appointed by him in that behalf, an oath or affirmation according to the form
set out for the purpose in the First Schedule.
(4) The State Chief Information Commissioner or a State Information Commissioner
may, at any time, by writing under his hand addressed to the Governor, resign from his
office:
Provided that the State Chief Information Commissioner or a State Information
Commissioner may be removed in the manner specified under section 17.
(5) The salaries and allowances payable to and other terms and conditions of service
of—
(a)
(b)

the State Chief Information Commissioner shall be the same as that of an
Election Commissioner;
the State Information Commissioner shall be the same as that of the Chief
Secretary to the State Government:

Provided that if the State Chief Information Commissioner or a State Information
Commissioner, at the time of his appointment is, in receipt of a pension, other than a
disability or wound pension, in respect of any previous service under the Government of
India or under the Government of a State, his salary in respect of the service as the State
Chief Information Commissioner or a State Information Commissioner shall be reduced by
the amount of that pension including any portion of pension which was commuted and
pension equivalent of other forms of retirement benefits excluding pension equivalent of
retirement gratuity:
Provided further that where the State Chief Information Commissioner or a State
Information Commissioner if, at the time of his appointment is, in receipt of retirement
benefits in respect of any previous service rendered in a Corporation established by or
under any Central Act or State Act or a Government company owned or controlled by the
Central Government or the State Government, his salary in respect of the service as the
State Chief Information Commissioner or the State Information Commissioner shall be
reduced by the amount of pension equivalent to the retirement benefits:
Provided also that the salaries, allowances and other conditions of service of the State
Chief Information Commissioner and the State Information Commissioners shall not be
varied to their disadvantage after their appointment.
(6) The State Government shall provide the State Chief Information Commissioner and
the State Information Commissioners with such officers and employees as may be
necessary for the efficient performance of their functions under this Act, and the salaries
and allowances payable to and the terms and conditions of service of the officers and other
employees appointed for the purpose of this Act shall be such as may be prescribed.

17. (1) Subject to the provisions of sub-section (3), the State Chief Information
Commissioner or a State Information Commissioner shall be removed from his office only
by order of the Governor on the ground of proved misbehaviour or incapacity after the
Supreme Court, on a reference made to it by the Governor, has on inquiry, reported that the
State Chief Information Commissioner or a State Information Commissioner, as the case
may be, ought on such ground be removed.
(2) The Governor may suspend from office, and if deem necessary prohibit also from
attending the office during inquiry, the State Chief Information Commissioner or a State
Information Commissioner in respect of whom a reference has been made to the Supreme
Court under sub-section (1) until the Governor has passed orders on receipt of the report of

Removal of State
Chief Information
Commissioner or
State Information
Commissioner

<!-- page 15 -->

SEC.1

THE GAZETTE OF INDIA EXTRAORDINARY
the Supreme Court on such reference.
(3) Notwithstanding anything contained in sub-section (1), the Governor may by
order remove from office the State Chief Information Commissioner or a State Information
Commissioner if a State Chief Information Commissioner or a State Information
Commissioner, as the case may be,—
(a) is adjudged an insolvent; or
(b) has been convicted of an offence which, in the opinion of the Governor,
involves moral turpitude; or
(c) engages during his term of office in any paid employment outside the duties
of his office; or
(d) is, in the opinion of the Governor, unfit to continue in office by reason of
infirmity of mind or body; or
(e) has acquired such financial or other interest as is likely to affect prejudicially
his functions as the State Chief Information Commissioner or a State
Information Commissioner.
(4) If the State Chief Information Commissioner or a State Information Commissioner
in any way, concerned or interested in any contract or agreement made by or on behalf of
the Government of the State or participates in any way in the profit thereof or in any
benefit or emoluments arising therefrom otherwise than as a member and in common with
the other members of an incorporated company, he shall, for the purposes of sub-section
(1), be deemed to be guilty of misbehaviour.

Powers and
functions of
Information
Commissions.

CHAPTER V
Powers and functions of the Information Commissions, appeal and penalties

18. (1) Subject to the provisions of this Act, it shall be the duty of the Central
Information Commission or State Information Commission, as the case may be, to receive
and inquire into a complaint from any person,—
(a) who has been unable to submit a request to a Central Public Information Officer
or State Public Information Officer, as the case may be, either by reason that no
such officer has been appointed under this Act, or because the Central Assistant
Public Information Officer or State Assistant Public Information Officer, as the
case may be, has refused to accept his or her application for information or
appeal under this Act for forwarding the same to the Central Public Information
Officer or State Public Information Officer or senior officer specified in subsection (1) of section 19 or the Central Information Commission or the State
Information Commission, as the case may be;
(b) who has been refused access to any information requested under this Act;
(c) who has not been given a response to a request for information or access to
information within the time limit specified under this Act;
(d) who has been required to pay an amount of fee which he or she considers
unreasonable;
(e) who believes that he or she has been given incomplete, misleading or false
information under this Act; and
(f) in respect of any other matter relating to requesting or obtaining access to records
under this Act.
(2) Where the Central Information Commission or State Information Commission, as
the case may be, is satisfied that there are reasonable grounds to inquire into the matter, it
may initiate an inquiry in respect thereof.

15

<!-- page 16 -->

16

THE GAZETTER OF INDIA EXTRAORDINARY

[PART II—

(3) The Central Information Commission or State Information Commission, as the
case may be, shall, while inquiring into any matter under this section, have the same
powers as are vested in a civil court while trying a suit under the Code of Civil Procedure,
1908, in respect of the following matters, namely:—

(a) summoning and enforcing the attendance of persons and compel them to give
oral or written evidence on oath and to produce the documents or things;
(b) requiring the discovery and inspection of documents;
(c) receiving evidence on affidavit;
(d) requisitioning any public record or copies thereof from any court or office;
(e) issuing summons for examination of witnesses or documents; and
(f) any other matter which may be prescribed.
(4) Notwithstanding anything inconsistent contained in any other Act of Parliament or State
Legislature, as the case may be, the Central Information Commission or the State
Information Commission, as the case may be, may, during the inquiry of any complaint
under this Act, examine any record to which this Act applies which is under the control of
the public authority, and no such record may be withheld from it on any grounds.

Appeal

19. (1) Any person who, does not receive a decision within the time specified in subsection (1) or clause (a) of sub-section (3) of section 7, or is aggrieved by a decision of the
Central Public Information Officer or State Public Information Officer, as the case may be,
may within thirty days from the expiry of such period or from the receipt of such a decision
prefer an appeal to such officer who is senior in rank to the Central Public Information
Officer or State Public Information Officer as the case may be, in each public authority:
Provided that such officer may admit the appeal after the expiry of the period of thirty
days if he or she is satisfied that the appellant was prevented by sufficient cause from filing
the appeal in time.
(2) Where an appeal is preferred against an order made by a Central Public
Information Officer or a State Public Information Officer, as the case may be, under section
11 to disclose third party information, the appeal by the concerned third party shall be
made within thirty days from the date of the order.
(3) A second appeal against the decision under sub-section (1) shall lie within ninety
days from the date on which the decision should have been made or was actually received,
with the Central Information Commission or the State Information Commission:
Provided that the Central Information Commission or the State Information
Commission, as the case may be, may admit the appeal after the expiry of the period of
ninety days if it is satisfied that the appellant was prevented by sufficient cause from filing
the appeal in time.
(4) If the decision of the Central Public Information Officer or State Public
Information Officer, as the case may be, against which an appeal is preferred relates to
information of a third party, the Central Information Commission or State Information
Commission, as the case may be, shall give a reasonable opportunity of being heard to that
third party.
(5) In any appeal proceedings, the onus to prove that a denial of a request was
justified shall be on the Central Public Information Officer or State Public Information
Officer, as the case may be, who denied the request.
(6) An appeal under sub-section (1) or sub-section (2) shall be disposed of within
thirty days of the receipt of the appeal or within such extended period not exceeding a total
of forty-five days from the date of filing thereof, as the case may be, for reasons to be

5 of 1908

<!-- page 17 -->

SEC.1

THE GAZETTE OF INDIA EXTRAORDINARY
recorded in writing.
(7) The decision of the Central Information Commission or State Information
Commission, as the case may be, shall be binding.
(8) In its decision, the Central Information Commission or State Information
Commission, as the case may be, has the power to—
(a) require the public authority to take any such steps as may be necessary to secure
compliance with the provisions of this Act, including—
(i) by providing access to information, if so requested, in a particular form;
(ii) by appointing a Central Public Information Officer or State Public
Information Officer, as the case may be;
(iii) by publishing certain information or categories of information;
(iv) by making necessary changes to its practices in relation to the maintenance,
management and destruction of records;
(v) by enhancing the provision of training on the right to information for its
officials;
(vi) by providing it with an annual report in compliance with clause (b) of subsection (1) of section 4;
(b) require the public authority to compensate the complainant for any loss or other
detriment suffered;
(c) impose any of the penalties provided under this Act;
(d) reject the application.
(9) The Central Information Commission or State Information Commission, as the
case may be, shall give notice of its decision, including any right of appeal, to the
complainant and the public authority.
(10) The Central Information Commission or State Information Commission, as the
case may be, shall decide the appeal in accordance with such procedure as may be
prescribed.

Penalties

20. (1) Where the Central Information Commission or the State Information
Commission, as the case may be, at the time of deciding any complaint or appeal is of the
opinion that the Central Public Information Officer or the State Public Information Officer,
as the case may be, has, without any reasonable cause, refused to receive an application for
information or has not furnished information within the time specified under sub-section
(1) of section 7 or malafidely denied the request for information or knowingly given
incorrect, incomplete or misleading information or destroyed information which was the
subject of the request or obstructed in any manner in furnishing the information, it shall
impose a penalty of two hundred and fifty rupees each day till application is received or
information is furnished, so however, the total amount of such penalty shall not exceed
twenty-five thousand rupees:
Provided that the Central Public Information Officer or the State Public Information
Officer, as the case may be, shall be given a reasonable opportunity of being heard before
any penalty is imposed on him:
Provided further that the burden of proving that he acted reasonably and diligently
shall be on the Central Public Information Officer or the State Public Information Officer,
as the case may be.
(2) Where the Central Information Commission or the State Information Commission,
as the case may be, at the time of deciding any complaint or appeal is of the opinion that
the Central Public Information Officer or the State Public Information Officer, as the case

17

<!-- page 18 -->

18

THE GAZETTER OF INDIA EXTRAORDINARY

[PART II—

may be, has, without any reasonable cause and persistently, failed to receive an application
for information or has not furnished information within the time specified under subsection (1) of section 7 or malafidely denied the request for information or knowingly
given incorrect, incomplete or misleading information or destroyed information which was
the subject of the request or obstructed in any manner in furnishing the information, it shall
recommend for disciplinary action against the Central Public Information Officer or the
State Public Information Officer, as the case may be, under the service rules applicable to
him.

CHAPTER VI
Miscellaneous
Protection of
action taken in
good faith.

21. No suit, prosecution or other legal proceeding shall lie against any person for
anything which is in good faith done or intended to be done under this Act or any rule
made thereunder.

Act to have
overriding
effect

22. The provisions of this Act shall have effect notwithstanding anything inconsistent
therewith contained in the Official Secrets Act, 1923, and any other law for the time being
in force or in any instrument having effect by virtue of any law other than this Act.

Bar of
jurisdiction of
courts

23. No court shall entertain any suit, application or other proceeding in respect of any
order made under this Act and no such order shall be called in question otherwise than by
way of an appeal under this Act.

Act not to
apply to
certain
organisations

24. (1) Nothing contained in this Act shall apply to the intelligence and security
organisations specified in the Second Schedule, being organisations established by the
Central Government or any information furnished by such organisations to that
Government:
Provided that the information pertaining to the allegations of corruption and human
rights violations shall not be excluded under this sub-section:
Provided further that in the case of information sought for is in respect of allegations
of violation of human rights, the information shall only be provided after the approval of
the Central Information Commission, and notwithstanding anything contained in section 7,
such information shall be provided within forty-five days from the date of the receipt of
request.
(2) The Central Government may, by notification in the Official Gazette, amend the
Schedule by including therein any other intelligence or security organisation established by
that Government or omitting therefrom any organisation already specified therein and on
the publication of such notification, such organisation shall be deemed to be included in or,
as the case may be, omitted from the Schedule.
(3) Every notification issued under sub-section (2) shall be laid before each House of
Parliament.
(4) Nothing contained in this Act shall apply to such intelligence and security
organisation being organisations established by the State Government, as that Government
may, from time to time, by notification in the Official Gazette, specify:
Provided that the information pertaining to the allegations of corruption and human
rights violations shall not be excluded under this sub-section:

<!-- page 19 -->

SEC.1

THE GAZETTE OF INDIA EXTRAORDINARY

19

Provided further that in the case of information sought for is in respect of allegations
of violation of human rights, the information shall only be provided after the approval of
the State Information Commission and, notwithstanding anything contained in section 7,
such information shall be provided within forty-five days from the date of the receipt of
request.
(5) Every notification issued under sub-section (4) shall be laid before the State
Legislature.
25. (1) The Central Information Commission or State Information Commission, as the
case may be, shall, as soon as practicable after the end of each year, prepare a report on the
implementation of the provisions of this Act during that year and forward a copy thereof to
the appropriate Government.
(2) Each Ministry or Department shall, in relation to the public authorities within their
jurisdiction, collect and provide such information to the Central Information Commission
or State Information Commission, as the case may be, as is required to prepare the report
under this section and comply with the requirements concerning the furnishing of that
information and keeping of records for the purposes of this section.
(3) Each report shall state in respect of the year to which the report relates,—
(a)
the number of requests made to each public authority;
(b) the number of decisions where applicants were not entitled to access to the
documents pursuant to the requests, the provisions of this Act under which
these decisions were made and the number of times such provisions were
invoked;
(c) the number of appeals referred to the Central Information Commission or
State Information Commission, as the case may be, for review, the nature of
the appeals and the outcome of the appeals;
(d) particulars of any disciplinary action taken against any officer in respect of
the administration of this Act;
(e) the amount of charges collected by each public authority under this Act;
(f) any facts which indicate an effort by the public authorities to administer and
implement the spirit and intention of this Act;
(g) recommendations for reform, including recommendations in respect of the
particular public authorities, for the development, improvement,
modernisation, reform or amendment to this Act or other legislation or
common law or any other matter relevant for operationalising the right to
access information.
(4) The Central Government or the State Government, as the case may be, may, as
soon as practicable after the end of each year, cause a copy of the report of the Central
Information Commission or the State Information Commission, as the case may be,
referred to in sub-section (1) to be laid before each House of Parliament or, as the case may
be, before each House of the State Legislature, where there are two Houses, and where
there is one House of the State Legislature before that House.

Appropriate
Government
to prepare
programmes

(5) If it appears to the Central Information Commission or State Information
Commission, as the case may be, that the practice of a public authority in relation to the
exercise of its functions under this Act does not conform with the provisions or spirit of
this Act, it may give to the authority a recommendation specifying the steps which ought in
its opinion to be taken for promoting such conformity.
26. (1) The appropriate Government may, to the extent of availability of financial and
other resources,—
(a) develop and organise educational programmes to advance the understanding
of the public, in particular of disadvantaged communities as to how to exercise
the rights contemplated under this Act;

Monitoring and
Reporting

<!-- page 20 -->

20

THE GAZETTER OF INDIA EXTRAORDINARY

[PART II—

(b) encourage public authorities to participate in the development and
organisation of programmes referred to in clause (a) and to undertake such
programmes themselves;
(c) promote timely and effective dissemination of accurate information by public
authorities about their activities; and
(d) train Central Public Information Officers or State Public Information Officers,
as the case may be, of public authorities and produce relevant training materials
for use by the public authorities themselves.
(2) The appropriate Government shall, within eighteen months from the
commencement of this Act, compile in its official language a guide containing such
information, in an easily comprehensible form and manner, as may reasonably be required
by a person who wishes to exercise any right specified in this Act.
(3) The appropriate Government shall, if necessary, update and publish the guidelines
referred to in sub-section (2) at regular intervals which shall, in particular and without
prejudice to the generality of sub-section (2), include—
(a)
(b)

(c)

(d)

(e)
(f)

(g)
(h)
(i)

the objects of this Act;
the postal and street address, the phone and fax number and, if available,
electronic mail address of the Central Public Information Officer or State
Public Information Officer, as the case may be, of every public authority
appointed under sub-section (1) of section 5;
the manner and the form in which request for access to an information shall be
made to a Central Public Information Officer or State Public Information
Officer, as the case may be;
the assistance available from and the duties of the Central Public Information
Officer or State Public Information Officer, as the case may be, of a public
authority under this Act;
the assistance available from the Central Information Commission or State
Information Commission, as the case may be;
all remedies in law available regarding an act or failure to act in respect of a
right or duty conferred or imposed by this Act including the manner of filing
an appeal to the Commission;
the provisions providing for the voluntary disclosure of categories of records in
accordance with section 4;
the notices regarding fees to be paid in relation to requests for access to an
information; and
any additional regulations or circulars made or issued in relation to obtaining
access to an information in accordance with this Act.

(4) The appropriate Government must, if necessary, update and publish the guidelines at
regular intervals.

27. (1) The appropriate Government may, by notification in the Official Gazette,
make rules to carry out the provisions of this Act.
(2) In particular, and without prejudice to the generality of the foregoing power, such
rules may provide for all or any of the following matters, namely:—
(a)
(b)
(c)
(d)

the cost of the medium or print cost price of the materials to be disseminated
under sub-section (4) of section 4;
the fee payable under sub-section (1) of section 6;
the fee payable under sub-sections (1) and (5) of section 7;
the salaries and allowances payable to and the terms and conditions of service
of the officers and other employees under sub-section (6) of section 13 and

Power to make
rules by
appropriate
Government

<!-- page 21 -->

SEC.1

THE GAZETTE OF INDIA EXTRAORDINARY
(e)

(f)

21

sub-section (6) of section 16;
the procedure to be adopted by the Central Information Commission or State
Information Commission, as the case may be, in deciding the appeals under
sub-section (10) of section 19; and
any other matter which is required to be, or may be, prescribed.

28. (1) The competent authority may, by notification in the Official Gazette, make
rules to carry out the provisions of this Act.

Power to make
rules by competent
authority.

(2) In particular, and without prejudice to the generality of the foregoing power, such
rules may provide for all or any of the following matters, namely:—
(i)
(ii)
(iii)
(iv)

the cost of the medium or print cost price of the materials to be disseminated
under sub-section (4) of section 4;
the fee payable under sub-section (1) of section 6;
the fee payable under sub-section (1) of section 7; and
any other matter which is required to be, or may be, prescribed

29. (1) Every rule made by the Central Government under this Act shall be laid, as
soon as may be after it is made, before each House of Parliament, while it is in session, for
a total period of thirty days which may be comprised in one session or in two or more
successive sessions, and if, before the expiry of the session immediately following the
session or the successive sessions aforesaid, both Houses agree in making any modification
in the rule or both Houses agree that the rule should not be made, the rule shall thereafter
have effect only in such modified form or be of no effect, as the case may be; so, however,
that any such modification or annulment shall be without prejudice to the validity of
anything previously done under that rule.

Laying of rules.

(2) Every rule made under this Act by a State Government shall be laid, as soon as
may be after it is notified, before the State Legislature.

30. (1) If any difficulty arises in giving effect to the provisions of this Act, the Central
Government may, by order published in the Official Gazette, make such provisions not
inconsistent with the provisions of this Act as appear to it to be necessary or expedient for
removal of the difficulty:

Power to remove
difficulties.

Provided that no such order shall be made after the expiry of a period of two years
from the date of the commencement of this Act.

Repeal

(2) Every order made under this section shall, as soon as may be after it is made, be
laid before each House of Parliament.
31. The Freedom of Information Act, 2002 is hereby repealed.

5 of 2003

<!-- page 22 -->

22

THE GAZETTER OF INDIA EXTRAORDINARY

[PART II—

THE FIRST SCHEDULE
[See sections 13 (3) and 16(3)]
Form of oath or affirmation to be made by the Chief Information
Commissioner/the Information Commissioner/the State Chief Information
Commissioner/the State Information Commissioner
"I, ....................., having been appointed Chief Information Commissioner
/Information Commissioner / State Chief Information Commissioner / State
Information Commissioner swear in the name of God
solemnly affirm
that I will bear true faith and allegiance to the Constitution of India as by
law established, that I will uphold the sovereignty and integrity of India,
that I will duly and faithfully and to the best of my ability, knowledge and
judgment perform the duties of my office without fear or favour, affection
or ill-will and that I will uphold the Constitution and the laws.".

<!-- page 23 -->

SEC.1

THE GAZETTE OF INDIA EXTRAORDINARY

23

THE SECOND SCHEDULE
(See section 24)
Intelligence and security organisation established by the Central Government
1. Intelligence Bureau.
2. Research and Analysis Wing of the Cabinet Secretariat.
3. Directorate of Revenue Intelligence.
4. Central Economic Intelligence Bureau.
5. Directorate of Enforcement.
6. Narcotics Control Bureau.
7. Aviation Research Centre.
8. Special Prontier Force.
9. Border Security Force.
10. Central Reserve Police Force.
11. Indo-Tibetan Border Police.
12. Central Industrial Security Force.
13. National Security Guards.
14. Assam Rifles.
15. Special Service Bureau
16. Special Branch (CID), Andaman and Nicobar.
17. The Crime Branch-C.I.D.-CB, Dadra and Nagar Haveli.
18. Special Branch, Lakshadweep Police.

T. K. VISWANATHAN,
Secy. to the Govt. of India.
Printed by THE Manager, Government of India Press, Minto Road, New Delhi
and Published by the Controller of Publications, Delhi, 2005.
MGIPMRND—1359GI(S3)—22-06-2005.
