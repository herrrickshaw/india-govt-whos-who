---
doc_id: "b09fbf6a1ce8d8ff"
source_url: "https://tgredco.telangana.gov.in/Updates_2022/PAT_SCHEMES/PAT_NOTIFICATIONS/PAT_Cycle_I.pdf"
ministry: "Telangana State Renewable Energy Development Corporation Ltd., (TSREDCO), Telangana"
title: "Cycle I"
date: ""
pages: 107
method: "tesseract:tel+eng"
script: "TELUGU"
needs_ocr: false
sha1: "0edf7c5f1c67e278"
---

<!-- page 1 -->

గళ్ళ ఇం అం ₹₹0-3300499 sti. REGD. NO. D.L.-33004/99
1/11
న.
SANT
| EXTRAORDINARY
ATT WUE 3_20-VUTS (il)
PART Il-—Section 3—Sub-section (ii)
ఛాలా & weir
PUBLISHED BY AUTHORITY
7 ఇ 603) ఇభ సాగి errant, ret 30, 2012 10, 1934
No 603} NEW DELHI, FRIDAY, MARCH 30, 2012/CHAITRA 10, 1934
ఇంగ
aftagerr
క్యా గాలి 30 Ard, 2012
Wa, 687(3ఫ).-టాషా ween, Sah జా లతా, 2001 (2001 ఇ 52) Hr ene 14 & as
(8) ait Gs @) GT ver క ar watt aa EU, Soft aera Rt & uot a, కాం dat
ARO ఖా (2) A ఈసా పసం sos & fae gH Beer అం & Tass (4) భి aceut
sft 4 ఆనం zal wos క్‌ తి ఖాలి wt gah Hal Woe ఫి ada Ha అ Way స 2012-
- 13 ₹ 2014-15 aa Fr soft & fer sat dent (sa sashes & fae sah wor were sie
arte, wea che fr wae dan, aan aa ar ater, Sol see var ont aaa Ar afar se
' Wea Hg Hat ఫ్‌ Tages Atel car Ia ఖా AA) fev, 2012 క & ater Penge, Fat waa wa
ఖాన & ea A ot ow doer భాగ్‌ & RTH (3) & sfeate sera Soh తాగా కాగా 3
ares వ సవర ఇరు కే గ :-
1170 GY2012 (1)
లు...

<!-- page 2 -->

2 THE GAZETTE OF INDIA : EXTRAORDINARY [Past గారం. 308,
deer BOT
(1 weqfatret
శ కనక! కాల్ల a4 ఆగ fet శ | alata కో &
wear a fae seme & of ate & | fae sens
waged da & Het cat wife afer a
(ahs A ane sar తాగ | శాస్త్రాల det ₹
ware ate Arr (ల్‌ Sst .
wre WATT
att ARR
యో తూ లా.
గా ర్యా atk Wet జాతో (దా ఖా Pas salt
WIA (SMS BT | FMEA (a) | WIT (SME
arsitgeen ar రేకుల
Renal gseerat సాం 376733 0.231
a a = a 7 m
aca
aga aeaprtee ats 762195 0.304
766027
atgrir
aie రాల ళా ఫాల fares
ఇగ్యాల feret-763008
న!
అాలం ఆతా aes 0.674 0.598
| or = “ene ee |
ands
cil ™ meee ep |
oder ~
జానా కాళ క్‌ 4.776 4.567
768016, 3itSterr ,
PR Heater ఖో ees 5.474 383988 $.199
a Wa us th arectene, ఇలా వాతా లాల , Fare
Bite, Fret-759145, Here
aaa aegfrtan fates 6.028
aisrir

<!-- page 3 -->

[ఇ wee 3(ii)) SRA a TT: TET 3
SS నవవ
i a a
ara, Tat He TST fate sat [sear ar | గగ
: WT (SNS HT | SMe (ea) | తాం (SMT
లేిష/ల్లా ar గ్రేంగెటరా)
న నరా fafaes 5.858 388869
కశాం [జైల గొల గాణ గ231217
రర weer
శ Cote 0. 2, కాగ్ళ్గకళి celta, ₹0ఖ0 adr పళ్ళు
fora ware, Pret-410208
తరగాలి
: (il) తాగాలి
1.) anféea న sar fates 0.997 90,777 0.928
wea US, S10 eon, నాం ware, 822124
కా
తలా షణ వం గం కా tate 0.273 94,527
feat SAMs, 362266
apSRTT
3.| dharcoee ఇం fees 49,942
gt
Haceree TAA PO FAT [3] 57,808
afar ang :
Shiva ara aelfeses fo irra ఇంగా ve | 0.305 106,142 0.287
eign కళళ)
FAN-Hool Faas, Are Aa, HeT-324004
మ.
తళలన్నా గాలికి 85,678 0.286
కారా Foret గభాగిడా, 628229
7. gsedra feo, bite fact 0.310 226,141
. titer tora area, Arey, 456331
వాలా weer
: JPR ఉననా sik afer fares 266,402 0.249
392130 |
వారగా లా Hh ఫాలం aS 0.277 179,708 0.262
కా గిల్లింపిగాాాలర్ళా Bar agler, 391346 |
HK ee తే
ee

<!-- page 4 -->

4 ‘THE GAZETTE OF INDIA : EXTRAORDINARY [Paar I—Sec. 3(0)]
se అనాం బా
వా et atk భ్‌ నా | SG aT fate Sait
waa seme an | sured (eat) | WOT SUE
eras et) a fais /e)
O} aparerel ఇ్యాోకళాత్యా రాక్‌ 0.286 54,736 0.271
care 0 12/0, seat భకత HECHT TT, :
fare,
NTA
eet ahidrnora waar, భా 60,682 0.548
afar ag
12) ళం THe సగాళాతల్న WHT (ఖగ 0.347 96,637 0.324 .
ann tape HAAR
SA WERT
age at seach (గక 0.412
న్న ఇళా[ి-460, THOSTSOTO, HAA, 301030 [|
Tea
Aaa agatha fates 0.967 61,796
at. ayant, Fete, 392130
eT :
ఇనా తాలి Tos tirana Terres 88,959 0.299
tare
గాం ఆయా సాగా 0.310 173,885
a — ee ae
TNT
17! Rta Heche రాక Abit 0.990 112,135
zag, hangera softer ete, కాగా, fete
ae, 393110
Deng
13] కానన అగాగాల Haters 75,833 0.287 ~
aia weteh, arene, కళా a0: 52, TTY, STAT
ude
న్‌ :
1a) ay తాత? పలానా wos Tangs hire feo | 0.333 116,716 0.312
TSO, PLATT
BIT Wear
202 31% are TO, పాలా wos అరా? ఉంగా 99,180
ఇక HOTA AS, SeeFOMO, 534318
HIT TART

<!-- page 5 -->

Cart ers 3(ii)] Ae ఇ UGA: TET క్‌
——— లైతే
గ 2222
౨ తా కానన నాం.
తా vat ait భా fafiwe sai see TT faferse Sait
Wa (Seu BT | Seas (eA) | Wat (See
ల aaitg sen) ఖా dais /eat)
21] greater భళా సాలా? గాం oo గ్ర
ఆళాశాకనా తలి, 683501
aT
arises otek fares 0.286 0.271
. 750 చికను కారం అతిగా, 393110
కరే
1) ఖా
“| తార series fears 0.386
tot
site ఆలా faites aE Tea) 27650
User
aiorten ళా feats (భో WaT) 0.204 41377
wane WS, Terre, 148102
dst
woo గా సాలా 0.697
144 Prosto అలా గాం శ సాం
భాణూా
తనఖా కాటా adh (war TEA గితా్యా 0.619 0.584
Wa గాషా[-254/261/268 Wa-aTAeM, SHEN 43, గారి
396191
aSRTT
తం గయా few atta ఇల Azz గం) 14355
wile aao-14, A కళా? wa, Hedidr, సజ
Waa, 462046
ata Weer
7.| ata గాలా సూర 0.883 9098 0.821
. arr 0-107, Tigaredren aur, Bede Us, stra,
311001 :
: Wee
లా సాగా Pew 0.371 20743 0.357
కారా 0-21, Ssegrrat Often, సార 148023
dara
Meee (eater BIRT 0.440 16740
arm గం, AS Vs, Tey, TAMAS, RraT-BleeT 173205
ee

<!-- page 6 -->

6 ‘THE GAZETTE OF INDIA : EXTRAORDINARY [Parr 1-59. 3(ii)]
ట్‌ మారా
, qua (seme ar | scorer (em) | కాగ (ర
ets ea) భా లగ
త్‌ ee eee
Beope a ae Rare fetes, భారా గరా 6826
fare, Tae
రా గాక
anfta fees 17750 2.798
పు. | aren -arererat, నాశ గ సాయి 382721 -
apa
Rite vise fares carr spe Sart) 1.791 3857
12. | రాక wagR He, ధారా 380022
తలగ
By గా Gree కా wea ఇ సం) ఓ
gag
arg as, mel, avatars, సాగినా, 173208 ”
సాం ఇట
కాం గారా fortes 0.478
ea
గాణ
ad fier గాగ 1.108 1.086
aa
ఇరా agers 1.080 76854
కాకా, eta, తోరా (RTA, 394120
aaa
frat లాం? Pes dae Hite wt 0.489 20175 0.464 ఆ
ప. జరా? సక ఖా TTI
ఇళ్ల ts, ఇట్‌ సొానాఇినా, 173205 .
జాం!

<!-- page 7 -->

(MT aE 3(0) BRN TST : TTT ?
Ce a ననన వన న
| ama, రగా st భా గా Sait గజ కాగ్‌
Wa (SNE ₹ wad (see
lee |
area tare theret faites 2.167
== ee
ఇాగరా |
భారా RRS URE కాగా 0.762 9446
కాగా ₹ేం-16, కరా శినాక 311001
వాన గం 0.736 5058 0.697 .
arp 80-17, asta, చకా 11001
పలా coef ies 0.812 0.797
13 అౌంథాం Tea, WaT, TIGR ds, శ్యాం
- 22. | Gaal sar గరా 1,055
కాకలు stare, సాగాళా, 411026
AERTS
స్వాన్‌ త్యాగి aeq wes aaa sar సం) 0.0102 5982471 0.0101
3. | ras Ho-22, aE Vs, were, సాం eer, 421103,
FER
unist Renta far) ₹0సొం 0.720 5137 0.679
24 | దాతగా as, aiaaifiggg, Beara, 311001
eee ee
25. | Seiwa శాక్‌ 0.290 14520
కాగా 0-59, asda Aor Wiss, ax
[igen
26. | dru యాళ్ల feo 1.863 8328 1.778
121, టాం Ofer, ఇటీ Prenatal, 173205
ఫలాల ceed Ws wae faites 0.710 6346 0.658
aa
416234 ’
ess

<!-- page 8 -->

8 THE GAZETTE OF INDIA : EXTRAORDINARY [Part 1-5౬. 3(0)]
a ననా
wad (scare ar | seat (eA) | SIA (గా
dais /eay ar లేరా)
sottiosso కాంలథన గం 20754
ae US, AAV, సొాగాశిణల, 174101 :
గాగ weer
aie పంల గానక 0,199 19981
591308 :
గి water
Baa tara (Gilera సాగా శా faferes fe aera) | 2885 2.720
30. | గాత FIAT. SFIS, 362266
PN :
. Set arse goede feines 0.818 6155 0.752
త, THERM, TRH Aerts, భోగిగా 416234
FERS ‘
' aA, సాక్‌ werarst 4.577 6513 4.196
ofa. Us, కాగాక. 144401
aaa
ier argo FerO 0.596 0.568
33. | భాసా ater శోక పలాల రాజూ
waret భంగ ఇ ఇరగ గాం 0.346 10292 0.327
ఇల? Pier Hae నాగ ఖా! ఇంగొ, సా కా
424001
AERTS
aaa 3fesar feo 0.714 13212 0.674
. ఇగాల తళా
ఇగ
PAN భోలా గ wo feo 2700 4.667 య
36. | waang గం 108/1, dodioanta భర్‌ ఇఇ,
HeAATMS, 382402
DONG! .
37. | ఇాంంాం fea feo ar 0.658 5447
va

<!-- page 9 -->

(9M జాక్‌ 3(ii)] బాం Fl భాగా see 9
SSS
aa, Tat తిం Wea fafwe wat | seme ar fates Sait
aaa (seme ay | దాదా (eet) | GU Gee
asta) ar eget}
. ae
aire ag
. 38. | daa శారాను కా aes 0.395 14689 0.384
22/4 గాం edie ste ao 2 భనం 628501
: afr arg
Ho భా art కాలిన few fo, ae - 2.448 10946 2.341 +
. | సా కాలా? fret ws ghee fend
tho ao-#4, తలా te, rah, 127021
లా
auctor ఇల foo trace సలం arias | 3175 4824 3.039
40.
afte
Todo 40-455, భాగా vs, anfSars, 387001
Isnt
Fenn at sae fara fafees 0.646 24493 0.616
Gell HRS, 306401
Wael
42. | వారా ier citer ea fo 12397 0.323
: wWamte VS, WATE, 148101
ర.
Tea aiead శా సాం Ro 0.591 9178 0.555
173025
శాం veer
44. | Aisa గి రాం faites 2502 5.738
iodo 40-6, శాఖా Ys, Hear
త్త.
45. | art tatersea fares 4.221 2932 3.883
. cere 4o-oft-2, శాంగకేి, Geant, ore -erensaran,
చార 441110 :
__| HERTS -— .
t 46. | nex కాలాన కాటి సాం 0.270 12619 0.258
| St sree, Toso, sus, (rem atereht
1170 G2012—2
ee

<!-- page 10 -->

10 THE GAZETTE OF INDIA : EXTRAORDINARY [Part 1-50. 3(ii)]
ep OU యా
ara, Get 3 WHT faftise sat =| Sear aT fafise sath
woe (యట్‌ a | SMe (a) | WI (STIG
ats /Ta) at €i3its/ea)
See
ఛాలా
ary యనా Tes సో 0.681 10220
మట.
ఇరా గటా?
49. | fafaa ఇళ 1షం 1.349 23531 1.216 .
16-17 సొంతం la, Fads ds, అకా సాలా
ఛాలా
గాల Rares (sto కళ sesegter సం) 0.788 13379 0.723
Teas
నన
51. | ఉత రసా? fees 0.743 6745 0.686
Peete న
TERT
wh at traegea fafaes 0.272 20090 0,267
UAC: 07, కాజా THEIR సంగా,
442305
FRITS:
గాధల ఇలా ఇలలో 0.301 0.291
తాగారా సం Wace ఇకా? 0.946 7128 0.852
ఇంఖం 0-13, Raisers Us, వాకా పతాక
311001
ఛాణుగ
tort Gas (1 Bae గా చా సాలా FA) 0.651 10250 0.617 |
11-12 Rrosto ఆలం ఖంచ్చాక గెలక శె
తినక?
గాణ
