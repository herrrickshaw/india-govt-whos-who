---
doc_id: "f7afdf90d11cf74c"
source_url: "https://horticulture.tg.nic.in/Downloads/2026/Transfer/JDH%20Incumbency%20list.pdf"
ministry: "Horticulture Department, Telangana"
title: "JDH Incumbency list"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9aad171cd325c957"
---

<!-- page 1 -->

GOVERNMENT OF TELANGANA
DEPARTMENT OF HORTICULTURE
GENERAL TRANSFERS 2026 JOINT DIRECTOR OF HORTICULTURE
-

INCUMBENT LIST : STATE CADRE : AS ON 20-04-2026

Sl.

Employee

No

Post Regular
Employee Name Gender

Date of Birth

Native District

5

6

Date of

Retirement

Mobile
Number

Current Designation

Place of

working

Deputation/
Other Duty

basis
1

3

2

4

7

8

10

9

11

Date of
present place
of Joining

Length of service
in the present
station ason Ol01-2026

12

13

Transfer

14

Compulsory (As
1

1600495

B Babu

Male

25/04/1966

NALGONDA

30/04/2027

8977714519

Joint Director of
Horticulture
[General

Manager

HYDERABAD

Deputation

04-05-2018

7

years and 8
months

per transfer G.O
he may be

exempeted as
going to retire on
30-04-2027)

2

2548402

V Sarojini Devi

Female

15/06/1971

GUNTUR

30/06/2032

8977714504

3

901649

K Ramalaxmi

Female

01-07-1967

KURNOOL

30-06-2028

8977714507

4

2559819

P

Sunitha

Female

23/06/1967

MAHABUBNAGAR

30/06/2028

8977714515

5

2559820

N Sunanda Rani

Female

21/02/1978

NIZAMABAD

28/02/2039

8125966536

Additional Director of
Horticulture (Against)
Joint Director of
Horticulture

Joint Director of
Horticulture

HYDERABAD

Regular

25-09-2019

HYDERABAD

Regular

23-04-2023

HYDERABAD

Deputation

09-10-2023

HYDERABAD

Deputation

09-10-2023

NIZAMABAD

Deputation

05-08-2024

HYDERABAD

Regular

26-05-2025

Joint Director of

6

339722

B Srinivas

7

1008369

G Sangeetha
Laxmi

26/09/1966

WARANGAL

30/09/2027

8977714031

25/06/1976

RANGAREDDY

30/06/2037

8977714155

Horticulture/

Chief Horticulture officer
Joint Director of
Horticulture
/DH&SO

Joint Director of
Female

Horticulture

Note : All 4 years and above length of service are liable for compulsory transfer subject to Para 4B/ 5A of
GO.Ms. No.38, of Finance (HRM-I) Department dt.21-04-2026.
-05-2026
Date
.

Place : 010 Director of Horticulture
Telangana Hyderabad

6

years and 3
months

2

years and 8
months

2

years and
months

3

2

years and
months

3

1

year and 5
months

0

years and 7
months

Compulsory
Not Compulsory
Not Compulsory
Not Compulsory

Not Compulsory

Not Compulsory
