---
doc_id: "eaefc4ab69fbe2ae"
source_url: "https://invest.telangana.gov.in/wp-content/themes/investtelangana-theme/assets/docs/policies/telangana-ev-ess-policy-2020-2030.pdf"
ministry: "Invest Telangana"
title: "Electric Mobility & Energy Storage   Telangana Electric Vehicle & Energy Storage Policy     2020–2030   PDF · 2.7 MB     View the document"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5855318548b7df4e"
---

<!-- page 1 -->

TABLE OF CONTENTS

TABLE OF
CONTENTS
Preamble

5

1.

Vision

6

2.

Mission

6

3.

Policy Objectives

7

4.

Implementation Strategy

8

5.

Policy Period

9

6.

Policy Measures

9

7.

Demand side Incentives

10

8.

Charging Infrastructure

11

9.

EV in Shared Mobility & Public Transport

12

10.

Supply Side Incentives

12

11.

Support for Manufacturing

13

12.

Other Initiatives

14

13.

Stakeholders

15

14.

Steering Committee

15

15.

Conclusion

16

Constitution of Steering Committee

16

Department Views/Suggestions received
for Electric Vehicle & Energy Storage Policy

17

<!-- page 2 -->

PREAMBLE

Energy Storage Solutions (ESS) provide alternative to energy backup for
home, enterprises & businesses, and are ideal for integrating renewable
energy into the electricity grid.
In March 2019, The Government of India (GoI) has launched the National
Mission on “Transformative Mobility and Energy Storage” committed
to develop a complete ecosystem domestically around EVs, including
manufacturing of batteries and all other components to make Electric
Vehicle and Energy Storage Solutions sector competitive in the near
term. Further, India is committed to reducing emissions up to 33-35% by
2030 from the 2005 level and has set the target of 40% non-fossil-based
electricity generation in the energy mix. This requires radical measures to
scale up the share of renewable energy, besides the ongoing program of
175 GW RE by 2022.
According to data compiled by IESA, the electric vehicle industry
consumed over 5 GWh of batteries in 2018 in India. This number is likely
to be over 36 GWh by 2025. During 2020-2027 period, the EV sector is
estimated to consume about 250 GWh of batteries.
The ‘Telangana Electric Vehicle & Energy Storage Policy 2020-2030’ builds
upon FAME II scheme being implemented since April 2019 by Department
of Heavy Industries, Govt. of India, where it also suggested States to offer
fiscal and non-fiscal incentives to further improve the use case for adoption
of EVs.

PREAMBLE

The advent of new breakthroughs and improvements in energy
storage is transforming vehicular technology and energy solutions.
Electric Vehicles (EVs) are a promising alternative to ICE (Internal
Combustion Engine) vehicles. Innovations in battery technology,
reduction in moving parts, and zero tailpipe emissions make EVs an
economically viable and sustainable mobility solution that is finding
global support from Policymakers and Industry leaders alike.

5
EV ESS POLICY 2020-2030

<!-- page 3 -->

1.VISION
To make Telangana a hub for Electric Vehicles & Energy Storage Systems

2. MISSION
a)

To make the State an attractive investment destination for this sector

b)

To promote R&D and manufacturing in Electric Vehicle & Energy Storage Systems’ sector

c)

To ensure faster adoption of Electric Vehicles & Energy Storage Systems in the State

d)

To achieve substantial reduction in total cost of transportation for personal and commercial
purposes, supported by a world-class infrastructure

6
EV ESS POLICY 2020-2030

<!-- page 4 -->

3. POLICY OBJECTIVES
a)

c)

e)

g)

To reduce the total cost of mobility
by increasing the adoption of Electric
Vehicles in public transportation, 2 & 3
Wheelers, 4 wheelers, Light Commercial
Vehicles & Shared Transportation.
b)

Promoting a shift from dependence on
fossil fuels which are mostly imported and
expensive with unreliable supply during
times of crisis, to reliable domestically
produced renewable energy which is less
expensive.

d)

To make Telangana a major base for EV
& ESS sectors and to attract investments
worth $ 4.0 Billion and create employment
for 120,000 persons by year 2030
through EVs in shared mobility, charging
infrastructure development and EV & ESS
manufacturing activities.

f)

To proactively support creation of EV
charging Infrastructure in the initial
phase and eventually create market for
commercially viable EV Charging business.

h)

Develop Telangana as a global center for
cutting-edge research and innovation
in Electric vehicles, battery technologies
and other emerging technologies such as
Autonomous/Connected vehicles.

Make Telangana state the preferred
destination for Electric Vehicle, ESS and
component manufacturing.

Generate demand for battery storage
solutions by driving EV adoption
incentives and supply side incentives for
battery manufacturing.

Promote Recycle and Cascading of
Batteries

7
EV ESS POLICY 2020-2030

<!-- page 5 -->

4. IMPLEMENTATION STRATEGY
a)

Incentives shall be made available for Manufacturing of Electric Vehicles, Energy Storage
Systems & related components in Telangana. Incentives shall include Capital Subsidies, SGST
reimbursements, power tariff subsidies, etc.

b)

Incentives shall be made available for 2 & 3 Wheelers, 4 wheelers, Light Commercial Vehicles,
Shared Transport & Public Transport. The incentives shall include waiver on Road Tax &
Registration Charges

c)

Incentives shall be provided for charging infrastructure

d)

Ride hailing services shall be encouraged to operate electric 2, 3 & 4 wheelers through
incentivization.

e)

Battery operated feeder shuttle services at all Hyderabad Metro Stations for last mile connectivity
shall be made available.

f)

Existing state self-employment schemes shall be extended to provide financial assistance for
purchase of Electric Vehicles for commercial purposes.

g)

Adoption of EVs at Institutional Level shall be promoted starting with Government entities.

h)

Preferential parking slots with required charging infrastructure shall be made available for Electric
Vehicles.

i)

Preferential Procurement to Make in Telangana Electric Vehicles and Energy Storage Systems for
Government Orders shall be provided.

j)

State Govt shall facilitate in dovetailing with Govt. of India (GoI) schemes and encourage state
stakeholders to avail benefits available under GoI schemes.

8
EV ESS POLICY 2020-2030

<!-- page 6 -->

5. POLICY PERIOD
This policy is applicable for a period of 10 years from the date of
notification of this policy. The policy shall be reviewed by the Steering
Committee as notified in this policy.

6. POLICY MEASURES
The policy aims to build on the policy objectives & strategies to
encourage growth of EV & ESS sector in the state and to attract private
sector investments in this sector. The framework consists of promoting
EV adoption for end users, setting up of Charging Infrastructure and
Promoting Manufacturing of EV & ESS Components in the State.

9
EV ESS POLICY 2020-2030

<!-- page 7 -->

7. DEMAND SIDE INCENTIVES
Following are the demand side incentives proposed under the Telangana
State Electric Vehicle and Energy Storage Policy 2020 – 2030 to incentivize
usage of Electric Vehicles in the state of Telangana.

A.

Incentives for Electric Two Wheelers

i)

B.

100% exemption of road tax & registration fee for the first 2,00,000 Electric 2 Wheelers
purchased & registered within Telangana.

Incentives for Three-Seater Auto-Rickshaws

i)

100% exemption of road tax & registration fee for first 20,000 Electric 3 Wheelers purchased &
registered within Telangana

ii)

Retro-fitment incentive at 15% of the retro-fitment cost capped at Rs. 15,000 per vehicle for
first 5,000 retrofit 3 seater auto rickshaws in Telangana

iii)

Financing Institutions shall be encouraged to provide a hire-purchase scheme at discounted
interest rates.

C.

Incentives for Electric 4-Wheeler commercial passenger Vehicles such as Taxi, Tourist Cabs, etc.

i)

D.

Incentives for Light Goods Carriers - including Three Wheelers (goods)

i)

E.

100% exemption of road tax & registration fee for first 10,000 Electric three-wheeler (goods),
e-carriers as well as electric Light Goods carriers purchased & registered within Telangana

Incentives for Private Cars

i)

F.

100% exemption of road tax & registration fee for the first 5,000 Electric 4-Wheeler commercial
passenger Vehicles such as Taxi, Tourist Cabs, etc. purchased & registered within Telangana

100% exemption of road tax & registration fee for the first 5,000 Electric 4-Wheeler private
vehicles purchased & registered within Telangana

Incentives for Buses

i)

100% exemption of road tax & registration fee for the first 500 Electric buses purchased &
registered within Telangana.

ii) State Transport Units shall also be encouraged to purchase Electric buses.

G.

Incentives for Tractors

i)

100% exemption of road tax & registration fee shall be applicable for electric tractors purchased
and registered in the state of Telangana as per the existing rules/guidelines applicable for
tractors by Transport Department, Govt. of Telangana.

10
EV ESS POLICY 2020-2030

<!-- page 8 -->

8. CHARGING INFRASTRUCTURE
Availability and accessibility of EV charging infrastructure is a pre-requisite
for the penetration of Electric Vehicles.
A.

Support for Charging Infrastructure

i)

Government shall facilitate setting of up initial batch of fast charging stations in Hyderabad
and other towns in a phased manner, by state entities and private players.

ii)

Telangana State Electricity Regulatory Commission shall provide special Power Tariff category
for Electric Vehicle Charging Stations.

iii)

TSREDCO (State Nodal Agency) shall evaluate to establish public charging stations directly or
under licensee/franchise/PPP model. Various public places such as airports, railway/ metro
stations, parking lots, bus depots, markets, petrol stations, malls & electric poles shall be
examined for the same.

iv)

A viable business model shall be developed for private players to set up ARAI compliant EV
charging/swapping infrastructure. Specifications for charging infrastructure shall be defined
by the Transport Department/ TSREDCO/ITE&C Dept.

v)

TSREDCO (State Nodal Agency) in coordination with State DISCOMS shall ensure Supply of
Renewable energy for EV charging stations & setting up of solar rooftop plants as per net
metering policy and captive power plants shall be encouraged as per the TSREC Guidelines.

vi)

Existing Residential Townships with 1000+ families shall be encouraged to develop charging
stations lots.

vii) Charging/ swapping station for every 50 km within state boundaries on highway to cities like

Bengaluru, Mumbai, and Chennai, followed by other national/state highways shall be
		encouraged.
viii) HMR stations and TSRTC Bus depots (across the state) shall provide reserved parking and

charging points for two-wheelers in their parking zones to encourage EVs for last mile
		commute.
ix)

Government shall develop Night time community parking with charging facility in PPP mode
for e- Autos, Shared mobility taxis and public transport vehicles within Industrial zones.

x) A battery disposal infrastructure model shall be created to facilitate deployment of used EV
		batteries.

11
EV ESS POLICY 2020-2030

<!-- page 9 -->

9. EV IN SHARED MOBILITY &
PUBLIC TRANSPORT
i)

Government shall encourage EV adoption in Shared Mobility, Public Transport, Institutional
Transport, Logistics & Delivery Services.

ii)

Govt shall facilitate aggregators involved in public transportation with regulatory support to
enable them to convert their fleet to EVs.

10. SUPPLY SIDE INCENTIVES

Telangana aspires to be the forerunner in Electric Mobility and Energy Storage space in the country.
Local manufacturing and R&D are key to reaching price/performance parity between Electric and ICE
Vehicles. Hence, support shall be extended to EV & ESS, ancillary & charging infrastructure & swapping
infrastructure manufacturers through policy interventions and Incentives.

12
EV ESS POLICY 2020-2030

<!-- page 10 -->

11. SUPPORT FOR
MANUFACTURING
i)

EV & ESS sectors shall be incentivized as per the subsidies and incentives available under the
Electronics Policy 2016.

ii)

Government shall extend tailor-made benefits to Mega and Strategic Projects on case

to case basis. Investment of more than Rs.200 crores in plant and machinery or providing

employment to more than 1000 persons shall be categorized as mega project.

iii)

The highlights of the Electronics policy are as below:

a.

Capital Investment Subsidy: 20% of investment capped at 30 Cr. for Mega Enterprises.

b.

SGST Reimbursement: 100% net SGST reimbursement capped at 5 Cr. per year with a

cumulative cap of 25 Cr. over a period of 7 years for Mega Enterprises.

c.

Power Tariff Discount: 25% for 5 years capped at 5 Cr. for Mega Enterprises.

d.

Electricity Duty Exemption: 100% for 5 years capped at 0.5 Cr.

e.

Interest Subvention: 5.25% for 5 years capped at INR 5 Cr.

f.

Transportation Subsidy: 60% with 10% reduction YoY - for 5 years; capped at INR 5 Cr.

g.

Stamp Duty/ Transfer Duty/ Registration Fees Reimbursements: 100% on first, 50% on

second transaction

h.

Lease Rental Assistance, Assistance in Patent Filing, Reimbursement of Quality

Certification costs, Cleaner Production cost reimbursement, Exhibition Cost

Reimbursements, Skill Development Assistance.

iv)

Electronics Manufacturing Clusters (EMC) and Industrial Parks are identified for promotion

of EV & Energy Storage manufacturing companies. Currently EMCs exist at Raviryal and

Maheshwaram, a designated industrial park at Divitapally for Energy Storage manufacturing,

with additional parks being designated.

v)

Batteries and related components make up a substantial part of EV. Manufacture and

assembly of EV related batteries and cells shall be encouraged in the State through

Electronics Manufacturing Policy and Incentives.

vi)

The Government shall promote reuse of EV batteries in stationary energy storage applications.

The government shall enable collaborating between cell/ battery manufacturers, EV

manufacturers, energy storage operators & recyclers to ensure efficient reuse & recycling of

		batteries.
vii) Urban Mining of rare materials and cell/ battery recycling shall be incentivized on par with EV

& ancillary manufacturing.

13
EV ESS POLICY 2020-2030

<!-- page 11 -->

12. OTHER INITIATIVES
A.

EV & ESS Cluster
A mega EV & ESS cluster with global standard infrastructure shall be developed. The cluster shall
cater to EV & ESS and related component manufacturing. The EV cluster shall have common
facilities as given below.
i)

Support infrastructure like roads, power, and water shall be provided at doorstep of the
industry;

ii)

Built-Up Space with ready factory sheds shall be developed to be used mainly by MSME units;

iii)

A common facility for Design, prototyping, and testing available to all units in the cluster;

iv)

Common infrastructure such as Drainage/ Common Effluent Treatment Plant (CETP)/Sewage
Treatment Plant (STP) and utilities such as Power, Gas and Water;

v)

A State-of-art Business environment with facilities such as Convention and exhibition centers;

vi)

Shared facilities to meet staffing and training requirements;

vii) A Logistics Hub shall provide with multimodal transport for safe and efficient handling of
cargo;

B.

Preferential Market Access
The policy of GoI on preferential market access in Government procurement for domestically
manufactured electronics products shall be implemented in all Government of Telangana
departments. Special preference shall be given to Telangana-based manufacturers.

C.

Research & Development
i)

EV Research Hub: A dedicated facility shall be developed to house EV R&D centers
by domestic and global EV Majors. Hyderabad’s strength in Technology domain shall
be leveraged to provide quality manpower for such centers. This hub is also expected to
attract global R&D activities on other emerging mobility trends such as connected and
autonomous vehicles.

ii)

Centers of Excellence: State Government shall partner with premier Technical Institutes
and research establishments across the state to establishing Centers of Excellence for
conducting market-focused research on Battery Technologies, battery management, motors,
and controllers. State Government shall seek Industry participation and leverage GOI EV policy
to provide grant to these centers. NFTDC (Non-Ferrous technologies Development center) at
Hyderabad is running one such COE on electric vehicle technologies, under GOI FAME
scheme.

iii)

T- Fund: The Government shall offer financial support to Start-ups for research and innovation
in EV & Battery technologies. Yearly awards shall be instituted to recognize breakthrough work
in Battery Technologies in separate categories for OEM’s, ancillaries and start-ups

iv)

T-Works Automotive Prototyping Center: Recognized as India’s largest Prototyping Centre,
T- WORKS shall have a dedicated wing for prototyping of Electric Vehicle components/
assembly & battery. Industry partnership in the same shall be invited from EV OEMs and large
component manufacturers. The facility shall serve start-ups and MSME units in the EV space
at subsidized rates.

14
EV ESS POLICY 2020-2030

<!-- page 12 -->

13. STAKEHOLDERS
S. No

Department

Responsibility

1.

Electronics Wing, ITE&C Dept.,
Govt. of Telangana

EV Policy & Operational Guidelines, EV Policy
Administration

2.

Transport Dept., Govt. of
Telangana

EV categorization, Administration of End User Rebates &
Subsidies

Setting up of Public Charging facilities – airports, metro
stations, parking lots, etc.,
3.

TSREDCO, Govt. of Telangana

Fixing of Ceiling Cost of Service for EV Charging,
Guidelines for charging stations – Public & Private
Provision of Renewable Energy for Charging Stations as
per Grid related provisions with support of TSDISCOMS

TSSPDCL/ TSNPDCL, Govt. of
Telangana

Electricity Tariff Administration for Public & Private
Charging as per TSERC guidelines.

5.

MAUD Dept., Govt. of Telangana

Adoption of EV in Urban Areas. Identification of sites for
EV parking & Public Charging Stations. Infrastructure for
EV mobility – Preferential Parking, Charging infra in malls,
apartment complexes, etc, with the support of TSREDCO
(State Nodal Agency).

6.

TSRTC

Electrification of TSRTC Fleet, Setting up of Charging
Infrastructure for TSRTC fleet with the support of
TSREDCO (State Nodal Agency).

4.

14. STEERING COMMITTEE
A Steering Committee comprising of senior officials from relevant departments shall be constituted.
The steering committee shall work towards time- bound EV demand creation and charging network
development in Hyderabad City followed by other towns in the State. The Steering committee shall also
be responsible for periodic review of EV policy.

15
EV ESS POLICY 2020-2030

<!-- page 13 -->

15. CONCLUSION
The rapid growth in urbanization and the surge in the number of vehicles on roads has led to an
immediate need for a sustainable model for personal and public mobility in urban centers to address the
rising pollution & mobility costs. Electric Vehicles have emerged as one such mobility solution that holds
best promise in terms of sustainability and mass adoption with its pace of technology advancement and
cost rationalization. Electric Vehicle technology integrations with the community transport and shared
mobility make the promise even stronger. Telangana State Electric Vehicle and Energy Storage Policy
2020-2030 strives to create a policy framework for the accelerated development of an Electric Vehicle
and Energy Storage Systems’ ecosystem, comprehensively addressing both the demand and supply
side gaps and laying emphasis on charging infrastructure creation. This policy is designed to make
Telangana State the Electric Vehicle capital and Energy Storage Systems Manufacturing hub of India.

CONSTITUTION OF
STEERING COMMITTEE
A Steering Committee comprising of senior officials from relevant departments has been constituted
to work towards time - bound EV demand creation, charging network development in Hyderabad City
followed by other towns in the State and for periodic review of EV policy.
The Steering committee comprises of the following members:

S. No

Department

Responsibility

1.

Principal Secretary, ITE&C Dept., Govt. of Telangana

Chairman

2.

Director - Electronics Wing, ITE&C Dept., Govt. of Telangana

Nodal Officer

3.

Project Director – EV, TSREDCO

Member Convener

4.

Transport Commissioner, Govt. of Telangana

Member

5.

Managing Director, HUMTA – HMDA

Member

6.

Executive Director – Engineering, TSRTC

Member

7.

Director – IPC & RAC, TSSPDCL

Member

8.

Director – IPC & RAC, TSNPDCL

Member

9.

Chief City Planner, GHMC

Member

10.

Joint Commissioner of Police Department

Special Invitee

11.

Managing Director – Hyderabad Metro Rail Ltd.

Special Invitee

12.

Representative - HMWSSB

Special Invitee

16
EV ESS POLICY 2020-2030

<!-- page 14 -->

DEPARTMENT VIEWS / SUGGESTIONS
RECEIVED FOR ELECTRIC VEHICLE &
ENERGY STORAGE POLICY

1

5

Public EV Charging Stations: In
addition to Public Charging Stations
at Airports, Metro Stations, Parking
lots mentioned in the EV policy;
the EV Charging Infrastructure
should be installed at Major Railway
terminals, MMTS stations, Major
terminals of South Central Railways
(Hyderabad, Secunderabad,
Kachiguda, etc.), TSRTC Depots,
Inter State Bus Terminals (ISBT),
Intra City Bus Terminals (ICBT), Truck
terminals, Multi-modal hubs, etc.

Development of App: with features
covering – locations of EV charging
stations, descriptions of its technical
infra, status of availability of charging
port, swapping facility, etc.

2

Planning interventions for promotion
of E- mobility and faster adoption of
E Vehicles: through amendments
and updating building Bye-Laws/
Regulations/Policies/ Guidelines.

3

Approval of building layouts and plans
within its jurisdiction by performing
technical scrutiny to ensure the fulfilment
of the building permit provisions for
Electric Vehicle Charging Infrastructure.

4

Preferential parking for EV vehicles can
be proposed at commercial buildings
and multi-modal hubs.

6

Extensive promotion in adoption
of EV through various print media/
electronic media/ related Govt.
platforms, workshops, awareness
program, information on the App under
development, etc.

17
EV ESS POLICY 2020-2030
