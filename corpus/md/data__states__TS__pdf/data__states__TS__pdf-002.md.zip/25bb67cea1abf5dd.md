---
doc_id: "25bb67cea1abf5dd"
source_url: "https://industries.telangana.gov.in/Library/NewCoalDisPolicy.pdf"
ministry: "Industries and Commerce Department, Telangana"
title: "New Coal Distribution Policy"
date: ""
pages: 9
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "9a6ae36cb6d9ad6e"
---

<!-- page 1 -->

No. 23011/4/2007-CPD
Government of India
Ministry of Coal
New Delhi, the 18" October, 2007
OFFICE MEMORANDUM
Subject: New Coal Distribution Policy
అజ

In supersession of existing coal distribution policy for core and non-core
sector and other instructions issued in this regard from time to time, the
Governmerit is pleased to approve the New Coal Distribution Policy. The
new policy is as follows: ల
‘lo Classification of Consumers :

The existing classification of consumers into Core & Non-core has been
reviewed and it has now been decided to dispense with the same. Instead,
each sector/consumers would be treated on merit keeping in view, inter-alia, the
regulatory provisions applicable thereto and other relevant factors.

2, Distribution and Pricing of coal to different consumers/sector(s):-

al Requirements of defence sector and Railways will be met in full at notified
price, as at present.

2.2 Power Utilities including Independent Power Producers _(IPPs)/

Captive Power Plants (CPPs) and_ Fertilizer Sector

100% of the quantity as per the normative requirement of the consumers
would be considered for supply of coal, through Fuel Supply Agreement (FSA) by
Coal India Limited (CIL) at fixed prices to be declared/notified by CIL. The
units/power plants, which are yet to be commissioned but whose coal
requirements has already been assessed and accepted by Ministry of Coal and
linkage/ Letter of Assurance (LOA) approved as well as future commitments
would also be covered accordingly.

2.3 Other consumers

75% of the quantity as per the normative requirement of the
consumers/actual users would be considered for supply of coal through FSA by
CIL at notified prices to be fixed and declared by CIL. The balance 25 % of

.2/-
:

<!-- page 2 -->

-2-
coal requirement of the units will be sourced by them through e-auction / import
of coal etc., as per their preference. The units which are yet to be commissioned
but whose coal requirement has already been assessed and accepted by
Ministry of Coal and linkage/LOA approved as well as future commitment finally
made would also be covered accordingly.

All the existing linkage holders of erstwhile core and non core sector and
not having FSAs would be required to enter into FSA with coal companies.
At present small and tiny consumers in non core sector, whose annual
consumption is less than 500 metric tonnes are — eligible to get coal through
State nominated agencies/NCCF etc. The scope of coverage through State
nominated agencies is now being increased upto 4200 tonnes per annum. It
means that now the distribution of coal to units whose requirement is upto
4200 tonnes per annum will be done through the agencies nominated by State
Governmerit. Units whose requirement is more than 4200 tonnes per annum
will take coal directly from Coal India Limited/Subsidiary companies through
FSAs. As far as the linked consumers of erstwhile non core sector, whose
annual requirement is less than 4200 tonnes are concerned, they would be
given the option to either entering into FSA with the coal company as per the
terms and conditions, including satisfaction level applicable to the other
consumers or they may opt out of FSA regime and access their coal
requirement through agencies nominated by State Governments.

2.4 Coking Coal to Integrated Steel plants:

Supply of coal to Steel plants would be based on Fuel Supply Agreements
(FSAs). The price of coal would be on the basis of import parity pricing with
suitable adjustment for quality. This system is already in vogue.

3. Consumers in_smail & medium_ sector
3.1 The State Governments are requested to work out genuine requirement
of such units in small and medium sector like Smokeless fuel, brick kiln, coke
oven units etc. on a transparent and scientific basis and distribute coal to them
accordingly. The State Governments may take appropriate steps to evaluate the
genuine consumption and monitor use of coal. The present cap is also enhanced
to 4200 tonnes per annum for the targeted consumers under this category. In
order to meet the enhanced cap fixed for such consumers, the quantity
earmarked for distribution to these agencies would also be increased to 8
million tonnes annually, to start with. This quantity would be allocated for
distribution to those units/consumers in small and medium sector across the
country whose requirement is less than 4200 tonnes per annum and are
otherwise not having any access to purchase coal or conclude Fuel Supply
Agreement (FSA) for coal supply with coal companies.

Ghee

fol

<!-- page 3 -->

-3-

The earmarked quantity would be distributed through agencies notified by
the State Governments. These agencies could be State Govt. Agencies /
Central Govt. Agencies (1210౧౭! Co-operative Consumer FederationINCCF]/
National Small Industries Corporation[NSIC] etc) or industries associations, as
the State Govt. may deem appropriate. The agency so notified will continue to
distribute coal until the State Govt. chooses to denotify it.

The agency /association so notified by the State Govts., would be
required to enter into FSA with coal company to be designated by the Coal India
limited. The FSA will continue to remain in force till either the State Govt.
denotifies the agency/association or CIL shifts the obligation to some other coal
company due to production , transportation logistics etc,. Inthe latter case, a
fresh FSA would be signed with the new coal company. The FSA would be
based on firm commitment and compensation for default in performance on
either side” These State Government/Central Govt. agencies would be free to
devise their own distribution mechanism. However, the said mechanism should
inspire public confidence and should result in distribution of coal in a transparent
manner.

The price charged to such agencies would be same notified price as
applicable to other consumers entering into FSA. The agency would be
entitled to charge actual freight and upto 5% margin as service charge, over
and above the basic price charged by the coal company, from their
consumers. The concerned State Governments and Central Govt. Deptt.
having administrative control over the agencies would be responsible to ensure
that coal allotted for targeted consumer is distributed in a fair and transparent
manner and appropriate action taken to prevent its misuse.

3.2 The quantity to be allocated to this sector may be reviewed on the basis of
their performance in the beginning of every year. Allocation of this quantity
amongst the states would be done on the basis of their consumption pattern in
the past.

4, Replacement of Linkage System by Fuel Supply Agreement (FSAs)

The linkage system will be replaced with a more transparent bilateral
commercial arrangement of enforceable FSAs. All the existing valid linked
consumers whose linkage/MPQ during the year 2006-07 was 4200 tonnes or
more would have to enter into FSAs with coal companies not later than six
months from a date to be notified by CIL. The other valid linked consumers will
have the option to opt out of FSA regime or enter into FSA within six months.
On opting out, they may access their coal requirement through various channels
like e-auction, distribution network of State nominated agencies etc. Failure to
enter into FSA will result in discontinuation of supplies at fixed prices. All existing

Al-
2

<!-- page 4 -->

-4-
FSAs, as prevailing on the date of introduction of this policy, will continue.
However, they would need to be modified in view of the new provisions.
5. Policy for New Consumers
5.1 The Letter of Assurance (LoA) to be issued now pursuant to the new
policy will have a validity of 24 months for consumers/applicants of Power
Utilities, CPPs & IPPs and 12 months for other consumers instead of 30 months
as earlier. The allottee of LoA would be required to fulfill certain stipulated
conditions and meet the milestones within this period and there upon
approach coal companies for entering into FSA. Such FSA would be completed
within three months. Further, with a view to ensure that only serious and
committed consumers approach for LoA, they would be required to furnish an
“Earnest Money Deposit” (EMD). EMD can be in the form of Bank Guarantee
and would §tand discharged once FSA _ is concluded within the stipulated
period. However, on failure, the EMD will be forfeited. The amount of EMD
could be initially kept at 5% of the value of Annual coal requirement. However,
CIL may decide a different. level, based on various relevant facts, with the
approval of Board of Directors of Coal India Limited.
5.2 For new commitments including short-term tapering commitment to
consumers having captive coal block, Power Utilities, CPPs, IPPs, Fertilizer
units, and others would be issued an enforceable Letter of Assurance for supply
of coal and thereafter they would be entitled to enter into FSA within a
stipulated time subject to fulfillment of certain conditions to be stipulated therein.
For Power Utilities including Independent Power Producers (IPPs) and Captive
Power Plants ( CPPs), cement sector and sponge iron sector, the present system
of linkage committee at the level of Government would continue. CIL will issue
LoA after approval of applications by the Standing Linkage Committee (Long-
term). However, for other sectors the task of issuing letter of assurance, will be
the responsibility of CIL.

In order to meet the domestic requirement of coal, CIL may have to
import coal as may be required from time to time, if feasible. CIL may adjust
its overall price accordingly. Thus, it will be the responsibility of CIL/Coal
companies to meet full requirement of coal under FSAs_ even by resorting to
imports, if necessary.

6. Letter of Assurance for New Consumers
6.1 New consumers from State/Central power utilities, CPPs, Independent
Power Producers (IPPs), Fertilizer, Cement and Sponge Iron units may be
issued LOA, based on prevailing norms and recommendation of Administrative
Ministry, which may inter alia have regard to LoA/Linkage already granted

.5/-

ఆ Aenme
A

<!-- page 5 -->

-5-

to the consumer of specific sector, existing capacity, requirement for capacity
addition during aplan period etc.
6.2 All other consumers may be issued LOA by CIL, based on the prevailing
norms and on the recommendation of the administrative ministry. CIL may also
engage an independent Govt. or recognized agency/ institution, if required, for
the purpose of processing/certification of coal requirement of individual
consumers, if there is ౧౦ prevailing norm for such category 01
consumers/sector.
6.3 LOA will be issued by the CIL to the applicant consumers consequent upon
payment of EMD to the coal company. The amount of EMD could be initially
kept at 5% of the value of annual coal requirement. However, CIL may decide a
different level, based on the various facts, with the approval of Board of
Directors df Coal India Limited.
6.4 LOA will be valid for a period of 12/24 months as applicable, during which
the applicant consumer will be required to achieve the milestones pertaining to
his projects/ plant as stipulated in the LOA, failing which LOA will stand
terminated automatically and the EMD would be forfeited.
7. FSAs with New Consumers
7.1 On successfully achieving the milestones stipulated in LOA coal companies
would execute FSA with the applicant consumer covering commercial
arrangement for supply of coal. FSAs would be, inter-alia, based on ‘ Take or
Pay ‘ principle.
7.2 The FSAs would cover 100% of normative coal requirements of the Power
Utilities, including Independent Power Producers (IPPs) and Captive Power
Plants (CPPs), Fertilizer units and 75% of normative coal requirement of other
consumers.
73 As and when Fuel Supply Agreements come into existence, both parties
viz. coal companies and consumers would endeavour to enter into Fuel Supply
and Transport Agreement (FSTA) which would be a tripartite agreement
involving the coal supplier, the coal consumer and the logistic provider i.e.
railways. The FSTA may firstly be made applicable to major consumers like
power, cement and steel sector and could be extended to other consumers in a
phased manner.
8. Role of Standing Linkage Committee

The existing SLC (LT) will continue to recommend issuing of LoA in
respect of Power Utilities including CPPs & IPPs, Cement and Sponge iron

లా లన పటా అల _6/-
ec

<!-- page 6 -->

-6-
including steel, as is being done at present. It may also perform other functions
as per its terms of reference for coal sector as a whole. The issuance of LoA to
consumers of other sectors willbe directly dealt with by CIL on the basis of
recommendation of nodal Ministry.
9. Discipline and economy in coal use
Coal is no longer an essential commodity but it is still considered a scarce
fuel and hence it must be used efficiently and economically. The consumers
getting coal through FSA would be expected to use it efficiently so as not to
waste this scarce resource and hence norms and efficiency compliance should
be carried out diligently by the concerned designated authority/agencies. This
would also require that coal supplied should not be misused or diverted by FSA
holder to others. The existing norms, wherever being made applicable for
deciding linkage quantity etc., would be reviewed in consultation with the
nodal Ministry concerned, and revised norms would be made applicable for
working out the satisfaction level, wherever applicable.
10. E-auction of Coal
Coal distribution through e-auction was introduced with a view to provide
access to coal for such consumers who are not able to source coal through
the available institutional mechanisms for reasons like the seasonality of coal
requirement, limited requirement of coal not warranting long-term linkage etc.
In the long run, it is expected that e-auction may help in creating spot as well as
future market of coal in the country.
Thus, a fresh scheme of E-auction will be introduced subject to, inter-alia,
following conditions:-
(i) Any buyer will be entitled to buy coal under e-auction
(ii) There shall not be any “Floor Price” in e-auction. However, coal
companies may be allowed to fix an undisclosed Reserve Price not below the
notified price.
(iii) | Programme of e-auction should be announced well in advance and be
given wide publicity to all consumers who intend to participate.
(iv) At the beginning of the financial year, CIL shall declare a programme on
sale of coal through e-auction indicating the quantity and quality of coal to be
made available through auction during all the four quarters from different coal
companies/coalfields.
eG Priiicvenen Th

<!-- page 7 -->

-7-

(v) In order to address the concerns of such industrial consumers who

wish to have an assured supply over a long period, say one year, under e-

auction so as to plan their annual production etc., CIL will earmark a fixed

quantity which will be provided to highest bidder/bidders as per bidder's
requirement over the period of the bid.

Based upon above guidelines and modalities, a revised e auction
scheme would be introduced by CIL within one month. Around 10% of
estimated annual production of CIL would initially be offered under e-auction and
the quantity to be offered under e-auction would be reviewed from time to time by
Ministry of Coal.

11. Transitional provisions and implementation schedule

The» new distribution policy envisages implementation of revised
distribution policy in which there will be departure from the existing policy of
distribution based on _ inter-alia norms, FSAs, price, distribution mechanism,
administrative allocation etc. As these modalities will have to be tailor made
accordingly to the new distribution policy, transitional provisions have been
made for implementing new coal distribution policy and to avoid any disruption
in coal distribution to various categories of consumers, as under:

Number

Upto Six months Distribution as per existing
FSA/SLC(ST). For non core
. linked consumers 16 present

system of offer by CIL.

Para 3 Upto Six months The existing system of allocation
of coal to State nominated
agencies and NCCF to continue.
However, tecommendations
regarding enhancement of cap to
4200 tonnes per annum will be
given immediate effect.

Para 4 Allocation in terms of existing
FSA/SLC(ST). For non core linked
consumers the present system of
offer by CIL.

iF Giccvone
7

<!-- page 8 -->

న౧౭[25&6 a) Two months For power utilities/IPPs LoA to be
tecommended by SLC(LT) subject
to deposit of applicable EMD and
modified LoA containing
stipulated terms and conditions.
For other categories — similar
interim/conditional LoA can be
issued by CIL, if required.
b) One Year ( For meeting | Existing system of meeting the
the requirement of FSA] FSA quantity would continue.
commitment through
import, if required. )
i వవ నా
interim.
Verification of erstwhile non core sector consumers
CIL would undertake verification of such consumers of erstwhile non-
core sector consumers, in atime bound manner, either directly or through an
agency, so as to check the veracity of their claim of being bonafide
consumers of coal and thereafter act accordingly. This exercise should be
carried out keeping in view the observations and directions of Hon’ble Supreme
Court in the case of M/s. Ashoka Smokeless Coal India Limited and Ors. In
tespect of those consumers who are not found to be bonafide, Coal companies
can cancel their allocation.
The above policy guidelines will also be applicable to distribution of coal
from Singareni Collieries Company Limited (SCCL).
CIL/SCCL/Coal Companies are advised to take further appropriate action
for implementation of this policy in respect of provisions relevant to them.
న్‌ d US =.
(G.Srinivasan)
Under Secretary to the Government of India
Tele. No. 2338 4285
To
1. Shri Ashok Khurana, Addl. Secy., Ministry of Power, Shram Shakti
Bhawan, New Delhi.
-9/-
Q

<!-- page 9 -->

-9-
2. Dr. Surya Sethi, Principal Advisor, Planning Commission, Yojana Bhawan,
New Delhi.
3. Shri Arvind Mayaram, Joint Secretary, Ministry of Economic Affairs,
Ministry of Finance, North Block, New Delhi.
4. Shri K.A. Singh Deo, Joint Secretary, Ministry of Steel, Udyog Bhawan,
New Delhi.
5. Shri Shashi Ranjan Kumar, Director, Deptt. Of Industrial Policy and
Promotion, Ministry of Commerce & Industry, Udyog Bhawan, New Delhi.
6. Shri P.K.Malhotra, Joint Secretary & Govt. Counsel, Deptt. Of Legal
Affairs, Ministry of Law, Shastri Bhawan, New Delhi.
7. Shri Chandan Saha, Director, 0/0 Development Commissioner, Ministry of
Small Scale Industries, Udyog Bhawan, New Delhi.
8. Shri P.S. Bhattacharyya, Chairman, CIL, 10-NS Road, Kolkata.
9. Shri,S. Ghoudhury, CMD, CMPDIL, Ranchi.
10. Shri గ. Ranganath, Director (Marketing), 15-Park Street, Kolkata.
11. Shri Narsing Rao, CMD, SCCL, Kothagudem, Hyderabad (AP).
Copy for information to:
a) CMDs of BCCL, ECL, CCL, SECL, MCL, WCL, NCL.
0) PS to MoS (Coal) (0) Sr. PPS to Secretary (Coal)
(d) PS to AS (Coal) (e) PS to AS (LA)
Copy also for information and necessary action to : All Chief Secretaries of
all State Governments/Union Territories
Copy also for information to: Shri Ashish Gupta, Director, PMO, South Block,
New Delhi.
Copy to NIC, Ministry of Coal with a request to place this on the website of
Ministry of Coal for wide publicity.
9
