---
doc_id: "c09c0aed25efba67"
source_url: "http://treasury.telangana.gov.in/docs_old/css.pdf"
ministry: "Directorate of Treasuries and Accounts, Telangana"
title: "Transfer of CSS to SNA Account"
date: ""
pages: 3
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "8e776492550fdb80"
---

<!-- page 1 -->

టకా GOVERNMENT OF TELANGANA
Perey FINANCE [PF] DEPARTMENT
== Circular Memo No. 715-H/19/PF/2022 Dated: 17-06-2022
= a 003196
4 “f .% 5640: Finance (PF) Department - New procedure for transfer of centrally
ట్‌ hae ; sponsored Scheme amount and to credit into the Single Nodal
న్న నా ఖ్‌ Agency Account - Orders - Issued.
0° XL Ref: 1..G.0.Ms.No.59, Finance (86.1) Department, dated: 30.03.2001.
న a Y- 2. U.O.Note No.29875-A/1283/A1/2006, Finance(BG.1) Department,
. Ux x dated: 25.11.2006. _
ad 3. OM F.No.1(13)/PFMS/FCD/2020, dated: 23.03.2021 of Ministry of
‘ “FS Finance, Department of Expenditure, PFMS Division, Government of
India.
7 య
In the reference 1 read above, Government issued instructions for issue
of Budget Release Orders to the Administrative Departments/Head of
Departments to facilitate the departments for speedy implementation of the
schemes. In para 7 of the said G.O., it has been clarified that the Budget Release
Order (BRO) which will be issued by Finance Department on 15 April of the
financial year shall substitute specific Finance concurrence and ౮.౦. Notes which
are required as per Article 45 of the Telangana State Finance Code Vol.I.
However, the Administrative Departments concerned shall issue Government
Orders for implementing the scheme by quoting Budget Release Orders issucd by
Bq the Finance Department.
ఈ (
ata)
2. In the reference 2" cited, detailed instructions were issued to follow the
en procedures required before issuing the administrative sanctions for the
schemes/programmes to be implemented by the Departments/Head of
Departments.
3: In the reference 34 cited, Government of India have issued new guidelines
5 for transfer of amount released under Centrally Sponsored Scheme’s into the
(| | concerned Scheme implementing department SNA account within 21 days and
Aw” matching State Share shall be credited into the SNA account within 40 days.
4. Government, after careful examination of the matter, in order to adhere
the guidelines of Government of India in implementation of Public Finance
Management System for Centrally Sponsored Schemes, hereby decided to adopt
new procedure for transfer of funds under Centrally Sponsored Schemes into the
scheme concerned; implementing department’s State Nodal Agency Account.
The procedure shall be as detailed below:
a) The amount released by Government of India under CSS to the State
Government will be credited into state consolidated fund.
[Contd..]

<!-- page 2 -->

235 i)

b) Based on the advice note of Government of India, the Finance (PF)
Department or other Designated Officer, will initiate Budget Release
Order duly indicating the details required for release of BRO

c) The designated Deputy Secretary & Drawing and Disbursement Officer
for CSS, will verify and process for online BRO and will prefer the
electronic bill to the Deputy Pay and Accounts Officer, Secretariat
Branch.

d) The Deputy Pay and Accounts Officer, Secretariat Branch, will audit the
bill and generate cheques for Central share and State share separately
for clearance.

e) The amount will be credited into the SNA account of the concerned
scheme implementing department.

f) The concerned scheme implementing administrative department will
issue administrative sanction duly following the instructions issued vide
reference 2% read above.

5. These orders shall come into force from the financial year 2022-2023.
K.RAMAKRISHNA RAO
SPECIAL CHIEF SECRETARY TO GOVERNMENT
To
The Special Chief Secretary/ Prl. Secretary/ Secretaries,
Telangana Secretariat, Hyderabad.
All Head of the Departments, Government of Telangana, Hyderabad.
The Director of Treasuries & Accounts, Government of Telangana, Hyderabad.
The Pay and Accounts Officer, Hyderabad.
The Director of Works &Accounts, Telangana State, Hyderabad
Copy to:
All Officers and EBS Sections,
Finance Department, Telangana Secretariat, Hyderabad.
P.S. to Spl. Chief Secretary/ Secretary(TKS)/ Secretary(DRR)
Finance Department, Telangana Secretariat, Hyderabad.
The Accountant General, Telangana, Hyderabad.
SF/SCs.
//FORWARDED::BY ORDER//
woth

<!-- page 3 -->

O/o Director of Treasuries and Accounts,
Telangana State:: Hyderabad
Endt. J1/003196/2022 Dt:_30.06.2022
Circular Memo.No.715-H/19/PF/2022 , Did.17.06.2022 of Finance (PF) Dept.
Government of Telangana.
“Copy Communicated”
Sd/- K. SRC Murthy
Director of Treasuries and Accounts
To
All the District Treasury Officers (DD/AD) of District Treasuries in the state
Deputy Director, District Treasury, Hyderabad (U), ౪
The Chief Accounts Officer,
O/o. Commissioner of Police, Hyderabad.
O/o. Commissioner of Police, Cyberabad.
O/o Commissioner of Police, Rachakonda.
(0/0. Director of Animal Husbandry, Telangana, Hyderabad.
O/o. Director of Public Health & Family Welfare, TS, Hyderabad.
The Accounts Officer,
O/o Director General of Police, Telangana, Hyderabad
O/o.Commissioner & Director of Agriculture, Telangana, Hyderabad.
O/o.Commissioner of Collegiate Education, Telangana, Hyderabad
O/o. Director of School Education. Telangana, Hyderabad.
O/o.Commissioner of Social Welfare, Telangana, Hyderabad.
O/o. Commissioner of Industries, Telangana, Hyderabad.
O/o Commissioner of Printing, Stationery & Stores Purchase TS, Hyderabad.
O/o. Director General & Inspector General of Prisons, Telangana, Hyderabad.
O/o. Commissioner of Intermediate Education, Telangana, Hyderabad.
The Assistant Accounts Officer,
O/o.Commissioner of Civil Supplies, Telangana, Hyderabad.
O/o.Commissioner of Information & Public Relations, Telangana, Hyderabad
O/o. Commissioner of Youth Services, Telangana, Hyderabad.
O/o. Commissioner of Tribal Welfare, Telangana, Hyderabad.
O/o. Director of Horticulture, TS, Hyderabad.
The Junior Accounts Officer (Incharge of Accounts Branches),
O/o.Commissioner of Fisheries Telangana, Hyderabad.
O/o. Director of Employment & Training, Telangana, Hyderabad
O/o. Director of B.C. Welfare, Telangana Hyderabad.
O/o. Controller, Legal Metrology, Telangana, Hyderabad.
O/o . National Cadet Corps (NCC), Telangana,Hyderabad
O/o. Tribal Cultural Research & Training Institute, Telangana, Hyderabad
Copy to the Director General, Directorate of Protocol, Telangana, Hyd
Copy to the Joint Director(AN) O/o DTA, TS, Hyderabad.
//¥.B.O// గ్గ
య =
