---
doc_id: "bce85aff48c9e4d6"
source_url: "https://www.ruraluniv.ac.in/files/includes/cetc/circular/pdf/Finance_Accounts_Manual170317.pdf"
ministry: "The Gandhigram Rural Institute (Deemed to be University), Telangana"
title: "Finance and Accounts Manual"
date: ""
pages: 129
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "89e7b70a73351490"
---

<!-- page 1 -->

<!-- page 2 -->

THE GANDHIGRAM RURAL INSTITUTE
DEEMED UNIVERSITY
GANDHIGRAM-624302 - DINDIGUL DISTRICT

FINANCE AND ACCOUNTS MANUAL

<!-- page 3 -->

<!-- page 4 -->

THE GANDHIGRAM RURAL INSTITUTE / DEEMED UNIVERSITY
FINANCE AND ACCOUNTS MANUAL
(As approved by the Board of Management in its 142nd meeting held on 22-01-2017)

<!-- page 5 -->

THE GANDHIGRAM RURAL INSTITUTE – DEEMED UNIVERSITY,
GANDHIGRAM
FINANCE AND ACCOUNTS MANUAL
Table of Contents
Chapter
No.
1
2
1

2

3
3
1
2
3
4
1
2
3
4
5
6
7
8
9

Contents
PART-I - ACCOUNTS
Introduction
Basic Accounting Concepts, Policies and
Conventions
Accounting Concepts
i) Business Entity Concept
ii) Money Measurement Concept
iii) Going Concern Concept
iv) Dual Aspect Concept
v) Periodicity Concept
vi) Historical Cost Concept
vii) Matching Concept
viii) Realization Concept
ix) Accrual Concept
x) Objective Evidence Concept
Accounting Conventions
i) Consistency
ii) Disclosure
iii) Conservatism
Generally Accepted Accounting Principles
Accounting Standards and Frame work
Accounting Standards
Accounting Framework
Standards of financial propriety
Functions of Finance Section
Accounting of Receipt of Funds
Monitoring of payments
Review of Advances
Physical verification of Fixed Assets
Review of Subsidiary Ledgers and Bank
Reconciliation
Conditions for incurring expenditure
Investments
Registers /Documents to be maintained
Inter Unit Transfer
1) Transfer Debit Advice (TDA) / Transfer Credit
Advice (TCA)
2) Form of TDA/TCA

Page
No.
1
2
2
2
2
2
3
3
3
3
4
4
4
4
4
5
5
5
6
6
6
7
8
8
8
8
8
9
9
11
12
15
15
17

<!-- page 6 -->

5
1
2
3
4
5

6

7

8
9

Internal Control and Audit
Internal Control
Financial powers
Internal Audit
Statutory Audit
C&AG Audit
1. Time Frame for C&AG Audit
2.A) Certificate Audit
2.B) Transactional Audit
Accounting of Government Grants

18
18
22
22
23
23
23
24
24
25

1 Accounts of Grantee Institutions (Rule 210 of GFR)
2 Audit of Accounts of Grants-in-aid (Rule 211 of
GFR)
3 Utilization Certificates (Rule 212 of GFR)
Form of Utilization Certificate
Chart of Accounts
1 Description of Account Code
2 Accounts Code for Non-Plan
Budget Estimate and Reports
Compilation of Annual Accounts and
Balance Sheet

25
25

1 Introduction
2 Accounting Principles
3 Other Important Instructions regarding
compilation of accounts
1. Accounting Period
2. Submission of Monthly and Quarterly accounts
3. Compilation and Submission of Annual
Accounts
Form of Balance Sheet
Form of Income and Expenditure Account

36
36
40

26
28
29
29
30
33
36

40
40
40
44
45

PART-II – PURCHASE AND WORKS
1

2

Permanent Advance and Temporary
Advance
1 Permanent Advance or Imprest (Rule 291 of GFR)
2 Temporary Advance (Rule 292 of GFR)
Guidelines to claim NMR wages

3
1
2
3
4

46
46
47
49

Purchase Procedures

50

Terminology
Financial Source for purchase proposals
Mandatory Requirement of Financial Concurrence
Financial power for sanctioning expenditure

50
50
51
51

<!-- page 7 -->

4

5 Purchase of goods-Procedures
5.A) Purchase of goods upto Rs.2000
5.B) Purchase of goods above Rs.2000 and up to
Rs.15000
5.C) Purchase of goods above Rs.15000 and up to
Rs.100000
5.D) Purchase of goods above Rs.100000
(a) Limited Tender (Above 1.00 lakh upto
Rs.25.00 lakh)
(b) Advertised Tender (Open Tender) - (Above
Rs. 25.00 lakh)
Two bid system (Rule 152 of GFR)
Late Bids (Rule 153 of GFR)
(c) Single Tender Enquiry
6 Tender Committee
7 Buy-Back Offer (Rule 162 of GFR)
8 Registration of Suppliers (Rule 142 of GFR)
9 Repeat Order
10 Purchase by Imports
11 Procedure for purchase of Major Scientific
Equipments costing more than Rs.25.00 Lakh
12 Bid Security (Earnest Money Deposit) (Rule 157
of GFR)
13 Forfeiture of EMD
14 Performance Security
15 Forfeiture of Performance Security
16 Refund of Performance Security
17 Opening of Quotations
18 Tender Evaluation
19 Negotiation with bidders
20 Purchase of goods under DGS&D rate contract
21 Relaxation of the Rules and Procedures of GRI
22 Black listing
23 Format for Inviting Quotations
Purchase Proposal under Tender System
Comparative Statement
Specimen- Proposal for sale under buy-back
Guidelines relating to Works Contracts

52
52
52

1 Original works and Repair works
2 Administrative Approval and Sanction (Rule 129.1
of GFR)
3 Group of similar works (Rule 130 of GFR)
4 Procedure for Execution of Works (Rule 132 of
GFR)
5 Tendering and award of works contract

76
76

52
53
53
54
55
55
55
56
57
57
58
58
59
61
62
63
63
63
63
64
64
65
66
66
67
69
73
74
76

77
77
78

<!-- page 8 -->

5

6 Works executed departmentally by GRI
7 Works entrusted to CPWD
Check List- Specimen
Notice Inviting Tender – Form -6-Specimen
Tender Notice Issued in Dailies – Specimen
Limited Tender Notice - Specimen
Rate Tender & Contract – Form 8 - Specimen
Work Order – Specimen
Write off, Condemnation and Disposal
1 Physical verification of fixed assets
2 Surplus, Obsolete and Unserviceable items
3 General Procedure for writing off the
unserviceable Materials/Items
4 Auction Committee
5 Procedure for Auction
6 Destruction of records connected with accounts
(Rule 289 of GFR)

79
82
83
84
89
90
92
104
116
116
116
117
118
118
120

<!-- page 9 -->

Chapter 1
Introduction
1.1. The Gandhigram Rural Institute - Deemed University obtains grants-in-aid,
from the Ministry of Human Resource Development through University Grants Commission
for its requirement. The Institute receives Plan grant for creation of assets such as
infrastructure, scientific equipment and all other necessities of the Institute. The Institute
also receives non-plan grant for salaries and non salary expenditure for running the
Institute. In addition to that, the Institute receives funds from various funding agencies
like UGC, CSIR, DAE, DST, ICSSR, ICAR etc. for operating the research projects,
conducting seminars and training programmes. General Financial Rules are strictly
followed in all the financial transactions. Apart from this, the specific instructions of the
concerned funding agencies are strictly adhered to while incurring the expenditure.
1.2 The Government has found the need for sound accounting and common
financial reporting framework for promoting accountability and for development of the
Education sector. Therefore, the MHRD introduced the implementation of new uniform
accounting standard for educational institutions to ensure proper accountability, financial
discipline, end use of funds and to meet the needs of the stakeholders under MHRD letter
No.21-16/2012-TS.II dated 21.2.2012 and No.29-4/2012-IFD dated 17.4.2015. The new
system for accounting and financial reporting has been introduced from the financial year
2014-15 onwards. This manual incorporates all the changes that have been introduced
and includes the provisions of GRI Procedure Manual which was already approved by the
BOM in its 135th Meeting, with slight modifications.
1.3 This Finance and Accounts Manual provides the essential information to enable
the Institute to carry out the financial operations effectively. This manual will provide
supportive information in complying with the rules set henceforth. The main purpose of
compiling this manual is to ensure that financial statements are in conformity with
generally accepted accounting principles, that finances are managed with responsible
stewardship and Institute‟s assets are safeguarded. All the personnel with a role in the
management of GRI‟s fiscal operations are expected to uphold the policies pointed out in
this manual.

1

<!-- page 10 -->

Chapter 2
Basic Accounting Concepts, Policies and Conventions
2.1. Accounting Concepts:
i) Business Entity Concept: A business unit is an organization of persons established to
accomplish an economic goal. Business entity concept implies that the business unit is
separate and distinct from the persons who provide the required capital to it. This concept
can be expressed through an accounting equation, viz., Assets = Liabilities + Capital. The
equation clearly shows that the business itself owns the assets and in turn owes to
various claimants. It is worth mentioning here that the business entity concept as applied
in accounting for sole trading units is different from the legal concept. The expenses,
income, assets and liabilities not related to the sole proprietorship business are excluded
from accounting. However, a sole proprietor is personally liable and required to utilize
non-business assets or private assets also to settle the business creditors as per law.
Thus, in the case of sole proprietorship, business and non-business assets and liabilities
are treated alike in the eyes of law. In the case of a partnership, firm, for paying the
business liabilities the business assets are used first and it any surplus remains thereafter,
it can be used for paying off the private liabilities of each partner. Similarly, the private
assets are first used to pay off the private liabilities of partners and if any surplus remains,
it is treated as part of the firm‟s property and is used for paying the firm‟s liabilities. In the
case of a company, its existence does not depend on the life span of any shareholder.
ii) Money Measurement Concept: In accounting all events and transactions are
recorded in terms of money. Money is considered as a common denominator, by means of
which various facts, events and transactions about a business can be expressed in terms
of numbers. In other words, facts, events and transactions which cannot be expressed in
monetary terms are not recorded in accounting. Hence, the accounting does not give a
complete picture of all the transactions of a business unit. This concept does not also take
care of the effects of inflation because it assumes a stable value for measuring.
iii) Going Concern Concept: Under this concept, the transactions are recorded
assuming that the business will exist for a longer period of time, i.e., a business unit is
considered to be a going concern and not a liquidated one. Keeping this in view, the
suppliers and other companies enter into business transactions with the business unit.
This assumption supports the concept of valuing the assets at historical cost or
replacement cost. This concept also supports the treatment of prepaid expenses as
assets, although they may be practically unsalable.
2

<!-- page 11 -->

iv) Dual Aspect Concept: According to this basic concept of accounting, every
transaction has a two-fold aspect, Viz., 1.Giving certain benefits and 2. Receiving certain
benefits. The basic principle of double entry system is that every debit has a
corresponding and equal amount of credit. This is the underlying assumption of this
concept. The accounting equation viz., Assets = Capital + Liabilities or Capital = Assets –
Liabilities, will further clarify this concept, i.e., at any point of time the total assets of the
business unit are equal to its total liabilities. Liabilities here relate both to the outsiders
and the owners. Liabilities to the owners are considered as capital.
v) Periodicity Concept: Under this concept, the life of the business is segmented into
different periods and accordingly the result of each period is ascertained. Though the
business is assumed to be continuing in future (as per going concern concept), the
measurement of income and studying the financial position of the business for a shorter
and definite period will help in taking corrective steps at the appropriate time. Each
segmented period is called “accounting period” and the same is normally a year. The
businessman has to analyze and evaluate the results ascertained periodically. At the end
of an accounting period, an Income Statement is prepared to ascertain the profit or loss
made during that accounting period and Balance Sheet is prepared which depicts the
financial position of the business as on the last day of that period. During the course of
preparation of these statements capital revenue items are to be necessarily distinguished.
vi) Historical Cost Concept: According to this concept, the transactions are recorded in
the books of account with the respective amounts involved. For example, if an asset is
purchased, it is entered in the accounting record at the price paid to acquire the same and
that cost is considered to be the base for all future accounting. It means that the asset is
recorded at cost at the time of purchase but it may be methodically reduced in its value
by way of charging depreciation. However, in the light of inflationary conditions, the
application of this concept is considered highly irrelevant for judging the financial position
of the business.
vii) Matching Concept: The essence of the matching concept lies in the view that all
costs which are associated to a particular period should be compared with the revenues
associated to the same period to obtain the net income of the business. Under this
concept, the accounting period concept is relevant and it is this concept (matching
concept) which necessitated the provisions of different adjustments for recording
outstanding expenses, prepaid expenses, outstanding incomes, incomes received in
3

<!-- page 12 -->

advance, etc., during the course of preparing the financial statements at the end of the
accounting period.
viii) Realization Concept: This concept assumes or recognizes revenue when a sale is
made. Sale is considered to be complete when the ownership and property are transferred
from the seller to the buyer and the consideration is paid in full. However, there are two
exceptions to this concept, viz., 1. Hire purchase system where the ownership is
transferred to the buyer when the last installment is paid and 2. Contract accounts, in
which the contractor is liable to pay only when the whole contract is completed, the profit
is calculated on the basis of work certified each year.
ix) Accrual Concept: According to this concept, the revenue is recognized on its
realization and not on its actual receipt. Similarly the costs are recognized when they are
incurred and not when payment is made. This assumption makes it necessary to give
certain adjustments in the preparation of income statement regarding revenues and costs.
But under cash accounting system, the revenues and costs are recognized only when they
are actually received or paid. Hence, the combination of both cash and accrual system is
preferable to get rid of the limitations of each system.
x) Objective Evidence Concept: This concept ensures that all accounting must be
based on objective evidence, i.e., every transaction recorded in the books of account must
have a verifiable document in support of its existence. Only then the transactions can be
verified by the auditors and declared as true or otherwise. The verifiable evidence for the
transactions should be free from the personal bias, i.e., it should be objective in nature
and not subjective. However, in reality the subjectivity cannot be avoided in the aspects
like provision for bad and doubtful debts, provision for depreciation, valuation of
inventory, etc., and the accountants are required to disclose the regulations followed.
The Institute is following accrual concept in particular and all other concepts in
general.
2.2. Accounting Conventions:
The following conventions are to be followed to have a clear and meaningful information
and data in accounting:
i) Consistency: The convention of consistency refers to the state of accounting rules,
concepts, principles, practices and conventions being observed and applied constantly,
i.e., from one year to another there should not be any change. If consistency is there, the
results and performance of one period can be compared easily and meaningfully with the
other. It also prevents personal bias as the persons involved have to follow the consistent
4

<!-- page 13 -->

rules, principles, concepts and conventions. This convention, however, does not
completely ignore changes. It admits changes wherever indispensable and adds to the
improved and modern techniques of accounting.
ii) Disclosure: The convention of disclosure stresses the importance of providing
accurate, full and reliable information and data in the financial statements which is of
material interest to the users and readers of such statements. This convention is given
due legal emphasis by the Companies Act, 1956 by prescribing formats for the preparation
of financial statements. However, the term disclosure does not mean all information that
one desires to get should be included in accounting statements. It is enough if sufficient
information, which is of material interest to the users, is included.
iii) Conservatism: In the prevailing present day uncertainties, the convention of
conservatism has its own importance. This convention follows the policy of caution or
playing safe. It takes into account all possible losses but not the possible profits or gains.
A view opposed to this convention is that there is the possibility of creation of secret
reserves when conservatism is excessively applied, which is directly opposed to the
convention of full disclosure. Thus, the convention of conservatism should be applied very
cautiously.
2.3. Generally Accepted Accounting Principles:
In order to maintain uniformity and consistency in accounting records throughout
the world certain rules and principles have been developed which are generally accepted
by the Accounting Profession. These rules, principles, concepts, conventions, postulates or
assumptions are taken as generally accepted rather than universal acceptability. Hence,
are called Generally Accepted Accounting Principles (GAAP).

5

<!-- page 14 -->

Chapter 3
Accounting Standards and Frame work
3.1. Accounting Standards:
3.1. Adopting Accounting Standards enables the Institute to maintain uniformity in
presentation of financial statements, proper disclosure and transparency. The Accounting
Standards applicable to Educational Institutions are as follows.
i) AS-1: Deals with disclosure of significant policies followed in preparing and
presenting financial statements. Eg. Indication of: foreign currency transactions, Valuation
of inventories and investments.
ii) AS-4: Contingencies and events occurring after the Balance Sheet date. Eg.,
Obligation to pay on the outcome of a pending court case. Liability arising, consequent to
legislative measures, with retrospective effect.
iii) AS-5: Extraordinary items appearing in the Income and Expenditure account,
changes in accounting estimate and prior period items.
iv) AS-6: Depreciation: Different accounting policies are adopted by different
enterprises. Such differences need to be indicated.
v) AS-9: Policy for recognition of revenue adopted for disclosing in books of
accounts.
vi) AS-10: To disclose information relating to fixed assets such as assets utilized for
the purpose of activities of the entity and those kept for sale.
vii) AS-12: Capital approach versus Income approach. Capital Approach – Grant is
treated as stakeholder‟s fund and Income approach is taken to indicate income over one
or more periods.
viii) AS 13: Accounting for investments. Investment is valued at the principal cost.
Market value or maturity value is not taken for disclosure.
3.2. Accounting Framework:
Accounting Framework is about the general purpose of financial statements which
are prepared and presented annually for the common information need of the users who
rely on the financial statements. Thus the accounting framework comprises the following:
a) Elements of financial statements which basically comprise income, expenses,
assets and liabilities. It identifies and defines the items that should be considered as
income, expenses, assets and liabilities. Assets are resources controlled by an entity from
6

<!-- page 15 -->

which future economic benefits or service potential is expected to flow. E.g., Land,
building, furniture and equipment etc,
b) Principles of recognition of items of income, expenses, assets and liabilities:These principles lay down timing of recognition of these items in the financial statement.
A grant is recognized as income in the financial statement under accrual basis of
accounting when it becomes reasonably certain that the grant will be received.
3.3. Standards of financial propriety:
Rule 21 of GFR: Every officer incurring or authorizing expenditure from public money
should be guided by high standards of financial propriety. Every officer should also
enforce financial order and strict economy and see that all relevant financial rules and
regulations are observed, by his own office and by subordinate disbursing officers. Among
the principles on which emphasis is generally laid are the following:
i)

Every officer is expected to exercise the same vigilance in respect of expenditure
incurred from public moneys as a person of ordinary prudence would exercise in
respect of expenditure of his own money.

ii)

The expenditure should not be prima facie more than the occasion demands.

iii)

No authority should exercise its powers of sanctioning expenditure to pass an order
which will be directly or indirectly to its own advantage.

iv)

Expenditure from public money should not be incurred for the benefit of a
particular person or a section of the public, unless a) a claim for the amount could
be enforced in a Court of Law, or b) the expenditure is in pursuance of a
recognized policy or custom.

v)

The amount of allowance granted to meet expenditure of a particular type should
be so regulated that the allowance are not on the whole a source of profit to the
recipients.

7

<!-- page 16 -->

Chapter 4
Functions of Finance Section
The Finance Section of the GRI consists of two sections namely, Finance Section-I
and Finance Section-II.
4.1. Accounting of Receipt of Funds:
The Finance Section-I is primarily concerned with receiving funds of the Institute in
the form of Grants-in-aid (Plan and Non-plan), fees from students, and any other receipts
and accounts for these receipts. Similarly, the Finance Section-I is concerned with all
payments for salaries, utilities, academic and student related activities, for procurement
and creation of capital assets for infrastructure and other requirements to run the
Institute. Based on the information contained in vouchers and bills for procurements and
other expenses, compilation of accounts is made classifying all receipts and payments.
The Institute also receives grants for Sponsored projects for Research and Development
from Ministries and other Organizations such as CSIR, DAE, DST, ICSSR, ICAR, etc, which
is dealt with by Finance Section-II.
4.2. Monitoring of payments:
The Finance Officer will be responsible for establishment of agreed financial
management arrangements, providing timely financial reports, facilitating smooth and
timely flow of funds and providing overall guidance in respect of financial management
issues, including monitoring of expenditures, audit and internal control of the Institute.
He/she will be responsible for complying with requirements of accounting, disbursement,
financial reporting, monitoring of expenditures and audit. He/ She will be assisted by
adequate support staff such as Assistant/Deputy Registrars, Section Officers, and other
staff of the Finance Section.
4.3. Review of Advances:
(a) Outstanding advances to suppliers, contractors, employees, etc. shall be
reviewed and provision is to be made for advances which are doubtful of
adjustment/recovery.
4.4. Physical verification of Fixed Assets:
In respect of physical assets,
(i) Capitalization of all fixed assets completed/commissioned/brought into use
during the year.
(ii) Physical verification of all fixed assets and adjustment of discrepancies.

8

<!-- page 17 -->

(iii)Survey reporting of assets considered to be beyond economic repair or
redundant and provide for possible diminution in value.
4.5. Review of Subsidiary Ledgers and Bank Reconciliation:
(i) Reconciliation and verification of various control accounts in the general ledger
and subsidiary ledgers, reconciliation of bank account etc.
(ii) Passing of all adjustment/rectification entries.
(iii) Subsidiary ledgers shall be maintained for detailed analysis of the balances in
main ledgers wherever such details are required. A list of balances from
different folios in subsidiary ledger, pertaining to one account shall be
prepared and the total shall be tallied with the balance in the concerned
account in the main ledger.
4.6. Conditions for incurring expenditure:
The responsibility of Finance Section is to ensure that:
a)

every expenditure is approved by the competent authority to whom powers
to incur expenditure from Institute‟s funds are delegated.

b)

the expenditure is provided for in the Institute‟s Budget and is within the
allocation or revised allocation.

c)

if the expenditure is related to procurement or creation of assets, a formal
Purchase order or Work order is issued after calling for quotations following
the procedures laid down in this Manual.

d)

the consumables / Capital assets procured are taken possession of and are
properly accounted for and that before passing a bill/claim under
contract/Purchase/Work order, evidence of inspection, installation and
accounting of Asset in the Assets Register of the Institute or other Stock
Register for consumables are looked for. The claim should be generated
from the User Department and after approval by the competent authority to
be forwarded to Finance Section for further action.

e)

if the claim relates to fellowship, scholarship and stipend it is ensured that
there is sanction for the expenditure. If it relates to sanction from external
agency, it should be ensured that the funds sanctioned has been actually
received from such agency. The receipt entry in the Bank account should be
linked before authorizing release of payment. The claim related to such
payments should be generated from the Academic Section and submitted for
further processing the claims.
9

<!-- page 18 -->

f)

a salary bill is passed for payment before the last date of the month except
for the salary for the month of March which will be released in April of the
following financial year. While passing salary bill the following points should
be scrutinized:
i) The previous month‟s salary bill should be seen to ensure that there is no
addition in the current month‟s salary bill. If addition is noted, it should
be seen that there is sanction of the competent authority in the form of
Appointment Order.
ii) It should be checked to ensure that the scale-of pay and grade pay
claimed are correct as per sanction.
iii) If increment is claimed, such increment is sanctioned. Deductions made
from salaries are authorized.
iv) It should be ensured that the deduction from salary such as Income Tax,
New Pension scheme deductions and any such deductions are remitted
to the appropriate authorities within the due time.
v) Salary bill should be generated from the Establishment section and
forwarded to Finance Section for authorizing payment.
vi) Bills for GRI employer‟s contribution should also be submitted by
Establishment section and submitted to the Finance Section for further
action.

g)

no claim or bill is generated by the Finance Section as the internal check
function and transaction audit function will be compromised.

h)

in respect of civil/electrical construction work, the following checks are
exercised:
i)

Verification of the Contract agreement if the work is allotted to
Civil/Electrical engineering contractor or Memorandum of Understanding
if the work is assigned as Deposit work to the State/Central
PWD/NBCC,etc.

ii)

Before passing a civil/electrical works, the contract agreement entered
into by the competent authority should be scrutinized to observe whether
the General principles for contract laid down in GRI Finance and
Accounts Manual have been fully complied with.

iii) While passing the Running Account Bills(RAB), the value of work
completed as assessed and certified by the Engineer-in-Charge and
10

<!-- page 19 -->

signed by the contractor should be checked. This certificate should be
supported by the entries in the Measurement Books which are legally
authentic records of works completed. If the RAB is a second or
subsequent one, it should be checked to see that the advance paid
through the earlier RAB is adjusted from the amount payable.
iv) Deductions on account of TDS, water and electric consumption charges,
Labour-Cess and any other recovery as laid down in the contract are
appropriately made and remitted to the concerned authorities within the
due date.
v) The final bill should be supported by complete entries in Measurement
Book(s) and supported by a Completion Certificate signed by the
Engineer in charge.
vi) It should be checked to see that the completion cost does not exceed
cost of construction as administratively approved. If exceeds, revised
administrative approval should be asked for before passing the bill.
i)

in respect of utility bills for electricity consumption, it is checked to see that
the amount claimed is as per agreed Tariff / contract load.

j)

in respect of claims for outsourced services, it is checked to see that the
Service Provider complies with all statutory requirements and such
deductions are deposited with EPF/ESI authorities.

4.7.

Investments:
i.

The monthly balances of all Bank accounts should be reviewed on the 10th of
the succeeding month and should be maintained to the barest minimum
which would be sufficient to meet the monthly requirement and the
remaining amount is to be invested in any investments such as FDRs.
Finance Section shall identify the availability of surplus funds and
recommend investment of the same in any form which gives maximum rate
of interest preferably in Government Sectors.

ii.

On receipt of FDR / Certificate etc., the same shall be entered in the
Investment Register and kept under the custody of Registrar. Such
certificates are to be physically verified every quarter with the Ledger
balance of the concerned account.
11

<!-- page 20 -->

iii.

The maturity date of each and every investment should be watched and
prompt renewal/encashment should be ensured.

At the time of making investment, renewal or closure of the FDRs and receipt of interest,
necessary journal entries are to be made duly mentioning the name & number of such
FDR. Separate ledger account should be maintained for each FDR.
4.8. Registers/Documents to be maintained :
1. All the original documents relating to Registration with TAX authorities such
TAN/PAN, Customs/Excise exemption certificates, etc, of the Institute.
2. The Cheque books should be kept in the custody of the Section Officer of
Finance Section.
3. Register to record all recurring payments such as Electricity, Water, internet
charges etc.
4. Register of Earnest Money Deposit: Entries are to be made as and when relevant
receipt or payment relating to parities is made in the relevant ledger accounts in a
consolidated form. In this register, entries to be made party wise and receipt and
payments linked to relevant entry in the ledger giving reference to relevant
receipt/voucher number with details of contract or purpose of receiving EMD. The total
balance in the register should be reconciled with the ledger balance, every month.
5. Register of Security Deposit – Receipts and payments of Security Deposits partywise, the purpose and relevant contract should be recorded in this register. Entries made
should relate to the relevant voucher number as recorded in the ledger accounts. The
balance appearing in the ledger account in a consolidated form should be reconciled with
the balance in this register every month.
6. Register of investments- Investments shall be classified under long term i.e., for
more than one year term and current investments under less than one year and are
intended to be held for purpose of ready encashment to meet exigencies. Each earmarked
and endowment fund investments should be individually and separately recorded and
other short term investments from revenue receipts must be separately recorded. This
register will show number and date of the term deposit, period for which invested, rate of
interest, and maturity value. Entry will be made for all renewals and encashment including
premature encashment indicating interest earned. Entries made will indicate the relevant
ledger entry and the amount under individual classification and total shall agree with the
compiled actual.
12

<!-- page 21 -->

7. Register of Grants-in-aid - The number and date of sanction of Grants-in-aid
under each classification such as Plan Grant Asset‟s creation, General, SC/ST Non
recurring and Re-curring should be separately recorded in this register. Receipt during the
year under each head should be recorded under each classification. Annually, expenditure
incurred under each head of account be recorded and unspent balance/deficiency be
recorded on which basis Utilization Certificate be submitted to the Ministry/Grantor.
8. Register of sponsored /Research and Development Projects- Number and date
of sanctions for each project, Name of Grantor, Period of the project, amount of sanction,
amount released during the year, name of the project, name of Coordinator along with
break up details of grant as sanctioned for Capital expenditure and other recurring
expenditure for each year should be recorded in this register. Amount of expenditure
incurred each year and unspent balance/deficiency arrived for rendering Utilization
Certificate to the Grantor authority.
9. Register of Fellowship /Scholarship: It is to indicate the name of the grantor,
number and date of the sanction, amount of scholarship, period to which it relates, name
of the student, Department and Semester details. Amount paid to the student amount
adjusted towards hostel or other fees. Receipts and payments should indicate date and
number of voucher. The total and net remaining balance should match with the Ledger
balance.
10. Student Fee Register – Since Fee are paid into the bank and Students generate
the medium of deposit from the net, receipt can be entered into the ledger in a
consolidated form on a monthly basis. This register will be on the basis of Semester-wise,
department-wise and Student-wise. Data generated from the Bank Statement could also
be source for building up this Register.
11. Student Fee Demand –Collection-Balance Register: This is to be maintained in
order to ascertain the exact amount of dues from students at any given point of time for
follow up action
12.To ensure a transparent and accurate accounting system, separate books of
accounts and record of fund flow for the project funds will be maintained. The standard
Books of Account (Cash Book, Bank Book, Journal, Ledgers, etc.) will be maintained.
13. Chart of Accounts: The Chart of Accounts provides the detailed list of ledger
accounts that are required to be maintained by Finance Section as per the instructions
and formats provided by MHRD. As the said chart of accounts comprehensively covers all
the account heads that would be required to account for transactions, it is expected that
13

<!-- page 22 -->

no additional accounts will be required to be opened. The Chart of Accounts based on the
MHRD instructions is furnished in the separate Chapter.
14. Mapping of Expenditure: The Mapping of Expenditure provides the information
about the permissible expenditure of the Institute under different components and
sub‐components to be reported under respective accounting heads
15. Standard Books of Accounts to be maintained at Finance Section:
(i) Cash Book: The Finance Section will maintain Cash Book as per the format
given in Tally software. The transactions of Bank will be recorded in the Cash
Book along with classification as and when transactions take place. The Cash
Book will be closed monthly and attested by the In‐charge (Finance).
(ii)Petty Cash / Imprest Advance Book: A reasonable amount of cheque pament will
be made as Imprest to meet routine office expenses at the Departments and it
will be in the custody of the respective Imprest holder.
(iii) Journal Book and Journal Vouchers: Journal Voucher will be prepared for any
adjustment entry and the same will be posted to Journal Book. The entries
from Journal Book will be posted to General Ledger as and when recorded in
the Journal Book, giving full details of transactions, Journal Voucher number
and amount.
(iv) General Ledger: The entries from Cash Book will be posted to General Ledger
as the transactions occur. It will be balanced on before 5th of succeeding
month.
(v) Subsidiary Ledgers: Subsidiary Ledgers should be maintained for the group of
Accounts Receivables such as Pending Advances, fee receivable from students,
other Receivables, etc and Accounts Payables such as Sundry Creditors, EMD,
Security Deposit Payable, etc.
(vi) Fixed Asset Register:

The Institute will maintain a separate Fixed Asset

Register to record the assets acquired and created out of grant-in-aid, project
funds, donations, etc. Individual asset‐wise entries will be recorded in the Fixed
Asset Register. An identification number would be assigned to each item of
asset for easy identification. These identification numbers would be painted on
each item prominently and the same would be recorded in the Fixed Assets
Register.

There will be an annual physical verification of fixed assets. The

result of such verification will be recorded in Fixed Asset Register under date
14

<!-- page 23 -->

and signature of verifying officer. Any significant difference will be dealt with in
the books of accounts properly.
(vii) General Advances Register: The Institution shall maintain advances register for
the temporary advances given for any specific purpose.
(viii) Register of Contracts: There should be separate Register of Contracts.
(ix) Advances to staff: Details of various advances made to the employees such as
Festival Advance, LTC advances, TA advances, etc.
(x) Budget Control Register – Details of amount approved by UGC, provision made
and actual amount spent under each head of account will be furnished in this
Register.
(xi) Despatch & Incoming Tapal Register - Every department shall have a despatch
register and incoming register to record all outgoing and incoming office
correspondence with outside agencies of the Institute. No Official letters shall
be sent without an entry and a reference number in the despatch register.
4.9. Inter Unit Transfer:
Generally, no fund shall be transferred from one account to another. In
extraordinary circumstances, if fund is transferred with the approval of authorities,
such transfer shall be accounted for properly in both the accounts i.e. transferor
account and transferee account as detailed below:
1)

Transfer Debit Advice (TDA) / Transfer Credit Advice (TCA):
i) When one account is to be debited by another towards transfer of fund /
materials / expenditure / accounting of any other receivables, an advice
called „TDA‟ is prepared. When fund / materials / expenditure is
transferred from one account to another, the transferor shall raise a
„Transfer Debit Advice‟, wherein, the details of payment made such as
cheque number, date, amount of transfer, etc. or journal reference if any
are mentioned. This advice is prepared in triplicate. First and Second
copies shall be sent to the transferee of the fund, keeping the third copy
for his reference.
ii) On receipt of such TDA, the dealing assistant who maintains the transferee
account shall prepare a journal and after recording the same in his books
of accounts, return the second copy, duly mentioning the reference of
15

<!-- page 24 -->

such Journal Voucher to the originator. The first copy shall be retained by
him for his reference.
iii) In the same way, „Transfer Credit Advice‟ may also be operated for
crediting another account.
iv) On or before 15th of every month, the acceptances of all such TDAs/TCAs
shall be reviewed by the Section Officer in order to ascertain the prompt
accounting of such transfer in both the accounts. If no acceptance is
received, reminder shall be given to regularize the accounting of fund such
transfer.
v) It shall be ensured that all the Transfer Debit Advices (TDAs) and Transfer
Credit Advices (TCAs) raised are accepted and properly accounted so as to
ensure that the net balance of all the Inter Unit transfer account becomes
zero as on the date of closure of accounts.
vi) In case of fund transfer from one account to another, the transactions
shall be shown under the group of “Inter Unit Account” as the Current
Liabilities. The balances appearing on each account of the Inter Unit
accounts shall be analysed and ensured that the corresponding balances
appear on the respective account. A statement showing all the balances of
debit and credit with the details of individual accounts shall be prepared
and submitted along with monthly accounts. The grand total of all debit
balances and credit balances should be equal. In case of discrepancy, the
individual accounts shall be analysed and corrections if any to be made, so
as to ensure that the balances shown are either payable from one account
or receivable by another account.
vii) It shall be ensured that the fund, materials etc. transferred on loan basis
are returned promptly and there is no long pending of dues from such
inter unit accounts.

16

<!-- page 25 -->

Form of TDA/TCA
In Triplicate
THE GANDHIGRAM RURAL INSTITUTE – DEEMED UNVIERSITY, GANDHIGRAM

TRANSFER DEBIT / CREDIT ADVICE
Originating Account No.__________
No. _______

Date : _____________

The undersigned has the honour to advise that a sum of Rs.____________
(Rupees

__________________________________________________________)

as detailed below has been debited / credited in transfer from our Account
No.____________ of ____________________________________ to your Account
No.____________ of ____________________________________ for the Financial
Year __________ and to request that an acceptance may please be furnished as
early as possible.

No. and date
of voucher

Particulars of transaction

Amount
Rs.

Total

Section Officer / Finance Section
(Transferor / Originator)

Acceptance by the Receiver of the Advice:
The advice is responded to in the accounts of No.________
vide Journal Entry No. ___________ dated ____________.

Section Officer / Finance Section
(Acceptor / Transferee)

17

<!-- page 26 -->

Chapter 5
Internal Control and Audit
5.1. Internal Control:
1. Internal control is an arrangement which provides for proper division and definition of
tasks and responsibilities, introduction of an appropriate accounting system and the
institution of forms of internal check. Internal check means the checks on day to day
transactions which operate continuously as part of the routine system whereby the work
of one person is proved independently or is complimentary to work of another, the
objective being the prevention or early detection of errors or fraud.
2. Internal control mechanism at Institutional level would include the following:
(i) Establishment of appropriate budgeting systems.
(ii) Regular monitoring of actual financial performance with budgets and targets.
(iii) Monitoring of physical and financial progress.
(iv) Establishment of procedures and systems for ensuring standard internal
controls such as checking of expenditures, appropriate documentation, levels
of authorization, bifurcation of duties, joint signature of two officers on all
payments, periodic bank reconciliation and physical verification.
3. For the purpose of proper checks and control, the institutions will ensure the following:
(i) Maintenance of basic day‐to‐day transactions on a regular basis in separate
registers and ledgers.
(ii) Generation of Trial Balance, Bank Reconciliation statements, Receipts and
Payment Account, Income and Expenditure statements, Balance Sheet etc. as per the
formats as prescribed by the MHRD.
(iii) Comparison of Statement of expenditure with the annual budgetary allocations
and categories of disbursement.
(iv) Periodic checks on delay in payments of pending bills and immediate corrective
action to be taken.
(v) Periodical review and /or internal audit of the Bank Reconciliation Statement
and Stock Registers by ensuring the preparation of Bank Reconciliation statement and
Stock Registers.

18

<!-- page 27 -->

4. The following are internal control points relating to Accounting functions:
(i)

Accounting of receipts and payments

(ii)

Realization of receipts

(iii)

Sanctions to expenditure and authorization to disburse

(iv)

Disbursement payments and utilization

(v)

Prompt making of entries in the books of accounts

(vi)

Evidence for substantiation of the entries in books of accounts

(vii)

Measures for periodical surprise check of physical assets

(viii)

Method of matching Balance in the Bank with balance as per books of
accounts

(ix)

Classification of capital and revenues

5. The process of internal control measures are:
a.

Depositors: Students and other parties depositing money should be requested to
deposit only through cheques/drafts or other electronic modes such as RTGS/NEFT
etc. directly into the Bank account. Cash transactions are not allowed in any case.

b.

The counterfoils of Pay-in-slips for depositing money in the Bank account should be
retained as a record in support of the deposit. This requires that the receipts are
properly classified and recorded in the ledger.

c.

Cheques / drafts and other direct credits should be checked from Bank Statement
as appearing in the net-banking access. This check should be carried out by the
Section Officer or other senior staff within three days of credit in the Bank. This
also requires that the Institute migrates all bank accounts to net banking facility so
as to enable periodic direct viewing of the Bank account for reconciliation purpose.

d.

Bank Reconciliation Statement is to be prepared and submitted to the authorities
on or before 5th of the following month. Balance in all Bank accounts should be
reconciled with the balance in the books of accounts and reconciliation statements
as appearing in the Tally software may be prepared, duly authenticated by the
Section Officer, Finance Section and kept in a separate file for audit purposes. Uncleared cheques deposited in the bank and cheques not presented by the
beneficiaries should be closely checked to ensure that the same has been cleared
or presented in subsequent month or months. Such clearance must be noted in the
month‟s reconciliation to which the same relates. Cases pending long shall be
carefully investigated and pursued to ensure that there is no misappropriation or
fraud.
19

<!-- page 28 -->

e.

Payments are to be invariably made through electronic mode ie NEFT / RTGS. If
not possible to transfer the fund electronically, only account payee cheques /
Demand Drafts are to be issued. The joint signatures of both the Registrar and the
Finance Officer of GRI, who have been authorized are necessary for drawing the
cheques. The outstation cheques are to be sent only through „Registered Post‟
invariably.

f.

Before payment is made, the relevant Bill is to be checked for its correctness and
submitted to the appropriate authority for approval.

g.

The bill or claim or invoices for services obtained must be addressed to Registrar of
the Institute and should have all details of Registration, PAN/TAN, Service Tax &
VAT. It should be checked to see that the same bill/invoice has not been produced
to claim any other payment.

h.

Documents evidencing of obtaining service, arrival of materials purchased should
be

checked

to

ensure

that

the

services/materials

have

been

actually

availed/received and recorded in the relevant Stock Register.
i.

After making payment, the documents submitted in support of the claim,
bill/invoice should be stamped “PAID & CANCELLED” and signed by the staff
passing the bill for payment to prevent making a double payment using the same
document / bill.

j.

It should be checked to see that purchase of service/materials is made only after
calling for tenders/quotations following the Purchase Procedure laid down and
Purchase Orders are placed by the competent authority.

k.

It should be ensured that entries are regularly made in the Assets Registers to be
maintained in the form GFR 40 vide Rule 190(2) of GFR.

l.

Periodically, at least once in a year, assets are to be physically verified for its
serviceability and working condition. The discarded, damaged, obsolete and
unusable assets are to be identified and action to be taken for e-auctioneering at
regular interval of six months period.

m.

Investments made in the form of Term Deposit Receipts should be periodically
verified and linked to the relevant ledger entries.

n.

All payments of above Rs.5000 are required to be stamped with Revenue Stamp to
be legally tenable.

20

<!-- page 29 -->

o.

All letters/remittances through cheques/DDs received directly or through post
should be opened by a responsible person in the Finance Section and action taken
immediately to avoid delay.

p.

It should be checked to see that only one cheque book for each bank account is in
use at a time and all cancelled cheques are retained in record for eventual check by
Audit or other authorities.

q.

Demands for the dues from students for fee remittances are to be raised
electronically through MIS system for the existing students and collections are to
be monitored by preparing the „Demand –Collection- Balance‟ statement. For the
newly admitted students fee collection is to be made through „on line‟ payment.
The refund is to be made to students by checking the „Fee Control Register‟ which
is being maintained at the Finance Section.

r.

Administrative approval for the expenditure proposals of more than Rupees One
Lakh is to be obtained from the Vice- Chancellor.

s.

The proposals for expenditures will be sanctioned by the authorities based on the
availability of Budget provisions ie after scrutiny by the Development and Finance
Sections.

t.

Permanent Advance or Imprest (Rule 291of GFR): Permanent Advance or imprest
for meeting day to day contingent and emergent expenditure may be granted to
the Departmental Heads, keeping the amount of advance as to the minimum
required for smooth functioning.

u.

Temporary Advances for Contingencies and Miscellaneous purpose (Rule 292 of
GFR): Temporary advance is given for any special purpose. The amount should be
spent only for the purpose for which it was drawn. The adjustment bill, along with
the remittance challan for the balance if any remitted into the Institute Bank
Account, shall be submitted within 15 days of the drawal of advance, failing which
the advance or balance shall be recovered from his next salary. No second advance
is allowed when the earlier advance is pending.

v.

All the bills are to be initiated by the concerned Department and further checked
for their accuracy by the concerned dealing assistant, Section Officer, Assistant
Registrar / Deputy Registrar, Finance Officer and the Registrar.

w.

Time barred cheques:
a. In case a time barred cheque is identified, the following journal entries are to be
made.
21

<!-- page 30 -->

a. Debit Bank A/c

Dr.

Credit To Time barred Cheques A/c
b. When a fresh cheque is issued:
Debit Time barred Cheques A/c

Dr.

Credit To Bank A/c
5.2. Financial powers:

i.

Finance Officer shall sanction proposals upto Rs.5000/-.

ii.

Registrar shall sanction proposals upto Rs.15000/-.

iii.

For amount exceeding Rs.15000/- proposals shall be approved by the ViceChancellor.

iv.

Imprest advance to Departments / Sections shall be based on the request from
the concerned HOD / Section Head and past recoupment records. Finance
Officer shall approve / sanction the imprest advance.

v.

Imprest advance holder may spend upto Rs.2000/- on purchase of a single
item, for which they cannot afford to wait for financial sanction from the
competent authorities from imprest advance.

5.3. Internal Audit:
i) Internal audit system is one of the important parts of financial management to
examine and verify the adequacy and effectiveness of the inherent internal control
system of an organization.
ii) All receipts and payment vouchers are to be checked by the Internal Audit
Section. The Accounts statements are to be verified by the Internal Audit Section on or
before 15th of every month.
iii) All the cash transactions / bank transactions carried out by the Departments,
hostels and Guest House, etc are to be checked for their accuracy and correctness. The
Bank book and Bank Pass sheet are to be checked on or before 15th of every month to
ensure the accuracy of the accounting of income and expenditures.
iv) A six monthly internal audit will be conducted by a team of Internal Audit
Section or “C.A Firm” appointed by the Institute for carrying out internal audit. The Report
of Internal Auditor should be prepared and submitted to the authorities at regular interval
of three months period.

22

<!-- page 31 -->

5.4. Statutory Audit:
1. The objective of the audit of the Institute accounts, is to enable the auditor to
express a professional opinion as to whether
(i) the Annual Financial Statements present fairly, in all material respects, the
sources and applications of funds for the period under audit examination,
(ii) the funds were utilized for the purposes for which they were provided, and
(iii) expenditures shown in the statements are as per the directions given by the
funding Agencies.
In addition, the auditor will express a professional opinion as deemed necessary.
2. The GRI will appoint a firm of chartered accountants for audit of the Institute by
following the required norms and procedure. The Finance Section will be required to
maintain the records of accounts of the grants-in-aid and the sponsored projects, to
enable the auditor to carry out necessary checks and verification effectively. For this
purpose, the Institution is required to furnish all documents / records to the auditors to
facilitate timely audit positively on or before the last week of April of every year, so that
the C&AG may be informed about the readiness for their audit. Annual audit of the
Institute by a firm of chartered accountants will be completed by second week of May, so
that the C&AG audit may be completed on or before 30th June of every Financial Year.
3. Period of Appointment:
The auditor shall be appointed for a period of one Financial Year beginning on 1st April
and ending on 31st March of the following year. The contract may be extended to two
years on the basis of performance of the auditor.
4.General: The auditor should be given access to all legal documents,
correspondence, Books of Accounts, Government Orders and Office Orders and any other
information associated with the Accounts and as deemed necessary by the Auditor.
5.5. C&AG Audit:
1. Time Frame for C&AG Audit: The Institute shall compile its accounts within a
period of three months from the date of closure of the Financial Year i.e. before 30th of
June and make them available for audit to enable the MHRD to lay the Reports and the
audited accounts before the Parliament within nine months of the closure of the
accounting year, ie 31st December of every year. In terms of GFR 211, the accounts of the
Institute shall be open to inspection by the sanctioning authority and audit, both by the
Comptroller and Auditor General of India under the provisions of section 20(1) of the
Comptroller & Auditor General‟s (Duties, Powers and Conditions Service) Act 1971 and
23

<!-- page 32 -->

internal audit by the Principal Accounts Office of MHRD, whenever the Institute is called
upon for such audit.
2. C&AG carries out audit of Institute‟s accounts annually as shown below:
A. Certificate Audit: Once the Financial Statements are prepared and approved by
the Finance Committee and Board of Management, the C&AG authorities are
intimated of the readiness and a team of auditors arrive to carry-out the
process of audit and certification. After certification the C&AG authorities render
Separate Audit Report (SAR). The Annual Financial Statement and SAR along
with action taken thereon are submitted to the Finance Committee and BOM for
approval. Thereafter, the report is submitted to the UGC which arranges the
Annual Financial Statement of the year along with SAR to be placed before both
the Houses of Parliament.
B. Transactional Audit: The C&AG also conducts regularity audit of the Institute on
all aspects covering all functional areas of the Institute. The normal areas to
which audit extends are cases of purchases, establishment functions such as
salaries and service matters of faculties and staff, pay fixations, leave
entitlements etc., Academic functions and departmental activities. The C&AG
team after completion of audit will issue an audit objection statement and the
Institute shall take suitable action on the observations and send a prompt reply
to C&AG authorities. C&AG also conductS performance audit of the Institute
periodically examining the Institute‟s functional aspects and render a report.

24

<!-- page 33 -->

Chapter 6
Accounting of Government Grants
6.1. Accounts of Grantee Institutions (Rule 210 of GFR):
Institutions or Organizations receiving grants should, irrespective of the amount
involved, be required to maintain subsidiary accounts of the Government grant and
furnish to the Accounts Officer a set of audited statement of accounts. These audited
statements of accounts are required to be furnished after utilization of the grants-inaid or whenever called for.
6.2. Audit of Accounts of Grants-in-aid (Rule 211 of GFR):
(i) The accounts of all grantee Institutions or Organizations shall be open to
inspection by the sanctioning authority and audit, both by the Comptroller and
Auditor General of India under the provision of CAG(DPC) Act 1971 and internal
audit by the Principal Accounts Office of the Ministry or Department, whenever
the Institution or Organization is called upon to do so and a provision to this
effect should invariably be incorporated in all orders sanctioning grants-in-aid.
(ii) (a) The accounts of the grantee Institution or Organization shall be audited by the
Comptroller and Auditor General of India under Section 14 of the Comptroller and
Auditor General of India (Duties, Powers and Conditions of Service) Act, 1971, if
the grants or loans to the institution in a financial year are not less than Rupees
twenty-five lakhs and also not less than seventy-five per cent of the total
expenditure of the Institution. The accounts may also be audited by the
Comptroller and Auditor General of India if the grants or loans in a financial year
are not less than Rupees one crore. Where the accounts are so audited by the
Comptroller and Auditor General of India in a financial year, he shall continue to
audit the accounts for a further period of two years notwithstanding that the
conditions outlined above are not fulfilled.
(b) Where any grant and /or loan is given for any specific purpose to any Institution
or Organization or authority, not being a foreign State or international
Body/Organization, the Comptroller and Auditor General is competent under
Section 15 (1) of the CAG‟s (DPC) Act, 1971, to scrutinize the procedures by
which the sanctioning authority satisfies itself as to the fulfillment of the
conditions subject to which such grants and/or loans were given and shall, for
this purpose, have right of access to the books and accounts of that Institute or
Organization or authority.
25

<!-- page 34 -->

(iii) In all other cases, the Institution or Organization shall get its accounts audited
from Chartered Accountants of its own choice.
(iv) Where the Comptroller and Auditor General of India is the sole auditor for a local
Body or Institution, auditing charges will be payable by the auditee Institution in
full unless specifically waived by Government.
6.3 Utilization Certificates (Rule 212 of GFR) :
In respect of non-recurring grants to an Institution or Organization, a certificate of
actual utilization of the grants received for the purpose for which it was sanctioned in
Form GFR 19-A, should be insisted upon in the order sanctioning the grants-in-aid. The
Utilization Certificate in respect of grants referred to in Rule 209 (6) should also
disclose whether the specified, quantified and qualitative targets that should have
been reached against the amount utilized, were in fact reached, and if not, the
reasons therefor. They should contain an output based performance assessment
instead of input based performance assessment. The Utilization Certificate should be
submitted within twelve months of the closure of the financial year by the Institution
or Organization concerned. Receipt of such certificate shall be scrutinized by the
Ministry or Department concerned. Where such certificate is not received from the
grantee within the prescribed time, the Ministry or Department will be at liberty to
blacklist such Institution or Organization from any future grant, subsidy or other type
of financial support from the Government. This fact should also be put on the website
of the Ministry or Department. In respect of recurring grants, Ministry or Department
concerned should release any amount sanctioned for the subsequent financial year,
only after Utilization Certificate in respect of grants of preceding financial year is
submitted. Release of grants-in-aid in excess of 75 per cent of the total amount
sanctioned for the subsequent financial year shall be done only after the Utilization
Certificate and annual audited statement relating to grants-in-aid released in the
preceding year are submitted to the satisfaction of the Ministry/Department
concerned. Reports submitted by the Internal Audit parties of the Ministry or
Department and inspection reports received from Indian Audit and Accounts
Department and the performance reports, if any, received for the year should also be
looked into while sanctioning further grants.
NOTE. 1. Utilization certificates need not be furnished in cases where the grants-in-

aid are being made as reimbursement of expenditure already incurred on
the basis of duly audited accounts. In such cases the sanction letters
26

<!-- page 35 -->

should specify clearly that the utilization certificates will not be
necessary.
NOTE 2. In respect of Central Autonomous Organizations, the Utilization Certificate

shall disclose separately the actual expenditure incurred and the Loans
and Advances given to suppliers of materials and assets, to construction
agencies, to staff (for house building and purchase of conveyance, etc.),
which do not constitute expenditure at that stage. These shall be treated
as unutilized grants but allowed to be carried forward. While regulating
the grants for the subsequent year, the amounts carried forward shall be
taken into account.

27

<!-- page 36 -->

Form of Utilization Certificate:
The Gandhigram Rural Institute- Deemed University,
Gandhigram-624 302. Dindigul District. Tamilnadu
FORM GFR 19-A
Name of the Project:
Period of Utilization Certificate : From …..

To ….

(As per GFR Form 19-A Rule 212 (1))
Sl. No.

Letter
No. Amount
and date

Certified that out of Rs…… of Grants-in-aid
sanctioned during the year…….. in favour of the
Registrar, GRI, under this Ministry / UGC Letter

Total

No. given in the margin and Rs…………….. on
account of unspent balance of the previous year,

a sum of Rs……..has been utilized for the purpose of……………. for which it was sanctioned
and that the balance of Rs…….remaining unutilized at the end of the year has been
surrendered to the Government (vide No……. dated …..) will be adjusted towards the
grant-in-aid payable during the next year…… .
2. Certified that I have satisfied myself that the conditions on which the grants-in-aid was
sanctioned have been duly fulfilled/are being fulfilled and that I have exercised the
following checks to see that the money was actually utilized for the purpose for which it
was sanctioned.
Kinds of checks exercised;
1.
Signature……
Designation

2.

28

<!-- page 37 -->

Chapter 7
Chart of Accounts
7.1. Description of Account Code:
The Chart of Accounts contains Account Number for various transactions to be
uniformly followed for all the accounts maintained at the Finance Section.
i)

The Account Number has got a five digit numerical code in which, the first
two digits represent Accounts Centre as defined below:
1. Non-Plan Fund Account
2. Plan Fund Account
3. Corpus Fund Account
4. General Development Fund Account
5. Students Fund Account
6. Institute Fund Account
7. Students Deposit Fund Account
8. GPF Account
9. New Pension Scheme Account
10. UGC Project Accounts
11. CSIR Project Accounts
12. DAE Project Accounts
13. DST Project Accounts
14. ICSSR Project Accounts
15. NIOS Accounts
16. NSS Accounts
17. Tamil Nadu Funding Agencies Accounts
18. FCRA Accounts
19. MNRE-PCRA-Rural Energy Centre
20. KVK Main Account
21. KVK Revolving Fund (Farm) Account
22. KVK Revolving Fund (Building) Account
23. OBE VIII STD Accounts
24. Distance Education Centre Account
25. Project - Others
26. Fellowship Accounts
27. Scholarship Accounts
28. Endowment Accounts
29. ………… upto 99.
Other accounts will be added as and when necessary upto 99.
ii)

Second digit represents as follows:
1. Liabilities
2. Assets
3. Income
4. Expenditure

iii)

Last two digits represent Group Code, under which various Ledger accounts
are maintained.
29

<!-- page 38 -->

iv)

Account Code: xx x xx
01. Non-Plan, 02. Plan, 03. Corpus Fund ………….
1.Liability, 2. Asset, 3. Income, 4. Expenditure
Group Code eg. 12. Computers & Peripherals,
31. Temporary Advances

7.2. Account Code for Non-Plan:
1. Liabilities
Capital Fund
One Time Special Assistance Fund
Grant Account
Current Liabilities:
Deposits from staff
Deposits from students
Sundry Creditors
Deposit – Others
EMD Deposits
Security Deposits
Statutory Liabilities
Other Current Liabilities
Unutilised Grant
Grant-in-advance
Retirement Benefits Payable
Inter Unit Account
Provisions:
Provision for Leave Encashment
Provision for Retirement Gratuity
Provision for Superannuation
Any other provision
2. Assets
Fixed Assets:
Land
Buildings
Roads & Bridges
Tube wells & Water supply
Sewerage & Drainage
Electrical Installations & Equipment
Plant & Machinery
Scientific & Laboratory Equipment
Office Equipment
Audio Visual Equipment
Computers & Peripherals
Furniture, Fixture & Fittings
Vehicles
Lib.Books & Scientific Journals
30

01101
01102
01103
01104
01105
01106
01107
01108
01109
01110
01111
01112
01113
01114
01115
01116
01117
01118
01119

01201
01202
01203
01205
01206
01207
01208
01209
01210
01211
01212
01213
01214
01215

<!-- page 39 -->

Small Value Assets
(Others)
Capital Works-in-Progress
Intangible Assets
Investments:
Long Term Investments
Short Term Investments
Investments – Others
Current Assets:
Stock of materials
Sundry Debtors
Bank Balances with Scheduled Banks
Bank Balances with Non-Scheduled Banks
Loans, Advances and Deposits:
Loans:
Vehicles Loans
House Building Advance (HBA)
Any other Loans to Employees
Advances:
Festival Advances to Employees
TA/LTC Advances
Temporary Advances to Employees
Imprest Advances
Deposits:
Deposit with CPWD
Deposits with TNEB
Gas Connection Deposit
Telephone Deposit
Deposits with others
Income Accrued:
Interest on Investments
Interest on Loans and Advances
Grants sanctioned and Receivables
Other Account Receivables
3. Income
Academic Receipts
Grants / Subsidies
Income from Investments
Interest Earned on SB Accounts
Other Income
Prior Period Income
4. Expenditure

Staff Payments and Benefits
Academic Expenses

Administrative and General Expenses
Transportation Expenses
Finance Costs
Depreciation
Other Expenses
31

01216
01217
01218
01219
01220
01221
01222
01223
01224
01225

01226
01227
01228
01229
01230
01231
01232
01233
01234
01235
01236
01237
01238
01239
01240
01241
01301
01302
01303
01304
01305
01306

01401
01402
01403
01404
01405
01406
01407

<!-- page 40 -->

Prior Period Expenses

01408

In the same way, Accounts codes can be created for other Accounts
Centres. For Example, Account Code for Plan Fund Account:
EMD
02108
Buildings
02202
Deposit with CPWD
02233
Grants / Subsidy
02302
Transportation Expenses
02404

32

<!-- page 41 -->

Chapter 8
Budget Estimate and Reports

1. Budget is an instrument of Financial Control. Budget is defined as “A comprehensive
plan, expressed in financial terms by which an operating programme is effective for a
period of time. It includes estimate of services, activities and projects comprising the
programme” (Chapter 9 GFR). As the Institute is fully funded by the Government of India
through the MHRD Budget, Institute has to follow instructions contained in Appendix – 3
GFR 48 which refers to estimates for expenditure on two categories: Non-Plan
expenditure (Recurring) and Plan (Non-recurring).
A)

Non-Plan - Revised Budget Estimate for the current year should always precede
estimation for the ensuing year. Revised Estimate should be framed with great care
to include only those items which are likely to materialize for payment during the
current year, in the light of
i)

actual so far recorded during the current year, compared with the actual for
corresponding period of the last and previous years.

(ii)

Seasonal character or otherwise of the nature of expenditure

(iii)

sanctions for expenditure and orders of appropriation or re-appropriation
already issued or contemplated and

(iv)

any other relevant factor, decision or development.

The Budget estimate for the ensuing year be prepared on the basis of what is
expected to be paid during the ensuing year including arrears of the previous years
if any. Due attention to considerations of economy must be paid and while all
inescapable and foreseeable expenditure should be provided for, care should be
taken that the estimate is not influenced by undue optimism.
B)

Plan Expenditure - Estimate / Revised Estimates: While preparing the Budget
Estimates for the Plan Expenditure, the instructions given by the UGC are to be
followed.

2.

Factors to be noted when framing Budget:
i) Objectives of the entity
ii) Plan outlay and its outcome
iii) Target to be achieved
iv) Cost overrun
v) Savings in some segments and excess in others
vi) Additional onsite eventualities

3.

Budget has three primary functions to perform:
33

<!-- page 42 -->

i)

Planning: It refers to the process of determining objectives and evaluation of
programmes.

ii)

Management: Budget provides authority to ensure efficient use of resources.

iii)

Control: It is a process of enforcing the limitations and conditions set in the
budget. Comparison of actual attainment with the Budget provision by
variance analysis should facilitate for taking corrective action or revision.

4.

Non-Plan (Recurring) Budget estimate is forecast under each head of account
i. Salaries and
ii. Non-salaries etc.
iii. In order to do so the Budget has to follow the same layout of Accounts heads
which from part of the ledger accounts maintained by the Accounts Department.
The layout of ledger accounts are planned and systematically laid down to match
the layout plan of the new MHRD Annual Financial Report format. The broad
division recurring expenditure appearing in the Income and Expenditure are:
a. Staff Payments and Benefits
b. Academic Expenses
c. Administrative and General Expenses
d. Transportation Expenses
e. Repair and Maintenance
f. Finance Costs
g. Other Expenses.
Thus, Budget has to be forecast under this broad division with sub-divisions. The
sub-divisions of these Major heads are as follows:

5.
I.

STAFF PAYMENTS & BENEFITS
a. Salaries and Wages with further subheads separately for i) Teaching Staff ii)
Non-Teaching Staff iii) Ad-hoc staff iv) Arrears of DA iv) Salary arrears due to
increment/pay-fixation on promotion etc.

II.

b. Allowances and Bonus
c. Contribution to New Pension Fund
d. Staff Welfare Expenses
e. Retirement and Terminal Benefits
f. LTC facility
g. Medical facility
h. Children Education Allowance
i. Honorarium
j. TA/DA expenses
k. Others
ADMINISTRATIVE AND GENERAL EXPENSES
a. Electricity and Power
b. Water charges
c. Insurance
d. Rent, Rates, and Taxes (including Property Tax)
34

<!-- page 43 -->

e. Postage and telegram
f. Telephone and Internet Charges
g. Printing and Stationery
h. Travelling and Conveyance Expenses
i. Expenses on Seminar/Workshops
j. Hospitality
k. Auditors Remuneration
l. Professional charges
m. Advertisement and Publicity
n. Magazines and Journals
o. Other if any to be specified
III.
TRANSPORTATION EXPENSES
a. Vehicles (owned by Institution) i) Running Expenses, ii) Repairs and Maintenance,
iii) Insurance expenses and Taxes.
b. Vehicles taken on rent/lease a)Rent/lease expenses
IV.
REPAIRS AND MAINTENANCE
a. Building
b. Furniture & Fixture
c. Plant & Machinery
d. Office Equipments
e. Cleaning Materials and services
f. Others to be specified
V.
FINANCE COSTS
a. Interest on fixed loans
b. Interest on other loans
c. Bank charges
d. Others to be specified
VI.
OTHER EXPENSES
a. Provision for Bad and Doubtful Debts/Advances
b. Irrecoverable Balances written off
c. Others to be specified.
6.

Budget reports:
The UGC in terms of GFR 209 calls for requirement of funds with supporting details

by the end of October every year. In addition, UGC may call for requirement of funds
every quarter for release of quarterly installments of funds. The Finance Section is also
required to submit expenditure details against budgetary allotment to the Finance
Committee and Board of Management. The reports submitted at the end of October will
give details of actual expenditure up to September of the year and expenditure up to
September of the previous year. This report should also contain details of budget and
expenditure thereof of the previous three years and forecast budget of the following year.
The projection for the ensuing year may indicate anticipated amount of internal revenue
generation by way of fees and interest on deposits if any. The UGC will use this
information for releasing grant and quarterly installments. Therefore these reports are to
be carefully and properly prepared.
35

<!-- page 44 -->

Chapter 9
Compilation of Annual Accounts and Balance Sheet
9.1. Introduction:
The Department of Higher Education, MHRD has introduced the Revised formats of
Accounts of Central Educational Institutions vide their letter number 29-4/2012-IFD dated
17.04.2015 to be implemented from the Financial Year 2014-15. The detailed notes and
instructions for compilation of Financial statements issued by MHRD are to be strictly
followed. The preparation and presentation of Annual Accounts of the Institute need to be
strictly as per the revised formats of Accounts, as approved by the office of the C&AG of
India which are as follows.
9.2. Accounting Principles:

1) The financial statements of non-profit and other similar organizations (viz., Balance
Sheet and Income and Expenditure Account) shall be prepared on accrual basis;
and shall be in the form suggested, or as near thereto as possible.
2) Normally, Central Educational Institutions cannot raise loans, particularly by
pledging their Assets. The heads Secured Loans & unsecured Loans do not
therefore find a place in the Balance Sheet. If however there is a rare case of an
institution getting a World Bank Loan, a new head "unsecured loans" could be
included on the Liabilities side of the Balance Sheet supported by a Schedule.
3) It is mandatory to follow the Accounting Standards applicable for Autonomous
organizations and Higher Educational Institutions. Where any of the accounting
policies is not in conformity with accounting standards, and the effect of departures
from accounting standards is material, the particulars of the departure shall be
disclosed, together with the reasons therefor and the financial effect thereof,
except where such effect is not ascertainable.
4) A statement of all significant accounting policies adopted in the preparation of the
Balance Sheet and the Income and Expenditure Account shall be included in the
financial statements. The significant Accounting Policies should be disclosed at one
place. Accounting Policies refer to the specific accounting principles and the
method of applying those principles adopted by the Entity in the preparation of the
financial Statements. Accounting policies shall be applied consistently from one
financial year to the next. Any change in the accounting policies which has a
36

<!-- page 45 -->

material effect in the current period or which is reasonably expected to have a
material effect in later periods, shall be disclosed in the Notes on Accounts. In case
of a change in accounting policies which has a material effect in the current period,
the amount by which any item in the financial statements is affected by such
change, shall also be disclosed to the extent ascertainable. Where such amount is
not ascertainable, wholly or in part, the fact shall be disclosed.
5) The accounting treatment and presentation in the Balance Sheet and the Income
and Expenditure Account, of transactions and events shall be governed by their
substance and not merely by the legal form.
6) In determining the accounting treatment and manner of disclosure of an item in the
Balance Sheet and/or the Income and Expenditure Account, due consideration shall
be given to the concept of materiality. If the information required to be given
under any of the items or sub-items in this Form cannot be conveniently included in
the Balance Sheet or the Income and Expenditure Account itself, as the case may
be, it can be furnished in a separate Schedule or Schedules to be annexed to and
forming part of the Balance Sheet or the Income and Expenditure account. This is
recommended where items are numerous.
7) The Schedules referred to above and the Schedules forming part of the Accounts
(Significant Accounting Policies; Contingent liabilities and Notes on Accounts)
should form an integral part of the financial statements.
8) The corresponding amounts for the immediately preceding year for all items shown
in the Balance Sheet and the Income and Expenditure Account should also be given
in the Balance Sheet or Income and Expenditure Account as the case may be.
9) Revenue shall not be recognized unless:
(a) The related performance has been achieved;
(b) No significant uncertainty exists regarding the amount of the consideration; and
(c) It is not unreasonable to expect realization and ultimate collection.
10) Provision shall be made for all known liabilities and losses even though the amount
cannot be determined with substantial accuracy (and the amount of provision
represents only a best estimate in the light of available information). Provision
means any amount written off or retained by way of providing for depreciation,
renewals or diminution in value of assets, or retained by way of providing for any
37

<!-- page 46 -->

known liability, the amount of which cannot be determined with substantial
accuracy.
Provision shall be made for contingent loss, if:
a) It is probable that future events will confirm that, after taking into account any
related probable recovery, an asset has been impaired or a liability has been
incurred at the balance sheet date, and
b) A reasonable estimate of the amount of the resulting loss can be made. If either
of the above conditions is not met, the existence of the contingent loss shall be
disclosed by way of a note to the Income and Expenditure account, unless the
possibility of the loss is remote.
11) Where any amount written off or retained by way of providing for depreciation,
renewals or diminution in the value of assets or retained by way of providing for
any known liability is in excess of the amount which is considered reasonably
necessary for the purpose, the excess shall be treated as a reserve and not as a
provision.
12) Separate disclosure shall be made in the Income and Expenditure Account in
respect of:
(a) "Prior period" items, which comprise material items of income or expenses which
arise in the current period as a result of errors or omissions or non provision of
Liability for outstanding expenses due to adoption of Cut- off date for the purpose
of closing the accounts, in the preparation of the financial statements of one or
more prior periods. The concept of Prior Period Income and Prior Period
expenditure applies only to Revenue items, and not to Asset/Liability Accounts. The
latter are accounted in the year in which the corresponding transactions take place.
(b) "Extra ordinary" items, which are material items of income or expenses that arise
from events or transactions that are clearly distinct from the ordinary activities of
the entity and, therefore, are not expected to recur frequently or regularly.
(c) Any item under the head "Miscellaneous Income" which exceeds 1 per cent of the
total turnover/gross income of entity or Rs.50,0001-, whichever is higher. This shall
be shown against an appropriate account head in the Income and Expenditure
Account.
(d) Any item under the head "Miscellaneous Expenses" which exceeds 1 per cent ur
the total turnover/gross income of entity or Rs.50,000/- whichever is higher. This
38

<!-- page 47 -->

shall be shown as a separate and distinct item against an appropriate account head
in the Income and Expenditure account.
13)A Receipts and Payments Account shall also be prepared by the Educational
Institutions.
14)Disclosures as suggested in the formats are minimum requirements. An Educational
Institute is encouraged to make additional disclosures.
15) The figures in the Balance Sheet and Income and Expenditure Account, if rounded
off, shall be rounded off as below:
Amount of turnover (in Rs.)

Rounding off to (Rs.)

Less than One lakh

Hundred

One lakh or more but less than one crore

Thousand

One crore or more but less than one

Lakh

hundred crore
One hundred or more but less than one

Crore

thousand crore

16) Reference may also be made to the enclosed Notes and Instructions for
compilation in relation to the formats suggested.
17) Most Central Universities and Institutes of Higher education, manage the general
Provident Fund and New Pension Scheme Funds. These are owned by the
members and hence cannot be accounted as part of the Accounts of the
Institutions. As these are managed by them along with their accounts, it is
necessary to prepare annually for these funds, a Balance Sheet, an Income and
Expenditure Account (on accrual basis) and a Receipts and Payments Account and
separately attach them to the accounts of the Institution, to show that they are
managed in the best interests of the members.
In respect of the New Pension Scheme, funds in respect of the employees
who have been allotted PRA numbers, would have been transferred to the
National Securities Depository Limited (NSDL) - Central Record Keeping Agency
(CRA). In these cases, only the employers contribution along with the subscription
recovered are transferred every month to NSDL. "The employers contribution is

39

<!-- page 48 -->

included in Schedule 15- Establishment expenses- Retirement and Terminal
Benefits"
If there are any employees whose subscriptions and matching contributions
have been retained and managed by the Institution pending allotment of PRA
numbers, the annual Accounts of the New Pension Scheme (including interest
credited) to be attached separately to the accounts of the Institution, will cover
only such employees. The formats in which GPF, CPF and NPS Annual Accounts
have to be Prepared, as given by MHRD.
9.3 Other Important Instructions regarding compilation of accounts:
1. Accounting Period:
The accounting period for which the annual accounts have to be compiled by the
Institute shall be a period of twelve calendar months ending on the 31st day of
March every year or in the case of the first accounts a shorter period commencing
on the date of constitution of such account centre and ending on the immediately
following the 31st day of March.
2. Submission of Monthly and Quarterly accounts:
The accounting entries of all the individual accounts shall be posted upto date in
the Tally software and the Income and Expenditure of every month shall be
generated on or before 10th of succeeding month. It should be ensured that the
Bank Reconciliation is prepared for all the individual accounts and differences if any
are made good by making necessary correction entries. The quarterly accounts
statements shall be submitted to the authorities as detailed below:
April to June

:

25th July

July to September

:

25th October

October to December

:

25th January

January to March

:

30th April

3. Compilation and Submission of Annual Accounts:
i) The Institute shall compile its accounts within a period of three months from the
date of closure of the Financial Year i.e. before 30th of June and make them
available for audit to enable the MHRD to lay the Reports and the audited
accounts before Parliament within nine months of the close of the accounting
year, ie 31st December of every year.
ii. Subsidiary ledgers shall be maintained for detailed analysis of the balances in
main ledgers wherever such details are required such as creditors, contractors,
40

<!-- page 49 -->

employees, students etc. Subsidiary ledgers for EMD, Security Deposits,
Advances to employees, Fee Receivables from students, Deposits accounts
refundable to students, deductions and remittances into Government Accounts,
etc. are to be verified for their correctness.
iii) Bank Reconciliation Statement – The Bank Reconciliation Report as on the
closing date shall be verified so as to ensure the correctness of the receipts and
payments. The correction entries if any shall be made and the copy of BRS shall
be submitted along with the statement of accounts.
iv) The certificate for the Bank balance as on 31 st March shall be obtained from the
concerned Branch and submitted along with statement of accounts for
verification by the auditors.
v) The Ledger balances of the individual investment accounts shall be verified and
tallied with the availability of physical certificates / FDRs. In case of discrepancy
necessary Journal Entry, omitted to have been entered at the time of closure /
renewal is to be made. The total balance of the investments should tally with
the availability of investment certificates / FDRs which will be physically verified
by both the Statutory Auditors and AG‟s auditors.
vi. Imprest – It shall be ensured that all the imprest accounts are settled on or
before 31st March.
vii. Temporary advance – It shall be ensured that all the temporary advances
drawn are settled on or before 31st March except in emergent cases.
viii. Inter Unit Transfer – It shall be ensured that the fund transferred on loan basis
is returned before closure of the accounts. All the Transfer Debit Advices (TDAs)
and Transfer Credit Advices (TCAs) raised shall be accepted and properly
accounted so as to ensure that the net balance of all the Inter Unit transfer
account becomes zero as on the date of closure of accounts.
ix. At the year end, all the accruals both income and expenditure as also any other
outstanding liabilities shall be brought into account through journal entries. It
shall be ensured that all the income due, such as fee receivable from students,
interest receivable from banks, refund of deposits due etc. are taken into
account before closure of accounts. Necessary journal entry based on accrual
concept, shall be made. Interest on Investments shall be approximately
calculated and accounted on accrual basis. This provision shall be reversed in
the beginning of next year.
41

<!-- page 50 -->

x. Expenditure due - No Provision need be made for March salary as the pay bills
for the month of March will be journalized in the month of March itself.
xi. A few adjusting entries that are to be passed have been illustrated below. The
illustrations are only indicative and not exhaustive.
a) Interest on provident fund:
Interest on G.P.F. A/c

Dr.

To G.P.F. Account
Note: The interest shall be correctly calculated and accounted for as above.
b) Expenses outstanding:
Concerned Expenses Account

Dr.

To Provision for liability for expenses
Note: This journal entry shall be reversed at the beginning of the next year.
c) Expenses Prepaid:
Pre-paid Expenses

Dr.

To Concerned expenses Account
Note: This journal entry shall be reversed.
d) Income Accrued:
Income accrued and due Dr……..
Income accrued but not due Dr……..
To Concerned income account
Note: This journal entry shall be reversed
e) Depreciation:
Depreciation on : Building

Dr……..

Depreciation on : Plant and Machinery

Dr……..

Depreciation on : Vehicles

Dr……..

Depreciation on : Furniture

Dr……..

Depreciation on : Office Equipment

Dr……..

To Provision for depreciation : Building
To Provision for Depreciation : Plant and Machinery
To Provision for depreciation : Vehicles
To Provision for depreciation : Furniture
To Provision for depreciation : Office Equipments
Note: The above journal entry shall not be reversed.
42

<!-- page 51 -->

xii. Simultaneous with the preparation of adjusting journal entries all the adjusting
entries made during the previous year if any that are to be reversed shall be
reversed through journal entries.
xiii. Preparation of list of contingent liabilities in consultation with other
departments concerned.
xiv. Preparation of Annual Statement of Accounts - The Schedules forming part of
Balance Sheet and Income & Expenditure Account are to be prepared as per
the General Instructions given by MHRD vide Circular No.29-4/2012-IFD dated
17.4.2015.

43

<!-- page 52 -->

Form of Balance Sheet:
THE GANDHIGRAM RURAL INSTITUTE – DEEMED UNVIERSITY, GANDHIGRAM
BALANCE SHEET AS AT 31ST March, ……..
Amount in Rs.
Schedule Current Year
1
ENDOW2

SOURCES OF FUNDS
CORPUS/CAPITAL FUND
DESIGNATED/EARMARKED /
MENT FUNDS
CURRENT LIABILITIES & PROVISIONS
TOTAL

3

APPLICATION OF FUNDS
FIXED ASSETS
Tangible Assets
Intangible Assets
Capital Works-in-Progress
INVESTMENTS FROM
ENDOWMENT FUNDS
Long Term
Short Term

EARMARKED

Previous Year

Schedule Current Year
4

/

5

INVESTMENT - OTHERS
CURRENT ASSETS
LOANS, ADVANCES & DEPOSITS
TOTAL

6
7
8

44

Previous Year

<!-- page 53 -->

Form of Income and Expenditure Account:
THE GANDHIGRAM RURAL INSTITUTE – DEEMED UNVIERSITY, GANDHIGRAM
INCOME AND EXPENDITURE ACCOUNT FOR THE PERIOD / YEAR ENDED 31st MARCH, ___

Amount in Rs.
Particular
Schedule Current Year
INCOME
Academic Receipts
9
Grants / Subsidies
10
Income from Investments
11
Interest earned
12
Other Income
13
Prior Period income
14
TOTAL (A)
EXPENDITURE
Staff Payments & Benefits (Establishment
Expenses)
15
Academic Expenses
16
Administrative and General Expenses
17
Transportation Expenses
18
Repairs & Maintenance
19
Finance Costs
20
Depreciation
4
Other Expenses
21
Prior Period Expenses
22
TOTAL (B)
Balance being excess of income over
Expenditure (A-B)
Transfer to / from Designated Fund
Building fund
Others (Specify)
Balance Being Surplus / (Deficit) Carried
to Capital Fund
Significant Accounting Policies
Contingent Liabilities and Notes to Accounts

23
24

45

Previous Year

<!-- page 54 -->

PART-II – PURCHASE AND WORKS
Chapter 1
Permanent Advance and Temporary Advance
1.1.Permanent Advance or Imprest : (Rule 291of GFR):
Permanent Advance or Imprest may be granted to the Departmental Heads for
meeting day to day contingent and emergent expenditure. The amount of advance to be
granted shall be kept at the minimum required for the smooth functioning of the
Department subject to the following conditions.
i)

All imprest holders have to bear in mind that the imprest is meant only to
meet urgent and unforeseen expenditure in the day to day functioning of
the Department.

ii)

The imprest amount drawn shall be kept in possession of the imprest holder
and the expenses shall be met out of that imprest.

iii)

Imprest Holder shall invariably cancel all the original sub-vouchers so that it
would be impossible to use them in support of a double or fraudulent claim.

iv)

Duplicate or Photo copy of the vouchers will not be accepted.

v)

All imprest holders will maintain Imprest Register.

vi)

The Imprest Register along with vouchers will be sent for recoupment.

vii)

The bill amount should be rounded off to the nearest rupee.

viii)

Objectionable payment not requiring detailed investigation may be
disallowed and the imprest holder may be intimated accordingly.

ix)

Ledger Account should be maintained for the Permanent Imprest Account
allotting separate folio for each individual.

x)

Imprest advance to Departments / Sections shall be based on the request
from the concerned HOD / Section Head and past recoupment records.

xi)

Imprest advance holder can spend upto Rs.2000/- on purchase of single
item, for which they cannot afford to wait for financial sanction from the
competent authorities from imprest advance.

xii)

The maximum limit of Imprest Amount shall be decided and approved by the
authorities based on the actual requirement.

xiii)

On inspection, at any given point of time, the total imprest amount should
agree with the cash balance in hand and the bills on hand / bills submitted.
46

<!-- page 55 -->

xiv)

At the year end, the unspent cash balance shall be remitted into Institute‟s
Bank account on or before 31st of March under intimation to the Finance
Section.

The vouchers for the amount spent shall also be sent to the

Finance Section for adjustment of the imprest.
1.2. Temporary Advance (Advances for Contingent and Miscellaneous purpose)
(Rule 292(1) of GFR):
Temporary Advance is sanctioned when it is considered necessary for the purpose
of meeting contingent expenditure of a specified kind or on a specified occasion. The
Authorities of the Institute may sanction advances to an employee, for purchase of goods
or services or any other special purpose needed for the management of the office, subject
to the following conditions:(i)

The amount of expenditure being higher than the Permanent Advance
available, cannot be met out of it.

(ii)

The purchase or other purpose cannot be managed under the normal
procedures, envisaging post- procurement payment system.

(iii)

The amount of advance should not be more than the power delegated to the
Head of the Office for the purpose.

(iv) The Head of the Office shall be responsible for timely recovery or adjustment
of the advance.
(v)

Rule 292 (2) of GFR: The adjustment bill, along with balance if any, shall
be submitted by the government servant within fifteen days of the
drawal of advance, failing which the advance or balance shall be
recovered from his next salary(ies). The copy of the challan for
remittance of balance amount if any, into the Canara Bank account of GRI,
shall be enclosed along with the adjustment Bill.

(vi)

The amount shall be spent only for the purpose for which it was drawn.

(vii) Temporary Advance should be adjusted by detailed bills and vouchers within
15 days from the date of receipt of Cheque.
(viii)

Separate ledger account shall be maintained for each account holder and the
list of advances shall be reviewed by the Section Officer on or before 10 th of
every month.

47

<!-- page 56 -->

(ix)

All third party payments will be made invariably by way of electronic transfer
ie NEFT/RTGS. If it is not possible, Account Payee cheque / Demand Draft
can be issued. No cash Payment or Money Order will be allowed except for
petty expenses.

48

<!-- page 57 -->

Chapter 2
Guidelines to claim NMR wages
The following guidelines are issued for claiming wages for engagement of NMRs.
1. Proposal for engagement of NMRs detailing the works to be done and the number
of man-days required along with the amount payable should be submitted to
Development Section at the beginning of the month for providing sanctions
2. The proposal will be transmitted to Finance Section for making financial provision
3. A register containing details of sanction orders, the names of the persons engaged,
the dates / number of days and the actual amount payable should be maintained in
the Department.
4. At the end of the month, duly certified bills along with Nominal Muster Rolls and
the register kept for the purpose duly certified that the works have been completed
satisfactorily should be submitted to the Finance Section. In case, the actual
number of days engaged exceeds the number of days for which sanction was
originally accorded, justification for the same should be furnished and revised
sanction order obtained while submitting the claim for payment.
5. Even in respect of NMRs to be engaged on a regular basis for routine works, the
above procedure will have to be followed.
6. The claim will be processed in Finance Section and a cheque issued to the HoD for
making the payment under acquittance.
7. Only in respect of NMRs engaged for very short duration for attending to
unforeseen and emergent works, payments shall be made out of imprest account
subject to a maximum of Rs.2000 for each work.
The above guidelines are to be followed strictly.

49

<!-- page 58 -->

Chapter 3
Purchase Procedures
Every authority delegated with the financial powers of procuring goods in public
interest shall have the responsibility and accountability to ensure efficiency, economy and
transparency in matters relating to public procurement and for fair and equitable
treatment of suppliers and promotion of competition in public procurement.
In accordance with the above principles, the following guidelines are framed for
observance while procuring the items such as machinery, equipment, furniture, chemicals,
glass wares, stationery, services such as repairs & maintenance, etc., as required by the
Faculties / Departments / Sections / Centres of GRI.
3.1. Terminology:
Standard terminology has been adopted as given below:i.

Tender, Bid, Quotation - Meaning: offer received from a supplier.

ii.

Tenderer, Bidder - Meaning: an entity who seeks to supply goods by sending
tender / bid.

iii.

Tender Enquiry Document, Tender Document, Bidding Document - Meaning: a
detailed document issued by the purchaser specifying his needs and the
requirement that a potential tenderer / bidder must meet.

iv.

Notice Inviting Tenders, Invitation for Bids - Meaning: advertisement
containing brief details of the requirement.

v.

Earnest Money Deposit, Bid Security - Meaning: monetary guarantee furnished
by a tenderer along with its tender.

vi.

Security Deposit, Performance Security - Meaning: monetary guarantee
furnished by the successful tenderer for due performance of the contract
concluded with it.

3.2. Financial Source for purchase proposals:
i) The source of finance will generally be made available to the authorities of this
Institute, under the following categories, in form of allocation / sanction.
a) Non-plan grant or maintenance grant.
b) Plan grant.
c) Ear marked special funds or project funds.
d) Special allocation from internal resources.
e) Special assistance from external sources

50

<!-- page 59 -->

All sanctions to the expenditure shall indicate the details of the provisions in the
relevant grant wherefrom such expenditure is to be met.
ii) Before initiating any purchase or approving purchase proposals, all the
functionaries / authorities should ensure the availability of finance, for their
respective units or at their disposal in the form of allocation or sanction under any
one of the sources mentioned.
iii) The Vice-Chancellor may allocate, sanction, re-allocate, re-appropriate, change
the head of account internally of the funds received under non-plan, plan, self
financing and special assistance head of accounts.

Provided that no re-

appropriation from Plan to Non plan or vice versa is resorted to unless specifically
permitted by UGC.
3.3. Mandatory Requirement of Financial Concurrence:
(i) It is mandatory that the financial concurrence from the Office of the Finance
Section has to be obtained by every Authority / Functionary while exercising
their power / delegated power towards purchase of Capital goods /
consumables.
(ii) While granting financial concurrence in every purchase proposals, the Finance
Section should keenly evaluate the budget allocation, fund position of the
respective Head of Account and compliance.
3.4. Financial powers for sanctioning expenditure:
i.

Finance Officer shall sanction proposals upto Rs.5000/-.

ii.

Registrar shall sanction proposals upto Rs.15000/-.

iii.

For amount exceeding Rs.15000/- proposals shall be approved by the ViceChancellor.

iv.

Imprest advance to Departments / Sections shall be based on the request form
the concerned HOD / Section Head and past recoupment records. Finance
Officer shall approve / sanction the imprest advance.

v.

Imprest advance holder can spend upto Rs.2000/- on purchase of single item,
for which they cannot afford to wait for financial sanction from the competent
authorities from imprest advance.
51

<!-- page 60 -->

3.5. Purchase of goods-Procedures:
A) Purchase of goods upto Rs.2000:
Purchase of goods upto Rs.2000 on each occasion may be made without inviting
quotations/bids and without obtaining prior sanction, on the basis of a certificate to
be recorded by the HODs/Section Heads/Project Holders/Course Coordinators etc.
in the following format:“I am personally satisfied that the goods purchased are of the requisite quality and
specifications and have been purchased from a reliable supplier at a reasonable
price”. This may be met from the Imprest account.
B) Purchase of goods above Rs.2000 and up to Rs.15000:
i) (Rule 145 of GFR) Purchase of goods without quotation : Purchase of goods upto
the value of Rs. 15,000/- (Rupees Fifteen Thousand) only on each occasion may
be made without inviting quotations or bids on the basis of a certificate to be
recorded by the competent authority in the following format.
“I, ___________________, am personally satisfied that these goods purchased
are of the requisite quality and specification and have been purchased from a
reliable supplier at a reasonable price.”
ii) Prior sanction is to be obtained before purchase of goods.
iii) Present stock position of items proposed may be mentioned with justification for
additional purchase if any. Justification for new items is to be given in the
proposal.
C) Purchase of goods above Rs.15000 and up to Rs.100000:
i)

Rule 146 of GFR. Purchase of goods by Purchase Committee : Purchase of
goods costing above Rs.15000 (Rupees Fifteen Thousand) only and upto
Rs.100000 (Rupees One lakh) only on each occasion may be made on the
recommendations of a duly constituted Local Purchase Committee consisting of
the following members.
1. Registrar, 2. Finance Officer, 3. Dy.Registrar / Asst.Registrar of
Dev.Section, 4. Dean of concerned Faculty, 5. The Proposer of the goods to be
purchased (Invitee).

ii) The committee will survey the market to ascertain the reasonableness of rate,
quality and specifications and identify the appropriate supplier.
52

<!-- page 61 -->

iii) Before recommending placement of the purchase order, the members of the
committee will jointly record a certificate as under.
“Certified that we _____________________, members of the purchase committee
are jointly and individually satisfied that the goods recommended for purchase are
of the requisite specification and quality, priced at the prevailing market rate and
the supplier recommended is reliable and competent to supply the goods in
question. “
D) Purchase of goods above Rs.1,00,000:
i) Rule 148 of GFR. A demand for goods should not be divided into small quantities
to make piece meal purchases to avoid the necessity of obtaining the sanction of
higher authority required with reference to the estimated value of the total
demand.
ii) Rule 149 of GFR. Purchase of goods by obtaining bids: Except in cases covered
under Rule 145, 146 and 147(1), Ministries or Departments shall procure goods
under the powers referred to in Rule 140 above by following the standard method
of obtaining bids in :
(a) Limited Tender Enquiry;
(b) Advertised Tender (Open Tender) Enquiry;
(c) Single Tender Enquiry.
(a)

Limited Tender (Above 1.00 lakh upto Rs.25.00 lakh):
Limited Tender Enquiry (Rule 151 of GFR)

(i)

This method may be adopted when estimated value of the goods to be
procured is up to Rupees Twenty five Lakh. Copies of the bidding document
should be sent directly by speed post/registered post/courier/ e-mail to firms
which are borne on the list of registered suppliers for the goods in question as
referred under Rule 142 above. The number of supplier firms in Limited
Tender Enquiry should be more than three. Further, web based publicity
should be given for limited tenders. Efforts should be made to identify a
higher number of approved suppliers to obtain more responsive bids on
competitive basis.

(ii) Purchase through Limited Tender Enquiry may be adopted even where the
estimated value of the procurement is more than Rupees twenty-five Lakh, in
the following circumstances:
53

<!-- page 62 -->

(a) The Institute certifies that the demand is urgent and any additional
expenditure involved by not procuring through advertised tender enquiry
is justified in view of urgency. The Ministry or Department should also put
on record the nature of the urgency and reasons why the procurement
could not be anticipated.
(b) There are sufficient reasons, to be recorded in writing by the competent
authority, indicating that it will not be in public interest to procure the
goods through advertised tender enquiry.
(c) The sources of supply are definitely known and possibility of fresh
source(s) beyond those being tapped, is remote.
(iii)

Sufficient time should be allowed for submission of bids in Limited Tender
Enquiry cases.

(b)
(i)

Advertised Tender (Open Tender) - (Above Rs. 25.00 lakh):
Subject to exceptions incorporated under Rules 151 and 154 of GFR,
invitation to tenders by advertisement should be used for procurement of
goods of estimated value Rs. 25 lakh (Rupees Twenty Five Lakh) and above.
Advertisement in such case should be given in the Indian Trade Journal
(ITJ), published by the Director General of Commercial Intelligence and
Statistics, Kolkata and at least in one national daily having wide circulation.

(ii)

The Institute should also publish all its advertised tender enquiries on the
web site and provide a link with NIC web site. It should also give its web site
address in the advertisements in ITJ and newspapers.

(iii)

The Institute should also post the complete bidding document in its web site
and permit prospective bidders to make use of the document downloaded
from the web site. If such a downloaded bidding document is priced, there
should be clear instructions for the bidder to pay the amount by demand
draft etc. along with the bid.

(iv) Where the Institute feels that the goods of the required quality, specifications
etc., may not be available in the country and it is necessary to also look for
suitable competitive offers from abroad, the Ministry or Department may
send copies of the tender notice to the Indian embassies abroad as well as
to the foreign embassies in India. The selection of the embassies will
depend on the possibility of availability of the required goods in such
countries.
54

<!-- page 63 -->

(v)

Ordinarily, the minimum time to be allowed for submission of bids should be
three weeks from the date of publication of the tender notice or availability
of the bidding document for sale, whichever is later. Where the department
also contemplates obtaining bids from abroad, the minimum period should
be kept as four weeks for both domestic and foreign bidders.
Two bid system (Rule 152 of GFR) : For purchasing high value plant,
machinery etc. of a complex and technical nature, bids may be obtained in
two parts as under :(a) Technical bid consisting of all technical details along with commercial
terms and conditions; and
(b) Financial bid indicating item-wise price for the items mentioned in the
technical bid.
The technical bid and the financial bid should be sealed by the bidder in
separate covers duly superscribed and both these sealed covers are to be
put in a bigger cover which should also be sealed and duly superscribed.
The technical bids are to be opened by the purchasing Ministry or
Department at the first instance and evaluated by a competent committee or
authority. At the second stage financial bids of only the technically
acceptable offers should be opened for further evaluation and ranking
before awarding the contract.
Late Bids (Rule 153 of GFR) : In the case of advertised tender enquiry or
limited tender enquiry, late bids (i.e. bids received after the specified date
and time for receipt of bids) should not be considered.

(c)

Single Tender Enquiry:
Rule 154 of GFR. Procurement from a single source may be resorted to in
the following circumstances:
(i) It is in the knowledge of the user department that only a particular firm
is the manufacturer of the required goods.
(ii) In a case of emergency, the required goods are necessarily to be
purchased from a particular source and the reason for such decision is
to be recorded and approval of competent authority obtained.
(iii) For standardization of machinery or spare parts to be compatible to the
existing sets of equipment (on the advice of a competent technical
55

<!-- page 64 -->

expert and approved by the competent authority), the required item is
to be purchased only from a selected firm.
Note : Proprietary Article Certificate in the following form is to be provided

by the Ministry/Department before procuring the goods from a single source
under the provision of sub Rule 154 (i) and 154 (iii) as applicable.
„(i) The indented goods are manufactured by M/s……..………………..
(ii) No other make or model is acceptable for the following reasons :
……………………….
……………………….
……………………….
(iii) Concurrence of finance wing to the proposal vide : ………………..
(iv) Approval of the competent authority vide :………………………
________________________
________________________
(Signature with date and designation
of the procuring officer)‟
3.6. Tender Committee :
A Tender Committee shall be constituted by the Vice-Chancellor for the purchase of
goods above Rs.1,00,000 (both for limited tender and open tender). The committee
shall consist of the following members.
i)

Dean of the Faculty

ii)

HOD / Project holder / Course Coordinator

iii)

HOD from other department nominated by the Vice-Chancellor

iv)

Technical Expert, if necessary

v)

Finance Officer or Assistant Registrar from Finance Section

The Dean / HOD / Project holder / Course Coordinator shall be the member and
convener of the Committee.
In the case of purchase of sophisticated item of equipments, one technical expert
from outside the GRI will be included in the Committee with prior approval of the
Vice-Chancellor. For all the purchase proposals, 50% of the members including a
member from other department will form the quorum of the Committee.

56

<!-- page 65 -->

3.7. Buy-Back Offer (Rule 162 of GFR):
When it is decided with the approval of the competent authority to replace
an existing old item(s) with a new and better version, the department may trade
the existing old item while purchasing the new one. For this purpose, a suitable
clause is to be incorporated in the bidding document so that the prospective and
interested bidders quote their bids accordingly. Depending on the value and
condition of the old item to be traded, the time as well as the mode of handing
over the old item to the successful bidder should be decided and relevant details in
this regard suitably incorporated in the bidding document.
3.8. Registration of Suppliers (Rule 142 of GFR):
i)

The Vice-chancellor on the recommendation of the Finance Officer and the
Registrar may approve registration of suppliers of goods, which are specifically
required by the Institute, especially for supply of goods like laboratory wares,
equipments, chemicals, stationeries, furniture and other items. This registration
of suppliers may be undertaken and such registered suppliers are prima facile
eligible for consideration for procurement process may be taken up once in two
years; after wide publicity in national news papers is given by the Development
Section of the Institute. The Deans, HODs & PIs may also recommend suppliers
of goods which are specifically required by the department or office for
incorporating in the registered list of suppliers.

ii) Credentials, manufacturing capability, quality control systems, past performance,
after sales service, financial background etc. of the supplier(s) should be
carefully verified before registration.
iii) The supplier(s) will be registered for a fixed period (between 1 to 3 years)
depending upon the nature of the goods. At the end of this period, the
registered supplier(s) willing to continue with registration are to apply afresh for
renewal of registration. New supplier(s) may also be considered for registration
at any time, provided they fulfill all the required conditions.
iv) The registered supplier(s) are liable to be removed from the list of approved
suppliers, if they fail to abide by the terms and conditions of the registration or
fail to supply the goods on time or supply substandard goods or make any false
57

<!-- page 66 -->

declaration to the Institute or in the opinion of the Institute his continuance as
registered supplier is not in public interest, without any advance notice.
3.9. Repeat Order:
a) Repeat order may be placed within 6 months from the date of original purchase
order.
b) The indenter has to certify that there was no downward trend in the price during
the intervening period.
c) In case quantity of the item proposed to be purchased now, exceeds the quantity
purchased in the earlier / original purchase order, then (i) either fresh quotation
has to be called for, (ii) or the rate per piece quoted in the original / earlier
purchase order is required to be negotiated. This strategy is required to be adopted
as rate per piece may decrease due to increase in the quantity.
3.10. Purchase by Imports:
Items not available indigenously or if the indigenous materials are not
technically suitable, purchase may be made by Imports from foreign sources. Such
requirements shall be notified in the Indian Trade Journal and given wide publicity.
DGS&D may be consulted regarding the availability of such items indigenously.
i) Letter of Credit is opened only after receiving the acknowledgement of Purchase
order from the Manufacturer / Supplier. As the foreign exchange rate is subject to
the fluctuation in accordance with condition prevailed in international market, due
care should be taken to open LC, as quickly as possible from the date of opening of
the tender. Otherwise the Institute will be forced to bear additional unnecessary
cost due to upward fluctuation in Forex rates.
ii) The supplier shall be responsible for obtaining the necessary Export Licence /
Permit / Authorization from the respective government for exporting the Materials /
Materials / Equipment to India, and all expenses incidental to the execution of
statutory and non-statutory obligations in this regard shall be to supplier‟s account.
iii) In case of LCs, bank charges outside India including confirmation charges, if any,
shall be to the supplier‟s account. The documents for payment shall be presented
to the purchasers‟ bank by the supplier within 21 days of shipment of Materials /
Equipment.
iv) The Letters of Credit opened for purchase of imported goods should be entered in
a separate register by the Department. The payments made against the Letter of
58

<!-- page 67 -->

Credit should be noted in the register as and when the intimations are received
from the Bank.
v) Steps should be taken to ensure that the imported items are cleared through
customs immediately.

The Finance Section must process the bills regarding

customs duty, freight charges and insurance within 2 working days, to avoid
demurrage charges. Vice-Chancellor‟s sanction should be obtained for payment of
demurrage / wharfage charges if any.
vi) Pre-installation including site preparation requirements may be obtained from the
manufactures in advance, and steps should be initiated accordingly for site
preparation, well before installation of the equipment.
vii) Suitable mechanism should be evolved to detect damages if any, in the imported
equipments at the time of inspection and to prefer claims with Insurance
Companies, suppliers etc. well in time.
viii)

The Registrar‟s Office shall place orders and arrange to open LC immediately

by obtaining the necessary sanctions.

The Deputy / Assistant Registrar

(Development) shall work in close co-ordination with the Finance Officer and shall
keep the Finance Section posted at every stage till the instrument is received by
the Department.
ix) The Deputy / Assistant Registrar (Development) shall mark copies of all
correspondences related to the purchase to the concerned HOD / Dean.
x) On arrival of the cargo, the Deputy / Assistant Registrar ( Development ) shall
arrange for release of equipment through cargo clearing agents.

However the

concerned HOD or his representative or project investigator shall also involve
himself with clearance, in order to expedite the process.
3.11. Procedure for purchase of Major Scientific Equipments costing more than
Rs.25.00 Lakh:
1. Every Department, Centre, Project Investigator should take diligent care in
purchase of scientific equipments particularly high value items costing more
than Rs.25.00 Lakh, to ensure a transparent, competitive and fair approach, to
secure best value for money spent in this regard. After purchase of such costly
equipments, the concerned Deans / HODs/ PIs should take responsibility for
optimum utilization of such equipments and which should not be left unused or
under repair for a long time. Under utilization and non-utilization of such costly
59

<!-- page 68 -->

equipment, owing to the negligence of the concerned in-charge will be viewed
seriously.
2. The detailed procedure to be followed for purchase of such costly equipments is
as follows:i)

The user Department should work out and finalize the technical details and
specification of the equipment to be purchased in consultation with
prospective user of Department. If needed, the opinion of the external expert
may also be obtained. The proposal should include the following:
a) The justification for procurement should include the list of end user and
their requests;
b) Identification of the site of installation in co-ordination, if needed with
Engineering Section;
c) Identification of proper technical / scientific personnel and a faculty, who
would be in charge & responsible for the installation, performance and
maintenance of the scientific equipment and who would be willing to
render services to all user within and outside the department.

ii)

The Proposal for purchase should be submitted to the Registrar along with
the following details:a) End Users and justifications;
b) Source of funds;
c) Acceptance from the identified faculty member who will be taking charge
of the instrument and provide services;
d) A detailed technical specification (provisional) of the instrument for
incorporation in the tender document, if the proposal is accepted;
e) Approximate or probable cost of the equipment.

iii)

After the receipt of the proposal, the Institute administration shall put up the
same for consideration within a period of one week (seven working days)
from the date of receipt of the proposal. If there are any shortcomings in
the proposal, the same shall be called for from the department within 3
working days of the receipt of the proposal.

iv)

If the proposal is approved, the Development Section shall prepare the
tender document with the provisional technical details, and float the same.

60

<!-- page 69 -->

v)

The Institute will notify the tenders in at least one national English Daily and
one Tamil Daily news paper. Tenders shall be in two parts, Technical and
Financial.

vi)

The technical tenders shall be opened in the Institute Offices in the presence
of Purchase Committee members, for further study.

vii)

Technical Evaluation of Bids:
a. The Technical Committee should first prepare the detailed “Technical
Comparative Statement” which should also include clear comments on the
advantages and disadvantages in each of the makes.

The technical

comparative statement should be an exhaustive document for technically
selecting one or more bidders for further consideration by the fully
constituted “Technical Evaluation Committee” with external experts.
b. The Technical Evaluation Committee will consist of HODs of all user
departments, person proposed to be in-charge of equipment and external
experts to be nominated with the approval of the Vice Chancellor. The
T.A. and D.A to the external experts shall be paid by Institute.
c. The Technical Evaluation Committee will examine the technical bids and
shortlist the technically qualifying bids, then prepare a list of final
requirement consisting of main equipment, spares and other conditions
carefully deleting unwanted items given by bidders and also including
those omitted by them. (This list will be used while negotiating). The
first elimination of the technical bids shall be based on the major /
essential specifications which do not meet the basic requirement. The
Technical Evaluation Committee can decide to overlook a few very minor
deviations which, it feels, are not of significance and will not affect the full
use of the instrument. This should be recorded in writing.
d. The Technical Evaluation Committee, if finds necessary, may call for a
presentation by qualified bidders, before preparing a final list of
requirements.
e. During the purchase of highly sophisticated Scientific equipments used for
advance research and teaching in Universities, it has been the experience
that international manufactures come out with improvements in
technology and innovative facilities, almost every year, and such changes
and innovative facilities are normally not known at the time of floating
61

<!-- page 70 -->

tenders; and hence a general specification tenders are floated. It has
also been the experience that only after studying the latest technical
tender and listening to the presentations of manufactures, the researcher
realizes to narrow down his requirements, which obviously would change
the costing.
If the finally prepared list of specification by the Technical Evaluation
Committee, after studying the technical bids, is in deviation from the
quoted lists of the qualified bidders which may contain unwanted items of
least priority, and is likely to affect the cost, then the committee may
decide to invite a revised proforma invoice based on the final specification
requirement lists prepared by the Technical Evaluation Committee. The
option shall be extended to all qualified bidders to bring them on same
platform of technical requirement and allow them to make their revised
offer again in sealed covers, within a stipulated date.
3.12. Bid Security (Earnest Money Deposit) (Rule 157 of GFR):
(i)

To safeguard against a bidder‟s withdrawing or altering its bid during the bid
validity period in the case of advertised or limited tender enquiry, Bid
Security (also known as Earnest Money) is to be obtained from the bidders
except those National Small Industries Corporation (NSIC) or the concerned
Ministry or Department. The bidders should be asked to furnish bid security
along with their bids. Amount of bid security should be two percent of the
estimated value of the goods to be procured. The bid security may be
accepted in the form of Account Payee Demand Draft, Fixed Deposit
Receipt, Banker‟s Cheque or Bank Guarantee from any of the commercial
banks in an acceptable form, safeguarding the purchaser‟s interest in all
respects. The bid security is normally to remain valid for a period of fortyfive days beyond the final bid validity period.

(ii)

Bid securities of the unsuccessful bidders should be returned to them at the
earliest after expiry of the final bid validity and latest on or before the 30th
day after the award of the contract.

3.13. Forfeiture of EMD:
EMD of tenderer will be forfeited, if the tenderer withdraws or amends its tender or
impairs or derogates from the tender in any respect within the validity period of
62

<!-- page 71 -->

tender. Further, if the successful tenderer fails to furnish the required performance
security within the specified period, the EMD will be forfeited.
3.14. Performance Security:
(i)

To ensure due performance of the contract, Performance Security is to be
obtained from the successful bidder awarded the contract. Performance
Security is to be obtained from every successful bidder irrespective of its
registration status etc. Performance Security should be for an amount of five
to ten per cent. of the value of the contract. Performance Security may be
furnished in the form of an Account payee Demand Draft, Fixed Deposit
Receipt from a Commercial bank, Bank Guarantee from a Commercial bank in
an acceptable form safeguarding the purchasers interest in all respects.

(ii) Performance Security should remain valid for a period of sixty days beyond the
date of completion of all contractual obligations of the supplier including
warranty obligations.
(iii) Bid security should be refunded to the successful bidder on receipt of
Performance Security.
3.15. Forfeiture of Performance Security:
Performance Security is to be forfeited in the event of a breach of contract by the
supplier, in terms of the relevant contract.
3.16. Refund of Performance Security:
Performance Security shall be refunded to the supplier without any interest,
whatsoever, after he duly performs and completes the contract in all respects but
not earlier than 60 days of completion of all such obligations under the contract.
3.17. Opening of Quotations:
1. The date and time (if necessary) of receipt of quotations shall be noted on
the envelope of the quotations received either by the purchasers (HOD/PI)
or any other responsible person. If the tender is received in person, it
should be put only in the tender box kept in the custody of the Registrar or
his representative (convenor of the committee).
2. After the last date and time prescribed, the sealed quotations received
shall be opened in the presence of the purchase committee members and
the bidders available at the time of opening of quotations notified in the
quotation call letter.
63

<!-- page 72 -->

3. The authorised person shall affix his/her signature with date on the
envelope of the quotations received and also in the quotations.
3.18. Tender Evaluation:
1. The Tender Committee will survey the market if necessary to ascertain the
reasonableness of rate, quality and specifications.
2. The Tender Committee will scrutinise the quotations received and invalid
quotations will be rejected. Quotations received late, quotations not in
conformity with tender specifications; unsigned quotations and quotations of
doubtful nature will be rejected. All valid quotations will be tabulated and a
comparative statement will be prepared.
3. The comparative statement containing the details of the items required with
specifications, rate quoted by the bidders for each item, tax payable,
packing and forwarding charges, requirement of advance, terms of payment
etc. shall be prepared and signed by the members of the committee with
date. No advance should normally be paid to the supplier. In exceptional
cases, advance can be made on the basis of Bank Guarantee to be furnished
by the supplier. Suitable financial loading has to be done in case of variation
in payment terms, credit period etc.
4. On tabulating the quotations received, the committee members shall
recommend the company / firm / person which / who quotes the lowest
rate. Contract should ordinarily be awarded to the lowest evaluated bidder
whose bid has been found to be responsive and who is eligible and capable
of performing the contract satisfactorily as per the terms and conditions
incorporated in the bidding document. However, where the lowest
acceptable bidder is not in a position to supply the full quantity required, the
remaining quantity, as far as possible, be ordered from the next higher
responsive bidder at the rates offered by the lowest responsive bidder.
3.19. Negotiation with bidders:
Negotiation with bidders after bid opening must be discouraged. However, in
exceptional circumstances where price negotiation against ad-hoc procurement is
necessary due to reasons to be recorded in writing, the same may be resorted to
only with the lowest evaluated responsive bidder. Guidelines issued by the Central
Vigilance Commission from time to time shall be followed in letter and spirit. The
64

<!-- page 73 -->

Tender Committee shall open the financial bids of all technically qualified bidders.
Negotiations can be only with the lowest tender. The offers obtained in sealed
covers shall be opened by the committee in the presence of bidders and the lowest
shall be accepted.

The negotiating committee shall further negotiate with

successful bidder on issues such as
a. Option of special pricing for educational institutions;
b. Negotiate for inclusion of certain special features in proposed
equipment, without additional cost.
c. Period of warranty.
d. After sale, service on completion of warranty period;
e. Essential spares and consumables for a minimum period of five years;
f. Technical training for the users (including onsite, factory, and
offshore); and
g. Periodical visits by the Service Engineer / Technician, from the
prospective supplier during the period of warranty as well as
thereafter, as and when required.
h. Performance Guarantee for an appropriate percentage of purchase
value.
i. Payment terms which may include retention of certain percentage till
the equipment is installed and performance Guarantee is received.
This step is felt necessary to finally purchase the right kind of equipment with most
economic pricing.
3.20. Purchase of goods under DGS&D rate contract
1. Ascertain from the DGS&D website www.dgsnd.gov.in whether the intended goods
are under DGS&D rate contract.
2. If multiples of particular product is available, choose the appropriate brand by
keeping the cost, brand, specification and past performances of the product in
mind.
3. Contact local dealer and place firm supply order. Specify the conditions that 90% of
payment will be released on receipt of good and balance 10% will be paid on
satisfactory performance of the product.
4. Arrange for inspection on specification / performance of the goods purchased
under DGS&D rate contract.
5. Ensure the payment as per the agreed terms and conditions.
65

<!-- page 74 -->

3.21. Relaxation of the Rules and Procedures of GRI
The Vice-Chancellor on the recommendations of Departmental Purchase Committee or any
other Committee may, for reason to be recorded in writing, grant relaxation on these rules
and procedures in specific cases, in the interest of the Institute to save time, money and
in the cases of urgency and justified exigency
3.22. Black listing
Black-listing of firm can be done on the recommendations of the HOD/PI and with the
approval of Competent Authority. The Officer–In-charge of Development Section shall
process all such cases reported by the Department/Centers. A committee specially
constituted by the Vice-Chancellor shall examine the case and shall submit its
recommendations to the competent authority for final action. The information on such
firms shall be promptly and widely disseminated by Officer–In-charge of Development
Section to all concerned.

66

<!-- page 75 -->

3.23. Format for Inviting Quotations:
Specimen:
Appendix-I
THE GANDHIGRAM RURAL INSTITUTE (DEEMED UNIVERSITY)
(Fully Controlled by MHRD, Govt. of India)
Gandhigram – 624 302
Dindigul District
Head
Tamil Nadu
_________________________________________________________________________
Ref:

Date:

Sir / Madam
On behalf of the Gandhigram Rural Institute, Gandhigram, sealed bids / quotations
/ tenders are invited from the Registered / reputed suppliers. Quotations will be
received upto 3.00 PM on ………………… and the same will be opened at 4.00 PM on
the same day in the presence of the available bidders / tenderers / their representative
of the firms.
Sl.No.

Name of items with
specifications

No. of Qty. required

Configuration of the items to be sold under Buy-back scheme
Sl.No.

Name of items with
specifications

No. of Qty.
available

Terms and conditions
 The rate should clearly indicate the unit / numbers
 The rate should include duties and taxes and also packing and forwarding charges.
 The period upto which the materials / equipments are guaranteed / warranty period
should be indicated separately.
 The nearest service point should also be indicated in the offer.
 The offer should be as far as possible from ready stock.
 Where the offer is not from ready stock, the period before which supply will be
effected should be indicated.
 The mode of payment should be specified.
67

<!-- page 76 -->

 TIN / PAN may be indicated. The price quoted should be in Net. (including freight
charges if any).
 Payment will be made within fifteen days from the date of the receipt of materials and
duly certified by the officers concerned / within a week of the satisfactory completion
of the work.
 Validity of offer should be normally for 60 days from the date of the offer. If
otherwise, the period should be specifically mentioned in the offer.
 Quotations should be addressed to :
The Registrar,
Gandhigram Rural Institute (Deemed University),
Gandhigram – 624 302
Dindigul District – TN
 Sealed envelope should be addressed & sent to :
The Head / Dean
Dept. of _____________/ Faculty of _________
Gandhigram Rural Institute- Deemed University
Gandhigram – 624 302
Dindigul District - TN
 Sealed envelope should be superscripted as “Quotation for purchase of
__________________________ Last date : ____________
 The above terms and conditions also be visited in our website : www.ruraluniv.ac.in.

SIGNATURE OF THE REGISTRAR
To

68

<!-- page 77 -->

Specimen
The Gandhigram Rural Institute – Deemed University, Gandhigram

Appendix – II

Format –A
Part A :

Purchase Proposal under Tender System
Date:

1.

Name of the Faculty / Dept. / :
Section / Project

2.

Name & Description of the :
item(s) to be purchased

3.

Amount of the Proposal

: Rs.
(Rupees
______________________________________
_______________________________________
Only)

4(a). Present similar stock position :
with status / condition

Yes / No (If „Yes‟ Annexure-B to be annexed)

4(b). Whether the item proposed to
be purchased under buy back
scheme
5.

Budget
Head
in
which : Non-Plan/Plan/Projects/CDF/Others
(Specify) _______
expenditure to be met from
Sub Head

6.

:

Pl. tick the method followed : Single Tender / Limited Tender / Open
for
inviting
Tender
bit/quotation/tender
(In the case of limited tender
more than 3 quotations are
required)

7.

Name of the supplier as :
recommended
by
the
Purchase
Committee
(Purchase Committee is must
for the value of purchase
69

<!-- page 78 -->

exceeding Rs.10000)
7(a)

Justification for single tender :
with estimate

7(b). Whether
Comparative : Yes / No
Statement
Annexure-A
enclosed is duly scrutinized by
the Purchase Committee
8.

Amount of advance if required
(As per GFR payment
advance to suppliers
discouraged)

:

of
is

8(a). To whom advance is to be :
paid
9.

Details of previous pending :
advance(s)

9(a). If pending advance(s) remains :
unsettled, Pl. give reason
9(b). Justification for requesting :
fresh advance even though
earlier advance(s) remains
pending settlement

Signature of the Proposer with seal

70

<!-- page 79 -->

Part B : Remarks on the Proposal by Development Section

1.

Whether purchase procedure has : Yes
been fully followed for the
amount proposed

2.

If No, specify the lapses noticed :
in a separate sheet to enable the
proposer to set right the lapses

3.

Whether the above lapses noticed : Yes
were duly set right

No

.

No

.

Recommendation of the proposal processing section

Dealing Asst.

Section Officer

Part C :

Asst. Registrar / Dy Registrar

Budget provision by the Finance Section I / II
Proposal No.

:

Account No.

:

Major Budget Head

:

Sub Budget Head

:

Budget Allotment

:

Provision so far made

:

Balance available

:

Less : Current Proposal

:

Net balance available

:

Remarks of the Finance Section if any

Dealing Asst.
Part D :

FINANCE OFFICER

Section Officer

Asst. Registrar (Fin)

Approval of the Authorities

REGISTRAR

71

VICE-CHANCELLOR

<!-- page 80 -->

CHECK LIST
Whether the Purchase Committee verified the following:
1. All sealed quotations/bids/tenders were received within the date and time
mentioned in the call letter :
Yes / No
(Late receipt of quotations shall be rejected)
2. 2. The Specification of the items furnished in the quotation are exactly the
same as in the call letter :
Yes / No
3. Proof for having dispatched the quotation call letters by Speed Post / Regd.
Post/Couriers and web publicity (in case of Limited Tender / Open Tender) is
verified
Yes / No
4. Whether TIN/PAN has been mentioned by the suppliers in the quotation
5. A. No. of quotations invited :
B. No. of quotations received :
C. No. of quotations rejected :
6. Whether the quotations were opened in the presence of the quotationers/
bidders/Tenderers or their representatives

Yes / No

7. Whether the sealed envelopes and the quotations were duly signed by the
members of the Tender Committee or its authorised officer with date.
Yes / No

72
