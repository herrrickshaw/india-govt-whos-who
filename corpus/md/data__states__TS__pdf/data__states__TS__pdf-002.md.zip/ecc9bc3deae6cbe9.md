---
doc_id: "ecc9bc3deae6cbe9"
source_url: "https://tgic.telangana.gov.in/Downloads/Instructions/45_38912_15112012.pdf"
ministry: "Information Commission, Telangana"
title: "38912_15112012.pdf"
date: ""
pages: 1
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "a1ad4fc07ccf6186"
---

<!-- page 1 -->

Yo ae
GOVERNMENT OF ANDHRA PRADESH
GENERAL ADMINISTRATION (GPM&AR) DE! మాకా
Circular U.O.Note. No. 38912/RTIA / GPM&AR/2012, Stas 11.2012
SNYDER Abe
: Sub:- Right to Information (RTI) Act, 2005 — Provisions of Special prestter—
meeting the expenditure on providing information to RTI Applicants — |
: Instructions - Issued.
It has come to the notice of the Government that the Public Information
Officers (PIOs) are facing certain difficulty for meeting the expenditure on
Photocopying, stationery, etc., while providing information to the applicants
NZ under the RTI Act, 2005,as no specific budget provision has been provided
న్‌ for this purpose and.the money being collected from the applicants is being
క remitted to the State exchequer.
2. The High Level Committee (HLC) established for monitoring the
implementation of RT! Act on 28.07.2012 discussed this issue and the
Committee has decided to provide the Public Information Officers (PIOs) with
the resources required for meeting the expenditure incidental to providing
information under the RTI Act.
3. in this background, all the Departments of Secretariat / HODs / District
॥ . Collectors are informed that the expenditure essential for providing
information to the applicant under RTI Act like stationery, photocopying, etc.,
may be met from the detailed HOA * 200 - other administrative expenses”
under respective sub-heads of the Head Quarters / District offices and
administrative Departments of Secretariat. Accordingly all concerned are
fequested to make necessary provision in the Revised Estimates of
2012-2013 FY and the Budget Estimates of 2013 - 2014 FY while submitting
proposals to the Finance Department for making provisions in their respective
న budgets at appropriate time.
4. These instructions are issued with the concurrence of Finance
Department vide their U.O.No.29145 / 684 / Expr.GAD.1 / 12, dt.07.11.2012.
MINNIE MATHEW
| _ CHIEF SECRETARY TO GOVERNMENT
క్‌ నేమో.
To
All the Spl.C.S’s / Prl.Secys / Secys to Government.
All the Departments of Secretariat.
All the Heads of Departments.
All the District Collectors.
Copy to: ఆమి.
+ The Secretary,
" A.P.|Inférmation Commission,
‘ HACA Bhavan, Hyderabad.
The Finance (Expr.GAD.|)Department.
The P.S to Chief Secretary to Government.
The P.S to Principal Secretary to Government,
G.A(GPM&AR)Department.
" SF/SC. _
/FORWARDED::BY ORDER//
ASSISTANT SECRETARY TO GOVT.
_
oa |
