---
doc_id: "bc847e27d1ba1ccc"
source_url: "https://horticulture.tg.nic.in/Downloads/2026/Transfer/Senior%20Assistant%20Incumbency%20list.pdf"
ministry: "Horticulture Department, Telangana"
title: "Senior Assistant"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "83e2745520780955"
---

<!-- page 1 -->

GOVERNMENTOF TELANGANA
DEPARTMENT OF HORTICULTURE
GENERAL TRANSFERS-2026- SENIOR ASSISTANT (ZONAL CADRE)
ANNEXURE-I Zone Wise Incumbent List as on Date: b -05-2026
Place of
Sl.

No.

Zone

Employee ID

Employee Name

Gender

Date of Birth

Native Dist.

Retirement

Mobile
Number

Date of

Post of District

posting/working
as on
01-01-2026

Post

Regular/Deputati
on/Other Duty

Date of
working in
present

Length of service in
Present Station as

Transfer

station

on 01-01-2026
14

15

1

2

3

4

5

6

7

8

9

10

11

12

13

1

Zone-II

1549394

Gulam Feroz Khan

Male

26-03-1986

Karimnagar

31-03-2047

9346502517

Nizamabad

Jagityal

Other Duty

31-01-2025

O

years II months

Not Compulsory

2

Zone-III

2100973

T. Ravi Kumar

01-06 _1972

Warangal

30-06-2033

8978422611

Rajanna Siricilla

Rajanna Siricilla

Regular

11-01-2022

3 years 11 months

Eligible

3

Zone-IV

1643718

K. Jyothsna Rani

Female

28-02 _1991

28-02-2052

99632533993

Mahabubabad

Mahabubabad

Regular

17-07-2017

8

years 5 months

Compulsory

4

Zone-IV

1629055

P.Yekambaram

Male

10-08-1974

31-08-2035

8500500536

Khammam

Other Duty

01-10-2022

3

years 3 months

Eligible

Bhadradri

Kothagudem

Hyderabad on
Warangal

Other Duty
(at

Hon'ble MLC)

6

Zone-V

2599424

K. Pavan Kumar

Male

08-11-1992

Hyderabad

30-11-2053

9000094047

Yadadri

Yadadri

Regular

01-08-2025

0

years 6 months

Not Compulsory

5

Zone-V

2042640

K. Rakesh Reddy

Male

25-03-1985

Nalgonda

31-03-2046

9246924692

Nalgonda

Nalgonda

Regular

03-06-2022

3 years 6 months

Eligible

9

Zone-VI

1953586

Hafeeza Nishath

Female

01-12-1985

Nalgonda

31-12-2046

9966537949

Vikarabad

Head Office

Other Duty

01-11-2025

O

years 2 months

Not Compulsory

7

Zone-VI

1701135

Ch.Sattaiah

Male

12-06-1970

Mahabubnagar

30-06-2031

9491527917

Hyderabad

Wanaparthy

Other Duty

04-02-2025

0

years II months

Not Compulsory

8

Zone-VI

1842212

P. Nilesh Kumar

Male

03-05-1984

Sangareddy

31-05-2045

8099956665

Sangareddy

Sangareddy

Regular

09-02-2018

7

years IO months

Compulsory

IO

Zone-VI

1961181

Varanasi Pavan

Male

23-10-1979

Nalgonda

31-10-2040

7382116061

Hyderabad

Hyderabad

Regular

24-06-2024

I

years 6 months

Not Compulsory

II

Zone-VII

1701137

A. Rajya Lakshmi

Female

01-04-1971

Mahabubnagar

31-04-2032

9000139442

Mahabubnagar

Mahabubnagar

Regular

24-04-2015

IO years 8 months

Compulsory

Note:

All (3) vears are Eliqible for Transfer and (4) vears and above are liable for Compulsory transfer subiect to Rule 4 & 5 of G.O.Ms.No.38. dt.21-04-202@
pf Fin(HRM-l) Depg

Date: 01-05-2026
Place:O/o.Director of Horticulture, Telangana, Hyderabad.

ec or

f Ho

ure
