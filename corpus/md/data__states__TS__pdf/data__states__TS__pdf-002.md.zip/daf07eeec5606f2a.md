---
doc_id: "daf07eeec5606f2a"
source_url: "https://cdn.s3waas.gov.in/s3a3f390d88e4c41f2747bfa2f1b5f87db/uploads/2024/03/2024030250.pdf"
ministry: "Mahabubabad"
title: "Notification and Guidelines for recruitment of Vacancies under NHM_page-0002 (526 KB)"
date: ""
pages: 3
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "86399a7d20ca7b06"
---

<!-- page 1 -->

Guidelines for recruitment of vacancies
under National Health Mission

1) Recruitment shall be done for number of vacancies in various categories as
per the details enclosed in the District :

2) Applications are hereby invited by 16 _____ 90156101 Selection Committee headed
by the District Collector & District Magistrate from the eligible applicants to
the vacant posts.

3) Age: |

The minimum age is 18 years and the maximum age is 46 years in terms of

G.0O.Ms.No.30 dated 08-02-2024 of General Administration (Services-A) Department,

Government of Telangana. The minimum and maximum age shall be reckoned as on

01.07.2024 with the following relaxations allowed for reckoning the maximum age limit

as per rules in force:

(1) For S.Cs., S.Ts & BCs & EWS Relaxation of (05) years.

(2) For Ex-service men relaxation of (3) years and length of service in armed forces
(applicable only for the posts of Medical Officers)

(3) For NCC (who worked as Instructor in NCC) relaxation of (3) years and length of
service in NCC

(4) For Physically challenged persons relaxation of 10 (ten) years.

4) The suitable qualifications for the vacant posts shall be as per Government guidelines.

5) Method of Recruitment

Recruitment shall be done by the District Selection Committee on behalf of the concerned

District Health Society, for all the vacant positions.

For the posts of MLHPs., the guidelines for recruitment issued by this Office in

Lr.Re.No.96/NUHM/HWC/NHM/2017, dated : 06.09.2022 shall be followed (For age the

guidance issued at “3)Age “ shall be followed).

Other than MLHP positions, the following guidelines shall be followed:

6) Selection will be done on Merit Basis and based on the following criteria

(i) Merit Lists shall be prepared separately for each of the categories of posts.

(ii) Total marks are 100 of which 90 marks will be allotted basing on the marks obtained
in qualifying examination and 10 marks will be awarded for the age. Weight-age for
age will be reckoned from 18 years of age of the candidate. 0.5 mark will be
awarded for one completed year of age with a maximum of 10 marks. The age will
be reckoned as on 01-07-2024. (Example 1. If a candidate completes 20 years as on
01-07-2024, he/she will be awarded 1.0 mark; Example 2. If a candidate completes
30 years of age as on 01-07-2021, he/she will be awarded 6.0 marks; Example 3. If
a candidate completes 40 years of age as on 01-07-2024, he/she will be awarded
10.0 marks).

(iii) Merit list will be prepared based on the marks obtained with above criteria and

॥ displayed on Official website of the concerned District Collector, for transparency
and also for calling objections.

(iv) Selections list will be prepared from the finalized merit list duly following the Rule of
Reservation (RoR) and Presidential Orders.

(v) The Selected candidates shall maintain the Headquarters.

(vi) These positions are not transferable.

Contd....2..

<!-- page 2 -->

327

7) Rule of Reservation

(i) Rule of Reservations in respect of Community, Disability, Ex-Service Men/Women shall
be strictly observed as ordered by the Government of Telangana from time to time.

(ii) 33 1/3% reservation for women will be applicable as per the orders issued by
Government in G.O.Ms.No.3 Dept for Women,Children, Disabled & Sr.Citizens (Prog.!)
dated 10.02.2024 and in GO.Ms.No.35, Genl.Admn.(Ser.D) Dept., dated 13.02.2024

(iii) | The Rule of Reservations to local candidates is applicable as per the Presidential order.

(iv) The districts should continue the existing Roster.

(v) The vacancies for the posts mentioned in G.O.68, falling in Scheduled Areas should be
filled exclusively with the Local Scheduled Tribes,

8) How to Apply

(i) Application forms along with instructions can be downloaded from the official web site of the
respective District.

(ii) Filled in application form shall be submitted in person or through registered post to the
respective District Medical & Health Officers of the District to which the candidate is applying.
Applications which are received after due dates will be summarily rejected. District Selection
Committee is not responsible for post delays.

(iii) Self attested copies of the following Certificates should be enclosed along with the application

form:

1 5.5.0 /Dated of Birth Certificate issued by the Competent Authority of the
Government, for proofofage. a

2 Intermediate or 10 + 2 examination.

Qualifying Examination Pass Certificate.

4 Marks Memos of all the years (qualifying examination)

5 | Registration Certificates of respective Councils =
Latest Community Certificate/EWC Certificate/Ex-Servicemen/
NCC/Physically Handicapped, whichever is applicable, issued by the
Competent Authority.

(౯ Study certificate for the years from 4 class to 10" class and in case of
Private study residence certificate from the Tahsildhar /MRO concerned to be
submitted.

[s | PH certificate in respect of candidates claiming reservation under PH Quota.

క. Relevant certificates in respect of candidates claiming Ex-service Men Quota.

10 Registration Certificate from the concerned Medical Council/ Nursing Council/
Para Medical Board / Other relevant authority.

11 1 Photograph duly pasted on the application form.

Contd..3..
gy SS ee eee ee

<!-- page 3 -->

3 |
9) Notification Schedule for filling up the positions
Issue of Notification by District Collectors i==-, . i
‘
2 Start date of receipt of applications |
3 Last Date of receipt applications Po
5 Display of provisional Merit List & Call for
Objections.
5 Last date of receipt of objections and reply
to candidates.
16 Display of final merit list and selection list Po
10) General Information to the candidates:
1) The District Collector reserves the right to change/modify/cancel the selection process at any
time during the process and the decision of the District Collector will be final and binding
2) The Mode of Appointment is on Outsourcing basis or Contract basis for a period of 1 year or
till the actual need ceases whichever is earlier.
3) No TA/DA will be paid to the candidates for attending the interviews.
4) Appointees will work under the overall administrative control of CH&FW and MD, NHM
5) The termination notice shall be (30) days period from either side.
6) Candidates selected under Outsourcing mode shall be appointed through Outsourcing
Agency.
7) The posts notified are not permanent/regular Government posts and purely temporary.
8) The Panel of Candidates will be utilized for future vacancies, until a period of one Year from
the final date of Selection of Candidates, in this Notification.
9) The selected candidates will be intimated through email/official communication.
10) The selected candidates may have to perform tours.
11) Their performance will be evaluated from time to time and also the same will be considered
for Extension/Termination of their service, in case of future requirements.
12)The employment is subject to disciplinary/codal rules and in case of any deviation,
employment is liable for termination.
District Collector and District Magistrate
District
rrr i
