---
doc_id: "ebcbce8afcacbf01"
source_url: "https://vidyutombudsman-tserc.gov.in/Tariff%20Orders/RTS2016-17.pdf"
ministry: "Vidyut Ombudsman, Telangana"
title: "View"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b5e7fe4ccd0be6d6"
---

<!-- page 1 -->

PRESS NOTE
23.06.2016
Telangana State Electricity Regulatory Commission
Salient Features of Tariff Order for Retail Supply Business of TSSPDCL and TSNPDCL
for FY 2016-17
1) No tariff increase for Domestic consumers consuming upto 100 units/ month (around 60 lakh
consumers).
2) No tariff increase for Agriculture consumers (around 20 lakh consumers) except for
Horticulture Nurseries upto 15 HP.
3) Overall Average increase of 7.5% in tariff.
4) Slabs under the Domestic andNon Domestic categories have been merged with a view to
simplifying the tariff structure.
5) New category for Hair cutting salons under the LT-II Non-Domestic for consumption upto
200 units per month, has been introduced.
6) The load restriction of 2kW for Religious places has been removed and a new slab with
connected load of above 2kW has been introduced under LT-VII (B) for wholly Religious
Places.
7) Under LT-III(v), Sheep and Goat Farms have also been included.
8) IT Assessees have also been included in the free category under LT-V Agriculture and Urban
Horticulture Nurseries have been included along with Rural Horticulture Nurseriesunder LTV Agriculture.
9) Optional category (with contract maximum demand up to 150 kVA) has been introduced under
HT-1 (A) - Industry at 11kV, to benefit small industries.
10) HT-V (B) Hyderabad Metro Rail (HMR) category has been introduced as a sub-category
under HT-V Railway traction.
11) Time of Day tariff has been introduced to aid in flattening of the day load curve while
incentivizing off-peak hour consumption for eligible customers. The new ToD charges
introduced are as follows.

1|P a g e

<!-- page 2 -->

Time of Day

ToD Charge

06:00 AM to 10:00 AM

+1 Rs./ unit

10:00 PM to 6:00 AM

-1 Rs./ unit

12) Government of Telangana has given its commitment to reduce the tariff applicable to poultry
farms by Rs. 2/unit.
13) Government of Telangana has given its commitment to provide Subsidy of Rs. 4584.50
Crores for FY 2016-17 under Section 65 of the Electricity Act, 2003.
14) The new tariffs shall come into effect from 01.07.2016.

2|P a g e

<!-- page 3 -->

Table 1: Retail Supply Tariff Schedule for FY 2016-17

Category
Low Tension
LT I: Domestic
LT I (A): Up to 100 Units/Month
0-50
51-100
LT I (B)(i): Above 100 Units/Month & up to
200 Units/Month
0-100
101-200
LT I (B)(ii): Above 200 Units/Month
0-200
201-300
301-400
401-800
Above 800 units
LT II: Non-Domestic/Commercial
LT II (A): Up to 50 Units/Month
0-50
LT II (B): Above 50 Units/Month
0-100
101-300
301-500
Above 500
LT II (C): Advertisement Hoardings
LT II (D): Haircutting salons consuming up
to 200 units/month
0-50
51-100
101-200
LT III: Industry
Industries
Seasonal Industries (off season)
Pisciculture/ Prawn culture
Sugarcane crushing
Poultry farms
Mushroom, Rabbit, Sheep and Goat farms
Floriculture in Green House
LT IV: Cottage Industries
Cottage Industries

3|P a g e

Fixed/ Demand
Charges
(INR/ month)
Unit
Rate

Energy Charge
(INR/kWh/kVAh)

1.45
2.60

3.30
4.30
5.00
7.20
8.50
9.00
9.50

kW

50

6.00

kW
kW
kW
kW
kW

60
60
60
60
60

7.50
8.90
9.40
10.00
12.00

kW
kW
kW

60
60
60

5.30
6.60
7.50

kW
kW
kW
kW
kW
kW
kW

60
60
21
21
50
60
60

6.70
7.40
5.20
5.20
4.00
6.30
6.30

kW

20/kW subject to a
minimum of

4.00

<!-- page 4 -->

Category

Agro Based Activities
LT V: Agriculture
LT V (A): Agriculture with DSM Measures
Corporate Farmers
Wet Land Farmers (Holdings >2.5 acre)
Dry Land Farmers (Connections > 3 nos.)
Wet Land Farmers (Holdings <= 2.5 acre)
Dry Land Farmers (Connections <= 3 nos.)
LT V (B): Agriculture without DSM
Measures
Corporate Farmers
Wet Land Farmers (Holdings >2.5 acre)
Dry Land Farmers (Connections > 3 nos.)
Wet Land Farmers (Holdings <= 2.5 acre)
Dry Land Farmers (Connections <= 3 nos.)
LT V (C): Others
Horticulture Nurseries with CL up to 15 HP
LT VI: Street Lighting & PWS
LT VI (A): Street Lighting
Panchayats
Municipalities
Municipal Corporations
LT VI (B): PWS Schemes
Panchayats

Municipalities

Municipal Corporations
LT VII: General
LT VII (A): General Purpose
LT VII (B): Wholly Religious Places
Load up to 2 kW
Load above 2 kW
LT VIII: Temporary Supply
High Tension
4|P a g e

Fixed/ Demand
Charges
(INR/ month)
Unit
Rate
Rs.30/month
20/kW subject to a
kW
minimum of
Rs.30/month

HP
HP

525 *
525 *

Energy Charge
(INR/kWh/kVAh)

4.00

2.50
0.50
0.50
0.00
0.00

HP
HP
HP
HP

1050 *
1050 *
525 *
525 *

3.50
1.00
1.00
0.50
0.50

HP

20

4.00

kW
kW
kW

32
32
32

6.10
6.60
7.10

HP

HP

HP

32/ HP subject to a
minimum of Rs
50/month
32/HP subject to a
minimum of Rs
100/month
32/HP subject to a
minimum of Rs
100/month

5.00

6.10

6.60

kW

21

7.30

kW
kW
kW

21
21
21

5.40
6.00
11.00

<!-- page 5 -->

Category
HT I(A): Industry General
11 kV
33 kV
132 kV and above
HT I(A):Lights and Fans
11 kV
33 kV
132 kV and above
HT I(A):Poultry Farms
11 kV
33 kV
HT I(A):Industrial Colonies
11 kV
33 kV
132 kV and above
HT I(A):Seasonal Industries
11 kV
33 kV
132 kV and above
HT I(A):Optional Category with Load up
to 150 kVA
11 kV
HT I: Time of Day Tariffs (6 PM to 10 PM)
11 kV
33 kV
132 kV and above
HT I: Time of Day Tariffs (6 AM to 10 AM)
11 kV
33 kV
132 kV and above
HT I: Time of Day Tariffs (10 PM to 6 AM)
11 kV
33 kV
132 kV and above
HT I(A): Poultry Farms - Time of Day
Tariffs (6 PM to 10 PM)
11 kV
33 kV
HT I(A): Poultry Farms - Time of Day
Tariffs (6 AM to 10 AM)
11 kV
33 kV
5|P a g e

Fixed/ Demand
Charges
(INR/ month)
Unit
Rate
kVA
kVA
kVA

390
390
390

Energy Charge
(INR/kWh/kVAh)

6.65
6.15
5.65
6.65
6.15
5.65

kVA
kVA

390
390

4.65
4.15
6.30
6.30
6.30

kVA
kVA
kVA

390
390
390

7.60
6.90
6.70

kVA

80

7.00
7.65
7.15
6.65
7.65
7.15
6.65
5.65
5.15
4.65

5.65
5.15

5.65
5.15

<!-- page 6 -->

Category
HT I(A): Poultry Farms - Time of Day
Tariffs (10 PM to 06 AM)
11 kV
33 kV
HT I(B):Ferro Alloy Units
11 kV
33 kV
132 kV and above
HT II Others
11 kV
33 kV
132 kV and above
HT II: Time of Day Tariffs (6 PM to 10PM)
11 kV
33 kV
132 kV and above
HT II: Time of Day Tariffs (6 AM to 10
AM)
11 kV
33 kV
132 kV and above
HT II: Time of Day Tariffs (10 PM to 6AM)
11 kV
33 kV
132 kV and above
HT III Airports, Bus stations and Railway
stations
11 kV
33 kV
132 kV and above
HT III: Time of Day Tariffs (6 PM to 10
PM)
11 kV
33 kV
132 kV and above
HT III: Time of Day Tariffs (6 AM to 10
AM)
11 kV
33 kV
132 kV and above
HT III: Time of Day Tariffs (10 PM to 06
6|P a g e

Fixed/ Demand
Charges
(INR/ month)
Unit
Rate

Energy Charge
(INR/kWh/kVAh)

3.65
3.15
5.90
5.50
5.00
kVA
kVA
kVA

390
390
390

7.80
7.00
6.80
8.80
8.00
7.80

8.80
8.00
7.80
6.80
6.00
5.80

kVA
kVA
kVA

390
390
390

7.50
6.85
6.45

8.50
7.85
7.45

8.50
7.85
7.45

<!-- page 7 -->

Category
AM)
11 kV
33 kV
132 kV and above
HT IV (A) Irrigation and Agriculture
11 kV
33 kV
132 kV and above
HT IV (B) CP Water Supply Schemes
11 kV
33 kV
132 kV and above
HT V (A) Railway Traction
HT V (B) HMR
HT VI Townships & Residential Colonies
11 kV
33 kV
132 kV and above
HT VII: Temporary
11 kV
33 kV
132 kV and above
HT VIII: RESCO
11 kV
* Equivalent flat rate tariff - INR/ HP/ year

7|P a g e

Fixed/ Demand
Charges
(INR/ month)
Unit
Rate

Energy Charge
(INR/kWh/kVAh)

6.50
5.85
5.45
6.40
6.40
6.40
5.10
5.10
5.10
7.10
7.00
kVA
kVA
kVA

60
60
60

6.30
6.30
6.30

kVA
kVA
kVA

500
500
500

10.80
10.00
9.80
1.00

<!-- page 8 -->

Terms and conditions
i.

Fuel Surcharge Adjustment (FSA) is applicable in accordance with the provisions of the
Electricity Act, 2003.

ii.

The tariffs are exclusive of Electricity duty payable as per the provisions of AP
Electricity Duty Act as adopted by Government of Telangana.

iii.

Voltage surcharge
The voltage surcharge for FY 2016-17 has been withdrawn.

iv.

Additional charges for maximum demand exceeding the contracted demand
In case, in any month the Recorded Maximum Demand (RMD) of the consumer exceeds
his Contracted Demand with the Licensee, the consumer shall pay the following charges
on excess demand recorded and on the entire energy consumed.
RMD over CMD
100 to 120%
Above 120% and up to
200%
More than 200%

Demand charges on excess
demand
2 times of normal charge
2 times of normal charge
2 times of normal charge

Energy charges on full
energy
Normal
1.15 times of normal
charge
1.20 times of normal
charge

In case of HT-V(A) and V(B): Railway Traction and HMR, the energy charges shall be
computed at 1.05 times of normal charges on the entire consumption, if RMD exceeds
120% of Contracted Demand.
v.

Minimum charges
Category

Rates for the
year 2016-17

LT Categories
LT-I (A)
LT-I (B)(i)
LT-I (B)(ii)
LT-II (A) & II
(B)
LT-II (C)
LT-II (D)
8|P a g e

Contracted load of 1,000 watts and
below
Single phase
INR. 25/ month
Domestic
Contracted load of above 1,000 watts
Single phase
INR. 50/ month
Three phase
INR. 150/ month
Single phase
INR. 65/ month
Three phase
INR. 200/ month
Non-Domestic/
Advertisement
INR. 300/ month
Commercial
Hoardings
Single phase
INR. 65/ month

<!-- page 9 -->

Category
Three phase
Panchayats
LT-VI (A)

Street lighting

LT-VII (A)

General purpose

LT-VIII

Temporary supply

Rates for the
year 2016-17
INR. 200/ month
INR. 2/ point/
month

Municipalities and
INR. 6/ point/
Corporation
month
s
Single phase
INR. 50/ month
Three phase
INR. 150/ month
INR. 125 per kW or part thereof of the
contracted load for first 30 days or part
thereof and for every subsequent period
of 15 days or part thereof a charge of
INR. 75 per kW

HT Categories
Billing demand shall be maximum
demand recorded during the month or
80% of contracted demand whichever
is higher except HT-VI (i.e. Township
and Residential Colonies, for this
category the billing demand is Actual
Demand Recorded)

Billing demand

Minimum energy charges
HT-I (A)

Industry – General

HT-I (B)

Ferro Alloy units

HT-II

Others

HT-III
HT-V(A) & V(B)
HT-VI

9|P a g e

Airports, Bus
stations and
Railway stations
Railway traction &
HMR
Townships and
residential
colonies

50 kVAh/ kVA of billing demand per
month
Maximum Demand or Average Actual
Demand whichever is higher. The
energy falling short of 6,701 kVAh per
kVA per annum will be billed as
deemed consumption
25 kVAh/ kVA of billing demand per
month
50 kVAh/ kVA of billing demand per
month
32 kVAh /kVA of Contracted demand
per month
Billing demand shall be Actual
Recorded demand. 25 units/ kVA of
contracted demand per month

<!-- page 10 -->

vi.

Customer charges
Consumer category
Low Tension
LT-I: Domestic (Units/ month)
0-50
51-100
101-200
201-300
301-400
401-800
Above 800 units
LT-II: Non-Domestic/ Commercial (Units/
month)
0-50
51-100
101-300
301-500
Above 500 units
LT-II (C): Advertisement Hoardings
LT-II (D): Haircutting Salons with
consumption up to 200 units per
month
0-50
51-100
101-200
LT-III: Industry up to 20 HP
LT-III: Industry 21-50 HP
LT-III: Industry 51-100 HP
LT IV: Cottage Industries
LT V: Agriculture
LT VI: Street Lighting & PWS
LT-VII: General purpose
LT-VIII: Temporary supply
High Tension

INR./ month

HT Consumer at 11 kV
HT Consumers at 33 kV
HT Consumers at 132 kV and above

INR. 1,685
INR. 1,685
INR. 3,370

10 | P a g e

INR. 25
INR. 30
INR. 50
INR. 60
INR. 80
INR. 80
INR. 80

INR. 45
INR. 55
INR. 65
INR. 65
INR. 65
INR. 70

INR. 45
INR. 55
INR. 65
INR.75
INR. 300
INR. 1125
INR. 45
INR. 30
INR. 50
INR. 60
INR. 65

<!-- page 11 -->

vii.

Delayed Payment Surcharge (DPS)
LT Category
a)

In case of LT- I (A), LT-I (B), LT-II(A), LT-II(D), LT-IV and LT-V (C), if
payment is made after due date, the consumers are liable to pay, Delayed Payment
Surcharge (DPS) per month on the bill amount at the rates given in table below.

LT-I (A)
LT-I (B), LT-II (A), LT-II (D), LT-IV
and LT-V (C)
b)

INR. 10 per month
INR. 25 per month

In case of LT- II(B), LT-II(C), LT-III, LT-VI and LT-VII, the Licensee shall levy
Delayed Payment Surcharge (DPS) on the bill amount at the rate of 5 paisa/
INR.100/ day calculated from the due date mentioned on the bill, up to the date of
payment or INR. 150 whichever is higher. In case of grant of installments, the
Licensees shall levy interest at the rate of 18% per annum on the outstanding
amounts compounded annually and the two (DPS and Interest) shall not be levied
at the same time.

HT Category
a)

viii.

The Licensees shall charge the Delayed Payment Surcharge (DPS) per month on
the bill amount at the rate of 5 paisa/ INR. 100/ day or INR. 550 whichever is
higher. In case of grant of installments, the Licensee shall levy interest at the rate
of 18% per annum on the outstanding amounts, compounded annually and the two
charges shall not be levied at the same time.

Reconnection charges
Low Tension services
LT-I (A)
Overhead LT services
U.G. services
High Tension service
11 kV
33 kV
132 kV and above

ix.

INR. 25
INR. 75
INR. 200
INR. 1,000
INR. 2,000
INR. 3,000

Testing charges
Installation
The first test and inspection of a new installation or
of an extension to an existing installation.

11 | P a g e

LT

HT

Nil

Nil

<!-- page 12 -->

Charges payable by the consumer in advance for
each subsequent test and/or inspection if found
necessary owing to any fault in the installation or
to non-compliance of the conditions of supply.
Meter
A.C. Single Phase Energy meter
A.C. Three Phase Energy meter
LT Tri Vector meter
11 kV
33 kV
132 kV and above
Transformer oil
Each sample of oil
x.

INR. 200

INR. 100
INR. 300
INR. 2,000
INR. 3,000
INR. 3,000
INR. 3,000
INR. 150 per sample

Supervision/ inspection and checking charges
For LT I(A) Domestic
For LT I(B) Domestic
LT Agricultural
For all other LT Categories
For all HT Categories

xi.

INR. 20

INR. 100
INR. 100
INR. 100
INR. 100
INR. 600

Low power factor charges
For all consumer categories where kVAh billing is done, no Low Power Factor surcharge
shall be levied.

xii.

Capacitor surcharge
LT consumers having connected loads mentioned in table below shall pay capacitor
surcharge (as per rules in vogue) at the rate of 25% of the billed amount, if capacitors are
found defunct.
Category
LT-II and LT-VII (A)
LT-III and LT-VI (B)

xiii.

Connected load
<10 kW
<20 HP

Fixed charges – Seasonal industries
LT-III: INR. 50/ HP/ month on 30% contracted load
HT: Demand charges – 30% of CMD or recorded demand whichever is higher

xiv.

Temporary Supply for LT and HT consumers
Temporary supply can be given on the request of a consumer initially for a period up to 6
months as per the tariff applicable under the Temporary supply category. In case, the

12 | P a g e

<!-- page 13 -->

consumer requests for further extension, the same can be extended for another 6 months
with the same tariff as applicable to Temporary supply category. After the expiry of 12
months, the consumer is at liberty to seek further extension provided, the consumer pays
twice the regular tariff or the consumer has the choice of availing of regular supply.

13 | P a g e

<!-- page 14 -->

Table 2: Cross Subsidy Surcharge for FY 2016-17 as determined by the Commission

Sl. No

Category

CSS as per NTP
TSSPDCL

TSNPDCL

1
2
3
4
6
7

HIGH TENSION
HT Category at 11 kV
HT-I Industry
HT-II – Others
HT-III Airports, Railways and Bus stations
HT -IV Lift Irrigation and agriculture & CPWS
HT-VI Townships and Residential Colonies
HT-Temporary Supply

1.65
2.03
1.88
0.36
1.31
2.76

1.66
2.03
1.78
0.21
1.28
-

8
9
10
11
12

HT Category at 33 kV
HT-I Industry
HT-II – Others
HT -IV Lift Irrigation and agriculture & CPWS
HT-VI Townships and Residential Colonies
HT -Temporary Supply

1.48
1.81
1.26
1.32
3.34

1.44
1.78
0.86
1.35
-

13
14
15
16
17
18

HT Category at 132 kV and above
HT-I Industry
HT-II – Others
HT III-Airports, Railways and Bus Stations
HT -IV Lift Irrigation and agriculture & CPWS
HT-V Railway Traction
HT-VI Townships and Residential Colonies

1.35
1.77
1.51
1.24
1.41
-

1.34
3.55
1.28
1.42
1.28

14 | P a g e
