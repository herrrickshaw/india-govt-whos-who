---
doc_id: "ec8d3b0e1fc2cb8e"
source_url: "https://clinicalestablishments.telangana.gov.in/PdfFiles/GuidelinesforPaediatricsandPaediatricsSurgery.pdf"
ministry: "Clinical Establishments Registration & Regulation, Telangana"
title: "Guidelines for Paediatrics and Paediatrics Surgery"
date: ""
pages: 123
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7437602e17878057"
---

<!-- page 1 -->

STANDARD TREATMENT
GUIDELINES
PEDIATRICS & PEDIATRIC
SURGERY

Ministry of Health & Family Welfare
Govt. of India
1

<!-- page 2 -->

Contents

S.No.
1
2
3
4
5
6
7
8
9

Topic
PROTOCOL FOR DENGUE FEVER IN CHILDREN
EMPYEMA THORACIS
INGUINAL HERNIA IN CHILDREN
NEONATAL CHOLESTASIS
Urinary tract infection and vesico ureteric reflux
NEONATAL JAUNDICE: UNCONJUGATED HYPERBILIRUBINEMIA
NEONATAL INTESTINAL OBSTRUCTION
PROTOCOL FOR NEONATAL SEIZURES
UNDESCENDED TESTIS IN CHILDREN

Page
No.
4
17
36
45
62
69
87
97
114

2

<!-- page 3 -->

Group Head Coordinator of Development Team

Dr Ashley J D'cruz
Narayana Hurdayalaya
Bangalore

3

<!-- page 4 -->

PROTOCOL FOR DENGUE FEVER IN CHILDREN
Dr.Supraja Chandrashekar and
Dr.Rajiv Aggarwal
Department of Pediatrics,
Narayana Hrudayalaya,
Bangalore.

Dengue Fever
1

Introduction

Dengue has a wide spectrum of clinical presentations, often with unpredictable clinical
evolution and outcome. Reported case fatality rates are approximately 1%, but in India,
Indonesia and Myanmar, focal outbreaks away from the urban areas have reported casefatality rates of 3-5%.

2

Classification and Case definition
The Newer WHO Classification of Dengue is practical from the management
perspective and involves 2 categories- Dengue and Severe Dengue [including both the
previously classified categories Dengue Shock Syndrome and Dengue Haemorrhagic
fever]1

Case definition of Dengue fever (DF) (1,2):
Dengue fever is an acute febrile illness with one or more of the following:Headache, retrorbital pain, myalgia, arthralgia, rash, hemorrhagic manifestations, and
leukopenia and lab confirmation by ELISA.

Case Definition of Severe Dengue
Severe dengue should be considered if the patient is from an area of dengue risk
presenting with fever of 2–7 days plus any of the following features:
• There is evidence of plasma leakage, such as:
4

<!-- page 5 -->

– high or progressively rising haematocrit;
– pleural effusions or ascites;
– circulatory compromise or shock (tachycardia, cold and clammy extremities,
capillary refill time greater than three seconds, weak or undetectable pulse,
narrow pulse pressure or, in late shock, unrecordable blood pressure).
• There is significant bleeding.
• There is an altered level of consciousness (lethargy or restlessness, coma,
convulsions).
• There is severe gastrointestinal involvement (persistent vomiting, increasing or
intense abdominal pain, jaundice).
• There is severe organ impairment (acute liver failure, acute renal failure,
encephalopathy or encephalitis, ARDS or other unusual manifestations. )
Warning Signs in Dengue Fever *
• Abdominal pain or tenderness
• Persistent vomiting
• Clinical fluid accumulation
• Mucosal bleed
• Lethargy, restlessness
• Liver enlargement >2 cm
• Laboratory: increase in HCT concurrent with rapid decrease in platelet count
*(requiring strict observation and medical intervention)

3

Differential diagnosis
Conditions that mimic the febrile phase of dengue infection
·
·
·
·
·
·
·
·
·
·
·
·
·

Influenza,
Measles,
Chikungunya,
Infectious
Mononucleosis ,
HIV Seroconversion Illness
Rubella,
Scarlet Fever,
Meningococcal infection,
Drug reaction
Enteric infections
Meningo/encephalitis
Febrile seizures
Conditions that mimic the critical phase of dengue infection

·

Acute gastroenteritis,
5

<!-- page 6 -->

·
·
·
·
·
·
·
·

4

Malaria,
Leptospirosis,
Typhoid,
Typhus,
Viral hepatitis,
Acute HIV, seroconversion illness,
Bacterial sepsis, septic shock
Malignancies Acute leukaemia and other malignancies

Investigations
Situation 1
Diagnostic Methods

Test
Antigen Detection
[NS-1]
IgM assay

Advantage
· Easy to perform
· Early detection
· Less expensive
· Easy to perform
· Useful in outbreaks

Disadvantage
· Not as sensitive as above
·
·
·

May miss secondary infection due
to undetectable IgM
Useful only after 5 days
Cross reactivity

Supportive Tests
·

Complete Blood Count-Hemoglobin, haematocrit, White Cell Count, Platelet
count.
· Blood grouping and Cross Matching.
· Peripheral smear: Indicates the type of anemia and confirms leukopenia
The presence of giant platelets and clumps is indicative of good platelet function
· Serum electrolytes, Urea, Creatinine, Random Blood Sugar
· Liver and renal function tests.
· Chest X Ray

5

Treatment
Situation 1

6

<!-- page 7 -->

Out Patient Management
Simple Dengue Fever with no warning signs, adequate oral intake and clinically
well.
Home Care Advice
• Adequate rest
• Adequate fluid intake - Milk, fruit juice, electrolyte solution (ORS) and
barley/rice water.
• Paracetamol [ Acetylsalicylic acid, Mefenemic acid, ibuprofen or other nonsteroidal anti-inflammatory agents (NSAIDs) and steroids to be avoided.]
• Tepid sponging
• To look for mosquito breeding places in and around the home and eliminate
them
• Antibiotics are not necessary.
To observe for the following Danger signs and report immediately for hospital
admission
• Bleeding:
- red spots or patches on the skin
- bleeding from nose or gums
- vomiting blood
- black-coloured stools
- heavy menstruation/vaginal bleeding
• Frequent vomiting
• Severe abdominal pain
• Drowsiness, mental confusion or seizures
• Pale, cold or clammy hands and feet
• Difficulty in breathing

Out -patient laboratory monitoring- as indicated
•
•
•

Haematocrit
White cell count
Platelet count

Admission Criteria to Secondary Centre
·
·

Child having high fever, poor oral intake, or any danger signs as
enumerated above.
If platelet count < 100,000 /cu.mm or rapidly decreasing trend.

·

If haematocrit is rising trend.
7

<!-- page 8 -->

·

Special Social Circumstances (living far from a health facility without
reliable means of transport).

Admission Criteria to Tertiary Centre directly from OPD
·

If signs of severe dengue or warning signs.

·

If < 50,000/cu.mm to refer to Tertiary facility

·

If Dengue fever is present with other co-morbidities

Management
·

·

·

Encourage oral fluids. If not tolerated, start intravenous isotonic fluid
therapy with or without dextrose at maintenance. Give only isotonic
solutions.[ see annexure 1] Start with 5 ml/kg/hour for 1–2 hours, then
reduce by 2ml/kg/hour every 2 hours till 2ml/kg/hr provided there is
clinical improvement and haematocrit is appropriately improving. IV
fluids are usually required for 1-2 days.
Reassess the clinical status and repeat the haematocrit after 2 hours. If the
haematocrit remains the same, continue with the same rate for another 2–4
hours and reassess. If the vital signs/haematocrit is worsening increase the
fluid rate and refer immediately.
Switch to oral as soon as tolerated, total fluid therapy usually 24-48 hrs,
titrated to adequate urine output.

Tests for Monitoring:
Frequent recording of vital signs and investigation are essential for evaluating the results
of treatment.
·
·
·

Temperature, Pulse, blood pressure and respiration should be recorded
every hour (or more often) until stable subsequently 2 hourly.
An hourly fluid balance sheet should be kept, recording the type of
fluid and the rate and volume of its administration in order to evaluate
the adequacy of fluid replacement.
Chest X-ray, ultrasound abdomen, electrolytes 12-24 hrly as when
clinically indicated

8

<!-- page 9 -->

Referral Criteria
·
·
·
·

All patients with Warning signs and signs of Severe dengue.
Patients not clinically responding to therapy in situation.
Patients with serious co-morbid conditions
Platelet counts < 50,000/cu.mm with a decreasing trend.

Situation 2
Diagnostic Tests
As in situation 1 in addition the following tests may be useful Test
PCR
IgM/IgG ratio

Advantage
Disadvantage
· Sensitive
· Expensive
· Rapid turn around
· No standardisation
· Can differentiate between
primariy and secondary
dengue

Supportive Tests
As in Situation1 and in addition·
·
·
·
·

Blood gases.
Coagulation studies
Ultrasound
CT scan
ECHO

Admission Criteria
 Same as in Situation 1 in addition
 All patients fulfilling referral criteria form secondary care centres presenting
directly or referred.

9

<!-- page 10 -->

Pre requisites for management
•

Paediatric Intensive care facilities should be available.

Management:
·

·

·

·
·

Obtain a reference haematocrit before fluid therapy. Give only isotonic
solutions. Start with 5–7 ml/kg/hour for 1–2 hours, then reduce to 3–5
ml/kg/hr for 2–4 hours, and then reduce to 2–3 ml/kg/hr or less according
to the clinical response.
Reassess the clinical status and repeat the haematocrit. If the haematocrit
remains the same or rises only minimally, continue with the same rate (2–3
ml/kg/hr) for another 2–4 hours. If the vital signs are worsening and
haematocrit is rising rapidly, increase the rate to 5–10 ml/kg/hour for 1–2
hours. Reassess the clinical status, repeat the haematocrit and review fluid
infusion rates accordingly.
Give the minimum intravenous fluid volume required to maintain good
perfusion and urine output of about 0.5 ml/kg/hr. Intravenous fluids are
usually needed for only 24–48 hours. Reduce intravenous fluids gradually
when the rate of plasma leakage decreases towards the end of the critical
phase. This is indicated by urine output and/or oral fluid intake that is/are
adequate, or haematocrit decreasing below the baseline value in a stable
patient.
Patients with warning signs should be monitored by health care providers
until the period of risk is over.
Supportive Management- antipyretics, empirical antibiotics as clinically
indicated.

Monitoring as follows·

A detailed fluid balance should be maintained. Parameters that should be
monitored include hourly vital signs and peripheral perfusion. (Until the
patient is out of the critical phase), urine output (hourly).

·

Arterial blood pressure monitoring and central venous pressure monitoring
ideal for all children in shock who are fluid unresponsive. Arterial blood
gas monitoring as clinically indicated. Infusion pump will help in precise
regulation of fluid input.

·

Haematocrit (before and after fluid replacement/change, Hourly to 2nd
hourly haematocrit for first 6 hours , decreasing frequency as patient
improves ), Platelet counts 12 hourly blood glucose, and other organ
functions (such as renal profile, liver profile, coagulation profile, as
indicated).
Chest x-ray –Effusions, pulmonary edema

·

10

<!-- page 11 -->

·
·
·

Echocardiogram for assessment of left ventricular function, dimensions
and
regional wall dyskinesia
ECG to exclude arrhythmia;

Treatment of Shock- See flow chart 1
Treatment of haemorrhagic complications
•

A drop in haematocrit with no clinical improvement despite adequate fluid
administration indicates significant internal bleeding. Internal bleeding is
difficult to recognize in the presence of haemo-concentration. First correct the
component of shock according to standard guidelines with early use of packed
cell transfusion. Component transfusion is indicated in cases with significant
clinical bleeding.

•

The results of hematological tests (PT, APTT) may be studied to document the
severity of DIC Transfusion of cryoprecipitate and or fresh frozen plasma
should be considered in cases of DIC with bleeds.

•

Indications for platelet transfusion
•
•
•
•
•

Shock, acidosis with rapidly declining platelets ( greatest risk of DIC)
Significant mucosal bleeds (harbinger of intracranial hemorrhage)
Platelet count < 20,000 cu mm in the acute phase
Need for invasive procedures such as central lines maintain platelet count >
50,000 cu mm
A low platelet count is less significant after recovery from shock and may not
need to be transfused.

Treatment of Fluid overload
Fluid overload with large pleural effusions and ascites is a common cause of acute
respiratory distress and failure in severe dengue. Other causes of respiratory
distress include acute pulmonary oedema, severe metabolic acidosis from severe
shock, and Acute Respiratory Distress Syndrome (ARDS)
Prevention of fluid overload

11

<!-- page 12 -->

•

When the following signs are present, resuscitation intravenous fluids should
be discontinued or reduced to the minimum rate necessary to maintain
euglycaemia:
– signs of cessation of plasma leakage;
– stable blood pressure, pulse and peripheral perfusion;
– haematocrit decreases in the presence of a good pulse volume;
– afebrile for more than 24–48 days (without the use of antipyretics);
– resolving bowel/abdominal symptoms;
– improving urine output.

•
•

Aim for a minimum acceptable urine output [ 0.5ml/kg/hr] to titrate fluids.
Maintain intravascular volume by using colloids and maintaining oncotic
pressure.

The action plan for the treatment of fluid overload is as follows:
§
§
§

Oxygen therapy/ventilation if indicated should be given immediately.
Stopping intravenous fluid therapy during the recovery phase will
allow fluid in the pleural and peritoneal cavities to return to the
intravascular compartment resulting ion dieresis.
Diuretics as given below

If the patient has stable haemodynamic status and is out of the critical phase
(more than 24–48 hours of defervescence)
• Stop intravenous fluids but continue close monitoring.
• If necessary, give oral or intravenous furosemide 0.1–0.5 mg/kg/dose once
or twice daily, or a continuous infusion of furosemide 0.1 mg/kg/hour.
Monitor serum potassium and correct the ensuing hypokalaemia.
If the patient has stable haemodynamic status but is still within the critical
phase, reduce the intravenous fluid accordingly.
• Avoid diuretics during the plasma leakage phase.
• Patients who remain in shock with low or normal haematocrit levels but
show signs of fluid overload may have occult haemorrhage. Further
infusion of large volumes of intravenous fluids will lead only to a poor
outcome. If the patient remains in shock and the haematocrit is elevated,
repeated small boluses of a colloid solution may help.

Other Complications of Dengue

· Hypo/Hyperglycemia
· Electrolyte abnormalities
· Nosocomial/Co-infection
· Metabolic Acidosis
Should be managed under standard ICU protocols

12

<!-- page 13 -->

Supportive Care and Adjuvant Therapy
This may include:
· Renal replacement therapy, with a preference to continuous veno-venous
haemodialysis (CVVH), or peritoneal dialysis if the former unavailable;
· Vasopressor and inotropic therapies as temporary measures to prevent lifethreatening hypotension in dengue shock and during induction for intubation,
while correction of intravascular volume is being vigorously carried out;
· Further treatment of organ impairment, such as severe hepatic involvement or
encephalopathy or encephalitis; cardiac abnormalities, such as conduction
abnormalities, may occur.

Criteria for discharge:
·
·
·
·
·
·
·

6

Absence of fever for at least 24 hrs.
Return of appetite.
Clinical improvement.
Good urine output.
Stable haematocrit.
2 days after recovery from shock.
No respiratory distress from pleural effusion and ascitis.

Annexure
Immediate replacement of plasma loss/ Issotonic solutions: (1,2)
This should be done with any of the following solutions;
· Normal saline.
· Ringer’s lactate
· In severe/refractory shock, colloids such as Plasma , plasma substitutes
(6% hetastarch/dextran/ / 5% albumin /) may be preferred
· Fresh whole blood or packed red blood cells may be needed for persistent
shock despite restoration of fluid volume and a fall in haematocrit,
suggesting the possibility of occult blood loss.
§ Rapidly administered dextrose containing solution when used for resuscitation may
result in hyperglycemia and osmotic diuresis, delaying correction of hypovolaemia.
Secondly, dextrose is rapidly metabolized resulting in a hypotonic solution that is
inappropriate for shock correction.

13

<!-- page 14 -->

Recognition of Shock
The following clinical signs should indicate the presence of shock
Tachycardia , Low pulse volume
Capillary Refill time > 2 sec
Narrow pulse pressure
Blood pressure less than the 3rd centile for age
Cold clammy peripheries
Altered sensorium
Poor urine output [ <0.5ml/kg/hr consistently ]
Tachypnoea
Metabolic acidosis

Choice of Vasoactive agents/ post resuscitation fluid removal (8)
·
·
·
·
·

Shock with low BP for age: Dopamine 10mcg/kg/min OR Noradrenaline
/adrenaline 0.1-0.2mcg/kg/min
Shock with normal BP for age: Dobutamine 5-10mcg/kg/min
Shock with diastolic dysfunction on echo: Milrinone 0.25-0.75mcg/kg/min (no
loading dose)
Predominant pulmonary edema, haemodynamics stable : Nitroglycerine 13mcg/kg/min, furosemide infusion 3- 5mg/kg/day, titrate to urine output of 3-5
ml/kg/hr. Cease infusion and infuse fluid if hypoperfusion occurs.
Pulmonary edema, fluid overload, haemodynamics unstable: Ventilation vital
(high risk of mortality), can consider peritoneal dialysis if 24 hour experienced
nursing and medical staff available in PICU

Good Clinical Practice
·
·
·
·
·
·
·
·
·

Serial haematocrit measurement (if not bleeding), and urine output provide the
most objective guides to fluid replacement and prevention of fluid overload.
In shock –fluid resuscitate with 10-20ml/Kg of isotonic fluids over 30-60 minutes.
Consider in severe shock
Aim for ≈ 20% fall in haematocrit and adjust fluid rate downwards to avoid
overload
Aim for minimal acceptable urine output (0.5-1ml/kg/hr).
A urine output > 3 ml /kg /hour indicates Hypervolaemia..
Fluid replacements are dynamic hence require continuous reassessments.
No dextrose containing fluid should be used for fluid resuscitation,
Separate maintenance fluids are usually not required. Glucose/potassium may
need to be given separately. Start enteral feeds early.
All invasive procedures must be performed by most experienced person. If
possible, aim for platelets > 50,000/cu mm prior to central line insertion.

14

<!-- page 15 -->

·

Profuse bleeds may necessitate transfusion of platelets and FFP regardless of lab
values: conversely, low platelet counts in the recovering, stable patient may not be
an indication for transfusions.

Flow Chart 1-Volume replacement flow chart for a patient with Severe
Dengue and a >20% increase in haematocrit. [No Shock](1)
5 % Fluid Deficit
Initiate intravenous therapy (deficit + maintenance)*
5-7 ml/kg/hr

No Improvement
· Haematocrit, Pulse Rate
Rises, Pulse pressure < 20
· Insert Urinary Catheter

Improvement
Haematocrit Falls
Pulse rate and BP stable
Urine Output Rises

Decrease IVF
to 5ml/Kg/Hr

Vitals/Haematocrit
Worsens

Increase fluid to
10 mL/Kg/Hr

Improvement
Improvement
Decrease IVF to
3ml/kg/hr

Further
improvement

Stop IV Fluids

No Improvement,
evaluate for bleeds

Increase IVF to 15-20ml/kg/hr
for 1 hour then reassess

Deterioration of
vitals and urine
See Flowchart 2

*- Ideally, infuse replacement and deficit fluid as normal saline/Ringers Lactate (isotonic, non-dextrose
containing fluid) and maintenance fluid as ½ DNS with potassium as needed.
14

<!-- page 16 -->

Flow Chart 2: Management of Severe Dengue with Shock

High flow oxygen, normal saline /colloids 10-20ml/kg* as rapid boluses x 2
Monitor hourly vitals , urine output with an indwelling catheter.
Obtain baseline haematocrit, correct hypoglycaemia, hypocalcaemia,

Improvement

No improvement, re-check hematocrit,
Evaluate for source of blood loss

Decrease IVF
Colloid or plasma substitutes 10-20ml/kg,
Repeat as necessary
(if HCT falls or is “normal” with signs of shock,
Transfuse PRBC 10ml/kg or whole blood 20ml/kg.)

Further
improvement

No improvement

Insert CVP with great caution
OR
Proceed to inotrope / vasopressor (see appendix)

Can discontinue
fluids over 24-36

CVP normal or high with shock
CVP low /HCT fall <20%
Discharge
Inotropes/ vasopressors (see box below)*

Fluids till CVP/HCT target

Echo for LV systolic and diastolic function,
Assess chamber filling

Respiratory distress, Echo as above

Hemodynamics improved
Low dose diuretics
infusion

Hemodynamics unstable

Consider assisted ventilation
Initiate vasodilators when BP stable

Assisted ventilation, continue fluids

15

<!-- page 17 -->

References

1. Dengue guidelines for diagnosis, treatment, prevention and control. A joint
publication of the World Health Organization (WHO) and the Special Programme
for Research and Training in Tropical Diseases (TDR). New Edition 2009
2. Manual of Pediatric emergencies and Critical Care. Dr Suchitra Ranjit. Paras
Publications. Second Edition, 2010

16

<!-- page 18 -->

EMPYEMA THORACIS
Dr.Rajendra Saoji,
Consultant Pediatric Surgeon,
Nagpur
INTRODUCTION :
Empyema thoracis is a disease of historical importance with modern menace. It results
into significant morbidity ; affects precious growing period of a child, parental working
days & possible negligence of other family members & also incurs formidable burden on
scarce resources if treated improperly or inadequately. Traditionally empyema is being
managed empirically. However, with the widespread availability of radioimaging
techniques , fibrinolytic agents, safe & effective surgical procedures ( open or
thoracoscopy ) the recent data is leading to more focused management guidelines though
optimal management is still controversial (22).

CASE DEFINITION :

‘Empyema’ is a term derived from the Greek verb ‘empyein’ ( to suppurate ) & literally
refers to frank pus in the pleural space. It could be localised or free collection of purulent
material in pleural space as a result of combination of inoculation of bacteria & culture
medium of pleural fluid. It is an advanced parapneumonic effusion. Pleural space
infection is a continuum but classically has been divided into three stages :

Stage 1 or Exudative or Acute phase ( lasts upto 3 days ) : The inflammatory process
associated with the underlying pneumonia leads to accumulation of clear fluid with no or
low PMN invasion ,ph >7.3, normal glucose & LDH levels : termed as ‘ simple ‘
parapneumonic effusion .

Stage 2 or Fibrinopurulent or Transitional phase ( 3 to 21 days ): There is deposition of
fibrin in the pleural space leading to septations & formation of loculations.There is
increase in white cell count , ph < 7.3, glucose < 40mgs.,LDH >3 times the normal. This
is termed as ‘complicated ‘ parapnumonic effusion. Eventually when it becomes overt or
frank pus which is termed as an ‘ empyema’.The presence of septations (fibrinous strands
17

<!-- page 19 -->

in pleural fluid )doesn’t necessarily mean fluid doesn’t flow freely, although separate
loculations will not communicate with each other.

Stage 3 or Organisational or Chronic phase (> 3 wks . duration ): Fibroblasts infiltrate
the pleural space & thin intrapleural membranes are reorganised to become thick & non
elastic – the ‘peel’ or ‘rind’. These solid fibrous or leather like peels may prevent lung reexpansion ( “trapped lung” ), impair lung function & create a persistent pleural space with
potential for infection.At this stage spontaneous healing may occur or a chronic empyema
may develop.

Further complications which may occur are : bronchopleural fistula , lung abscess,
pneumatocele formation, empyema necessitans : perforation through chest wall,
fibrothorax etc…
Video-assisted thoracoscopic surgery (VATS ) is a key hole or minimal access surgical
approach. It achieves debridement of fibrinous pyogenic material, breakdown of
loculations, and drainage of pus from the pleural cavity under direct vision. It leaves three
small scars.
Mini-thoracotomy achieves debridement and evacuation in a similar manner to VATS
but it is an open procedure leaving a small linear scar along the rib line.

Decortication involves an open posterolateral thoracotomy and excision of the thick
fibrous pleural rind with evacuation of pyogenic material. It is a longer and more
complicated procedure leaving a larger linear scar along the rib line.

INCIDENCE OF CONDITION :
Empyema thoracis constitutes 5-10 % cases seen by a paediatrician in our country(23).
The reported rate of empyema thoracis complicating community acquired pneumonia is
said to be 27% in children(21). The prevalence of small parapneumonic effusions is
difficult to estimate (and often undetected )& they are unlikely to be reported in case
series. However cases non secondary to infection viz.. heart disease, malignancy,
connective tissue disorders, trauma etc. are largely dependent on the referral base & case
mix in the particular hospital (5,6,7,8).

18

<!-- page 20 -->

DIFFERENTIAL DIAGNOSIS:

Empyema secondary to bacterial infection eg..
staph./streptococci,Mycobacteria, Anarobes etc..
Neoplasm
Massive consolidation
Chylous collection
Haemothorax
Lung abscess
PREVENTION & COUNSELING :
Though complete prevention of empyema may not be possible due to factors such as
variance in microbial virulence & host’s immunological idiosyncracies etc.. but following
measures will be very beneficial………
* Adequate management of pneumonia ie early recognition, proper selection ,
duration& mode of delivery of antibiotics according to regional sensitivity pattern &
prompt referral facilities to higher centers.
*Prevention of pneumonia :
Ensuring widespread vaccination program for predisposing conditions such as
measles,Hib,Pneumococcal, chickenpox etc. because significant fall in incidence of
empyema has been reported in vaccinated as compared to non vaccinated zones (21).
Since Staph aureus is the most common organism responsible in our country improving
hygienic conditions especially during hot & humid conditions of the year ie April to
August will bring down in general incidence & severity of staph infections.
Improvement in nutritional status as PEM is known predisposing factor for all infective
illnesses & their complications.
Improvement in dental/oral hygiene as it is a welknown predisposing factor for
development of aspiration pneumonia.
Patients with immunodeficient conditions, tuberculosis, musculoskeletal/neurological
illnesses, CHD, Diabetes, Renal disease etc..must remain under high index of suspicion as
classical clinical presentation may be absent in such situations.

19

<!-- page 21 -->

SITUATION 1 :
At Secondary hospital / Non metro situation : Optimal standards of Treatment in
Situations where technology& resources are limited.
Clinical Diagnosis*
Acute , recurrent or chronic presentations are common.
If a child with pneumonia remains pyrexial or unwell 48 hrs. after the start of the
treatment possibility of parapneumonic effusion or empyema should be suspected.
Constitutional signs / symptoms viz.. lassitude, poor appetite, pallor, intermittent fever,
easy fatigability, sick look with dull percussion note & decreased breath sounds on
auscultation in the setting of partially treated pneumonia, PUO, Disseminated infections
e g.. Pyoderma / otitis media /arthritis/Osteomylitis / Serosal infections etc..
Febrile response may be blunted in immunocompromised patients.
*Physical findings & presentation may vary depending on type organism & duration of
illness.
*Inflammation of pleural space may present with abdominal pain &vomiting.
INVESTIGATIONS :
1) Chest X-ray : Posteroanterior ( PA ) view
2) Ultrasound chest :Sensitive for confirmation of pleural fluid , for guided diagnostic
tapping &
insertion of chest drainage tube.
3) Pleural fluid exam:
Colour, Odour, Gram staining, AFB, Bacterial culture, cytology.
Biochemistry: Ph, Sugar, LDH, Proteins.
4 ) Blood & sputum culture : if feasible
TREATMENT :
Conservative Management : Antibiotics ± Intercostal Dranaige Tube (ICD)
If effusion is simple & small in quantity : can be managed with antibiotics alone .But
very close observation is necessary for development of enlarging size &/or compromise
of respiratory function when prompt ICD placement is necessary.
Repeated thoracentesis has no role.
20

<!-- page 22 -->

If effusion is complicated or frank pus : Antibiotics + ICD

Surgical management : Only if adequately trained personnel & blood banking facilities
are available then limited thoracotomy in a situation where there is no satisfactory
response (persistent fever, incomplete lung expansion ,loculations on ultrasound etc..)ie..
in stage 2 or fibrinopurulent phase.

Standard operating procedure ( SOP )
All the patients of parapneumonic effusion or empyema should be admitted in hospital
i e.. no out patient or day care management to be done.
Pediatric surgeon or General surgeon familiar with basic thoracic surgery along with
paediatrician or respiratory physician should manage these cases.
They should be monitored closely & carefully by frequent clinical assessment & room air
saturation by pulse oximeter whenever child is in resp. distress.
Diagnostic imaging, microbiology, pleural fluid analysis should be carried out promptly.
Conservative management to be started swiftly & supported by antipyretics, analgesia,
oxygen ,
if necessary.
Empirical antitubercular therapy should be avoided as far as possible.
Antibiotics :
Intravenous antibiotics for 10 to 14 days for community acquired pneumonia covering
Gram positive cocci & anaerobes to be started empirically pending preferably c & s
report. Broad spectrum coverage should be started for hospital acquired pneumonia as
well as empyema following surgery, trauma & aspiration. Oral antibiotics should be
continued at discharge for 1-4 wks. or longer depending on disease state.
Chest drainage tube(ICD) insertion:
Chest drains should be inserted by adequately trained personnel to reduce the risk of
complications.

21

<!-- page 23 -->

Preferably procedure should be done in operation room or isolated / treatment room on
ward. However , if need arises it can be done as a bed side procedure as well.
A suitable assistant and trained nurse must be available.
Routine measurement of the platelet count and clotting studies are only recommended in
patients with known risk factors.
Where possible, any coagulopathy or platelet defect should be corrected before chest
drain insertion.
Ultrasound should be used to guide thoracocentesis or drain placement.
If general anaesthesia is not being used, intravenous sedation should only be given by
those trained in the use of conscious sedation, airway management and resuscitation of
children, using full monitoring equipment. .
Local anaesthesia, 2% xylocaine Or .25% bupivacaine, can also be used .
Large bore surgical drains should be inserted at the optimum site suggested by
ultrasound, but preferentially placed in the mid axillary line through the ‘‘safety
triangle’’.
Substantial force should never be used to insert a drain. Trocar usage preferably
should be avoided & should it be needed ,due to circumstances, great care is mandatory
to have a guard or control on it while inserting.

Chest tube should be secured well with non absorbable suture & appropriate dressing.
A chest radiograph should be performed after insertion of a chest drain.All chest tubes
should be connected to a unidirectional flow drainage system (such as an underwater seal
bottle) which must be kept below the level of the patient’s chest at all times.
A bubbling chest drain should never be clamped.
A clamped drain should be immediately unclamped and medical advice sought if a
patient complains of breathlessness or chest pain.
The drain should be clamped for 1 hour once 10 ml/kg are initially removed.
Patients with chest drains should be managed on wards by staff trained in chest drain
management.

22

<!-- page 24 -->

When there is a sudden cessation of fluid draining, the drain must be checked for
obstruction (blockage or kinking) by flushing.
The drain should be removed once there is clinical resolution.
A drain that cannot be unblocked should be removed and replaced by new catheter if
significant pleural fluid remains.
Surgical management :
Proper planning & ensuring availability of all the trained & experienced personnel ie
..surgeon, anaesthesiologist ,OT technician & nursing staff and also smooth supply of
oxygen,blood ,medicines etc..is very important .
Limited thoracotomy with or without rib resection by 5-7cms total incision on either side
of chest tube ,if already in situ.
To ensure complete lung expansion at the end of the procedure with minimal air leak.
If necrotic lung tissue is present then excision of the segment is to be done.
Send debrided tissue or ‘gubbin ‘ for histopathological examination.
ICD removal after complete lung expansion ,minimal or no drainage ,afebrile state & no
air leak
X ray chest to be done before ICD tube removal
Good analgesia ( oral &/or suppositories ) & early ambulation to hasten the recovery
should be practiced regularly.
Antibiotics for 1-2wks. after the discharge are usually sufficient except in situation of
complications.
Follow- up :
Till complete resolution of disease process & near complete lung expansion on x- ray
chest.
Evaluation of underlying condition, if any.
Referral criteria
If no satisfactory response to conservative management by 5-7 days.
Initial presentation as stage 2 or 3 of an empyema
23

<!-- page 25 -->

Suspecting underlying immunodeficiency condition or empyema associated with non
pneumonic pathologies which also require specialist’s attention.
Development of complications eg Persistent air leak.
Non availability of trained personnel at given time.

Situation 2
At Super Speciality Facility in Metro location where higher end technology is
available
Clinical diagnosis*
If a child with pneumonia remains pyrexial or unwell 48 hrs. after the start of the
treatment possibility of parapneumonic effusion or empyema should be suspected.
Constitutional s/s viz.. lassitude, poor appetite, pallor, intermittent fever, easy
fatigability, sick look with dull percussion note & decreased breath sounds on
auscultation in the setting of partially treated pneumonia, PUO, Disseminated infections
e g.. Pyoderma / otitis media /arthritis/Osteomylitis / Serosal infections etc..
Patients inadequately treated or responded to previous therapy.
Complications of an empyema eg.. BPF, lung abscess, empyema necessitans etc.
Patients with underlying conditions such as liver abscess, pancreatitis ,trauma , surgical or
endoscopic procedure done etc with respiratory signs & symptoms.
Response may be blunted ‘absent fever’ in immunocompromised patients.
*Acute , recurrent or chronic presentations are common.
*Physical findings & presentation may vary depending on type of organism & duration of
illness.
*Inflammation of pleural space may present with abdominal pain &vomiting
Investigations
Diagnostic imaging

24

<!-- page 26 -->

Posteroanterior or anteroposterior radiographs should be taken; there is no role for a
routine lateral radiograph.
Ultrasound may be used to confirm the presence of a pleural fluid collection, septations,
to guide thoracocentesis or drain placement.
Chest CT scans should not be performed routinely. It should be done once surgery is
contemplated to know pleural peel thickness, loculations & their details such as
number,position,size etc.; parenchymal pathology,guide for port placement if VATS is
being planned .
Diagnostic microbiology
Blood cultures should be performed in all patients with parapneumonic effusion.
When available, sputum should be sent for bacterial culture.
Diagnostic analysis of pleural fluid
Pleural fluid must be sent for microbiological analysis including Gram stain and bacterial
culture.
Aspirated pleural fluid should be sent for differential cell count.
Tuberculosis and malignancy must be excluded in the presence of pleural lymphocytosis.
If there is any indication the effusion is not secondary to infection, consider an initial
small volume diagnostic tap for cytological analysis, avoiding general
anaesthesia/sedation whenever possible.
Biochemical analysis of pleural fluid : Ph, LDH, sugar, & proteins

Diagnostic bronchoscopy

There is no indication for bronchoscopy and it is not routinely recommended. Considered
only when bronchoalveolar lavage is necessary or suspected foreign body or assessing
bronchial mucosal status for safe closure of br. stump when major pulmonary resection is
also planned alongwith decortication .

25

<!-- page 27 -->

Treatment
Conservative management (antibiotics ± simple drainage)
Effusions which are enlarging and/or compromising respiratory function should not be
managed by antibiotics alone.
Give consideration to early active treatment as conservative treatment results in
prolonged duration of illness and hospital stay.
If a child has significant pleural infection, a drain should be inserted at the outset and
repeated taps are not recommended.
Antibiotics
All cases should be treated with intravenous antibiotics and must include cover for Gram
positive cocci eg..Staph Aureous, Streptococci & Anarobes.
Broader spectrum cover is required for hospital acquired infections, as well as those
secondary to surgery, trauma, and aspiration.
Where possible, antibiotic choice should be guided by microbiology results.
Oral antibiotics should be given at discharge for 1–4 weeks, but longer if there is residual
disease.

Chest drains
Chest drains should be inserted by adequately trained personnel to reduce the risk of
complications.
A suitable assistant and trained nurse must be available.
Routine measurement of the platelet count and clotting studies are only recommended in
patients with known risk factors.
Where possible, any coagulopathy or platelet defect should be corrected before chest
drain insertion.
Ultrasound should be used to guide thoracocentesis or drain placement, when available.
If general anaesthesia is not being used, intravenous sedation should only be given by
those trained in the use of
conscious sedation, airway management and resuscitation of children, using full
monitoring equipment.
26

<!-- page 28 -->

Large bore surgical drains should be inserted at the optimum site suggested by
ultrasound. The usual site for ICD insertion should be in the mid axillary line in the 5th
intercostal space which is in the ‘safe triangle.’
Substantial force should never be used to insert a drain. Trocar usage preferably
should be avoided & should it be needed ,due to circumstances, great care is mandatory
to have a guard or control on it while inserting.
Chest radiograph should be performed after insertion of a chest drain.
All chest tubes should be connected to a unidirectional flow drainage system (such as an
underwater seal bottle) which must be kept below the level of the patient’s chest at all
times.
Appropriately trained nursing staff must supervise the use of chest drain suction.
A bubbling chest drain should never be clamped.
A clamped drain should be immediately unclamped and medical advice sought if a
patient complains of breathlessness or chest pain.
Patients with chest drains should be managed on specialist wards by staff trained in chest
drain management.
When there is a sudden cessation of fluid draining, the drain must be checked for
obstruction (blockage or kinking) by milking / flushing. If it can not be unblocked in
presence of significant pleural infection then it should be reinserted.
The drain should be removed once there is clinical resolution & / or lung expansion on xray.

Intrapleural fibrinolytics
Intrapleural fibrinolytics are said to shorten hospital stay and may be used for any
stage 2 empyema .
There is no evidence that any of the three fibrinolytics ( Streptokinase, Urokinase,
Alteplase ) are more effective than the others, but only urokinase has been studied in a
randomised controlled trial .
Urokinase should be given twice daily for 3 days (6 doses in total) using 40 000 units in
40 ml 0.9% saline for children weighing 10 kg or above, and 10 000 units in 10 ml 0.9%
saline for children weighing under 10 kg.
27

<!-- page 29 -->

Surgery
Patients should be considered for surgical treatment if they have persisting sepsis in
association with a persistent pleural collection, despite chest tube drainage and
antibiotics.
Failure of chest tube drainage, antibiotics, and fibrinolytics would necessiiate surgical
intervention.However, a pediatric surgeon should be involved early in the management of
empyema thoracis.
If requisite skill & facilities are available then VATS debridement is preferable over
open surgical procedure in stage 2 & select stage 3 empyema cases.
Organised empyema in a symptomatic child may require formal thoracotomy and
decortication.

Other management
Antipyretics should be given.
Analgesia is important to keep the child comfortable, particularly in the presence of a
chest drain.
Early mobilisation , chest physiotherapy and exercise is recommended.
Secondary scoliosis noted on the chest radiograph is common but transient; no specific
treatment is required but resolution must be confirmed.
Standard operating procedure ( SOP )
All the patients of parapneumonic effusion or empyema should be admitted in hospital
i e.. no out patient or day care management to be done.
Pediatric surgeon or a surgeon well trained in pediatric thoracic surgery
paediatrician or respiratory physician should manage these cases.

along with

CECT( Contrast Enhanced Cat Scan ) should be done if surgery is contemplated.
There are no evidence based criteria to guide the decision on when a child should proceed
to surgery, and consequently there is little consensus on the role of medical versus
surgical management (1)

28

<!-- page 30 -->

Intrapleural fibrinolytics
Intrapleural fibrinolytics shorten hospital stay and are recommended for any complicated
parapneumonic effusion (thick fluid with loculations) or empyema (overt pus).
There is no evidence that any of the three fibrinolytics(streptokinase,urokinase &tPA ) are
more effective than the others, but only urokinase has been studied in a randomised
controlled trial in children so is recommended(10 to 16)

Surgery:
The decision to involve a pediatric surgeon early in the decision making process should
be encouraged and referral should not automatically mean surgery is inevitable .(1)
Available procedures are: VATS, Mini thoracotomy & Decortication.
A chest drain(s) is left after each procedure for further drainage of fluid/pus.
A persistent radiological abnormality in a symptom-free well child is not an indication
for surgery.
Role of surgical management in complex empyema
(A) Organised empyema with a thick fibrous peel
Organised empyema in a symptomatic child may require formal thoracotomy and
decortication.
The surgical management of an organised empyema, in which a thick fibrous peel is
restricting lung expansion and causing chronic sepsis with fever, requires a formal
thoracotomy with excision of the pleural rinds (decortication) to achieve proper lung reexpansion. However, if the child is asymptomatic, surgery is not necessarily indicated.(18
)

(C) Bronchopleural fistula and pyopneumothorax
Different approaches have been advocated for a bronchopleural fistula related to an
empyema. Most fistulae are peripheral and the majority resolve with continued chest
drainage and antibiotics provided the lung shows satisfactory lung expansion.
However, at times they are slow and difficult to resolve, and it has been said that
conservative management and open thoracostomies result in protracted recovery and
morbidity. A more radical approach is partial decortication and muscle flap surgery to
bring a blood supply to the necrotic area and help with healing the fistula. This can either
be done as a staged procedure or a more aggressive one stage approach (19, 20)
29

<!-- page 31 -->

Follow up
Children should be followed up after discharge until they have recovered completely and
their chest radiograph has returned to near normal.
Underlying diagnosis—for example, immunodeficiency –may need to be considered in
selected situations.
open chest tube care in select patients till tube is in situ
For monitoring of ATT

Referral to tertiary speciality centre
Non availability of skilled & experienced personnel or infrastructure necessary for
management of complex situations eg. BPF, major lung resections or Thoracoscopic
procedure or need of PICU facilities etc..
When respiratory paediatrician is needed to be involved early in the care of patients
requiring chest tube drainage for a pleural infection & in critically ill child.
Who does what ? & Time lines :
Doctor : Pediatric Surgeon :
Does all the interventional procedures & involved in decision
making regarding overall management with paediatrician.
Pediatrician (Respiratory ) : Along with surgeon involved in conservative
management & post operative care & preop. preparation
General Surgeon : Does interventions In situation 1 only & in situation 2
maybe involved in assisting pediatric surgeon.
Anaesthesiologist : Anaesthesia & pain management
Junior doctor : Assisting in surgery, ICD care ,dressings & day to day
ward management

b ) OT Technician : Helping anaesthesiologist & surgeon in OT & if required on ward
bedside interventions.

30

<!-- page 32 -->

C ) Nursing Staff : Care & organisation of instrument trolly, medications & ICD care,
suction etc. & day to day nursing care.

Time line :
Radiological clearance takes few wks. to many months.
If an empyema fails to respond in 3-5 days of conservative treatment
intervention should be considered to reduce morbidity.

then surgical

Dwelling time for fibrinolytics is 1-4 hours.
There is no specific / precise time period for spontaneous closure or need for surgical
intervention in BPF patients.
Antibiotics are needed for 4-8 wks. ( Intravenous 2-3 wks. & oral 1-4wks.)
ATT is required for 6-9 mths duration.

31

<!-- page 33 -->

REFERENCES
1 BTS guidelines for the management of pleural infection in children I M Balfour-Lynn,
E abrahamson, G Cohen, et al.Thorax 2005 60: i1-i21
2 British Thoracic Society Standards of Care Committee. BTS guidelines for the
management of pleural disease. Thorax 2003;58(Suppl II):ii1–59. [I+]
3 Playfor SD, Smyth AR, Stewart RJ. Increase in incidence of childhood empyema.
Thorax 1997;52:932.
4 Freij BJ, Kusmiesz H, Nelson JD, et al. Parapneumonic effusions and empyema in
hospitalized children: a retrospective review. Pediatr Infect Dis1984;3:578–91.
5 Chonmaitree T, Powell KR. Parapneumonic pleural effusion and empyema in
children. Review of a 19-year experience, 1962–1980. Clin Pediatr
1983;22:414–9. [III]
6 Wolfe WG, Spock A, Bradford WD. Pleural fluid in infants and children. Am
Rev Respir Dis 1968;98:1027–32. [III]
7 Alkrinawi S, Chernick V. Pleural infection in children. Semin Respir Infect
1996;11:148–54. [III]
8 Thomson AH, Hull J, Kumar MR, et al. Randomised trial of intrapleural
urokinase in the treatment of childhood empyema. Thorax 2002;57:343–7.
9 Tiryaki T, Abbasoglu L, Bulut M. Management of thoracic empyema in
childhood. A study of 160 cases. Pediatr Surg Int 1995;10:534-6
10 Barbato A, Panizzolo C, Monciotti C, et al. Use of urokinase in childhood
pleural empyema. Pediatr Pulmonol 2003;35:50–5.
11 Kilic N, Celebi S, Gurpinar A, et al. Management of thoracic empyema in
children. Pediatr Surg Int 2002;18:21–3.
12 Kornecki A, Sivan Y. Treatment of loculated pleural effusion with intrapleural
urokinase in children. J Pediatr Surg 1997;32:1473–5.
13 Krishnan S, Amin N, Dozor AJ, et al. Urokinase in the management of
32

<!-- page 34 -->

uncomplicated parapneumonic effusions in children. Chest
1997;112:1579–83.
14 Rosen H, Nadkarni V, Theroux M, et al. Intrapleural streptokinase as
adjunctive treatment for persistent empyema in pediatric patients. Chest
1993;103:1190–3.
15 Stringel G, Hartman AR. Intrapleural instillation of urokinase in the treatment
of loculated pleural effusions in children. J Pediatr Surg 1994;29:1539–40.
16 Wells RG, Havens PL. Intrapleural fibrinolysis for parapneumonic effusion
and empyema in children. Radiology 2003;228:370–8. [III]
17 Bouros D, Schiza S, Patsourakis G, et al. Intrapleural streptokinase versus
urokinase in the treatment of complicated parapneumonic effusions: a
prospective, double-blind study. Am J Respir Crit Care Med
1997;155:291–5.
18 Fraga JC, Kim P. Surgical treatment of parapneumonic plearl effusion and its
complications. J Pediatr 2002;78(Suppl 2):161–73.
19 Asp K, Pasila M, Sulama M. Treatment of pyopneumothorax in infants and
children. Acta Chir Scand 1964;128:715.
20 Puskas JD, Mathisen DJ, Grillo HC, et al. Treatment strategies for
bronchopleural fistula. J Thorac Cardiovasc Surg 1995;109:989–95.
21 A K Baranwal, M Singh, R K Marwaha, L Kumar Empyema thoracis: a 10-year
comparative review of hospitalised children from south Asia . Arch Dis Child
2003;88:1009–1014
22 Sonnappa S, Cohen G, Owens CM, van Doorn C, Cairns J, Stanojevic S, Elliott MJ,
Jaffe´ A. Comparison of urokinase and video-assisted thoracoscopic surgery for treatment
of childhood empyema. Am J Respir Crit Care Med 2006;174:221–227
23 DKGupta,Shilpa Sharma.Management of empyema-Role of a surgeon J Indian assoc
pediatr surg July-Sept2005/vol10/issue 3..
33

<!-- page 35 -->

24 Robert L. Gates, Mark Hogan, Samuel Weinstein, and Marjorie J. Arca Drainage,
Fibrinolytics, or Surgery: A Comparison of Treatment Options in Pediatric Empyema
Journal of Pediatric Surgery, Vol 39, No 11 (November), 2004: pp 1638-1642

Resources required for one patient / procedure
Situation 1
Human resources : Surgeon 1, Pediatrician1, nursing staff1, OT technician 1,
Anaesthesiologist
Investigations :
Chest radiograph
Ultrasound scan of chest
Full blood count
C-reactive protein (some regard this as a useful marker of progress)
.Blood culture (including anaerobic bottle) & Sputum culture (if available)
Drugs & Cosumables :
Antibiotics
,Analgesics,antipyretics,Oxygen,IVFluids,sedatives,atropine/pyrolate,ketamine,
propafol,local anaesthetics,muscle relaxants,antiemetics, PPI/H2 blockers,Emergency
medicationsetc…,Betadine, Savolon, spirit, Normal saline
Syringes &
needles,IVsets,oxygen mask,IVCannulae,Sticking plaster,Cotton, gauze pieces,
pads,suture material,ICD tubes, Under water seal drainage bags etc…Gloves
(surgical),Gowns, Eye towel
Equipments :
EQUIPMENT FOR CHEST DRAIN INSERTION
Sterile gloves and gown
Skin antiseptic solution, e.g. povidone iodine (Betadine) or
chlorhexidine in alcohol
Sterile gauze swabs
34

<!-- page 36 -->

A selection of syringes (2 ml and 5 ml) and needles (21–25gauge)
Local anaesthetic, e.g. 0.25% bupivacaine (Marcaine) , 2% xylocaine
Scalpel and blade
Suture (e.g. 2/0 or 3/0 silk)
Guide wire with dilators for Seldinger technique
Chest tube: 10–12 FG appropriate for most children (8–14 FG should be available)
Connecting tubing
Closed drainage system (including sterile water if underwater seal being used)
Sterile universal containers and anaerobic blood culture bottle for pleural fluid
Large transparent adhesive dressings
Equipment for percutaneous long line and bottles for blood tests.
Limited Thoracotomy Equipments :
Basic Thoracotomy set
General Anaesthesia machine, Tracheal intubation set organised well in operation room
with other basic facilities eg. Good negative suction source, satisfactory illumination,
patient warming gadgets etc..
Situation 2
Human resources : Well trained pediatric surgeon, Respiratory pediatrician &
Anaesthesiologist mandatory ,Assistent Surgeon, Resident doctors & specialised nursing
staff round the clock, Anaesthesia technician.
Investigations : As in situation 1 + Albumin, Creatinine, blood group ,Blood gases,
Specialised infective, immunodeficiency etc…workup facilities + Contrast Enhanced CT
Scan + investigations facilities for associated problems & complications from the disease
process.
Equipments :
Basic + High end open surgery & Thoracoscopy set in well planned & equipped OT.
Drugs & Consumables
35

<!-- page 37 -->

INGUINAL HERNIA IN CHILDREN
Dr.Sanjay Rao
Dr.Vinay C
Dr. Zameer K
Consultant Pediatric Surgeons,
Narayana Hrudayalaya,
Bangalore
a)

WHEN TO SUSPECT/ RECOGNIZE?

Inguinal hernia is suspected in any child with a swelling in the inguinoscrotal region.

a.

Introduction:
Inguinal hernia repair is one of the most common pediatric operations performed. Most
hernias that present at birth or in childhood are indirect inguinal hernias. All pediatric
inguinal hernias require operative treatment to prevent the development of
complications, such as inguinal hernia incarceration or strangulation.

b.

Case definition:
Inguinal hernia is a type of ventral hernia that occurs when an intra-abdominal structures, such
as bowel or omentum, protrude through the open processus vaginalis through the inguinal
canal.

b)

INCIDENCE OF THE CONDITION IN OUR COUNTRY

Although the exact incidence of indirect inguinal hernia in infants and children is unknown, the
reported incidence ranges from 1-5%. Sixty percent of hernias occur on the right side. Premature
infants are at increased risk for inguinal hernia, with incidence rates of 2% in females and 7-30%
in males.

36

<!-- page 38 -->

Inguinal hernias are much more common in males than in females. The male-to-female ratio is
estimated to be 4-8:1.

Premature infants are at an increased risk for inguinal hernia, with the incidence ranging from 730%. Moreover, the associated risk of incarceration is more than 60% in this population.

c)

DIFFERENTIAL DIAGNOSIS
Congenital Hydrocoele
Inguinal adenitis
Femoral adenitis
Psoas abscess
Saphenous varix
Retractile testis
Varicocele
Testicular tumor
Undescended testis

d)

PREVENTION AND COUNSELING :

A high index of suspicion is required-especially in the high risk population of
premature babies. If a child has developed a unilateral hernia, there is a potential risk of
developing a hernia on the opposite side-this risk is higher in premature babies and infant girls.
These families need to be counseled about signs and symptoms of these recurrences.

e)

OPTIMAL DIAGNOSTIC CRITERIA, INVESTIGATIONS,
TREATMENT & REFERRAL CRITERIA

37

<!-- page 39 -->

Diagnostic criteria: diagnosis is clinical.

1. History of a soft swelling in inguinal region. Gets larger when child cries, may
disappear completely when the child is quietly lying down.
2. Examination: Soft, reducible mass in the inguinal area is diagnostic. Even in
the absence of the mass at examination, a strong history is adequate for
diagnosis.

Investigations:

No imaging studies are required. General tests towards anaesthesia fitness may be
required ( haemoglobin, urine analysis).

Referral Criteria:

A strong clinical history and physical findings of inguinal hernia are indications for
referral for surgery.

HISTORY

The child with an inguinal hernia presents with a bulge at the internal or external ring or within
the scrotum. The parents typically provide the history of a visible swelling or bulge, commonly
intermittent, in the inguinoscrotal region in boys and inguinolabial region in girls.

Usually, a simple inguinal hernia in an infant is painless.

The bulge commonly occurs after crying or straining and often resolves during the night while
the baby is sleeping.

38

<!-- page 40 -->

If the family provides a history of a painful bulge in the inguinal region, one must suspect the
presence of an incarcerated inguinal hernia. Patients with an incarcerated hernia generally
present with a tender firm mass in the inguinal canal or scrotum. The child may be fussy,
unwilling to feed, and inconsolably crying. The skin overlying the bulge may be edematous,
erythematous, and discolored.

39

<!-- page 41 -->

EXAMINATION

Physical examination of a child with an inguinal hernia typically reveals a palpable
smooth mass originating from the external ring lateral to the pubic tubercle. The mass may only
be noticeable after coughing or performing a Valsalva maneuver and it should be reduced easily.
Occasionally, the examining physician may feel the loops of intestine within the hernia sac. In
girls, feeling the ovary in the hernia sac is not unusual; it is not infrequently confused with a
lymph node in the groin region. In boys, palpation of both testicles is important to rule out an
undescended or retractile testicle.

Hernia and hydrocele: Transillumination has been advocated as a means of distinguishing
between the presence of a sac filled with fluid in the scrotum (hydrocele) and the presence of
bowel in the scrotal sac. However, in cases of inguinal hernia incarceration, transillumination
may not be beneficial because any viscera that are distended and fluid-filled in the scrotum of a
young infant may also transilluminate.

INVESTIGATIONS
No laboratory studies are needed in the assessment of a patient with a suspected inguinal
hernia and/or hydrocele.
Ultrasonography: Its routine use is unnecessary. It is indicated when presentation and
examination suggest a diagnosis other than hernia or hydrocele. An enlarged inguinal lymph
node can mimic an incarcerated inguinal hernia.
Laparoscopy: Diagnostic laparoscopy may rarely be required for determining the presence of an
inguinal hernia. It is used only in the following: a) assessment of contralateral hernia when one is
being operated upon, and b) recurrent hernia after previous surgery.

TREATMENT
Congenital hernias are treated surgically with herniotomy. Surgical treatment can be either open
or laparoscopic. Inguinal hernias do not spontaneously heal and must be surgically repaired
because of the ever-present risk of incarceration. Repair is usually planned as an elective
procedure as soon as possible after diagnosis.
40

<!-- page 42 -->

If hernia is irreducible, ie cannot be easily pushed back into the abdomen, child needs to be
admitted and a manual reduction tried by an experienced pediatric surgeon. If successful, the
operation is performed after 24-48 hours to allow local oedema to settle down.

If reduction is unsuccessful, or if there is clinical evidence of inflammation (as evidenced by pain,
redness, edema of skin on hernia) emergency exploration and hernia repair is necessary.

Hydroceles without hernia in neonates: This is the only exception in which surgical treatment
may be delayed. Repair of hydroceles in neonates without the presence of hernia is typically
delayed for 12 months because the connection with the peritoneal cavity (via the processus
vaginalis) may be very small and may have already closed or be in the process of closing. If the
hydorcoele persists after this observation period, operative repair is indicated and appropriate.

Postpone the operation in the event of upper respiratory tract infection,otitis media, or
significant rash in the groin.

FOLLOW UP
No specific limitations are indicated once the diagnosis of an inguinal hernia has been
established; however, following operative repair, avoidance of major physical activity for 1 week
is recommended. After that time, the patient is allowed to participate in physical activities (eg,
sports, swimming, running).
Children younger than 5 years are likely to recover extremely quickly from surgery; they are
typically capable of returning to their normal level of activities within 24-48 hours of surgery.

*Situation 1: At Secondary Hospital/ Non-Metro situation: Optimal
Standards of Treatment in Situations where technology and
resources are limited

a.

Clinical Diagnosis:
Similar generic diagnostic criteria apply. A typical history and physical finding are
adequate for diagnosis.

41

<!-- page 43 -->

b.

Investigations:
a. Investigations are not required other than for anaesthetic purposes.
b. Rarely, ultrasonography and diagnostic laparoscopy may be indicated

c.

Treatment:
a. Inguinal hernia: Treatment is surgery -herniotomy operation that aims at ligating
the patent processus vaginalis at the internal ring after reduction of contents
into the abdomen
nd
b. Congenital hydrocoele: Treatment is deferred until the 2 birthday as there is a
80% chance of spontaneous closure. Surgery is indicated if hydrocoele persists
beyond the 2nd year and if it is rapidly growing is size.
c. All hernia and hydrocoele repairs in infants and children MUST be performed by
a qualified pediatric surgeon.

Standard Operating procedure

a. In Patient : inpatient care is indicated if:
I. h/o incarceration or obstructions
II. neonate awaiting hernia repair
b. Out Patient
i. Outpatient care is adequate for diagnosis and follow up in most children
ii. Clinical evaluation usually sufficient to diagnose
c. Day Care
i. most hernia operations in children are done as day care procedures
d. Referral criteria:

A child with a hernia needs referral to a higher centre if:
1.
2.
3.
4.
5.

neonatal age and anaesthesia facilities are inadequate
ex-premature baby who had prolonged ventilation
recurrent inguinal hernia
inguinal hernia with complications (incarceration, obstruction)
associated major morbidity-such as cardiac anomalies, lung disease, renal
disease, ascites

*Situation 2: At Super Specialty Facility in Metro location where
higher-end technology is available

42

<!-- page 44 -->

a. Clinical Diagnosis:
a. Same as in situation1
b. Investigations:
a. Same as in situation1
b. additional tests for comorbid conditions such as pulmonary and cardiac
anomalies
c. Treatment:
a. principles of treatment are same as above

Standard Operating procedure
a. In Patient
i. criteria same as above
ii. all babies under 1 year of age need inpatient care after surgery-as there
is an increased risk of apnoea in this subgroup.
iii.
All children with comorbid problems-cardiac, respiratory or
others, need inpatient care after surgery
b
Out Patient
i. criteria same as above

c. Day Care
ii.
criteria same as above
iii.
Children who are above 1 year of age and in good health with
no associated comorbid problems can be treated as day care procedures
d. Referral criteria:
No further referrals

f)

WHO DOES WHAT? and TIMELINES
Doctor makes a clinical diagnosis, counsels the family and plans surgery- a
pediatric surgeon performs the surgery
b. Nurse: assists surgeon in care of child during pre, intra and post operative
course of the baby
c. Technician: assists medical and nursing teams in care of child during intra and
post-operative periods.
a.

43

<!-- page 45 -->

g)

FURTHER READING / REFERENCES

1. Brandt ML. Pediatric hernias. Surg Clin North Am. Feb 2008;88(1):27-43, vii-viii.
2. Skinner MA, Grosfeld JL. Inguinal and umbilical hernia repair in infants and
children. Surg Clin North Am. Jun 1993;73(3):439-49.
3. Deeba S, Purkayastha S, Paraskevas P, et al. Laparoscopic approach to
incarcerated and strangulated inguinal hernias. JSLS. Jul-Sep 2009;13(3):327-31.

RESOURCES REQUIRED FOR ONE PATIENT / PROCEDURE (PATIENT
WEIGHT 60 KGS)
(Units to be specified for human resources, investigations, drugs
and consumables and equipment. Quantity to also be specified)

Situation

Human Resources

Drugs & Consumables

Equipment

1

·

·
·

2

·
·
·
·

·
·
·
·
·
·
·
·
·
·

·
·
·

Pediatric
Surgeon
Pediatrician
Pediatric Nurse
Lab. Technician
Pediatric
surgeon
Pediatrician
Pediatric
anaesthesist
Pediatric Nurse

I.V. Glucose/ Fluids
I.V. cannula
I.V. Set
anesthetic drugs, disposables
antibiotic prophylaxis
I.V. Glucose/ Fluids
I.V. cannula
I.V. Set
anesthetic drugs, disposables
antibiotic prophylaxis

·
·
·
·

Radiant Warmer
Saturation
monitor
Basic Lab
Child friendly OT
ICU
Pediatric O.T.

44

<!-- page 46 -->

NEONATAL CHOLESTASIS

Prepared by:
1. Dr.Sanjay Rao MS,MCh (Paediatric Surgery)
Consultant Pediatric Surgeon,
Narayana Hrudayalaya,
Bangalore
2. Dr.Rajiv Aggarwal, MD
Consultant Pediatrician and Neonatologist
Narayana Hrudayalaya,
Bangalore
Assisted by:
1. Dr.Vinay C
2. Dr. Zameer K
Both from Department of Pediatric Surgery
Narayana Hrudayalaya,Bangalore

I.

WHEN TO SUSPECT/ RECOGNIZE?

Introduction:
Neonatal cholestatis is a pathological condition in the newborn where in bile flow from
the liver is reduced. Neonatal Cholestasis Syndrome (NCS) includes a wide spectrum of clinical
conditions ranging from congenital malformations of the hepatobiliary tree, infections, inborn
errors of metabolism to some of the recently identified clinical conditions with or without
genetic predilection. Most of these disorders have linkage with insults during antenatal, natal
and postnatal periods.
45

<!-- page 47 -->

NCS has largely remained ignored in our country.

Case definition:
Neonatal cholestasis refers to conjugated hyperbilirubinemia >1.5 – 2 mg% and/or
direct component of more than 20% of total bilirubin in a newborn/ infant with passage of
high coloured urine with or without clay stools.

II.

INCIDENCE OF THE CONDITION IN OUR COUNTRY

NCS constitutes 30% of referrals with hepatobiliary disorders in India. The average
age of presentation to a specialized center is 3.5 months (range birth to 15 months) with a
consequent delay of 3 months in referral (medical and surgical centers).

Based on consensus conference by paediatric gastroenterology, out of 1008 cases
analysed in our country

·
·
·
·

Hepatocellular causes: 53 %( neonatal hepatitis-47%, metabolic-4%, others-2%)
Obstructive causes: 38 %( billiary atresia-34%, Choledochal cyst-4%)
Ductal paucity: 3%
Idiopathic: 6%

In neonatal hepatitis-

·
·
·
·
III.

Idiopathic giant cell hepatitis: 64%,
TORCH: 22%
Sepsis: 8%
Others: 6%

DIFFERENTIAL DIAGNOSIS

46

<!-- page 48 -->

A. CAUSES OF EXTRA HEPATIC OBSTRUCTION

§
§
§
§
§
§

Biliary Atresia
Choledochal Cyst
Spontaneous perforation of bile ducts
Biliary stenosis
Inspissation of bile ducts
Mass/peritoneal bands

B. HEPATOCELLULAR

1. INFECTIVE

·
·
·
·
·
·
·

Sepsis
TORCH
Malaria
UTI
Hepatitis
Other Viral infections
HIV

2. METABOLIC

·
·
·
·
·
·
·
·
·
·

Galactossemia
Hereditary Fructosemia
Tyrosinemia
Alfa 1 AT deficiency
Bile acid disorders
Fatty Acid Oxidation defects
Cystic fibrosis
Storage disorders
Neonatal hemochromatosis
Zelweger’s disease

3. MISCELLANEOUS

47

<!-- page 49 -->

·
·
·
·
·

TPN
Shock
Hypoperfusion
Downs
Congenital heart / valvular abn

4. IDIOPATHIC
C. PAUCITY OF INTRAHEPATIC DUCTS
§

Syndromic - Alagille's syndrome, Byler's, Aagene's

§

Non - Syndromic - a 1AT deficiency, Idiopathic, Familial

IV.

PREVENTION AND COUNSELING

A high index of suspicion is necessary. Mothers must be informed about the need to
seek medical attention if jaundice persists beyond two weeks of birth and / or baby passes
pale stools and high coloured urine. If the previous sibling has had liver disease antenatal
counselling and referral for further evaluation may be necessary.

V.

OPTIMAL DIAGNOSTIC CRITERIA, INVESTIGATIONS,
TREATMENT & REFERRAL CRITERIA
a. Diagnostic criteria:

1.
2.

Clinical: Neonate with jaundice persistent beyond 2 weeks, dark colour urine
and/or pale stool
Screening Biochemistry: Serum bilirubin direct and indirect

Any child that meets with the clinical and /or biochemical criteria needs
investigation, treatment and referral.

48

<!-- page 50 -->

Typical presentation:
·

Newborn with jaundice/ high colored urine with or without clay colour stools beyond
two weeks of age.

·

Typically a child with biliary atresia is usually a term baby with normal weight, accepting
feeds well.

·

Pigmented stools do not rule out Biliary atresia, upto 30% of biliary atresia stools are
yellow in the early weeks.

Clinical examinations:

Clinical evaluation-

1.

Sick baby: Sepsis/UTI/Congenital infections/metabolic disorders.

2.

Dysmorphism

3.

Examination of eye and fundus must be done·
Cataract in Galactosemia
·
Chorioretinitis in TORCH
·
Posterior embryotoxins in alagilles syndrome
·
Cherry red spot in Lipid storage disorders

4.
5.

Chronic Cholestatis – Pruritis/ irritability/xanthomas
Failure to thrive.

: Downs syndrome/ alagilles syndrome.

*Situation 1: At Secondary Hospital/ Non-Metro situation: Optimal
Standards of Treatment in Situations where technology and
resources are limited

49

<!-- page 51 -->

e.

Clinical Diagnosis:
2. Jaundiced child
3. Dark urine
4. Pale stool
5. Hepatomegaly ± splenomegaly

f.

Investigations:
· Hematology: CBC
· Urine routine & microscopy
· Biochemistry:
a. LFT
b. RFT
c. PT/INR
d. RBS
· Imaging: USG Abdomen

g.

Treatment:

Standard Operating procedure

4.
5.
6.
7.

Resuscitation if required,
Correction of Hypoglycemia
Administration of Vitamin K (0.3mg/kg parenteral)
Initiation of antibiotics: if there is clinical or laboratory evidence of infection or
sepsis

a.

In Patient : Child needs admission if
1. there is clinical evidence of dehydration
2. clinical ± laboratory evidence of hypoglycemia
sepsis or coagulopathy.
3. failure to thrive

b.

Out Patient : Baby who is clinically well, feeding well and has no evidence of
hypoglycemia or coagulopathy can be investigated as an outpatient

50

<!-- page 52 -->

c.

h.

Day Care : No role of day care admission.

Referral criteria: ( All workup at this level must be completed by 48 hours)
1.

Any child with neonatal cholestasis syndrome who is > 2 weeks
of age

2.

Clinically unwell, poor feeding, poor weight gain

3.

Evidence of coagulopathy, hypoglycemia or sepsis

*Situation 2: At Super Specialty Facility in Metro location where
higher-end technology is available

Clinical Diagnosis:

Investigations: Urgent Investigations

§
§
§
§
§
§
§
§
§

Blood counts
LFT
PT
Electrolytes
Blood culture
Urine culture, Urine microscopy
Urine reducing substances
GRBS
Ascitic tap (if ascites)

Standard LFT are usually abnormal with modestly raised levels of AST, ALT, and alkaline
phosphatase. GGT is raised in all cases of cholestasis except in one of the bile acid synthetic
defects. Serum albumin does not fall till late. None of the biochemical tests are of deciding value
and at best reflect the degree of damage to liver.
Tests directed towards infective and metabolic causes :
51

<!-- page 53 -->

Blood Tests

• TORCH, VDRL, Hepatitis B/C, HIV
• T4, TSH
• Serum cortisol
• α l AT levels and phenotype
• Galactose 1 Phosphate Uridyl transferase (to r/o galactosemia)
• Urinary succinyl acetone (to r/o tyrosinemia)
• Cholesterol, triglycerides
• S. iron and ferritin levels (to r/o neonatal hemachromatosis)

Radiology

Role of USG
USG can exclude choledochal cyst, any focal lesions, dilated CBD, anomalies of viscera or
portal hypertension.
Role of Hida Scan
Hepatobiliary scintigraphy, after a 5 day priming with phenobarbitone,is useful.
Excretion of the radio-tracer into the gut rules out biliary atresia. However, the converse is not
true and absence of gut excretion of radiotracer requires further evaluation.

Role of Liver Biopsy
Liver biopsy is useful in the charecterisation of NCS in some cases. Coagulopathy and
ascitis are contraindications for percutaneous liver biopsy.

52

<!-- page 54 -->

TREATMENT

On suspicion of cholestatic liver disease, vitamin-K is started along with supplementation
of other fat soluble vitamins (A,D,E,)

Treatable Causes

Medical
§
§
§
§
§
§
§
§
§

Sepsis
UTI
Congenital infections
Hepatitis
Galactosemia
Heriditary fructose intolerance
Hypothyroidism
Hypopitaris m
Tyrosinaemia

Surgical
3.
4.
5.
6.

Biliary Atresia
Choledochal cyst
Spontaneous perforation of bile ducts
Inspissation of bile ducts

SUPPORTIVE CARE

Nutrition

 Energy - 125% RDA
 Protein intake -2-3 gm/kg/day in infants (0.5gm/kg/day in hepatic encephalopathy)

53

<!-- page 55 -->



Vitamin A should be supplemented in a dose of 50,000 IU intramuscularly at diagnosis
and then 10,000 IU monthly till cholestasis resolves. Avoid hyper- vitaminosis as it can
enhance fibrosis.



Vitamin D should be supplemented in a dose of 30,000 IU intramuscular at diag-nosis
and then monthly till cholestasis resolves. If the child has rickets give a dose of 60,000 IU.



Oral Vitamin E, supplementation (50-200 mg/day) is required to avoid neuro-muscular
degeneration, retinal pigmentation and hemolytic anemia.



Provide Vitamin K 5 mg/day intramuscular/intravenous for first 3 days and then 5
mg weekly. Perform prothombin time (PT) monthly. Administer injectable
vitamin K if PT is prolonged.

 Water soluble vitamins and trace elements (2-5) times RDA)

Pruritis

For control of pruritis following agents have been tried :1. Phenobarbitone-5mg/kg/day
2. Rifampicin- 1Omg/kg/day
3. Ursodeoxycholic acid-10-20 mg/kg/day
4. Cholestyramine-4- 8gm/kg/day
5. Terfenadine l-3mg/kg/day
6. Carbamazepine

Liver Transplantation
This may remain the only option for infants with decompensated liver disease (ascites
and /or encephalopathy) or failed portoenterostomy.

54

<!-- page 56 -->

TREATMENT PLAN

55

<!-- page 57 -->

Standard Operating procedure

 In Patient only: May require ICU monitoring
 Referral criteria:

Referral criteria for a specialist centre:

Any case of neonatal cholestasis as defined by above parameters with deranged liver function
tests to be referred to tertiary centre for further management.

Child needs to be referred to a specialist pediatric liver unit if,
1. Evidence of progressive liver failure
2. Evidence of complications such as portal
hypertension, SBP, Respiratory distress, pathological
fractures.
3. Failure of Kasai operation
Evidence of liver cirrhosis in biopsy
Jaundice not cleared by 2 months after surgery
4. Considerations for liver transplant
Situation 2:

Referred cases from secondary centres or any newborn with evidence of cholestatis with
deranged liver function tests.

56

<!-- page 58 -->

Investigation:

Medical causes

Surgical causes

As in situation 1 &
Additional investigations
USG Abdomen:

Blood culture
Urine culture
Urine reducing substances
Prothrombin time
T3/T4/TSH
TORCH/VDRL
Hep B/C, HIV
Metabolic work up

Day 5 : Prepare patient for HIDA (Priming
with gardenal 3-5 mg/kg)

57

<!-- page 59 -->

Subsequent investigation (if initial workup negative)
·







α 1 antitrypsin levels & phenotype
Galactose 1- P uridyl transferase
Urinary succinyl acetone
Cholesterol, Triglycerides
Serum ferritin, iron
Radiology
Rare investigation-

Bone marrow aspiration/skin biopsy/muscle biopsy/ serum lactate / pyruvate / ammonia,
very long chain fatty acid, urinary organic acids, urinary bile acids, auto immune screen / sweat
chloride test.

Treatment:

 Aims of treatment
 Within 7 days of hospitalisation treatment is mandatory.
· Kasai’s Portoenterostomy preferably within 60 days of life.

Medical:

Neonatal hepatitis:
2.
3.
4.
5.
6.
7.

Bacterial Sepsis/ UTI
Malaria
Toxoplasmosis & syphilis
CMV
Herpes
Metabolic:
8. Galactosemia
9. Fructosemia
10. Hypothyroidism

: antibiotics
: antimalarial
: specific antibiotics
: ganciclovir
: acyclovir
: stop lactose milk
: withdrawal of fructose containing item
: Thyroxine

Chronic cholestatis:
 Basically improve nutritional status
58

<!-- page 60 -->







Provide energy (125%RDA)
Proteins intake 2-3 gm/kg
MCT diet
Fat Soluble vitamins (A/D/E/K)
Pruritis control:
Phenobarbitone / Rifampicin/ UDCA/ Cholestyramine/ Terfenadine/ Carbamazepine

Surgical

Biliary atresia

Kasai Portoenterostomy

Choledochal cyst

Laparatomy

Failed Kasai

Liver Transplantation

End stage liver disease
PFIC

VI.

WHO DOES WHAT? and TIMELINES
·

·

·

VII.

Doctor :
· Close and continuous and crucial monitoring of the child
· Planning of tests and treatment
·
Nurse
§ Counseling and support to child and family
§ Assisting to treatment

Technician

FURTHER READING / REFERENCES

1. S.K.Yachha: Consensus Reoprt on Neonatal Cholestasis Syndrome, Indian Pediatircs
2000;37:845-85
2. Neelam Mohan: Neonatal Cholestasis, openmed.nic.in/1827/01/neelam.pdf
3. Chardot C, CartonM, Spire-bendelae N etal.Is Kasais. Operation still indicated in children
older than 3 months. Diagnosed with billiary atresia Pediatr2001; 138:224-28

59

<!-- page 61 -->

4. ChhabraM, PoddarU, Thapa BR, SinghK, Spectrum of Cholestatis of infancy. Indian J
gastroenterology 1996; 15: suppl1 A73
5. KaderHH, Balisteri WF.In: Rd Behrmann, RM Kliegman, HB jenson, (Eds): cholestatis from
nelson text of pediatrics.saunders company. (17edition) 2003; 1314-19.
6. 4.Kotb MA,Sheba M, El koofy N,etal.Evaluation of Triangular cord sign in the diagnosis of
billiary atresia.2001;108:416-20.
7. Lai MW, Chang MH.Hsu SC, Cheng TS, kao CL, Lee CY.Differential diagnosis of
extrahepatic billiary atresia from neonatal hepatitis: a prospective study Pediatr
Gastroenterology Nutr 1994; 18:121-217
8. McEvoy CF, SuehyFJ.Billiary tract disease in children.Ped clin north Am1996; 43:75-98
9. Paltiel HJ.Imaging of neonatal cholestatis.semin Ultrasound CT and MRI 1994; 15:290305

60

<!-- page 62 -->

RESOURCES REQUIRED FOR ONE PATIENT / PROCEDURE (PATIENT
WEIGHT 60 KGS)
(Units to be specified for human resources, investigations, drugs
and consumables and equipment. Quantity to also be specified)

Situatio
n
1

Human
resources

Investigations

Drugs &
consumables

Equipment

Pediatrician

Vitamin K

Radiant Warmer

Pediatric Nurse

Antibiotics

Saturation monitor

Radiologist

I.V. Glucose/ Fluids

Basic Lab.

Lab. Technician

I.V. canula

USG

I.v. set

2

Pediatrician with
liver intensivists
Pediatric surgeon
Pediatric
anaesthesists
Radiologists

Higher antibiotics

NICU
Pediatric O.T.
Pathologist for
biopsy
Radiologists
Nuclear medicine

Gastroenterologis
ts
Nuclear medicine

61

<!-- page 63 -->

Urinary tract infection and vesico ureteric reflux

e.
h)

When to suspect and recognise
Introduction

Urinary tract infection (UTI) is a common condition affecting children and vesico
ureteric reflux (VUR) is one common cause of recurrent UTI. UTI in the presence of
infection results in kidney damage and one of the common causes of chronic renal failure
in adult hood . UTI and VUR need prompt recognition to reduce morbidity and
mortality in children.
( B) Case definition.
Vesico ureteric reflux may be primary due to short intramural course of ureters or it may
be secondary to posterior urethral valves, Ureteroceles. Neurogenic bladder
or it may be a part of duplex system of the kidney.

II . Incidence of the condition in our country

The exact incidence in our country is not known But from published data it is the risk of
developing UTI before the age of 14 years is approximately 1% in boys and 3-5% in girls
The incidence varies with age. During the first year of life, the male to female ratio is 35:1. Beyond 1-2 years, there is female preponderance with male to female ratio of 1:10.
The incidence of VUR in children with UTI is approximately 30 to 50 % in the
siblings of the index case shows an incidence of 20 to 30 %.

III . Differential diagnosis of VUR

I.

Obstructive Mega ureters,

II.

Ureteroceles,

III.

Uretral valves,
62

<!-- page 64 -->

IV.

PUJ obstructions

V.

Ureteric stenosis,

VI.

Neurogenic bladder,

VII.

Posterior urethral valves with reflux

VIII. Stones in the bladder and ureter.

IV. Prevention and counselling
VUR is congenital disease either primary or secondary to congenital outlet
obstructions. As such prevention is not possible.
Presence of pelviureteric dilatation on antenatal scans needs evaluation soon after
birth.
However UTI secondary to VUR can be prevented by prophylactic antibiotic
therapy,
Periodical cultures and recognising infective episodes and treating them aggressively.
Mothers must be counselled on the need for long term chemo prophylaxis and have
the urine culture done every febrile episode of the child with VUR. Early recognition
can prevent damage and scarring to the kidney ,
As regards the parents can be counselled that Grade I to III is likely to disappear
spontaneously in most cases within a period of two to three years. However
spontaneous disappearance Gr IV and Gr V is likely to be less but can be given a
chance of Chemo prophylaxis and observation for a period of two to three years.
Break through infections and fresh scars and structural abnormalities will be an
indication for surgical intervention.

V. Optimal diagnostic criteria , investigations treatment and referral criteria.
Situation 1. At secondary hospital / Non metro situation – optimal standards of
treatment in situations where technology and resources are limited.
A. Clinical diagnosis
High degree of suspicion of VUR in all UTI patients.
Febrile episodes with anorexia , vomiting and shivering
63

<!-- page 65 -->

Recurrent fever/ PUO
Recurrent vomiting
Failure to thrive.
Voiding dysfunction and dysuria
b. Investigations
Urine Routine and microscopy
Urine culture and sensitivity (MSSU)
Blood urea and serum creatinine
Ultra sonogram
Micturiting cysto urethrogram if expertise is available
C. Treatment:
If the urine culture is positive
c.

Day care: No role for day-care

d.

Out patient : UTI treated with appropriate oral antibiotics

e.

Inpatient: UTI treated by appropriate

antibiotics intravenously : Sick child

Based on culture and sensitivity report child needs admission . Appropriate antibiotics
are chosen and administered for a period of 7 to 10 days intravenously.
It should be followed by oral chemo prophylaxis till the reflux subsides with periodical
monitoring of the urine culture especially during febrile episodes.
In metro hospitals for the VUR no surgical intervention is done .
Ultrasonogram done shows some structural abnormalities , should be investigated further
with Intravenous urogram and sent to higher centres for intervention.

Referral criteria
11. All cases of UTI who have not been evaluated with MCU should be referred
to higher centre for further evaluation and plan of management.
64

<!-- page 66 -->

12. All patients with VUR should be referred to higher centres for
Radionuclide studies to see the differential renal function and asses the renal
damage.
Lower grades of reflux with recurrent UTI and evidence of development of new scars
and anatomical abnormalities need to be referred to higher centres for management.
( B) All cases of Gr IV and Gr V VUR should be referred to centres doing
major paediatric surgical work as they do not undergo spontaneous resolution and require
surgical or endoscopic management.
.

Situation 2
At super specialty at metro location where higher end technology is available

Investigations.
Routine urine examination and culture and sensitivity
Blood urea creatinine
Ultrasonogram
DMSA scan
IVU in selected cases to exclude upper urinary tract lesions
Bladder function Urodynamics studied in selected cases
Other investigations such as Plasma rennin activity and Genetic studies may be required
in some cases.

Absolute indications for surgery

i.

Anatomic abnormalities of the bladder and VU junction

j.

Unresolving VU reflux

k.

Progressive renal injury

l.

Break through Pyelonephritis inspite of appropriate antibiotic prophylaxis

m. Failure of renal and somatic growth

65

<!-- page 67 -->

n.

Non compliance in medical management of the drug regime

Treatment
Primary treatment
Treatment of UTI with appropriate drug with appropriate dosage and period of time.
Spontaneous resolution for most of the minor VUR and to a small extent Major VUR It
happens over period of time which is usually 3 years.
Children need long term chemoprophylaxis & surveillance ( BP monitoring ), Somatic
growth monitoring , renal function tests , urine analysis and Periodical cultures
Periodical assessment of renal condition with Ultra sonogram and Nuclear scans and
MCU

Surgical treatment:
Type of surgery
Open surgery :- Reimplantation of ureters
Average stay 7 to 10 days
Has a success rate of 98 %
Child may need readmission for removal of stents if used for splinting the reimplanted
ureters

Alternative management
There is a role for alternate procedures in select patients like
1.Circumcision
2. Endoscopic injection therapy

3 Diversion procedures like Ureterostomy and vesicostomy.
Long term management will include surveillance of the child and addressing bladder
dysfunction if present.
Referals
Even in Metro cities there are several levels of care. Surgical and endoscopic procedures
should be done in institutions with proper cystoscopes for different age groups including
66

<!-- page 68 -->

the neonates. C arm facilities and monitors to see the endoscopic procedures are
necessary. Anaesthetist trained in paediatric anaesthesia is essential.

Who does what and timelines
·

Doctor.

·

Paediatric chief surgeon........ Main surgery

·

Assistant surgeon... Assists the surgeon

·

Scrub nurse

·

Theatre technician

·

X- Ray technician to monitor C Arm

·

Ward staff

Further Reading and references
Consensus statement of management of Urinary tract infections
Indian Paediatric nephrology group Ind Paeditrics 2001:38:106-1155
Progress in Paediatric urology Edited bY Minu bajpai. Volume 6
Vesico ureteric reflux

SITUATION

HUMAN RESOURCE

INVESTGATIONS

DRUGS AND
CONSUMABLES

EQUIPMENT

1

Pediatrician, Nurse.,
ultrasonologist
lab
technician

Urinanalysis urine Oral antibiotics
culture ultrasound
blood counts
serum creatinine

Ultrasound
machine basic
laboratory

2

Pediatric surgeon
In addition to (1)
pediatric
fluoroscopy,
nephrologist/pediatricia nuclear medicine
n ultrasonologist,
urodynamics
radiologist, nuclear
medicine specialist ,

Oral antibiotics IV
antibiotics
material for IV
access , material
for radiological
tests. Material for

In addition to (1)
advanced
laboratory,
fluoroscopy faclity
nuclear medicine
facility,
67

<!-- page 69 -->

urodynamics expert

nuclear medicine
tests,

urodynamics
operation theatre

68

<!-- page 70 -->

Neonatal Jaundice-Unconjugated
hyperbilirubinemia

Prepared by:
1.Dr.Swarna Rekha Bhat,
Professor of Pediatrics,
St.John’s Medical College and Hospital
Bangalore.
`

2. Dr. Chandrakala,
Department of Pediatrics,

St.John’s Medical College and Hospital
Bangalore

69

<!-- page 71 -->

NEONATAL JAUNDICE : UNCONJUGATED
HYPERBILIRUBINEMIA
7. When to suspect / Recognize?
f.

Introduction:

Neonatal jaundice is one of the most common neonatal problems. The
most common cause of neonatal jaundice is physiologic jaundice.
Although most newborns with jaundice are otherwise healthy, they need
to be monitored because bilirubin is potentially toxic to central nervous
system, causing bilirubin induced neuronal damage (BIND). Chronic
BIND is also known as kernicterus. Kernictrus leads to permanent
neurodevelopmental handicap. Physiologic jaundice is benign and self
limiting, but pathologic jaundice can cause severe hyperbilirubinemia ,
which if not treated appropriately can result in kernicterus
g.

Case definition : For both situation of care ( mentioned below)

Neonatal jaundice : indicates presence of visible jaundice. Jaundice is
visible in a neonate at bilirubin levels of 5 mg/dl
Neonatal hyperbilirubinemia : bilirubin > 15 mg/dl
Significant hyperbilirubinemia : jaundice requiring treatment (bilirubin
> 17 mg/dl )
Severe hyperbilirubinemia : bilirubin > 20 mg / dl
Extreme hyperbilirubinemia : bilirubin > 25 mg / dl
Acute bilirubin encephalopathy : used to describe acute CNS
manifestation of bilirubin toxicity.
Chronic bilirubin encephalopathy (Kernictrus ): Chronic and
permanent clinical sequelae of bilirubin toxicity
Bilirubin induced neurological dysfunction (BIND): changes
associated with acute bilirubin encephalopathy
Physiological jaundice :
70

<!-- page 72 -->

TERM infants :
o.

Onset on day 2-3 of life

p.

Reaches peak of 12mg/dl on day 4-5

q.

Subsides over 7-10 days

Preterm :
f. Onset on day 2 of life
g. Reaches peak of 15mg/dl on day 6-8
h. Subsides over 10-14 days of life
There is no clear consensus on what is bilirubin cut off for
physiological jaundice. However levels greater than 17 mg% are
unlikely to be due to physiologic jaundice
Pathological jaundice :
8. Onset of jaundice before 24 hours of life
9. Rise in bilirubin of > 0.5 mg/dl/hour
10. Any level of bilirubin that requires phototherapy
11. Signs of underlying illness in an infant with jaundice ( vomiting,

lethargy, poor feeding, excessive weight loss, apnoea, tachypnoea,
temperature instability )
12. Jaundice persisting more than 14 days in a preterm and term infant

13.Direct bilirubin of more than 2mg/dl or more than 15 % of total
serum bilirubin.
8. INCIDENCE OF THE CONDITION IN OUR COUNTRY :
65 -70 % of all neonates have clinical jaundice . Incidence is higher
among preterm neonates as compared to term neonates. Incidence of
neonatal hyper bilirubinemia is 4.3- 6.5 % of all live births ( NNPD
2005 )

71

<!-- page 73 -->

9. Differential diagnosis :
1. The most important aspect is to differentiate neonates with self
limiting physiologic jaundice from those having neonatal
jaundice due to underlying problems ( pathologic jaundice ), as
the latter group can develop severe hyperbilirubinemia which
can result in neuronal damage
2. Neonatal unconjugated hyperbilirubinemia should always be
differentiated from neonatal cholestasis. One should suspect
neonatal cholestasis if any neonate with jaundice has pale
coloured stools and high coloured urine
Causes of indirect hyperbilirubinemia
· Fetomaternal blood group incompatibility – ABO / Rh
· Hemolytic jaundice
· Drug induced – Vitamin K, antimalarials, Oxytocin
· Collection of blood in the extravascular space ( cephalhematoma )
· Polycythemia
· Metabolic and endocrine conditions
Galactosemia, Criggler Najjar syndrome, Hypothyroidism,
hypopituitarism, Tyrosinosis
· Prematurity
· Infant of diabetic mother
· Sepsis
14. PREVENTION & COUNSELLING :

Primary prevention :
1. Screening for isoimmunisation:

All pregnant women should be tested for ABO/ Rh (D) typing
72

<!-- page 74 -->

All neonates born to O blood group and Rh negative mothers should have a
cord blood sample taken for blood grouping, typing and Coombs test ( DCT
)
2. Preventing hyperbilirubinemia :

Having hospital policies for detection for jaundice in newborn
i)

Protocols for assessment of jaundice at 12 hrly interval

j)

Identifying the babies at risk of developing hyperbilirubinemia

k)

Ensuring successful breast feeding

***Babies at risk for developing hyperbilirubinemia are;
Major:
IX. Predischarge TSB ( total serum bilirubin ) in high risk zone
X. Jaundice within first 24 hours
XI. Blood group incompatibility with positive DCT
XII.

All preterm babies

XIII.

Previous sibling received photo therapy

XIV.

Cephalhematoma or significant bruising

XV.

Exclusive breast feeding , if nursing is not going on well and
weight loss is excessive (greater >10%)

Minor:

XVI.

Predischarge TSB in the high intermediate risk zone

XVII. Gestational age 37-38 weeks
XVIII. Macrosomic infant of a diabetic mother
73

<!-- page 75 -->

XIX.

Maternal age >25 yrs

XX.

Male gender

Counselling parents :
a. It is essential to make sure that the parents are informed

about newborn jaundice.
b. Early discharge (<48 hours) is one of the reasons for

missing neonates with hyperbilirubinemia ( as breast
feeding is not yet established and jaundice usually peaks
at about 3 to 5 days )
c. It is preferable to keep the mother and baby pair in the

hospital at least for a period of 48 hours even for normal
deliveries
d. Those with major risk factors*** should definitely not be

discharged early (preferably observed for 72 hours)
e. If

for any reason early discharge is planned, a predischarge bilirubin should be done and treatment
planned as per the bilirubin nomogram ( appendix 1) and
frequent follow up is essential

15. Optimal diagnostic criteria: Investigations, treatment and referral

criteria
Situation 1: At secondary hospital / Non Metro situation:
Optimal standards of treatment in situation where technology
and resources are limited
A ) Clinical criteria:
Identify any risk factors in mother and baby
Clinical assessment using Kramer’s criteria
74

<!-- page 76 -->

Non invasive measurememt of jaundice if available – transcutaneous
bilirubinometer
· Lab measurement of bilirubin :
Total serum bilirubin (TSB) and Direct bilirubin (daily)
More frequent bilirubin assessment ( 8-12 hrly) if hemolytic jaundice
is suspected
Blood grouping/typing (ABO/Rh ) of all mothers and neonates born
to mothers with Rh negative and O positive mothers
Coomb’s test if mother is Rh negative or O positive
Complete hemogram including Peripheral smear , Reticulocyte count
if hemolytic jaundice is suspected or neonate requires phototherapy
Jaundice present beyond 2 weeks or sick infants need further
evaluation

C) Treatment:
No role of outpatient or day care treatment
If a neonate is referred from outside, neonate needs to be assessed for
level of jaundice and assessment of risk factors needs to be done***
The following will need to be admitted and bilirubin estimation
should be done
· Any term neonate having clinical jaundice till lower abdomen
and beyond
· Any preterm neonate having jaundice
· Any neonate having jaundice in the first 24 hrs
· Any neonate having jaundice beyond 2 weeks or has pale
coloured stools
75

<!-- page 77 -->

INPATIENT TREATMENT
1. AAP guide lines for management of hyperbilirubinemia in baby >_35
weeks (Appendix 2)
The bilirubin level is estimated and plotted on the chart based
on age of the baby. Decision is taken depending on which part of
the graph the value falls
§ In addition to providing phototherapy for those who
require the following policy needs to be practiced for all
intramural neonates
§ Promote & support successful breast feeding
§ Establish nursery protocols for identification and
evaluation of hyperbilirubinemia
§ Assess all neonates for presence of risk factors
§ Only visual estimation of degree of jaundice can lead to
errors in darkly pigmented infants, therefore frequent
bilirubin estimations will have to be done
§ Perform systemic assessment on all infants prior to
discharge for the risk of hyperbilirubinemia
§ Do a serum bilirubin for infants discharged before 48
hours
§ Interpret all babies bilirubin levels according to infant
age, in hour specific nomogram
§ Provide appropriate follow up based on the time of
discharge and risk assessment.
§ Treat newborn when indicated with phototherapy/
exchange transfusion

76

<!-- page 78 -->

Phototherapy
Indications for phototherapy in neonates above 35 weeks is based on
the chart provided ( appendix 2)
Indications in preterm babies
In preterm neonates < 35 weeks there are no charts
Guidelines for phototherapy in thus group is as follows
< 1000gms

? prophylactic phototherapy

1000 to 1500 gms

7 to 9 mg%

1500 – 2000gms

10 to 12 mg%

2000 – 2500gms

13 – 15 mg%

Duration of phototherapy : to be given till the bilirubin value reaches
safe level as per chart. It is advisable to keep the neonate in hospital
for a period of 12 to 24 hrs or repeat a bilirubin value 12 to 24 hrs
after stopping phototherapy as rebound hyperbilirubinemia can
occur, particularly in neonates with hemolytic jaundice
Types of light: Single or double surface phototherapy .
A combination of special blue (TL20) lights and white lights
Do not use white lights covered with blue paper as they are
ineffective
IT IS IMPORTANT TO CHANGE LIGHTS AFTER EVERY 1000
HOURS OF USE
EXCHANGE TRANSFUSION CAN BE DONE AT A
SECONDARY LEVEL ONLY IF EXPERTISE IS AVAILABLE
If expertise is not available early referral of high risk neonates is
recommended
· Referral criteria: Early referral
· Presence of major risk factors (Rh/ABO)
77

<!-- page 79 -->

· Onset of jaundice within 24 hours
· Rapid rise of bilirubin in spite of phototherapy
· TSB is nearing Exchange transfusion range
· Associated other morbidity

Situation 2
Tertiary centre
a) Clinical diagnosis :
Same as Explained
c) Investigation :
Non invasive mode of detection of jaundic
Transcutaneous bilirubinometry
These instruments gives fairly accurate estimates of TSB in term/near
term, values within 2-3mg/dl
They have been considered as a predischarge screening tool to
identify at risk infants
Lab investigation :
As above
Additional investigations
· G6PD
· T3 T4 TSH
· Bilirubin monitoring 6-8 hourly in neonates with hemolytic
jaundice or 12 to 24 hrly in other neonates
Treatment :

78

<!-- page 80 -->

Phototherapy : started when the bilirubin value crosses the
percentile charts. Appendix 2
The lights which can be used for the treatment are:
Special blue light ( TL 20) (acceptable range for flux should be 8-10 microwatts/cm2 /nm and
for intensive photo therapy ; >30 microwatts/cm2 /nm
Fiberoptic ( bili blanket)
LED ( light emitting diode)
Exchange transfusion
Is indicated if bilirubin rises beyond recommended levels as per chart
Appendix 3
It is indicated at earlier levels in preterm neonates and neonates with
immune hemolysis
Guideline for preterms
< 1000gms

10 to 12 mg %

1000 to 1500 gms

12 to 15 mg%

1500 – 2000gms

15 to 18 mg%

2000 – 2500gms

18 to 20 mg%

Rh or ABO immune hemolysis
Bilirubin values of 10 mg% within 24 hrs of age
15 mg% between 24 to 48 hours of age
In all other situations - as per chart ( appendix 3 )

Other pharmacological treatment ;

79
