---
doc_id: "9a24a82fcaadbdc3"
source_url: "https://tgic.telangana.gov.in/Downloads/Instructions/51_218_13092017.pdf"
ministry: "Information Commission, Telangana"
title: "218_13092017.pdf"
date: ""
pages: 1
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "968f763a66268417"
---

<!-- page 1 -->

ZL
Be GOVERNMENT OF TELANGANA
S) ABSTRACT
RTI Act 2005 (Central Act 22 of 2005) - Constitution of Telangana State
Information Commisslon- Orders - Issued.
GENERAL ADMINISTRATION (GPM&AR) DEPARTMENT
G.O.Ms.No. 218 Dated: 13-09-2017
వనన
ORDER:
The following notification shall be published In the extraordinary Issue of
Telangana Gazette.
NOTIFICATION
In exercise of the powers conferred by sub-section (1) of section 15 of RTI
Act 2005 (Central Act 22 of 2005), Government of Telangana hereby constitute
Telangana State Information Commission to exercise the powers conferred on and
to perform the functions assigned to it under the Act.
Under sub section (7) of section 15 of the Act, Government hereby further
notify that the Commission shall function in the following premises:
“Samachara Hakku Bhavan,
D.No. 5-4-399, Housing Board Building,
Mozam-jahi-Market, Hyderabad - 500 001.”
(BY ORDER AND IN THE NAME OF THE GOVERNOR OF TELANGANA)
S.P.SINGH
CHIEF SECRETARY TO GOVERNMENT
To
The Commissioner of Printing, Stationers & Stores Purchase, TS,
Chanchalguda, Hyderabad. (to cause publication of the above notification
in the 7.5. extraordinary Gazette and to furnish 1000 copies to this
Department)
All Departments of Secretariat, Hyderabad.
All Heads of Departments.
All District Collectors of Telangana.
The Commissioner, I&PR, Department.
The A.G.Office, Hyderabad.
The DTA, Telangana.
The PAO, TS, Hyderabad.
The Resident Commissioner, Telangana Bhavan, New Delhl.
Copy to:
The P.S.to Prl.Secretary to Chief Minister.
The P.S.to Minister (I&PR), Telangana.
The P.S.to Minister (Finance), Telangana.
The P.S.to Chlef Secretary to Government, Telangana.
The P.S.to Pri Secretary to Govt.,(Poll)
The P.S.to Pri Secretary to Govt.,(GPM&AR)
The Law Department.
The Publicity Cell, Secretariat, Hyderabad.
// FORWARDED :: BY ORDER //
SECTION OFFICER H
