---
doc_id: "6c4c0da9f5acbb41"
source_url: "https://cybpms.telangana.gov.in/static/assetss/doc/Instructions.pdf"
ministry: "Cyberabad Police Permission Management System"
title: "Instructions to Submit Event Permission Application"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7a6be2dddd5acd4c"
---

<!-- page 1 -->

INSTRUCTIONS TO SUBMIT EVENT PERMISSION APPLICATION
The Event Organizers are requested to submit event permission applications to
the following permission issuing authority Officers based on the category of
event.
S.No.

1

2

3

4
5

Type of Event
Commercial/Ticketed Programs (i.e. 1.Live
Shows, 2.Concerts, 3.Musical Events, 4.PreRelease Events, 5.Audio Function, 6.
Success Meet, 7.Exhibitions, 8.New Year
Events, 9.Cultural Events, and 10. Similar
ticketed programs)
Non-Commercial/Non-Ticketed
Programs
for
above
500
Members
(like
1.School/College
Events,
2.Company
Annual
Events,
3.Conferences,
4.Symposiums)
Non-Commercial/Non-Ticketed
Programs
(like Furniture, Textile & Jewellery etc.,
Exhibitions/Fairs/Displays, and Similar Nonticketed programs)
Marathon/Walks/Runs etc., up to 1000
Members (Within Zone)
Marathon/Walks/Runs etc., for above 1000
Members.

6

Marathon/Walks/Runs etc., (Multi Zone)

7

Film Shootings (On Roads) (Within Zone)

8

Film Shootings (On Roads) (Multi Zone)

9
10
11
12

Film Shootings (Except On Roads)
License to supply Loudspeakers
License to use Loudspeakers
Political Meetings/Protests/Dharnas etc.,
Political or Religious Rallies/Processions
(Within Division)
Political or Religious Rallies/Processions
(Multi Division)
Political or Religious Rallies/Processions
(Multi Zone)

13
14
15

Permission Issuing
Authority

Commissioner of Police,
Cyberabad

DCsP (L&O), Cyberabad

DCsP (L&O), Cyberabad
DCsP (Traffic),
Cyberabad
Jt.CP (Traffic),
Cyberabad
Jt.CP (Traffic),
Cyberabad
DCsP (Traffic),
Cyberabad
Jt.CP (Traffic),
Cyberabad
DCsP (L&O), Cyberabad
DCsP (L&O), Cyberabad
ACsP (L&O)
ACsP (L&O)
ACsP (L&O)
DCsP (L&O)
CP, Cyberabad

 S.No.01 to 11 permissions will be issued in Online (Cyberabad Police
Permission Management System (CPPMS)) portal only.
 Application for Commercial/Ticketed Programs Should be submitted prior
to (14) days, whereas for other events Prior to (10) days of the event.
