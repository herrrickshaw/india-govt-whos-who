---
doc_id: "cc8d00cb8f7b7b8f"
source_url: "https://invest.telangana.gov.in/wp-content/themes/investtelangana-theme/assets/docs/policies/telangana-msme-policy-2024.pdf"
ministry: "Invest Telangana"
title: "Micro, Small & Medium Enterprises   Telangana MSME Policy     2024   PDF · 21.8 MB     View the document"
date: ""
pages: 36
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "ed9dc9ad7ef19b31"
---

<!-- page 1 -->

: (శ్ర | : ఘా మ్‌.
నం. My .
టో
. Oy
Se ~=6Telangana
ల MSME Polic
వ y
me 2024
rey
ae కాల!
/
|
య శక SS /
: ;
“oN fof
“aaa
: ae med —o- ॥ l= కి
Unlocking growth for Micro, Small and Medium Enterprises

<!-- page 2 -->

॥] | |
EL) \
అ క ====డే! | ee స్తో వ

<!-- page 3 -->

Executive Summary: Telangana Government for MSMEs growth 4
MSMEs in Telangana: An Overview 5
Committed support - Targets consolidation 10
Telangana’s MSME sector: The challenges 12
Access to land 12
Access to funds 13
Access to raw material 14
Access to labour 15
Access to technology 16
Access to markets 17
Telangana’s roadmap for MSMEs 18
Increasing the availability of accessible and affordable land 18
Greater access to finance 20
Ensuring easy access to raw materials 22
Improving flexibility in labour markets 24
Encouraging adoption of technology 26
Improving access to markets 2/7
From ideation to action: Assured Institutional support 29
Governance structures to monitor delivery 31
Conclusion 32
= a mo —- il S==== QJ తి

<!-- page 4 -->

Sri Anumula Revanth Reddy
Hon'ble Chief Minister of Telangana

Telangana has been an important industrial hub since the decade of 1950s onwards. Because of the policy
of the then national government to setup large public sector undertakings in different parts of the country,
the region of Hyderabad was also given important industries such as BHEL, IDPL, HMT, etc. In later
decades, many defence PSUs also got established here like BDL, Ordnance Factory, MIDHANI, etc. Due to
the presence of these public sector units, a large number of MSMEs emerged in the surrounding areas.
Since then, the region of Hyderabad and few other pockets in Telangana like Warangal, Karimnagar,
Khammam, Nizamabad, Ramagundam etc. saw a steady development of MSME clusters
While the performance of Telangana based MSMEs was very striking in the decades of 80s, 90s, 2000s, in
the last 15-20 years, we have seen many other states outperforming and relegating Telangana to an
average performer status
When the new state of Telangana was created in 2014, itwas expected that the government will focus on the
rapid development of all the sectors. Unfortunately, this was not seen in practice in the case of MSMEs.
While an industrial policy called TS-iPASS was introduced in 2014, it did not have anything specific to offer to
the MSMEs. Most of the benefits of this policy were enjoyed by large and mega companies.
Itis universally seen that MSMEs have tremendous potential to contribute significantly to the economy and
employment, if a proper policy and infrastructure support is provided. Our government's main objective is
to expand industrial development to rural Telangana also. To ensure this Telangana will be divided into three
clusters. An Urban Cluster will be developed within the Hyderabad Outer Ring Road (ORR), Semi Urban
Cluster between the ORR and the Regional Ring Road (RRR) and Rural cluster will be developed in the
surrounding area after the Regional Ring Road. These clusters will help to encourage the establishment of
industries and MSMEs will play a vital role in this growth.
lam happy that the new government in Telangana is introducing a dedicated policy for MSMEs, which also
happens to be one of the earliest policy reforms that we are introducing. Apart from setting right some of the
imbalances that the MSMEs have been facing in the last decade or so, this policy also provides some novel
initiatives which will help our MSMEs become world-class performers.
| expect the MSMEs based in Telangana to make full use of this opportunity which is provided by the
government. | also commend the Industries and Commerce Department for creating a focused
implementation mechanism to ensure that whatever is promised in the Policy gets delivered in totality on the
ground
| wish everyone all the very best.

O ANUMULA REVANTH REDDY

<!-- page 5 -->

[షా నె ti
| A ae { న్‌
. ఆయ”
Sri Duddilla Sridhar Babu
The Hon'ble Minister for Information Technology,
Electronics & Communications; Industries & Commerce and Legislative Affairs
Micro, Small and Medium Enterprises (MSMEs) are a vital part of Telangana’s economy. They encompass
manufacturing, services as well as retail and trading sectors. MSMEs have been an inseparable part of the
supply chains of large PSUs and multinational companies. Although the MSME sectors vibrancy has
supported development of our IT/ITES, Pharma, defence, textiles, food processing and other similar
verticals, the fact remains that MSME sector is also the most vulnerable due to its small size and low
financial resilience. Keeping in view their unique requirements, we have designed the first MSME Policy for
Telangana.
The MSME Policy framework hasidentified current challenges faced by MSMEs in access to land, finance,
raw materials, labour, technology, and markets in consultation with the local Industry stakeholders.
Innovative solutions have been identified for addressing each of these issues either through fiscal or non-
fiscal measures. The policy has focused on supporting MSMEs through their entire lifecycle right from the
set-up phase to growth and expansion. We also ensured that the development reaches all parts of the State
and marginalized sections like SC/ST community and women entrepreneurs. A new governance structure
is also being proposed under the policy to take swift and suitable action on all issues being faced by
MSMEs.
The industrial sector in Telangana needs to embrace Industry 4.0 for staying relevant and globally
competitive. This policy through a Rs. 100 Crore Yantram fund will help MSMEs make that transition from
old-age technology to new-age. We will develop industrial parks across all the districts in Telangana for a
uniform industrial growth in the state and also develop dedicated parks for MSMEs, women entrepreneurs
and innovative start-ups. Government will develop flatted factories with in-built facilities for women
entrepreneurs across all the 119 constituencies in state and encourage women members of SHGs to
transition to MSMEs. The various policy measures are a step in the right direction to ensure that the
untapped potential of MSMEs is properly harnessed and their resources are utilized for creating wealth for
industry as well as the State.
| congratulate the Industries and Commerce department officials for their efforts in conducting various
consultation sessions and developing a wholistic policy document. | urge them to conduct awareness
sessions among all Industries associations so that the policy benefits reach the target audience.| thank
Prosperiti group for their expert guidance and untiring support during the policy development process
lam sure this policy will unlock the growth potential of our industrial sector, create more employment for the
youth and increase productivity among MSMEs.
శీ
({DUDDILLA SRIDHAR BABU)

<!-- page 6 -->

Executive Summary:
Telangana Government for MSMEs growth
MSME sector in Telangana is highly resilient & has shown significant growth.
Since 2014, MSMEs in Telangana have shown a positive trend of formalisation as annual
registrations on the TG-iPASS portal have increased by 11-15% annually. MSMEs have seen a
rise in average investment from Rs 1 crore in 2018 to Rs 2.15 crore in 2022. An highly
encouraging social and gender diversity among MSME owners is visible in Telangana
compared to other states.
The Government is Committed to engendering inclusive and sustainable
growth for the MSMEs in Telangana:
The MSME policy is designed to achieve: inclusive and diverse employment, equitable growth,
scale-based graduation, technology upgradation, and improved productivity. Through this
policy, the government has set out to achieve specific outcomes, along with outlining indicators
to measure progress. The government hopes to develop inclusive businesses that create
opportunities for all regardless of identity, integrate technology to usher in the era of ‘Industry
4.0’, and unlock growth for the MSME ecosystem in the state.
Six thrust areas for improvement:
To accelerate the growth of MSMEs, the Government has identified six thrust areas for
improvement - Improving availability, accessibility, and affordability of land; Facilitating access
to finance; Ensuring easy access to raw materials; Improving flexibility in labour markets;
Encouraging adoption of technology; and Enhancing access to markets.
End-to-end support from the Startup to Sales:
The policy envisages 40 measures to offer end-to-end support from the Startup to Sales phase.
It is proposed to enhance state infrastructure through dedicated MSME parks and private
flatted factories, offer fiscal support especially to SC/ST and women-owned MSMEs by
increasing the incentives offered under other industrial policies, improve access to traditional
and alternative sources of credit, develop best-in-class testing centres and warehousing
facilities in the state, expand the pool of skilled workforce, earmark a special fund for
technology transfer and modernisation in the MSME sector, enhance market access by
incentivising local procurement and increased e-commerce participation, and improve ease of
doing business in the state.
Effective Implemenatation and Monitoring Mechanism:
To ensure effective and efficient implementation of the policy, the government has developed
implementation and monitoring mechanisms. The government proposes to establish an
MSME wing to provide 24*7 dedicated support to MSMEs in the state. A high-level steering
committee will be established under the state leadership to monitor delivery on commitments
and set policy direction. The government has earmarked Rs. 600 crores over the next five years
to support these initiatives for MSMEs.
A
తి జ జ |
A 2222వ =

<!-- page 7 -->

MSMEs in Telangana: An overview ను.
Number of MSMEs operating and registered in Telangana
Survey Nature of enterprises Micro Small | Medium Total
National Sample Survey | Manufacturing, services, 25,94,000} 10,000 1,000 | 26,05,000
retail, wholesale
Udyam Registration Manufacturing, services, 8,64,202 | 26,560 3,028 8,93,790
retail, wholesale
GoTG, 2023 Manufacturing, services 34,953] 18,394 54,758
TG-iPass registration Manufacturing, services 15,434] 6,106 | 666 | 22,206
+ In 2015, the National Sample Survey estimated 26 lakh MSMEs to be operational in Telangana:
About 8.9 lakh MSMEs have received Udyam registration since 2020. Around 22,000 approvals for
new MSMEs have been issued under the TG-iPASS regulation since 2014.
+ Telangana has registered nearly 9 lakh MSMEs on the Udyam portal. 0.33% of these registered
industries are medium enterprises.
+ Annual registration of new MSME units on the TG-iPASS portal has risen by 11-15% annually from
FY 2014 to FY 2023.
von
జ
న్‌
TP... a Se fl | el తి
= [న్న ౧]

<!-- page 8 -->

Number of MSMEs registered in each financial year
4,000 3,974
3,309
ra 2,869 3,061
3,000
=” 2,587 2,606 2,622
ల
=
3
@ 2000 1,606
@ 1,343
>
2
5 1,000
8
క 151 175
>
2 0
Fe & మ న SF F FC YF LF
v 7 v v v v Vv v 7 v v
క OE న a A
SPF KSK KK K KK S
MSMEs on the TG-iPASS received an average investment of Rs 1 crore in 2018. This investment
rose to an average of Rs 2.15 crores in 2022.
Investment received by industries in Telangana
© Micro industries త Small industries @ Medium industries
44,000.00
Ps.
| ౩00000 f ల
౫ et an
= 200000 ae ie
క్ష ae
0.01
2018-19 2019-20 2020-21 2021-22 2028-23,
(| ౯9
im శే
క ! ee = IS

<!-- page 9 -->

The concentration of MSME’s around the State Capital
State Capital and MSMEs in select Total MSMEs in %Share of MSMEs
adjoining districts | districts the state in select districts
Hyderabad
Telangana | Ranga Reddy 3,58,563 8,93,790 40
Medchal-Malkajgiri
+ According to data from Udyam registrations, 40% of MSMEs in Telangana are situated in and
around the capital district.
+ A 2023 survey by the Government of Telangana showed that ~25,000 manufacturing and services-
based MSMEs operated out of Medchal-Malkajgiri, Sangareddy and Rangareddy districts
గ్‌
గర్వ
x
వం
క్వ
x
= రం
స్త
= bY
= va
=a
ey
=a =o
—
—_—_— = eS oo =>
న్‌
TP... a Se fl | el 7)
= [న్న ౧]

<!-- page 10 -->

Major contributors of employment in Telangana state i
Number of workers
Sector Micro Small Medium Total
industries industries industries
సం. 209793 | 93900 | 267.965
Mineral based and 4,08,110 26,837 9,379 4,44,326
wood-based Industries
Health & Life Sciences 1,42,209 38,605 2,15,199
Electronics & IT Hardware 8,122 87,868
Waste Management 23,804 1,631 598 26,033
and Green Technologies
According to an internal survey, services in Telangana account for nearly 33 lakh jobs, surpassing the
employment generated by the next six highest sectors combined
hy క్‌ ౧7
vi | శ a @ ని!
భ్‌ P కళ
( hy
, ప § ఏఈ
ఆజ ఉత ఆఆ
ise ,
ఆ 4
