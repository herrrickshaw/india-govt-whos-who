---
doc_id: "ad50aabeef59e18b"
source_url: "https://cdn.s3waas.gov.in/s36c524f9d5d7027454a783c841250ba71/uploads/2025/11/17619909307258.pdf"
ministry: "Hyderabad"
title: "Gazette05 (2 MB)"
date: ""
pages: 2
method: "tesseract:tel+eng"
script: "TELUGU"
needs_ocr: false
sha1: "a2159f2f5188e63c"
---

<!-- page 1 -->

THE HYDERABAD DISTRICT GAZETTE
EXTRAORDINARY
PUBLISHED BY AUTHORITY
cA ee
Gazette No.05 HYDERABAD THURSDAY, OCTOBER 16, 2025
NOTIFICATION BY COLLECTOR
a ae
REVENUE DEPARTMENT

OFFICE OF THE SPECIAL DEPUTY COLLECTOR,

LAND ACQUISITION (GENERAL), HYDERABAD.
CONSTRUCTION OF ELEVATED CORRIDOR FROM PARADISE JUNCTION TO
SHAMIRPET AT ORR JUNCTION ON RAJEEV RAHADAARI (SH-01) — LAND
ACQUISITION IN THE VILLAGES OF KAKAGUDA, TIIOKATTA OF
TIRUMALGHERRY MANDAL OF HYDERABAD DISTRICT - PRELIMINARY
NOTIFICATION IN FORM VI (UNDER SECTION 11 (1) OF THE ACT, 30 OF 2013
READ WITH SUB RULE (1) OF RULE 19).

FORM NO.VI
[Under Section 11 (1) of the Act, 30 of 2013 read with Sub Rule (1) of Rule(19)]
NOTIFICATION

No.B2/36/2024 Dated: 16.10.2025

In exercise of the powers conferred U/s 19(7) of Right to Fair
Compensation and Transparency in Land Acquisition, Rehabilitation and
Resettlement Act, 30 of 2013, the validity of the Preliminary Notification issued
as per the Section 11(1) vide Gazetle No.10, Dated: 25.11.2024 is hereby
extended tor the period of Twelve months w.e.f., 26-11-2025 to 25-11-2026.

District Col

Place: Hyderabad istrict Collector,
Date: 164 0.2025 Hyderabad District.

<!-- page 2 -->

{EES
హైదరాబాద్‌ జిల్లా గెజిట్‌
విశేష పత్రము
గెజిట్‌ 30.05 హైదరాబాద్‌ గురువారం, అక్టోబర్‌ 16, 2025
Ee
కలెక్టర్‌ ద్వారా నోటిఫికేషన్‌
* * ట్ల
రెవెన్యూ విభాగం
స్పెషల్‌ డిప్యూటీ కలెక్టర్‌ కార్యాలయం,
భూసేకరణ (సాధారణ), హైదరాబాద్‌.
హైదరాబాద్‌ జిల్లా తిరుమలగిరి మండలం కాకగూడ, తోకట్ట గ్రామాలలో భూసేకరణ - రాజీవ్‌
ట
రహదారి (SH-01) పై ప్యారడైజ్‌ జంక్షన్‌ నుండి షామీర్‌పేట ORR జంక్షన్‌ వరకు ఎలివేటెడ్‌
కారిడార్‌ నిర్మాణం - ఫారం VI లో ప్రాథమిక నోటిఫికేషన్‌ (30/2013 చట్టంలోని సెక్షన్‌ 11 (1)
కింద, నియమము 19లోని ఉప నియమము (1) తో చదవండి).
ఫారం నెం./!
[30/2013 చట్టంలోని సెక్షన్‌ 11 (1) కింద, నియమము 19లోని ఉప నియమము (1) తో చదవండి]
నోటిఫికేషన్‌
నెం. బి2/36/2024 తేదీ: 16.10.2025
భూసేకరణ, పునరావాసం మరియు పునరావాసంలో న్యాయమైన పరిహారం మరియు
పారదర్శకత హక్కు చట్టం, 30/2013 యొక్క సెక్షన్‌ 19(7) ద్వారా ఇవ్వబడిన అధికారాలను
వినియోగించుకుంటూ, 30/2013 చట్టంలోని సెక్షన్‌ 11(1) ప్రకటన ద్వార ఇవ్వబడిన ప్రాథమిక
నోటిఫికేషన్‌ గెజిట్‌ నెం.10, తేదీ: 25.11.2024 ప్రచురణ గడువును 26-11-2025 నుండి 25-
11-2026 వరకు పన్నెండు నలల పాటు పొడిగిస్తున్నాము.
సం/ 7 ర్‌
స్తలం: హైదరాబాద్‌, జిల్లా కలెక్టర్‌,
తీద: 16.10.2025. హైదరాబాద్‌'జిల్లా.
