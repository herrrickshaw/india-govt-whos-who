---
doc_id: "25bceacd290dcd1b"
source_url: "https://bse.telangana.gov.in/pdf/HM_Instructions2017.pdf"
ministry: "Directorate of Government Examinations, Telangana"
title: "HM instructions of march 2017"
date: ""
pages: 11
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "8cd8f37df413ce77"
---

<!-- page 1 -->

GOVERNMENT OF TELANGANA
From: To
Dr. R. Surender Reddy, All the Heads of High Schools
M.Sc., Ph.D., M.Ed., presenting the pupils for
Director of Government Examinations, 5.5.0 Public Examinations,
Telangana State :: Hyderabad. March, 2017 in the State.
Re.No. 150/B~2/2016 dated:03-10-2016
Sir / Madam,

Sub:- S.S.C., O.S.S.C., and 5.5.0 (Vocational Course) Public Examinations, March- 2017
and onwards — Important instructions for the preparation of Nominal Rolls of the
candidates and submission to the District Educational Officers concerned for onward
submission to the Office of the Director of Government Examinations, T.S., Hyderabad
— Issued — Reg.

Ref:- _ 1)This office instructions on Re No.150/B-2/2014, Dt: 18 -09-2014.

2) GO Ms.No.17, School Education (PE-Program-Il) Dept., and Dated 14.05.2014.
3) G.O.MS.No.2, School Education (PROG.II) Dept., Dated.26.08.2014.

4 4) G.O.Ms.No. 10, School Education (PROG. I!) Department, dated 26-11-2014.
5) G.O.Ms.No.06 School Education (PROG. I) Department, dated: 17.02.2016.

It is hereby informed to all the Heads of High Schools in the State presenting Regular / Private
(Once failed in New Syllabus) / OSSC and Vocational Candidates for SSC Public Examinations,
March- 2017, the collection of online data of the candidates is continued for this year to avoid
mistakes. Separate guidelines will be kept in Website and will be intimated later on.

The following are the instructions for the preparation of Nominal Rolls in respect of Regular /
Private Once failed Candidates appearing for the S.S.C / O.S.S.C and 5.5.0. Vocational Course
Public Examinations, March- 2017.

It has been observed in the previous years that the Headmasters of certain Schools
have submitted MNRs after 1 to 3 Months 1.6. after the actual date of remittance of exam fee
paid by them. In all such cases late fee was collected as applicable on the date of submission

= of Manuscript Nominal Rolls in addition to initiating disciplinary action against the Headmaster
{ Management.

The due dates now fixed for submission of Manuscript Nominal Rolls and remittance of
examination fees must be followed without any delay and deviation scrupulously. Mere
payment_of examination fees _will_not_exempt from payment of late fee if they submit
Manuscript Nominal Rolls (MNRs) along with Challan in the office of the District Educational
Officer concerned after due dates. After expiration of due dates they will not be taken in the
Office of the District Educational Officer concerned and the Headmaster / Management will
have to face consequences and will be held personally responsible for the students from
whom they have collected fees.

From SSC public Examinations March 2017, There is no need to submit ICR cum OMR
forms along with MNR. The Head Master should furnish MNR data through Online within the
prescribed schedule dates, besides submitting MNR, Challan etc. duly obtaining counter
signature of the Dy. Educational Officer concerned. through the District Educational Officer.

ల Without uploading the data of the students through online to this Office the MNRs will not be
accepted.

<!-- page 2 -->

నామ్‌
|. CATEGORIES OF CANDIDATES:
a) GENERAL STREAM OF SSC:
There are two categories of candidates appearing for SSC Public Examinations, March- 2017

4. Regular candidates: Students presently studying X class in Government, Zill Parishad,
Recognised Private Aided, Recognised Unaided and T.S. Residential, T.S.SW Residential,
T.S.TW Residential, KGBV Schools MJPTSBCWR Schools and TS Model Schools and
other recognized schools.

2. Private (Once Failed) Candidates: Failed in SSC March and ASE June - 2016 and the
Candidates failed SSC March & June 2015 Examinations (New Syllabus candidates only)

Note: a) As per the Govt Memo no. 5073/Prog.II/A1/2015, School Education (Prog.ll) Dept,
dt.24-11-2015. Government has informed that, no further permission is granted to the
once failed Candidates under the Old syllabus to reappear SSC Examinations. Under
any circumstances Old syllabus students are not allowed. If any deviations the Head
Master will be personally held responsible and action will be initiated on concerned as
per Act 25/97.

b) As per the G.O.Ms.No.2 School Education department dated 26.08.2014., The
existing facility of Students appearing for SSC Public Examinations Without School
Study is be dispensed with from March 2015 onwards. Such Students can appear for X
Class through other alternating systems like National or State Open School systems.

c) Old syllabus failed candidates can appear for Tenth Class Examinations through
Open Schools society.

b) SPECIAL STREAMS OSSC:

4. Regular candidates studying X class (OSSC) in OSSC Schools.

2. Private Once failed candidates. (New Syllabus candidates only).

3. As per the G.O.Ms.No. 6. School Education Department dated 17-02-2016 all the
Composite courses being in vogue is restore the Composite Language Courses i.e.,
a) Telugu and Sanskrit (03T/04S, 80 Marks for Telugu and 20 Marks for Sanskrit).
b) Arabic/Persian (03U/05A 80 Marks for Urdu and 20 Marks for Arabic/Persian),
0) Marathi and Hindi (03M/08H 80 Marks for Marathi and 20 Marks for Hindi) from the
Academic year 2016-2017.

C) SSC VOCATIONAL COURSE:

1. Students who opted SSC of general stream and vocational course appearing for vocational
subjects for March-2017.
2. Private candidates once failed in vocational subjects.
2.PREPARATION OF NOMINAL ROLLS:

4. Read the instructions carefully before filling the columns prescribed there in.

2. Preparation of Nominal Rolls should be entrusted to Junior Assistant or a Teacher who is
familiar with the preparation of Nominal Rolls and dealing with examination work to avoid
mistakes. Utmost care should be taken while writing the candidates Name, Father's name,
Mother’s name, Date of Birth, Community Code and AADHAR Number of the candidates etc

2

<!-- page 3 -->

Note: Special care shall be taken while writing in the MNRs Particulars of the following:

a. First write Surname followed by the remaining name of the candidate (In Block letters).
If needed it should be abbreviated to fit within 42 characters only.

b. Leave a space between surname and the remaining name of the candidate

6. Father's Name and Mother's Name by Abbreviating to fit in 42 characters in Block
letters in MNR.

d. Govt. have issued Memo vide No.7679/PE-Ser-II/A2/2010., dt:14-09-2010 to
incorporate Mother's name in the SSC Pass Certificate in additional to the father’s
name from March 2011 examinations onwards. Therefore before entering the
Mother’s Name in the MNR, the Headmaster has to take a declaration from the
parent concerned, duly entering the same in the school admission register.

e. All once failed private candidates (New syllabus) shall be insisted to mention the Roll
number of the previous appearance i.e., June 2016 in MNR as well and their latest
original failed memorandum of marks shall be enclosed to the MNR. However provision
is provided in the MNR to write old Roll Number, Month & Year for other than June
2016 candidates.

f. Challans, Failed Memos, Recognition Orders, Medical certificates issued in respect of
PH candidates, figure statements etc should be attached and packed with MNR only
and they shall not be mixed up with other papers.

g. The Headmaster of all the recognized schools should obtain one photocopy / Xerox of
relevant documents and preserved the photo copies / Xerox copies duly attested by
him as permanent record along with MNR and respect of both Regular and Private
(Once failed) students. This will help the administration in sorting out future
complications if any.

3. The Nominal Rolls shall be prepared separately in respect of :

1 Regular Candidates and Private Once failed candidates (New Syllabus candidates only)
2. Nominal Rolls in respect of (a) Regular Candidates,

(b) Private Once failed candidates, other than S.S.C Advanced Supplementary

Examinations, June -2016 shall be prepared SEPARATELY. The particulars of the

candidates uploaded through online and furnished in the Nominal Rolls shall be in the

same_order_of serial number shown in the challan to avoid confusion and for easy
verification. The category of candidates should be noted in RED INK BALL PEN on the

Right side top corner of the Nominal Rolls.

4. Extracted nominal rolls in respect of candidates failed in SSC June-2016 examinations are
supplied in Duplicate for use in respect of the candidates who failed in SSC Public
Examinations, June- 2016 and wish to appear for SSC Public Examinations March-2017. All
candidates must be noted in one copy of extracted Nominal Rolls and sent to the DEO
concerned Second and third copy of extracted Nominal Rolls may be used if some more
related candidates approach after 1* and 2 batch sent to the DEO. However the concerned
schools shall take Xerox copies of such extracted N.R and keep with them as office copy for
future references.

5. Nominal Rolls pertaining to Blind, Deaf and Dumb and Ortho Physically handicapped
candidates should be prepared and submitted SEPARATELY clearly superscribing in
RED INK duly enclosing the original Medical certificates issued by the Medical Board in
support of PH category. The code number of PH category should be necessarily be noted in
the NR as per the instructions shown in the blank nominal roll format without fail.

6. Only such of the candidates whose disability is more than 40% as per medical certificate alone
are considered as P.H. Candidates under respective categories and the benefit/concessions
will be given as per rules. (G.O.Ms.No.27, dt:09-08-2000 of Women Development, Child
Welfare & Disable Welfare (DW) Department.

3

<!-- page 4 -->

7. Guardian’s name, or 1450200615 name in case of a married women candidate should not
be written in the Father’s name column, since no such provision is made in the 5.5.0
Scheme. Only Father’s name & Mother's name shail be written in MNR.

8. Care should be taken to see that candidates of the same medium come together,
followed by another medium. For example, all Telugu medium candidates come in the
first order followed by English medium etc.,

9. i) After the Nominal roll is prepared, it should be verified personally by the Headmaster with
feference to the Admission reaister. particularly the entries relating to the Candidate’s name,
Father's name & Mother's name, Date of birth Community Code of the Candidate. Medium
of instruction Aadhaar Number and Subject codes.

ii) From March - 2015 onwards, there shall be common English Paper (Ill Language) for
all media Candidates including English Medium Candidates. 1.6. Paper-I is 13E &
Paper-ll is 14E.

ili) The names which are on rolls of the School alone should be considered and forwarded
as Regular candidates.

iv) Special care shall be taken while noting the similar names of the candidates in MNR to
avoid any kind of confusion.

v) The no. of Regular candidates forwarded shall be as per the sections ermitted
as_per the prescribed strength by competent Authority only 2౧6 ౧౦ excess
candidates shall be forwarded.

vi) Incomplete MNR will not be accepted by this office.

10) 706 Manuscript Nominal Rolls of S.S.C (Academic), O.S.S.C., and 5.5.0 Vocational Course
shall be prepared separately, as per rules, duly noting the correct codes of the subjects.

The group combinations in respect of S.S.C., 0.S.S.C and 5.5. C., Vocational trade codes

are detailed in Annexure.

11) i. 2 The Headmaster should invariably fill-in and sign on the certificate printed on
separate Sheet, after verification of the N.Rs. The Headmaster should affix
School Stamp with full Postal address (Like Post, Mandal, Pin Code, Phone
Number) for future correspondence.

b. The Forwarding Schools should invariably maintain one copy of the Original
Manuscript Nominal Roll sent to the Director of Government Examinations and present
the same before the Departmental Officers whenever asked for.

||. REGULAR CANDIDATES: SPECIFIC INSTRUCTIONS:

a) Care should be taken to see that the particulars pertaining to the Name of the
candidate, Father's name, Mother's name, Date of birth, subjects offered for
Community code, Medium of instruction, P.H. code, Aadhaar Number etc. written in the
Manuscript Nominal Rolls, the particulars of the candidate uploaded through
online and the corresponding entries in the School Admission Register must be
one and the same. There should not be any differences between the particulars given
in MNR and School Admission Register as this will lead to complications for corrections
of any mistakes in future.

b) A declaration from the parents shall also be taken for the confirmation of above
particulars before uploading the candidate’s data through online.

4

<!-- page 5 -->

6) Identification marks mentioned in the admission register shall be verified physically
before they are uploading through online in the case of regular candidates.

ఈ) All the regular _MNRs_ submitted by the Headmasters of schools of _all
managements should be countersigned by the Deputy Educational Officer
concerned duly verifying all particulars as per the certification of Secreta
DCEB, with reference to number of Question Papers supplied to each High
School by DCEB for Quarterly and Half yearly Examinations duly verifying the
school Admission register and attendance register thoroughly.

Mh. VOCATIONAL CANDIDATES:

a) Separate MNR has to be prepared in fespect of Vocational candidates also as per the
existing practice duly noting the paper code of Vocational Trade theory and practical in
the remarks column. Ensure that Theory paper code which is noted in MNR and data
uploaded through online shall be one and same.

b) In the MNR the Vocational trade theory and practicals have to be necessarily noted
with Red Ink ball pen without fail for easy identification in the same MNR on the
extreme right side.

WV. O.S.S.C CANDIDATES:-

01. Prepare separate MNRs for Regular and once failed candidates.

02. Fill up the correct paper code of the Subjects appearing in MNR and upload the correct
Paper code through online and it should be tally with each other.

03. In respect of once failed candidates, correct previous Roll Number with Month &
year has to be furnished both in Manual Nominal Rolls and uploaded data through
online.

Vv. REMITTANCE OF FEES:

01. Collect the examination fee and other fee as given in the notification and remit the
amount through the prescribed consolidated Challan duly noting the names of the
candidates who have paid the examination fees, on the back side of the challan. If the
space on the back side of the challan is not sufficient a white sheet may be used for
noting the names. Care may be taken to remit the fee of the Regular / Private once
failed candidates of earlier examinations other than the 5.5.0 Advanced
Supplementary Examinations, June-2016, candidates failed in the S.S.C Advanced
Supplementary Examinations June-2016, through SEPARATE GONSOLIDATED
CHALLANS IN THE CATEGORIES SHOWN ABOVE. They shall not be mixed-up with
one another, to avoid confusion and for easy verification.

02. The Notified fee dates for SSC Public Exams, March-2017 are common for SSC,
0550, Private all once failed candidates (New Syllabus only) and SSC vocational
candidates. The notification has to be put on the notice board of the school for the
convenience of the concerned. The Head of account to which fee has to be remitted is
as follows.

0202- Education, Sports, Arts & Culture
01- General Education
102- Secondary Education
06- Director of Government Examinations
800- User Charges
DDO Code: 25000303001
5

<!-- page 6 -->

03. The candidates belonging to Scheduled Castes / Scheduled Tribes and Backward
Classes who are appearing for SSC March- 2017 for the first time as Regular
candidates and whose parental income does not exceed Rs.24,000/- per annum ini
urban areas and Rs.20,000/- or land holding not exceeding 2.5 Acres wet land / 5
acres dry land in Rural areas are exempted from the payment of examination fee. As
such, the Headmasters are requested to satisfy themselves about the Parental income
by insisting upon a certificate issued by the Mandal Revenue Officer as per rules, and
retain the same in the school to produce before the officers and audit if sought for, and
also to submit to this office on demand. The particulars of exemption shall be clearly
noted in the remarks column of the M.N.R, with red ink failing which the M.N.R will not
be accepted and will be returned under objection or such candidates name will not be
registered for the S.S.C Examinations, March- 2017.

04. The list of fee exempted candidates in respect of SC, ST and BC has to be
enclosed to the MNR (Category wise list).

VI. OTHER INSTRUCTIONS:

01. The Candidate should be advised to appear for correct combination of subjects and for
this purpose the school should furnish correct Paper codes under 1" Language, 2"
Language and 3” Language subjects as per the Three Language Formula.

02. All Regular candidates those who appear for SSC Public Examinations, March
2017 have to follow first languages TELUGU, HINDI, URDU, TAMIL, KANNADA,
MARATHI in NEW PATTERN of Question Paper.

03. Text Books with New syllabus is introduced and being taught from the Academic
year i.e.2014-15. The new syllabus is being taught for Non-Languages also. Third
Language English will be same for candidates of all media including English
medium. The code will be 13E for 1° paper and 14E for 2" paper.

04. Candidates shall complete 14 years of age as on 31-08-2016; in other words, they
must have been born on or before 31-08-2002.

05. The names of under aged candidates shall not be included in the Manuscript Nominal
Rolls_unless_condonation orders from the competent authority are obtained and
enclosed. The fees for obtaining orders of condonation of age is Rs.300/-.The
competent authorities for issuing orders condoning the age are as follows:

(i) The DEO of the district concerned is the competent authority to condone the
shortage of age up to 1 % years as per rules in vogue i.e the students of Private
Management Recognized Schools.

(ii) Above 1 % year and up to 2 years, the Director of Government Examinations,
Telangana., Hyderabad is the competent authority to condone the shortage of
age in respect of all Managements i.e., Government, Zilla Parishad, Aided,
Private Recognized Schools etc., .

(ili) Regarding students of Government & 2. P High Schools the procedure
prescribed in the G.O. Ms, No.40 Edn (Ser V) Dept: dt:07-05-2002 and Govt
Memo No.17120/Exams/2004. Edn (SE Exams) Dated:08-06-2006 shall be
followed.

6

<!-- page 7 -->

06. No_age relaxation shall be given above 2 years and as such no such

applications should be accepted and forwarded to the office of the Director of

Government Examinations, Telangana, Hyderabad as. per
Govt.Memo.No.17120/Exams/2004, dt:08-06-2006.

Seto MO. T1720/Exams/2004, dt:08-06-2006.

07. i) Hearing impaired (Deaf and Dumb) candidates are exempted from appearing 2
language subjects out of 3 language subjects Prescribed. However such
candidates should get prior permission of the Director of Government
Examinations, Telangana, Hyderabad before remitting the examination fee.
Copy of the permission letter shall be enclosed to MNR, and particulars of the
exemption orders should Clearly be noted against the name of the candidates in
the remarks column. Otherwise the result of the candidates will be kept under
withheld.

ii) 1౧ pursuance of the Government orders contained in G O.Ms.No.34, dt:05-03-
2004 the following concession be allowed to the students suffering from Dyslexia
and appearing for SSC Public Examinations, March- 2004 onwards:

a) Exemption from writing 3% Language (English).

5) Provision of scribe

¢) Allowing additional time for one hour for each paper.
However such candidates should get prior permission of the Director of
Government Examinations, Telangana, Hyderabad before remitting the
examination fee.

08. Visually impaired (Blind) and Orthopedically challenged candidates shall appear for all
6 (Six) subjects. No exemption is given to them.

Note: All Physically Handicapped candidates shall produce a Xerox copy of
Medical certificate duly attested by the concerned Headmaster along with
original Medical certificate.

09. All private recognized High Schools forwarding regular candidate shall invariably
enclose the copies of the latest Recognition orders to the MNR. If the school is. newly
permitted to open ౫ class during 2016-2017 they should enclose 2 copy of the
opening permission orders issued by the competent authority (Regional Joint Director
of School Education) duly attested by the Deputy Educational Officer concerned.

10. Mere submission of Proposals for opening permission during 2016-2017 will not give
any right to the management to Present the students as regular candidates. In this
aspect in the earlier examinations certain DEOs have forwarded OMR cum ICR forms /
MNR of such schools along with “Under Process certificate” (self issued) which is
irregular. Hence the DEO shall not accept MNRs and fees challans from the schools
who do not have the permission to open X class. They will be held responsible for any
such deviations.

11. In case of new schools which are Permitted to open X class and Presenting regular
candidates for the first time during academic year 2016-2017 shall submit recognition
proposals to the RIDSE through DEO with in two months from the date of receipt of
the same, otherwise the candidates will not be admitted for SSC Exams. In all these

~ cases they must enclose orders issued by the competent authority permitting to open x
class during 2016-2017. Schools which were permitted to open X class during 2015-
: 2016 must and should enclose Fecognition orders obtained from the competent
authority.
7
— నయ

<!-- page 8 -->

12. Forwarding schools have to maintain a Record /Register containing the particulars of
the candidates presented for the S.S.C Examinations till he / she passes the
Examinations, duly noting the marks secured by them at every sitting along with the
Roll number, Month and Year of Examination, Serial number of the certificate / failed
memorandum etc., and should be able to produce before the Director of Government
Examinations as and when asked for. The Head of the institution will be solely made
responsible for not-maintaining such Register/Record. Photo of the candidate should
also be affixed in concerned page of the Register.

13. 1. While preparing the MNRs Headmaster of school concerned should write area

code of that school i.e., URBAN / RURAL in consultation with mandal
Revenue Officer concerned & DISE information submitted to C & DSE.
2. He / She is responsible for future complications in connection with
admissions in IIIT course of Telangana State.

14. The candidates who were involved in malpractice earlier should not be forwarded
without permission letter from this office. As ‘such, the Heads of Schools are strictly
informed to exercise more care and vigil over such occurrences and not to give
scope for any such lapses, since it attracts punishment as per “THE
PREVENTION OF MALPRACTICES ACT 25 OF 1997. If any Headmaster sponsors
any private candidate without schoo! study or any candidate of unrecognized school as
their reqular candidates, the Headmaster and the correspondent will be prosecuted in
addition_to_initiating disciplinary action and collection of foregone income to the
Government from the Headmaster concerned. In addition to heavy penalty as decided
by the DGE, the Recognition of such school will be withdrawn

15. The English medium students, in case they opt for Telugu as 1° Language
should opt only Hindi as a second Language and they shall not opt or choose
Special English as 2 Language under any circumstances as Special English
under Second Language is dispensed already. Only 09H and 097 are available
under Second Language and no other Language is admissible under Second
Lanquage.

16. It is came to notice that some of the Headmasters / Correspondents of recognized high
schools are paying the examination fee in time even before the candidates approach
them without mentioning the names on the reverse side of the challan and collecting
more money when the students approach them after due dates prescribed, this is
highly irregular and punishable. If the same thing is noticed this year, severe
disciplinary action will be taken against the Headmaster concerned, declaring him unfit
to be Headmaster for any secondary school as per TSER and the MNR & the
particulars uploaded through online will not be accepted. The
Headmaster/Correspondent will have to face any legal complications that may arise
from the students and parents. Further the school recognition is also be cancelled.

17. Previous pattern of Eleven Papers with Six subjects will be continued. All the subjects
i.e, 1 Language, 3 Language, Mathematics, General Science, Social Studies except
2” Language Hindi/Telugu will have 2 Papers. In case of 2” Language there will be
one Paper only.

18. Exams are conducted for 100 marks in all the subjects i.e., 80 marks for
summative test (Board Exam) and 20 marks for formative test (internal exams or
School based exam).

8

<!-- page 9 -->

49. Pass Marks for all the subjects excluding 2” language i.e. Hindi/Telugu is 35 Marks.
That means candidates shall secure 35 marks in each subject both summative and
formative marks put together. However, the candidates should secure a minimum of
28 marks in the Board Exam to declare them as passed. Pass marks for 2" Language
subjects is 20 Marks only.

3 20. The existing facility of students appearing for SSC Public Examinations without Regular
School Study is dispensed with. Such students may appear for Class X through other
alternative systems like National or State Open Schools System. This is a major Policy
decision and the Headmasters of all the managements are requested to give wide publicity
so that students of Without School Study would enroll themselves in Open Schools to
appear the SSC Exams. Otherwise they will lose the opportunity of writing the exams.

21. Subject codes like special English 11E, 090౮ etc, offered under 2” language are dispensed
with. Now the students of Outside State / Country, will have to write compulsorily either 097
or 0911 depending upon their choice of 1* language if they take admission in 6" class itself.
In the case, if they take admission in formal schools of Telangana in classes like mee,"
and 10" they are exempted from writing 2” language. However such candidates should get
prior permission from the DEO Concerned before remitting the examination fee. Copy of the
permission letter shall be enclosed to MNR and Particulars of the exemption orders should
be noted against the name of the Candidates in the remarks Colum. Others wise the result
of the Candidates will kept under with held

22. OSSC Scheme :- As per the revised rules OSSC students shall write 1* language Telugu
017, 027, Urdu 010, 020 etc., for 100 marks instead of 80 marks. The 100 mark will be for
both summative and formative i.e 80 marks for summative and 20 marks for formative
evaluation. Similarly there are three Oriental Subjects i.e Sanskrit, Arabic and Persian for
200 each and examination conducted in 2 papers @ 100 marks per paper. The 100 marks
will be distributed across summative and formative evaluation 1.6 80 marks for summative
and 20 marks for formative evaluation under each paper.

23. The Managements of Private Recognized Schools should be very careful and they should
get the opening permissions, upto date recognitions, Additional Sections Permission etc.,

should be enclosed to the MNR at the time of submission to the District Educational
Officers concerned. Under any circumstances MNR’s shall not be accepted by the DEO’s
without Permission / Recognition orders. If any deviation DEO’s / Dy. EOs and School
managements are personally held responsible.

24. Further, the Private Management schools are cautioned not to present the candidates more
than the prescribed strength for each section under any circumstances. If so the excess
candidates as per prescribed strength shall be deleted from the MNRs and the students will
loose one complete academic year and the managements are personally held responsible
for any such lapses.

Yours faithfully,
|(16తడబ్ల.
he

మ Copy to all the District Educational Officers / Asst. Commissioners for Government Examinations in the
State for information and necessary action
Copy to all Officers / Section Heads of this Office for information and necessary action.
Copy to C & DSE, RJDSE,SCERT for information and necessary action.
9

<!-- page 10 -->

ANNEXURE
5.5.0. & O.S.S.C. PUBLIC EXAMINATIONS GROUP COMBINATIONS
1. $.S.C:-
GROUP - A.
One of the following Languages which is the Mother Tongue / or the Regional Language of
the students: Telugu (01T/02T), Hindi (01 H/02H), Urdu (01U/02U), Kannada (01K/02k),
Tamil (01A/02A), Marathi (01M/02M)
Paper-| — 40 Marks: Paper-ll — 40 Marks:
భి Government have issued orders to restore the Composite Courses as existing prior
to the issue of G.O.Ms. No.2, SE(Prog.ll) Dept, t:26-08-2014, from the Academic
Year 2016-2017 onwards vide their G.0.Ms.No.6 School Education (Prog.Il) Dept.,
dt:17-02-2016. Hence the following languages may be opt under Group-B.
GROUP -B:
A Composite Course of any of the Languages mentioned in Group-A, under Paper-I with the
allied classical Language. (Sanskrit, Arabic, Persian) under Paper — Il
Paper-| : 60 Marks Summative Assessment — Mother Tongue (03T/03A/03K/03U/03H/03M)
(20 Marks Formative Assessment).
Paper-ll: 20 Marks — Any of the three allied classical Languages
(Sanskrit (04S) / Arabic (05) / Persian (06) / Hindi (08H))
Note: (1) Telugu / Sanskrit (037 / 04S), (2) Arabic / Persian (03U / 054), (3) Marathi / Hindi
(03M / 08H).
ll. 0.S.S.C. PATTERN:
As per three language formula
Oriental Classical | Language ll Language Il Language
Language
(23/24) Sanskrit (01T&02T) Telugu Hindi (09H) English
(80+80=160 Marks) (40+40=80 Marks)
(25/26) Arabic (01U&02U) Urdu Telugu (097) English
(80+80=160 Marks) (40+40=80 Marks)
(27/28)Persian (01U&02U) Urdu Telugu (097) English
(80+80=160 Marks) (40+40=80 Marks)
Note:- Non-Language subjects: The student under 0.S.S C can opt for any two of the three
non-language subjects. But, it is enough if the candidate gets pass marks in one sub ject.
10
