---
doc_id: "1afbaecf6678ba2d"
source_url: "https://emunicipal.telangana.gov.in/etistmvcdfwefrzxczx/scsdvcxvcxvcvxc?adsjfasd=NEWS_25102024053711Namaste%20state%20coordinator%20adverstisement%20final.pdf"
ministry: "Commissioner and Director of Municipal Administration, Telangana"
title: "Brochure for Appointment of State NAMASTE Coordinator under NAMASTE scheme    Updated On 25-10-2024 17:02:58"
date: ""
pages: 5
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "d4ea67ef67060482"
---

<!-- page 1 -->

f
GOVERNMENT OF TELANGANA
MUNICIPAL ADMINISTRATION DEPARTMENT

O/o Commissioner & Director of

Municipal Administration Department,

Telangana, Hyderabad.

INVITATION OF APPLICATIONS FOR STATE NAMASTE COORDINATOR UNDER
NAMASTE SCHEME

Roc.No.E-616798-743929/2022/H2 24.10.2024

Commissioner & Director of Municipal Administration (CDMA), TG., Hyderabad
is the nodal agency for implementation of the National Action for Mechanized
Sanitation Ecosystem (NAMASTE) which is to be implemented in all towns of the
Telangana with the objectives to avoid deaths of workers while cleaning sewers and
septic tanks.

CDMA requires one young and energetic professional to work under Project
Management Unit (PMU) as State Namaste Coordinator and implementation of
NAMASTE,

For information Brochure containing eligibility conditions, work profile and
format of application etc. please visit to website:- emunicipal.telangana.gov.in &
wvw.nskfdc.nic.in

Applications should reach to O/o. Commissioner & Director Municipal
Administration, TG., Hyderabad, AC Guards, Masab Tank,-500004 with a cover title-
“Application for the post of PMU under NAMASTE” on or before 15:00 hrs of
01.11.2024.

Sd/- V.P.Gautham, 1.45,
Director of Mpl.Admn.

<!-- page 2 -->

19014/06/2020-SCD-IV(SRMS)
\
1/29819/2023 Terms and Conditions for Engagement of PMUs Y 1
(State NAMASTE Coordinators) ~~
1. Requirement of PMUs- 55 PMUs will be appointed and placed at the disposal
of State NAMASTE Coordinator as per bifurcation attached at Annexure
2. Eligibility criteria for selection of PMU
A. Essential:

(i) Graduate or Post Graduate degree from a recognized university in urban
planning, Social Work, public policy, business administration, Sociology,
Anthropology, Commerce, Science or other related fields, with at least 55%
marks.

(ii) Two years’ relevant work experience in case of Graduate candidates

(iii) Excellent communication (both oral and written) in English and the official
language of the State/UT of deployment.

(iv) Computer proficiency in MS Office and proficiency of working on various
mobile applications.

(v) Age between 21 years to 35 years.

B. Desirable:
(i) Relevant work experience of two (02) years for Post Graduate Candidates.
3. Selection of PMU Managers

The candidates shall be selected anddeployed by the concerned State Namaste

Nodal Officerin consultation with Committee of officers from MoSJE and

NSKFDC through web link

4. Terms and Conditions to deploy PMU

a) The PMU would work on full-time basis for the project and would not be
allowed to engage themselves for any other project/ work during the duration
of the NAMASTE project. Any changes in PMU deployment would be only
after approval of NSKFDC/Ministry.

b) PMU would be selected for a period of two year with a possibility of extension
for one year, subject to requirement and satisfactory performance.

9 The engagement of PMU would be done by the concerned State NAMASTE
Nodal Officer. The engagement would be purely project based. They will
have no claim whatsoever for continuing their services in any capacity.

d) The PMU would be paid monthly remuneration of Rs 45000/- per month
inclusive of applicable taxes and statutory dues.

<!-- page 3 -->

19014/06/2020-SCD-IV(SRMS)

1/29819/2023 @) NSKFDC would make payment to the PMU upon certification of attendance i
and satisfactory working of PMU and submission of brief write up of works
performed during the month, by the State Namaste Nodal Officer.

f) Since these PMUs would work as State Namaste Coordinators(SNCs), they
would be required to travel within the State. An amount of Rs. 10,000/- per
month has been estimated on their TA/DA, which would be paid by NSKFDC
on actual basis upon furnishing the original bills/tickets at the norms fixed by
NSKFDC for its Executives at E-0 level.

g) PMU would be required to arrange a good working condition laptop and
mobile during the period of engagement for his/her use. For this, they will not
be paid any extra amount.

h) PMU will get benefit of one leave per month.

i) PMU will not be allowed to show any political affiliation during the project
period. They will work without any favour with any section of the society.

j) Except with the prior written consent of NSKFDC, PMU shall not, at any time,
communicate to any person or entity any confidential information acquired in
the course of the Services.

k) The services of PMU can be terminated anytime by Ministry of Social Justice
in case of non- performance and non-adherence of duty timeline.

5. Scope of Work for PMU Managers under NAMASTE

a. The proposed PMU would be called State NAMASTE Coordinator(SNC) and
shall be deployed with the State Namaste Nodal Officer.

b. SNC would report the progress of implementation in the ULBs of the State
assigned, to the State Namaste Nodal Officer and also assist the State
Namaste Nodal Officer incoordination and regular follow up with the
concerned ULBs for taking action for implementation of the Scheme.

c. SNC would report the progress periodically and as and when required during
implementation of NAMASTE and any other report or information, in respect
of ౮౮౫౨ of the assigned State, to NSKFDC in the mode as may be requiréu
and would be responsible for regular updation of MIS on the NAMASTE
portal.

d. The State Namaste Nodal Officer and NSKFDC are authorised to direct the
SNC to visit any District or ULBs for any work relating to implementation of
NAMASTE.

<!-- page 4 -->

APPLICATION FORM |
Post applied for. Project Manager
1. Full Name :
2. Father/ Husband's Name స
3. Permanent Address క్ష
4. Address for Correspondence/
Present Address
. ree
5. Date of Birth: 6. Sex: Male a Female [cal
7. Religion: 8. Nationality :
9. Category (PI. tick): SC క "556 EXSM 1 ae el
| |
10. E-mail id క
11. Telephone No. (with Std Code): -
12. Mobile No.

<!-- page 5 -->

13. Educational Qualification:-
| Qualification Subjects Percentage | Year of Name of Board |
| (Starting 10+2) | of marks passing /University/ |
eee | Institution |
a |
14. Experience:
[Name ofthe | Designation | Nature of Period ~] Duration —
_Organization | duties | -
ప =|
i eS cell
Declaration: | hereby declare that all statements made in the application are true, complete and
correct to the best of my knowledge and belief. | understand that in the event of any information
being found untrue / false/ incorrect or if | do not satisfy the eligibility criteria, my candidature/
appointment will be cancelled/ terminated, without assigning any reason. | have tead the content of
the advertisement and agree to abide by the rules, regulations and procedures for appointment to
the post.
Signature of applicant
Date:
Place’
