---
doc_id: "5eee67bfbe56fb05"
source_url: "https://cdn.s3waas.gov.in/s31c383cd30b7c298ab50293adfecb7b18/uploads/2024/12/2024121222.pdf"
ministry: "Khammam"
title: "Press Note-Notification for Contract Recruitment for the Posts of Govt.Medical College Khammam- Click Here"
date: ""
pages: 1
method: "tesseract:tel+eng"
script: "TELUGU"
needs_ocr: false
sha1: "30bc1add8890e7c6"
---

<!-- page 1 -->

ప్రభుత్వ మెడికల్‌ కాలేజీ ఖమ్మం
పత్రికా ప్రకటన

కారటక్తు/గౌరవ వేతనం పద్దతిలో పోస్టులను నియమించుటకు గాను ప్రకటన
జారీ చేయడమైనది. అర్హులైన అభ్యర్తులు తేదీ 19.12.2024 (4 pm) లోపు ఆన్లైన్‌ / ఆఫ్‌
లైన్‌ ద్వారా దరఖాస్తు చేసుకోవాలని కోరుచున్నాము మరియు 20.12.2024 (10 : 30 AM)
నుండి ఇంటర్వ్యూ ద్వారా పోస్టులను నియమించుట జరుగును. విద్య అర్హతలు,
నియమనిబంధనలు ఖమ్మం జిల్లా వెబ్సైటు మరియు ప్రభుత్వ మెడికల్‌ కాలేజీ వెబ్సైటు
నందు ప్రకటన యొక్క పూర్తి వివరములు కలవు.
[Sine [Fat టల లుం]
లవ నన.
యం నా Pt
[2 నత నా
Emergency Medicine/ General Medicine 1
తన తతత నా
[6 సుంకము డంకన్‌ |
Respiratory Medicine/General Medicine
1. CAS Specialist (ICU) General Medicine, MD, DA, DTCD,
CAS Specialist (ICU) Pulmonary Medicine , MD, DA, DTCD, 1.

Total posts of all cadres
District Website https://khammam.telangana.gov.in// /
College website https://gmckhammam.or, / (9
వ. క
ప్రిన్సిపాల్‌
ప్రభుత్వ మెడికల్‌ కాలేజీ
ఖమ్మం.
ఆ Scanned with OKEN Scanner
