---
doc_id: "febe0fa02d5ad934"
source_url: "https://tgic.telangana.gov.in/Downloads/Instructions/50_1193_29052017.pdf"
ministry: "Information Commission, Telangana"
title: "1193_29052017.pdf"
date: ""
pages: 1
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "74908f9dbad19e09"
---

<!-- page 1 -->

GI
GOVERNMENT OF TELANGANA
” ABSTRACT
RTI Act 2005 - Constitution of District Level Coordination Committee for effective
implementation of RTI Act 2005 - Orders Issued.
GENERAL ADMINISTRATION (GPM&AR) DEPARTMENT
G.O.Rt.No. 1193 Dated: 29-05-2017
Read:-
From the Secretary, State Information Commission, Hyderabad,
Letter No.37370/APIC- A/2016, dated, 20.04.2017.
OK
QRDER:

It has been decided to ensure effective implementation of RTI Act, 2005, at
all levels of public authorities. Accordingly Government hereby order to constitute
District Level Coordination Committee, with all the district officers as members and
District Revenue Officer as the nodal officer for effective implementation of RTI
Act. The representatives of two RTI NGOs also are made members in the sald
committee, on rotation basis for a period of one year.

2. All the District Collectors shall take immediate necessary action and see that
the committee meets once in a quarter for review of the implementation of the Act
in the district and send the report to Government.

(BY ORDER AND IN THE NAME OF THE GOVERNOR OF TELANGANA)

S.P.SINGH
CHIEF SECRETARY TO GOVERNMENT
To
All the District Collectors
Copy toi-
The Secretary,
A.P, Information Commission,
Samachara Hakku Bhavan,
D.No. 5-4-399, Housing Board Building,
Mozam-jahi-Market, Hyderabad - 500 001.
//FORWARDED :: BY ORDER//
SECTION OFFICER
