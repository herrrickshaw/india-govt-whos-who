---
doc_id: "7eeae4acba5f9ae5"
source_url: "http://treasury.telangana.gov.in/docs_old/CPSinstructionstoNodalOffices.pdf"
ministry: "Directorate of Treasuries and Accounts, Telangana"
title: "CPS Instructions to Nodal Offices"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "d8eeb32ba5f88573"
---

<!-- no text layer: pending OCR -->
