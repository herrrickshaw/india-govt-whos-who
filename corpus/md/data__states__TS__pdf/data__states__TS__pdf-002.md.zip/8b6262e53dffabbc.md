---
doc_id: "8b6262e53dffabbc"
source_url: "https://tafrc.telangana.gov.in/newpdfs/TAFRC_MEDICAL_GO-131FOR_PG_MEDICAL_COURSE-IN-SURABHI-INSTITUTE-OF-MEDICAL-SCIENCES-FOR-BP2023-2026.pdf"
ministry: "Telangana Admission and Fee Regulatory Committee, Telangana"
title: "12.TAFRC_MEDICAL_GO-131FOR_PG_MEDICAL_COURSE-IN-SURABHI-INSTITUTE-OF-MEDICAL-SCIENCES-FOR-BP2023-2026(GO)"
date: ""
pages: 2
method: "tesseract:tel+eng"
script: "LATIN"
needs_ocr: false
sha1: "5c41eaf1979b11a7"
---

<!-- page 1 -->

| GOVERNMENT OF TELANGANA
మ ABSTRACT
HM & FW Department - Medical Education - Surabhi Institute of 141 గగ
Sciences, Mittapally (V), Siddipet (M), Medak District - Fixation ef ce
structure for PG medical courses for the period 2023-2026 - Orders - Issue Pt
HEALTH, MEDICAL AND FAMILY WELFARE (C1) DEPARTMENT
G.OMs.No. 131 Dated:18.08,2023
Read the following:-
1. G.O.Ms.No.107, HM&rW(Cl) Dept, dated: 28.07.2023. ca
Is 2. From Administrative officer, TAFRC, Masab tank, Hyderaba
Lr.No,TAERC/PG Course/Fee/2023 66 07.08.2023.
ORDER: స్ట
| In the GO, 1% read above, orders were issued for fixation of fee
| structure for PG medical and dental courses for the block period of 2023-2026
for the private unaided non-minority/ minority medical and dental colleges in *
the State.
2. In the reference 2nd read above, Telangana Admission and Fee
Regulatory Comunittee (TAFRC) has submitted proposal for fixation of fee
structure for newly recognized PG medical courses at Surabhi Institute of
Medical Sciences, Mittapally (V), Siddipet(M), Medak for the block period
2023-2026. |
3. Government after examination of the matter, hereby. accept the
: recommendations of the Telangana Admission and Fee Regulatory Committee ©
and fix the fee structure for PG medical courses at Surabhi Institute of Medical
Sciences, Mittapally (V), Siddipet(M), Medak district for the block period 2023-
2026 as follows, subject to following the conditions mentioned in the reference .
15t read above: be, న oe aa i
యు Medical PG Fees (Rs.in lakh) = 5 |
. 5. College Name Degree/Diploma.~. |. Degree/Diploma _Degree/ Diploma |
No Cat 6౯ (6౯ | Cat =] Cat-A | Cat-B «| Cat-C
A A B c ei eres rasa
1 | Surabhi Institute | 7.00 23.00 | Up to |-4.30-.. 5.30. Up to .}-1.70 © |.1.70 Up to |
of Medical sate 3 వసన కంల సన “3606 |.
| Sciences, | ote ; న. ies} of Cat-B
| | Mittapally (V), a pat ees aed లె. eid 1
Siddipet(M), it at BE eA న moter tees ED
Medak district ; Rand Birt Ace టన
4... The Registrar, KNR University of Health Sciences, Warangal shall take’: anne
, Necessary action in the matter accordingly. site న eew was ce
: (BY ORDER AND IN THE NAME OF THE GOVERNOR OF TELANGANA) 0!
వ Leb pe ces SSeS AM, RIZMI os ccs ieee
: న Tous Beat : os a aie ‘ ae న qe
సి మం స్ట of seal Sciences, Warangal. -:” et ee pee ees
- Principal, Surabhi Institute of Medical Sciences, Mittapall క న!
వ టంలం ము న ciao
ప్‌ ~,,,Director of Medical Education, TS., Hyderabad. సననం న ర
Scanned with CamScanner

<!-- page 2 -->

2 ||
Copy to: :
Secretary, Government of India, Ministry of Health & Family Welfare,
Department of } lealth, New Dethi,
Secretary, National Medical Commission, New Delhi:
Secretary, Dental Council of India, New Dethi, క
Administrative Officer, Telangana Admission & Fee Regulatory Committee,
Masab Tank, Hyderabad - 28, .
PS. to Minister (HM&FW), 11
PS. to Secretary toC.M,
P.A. to Secretary to Government, HM&EW Dept.
SF/SCs, i
// FORWARDED. =: BY ORDER //
[Ripe 2)
ECTIONOFFICER =.
Ww TS ae
|
|
. Scanned with CamScanner
