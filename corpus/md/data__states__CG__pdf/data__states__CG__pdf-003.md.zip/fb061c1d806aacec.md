---
doc_id: "fb061c1d806aacec"
source_url: "https://eproc.cgstate.gov.in/CHEPS/html/chips/Online_EMD_Refund_Notice.pdf?OWASP_CSRFTOKEN=IHWR-J3W9-SK4Q-T0BX-FDMX-C2I8-6N3L-5XKC"
ministry: "Integrated e-Procurement Portal, Chhattisgarh"
title: "EMD Refund Guidelines"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "60b7a4ea9c3cd3af"
---

<!-- page 1 -->

OFFICE OF CHiPS
State Data Center Civil Line Raipur,
Raipur, CHHATTISGARH
Guidelines on Refund of Earnest Money Deposit under Integrated eProcurement

 CHiPS have already integrated the online Payment Gateway for the
Collection/Refund of the Online EMD through Integrated e-Procurement
system.
 To make departments familiar with the above process of online
submission/refund of EMD, CHiPS had already Conducted the Multiple
Training session and shared user manuls (also availbe in the portal) .
 All the EMD collected during online tendering Process will be refunded
by Respective Departments Officials only. CHiPS do not have any
intervention on such process.
EMD Refund process for unsuccessful Bidders is as given below:1) The tender owner/department admin to initiate the EMD
remittance/Refund
process
for
unsuccessful
bidders
after
opening/evaluation for PQ/Technical Bid and also opening of Price Bid &
confirmation of the Price bid and sent it to appropriate Department
Approver.
2) Once Departments approver approved the refund process after verification
the e-Procurement system automatically sent the instruction to bank for
refund of EMD to respective bank account of the bidders as per registered
details of account no. provided in the bidder profile/ registration details on
Integrated e-Procurement portal.
3) EMD Refund MIS is already available in the e-procurement portal for
Departments as well as bidder on their login to check EMD refund status .
There is no need to visit CHiPS office for getting status of the EMD as it
already available online on the portal.
4) With in 1 or 2 day after refund & approval process by department
officials, the EMD amount gets credited to respective bidders account.
1|Page

<!-- page 2 -->

L1 EMD Refund process is as given below
a) Initiate L1 EMD Remittance/Refund Process:
Department will have following options for L1 Bidder’s EMD remittance and
refund to bidders:
i.

L1 EMD Remittance to Department: The tender
owner/department admin will initiate the EMD remittance process
for successful bidders (L1/H1) after Online contract is created &
approved online using contract management module. Tender owner
will have option to select appropriate bank account. .

ii.

L1 EMD Refund to Bidder: The Tender owner/department admin
will initiate EMD refund to L1 Bidder in its bank account already
mapped in registration profile. In such cases department may
initiate refund only after receiving of Performance Bank Guarantee
as required in appropriate format while online contract is approved.

 All the activities related Refund process will be carried out by respective
tender owner of the departments in order to ensure no manual intervention
in EMD Refund/Remittance Process.
 Further if Department user/bidders face any difficulties regarding EMD
refund then Integrated e-Procurement Help Desk is reachable on 1800419-9140 for support/assistance in this regard.
 Departments are requested to resolve the EMD related matter at their end,
CHiPS will not directly entertain the bidders.
 If any technical difficulty faced by the departments officials then inform
the CHiPS via mail or telephonically with proper details in this regard.

CHiPS

2|Page
