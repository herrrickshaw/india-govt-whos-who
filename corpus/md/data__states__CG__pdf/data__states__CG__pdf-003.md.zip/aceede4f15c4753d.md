---
doc_id: "aceede4f15c4753d"
source_url: "https://csidc.in/wp-content/uploads/2025/10/Private-Mini-Malls-Promotion-Rules-2025.pdf"
ministry: "Chhattisgarh State Industrial Development Corporation Limited (CSIDC)"
title: "Private Mini Malls Promotion Rules 2025"
date: ""
pages: 5
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "b27f000574e73317"
---

<!-- page 1 -->



वािण

एवं उ ोग िवभाग

मं ालय, महानदी भवन, नवा रायपुर अटल नगर
नवा रायपुर अटल नगर, िदनां क 14 अ टू बर 2025

अिधसू चना

<!-- page 2 -->

<!-- page 3 -->

<!-- page 4 -->

<!-- page 5 -->

छ ीसगढ़ के रा

पाल के नाम से तथा आदे शानु सार,
रजत कुमार, सिचव.
