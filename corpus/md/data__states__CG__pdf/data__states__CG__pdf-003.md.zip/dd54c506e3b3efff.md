---
doc_id: "dd54c506e3b3efff"
source_url: "https://cspc.co.in/cspc/csptcl/tariffpetition/CSERC%20Approved%20Tariff%20Order%20for%20FY%202023-24.pdf"
ministry: "Chhattisgarh State Power Generation Co. Ltd."
title: "Approved Tariff Order for FY 2023-24"
date: ""
pages: 284
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2bbad5b14de0c180"
---

<!-- page 1 -->

CHHATTISGARH STATE ELECTRICITY REGULATORY COMMISSION
RAIPUR

Chhattisgarh State Power Generation Co. Ltd.

......

P. No. 102/2022 (T)

Chhattisgarh State Power Transmission Co. Ltd

......

P. No. 94/2022 (T)

Chhattisgarh State Load Despatch Centre

......

P. No. 100/2022 (T)

Chhattisgarh State Power Distribution Co. Ltd.

......

P. No. 95/2022 (T)

Present:

Hemant Verma, Chairman
Vinod Deshmukh, Member (Judicial)
Pramod Kumar Gupta, Member

In the matter of –
1.

Chhattisgarh State Power Generation Company Ltd. (CSPGCL) Petition for final TrueUp of ARR of conventional thermal and hydro power plants for FY 2021-22;

2.

Chhattisgarh State Power Transmission Company Ltd. (CSPTCL) Petition for final
true-up for FY 2021-22 and determination of transmission tariff for FY 2023-24;

3.

Chhattisgarh State Load Despatch Centre (CSLDC) Petition for final true-up for FY
2021-22 and determination of SLDC charges for FY 2023-24;

4.

Chhattisgarh State Power Distribution Company Ltd. (CSPDCL) Petition for final trueup for FY 2021-22, and Re-Determination of ARR and Retail Tariff for FY 2023-24.

ORDER
(Passed on 28/03/2023)
1.

As per provisions of the Electricity Act, 2003 (hereinafter referred as 'the Act') and
the Tariff Policy, the Commission has notified the Chhattisgarh State Electricity
Regulatory Commission (Terms and Conditions for determination of tariff according
to Multi-Year Tariff principles and Methodology and Procedure for determination of
Expected revenue from Tariff and Charges) Regulations, 2021 (hereinafter referred as
'CSERC MYT Regulations, 2021') for determination of tariff for the Generating
Company, Licensees, and CSLDC.

CSERC Tariff Order FY 2023-24

i

<!-- page 2 -->

2.

The Commission had notified the Chhattisgarh State Electricity Regulatory
Commission (Terms and Conditions for determination of tariff according to MultiYear Tariff principles and Methodology and Procedure for determination of Expected
revenue from Tariff and Charges) Regulations, 2015 (hereinafter referred as 'CSERC
MYT Regulations, 2015') for determination of tariff for the Generating Company,
Licensees, and CSLDC, which is applicable for truing up for FY 2021-22 for the
Generating Company, Licensees, and CSLDC.

3.

This Order is passed in respect of the Petitions filed by the (i) Chhattisgarh State
Power Generation Company Ltd. (CSPGCL) for approval of final True-Up of ARR of
conventional thermal and hydro power plants for FY 2021-22, (ii) Chhattisgarh State
Power Transmission Company Ltd. (CSPTCL) for approval of final true-up for FY
2021-22 and determination of transmission tariff for FY 2023-24 (iii) Chhattisgarh
State Load Despatch Centre (CSLDC) for approval of final true-up for FY 2021-22
and determination of SLDC charges for FY 2023-24, (iv) Chhattisgarh State Power
Distribution Company Limited (CSPDCL) for final true-up for FY 2021-22, and redetermination of ARR and retail tariff for FY 2023-24.

4.

This order is passed under the provisions of Section 32(3) and Section 62 read with
Section 86(1) of the Act. The Commission, before passing the combined order on the
above petitions, has considered the documents filed along with the petitions,
supplementary information obtained after technical validation, suggestions emerging
from the applicant companies, the consumers, their representatives and other
stakeholders during the public hearing.

5.

The petitions were made available on the Commission‟s website. The petitions were
also made available at the offices of the petitioners. A public notice along with the
gist of the petitions was also published in the newspapers

to invite

objections/suggestions as per the procedure laid down in the Regulations. The
Commission also held a meeting with members of the State Advisory Committee on
February 20, 2023 for seeking their valuable suggestions and comments. Further, the
Commission conducted public hearings on the petitions in its office at Raipur on
February 21 & 22, 2023.
6.

The Commission passed the tariff order for FY 2021-22 on August 02, 2021. The
Commission has undertaken final true-up for FY 2021-22 for CSPTCL, CSLDC,

ii

CSERC Tariff Order FY 2023-24

<!-- page 3 -->

CSPGCL and CSPDCL, based on the audited accounts submitted by the utilities and
in accordance with the provisions of the CSERC MYT Regulations, 2015. Further, the
Commission has also undertaken true-up of capital cost of the GP III integrated mine
and input price of coal from GP III mine for FY 2021-22 in accordance with the
provisions of the CSERC MYT Regulations, 2021.
7.

While computing the cumulative revenue deficit/(surplus) to be allowed to CSPDCL
for FY 2023-24, the revenue deficit/(surplus) of CSPGCL, CSPTCL and CSLDC
arising out of final true-up for FY 2021-22, along with corresponding
carrying/holding cost and the impact of the review filed by CSPDCL on the tariff
order for FY 2022-23, have been considered.

8.

After applying the carrying cost on revenue deficit of Rs. 447.95 Crore of CSPGCL
for FY 2021-22, the total revenue deficit up to FY 2023-24 has been approved as
Rs. 538.04 Crore, as claimed by CSPGCL.

9.

In this order, the Commission has trued-up the capital cost and also determined the
input price of coal from Gare Palma -III mines, for FY 2021-22 as given in the
following Table:
Approved Capital Cost and Input Price of Coal from GP-III mines (Rs. Crore)
Particulars

10.

Unit

FY 2021-22

Capital Cost as on 31.03.2022

Rs. Crore

896.23

Input Price

Rs./MT

1268.29

The Annual fixed Cost (AFC) and Energy Charge Rate for CSPGCL stations
approved by the Commission for FY 2023-24 in its tariff order dated 13.04.2022 are
as under:
Thermal Power Stations
Sl.
No.

Particulars

Units

1

Annual Fixed Cost

2

3

FY 2023-24
HTPS

DSPM

KWTPP

ABVTPP

Rs. Crore

672.77

434.35

580.90

1394.41

Energy Charge Rate
(ex-bus power plant
basis)

Rs./kWh

1.574

1.688

1.339

1.838

Contribution to P&G

Rs. Crore

150.74

55.93

33.48

91.55

CSERC Tariff Order FY 2023-24

iii

<!-- page 4 -->

Hydro Power Station (Hasdeo Bango)
Sl. No.

Particulars

Units

FY 2023-24

1

Approved Annual Fixed Cost Rs. Crore

24.68

2

Approved Net Generation

MU

270.71

3

Approved Tariff

Rs./kWh

0.912

4

Contribution to P&G

Rs. Crore

4.77

The contribution to Pension and Gratuity approved by the Commission shall be
separately billed by CSPGCL on monthly basis.
CSPTCL: Tariff for FY 2023-24
11.

After applying the carrying cost on the revenue deficit of Rs. 42.66 Crore of CSPTCL
for FY 2021-22, the total revenue deficit up to FY 2023-24 has been approved as
Rs. 51.24 Crore, as against the claim of CSPTCL for revenue deficit of Rs. 38.22
Crore.

12.

For CSPTCL, the transmission charge for FY 2023-24 shall be as under:
Sl.
No.

Particulars

Units

FY 2023-24

A

ARR approved vide order dated 13.04.2022 for
FY 2023-24

Rs. Crore

1155.61

B

Add: past year cumulative revenue deficit, with
carrying cost

Rs. Crore

51.24

C

Adjusted ARR for FY 2023-24 (A+B)

Rs. Crore

1206.85

D

Monthly Transmission Charges for Medium-term
and Long-term Open Access Consumers (C/12)

Rs. Crore/

Short-term Open Access Charges

Rs./kWh

E

month

100.57
0.3634

Further, transmission losses of 3% for the energy scheduled for transmission at the
point or points of injection shall be recoverable from Open Access customers.
CSLDC: Charges for FY 2023-24
13.

Similarly, after applying the holding cost on the revenue surplus of Rs. 2.12 Crore of
CSLDC for FY 2021-22, the total revenue surplus up to FY 2023-24 has been
approved as Rs. 2.55 Crore, as against the claim of CSLDC for revenue deficit of
Rs. 1.83 Crore.

iv

CSERC Tariff Order FY 2023-24

<!-- page 5 -->

14.

For CSLDC, the charges for FY 2023-24 shall be as under:
Sr. No.
1

Particulars

Approved (Rs. Crore)

ARR approved vide Order dated
13.04.2022 for FY 2023-24

2

Less: Adjustment of Surplus of FY 202122, with carrying cost

15.

19.55

(2.55)

3

Adjusted ARR for FY 2023-24 (1+2)

17.00

4

System Operation Charges

13.60

5

Intra-State Market Operation Charges

3.40

6

Total SLDC Charges

17.00

The cumulative revenue deficit/(surplus) of CSPGCL, CSPTCL, and CSLDC for FY
2021-22 along with carrying/holding cost amounts to Rs. 586.73 Crore, as against the
claim of Rs. 578.81 Crore by the Companies.
CSPDCL: Tariff for FY 2023-24

16.

CSPDCL has claimed a revenue deficit of Rs. 5319.67 Crore, as against which the
Commission has approved revenue deficit of Rs. 3837.25 Crore for FY 2021-22.
After applying the carrying cost on revenue deficit of FY 2021-22, CSPDCL has
claimed revenue deficit of Rs. 6134.77 Crore. After prudence check and due scrutiny,
the Commission approves Rs. 4321.46 Crore, as against the claim of CSPDCL for
revenue deficit of Rs. 6134.77 Crore after considering the carrying cost.

17.

For FY 2023-24, CSPDCL has sought approval for ARR of Rs. 15,581.14 Crore. As
against this, the Commission, after prudence check and due scrutiny, has approved the
ARR at Rs. 17,228.31 Crore. After considering the ARR and revenue from sale of
electricity for FY 2023-24, the stand-alone revenue surplus for FY 2023-24 has been
estimated as Rs. 1,804.16 Crore, as against the stand-alone revenue surplus of
Rs. 3,763.03 Crore projected by CSPDCL for FY 2023-24.

18.

CSPDCL in its petition has not factored the revenue deficit/surplus of CSPGCL,
CSPTCL and CSLDC for FY 2021-22. After considering the cumulative
deficit/surplus (including carrying cost) claimed by CSPGCL, CSPTCL and CSLDC
for FY 2021-22 in their respective petitions, the net ARR of CSPDCL for FY 2023-24

CSERC Tariff Order FY 2023-24

v

<!-- page 6 -->

works out as Rs. 22,294.71 Crore. The Commission approves the net ARR of Rs.
21,957.00 Crore for FY 2023-24, which includes the approved revenue
deficit/(surplus) of CSPGCL, CSPTCL, and CSLDC.
19.

The adjusted Average Cost of Supply (ACoS) approved for FY 2022-23 was Rs.
6.22/kWh. The adjusted ACoS has been approved as Rs. 6.58/kWh for FY 2023-24.

20.

CSPDCL has projected a net deficit of Rs. 2371.73 Crore for FY 2023-24 in which
they have not considered the cumulative deficit/surplus of Rs. 578.81 Crore claimed
by CSPGCL, CSPTCL and CSLDC for FY 2021-22 in their respective petitions.

21.

Considering the cumulative deficit of Rs. 578.81 Crore claimed by CSPGCL,
CSPTCL and CSLDC in their respective petitions, the effective revenue deficit of
CSPDCL works out as Rs. 2950.54 Crore. As against this, the Commission has
arrived at cumulative revenue deficit of Rs. 2924.53 Crore for CSPDCL for FY 202324 which includes the approved cumulative revenue deficit of Rs. 586.73 Crore of
CSPGCL, CSPTCL and CSLDC.

22.

The primary objective of the Commission is to protect the interest of the consumers
and at the same time ensuring recovery of reasonable and justified cost of the utilities.
The Commission in the previous orders as well as this order has taken various steps to
balance the interest of consumers and utilities.

23.

The CSPDCL, in its petition, has not proposed any tariff hike, however, in its
subsequent submissions, CSPDCL requested for rationalized tariff for all consumer
categories required to meet the approved deficit.

24.

In order to recover the cumulative revenue deficit of Rs. 2924.53 Crore and for tariff
rationalisation, the Commission has taken the following measures for FY 2023-24:

vi

a)

The ToD tariffs have been rationalized. The rebate during off-peak hours is
revised to 20% and additional charges during peak hours have been retained as
20%.

b)

The tariff for 220 kV and 132 kV sub-categories under HV-4 Steel category
have been rationalized, in line with the voltage-wise tariff differential
philosophy adopted for other categories.

CSERC Tariff Order FY 2023-24

<!-- page 7 -->

c)

The discount of 10% on Energy Charges provided for exclusive Oxygen plants
connected up to 33 kV supply voltage under HV-3 category has been
withdrawn.

d)

The discount of 25% on Energy Charges provided for Textile industries
including handlooms and powerlooms, Jute industries, and ethanol industries
categories under HV-3 category has been withdrawn.

e)

The monthly power-off (non-supply) hours to be considered for HV-4 Steel
category calculation of Load Factor has been rationalized to „Nil‟ hours for
industries connected at 220 kV and 132 kV voltage, and rationalized to 30 hours
for industries connected at 33 kV and 11 kV voltage.

f)

“Mines with stone crusher unit” and “Mixer and/or stone crushers” have been
included in LV-5: L.V. Industry Tariff Category.

g)

“Mixer and/or stone crushers” have been moved to HV-2 (Mines Tariff
Category) from earlier HV-3 (Other Industrial and General Purpose NonIndustrial Tariff) Category.

h)

A new sub-category “Saw mill with carpenters and furniture makers” has been
introduced and included in LV-2: Non-Domestic Tariff Category.

i)

The discount on Energy Charges applicable for private clinics, hospitals and
nursing homes including X-ray plant, diagnostic centres and pathological labs,
situated in rural areas as defined by Government of Chhattisgarh and all areas in
Bastar avem Dakshin Kshetra Adivasi Vikas Pradhikaran, and Sarguja avem
Uttar Kshetra Adivasi Vikas Pradhikaran Notified Vide Order dated August 22,
2005, under LV-2 and HV-3 categories has been reduced from 7% to 5%.

j)

The discount on Energy Charges applicable for HV-4 Steel industries situated in
Bastar avem Dakshin Kshetra Adivasi Vikas Pradhikaran and Sarguja avem
Uttar Kshetra Adivasi Vikas Pradhikaran has been reduced from 7% to 5%.

25.

Based on the above-elaborated tariff rationalisation measures, it is estimated that
CSPDCL will earn additional revenue in FY 2023-24. However, even after
considering the additional revenue from these tariff rationalisation measures, it is
estimated that revenue deficit of around Rs. 2528 Crore for FY 2023-24 will remain
unmet.

CSERC Tariff Order FY 2023-24

vii

<!-- page 8 -->

26.

The Commission is likely to introduce the Fuel and Power Purchase Adjustment
Surcharge (FPPAS) formula consistent with the Electricity (Amendment) Rules,
2022, notified by Central Govt., which may be made effective from April 1, 2023.
Further, the Commission also decides that FPPAS shall be applicable on the energy
charge.

27.

The standalone ACOS for FY 2023-24 has been estimated as Rs. 5.62/kWh. The
adjusted ACoS for FY 2023-24 has been estimated as Rs. 6.58/kWh. The Average
Billing Rate (ABR) for FY 2023-24 with existing tariffs is estimated to be Rs.
6.21/kWh. Considering the tariff rationalisation measures, the estimated ABR for FY
2023-24 works out as Rs. 6.34/kWh which is higher than the ABR with the existing
tariff, i.e., Rs. 6.21/kWh with prevailing terms and conditions of tariff. The ABR for
FY 2023-24 is significantly higher than the standalone ACOS of FY 2023-24, thereby
indicating that the expenses of FY 2023-24 will be met, and the shortfall would be
only in meeting the revenue deficit due to true-up of FY 2021-22.

28.

Further, it may be noted that the quantum of unmet revenue requirement for FY 202324 is only an estimate at this stage, and the actual revenue deficit/(surplus), if any,
shall be addressed at the time of true-up for FY 2023-24.

29.

The approved Tariff Schedule applicable is appended herewith as Schedule.

30.

The Order will be applicable from 1st April, 2023 and will remain in force till March
31, 2024 or till the issue of the next Tariff Order, whichever is later.

31.

The Commission directs the Companies to take appropriate steps to implement the
Tariff Order.

Sd/(PRAMOD KUMAR GUPTA)
MEMBER

viii

Sd/(VINOD DESHMUKH)
MEMBER (JUDICIAL)

Sd/(HEMANT VERMA)
CHAIRMAN

CSERC Tariff Order FY 2023-24

<!-- page 9 -->

LIST OF ABBREVIATIONS
Abbreviation

Description

A&G

Administrative and General

ABR

Average Billing Rate

ADMS

Automatic Demand Management System

AFC

Annual Fixed Charges

AMC

Annual Maintenance Contract

APTEL

Hon‟ble Appellate Tribunal of Electricity

ARR

Annual Revenue Requirement

AT&C

Aggregate Technical and Commercial

BESS

Battery Energy Storage System

BSP

Bhilai Steel Plant

CAGR

Compounded Annual Growth Rates

CEA

Central Electricity Authority

CERC

Central Electricity Regulatory Commission

CGS

Central Generating Stations

CIP

Capital Investment Plan

COD

Date of Commercial Operation

CPI

Consumer Price Index

CSD

Consumer Security Deposit

CSEB

Chhattisgarh State Electricity Board

CSERC

Chhattisgarh State Electricity Regulatory Commission

CSLDC

Chhattisgarh State Load Despatch Centre

CSPDCL

Chhattisgarh State Power Distribution Company Limited

CSPDCL

Chhattisgarh State Power Distribution Company Ltd

CSPGCL

Chhattisgarh State Power Generation Company Limited

CSPGCL

Chhattisgarh State Power Generation Company Ltd.

CSPHCL

Chhattisgarh State Power Holding Company Limited

CSPTCL

Chhattisgarh State Power Transmission Company Limited

CSPTCL

Chhattisgarh State Power Transmission Company Ltd.

CSPTrCL

Chhattisgarh State Power Trading Company Limited

CTU

Central Transmission Utility

CWIP

Capital Work in Progress

CSERC Tariff Order FY 2023-24

ix

<!-- page 10 -->

Abbreviation

Description

DA

Dearness Allowances

DISCOM

Distribution Company

DPC

Delayed Payment Charges

DPS

Delayed Payment Surcharge

DS

Domestic Service

DSM

Deviation settlement mechanism

DT

Distribution Transformer

EHV

Extra High Voltage

FCA

Fuel Cost Adjustment

FY

Financial Year

GCV

Gross Calorific Value

GFA

Gross Fixed Assets

GoCG

Government of Chhattisgarh

GoI

Government of India

HP

Horse Power

HPO

Hydro Purchase Obligation

HR

Human Resource

HT

High Tension

HV

High Voltage

IDC

Interest During Construction

IoWC

Interest on Working Capital

IPDS

Integrated Power Development Scheme

IPP

Independent Power Producer

kcal

Kilocalorie

kg

Kilogram

km

Kilometer

kV

kilo Volt

kVA

kilo Volt-Ampere

kW

Kilo Watt

kWh

kilo Watt-hour

LV

Low Voltage

M&G

Maintenance and General

x

CSERC Tariff Order FY 2023-24

<!-- page 11 -->

Abbreviation

Description

MAT

Minimum Alternative Tax

MAT

Minimum Alternate Tax

MCLR

Marginal Cost of Fund based Lending Rate

MGR

Merry-Go-Round

ml

Millilitre

MMC

Monthly Minimum Charges

MT

Metric Tonnes

MU

Million Units

MYT

Multi Year Tariff

NTI

Non-Tariff Income

NTPC

National Thermal Power Corporation Ltd.

O&M

Operation and Maintenance

P&G

Pension & Gratuity

PGCIL

Power Grid Corporation of India Limited

PLF

Plant Load Factor

PLR

Prime Lending Rate

PPA

Power Purchase Agreement

PTC

Power Trading Corporation of India Limited

R&M

Repair and Maintenance

RBI

Reserve Bank of India

RDSS

Revamped Distribution Sector Scheme

RE

Renewable Energy

RoE

Return on Equity

RPO

Renewable Purchase Obligation

Rs.

Rupees

RSA

Revenue Sharing Agreement

SAIL

Steel Authority of India Ltd.

SAMAST

Scheduling, Accounting, Metering and Settlement of Transaction

SBI

State Bank of India

SCADA

Supervisory Control and Data Acquisition

SERC

State Electricity Regulatory Commission

SLDC

State Load Despatch Centre

CSERC Tariff Order FY 2023-24

xi

<!-- page 12 -->

Abbreviation

Description

SLM

Straight Line Method

STPS

Super Thermal Power Station

STU

State Transmission Utility

T&D Loss

Transmission and Distribution Loss

ToD

Time of Day

TSAF

Transmission System Availability Factor

TSAF

Transmission Service Agreement

TVS

Technical Validation Session

UDAY

Ujjwal DISCOM Assurance Yojana

UI

Unscheduled Interchange

UI

Unscheduled Interchange

VCA

Variable Cost Adjustment

WLDC

Western Regional Load Despatch Center

WPI

Wholesale Price Index

YoY

Year-on-Year

STPS

Super Thermal Power Station

STU

State Transmission Utility

T&D Loss

Transmission and Distribution Loss

ToD

Time of Day

TSAF

Transmission System Availability Factor

TSAF

Transmission Service Agreement

TVS

Technical Validation Session

UDAY

Ujjwal DISCOM Assurance Yojana

UI

Unscheduled Interchange

VCA

Variable Cost Adjustment

WLDC

Western Regional Load Despatch Centre

WPI

Wholesale Price Index

YoY

Year-on-Year

xii

CSERC Tariff Order FY 2023-24

<!-- page 13 -->

TABLE OF CONTENTS
1 BACKGROUND AND BRIEF HISTORY ...................................................................... 1
1.1
1.2
1.3
1.4
1.5

BACKGROUND ................................................................................................................... 1
THE ELECTRICITY ACT, 2003, TARIFF POLICY AND REGULATIONS .............................. 1
PROCEDURAL HISTORY .................................................................................................... 1
ADMISSION OF THE PETITION AND HEARING PROCESS ................................................... 2
STATE ADVISORY COMMITTEE MEETING ....................................................................... 3

2 HEARING PROCESS, INCLUDING THE COMMENTS MADE BY VARIOUS
STAKEHOLDERS, THE PETITIONERS’ RESPONSES AND VIEWS OF THE
COMMISSION ........................................................................................................................ 4
2.1
2.2
2.3
2.4
2.5

COMMON OBJECTIONS ..................................................................................................... 4
OBJECTIONS ON CSPGCL’S PETITION ............................................................................ 5
OBJECTIONS ON CSPTCL’S PETITION........................................................................... 10
OBJECTIONS ON CSLDC’S PETITION ............................................................................. 10
OBJECTIONS ON CSPDCL’S PETITION .......................................................................... 11

3 DETERMINATION OF INPUT COAL PRICE AT GARE PALMA-III MINE END
FOR ABVTPS ........................................................................................................................ 46
3.1
3.2
3.3
3.4

BACKGROUND ................................................................................................................. 46
CAPITAL COST ................................................................................................................ 50
PROGRESS AGAINST THE MINING PLAN ........................................................................ 63
COMPUTATION OF INPUT PRICE OF COAL ..................................................................... 63

4 TRUE-UP FOR FY 2021-22 FOR CSPGCL ................................................................. 80
4.1 BACKGROUND ................................................................................................................. 80
4.2 GENERATION CAPACITY OF EXISTING GENERATING STATIONS .................................. 80
4.3 PLANT AVAILABILITY FACTOR (PAF) ........................................................................... 81
4.4 AUXILIARY ENERGY CONSUMPTION .............................................................................. 82
4.5 GROSS GENERATION AND NET GENERATION ................................................................ 83
4.6 GROSS STATION HEAT RATE .......................................................................................... 84
4.7 SECONDARY FUEL OIL CONSUMPTION .......................................................................... 85
4.8 TRANSIT LOSS ................................................................................................................. 86
4.9 CALORIFIC VALUE AND PRICE OF FUEL ........................................................................ 87
4.10 FUEL COST ...................................................................................................................... 89
4.11 ANNUAL FIXED CHARGES FOR CSPGCL ...................................................................... 89
4.12 CAPITAL COST AND ADDITIONAL CAPITALISATION ...................................................... 89
4.13 MEANS OF FINANCE FOR ADDITIONAL CAPITALISATION.............................................. 91
4.14 DEPRECIATION ................................................................................................................ 92
4.15 RETURN ON EQUITY ........................................................................................................ 94
4.16 INTEREST AND FINANCE CHARGES ................................................................................ 96
CSERC Tariff Order FY 2023-24

xiii

<!-- page 14 -->

4.17 NORMATIVE OPERATION AND MAINTENANCE (O&M) EXPENSES................................ 97
4.18 PENSION AND GRATUITY CONTRIBUTION .................................................................... 101
4.19 INTEREST ON WORKING CAPITAL ................................................................................ 101
4.20 NON-TARIFF INCOME ................................................................................................... 102
4.21 ASH UTILIZATION EXPENSES ....................................................................................... 104
4.22 STATUTORY CHARGES .................................................................................................. 105
4.23 AGGREGATE REVENUE REQUIREMENT FOR CSPGCL FOR FY 2021-22 ................... 105
4.24 SHARING OF GAINS AND LOSSES .................................................................................. 107
4.25 REVENUE GAP/(SURPLUS) FOR CSPGCL FOR FY 2021-22 ........................................ 111
5 TRUE-UP OF ARR FOR FY 2021-22 FOR CSPTCL ................................................ 113
5.1 BACKGROUND ............................................................................................................... 113
5.2 TRANSMISSION SYSTEM OF CSPTCL .......................................................................... 113
5.3 TRANSMISSION LOSSES ................................................................................................. 114
5.4 OPERATIONS AND MAINTENANCE (O&M) EXPENSES ................................................. 115
5.5 CONTRIBUTION TO PENSION AND GRATUITY FUND .................................................... 123
5.6 GROSS FIXED ASSETS ................................................................................................... 124
5.7 DEPRECIATION .............................................................................................................. 125
5.8 INTEREST ON LOAN ....................................................................................................... 126
5.9 RETURN ON EQUITY (ROE) AND INCOME TAX ............................................................ 127
5.10 INTEREST ON WORKING CAPITAL ................................................................................ 128
5.11 NON-TARIFF INCOME ................................................................................................... 129
5.12 INCENTIVE/PENALTY ON TRANSMISSION SYSTEM AVAILABILITY FACTOR (TSAF) . 129
5.13 AGGREGATE REVENUE REQUIREMENT (ARR) ........................................................... 130
5.14 REVENUE GAP/(SURPLUS) FOR FY 2021-22................................................................. 131
5.15 ADJUSTED ARR FOR FY 2023-24 ................................................................................. 132
5.16 TRANSMISSION CHARGES FOR FY 2023-24 ................................................................. 133
6 TRUE-UP OF ARR FOR FY 2021-22 FOR CSLDC .................................................. 135
6.1 BACKGROUND ............................................................................................................... 135
6.2 ANNUAL CHARGES FOR SLDC ..................................................................................... 135
6.3 OPERATION AND MAINTENANCE (O&M) EXPENSES ................................................... 135
6.4 CONTRIBUTION TO PENSION AND GRATUITY FUND .................................................... 138
6.5 GROSS FIXED ASSETS AND MEANS OF FINANCE .......................................................... 138
6.6 DEPRECIATION .............................................................................................................. 139
6.7 INTEREST ON LOAN ....................................................................................................... 140
6.8 RETURN ON EQUITY (ROE) AND INCOME TAX ............................................................ 141
6.9 INTEREST ON WORKING CAPITAL (IOWC) ................................................................. 141
6.10 NON-TARIFF INCOME ................................................................................................... 142
6.11 AGGREGATE REVENUE REQUIREMENT FOR CSLDC.................................................. 142
6.12 REVENUE FROM CSLDC CHARGES ............................................................................. 143
6.13 REVENUE GAP/(SURPLUS) FOR CSLDC ...................................................................... 143
6.14 SLDC CHARGES FOR FY 2023-24 ................................................................................ 144

xiv

CSERC Tariff Order FY 2023-24

<!-- page 15 -->

7 REVIEW OF ORDER FOR FY 2022-23 FOR CSPDCL ........................................... 146
7.1 BACKGROUND ............................................................................................................... 146
7.2 GROUNDS FOR REVIEW................................................................................................. 147
7.3 DISALLOWANCE OF PROVISIONING OF BANKING OF RS. 488.69 CRORE IN FY 2018-19
CAUSING NEGATIVE IMPACT ON POWER PURCHASE EXPENSES FROM CENTRAL GENERATING
STATIONS BY RS. 388.54 CRORE DURING FY 2019-20 ......................................................... 148
8 TRUE-UP OF FY 2021-22 FOR CSPDCL................................................................... 151
8.1
8.2
8.3
8.4

BACKGROUND ............................................................................................................... 151
ENERGY SALES .............................................................................................................. 151
DISTRIBUTION LOSS AND ENERGY BALANCE .............................................................. 154
INCENTIVE/DISALLOWANCE FOR OVER/UNDER-ACHIEVEMENT OF DISTRIBUTION LOSS
155
8.5 POWER PURCHASE COST .............................................................................................. 159
8.6 O&M EXPENSES ........................................................................................................... 168
8.7 CONTRIBUTION TO PENSION AND GRATUITY .............................................................. 172
8.8 CAPITAL STRUCTURE.................................................................................................... 172
8.9 DEPRECIATION .............................................................................................................. 174
8.10 INTEREST ON LOAN CAPITAL ....................................................................................... 175
8.11 INTEREST ON CONSUMER SECURITY DEPOSIT ............................................................ 176
8.12 INTEREST ON WORKING CAPITAL ................................................................................ 176
8.13 RETURN ON EQUITY ...................................................................................................... 177
8.14 NON-TARIFF INCOME ................................................................................................... 178
8.15 AGGREGATE REVENUE REQUIREMENT ....................................................................... 178
8.16 REVENUE FROM SALE OF POWER ................................................................................. 179
8.17 REVENUE GAP/(SURPLUS) ............................................................................................ 181
9 ARR OF CSPDCL FOR FY 2023-24 ............................................................................ 183
9.1 BACKGROUND ............................................................................................................... 183
9.2 SALES PROJECTIONS ..................................................................................................... 183
9.3 INTER-STATE TRANSMISSION LOSSES ......................................................................... 185
9.4 INTRA-STATE TRANSMISSION LOSSES ......................................................................... 186
9.5 DISTRIBUTION LOSSES .................................................................................................. 186
9.6 ENERGY BALANCE ........................................................................................................ 187
9.7 POWER PURCHASE QUANTUM AND COST .................................................................... 188
9.8 OTHER HEADS OF ARR ................................................................................................. 193
9.9 IMPACT OF APTEL JUDGEMENT ................................................................................. 194
9.10 AGGREGATE REVENUE REQUIREMENT FOR FY 2023-24 ............................................ 195
9.11 REVENUE FROM SALE OF POWER .................................................................................. 196
9.12 STAND-ALONE REVENUE GAP/(SURPLUS) FOR FY 2023-24 ........................................ 198
9.13 CUMULATIVE REVENUE GAP/(SURPLUS) FOR FY 2023-24 ......................................... 198
10 TARIFF PRINCIPLES AND TARIFF DESIGN ........................................................ 200
CSERC Tariff Order FY 2023-24

xv

<!-- page 16 -->

10.1 APPROACH FOR TARIFF FOR FY 2023-24 .................................................................... 200
10.2 VOLTAGE-WISE COST OF SUPPLY FOR FY 2023-24..................................................... 200
10.3 TARIFF PHILOSOPHY FOR FY 2023-24 ......................................................................... 202
10.4 POWER FACTOR INCENTIVE AND SURCHARGE FOR LV CATEGORY ........................... 203
10.5 METHOD OF PAYMENT OF BILLS .................................................................................. 203
10.6 BILLING ON ACCUMULATED METER READING ............................................................. 203
10.7 CATEGORY-WISE TARIFF .............................................................................................. 204
10.8 MINIMUM BILLING DEMAND ........................................................................................ 208
10.9 TIME OF DAY CHARGES ................................................................................................ 208
10.10 WHEELING CHARGES ................................................................................................ 208
10.11 REVENUE AT APPROVED TARIFF .............................................................................. 209
10.12 CROSS-SUBSIDY ......................................................................................................... 210
10.13 CROSS-SUBSIDY SURCHARGE ................................................................................... 210
10.14 FUEL AND POWER PURCHASE ADJUSTMENT SURCHARGE (FPPAS) ...................... 211
10.15 PARALLEL OPERATION CHARGES ............................................................................ 212
10.16 APPLICABILITY OF ORDER........................................................................................ 212
11 TARIFF SCHEDULE FOR FY 2023-24 ...................................................................... 213
11.1 TARIFF SCHEDULE FOR LOW VOLTAGE (LV) CONSUMERS ........................................ 213
11.2 TARIFF SCHEDULE FOR HIGH VOLTAGE (HV) CONSUMERS ...................................... 229
11.3 OPEN ACCESS CHARGES ............................................................................................... 246
12 DIRECTIVES ................................................................................................................. 250
12.1 DIRECTIVE TO CSPDCL .............................................................................................. 250

xvi

CSERC Tariff Order FY 2023-24

<!-- page 17 -->

List of Tables
Table 3-1: Brief Description of GP-III Coal Block ................................................................. 47
Table 3-2: Capital Cost for GP-III mines approved by Commission in MYT Order dated
April 13, 2022 in Petition No. 1 of 2022 on provisional basis (Rs. Crore) ............................. 50
Table 3-3: Actual Capital Cost for GP-III mines based on Audited Accounts of FY 2021-22
vis-a-vis Approved Capital Cost in MYT Order dated April 13, 2022, as submitted by
CSPGCL (Rs. Crore) ............................................................................................................... 52
Table 3-4: IEDC expenses as on CoD (Rs. Crore) .................................................................. 57
Table 3-5: Approved Capital Cost of GP-III Mine for True up of FY 2021-22 (Rs. Crore) ... 61
Table 3-6: Opening GFA, Capitalisation and Closing GFA for GP-III Mines for True up of
FY 2021-22 (Rs. Crore) ........................................................................................................... 62
Table 3-7: Approved Funding of Capitalisation for GP-III Mines for FY 2021-22 (Rs. Crore)
.................................................................................................................................................. 62
Table 3-8: Depreciation Approved for FY 2021-22 (Rs. Crore) ............................................. 66
Table 3-9: Interest on Loan for GP-III mines approved for FY 2021-22 (Rs. Crore) ............. 67
Table 3-10: Approved RoE for GP-III mines for FY 2021-22 (Rs. Crore) ............................. 67
Table 3-11: Approved O&M Expenses for GP-III mines for FY 2021-22 (Rs. Crore)........... 68
Table 3-12: Interest on Working Capital Approved for GP-III mines for FY 2021-22 (Rs.
Crore) ....................................................................................................................................... 69
Table 3-13: Non-Tariff Income Approved for FY 2021-22 (Rs. Crore) ................................. 71
Table 3-14: Statutory Charges for GP-III mines for the Control Period as submitted by
CSPGCL .................................................................................................................................. 72
Table 3-15: Approved Statutory Charges for GP-III mines for FY 2021-22 (Rs. Crore) ....... 72
Table 3-16: Approved MDO Charges for GP-III mines for FY 2021-22 ................................ 73
Table 3-17: Sharing of Gains due to Higher Production Approved for FY 2021-22 between
GP-III Mine and CSPGCL Plants ............................................................................................ 74
Table 3-18: Input Price of Coal from GP-III mines for FY 2021-22 as submitted by CSPGCL
.................................................................................................................................................. 78
Table 3-19: Approved Input Price of Coal from GP-III mines for FY 2021-22 (Rs. Crore)... 78
Table 3-20: Breakup of Approved Input Price of Coal from GP-III mines FY 2021-22 ........ 79
Table 4-1: Generation Capacity (MW) of existing Generating Stations ................................. 81
Table 4-2: Actual PAF for FY 2021-22 as submitted by CSPGCL......................................... 81
Table 4-3: Approved Plant Availability Factor for FY 2021-22 ............................................. 82
Table 4-4: Auxiliary Energy Consumption for FY 2021-22 as submitted by CSPGCL ......... 82
Table 4-5: Approved Auxiliary Energy Consumption for FY 2021-22 .................................. 83
Table 4-6: Actual Gross Generation and Net Generation for FY 2021-22 as submitted by
CSPGCL (MU) ........................................................................................................................ 83
CSERC Tariff Order FY 2023-24

xvii

<!-- page 18 -->

Table 4-7: Approved Gross Generation and Net Generation for FY 2021-22 (MU) .............. 84
Table 4-8: GSHR for FY 2021-22 (kcal/kWh) ........................................................................ 84
Table 4-9: Approved GSHR for FY 2021-22 (kcal/kWh) ....................................................... 85
Table 4-10: SFOC submitted by CSPGCL for FY 2021-22 (ml/kWh) ................................... 85
Table 4-11: Approved SFOC for FY 2021-22 (ml/kWh) ........................................................ 85
Table 4-12: Transit loss as submitted by CSPGCL for FY 2021-22 ....................................... 86
Table 4-13: Approved Transit loss for FY 2021-22 ................................................................ 87
Table 4-14: Actual Calorific Value and Price of fuels for FY 2021-22 .................................. 88
Table 4-15: Approved Calorific Value and Price of fuels for FY 2021-22 ............................. 88
Table 4-16: Actual Fuel Cost for FY 2021-22 (Rs. Crore) ...................................................... 89
Table 4-17: Approved Fuel Cost for FY 2021-22 (Rs. Crore) ................................................ 89
Table 4-18: Approved Additional Capitalisation in true up for FY 2021-22 (Rs. Crore) ...... 91
Table 4-19: Approved Means of Finance for existing stations for FY 2021-22 (Rs. Crore) .. 92
Table 4-20: Depreciation for FY 2021-22 as submitted by CSPGCL (Rs. Crore) .................. 92
Table 4-21: Depreciation approved for CSPGCL for FY 2021-22 (Rs. Crore)....................... 93
Table 4-22: Return on Equity for FY 2021-22 as submitted by CSPGCL (Rs. Crore) ........... 94
Table 4-23: Approved Return on Equity for FY 2021-22 (Rs. Crore) .................................... 95
Table 4-24: Interest & Finance Charges as submitted by CGPGCL for FY 2021-22 (Rs.
Crore) ....................................................................................................................................... 96
Table 4-25: Interest & Finance Charges approved for FY 2021-22 (Rs. Crore) ..................... 97
Table 4-26: CPI and WPI Index considered by CSPGCL ....................................................... 98
Table 4-27: O&M Expenses for FY 2021-22 submitted by CSPGCL (Rs. Crore) ................. 98
Table 4-28: Approved Normative O&M Expenses for FY 2021-22 (Rs. Crore) .................. 100
Table 4-29: Approved O&M Expenses for FY 2021-22 (Rs. Crore) .................................... 101
Table 4-30: Pension and Gratuity Contribution for FY 2021-22 as submitted by CSPGCL
(Rs. Crore).............................................................................................................................. 101
Table 4-31: IoWC for FY 2021-22 as submitted by CSPGCL (Rs. Crore) ........................... 102
Table 4-32: Approved IoWC for CSPGCL for FY 2021-22 (Rs. Crore) .............................. 102
Table 4-33: Non-Tariff Income for FY 2021-22 as submitted by CSPGCL (Rs. Crore) ...... 103
Table 4-34: Approved Non-Tariff Income in True-up for FY 2021-22 (Rs. Crore) ............. 104
Table 4-35: Ash Utilization Expenses as approved (Rs. Crore) ............................................ 104
Table 4-36: Approved ARR for CSPGCL‟s Generating Stations for FY 2021-22 (Rs. Crore)
................................................................................................................................................ 106
Table 4-37: Approved Sharing of Gains and Losses for final True-up for FY 2021-22 for
CSPGCL‟s Generating Stations ............................................................................................. 108

xviii

CSERC Tariff Order FY 2023-24

<!-- page 19 -->

Table 4-38: Revenue Gap/(Surplus) after True-up for FY 2021-22 for CSPGCL (Rs. Crore)
................................................................................................................................................ 111
Table 4-39: Revenue Gap after True-up for FY 2021-22 for CSPGCL along with carrying
cost (Rs. Crore) ...................................................................................................................... 112
Table-5-1: Physical status of transmission system of CSPTCL as on March 31, 2022......... 114
Table 5-2: Transmission Losses for FY 2021-22 as submitted by CSPTCL (MU)............... 114
Table 5-3: Gross Employee Expenses for FY 2021-22 as submitted by CSPTCL
(Rs.
Crore.) .................................................................................................................................... 115
Table 5-4: Employee strength of CSPTCL as on 31st March 2022 ....................................... 115
Table 5-5: Gross R&M expenses and A&G expenses for FY 2021-22 as submitted by
CSPTCL (Rs. Crore) .............................................................................................................. 116
Table 5-6: O&M Expenses as submitted by CSPTCL for FY 2021-22 (Rs. Crore) ............. 117
Table 5-7: Additional Normative O&M Expenses as submitted by CSPTCL for FY 2021-22
(Rs. Crore.)............................................................................................................................. 118
Table 5-8: Revised Normative A&G Expenses and R&M Expenses as submitted by CSPTCL
for FY 2021-22 (Rs. Crore) ................................................................................................... 118
Table 5-9: Sharing of gain/(loss) on A&G Expenses and R&M expenses as submitted by
CSPTCL for FY 2021-22 (Rs. Crore.) ................................................................................... 119
Table 5-10: Details of Outsourced Expenses (Rs. Crore) ...................................................... 119
Table 5-11: Computation of Additional A&G expenses and R&M expenses for FY 2021-22
(Rs. Crore).............................................................................................................................. 121
Table 5-12: Approved Normative A&G Expenses and R&M Expenses for FY 2021-22 (Rs.
Crore) ..................................................................................................................................... 122
Table 5-13: Approved Actual Employee Expenses for FY 2021-22 (Rs. Crore) .................. 122
Table 5-14: Approved Actual A&G Expenses and R&M Expenses for FY 2021-22
(Rs.
Crore) ..................................................................................................................................... 122
Table 5-15: Sharing of gain/(loss) on A&G Expenses and R&M expenses for FY 2021-22 as
approved by the Commission (Rs. Crore).............................................................................. 123
Table 5-16: Contribution to P&G Fund for FY 2021-22 as approved by the Commission (Rs.
Crore) ..................................................................................................................................... 123
Table 5-17: Approved GFA Addition and Means of Finance for FY 2021-22 (Rs. Crore) .. 125
Table 5-18: Approved Depreciation for FY 2021-22 (Rs. Crore) ......................................... 125
Table 5-19: Approved Interest on Loan for FY 2021-22 (Rs. Crore) .................................... 127
Table 5-20: Approved Return on Equity for FY 2021-22 (Rs. Crore) .................................. 127
Table 5-21: Approved Interest on Working Capital for FY 2021-22 (Rs. Crore) ................. 128
Table 5-22: Approved Non-Tariff Income for FY 2021-22 (Rs. Crore) ............................... 129
Table 5-23: Approved Incentive for Higher Transmission System Availability for FY 202122 (Rs. Crore)......................................................................................................................... 130
CSERC Tariff Order FY 2023-24

xix

<!-- page 20 -->

Table 5-24: Approved ARR after true-up for FY 2021-22 (Rs. Crore) ................................. 130
Table 5-25: Revenue Gap/(Surplus) submitted by CSPTCL for FY 2021-22 (Rs. Crore) .... 131
Table 5-26: Approved Revenue Gap/(Surplus) for FY 2021-22 (Rs. Crore) ........................ 132
Table 5-27: Cumulative Gap/(Surplus) submitted by CSPTCL for FY 2023-24 (Rs. Crore)132
Table 5-28: Adjusted approved ARR for FY 2023-24 (Rs. Crore) ....................................... 133
Table 5-29: Approved STOA Charges submitted by CSPTCL for FY 2023-24 (Rs. Crore) 134
Table 6-1: O&M Expenses for FY 2021-22 (Rs. Crore) ....................................................... 135
Table 6-2: Employee strength of CSLDC as on 31st March 2022 ......................................... 136
Table 6-3: Normative A&G Expenses and R&M Expenses for FY 2021-22 as submitted by
CSLDC (Rs. Crore) ................................................................................................................ 136
Table 6-4: Sharing of gain/(loss) on A&G expenses and R&M expenses for FY 2021-22 as
submitted by CSLDC (Rs. Crore) .......................................................................................... 137
Table 6-5: Approved Normative O&M Expenses for FY 2021-22 (Rs. Crore) .................... 137
Table 6-6: Sharing of gain/(loss) on A&G expenses and R&M expenses for FY 2021-22 as
approved by the Commission (Rs. Crore).............................................................................. 138
Table 6-7: Gross Fixed Assets and its Funding for FY 2021-22 for CSLDC as approved by
the Commission (Rs. Crore) .................................................................................................. 139
Table 6-8: Depreciation for FY 2021-22 for CSLDC as approved by the Commission (Rs.
Crore) ..................................................................................................................................... 139
Table 6-9: Interest on Loan for FY 2021-22 for CSLDC approved by Commission (Rs.
Crore) ..................................................................................................................................... 140
Table 6-10: Return on Equity for FY 2021-22 for CSLDC as approved by Commission (Rs.
Crore) ..................................................................................................................................... 141
Table 6-11: IoWC approved for FY 2021-22 for CSLDC by the Commission (Rs. Crore). 142
Table 6-12: Aggregate Revenue Requirement (ARR) for FY 2021-22 approved by the
Commission (Rs. Crore) ........................................................................................................ 143
Table 6-13: Revenue Gap/(Surplus) for FY 2021-22 as submitted by CSLDC (Rs. Crore) 144
Table 6-14: Revenue Gap/(Surplus) for FY 2021-22 for CSLDC as approved by the
Commission (Rs. Crore) ........................................................................................................ 144
Table 6-15: SLDC Charges claimed by CSLDC for FY 2023-24 (Rs. Crore) ...................... 145
Table 6-16: Adjusted ARR and SLDC Charges approved for FY 2023-24 (Rs. Crore) ....... 145
Table 8-1: Approved Energy Sales for FY 2021-22 (MU) .................................................... 153
Table 8-2: Energy Balance for FY 2021-22 as submitted by CSPDCL (MU) ...................... 154
Table 8-3: Approved Energy Balance and Distribution Loss for FY 2021-22 ...................... 155
Table 8-4: Sharing of Loss on account of underachievement of Distribution loss for FY 202122 as submitted by CSPDCL (Rs. Crore) .............................................................................. 156
Table 8-5: Revised Sharing of Loss on account of underachievement of Distribution loss for
FY 2021-22 as submitted by CSPDCL (Rs. Crore) ............................................................... 158
xx

CSERC Tariff Order FY 2023-24

<!-- page 21 -->

Table 8-6: Sharing of Loss approved by the Commission on account of underachievement of
Distribution loss for FY 2021-22 (Rs. Crore) ........................................................................ 159
Table 8-7: Details of „Other Charges‟ under CGS Power Purchase for FY 2021-22 (Rs.
Crore) ..................................................................................................................................... 161
Table 8-8: Revenue from Sale of Power as approved by the Commission ........................... 165
Table 8-9: Approved Power Purchase Cost after True-up for FY 2021-22 (Rs. Cr.) ............ 166
Table 8-10: Actual O&M expenses as submitted by CSPDCL (Rs. Cr.) .............................. 168
Table 8-11: Details of contract services as submitted by CSPDCL (Rs. Cr.) ....................... 168
Table 8-12: Actual O&M expenses as considered by the Commission (Rs. Crore).............. 169
Table 8-13: Revised Normative R&M and A&G Expenses for FY 2021-22 (Rs. Crore) ..... 171
Table 8-14: Sharing of (Gain)/Loss for FY 2021-22 (Rs. Cr.) .............................................. 172
Table 8-15: Capital Structure for FY 2021-22 as submitted by CSPDCL (Rs. Crore) ......... 173
Table 8-16: Approved GFA and Funding for FY 2021-22 (Rs. Crore) ................................. 174
Table 8-17: Approved Depreciation for FY 2021-22 (Rs. Crore) ......................................... 175
Table 8-18: Approved Interest Expenses for FY 2021-22 (Rs. Crore) .................................. 176
Table 8-19: Approved Interest on CSD for FY 2021-22 (Rs. Crore) .................................... 176
Table 8-20: Approved IoWC for FY 2021-22 (Rs. Crore) .................................................... 177
Table 8-21: Approved RoE for FY 2021-22 (Rs. Crore) ....................................................... 178
Table 8-22: Approved Non-Tariff Income for FY 2021-22 (Rs. Crore) ............................... 178
Table 8-23: Approved ARR for FY 2021-22 (Rs. Crore) ...................................................... 179
Table 8-24: Additional Revenue from Agriculture Category for FY 2021-22 ...................... 180
Table 8-25: Approved Revenue for FY 2021-22 (Rs. Crore) ................................................ 181
Table 8-26: Approved Revenue Gap/(Surplus) for FY 2021-22 (Rs. Crore) ........................ 182
Table 9-1: Category-Wise Sales Projected by CSPDCL for FY 2023-24 ............................. 184
Table 9-2: Approved Category-Wise Sales for FY 2023-24 (MU) ....................................... 185
Table 9-3: Approved Distribution Losses for FY 2023-24 (%) ............................................. 187
Table 9-4: Energy Balance Projected by CSPDCL for FY 2023-24 (MU) ........................... 187
Table 9-5: Approved Energy Balance for FY 2023-24 ......................................................... 188
Table 9-6: RPO Target for FY 2023-24 (%) .......................................................................... 189
Table 9-7: RE Capacity Addition envisaged for FY 2023-24 ............................................... 190
Table 9-8: Approved Power Purchase Quantum and Cost for FY 2023-24 .......................... 192
Table 9-9: Other Components of ARR as claimed by CSPDCL for FY 2023-24 ................. 193
Table 9-10: Impact of APTEL Judgment allowed in FY 2023-24 (Rs. Crore) ..................... 195
Table 9-11: Approved ARR for CSPDCL for FY 2023-24 (Rs. Crore) ................................ 195

CSERC Tariff Order FY 2023-24

xxi

<!-- page 22 -->

Table 9-12: Revenue from sale of power at existing tariff for FY 2023-24 as submitted by
CSPDCL (Rs. Crore) ............................................................................................................. 196
Table 9-13: Revenue from sale of power at existing tariff for FY 2023-24 as computed by the
Commission (Rs. Crore) ........................................................................................................ 197
Table 9-14: Standalone Revenue Gap/(Surplus) for FY 2023-24 (Rs. Crore) ...................... 198
Table 9-15: Cumulative Revenue Gap/(Surplus) for CSPDCL for FY 2023-24 as submitted
by CSPDCL (Rs. Crore) ........................................................................................................ 198
Table 9-16: Cumulative Revenue Gap/(Surplus) for CSPDCL for FY 2023-24 as approved by
the Commission (Rs. Crore) .................................................................................................. 199
Table 10-1: Average Cost of Supply (Rs./kWh) for CSPDCL for FY 2023-24 ................... 200
Table 10-2: VCoS for FY 2023-24 as calculated by Commission ........................................ 201
Table 10-3: Revenue in FY 2023-24 at Tariffs approved by the Commission ...................... 209
Table 10-4: Cross-subsidy with Existing tariff and Approved tariff ..................................... 210

xxii

CSERC Tariff Order FY 2023-24

<!-- page 23 -->

1

BACKGROUND AND BRIEF HISTORY

1.1

Background
The Chhattisgarh State Electricity Board (CSEB) was restructured by the Government
of Chhattisgarh (GoCG) in pursuance of the provisions of Part XIII of the Electricity
Act, 2003. GoCG, vide notification No. 1-8/2008/13/1 dated December 19, 2008. The
erstwhile CSEB was unbundled into five different Companies, viz., Chhattisgarh State
Power Generation Company Limited (CSPGCL), Chhattisgarh State Power
Transmission Company Limited (CSPTCL), Chhattisgarh State Power Distribution
Company Limited (CSPDCL), Chhattisgarh State Power Trading Company Limited
(CSPTrCL), and Chhattisgarh State Power Holding Company Limited (CSPHCL).
The assets and liabilities of the erstwhile CSEB have been allocated to the successor
Companies w.e.f. January 1, 2009 according to the provisions of the CSEB Transfer
Scheme Rules, 2010.

1.2

The Electricity Act, 2003, Tariff Policy and Regulations
Section 61 of the Electricity Act, 2003 (herein after referred as „the EA, 2003‟ or „the
Act‟) stipulates the guiding principles for determination of tariff by the Commission
and mandates that the tariff should progressively reflect the cost of supply of
electricity, reduce cross subsidy, safeguard consumers interest and recover the cost of
electricity in a reasonable manner. This Section also stipulates that the Commission
while framing the Tariff Regulations shall be guided by the principles and
methodologies specified by the Central Electricity Regulatory Commission for
determination of the tariff applicable to generating companies and transmission
licensees.
Section 62 of the Act stipulates that the Commission shall determine the tariff for:


Supply of electricity by a Generating Company to a Distribution Licensee;



Transmission of electricity;




Wheeling of electricity; and
Retail sale of electricity.

The Tariff Policy notified by the Government of India in January 2006, as well as the
amended Tariff Policy notified in January 2016, provides the framework to balance
the conflicting objectives of attracting investments to ensure availability of quality
power and protecting the interest of consumers by ensuring that the electricity tariffs
are affordable.
1.3

Procedural History
The Commission notified the Chhattisgarh State Electricity Regulatory Commission
(Terms and Conditions for determination of tariff according to Multi-Year Tariff
principles and Methodology and Procedure for determination of Expected revenue
from Tariff and Charges) Regulations, 2015 (hereinafter referred to as CSERC MYT
Regulations, 2015) on September 9, 2015 for the Control Period from FY 2016-17 to
FY 2020-21. The Commission vide public notice CSERC letter 03/CSERC/Tariff
2020/1228 dated November 26, 2020 has notified the extension of CSERC MYT

CSERC Tariff Order FY 2023-24

1

<!-- page 24 -->

Regulations, 2015 for the next year, i.e., 2021-22. Accordingly, CSPGCL, CPSTCL
and CSLDC had filed Petitions for final true-up for FY 2019-20 and ARR for FY
2021-22 while CSPDCL filed Petitions for final true-up for FY 2018-19 and FY
2019-20 and ARR & Retail Supply Tariff for FY 2021-22 for which the Commission
issued order on August 02, 2021.
Further, the Commission notified the Chhattisgarh State Electricity Regulatory
Commission (Terms and Conditions for determination of tariff according to MultiYear Tariff principles and Methodology and Procedure for determination of Expected
revenue from Tariff and Charges) Regulations, 2021 (hereinafter referred as 'CSERC
MYT Regulations, 2021') for determination of tariff for the Generating Company,
Licensees, and CSLDC.
In accordance with CSERC MYT Regulations 2015 and CSERC MYT Regulations
2021, CSPGCL filed the Petition for approval of final true-up for FY 2021-22 on
15/12/2022 which was registered as Petition No. 102 of 2022. CSPTCL filed the
Petition for approval of final true-up for FY 2021-22 and determination of
transmission tariff for FY 2023-24 on 30/11/2022 which was registered as Petition
No. 94 of 2022. Also, CSLDC filed the Petition for approval of final true-up for FY
2021-22 and determination of SLDC charges for FY 2023-24 on 12/12/2022, which
was registered as Petition No.100 of 2022. CSPDCL filed the Petition for approval of
final true-up for FY 2021-22, and determination of ARR and Retail Supply Tariff for
FY 2023-24 on 28/11/2022, which was registered as Petition No. 95 of 2022.
In this instant Order, the Commission has undertaken the final true-up for FY 2021-22
in accordance with the provisions of the MYT Regulations, 2015 and determination of
Tariff for FY 2023-24 for CSPTCL, CSLDC and CSPDCL in accordance with the
provisions of the MYT Regulations, 2021.
1.4

Admission of the Petition and Hearing Process
The Petitions filed by CSPDCL, CSPTCL, CSLDC, and CSPGCL were registered on
01/12/2022, 01/12/2022, 14/12/2022 and 15/12/2022 respectively.
The Companies were directed to publish the abridged version of the Petition in Hindi
and English newspapers for inviting comments/objections/suggestions from all the
stakeholders. The Petitions were made available on the website of the Commission as
well as on the Petitioners' websites. As required under Clause 21 of the CSERC
(Details to be furnished by licensee etc.) Regulations, 2004, notices inviting
comments/objections/suggestions from the stakeholders on the above proposals, were
published by the Petitioners in the leading newspapers of the State.
A period of twenty-one (21) days was given for submission of written objections and
suggestions by the public. The Companies were also directed to submit written replies
to the Commission with copies endorsed to the objectors.
In order to have better clarity on the data submitted by the Petitioners and to remove
inconsistency in the data, the Technical Validation Sessions (TVS) were held on
24/01/2023 and 25/01/2023 with the Petitioners. During the TVS, additional
information required for processing of the Petitions was sought from the Petitioners.
The Petitioners submitted the additional information sought during TVS.

2

CSERC Tariff Order FY 2023-24

<!-- page 25 -->

The objections and suggestions from stakeholders were received on the Petitions filed
by CSPGCL, CSPTCL, CSPDCL and CSLDC. The list of persons who filed the
written submissions is annexed as Annexure-I.
Public hearing was held on 21/02/2023 and 22/02/2023. The Commission has ensured
that the due process as contemplated under the law to ensure transparency and public
participation was followed at every stage and adequate opportunity was given to all
the persons to offer their views. The list of persons who submitted comments during
the hearing is annexed as Annexure-II.
The issues raised by the stakeholders along with the response of the Petitioners‟ and
views of the Commission are elaborated in Chapter 2 of this order.
1.5

State Advisory Committee Meeting
A copy of the abridged Hindi and English version of the Petitions were also sent to all
the members of the State Advisory Committee of the Commission for their comments.
A meeting of the State Advisory Committee was convened on 20 February, 2023 to
discuss the Petitions and seek inputs from the Committee. CSPGCL, CSPTCL,
CSLDC and CSPDCL gave presentations in the meeting on the salient features of
their petitions. Various aspects of the petitions were discussed by the Members of the
Committee in the meeting. The list of the SAC Members who participated in the
meeting in annexed as Annexure III.
The following suggestions and objections were submitted:
a) CSPDCL should refrain from signing any further PPA because it has already
signed more than sufficient PPAs and is unable to sell the same.
b) Surplus power available with CSPDCL should be utilized for manufacturing
Hydrogen.
c) The Commission should consider Aggregate Technical and Commercial
(AT&C) loss to evaluate the performance of CSPDCL.
d) CSPDCL should not write-off the arrears of consumers.
e)

CSPDCL should prepare action plan for utilization of excess solar injection in
near future.

f)

CSPDCL should be directed to meet its RPO target.

CSERC Tariff Order FY 2023-24

3

<!-- page 26 -->

2

HEARING PROCESS, INCLUDING THE COMMENTS MADE BY VARIOUS
STAKEHOLDERS, THE PETITIONERS’ RESPONSES AND VIEWS OF THE
COMMISSION

2.1

Common Objections

2.1.1 Contribution to Pension and Gratuity Fund
The objector submitted that companies have contributed Rs. 546.34 Crore to the
pension trust in FY 2022-23. It is pertinent to mention here that total contribution of
Rs. 706.65 Crore was to be submitted in the pension trust during FY 2022-23.
Therefore, an amount of Rs. 160.31 Crore has yet to be submitted to the pension trust.
In this context, objector has requested the Commission to direct the State Power
Companies to deposit the short fall amount on priority basis.
Another objector submitted that in the true-up petitions filed by CSPGCL, CSPTCL
and CSPDCL, expenses towards Pension and Gratuity liability has been restricted to
the amount of contribution made in pension trust on actual basis whereas they have
accounted revenue from operation on accrual basis.
The objector further submitted that this deliberate attempt of claiming less than actual
in true-up and estimating lesser expenses than what it should be is causing undue
benefit to present consumers, at the cost of reduction in corpus of Gratuity and
Pension Fund. This is creating uncertainty among employees of State Power
Companies and will burden the future consumers. Total corpus of the Gratuity and
Pension Fund was around Rs. 5000 crore as on 31/03/2018, which has reduced to
Rs. 4700 crore as on 31/03/2022. And this reduction in corpus happened when there is
already huge deficit of around Rs. 10,000 crore as per latest actuarial analysis.
The objector requested the Commission that during true-up of ARR of previous years,
the expenses towards payment of pension and gratuity should be considered on the
basis of actual outflow from the Gratuity and Pension Fund with carrying cost and not
on the basis of contribution to the fund by State Power Companies. The objector also
requested that ARR for future years of all State Power Companies should be approved
by considering appropriate estimation of the expenses towards payment of retirement
benefits for Gratuity and Pension for all the retirees or pensioners of the State Power
Companies. Some additional allocation to the fund should also be made in the ARR to
reasonably fill the gap or deficit of the Gratuity and Pension Fund between actual
available fund and requirement of fund as per actuarial analysis/ valuations so that
deficit of previous years can be filled up.
Another Objector has requested the Commission to make such provision in relation to
contribution to the pension trust so that a corpus of Rs. 18,000 Crore can be created.
Petitioner’s Reply
CSPGCL, CSPTCL and CSLDC have submitted that they have deposited full amount
to the pension trust during FY 2022-23 as per the tariff order. CSPDCL has submitted
that it has deposited full contribution as specified in the tariff order for FY 2022-23 in
the month of December 2022.
CSPDCL submitted that it is contributing to Pension and Gratuity Trust Fund in the
manner approved by the State Commission in its tariff order time to time. As per the
4

CSERC Tariff Order FY 2023-24

<!-- page 27 -->

tariff order dtd. 02.10.2021, the Commission has approved contribution towards
pension and gratuity amount to Rs. 449.48 Crore and CSPDCL has contributed to a
same amount of contribution towards pension and gratuity. CSPDCL submitted that
the matter (corpus of Rs. 18000 Crore) is not related to present petition.
Commission’s View
The instant petition pertains to true up for FY 2021-22 for which the CSERC MYT
Regulations, 2015 are applicable and Regulation 32 of the CSERC MYT Regulations,
2015 specifies that the contribution to the fund shall be decided by the Commission
on the basis of actuarial analysis, expected pension outflow for the State Power
Companies and availability of fund with the pension trust. Accordingly, the
Commission has allowed the contribution to fund as approved in this Order.
2.2

Objections on CSPGCL’s petition

2.2.1 Capacity Charges for Marwa TPP/ ABVTPP
The objector, submitted that the average cost of generation claimed by CSPGCL for
FY 2021-22 is substantially high, hence the purchase of power from Marwa TPP for
retail sale is inflating retail tariff. The actual Station Heat Rate and Auxiliary
Consumption is higher than the approved values and all such inefficiency is
increasing the cost of generation. The objector submitted that during FY 2021-22, the
PAF of Marwa TPP was only 54.67%, against the approved PAF of 76.5%. CSPGCL
has claimed capacity charges of Rs. 1513.78 crore as against the approval of Rs.
1526.18 Crore. The objector stated that based on the actual Plant Availability Factor
(PAF), CSPGCL has claimed an excess capacity charge of Rs. 423.11 crore. The
objector prayed for not allowing the excess capacity charges of Rs. 423.11 crore
during FY 2021-22.
Petitioner’s Reply
CSPGCL submitted that the CSERC Regulations provide specific mechanism for
dealing with under / over performance by any entity. CSPGCL in its true-up petition
has followed the Regulations without any deviation. The objector has pleaded for
circumventing the Regulations which is not acceptable.
Commission’s View
On account of lower actual PAF as compared to normative PAF, CSPGCL, in
accordance with the CSERC MYT Regulations, 2015, has claimed lower Fixed
Charges of ABVTPP. The Commission has also followed the CSERC MYT
Regulations, 2015 while approving fixed charges for FY 2021-22 considering sharing
of gains/losses, the details of which are provided in subsequent Chapter of this Order.
Landed Price and GCV of coal for Marwa TPP/ ABVTPP
Further, the objector stated that under Form 15B for Marwa TPP, CSPGCL has
submitted that landed price of coal is lower than the approved landed price and GCV
of coal is equal to the approved GCV. CSPGCL has recovered Rs. 57 Crore on
account of Fuel Cost Adjustment (FCA) from consumers of the State without any
increase in fuel cost.

CSERC Tariff Order FY 2023-24

5

<!-- page 28 -->

The objector further requested not to load on retail consumers any under recovery (Rs.
172.91 crore) from sale of power to TSDISCOMs and prudently examine the FCA
and VCA charges determined by CSPGCL and CSPDCL before recovery from
consumers.
Petitioner’s Reply
CSPGCL submitted that the contentions of the objector are incorrect. Table 7-14 of
the Tariff Order for FY 2021-22 (Page 218) shows that at the time of Tariff Order, the
GCV of coal was considered as 3631 kcal/kg and the landed price of coal was
considered as Rs. 1990.87/MT. At the time of true up the uncontrollable parameters
such as GCV of coal and landed price of coal get substituted by the actual values
instead of the projected values. Therefore, in the format 15B, the actual GCV of coal
of 3470 kcal/kg has been considered. Similarly, the actual landed price of coal of Rs.
2272.04/MT has been considered. Further, as the actual transit loss was lower than the
normative, following the precedence set in the previous Tariff Orders, CSPGCL has
claimed actual landed price of coal at a lower value of Rs. 2270.61/MT. In view of the
above, CSPGCL requested the Commission that all the prayers made by the objector
may be rejected.
Commission’s View
The Commission has done prudence check on the submission of CSPGCL and has
accordingly approved the coal cost in line with the provisions of CSERC MYT
Regulations, 2015 and as per the settled methodology adopted in previous Tariff
Orders.
2.2.2 Cost of Coal
The Objector submitted that CSPGCL has not provided consolidated quantum and
cost of coal consumed, in its True-up Petition for FY 2021-22. Also, claim against
cost of coal and net generation in the True-up Petition are not matching with the
figures as per Audited Balance Sheet of FY 2021-22. The Objector requested the
Commission to direct CSPGCL to submit reconciled data in the True-up Petition for
FY 2021-22 to carry out proper True-up exercise.
Petitioner’s Reply
CSPGCL denied that there is any infirmity in claiming coal cost and net Generation.
CSPGCL submitted that the coal cost has been computed as per settled methodology
approved by the Commission in all previous Tariff Orders. While the accounting cost
is determined in accordance with moving average price of coal, for regulatory purpose
the rate is determined on the basis of replacement price (determined on the basis of
landed rate of the coal during the year). Further, in the regulatory computation, the
landed cost of coal includes all the costs incurred in transportation. In the financial
accounts, the cost incurred on employees, A&G and R&M of external CHP is part of
O&M cost and not the fuel cost. It is for this reason that for each plant the O&M cost
incurred on coal transportation is added in the landed cost computation and is
deducted from the O&M cost. CSPGCL also submitted that for determination of
landed cost of coal, all relevant data has been submitted along with the bimonthly
FCA calculations.
6

CSERC Tariff Order FY 2023-24

<!-- page 29 -->

Regarding the difference in net generation in the accounts and in the True up Petition,
CSPGCL submitted that net generation in Accounts refer to the scheduled energy,
whereas net generation as per True up Petition refers to actual net generation. In
support of both the data, CSPGCL has already submitted the DSM statement certified
by CSLDC. CSPGCL submitted that in the last decade these issues have been dealt by
the Commission in number of cases and the regulatory practice has been consistent
for more than a decade. Therefore, the objection may also be considered barred by the
principle of res-judicata.
Commission’s View
The Commission has done prudence check on the submission of CSPGCL and has
accordingly approved the coal cost and net generation in line with the provisions of
CSERC MYT Regulations, 2015 and as per the settled methodology adopted in
previous Tariff Orders.
2.2.3 Operational Parameters for CSPGCL Thermal Plants
The Objector submitted that the PAF and other operational parameters for FY 202122 for HTPS and Marwa TPP are lower than approved values. The Objector requested
the Commission to allow operational parameters of HTPS and Marwa TPP on the
basis of approved values without relaxing the normative values.
Petitioner’s Reply
CSPGCL submitted that it has considered normative operational parameters in
accordance to the Regulations and the undisputed Tariff Order for FY 2021-22. In the
instant True up Petition, no prayer for relaxation of the norms has been made.
CSPGCL also submitted that the appropriateness of the Regulations cannot be
challenged through the objection. Such pleadings do not sustain even in an Appeal
filed before the Hon‟ble APTEL. CSPGCL referred to the decision of the Hon‟ble
APTEL in the Appeal No. 5 of 2013 read with the decision of Constitution bench of
Hon‟ble Supreme court of India in PTC India Ltd. v/s CERC reported at 2010 (4)
SCC page 603, wherein the Hon‟ble Supreme Court has held that validity of the
Regulations framed under the Act can be challenged only by seeking judicial review
under article 226 of the constitution of India and not otherwise. In view of the above,
CSPGCL prayed to reject the objection and allow CSPGCL claim as prayed in the
True up Petition.
Commission’s View
The Commission has done prudence check on the submission of CSPGCL and has
accordingly approved the performance parameters and carried out sharing of gains
and losses in line with the provisions of the CSERC MYT Regulations, 2015 and as
per the settled methodology adopted in previous Tariff Orders.
2.2.4 Non-Tariff Income of CSPGCL
The Objector submitted that CSPGCL has claimed the Non-Tariff Income of Rs.
34.74 Crore for FY 2021-22, whereas as per the Audited Balance Sheet for FY 202122, the Non-Tariff Income is Rs. 50.40 Crore. Therefore, the Commission should

CSERC Tariff Order FY 2023-24

7

<!-- page 30 -->

consider the Non-Tariff Income of CSPGCL for FY 2020-21 as Rs.50.40 Crore and
prudently check revenue suppression of Rs.15.66 Crore.
Petitioner’s Reply
CSPGCL submitted that in the True up Petition, it has explained the principles
followed and specific exclusions made in Non-tariff Income. The approach and
methodology adopted by CSPGCL is in line with the settled principles and practice
adopted in previous Tariff Orders. Further, in the instant True up Petition, CSPGCL
has not claimed residual salvage value of KTPS plant of more than Rs. 61 Crore. The
cost of decommissioning has also not been claimed in the instant True up Petition. In
compliance to the principle adopted in the previous Tariff Orders, leave has been
craved for submission of detailed settlement of revenue from sale of scrap and
recovery of salvage value of plant / balance stores / cost of decommissioning etc. in
the True up for FY 2022-23. Further, as per well settled principle and practice, the
interest on FDRs pertaining to the coal blocks have been reduced from the Capital
cost of the projects and hence for the regulatory purpose they are not considered as
revenue income. Thus, all components of Non-tariff Income have been dealt in the
True up Petition in accordance to the Regulations and undisputed previous Tariff
Orders of the Commission. Hence, CSPGCL requested the Commission to allow NonTariff Income as submitted in the True up Petition.
Commission’s View
The Commission has approved Non-Tariff Income for FY 2021-22 after due prudence
check and based on the approach adopted by the Commission in previous Tariff
Orders. The details are provided in subsequent Chapter of this Order.
2.2.5 Non Adjustment of Income Tax Refund by CSPGCL
The objector submitted that CSPGCL has received Income Tax refund of Rs. 69.48
Crore pertaining to AY 2020-21 ordered on 30.03.2021, but the same was not
adjusted in the True up of FY 2021-22. The Objector requested the Commission to
adjust Income Tax refund of Rs. 69.48 Crore pertaining to AY 2020-21 in the True up
of FY 2021-22.
Petitioner’s Reply
CSPGCL submitted that this specific issue has been clarified as part of additional
submission 1, vide Letter No. 35 dated 16.01.2023. In none of the previous years, for
CSPGCL, the ROE was grossed up by the tax rate. The tax was always allowed by the
Commission on actual basis. The income tax refund received during FY 2021-22
pertains to AY 2020-21 (FY 2019-20). In the FY 2019-20, the actual pre-paid tax was
Rs. 130.57 Crore, the actual income tax computed was Rs. 70.68 Crore and tax refund
of Rs. 59.89 Crore was claimed. In the True up for FY 2019-20 (dealt in the Tariff
Order for FY 2022-23), only the computed tax of Rs. 70.68 Crore was claimed and
allowed. In the true up of FY 2019-20, no claim was made / allowed for the claim of
Rs. 59.89 Crore. The said refund claim along with the applicable interest as per the
Finance Act materialized during the FY 2021-22. Copy of the challans, ITR and the
Refund order have been submitted to the Commission. As the above amount was
never considered as pass through by the Commission, hence no treatment of such
8

CSERC Tariff Order FY 2023-24

<!-- page 31 -->

refund (including interest on the same) qualifies for adjustment during True up of
FY 2021-22.
Commission’s View
The Commission has approved Income Tax for FY 2021-22 after due prudence check
and based on the approach adopted by the Commission in previous Tariff Orders. The
details of income tax refund are provided in subsequent Chapter of this Order.
2.2.6 Depreciation for ABVTPS (Marwa) for FY 2021-22
The Objector submitted that it has entered into a PPA with CSPDCL for purchase of
power supplied by ABVTPS to CSPDCL. The Agreement is for 12 years and this
Agreement has been entered after negotiation between the two State Governments.
Ultimately the ARR approved for the project is passed on by CSPDCL to
TSDISCOMs. TSDISCOMs requested the Commission to consider their views and
objections before approval of ARR of ABVTPS. TSDISCOMs submitted that as per
Regulation 24 of Chhattisgarh State Electricity Regulatory Commission (Terms and
Conditions for determination of tariff according to Multi-Year Tariff principles and
Methodology and Procedure for determination of Expected revenue from Tariff and
Charges) Regulations, 2015, the depreciation rate is 5.1% and the amount of
depreciation estimated ought to be Rs. 447.86 Crore, whereas CSPGCL has claimed
the depreciation of Rs. 521.53 Crore, which works out to a rate of 5.94%. CSPGCL
has claimed higher depreciation in order to match its debt repayment obligation.
TSDISCOMs also stated that the PPA is not co-terminus with the life of the project.
The benefit out of advance depreciation charged on TSDISCOMs will accrue to the
beneficiary at later years. TSDISCOMs requested the Commission to consider the
applicable depreciation rate as per Regulations. The difference between the
depreciation claimed by CSPGCL i.e., Rs. 521.53 Crore and Rs. 447.86 Crore may be
to the account of beneficiary (CSPDCL) after 13th year and after the expiry of PPA
with TSDISCOMs.
Petitioner’s Reply
CSPGCL reiterated its submission with respect to locus of TSPCC or TSDISCOMs to
file objection against CSPGCL True up Petition for FY 2021-22. In addition,
CSPGCL submitted that as per the definition given in the Act (Section 2 (15)),
TSPCC is not a consumer of CSPDCL. The jurisdiction of the Commission is limited
to the state of Chhattisgarh and as such TSPCC has no locus to participate in the
proceedings before the Commission.
Without prejudice to the above, CSPGCL submitted that it is a settled legal position
that any agreement between two parties cannot override the specific provisions of the
Regulations. CSPGCL has prayed for allowing the depreciation for ABVTPS
(Marwa) in accordance to the last proviso of the Regulation 24.4 of the Regulations,
2015. The appropriateness of the Regulations cannot be challenged through objection.
Such pleadings do not sustain even in through an Appeal before the Hon‟ble APTEL.
CSPGCL referred to the decision of the Hon‟ble APTEL in the Appeal No. 5 of 2013
read with the decision of Constitution bench of the Hon‟ble Supreme Court of India in
PTC India Ltd. v/s CERC reported at 2010 (4) SCC page 603, wherein the Hon‟ble
Supreme Court has held that validity of the Regulations framed under the Act can be
challenged only by seeking judicial review under article 226 of the constitution of
CSERC Tariff Order FY 2023-24

9

<!-- page 32 -->

India and not otherwise. As the pleadings of the Objector are contrary to the
established principles of law, it is submitted that the Objection deserve to be
summarily dismissed.
Further, it is also a well settled legal position that at the time of true up the principles
followed at the time of tariff determination are applicable. The tariff for FY 2021-22,
was determined by the Commission vide Order dated August 2, 2021 read with
detailed Order dated August 11, 2021 on the Petition No. 09 of 2021(T). The
depreciation for ABVTPS was approved by the Commission vide para 7.6.3, page
223-225 in the Tariff Order. The aforesaid Order has attained finality and therefore
lays down binding principle for the purpose of True up. In view of the above
CSPGCL requested that the objection raised by TSPCC or TSDISCOMs may be
rejected on the ground of merits too.
Commission’s View
The Commission while approving the ARR for FY 2021-22 in the Order dated August
11, 2021 on the Petition No. 09 of 2021(T) had approved the depreciation in
accordance with the provision specified in Regulation 24.4 of the CSERC MYT
Regulations, 2015. Therefore, at the true up stage, the Commission has followed the
same principles as detailed in subsequent chapter of this Order.
2.3

Objections on CSPTCL’s petition

2.3.1 Transmission Losses and Short-Term Open Access (STOA) Charges
The objector submitted that STOA charges proposed by CSPTCL are 36.05 paise per
unit for FY 2023-24. These charges proposed by CSPTCL are on the higher side as
compared to other States. The objector cited the example of Himachal Pradesh, Goa,
Uttarakhand, Jharkhand, Uttar Pradesh, Odisha and Telangana wherein Transmission
Charges are much lower as compared to Chhattisgarh. Therefore, the Objector
requested the Commission to rationalise the Transmission Charges of CSPTCL at
least at par with Transmission Charges of Odisha, which is 28.00 paise per unit
(highest among these States).
Petitioner’s Reply
CSPTCL submitted that STOA charges proposed for FY 2023-24 in the Petition are
based on the methodology adopted for determination of STOA charges in the previous
Tariff Orders.
Commission’s View
The Commission has approved the STOA Charges based on the methodology adopted
in the past Tariff Orders. The detailed computation has been given in relevant Chapter
of this Order.
2.4

Objections on CSLDC’s petition

2.4.1 SLDC Operating Charges
The Objector submitted that CSLDC is currently charging Operating Charges at Rs.
2000 per day per transaction for all inter-State as well as intra-State Open Access
consumers, which is very high. The Objector cited examples of States like Delhi,
10

CSERC Tariff Order FY 2023-24

<!-- page 33 -->

Madhya Pradesh, Haryana, Uttar Pradesh, Gujarat and Goa, wherein these charges are
Rs. 1000 per transaction per day. The Objector requested the Commission to reduce
the Operating Charges and make it at par with other States.
Petitioner’s Reply
CSLDC submitted that in the Western Region, SLDC Operating Charges in
Maharashtra and Madhya Pradesh are Rs. 2,250 per day and Rs. 3,000 per day,
respectively. Thus, SLDC Operating Charges of Rs. 2000 per day levied by CLSDC is
justifiable in comparison of SLDC operating charges levied in Maharashtra and
Madhya Pradesh.
Commission’s View
SLDC Operating Charges for STOA consumers are reasonable and have been retained
at existing levels.
2.5

Objections on CSPDCL’s petition

2.5.1 Telecom Services in Industrial Tariff Category
The Airtel Telecom, Cellular Operators Association of India (COAI), Digital
Infrastructure Providers Association (DIPA) and Jio Digital Life submitted that the
telecom industry is being charged commercial rates as against industrial rates,
resulting in undue financial burden on the telecom industry which works round the
clock like any other industry. As a result, early deployment of 5G in the States will
lead to multiple new sources of revenue generation for local bodies, State
Governments, Start-ups, existing businesses, and most importantly, benefits for the
citizens. Telecom sites should be provided electricity connection under Utility
/Industrial tariff. SERCs may be requested to incorporate the same in their tariff
orders.
We request that in the State EB Tariff Orders, Telecom Industry electricity tariff may
kindly be placed under Industrial rates rather than the commercial rates.
Petitioner’s Reply
CSPDCL submitted that no activity of manufacturing is being carried-out in the
telecom towers thus present classification in the non-domestic category is appropriate
and same should be continued.
Further it has submitted that designing and re-structuring of retail supply tariff is
statutory function of State Commission under Electricity Act. Hence, applicant‟s
request can only be considered subject to protection of CSPDCL‟s approved ARR for
the year FY 2023-24.
Commission’s View
The Commission found that the present tariff categorisation of the objector is
appropriate, thus, the tariff category of the objector kept unchanged.
2.5.2 Rationalize the Transmission Loss
The objector submitted that the inter-state and intra state transmission losses proposed
by CSPDCL are 3.43% and 3% respectively, which are on very much higher side as
CSERC Tariff Order FY 2023-24

11

<!-- page 34 -->

compared to the other states. The Objector citied the examples of Himachal Pradesh,
Uttarakhand, Jharkhand and Madhya Pradesh wherein Transmission Losses are much
lower as compared to Chhattisgarh. Therefore, the Objector requested the
Commission to rationalise the Transmission Losses of CSPDCL for the Control
Period at least at par with Transmission Losses of Madhya Pradesh, which is 2.62%
(highest among these States).
Petitioner’s Reply
CSPDCL submitted that based on transmission loss achieved for FY 2020-21
(3.00%), the Commission has set target as 3.00% every year of the Control Period
from FY 2021-22 to FY 2023-24. CSPDCL considered intra state transmission losses
as determined in the latest Tariff Order dated 13.04.2022 and inter-state transmission
losses has been considered as weighted average transmission losses of actual 12
months of Western Region.
Commission’s View
The Commission approves the transmission loss considering the data submitted by
CSPTCL and hence, comparing the transmission loss of Chhattisgarh with other
States has no relevance.
2.5.3 Parallel Operation Charges
The Objector submitted that the CSPDCL‟s prevailing POC charges is 13 paisa/kWh
and thus, requested the Commission to consider the POC charges payable by CPP to
CSPDCL for its captive and non-captive load as 10 paisa/kWh.
Another Objector submitted that parallel operation charges were increased up to
300% only on the request of CSPDCL to fulfil the revenue gap without considering
any exercise before hike. Now CSPDCL is getting revenue surplus, hence a part of
this surplus may be used to reduce the existing Parallel operation charges by 50%
from existing tariff.
Petitioner’s Reply
CSPDCL submitted that POC charges are constituent of non-tariff income and any
rationalization among such constituents would have a bearing on tariff of normal
electricity consumers. We requested to continue the existing methodology for
calculation of Parallel Operating Charges.
Commission’s View
The Commission has found the present POC charges appropriate, hence, do not
require any change.
2.5.4 Reactive Energy Charges
The objector submitted that the CSPDCL‟s reactive energy charges is 27 paisa/kWh
which is on higher side and hence, requested the Commission to consider the reactive
energy charges as 20 paisa/kWh.

12

CSERC Tariff Order FY 2023-24

<!-- page 35 -->

Petitioner’s Reply
CSPDCL submitted that based on past Tariff Order, Reactive Energy Charge has been
considered by the Commission @ 27 paise per unit and the same shall be continued.
Commission’s View
The Commission has found the present Reactive Energy Charges appropriate, hence
the request of the objector is not accepted.
2.5.5 Non-Reconciliation of data
The Objector submitted that CSPDCL has submitted Tariff Petition in December
2022 and it has revised lot of data vide additional submission. The additional
submission is meant to supplement data gap, which was submitted originally. In fact,
CSPDCL has amended the Tariff Petition without filing amended Petition and
requisite affidavit, which is not permissible under the Law.
CSPDCL has submitted Audited Balance Sheet for FY 2021-22; however, no
reconciliation has been provided in support of submission made under additional
submission and there remain several ambiguities and discrepancies of data.
The Objector submitted that due to such different sets of data for FY 2021-22, it is
impossible for stakeholders to make any legitimate objection on present Tariff
Petition filed by CSPDCL. Therefore, the Commission should direct CSPDCL to
amend the Tariff Petition and to submit reconciled data in order to enable
stakeholders/consumers to make legitimate suggestions/ objections.
Petitioner’s Reply
As regards objection on difference between the Tariff Petition and Additional
Submission, CSPDCL submitted that the contention of the Objector that the data is
non-reconciled is wrong.
Pursuant to the directions of the Commission, during Technical Validation Session
(TVS) the Petitioner has submitted the item-wise reconciliation of the data submitted
with the Audited Balance Sheet.
Commission’s View
The CSPDCL has asked to remove the discrepancies in data submitted with the
petition and the same was compiled by CSPDCL.
2.5.6 Issues related to Agriculture Consumption
The Objector submitted that based on analysis of actual sales to Agriculture
consumers from FY 2016-17, the sales forecast for Agriculture consumers during FY
2023-24 as submitted by CSPDCL appears to be on higher side (245 units/HP/month)
against that claimed by CSPDCL in True-up for FY 2021-22 (238 units/HP/month).
CSPDCL has shown Agriculture consumption during FY 2021-22 lower than FY
2020-21 even when number of such consumers is projected to increase considerably,
which shows absence of realistic and reliable data and estimation.

CSERC Tariff Order FY 2023-24

13

<!-- page 36 -->

Existing Energy Charges for Agriculture category is Rs.5.05 per unit whereas
CSPDCL has proposed lower consumption of Agriculture Pumps during FY 2022-23
and also proposed to dispose surplus power at a lower rate, creating an artificial loss.
From the above, it is quite clear that CSPDCL has projected lower consumption of
Agriculture Pumps during FY 2022-23 in order to show lower revenue artificially.
Energy Meters of Agriculture Pumps are not read regularly and lakhs of such
connections are served without any meter in violation of Electricity Act, 2003, hence,
it has become quite difficult to determine their actual consumption.
The Objector submitted that the report of the study on Agricultural consumption as
directed in Tariff Order for FY 2017-18, FY 2018-19 and FY 2019-20 should be
made available along with Tariff Order for FY 2023-24. Action taken report to curb
the large number of defective energy meters and present status of such meters as
observed under Tariff Order for FY 2018-19 and FY 2019-20 should also be made
available along with Tariff Order for FY 2023-24.
The Objector submitted that a Suo-Motu Petition should be filed in matters relating to
Agriculture category, viz., their actual consumption, issue of defective meters, unmetered supply, assessment of consumption, etc. The Objector requested the
Commission to approve actual sales during FY 2021-22 and FY 2023-24 on the basis
of realistic data.
Petitioner’s Reply
CSPDCL submitted that it has submitted the justification for consumption of LV-3
category in revenue statement for FY 2021-22, in reply to data gaps dated January 25,
2023. Further, basis of projections of consumption for FY 2023-24 is detailed at Para
8.4 to 8.12 of the Tariff Petition.
CSPDCL submitted that the sales considered under agricultural category is taken from
its revenue statement (R-15) for FY 2021-22. The sales considered in true up part are
extracts of revenue statement, which is based on meter readings/assessments as per
the provisions of Supply Code. The difficulties in replacement of stopped and
defective meters such as diversity in locations of agriculture pump and BPL
consumers, prolonged locked premises are prominent reasons for existing status.
All other issues such as Suo-motu Petition in the matters of agriculture category, etc.,
with regard to LV-3 category are not connected to CSPDCL‟s Tariff Petition, hence,
no comments are offered.
Commission’s View
The Commission has verified the sales to the agricultural category for FY 2021-22,
based on the R-15 submitted by CSPDCL, and the same has been considered in the
true-up for FY 2021-22. The Commission has already issued directions to CSPDCL
for improvement of its agricultural metering. Further, in line with the approach
adopted in the previous Order, the Commission has considered notional revenue from
sale to agricultural category for FY 2021-22, based on the approved ABR and the
sales reported by CSPDCL. The methodology adopted by the Commission for
projecting the sales to the agriculture category for FY 2022-23 to FY 2024-25 has
been elaborated in the relevant Chapter of this Order.

14

CSERC Tariff Order FY 2023-24

<!-- page 37 -->

2.5.7 UDAY Scheme and Distribution Losses
The Objector submitted that CSPDCL has committed to specific loss levels under
UDAY Scheme vide MoU executed on January 25, 2016.
Previously, CSPDCL had claimed share of gains on reduction of Distribution Losses
during FY 2016-17 in Provisional True-up Petition; however, the same was rejected
by the Commission in the Tariff Order for FY 2018-19.
From the 1st Amendment in CSERC MYT Regulations, 2015 effective from April 1,
2016, it is amply clear that the energy loss trajectory agreed and committed in writing
by CSPDCL shall prevail over provisions made in principal Regulations. Further,
CSERC MYT Regulations, 2015 specifies Transmission & Distribution Loss as
Controllable factor under Regulation 11.2 and provides mechanism for sharing of
under-achievement of stipulated targets.
CSPDCL has reported Distribution Loss of 16.14% including EHV sales during FY
2021-22. Surprisingly, without attaining prescribed target of 14.64% for FY 2018-19.
Further, the share of loss of Rs. 131.50 Crore computed by CSPDCL is not accounted
in ARR for FY 2021-22, which is unacceptable.
Considering all above reasons and provisions of CSERC MYT Regulations, 2015 and
UDAY Scheme, the Objector requested the Commission:
a. to stipulate the Distribution Loss including EHV Sale at 14.22% as approved by
the Commission for FY 2021-22.
b. to order for share of loss against non-achievement of Distribution/AT&C Losses
in accordance with CSERC MYT Regulations, 2015.
c. to direct CSPDCL for reconciliation of quantum of Net Power Purchase with
quantum of Energy available at Distribution Periphery.
d. to consider the distribution loss trajectory committed by CSPDCL under
Revamped Distribution Sector Scheme in the True-up and Tariff Order.
Petitioner’s Reply
The Petitioner submitted that it has clarified the reasons for not considering
deductions due to under achievement of line loss targets at 33 kV level at Para 6.13
and Para 6.14 of the Tariff Petition. This includes the modified table on sharing of
efficiency losses. The request of Objector to substitute 33 kV distribution loss with
AT&C losses is strongly objected as it considers collection efficiency too. As the
collection efficiency is not included as a performance parameter for distribution
licensee, consideration of AT&C losses at 33 kV level would be against the
Regulations.
The Objector has not considered the differential timings involved in billing cycles of
power purchase and consumers. CSPDCL bills more than 60 lakh consumers in LT
spread across the State and it is difficult to issue simultaneous bills to all consumers at
one time due to constraints in meter reading, while the power purchase bills observe
definite monthly cycle.
Further CSPDCL has also provided the details of Quantum of net power purchase
with the energy available while showing the statement of Energy balance along with
the tariff Petition.
CSERC Tariff Order FY 2023-24

15

<!-- page 38 -->

The Petitioner would further like to submit that the distribution loss trajectory as
projected by the petitioner is in accordance with the Distribution loss trajectory as
approved by the Commission.
Commission’s View
For true-up for FY 2021-22, the Commission has considered the Distribution Losses
based on actual energy sales and purchase with respect to the Distribution Losses
approved in the Tariff Order for FY 2021-22. Further, the efficiency losses on account
of non-achievement of the distribution loss trajectory approved in the Tariff Order,
despite inclusion of assessed sales, has been computed and shared between CSPDCL
and the consumers, in accordance with the CSERC MYT Regulations, 2015. For the
Control Period, the Commission has approved the trajectory for reduction of
Distribution Losses as detailed in relevant Chapter of this Order. The power purchase
quantum has been matched with the energy requirement as per the approved Energy
Balance. The detailed approach of the Commission is discussed in relevant Chapter of
this Order.
2.5.8 Higher Cost of Renewable Power and Lower Quantum of Concessional Power
Purchase
The Objector submitted that CSPDCL has purchased Renewable Power at quite
higher cost and much lower quantum of concessional power than approved, which
indicates effort to inflate over-all power purchase cost. CSPDCL has not explained
the reasons for such variations, which are causing additional burden to the consumers
of approx. Rs. 293 Crore for FY 2021-22.
The Objector also submitted that the information provided in the present Petition and
additional information do not match with the Audited Accounts for FY 2021-22.
CSPDCL has entered into an Agreement with SECI for purchase of Solar power of
2373 MW at very low rate of Rs. 2.57 per unit. Hence, such high purchase cost of
Solar power during FY 2023-24 @3.79 is not understandable and it needs prudent
examination.
Further, CSPDCL has proposed not to draw any power from Renewable Generation
from Biomass during FY 2023-24 and on the other hand, CSPDCL is drawing less
power from some Central Generating Stations of NTPC against the allocated capacity
and the resultant cost of power from such plants is very high.
Therefore, not drawing power from State Biomass Renewable Generators and buying
from outside of the State at higher rates is not a justifiable and wise proposal as State
Biomass Renewable Generators also contribute towards employment, utilization of
waste biomass, support to Agriculture and Agro-based Industries, Environment
Protection, Electricity Duty and other taxes etc. Notably, such proposal was turned
down by the Commission in Tariff Order FY2022-23.
Hence, the Objector is requesting the Commission to:

16



prudently examine the inconsistent data supplied by CSPDCL in Tariff
Petition, Additional Submission/s and VCA Calculations



prudently examine the cost of Renewable and Concessional Power during
FY2021-22 and FY2023-24
CSERC Tariff Order FY 2023-24

<!-- page 39 -->



continue buying power from State Biomass Renewable Generators during
FY2023-24



seriously examine the ways to come out of unnecessary, un-required and
costly power purchase agreement/ allocation from CGS.

Petitioner’s Reply
CSPDCL submitted that the procurement of renewable energy power is to meet the
RPO target. Further, the power purchase is made in accordance with the long-term
Power Purchase Agreement (PPA) at tariff determined/approved by the Commission.
Hence, the objection that RE purchase has been done at higher cost is denied. The
Objector has not taken into consideration the additional billing of DSM and statutory
taxes and duties applicable to biomass sources. Further, the reduced rates in respect of
solar purchase is due to availability of cheaper power during FY 2021-22, thereby,
reducing the effective average weighted rate. The procurement of hydel/other RE
contains sources with less than installed capacity 25 MW. The per unit rates approved
for small hydel plants varies between Rs. 6.15 to Rs. 7.74 per unit (levelised tariff)
plus taxes, duties and water charges for FY 2021-22. CSPDCL has submitted sourcewise power procurement details in MS Excel format along with the Petition as well as
in reply to additional points under prudence check.
In view of the above, CSPDCL requested to dismiss the prayers made by the
Objector.
Commission’s View
The Commission has considered the quantum and rate of purchase from RE sources
and Concessional Power sources for FY 2021-22, as elaborated in relevant Chapter of
this Order. The Commission has considered the quantum and rate of purchase from
RE sources and Concessional Power sources for the Control Period, as elaborated in
the relevant Chapter of this Order.
2.5.9 Banking of Power
The Objector submitted that the „Banking of Power‟ is a recent development in the
field of Distribution Business. Banking of energy does not involve any purchase of
electricity. It is a cashless transaction and is a facility available to Distribution
Licensee like storing energy with other Discoms for subsequent own consumption.
The Banking is done between two Discoms on mutually agreed terms and conditions.
This methodology is mutually beneficial as one Discom can bank its costly surplus
power with other Discom, without surrendering at quite low UI Rates in the Grid, and
can avail back such power in the hours of shortages, avoiding emergency purchase of
costly power. This methodology facilitates discipline in operation of the Grid,
Distribution network and Power Purchase Cost.
In the present True-up Petition for FY2021-22, CSPDCL has neither shown any
reason for not returning 437.94 MU of power banked with it in totality although it had
surplus availability of power nor has it submitted the “Power Banking Pass Book. It is
clear that the quantum of such Banked Power is quite high and is purchased in one
year and used/sold in later years or vice-versa. Amount of such power may be as high
as Rs.500 Crore to Rs.1,000 Crore evaluated at Average Power Purchase Cost.
CSERC Tariff Order FY 2023-24

17

<!-- page 40 -->

The Objector submitted that the Judgment of Hon‟ble APTEL dated July 1, 2014 in
Appeal No. 220 of 2013 (Himalaya Power Producers Association Vs. HPERC, etc.) is
related to the determination of Average Pooled Power Purchase Cost (APPC) under
REC mechanism, hence, the directives of Hon‟ble APTEL should not be taken in
other context.
If the quantum and cost of such Banked Power is not accounted in the same Financial
Year, it may create several problems relating to accounting and statutory lapses, viz:
a. Banked Power is Stock in Hand (positive or negative, as the case may be) and it
should be accounted in the Balance Sheet and Profit/Loss Account of CSPDCL.
b. By not accounting the quantum and cost of such Banked Power in the same
financial year, Revenue Surplus or Deficit may be siphoned to the coming years,
which will create artificial stand-alone Profit/Loss for that particular Financial
Year.
c. It is against the basic principles of accounting and Accounting Standards being
followed.
d. It is against the statutory provisions of Income Tax.
CSPDCL has failed to comply with the above directives of the Commission while
filing True-up Petition for FY 2021-22. In view of the above, the Objector submitted
following:
a. Such quantum of Banked Power should be treated as Stock in Hand (positive or
negative, as the case may be) and Cost of such Banked Power should be
accounted in the same Financial Year. Further, CSPDCL should be directed to
comply with the directive already issued to maintain a „Power Banking Passbook‟
having details like Banking Partner/s, Banked Quantum, Date & Time of such
Banked Quantity, effective UI Rates on such time, Agreed Date and Time for
Reverse Banking, etc.
b. Necessary Regulations be made at the earliest with respect to Banking of Power
as announced in Tariff Order for FY 2019-20.
c. Trued-up details from FY 14-15 are showing a Returnable Quantum of
437.94MU in Power Banking whereas CSPDCL is reporting Receivable Quantum
of 328.92 MU at the end of FY21-22 which needs to be examined prudently.
d. Discrepancy in the data submitted by CSPDCL in the True-up Petition and
Additional Submission needs to be examined prudently.
Petitioner’s Reply
CSPDCL submitted that it is complying with the directions issued by the Commission
at Para 10.2(vi) „New directives to CSPDCL‟ regarding banking transactions. Further,
CSPDCL has also submitted the details showing reconciliation of banking
transactions during FY 2021-22 with respect to corresponding banking agreements
showing energy units received and unit returned in reply to Query No. 25 of Letter
No. 2626, dated February 3, 2023. The aforesaid replies were also placed in public
domain.
The contentions of banking about previous many years is not a subject matter of
present Petition when the Commission has already settled the transactions in terms of
18

CSERC Tariff Order FY 2023-24

<!-- page 41 -->

true-up Orders for each of the previous year. The Commission has approved final true
up to FY 2020-21.
In view of the above, the Objector‟s prayer is ineffective; hence, may be dismissed.
Commission’s View
While undertaking the final true-up for FY 2021-22, the Commission sought all
relevant details of banking of power and has approved the quantum of banked power
after due prudence check, as elaborated in the relevant Chapter of this Order.
2.5.10 Review of Final True-up of FY 2018-19
The Objector submitted that in the present Tariff Petition, CSPDCL has sought review
of Tariff Order for FY 2022-23 pertaining to true-up of FY 2018-19. This Review
Petition was filed for an additional claim of Rs. 518.03 Crore against approved trueup for FY 2018-19 under Tariff Order for FY 2022-23. Public Notice issued by the
Commission and CSPDCL in the newspaper/s inviting comments, suggestions and
objections from the public do not mention about the Review of Tariff Order for FY
2022-23 within the scope of present Petition. Since comments/objections are not
called on review of Tariff Order for FY 2022-23 pertaining to True-up for FY 201819, it would neither be legitimate for the public/stakeholders to raise any objection/s
on the merits of such a huge demand of Rs.518.03 Crore (including carrying cost) nor
for the Commission to address this issue without having followed proper procedure.
Therefore, the Objector requested the Commission not to re-review the matters of FY
2018-19 which is already time-barred and which has nature of appeal, to disallow
claim of Rs. 518.03 Crore under ARR for FY 2023-24 and to issue Public Notice for
the review of Tariff Order for FY 2022-23 inviting suggestions/ objections from the
public/ stakeholders and calling for a Public Hearing on the matter.
Petitioner’s Reply
CSPDCL submitted that the prayer made by the Objector does not hold good in light
of the directions of the Commission to include the points of review of Tariff Order
dated August 2, 2021 in ensuing Tariff Petition for FY 2023-24. Accordingly,
inclusion of Chapter 5 under present Petition is in pursuance to the Order dated
August 5, 2022 in Review Petition No. 51 of 2022 read with provisions of Order 47
Rule 1 of Civil Procedure Code.
Commission’s View
The reply of the Petitioner is self-explanatory.
2.5.11 Difference in Energy Sold and Actual Revenue Receipts from Retail Sale
The Objector submitted that revenue receipts claimed in the True-up Petition for FY
2021-22 is less than Revenue reported in R-15 format by CSPDCL, amounting to Rs.
54.44 Crore.
Similarly, CSPDCL has shown lower revenue from retail sale to LV3-Agriculture
category, amounting to Rs. 422.32 Crore.
The Objector submitted that in accordance with Section 45 of the Act, CSPDCL is
bound to recover energy charge as prescribed by the Commission under prevailing
CSERC Tariff Order FY 2023-24

19

<!-- page 42 -->

Tariff Order and it cannot show any undue preference to a consumer or class of
consumers.
While truing-up of earlier years, the Commission has considered „additional revenue
for Agriculture metered category‟. During FY 2017-18, such additional revenue was
Rs. 351.24 Crore whereas during FY 2018-19, it is considered as Rs. 382.85 Crore
under true-up.
Therefore, the Objector requested the Commission to:
a. prudently check shortage of revenue of Rs. 54.44 Crore received from retail sale
of power to HT Consumers during FY 2021-22 in light of R-15 data provided by
CSPDCL
b. consider additional revenue of Rs.422.32 Crore from sale of power to LV-3
Agriculture category during FY 2021-22 in accordance with prescribed Energy
Charges under prevailing Tariff Order and the approach followed by the
Commission in previous Tariff Order/s.
Petitioner’s Reply
CSPDCL submitted that the contentions about difference of Rs. 54.44 Crore are
baseless. CSPDCL has considered revenue reported in the audited accounts, under
„Revenue from sale of power‟ and „Non-Tariff Income‟ in Tariff Petition as per the
practice adopted by the Commission. Billing of Parallel Operation Charges, meter
rent, cross subsidy surcharge, etc., forms miscellaneous part of revenue and is
included under Non-Tariff Income. Therefore, comparing R-15 with figures of
audited balance sheet is superfluous.
Commission’s View
The Commission has performed prudence check on the revenue recovered from
consumers and has only considered the revenue reflected in Audited Accounts.
Further, in line with previous Tariff Orders, the Commission has addressed the issue
of additional notional revenue from LV-3 Category Consumers in the relevant
Chapter of this Order.
2.5.12 Discrepancy in Quantum & Cost of Power Purchased & Transmission Charges
The Objector submitted that the net generation by CSPGCL for FY 2021-22 differs
from quantum of power purchased by CSPDCL although entire power is purchased by
CSPDCL. Also, there is difference in the cost of power purchased from CSPGCL
during FY 2021-22.
Further, rebate of 2.5% is provided for timely payment against power purchase from
Central Sector; however, CSPDCL is not availing this benefit although sufficient
provision for working capital requirement is provided in the ARR. Thus, consumers
of the State are deprived from huge benefit of Rs. 219.38 Crore in the form of rebate
from CGS
Therefore, the Objector requested the Commission to:
a. prudently examine cost and quantum of power purchase as claimed by CSPDCL
during FY21-22.

20

CSERC Tariff Order FY 2023-24

<!-- page 43 -->

b. allow rebate of Rs.147.55 Crore for FY 2021-22 and Rs.127.03 Crore for FY
2023-24 for purchase from Central Generating Stations and not to allow any
Delayed Payment Surcharge under ARR.
Petitioner’s Reply
The contentions on rebate from CGS are hypothetical in nature. The benefit of early
payment is consequential of discharging payment liability within the prescribed
timelines. This is in turn connected to the financial position of the Petitioner. As there
is no actual benefit received by the Petitioner towards early payment, the request of
Objector to consider rebate is ridiculous.
Commission’s View
The Commission has verified the reconciliation given by CSPDCL and CSPGCL and
has accordingly approved the quantum and cost of power purchased from CSPGCL in
the final true-up for FY 2021-22.
The Commission does not find any merit in the suggestion for considering notional
rebate on power purchase, which has not been received by the Petitioner, in the trueup for FY 2021-22.
2.5.13 Non-compliance of Regulations in the matter of Recovery of VCA Charges
The Objector submitted that CSPDCL is not showing VCA Charges billed/recovered
to the consumers separately in the books of Accounts although LT R-15 shows it
separately but again HT R-15, VCA Charges are not shown separately. This is noncompliance of MYT Regulations‟ 2015.
VCA Charges have gone as high as Rs 1.10 per kWh, increasing the tariff
substantially beyond Tariff Estimation because of which Power Intensive Consumers
like Mini Steel Plants are highly affected. Hence resetting of VCA Charges to “Zero”
in the Tariff Order is necessary so that Retail Tariff may become stable and
predictable as desired under National Tariff Policy.
Govt of India has notified Electricity (Amendment) Rules 2022 on 29.12.2022,
providing speedy recovery of variation of Power Purchase Costs of Distribution
Licensee through VCA Charges and to carry separate True-up for such VCA Charges
for any financial year to be completed by 30th June of the next financial year.
Therefore, the Objector requested the Commission to:
a. set VCA Charges to “Zero” at the start of FY23-24 for a stable and predictable
Retail Tariff
b. device mechanism for speedy recovery of VCA Charges
c. institute separate True-up mechanism for VCA and FCA Charges
Petitioner’s Reply
CSPDCL submitted that the contentions and prayers made by the Objector are absurd.
It is because the Objector has compared unlike with likes. The expenditure taken as
difference of power purchase cost (CHPP) on bi-monthly basis under the FCA and
VCA mechanism observes separate annual cycle specified at Regulation 67.8 of
CSERC MYT Regulations, 2015. Further, the expenditure taken as cost of power
CSERC Tariff Order FY 2023-24

21

<!-- page 44 -->

purchase observes annual cycle of financial year. This different billing cycles give
rise to aforesaid difference. Hence, the contention of excess recovery through VCA is
incorrect.
Commission’s View
The Commission has verified the details provided by CSPDCL and has accordingly
approved the quantum and cost of power purchased from CGS stations in the final
true-up for FY 2021-22.
The approach adopted by the Commission for projecting quantum and cost of power
purchase from CGS stations for the Control Period is detailed in the relevant Chapter
of this Order. The Commission has also made certain modifications in the FCA and
VCA mechanism from FY 2023-24 onwards, as elaborated in the Tariff Schedule and
in the relevant Chapter of this Order.
2.5.14 Discrepancy in Quantum & Cost of Power Purchased from CSPGCL
The Objector submitted that that during FY 2020-21, net generation by CSPGCL
differs from quantum of power purchased by CSPDCL although entire power is
purchased by CSPDCL.
Therefore, the Objector requested the Commission to:
a. Prudently examine quantum of power purchase from CSPGCL against such
power claimed by CSPDCL during FY 2021-22 as there is multiplicity of data;
b. Prudently examine quantum of power purchase from Hasdeo Bango Hydel Power
Station of 403.35 MU as there appears to be no provision under True-up Petition
for FY 2021-22;
c. Prudently examine the cost of power purchase from CSPGCL claimed by
CSPDCL in FY 2021-22 as there is multiplicity of data.
Petitioner’s Reply
CSPDCL submitted that it has furnished the reconciliation of Power purchase cost and
Quantum as considered by the CSPDCL with CSPGCL in reply to the data gaps dated
23.01.2023 & dated 03.02.2023.
Commission’s View
The Commission has verified the details provided by CSPDCL and has accordingly
approved the quantum and cost of power purchased from CGS stations in the final
true-up for FY 2021-22.
2.5.15 Burden of Short Recovery of Power Cost of Marwa TPP on Retail Consumers &
Excess Recovery of Capacity Charges
The Objector submitted that CSPDCL has an agreement with Telangana for back-toback supply of power generated by Marwa TPP after adding trading margin of 7 paise
per unit. The average cost of generation claimed by CSPGCL during FY 2021-22 is
substantially high, hence, purchase of power from Marwa TPP for Retail Sale is
inflating Retail Tariff. Station Heat Rate is reported to be 2572.42 kCal/kWh against
approved 2372.42 kCal/kWh, meaning that coal consumption is higher to generate 1
22

CSERC Tariff Order FY 2023-24

<!-- page 45 -->

unit of electricity. Further, the Auxiliary Consumption is also higher at 6.12% against
approved 5.25%. All such inefficiency is increasing the cost of generation. This is not
acceptable.
During FY 2020-21, PAF of Marwa TPP was only 55.06% against approved PAF of
76.5%. Similarly, during FY2021-22, PAF of Marwa TPP was only 54.67% against
approved PAF of 76.5% but CSPGCL has claimed Rs.1,513.78 Crore as Capacity
Charges against approval of Rs.1,526.18 Crore which is not reasonable. This means
that without running the plant to normative capacity, CSPGCL is recovering its fixed
cost from the consumers of the State, even when such plant is meant to supply
electricity to Telangana on back-to-back basis.
Further, CSPGCL has submitted under Form 15B for Marwa TPP that landed price of
coal is lower than approved and GCV of coal is also equal to approved but CSPGCL
has recovered Rs. 57 Crore on account of Fuel Cost Adjustment (FCA) from
consumers of the State, understandably without any such increase in Fuel Cost.
Therefore, the Objector requested the Commission to:
a. Consider ARR/ capacity charge of Marwa TPP on reduced PAF/PLF and
disallow excess claim of Capacity Charges of Rs. 423.11 Crore during
FY2201-22;
b. not to load on Retail Consumers any under-recovery from sale of power to
Telangana below the cost of generation amounting more than Rs. 172.91
Crore;
c. prudently examine the FCA and VCA charges determined by CSPGCL and
CSPDCL before recovery from consumers
Petitioner’s Reply
CSPDCL submitted that it is supplying power purchase from ABVTPP (Marwa) to
Telangana DISCOMs under back-to-back arrangement. It has been reiterated that
based on demand supply gap of the State, a portion of availability from Marwa is
utilised for supply to consumers of the State. CSPDCL submitted that out of total
availability of 4846.14 MU, the sale to Telangana is 1631.25 MU. Resultantly, the
short-dispatch to Telangana is utilised for supply to consumers of the State. Therefore,
the prayer submitted by the Objector is irrelevant and liable to be dismissed.
Commission’s View
The Commission has verified the details provided by CSPDCL and has accordingly
approved the quantum and cost of power purchased from CGS stations, including
ABVTPP, in the final true-up for FY 2021-22. Further, the recovery of Fixed Charges
by ABVTPP has been allowed in accordance with the CSERC MYT Regulations,
2015, as elaborated in the relevant Chapter of this Order. For true-up, the Commission
has approved sale of surplus power to Telangana after due prudence check, as detailed
in the relevant Chapter of this Order.

CSERC Tariff Order FY 2023-24

23

<!-- page 46 -->

2.5.16 Preparation of R-15 and Status of Defective Meters and Assessed Billing
The data submitted in LT R-15 report from FY 2015-16 to FY 2022-23 (8 months)
along with Tariff Petition for FY 2022-23 shows that the number of defective meters
and assessed billing cases are extremely high.
Thus, it is quite evident that CSPDCL is not sure about actual energy consumption
and in large number of cases, billing is done on assessment basis. Hence, it is also
obvious that meter reading is not done on regular basis. Number of defective meters
are increasing in spite of several directives and Orders from the Commission.
CSPDCL has spent a hefty sum of Rs. 97.02 Crore (Petition Page 32) for meter
reading and other merchandizing services during FY 2021-22, in spite of which meter
readings are not done on regular basis. The Commission should disallow such huge
expenditure on out-sourcing of meter reading when 20-30% of meters are not being
read.
The Commission had directed CSPDCL to prepare an action plan and take corrective
measures to bring down percentage of defective meters and assessment-based billing
within prescribed ceiling under Tariff Order FY 2019-20 and again under Tariff Order
FY 2022-23. However, unfortunately nothing has been done, hence, disallowance
should be treated as punishment for non-compliance of directives.
The Objector submitted that the Commission in several Tariff Orders, has laid
emphasis on correct and timely preparation of R-15 report. However, there is no
uniformity in the submission of CSPDCL with respect to R-15 report, and it is very
difficult to have a „Bird‟s Eye-view‟ to have an overall picture of distribution system.
There are also several data-based and calculation errors due to which very purpose of
preparing R-15 report has been lost.
It is observed that R-15 format is being prepared by CSPDCL using SAP software and
the Commission is now authorized to look directly into the data fed into SAP system.
Therefore, it is desired that the Commission should inspect SAP data directly and
regularly for better feedback and control.
In absence of authenticated, reliable and reconciled data and information like R-15
format, True-up Petition, Additional Submission and Audited Balance Sheet and
Auditors‟ Report for FY 2021-22, the True-up exercise for FY 2021-22 should be
carried only after submission of uniform data and information by CSPDCL.
Petitioner’s Reply
CSPDCL submitted that the Commission has disposed Petition No. 53 of 2020
through its Order dated December 9, 2021 which was connected to compliance of
directives by CSPDCL in respect of Tariff Order for FY 2019-20. The Commission
after perusing the details of submissions made by respondent on each of the tariff
directive contained in the Tariff Order dated February 28, 2019, appreciated the
efforts taken by CSPDCL with specific observation to accelerate the efforts. The
directives include preparation of action plan and corrective measures to bring down
percentage of stop/defective meter and assessment based billings.
Further, the status of stopped and defective meters and cases of assessed billing are
demonstrated in revenue statement and the same are in pursuance to provisions of the
Supply Code. The difficulties in replacement of stopped and defective meters such as
24

CSERC Tariff Order FY 2023-24

<!-- page 47 -->

diversity in locations of agriculture and BPL pumps, prolonged locked premises and
resistance of consumers towards meter replacement are prominent reasons for existing
status.
As regards to preparation of R-15, the contentions of Objector may be dismissed as
the Petitioner is following the directions of the Commission from time to time.
Commission’s View
The Commission has done prudence check on R-15 data submitted by CSPDCL and
accordingly approved the sales of CSPDCL. Further, the Commission observed that
the number of defective meters and billing based on assessment is still on the higher
side despite various directives given by the Commission in previous Tariff Orders.
The Commission has hence, given further directions to CSPDCL to submit a time
bound action plan to phase out defective meters and assessment billing, within three
months.
2.5.17 Submission of Compliance Report under Directives issued by the Commission in
previous Tariff Order FY 2022-23
The Objector submitted that CSPDCL has not submitted any “Compliance Report”
along with Tariff Petition for FY 2023-24. It is further observed that CSPDCL has not
complied with most of the directives issued by the Commission in order to facilitate
improvement in operational efficiency. In many cases, operation efficiency has further
deteriorated. Hence, the Objector requested the Commission to take strict action
against such lapses of non-compliance and non-submission of “Compliance Report”.
Petitioner’s Reply
CSPDCL submitted that they have complied with the Directives of the Commission
vide Letter no. 2772, dated 17.02.2023. It is further submitted that the compilation of
the directives took time and therefore the same is not been submitted with the Tariff
Petition. CSPDCL took all the measures to comply with the directives issued by the
Commission.
Commission’s View
CSPDCL submitted compliance report to the directives vide Letter no. 2772, dated
17.02.2023. The Commission has gone through the compliance report and
accordingly, issued subsequent directives in this order.
2.5.18 Discrepancy in CSPDCL’s Employee Cost , A&G, R&M Expenses
The Objector submitted that a discrepancy in the claim of employee cost has been
observed in the True-up Petition for FY 2021-22 when compared with Audited
Balance Sheet.
The Objector requested the Commission to:
a. Treat excess Employee Cost of Rs.1,017.36 Crore over approved Rs. 947.51
Crore in accordance to MYT Regulations‟ 2015;
b. Disallow claimed A&G and R&M expenses of Rs. 547.45 Crore in ARR and
treat excess expense of Rs.388.46 Crore over approved Rs. 280.26 Crore in
accordance to MYT Regulations‟ 2015;
CSERC Tariff Order FY 2023-24

25

<!-- page 48 -->

Petitioner’s Reply
CSPDCL submitted that there is no deviation between the Petitioner‟s claim and
audited accounts as regards the employee expenses. The Objectors claim of adding the
outsourced manpower expenses in the employee expenses is contrary to the
Regulations. Hence, the objection is baseless and has been made contrary to the
Regulations. Also, CSPDCL has already submitted the reconciliation of the expenses
claimed by the Petitioner with the Audited Balance sheet.
Further CSPDCL submits that the R&M expenses as per the Accounts are Rs. 390.04
Crore, which has been claimed as R&M expenses. Further, the expenses of Rs. 64.26
Crore towards manpower expenses at 33/11 kV substations has been deducted while
claiming the sharing of gain and losses on account of O&M expenses. The R&M
expenses have been claimed strictly as per the audited accounts and there is no
multiplicity of the data as contended by the Objector.
Similarly, Rs.157.41 Crore has been claimed under the head A&G expenses after
adjustment of the capitalization of expenses, strictly as per the audited accounts and
there is no deviation. The Objector has wrongly adjusted the capitalization from R&M
expenses, which is resulting in confusion. The Commission is requested to consider
the submission of the Petitioner, which are as per the audited accounts.
Commission’s View
The Commission has approved the Employee Cost, R&M Expenses and A&G
Expenses in accordance with the applicable tariff regulations i.e. the MYT
Regulations, 2015 for true-up of FY 2021-22 and thus, not treated the expenses
towards contract services, viz., operations of 33/11 kV Substations, meter reading, bill
distribution and revenue collection, secretarial assistance in offices, housekeeping and
security guards under employee expenses and as uncontrollable. The same is detailed
at relevant chapter of the order.
2.5.19 Retail Tariff of Mini Steel Plants (HV4-Steel Industries)
Chhattisgarh Mini Steel Plant Association (CGMSPA) submitted that
Effect of Lock-down and COVID-19 Pandemic on Steel Industries:
The Objector submitted that due to first wave of COVID-19 Pandemic, the Central
and State Governments imposed Lock-down since March 23, 2020. Industries were
allowed to work in limited manner since 1st week of May 2020, by strictly observing
certain terms and conditions prescribed by the Government. The said Lock-down had
been effectively imposed till May 31, 2020 by issuing strict guidelines and
notifications. In second and third wave of Corona Pandemic, although the lock-down
was not strictly imposed, the procurement-production-marketing-monetary cycle of
Steel Industries of the State was very badly affected.
Under said circumstances, Steel Industries have been hit hard and are almost unable to
run normal production activities due to following reasons:
a. Complete Lock-down till 03.5.2020 and partially till 31.5.2020;
b. Labourers and Staff are not attending production activity due to threat to their
lives, migratory labourers have gone back to their respective States;
c. Raw-material is not available in required quantity;
26

CSERC Tariff Order FY 2023-24

<!-- page 49 -->

d. Market and demand of goods has substantially diminished;
e. Financial cycle has been badly affected;
f. Huge liability of Minimum Electricity Bill during the period of closure.
The impact of above negative forces has resulted in actual sales to HV-4 category
being much lower than approved in FY 2022-23.
Hence, it is clear that Steel Industries, especially Mini Steel Plants, have suffered very
badly due to Corona Pandemic and have not recovered even to the level 2 years
before. This is a matter of great concern not only for industries but also for CSPDCL.
Looking at the seriousness of the situation, the State Government had announced
Tariff Subsidy up to Rs.1.22 per unit for Steel Industries having load of 2,500 kVA or
above till July 2021 and later Retail Tariff was also reduced by the Commission,
which is a highly welcome initiative taken by the Commission.
Lower Tariff in Neighbouring States:
The Objector submitted that some of the neighbouring States have announced
electricity tariff for Steel Industries quite lower/competitive to the existing tariff in
Chhattisgarh.
It is feared that trade and manufacturing activity may shift from the State to other
States, which may prove to be nightmare for the development of our State. Hence,
Retail Tariff of Steel Industries should be designed in such a manner that such
existing industries not only survive stiff competition from other States but are also
able to fetch fresh investment.
Post-COVID afresh Investment in the State:
The Objector submitted that in the post-Corona period, the State Government is trying
hard to attract fresh investment in the State by providing booster under State
Industrial Policy 2019-24. Hence, to achieve above objective, the growth of existing
industries is essentially required to be secured who are finding it difficult to survive in
the present scenario.
CSPDCL has reported a surplus of electricity by about 17.5% during FY 2023-24 and
such surplus power is proposed to be sold to other States at a price lower than
purchase price. In this manner, we are subsidizing other States, which is certainly not
our objective.
Therefore, the Objector prayed that the Retail Tariff and Incentives should be
designed in such a manner that they not only help in survival but also encourage the
consumption of electricity. To achieve above objective, following measures are
suggested:
a. Average Billing Realization from Bulk Consumers to CSPDCL should be near to
Voltage-wise Cost of Supply (FY 2022-23 - Rs.5.20 per unit for 33 kV supply
determined by the Commission excluding past revenue gap);
b. Suitable Bulk Consumption Incentive should be given over and above Load
Factor Incentive (Orissa Pattern);
c. Power-off hours should be increased to average 72 hours per month, considering
shutdowns and weekly-off days;

CSERC Tariff Order FY 2023-24

27

<!-- page 50 -->

d. Additional Power Off Hours against Load Shedding should be provided based on
actual load shedding period, apart from existing normal power-off hours of 36
hours per month;
e. Only Night Tariff (optional) should be introduced to encourage consumption
during surplus period with allowing 12 hours working;
f. TOD Tariff Hours should be reset by reducing the peak period from 5 hours to 4
hours, reducing the normal period from 13 hours to 12 hours, and increasing the
off-peak hours from 6 hours to 8 hours.
g. Variable Cost Adjustment (VCA) to be reset to zero as it has gone up high as Rs.
1.10/kWh Mechanism for independent checking of computation of FCA and
VCA charges should added.
h.

No additional charge be levied on exceeding contract demand up to a maximum
limit of 30% during off-peak hours. Correction in Clause 9(iii) of Terms &
Conditions of HV Supply be made to consider excess demand over 120% of
contract demand during off-peak hours as excess billing demand (example- CD
of 1000kVA is permitted to draw 1200kVA during off-peak hours and if suppose
during off-peak hours, recorded demand is 1210kVA then only on 10kVA,
provision of excess demand be applied.)

i. Advance Payment Rebate equivalent to DPS (presently 1.5% of the bill per
month or part) may be given to encourage advance payment of energy bills,
which will improve cash-flow of CSPDCL.
j. Mechanism for 15-day billing cycle be fairly devised in the benefit of Discom
and consumers.
The Objector made detailed submissions regarding the formulation of Only Night
Tariff, which provides an ABR of about Rs.5.25 per unit considering 60% load factor
(12 hrs) and 10% additional working during the period other than Normal (12 hrs) for
other essential operational activities like loading, unloading, cooling, production cycle
completion, office, etc.
Following issues are required to be fixed in consultation with CSPDCL:
a. Allowable Normal Working Hours for Only Night Tariff, which should be 12 hrs
minimum;
b. Metering and Billing issues;
c. Availability of Load in respective feeders during said period of 12 hrs, which can
be permitted on „first come- first get‟ basis, etc.
The Objector submitted that the Retail Tariff for Mini Steel Plants during FY 2023-24
should be designed considering Corona after-effects, package/ relief from the Central
Government, lower tariff in neighbouring States, sincere efforts of the State
Government to attract afresh investment and revenue contribution by Mini Steel
Plants over the years, etc.
Petitioner’s Reply
CSPDCL submitted point-wise reply to the measures suggested by the Objector as
under:
a. As regards Average Billing Realization from Bulk Consumers being near to
Voltage-wise Cost of Supply, it would be against the Tariff Policy Clause 8.3(2)
28

CSERC Tariff Order FY 2023-24

<!-- page 51 -->

wherein consumer retail tariff is required to be determined within the limits of ±
20% of Average Cost of Supply.
b. Load factor incentive is a prerogative of the Commission under Section 62(3) of
Electricity Act, 2003. CSPDCL submitted that if this request is considered by the
Commission then approved ARR for FY 2023-24 should be protected.
c. The intention of power off hours is to compensate power intensive industries from
interruptions. The Commission has already revised duration of 30 hours to 36
hours recently in the Tariff Order dated August 2, 2021. The aforesaid revision is
based on average interruptions caused to industrial feeders across the area of
supply in the State. Applicant has not submitted any justifications for revision.
However, the availability of supply in EHV is 99.97%. Hence, the duration of
hour shall be minimized.
d. CSPDCL submitted that if the request of only night tariff is considered by the
Commission then approved ARR for FY 2023-24 should be protected.
e. The present TOD structure is appropriate as per availability of power.
f. The expenditure taken as difference of power purchase cost (CHPP) on bimonthly basis under the FCA and VCA mechanism observes separate annual
cycle specified at Regulation 67.8 of CSERC MYT Regulations, 2015 and
Regulation 93.10 of CSERC MYT Regulations, 2021.
g. The current billing provisions are governed by the supply code and regulations.
The Discoms are operating according to the provisions of the Regulations.
Therefore, CSPDCL humbly submits before the Commission that present TOD
tariff is appropriate.
h. The advance payment rebate already exists in the Tariff Design.
i. Billing frequency plays an important role in getting to know the status regarding
the timely regularization and realizations of revenue across distribution utilities in
different categories. It is in the common interest of both customers and
distribution utilities to regularize the billing schedule. CSPDCL humbly submits
before the Commission that present criteria for 15 days billing cycle is
appropriate.
Commission’s View
The Commission has addressed the issue of Load Factor Rebate for HV4-Steel
Industries Category along with the tariff philosophy and other terms and conditions of
tariff in the relevant Chapter of this Order. The category-wise tariffs have been
determined based on Average Cost of Supply and cross-subsidy level.
2.5.20 Sale/Consumption of Surplus Power within State
The Objector submitted that the Commission in Tariff Order for FY 2019-20, has
directed CSPDCL to examine the possibility of optimum utilisation of surplus power
within the State through appropriate incentive mechanism and to come up with a
proposal for same by November 30, 2019. However, CSPDCL has not submitted any
such proposal.

CSERC Tariff Order FY 2023-24

29

<!-- page 52 -->

In the True-up Petition for FY 2021-22 and Tariff Petition for FY 2023-24, CSPDCL
has reported surplus availability of power of 3,612.34 MU and 7,075.87 MU
respectively (excluding sale to Telangana in spite of much lower drawal against
Central Allocation of power from Central Generating Stations), which is sold at Rs.
3.20/kWh and 4.94/kWh as against average power purchase cost of Rs. 4.27/kWh.
and Rs. 3.71/kWh for FY 2021-22 and FY 2022-23 respectively.
The above quantum of surplus power amounts to more than 24.5% of retail sale of
power of 25,885 MU during FY 2023-24. It is observed that CSPDCL is paying
capacity charges to about 4 to 5 CGS stations (NTPC) without drawing any power
from them due to surplus availability. Also, about 25% of the Retail Sale & 17.5% of
net Power Purchase is disposed-off by CSPDCL to other States at very low realization
(below average procurement cost) and the burden of such disposal of power to other
States is borne by the consumers of Chhattisgarh by way of higher tariff. Hence, if
such power can be utilised within the State at relatively higher realization, it shall
prove to be beneficial to CSPDCL and consumers as well.
Further, the Commission had registered a suo-motu Petition (P.No.59/2020) on
representation of industries to find ways to utilize surplus power within the State. In
the Order dated December 10, 2020, the Commission had directed industries to take
up the matter during discharge of Tariff Petition for FY 2021-22 and also directed
CSPDCL to submit detailed data and proposal to achieve above objective.
Due to favourable policies, market conditions and State Subsidy, Steel Industries have
grown beyond estimations during FY 2020-21 and FY 2021-22 and have delivered
major revenue to CSPDCL.
The tariff of Steel Industries is considerably reduced and anomalies are removed,
considering negative impact of economic slowdown and effect of Covid-19. Hence,
CSPDCL should be directed to make efforts to sell this surplus quantum of power to
the consumers of the State as directed by the Commission. Therefore, a mechanism
has to be devised so that:
a. Consumers may get benefit of surplus power, at cheaper rates, (which is otherwise
sold/ surrendered to other States at loss-making rate) over and above their existing
consumption;
b. Having slight better realization from retail consumers compared to Rs.3.71 (gross
average power purchase cost estimated for FY 2023-24 by CSPDCL), revenue of
CSPDCL will be improved;
c. State Government will be benefited by way of additional taxes and revenue on any
possible increase in production of industries;
d. Public may be benefited by way of more employment due to increased production.
The Objector submitted that the above measures may be designed in such a manner
that it may prove beneficial to CSPDCL by way of sale of surplus power at profitmaking rate when there is no demand of such power in inter-State market and also to
Steel Industries of the State by way of lower tariff when they are badly suffering from
economic slowdown and after-effect of Corona Pandemic. Any operational
constraints may be resolved under consultation with CSPDCL and consumers.

30

CSERC Tariff Order FY 2023-24

<!-- page 53 -->

Petitioner’s Reply
CSPDCL submitted that it anticipates a TOD surplus ranging between 100 MW to
1500 MW in the system during off-peak hours of winter and day time subject to
commissioning of solar plants during the next Control Period. As consumer sale
requires RTC surplus; hence, the present suggestion is senseless.
Commission’s View
In the present Order, the Commission has made a reasonable assessment of the
surplus quantum to be sold in the Power Exchanges for the Control Period, and has
considered some short-term purchase from Power Exchanges to meet the energy
requirement. However, during the Control Period, there are bound to be mismatches
between demand and supply, and CSPDCL should strive to maximise the revenue
from such sale of surplus power.
2.5.21 Distribution loss including EHV Sales
The Objector submitted that CSPDCL is unable to match with its commitment in
“UDAY Scheme” and “Revamped Distribution Sector Scheme” in the matter of
Distribution Losses in spite of huge capital expenditure, resulting in burden on Retail
Tariff of consumers. Proposal of Distribution Loss at 11.54% for FY23-24 is
unrealistic.
Petitioner’s Reply
CSPDCL submitted that CSPDCL would like to consider the losses of 15.33% as
approved by CSERC, the cumulative losses for FY 2023-24 after considering EHV
consumers comes out 11.54%. Also, CSPDCL would like to submit that it has
followed the distribution loss trajectory as approved by the Commission and putting
its best efforts to increase the revenue realization and to manage the cost side more
efficiently.
Commission’s View
The Commission has projected sales based on cumulative average growth rate
considering R-15 submitted by CSPDCL. As per the computation of the Commission,
the distribution loss including EHV sales works out to be 13.67% as against 11.54%
submitted by CSPDCL which appears to be a realistic assessment.
2.5.22 Change of Tariff Category
The Objector submitted that the process in Printing Industries involves several steps
to manufacture variety of finished products. During the discharge of tariff petition of
FY 2022-23 the objector has requested the Commission to classify the Printing
Industries under LV5 - LT Industries instead of existing LV2 - Non-Domestic
category. In its response, the Commission has expressed its views in a subjective
manner that “Printing Industries, though an industry, cannot be categorized under
industrial tariff category”, without citing any reason.
The Objector submitted that the Commission is required to adopt an objective,
analytical and reasoned approach while deciding tariff category of Printing Industries.

CSERC Tariff Order FY 2023-24

31

<!-- page 54 -->

Petitioner’s Reply
CSPDCL submitted that determination of retail supply tariff and differentiating
among consumers while tariff determination, is a prerogative of State Commission
under section 62(3). The retail supply tariff of a consumer category has to be within
the limits of +20% of Average cost of supply. Further, if the applicant request
considered by the Commission the petitioner proposal ARR for the FY 2023-24 shall
be protected. In addition to the above contentions raised by objector that are not
specifically admitted are denied.
Commission’s View
Hon‟ble APTEL in order dated 07.08.2014 passed in appeal no. 131 of 2013 in the
matter of Vianney Enterprises V. Kerala State Electricity Regulatory Commission,
held that the categorization of consumer for the purpose of electricity tariff is under
the domain of the State Commission under the Electricity Act, 2003. Under Section
62(3) of the Electricity Act, the State Commission can differentiate between the tariffs
based on purpose for which the supply is required. The State Commission is
empowered to differentiate in tariff based on a purpose for which the supply is
required. Considering the above, the Commission has not found any merit, therefore,
tariff category of printing industries is kept unchanged.
2.5.23 Promotional Electricity Tariff for ‘Export Oriented Units’
The Objector requested the Commission to extend the scope of promotional electricity
Tariff granted to export oriented Textile industries to other Textile industries also.
Petitioner’s Reply
CSPDCL submitted that determination of retail supply tariff and differentiating
among consumers while tariff determination, is a prerogative of the Commission
under Section 62(3) of the Act. In the capacity of Distribution Licensee, CSPDCL
submitted that the aforesaid request of the Objector may be considered subject to
protection of Petitioner‟s approved ARR for FY 2023-24.
Commission’s View
The detailed rationale and tariff philosophy adopted by the Commission, while
determining the category-wise tariff for FY 2023-24 is given in the relevant Chapter
of this Order.
2.5.24 Voltage-wise Cost of Supply
The Objector submitted that Hon‟ble APTEL in its Judgment in Appeal No. 102 of
2010 dated May 30, 2011, provided the guidelines for calculation of cost of supply
calculation. CSPDCL is continuously following the same method for calculating the
cost of supply and has proposed tariffs accordingly, without considering the
development in metering network and availability of actual voltage-wise losses. Due
to this, the consumers who are having connectivity at 220 kV voltage are compelled
to bear both the transmission losses as well as distribution loss.
The objector also requested the Commission to direct CSPDCL to take steps to reduce
losses, not to entertain the CSPDCL‟s proposal to abolish the existing provision of
power off hours under HV 4 – Steel Industries category.
32

CSERC Tariff Order FY 2023-24

<!-- page 55 -->

Petitioner’s Reply
CSPDCL submitted that the applicant‟s request to consider Voltage-wise Cost of
Supply in tariff determination is misplaced in light of the fact that the Commission
has already differentiated the energy charges for HV-4 tariff category on the basis of
voltage of supply. It is pertinent that energy charges for 220 kV and 132 kV are
substantially less than energy charges for 33 kV and 11 kV voltage.
The Hon‟ble Supreme Court in the matter of Punjab State Power Corporation Limited
V/s Punjab State Electricity Regulatory Commission & Ors. in Civil Appeal No. 4510
of 2006 decided on 10.02.2015 [(2015) 7 Supreme Court cases 387] has already
upheld principles of cost of supply and cross subsidy. Accordingly, the present tariff
structure in respect of HV-4 tariff category wherein different energy charges are
determined for different supply voltages, is consistent with the aforesaid legal
principle settled by the Hon‟ble Supreme Court.
Further, retail supply tariff is statutory function of the Commission and while
discharging this function it is guided by the Tariff Policy. According to Clause 8.3(2)
under „tariff design‟ of Tariff Policy notified on 28.01.2016, the retail supply tariff of
a consumer category has to be within the limits of + 20% of Average Cost of Supply.
In view of the above, the request of the applicant to consider Voltage-wise Cost of
Supply for retail tariff determination is baseless and need not be taken into
consideration.
Commission’s View
The approach of the Commission regarding determination of Voltage-wise Cost of
Supply is given in the relevant Chapter of this Order. The Commission has already
implemented differential tariffs within a consumer category based on the supply
voltage, and consumers taking supply at higher voltages are required to pay lower
tariff, as compared to consumers taking supply at lower voltages. These changes have
been retained in this Tariff Order also.
2.5.25 Projected revenue, Energy balance, Parallel Operation Charges and Power
purchase Cost
The Objector submitted that ARR of CSPDCL for 2023-24 is Rs.15581.14 Crore,
whereas projected revenue at existing tariff and charges is Rs. 19,344.17 Crore which
is surplus of 3763.03 Crore and petitioner wants to recover entire previous gap
through the existing tariff which is already over estimated.
In view of this, objector requested the Commission to provide tariff relief to the
consumers and reduction in parallel operation charges considering a huge revenue
surplus.
Objector submitted that the projected energy balance for financial years 2022-23,
2023-24, in the CSPDCL petition, where sales projection for all categories are
increasing every year, but unfortunately on the point of energy losses for below 33
KV (in%) is projected almost same without any positive corrections. Hence requested
the Commission to reduce the losses as it impacts on the tariff specially for EHV
consumers

CSERC Tariff Order FY 2023-24

33

<!-- page 56 -->

Power Purchase cost is also a major component of tariff. It needs to consider the
voltage wise power purchase rate by CSPDCL and taking into account of this needs to
access the actual cost of purchase for different category of consumers instead of
uniform rate of purchase.
Petitioner’s Reply
CSPDCL submitted that the revenue earned through Parallel operation charges is
among the constituents of non-tariff income. Any rationalization among such
constituents would have a bearing on tariff of normal electricity consumers. As
CSPDCL has requested to continue the existing tariff design in present tariff proposal,
hence any consideration to applicant‟s present request may cause additional burden on
other consumers.
CSPDCL submitted that the applicant‟s contention on projected revenue at existing
tariff charges FY 2023-24, Energy balance for FY 2022-23 and FY 2023-24 & Power
purchase cost need not require any comments as the same have been dealt in the tariff
petition in details. Furthermore applicant has also not objected any specific point
about tariff petition.
Commission’s View
As regard the revenue surplus projected by CSPDCL, it is pertinent to mention that
this revenue surplus is stand-alone revenue surplus for FY 2023-24 whereas when the
revenue gap of FY 2021-22 is taken into account, no surplus remains. Hence, request
of the objector to reduce the parallel operation charges cannot be accepted.
2.5.26 Provision of Power Off hours
The Objector submitted that the Commission should not entertain the CSPDCL's
proposal to abolish the existing provision of power off hours under HV-4 steel
industry category for the HT consumer of above 33 KV voltage.
Petitioner’s Reply
CSPTCL has submitted on their tariff petition no. 94/2022 that the Transmission
System Availability Factor (TSAF) for above 33 KV line (i.e. 400 kV, 220 kV & 132
kV) is 99.77% for FY 2021-22. Hence, CSPDCL has requested in petition to abolish
the existing provision of Power off hours under HV-4 Steel Industries category for the
HT consumer at EHV connectivity.
Commission’s View
The Commission has observed that the TSAF for networks 132kV and above is
99.77%, therefore, outage in 132kV and above system is almost negligible. Hence, the
Commission has accepted the request of CSPDCL for abolishing power off hours for
132kV and above system.
2.5.27 Revenue from Existing Tariff
The Objector submitted that there is lack of transparency in estimating revenue from
the existing tariff particularly from Railway and Steel Industry. ABR of Railway and
Steel Industry comes out to be Rs. 7.41 per unit. Such huge ABR indicates that the
34

CSERC Tariff Order FY 2023-24

<!-- page 57 -->

Petitioner has deliberately not considered huge load factor rebate allowed to both
categories.
Petitioner’s Reply
CSPDCL submitted that in response to specific query of the Commission, CSPDCL
has submitted detailed reply showing revenue from sale of power at existing tariff for
FY 2023-24 incorporating the implications of load factor rebate allowed by the
Commission in the Tariff Order for FY 2022-23, impact of TOD tariff with details of
TOD time slot, vide submission through Letter No. 2626 dated February 03, 2023.
Commission’s View
The Commission‟s analysis on the revenue from existing tariff has been detailed in a
relevant Chapter of this Order. The Commission has considered the impact of load
factor rebate for HV-1 and HV-4 category, while computing the revenue from
existing tariff for FY 2022-23.
2.5.28 Revenue Gap/Surplus for FY 2021-22
The Objector submitted that CSPDCL has not revealed under-recovery/over-recovery
of revenue from consumers with reference to the estimation/approval in the Tariff
Order. The Objector objected to the ARR submitted by CSPDCL and sought relief on
following:
a. Under-recovery (i.e., difference between actual ABR and ABR approved in Tariff
Order multiplied by units sold to such category of consumers) from Steel Industry
(HV-4) and Railway (HV-1) should be worked out for FY 2019-20 and previous
years and financial impact should be loaded to the same category of consumers.
b. To maintain transparency, CSPDCL should be instructed to share the details of
above calculations considering load factor rebate and share with public.
c. To keep steel industry as subsidizing category, the load factor rebate needs to be
withdrawn/ abolished.
Petitioner’s Reply
CSPDCL submitted that the contentions raised by the Objector regarding retail tariff
determination are connected to previous Tariff Orders and proposal for ensuing year.
With regard to contentions on retail tariff determination for the previous years,
CSPDCL submitted that the Tariff Orders of all previous except FY 2022-23 (Tariff
Order dated April 13, 2022) have attained finality as each of these have completed the
term after issuance of subsequent Tariff Orders. Under the adopted practice, every
change in existing tariff design is supported by justification and reasons in respective
Tariff Order by the Commission. Facts demonstrate that the Objector have not
exercised remedies available under the Act, in terms of examining the legality,
propriety and correctness of these Orders.
Under such circumstances, raising issues with regard to previous Tariff Orders before
the Commission again would be inappropriate and abuse of regulatory process. In
light of the above, the Petitioner submitted that it would not like to comment on
contentions raised by the Objector on tariff determination of previous Tariff Orders.
CSPDCL submitted that the Revenue Gap at Table No. 26 is computed according to
CSERC Tariff Order FY 2023-24

35

<!-- page 58 -->

the regulatory practice adopted by the Commission. Pursuant to such practice, the
estimation of expenses and revenue is compared with actual expenses and revenue in
terms of audited accounts at the time of truing up to get stand-alone gap position of
CSPDCL for FY 2021-22. The Table also includes additional gap arising out of
Review Petition included at Chapter 5 of present Tariff Petition.
Further, the projections of revenue for ensuing year, i.e., FY 2023-24 are also done by
applying existing tariff on estimated sales discovered on the basis of scientific
methodology described at Para 8.6 to 8.8 of the Tariff Petition. Additionally,
CSPDCL has also provided the revenue implications arising out of implementation of
load factor rebate and TOD in response to data gaps raised by the Commission
pursuant to prudence check.
CSPDCL submitted that the Objector‟s contention on closing deficit for FY 2021-22
do not require any comments as the same have been dealt in the Tariff Petition in
detail. Further, CSPDCL has also submitted reply to data gaps/additional points on
Tariff Petition to the Commission under prudence check.
Commission’s View
The Commission has adjusted the Revenue Gap/(Surplus) arrived at based on final
true-up of FY 2021-22, with the stand-alone Revenue Gap/(Surplus) of FY 2023-24,
and the tariffs have been designed based on the cumulative Revenue Gap/(Surplus) as
per the methodology adopted in previous Tariff Orders.
2.5.29 Retail Tariff Proposal
The Objector submitted that CSPDCL has not submitted any proposal related to
change in terms of current tariff applicable in year 2023-24 that means the petitioner
wants to continue with same terms and condition of current tariff applicable in year
2022-23. Therefore, the objections in reference to the terms and conditions of current
tariff applicable in FY 2022-23, are that, since, the objective of the rebate is to
increase the utilization of power supply from CSPDCL, this facility of Load Factor
rebate should not be applicable to those consumers in HV-4 category having captive
generating facility with installed capacity above 1 MW. This will encourage higher
consumption by this subsidizing category, which would Improve the revenue of
CSPDCL.
Whereas after allowing huge Load Factor rebate (LF rebate in short) the actual
average billing rate to such steel industries consumer is less than Rs. 5.41 per unit i.e.,
almost 1 Rs lower than ACoS of Rs.6.41 and thus it will become de facto a subsidized
category.
In tariff order FY 22, nowhere any justification / financial calculation was given why,
the cut-off of load factor for rebate shifted upward from 63% to 50%, it is totally
baseless and giving undue benefit to particular class/ section of Steel industry
consumers. Similarly, there is no technical/financial justification of giving higher load
factor rebate on energy charges of entire consumption.
The criteria and quantum of load factor rebate allowed to railway and steel industries
are different, whereas as per economic considerations it is not appropriate therefore,
we request with the Commission that if load factor rebate has to be allowed then the
criteria and quantum of load after rebate must be same for all class of consumers but
36

CSERC Tariff Order FY 2023-24

<!-- page 59 -->

should be limited to Steel industry and Railway like power factor improvement
penalty/incentives are being allowed.
The quantum of load factor (30%) rebate being allowed to railway is huge and
resulting very 1ow realization as ABR, therefore we request with the Commission to
reconsider the basis of such huge load factor rebate and tariff for railway as
comparison to the same of all neighbouring states.
Petitioner’s Reply
CSPDCL submitted that under Section 62(3) of the Act, the Commission has powers
to determine retail tariff of different consumer categories and differentiate among the
consumers on grounds of consumer load factor, power factor, voltage, total
consumption of electricity during any specified period or the time at which the supply
is required or the geographical position of any area, the nature of supply and the
purpose for which the supply is required. CSPDCL has not proposed any change in
tariff design in respect of steel industries and requested the Commission to kindly
continue the existing tariff design.
CSPDCL requested the Commission to consider the Objector‟s prayer subject to
protection of approved ARR of CSPDCL for FY 2022-23.
Commission’s View
The Commission has adjusted the Revenue Gap/(Surplus) arrived at based on final
true-up of FY 2021-22, with the stand-alone Revenue Gap/(Surplus) of FY 2023-24,
and the tariffs have been designed based on the cumulative Revenue Gap/(Surplus) as
per the methodology adopted in previous Tariff Orders.
2.5.30 Excess Rebate in Time of the day Tariff (TOD)
The Objector submitted that as per Tariff order FY 2022-23 clause 30. p), reproduced
below as: 30 p) In order of better utilize the surplus power available with CSPDCL especially
during night off-peak hours, the tariff for night-time consumption has been reduced
from 75% to 65% of normal rate of energy charge.
Whereas the factor of TOD is less than 1 i.e., 95.4%, when hourly consumption
pattern remains unchanged for 24 hours; thus, if any continuous industry opts TOD
tariff without changing its consumption pattern, he will get benefit of reduction in
tariff by 4.6% without contributing anything to distribution company‟s demand curve,
which setbacks the purpose of TOD tariff. And this may affect expected revenue
calculation by more than 400 Crore.
Petitioner’s Reply
CSPDCL submitted that the present TOD method is appropriate as per commercial
matrix in respect of availability of power.
Commission’s View
For deciding the TOD tariff, the Commission sought the relevant data from SLDC.
Considering the data provided by SLDC, the Commission has revised the TOD tariff
and the same is given in tariff schedule chapter.
CSERC Tariff Order FY 2023-24

37

<!-- page 60 -->

2.5.31 Prepaid Smart Meter
The Objector submitted that CSPDCL daily publishing news related to pre-paid smart
meters in local newspaper and spreading panic among consumers but not said
anything specific in this petition. They should be asked to clarify following issue
related to the scheme: i. In RDSS scheme when there is only one compulsion of installing pre-paid smart
meters in Govt connection then what is the necessity that CSPDCL is bent upon to
install pre-paid smart meters in more than 50 Lakh consumers.
ii. Is there any success story for similar case, in any part of India?
iii. Who is going to bear the residual cost of more than 50 lakh electronic old meters
and infrastructure of reading, billing, collection?
iv. Have CSPDCL done activity-based costing for reading, billing, and collection,
activities if yes then the same may be published in public domains
v. What may be the charges be paid to the contractor for his services of per-paid
meters?
vi. In case of BPL consumers, the energy charges are being subsidized by Govt of CG
and if smart meter are placed in their premises, then who will bear the O&M
changes including depreciation charges etc. of per-paid smart meters.
Petitioner’s Reply
CSPDCL submitted that the Pre-paid smart meters are not connected to CSPDCL‟s
Tariff Petition, hence, no comments are offered. But, CSPDCL already submitted the
details of the RDSS scheme under petition no. 04/2022 in the matter of the Capital
Investment Plan for FY 2022-23 to 2024-25. Accordingly, Capital Investment Plan
for FY 2022-23 to 2024-25 has approved by Commission.
Commission’s View
The Commission has found that concerns raised by the objector are not related to the
present petition and hence, are not considered.
2.5.32 Sale of Surplus power and Tariff hike
As regards sale of surplus power, the objector submitted that at page 60, CSPDCL
stated that it will sale 7075.87 MU surplus power and collect Rs. 3495.48 Crore
which seems unrealistic.
As regards tariff hike, the objector submitted that CSPDCL has not proposed any hike
in tariff whereas it has projected a revenue deficit of Rs. 2371 Crore and this may be
due to political compulsion of coming state assembly election. As per APTEL‟s
decision normally no regulatory asset can be created thus there is no alternate remains
other than hike in tariff specially of Steel Industry category.
Petitioner’s Reply
CSPDCL submitted that surplus power, if any, shall be sold to retail consumer of the
State as well as on exchange/utilized for banking purpose.
CSPDCL submitted that determination of tariff for retail sale is prerogative of the
Commission U/s 62(3) of the Electricity Act 2003, hence CSPDCL has submitted its
38

CSERC Tariff Order FY 2023-24

<!-- page 61 -->

request for rationalized tariff for all consumer categories required to meet the
approved gap. CSPDCL requested the Commission to approve the same.
Commission’s View
In the present Order, the Commission has made a reasonable assessment of the
surplus quantum to be sold in the Power Exchanges for the Control Period, and has
considered some short-term purchase from Power Exchanges to meet the energy
requirement.
The Commission has adopted various tariff rationalisation measures to recover the
approved annual revenue requirement of CSPDCL.
2.5.33 Railway Tariff
The Objector submitted the Railways is a public utility and a bulk customer.
Therefore, Railways should be provided with favourable tariff formulation so that
CSPDCL and Railways can serve the Nation as well as the State together. The
Objector hence, requested the Commission to reduce tariff for HV-1 (Railway
Traction). Railway should be provided electricity @ economical single part tariff for
their traction connection. Further, the tariff for non-traction load of Railways in HV-3
category should be reduced. All non-traction load should be considered under LV-6
(Public utilities) tariff category.
The reasons provided by the Objector are as follows:
a. It is a base load consumer with average load factor of 30 to 40%;
b. Railways being a Deemed Licensee should be provided power at Average Power
Purchase Cost;
c. Article 287 of the Constitution of India forbids States from imposing any kind of
tax on the consumption or sale of electricity, which is consumed by Railways;
d. Railway is playing a very important role in sustainable development of the State
utilising energy efficient measures. By further rationalising tariff, it would help
Railways justify the expenditure.
Petitioner’s Reply
CSPDCL submitted that the Objector has not made any comments on the Tariff
Petition. The contention that the Objector may be treated as deemed licensee, does not
require any consideration in light of the fact that such issue is not connected to the
subject matter of present Tariff Petition. Further, the benefit of load factor rebate is
already extended to Railway traction tariff under HV-1 category where traction substations attaining load factor above 20% are availing rebate of 20% in billing of
energy charges, under existing tariff design. Hence, consideration of single part tariff
being HT consumer will encourage other HT consumer for the same.
The request for treatment of non-traction load under LV-6 tariff category is an issue
related to tariff design, which falls under the realm of the Commission. Under a
conscious decision, bulk supply at one point to establishments applicable to consumer
like Railway is categorised as HV-3 (other industrial and general purpose nonindustrial), which is to meet commercial implications of mixed load in same premises
availing non-traction connection. Further, request to include non-traction load under
LV-6 tariff category may also observe the limitations of electrical safety involved in
CSERC Tariff Order FY 2023-24

39

<!-- page 62 -->

issuing electricity connections simultaneously of HV/LV in same premises and more
so, this issue is controlled by the Supply Code and not by Tariff Order.
Further, the request of the Objector to reduce tariff of HV-1 and HV-3 tariff
categories requires examination of Tariff Policy Clause 8.3(3) wherein it is stipulated
that consumer tariff has to remain within the limits of + 20% of average cost of
supply. Pursuant to load factor rebate in HV-1 tariff category, applicant is already
availing the benefit of subsidized tariff category. Hence, request for further tariff
reduction would be unfair.
Commission’s View
The detailed rationale and tariff philosophy adopted by the Commission, while
determining the category-wise tariff for FY 2023-24 is given in the relevant Chapter
of this Order. The detailed Tariff Schedule applicable for FY 2023-24 is given in the
Tariff Schedule Chapter of this Order.
2.5.34 Educational institution in LV1 category
The Objector has requested the Commission to delete "Educational institutions
controlled by firms and society regd. as non-profit organisation" from LV-1 category
so that electricity can be supplied to poor people at justified rate and retain
"educational institution controlled by Govt. and Registered religious organisation" in
LV-1 category.
Petitioner’s Reply
CSPDCL submitted that it is prerogative of the CSERC to decide the applicability of
any tariff category therefore it is upto the Commission to take any view on the
suggestion of the objector.
Commission’s View
The detailed rationale and tariff philosophy adopted by the Commission, while
determining the category-wise tariff for FY 2023-24 is given in the relevant Chapter
of this Order. The detailed Tariff Schedule applicable for FY 2023-24 is given in the
Tariff Schedule Chapter of this Order.
2.5.35 Provision of LT connection
The Objector has requested the Commission to make a provision to issue LT
connection upto 265 HP (200 kW) and to introduce TOD tariff in LT tariff category
also.
Petitioner’s Reply
CSPDCL submitted that the issue of LT connection upto 265 HP (200 kW) is not
related to present tariff petition therefore there is no need to comment anything on this
issue. As regards to introduction of TOD tariff, CSPDCL submitted that the issue is
prerogative of the Commission therefore it is upto the Commission to take any view
on the suggestion of the objector.

40

CSERC Tariff Order FY 2023-24

<!-- page 63 -->

Commission’s View
The Commission has already enhanced load limit from 100 HP to 150 HP at low
voltage level. It is not technically feasible to enhance the limit further to or 265HP.
The proposal of the objector for introducing TOD tariff in LT connections may be
considered once the smart meters are installed.
2.5.36 Issues raised by the small shopkeepers
The Objector has requested the Commission;
i.
ii.
iii.

iv.

v.
vi.

To extend the facility of electricity bill half scheme to small shopkeepers in
line with electricity bill half scheme provided to domestic consumers.
To revise the prevailing VCA charges to rationalize it.
To make tariff of consumers who are getting electricity from single point
consumer of CSPDCL, equal to the tariff applicable to consumers of
CSPDCL.
To retain the industrial category tariff of consumers who were initially issued
industrial connection but CSPDCL has converted the same to non-domestic
tariff category.
To make provision for providing multiple connections in single premises
because different types of activity is being performed in same premises.
To shift some frozen food plant to agriculture allied tariff category who are
being presently billed as per non-domestic tariff category.

Petitioner’s Reply
CSPDCL submitted the following observations as:
i.
ii.
iii.
v.
vi.

It is a jurisdiction of the State Govt. to introduce electricity bill half scheme to
small shopkeepers therefore CSPDCL has no comments on this issue.
VCA charges is being levied in accordance with the CSERC MYT Regulation,
2021, therefore, this issue is not related to the present petition.
& iv. Subject matter does not pertain to this petition.
Matter pertains to the provisions of the supply code not to this petition.
It is the jurisdiction of the CSERC to decide applicability of the tariff category
to a specific class of consumers therefore CSPDCL need not to comment
anything on this issue.

Commission’s View
The Commission has no jurisdiction to introduce electricity bill half scheme to small
shopkeepers. VCA charges is being levied in accordance with the CSERC MYT
Regulation, 2021, therefore, this issue is not related to the present petition. Issue of
providing multiple connections in same premises is also not related to this petition.
The detailed rationale and tariff philosophy adopted by the Commission, while
determining the category-wise tariff for FY 2023-24 is given in the relevant Chapter
of this Order.

CSERC Tariff Order FY 2023-24

41

<!-- page 64 -->

2.5.37 Issues of extending electricity half bill to temporary domestic connection
The objector has requested to extend the facility of electricity half bill scheme to
temporary domestic connections also.
Petitioner’s Reply
CSPDCL submitted that it is the jurisdiction of the State Govt. to introduce electricity
bill half scheme therefore CSPDCL has no comments on this issue.
Commission’s View
It is the jurisdiction of State Govt. to extend electricity bill half scheme to any class of
consumer, therefore, this matter should be raised before appropriate forum.
2.5.38 Issue of extending domestic tariff to private hostels
The objector submitted that as per prevailing tariff order, domestic tariff is applicable
to government hostels whereas private hostels are being charged as per non-domestic
tariff category. Therefore, objector has requested to the Commission to remove the
anomaly and extend domestic tariff to private hostels.
Petitioner’s Reply
CSPDCL submitted that determination of retail supply tariff and differentiating
among consumers while tariff determination, is a prerogative of State Commission
under section 62(3). Further, if the applicant request considered by the Commission
the petitioner proposal ARR for the FY 2023-24 shall be protected.
Commission’s View
The detailed rationale and tariff philosophy adopted by the Commission, while
determining the category-wise tariff for FY 2023-24 is given in the relevant Chapter
of this Order. The detailed Tariff Schedule applicable for FY 2023-24 is given in the
Tariff Schedule Chapter of this Order.
2.5.39 Issue of Tariff Classification of Wooden Door Manufacturing Industries under
LV Supply
The Objector submitted that there are about 75 Wooden Door Manufacturing
Industries in Chhattisgarh, registered with Department of Industries. These are very
small industries having connected load of 25-50HP only and are members of CECC.
After inspection, CSPDCL has billed them under LV2- Non-Domestic Category
instead of LV5- LV Industries stating that „Wooden Door Manufacturers‟ are covered
under „Furniture Maker‟.
Objector further submitted that the Hon‟ble Supreme Court of India has defined
„Furniture‟ as movable item and subject of convenience whereas Doors are not
movable item and are basic requirement of a premise for security and privacy
purpose. Hence Doors cannot be termed as Furniture.
In view of the above, the objector submitted that Tariff Category LV5- LV Industries
will be applicable to Wooden Door Manufacturing Industries, who are certainly not
“Furniture Makers”.
42

CSERC Tariff Order FY 2023-24

<!-- page 65 -->

Petitioner’s Reply
CSPDCL submitted that determination of retail supply tariff and differentiating
among consumers while tariff determination, is a prerogative of State Commission
under section 62(3). Further, if the applicant request considered by the Commission
the petitioner proposal ARR for the FY 2023-24 shall be protected. In addition to the
above contentions raised by objector that are not specifically admitted are denied.
Commission’s View
The Commission has considered the objection and found the present categorisation
appropriate and self-explanatory, hence, no changes have been made in the tariff
category.
2.5.40 Tariff for LT Industries
The Objector submitted that the rural incentive of 5% on Energy Charges, existing
Adivasi Area Incentive for Bastar and Saguja and 10% rebate on Energy Charges to
Women Self-help Groups should be continued. Food Processing Units should be
given 5% rebate on Energy Charges in line with 5% rebate to HT Rice Mills.
Only Night Tariff may be introduced to encourage consumption during the night
hours. Load factor incentive may be introduced in similar way as given to HT
industries and as made available to LT Industries in MP so that more electricity
consumption will be encouraged using the same infrastructure. Further, power factor
penalty below 0.90 made applicable since 01.08.2021, should be rolled back to earlier
level of 0.85. Power factor incentive may be given step-wise on each point
improvement above 0.85.
The objector also submitted that tariff for LT Industries should be reduced and
existing supply affording charges should be reviewed.
Petitioner’s Reply
CSPDCL submitted that it has not given any specific proposal for retail tariff
determination. It is submitted that the retail tariff determination is the prerogative of
the Commission under Section 62 of the Electricity Act, 2003.
Further the suggestions related to Supply affording charges is related to the Supply
Code and may not be dealt in the matter of Tariff. In addition to the above contentions
raised by objector that are not specifically admitted are denied.
Commission’s View
The Commission has continued the rebate as requested by the objector. The detailed
rationale and tariff philosophy adopted by the Commission, while determining the
category-wise tariff for FY 2023-24 is given in the relevant Chapter of this Order. The
detailed Tariff Schedule applicable for FY 2023-24 is given in the Tariff Schedule
Chapter of this Order.
2.5.41 Tariff for Agriculture Consumers
The Objector submitted that the existing tariff for Agriculture Consumers is quite high
and near to the level of agriculturally rich States. Farmers of Chhattisgarh are poor
CSERC Tariff Order FY 2023-24

43

<!-- page 66 -->

and any tariff increase from the existing level shall prove to be detrimental to the
farmers. Therefore, there should be no increase in tariff for Agriculture Consumers.
Petitioner’s Reply
CSPDCL submitted that determination of retail supply tariff and differentiating
among consumers while tariff determination, is a prerogative of State Commission
under section 62(3). The retail supply tariff of a consumer category has to be within
the limits of +20% of Average cost of supply. Further, if the applicant request
considered by the Commission the petitioner proposal ARR for the FY 2023-24 shall
be protected. In addition to the above contentions raised by objector that are not
specifically admitted are denied.
Commission’s View
The Commission, in this tariff order, has not increased tariff applicable to agriculture
category. The philosophy and rationale adopted by the Commission is detailed in the
relevant Chapter of this Order.
2.5.42 Tariff for Oxygen Plant
The Objector submitted that in the previous Tariff Orders, oxygen plant got
concession of 10% on energy charge but at the same time tariff and VCA was
increased. Therefore, effectively oxygen plants have got negligible benefit of
concession.
The Objector‟s request is to move standalone oxygen plants into HV-8 (Industries
related to manufacturing of equipment for power generation from renewable energy
sources) or HV 4 (Steel industries).
Petitioner’s Reply
CSPDCL submitted that determination of retail supply tariff and differentiating
among consumers while tariff determination, is a prerogative of State Commission
under section 62(3). Further, if the applicant request considered by the Commission
the petitioner proposal ARR for the FY 2023-24 shall be protected. In addition to the
above contentions raised by objector that are not specifically admitted are denied.
Commission’s View
The Commission after considering the views and suggestions of all objectors has
approved the Tariff for FY 2023-24. The philosophy and rationale adopted by the
Commission is detailed in relevant chapter of this Order.
2.5.43 Delayed Replacement of Burnt/Damaged Transformers
The Objector submitted that CSERC has expressed in Tariff Order FY 2022-23 that if
distribution transformer gets damaged, consumers are pressurised to clear dues as a
precondition of replacement of such transformer. Therefore, CSPDCL should be
directed for replacement of all burnt/ damaged transformers to supply power to
Agriculture consumers. The Commission has noted the objection on delayed
replacement of burnt/ damaged transformers by CSPDCL. CSPDCL is directed to
replace such transformers as per the timelines specified in the Standard of
44

CSERC Tariff Order FY 2023-24

<!-- page 67 -->

Performance Regulations. However, the consumers also have the obligation to clear
their dues as per the bills raised by CSPDCL.
But the situation in the field remains the same in spite of above direction. Hence the
Objector is requested to the Commission to instruct for immediate replacement of all
burnt/ damaged transformers relating to supply to Agriculture Consumers.
Petitioner’s Reply
CSPDCL has not submitted any reply.
Commission’s View
The Commission has noted the objection on delayed replacement of burnt/ damaged
transformers by CSPDCL. CSPDCL is directed to replace such transformers as per
the timelines specified in the Standard of Performance Regulations. However, the
consumers also have the obligation to clear their dues as per the bills raised by
CSPDCL.
2.5.44 Temporary Connections to Agriculture Consumers
The Objector submitted that large number of consumers are waiting since long to get
the permanent connection from CSPDCL and have no choice other than to avail
Temporary Supply. Hence, CSPDCL should be directed to prepare time-bound plan
for release of pending Agriculture connections to farmers.
Petitioner’s Reply
CSPDCL has not submitted any reply.
Commission’s View
The Commission has noted the objection on delay in releasing new connections to
Agriculture consumers by CSPDCL. CSPDCL is directed to release the new
connections as per the timelines specified in the Standard of Performance
Regulations.

CSERC Tariff Order FY 2023-24

45

<!-- page 68 -->

3

DETERMINATION OF INPUT COAL PRICE AT GARE PALMA-III MINE
END FOR ABVTPS

3.1

Background
CSPGCL has submitted the Petition for True up of the capital cost as well as
determination of the input price of coal from Gare Palma-III (GP-III) mine for FY
2021-22. CSPGCL has submitted details of its actual expenses incurred during the
year under various heads, viz., O&M expenses, depreciation, interest on loans,
interest on working capital, etc., and the total input price of coal as per the CSERC
MYT Regulations, 2021.
Regulation 5.9 and Regulation 49 of the CSERC MYT Regulations, 2021 specifies as
under:
“5.9. …. In respect of Integrated mine, the generating company shall file
separate mine wise petition for determination of input price of coal from such
mine.”
“49. Input Price of coal and lignite for energy charges:
49.1. Where the generating company has the arrangement for supply of coal
from the integrated mine(s) allocated to it, for use in one or more of its
generating stations as end use, partially or fulIy, the energy charge
component of tariff of the generating station shall be determined based on the
input price of coal, as the case may be, from such integrated mines determined
in accordance with these regulations.”
In accordance with the above Regulations, in the present Order, the Commission has
carried out the true up of the capital cost and also determined the Input Price of coal
from GP-III coal mine for FY 2021-22 based on the submission by CSPGCL as
discussed in the subsequent sections of this Order.

3.1.1 Allocation of Gare Palma-III Coal Mine
CSPGCL submitted that initially, the Parsa coal block was allotted to the erstwhile
CSEB and subsequently to CSPGCL for ABVTPP. The Gare Palma-III (GP-III) coal
block was allotted to M/s Goa Industrial Development Corporation (GIDC) vide letter
No. 38039/14/2008 CA-I dated November 12, 2008 by the Ministry of Coal, GOI.
GIDC, in terms of the provisions of Rule 22(4) of the Mines and Mineral Concession
Rules, 1960 as amended from time to time, prepared the Mining Plan for GP-III mine.
The Mining Plan for GP-III mine was approved by the Ministry of Coal, GOI vide
letter No. 13016/57/2009 CA-I dated May 17, 2010. Further, the approval for Mining
Lease was accorded by the GOI in terms of the provisions of Section 5(1) and Section
6(1) of the Mines and Mineral (Development and Regulation) Act, 1957 vide letter
No.13016/57/2009- CA-I dated May 30, 2011.
The Hon‟ble Supreme Court vide its Order dated September 24, 2014, cancelled the
allocation of 218 no. of coal blocks. In light of the aforesaid Order, the Parsa coal
block was deallocated from CSPGCL and the Gare Palma III coal block was
deallocated from GIDC.
Subsequently, after enactment of the Coal Mine (Special Provisions) Act, 2015, the
GP-III coal block was classified under Schedule I of the said Act. In terms of the
46

CSERC Tariff Order FY 2023-24

<!-- page 69 -->

provisions of Section 5 of the said Act, the GP-III coal block was allocated to
CSPGCL for utilization of coal in end-use plant of ABVTPP.
In terms of Section 8 of the Coal Mine (Special Provisions) Act, 2015 and Clause (c)
of Sub Rule (2) of Rule 7 and Sub-Rule (1) of Rule 13 of the Coal Mine (Special
Provisions) Rule, 2014, the Nominated Authority issued the Allotment Order (Order
No. 103/23/2015/NA) dated September 14, 2015 for allotment of the GP-III coal
block to CSPGCL.
In terms of Section 8 of the Coal Mine (Special Provisions) Act, 2015, all the
statutory permits and approvals accorded to prior allotee were transferred to
CSPGCL.
The brief description of the GP-III coal block is tabulated below:
Table 3-1: Brief Description of GP-III Coal Block
Name of Coal Mine

Gare Palma Sector III

Latitude

22010‟24.36” N to 22011‟15.84” N

Longitude

83027‟26.62” E to 83031‟56.85” E

Coalfield

Mand Raigarh

Villages

Bajarmuda, Dholnara

District

Raigarh

State

Chhattisgarh

Lease hold land for mining (Private)

444.58 (Hectares)

Lease hold land for compensatory 400 (Hectares)
afforestation (Government)

Through transparent open competitive bidding, CSPGCL appointed Gare Palma III
Collieries Limited as the Mine Development Operator (MDO). Crushing and the mine
end transportation (Surface Transportation Charges or STC in the Coal India
parlance) is also in the MDO scope. The production from the GP-III mine commenced
in December 2019 and since then mining progress has been better than the Mine Plan
benchmarks. As per Section 61 of the Act, the Regulations notified by the Central
Electricity Regulatory Commission (CERC) are one of the guiding principles for
framing of Regulations by the State Electricity Regulatory Commission‟s (SERCs).
For determination of Input Price from an integrated mine, certain provisions were
included in the draft CERC Tariff Regulations, 2019. However, considering various
suggestions, the same could not find place in the final Regulations. Provisionally, the
generating plants were allowed to bill the coal from integrated mines at the notified
rates of Coal India Ltd. The Regulation was finally notified vide second amendment
to CERC Tariff Regulations, 2019. In the State of Chhattisgarh, the provisions for
determination of input cost of coal were first notified in the MYT Regulations 2021.
For the intervening period, in response to CSPGCL request for guidance related to
billing of ECR / FCA for power generated by coal received from GP III mine, in line
CSERC Tariff Order FY 2023-24

47

<!-- page 70 -->

with the principle adopted by the CERC, the Commission vide letter dated January
27, 2020, directed CSPGCL to provisionally bill the coal from integrated mines of
GP-III at the notified rates of Coal India Ltd. During FY 2021-22, billing continued in
accordance to the Commission‟s direction.
CSPGCL submitted that upon notification of CSERC MYT Regulations, 2021, for the
Control Period April 01, 2022 to Match 31, 2025, CSPGCL filed Petition for
determination of ARR for its conventional Power Plants, which got registered as
Petition No. 01 of 2022 (T). The Petition included prayer with detailed submissions
for approval of input cost of coal from the integrated mine Gare Palma – III (GP III)
along with detailed submission on capital cost of the GP III mine. The Commission,
allowed the capital cost of the mine and input cost of coal for the current Control
Period vide the MYT Order.
3.1.2 Date of Commercial Operation for GP-III mine
CSPGCL submitted that regarding the Date of Commercial Operation (COD) of the
integrated mines, Regulation 3.19 (iii) of the CSERC MYT Regulations, 2021
specifies as under:
“3.19. "Date of Commercial Operation" or "COD" means …. (iii) The date of
commercial operation in case of integrated mine(s), shall mean the earliest of
―
a) the first date of the year succeeding the year in which 25% of the Peak
Rated Capacity as per the Mining Plan is achieved; or
b) the first date of the year succeeding the year in which the value of
production estimated in accordance with these regulations, exceeds total
expenditure up to that year; or
c) the date of two years from the date of commencement of production:”
During FY 2020-21, the production from the mine crossed 1.6 MTPA. As the peak
rated capacity of the mine as per the approved mining plan is 5 MTPA, the first
conditionality of provisions of Regulation 3.19 (iii) of the CSERC MYT Regulations,
2021 was met in FY 2020-21. Accordingly, as per the CSERC MYT Regulations,
2021, the COD of the mine is April 1, 2021. The Commission has approved the same
in the MYT Order dated April 13, 2022 in Petition No. 1 of 2022. Thus, FY 2021-22
was first full year of operation of the mine after the achievement of COD.
Commission’s View
The Commission in the MYT Order dated April 13, 2022 in Petition No. 1 of 2022
had observed that the peak rated capacity of GP-III mine, as per the approved mining
plan, is 5 MTPA and the production from the GP-III mine had crossed 1.6 MTPA
during FY 2020-21. Thus, the first conditionality of COD as per Regulation 3.19 (iii)
of the CSERC MYT Regulations, 2021 was met in FY 2020-21. Accordingly, the
Commission had accepted the COD of GP-III mine as April 1, 2021 in the MYT
48

CSERC Tariff Order FY 2023-24

<!-- page 71 -->

Order dated April 13, 2022 in Petition No. 1 of 2022. For this Order also, the
Commission has considered the COD of GP-III mine as April 1, 2021.
3.1.3 Provisions of Regulations
CSPGCL’s Submission:
CSPGCL submitted that Regulation 49.3 of the CSERC MYT Regulations 2021,
which is the enabling provision for true up is as under:
“Provided, if Commercial operation date of any integrated mine occurred
before the notification of these regulations, input price of the coal supplied
from such mine shall also be determined by the Commission as per provisions
of these regulations.”
Accordingly, for preparation of True up Petition for GP-III coal mine for FY 2021-22,
the provisions of Chapter 5 of the CSERC MYT Regulations 2021 have been
followed.
CSPGCL also submitted that the Regulations provide that the excess or short recovery
due to difference between the input price of coal determined under these Regulations
and the input price of coal adopted prior to such determination, shall be a pass through
with interest rate considered for Working Capital Loan. Therefore, in the True up
Petition, the input cost derived on the basis of referred Regulations has been used for
computation of actual fuel cost and ARR of CSPGCL plants (namely ABVTPS and
DSPM TPS) which used the coal from the GP-III coal mine.
Commission’s View
Regulation 49.2 to Regulation 49.5 of the CSERC MYT Regulations, 2021 are
reproduced below:
“49.2. The generating company shall, after the date of commercial operation
of the integrated mine(s) till the input price of coal is determined by the
Commission under these regulations, adopt the notified price of Coal India
Limited commensurate with the grade of the coal from the integrated mine(s)
or the estimated price available in the investment approval, whichever is
lower, as the input price of coal for the generating station:
49.3. Provided, if Commercial operation date of any integrated mine occurred
before the notification of these regulations, input price of the coal supplied
from such mine shall also be determined by the Commission as per provisions
of these regulations.
49.4. Provided further that the difference between the input price of coal
determined under these regulations and the input price of coal so adopted
prior to such determination, for the quantity of coal billed, shall be adjusted in
accordance with Regulation 46.3.
49.5. In case of excess or short recovery of input price under regulations 46.2
of this Regulation, the generating company shall refund the excess amount or
recover the shortfall amount, as the case may be, with simple rate of interest,
equal to the rate equal to the rate as allowed for computation of Interest on
CSERC Tariff Order FY 2023-24

49

<!-- page 72 -->

Working Capital Loan for the said year in installment as may be decided by
the Commission.”
The COD of GP-III mine is on April 01, 2021, which is before the notification of
CSERC MYT Regulations, 2021. As per Regulation 49.3 of the CSERC MYT
Regulations 2021, the input price of coal from GP-III mine shall be determined by the
Commission. The Commission has determined the input price of coal from GP-III
mine for the first time in the MYT Order dated April 13, 2022 in Petition No. 1 of
2022 for the period FY 2022-23 to FY 2024-25. The input price of coal from GP-III
mine has not been determined by the Commission earlier for FY 2021-22. As per the
Commission‟s letter dated January 27, 2020, CSPGCL had provisionally considered
the notified price of Coal India Limited commensurate with the grade of the coal from
GP-III mine as the input price of coal for the CSPGCL plants consuming coal from
GP-III mine. In this Order, the Commission has carried out True up of input price of
coal from GP-III mine along with approval of capital cost of GP-III mine for FY
2021-22. The trued-up input price of coal from GP-III mine for FY 2021-22 has been
considered as the cost of coal for CSPGCL plants consuming coal from GP-III mine
for the purpose of truing up of FY 2021-22.
3.2

Capital Cost
CSPGCL’s submission
CSPGCL submitted that the Commission, in the MYT Order dated April 13, 2022 in
Petition No. 1 of 2022 had approved the capital cost of GP-III mine on provisional
basis, as shown in the Table below:
Table 3-2: Capital Cost for GP-III mines approved by Commission in MYT
Order dated April 13, 2022 in Petition No. 1 of 2022 on provisional basis (Rs.
Crore)

Sr.
No.

50

Particulars

Approved
Cost

Year

A

Statutory Expenses

1

Upfront amount paid to Ministry of Coal

39.94

COD

2

Fixed cost (Consents Cost+ Cost of Geological Report)

30.99

COD

3

Incremental cost of Geological Report

1.96

COD

4

Mining Lease agreement

21.48

COD

5

Compensation for obtaining surface right of Private land

190.14

COD

6

Addl. Compensation for private and forest land due to
land diversion and having Van Adhikar Patta

3.44

7

Afforestation Charges for diversion of forest land.

2.05

COD

8

Reimbursement of GIDC claim for tree felling

1.20

COD

9

Dead rent

0.09

COD

COD

CSERC Tariff Order FY 2023-24

<!-- page 73 -->

Sr.
No.

Particulars

Approved
Cost

Year

B

Other expenses

10

Payment towards Consultancy fee, BG charges to Bank,
Hiring of vehicles, Office rent, deployment of
manpower, Annual watch ward of office & rest house,
and other A & G expenses

9.03

11

Salaries Coal project

4.79

COD

12

FDR Expenses

110.20

COD

Total Expenses Incurred

415.31

Adjustment

-30.92

Net Expenses Incurred

384.39

13

COD

C

Expenses to be incurred

14

Payment of compensation of land for obtaining surface
right of remaining one village Bajarmuda

415.03

15

Payment of compensation of land adjacent to main road
of village Dholnara & Milupara.

5.99

16

Land acquisition of village Bhalumar for R&R of
project affected families of village Bajarmuda.

12.64

17

Rerouting of Spur line (Railway Line) passing through
GP-III coal mine

53.45

18

Drilling of boreholes and preparation of GR for proving
coal reserve in mining lease area and unexplored 59.431
Ha on western part of GPIII coal mine.

25.60

19

Construction of Rest house, office building and other
works

4.39

20

Construction of Approach Road from Gharghoda Chhal Main Road to Ghargoda Railway Siding for
transportation of Coal of GP-III Coal Block.

FY 22-23
FY 22-23
FY 21-22

FY 23-24

2.65

Expenses to be incurred

519.75

Grand Total

904.10

Contingency @5% of IA Cost

22

Notional IDC

111.91

Total Capital Cost

1016.05

De-capitalization on achieving peak rated capacity

-110.20

Net Capital Cost

905.85

CSERC Tariff Order FY 2023-24

FY 21-22

FY 23-24

21

23

COD

0.00

Reserve

FY 24-25

51

<!-- page 74 -->

In the above, Rs. 25.60 Crore appearing at Sr. No. 18 towards drilling of boreholes
and preparation of GR for proving coal reserve in mining lease area and unexplored
59.431 Hectare on western part of GP-III coal mine was not considered as a part of
the capital cost for GP-III mine, as these expenses relate to unexplored area. Hence
the approved capital cost for the project stands at Rs. 880.25 Crore along with
contingency reserve of 5% (about Rs. 44 Crore). Against the above capital cost
considered in the MYT Order dated April 13, 2022 in Petition No. 1 of 2022, the
actual capital cost as per Audited Accounts for FY 2021-22, certified by the Statutory
Auditors is as under:
Table 3-3: Actual Capital Cost for GP-III mines based on Audited Accounts of
FY 2021-22 vis-a-vis Approved Capital Cost in MYT Order dated April 13, 2022,
as submitted by CSPGCL (Rs. Crore)
Sr.
No.
1
2
3
4
5
6
7
8
9
10

11
12
13
14

15
16
17
18
19
52

Particulars
Upfront amount paid to Ministry of Coal
Fixed cost (Consents Cost+ Cost of Geological
Report)
Incremental cost of Geological Report
Mining Lease agreement
Compensation for obtaining surface right of Private
land
Addl. Compensation for private and forest land due to
land diversion and having Van Adhikar Patta
Afforestation Charges for diversion of forest land.
Reimbursement of GIDC claim for tree felling
Dead rent
IEDC including consultancy fee, BG charges to
Bank, hiring of vehicles, office rent, deployment of
manpower, watch &ward and other such expenses.
Salaries Coal project (1.27 Cr in FY 16-17 & 3.52 Cr
in FY 17-18)
FDR Expenses
Adjustment
IDC
Net GFA on COD
Expenses Incurred in FY 21-22
Payment of compensation of land for obtaining
surface right of remaining one village Bajarmuda
Balance for Van Adhikar Patta (SN 6 above)
Rerouting of Spur line (Railway Line) passing
through GP-III coal mine
One Time Settlement payment to PAPs in lieu of
employment
Prior Period Salary Capitalisation

Approved

Actual

39.94

39.94

30.99

31.00

1.96
21.48

1.96
21.48

190.14

190.14

3.44

3.02

2.05
1.20
0.09

2.05
1.20
0.09

9.03

20.30

4.79

4.79

110.20
-30.92
111.91
496.30

110.20
-38.97
111.21
498.43

415.03

387.28

0

0.41

53.45

0

0
0

5.78
5.56

CSERC Tariff Order FY 2023-24

<!-- page 75 -->

Sr.
No.
20
21

Particulars
Construction of Approach Road from Gharghoda Chhal Main Road to Ghargoda Railway Siding
Other Miscellaneous / Contingent expenses
Sub-Total for FY 21-22
Closing GFA for FY 21-22

Approved

Actual
0

1.33

0
468.48
964.78

0.45
400.80
899.24

CSPGCL further submitted that:
a. The Incidental expenditure during construction (IEDC) expenses include Salary
expense capitalized on COD in Gare Palma accounts for FY 2019-20 (Rs. 2.39
Crore) and FY 2020-21 (Rs. 5.06 Crore) and capitalization of R&M expenses and
A&G expenses of Rs. 2.25 Crore capitalized on COD.
b. Though the accounts reflect the total payment of one Time Settlement payment to
Project Affected Persons (PAPs) as Rs. 11.75 Crore, only 50% of the amount has
been considered here.
c. The construction of kuchha approach road from Gharghoda - Chhal Main Road to
Ghargoda Railway Siding was a work undertaken due to urgency and may be
considered as part of Contingency work.
d. As on COD, the total CWIP was about Rs. 0.73 Crore.
In response to queries raised during TVS, vide additional submission dated February
3, 2023 CSPGCL revised the Adjustment figure of Rs. 38.97 Crore to Rs 41.98 Crore.
After prudence check, For the purpose of this Order, Commission has relied on the
same. CSPGCL submitted that as on COD, there is marginal (less than 0.5%) increase
in the estimated cost and the closing GFA for FY 2021-22 is lower than the estimate.
The total contingency expenses are also lower than the approved ceiling of 5% of
capital cost. Also, there is slight reduction in the IDC being submitted now compared
to the IDC submitted earlier due to minor adjustment of actual quarter-wise expenses.
CSPGCL submitted that during FY 2021-22, CSPGCL has tied up and drawn actual
loan, however, the actual loan drawal is lower than 70% of the capital cost. Thus, the
equity deployed is more than the normative ceiling of 30% of capital cost. Hence,
CSPGCL has considered the normative debt equity ratio of 70:30 for FY 2021-22.
CSPGCL further submitted that a large part of project expenses pertains to
compensation for land. The land acquisition has been made and compensation has
been paid in accordance with the Orders of the revenue authorities. In this regard, the
Government of Chhattisgarh, Energy Department vide letter no. 2647/ R124/2019/13/2 dated 18.11.2019 had directed CSPGCL to obtain approval of this
Commission for the compensation to be paid for land before making payment.
CSPGCL had approached the Commission vide letter no. 03-09/Reg-2/49 dated
20/10/2020 to grant in-principle approval for the compensation to be paid towards
land. In response, the Commission vide letter no. 13-GH30/ 2020/186 dated
27.01.2020 replied that the matter of approval of rate of compensation to be paid to
the land owners does not come under the jurisdiction of the Commission. The relevant
extract is reproduced below:
CSERC Tariff Order FY 2023-24

53

<!-- page 76 -->

“……The said provisions do not contain any reference to approval of the rate
of compensation to be paid for land acquisition by the generating company.
Thus, the matter of approval of the rate of compensation to the landowners for
operating/ commissioning the coal mines sanctioned in Gare Palma- 3 does
not come under the purview of Section 86 of the Electricity Act, 2003”
………………………………..
“…… In the light of the aforesaid, the Commission is of the view that the
matter does not require approval of the Commission.” (Emphasis added)
Accordingly, the compensation for land has been paid as per the Government
directive. CSPGCL requested the Commission to accept the same as uncontrollable
expense for CSPGCL.
CSPGCL submitted that the Commission vide its letter no. 13-GH30/ 2020/186 dated
27.01.2020, had provisionally permitted CSPGCL to continue to adopt the notified
price of Coal India Limited commensurate with the grade of coal from integrated
mines. Accordingly, CSPGCL had adopted the South Eastern Coalfields Ltd. (SECL)
rates till COD of the mine. While ascertaining the capital cost of the mine, it is
necessary to set off or adjust the revenue earned over and above the expenses incurred
for coal production before COD of a mine. This treatment is similar to setting off of
revenue earned due to sale of infirm power from capital cost of a power plant before
COD. Accordingly, CSPGCL considered the quantity already submitted to this
Commission through FCA, which is RR (Railway receipt) quantity. During the
previous submission of capital cost in Petition No. 1 of 2022, for provisional working
of the adjustment value, a normative transit loss segregated in 50:50 ratio between the
rail and road transport was considered. The statutory charges payable prior to COD
were also computed on the basis of RR quantity grossed up by transit loss of 0.4% in
road transport. However, CSPGCL in Petition No. 1 of 2022 had submitted that these
charges are subject to change once the final reconciliation of quantity supplied from
GP-III mine to ABVTPP, Marwa is completed. At present, as the transit passes data
have been compiled and as after FY 2020-21, the plant end transit loss data has
attained finality, in this Petition for true up of FY 2021-22, the final adjustment
computation has been submitted.
CSPGCL submitted that save for some uncontrollable reason (including but not
limited to some legal/ statutory development), the capital cost on COD need not be
revised again. The other costs incurred during the period are also known, hence,
CSPGCL has considered the actual values for true up of FY 2021-22. The statutory
charges have been computed on the basis of actual grade-wise quantity dispatched (as
recorded in the transit passes). The adjustment value, which was earlier estimated as
Rs. 30.92 Crore, has been revised to Rs. 38.97 Crore based on actual data.
Accordingly, in line with regulatory principles, CSPGCL has reduced this amount
from the capital cost incurred on COD and the input price of coal has been worked out
considering the reduced capital cost. CSPGCL submitted that the set off considered
for determination of input price of coal is for regulatory purpose only, which is
different from accounting principles. The accounting principles follow the concept of
moving averages (which involves loading of stock cost) and regulatory approach
relies on replacement cost philosophy. It is for this reason that since the start of plantwise two-part tariff regime, there has always been a difference between the cost of
coal in the financial accounts and the regulatory accounts. In this case too, the
54

CSERC Tariff Order FY 2023-24

<!-- page 77 -->

adjustment in accounts include stock valuation. However, for regulatory purpose, as
cost of coal is recovered only when electricity is supplied, historically, stock valuation
finds no place in the Commission‟s Orders. Accordingly, CSPGCL has relied on the
principle approved in the previous Orders of the Commission.
CSPGCL further submitted that at this juncture, there exist some unsettled contingent
contractual / legal issues, which may have commercial implications. Some such
disputes are already before arbitration and some others are at discussion stage. Details
of such issues were submitted during the proceedings on Petition No. 01 of 2022 and
the Commission had taken cognizance of such issues in the MYT Order dated April
13, 2022. Though such issues may not have an impact on true up of FY 2021-22,
CSPGCL submitted brief updates on such issues, as under.
a.

Claim before the Tribunal by the previous coal mine allottee, i.e., M/s Goa
Industrial Development Corporation (GIDC): M/s GIDC has lodged a claim of
Rs. 232.06 Crore before the Hon‟ble Tribunal at Bilaspur (CG) constituted under
the Coal Bearing Act. No further development has taken place. CSPGCL
submitted that in case any cost is borne by CSPGCL in future, the same will be
submitted.

b. Payment against demand received from Chhattisgarh Environment Control Board
(CECB), citing conditions of environment clearance: The matter is before
arbitration to adjudge the issue regarding the liability of CSPGCL vis-a-vis the
MDO.
c.

Payment against 600 metre Coal Transport Road constructed by M/s. Gare Palma
Collieries Limited and proposal of another 950 metre road: The matter is before
the Joint Committee for amicable settlement.

d. Railway Siding expenses at Mine end: On the basis of Feasibility Survey Report
(FSR) prepared by M/s RITES in December 2017, the cost of the Railway Siding
was estimated to be Rs. 60 Crore. However, now M/s IRCON (A Government of
India Undertaking) has been appointed for the said work and a MOU has been
entered between the Parties for the same. The revised cost estimate will be known
after receipt of DPR. However as per MOU, till such time the estimate for the
Railway siding is being considered as Rs. 75 Crore (excluding value of land,
taxes and duties).
e.

Arbitration cases with the MDO: Such arbitrations relate to unloading charges at
plant end, liability for one-time settlement of Project Affected Persons (about
1090 persons), settlement of environment clearance issues, etc. The cases are yet
to be decided and the principal amount involved is now estimated to be over Rs.
100 Crore.

CSPGCL submitted that as directed by the Commission in the MYT Order dated
April 13, 2022, no claim against the above cited issues have been included in this
Petition. CSPGCL shall claim these expenses when they are actually incurred.
CSPGCL also submitted that earlier it was planned that employment will be provided
by MDO to the Project Affected Persons (PAPs). Further, rehabilitation for the
Project Affected Families (PAFs) was planned at the Village Bhalumar. Accordingly,
an estimate of about Rs. 12.64 Core was considered in the original cost estimate
approved in the MYT Order dated April 13, 2022 (Sr. No. 16 of the Table related to
approved cost break up). However, now number of PAPs are opting for one-time
CSERC Tariff Order FY 2023-24

55

<!-- page 78 -->

settlement of compensation of Rs. 5 Lakh. Similarly, PAFs are opting for one-time
settlement. Vide letter no. 5350/LA/2022 dated 16.06.2022, the Collector of Raigarh
district has communicated that villagers of Bajarmuda and Dholnara are not willing to
get displaced to R&R village Bhalumar and for amicable settlement, the Collector of
Raigarh district has suggested one-time payment of Rs 9,55,000/- per PAF. At
present, in the interest of keeping the mine operational, CSPGCL and MDO have
agreed to pay costs in the 50:50 ratio. Accordingly, first tranche payment of Rs. 11.55
Crore has already been deposited to revenue authorities. The district authorities have
been requested to certify the number of PAFs and PAPs. CSPGCL submitted that in
view of Government Policy, decisions of the revenue authorities, and outcome of
arbitration decisions, the project cost may escalate substantially. However, except the
50% share of Rs. 11.55 Crore already paid, CSPGCL has not included any other cost
in the true up petition.
Commission’s View
As regards the Capital Cost for integrated mine, Regulation 55 of the CSERC MYT
Regulations, 2021 specifies as under:
“55. Capital Cost:
55.1. The expenditure incurred, including IDC and IEDC, duly certified by the
Chartered Accountant, for development of the integrated mine(s) up to the
date of commercial operation, shall be considered for arriving at the capital
cost.
55.2. Capital expenditure incurred shall be admitted by the Commission after
prudence check.
55.3. Capital expenditure incurred on infrastructure for crushing,
transportation, handling, washing and other mining activities required for
mining operations shall be arrived at separately in accordance with these
regulations:
Provided that where crushing, transportation, handling or washing are
undertaken by the generating company, the expenditure incurred on
infrastructures of these components shall be capitalized;
Provided further that where mine development and operation, with or without
any component of crushing, transportation, handling or washing are
undertaken by the generating company by engaging Mine Developer and
Operator or an agency other than Mine Developer and Operator, the capital
expenditure incurred by Mine Developer and Operator or such agency shall
not be capitalised by the generating company and shall not be considered for
the determination of input price.
55.4. The capital expenditure shall be determined by considering, but not
limited to, the Mining Plan, detailed project report, mine closure plan, cost
audit report and such other details as deemed fit by the Commission.
55.5. In case of integrated mine(s) which have declared the date of
commercial operation prior to 1.4.2022, the capital expenditure allowed by
the Commission for the period ending 31.3.2022 as per provisions of these
regulations shall form the basis for computation of input price.”
56

CSERC Tariff Order FY 2023-24

<!-- page 79 -->

In view of the above Regulations, the Commission has undertaken the true up of the
Capital Cost for GP-III coal mine as discussed below.
As per Regulation 55.1, the expenditure incurred including IDC and IEDC, duly
certified by the Chartered Accountant, for development of the integrated mine(s) up to
the date of commercial operation, shall be considered for arriving at the capital cost.
Therefore, the Commission has considered the expenditure incurred, including IEDC,
duly certified by the Chartered Accountant, for development of the integrated mine(s)
up to the COD for GP-III mine for approval purpose. As the IDC is computed in
accordance with Regulatory principles, hence, for the purpose of IDC, Commission
has adopted the methodology settled in the previous order.
The Commission had considered the capital cost of GP-III mine as on April 01, 2021
(COD) on provisional basis in the MYT Order dated April 13, 2022 in Petition No. 1
of 2022. Except for IEDC, IDC and regulatory adjustment, values of all other items
claimed by CSPGCL are at the same level as approved provisionally in the MYT
Order dated April 13, 2022. Therefore, the Commission has accepted the actual
expenses incurred as on March 31, 2021 pertaining to upfront payment paid to
Ministry of Coal, fixed cost (consents cost and cost of geological report), incremental
cost of geological report, mining lease agreement, compensation for obtaining surface
right of private land, afforestation charges for diversion of forest land, reimbursement
of GIDC claim for tree felling, dead rent, salaries of coal project, and FDR expenses.
CSPGCL has submitted some variation in the capital cost as on COD, as discussed
below:
Incidental Expenses During Construction (IEDC)
The Commission had considered IEDC of Rs. 9.03 Crore in the capital cost approved
provisionally in the MYT Order dated April 13, 2022. For True up of FY 2021-22,
CSPGCL has claimed IEDC of Rs. 20.30 Crore. In support of the capital cost with
IEDC, CSPGCL has submitted a Chartered Accountant (CA) certificate, wherein the
IEDC mentioned was Rs. 20.99 Crore. CSPGCL submitted that the CA certificate
pertains to the capex incurred for the project and the reconciliation of IEDC as under:
Table 3-4: IEDC expenses as on CoD (Rs. Crore)
Sr.
No.
1
2
3
4

Particulars
IEDC as per CA Certificate
Less: CWIP as on 01.04.2021
Add: Furniture and Office equipment
IEDC claimed in True up Petition

Amount
20.99
(0.73)
0.05
20.30

*The minor difference of Rs. 0.01 Crore is due to rounding off of values
Considering the above reconciliation, the Commission allows the IEDC of Rs. 20.30
Crore as part of capital cost as on COD.
Adjustment of additional revenue
During the period before COD, the Commission had permitted CSPGCL to
provisionally continue to adopt the notified price of Coal India Ltd. CSPGCL has
adjusted the additional revenue of Rs. 38.97 Crore earned over and above the actual
CSERC Tariff Order FY 2023-24

57

<!-- page 80 -->

expenses towards coal production from the Capital Cost in a manner similar to that of
infirm power.
Subsequently, CSPGCL in its additional submission submitted that inadvertently in
the computation of gain from transfer of coal before COD, the GST on FRV, which
was claimed @ 18% was already claimed during the true-up of FY 2020-21 as it was
paid from the Central Accounting Unit. Therefore, the additional revenue claim was
revised to Rs. 41.98 Crore.
Accordingly, the Commission has adjusted the additional revenue of Rs. 41.98 Crore
from the Capital Cost under the head of adjustment.
Interest During Construction (IDC)
The Commission had considered IDC of Rs. 111.91 Crore in the capital cost approved
provisionally in the MYT Order dated April 13, 2022. For True up of FY 2021-22, the
IDC has been revised due to minor adjustment in actual quarter-wise expenses.
However, CSPGCL had claimed IDC in accordance with Hon‟ble ATE Judgment in
Appeal No 231 of 2017 dated October 3, 2019, wherein the Hon‟ble ATE had ruled
that in absence of actual loan, the developer is entitled to normative IDC. In
accordance with the ATE Judgment, the Commission had considered IDC as part of
capital cost approved provisionally in the MYT Order dated April 13, 2022. The
Commission asked CSPGCL about the interest rates considered for calculation of
IDC. CSPGCL submitted that the expense on GP-III mine started from FY 2015-16.
CSPGCL has used the trued up weighted average interest rates of CSPGCL from FY
2015-16 to FY 2020-21, as per the Truing up Orders to determine IDC. The
computation has been shared by CSPGCL as part of financial model and is found to
be in order. Accordingly, the Commission allows the revised IDC as part of capital
cost as on COD.
Capitalisation in FY 2021-22
Regulation 56.1 of the CSERC MYT Regulations, 2021 specifies the conditions
whereby the expenditure incurred shall be considered as Additional Capital
Expenditure, as reproduced below:
“56.1 The expenditure, in respect of the integrated mine(s), incurred or
projected to be incurred after the date of commercial operation and up to the
date of achieving the Peak Rated Capacity may be admitted by the
Commission, subject to prudence check and shall be capitalized in the
respective year of the tariff period as additional capital expenditure
corresponding to the Annual Target Quantity of the year as specified in the
Mining Plan or actual extraction in that year, whichever is higher, on
following counts:
(a) expenditure incurred on activities as per the Mining Plan;
(b) expenditure for works deferred for execution and un-discharged
liabilities recognized for works executed prior to date of commercial
operation;
(c) expenditure for works required to be carried out for complying
with directions or orders of any statutory authorities;
(d) liabilities arising out of compliance of order or decree of any court
of law or award of arbitration;
58

CSERC Tariff Order FY 2023-24
