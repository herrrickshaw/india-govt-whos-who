---
doc_id: "7f78a8bc0cbe81fe"
source_url: "https://www.sldccg.com/wif-for-website/sldccg_act_regulations/33-secondamendmentuiamendments2012.pdf"
ministry: "State Load Despatch Centre (SLDC), Chhattisgarh"
title: ""
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9ec2d50765da0318"
---

<!-- page 1 -->

CENTRAL ELECTRICITY REGULATORY COMMISSION
NEW DELHI
No.L-1(1)/2011-CERC

New Delhi, the 5th March, 2012
NOTIFICATION

In exercise of the powers conferred under Section 178 read
with Section 79 (1) (c) of the Electricity Act, 2003 (36 of 2003), and
all other powers enabling it in this behalf, and after previous
publication, the Central Electricity Regulatory Commission hereby
makes the following regulations to amend the Central Electricity
Regulatory Commission (Unscheduled Interchange charges and
related matters) Regulations, 2009 (hereinafter referred to as “the
Principal Regulations”), namely.1.

Short title and commencement.-

(1)

These regulations may be called the Central Electricity
Regulatory Commission (Unscheduled Interchange charges
and related matters) (Second Amendment) Regulations,
2012.

(2)

These regulations shall come into force with effect from 2nd of
April, 2012.

2.

Amendment of Regulation 5 of the Principal Regulations.-

Regulation 5 of the principal Regulations shall be substituted as
under, namely.-

1

<!-- page 2 -->

“5.

Unscheduled Interchange (UI) Charges:

(1) The charges for the Unscheduled Interchanges for all the
time-blocks shall be payable for over drawal by the buyer or the
beneficiary and under-injection by the generating station or the
seller and receivable for under-drawal by the buyer or the
beneficiary and over-injection by the generating station or the
seller and shall be worked out on the average frequency of a
time-block at the rates specified in the Schedule 'A' of these
regulations as per the methodology specified in clause (2) of this
regulation:
Provided that the charges for the Unscheduled Interchange
for the generating stations using coal or lignite or gas supplied
under Administered Price Mechanism (APM) as the fuel, when
actual generation is higher or lower than the scheduled
generation, shall not exceed the Cap Rate as specified in the
Schedule 'A' of these regulations as per the methodology specified
in clause (3) of this regulation:
Provided further that the Charges for the Unscheduled
Interchange for the injection by a generating station other than
the hydro generating station in excess of 105% of the Declared
Capacity of the station in a time block or in excess of 101% of the
average Declared Capacity over a day shall not exceed the Cap
Rate as specified in the Schedule 'A' of these regulations:
Provided also that the charges for the Unscheduled
Interchange for the underdrawls by the buyer or the beneficiaries
in a time block in excess of 10% of the schedule or 250 MW
whichever is less, shall not exceed the Cap Rate as specified in the
Schedule 'A' of these regulations as per the methodology specified
2

<!-- page 3 -->

in clause (4) of this regulation:
Provided also that the charges for the Unscheduled
Interchange for the injection by the seller in excess of 120% of the
schedule subject to a limit of ex-bus generation corresponding to
105% of the Installed Capacity of the station in a time block or
101% of the Installed Capacity over a day shall not exceed the
Cap Rate as specified in the Schedule 'A' of these regulations as
per the methodology specified in clause (5) of this regulation:
Provided also that the Charges for the Unscheduled
Interchange for the injection by the seller in excess of ex-bus
generation corresponding to 105% of the Installed Capacity of the
station in a time block or 101% of the Installed Capacity over a day
shall not exceed the Cap Rate as specified in the Schedule A of
these regulations.
(2) The Charge for Unscheduled Interchange shall be determined
in accordance with the following methodology:

(a) The Charge for Unscheduled Interchange shall be zero at grid
frequency of 50.2 Hz and above.
(b) The Charge for Unscheduled Interchange corresponding to grid
frequency interval of ‘below 50.02 Hz and not below 50.0 Hz’
shall be based on the median value of the average energy
charge of coal/lignite based generating stations for the six
months period of August 2010 to January 2011 and suitably
adjusted upward to decide on the UI price vector.
(c) The UI Price Vector shall accordingly, be in steps for a
3

<!-- page 4 -->

frequency interval of 0.02 Hz between 50.2 Hz and ‘below 50.02
Hz and not below 50.0 Hz’.
(d) The Charge for Unscheduled Interchange in grid frequency
interval of ‘below 49.82 Hz and not below 49.80 Hz’shall be such
that it provides sufficient incentive to the generating station
based on coal including imported coal to support the grid after
meeting fixed and energy charge.
(e) The UI Price Vector shall accordingly, be in steps for a frequency
interval of 0.02 Hz between grid frequency interval of ‘below
50.02 Hz and not below 50.0 Hz’ and ‘below 49.82 Hz and not
below 49.80 Hz’.
(f) The Charge for Unscheduled Interchange at grid frequency
"below 49.50 Hz" shall be based on the highest of the average
energy charges of generating stations for the six months period
of August 2010 to January 2011 and suitably adjusted upward to
decide on the UI price vector.
(g) The UI Price Vector shall accordingly, be in steps for a frequency
interval of 0.02 Hz between grid frequency interval of ‘below
49.82 Hz and not below 49.80 Hz’ and ‘below 49.5 Hz’.
(h) The UI Price Vector shall be in steps for a frequency interval of
0.02 Hz between 50.2 Hz to 49.70 Hz corresponding to the
Charge for Unscheduled Interchange in grid frequency intervals
of ‘not below 50.2 Hz’, ‘below 50.02 Hz and not below 50.0 Hz’,
‘below 49.82 Hz and not below 49.80 Hz’ and “below 49.50 Hz”.
(3) The Cap rate for the charges for the Unscheduled
Interchange for the generating stations using coal or lignite or gas
4

<!-- page 5 -->

supplied under Administered Price Mechanism (APM) as the fuel
shall be as specified in Schedule “A” of these Regulations.

(4) The Cap Rate for the Unscheduled Interchange for the under
drawls by the buyer or the beneficiaries in excess of 10% of the
schedule or 250 MW, whichever is less, shall be the same as the
charges for the Unscheduled Interchange corresponding to grid
frequency interval of ‘below 49.82 Hz and not below 49.80 Hz’ as
specified in Schedule “A” of these Regulations.
(5) The Cap Rate for the Unscheduled Interchange for the
injection by the seller in excess of 120% of the schedule subject to
a limit of ex-bus generation corresponding to 105% of the Installed
Capacity of the station in a time block or 101% of the Installed
Capacity over a day shall be the same as the charges for the
Unscheduled Interchange corresponding to grid frequency
interval of ‘below 49.82 Hz and not below 49.80 Hz’ as specified in
Schedule “A” of these Regulations.
(6) The Charge for Unscheduled Interchange may be reviewed
and re-notified every six months by the Commission and Schedule
“A” of these regulations shall be re-notified accordingly.
(7)

The infirm power injected into the grid by a generating unit of

a generating station during the testing, prior to COD of the unit
shall be paid at UI rates for power injected into the grid,
consequent to testing, for a period not exceeding 6 months or the
extended time allowed by the Commission in the Central
Electricity

Regulatory

Commission

(Grant

of

Connectivity,

Long-term Access and Medium-term Open Access and related
matters) Regulations, 2009, as amended from time to time,
subject to ceiling of Cap rates corresponding to the main fuel
used for such generation as specified in the Schedule “A” of this
5

<!-- page 6 -->

Regulation.

(8) Charges for Inter-regional UI Exchanges between the two
asynchronous Regions shall be computed by the respective
Regional Power Committees, based on UI rates as per the
frequency of the respective Region. The amount to be settled for
the inter-regional exchanges shall be average of the UI charges
computed for the two regions by way of such inter-change. "
3.

Amendment of Regulation 7 of the Principal Regulations.-

Regulation 7 of the Principal Regulations shall be substituted as
under, namely.“7.

Limits on UI volume and consequences of crossing the

limits.(1) The over-drawal of electricity by any beneficiary or a buyer
during a time block shall not exceed 12% of its scheduled drawal
or 150 MW, whichever is lower, when frequency is ‘below 49.80’ Hz
and 3% on a daily aggregate basis for all the time blocks when the
frequency is ‘below 49.80 Hz’.
Explanation: The limits specified in this clause shall apply to the sum
total of over-drawal by all the intra-State entities in the State
including the distribution companies and other intra-State buyers,
and shall be applicable at the inter-State boundary of the
respective State.
(2)

The under-injection of electricity by a generating station or a

seller during a time-block shall not exceed 12% of the scheduled
injection of such generating station or seller when frequency is
‘below 49.80 Hz’ and 3% on daily aggregate basis for all the time
6

<!-- page 7 -->

blocks when the frequency is ‘below 49.80 Hz’.
(3)

In addition to Unscheduled Interchange Charges as

stipulated under Regulation 5 of these regulations, Additional
Unscheduled Interchange

Charge

shall

be

applicable

for

over-drawal or under-injection of electricity for each time block
when grid frequency is ‘below 49.7 Hz’ at the rates specified in the
schedule A of these regulations in accordance with the
methodology specified in clause (3a) of this regulation:
Provided further that Additional Unscheduled Interchange
Charge for under-injection of electricity, during the time-block
when grid frequency is ‘below 49.7 Hz’, by the generating stations
using coal or lignite or gas supplied under Administered Price
Mechanism (APM) as the fuel shall be at the rates specified in the
schedule A of these regulations in accordance with the
methodology specified in clause (3b) of this regulation.
Explanation: Additional Unscheduled Interchange Charges shall
not be applicable for net over drawls by a region as a whole from
other regions when grid frequency is ‘below 49.7 Hz’.
(4)

The

additional

Unscheduled

Interchange

charge

for

over-drawals and under-injection of electricity for each time block
when grid frequency is below 49.7 Hz shall be as specified by the
Commission as a percentage of the charges for the Unscheduled
Interchange in grid frequency ‘below 49.5 Hz’ with due
consideration to the behavior of the buyer and beneficiaries and
sellers and the generating stations towards grid discipline:
Provided that the Commission may specify different rates for
additional Unscheduled Interchange charges for over drawls and
7

<!-- page 8 -->

under injections and for different ranges of frequencies ‘below
49.7 Hz’.
(5)

The

additional

Unscheduled

Interchange

charge

for

under-injection of electricity during the time-block when grid
frequency is ‘below 49.7 Hz’, by the generating stations using coal
or lignite or gas supplied under Administered Price Mechanism
(APM) as the fuel shall be as specified by the Commission as a
percentage of the Cap Rate, with due consideration to the
behavior of the generating stations towards grid discipline:
Provided that the Commission may specify different rates for
additional Unscheduled Interchange charges for under injections
at different ranges of frequencies ‘below 49.7 Hz’.

(6)

Payment

of

Unscheduled

Interchange

Charges

under

Regulation 5 and the Additional Unscheduled Interchange
Charge under Regulation 7(3) above, shall be levied without
prejudice to any action that may be considered appropriate by
the Commission under Section 142 of the Act for contravention of
the limits of over-drawal or under-generation as specified in these
regulations, for each time block when frequency is ‘below 49.80
Hz’.
(7)

The Commission may, if considered necessary, prescribe

from time to time Additional Unscheduled Interchange Charge for
over-drawal

or

under-injection

of

electricity

during

each

time-block when grid frequency is ‘below 49.80 Hz’ and up to 49.7
Hz.
(8)

The charges for over-drawal/under-injection and under8

<!-- page 9 -->

drawal/over-injection of electricity shall be computed by the
respective Regional Power Committee in accordance with the
methodology used for preparation of ‘Regional Energy Accounts’.
(9)

The Regional Load Despatch Centre shall prepare and

publish on its website the records, on monthly basis, of the UI
Accounts,

specifying

the

quantum

of

over-drawal/

under-generation and corresponding amount of UI charges paid
for each beneficiary or buyer and received for each generating
station or seller for the time-blocks when grid frequency was below
49.7 Hz and between 49.80-49.7 Hz separately.”

Sd/(Rajiv Bansal)
Secretary
Note: The Principal Regulations were published in the Gazette of India
Extraordinary Part III Section 4 at Ser No.43 on 3rd March 2009 and the first
amendment to the Principal Regulations were published in the Gazette of
India Extraordinary Part III Section 4 at Ser No. 114 on 28th April 2010.

9

<!-- page 10 -->

SCHEDULE “A”
1.

Unscheduled Interchange (UI) Charges:
In terms of clause (1) of Regulation 5, the charges for

Unscheduled Interchanges for all the time-blocks payable for
over-drawal by the buyer or the beneficiary and under-injection
by the generating station or the seller and receivable for
under-drawal by the buyer or the beneficiary and over-injection
by the generating station or the seller shall be worked out on the
average frequency of the time-block at the rates given
hereunder:Average Frequency of the time
block(Hz)
Below
50.20
50.18
50.16
50.14
50.12
50.10
50.08
50.06
50.04
50.02
50.00
49.98
49.96
49.94
49.92
49.90
49.88
49.86
49.84
49.82
49.80
49.78

Not Below
50.20
50.18
50.16
50.14
50.12
50.10
50.08
50.06
50.04
50.02
50.00
49.98
49.96
49.94
49.92
49.90
49.88
49.86
49.84
49.82
49.80
49.78
49.76
10

UI Rate
(Paise per kWh)
0.00
16.50
33.00
49.50
66.00
82.50
99.00
115.50
132.00
148.50
165.00
193.50
222.00
250.50
279.00
307.50
336.00
364.50
393.00
421.50
450.00
478.13
506.25

<!-- page 11 -->

49.76
49.74
49.72
49.70
49.68
49.66
49.64
49.62
49.60
49.58
49.56
49.54
49.52
49.50

49.74
49.72
49.70
49.68
49.66
49.64
49.62
49.60
49.58
49.56
49.54
49.52
49.50

534.38
562.50
590.63
618.75
646.88
675.00
703.13
731.25
759.38
787.50
815.63
843.75
871.88
900.00

(Each 0.02 Hz step is equivalent to 16.50
Paise/kWh in the 50.2-50.00 Hz frequency range,
28.50 Paise/kWh in 50 Hz to 49.8 Hz and 28.12
Paise/kwh in frequency in the below 49.8 Hz to
49.5 Hz range.)

11

<!-- page 12 -->

2.

Unscheduled Interchange Cap Rates

(a)

In terms of clauses (1) and (3) of Regulations 5, the UI Cap Rate

shall be 421.50 Paise/kWh for all generating stations using coal or
lignite or gas supplied under Administered Price Mechanism (APM) as
the fuel, in case when actual generation is higher or lower than the
scheduled generation.
(b)

In terms of clauses (1) and (6) of Regulations 5, the UI Cap Rate

shall be 450.00 Paise/kWh for the under drawls by the buyer or the
beneficiaries in excess of 10% of the schedule or 250 MW whichever is
less.
(c)

In terms of clauses (1) and (7) of Regulations 5, the UI Cap Rate

shall be 450.00 Paise/kWh for the injection by the seller in excess of
120% of the schedule subject to a limit of ex-bus generation
corresponding to 105% of the Installed Capacity of the station in a
time block and 101% of the Installed Capacity over a day.
(d)

In terms of clauses (1) of Regulation 5, the UI Cap Rate shall be

165.00 Paise/kWh for the injection by a generating station other than
the hydro generating station in excess of 105% of the Declared
Capacity of the station in a time block or in excess of 101% of the
average Declared Capacity over a day.
(e)

In terms of clauses (1) of Regulation 5, the UI Cap Rate shall be

165.00 Paise/kWh for the injection by the seller in excess of ex-bus
generation corresponding to 105% of the Installed Capacity of the
station in a time block or 101% of the Installed Capacity over a day
shall not exceed the Cap Rate as specified in the Schedule 'A' of
these regulations.
(f)

In terms of clauses (7) of Regulation 5, the cap rates for the

infirm power injected into the grid by a unit of a generating station
12

<!-- page 13 -->

during the testing/commissioning prior to COD of unit shall be as
follows corresponding to the fuel used for the generation:

3.

Domestic coal/ Lignite/Hydro
(` / kWh sent out)

:

1.65

APM gas as fuel
(`/ kWh sent out)

:

2.60

Imported Coal/RLNG
(`/ kWh sent out)

:

3.30

Liquid Fuel
(` / kWh sent out)

:

9.00

Additional Unscheduled Interchange Charges

(a) In terms of clause (4) of Regulation 7 , the Additional Unscheduled
Interchange

Charge

for

over-drawal

of

electricity

for

each

time-block when grid frequency is "below 49.7 Hz" and up to "Not
below 49.5 Hz" shall be equivalent to 20% of the Unscheduled
Interchange Charge corresponding to grid frequency of "below 49.5
Hz".

The

Additional

Unscheduled

Interchange

Charge

for

under-injection of electricity for each time-block when grid
frequency is "below 49.7 Hz" and up to "Not below 49.5 Hz" shall be
equivalent to 20% of the Unscheduled Interchange Charge of the
corresponding grid frequency of "below 49.5 Hz":

Provided that the Additional Unscheduled Interchange Charge for
over-drawal of electricity for each time-block when grid frequency is
below 49.5 Hz and up to 49.2 Hz shall be equivalent to 40% of the
Unscheduled Interchange Charge 900.0 Paise/kWh corresponding to
13

<!-- page 14 -->

the grid frequency of below 49.5 Hz. The Additional Unscheduled
Interchange Charge for under-injection of electricity for each
time-block when grid frequency is below 49.5 Hz and up to 49.2 Hz
shall be equivalent to 40% of the Unscheduled Interchange Charge
of 900.0 Paise/kWh corresponding to the grid frequency of below 49.5
Hz:
Provided that the Additional Unscheduled Interchange Charge for
over-drawal of electricity for each time-block when grid frequency is
below 49.2 Hz shall be equivalent to 100% of the Unscheduled
Interchange Charge 900.0 Paise/kWh corresponding to the grid
frequency

of

below

49.5

Hz.

The

Additional

Unscheduled

Interchange Charge for under-injection of electricity for each
time-block when grid frequency is below 49.2 Hz shall be equivalent
to 100% of the Unscheduled Interchange Charge of 900.0 Paise/kWh
corresponding to the grid frequency of below 49.5 Hz.
(b) In terms of clause (4) of Regulation 7, the Additional Unscheduled
Interchange Charge for under-injection of electricity during the
time-block when grid frequency is below 49.7 Hz and up to 49.5 Hz for
the generating stations using coal or lignite or gas supplied under
Administered Price Mechanism (APM) as the fuel shall be equivalent
to 20% of the UI Cap Rate of 421.50 Paise/kWh:
Provided that the Additional Unscheduled Interchange Charge
for under-injection of electricity during the time-block when grid
frequency is below 49.5 Hz for the generating stations using coal or
lignite or gas supplied under Administered Price Mechanism (APM) as
the fuel shall be equivalent to 40% of the UI Cap Rate of 421.50
Paise/kWh.

14
