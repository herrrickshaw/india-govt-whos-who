---
doc_id: "fbec7f5f74f8fc4d"
source_url: "https://www.sldccg.com/wif-for-website/sldccg_act_regulations/22-electricityact2003secondamendment.pdf"
ministry: "State Load Despatch Centre (SLDC), Chhattisgarh"
title: ""
date: ""
pages: 7
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "182a48a51ed19c8a"
---

<!-- page 1 -->

रजिस्ट्री सं” डी" एल*-(एन)04/0007/2003--07 REGISTERED NO. DL—(N)04/0007/2003—07
The Gazette of Gudia
असाधारण
EXTRAORDINARY
~- aw I— asi
PART II — Section i
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY
we 34] नई दिल्‍ली, मंगलवार, मई 29, 2007 / ज्येष्ठ 7, 929 *
No.3] NEW DELHI, TUESDAY, MAY 29, 2007/ JYAISTHA 8, 929
इस भाग में भिन पृष्ठ संख्या दी जाती है जिससे कि यह अलग संकलन के रूप में रखा जा सके।
Separate paging is given to this Part in order that it may be filed as a separate compilation.
MINISTRY OF LAW AND JUSTICE
(Legislative Department)
New Delhi, the 29th May, 2007/Jyaistha 8, 929 (Saka)
The following Act of Parliament received the assent of the President on
the 28th May, 2007, and is hereby published for general information:—
THE ELECTRICITY (AMENDMENT) ACT, 2007
No. 26 oF 2007
[28th May, 2007.]
An Act further to amend the Electricity Act, 2003.
Be it enacted by Parliament in the Fifty-eighth Year of the Republic of India as
follows:—
I. (7) This Act may be called the Electricity (Amendment) Act, 2007. Short title and
commencement
(2) Itshall come into force on such date as the Central Government may, by notification
in the Official Gazette, appoint.

<!-- page 2 -->

2 THE GAZETTE OF INDIA EXTRAORDINARY [Part [I—
Substitution of 2. For section 6 of the Electricity Act, 2003 (hereinafter referred to as the principal 36 of 2003.
ne for Act), the following section shall be substituted, namely:—
s
Joint "6. The concerned State Government and the Central Government shall
Responsibility jointly endeavour to provide access to electricity to all areas including villages
Goveroment and hamlets through rural electricity infrastructure and electrification of
and Central households", ५
Government in
tural
electrification.
Amendment of 3. In section 9 of the principal Act, in sub-section ( /), after the proviso, the following
section 9. proviso shall be inserted, namely:—

“Provided further that no licence shall be required under this Act for supply of
electricity generated from a captive generating plant to any licensee in accordance
with the provisions of this Act and the rules and regulations made thereunder and to
any consumer subject to the regulations made under sub-section (2) of section 42.",

Amendment of 4. In section 38 of the principal Act, in sub-section (2), in clause (d),—

section 38
(i) in the second proviso, the words "and eliminated" shall be omitted;
(ii) the third proviso shall be omitted.

Amendment of 5. In section 39 of the principal Act, in sub-section (2), in clause (d),—

tion 39. aa न नि

seen (i) in the second proviso, the words “and eliminated" shall be omitted;
(i) the third proviso shall be omitted.

Amendment of 6. In section 40 of the principal Act,—

section 40, (i) in the second proviso, the words "and eliminated” shall be omitted;
(ii) the third proviso shall be omitted. मा

Amendment of 7. In section 42 of the principal Act, in sub-section (2),—

section 42 हु है

(i) in the first proviso, for the words "such open access may be allowed before
the cross-subsidies are eliminated on payment of a surcharge", the words "such open
access shall be allowed on payment of a surcharge" shall be substituted;

(ii) in the third proviso, the words "and eliminated" shall be omitted.

Amendment of 8. In section 43 of the principal Act, in sub-section (/),—

section 43 कई कं —

ae (i) for the words "Every distribution", the words "Save as otherwise provided in
this Act, every distribution" shall be substituted:

(ii) after the second proviso, the following Explanation shall be inserted, namely:—

‘Explanation. —For the purposes of this sub-section, "application" means
the application complete in all respects in the appropriate form, as required by
the distribution licensee, along with documents showing payment of necessary
charges and other compliances:',

Substitution of 9. For section 50 of the principal Act, the following section shall be substituted,

new section fF namely.

section 50 y

The electricity “50. The State Commission shall specify an electricity supply code to provide

supply code. for recovery of electricity charges, intervals for billing of electricity charges,
disconnection of supply of electricity for non-payment thereof, restoration of supply
of electricity, measures for preventing tampering, distress or damage to electrical plant
or electrical line or meter, entry of distribution licensee or any person acting on his
behalf for diconnecting supply and removing the meter, entry for replacing, altering or
maintaining electric lines or electrical plants or meter and such other matters.”.

<!-- page 3 -->

Sec. l] THE GAZETTE OF INDIA EXTRAORDINARY 3
SSS
SSS eeY”g”wwieee®e:
0. In section 6 of the principal Act, for clause (g), the following clause shall be Amendment of
substituted, namely:— section 6
"(g) that the tariff progressively reflects the cost of supply of electricity
and also reduces cross-subsidies in the manner specified by the Appropriate
Commission;", , ~
व, व section 26 of the principal Act— Amendment of
Df व है नि . section 26..
(i for sub-section (3), the fol lowing sub-section shall be substituted, namely:—
“(3) The person, on whom an order has been served under sub-section (2),
a shall be entitled to file objections, if any, against the provisional assessment
before the assessing officer, who shall, after affording a reasonable opportunity
of hearing to such person, pass a final order of assessment within thirty days
from the date of service of such order of provisional assessment, of the electricity
charges payable by such person.”;
(ii) in sub-section (4), the proviso shall be omitted;
(iii) for sub-section (5), the following sub-section shall be substituted, namely:—
“(5) If the assessing officer reaches to the conclusion that unauthorised
use of electricity has taken place, the assessment shall be made for the entire
period during which such unauthorised use of electricity has taken place and if,
however, the period during which such unauthorised use of electricity has taken
place cannot be ascertained, such period shall be limited to a period of twelve
months immediately preceding the date of inspection.”;
हु (iv) in sub-section (6), for the words “one-and-half times”, the word “twice”
shall be substituted;
(v) in the Explanation Occurring at the end, in clause (4), for sub-clause (7), the
following sub-clauses shall be substituted, namely:—
“(ivy for the purpose other than for which the usage of electricity was
authorised; or
(») for the premises or areas other than those for which the supply of
electricity was authorised.”,
2. In section 27 of the principal Act, in sub-section (2), for the words “one-third of Amendment of
the assessed amount”, the words “half of the assessed amount” shall be substituted. section 427.
43, In section 35 of the principal Act— ‘Amendment of
| : हे हि section 35
(A) for sub-section (/), the following sub-sections shall be substituted, namely:—
+(7) Whoever, dishonestly,—
(a) taps, makes or causes to be made any connection with overhead,
underground or under water lines or cables, or service wires, or service
facilities of a licensee or supplier, as the case may be; or
(6) tampers a meter, installs or uses a tampered meter, current
Teversing transformer, loop connection or any other device or method which
interferes with accurate or proper registration, calibration or metering of
electric current or otherwise results in a manner whereby electricity is
stolen or wasted; or
(c) damages or destroys an electric meter, apparatus, equipment, or
wire or causes or allows any of them to be so damaged or destroyed as to
interfere with the proper or accurate metering of electricity; or
(d) uses electricity through a tampered meter; or
(e) uses electricity for the purpose other than for which the usage of
electricity was authorised,

<!-- page 4 -->

4 THE GAZETTE OF INDIA EXTRAORDINARY a AEE OF INDIA EXTRAORDINARY [Part II— 0—

—S—— सा 7
So as to abstract or consume or use electricity shall be punishable with
imprisonment for a term which may extend to three years or with fine or with
both:

Provided that in a case where the load abstracted, consumed, or used or
attempted abstraction or attempted consumption or attempted use—

(i) does not exceed 0 kilowatt, the fine imposed on first conviction
shall not be less than three times the financial gain on account of such
theft of electricity and in the event of second or subsequent conviction
the fine imposed shall not be less than six times the financial gain on

* account of such theft of electricity;

(ii) exceeds 0 kilowatt, the fine imposed on first conviction shall
not be less than three times the financial gain on account of such theft of
electricity and in the event of second or subsequent conviction, the
sentence shall be imprisonment for a term not less than six months, but
which may extend to five years and with fine not less than six times the
financial gain on account of such theft of electricity:

Provided further that in the event of second and subsequent conviction
of a person where the load abstracted, consumed, or used or attempted
abstraction or attempted consumption or attempted use exceeds 0 kilowatt,
such person shall also be debarred from getting any supply of electricity for a
period which shall not be less than three months but may extend to two years
and shall also be debarred from getting supply of electricity for that period
from any other source or generating station:

Provided also that if it is proved that any artificial means or means not
authorised by the Board or licensee or supplier, as the case may be, exist for the
abstraction, consumption or use of electricity by the consumer, it shall be
presumed, until the contrary is proved, that any abstraction, consumption or
use offelectricity has been dishonestly caused by such consumer, .

(IA) Without prejudice to the provisions of this Act, the licensee or
supplier, as the case may be, may, upon detection of such theft of electricity,
immediately disconnect the supply of electricity:

Provided that only such officer of the licensee or supplier, as authorised
for the purpose by the Appropriate Commission or any other officer of the
licensee or supplier, as the case may be, of the rank higher than the rank so
authorised shall disconnect the supply line of electricity:

Provided further that such officer of the licensee or supplier, as the case
may be, shall lodge a complaint in writing relating to the commission of such
offence in police station having jurisdiction within twenty-four hours from the
time of such disconnection:

Provided also that the licensee or supplier, as the case may be, on deposit
or payment of the assessed amount or electricity charges in accordance with
the provisions of this Act, shall, without prejudice to the ob ligation to lodge the
complaint as referred to in the second proviso to this clause, restore the supply
line of electricity within forty-eight hours of such deposit or payment.”;

(B) in sub-section (2), for the words “Any officer authorised”, the words “Any

officer of the licensee or supplier as the case may be, authorised” shall be substituted.

Amendment of 44. In section 50 of the principal Act, after sub-section (2), the following shall be
serion 250, inserted, namely:—

“(3) Notwithstanding anything contained in sub-section ( 7) of section 35, sub-

section (7) of section 36, section I37 and section I 38, the licence or certificate of

<!-- page 5 -->

Sec. I] THE GAZETTE OF INDIA EXTRAORDINARY EE OF INDIA EXTRAORDINARY OS
eee ARS
SSS 4232 ललल कल,
competency or permit or such other authorisation issued under the rules made or deemed
to have been made under this Act to any person who acting as an electrical contractor,
supervisor or worker abets the commission of an offence punishable under sub-section
(J) of section 35, sub-section (J) of section 36, section | 37, or section 38, on his
रे conviction for such abetment, may also be cancelled by the licensing authority:
Provided that no order of such cancellation shall be made without giving such
Person an opportunity of being heard.
Explanation.— For the purposes of this sub-section, “licensing authority” means
the officer who for the time being in force is issuing or renewing such licence or
‘ certificate of competency or permit or such other authorisation.’.
5. In section 5] of the principal Act, the following provisos shall be inserted, namely:— Amendment of
४ F ff . section I5].
“Provided that the court may also take cognizance of an offence punishable sen
under this Act upon a report ofa police officer filed under section 73 of the Code of
2 of 974. Criminal Procedure, 973:
Provided further that a special court constituted under section | 53 shall be
competent to take cognizance of an offence without the accused being committed to it
for trial.",
6. After section 5] of the principal Act, the following sections shall be inserted, insertion of new
namely:— sections I5A
and I5B.
“I5A. For the purposes of investigation of an offence punishable under this Power of police
Act, the police officer shall have all the Powers as provided in Chapter XII of the ‘0 investigate.
2 of 974, Code of Criminal Procedure, |973.
I5B. Notwithstanding anything contained in the Code of Criminal Procedure. Certain offences
2 of 974. 973, an offence punishable under sections I35 to 40 or section 50 shall be cognizable _ to be cognizable
and non-bailable.”. and non-bailable
47, in section 53 of the principal Act, in sub-section (J), for the words and figures “sections Amendment of
35 to 39", the words and figures “sections 35 to 40 and section 50" shall be substituted, section 53
8. In section 54 of the principal Act,— Amendment of
ke fi न 54,
() for the words and figures “sections 35 to 39" wherever they occur, the °°"!
words and figures “sections 35 to 40 and section 50” shall be substituted;
(ii) in sub-section (5), for the words “Special Court may", the words “Special
Court shall” shall be substitued,
-
9. In section 76 of the principal Act, in clause (2), in clause (6), for the brackets and Amendment of
words “(including the capital adequacy, credit worthiness or code of conduct)", the words section 76.
“relating to the capital adequacy, credit worthiness or code of conduct" shall be substituted.
20. In section 78 of the principal Act, in sub-section (2)— ae of
section
(#) in clause (X), the words “and elimination" shall be omitted;
कं (i) in clause (m), the words “and elimination" shall be omitted;
(iit) for clause (r), the following clause shall be substituted, namely:—
“() the manner for reduction of cross-subsidies under clause (g) of
section 6;".
2. In section I8] of the principal Act, in sub-section (2),— Amendment of
मा]
() in clause (j), the words “and elimination” shall be omitted;
(ii) in clause (m), the words “and elimination” shall be omitted;
(iii) in clause (p), the words “and elimination” shall be omitted;
ee

<!-- page 6 -->

6 THE GAZETTE OF INDIA EXTRAORDINARY [Part Il—Sec. l]
(iv) for clause (zc), the following clause shall be substituted, naniely:—
“(zc) the manner of reduction of cross-subsidies under clause (g) of
section 6;".
K.N. CHATURVEDI,
Secy. to the Govt. of India.
PRINTED BY THE MANAGER , GOVT, OF INDIA PRESS, MINTO ROAD, NEW DELHI AND PUBLISHED BY THE
CONTROLLER OF PUBLICATIONS, DELHI, 2007
MGIPMRND—2474G|(S5)—30-06-2007

<!-- page 7 -->

रजिस्ट्री सं०् डी० एल०-33004/99 es REGD.NO.D. L.-33004/99
San
ut
42
ta राज पन्न
सत्पमेव जयते
असाधारण
; EXTRAORDINARY
amt _— aus 3 —3a-WUS (ii)
PART Il—Section 3—Sub-section (ii)
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY
ooo
सं, 709] नई दिल्‍ली, मंगलवार, जून 2, 2007/ज्येष्ठ 22, 929
De See eee नमन मनन न नन्न 709] NEW DELHI, TUESDAY, JUNE 2, 2007/TYAISTHA 22, 929
विद्युत मंत्रालय MINISTRY OF POWER
अधिसूचना NOTIFICATION
नई दिल्‍ली, 2 5%, 2007 New Delhi, the 2th June, 2007
950(E).—In exerci Phe ree
aren, 950(#), 37 सरकार, विद्युत (संशोधन) ee S.0. 950(E). : a pee ० th power
अधिनियम, 2007 (2007 का 26) की धार की उप-धारा (2) sonferred by sub-section (2) of Section | of the
; ue aH, 2007 oe 20 की ee Electricity (Amendment) Act, 2007 (26 of 2007), the
a ei te का अंबीग a Ba I5 Eh 2007 —_ oT Central Government hereby appoints the [5th June,
तारीख के ee a नियुक्त करती है, जबसे उक्त अधि कक 2007, as the date on which the provisions of the said
Waar are |e Act shall come into force.
[फा. H 42/2/2005-aIk Us a (@TS-IV)] [F. No. 42/2/2005-R&R (Vol-IV)]
अनिल कुमार, अपर सचिव ANIL KUMAR, Addl. Secy.
2755 GI/2007
Printed by the Manager, Govt, of India Press, Ring Road, Mayapurl, New Delhi-I0064 -
and Published by the Controller of Publications, Delhi-0054.
