---
doc_id: "fcaba3b8d49ee6a3"
source_url: "https://cdn.s3waas.gov.in/s35f93f983524def3dca464469d2cf9f3e/uploads/2025/07/2025070263-1.pdf"
ministry: "Mohla-Manpur-Ambagarh Chouki"
title: "स्थानांतरण आदेश फार्मासिस्ट स्वास्थ्य विभाग (501 KB)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4fc385406bb2d73e"
---

<!-- page 1 -->

GRE-

07747-299136

d- collector-mmac@cg.gov.in

//AI4T//

H0G6295/T./FATRY /2025

$ File No.RULE-3017/2/2025-GAD-6 TT

2

3

HE

HH9 3i0t, fio 27.062025

2025 $ 314T4 # TT

yr fe-io 05

5

6

1

G-2

27.6.4

yo»4io395/eT./RA/ 2025
1.
2.
3
4.

5.
6

7.

rI--HY tt (31)
