---
doc_id: "efeee46a5b1f48fa"
source_url: "https://rda.cgstate.gov.in/uploads/gallery/worktender1-21-Jul-2026.pdf"
ministry: "Raipur Development Authority"
title: "Work regarding the drilling of 04 borewells and the installation of submersible pumps and panel boards (including cables) for the water supply system of the Authority's Town Development Scheme No. 04, Kaushalya Mata Vihar (Kamal Vihar)."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "43d954103f819036"
---

<!-- page 1 -->

(shHjF- 15 feio 17.07.2026)

1

1. urfecagU

3

2

4

5

R facaH
5.

04

15 f¢qH

T 12,56,643/- o. 25,133/-. 2,000/

26

I4yr (B0T0)
GIYear 2012Pat- IV)\Deewan Sir-(5)\NLT LALL).docx
