---
doc_id: "5ebce38c4fb84fb9"
source_url: "https://scert.cg.gov.in/pdf/DED2017-18/school-internship-direction-22sept2017.pdf"
ministry: "State council of Educational Research & Training, Raipur, Chhattisgarh"
title: "द्विवर्षीय बी.एड. /डी.एल.एड. के छात्राध्यापकों को शाला अनुभव कार्यक्रम के लिये संस्था आबंटन करने के संबंध में दिशा निर्देश (22/09/2017)"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "bd5feb59441a7b75"
---

<!-- page 1 -->

Scanned by CamScanner

<!-- page 2 -->

Scanned by CamScanner

<!-- page 3 -->

Scanned by CamScanner

<!-- page 4 -->

SCHOOL INTERNSHIP: FRAMEWORK
AND GUDELINES
(January, 2016)

NATIONAL COUNCIL FOR TEACHER EDUCATION
Hans Bhawan (Wing-II),
1, Bahadur Shah Zafar Marg,
New Delhi-110 002
www.ncte-india.org

0

<!-- page 5 -->

1. Background
Like all other professional programmes, field engagement is an essential component of any
teacher education programme. In the case of teacher education programmes, field engagement
involves engagement with the students and teachers in schools. The sustained engagement with
the school over a period of time is known as ‘school internship’ which equips the prospective
teacher to build a repertoire of professional understandings, competencies and skills, and
positive attitude to schooling and teaching. In fact, it is this component of the teacher education
curriculum which facilitates transformation of a student-teachers from being learners in the art
and science of teaching to adequately-equipped teachers to perform the responsibilities of a
teacher in actual school settings.
The present day educational discourse centres around the concepts of self-learning, selfknowledge, and constructivist approach to teaching and learning which implies the students
need to be facilitated to graduate from being mere recipients of knowledge to become
assimilators and generators of knowledge. The internship programme provides an opportunity
to the prospective teachers to link the educational theory and pedagogical concepts with their
practice on the one hand, and on the other to test the validity of theoretical propositions in
actual school settings.
2. School Internship: Changing Scenario
The past few years have witnessed a paradigm shift in the concept of school internship courses
in India. The earlier stipulation of practice-teaching involved teaching of a pre-specified
number of lessons in the subjects offered by a student-teacher as teaching or methods subjects.
The NCTE Regulations, 2009 made an attempt to broaden the scope of practice-teaching by
emphasising the importance of providing experience of all activities and programmes of the
school to the student-teachers. The NCTE Regulations, 2014 have stipulated further
strengthening of the component of ‘Field Engagement’ by prescribing a longer duration of 20
weeks for it in the elementary and secondary teacher education programmes like D.El.Ed.,
B.El.Ed, B.Ed, B.A.B.Ed., and B.Sc.B.Ed. and B.Ed.-M.Ed. The ‘Field Engagement’ of 20
weeks has been further split into two parts consisting of 4 weeks and 16 weeks to be organized
in the first and second year of the Two-Years programmes, and in the second, third and fourth
year of the Four-Year programmes. The engagement of 16 weeks’ duration is further split into
14 weeks of school internship and 2 weeks of engagement with the field other than the school
(i.e. community engagement). Further, the total internship time is to be split between two types
of schools at the rate of 80% and 20%.
The relevant stipulations of NCTE Regulations, 2014 regarding duration of school internships
are summarised below:

1

<!-- page 6 -->

Diploma in Elementary Education (D.El.Ed.)
1st Year

2nd Year

Total

4 Weeks
(2nd Semester)

16 Week
(3rd Semester)

20 weeks

S.No.
1

Internship Duration

2

Total Programme Credits

40

40

80

3

4

16

20

4

Internship (field engagement)
Credits
Total Marks assigned

1000

1000

2000

5

Marks assigned for Internship

100

400

500

6
7

Weightage in terms of credits
Weightage of Internship in terms
of marks

10%
10%

40%
40%

25%
25%

1st Year

2nd Year

Total

2 weeks
(2nd Sem)

18 weeks
(3rd Sem)

20 weeks

40

40

80

Bachelor of Education (B.Ed.)
S.No.
1

Internship Duration

2

Total Programme Credit

3

Internship Credits

4

16 (14+2)

20

4

Total Marks assigned

1000

1000

2000

5

Marks assigned for Internship

100

400

500

6

Weightage in terms of credits

10%

40%

25%

7

Weightage of Internship in terms
of marks

10%

40%

25%

B.A B.Ed./B.Sc. B.Ed. (4 Year Integrated Programme)
S.No.
1

Internship Duration

2

Total Programme Credit
(Education Component)
Internship Credits
(Education Component)
Total Marks assigned
(Education Component)
Marks assigned for Internship
(Education Component)

3
4
5

1st
Year
-

2nd Year

3rd Year

4th Year

Total

2 weeks
(4th Sem)

2 weeks
(6th Sem)

16 weeks
(7th Sem)

20 weeks

14

10

18

44

86

-

2

2

16 (14+2)

20

350

250

450

1100

2150

-

50

50

400

500

6

Weightage in terms of credits
(Education Component)

-

20%

11.11%

36.3%

23.25%

7

Weightage of Internship in terms of
marks (Education Component)

-

20%

11.11%

36.3%

23.25%

N.B.: - In the final year of the programme 14 weeks are recommended for school internship and the remaining
two weeks for community field work.

2

<!-- page 7 -->

The tables given above reveal that due to enhanced duration and enhanced weightage, school
internship and field engagement component of the curriculum of three teacher education
programmes has been placed at the centre stage of the programme design. Approximately 25%
weightage has been assigned to this component alone. It is expected that after the completion
of ‘Internship’, the intern teacher will be ready to take up the responsibilities of a teacher
independently. The enhanced duration of internship implies that tremendous amount of
resources shall be required in terms of money, time and efforts and therefore these will have
to be utilised in a planned and systematic manner to ensure successful implementation of
internship. To ensure realisation of the expected outcomes, the planning and organization of
the internship shall have to be based on the principles mentioned below.
3. Organisation of Internship: Some Principles

Internship
Schools as
Lab Schools

School
Experience in
Diverse
contexts: 80%
Govt Schools,
20% Non Govt
Schools

Teacher
Preparation: Joint
Responsibility of
NCTE, State
Education
Departments,
Schools,
Affiliating Bodies

Performance
Assessment
by TEI and
Schools

SCHOOL
INTERNSHIP
InternTeachers as
Full-Time
Teachers
Competent and
Willing
Internship
school teachers
as Mentor
Teachers

a)
While the Internship shall be put in by student-teachers in designated schools, the rest
of the four weeks shall be spread over other semesters and involve activities like school visit,
classroom observation, individual and group assignments. Out of the 16 weeks full-time school
internship, two weeks shall be for community work, and the rest be divided equally between
practice teaching and all school-based activities.
b)
The student-teachers/intern-teacher should be called upon to work as full-time teachers
in negotiated schools during internship under the guidance and supervision of school principal
and mentor teachers. In other words, they should be required to undertake all such tasks as are
3

<!-- page 8 -->

performed by regular teachers of the school. In addition, they ought to be provided
opportunities to observe, participate and contribute in all activities of the school both in school
curricular and co-curricular activities and out of school activities.
c)
Some competent and willing teachers of the ‘internship schools’ could be designated as
“Mentor Teachers”. In an academic session, 3-4 student-teachers could be attached with a
mentor-teacher keeping in view his /her subject specialisation. The identified mentor-teachers
who could be treated as members of the extended teacher education faculty shall be provided
intensive orientation to the responsibilities of a mentor-teacher to avoid wastage of resources.
It would be desirable to ensure stability of the tenure of the mentor-teachers.
d)
A majority of teachers are generally called upon to work during their professional career
in diverse contexts, such as Govt/Private schools in urban and rural areas. It would be desirable
to provide opportunities to the student-teachers to gain experience of working in diverse
contexts by completing internship in schools located in urban, rural and tribal areas. It has
been proposed to earmark 80% of time for Internship in Government and 20% of time in
Private Schools.
e)
The schools identified for hosting the internship ought to be treated as lab schools of a
TEI so as to enable the faculty and the student-teachers to engage with the school students,
teachers and the local community in a sustained manner which may lead to the understanding
of the education system, self, students, community, etc. These schools should be available to
the faculty and students throughout the year for observation, experimentation, interaction,
information gathering, etc.
f)
Initial teacher preparation including organization of school internship shall be as a joint
responsibility of the Teacher Education Regulator at the Central level, State Education
Departments, Affiliating Bodies, Teacher Education Institutions and Internship or host schools.
The above mentioned institutions/ agencies, being stakeholders in the quality of future teachers
are expected to function in a coordinated manner with pre-defined and suitably demarcated
responsibilities.
g)
The assessment of the student teacher’s performance and achievements at different
stages during the school internship will be required for certification purposes as per the scheme
of evaluation prescribed by the affiliating body. The assessment of interns’ performance in
tasks undertaken by them shall be done jointly by the teacher education faculty, school
principals and mentor teachers. The teacher education institutions will make available to the
schools the detailed guidelines for the evaluation scheme (provided in the Internship Handbook
of NCTE).
·

NCTE shall develop Internship Guidelines for State Governments/SCERTs, and
Internship Handbook for Affiliating Universities, TEIs and Internship Schools for
implementation of school internship. NCTE shall also orient University Education
Faculties and SCERTs as master trainers to further orient the TEIs and Internship Schools.
4

<!-- page 9 -->

·

The State Government shall facilitate availability of especially Government Schools to the
TEIs and in the smooth implementation of School Internship.

·

The Internship Schools shall take responsibility in engaging and assessing studentteachers, and shaping their attitude and experiences on school and community engagement.
4. Organisational Responsibilities

As stated above, the NCTE, State Education Departments, affiliating bodies, teacher education
institutions and schools have to share the responsibility of preparing future teachers. The roles
and responsibilities of different players are elaborated as follows.
a) National Council for Teacher Education (NCTE): As a Regulator for teacher education
in the country, the NCTE is mandated to formulate teacher education policy, lay down norms
and standards for various teacher education programmes, and develop curriculum frameworks
for different programmes. In the context of School Internship, the NCTE shall develop
guidelines for its implementation and elaborate the roles and responsibilities of various
agencies involved in the task of teacher preparation, such as State Education Departments and
Affiliating Bodies. It is estimated that for approximately 16000 TEIs, (D.El.Ed. and B.Ed.),
around 1.5 lakh schools will have to be identified for the organizations of internship. In
addition, it shall develop a handbook of internship for the reference of the State Govts. and
affiliating bodies, and for the use of TEIs and internship schools.
The roles and responsibilities of NCTE are summarised in the box given below:
Roles and Responsibilities: NCTE
· Formulate and notify Internship Policy (already given in Regulations 2014).
· Develop Internship Handbook for the use of Teacher Education Faculty, Student Teachers,
School Principals and Mentor Teachers.

· Elaborate Internship Tasks and Assessment Framework in the Handbook.
b) State Education Departments: The schools in any state are under the administrative
control of the State Education Departments. A State Education Department needs to maintain
the data regarding institutions offering various Teacher Education programmes and the
sanctioned intake of each institution. The department shall work out the requirement of
internship school for each TEI keeping in view the norms prescribed by NCTE. The NCTE
Regulations, 2014 stipulate that a TEI for an intake of 100 students, should have easy access
to 10 schools for the organization of internship programme. (This shall be reduced to 5 schools
for an intake of 50 students).
The criteria for allocation of schools to TEIs should be developed, which may include distance
from the TEI, distance from residence, accessibility etc. The allocation of schools to TEIs could
be done at the district level in the office of the District Education Officer. The district education
5

<!-- page 10 -->

officials shall visit the lab school at least twice during the internship, and at least once in the
first year of internship to take stock of the ongoing programme in the internship school.
The roles and responsibilities of State Education Department are summarised in the box
given below:
Roles and Responsibilities: State Education Department
State Level
· Maintain database of TEIs in the State.
· Work out the requirement of Internship/ Lab Schools @10 schools per 100 student-teachers
(5 per 50 student-teachers).
· Formulate internship policy of the state and issue guidelines for the District Education
authorities concerning identification and monitoring of internship schools.
· Compile monitoring reports received from the districts and forward the consolidated report to
the NCTE.
District Level
· Prepare internship calendar in consultation with affiliating bodies.
· Allocate schools to TEIs in the district.
· Monitor internship periodically and send reports to the state headquarters.

c) Affiliating Bodies: In India, the degree level teacher education programmes are affiliated
to the universities and diploma level programmes are affiliated to either SCERTs or Boards of
School Education. The affiliating bodies prescribe the scheme of examination of different
components of the teacher education programme including internship. The affiliating body
shall have to assign weightage to each component of the internship and thereafter should
specify the procedure to be adopted by a TEI for determining the assessment grade or marks
for individual student-teachers in different components. The responsibility of an affiliating
body does not end with the formulation of evaluation scheme and development of guidelines
for TEIs. It should chalkout a plan to monitor and supervise the organization of internship by
the TEIs affiliated to it, for which it may devise “monitoring-cum-supervision proforma”. A
consolidated monitoring report along with monitoring reports of individual institutions should
be sent to NCTE for its reference and use.
The roles and responsibilities of Affiliating Bodies are summarised in the box given below:
Roles and Responsibilities: Affiliating Bodies
·
·
·

Prepare a calendar of school internship in consultation with the state education department.
Develop, notify and circulate the scheme of evaluation for the internship component.
Suggest procedures to be followed by TEIs and internship schools for assessing student-teachers’
performance.

· Undertake periodical monitoring of TEIs (along with DEOs) and of internship and send consolidated
report to NCTE.

d) Teacher Education Institution: A Teacher Education Institution (TEI) has to play a crucial
role in the organization of internship programme. It has to: i) internalise the internship policy
formulated by NCTE, ii) examination scheme formulated by affiliating body, iii) internship
6

<!-- page 11 -->

schedule drawn by the state government, and prepare itself to implement the policies and plan
effectively. If should interact with the lab schools and mentor teachers continuously. The TEI
shall shoulder the responsibility of orienting the School Principals and Mentor Teachers to
equip them for the organisation of internship. The Handbook on School Internship prepared by
the NCTE (and also by the Affiliating Body) should be discussed in the Internship Schools
attached to it. In addition to the core activities suggested in the Handbooks, the teacher
education faculty and school mentor teachers may design a few need-based and locally-relevant
activities, such as survey of historical monuments in the school neighbourhood, interview with
local artists and artisans, meetings with retired award winning soldiers and teachers, visits to
places of cultural importance assessment of the mechanism of neighbourhood cleanliness, etc.
The roles and responsibilities of Teacher Education Institutions are summarised in the box
given below:
Roles and Responsibilities: Teacher Education Institutions
· Provide Internship Handbooks to the internship schools.
· Organise orientation–cum-consultation meetings with the school principals and mentors
teachers.
· Develop supplementary material for additional activities in collaboration with mentor
teachers.
· Hold fortnightly review meetings with mentor teachers.
· Hold follow-up meetings with student-teachers at regular intervals in the TEI.
· Monitor implementation of internship including observation of practice teaching.
· Assess, in collaboration with school mentor-teachers, the internship performance of studentteachers.

e) Internship or Lab School: A school categorised as Internship or Lab School by the State
Education Department should prepare itself to function as the extension centre of the TEI to
which it has been attached. The teachers identified by it as mentor teachers shall participate in
the orientation workshop organised by the concerned TEI and contribute towards the
development of the internship Implementation Plan. The mentor-teachers shall be called upon
to continuously supervise the student-teachers and provide them the necessary guidance, as and
when required on the listed school-based and community-based activities. The mentor-teachers
will also be involved in the assessment of student-teachers’ performance for which they will
be oriented to the use of a variety of assessment tools like rating scales, questionnaires,
observation schedules, etc.
The roles and responsibilities of Internship /Lab School are summarised in the box given
below:
Roles and Responsibilities: Internship /Lab School
·
·
·

Identify well-qualified and adequately-motivated teachers to be associated with TEIs as
mentor teachers.
Depute the mentor-teachers to participate in the orientation meetings in the TEI.
Make available all school facilitates to the student-teachers such as library, laboratories,
playgrounds etc.

7

<!-- page 12 -->

·

·

Permit the student-teachers to participate and contribute in all activities
of the school such as school assembly, cultural activities, PTA meetings, games, inter-house
competitions, etc., and guide in the subject practice teaching by student-teachers.
Participate in the assessment of students’ performance.

· Address promptly the problems and difficulties of student-teachers.
5. Student Teachers’ Tasks during Internship
During Internship, the student-teachers are required to undertake a variety of activities relating
to classroom teaching, classroom management, and organisation of school-based and
community-based activities other than teaching. However, for undertaking the activities, the
student-teachers are required to develop a repertoire of understandings, competencies, and
skills. They have to undertake some activities in the first part of the internship and some other
in the second part. A few such activities are suggested below (which have been elaborated in
detail in the Internship Handbook):
a)
b)
c)
d)
e)

Understanding the Internship School and the community around.
Analysis of school syllabus and textbooks.
Observing the classroom teaching of regular teachers.
Observation of classroom teaching of peer student-teachers.
Preparation of case study of the internship school and the innovative activities that the
school undertakes.
f) Preparation of Lesson Plans and Unit Plans.
g) Teaching the units of the prescribed syllabus in two subjects currently being taught in
the school.
h) Teaching as a substitute teacher.
i) Mobilisation and development of teaching-learning resources.
j) Preparation of a question papers and other assessment tools.
k) Preparation of a diagnostic tests and organisation of remedial teaching.
l) Undertake case study of a child.
m) Undertake action research project on at least one problem area of schooling.
n) Community work, community survey etc.
o) Maintenance of a reflective diary or journal to record day to day happenings and
reflections thereon.
p) Writing a term paper on a selected theme.
The TEIs and Internship Schools may devise additional activities on the basis of local specific
needs. While selecting the units of the syllabus, the student-teachers shall follow the annual
instructional plan drawn by the host school.
6. Assessing Student Teachers’ Performance for Certification
The NCTE Regulations, 2014 envisage 100% internal assessment in respect of internship. As
stated earlier, the student-teachers’ performance shall be assessed jointly by the TEI Faculty,
8

<!-- page 13 -->

School Principals and Mentor Teachers. In order to ensure transparency and objectivity in
assessment, the affiliating bodies shall have to prescribe a detailed evaluation scheme and
suggest an appropriate mechanism for carrying out the assessment. (This has been explained
in the Internship Handbook of NCTE). Further to ensure uniformity across TEIs, a number of
assessment proformas like classroom observation schedule, teaching quality assessment
proforma, term paper/ project report assessment proforma, etc. shall be developed by NCTE.
Timeline
1. Preparation of Internship Handbook by NCTE: February, 2016.
2. Preparation of Internship Guidelines for State Govts by NCTE: February, 2016.
3. Review and Finalisation of Handbook and Guidelines by Experts in a Workshop:
February, 2016.
4. The Internship Framework and Guidelines have been circulated on February 15, 2016
to University Heads of Education, Directors of SCERTs (with copy to State Education
Secretaries) to start preparation for statutory approval and identification of internship
schools (especially government schools).
5. As the next step, the following activities shall be undertaken to implement Internship
in TEIs by July 2016.
6. Orientation of Affiliating Bodies, State Education Departments, SCERTs: March,
2016.
7. Identification of Internship Schools and orientation of ISs and TEIs by affiliating
bodies/SCERTs: April, 2016.
8. Preparation for school internship by TEIs: May 2016.
9. Allocation of student-teachers to internship schools by the TEIs: June 2016.
10. Start of school internship: July 2016 (July – December 2016).

9
