---
doc_id: "f01fb5ce24e3befb"
source_url: "https://eproc.cgstate.gov.in/CHEPS/html/chips/Guidelines_To_Bidders_EPS_v1.6.pdf?OWASP_CSRFTOKEN=IHWR-J3W9-SK4Q-T0BX-FDMX-C2I8-6N3L-5XKC"
ministry: "Integrated e-Procurement Portal, Chhattisgarh"
title: "Guidelines to Bidders"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0db4f8493b6fc269"
---

<!-- page 1 -->

Guidelines for bidders on using integrated eProcurement
System Govt. of Chhattisgarh
https://eproc.cgstate.gov.in

1

<!-- page 2 -->

Change Log
Version

Author

Change Description

Reviewer

Date

Approver

1.0

Mjunction

-

CHiPS

10/02/16

CHiPS

1.1

Mjunction

Java ver. Update,
Recommended Min.
Bandwidth, Document
size limit

CHiPS

06/04/16

CHiPS

1.2

Mjunction

Earnest Money section
update

CHiPS

13/06/16

CHiPS

1.3

Mjunction

Added Registration &
Renewal Fees

CHiPS

26/11/16

CHiPS

1.4

Mjunction

Update Help Desk
Number & email

CHiPS

14/12/17

CHiPS

1.5

Mjunction

EMD Payment details

CHiPS

05/06/18

CHiPS

1.6

Mjunction

Bid Submission

CHiPS

18/10/19

CHiPS

2

<!-- page 3 -->

TABLE OF CONTENTS
1

Vendor / Bidder Registration on the e-Procurement System………………….4

2

Digital Signature Certificates………………………………………………………………….4

3

Online Payment……………………………………………………………………………………..5

4

Setup of User’s Computer System …………………………………………………………6

5

Publishing of N.I.T………………………………………………………………………………….6

6

Tender’s Critical Dates & Time/Tender Time Schedule…………………………..6

7

Download Tender Document(s)……………………………………………………………..6

8

Submit Online Bids…………………………………………………………………………………6

9

Submission of Earnest Money Deposit……………………………………………………6

10

Opening of Tenders………………………………………………………………………………..7

11

Briefcase…………………………………………………………………………………………………7

12

Support – Help Desk……………………………………………………………………………….7

3

<!-- page 4 -->

Note: These conditions will over-rule the conditions stated in the tender document(s),
wherever relevant and applicable.

1. Vendor / Bidder Registration on the e-Procurement System:
.
All the Users / Bidders (Manufacturers / Contractors / Suppliers / Vendors / Distributors etc.)
registered with and intending to participate in the Tenders of various Govt. Departments /
Agencies / Corporations / Boards / Undertakings under Govt. of Chhattisgarh processed using
the Integrated e-Procurement System are required to get registered on the centralized portal
https://eproc.cgstate.gov.in and approved on specific class (e.g. A, B, C, D, UGE, UDE) from
Public Works Department (in case to participate in tenders restricted to vendors / bidders in a
particular class).
The non – registered users / bidders who are also eligible to participate in the tenders floated
using the e-Procurement system are also required to be registered online on the e-Procurement
system.
Vendors are advised to complete their online enrolment / registration process on the portal well
in advance to avoid last minute hassle, it is suggested to complete enrolment at least four days
before the last date of bid submission date, failing which may result in non-submission of bids
on time for which vendor/end user shall be solely responsible. Also ensure to mention correct
Bank account details during the registration, which will be referred during refund of
unsuccessful EMD/Bid Security.
Vendors are required to pay online registration / enrolment fee of Rs. 500/- one time and
renewal fee of Rs. 100/- for subsequent each year.
For more details, please get in touch with e-Procurement system integrator:
M/s. Mjunction Services Limited, Raipur – 492 001
Toll free 1800 419 9140 or
Email: helpdesk.cgeproc@mjunction.in.

2. Digital Signature Certificates:
The bids submitted online must be signed digitally with a valid Class II / Class – III Digital
Signature Certificate to establish the identity of the bidders submitting the bids online. The
bidders may obtain pair of Encryption & Signing Class – II / Class – III Digital Certificate issued by
an approved Certifying Authority (CA) authorized by the Controller of Certifying Authorities
(CCA), Government of India, may refer http://www.cca.gov.in/cca/?q=licensed_ca.html.

4

<!-- page 5 -->

Note: It may take up to 7 to 10 working days for issuance of Class-II / Class-III Digital Certificate,
Therefore the bidders are advised to obtain it at the earliest. It is compulsory to possess a valid
Class-II / Class-III Digital Certificate while registering online on the above mentioned eProcurement portal. A Digital Certificate once mapped to an account / registration cannot be
remapped with any other account / registration however it may be inactivated / deactivated.
Important Note: bid under preparation / creation for a particular tender may only be submitted
using the same digital certificate that is used for encryption to encrypt the bid data during the
bid preparation / creation / responding stage. However bidder may prepare / create and submit
a fresh bid using his/her another / reissued / renewed Digital Certificate only within the
stipulated date and time as specified in the tender.
In case, during the process of a particular bid preparation / responding for a tender, the bidder
loses his/her Digital Certificate for any reason they will not be able to submit the same bid under
preparation online, Hence the bidders are advised to keep their Digital Certificates secure to be
used whenever required and comply with IT Act 2000 & its amendments and CVC guidelines.

The digital certificate issued to the authorized user of an individual / partnership firm / private
limited company / public limited company / joint venture and used for online bidding will be
considered as equivalent to a no-objection certificate / power of attorney to the user.
Unless the certificate is revoked, it will be assumed to represent adequate authority of the
specific individual to bid on behalf of the organization / firm for online tenders as per
Information Technology Act 2000. This authorized user will be required to obtain a valid Class-II
/ Class-III Digital Certificate. The Digital Signature executed through the use of Digital Certificate
of this authorized user will be binding on the organization / firm. It shall be the responsibility of
management / partners of the concerned organization / firm to inform the Certifying Authority,
if the authorized user changes, and apply for a fresh digital certificate for the new authorized
user.

3. Online Payment: As the bid is to be submitted only online, bidders are required to make
online payment(s) of the Registration fee / Transaction or Service fees / EMD using the online
payments gateway services integrated into the e-Procurement portal using various payment
modes like Credit Card / Debit Card / Internet Banking / Cash Card / NEFT / RTGS etc. bidders
are advised to initiate and process the eChallan/NEFT/RTGS payments well before bid due date
in order to get the same updated in the eProcurement system, Also refer RBI guidelines for
NEFT/RTGS payment.
For the list of available online modes of electronic payments that are presently accepted on the
online payments gateway services, please refer the link ‘Payments accepted online’ on the
eProcurement portal https://eproc.cgstate.gov.in.

5

<!-- page 6 -->

4. Setup of User’s Computer System: In order to operate on the e-Procurement portal for a
bidder / user, the computer system /desktop/laptop of the bidder is required to have Java
ver.8.77, Internet explorer 9 / 11, latest Mozilla Firefox, Google Chrome with IE Tab V2
(Enhanced IE Tab).
A detailed step by step document on the same is available on the eProcurement portal home
page. Also internet connectivity should be minimum one MBPS.
An auto setup utility is available on the eProcurement portal home page for its users to auto
configure client system, link to auto setup: https://eproc.cgstate.gov.in --> Auto Setup.
5. Publishing of N.I.T.: For the tenders processed using the e-Procurement system, only a brief
advertisement notice related to the tender shall be published in the newspapers and the
detailed notice shall be published only on the e-Procurement system. Bidders can view the
detailed notice, tender document and the activity time schedule for all the tenders processed
using the e-Procurement system on the portal https://eproc.cgstate.gov.in.
6. Tender’s Critical Dates & Time/Tender Time Schedule: The bidders are strictly advised to
follow the tender schedule for their side of tasks activities and responsibilities require to
participate in the tender.
All the activities / tasks of each tender are locked with the start date and time and end date &
time at the time of uploading tender as set by the concerned department official.
7. Download Tender Document(s): The tender document and supporting document(s) can be
downloaded only online. The tender document(s) will be available for download to concerned
bidders after online publishing of the tender and up to the stipulated date & time as set in the
tender.
8. Submit Online Bids:
Bidders have to submit their bid online after successful filling of forms within the specified date
and time as set in the tender.
The encrypted bid data of only those bidders who have submitted their bids within the
stipulated date & time will be accepted by the e-Procurement system. It is expected that the
bidder complete his bid within stipulated timeline. Bid of the bidder who has not submitted his
bid within the stipulated date & time will not be available during opening. It is recommended
that bidders login and recheck their bid details & its status after bid submission in order to
double sure submission of accurate bid data for respective tenders.
Size of bid documents uploaded during bid preparation should be less than five MB (for
individual document) and over all bid documents should be less than fifty MB.
In case of any concern for any tender/bid submission, please register it in the Department /
CHiPS/ Help Desk well in advance before initiating opening process so that appropriate action
can be taken.
6

<!-- page 7 -->

9. Submission of Earnest Money Deposit: The bidders shall submit their Earnest Money Deposit
Either as in usual physically sealed Earnest Money Deposit envelope and the same should reach
the concerned office OR Online using payment gateway as stated in the Notice Inviting Tender/
Tender document. Bidders also have to upload scanned copy of Earnest Money Deposit
instrument OR Online Payment /NEFT/RTGS receipt along with the reference details online.
Bidders who choose to pay Earnest Money Deposit (EMD) or bid security using online
payment(s) mode like Internet banking/ Debit Card/ Credit Card/NEFT/RTGS/eChallan/wallet
etc. would be entitled for online refund subject to tender terms & conditions and evaluation by
respective department authority.
Intending bidder(s)/vendor(s)/user(s) are required to provide their relevant & correct account
details during registration in the portal which shall be used for EMD/Bid Security refund
purpose, bidder(s)/vendor(s)/user(s) shall be solely responsible for providing correct account
details and CHiPS/System Integrator shall not verify account details provided and be not
responsible for any loss/transfer of funds.
Bidder(s)/vendor(s)/user(s) may update their account details in their registration if desired, the
last updated account details shall be considered for future payment(s)/refund(s) if applicable.
10. Opening of Tenders: The concerned department official receiving the tenders or his duly
authorized officer shall first open the online Earnest Money Deposit envelope of all the bidders
and verify the same uploaded by the bidders. He / She shall also verify the scanned documents
uploaded by the bidders, if any, as required. In case, the requirements are incomplete, the next
i.e. technical and commercial envelopes of the concerned bidders received online shall not be
opened.
The concerned official shall then open the other subsequent envelopes submitted online by the
bidders in the presence of the bidders or their authorized representatives who choose to be
present in the bid opening process or may view opened details online.
11. Briefcase: Bidders are privileged to have an online briefcase to keep their documents online
and the same can be attached to multiple tenders while responding, this will facilitate bidders
to upload their documents once in the briefcase and attach the same document to multiple bids
submitting.
12. Support – Help Desk
For any further queries / assistance, bidders may contact:
1. The Service Integrator of e-Procurement system, M/s. Mjunction Service Ltd. on Help Desk
Toll free No. 1800 419 9140 or email helpdesk.cgeproc@mjunction.in.
2. Mr. Shailesh Kumar Soni, Sr. Manager, Chhattisgarh Infotech & Biotech Promotion Society
(CHiPS) on Tel. No. 0771 - 4014158 or email: pro-chips@nic.in.
7
