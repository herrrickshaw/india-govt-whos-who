---
doc_id: "ff35a28efc6d2e4e"
source_url: "https://cgbse.nic.in/Documents/2024/SecondExam_Gazette_Notification_edit.pdf"
ministry: "Chhattisgarh Board Of Secondary Education, Raipur"
title: "मण्डल द्वारा एक शैक्षणिक सत्र में दो मुख्य परीक्षा आयोजित करने संबंधी असाधारण राजपत्र |"
date: ""
pages: 3
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "4801eec174f1c0a9"
---

<!-- page 1 -->

८522 g 5 On Ve
“बिजनेस पोस्ट के अन्तर्गत डाक शुल्क के 9 </222---५३५० ९ पंजीयन क्रमांक
डाक ( i on “छत्तीसगढ़ 99
नगद भुगतान (बिना डाक टिकट) के प्रेषण (30 ) रे [St /09/203-2045.
हेतु अनुमत. क्रमांक जी.2-22-छत्तीसगढ़ ‘ay or  }
oon दिनांक a A ॥॥! # R
गजट / 38 सि. से. भिलाई. दिनांक ॥ १६ ६ AY ५
30-05-200!.” * WW eat AW &
Sr 00
&
(असाधारण)
क्रमांक 239 | रायपुर, शुक्रवार, दिनांक 2। जून 2024--- ज्येष्ठ 33, शक 946
स्कूल शिक्षा विभाग
मंत्रालय, महानदी भवन, नवा रायपुर अटल नगर
CHHATTISGARH BOARD OF SECONDARY EDUCATION
PENSION BADA, RAIPUR
Raipur, the l9th June 2024
NOTIFICATION
No./556/Samnvay/2024.— In exercise of the powers conferred by sub-section (l) and (4) of Section 28
of the Chhattisgarh Madhyamik Shiksha Adhiniyam, 965 (No. 23 of 965), the Board of Secondary Education,
Chhattisgarh, hereby, makes the following further amendment in the Board of Secondary Education
Chhattisgarh Regulation, 965, these regulation have been approved by the State Government, namely:-
AMENDMENT
In the said regulation,-
L. Under Chapter XIX, for the heading “Supplementary Examination”, the heading “Supplementary
Examination or Second Main Examination’ shall be substituted.
2. After regulation 48, the following regulation shall be inserted, namely:-
“[484., Second Main Examination.-

() Chhattisgarh Board of Secondary Education will conduct the annual examination of high
school (Class l0th) and higher secondary (Class 2th) twice in one academic session. The
first examination will be addressed as First Main Examination and the second examination
will be addressed as Second Main Examination.

(2) It will be mandatory to fill the application form to appear in the second main examination
and only those students, who are registered in the first examination will be able to fill the
application and they will have to fill the online examination application from the same
institution in which, he had filled the application for the first main examination.

(3) A separate date will be fixed by the Board of Secondary Education for filling the
application form for the second main examination.

477
Scanned with OKEN Scanner

<!-- page 2 -->

478 छत्तीसगढ़ राजपत्र, दिनांक 2। जून 2024

(4) Candidates, whose result in the first main examination has been in the supplementary
category, it will be mandatory for those candidates to apply in all the subjects given
supplementary and candidates can also apply for improvement in marks in other subjects.

(5) Candidates, who have failed or remained absent in the first main examination can apply for
the second main examination. In such situation, it will be mandatory for them to apply in
all the absent/failed subjects and the candidates can also apply for improvement in marks
in other subjects.

(6) If, the result of the candidate is pass in the first main examination and he is not satisfied
with his marks, then he can fill-up the examination application for improvement of marks
in the second main examination. It is not necessary that the candidate should apply in all
the passed subjects, the candidate can apply in one passed subject or two passed subjects or
more passed subjects as per his wish. The result will be prepared considering the increased
marks in the subject/subjects in which the candidate improves his/her marks in the second
main examination and the marks obtained in the first main examination in other subjects.

If the candidate is not able to improve the marks in the subject/subjects in the second
main examination, then in that situation only the marks of the candidate in the first main
examination will be considered and the marks sheet will not be issued to him again.

(7) The candidate will be eligible to appear in the same subjects in the second main
examination in which he has filled the examination application form in the first main
examination. Under no circumstances, he can change his subjects in the second main
examination. It is also worth mentioning here that if the candidate has taken an additional
subject in the first main examination, then he can appear in the second main examination
also by taking the same subject as an additional subject.

(8) While preparing the results of the candidates in the second main examination, the marks
obtained in the practical and project in the first main examination will be considered for the
second main examination, but if any candidate is not able to appear in the practical and
project examination or fails in the first main examination, then such candidates will be
eligible to appear in the practical and project examination in the second main examination.

(9) The same grace marking policy will be valid in the second main examination, which is
valid in the first main examination.

(0) If the candidate is eligible for bonus marks in the first main examination, then he will be
eligible for bonus marks in the second main examination also but the bonus marks will not
be repeated i.e. after deducting the bonus marks added in the first main examination, the
bonus in the second main examination will be added.

(.l) After the result of the first main examination, a temporary merit list will be issued and after
re-calculation/re-evaluation of the first main examination, a permanent merit list will be
issued.

(।.2)) The passed candidate shall be issued mark sheet in first main examination and if the marks
increased in second main examination to the candidates, then such circumstances, shall get
first examination mark sheet from the students, second main examination marksheet shall
be provided.

(i3) Counterfoil of mark list and result of recount/re-evaluation of 2nd TR, 2nd Main
Examination will be printed only after their release but the database of both the exams will
be kept safe. In the mark list of the first and second main examination, the name of the
studying institution for regular candidates and the name of the forwarding institution for
self-study candidates will be mentioned against the name of the institution/centre.

(4) While printing the mark list of the second main examination. special mark (exa.$) will be
marked in the those subjects, in which the marks of the candidate have increased.

(5) After declaring the results of the first main examination, the second main examination will
be started from the third week of June. since the results of retotaling/revaluation of the first
main examination cannot be declared before the commencement of the second main
examination, therefore, candidates will have to fill the application for Second Main
Examination without waiting for the result of retotaling/revaluation of First Main
Examination. If the results of retotaling /re-evaluation of the first main examination are

Scanned with OKEN Scanner

<!-- page 3 -->

eT oT, eT 220248)
declared after the commencement of the second main examination, then any representation
or complaint of the candidate will not be considered.

(6) Those candidates who appear in the second main examination for improvement of marks in
the subject/subjects and improve the marks or there is no improvement in the marks, then
such candidates are eligible for division improvement as per the provisions of the previous
rules on the basis of eligibility.

(7) Those candidates who remain unsuccessful in some subjects even after the second main
examination, will get the benefit of third and fourth chance as per the current rules in the
first main examination and second main examination of the coming year.

(8) Like the first main examination, in the second main examination also, question papers will
be printed in three sets (A, B, C) in main subjects and single set in minor subjects.

(i9) It will be mandatory for the candidates, who want to appear in the examination under these
regulations, to deposit the fees prescribed by the Board.”

Sd/-
(Pushpa Sahu)
Secretary
Board of Secondary Education.
संचालक, मुद्रण तथा लेखन सामग्री, छत्तीसगढ़ द्वारा शासकीय मुद्रणालय, रायपर से मुद्रित तथा प्रकाशित - 2024.
Scanned with OKEN Scanner
