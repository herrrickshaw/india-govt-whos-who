---
doc_id: "aafda327ad0b7ada"
source_url: "https://cdn.s3waas.gov.in/s328dd2c7955ce926456240b2ff0100bde/uploads/2026/06/17804884774725.pdf"
ministry: "Kabeerdham"
title: "संहायक ग्रेड 3 नियमित क्र 22 से (4 MB)"
date: ""
pages: 25
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a8a8cdf01fd1f639"
---

<!-- page 1 -->

(

E

&

r
SEE re

.--lF

t.
t-

5
a

'E

E

E

E

RBi

F

trE"

E

Ff

#6 *
+€ L

EE

#E r"
+EF

t"

-t"

Erfre;ErrgEgr

rf
E

*

E
E
E

E

EB EEf

b E : E EIE E I F
-

€$f f
F

E

E
t:; sIE E
F . F d E 6 ts.s
E BnEEFtr

& Fr
&+.
E

- 16& F 6
E& r t'- dg

" E p€ "
EEF.E
E

EEv

E

E

E
E

E
16

E

F

E

& E

E
E
E

f
E

Ro

3i

E

4

:E^

rD E

*
E

Fs'

:E
P

Eu
E

E
E

E

a

*,F
e Fi F F: - "E . uE

EE

trE
F'E

FF

E

r.LE
FE

#F
tr,

EE

E

F

tr

a

rE e€
F&
#p EFI
_fl

KE
d"B

F

B:

-E
si5
FE
EC

F7A

:

-

:

:

)

3

6\

)

n

<!-- page 2 -->

.E
c2

E

:
E

::

g^r

E H: -r" F;
"E

?

&
E

tr E

Ef e e F
SFE r€

E

l-

t-

ui
E
tu

.E

16

V

e Et E

E+

i=

l"
l

s

EF'
trE
Fe

EE

FE

EF

gE
FE
tE
eE

"E

plE

:E

EE

6

E

;E

=

s:

rE
cE
;E
1s lE

EE

f*

Fr
B"

E,T

E

E

E
E

+

E

E

Eb

F,Y

EF

EE

iE
g

E

E

l9-

t

E

F@

F

E,E

l=

E

E

E;fessfrr EEEr

*

":l9 E tr t) r,
dt
6tr!c
F 1€ t
E BnEE?tr

E.E;f x{F E

E

- lEd F E
E eG le F
d{

trl5 "E - F
IE

E
"E E

EEFE
E

;Fu

EEE
E

t
E

E

F
F

E'

E
F

E

E
E

lc

f

a

E

E

t2_

FF
TF
E

E

€r
es

;

=

a

)

t

cb

)

\

EF

iF

\

<----

E,

E

a

€

<!-- page 3 -->

1!

E
E

SE# r*

E;fes;ErrgEsr
FF
166
E

&
E
E
&

vE

E€EfEEE Ele

E'fruiEEfE
di56
E+.
E

rd

r 5E E E

l: .-E .

" E rf '
E

EEK E
&

sG,

:KE
b

t
€
E

t-

l-

t
EE

cF

fE
lE 4:
E.

g

F

E

F

EE
V

F

E E

E

E

E

E

E
E
E-

E
lc

f

E
=

:a

E

EE
+E
EE

*E
EE

Ir

i

E3

V

.Ptr

c

E*
sE

rE
q;E
B:

E

r
E

I

E

lt

E

E

=

rF
EA
-!

"rF

E'

L.

)
(.

c-9

6\

1

a
\
tr{
\

<!-- page 4 -->

N

&
E
E E

t"

*EE rs
l"
6rp"Irts66FFEe
EEEEBEf Fg E,E Ei;
B"E

i=
l=

E+

E
l-

1=

t-

*

.E

&
E

FFTEE16EgF

r

E

ES.tsC
E E 5 EN'
i-6.+FE,fr

FE E *:E FE E

EH

sEf
t,E;t
nE E?'r
@e
E

]€E F E

E *G 16 F

"E

na:
tE&.
E
E
E

5ET.E
E

EEv
EEE

R!
E

?

b

? = =&

a

E

:

<E

-}

E

E

{

E"

E.

Ec

E

E

^E

d
H

f

,5

u\

-{

a

EF

E

t&
FT

E

tt)
E

FE

eE

€

ts

E

E:

E

FE

!E

E

E

E
e-

F

tE

EE

*
E.E

EE
E

19E

Ev

E

H

F

F

& E

:

E
E

f

<!-- page 5 -->

)

E;f

I

1!

&
E

*FE re

re;Ere rErr
UE
cI

leF
E

E"

€
16'

^ - e,6 E F- E

p
p-81.E21i

B 5S Es r
"EE
E#.Ea E E a'Ew

E

E HEEE?tr

E.i;t sE#
@b€

l"
t-

-t:
l-

E
E

E

E

?

e.

ss

s+
g3

16

- 16& ts

E eG le E

E cG "
E

E

h

b.E r tr ds

n

E

"f "
;Sb
g

E

F
E

E

Es,

3se

* F6I

?

Eg
\h

Ed

EE,

EE
r;E
E F.E

E

7

€

FF

P
E

FE

F

E'

*,

E,

?

E,
E"

E
E

H

frc

EE
o*'

F
E

F
F
@ E

E F
E
E

E

c
IG

1

_E

rl

E

=

:

=- =

\

J

A

3

(

<!-- page 6 -->

15

I

F{
SF& Ps

E;f re;Err EEEr
-\
N.E

CP
tEF

E

€
tu

f
E
E

rE:EE16EEF
E

E.E F H#
'tr.JEtrb.

g
E€
E EE E-E F
o6E6
E

E.E;t

16

EsF E
E .|,EEE€;-E 6 16 lr lE
@.@

E
16

"

r'4{

- 16& F
ls lE

F E iE

,€

bi E F.E

E

;6 p
ESU
D

E
E

E

E
p

E
E

F
F

F

E E
E
F
E
E
ts

l-

I

I

6

I

E

s'!

E

dE
6E

* ef,
cEF
drE

q
E

3x-

FE

E

n3

Ee F,

e

P"t5&

&
EE

E

EE

E

E

E

Er

Fcp

E

FE

EE F,

TE
rE
TE
E

F

BFE

E

e

E

;

F

Ep
E
E

:!

b

E

F

.E

=-

a.::

'E

a

\

J_

f

i-

6\

t'l

11

<!-- page 7 -->

)

E

1!

E

E

E

SEE p-€

*€reFFEe

oE

]=
I

l=

i-

t-

I

E
3

q
E sF

:a

HEE

t dEF

E F

l

:

E

Ei

4i .E

F

E

€-pF

E

cB^

;

&

E1

E

E,

i

g3'

E

:5t
E

z
a"

a:::

J

-t
5\

-'1

E

f
5tn

EP

E+

\

]

1

:(

\
,,{
E"

EEi

;
- E& - E& EF€

rE e
Fpfi
EE

E

Fct
Y

Eg

tr
P'

E

E

EE,

E

ETE

K)

E

E

E"

b

PE

r Ee

E'E
o EE

E EE
E:E

E;E E

-T;

Egst, E$ ee 6,9 g;
tsf

E
tu

E
E
E

o * I t Et P I

r*8"

n

E

.F€ E H Ifr E3 E
EE E EE

EB

sEF
E.E;f
oE EF'e
@ 56

E

E

EE

e5EEF

16

lE -E * Edg
,E.E-Er

E

;f u
Esb
E

E

E
E

E

F
F

E

& E

E
F
E

E
E

<!-- page 8 -->

F

E

E

E€f FE
Et E*ts€r r sF e- e

EEEft,EfEsEgr;
Ff

Eff

EI;
.E
E.
E

E

EEEEEg
E E I ,tr,trF
E. EI*Fa.Et
F \FirE 6tr/rE

E 1'IEEEG-B E l€. lrtrE

E

-

r 5# rE dce

lq .E

E

"Er€"
EEF"E
E

sG p

E

E

E

g

F

E
E-

H

E

F

g^
g

E

EE

EE

c5F

E e?
@rE

E

€

33
P\

*B

s E-

BN

CE

"9,

Ec

E

€F€

E

E"d? E

EE

*e

t

EE

v,

E.

-E
rP

PE'

p)d: E

::!':::
EE

FB

P

F
E

E

E
j'

:=

Ets i.

E

v

€

:€

*E

.E

V

E

t

tE
E

F

E E

E tr

E

E

E

E

E
F
F
E

E

:

j

f

-J

1

d,

I

a

<!-- page 9 -->

E

E

r E:
SFE Ps

F;f cs;Err
rE
E
B.

€
E
E

tt-

l-

gEgr

IE}EEGE9F

E,E E 5 &f Ft d!'E i9 E tr E) 11' tr E'

btr+6 H*
E E+
E E G.'EtrE

EIt

56

E.-FE. li ?Eef
Pdr l!s
h
tr N PE EG& 6 E n_trF-

49

e.@

E

tr_

16E15

Ed ts lF
E rE le F
4I
ls "E r
6E-Eb
E

E

P

:

i
6i

RR

,.

E

RR

E

EEF"E
E

€- &
5

I

FE

;Fn"
638
E

E

E

EE

ts-

E F"

E

rFP

rE

EE
E:

EE

FE

E

I

-F

E

FE

F

s

E

E

g
G

t
e

?.

€

E

HE

rFP
r--P.
t Fd:

H

F

e F
E

E

d E
F

f
IG

-E

r FEc

EE;

Is

FE

9e
FEE)5 t
FIE
E

z3

E

E

e.

EE
E

E

i

:

n

:

a

eC"-

J
(

I

,3

6

4oIJ
7
-7

<!-- page 10 -->

'ls

E
E

Ef e e E
*EE cs
]cE4rc
E[[6sf!sIsFt=[
IEpef,E$c*fi[in

rf
&
.E
E.
IG

F

- E } E 816 E E F
€E Ef [E E;f

E BPEE?,TT

t.E;EsEfE
€d

E
e 5E E F
b"E r r4:

" E p6'
b," E"E
&

sf p,
:3b
E

E

E

F

F

E

E

F

F

E

E

E
F

€

E

tr

tp

€:E

E

:

e

p E'

EE^,

FE
EE

H F,E

E

E.

F

E

E

FE"

E4? ts

PeE
& p,E
EF

E

E,
.E

l

E

eE
sE

hE
EE

L-

€

E,

f

9i

i

e

x:.

r!

i

.

-l
-(

,3

a\

.fi
p
3
-h
\

<!-- page 11 -->

1C

E

&

F

E€E;I
Et Euitt* r eP E r
I Eptf Efi F€ E,E; E
FF
166

E

€

E+Er EE E E#

o, n : r Ef, E I F
F€ E B It EE r

E B "E

p-

E.t;fsEfE
EFt
@+
E

FdJ

"E "

e 5S E F

fI'E.-E
;. F F.E
E

st n"
:SB

E

E

t.
l-

t-

l-

E

E

E E

a :

+

E

E3

R:
E

E

E=
EE

F

-Ets
EE

FE

li ,E

g
E

EE

FE
E

rsE

F

F

EE
@

E

E

f

F.E

EE

"E
r1

E

Eii

F
E

s..F

d

V

F

F

6

;
€
lr

E

t

G

a

t

E

E

]

I
ts!

;

3_

,2

;

h
\
c<
\

<!-- page 12 -->

{E

E

E

$Ft *-s

l-

l'

-F

Et $ods€s s sg 6 E
EEEfgSEF€EgE F
r)
rE
E
E"

€
16

F

*EEF r: iE &F
E1E E I F
Ff r

E

*Ef; E# EEf

-i;t s;P

E

!

?

E BnEEPtr

E
@4fr

E

n-

- 16&',F E

E)

o,

E

E'-FE

a

b-E r 4:
rE"E"

E rG b F

E

5

I

E&

pE
E€

E

*H

F

fr

E

E

&

EF

F

-s3-

E
E

E
E

€

E

F
E

F
E

Br

"€
ESb

:
e.
E

F

f

E

r?

dlFI
aFI

,i

Ep+

FEf
E#E

E

E

E,*
E

Ets

EEseE

tsD b

512

EF

srE

trE I'
2
E.

atr
E

=

tp
ilE

ls,@

E,

€

z
E

XR

€
F&
=
,"8,

e

=

;

-

:

-1

-(.
CE

b\
.<1

-\

a
N$
?-\

<!-- page 13 -->

A
\!

E
E

F E

Ef E s E
SE{ Pe

E;fEe;Err
RF
Ef
E
l€

E

gEgr

FhIEEI6EEE

r

E

4" E.F E IH

e * IB EE B'
"E€
Ef

EH

xEf
f.E;f
nE E?t
E Eo
E

"E E

E

-- E& F r€
F p$ re F
FE r r4:

FE

E

sG p

t
E

E

E
E

E

& E

t-

E

a

F

fi
E

s3

g t ^,s

F

Etrn

EE

E
G

E. F

F
-42
HF E

EEIi

trE

FE

;E s"
E

E,F

E

E

F.
E

E

v
b?_

F

E

&

€

I

E

lE

-e

E

E EE
.e EE

E

FE

e EE
E

FE

E

=

aE

E

:

-.:=

::

E?

Et'

i

l

=

\

J

.I

il
d
J

t

1

?--

\

\

<!-- page 14 -->

@

F

E

E

Ef E s E
SEE c€

l_

gEEr

pD

l-

F;f es;f rr

E

]6

E-

E

E'trE

F

t-

I'

l€6

E

*

€
E
E

FE._^EEiGF9F
.E€ E H YS EE
E#4"
E,.E E E+

E

sEF
E.f;t
E lVEEE€-.

E

F

E

fE
EE

'E'
EE
rdi

EE

E g?

d!rE

E

P

E

!E
r&

tE
19

Es,

nE

rE

'12

e

E

Ee
6E

-p

F

E

r

=

:

F€E

eft
E! FF E
Y:E

E

"E

a

ER

J

-t

,s

lc

b

5

\
*
5E

F&
E

\

\$
c<

a)

"E- ?r;
EE
h-8"

!

FE

b.c

*fi

E

E

F

E,

E

E
b,

t

E
E
F
E

E

F

I

€s; EEE

9

F

a

etu
E

F
E

I

H:

s

E& F tr
E *G le F
bE r rdl
E E1'

E

EEP E
&

E

E

E

E

E

E

E

E

E

p
:AB
"G

E
F

{
l€

<!-- page 15 -->

16

&

E

E

f C F:E
E#F IE h

;;

Er,5-"sE€EFYEE
Ei€flHfi cc s g
E

Bf
E

c
E
E

16

" - Er€ E F, E

E€f i[E EEf

E tt* Fa,E e
E 6 16 rrtrle
& Eo

E

e

etu
E

Raa

sl

fr

TFF E
&
p,

:Rb
"G
E

E F&

E -€ 16 F
E.E - r'- e
trE-Eo

I

EE

E

E

.:

-

E

&

;ec

n8!

E F&

EE*

3,.E'
", b pts
+E
EE

EE
E

r'i

::

=

;

J

J
\

.h
6\

a

--1a

-E
I.J
F

)f

E1:
rF+ E-Ef

: E"E

E

(!

1.

t

+

E rE

Eu'

H

F

E

E

E,

t:
E,

E
E

*

E

F,

;E

E

F

E
:
E
E

F

f
lE

<!-- page 16 -->

E
&
E
E E

E€f E&

g;

Sr [* [slis 5 Ef, [ r

EEEtf,Bfi Er E,E

u;

E{
E

E"

€
E

FETFEleEEF

€Ef* EE EEf
E

E H*EE?,Er

f.E;f sEf
4! 5€

E

- 16& F E
E rG IE F

E.E * tr dg
tE"Er"

EERE
E

@

!

s

15

E

tr

e
E

;;!

2-a

"f

.!Ea
tr [
Y

F FEd?

"'..88
ETEE

E

3n

iE

E'

E

f-

E'

F-E

EE

5trE

r

E

v

E ru

.sE

IseE'

E

E

. EE

ET EE
E- F Ed:

4eI
E

v.

F
F

E.

e-

E

f
E

l5' E

Ee

E

E

g

€

E

E

&

;8ts
"F"

E
E
E

€

F

S

=di

a='

::

5

E

-r

f

,s

e\

"x
a

h

<!-- page 17 -->

16

E
Ir.

! s

*E E r€

ErfsgsfirrCEgr
pF
leF
E

&
tu

.E

E

E

T'*IEEl6EEF

€Ef * H} EEf
&

E

1,

16

lt- lE E

E

s{F
€.t;t
PE'86,
tr
@ 5€

F

"E "

- lE& F E
E pG b F
F.E r r4I

FE

E6F &P
E

;€ o
:Si,

E

E

F
E

F
E
F
E

e E
F
F

f
IG

t;

t"

l-

E

a

E rts

E

d=r

;

l

Fdg

.r

1

3f,

\

,s

c

x

EE

I
F.P

-.5
IJ

F

=t

EE

I;E
FE

F

E

I
E

\

F Fq

B:5

b

:1 -

EEE

P

.!

E

:!

EEEif,E

E

s

r Et"
d EE

6tse
T EE

E FE

EHe
.B
trE

Fe
E

f'-

g

\

<!-- page 18 -->

E

E

E

SF{ rs

F

E

E

E

E,E

E"i

EtfcssErpgEgr

-

r

.-.

it

-l.:trE1689F
.E4r u E !B EE c
E#+6 [E B E#
F

E HnEEF'er

E.E;; gtF c
e r@
En
E

rIEEF

lr -E * tr dY

E

'E cf "
EEF, E
E

s€ e
:Rs

E

E
E

E
g.

€

E

1,

E

a

EFT

€Er
dg
r

E

FE

Ri

? :

3e

\

:!
E\

F;

sn

e F&

E

E?
Ee

f'
FE
EF s"

t
EE*

e*

*st'
E EE
E

;EE

Ee
EE

F

&

Fi

tsF
EE

F
F

F
F

E"

:

E

€
E

F

E

e

E

E E
&
F
F

f

]G

E

lsrE

q
E

* EE

=

J
f

,3

a\

9

11

/1

e
\

<!-- page 19 -->

E
H

*FE r€

E;fra;ErrEEEr
PE
EE
E

E

1-

E

€
]G

t-

l.

l-

E

-

FETEEl6E9F
8,ts E 5 [,f F.i'

tc

E

€Ff; # EE#

EB

sEf
E.E;f
oE Ef

E

e 5E E F
b.E - rdY

" E Ff '
E

EEF E
&

B

E

E

d

€ sF
3EF

E
q

E

iii

E

E
E

E

E

ad2

EE

F:
E

E

oE

:3
16

!
F

Y
E

d.'

;E-

E"p

F

Hfi

E€ E

r F& E F& E E

E6

;E

Et

Rs8 653

E

pE
E

EE

F+

E E

E

H

EE

*E

EE

Err

FE
E6

*E

t1,

2

1;

E

E

E

E

E

E

EE

E

E

E
E

E

F

e.E
EE

d

F
E

f
E

!E

l:

{r

s=.

5*

5

E

-

gsi

""8
EEi
EF1

pr
:
a

;
;

-'

a\

-.1;)

a

<!-- page 20 -->

\-

1!

E

E

E

€84 ne
Eo $*f,s€6 s sg
E

EEE1;EEE Ff E E I

Li
CF

l0F
E

&

-u
F
E

-Ec
F - s+ E eF

rFlEEl6EgF
B;'E Er c
E€
Ef c E E 5 Er,

E,E;tsEFE
E H'EEPtr
E5F
E

I6E F E

"

E rG E F
r. dl
oliE.
E e€

IEFE
&

v

"G
=Sts

F
E

F
l

l-

I
l=

5
a

sE,EFF
EE
I

E

:E

E ,t!

E

F€

EE

E

E

Eg

€E"

H

E"o

&

FE

Fr"
eE

rE

fE

6F

EE

-E

€E

EP

E

E Ef

Eg

E
E

F

EE

F
E

Ef

F

H

*E

,t
F

& E

E
F
E

{
?

a

E:
a F&

pF
rE

br
E
E,

&a.

EF

:

:

j-

J

3
h

7

'v:

<!-- page 21 -->

A
v

"F

E

E

EE 5 O E

T*E EE

l-

i=

E;f resErr EEgEl,
E"i
EE
E

&

E
E

- o 3 s [t p I I
€EE* EE EEf
# E t
'trtr8

g.p;;EefE

E 1'TFEEG-E 6 16 rrEE
4! 56

c 5€ E e

b.E * tr 4c

" E F€ "
E

;rE-& E
E

;

E

,

E
E

EEr
SEE
'E F

?

E

;

:

=

FE"

F

EEg,

FE=

EF

B

EE

F

EEEB

"-FE p
sd*

fi)!E

,i]EE

g -E
96 E

E;q

E EE

e EE
EE

F

EE
E

F

E

E

+.

f;

EI,

G

E

I

€u

€

E

E

E

H

E.

F

F

E

E

E

F

E

F

sG nn
xtb

E
E

6

f

B-

EE

'12

EE

E
E

E

=

!

)

t

,s

a

7X\
).-

\*s
\

<!-- page 22 -->

16

&

E

€Ef ;€
E+ $*f,6€6 6 pg g s

F'

t,

T

EEEfBEEE€EEE;
FH
lc6
u

E
16

*
.E

E

- E ! tr Flc E I
E€
s E EE Er e
o"*6
[.8 F E=E

E e t-,orF

E-Ep;Esfg

@d

E

FT

tr lJ PE E,E,
E E 16 h lEle-

E

"E
f ftrFE
:pt
-r; 16 Ff

E.

aG e

Eu

E

€

€ E?
e

BE6

F

f

3E

3

:

e

pE

n F& :

E

E5

f,E

I
;E

s

E

E
E

€

EE
EE

Els

5E

E

Ec

u

&

P
E

E

EE

e€

F,B.

'E

Ei5

Etr,

cE
E_a

E

F
E

H

E

E

g E

+

E

E,
E

E

e E
E

6

E

=

re

ii

=i
j-

t=
FE

E

eE

:
=

.:
Gi.

]

t"

i

vE
P

F

€
E

E

J

l

-1
L^.J

a\

r,'
-++U\

\

<!-- page 23 -->

&

EEE
*&;

F

e

E

I

t-

t-

t:

l-

t-

l=

E
E E

EE E O ts

$*+ FE

E;fre;frrEEBr
pd
E6

E
E"

.E

E
E

,F E ! E 816 E I F
E€EBE?EEF
no+€ EE B E#

E I t-,ueE
E

E.E;T Egf
E },EE?rP
& Fc

E*
E

r

5€ E 4se

b .-E
=

E

"
" E r€'

E

6

s

EEE

E
E
E

E

€

E

E

€r

EEb

EEE

E

E

E

F

F

I

E

F

EE E.

E

&
&

;SE
"f "

&
E

E
E
P

,b

E

I

PE

!F

a
tsd{

E"trE

ErE
p& E

HE

Y
c

v,

E

E

E Ef

e
E,

=!
E

R ts&

-}
(

,5

A

-a

4
-h
\
2z
\

<!-- page 24 -->

ri\

\2

lqtr,Fits

&

Eq

Ef e s E
€FErs

5

E

F
P

E

?

-E

t6 d: E

EEE

:

EFT

6Ets
E F-f
'E
e

+
E

E

E3

s.
3R

EE

E

EY

E

EE

EI

E, F

b

r&

P\

u
Fd{

IE F
"dE
€e
IEE

F.E

EF

I

t-

-1:

"-fEGESESFEpEE
F
EEECf,E][ Eg E,E;
eE'
FE
E

E

E.

"E

E

F

E

*'+T EE E E#

o s r Ef, E I F
E^E E 5 Etr F' E
dT H E F EP H,E E,

E.E;l sEf
E ]JEEE€-E E Ir lrtrtE

E

E&'F r€

F *6le F
"E

rds
f,E.E.
E
E

EFFE
E

sG p"
EEb
E
E

E

E
E

EE

tEt

E

E

Ep

E I
&

E

F
F

E

& E
E
F
E

t

lc

:

-- a':

r

; =c

e

E

;

=

:

=!.

=

J

-t
c5

)

a
$

\

2--.

t-

<!-- page 25 -->

E

E
&

E

€EE eq

F;fss;frcgEfr

Eff

ui
E+
E

&

.E

E

E€Ef gg

sIf E
E.E;f
E B nE Ef t r
&a

eF

€Er'
CEF
'&
F

e

I

9R

F

"

U9

&

TFFE

r 5E E F
l5 .E * E 4l
t.P
rE

s

E_" E

fP
EE

E

e

FE

RS

E :-

rE

P

Fd2 F,
E FE

EE

Ee

f€

t p,E
€

f

E

e

F

g

.E

rF

P/i u"
E'r

F

B,

b

Ee

F
E

E

F

F
F

E

E

E

E

Eev

E
E

F

€

3EE

€Er

E,

g;

Ec
e;
:ti
FE

E
E

E
E

i-

E

E,

ii

Fd

: .1 :.:

t--

=

E

\
:\

e

6\

'3

A)
\

r\

-{
