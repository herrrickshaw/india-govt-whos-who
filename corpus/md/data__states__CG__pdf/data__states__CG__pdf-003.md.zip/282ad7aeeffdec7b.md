---
doc_id: "282ad7aeeffdec7b"
source_url: "https://agriportal.cg.nic.in/fisheries/RecruitmantRules/Bharti_Niyam_Class_IV.pdf"
ministry: "Agriculture Development and Farmer Welfare and Bio-Technology Department, Chhattisgarh"
title: "देखें"
date: ""
pages: 8
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "13150194316ae0ef"
---

<!-- page 1 -->

भाग] ] छत्तीसगढ़ राजपत्र, दिनांक 7 मई 2070 ह। 463
I oom
zege, fetie 29 ard 20:0

कमांक एफ i-:6/2009/362e.— ana @ संविधान के अनुच्छेद 309 के परन्तुक

द्वारा प्रदत्त शक्तियों को प्रयोग में लाते डुए, छत्तीसगढ़ के राज्यपाल, एतदूद्वारा, मत्स्योद्योग

संचालनालय में चतुर्थ श्रेणी सेवा की भर्ती के तरीके तथा विस्तार के विनियमन ढेवु निम्नलिखित
नियम बनाते हैँ, अर्थात्‌ ः-
{ नियम

हट संक्षिप्त नाम तथा प्रारंभ - (7) ये नियम "छत्तीसगढ़ मत्स्योद्योग विकास चतुर्थ श्रेणी

सेवा भर्ती नियम, 2009? कहालायेंगे ॥
हे (2) ये नियम राजपत्र में इनके प्रकाशन की तारीख से प्रवृत्त हॉगे ॥
; 2... लागू होना - ये नियम अनुयूची के कॉलम (2) में विनिर्दिष्ट पर्दों पर लागू होंगे।

3... वर्गीकरण तथा वेतनमान इत्यादि - सेवा का वर्गीकरण, सेवा में सम्मिलित पर्दों की
संख्या तथा उससे संलग्न वेतनमान, भर्ती का तरीका, आयु सीमा और अन्य विषय अनुसूची
के कॉलम (3) से (2) में अन्तर्विष्ट उपबर्न्धों के अनुसार होंगे।

| 4... आरक्षण - () अनुसूचित जातियों, अनुसूचित जनजातियों और अन्य पिछड़े वर्गो के लिए
आरक्षण - सीधी भर्ती के पर्दों के लिए छत्तीसगक लोक सेवा (अनुसूचित जातियों, अन्नुसूचित
जनजातियों और अन्य पिछड़े वर्गों के लिए आरक्षण) अधिनियम, :994 (. 2' Bel

994) के उपबरनन्‍धों के अनुसार आरक्षण रहेगा।

(2) अनुसूचित जातियों, अनुयूचित जनजातियों के अभ्यर्थियों के लिये udieafer af

है आरक्षण छत्तीसगढ़ सिविल सेवा (पदोन्‍नति) नियम, 2003 के उपबर्न्धों के अनुसार
डोगा।

(3)... महिलाओं के लिए आरक्षण, - महिला अभ्यार्थियाँ के लिए आरक्षण छत्तीसगढ़
सिविल सेवा (लोक सेवा एवं पदो में महिलाओं की नियुक्ति के लिए विशेष उपबंध)
नियम, :997 & sucet के अनुसार होगा।

5. च्यावृत्ति - इन नियर्मो में की कोई भी बात, अनुसूचित जातियों, अनुसूचित जनजातियों
और अन्य पिछड़े वर्गों, भूतपूर्व सैनिकों, ऐसे शासकीय कर्मचारी की, जिसकी मृत्यु सेवावधि के
दौरान हुई हो, के कूटुम्ब के किसी एक सदस्य को अनुकम्पा नियुक्ति, विकलांग व्यक्तियों
तथा अन्य व्यक्तियों जो अन्य श्रेणियाँ से संबंधित हो, आरक्षण तथा शियिलीकरण को प्रभावित
नहीं करेगी तथा राज्य सरकार द्वारा इस संबंध में समय समय पर जारी किए गए आदेशों

; या बनाये गये नियमों के अनुसार विनियमित छोगी।
6. निरंसन तथा व्यावृत्ति - इन नियर्मो के तत्थानी और इनके प्रारंभ होने के ठीक पूर्व प्रवृत्त
समस्त नियम, इन नियर्मो के अंतर्गत आने वाले विषर्यों के संबंध में एतदद्वारा निरसित
; किये जाते है,
परन्तु इस प्रकार ज्ञरसित नियर्मों के अधीन किया गया कोई भी आदेश या की गई
कोई भी कार्रवाई इन नियर्मो के तत्थानी उपबंधों के अधीन दिया गया आदेश या की णई
कार्रवाई समझी ज़ायेगी।
छत्तीसगढ़ के राज्यपाल के नाम से तथा आदेशानुसार,
याकुब खेस्स, उप-सचिव.

<!-- page 2 -->

464 : wing usr, feaias 7 4g 2070 Ss ee ee लिए का (wi
ive f pire tHPLE HE | -
mH | हा
हि | /
; eeree | | BeREEH leg
£ tk GEE 7 Hr “Bebe be Ee eH ‘ 7
' FEE  REEREE FE ke

5 rH TE RRR RARER
ee
: a THe FE |
E ~ (EE se Webleg है EER FEE ४
K et ee eee

<!-- page 3 -->

rT J छत्तीसगढ़ wo, fear 7 4g 2070 2S _ 4S
Raipur, the 29th March 20L0
No. F |-6/2009/36/Estt.—In exercise of the powers conferred by the proviso to Article 309 of the Consti-
tution of India, the Governor of Chhattisgarh, hereby makes the following rules to regulate the method and scope of
recruitment to the class-IV service in the Directorate of Fisheries, namely;-
RULE
i Short title and Commencement- () These rules may be called Chhattisgarh Fisheries Development class-[V
service Recruitment Rules, 2009. ¥
(2) ‘These rules shall come into force with effect from the date of their publication in the Official Gazette.
2, Application :- These rules shall apply to the posts specified in column (2) of the Schedule.
3. Classification and Scale of Pay etc. - The classification of the Service, the number of posts included in the
- Service, and the scale of pay attached thereto, method of recruitment, age limit and other matters shall be in
: accordance with the provisions contained in column (3) to (I2) of the Schedule. के
4. Reservation - (I) Reservation for Scheduled Castes, Scheduled Tribes and Other Backward Classes. - Reser-
vation for the posts of direct recruitment shall be made in accordance with the provisions of the Chhattisgarh
Public Service (Reservation for Scheduled Castes, Scheduled Tribes and Other Backward Classes) Act, 994
(No. 2! of 994).
(2) Reservation in promotion shall be made for the candidates of Scheduled Castes, Scheduled Tribes in
accordance with the provisions of Chhattisgarh Civil Service (Promotion) Rules, 2003.
(3) Reservation for women,- Reservation for women candidates shall be made in accordance with the
provisions of the Chhattisgarh Civil Service (Special Provision for Appointment of Women in
Public Service and Posts) Rules, !997_

5. Saving.- Nothing in these rules shall effect reservation and relaxation provided for the Scheduled Castes and
Scheduled Tribes and Other Backward Classes, for Ex-serviceman compassionatory appointment to the one
member of the family of the Government employees, who dies during service period, handicapped persons
and other persons belonging to other categories and shall be regulated in accordance with the rules made or
orders issued by the State Government from time to time in this regard.

- 6 Repeal and Saying - All rules corresponding to these rules and in force immediately before the commence-
ment of these rules are herby repealed in respect of matters covered by these rules:
मी Provided that any order made or any action taken under rules so repealed shall be deemca to have
' been made or taken under the corresponding provisions of these rules.
By order and in the name of the Governor of Chhattisgarh,
YACUB KHESS, Deputy Secretary.

<!-- page 4 -->

PS Se 2000. लय
ge a one
a, aah ak | का काया न
or! |. |
! i $26_8:,, lee le fdas
है 28488 22 (6 8 किला नि
ce~SSuge ses a) | हि {7 7 ET
se 8,88 E | ;
ee ere if ee acl ey ला
gaazcigeis |. a a te | ld id *
222 63 8 688 Bf ee pn TT TG
4852४ 2 869 | ४ cP a
bie el 3 १6 «०8658 i Lo
BE a pean
zi! apodi oe la 8 है? १३॥ है? 5३ ४
us divide 2 EH Hiedis
rig 22222 246 [° [os "Fae" Fas de oy
aa f (4258 ००8
| | ig 275 3066 i iid
eB 238 “६ ड़ तक det
oO esteste. ee : |
n sEgckees es | i i
Sg RD hay जी प्लीनिज अल
हैं। 88275 | 6
ee bode
gE : RH OO
मर toll
: + ipld@e 3
: ois ee ci isist
2 é ej; [é
2 leg f i fio है है
डंडे alle |. 8 जम ३ ६
2 3 ZO < ce
ae ride b he F al |

<!-- page 5 -->

भाग ३] जो आह न ie oe
ee
tied re
is
ERE ie
[eee न
SyazieG2 8 ii i ।।
ipaie a |
pes tit i
En 4
|haS ja 8
zit | ॥ |॥ -
a] | TER
redisin, | |,
PEG 4 i
23 888 8 223 *
et
eee |
| S
2
2 a2 |;
2 Hi |
ae He [+ fe |

<!-- page 6 -->

468 = ellen छत्तीसगढ़ राजपत्र, दिनांक 7 ug 200 eee sb =e ae
राजस्व विभाग
कार्यालय, कलेक्टर, जिला महासमुन्द, छत्तीसगढ़ एवं पदेन उप-सचिव, छत्तीसगढ़ शासन, राजस्व विभाग
महासमुन्द, दिनांक 3] दिसम्बर 2009
क्रमांक/9/क/अ.वि.अ./भू-अर्जन/3 अ/82/2008-09.-- चूंकि राज्य शासन को यह प्रतीत होता है कि इससे संलग्न अनुसूची के
खाने () से (4) में वर्णित भूमि की अनुसूची के खाने (6) में उसके सामने दिये गये सार्वजनिक प्रयोजन के लिये आवश्यकता है अथवा
आवश्यकता पड़ने की संभावना है. अत: भू-अर्जन अधिनियम, i894 (amie 7 a i894) at aT 4 at sUTE (7) & Saal &
अनुसार इसके द्वारा सभी संबंधित व्यक्तियों को इस आशय की सूचना दी जाती है कि राज्य शासन, इसके द्वारा, इस अनुसूची के खाने (5) में
उल्लेखित अधिकारी को उक्त भूमि के संबंध में उक्त धारा 4 की उपधारा (2) द्वार दी गई शक्तियों का प्रयोग करने के लिए प्राधिकृत करता है :-- हे
अनुसूची पे
भूमि का वर्णन a धारा 4 की उपधारा (2) सार्वजनिक प्रयोजन
जिला तहसील नगर/ग्राम लगभग क्षेत्रफल के द्वारा का वर्णन
(हेक्टेयर में) प्राधिकृत अधिकारी
q) (2) (3) (4) (s) (6)
महासमुन्द पिथौरा 'परसवानी 0.96 कार्यपालन अभियंता, जल संसाधन लोवर जोंक बैराज
प. ह. ने. 44 संभाग, महासमुन्द छ. ग. योजना पहुंच मार्ग एवं
बंड लाईन निर्माण.
भूमि का नक्शा (प्लान) का निरीक्षण भू-अर्जन अधिकारी, पिथौरा के कार्यालय में किया जा सकता है.
छतीसगढ़ के राज्यपाल के नाम से तथा आदेशानुसार,
निहारिका बारिक सिंह, कलेक्टर एवं पदेन उप-सचिव.
कार्यालय, कलेक्टर, जिला कोरबा, छत्तीसगढ़ एवं पदेन उप-सचिव, छत्तीसगढ़ शासन, राजस्व विभाग
कोरबा, दिनांक 9 अप्रैल 200
क्रमांक क/ भू-अर्जन/04.--चूंकि राज्य शासन को यह प्रतोत होता है कि इस्ससे संलग्न अनुसूची के खाने () से (4) में वर्णित भूमि
की अनुसूची के खाने (6) में उसके सामने दिये गये सार्वजनिक प्रयोजन के लिये आवश्यकता है अथवा आवश्यकता पड़ने की संभावना है. अतः
भू-अर्जन अधिनियम, i894 Grate । सन्‌ 7894) संशोधित भू-अर्जन अधिनियम, i984 et धारा 4 की उपधारा (१) के उपबन्धों के अनुसार मु
इसके द्वारा सभी संबंधित व्यक्तियों को इस आशय कौ सूचना दी जाती है कि राज्य शासन, इसके द्वारा, इस अनुसूची के खाने (5५) में उल्लेखित
अधिकारी को उक्त भूमि के संबंध में उक्त धारा 4 की उपथारा (2) द्वारा दी गई शक्तियों का प्रयोग करने के लिए प्राधिकृत करता है :-- ६
अनुसूची
भूमि का वर्णन धारा 4 की उपधारा (2) सार्वजनिक प्रयोजन
जिला तहसील नगए/ग्राम लगभग क्षेत्रफल के द्वारा का वर्णन
: (हेक्टेयर में ) प्राधिकृत अधिकारी
q) (22 (3) (4) (५) (6)
कोरबा करतला ढिटोरी 0.08 कार्यपालय अभियंता, मिनरीमाह करेंपाली माइनर set
ये. ह. न. 08 बांगो नहर संभाग क्र. 2, चांपा. निर्माण.
भूमि का नक्शा (प्लान) का निरीक्षण भू-अर्जन अधिकारी, हसदेव परियोजना, जांजगीर के कार्यालय में किया जा सकता है.

<!-- page 7 -->

; “बिजनेस पोस्ट के अन्तर्गत डाक atte 'पंजीयन क्रमांक
शुल्क के नगद भुगतान (बिना डाक Sn % “aaheare/37/09/200-2022.”
,  « टिकट) के प्रेषण हेतु अनुमत. क्रमांक क ८22 जे), फ
जी. 2-22-छत्तीसगढ़ गजट/38 सि. से. # रे
भिलाई, ferie 30-5-200.” RY ४ ५
रे = g Ze §
छत्तीसगढ़ ठ राजपत्र
( असाधारण )
प्राधिकार से प्रकाशित
क्रमांक 469 ] रायपुर, शनिवार, दिनांक 7 जुलाई 202--आपाढ़ 6, शक 934
कृषि (मछली पालन) विभाग
‘ मंत्रालय, दाऊ कल्याण सिंह भवन, रायपुर
रायपुर, दिनांक 7जुलाई 202 , . *
अधिसूचना
क्रमांक एफ-4-/202/36.--भारत के संविधान के अनुच्छेद 309 के परन्तुक द्वाग प्रदत्त शक्तियों को प्रयोग में लाते हुये, छत्तीसगढ़
के राज्यपाल, एतद्द्वारा, छत्तीसगढ़ मत्स्योद्योग विकास चतुर्थ श्रेणी सेवा भर्ती नियम, 2009 में निम्नलिखित संशोधन करते हैं. यह अधिसूचना
feaies 07 ora, 2072 8 at वर्ष की कालावधि के लिये प्रवृत्त रहेगी, अर्थात्‌ :--
संशोधन
उक्त नियमों की अनुसूची में,--
सरल क्रमांक-2 के कॉलम (4) में, शब्द “चतुर्थ श्रेणी” के पश्चात्‌ शब्द “जिला स्तरीय" जोड़ा जाय.
' 337

<!-- page 8 -->

338 छत्तीसगढ़ ws, feria 7 Yen 2072 कर zc
eee
Raipur, the 7th July 202 Mes sic:
"NOTIFICATION me
* No. F-4-/202/36.—In exercise of the powers conferred by the proviso to Article 309 of the Constitution of .
India, the Governor of Chhattisgarh, hereby, makes the following amendment in the Chhattisgarh Fisheries Develop- |
ment Department Class-IV Services Recruitment Rules, 2009. This Notification shall come into force from the date of
I7th January, 202, for a period of two years, namely :— %
४ AMENDMENT
In Schedule I of the said rules,— i
In column (4) of serial number 2, after the words “Class-IV” the words “District Level” shall be added.
छत्तीसगढ़ के राज्यपाल के नाम से तथा आदेशानुसार,
पारसनाथ राम, उप-सचिव.
की ee न न
संचालक, मुद्रण तथा लेखद सामग्री, छद्तौसयढ़ द्वाउ कासकोब क्षेत्रीय मुद्रणालद, दकनापर्माद से मुझव ता अ्रकातित-- 2०72.
