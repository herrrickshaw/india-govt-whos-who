---
doc_id: "9add4ee0f209fd5b"
source_url: "https://eproc.cgstate.gov.in/CHEPS/html/chips/Manual_Offline_Tenders_v.1.0.pdf?OWASP_CSRFTOKEN=E4HK-JCXS-X3TG-8342-RHRB-K5EO-6G1M-J153"
ministry: "Integrated e-Procurement Portal, Chhattisgarh"
title: "Uploading Manual / Offline Tenders"
date: ""
pages: 23
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2bb4d7568f2368f9"
---

<!-- page 1 -->

User Manual on
Uploading Manual/Offline Tender details

<!-- page 2 -->

Login as
Tender
Creator

<!-- page 3 -->

Click on Tender(s)
 Offline Tender

<!-- page 4 -->

Please fill in all
Tender details as
shown in the screen

<!-- page 5 -->

Click on
SAVE

<!-- page 6 -->

Click on
Attachment

<!-- page 7 -->

Select Appropriate Tender
Document on clicking
BROWSE and then click on
SIGN FILE

<!-- page 8 -->

Select Your
DSC and Click
on OK

<!-- page 9 -->

Click on
Attach/Detach
to upload signed
document

<!-- page 10 -->

Uploaded
document’s link is
available as shown
in screen

<!-- page 11 -->

Click on ADD ROW and
Enter Supporting
Document(s) Required from
Bidders and click on SAVE

<!-- page 12 -->

Click on
Payment

<!-- page 13 -->

Enter Payment
details and
click on SAVE

<!-- page 14 -->

Click on
Evaluation

<!-- page 15 -->

Add Bidders by
entering PAN No.
& Click on SEARCH

<!-- page 16 -->

Verify Bidder’s
Name and Click
on OK to add

<!-- page 17 -->

Enter Quoted/Bid
Value & Remarks
and Click on SAVE

<!-- page 18 -->

Click on REGISTER
NEW BIDDER if
bidder is not already
registered online.

Enter Bidder’s
details and Click
on REGISTER.

<!-- page 19 -->

Enter Quoted/Bid
Value & Remarks
and Click on SAVE

<!-- page 20 -->

Click on SAVE
Also verify Rank
as L1,L2…Ln

<!-- page 21 -->

Click on
Purchase
Order

<!-- page 22 -->

Fill-in all PO
details &
Attachment and
click on SAVE

Click on
CONFIRM

<!-- page 23 -->

Thank You
