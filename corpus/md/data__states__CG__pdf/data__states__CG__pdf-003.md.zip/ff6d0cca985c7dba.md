---
doc_id: "ff6d0cca985c7dba"
source_url: "https://cdn.s3waas.gov.in/s351d92be1c60d1db1d2e5e7a07da55b26/uploads/2021/08/2021080453.pdf"
ministry: "Raigarh"
title: "NGT Order 20.11.2020"
date: ""
pages: 16
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "005220884c6a61eb"
---

<!-- page 1 -->

Item Nos. 02 & 03 Court No, ]
BEFORE THE NATIONAL GREEN TRIBUNAL
PRINCIPAL BENCH, NEW DELHI
Original Application No. 04/208
(M.A. No. 279/208, M.A. No. 858/208 & I.A. No. 382/2020)
WITH
Execution Application No. 05/209
(With report dated 7,.2020)
Shivpal Bhagat & Ors. Applicant(s)
Versus
Union of India & Ors. Respondent(s)
Date of hearing: 20..2020
CORAM: HON’BLE MR. JUSTICE ADARSH KUMAR GOEL, CHAIRPERSON
HON’BLE MR. JUSTICE SHEO KUMAR SINGH, JUDICIAL MEMBER
HON’BLE DR. SATYAWAN SINGH GARBYAL, EXPERT MEMBER
HON’BLE DR. NAGIN NANDA, EXPERT MEMBER
Applicant(s): Mr. Saurabh Sharma, Advocate
Respondent(s): Mr. Kush Sharma, Advocate for CPCB
ORDER
५ The issue for consideration is the remedial action against pollution
caused by the Thermal Power Plants, the coal washeries in Tamnar and
Gharghoda blocks of Raigarh District in Chhattisgarh, including M/s
Jindal Power Limited, M/s Jindal Power and Steel Limited, M/s TRN
Energy Private Limited, M/s Mahavir Energy & Coal Benefaction Limited,
M/s. Hindalco Industries Limited and M/s. Monet Energy Limited, SECL.
The operation of the said units is resulting in contamination of air, water
and land and having adverse impact on the environment and the
habitants. Water and soil have toxic metals having potential for health
व

<!-- page 2 -->

hazard requiring monitoring of emissions, making the polluter
accountable and regulating the polluting activities.
2. The matter has been considered earlier and under direction of this
Tribunal, an Expert Committee furnished its report dated 4.0.209
after visiting the sites and considering earlier reports on the subject. The
Committee considered the mitigation measures required to be adopted by
the Thermal Power Plants and the coal washeries. The Committee found
that the issue of ground water depletion, soil pollution, forest loss and
livelihood loss were required to be addressed for which short term and
long terms measures were suggested. The Tribunal directed remedial
action for dealing with the deficiencies having potential for damage to the
environment. Further direction was to review the existing arrangements
and furnishing a further report. The operative part of directions in the
order dated 27.02.2020 is as follows:
“3. Accordingly, a report dated 74. 70.2079 आवड 9९९7 पिल्व 9५ #९
CPCB on behalf of the Committee on 75.70.2079, 776 एकाफाएं[ट2ट
visited various sites and considered the earlier reports, including
maps and the data of air quality as well as water pollution. The
Committee then considered the mitigation measures prescribed and
their current status including installation of Electro-Static
Precipitators (ESPs) and Fluidized Gas Desulfurizers (FGDs) in the
Thermal Power Plants. The committee also considered ground water
depletion, soil pollution, forest loss and livelihood loss and after
detailed study of various aspects made following recommendations:
“4, RECOMMENDATIONS:
Based on the above observations, the committee
recommends a set of short-term and long-term measures.
4.l Short-term measures

a. Requiring all coal mines in Raigarh district to
accept fly ash for disposal through OB dump and
back-filling. (Action by respective Coal mine
companies).

b. Given the seriousness of improper fly ash dumping
in low lying areas, and the practical difficulty in
rigorously monitoring the implementation of the
recent SOP in the field, no further disposal of fly

2

<!-- page 3 -->

ash in low-lying areas by TPP/CPP companies to be
permitted and all Gram Panchayats in Raigarh
district to be directed to stop issuing NOCs for the
same.

6. Requiring that whatever coal is being supplied to
JPL and JSPL from Gare Palma IV/2&3 should be
transported through the already existing closed
conveyor belts and no such coal transport should
be allowed via trucks. (Action by SECL).

d. Establishment of monitoring cell by PHED to
monitor water quality being used by the residents
of villages and provide pretreatment facility and
removal of geogenic contaminants and
anthropogenic contaminants before its use as
drinking water. Specifically. the quality of water
treatment in the mine-supported water supply
system in village Kondkhel needs to be ensured by
PHED as per drinking water norms.

e. Installation of adequate number of CCTV and
CAAQM stations in coal mining area. Proper
records under CCTV coverage shall be maintained
by coal mines to ensure movement of covered
trucks loaded with coals and regular and
comprehensive operation of sprinklers in coal zone,
stockyard and all mine roads. CAAQMS shall be
connected to CECB/CPCB_ server, and also
displayed on the mine gates for public information.
(Action by respective coal mine companies).

f. Proper repairing and maintenance of roads both
inside and outside the mine area to ensure smooth
movement of trucks and other load carrying
vehicles. (Action by Public Works Department and
respective mining companies). Indian Railways to
be directed to submit a time-bound action plan for
commissioning of the railway line in Tamnar and
Gharghoda blocks to ensure all coal transportation
by rail.

g. Proper and free health care facilities with
multispecialty treatment system may be provided
in all coal mine-adjacent villages as per the
recommendations of the committee report of
74.6.2079 का कार एप्राव्वांध कबाता (05 374/2074 CZ)
case. (Action by respective coal mine companies).

h. Strict vigilance by MOEFCC for green belt
development compliance as per EC conditions.

i. We also recommend that no further conversion
of UG mines to Open Cast mines be permitted in
Tamnar and Gharghoda, keeping in mind the
environmental costs in terms forest loss, major

3

<!-- page 4 -->

noncompliance in pollution control and social cost
(rehabilitation).
4.2 Long-term measures

a) Based on evidence summarised above, the
committee is of the opinion that the Tamnar-
Gharghoda block region is close to exceeding
its environmental carrying capacity. However.
the precise extent of current environmental load
and the likely impacts of future mining and
industrial activities has to be worked out through
a detailed and comprehensive environmental
load carrying capacity study, to be carried
out by a reputed environmental research
institute or a consortium of such institutes
over a 24-month period.

i) The study must cover dimensions of air pollution
(especially PM2.5), water pollution and ground and
surface water depletion, soil contamination, forest
and biodiversity loss, and social and health
impacts.

ii) Moreover, given the geography of the region,
the study must assess the carrying capacity
separately for two different subregions: the
northern Tamnar (coal mining related) block
and Gharghoda block. Moreover, since Chhal
open cast mine located in southern
Dharamjaigarh block is located on the bank of
Mand River and therefore in an eco-sensitive
zone, a baseline study of this region may also
be carried out. The southern Tamnar subregion
has already been studied for environmental
load carrying capacity by IIT Kharagpur (report
submitted to CECB in 208) and it has already
recommended strict regulation of any further
industrial development in particular parts of the
sub-region through a high-level committee.

ili) Mode of commissioning of this study may
please be decided by the Hon'ble NGT, and
necessary directions may please be issued
accordingly.

b) To reduce the pollution and other impacts caused
by road transport of coal and other minerals,
directions may be issued that coal transport by road
from coal mines or to thermal power plants in these two
blocks will be permitted only for l year, after which
transport must be done by rail or closed conveyor belt
only.

c) Condition of greenbelt development may be
incorporated at TOR stage of EC application to ensure

4

<!-- page 5 -->

that greenbelt work shall be in place at the time of final
presentation for obtaining EC, which shall be verified by
MOEFCC. Further, while granting TOR, EAC should
specify the location of the greenbelt to provide buffer
between coal mine and human settlements, and specify
a sufficient width of the greenbelt for the same.

d) Ministry of Coal be directed to include the necessary
provisions to ensure the acceptance of fly ash in coal
mines for disposal through OB dump and back-filling as
per fly ash notification of 2009.”

4. We find that the recommendations are based on relevant
studies and need to be implemented by the concerned power plants
and mines in the area for protection of environment and the public
health and the environmental rule of law.
5. The applicants have, while broadly expressing satisfaction
with the report, made certain suggestions. First suggestion of the
applicants is that carrying capacity assessment must be
expeditiously carried out and till such assessment is done,
expansion and new projects should be only after thorough
evaluation. Further suggestion is that there should be a mechanism
to oversee the remedial measures, including oversight of health
mitigation measures suggested by the Committee.
6. We are of the view that since serious deficiencies have been
found and there is potential for damage to the environment as
observed in the report, the ‘Precautionary’ and ‘Sustainable
Development’ principles require that any further expansion or new
projects in the area should be allowed after thorough evaluation only
and mechanism for remedial measures should be in place, including
oversight of measures for health mitigation. The Committee already
constituted in terms of order of this Tribunal dated 22.07.209 will
act as an Oversight Committee. The nodal agency for the purpose
will be the CPCB. Meeting of the Committee may be held atleast once
in two months or at such interval as may be decided by the
Committee. Mitigation measures for health issues may be overseen
by the Principal Secretary, Health, Govt. of Chhattisgarh. For this
purpose, the existing arrangements in the local areas may be
reviewed and further strengthened to meet the requirements. The
Principal Secretary, Health, Govt. of Chhattisgarh will be at liberty to
issue appropriate directions to the concerned project proponents also
for their initiatives out of CSR funds. The Committee may give a
status report on the issue as on 30.06.2020 by 75.07.2020 #9 €-
mail at judicial-ngt@gov.in. The Oversight Committee may issue
appropriate directions to the project proponents for other remedial
measures.
Fs The above report may be looked into and acted upon by the
Ministry of Coal as well as MoEF&CC for such further action as may
be necessary.”

5

<!-- page 6 -->

3. Accordingly, report has been filed by the CPCB on 7.,2020
giving the status of compliance of the recommendations in a tabular form
as follows:

“« fe. Orders of the Hon’ble NGT from | Compliance Review Status

No. | recommendations in the report, | ०97 09. 74.2020
November 20i9

हि |

@) | Requiring all coal mines in Raigarh | Three SECL mines are found
district to accept fly ash for| complying. Letters were issued
disposal through OB dump and| to SECL Chaal OC, Monnet
back-filling. (Action by respective | Ispat, HINDALCO Limited and
Coal mine companies). M/s Ambuja Cement Ltd. M/s

HINDALCO mines informed
about no OB dump because of
continuous back filling of mined
area with OB as per Approved
mining plan. M/s Monnet Ispat
Mines has been taken over by
SECL. No response received
from M/s Ambuja Cement
Limited. More over CEA vide its
letter dated 4.02.2020 has
informed about declaration of
abandoned mines on
recommendation of task force.
The list includes 24 abandoned
OC mines of Chhattisgarh to be
used for filling of fly ash
generated from TPP. Process of
allocation no of these mines to
TPP of Chhattisgarh is under
taken by CECB and is on
advance stage. Annexure-IT

b) | Given the seriousness of improper | District Collector of Raigarh has
fly ash dumping in low lying | issued letter to concerned
areas, and the practical difficulty | department for directing all
in rigorously monitoring the| gram panchayats for not
implementation of the recent SOP | issuing any NOC to use low
in the field, no further disposal of | lying area for disposal of Fly
fly ash in low-lying areas by| Ash. During visit of the
TPP/CPP companies to be) committee, disposal of fly ash
permitted and all Gram) in low lying area was not
Panchayats in Raigarh district to | observed. Annexure-IT
be directed to stop issuing NOCs
for the same.

०) Requiring that whatever coal is| Based on the observation of
being supplied to JPL and JSPL| CECB, RO, Raigarh, it seems to
from Gare Palma IV/2&3 should | be complied.
be transported through the already
existing closed conveyor belts and
no such coal transport should be
allowed via trucks. (Action by
SECL).

d) | Establishment of monitoring cell by | The representative of PHED
PHED to monitor water quality| present during visit of the
being used by the residents of | committee has informed that
villages and provide pre _—| PHED established water testing

6

<!-- page 7 -->

treatment facility and removal of | laboratory at Gharghoda and
geogenic contaminants च्तावे Raigarh for testing of drinking
anthropogenic contaminants before | water quality of the area.
its use as drinking water.| Moreover 2 hand pumps, 02
Specifically, the quality of water | Power pumps and 0I tap water
treatment in the mine-supported| supply have been provided in
water supply system in village| Kondkel area. {(Annexure-IV)
Kondkhel needs to be ensured by | The residents of the village has
PHED as per drinking water| informed about frequent
norms. lowering of ground water table
due to UG mining activity.
Representative of the PHED
was also in concurrence with
the observation of the villagers.
In order to ensure regular and
good water quality to villagers
the committee has directed M/s
Hindalco to provide tape water
in village and ensure quality of
water in coordination with
PHED Raigarh.

e) | Installation of adequate number of | - As per field report by CECB,
CCTV and CAAOQM stations in coal | RO, Raigarh it seems that CCTV
mining area. Proper records under| has been installed by M/s
CCTV coverage shail be | HINDALCO industries, SECL
maintained by coal mines to| Gare Palma IV/2 & 3, SECL
ensure movement of covered | Chhal. SECL Gare Palma IV/.
trucks loaded with coals and_| At the time of visit M/s Monnet
regular and comprehensive | Ispat Mines were not found
operation of sprinklers in coal| operational.
zone, stockyard and all mine
roads. CAAQMS shall be|- In case of installation of
connected to CECB/CPCB server,| CAAQMS all the mines have
and also displayed on the mine | informed that as per mandatory
gates for public information. | conditions of EC and CTO fixed
(Action by respective coal mine | location ambient air Quality
companies). monitoring is being conducted

by the units and reports are
regularly submitted 0
| : _ MoEF&CC and CECB.

A Proper repairing and maintenance |- Letter issued to PS, PWD,
of roads both inside and outside | Si/03, Mahanadi Bhawan,
the mine area to ensure smooth| Raipur by this office vide
movement of trucks and other load | number RDB/ NGTOA-
carrying vehicles. (Action by Public | 704/2078/553 dated
Works Department and respective | 07.09.2020. EE PWD was
mining companies). Indian | present before committee to
Railways to be directed to submit | appraise the status of PWD
a time-bound action plan for| roads in the area. Committee
commissioning of the railway line | has observed very bad road
in Tamnar and Gharghoda blocks | condition in Tamnar and
to ensure all coal transportation by | Gharghoda area which seems
rail. to be one of the major factors

for deterioration of ambient air

quality. EE PWD Sh. Khamra

has informed the committee

about requirement of immediate

construction of approximate I

Km CC road (Raigarh to

Dharmajay Garh about 76 Km

= and Punjipatra to Milupara |
7

<!-- page 8 -->

about 35 Km} but due to budget
constraint the work is pending
since last several years, More
over SECL has paid an amount
of 42 Crore to Raigarh PWD for
construction of 49 क्ाछ, ग्रा
wide tar road from Gharghoda
to Jampali in compliance of
Hon'ble NGT order.

- IRCON International Limited,
in reference to our letter dated
07.09.2020 has informed that
44 Km Railway line work from
Kharsia-
GharghodaKorichhapar has
been completed and started
transportation of coal. Work for
4. km rail line from
Gharghodabhalumuda- Gare
Palma will be completed by
June 202. Rail line work from
Karichhapar Kurumkela-
Dharamjaygarh will be
completed by December 2020.
IRCON has to construct 05
numbers of coal siding in
Tamnar and Gharghoda area
for — increasing rail coal
transportation. As on date of
committee visit IRCON has
completed 03 coal siding and
made 0I siding operational, 02
more siding will be made
operational by December 2020.
As informed by the
representative of Indian
Railway rest 02 sidings shall
be completed by March 202].
(Annexure-V) Compliance in
Progress

g) | Proper and free health care | Mitigation measure for health
facilities with — multispecialty | issues is to be overseen by the
treatment system may be provided | Principal Secretary, _ health,
in all coal mineadjacent villages as | Govt. of Chhattisgarh. For this
per the recommendations of the | purpose, the existing
committee report of 74.6.2079 in| arrangements in the local areas
the Dukalu Ram (OA 34/20I4)\ may be reviewed and further
CZ) case. (Action by respective coal| strengthened to meet the
mine companies). requirements. The Principal

Secretary Health, Govt. of
Chhattisgarh is at liberty to
issue appropriate directions to
the concerned project
proponents also for their
initiatives out of CSR funds.

h) | Strict vigilance by MOEF&CC for) MoEF&CC has started close
green belt development compliance | monitoring for green belt
as per EC conditions development in all coal mines.

Compliance in progress.
[कि
8

<!-- page 9 -->

(further conversion of UG mines to | MoEF&CC (IA-Coal) for
Open Cast mines be permitted in| implementation of restriction on
Tamnar and Gharghoda, keeping | conversion of UG coal mines to
in mind the environmental costs in| OC coal mines in Tamnar and
terms forest loss, —_major| Garghoda area of District
noncompliance in pollution control | Raigarh.

and social cost{rehabilitation). |

है LONG TERM MEASURES

a) | Commissioning a detailed and | The matter was discussed with
comprehensive environmental load | CPCB HO and got advised to
carrying capacity study (as| include the project in State EC
mentioned in NGT order), to be| fund as defined by Hon’ble
carried out by a reputed| NGT. In order of this proposal
environmental research institute | for the same has been prepared
over a 24 month period. by CECB and submitted to
Mode of commissioning of this| CPCB for compilation of all
study may please be decided by | project and submission before
the Hon’ble NGT and necessary) Hon’ble NGT. Annexure-VI
directions may please be issued | Compliance in progress.
accordingly

b) | To reduce the pollution and other| As per report obtained from
impacts caused by road transport | SECL it is evident 35% increase
of coal and other minerals) in daily average dispatch by
directions may be issued that coal | rail in comparison to the FY-
transport by road from coal mines | 209-20 after construction of
or to thermal power plants in these | new rail line between Kharsia-
two blocks will be permitted only | Gharghoda- Korichhapar. Coal
for l year, after which transport | dispatch from  Korichhapar
must be done by rail of closed| railway siding commenced in
conveyor belt. the FY209-20. It is assumed

that coal transport by rail may
increase by 50% in addition to
earlier transport in rail by
December 2020.

० Condition of green belt) Copy of Hon’ble NGT order
development may be incorporated | dated 27.02.2020 has been
at TOR stage of EC application to | sent to IA-Coal on 48.09.2020
ensure that green belt work shall | for further necessary action by
be in place at the time of final) MoEF&CC.
presentation for obtaining EC,
which shall be verified by
MoEF&CC. Further while granting
TOR, EAC should specify the
location of the green belt to provide
buffer between coal mine and
human settlements and specify
sufficient width of the green belt
for the same.

d) | Ministry of coal be directed to| Pursuant upon long
include the necessary provisions to | deliberations by CPCB, Central
ensure the acceptance of fly ash in | Electricity Authority, NTPC and
coal mines for disposal through OB | Ministry of Coal through Task
dump and backfilling as per fly | Force, list of 24 abandoned OC
ash notification of 2009. mines of Chhattisgarh has been

submitted to be used for filling

of fly ash generated from TPP.

Process of allocation of these

mines to TPP of Chhattisgarh is

under taken by CECB and is on

advance stage. ”
9

<!-- page 10 -->

4, The Committee has also made field observations and
recommendations as follows:

“FIELD OBSERVATIONS:

i. Pursuant upon long deliberations by CPCB, Central Electricity
Authority, NTPC and Ministry of Coal through Task Force, list of
24 abandoned OC mines of Chhattisgarh has been submitted to
be used for filling of fly ash generated from TPP. Member
Secretary CECB has informed about considering mine wise
allocation of abandoned coal mines as declared by CEA vide its
letter dated 4.02.2020. The co-operation of SECL is not
satisfactory as many applications of TPP of Tamnar &
Gharghoda area are lying unattended by SECL.

2. District collector, Raigarh has issued letter to concern
departments for directing all gram panchayats for not issuing
any NOC to use low lying area for disposal of Fly ash. During
visit committee has observed restriction on fly ash disposal in
low lying areas particularly in agricultural fields of the villages.

3. In compliance of letter issued by Nodal Officer of the committee
on 07.09.2020 to PS, PHED, Raipur, it was informed that PHED
has established water testing laboratory at Gharghoda and
Raigarh for testing of drinking water quality of the area. PHED,
Raigarh has also established 06 control rooms and circulated
the contact numbers of the concern officers to manage any crisis
of drinking water availability in Raigarh District. In order to
provide proper treatment for removal of any geogenic
contaminants PHED Raigarh has also provided 05 Electrolytic
DE fluoridation (EDF) plants in 03 villages (Pata, Mudagaon,
Saraitola) of Tamnar Block. Moreover 2 hand pumps, 02 Power
pumps and 0I tap water supply have been provided in Kondkel
area. In addition to above PHED, Raigarh has also proposed
drinking water supply scheme (Rs. 270.4 Lakh project cost)
for 0 mining effected villages of Tamnar Block. The details
submitted by PHED, Raigarh was verified in Kondkel Village
and found insufficient with respect to population of the village.
The representative of PHED present during visit of the committee
has informed that PHED has established 04 hand pumps, 04
Power pumps and OI tap water supply have been provided in
Kondkel area. The residents of the village has informed about
frequent lowering of ground water table due to UG mining
activity. Representative of the PHED was also in concurrence
with the observation of the villagers. In order to ensure regular
and good water quality to villagers the committee has directed
M/s Hindalco to provide tape water supply from mine in village
and ensure quality of water in coordination with PHED Raigarh.
M/s Hindalco Coal Mine shall also submit report on quantity of
mine water generation from UG mines to make an assessment
for water supply required from PHED.

व0
