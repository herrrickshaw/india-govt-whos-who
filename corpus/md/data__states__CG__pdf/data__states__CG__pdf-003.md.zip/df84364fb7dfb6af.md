---
doc_id: "df84364fb7dfb6af"
source_url: "https://www.cbda.in/sites/default/files/Guidelines%20for%20sale%20of%20biodiesel%20for%20blending%20with%20HSD%20for%20transportation%20purposes-%20issued%20by%20Director%2C%20Food%2C%20GoCG%20dt.240921.pdf"
ministry: "Chhattisgarh Biofuel Development Authority (CBDA)"
title: "Guidelines for sale of biodiesel for blending with HSD for transportation purposes- issued by Director, Food, GoCG dt.240921.pdf"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e4574c754bbd7e91"
---

<!-- page 1 -->

TATT

ma

mTTETAA

mTTAT

mTOTT

- 2 , qTia Ta

H

g6y -VTAT/2021

Su

3E 7T, f T /09/2021

faot iast feT-AT 2019 fayq7|

I
2019
TR 379THT AT 30 1
2021 PT ZIdICY
2
T H ET TN 3HEAT A
HINTHDIR ETRT

830/TE-AT/TY

TUT-366/2021,

fi

21.06.2021

arferye - i 30 sd7 2019 ufuT7 VI T
ERT TNT GNT
fRT 2 2021 f e T 2 da du (-100) * YTfaei Bg 3Td

(frpT tera)

<!-- page 2 -->

2S62

. cHIC
1.

/TETE-T./2021

,

T

H, TTE AMRa Tyf ge vu. HK.

3. HRE DTZYICT
4
5.

3HE 7T, f&ATB,y 09/2021

3ferÝt, BritHT ar

faHTT, HAICY,

faBTH TRRUT,

<!-- page 3 -->

(-37

hfH

3TE ATgMe t

ATT

aferr

.

t-13039(18) R30.04.

2019ofaa

01
02

03

Ia/RTY ZITHT ATTeTC5VUT FINT VINT 37-119T yHTU YA|
wwwwwe

05
06
07

08
***

09
10
11

HTTTI fTI À GTRI 3IPFTYfET K
