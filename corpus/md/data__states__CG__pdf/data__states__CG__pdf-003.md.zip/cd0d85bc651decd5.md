---
doc_id: "cd0d85bc651decd5"
source_url: "https://www.sldccg.com/wif-for-website/sldccg_act_regulations/23-cercgnaregulations2022mergedcorrigendum.pdf"
ministry: "State Load Despatch Centre (SLDC), Chhattisgarh"
title: ""
date: ""
pages: 60
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e17eefb476fc2578"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

xxxGIDHxxx

सी.जी.-डी.एल.-अ.-15102022-239685
xxxGIDExxx
CG-DL-E-15102022-239685
असाधारण
EXTRAORDINARY
भाग III—खण्ड 4
PART III—Section 4
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 520]
No. 520]

नई दिल्ली, िुक्रवार, अक्तूबर 14, 2022/आज‍वन 22, 1944
NEW DELHI, FRIDAY, OCTOBER 14, 2022/ASVINA 22, 1944

अजधसूचना
नई दिल्ली, 9 अक्तूबर, 2022
फा. सं.&
.—pwfa d] dsUæh; fo|qr fofu;ked vk;ksx ¼varj&jkfT;d ikjs"k.k
ç.kkyh esa la;kstdrk vkSj lkekU; usVodZ igqap½ fofu;e] 2022 ¼blds ckn th,u, fofu;e ds :i esa mfYyf[kr½ dks
fnukad 07-06-2022 dks Hkkjr ds vlk/kkj.k jkti= ¼Hkkx&III] [kaM&4] la-364½ esa çdkf'kr fd;k x;k Fkk]

pwfa d] th,u, fofu;eksa ds fofu;e 1-2 esa mica/k gS fd ;s fofu;e ml rkjh[k ls ço`Ùk gksx
a s ftls vk;ksx }kjk
vf/klwfpr fd;k tk,xk vkSj i`Fkd fofu;eksa ds vkjaHk ds fy, i`Fkd rkjh[ksa fu/kkZfjr dh tk ldrh gSa]
vkSj vc] vr,o] ;g vf/klwfpr fd;k tkrk gS fd%
¼d½ th,u, fofu;e] fofu;e 23 ls 24] 26 ls 36] 37-9] 38] 40] vkSj 43 ds mica/kksa dks NksM+dj fnukad
15-10-2022 ls ço`Ùk gksx
a s ftuds vkjaHk dh rkjh[k i`Fkd :i ls vf/klwfpr dh tk,xhA
¼[k½ la;kstdrk vkSj th,u, ds fy, u, vkosnu vkSj th,u, fofu;eksa ds v/khu muds çlaLdj.k vkSj vuqnku
dks i`Fkd :i ls vf/klwfpr dh tkus okyh rkjh[k ls ço`Ùk fd;k tk,xkA
¼x½ fo|qr ds vuqlwphdj.k vkSj çs"k.k dk] vxyh vf/klwpuk rd] le;&le; ij ;Fkkla'kksf/kr dsUæh; fo|qr
fofu;ked vk;ksx ¼Hkkjrh; fo|qr fxzM dksM½ fofu;e] 2010 ds mica/kksa ds vuqlkj çR;sd fufnZ"V vkbZ,lVh,l
miHkksäkvksa ¼MhvkbZ,l½ ds nh?kZdkfyd igqap ¼,yVh,½] e/;dkfyd fuckZ/k igqap ¼,eVhvks,½ vkSj vYidkfyd
fuckZ/k igqap ¼,lVhvks,½ vkSj fxzM ds vU; mi;ksxdrkZvksa dh ek=k ij vk/kkfjr gksuk tkjh jgsxkA
¼?k½ vYidkfyd fuckZ/k igqap dk] vxyh vf/klwpuk rd] le;&le; ij ;Fkkla'kksf/kr dsUæh; fo|qr fofu;ked
vk;ksx ¼varj&jkfT;d ikjs"k.k esa fuckZ/k igqap½ fofu;e] 2008 vkSj mlds v/khu tkjh foLr`r fØ;kfof/k ds v/khu
vuqnku fd;k tkuk tkjh jgsxkA

6982 GI/2022

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

¼³½ varj&jkfT;d ikjs"k.k çHkkjksa vkSj gkfu;ksa dh fcfyax] laxzg.k vkSj laforj.k dk] vxyh vf/klwpuk rd]
dsUæh; fo|qr fofu;ked vk;ksx ¼varj&jkfT;d ikjs"k.k çHkkjksa vkSj gkfu;ksa dh 'ks;fjax½ fofu;e] 2020 ds mica/kksa
ds vuqlkj çR;sd fufnZ"V vkbZ,lVh,l miHkksäkvksa ¼MhvkbZ,l½ ds nh?kZdkfyd igqap ¼,yVh,½] e/;dkfyd fuckZ/k
igqap ¼,eVhvks,½ vkSj vYidkfyd fuckZ/k igqap ¼,lVhvks,½ vkSj fxzM ds vU; mi;ksxdrkZvksa dh ek=k ij vk/kkfjr
gksuk tkjh jgsxkA

gjçhr flag çqFkh, lfpo
[जवज्ञापन-III/4/असा./342/2022-23]

CENTRAL ELECTRICITY REGULATORY COMMISSION
NOTIFICATION
New Delhi, the 9th October, 2022
F.No. L-1/261/2021/CERC.—Whereas, the Central Electricity Regulatory Commission (Connectivity and
General Network Access to the inter-State Transmission System) Regulations, 2022 (hereinafter GNA Regulations)
was, on 07.06.2022, published in the Gazette of India Extraordinary (Part-III, Section-4, No. 364),
Whereas, the Regulation 1.2 of the GNA regulations provides that the regulations shall come into force from
the date to be notified by the Commission and different dates may be appointed for commencement of different
regulations,
And now, therefore, it is notified that:
(a) The GNA Regulations shall come into operation with effect from 15.10.2022 except the provisions of
Regulations 23 to 24, 26 to 36, 37.9, 38, 40, and 43, whose date of commencement shall be notified
separately.
(b) Fresh Applications for Connectivity and GNA and their processing and grant under GNA Regulations
shall be made effective from a date to be notified separately.
(c) Scheduling and Despatch of electricity shall continue to be based on the quantum of Long-Term
Access (LTA), Medium-Term Open Access (MTOA) and Short-Term Open Access (STOA) of each of the
Designated ISTS Customers (DICs) and other users of the grid in accordance with the provisions of the
Central Electricity Regulatory Commission (Indian Electricity Grid Code) Regulations, 2010, as amended
from time to time, till further notification.
(d) STOA shall continue to be granted under the Central Electricity Regulatory Commission (Open Access
in inter-State transmission) Regulations, 2008, as amended from time to time and the Detailed Procedures
issued thereunder, till further notification.
(e) Billing, Collection and Disbursement of the inter-State Transmission Charges and Losses shall continue
to be based on the quantum of Long-Term Access (LTA), Medium-Term Open Access (MTOA) and ShortTerm Open Access (STOA) of each of the DICs and other users of the grid in accordance with the
provisions of the Central Electricity Regulatory Commission (Sharing of inter-State Transmission Charges
and Losses) Regulations, 2020 till further notification.
HARPREET SINGH PRUTHI, Secy.

[ADVT.-III/4/Exty./342/2022-23]

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ KUMAR VERMA

Digitally signed by MANOJ KUMAR VERMA
Date: 2022.10.15 16:33:10 +05'30'

<!-- page 3 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-20072022-237375
xxxGIDHxxx
CG-DL-E-20072022-237375
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग III—खण्ड 4
PART III—Section 4
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं.

364]

No. 364]

नई दिल्ली, मंगलवार, िुलाई 19, 2022/आषाढ़ 28, 1944
NEW DELHI, TUESDAY, JULY 19, 2022/ASHADHA 28, 1944

ubZ fnYyh] 7 twu] 2022
.—pwfa d lkekU; usVodZ igqap ds ek/;e ls varj&jkfT;d ikjs"k.k ç.kkyh ds
mi;ksx ds fy, vuqKfIr/kkfj;ksa ;k mRiknu daifu;ksa ;k miHkksäkvksa dks HksnHkko jfgr fuckZ/k igqap dks lqxe cukus ds fy,
fofu;ked <kapk çnku djuk vkSj bl fo"k; ij fofu;eksa dks lesfdr djuk vko';d gS] bls ,rn~ }kjk fuEukuqlkj
fofufnZ"V fd;k x;k gS%

dsUæh; fo|qr fofu;ked vk;ksx] fo|qr vf/kfu;e] 2003 dh /kkjk 79 dh mi&/kkjk ¼1½ ds [kaM ¼x½ vkSj /kkjk 40
ds [kaM ¼x½] /kkjk 38 dh mi&/kkjk ¼2½ ds [kaM ¼?k½] /kkjk 2 ds [kaM ¼47½ ds lkFk ifBr /kkjk 178 dh mi&/kkjk ¼2½ ds [kaM
¼;³½ vkSj /kkjk 178 dh mi&/kkjk ¼1½ vkSj bl fufeÙk vU; lHkh leFkZdkjh 'kfä;ksa dk ç;ksx djrs gq, vkSj iwoZ çdk'ku
ds i'pkr~ fuEufyf[kr fofu;e cukrk gS] vFkkZr~%&

1.

bu fofu;eksa dk uke dsUæh; fo|qr fofu;ked vk;ksx ¼varj&jkfT;d ikjs"k.k iz.kkyh esa la;kstdrk rFkk
lkekU; usVodZ igqap½ fofu;e] 2022 gSA
1.2 ;s fofu;e ml rkjh[k ls izo`Ÿk gksx
a s ftls vk;ksx }kjk vf/klwfpr fd;k tk,xkA
ijarq ;g fd i`Fkd fofu;eksa ds vkjaHk ds fy, i`Fkd rkjh[ksa fu/kkZfjr dh tk ldrh gSaA
1.1

4761 GI/2022

(1)

<!-- page 4 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

2.
2.1 bu fofu;eksa esa] tc rd fd lanHkZ ls vU;Fkk visf{kr u gks%

¼d½ Þvf/kfu;eß ls fo|qr vf/kfu;e] 2003 vfHkçsr gS(
¼[k½ la;kstdrk gsrq vkosnd ¼vkosndks½a ds fy, Þlac) ikjs"k.k ç.kkyhß ;k Þ,Vh,lß ls bu fofu;eksa ds fofu;e
6 ds vuqlkj ;Fkk vo/kkfjr ,Vh,l vfHkçsr gS(
¼x½ Þf}i{kh; laO;ogkjß ls lh/ks ;k O;kikj vuqKfIr/kkjh ds ek/;e ls ;k ikoj ,Dlpst
a ij fofufnZ"V Øsrk vkSj
fofufnZ"V foØsrk ds chp fo|qr ds fofue; ds fy, lkewfgd laO;ogkj ds vykok laO;ogkj vfHkçsr gS (
¼?k½ ÞlhbZ, jftLVªhß ls la;kstdrk ds fy, lhbZ, rduhdh ekudks esa ;Fkk fofufnZ"V mRiknu LVs'kuksa ds
MkVkcsl ds j[kj[kko gsrq jftLVªh vfHkçsr gS(
¼³½ Þla;kstdrk ds fy, lhbZ, rduhdh ekudß ls dsUæh; fo|qr çkf/kdj.k ¼fxzM dks la;kstdrk ds fy,
rduhdh ekud½ fofu;e] 2007 vfHkçsr gS(
¼p½ ÞfuekZ.k ds fy, lhbZ, rduhdh ekudksßa ls dsUæh; fo|qr çkf/kdj.k ¼fo|qrh; la;a=ksa vkSj fo|qrh; ykbuksa
ds fuekZ.k ds fy, rduhdh ekud½ fofu;e] 2010 vfHkçsr gS(
¼N½ ÞdsUæh; vk;ksxß ls vf/kfu;e dh /kkjk 76 dh mi&/kkjk ¼1½ esa lanfHkZr dsUæh; fo|qr fofu;ked vk;ksx
vfHkçsr gS(
¼t½ ÞdsUæh; ikjs"k.k ;wfVfyVhß ;k ÞlhVh;wß dk ogh vFkZ gksxk tSlk fd vf/kfu;e dh /kkjk 2 dh mi&/kkjk 10
esa ifjHkkf"kr gS(
¼>½ Þlkewfgd laO;ogkjksßa ls fo|qr cktkj fofu;eksa esa ;Fkk ifjHkkf"kr lkewfgd laO;ogkj gS vfHkçsr gS (
¼¥½ Þlapkj fofu;eß ls dsUæh; fo|qr fofu;ked vk;ksx ¼fo|qr ds varj&jkfT;d ikjs"k.k ds fy, lapkj ç.kkyh½
fofuf;e] 2017 vfHkçsr gS(
¼V½ Þla;kstdrkß ls bu fofu;eksa ds vuqlkj varj&jkfT;d ikjs"k.k ç.kkyh ls tqM+us dh fLFkfr vfHkçsr gS (
¼B½ Þla;kstdrk fofu;e] 2009ß ls dsUæh; fo|qr fofu;ked vk;ksx ¼varj&jkfT;d ikjs"k.k esa la;kstdrk]
nh?kZdkfyd igqap vkSj e/;dkfyd igqap fuckZ/k igqap çnku djuk vkSj lac) ekeys½ fofu;e] 2009 vfHkçsr gS (
¼M½ ÞØ‚l c‚MZj fofu;eß ls dsUæh; fo|qr fofu;ked vk;ksx ¼fo|qr dk Ø‚l c‚MZj O;kikj½ fofu;e] 2019
vfHkçsr gS(
¼<½ Þfnolß ls 00-00 cts ls vkjaHk vkSj 24-00 cts ij lekIr gksus okyk fnol vfHkçsr gS(
¼.k½ ÞlefiZr ikjs"k.k ykbuß dk ogh vFkZ gksxk tSlk fd vf/kfu;e dh /kkjk 2 dh mi&/kkjk ¼16½ esa ifjHkkf"kr
gS(
¼r½ ÞMh,l,e fofu;eß ls dsUæh; fo|qr fofu;ked vk;ksx ¼fopyu O;oLFkkiu ra= vkSj lac) ekeys½ fofu;e]
2014 vfHkçsr gS(
¼Fk½ fo|qr ç.kkyh ds laca/k esa ÞÅtkZ HkaMkj.k ç.kkyhß ;k ÞbZ,l,lß ls og lqfo/kk vfHkçsr gS tgk¡ fo|qrh; ÅtkZ]
ÅtkZ ds fdlh Hkh :i esa ifjofrZr gksrh gS ftls HkaMkfjr fd;k tk ldrk gS] vkSj rRi'pkr~ fo|qrh; ÅtkZ esa iqu%
ifjofrZr vkSj fxzM esa okfil var%{ksfir fd;k tk ldrk gS(
¼n½ ÞlkekU; usVodZ igqapß ;k Þth,u,ß ls bu fofu;eksa ds v/khu vkbZ,lVh,l dks vuqnÙk fuckZ/k igqap vfHkçsr
gS(
¼/k½ ÞlkekU; usVodZ igqap vuqnkuxzkghß ;k Þth,u, vuqnkuxzkghß ls og O;fä vfHkçsr gS ftls bu fofu;eksa ds
v/khu th,u, vuqnku fd;k x;k gS ;k th,u, vuqnku fd;k x;k le>k x;k gS(
¼u½ ÞfxzM dksMß ls vf/kfu;e dh /kkjk 79 dh mi&/kkjk ¼1½ ds [kaM ¼t½ ds v/khu dsUæh; vk;ksx }kjk
fofufnZ"V fxzM dksM vfHkçsr gS(
¼i½ Þvarj&jkfT;d ikjs"k.k ç.kkyhß ;k ÞvkbZ,lVh,lß ls vf/kfu;e dh /kkjk 2 dh mi&/kkjk ¼36½ esa ;Fkk
ifjHkkf"kr varj&jkfT;d ikjs"k.k ç.kkyh vfHkçsr gS(
¼Q½ Þvar%jkfT;d bdkbZß ls og O;fä vfHkçsr gS ftldh ehVfjax ;FkkfLFkfr jkT; ikjs"k.k ;wfVfyVh ;k forj.k
vuqKfIr/kkjh }kjk dh tkrh gS] vkSj ÅtkZ ys[kkadu jkT; Hkkj çs"k.k dsUæ ;k bl çdkj fdlh vU; ,tsl
a h }kjk
fd;k tkrk gS(
¼c½ ÞbaVjQsl ehVjß dk ogh vFkZ gksxk tSlk fd dsUæh; fo|qr çkf/kdj.k ¼ehVj dk laLFkkiu vkSj çpkyu½
fofu;e] 2006 esa ifjHkkf"kr gS(

<!-- page 5 -->

[भाग III—खण्ड 4]

¼Hk½

भारत का रािपत्र : असाधारण

3

ÞyhM bZ,l,lß ls fuEufyf[kr vfHkçsr gS
¼i½ bZ,l,l tks ,dy varj&la;kstu fcanq ij vkbZ,lVh,l dks la;kstdrk gsrq vkosnu djus ds fy,
djkj ds ek/;e ls ,d ;k vf/kd bZ,l,l ;k mRiknu LVs'ku ¼LVs'kuks½a }kjk çkf/k—r gS% ;k
¼ii½ vkbZ,lVh,l ls igys ls gh la;kstdrk j[kus okyk bZ,l,l] vkSj ftlds fo|qrh; ç.kkyh ds
ek/;e ls ,d ;k vf/kd bZ,l,l ;k mRiknu LVs'ku ¼LVs'kuks½a }kjk djkj ds ek/;e ls la;kstdrk ekaxh
xbZ gSA
¼e½
ÞyhM mRikndß ls fuEufyf[kr vfHkçsr gS]
¼i½ mRiknu LVs'ku tks ,dy la;kstu fcanq ij vkbZ,lVh,l dks la;kstdrk gsrq vkosnu djus ds fy,
djkj ds ek/;e ls ,d ;k vf/kd mRiknu LVs'ku ¼LVs'kuks½a ;k bZ,l,l ;k }kjk çkf/k—r gS% ;k
¼ii½ vkbZ,lVh,l ls igys ls gh la;kstdrk j[kus okyk mRiknu LVs'ku] vkSj ftlds fo|qrh; ç.kkyh
ds ek/;e ls ,d ;k vf/kd mRiknu LVs'ku ¼LVs'kuks½a ;k bZ,l,l }kjk djkj ds ek/;e ls la;kstdrk
ekaxh xbZ gSA
¼;½
Þjk"Vªh; Hkkj çs"k.k dsUæß ;k Þ,u,yMhlhß ls vf/kfu;e dh /kkjk 26 dh mi&/kkjk ¼1½ ds v/khu LFkkfir
jk"Vªh; Hkkj çs"k.k dsUæ ¼,u,yMhlh½ vfHkçsr gS(
¼dd½ Þjk"Vªh; fuckZ/k igqap jftLVªhß ;k Þ,uvks,vkjß ls bu fofu;eksa ds fofu;e 27 ds v/khu ;Fkk fofufnZ"V
jftLVªh vfHkçsr gS(
¼d[k½ ÞuksMy ,tsl
a hß ls fuEufyf[kr vfHkçsr gS
¼i½ la;kstdrk ;k vkbZ,lVh,l dks th,u, ds fy, ukfer ,tsl
a h tks fd bu fofu;eksa ds fofu;e 3
ls fofu;e 25 vkSj fofu;e 37 ds ç;kstu gsrq dsUæh; ikjs"k.k ;wfVfyVh gksxh(
¼ii½ f}i{kh; laO;ogkjksa ds fy, Vh&th,u, gsrq ukfer ,tsl
a h tks fd bu fofu;eksa ds fofu;e 26 ls
fofu;e 36 ds ç;kstu gsrq ml çns'k dk vkj,yMhlh gksxh tgka vkgj.k fcanq fLFkr gS (
¼iii½ lkewfgd laO;ogkjksa ds fy, Vh&th,u, gsrq ukfer ,tsl
a h tks fd bu fofu;eksa ds fofu;e 26 ls
fofu;e 36 ds ç;kstu gsrq ,u,yMhlh gksxh(
¼iv½ ,uvks,vkj ds dk;kZUo;u vkSj çpkyu ds fy, ,tsalh tks fd bu fofu;eksa ds fofu;e 27 ds
ç;kstu gsrq ,u,yMhlh gksxh(
¼dx½ ÞfuckZ/k igqap fofu;eß ls dsUæh; fo|qr fofu;ked vk;ksx ¼varj&jkfT;d ikjs"k.k esa fuckZ/k igqap½ fofu;e]
2008 vfHkçsr gS(
¼d?k½ Þfo|qr cktkj fofu;eß ls dsUæh; fo|qr fofu;ked vk;ksx ¼fo|qr cktkj½ fofu;e] 2021 vfHkçsr gS (
¼d³½ Þçknsf'kd bdkbZß dk ogh vFkZ gksxk tSlk fd fxzM dksM esa ifjHkkf"kr gS (
¼dp½ Þçknsf'kd Hkkj çs"k.k dsUæß ;k Þvkj,yMhlhß ls vf/kfu;e dh /kkjk 27 dh mi&/kkjk ¼1½ ds v/khu LFkkfir
çknsf'kd Hkkj çs"k.k dsUæ vfHkçsr gS(
¼dN½ Þuohdj.kh; ÅtkZ mRiknu LVs'kuß ;k ÞvkjbZth,lß ls ÅtkZ HkaMkj.k ç.kkyh lfgr ;k blds fcuk ÅtkZ ds
uohdj.kh; lzksr ij vk/kkfjr mRiknu LVs'ku vfHkçsr gS vkSj blesa uohdj.kh; gkbfczM mRiknu LVs'ku 'kkfey gS (
¼dt½ Þuohdj.kh; gkbfczM mRiknu LVs'kuß ;k Þvkj,pth,lß ls ,d gh varj&la;kstu fcanq ij tqM+s ÅtkZ
HkaMkj.k ç.kkyh lfgr ;k blds fcuk] ÅtkZ ds nks ;k nks ls vf/kd uohdj.kh; lzksr ¼lzksrks½a ds gkbfczM ij
vk/kkfjr mRiknu LVs'ku vfHkçsr gS(
¼d>½ Þuohdj.kh; fo|qr ikdZ fodkldrkZß ls uohdj.kh; ÅtkZ mRiknu LVs'ku ¼LVs'kuks½a ds fy, fo|qr ikdZ
fodkldrkZ ds :i esa dsUæ ljdkj ;k jkT; ljdkj }kjk çkf/k—r bdkbZ vfHkçsr gS(
¼d¥½ Þvkj,yMhlh Qhl vkSj çHkkj fofu;eß ls dsUæh; fo|qr fofu;ked vk;ksx ¼çknsf'kd Hkkj çs"k.k dsUæ ds
Qhl vkSj çHkkj vkSj vU; lac) ekeys½ fofu;e] 2019 vfHkçsr gS(
¼dV½ Þ'ks;fjax fofu;eß ls dsUæh; fo|qr fofu;ked vk;ksx ¼varj&jkfT;d ikjs"k.k çHkkjksa vkSj gkfu;ksa dh
'ks;fjax½ fofu;e] 2020 vfHkçsr gS(
¼dB½ ÞLFkk;h fDy;jsalß ls bu fofu;eksa ds fofu;e 31 esa ;Fkk fofufnZ" V lacaf/kr jkT; Hkkj çs"k.k dsUæ }kjk tkjh
fDy;jsal vfHkçsr gS(
¼dM½ ÞjkT; ikjs"k.k ;wfVfyVhß ;k Þ,lVh;wß dk ogh vFkZ gksxk tSlk fd vf/kfu;e dh /kkjk 2 dh mi&/kkjk ¼67½
esa ifjHkkf"kr gS(

<!-- page 6 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

¼d<½ ÞvLFkk;h th,u,ß ;k ÞVh&th,u,ß ls bu fofu;eksa ds v/;k; 6 ds lan HkZ esa vkbZ,lVh,l dks vuqnÙk
fuckZ/k igqap vfHkçsr gS(
¼d.k½ ÞVfeZuy csß ls vkbZ,lVh,l lc&LVs'ku ij cs vfHkçsr gS tgka la;kstdrk vuqnkuxzkgh dh ikjs"k.k ykbus
lekIr gksrh gSa(
¼dr½ ÞVh&th,u, vuqnkuxzkghß ls og O;fä vfHkçsr gS ftls bu fofu;eksa ds v/khu Vh&th,u, çnku fd;k x;k
gSA
2.2 bu fofu;eksa esa iz;qä vkSj ;gka ifjHkkf"kr ugha fd, x, ijarq vf/kfu;e ;k dsUæh; vk;ksx }kjk fofuÆn"V
fdlh vU; fofu;eksa esa ifjHkkf"kr 'kCnksa vkSj vfHkO;fä;ksa dk vFkZ] tc rd fd lanHkZ }kjk vU;Fkk visf{kr
u gks] og gksxk tSlk fd ;FkkfLFkfr vf/kfu;e ;k dsUæh; vk;ksx }kjk fofuÆn"V vU; fofu;eksa ds v/khu
mUgsa iznku fd;k x;k gSA
2.3 fdlh Hkh vf/kfu;e] fu;eksa vkSj fofu;eksa ds lanHkZ esa mudk la'kks/ku ;k lesdu ;k iqujkf/kfu;eu 'kkfey
gksxkA

3.
3.1
3.2
3.3

3.4
3.5

3.6

3.7

la;kstdrk iznku fd, tkus ;k th,u, iznku fd, tkus gsrq vkosnu] ;FkkfLFkfr] uksMy ,tsalh dks
vkWuykbu :i esa fd;k tk,xk vkSj vkosnd }kjk fMftVy :i ls gLrk{kfjr fd;k tk,xkA
la;kstdrk iznku fd, tkus gsrq izR;sd vkosnu] ykxw djksa lfgr #-5 yk[k dh vkosnu Qhl ds lkFk
fd;k tk,xkA
th,u, iznku fd, tkus gsrq izR;sd vkosnu] ykxw djksa lfgr #-5 yk[k dh vkosnu Qhl ds lkFk fd;k
tk,xkA
ijarq ;g fd th,u, gsrq vkosnu djrs le; jkT; ikjs"k.k ;wfVfyVh }kjk dksbZ vkosnu Qhl ns; ugha
gksxhA
vkosnu dh izkfIr gsrq vkosnu dh rkjh[k vkSj le; lfgr Lor% mRiUUk ikorh vkosnd dks tkjh dh
tk,xh vkSj bldh izfr uksMy ,tsalh dh osclkbV ij iznÆ'kr dh tk,xhA
laoh{kk ds ckn] uksMy ,tsl
a h vkosnd dks vkosnu dh izkfIr dh rkjh[k vkSj le; ds Øe esa vkosnu dh
izkfIr ds ,d lIrkg ds vanj la;kstdrk iznku fd, tkus ;k th,u, iznku fd, tkus ds fy, vkosnu esa
dfe;ks]a ;fn dksbZ gks] ds ckjs esa lwfpr djsxhA vkosnd blds ckn ,d lIrkg ds vanj dfe;ksa dks lq/kkj
ldrk gS] ftlds u gksus ij vkosnu dks lekIr dj fn;k tk,xk vkSj vkosnu Qhl dk 20% tCr dj
fy;k tk,xkA vkosnu 'kqYd dk 'ks"k 80% uksMy ,tsalh }kjk vkosnd dks vkosnu lekIr fd, tkus ds 15
fnuksa ds vanj okil fd;k tk,xkA
la;kstdrk iznku fd, tkus ds fy, ekl ds nkSjku bu fofu;eksa ds fofu;e 4-1 ds v/khu vkosndksa ls
izkIr lHkh vkosnuksa dks ekl ds vafre fnu ds 2400 cts rd ,d lkFk lalkf/kr fd;k tk,xkA vkosnuksa
dh ijLij izkFkfedrk] tgka dgha vko';drk gks] vkosnu izkIr gksus dh rkjh[k vkSj le; ds vuqlkj nh
tk,xhA
;fn bu fofu;eksa ds fofu;e 7 ds lanHkZ esa la;kstdrk ds lS)kafrd vuqnku ;k bu fofu;eksa ds fofu;e
22 ds lanHkZ esa th,u, ds vuqnku ls iwoZ la;kstdrk ds vuqnku ;k th,u, ds vuqnku gsrq dksbZ vkosnu
okil fy;k tkrk gS] rks vkosnu Qhl dk 50% tCr dj fy;k tk,xkA vkosnu Qhl dk 'ks"k 50%]
vkosnu ds okil fy, tkus ds 15 fnuksa ds vanj uksMy ,tsalh }kjk vkosnd dks okil dj fn;k tk,xk%
ijarq ;g fd ;fn dksbZ vkosnu] la;kstdrk ds lS)kafrd vuqnku ;k th,u, ds vuqnku ds ckn okil
fy;k tkrk gS] rks ,sls vkonsu dks okil fy, tkus dh rkjh[k ds 15 fnuksa dh vof/k ds vanj uksMy
,tsalh }kjk lekIr dj fn;k tk,xk vkSj vkosnu Qhl dk 100% tCr dj fy;k tk,xkA

4.
4.1 fuEufyf[kr bdkb;ka la;kstdrk ds vuqnku gsrq ;k la;kstdrk dh ek=k esa o`f) gsrq vkosnu djus ds fy,

vkosnu ds :i esa ik= gksx
a h%

<!-- page 7 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

5

¼d½ vkjbZth,l lfgr] bZ,l,l ds lkFk ;k fcuk] vyx&vyx :i ls 50 esxkokV vkSj mlls vf/kd dh
laLFkkfir {kerk ds lkFk] ;k yhM tsujsVj ;k yhM bZ,l,l ds ek/;e ls 50 esxkokV vkSj mlls vf/kd dh
ldy laLFkkfir {kerk ds lkFk mRiknu LVs'ku(
¼[k½
50 esxkokV vkSj mlls vf/kd ds vkbZ,lVh,l esa var%{ksi.k dh {kerk ds lkFk dSfIVo mRiknu la;a=(
¼x½
vyx&vyx :i ls 50 esxkokV vkSj mlls vf/kd dh laLFkkfir {kerk ds lkFk ;k yhM bZ,l,l ;k
yhM tsujsVj ds ek/;e ls 50 esxkokV dh ldy laLFkkfir {kerk ds lkFk bZ,l,l LVSaMvyksu(
¼?k½
uohdj.kh; fo|qr ikdZ fodkldrkZ(
¼³½ vkbZ,lVh,l ls igys ls gh la;kstdrk okys mRiknu LVs'ku dh fo|qrh; ç.kkyh ds ek/;e ls
vkbZ,lVh,l ls la;kstdrk ds vuqnku gsrq vkosnu djus okys 5 esxkokV vkSj mlls vf/kd dh laLFkkfir {kerk
ds lkFk vkjbZth,l ;k LVSaMvyksu bZ,l,l%
ijarq ;g fd vkbZ,lVh,l ls la;kstdrk ds vuqnku gsrq vkosnu djus okyh ,slh bdkbZ us viuh fo|qrh;
ç.kkyh vkSj lefiZr ikjs"k.k ykbuks]a ;fn dksbZ gks] dks mä mRiknu LVs'ku ds lkFk 'ks;j djus gsrq djkj fd;k
gSA
4.2 fofu;e 4-1 esa fdlh ckr ds gksrs gq, Hkh] la;kstdrk okyh bdkb;ka] vkosnu Qhl ds Hkqxrku ij ikjs"k.k
iz.kkyh esa miyC/k {kerk ds v/;k/khu 50 esxkokV ls de dh la;kstdrk dh o`f) ds fy, vkosnu djus
gsrq ik= gksx
a hA
4.3 var% jkfT;d ikjs"k.k iz.kkyh ls igys ls tqM+s ;k tqM+us ds bPNqd mRiknu LVs'ku Hkh la;kstdrk gsrq
vkosnd ds :i esa ik= gksx
a sA
5.
5.1 vkosnd] tks fd vkjbZth,l lfgr mRiknu LVs'ku gS] mRiknu LVs'ku dh laLFkkfir {kerk dh lerqY; ek=k

ds fy, uksMy ,tsalh dks la;kstdrk ds vuqnku gsrq vkosnu djsxk%
ijarq ;g fd ;fn ,sls vkonsd ds ikl viuh laLFkkfir {kerk ds Hkkx ds fy, var% jkfT;d ikjs"k.k
iz.kkyh ls la;kstdrk gS] rks og laLFkkfir {kerk ds 'ks"k rd dh ek=k ds fy, vkbZ,lVh,l ls la;kstdrk
gsrq vkosnu dj ldrk gS;
ijarq ;g vkSj fd ;fn ,slk vkosnd uohdj.kh; gkbfczM mRiknu LVs'ku ;k HkaMkj.k ds lkFk vkjbZth,l
gS] rks og laLFkkfir {kerk ds cjkcj ;k mlls de dh ek=k ds fy, la;kstdrk ds vuqnku gsrq vkosnu
dj ldrk gSA
5.2 fofu;e 5-1 esa fdlh ckr ds gksrs gq, Hkh mRiknu LVs'ku ;k bZ,l,l] lhVh;w ds iwoZ vuqeksnu ds lkFk]
mls vuqnŸk la;kstdrk dh ek=k ds vanj bZ,l,l lfgr vfrfjä mRiknu dks tksM+us dk ik= gksxk;
ijarq ;g fd ,slh vfrfjä mRiknu {kerk ds fy,] mä mRiknu LVs'ku fxzM dksM vkSj dsUæh; vk;ksx ds
vU; fofu;eksa ds vuqikyu gsrq mŸkjnk;h gksxkA
5.3 vkosnd] tks fd dSfIVo mRiknu la;a= gS] vkbZ,lVh,l esa viuh izLrkfor vf/kdre var%{ksi.k dh ek=k ds
fy, la;kstdrk ds vuqnku gsrq vkosnu dj ldrk gSA
5.4 vkosnd] tks fd LVSaMvyksu bZ,l,l gS] vkbZ,lVh,l esa viuh izLrkfor vf/kdre var%{ksi.k ;k vkbZ,lVh,l
ls izLrkfor vf/kdre vkgj.k dh ek=k] tks Hkh vf/kdre gks] ds fy, la;kstdrk ds vuqnku gsrq vkosnu
dj ldrk gSA
5.5 vkosnd] tks fd uohdj.kh; fo|qr ikdZ fodkldrkZ gS] la;kstdrk dh ml ek=k ds vuqnku gsrq vkosnu
dj ldrk gS ftlds fy, mls uohdj.kh; fo|qr ikdZ fodkldrkZ ds :i esa dsUæ ljdkj ;k jkT;
ljdkj }kjk izkf/k—r fd;k x;k gSA
5.6 vkosnd] VÆeuy cs ;k fLop;kMZ vkSj leÆir ikjs"k.k ykbuks]a ;fn dksbZ gks] dks 'ks;j djus ds fy, vkosnd
vkSj mä la;kstdrk vuqnkuxzkgh ;k vkbZ,lVh,l ls la;kstdrk okys mRiknu LVs'ku] ;FkkfLFkfr] ds chp
fof/kor~ :i ls gLrk{kfjr djkj ds lkFk (i) vU; la;kstdrk vuqnkuxzkgh dks igys ls gh vkcafVr
vkbZ,lVh,l lc&LVs'ku dh VÆeuy cs ;k (ii) vkbZ,lVh,l ls la;kstdrk okys mRiknu LVs'ku ds
fLop;kMZ ij la;kstdrk ds vuqnku gsrq vkosnu dj ldrk gSA bu fofu;eksa ds fofu;e 8 ds vuqlkj
ykxw la;kstdrk cSad xkjaVh] ,sls vkosnd }kjk izLrqr dh tk,xhA
5.7 nks ;k nks ls vf/kd vkosnd leÆir ikjs"k.k ykbuksa vkSj VÆeuy cs dks 'ks;j djus gsrq muds }kjk fof/kor~
:i ls gLrk{kfjr djkj ds lkFk leku VÆeuy cs ij la;kstdrk ds vuqnku ds fy, vkosnu dj ldrs
gSaA bu fofu;eksa ds fofu;e 8 ds vuqlkj ykxw la;kstdrk cSad xkjaVh ,sls izR;sd vkosnd }kjk izLrqr dh
tk,xhA

<!-- page 8 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

5.8 la;kstdrk ds vuqnku gsrq

vkosnu esa] vU; ckrksa ds lkFk&lkFk] fofu;e 39-1 ds vuqlkj tkjh la;kstdrk
vkSj th,u, ds fy, foLr`r fØ;kfof/k esa ;Fkk fu/kkZfjr] lqlaxr ,fQMsfoV ds lkFk fof/kor~ leÆFkr] ;Fkk
ykxw] fuEufyf[kr fooj.k 'kkfey gksus pkfg,a%
(i)
bu fofu;eksa ds fofu;e 4-1 ds v/khu HkkSxksfyd fLFkfr vkSj laLFkkfir {kerk(
(ii) vkbZ,lVh,l ds lkFk varÆofue; dh tkus okyh fo|qr dh vf/kdre ek=k vkSj vkbZ,lVh,l ls
la;kstu dk loZ&iz/kku Çcnq(
(iii) ftl rkjh[k ls la;kstdrk ekaxh xbZ gS(
(iv) vkosnu Qhl ds fy, fMftVy Hkqxrku dh cSad tfur izek.k(
(v) daiuh ds ekeys esa] la;kstdrk ds vuqnku gsrq vkosnu djus ds fy, ukfer O;fä dks izkf/k—r
djus okyk cksMZ jst+ksY;w'ku(
(vi) lhbZ, jftLVªh }kjk tkjh izek.ki= ds lkFk iathdj.k la[;k(
(vii) uohdj.kh; fo|qr ikdZ fodkldrkZ ds ekeys esa] lkSj fo|qr mRikndksa ;k iou fo|qr mRikndksa
dh vksj ls la;kstdrk ds fy, O;oLFkk lfgr <kapkxr xfrfof/k;ksa dks djus gsrq ;Fkk ykxw dsUæ
ljdkj ;k jkT; ljdkj }kjk izkf/kdkj(
(viii) yhM mRiknd ;k yhM bZ,l,l] ;FkkfLFkfr] ds ek/;e ls vkosnu ds ekeys esa] leÆir ikjs"k.k
ykbuksa vkSj VÆeuy cs dh 'ks;Çjx ds fy, djkj vkSj fxzM dksM ds mica/kksa vkSj dsUæh; vk;ksx
ds vU; fofu;eksa ds vuqikyu gsrq mŸkjnk;h gksus ds fy, yhM tsujsVj ;k yhM bZ,l,l]
;FkkfLFkfr] dh lgefr(
(ix) bu fofu;eksa ds fofu;e 5-6 ds v/khu doj fd, x, vkosnd ds ekeys esa] VÆeuy cs ;k
fLop;kMZ] ;FkkfLFkfr] vkSj leÆir ikjs"k.k ykbuks]a ;fn dksbZ gks] dh 'ks;Çjx gsrq vkosnd vkSj
la;kstdrk vuqnkuxzkgh ;k vkbZ,lVh,l ls la;kstdrk okys mRiknu LVs'ku ds chp djkj(
(x) bu fofu;eksa ds fofu;e 5-7 ds v/khu doj fd, x, vkosnd ds ekeys esa] VÆeuy cs vkSj
leÆir ikjs"k.k ykbuks]a ;fn dksbZ gks] dh 'ks;Çjx gsrq vkosnd ¼vkosndks½a ds chp djkjA

6.
6.1 la;kstdrk ds vuqnku gsrq vkosnu izkIr gksus ij uksMy ,tsalh] lkekU; usVodZ igqap ds v/khu vkbZ,lVh,l

ls vf/kd fo|qr ds varj.k dks l{ke djus gsrq ekStwnk vkbZ,lVh,l] ;fn dksbZ gks] dh o`f) dh
vko';drk ds lkFk la;kstdrk ds fy, lhbZ, rduhdh ekudksa esa ;Fkk fofuÆn"V varjla;kstu v/;;u
djsxh%
ijarq ;g fd bl fofu;e ds iz;kstu gsrq ekStwnk vkbZ,lVh,l ml ikjs"k.k iz.kkyh dks 'kkfey djsxk ftls
ml ekl ds vafre fnu ij dk;kZUo;u ds fy, vokMZ fd;k x;k gS ftlesa la;kstdrk ds vuqnku gsrq
lHkh izdkj ls laiw.kZ vkosnu izkIr gqvk gS%
ijarq ;g vkSj fd ;fn fdlh vfrfjä ikjs"k.k iz.kkyh dks varjla;kstu v/;;u ds lekiu ls iwoZ
dk;kZUo;u ds fy, vokMZ fd;k tkrk gS] rks ,slh vfrfjä ikjs"k.k iz.kkyh dks Hkh ekStwnk vkbZ,lVh,l ds
:i esa leÖkk tk,xkA
6.2 bu fofu;eksa ds fofu;e 6-1 ds v/khu igpku dh xbZ o`f) dh vko';drk esa ls] VÆeuy cs dks NksM+dj]
vkosnd ¼vkosndksa½ dh fo|qr dh rRdky fudklh ds fy, vko';d o`f) dks vkosnd ¼vkosndks½a ds fy,
lac) ikjs"k.k iz.kkyh ¼,Vh,l½ ds :i esa leÖkk tk,xkA
7.

;fn uksMy ,tsalh bu fofu;eksa ds fofu;e 6-1 ds vuqlkj fd, x, varjla;kstu v/;;u ds ckn ;g
fu/kkZfjr djrh gS fd fdlh ,Vh,l dh vko';drk ugha gS] rks uksMy ,tsl
a h] ftl ekl esa vkosnu çkIr
gqvk Fkk] ml ekl ds vafre fnu ls 30 fnuksa ds vanj vkosnd dks la;kstdrk dk lS)kafrd vuqnku lwfpr
djsxh ftlesa VÆeuy cs] igys ls gh miyC/k ;k lhVh;w ds ek/;e ls vkbZ,lVh,l ds v/khu fodflr
fd, tkus] vkSj vkosnd }kjk fuekZ.k dh tkus okyh leÆir ikjs"k.k ykbuksa ds fy, U;wure fMt+kbu
fo'ks"krkvksa tSls fooj.kksa dk mYys[k gksxkA
7.2 ;fn uksMy ,tsalh bu fofu;eksa ds fofu;e 6-1 ds vuqlkj fd, x, varjla;kstu v/;;u ds ckn ;g
fu/kkZfjr djrh gS fd ,Vh,l dh vko';drk gS] rks uksMy ,tsl
a h ml ekl ds vafre fnu ls 60 fnuksa ds
vanj vkosnd dks la;kstdrk dk lS)kafrd vuqnku lwfpr djsxh ftlesa vkosnu izkIr gqvk Fkk%
ijarq ;g fd la;kstdrk ds lS)kafrd vuqnku gsrq lwpuk esa ,Vh,l vkSj VÆeuy cs] ,sls ,Vh,l vkSj
VÆeuy cs dh vuqekfur ykxr] vkosnd }kjk fuekZ.k dh tkus okyh leÆir ikjs"k.k ykbuksa ds fy,
U;wure fMt+kbu fo'ks"krk,a vkSj la;kstdrk ds vkjaHk dh laHkkfor rkjh[k dk mYys[k gksxk%
7.1

<!-- page 9 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

7

ijarq ;g vkSj fd la;kstdrk ds fu.kkZ;d vuqnku ds le; la;kstdrk ds vkjaHk dh fu/kkZfjr rkjh[k dh
iqf"V dh tk,xhA
8.
8.1 vkosnd

}kjk la;kstdrk cSad xkjaVh rhu Hkkxksa esa izLrqr dh tk,xh] la;kstdrk&chth1 dh jkf'k #- 50
yk[k] vkSj la;kstdrk&chth2 vkSj la;kstdrk&chth3] dh jkf'k bu fofu;eksa ds fofu;e 8-2 vkSj fofu;e
8-3 esa ;Fkk micaf/kr gksxhA
8.2 bu fofu;eksa ds fofu;e 7-1 esa doj fd, x, ekeyksa ds fy,] la;kstdrk&chth2 vkSj la;kstdrk&chth3
fuEukuqlkj izLrqr dh tk,xh%
¼d½ VfeZuy cs ds fy, la;kstdrk&chth2 fuEukuqlkj vkcafVr VfeZuy cs dh la[;k ds vk/kkj ij çLrqr dh tk,xh%
vkcafVr VÆeuy cs dk oksYVrk Lrj
132 dsoh
220@230 dsoh
400 dsoh
765 dsoh

la;kstdrk&chth2 ¼çfr VÆeuy cs½
#- 2 djksM+
#- 3 djksM+
#- 6 djksM+
#- 12 djksM+

ijarq ;g fd fdlh la;kstdrk&chth2 dks izLrqr djus dh vko';drk ugha gksxh ;fn bdkbZ (i) bu fofu;eksa ds
fofu;e 12-4 ds v/khu VÆeuy cs dk fuekZ.k Lo;a djus dk izLrko djrh gS] ;k (ii) vU; la;kstdrk vuqnkuxzkgh
}kjk fuÆer ;k fuÆer fd, tk jgs VÆeuy cs ij la;kstdrk ekaxrh gS] ;k (iii) mRiknu LVs'ku dh fo|qrh; iz.kkyh
;k fLop;kMZ ds ek/;e ls la;kstdrk ekaxrh gSA
¼[k½ ekStwnk vkbZ,lVh,l ds fy, bdkbZ }kjk #- 2 yk[k@esxkokV ij la;kstdrk&chth3 çLrqr dh tk,xhA
¼x½ la;kstdrk&chth1] la;kstdrk&chth2] vkSj la;kstdrk&chth3] ;Fkk ykxw] la;kstdrk ds lS)kafrd vuqnku dh
lwpuk ds 1 ¼,d½ ekl ds vanj çLrqr dh tk,xh] ftlds u gksus ij la;kstdrk gsrq vkosnu lekIr dj fn;k
tk,xk vkSj vkosnu Qhl tCr dj yh tk,xhA
8.3 bu fofu;eksa ds fofu;e 7-2 ds v/khu doj fd, x, ekeyksa ds fy,] fuEufyf[kr fØ;kfof/k dk ikyu
fd;k tk,xk%
¼d½ og bdkbZ ftls la;kstdrk dk lS)kafrd vuqnku lwfpr dj fn;k x;k gS] la; kstdrk ds lS)kafrd
vuqnku dh lwpuk ds ,d ekl ds vanj] la;kstdrk&chth1 ds lkFk] bu fofu;eksa ds fofu;e 7-2 ds v/khu ;Fkk
lwfpr] ,Vh,l vkSj VfeZuy cs ds fu"iknu gsrq viuh lgefr çLrqr djsxh] ftlds u gksus ij la;kstdrk gsrq
vkosnu lekIr dj fn;k tk,xk vkSj vkosnu Qhl tCr dj yh tk,xhA
¼[k½
uksMy ,tsalh] bl fofu;e ds [kaM ¼d½ ds vuqlkj la;kstdrk&chth1 dh çLrqfrdj.k ds 6 ¼Ng½ ekl
ds vanj ,slh bdkbZ dks ¼i½ ,Vh,l vkSj VfeZuy cs ds fy, çLrqr dh tkus okyh la;kstdrk&chth2 dh jkf'k tks
fd bu fofu;eksa ds fofu;e 7-2 ds v/khu lwfpr vuqekfur ykxr ls vf/kd ugha gksxh] ¼ii½ ,Vh,l vkSj VfeZuy
cs ds lekiu ds fy, VkbZeykbu] vkSj ¼iii½ la;kstdrk ds vkjaHk dh fu/kkZfjr rkjh[k lwfpr djsxhA
ijarq ;g fd ;fn ,sls ,Vh,l vkSj VfeZuy cs] ,d ls vf/kd bdkbZ ds fy, fu;ksftr gSa] rks la;kst drk&chth2
,slh bdkb;ksa }kjk vkosnu dh xbZ la;kstdrk dh ek=k ds vuqikr esa çLrqr dh tk,xhA
¼x½
;fn uksMy ,tsalh bl fofu;e ds [kaM ¼[k½ ds vuqlkj fooj.kksa dks 6 ¼Ng½ ekl ds vanj lwfpr ugha
djrh gS] rks uksMy ,tsalh] ml laHkkfor rkjh[k ds lkFk ftl rd la;kst drk&chth2 vkSj ,slh VkbeykbZu
çLrqr dh tk,xh] Ng ekl dh ,slh vof/k dh lekfIr ds ,d ekl ds vanj dsUæh; vk;ksx dks çfr ds lkFk
bdkbZ dks ,slh xSj&lwpuk ds fy, dkj.k çLrqr djsxh%
ijarq ;g fd uksMy ,tsl
a h }kjk Ng ekl ds vanj xSj&lwpuk dh n'kk es]a bdkbZ ds ikl la;kstdrk gsrq vkosnu
dks okil ysus dk fodYi gksxk vkSj ,sls ekeys es]a bdkbZ }kjk okil ysus dk fodYi pquus ds ,d ekl ds vanj
la;kstdrk&chth1 okil dj nh tk,xh vkSj vkosnu lekIr dj fn;k tk,xkA
¼?k½
og jkf'k ftlds fy, bl fofu;e ds [kaM ¼[k½ ds vuqlkj la;kst drk&chth2 çLrqr tkuh gS] ,Vh,l
vkSj VfeZuy cs dh vuqekfur ykxr ds cjkcj gksxh vkSj ,Vh,l vkSj VfeZuy cs ds lekiu gsrq VkbZeykbu] ,sls
,Vh,l vkSj VfeZuy cs gsrq okf.kfT;d çpkyu dh vuqlwfpr rkjh[k ij vk/kkfjr gksxhA
¼³½ og bdkbZ ftls la;kstdrk dk lS)kafrd vuqnku lwfpr fd;k x;k gS] bl fofu;e ds mi&[kaM ¼[k½ ds
v/khu uksMy ,tsalh }kjk lwpuk ds 1 ¼,d½ ekl ds vanj la;kstdrk&chth2 çLrqr djsxh] ftlds u gksus ij
la;kstdrk gsrq vkosnu lekIr dj fn;k tk,xk] la;kstdrk&chth1 dk udnhdj.k fd;k tk,xk vkSj vkosnu
Qhl dks tCr dj fy;k tk,xkA

<!-- page 10 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY
8.4

[PART III—SEC.4]

fofu;e 39-1 ds vuqlkj tkjh dh xbZ la;kstdrk vkSj th,u, ds fy, foLr`r fØ;kfof/k esa fu/kkZfjr izk:i
ds vuqlkj] Hkkjrh; fjt+oZ cSad }kjk ekU;rk izkIr fdlh vuqlwfpr okf.kfT;d cSad }kjk lhVh;w ds i{k esa
la;kstdrk&chth1] la;kstdrk&chth2] vkSj la;kstdrk&chth3 tkjh dh tk,xhA

9.
9.1 la;kstdrk&chth2 vkSj la;kstdrk&chth3] ;Fkk ykxw] ds izkIr gksus ds 15 fnuksa ds vanj uksMy ,tsl
a h ml

bdkbZ dks la;kstdrk dk fu.kkZ;d vuqnku lwfpr djsxh ftls la;kstdrk dk lS)kafrd vuqnku lwfpr
fd;k x;k gSA lwpuk esa] vU; ckrksa ds lkFk&lkFk] fuEufyf[kr 'kkfey gksx
a s%
¼d½
vkbZ,lVh,l lc&LVs'ku ;k mRiknu LVs'ku dk fLop;kMZ] ;Fkk fLFkfr] dk uke tgka la;kstdrk dk
vuqnku fd;k x;k gSA
¼[k½
ekStwnk vkbZ,lVh,l lc&LVs'ku ds ekeys es]a ,dy ykbu vkjs[k ds lkFk VfeZuy cs dh vofLFkfrA
¼x½
fuekZ.kk/khu vkbZ,lVh,l lc&LVs'ku ds ekeys esa] ,sls vkbZ,lVh,l lc&LVs'ku ds funsZ'kkadksa vkSj
okf.kfT;d çpkyu dh vuqlwfpr rkjh[k] ,dy ykbu vkjs[k ds lkFk VfeZuy cs dh vofLFkfrA
¼?k½
çLrkfor vkbZ,lVh,l lc&LVs'ku ds ekeys esa] ,sls vkbZ,lVh,l lc&LVs'ku ds vuafre funsZ'kkadksa vkSj
okf.kfT;d çpkyu dh vuqlwfpr rkjh[kA
¼³½ oksYVrk Lrj lfgr lefiZr ikjs"k.k ykbuksa dh O;kid fMtkbu fo'ks"krk,aA
9.2 tgka vkosnd us vU; la;kstdrk vuqnkuxzkgh dks igys ls gh vkcafVr VÆeuy cs ij la;kstdrk ds fy,
vkosnu fd;k gS ;k tgka leku VÆeuy cs ij la;kstdrk ds fy, nks ;k nks ls vf/kd vkosndksa us
vkosnu fd;k gS] ogka bu fofu;eksa ds fofu;e 9-1 ds v/khu ;Fkk lwfpr la;kstdrk dk vafre vuqnku]
leÆir ikjs"k.k ykbuksa esa {kerk dh miyC/krkds v/;/khu gksxkA
10.

og bdkbZ ftls la;kstdrk dk vafre vuqnku lwfpr dj fn;k x;k gS] fofu;e 39-1 ds vuqlkj tkjh
la;kstdrk vkSj th,u, ds fy, foLr`r fØ;kfof/k esa ;Fkk fu/kkZfjr uksMy ,tsalh dks rduhdh MkVk] vU;
ckrksa ds lkFk&lkFk] QkWYV v/;;u ds fy, tsujsVj MkVk] Mk;usfed fleqy's ku MkVk vkSj MkVk vkSj okW;l
dE;wfuds'ku dk fooj.k izLrqr djsxh%
ijarq ;g fd ;fn bdkbZ ds ikl vafre rduhdh la;kstu MkVk dk vf/kdkj ugha gS] rks og la;kstdrk
djkj dk Hkkx cuus gsrq vuafre MkVk izLrqr dj ldrh gS vkSj HkkSfrd la;kstu ls de ls de 1 ¼,d½
o"kZ iwoZ vafre MkVk izLrqr dj ldrh gSA ,sls vafre rduhdh la;kstu MkVk dks la;kstu djkj ds lkFk
layXu fd;k tk,xkA
10.2 uksMy ,tsl
a h fofu;e 10-1 ds v/khu rduhdh la;kstu MkVk ds izkfIr dh rkjh[k ls ,d ekl dh vof/k
ds vanj la;kstu fooj.k] vU; ckrksa ds lkFk&lkFk] laj{k.k miLdj dk fooj.k] iz.kkyh fjdkWÉMx]
,llh,Mh, vkSj lapkj miLdj lwfpr djsxhA
10.3 fofu;e 10-2 ds v/khu uksMy ,tsalh }kjk la;kstu fooj.kksa ds lwfpr fd, tkus ds 30 fnuksa ds vanj]
uksMy ,tsalh vkSj ml bdkbZ ds chp la;kstdrk djkj gLrk{kfjr fd;k tk,xk ftls la;kstdrk dk vafre
vuqnku lwfpr fd;k x;k gSA la;kstdrk djkj ds gLrk{kfjr gksus ij] ,slh bdkbZ la;kstdrk vuqnkuxzkgh cu
tk,xhA
10.4 fofu;e 10-1 esa bafxr rduhdh la;kstu MkVk vkSj fofu;e 10-2 esa bafxr la;kstu fooj.k] la;kstdrk
djkj dk fgLlk gksaxsA
10.5 tgka la;kstdrk izLrkfor vkbZ,lVh,l lc&LVs'ku ij vuqnku dh xbZ gS] ogka uksMy ,tsalh la;kstdrk
djkj ds gLrk{kfjr gksus ds 2 ekl ds vanj vafre funsZ'kkadksa dh iqf"V djsxh vkSj ,sls funsZ'kkad igys ls
gh lwfpr vuafre funsZ'kkadksa ds 5 fdeh ds jsfM;l ls ckgj ugha gksx
a sA
10.6 fofu;e 10-3 ds v/khu tSlk fd visf{kr gS] ml bdkbZ }kjk la;kstdrk djkj dks gLrk{kj djus esa
foQyrk dh n'kk esa ftls la;kstdrk dk vafre vuqnku lwfpr dj fn;k x;k gS] uksMy ,tsl
a h 30 fnuksa
dh vf/kdre vof/k ds fy, la;kstdrk djkj dks gLrk{kj djus ds fy, le; c<+k ldrh gS] ftlds u
gksus ij uksMy ,tsl
a h }kjk vkosnd dks lwfpr djrs gq, la;kstdrk dk vafre vuqnku dk izfrlagj.k dj
fn;k tk,xk] la;kstdrk&chth1] la;kstdrk&chth2 dk udnhdj.k fd;k tk,xk] vkSj la;kstdrk&chth3 dks
okil dj fn;k tk,xkA
ijarq ;g fd tgka ,Vh,l ;k VÆeuy cs dk fuekZ.k dk;kZUo;u ds fy, vokMZ ugha fd;k x;k gS]
la;kstdrk&chth2 dks ,sls izfrlagj.k ds ,d ekl ds vanj okil dj fn;k tk,xkA
10.1

10.7 la;kstdrk djkj esa] vU; ckrksa ds lkFk&lkFk] fuEufyf[kr vkSj fofu;e 39-1 ds vuqlkj tkjh ‘la;kstdrk

vkSj th,u, ds fy, foLr`r fØ;kfof/k‘ esa ;Fkk fu/kkZfjr vU; fooj.k 'kkfey gksx
a s%

<!-- page 11 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

9

¼d½
bu fofu;eksa ds fofu;e 10-5 ds mica/kksa ds v/;/khu vkbZ,lVh,l lc&LVs'ku ij vkcafVr VfeZuy cs
ds fooj.k(
¼[k½
la;kstdrk ds vkjaHk dh rkjh[k( vkSj
¼x½
mica/k fd ns; rkjh[k ls 3 ekl ls vf/kd ds fy, 'ks;fjax fofu;eksa ds fofu;e 13 ds v/khu ikjs"k.k
çHkkjksa ds xSj&Hkqxrku ds ekeys esa] bldh olwyh bu fofu;eksa ds fofu;e 16-3 ds mica/k dh vis{kk vuqlkj
la;kstdrk&chth1] la;kstdrk&chth2 vkSj la;kstdrk&chth3 ds udnhdj.k }kjk dh tk,xhA
10.8 LVkVZ&vi fo|qr ds vkgj.k ;k v'kä fo|qr ds var%{ksi.k gsrq bdkbZ] ,Vh,l esa ?kVdksa dks igpku ldrh
gS vkSj la;kstdrk djkj esa lgefr ds vuqlkj la;kstrk ds vkjaHk dh rkjh[k ls iwoZ mu ?kVdksa dh
lhvksMh ekax ldrh gSA uksMy ,tsalh vkSj bdkbZ ds chp okf.kfT;d fuca/kuksa vkSj 'krks± dks doj djrs gq,
blds fy, i`Fkd djkj gLrk{kfjr gksxkA ,slh bdkbZ] 'ks;Çjx fofu;eksa ds fofu;e 13 ds vuqlkj ikjs"k.k
izHkkjksa ds Hkqxrku gsrq mŸkjnk;h gksxhA
10.9 la;kstdrk vuqnkuxzkgh ml vkj,yMhlh dks gLrk{kfjr la;kstdrk djkj dh izfr izLrqr djsxh ftlds
fu;a=.k {ks= esa og fLFkr gSA
10.10 la;kstdrk vuqnkuxzkgh] la;kstdrk ds fy, lhbZ, rduhdh ekudksa ds mica/kksa dk ikyu djsxkA
11.

la;kstdrk vuqnkuxzkgh] leÆir ikjs"k.k ykbuksa lfgr vius {ks= ds v/khu dk;Z ds dk;kZUo;u dh fLFkfr
izR;sd frekgh esa uksMy ,tsalh dks v|ru djsxk tks bls viuh osclkbV ij v|ru djsxhA
11.2 uksMy ,tsl
a h] lHkh la;kstdrk vuqnkuxzkfg;ksa ds laca/k esa ,Vh,l vkSj VÆeuy cs ds dk;kZUo;u dh
fLFkfr izR;sd frekgh esa viuh osclkbV ij v|ru djsxhA
11.3 uksMy ,tsl
a h] fofu;e 11-1 ds v/khu ;Fkk izLrqr la;kstdrk vuqnkuxzkgh ds {ks= ds v/khu dk;Z ds
dk;kZUo;u dh fLFkfr vkSj fofu;e 11-2 ds v/khu ;Fkk v|frr ,Vh,l vkSj VÆeuy cs ds dk;kZUo;u dh
fLFkfr ds vk/kkj ij leh{kk djsxh vkSj lq/kkjkRed dkjZokbZ djsxhA
11.4 ikjs"k.k iz.kkyh ds b"Vre mi;ksx ds fy,] lacaf/kr la;kstdrk vuqnkuxzkgh ¼vuqnkuxzkfg;ks½a dh lgefr ds
vuqlkj uksMy ,tsl
a h] leku vkbZ,lVh,l lc&LVs'ku ds fofHkUUk VÆeuy cs ds chp la;kstdrk dh
iquO;ZoLFkk dj ldrh gSA
11.5 uksMy ,tsalh ekStwnk ;k izLrkfor vkbZ,lVh,l lc&LVs'kuksa ij VÆeuy cs ds vkcaVu] vU; ckrksa ds
lkFk&lkFk] cs&okj vuqnŸk la;kstdrk dh ek=k vkSj 'ks"k ek=k ftlds fy, cs&okj la;kstdrk vuqnku dh
tk ldrh gS] dh v|frr fLFkfr viuh osclkbV ij iznÆ'kr djsxh vkSj bls ekfld vk/kkj ij v|frr
djsxhA
11.1

12.

;fn la;kstdrk vuqnkuxzkgh dksbZ mRiknu LVs'ku ;k dSfIVo mRiknu la;a= ;k LVSaMvyksu bZ,l,l gS] rks
leÆir ikjs"k.k ykbuksa dh LFkkiuk] izpkyu vkSj j[kj[kko ,sls la;kstdrk vuqnkuxzkgh }kjk fd;k tk,xkA
12.2 ;fn la;kstdrk vuqnkuxzkgh dksbZ uohdj.kh; fo|qr ikdZ fodkldrkZ gS] rks leÆir ikjs"k.k ykbuksa dh
LFkkiuk] izpkyu vkSj j[kj[kko ,sls uohdj.kh; fo|qr ikdZ fodkldrkZ }kjk fd;k tk,xkA
12.3 leÆir ikjs"k.k ykbuksa dk fuekZ.k vkSj j[kj[kko] fuekZ.k gsrq lhbZ, rduhdh ekudksa ds vuqlkj fd;k
tk,xkA
12.4 vkbZ,lVh,l lc&LVs'ku ij VÆeuy cs] vkbZ,lVh,l lc&LVs'ku ds LokfeRo okys ikjs"k.k vuqKfIr/kkjh ds
dk;Z{ks= ds v/khu gksxh%
ijarq ;g fd la;kstdrk vuqnkuxzkgh] ;fn ,slk pqurk gS] uksMy ,tsalh ds iwoZ vuqeksnu ds v/;/khu
vkbZ,lVh,l lc&LVs'ku ds LokfeRo okys ikjs"k.k vuqKfIr/kkjh ds lkFk djkj ds }kjk viuh ykxr ij
VÆeuy cs dk fuekZ.k vkSj j[kj[kko dj ldrk gS%
ijarq ;g vkSj fd ;fn la;kstdrk vuqnkuxzkgh viuh ykxr ij VÆeuy cs ds fuekZ.k dk pquko djrk gS]
rks viuh la;kstdrk ds izfrlagj.k dh n'kk esa la;kstdrk vuqnkuxzkgh }kjk ,sls VÆeuy cs ds fy, fdlh
ykxr dk nkok ugha fd;k tk ldrk%
ijarq ;g Hkh fd la;kstdrk ds izfrlagj.k ds ,sls ekeys esa] la;kstdrk vuqnkuxzkgh 3 ekl ds vanj
VÆeuy cs dks fo[kafMr djsxk ftlds u gksus ij lhVh;w fdlh vU; la;kstdrk vkosnd ds fy, cs dk
mi;ksx dj ldrh gSA
12.5 fofu;e 17-1(iii) ds v/khu doj bdkbZ ds ekeys esa] ,slh bdkbZ dks vkbZ,lVh,l ls tksM+us ds fy, ykbu
vkSj vkbZ,lVh,l dks la;kstu iznku djus ds fy, vko';d o`f) dk fuekZ.k vkSj j[kj[kko] ,slh bdkbZ
dh ykxr ij vuqKfIr/kkjh }kjk fd;k tk,xkA
12.1

<!-- page 12 -->

10

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

13.

la;kstdrk vuqnkuxzkgh] fxzM dksM ds mica/kksa ds vuqlkj v'kä fo|qr dk var%{ksi.k vkSj LVkVZ&vi fo|qr
dk vkgj.k djus ds ik= gksx
a sA
14.
14.1 dsUæh;

ikjs"k.k ;wfVfyVh }kjk bu fofu;eksa ds fofu;e 17-1(iii) ds v/khu doj fd, x, la;kstdrk
vuqnkuxzkgh vkSj th,u, vuqnkuxzkgh ds fy, vkSj mudh ykxr ij baVjQsl ehVj yxk, tk,axsA
14.2 fofu;e 14-1 ds v/khu laLFkkfir baVjQsl ehVj] dsUæh; ikjs"k.k ;wfVfyVh }kjk izkf/k—r fdlh O;fä ;k
izknsf'kd Hkkj izs"k.k dsUæ] ftlds fu;a=.k {ks= esa og fLFkr gS] }kjk fujh{k.k ds fy, [kqys jgsaxsA
15.
15.1 la;kstdrk

vuqnkuxzkgh] bu fofu;eksa ds fofu;e 15-2 vkSj fofu;e 15-3 ds v/khu ;Fkk micaf/kr dks
NksM+dj fdlh O;fä dks viuh la;kstdrk vkSj lac) vf/kdkjksa vkSj nkf;Roks]a iw.kZr;k ;k blds Hkkxksa dk]
varj.k] fuÆn"V ;k ladYi ugha djsx
a sA
ijarq ;g fd isjVsa daiuh dks vuqnŸk la;kstdrk bldh lgk;d daifu;ksa }kjk mi;ksx dh tk ldrh gS
vkSj lgk;d daifu;ksa dks vuqnŸk la;kstdrk] bldh isjVsa daiuh }kjk mi;ksx dh tk ldrh gSA

15.2 tgka la;kstdrk vuqnkuxzkgh vkjbZth,l gS, og bu fofu;eksa ds fofu;e 4-1 ds vuqlkj U;wure {kerk ds

v/;/khu, ,sls fgLls ds lhvksMh ds ckn, viuh dusfDVfoVh dks fgLlksa esa foHkkftr dj ldrk gS, vkSj
izR;sd fgLls dh laLFkkfir {kerk dks uksMy ,tsalh dks izLrqr dj ldrk gSA ,slh fLFkfr esa] la;kstdrk dks
çR;sd ,sls fgLls dh laLFkkfir {kerk ds vuqikr esa foHkkftr ekuk tk,xk%
ijarq ;g fd bu fofu;eksa ds vuqlkj lHkh nsunkfj;ka vkSj nkf;Ro izR;sd fgLls ds fy, la;kstdrk
vuqnkuxzkgh ds ikl cus jgsaxsA
15.3 fofu;e 15-2 ds lanHkZ esa dksbZ O;fä tks daiuh ;k mldh lgk;d daiuh ;k vkjbZth,l ds LokfeRo
okyh lgc) daiuh ;k mlds Hkkx dh 'ks;jgksÇYMx dk 51% ;k mlls vf/kd dk vf/kxzg.k djrk gS] rks
og ,sls foHkkftr fgLls dh lhvksMh ds ckn] la;kstdrk ds varj.k gsrq uksMy ,tsalh dks vkosnu dj
ldrk gSA uksMy ,tsl
a h] ,sls O;fä }kjk ykxw la;kstdrk&chth2 vkSj la;kstdrk&chth3 ds izLrqfrdj.k
ij la;kstdrk dk iqujhf{kr vuqnku tkjh djsxhA ewy vuqnkuxzkgh viuh la;kstdrk&chth2 vkSj
la;kstdrk&chth3 dks lhVh;w }kjk lwfpr dh tkus okyh iqujhf{kr la;kstdrk&chth2 vkSj
la;kstdrk&chth3 ds lkFk izfrLFkkfir dj ldrk gSA la;kstdrk dk iqujhf{kr vuqnku tkjh gksus ij] ,slk
O;fä u, la;kstdrk djkj djsxk vkSj lHkh ykxw fofu;eksa ds vuqikyu gsrq mŸkjnk;h gksxkA
ijarq ;g fd bu fofu;eksa ds vuqlkj lHkh nsunkfj;k¡ vkSj nkf;Ro] varfjr ugha dh xbZ la;kstdrk ds
fy,] ewy la;kstdrk vuqnkuxzkgh ds ikl cuh jgsaxhA
16.

la;kstdrk vuqnkuxzkgh }kjk iw.kZ {kerk ds okf.kfT;d izpkyu dh ?kks"k.kk ds 30 fnuksa ds vanj
la;kstdrk&chth1 okil dj nh tk,xhA
16.2 mRiknu {kerk] ftls la;kstdrk vuqnkuxzkgh }kjk okf.kfT;d izpkyu ds v/khu ?kksf"kr fd;k x;k gS] ds
rnuqlkj la;kstdrk&chth2 vkSj la;kstdrk&chth3 ikap o"kks± esa ikap cjkcj fgLlksa esa okil dj nh
tk,xhA
16.3 ns; rkjh[k ls 3 ekl ls vf/kd ds fy, 'ks;Çjx fofu;eksa ds fofu;e 13 ds v/khu ikjs"k.k izHkkjksa ds
xSj&Hkqxrku ds ekeys esa] ,sls ikjs"k.k izHkkjksa dks vis{kkuqlkj la;kstdrk&chth1 ¼;fn vfLrRo esa gS½]
la;kstdrk&chth2 vkSj la;kstdrk&chth3 ds udnhdj.k }kjk olwy fd;k tk,xkA la;kstdrk dks ml
rkjh[k ls izfrlaâr dj fn;k tk,xk tc ;Fkk miyC/k la;kstdrk&chth2 vkSj la;kstdrk&chth3] 'ks;Çjx
fofu;eksa ds fofu;e 13 ds v/khu ikjs"k.k izHkkjksa dks doj djus ds fy, i;kZIr ugha gSaA
16.4 fofu;e 16-3 ds lanHkZ esa udnh—r dh xbZ la;kstdrk&chth1] la;kstdrk&chth2 vkSj la;kstdrk&chth3 ls
vk; dks] 'ks;Çjx fofu;eksa ds v/khu ekfld ikjs"k.k izHkkjksa esa lek;ksftr fd;k tk,xkA
16.1

17.
17.1 fuEufyf[kr bdkb;ka th,u, ds vuqnku ;k th,u, dh ek=k esa o`f) gsrq vkosnu djus ds fy, vkosnd

ds :i esa ik= gksx
a h%

<!-- page 13 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

11

forj.k vuqKfIr/kkfj;ksa lfgr var% jkfT;d bdkb;ksa dh vksj ls jkT; ikjs"k.k ;wfVfyVh(
(ii) var% jkfT;d ikjs"k.k iz.kkyh ls tqM+h Øsrk bdkbZ(
(iii) 50 esxkokV vkSj mlls vf/kd Hkkj ds lkFk vkbZ,lVh,l ls lh/ks tqM+us dh ekax djus okyk forj.k
vuqKfIr/kkjh ;k Fkksd miHkksäk(
(iv) ØkWl ckWMZj fofu;eksa ds lanHkZ esa fo|qr ds ØkWl ckWMZj O;kikj esa izo`Ÿk O;kikj vuqKfIr/kkjh(
(v) vkuq"kafxd fo|qr ds vkgj.k ds fy, vkbZ,lVh,l ls tqM+s ikjs"k.k vuqKfIr/kkjhA
17.2 fofu;e 17-1 ds v/khu doj ugha dh xbZ bdkb;ka] tks fd bu fofu;eksa ds izo`Ÿk gksus dh rkjh[k ij]
vkbZ,lVh,l ls tqM+s gSa ;k ftUgsa la;kstdrk fofu;e] 2009 ds v/khu la;kstdrk vuqnku dh xbZ gS]
la;kstdrk dh ek=k ds cjkcj ek=k ds fy, vkbZ,lVh,l ls th,u, ds vuqnku gsrq vkosnu djus ds ik=
gSa] ftls bu fofu;eksa ds fofu;e 37-6 ds vuqlkj lalkf/kr fd;k tk,xkA
17.3 bu fofu;eksa ds fofu;e 17-1(iii) ds v/khu doj fd, x, vkosnd] VÆeuy cs dh 'ks;Çjx ds fy, vkosnd
vkSj mä bdkbZ ds chp fof/kor~ :i ls gLrk{kfjr djkj ds lkFk] bu fofu;eksa ds fofu;e 17-1(iii) ds
v/khu ,slh vU; bdkbZ dks igys ls gh vkcafVr fdlh vkbZ,lVh,l ds VÆeuy cs ls tqM+us dh ekax dj
ldrk gSA
(i)

18.
18.1 rkjh[k ij] ;s fofu;e izo`Ÿk gksrs gSa]

¼d½
¼i½ var% jkfT;d bdkbZ ¼bdkb;ks½a lfgr jkT; vkSj ¼ii½ vU; vnkdrkZ bdkb;ksa ds fy, th,u,] foÙkh;
o"kksZa 2018&19] 2019&20 vkSj 2020&21 ds fy, ^d^ dh vkSlr gksxk%
tgka]
^d^ ¾ ¿0-5 x o"kZ ds nkSjku VkbZe Cy‚d esa vf/kdre vkbZ,lVh,l vkgj.kÀ $ ¿0-5 x [o"kZ ds nkSjku ¼fnu esa
VkbZe Cy‚d esa vf/kdre vkbZ,lVh,l vkgj.k½ dk vkSlr]À
¼[k½
bl fofu;e ds [kaM ¼d½ ds vuqlkj ifjdfyr th,u,] bu fofu;eksa ds vuqyXud&I esa fn;k x;k gSA
¼x½
bl fofu;e ds [kaM ¼[k½ ds vuqlkj var% jkfT;d bdkbZ ¼bdkb;ks½a lfgr jkT; ds fy, th,u,] ,slh
var% jkfT;d bdkb;ksa dh vksj ls ml jkT; ds ,lVh;w dks vuqnÙk dh xbZ le>k tk,xk vkSj rc rd oS/k jgsxk
tc rd fd bu fofu;eksa ds vuqlkj mldk R;kx ugha fd;k tkrkA
¼?k½
bl fofu;e ds [kaM ¼x½ ds vuqlkj ,lVh;w dks vuqnÙk le>s x, th,u, dks] la;kstdrk fofu;e]
2009 ds vuqlkj çkIr nh?kZdkfyd igqap vkSj e/;dkfyd fuckZ/k igqap ds v/khu ¼ i½ çns'k ds vanj th,u, vkSj
¼ii½ çns'k ds vanj ;k çns'k ds ckgj] lafonkvksa ds vuqikr esa] çns'k ds ckgj ls th,u, ds :i esa bu fofu;eksa
dh vf/klwpuk ds 30 fnuksa ds vanj uksMy ,tsl
a h }kjk çdkf'kr fd;k tk,xkA
¼³½
bl fofu;e ds [kaM ¼?k½ ds vuqlkj ,lVh;w dks vuqnÙk le>s x, th,u, dks] lacaf/kr ,l,yMhlh
}kjk forj.k vuqKfIr/kkjh lfgr çR;sd var%jkfT;d bdkbZ ds fy, i`Fkd fd;k tk,xk vkSj bl fofu;e ds [kaM
¼?k½ ds v/khu uksMy ,tsalh }kjk fooj.kksa ds çdk'ku ds 1 ekl ds vanj ,lVh;w] uksMy ,tsalh vkSj ,u,yMhlh
dks lwfpr fd;k tk,xkA
ijarq ;g fd ;fn ,l,yMhlh ,slk i`FkDdj.k çnku djus esa foQy gksrk gS] rks tSlk dh 'ks;fjax fofu;eksa ds
v/khu fiNys ekl ds çFke fcy esa 'kkfey gS] çR;sd var%jkfT;d bdkbZ dks muds nh?kZdkfyd igqap vkSj
e/;dkfyd fuckZ/k igqap ds vuqikr esa ;Fkkuqikr th,u, vkcafVr fd;k tk,xkA
¼p½
bu fofu;eksa ds fofu;e 4-1 ds v/khu doj dh xbZ bdkbZ ¼bdkb;ka½ dks] tgka la;kstdrk fofu;e] 2009
ds v/khu ,slh bdkbZ dks ;k blds igpkus x, Øsrk dks vuqnÙk nh?kZdkfyd igqap çHkkoh gks pqdh gS] bu fofu;eksa
ds v/khu ,slh nh?kZdkfyd igqap dh ek=k ds cjkcj th,u, vuqnku fd;k x;k le>k tk,xkA
¼N½
dsUæh; mRiknu LVs'ku tks fxzM ls tM+s gSa vkSj ftUgsa la;kstdrk fofu;e] 2009 ds v/khu nh?kZdkfyd
igqap vuqnku ugha dh xbZ gS ijarq ftudh fo|qr dks fo|qr ea=ky; }kjk vkcafVr fd;k x;k gS] mUgsa ,sls mRiknu
LVs'ku ¼LVs'kuks½a dh laLFkkfir {kerk ds cjkcj th,u, vuqnku fd;k x;k le>k tk,xkA
¼t½
O;kikj vuqKfIr/kkjh dks vuqnÙk nh?kZdkfyd igqap] Ø‚l c‚MZj fofu;eksa ds vuqlkj fo|qr ds Ø‚l c‚MZj
O;kikj ds vykok] bl fofu;e ds [kaM ¼d½ ls [kaM ¼p½ ds v/khu lacaf/kr fxzM ls tqM+h bdkbZ ¼bdkb;ks½a dks
vuqnÙk le>s x, th,u, dk fgLlk gksxh%
ijarq ;g fd ,sls O;kikj vuqKfIr/kkjh vkSj lacaf/kr fxzM ls tqM+h bdkbZ ¼bdkbZ;ks½a ds chp ikjs"k.k çHkkjksa dk
fuiVkjk muds chp ekStwnk djkj ds vuqlkj ;k ikjLifjd :i ls lgefr ds vuqlkj fd;k tk,xkA
¼>½
Ø‚l c‚MZj fofu;eksa ds vuqlkj fo|qr ds Ø‚l c‚MZj O;kikj esa yxs O;kikj vuqKfIr/kkjh dks vuqnÙk
nh?kZdkfyd igqap dks ,sls nh?kZdkfyd igqap dh vof/k ds fy, bu fofu;eksa ds v/khu ,sls O;kikj vuqKfIr/kkjh dks
vuqnÙk th,u, le>k tk,xkA

<!-- page 14 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

18.2 mu

bdkb;ksa dk fooj.k dks ftUgsa bu fofu;eksa ds v/khu th,u, vuqnku fd;k leÖkk x;k gS] bu
fofu;eksa ds izHkkoh gksus ds 1 ¼,d½ ekl ds vanj uksMy ,tsalh }kjk viuh osclkbV ij izdkf'kr fd;k
tk,xkA

19.
19.1 bu fofu;eksa ds izHkkoh gksus ds 3 ekl ds vanj ,lVh;w] izn's k ds vanj vkSj izn's k ls ckgj th,u, n'kkZrs

gq,] forj.k vuqKfIr/kkfj;ksa lfgr] var%jkfT;d bdkb;ksa dh vksj ls bu fofu;eksa ds [kaM ¼d½ ls [kaM ¼³½
ds v/khu ¼bdkbZ&okj i`FkDdj.k ls lkFk½ vuqnŸk leÖkh xbZ th,u, ls vf/kd vfrfjä th,u, ds fy,
vkosnu dj ldrk gSA
19.2 forj.k vuqKfIr/kkfj;ksa lfgr var%jkfT;d bdkb;ksa dh vksj ls ,lVh;w] tSlk fd fofu;e 39-1 ds vuqlkj
tkjh [kla;kstdrk vkSj th,u, ds fy, foLr`r fØ;kfof/k[k esa fu/kkZfjr gS] izns'k ls th,u, vkSj izns'k ds
ckgj ls th,u, n'kkZrs gq, ¼bdkbZ&okj i`FkDdj.k ls lkFk½ vxys 3 ¼rhu½ foŸkh; o"kks± ds fy, vfrfjä
th,u, ds fy, izR;sd o"kZ flrEcj ds ekl rd foŸkh; o"kZ ¼ml foŸkh; o"kZ] ftlesa ;s fofu;e izHkkoh
gq,] ds ckn ds foŸkh; o"kZ ls vkjaHk djrs gq,½ esa ,d ckj vkosnu dj ldrk gS%
ijarq ;g fd vxys rhu foŸkh; o"kks± esa ls izR;sd esa ,slh vfrfjä tksM+s tkus okyh th,u, dh ek=k]
lacaf/kr foŸkh; o"kZ dh fofuÆn"V rkjh[k ls ykxw gksxhA
20.
20.1 bu fofu;eksa ds fofu;e 17-1 ds [kaM ¼ii½ vkSj [kaM ¼iii½ ds v/khu doj dh xbZ bdkb;ka] fofuÆn"V ek=k

ds fy,] vkSj X;kjg ekl ls vf/kd dh fofuÆn"V vof/k ds fy,] fofuÆn"V rkjh[k ls] izn's k ds vanj vkSj
izn's k ds ckgj ls th,u, dk f}Hkktu n'kkZrs gq, th,u, ds fy, vkosnu dj ldrh gSaA
ijarq ;g fd bu fofu;eksa ds fofu;e 17-1 ds [kaM ¼ii½ ds v/khu doj dh xbZ bdkb;ka] th,u, dh ,slh
ek=k vkSj vof/k ds fy, var%jkfT;d ikjs"k.k iz.kkyh esa ikjs"k.k {kerk dh miyC/krk ds vuqlkj lacaf/kr
,lVh;w dh lgefr izLrqr djsaxhA
20.2 bu fofu;eksa ds fofu;e 17-1¼iv½ ds v/khu doj dh xbZ bdkb;ka] X;kjg ekl ls vf/kd dh fofuÆn"V
vof/k ds fy,] fofuÆn"V ek=k ds fy,] Hkkjrh; fxzM dks var%{ksi.k ;k Hkkjrh; fxzM ls vkgj.k ds fy,
th,u, gsrq i`Fkd :i ls vkosnu dj ldrh gSaA
20.3 bu fofu;eksa ds fofu;e 17-1 ds [kaM ¼v½ ds v/khu doj dh xbZ bdkb;ka] fofuÆn"V ek=k ds fy,] vkSj
X;kjg ekl ls vf/kd dh fofuÆn"V vof/k ds fy,] fofuÆn"V rkjh[k ls th,u, ds fy, vkosnu dj
ldrh gSaA
21.

vfrfjä th,u, ds vuqnku gsrq izkIr vkosnuksa ds vk/kkj ij uksMy ,tsl
a h] vf/kfu;e ds v/khu cuk, x,
fu;eksa ,oa fofu;eksa vkSj vf/kfu;e ds v/khu fofuÆn"V lhbZ, ikjs"k.k fu;kstu ekunaM ds vuqlkj iz.kkyh dk
v/;;u djsxhA
22.
22.1

¼d½ uksMy ,tsl
a h] bu fofu;eksa ds fofu;e 19-1 ds v/khu çkIr lHkh vkosnuksa dks vkosnu dh çkfIr ds vafre
fnu ls nks ekl ds vanj ,d&lkFk lalkf/kr djsxh vkSj miyC/k ikjs"k.k {kerk] ;k ;Fkkuqikr] ;fn vko';d gks]
ds vk/kkj ij ,lVh;w dks vfrfjä th,u, dk vuqnku djsxhA ,d ckj vuqnÙk fd;k x;k th,u,] R;kx fn,
tkus rd oS/k jgsxhA
¼[k½ uksMy ,tsalh] ml rkjh[k dks n'kkZrs gq, ftlls ,slh vfrfjä th,u, çHkkoh gksxh] miyC/k ikjs"k.k
{kerk ;k o`f) dh le;js[kk dks /;ku esa j[krs gq,] mlh foÙkh; o"kZ ds 31 ekpZ rd bu fofu;eksa ds fofu;e
19-2 ds v/khu çkIr vkosnuksa ds vk/kkj ij ,lVh;w dks vfrfjä th,u, dk vuqnku djsxhA ,d ckj vuqnÙk
fd;k x;k th,u,] R;kx fn, tkus rd oS/k jgsxhA
¼x½
,lVh;w dk dqy th,u,] fofu;e 18-1 ds v/khu vuqnÙk le>s x, th,u, vkSj bl fofu;e ds v/khu
vuqnÙk vfrfjä th,u, dk ;ksx gksxkA
¼?k½
fofu;e 19-1 ds v/khu ,lVh;w dks vuqnÙk le>k x;k var%jkfT;d bdkbZ&okj th,u, vkSj bl
fofu;e ds v/khu vuqnÙk vfrfjä th,u,] ,slh var%jkfT;d bdkb;ksa ds fy, 'ks;fjax fofu;eksa ds v/khu fcy
gsrq vk/kkj cusxhA

<!-- page 15 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

13

22.2

¼d½
bu fofu;eksa ds fofu;e 4-1 ds v/khu doj fd, x, la;kstdrk vuqnkuxzkfg;ksa dks] la;kstdrk ds vkjaHk
dh rkjh[k ls la;kstdrk dh ek=k ds cjkcj th,u, vuqnku fd;k x;k le>k tk,xkA bu fofu;eksa ds fofu;e
15 ds vuqlkj la;kstdrk ds foHkktu ;k varj.k dh n'kk esa] rnuq:ih th,u, dks ;FkkfLFkfr] foHkkftr ;k
varfjr le>k tk,xkA
¼[k½
uksMy ,tsalh fuEufyf[kr le;js[kk ds vuqlkj] th,u, ds vkjaHk dh rkjh[k dks fofufnZ"V djrs gq,
fofu;e 17-1 ds [kaM ¼ii½ ls ¼v½ ds v/khu doj dh xbZ bdkb;ksa dks th,u, dk vuqnku djsxh%
(i) tgka th,u, ekStwnk iz.kkyh ij vuqnŸk gS% ml ekl ds ckn ds ekl ds var rd ftlesa lHkh izdkj ls
laiw.kZ vkosnu izkIr gqvk gS(
(ii) tgka ikjs"k.k iz.kkyh dh o`f) vko';d gS% ml ekl ds 180 fnuksa ds vanj rd ftlesa lHkh izdkj ls
laiw.kZ vkosnu izkIr gqvk gS%
ijarq ;g fd uksMy ,tsalh ikjs"k.k iz.kkyh dh o`f) dh le;js[kk dks /;ku esa j[krs gq, th,u, ds
vkjaHk dh rkjh[k ls th,u, dk vuqnku djsxhA
¼x½
fofu;e 17-1 ds [kaM ¼iv½ ds v/khu doj dh xbZ bdkb;ka vkSj
¼i½ Hkkjrh; fxzM esa var%{ksi.k ds fy, th,u dk vkosnu djus okyh bdkb;ka fofu;e 4-1 ds v/khu bdkb;ksa ij
;Fkk ykxw lHkh vko';drkvksa dk vuqikyu djsaxh(
¼ii½ fofu;e 22-2 ¼x½¼i½ ds v/khu doj dh xbZ bdkb;ksa ds fy,] la;kstdrk&chth1] la;kst drk&chth2 vkSj
la;kstdrk&chth3] bu fofu;eksa ds fofu;e 16 ;k th,u, dh vof/k ds lekIr gksus ij] tks Hkh igys gks] ds
vuqlkj okil dh tk,xh(
¼iii½ Hkkjrh; fxzM ls vkgj.k ds fy, th,u, dk vkosnu djus okyh bdkb;ka] fofu;e 17-1¼iii½ ds v/khu
bdkb;ksa ij ;Fkk ykxw lHkh vko';drkvksa dk vuqikyu djsaxhA
¼?k½
bu fofu;eksa ds fofu;e 4-1 vkSj fofu;e 17-1 ds [kaM ¼iii½ ds v/khu doj dh xbZ bdkb;ka] th,u, ds
vkjaHk dh rkjh[k ls ,d ekl iwoZ th,u, dh ek=k ds fy, #- ,d yk[k çfr esxkokV dk ,deq'r th,u, çHkkj
çLrqr djsx
a hA ;fn bdkbZ }kjk ,sls çHkkj fofufnZ"V le;js[kk ds vanj çLrqr ugha fd, tkrs gSa] rks budh olwyh
vis{kkuqlkj la;kstdrk&chth1] la;kstdrk&chth2 vkSj la;kstdrk&chth3 ds udnhdj.k }kjk dh tk,xhA ,sls
,deq'r th,u, çHkkj dh çkfIr dks 'ks;fjax fofu;eksa ds v/khu ekfld ikjs"k.k çHkkjksa ds fy, mi;ksx fd;k
tk,xkA
ijarq ;g fd fofu;e 17-1¼iii½ ds v/khu doj dh xbZ bdkb;ka] 'ks;fjax fofu;eksa ds vuqlkj ,deq'r th,u, çHkkj
ds vfrfjä vius th,u, ds fy, ekfld ikjs"k.k çHkkjksa dk Hkqxrku djsaxhA
22.3 mu bdkb;ksa dk fooj.k ftUgsa ek=k] vof/k vkSj th,u, ds vkjaHk dh rkjh[k ds lkFk th,u, vuqnku fd;k
x;k gS] mUgsa th,u, ds vuqnku ds ,d ¼01½ ekl ds vanj uksMy ,tsalh }kjk mudh osclkbV ij
izdkf'kr fd;k tk,xkA
22.4 th,u, dh izHkkoh rkjh[k
¼d½ bu fofu;eksa ds fofu;e 4-1 ds v/khu doj fd, x, la;kstdrk vuqnkuxzkfg;ksa ds fy,] ,sls la;kstdrk
vuqnkuxzkfg;ksa ds th,u, dh çHkkoh rkjh[k] la;kstdrk ds vkjaHk dh rkjh[k ;k ,Vh,l dh lhvksMh] tks Hkh ckn
esa gks] gksxhA
ijarq ;g fd tgka ,Vh,l ds dsoy dqN ikjs"k.k ?kVdksa us ,Vh,l dh lhvksMh ls iwoZ lhvksMh çkIr dj yh gS
vkSj la;kstdrk vuqnkuxzkgh] viuh la;kstdrk dh vkaf'kd çHkko'khyrk dh ekax djrk gS] uksMy ,tsl
a h ikjs"k.k
ç.kkyh dh miyC/krk ds v/;/khu ,slh vkaf'kd la;kstdrk vkSj laxr th,u, dks çHkkoh cuk,xhA
ijarq ;g Hkh fd tgka ,sls th,u, dk çHkkoh gksuk ckdh gS] ,slh bdkbZ ,slh igqap dks MhEM Vh&th,u, tSlh ds
:i esa ekurs gq, ikjs"k.k ç.kkyh dh miyC/krk ds v/;/khu] viuh fo|qr dks ekaxh xbZ la;kstdrk dh ek=k ds
vkaf'kd ;k iw.kZ :i ls vuqlwfpr djus dh ik= gksxh vkSj mls Vh&th,u, çHkkjksa dk Hkqxrku djus dh
vko';drk ugha gksxhA
¼[k½ fofu;e 17-1 ds v/khu doj dh xbZ bdkb;ksa ds fy,] ;fn th,u, ds vuqnku ds le; igpkuh gqbZ
o`f) dh lhvksMh dks /;ku esa j[krs gq, th,u, ds vuqnku esa lwfpr th,u, dh çHkkoh rkjh[k dks iqujhf{kr
fd;k tkuk gS] rks uksMy ,tsalh ,slh bdkb;ksa dks] th,u, dh iqujhf{kr çHkkoh rkjh[k ls de ls de 3 ¼rhu½
ekl iwoZ] ml iqujhf{kr rkjh[k dks bafxr djrs gq, uksfVl nsxh ftlls th,u, çHkkoh gksxhA
¼x½
fofu;e 17-1 ds v/khu doj dh xbZ bdkb;ksa ds fy, uksMy ,tsalh] tgka ,slh bdkbZ vuqnÙk th,u, dh
laiw.kZ ;k vkaf'kd ek=k ds fy, ml rkjh[k dks vkxs c<+kus ds fy, ftlls th,u, çHkkoh gksxh] ikjs"k.k ç.kkyh
dh miyC/krk ds v/;/khu ,slh th,u, dks çHkkoh cuk,xhA

<!-- page 16 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

23.
23.1 fofu;e 17-1 ds v/khu doj dh xbZ bdkbZ] tks fd th,u, vuqnkuxzkgh gS] ijLij lger fuca/kuksa vkSj

'krks± ij ,d le; ij 1 ¼,d½ o"kZ ds de dh vof/k ds fy,] uksMy ,tsalh ds iwoZ vuqeksnu ds lkFk]
vius laiw.kZ ;k vkaf'kd th,u, dks fofu;e 17-1 ds v/khu doj vU; bdkb;ksa tks fd th,u, vuqnkuxzkgh
gSa] mi;ksx djus gsrq izkf/k—r dj ldrh gS%
ijarq ;g fd ikjs"k.k izHkkjksa ds fy, Hkqxrku ns;rk mlh ewy th,u, vuqnkuxzkgh dh jgsxh] ftlus vU;
th,u, vuqnkuxzkgh ¼vuqnkuxzkfg;ks½a dks viuh th,u, mi;ksx djus gsrq izkf/k—r fd;k gS%
ijarq ;g vkSj fd 'ks;Çjx fofu;eksa ds v/khu ikjs"k.k fopyu izHkkjksa dh lax.kuk djus ds iz;kstu gsrq]
vU; th,u, vuqnkuxzkgh ¼vuqnkuxzkfg;ks½a }kjk mi;ksx dh tkus okyh izkf/k—r th,u, dks ml ewy
th,u, vuqnkuxzkgh esa ls ?kVk fn;k tk,xk ftlus viuh th,u, dks vU; vuqnkuxzkgh ¼vuqnkuxzkfg;ks½a
}kjk mi;ksx fd, tkus gsrq izkf/k—r fd;k gS vkSj bls vU; th,u, vuqnkuxzkgh ¼vuqnkuxzkfg;ks½a dh
th,u, esa tksM+ fn;k tk,xk tks bldk mi;ksx djrh gSA
23.2 og vuqnkuxzkgh tks viuh th,u, dks vU; th,u, vuqnkuxzkgh ¼vuqnkuxzkfg;ks½a }kjk mi;ksx fd, tkus
dks izkf/k—r djus dk bPNqd gS] og la;kstdrk ds fy, foLr`r fØ;kfof/k vkSj fofu;e 39-1 ds vuqlkj
tkjh fd, x, th,u, ds vuqlkj uksMy ,tsalh dks vkosnu djsxkA

24.
24.1 la;kstdrk vuqnkuxzkgh] iw.kZ ;k vkaf'kd :i ls] la;kstdrk dk R;kx uksMy ,tsl
a h dks 30 fnuksa ds uksfVl

ds lkFk dj ldrk gSA uksMy ,tsalh] ,sls vuqnkuxzkgh dks la;kstdrk dk iqujhf{kr vuqnku tkjh djsxh
;fn la;kstdrk dk R;kx vkaf'kd :i ls fd;k x;k gSA
24.2 fofu;e 7-2 ds v/khu doj bdkb;ksa ds fy, vkSj tgka bu fofu;eksa ds fofu;e 8-2 ds vuqlkj ;Fkk ykxw
la;kstdrk&chth2 vkSj la;kstdrk&chth3 izLrqr dh xbZa gS] fuEufyf[kr ykxw gksxk%
¼d½ la;kstdrk dh laiw.kZ ek=k ds R;kx ds ekeys esa] ¼i½ ekStwnk la;kstdrk&chth1 dk udnhdj.k gksxk] ¼ii½
ekStwnk la;kstdrk&chth2 dk udnhdj.k gksxk ;fn VfeZuy cs igys ls gh fodflr gSa ;k ftudk fuekZ.k
dk;kZUo;u ds fy, igys gh vokMZ fd;k tk pqdk gS vkSj ¼iii½ ekStwnk la;kstdrk&chth3 dk udnhdj.k gksxkA
¼[k½ la;kstdrk dh vkaf'kd ek=k ds R;kx ds ekeys esa] ¼i½ ekStwnk la;kstdrk&chth2 dk udnhdj.k
la;kstdrk dh R;kxh xbZ ek=k ds vuqikr esa gksxk ;fn VfeZuy cs igys ls gh fodflr gSa ;k ftudk fuekZ.k
dk;kZUo;u ds fy, igys gh vokMZ fd;k tk pqdk gS vkSj ¼ ii½ ekStwnk la;kstdrk&chth3 dk udnhdj.k
la;kstdrk dh R;kxh xbZ ek=k ds rnuq:i gksxkA la;kstdrk&chth1 dks fofu;e 16-1 ds vuqlkj iw.kZ {kerk ij
fopkj djrs gq, ,slh R;kxh xbZ ek=k dks NksM+dj okil dj fn;k tk,xkA
24.3 fofu;e 7-2 ds v/khu doj bdkb;ksa ds fy, vkSj tgka bu fofu;eksa ds fofu;e 8-3 ds vuqlkj
la;kstdrk&chth2 dks izLrqr fd;k x;k gS] fuEufyf[kr ykxw gksxk%
¼d½ la;kstdrk dh laiw.kZ ek=k ds R;kx ds ekeys esa] ekStwnk la;kstdrk&chth1 dk udnhdj.k gksxk vkSj
ekStwnk la;kstdrk&chth2 dk udnhdj.k ,Vh,l vkSj VfeZuy cs ds rnuq:i gksxk ftudk fuekZ.k dk;kZUo;u ds
fy, igys gh vokMZ fd;k tk pqdk gSA
¼[k½ la;kstdrk dh vkaf'kd ek=k ds R;kx ds ekeys esa] ekStwnk la;kstdrk&chth2 dk udnhdj.k ,Vh,l
vkSj VfeZuy cs ds rnuq:i la;kstdrk dh R;kxh xbZ ek=k ds vuqikr esa gksxk ftudk fuekZ.k dk;kZUo;u ds
fy, igys gh vokMZ fd;k tk pqdk la;kstdrk&chth1 dks fofu;e 16-1 ds vuqlkj iw.kZ {kerk ij fopkj djrs
gq, ,slh R;kxh xbZ ek=k dks NksM+dj okil dj fn;k tk,xkA
24.4 la;kstdrk ds izfrlagj.k ;k la;kstdrk ds R;kx ds ekeys esa] rnuq:ih th,u, dks de dj fn;k
tk,xkA ;fn la;kstdrk vuqnkuxzkgh la;kstdrk dk iw.kZ :i ls R;kx djrk gS] rks mls la;kstdrk ds
R;kx dh rkjh[k ls vkbZ,lVh,l ls fo;ksftr dj fn;k tk,xkA izfrlagj.k gksus ij] 'ks;Çjx fofu;eksa ds
fofu;e 13 ds v/khu rnuq:ih ek=k ds fy, dksbZ fcÇyx ugha gksxhA
24.5 bu fofu;eksa ds fofu;e 24-2 ;k fofu;e 24-3 ds vuqlkj] udnh—r la;kstdrk&chth1] la;kstdrk&chth2
vkSj la;kstdrk&chth3 dh izkIr jkf'k dks 'ks;Çjx fofu;eksa ds v/khu ?kVrs gq, ekfld ikjs"k.k izHkkjksa ds
fy, mi;ksx fd;k tk,xkA
25.

<!-- page 17 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

15

25.1 fofu;e

17-1 ds v/khu doj bdkbZ ds fy,] ,d ckj vuqnŸk th,u, dk iw.kZr;k ;k vkaf'kd :i ls
R;kx] fuEufyf[kr ds vuqlkj] vfxze :i ls R;kx izHkkjksa ds Hkqxrku ij] uksMy ,tsl
a h dks 30 fnuksa ds
uksfVl ds lkFk fd;k tk ldrk gS%
¼d½ bu fofu;eksa ds fofu;e 17-1 ds [kaM ¼i½ ds v/khu doj bdkbZ ds fy, ,lVh;w] igpkuh xbZ
var%jkfT;d bdkbZ dh vksj ls th,u, dk R;kx dj ldrh gSA R;kx çHkkj] R;kxh xbZ ek=k ds rnuq:i] 'ks;fjax
fofu;eksa ds v/khu vafre fcfyax ekl ds fy, ,slh var%jkfT;d bdkbZ }kjk Hkqxrku fd, x, ikjs"k.k çHkkjksa ds
24 xquk ds cjkcj gksx
a sA
¼[k½ bu fofu;eksa ds fofu;e 17-1 ds [kaM ¼ii½ ls [kaM ¼iv½ ds v/khu doj bdkb;ksa ds fy, R;kx çHkkj]
R;kxh xbZ ek=k ds rnuq:i] 'ks;fjax fofu;eksa ds v/khu vafre ekl ds fy, ,slh bdkbZ }kjk Hkqxrku fd, x,
ikjs"k.k çHkkjksa ds 24 xquk ds cjkcj gksx
a sA
ijarq ;g fd ;fn th,u, dh 'ks"k vof/k 24 ekl ls de gksrh gS rks R;kx çHkkj] R;kxh xbZ ek=k ds rnuq:i]
'ks;fjax fofu;eksa ds v/khu vafre ekl ds fy, ,slh bdkbZ }kjk Hkqxrku fd, x, ikjs"k.k çHkkjksa ds 'ks"k ekl dh
la[;k ds cjkcj gksx
a sA
¼x½
bl fofu;e ds [kaM ¼d½ vkSj [kaM ¼[k½ ds v/khu çkIr gq, R;kx çHkkjksa dks] 'ks;fjax fofu;eksa ds v/khu
?kVrs gq, ekfld ikjs"k.k çHkkjksa ds fy, mi;ksx fd;k tk,xkA
¼?k½
bu fofu;eksa ds fofu;e 17-1 ds [kaM ¼iii½ ds v/khu doj bdkbZ }kjk th,u, dh laiw.kZ ek=k ds R;kx
ij] ,slh bdkbZ dks fxzM ls fo;ksftr dj fn;k tk,xkA
25.2 ;fn fofu;e 17-1 ds [kaM ¼i½ ds v/khu doj th,u, okys forj.k vuqKfIr/kkjh lfgr var%jkfT;d bdkbZ]
fofu;e 17-1 ds [kaM ¼ii½ ds v/khu th,u, ds lkFk izfrLFkkfir djrh gS] rks ,slh var%jkfT;d bdkbZ ds
fy, th,u, dks ,slh izfrLFkkfir ek=k ds fy, vkSj ,slh izfrLFkkfir vof/k ds fy,] fofu;e 22-1 ds [kaM
¼x½ ds v/khu ,lVh;w dh j[kh xbZ dqy th,u, esa ls ?kVk fn;k tk,xkA

26.
26.1 fuEufyf[kr bdkb;ka] vkbZ,lVh,l dks Vh&th,u, gsrq vkosnu djus ds fy, vkosnd ds :i esa ik= gksx
a h%

¼d½

Øsrk ds :i es]a
¼i½ vkbZ,lVh,l ls lh/ks tqM+s forj.k vuqKfIr/kkjh(
¼ii½ vkbZ,lVh,l ls lh/ks tqM+s Fkksd miHkksäk(
¼iii½ var%jkfT;d ç.kkyh ;k ,slh var%jkfT;d ikjs"k.k ç.kkyh ls tqM+h forj.k ç.kkyh ls tqM+h Øsrk
bdkbZ(
¼iv½ fo|qr cktkj fofu;eksa ds fofu;e 6 ds [kaM ¼3½ ds vuqlkj viuh vkuq"kafxd [kir ;k LVkVZ&vi
fo|qr dks iwjk djus ds fy, ;k vius vkiwfrZ nkf;Roksa dks iwjk djus ds fy, vkjbZth,l lfgr mRiknu
LVs'ku(
¼v½ dSfIVo mRiknu la;a=(
¼vi½ LVSaMvyksu bZ,l,l(
¼vii½ xSj&mRiknu ?kaVksa ds nkSjku vkgj.k gsrq vkjbZth,lA
¼[k½ Hkkjrh; fxzM dks var%{ksi.k ;k blls vkgj.k ds fy, ¼i½ bl fofu;e ds [kaM ¼d½ ds v/khu doj Øsrk
¼Øsrkvks½a dh vksj ls] vkSj ¼ii½ Ø‚l c‚MZj fofu;eksa ds vuqlkj fo|qr ds Ø‚l c‚MZj O;kikj esa yxs gq, O;kikj
vuqKfIr/kkjhA
¼x½
Hkkjrh; fxzM dks var%{ksi.k ;k blls vkgj.k ds fy, ¼i½ bl fofu;e ds [kaM ¼d½ ds v/khu doj Øsrk
¼Øsrkvks½a ] vkSj ¼ii½ Ø‚l c‚MZj fofu;eksa ds vuqlkj fo|qr ds Ø‚l c‚MZj O;kikj esa yxs gq, O;kikj vuqKfIr/kkjh
¼vuqKfIr/kkfj;ks½a dh vksj ls lkewfgd laO;ogkjksa ;k f}i{kh; laO;ogkjksa ds fy, ikoj ,Dlpst
a A
26.2 th,u, vuqnkuxzkgh] mls vuqnŸk th,u, ls vf/kd Vh&th,u, ds fy, vkosnu djus gsrq bl fofu;e ds
fofu;e 26-1 ds [kaM ¼d½ ds v/khu ik=rk ds vuqlkj ik= gksxkA
26.3 Vh&th,u, vkosnu] Çlxy ÇoMks bysDVªkWfud IysVQkWeZ vFkkZr~ jk"Vªh; fuckZ/k igqap jftLVªh ¼,uvks,vkj½ ds
ek/;e ls fd, vkSj lalkf/kr fd, tk,axsA

<!-- page 18 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

27.
27.1 ,uvks,vkj fuEufyf[kr djsx
a s%

Vh&th,u, vkosnuksa dh ys[kkijh{kk dk iFk&ekxZ iznku djuk(
(ii) Vh&th,u, vkosnuksa ds lalk/ku gsrq vkj,yMhlh vkSj ,l,yMhlh ds lkW¶Vos;j ds lkFk baVjQsl
iznku djuk(
(iii) LVSaÇMx fDy;jsal ds izek.ku vkSj var%fnol] Ms vgsM vkdfLedrk] VeZ&vgsM] Ms&vgsM vkSj
okLrfod le; laO;ogkjksa ds lalk/ku gsrq ikoj ,Dlpst
a ds lkFk baVjQsl iznku djuk(
(iv) Vh&th,u, ls lacaf/kr Hkqxrku djus gsrq Hkqxrku xsVos iznku djuk(
(v) vkj,yMhlh vkSj ,l,yMhlh dks okLrfod le; lwpuk ds lkFk MS'k cksMZ lqfo/kk iznku djuk
vkSj vkj,yMhlh vkSj ,l,yMhlh }kjk tkjh LVSaÇMx fDy;jsal] ikjs"k.k dkWfjMksj dh miyC/krk]
yafcr vkosnu] vkSj vunŸk Vh&th,u, vkSj jÌ Vh&th,u, lfgr Vh&th,u, ls lacaf/kr lwpuk
ds HkaMkj&x`g ds :i esa dk;Z djuk(
(vi) cktkj tkap vkSj fuxjkuh ds fy, lkef;d fjiksVZ cukus dh lqfo/kk iznku djuk(
(vii) le;&le; ij vk;ksx }kjk ;Fkk funsf'kr dksbZ vU; dk;Z dh lqfo/kk iznku djukA
27.2 ,u,yMhlh] ,uvks,vkj ds fodkl vkSj j[kj[kko ds fy, mŸkjnk;h gksx
a s vkSj ,uvks,vkj dks izpkfyr djus
gsrq fofu;e 39-2 ds vuqlkj tkjh Vh&th,u, ds fy, foLr`r fØ;kfof/k tkjh djukA
(i)

28.
28.1 Vh&th,u, ds fy, vkosnu] 1 ¼,d½ le; CykWd ls vkSj 11 ¼X;kjg½ ekl rd dh fdlh vof/k ds fy,

fd;k tk ldrk gSA
28.2 fdlh fofuÆn"V ek=k vkSj fofuÆn"V le; vof/k ds fy, uksMy ,tsl
a h dks Vh&th,u, ds vuqnku gsrq
vkWuykbu vkosnu] ikap gtkj #i, ¼#- 5000@&½ dh vizfrns; Qhl ds lkFk fd;k tk,xkA
28.3 vkWuykbu vkosnu dh izkfIr ds fy, Lor%tfur ikorh tkjh dh tk,xhA ikorh esa vkosnu dh izkfIr dk
le; vkSj rkjh[k gksx
a s vkSj bls Vh&th,u, ds vuqnku gsrq vkosnu ds fnu ¼Mh½ ds :i esa ekuk tk,xkA
28.4 Vh&th,u, ds vuqnku ds fy, vkosnu fuEufyf[kr fdlh Hkh Js.kh ds v/khu fd;s tk,axs%
d- f}i{kh; laO;gkjksa ds fy,
¼d½ Vh&th,u, ds vuqnku ds fy, vfxze vkosnu% ¼Mh$3½ fnol dks ;k mlds ckn vkjaHk gksus okys
Vh&th,u, ds vuqnku ds fy, fnol ¼Mh½ ij fd;k x;k vkosnu] tks fnol ¼Mh½ ;k ijorhZ ekg ds :i
esa mlh ekg esa vkrk gSA
¼[k½ Vh&th,u, ds vuqnku ds fy, vR;ko';d vkosnu% ¼,l½ fnol ds fy, 'ksMîwfyax lfgr
Vh&th,u, ds vuqnku ds fy, ¼Mh½ fnol ij fd;k x;k vkosnu tks 7¼lkr½ Vkbe&CykWdksa ds U;wure
vkjafHkd le; ds lkFk ¼Mh½ fnol ;k ¼Mh$1½ fnol ;k ¼Mh$2½ fnol gks ldrk ldrk gS tcrd fd
fxzM dksM esa vU;Fkk fofuÆn"V u fd;k x;k gks%
ijarq fd Vh&th,u, ds vuqnku ds fy, vR;ko';d vkosnu fnol ¼,l½ ds 0000 ?kaVs ls 2400 ?kaVksa ds
chp fdlh Vkbe&CykWd¼CykWdks½a ds fy, fd;k tk,xkA
[k- lkewfgd laO;ogkjksa ds fy,
vkonsu fofu;e 39-2 ds vuqlkj tkjh fd;s x;s Vh&th,u, ds fy, foLr`r fØ;kfof/k esa ;Fkkfu/kkZfjr ikoj ,Dlpst
a
}kjk fd;k tk,xkA
f}i{kh; laO;ogkjksa ds fy, Vh&th,u+, ds vuqnku ds fy, vkosnu esa fuEufyf[kr 'kkfey gksx
a s:
¼d½ vfxze vkosnu dh Js.kh:
(i)

esxkokV esa Vh&th,u, dh ek=k;

(ii)

Vkbe&CykWd vkSj rkjh[k ds vuqlkj Vh&th,u, dk izkjafHkd le; ;

(iii) Vkbe&CykWd vkSj rkjh[k ds vuqlkj Vh&th,u, dk vafre le;;
(iv) var%{ksi.k

dk IokbaV] ;fn miyC/k gS] ;k var%{ksi.k ds IokbaV ds vHkko esa yf{kr var%{ksi.k

{ks=;
ijarq fd ØkWl ckMZj fofu;eksa ds vuqlkj fo|qr ds ØkWl ckMZj O;kikj dh fLFkfr esa Hkkjrh; fxzM
esa var%{ksi.k ds ekeys esa var%{ksi.k dk IokbaV vkosnu lfgr izLrqr fd;k tk,xkA

<!-- page 19 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

17

vkgj.k dk IokbaV;
(vi) ,l,yMhlh fd LFkk;h Dyh;jsal ftlds {ks=kf/kdkj ds v/khu vkgj.k dk IokbaV fLFkr gS ;fn
Øsrk ,d var%jkfT;d bdkbZ gS;
(vii) ;fn foØsrk ,d var%jkfT;d bdkbZ gS vkSj var%{ksi.k dk IokbaV miyC/k gS rks ,l,yMhlh
dk LFkk;h Dyh;jsal ftlds {ks=kf/kdkj ds v/khu var%{ksi.k dk IokbaV fLFkr gSA
ijarq fd var%{ksi.k ds IokbaV rFkk ,l,yMhlh ds rnuq:ih LFkk;h Dyh;jsal ds ekeys esa ftlds
{ks=kf/kdkj ds v/khu var%{ksi.k dk IokbaV fLFkr gS vkSj vkosnu djrs le; miyC/k ugha gS rks bls bu
fofue;ksa ds fofu;e 33 ds vuqlkj 'ksMîwfyax vuqjks/k ds lkFk izLrqr fd;k tk,xkA
(viii) ;fn foØsrk izknsf'kd bdkbZ gS vkSj var%{ksi.k dk IokbaV vkosnu djrs le; miyC/k ugha gS
rks var%{ksi.k dk IokbaV bu fofu;eksa ds foue; 33 ds vuqlkj 'ksMîwfyax vuqjks/k lfgr izLrqr
fd;k tk,xkA
(v)

¼[k½ vR;ko';d vkosnu Js.kh:
(i)
var%{ksi.k dk IokbaV ij vuqlwfpr fd;k tkus okyk ikoj ¼,eMCY;w½ dh dkUVªsDV dh x;h
ek=k;
(ii)

Vkbe&CykWd vkSj rkjh[k ds vuqlkj Vh&th,u, dk vkjafHkd le;;

(iii)

Vkbe&CykWd vkSj rkjh[k ds vuqlkj Vh&th,u, dk vafre le;;

(iv)

var%{ksi.k dk IokbaV;

vkgj.k dk IokbaV;
(vi) ,l,yMhlh dh LFkk;h Dyh;jsal ftlds {ks=kf/kdkj ds v/khu vkgj.k dk IokbaV vkSj
var%{ksi.k dk IokbaV fLFkr gS ;fn Øsrk ;k vkiwÆrdrkZ var%jkfT;d bdkbZ gS] tSlk ykxw gSA
(vii) fo|qr ds fcØh vkSj Ø; ds fy, dkUVªsDV dh izfr
f}i{kh; laO;ogkjksa ds v/khu Vh&th,u, ds vuqnku ds fy, vkosnu esa vkosnd }kjk fuEufyf[kr ?kks"k.kkvksa dks 'kkfey
fd;k tk,xk%
¼d½
fd fxzM ds mica/kksa ds vuqlkj VkbZe&CykWd okj ehVÇjx vkSj ys[kkadu ds fy, vko';d volajpuk vkSj lapkj
fofue;ksa ds mica/kksa ds vuqlkj mi;qä lapkj iz.kkyh vkgj.k ds IokbaV vkSj var%{ksi.k ds IokbaV] ;fn miyC/k
gks] ds fy, mi;qä LFkku esa gSA
¼[k½
fd Vh&th,u, ds fy, vfxze vkosnu djrs le; ;fn var%{ksi.k dk IokbaV irk ugha yxk;k x;k gS rks fxzM
dksM ds mica/kksa ds vuqlkj &CykWd okj ehVÇjx vkSj ys[kkadu ds fy, vko';d volajpuk dh miC/krk]
var%{ksi.k ds IokabV ds fy, lapkj fofu;eksa ds mica/kksa ds vuqlkj mi;qä lapkj iz.kkyh vkSj ,l,yMhlh dh
LFkk;h Dyh;jsal ;fn foØsrk ,d var%jkfT;d bdkbZ gS ftlds {ks=kf/kdkj ds v/khu bl izdkj ds var%{ksi.k dk
IokabV fLFkr gS bu fofu;eksa ds fofu;e 33 ds vuqlkj 'ksMîwfyax vuqjks/k lfgr izLrqr dh tk,xhA
¼x½
fd vkosnd Vh&th,u, ds v/khu laO;ogkjksa ls ifj.kker% ;k m˜wr FkMZ ikVhZ dks ;k mlds }kjk fdlh vU;
ck/;rkvksa rFkk fdlh vkSj lHkh nkoks]a dkjZokb;ksa ls fdlh Hkh le; ij uksMy ,tsl
a h ls {kfriwÆr djrk gSA
¼?k½
fd izLrkfor 'ksMîwfyax ds fy, oS/k dkUVªsDV gSA
ijarq fd Vh&th,u, ds fy, vfxze vkosnu ds ekeys esa ;g ?kks"k.kk fd izLrkfor 'ksMîwfyax ds fy, oS/k
dkUVªsDV gS izLrqr fd;k tk,xk ;fn bls bu fofu;eksa ds fofu;e 33 ds vuqlkj 'ksMîwfyax vuqjks/k lfgr
Vh&th,u, ds fy, vkonsu djus ds le; ij igys izLrqr ugha fd;k x;k gSA
ikoj ,Dlpst
a }kjk lkewfgd laO;ogkjksa ds fy, Vh&th,u, ds vuqnku ds fy, vkosnu esa izR;sd CykWd ds fy,
izknsf'kd bdkbZ okj var%{ksi.k ;k vkgj.k¼esxkokV½ 'kkfey fd;k tk,xkA
Vh&th,u, ds fy, vkosnu dks j) djus ds ekeys esa vkosnu Qhl tCr dh tk,xhA
(v)

Vh&th,u, dks th,u, vuqnkuxzkfg;ksa ds th,u, ds fy, ys[kkadu ds ckn vkbZ,lVh,l ij miyC/k varj.k {kerk ds
varxZr iznku fd;k tk,xkA
th,u, vuqnkuxzkfg;ksa dks vkbZ,lVh,l ds mi;ksx ds fy, Vh&th,u, vuqnkuxzkfg;ksa ij izkFkfedrk gksxhA
Vh&th,u, ds fy, vfxze vkosnuksa ij izFke vkvks izFke ikvks ds vk/kkj ij fopkj fd;k tk,xk vkSj vkosnu djus dh
rkjh[k gksus ls 'Mh' ij fnol ds 23-59 rd vf/kdre ¼Mh$1½ ij izksll
s fd;k tk,xkA

<!-- page 20 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

¼,l½ fnol ds fy, vuqlwph lfgr Vh&th,u, ds fy, vR;ko';d vkosnuksa dks fuEukuqlkj izksll
s fd;k tk,xkA
¼d½ ¼,l&1½ fnol ds 1300 ?kaVs rd izkIr vkosnu izFke vkvks izFke ikvks vk/kkj ij ¼,l&1½ fnol ij 1300
?kaVksa ds ckn izksll fd;k tk,xk vkSj fnol ¼,l&1½ ds 1400 ?kaVksa rd vafre :i fn;k tk,xkA
¼[k½ ¼,l&1½ fnol ;k ¼,l½ fnol esa 1300 ?kaVksa ds ckn izkIr vkosnuksa dks izFke vkvksa izFke ikvksa vk/kkj ij 4
Vkbe&CykWdksa ds varxZr izksll fd;k tk,xkA
MsvgsM cktkj ds varxZr lkewfgd laO;ogkjksa ds fy, Vh&th,u, dks fnol ¼,l&1½ ds 1300 ?kaVksa rd izksll
s fd;k
tk,xkA
okLrfod le; cktkj ds varxZr lkewfgd laO;ogkjksa ds fy, Vh&th,u, dks Vkbe&CykWd ds varxZr izksll
s fd;k
tk,xkA
uksMy ,tsl
a h fuEufyf[kr dks lR;kfir djsxh:
¼d½ var%jkfT;d bdkbZ ds ekeys esa :
(i) ;fn Øsrk ,d var%jkfT;d bdkbZ gS rks ,l,yMhlh ls LFkk;h Dyh;jsal ftlds {ks=kf/kdkj ds v/khu
vkgj.k dk IokbaV fLFkr gS ogka ;g iqf"V djrs gq, ¼d½ fxzM dksM ds mica/kksa ds vuqlkj ys[kkadu
vkSj Vkbe CykWd okj ÅtkZ ehVÇjx ds fy, vko';d volajpuk dk vfLrRo ¼[k½ lapkj fofu;eksa
ds mica/kksa ds vuqlkj mi;qä lapkj iz.kkyh ¼x½ var%jkfT;d usVodZ esa ikjs"k.k {kerk dh miyC/krk(
(ii) ;fn foØsrk ,d vr%jkfT;d bdkbZ gS vkSj var%{ksi.k dk IokbaV miyC/k gS rks ,l,yMhlh ls
LFkk;h Dyh;jsal fLFkr gS ogka ;g iqf"V djrs gq, ¼d½ fxzM dksM ds mica/kksa ds vuqlkj ys[kkadu
vkSj Vkbe CykWd okj ÅtkZ ehVÇjx ds fy, vko';d volajpuk dk vfLrRo ¼[k½ lapkj fofu;eksa
ds mica/kksa ds vuqlkj mi;qä lapkj iz.kkyh ¼x½ var%jkfT;d usVodZ esa ikjs"k.k {kerk dh miyC/krk(
(iii) vkbZ,lVh,l ij miyC/k varj.k {kerk(
(iv) fofu;e 28-6 esa ;Fkk iznŸk ?kks"k.kkvksa dks] ;Fkkykxw] izLrqr fd;k x;k gSA
([k) izknsf'kd bdkbZ ds ekeys esa :
(i) ;fn Øsrk ¼vkgj.k dk IokbaV½ izknsf'kd bdkbZ gS rks vkj,yMhlh ds ek/;e ls iqf"V ftlds
{ks=kf/kdkj ds v/khu bl izdkj dk vkgj.k dk IokbaV fLFkr gS:
¼d½ fxzM dksM ds mica/kksa ds vuqlkj Vkbe&CykWd okj ÅtkZ ehVÇjx vkSj ys[kkadu ds fy, vko';d
volajpuk dk vfLrRo vkSj
¼[k½ lapkj fofu;eksa ds mica/kksa ds vuqlkj mi;qä lapkj iz.kkyh.
(ii) ;fn foØsrk izknsf'kd fu;a=.k {ks= ds v/khu var%{ksi.k dk IokbaV j[kus okyh izknsf'kd bdkbZ gS
rks vkj,yMhlh ds ek/;e ls iqf"V djuk ftlds {ks=kf/kdkj ds v/khu var%{ksi.k dk bl izdkj dk
IokbaV fLFkr gS:
¼d½ fxzM dksM ds mica/kksa ds vuqlkj Vkbe&CykWd okj ÅtkZ ehVÇjx vkSj ys[kkadu ds fy,
vko';d volajpuk dk vfLrRo vkSj
¼[k½ lapkj fofu;eksa ds mica/kksa ds vuqlkj mi;qä lapkj iz.kkyh izo`Ÿk gSA
(iii) vkbZ,lVh,l ij miyC/k varj.k {kerk ¼,Vhlh½
(iv)
fofu;e 28-6 esa ;Fkk iznŸk ?kks"k.kkvksa dks] ;Fkkykxw] izLrqr fd;k x;k gS
,u,yMhlh ;k uksMj vkj,yMhlh] tSlh Hkh fLFkfr gks bu fofu;eksa ds fofu;e 29 esa fu/kkZfjr Vkbe ykbZu ds vuqlkj
vkosnd dks Vh&th,u, dk vuqnku djuk ;k vU;Fkk izsf"kr djsxkA Vh&th,u, dk vuqnku djus ds fy, vkosnu dks
jÌ djus dh fLFkfr esa] ,u,yMhlh ;k uksMy vkj,yMhlh] tSlh Hkh fLFkfr gks fyf[kr esa vkosnd dks bl izdkj jÌ djus
ds fy, dkj.k nsxkA
vkosnu fd;s x;s Vh&th,u, dh fLFkfr esa dks iw.kZ ek=k ds fy, vkSj ikjs"k.k iz.kkyh esa ck/kkvksa dks /;ku esa j[krs gq,
vkosnu esa ekaxh x;h iw.kZ vof/k dh Loh—fŸk ugha nh tk ldrh rks vkosnu dks jÌ fd;k tk,xkA
ijarq fd ;fn vkosnd us vius vkosnu esa eatwjh nh gS fd vkaf'kd ek=k ;k vkaf'kd vof/k ;k nksuksa ds fy, Vh&th,u, dk
vuqnku fd;k tk ldrk gS rks bl izdkj dh vkaf'kd ek=k vkSj vkaf'kd vof/k ;k nksuksa ds fy, Vh&th,u, dks miyC/k
ikjs"k.k {kerk ds vuqlkj vuqnku fd;k tk,xkA
Vh&th,u, ds vuqnku ds fy, ,l,yMhlh ls LFkk;h Dyh;jsal ds fy, vkosnu fofuÆn"V ek=k vkSj fofuÆn"V vof/k d
fy, v‚uykbu fd;k tk,xkA

<!-- page 21 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

19

tgka var%jkfT;d ikjs"k.k usVodZ esa vf/k'ks"k ikjs"k.k {kerk dh miyC/krk vkSj vko';d volajpuk dk vfLrRo LFkkfir
fd;k x;k gS rks lacaf/kr ,l,yMhlh bl izdkj ds vkosnu dh izkfIr ds rhu dk;Z fnol ds vanj LFkk;h Dyh;jsl
a tkjh
djsxk:
ijarq fd tc LFkk;h Dyh;jsal ds fy, vkosnu bdkbZ }kjk igyh ckj fd;k x;k gS rks lacaf/kr ,l,yMhlh
ds vkosnu dh izkfIr ds lkr fnuksa ds vanj vkosnd dks LFkk;h Dyh;jsal tkjh djsxkA
;fn lacaf/kr ,l,yMhlh vko';d volajpuk ds xSj vfLrRo ds vk/kkj ij ;k var%jkfT;d ikjs"k.k usVodZ esa vf/k'ks"k
ikjs"k.k {kerk dk vuqiyC/krk ds vk/kkj ij LFkk;h Dyh;jsal tkjh djus ds fy, euk djrk gS rks bl izdkj dh eukgh ds
fy, dkj.kksa lfgr vkosnu dh izkfIr dh rkjh[k ls rhu dk;Zfnolksa ;k lkr dk;Zfnol] tSlh Hkh fLFkfr gks] ds vanj
,uvks,vkj ds ek/;e ls vkosnd dks izsf"kr djsxk:
ijarq fd tgka lacaf/kr ,l,yMhlh us rhu dk;Zfnolksa ;k lkr dk;Zfnolksa tSlh Hkh fLFkfr gks dh vof/k
ds vanj LFkkbZ Dyh;jsal ds fy, vkosnu dh eukgh ;k vuqeksnu dks izsf"kr ugha fd;k gS rks LFkk;h
Dyh;jsal dks ml vof/k ds fy, rhu dk;Zfnolksa ;k lkr dk;Zfnolksa tSlh Hkh fLFkfr gks dh bl izdkj
dh vof/k dh lekfIr ds ckn vxys fnu ds var esa iznku fd;k ekuk tk,xk ftlds fy, bl izdkj
dk LFkk;h Dyh;jsal dk vkosnu fd;k x;k Fkk ;k lkr fnuksa dh vof/k ds fy,] tks Hkh de gks] ds fy,
vkosnu fd;k x;k FkkA
Vh&th,u, vuqnkuxzkgh ftls LFkk;h Dyh;jsal fofu;e 31-2 ds vuqlkj tkjh fd;k x;k gS ;k fofu;e 31-3 ds vuqlkj
tkjh fd;k x;k ekuk x;k gS] bl izdkj ls ikoj ,Dlpst
a ¼tks½a esa cksyh yxk,xk fd f}i{kh; laO;ogkjksa vkSj lkewfgd
laO;ogkjksa ds v/khu lHkh cksyh¼;ks½a ds fy, izR;sd Vkbe CykWd esa dqy ek=k LFkk;h Dyh;jsal dh ek=k ls vf/kd ugha
gksxhA
ijarq fd ;fn Vh&th,u, vuqnkuxzkgh }kjk f}i{kh; laO;ogkjksa vkSj lkewfgd laO;ogkjksa ds v/khu ikoj
,Dlpst
a ¼tks½a esa cksyh¼;ks½a dh dqy ek=k fdlh Vkbe CykWd esa LFkk;h Dyh;jsal dh ek=k ls vf/kd gksrh
gS rks ,u,yMhlh lacaf/kr ,l,yMhlh dks lwfpr djrs gq, lkr fnuksa dh vof/k ds fy, f}i{kh; ,oa
lkewfgd laO;ogkjksa esa lgHkkfxrk ls bl izdkj ds Vh&th,u, vuqnkuxzkgh dks vioÆtr djsxkA
ijarq ;g fd mä ijarqd ds vuqlkj vioÆtr bl izdkj ds Vh&th,u, vuqnkuxzkfg;ksa dh lwph
,uvks,vkj ij iznÆ'kr gksxhA
lacaf/kr ,l,yMhlh ikjs"k.k iz.kkyh esa ck/kkvksa ds ekeys esa dsoy fdlh Vh&th,u, xkjaVh ds laca/k esa ;k jf{kr
xzhM izpkyu ds fgr esa tkjh fd, x, LFkk;h fDy;jsal dh vof/k ;k ek=k dks la'kksf/kr dj ldrs gSaA
,d ekg ls vukf/kd vof/k ds fy, vfxze vkosnu Js.kh ;k vR;ko';d vkosnu Js.kh ds v/khu iznku fd;k x;k
Vh&th,u, dks iqujhf{kr ugha fd;k tkrk ldrkA
,d ekg ls vf/kd dh vof/k ds fy, vfxze vkosnu Js.kh ds v/khu iznku fd, x, Vh&th,u, dks Vh&th,u,
xkjaVh }kjk ,d ekg ds iwoZ uksfVl lfgr 'ks"k vof/k ds fy, de fd;k tk ldrk gS:
ijUrq fd vuqnku fd, x, Vh&th,u, dh ek=k ds fy, ykxw Vh&th,u, izHkkj ,d ekg dh uksfVl vof/k ds
fy, izfrns; gksxkA
vfxze vkosnu Js.kh :
¼d½ vfxze vkosnu Js.kh ds v/khu Vh&th,u, vuqnkuxzkgh }kjk 'ksMîwfyax vuqjks/k fxzMdksM ds mica/kksa ds
vuqlkj MsvgsM cktkj ds v/khu lkewfgd laO;ogkjksa ds fy, cksyh foaMks dh 'kq:vkr ls iwoZ MsvgsM vk/kkj ij
fd;k tk,xkA
¼[k½ ;fn foØsrk jkT; fu;a=.k {ks= ds v/khu var{ksi.k ds IokbaV okyh ,d varjkfT;d bdkbZ gS rks 'ksMîwfyax
vuqjks/k ds lkFk bu fofu;eksa ds fofu;e 28-5 ds [k.M ¼d½ ds mi[k.M ¼vii½ ds vuqlkj LFkk;h fDy;jsal
layXu gSA
¼x½ ;fn foØsrk izknsf'kd fu;a=.k {ks= ds v/khu var{ksi.k dk IokbaV okyh ,d izknsf'kd bdkbZ gS rks var{ksi.k
dk IokbaV bu fofu;eksa ds fofu;e 28-5 ds [k.M ¼d½ ds mi[k.M ¼viii½ ds vuqlkj izLrqr fd;k tk,xkA
¼?k½ 'ksMîwfyax vuqjks/k ds lkFk ;g ?kks"k.kk layXu gksxh fd fo|qr dh fcØh vkSj Ø; ds fy, dkaVªDs V dh izfr
lfgr bu fofu;eksa ds fofu;e 28-6 ds [k.M ¼?k½ ds ijUrqd ds vuqlkj ,d oS/k dkaVªsDV gSaA
vR;ko';d vkosnu Js.kh ds v/khu vuqnku dh xbZ Vh&th,u, ij vuqlwph ds :Ik esa fopkj fd;k tk,xk ftls
la'kksf/kr ugha fd;k tk ldrkA

<!-- page 22 -->

20

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

vfxze vkosnu Js.kh ds v/khu Vh&th,u, vuqnkuxzkgh vxys fnu ds fy, MsvgsM cktkj ds v/khu lkewfgd
laO;ogkjksa ds fy, cksyh foaMks ds vkjaHk ls iwoZ 'ksMîwfyax vuqjks/k djus ds le; ij blds Vh&th,u, ek=k rd
vuqlwph fo|qr ds fy, vuqjks/k dj ldrk gS:
ijUrq fd ;fn bl izdkj dk Vh&th,u, vuqnkuxzkgh vuqlwpu vuqjks/k ds le; ij blh Vh&th,u, ek=k rd
vuqlwph fo|qr ugha djrk rks Vh&th,u, dh viz;qDr ek=k dks bu fofu;eksa ds fofu;e 36 ds vuqlkj okLrfod
le; cktkj ds v/khu lkewfgd laO;ogkjksa vkSj Vh&th,u, ds fy, vR;ko';d vkosnuks]a th,u, vuqnkuxzkfg;ksa
}kjk fu;r vuqlwph iqujh{k.k] MsvgsM cktkj ds v/khu lkewfgd laO;ogkjksa ds fy, fjyht fd;k tk,xkA
jkT; ds fy, #i;s@esxkokV@VkbeCykd esa Vh&th,u, ds fy, ikjs"k.k izHkkj nj 'ks;fjax fofu;eksa ds vuqlkj
dk;kZUo;u ,tsalh }kjk izR;sd ekg ds fy, izdkf'kr fd;k tk,xkA
f}i{kh; ,oa lkewfgd laO;ogkjksa ds ekeyksa esa Vh&th,u, ds fy, ikjs"k.k izHkkj ml jkT; ds fy, tgka vkgj.k
bl izdkj dk IokbaV fLFkr gS] Vh&th,u, ds fy, vafre izdkf'kr ikjs"k.k izHkkj nj ds vuqlkj ds dsoy vkgj.k
ds IokbaV ij izfrns; gksxk:
ijUrq fd lkewfgd laO;ogkjksa ds v/khu] Vh&th,u, ds fy, ikjs"k.k izHkkj th,u, ek=k ls vf/kd vkgj.k vuqlwph
;k Vhth,u, ek=k ;k nksuks]a tSlk Hkh ykxw gks] ds fy, izfrns; gksxkA
Vh&th,u, ds fy, ikjs"k.k izHkkjksa dks iwoZO;kih izHkko ls la'kksf/kr ugha fd;k tk,xkA
Vh&th,u, ds fy, ikjs"k.k izHkkjksa dk Hkqxrku:
¼d½ vfxze vkosnu Js.kh ds v/khu Vh&th,u, ds fy, ikjs"k.k izHkkjksa dks fuEukuqlkj uksMy ,tsl
a h ds ikl
Vh&th,u, xkjaVh }kjk tek djok;k tk,xk :
(i) ,d ekg rd Vh&th,u, ds fy, & Vh&th,u, ds vuqnku ds rhu dk;Zfnolksa ds vanj :

ijarq fd tgka Vh&th,u, vxys rhu dk;Zfnolksa ds vanj vkjaHk gks jgk gSA Vh&th,u, ds fy, ikjs"k.k
izHkkj Vh&th,u, dh vkjafHkd rkjh[k ls iwoZ tek gksx
a s;
(ii) ,d ekg ls vf/kd ds fy, Vh&th,u, ds fy, & Vh&th,u, ds vuqnku ds rhu dk;Zfnolksa ds
vanj ysfdu Vh&th,u, dh vkjafHkd rkjh[k ls iwoZ izFke ekg ds fy, izHkkj vkSj vfxze esa ,d ekg
jksfyax vk/kkj ij izR;sd ijorhZ ekg vkSj mlds Hkkx lfgr ;fn dksbZ gS] ds fy, izHkkjA
¼[k½ vR;ko';d vkosnu Js.kh ds v/khu Vh&th,u, ds fy, ikjs"k.k izHkkj vkosnu lfgr tek gksx
a sA ;fn vfr
vko';d vkosnu iz;qDr ek=k ds Hkkx ds fy, vuqeksfnr gks tkrk gS ;k iz;qDr vof/k dk Hkkx ;k jn~n gks tkrk
gS rks rnuq:ih ikjs"k.k izHkkj vuqeksnu dh rkjh[k ls vxys fnu rd okfil gks tk,xkA :
ijarq fd vkosnd Hkkoh Vh&th,u, vkosnuksa ds fy, lek;ksftr fd, tkus okys uksMy ,tsalh ds ikl vf/kd
ikjs"k.k izHkkjksa dks j[kus ds fy, fodYi dj ldrk gSA
¼x½ lkewfgd laO;ogkjksa ds varxZr ikoj ,Dlpst
a Vh&th,u, ds vuqnku ds fy, vkosnu ds fnol gksus ds ukrs
¼Mh$2½] ¼Mh½ ds 2400 ?kaVs rd uksMy ,tsl
a h ls Vh&th,u, ds fy, ikjs"k.k izHkkjksa dks tek djsaxs:
ijarq fd varjkfT;d ikjs"k.k iz.kkyh ds mi;ksx ds fy, Vh&th,u, ds fy, ikjs"k.k izHkkjksa dks lacaf/kr jkT; Hkkj
izs"k.k dsUnz ls fo|qr ,Dlpst
a }kjk izR;{k :Ik ls fuiVk;k tk,xkA
¼?k½ ;fn Vh&th,u, ds v/khu dksbZ 'ksMîwfyax vuqjks/k MsvgsM vk/kkj ij vkj,yMhlh }kjk vuqeksfnr ugha fd;k
tkrk ;k ikjs"k.k ck/kkvksa ;k fxzM lqj{kk ds dkj.kksa ls de fd;k tkrk gS rks vuqlwfpr ugha fd, x, ;k de
fd, x, bl izdkj dh ek=k ds fy, ikjs"k.k izHkkjksa dks vxys ekg dh 15 fnol rd Vh&th,u, vuqnkuxzkgh
dks okil fd;k tk,xkA
ijarq fd LFkk;h fDy;jsal dh xSj miyC/krk dks ikjs"k.k iz.kkyh esa ck/kkvksa ds :Ik esa ugha ekuk tk,xkA
Vh&th,u, ds fy, ikjs"k.k izHkkjksa ds Hkqxrku esa pwd dh fLFkfr esa iznku fd, x, Vh&th,u, dks jn~n fd;k
tk,xkA
lkewfgd laO;ogkjksa ds varxZr Vh&th,u, izHkkjksa ds Hkqxrku esa foyac ds ekeys esa pwd ds izR;sd fnu ds fy, 004%dh nj ij lk/kkj.k C;kt fo|qr ,Dlpst
a }kjk izfrns; gksxkA
Vh&th,u, ds vkosnuksa ds vuqeksnu ;k jnn djus ls lacaf/kr lwpuk] vuqlwfp;ksa ds iqujh{k.k ;k deh] Hkqxrku
vuqlwfp;ksa vkSj bl izdkj ds vU; ekeyksa dks bZey
s ;k ,l,e,l ;k lapkj ds bl izkdj ds vU; bysDVªkWfud <ax
ds ek/;e ls vyVZ djus lfgr lacaf/kr cktkj lgHkkfx;ksa dks ,uvks,vkj ds ek/;e ls miyC/k djok;k tk,xkA

<!-- page 23 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

21

th,u, xkjaVh fxzM dksM esa fofufnZ"V 'krksaZ ds v/;k/khu fdlh dkaVªDs V ds varxZr iznku fd, x, th,u, ds
varxZr vuqlwfpr fo|qr ds fy, ik= gksx
a s%
ijarq fd ikjs"k.k iz.kkyh esa ck/kkvksa dh fLFkfr esa miyC/k ikjs"k.k dkWfjMksj izn's k ;k izn's k ds vanj ;k izns'k ds
ckgj ls muds th,u, esa lekuqikr esa th,u, vuqnkuxzkfg;ksa dks vkcafVr fd;k tk,xk vkSj th,u, vuqnkuxzkgh
bl izdkj ds vkcafVr ikjs"k.k dkfjMksj ds vanj fdlh dkaVªDs V ds v/khu vuqlwfpr fo|qr ds fy, ik= gksx
a sA
bls iznku dh xbZ Vh&th,u, ds vanj vfxze vkosnu Js.kh ds v/khu Vh&th,u, vuqnkuxz kgh fxzM dksM esa
fofufnZ"V 'krksZa ds v/;k/khu fdlh dkaVªDs V ds varxZr vuqlwfpr fo|qr ds fy, ik= gksx
a sA
ijarq fd ;fn Vh&th,u, dh iw.kZ ek=k ds fy, Vh&th,u, vuqnkuxzkfg;ksa ds MsvgsM 'ksM~;wfyax vuqjks/k dks
Ik;kZIr ikjs"k.k dkfjMksj dh xSj miyC/krk ds dkj.k lek;ksftr ugha fd;k tk ldrk] 'ksM~;wfyax mudh
Vh&th,u, ds lekuqikr esa Vh&th,u, vuqnkuxzkfg;ksa ds fy, lekuqikfrd vk/kkj ij gksxkA
,d ckj MsvgsM vuqlwph th,u, vuqnkuxzkfg;ksa ds fy, vafre :Ik gks tkrk gS rks Vh&th,u, dh vfxze vkosnu
Js.kh ds v/khu Vh&th,u, vuqnkuxzkfg;ksa ds fy, 'ksM~;wy dks 'ks"k ikjs"k.k dkWfjMksj ij vafre :Ik fn;k tk,xkA
vfxze vkosnu Js.kh ds v/khu th,u, vuqnkuxzkfg;ksa vkSj Vh&th,u, vuqnkuxzkfg;ksa dks ikjs"k.k dkfjMksj ds
vkcaVu ds ckn 'ks"k ikjs"k.k dkfjMksj MsvgsM cktkj ds v/khu lkewfgd laO;ogkjksa ds fy, fjyht fd;k tk,xkA
MsvgsM cktkj ds v/khu lkewfgd laO;ogkjksa dks vafre :Ik nsus ds ckn] ‘,l-1’ fnol ds 1300 ?k.Vs rd izkIr
;k fxzM dksM ;FkkfofufnZ"V bl izdkj ds le; rd izkIr Vh&th,u, ds vuqnku ds fy, vR;ko';d vkosnuksa dks
ikjs"k.k dkfjMksj vkcafVr fd;k tk,xkA
fofu;e 36-1 ls 36-4 ds v/khu ikjs"k.k dkWfjMksj ds vkcaVu ds ckn 'ks"k ikjs"k.k dkWfjMksj dks th,u, ds vanj
fdlh dkaVªsDV ds v/khu ;k vR;ko';d vkosnu Js.kh ds v/khu ;k bl izdkj ds vuqjks/k ds fy, le; LVsEi ij
vk/kkfjr okLrfod le; cktkj ds varxZr fdlh dkaVªDs V ds v/khu fxzM dksM esa ;Fkkfu/kkZfjr 'ksM~;wy ds iqujh{k.k
ds ek/;e ls th,u, vuqnkuxzkgh }kjk iz;qDr fd;k tkrk ldrk gSA

;fn la;kstdrk iznku djus ds fy, ;k nh?kZdkfyd igqap iznku djus ;k e/;dkfyd fuckZ/k igqap iznku djus ds
fy, dksbZ vkosnu la;kstdrk fofu;e 2009 ds vuqlkj fd;k x;k gS vkSj mls bu fofu;eksa ds izHkkoh gksus dh
rkjh[k ij iznku fd;k tkuk gS rks vkosnd dks ;g fodYi gksxk fd og ¼d½ ml vkosnu dks okfil ys lds
ftl ekeys esa vkosnu Qhl vkSj cSad xkjaVh] ;fn dksbZ gS] okil dj nh tk,xh ;k ¼[k½ bu fofu;eksa ds v/khu
vis{kkvksa dk vuqikyu djrs gq, bu fofu;eksa ds v/khu fd, x, vkosnu ds :Ik esa vkosnu dks laifjofrZr fd;k
tk,xk ftls bu fofu;eksa ds vuqlkj izksll
s fd;k tk,xk:
ijarq fd bl izdkj ds fodYi dks bu fofu;eksa ds izHkko esa vkus ds ,d ekg ds vanj vkosnd }kjk iz;ksx fd;k
tk,xk ftlds u gksus dh fLFkfr esa vkosnu dks can fd;k tk,xk vkSj vkosnu Qhl vkSj cSad xkjaVh ;fn dksbZ gS]
okil dh tk,xhA
;fn la;kstdrk iznku dh xbZ gS ysfdu nh?kZdkfyd igqap la;kstdrk fofue; 2009 ds vuqlkj iznku ugha dh xbZ
gS vkSj la;kstdrk bu fofu;eksa ds izHkko esa vkus dh rkjh[k dks izHkkoh gksuk ckdh gS rks mls fuEukuqlkj ekuk
tk,xk:
bdkbZ dks ;g fodYi gksxk (i) fd bu fofu;eksa ds v/khu vis{kkvksa dk vuqikyu djrs gq, bu fofu;eksa
ds v/khu fd, x, la;kstdrk ds :Ik esa la;kstdrk fofu;e 2009 ds v/khu iznku dh xbZ la;kstdrk dks
laifjofrZr djsa ;k (ii) bl izdkj dh la;kstdrk dks vH;fiZr djsAa
¼[k½ bl fofu;e ds [k.M ¼[k½ ds v/khu bl izdkj dk fodYi bu fofu;eksa ds izHkkoh gksus ds ,d ekg ds
vanj vkosnd }kjk iz;ksx fd;k tk,xk ftlds u gksus dh fLFkfr esa la;kstdrk fofu;e 2009 ds v/khu iznku
dh xbZ la;kstdrk dks vH;fiZr ds :Ik esa le>k tk,xkA
¼x½ ;fn la;kstdrk bl fofu;e ds [k.M ¼d½ ds fodYi ¼ii½ ;k bl fofu;e ds [k.M [k ds vuqlkj vH;fiZr
dh tkrh gS rks la;kstdrk fofu;eksa ds fofu;eksa ds v/khu izLrqr dh xbZ la;kstdrk chth&1 vkSj la;kstdrk
chth&2] ;fn dksbZ gS] okil dh tk,xhA
ijUrq fd ;fn VfeZuy cs dk fuekZ.k lhVh;w ds ek/;e ls vkbZ,lVh,l ds v/khu dk;kZfUor ds fy, vokMZ fd;k
x;k gS rks la;kstdrk fofu;e 2009 ds v/khu izLrqr la;kstdrk chth&2 dk udnhdj.k fd;k tk,xkA

<!-- page 24 -->

22

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

¼?k½ ;fn bdkbZ bl fofu;e ds [k.M ¼d½ ds fodYi ¼i½ ds vuqlkj bu fofu;eksa ds v/khu la;kstdrk ds :Ik
esa la;kstdrk fofu;e 2009 ds v/khu iznku fd, x, la;kstdrk ds laijofrZr djus ds fy, fodYi dk iz;ksx
djrh gS rks uksMy ,tsalh vxys 30 fnuksa ds vanj la;kstdrk fofu;e 2009 ds v/khu bl izdkj dh bdkbZ }kjk
vnk dh xbZ cSad xkjaVh] ;fn dksbZ gS dks lek;ksftr djus ds ckn bu fofu;eksa ds fofu;e 8 ds vuqlkj bl
izdkj dh bdkbZ }kjk vnk dh tkus okyh la;kstdrk chth&1 vkSj la;kstdrk chth&2 vkSj la;kstdrk chth&3
dh jde dks lwfpr djsxhA
¼³½ la;kstdrk chth&1 vkSj la;kstdrk chth&2 vkSj la;kstdrk chth&3 dks bl fofu;e ds [k.M ¼?k½ ds
v/khu lwfpr djus ds nks ekg ds vanj bdkbZ }kjk izLrqr dh tk,xhA
¼p½ bl fofu;e ds [k.M ¼³½ ds v/khu la;kstdrk chth&1 vkSj la;kstdrk chth&2 vkSj la;kstdrk chth&3
dks izLrqr djus ij bdkbZ vkSj uksMy ,tsalh ds chp ekStwnk O;oLFkkvksa dks bu fofu;eksa ds fofu;e 10-3 ds
mica/kksa ds lekuq:Ik fd;k tk,xkA
¼N½ bl fofu;e ds [k.M ¼p½ ds v/khu ekStwnk O;oLFkkvksa ds lq;kstu ij bdkbZ bu fofu;eksa ds v/khu lHkh
iz;kstuksa ds fy, la;kstdrk vuqnkuxzkgh gks tk,xhA
¼t½ ;fn bdkbZ bl fofu;e ds [k.M ¼?k½ ds vuqlkj uskMy ,tsalh }kjk ;Fkklwfpr la;kstdrk chth&1 vkSj
la;kstdrk chth&2 vkSj la;kstdrk chth&3 dks izLrqr djus esa vlQy jgrh gSA
(i) rks la;kstdrk fofue; 2009 ds v/khu bdkbZ dks iznku dh xbZ la;kstdrk uksMy ,tsl
a h }kjk
izfrlagfjr gksxh vkSj
(ii)la;kstdrk fofu;e 2009 ds v/khu izLrqr la;kstdrk chth&1] ;fn dksbZ gS] dks udnhÑr fd;k
tk,xk vkSj
(iii)la;kstdrk fofu;e 2009 ds v/khu izLrqr la;kstdrk chth&2 ;fn dksbZ gS] okil fd;k tk,xk:
ijarq fd ;fn VfeZuy cs dk fuekZ.k lhVh;w ds ek/;e ls vkbZ,lVh,l ds v/khu dk;kZUo;u ds fy, vokMZ fd;k
x;k gS rks la;kstdrk fofu;e 2009 ds v/khu izLrqr la;kstdrk chth&2 dks udnhÑr fd;k tk,xkA
;fn la;kstdrk ,oa nh?kZdkfyd igqap dks la;kstdrk fofu;e 2009 ds vuqlkj iznku fd;k x;k gS ysfdu nksuksa
la;kstdrk vkSj nh?kZdkfyd igqap dks izHkkoh cukuk ckdh gS ;k la;kstdrk izHkkoh gS vkSj nh?kZdkfyd igqap dks
bu fofu;eksa ds izHkkoh gksus dh rkjh[k dks izHkkoh cukuk ckdh gS rks mls fuEukuqlkj ekuk tk,xk:
(1)
la;kstdrk fofu;e 2009 ds v/khu vuqnku dh xbZ la;kstdrk dh ek=k ftlds fy, nh?kZdkfyd igqap
iznku ugha dh xbZ gS mls bl ckr ij vkfJr djrs gq, fd bl izdkj dh la;kstdrk ek=k izHkkoh gS ;k izHkkoh
ugha gS mls fofu;e 37-6 ;k fofu;e 37-2 ds [k.M ¼1½ ds vuqlkj ekuk tk,xkA
(2)
tgka nh?kZdkfyd igqap ekStwnk iz.kkyh ij iznku dh xbZ gS] bl izdkj dh nh?kZ dkfyd igqap dk
laO;ogkj vkSj la;kstdrk dk rnuq:ih ek=k fuEukuqlkj gks:
¼d½ bdkbZ dks ;g fodYi gksxk fd og (i)bu fofu;e ds v/khu th,u, ds :Ik esa la;kstdrk fofu;e
2009 ds v/khu iznku dh xbZ nh?kZdkfyd igqap dks laifjofrZr djs ;k (ii)bl izdkj dh nh?kZdkfyd
igqap dks vH;fiZr djsA
¼[k½ bl fofu;e ds [k.M ¼d½ ds v/khu fodYi dks bu fofu;eksa ds izHkkoh gksus ds ,d ekg ds vanj
bdkbZ }kjk iz;ksx fd;k tk,xk ftlds u gksus dh fLFkfr esa la;kstdrk fofu;e 2009 ds v/khu iznku
fd, x, bl izdkj ds nh?kZdkfyd igqap dks vH;fiZr ds :Ik esa le>k tk,xkA
¼x½ ;fn nh?kZdkfyd igqap bl fofu;e ds [k.M ¼[k½ ;k bl fofu;e ds [k.M ¼d½ ds fodYi ¼ ii½ ds
vuqlkj vH;fiZr dh tkrh gS rks la;kstdrk fofu;e 2009 ds v/khu bdkbZ }kjk izLrqr dh xbZ vkosnu
cSad xkajVh] ;fn dksbZ gS] okil dh tk,xhA
¼?k½ ;fn] bdkbZ bu fofu;eksa ds v/khu MhEM th,u ds :Ik esa la;kstdrk fofu;e 2009 ds v/khu iznku
dh xbZ nh?kZdkfyd igqap ds laifjorZu ds fy, bl fofu;e ds [k.M ¼d½ ds fodYi ¼i½ dk iz;ksx
djrh gS rks ;g bl izdkj ds fodYi ds iz;ksx djus ds nks ekg ds vanj bl izdkj dh nh?kZdkfyd
igqap ek=k 50 yk[k #i;s ds fy, la;kstdrk chth&1 vkSj 2 yk[k #i;s@esxkokV dh nj ij
la;kstdrk chth&3 izLrqr djsxkA ;fn dksbZ la;kstdrk chth&2] la;kstdrk fofu;e 2009 ds v/khu
izLrqr fd;k x;k gS rks mls bu fofu;eksa ds v/khu la;kstdrk chth&2 ds :Ik esa ekuk tk,xkA
la;kstdrk chth&1] la;kstdrk chth&2 vkSj la;kstdrk chth&3 dk ijorhZ laO;ogkj bu fofu;eksa ds
fofu;e 16-1 ls 16-4 ds vuqlkj gksxkA la;kstdrk fofu;e 2009 ds v/khu bl izdkj dh bdkbZ }kjk
izLrqr cSad xkjaVh ;fn dksbZ g]S lek;ksftr dh tk,xhA
¼³½bl fofu;e ds [k.M ¼?k½ ds v/khu la;kstdrk chth&1 vkSj la;kstdrk chth&3 dks izLrqr djus ij
nh?kZdkfyd igqap dks bu fofu;eksa ds v/khu iznku fd, tkrs gq, MhEM th,u ds :Ik esa ekuk tk,xk
vkSj bdkbZ rFkk uksMy ,tsl
a h ds chp ekStwnk O;oLFkk dks bu fofu;eksa ds mica/kksa ds vuq:Ik fd;k
tk,xkA

<!-- page 25 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

23

¼p½;fn bdkbZ bl fofu;e ds [k.M ¼?k½ ds vuqlkj la;kstdrk chth&1] la;kstdrk chth&2 vkSj
la;kstdrk chth&3dks izLrqr djus esa vlQy jgrh gS rks la;kstdrk fofu;e 2009 ds v/khu bdkbZ dks
iznku dh xbZ nh?kZdkfyd igqap dks bl fofu;e ds [k.M ¼[k½ ds vuqlkj vH;fiZr ds :Ik esa ekuk
tk,xkA
¼N½ nh?kZdkfyd igqap dh ek=k ds fy, la;ktsdrk dh ek=k ftls bl fofu;e ds [k.M ¼³½ ds v/khu
th,u, esa laifjofrZr fd;k x;k gS] bu fofu;eksa ds v/khu iznku dh xbZ la;kstdrk ds :i esa ekuk
tk,xkA
(3)
tgka nh?kZdkfyd igqap iz.kkyh o`f) ds lkFk iznku dh xbZ gS] bl izdkj dh nh?kZdkfyd igqap vkSj
la;kstdrk dh rnuq:ih ek=k dk laO;ogkj fuEukuqlkj gksxk :
¼d½ bdkbZ dk fodYi gksxk (i)bu fofu;eksa ds v/khu th,u, ds :Ik esa la;kstdrk fofu;e 2009 ds
v/khu iznku dh xbZ nh?kZdkfyd igqap dks laifjofrZr fd;k tk, ;k (ii)bl izdkj ds nh?kZdkfyd igqap
dks vH;fiZr fd;k tk,A
¼[k½ bl fofu;e ds [k.M ¼d½ ds v/khu fodYi dk bu fofu;eksa ds izHkko ds ,d eghus ds vanj
vkosnd }kjk iz;ksx fd;k tk,xk ftlds vlQy gksus ij la;kstdrk fofu;e 2009 ds v/khu iznku dh
xbZ nh?kZdkfyd igqap dks vH;fiZr ds :Ik esa ekuk tk,xkA
¼x½ ;fn nh?kZdkfyd igqap bl fofu;e ds [k.M ¼d½ ;k [k.M ¼[k½ ds fodYi ¼ ii½ ds vuqlkj vH;fiZr
gksrk gS] la;kstdrk fofu;e 2009 ds v/khu izLrqr fuekZ.k cSad xkjaVh dks ,Vh,l dh izkDdfyr ykxr
dh lhek rd udnhÑr fd;k tk,xk] ftls dk;kZUo;u ds fy, ¼igys ls izLrqr cSad xkjaVh ds ewY; rd
vf/kdre½ vokMZ fd;k x;k gS vkSj 'ks"k ;fn dksbZ gS] okil fd;k tk,xkA nh?kZdkfyd igqap dh bl
izdkj dh ek=k ds fy, ftls vH;fiZr fd;k x;k gS la;kstdrk fofu;e 2009 ds v/khu iznku dh xbZ
la;kstdrk dh ek=k dks bl fofu;e ds [k.M ¼1½ ds vuqlkj ekuk tk,xkA
¼?k½ ;fn bdkbZ bu fofu;eksa ds v/khu iznku fd, x, MhEM th,u ds :Ik esa la;kstdrk fofu;e 2009 ds
v/khu iznku fd, x, nh?kZdkfyd igqap ds laifjorZu ds fy, bl fofu;e ds [k.M ¼d½ ds fodYi ¼>½
dk iz;ksx djrh gS] igys ls izLrqr dh xbZ fuekZ.k cSad xkjaVh dks bu fofu;eksa ds v/khu #i;s 50 yk[k
ds fy, la;kstdrk chth&1 ds :Ik esa vkSj 'ks"k la;kstdrk chth&2 ds :Ik esa ekuk tk,xkA ;fn dksbZ
fuekZ.k cSad xkjaVh ihih, vkSj ih,l, ds gLrk{kj ds vuqlj.k esa izLrqr ugha dh xbZ gS rks bl fofu;e ds
[k.M ¼d½ ds v/khu fodYi ¼>½ dk iz;ksx djrs gq, nks ekg ds vanj bl izdkj ds nh?kZdkfyd igqap
ek=k ds rnuq:ih #i;s 50 yk[k ds fy, la;kstdrk chth&1 ds fy, vkSj @2 yk[k #i;s@esxkokV ?k.Vs
dh nj ij la;kstdrk chth&3 izLrqr djsxkA ;fn dksbZ la;kstdrk chth&2 la;kstdrk fofu;e 2009 ds
v/khu izLrqr dh xbZ gS] mls bu fofu;eksa ds v/khu la;kstdrk chth&2 ds :Ik esa ekuk tk,xkA
la;kstdrk chth&1] la;kstdrk chth&2 vkSj la;kstdrk chth&3 dks bu fofu;eksa ds fofu;e 16-1 ls 164 ds vuqlkj ekuk tk,xkA
¼³½ la;kstdrk chth&1 vkSj la;kstdrk chth&2 ds :Ik esa fuekZ.k cSad xkjaVh ds laifjorZu ij ;k bl
fofu;e ds [k.M ¼?k½ ds vuqlkj la;kstdrk chth&1 vkSj la;kstdrk chth&3 dks izLrqr djus ij] tSlk
ykxw gks] la;kstdrk fofu;e] 2009 ds v/khu vuqnku dh xbZ nh?kZdkfyd igqap dks bu fofu;eksa ds
v/khu vuqnku fd, tkus okyk MhEM fd;k x;k th,u, ds :Ik esa ekuk tk,xkA bdkbZ rFkk uksMy
,tsalh ds chp ekStwnk djkjksa dks bu fofu;eksa ds mica/kksa ds vuq:Ik fd;k tk,xkA
¼p½ ;fn bdkbZ bl fofu;e ds [k.M ¼?k½ ds vuqlkj la;kstdrk chth&1 vkSj la;kstdrk chth&3 izLrqr
djus esa vlQy jgrh gS] la;kstdrk fofu;e] 2009 ds v/khu bdkbZ dks vuqnku dh xbZ nh?kZdkfyd
igqap bl fofu;e ds [k.M ¼[k½ ds vuqlkj vH;fiZr ekuk tk,xkA
¼N½ nh?kZdkfyd igqap dh ek=k ds fy, la;kstdrk dh ek=k ftls bl fofu;e ds [k.M ¼³½ ds v/khu
th,u, eas laifjofrZr fd;k x;k gS] bu fofu;eksa ds v/khu vuqnku dh xbZ la;kstdrk ds :Ik esa ekuk
tk,xkA
;fn e/;dkfyd fuckZ/k igqap la;kstdrk fofu;e] 2009 ds vuqlkj vuqnku dh xbZ gS] ys fdu bu fofu;eksa ds
izHkkoh gksus dh rkjh[k dks izHkkoh gksuk ckdh gS] mls fuEukuqlkj ekuk tk,xk :
(1)
bu fofu;eksa ds fofu;e 4-1 ds v/khu doj dh xbZ bdkbZ dks vuqnku dh xbZ e/;dkfyd fuckZ/k igqap
dks fuEukuqlkj ekuk tk,xk:
¼d½ bdkbZ dks ;g fodYi gksxk fd ;k (i)e/;dkfyd fuckZ/k igqap dh vof/k ds fy, bu fofu;eksa ds
v/khu vuqnku dh tkus okyh MhEM th,u, ds :Ik esa la;kstdrk fofu;e 2009 ds v/khu vuqnku dh xbZ
e/;dkfyd fuckZ/k igqap dks laifjofrZr djsAa ;k (ii)bl izdkj ds e/;dkfyd igqap dks vH;fiZr djsAa
¼[k½bl fofu;e ds [k.M ¼d½ ds v/khu bl izdkj dk fodYi bu fofu;eksa ds izHkkoh gksus ds ,d ekg ds
vanj vkosnd }kjk iz;ksx fd;k tk,xk ftlds vlQy gksus dh fLFkfr esa la;kstdrk fofu;e 2009 ds
v/khu vuqnku dh xbZ e/;dkfyd fuckZ/k igqap dks vH;fiZr ds :Ik esa ekuk tk,xkA

<!-- page 26 -->

24

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

¼x½;fn la;kstdrk fofu;e 2009 ds v/khu vuqnku dh xbZ e/;dkfyd fuckZ/k igqap dks bl fofu;e ds
[k.M ¼d½ ;k [k.M ¼[k½ ds fodYi ¼ii½ ds vuqlkj vH;fiZr fd;k tkrk gS] ;fn dksbZ gS] okil fd;k
tk,xkA
¼?k½;fn bdkbZ bu fofu;eksa ds v/khu th,u, ds :Ik esa la;kstdrk fofu;e 2009 ds v/khu vuqnku dh
xbZ e/;dkfyd fuckZ/k igqap ds laifjorZu ds fy, bl fofu;e ds [k.M ¼d½ ds fodYi ¼i½ dk iz;ksx
djrh gS] ;g bl fofu;e ds [k.M ¼d½ ds v/khu fodYi ¼i½ dk iz;ksx djus ds nks ekg ds vanj bl
izdkj ds e/;dkfyd fuckZ/k igqap ek=k ds rnuq:ih @#i;s 2 yk[k@esxkokV la;kstdrk chth&3 izLrqr
djsxk] ftls e/;dkfyd fuckZ/k igqap ds vuqlkj iw.kZ djus ds ckn okil fd;k tk,xkA ;fn bl izdkj
dh bdkbZ us e/;dkfyd fuckZ/k igaqp ds fy, dksbZ cSad xkjaVh izLrqr dh gS] mls lek;ksftr fd;k tk,xkA
bl izdkj ds e/;dkfyd fuckZ/k igqap dks e/;dkfyd fuckZ/k igqap ds lekfIr rd bu fofu;eksa ds v/khu
vuqnku dh xbZ MhEM ds :Ik esa ekuk tk,xkA
¼³½bl fofu;e ds [k.M ¼?k½ ds v/khu la;kstdrk chth&3 dks izLrqr djus ij] la;kstdrk fofu;e 2009
ds v/khu vuqnku dh xbZ e/;dkfyd fuckZ/k igqap dks bu fofu;eksa ds v/khu vuqnku dh xbZ MhEM
th,u ds :Ik esa ekuk tk,xkA bdkbZ rFkk uksMy ,tsalh ds chp ekStwnk djkjksa dks bu fofu;eksa ds mica/kksa
ds vuq:Ik fd;k tk,xkA
¼p½;fn bdkbZ bl fofu;e ds [k.M ¼?k½ ds vuqlkj la;kstdrk chth&3 dks izLrqr djus esa vlQy jgrh
gS] la;kstdrk fofu;e 2009 ds v/khu bdkbZ dks vuqnku dh xbZ e/dkdkfyd fuckZ/k igqap dks bl
fofu;e ds [k.M ¼[k½ ds vuqlkj vH;fiZr ds :Ik esa ekuk tk,xkA
¼N½vuqnku dh xbZ e/;dkfyd fuckZ/k igqap dh ek=k ds fy, la;kstdrk ftls bl fofu;e ds [k.M ¼³½
ds v/khu th,u, esa laifjofrZr fd;k x;k gS] e/;dkfyd fuckZ/k igqap dh fe;kn ds lekIr gksus rd
e/;dkfyd fuckZ/k igqap fd bl izdkj dh ek=k ds fy, bu fofu;eksa ds v/khu iznku dh xbZ la;kstdrk
ds :Ik esa ekuk tk,xk] ftlds ckn bdkbZ bu fofu;eksa ds v/khu iznku dh xbZ la;kstdrk ds :Ik esa
la;kstdrk fofu;e 2009 ds v/khu iznku dh xbZ bldh la;kstdrk ds laifjorZu ds fy, vkosnu dj
ldrk gSA .
(2)
bu fofu;eksa ds fofu;e 17-1 ds v/khu doj dh xbZ ,d bdkbZ ds fy, la;kstdrk fofu;e 2009 ds
v/khu iznku dh xbZ e/;dkfyd fuckZ/k igqap] ml vkjafHkd rkjh[k ls e/;dkfyd fuckZ/k igqap dh fe;kn ds
lekIr gksus rd ml bdkbZ dks iznku dh xbZ th,u, ds :Ik esa ekuh tk,xh] ftl rkjh[k ls ftlls bl izdkj
dh e/;dkfyd fuckZ/k igqap izHkkoh gksuh FkhA
la;kstdrk fofu;e 2009 ds v/khu iznku dh xbZ nh?kZdkfyd igqap tks bu fofu;eksa ds fofu;e 17-1 ds v/khu
ml laifjofrZr ls fHkUu O;kikj vuqKfIr/kkjh dks izHkkoh ugha gqbZ gS mls vkgj.k ds :Ik esa ekuk tk,xk vkSj
izLrqr dh xbZ cSad xkjaVh] ;fn dksbZ gS] okil dh tk,xhA
;fn la;kstdrk fofu;e 2009 ds vuqlkj iznku dh xbZ la;kstdrk izHkkoh gS vkSj nh?kZdkfyd igqap u rks fdlh
{kerk ds fy, iznku dh xbZ gS ;k iw.kZ@vkaf'kd {kerk ds fy, iznku dh xbZ gS tks bu fofu;eksa ds izHkko esa vkus
dh rkjh[k dks izHkkoh gks xbZ gS ogka fuEufyf[kr ykxw gksx
a s :
(1) bu fofu;eksa ds fofu;e 4-1 ds v/khu doj dh xbZ bdkb;ka ftls fdlh {kerk ds fy, nh?kZdkfyd igqap
iznku ugha fd;k x;k gS ;k la;kstdrk fofu;e 2009 ds v/khu la;kstdrk ek=k dh {kerk ds Hkkx ds fy,
nh?kZdkfyd igqap iznku dh xbZ gS] bu fofu;eksa ds fofu;e 17-2 ds v/khu la;kstdrk dh 'ks"k ek=k ds fy,
vfrfjDr th,u, ds fy, vkosnu dj ldrs gSaA mls fuEukuqlkj uksMy ,tsl
a h }kjk izksll
s fd;k tk,xkA :
¼d½ fofu;e 17-2 ds v/khu ;Fkk ç;qDr vfrfjDr th,u, ds ekeys esa ekStwnk ikjs"k.k ç.kkyh ij iznku
fd;k tk ldrk gS] uksMy ,tsl
a h ;g la;kstdrk chth&3 #i;s 2 yk[k@esxkokV dh nj ij izLrqr djus
ij bl izdkj ds vfrfjDr th,u, iznku djsxkA ml o"kZ ls vkjaHk gksus okys vxys ikap o"kksZa esa ikap
leku Hkkxksa esa la;kstdrk chth&3 okfil fd;k tk,xk] tc bl izdkj ds th,u;k bu fofu;eksa ds 16-2
ds vuqlkj] tks Hkh ckn esa vizHkkoh gks tkrk gSA
ijUrq fd ;fn la;kstdrk bu fofu;eksa ds fofu;e 24-1 ds vuqlkj vf/kR;kx dh tkrh gS] vofLFkr
la;kstdrk chth&3 dks udnhÑr fd;k tk,xkA
¼[k½ ;fn ,Vh,l bl izdkj ds vfrfjDr th,u, iznku djus ds fy, visf{kr gSa] vkosnu bu fofu;eksa ds
fofu;e 8-3 ds vuqlkj izksll
s fd;k tk,xkA bl izdkj dk vfrfjDr th,u, la;kstdrk chth&2 ds
izLrqr djus ij iznku fd;k tk,xkA la;kstdrk chth&1 {kerk ds okf.kfT;d izpkyu dh ?kks"k.kk ds 30
fnuksa ds vanj okil fd;k tk,xk ftlds fy, vfrfjDr th,u, iznku fd;k x;k gSA la;kstdrk chth&2
ml o"kZ ls vkjaHk gksus okys ikap o"kksZa ls ikap leku Hkkxksa es okfil fd;k tk,xk] tc bl izdkj ds
th,u, bu fofu;eksa ds 16-2 ds vuqlkj] tks Hkh ckn esa izHkkoh gks tkrk gSA

<!-- page 27 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

25

ijarq fd tgka ,Vh,l ds dsoy dqN ikjs"k.k ?kVdksa dks ,Vh,l dh okf.kfT;d izpkyu dh rkjh[k ls iwoZ
okf.kfT;d izpkyu dh rkjh[k dks izkIr fd;k gS vkSj la;kstdrk vuqnkuxzkgh blds th,u, ds vkaf'kd
izHkko'khyrk dh ekax djrk gS] uksMy ,tsalh ikjs"k.k ç.kkkyh dh miyC/krk ds v/;/khu bl izdkj ds
vkaf'kd :Ik ls th,u, dks izHkkoh djsxkA
ijarq ;g fd th,u, ds ckn uksMy ,tsalh }kjk iznku fd;k x;k gS ysfdu izHkkoh gksuk gS bl izdkj dh
bdkbZ MhEM dh xbZ Vh&th,u, ds :Ik esa bl izdkj dh igqap dk mipkj djrs gq, ikjs"k.k ç.kkyh dh
miyC/krk ds v/khu ekaxh xbZ th,u, dh vkaf'kd ;k iw.kZ ek=k dh vuqlwfpr fo|qr dks izkIr djus ds fy,
ik= gksxh vkSj Vh&th,u, izHkkjksa dks vnk djuk visf{kr ugha gksxkA
ijarq fd ;fn fofu;e 24-1 ds vuqlkj la;kstdrk dk vf/kR;kx gks tkrk gS] vofLFkr la;kstdrk chth&2
bu fofu;eksa ds fofu;e 24-2 ds vuqlkj udnhÑr gks tk,xkA
(2) bu fofu;eksa ds fofu;e 4-1 ds v/khu doj dh xbZ bdkb;ka ftUgsa yf{kr izn's k ds fy, nh?kZdkfyd igqap
iznku dh xbZ gS] #i;s 2 yk[k@esxkokV dh nj ij la;kstdrk chth&3 izLrqr djsxkA bl izdkj ds
la;kstdrk chth&3 dks izLrqr djus ij bu bdkb;ksa dks bl izdkj dh nh?kZdkfyd igqap dh rnuq:Ikh
th,u, okys bu fofu;eksa ds v/khu la;kstdrk xkjaVh ds :Ik esa ekuk tk,xkA la;kstdrk chth&3 dks ml
o"kZ ls vkjaHk gksus okys vxys ikap o"kksZa esa ikap leku Hkkxksa eas okil fd;k tk,xk] tc bl izdkj ds th,u;k
bu fofu;eksa ds 16-2 ds vuqlkj] tks Hkh ckn esa izHkkoh gks tkrk gSA
ijarq fd ;fn la;kstdrk bu fofu;eksa ds fofu;e 24-1 ds vuqlkj vf/kR;kx gks tkrh gS] vofLFkr la;kstdrk
chth&3 udnhÑr fd;k tk,xkA
;fn bu fofu;eksa ds fofu;e 17-1 ds v/khu doj dh xbZ bdkb;ksa dks iznku dh xbZ nh?kZdkfyd igqap]
la;kstdrk fofu;e 2009 ds vuqlkj ;g izHkkoh gks x;k gS] bls fofu;e 18-1 ds v/khu lacaf/kr bdkb;ksa dks iznku
fd;k tkus okyk MhEM th,u, ds Hkkx ds :Ik esa ekuk tk,xkA
tgka la;kstdrk fofu;e 2009 ds lkFk iznku fd;k x;k e/;dkfyd fuckZ/k igqap bu fofu;eksa ds izHkkoh gksus dh
rkjh[k dks izHkkoh gks x;k gS] bl izdkj ds fuckZ/k igqap dks fuEukuqlkj ekuk tk,A
¼d½ bu fofu;eksa ds fofu;e 4-1 ds v/khu doj fd, x, bdkb;ksa ds fy,] bl izdkj dh e/;dkfyd fuckZ/k
igqap ds rnuq:ih th,u dks bl izdkj dh e/;dkfyd fuckZ/k igqap dh lekfIr rd bl izdkj dh bdkbZ dks
MhEM iznku fd;k tkus okyk ekuk tk,xkA
ijarq fd bl izdkj dh bdkbZ bu fofu;eksa ds fofu;e 17-2 ds v/khu th,u, ds fy, vkosnu dj ldrh gSA
¼[k½ bu fofu;eksa ds fofu;e 17-1 ds v/khu doj dh xbZ bdkb;ksa dks iznku dh xbZ e/;dkfyd fuckZ/k igqap dks
lacaf/kr bdkb;ksa dks iznku fd, tkus ds fy, MhEM th,u, ds Hkkx ds :Ik esa le>k tk,xk ftlds lkFk fofu;e
17-1 ds v/khu bdkbZ us ihih, esa izos'k fd;k gSA
vYidkfyd fuckZ/k igqap :
¼d½ bu fofu;eksa ds izHkko dh rkjh[k ij fuckZ/k igqap fofu;e ds vuqlkj iznku dh xbZ vYidkfyd fuckZ/k
igqap dks bl izdkj ds vYidkfyd fuckZ/k igqap dh vof/k ds fy, iznku dh xbZ vR;ko';d vkosnu Js.kh ds
v/khu Vh&th,u, ds :Ik esa ekuk tk,xkA
¼[k½ bu fofu;eksa ds izHkko esa vkus dh rkjh[k dks vkj,yMhlh ;k ,u,yMhlh ds ikl vfuf.kZr fuckZ/k igqap
fofu;eksa ds v/khu vYidkfyd fuckZ/k igqap vkosnu can gks tk,axsA
tc fxzM dksM esa mica/kksa ds vuqlkj ikjs"k.k ck/kkvksa ds dkj.k ;k fxzM lqj{kk ds fgr ds dkj.k ds fy, ;g
ikjs"k.k dkWfjMksj ij fo|qr izokg dks de djus ds fy, vfuok;Z gks tkrk gS] igys ls vuqlwfpr laO;ogkjksa dks
fuEufyf[kr mica/kksa ds vuqlkj izknsf'kd Hkkj izs"k.k dsUnz }kjk de fd;k tk ldrk gS :
¼d½Vh&th,u, ds v/khu laO;ogkjksa dks th,u, ds v/khu laO;ogkjksa ls igys vuqikyu djrs gq, de fd;k
tk,xkA
¼[k½Vh&th,u, ds v/khu laO;ogkjksa esa] f}i{kh; laO;ogkjksa dks MsvgsM cktkj ds v/khu lkewfgd laO;ogkjksa ls
igys vuqikyu djrs gq, de fd;k tk,xk vkSj mlds ckn okLrfod le; cktkj ds v/khu lkewfgd laO;ogkjksa
}kjk fd;k tk,xkA
¼x½Vh&th,u, ds v/khu f}i{kh; laO;ogkjksa ds vanj] deh Vh&th,u, ij vk/kkfjr lekuqikfrd vk/kkj ij
gksxhA
¼?k½th,u ds v/khu laO;ogkjksa ds varxZr] deh Vh&th,u, ij vk/kkfjr lekuqikfrd vk/kkj ij gksxhA

<!-- page 28 -->

26

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

uksMy ,tsalh vFkkZr lhVh;w bu fofu;eksa dh vf/klwpuk ds rhu eghuksa dh vof/k ds vanj LVsdgksYMjksa ls ijke'kZ
ds ckn fuEufyf[kr QkesZVksa lfgr bu fofu;eksa ds vuqlkj la;kstdrk vkSj th,u, ds fy, foLr`r fØ;kfof/k
tkjh djsxh vkSj mls dsUnzh; vk;ksx dh lwpuk ds fy, izLrqr djsxh:
¼d½ fu;e 5-8 esa ;FkkmfYyf[kr vkosnu }kjk 'kiFki=;
¼[k½ fu;e 5-8 esa ;FkkmfYyf[kr la;kstdrk ds fy, vkosnu;
¼x½ fofu;e 5-2 ds v/khu la;kstdrk ds mi;ksx ds fy, vkosnu;
¼?k½ fofu;e 5-2 ds v/khu la;kstdrk ds iz;ksx ds fy, vuqeksnu;
¼³½ fofu;e 7-1 vkSj 7-2 esa ;FkkmfYyf[kr la;kstdrk dk fl)kar% iznku djus ds fy, lwpuk;
¼p½ fofu;e 8-3 ds [k.M ¼[k½ ds v/khu C;ksjksa dh lwpuk;
¼N½ fofu;e 8 ds v/khu la;kstdrk chth&1] chth&2 vkSj chth&3 ds fy, QkesZV;
¼t½ fofu;e 9 ds v/khu la;kstdrk vafre iznku djus ds fy, lwpuk;
¼>½ fofu;e 10-1 ds v/khu rduhdh la;kstdrk MkVk;
¼´½ fofu;e 10-2 ds v/khu la;kstdrk C;ksjks dh lwpuk;
¼V½ fofu;e 10-7 ds v/khu la;kstdrk djkj;
¼B½ fofue; 11-1 ds v/khu dk;Z{ks= dh v|ru fLFkfr;
¼M½ fofu;e 11-2 ds v/khu ,Vh,l ,oa VfeZuy cst dh v|ru fLFkfr;
¼<½ fofu;e 11-5 ds v/khu VfeZuy cst ,oa vU; C;ksjksa dh vkoaVu dh fLFkfr;
¼.k½ fofu;e 15-3 ds v/khu la;kstdrk ds varj.k ds fy, vkosnu;
¼r½ fofu;e 17-1 vksj 17-2 ds v/khu th,u iznku djus ds fy, vkosnu;
¼Fk½ fofu;e 22 ds v/khu th,u, vuqnku;
¼n½ fofu;e 23 ds v/khu vU; th,u vuqnkuxzkgh }kjk th,u, ds iz;ksx ds fy, vkosnu ;
¼/k½ fofue; 24 ds v/khu la;kstdrk dk vf/kR;kx;
¼u½ fofu;e 25 ds v/khu th,u dk vf/kR;kx;
ijarq fd uksMy ,tsalh dsUnzh; vk;ksx ds vuqeksnu ds fy, bu fofu;eksa ds fofu;e 4.3, 5, 6, 10.7, 15, 16.2,
18.1, 23, 24, 25 vkSj 37ds laca/k esa foLr`r fØ;kfof/k dks izLrqr djsxhA
Vh&th,u, ds fy,] ,u,yMhlh bu fofu;eksa dh vf/klwpuk ds rhu eghuksa dh vof/k ds vanj LVsdgksYMjksa ls
ijke'kZ ds ckn fuEufyf[kr QkesZVksa lfgr Vh&th,u, ds fy, foLr`r fØ;kfof/k tkjh djsxh vkSj mls dsUnzh;
vk;ksx dh lwpuk ds fy, izLrqr djsxh:
¼d½ fofu;e 28-4 ds v/khu vfxze vkosnu
¼[k½ fofu;e 28-4 ds v/khu vR;ko';d vkosnu;
¼x½ fofu;e 28-4 ds v/khu ikoj ,Dlpst
a }kjk vkosnu;
¼?k½ fofu;e 30 ds v/khu vfxze vkosnu Js.kh ds v/khu Vh&th,u, dk vuqnku;
¼³½ fofu;e 30 ds v/khu vR;ko';d vkosnu Js.kh ds v/khu Vh&th,u, dk vuqnku;
¼p½ fofu;e 30 ds v/khu lkewfgd laO;ogkjksa ds v/khu Vh&th,u, dk vuqnku;
¼N½ fofu;e 31 ds v/khu LFkk;h fDy;jsal ;
¼t½ fofu;e 33 ds v/khu 'ksM~;wfyax vuqjks/k;
¼>½ fofu;e 34-4¼x½ ds v/khu ikoj ,Dlpst
a }kjk izfrns; ikjs"k.k izHkkj;
ijarq fd ,u,yMhlh dsUnzh; vk;ksx ds vuqeksnu ds fy, bu fofu;eksa ds fofu;e 36 ds laca/k esa foLr`r
fØ;kfof/k izLrqr djsxkA
varjjkfT;d ikjs"k.k ç.kkyh ds mi;ksx ds fy, ikjs"k.k izHkkj vkSj gkfu;ka 'ks;fjax fofue; ds vuqlkj bu fofu;eksa
ds fofu;e 17-1 ¼iii) ds v/khu doj dh xbZ bdkb;ksa lfgr vkbZ,lVh,l ds vkgfjrh esa 'ks;j fd;k tk,xkA

<!-- page 29 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

27

,d ckjxh th,u, izHkkj bu fofu;eksa ds fofu;e 22-2 ds [k.M ¼?k½ ds vuqlkj bu fofu;eksa ds fofu;e 17-1 ds
[k.M ¼iii½ vkSj fofu;e 4-1 ds v/khu doj dh xbZ bdkb;ksa }kjk izfrns; gksxkA
jk"Vªh; Hkkj izs"k.k dsUnz] izknsf'kd Hkkj izs"k.k dsUnz ¼,dhÑr Hkkj izs"k.k ;kstuk ds fy, izHkkj lfgr½ vkSj jkT; Hkkj
izs"k.k dsUnzksa ds fy, Qhl o izHkkj ykxw fofu;eksa ds vuqlkj th,u, vuqnkuxzkfg;ksa }kjk izfrns; gksx
a sA
fopyu izHkkj Mh,l,e fofu;eksa ds vuqlkj ykxw gksx
a sA
dsUnzh; vk;ksx] fyf[kr esa vfHkfyf[kr fd, tkus okys dkj.kksa ds fy,] bu fofu;eksa ds fdlh Hkh mica/k dks
Loizsj.kk ls ;k fdlh izHkkfor ikVhZ }kjk fd, x, vkosnu dks bu fofu;eksa ds izpkyu ls mn~Hkwr dfBukbZ dks nwj
djus ds fy, f'kfFky dj ldsxkA
;fn bu fofu;eksa ds mica/kksa dks izHkkoh cukus esa dksbZ dfBukbZ mRiUu gksrh gS] rks dsUnzh; vk;ksx] Loizsj.kk ls ;k
izHkkfor ikVhZ }kjk fd, x, vkosnu ij] ,sls vkns'k }kjk ,sls mica/k tks vf/kfu;e ds mica/kksa ;k dsUnzh; vk;ksx
}kjk fofufnZ"V vU; fofu;eksa ds mica/kksa ls vlaxr u gks] cuk ldsxk tks bu fofu;eksa ds mís';ksa dks izHkkoh djus
esa dfBukbZ dks nwj djus ds fy, vko';d :Ik esa ik;k tk,A
bu fofu;eksa esa vU;Fkk micaf/kr ds flok;] la;kstdrk fofu;e 2009 vkSj mlds v/khu fuEufyf[kr fØ;kfof/k;ksa
dks fujLr fd;k tkrk gS:
¼d½ dsUnzh; fo|qr fofu;ked vk;ksx ¼varjjkfT;d ikjs"k.k esa nh?kZdkfyd igqap ,oa e/;dkfyd fuckZ/k igqap]
la;kstdrk iznku djuk vkSj lac) ekeys½ fofu;e 2009 rkjh[k 31-12-2009 ds fofu;e 27 ds [k.M ¼1½ ds
v/khu dsUnzh; ikjs"k.k iz;ksT;rk dh foLr`r fØ;kfof/k;kaA
¼[k½ fnukad 20-2-2021 ds **varjjkfT;d ikjs"k.k iz.kkyh ds fy, uohdj.kh; lzksrksa ij vk/kkfjr ifj;kstuk dh
la;kstdrk iznku djuk** ds fy, la'kksf/kr fØ;kfof/k lfgr fnukad 15-5-2018 ds **varjjkfT;d ikjs"k.k iz.kkyh
ds fy, uohdj.kh lzksrksa ij vk/kkfjr ifj;kstuk dh la;kstdrk iznku djuk** ds fy, foLr`r fØ;kfof/kA
bu fofu;eksa esa vU;Fkk micaf/kr ds flok;] fuckZ/k igqap fofu;e vkSj mlds v/khu tkjh dh xbZ fuEufyf[kr
fØ;kfof/k;ksa dks fujLr fd;k tkrk gS :
¼d½ fnukad 30-6-2011 varjjkfT;d ikjs"k.k ¼f}i{kh; laO;ogkj½ esa vYidkfyd fuckZ/k igqap vuqlwphdj.k ds
fy, fØ;kfof/k
¼[k½ fnukad 30-6-2011 ds vuqlwphdj.k ds fy, varjjkfT;d ikjs"k.k ¼lkewfgd laO;ogkj½ fØ;kfof/k esa
vYidkfyd fuckZ/k igqapA
bl izdkj ds fujlu gksrs gq, Hkh :
¼d½ fopyu O;oLFkkiu ra= fnukad 12-8-2014 ds ek/;e ls pj.k ds vkjaHk gksus ds v/khu mRiknu LVs'kuksa }kjk
fxzM ls LVkVZvi fo|qr izkIr djus ds fy, fØ;kfof/k vkSj LVkVZvi fo|qr rFkk buQeZ ikoj ls lac)
la;kstdrk fofu;e 2009 ds fofu;e 8 ds [k.M ¼7½ izo`Rr jguk tkjh jgsx
a s tc rd fd rnuq:ih mica/kksa dks
fxzM dksM esa 'kkfey ugha fd;k tkrk vkSj izHkkoh ugha gks tkrsA
¼[k½ okLrfod le; cktkj ls lac) fofu;e 2 ds [k.M ¼1½ ds mi[k.M ¼N&d½] fofu;e 2 ds [k.M 1 ds
mi[k.M ¼M&d½] fofue; 13 [k.M 13 ¼d½ vkSj fofu;e 20 ds [k.M ¼1½ rFkk okLrfod le; cktkj ds ek/;e
ls lkewfgd le; cktkjksa dh okLrfod le; cktkjksa ds ek/;e lkewfgd laO;ogkjksa dh 'ksM~;wfyax ds fy,
fØ;kfof/k izo`Rr jguk tkjh jgsx
a s tc rd fd rnuq:ih mica/kksa dks fxzM dksM esa 'kkfey ugha fd;k tkrk vkSj
izHkkoh ugha gks tkrsA
¼x½ ckaXykns'k dks fu;kZr ds fy, nh?kZdkfyd igqap ikjs"k.k izHkkjksa ds fy, Hkqxrku lfgr ekStwnk O;oLFkk ds
vuqlkj izo`Rr jguk tkjh jgsxkA
¼?k½ fujflr fofu;eksa ds v/khu fu"ikfnr lHkh djkjksa dks bu fofu;eksa dh vf/klwpuk ds 30 fnuksa ds vanj bu
fofu;eksa ds lkFk vuq:Ik gksx
a sA
dsUnzh; vk;ksx bu fofu;eksa ds dk;kZUo;u ls lacaf/kr Loizsj.kk vkns'k vkSj i)fr funsZ'k vkSj vkdfLed ;k
mldh vkuq"kafxd ekeyks]a tSlh Hkh fLFkfr gks] dks le; le; ls tkjh djsA
gjizhr flag izqFkh] lfpo
[जवज्ञापन III/4/असा./185/2022-23]

<!-- page 30 -->

28

[PART III—SEC.4]

THE GAZETTE OF INDIA : EXTRAORDINARY

vuqc/a k-I

A1= 0.5*
X1+0.5*
Y1
(
)

(Y1)

(X1)
(

(

(Y2)

(X2)
(

)

)

A2= 0.5*
X2 +0.5*
Y2(
)

(

(Y3)

(X3)

)
(

A3= 0.5*
(
)
X3+0.5*
=
Y3(
A1A2&A3
)

(

)

)

)
2018-19

2019-20

2020-21

paMhx<+

262

474

368

267

431

349

233

383

308

342

fnYyh

3735

5626

4681

3954

6257

5105

3642

5646

4644

4810

gfj;k.kk

5004

7739

6371

5728

8117

6922

5756

9132

7444

6913
5418**

fgekpy izns'k

793

1421

1107

743

1398

1071

751

1675

1213

1130

tEew ,oa d'ehj

1605

2210

1907

1570

2305

1937

1728

2444

2086

1977

iatkc

3556

6608

5082

4198

6681

5440

4823

7119

5971

5497

jktLFkku

3946

5668

4807

4429

7834

6131

5144

7512

6328

5755

mÙkj izns'k

7343

10648

8996

8551

12500

10525

8999

12952

10975

10165

mÙkjk[k.M

1154

1654

1404

1016

1761

1389

1117

1709

1413

1402

NÙkhlx<+

1320

2492

1906

1743

2626

2184

1716

3001

2358

2149

nknjk uxj gosyh

757

825

791

776

839

807

664

894

779

792

neu nho

320

355

337

317

363

340

278

367

323

334

xksok

476

598

537

518

639

578

459

596

527

548

xqtjkr

5491

8852

7172

4373

6547

5460

4731

8611

6671

6434

e/; izns'k

5363

8268

6815

5611

8521

7066

6639

9764

8202

7361

egkjk"Vª

6804

10488

8646

6751

9053

7902

7535

10344

8940

8496

vka/kz izns'k

2994

5015

4004

3094

5791

4443

4095

6110

5102

4516

dukZVd

3225

5026

4125

3232

4805

4019

3658

6312

4985

4376

dsjy

2269

2913

2591

2548

3034

2791

2365

2946

2655

2679

iqnqpsjh

359

413

386

376

464

420

352

427

390

398

rfeyukMq

6962

9732

8347

7673

10496

9085

7973

12227

10100

9177

rsyaxkuk

4511

6515

5513

4453

8145

6299

4720

8494

6607

6140

fcgkj

4291

5036

4664

4520

5664

5092

4773

5973

5373

5043

687

996

841

829

1,158

993

881

1,187

1,034

956

>kj[k.M

919

1167

1043

927

1270

1099

1050

1325

1188

1110

vksMh'kk

1909

3080

2494

1300

3166

2233

825

2661

1743

2157

flfDde

88

111

99

92

132

112

92

149

121

111

2549

6710

4629

2719

5334

4026

2091

4274

3183

3946

Mhohlh*

if'peh caxky

<!-- page 31 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

A1= 0.5*
X1+0.5*
Y1
(
)

(Y1)

(X1)
(

(

)

)

A2= 0.5*
X2 +0.5*
Y2(
)

(Y2)

(X2)
(

(

29

(Y3)

(X3)

)
(

A3= 0.5*
(
)
X3+0.5*
=
Y3(
A1A2&A3
)

(

)

)

)

v#.kkpy izns'k

135

155

145

119

155

137

107

134

120

134

vle

1273

1583

1428

1304

1737

1520

1391

1885

1638

1529

ef.kiqj

174

211

193

179

216

198

196

246

221

204

es?kky;

167

319

243

170

327

248

147

298

223

238

fetksje

72

115

93

77

110

93

79

119

99

95

ukxkySaM

118

153

135

124

144

134

119

149

134

134

f=iqjk

225

366

295

222

380

301

261

414

337

311

,Llkj LVhy
jsyos &
,uvkj&vkbZ,lVh
,l&;wih$

537

747

642

417

703

560

322

649

485

563

130

151

140

130

144

137

92

133

112

130

5

9

7

5

11

8

7

11

9

8

5

4

5

3

4

4

4

7

5

5

2

3

2

2

3

2

2

3

2

2

1

1.4

1.2

0.9

1.4

1.2

0.9

1.4

1.1

1.2

5

7

6

5

6

5

4

6

5

5

81541

124464

102998

85066

129272

107166

89822

138289

114054

106578

ihth&,pohMhlh&
,uvkj#
ihth&,pohMhlh&
MCY;wvkj#
ihth&,pohMhlh&
bZvkj#
ihth&,pohMhlh&
,ubZvkj#
ch,vkjlh

_
:

*Mhohlh }kjk vkgj.k esft;k FkeZy ikoj LVs'ku #7,oa8,nqxkZiqj LVhy FkeZy ikoj LVs'ku #1&2, dksMjek FkeZy ikoj LVs'ku#1&2,
cksdkjksa FkeZy ikoj LVs'ku A#1, j?kqukFkiqj FkeZy ikoj LVs'ku #1&2, ls var{ksi.k dks 'kkfey djrs gq, fopkj fd;k tkrk gS tks
lhVh;w iz.kkyh ls lac) gSA
** gfj;k.kk ds fy, th,u, 1495 esxkokV dks 'kkfey u djus ds ckn 5418 esxkokV gksxkA 1495 esxkokV ds fy, ikjs"k.k izHkkj
'ks;fjax fofu;eksa ds vuqlkj eSllZ vnkuh ikoj ¼eqUnzk½ fyfeVsM }kjk vnk fd;k tk,xkA
'ks;fjax fofu;eksa ds v/khu gfj;k.kk ds ikjs"k.k fopyu ds lax.kuk ds iz;kstu ds fy,] 1495 esxkokV ds vanj eSllZ vnkuh ikoj
¼eqUnzk½ fyfeVsM ls gfj;k.kk }kjk vuqlp
w h dks 'kkfey ugha fd;k tk,xkA
# ,pohMhlh lcLVs'ku esa vkbZ,lVh,l vkgj.kksa dks izknsf'kd Lrj ij lefUor fd;k x;k gS vkSj rnuqlkj th,u izknsf'kd Lrj ij
izLrkfor fd;k x;k gSA
$ vksjb;k ,oa nknjh esa vkbZ,lVh,l baVjQsl esa jsyos ¼izknsf'kd bdkbZ ds :Ik esa ekuk x;k½ }kjk vkbZ,lVh,l vkgj.k th,u,
vkgj.k ij th,u, ds fy, fopkj fd;k x;k gSA

<!-- page 32 -->

30

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

CENTRAL ELECTRICITY REGULATORY COMMISSION
New Delhi, the 7th June, 2022
PREAMBLE
No. L-1/261/2021/CERC.—Whereas it is necessary to provide for a regulatory framework to facilitate nondiscriminatory open access to licensees or generating companies or consumers for use of inter-State transmission
system through General Network Access and to consolidate the regulations on the subject, it is hereby specified as
under:
NOTIFICATION
In exercise of the powers conferred by sub-section (1) of Section 178 and clause (ze) of sub-section (2) of
Section 178 read with clause (47) of Section 2, clause (d) of sub-section (2) of Section 38, clause (c) of Section 40 and
clause (c) of sub-section (1) of Section 79 of the Electricity Act, 2003 and all other powers enabling it in this behalf
and after previous publication, the Central Electricity Regulatory Commission hereby makes the following
regulations, namely:
Chapter 1
Preliminary
1.

Short Title and Commencement

1.1.

These regulations may be called the Central Electricity Regulatory Commission (Connectivity and General
Network Access to the inter-State Transmission System) Regulations, 2022.

1.2.

These regulations shall come into force on such date as the Central Commission may notify.
Provided that different dates may be appointed for commencement of different regulations.

2.

Definition

2.1.

In these regulations, unless the context otherwise requires:
(a)

“Act” means the Electricity Act, 2003;

(b) “Associated Transmission System” or “ATS” for Applicant(s) for Connectivity means the ATS as
determined in accordance with Regulation 6 of these regulations;
(c) “Bilateral Transaction” means a transaction, other than collective transaction, for exchange of power
between a specified buyer and a specified seller directly or through a trading licensee or at a Power
Exchange;
(d)

“CEA Registry” means the Registry for maintaining database of generating stations as specified in the
CEA Technical Standards for Connectivity ;

(e)

“CEA Technical Standards for Connectivity” means the Central Electricity Authority (Technical
Standards for Connectivity to the Grid) Regulations, 2007;

(f)

“CEA Technical Standards for Construction” means the Central Electricity Authority (Technical
Standards for Construction of Electrical Plants and Electric Lines) Regulations, 2010;

(g)

“Central Commission” means the Central Electricity Regulatory Commission referred to in sub-section
(1) of Section 76 of the Act;

(h)

"Central Transmission Utility" or “CTU” shall have the same meaning as defined in sub-section 10 of
Section 2 of the Act;

(i)

“Collective Transactions” means the Collective Transactions as defined in the Power Market
Regulations;

(j)

“Communication Regulations” means the Central Electricity Regulatory Commission (Communication
System for inter-State transmission of electricity) Regulations, 2017;

(k)

“Connectivity” means the state of getting connected to the inter-State transmission system in
accordance with these regulations;

(l)

“Connectivity Regulations, 2009” means the Central Electricity Regulatory Commission (Grant of
Connectivity, Long-term Access and Medium-term Open Access in inter-State Transmission and
related matters) Regulations, 2009;

<!-- page 33 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

31

(m)

“Cross Border Regulations” means the Central Electricity Regulatory Commission (Cross Border
Trade of Electricity) Regulations, 2019;

(n)

“day” means the day starting at 00.00 hours and ending at 24.00 hours;

(o)

“dedicated transmission lines” shall have the same meaning as defined in sub-section (16) of Section 2
of the Act;

(p)

“DSM Regulations” means the Central Electricity Regulatory Commission (Deviation Settlement
Mechanism and related matters), Regulations, 2014;

(q)

“Energy Storage System” or “ESS” in relation to the electricity system, means a facility where
electrical energy is converted into any form of energy which can be stored, and subsequently
reconverted into electrical energy and injected back into the grid;

(r)

“General Network Access” or “GNA” means open access to the ISTS granted under these regulations;

(s)

“General Network Access Grantee” or “GNA Grantee” means a person who has been granted GNA or
is deemed to have been granted GNA under these regulations;

(t)

“Grid Code” means the Grid Code specified by the Central Commission under clause (h) of sub-section
(1) of Section 79 of the Act;

(u)

“inter-State transmission system” or “ISTS" means inter-State transmission system as defined in subsection (36) of Section 2 of the Act;

(v)

“intra-State entity” means a person whose metering is done either by the State Transmission Utility or
the Distribution Licensee, as the case may be, and energy accounting is done by the State Load
Despatch Centre or any other agency so authorized;

(w)

“Interface Meter” shall have the same meaning as defined in the Central Electricity Authority
(Installation and Operation of Meters) Regulations, 2006;

(x)

“Lead ESS” means

(i)

an ESS which is authorized by one or more ESS(s) or generating station(s) through an agreement for
applying for Connectivity to the ISTS at a single inter-connection point: or

(ii)

an ESS already having Connectivity to the ISTS, and through whose electrical system, Connectivity is
being sought by one or more ESS(s) or generating station(s) through an agreement.

(y) “Lead Generator” means,
(i) a generating station which is authorized by one or more generating station(s) or ESS(s) through an
agreement for applying for Connectivity to the ISTS at a single connection point: or
(ii) a generating station already having Connectivity to the ISTS, and through whose electrical system,
Connectivity is being sought by one or more generating station(s) or ESS(s) through an agreement.
(z) “National Load Despatch Centre” or “NLDC” means the National Load Despatch Centre (NLDC)
established under sub-section (1) of Section 26 of the Act;
(aa) “National Open Access Registry” or “NOAR” means the Registry as specified under Regulation 27 of
these regulations;
(ab) “Nodal Agency” means
(i)

the agency designated for Connectivity or GNA to the ISTS, which shall be the Central Transmission
Utility (CTU), for the purpose of Regulations 3 to 25 and Regulation 37 of these regulations;

(ii)

the agency designated for T-GNA for bilateral transactions which shall be RLDC of the region where
point of drawal is located, for the purpose of Regulations 26 to 36 of these regulations;

(iii) the agency designated for T-GNA for collective transactions which shall be NLDC, for the purpose of
Regulations 26 to 36 of these regulations;
(iv)

the agency for implementation and operation of NOAR which shall be NLDC, for the purpose of
Regulation 27 of these regulations;

(ac) "Open Access Regulations” means the Central Electricity Regulatory Commission (Open Access in
inter-State Transmission) Regulations, 2008;
(ad) “Power Market Regulations” means the Central Electricity Regulatory Commission (Power Market)
Regulations, 2021;
(ae) “Regional Entity” shall have the same meaning as defined in the Grid Code;

<!-- page 34 -->

32

THE GAZETTE OF INDIA : EXTRAORDINARY
(af)

[PART III—SEC.4]

“Regional Load Despatch Centre” or “RLDC” means the Regional Load Despatch Centre established
under sub-section (1) of Section 27 of the Act;

(ag) “Renewable Energy Generating Station” or “REGS” means a generating station based on a renewable
source of energy with or without Energy Storage System and shall include Renewable Hybrid
Generating Station;
(ah) “Renewable Hybrid Generating Station” or “RHGS” means a generating station based on hybrid of two
or more renewable source(s) of energy with or without Energy Storage System, connected at the same
inter-connection point;
(ai) “Renewable Power Park Developer” means an entity authorised by the Central Government or a State
Government as Power Park developer for Renewable Energy Generating Station(s);
(aj)

"RLDC Fees and Charges Regulations” means Central Electricity Regulatory Commission (Fees and
Charges of Regional Load Despatch Centre and other related matters) Regulations, 2019;

(ak) “Sharing Regulations” means Central Electricity Regulatory Commission (Sharing of inter-State
Transmission Charges and Losses) Regulations, 2020;
(al)

“Standing Clearance” means the clearance issued by concerned State Load Despatch Centre as
specified in Regulation 31 of these regulations;

(am) "State Transmission Utility" or “STU” shall have the same meaning as defined in sub-section (67) of
Section 2 of the Act;
(an) “Temporary GNA” or “T-GNA” means open access to the ISTS granted in terms of Chapter 6 of these
regulations;
(ao) “terminal bay” means the bay at ISTS sub-station where dedicated transmission lines of a Connectivity
grantee terminate;
(ap) “T-GNA Grantee” means a person which has been granted T-GNA under these regulations.
2.2.

Words and expressions used in these regulations and not defined herein but defined in the Act or any other
regulations specified by the Central Commission shall, unless the context otherwise requires, have the
meanings assigned to them under the Act or other regulations specified by the Central Commission, as the
case may be.

2.3.

Reference to any Acts, Rules and Regulations shall include amendments or consolidation or re-enactment
thereof.
Chapter 2
General Provisions

3.

Application for Grant of Connectivity and GNA

3.1.

Applications for grant of Connectivity or grant of GNA, as the case may be, shall be made online to the
Nodal Agency and shall be digitally signed by the Applicant.

3.2.

Each application for grant of Connectivity shall be accompanied by an application fee of Rs.5 lakh along
with applicable taxes.

3.3.

Each application for grant of GNA shall be accompanied by an application fee of Rs.5 lakh along with
applicable taxes.

Provided that no application fee shall be payable by the State Transmission Utilities while applying for GNA.
3.4.

An auto-generated acknowledgement for receipt of application bearing date and time of application shall be
issued to the Applicant and a copy thereof shall be displayed on the website of the Nodal Agency.

3.5.

After scrutiny, the Nodal Agency shall intimate the deficiencies, if any, in the application for grant of
Connectivity or grant of GNA, to the Applicant within one week of the receipt of application, in order of date
and time of receipt of application. The Applicant shall rectify the deficiency within one week thereafter,
failing which the application shall be closed and 20% of the application fee shall be forfeited. Balance 80%
of the application fee shall be refunded by the Nodal Agency to the Applicant within 15 days of closure of
the application.

3.6.

All applications for grant of Connectivity received from the Applicants covered under Regulation 4.1 of these
regulations, during the month by 2400 hours of the last day of the month, shall be processed together. The
inter-se priority of applications shall be accorded as per the date and time of receipt of the application,
wherever required.

<!-- page 35 -->

[भाग III—खण्ड 4]
3.7.

भारत का रािपत्र : असाधारण

33

If any application for grant of Connectivity or grant of GNA is withdrawn before the in-principle grant of
Connectivity in terms of Regulation 7 of these regulations or grant of GNA in terms of Regulation 22 of
these regulations, 50% of the application fee shall be forfeited. Balance 50% of the application fee shall be
refunded by the Nodal Agency to the Applicant within 15 days of withdrawal of the application:
Provided that if any application is withdrawn after the in-principle grant of Connectivity or grant of GNA,
such application shall be closed by the Nodal Agency within a period of 15 days from the date of
withdrawal and 100% of the application fee shall be forfeited.
Chapter 3
Connectivity

4.

Eligibility for Connectivity to ISTS

4.1.

The following entities shall be eligible as Applicants to apply for grant of Connectivity or for enhancement of
the quantum of Connectivity:
(a)

Generating station(s), including REGS(s), with or without ESS, with an installed capacity of 50 MW
and above individually or with an aggregate installed capacity of 50 MW and above through a Lead
Generator or a Lead ESS;

(b)

Captive generating plant with capacity for injection to ISTS of 50 MW and above;

(c)

Standalone ESS with an installed capacity of 50 MW and above individually or with an aggregate
installed capacity of 50 MW and above through a Lead ESS or Lead Generator;

(d)

Renewable Power Park Developer;

(e)

REGS or standalone ESS with an installed capacity of 5 MW and above applying for grant of
Connectivity to ISTS through the electrical system of a generating station already having
Connectivity to ISTS:

Provided that such an entity applying for grant of Connectivity to ISTS has an agreement with the said
generating station to share its electrical system and dedicated transmission lines, if any.
4.2.

Notwithstanding anything contained in Regulation 4.1, the entities having Connectivity shall be eligible, on
payment of application fees, to apply for enhancement of Connectivity of less than 50 MW subject to
available capacity in transmission system.

4.3.

A generating station, already connected to or intending to connect to intra-State transmission system shall
also be eligible as an Applicant for Connectivity.

5.

Application for Grant of Connectivity

5.1.

An Applicant, which is a generating station including REGS, shall apply for grant of Connectivity to the
Nodal Agency for the quantum equal to the installed capacity of the generating station:
Provided that if such an Applicant already has Connectivity to intra-State transmission system for part of its
installed capacity, it may apply for Connectivity to the ISTS for a quantum not exceeding the balance of the
installed capacity;
Provided further that if such an Applicant is a Renewable Hybrid Generating Station or REGS with storage, it
may apply for grant of Connectivity for a quantum less than or equal to the installed capacity.

5.2.

Notwithstanding anything contained in Regulation 5.1, a generating station or ESS, with prior approval of
CTU, shall be eligible to add, within the quantum of Connectivity granted to it, additional generation
capacity, including ESS.;
Provided that for such additional generation capacity, the said generating station shall be responsible for
compliance with the Grid Code and other regulations of the Central Commission.

5.3.

An Applicant, which is a captive generating plant, shall apply for grant of Connectivity for a quantum of its
proposed maximum injection to ISTS.

5.4.

An Applicant, which is a standalone ESS, shall apply for grant of Connectivity for a quantum of its proposed
maximum injection to ISTS or proposed maximum drawal from ISTS, whichever is higher.

5.5.

An Applicant, which is a Renewable Power Park Developer, shall apply for grant of Connectivity for the
quantum for which it has been authorised by the Central Government or a State Government as a Renewable
Power Park developer.

5.6.

An Applicant may apply for grant of Connectivity at (i) a terminal bay of an ISTS sub-station already
allocated to another Connectivity grantee or (ii) switchyard of a generating station having Connectivity to
ISTS, with an agreement duly signed between the Applicant and the said Connectivity grantee or the

<!-- page 36 -->

34

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

generating station having Connectivity to ISTS, as the case may be, for sharing the terminal bay or the
switchyard and the dedicated transmission lines, if any. The applicable Connectivity Bank Guarantee as per
Regulation 8 of these regulations shall be submitted by such Applicant.
5.7.

Two or more Applicants may apply for grant of Connectivity at a common terminal bay with an agreement
duly signed by such Applicants for sharing the dedicated transmission lines and the terminal bay(s). The
applicable Connectivity Bank Guarantee as per Regulation 8 of these regulations shall be submitted by each
such Applicant.

5.8.

The application for grant of Connectivity shall contain, inter alia, the following details, as applicable, duly
supported with relevant affidavit, as stipulated in the Detailed Procedure for Connectivity and GNA issued in
accordance with Regulation 39.1:
(i) Geographical location and installed capacity under Regulation 4.1 of these regulations;
(ii) Maximum quantum of power to be interchanged with ISTS and preferred point of connection to ISTS;
(iii) Date from which Connectivity is being sought;
(iv) Bank generated proof of digital payment for application fee;
(v) In case of a Company, Board Resolution authorizing a designated person for filing of application for
grant of Connectivity;
(vi) Registration Number along with certificate issued by the CEA Registry;
(vii) In case of Renewable Power Park Developer, authorisation by the Central Government or the State
Government, as applicable, to undertake infrastructural activities including arrangement for Connectivity
on behalf of solar power generators or wind power generators;
(viii) In case of application through Lead generator or Lead ESS, as the case may be, the Agreement for
sharing the dedicated transmission lines and terminal bay and the consent of the Lead Generator or Lead
ESS, as the case may be, to be responsible for compliance of the provisions of the Grid Code and other
regulations of the Central Commission;
(ix) In case of the Applicant covered under Regulation 5.6 of these regulations, the Agreement between the
Applicant and the Connectivity grantee or the generating station having Connectivity to ISTS, for sharing
the terminal bay or the switchyard, as the case may be, and the dedicated transmission lines, if any.
(x) In case of Applicant covered under Regulation 5.7 of these regulations, the Agreement between the
Applicant(s) for sharing the terminal bay and the dedicated transmission lines, if any.

6.

Interconnection Study by the Nodal Agency and ATS

6.1.

On receipt of applications for grant of Connectivity, the Nodal Agency shall carry out interconnection study
as specified in the CEA Technical Standards for Connectivity along with requirement of augmentation to the
existing ISTS , if any, for enabling transfer of power over ISTS under General Network Access:
Provided that the existing ISTS for the purpose of this Regulation shall include transmission system which
has been awarded for implementation, as on the last day of the month in which application for grant of
Connectivity complete in all respects, has been received:
Provided further that if any additional transmission system gets awarded for implementation before
completion of interconnection study, such additional transmission system shall also be considered as existing
ISTS.

6.2.

Of the augmentation requirement as identified under Regulation 6.1 of these regulations, augmentation
required for immediate evacuation of power of the Applicant (s), excluding terminal bay(s), shall be
considered as the Associated Transmission System (ATS) for the Applicant(s).

7.

In-principle Grant of Connectivity by the Nodal Agency

7.1.

In the event the Nodal Agency after the interconnection study undertaken in accordance with Regulation 6.1
of these regulations, determines that no ATS is required, the Nodal Agency shall intimate in-principle grant
of Connectivity to the Applicant within 30 days from the last day of the month in which the application had
been received along with details such as terminal bay(s), already available or to be developed under ISTS
through CTU, and minimum design features for dedicated transmission lines to be constructed by the
Applicant.

7.2.

In case the Nodal Agency, after the interconnection study undertaken in accordance with Regulation 6.1 of
these regulations, determines that ATS is required, the Nodal Agency shall intimate in-principle grant of
Connectivity to the Applicant within 60 days from the last day of the month in which the application had
been received:

<!-- page 37 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

35

Provided that intimation for in-principle grant of Connectivity shall mention the ATS and terminal bay(s),
estimated cost of such ATS and terminal bay(s), minimum design features for dedicated transmission lines to
be constructed by the Applicant and the likely date of start of Connectivity:
Provided further that the firm date of start of Connectivity shall be confirmed at the time of final grant of
Connectivity.
8.

Connectivity Bank Guarantee

8.1.

Connectivity Bank Guarantee shall be submitted by an Applicant in three parts, Conn-BG1 amounting to Rs.
50 lakhs, and Conn-BG2 and Conn-BG3, as provided in Regulations 8.2 and 8.3 of these regulations.

8.2.

For cases covered under Regulation 7.1 of these regulations, Conn-BG2 and Conn-BG3, shall be furnished as
under:
(a)

Conn-BG2 towards terminal bay(s) shall be furnished on the basis of number of terminal bay(s)
allocated as under:
Voltage level of allocated terminal bay

Conn-BG2 (per terminal bay)

132 kV

Rs. 2 crore

220/230 kV

Rs. 3 crore

400 kV

Rs. 6 crore

765 kV

Rs. 12 crore

Provided that if the entity (i) proposes to construct the terminal bay(s) on its own under Regulation 12.4 of
these regulations, or (ii) seeks Connectivity at a terminal bay constructed or being constructed by another
Connectivity grantee, or (iii) seeks Connectivity through electrical system or switchyard of a generating
station, no Conn-BG2 is required to be furnished.
(b) Conn-BG3 @ Rs. 2 lakh/MW, for the existing ISTS, shall be furnished by the entity.
(c) Conn-BG1, Conn-BG2 and Conn-BG3, as applicable, shall be furnished within 1 (one) month of
intimation of in-principle grant of Connectivity, failing which the application for Connectivity shall be
closed and application fee shall be forfeited.
8.3.

For cases covered under Regulation 7.2 of these regulations, the following procedure shall be followed:
(a) The entity that has been intimated in-principle grant of Connectivity, shall submit its consent for
execution of ATS and terminal bay(s), as intimated under Regulation 7.2 of these regulations, along with
Conn-BG1, within one month of intimation of in-principle grant of Connectivity, failing which the
application for Connectivity shall be closed and application fee shall be forfeited.
(b) The Nodal Agency, within 6 (six) months of furnishing of Conn-BG1 as per clause (a) of this
Regulation, shall intimate to such entity, (i) amount of Conn-BG2 to be furnished towards ATS and
terminal bay(s), which shall not exceed the estimated cost intimated under Regulation 7.2 of these
regulations, (ii) the timeline for completion of ATS and terminal bay(s), and (iii) firm date of start of
Connectivity:
Provided that if such ATS and terminal bay(s) are planned for more than one entity, Conn-BG2 shall be
furnished in proportion to the quantum of Connectivity applied for by such entities:
(c) In the event, the Nodal Agency does not intimate the details as per clause (b) of this Regulation within
6 (six) months, the Nodal Agency shall furnish the reasons for such non-intimation to the entity with a copy
to the Central Commission within one month of expiry of such period of six months with a probable date by
which the details of Conn-BG2 and such timeline shall be furnished:
Provided that in the event of non-intimation by Nodal Agency within six months, the entity shall have the
option of withdrawing the application for Connectivity and in such a case, the Conn-BG1 shall be returned
within one month of exercising option of withdrawal by the entity and application shall be closed.
(d)
The amount for which Conn-BG2 is to be furnished as per clause (b) of this Regulation, shall be
equal to estimated cost of ATS and terminal bay(s) and the timeline for completion of ATS and terminal
bay(s) shall be based on the scheduled date of commercial operation for such ATS and terminal bay(s).
(e)
The entity that has been intimated in-principle grant of Connectivity shall furnish Conn-BG2 within
1 (one) month of intimation by the Nodal Agency under sub-clause (b) of this Regulation, failing which
application for Connectivity shall be closed, Conn-BG1 shall be encashed and application fee shall be
forfeited.

<!-- page 38 -->

36

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

8.4.

Conn-BG1, Conn-BG2 and Conn-BG3 shall be issued by any scheduled commercial bank recognized by the
Reserve Bank of India, in favour of CTU, as per the Format stipulated in the Detailed Procedure for
Connectivity and GNA issued in accordance with Regulation 39.1.

9.

Final Grant of Connectivity by the Nodal Agency

9.1.

Within 15 days of receipt of Conn-BG2 and Conn-BG3, as applicable, the Nodal Agency shall intimate the
final grant of Connectivity to the entity that has been intimated in-principle grant of Connectivity. The
intimation shall contain, inter alia, the following:
(a)
Name of the ISTS sub-station or switchyard of the generating station, as the case may be, where
Connectivity is granted.
(b)

In case of an existing ISTS sub-station, the terminal bay location along with Single Line Diagram.

(c)
In case of an ISTS sub-station under-construction, the coordinates and scheduled date of commercial
operation of such ISTS sub-station, terminal bay location along with Single Line Diagram.
(d)
In case of a proposed ISTS sub-station, the tentative coordinates and the scheduled date of
commercial operation of such ISTS sub-station.
(e)

The broad design features of the dedicated transmission lines including voltage level.

9.2.

Where an Applicant has applied for Connectivity at the terminal bay already allocated to another
Connectivity grantee or where two or more Applicants have applied for Connectivity at a common terminal
bay, final grant of Connectivity as intimated under Regulation 9.1 of these regulations shall be subject to
availability of capacity in the dedicated transmission lines.

10.

Connectivity Agreement

10.1.

An entity which has been intimated the final grant of Connectivity, shall furnish technical connection data,
inter alia, generator data for fault studies, dynamic simulation data, details of data and voice
communication, to the Nodal Agency as stipulated in the Detailed Procedure for Connectivity and GNA
issued in accordance with Regulation 39.1:
Provided that in case the entity is not in possession of the final technical connection data, it may furnish
tentative data to form part of the Connectivity Agreement and furnish the final data at least 1 (one) year
prior to the physical connection. Such final technical connection data shall be appended with the
Connectivity Agreement.

10.2.

The Nodal Agency shall intimate the connection details, inter alia, details of protection equipment, system
recording, SCADA and communication equipment, within a period of one month from the date of receipt of
technical connection data under Regulation 10.1.

10.3.

Within 30 days of the intimation of connection details by the Nodal Agency under Regulation 10.2,
Connectivity Agreement shall be signed between the Nodal Agency and the entity which has been
intimated final grant of Connectivity. On signing of the Connectivity Agreement such entity shall become
the Connectivity grantee.

10.4.

The technical connection data indicated at Regulation 10.1 and connection details indicated at Regulation
10.2 shall form part of the Connectivity Agreement.

10.5.

Where Connectivity is granted at a proposed ISTS sub-station, the Nodal Agency, shall confirm the final
coordinates within 2 months of signing of the Connectivity Agreement and such coordinates shall not be
outside the radius of 5 km of the tentative coordinates already intimated.

10.6.

In case of failure to sign the Connectivity Agreement by the entity that has been intimated final grant of
Connectivity, as required under Regulation 10.3, the Nodal Agency may extend the time for signing the
Connectivity Agreement for a maximum period of 30 days, failing which the final grant of Connectivity
shall be revoked by the Nodal Agency under intimation to the Applicant, the Conn-BG1, Conn-BG2 shall
be encashed, and Conn-BG3 shall be returned.
Provided that where no construction of ATS or terminal bays has been awarded for implementation, ConnBG2 shall be returned within a month of such revocation.

10.7.

The Connectivity Agreement, inter alia, shall include the following and other details as may be stipulated in
the ‘Detailed Procedure for Connectivity and GNA’ issued in accordance with Regulation 39.1:
(a)
Details of the allocated terminal bay(s) at ISTS sub-station subject to provisions of Regulation 10.5
of these regulations;
(b)

Start date of Connectivity; and

<!-- page 39 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

37

(c)
Provision that in case of non-payment of transmission charges under Regulation 13 of the Sharing
Regulations for more than 3 months from the due date, the same may be recovered by encashing ConnBG1, Conn-BG2 and Conn-BG3, as required as per provision of Regulation 16.3 of these regulations.
10.8.

The entity, may, for drawal of Start-up power or injection of infirm power, identify elements in the ATS
and seek COD of those elements prior to the Start date of Connectivity as agreed in the Connectivity
Agreement. A separate agreement shall be signed between the Nodal Agency and the entity for the same
covering the commercial terms and conditions. Such entity shall be liable to pay transmission charges as
per Regulation 13 of the Sharing Regulations.

10.9.

Connectivity grantee shall submit a copy of the signed Connectivity Agreement to the RLDC, in whose
control area it is located.

10.10.

Connectivity grantee shall comply with the provisions of the CEA Technical Standards for Connectivity.

11.

Monitoring by the Nodal Agency

11.1.

Connectivity grantee shall update the status of implementation of work under its scope, including dedicated
transmission lines, every quarter to the Nodal Agency who shall update the same on its website.

11.2.

The Nodal Agency shall update the status of implementation of the ATS and terminal bays in respect of all
Connectivity grantees, every quarter, on its website.

11.3.

The Nodal Agency shall review and take corrective action based on the status of implementation of work
under the scope of the Connectivity grantee as submitted under Regulation 11.1 and status of
implementation of the ATS and terminal bay(s) as updated under Regulation 11.2.

11.4.

For optimal utilisation of transmission system, the Nodal Agency with consent of the concerned
Connectivity grantee(s), may rearrange the Connectivity across different terminal bay(s) of the same ISTS
sub-station.

11.5.

The Nodal Agency shall display the updated status of allocation of terminal bay(s), inter alia, quantum of
Connectivity granted bay-wise and balance quantum for which Connectivity can be granted bay-wise, at
existing or proposed ISTS sub-stations on its website and the same shall be updated on monthly basis.

12.

Dedicated Transmission Lines and Bay(s)

12.1.

In case Connectivity grantee is a generating station or a captive generating plant or a standalone ESS, the
dedicated transmission lines shall be established, operated and maintained by such Connectivity grantee.

12.2.

In case Connectivity grantee is a Renewable Power Park Developer, the dedicated transmission lines shall
be established, operated and maintained by such Renewable Power Park Developer.

12.3.

The dedicated transmission lines shall be constructed and maintained in accordance with CEA Technical
Standards for Construction.

12.4.

The terminal bay(s) at the ISTS sub-station shall be under the scope of the transmission licensee owning the
ISTS sub-station:
Provided that the Connectivity grantee may, if it so chooses, construct and maintain the terminal bay(s) at
its own cost, by entering into an agreement with the transmission licensee owning the ISTS sub-station,
subject to prior approval of the Nodal Agency:
Provided further that in case the Connectivity grantee chooses to construct the terminal bay(s) at its own
cost, no cost towards such terminal bay(s) shall be claimed by the Connectivity grantee in the event of
revocation of its Connectivity:
Provided also that in such case of revocation of Connectivity, the Connectivity grantee shall dismantle the
terminal bay within 3 months failing which the CTU may utilise the bay for some other Connectivity
applicant.

12.5.

In case of an entity covered under Regulation 17.1(iii), the line to connect such an entity to the ISTS and
necessary augmentation for providing connection to the ISTS, shall be constructed and maintained by a
licensee at the cost of such entity:

13.

Injection of Infirm Power and drawal of Start-up Power
Connectivity grantee shall be eligible to inject infirm power and draw start-up power in accordance with the
provisions of the Grid Code.

14.

Interface Meters

14.1.

Interface meters shall be installed by the Central Transmission Utility for and at the cost of the Connectivity
grantee and the GNA grantee covered under Regulation 17.1(iii) of these regulations.

<!-- page 40 -->

38

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

14.2.

Interface meters as installed under Regulation 14.1, shall be open for inspection by any person authorized
by the Central Transmission Utility or the Regional Load Despatch Centre in whose control area it is
located.

15.

Transfer of Connectivity

15.1.

A Connectivity grantee shall not transfer, assign or pledge its Connectivity and the associated rights and
obligations, either in full or in parts, to any person except as provided under Regulations 15.2 and 15.3 of
these regulations.
Provided that Connectivity granted to a parent company may be utilised by its subsidiary companies and
Connectivity granted to a subsidiary may be utilised by its parent company.

15.2.

Where the Connectivity grantee is an REGS, it may split its Connectivity in parts, after COD of such part,
subject to the minimum capacity in accordance with Regulation 4.1 of these regulations, and submit the
installed capacity of each part to the Nodal Agency. In such an event, the Connectivity shall be deemed to
have been split in proportion to installed capacity of each such part:
Provided that all liabilities and obligations in accordance with these regulations shall continue to remain
with the Connectivity grantee for each part.

15.3.

Any person which acquires 51% or more shareholding of the company or its subsidiary or affiliate company
owning REGS or part thereof in terms of Regulation 15.2, may after COD of such split part, apply to the
Nodal Agency for transfer of Connectivity. The Nodal Agency shall issue revised grant of Connectivity on
submission of applicable Conn-BG2 and Conn-BG3 by such person. The original grantee may substitute its
Conn-BG2 and Conn-BG3 with revised Conn-BG2 and Conn-BG3, to be intimated by CTU. On issue of
revised grant of Connectivity, such person shall enter into a fresh Connectivity Agreement and be
responsible for compliance with all applicable regulations.
Provided that all liabilities and obligations in accordance with these regulations, for the Connectivity not
transferred, shall continue to remain with the original Connectivity grantee.

16.

Treatment of Connectivity Bank Guarantee

16.1.

Conn-BG1 shall be returned within 30 days of declaration of commercial operation of full capacity by the
Connectivity grantee.

16.2.

Conn-BG2 and Conn-BG3 shall be returned in five equal parts over five years corresponding to the
generation capacity which has been declared under commercial operation by the Connectivity grantee.

16.3.

In case of non-payment of transmission charges under Regulation 13 of the Sharing Regulations for more
than 3 months from the due date, such transmission charges shall be recovered by encashing Conn-BG1 (if
subsisting), Conn-BG2 and Conn-BG3, as required. Connectivity shall be revoked from the date when
Conn-BG2 and Conn-BG3, as available is not sufficient to cover transmission charges under Regulation 13
of the Sharing Regulations.

16.4.

The proceeds of encashed Conn-BG1, Conn-BG2 and Conn-BG3 in terms of Regulation 16.3, shall be
adjusted in Monthly Transmission charges under the Sharing Regulations.
CHAPTER 4
General Network Access (GNA)

17.

Eligibility for GNA

17.1.

The following entities shall be eligible as Applicants to apply for grant of GNA or for enhancement of the
quantum of GNA:
(i) State Transmission Utility on behalf of intra-State entities including distribution licensees;
(ii) A drawee entity connected to intra-State transmission system;
(iii) A distribution licensee or a Bulk consumer, seeking to connect to ISTS, directly, with a load of 50
MW and above;
(iv) Trading licensees engaged in cross border trade of electricity in terms of the Cross Border
Regulations;
(v) Transmission licensee connected to ISTS for drawal of auxiliary power.

17.2.

Entities not covered under Regulation 17.1, which as on the date of coming into force of these regulations,
are connected to the ISTS or for whom Connectivity granted under Connectivity Regulations,2009 has
become effective, shall be eligible for applying for grant of GNA to the ISTS for the quantum equal to the
quantum of Connectivity, which shall be processed as per Regulation 37.6 of these regulations.

<!-- page 41 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

39

17.3.

The Applicant covered under Regulation 17.1(iii) of these regulations, may seek to connect at a terminal
bay of an ISTS sub-station already allocated to another such entity under regulation 17.1(iii), with an
agreement duly signed between the Applicant and the said entity for sharing the terminal bay.

18.

Deemed Grant of GNA

18.1.

On the date, these regulations come into force,
(a) GNA for a (i) State including intra-State entity(ies) and (ii) other drawee entities, shall be the average
of ‘A’ for the financial years 2018-19, 2019-20 and 2020-21:
where,
‘A’ = {0.5 X maximum ISTS drawal in a time block during the year} + {0.5 X [average of (maximum ISTS
drawal in a time block in a day) during the year]}
(b) GNA computed as per clause (a) of this Regulation is given at Annexure-I to these regulations.
(c) GNA for a State including intra-State entity(ies) as per clause (b) of this Regulation shall be deemed
to have been granted to STU of that State on behalf of such intra-State entities and shall remain valid until
relinquished in accordance with these regulations.
(d) GNA deemed to have been granted to STU as per clause (c) of this Regulation, shall be published by
the Nodal Agency within 30 days of notification of these regulations, as (i) GNA within the region and (ii)
GNA from outside the region, in proportion to contracts, within the region or outside the region, under
Long Term Access and Medium Term Open Access obtained in terms of the Connectivity Regulations,
2009.
(e) GNA deemed to have been granted to STU under clause(d) of this Regulation, shall be segregated for
each intra-State entity, including distribution licensee, by the respective SLDC, and intimated to STU,
Nodal Agency and NLDC within 1 month of publication of details by the Nodal Agency under clause (d) of
this Regulation.
Provided that in case an SLDC fails to provide such segregation, the pro rata GNA shall be allocated to
each intra-State entity in the ratio of their Long Term Access and Medium Term Open Access, as included
in the first bill raised in the previous month under the Sharing Regulations.
(f) Entity(ies) covered under Regulation 4.1 of these regulations where Long Term Access granted to
such entity or to its identified buyer, under the Connectivity Regulations, 2009 has become effective, shall
be deemed to have been granted GNA equal to the quantum of such Long term Access, under these
regulations.
(g) The Central generating stations which are connected to the grid and have not been granted Long term
Access under the Connectivity Regulations, 2009 but whose power is allocated by the Ministry of Power,
shall be deemed to have been granted GNA equal to the installed capacity of such generating station(s).
(h) Long Term Access granted to a Trading licensee, other than for cross border trade of electricity in
terms of the Cross Border Regulations, shall be part of the GNA deemed to have been granted to the
concerned grid connected entity(ies) under clauses (a) to (f) of this Regulation:
Provided that settlement of transmission charges inter-se between such trading licensee and the concerned
grid connected entity(ies) shall be made in terms of the existing agreement between them or as may be
mutually agreed.
(i) Long term Access granted to a Trading licensee engaged in cross border trade of electricity in terms of
the Cross Border Regulations shall be the GNA deemed to have been granted to such trading license under
these regulations for the period of such Long term Access.

18.2.

Details of entities deemed to have been granted GNA under these regulations shall be published by the Nodal
Agency on its website within 1 (one) month of coming into force of these regulations.

19.

Application for Grant of additional GNA by STU

19.1.

Within 3 months of coming into force of these regulations, STU may, on behalf of intra-State entities
including distribution licensees, apply for additional GNA over and above the GNA deemed to have been
granted under clauses (a) to (e) of Regulation 18.1 of these regulations (with entity-wise segregation)
indicating GNA within the region and from outside the region.

19.2.

STU, on behalf of intra-State entities including distribution licensees, may apply, once in a financial year
(starting from the financial year following the financial year in which these regulations have become
effective) by the month of September each year, for additional GNA for the next 3 (three) financial years
(with entity-wise segregation) indicating GNA within the region and from outside the region, as stipulated in
the ‘Detailed Procedure for Connectivity and GNA’, issued in accordance with Regulation 39.1:

<!-- page 42 -->

40

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

Provided that such additional GNA quantum to be added in each of the next three financial years shall be
applicable from a specified date of the respective financial year.
20.

Application for Grant of GNA by entities other than STU

20.1.

Entities covered under clauses (ii) and (iii) of Regulation 17.1 of these regulations, may apply for GNA
indicating bifurcation of GNA within the region and outside the region, from a specified date, for a specified
quantum, and for a specified period of more than eleven months.
Provided that the entities covered under clause (ii) of Regulation 17.1 of these regulations shall furnish
consent of the concerned STU in terms of availability of transmission capacity in intra-State transmission
system for such quantum and period of GNA.

20.2.

Entities covered under Regulation 17.1(iv) of these regulations, may apply separately for GNA for injection
into Indian grid or drawal from Indian grid, for a specified quantum, and for a specified period of more than
eleven months.

20.3.

Entities covered under clause (v) of Regulation 17.1 of these regulations, may apply for GNA from a
specified date, for a specified quantum, and for a specified period of more than eleven months.

21.

System Study by the Nodal Agency
The Nodal Agency, based on the applications received for grant of additional GNA, shall carry out system
study in accordance with the Rules and Regulations made under the Act and the CEA Transmission Planning
Criteria specified under the Act.

22.

Grant of GNA

22.1.

Grant of additional GNA to STU
(a) The Nodal Agency shall process all applications received under Regulation 19.1 of these regulations
together, within two months from last day of receipt of applications and grant additional GNA to STU
based on available transmission capacity, or on pro-rata basis, if necessary. GNA once granted shall remain
valid until relinquished.
(b) The Nodal Agency shall grant additional GNA to STU based on applications received under
Regulation 19.2 of these regulations by 31st March of the same financial year, keeping in view the available
transmission capacity or timeline of augmentation, indicating the date from which such additional GNA
shall be effective. GNA once granted shall remain valid until relinquished.
(c) The total GNA of STU shall be the sum of GNA deemed to have been granted under Regulation 18.1
and additional GNA granted under this Regulation.
(d) Intra-State entity-wise GNA deemed to have been granted to STU under Regulation 19.1 and
additional GNA granted under this Regulation shall form the basis for raising the bills under the Sharing
Regulations to such intra-State entities.

22.2.

Grant of GNA to entities other than STU
(a)
Connectivity grantees covered under Regulation 4.1 of these regulations shall be deemed to have
been granted GNA, equal to the quantum of Connectivity from the start date of Connectivity. In the event
of split or transfer of Connectivity in terms of Regulation 15 of these regulations, the corresponding GNA
shall be deemed to have been split or transferred, as the case may be.
(b)
The Nodal Agency shall grant GNA to entities covered under clauses (ii) to (v) of Regulation 17.1
specifying start date of GNA, as per the following timeline:
(i) where GNA is granted on the existing system: by the end of the month subsequent to the month
in which application complete in all respects has been received;
(ii) where augmentation of transmission system is required: within 180 days from the end of the
month in which application complete in all respects has been received:
Provided that the Nodal Agency shall grant GNA with start date of GNA keeping in view the
timeline of augmentation of the transmission system.
(c)

Entities covered under clause (iv) of Regulation 17.1 and
(i) applying GNA for injection into the Indian Grid shall comply with all requirements as applicable
to entities under Regulation 4.1:
(ii)For entities covered under Regulation 22.2 (c) (i), Conn-BG1, Conn-BG2 and Conn-BG3 shall be
returned in accordance with Regulation 16 of these regulations or on expiry of period of GNA,
whichever is earlier;

<!-- page 43 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

41

(iii) applying GNA for drawal from the Indian Grid shall comply with all requirements as applicable
to entities under Regulation 17.1(iii).
(d)
Entities covered under Regulation 4.1 and clause (iii) of Regulation 17.1 of these regulations shall
furnish one-time GNA charge for Rs. one lakh per MW for the quantum of GNA one month prior to the
start date of GNA. In case, such charges are not furnished by the entity within the specified timeline, the
same shall be recovered by encashment of Conn-BG1, Conn-BG2 and Conn-BG3 as required. The proceeds
of such one-time GNA charge shall be used for reducing Monthly Transmission Charges under the Sharing
Regulations.
Provided that the entities covered under Regulation 17.1(iii) shall pay monthly transmission charges for its
GNA in addition to one time GNA charge in accordance with the Sharing Regulations.
22.3.

Details of entities which have been granted GNA along with quantum, period and start date of GNA shall
be published by the Nodal Agency, on its website, within one (01) month of grant of GNA.

22.4.

Effective Date of GNA
(a)
For Connectivity grantees covered under Regulation 4.1 of these regulations, the effective date of
GNA of such Connectivity grantees shall be the start date of Connectivity or COD of ATS, whichever is
later.
Provided that where only some of the transmission elements of the ATS have achieved COD before the
COD of the ATS and the Connectivity grantee seeks part effectiveness of its Connectivity, the Nodal
Agency shall make such part Connectivity and corresponding GNA effective, subject to availability of
transmission system.
Provided also that where such GNA is yet to become effective, such entity shall be eligible to get its power
scheduled partly or fully of the quantum of Connectivity sought for, subject to availability of transmission
system by treating such access as deemed T-GNA, and shall not be required to pay T-GNA charges.
(b)
For entities covered under Regulation 17.1, in case the effective date of GNA intimated in the grant
of GNA is to be revised keeping in view COD of the augmentation identified at the time of grant of the
GNA, the Nodal Agency shall, at least 3 (three) months prior to the revised effective date of GNA, give a
notice to such entities, indicating the revised date from which the GNA shall be effective.
(c)
For entities covered under Regulation 17.1, where such entity seeks to advance the date from which
GNA shall be effective for full or part quantum of GNA granted, the Nodal Agency shall make such GNA
effective, subject to availability of transmission system.

23.

Use of GNA by other GNA grantee(s)

23.1.

An entity covered under Regulation 17.1 which is a GNA grantee, may authorise other entities covered
under Regulation 17.1 which are GNA grantee(s), to use its GNA, in full or in part, with prior approval of
the Nodal Agency, for a period not exceeding 1 (one) year at a time on mutually agreed terms and
conditions:
Provided that payment liability for transmission charges shall continue to be with the original GNA grantee
that authorised its GNA to be used by other GNA grantee(s):
Provided further that for the purpose of calculating the transmission deviation charges under the Sharing
Regulations, GNA authorised to be used by other GNA grantee(s) shall be reduced from original GNA
grantee that authorised its GNA to be used by other GNA grantee(s) and shall be added to GNA of other
GNA grantee(s) which is using it.

23.2.

The GNA grantee that intends to authorise the use of its GNA by other GNA grantee(s), shall apply to the
Nodal Agency in terms of the Detailed Procedure for Connectivity and GNA issued in accordance with
Regulation 39.1.
Chapter-5
Relinquishment of Connectivity and GNA

24. Relinquishment of Connectivity
24.1.

Connectivity grantee may relinquish, in full or in part, the Connectivity with a notice of 30 days to the
Nodal Agency. The Nodal Agency shall issue revised grant of Connectivity to such Grantee, in case the
Connectivity has been relinquished in part.

24.2.

For entities covered under Regulation 7.1 and where Conn-BG2 and Conn-BG3, as applicable, has been
furnished as per Regulation 8.2 of these regulations, the following shall apply:

<!-- page 44 -->

42

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

(a) In case of relinquishment of full quantum of Connectivity, (i) subsisting Conn-BG1 shall be encashed,
(ii) subsisting Conn-BG2 shall be encashed if the terminal bay(s) are already developed or construction of
which has already been awarded for implementation and (iii) subsisting Conn-BG3 shall be encashed.
(b) In case of relinquishment of part quantum of Connectivity, (i) subsisting Conn-BG2 shall be encashed
in proportion to the relinquished quantum of Connectivity if the terminal bay(s) are already developed or
the construction of which has already been awarded for implementation and (ii) subsisting Conn-BG3
corresponding to the relinquished quantum of Connectivity shall be encashed. Conn-BG1 shall be returned
in terms of Regulation 16.1 considering full capacity after excluding such relinquished quantum.
24.3.

For entities covered under Regulation 7.2 and where Conn-BG2 has been furnished as per Regulation 8.3 of
these regulations, the following shall apply:
(a) In case of relinquishment of full quantum of Connectivity, subsisting Conn-BG1 shall be encashed and
subsisting Conn-BG2 shall be encashed corresponding to the ATS and terminal bay(s), construction of
which has already been awarded for implementation.
(b) In case of relinquishment of part quantum of Connectivity, subsisting Conn-BG2 shall be encashed in
proportion to the relinquished quantum of Connectivity corresponding to the ATS and terminal bay(s),
construction of which has already been awarded for implementation. Conn-BG1 shall be returned in terms
of Regulation 16.1 considering full capacity after excluding such relinquished quantum.

24.4.

In case of revocation of Connectivity or relinquishment of Connectivity, corresponding GNA shall be
reduced. In case a Connectivity grantee relinquishes the Connectivity in full, it shall be disconnected from
the ISTS from the date of relinquishment of Connectivity. On revocation, there shall be no more billing for
the corresponding quantum, under Regulation 13 of the Sharing Regulations.

24.5.

The proceeds of encashed Conn-BG1, Conn-BG2 and Conn-BG3 in terms of Regulations 24.2 or 24.3 of
these regulations, shall be used for reducing Monthly Transmission Charges under the Sharing Regulations.

25.

Relinquishment of GNA

25.1.

For an entity covered under Regulation 17.1, GNA once granted can be relinquished with a notice of 30
days to the Nodal Agency, in full or in part, on payment of relinquishment charges in advance as per
following:
(a) For an entity covered under clause (i) of Regulation 17.1 of these regulations, STU may relinquish
GNA on behalf of identified intra-State entity. The relinquishment charges shall be equal to 24 times the
transmission charges paid by such intra-State entity for the last billing month under the Sharing
Regulations, corresponding to the relinquished quantum.
(b) For an entity covered under clauses (ii) to (iv) of Regulation 17.1 of these regulations, the
relinquishment charges shall be equal to 24 times, the transmission charges paid by such entity for the last
month under the Sharing regulations, corresponding to the relinquished quantum.
Provided that, if the balance period of GNA is less than 24 months, the relinquishment charges shall be
equal to the number of balance months times the transmission charges paid by such entity for the last month
under the Sharing Regulations, corresponding to the relinquished quantum.
(c) Relinquishment charges received under clauses (a) and (b) of this Regulation shall be used for
reducing Monthly Transmission Charges under the Sharing Regulations.
(d) On relinquishment of full quantum of GNA by entity covered under clause (iii) of Regulation 17.1 of
these regulations, such entity shall be disconnected from the grid.

25.2.

In case an intra-State entity including a distribution licensee having GNA covered under clause (i) of
Regulation 17.1, substitutes GNA with GNA under clause (ii) of Regulation 17.1, GNA for such intra-State
entity shall be reduced from the total GNA of STU as held under clause (c) of Regulation 22.1, for the
quantum so substituted and for such substituted period.
CHAPTER 6
Temporary General Network Access

26.

Eligibility for Temporary GNA

26.1.

The following entities shall be eligible as Applicants to apply for T-GNA to ISTS:
(a)

As buyers,
(i) Distribution licensee directly connected to ISTS;
(ii) Bulk consumer directly connected to ISTS;

<!-- page 45 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

43

(iii) A buying entity connected to intra-State transmission system or to distribution system connected
to such intra-state transmission system;
(iv) Generating station including REGS for meeting its auxiliary consumption or start-up power or
for meeting its supply obligations in terms of clause (3) of Regulation 6 of the Power Market
Regulations;
(v)

Captive generating plant;

(vi) Standalone ESS;
(vii) REGS for drawal during non-generation hours.
(b)
Trading licensee (i) on behalf of buyer(s) covered under clause (a) of this Regulation, and (ii)
engaged in cross border trade of electricity in terms of the Cross Border Regulations for injection into or
drawal from the Indian grid.
(c)
Power exchange for collective transactions or bilateral transactions on behalf of (i) buyer(s) covered
under clause (a) of this Regulation, and (ii) trading licensee(s) engaged in cross border trade of electricity in
terms of the Cross Border Regulations for injection into or drawal from the Indian grid.
26.2.

A GNA grantee shall be eligible to apply for T-GNA over and above the GNA granted to it, as per eligibility
under clause (a) of Regulation 26.1 this Regulation.

26.3.

The T-GNA applications shall be applied and processed through single window electronic platform, namely,
National Open Access Registry (NOAR).

27.

National Open Access Registry (NOAR)

27.1.

NOAR shall:
(i)

Provide the audit trail of T-GNA applications;

(ii)
Provide an interface with the software of the RLDCs and SLDCs for processing T-GNA
applications;
(iii) Provide an interface with the Power Exchange(s) for validation of standing clearance and processing
of intra-day, day ahead contingency, term-ahead, day-ahead and real time transactions;
(iv)

Provide a payment gateway for making payments related to T-GNA;

(v)
Provide Dash Board facility with real time information to RLDCs and SLDCs and act as a
repository of information related to T-GNA including standing clearance issued by RLDCs and SLDCs,
availability of transmission corridor, pending applications, and T-GNA granted and rejected;
(vi)

Facilitate generation of periodic reports for market monitoring and surveillance; and

(vii)

Facilitate any other functions, as directed by the Commission from time to time.

27.2.

NLDC shall be responsible for developing and maintaining NOAR and issue the Detailed Procedure for
T-GNA issued in accordance with Regulation 39.2 to operationalize NOAR.

28.

Application for grant of T-GNA

28.1.

T-GNA may be applied for any period from 1 (one) time block and up to 11 (eleven) months.

28.2.

On-line application for grant of T-GNA to the Nodal Agency for a specified quantum and specified time
period shall be accompanied by a non-refundable fee of Rupees five thousand (Rs.5000/-).

28.3.

An auto-generated acknowledgement for receipt of online application shall be issued. The
acknowledgement shall have time and date of receipt of the application and shall be taken as the day (D) of
the application for grant of T-GNA.

28.4.

Application for grant of T-GNA may be made under any of the following categories:
A. For bilateral transactions
(a)
Advance application for grant of T-GNA: Application made on the (D) day for grant of T-GNA
starting on or after the (D+3) day, which may fall either in the same month as the (D) day or in the
subsequent month.
(b)
Exigency application for grant of T-GNA: Application made on (D) day for grant of T-GNA with
scheduling for (S) day, which may be (D) day or (D+1) day or (D+2) day, with a minimum start time of 7
(seven) time blocks unless specified otherwise in the Grid Code:
Provided that the Exigency application for grant of T-GNA shall be made for any time block(s) between
0000 hrs to 2400 hrs of the (S) day.

<!-- page 46 -->

44

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

B. For collective transactions
Application shall be made by a power exchange as stipulated in the Detailed Procedure for T-GNA
issued in accordance with Regulation 39.2.
28.5.

Application for grant of T-GNA for a bilateral transaction shall contain the following:
(a)

Advance application category:
(i)

Quantum of T-GNA in MW;

(ii) Start time of T-GNA in terms of time-block and date;
(iii) End time of T-GNA in terms of time-block and date;
(iv) Point of injection, if available, or in the absence of the point of injection, the target injection
region;
Provided that in case of injection into the Indian grid in the course of cross border trade of electricity
in terms of the Cross Border Regulations, point of injection shall be furnished along with the
application.
(v) Point of drawal;
(vi) Standing Clearance of SLDC under whose jurisdiction the point of drawal is located, in case
the buyer is an intra-State entity and;
(vii) In case the seller is an intra-State entity and the point of injection is available, Standing
Clearance of SLDC under whose jurisdiction the point of injection is located:
Provided that in case the point of injection and corresponding Standing Clearance of SLDC under
whose jurisdiction the point of injection is located is not available at the time of making the
application, the same shall be submitted along with the scheduling request in terms of Regulation 33
of these regulations;
(viii) In case the seller is a regional entity and the point of injection is not available at the time of
making the application, the point of injection shall be submitted along with the scheduling request in
terms of Regulation 33 of these regulations.
(b)

Exigency application category:
(i)

Contracted quantum of power (MW) to be scheduled at point of injection;

(ii)

Start time of T-GNA in terms of time-block and date;

(iii)

End time of T-GNA in terms of time-block and date;

(iv)

Point of injection;

(v)

Point of drawal;

(vi) Standing Clearance of SLDCs under whose jurisdiction the point of drawal and point of
injection are located, in case the buyer or the supplier is an intra-State entity, as applicable.
(vii) Copy of the contract for sale and purchase of power
28.6.

Application for grant of T-GNA, under bilateral transactions, shall contain the following declarations by the
Applicant:
(a)

That necessary infrastructure for time-block wise metering and accounting in accordance with the
provisions of the Grid code and appropriate communication system in accordance with the
provisions of the Communication Regulations are in place for the point of drawal and point of
injection, if available.

(b)

That at the time of making of the Advance application for T-GNA, if the point of injection has not
been identified, availability of necessary infrastructure for time-block wise metering and accounting
in accordance with the provisions of the Grid code, appropriate communication system in
accordance with the provisions of the Communication Regulations for the point of injection and, the
Standing Clearance of SLDC, in case the seller is an intra-State entity, under whose jurisdiction such
point of injection is located, shall be submitted along with the scheduling request in terms of
Regulation 33 of these regulations.

(c)

That the Applicant indemnifies the Nodal Agency at all times from any and all claims, actions and
all other obligations by or to third parties arising out of or resulting from the transactions under TGNA.

<!-- page 47 -->

[भाग III—खण्ड 4]
(d)

भारत का रािपत्र : असाधारण

45

That there is a valid contract for the proposed scheduling:
Provided that in case of Advance application for T-GNA, the declaration that there is a valid
contract for the proposed scheduling shall be submitted, if not already submitted at the time of
making application for T-GNA, along with the scheduling request in terms of Regulation 33 of these
regulations.

28.7.

Application for grant of T-GNA for collective transactions by a power exchange shall contain Regional
entity-wise injection or drawal (in MW) for each block.

28.8.

The application fees in case of rejection of application for T-GNA shall be forfeited.

29.

Processing of applications for grant of T-GNA by Nodal Agency

29.1.

T-GNA shall be granted within the Available Transfer Capability (ATC) on the ISTS after accounting for
GNA of the GNA grantees.

29.2.

The GNA grantees shall have priority over the T-GNA grantees for use of the ISTS.

29.3.

Advance applications for T-GNA shall be considered on first-come-first-served basis and shall be processed
latest by 23.59 hrs of the (D+1) day, ’D’ being the date of making the application.

29.4.

Exigency applications for T-GNA with the schedule for (S) day shall be processed as under:
(a)

Applications received till 1300 hrs of (S-1) day shall be processed after 1300 hrs on (S-1) day on
first-come-first-served basis, and shall be finalised by 1400 hrs of (S-1) day.

(b)

Applications received after 1300 hrs of (S-1) day or in the (S) day shall be processed within 4 time
blocks, on first-come-first-served basis.

29.5.

T-GNA for collective transactions under day ahead market shall be processed by 1300 hrs of (S-1) day.

29.6.

T-GNA for collective transactions under real time market shall be processed within a time block.

29.7.

The Nodal Agency shall verify the following:
(A) In case of intra-State entity:
(i) In case buyer is an intra-State entity, Standing Clearance from SLDC under whose jurisdiction
the point of drawal is located, confirming (a) existence of infrastructure necessary for time-block
wise energy metering and accounting in accordance with the provisions of the Grid code, (b)
appropriate communication system in accordance with the provisions of the Communication
Regulations and (c) availability of transmission capacity in the intra-State network;
(ii) In case the seller is an intra-State entity and the point of injection is available, Standing
Clearance from SLDC under whose jurisdiction the point of injection is located, confirming (a)
existence of infrastructure necessary for time-block wise energy metering and accounting in
accordance with the provisions of the Grid code, (b) appropriate communication system in
accordance with the provisions of the Communication Regulations and (c) Availability of
transmission capacity in the intra-State network;
(iii) Available Transfer Capability (ATC) on the ISTS;
(iv) Declarations as provided in Regulation 28.6, as applicable, have been furnished.
(B) In case of Regional entity:
(i) In case the buyer (point of drawal) is a regional entity, confirmation through the RLDC under
whose jurisdiction such point of drawal is located:
(a) existence of infrastructure necessary for time-block wise energy metering and accounting
in accordance with the provisions of the Grid code and;
(b) appropriate communication system in accordance with the provisions of the
Communication Regulations.
(ii) In case the seller is a regional entity having point of injection under regional control area,
confirmation through the RLDC under whose jurisdiction such point of injection is located:
(a) existence of infrastructure necessary for time-block wise energy metering and accounting
in accordance with the provisions of the Grid code; and
(b) appropriate communication system in accordance with the provisions of the
Communication Regulations in force.
(iii) Available transfer capability (ATC) on ISTS.
(iv) Declarations as provided in Regulation 28.6, as applicable, have been furnished.

<!-- page 48 -->

46

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

30.

Grant of T-GNA

30.1.

NLDC or the nodal RLDC, as the case may be, shall convey the grant or otherwise of T-GNA to the
Applicant as per timelines stipulated in Regulation 29 of these regulations. In the event of rejection of
application for grant of T-GNA, NLDC or the nodal RLDC, as the case may be, shall give reasons for such
rejection to the Applicant in writing.

30.2.

In the event T-GNA as applied for, cannot be granted for full quantum and full period as sought in the
application, in view of constraints in transmission system, the application shall be rejected:
Provided that in case the Applicant has given consent in its application that T-GNA for part quantum or part
period or both may be granted to it, T-GNA for such part quantum and part period or both shall be granted
as per available transmission capacity.

31.

Standing Clearance for grant of T-GNA

31.1.

The application for Standing Clearance from SLDC, for grant of T-GNA, shall be made online for a
specified quantum and specified period.

31.2.

Where the existence of necessary infrastructure and availability of surplus transmission capacity in the
intra-State transmission network have been established, the concerned SLDC shall issue Standing
Clearance within three (3) working day of receipt of such application:
Provided that when application for Standing Clearance has been made for the first time by an entity, the
concerned SLDC shall issue Standing Clearance to the Applicant, within seven (7) working days of receipt
of the application.

31.3.

In case the concerned SLDC refuses to issue Standing Clearance on the grounds of non-existence of
necessary infrastructure or unavailability of surplus transmission capacity in intra-State transmission
network, such refusal shall be communicated to the Applicant through NOAR within the period of three (3)
working days or seven (7) working days, as the case may be, from the date of receipt of the application
along with reasons for such refusal:
Provided that where the concerned SLDC has not communicated approval or refusal of application for
Standing Clearance within the period of three working days or seven working days, as the case may be, the
Standing Clearance shall be deemed to have been granted at the end of the next day after expiry of such
period of three working days or seven working days, as the case may be, for a period for which such
Standing Clearance was applied for or a period of 7 days, whichever is lower.

31.4.

The T-GNA Grantee to whom the Standing Clearance has been issued in terms of Regulation 31.2 or
deemed to have been issued in terms of Regulation 31.3, shall bid in the power exchange(s) in such a
manner that the aggregate quantum in each time block for all the bid(s) under bilateral transactions and
collective transactions shall not exceed the quantum of Standing Clearance:
Provided that if the aggregate quantum of bid(s) in the power exchange(s) under bilateral transactions and
collective transactions by a T-GNA grantee exceeds the quantum of the Standing Clearance in any time
block, NLDC shall debar such T-GNA grantee from participating in bilateral and collective transactions for
a period of seven (7) days under intimation to the concerned SLDC;
Provided further that the list of such T-GNA grantees debarred in terms of the above proviso shall be
displayed on NOAR.

31.5.

The concerned SLDC may revise the quantum or period of the Standing Clearance issued in respect of any
T-GNA grantee only in case of constraints in transmission system or in the interest of secure grid operation.

32.

Revision of T-GNA

32.1.

T-GNA granted under Exigency application category or under Advance application category for a period
not exceeding one month cannot be revised.

32.2.

T-GNA granted under Advance application category for a period of more than one month may be reduced
for the balance period with a prior notice of one (1) month by the T-GNA grantee:
Provided that applicable T-GNA charges for the quantum of T-GNA granted shall be payable for the notice
period of one (1) month.

33.

Scheduling request for power under T-GNA

33.1.

Advance application category:
(a) Scheduling request by T-GNA grantees under Advance application category shall be made on day
ahead basis before the opening of bidding window for collective transactions under day ahead market, as
per provisions of the Grid Code.

<!-- page 49 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

47

(b) In case the seller is an intra-State entity having point of injection under state control area, the
scheduling request shall be accompanied by Standing Clearance in terms of sub clause (vii) of Clause (a)
of Regulation 28.5 of these regulations.
(c) In case the seller is an regional entity having point of injection under regional control area, the point
of injection shall be furnished in terms of sub-clause (viii) of clause (a) of Regulation 28.5 of these
regulations.
(d) The scheduling request shall be accompanied by a declaration that there is a valid contract, in terms of
Proviso to clause (d) of Regulation 28.6 of these regulations, along with a copy of contract for sale and
purchase of power.
33.2.

T-GNA granted under Exigency application category shall be considered as scheduled, which cannot be
revised.

33.3.

T-GNA grantee under Advance application category may request to schedule power upto its T-GNA
quantum at the time of making scheduling request, before the opening of bidding window for collective
transactions under day ahead market for the next day:
Provided that in case such T-GNA grantee does not schedule power up to its T-GNA quantum at the time of
making scheduling request, the unutilised quantum of T-GNA shall be released for collective transactions
under day ahead market, schedule revision by GNA grantees, Exigency applications for T-GNA and
collective transactions under real time market in terms of Regulation 36 of these regulations;

34.

Transmission charges for T-GNA

34.1.

Transmission charge rate for T-GNA, in Rs./MW/time block, for a State shall be published for each month
by the Implementing Agency in terms of the Sharing Regulations.

34.2.

Transmission charges for T-GNA, in case of bilateral and collective transactions, shall be payable only at
point of drawal, as per the last published Transmission charge rate for T-GNA for the State where such
point of drawal is located:
Provided that under collective transactions, transmission charges for T-GNA shall be payable for drawal
schedules more than GNA quantum or T-GNA quantum or both, as applicable.

34.3.

The transmission charges for T-GNA shall not be revised with retrospective effect.

34.4.

Payment of transmission charges for T-GNA:
(a)
Transmission charges for T-GNA under Advance application category shall be deposited by the TGNA grantee with the Nodal Agency as under:
(i) For T-GNA up to one (1) month - within three (3) working days of grant of T-GNA:
Provided that where T-GNA is starting within next 3 working days, transmission charges for T-GNA
shall be deposited before the start date of T-GNA;
(ii) For T-GNA for more than 1 month - charges for the first month, within three (3) working days of
grant of T-GNA but before the start date of T-GNA and charges for each subsequent month
including part thereof, if any, on rolling basis, one month in advance.
(b)
Transmission charges for T-GNA under Exigency application category shall be deposited along with
the application. In case, the Exigency application is approved for part of the applied quantum or part of the
applied period or is rejected, the corresponding transmission charges shall be returned by the next day from
the date of approval or rejection:
Provided that the applicant may opt for keeping the excess transmission charges with the Nodal Agency to
be adjusted against future T-GNA applications.
(c)
Under collective transactions, the power exchange shall deposit the transmission charges for T-GNA
with the Nodal Agency by the 2400 hrs of (D+2) day, (D) being the day of application for grant of T-GNA:
Provided that the transmission charges for T-GNA for use of intra-State transmission system shall be settled
directly by the power exchange with respective State Load Despatch Centre.
(d)
In case any scheduling request under T-GNA is not approved by RLDC on day ahead basis or
curtailed for the reasons of transmission constraints or grid security, the transmission charges for such
quantum not scheduled or curtailed shall be refunded to the T-GNA grantee by 15th day of the next month.
Provided that non-availability of Standing Clearance shall not be treated as constraint in transmission
system.

34.5.

In case of default in payment of transmission charges for T-GNA, the T-GNA granted shall be cancelled.

<!-- page 50 -->

48

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

34.6.

In case of delay in payment of T-GNA charges under collective transactions, simple interest at the rate of
0.04% for each day of default shall be payable by the power exchange.

35.

Information about applications under T-GNA
The information related to approvals or rejections of applications of T-GNA, revisions or curtailment of
schedules, payment schedules and such other matters, shall be made available through NOAR to the
respective market participants including providing alerts through email or SMS or such other electronic
mode of communication.
Chapter 7
Allocation of Transmission Corridor under GNA and T-GNA

36.

Allocation of Transmission Corridor

36.1.

GNA grantee shall be eligible to schedule power within the GNA granted to it under any contract subject to
conditions specified in the Grid Code:
Provided that in case of constraint in transmission system, the available transmission corridor shall be
allocated to the GNA grantees in proportion to their GNA within the region or from outside region and the
GNA grantee shall be eligible to schedule power under any contract within such allocated transmission
corridor.

36.2.

T-GNA grantee under Advance application category, within the T-GNA granted to it, shall be eligible to
schedule power under any contract subject to the conditions specified in the Grid Code:
Provided that in case the day ahead scheduling request of T-GNA grantees for full quantum of T-GNA
cannot be accommodated due to non-availability of sufficient transmission corridor, scheduling shall be on
pro rata basis for T-GNA grantees in proportion to their T-GNA.

36.3.

Once the day ahead schedule is finalised for the GNA grantees, schedule for T-GNA grantees under
Advance application category of T-GNA shall be finalised over the balance transmission corridor.

36.4.

After allocation of transmission corridor to GNA grantees and T-GNA grantees under Advance application
category, the balance transmission corridor shall be released for collective transactions under day ahead
market.

36.5.

After finalisation of collective transactions under day ahead market, Exigency applications for grant of TGNA received till 1300 hrs of ‘S-1’ day or such time as specified in the Grid Code, shall be allocated the
transmission corridor.

36.6.

After the allocation of transmission corridors under Regulations 36.1 to 36.4, the balance transmission
corridor may be utilised by GNA grantee by way of revision of schedule, as stipulated in the Grid Code,
under any contract within its GNA or under Exigency application category or Real time market based on
time stamp for such request.
Chapter 8
Miscellaneous

37.

Arrangement for Transition

37.1.

If an application for grant of Connectivity or grant of Long term Access or grant of Medium Term Open
Access has been made in accordance with the Connectivity Regulations, 2009 and the same is yet to be
granted as on the date of coming into effect of these Regulations, the applicant shall have the option of,
either (a) to withdraw the application, in which case the application fee and bank guarantee, if any, shall be
returned, or (b) to convert the application as an application made under these regulations by complying with
the requirements under these regulations, which shall be processed in accordance with these regulations:
Provided that such option shall be exercised by the applicant within one month of coming into effect of
these Regulations, failing which the application shall be closed and the application fee and bank guarantee,
if any, shall be returned.

37.2.

If Connectivity has been granted but Long Term Access has not been granted in accordance with the
Connectivity Regulations, 2009 and Connectivity is yet to become effective as on the date of coming into
effect of these regulations, the same shall be treated as under:

<!-- page 51 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

49

(b)
The entity shall have the option of, either (i) to convert the Connectivity granted under the
Connectivity Regulations, 2009 as Connectivity made under these Regulations complying with the
requirements under these regulations, or (ii) to surrender such Connectivity.
(c)
Such option under clause (a) of this Regulation shall be exercised by the applicant within one month
of coming into effect of these Regulations, failing which the Connectivity granted under the Connectivity
Regulations, 2009 shall be considered as surrendered.
(d)
In case the Connectivity is surrendered in terms of option (ii) of clause (a) of this regulation or
clause (b) of this regulation, Conn-BG1 and Conn-BG2, if any, furnished under the Connectivity
Regulations, 2009 shall be returned.
Provided that in case the construction of terminal bay has been awarded for implementation under ISTS
through CTU, Conn-BG2 furnished under the Connectivity Regulations, 2009 shall be encashed.
(e)
In case, the entity exercises the option to convert the Connectivity granted under the Connectivity
Regulations, 2009 as Connectivity under these Regulations in terms of option (i) of clause (a) of this
regulation, the Nodal Agency shall, within next 30 days, intimate the amount of Conn-BG1, Conn-BG2 and
Conn-BG3, to be paid by such entity in terms of Regulation 8 of these regulations, after adjusting bank
guarantee, if any, paid by such entity under the Connectivity Regulations, 2009.
(f)
Conn-BG1, Conn-BG2 and Conn-BG3 shall be furnished by the entity within two (2) months of
intimation under clause (d) of this Regulation.
(g)
On furnishing of Conn-BG1, Conn-BG2 and Conn-BG3 under clause (e) of this Regulation, existing
agreements between the entity and the Nodal Agency shall be aligned with provisions of Regulation 10.3 of
these regulations.
(h)
On alignment of existing agreements under clause (f) of this Regulation, the entity shall become
Connectivity grantee for all purposes under these regulations.
(i)
In case the entity fails to furnish Conn-BG1, Conn-BG2 and Conn-BG3 as intimated by the Nodal
Agency in terms of clause (d) of this Regulation,
(i)
the Connectivity granted to the entity under the Connectivity Regulations, 2009 shall be
revoked by the Nodal Agency and
(ii) Conn-BG1 furnished, if any, under the Connectivity Regulations, 2009 shall be encashed and
(iii) Conn-BG2 furnished, if any under the Connectivity Regulations, 2009, shall be returned:
Provided that in case the construction of terminal bay has been awarded for implementation under
ISTS through CTU, Conn-BG2 furnished under the Connectivity Regulations, 2009 shall be
encashed.
37.3.

If Connectivity and Long Term Access have been granted in accordance with the Connectivity Regulations,
2009 but either both Connectivity and Long term Access are yet to become effective or Connectivity is
effective and Long term access is yet to become effective as on the date of coming into effect of these
regulations, the same shall be treated as under:
(1)
The quantum of Connectivity granted under the Connectivity Regulations, 2009, for which Long
term Access has not been granted shall be treated in terms of clause (1) of Regulation 37.6 or Regulation
37.2 depending on whether such Connectivity quantum is effective or not effective.
(2)
Where Long term Access has been granted on the existing system, the treatment of such Long term
Access and corresponding quantum of Connectivity shall be as under:
(a) The entity shall have the option of, either (i) to convert the Long term Access granted under the
Connectivity Regulations, 2009 as GNA under these Regulations, or (ii) to surrender such Long term
Access.
(b) Option under clause (a) of this Regulation shall be exercised by the entity within one month of
coming into effect of these Regulations, failing which such Long term Access granted under the
Connectivity Regulations, 2009 shall be considered as surrendered.
(c) In case the Long term Access is surrendered in terms of option (ii) of clause (a) of this
Regulation or clause (b) of this Regulation, the Application Bank Guarantee, if any, submitted by the
entity under the Connectivity Regulations, 2009 shall be returned.
(d) In case, the entity exercises the option (i) of clause (a) of this Regulation to convert the Long
term Access granted under the Connectivity Regulations, 2009 as deemed GNA under these
Regulations, it shall furnish Conn-BG1 for Rs. 50 lakhs and Conn-BG3 @ Rs. 2 lakh/MW
corresponding to such Long term Access quantum within two (2) months of exercising such option.

<!-- page 52 -->

50

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

In case any Conn-BG2 has been furnished under the Connectivity Regulations, 2009, the same shall
be treated as Conn-BG2 under these regulations. Subsequent treatment of Conn-BG1, Conn-BG2
and Conn-BG3 shall be in terms of Regulations 16.1 to 16.4 of these regulations. Bank Guarantee, if
any, furnished by such entity under the Connectivity Regulations, 2009 shall be adjusted.
(e) On furnishing of Conn-BG1 and Conn-BG3 under clause (d) of this Regulation, the Long term
access shall be treated as GNA deemed to have been granted under these regulations and the existing
agreements between the entity and the Nodal Agency shall be aligned with provisions of these
regulations.
(f) In case the entity fails to furnish Conn-BG1 and Conn-BG3 in terms of clause (d) of this
Regulation, the Long term access granted to the entity under the Connectivity Regulations, 2009
shall be considered as surrendered in terms of clause (b) of this Regulation.
(g) The quantum of Connectivity for the quantum of Long term access which has been converted
into GNA under clause (e) of this regulation, shall be treated as Connectivity granted under these
regulations.
(3)
Where Long term Access has been granted with system augmentation, the treatment of such Long
term Access and corresponding quantum of Connectivity shall be as under:
(a) The entity shall have the option of, either (i) to convert the Long term Access granted under the
Connectivity Regulations, 2009 as GNA under these Regulations, or (ii) to surrender such Long term
Access.
(b) Option under clause (a) of this Regulation shall be exercised by the applicant within one month
of coming into effect of these Regulations, failing which the Long term Access granted under the
Connectivity Regulations, 2009 shall be considered as surrendered.
(c) In case the Long term Access is surrendered in terms of option(ii) of clause (a) or clause (b) of
this Regulation, the Construction Bank Guarantee furnished under Connectivity Regulations, 2009
shall be encashed to the extent of estimated cost of ATS has been awarded for implementation
(maximum up to value of the bank guarantee already furnished) and balance, if any, shall be
returned. The quantum of Connectivity granted under the Connectivity Regulations, 2009 for such
quantum of Long term Access which has been surrendered shall be treated as per clause (1) of this
regulation.
(d) In case, the entity exercises the option (i) of clause (a) of this Regulation to convert the Long
term Access granted under the Connectivity Regulations, 2009 as GNA deemed to have been
granted under these regulations, the Construction Bank Guarantee already furnished shall be treated
as Conn-BG1 for Rs 50 lakhs and balance as Conn-BG2 under these regulations. In case no
construction bank guarantee has been furnished pursuant to signing of PPA and PSA, it shall furnish
Conn-BG1 for Rs. 50 lakhs and Conn-BG3 @ Rs. 2 lakh/MW corresponding to such Long term
access quantum within two (2) months of exercising the option (i) under clause (a) of this
Regulation. In case any Conn-BG2 has been furnished under Connectivity Regulations, 2009, the
same shall be treated as Conn-BG2 under these regulations. The Conn-BG1, Conn-BG2 and ConnBG3 shall be treated in terms of Regulations 16.1 to 16.4 of these regulations.
(e) On conversion of Construction bank guarantee as Conn-BG1 and Conn-BG2 or furnishing of
Conn-BG1 and Conn-BG3 in terms of clause (d) of this Regulation, as applicable, the Long term
Access granted under the Connectivity Regulations, 2009 shall be treated as GNA deemed to have
been granted under these regulations. The existing agreements between the entity and the Nodal
Agency shall be aligned in line with provisions of these regulations.
(f) In case the entity fails to furnish Conn-BG1 and Conn-BG3 in terms of clause (d) of this
Regulation, the Long term access granted to the entity under the Connectivity Regulations, 2009
shall be considered as surrendered in terms of clause (b) of this Regulation.
(g) The quantum of Connectivity for the quantum of Long term access which has been converted
into GNA under clause (e) of this Regulation, shall be treated as Connectivity granted under these
regulations.
37.4.

If Medium Term Open Access has been granted in accordance with the Connectivity Regulations, 2009, but
is yet to become effective as on the date of coming into effect of these regulations, the same shall be treated
as under:

(1) Medium Term Open Access granted to an entity covered under Regulation 4.1 of these regulations shall be
treated as under:

<!-- page 53 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

51

(a) The entity shall have the option of, either (i) to convert the MTOA granted under the Connectivity
Regulations, 2009 as GNA deemed to have been granted under these regulations for the period of
MTOA, or (ii) to surrender such MTOA.
(b)
Such option under clause (a) of this Regulation shall be exercised by the applicant within one
month of coming into effect of these Regulations, failing which the MTOA granted under the
Connectivity Regulations, 2009 shall be considered as surrendered.
(c) In case the MTOA granted under the Connectivity Regulations, 2009 is surrendered in terms of
option (ii) of clause (a) or clause (b) of this Regulation, the Bank Guarantee furnished for MTOA, if
any, shall be returned.
(d)
In case, the entity exercises the option (i) of clause (a) of this Regulation to convert the
Medium term open Access granted under the Connectivity Regulations, 2009 as GNA under these
regulations, it shall furnish Conn-BG3 @ Rs. 2 lakh/MW corresponding to such MTOA quantum
within two (2) months of exercising option (i) under clause (a) of this Regulation, which shall be
returned after completion of the term of MTOA. In case such entity has furnished any bank guarantee
for MTOA, the same shall be adjusted. Such MTOA shall be treated as GNA deemed to have been
granted under these regulations till expiry of the of MTOA.
(e) On furnishing of Conn-BG3 under clause (d) of this Regulation, Medium term open Access
granted under the Connectivity Regulations, 2009 shall be treated as GNA deemed to have been
granted under these regulations. The existing agreements between the entity and the Nodal Agency
shall be aligned in line with provisions of these regulations.
(f) In case the entity fails to furnish Conn-BG3 in terms of clause (d) of this Regulation, the MTOA
granted to the entity under the Connectivity Regulations, 2009 shall be considered as surrendered in
terms of clause (b) of this Regulation.
(g)
The Connectivity for the quantum of MTOA granted which has been converted into GNA
under clause (e) of this regulation, shall be treated as Connectivity granted under these regulations for
such quantum of MTOA, till expiry of the term of MTOA post which the entity may apply for
converting its Connectivity granted under the Connectivity Regulations, 2009 as Connectivity granted
under these regulations.
(2) Medium Term Open Access granted under the Connectivity Regulations, 2009 to an entity covered under
Regulation 17.1 of these regulations, shall be treated as GNA granted to that entity till expiry of the term of
Medium Term Open Access, with start date as the date from which such Medium Term Open Access was to
become effective.
37.5.

Long Term Access granted under the Connectivity Regulations, 2009 which has not become effective, to a
trading licensee other than that covered under Regulation 17.1 of these regulations shall be treated as
withdrawn and bank guarantee furnished, if any, shall be returned.

37.6.

If Connectivity granted in accordance with the Connectivity Regulations, 2009 is effective and Long term
Access has either not been granted for any capacity or has been granted for full/part capacity which has
become effective as on the date of coming into effect of these Regulations, the following shall apply:
(1) Entities covered under Regulation 4.1 of these regulations, which have not been granted Long Term
Access for any capacity or granted Long term access for part of the capacity qua the Connectivity
quantum under the Connectivity Regulations, 2009 may apply for additional GNA for balance quantum
of Connectivity under Regulation 17.2 of these regulations. The same shall be processed by the Nodal
Agency as under:
(a) In case additional GNA as applied for under Regulation 17.2 can be granted on existing
transmission system, the Nodal Agency shall grant such additional GNA on furnishing Conn-BG3 @
Rs.2 lakh/MW. Conn-BG3 shall be returned in five equal parts over the next five years starting from
the year when such GNA becomes effective or in accordance with Regulation 16.2 of these
regulations, whichever is later.
Provided that in case connectivity is relinquished in terms of Regulation 24.1 of these regulations,
subsisting Conn-BG3 shall be encashed.
(b) In case ATS is required for granting such additional GNA, the application shall be processed in
accordance with Regulation 8.3 of these regulations. Such additional GNA shall be granted on
furnishing of Conn-BG2. The Conn-BG1 shall be returned within 30 days of declaration of
commercial operation of capacity for which additional GNA has been granted. Conn-BG2 shall be
returned in five equal parts over five years starting from the year when such GNA becomes effective
or in accordance with Regulation 16.2 of these regulations, whichever is later.

<!-- page 54 -->

52

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

Provided that where only some of the transmission elements of the ATS have achieved COD before
the COD of the ATS and the Connectivity grantee seeks part effectiveness of its GNA, the Nodal
Agency shall make such part GNA effective, subject to availability of transmission system.
Provided also that after the GNA has been granted by the Nodal Agency but yet to become effective,
such entity shall be eligible to get its power scheduled partly or fully of the quantum of GNA sought
for, subject to availability of transmission system by treating such access as deemed T-GNA and shall
not be required to pay T-GNA charges.
Provided that in case connectivity is relinquished in terms of Regulation 24.1, subsisting Conn-BG2
shall be encashed in terms of Regulation 24.2 of these regulations.
(2) Entities covered under Regulation 4.1 of these regulations which have been granted Long Term Access
to the target region, shall furnish Conn-BG3 @ Rs. 2 lakh/MW. On furnishing such Conn-BG3, these
entities shall be treated as Connectivity grantee under these regulations having GNA corresponding to
such Long term access. Conn-BG3 shall be returned in five equal parts over the next five years starting
from the year when such GNA becomes effective or in accordance with Regulation 16.2 of these
regulations, whichever is later.
Provided that in case Connectivity is relinquished in terms of Regulation 24.1 of these regulations,
subsisting Conn-BG3 shall be encashed.
37.7.

If Long Term Access granted to entities covered under Regulation 17.1 of these Regulations, in accordance
with the Connectivity Regulations, 2009 has become effective it shall be considered as part of GNA
deemed to have been granted to the concerned entities under Regulation 18.1.

37.8.

Where Medium term open access granted, in accordance with the Connectivity Regulations, 2009 has
become effective as on the date of coming into effect of these Regulations, such open access shall be treated
as under:
(a)

For entities covered under Regulation 4.1 of these regulations, GNA corresponding to such Medium
term open access shall be deemed to have been granted to such entity, till the expiry of the such
Medium Term Open Access.
Provided that such entity may apply for GNA under Regulation 17.2 of these regulations.

(b) Medium Term Open Access granted to the entities covered under Regulation 17.1 of these regulations,
shall be considered as part of GNA deemed to have been granted to the concerned entities. The
corresponding quantum shall be considered as deemed GNA for entity covered under Regulation 4.1
of these regulations with whom the entity under Regulation 17.1 has entered into PPA.
37.9.

Short Term Open Access:
(a)
On the date of coming into effect of these Regulations, Short Term Open Access granted in
accordance with the Open Access Regulations shall be treated as T-GNA under Exigency application
category, granted for the term of such Short Term Open Access.
(b)
On the date of coming into effect of these Regulations, Short Term Open Access applications under
the Open Access Regulations pending with RLDC or NLDC shall be closed.

38.

Curtailment

38.1.

When for the reason of transmission constraints or in the interest of grid security, as per the provisions in
the Grid Code, it becomes inevitable to curtail power flow on a transmission corridor, the transactions
already scheduled may be curtailed by the Regional Load Despatch Centre as per the following provisions:
(a) Transactions under T-GNA shall be curtailed first followed by transactions under GNA.
(b) Within transactions under T-GNA, bilateral transactions shall be curtailed first followed by collective
transactions under day ahead market followed by collective transactions under real time market.
(c) Within bilateral transactions under T-GNA, curtailment shall be on pro rata basis based on T-GNA.
(d) Within transactions under GNA, curtailment shall be on pro rata basis based on GNA.

39.

Detailed Procedure

39.1.

Nodal Agency, i.e., CTU shall issue the ‘Detailed Procedure for Connectivity and GNA’ in line with these
regulations, including the following formats after stakeholders’ consultation within a period of 3 months of
notification of these regulations and submit the same for information of the Central Commission:
(a)

Affidavit by the applicant as referred to in Regulation 5.8;

(b) Application for Connectivity as referred to in Regulation 5.8;
(c)

Application for utilization of Connectivity under Regulation 5.2;

<!-- page 55 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

53

(d) Approval for utilization of Connectivity under Regulation 5.2;
(e)

Intimation for in-principle grant of Connectivity as referred to in Regulations 7.1 and 7.2;

(f)

Intimation of details under clause (b) of Regulation 8.3;

(g) Format for Conn-BG1,Conn-BG2 and Conn-BG3 under Regulation 8;
(h) Intimation for final grant of Connectivity under Regulation 9;
(i)

Technical connection data under Regulation 10.1;

(j)

Intimation of connection details under Regulation 10.2;

(k) Connectivity Agreement under Regulation 10.7;
(l)

Status updation of scope of works under Regulation 11.1;

(m) Status updation of ATS and terminal bay(s) under regulation 11.2;
(n) Status of allocation of terminal bay(s) and other details under Regulation 11.5;
(o) Application for transfer of Connectivity under Regulation 15.3;
(p) Application for grant of GNA under Regulation 17.1 and 17.2;
(q) Grant of GNA under regulation 22;
(r)

Application for use of GNA by other GNA grantee(s) under Regulation 23;

(s)

Relinquishment of Connectivity under Regulation 24;

(t)

Relinquishment of GNA under Regulation 25;

Provided that the Nodal Agency shall submit the Detailed Procedure in respect of Regulations 4.3, 5, 6,
10.7, 15, 16.2, 18.1, 23, 24, 25 and 37 of these regulations for approval of the Central Commission.
39.2.

For T-GNA, NLDC shall issue the Detailed Procedure for T-GNA including the following formats after
stakeholders’ consultation within a period of 3 months of notification of these regulations and submit the
same for information of the Central Commission:
(a) Advance Application under Regulation 28.4
(b) Exigency Application under Regulation 28.4;
(c) Application by power exchange under Regulation 28.4;
(d) Grant of T-GNA under Advance application category under Regulation 30;
(e) Grant of T-GNA under Exigency application category under Regulation 30;
(f) Grant of T-GNA under collective transactions under Regulation 30;
(g) Standing clearance under Regulation 31;
(h) Scheduling request under Regulation 33;
(i) Transmission charges payable by power exchange under Regulation 34.4(c)
Provided that NLDC shall submit the Detailed Procedure in respect of Regulation 36 of these regulations
for approval of the Central Commission.

40.

Payment of charges

40.1.

The transmission charges and losses for use of the inter-State transmission system shall be shared among
drawee DICs of ISTS including entities covered under Regulation 17.1(iii) of these regulations, in
accordance with the Sharing Regulations.

40.2.

One time GNA charges shall be payable by entities covered under Regulation 4.1 and clause (iii) of
Regulation 17.1 of these regulations in terms of clause (d) of Regulation 22.2 of these regulations.

40.3.

The fees and charges for National Load Despatch Centre, Regional Load Despatch Centres (including the
charges for Unified Load Despatch Scheme) and State Load Despatch Centres shall be payable by the GNA
grantees as per the applicable Regulations.

40.4.

Deviation charges shall be applicable as per the DSM Regulations.

41.

Power to Relax
The Central Commission, for reasons to be recorded in writing, may relax any of the provisions of these
regulations on its own motion or on an application made before it by an affected party to remove the
hardship arising out of the operation of these regulations.

<!-- page 56 -->

54
42.

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART III—SEC.4]

Power to Remove Difficulty
If any difficulty arises in giving effect to the provisions of these regulations, the Central Commission may,
on its own motion or on an application made before it by affected party by order, make such provision not
inconsistent with the provisions of the Act or provisions of other regulations specified by the Central
Commission, as may appear to be necessary for removing the difficulty in giving effect to the objectives of
these regulations.

43.

Repeal and Savings

43.1.

Save as otherwise provided in these regulations, the Connectivity Regulations, 2009 and the following
Procedures thereunder, are hereby repealed:
(a)
Detailed Procedures of Central Transmission Utility under clause (1) of Regulation 27 of the Central
Electricity Regulatory Commission (Grant of Connectivity, Long-term Access and Medium-term Open
Access in inter-State Transmission and related matters) Regulations, 2009 dated 31.12.2009.
(b)
Detailed procedure for “Grant of connectivity to projects based on renewable sources to inter-state
transmission system” dated 15.05.2018 along with Revised procedure for “Grant of connectivity to projects
based on renewable sources to inter-state transmission system” dated 20.02.2021.

43.2.

Save as otherwise provided in these regulations, the Open Access Regulations and the following Procedures
issued thereunder, are hereby repealed:
(a) Procedure for Scheduling Short-Term Open Access in Inter-State Transmission (Bilateral Transaction)
dated 30.6.2011
(b) Short-Term Open Access in Inter-State Transmission (Collective Transaction) Procedure for
Scheduling dated 30.6.2011.
(c) “Procedure for Short Term Open Access in inter-State Transmission System through National Open
Access Registry (NOAR) dated 1.4.2022” under Regulation 4 of the Central Electricity Regulatory
Commission (Open Access in inter-State Transmission)(Fifth Amendment) Regulations, 2018.

43.3.

Notwithstanding such repeal:
(a) Clause (7) of Regulation 8 of the Connectivity Regulations, 2009 related to infirm power and start up
power and Procedure for availing Start up power from the Grid by the Generating Stations under
commissioning phase through Deviation Settlement Mechanism dated 12.8.2014, shall continue to be in
force till corresponding provisions are included in the Grid Code and become effective.
(b) Sub-clause (g-a) of Clause (1) of Regulation 2, sub-clause (ma) of clause (1) of Regulation 2, clause
13(A) of Regulation 13 and clause (1) of Regulation 20 of Open Access Regulations, related to Real time
market and Procedure for Scheduling of Collective Transactions through Real Time Market shall continue
to be in force till corresponding provisions are included in the Grid Code and become effective.
(c) Long term Access for export to Bangladesh shall continue to be in effect as per the existing
arrangement including, payment for transmission charges.
(d) All the agreements executed under the repealed regulations shall be aligned with these regulations
within 30 days of notification of these regulations.

44.

Issue of Suo Moto Orders and directions
The Central Commission may from time to time issue suo moto orders and practice directions with regards
to implementation of these regulations and matters incidental or ancillary thereto, as the case may be.
HARPREET SINGH PRUTHI, Secy.
[ADVT.-III/4/Exty./185/2022-23]

<!-- page 57 -->

[भाग III—खण्ड 4]

भारत का रािपत्र : असाधारण

55
Annexure-I

GNA for States and other entities

State

Yearly
Average
of Daily
Max
ISTS
drawal
(X1)
(MW)

Yearly
Max ISTS
drawal
(Y1)
(MW)

A1= 0.5* X1
+ 0.5* Y1
(MW)

Yearly
Average
of Daily
Max
ISTS
drawal
(X2)
(MW)

2018-19

Yearly
Max ISTS
drawal
(Y2)
(MW)

A2 = 0.5*
X2 + 0.5*
Y2 (MW)

Yearly
Average
of Daily
Max
ISTS
drawal
(X3)
(MW)

2019-20

Yearly
Max ISTS
drawal
(Y3)
(MW)

A3= 0.5* X3
+ 0.5* Y3
(MW)

GNA
(MW)=
Average of
A1 A2 & A3

342

2020-21

Northern
Region
Chandigarh

262

474

368

267

431

349

233

383

308

Delhi

3735

5626

4681

3954

6257

5105

3642

5646

4644

4810

Haryana

5004

7739

6371

5728

8117

6922

5756

9132

7444

6913
5418**

HP

793

1421

1107

743

1398

1071

751

1675

1213

1130

J&K

1605

2210

1907

1570

2305

1937

1728

2444

2086

1977

Punjab

3556

6608

5082

4198

6681

5440

4823

7119

5971

5497

Rajasthan

3946

5668

4807

4429

7834

6131

5144

7512

6328

5755

UP

7343

10648

8996

8551

12500

10525

8999

12952

10975

10165

Uttarakhand

1154

1654

1404

1016

1761

1389

1117

1709

1413

1402

Chhattisgarh

1320

2492

1906

1743

2626

2184

1716

3001

2358

2149

Dadra
Nagar
Haveli

757

825

791

776

839

807

664

894

779

792

Daman Diu

320

355

337

317

363

340

278

367

323

334

Goa

476

598

537

518

639

578

459

596

527

548

Gujarat

5491

8852

7172

4373

6547

5460

4731

8611

6671

6434

Madhya
Pradesh

5363

8268

6815

5611

8521

7066

6639

9764

8202

7361

Maharashtra

6804

10488

8646

6751

9053

7902

7535

10344

8940

8496

Andhra
Pradesh

2994

5015

4004

3094

5791

4443

4095

6110

5102

4516

Karnataka

3225

5026

4125

3232

4805

4019

3658

6312

4985

4376

Kerala

2269

2913

2591

2548

3034

2791

2365

2946

2655

2679

Pondicherry

359

413

386

376

464

420

352

427

390

398

Tamil Nadu

6962

9732

8347

7673

10496

9085

7973

12227

10100

9177

Telangana

4511

6515

5513

4453

8145

6299

4720

8494

6607

6140

4291

5036

4664

4520

5664

5092

4773

5973

5373

5043

Western
Region

Southern
Region

Eastern
Region
Bihar
DVC*

687

996

841

829

1,158

993

881

1,187

1,034

956

Jharkhand

919

1167

1043

927

1270

1099

1050

1325

1188

1110

Odisha

1909

3080

2494

1300

3166

2233

825

2661

1743

2157

Sikkim

88

111

99

92

132

112

92

149

121

111

West
Bengal

2549

6710

4629

2719

5334

4026

2091

4274

3183

3946

<!-- page 58 -->

56

State

North
Eastern
Region
Arunachal
Pradesh
Assam
Manipur
Meghalaya
Mizoram
Nagaland
Tripura

[PART III—SEC.4]

THE GAZETTE OF INDIA : EXTRAORDINARY
Yearly
Average
of Daily
Max
ISTS
drawal
(X1)
(MW)

A1= 0.5* X1
+ 0.5* Y1
(MW)

Yearly
Average
of Daily
Max
ISTS
drawal
(X2)
(MW)

A2 = 0.5*
X2 + 0.5*
Y2 (MW)

Yearly
Average
of Daily
Max
ISTS
drawal
(X3)
(MW)

Yearly
Max ISTS
drawal
(Y1)
(MW)

Yearly
Max ISTS
drawal
(Y2)
(MW)

Yearly
Max ISTS
drawal
(Y3)
(MW)

A3= 0.5* X3
+ 0.5* Y3
(MW)

GNA
(MW)=
Average of
A1 A2 & A3

135

155

145

119

155

137

107

134

120

134

1273
174
167
72
118
225

1583
211
319
115
153
366

1428
193
243
93
135
295

1304
179
170
77
124
222

1737
216
327
110
144
380

1520
198
248
93
134
301

1391
196
147
79
119
261

1885
246
298
119
149
414

1638
221
223
99
134
337

1529
204
238
95
134
311

537

747

642

417

703

560

322

649

485

563

130

151

140

130

144

137

92

133

112

130

5

9

7

5

11

8

7

11

9

8

5

4

5

3

4

4

4

7

5

5

2

3

2

2

3

2

2

3

2

2

1

1.4

1.2

0.9

1.4

1.2

0.9

1.4

1.1

1.2

5

7

6

5

6

5

4

6

5

5

81541

124464

102998

85066

129272

107166

89822

138289

114054

106578

Other
Entities
Essar Steel
RailwaysNR-ISTSUP $
PG-HVDCNR#
PG-HVDCWR#
PG-HVDCER#
PG-HVDCNER#
BARC
Total

GNA for HVDC_SR shall be 6.15 MW (in addition to the Other Entities included in the above table)
Explanations:
* Drawal by DVC is considered excluding injection from Mejia Thermal Power Station #7 & 8, Durgapur Steel
Thermal Power Station #1&2, Koderma Thermal Power Station #1 & 2, Bokaro Thermal Power Station-A #1,
Raghunathpur Thermal Power Station #1 & 2, which are connected to CTU system.
** GNA for Haryana shall be 5418 MW after excluding 1495 MW. The Transmission Charges for 1495 MW shall be
paid by M/s Adani Power (Mundra) Ltd. as per the Sharing Regulations.
For the purpose of calculation of transmission deviation of Haryana under the Sharing Regulations, schedule by
Haryana from M/s Adani Power (Mundra) Ltd. within 1495 MW shall be excluded.
# ISTS drawal at HVDC substations have been combined at regional level and accordingly, GNA has been proposed
at regional level.
$ ISTS drawal by Railways (treated as a regional entity) at ISTS interface at Auraiya and Dadri, have been considered
for GNA.
Note: GNA for export to Bangladesh shall be equal to 782 MW, same as the Long Term Access granted.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
signed by ALOK KUMAR
and Published by the Controller of Publications, Delhi-110054.
ALOK KUMAR Digitally
Date: 2022.07.20 22:06:07 +05'30'

<!-- page 59 -->

Central Electricity Regulatory Commission
New Delhi
No. L-1/261/2021/CERC

Dated: 18.6.2022
CORRIGENDUM

In the Central Electricity Regulatory Commission (Connectivity and
General Network Access to the inter-State Transmission System) Regulations,
2022, (‘Principal Regulations’), the following sentence shall be added in
Annexure-I after the Table:
“GNA for HVDC_SR shall be 6.15 MW ( in addition to the Other Entities
included in the above table) ”

Sd/(Harpreet Singh Pruthi)
Secretary
Note: The above corrigendum shall be incorporated in the Principal Regulations
to be notified in the Gazette.

Central Electricity Regulatory Commission (Connectivity and General Network Access to the inter-State transmission
System) Regulations, 2022
Page |1

<!-- page 60 -->

CENTRAL ELECTRICITY REGULATORY COMMISSION
NEW DELHI
No.-L-1/261/2021/CERC
CORAM:
Shri I. S. Jha, Member
Shri Arun Goyal, Member
Shri P. K. Singh, Member
Date of Order: 31st August, 2023
In the matter of:
Corrigendum to the order dated 14th October,2022 in Order No.-L-1 /261/2021CERC
In the matter of:
Approval of ‘Detailed Procedure for Connectivity and GNA’ under Regulation
39.1 of the Central Electricity Regulatory Commission (Connectivity and General
Network Access to the inter-State Transmission System) Regulations, 2022.

CORRIGENDUM
1. In order to rectify an inadvertent error noticed in the order dated 14.10.2022 in Order
No.-L-1 /261/2021/CERC, following correction is made in the said order:

(a)

At pages 5 and 6 - Clause (iii) of Para 8 shall stand deleted.

2.All other terms of the order dated 14 th October, 2022 in Order No.-L-1 /261/2021CERC shall remain unchanged.

Sd/
(P. K. Singh)
Member

Sd/
(Arun Goyal)
Member

Sd/
(I. S. Jha)
Member

1|Page
