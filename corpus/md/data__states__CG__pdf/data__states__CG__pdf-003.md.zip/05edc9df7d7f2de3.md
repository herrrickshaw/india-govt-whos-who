---
doc_id: "05edc9df7d7f2de3"
source_url: "https://law.cgstate.gov.in/custom-files/notice_files/ODR20260713_57_6a54b46edfcb8.pdf"
ministry: "Law and Legislative Affairs Department, Chhattisgarh"
title: "Orders"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "70dcc0dd4a12de57"
---

<!-- page 1 -->

rrft9r6 Tns{
frts 3fu Aqrs znRi fr"qrr, riTrerq
cEIi-S qq=r, rcII <tqgr 3rao q,n,
ft-or vugr (s.,T.) 492002
c,ir l. Ozzt.zZZt346. enrail lawdept.cg@gov rn

trctrlltt

rfl {sgr, gqio ozl07 /2026

5q1o 1.aw - 42 / 8 1 5 / 2026/ 2 1 -q /8.r. / 2OZ O erfrRm {nq-ffq 3{furT'q6/

3rfrftm oto qFpYq-o, sfr fr-dr q-fr b Er< tr{ frr{r.r b 3rdiT mqtq azol/
33s7/21-sN.q./2O24 ft-{i6 03.12.2024 b qRq rft s-qq TqR qd 6}
6-{i & Bq ot q{ fr qkfrefl srqts w ftgo foqr qsl
nrsc fr 3i{
en, sqh 6Rr tsr6 qR-ften erqB Wf os ofr .r{ *, G-sb s{rid
sRr

tM

ils{

e-{fr 6rd crqfB e-dri 6.r ffq Bqr .rqr t I

si-f,: rrc{r {RrT gil<Er{ fr s-qq gnn od o} trw

fr 3ir fr ffi o.-ti b ftq

ft{i-d 0e.12.zozs t d-{ s{ A 6i-drsE qr ez q,i 6l eq q\ m qrd E\, dt
E\ 3{frkrn {rq-fiq qftrnsm/ 0ftR6 ao e$Eilq-6, se G-cl q-fr
F-gmoror Bt

sd rn-sc stqr fterfR-d 1,.j qqq-qr{r.ri ririlffd ft}fl fiq gs 3r--q fi-s tq
dfrt u=rfr tqT fr erq rrd u.q. ffi frrrr,T q=g_d i frrTfftd cavn *ftr
frg6 fr-is am srFrqlo"o d gao enR or 5.ron.ffi 3ft frqTm fl?i
ftqiq, ,ixoq e 3rhl mqiraTqzttsl/21-s,te..q./zozzfrqifi 25 ',
zozzd erEw ia e}'frt
E-tftsricb rtGqqab ilq toen
srtrrrSqn,
)r(r,l lly \'(r''.al hy
llI tl/I,LN()rr,,\ KUI-a/\l{ vn 5NlKAlr
r ).rrr. (r ,r .r / )r);,4, 1 l 1 r .)r,
I

1r1t< grn qrs{-ocl
3rfdR6 q-frs
fll0 3tR flqr$ efld frqm, r*-oq

*qvq L6iu a2 / 81 / 2026/ 21 -q /\i.q. / 2026
-

qfrftfr

5

.rqr rrug{, fuqw ot /ot /zoza

r.r&qeq gq G-or srsTfffi, qiq,ft< sicr oi tr<ir inrfi -oqi+ gzol tnta

<!-- page 2 -->

fufro/2026 fa-{rm r 3.03.2026 * S<.i {,
2.qqm Gor vq e.-{ =qmeftil, fiIdrqiq.flr qiw (&.q.).
b frns Hdq6 61 3iR q'Ir-frq frfD Tfr "fr
3 . qra{-q frftr
srroto-+rsf,
4.Ritr 3iftqi. ryu vfra, frfA oflr ryu qPds, frfB rdEq &

,if fr

il

fr

er+oto{ei,
s. rfr s-<s gw< ad, 3Tftft.i6 nmfiq qfuqn-r7 srfrfuo oYo sfto}q-o,

wfrB-ilvfr @.,r.)
6.sc {iqrdm, rrsfi-q etfiu gerunau, {<Tilfi 'ra< b qrn', rzrT $qg{srugq
(3rqTerRUD ri qenTimi?j,
(e
ysFffiFF, ftfB 3ft frtIlS 6r?i ftqi.r fr 3iR frrrTrflq Ls6c
q.ri il miq .\,
3rqcng

lfr

{

fu

fr 3i1qqfl?i vq en+ro mT,isr$ fu edf\o

t

I r'o'rnrr), .r.r^^d

bv

rr.!rr. r)/-{},r,J(r20 1! 4rl a }

CfrfrHH{r)
orqr sfrq
iafB 3fr-r ftffi-fr zFTqftry, rinou
