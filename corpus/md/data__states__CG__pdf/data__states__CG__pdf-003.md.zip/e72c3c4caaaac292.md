---
doc_id: "e72c3c4caaaac292"
source_url: "https://descg.gov.in/pdf/actrules/vital/RBDAct1969.PDF"
ministry: "Directorate of Economics & Statistics, Raipur, Chhattisgarh"
title: "जन्म एवं मृत्यु पंजीकरण अधिनियम 1969"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eb257e365edeac78"
---

<!-- page 1 -->

qq efrr{Fg rfu{f*u
qftFr.rq, 1969
( t sos sT erRrft{q +ic+im r s)

[:r d, roos]
wq 3i1{ gq e Nf*-{ur

t hf{qcr air a-eiqq ffi'mr

sq-d*r il+

* fuq

3{ftftqq
Tird quRrer * d1g} dd i'+T€S frr

ffia

sq fr qe e+F"rfffi-a dt ,-

qsqrq I

qRFrs
. r. ilqrq4s, fu+rneilrsnrrT -- (r)qr3TFrfrqqq-qefrrrcftn4-q;t"t3iRTfrqc, 1e6e 6-6Iqr q'*"q;.

(:)
(3

)

gs+r fuwn vnEf r+nd q{ 1.
a5

ffi a-q il ss arfte i +1r{ca Elrn Frt *-*q sr*n, $nq6q rrsqt fr 3TRrqqcT rnr ft+a *t

,

wg ffi nq * RFrq'Tr'il * frl aFrq il{d'Fqd ft qr €ffi.
z. cfu{rsrq St frdq-{ -- (1)qs3{RTftqqil, wsd-iti*.ds$t3ra?n3TqRTdq 6I,--

(*.) "-1=q'" t *ka-qq {T rffi-qq uffi 1 '
(u) "gq" t frFa-wq fr sr+ * qrqr( ffi * sc-q frql * $e ideruil sr Fprrfr dfi qt ft-dc{ 3{FT}d t

;

('T,) "r4rr-Tq" t qqhm * rtqq sT, 'Itf qrt ffi wm an d. qq-fi qrdt fr Wt frsqtnffi qi frq{q t fd
*dq tss osTuil 613Tr1Hd "n:nsfiTidt;

(q) "*fud-qq" fr qqiqr+ * tfr s-.qrE.6T, .nf qrt ffi wtr sr ET, 3Tq-fi HdT t [rt frqr€-{ qr fr,q$sr
3fiThdt, .ilttfrqrsqqrMvr*qrqKrsrq+drilw*fi516)$eraoavrERla+cmt3irt+q;qil-oTr+s'

rarc*Fa-qraqFfiqmrt

r

(s) "fi[ia" t ss +rRrFqH * qtft+ er+rq qq furfr nn ffid 3TFrfd t
(q) ffi {iqtrq*{t {ftitrii "{-q s(frT{"

:

c$.n€ffi'3{frhd.t ;

(e) "q6-;1a1" t t* W-q-€ wffi 1wi qrrtqrc *.1 s.srq slr t mc Bkd qqfqRi qq +.t g*r t.
(z) ry erfufiuv il ffi M frfu t cft. ;it ffi *x il rgr$ t, FtvT +r ss drr * +ieq i T6 3rd ellnqr qrEn l+
+a rq +d il 4.a d-.Fqr+ frRr b t'fr , qR +g d, Ffu t.

r"gm-+teiaigrstfuq

<!-- page 2 -->

2

qqefirry{ftrql-o{w31ft1ftqq, 1e6e

[trnqt-r]

3Tsqtq 2

tHfenq-{elIT{

3.

qr(T .Fr cet{frqn- (r ) *;+q qr+-n, wrrftq n qq* il 3rRtrla.iT ilu,

ffi qR *} qrra * ild{k€T{ t

sq fr figfi.qir s*rft.

(z) **q sr+R. qt r;q 3TFr"Ttr fi. tfr qrqrrm t, *i +t ** q{i, {6nfu€n * cs. 3firfrqq * ;'-:r+ \* ya:r

h. fui-6r frd-dc sr} * ftq *e r't sc-q-s'rq q{ nfir.sd *t, ctnfrqn *:rtftslor *{ fravrq t 3+fr{ frfdq 'r'; * q*srq *
;"q. ng4d s{ strfr.

(l)

q51{frqT{ r+ ilqq}fr fr, fr'-+qrW gTRrF-{q*r fumn t, w-c a+r fq h rftrdo'"r q qt i.. np:-,-q frEiTqfi

6{€+rjTrfuw.c*<5.gt@*w*fuwfrgcu@'* bqr-*-orq*€qE-q3ilrKfi-"{nThfuq*-<caalqrn$1r+a
{rqffi- il g€'oTP.Tftqq *'mrqtaq-+ fuqq-m ilffifi fi*J }-*-q+rc*n al qK-d 6tqT"

4.

gca r&qn- (r ) uq-sc*R, $Tsffq trsq* il 3TfrrqqcT rrn, ffi o-q t ftq 116 wq 11;'31figcd s{

Her'rt.

(2) {q s{fiR, tt er;q o{Rrsrfr $, tft q€rfr't, fifr +t dto vr}, g€q &qT{ * W 1-,rd w. i'r-";r frd-5a ry-;

* fuq {6 rA vw-qq-q q{ grRrqnd *t, g€q {frqR * 3r$flol sfu fttflq t 3TEft{ fi-dtc Fd t q+qq t fo.L, fq:Td qd s*rfi.

(3) {rwrsr6nERrfrq'rqfrM'*,qR+t$dt,3{tad-{rtegqgcuftqnffirrqfrqH3rtlfiw*3rd-{i;*l
ilqfl-+ e-+rq 'rq ffi' 3t{ t*q,Tq 3nfpil t ftEqrqq h fu< g6q q'rdcrc.-a; qrRIqrS *q-r.
(+) g€q {fuqq nw il GS+.wr h ar{ * qrrac, gftowr sfrt q*}qur t frq sgfra 3i-ihT ft-*.r-d fi{ qr 3rerrn
@orq ff c-dft gfrRa od bfuq*-scsdrqrrr dprsrT{qfr wsrFrftqq * Flfae-{ * qrt il q* fi*J. tS ftft t *{
tt arffidt' q{, ffi'frkd kqr qK, rrKT 1e ff sqqrr (z) il ftffic siffi ffiJ * e-{R st'n 3fr{ {rRI {t-*'R +} rqa
qqT

qTPr

*tq-r.

5.

rkqfotur ds-{rq{{{-s'f(, wrc#cnwv-*fr 3TRr{fiTdtrl, rrq*lftcr *cq*-**}tt{F"I€fmiEqu-sl'n'
H a-6 *-f, qq-&, Frrm e{ Hailft enr frFr* @+tq qt$'.* fuq frFr* frirq frtrd *r s*rft.

6. kor rfurqn- (r ) ii-qsr*r<. qA${qqffihfuqs-dflqoTrfrEr{ stt td-{ -rTfiTft-oFrrdr rf ,'4 fuff a'
q}.'n ffi q.6'&s qq-+ 3n{ q} k_dT {ftqffi * Hlm"r futq S{ fral]r * 3rtstftq rsi gq, lwor rfuen * qri : ''r1 61firia,r
#n fs{*T ft+f,{ 6d + fuq tddT {,triEr

";'sqq-sqq

qr'llf"Tn *i

grearRren+kiqq*:'rr-+il=-ei g<,iverrtegni'*oq-r-q4 3f., f.'q'*,rf.:rz-t'rlsl*j ,
:ir ryeq {kBli;:c rq'"iir'iiqq + g,ffi * ft{ sE -{-€-tR'qr k*la w ,n,:*'+i il'
9q
"faRqs;3q-dr.i

ir)

ry+l=i.rr.} i; -

a fuqrarqrx ill

r&<n- (r ) uq viqrr qrRq,in-,,tr, ivrcra q'r $.q {erffiq cifite;Tfr *} 3f"Filk.fl * ,nil +ti , {$iiif', ;;i:
-rr:r *x * foq ar;-cc't; a-rrQp6 } uq=aq * ftc FF lfrEr f}{Eri 'r
ar& rA€ {prT{q f{ h fuq qT ffi
'r'r'ft
i.

'

q{d {:q {fs'R

ffi +ncrfu-6r, tqt'rd fl crq r,rr*q vr'ffi * * q 3u* fldt 3Tfir6ift qr ':;z +'fui *-;

rRqRhsqilftgmqd€-}a'ft.

(z) [SdFrftqr{€rd-cqtfuqfe'rqrfurafrtnasqTqnrg*3Tifl-{st*,r{ERrdr,ftsqrqrc*k{rdahtTT
aenqcfi3{ftrsTkdr*Sil{E}},E;Sc*6sqslfrn&*AghFnr+ffs{iqrr*rtrrr6t}}ftTq$€rcrrr$*arqrarEn
mnrfir$ou *fuqqEfu Rftfrfr'hilnrftrq4{ sfn$r$ow hfdtq$ 5g 361qrl.

<!-- page 3 -->

3

qq dr {q rfrdffiq ffiftqq, t e6e

[qraq a-s]

(l )

s-.*6 {RET{ +r *rqloq sq €qr+q ** il *'Tr

ffi ftq *o pgm mur 'rlr d'

(+) rc+6F {BRr{ s-q 3+( q-.g h @*.{'T t qdqq * fuq.{q} firqtoq il tt ftd 3ir tfr vcq} q{, Ri-6r g@
q{
{Rq-R nhr {, Efiq{ GrT 3Tt rFqTi } ilqtoq h qreft (R c{ sqt cru * ffi s-dq{as FPIr{ c{ \-fi e}-d o:T-aIEr R's
qT

rsm1{Hdpn 6.epn*q*r*&qs6Fgffids$firsq3fugqarGqnapns{fttrtrd$*Rq*{rD€rfrqqlntrilftd

*t.

(s) g6qftqRh$egntqqgrR€Rgrqfi3TRrsTRdrhfrfrfrsHtri.iuilw-rRqnfiginm{qh'Tr3fr{:-'t
qq-fi +t$ qr srfr wftqr eft o-dq q1q'qh'IT.
3TErrq 3

qrq Sr {"9 *-r @fflq

8.

w+ 3rilrlg or @r+rur6{r} * fuq3rilfrd qRF- (r ) fiiRffiEqRnd'anrw*dqfr'nb}qKr

16discqrr(r)h3rrfi-{G*.",.srnfrfroxsmqqEufuqqf+fuq3r}fkdEtrdfrRrMff{Frdr3Tqtuqtdc{He*{
qr
Erdm h s1ffi, \fr scq * lftdr, * Rkd hqr ilq, fifuq fufut sc il {R1qR *1t w froqrq,-

(6) cw (o) t (s) c+ H ftRe{p{r+tF€ffi q( il, qrt *a ffi

* qi +rFrqrffq, gqq;w *r q-q ff

qlard, 3s qr sT t€-T gfu*, qr qR sq qi il q6 * sTRm {6RIqi F-fl-s sIfi fr fr 3q r-drsfr *r \er gfucn, fr sq

q{ qr

qfu
g6{ * 3nr qR fsm W *rorsRT *'*rH, ffi'q:q qr T.g ff f[frf ft si* d, ffi e{q W
* q 3qftra a * fr gfuw q;1 a6 ft6-mn {icfuft S * q 3qftm d sfR R ffi qfrF ff er{cfuft fr sm *rrorqRi *

'.r*pfi rro

q-ra

U*.*q.3qRrd s-qfr qsreqw'g{q ;

(o) tqd er€qflo, qTe.zr kq, g(fr qT qftsqi Td qr *S 6 ffi {i€?{r il s+I qT aq ff qf{f,, EI6I ;FI
qrsr.rs fui*?tffi 3TRrfirft qrssb 6Kr {qfrfr{ c'tErfd 6}i eftn ;

(q) to il s-'c ar qq ff erm, *o*rrlrerrr6 i6t

;

(q) 66q1-4g1, it"{, *g.o, qfvrrcn, *q;Tr6{, qtsr, qirlfl-tdt*c+, ar*qrqTqro}s.eTF{qq*pmilqqqI

gq fi qrqe , +6i *.r r+nqr?rfi qft ;

(s) #+ em il sT6riq-m vrq'rq ffi r+em fir{ qr trq ft qrdd, rrs ft s{n d {rcsft qr qFT sI :jrrl d.ierrfr
srtrorft.ia er;q-* err$q gfuq rfi+ q.t rrKqnrfi enR-st '
c.u *t$ qfu fr tt frru qr {rq +l qrar t qr ffi
w qfr-o erFrorfirfr'+1 qfud 6t'n.

r+rrqnTr n'kT Rrq qT $cr (el srlq, {6 se nq *1sq nquft

(s) ffi erqeernil, tsrqfu +frRdfuutwtq'
(z) scrtT11(r)ilffierahdtgrfi,rrqqc*Kffi@s{uTov-silkfl{Hs{rrci6reqniliq}g<,+ntvr

s*, **tfi*s{q*.ftinw*rdTqFThftq, s}3Trt{TfrfrfrffigffqK, sqqKr (r)*uus (*)ilfrffisq{ilwa*tgq
* {iEftT d sfroT Ts G-s il anftu qftfis} t e-qrq {6 qRF t'n fr ttq' qrml-{ dKI qflq fr {s frfr-d frfrffis bqr 4'{r d'

s.

q1.11qt wqe1t{q

* ri"iq} ffiqgq-d*r-ffiqrn-{ilqq'3rt{5.gffE{nils€qTrTr;Iq;T3ltfrs{s

qru e il frEE gftdl {RETi *} tm qr Ro-dK'Tr :

ciaETKIsffsqtTr-{T(r)*sre(*)*(s)il.nfrfficqfusseFTt{*e$ym;Stonq{rrm66-Buttt.

<!-- page 4 -->

ltrniq ro-il]

w+ 3ia 1q <ftdfam"r 31ft1ftqc, t 96e
wdfs-iur-{q q-{T t "il'TT-{" qq t qn i-+a fr:rqr frRrt fi W Tfu 3iF{i-d i s} urs, +Tfi, srd ftrd, rqe.

1on-*, ffi?Tw(S:1qriqrd'*J, fra-qu-rmn, $Rrftqn-fleil:+fuqscTrrrr, ffift9*1.3.mt*frqiqnfiwr$
t qT fu€c d sq-d +rga, era'* arn "qlrn q;1 ffistdF" qE t EE qfu ]TFrrd * ir ertrn m zrfiffiT, qt qrh-q s *Bi q.'rrR qt
e".frsq tucr E), ili q rqam, sTtft{* qr ffi 3dq ilq t f*ta waT E}.

10. q;c ailr {{ ft qqrr t} s*r gq * ann"r +} sqrFrd and ar g;o aRnu} qr *dq- ( I ) (i) qq.fl T{
* srrq sqRrd arg q1 Hf eFq fuffiq qr sr€q qkqrr+ 6I,
(ii) $q]*qfitfuqrororRq,TqffiFprn*qdtrfiqTerdtqr\AFrr+w3vRidrti*frqFr-rr+qqrRrrrft
ffi qfu.Fr,

il{r 3T}Rrd

3TQTqI

(iii) ffi er;q qfu 6r, ffi {rq qr*R rqt cre+m * g frfut Efrffis st,
+o *-*q d,n ro eF qdqr

qlq,

-

tt s-'c qr Tq qr +i' ff, m' rq} cftEqf fr A qr {6 rqRrd

-r\
qr\'
( tq R
(llcl +
chl qdi
(lsl<.|( -)
tll( tm
lqlbo bff
leer eK.
lq$ frftd
Hqq Hl(l( 3fr{
\ql fifr
lc'l qrqt$d{
S$ 6, tl\llil

en , qT

* \A +{ il, i€T Efnd isqT

ch

-*.-

(z) ffi fr"* t qq frfr-a rrw gfu.rrcfr +1 cqT{ il rc} gq, {rq e.'cs.R +s e{+srr qd qailft fu ltg * *r-toT sT e-qluFl-{.

tfr 6qfu + 3fr{ tfr nsq }. + frkd t*-qr wq, tfrqT{ nn eTFffifr fuqr qrqn

(:)

qoia-"qvc*rlsqtnrr (z) *e+tf+u-reitwrffdt*gq**-rw*rrqrqq-{3TF+nEfoqrqrq+ossqfuff
gqff<rnil, fr3iq-fioiftqfiffi*Ariaffifuh."iqT-d-{sr{ffqfteqf il u-i, Eqqfu fi Tq * qrqqilisro q-6ffi'ai€T-

d-sqdst$ffqfuqfr+rtftqfu*}, frw3TRTftqq*3rtfl.{fu-${qt*d-qfd-itri}hfuq3itRn*, 1qt+n'r*ilt
il, 3{c} udtrn ilq *{ Ardrs * er-gw *rrq ort gq, rllTsic{ tTr, 3frr tqT qfu {d q'qruq-{ crn' +trTT efu gs 3{Efiqq ff
ertaqun{.g t +d-q sf{dT t+ unv rfrqr *} cR-{d 6t'r.
1

1. fd-dr ti erA sr {Fdsr q{ 6€rTqR 6-5ar- r&fi qfu, m tRqli +1 qq 3TRTfrqq * 3r$a 3Ttfti-d *t$

sft-dr frfu-6 Fq i'fi E), $u frfr-6
fr e{cl clc, d"h Jfu kqrs-FerH

6 nl rRR{ il eTT{r qrq, aut{ sfr{ R-{re€?Irr fud,-n aw qR dF fulo {S iffi-dT t d} tflr€{

t qrc+

d-q-r\rtr 3ii

W <tlT fr e frRlfrqi (RTqT{ sI{]'ld qrq'ft.

rz. vff,dr t} qr$ 61 @f6{'r ff cFEd t d-d{'il'{r fr{n sTr+T-q+r qI trq sT {Rq-s{"T I'i E}e S,

{fuqT( tFd€{ fr fr sq q-q qr Tq * sqq Rtrd frRrfud q;T 3dq} 6"Rlert v.kd :-diur:s'qfu +} gw bT C.s}
qRT

qnr 8 qI

; t 3r${ sftdT *.

13. qq dr {q +l ffid @f*.{q- ( r ) fus q-q qr Ts ff sFd-oT ilq{ BftqE sTomftr * 3ffi€T4 :5

qrqq, i6-drqhdi*ftqRr**d{, {frqK*1*sqd-6tfrfudq-fts, frfukdffwrq, RqsT}qr@fafisT\'ft

(zl f,q-s q-rc {r Tq ff ffid qFddr rs+ 6r} h dts Rc b q.rqr{ fu-< c6 e"i + fr-d{. {fqgr *} fr eq m frka
ge frfut srftryd Hf :rq 3TRr*.rfr * ucq
qrRr+Tft fi frfu-d 3t-3ll t *{ fukd fi-q Rq qr} d.n ffi qfu-s qr {rq qwr{
aRT

$qfu-6 flqpr-qr

t

qyr fuq qri w S

@.*-o fi wq'ft

S w+ a g.g, di h q* sS t $-fi {Msd q-S: ff d Ei, dF 3€ qq rn T.g ff gcar Ft {.{Ffi ad t q5-IIq
e:rq d?i qRd qr iR#* qffid eRT fuq qq 3Trt{r c{ S{ frRd ffq Rq qA qt fr rffi+-o ft iT\.ft .
(I

)

(+) {s rn{T } 3q-{*r W ffi +rff s{ dri cfr{a qqm 4 srA't * ffi s-{ qT Tq 6r ffifi"T 3€* ftq,
frfiftsqqq *rfrcr*.6fr ffiqR6t a+es-d{6} q< rs*f,qlq ffil €q-frE}3il{tftffiq;c qIT.q *1Wffi*'tr
t. oG-d {6i s +{T{ {ffii6d f+qr qr s;Frr.

<!-- page 5 -->

5

[tinrq

i+-zo]

vq3fi1m$dfowe1fuftqq, 1e6e
14. srd{ t ;rrr{sr @f*lq- wtiffiora*6rqqarc}fufl@sdisqrrqrE} {6i \frqr6-s.ffcrdIqr

fro qi e-ier+d.--,mtilct{ftiuil gfuor, qrddfuo'qrfrfuasqil, IRER"}frRd6r-dTERT**d\hnefuaerRqRtfr
;rq # rfq€{fr d;i d.n 3fu cBfr a} 3iTilqTkd*t'rrsfu 3€ qril{-qer+'il

" e-q $r gcg * rker t yfrfr si #6 w cq *-r+r- *R rR.sR s} sqr?dn r<id *-d +rd sc il T6 srkd 6{
ri}'rs G€{ i q=f qr q-q' ff
strfr [Fckr: {r Hrfir: rr-6?i t eryar *q-eXf* qr
tr+ srq k qo:rF.rFeq t 3rd-{ Js*
is

dT{T

3rrfqdfi{r{fiqgt*d€ttffi't3{sqdr{{-6egq,.*rrww*.narr, "tt
Wyrdfrsrc-dRqc{3fr{Mqfrfuft*'ffqrqf,
ffi W cfdfu?n qi, S-+. qr rq isqr qT €+.n. e-{K qr(, qd qBB t *t€ cM{ t*.q fu+r crrs il qpr}fud qBE sr*. r€ effi ff
'rofisrdrq*rs"*'nqrysrBfu+)re*{s*'nnrnqrrd-sfrEq-{3rGF€dreru*tTr3nTTs}*+qrreFdfff,Tte.*-skir.

slqrq 4

3TFrM'ert qiGqffi'*} rsn

16. hfto ssc fr {Fd{zfr'anr tRqnl rnr IttT s{r.fi- (r ) nc}* &qn @s{uT *" qT 3qt ffi,{rq * fuq,

ffi {i6irT } a5 o+Miar - efrn q-rm *, fuRd q-sq } qq efu 5q *-r iker tdqr.

:

(z) g@ &{qT{ tt esc} 3ir q-iN * orgvn, $ qrq-€Tq q{ kRd tnq v.rq. sq 3*{ Tq ff cFdfuqi *-d * fus
qqk{iresT il {FqRi oqqrq{r3*{9rqrq6nq'n ; aqr tSrsfr ftrrri-frqqmfr qdncft g-&fi{RqT{ * flqidq* drg(R c{qT

s€+ fi62

ffi ffi-s-$qrprn q{ drTd qrqrft.

fi. v-r+sfuqq b {Fd€{frilor-{ft- (r ) nww*nilrqsftfrf,qqrq{qffiffi}eTeqrtr{rt*g<, ffi
_5t+,-HFttC
__ * s_qrq * +d_q fiqq * t, *t$ qfu_
-"
ticr'tcr
_-_r_ !tl*l gi11
_s._

(*) wq efrr {q * {FdFa 6 ffi qFdE +1tRqn ani.r6HI s-(qT s*rn ; dpn
(q) tt {Fdet fr * ffi wq.qr Tqt €qq *ti 3q{q 3{F{flTu;1 q}irn
o{g

:

ffi qfo +} Rur.rw 5q +titfr +t$ sq{q, Tq[ 6r {Fds{ il cBs 6REt etr-c q-tr 6tn.

(z) {€'rTRr * e{$-{ Rq qq erfi 3-q{or qrcd-q vrsq 3TRrfr-qq , ntz (1s72 qt r ) ff trnr zo * scro;*'* eqvn,
rRqR Era ffi erq til sTRrfirt nn, ffi \fr rq"r ti * fuq nq ec*n l yrFry-a fuqr fr , rqrFrd tsq qlq+ oir rt w+I
shB {iqq fr , qrRd drd * s+s-i t fuq sres il rrs *}.
T{ *} ffi
qT

qT

e-6

orqfod' ol fttaw- ffiffiorur *rqH'*r ftfrqq efr{ B-$'rd 'rq {M ff qftsn \fr ftft, t
3ir \fr rnr*fi il{r ffi fr-dT {Rqr{ trfifrs +rt, ffiqr qq'n.
18

. @fl'r

1e. orfufi ffi

61fusrn ern ge+t&qn+1 i+c+h fuqtlw qFrT- ( r ) nd+rfueir greq{fuqTt
+)qr$TtnnEfiffiE663aq+rRr*rfr*t+oo*c{3+{tte-sci, *frRdfsqqK, wftqnaroi'dqqG€{ff
e-{ 3fr{ g.g fi ctrM * srt U s-d ffi +}qT
il fi d qft-dr *l do-oq oriq,n 3fr{ q{ * st{c {f;ilqtfd wq :,frt gg fi
s.iffiq ftcU t+ 3{f,{to} cr 3tR t} e-6c }, s} frRd hq sR, vderqRvr S} qrr.Frfr * fuq e-6rfud *i'n.
(2

)

gL"q

ifrqn, M

rrcr

ffi

3Tqrq 5

etH
20. rrno0qrer+rrrfir*}'tw+efugqttF(f*iw*ortiHq3q6r;q-(r)scm*3rq'?fi-{{Eegq,
--)',
^ s{+rJ. ar{i qv r+fut d:il-q qlq, c6nRqri *TRT * iTrlftd'h ,fid t eft{ q:q +}'t q-q idqq-6 w
r1r ch-itq
-----_-_c+nqrTiTTS il.lk*rdTarP.Tfr{c, 19ss (1955 qt. sr) *erfl-{qqqqq$r qr+q +lvomrqffi'}-tfriTrTfis}
€En.Jr,?rc? h er.i-c alt 3

31y$* tqT {Mflq rS gq oTRrR"qq * qtfl-q qRF' sq I fuqr r.rzn {c-gT q-lgrn.

*{ftd-si"T

<!-- page 6 -->

6

e-t{ Sr {q $dfflur e{ftTfrqq, t 969

fqniq z r -zs]

(z\ rncotil-d{qS\froro+ft<rirt,ffiqr+asqqrcr(t)SwrsrciftraqfrsTtrrxagtfr,fisro-miFHrdrfom'TREildq)fieEfrqnaErq-swqdlsrd-m*Ermq-Ssfftdltg.t€'raF{brn-*h*.frqtrqqfd€sTs-'c{s

sTRrftsc*3{dq3$tftftlffi5mirs*frqriqt€-mfiq-qrtrdtgwur*rtrnrr:bsq"fu(fr+ra*hr++irfdts
sra frc fi sToraP.l *:r+s'n * qrqrsdqelt.
sg t,

zj. !i-+TqTqq*dsiufr{frf,rarFrsrrm.GftrRqnft{rfo'-{ftEr{ffiqfut,qr.i}*ft{dFqrfufu-d
jt

116 gr}eTl 4;{ g..............h,1T

b fr.q qft&x fr +a qfu fr-qrq 4;{?ir t sv* g u-+ w g-cu ridtft +t$ $.fidT

qRrWertql-r*I

Jfr t. *e sii t :lr< m

66qwr*<dm.

22" frtsrtiffwfu-*aqsr*'nffirqel-fiR+\Rfra{rts*rfrfrqs3TRifiqq*+rrgi-<o-+rq'iqffi
f#t 3{rfu * 3q*i fr t ffi +r sq {ra i ftEqrqr fl} $ ftq 3ilq{q_fi e-ed E}.

fr-qc- ar hc IIq

:3. {nftqi- ( 1) slt qfu s}.\.\

gJ:'--._---+-)'J+;itrert

.

^
^.
-L\
{6} qT{T8efr{s*ffi'rq.it}*3{rff-{WgF{-dr,ma*3etnf,d-qt,t+}-{ft'T66Kq*fu+:ffiq-d

rtrn; e{:r+r

ig)s-q*(Fgtri'mrfr€{ilft€sT}*g*-sct+t{wtrd-dTt''rmkoarq'rrffi+ror+ertqr
frr*qs{trrtr*+oscffid}'frffi;rlqfuaTtHqn-n3nrfu{*l@"fi-dt*qTefil3{+RJ-dt;3TSraI

({) rm I I il-{T 3T+fka sq t rfuer il orq-cr am. qui-q sfrt ft''qrs-rBna fuq+ {t 3lqlT 3iTs- fu< o'nf t
gwt+ g, $1 v-+m w{ * * ,1q*r[, (u-sfrq dfi'
6mn +tm,
E-6

(z

)

+tt rRqn qr w iRqn * wrfi eTftffirftar il EH

qr&

ffi sq {r 5q * @fivr il 4l Er$ i s ff 3qtrl{T ( t )

iliT3{+ftrdffiTqiqq}ilstqilqTss-frna-RgfrTiFsT{q*ftiTahtrrTq6{fii*q-fl{rwqa-**ris*T'<0-sfq*'tT

(l)+t$fur4-iqr.qd€l*,*trrotoffss?IKr(l)}efiEgc1urq''a}ilsEeilql3qtF6Ratrrr3nT*$qfu*
q-qiq €qq irdF *r d shm, s!-e'sq 6rIT.
tw 9q1!T q* cffG-d 6"{-} i stff qr s€.fr r+n oFtrn *e gch fr, fr

(+) *yg aft, * gq 3Tfuftqq * ffi Wsqdq a;r, gfrgr arw * k{r, 3?isq 6trn, ffi 3!is-{h fuq is

qrcr il

ffi gIrR sT 3q.fu rS t, +t gct} fr . fr c{ {qs ilfi fi fr q*rn' €snq frqT'

(s) ql-c cts?n {ifr-dr. soa (i 898 sI ) il ffi srd * ** gq lfi, {s tIRT * utftq g{q1tq 6I kqq"r c@a epr
r

s

rifrqa:i+qrqKrn.

24. 3{qftfr'hqns{ff$ftF-(1)WYrdtq1qtfl-{(6eg<'*frkaftst(gt*{frEr{rra'qFrRolqrms
qt qrqr(.,
qr}

ffi'

affi

*
eTfr-s-*'
en?v aru, Es ftft-{ $ftsa 4t$ erRffirft 5q 3firftqq b 3ftft{
q;d
cR
gfu-gm
orq{rq
or
qfr fr,
gs 3itrfiqq * 31$-{ +t$ 3Tq{'?l fusT d +i fus

ffi

ffi
* rd
itd d, :q 3{q{EI * qYFrq h d-t s{
{iRl_d tsc

qqro {qq t 3r+Rr* tr-{fiT trftrfda 4t{ €+TT.

e)

q6 tnnpr t t) q{ {6 qfu 3-q\frn ar Rqi qrqr 3ir \S:rvrru fi erqd rq+ Elc q}$ 3rdt 6ff1c-S ff

qtqttft"

2s. 3rfirfrqq * fuq iqt-gs 3ifiTftqq t 3{d-{ <u-s{q ffi 3iq{rq * fuq +t$ 3fii+q-{' 5w &qt no.

qTrr{q qr Hs +ltw dnr, qq ftfrT srRrfd srFrfift dRT fr {iRrd f"qT qrq'n, wqPn rfr"

<!-- page 7 -->

s[qsirqq@f+-{worfufrqq, lsog
26. r6qrfr 31r w rfrqrt or do t+o sqgl qr+- vf rfuen *r sq {Rrq{. s"q } Es 3TRTfrqq il n-+ftc
qr Fd +-ft driqtrd d, r{rf&q Eo-s {iFdl
dcrq {q ffi fiqq qr fuq -rq ffi 3tThT * sq-tiln'* qei"r il *ni or G d
( r soo *r +s) ff trnr z r * erpl il dt* *d-{ €T+ q\"}

[tnaqzo-lo]

fran a q}ilft b se. 3lfirfrqq qI n-*frc
{rf6 (c} ,TRT 30 t 3rtfi{ fiqc q-{rt fr wfr fr Frr *) W fl-,if 6' qk +ld t'}' fr
dfls 'rq Frqfr'h 3rrfi-{ rs* ern cSFq
"ti
qrq,
qr
fra$ i'frfifiu ff qlc, 3nq"d;T r6i Eq, {w srsr{ 3*fi-d€I tt 3{Rl6rti qiftIfifi eru fr, 3 fr}n }'Ef+ffis fu-qt
2j

. {rffi' or csrdq{- {rq {rfr'R, vlrsftq {rqq* fr 3{R]{+{r gl{t,

116

t

gst+-"q drfr

28 gqqaaXdoffrri6ri4rihfuqckdr"r-(t)gs+rfufiqqwaqft.+a-+rqqqHlfuqc{rhCq\ffialTarT
* :r5eu il rqrilq$fi ff'r€ qr ff wi t fuq 3rTrrfod ffi ern t fuq +$ $ arq, 3TFr+f,{ qI :i,;zr Bfir€ 6ffir s'6R h.
ft"ftg" *, ffi iRET{;, a1ffi 3rq qfu *, fr Es e+Rrnqq * etftq ffi Yrts e;r ss}T ffi *-*q w qr-arl6-t w
qT

d, kr-q c *'ft.

\z) *t$.fi eK qr 3rq Rftr6 ffi

gq 3Tftrfi-qq w a-4fl-+e-+q qq

ffi iffq qr fuC qq ffi 3rierT }' e65cw i

6qr{te1d"ff'r$qrffqr}*fuq+rmrfr_dffiqrdtgq*d}friqrqted3*uratfrqsrqn*kd-€i-fr6}'ft.

ze. gserftrfrqc611886*srfufrqn{i€qiu;6}3pffi5<uricdn-{s3fiTfiqcfiffisrdsl{t3{Qfa-S

ilTrzrT nlqqr i*'a6 qq, 1.g

*r fr-dr6 @r"{"T 3TRrfiqq, t aso b sqtid't 3rffifi{ur il t.

30. fr{q d-{r} fi vrfu- ( r ) #tr+uc*n *sr{*qq t {rcqsq6r-r T{ lrnrnqc * cffi *} flqiRd *.d h fuq
fuqq, ynsftqn-sq-* il +rtrqfd{ {rc, q+r si;tfi.
(z

)

Rftrsd, efo f*n* sqEiq ff qru-fidr w lfo6o lrilq sr& kiT, W frqc

ffifud + fuq 3qErtr s( q+fr-

(6) vs rrErftqq * 3Td-{ {d qr} * frq 3T}RTa wq *t 1q * tffi'* s-sq

;

(s) m ar6rrqfiiFm*ftar rw E6 tr6-q S{ fifr ffi rfrqr{ *} qra s * 3ftfu *or U"rt arR<

;

(,T) q6arorqRTftils*rfrrr*r+rftRfrns*'qra l0 ffscErrr (r ) * ertitcwq*r Tqffqil{rficrqfi;

(q) q6 qRF ffi *i +r rsv ffi 1q b *i'rur sT qqllTqt 3TF{F[H h;qr wq'Tr

;

) a frfriBqi, &r,*r rqr-q trr{i z * 3rd-{ Rqr w s*'n'
(-rr sE nf.&il{ i ur,r r r fi :c*;rm (zt * :+*qsq q?t hffi*rvr ff lrm i r*'ri
t

ie

;

qT

fii

;,t

.;'ri I i +

i; i

'am r fi j't'.tr{l i.t ) +. arfiq {'.'.q rlqrar arrr foiid +t qr4d, f4,;;i ;p1

;.gi

F.-it e-r;', 'v,.'t';:,i',{'t a:il:ii-rjit'}rna;avfi*?coa4rtFj-tatq}f-l]torfu;t:t-1

r

* go.', isiir 1rT) )'t. . . i+; ';: ,

,

'r'ifc l'ry

;;1; rfnrTr4;rq *' f.tq +raa

,,.t"1

;

;

iv:fi'

gr qfia*rn i{d.JZ tl{ 1q * tt:la i; ;:i 'i'i,:tii- Ti n' 'l

(Z; iftnrrn g-1-rl {€ {rq qTa rfTrar -rrtr -r;l 1x11"14 {"r 'rrfuri*i, ti4t Tsl i++ m,n :'rr 'ranur

{a) {ar $fur T.g * tP${T{ il qofrrd'+ f6 scn 3*r s_{-fi qFdH *1 re +r+r
i3) eiris*"rfuq* G&cmt'ott lqrHf EIq.

'

;

<!-- page 8 -->

8

wq gftr

[qraq:i -lz]
t

1eg @f*..{'r e1fuftqq, 1e6e

[ (, ) v* 3TRfiqq * sreft+ cqrqr qqr r&-fi F-qc, r+K sr] * qwrs qpn{fts, ffq fuirq-risd * sce rcr qrqn. l

3r. ftrr+afrrqr{ft-(r).TRT29*3l-*xi'*3+ta"fr{rEtgqwtfqffirrqqrrs*rn-rfrr+tfuRrarrccT
M'q 1, Js {rwr r+r.r } cs 3nrfreq h s-.{f, F* * qrq t. qqrFlfr. J€ {rq qr
m

3i$,
mr ddtr rs eiF.Tfr-{q t q;dria
,il'r i'frlkd d crqfi.

qT

{z) t+fite-{*fr}gqfr,WffiRF.T*31'rfi-{ffG+t$erdqT*rH tffi;3{<rf-d, Fq|dT.TsTst€aShteiq
tft qm qi *fu ga :rfufiqq * srd-*i t :+sqa

fi?vr. q+rqr ,TqT *+$ Rfiqq qr fi-qq qr bqrrqr *tt erfu rn 1;, wi n-*

tT,{frmstr{*frh3rtfl-{\+ff'rtscdrwrqtmi}ssqwr.*rtwmcraqrfirtedfidpfretr'aeyra-oa-+n.+n+fr
r*fr +e ilm {6 wr 3ftfiqq * 3rtft{ff'r$ ffi erdql srt{r$ fl-qr3Tfrbd q s{ { wq.

32. ff K *t+ +1 {rFs- qRqq 3TRfiqc* wf,xi'+} ffi {Tqfr q}ilqrhct s{} i' *}$ 4H, Ft ffi ett
il ar.f*"G il sttd frft i A *-ftq sr*n * 3i-Sil-qq +, gnt{r errr, {fRI q{sT{ tt 3rrq;q 6{ q}nft qr tfr fri{T t sa;'ft q} {s
3rtTftqqhJqq-.tn'tq{i'rir+dolrr*wsffi+}6*r}*fuqrrqq'{si{*}3ilcrrqtrqr€dEfiqg-ft-d6}:

qqryunrh3rti-{+t$3ilerrffinsq*ffiQ-x*rftiqil3qrrff€*,
sr+qn* qrqrq rfr hqr qRtrr.

r

.

1

e86 + s{ftrftqq {i. +

ff errr z Sr eqqfr anr ( t s- s- t sao ) * ein.:erft-d

qs{63TPaftqqcvQ-*ilngnE},

*4S*
