---
doc_id: "5e8ab56c59deac5b"
source_url: "https://scert.cg.gov.in/pdf/NGO-2022-23/NGO-letter-2022-23.pdf"
ministry: "State council of Educational Research & Training, Raipur, Chhattisgarh"
title: "SCERT द्वारा NGO से प्राप्त प्रस्तावों के प्रस्तुतीकरण के लिए दिशा निर्देश"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "46df849acab0c2a7"
---

<!-- page 1 -->

State Council of Educational
Research & Training, Chhattisgarh
Shankar Nagar, Raipur

Telephone-0771-2443596 Fax-0771.2443496 Website www.scert.ca.govin Email scertcg@gmail.com

y

/ufRuq /tr emNI YIVeII (NGO) / 2022 /.1.k2..Tyy, feaic% 32e22

Website : www.scert.cg.gov.in

TCY T

Hd

yi sTI 7

AutRa

ufiepv g 3if faf 15/04/2022 I

AS

<!-- page 2 -->

State Council of Educational

ufRrerUT yRE, BTIATTg,

Research & Training, Chhattisgarh

TH TY, YRITR

Shankar Nagar, Raipur
Website: www.scert.cg.gov.in

Telephone-0771-2443596, 2443496

rAy, faiis4e3.a3

HT5/ufwz/fèm AdI/2022/ o S

3TT415 U5 23-03/2021/20-

y:q 2022 feT H

TTeroT

P

TIgR fGT 06.03.2021

yuiYUT

NGO's

TRgcitYUT

fe :

BTT F¥

2022-23

PRgcheovU

3THR T I êrs

fer uRy

WebSite

yuitm 7 I 3TTY7

i MHS FiRemg (NGO's) 3TP.P.T.(Power PointPresentation)

RTdtebYUT T 3TYa5 ETNT T, 2020-21 ya 2021-22
a a

Email: scertcg@gmail.com

ET F

3Tyc NI I

g

34TY51

G r

Brt¥IE YY

fMeT

7T?Target Group 71 HA

fEm fa 2020, N.I.P.U.N.Bharat i e t

3H

<!-- page 3 -->

4TiT

02 I

03

RITVISy vivepaii (NGO's)

UvTIai

TbUT RIT offline

g.¥HRFTT,

HET.

TEyTy5

IAS
