---
doc_id: "8aafe4970e9aedc7"
source_url: "https://revenue.cg.nic.in/NoticeforInvitingTender(NIT)ANDRFPunderUPAHAR.pdf"
ministry: "Revenue and Disaster Department, Chhattisgarh"
title: "Notice for Inviting Tender(NIT) एवं RFP under UPAHAR"
date: ""
pages: 141
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2c17ed4fd9f61efa"
---

<!-- page 1 -->

<!-- page 2 -->

Request for Proposal
for

Unified Platform for Agriculture and Holistic
Assessment with Records
(UPAHAR)

RFP No. 350

Raipur Dated 22/04/2026

Invited by

Director of Land Record,
Block – 2, First Floor, Indravati Bhawan,
Nava Raipur Atal Nagar, Raipur, Chhattisgarh - 492002

<!-- page 3 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

NOTICE FOR INVITING TENDER (NIT)
“Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)”
Ref No: - 351

Raipur, Date: 22/04/2026

Director of Land Record Chhattisgarh Government invites Bids from qualified and
experienced companies for the selection of System Integrator to study, design,
development, integration, implementation, execution, migration, operation, and
maintenance of “Unified Platform for Agriculture and Holistic Assessment with Records
(UPAHAR)” with the use of Geo spatial, Remote Sensing and new emerging technologies
for the Director of Land Record Govt. of Chhattisgarh. Bidders qualifying as per the criteria
defined in the RFP are encouraged to participate in the selection process.
Interested bidders should submit their Bids online only in response to this NIT latest by
17:30 hrs. on 13/05/2026 through Online tender portal. The detailed RFP document can
be downloaded from websites e-tender portal http://www.eproc.cgstate.gov.in/ and
departmental portal http://revenue.cg.nic.in.
Director,
Director of Land Record,
Nava Raipur Atal Nagar, Raipur, Chhattisgarh - 492002

Page 2 of 140

<!-- page 4 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

DISCLAIMER
All information contained in this Request for Proposal (RFP) provided/ clarified is in good faith. This is not
an agreement, and this is not an offer or invitation to enter into an agreement of any kind with any party.
Though adequate care has been taken in the presentation of this RFP document, the interested bidders
shall satisfy themselves that the document is complete in all respects. The information published in this
document is not intended to be exhaustive.
Intimation of a discrepancy, if any, should be immediately given to the specified office. If no intimation is
received by this office by the date mentioned in the document, it shall be deemed that the RFP document
is complete in all respects, and firms submitting their bids are satisfied that the RFP document is complete
in all respects.
Director Land Records Chhattisgarh reserves the right to reject any or all of the applications submitted in
response to this RFP document at any stage without assigning any reasons whatsoever. Director Land
Records Chhattisgarh also reserves the right to withhold or withdraw the process at any stage with
intimation to all who have submitted their bids in response to this RFP. Director Land Records Chhattisgarh
reserves the right to change/ modify/ amend any or all the provisions of this RFP document without
assigning any reason. Any such change would be communicated to the bidders by posting it on the official
eProcurement Website (http://www.eproc.cgstate.gov.in/ and http://revenue.cg.nic.in).

Neither Director Land Records Chhattisgarh nor its employees, associates, and consultants will have any
liability to any prospective bidder interested to bid or any other person under the law of contract to the
principles or resolution or unjust enrichment or otherwise for any loss, expense, or damage which may
arise from or be incurred or suffered in connection with anything contained in this RFP document, any
matter deemed to form part of this RFP document, the award of the Project, the information and any
other information supplied by or on behalf of Director Land Records Chhattisgarh or their employees and
bidders or otherwise arising in any way from the selection process for the Project.
Information provided in this document or imparted to any respondent as part of the RFP process is
confidential to Director Land Records Chhattisgarh and shall not be used by the respondent for any other
purpose, distributed to, or shared with any other person or organization without the written permission
of Director Land Records Chhattisgarh.

Page 3 of 140

<!-- page 5 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

Data Sheet - Key Activities and Dates
Competitive bidding for Study, Design, Development, Implementation, Execution, Migration &
Maintenance of “Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)” for
the Director of Land Records Chhattisgarh Government.
S. No
1
2
3
4

5

Key Activities
Client
Address and Concerned Person
for Correspondence
Cost of Bid Document
Point of Contact related to this
Bid Document

6

Earnest Money Deposit (EMD) /
Bid Security Amount
Mode of deposit of EMD

7
8
9
10
11

Bid Validity period
Selection Method
Assignment Phases
Joint Venture/ Consortium
Availability of Bid Documents

12
13

Language for Communication
Purchase of Bid Document Start
Date & Time

14

Pre-Bid queries/suggestions Last
date and time
E-mail address for Pre-bid
Queries
Pre-Bid Meeting Date and Time
Mode of Pre-bid Meeting

15
16
17

18
19
20
21
22

Bid Submission Start Date
Last Date and Time for Bid
Submission
Bid Opening Date and Time
Technical Presentation Date,
Time, and Venue
Financial Bids Opening Date and
Time

Details
Commissioner Land Record Chhattisgarh Raipur
Block – 2, First Floor, Indravati Bhawan,
Nava Raipur Atal Nagar, Raipur, Chhattisgarh – 492002
INR 20000.00 (Rs. Twenty Thousand Only)
Mr. Rakesh Sahu – Deputy Commissioner
Directorate of Land Records, Government of Chhattisgarh,
Indravati Bhawan, Nava Raipur, Raipur, Chhattisgarh
rakesh.sahu257@cg.gov.in
INR: 2,50,00,000 (Rupees Two Crores Fifty lacs Only)
Online on http://www.eproc.cgstate.gov.in/ valid for 180
days from the date of bid submission
180 Days from the date of bid submission
QCBS (70:30)
As per scope of work mentioned in the RFP
Allowed (One Lead and One partner Allow only)
http://www.eproc.cgstate.gov.in/
http://revenue.cg.nic.in
English
From 22/04/2026 at 1800 hours
Up to 1730 hours on 27/04/2026
clr-cg@nic.in
29/04/2026 at 1200 hours (12 PM)
Pre bid meeting shall be conducted in hybrid mode. Physical
Presence at Office of Commissioner of Land Records –
Meeting Hall at Indravati Bhawan, Nava Raipur, Raipur,
Chhattisgarh along with online video conferencing. Online
link will be available on specific request to official email id
clr-cg@nic.in
22/04/2026
Upto 1730 hours on 13/05/2026
After 1800 hours on 13/05/2026
Would be communicated later to qualified bidders.
Would be communicated later to shortlisted bidders.
Page 4 of 140

<!-- page 6 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

S. No
23

Key Activities
Performance Bank Guarantee

Details
An amount equivalent to 10% of the total contract amount
within 15 days of the LOI issue. The PBG should be issued
by a Scheduled / Nationalized Bank in India, in the favor of
Director Land Records, Chhattisgarh, Indravati Bhawan,
Nava Raipur Atal Nagar, Raipur, Chhattisgarh – 492002

Note: This Bid Document is not transferable.
1. Prospective Bidders are encouraged to undertake a preliminary study of the Directorate of Land
Records Chhattisgarh it’s, Functions, regional office and branch office, etc. at their own cost.
2. Directorate of Land Records Chhattisgarh reserves the right to reject any or all the bids in whole
or in part at any time without mentioning any reasons thereof.
3. Prospective Bidders are encouraged to undertake a preliminary study of the existing
applications/systems of CLR, Food, Agriculture and MARKFED and any other relevant departments
for integration with the new proposed system requirement of integrated command and control
center at their own cost.

Page 5 of 140

<!-- page 7 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

Contents
1.

About Chhattisgarh ............................................................................................................................ 14

2.

About Land Record Department ....................................................................................................... 14

2.1.

About Project ................................................................................................................................ 14

3.

Instructions to Bidder ........................................................................................................................ 15

3.1.

Definitions ..................................................................................................................................... 15

4.

RFP Document Cost ........................................................................................................................... 17

5.

Preparation of Bid/Tender Document ............................................................................................... 17

5.1.

Cost Incurred for Preparation of Bid/Tender Document ............................................................. 17

5.2.

Bid Security/ Earnest Money Deposit .......................................................................................... 17

5.3.

The Bid security may be forfeited: ............................................................................................... 18

5.4.

Language of Proposal.................................................................................................................... 18

5.5.

Pre-bid meeting ............................................................................................................................ 18

5.6.

Amendment of bid document ...................................................................................................... 19

5.7.

Bid Currency .................................................................................................................................. 19

5.8.

Correction of Errors ...................................................................................................................... 19

5.9.

Proposal Validity ........................................................................................................................... 19

5.10.

Lack of Information to bidder....................................................................................................... 19

5.11.

Application and interpretation of clauses .................................................................................... 20

5.12.

Completeness of bid document ................................................................................................... 20

5.13.

Code of integrity ........................................................................................................................... 20

6.

Intellectual Property Rights ............................................................................................................... 21

7.

Contract Period .................................................................................................................................. 21

8.

Contract Agreement .......................................................................................................................... 21

9.

Performance Bank Guarantee (PBG) ................................................................................................. 21

10.

Recovery of Dues .......................................................................................................................... 22

11.

Transfer /Sub-Contracting/Subletting .......................................................................................... 22

12.

Scope of work ............................................................................................................................... 22

12.1.

Brief of Scope of Work .................................................................................................................. 22

12.2. The indicative scope of work defined to deliver the following applications/ modules/system
(but not limited to): ................................................................................................................................... 25
12.2.1.

Satellite Imagery Procurement and Specification ................................................................... 25
Page 6 of 140

<!-- page 8 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

12.2.2.

Field Survey for Ground Truth Data Collection ........................................................................ 26

12.2.3.

Georeferencing of Cadastral Maps........................................................................................... 27

12.2.4.

Crop Acreage & Production Monitoring System ...................................................................... 27

12.2.5.

Crop Identification:................................................................................................................... 27

12.2.6.

Crop Health Monitoring ........................................................................................................... 28

12.2.7.

Crop acreage estimation: ......................................................................................................... 29

12.2.8.

Crop Yield Modeling and Production Estimation .................................................................... 30

12.2.9.

Support for MSP Procurement Planning .................................................................................. 31

12.2.10.

Drought and Dry Spell Monitoring ...................................................................................... 31

12.3.

Drone-Satellite Imagery based (hybrid) disaster monitoring ...................................................... 31

12.3.1.

Flood Mapping and Monitoring (In case of requirement) ....................................................... 31

12.3.2.

Crop Loss Assessment (In case of requirement) ...................................................................... 32

12.4.

Advisories...................................................................................................................................... 32

12.4.1.

Advisory to department ........................................................................................................... 32

12.4.2.

Advisory to extension functionaries ........................................................................................ 33

12.4.3.

Advisory to farmers: ................................................................................................................. 33

12.4.4.

Subject for advisory:................................................................................................................. 33

12.4.5.

Integration with Farmer Registration Module and allied services .......................................... 34

12.5.

Paddy Procurement Module: ....................................................................................................... 35

12.5.1.

Mobile App for digital tokens .................................................................................................. 35

12.5.2.

Block Chain ............................................................................................................................... 36

12.5.3.

Reports Requirement ............................................................................................................... 36

12.6.

Database Management ................................................................................................................ 36

12.7.

Establishment of Data Analytics Center (Command and Control Unit)....................................... 37

12.7.1.

Facilities .................................................................................................................................... 37

12.7.1.1.

Design Considerations: ........................................................................................................ 37

12.7.2.

Overview of Requirements: (But not limited to) ..................................................................... 38

12.7.3.

Data Analysis Center (But not limited to) ................................................................................ 38

12.7.4.

Conference Room: .................................................................................................................... 38

12.7.5.

In-Charge Officials Rooms: ....................................................................................................... 39

12.8.

Data Analytics Centre (DAC) ......................................................................................................... 39
Page 7 of 140

<!-- page 9 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

12.8.1.

Functional Requirements ......................................................................................................... 39

12.8.2.

Core Responsibilities of the System Integrator for DAC (but not limited to) .......................... 40

12.8.3.

Geospatial Infrastructure Layer (GIS Server + OGC Services) .................................................. 41

12.8.4.

Integration with Web-GIS Portal .............................................................................................. 42

12.8.5.

Spatial Indexing, Tiling & High-Performance Map Rendering ................................................. 42

12.8.6.

Digital Web Platform ................................................................................................................ 42

12.8.7.

Mobile Platform ....................................................................................................................... 43

12.8.7.1.

Mobile Application ............................................................................................................... 44

12.9.

Integrations ................................................................................................................................... 45

12.10.

Post Award of work to Selected bidder ................................................................................... 46

12.10.1.

Preparation of Inception Report .......................................................................................... 46

12.10.2.

Deployment of Resources .................................................................................................... 46

12.10.3.

Preparation of Detailed Project Plan ................................................................................... 47

12.10.4.

Design of System Architecture ............................................................................................. 47

12.11.

Cloud Hosting Requirement ..................................................................................................... 49

12.11.1.

Cloud Hosting Requirements ............................................................................................... 49

12.12.

Help Desk .................................................................................................................................. 49

12.13.

Standards & Interoperability.................................................................................................... 50

12.14.

API Approach ............................................................................................................................ 51

12.14.1.

Post Award of Work to Selected Bidder .............................................................................. 51

12.15.

Testing ....................................................................................................................................... 53

12.15.1.

Unit Testing........................................................................................................................... 53

12.15.2.

Performance and Load Testing: ........................................................................................... 53

12.15.3.

User Acceptance Testing (UAT): ........................................................................................... 54

12.15.4.

Security Testing: ................................................................................................................... 54

12.15.5.

Detailed Types of Testing within the scope of SI ................................................................. 54

12.16.

Change orders/ Alterations/ Variations ................................................................................... 56

12.16.1.

Change orders ...................................................................................................................... 57

12.17.

Deployment of the Application ................................................................................................ 57

12.18.

Application Testing and Certification ....................................................................................... 58

12.19.

Security and Performance Testing ........................................................................................... 58
Page 8 of 140

<!-- page 10 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

12.20.

Change Management and Capacity Building ........................................................................... 59

12.21.

Go-live of the Application ........................................................................................................ 59

12.21.1.

Partial Go-Live ...................................................................................................................... 59

12.21.2.

Project Go-Live ..................................................................................................................... 60

12.22.

Training & Handholding............................................................................................................ 60

12.23.

Operation and Maintenance for 4 years .................................................................................. 60

12.24.

Exit Management ..................................................................................................................... 60

12.25.

Others ....................................................................................................................................... 61

12.26.

Functional Requirement Specification (FRS) – Indicative ........................................................ 61

12.27.

Summary Reports of Deliverables............................................................................................ 64

12.27.1.

Design & Development of Web & Mobile Applications (but not limited to)...................... 64

12.27.2.

Data processing service on the remote sensing applications ............................................. 65

12.27.3.

Report and Advisory ............................................................................................................ 65

12.27.4.

Submission Timelines........................................................................................................... 66

13.

Qualification Criteria and Bid Evaluation ..................................................................................... 67

13.1.

Evaluation Criteria (QCBS): ........................................................................................................... 67

13.2.

Bid Opening .................................................................................................................................. 68

13.3.

Rejection and Return of Tender.................................................................................................... 68

13.4.

Department Rights to Terminate the Process .............................................................................. 69

13.5.

Minimum Eligibility Criteria.......................................................................................................... 69

13.6.

Eligibility for a Consortium ........................................................................................................... 73

13.6.1.

Bid by a Consortium of Firms ................................................................................................... 74

14.

Technical Evaluation ..................................................................................................................... 75

15.

Documents Comprising the bidder's Proposal ............................................................................. 77

15.1.

Technical Proposal ........................................................................................................................ 77

15.2.

Financial Proposal ......................................................................................................................... 78

15.3.

Financial Bid / Commercial Proposal............................................................................................ 79

15.4.

Bid Submission details .................................................................................................................. 79

15.5.

Bidder's Authorized Signatory ...................................................................................................... 79

16.

Award of Contract ......................................................................................................................... 80

16.1.1.

Right to Accept Any Proposal and To Reject Any or All Proposal(s) ........................................ 80
Page 9 of 140

<!-- page 11 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

16.1.2.

Failure to Agree with the Terms and Conditions of the Bid Document .................................. 80

17.

Confidentiality .............................................................................................................................. 80

18.

General instructions ..................................................................................................................... 80

19.

Conflict of Interest during Bid Process ......................................................................................... 81

20.

Disqualification ............................................................................................................................. 82

21.

Confidentiality .............................................................................................................................. 83

22.

Data Protection Compliance ......................................................................................................... 84

23.

Delay and Non-Performance ........................................................................................................ 84

24.

Risk Purchase Clause..................................................................................................................... 84

25.

Applicable Law .............................................................................................................................. 84

26.

Limitation of Liability towards Director of Land Records, Government of Chhattisgarh ............ 85

27.

Fraud and Corruption ................................................................................................................... 85

28.

Force Majeure ............................................................................................................................... 85

29.

Conflict of Interest ........................................................................................................................ 86

30.

Settlement of Disputes and Arbitration ....................................................................................... 87

30.1.

Dispute Settlement Mechanism ................................................................................................... 87

30.2.

Legal Jurisdiction........................................................................................................................... 87

31.

Taxes and Duties ........................................................................................................................... 87

32.

Local Conditions ............................................................................................................................ 88

33.

Notice ............................................................................................................................................ 88

34.

Warranty and Maintenance.......................................................................................................... 88

35.

Data Ownership and Access ......................................................................................................... 90

36.

Termination of Contract................................................................................................................ 90

37.

Team Structure for Management and Operations ....................................................................... 90

37.1.

Replacement ................................................................................................................................. 94

38.

Business Continuity Plan (BCP)..................................................................................................... 95

39.

Project Deliverable Timeline and Payment Milestone ................................................................ 95

39.1.

Payment Terms based on Reports Submission ............................................................................ 97

39.2.

Payments for Change Request handling....................................................................................... 97

40.

Service Level Agreement .............................................................................................................. 98

40.1.

Service Level Agreement (SLA): .................................................................................................... 98
Page 10 of 140

<!-- page 12 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

40.1.1.

Service Level – Implementation period SLA. ........................................................................... 98

40.1.2.

Service level agreement for O&M phase ................................................................................. 98

40.1.3.

General Penalty & SLA Conditions ......................................................................................... 100

41.

Annexure ..................................................................................................................................... 101

41.1.

Bid Submission Letter (Annexure – 1) ........................................................................................ 101

41.2.

Bid Submission Letter (Annexure – 2) ........................................................................................ 103

41.3.

Certificate of Corporate Principal (Annexure – 3) ...................................................................... 104

41.4.

Project Experience Submission (Annexure – 4): ........................................................................ 105

41.5.

Technical Bid Submission (Annexure – 5): .................................................................................. 106

41.6.

Manpower Details (Annexure – 6): ............................................................................................ 107

41.7.

Curriculum Vitae Format (Annexure – 7) ................................................................................... 108

41.8.

Software Support (Annexure – 8) ............................................................................................... 110

41.9.

No Deviation Certificate (Annexure – 9) .................................................................................... 111

41.10.

Non-Disclosure Agreement – NDA (Annexure – 10) .............................................................. 112

41.11.

Letter of Undertaking (Annexure – 11) .................................................................................. 115

41.12.

Undertaking by the bidder for No Conflict of Interest (Annexure – 12) ............................... 117

41.13.

Undertaking Regarding Blacklisting/ Non – Debarment (Annexure – 13) ............................ 118

41.14.

Format for Pre-Bid Queries (Annexure – 14) ......................................................................... 119

41.15.

Format for Undertaking on Total Responsibility (Annexure – 15):........................................ 120

41.16.

Undertaking on Compliance and Sizing of System (Annexure – 16): .................................... 122

41.17.

Undertaking on Service Level Compliance (Annexure – 17): ................................................ 123

41.18.

Performance Bank Guarantee (Annexure – 18): .................................................................... 124

41.19.

Form of Power of Attorney (Annexure – 19): ........................................................................ 127

41.20.

Proposed Work Plan (Annexure – 20) .................................................................................... 128

41.21.

Financial Bid Covering Letter (Annexure – 21)....................................................................... 129

41.22.

Financial Proposal Submission Forms (Annexure – 22) ......................................................... 131

41.22.1.

Bill of Quantity ................................................................................................................... 131

41.22.2.

Web & Mobile Applications Customization and Configuration ........................................ 133

41.23.

Bidder’s Authorization Certificate (Annexure – 23)............................................................... 136

41.24.

Indicative Document Checklist (Annexure- 24) ..................................................................... 137

41.25.

Hardware/ equipment specifications for Help Desk (Annexure- 25): ................................... 137
Page 11 of 140

<!-- page 13 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

41.25.1.

All in One Desktop Computer ............................................................................................ 138

41.25.2.

All-in-one multifunctional Printer ..................................................................................... 138

41.25.3.

UPS ..................................................................................................................................... 138

41.25.4.

Configuration for the Video Wall Screen ........................................................................... 139

41.25.5.

Video Wall Controller ............................................................................................................. 139

41.25.6.

Video Wall Management Software ........................................................................................ 139

Page 12 of 140

<!-- page 14 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

Abbreviations
Abbreviations

DLR/Department
UPAHAR
DAC/ICCC
MSP
SLA
INR
EMD
GST
RFP
IPR
MeitY
NDVI
EVI
SAVI
NDWI
GP
CCE
KPI
LMS
RS
API
GPS
RBAC
CSP
SPOC
SI
O&M
OGC
BIS
CERT-In
UAT
SPDI
FRS
EAI
MoA
EPF
PAN
MAAT
WAN

Details

Directorate of Land Records, Government of Chhattisgarh
Unified Platform for Agriculture and Holistic Assessment with Records
Data Analytics Center/ Integrated Command and Control Center
Minimum Support Price
Service Level Agreement
Indian National Rupees
Earnest Money Deposit
Goods and Services Tax
Request for Proposal
Intellectual Property Rights
Ministry of Electronics and Information Technology, Government of India
Normalized Difference Vegetation Index
Enhanced Vegetation Index
Soil Adjusted Vegetation Index
Normalized Difference Water Index
Gram Panchayat
Crop Cutting Experiment
Key Performance Indicator
Learning Management System
Remote Sensing
Application Programming Interface
Global Positioning System
Role-Based Access Control
Cloud Service Provider
Single Point of Contact
System Integrator
Operation and Maintenance
Open Geospatial Consortium
Bureau of Indian Standards
Indian Computer Emergency Response Team
User Acceptance Testing
Sensitive Personal Data Rules
Functional Requirement Specification
Enterprise Application Integration
Memorandum of Association
Employees' Provident Fund
Permanent Account Number
Minimum Average Annual Turnover
Wide Area Network

Page 13 of 140

<!-- page 15 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

1. About Chhattisgarh
Chhattisgarh is a state in central India, known for its rich tribal culture, abundant natural resources, and
historical sites. It was formed on November 1, 2000, by separating from Madhya Pradesh. The state is
often called the "Rice Bowl of India" due to its high rice production.
The Geography and Location: Chhattisgarh is located in the east-central part of the country and is
surrounded by Uttar Pradesh and Jharkhand to the north and northeast, Odisha to the east, Telangana to
the south, and Maharashtra and Madhya Pradesh to the west.
Economy: Chhattisgarh is rich in natural resources, particularly coal, iron ore, and bauxite, making it a key
player in the power, steel, and cement industries. It's also a major producer of rice, hence the nickname
"Rice Bowl of India".

2. About Land Record Department
The Directorate of Land Records, Chhattisgarh, functioning under the Revenue and Disaster Management
Department, is responsible for the maintenance, updation, and digitization of land records in the state.
The Director Land Records is the custodian of both government lands and private lands. The Directorate
manages land records such as Khasra, B-1 Khatauni, and land parcel maps, while registration-related
documents like sale deeds are handled by separate Registration Department. Citizens can access and verify
land records online through the official ‘Bhuiyan’ portal. The following related information (indicative) as
follows:
i.

District of Chhattisgarh – 33

ii.

Number of Blocks in Chhattisgarh – 146

iii.

Number of Tahsil in Chhattisgarh – 252

iv.

Number of Villages in Chhattisgarh – 20289

v.

The total Number of Khasra available in Chhattisgarh state – 25298568

vi.

The total Number of Government Khasra available in Chhattisgarh state – 2870612

vii.

The total Number of Khasra available with Digital Signature – 24044189

viii.

The total Number of available Nazul Khasra/ Plot– 125958

ix.

The total Number of Diversion Khasara – 239633

2.1. About Project
The primary goal of this project is to undertake the study, design, development, implementation,
execution, migration, operation, and maintenance of an integrated system/application focused on Paddy
Procurement, crop acreage estimation, yield estimation, disaster management and monitoring, pest and
disease identification, weather advisories, and other related functionalities using Geospatial, GIS, Remote
Sensing, other frontier technologies as applicable and as required and AI/ML technologies—supported
through a Data Analytics Centre (DAC) and help desk support.
Page 14 of 140

<!-- page 16 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

The objective of this project is to establish a digitally enabled ecosystem for the monitoring, analysis, and
forecasting of agricultural and other allied activities as required by the department across the state using
Geospatial, GIS, Remote Sensing, other frontier technologies as applicable and as required and AI/ML
technologies along with allied application of paddy procurement module. The platform and it’s paddy
procurement module will serve to both government stakeholders - including MSP procurement entities and farmers, by delivering actionable, data-driven insights across agriculture value chain. It will support
crop management, acreage estimation, disaster monitoring and assessment and real-time advisory
services for informed decision making. The platform will also enable seamless integration with other
departmental (inter and intra) applications/systems/apps, facilitating bi-directional data exchange (data
pull and push) to ensure interoperability, data consistency, and a unified view across systems covering both
central/state government and private sector applications as per the requirement.

3. Instructions to Bidder
3.1. Definitions
1 ‘System Integrator’ means the person(s), partnership(s) or company(ies) with whom this Contract is
placed.
2 ‘The System integrator’s Representative’ means the person named who is responsible for all
contractual aspects of the contract on behalf of the SI.
3 ‘The system integrator’s Personnel’ means any person instructed pursuant to this Contract to
undertake any of the system integrator’s obligations under this contract, including the system
integrator’s employees, agents, and sub- system integrator.
4 ‘Joint Venture’ means a system integrator which comprises two or more partners each of whom will
be jointly and severally liable to the Client for all the system integrator’s obligations under the contract.
5 ‘The Client’s Representative’ means any entity appointed by the client to act on the client’s behalf
about procurement and/or management of this contract.
6 ‘The PMU’s means and refers to the project management unit of SI, a separate vertical formulated
under Director Land Records Chhattisgarh for project management, implementation, execution and
monitoring of the scope mentioned in the RFP.
7 ‘The Services’ means the services delivered to the stakeholders of the project using the tangible and
intangible assets created, procured, installed, managed, implemented and operated by the system
integrator.
8 'Service Level' means the level of service and other performance criteria that will apply to the set
services as published in this RFP.
9 ‘The Software/Online application solution’ means the study for software designed and developed/
customization and implemented by the system integrator or the system integrator’s personnel and
software, hardware, antiviruses, licenses, tools, other accessories and includes the study, plan, design,
develop, procure, customize, install, configure, integrate, execute, migrate and maintain entire
software with source code and object code along with associated documentation, which is the work
product of the development efforts envisaged in the terms of reference.

Page 15 of 140

<!-- page 17 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

10 ‘The Program Manager’ for the head of project management unit for the project means the person
named who is responsible for issuing instructions and dealing with all correspondence in connection
with the technical aspects of the contract.
11 ‘Contract Documents’ means the documents listed in the contract agreement, including any
amendments thereto.
12 ‘Contract Price’ means the price payable to the system integrator as specified in the contract
agreement, subject to such additions and adjustments thereto or deductions there from, as may be
made pursuant to the contract.
13 ‘Contract’ means the contract agreement entered between the client and the system integrator,
together with the contract documents referred to therein, including all attachments, appendices, and
all documents incorporated by reference therein.
14 ‘Application’ means the Application developed or Solution customized, tested, deployed and
changed/improved during project duration by the Implementing Agency for the purposes of rendering
services to the stakeholders of the Project as per agreed performance standards and levels.
15 ‘Bidders’ means the agencies participating and submitting their bids as per the bid time schedule.
16 ‘Lead Bidder’ means the person(s) or company(ies) with whom this Contract is placed.
17 'Confidential Information' means all information including Project Data (whether in written, oral,
electronic, or other format) which relates to the technical, financial and business affairs, customers,
bidders, products, developments, operations, processes, data, trade secrets, design rights, know-how
and personnel in connection with this Bid Document.
18 'Contract Value' is the bid value which means the price accepted by the Director Land Records
Chhattisgarh as per Price Schedule.
19 'Competent Authority' is the official within Director Land Records Chhattisgarh legally authorized to
perform all the necessary roles and functions pertaining to this Bid Document.
20 'Deliverables' means the products and services agreed to be delivered by the Successful Bidder in
pursuance of the agreement as elaborated in Scope of Work.
21 'Go-Live' means the date of issuance of Certificate of Completion by Director Land Records
Chhattisgarh.
22 ‘Purchaser’ or ‘Authority’ refers to the Director Land Records Chhattisgarh of Chhattisgarh, Raipur.
23 ‘Project Data’ means all proprietary data of project generated out of project operations and
transactions, documents, code, database, queries and related information including but not restricted
to user data which the Bidder obtains, possesses or processes in the context of providing the services
it should be property and all rights including copy rights of Director Land Records Chhattisgarh of
Chhattisgarh Raipur.
24 'Project Duration' refers to the period of this project for which this RFP is being issued.
25 'Selection Committee' means the committee constituted Director Land Records Chhattisgarh level for
bid evaluation and selection of most appropriate bidder as per procedures and provisions articulated
in this RFP document.
26 'Service Level Agreement (SLA)' means the study, design, supply, development, installation,
implementation, migration and maintenance SLA, to be executed within time by the SI, in terms of the
service level requirements project deliverables, uptime of application, software, hardware, support
mechanism etc. as set out in the contract.
Page 16 of 140

<!-- page 18 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

27 Data Analytics Center (DAC) – The data analytics center act as Integrated Command and Control
Center a centralized hub in Unified Platform for Agriculture and Holistic Assessment with Records
(UPAHAR) initiatives that monitors, review and implement ground level operations, data, and security
in real-time for data assisted timely decision making.
28 ‘Similar type of services’ means study, design, supply, development, installation, implementation,
integration, migration and operation & maintenance of software/applications/platforms.
29 “Acceptance” means the Department’s written certification that following installation, the system(s)
(or specific part thereof) has been tested and verified as complete and/or fully operational, in
accordance with the acceptance test defined in the Acceptance Test Documents.
30 “Acceptance Test Documents” means a mutually agreed document which defines procedures for
testing the functioning of the Proposed Application, against requirements laid down in the agreement.
It should define tests to be carried out, test equipment and expected test results.
31 “Documentary evidence” means any matter expressed or described upon any substance by means of
letters, figures or marks intended to be used for the recording of that matter and produced before a
court.

4. RFP Document Cost
The RFP document cost is Non-refundable INR. 20,000/- is to be submitted along with the bid towards the
cost of the tender paper on online on the e-Tendering portal http://www.eproc.cgstate.gov.in/. Bids
received without or with inadequate RFP Document fees will be rejected.

5. Preparation of Bid/Tender Document
5.1. Cost Incurred for Preparation of Bid/Tender Document
Bidder shall bear all costs associated with the preparation and submission of the tender including surveys
and Director Land Records Chhattisgarh will in no case be responsible or liable for those costs, regardless
of the conduct or outcome of the tender process.

5.2. Bid Security/ Earnest Money Deposit
1. The Bidder shall furnish as part of its bid, a bid security of the amount as mentioned in datasheet
above (the "Bid Security"), online on the e-Tendering portal http://www.eproc.cgstate.gov.in/
valid for 180 days from the date of bid submission. In the absence of Bid Security, a bid shall be
considered non-responsive and shall not be considered for selection.
2. The Bidder shall furnish, as part of its bid, a bid security (EMD) of INR 2,50,00,000 (Rupees Two
Crores and Fifty lacs only), submitted online via the Chhattisgarh e-Procurement Portal
(eproc.cgstate.gov.in), valid for 180 days from the date of bid submission. Unsuccessful bidders'
EMD will be returned within 90 days from contract signing. The successful bidder's EMD will be
discharged upon furnishing the performance security. The EMD may be forfeited if the bidder
withdraws its bid during validity, fails to sign the contract, or fails to furnish performance security.
No interest shall be payable on EMD.

Page 17 of 140

<!-- page 19 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

5.3. The Bid security may be forfeited:
1. If a bidder withdraws its bid during the period of bid validity specified in this bid document
2. In case the successful bidder fails to sign the contract as specified in this bid document or fails
to furnish performance security as specified in this bid document.
3. No interest shall be payable on bid security under any circumstances.
4. In the event that Purchaser terminates the Agreement pursuant to failure on the part of the
system integrator to comply with the conditions as contained in this Clause and depending on
the event of default, Performance Guarantee furnished by system integrator may be forfeited.
5. Fraud and Corrupt Practices: The Bidders/Bidders and their respective officers, employees, and
advisers shall observe the highest standard of ethics during the selection process.
Notwithstanding of anything to the contrary contained in this RFP, the purchaser shall reject a
proposal without being liable in any manner whatever to the Bidder, if it determines that the
Bidder has, directly or indirectly or through an agent, engaged in corrupt practice, fraudulent
practice, coercive practice, inexpedient practice or restrictive practice (collectively the
“Prohibited Practices”) in the selection process. In such an event, the purchaser shall, without
prejudice to its any other rights or remedies, forfeit and appropriate the bid security or
performance security, as the case may be, as pre-estimated compensation and damages
payable to the authority for, inter alia, time, cost and effort of the authority, in regard to the
RFP, including consideration and evaluation of such bidder’s proposal.

5.4. Language of Proposal
The proposal prepared by the bidder, as well as all correspondence and documents relating to the tender
exchanged between the bidder and Director Land Records Chhattisgarh shall be in English. Information
supplied in other languages shall be rejected.

5.5. Pre-bid meeting
1. Pre-bid meeting shall be conducted either through physical meetings at Director Land Records
Chhattisgarh or as per the decided by department HO or Video Conferencing on the date and time
mentioned in the datasheet. Potential bidders interested in joining the Pre-bid meeting, must
share their Company Name, Authorized Person's name, Email and Contact No. at the email
address mentioned in the data sheet latest by one day before the pre-bid conference. Director
Land Records Chhattisgarh shall invite them formally through email.
2. Bidders are required to submit the queries/clarifications/suggestions in writing (editable MS
Word/ Excel format) to specified e-mail address mentioned in the data sheet in given format
(Annexure- 14) Format for Pre-Bid Queries latest by one day in advance from the date of pre-bid
meeting. Bidders note that queries not submitted in the prescribed format may not be addressed
at all. Department shall not be responsible for ensuring that the Bidders’ queries have been
received by them. Any requests for clarification post the indicated date and time may not be
entertained by the Purchaser.
3. In the pre-bid meeting, Departmental technical committee representatives would address
clarifications sought by bidders with respect to the RFP document and the proposed project scope
Page 18 of 140

<!-- page 20 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

defined in the RFP. Clarifications that require internal consultation would be addressed in written
form and uploaded on the e-Tender portal http://www.eproc.cgstate.gov.in/ and Departmental
Portal http://revenue.cg.nic.in
4. Director Land Records Chhattisgarh reserves the right not to respond to any/all queries raised or
clarifications sought if, in their opinion and at their sole discretion, they consider that it would be
inappropriate to do so or do not find any merit in it.
5. All responses to the Pre-bid queries and amendments/corrigendum’s (if any) would be uploaded
only on http://www.eproc.cgstate.gov.in/ and http://revenue.cg.nic.in Bidders are advised to
regularly visit the e-Tender portal for updates.

5.6. Amendment of bid document
1. At any time prior to the deadline for the submission of bids, the Director Land Records
Chhattisgarh may, for any reason, whether on its own or in response to a clarification requested
by any prospective bidder, modify the bid document by way of issuing corrigendum(s).
2. To allow reasonable time to the prospective bidders for considering such amendment(s), in the
preparation of their Bids, the Director Land Records Chhattisgarh, at its discretion, may extend the
deadline for the submission of bids, any time.
3. All the amendments/corrigendum/addendum (if any) would be uploaded on portal
http://www.eproc.cgstate.gov.in/ and departmental portal http://revenue.cg.nic.in.

5.7. Bid Currency
Prices for services offered shall be quoted in Indian National Rupees (INR) only.

5.8. Correction of Errors
The person signing the bid must initial erasures or other corrections. The Bidder further agrees that in the
event of any obvious errors, Director Land Records Chhattisgarh reserves the right to waive such errors in
its sole discretion. However, Director Land Records Chhattisgarh has no obligation under any
circumstances to waive such errors.

5.9. Proposal Validity
1. The bid shall remain valid for 180 days from the actual date of Technical Bid Opening. Bidder
should ensure that in all circumstances, its Bid fulfills the validity condition. Any bid valid for a
shorter period shall be rejected as non-responsive.
2. In exceptional circumstances, Director Land Records Chhattisgarh may solicit bidder’s consent to
an extension of the period of validity. The request and the responses thereto shall be made in
writing or by mail. Bid Security/EMD shall also be suitably extended. A bidder granting the request
is neither required nor permitted to modify the bid.

5.10.

Lack of Information to bidder

The bidder shall be deemed to have carefully examined RFP document to his entire satisfaction. Any lack
of information shall not in any way relieve the bidder of his responsibility to fulfill his obligation under the
tender.
Page 19 of 140

<!-- page 21 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

5.11.

Application and interpretation of clauses

For interpretation of any clause in the bid document or contract agreement, the interpretation of the
Director Land Records, Chhattisgarh of Government of Chhattisgarh and associate organization level
technical committee shall be final and binding on the Bidder.

5.12.

Completeness of bid document

Bidders are advised to study all instructions, forms, terms, condition, requirements, and other information
in the RFP document carefully. Submission of bid shall be deemed to have been done after careful study
and examination of the RFP document with full understanding of its implications. The response to this RFP
should be full and complete in all respects. Failure to furnish the information required by the RFP
documents or submission of a proposal not substantially responsive to the RFP documents in every aspect
will be at the bidder's risk and may result in rejection of its proposal. The RFP document is not transferable
to any other bidder.
The bidders are expected to examine all instructions, forms, terms, conditions, project requirements and
other information provided in the bid document, corrigendum/s, if any, pre-bid responses etc. if any.
Failure to furnish any information required by the bid or submission of a bid not substantially responsive
in every respect will be at the bidder’s risk and may result in rejection of the bid and forfeiture of the bid
security. The documents comprising the bid to be mandatorily submitted by the bidder.

5.13.

Code of integrity

1 No official of the purchaser or any Bidder shall act in contravention of the codes which include:
i.
Prohibition of:
a. Making offer, solicitation or acceptance of bribe, reward or gift or any material benefit,
either directly or indirectly, in exchange for an unfair advantage in the procurement
process or to otherwise influence the procurement process.
b. Any omission, or misrepresentation that may mislead or attempt to mislead so that
financial or other benefit may be obtained, or an obligation avoided.
c. Any collusion or bid rigging or anticompetitive behavior that may impair the transparency,
fairness and the progress of the procurement process.
d. Improper use of information provided by the procuring entity to the bidder with an intent
e. Any financial or business transactions between the bidder and any official of the procuring
entity related to tender or execution process of contract, which can affect the decision of
the procuring entity directly or indirectly.
f. Any coercion or any threat to impair or harm, directly or indirectly, any party or its property
to influence the procurement process.
g. Obstruction of any investigation or auditing of a procurement process.
h. Making false declaration or providing false information for participation in a tender process
or to secure a contract.
ii.
Disclosure of conflict of interest.

Page 20 of 140

<!-- page 22 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

2 In case of any reported violations, if the Purchaser, after giving a reasonable opportunity of being
heard, concludes that a bidder or prospective bidder, as the case may be, has contravened the
code of integrity, may take appropriate measures.

6. Intellectual Property Rights
For the customized solution developed for the project, IPR of the solution would belong exclusively to
Director Land Records Chhattisgarh, Government of Chhattisgarh. The agency shall also submit all the
necessary instructions for incorporating any modification/changes in the software and its compilation into
executable/installable product.
Deliverables provided to Director Land Records Chhattisgarh by Agency during its performance under this
project, in which subject to the foregoing provisions of this Article, all right, title and interest in and to
such deliverables, shall, as between agency and Director Land Records Chhattisgarh, immediately upon
creation, vest with Director Land Records Chhattisgarh. To the extent that the agency’s Proprietary
Information is incorporated within the deliverables, agency and its employees engaged hereby grant to
Director Land Records Chhattisgarh a perpetual, irrevocable, non-exclusive, transferable, paid-up right and
license to use, copy, modify (or have modified), transport to Director Land Records Chhattisgarh facilities,
and prepare from them, use and copy derivative works for the benefit of and internal use of Director Land
Records Chhattisgarh, of such agency’s Proprietary Information, Department’s rights pursuant to the
preceding sentence include the right to disclose such agency’s Proprietary Information to third party
contractors solely for use on the project provided that all such third party contractors execute, deliver and
comply with any customary confidentiality and non-disclosure agreements reasonably required by
Director Land Records Chhattisgarh.

7. Contract Period
The project duration is 5 years - (16 weeks for study, design, development and implementation and
remaining duration for Operations & Maintenance, or O&M), with phased deliverables from the Date of
Agreement and which may be extendable for maximum period of 24 months based on performance and
with the consent of competent authority.

8. Contract Agreement
a) This Bid Document, in totality, will be constituted as part of the Contract Agreement between
department and Successful Bidder.
b) Successful Bidder shall bear the cost of procuring stamp paper of an amount as specified by
Registration and Stamps, Commercial Taxes Department, GoCG.

9. Performance Bank Guarantee (PBG)
1. The Bidder shall be required to submit PBG as specified in Bid Data Sheet within 15 working days
of issue of LOI/LOA in the format detailed in annexures.
2. The PBG shall be denominate/d in the currency of the contract and will be for an amount as
mentioned in Bid Data Sheet. All charges with respect to the PBG shall be borne by the Bidder.
3. The PBG shall remain valid six months beyond the life of the contract including extensions, if any.
Page 21 of 140

<!-- page 23 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

4. The PBG will be discharged/returned only after issuance of ‘No-Demand Certificate’ by the
department upon being satisfied that there has been due performance of the obligations of the
bidder under the contract. However, no interest shall be payable on the performance bank
guarantee.
5. In the event of the Bidder being unable to service the contract for whatever reason, Department
will invoke the PBG. Department shall notify the Bidder in writing of the exercise of its right to
receive such compensation within 10 days, indicating the contractual obligation(s) for which the
Bidder is in default.

10.

Recovery of Dues

1. Any sum of money due and payable to the Service Provider under this contract may be
appropriated by the Department and set off against any claim of the Department for the payment
of any sum of money arising out of this contract or under any other contract made by SI with the
Department.
2. In case of any recovery arising due to non-conformity to the agreement with its terms and
conditions, they will be recovered from deposited amounts (in form of EMD/PBG), any service
charges payable to SI and if required by invoking the Performance Bank Guarantee. If the
recoverable amount still remains due, it shall be recovered from Service provider as land revenue.

11.

Transfer /Sub-Contracting/Subletting

The bidder has no right to give, bargain, sell, assign or sublet or otherwise dispose of the Contract or any
part thereof, as well as to give or to let a third party take benefit or advantage of the present Contract or
any part thereof.

12.

Scope of work

12.1.
#
1.

Brief of Scope of Work

Scope Heads
Design, Development,
Testing, Configuration,
Integration of
System/Application/s and
Implementation for Unified
Platform for Agriculture and
Holistic Assessment with
Records (UPAHAR)

Description (But not limited to)
a. Design and Development of the Project Implementation plan
b. Business Requirements, FRS, SRS, System Design &
Application Development, HLD, LLD and other required
documentation as per stakeholder’s requirement (but not
limited to)
c. Design, Supply, Installation, Configuration, Integration &
Customization of System/Applications, tools, licenses,
mobile apps etc. as required to implement the overall
system to achieve its desired objectives.
d. Development and Implementation of a System Security Plan
(SSP) framework tailored to project requirements, including
configuration, integration, and customization.
e. Data/Images procurement/Acquisition, its assessment,
benchmarking, meaningful assisted decision-making
support, advisory services, and Reporting Services
Page 22 of 140

<!-- page 24 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

f.

g.

2.

Establishment and
Maintenance of DAC

2.

Application Hosting,
Collaboration and
Networking on cloud service
provider empaneled by
MeitY/CHiPS for Unified
Platform for Agriculture and
Holistic Assessment with
Records (UPAHAR)

3.

4.

h.
i.
j.
a.

a.
b.
c.
d.

e.
f.
g.
Training and Capacity Building a.
b.
c.
d.
e.
f.

g.
User Support, Operation and a.
Maintenance
of
the
Integrated IT application and b.
Infrastructure for 4 years

Project Governance and Program Management, including
project planning, milestone tracking, issue and risk
management, stakeholder coordination, reporting, change
control, and compliance monitoring.
Data Management Service with open-source applications or
open-source database services.
Application Testing
Quality Review
Project and Product Documentation
Establishment of the Data Analytics Centre (DAC) and its
operation and maintenance for the entire project duration,
including execution of civil works, interior works, electrical
installations, and provision of seating and workstation
arrangements, in accordance with the designs approved by
the Department. The Department shall provide the requisite
built-up space with roof and walls, while all remaining
activities required to make the DAC fully functional shall be
within the scope of the project.
Cloud based hosting at Data Centre, Disaster Recovery
Centre and backup infrastructure as per the requirement
Redundant Network connectivity from Data Centre to DR
and Purchaser offices
Provision of security infrastructure including IDS / IPS /
Antivirus etc.
Provision of Enterprise Asset Management including help
desk software
Backup Restore and Archival Services
Storage Administration Services
Data Centre and Data Recovery Centre
Training and Capacity Building requirement assessment.
Change Management
Preparation of Comprehensive training program.
Implementation of Train the Trainer Module.
Preparation of Online and offline training modules
Conducting regular/periodic/ad-hoc trainings online and
offline of all the stakeholders as required by the department
during the project duration.
Imparting of regular refresher trainings
Application monitoring and Compliance to Service Level
Agreements
Application support including modifications and integration
with future systems

Regular Security Audit as per
the requirement.
Page 23 of 140

<!-- page 25 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

c. Data/Images procurement/Acquisition, its assessment,
benchmarking, meaningful assisted decision-making
support, advisory services, and Reporting Services
d. Data Management Service with open-source applications or
open-source database services.
e. Application Testing
f. Quality Review
g. Project and Product Documentation
h. Bugs / Fixes Management
i. Software Change and Version Control
j. Maintenance of Configuration Information & System
documentation
k. Licenses and warranties for all the off-the-shelf
products/applications
l. Help Desk Software Implementation and Services
m. Database Administration
n. User Administration
o. Security Administration and Conducting regular security
audits as per guidelines.
The module shall serve as a unified interface for onboarding,
farmers, procurement tracking, and managing society-level
activities, enabling the Department of Food, Department of
Agriculture and the Director Land Records to monitor
institutional agricultural support delivery across the state.

5.

Paddy Procurement Module

6.

Mobile App for Digital Tokens

The application must operate effectively across Android and iOS
platforms, supporting offline-first functionality for field use in
low-connectivity rural areas, while synchronizing seamlessly
when connectivity is restored.

7.

Integration

To enable seamless integration with the satellite imagery
verification system and Digital Crop Survey (DCS) and any other
system, applications etc. as per the requirement and the Farmer
Database for the Paddy Procurement Module shall be developed
exclusively from the AgriStack Farmer Registry and as per
requirement of departments/stakeholders. SI shall be
responsible for developing APIs and facilitate any future
integration requirement with any state central, state
government, private sector application/ module.

8.

Data migration / Data Data Migration, if required, refers to the systematic, secure, and
Storage/Data Management
verifiable process of transferring data from existing legacy
systems, registers, databases, applications, or manual records to
the new UPAHAR application/platform, while ensuring data
Page 24 of 140

<!-- page 26 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

integrity, accuracy, completeness, confidentiality, and
compliance with applicable Government of Chhattisgarh and
Government of India standards.
Data management is systematic collection, processing, storage,
securing, and using data to achieve better business outcomes
from UPAHAR thereby ensuring data is accurate, accessible,
secure, and usable for decision-making, analytics
9.

Farmer Registration and The Paddy Procurement Module shall source farmer data
Integration with AgriStack
exclusively from AgriStack. No separate farmer registration shall
be permitted within the UPAHAR system. All farmer data
creation, modification, and validation shall be governed solely
through AgriStack integration.

Note: SI shall be responsible to design, develop, integrate and implement, operate and maintain any other
allied application/system which is related to UPAHAR system for the smooth development and functioning
of the proposed system.

The indicative scope of work defined to deliver the following
applications/ modules/system (but not limited to):

12.2.

12.2.1. Satellite Imagery Procurement and Specification
1. The selected agency shall be responsible for procuring the required satellite imagery for the
project. To facilitate this process, the department will issue a formal letter to NRSC (National
Remote Sensing Centre), if necessary. The satellite imagery must have a spatial resolution of at
least 3 meters or < 3m for agricultural analysis and the temporal resolution for optical data should
not exceed 5 to 7 days.
2. The multispectral satellite data must include a minimum of four spectral bands—Blue, Green, Red,
and Near Infrared (NIR) with a spatial resolution of 3 meters or < 3m. In cases where cloud-free
optical data is unavailable, alternative spectral bands may be utilized.
3. Additionally, subject to prior approval from the competent authority, very high-resolution
satellite imagery may be used to support data processing requirements. The selected agency must
procure imagery for per season at least four distinct dates during each crop growing season,
covering both pre-harvest and post-harvest phases. The selected agency must procure a minimum
of FOUR (04) multi-date satellite imagery sets during each crop growing season, covering key crop
growth stages, including early season, mid-season, peak season (pre-harvest), and late season
(post-harvest).
4. The project area for satellite-based monitoring will encompass agricultural land, including all
cultivated fields to support comprehensive crop analysis and mapping requirements. The selected
agency will be responsible for procuring and processing satellite imagery for two (02) crop seasons
each year, ensuring complete spatial and temporal coverage across the entire cultivated
landscape.

Page 25 of 140

<!-- page 27 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

5. For each crop season, the selected system integrator shall acquire a minimum of four (04)
multi-date satellite imagery sets capturing the key crop growth stages. Accordingly, a minimum
of Four (04) for Kharif Season and Four (04) for Rabi Season, total eight (08) imagery sets must be
delivered annually. The required imagery epochs for each season shall include early-season,
mid-season, peak-season, and late-season stages.
6. All procured imagery must provide complete coverage of the entire agricultural area (parcel wise
define parcel wise) without any gaps, ensuring reliable, consistent, and repeatable multi-temporal
agricultural monitoring across all districts.
7. Imagery procurement shall specifically target the entire cultivated area, accounting for seasonal
variations in sown extent, fallow land conversion, intercropping patterns, and expansion of
agricultural boundaries.
8. In addition, the SI must ensure that satellite scenes include a buffer zone (2 km) beyond cultivated
boundaries to avoid edge distortion and ensure seamless mosaicking of satellite tiles.
9. During cloudy periods and extreme weather conditions, the agency shall incorporate
microwave/SAR data to support monitoring during monsoon, flood events, and other critical
windows where optical data is unavailable.
10. All imagery must be delivered after standard pre-processing, including radiometric correction,
atmospheric correction, geometric correction, cloud/shadow masking, mosaicking, and
georeferencing as per project specifications.
11. Any additional imagery procurement requirement by any other government department or body
for example - disaster management etc. in any region or district, proposed DAC shall help the
concern department with the data analysis/ data reports analysis along with help desk support as
per the requirement post cost approval of the concern authority. This will help in assessing the
ground level impact caused to various departments during the specific event, such as the
Agriculture Department, Disaster Management Department, Food Department, Irrigation
Department, etc. (but not limited to). The cost for such imagery procurement will be additional
and separate from the project cost, calculated on a pro-rata basis depending on the time and
extent of imagery procurement. No other cost apart from imagery procurement shall be payable
to SI for the additional requirement, if any.

12.2.2. Field Survey for Ground Truth Data Collection
1. Field surveys are a critical component of crop classification using remote sensing data. The
selected agency shall conduct ground truth (GT) surveys covering at least 1%, up-to 2% maximum
of the total sown area during each season, across various crop growth stages or as per the
requirements specified by the authority.
2. Surveys must be well-distributed geographically, ensuring representation across different crop
types and cultivation areas within the study region. Field personnel will collect both primary and
secondary crop-related information, recording latitude and longitude coordinates along with key
attributes such as crop type and variety, sowing date, and growth stage, Irrigation status, Field
condition, Intercropping (if any), Farmer details (optional) using a mobile application.
3. The collected ground truth data must be integrated into the crop classification map to enhance
accuracy. Additionally, the selected agency is required to submit a detailed field survey plan to
the authority prior to the commencement of each season.
Page 26 of 140

<!-- page 28 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

4. GT sampling must follow a stratified random sampling approach, ensuring adequate coverage of
crop type, soil type, landholding size, and landscape variability.
5. Collected GT datasets shall undergo strict quality control checks, including spatial accuracy
verification, attribute completeness, duplicate removal, and photo-location match.
6. The agency must recollect or rectify any faulty GT records within five (05) working days of
identification.
7. At least 30% of GT points shall be reserved for independent accuracy assessment, separate from
training datasets.
8. All validated GT data shall be used for classification model training, accuracy improvement, and
refinement of crop maps.
9. The GT dataset (points, attributes, photos, timestamps, QC reports) must be submitted in
prescribed formats and integrated into the project’s Web-GIS platform for transparency and audit
10. The selected agency must deploy trained field personnel, familiar with crop identification, mobile
GT tools, and data quality compliance. Training details must be submitted to the Authority
11. A detailed GT survey plan including methodology, sampling distribution, manpower deployment,
schedule, logistics, and mobile app design and workflow must be submitted and approved prior
to commencement of each season.
12. All GT activities and datasets shall be treated as project assets and must be handed over to the
Authority at the end of each season
13. Through the proposed portal, geo-tagged photographs should be captured, which can also be
verified by the farmer. The farmer’s photograph should also be included, and the survey work
should be carried out based on the prior information available.

12.2.3. Georeferencing of Cadastral Maps
1. The selected Implementing Agency shall be responsible for acquiring cadastral maps from the
Department of Land Records (DLR), Chhattisgarh, in geo-referenced vector formats (e.g.,
shapefiles). The implementing agency will utilize these datasets in the available form, without
performing any additional digitization, geo-referencing, or spatial processing.

12.2.4. Crop Acreage & Production Monitoring System
Timely information on crop acreage is vital for effective resource planning and allocation. The
selected agency shall continuously map and monitor cultivated areas, producing consolidated,
crop-wise acreage estimates and summary reports.

12.2.5. Crop Identification:
1. The selected agency shall be responsible for developing robust crop identification
algorithms, leveraging remote sensing and machine learning techniques.
2. The system should achieve parcel-level crop classification accuracy ≥ 85%. (minimum
85%) Accuracy shall be computed through independent validation datasets and confusion
matrices.
3. The crop identification workflow must utilize multidate imagery representing key crop
growth stages (early, mid, peak, late season) to strengthen the phenological signature
analysis.
Page 27 of 140

<!-- page 29 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

4. The classification workflow shall utilize multi-temporal satellite imagery covering
early-season, mid-season, peak-season, and late-season stages for reliable crop
phenology extraction.
5. The agency shall incorporate spectral vegetation indices including NDVI, EVI, SAVI, NDWI,
and Red-Edge indices to improve crop separability.
6. A hybrid classification approach (supervised classification + machine learning + rule-based
refinement) must be applied to handle agro-ecological variability.
7. The agency shall implement phenology-based consistency checks using time-series
NDVI/EVI curves to validate classification stability across dates.
8. The system must identify multi-cropping and intercropping situations, producing primary
and secondary crop layers where feasible.
9. Classification models must be iteratively improved each season using updated GT samples
and spectral profiles.
10. The classification output must include a confidence score for each parcel, reflecting
classification certainty.
11. The agency is responsible for acquiring or generating the necessary crop data at the
parcel/village/GP level. In cases where cadastral data is unavailable, the agency must
delineate farm boundaries independently. If parcel-level data is not accessible, the village
shall serve as the reporting unit.
12. Parcel boundaries generated must be topologically clean, with no overlaps or gaps,
ensuring accurate spatial area aggregation.
13. A minimum of 30% of Ground Truth (GT) data must be reserved exclusively for
independent accuracy validation (not used in training).
14. Additionally, the agency must conduct an independent accuracy assessment of the
classification output by generating a confusion matrix using the remaining 30% of the GT
data.
15. Accuracy reporting must include Overall accuracy, Producer accuracy, User accuracy,
Class-wise accuracy. Parcel-level accuracy must meet or exceed ≥ 70% for major crops and
Any classification failing to meet accuracy targets must be refined and resubmitted.
16. The classification output shall include Crop-wise maps (parcel, village, block levels), Crop
acreage estimates, Crop dominance maps, Confidence score for each classified parcel.
17. Machine learning models shall be iteratively improved every season, incorporating
updated GT data, spectral profiles, and field feedback to enhance accuracy.
18. All classification layers must be delivered in GIS-compatible formats and integrated into
the project’s Web-GIS platform for visualization, validation, and decision-making.
19. The agency shall document the complete classification methodology, including algorithms
used, training samples, parameters, accuracy report, error matrix, and model
performance summary.

12.2.6. Crop Health Monitoring
1. The selected agency shall implement a satellite-based Crop Health Monitoring System to track
crop condition, detect stress, and support timely interventions during each cropping season.
Page 28 of 140

<!-- page 30 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

2. Crop health monitoring must utilize multi-temporal satellite imagery, including early, mid, peak,
and late-season observations to monitor crop growth patterns
3. The agency shall compute and analyze key vegetation indices (VIs) such as: NDVI (Normalized
Difference Vegetation Index), EVI (Enhanced Vegetation Index), SAVI (Soil Adjusted Vegetation
Index), NDWI (Normalized Difference Water Index)
These indicators must be used to detect crop stress, vigour, and moisture conditions (SWIR
Band).
4. The system shall generate pixel-level and parcel-level crop health maps, updated for each
satellite acquisition date.
5. The agency must implement change detection analysis to identify areas affected by: moisture
stress, nutrient deficiency, pest/disease attacks, flood or waterlogging, drought conditions
6. Identified stress zones must be mapped at parcel, village, block, and district levels, along with
severity categorization (low, moderate, high).
7. The system shall generate seasonal crop health reports and geo-spatial layers that can be
accessed through the project’s Web-GIS platform.
8. The agency must provide alerts/notifications for significant crop stress events, enabling timely
decision-making for field inspections and interventions.
9. Crop health monitoring outputs must be integrated with Ground Truth (GT) observations, Weather
data, Yield estimation, Soil data workflows for improved accuracy and decision-support.
10. Crop health monitoring outputs must be integrated with Ground Truth (GT) observations, Weather
data, Soil data workflows for improved accuracy and decision-support.
11. All crop health layers must be delivered in GIS-compatible formats, including metadata, processing
methodology, and accuracy summary.
12. The agency shall ensure that crop health outputs are consistent across seasons and validated using
available GT data and field feedback.

12.2.7. Crop acreage estimation:
1. Real-time crop area statistics are crucial for effective planning and resource allocation. The
selected agency shall be responsible for mapping all cultivated crops and generating
comprehensive, crop-wise and area-wise acreage estimation reports. This activity must be
continuous throughout the year, as sowing dates vary, and certain crops are cultivated irrespective
of the season. The scope of the project will cover all districts within the state of Chhattisgarh. The
selected agency must ensure comprehensive coverage of all crops cultivated within the village
during both the Kharif and Rabi seasons.
2. Acreage estimation must be continuous, leveraging multi-date imagery to capture staggered
sowing patterns and dynamic crop spread.
3. The system shall detect fallow-to-crop transitions, newly cultivated plots, and abandoned or failed
crop patches.
4. Acreage outputs must identify re-sown areas following rainfall damage, pest attack, or flood
events.
5. Acreage maps must differentiate between the sown area vs. harvested area at
village/block/district levels.
6. The system must generate multidate crop extent change detection layers, identifying area increase
or reduction between acquisition dates.
Page 29 of 140

<!-- page 31 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

7. Acreage estimation must include off-season, short-cycle, and perennial crops. Acreage validation
shall use GT data, historical crop statistics, and phenology profiles for cross-verification.
8. Acreage deliverables must include: - Village-wise acreage maps, Block and district summaries,
Acreage heatmaps & density maps and Year-on-year acreage comparison
Final outputs shall be provided in GIS-compatible formats (SHP, GeoJSON, GeoTIFF or as per the
requirement of Department) and integrated into the project’s Web-GIS dashboard.

12.2.8. Crop Yield Modeling and Production Estimation
1. Estimating crop yield with reasonable accuracy ahead of harvest is essential for ensuring food
security and facilitating responsive policy measures. Crop production estimation is typically
derived from a combination of crop yield data and acreage assessments. Timely forecasting of
crop production is essential for the department to effectively plan activities related to agricultural
marketing and resource allocation.
2. The selected agency shall integrate crop yield predictions—generated through data analytics and
crop modeling techniques—with satellite-based crop acreage estimations. This integration will
enable accurate forecasting of expected crop production across the designated area and help
determine the total output for crops.
3. Ideally, the crop production estimation report should be submitted after the finalization of the
crop acreage report, ensuring consistency and reliability in the forecasting process.
4. Accurate crop yield estimation is a critical component in ensuring food security and supporting
economic planning. Predicting crop yields with reasonable accuracy prior to harvest enables
timely interventions, particularly in cases where low yields are anticipated.
5. For crop production estimation, the selected agency shall develop robust crop yield models using
a combination of spectral data, weather information, land and soil parameters, and agronomic
inputs at the parcel, village, or Gram Panchayat level. These models should be developed for all
major crops, as notified by the authority before the start of each season.
6. Yield models must incorporate multi-temporal vegetation index trends (NDVI, EVI, SAVI, NDWI)
derived from satellite imagery to capture crop vigor, biomass accumulation, and stress variations
throughout the season.
7. The selected agency shall integrate weather parameters (rainfall, temperature, humidity,
evapotranspiration) and soil moisture indicators to strengthen the accuracy of yield prediction
models.
8. Yield forecasts must account for anomaly factors, including drought stress, flood/waterlogging,
pest/disease impacts, and nutrient deficiency indicators identified during crop health monitoring.
9. Yield estimation must include both mid-season forecast (based on spectral and agro-climatic
indicators) and end-season final estimates, calibrated using ground data and field observations.
10. The yield estimation framework must support village-level, block-level, district-level, and statelevel aggregation, aligning with departmental reporting hierarchies.
11. The selected agency is required to submit two yield reports per season:
i.
One month before harvest, based on predictive modeling.
ii.
One month after harvest, incorporating Crop Cutting Experiment (CCE) data for validation.
12. Following validation, a final yield report must be submitted to the authority, ensuring accuracy
and reliability in crop production forecasting.

Page 30 of 140

<!-- page 32 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

12.2.9. Support for MSP Procurement Planning
1. To support data-driven governance in agricultural procurement, the selected agency shall
operationalize its satellite-derived outputs to facilitate Minimum Support Price (MSP)
procurement planning and validation. This functionality is envisioned as a value-added layer that
leverages existing classification, acreage data without duplicating those workflows- to enable
transparency and precision in procurement processes.
2. The system must provide actionable insights on crop presence and extent at village and block
levels, indicative availability patterns for procurement planning, identification of areas with
comparatively lower crop coverage or delayed crop development, and early identification of
regions requiring proactive procurement and logistical interventions.
3. MSP support outputs must be integrated into the Web-GIS platform and exported in
GIS-compatible formats for use by procurement and food supply chain departments.

12.2.10.

Drought and Dry Spell Monitoring

1. Monitoring weather conditions and drought trends is essential for informed decision-making and
policy planning by the Commissioner of Chhattisgarh Land Records. The selected agency shall
conduct multi-year analysis of weather data in conjunction with satellite-based remote sensing to
assess drought patterns using geostatistical methods and advanced data analytics techniques.
2. The selected agency shall provide predictive insights into rainfall patterns for the target area,
including the estimated time interval between the current rainfall event and the next expected
occurrence.
3. The agency shall utilize satellite-derived vegetation indices (NDVI, EVI, SAVI, NDWI) to detect
vegetation stress and moisture loss, enabling early identification of drought onset.
4. Multi-temporal analysis of vegetation and soil moisture conditions must be carried out to classify
drought severity at parcel, village, block, and district levels.
5. The agency shall incorporate microwave/SAR data for assessing drought conditions during cloudy
or monsoon periods when optical imagery is unavailable.
6. The drought monitoring system shall generate anomaly maps by comparing the current season’s
vegetation and soil moisture conditions with long-term historical averages.
7. Dry spell assessment shall include analysis of consecutive rainless days, crop water-stress risk, and
deviation from normal monsoon behavior across the project area.
8. The agency must prepare village-level drought severity layers categorized as: No Stress, Mild
Stress, Moderate Stress, Severe Stress.
9. The system must generate early-warning alerts for severe vegetation stress zones, enabling field
verification and timely intervention by the department.
10. All drought-related outputs including stress maps, anomaly layers, rainfall deviation maps, and
predictive dry-spell indicators must be integrated into the project’s Web-GIS platform.
11. The agency must submit seasonal drought assessment reports, including spatial statistics, drought
evolution trends, and crop-specific impacts for each district.

12.3.

Drone-Satellite Imagery based (hybrid) disaster monitoring

12.3.1. Flood Mapping and Monitoring (In case of requirement)
1. The agriculture sector is highly susceptible to flood events, which can severely damage crops,
particularly during critical phases such as planting or harvesting. In the event of a natural or
localized flooding incident, the selected agency shall utilize real-time remote sensing data to
identify, and map submerged or inundated agricultural areas.
Page 31 of 140

<!-- page 33 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

2. The selected agency shall provide detailed information on crop acreage within the designated
area, along with the current crop situation. Additionally, the agency must identify and map regions
that are likely to be flood-prone or suffer from inadequate drainage infrastructure.
3. Flood mapping shall utilize both optical and microwave/SAR data, ensuring reliable detection even
during cloud cover.
4. Flood impact must be assessed using multi-temporal change detection, comparing pre-flood and
post-flood imagery to quantify damage intensity.
5. The agency shall generate flood severity classification layers (e.g., shallow, moderate, deep
inundation) at parcel, village, and block levels.
6. UAV (drone) flights may be deployed for high-resolution validation, subject to approval by the
competent authority.

12.3.2. Crop Loss Assessment (In case of requirement)
1. Precise estimation of crop loss at the parcel level is critical for implementing crop insurance
schemes and compensation programs. In the event of crop damage resulting from natural
disasters, local calamities, or disease and pest outbreaks, the selected agency shall provide both
an overall assessment and detailed parcel-wise data, indicating the extent and severity of damage
for each affected crop.
2. Crop loss assessment should encompass damages occurring at various stages of the cropping
cycle, including sowing, mid-season, and harvesting phases. The assessment must be conducted
using satellite remote sensing data and should be validated through field surveys to ensure
accuracy and reliability.
3. Loss estimation shall use: NDVI/EVI reductions, Change detection between seasonal time-steps,
Moisture anomaly mapping, Flood/water-logging signatures and Pest/disease indicators derived
from spectral deviation
4. Damage classification must include categories such as: No Damage, Partial Damage, Severe
Damage, Crop Failure
5. This categorization must be generated at parcel, village, block, and district levels for administrative
decision-making.
6. SI shall have to provide the analytics as per the insurance requirement, if required by the
department.

12.4.

Advisories

The selected SI shall be responsible for establishing a robust and scalable advisory framework and system
designed to support multiple stakeholders, namely the Department of Agriculture, extension
functionaries, and registered farmers. This advisory system will leverage data from satellite imagery,
weather sources, field surveys, and predictive models to generate timely, actionable guidance. Advisories
shall be disseminated through web platforms and mobile applications, with appropriate role-based access
and multilingual capabilities.

12.4.1. Advisory to department
The selected SI should provide advisory to the department for the stress identification, weather pattern,
cropping pattern with the area to be approach for solution with crop acreage and crop situation of the
particular area. Advisory should be accessible through web platform as well as mobile application.

Page 32 of 140

<!-- page 34 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

12.4.2. Advisory to extension functionaries
The selected SI should provide selective area information to the concerned extension functionaries for the
subject narrated in the document. These advisories should be available to the field functionaries through
mobile application. Field functionaries will be extension officers and other officials as deemed necessary
by the authority.

12.4.3. Advisory to farmers:
a. Generalized advisory to all farmers:
Advisory which are general in nature should be disseminated to all the farmers of the given area through
SMS Or Whats app Or IVRS. Generalized advisories should be at Tehsil level and it should highlight specific
region if any concerns are there. Separate validation mechanisms shall be finalized once the project is
operational. Farmer mobile application should have the facility for:

•
•
•
•

To integrate the weather data from Automatic weather stations, IMD and any other reliable weather
data sources. Weather forecast should include forecasted rainfall, temperature, humidity, wind speed
and cloudiness.
To provide soil preparation advisory services at beginning of the cropping season.
To provide crop management practice to the farmers at each crop growth stage.
Backend platform of the mobile app should have the facility to maintain crop knowledge database
which includes recent best package of practices for individual crops.
b. Personalized advisory

The selected SI should provide mobile based facilities for registered farmers, where farmers can pin their
farm to get crop situation and personalized advisory. Selected SI should provide farm specific personalized
advisory. Personalized advisories should be at parcel level. Personalized advisories are to be generated
using satellite data however the mobile application should have the provision for farmers to upload image
and comment text through their application. Department will help bidder for the registration of farmers
or on boarding them to the platform.

12.4.4. Subject for advisory:
a) Advisories on sowing and harvesting time:
Information on best time for sowing will help farmers to plan their sowing related activities in advance.
Also, Identification of crop wise planting dates spatially will identify areas which are behind in sowing,
which will help department analyse reason and implement the contingency measures. Selected SI should
create advisories for farmers on best possible sowing date based on weather prediction. Also, the selected
SI should create additional reports at the end of season analyzing the sowing pattern for the identified
crops based on planting date by using multi temporal satellite data on basis or the time period given by
department. Selected SI should also identify the probable harvesting date by using satellite data integrated
crop models and submit the report to department.
b) Advisories on crop stress:
Crop condition and stress identification at early stages of the crop is essential for farmers to do necessary
action in time and also agriculture department to better monitoring of crop health. Selected SI should
assess the crop health condition of each crop periodically through remote sensing and field visits. On
abrupt change of crop health or such anomalies in any area of the state, should be detected and provide
advisories to farmers. Selected bidder should also provide the department with detailing of the area, crop
situation, acreage and cause of stress as an additional report as well.
Page 33 of 140

<!-- page 35 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

c) Advisories on pest and disease infestation
Early identification of a crop disease or pest can lead to faster interventions with resulting reduced impacts
on food supply chains. Selected SI should develop algorithms for pest and diseases symptoms
identification which is integrated with mobile applications. The mobile application will provide advisories
to farmers in order to prevent the possible outbreak especially an epidemic situation. Also, bidder should
submit an additional report to agriculture department which should include the disease/ pests in area,
extent of damage. Pest & disease spread analysis should be done by satellite data and it should be
supported by the field survey.
d) Advisories on soil moisture stress and Irrigation Application
Sufficient levels of soil moisture are essential for optimum plant growth and high crop yields. To determine
the quantity of moisture in the soil is crucial importance for crop production to avoid water stress, but also
for the mitigation of adverse environmental impacts due to over-irrigation as well as for the conservation
of water resources. Thus, selected bidder should develop an indirect method for estimating soil moisture
data where soil data, remotely sensed data like microwave data can be utilized.
Derived soil moisture should be used to provide personalized irrigation advisory to farmers to advice on
irrigation requirement and application. Selected SI should to also provide additional reports and maps to
department on estimated soil moisture and irrigation requirement at village level.
e) Advisories on weather pattern
Selected SI should provide analysis with past and current weather data and forecast the weather pattern.
Selected SI should analyse the inputs/ dataset on weather situation provided by the department and
generate forecast and advisory accordingly.

12.4.5. Integration with Farmer Registration Module and allied services
The selected System Integrator must provide seamless integration with the satellite imagery verification
system, the Farmer Database for the Paddy Procurement Module shall be developed exclusively from the
AgriStack Farmer Registry. The Farmer Registration Module serves as the foundational data layer of the
entire Agriculture Platform. Every service advisory delivery, subsidy targeting, crop insurance, MSP
procurement validation, and disaster compensation is anchored to a verified farmer identity and land
parcel record. This module shall establish and maintain a comprehensive, de-duplicated, and constantly
updated digital registry of farmers in Chhattisgarh.
The module shall be fully aligned with the National Farmer Registry (NFR) schema under the AgriStack
initiative of the Ministry of Agriculture & Farmers Welfare and shall map to a Unified Farmer ID (UFID) for
every registered farmer. Some of the indicative functional requirements are as follows (but not limited to):
a) Capture of complete farmer demographic data i.e. name, gender, category mobile number,
category (SC/ST/OBC/General if applicable), Aadhaar number, bank account details etc.
b) Linkage with Aadhaar e-KYC/ AgriStack records for identity de-duplication
c) Digital capture of all land parcels (Khasra) associated with a farmer, linked to Land Records
Management System as per AgriStack (LRMS / Bhuiyan portal)
d) Geo-spatial mapping of individual farm parcels boundary walk-in via GPS on mobile app, or
polygon import from cadastral.
e) Recording of land attributes: survey number, area (in hectares), ownership type (own / leased /
shared), soil type etc.
f) Historical crop record maintenance with cumulative season-wise data per parcel
g) Application and approval workflow for scheme enrollment via web portal and mobile app.
Page 34 of 140

<!-- page 36 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

h) Co-ordination with all the relevant department for all active Chhattisgarh schemes mapped to
state/ national Schemes Registry
i) Mapping of each farmer to their respective Cooperative committee / procurement committee
j) Bank details shall be mandatory for benefit payment eligibility which will be fetched from CCB
module
k) All new registrations and modifications shall require Aadhaar based e-verification
l) Duplicate account linkage across multiple farmers shall be restricted or flagged
m) Mapping of each farmer to their respective relevant administrative unit (Village/Tehsil / District)
etc.

12.5.

Paddy Procurement Module:

SI shall be responsible to undertake the study, design, development, implementation, execution,
migration, operation, and maintenance of an integrated system/application focused on Paddy
Procurement module. The selected system Integrator must provide but not limited to:a) The module shall serve as a unified interface for onboarding farmers, tracking procurement, and
managing society-level activities, enabling the Department, other cross functional department
and the Director Land Records to monitor institutional agricultural support delivery across the
state
b) Digital onboarding of all types of primary agricultural societies PACS
c) Farmer-level membership enrollment linked to Unified Farmer ID (UFID) etc.
d) Tracking of membership additions, exits, and transfers across societies
e) Integration with CCB (Cooperative Credit Bank) module for seamless loan disbursement and
recovery workflows
f) Management of fertilizer, seed, and pesticide distribution by society to registered member farmers
g) MSP procurement support linking society-level procurement operations with satellite-derived
crop maps for area.
Department officials at all required levels shall have access to society-level performance dashboards
showing member count, active borrowers, loan portfolio, input distribution volume, and procurement
activity.
The SI shall also ensure that the designed solution is highly dynamic, configurable, and
administrator-friendly, incorporating low-code/no-code capabilities such as drag-and-drop configuration
tools. Authorized officials shall be able to enable, disable, or modify specific services, business rules,
workflows, user roles, deduction logic, approval chains, and reports without requiring code-level changes.
This dynamically configurable framework shall support faster rollout of policy changes, seasonal updates,
and operational adjustments.
All modules and architectural components delivered by the SI shall maintain strict standards of security,
privacy, auditability, performance, and compliance. The SI shall provide end-to-end documentation, APIs,
dashboards, training, and operational support required for the smooth functioning and long-term
sustainability of the system.

12.5.1. Mobile App for digital tokens
The mobile application shall serve as an accessible and user-friendly platform enabling farmers to
seamlessly participate in the digital procurement ecosystem. Through the mobile app, farmers shall be
able to securely register themselves by providing essential personal details and Aadhaar-based
Page 35 of 140

<!-- page 37 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

verification. Once registered, the farmer shall be able to view the list of assigned Procurement Centers
(PCs) based on jurisdiction, availability, and operational schedules. The application shall allow farmers to
generate digital procurement tokens for selling their paddy at the designated Procurement Center,
ensuring systematic crowd management, avoiding long queues, and enabling transparent and fair
allocation of procurement slots. The token shall include details such as date, time, PC location, allowable
quantity, for use at the procurement center. The system shall sync in real time with the central portal,
ensuring accurate data flow, improved planning, and efficient procurement operations.

12.5.2. Block Chain
The Selected System Integrator (SI) shall undertake a comprehensive review of the existing Paddy
Procurement processes, understand the functional, technical, and operational requirements of all
stakeholders, and conduct detailed system studies to map current workflows and data flows. Based on this
assessment, the SI shall design, develop, and implement microservice-based, scalable, and modular
system architecture for the above-mentioned modules, capable of supporting a minimum of 8,000
concurrent users at any given point of time without degradation of performance. Portal shall leverage
Blockchain technology to ensure end to end transparency, traceability, security, and immutability of
transactions throughout the procurement lifecycle. The SI shall further ensure seamless integration of the
proposed system with relevant departmental databases and external systems to enable real time data
exchange, automated verification, and comprehensive reporting. The scope shall also include
development, testing, deployment, user training, preparation of technical and user documentation, and
ongoing technical support to ensure smooth adoption, secure operations, and effective functioning of the
portal.

12.5.3. Reports Requirement
The department may require a comprehensive set of daily and periodic reports on paddy procurement or
farmer registration to ensure effective monitoring, transparency, and operational control. The reports
mentioned are indicative in nature, and the department may seek any additional or specific reports as
required from time to time based on operational, administrative, or policy needs. These may include daily
procurement reports capturing center-wise quantities procured and farmer participation, periodic
progress reports summarizing cumulative procurement against targets, stock and storage status reports
reflecting availability and movement, farmer payment and MSP disbursement reports to ensure timely
and accurate payments, transportation and delivery reports tracking movement to mills or godowns, and
reconciliation reports aligning physical stocks with records. Collectively, such reports enable the
department to assess procurement performance, promptly address operational gaps, safeguard farmer
interests, and support informed decision-making throughout the procurement season.

12.6.

Database Management

Selected SI should procure satellite imageries specified in the tender document, analysed with different
techniques for the scope of work narrated in the document. For on-going data analysis during the season
data processing shall be done on cloud servers by the selected SI and after the completion of each season/
year (whichever is feasible) all the generated data shall be deployed / stored at Chhattisgarh State Data
Centre (CGSDC) server along with security certificate and credentials. Data can be archived post 180 days.
All raw and processed data should be available as per the department norms or instructions or as per
departments requirement.

Page 36 of 140

<!-- page 38 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

12.7.

Establishment of Data Analytics Center (Command and Control Unit)

12.7.1. Facilities
12.7.1.1. Design Considerations:
1. The project includes designing, engineering, supply & installation of Project Operations & Data
Analytics Centre (DAC) and other office set up pertaining to the center.
2. Satisfactory environmental conditions for operator personnel - including noise, air flow, temperature
and humidity should be ensured. Adequate space for personnel and equipment for the movements and
activities they are required to perform during operation and maintenance, under both normal and
emergency conditions.
3. In broad, the scope of work and supply shall consist of the following parts:
a) Interior design, engineering for the operation center.
b) All related services for supply, installation, testing.
c) Maintenance and warranty throughout project duration
4. General Considerations
a) The tentative control room area shall be approximate 2000 square feet, and within this area the
control room (provisioned for 30 personnel), conference room (provisioned for 20 personnel),
team room, waiting area, and 2 offices for project in-charge officials will have to be constructed.
This will include raised flooring, carpeting, glass wall, video wall, false ceiling, electrical cabling,
network cabling, minor civil works to create partitions for offices and remove existing
partitions/walls, if any, based on acceptable civil engineering practices, provisioning of all
furniture, installation of furniture, non-IT and IT infrastructure.
b) Selected SI shall be responsible for safety and security of the installed item still commissioning
and final acceptance by selected SI or committee appointed by selected bidder.
c) Quality assurance & commissioning of the complete system at site to the complete satisfaction
of the selected SI or committee appointed by selected bidder.
5. Ergonomic Design: DAC site should be ergonomically designed and should follow Control Centre
Ergonomics Standards and other applicable standards.
6. Cabling at Site: Entire cabling at DAC shall be rat protective and insulated. The selected bidder shall
ensure that proper earthing and cooling requirements are met at control center during the contract
period.
7. Network Connectivity: The DAC shall have dedicated connectivity for display/monitoring of agriculture
insights and also have provision to interface with external systems such as weather stations, news
feeds. The selected SI should also provision for redundant internet connectivity for failover situations.
The expenses related to band width/lease line for internet connectivity shall be borne by department.
8. Physical Security at DAC: Physical security at Data Analytics Centre shall be maintained using access
control device / biometric based authentication. The entire physical security system will be set up based
on user authentication and room wise security provisions.
9. The Data Analytics Centre should be equipped with relevant signage. The signage should be easy to
read and highlighted in case of any disaster to guide control room staff to safety.

Page 37 of 140

<!-- page 39 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

12.7.2. Overview of Requirements: (But not limited to)
S.
No.

Particular

1

Control Room or
Data
Analytics
Center

2

Conference Room
(With
glass
panels
facing
operations
control rooms)
In-Charge
Officials
Room
(Cabin)

3

Approx.
Dimensions
(in feet)
50 X 20

20 X 20

10 X 10

Seating
Scope Inclusions
Capacity
(But not limited to)
(Persons)
30
Civil Works, Raised Floor, False Ceiling, Electrical
and Network Cabling, Video wall setup,
Furniture Setup, Non-IT infrastructure set-up, IT
infrastructure and systems set-up
20
Civil Works, False Ceiling, Electrical and Network
Cabling, Video Screens setup, Furniture Setup,
Non-IT infrastructure set-up, IT infrastructure
and systems setup
1+4

Civil Works, False Ceiling, Electrical and Network
Cabling, Furniture Setup, Non-IT infrastructure
set-up, IT infrastructure and systems set-up

12.7.3. Data Analysis Center (But not limited to)
S.
No.
1
2
3
4
5
6
7
8
9
10
11

Particular

Quantity

Workstations
(Minimum specifications are mentioned as per Annexure)
Multi-Function Printer (Heavy Duty) color
Indoor Wi-Fi Access Points
Video Wall
(Minimum specifications are mentioned as per Annexure)
Network based Video Wall Controller
Video Wall Monitoring Software
Managed Switch
NVR based cameras
Fire Panels
Furniture, Cooling, Electrical and Networking Cabling (Quantity based
on number of personnel occupying the room)
UPS with Minimum 05 hours back

30
01
05
01
01
01
02
06
02
30
01

12.7.4. Conference Room:
S. No.
1
2
3
4
5

Particular
Workstations
(Minimum specifications are mentioned as per Annexure)
Indoor Wi-Fi Access Points
Video Screen
Furniture, Cooling, Electrical and Networking Cabling (Quantity based
on number of personnel occupying the room)
Video conference solution license with 50 concurrent users

Quantity
01
05
02
20
01

Page 38 of 140

<!-- page 40 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

12.7.5. In-Charge Officials Rooms:
S. No.
1
2
3

Particular
Desktop
Color Laser Printer
Furniture, Cooling, Electrical and Networking Cabling (Quantity
based on number of personnel occupying the room – include 4
visitors)
Video Screen (56 inches)

4

12.8.

Quantity
02
02
02
02

Data Analytics Centre (DAC)

1. The selected SI shall be responsible for the Integrated Data Analytics Centre (DAC). This facility will
function as the central data hub for the Unified Platform for Agriculture and Holistic Assessment
with Records (UPAHAR), enabling real-time agricultural monitoring, advanced data analytics,
visualization, and coordination across the Chhattisgarh.
2. The DAC shall provide a unified platform to visualize and manage multi-source data streams,
including GIS/Geospatial, remote sensing outputs, drone-based observations, crop cutting
estimation, yield estimation, parcel wise crop, crop insights, and ground survey information. It
must also enable seamless communication with field teams and the Department of Agriculture or
as per requirement of government of Chhattisgarh.
3. The DAC will function as a knowledge hub for policy formulation, analysis, performance
monitoring, and proactive interventions, supporting features like predictive analytics for crop
yields, disaster impact assessments, and customized dashboards. It must handle high-volume data
processing (e.g., analytical dashboard, queries-based analysis etc.) with minimum 97% uptime,
real-time data ingestion, and AI/ML-driven insights, while facilitating seamless communication via
APIs and role-based access. Additionally, the DAC shall house a dedicated helpdesk team of
executives stationed on-site to assist farmers through tele consultations, query resolution, and
advisory support, enhancing farmer outreach and engagement and other management enabled
by with the help of help desk software.

12.8.1. Functional Requirements
1. The DAC shall support the following core functionalities, drawing from multi-source data
aggregation and analytics, with extended support for helpdesk operations:
2. Data Ingestion and Management: Real-time/batch ingestion from UPAHAR modules (e.g., satellite
data, ground truthing etc.) and external sources. Perform data cleaning, transformation, and
enrichment using automated pipelines, with metadata catalogs for searchability.
3. Advanced Analytics and AI/ML: Develop models for predictive tasks (e.g., drought risk
assessment, crop loss prediction etc.) using time-series analysis, machine learning algorithms
(e.g., regression, clustering), and anomaly detection. Enable ad-hoc querying, statistical testing,
and scenario simulations for policy insights.
4. Visualization and Dashboards: Create interactive, role-based dashboards (e.g., executive
summaries for officials, operational views for field staff) with charts, heatmaps, GIS overlays, and
drill-down capabilities. Support real-time alerts for events like flood risks or pest outbreaks.

Page 39 of 140

<!-- page 41 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

5. Reporting and Decision Support: Generate automated reports (e.g., fortnightly crop health
summaries, annual production forecasts) with export options (PDF, CSV, .xlsx etc.). Include a
Decision Support System (DSS) for what-if analysis, predictions and recommendations.
6. Collaboration and Communication: Facilitate secure data sharing, video conferencing, and task
assignment for field teams. Integrate with web/mobile apps for push notifications and feedback
loops. For helpdesk executives, enable tele consultations via integrated video/audio tools,
allowing them to assist farmers with queries on crop advisories, loss assessments, or platform
usage in real-time.
7. Monitoring and Optimization: Track system performance KPIs (e.g., query response time <5
seconds, data accuracy >95%) and provide optimization tools for resource scaling.

12.8.2. Core Responsibilities of the System Integrator for DAC (but not limited to)
The SI shall establish a statkae-of-the-art Data Analytics Centre (DAC), the key components of the
Command Centre will be as follows:
a. Design of Data Analytics Centre (DAC) and related Civil Work
b. Video Walls
c. Operator workstations
d. Design/establish DAC and required storage infrastructure in the same premises for meeting DLR
data needs and solution needs
e. Procure and deploy the required software solutions like Video Management System (VMS) and
other required software at its own cost for successful functioning of DAC
f. Design and establish all information security measures/systems including Physical, Network,
Information security aspects to safeguard the infrastructure, applications and data
g. Establish a Disaster Recovery Center hosted by using Meghraj, GoI cloud with prior approval from
DLR or nominated representative by DLR/PMC
h. Develop standard operating procedures (SOPs) and SLAs for all procedures related to operating
various applications, devices and business processes related to successful functioning of DAC.
i. Conduct a need assessment and design the DAC architecture, including hardware/software sizing
and integration plans.
j. Procure, install, and configure all components, ensuring compatibility with existing systems, if any,
including set up for the helpdesk executives' infrastructure.
k. Migrate historical data and validate data integrity.
l. Ensure inclusivity (e.g., multi-lingual interfaces, accessibility for low-bandwidth areas).
m. Manage risks (e.g., data silos via governance policies) and provide scalability for future expansions.
n. Design, Supply, Installation testing and commissioning of IT Infrastructure including site
preparation of DAC, DR center.
o. Establishment of LAN and WAN connectivity at DAC, and connectivity of field devices and solutions
with DAC.
p. Integration Services as per the scope documented in the RFP.
q. Should have provision for Data Analytics Centre (DAC) over a Mobile platform. SI should provision
for Mobile Client application. Number of Mobile users accessing the DAC application will be
provided during requirement phase.
r. All the hardware and software issues will be the responsibility of SI.
s. Networking & Security Infrastructure and other associated IT Components.
t. 24x 7 monitoring and management services and technical support.

Page 40 of 140

<!-- page 42 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

u. Procurement and supply of all the IT Infrastructure components such as Servers, Databases,
System Software, Networking & Security components, Storage Solution, Software and other IT
components required for the DAC.
v. No Products supplied under this bid shall be nearing their date of “end of life”.
w. Procurement and supply of requisite licenses, Installation and implementation (including
configuration /customization and Testing) of proposed DAC.
x. All documentation generated inclusive of IT architecture, functional specifications, design and
user manuals of the IT solution and documentation of non-IT components during design,
installation and commissioning phase shall always be submitted and approved by DLR.
y. Standard business process management framework shall be followed for workflow
management with capabilities of configurability at user level in consultation and approval form
DLR.
z. Shall also provide chatting tool/software for communication.
aa. Shall provide system integration services to customize and integrate the applications provided and
also integrate with existing application installed in other agencies. The DAC application proposed
by the SI shall have open API and API management and shall be able to integrate and fetch the
data from other third-party systems already available or coming up in the near future in
consultation and approval by DLR.
bb. As part of preparing the final bill of material for the physical hardware, the successful bidder will
be required to list all passive & active components required in the command-and-control center
and get it approved by the DLR.
cc. All IT equipment models offered shall be latest released with bundled version update and not
nearing end of life.
dd. Assessment of the business requirements and IT Solution requirements for the DAC.
ee. Design and build the solution of DAC as per the design considerations.
ff. Plan for development, configuration and customization of software products.
gg. The above are only indicative requirements of IT & Non-IT Infrastructure requirements at DAC.
The exact quantity and requirement shall be proposed as part of the technical proposal of the SI.
hh. The SI shall prepare the overall Command and Control Centre Operational plan for this project.
The plan shall comprise of deployment of all the equipment required under the project. The
implementation roll-out plan for setting up the Data Analytics Centre (DAC) shall be approved by
DLR. The detailed plan shall also be comprising of the scalability, expandability and security under
this project.
ii. The SI is required to size and provide IT infra to meet the project functional requirements and
Service Level Agreements (SLAs).
jj. The SI shall be required to submit a detailed installation report and have it approved by DLR before
proceeding and installation as per approved design.
kk. Post installation of all the equipment at approved locations. The report shall be utilized during the
acceptance testing period of the project to verify the actual quantity of the equipment supplied
and commissioned under the project.
ll. After completion of installation, SI shall submit a detail report and take approval from the DLR.

12.8.3. Geospatial Infrastructure Layer (GIS Server + OGC Services)
1. DAC must include a dedicated GIS Server Stack supporting OGC services (WMS/WFS/WCS) for all
Remote Sensing (RS) outputs.
2. DAC shall maintain a geospatial metadata catalog (CSW) with lineage, accuracy metrics, and
dataset versioning.
3. Real-Time GIS Layer Pipeline (Remote Sensing - Processing - DAC)
Page 41 of 140

<!-- page 43 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

4. DAC must host automated pipelines for ingestion and transformation of RS layers, including
Satellite mosaic updates, Index roasters (NDVI/EVI/SAVI/NDWI), Flood, drought, crop-stress
masks, Crop classification layers and Acreage geospatial layers.

12.8.4. Integration with Web-GIS Portal
1. DAC must integrate with the Web-GIS platform so that all analytical results (classification, acreage,
health, flood, drought, yield) appear as map layers in dashboards.
2. DAC must expose APIs for GIS viewers (Web + Mobile) to fetch: Layers, Legends, Map tiles, and
Filtered parcel-statistics

12.8.5. Spatial Indexing, Tiling & High-Performance Map Rendering
1. DAC must perform tiling, caching, and spatial indexing for fast rendering of high-volume RS
datasets.
2. Must support 5-second max response time for map layer queries during peak load

12.8.6. Digital Web Platform
1. The System Integrator (SI) shall be responsible for the end-to-end development, deployment, and
maintenance including integration with state level available applications of a comprehensive webbased platform as a core component of the solution as per the MeitY guideline.
2. The System Integrator (SI) will be responsible for the end-to-end development, deployment, and
maintenance including integration with state level available applications of a comprehensive webbased platform as a core component of the solution, adhering to the following key features and
requirements (but not to limited):
3. Secure, multi-level authentication for all users.
4. Role-based dashboards tailored to individual stakeholder needs (e.g., farmers can access crop
calendars, subsidy application statuses, etc.).
5. The web portal and mobile applications must be hosted on a MeitY - empaneled cloud service
provider to support ongoing data processing.
6. Pre-filled forms should be available by fetching beneficiary data from the database.
7. Strong authentication and security features, with rights and privileges managed through an
Integrated Management Solution.
8. Support for HTTPS protocol (SSL) and comprehensive audit trails.
9. No concurrent sessions allowed for the same user.
10. Preference for development using open-source technologies.
11. Support for all major browsers (Internet Explorer, Chrome, Firefox) and both Android and iOS
mobile operating systems.
12. Multi-lingual capabilities (Hindi, English and Chhattisgarhi).
13. Interoperability with industry-standard databases.
14. Support for web services/APIs and integration with common business applications/ with state
level available applications as per requirement of departments.
15. Integration with standard email and instant messaging services.
16. Compatibility with other platform components via open standards.
17. Support for virtualization, encryption and compression.
18. Integrated workflow management system for all departmental activities.
19. Advanced search engine with full-text search capabilities.
20. Department officials can upload reports in specified formats.
21. Facilities for storing, tracking, and monitoring data at various administrative levels.
Page 42 of 140

<!-- page 44 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

22. Field officer can report pest or disease incidences and record at the village level using provided
formats.
23. District/Block/Tehsil Officers can view aggregated pest and disease information and make strategic
decisions at the district level.
24. Facility to record disaster events and crop damage, including estimation data, evidence, and audit
records.
25. Capability to estimate and record crop production losses for each crop.
26. Visualization of potential threat areas, vulnerability profiles, and occurrence frequencies for
natural calamities.
27. Database backups must be maintained throughout the project duration and maintenance period.
28. The platform must include an integrated Web-GIS Map Viewer supporting OGC standards: WMS,
WFS, WCS for all geospatial layers (crop classification, acreage, crop health, flood/drought, yield,
GT points, UAV/VHR layers) and CSW Metadata Catalog for dataset discovery, lineage, sensor info,
dates, and accuracy metadata.
29. The Web Platform must provide: Time-slider to view NDVI/EVI time-series, flood pre/post maps,
and crop growth stages, Side-by-side (“swipe”/comparison) tool for multi-date imagery analysis,
Parcel-level query tools: click a parcel - show crop, acreage, stress, yield, advisory history and Layer
filtering (season, crop, date, district/block/village, severity).
30. The web platform must fetch analytics output from DAC APIs: Crop classification layers, Acreage
summaries, Crop health/stress rasters, Flood/drought masks and Advisories (geo-linked)
31. Geospatial Search & Administrative Navigation: Search by parcel ID, village, block, district, crop,
incident type and Map navigation synced with analytical dashboards.
32. For all advisories, crop-loss assessments yield estimates the platform must allow “View on Map”
linking the record to its source GIS layers (raster/vector).
33. Real-Time Map Performance & Caching: Spatial indexing & caching for handling large RS imagery
datasets and Target map response time: <5 seconds under peak load.
34. Secure, multi-level authentication for all users

12.8.7. Mobile Platform
The Mobile Platform is an integral component of the solution. The Mobile Application should
meet the following key specifications (but not limited to):
1. Provide an intuitive, user-friendly graphical interface (GUI) that allows users to navigate and
perform actions effortlessly.
2. Ensure the GUI is highly responsive, with minimal or no delays during launch or while navigating
between screens.
3. Include pre-filled data and forms for user convenience based on user credential.
4. Ensure compatibility with both Android and iOS platforms.
5. Incorporate analytics to monitor and improve user experience patterns.
6. Optimize memory usage.
7. Implement strict authentication, privacy, and security measures.
8. Enable fast page loading and refreshing.
9. Offer real-time GPS information capture.
10. Allow easy configuration and modification of existing GUIs and support the addition of new
screens.
11. Design screens to be resolution-independent for consistent display across devices.
12. Facility to register farm boundaries through GIS map tools where Farmer can digitize the farm
boundaries by walk or draw a polygon on the high-resolution satellite image.
Page 43 of 140

<!-- page 45 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

13. Facility to record cropping season, crop details and irrigation facility details of each survey number.
14. Provide contextual crop advisories to individual farmers based on the crop type and phenological
stage of the crop sown.
15. Have option to view and analyze the optimum sowing date based on the weather data.
16. To generate Crop Activity Calendar for the entire crop lifecycle automatically based on the sowing
date input from farmer registration.
17. To provide Irrigation management advisories based on the WRD data, Crop data, Soil data and
rainfall data.
18. Should be providing advisory on best possible time for harvesting based on the forecasted weather
and crop calendar so the farmer can plan the activity well in advance.
19. Backend platform of the mobile app should have the capability to predict pest and diseases using
crop models and should provide controls advisories as preventive action.
20. Backend platform of the mobile app should have the capability to predict the expected harvesting
date for each crop based on the sowing date and varying weather parameters in season.
21. To disseminate disaster forecast, context specific damage mitigation advisory to respective
farmers based on the age and stage of the crop.
22. The mobile app shall support offline map tiles and cached parcel boundaries for low-network or
no-network geographies, enabling uninterrupted field data collection.
23. The app must contain a lightweight GIS viewer to display parcel maps, crop layers, flood masks,
NDVI/EVI rasters, and advisory zones pulled from backend OGC services.
24. All field observations, photos, pest/disease reports, and damage records must be geo-tagged, and
farmer advisories must be geo-fenced to the farmer’s parcel boundaries.
25. All mobile-captured data (GT, losses, pest/disease, field inspections) must immediately sync with:
DAC (analytics engine) and Web-GIS (parcel-level visualization)
26. The app must support GNSS/GPS-based farm boundary capture, with accuracy checks and
topology cleaning.
27. Field officers/farmers must upload: Geotagged photos, Short video evidence, and Notes linked to
parcel polygons. All mapped to Web-GIS for audit and validation.

12.8.7.1. Mobile Application
The System Integrator (SI) shall be responsible for the design, development, deployment, and
maintenance of a robust mobile application to enable field-level data capture, monitoring, and
interaction with the core system as well as the farmer mobile application. The features (but not
limited to) of the farmer mobile application are outlined below:
1. Enable farmers to zoom, pin location and view the farm boundaries using GIS mapping tools for
indicative eligibility of Scheme Benefits/MSP benefits. Boundaries can be digitized either by
walking the perimeter or by drawing polygons on high-resolution satellite imagery. Allow farmers
to view and verify cropping season details, crop type, and irrigation facilities for each survey
number. Also enabling farmers’ to raise grievances in case of any discrepancies.
2. Deliver personalized crop advisories based on crop type and its phenological stage.
3. Provide insights into optimal sowing dates using historical and forecasted weather data.
4. Generate a crop lifecycle calendar automatically based on the sowing date entered during farmer
registration.
5. Advise farmers on the best possible time for harvesting based on weather forecasts and crop
calendar to enable proactive planning.

Page 44 of 140

<!-- page 46 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

6. Backend system should predict potential pest and disease outbreaks using crop models and
provide preventive control advisories.
7. Estimate expected harvest dates for each crop based on sowing date and in-season weather
variations.
8. Disseminate disaster alerts and context-specific damage mitigation advisories tailored to the
crop’s age and growth stage.
9. Farmers should be able to see their parcel polygon, crop type, crop health status, rainfall
deviations, advisory layers, and flood/drought alerts on a GIS map within the app.
10. All advisories (crop health, drought, flood, pest, nutrient) must be linked to the farmer’s parcel
geometry through Web-GIS API.
11. Farmer-submitted crop information must be validated using satellite-derived classification & NDVI
returned by the backend system

12.9.

Integrations

13. The system should be equipped for secure and seamless API-level integration with key
government platforms to enable real-time data exchange and enhanced functionality. Some of the
key integrations include (but not limited to):
i.
Land Records Management Systems – For accessing land parcel details and ownership for
field validation and beneficiary mapping.
ii.
Soil Health Card Database – To fetch soil parameters and support personalized crop and
nutrient advisories.
iii.
Agriculture market data – To provide market-related data such as mandi prices and
arrivals for farmer decision support.
iv.
Weather data: To integrate weather data into AgriStack ecosystem for better analysis and
decision-making.
v.
Other Platform Integration – To provide the integration functionality if state government
department based on requirement.
vi.
Integration with Food Department and Markfed : - The application/module/system shall
integrate various existing and upcoming systems, applications, and databases. It should
have an adaptable architecture capable of supporting evolving business needs and
end-user requirements.
vii.
AgriStack Integration and Implementation Module - To align with the digital public
infrastructure goals under the AgriStack initiative launched by the Ministry of Agriculture
& Farmers Welfare, Government of India, the proposed solution must support integration
with the federated data architecture, registries, and APIs prescribed under the AgriStack
framework. The module shall ensure Chhattisgarh’s seamless onboarding onto the
national AgriStack ecosystem and enable data exchange for enhanced service delivery,
transparency, and interoperability.
viii.
Any other state/department level or central level portal integration - The application
shall integrate various existing and upcoming systems, applications, and databases. It shall
have an adaptable architecture capable of supporting evolving business needs and
end-user requirements.
ix.
At the time of requirement discovery and gathering, there may be requirements of more
integrations. The SI shall be responsible for integrating all the systems/ softwares/ portals/
tools etc. as per the requirements.
x.
Integration with Web-GIS and OGC Services- The system must integrate with the UPAHAR
Web-GIS platform using OGC-compliant services (WMS/WFS/WCS) to fetch and publish
Page 45 of 140

<!-- page 47 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

xi.

xii.
xiii.
xiv.
xv.
xvi.

geospatial layers such as classification maps, acreage layers, crop health indices,
flood/drought masks, UAV/VHR outputs and yield rasters.
Integration with DAC for Geospatial Analytics- The integration layer shall support
bi-directional exchange between the Data Analytics Centre (DAC) and the Web-GIS system
to synchronize map layers, dashboard data, and analytics outputs (NDVI/EVI time-series,
stress layers, flood detection).
Integration of UAV/VHR/SAR Data Pipelines- The solution must support ingestion and
integration of drone, VHR, and SAR-based geospatial datasets into the GIS engine and DAC
workflows for crop-loss assessment, flood mapping, and field verification.
API-First Spatial Querying (Parcel/Village/Block)- The SI shall expose REST/JSON APIs
enabling external systems to retrieve parcel-level and village-level geospatial outputs
(crop ID, acreage, stress, yield, flood/drought, advisories).
Integration with Disaster Management Systems- The platform must integrate with
disaster management authorities to exchange flood maps, drought/stress layers, crop
damage assessments, and UAV evidence maps in near-real time.
Farmer/Extension Mobile App-GIS Integration- All mobile-captured data (pest/disease
reports, crop condition photos, GT points, boundary corrections) must integrate with GIS
backend layers in real time.
Integration with Central Agri Geo-Portals - The system should be capable of consuming
external RS-based products such as NDVI composites, rainfall/soil moisture maps, crop
watch layers etc.

Note: The above-mentioned integration points are suggestive and indicative only and may be expanded,
modified, or reduced during the project lifecycle based on functional, technical, or departmental
requirements.

12.10.

Post Award of work to Selected bidder

Following are the activities, documentation but not limited to, the selected bidder needs to undertake
before starting the implementation plan. Submit survey reports, design, layouts, (in both AutoCAD &
pdf), SLDs and other related documentation within given time schedule with complete required details
such that the related information shall covered in total and maximum revisions shall not cross more
than three (03) times for each document:

12.10.1.

Preparation of Inception Report

The SI needs to prepare and submit an Inception Report of the project, which will serve as the foundation
document for all the activities related to the project. Additionally, the Inception Report must cover the
risks that SI anticipates and the plans they propose towards Risk mitigation. Major roles and
responsibilities of the project team along with support arrangements that are expected from the
Department, other Department and stakeholders will be an essential part of the inception report. The SI
will also describe the Project Team with individual roles and responsibilities in the Inception Report. The
acceptance of the Inception Report by Department/authorized Project implementation committee is
necessary before proceeding to the next stage of the project.

12.10.2.

Deployment of Resources

SI shall deploy a full-time Project Manager and adequate competent team for the entire duration of project
at Department HO at Raipur and at other related organizations (i.e., MarkFed, Department of Land Records
Page 46 of 140

<!-- page 48 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

etc.). SI shall share profile/CV of proposed personnel with Department before deployment. Project
Manager shall be overall responsible for all the project implementation activities and coordination with
the PMU of other Stakeholders. Department may ask for replacement if the profile of Project
Manager/Other resources is not found suitable after signing of contract agreement. The deployment of
resources at all three HOD’s shall be finalized by Department/ Project implementation committee
nominated by the department.

12.10.3.

Preparation of Detailed Project Plan

The SI shall prepare and submit an Integrated Project Plan along with bid document for the entire project
that covers detailed tasks with work breakdown structure which are intended to be performed, as part of
the project.
The SI shall conduct requirements gathering exercise and prepare a Functional Requirement Specification
(FRS) with process maps, Software Requirement Specifications (SRS) document, for which the SI shall have
a comprehensive discussion with all stakeholders, and other stakeholders related with this project to
ensure that each of the requirements mentioned in this scope of work or identified during study is
covered.
Activities conducted as part of this task will result in the project deliverable FRS/SRS document, which shall
detail the requirements of the complete solution up to the last detail. The FRS/SRS document shall comply
with the latest and applicable standards.

12.10.4.

Design of System Architecture

The selected SI must review the current processes of the system and after conducting a comprehensive
analysis of the requirements for the Project, the system integrator will prepare system architecture and
design documents and submit the solution design along with bid document for proposed project. The
Architecture document will give the complete architecture of the proposed systems. The corresponding
architecture will also be identified for customization requirements. The following documents, including,
but not limited to, will be submitted for a sign-off of application architecture and development
methodology:
1.
2.
3.
2.
3.
4.
5.
6.
7.
8.

Application Architecture with all relevant design patterns identified.
All Database structure and detailed description of tables and fields.
Naming conventions followed for the tables and fields.
Data Flow Diagrams (DFD) & Entity-Relationship (ER) diagrams.
Details of validation rules and constraints like Integrity Checks etc. to be applied.
Format of all input screens including data entry requirements.
Format of all reports that would be generated by the system.
Integration with another application through API layer data flow to and from level at centralized
database.
Business logic is used for all reports and functions.
Access control mechanisms, data security and audit trails to ensure that databases are not
tampered or modified by unauthorized users. The following guidelines need to be observed for
security:
a. Build a complete audit trail of all transactions (add, update and delete) using transaction
log reports, so that errors in data, intentional or otherwise, can be traced and reversed.
b. The most appropriate level of security commensurate with the value to that function for
which it is deployed must be chosen.

Page 47 of 140

<!-- page 49 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

9.
10.
11.
12.

13.

14.
15.
16.
17.

18.

c. Access Controls must be provided to ensure that the databases are not tampered or
modified by the system operators.
d. Implement data security to allow for changes in technology and business needs.
Hardware Deployment Architecture, Network Design, Security Architecture etc. for the Project.
Plans for User Acceptance Tests and System Integration Tests including Stress Tests and plans.
Detailed Project Implementation Plan, Operations & Maintenance Plan, component-wise activity
schedule, etc.
The Implementation Plan shall be comprehensive including, but not limited to:
a. Process, methodology, Make, Model, Version of hardware, software etc. to be used in the
Project (exactly as submitted by the Bidder during Technical Evaluation) along with
corresponding documents, user manuals, system administration manual, SOPs, repair and
maintenance manuals, including details of the IA.
b. Software Licenses details for system and other software, proposed application
architecture document.
c. Data modelling document, approach and methodology and plan for master data creation.
d. Detailed description of the technology to be used for each system modules (exactly as
submitted by the Bidder during Technical Evaluation)
e. Training and Capacity Building Material, Content and Plan
f. Detailed timelines for implementation as per defined requirements.
g. SLA and Performance monitoring Plan
h. Exit Management Plan
The Operations and Maintenance Plan shall be comprehensive, including, but not limited to:
a. Resource deployment plan with qualification, experience and Escalation Chart.
b. Operations management plan
c. Repair and Maintenance plan
d. Data Backup Plan
e. Information Security
f. Risk management plan
g. Standard Operating Procedures for various system modules
h. SLA adherence plan
i. Detailed security policy and recommendation updated from time.
The system integrator shall be entirely responsible for the architecture of the system as per the
scope mentioned in this RFP. The system architecture description provided in this document is
for reference only. The System Integrator should ensure all possible and required improvements.
The System architecture shall be designed in such a way that all futuristic requirements of the
department will have minimal impact on the Department system and all-customization
requirement will be incorporated by SI are in the scope of existing project of Department.
The suggested integrated system shall include the functional landscape, phasing options for the
different modules and the API Enabled deployment architecture which should be customized and
configured thereby ensuring interoperability.
The application design will be such as to require minimal installation, if at all, at the user‘s end,
besides the Internet Browser and will be able to support all common browsers (like Internet
Explorer, Mozilla, Google Chrome and mobile based browsers etc.). System Integrator shall also
design the Frontend and Backend portals for the Project.
User involvement will also be ensured during finalization of user interfaces, the mode of data
entry, storage and retrieval, outputs report, queries, and the application design as a whole.

Page 48 of 140

<!-- page 50 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

19. Indicative solution architecture of the envisaged New Proposed system is shown below. The
schematic diagram represents the overall solution architecture of the Project. The SI shall
propose a relevant solution in his proposal that best suits the required functionality.

12.11.

Cloud Hosting Requirement

The SI should provide the cloud platform for “Unified Platform for Agriculture and Holistic Assessment
with Records (UPAHAR)” encompasses the study, design, development, implementation, integration,
testing, deployment, operations, maintenance, and capacity building of an integrated digital ecosystem
for agricultural monitoring, planning, and farmer support in Chhattisgarh. The SI shall leverage advanced
technologies including satellite imagery, remote sensing, GIS, AI/ML, drones, mobile/web applications,
and cloud computing to deliver near real-time insights on crop acreage, health, yield, disasters,
procurement, and advisories. The entire solution must be hosted by a MeitY-empaneled Cloud Service
Provider (CSP) to ensure data sovereignty, security, scalability, and compliance with MeitY guidelines. The
SI shall select and manage a MeitY-empaneled CSP, with all data residing in Indian data centers to comply
with data localization requirements.
The project duration is 5 years (16 weeks for study, design, development and implementation and
remaining period for Operations & Maintenance, or O&M), with phased deliverables. The SI is responsible
for all aspects, including risk mitigation, adherence to standards (e.g., BIS/OGC geospatial, MeitY security),
and integration with systems like Bhuiyan, AgriStack, PMFBY, and MSP portals (but not limited to). Noncompliance may result in penalties as per SLAs/applicability.

12.11.1.

Cloud Hosting Requirements

The SI shall host the UPAHAR solution on a MeitY-empaneled CSP, ensuring high availability (97% uptime),
scalability, and security.
1. CSP Selection and Compliance: Select a CSP empaneled by MeitY. Provide proof of empanelment
and audit status (e.g., STQC certification). Comply with MeitY guidelines on data residency,
prohibiting data storage outside India.
2. Infrastructure Specifications: Provision virtual machines, storage, databases, networking, and
compute resources scalable to handle state-wide data processing. Use encrypted data-at-rest and
in-transit.
3. Security and Compliance: Implement role-based access control (RBAC), audit logging, intrusion
detection, and annual STQC audits. Ensure certifications like ISO 27001/27017/27018 and
compliance with India's IT Act 2000 and DPDP Act 2023.
4. Backup and Disaster Recovery: Automated daily backups with 7-day retention, geo-redundant
storage across at least two Indian regions, and RPO/RTO of <1 hour/<4 hours.
5. Monitoring and Management: Deploy cloud-native tools for real-time monitoring (e.g., resource
utilization, performance metrics) and automated scaling.
6. Deliverables: Cloud architecture diagram, CSP contract details, compliance certificates,
deployment plan, and quarterly audit reports.
7. Responsibilities: SI shall handle procurement, configuration, migration, and costs, if any.

12.12. Help Desk
The help desk service will serve as a single point of contact for all ICT-related incidents and service
requests. The SI will provide a Single Point of Contact (SPOC) and resolution of incidents. The helpdesk
services should include:

Page 49 of 140

<!-- page 51 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

1. SI shall be required to set up centralized Helpdesk for the period of Operation and Maintenance
to provide uninterrupted technological support to all the department provided location. The
helpdesk will serve as a single point of contact for all incidents and service requests for the system,
providing real-time Incident management services.
2. Help Desk facility for reporting issues/problems with the software application.
3. All complaints related to online applications will be handled/resolved/responded within decided
timeline. If not, it will be considered as a down time and penalty will be imposed accordingly.
4. To provide a service desk facility and set up all necessary channels for reporting issues to helpdesk.
The incident reporting channels will be the following:
i.
Single Contact No.
ii.
Specific E-Mail account
iii.
Ticket Portal
5. The Help desk services should be in operation from the date of operationalization of state wise
rollout of the solution.
6. The helpdesk shall have adequate number of manpower resources trained in all the application
operation for technical support to the users.
7. Resolution mechanism should be managed through Ticket Handling System/Module in the SI
scope.
8. SI shall have the capability to guide the application users for the application related issues.
9. Helpdesk executives should also have provision for screen sharing options for remote operational
support.
10. Computers, Printer, telephone connectivity, UPS and other electronic devices needed for helpdesk
support such as LAN networking (Switch and cables), Headphones etc. shall be arranged by SI
itself.
11. The SI shall arrange the telephone system in such a way that multiple calls are handled by the Help
Desk team simultaneously on the given Help line number. All the necessary equipment/ hardware
arrangement will be managed by the SI for the same.
12. The warranty shall cover all materials and workmanship for the complete operational and
maintenance period of 05 years as mentioned in the RFP after delivery of the items, components,
and equipment and after its installation & functioning. During the maintenance period, it is the SI
responsibility to ensure that the manufacturer shall furnish replacements for each failed
component/accessories at no cost to the Department.
13. After completion of O&M phase the SI will hand over all the assets of the support center
(Application, software, Computer, Printer, licenses etc.) and data etc. to Department.
Note: The selected System Integrator shall mandatorily submit a detailed Help Desk escalation matrix,
including roles, responsibilities, and response timelines, along with the bid submission.

12.13. Standards & Interoperability
The proposed solution must ensure full compliance with relevant national and international standards to
facilitate interoperability, data exchange, and long-term sustainability. Specifically:
1. The system shall adhere to applicable standards issued by MeitY, Bureau of Indian Standards (BIS),
and Open Geospatial Consortium (OGC), wherever relevant.
2. Ministry of Electronics and Information Technology (MeitY): including but not limited to the eGovernance Standards, Open API Policy, Cloud Adoption Framework, and Policy on Open-Source
Software.

Page 50 of 140

<!-- page 52 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

3. Bureau of Indian Standards (BIS): compliance with relevant IS codes under the Electronics and IT
Goods (Compulsory Registration) Order, 2012, and subsequent notifications for hardware,
software, and data formats.
4. Open Geospatial Consortium (OGC): adherence to geospatial data standards such as WMS (Web
Map Service), WFS (Web Feature Service), WCS (Web Coverage Service), GML (Geography Markup
Language), and GeoTIFF for spatial data interoperability.
5. All data formats, APIs, and metadata structures must be designed to support open standards,
enabling seamless integration with existing and future government platforms.
6. Preference shall be given to solutions that utilize open-source or equivalent technologies, ensuring
transparency, auditability, and system integrator neutrality.
7. Require all deliverables in standard formats (GeoTIFF, shapefiles, JSON, APIs) to ensure future
migration to other systems is possible.

12.14. API Approach
1. The platform should be based on open API approach as multiple channels like web portal, mobile
applications and other interfaces should access the platform
2. Adaptable architecture should be supported for changing business needs and end user
requirements.
3. It would have integrated various systems, applications, databases already being used or to be built
for future.
4. SI has to set up and maintain systems and processes for following APIs. The authority does not
have any available APIs.
a) Authorization and license key management
b) Standardization
c) Authentication
d) Version Control
e) Environmental management
f) Security Governance
g) Audit Trail

12.14.1.

Post Award of Work to Selected Bidder

1. Overview
After award of work, the selected bidder must prepare and submit key documents required for design,
implementation, and commissioning of the DAC system.
• All documents must be submitted in editable + PDF format.
• Maximum 3 review cycles per document (unless otherwise required).
• Work execution can start only after approval by the Department.
2. Key Deliverables
a. Requirement & Design
1. Requirement & Gap Assessment
a. Site study, stakeholder inputs, existing systems review
b. Identification of integration needs
2. Solution Design Document
a. Overall concept, workflows, modules, user roles
b. Incident management and alerting logic
Page 51 of 140

<!-- page 53 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

3. Architecture Document
a. Application, infrastructure, network, and security architecture
b. Sizing, deployment model (cloud/on-prem), HA/DR
4. Layout & Infrastructure
a. Control Room Layout: Seating, video wall, consoles, server room, cabling
b. AV & Video Wall Design: Display setup, control system, content flow
5. Functional & Integration Design
a. Functional Specification (FSD): Modules like dashboards, workflows, reporting, alerts
b. Integration Plan
1. Systems to integrate (CCTV, GIS, apps, APIs)
2. Data flow and interface details
c. Integration Matrix: Source systems, data types, protocols, responsibilities
6. Technology & Security
a. Network & Cybersecurity Plan
1. Network design, access control, logging, backups
2. Security policies and monitoring
b. Bill of Materials (BOM)
1. Hardware, software, licenses, specifications
7. Execution Planning
a. Project Plan
1. Timeline from start to go-live
2. Milestones and dependencies
8. Configuration & Development Plan
a. Customization approach, dashboards, alerts, workflows
9. Use Cases & SOPs
a. Events, alerts, response workflows, escalation
10. Testing & Go-Live
a. Testing Plan
1. FAT, SIT, UAT, performance & security testing
b. Training & O&M Documents
1. Training plan, manuals, SOPs, support structure
11. Governance
a. Project Monitoring
1. Weekly reviews
2. Progress reports, issue tracking, risk logs

Page 52 of 140

<!-- page 54 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

12. Timelines
S.
Deliverables Type
No.
1.
Requirement Study
2.
Design & Architecture
3.
Layout & AV Design
4.
Functional & Integration Docs
5.
Security, BOM
6.
Project & Development Plan
7.
Testing Plan
8.
Training & Go-Live Docs
9.
Reviews

Timeline
T + 7 days
T + 10–12 days
T + 15 days
T + 18–21 days
T + 21 days
T + 25 days
T + 30 days
T + 35 days
Ongoing

13. Key Conditions
1 Documents must be complete, version-controlled, and clearly structured.
2 Must define:
a. Bidder scope
b. Department responsibilities
c. Dependencies & assumptions
3 Approval is mandatory before execution.

12.15. Testing
Testing should be initiated by the selected SI along with the requirement finalization where test cases and
test plans should be designed simultaneously. The selected SI should submit the test cases and test plan
and it should be approved by the authority. Standard best testing practices should be followed throughout
the testing phase.
Testing should be performed in spring manner and the identified bugs / issues should be resolved in the
respective spring only. The SI should maintain the record of bug / issues with their status, and it should be
submitted to the authority after each testing phase. The SI should perform following testing (but not
limited to):

12.15.1.

Unit Testing

Once the customization and configuration phase is over, each module of the application should be tested
end to end. The selected SI has to demonstrate the system is a controlled production environment where
the data which is being utilized in a multiple module are managed efficiently.

12.15.2. Performance and Load Testing:
The SI would develop performance scenarios of performance conditions of the application which should
be reviewed and approved by the department. The application along with its infrastructure should
successfully meet the criteria for the response time. The SI should gather run analytics to understand
realistic usage and setting up the infrastructure to meet the performance. Selected SI should submit
required reports to the authority.

Page 53 of 140

<!-- page 55 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

12.15.3. User Acceptance Testing (UAT):
The SI should submit UAT test plan and it should be reviewed and approved by the authority. The
application would go for UATs when the test results of unit testing and performance testing are submitted
to the authority. UAT will be performed as per the test plans and the team performing UAT would
categorize the defects in critical, high, medium and low priority. The critical defects identified should be
fixed and retested before go-live whereas 90% of high priority should be fixed before go-live. The medium
and low priorities defects should be fixed within before the go-live.

12.15.4. Security Testing:
The selected SI should perform security testing before hosting the application. In the security testing
should be performed by CERT-in empaneled selected SI. In the security testing, web application, mobile
application, external threat testing, system vulnerabilities etc. should be tested.
The findings of security testing should be resolved, and the certificate should be submitted to the authority
before hosting of the application.
Note: The selected System Integrator shall perform STQC testing for the complete solution. However,
considering the criticality of the project and the defined timelines, the SI shall first obtain CERT-In
certification and host the solution on the cloud. Subsequently, STQC certification shall also be mandatorily
obtained. The entire cost of both CERT-In and STQC certifications shall be borne solely by the SI.

12.15.5.
Type
System Testing

Detailed Types of Testing within the scope of SI
Responsibility
SI

No
1.
2.
3.
4.

Integration
Testing

SI

1.
2.
3.
4.
5

Interoperability
Testing

SI

1

Scope of Work
System testing.
Prepare test plan and test cases and maintain it. DLR
may request the SI to share the test cases and
results.
Shall be performed through manual as well as
automated methods.
Automation testing tools to be provided. DLR doesn’t
intend to own these tools.
Perform Integration testing.
Prepare and share with DLR the Integration test plans
and test cases.
Perform Integration testing as per the approved plan.
Integration testing to be performed through manual as
well as automated methods.
Automation testing tools to be provided DLR doesn’t
intend to own these tools.
Prepare interoperability traceability matrix with third
party systems (existing legacy/being developed
systems with Data Analytics Centre (DAC)) in
consultation with DLR and other relevant stakeholders
(of external systems). Interoperability is an ability of
one system to interact with another system. This
matrix will cover all the use cases of system interaction
Page 54 of 140

<!-- page 56 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

Type

Performance
and
load
Testing

Responsibility

No

SI

2

SI

3

SI

4

SI

5

SI

1

Performance and load testing.

SI

2

Various performance parameters such as transaction
response time, throughput, and page loading time
shall be taken into account.

SI / Third
Party Auditor
(to monitor the
performance
testing)

Security Testing
(including
Penetration
and
Vulnerability
testing)

Scope of Work
and data movement.
Perform Interoperability testing.
Prepare and share with DLR the Interoperable test
plans and test cases with scenarios.
Perform Interoperable testing as per the approved
plan.
Interoperability testing all the functions / components
will be tested of a particular third party system
which is integrated with DAC.

Load and stress testing of the ICCC and other field
equipment Components

SI

3

SI

4

SI

5

SI

6

SI

1

SI / Third Party
Auditor to
monitor the
security
testing)

2

SI

3

SI

4

System to be performed on business transaction
volume
Test cases and test results to be shared with DLR.
Performance testing to be carried out in the exact
same architecture that would be set up for production.
Use performance and load testing tool for testing. DLR
doesn’t intend to own these tools.
DLR, if required, could ask SI to appoint third party
auditors to monitor/validate the performance
testing. Cost for such audits to be paid by SI.
The solution shall demonstrate the compliance
with security requirements as mentioned in the Bid
document including but not limited to security
controls in the application, at the network layer,
network, data Centre(s), security monitoring system
deployed by the SI.
The solution shall pass vulnerability and
penetration testing. The solution shall pass web
application security testing for the portal, mobile app
and other systems and Security configuration review
of the infrastructure if applicable.
SI shall carry out security and vulnerability testing on
the developed solution.
Security testing to be carried out in the exact same
environment/architecture that would be set up for
production.
Page 55 of 140

<!-- page 57 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

Type
User
Acceptance
Testing (UAT)

Responsibility

No

Scope of Work

SI/appointed
third party
auditor

1

SI

2

SI/DLR/PMU

3

SI

4

SI

5

DLR, shall ask SI to appoint third party auditors to
perform User Acceptance Testing. The cost for the
same shall be in the SI’s scope
SI to prepare User Acceptance Testing test cases.
UAT to be carried out in the exact same
environment/architecture that would be set up for
production.
SI shall fix bugs and issues raised during UAT and get
approval on the fixes from DLR /third party auditor
before production deployment.
Changes in the application as an outcome of UAT shall
not be considered as Change Request. SI has to rectify
the observations.

Note:
a) SI needs to provide details of the testing strategy and approach including details of intended
tools/environment to be used by for testing in its technical proposal. DLR does not intend to own
the tools.
b) The SI shall work in a manner to satisfy all the testing requirements and adhere to the testing
strategy outlined. The SI shall ensure deployment of necessary resources and tools during the
testing phases. The SI shall perform the testing of the solution based on the approved test
plan, document the results and fix the bugs found during the testing and report to DLR. It is the
responsibility of SI to ensure that the product delivered by SI meets all the requirements specified
in the Bid document. The SI shall take remedial action based on outcome of the tests.
c) The SI shall arrange for environments and tools for testing and for training as envisaged. Post Go
live; the production environment shall not be used for testing and training purposes.
d) The cost of rectification of non-compliances shall be borne by SI.
e) STQC/Other agencies appointed by SI with the consent of Department/DLR shall perform the role
of TPA. SI need to engage with the TPA at the requirement formulation stage itself. This is important
so that unnecessary rework is avoided and the audit is completed in time. The audit needs to be
completed before Go Live. SI needs to prepare and provide all requisite information/documents to
third party auditor and ensure that there is no delay in overall schedule.

12.16. Change orders/ Alterations/ Variations
1. SI agrees that the requirements given in the Bidding Documents are minimum requirements and are
only indicative. The vendor would need to etch out the details at the time of preparing the design
document prior to actual implementation. It shall be the responsibility of SI to meet all the
requirements of technical specifications contained in the RFP and any upward revisions and/or
additions of quantities, specifications sizes given in the Bidding Documents required to be made
during execution of the works, shall not constitute a change order and shall be carried out without
a change order and shall be carried out without any time and cost effect to Purchaser.
2. Further upward revisions and or additions required to make SI’s selected equipment and installation
procedures to meet Bidding Documents requirements expressed and to make entire facilities safe,
Page 56 of 140

<!-- page 58 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

operable and as per specified codes and standards shall not constitute a change order and shall be
carried out without any time and cost effect to Purchaser.
3. Any upward revision and/or additions consequent to errors, omissions, ambiguities, discrepancies
in the Bidding Documents which SI had not brought out to the Purchaser’s notice in his bid shall not
constitute a change order and such upward revisions and/or addition shall be carried out by SI
without any time and cost effect to Purchaser.

12.16.1.

1.

2.

3.

4.

Change orders

The Change Order will be initiated only in case
(i)
the department directs in writing SI to include any addition to the scope of work covered
under this Contract or delete any part of the scope of the work under the Contract,
(ii)
SI requests to delete any part of the work which will not adversely affect the operational
capabilities of the facilities and if the deletions proposed are agreed to by the department
and for which cost and time benefits shall be passed on to the Department, (iii) the
department directs in writing SI to incorporate changes or additions to the technical
specifications already covered in the Contract.
Any changes required by the Department over and above the minimum requirements given in the
specifications and drawings etc. included in the Bidding Documents before giving its approval to
detailed design or Engineering requirements for complying with technical specifications and
changes required to ensure systems compatibility and reliability for safe operation (As per
codes, standards and recommended practices referred in the Bidding Documents) and trouble
free operation shall not be construed to be change in the Scope of work under the Contract.
Any change order comprising an alteration which involves change in the cost of the works (which
sort of alteration is hereinafter called a “Variation”) shall be the Subject of an amendment to the
Contract by way of an increase or decrease in the schedule of Contract Prices and adjustment of
the implementation schedule if any.
If parties agree that the Contract does not contain applicable rates or that the said rates are
inappropriate or the said rates are not precisely applicable to the variation in question, then the
parties shall negotiate a revision of the Contract Price which shall represent the change in cost of
the works caused by the Variations. Any change order shall be duly approved by the Purchaser in
writing.
Within ten (10) working days of receiving the comments from the Department or the drawings,
specification, purchase requisitions and other documents submitted by SI for approval, SI shall
respond in writing, which item(s) of the Comments is/are potential changes(s) in the Scope of
work of the RFP document covered in the Contract and shall advise a date by which change order
(if applicable) will be submitted to the Department.

12.17. Deployment of the Application
The selected SI should deploy the successfully tested application on the cloud. The cloud service provided
should be MeitY empaneled. The selected SI has to bear the cost of cloud infrastructure and necessary
access of the applications and data should be provided to the authority. The cloud service should be
procured in the name of SI.
The selected SI should maintain following environments on cloud.

•
•
•

Development environment
Testing environment
Staging environment
Page 57 of 140

<!-- page 59 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

•
•

Production environment
Disaster recovery

After go-live any change requests should be made in the development environment and thorough testing
should be performed. The bugs should be fixed before moving to staging and subsequently production
environment. Disaster recovery should replicate the production environment, and the backup should be
taken at the regular interval. Recovery Point of Object is expected as 8 hours. Recovery Time of Object is
expected as 12 hours.

12.18. Application Testing and Certification
SI will perform the Testing of the software application before the application is made ready for acceptance
and rolling out in the region. The primary goal of Testing is to ensure that all the functional requirements
and integration components or data exchange interfaces of the developed application are working as per
the FRS/SRS prepared by SI and user expectations.
Additionally, SI requires the software application to be audited and certified by a cert-in empaneled thirdparty agency to ensure that the application meets the security and performance standards, while
complying with the recommended infrastructure, future scalability, and manageability. The Audit will have
to be arranged and done by the SI for the following aspects:
1. Safety & Security
2. Performance
Department will also conduct a User Acceptance Testing (UAT) to ensure satisfactory completion of the
application development as per the functional requirement specification. The SI has to provide the test
cases/scenarios for such testing along with test data and also facilitate hand hold Director Land Records
Chhattisgarh/Agriculture/Food department and other related internal and external stakeholders to carry
out the UAT. SI should also continue to fix any issues processes identified during the testing before the
final acceptance of the application.
It is to be noted that Director Land Records Chhattisgarh may also get the solution audited through a Third
Party periodically after Go-Live to ensure the success of the project as per the requirement. Such thirdparty agency for carrying out the periodic audit and certification of the entire solution will be nominated
by Director Land Records Chhattisgarh. All costs will be borne by SI.

12.19. Security and Performance Testing
The software developed/customized shall be audited by third party from a security and controls
perspective. Such audit shall also include the IT infrastructure deployed for the project. Following are the
broad activities to be performed as part of Security Review for the solution.
1.
2.
3.
4.
5.

6.

Assessment of authentication mechanism provided in the application /components/modules.
Assessment of data encryption mechanisms implemented for the solution.
Assessment of data access privileges, retention periods and archival mechanisms
Server and application security features incorporated.
Application Security mechanisms should be accessed in compliance with the IT Act 2000, 2008
Amendment and IT rules 2011, such that it maintains data/information Integrity, Confidentiality,
Non-repudiation. Any new acts and rules brought by the Government of India, Govt. of CG, the
compliance and regulatory requirements if any needs to be implemented by the SI.
Audit of Security mechanisms so that they follow the latest Guidelines by Controller of Certifying
authority (CCA), IT Act, ISO27001 etc. or as applicable updated guidelines.
Page 58 of 140

<!-- page 60 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

7.

Gap assessment of certain controls like ISO 27001, IT ACT amendment 2008 etc. as applicable
and decide how the sensitive data from a data centric standpoint is to be protected.
The SI shall ensure all security measures comply with the Information Technology (IT) Act 2000
and SPDI (Sensitive Personal Data Rules) Rules 2011, including reasonable security practices such
as ISO 27001 certification, end-to-end encryption with Advanced Encryption Standard (AES-256),
and audit trails for data access. Annual security audits shall be conducted, with reports submitted
to the Department. In the event of a data breach, the SI shall notify the Department and relevant
authorities immediately, bearing all liabilities under IT Act.

8.

12.20. Change Management and Capacity Building
The SI will impart training to all stakeholder’s staff and other key stakeholders on the usage and
maintenance of the project application. SI shall perform following activities as part of Capacity Building
and Change Management initiatives:
1. Prepare detailed training plan and training manuals to impart trainings to All departmental
stakeholders and Staff and other stakeholders. Plan will include appropriate training model,
modules, curriculum, schedule along with detailed methodology on how the training would be
conducted.
2. Provide additional trainings as they deem necessary to ensure that the training imparted is
comprehensive and complete.
3. Provide Computer Based Training Modules (LMS) prepared by SI to enable the users for selflearning and provide content to Govt. LMS system in coordination with the departments.
4. Training material with user manual (Hindi/English), online and soft copy/ hard copy/ kits should
be arranged by the SI during training program.
5. SI should ensure that the knowledge is transferred to the Department of Land Record, Agriculture
and Food Director officials effectively.

12.21. Go-live of the Application
The selected SI should submit following before Go-live to the authority:
1.
2.
3.
4.
5.

Final Go-live and UAT certificate from the authority
Proofs of trainings conducted
User manual bilingual
Security certificates
All necessary software documents of delivered product (SRS, FRS, design document, test plans,
test cases, test results, as-built drawings, etc.)

The committee will decide the Go-live exit criteria such as software rights and other related clauses and it
will be shared with selected SI during the execution of project.

12.21.1.

Partial Go-Live

There may be situations where final acceptance testing and Go-Live are being delayed due to technical
complications or operational issues with some modules/functionalities. In such case, SI may request
Department and other associated departments to allow Partial Go-Live, however, Department/authorized
Project implementation committee will not be bound to accept such request. After necessary consultation
with SI and authorized Project implementation committee, Department will decide on such request.
Department may reject such request without assigning any reason whatsoever it is. Objective of partial
Go-live is only to expedite implementation without compromising quality of the deliverables.

Page 59 of 140

<!-- page 61 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

Partial Go-Live is not the end of implementation phase partially. It is just a declaration on such part of the
solution as ready for production. Operation and Maintenance phase will start only after complete/final
Go-Live with due acceptance of the Department nominated officials in writing.

12.21.2.

Project Go-Live

After statewide roll-out of proposed project and its integration with associated departments and
integrated command and control center, SI shall formally request Department /authorized Project
implementation committee to issue Go-live certification. Department Authorized Project implementation
Committee will evaluate all the deliverables in terms of proposed project based on scope of work with
end-to-end digital integration with other departmental services and integrated command and control
center. Provisional and written instructions will be given to SI from time to time. The Project
implementation committee shall perform necessary due diligence and make necessary recommendations
to the competent authority. Based on the recommendations of the Project implementation Committee,
the competent authority shall issue Go-live Certificate. From date of the issue of Go-live certificate, the
project shall enter Operation & Maintenance Phase.

12.22. Training & Handholding
1. The system integrator would be responsible for training and hand holding across all the relevant
stakeholders in the respective responsible departments. The training shall be carried out on
periodic/regular basis by the System Integrator.
2. To ensure smooth system adoption and capacity-building across user groups, the selected agency
will implement a detailed Training and Handholding Program tailored to different user roles.
3. SI and its team are responsible for conducting Regular Trainings, Periodic, Ad hoc trainings of all
the stakeholders, farmers and their representatives, Digital Class rooms, offline and online
trainings, Train the trainers program implementation etc. but not limited to, as per the
requirement of the department.

12.23. Operation and Maintenance for 4 years
The selected bidder shall be responsible for after the successful Go-live date providing comprehensive
Operations and Maintenance including the technical support (O&M) services for all applications
developed and deployed under this engagement. The O&M phase shall commence from the Go-Live date
and shall continue for a period of four years, unless otherwise specified by the Department. The tenure of
the O&M period may be revised by the Department based on the SI’s performance and service delivery.
The SI has to carry out following activities during O&M period (but not to limited):
i.
ii.
iii.
iv.

Maintain the implemented applications as per agreement terms mentioned in RFP
Implement changes as per terms and conditions of RFP
Training/s to be conducted for government officials as and when required
All the SRS, FRS and other concerned documents with updated/modified changes during
the O&M phase need to be updated regularly and submitted to the department.

12.24. Exit Management
Successful Bidder shall provide an Exit Management Plan within 60 days of contract agreement date that
shall outline overall process that shall be followed post completion of contract period or on termination
of contract. At the time of handing over of the system per site by bidder within five (05) days, complete
set of OEM documents, warranty certificates, installation, testing, commissioning, and maintenance
Page 60 of 140

<!-- page 62 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

manuals, as built drawings and documents, cable and termination schedule, shop drawings shall be
handed over to the Department’s authorized personal and acknowledgment of submission shall be
provided for full and final completion certificate from Department. This handing over shall be in digital
form in pen drive and as well as in five (05) sets of hard copy duly signed and stamped by bidder.
As Built Drawings preparation & its compilation shall be done by the bidder and shall constitute a
permanent record of the works as executed. These shall include all such drawings, schedules,
documentation and designs as necessary for a complete understanding of the works and maintenance.
The As-Built Drawings shall consist of the fully up-dated versions of the approved numbered with titled
construction documents incorporating any additional information which will assist the Department in
maintaining the system and if necessary, modifying or extending the works at a later date. These drawings
should extend and supplement the information collected and generated during the tenure of the project.
As-Built Drawings shall be provided on durable paper Four (04) sets for reproduction by photocopier. In
addition, drawings shall be provided in latest version of AutoCAD software and copy in editable form in
solid state device (SSD) reputed make pendrive/s. Other related information such as progress reports, field
instruction notes, log-books, completion report etc., but not limited to, shall be provided in hardcopy as
well as editable softcopy format (Microsoft Word, Excel, Access, or MS Project).
All assets including software, hardware, licenses, tools, accessories etc. defined under the scope of this
RFP shall be sole property of Department irrespective of the termination or exit of the bidder at any point
of time.
In case of any kind of exit pre or post competition or termination, the bidder will be entitled payment on
the pro-rata basis, as per the decision of department competent authority.

12.25. Others
1. Equipment from vendors will be considered only when their OEM’s have requisite service centers in
India as defined in the RFP. Requisite proof to be provided.
2. Support from OEM / Technology Partner: Bidder should provide an undertaking from OEM /
Technology Partner as per format attached in Annexure confirming service support including spares,
software upgrades, etc. shall be made available during warranty period. Bidder should also be
responsible for maintaining sufficient spare parts and associate equipment and hardware, licenses,
inverter and UPS type etc. with 100% redundancy type with dual power, inbuilt all protection boosts
and float charger with batteries, softwares, tools, stocks up to safety level to ensure the defined
service levels during the contract period.
a. The bidder shall ensure to provide the continuous operation for at least 3 hours for UPS type.
Its batteries, accessories, and wiring should be capable of functioning to meet the
requirements. Any intermediate maintenance, replacement, change as required during the
complete contract period shall be in scope of bidder.

12.26.

Functional Requirement Specification (FRS) – Indicative

The selected SI should prepare the Functional Requirement Specification (FRS) once the requirement
study with all stakeholders has been finalized and approved by the concern department authority. In
Page 61 of 140

<!-- page 63 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

the FRS, the selected SI should mention each and every requirement in a detailed way and with all the
necessary features and integration for the centralized dashboard.
The selected SI has to submit the FRS to the authority for their reference and note any suggestions
received in any stage from the authority before/after the customization process starts. The SI should
have following points (but not limited to) in the proposed software for the project SI shall provide
compliance for all the points in technical response document.:
1. Should have provision to maintain/refer all farmer data as per National Farmer Registry data
requirements and any other data as required by the Department of Agriculture, Department of
Land Records, Department of Food etc.
2. Should have the facility to record all welfare schemes and scheme wise, subsidies, benefits and
any other support the respective farmers are receiving.
3. Identification of planting & harvesting dates
4. Crop condition assessment & stress identification.
5. Soil moisture estimation & irrigation monitoring
6. In addition to crop-related information, information pertaining to crop diversification, crop
advisory services, and disaster management will also be collected.
7. Farmland Registration
8. Geo-mapping of Farmlands
9. Farmland ownership data
10. Should be able to record crop details season after season and maintain the complete history of
Crop details including soil testing data and other agro-climatic conditions.
11. Should be integrated to all current systems with all required application of the State.
12. Registration of Farmers Organizations
13. Should have provision to Register and Maintain FPOs, Joint Liability Groups, Common Interest
Groups, Self Help Groups, Cooperatives Department, PACS and Communities centers etc. with a
provision for intragroup communication and collaboration.
14. Stakeholder registration
15. Should have provision to register all Stakeholders.
16. Should have provision to map operational processes of all stakeholder
17. Should have provision to record all stakeholder interactions and actions to bring in accountability
and responsibility across the spectrum. Should have a provision for Department of Agriculture,
Department of Land Records, Department of Food etc. to analyze the performance of various
stakeholders.
18. Farm Data Management
19. Integration with Land Records and ownership data from Agriculture, Department of Land Records,
Department of Food etc. Specified sources
20. Maintain Land owners and Crop cultivators distinctly along with soil preparation data, Crop data
and Soil testing data.
21. Provision to integrate and maintain Historical Market data against each crop.
22. Govt schemes and benefits
23. Facility to publish and maintain various departments schemes, subsidies, benefits, etc. of the
Government of Chhattisgarh.
24. Crop Husbandry Module
25. Should have best Agricultural practices framework and knowledge base for all crops.
26. Should generate Crop Activity Calendar automatically so that the farmers are hand holed
throughout from sowing to marketing.
Page 62 of 140

<!-- page 64 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

27. Should have the facility to analyze the impact of all forces of nature and advise the farmer with
context specific recommendations without having to trouble the customer with micro-level
technical details.
28. Should have a framework for recording all advisory points against each and every crop with
recommendation-action-response feedback loop.
29. Should facilitate introduction of new methodologies and farming techniques through digital
facilities rather than having to conduct expensive physical training of farmers and Agriculture,
Department of Land Records, Department of Food etc. staff.
30. Crop Insurance
31. Should facilitate on-line Crop insurance application process and Crop data verification process
including claim verification.
32. Should have the provision to Integrate with insurance claims process with approval notifications.
33. Village Agriculture Assistant (VAAs) and Department of Agriculture, Department of Land Records,
Department of Food etc. Staff should have the facility to manage, facilitate and support the Crop
Insurance Process.
34. Disaster Management
35. Should have the framework to disseminate disaster forecast, context specific damage mitigation
advisory to respective farmers based on the age and stage of their crop.
36. Facility to record the disaster and crop damage against each crop along with damage estimation
data, evidence and damage audits.
37. Crop Advisory Framework
38. Crop Advisory Framework to manage and maintain Package of Practices for respective crops with
respect to different agro-climatic conditions.
39. Facility to manage and disseminate different farming practices such as Natural Farming, Organic
Farming etc.,
40. Framework to disseminate context specific crop advisory to farmers
41. Crop Health Management (CHM)
42. Should have a built-in Crop heath Management Framework and Knowledge Repository
43. Should have a provision to manage and maintain crop specific Weed, Pest, Disease and Deficiency
repository along with images
44. Should have provision for the farmer to record the voice, and video of the diseased crop, and
should generate an incident automatically and have the facility to route the incident to designated
panelists for resolution.
45. Agriculture Extension and Knowledge Management Module
46. Should have built-in Knowledge repositories to support the field-level extension staff
47. Should facilitate context specific Crop Advisory dissemination directly to the farmers mobiles
48. Should facilitate Department of Agriculture staff extension efforts through context specific content
dissemination to targeted audience by crop or region
49. Should have facility for Department of Agriculture to publish all schemes/ subsidies/ latest farming
techniques/ Crop management practices/ Notifications/ context specific advisory, etc. to all
farmers or specific target groups.
50. Satellite (Remote Sensing) data integration
51. Should have the ability to integrate and analyze Remote Sensing data with AI/ML based image
analytics to facilitate context specific forecast and advisory.
52. Should have the ability to integrate and analyze Remote Sensing data with AI/ML based image
analytics to facilitate context specific forecast and advisory with centralized real-time dashboard.
53. Marketing Department
54. Facility to analyze market forecast.
Page 63 of 140

<!-- page 65 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

55. Should have facility to record historical market prices data for farm produce.
56. should have the facility to display context specific market prices for farmers' crops with in their
vicinity.
57. Providing Purchasing Centers information to farmers
58. Should have the facility to report the incident through Images, Voice/Video Messages
59. Should have a facility to receive various notifications broadcast from the Department Agriculture,
Department of Land Records, Department of Food etc.
60. Show market prices of farm produce across Mandis within their vicinity.
61. Village Agriculture Assistant Mobile App/Tablet App
62. Should have the functionality to register Farmers, Farmland identification, Distributor and other
stakeholders that operate at the village level.
63. Crop registration feature to register the crops and capture farm visuals.
64. Should have the facility to view and act on the assigned incidents or Service requests.
65. Should display Farmer and Farm details for respective Incidents/SRs
66. Should display the prescribed Crop Husbandry practices, diseases, Insect, Deficiencies, Package of
Practices and Weed management specific to the Crop in question so that the VAA can have ready
access to all farm data and history.
67. Should have the provision to maintain and record daily activities.
68. Reports & Dashboards Agriculture Dept
69. Cropping details report - at all levels such as Village, Vikash Khand, Taluk, District, Division and
State.
70. Cropping Details report -Crop-wise across State level, Division level, Tehsil level, Vikas Khand Level
etc.
71. Disease incidence report.
72. Pest, Weed, Insect Incidence Report.
The above-mentioned requirements are not exhaustive, and RFP owner can update the overall
requirements related to the required modules during the time of functional study, development of system
and implementation of system.

12.27. Summary Reports of Deliverables
12.27.1.

Design & Development of Web & Mobile Applications (but not limited to)

1.
2.
3.
4.

System Requirements Specification (SRS)
Development of the Project Implementation plan
Business Requirements, FRS, SRS, System Design & Application Development, HLD, LLD
Supply, Installation, Configuration & Customization of SSP 2.0 (Functional & Non-Functional
Requirements)
5. Data Acquisition and Reporting Services
6. Data Management Service
7. Enterprise Application Integration (EAI)
8. Application Testing
9. Quality Review
10. Project and Product Documentation
11. Customization of Applications
a. Mobile Application Android and iOS
b. Web Application
12. CERT-in security certification and STQC Certification
Page 64 of 140

<!-- page 66 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

13. User documentation
14. Training
15. For the design and development solution developed for the UPAHAR project, IPR of the
customized solution with editable rights including all the license/ Certificates would belong
exclusively to the Director of Land Records, Government of Chhattisgarh.
16. All License copies (if any) with named of Director of Land Records, Government of Chhattisgarh
17. All The data collected with functionalities of sharing through API/Excel etc. format for extension,
research, and education purpose.

12.27.2.

Data processing service on the remote sensing applications

During the development and maintenance period of the proposed system, various required reports—
based on ground truthing and imagery—shall be generated for Kharif, Rabi, and summer seasons using
actual data. These reports shall be prepared on a per-hectare basis, at the tehsil level, for specific regions,
and for different crop types. The necessary data shall be provided by the SI from time to time, or the
system shall enable users/stakeholders to generate the required data reports based on their needs. This
data and the corresponding reports shall also remain available on the proposed portal for future analysis
and for use in the Decision Support System (DSS). (but not limited to)
The proposed reports shall be based on real-time data and must maintain an accuracy level of minimum
70%. Payments linked to deliverables shall be made based on the accuracy of the submitted reports. For
this purpose, the SI shall submit invoices from time to time as per the approved process.

12.27.3.

Report and Advisory

S.
No.

Indicative Reports requirement
(But not limited to)

1
2

Crop acreage estimation and final
Crop diversification Season wise
final
Crop Loss and crop identification
report
Cropping Pattern Analysis per hac.
Crop Identification & Acreage
Estimation and final
Identification of pest and disease
infestation
Droughts Monitoring as per the
requirements
Flood mapping & monitoring as
per requirement
Accurate parcel boundaries
Linking each parcel with
ownership details, land use, crop
type, and taxation records
Drought or flood impacts
Compensation assessment

3
4
5
6
7
8
9
10

11
12

Approx.
Estimated Area for
Kharif Season
40 L. Hac.
40 L. Hac.

Approx.
Estimated Area for
Rabi Season
20 L. Hac.
20 L. Hac.

Approx.
Estimated Area for
Summer Season
5 L. Hac.
5 L. Hac.

40 L. Hac.

20 L. Hac.

5 L. Hac.

40 L. Hac.
40 L. Hac.

20 L. Hac.
20 L. Hac.

5 L. Hac.
5 L. Hac.

40 L. Hac.

20 L. Hac.

5 L. Hac.

40 L. Hac.

20 L. Hac.

5 L. Hac.

40 L. Hac.

20 L. Hac.

5 L. Hac.

40 L. Hac.
40 L. Hac.

20 L. Hac.
20 L. Hac.

5 L. Hac.
5 L. Hac.

40 L. Hac.
40 L. Hac.

20 L. Hac.
20 L. Hac.

5 L. Hac.
5 L. Hac.

Page 65 of 140

<!-- page 67 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

Assess damage to crops, roads and
other as per requirement
14
Land use/land cover mapping
15
Identification of planting &
harvesting dates
16
Crop condition assessment &
stress identification
17
Soil moisture estimation &
irrigation monitoring
Advisories
1.
Generalize Advisory
2.
Sowing and harvesting time
3.
Crop stress
4.
Pest and disease infestation
5.
Soil moisture stress and irrigation
Application
6.
On weather pattern
13

12.27.4.

40 L. Hac.

20 L. Hac.

5 L. Hac.

40 L. Hac.
40 L. Hac.

20 L. Hac.
20 L. Hac.

5 L. Hac.
5 L. Hac.

40 L. Hac.

20 L. Hac.

5 L. Hac.

40 L. Hac.

20 L. Hac.

5 L. Hac.

Submission Timelines

S.
No.
1
2
3
4
5
6
7
8
9
10
11
12
13

Requirement
Crop Acreage Estimation
Crop Yield Estimation
Crop Loss Assessment
Drought Monitoring
Flood Mapping and Monitoring
Pest and Disease Identification
Planting and Harvesting Dates Identification
Crop Condition Assessment and Stress Identification
Soil Moisture Estimation and Irrigation Monitoring
Generalized Advisories
Sowing and Harvesting Time
Crop Health Assessment
Crop Stress

14

Pest and Disease Infestation

15

Soil Moisture Stress and Irrigation Application

16

Weather Pattern

Timeline
Two times in a Season
Two times in a Season
On Event Occurrence
On Event Occurrence
On Event Occurrence
On Event Occurrence
Once in a Season
Once in a Season
Once in a Season
Every Week
Every Fortnight
Every Week
Every Fortnight/Event
Occurrence
Every Fortnight/Event
Occurrence
Every Fortnight/Event
Occurrence
Every Fortnight

Note: The above-mentioned data processing services and reports are suggestive and indicative only and
may be expanded, modified, during the project lifecycle based on functional, technical, stakeholders and
departmental requirements.

Page 66 of 140

<!-- page 68 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

13.

Qualification Criteria and Bid Evaluation

The Bids will be evaluated on QCBS Basis with Scores of Technical Evaluation and then Financial Bid in the
following manner:
S.No

Criteria

Details

1

Minimum Eligibility
Criteria

2

Technical &
Financial Evaluation

3

Financial Bid

Bids meeting minimum eligibility criteria will only be shortlisted for
technical evaluation
• Bidder’s work experience shall be reviewed & analysed based on
their Customer Order / Purchase Order and Successful Completion
Certificates/Go Live certificate in case of ongoing project/Sign-off
document clearly mentioning the scope, issued by officer not
below the rank of Head of Department/ Nodal officer shall be
considered as completion certificate., similar nature with the scope
of work mentioned in the Bid Document.
• For all projects, wherein Bidder is/was a Consortium partner, only
credentials/project experience of Lead Bidder shall be considered
where in Lead Bidder either shall be acting as a sole bidder or as a
Lead Bidder.
• Financial Bids of only those Bidders shall be opened who score
minimum of 70% in Technical Evaluation

4

Award of the
Tender

13.1.

•

Highest Score – H1 Bidder post QCBS evaluation

Evaluation Criteria (QCBS):

Only those bidders scoring more than 70% marks will be considered for financial bid/proposal. Bidders
scoring less than 70 % marks will be considered disqualified at technical evaluation stage. The cost
indicated in the Financial Proposal shall be deemed as final and reflect the total cost of services and should
be stated in INR only. Omissions, if any, in costing of any item shall not entitle the Bidder to be
compensated and the liability to fulfil its obligations as per the Terms of Reference within the total quoted
price shall be that of the Bidder. The Bidder shall bear all taxes, duties, fees, levies and other charges
imposed under the Applicable Law as applicable. The lowest Financial Proposal (Fm) will be given a
financial score (Sf) of 100 points. The financial scores (Sf) of the other Financial Proposals will be
determined using the following formula:
Sf = 100 x Fm/F
In which Sf is the financial score, Fm is the lowest Financial Proposal, and F is the Financial Proposal (in
INR) under consideration. Proposals will be finally be ranked in accordance with their combined technical
(St) and financial (Sf) scores:
S = St x Tw + Sf x Fw;

Page 67 of 140

<!-- page 69 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

Where S is the combined score, and Tw and Fw are weights assigned to Technical and Financial Proposal
that will be 70:30 respectively.
The bidder with highest value of “St x Tw + Sf x Fw” will be the preferred bidder and will be invited for
further proceeding for contract award and execution.

13.2.

Bid Opening

1. Bid Opening shall take place through the e-Procurement Portal.
2. A maximum of one representative from each participating organization would be allowed to attend
the tender opening. The Bidder’s representative, who may choose to attend the session, should attend
the tender opening on the date and time mentioned in the bid data sheet or as per the date and time
revised in the subsequent communication given through the e-procurement portal.
3. To assist in the scrutiny, evaluation, and comparison of offers, the bidders may be asked for clarification
of their offers on any of the points mentioned therein and the same may be sent through email. No
change in the prices or substance of the bid shall be sought, offered, or permitted, except to confirm
the correction of arithmetic errors discovered in the evaluation of the bids.

13.3.

Rejection and Return of Tender

1. Director of Land Records, Government of Chhattisgarh reserves the right to reject any or part of
tender or all without assigning any reason. The documentation submitted by tenderers shall not
be returned in case the technical offer is not acceptable unless the tenderer expressly states his
request at the time of submission of their tender that tender documentation be returned. The
cost for returning the document shall be borne by the tenderer. Director of Land Records,
Government of Chhattisgarh also reserves the right at its sole discretion not to award any order
under the tender call. This decision does not commit Director of Land Records, Government of
Chhattisgarh to pay any costs or loss incurred in the preparation and submission of any requisite
tender or technical proposal or to procure or contract for any of the items described herein.
2. If the tenderer deliberately gives wrong information in his tender, Director of Land Records,
Government of Chhattisgarh reserves the right to reject such tender at any stage or to cancel the
contract, if awarded, and to forfeit the earnest money and invoke performance guarantee.
3. Canvassing in any form in connection with the tenders is strictly prohibited and the tenders
submitted by the contractors who resort to canvassing are liable for rejection.
4. Tender in which any of the particulars and prescribed information are missing or are incomplete,
in any respect and /or prescribed conditions are not fulfilled, shall be considered non-responsive
and is liable to be rejected.
5. Any condition put forth by the bidder non-conforming the tender requirements shall not be
entertained at all and such Tender shall be rejected. The Technical tender shall be submitted in
the form of printed document and bid must be uploaded online through
http://www.eproc.cgstate.gov.in/. Tender submitted by Telex, fax or email will not be entertained.
Any tender not authenticated or not secured will be rejected straightaway by Department without
any further correspondence, as non-responsive. A tender that does not meet any qualification
criteria or is not responsive or not fulfilling technical evaluation will be disqualified and rejected
Page 68 of 140

<!-- page 70 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

by Director of Land Records, Government of Chhattisgarh, and may not subsequently be made
responsive by correction or withdrawal of the non-conforming deviation or reservation by the
bidder.

13.4.

Department Rights to Terminate the Process

Director Land Records Chhattisgarh may terminate the tender process at any time and without assigning
any reason. Director Land Records Chhattisgarh makes no commitments, express or implied, that this
process will result in a business transaction with anyone. This tender does not constitute an offer by
Director Land Records Chhattisgarh. The bidder's participation in this process may result in Director Land
Records Chhattisgarh selecting the bidder to engage in further discussions and negotiations toward
execution of a contract. The commencement of such negotiations does not, however, signify a
commitment by the Director Land Records Chhattisgarh to execute a contract or to continue negotiations.
Director Land Records Chhattisgarh may terminate negotiations at any time without assigning any reason.

13.5.

Minimum Eligibility Criteria

Documents submitted by Bidder shall be evaluated against stipulated requirements of Minimum Eligibility
Criteria. Bids not substantially responsive or having incomplete information shall be rejected.
1. The Bidder(s) must meet the Pre-Qualification Criteria. In case of a consortium the Pre- Qualification
Criteria must be met jointly by the consortium members unless mentioned in the specific criteria.
2. The value of the Contract/ Work Orders uploaded as part of the credentials by the Bidder(s) will be
considered with the Conversion value to INR as on the Contract order date.
3. During evaluation of tender response, the Purchaser reserves right to contact/visit the location of
clients for whom the Contract Orders are uploaded by bidders as part of the bid submission.
4. Any bid not found to be in conformance with any of the pre-qualifying conditions may be summarily
rejected and not considered for further evaluation.
5. Bidders shall submit only the relevant credentials against the Pre-Qualification and Technical
Evaluation Criteria with experiences of projects along with a ready reckoner as part of their respective
bids.
S.
Requirement
No.

Description

1.

The bidder must be a
Company incorporated in
India
under
the
Companies Act 1956/
2013/ Limited Liability
Partnership Act 2008/
Partnership act 1932 for
at least 15 (fifteen) years

Legal Entity

Single/
Lead
Bidder

All

Yes

Any
One

Documentary Evidence

Certificate of incorporation
and MoA/ Partnership Deeds
as applicable

Page 69 of 140

<!-- page 71 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

S.
Requirement
No.

Description

Single/
Lead
Bidder

All

Any
One

Documentary Evidence

with their registered
offices in India
2.

Consortium
Partner

Must be registered under
Indian Companies Act
(1956/2013) or LLP Act
(2008) with Consortium
size limited to 2 (Two)
members only.

Yes

Certificate of incorporation
and MoA of all the
consortium
partners.
Consortium Agreement with
shareholding details.

3.

Company
Documents

The Bidder should be
registered under EPF, GST,
PAN

Yes

Duly attested copies of
certificate by the authorized
signatory
should
be
submitted

4.

Consortium
Member/
Partners Roles
and
Responsibilities

Consortium Agreement
must be signed by all
members, detailing roles,
responsibilities,
and
equity participation.

Yes

•

•

•

5.

Turnover

The Bidder/Lead bidder in
case
of
consortium
should have minimum
average annual turnover
(MAAT) of at least INR 400
(Four Hundred crores) in
the last three financial
years (i.e. FY 2022-23,

Yes

A Consortium Agreement
must be signed by all
members, detailing roles,
responsibilities,
and
equity participation.
A Power of Attorney from
each member authorizing
the lead Member/Lead
Bidder is required.
The Lead Member/Lead
Bidder must be clearly
designated and cannot be
changed during the
project lifecycle.

CA/
Statutory
auditor
certified turnover certificate
for the last three financial
years 31 March, 2025 (i.e.
2022-23, 2023-24 and 202425) are to be submitted.

Page 70 of 140

<!-- page 72 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

S.
Requirement
No.

Description

Single/
Lead
Bidder

All

Any
One

Documentary Evidence

FY2023-24 and FY202425).
6.

Net Worth

The
Bidder/
All
Consortium
members
should have positive Net
Worth for each of the last
three (3) Financial Years,
(i.e. FY 2022-23, 2023-24
and 2024-25).

7.

Certification

The Bidder/ Lead bidder
in case of consortium,
should have following
certification as on bid
submission date:

Yes

Yes

The audited balance sheet
and Profit & loss statement
for last three financial years
(i.e. FY 2022-23, 2023-24 and
2024-25) are to be submitted
along with CA certificate as
documentary evidence.
Copy
certificate
from
authorized certification body
and in the name of the
bidder/lead bidder should be
submitted.

Mandatory Certifications

The certifications should be
kept valid throughout the
duration of contract period.

a. ISO 27001
b. ISO 9001:2015
c. Minimum CMMI
Level 3
d. GIS / Remote sensing
credentials
Desirable Certifications
e. ISO 22301 / 27701
f. Cloud security
certifications
8.

Blacklisting

The Bidder and all the
consortium
partners
should not be under a
declaration of ineligibility
/ banned / blacklisted for
any
of
Government
Authority/ Public Sector
Banks/ Public Sector
undertaking (PSU)/Centre

Yes

Bidder
/all
consortium
partners to provide affidavit
on a Rs. 500 notarized stamp
paper
as
documentary
support.

Page 71 of 140

<!-- page 73 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

S.
Requirement
No.

Description

Single/
Lead
Bidder

All

Any
One

Documentary Evidence

Govt./State Govt./ State
PSUs and/or performance
reasons, as on last date of
submission of the Bid.
9.

Experience

a)
The
bidder/Lead
Bidder consortium/OEM
must have experience in
successful execution of
similar
projects
i.e.
Projects comprising of
High resolution satellite
images, drones, Crop
mapping, Crop Acreage
Estimation, Crop Yield
Estimation, Crop Loss
Assessment as well as
Agriculture Web and
Mobile Application (Only
Agriculture Web and
Mobile Application will
not be considered) for
central/
state
government
or
any
government enterprise in
India during last seven
years from the date of bid
submission. With value
listed below.

Yes

Customer Order / Purchase
Order
and
Successful
Completion Certificates/Go
Live certificate in case of
ongoing
project/Sign-off
document clearly mentioning
the scope, issued by officer
not below the rank of Head of
Department/ Nodal officer
shall be considered as
completion certificate.

1) One project of similar
nature with the value
of at least 100 crores
or
2) Two projects of
similar nature with
the value of at least
60 crores each
Page 72 of 140

<!-- page 74 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

S.
Requirement
No.

Description

Single/
Lead
Bidder

All

Any
One

Documentary Evidence

or
3) Three projects of
similar nature with
the value of at least
50 crores.
b) The bidder/ OEM/ Lead
bidder or Consortium
Partner in case of
consortium must have
experience in successful
execution of at least one
Data Analytics Center
(DAC)
or
Integrated
Command and Control
Centre (ICCC) project for
central, state government
or
any
government
enterprise in India during
last seven years from the
date of bid submission
10.

Local Presence

13.6.

Bidder/Lead bidder in
case
of
consortium
should have office in
Raipur Or provide selfdeclaration
for
establishment of local
registered office within
30 days after award of the
contract.

Yes

Relevant Proof document /
self-Declaration for opening
of local office at Raipur.

Eligibility for a Consortium

In case of consortium, it should have maximum two members only. In the event of a Consortium, one of
the partners shall be designated as a “lead Bidder” who shall be responsible and liable for the successful
completion of the entire project along with responsible and liable for any communication, service levels
and penalties, payment, billing, issues, and issue resolution in accordance with the terms and conditions
of this tender/contract.
Page 73 of 140

<!-- page 75 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

i. Lead Bidder must have a minimum of 51% participation in the Consortium and 26% minimum for the
other Consortium member.
ii. In case of Consortium, change in constitution or percentage participation shall not be permitted at
any stage after their submission of application otherwise the applicant shall be treated as nonresponsive.

13.6.1. Bid by a Consortium of Firms
Bids submitted by the Consortium must comply with the following requirements:
i.

ii.

iii.

iv.

v.
vi.

vii.

viii.
ix.

In case of a Consortium, the members shall submit a Memorandum of Agreement (MOA)
conveying their intent to jointly Bid for the Project, The MOA shall also include the nomination of
the Lead Bidder/Member in the Consortium and clearly outline the proposed shareholding.
Members of the consortium authorize the Lead Partner to bid, negotiate and execute all technical,
financial and commercial matters on their behalf and that shall be final and binding on the Lead
Partner and the Consortium members.
The MOA should also clearly indicate that all the Consortium Members shall be jointly & severally
responsible for execution of the Project & subsequent operationalization of this tender Contract
during entire contract Period in accordance with the terms and conditions of this tender/contract.
One of the members of Consortium, holding at least 51% of the equity / ownership stake shall be
authorized and nominated as the ‘Lead Bidder/member’ (“Lead Bidder”) to act and represent all
the members of the Consortium for bidding and implementation of the Project. A copy of this
MOA shall be enclosed with the Bid.
A Bidder or a member of a Consortium can be a member in only one Consortium. If a Bidder /
member participates in more than one Bid for the same site / site, all Bids of which it is a part shall
be summarily rejected. No Bidder shall submit more than one Bid for the Project. A Bidder bidding
individually or as a member of a Consortium shall not be entitled to submit another bid either
individually or as a member of any Consortium, as the case may be.
The RFP shall include all the information required for each member of Consortium separately and
should be signed all the members of the Consortium.
If the Selected Bidder is a Consortium, the Agreement shall be signed with the lead member,
however, all members of the Consortium shall be liable jointly and severally, for the execution of
the Project in accordance with the terms of the Agreement.
After receipt of the Bid, there shall be no change in composition of Consortium (either inclusion
of a new member or exclusion of a member) or proposed shareholding structure as mentioned in
the submitted Bid which affects the minimum shareholding requirement of members of the
Consortium to decline below the required percentage as mentioned hereinabove till the
completion of the contract Period and any extension thereof.
Any change proposed in the equity shareholding pattern of the Consortium during the Contract
Period, shall require prior written approval of DLR.
A Lead Bidder/Bidder or JV/Consortium member/associate/partner or any shall not have a conflict
of interest (the “Conflict of Interest”) that affects the bidding process. Any Bidder/member of the

Page 74 of 140

<!-- page 76 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

x.
xi.

xii.

consortium found to have such a Conflict of Interest shall be disqualified. In the event of
disqualification, DLR shall forfeit and appropriate the EMD.
In case of Consortium, Bank Guarantee or FDR for EMD/PBG shall be in the name of Lead
bidder/Consortium.
In case of a Consortium, the proposal shall be signed by the duly Authorized Signatory of the Lead
Member. The Bidders/consortium member shall submit a supporting Power of Attorney (POA)
authorizing the Signatory of the Proposal, to commit the Bidder/Lead Member and agreeing to
ratify all acts, deeds, communications and things lawfully done by the said attorney and such POA
shall be signed by all members of the Consortium and shall be legally binding on all of them.
If it is discovered at any point of time that any Bidder/consortium member/s has suppressed any
facts or has given a false statement or has made any misrepresentation or has committed a fraud
or has violated any of the terms of this Bid, the Bid shall be disqualified by DLR. If the Bidder is a
Consortium, then the entire Consortium and each Member shall be disqualified/ rejected. In such
an event, the Bidder shall not be entitled to any compensation whatsoever, or refund of any
EMD/amount/s deposited / paid by it.

In case of a Bidder being a consortium, all the consortium members are required to provide the
following details:
1. Copy of registration certificate of Bidder/each member of the consortium, in case of the Bidder
being a consortium.
2. Consortium Agreement signed by all the members of consortium.
3. Memorandum of Understanding and Articles of Association of Bidder/ each member of the
consortium in case of the Bidder being a consortium.
4. The particulars of our organization, in case of Consortium, for all the members of consortium like
Name of the Company, Official Address with Phone No., Fax No., E-Mail id, Corporate
Headquarters Address with Phone No., Fax No., E-Mail id, Website Address, GST registration
Number., Permanent Account Number (PAN) etc.
In the event of the Consortium, after the award of contract, the parties shall enter into the separate
agreement mutually, specifically defining the terms and conditions of the contract and furnish a copy of
the same to the DLR.
Upon award of the Contract to the Consortium by the DLR, successful bidder/s shall not sub- contract any
portion of the Work to any third parties without the written consent of the other party and the DLR.

14.

Technical Evaluation

The Evaluation criteria shall be Quality cum Cost Based Selection (QCBS) where Technical Bid Score will
get a weightage of 70% and Financial Bid Score a weightage of 30%.
Evaluation criteria shall be as follows:
Technical Evaluation – Summary of Marks

Page 75 of 140

<!-- page 77 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

S.
Evaluation Criteria
Max
Documentary Evidence
No.
Marks
1
The Bidder/Lead Bidder (in case of consortium)
15
The audited balance sheet and
should have achieved average annual turnover of at
audited Profit and Loss Statement
least INR. 400 Crores in last three financial years (i.e.
for the last three financial years (i.e.
FY 2022-23, 2023-24 and 2024-25).
FY 2022-23, 2023-24 and 2024-25)
Turnover:are to be submitted along with
(1)
>=400 &< 550 Cr- 05 Marks
certificate from CA/ statutory
(2)
>=550 and <700 Cr – 10 Marks
auditor.
(3)
>= 700 Cr- 15 Marks
2
The Bidder/Lead Bidder (in case of consortium),
10
Customer Order / Purchase Order
experience of executing large scale IT projects in India
and Successful Completion
for central/ state government or any government
Certificates/Go Live certificate in
enterprise in India.
case of ongoing project/Sign-off
(1)
=>INR 20 Cr and <= INR 35 Cr – 5 Marks
document clearly mentioning the
(2)
=>INR 35 Cr and <= INR 50 Cr – 7.5 Marks
scope, issued by officer not below
(3)
=>INR 50 Cr – 10 Marks
the rank of Head of Department/
Nodal officer shall be considered as
completion certificate.
3
Certifications
05
Lead bidder or single bidder should
have valid certifications and GIS/
a) ISO 27001 – 01 Marks
Remote Sensing Credentials.
b) Cloud security certifications: 01 Marks
c) Above CMMI Level 3 – 02 Marks
d) GIS / Remote sensing credentials – 01 Marks
4

5

The bidder/consortium partner/OEM should have
experience in Development of Web as well as Mobile
Application in Agriculture Domain for central/state
government or any government enterprise in India in
last Seven (7) years from the date of bid submission.
(1)
1 Project: 1 Marks
(2)
2 Projects: 2 Marks
(3)
3 Projects: 3 Marks
(4)
4 Projects: 4 Marks
(5)
5 Projects: 5 Marks
Additional 5 marks would be given if any one of the
projects comprises of Web and Mobile Application
development in line with Central/State Government’s
AgriStack initiative.
The bidder/Lead Bidder/OEM (in case of consortium)
should have an experience of successful execution of
at least one similar large scale project i.e. Projects
comprising of High resolution satellite images,
drones, Crop mapping, Crop Acreage Estimation,
Crop Yield Estimation, Crop Loss Assessment as well
as Agriculture Web and Mobile Application (Only
Agriculture Web and Mobile Application will not be

10

Customer Order / Purchase Order
and Successful Completion
Certificates/Go Live certificate in
case of ongoing project/Sign-off
document clearly mentioning the
scope, issued by officer not below
the rank of Head of Department/
Nodal officer shall be considered as
completion certificate.

20

Customer Order / Purchase Order
and Successful Completion
Certificates/Go Live certificate in
case of ongoing project/Sign-off
document clearly mentioning the
scope, issued by officer not below
the rank of Head of Department/

Page 76 of 140

<!-- page 78 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

considered) for central/ state government or any
government enterprise in India during last seven
years from the last date of bid submission
(1) Project Value > INR 50 Crore: 10 Marks
(2) Project Value > INR 60 Crore: 15 Marks
(3) Project Value > INR 100 Crore: 20 Marks
The bidder/Lead Bidder/OEM should have an
experience of successful execution of project in
Agriculture domain where various Agriculture
insights are derived using high resolution satellite
images and AI/ML technology covering atleast 40,000
Sq Km classifying at least two (02) crops in a single
cropping season.
(1) >= 40,000 Sq Km and < 80,000 Sq Km: 05 Marks
(2) >= 80,000 Sq km and < 1,20,000 Sq Km: 10 Marks
(3) > 1,20,000 Sq Km: 15 Marks
(4) Additional 05 Marks would be given if atleast 5
crops are classified covering the area of 1,00,000 Sq
Km in more than one cropping season
Technical Presentation: 15 Marks (each point equal)
1. Understanding of the Project
2. Approach and Methodology - Solution
proposed & its components
3. Ground Truth Planning
4. Use of AI / ML in overall solution
5. Quality assessment methodology for
GIS/remote sensing & Machine Learning
derived output
6. Proposed DAC dash boards demo
Online Demonstration: 5 Marks
Web as well as Mobile Application deployed for any
of the client showcasing live the following modules: 1 Crop Acreage
2 Crop Health
3 Crop Yield
4 Ground Truth
5 Crop Loss
6 AI/ML based Satellite derived classification
7 Advisories
8 Chat bot for Farmers

6

7

15.

Nodal officer shall be considered as
completion certificate.

20

Customer Order / Purchase Order
and Successful Completion
Certificates/Go Live certificate in
case of ongoing project/Sign-off
document clearly mentioning the
scope, issued by officer not below
the rank of Head of Department/
Nodal officer shall be considered as
completion certificate.

20

Presentation to be delivered by the
Project Manager who has similar
project experience of the
business/functional requirements of
department, proposed solution and
implementation approach.

Documents Comprising the bidder's Proposal

15.1.

Technical Proposal

The technical proposal of the bidder (WITH PROPER PAGE NUMBEER OF PREPARED BID) shall contain
detailed description on the approach and methodology on the system developments to achieve the
desired objectives as specified in this document wherein the bidder shall describe in detail, the required
Page 77 of 140

<!-- page 79 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

services and articulate how the technical solution shall meet the requirements within the scheduled
timeline as specified in this tender document. The technical proposal shall also include the following: 1 Detailed Project Plan, Approach & Methodology
2 Project governance structure describing project management processes, methodologies and
procedures, risk and issue management, escalation mechanism, including team structure, capability
and resource deployment plan.
3 Detailed quality assurance processes, procedures, formal review to be adopted.
4 Proposed solution that meets the requirements as per the RFP.
5 Security capabilities of proposed solution architecture covering authentication, authorization, audit
trail, intrusion prevention and overall alignment to the Govt. of India and Govt. of Chhattisgarh’s
security policies and best practices.
6 Proposed solution addressing scalability, availability, performance, security & manageability.
7 Strategy for executing Annual Maintenance.
8 Approach for business continuity & disaster recovery.
9 Bidder’s experience provided in the format specified in the RFP.
10 Profiles of resources proposed for the project. All the CVs of proposed team should be given in the
format provided in the RFP.
11 Proposed solution on monitoring resource utilization in real time.
12 Proposed solution on automated configuration management with effective build and release process.
13 Proposed Backup Recovery Strategy defining back-up window, periodicity and incidence response and
recovery-restoration and disk management.
14 Proposed data retention and archiving policy.
15 Risk management strategy on backup and recovery, network and security infrastructure.
16 Any other documentary evidence/supporting document asked/mentioned in the RFP.

15.2.

Financial Proposal

1. The Bidder shall indicate prices on the prescribed Financial Bid Price Schedule (Annexure 21 and
22) in Indian Rupees only.
2. The Bidder is required to ensure that the products/Services quoted are as per prescribed
specification, industry standard and is compatible with latest hardware, system software,
application software, networking equipment, licenses, tools, database etc.
3. The Bidders are required to quote their best prices, inclusive of all applicable taxes, levies,
excluding GST, freight, forwarding, handling, insurance, inland transportation, local costs,
installation, commissioning, configuration, license cost, data migration etc. incidental to the
delivery of products/goods/services to their final destination at all project sites and for its
installation, configuration, tuning, testing, integration, commissioning , migration, integration and
maintenance charges after “Go-Live” and training of personnel required. In addition,
establishment of DAC and its maintenance during project duration along with its civil and interior
work, electric installation, sitting and working stations arrangements as per the design approved
by the department and as per the requirement shall also be the part of scope. GST will be paid
extra as applicable.
Page 78 of 140

<!-- page 80 -->

Request for Proposal for Unified Platform for Agriculture and Holistic Assessment with Records (UPAHAR)
RFP No. 350
Raipur, Date: 22/04/2026

4. Financial bid format will consist of Project Design, Development, Configure, Testing,
Implementation Cost and Operation & Maintenance Cost etc.
5. During the contract period, the bidder, with the consent of Director Land Records Chhattisgarh,
may supply a superior compatible version, or higher configuration, meeting or exceeding technical
specifications of the contract without any extra cost payable by Director Land Records
Chhattisgarh.
6. The rates offered by the bidder should be firm and free from all escalations during the entire
duration of the project. Prices quoted by the bidder shall be fixed during bidder’s performance of
the contract and shall not be subject to variation on any account. A Bid submitted with a price
adjustment/variation provision will be treated as non-responsive and rejected, pursuant to the
Preliminary Examination clause mentioned in this bid document.

15.3.

Financial Bid / Commercial Proposal

1 Unless expressly indicated, bidder shall not include any technical information regarding the
services in the commercial proposal.
2 Prices shall be quoted entirely in Indian Rupees (INR) and must be arrived at after including all
expenses, rates, and taxes.
3 The commercial Proposal must include the total price for all services scoped in the Proposal. To
be deemed responsive to this Tender Document, bidders must complete in detail all the
Commercial Proposal Forms provided in the RFP.
4 Bidders are suggested not to use ― ‘To Be Determined’ or similar annotations in the cells for cost
estimates. It is suggested that the bidders need to specify prices for all categories.

15.4.

Bid Submission details

1. Bids must be direct, concise, and complete. All information not directly relevant to this RFP
should be omitted. Department shall evaluate the bid based on its clarity and the correctness of
its response to the requirements of the project as outlined in this RFP.
2. In case of EMD/ Bid Security not received as per the timeline mentioned in Bid Data Sheet, the
bid submitted in e-Procurement portal would be rejected.
3. "Fraudulent practice" means a misrepresentation of facts to influence award of contract or a
procurement process or an execution of a contract to the detriment of Director Land Records
Chhattisgarh and includes collusive practice among Bidders (prior to or after bid submission)
designed to establish bid prices at artificial non-competitive levels and to deprive Department of
the benefits of the free and open competition.
4. The bids shall be submitted online on http://www.eproc.cgstate.gov.in/ only as per the formats
given below and as per date and time mentioned in the Bid data sheet. No physical submission
is required.

15.5.

Bidder's Authorized Signatory

A proposal should be accompanied by an appropriate board resolution or letter of authorization
(Annexure-23) in the name of an authorized signatory of the Bidder stating that he is authorized to execute
documents and to undertake any activity associated with the bidder’s proposal.
Page 79 of 140
