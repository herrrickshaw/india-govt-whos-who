---
doc_id: "e3ef52bca3f5a7c0"
source_url: "https://law.cgstate.gov.in/custom-files/notice_files/TDR20250912_11_68c3d137612ef.pdf"
ministry: "Law and Legislative Affairs Department, Chhattisgarh"
title: "Tender"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "6552067a640af880"
---

<!-- page 1 -->

ह GOVERNMENT OF CHHATTISGARH
LAW & LEGISLATIVE AFFAIRS DEPARTMENT
MAHANADI BHAWAN, MANTRALAYA, ATAL NAGAR,
NAWA RAIPUR (C.G.) 492002
NOTIFICATION
Raipur dated .02.202

9432 . seat co FEB 2024
F. No. /357 /XXI-B/C.G./202l- In compliance of the directions issue "
Hon’ble Supreme Court in its order dated 04-0l-2007 passed in C.A. 867/2006
(Malik Mazhar Sultan and another Vs U.P. Public Service Commission & Ors), the
State Government, as per information received from Hon’ble High Court, hereby,

है notifies the vacancies in respect of Civil Judge (Entry Level) for the year 202], as
under :-
Vacancies of Civil Judge (Entry Level) Nil
+o
Qha ही]
(Maneesh Kumar Thakur) *
Additional Secretary
Governemnt Of Chhattisgarh
4 Law & Legislative Affairs Department
