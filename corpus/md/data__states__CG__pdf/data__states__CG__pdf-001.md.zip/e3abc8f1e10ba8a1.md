---
doc_id: "e3abc8f1e10ba8a1"
source_url: "https://dprcg.gov.in/public/uploads/tenders/1746021912_5d24fea4efd0654dee4d.pdf"
ministry: "Chhattisgarh Public Relations Directorate"
title: "छत्तीसगढ़ प्रदेश की कला जत्थों/ नाचा दलों / नाट्य दलों के माध्यम से शासकीय योजनाओ के प्रचार-प्रसार क्र लिए संभागवार दर निर्धारण एवं इम्पैनलमेंट हेतु वित्तीय प्रपत्र खोलने की सूचना [199.04 KB]"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b1ad7056b18654b3"
---

<!-- page 1 -->

tulaidZ lapkyuky;
uok jk;iqj&vVy uxj

Qkus u-a & 0771&2511957] 2221616] 2221612
&&&

@@lp
w u k i =@ @

Øekad 2845@tlal@
a {ks-iz-@Vh,lih@2025&26

uok jk;iqj] fnukad 30@04@2025

NRrhlx<+ izn's k dh dyk tRFkksa@ukpk nyksa@ukV~; nyksa ds ek/;e ls 'kkldh; ;kstukvksa
ds izpkj&izlkj ds fy, laHkkxokj nj fu/kkZj.k ,oa bEiSuyesaV gsrq
foRrh; izi= [kksyus dh lwpuk
tulaidZ lapkyuky;] uok jk;iqj }kjk jkT; 'kklu dh tudY;k.kdkjh
;kstukvksa vkSj dk;ZØeksa dk tufgr esas NRrhlx<+ izns'k dh dyk tRFkksa@ukpk
nyksa@ukV~; nyksa ds ek/;e ls izpkj&izlkj gsrq laHkkxokj nj fu/kkZj.k ,oa bEiSuyesaV gsrq
fufonk vkeaf=r dh FkhA ftldk fufonk Øekad 4684@tlala@{ks-iz-@2024] uok jk;iqj]
fnukad 26@9@2024 }kjk tkjh fd;k x;k FkkA
fufonk gsrq vkosnu fnukad 25-10-2024 rd eaxk;h x;h Fkh] ftldk VsDuhdy chM
fnukad 15 tuojh 2025 dks [kksyk x;k] ftlesa p;fur 91 dyk tRFkksa@ukpk nyksa dks
izLrqrhdj.k esa cqyk;k x;k FkkA fufonk fu;e&'krZ vuqlkj izLrqrhdj.k mijkar 74 dyk
laLFkkvksa@dyk tRFkksa dk p;u fd;k x;k gSA
vr% lHkh p;fur dyk tRFkksa@ukpk nyksa@ukV~; nyksa dks lwfpr fd;k tkrk gS fd
tek fd, x, fufonk izi= ds foRrh; izi= dks 01 ebZ 2025 dks nksigj 12 cts ls
tulaidZ lapkyuky;] bUnzkorh Hkou] uok jk;iqj esa [kksyk tk,xkA mDr foRrh; chM esa
izLrqrhdj.k esa p;fur laLFkk ds bPNqd izfrfuf/k@vkosnd 'kkfey gks ldrs gSA
layXu %& p;fur dyk laLFkkvksa@dyk tRFkk dh lwph
vij lapkyd
tulaidZ lapkyuky;
vVy uxj] jk;iqj
