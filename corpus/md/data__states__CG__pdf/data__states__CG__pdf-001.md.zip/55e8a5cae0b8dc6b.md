---
doc_id: "55e8a5cae0b8dc6b"
source_url: "https://revenue.cg.nic.in/Tendar_Notice_wind.pdf"
ministry: "Revenue and Disaster Department, Chhattisgarh"
title: "Tender-Notice-Selection of WINDS(WIP)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dc7d966be960684d"
---

<!-- page 1 -->

<br>

Page 2 of 46

B:0771-2234583,2234584,2234578

hCH : 0771-2237480,2235302

:clr-cg@nic.in

#./6877/ H./WINDS/2024
TENDER NOTICE
Selection of WINDS Implementation Partners (WIP) to setup network of Automatic

Weather Station(AWS)at Revenue Inspector Circle level and ARG at GramPanchayat (GP)
level
The Director, Land Record Chhattisgarh, Governmentof Chhattisgarh invites quotations rom
experienced agencies for installation ofAutomatic Weather Station (AWS) at RI Circle level and
ARG at Gram Panchayat (GP) level under WINDS in the State of Chhattisgarh. All empanelled
agencies are mandated to get enrolled on https:lleproc.cgstate.gov.in/ in order to download the
tender documents and participate in the subsequent bidding process. The Bid form will be
available from date 03 January 2025 and may be submitted upto 17:00 hours on 03 Febuary
2025. This tender is subject to approval from the Finance Department for online tendering,
as per Chhattisgah store purchase rule 2002 (As ammended).

Detail schedule of important date may be seen on notice board of the office,
Tender Document and also availabe in departmental Website https://revenue.cg.nic.in/

iaudaue

. 36./6878/ H./WINDS/

2024

audaus.
