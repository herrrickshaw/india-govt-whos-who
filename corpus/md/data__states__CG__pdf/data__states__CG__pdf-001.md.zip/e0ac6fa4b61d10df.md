---
doc_id: "e0ac6fa4b61d10df"
source_url: "https://www.cbda.in/sites/default/files/tender-document/ADDENDUM_01%20PT_GHP%20002.pdf"
ministry: "Chhattisgarh Biofuel Development Authority (CBDA)"
title: "ADDENDUM_01 PT_GHP 002.pdf"
date: ""
pages: 16
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fcb89244a0d10361"
---

<!-- page 1 -->

Page no. 01
ADDENDUM No. 01 TO TENDER No. CBDA/2025/PT/GHP/002
Page no.13 : Clause no. 4.1 of NIT
4.0

EMD AND SECURITY DEPOSIT

Clause
No.
4.1

Particular

To be replaced with/to be read as

The AGENCY/Bidder shall deposit
EMD by way Demand Draft / Pay
Order
in
favour
of
M/s
CHHATTISGARH
BIOFUEL
DEVELOPMENT
AUTHORITY,
payable at Raipur. No interest shall be
payable by CBDA for the Earnest
Money
Deposit.
Bids
not
accompanied by Earnest Money are
liable to be rejected.

The AGENCY/Bidder shall deposit
EMD by way Demand Draft / Pay
Order
in
favour
of
M/s
CHHATTISGARH
BIOFUEL
DEVELOPMENT
AUTHORITY,
payable at Raipur. No interest shall
be payable by CBDA for the Earnest
Money
Deposit.
Bids
not
accompanied by Earnest Money are
liable to be rejected.

For Bidders applying for Green
Hydrogen Production Trial Unit, the
EMD amount should be as per Para
1.2 of the NIT. In the event amount of
EMD deposited by the Bidder is
insufficient, the technical bid would
be rejected, without any reference to
the Bidder.

For Bidders applying for Green
Hydrogen Production Trial Unit, the
EMD amount should be as per Para
1.2 of the NIT. In the event amount
of EMD deposited by the Bidder is
insufficient, the technical bid would
be rejected, without any reference to
the Bidder.
Micro and Small Enterprises
(MSMEs) may be exempted from
submitting EMD as per applicable
Government rules, subject to
submission of valid documentary
proof along with the bid.The EMD
of unsuccessful bidders shall be
refunded as per applicable tender
rules and procedures.

------------00----------

<!-- page 2 -->

Page no. 02
ADDENDUM No. 01 TO TENDER No. CBDA/2025/PT/GHP/002
Page no.60 : Annexure-A of SCC, Section-II,
Scope of Work
Clause
No.

Particular
Page no. 60-71, number of
Equipments - 13

To be replaced with/to be read as
Page no. 60-71, number of
Equipments - 10
ANNEXURE-A of SCC

Section II
Scope of Work (SoW)
Scope of work and schedule given for Activity:Fabrication, Installation and
Commissioning of Dark Fermentation Reactor and Associated Systems for Biomass
Based Hydrogen Production Trials Using Nisargruna Technology at CBDA Biofuel
Complex Site, Village Godhi, District Durg (C.G.)
The scope of work under this contract shall include in general but not limited to the
following:
1.

Fabrication, Installation and Commissioning of Dark Fermentation Reactor and Associated
Systems for Biomass Based Hydrogen Production Trials Using Nisargruna Technology at
CBDA Biofuel Complex Site, Village Godhi, District Durg (C.G.) as per Layout Diagram
(Annexure-XII A to ITB)

2.

Specifications of a few equipment for the Fabrication, Installation and Commissioning of
Dark Fermentation Reactor and Associated Systems for Biomass Based Hydrogen
Production Trials Using Nisargruna Technology at CBDA Biofuel Complex Site, Village
Godhi, District Durg (C.G.) are mentioned below:

<!-- page 3 -->

Details of Equipment and allied installations for Green Hydrogen Production Trial Unit
Technical Specifications/ Activity

S.

Equipment

Name of

No.

Activity/

Equipment

Code

/Activity

HR

Hydrolyser

Storage Capacity- 900L

Reactor

Mounting- Lug support

1.

Material- SS316/304
Shell and Dish Welded
Tank Capacity- 1100L Liquid
Thickness-3mm
Pressure-2 bar (29 psi)
Internal Baffles 60 x3 mm thick
Water Jacket- MOC-SS304 x 2mm thick
Jacket Water Volume- 500L approx
Nozzel: i. Shell Size


pH meter-25NB



Temp. Indicator Extra-25 NB



Level Indicator-50NB



Material Feed Inlet- 50NB



Material Feed Outlet-50NB



Extra- 25NB
ii.

Top Dish



Temp. Indicator- 25 NB



Pressure Indicator-25 NB



Gas Outlet- 40NB



Feed Nozzle with Hopper-65 NB



Water Inlet- 50NB



SG and LG- 150NB



Nitrogen Purging-25NB



Safety Valve- 25NB



Extra- 3 Nos.-25 NB each



Agitator Mount
iii.

Bottom Dish

<!-- page 4 -->



Main Drain- 80NB



Insulation cladding required

Acid & Alkali storage tank: Plastic
Tank- 200L each
1.1

HA

Hydrolyser

Top mounted, specially designed agitator

Agitator

for complete removal gases from liquid
phase and prevent minimum solid setlling
Agitator Type: Pitch blade type (PBT)
Motor Power: Flame proof 5 hp, 1440 rpm
Gear box output rpm Upto 250 RPM
MOC of wetted parts: SS304
Sealing arrangement with Dry Mechanical
seal
Control Panel: VFD control panel, RPM
meter,

amp

meter,

phase

indicator,

overload relay, Agitator On/Off, Speed
increase/decrease, Timer for motor
2

DFT

Dark

Storage Capacity: 1360L

Fermenter

Mounting - Lug supported

Feed Tank

Material: SS304
Shell & Dish welded
Tank Capacity: 1500 L Liquid
pressure- 2 bar
Thickness: 4 mm
Water Jacket- MOC SS304 x 2 mm
thickness
Jacket water volume- 600-800 L approx
Nozzle: i. Shell Side


pH meter- 25 NB



Temp. Indicator extra- 25 NB



Level Indicator- 50 NB



Extra- 25 NB
ii. Top Dish



Agitator mount

<!-- page 5 -->



Bottom Dish-



Main Drain- 80NB



Insulation cladding required

Acid & Alkali storage tank: Plastic
Tank- 200L each
2.1

DFTA

Dark

Top mounted, specially designed agitator

Fermenter

for complete removal gases from liquid

Feed Tank

phase and prevent minimum solid setlling

Agitator

Agitator Type: Pitch blade type (PBT)
Motor Power: Flame proof 5 hp, 1440 rpm
Gear box output rpm Upto 250 RPM
MOC of wetted parts: SS304
Sealing arrangement with Dry Mechanical
seal
Control Panel: VFD control panel, RPM
meter,

amp

meter,

phase

indicator,

overload relay, Agitator On/Off, Speed
increase/decrease, Timer for motor

<!-- page 6 -->

3

DFR

Dark

Storage Capacity- 3100L

Fermenter

Mounting- Lug support

Reactor

Material- SS316/304
Shell and Dish Welded
Tank Capacity- 3300L Liquid
Thickness-6mm
Pressure- 5 bar max
Internal Baffles 60 x 6 mm thicker
Water Jacket- MOC-SS304 x 2mm thick
Jacket Water Volume- 1200L approx
Nozzel: i. Shell Size


pH meter-25NB



Temp. Indicator Extra-25 NB



Level Indicator-50NB



Material Feed Inlet- 50NB



Material Feed Outlet-50NB



Extra- 25NB
iv.

Top Dish



Temp. Indicator- 25 NB



Pressure Indicator-25 NB



Gas Outlet- 40NB



Feed Nozzle with Hopper-65 NB



Feed Inlet 2- 50NB



SG and LG- 150NB



Nitrogen sparger in tank-25NB



Safety Valve- 25NB



Extra- 5 Nos.-25 NB each



Gas Analyser- 25NB



Manhole- 600NB



Agitator Mount-400 NB
v.

Bottom Dish



Main Drain- 80NB



Insulation cladding required

<!-- page 7 -->

Acid & Alkali storage tank: Plastic Tank200L each
3.1

DFRA

Dark

Top mounted, specially designed agitator

Fermenter

for complete removal gases from liquid

Reactor

phase and prevent minimum solid setlling

Agitator

Agitator Type: Pitch blade type (PBT)
Motor Power: Flame proof 12.5 hp, 1440
rpm
Gear box output rpm upto 300 RPM
MOC of wetted parts: SS304
Sealing arrangement with Dry Mechanical
seal
Control Panel: VFD control panel, RPM
meter,

amp

meter,

phase

indicator,

overload relay, Agitator On/Off, Speed
increase/decrease, Timer for motor
4

IR

Inoculum

Storage Capacity- 400L

Reactor

Mounting- Lug support
Material- SS316/304
Shell and Dish Welded
Tank Capacity- 500 L Liquid
Thickness-3mm
Pressure- 2 bar max
Internal Baffles
Water Jacket- MOC-SS304 x 2mm thick
Jacket Water Volume- 350L approx
Nozzel: i. Shell Size


pH meter-25NB



Temp. Indicator Extra-25 NB



Level Indicator-50NB



Material Feed Inlet- 50NB



Material Feed Outlet-50NB



Extra- 25NB
vi.

Top Dish

<!-- page 8 -->



Temp. Indicator- 25 NB



Pressure Indicator-25 NB



Gas Outlet- 40NB



Feed Nozzle with Hopper-65 NB



Feed Inlet 2- 25NB



SG and LG- 50NB



Nitrogen sparger in tank-25NB



Safety Valve- 25NB



Extra- 2 Nos.-25 NB each



Extra- 50 NB



Gas Analyser- 25NB



Hand hole- 150NB



Agitator Mount-400 NB
vii.

Bottom Dish



Main Drain- 80NB



Insulation cladding required

Acid & Alkali storage tank: Plastic Tank100L each
4.1

IRA

Inoculum

Top mounted, specially designed agitator

Reactor

for complete removal gases from liquid

Agitator

phase and prevent minimum solid setlling
Agitator Type: Pitch blade type (PBT)
Motor Power: Non-Flame proof 3 hp, 1440
rpm
Gear box output rpm Upto 300 RPM
MOC of wetted parts: SS304
Sealing arrangement with Dry Mechanical
seal
Control Panel: VFD control panel, RPM
meter,

amp

meter,

phase

indicator,

overload relay, Agitator On/Off, Speed
increase/decrease, Timer for motor

5

CR

Cavitation

Storage Capacity- 2000L

<!-- page 9 -->

Reactor

Mounting- Lug support
Material- SS316/304
Shell and Dish Welded
Tank Capacity- 2200 L Liquid
Thickness-3mm
Pressure- 2 bar max
Internal Baffles
Water Jacket- MOC-SS304 x 2mm thick
Jacket Water Volume- 800-1000L approx
Nozzel: i. Shell Size

5.1

CRA



Temp. Indicator Extra-25 NB



Main Drain Side- 80NB



Main Drain Bottom-80NB

Cavitation

Top mounted agitator for complete removal

Reactor

gases from liquid phase and prevent solid

Agitator

setlling
Agitator Type: Pitch blade type (PBT)
Motor Power: Non-Flame proof 3 hp, 1440
rpm
Gear box output rpm Upto150 RPM
MOC of wetted parts: SS304
Sealing arrangement with Dry Mechanical
seal
Control Panel: VFD control panel, RPM
meter,

amp

meter,

phase

indicator,

overload relay, Agitator On/Off, Speed
increase/decrease, Timer for motor
Other:
1. Solid Liquid Separator- 3HP 200L
per hour
2.

Membrane assembly and liquid

transfer pump- For removal of Volatile
Fatty Acids and water recycling – 3
Nos.- 1-2HP for liquid transfer

<!-- page 10 -->

3. Bacterial Biomass Separator- 20” x
9.8” MTD/SS & MS/ 3pt
2HP; 1440 RPM; 415V; 50Hz IE2
Foot Motor mounted with Clutch Pulley
and V Belts
4. Feed Pipe- MOC- MS, 38 mm, with
ASA

150

flanges

with

rotational

arrangement for selecting the required
angle of feed
5. Filtrate Outlet- MOC-MS, 50mm
Pipes with ASA 150 flanges
6.Vent

Nozzles-

MOC-MS,38mm

Pipewith ASA 150 flanges
7. Motor Guard- MOC-MS sheets and
shall be completely enclosed with
required lowers for the ventilation of
motor.
8. Tanks- 3 Nos- Plastic- 2000 L
9. Liquid Transfer Pumps- 1-2HP3Nos.
6

BGS

Biogas

Scrubber- 500 L with a gas inlet and outlet

Scrubber

0.5” with an appropriate valve and fitting
Low-pressure compressor- 3-5HP, 12 bars
Dryer- Alumina dryer

7

SHR

Shredder



Chipping and shredding in a single
operation



Power- 5.0 HP to 7.5 HP



Shredding capacity-300-500kg/hr



Running blades-2 nos. double side
cutting edges



Stationary blades- 1 nos. double
cutting edge



Output size- Adjustable as per
requirement

<!-- page 11 -->



Bitters/cutters- max 12 nos, each
having 6 cutting edges



Motor Driven



Speed- upto 2800RPM



Maximum Shredding capacity- upto
1.5 inches



Control panel



‘V’

Belt

Drive

System

with

minimum 2 Nos. V-belts


Emergency

stop

switch,

blade

guard, overload protection
8

PUM

1-2 HP; Solid Transfer pumps – 6 Nos. + 2

Pump

stand-by
9

HGSB

Hydrogen

Raw and pure gas storage- 2500m3

Gas

Flaring setup-4 Nos.

Storage

Blower- Flame proof- 0.5-1.0 HP- 2Nos.

Balloon

Gas Alarm- Hydrogen 0-100%- Gas Panel

and
Safety
10

OTHERS

Fire

Sensor, CO2 0-100%, Oxygen 0-30%
Sprinkler Arrangement
1.Instrumentation/process control panel








Speed control
Temperature monitoring
Ph monitoring
Pressure monitoring
Data logging and controlling
MFM for power measuring
Cabling from the panel to the
equipment
 Monitoring and controlling using an
HMI PLC
2. Piping valves and fittings
3. Cooling tower
4. Chiller Unit - 2TR
5. UPS- 10 KV with 1 Hour battery
backup
6. Stabilizer- 40-50KW 3 phase
5.1 AGENCY must maintain a track record of regular movement of the equipment from the stock
point to the installation site.

<!-- page 12 -->

NOTE:
1. CBDA will have the right to inspect and decide satisfactory level of the activity carried out by
AGENCY. All equipment supplied and installed shall be regularly maintained by the vendor to
the satisfaction of CBDA during the warranty period.
2. AGENCY entered into the contract with CBDA shall not abandon the work or discontinue the
activity without the prior NOTICE and approval by CBDA. If the AGENCY discontinues the
activity, CBDA shall have rights to forfeit both EMD and any work done till such time of
abandoning the activity.
3. At least 24 months comprehensive warranty from the date of commissioning of equipment (s).
4. Installation, commissioning and comprehensive free on-site training of personnel by
service/application engineer trained from the manufacturing company.
5. Provide the service and operation manual.
6. All the piping would be of stainless steel. However, complete sizing of the piping part
would be done at a later stage. The Above list of equipment for Green Hydrogen production
trial unit and its specification are indicative only and not exhaustive in nature.
7. The cost of delivery of the specified Green Hydrogen production trial unit to CBDA, Durg
as per specification in Sl. No. 1 above, shall be at CBDA Biofuel Complex site at Vill:
Godhi, Dist.: Durg, shall include all manpower, transportation costs, tools and tackles,
loading & unloading at the point of transfer of ownership.
8. SoW includes rate of material (basis rate + GST/other taxes, as applicable, all inclusive),
creation of item as per specification in Sl. No. 1 above including labour, transport, watch &
ward is part of the EOI.

<!-- page 13 -->

Page no. 03
ADDENDUM No. 01 TO TENDER No. CBDA/2025/PT/GHP/002
Page no.74 : Reporting Formats (MV)
Clause
No.

Particular

To be replaced with/to be read as

Page no. 74, number of Equipments Page no74, number of Equipments - 13
10
MV: Reporting format for Fabrication, Installation and Commissioning of Dark
Fermentation Reactor and Associated Systems for Biomass Based Hydrogen Production
Trials Using Nisargruna Technology at CBDA Biofuel Complex Site, Village Godhi,
District Durg (C.G.)
Equipment supplied to site for installation, installation of equipment completed, timeline for
completion of all installations and trial run has been completed and the details of the same is
given below:
S.
No.

Equipment/

1.
1.1
2.
2.1

Activity
Code
HR
HA
DFT
DFTA

3.
3.1
4.
4.1
5.
5.1
6.
7.

DFR
DFRA
IR
IRA
CR
CRA
BGS
SHR

8.

HGSB

9.
10

PUM
OTHERS

Name of Equipment/ Activity

Make

Date/Period
of
Installation

Hydrogen Reactor
Hydrolyser Agitator
Dark Fermenter Feed Tank
Dark Fermenter Feed Tank
Agitator
Dark Fermenter Reactor
Dark Fermenter Reactor Agitator
Inoculum Reactor
Inoculum Reactor Agitator
Cavitation Reactor
Cavitation Reactor Agitator
Biogas Scrubber
Shredder
Gas Storage Balloon and Fire
Safety
Pump
Instrumentation/process control
panel
Piping valves and fittings
Cooling tower
Chiller Unit - 2TR
UPS- 10 KV with 1 Hour battery
backup
Stabilizer- 40-50KW 3 phase
Piping valves and fittings

NOTE: The above format is an indicative one and may be modified by CBDA.
DATE: _______________
Signature of the AGENCY representative:
Counter Signature of the CBDA authority:

Remarks (if
any)

<!-- page 14 -->

Page no. 04
ADDENDUM No. 01 TO TENDER No. CBDA/2025/PT/GHP/002
Page no.76 :

ANNEXURE OF PRICE PART-I

Scope of Work
Clause
No.

Particular
Page no. 76

To be replaced with/to be read as

Page no. 76-76A
SUMMARY OF BIDDER'S PRICE

NAME OF WORK: Fabrication, Installation and Commissioning of Dark Fermentation
Reactor and Associated Systems for Biomass Based Hydrogen Production Trials Using
Nisargruna Technology at CBDA Biofuel Complex Site, Village Godhi, District Durg
(C.G.)
TENDER NO.: CBDA/2025/PT/GHP/002
S.
No.

Equipment/

1.

HR

Hydrogen Reactor

1.1

HA

Hydrolyser Agitator

2.

DFT

2.1

DFTA

3.

DFR

Dark Fermenter Feed
Tank
Dark Fermenter Feed
Tank Agitator
Dark Fermenter Reactor

3.1

DFRA

4.
4.1

IR
IRA

5.

CR

Cavitation Reactor

5.1

CRA

Cavitation Reactor
Agitator

6.

BGR

Biogas Scrubber

7.

SHR

Shredder

8.

HGSB

9.

PUM

Hydrogen Gas Storage
Balloon and Fire Safety
Pump

Activity
Code

Name of Equipment/
Activity

Rate
(Rs.)

Applica
ble GST
& all
taxes

Dark Fermenter Reactor
Agitator
Inoculum Reactor
Inoculum Reactor
Agitator

TOTAL

Total
Cost
(Rs. In
figures)

Total Cost
(Rs. In
words)

<!-- page 15 -->

Page no.76 A :

ANNEXURE OF PRICE PART-II
SUMMARY OF BIDDER'S PRICE

NAME OF WORK: Fabrication, Installation and Commissioning of Dark Fermentation
Reactor and Associated Systems for Biomass Based Hydrogen Production Trials Using
Nisargruna Technology at CBDA Biofuel Complex Site, Village Godhi, District Durg
(C.G.)
TENDER NO.: CBDA/2025/PT/GHP/002
S.
No.

Equipment/

10.

OTHERS

Activity
Code

Name of Equipment/
Activity

Rate
(Rs.)

Applicable
GST & all
taxes

Total
Cost
(Rs. In
figures)

Total Cost
(Rs. In
words)

Instrumentation/process
control panel
Piping valves and
fittings
Cooling tower
Chiller Unit - 2TR
UPS- 10 KV with 1
Hour battery backup
Stabilizer- 40-50KW 3
phase
TOTAL

NOTES:
1. The above estimated quantities for evaluation purpose only, however payment will be made
as per actual supply of the item as described in Column 3 (Name of Equipment/Activity) of
above chart.
2. SOR rate shall include basic rate of material (taxes, if applicable, would be extra), including
labour, transport, etc. is part of the EOI.
3. The total cost of material includes delivery of item as described in Column 2 (description) of
above chart at CBDA Biofuel Complex Site Vill: GodhiDist: Durg, shall include all
manpower, transportation costs, tools, tackles, installation, fitting, loading & unloading at
Point of transfer of ownership, etc.
4. Please refer to Scope of Work attached herewith as Section - II.

<!-- page 16 -->

5. Includes installation of equipment mentioned in Sl. No. 01 to 18 in Column 1 above at site,
its complete laying out and installation as per Layout Model Diagram provided in Annexure
XIIA to ITB, successful commissioning of those equipment and Production of end product
confirming to specification given in Annexure XIIB to ITB, all cost of manpower,
transportation cost, tools, tackles, installation, fitting, loading & unloading at Point of
transfer of ownership, etc.

---------0-----------
