---
doc_id: "7f2cbcd4bc1f69f0"
source_url: "https://cdnbbsr.s3waas.gov.in/s34b4edc2630fe75800ddc29a7b4070add/uploads/2023/07/2023072054.pdf"
ministry: "Chhattisgarh Medical Counselling"
title: "PG DENTAL RULES"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "24a59c2ea5caa963"
---

<!-- page 1 -->

'ffis +€ + en<tia er* go*

qftqr.qis
't*srq/g.f los f zort-zors."

irq Uirdli(ffir cr6E6a,q; fuur

tg srgnd sqi6 *.2-zz-B-dwrc
rrwe

/ 38 ft. t. fu, frtts

30-05-2001."

ffi

{l\IilIET
(€rgrErruur)

urfu+,R

t ffirRIil

{ugr, xrfrdri, frqis zu erfra zorz- tsnq 2 , {Ffi re3e

frris r47l

fufrmr ftR{r ftfilrr
riilitl, r{-6Frff t{{q, Tfltrtlgt
aur**gt, fr<im ts sr+a zotz

sTftiqffr

ff srs

rrq + srrrffq FlS +d fufr-flI rcr|ffi
rrer {rs{
erg<n
erg<n
sm*tm d-dqei
um aen ft
ure ffiria fufuer rok*laq + Fril+tff qr-{s-sfliff qre ft} f re{r &
m'ai* qm z r - o a l zo rt l fi l s s - t.

gd{anr

qd

firqffiaiqqqqrart:-

Ffic
1

q'f!frR {rq, tdFR w unc-

(\16) nftqqodqrcti-afuftetffiqfu-fuq, zotz+ear{i
1d) iftqcirmrdurmt:rgfir - ";

r

(di) nq * iia fufuror rcr|M**rqqiitletmiEr+ ftqai{r* vril+tff qrqlfc] ff (ffi tffi qt lrfu Ei
,

Fuell *roqrfrqrv(r{r |

2.

- .- -

qiitrtqdt- Ei firqn]fr, nGI air i* d+i q ef,qeil srfi{ird a a,"qfrfr"' nefirimtsfurqqns{/+EF{firianrrqsrqttqlsilEirfu

(6)
*,,rttgerfrryar'ffi;
(q) "qr<ldsffi" teTFThdtkr€Tr+ffi 1orru$*udvrcrtnFrenrqcq-qqqqtvrff fre rN qftq1/
Fr)

qfuqq-cl/ene{il+ straqfttTrfud wgqn, Bffisrc{rsH.rqrsk*FHrsa FRfrre - sd);
"ffi "tgrfi rfrdtargqfuaqrfr ,q-gE'fuaiiffi ,wqfto$q,f tft fi*furlaqreqnferdffi

;

(H)

"{i{rf"tsrnlifr tckTrqrft:$ffitr{-{+d;., . . ..... : . .. .- ..
"{6Tfr{r6q"Qsrft TAatfu rrqifr rrarntr$s,vrffi tiafr ft,-er:rakends;
"fu' I srnTilat qrq*q{afufu-ffqf{re;
"qr{q*c " 8 srnT+f, t Frr+ff fun ur{r*e;
"{iqrilfi " Q Erfir*d t iiarrs, fufuRr ft ai; g+srq usq;

(H)

"{i=n56151q" q e{fuAa t {andflaq frfu-ffi ft ffi ,

(q)

'?*sr qff qn" t srnTia t

(z)

"aifrqtra{ryfr.qr" turfuiaQuifrqq<ursu,rifrrfrfuwiaftmrerr{ft161qr-{-ftvfraqrqrrq*enr
eift rfl ft l\fr]errrdrss+{da1ft rfu iemiarrrdqtdqqef *Idcrtg#d
fr FrHuergqnufu ff

(s)
(s)
(?)
(B)

vfurq flv{;

{& ffi re s+ir .n{qr (vrd+tm ) NEE T-M D

S);

ffi

nFmur;

(a)

"Q-qnasnqeff'taftrldtgrrrq qd qffi q-srqr *,rm + ereft{ "S.sTR.w.d." ffi fr w ftfr-€r
a{Rr*rft s]+ft reell({hddrft ;''fr n-€l+q-<ini+orh/qrg,tnffi fr qct6qorq{r+tsrff t.+drn6,$at-ff
tFrqfualnqefNFsr emmurI

t$1tTuaerm* zs rrr+0*wvffqt-dlfr s adqrf atd6;
, 293

<!-- page 2 -->

' Hs 22 3Tftd 2017

294

(s)

d

t

qrro fi q+frsfl-r- h
"er!;q€uq.F' TeTftqrdq" t{ GTftffl rerfrurarq qr qrenq,
srJ"dE so h'Ew 1t y h erofo qrffio. eier+r qtEr$ ci-fl-€lwo. qtRd qfu'qr qRndi

il eae am qjilfrrfl d oen qt E-ffi aTrc;r drqr GTErqfrd GTfrffi/Fuqt b Bid,ftr
qrcrar qr.d d;
(d)

(q)

t

g { vRurfr-+ ffi fr e-qf b

"ft:QFKITFI'

t 3lftfd t tqT ft:alihum +€T fu- "ft:QEfiI afu' g+m 3;[.Nl{, 3IRroT-iT

"ftq; sffi' GrFdd t tqT cllqsff ut fuq z b' su-g
Brd,t-a rSsfl.tET;

or qr<elul Gfri TUt qrrffil e{Rlftqq, 1995 (1990 mI r{. l1 fr effiI 2 b w*rs m fi'
oTeftqqR'+tfril d ow ut .fl-{frq fr'fu-cT q.R'q-q am ftqffu sftHffid b ergwx

frrfr/MqT qTd.q-mq { q}aT fi ft\ qn d (fr:at.ffiIl E qqTufto-<uT -

qRRr"e -d) ;
(d)

"{r.'q q1q1q''

t olft*tr t E-frE IE aTNFI;

(eT)

"frsfrsr-dq'

t uplo * q. *+Eqrd sqlealq efi *alea fr-am g errgv fraPdqrdq,

Eedq+.|6
(E)

|

"fr.enq.qq.{ft." or Grftmq t q.'q qTrtfi drql uw elffi+c, qfqm { qil arluderc

il4lTfrfu-*Taiqqt-q-fl

t

TITrIfrq -

fui vtqu-#q, qxfiq qf, qPtsq I frEfr--srdq / qrw qTrs{ / cl-{f, rr{filt /

N-o1
q-erfufl--dq

fi qeffieft, qler q-frffI sTqe{ oen q}aT b dffi t+ru-{+rtt w qsfl t+eT}Bfl

q-{.d Frqfr oen frFrqt'r E frr} qq {{qtelq sr-{. erR{f, oer frFHR-d *{ftr

Grl

qerfr-oraq { q}aT b fu{ro. t" B.n < d-{ qq ft oT-drqfu b ftq TUffif, di+r r e,nq$

6 t+qf 3TrzFt=rrrEr E Ffr ifrcs, siarorfuo ffi

qr ot$ erq qtfit m{i fr oITsT

3spqffil
ffiqt rr,ft qn GrrqPH o\ oT-sqftq { rnq d-i h ftt q-qrf,fld'q fr-fucT lelen b 3fq-dTfi
fr&o w q-tfu-q o-{FII GTFrfld EhT b-q-d qlr q-fif-d 3i",qeff of fr {fu 3lldfrd fr qrSftt
eqff + ortRffi t fu-ffi{ qdqq b driTq.q-ifufl o'1X qpq-+rft rrc qEd of t eiq
qT$T
ar{-q Er$qq h gd G1x;PH oi qdrd fr qrft t fr-t FEq} 4\ tuf sq t qe d \r{
d efl{ GfiRm fi T$ Hfoi n n o6 q6ot eft, m' erqrq E meff of sTqfr-d fte w

qlaTfrqr+flTfrdfr
(qt-r)

r

er,qeff aRr NEET-MDS o\ iBa ftti T$

frI

q-dqq 3[e.lfd 3il'dfi q{ } qpl

offi{

"il

q-dq frt$ t e-S std fr fr q.ffi eq:t ox,ft+ftq qq 3fldd{ qQqrcr r{qe.rT { q}aT

tg en+e+oeifr
Frq) eFqefi an

r

ffiq

orsR+fuq h dRTq Grq-dtg ftql Tqr 6FIel{ b q$

t 3il-qe{

tsw<r GTrtifra iiterT E sleT b 6*q 3p+ff ar-{ frt}.r$ aq.nsrc ot {+ti=I dr+ enqeqmt I r*oreN\ E ft-qnT qr€ ql-i * 31weff q+e eneieq/triaT @-r E-6ER TS E)'r t qtffr
qd-tft aqr qfreil'sq{r< wE6EI6u-$ ,T-$ 3r,q?ff ol e1siff6 fr-f,inT or tfr q}er sqq?f,
fr-drq frqT qr{| rfleJT E qlaT &' ftg enqeqo' dTr
r

<!-- page 3 -->

Bffi€r'rd{uilr-{, fuis 22 sT+d 2ot7

zst (r)

(E:) e$ frofro!-iRrd.ET-n d u-cfi€Tc r'q E E-.fiqr6 Ed qfrq-q E [Sqq o{FIT 3r-qautr.
a).n r qlaT swt<I gs'qr6 fr qqq {irT Gidrfa"E-c*qrTd q6 qftqE E q-frfr fr-fu-tr-o
qqT oqi o.r r'lrur wI q-sgf, offi en+ero.6)qit
dri ig oITnfi oer qifu-d

Wo

F{ra) ET-n o} e}eftro s+ fr oT-drqfu { qftq{ 19 R-{q or enofuo erc-olaT y+ €en ugu
fr sqqft q) aBe/rr&eiq & oTfu-6-dq 10 k+*{ o6 qleftrm qq b fre)q eflq-onT
qr*ordfrr

ft

Eq :- 1 . 3icrfrraT ftqq liqrrd oflqPH b ftri .fr arldtr
2. e,Er6IaT 5 fufkd frqr (r5 kdt+) sTfU'o

t

ffi fr qqRaft fr Reifr {,
3rgqRaffi ft-qr+ GTffi6 strff,raT h {rfi E ffi
d\, m oIEffiq dET
15

tfl

kd$ !ft eteftrm'rr{ dflr

+qrd qrqRffi h qqffiq TUt o{i sqq<I ftqr{i { qrq-e - ffi fr'ft qg{fiq h fr\
qlq-rq erqfu so qre t I qqffiq./ ffiqrm omfu Wf o{i or-& eTrqftq tqndsnqeff ot

{

qteil E sq-ft q|Re{fr w fuqR fuq fuqT qeJ@- frqr,I { ilq{{ urm dqr, tI& S i qteil
scdrt g$ d ergrqr rS 1 ftnfr fr qRRe{ft t Gftafi qft qs-i ar orfora qarqr =r&
sKr{r r w^+ft ci-{fr-raT fr GrqE.}'csrq{ fr ci-qfu ol qfEletul 3lfrktrd w t} qlw 4-{qi
GIFrfl-4

+r fuE gq ci-qfu b ftri d{ relritu-s erer+r icrq srTR eq re1 e}'n

t

qrrirT- ar{d uift GFqetr a} v-}qr tg q+ot d,ft q} -

(o) N-o-) - fuq ei",qeff i e-.fr-q.rd { frerd sratflT qlkr qa ft.fu-trT reft-qrcq t d-dqt+
Bfr flW fr E) r u.fis.re aTNFr {qrc-sq \q qkqn o-eflul frqTq b 3Teft{ tqlw
fr-furoo ffi qlaT qE b'ze E-{drft E tr{ qq fr arrq6?T +qT TUf oq d d, s{h'frq
sqqrf,d Bqq 6arr1rfr dt

r

1.dfu.z erftFrqq 1s4B (1e48 A'to1 uEqfi+vrpqnrO
qrr{ b frfu-ffi
1dl - nqem FrqoreT oYA fi {ffi { qnaT fu {rwAqT h

retfffi b
-i frfud q$eil qRqrq ii so qffd sio qq eTltfu'w t
enqsff $ qtrTfu-d 6}.),
ft:aErir qrqf b ftr$ +s ffid sro qr.f, ffi E) {rrq h erTqffd ffi fi 3flqpff b ft\
frfu-d qteil { +o ffia ero flw o-E+ enqeuffi' d.n
(s) ffi qRqq drcr qrard"f (f, {qr-ilfr.frfrDt{T qSeil sfruf o-{i h qeflq qfreil
r

t

qTH

qf fr 31 qr{ of qr se-h W {-ff}M W oq frn 6\;

(,T) ffi

qd-S EIiT 3nqtfu-d ftfu-d qter h dBd qftonq.{, erfl{f,em dnft b

ftt qr-dq

b ftr'$ qr-ou +o ffia et-o oqr 3i-rlqRrd Anft h
eTr-Sk6"w t ft:at,rer qiq.f h fu$ +s ffia. ero qF ffi d oTerqr sfla qlelBro sd
so qWa eio, enqf$fl ,nft

tg qT{fiq eo engff-srn qRr{ qq b--q rr{o'R arEr qjEifud Anft ig GriRffi g+ot ero
oTPs-dfrde)

r

<!-- page 4 -->

Bffis{€{rq[d, fr{is 22 erfrcr 2ot7

2e4 (21

1u) frr{ft fr Bilqeff &qrd q+Bc-l ffi Td { oTfu-f, eilrfr+ / rw oitl qffiffi ftsrtieT t
qler sq{=d fte o-r qReqT,T fuqT d erer+ q-*w v+o errqefi ol fur$q fuil rrfi dI
dt sQ-{fu qkiql,T / ftw-rqr{ ftq $ qQr ReTfr B,n fu ffilfr d-r qq b ftr} qr'q
t=lf,otctr{ srdqm-q { $}qT fr qrror qS d.ft

r

{

t

M qdffi-q $ w fu{n *, s+ s{b av Xuf ffi TS
qq ffr {rvrl ii
qrdzrn-q fi' vearq qrdqlrq
Wt m{i fr Aqro t mqqr; eilTrfr ft-q

(s) a-ei",qeff ffii

qm5pq{s}qT frqwf,r rfl d,ftr

1a) tqt GFqeff ful-oT qq-{ GTRe-i{ qT{dq.ote t qsfl h i=lf,otcil qrdqlrq t gq d mn
{rwq dt tg 3ilqtfu-d orsR{friq am .fr st qfu oil-eBd dri fr Re{fr { st Aro-d To fr
rfte qq qlqr di fr qrrm dfr r qrw ote

rte oiqfurqm-{fl*fl
5.

t qlaT di fr Rerft S GTfu-d lTr{dq ote ft

r

ercqdqfi Tisefl+ { s}er tg f{r}o qFlerFT - oTil.{-cqo. {i*e{Fi, eil.+ s{effi { r}et fu
Grfrft+d sr;q Grffi q foifto mq q++il frg g-+ qe.GTfrk{f, or€nT h qIWU-s h'eiiq ti, qfrqil
q{ b ze q-c+tt b $ {+qra.n, frE -trT feTeil of ftfu--d { qall tft E\,ft ffi fu s€ q}aT
ffiroT{rlFqfu.afuqf srtrs
t

qfuf orGINeTUL-

(\-o.) e-$m'€{eJrq.b qr.'q dt q BTgq"Tfrd q-q-flfr b ftr} ezv., ea-gqpa wfr.b ftr$ tzv.
defl GraI @ e.f (ffidTi) b fuS t +'to enqeu t].n
t

dl

Bqtrffi G{r{ffur a-cfie.,T-d orflfrd qtft, Gr5qftrd u-r-sift ozn fusl q.f Nlttfr.o
qiR€{ft b eqrufl-o-inT or frft-qr{y erfufrunrFur zot a ti ftBd HqerT-+ il ergw v}r
t

1fifl qtrdTqqf fg 30% derTft:erflrs{{iq{tg sz Sfro ememd{r
(o.) q-q-t q-f,e iffi at so qftqm t zo qfterd n-o h fid Fmd 3i.lt fr rerTfr
dt-dqld{ GTerfidT u,6 srq-Rffi t ,rqr qd-ff r tt 3lrqfDht} ft 3i-g.rffiqdT fr
r

Rqft"{, {q+ s-qtR Tfr'Tt TS d-d e) +o vftBro t+ so ffierf, n-o fr ft-q-& 3i=lT
ft erm a'rmit'r-eq GIakFdI uri e.qRffi q).rql qr}qr
;

(s) qTrdq ftEtffi qR'q-{ Nq.{ft Gil{ ) h qfttrrr-o\ib ergun FmftTfud ereffi-al-Sl
qqlqq{ qT-& si",q'pff, gra rft g}t, eglo:-

(\-6-) sqs sffi ft:aEfiuFT

til

;

Effif,ft:ak5uFl;

d-ql qBtqft:aTincFr;

q
1arr) Frz-A orrr fr zo qfterf, qfo-o ft:flinitl
FIO q;rf,r qrru q* d orgRiftq b'q+ryq 03 qra 6 sg+- gvr+ r d;
;

<!-- page 5 -->

I
tldsrrGttq[d, Gqis 22 ETftd 2017

ze4 (31

1urg wtra sq-ftqq (1) E B-cAfu-d oTnclur b qux fid o-r frs-ffiR BTTEic ffi qGft
aM frqr qr$rr ffi WqT qrqTdrTdq. fr t-qq.r{c w rurB* 6 uffi
t

7. qqqqfuil.-

(O s+eTrrften:-

\q-fiq qroqlnq { q}aT \ ier+o e}-€ Gil.F \'ffiifriera q{ frd ar-u dB-o
q-dq.H eterFrfi e-* tg v-ften lueer-MDs) b qn"rq trq GTETIfu lrfiuq q* qTq fr

(\-o.)

"ri+ft

r

G) Sr-f,r5 err-ifi fi Gifu ftPr e-o qr0 ftr$ 6q (e-dr-if, \-a eru-"liS.s qTTorS fr e'qlfi
dtr;
d-ql oir-dts{ Gil-}E-{ h r+rq q.ftE fr a$ qr*m *+tfit qrq-o.rt St - qrw ftfl-$$ rqrcro Bfr
qft qq q+f t qEdI, fr:arrram ) ti aq-{ sq$f, 6N qffiq qrq
qtw fr,
Xa.Frotfr,

r$d{r

t

1u) qfte{rqRsnq '(1-o1 frr+ 3flqpfi i e-.dlqr6 { Rerd qrcrdl qrw (a frfu--trT TeTfrqraq qt fi-S\'€ Bft srro
ft E\, u-.fr-qrrd an*r{ {qraa \q qfudn 6e,.rru[ fuTrt fi qfi-{ tq'na ftfuffi--fi ftf,-dri
l-}eT q'E h zs

q-SElt

wrt { fr-r'q{ fr eTrcrfrq tqT [uf o-q fr 6 s-qh frq wlttrf, Fqq aTT

I

GD qi-qrd errqetr of fr qnaT fu lllaT qtefl h FRTII E frEf, qr-dq 3rffi eio ulw q,-S
dlr r q+q-i{ +qrff silqRffi fr gelo Hfrsq q* frq=T 7 3ilguq Frcrfkd drqq+ s@} d
cisfl qrqwqlaq arqr tqn fr qrS'ft

t

ffifl t+rr€r qH trqrd 3flqeff @fuer sTRrfiTfl orqi enaer qfrefi qforq strd i{qk4-o.
rqr{-eq W o\ s-{gil mti r qqqffiqt {qK€T W fufucT sTErorM fr \-6-sr$ etr-{T
rtfi tqR mtt r q)-+s ci-o) fr quril h'GTrErn qq BIfrR-{fl ci-o. utsoq s-+ qt'q-dT
q-m E erfum oq eiftq fr.qflr q-*, €qrdro. frfuNT f}reil dm +qR fr ur}'X
oi-o.

I

1qtr) t{fia-eflqPlq-i fr qTwqRo q)]?l-dr Fu-ev - qt - tful fl{nT I ffiom"a
ard A6o e)rT { sq-ft fi,T{ Q-dT b ftq +q-s b 31o. u}-sfii Frftrd fr qr},ftt qlftT
leftn+ftorsza merR-o-f,r qTA fr-F6d dri E +qrrd. 3flqetr of GTB+-dq NEET-MDS

qTQ{frmdr

oqqtT fu qrwio- 6-t 30 qfrqrd ero qFf, ein r qI qr wrt+ olfuo +qrEa eflqRHr

sim, Frdr+

Orf'ft

d qsrqq

fi qen q qrznff fr eng E q€qdT d GTftqrq ti gV me+F-o-ot fuItkd fr

t

Frq) qi-rs Gt+'f ft qurfl tg oTEtqfr-d I frFro A-qT eld h 3TfrR-+d erq f* enrqr 3nqeff ENf
t-qT h dRTq orqTftr"od'Gr-JqRa{ft I

erffio 3r+m-rqT qrq rS fr or}fr

t

<!-- page 6 -->

ir-dsqc ttqq{, Gqis 22 sr*fr 2or7

2e4 14)

(E:) r+Etsr BqeFEr ffd qq, il-duq q-fi b or1qTi ner ftqq g ii qe{r sfrdfu-fl orgfuftrl
qfuqT 61-q,

srqffi of q-uB-srdqfl{ \rd €-m-r+qn qqrmq mT 3rrq-{ fuqr ud'n

t

B. drr$ dq, (*qio.) fi rrumr.- tfu or FHfqET ori E ({-E-{r\{ h Gfl{ / qT g,tq H E fr r$ +qT b
qq
ftr$ e-kr6q b'rq ii qn-onrc+erq Hftrfifr ffiT vlseq qr+ot q qlqr qfretT t slw 3i-m'w r++.
qcndT t r
t O qftem fi cq t,TMet, q\ fu 3lB"fr-dq gO qfret-dom. fuql w
b
5-<<rw h 3fu

ft\

Sfq e)T t E1i,

q\ qrq-qqq ql {\'q e-*DR/T{qfl qtmTt qxr qfuTIG-a fu'q'K d

'-

(116) qt-r-q sTa. b-{f, q-dqlq { qfi.eiq.\'q.{fr. qtd { mTtrid.{qr€Qq qq qRil-{ o-e'qg frq1T 5
3rtfi-{ NEEr-MDS sieTqteilsdltdqRd fufu-g+o.,

ffi

dl

ffit 02 qqfr errtrfiqe-qTWt

qr}t
oq fr E\, o}q-{H
et{s Giot qqqr tg .nqfr am ll}er qS b' za h-{dft ft Re{fr {
r

ffi T} tf t-qT sfr

fi

otqFqfu-dfuqtqrn
1ft-fl dr{t+ 3ffit fi rruTil iE fl{<IE-6 or$ €ra (Actuar prace of postins) qrq ffi qr$f, q fr
t

qdJq ofd' refa (Attach ment)

I

1urg un elrq'eff ff{r 01 q{{vot Grft-m. foft h q}r}toT{fuqT.rqr dfi dqqa ry* fu
erter"oo gw ffi il-d etd { frrS r} +qrut a} rrurqr b fu GTretN e-{MI qrhrr

Fra; qi{q. Grf, NEEr-MDS { ms er+t b qfrard h qq6.{ nqm 6q qfit
(8,) dfr-s sd fi rrurfl h ft\ q$q FqNe2T frer+ &'sm qft ol€ld=I fr.enq.g.qft. qfr {
srfrT fr|Qlg1ffi ti qflenqfl-d entrrc e=[ql qr].[r M rrumr ftqrgqi{ fr

T'-*

eHi{fttSrSmid< eXuuftrroqfrrqq
r q2ftq ehT q frtS r$ und ig vlllo. b'os qfrqrf, qRrqq
(Normar)

r

t

st*qq sq-d?-ftq ffi{ffiTsuFrs fusTE.rfib"to ffiqro

(qrq 3IWt t"T qq b ftTS oi$ fr ei-rr+ 31o. rqm Tft fu-t ortit

qRHE

t

;

(3nO rrqrd-flaq Fqr{zr ffi b GTtft+fr ,r$ t-qT b ftI q{qm-fi, Errazl artlqrt tqT
srrrul- q-[, qY-r-{{ 0T6' o-r al-*r qrw 6-d

tg ur+:uo t r erq !-m-iuii { i]efuf, frqn€qel

arqr qrt trfl qqrq q'{ t

d) tfl fl srru q;r, qlqT.rfteil.fr

G{-o.

q.fr oilA<q q{ b'v+tu q-€gd o-r+r fir frN{h 3TIEIT{

qq qicifufl fr'+rrrTeaqI an qYfl{ ero rqH fr urS'ft r FRfqrw - d-ql

e. oniftrftirr sfuqr- oT-sfrfrrr qfu"T qTTfrq e-qt"?;qEnEM/ qndq {d qFtsE aM ftqffud $rRpft
3EsI{ frqr qnT n r 6-njft+frr'lefrqT fiErTTqT{

t-

dt vq miqq ft+oieT fr sqdc.sT rfid ft frqq-qR frrqf, qlrfiI-t €qrdrTdq
frE-*T fqreil fi tq-s6c t e"-6rfaTd ft qfirft r enqeff fid h +qq fr qrw att nen
qqem ftqoiqr de E sqEF=eI ffi mr qqdaT ftEq a+q { o-q q{ht

11-6.) {rw

t

G) e-q {ffi fr r}eT b.ftr$, lrfiuq-qrft h GTTEII w wqrf,fldq fl-{ Fiqfufud i1fr E
oflq-dEq orsfufriq ft qr$fr :-

<!-- page 7 -->

, frcis 22 srftd 2017

(o)

{

wqt-{d sdfud sq-t+ri fl-dnq q-fr dftd Efi fi qIE, sqrdfldq dffi d qiuil
qr+,ft, ftf,-q-ft q+qq
a-q-qr{c w rorfQi-o
orriffir.r

qruft

ft

(s)

2e4 (s')

ft

ptR-q fr sd,ft, t+rrkr rquil a tnRjfufrFT sffiqT eiqd-fl qrqq t ft ar*ft;
<rolNr fr
GIE-atEq otjffir.r { ffiq{, qrerfrm-fl wq qt ftqt{q, 3ilttia,

p

€freil q emiftn {ftd { qiaT fr s-frqT HFqfu-d dfr r q}aT q$eil b'31ff6 r*
',rti b .i6q
w T4 b qlt ffi T$ qrIM qr fr q{frefl i qrq fut qr$t

ffi

(.D

;

afu arEq qdT{ ft qfuqT sFI qeH onifufu,r At sqzl ErlErG=eI e}'ft r aTgffit'I
ti qnr d-i b szg-o. qrfr qrd 3rrqRHr d qr{q orsfrftir b qrq fr q-Sq-q o-{rql

36qflddI.r;
(q)

iqrrqu q-q qrt argfuffiT ft q{Tq qRUft fi' ergsu, onqeff of frfrav.*rEoq t{dqr r er,qeff gqFf6=Er $rrEI

ruffi

Vq qr-offiqT or fuo-sq qTerB-m-f,r srgqTq

+iEqqef di;
(s)

(q)

vm'qrq eTerR-fi-dr furtqq qam s{h'meftoor Fq ii,

qffi o6 fout ql-iTl,

r*g drBo ifrd b oftfum ei-q r$ Aw fr {frd, u} Td { qERfd r$l.g{ Et, b
6q ere{B-m-dl;nq { sffi ftd 4.r fuocq qfuftf, o{i fl rnqenfrd *{r;
qprfum-flr mq { ft-oeq trri fr oifu ftfu n-o fuq GilqRffi i ft-o--fl qfr
t,
'fiT
i atftftiq iE {q'i-q ercnr dr ur}t
qtda w
sflqPffi of effiq orsRTfuq q1q'er s. 2ooo t- mT Urrdm ffi
osr eln dQfi errqe{ d-i b T4 oFqPffi o} €qrf,fl-d'q aF{r Frqfftf, ftRrdr {
sqR€rd d-o< Xa ETdImt fr q{*ffi o-{FIT GiM dt n r enqgff o} <Tflrffi fr
qfreil
fu eva-"tr rffi t fr-+ g+r er.qRffi of iiq-rdo am {freil < flqtrd
6q1qTfifl r sfir scqT fr i{qrcffi dRI cfl?raqo-flrgtrx ?tr ft w q+h..ft I qifreil
{ 3r€ Eti w fr GFqS o} eircta RqT qr&r r ftqfka frfqru+rq t fuq aili qrd
rner fu Fmftrfuo e€tno q-qd o{qT srFrqr$ t :(\-o.) 1o+z fr Gr-o.{$ F*rfrq er6-fr1
t$ wrdotctr(XdsneTqftefi olslerqd
d-ql rq.fr.fr.\'q rfr.S.Ts. perq, Efi-qq-a siftqlfrXa oroqfr
;

(E)

(qrg {.{ft.T1:f eti Giqfreri) qr qrilur q;r

FtO Erfrvlc or qrE<fro FErtft qrru q{ lexRro ffi tgl
(E:) ft.S.gq. fr {fl-f,fi'31-{€rr{rcerTt wTB
F{rOqr'qtfuo-a4l-s{ftf, otsr?a-$R{.dq-Sq{qquwr
(e[rq u-.tfl-e-,T-d qr'q b qelq sTEm]-fr ar-u wfr Tra{ qft 1trq1u1 tl-fl, qft
s€mrq qflqwt q *i fr ft€rft"E eqilro qrgq f, aFIsI q?r qlEd mRqI
oTFrfld t nw aTqel q{ !-t-gd +-{i h 1116 b'efril{ q-cqrfud srlTq wr q'{gf,

fuqr srfl. enqeqfi'tl

qrq tfumeT il€ ar<r qr$ Tarrft ft:eltrercTT IHTUT q*
1<rfl FFrfRfr srsq{ aTrsfrqtrfl qqMT{

tfl

<!-- page 8 -->

2e4 (6)

Bdsrc ttgqd, fuis 22 eTfra 2ol 7
(u)

*ifren { 3r€ Eti w srfiuq qfr il srEq]T qqoTq vq rdTfr-fldq or effiieq fuqr
qrtfi u\ qqrdqldq fr tqrrr{c qq qqfatd d.r dsrT 3ll-qffi qIW silqPffi o}
qlaT AlT GTrzIQqtF'd.r atqezrq fr enrn* ?-iuli

fr oT-sqftq { e-i {Bt derT

er-fiurdT 3rgqTq Gtq-i-s qrEf, m{i tg ut u <il;

(s)

eqt Gr.qeff frr{fr ft q{Tq mRiR{ftirr qfuqT t qrg{ uri or fr-f,-cq t q-f,fr t
fu=g t gq: orjqfdq qfuqr q qFq.fr-f, TS EI q{ilt
;

(q)

i Bflqeff ffi srqdq qIW +fl t e.t A-qsEe t orrci-q q-I znt Eie erse d-oq
qrfr q{Tq qliuft cTTsq srEifrd.q-erEqraq E oTq-fr q}eT qfuqr wt +qfr etfr;
q{qerT

{ fieT TS ftT} ur+ w t enqrfr vwt fu erqn d qr$ti oerfr st oTfrr

Gnqer-s.fuqT { q{Fqfud ftqr qr qhrrT r
qR-iqrT ftlqT

tt 3rqrff ftil.Eti q}et s.r{-< rfu ot

t, i qrqrt anifrfu,r qfrqr t qreq Et qr$n t wft eflqeff ftil€ii
r

erq-+ giedfrm-fl. 6q 6T FErfinT ft-fl efi fu--g s=t frqq 3IIiiEd t-& gv, n {{S

er'rA a-{ur b

ft\ qn drr , I 3pq-eff "il GltiBd rfte qq qnaT E qafuqraq E

Fq"i sqRrd o-S gq d, T6 qFIr fi-iqr fu t s-df, q+d w qlaT fr EzEr q-S
(d)

t

t

(g*-) onqptrb x-qo+ibqtnf, TflfrfllErci h- drct, ftrffiq qSemovql
qrlw;
Fi) frfr-G-fiq qfterq q 3d Eti w fr er,qeff o'r qlaT frqT rrr$'n;
d-ql qR a s"tfu-d sqn-n qfuqT { frq-d d qri t d} a qTqteIFIo. qr* h
ftd, qler e.BqT t erqn qlkd oq frd qrtiit;
(qR) r+$il eME+nrq qd 6-c+ 3TFHd dr.n, entito =reft-qrdq { }riaT di
tg Frrffud ftR{ h T4 BrEft-f, Tc'o qqr ex{r dfl'
(qlq) sTftq ftR{ Frqilq gmq atd am fttrtR-o qqq vnfr h sl.+sr9 fi ga
{fu qkiqT,T mri fr ft€{ft { Gr.qsff dr{I wrl fr T€ geo { q} zo qfrera
<TRT o-dft ft qd,fr Gfu a)q <Tfar errqfr of qrq$ frq dfr
(u:) cpqpffi at q-erfr-qrdq { q}aT h q{qq e!fr Tf, T{f,rffi a} qqf zEt;il
;

elw
rfu sTqffi sq-{f, e-}RId snqeff, dqT W E
r

(d)

ffi{

ffi orrqeqqrw rS E} qror t fuE

q-Sqq E q-fi.6d t e-+ m-duq qdr b oqmq {, utg+m=+ \-q reTfuildq

o-r Btrq qqur ii Giliier frqT qdqr r qq si-rqRffi ol {fi++ gs qfuqT fg qS

fuqrqfiqT
(s)

I

k&q qqg,I fr +rgR{frtT + q-foprq qr'q dt fr {ffi or enda ftql q|.\'.r s6ff w qlaT fr FFIfRf, ftP{ b qflrf, s{ R-fi rffi of lqtffi ftq-oieT t 6qq 16
gq eqw qRqffid oq q-etm ftqoieT fr {ffi or enq-{ frqr fl.qqr t fu-*ft fr
onq t{ siftq aqq ft or-ifufrr.r w-{ro R-m.w r€ ifi-d of 'oiRrq q}aT qfrql t
rrql sr${r, rfri of

Td { frqT 3ilqe mw u-S-.oo crq-}f0rd

* 3pqRlfr dRI q{I

udr r gq-b qaqrn rfr qR fi& R-+d rs qrfr * ai sq m-d ig rfi-{ iidqr
ffimT{ fuT uc f,erT tffi.m-d slqPffi 6 ryfruuar il ergm+ t t ftd; iflt
oildfrd-fturgft

r

<!-- page 9 -->

t
effisrrermq*, ftFis zz erfra zotz

2e4 (71

10. GTnferd *uft fr elq re G fid 6r Gr;tI oTrfe-rd /GffiRferfr drft t qFITdq (3iffiuD .-

(\-6) ffi * orTrRffi M ft q'rv ve r$ {frd h ftT$ vs &}uft b or,qrff ft ergv-a-"trm fr een
ii, g-q iffi of 6it-qrT6 aleTftr6 €er p-iu { en<eiuD eTfufrqq, 2012 (fr.9 q1 2012)
b srqqnT b elgqn qffif, frqi qrSfl
r

lEil qR srtRrf,M {ffiq-q,ifra}qhqn e.qffsqErcqqdd}, fu+dffa}
sS ii+f ft ei-q &tM ii qffio oq ftq qri'n

t

dfl ffilrqf {, w{{ff&', qn qqfrfteqv-o-ercrfrqaTr{Wffib "fr*ff' E
qRoffido-qfrfiqt-&r

r

(qrg iffi/ ffiqMq ftqfu?Tq{rd,f qMqq-E-dfufrqffiqMq dqT
11. wlq+fiq *'qeq + fie or qftteqr{r

FFrfRc.qlaT

t

od w fifttEFf .- qTqfi'q q-qt"q qlzIkEI h'ftter h ergux

fr 3rftq.ftP{ b w{-o,6'ffiq.t{ euFrr{ ti er+fl qq{f,q ruf fttt G-iT {fr-c

reqffiq b qq q qft(qT,T oti qf qRsq arsr fteflso eirtfU?cr erqfu rfi' sqqRerd rsi w
snqfr m<r erffi fr <TPr ffi qqf qqqmq fr geo qlf$r oen q-Erq frti ng q-drqqrs fr
qft qpqft--a e}.ft lemon ft€{R { qur+ ft.r$, qJ-{€fl o} aq dft r guu* or qrsrl qRftrc-qra;
t

12. siler ra trirqr.- qR q6 qrqr qror * fu si"qrff

i ffi q-srfr.qraq { freaT (trtils s-(ad o{ qI

.rf,a qrflst-S toq q.iaT ftqT t ql sler h warqffi *fr q+qq 46 qrff urart 6 31weff 4i

ffi

,ra-ft qoy t+ qlqT ft-a.rfl t, d) tt{ etrqpfi of frqT.rq q}qr, lr{pr{ qgs sM r+sh' eft4trq frffi

b dtrq frrT frr{fr qa+r h Ea fuqr w qio.n t q}$ sfirqr { s-gp ffi fr ft-qrE qr eizrT fr
Rplfr {, qrqrcro', frfu-trT ftrelr zFI Fptq, q+rft w dq+orfr *qi
t

t

ffi

qd vri qrd un,
gnwor, Gqan.qr$l-dT oen ernfugo w or5qRerd {di b
ei-gaTrsqr.Tm'6Tffi b frq s.d{erfr dt, ftf,-*+{ erfus-o-ovvrild b artl rofuarcq t Fqrqq
gq freqfrilrf,q am qfi+q rg fu-fi qrfl r+Fqfua t srqTts-ff, sv ri qq e'tr rp=n b fu;oq as
fu 3rflRe{d rsi qq yiqr {q'+q fr{w qlqf qrhr r {'$ orEqRp{fr srqfq or frtfi fr r61q fi qr;q
effifrlaT

ftP{

{ qqtqtsq TS E}rI t,ti tt fuft qrdqm-q q e-nfaTd FrwTftf, qrqeff, w+'Bqllr{ fr

t m-'raT: err.nfr d-{ qd h ftT-$ qrw ft FqTildrd{ fie w q}aT h ftr$ erqn e}t t q}qT {a

*i fr ft€rft.ri Fqq r r { frFo wmrq aqdn r.qQqkr fr arrqfr of ss-b Xa <wrilo ilfr-s
r

ffiqriir
13.

14.

r

offi

s{Id d-ft E} a}
Frqtf e Hqer+ of e.,rT-ft qil-i { ot$
o,1ftq-5wr.- qR
T{ .Fq q$t ft
<r'zr aTrqq eriqr trrqr, q) Fffit b elqqtqT GrqTd q d,

fut

fl

t

offii

I

enfiuq qft ft qrqrft.- qr{frq q-d"q qFn('EI b fr{nqun q}aT qq fr sr rg qI ss *q{frrqt
q* b'ftq qiaT tg qTTfrq q-d'q qrfl?Fr am ftqfka
erq ftR{ a'l lTdu{dT rrfr v+qro

ffi

Et qd-rft \q R-fld qftd qq.ro e\

qtft

t

<!-- page 10 -->

B#€rE rdq-{, fuis 1z wfu zor z
1

s. Ftwfi \rd Eqtg,fu,: EFfiqE ffi frfr,-isr Frdotfi( qleT frqq, 201 5 \T(*rqr, ftfrd fir$ Gnfr

tt
u-tg zre fr ry+ n+x Frfto vm Frq,fr h BTEfl-{ Fql ryr +t{ rfr enieT qr ft G orm,

s{ Froq} h il€.ffi BRfqT b qdq fur lqr qrriiei qr fr T{ mffi qq* sri..i' I

udfrsirc + {rqqta * qrc taer elTaqrqsn,

s{ftdgmnwrq, qkd"

<!-- page 11 -->

' Hs 22 3T*fr 2017

2e4

gRRtss.

w

ucft*r.ra h ilgafr ro FreRft tg srsq

B{i-n

frqw
rmT0rilfoqr qrnefu

fr-dT......... .
Frqfufud erff E t

ffi T6 ard fr qffi

. 1. +a gfr'yE drlq6{t<rgert6tt
2. (o) T6 (qfu)

E ftqrEorflt=-dfrm'Frqrftt, qdfu': qa
znsor

t

:

t

stelql

(s) sso qTd-*t q t ot€ slstqt

(0 sq+h qrd-d E t qR oig frfr-d q d, at v{rol dq Glftqrqo prffiwl t .-frrrT d E

F{il{oqtoq1sqqtwwtt
3. sq.bqrn-olqtoi$$1o) rFw aINFI o-r tqRE ur

ffig< m{att t

STEIqI

g1il*+ arNFI o-f fiffi t, d u.der-G qrq { o-rf{a t,

4.

(6) T6r=u 961
STSHI

1u) sq+h srmm'qrw {

M qiq eqT t ot{ eraa €qfu, sq}t oTsrfl.qrsrq qsi t

t

wtt-+d ardfiTffidib-qm, qfu, +ifrSr$oqt.F-q1r6'arf ftq6 q6trrt :

5. ts-$i E-dW qr-\'q ererfl 3Tfuflftf, qeqqeer b fti-dt { Rrd fri{fr fr leTeu q{wlT q}
Tdqrq E EdE-r6 rw { eFqft--d t, ii znq t *., q{ oo erq-ft leTefi qltd fr tr

6. sqi E-.-dqre b frtifr rfr ft'reu i{FerT t Frqfrfod q$efl q B-ftuf fr d, ere;io:-

0l

<!-- page 12 -->

2e4 (tDl

u$qrr€tttT[d, fi{i*. 22 erftf, 2ot7
1o;

qRffiqwfl {q}er bfrr&qT fu-tfr qTr$ftqwtorE trqTbftr} oTiferdq{ffi
aterFrfi qlrqdr, qr.trflT qrw freqfuilmq

fr Hrffir qr vst s@cr-r wTfu FErfRf,
d, at sqerq qtqB-f, q$er qI afr oeil fr qtefl
r

(g) qR

ffi ii*erT { q}aT b frr} qr ffi fl-q-fu iirTil{ { +fl il ftq crnRrd q-{-dq

elerFro qtqcrl,

ffi fr fraqfrqrdq. qr +g ft eeq+e\'e

qlqqQI rgffr frqfkd fr T$ d, dt Gr-6fr mer fr qteil
1.r; srq

qrqat { qlqft oeil ft qtefl

arsrq

tffi

qT et$ Gil-t

t

t

7. GFzr q",fr qTq?rT h ffi w-Rtf,f, h' eraro FlqfufuT E t frrift ffi b qfu fi E-.ftq.r6 b
qrtflfuf, Frfl-{fr d}t:

py u.d-w.ra qrw { frg+a GTfu-d Hrdq-trqTd b eftrorRs} fr qdlqft ererqt
*iorq

r

eiffii mffi

ft qd I qft erpreT sorq
I
1q u.d-s.ra erttfi b.
q*flfto qT or€r frfuo. q-d w qqqfr mir frgm
1.q ucdu.ra trw {
q-d/qft eremr sdrq
q-€r.tru) q ftrs qr rs-d qf 3ildf,T { qEq+r
1u1 ucd-t+l-d {rs b orefl-q- w.rTfr--d
q-qTftmrfr/3Tfuqrrt/6ffi1, s{ft q-d/qft crerqr won
r

qffi ft

t

r

tt ereq d wr)ed qrq-qusT h et-gwn ffif,fr.o Frfl{ft d, w{ft q-d/qft orsur sf,H
cfr, E-.d-q-rd A- qrrflFdf, FHRfr qti

ur}t

t

qTftryil sTftrfi'rt+ a*dTefi

q$rFT\qfid

<!-- page 13 -->

u,ifi-ffi{rsq-d, frqis 22 er*d 2ol7

2e4

qRfeTfr - +

qr5q

TrcrtBfid q}S errnur-q*

furw+Bo,ddd

dqrfi{raqfr Fdiliqfl f }tEn,ffi
qt+ t.-ozz 1-22344s1, q,_ffi n. 0771-2222212
E-mai l -cgd me@rediffmai l. com

n{fr[0y

ffiot

qEIg{, R-{tzF
grITuI q5r

.n-eqt-Cqriqo.i
h)-d-Jrq-

ffiqflDrf,fuqrqrortfr-fr

fr-dT-

+fr

!.......!.............,

ss-..................q{ $rcqrft-d m'rd,:rO b sr}er{ Rqio..................b qtu qja,{ 611qrqrflq

tB+a +g h qqq q;r mqr+'.... ......,., fuip
qfretul Bq{if, ui-ft F?a*

............qftr4rf,*

....*'qSeM vq en-i<o b Wf

eTrfrfutr'ft:aEr(klt qr€.r$ t s+ft gn ft:aErrcrT

t

q6qm m-l fteTm-

(3ftrreD

(s{tq)

qrw+fufide}-g

qT-'q tB-m-d qtg

(s{{q)
q-qtkm.-dd-€

(tt)

<!-- page 14 -->

2e4 (t2l

Bdercttq[d, frqis 22 sTfrd 2017

qRRtse- fiq
Edqq-6 aTNFr b oreftT t-qT o-{i b qqu-q{ o-r !r-sErg'

sr-fficrf, qrs*t

{r{fr 6r

dqrfi{rdq {-qrtPq +il'}i

+iqr*rfr EEKr

vlqrqflq-qf,

3rfrrfrrtrd

irff, sH

--ft-flrqft--- -i fr{fo-----

qflFril fuqr qrsr t fr-sT
-*---rY

gqra.-

-----fr ci-qB { gm ------od------ qr6 rro ftfr-cqffi'il rq { w{ €qrf,{rdq

il 3rtft{ E-SsqE qrq { ftq e}r} + FgftTt-qr nErc ff*

(o)

-----------ftorq-*rs----------------fr-dT

r

g*nT -a.rrfrw-tR-48-d{ ehl-----q{---qrd

(s)--

fr

-om*rg---------------ffidTgd-s.ra.qffi ur-EBm-d-ot{ffl ------qS----qra

(,T)

fr

.+rq-ss---------------fu -dTg*ere-r{u-EBoe-d{*-+l---q{---qa

1u)

---------

Eorrcrs----------------fr-dT Grderc-nT{nl-+Boa-d{

h lercct tf1-

srrtfl-rqv+n trqr b ftri srrqem of gia

qrf,f,rt

r

*l---q{----qa
trsi6 ft

-eio}
dqrro,
v.qrq€qffi'

{qra-*, giur am A€? RTqrn, u-dqrrq enr rne*q

$undq, .*g t gBo o* r-"rR" _, o tr
