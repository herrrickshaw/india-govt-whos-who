---
doc_id: "ee6c76f5acc0cecd"
source_url: "https://cdnbbsr.s3waas.gov.in/s3db116b39f7a3ac5366079b1d9fe249a5/uploads/2026/09/202609031470631448.pdf"
ministry: "Chhattisgarh Ayush Counselling"
title: "EWS Rules and Regulation Dated: 03-09-2026"
date: ""
pages: 16
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "e8513beae7ef3300"
---

<!-- page 1 -->

पल छत्तीसगढ़ शासन
मा सामान्य प्रशासन विभाग
मंत्रालय
महानदी भवन, अटल नगर, जिला रायपुर
क.एफ-43-5 / 2049 / आ. प्र. / 4-3 अटल नगर, रायपुर, दिनांक 2.) /5,/ 2049
प्रति,
शासन के समस्त विभाग,
अध्यक्ष, राजस्व मण्डल बिलासपुर,
समस्त विभागाध्यक्ष,
समस्त संभागीय आयुक्त,
समस्त कलेक्टर्स,
समस्त मुख्य कार्यपालन अधिकारी (जिला पंचायत),
छत्तीसगढ़
विषय:-- आर्थिक रूप से कमजोर वर्गों (7५४७५) के लिए छत्तीसगढ़ राज्य में आय
एवं सम्पत्ति प्रमाण पत्र प्राप्त करने हेतु आवेदन पत्र का प्रारूप एवं अन्य
निर्देश।

संदर्भ:- इस विभाग का समसंख्यक आदेश दिनांक 30.4.2049.

आर्थिक रूप से कमजोर वर्गों (5५9/85) के लिए भारत सरकार के अंतर्गत लोक
पदों एवं सेवाओं में तथा शैक्षणिक संस्थाओं में प्रवेश में 40 प्रतिशत आरक्षण के संबंध में
भारत सरकार, कार्मिक लोक शिकायत एवं पेंशन मंत्रालय, कार्मिक एवं प्रशिक्षण विभाग के
कार्यालय ज्ञापन क्रमांक 36039 / 4 /2049--890(१७५), दिनांक 34.04.2049 द्वारा जारी किए
गए दिशाजनिर्देशों के अनुसार इस राज्य में आर्थिक रूप से कमजोर वर्गों (5985) के लिए
आय एवं सम्पत्ति प्रमाण पत्र जारी करने हेतु संदर्भित आदेश द्वारा अनुविभागीय अधिकारी

(राजस्व) / तहसीलदार को सक्षम प्राधिकारी नियुक्त किया गया है।

2/ इस विभाग के संदर्भित आदेश द्वारा आय एवं सम्पत्ति प्रमाण पत्र जारी करने हेतु

केवल सक्षम प्राधिकारी की नियुक्ति की गई है, उसमें आवेदन के प्रारूप एवं प्रकिया के

संबंध में स्थिति दर्शित न होने के कारण जिला कार्यालयों में उक्त प्रमाण पत्र जारी करने
के संबंध में विभिन्‍न कठिनाईयां आ रही हैं। अत: इस संबंध में निम्नानुसार निर्देश जारी
किए जाते हैं :-

4. आर्थिक रूप से कमजोर वर्ग के आवेदक को “आय एवं संपत्त्ति प्रमाण पत्र” प्राप्त
करने हेतु निर्धारित प्रारूप (परिशिष्ट-एक) में आवेदन-पत्र प्रस्तुत करना होगा।

2. आवेदकों को आवेदन पत्र में उल्लिखित दस्तावेज संलग्न प्रस्तुत करने होंगे।

3. सक्षम प्राधिकारियों द्वारा आय एवं संपत्ति प्रमाण पत्र जारी करने के संबंध में वही
प्रकिया अपनाई जाएगी, जो वर्तमान में आय प्रमाण पत्र जारी करने के लिए प्रचलित
है।

4. प्रमाण पत्र जारी करने के पूर्व उद्घोषणा एवं दावा आपत्ति के संबंध में कोई कार्यवाही
नहीं की जाएगी।

5. अनुविभागीय अधिकारी (राजस्व) तथा तहसीलदारों द्वारा उनके क्षेत्राधिकार की सीमा के
अंतर्गत ही उक्त प्रमाण पत्र जारी किए जाएंगे।

6. सक्षम प्राधिकारी द्वारा आवेदन अमान्य करने के विरूद्ध आवेदक द्वारा संबंधित जिला
कलेक्टर के समक्ष प्रथम अपील तथा संभागीय आयुक्त के समक्ष द्वितीय अपील प्रस्तुत
की जा सकेगी।

कमशः:....2
५):

<!-- page 2 -->

< 7. आवेदन के साथ प्रस्तुत साक्ष्यों / दस्तावेजों इत्यादि की समुचित जांच व परीक्षण
जारीकर्ता अधिकारी द्वारा किया जाए एवं स्वयं संतुष्ट होने के उपरांत ही प्रमाण पत्र
जारी किया जाए। मिथ्या साक्ष्य / दस्तावेज के आधार पर प्रमाण पत्र जारी होने पर
जारीकर्ता अधिकारी के विरूद्ध कार्यवाही उसी प्रकार की जाएगी जैसा कि मिथ्या
सामाजिक प्रास्थिति प्रमाण पत्र (जाति प्रमाण पत्र) जारी होने पर सक्षम प्राधिकारी के
विरूद्ध की जाती है।

8. भारत सरकार के कार्यालय ज्ञापन wSHim 36039/7/20I9 Estt (२०७), दिनांक
3..20i9 ERT Un दिशा निर्देशों की कंडिका 4.4 में आय एवं सम्पत्ति के संबंध में
दिए गए निर्देशों के अनुसार ऐसे उम्मीदवार जो अनुसूचित जाति अनुसूचित जनजाति
/अन्य पिछड़ा वर्ग एवं कीमीलेयर योजना के अंतर्गत नहीं आते हैं और जिनकी
पारिवारिक सकल वार्षिक आय रूपये 8.00 लाख (आठ लाख रूपये) से कम है, उनकी
पहचान आर्थिक रूप से कमजोर वर्ग के रूप में की जाएगी। आय एवं सम्पत्ति प्रमाण
पत्र में आय, आवेदन किए गए वर्ष से पहले के वित्तीय वर्ष में सभी स्त्रोतों, अर्थात्‌
वेतन, कृषि, व्यवसाय, पेशे एवं अन्य स्त्रोतों से हुई आय शामिल होगी। ऐसे उम्मीदवारों
की पहचान आर्थिक रूप से कमजोर वर्ग के रूप में नहीं की जाएगी जिनके परिवार के
पास उक्त ज्ञापन की कंडिका 4.4 में उल्लिखित कोई भी सम्पत्ति होगी, चाहे उनकी
पारिवारिक आय कुछ भी हो।

9. आवेदन पत्र में दी गई जानकारी एवं संलग्न दस्तावेजों का समुचित रूप से
परीक्षण / सत्यापन किया जाकर, आवेदन प्राप्ति की तिथि से अधिकतम एक माह के
भीतर प्रमाण पत्र जारी किया जाए।

छत्तीसगढ़ के राज्यपाल के नाम से
तथा आदेशानुसार,
(नि सर
सचिव
छत्तीसगढ़ शासन
सामान्य प्रशासन विभाग
UB. UH 3-6/20i9/39./i-3 Fea TR, Wag, feain 29/5 /209
प्रतिलिपि:-
4. राज्यपाल के सचिव, राजभवन, रायपुर। .
2. प्रमुख सचिव, मान. मुख्यमंत्रीजी, मंत्रालय, अटल नगर, रायपुर,
3. उप सचिव, मुख्य सचिव कार्यालय, मंत्रालय, अटल नगर, रायपुर,
4. रजिस्ट्रार जनरल, छत्तीसगढ़ उच्च न्यायालय, बिलासपुर,
5. सचिव, छत्तीसगढ़ विधान सभा सचिवालय, जीरो पाईंट, रायपुर,
6. समस्त निज सचिव,/निज सहायक, मान. मंत्रीगण, मंत्रालय, अटल नगर, रायपुर,
7. सचिव, छत्तीसगढ़ लोक सेवा आयोग, रायपुर,
8. महानिदेशक, छत्तीसगढ़ प्रशासन अकादमी, निमोरा, रायपुर,
9. मुख्य निर्वाचन पदाधिकारी छत्तीसगढ़, रायपुर,
40. सचिव, राज्य निर्वाचन आयोग छत्तीसगढ़, रायपुर
4. संचालक, जनसम्पर्क छत्तीसगढ़,
42. आवासीय आयुक्त, छत्तीसगढ़ भवन, नई दिल्‍ली,
43. सचिव, छत्तीसगढ़ लोक आयोग मानव अधिकार आयोग, रायपुर,
44. सचिव, छत्तीसगढ़ राज्य अनुसूचित जाति /अनुसूचित जनजाति,अन्य पिछड़ा वर्ग
आयोग, रायपुर।
कमश.....3

<!-- page 3 -->

45. संचालक, राज्य सूचना अधिकारी, राष्ट्रीय सूचना केन्द्र (गट), रायपुर की ओर
भारत सरकार, कार्मिक लोक शिकायत एवं पेंशन मंत्रालय, कार्मिक एवं प्रशिक्षण
विभाग के कार्यालय ज्ञापन क्रमांक 36039 / 4 / 2049--75/(२०७), दिनांक 49.04.2049
एवं कार्यालय ज्ञापन दिनांक 34.04.209 की छायाप्रति सहित सामान्य प्रशासन
विभाग की वेबसाईट ्ए:/छऋफ्त-280.०४-९०४-३/ पर अपलोड करने हेतु।

की ओर सूचनार्थ एवं आवश्यक कार्यवाही हेतु अग्रेषित । yy

छत्तीसगढ़ शासन
सामान्य प्रशासन विभाग

<!-- page 4 -->

4 परिशिष्ट--एक
आर्थिक रूप से कमजोर वर्ग के लिए आय एवं संपत्ति प्रमाण पत्र प्राप्त करने हेतु
, आवेदन-पत्र का प्रारूप
प्रति, स्व-प्रमाणित
पासपोर्ट साईज
अनुविभागीय अधिकारी(रा) / तहसीलदार, नवीनतम फोटो
जिला..............................छ.ग.)।
महोदय,
निवेदन है कि मुझे मेरे पुत्र,मेरी पुत्री को केन्द्र सरकार के अंतर्गत लोक पदों एवं
सेवाओं में नियुक्ति हेतु /शैक्षणिक संस्थाओं में प्रवेश प्राप्त करने हेतु आर्थिक रूप से कमजोर वर्ग
के लिए निर्धारित 40 प्रतिशत आरक्षण का लाभ प्राप्त करने हेतु भारत सरकार द्वारा निर्धारित प्रारूप
में आय एवं संपत्ति प्रमाण पत्र की आवश्यकता है। इस संबंध में मेरे द्वारा निम्नानुसार जानकारी
प्रस्तुत है:-
4. आवेदक का पूरा नाम (हिन्दी में)
2. आवेदक के पिता का पूरा नाम (हिन्दी में)
3. हितग्राही का नाम (जिसके लिए (हिन्दी में)
प्रमाण पत्र चाहा जा रहा है) , अंग्रेजी में)
4. हितग्राही की जन्मतिथि अंकों में.
शब्दों में.
अविवाहित
स्थानीय निवासी है ?
हु 7. आवेदक» हितग्राही का पूरा पत्ता अ. वर्तमान पता-
(ग्राम / नगर, पटवारी हल्का नं. ग्राम......................पोस्ट आफिस,
तहसील एवं जिला सहित) तहसील.......................जिला.
ब. स्थाई पता-
ग्राम...............................पोस्ट आफिस.
8. हितग्राही की जाति जाति................................उपजाति.
(उपजाति सहित)
9. क्या हितग्राही अनारक्षित वर्ग का है? ...........................-9+«_-न--+---आतततननत?णनननलि?ननगनननननिताननन
(हां,/ नहीं)
कमशः...2

<!-- page 5 -->

eyo De
of
ad to. free frit of F uRae at ea ara Bt जानकारी :-
संबंध (वैतन / कृषि,/ व्यवसाथ ,” कारोबार // भूमि //
मकान, अन्य स्त्रोत से प्राप्त आय की
जानकारी पृ पृथक दी जाए)
PT PT
PO कह | ऋ[€ऋ£ऋ£&ख ऋ ख/_$झऋ£ [  रफ
a a [7 |
i fied facie af FY uRa के उक्त सदस्यों की सम्पत्ति की जानकारी :-
है
(रकबा एकड़ में | (क्षेत्रफल वर्ग फूट में एवं पालिकाओं में घारित पालिकाओं के
एवं किस राज्य | किस राज्य में स्थित है) आवासीय भू-खण्ड अलावा अच्य क्षेत्रों में
में स्थित है) क्षेत्रफल वर्ग गज में एवं आवासीय भू-खण्ड
किस राज्य में रिथित है) | (क्षेत्रफल बर्ग गज में एवं
किस राज्य में स्थित है)
ृ रू [ | [
न [| [ई£ |[
a ट[[भ् [| |
42. आवेदन पत्र के साथ () आधार कार्ड /अन्य फोटोयुक्त परिचय पत्र की छायाप्रति,
संलग्न दस्तावेजों की (2) जन्मतिथि की पुष्टि हेतु प्रमाण पत्र की छायाप्रति,
सूची (3) छ.ग. के स्थानीय निवासी प्रमाण पत्र की छायाप्रति,
(4) वेतन से आय के संबंध में नियोक्‍ता का प्रमाण पत्र
(व्यवसायी / शासकीय सेवकों के लिए गत वित्तीय वर्ष के आयकर
रिटर्न की छायाप्रति),
(5) भूमि,/मकान से आय के संबंध में अनुबंध पत्र की छायाप्रति/
स्वघोषणा पत्र, :
(6) अन्य स्त्रोतों से आय के संबंध में प्रमाण पत्र /स्वधयोषणा पत्र,
(7) आवासीय फ्लैट,“मकान की रजिस्ट्री की छायाप्रति
(8) कृषि भूमि के संबंध में बी-4 खसरा,/ऋण-पुस्तिका की छायाप्रति,
(9) आवासीय भू-खण्ड की रजिस्ट्री की छायाप्रति
(0) पासपोर्ट साईज एक अतिरिक्त फोटो।
(॥१) अन्य दस्तावेज जो सक्षम अधिकारी द्वारा मांगे जाए।
मैं प्रमाणित करता/करती हूं कि मेरे द्वारा आवेदन पत्र में दी गई उपरोक्त जानकारी मेरे
ज्ञान और विश्वास के अनुसार सत्य है और मैं आर्थिक रूप से कमजोर वर्ग के लिए आरक्षण सुविधा
प्राप्त करने हेतु पात्रता धारण करता,करती हूँ। यदि मेरे द्वारा दी गई जानकारी असत्य/गलत
पाई जाती है, तो मैं पूर्ण रूप से जानता/जानती हूँ कि इस आवेदन पत्र के आधार पर दिए गए
प्रमाण-पत्र के आधार पर लोक सेवाओं में प्राप्त की गई नियुक्ति निरस्त कर दी जाएगी शैक्षणिक
संस्थान में लिया गया प्रवेश निरस्त कर दिया जाएगा अथवा इस प्रमाण पत्र के आधार पर कोई
अन्य सुविधा / लाभ प्राप्त किया गया है, उससे भी वंचित किया जा सकेगा और इस संबंध में विधि
एवं नियमों के अधीन मेरे विरूद्ध की जाने वाली कार्यवाही के लिए मैं उत्तरदायी रहूंगा।
आवेदक के हस्ताक्षर
तथा नाम

<!-- page 6 -->

F. No.36039/2/209-Est:.(Res.)
Government of India
Ministry of Personnel, Public Grievances and Pensions :
Department of Personnel and Training
North Block, New Delhi
49" January, 20/9
OFF CE MEMORANDUM

Subject: Reservation for Economically Weaker Sections (EWSs) in civil posts

and services in the Gevernment of India
Reference is invited to Ministry of Social Justice and Empowerment O.M. No.
F No.20073/0/208-BC-li dated 7,4.209 on the above mentioned subject, which,

inter-alia, reads as under:-

“4. In pursuance of insertion of clauses 756) and 76(6) in the Constitution
vide the Constitution (One Hundred and Third Amendment) Act, 2079 and in
order to enable the Economically Weaker Sections (EWSs) who are not
covered under the existing scheme of reservations for the Scheduled Castes,
the Scheduled Tribes and the Socially and Edueationally Backward Classes.
to receive the benefits of reservation on a preferential basis in civil posts and
services in the Government of India and admission in Educational institutions.

. if has been decided by the Government to provide 0% reservation to EWSs
in civil posts and services in Government of India and admission in
Educational Institutions *
2, Persons who are not covered under the existing scheme of ‘

. reservations for the Scheduled Castes, the Scheduled Tribes and the Socially
and Educationally Backward Classes and whose family has gross annual
: income below Rs. 8.00 lakh ate to be identified as EWSs for the benefit of
reservation. Family for this purpose will include the person who seeks benefit
of reservation, his/her parents and siblings helow the age of 8 years as also
his/her spouse and children below the age of 78 years. The income shall
include income from all sources i.e. salary, agriculture, business. profession
ete. and it will be income for the financial year prior to the year of application
Aiso persons whose family awns or possesses any of the following assets
shall be excluded from being identified as EWSs. irrespective of the family
income: ‘@
i. S acres of Agricultural Land and above; :
ii, Residential flat of 7500 sq. ft. and above:
iii, Residential plot of 790 sq. yards and above in notified municipalities;
iv. Residential plot of 200 sq. yards and above in areas other than the
notified municipalities.
3. The income and assets of the familics as mentioned in para 2 would be
required to be certified by an officer not below the rank of Telisifdar in the
States/UTs. The officer wha issues the certificate would do the same after
i
OYpiraincte To Jenthy”
. Y, / Pelg

<!-- page 7 -->

carefully verifying all relevant documents following due process as prescribed
by the respective State/ UT.
5 Instructions regarding reservation in employment and admission to
educational institutions will be issued by DOPT and Ministry of HRD
respectively.”
2. in pursuance of the above Office Memerandum, it is hereby notified that 0%
reservation would be provided for Economically Weaker Sections (EWSs) in central
government posts and services and would be effective in respect of all Direct
Recruitment vacancies to be notified on or after 04.02,2079.
3. Detailed Instructions regarding operation of roster and procedure for
implementation of EWS reservation will be issued separately.
° re Ty 7 oath \
Loenrerrtcr NURS
( Gyanendra Dev Tripathi) "Vel forg
Joint Secretary to the Government of India ,
To
4. The Secretaries of all Ministrias/Departments of the Government of India.
2. Department of Financial Services, New Delhi
3. Department of Public Enterprises, New Delhi है
4, Railway Board, Ministry of Railways, Rail Bhavan, New Delhi .
5. Secretary, Ministry of Human Resourses Development, Shastri Bhavan,
New Delhi.
हि 6. Supreme Court of India/Election Commission of Indiaf Lok Sabha
Secretariat’ Rajya Sabha Secretariat) Cabinet Secretariat/ Central
Vigilance Commission/ President's Secretariat) Vice President's
Secretariat /Prime Minister's Office/ NIT! Aayog
7. Union Public Service Conimission / Staff Selection Commission
8, Secretary, Ministry of Social Justice and Empowerment, Shastri Bhawan,
New Delhi
9. National Commission for Scheduled Castes, Lok Nayak Bhawan, New
Delhi
40. Natianal Commission tor Scheduled Tribes, Lok Nayak Bhawan, New
Deihi .
44. National Commission for Backward Classes, Trikoot-7, Bhikaji Cama. -
Place, R.K. Puram, New Delhi
42. Office of the Comptroller and Auditor General of India
43. information and Facilitation Center, UoPT, North Block, New Delhi.
i4. Director. ISTM, Old JNU Campus, Oiof Palme Marg, New Delhi 770067
॥5$... NIC, DoPT — to upload the same on DoPT website.
46. - Hindi Section for providing a Hindi translation
2

<!-- page 8 -->

. ‘ No.36039//2049-Estt (Res) oF
, Government of India :
Ministry of Personnel, Public Grievances & Pensions o
: Department of Personnel & Training .
. है North Block, New Delhi
: oe dated the 34%tJanuary, 20I9
, OFFICE MEMORANDUM
, Subject: Reservation for Economically Weaker Sections (EWSs) in direct रु
है recruitment in civil posts and services in the Government of India. .
per le - In continuation of this Department’s Office Memorandum of even nuniber .
i | dated 9.04.2049, the following instructions are issued in consultation with ~
' ' Ministry"of Social Justice and Empowerment and Department of Legal. Affairs © ©
. regarding reservation for EWSs not covered under the reservation scheme for
SCs/STs/OBCs in respect of direct recruitment in civil posts and services.ii the
“Government of India. * ः ; *
2, QUANTUM OF RESERVATION =
‘The persons belonging to EWSs who, dre not covered under the scheme of
_ Yeservation for SCs, STs and OBCs shall get 0% reservation in direct recruitment =
in civil posts and services in the Government of India. : on
3. EXEMPTION FROM RESERVATION: ae /
3.. “Scientific and Technical” posts which satisfy all the following conditions can
be exempted from the purview of ‘the reservation orders by the Ministries/
Departifents: न .
(i) The posts should be in grades above the lowest grade in Group A of the
serviceconcerned. . — .
(ii) They should be classified as “scientific or technical” in terms of Cabinet
Secretariat [OM No. 85/44/CF-6I(4) dated 28.2.4964], according to which
. scientific and technical posts for which qualifications in the natural sciences
or exact sciences or applied sciences.or in technology are prescribed and the
' incumbents of which have to use that knowledge in the discharge of their —_
duties. ere
हु . हे cs (ी:६५६+4-- .

<!-- page 9 -->

s है oo OAS
. a .
LO (iit) The posts should be ‘for conducting research’ or ‘for organizing, guiding
and directing research’. -
. .32 Orders of the Minister concerned should be obtained before exenipting any
posts satisfying the above condition from the purview of the scheme of reservation.
4, CRITERIA OF INCOME & ASSETS:
44 Persons who are not covered under the scheme of reservation for SCs, STs
"and OBCs and whose family has gross annual income below Rs. 8.00 lakh (Rupees
eight lakh only) are to be identified as EWSs for benefit of reservation. Income
‘shall. also include income from all sources ie. salary, agriculture, business,
profession, etc. forthe financial year prior to the year of application. :
: Also persons whose family owns or possesses any of the following assets -
shall be excluded from being identified as EWS, irrespective of the family income:-
i. 5.acres of agricultural land and above; -
3 ii, Residential flat of 000 sq: ft. and above; .
iii, Residential plot of L00 sq. yards and above in notified municipalities;
iv. Residential plot of 200 sq. yards and above in areas other than the
notified municipalities. न
4.2, The property held by a “Family” in different locations or different places/cities —
would be clubbed while applying the land or property holding test to determine
EWS status, , ,
4.3. The term “Family” for this purpose will include the person who seeks benefit
of reservation, his/her parents-and siblings below the age of 28 years as also
. his/her spouse and children below the age of 8 years. *
ह 5. INCOME AND ASSET CERTIFICATE ISSUING AUTHORITY AND FICATE ISSUING AUTHORITY _AND
VERIFICATION OF CERTIFICATE:
“5.4 The benefit of reservation under EWS can be availed upon production of an
Income and Asset: Certificate issued by a Competent Authority. The Income and
Asset Certificate issued by any one of the following authorities in the prescribed
. format as given in Annexure-I shall only be accepted as proof of candidate’s claim
"as belonging to EWS: - : . हु
 [].. शत Magistrate/Additional District Magistrate/ Collector/ Deputy
: Commissioner/Additional. Deputy Commissioner/is* Class Stipendary ~

<!-- page 10 -->

: 3
: Magistrate/ Sub-Divisional Magistrate/ Taluka Magistrate/ Executive
Magistrate/ Extra Assistant Commissioner
(ii) Chief Presidency Magistrate/Additional Chief Presidency Magistrate/
Presidency Magistrate ce रथ oo
(iii) Revenue Officer not below the rank of Tehsildar and
(iv) Sub-Divisional Officer or the area where the candidate and/or his family
normally resides. . . है . -
5.2 The Officer who issues the certificate would do the same after carefully
-  verlfying ali relevant documents following due process as prescribed by the
respective State/UT.
. 5.3 The crucial date for submitting income and asset certificate by the candidate
_ Iaay be treated as the closing date for receipt of application for the post, except in
है cases where crucial date is fixed otherwise. - ,
9.4 The ‘appointing authorities should, in the offer of appointment to the
candidates claiming to be belonging to EWS, include the following clause :- *
“The appointment is provisional and is subject to the Income and asset
certificate. being verified through the proper channels and if the verification
reveals that the-claim to belong to EWS is fake/false the services will be
: terminated forthwith without assigning any further reasons and without
prejudice to such further action as may be taken under the provisions of the
Indian Penal Code for production of fake/false certificate.”
5 ’ The appointing authority should verify the veracity of the Income and asset
4 certificate submitted by the candidate through the certificate issuing authority.
5.5 Instructions referred to above should be strictly followed so that it may not
be possible for an unscrupulous person to secure employment on the hasis of a
false claim and if any person gets an appointment on the basis of such false claim,
her/his services shall be terminated invoking the conditions contained in the offer
ofappointment. है हु
6. EFFECTING RESERVATION - MAINTENANCE OF ROSTERS:
6.. Department of Personnel and Training had circulated Office Memorandum
No.360i2/2/96-Estt{Res) dated July.2, 997 regarding implementation of post |
based reservation roster. The general principles for making and operating post
* ह : Cy. Din tuasen
