---
doc_id: "d3160b1a35dafebb"
source_url: "https://cspc.co.in/cspc/csptcl/CSR%20Policy/CSR%20Policy%20410-01062022.pdf"
ministry: "Chhattisgarh State Power Generation Co. Ltd."
title: "CSR Policy"
date: ""
pages: 16
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "ab9a026a743e19fe"
---

<!-- page 1 -->

Cc PT C
% L
उत्तीसयढ़ स्टेट पॉवर ट्रांसमिशन कंपनी लिमिटेड
CHHATTISGARH STATE POWER TRANSMISSION
COMPANY LIMITED
(A Govt. of Chhattisgarh Undertaking)
CIN -U40I08CT2003SGC0I5820
Reg. Office:-Vidyut Sewa Bhawan, Dangania, Raipur (C.G.) — 4920] 3
CORPORATE SOCIAL RESPONSIBILITY (CSR)
POLICY
\

<!-- page 2 -->

CORPORATE SOCIAL RESPONSIBILITY POLICY

(A) Introduction:-

Chhattisgarh State Power Transmission Company Ltd. (CSPTCL) was incorporated on 7"

May, 2003 under the Companies Act, 956. The Company is a wholly owned Government of

Chhattisgarh Undertaking and a State Government Company under the provisions of the

Companies Act.

CSPTCL aims to actively contribute to sustainable socio-economic development of the local

community and society at large, including its employees and their families, so as to improve

the quality of life.

Formulation of CSR Policy is mandatory for a company to which section 35 of the

Companies Act 20I3 is applicable. As per this Section, every company having net worth of

Rs. 500.00 core or more, or turnover of Rs. 000.00 crore or more or a net profit of Rs. 5.00

crore or more during any financial year shall constitute a Corporate Social Responsibility

Committee of the Board. Since CSPTCL is covered under the above provisions of the

Companies Act, 203, the Company has framed its CSR policy which is applicable to all its

Circles/Divisions & Corporate Office.

(B) Objective:-

The main objective of CSR policy is —

** To lay down guidelines for compliance with the provisions of the regulations to dedicate
a percentage of profits of the Company for social projects.

* To directly/ indirectly undertake projects/programs which will enhance the quality of life
and economic well-being of the communities in and around the work site and society at
large.

(C) Activities :-

The scope of the CSR activities of the Company will cover the following areas but is not

limited to the same and may extend to other specific projects/ programs as permitted under

the law from time to time:-

EDUCATION

“+ Counseling of villagers to encourage their children for education and Conduct
awareness programmes for promotion of girl education.

“ Special attention on education, training and rehabilitation of Project Affected
People

* Special attention on education, training and rehabilitation of mentally &
physically challenged children/persons.

“+ Academic education by way of financial assistance to Primary, Middle and Higher 7
Secondary Schools.

*» Providing Scholarships to the meritorious students of the schools in the Project
Affected Areas.

* Support to Technical/Vocational Institutions for their self- development.

* Adult literacy especially amongst those belonging to Below Poverty Line (BPL).

“» Spreading legal awareness amongst people and disadvantageous sections of the
society about their rights & remedies available.

<!-- page 3 -->

HEALTH CARE

Organizing Mobile Clinics/ medical camps in the villages of Project Affected
Areas.

“> Organizing general awareness camp for the surrounding villages to make the
people realize the harmful effects of social evils like smoking, alcohol, drug abuse
etc.

¢ Conduct Aids, TB and Leprosy awareness programmes in Project affected areas.

“ Diet and Nutrition awareness

* Blood donation camps.

“ Diabetics detection & Hypertension Camps.

“ Promotion of Family Planning activities.

“» Senior Citizen Health Care.

“ To supplement the different programmes of Local/State Authorities like Swacch
Bharat Abhiyan etc.

SPORT AND CULTURE

“ Promotion of sports activities in nearby villages by conducting tournaments in
sports such as Football, Kabaddi, Khokho, etc.

> Providing sports materials for Football, Volleyball, Hockey sticks ete to the young
and talented villagers.

+ Sponsorship of Sports event in the Project affected areas.

* Support for development of play grounds in Project affected areas.

“ Promotion of State level sports/games teams.

+ Sponsorship of National Sports events in Power Station & Corporate office areas.

> Sponsorship of Cultural event to restore Indian Cultural Traditions and Values.
+ Providing sports facilities for physically handicapped persons.
“ Promotion of Art & Culture.
“ Protection of Heritage sites.
INFRASTRUCTURAL DEVELOPMENT
“ Construction / repairs of community halls, road, bridges, culverts, check dam,
auditorium, play ground, sports, complex, parks, garden, night shelters,
orphanages, old age homes etc.

“ Providing Street lighting.

“Providing furniture &equipments to educational institutions.

“Development of public utilities and sanitation facilities.

<* Tree plantation including fruits trees.

Construction of public cremation ground /burial grounds.

“* Creating common grazing land/ small distributaries for irrigation.

DISASTER MANAGEMENT

Relief for victims of Natural Calamities like Earth Quake, Cyclone, Draught and
Flood situation in any part of the country. 5

“> Relief for family members of Army Personnel losing their lives at War.

“+ Disaster © Management Activities including _ those related to
amelioration/Mitigation.

ENVIRONMENTAL PROTECTION & CONSERVATION PROTECTION & CONSERVATION

“> Organizing sensitizing programmes on Environment Management and Pollution
Control.

“* Green Belt Development

<!-- page 4 -->

“* Create awareness for adoption of environmental friendly technologies in everyday
life

* Aforestation, Social Forestry, Check Dams, Park.

“ Restoration of barren lands.

* Development of jobs related to agro product i.e. Dairy/Poultry/farming and others.

* Plantation of saplings producing fruit.

“ Animal care-Vaccination &Checkup.

EMPOWERMENT.

“ Imparting Vocational Training to rural youth on Welding, Fabrication, Motor
Winding and other professional expertise.

“ Organizing training programmes for women on tailoring Embroidery designs,
Home Foods/Fast Foods, Pickles, Painting and Interior Decoration and other
Vocational Courses.

के Setting-up skill development centres for youth, women, girls etc.

*» Empowerment of women for education / health &self employment.

“* Capacity building of the Project affected persons (PAPs) to improve their
employability.

“ Care for senior citizens, physically challenged, destitute women, widow.

* Improving lives of people belonging to Scheduled Caste & Scheduled Tribe.

* Adoption/construction of Hostels (specially those for SC/ST & girls)

LIVELIHOOD DEVELOPMENT

“ To provide assistance to villagers having small patch of land to develop
mushroom farming, medicinal plants, vegetable farming & other cash crops to
make them economically dependent on their available land resources. Training
may be provided by agricultural experts for above farming.

** Promotion of livelihood/ Employment facilities to the community especially to the
backward & weaker section by providing education and training thereby
developing their skill for suitable employment. Further opportunities for self-
employment should be provided by constructing Shopping Complex in and around
the projects.

* Self Help Groups (SHGs) should be formed by active participation of local people
for setting up Dairies, Poultries etc, which will also help to generate self-
employment.

* Placement assistance programs for youth.

“ Grant/donation/financial assistance/sponsorship to reputed NGOs of the Society
/locality doing/involve in upliftment of the standard of the society.

NATURAL RESOURCE MANAGEMENT

“+ Water Supply to village through mobile Tanker in summer till permanent
Arrangement. ५

“ Installation/Repair of Hand Pumps/Tube Wells.

* Digging/Renovation of Wells & other irrigation facilities.

“ Gainful utilization of waste water through treatment plants for cultivation or any
other purpose.

* Development/construction of Water Tank/Ponds.

“ Rain water-harvesting scheme.

“ Formation of a Task Force of Volunteers to educate people regarding proper use
of drinking water.

“ Empowerment to the villagers for maintenance of the above facilities for
availability of water.

<!-- page 5 -->

The Above list is illustrative and not exhaustive. CSR Committee may also consider CSR

activities not falling in this list. The Act provides that the Company shall give preference to

the local area and areas around it where it operates, for spending the amount earmarked for

Corporate Social Responsibility. Thus, the Company will give preference to conducting CSR

activities in the state of Chhattisgarh wherein the Company has/will have its operations.

However, the Committee may identify such areas other than stated above, as it may deem fit,

and recommend it to the Board of Directors for undertaking CSR activities.

(D) Exclusion from CSR :-

The following activity shall not form part of the CSR activities of the Company:-

a) The activities undertaken in pursuance of normal course of business of the Company.

b) CSR projects/ programs or activities that benefit only the employees of the Company and
their families.

c) Any contribution directly/ indirectly to political party or any funds directed towards
political parties or political causes.

d) Any CSR projects/ programs or activities undertaken outside India.

(E) CSR Committee:-

+ As per provisions of the Companies Act, 203, the CSR Committee should consist of
minimum three or more directors. The Board of Directors of the Company, in its meeting
held on 0I.2.20!7 has constituted CSR Committee consisting of the following
directors:-

SE ee ee
l. | Addl. Chief Secretary / Principal Secretary / Secretary, Finance,
Government of Chhattisgarh
‘Addl. Chief Secretary / Principal Secretary / Secretary, Energy,
Government of Chhattisgarh
Managing Director, CSPTCL

+ The CSR Committee shall be responsible for implementation/ monitoring and review of
this policy and various projects/ activities undertaken under the policy. The CSR
Committee shall submit periodical reports to the Board of Directors.

(F) CSR Officer :-

The Chairman of the Company shall designate CSR officer of the Company.

« The CSR Officer shall be responsible for the proper implementation and execution of
CSR Projects of the Company.

« The CSR Officer shall be responsible for monitoring the Projects vis-a-vis the Annual
Plan.

« The CSR Officer shall communicate the relevant feedbacks received by him to the CSk
Committee.

* The CSR Officer shall be directly responsible to the CSR Committee.

+ The CSR Officer shall be assisted by a select group of individuals who shall be
exclusively dedicated and/or available on priority basis to the CSR Officer, as and when
required in discharge of all or any of his functions as required under the CSR Policy.

(G) Budget & Funding :-

+» The Company shall spend, in every financial year, at least two percent of the average net
profits of the company made during the three immediately preceding financial years, in
pursuance of its Corporate Social Responsibility Policy.

<!-- page 6 -->

+ The CSR Committee shall prepare and submit a CSR Annual Plan to the Board of

Director for the approval which shall include:
a) Identified CSR Projects
b) CSR expenditure

+ Total expenditure in the CSR Annual Plan shall be approved by the Board upon
recommendation by the CSR Committee. The amount sanctioned by the Board will have
to be utilised for the projects/ programs as specified by the CSR committees.

‘> The unspent amount, if any, at the close of the financial year shall be retained and shall be
spent only on specified projects/ programs in the next financial year.

+ Any surplus arising out of the contribution made for CSR Activities shall not form part of
the business profit of the Company and redeployed for such activities.

+ All administrative expenses including expenditure on wages & salaries, tours and travels,
training & development of personal deputed on CSR activities would be borne from CSR
funds.

(H) Implementationof CSR Projects :- .

* The Company may itself implement the identified CSR Projects presently within the
scope and ambit of the areas as defined in the Policy.

« The Company shall ensure that in identifying its CSR Projects, preference shall be given
to the local area and areas around which the Company operates. However, this shall not
bar the Company from pursuing its CSR objects in other areas.

+ The Company may engage external professionals/firms/agencies if required, for the
purpose of implementation of its CSR Projects.

() Monitoring :-

Monitoring process for CSR Projects shall include the following.

a) Evaluation of Planned progress V/s Actual Progress.
b) Actual expenditure V/s expenditure as per Approved Budget.

+ The CSR Committee shall monitor the implementation of the CSR Policy and CSR
Plan and report to the Board from time to time. The Board of Directors shall ensure
that activities included by a company in its Corporate Social Responsibility Policy
are related to the activities included in Schedule VII of the Act.

« CSR Plan may be revised/ modified/ amended by the CSR Committee at such
intervals as it may think fit.

(J) Disclosures :-

« The Company is required to disclose in its Board’s Report an Annual Report on
CSR containing the following :-

Y A brief outline of the company's CSR Policy, including overview of projects .
or programs proposed to be undertaken and a reference to the web-link to the
CSR policy and projects or programs;

Y The composition of the CSR Committee;

v Average net profit of the company for last three financial years;

v Prescribed CSR Expenditure (2% of the amount of the net profit for the last 3
financial years);

Y Details of CSR spent during the financial year;

Y Incase the company has failed to spend the 2% of the average net profit of the
last three financial year, reasons thereof;

<!-- page 7 -->

Y A responsibility statement of the CSR Committee that the implementation and
monitoring of CSR Policy, is in compliance with CSR objectives and Policy
of the Company;

(K) GENERAL:-

* In case of any doubt with regard to any of the provisions of this Policy and also in
respect of matters not covered herein, a reference may be made to the CSR
Committee. In all such matters, the interpretation and decision of the CSR
Committee shall be final.

+ The provisions of the CSR Policy shall stand modified in accordance with the
provisions of the Companies Act / Companies CSR Rules, as amended from time
to time and the applicable Government guidelines.

“ The CSR Committee reserves the right to modify, add, or amend any of provisions
of this Policy subject to the approval of the Board of Directors.

* CSR Committee shall meet at such intervals as may be required.

<!-- page 8 -->

C#PTCL CHHATTISGARH STATE POWER TRANSMISSION CO. LTD.
eons ea pen eh wave (A Govt. of Chhattisgarh Undertaking)
— CIN - U4008CT2003SGC05820
Registered Address:- Vidyut Sewa Bhawan, Dangania, Raipur-492023 (C.G.)
Ee
i Sr. = ACTIVITIES Location a
No. ete ae
l | Tree plantations Jora-Saddu Road, Raipur &
Bidhola -Karnala Raod,
: 5 ie fale Kabirdham हे
2 00 '0.5 of Rain Water Harvesting
| Systems in consultation with local Raipur, Durg & Bialspur
| Authorities like Nagar Nigam/Nagar
Palika. es = oo व व शक
हि | Various works as proposed by Gram Village- Pander, |
aa Panchayat at Village Pander. _ Dur; _—
4 Establishment of Integrated Animal Village- Nagri,
| DevelopmentCenter, Dhamtari
LE Project for filling of Ponds by Solar Kharun River side,
| Powered System from Rivers/Anicut by eal
__|_ CREDA. Pe
6 | Solar Community Irrigation Scheme. Village- Parsulidih,
| =I _ ___ Raipur
| 7 Up-gradation of Shringi Rishi Govt. Higher Village- Nagri,
| [5 Secondary School, Nag Mae i Manterancesoi | Block ना
8 Up-gradation, Creation & Maintenances of Block- Patan,
various Health Centers, Covi Hospiaisy Hospitals Distt.-Durg
|_| Isolation Centers. _

<!-- page 9 -->

_ THE GAZETTE OF INDIA: EXTRAORDINARY [700 व--88८. 30)]
घोषणा
मैं कंपनी के निदेशक मंडल द्वारा संकल्प संख्या .....................--«« द्वारा तारीख ................... द्वारा इस प्ररूप पर
हस्ताक्षर करने और यह घोषित करने के लिए प्राधिकृत हूं कि कंपनी अधिनियम, 2043 की सभी आवश्यकताओं और इसके
अधीन बनाए गए नियमों के संबंध में इस मामले का अनुपालन किया गया है। मैं आगे घोषणा करता हूं कि:
43. इस प्ररूप में और इसके संलग्नक में जो कुछ भी कहा गया है वह सत्य, सही और पूर्ण है और इस प्ररूप की विषय
वस्तु से संबंधित कोई भी सूचना सामग्री को छुपाया या छुपाया नहीं गया है और कंपनी द्वारा बनाए गए मूल रिकॉर्ड के
अनुसार है।
44... सभी आवश्यक संलग्नक इस प्ररूप के साथ पूरी तरह से और स्पष्ट रूप से संलग्न किए गए हैं।
निदेशक द्वारा डिजीटल रूप से हस्ताक्षरित किया जाना है। ase RPP:
*डिजीटल रूप में हस्ताक्षरित किया जाना है डीएससी बॉक्स Pre
*पदनाम ......................--०------
निदेशक का डीआईएन ....................-०००
टिप्पणः कंपनी अधिनियम, 2043 की धारा 448 और 449 के उपबंधों की ओर ध्यान आकर्षित किया जाता है जिनमें क्रमशः
धोखाधड़ी, मिथ्या और मिथ्या साक्ष्य के लिए दंड का प्रावधान है।
यह ई-प्ररूप इलेक्ट्रॉनिक मोड के माध्यम से तथा फाइल करने वाली कंपनी द्वारा प्रस्तुत विवरण की सत्यता के आधार पर
कंपनी रजिस्ट्रार द्वारा फाइल में रख दिया गया है।
सेव प्ररूप चैक करें परियोजना आईडी बनाएं प्रस्तुत करें
[फा.सं./]9/203-सीएल . ए-भाग-ता]
के.बी.आर. मूर्ति, संयुक्त सचिव
टिप्पण: मूल नियम भारत के राजपत्र में संख्यांक सा.का.नि. 239 (अ), तारीख 3 मार्च, 2044 के अधीन प्रकाशित किए
गए थे और बाद में अधिसूचना संख्या सा.का.नि. 723 (अ), तारीख 4 aaa, 2044, सा.का.नि. 37 (अ) तारीख 46
जनवरी, 2045, सा.का.नि. 680 (अ), तारीख 4 सितंबर, 2045, सा.का.नि. 742 (अ), तारीख 27 जुलाई, 2046,
सा.का.नि. 4374 (a), तारीख 7 नवंबर, 2047, सा.का.नि. (94 (a), aera 27 Heat, 208, ATA. 725 (3),
artra 34 Garg, 2048, ara. ft. 803 (a), तारीख 22 अक्टूबर, 209, सा.का.नि. 60 (अ), तारीख 30 जनवरी,
2020 और सा.का.नि. 205(अ), तारीख 24 मार्च, 2024 द्वारा संशोधित किए गए थे।
MINISTRY OF CORPORATE AFFAIRS
NOTIFICATION
New Delhi, the l]th February, 2022

G.S.R. 07(E).—In exercise of the powers conferred by sub-sections (l) and (3) of section 28, sub section (3)
of section 29, section 33, section 34, sub-section (4) of section 35, sub-section (l) of section 36, section 37 and
section ]38 read with section 469 of the Companies Act, 203 (I8 of 20I3), the Central Government hereby makes
the following rules further to amend the Companies (Accounts) Rules, 204, namely:- 7
I, () These rules may be called the Companies (Accounts) Amendment Rules, 2022.
(2) They shall come into force on the date of their publication in the Official Gazette.
2. In the Companies (Accounts) Rules, 204 (hereinafter referred to as the said rules), in rule 2, after sub-rule (lA),
the following sub-rule shall be inserted, namely: -
“(IB) Every company covered under the provisions of sub-section (l) to section 35 shall furnish a report on
Corporate Social Responsibility in Form CSR-2 to the Registrar for the preceding financial year (2020-202) and
onwards as an addendum to Form AOC-4 or AOC-4 XBRL or AOC-4 NBFC (Ind AS), as the case may be:
Provided that for the preceding financial year (2020-202l), Form CSR-2 shall be filed separately on or before
3* March 2022, after filing Form AOC-4 or AOC-4 XBRL or AOC-4 NBEC (Ind AS), as the case may be.”.
3. In the said rules, in the Annexure, after Form AOC-4 CFS, the following form shall be inserted, namely:-

<!-- page 10 -->

भागा खण्ड 30) TTS ननन नननननननननननन नमन न 30)] भारत का राजपत्र : असाधारण 9
= as es Report on Corporate Sol
[Pursuant to sub-rule (IB) of Rule I2 of ERE Responsibility (CSR)

Companies (Accounts) Rules, 204) Rp 08
Sey
iy tae Nt
Jat
op
'सत्यमेव जयते
Form language 0 English o Hindi
Refer the instruction kit for filing the form. ee
L. *(a) Corporate Identity Number (CIN) of the company |
*(c) Address of the registered office of the company
*(@) email ID ofthe company |
2. (a) *Financial Year to which the Corporate Social Responsibility details pertain:
From (DD/IMM/YYYY) To [pp mwyyyy)
(b) *SRN of form AOC-4/ AoC-4 XBRL/ AoC-4 NBFC filed by the company for its
standalone financial statements Cd
3. (Net Worth [ फ त फत
(iv) Criteria that triggered CSR applicability
4... (a)*(i) Whether CSR Committee has been constituted O ves Ono ONot Applicable
(ii) Number of directors composing CSR Committee ४५५
(iii) Number of meetings of CSR Committee held during the फट |
Sr. No. DIN Name of | Category No. of meetings of CSR = attended
Director during the year
_ Sa" Whether the company has a website Oves ONo दे
(ii) If Yes, Provide web-link
(iii) Whether following has been disclosed on the website of the company in pursuance of Rule 9
of Companies (CSR Policy) Rules, 204:
© Composition of CSR committee ° Yes o No oO NA.
* CSR Policy O yes QO No
¢ CSR projects approved by the board oO Yes oO No
(c)* (i) Whether Impact assessment of CSR projects is carried o Yes oO No oO Not Applicable
out in pursuance of sub-rule (3) of Rule 8 of
___ Companies (CSR Policy) Rules,204, ifapplicable --++ Rules,204, if applicable
