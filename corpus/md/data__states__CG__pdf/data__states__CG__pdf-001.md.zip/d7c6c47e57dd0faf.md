---
doc_id: "d7c6c47e57dd0faf"
source_url: "https://cgmfpfed.org/new/pdf/Gazette_Notification_Aadhaar.pdf"
ministry: "Chhattisgarh State Minor Forest Produce (Trading & Development) Co-Operative Fedration Limited, Chhattisgarh"
title: "Aadhaar Notification Published in the Official Gazette"
date: ""
pages: 11
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "c0f78c089521f75a"
---

<!-- page 1 -->

OE po. mS EN
“बिजनेस पोस्ट के अन्तर्गत डाक शुल्क के oy” (SSN Ng पंजीयन क्रमांक
नगद भुगतान (बिना डाक टिकट) के प्रेषण [ « eae. पे “setrentg /St/09/203-205.”
हेतु अनुमत. क्रमांक जी.2-22-छत्तीसगढ़ 7 ( On » 5
गजट / 38 सि. से. भिलाई. दिनांक ANN os 9
30-05-200.” ५ con WW 46
SS 25८
(असाधारण)
प्राधिकार से प्रकाशित
क्रमांक 42 ] नवा रायपुर, गुरूवार, दिनांक 8 मई 2025 ---- वैशाख 8, WH 947
वन एवं जलवायु परिवर्तन विभाग
मंत्रालय, महानदी भवन, नवा रायपुर अटल नगर
नवा रायपुर अटल नगर, दिनांक 2 मई 2025
अधिसूचना
क्रमांक एफ 2--9,// 2024 // 40-2 ,/ बजट.---- यतः, सेवाएं या प्रसुविधायें या सहायिकी प्रदान करने हेतु पहचान
दस्तावेज के रूप में आधार के उपयोग से सरकारी परिदान प्रकियाएं सुगम हो जाती है, पारदर्शिता एवं दक्षता आ जाती
है और लाभार्थी, अपनी पहचान साबित करने के लिये बहुविध दस्तावेज प्रस्तुत करने की आवश्यकता से मुक्त होते हुए
सुविधाजनक और निर्बाध रीति से सीधे अपना हक प्राप्त करने के योग्य हो जाते हैं।
और यतः, वन एवं जलवायु परिवर्तन विभाग, छत्तीसगढ़ शासन, (को इसमें
इसके पश्चात्‌ विभाग के रूप में निर्दिष्ट है), निम्नलिखित- योजनाओं का संचालन
कर रहा है:-
य का नाम य का विवरण (इसमें इसक लाभ का विवरण
पश्चात्‌ योजनाएँ के रूप में निर्दिष्ट है) | (इसमें इसके
पश्चात्‌ लाभ के
रूप में निर्दिष्ट है)
4. | aque oT aOR तेंदूपत्ता संग्रहण एवं तेंदूपत्ता व्यापार से | लघु वनोपज/
अर्जित लाभांश का प्रोत्साहन राशि के रूप | तेंदूपत्ता के संग्राहकों
में भुगतान और अन्य लाभार्थियों
at Direct
2. | ay प लिए न्यूनतम | लघु प अन्य eae ian
समर्थन मूल्य योजना वनवासियों को लघु वनोपज के संग्रहण | जो इसमें उस तरीकी
aaa मूल्य, व्यापार के लाभांश वितरण, प्रसंस्करण, | वात I ते
3. विन धन विकास योजना के | विपणन कार्य की राशि का भुगतान । के रूप में निर्दिष्ट के
अन्तर्गत लघु वनोपज का है) और अन्य तरीकों
प्रसंस्करण से भुगतान।
za लाख पालन जौर ag Ge Sa
5. | लघु पज आधारित कृषि | कृषि वानिकी के देय, अनुदान ।
वानिकी
823

<!-- page 2 -->

824 छत्तीसगढ़ राजपत्र, दिनांक 8 मई 2025
सामाजि सुरक्षा बीमा | तें | के लि मोहिनी देवी
योजनाएँ तेंदूपत्ता सामाजिक सुरक्षा योजना और समूह
बीमा योजना एवं प्रबंधक और फड़ मुंशी के
लिए बीमा योजना एवं राशि |
7. | छात्रवृत्ति शैक्षिक सहायता [4. मेधावी छात्र/ छात्राओं पुरस्कार
योजना योजना।
2. प्रतिभाशाली बच्चों के लिए शिक्षा
प्रोत्साहन योजना ।
3. व्यावसायिक कोर्स हेतु छात्रवृत्ति।
4. गैर-व्यावसायिक स्नातक कोर्स हेतु
अनुदान योजना (क्रियान्वयन एजेंसी द्वारा
लाभार्थियों को भुगतान उपरोक्त योजना के
मार किया जायेगा।)
जो कि छत्तीसगढ़ राज्य लघु वनोपज सहकारी संघ मर्यादित ( जो इसमें
इसके पश्चात्‌ क्रियान्वयन एजेंसी के रूप में निर्दिष्ट है) के माध्यम से क्रियान्वित
किया जा रहा है।
और यतः, योजना के अधीन (जो इसमें इसके पश्चात्‌ योजना के रूप में
निर्दिश्ट है) लघु वनोपज के संग्राहकों और अन्य वनवासियों तथा लघु वनोपज की
खरीद, प्रसंस्करण, विपणन एवं विकास में लगे व्यक्तियों (जो इसमें इसके पश्चात्‌
लाभार्थियों के रूप में निर्दिष्ट है) को विद्यमान योजनाओं के दिशाननिर्देशों के
अनुसार क्रियान्वयन एजेंसी द्वारा भुगतान किया जाता है;
और यतः, उक्त योजना के अंतर्गत छत्तीसगढ़ शासन की समेकित निधि से
आवर्ती व्यय भी होता है;
अतएव, आधार (वित्तीय एवं अन्य सहायिकीयों, प्रसुविधाओं और सेवाओं का
लक्ष्यत परिदान) अधिनियम, 2046 (क्र.8 सन्‌ 2046) (जो इसमें इसके पश्चात्‌ उक्त
अधिनियम के रूप में निर्दिष्ट है) की धारा 7 के अनुसरण में, छत्तीसगढ़ सरकार,
एतद्द्वारा, निम्नलिखित अधिसूचित करती है, अर्थात्‌:-
4. () कोई भी पात्र व्यक्ति, जो उक्त योजना का लाभ प्राप्त करना चाहता है तो उसे
आधार क्रमांक होने का प्रमाण प्रस्तुत करना होगा या आधार प्रमाणीकरण
करवाना होगा।

<!-- page 3 -->

छत्तीसगढ़ राजपत्र, दिनांक 8 मई 2025 824 [!)

(2) कोई भी पात्र व्यक्ति, जो योजना के तहत लाभ प्राप्त करने का इच्छुक और
जिसके पास आधार क्रमांक नहीं है या जिन्होंने आधार के लिए नामांकन नहीं
कराया है को आधार नामांकन के लिए आवेदन करना होगा पंरतु यह कि यह
उक्त अधिनियम की धारा 3 के अनुसार आधार प्राप्त करने का हकदार हो और
ऐसे व्यक्ति किसी भी आधार नामांकन केंद्र (सूची भारतीय विशिष्ट पहचान
mex (UIDAD की वेबसाइट छछफ-प्रांठभ्न.8०४०॥ पर उपलब्ध है) पर जाकर
आधार के लिए आवेदन कर सकते है ।

(3) आधार (नामांकन और अद्यतन) विनियमन, 2048 के विनियम 42 के अनुसार,
विभाग को अपनी क्रियान्वयन एजेंसी के माध्यम से उन पात्र हितग्राहियों के
लिए, जो अभी तक आधार के लिए नामांकित ना हो, के लिये नामांकन सुविधाएं
प्रदान करना अपेक्षित है और यदि संबंधित ब्लॉक या तहसील में कोई आधार
नामांकन केन्द्र अवस्थित न हो, तो विभाग अपने क्रियान्वयनकर्ता अभिकरण के
माध्यम से यूआईडीएआई के विद्यमान रजिस्ट्रारों के साथ या यूआईडीएआई द्वारा
उन्हें बनाए गए रजिस्ट्रार के साथ समन्वय करके सुविधाजनक स्थानों पर
आधार नामांकन सुविधायें Wart PRAT |

परंतु जब तक ऐसे व्यक्ति को आधार नहीं दिया जाता है, तब तक
योजना के तहत लाभ ऐसे व्यक्तियों को निम्नलिखित दस्तावेजों के प्रस्तुतीकरण
के आधार पर दिया जाएगा, अर्थात्‌ः-
(क) यदि उसने नामांकन किया है, तो उसकी आधार नामांकन पहचान पर्ची;
या

(ख) निम्नलिखित दस्तावेजों में से कोई एक, अर्थात्‌ :-

(एक) बैंक या पोस्ट ऑफिस की फोटो युक्त पासबुक; या

(दो) स्थायी खाता संख्या (पैन) कार्ड; या

(तीन) पासपोर्ट; या

(चार) राशन कार्ड; या

(पांच) मतदाता पहचान पत्र; या

(छः) मनरेगा कार्ड; या

<!-- page 4 -->

_04(| tert evs  ै_+_/"औई+ _._"ै॒_
(सात) किसान फोटो पासबुक; या
(आठ) मोटर वाहन अधिनियम, 4988 (4988 का 59) के अधीन
लाइसेंसिंगप्राधिकरण द्वारा जारी ड्राइविंग लाइसेंस; या
(नौ) राजपत्रित अधिकारी या तहसीलदार द्वारा आधिकारिक लेटर हेड पर
जारी किए गए ऐसे व्यक्ति की फोटो युक्त पहचान का प्रमाण पत्र; या
(दस) विभाग द्वारा निर्दिष्ट कोई अन्य दस्तावेज :

पंरतु और यह कि उपरोक्त दस्तावेजों की जांच विभाग द्वारा विशेष रूप
से इस प्रयोजन के लिए पदाभिहीत प्राधिकारी द्वारा की जाएगी।

2. योजनांतर्गत हितग्राहियों को सुविधापूर्वक लाभ उपलब्ध कराने हेतु विभाग अपनी
क्रियान्वयन एजेंसी के माध्यम से आवश्यक व्यवस्थाओं हेतु यह सुनिश्चित करेगा
कि हितग्राहियों को योजनांतर्गत आधार की आवश्यकता से अवगत कराने के
लिए मीडिया के माध्यम से व्यापक प्रचार-प्रसार किया जाए।

3. सभी मामलों में, जहाँ लाभार्थियों के खराब बायोमेट्रिक्स के कारण या किसी
अन्य कारण से आधार प्रमाणीकरण विफल हो जाता है, निम्नलिखित
उपचारात्मक तंत्र को अपनाया जाएगा, अर्थात्‌
(क) खराब फिंगरप्रिंट गुणवत्ता के मामले में, प्रमाणीकरण के लिए आईरिस स्कैन

या फेस प्रमाणीकरण की सुविधा को अपनाया जाएगा, जिससे विभाग अपनी
क्रियान्वयन एजेंसी के माध्यम से आईरिस स्कैनर या फेस प्रमाणीकरण के
साथ-साथ फिंगरप्रिंट प्रमाणीकरण के लिए प्रावधान करेगा ताकि निर्बाध रीति
से लाभ दिया जा सके।

(ख) उंगलियों के निशान या आईरिस स्कैन या चेहरे के प्रमाणीकरण के
माध्यम से बायोमेट्रिक प्रमाणीकरण सफल नहीं होने की स्थिति में, जहां भी
संभव हो आधार वन टाइम पासवर्ड या सीमित समय वैधता के साथ
टाइम-आधारित वन टाइम पासवर्ड जैसी भी स्थिति हो, द्वारा प्रमाणीकरण
स्वीकार्य होगा।

<!-- page 5 -->

(ग) अन्य सभी मामलों में, जहां बायोमेट्रिक या आधार वन टाइम पासवर्ड या
टाइम-आधारित वन-टाइम पासवर्ड प्रमाणीकरण संभव नही है. वहां योजना
के तहत भौतिक आधार पत्र के आधार पर लाभ दिया जा सकता है, जिसका
प्रमाणीकरण आधार पत्र पर मुद्रित क्विक रिस्पोंस कोड के माध्यम से
सत्यापित किया जा सकता है। क्विक रिस्पोंस कोड रीडर की आवश्यक
व्यवस्था विभाग द्वारा अपनी क्रियान्वयन एजेंसी के माध्यम से सुविधाजनक
स्थानों पर उपलब्ध कराया जायेगा।

4. यह सुनिश्चित करने के कम में, कि योजना के तहत कोई भी वास्तविक लाभार्थी
मिलने वाले लाभों से वंचित न हो, राज्य सरकारों और केंद्र शासित प्रदेशों के
संबंधित विभाग के कार्यालय ज्ञापन में निर्दिष्ट अपवाद प्रबंधन तंत्र का पालन
करेंगे, जैसा कि डायरेक्ट बेनिफिट ट्रांसफर मिशन, कैबिनेट सचिवालय, भारत
सरकार के कार्यालय ज्ञापन नं. 0-260/04/207-)87' दिनांक 49 दिसंबर,
2047 (https://dbtbharat.gov.in/ uy were) 4 fafere है।

यह अधिसूचना, राजपत्र में इसके प्रकाशन की तिथि से प्रभावशील
होगी।
एत्तीसाढ़ के राज्यपाल के नाम से तथा आदेशानुग्तार,
प्रणय मिश्रा, संपुक्त सचिव,

<!-- page 6 -->

Nava Raipur Atal Nagar, the 2nd May 2025
NOTIFICATION
No. F 2-9/2024/0-2 — Whereas, the use of Aadhaar as an identity document for delivery of services
or benefits or subsidies simplifies the Government delivery processes, brings in transparency and efficiency, and
enables beneficiaries to get their entitlements directly in a convenient and seamless manner by obviating the
need to produce multiple documents to prove one's identity;

And whereas, the Forest and Climate Change Department,
Government of Chhattisgarh (hereinafter referred to as the
Department), is administering the following Schemes:-

Name of _ the/| Description of the | Description of

Scheme Scheme (hereinafter | the Benefit

referred to as__ the | (hereinafter
Schemes) referred to as

the Benefit’
l. | Trade of | Payment against the | Payment to the
tendupatta tendupatta collection and | collectors of
incentive amount from | tendupatta/mi
tendupatta trade surplus. | nor forest
2. |Minimum Payments to Minor Forest|produce and

Support Price for| Produce collectors and | other

Minor Forest | other forest dwellers | beneficiaries

Produce scheme | against procurement, | through direct
3. | Processing of| processing, marketing of| benefit transfer

Minor Forest | Minor Forest Produce (herein after

Produce as per referred to as

Van Dhan Vikas . other mode(s).

<!-- page 7 -->

[ छछछछ रू |

4. | Lac Grants/Subsidies to
Development farmers of Lac and Minor
Scheme Forest Produce based Agro

forestry

5. | Minor Forest
Produce based
Agro forestry
Social security | Rajmohini Devi Tendupatta
and insurance |Samajik Suraksha Yojna
schemes and Samooh Bima Yojna

for the collectors of
tendupatta and insurance
scheme for Prabandhak
and Phad Munshi and
payment thereof.

7. |Scholarship and | . Medhavi Chhatra /
Educational Chhatraon ko Puruskar
Support Scheme Yojna.

2. Pratibhashali Bachhon
ke liye Shiksha
Protsahan Yojna.

3. Vyavsayik Course hetu
Chhatravritti.

4. Gair-vyavsayik Snatak
Course hetu Anudan
Yojna.

(The payment as per the
above schemes will be
paid to the beneficiaries
by the implementing
agency.)

which is being implemented through the Chhattisgarh State Minor

Forest Produce Co-operative Federation Limited (hereinafter referred

to as the Implementing Agency);

<!-- page 8 -->

And whereas, under the Scheme, payments (hereinafter
referred to as the benefit) is given to the collectors of minor forest
produce and other forest dwellers and persons engaged in
procurement, processing, marketing and development of Minor
Forest Produce (hereinafter referred to as the beneficiaries), by the
Implementing Agency as per the extant Scheme guidelines;

And whereas, the aforesaid Scheme involves recurring
expenditure incurred from the Consolidated Fund of Government of
Chhattisgarh;

Now, therefore, in pursuance of Section 7 of the Aadhaar
(Targeted Delivery of Financial and Other Subsidies, Benefits and
Services) Act, 206 (No.l8 of 206) (hereinafter referred to as the
said Act), the Government of Chhattisgarh, hereby, notifies the
following, namely: -

.(l) An individual eligible for receiving the benefits under the Scheme
shall be required to furnish proof of possession of the Aadhaar
number or undergo Aadhaar authentication.

(2) Any individual desirous of availing benefits under the Scheme,
who does not possess the Aadhaar number or, has not yet
enrolled for Aadhaar, shall be required to make application for
Aadhaar enrolment before registering for the Scheme provided
that he is entitled to obtain Aadhaar as per section 3 of the said
Act, and such individuals shall visit any Aadhaar enrolment
centre (list available at the Unique Identification Authority of
India (UIDAI) website www.uidai.gov.in) to get enrolled for
Aadhaar.

<!-- page 9 -->

(3) As per Regulation 2 ण the Aadhaar (Enrolment and Update)
Regulations, 206, the Department through its Implementing
Agency, is required to offer Aadhaar enrolment facilities for the
beneficiaries who are not yet enrolled for Aadhaar and in case
there is no Aadhaar enrolment centre located in the respective
Block or Taluka or Tahsil, the Department through its
Implementing Agency shall provide Aadhaar enrolment facilities
at convenient locations in coordination with the existing
Registrars of UIDAI or by becoming a UIDAI Registrar
themselves:

Provided that till the time Aadhaar is assigned to the
. individual, benefits under the Scheme shall be given to such
individual, subject to the production of the following documents,
namely:—
(a) if he has enrolled, his Aadhaar Enrolment Identification
slip; or
(b) any one of the following documents, namely:-
(i) Bank or Post office Passbook with Photo; or
(ii) Permanent Account Number (PAN) Card; or
(iii) Passport; or
(iv) Ration Card; or
(v) Voter Identity Card; or
(vi) MGNREGA card; or
(vii) Kisan Photo passbook; or
(viii) Driving license issued by the Licensing Authority under
the Motor Vehicles Act, 988 (No.59 of 988); or

<!-- page 10 -->

(ix) Certificate of identity having photo of such person
issued by a Gazetted Officer or a Tahsildar on an official
letter head; or

(x) any other document as specified by the Implementing
Agency:

Provided further that the above documents may be
checked by an officer specifically designated by the implementing
agency for that purpose.

2. In order to provide benefits to the beneficiaries under the
Scheme conveniently, the Department through its
Implementing Agency shall make all the required
arrangements to ensure that wide publicity through the media
shall be given to the beneficiaries to make them aware of the
said requirement.

3. In all cases, where Aadhaar authentication fails due to poor
biometrics of the beneficiaries or due to any other reason, the
following remedial mechanisms shall be adopted, namely:-

(a) in case of poor fingerprint quality, iris scan or face
authentication facility shall be adopted for
authentication, thereby the Department through its
Implementing Agency shall make provisions for iris
scanners or face authentication along with finger-print
authentication for delivery of benefits in seamless
manner;

(b) in case the biometric authentication through fingerprints
or iris scan or face authentication is not successful,
wherever feasible and admissible authentication by
