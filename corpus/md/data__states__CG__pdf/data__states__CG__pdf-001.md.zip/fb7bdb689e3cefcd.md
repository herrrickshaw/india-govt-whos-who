---
doc_id: "fb7bdb689e3cefcd"
source_url: "https://law.cgstate.gov.in/custom-files/notice_files/ODR20261023_110_6adafc9eab7e8.pdf"
ministry: "Law and Legislative Affairs Department, Chhattisgarh"
title: "Orders"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a947d8677f22b71f"
---

<!-- page 1 -->

Ed$rrqrrrfl{

frB ofl{Mordfrqrq, {aTdq
qErl-* qfi, TEI {Iqgq 3i-e6 nIR,
G-or<rugt (8.r.) 492ooz
qt< i. OZZt -ZZZt :46. email-lawdept.cg@gov.in

rctr$tt

$qgt,Ho zzltolzoze
nqttr. / taw - 42 t 2 1 3 t 2O26 / 21 -4 /v.1. / 2 02 6 tlifl' {rffi , qil{fl -tI, * oro
grn or6f, srfr{mT a\ srET fi oi{ + $rfr 6-{i b ftcarfrtro rrl€-fi=q
q-qr

O

3rftqrq6, utfrIqr G-or qsqq dqT lTrtrq ilrR-o grefi HG-dr fr qr{ 18 (3)
fr u-<Efl irRnd 6) qfrq { drfr S}, 3rftR-6 do srFrq}-co, EnRqr G-irr
rrqrE h c-q ER6rdqn reur.F-ri h ft-{i6 ot s{ fr qR-fiefl erqB qr s-+b
62

E{fr eqd 'frqe-&d, fumo-rottt

t

e-+ rn-s-{ aro frqfR-d G qrq-rrrqw €ril[*o fttfl fi's qti er;q fi's +q
Arrr,r +go it MR-d 3rgwn *frt
dfrt srfr +sT erq ird u.q.
3flr
Egm frns dY6 3lft+s-o. a't g@ s*R or y-an
o.rd
fuiTrT, qTr6q b 3nt{T i,qrr 3142fis1/21-qq.q./2022ft{i6 2 5qrd,
zozzd s-Jsc tq Eifrt

fi

ffi

ffi

M

E-dsT6 b r.,qqro il crq

qrhTr{sx,

t oetT

Digitally signed byz
B }< VASNIKAR
Date: 22-10-2026
12:30:O1
tti-<g;qnqrs-+oi)
3rfrfto.{Bq
frfB 3ft freTrfr6rd fi*qrr. q-ll6q
nirq /Law 42/2130 /2026/ 21 -4 N.1./2026 il4r ilqg{, fut{. 22/ 10/2026
-

sfrBfr
L o-&+es yq G-6'r eu-erfffi, qrqrd 6\ g-{b ilq-{ mqi6GENCRo/35/
zt3/2026trq.8. R-{i6 1s.ol.zoz6 b €<q C,
2. qqn G-or vq sa qrflftfl, <rtrqo Gr.{.),
3 . qrfl+q A'0 q* fi & frts s6rq-6 fr oN qTr-{q frB q* S b

<!-- page 2 -->

3{s-6t-6-{rel,

4. Eitr olfi,rn, qgre Hfrs, frfB fr eir ryu sfrq, frB rdcq b
er+oi-*-+ei,

ftgt

qmqq
s . afr oro g;rn orfi. 3il-dilfii. qTq q GEDER- ft-s{,
G-ol <uetfffiTqqq b
a-6S6 E{Rqr. G-or <nrqE 4s6661(8.,I.)
qftuq erlG-o mv #s t, f6 n FrqBfud s{r{rq 6-r dqun c{ r-qa ott
(sD frB frffq FRTqro-d b fr'qq 1s vs 16b qun
fr e.eiq 3rErda
ftmBfi sifr-d c-S ft'qT rfqT t 3ilr €-{h fu-dTtr oX
EnT ft-+q sq
Rft-d Bft atR-d "rfr * qi scb fuomn ot{ fr vrra itRd r-fr i t CE) fufr
$ qqr6q qT srB6-ruT b rm qr{F.'q frEfd qfrq-<, qreq fr8-f, qf{q-q qdi

d

t

ffi

t

sq-or

qfiqq

q

dItrd q-fr frfl,rfi tt6$ uqb fr'68 6t{.fr
,ff sefi ei-<rdn ri 6n{f, =rd} t 3ar q fr GtS $

ffi
3i-qra-d ilq s+ ffi€
d6$qr rrrr tt Cq 3{frtr6 rrr€-ftq
,pqq-57eftfuo 6to. 3{fuq}$o' b olqh8 h +iH q-dfrfuo qftfrffi;f
,{r'r rfr &t ae{r xol nkrdr t ut qrElil r-fr 6}i tsT s}sqr
e-qd ott (5)
gv-+r mr*vn q-6ul a-{ cftt"<n o-&fei f.q G-ar <u-srEqtrfrrrqrrd b neqq t
gsfrqrudifr-oott
G. ss €!-rd6, rrrs-6q el-*u g*onau, {<r<-fr .r+c } qrs, TqT wg{
15,r ) qft 11-sq{ (3NilqRrD { n-dnr{ret,
qse-&c, fqB'3ir frqr-fr fl{ fuarl 5 3ir fu,Trftq Me
t_-r<ffi
q qq-dt-s
qr+
enq-*rB-o qrror

Erd

frri

b €Err {,

fr sir q-firef Vi ep-{q-6 6rffi tg er}&o

t

Digitally signed by
MURALI RAM VERMA
Date:22-1O-2O26
L3iO-7:47

fgd$qqqf1
ercsqfu{

frfq 3fl{ ftqrfr o-rd frqi1, ria.,
