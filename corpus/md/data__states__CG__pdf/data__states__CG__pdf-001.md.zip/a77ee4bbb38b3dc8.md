---
doc_id: "a77ee4bbb38b3dc8"
source_url: "https://www.sldccg.com/wif-for-website/sldccg_act_regulations/47-centralelectricityauthorityinstallationandoperationofmetersamendmentregulations2014.pdf"
ministry: "State Load Despatch Centre (SLDC), Chhattisgarh"
title: ""
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f92aba8889280e72"
---

<!-- page 1 -->

.

--·

.

� "Bo 'ito 'Qglo-33004/99

REGD. NO. D. L.-33004/99

91I1fcl chi .i,5i1Qil
'[:he <f;a:iette. of 3ndia
��

,

,

EXTRAORDINARY
'q'f1T3-�4
PART 3-Section 4
� � \.l_a:iif¥!H
PUBLISHED BYAUTHORITY
� �. 'aJSr«ffl", � 3, 2014/� 12, 1936

ti. 348]
No. 348]

NEW DELHI, WEDNESDAY, DECEMBER 3, 2014/AGRAHAYANA 12, 1936 ...

�li':ill(14
(���)
�
��. 26 �. 2014
· t. 23/47/2014-oITT: � am:(� III).-� � �. ·� � 2003 (2003 oft
�- 36) mu 177 oft� mu (2) � m!?:f � mu 55 oft� mu (1) cim mu 73 � � (W) IDU �
!/� "ifiT � m ge;, � � � (� "ifiT � � �) Plf.l<i+i, 2005 "ifiT tllrr&<=r
ffl � � f.li:11R!Rsla f4f.l:q4-1 ��.of�:-.
1. � ifl+I" aitt "5ITtir - (1) · � f4f.l:q+fl "ifiT � ;:im � � � (� "ifiT � �
mi-I") t!/TTWI f4f.1:q+1, 2014 �I
(2) � fcl f.l 4 +l � if Wfir!/Ti-1" oft � � � �I
2. � �- � fcl f.l <iii {cfi) 415 elk aitt � f.n:<:r � "fa""U (of� w:r4" - � tR �m zj-!/nfira Sk41<·-1dT
(611�c{iif'lll) W (l; ffl) � l;f1JTTm �oft��� SlHifili:fi � lfRcfi � � d�ij,¥41
�) tr{
"ffi� cfi�feR:f4J'I oft +lTiT ffi" ��fir€" {c(((feR:i:I .-j c{)ifi(Ul)4 3;"aj � <i)- � �I

m�

<iz

(i:cr) 41s elk an-z � � � � (a:r� ™ - ™ 9--.:: ,:pn zj-!/irfm1· s1<::q19Jf (611�2.z<1R•1) � m)
� >f1Jffin � � � � fur:t sm-ir'lc!i � � � � a�j�Yl �) 1T<- fi-41f?rn (if>�rta)
��qR2.<l ;:icfl<h<afl:q � � � -.:flm.T
il" � � � � � � (lTTc"U "ifiT
� � �) fclf.-l:qi;, 2006 if����� f.r&ffi:cr fet;Q: 'ftt �I
(<T) � � � (-i:ftctt "ifiT � 3itt �) fclf.l:qi;, 2006 if <l'l!T1 fclf.l f;ftS2. ·��

�m

m

w· �

B'lfi �� 'ii<f11kizofhT �f �· � fi11pfi f1PJ._ �, � d'fifitl �'1 fclf.:P:if-l"i if ��1 fclf.lfcftS?. rf fel;-;rr ,r,:rqfr1

3, ���(�'FT� tJ:f �) fclf.'l:qi; 2006 (ITT�� 'T!/'effif f¾f.-llfR �
mrr �) � R1 f.l £f R 2 73T.f
(1) if
(�) � tr!/� f.l 4l RI� a
at-a-:� HilfT �. ar�

m

4776 GI/2014

m

m

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

(PART III-SEC. 4]

'(+f) - '..pf\if,(Ofhl � lflc;{· #.�it � .f;)- � � � ID"U � .f;)- � � ifi" � � � �
fu't!:��#3lfmh:r!��3{ij7ffiit#lflc;{�!���ifi"�3lra�I
4. � f4f.lll+i1 ifi",.f4f.l44-l 7 ifi" '3"tf f4f.).q'-l 2 ifi" � (lf} ifi" 1:f!?'q@ f.h-.-iRIF€1a � ahr:� � �.
��:
'('i'.f) i-l<flifi<vfl4 � i:ftw ofiT � � f4f.lf4iSi! � � � itlfr:irrq.;"Sfiiilr

o1.ftefitoft4 �·�iii!'�

*

�+rrq;;ij� :- '3,Yl�d WflT ·� it firn" ij .-tcflcfi<vft4 � � ��•tfifl ffi"{j
i'!cflcfi(U\)lj � ffl it fira" #
3fcf:�
tj��a�;;nmt1

m��

�

.-tcflcf><Ufl4 -a;aj +rrr,; il'i Sl4lG!i'll"l "SI"�� <fl"
�:�ifi"�"ID"{Tf.twr.<fl"�ifi"� G!?TT ij 'i-lcflcfi(vfh.l � �• it � � �
Fnm �
# tj4111la .� ;;nm � � �.f4f.lffl6l � 1f{ � � � �
- CD
_:,._ =- .'.l< .-.!......._-� ..ri. _.JS_
� �&TI" � ��TT � � lfr;i:.
,��(1, -0...
�,G _:,._
QI di, l<,I� +I �d.�l'H1 Cfll 1111C11
I <!11(11(""1 =-I
I �!
, '.1cfl-.i<oft 4 �hflc{' � � Pfi4T �I
.
� +rrr,; (;te �) :-i-1cl1cf>(vfl4 -a;aj ffl it,

·��·

I

· . · ... · · ·

. .

I

�cqo1:-•� mtfi1 (;te �) cf;J' G.!ITT #, tafT crIB -1cfl.,.;(ofl.q � ffl, fira" .f;)- �.<fl"� ij
��<f;)-�'-ii{ffl�I WG!/TTif, firn".f;)-�.(TT-�if. fira"#:JT.T-.:i'lcfdl �<fl"<Sll��"f€,1
�����1R�fcl'€11Rid����<ll(flIT\ifT,'IT�I'·

5 .. � MR4'11 � � ifi" �- 111 #
• (cfl)'� (1)� :JT.T � (<l>) � � i:r<. Plk1PIF€1a :JT.T � � �. �:
(cfl} ·� lflc;{, � mr � .fTT" � "fiwft � -a;aj it +rrFt ifi" �. � � 3th:
i-11:flcf>tOnii �.� �
au! #
-a;aj it +rrFt ifi". �

* � m arcr:� � ·� � �

itlfr1'

(�) � (3) ifi" lT!?"'ifra, fi?lir1Rif€1c1 ·�· it

mo

ara:� f.lim �. ��:

•�:- .-tcflef>{Ofjll 3i\ifT ��-�.!/��au! afa": "3iY1: (3) (is) if f.p:ra- � � U&f (i:ijr �) ofiT(cf).
'1 cfl if,(vfl 4 ��cf;," Gm# m<J_ 'f@ "@7m
mifmr �mft � an<fflf ifi" f4f.l4+if <lT

m ,·

'

'

�.11rr �. � � �- .� u&t B+rT&rii arr,;r
[Pl#! l'F1 III/4/arm./186-cft-/2014]

1iR �- � �f.-l<-P-1, m-TTr ��if�- 502/70/ifi".f<t.m.Jit i:ft" t?,s it� 17 l=!T'<T, 2006 IDU
� � <nr � aw; ��itfITTI Mf.'14'-l mur ��if�- 5021612009/it ifl" ti,s irtit-1 � 4 ¥,
2010 IDU��,n:i: il-1

<!-- page 3 -->

3

[� III-�4].

MINISTRY OF POWER
(CENTRAL ELECTRICITY AUTHORITY)
NOTIFICATION
.New Delhi, the 26th November, 2014
No. 23/47/2014-R&R (Vol. III).-In exercise of the powers conferred by the sub-Section (1) of
Section 55 and clause (e) of section 73 read with sub-section (2) of Section 177 of the Electricity Act, 2003
(No. 36 of 2003), the Central Electricity Authority, hereby makes the following regulations to amend the
Central Electricity Authority (Installation and Operation of Meters) Regulations, 2006, namely:L
Short title and commencement.-(!) These regulations may be called the Central Electricity
Authority (Installation and Operation of Meters) Amendment Regulations, 2014.
(2) These regulations shall come into force on the date of their publication in the Official Gazette.
2.
Application.-These Regulations shall be applicable for (a)all Grid Interactive Renewable Energy
Plants seeking the · connectivity with the grid at 415 V ( or corresponding voltage as per relevant Indian
Standard for values of alternating current(AC) nominal system voltage, as amended from time to time) and
below Voltage Levels;
(b) Grid interactive Renewabie Energy Plants connected at above 415 V (ur corresponding voltage as per
. reievani Indian Standard for values of alternating current(AC) nominal system voltage, as an1ended from time
to time) �,rou1d foH�w the sm-ne metering arrangement as stipti1ated for· Generating Stations·, ,in Central
Electricity Authority (Installation and Operation of Meters) Regulations, 2006.
(c) all the clauses of 'Consumer Meters' as specified in Central Electricity Authority (Installation and
Operation of Meters) Regulations; 2006,-would also be applicable for 'Renewable Energy Meter', unless
specified in these Regulations.
3,.
In the .Central Electricity Authority (Installation and Operation of Meters) Regulations, 2006 .
(hereinafter referred to as the principal regulations), in Regulation 2, in sub-section (1), after clause(x), the
following clause shall be inserted, namely:" (y) Renewable Energy Meter means a meter used for accounting and billing of electricity supplied to and
from the consumer but excluding those covered under Interface Meters."
4.
In the principal regulations, in regulation 7, in sub regulation 2, after clause (c), the following clause
shall be inserted, namely:"(d) The location of Renewable Energy.Meters shall be as specified_ below:
. Meterin2 arran2ement
Feed m Tariff metering:- Renewable
Energy Plant is connected to the grid to
inject the entire electricity generated to
the grid
Net metering :- Renewable Energy Plant
is .connected to the load bus of the owner
to consume electricity
generated
primarily by the owner of the Plant and
excess electricity, if any, is injected to the
grid

Location of Renewable Enerl!v Meter
Out going feeder from Renewable Energy Plant

In case of first installation for the purpose of Renewable Energy
Metering, the 'Renewable Energy Meter' shall be installed at
the location specified for consumer meter and in case of existing
consumers, the consumer meter shall be replaced with
'Renewable Energy Meter'.

Note : In case of Net metering, Renewable Energy Plants with battery can supply the consumer load in the
event of grid failure. In this case, an automatic isolating mechanism has to be provided at appropriate location
lo make islanding of the consumer load from the grid at the event of grid failure."
5.

In the principal regulations, in the Schedule, in Part III-

(a) In paragraph (1), for sub-paragraph (a), the following sub-paragraph shall be substituted, namely:-

<!-- page 4 -->

4

[PART III-SEC. 4]

THE GAZETTE OF INDIA : EXTRAORDINARY

"(a) The Consumer meter shall be suitable for measurement of cumulative active energy utilized by the
consumer and the Renewable Energy Meter shall he suitable for measurement of cumulative active energy
drawn from the grid and injected into the grid.".
(b) After paragraph(3), at the end, the following "Note" shall beinserted, namely:"NOTE - Renewable Energy Meter is bi-directional and therefore anti tamper feature stipulated at (3) (e)
above shall not be applicable in case of Renewable Energy Meter. Respective licensee may adopt appropriate
anti tampering solutions as per regulations or directions of appropriate Commission."
NAP AN BATEI, Secretary
[ADVTAII/4/Exfy:186-R/14]
Foot Note - The principal Regulations were published in the Gazette of India vide No. 502/70/CEA/DP&D
dated the 17th March, 2006 and Amendment regulations were published in the Gazette • of India vide
No. 502/6/2009/DP&D/D-1, dated the 4th June, 2010.

Printed by the Manager, Government of India Press, Ring Road, lvlayapuri, New Delhi-110064
and Published by the Contro!ler of Publications, Delhi-l l 0054.
