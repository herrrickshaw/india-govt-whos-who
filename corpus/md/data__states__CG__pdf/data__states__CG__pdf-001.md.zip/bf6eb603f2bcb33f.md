---
doc_id: "bf6eb603f2bcb33f"
source_url: "https://www.cbda.in/sites/default/files/tender-document/JCB%20and%20construction%20material%20PT001%20-%20Corrected%2019%20august%20%281%29.pdf"
ministry: "Chhattisgarh Biofuel Development Authority (CBDA)"
title: "JCB and construction material PT001 - Corrected 19 august (1).pdf"
date: ""
pages: 23
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0e7335f40dbf9e34"
---

<!-- page 1 -->

CHHATTISGARH BIOFUEL DEVELOPMENT AUTHORITY
(CBDA)
Project Office, Biofuel Complex, Village: Godhi, Dist: Durg - 490036

TENDER DOCUMENT
FOR
Provision of mechanized soil excavation, digging, levelling and allied works
with mechanical diggers and excavators and supply of other construction
materials as and when required at CBDA Biofuel Complex Project sites at
Vill: Godhi and Vill: Thengabhat. Dist: Durg.

TENDER NO: CBDA/2026/PT/BFC/001

Prepared & Issued By:
Chhattisgarh Biofuel Development Authority
(CBDA)

Document Fee- 1180/-

<!-- page 2 -->

TENDER NO: CBDA/2026/PT/BFC/001
TABLE OF CONTENTS

INDEX
SL. NO.

DESCRIPTION

1.0

NOTICE INVITING TENDER (NIT)

2.0

PRICE BID SCHEDULE

3.0

SPECIAL CONDITIONS OF CONTRACT (SCC)

4.0

SCOPE OF WORK

5.0

ANNEXURES

PAGE
NOs.

<!-- page 3 -->

NOTICE INVITING TENDER (NIT)
REF: TENDER NO.: CBDA/2026/PT/BFC/001
Date:

June 2026

To,
M/s.
___________
_
____________________
____________________
PT No. CBDA/2026/PT/BFC/001
SUBJECT- Provision of mechanized soil excavation, digging, levelling and

allied works with mechanical diggers and excavators and supply of other
construction materials as and when required at CBDA Biofuel Complex
Project sites at Vill: Godhi and Vill: Thengabhat. Dist: Durg
The CBDA Biofuel Complex Project Sites at Village Godhi and Village Thengabhat, District Durg,
require various site development and plantation-related works for establishment and maintenance of
biofuel plantations. The works include land development, mechanized digging of plantation pits for
Candidate Plus Trees (CPTs) of Pongamia, Simarouba and other biofuel species, repair and strengthening
of existing cattle-proof trenches through deepening and widening to prevent grazing by stray animals,
land levelling, and construction and improvement of internal pathways and roads. Construction work of
cement pole for boundary of block A, B, C and D, store room and additional laboratory in bio-ethanol
plant needs to be done. These activities are essential for ensuring proper plantation establishment, site
protection, accessibility, and overall development of the Biofuel Complex Project Sites.
In order to execute the above works efficiently and within the stipulated timeframe, it is proposed to
engage a competent agency having the required machinery and technical capability. Accordingly, CBDA
invites sealed bids for the “Provision of mechanized soil excavation, digging, levelling and allied
works with mechanical diggers and excavators, and supply of other construction materials as and
when required at the CBDA Biofuel Complex Project Sites located at Vill: Godhi & Vill:
Thengabhat, Dist.: Durg”
Sealed bids are invited under a five-bid system —
 Part I: Technical part
 Part II: EMD and Tender fees
Page | 1
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 4 -->

 Part III: Price bid for Vill. Godhi
 Part IV: Price bid for Vill Thengabhat
 All the above four envelopes shall be duly sealed and placed together in one final sealed

envelope (Part- V), which shall be submitted as the complete bid.
Bidders are required to submit their proposals in accordance with the terms, specifications, and
instructions contained in this tender document.
A complete set of tender documents along with the ‘Price Bid’ format, is enclosed for submission of
your offer.
1. Brief Details of the Work are as under:
1.1 TENDER COST
(NONREFUNDABLE)

1.2 EARNEST
MONEY
DEPOSIT(EMD)
1.3 RELEASE OF
TENDER
DOCUMENT
1.4 LAST DATE FOR
SEEKING
CLARIFICATION
S/ QUERIES
1.5 PRE-BIDMEETING
1.6 LAST DATE FOR
ISSUE OF
CLARIFICATIONS
BY CBDA
1.7 PERIOD OF
COMPLETION OF
ACTIVITY

Rs. 1000/- (Rs. One thousand only) + 18% GST, total
amount of Rs. 1180/- (One Thousand One Hundred
Eighty Only) by Online Payment/demand draft in favor of
CHHATTISGARH
BIOFUEL
DEVELOPMENT
AUTHORITY (CBDA), payable at Raipur, CG or by cash at
CBDA’s Project Office, Biofuel Complex, Village: Godhi,
Dist: Durg
Tender document can also be downloaded from the CBDA
website (www.cbda.in). Prospective Bidder downloading
from the website shall be required to pay the tender cost of
Rs. 1180 /- by demand draft along with the bid.
Rs. 35000.00 (Rupees Thirty-Five thousand only). EMD of
unsuccessful work Bidder(s) will be refunded after award of
work and receipt of security deposit from the successful
bidder.
27th August 2026

31st August 2026

10th September 2026 at 12.00 Hours.
15th September 2026

03 (three) months. Can be extended at the sole discretion of
CBDA

Page | 2
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 5 -->

1.8 LAST DATE OF
SUBMISSION OF
BID

17th September 2026 at 14:00 Hours.

1.9 DATE & TIME FOR
BID OPENING

Techno-commercial bids (Part-I & II) shall be opened on
17thSeptember 2026 at 15:00 Hours Authorized
representatives of Bidder shall attend.

1.10 PLACE OF TENDER
SUBMISSION

Price bid (Part-III & IV) of the Bidders whose Technocommercial bid has been found acceptable by CBDA, shall
be opened at a later date. Such bidder(s) will be informed by
e-mail/post/telephonically
The tender document can be submitted by post so as to reach
at the following address before the last date and time for
submission of bids:
To,
The Asst. Project Officer (PC-I)
Chhattisgarh Biofuel Development Authority,
Biofuel Complex, Village-Godhi-490036, Durg,
Chhattisgarh
Contact no. – 7880161544

1.11 VALIDITY OF
OFFER

If submitted in person, the same could be submitted in the
tender box placed at the above office address.
6 (Six) months from the last date of submission of tender,
May be extended at the sole discretion of CBDA

1.12 DURATION OF THE
PROJECT

08 (Eight) months. May be extended at the sole discretion of
CBDA

2. Submission of Bids
2.1 The bidder has to submit their bid in Hard Copy (printed form) with all information requested
or to be provided/ appended there to, and is to be submitted strictly in accordance with the
documents accompanying this Tender Document, within the Closing Date and Time stipulated.
2.2 The Techno commercial Bid is to be submitted as per Scope of Work and Specification of the
tender (Section II). The Price Bid rates shall be quoted per unit as specified in the “Schedule
of Rates”.
2.3 Bid submitted by the Tenderer shall remain valid and open for acceptance for a period of 1 (one)
month from the date of opening of Techno-commercial part of the tender. The rates quoted
in the schedule of rates shall remain firm during the validity period and Contract period
subject to escalation clause.
Page | 3
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 6 -->

2.4 Bidder to submit their Quotes by the due date, quotes / bids not received by the due date and
time shall be responsibility of the tenderer. CBDA takes no responsibility for delay, loss or nonreceipt of tender documents sent by post/courier / e-mailed offer shall be accepted and CBDA
takes no responsibility for delay, loss or non-receipt of bid.
2.5 CBDA shall not be responsible for any expense incurred by bidders in connection with the
preparation & delivery of their bids, site visit and other expenses incurred during bidding
process.
2.6 CBDA reserve the right to assess bidder’s capability and capacity to execute the work using inhouse

information

and

by

taking

into

account

other

aspects

such

as concurrent

commitments and past performance.
2.7 Bidder submitting his bid should not be under liquidation, court receivership or similar
proceedings.
2.8 Bids submitted through e-mail shall be accepted only for outstation vendors/Agencies.
2.9 All r equir ed document s shall be submit t ed by t he bidder in sea le d enve lo pes wit h PT
No. mentioned clearly on the envelopes, before or on Bid Closing date at below mentioned
address:
Assistant Project Officer- PC(I)
Chhattisgarh Biofuel Development Authority,
Project Office, Biofuel Complex, Village: Godhi, Dist: Durg - 490036
Ph. No: - 7880161544
Email- skmaitry@gmail.com & cbdaraipur@gmail.com
Requested to acknowledge by return e-mail/ post, in the proforma attached Annexure, receipt of this Tender Document and its accompanying documents, and
confirm your intention to submit a proposal.
Due to project schedule limitations, requests for extension of Bid submission dates
will not be granted nor acknowledged.
Thanking You
Yours Sincerely,
For Chhattisgarh Biofuel Development Authority
Assistant Project Officer (PC-I)
Date:

Page | 4
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 7 -->

3. Earnest Money Deposit (EMD)
The EMD shall be Rs. 35,000/- (Rupees Thirty-Five thousand only) EMD of unsuccessful
Bidder(s) will be refunded after award of work and receipt of security deposit from the
successful Bidder
EMD shall be paid only by crossed Demand Draft or Pay Order issued by any scheduled
Bank, in favor of M/s CHHATTISGARH BIOFUEL DEVELOPMENT AUTHORITY. or
submit online transfer receipt to CBDA Bank account. Particulars of CBDA Bank account are
as under:
Name of Account Holder

Chhattisgarh Biofuel Development Authority

Bank Account No.

1279077570

Bank Name

Central Bank of India

Branch

Civil Lines, Raipur

11-digit IFSC code

CBIN0282321

GST No.

22AAALC0213H1Z2

Note: Tenders without EMD will be summarily rejected.
4. Security Deposit (SD)
The VENDOR/AGENCY shall have to maintain a security deposit of 3 % of the value of the
Work order with the CBDA.
Security deposit shall be provided by payment in Bank Draft or Pay Order of a scheduled Bank
or thru' online transfer to CBDA Bank account at Raipur. Within seven days of acceptance of
work order by the selected vendor, the AGENCY must deposit an amount equal to 3 % of the
work order value. The EMD deposited by the AGENCY along with the tender shall be converted
into security deposit. in case the successful bidder submits a request for the same. No interest
shall be payable against EMD and security deposit, by CBDA.

Page | 5
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 8 -->

5. Eligibility Criteria
5.1 The Bidder should satisfy itself regarding the eligibility criteria before submission of the
bid.
5.2 The Bidder should fulfill all of the following eligibility criteria outlined below and provide
necessary documents (annual report, related work-order, payment vouchers approved by the
work promoting agency, work completion report/payment proofs etc.) for verification.
5.3 Schedule of qualifying criteria for selection of bidder:
5.3.1 The Bidder must be locally registered (Chhattisgarh/ adjoining states) engaged in
dealing with mechanized soil excavation and digging work, civil construction work,
supply of sand, grit, cement, bricks, Iron rod etc.
5.3.2 The Bidder applying for the tender must have undertaken mechanized soil
excavation and digging work and allied activities and supply of work, sand, grit,
cement, bricks, Iron rod etc.to any of the State Chhattisgarh.
5.3.3 The Bidder must have minimum 2 years of GST CAS in supplying materials to
CBDA or any department of Chhattisgarh Government.
5.3.4 GST registration no. (if annual turnover is more than Rs. 10.00 lacs) for bidders
qualifying in Sl. No. 5.3.1 to 5.3.3 above.
5.3.5 Annual turn over should be more than 100 lakhs.

Page | 6
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 9 -->

CHHATTISAGARH BIOFUEL DEVELOPMENT AUTHORITY

Provision of mechanized soil excavation, digging, levelling and allied works with
mechanical diggers and excavators and supply of other construction materials as and
when required at CBDA Biofuel Complex Project site at Vill: Godhi Dist: Durg
SUMMARY OF BIDDER’S PRICE
(PRICE BID SCHEDULE-I)

PT NO.

CBDA/2026/PT/BFC/001

PT DATE:
Closing Date:

till 15:00Hrs.

Bidder's
Name
Bidders'
Ref. No.
Bid
Submission
Date:

Name & Contact Details of Bidder:
Sl. No.

Description

Work/Unit

Unit rate per item Rs. (exBiofuel Complex as detailed
above)

GST (%)

1

2

4

5

1

Quote for the Provision of
mechanized
soil
excavation,
digging, levelling and allied works
with mechanical diggers and
excavators

3
Per hour

Page | 7
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 10 -->

CHHATTISAGARH BIOFUEL DEVELOPMENT AUTHORITY
SUMMARY OF BIDDER’S PRICE

(PRICE BID SCHEDULE-II)

Provision of mechanized soil excavation, digging, levelling and allied works with
mechanical diggers and excavators and supply of other construction materials as and
when required at CBDA Biofuel Complex Project sites at Vill: Godhi Dist: Durg
1
2

2
Materials
1. Sand
2.Cement
3.Crushed stone
(1/2 inch)
4. Crushes stone
(3/4 inch)
5.Black bricks
6.Red bricks
7.Iron rod (12mm)
8.Iron rod (10mm)
9.Iron rod (8mm)
10.Fencing wire
11. Birla white
cement
12. Murroom
13.Soil
14.Stone dust
15. Chain link
mesh wire (5 feet,
3.15 mm
thickness)
50mmx50mm
(2”x2”) mesh size.
NOTES:

3
Details
Per sq. feet
Per bag

4
Rate

5
GST (%)

Per feet
Per feet
Per piece
Per piece
Per kg
Per kg
Per kg
Per kg
Per bag
Per sq. feet
Per sq. feet
Per sq feet
Per sq feet

1. Bidder have to quote offer (fill up) unit rate with Estimated required quantity (in column no.
4,5, and 6 above) of provision of mechanized soil excavation, digging, levelling and allied
works with mechanical diggers and excavators and supply of other construction materials as
and when required at CBDA Biofuel Complex Project at Vill. Godhi, Dist. Durg.
2. Bidder have to quote offer unit rate (in column no.4 above) of mentioned materials form
separately in rows (row no. 2 above) CBDA will have the right to reject the tender for any
reasons.
3. SOR rate shall include basic rate of material, taxes, GST, transportation and other
expenses.

Page | 8
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 11 -->

CHHATTISAGARH BIOFUEL DEVELOPMENT AUTHORITY
SUMMARY OF BIDDER’S PRICE

(PRICE BID SCHEDULE-III)

Provision of mechanized soil excavation, digging, levelling and allied works with
mechanical diggers and excavators and supply of other construction materials as and
when required at CBDA Biofuel Complex Project site at Vill: Thengabhat Dist: Durg
PT NO.

CBDA/2026/PT/BFC/001

PT DATE:
Closing Date:

till 15:00Hrs.

Bidder's
Name
Bidders'
Ref. No.
Bid
Submission
Date:

Name & Contact Details of Bidder:
Sl. No.

Description

Work/Unit

Unit rate per item Rs. (exBiofuel Complex as detailed
above)

GST(%)

1

2

4

5

1

Quote for the Provision of
mechanized
soil
excavation,
digging, levelling and allied works
with mechanical diggers and
excavators

3
Per hour

Page | 9
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 12 -->

CHHATTISAGARH BIOFUEL DEVELOPMENT AUTHORITY
SUMMARY OF BIDDER’S PRICE

(PRICE BID SCHEDULE-IV)

Provision of mechanized soil excavation, digging, levelling and allied works with
mechanical diggers and excavators and supply of other construction materials as and
when required at CBDA Biofuel Complex Project sites at Vill: Thengabhat Dist: Durg
1
2

2
Materials
1. Sand
2.Cement
3.Crushed stone
(1/2 inch)
4. Crushes stone
(3/4 inch)
5.Black bricks
6.Red bricks
7.Iron rod (12mm)
8.Iron rod (10mm)
9.Iron rod (8mm)
10.Fencing wire
11. Birla white
cement
12. Murroom
13.Soil
14.Stone dust
15. Chain link
mesh wire (5 feet,
3.15 mm
thickness)
50mmx50mm
(2”x2”) mesh size.

3
Details
Per sq. feet
Per bag

4
Rate

5
GST (%)

Per feet
Per feet
Per piece
Per piece
Per kg
Per kg
Per kg
Per kg
Per bag
Per sq. feet
Per sq. feet
Per sq feet
Per sq feet

NOTES:

1. Bidder have to quote offer (fill up) unit rate with Estimated required quantity (in column no.
4,5, and 6 above) of provision of mechanized soil excavation, digging, levelling and allied
works with mechanical diggers and excavators and supply of other construction materials as
and when required at CBDA Biofuel Complex Project at Vill. Godhi, Dist. Durg.
2. Bidder have to quote offer unit rate (in column no.4 above) of mentioned materials form
separately in rows (row no. 2 above) CBDA will have the right to reject the tender for any
reasons.
3. SOR rate shall include basic rate of material, taxes, GST, transportation and other
expenses.
Page | 10
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 13 -->

SECTION I
Special Conditions of Contract (SCC)

Company Name
Location

Details
CHHATTISGARH BIOFUEL DEVELOPMENT AUTHORITY (CBDA)
vill. Godhi, Dist. Durg.

Street

Biofuel Complex site

Place
Country
Telephone
Mobile No.
Email
Contact Person

Godhi
INDIA
7880161543-45
7880161543-45
skmaitry@gmail.com
Santosh Kumar Maitry

PART-A
For any query please contact at Biofuel Complex, Godhi as per details mentioned above.
1.
2.
3.

4.

5.
6.

7.

8.
9.

CHHATTISGARH BIOFUEL DEVELOPMENT AUTHORITY shall hereinafter be referred
to as CBDA, Raipur as owner and the successful bidder is referred to as vendor.
The offer shall be valid for 30(thirty) days from the date of placing of supply letter.
The material to be supplied will be inspected prior the payment to the bidder. For delivery of
materials the bidder may contact Sh. Samaylal at 7880161545 (Mob) or Sh. Govind
Suryavanshi at 7880161543 (Mob) at Biofuel Complex, Godhi.
The Contract shall be treated as having been entered into as soon as the bid is confirmed by
CBDA in favor of the successful bidder(s) and SD is submitted by the successful bidders.
The contract shall be deemed to be complete as soon as the total quantity of materials is
supplied within stipulated time i.e. within 30 (thirty) days from the date of supply intimation
letter.
Rate must be quoted in Rupees per unit only. The quantity indicated is indicative.
Rate must be quoted exclusive of GST taxes. Rates are to be quoted in Indian Rupees in
words and in figures. In case of any difference between the two, the rates quoted in words
would be considered as final and authentic.
The bidders shall be evaluated on the basis of the lowest quoted amount for the materials.In
case of more than one qualified L1 bidder, the Work Order shall be awarded to the bidder
offering the maximum additional discount on the quoted L1 rates.
If L1 bidder is unable to supply the material within stipulated time period, then L2 bidder will
be offered 100% i.e. (+/- 10%) of material provided L2 bidder matches the rate of L1 bidder.
The vendor’s workmen shall have to abide by the rules regulation including safety & security
regulation of the relevant statutory Acts/Labor laws etc.
Page | 11

CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 14 -->

10. The Supplier will employ his own labour and means; at his own cost for delivering of
Materials as per schedules and payment of wages/compensation to the labourers will be the
sole responsibility of the supplier. The supplier shall ensure that his workmen do not litter
around/within the stores area of the factory areas. They shall not touch any material except
those materials shown to them. If any of his workmen is even found violating these
restrictions, the supplier shall be responsible for making compensation on account of the loss
to the owner on which their decision shall be final and binding.
11. DELIVERY PERIOD: The successful bidders shall deliver the allotted material transport at
his own cost within 7(seven) days from the placing of supply/work intimation letter.
12. The bidders shall submit interest free Security Deposit by Bank Draft or by RTGS in favor of
Chhattisgarh Biofuel Development Authority, Raipur within 3 working days from the day of
issuance of supply intimation letter.
13. Bidder has to attach duly self-attested GST registration certificates, if required.
14. CONFIDENTIALITY: The Contractor shall not, without CBDA's prior written consent,
disclose the contract, or any provision thereof, or any specification, plan, drawing pattern,
sample or information furnished by or on behalf of CBDA in connection therewith, to any
person other than a person employed or contracted by Contractor in the performance of the
contract. Disclosure to any such employed person shall be made in confidence and shall
extend only as far as may be necessary for purposes of such performance. Contractor shall
not, without CBDA’s prior written consent, make use of any document or
information except for purposes of performing the contract.
15. INSURANCE: The Contractor shall maintain at its own cost, all insurances necessary to
cover its liabilities for the performance of the Services under this Contract.
16. NOTICES: All notices and communications under this Contract shall be in writing by hand,
post, e-mail so long as in each case proof of delivery can be demonstrated by the sending
Party to the person at the address, e-mail account as stated below or such other person or
address as may be notified to the other Party from time to time.
17. Bidder has to quote their price against the supply of materials/work in the “Price bid
schedule” provided in the tender document.
18. The bid document duly filled in and signed (including special terms & conditions, general
terms & conditions and price bid document) should reach CBDA at the following address on
or before 15:00 hrs on _____________ :
Assistant Project Officer- PC(I)
Chhattisgarh Biofuel Development Authority
Project office, Biofuel Complex, Village: Godhi, Dist: Durg - 490036
Ph.No: - 7880161544
Email- skmaitry@gmail.com & cbdaraipur@gmail.com

Page | 12
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 15 -->

PART-B
1. ENTIRE CONTRACT
1.1 This Contract represents the entire Contract between the CBDA and the Contractor in
relation to the performance of the Services by the Contractor. Copies of or notice of
requirements under other Contracts between the CBDA and others shall not imply additional
duties or requirements, nor by implication add to or modify the Services.
2. SEVERABILITY
2.1 If any term of this Contract shall be held to be invalid, illegal or unenforceable, the
remaining terms or provisions shall remain in full force and effect and such invalid, illegal
or unenforceable terms and provisions shall be deemed, from the beginning, not to have been
part of this Contract.
3.

FORCE MAJEURE
3.1 The obligations (except the obligation to make payment hereunder) of each Party
under this Contract shall be suspended during the period and to the extent that Party is
prevented or hindered from complying with them by any cause beyond its reasonable control
including but not limited to an act of God, strikes, floods, fire, storm, failures of electrical or
telephone supplies, change in the laws, rules, regulations or orders of any national or
municipal or other governmental body, acts of war or terrorism, riots, civil disturbance or
natural disasters.
3.2 In the event of either Party being so hindered or prevented, the Party concerned shall give
notice in writing of suspension as soon as reasonably possible to the other Party stating the
date and extent of the suspension and its cause. A Party whose obligations have been
suspended as aforesaid shall resume the performance of those obligations as soon as
reasonably possible after the removal of the cause and shall so notify the other Party. In
the event that the cause continues for more than Four (4) months, and Contract to a Change
is not a reasonable way of removing the hindrance or prevention, the Parties agree that
performance of the Services under this Contract shall terminate automatically.

4.

TERMINATION
CBDA shall be entitled to terminate this Contract if the Contractor–
3.1.1 fails to comply with the material terms of the Contract
3.1.2 materially breach of the Contract
3.1.3 is adjudicated or found bankrupt or insolvent or any order is made or resolution passed
for winding up, liquidation or dissolution of the Contractor,
3.1.4 makes a general assignment for the benefit of the creditors
3.1.5 owned property is assigned to any Receiver by a Court of Law
3.1.6 has abandoned the Contract before the Delivery Date/Primary Term, or
Page | 13

CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 16 -->

3.1.7 has failed to commence Work or has without any lawful excuse under the prevailing
conditions suspended the progress of the work necessary for Supply for more than
seven (7) days after receiving a written notice from the CBDA to proceed with the
works.
3.1.8 CBDA in turn also assures to make payment of material supplied within the specified
timeline else Contractor will be at liberty to stop further delivery of next batch of
material till clearance of dues.

4. GOVERNING LAW & ARBITRATION
4.1 Governing Law: This Contract is to be construed and governed in accordance with
laws of India. The Parties hereto irrevocably submit to the exclusive jurisdiction of the
courts at Raipur, Chhattisgarh, India.
4.2 Arbitration: This Contract shall be governed by and construed in accordance with the
laws of India. Any dispute between the CBDA and the Contractor in respect of matters
arising out of and relating to this Contract shall be resolved amicably through good
faith negotiation. If any dispute cannot be resolved amicably, the aggrieved Party shall
be entitled to refer the unresolved dispute(s) to arbitration by serving notice on the other
Party.
4.3 The provisions of Indian Arbitration and Conciliation Act 1996 or any statutory
modification or re-enactment thereof for the time being in force

shall

govern such

Arbitration proceedings. The venue for such arbitration shall be Raipur, Chhattisgarh
India.

5. COMPLIANCE TO HEALTH AND HYGINE
That Contractors working on behalf of CBDA shall conform to all the norms of safety, health
and environmental upkeep.
6. CBDA’S RIGHT TO ANNUL BIDDING PROCESS OR ACCEPT/REJECT A BID
CBDA reserves the right to accept a bid other than the lowest and to accept or reject any bid in
whole or part, to annul the bidding process or to reject all bids with or without notice or reasons.
Such decisions shall be without any liability whatsoever upon the CBDA. CBDA’s decision in
this regard shall be final and binding for all Bidders

Page | 14
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 17 -->

SECTION II
Scope of Work
The scope of work under this contract shall include in general but not limited to the following:
‘Provision of mechanized soil excavation, digging, levelling and allied works with
mechanical diggers and excavators and supply of other construction materials as and
when required at CBDA Biofuel Complex Project sites at Vill. Godhi, Dist. Durg and
Vill: Thengabhat, Dist: Durg.’ as per specific quality criteria given below
Tender Specification
1. Specifications - The list of above-mentioned materials (Pg. 7-10 Price Bid schedule)
shall be in complete accordance with the work order provided by CBDA as it is.

2. The total cost of material includes delivered quantity of all the materials at Biofuel
Complex site Vill. Godhi, Dist. Durg and Vill: Thengabhat, Dist.: Durg shall n o t
include all manpower, t o o l s , tackles, u n - loading at Point of transfer of ownership.
Transportation will be borne by the bidder from Point of transfer of ownership.

3. Payment of the material will be made by CBDA to the contractor on actual quantity on
physical weighing in presence of both the representatives of CBDA & contractor at
ex- Biofuel complex site basis.

Page | 15
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 18 -->

ANNEXURE-I
To,
Assistant Project Officer- PC(I)
Chhattisgarh Biofuel Development Authority,
Project office, Biofuel Complex, Village: Godhi, Dist: Durg – 490036
Sub.: Acknowledge by return e-mail - receipt of this Letter of Invitation to Tender (LIT)
and its accompanying documents, and confirmation to submit a Proposal.

Dear Sir/Madam,
I/We acknowledge by this return e-mail the receipt of this Letter of Invitation to
Tender (LIT) and its accompanying documents, and confirmation to submit a Proposal. I /
We agree to submit the attested hard copies of tender documents as per the Notice Inviting
Tender along with our offer.

I / We undertake and confirm that in case we do not submit this tender document
with our offer or the documents are not found in order by CBDA / not acceptable to CBDA
our tender shall be rejected by CBDA without any correspondence in this regard.

SIGNATURE AND SEAL OF TENDERER

Place:

Date:

Page | 16
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 19 -->

ANNEXURE – II
DECLARATION BY THE TENDERER(S)

We __________________________________________________ (Name of the Tenderer)
hereby represent that we have gone through and understood the bid documents (including but
not limited to), the Technical Requirements in Part

to Part

and

that our bid has been prepared accordingly in compliance with the requirements stipulated in
the said documents.

We are submitting bid documents as part of our bid duly signed and stamped on each page
in token of our acceptance and shall form part of our bid. In the event of award of contract
to us, all the parts shall be considered for constitution of Contract Agreement.

SIGNATURE AND SEAL OF TENDERER

Place:

Date:
Note: This declaration should be signed by the Tenderer or Tenderer’s authorized
representative who is signing the bid.

Page | 17
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 20 -->

ANNEXURE – III

DECLARATION BY THE TENDERER(S) REGARDING BLACKLISTING

We

(Name of the Tenderers) hereby

declare that we have not been placed on any Holiday List/ Black List declared by M/s.
Chhattisgarh Biofuel Development Authority or its Nodal Agency CREDA or its
Administrative Department (presently the Department of Energy, GoCG), except as below:
1.

2.

3.

It is understood that, if this declaration is found to be false in any particular, M/s.
Chhattisgarh Biofuel Development Authority or its Nodal Agency CREDA or its
Administrative Department (presently the Department of Energy, GoCG) shall have all the
rights to reject my/ our bid. If the bid has resulted in a contract, the contract will be liable to
be terminated without any reimbursement for works performed/ executed.

SIGNATURE AND SEAL OF TENDERER

Place:

Date:

Page | 18
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 21 -->

ANNEXURE – IV

FORMAT FOR GIVING CONSENT & BANK DETAILS FOR E-PAYMENT
Dear Sir,
With the reference to your letter, we hereby agree to accept the payment of our
bills through direct credit to our below mentioned Bank Account through Internet Banking:
1.

Beneficiary’s Name & Address with Pincode

2.

Bank Name

3.

Branch Name

4.

Address of the Branch

5.

STD Code & Phone No. of Branch

6.

Branch Code
9 Digit MICR code of Branch as appearing
on the cheque
(copy of cancelled cheque may be enclosed) *

7.
8.

Bank Account No.

9.

Account Type (SB/CA/CC)

10. Branch IFSC Code
11. Email address of the Vendor
12. Mobile No. of the Vendor
13 GST No.
*Please attach a blank cancelled cheque or photocopy of a cheque issued by your bank
relating to your above account for verifying the accuracy of the 9 Digit MICR Code.
I/ We hereby declare that the particulars given above are correct and complete.

(Signature of Authorized Person with seal)
Place:

Date:

Enclosure: As Above
Page | 19
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 22 -->

ANNEXURE –V
UNDERTAKING FOR NON-ENGAGEMENT OF CHILD LABOUR
Name of Work: Contract for Provision of mechanized soil excavation, digging, levelling
and allied works with mechanical diggers and excavators and supply of other
construction materials as and when required at CBDA Biofuel Complex Project sites at
Vill. Godhi, Dist. Durg and Vill: Thengabhat, Dist: Durg.
Tender No.: CBDA/2026/PT/BFC/001
I/ We hereby declare that:
A. We are committed to elimination of child labour in all its forms.
B. Neither we nor any of our nominated sub-contractor(s) are engaging Child Labour
in any of our work(s) in terms of the provisions of the Child Labour (Prohibition and
Regulation) Act, 1986 and other applicable laws.
C. We as well as our nominated sub-contractor(s) undertake to fully comply with
provisions of the Child Labour (Prohibition and Regulation) Act, 1986 and other applicable
labour laws, in case the work is awarded to us.
D. It is understood that if I/ We, either before award or during execution of Contract,
commit a transgression through a violation of Article b/c above or in any other form, such
as to put my/our reliability or credibility in question, the Owner is entitled to disqualify us
from the Tender process or terminate the Contract, if already executed or exclude me/us
from future contract award processes. The imposition and duration of the exclusion will be
determined by the severity of transgression and determined by the Owner. Such exclusion
may be for a period of 1 year to 3 years as per the procedure prescribed in the guidelines
for holiday listing of the Owner.
E. I/ We accept and undertake to respect and uphold the Owner’s absolute right to resort to
and impose such exclusion.

(Signature of Authorized Person with seal)
Place:
Date:

Page | 20
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder

<!-- page 23 -->

ANNEXURE – VI

DECLARATION OF RELATIONSHIP WITH DIRECTORS/ EMPLOYEES OF CBDA
The tenderer should declare the following information in exhaustive details:
Whether proprietor is a Director or is related to any

YES

Director/ Employees of CBDA at present or retired within
the past two years from the due date of submission of Bids.
Whether any partner or member of the firm is a Director

NO
YES

or is related to any Director/ Employees of CBDA at
present or retired within the past two years from the due date

NO

of submission of Bids.
Whether any of the Directors of the CBDA is a director or

YES

is related to any employees of CBDA at present or retired
within the past two years from the due date of submission of

NO

Bids.

SIGNATURE AND SEAL OF TENDERER

Place:

Date:

Page | 21
CBDA/2026/PT/BFC/001

Stamp & Signature of the Bidder
