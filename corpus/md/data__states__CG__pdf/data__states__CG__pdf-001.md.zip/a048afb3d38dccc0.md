---
doc_id: "a048afb3d38dccc0"
source_url: "https://www.cbda.in/sites/default/files/tender-document/Extension%20notice%2030%20jan%20PT%20002.PDF"
ministry: "Chhattisgarh Biofuel Development Authority (CBDA)"
title: "Extension notice 30 jan PT 002.PDF"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ff9f551ba49ae6c0"
---

<!-- page 1 -->

Chhattis garh Biofuel Developm ent Autho rity(CBDA)
@ept. of Energy, Govt. of Chhattisgarh)
Biofuel Complex project

vill. Godhi, Tahsil- Dhamdha, Dist. Durg (c.G.) 490042 Mo. 788016rs43-4s

TENDER NO. CBDA/2O25iPTiGHPIOO2

This is to noti$z that last t'ut. fo, submission of Bid for the Tender ,Fabrication,
Installation and Commissioning of Dark Fermentation Reactor and Associated
Biomass-Based Hydrogen Production Trials Using Nisargruna Technology

Systems for

at CBDAtsiofuel

complex site, village Godhi, District Durg (c.G.)' with Tender no. GBDN2025/qT/GI+/002
, is hereby extended up to 14:00 tlrs. till 16 February 2026 instead of earlier scheduled date

and

time of submission of bid i.e. up to 14:00 rhs. on 30 January 2026.

Date & Time for Bid Opening will now be opened on 16 February 2026

at 14:30

Hrs. Authorized representative of Bidder shall attend.
(Approved By CEO, CBDA)

7ol otl z'o 4

Asst. Project Officer (PC-D
