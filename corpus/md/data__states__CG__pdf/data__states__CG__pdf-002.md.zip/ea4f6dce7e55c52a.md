---
doc_id: "ea4f6dce7e55c52a"
source_url: "https://www.dbgirls.org/Academic_Integrity_and_Research_Ethics_Policy.pdf"
ministry: "Govt. Dudhadhari Bajrang Girls Postgraduate College,Raipur, Chhattisgarh"
title: "Academic_Integrity_and_Research_Ethics_Policy"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "68cc6da6d7d5d5f8"
---

<!-- page 1 -->

OFFICE OF THE PRINCIPAL
GOVT. D.B. GIRLS’ P.G. (AUTONOMOUS) COLLEGE,
KALIBADI CHOWK, RAIPUR (C.G.)
Phone/Fax - 0771-2229248, Email-dbgirls@yahoo.co.in

ACADEMIC INTEGRITY AND RESEARCH ETHICS POLICY-2018-2021
NOTE: This policy statement is based on the notification issued by the University Grants
Commission on 23rd July, 2018 entitled ‘UNIVERSITY GRANTS COMMISSION
(PROMOTION OF ACADEMIC NTEGRITY AND PREVENTION OF PLAGIARISM IN
HIGHER EDUCATIONAL INSTITUTIONS) REGULATIONS, 2018’ Ref: F. 118/2010(CPP-II).
As per the UGC guideline and notification “Promotion of Academic Integrity and Prevention
of Plagiarism in Higher Educational Institutions” Regulations, 2018, the faculty, students and
research scholars are required to have ethical and moral values for academic pursuit.
Plagiarism has become a serious problem during current ICT era. The Plagiarism Policy of
Govt. D.B. Girls’ P.G. College, Raipur (Autonomous) has been formulated with a view to
ensure no plagiarism in the research work that is carried out by its faculty, researchers or
students in the form of thesis, dissertation and publication of research papers, chapters in
books, full-fledged books and/or any other similar work.
OBJECTIVES
i.

To create awareness about responsible conduct of research, thesis, dissertation,
and promotion of academic integrity and prevention of misconduct including
plagiarism in academic writings among students, faculty, researchers and the
staff.

ii.

To establish institutional mechanism through education and training to
facilitate responsible conduct of research, thesis, dissertation, and promotion
of academic integrity and deterrence from plagiarism.

iii.

To develop systems to detect plagiarism and to set up mechanisms to prevent
plagiarism, all Ph.D. supervisors of the college registered in URKUND.



<!-- page 2 -->

REGULATORY AUTHORITY
College Level Academic Integrity and Ethical Committee (CAIEC) Composition for College
Level Research/PhD Programmes
1.
2.
3.
4.
5.
6.

Chairperson – Principal
Organising Secretary
Member – Senior Academician(s) from each Faculty nominated by the
Principal.
Member – Member(s) nominated by the Principal as experts from outside the
College
Member – Member(s) anti-plagiarism experts nominated by the Principal.
Member – Member representative from the student body nominated by the
Principal.

FUNCTIONS AND POWERS
(a) The Chairperson of the CAIEC shall be the Principal of the College.
(b) The tenure of the Committee members shall be for five years, with the exception of the
Student Representative.
The CAIEC shall investigate cases of plagiarism as per the provisions mentioned in these
regulations. (c) The CAIEC shall provide a copy of the report to the person(s).
