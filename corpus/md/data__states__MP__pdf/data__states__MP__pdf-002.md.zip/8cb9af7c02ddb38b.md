---
doc_id: "8cb9af7c02ddb38b"
source_url: "https://mppgcl.mp.gov.in/Amendment_Order_898_19062026der.pdf"
ministry: "M.P Power Generating Company Limited (MPPGCL), Madhya Pradesh"
title: "Amendment Order regarding Distribution Factor of Incentive for the FY 25-26"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "f4c303a366ad6e38"
---

<!-- page 1 -->

MADHYA PRADESH POWER GENERATING CO. LTD.

(A wholly owned Government of Madhya Pradesh Undertaking)
(ed) CIN - U4009MP200iSGC0I4882

s Block No.6, 2° Floor, Shakti Bhawan, Rampur, Jabalpur-482008 (M.P.)

Phone No. (0764)-2664589/2702600; Fax No. (0764)-2664572/2668050;
email:edomg_mpeb@rediffmail.com
No.07-03/GCC, i 8 i
/GCC/Incentive/Yearly/ # Jabalpur, dtd 7] 9 JUN 226
Amendment Order

Sub: Incentive Policy of MPPGCL for FY 24-25 to FY 25-26- declaration of “Distribution Factor of the

Incentive” for FY 25-26.

As per this office Order No. No.07-03/GCC/Incentive/Yearly/888, Jabalpur dated 6.06.2026 the
"distribution factor of the incentive" of various thermal & Hydel Power stations of MPPGCL for FY 25-
26 has been issued. The order is hereby partially amended as under
The following line is added:

“The distribution factor of the incentive is calculated based on weighted average basic salary for the
year 25-26.”
[Approved by competent authority]
Qkaes—
( Rajesh Shrivastava )
Addl CE-II
O/o ED(O&M:Gen)
MPPGCL, Jabalpur
Copy to:
i. Executive Director/Chief Engineer, O&M:Gen./HR&A/Engineering/FM/CS/Civil Engineering/

R&M/ MM/ PRG / O&M:Hydel, MPPGCL, Jabalpur.

2. The Executive Director / Chief Engineer (Gen) SSTPP/ATPS/STPS/SGTPS, MPPGCL, Khandwa/

Chachai/ Sarni/ Birsinghpur.

३. The Chief Financial Officer, MPPGCL, Jabalpur.

4. The Chief Security Officer, MPPGCL, Jabalpur.

5. Addl. Chief Engineer (Gen.-Stores)/ THC, MPPGCL, Jabalpur/Sirmour.

6. The Superintending Engineer (Civil: HM&SI), MPPGCL, Jabalpur.

7. The SE(O&M), PHPS/ RHPS/ RABSHPS/ MHPS/ GHPS/ Bansagar-I/II/III/IV, MPPGCL Totladoh/

Chanderi/ Bargi nagar/ Shivpuri/ Gandhi Sagar/ Silpara/ Deolond/ Jhinna.

8. The Chief/ Senior Medical Officer Khandwa/ Chachai/ Sarni/ Birsinghpur MPPGCL.
9. The Jt. Director/ Director/ Senior Accounts Officer/ Accounts Officer (COG&HS) Jabalpur/

Khandwa/ Chachai/ Sarni/ Birsinghpur/ Sirmour MPPGCL.

20. EA to Managing Director / Director Technical/ Commercial, MPPGCL,JABALPUR

. Payroll in-charge, MPPGCL, Jabalpur

42. AE(IT), O/o ED(HR&A), MPPGCL Jabalpur-For Uploading on Company's ‘Ue

(Shreya Ghosh Prasad)
EE(GCC)
O/o ED(O&M:Gen)
MPPGCL, Jabalpur
E:\Office GCC\SHREYA\GENERATION\25-26\ Incentive Policy\yearly 25-26\Order DT for yearly-26 -ammendment.docx Page t
