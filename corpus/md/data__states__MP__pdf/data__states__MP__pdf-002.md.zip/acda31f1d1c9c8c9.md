---
doc_id: "acda31f1d1c9c8c9"
source_url: "https://ssc.gov.in/api/attachment/uploads/masterData/NoticeBoards/corrigendum_cht24_283325.pdf"
ministry: "Staff Selection Commission (SSC), Madhya Pradesh Region"
title: "COMBINED HINDI TRANSLATORS EXAMINATION, 2024 (PAPER-II) – CLARIFICATION REGARDING ‘GENERAL INSTRUCTIONS FOR THE CANDIDATES’ IN ADMISSION CERTIFICATE."
date: ""
pages: 1
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "0a2b7b17a486abc8"
---

<!-- page 1 -->

F. No. HQ-IT015/08/2024-IT (E-8885)
Staff Selection Commission
IT Section
***
Corrigendum
Combined Hindi Translators Examination, 2024 (Paper-II) – Clarification
regarding ‘General instructions for the candidates’ in Admission
Certificate.
अभ्यर्थिय ों क सूर्ित र्कया जाता है र्क परीक्षा केन्द्र में घडी (केवल गैरइलेक्ट्रॉर्िक) एवों पेि ले जािे की अिुमर्त है । अन्य सभी र्िर्दे श यथावत रहें गे Ӏ
The candidates are hereby informed that watches (non-electronic
only) and pen are allowed to be carried in the examination center. All
other instructions will remain the same.

Under Secretary to the Govt. of India
28.03.2025

Confidential
