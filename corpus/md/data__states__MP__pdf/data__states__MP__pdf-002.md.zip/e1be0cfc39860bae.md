---
doc_id: "e1be0cfc39860bae"
source_url: "https://mpcost.gov.in/images/files/sadmin/718/Tendernotice_1_1.pdf"
ministry: "Madhya Pradesh Council of Science and Technology (MPCOST), Bhopal, Madhya Pradesh."
title: "📄 Click here to view E-Tender details"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "46ee3eb2bd0feea1"
---

<!-- page 1 -->

e/;izns’k foKku ,oa izkS|ksfxdh ifj"kn~]
foKku Hkou] usg: uxj] Hkksiky
fufonk Ø-

222 @,uvkbZVh@,eihlh,lVh@Hkksiky

fnukad 19@01@2026

lkQ&lQkbZ O;oLFkk gsrq bZ&fufonk vkea=.k
¼v½ lkekU; tkudkjh
Ø

fufonk izfØ;k dk fooj.k

frfFk

le;

01 fufonk izi= MkmuyksM djus dh
izkjafHkd frfFk
02 izhfcM frfFk ,oa le;
03 fufonk tek djus dh izkjEHk
frfFk ,oa le;
04 fufonk izi= dks MkÅuyksM ,oa
tek djus dh vafre frfFk ,oa
le;
05 fufonk dh rduhdh foM [kqyus
dh frfFk ,oa le;
¼c½ izi= ,oa bZ,eMh dk fooj.k

19-01-2026

11-00 AM

30-01-2026
19-01-2026

3-30 PM - 4:00 PM
11-30 AM

23-02-2026

5-30 PM

25-02-2026

3-00 PM

izi= ,oa bZ,eMh
v fufonk izi=
c bZ,eMh jkf’k

fooj.k

jkf'k

lkQ&lQkbZ
O;oLFkk

:- 5]000@&
:- 1-00 yk[k

izeq[k iz’kklu

e/;izns’k foKku ,oa izkS|ksfxdh ifj"kn~]
foKku Hkou] usg: uxj]
Hkksiky&462003
Qksu u- 0755&2671900
QSDl ua- 0755&2671600

<!-- page 2 -->

Signature Not Verified
Digitally signed by Neelima Agaraiya
Date: 2026.01.13 13:05:55 IST
Location: Madhya Pradesh-MP
