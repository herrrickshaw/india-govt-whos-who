---
doc_id: "ebd8e9fe52b498fa"
source_url: "https://jiwaji.edu/download/file/tender/E-_TENDER.pdf"
ministry: "Jiwaji University, Gwalior, Madhya Pradesh"
title: ""
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "7de393d50cfbf4e7"
---

<!-- page 1 -->

> {Ree जा हा = tains imitans: cc NN reinhe eh BN fe
जीवाजी विश्वविद्यालय, ग्वालियर |

BHT / एफ.जे.यू / TH / 2028 JB ५१ दिनांक -AI-7- 2926

. ई--निविदा आमंत्रण सूचना-पत्र =
जीवाजी विश्वविद्यालय ग्वालियर में नवीनीकरण ,/ विशेष वार्षिक सिविल मरम्मत कार्य i
करने के लिये पंजीकृत योग्य अनुभदी ठेकेदारों से ऑनलाइन टेंण्डर ई-प्रोक्‍्योरमेंट्सिस्टग के |
| |
| diga https://mptenders.gev.in पर ऑनलाईन निविदायें आमंत्रित की जाती हैं। जिसकी |
टेण्डर आई.डी. 2026 NWA! 520!:0_। है। निविदा टेण्डर दिनांक [.3- 28: 2०२6 5:00 बज |
तक आमंत्रित की जाती है, निविदा की विस्तृत जाएकारी जीव्जी विश्वविद्यालय ci * |
e
वेबरगाइट www. jiwajicdu पर भी देखी जा सकती है। |
Mare 2 छा LG
mT
