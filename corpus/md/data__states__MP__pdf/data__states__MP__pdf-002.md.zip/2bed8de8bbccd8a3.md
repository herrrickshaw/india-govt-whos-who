---
doc_id: "2bed8de8bbccd8a3"
source_url: "https://jiwaji.edu/download/file/tender/Paraffin_Embedding_Bath_compressed.pdf"
ministry: "Jiwaji University, Gwalior, Madhya Pradesh"
title: ""
date: ""
pages: 16
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "c083a619ae701200"
---

<!-- page 1 -->

जीवाजी विश्वविद्यालय, ग्वालियर
JS दिनांक: 06/08/26
was fixie ई-निविदा आमंत्रण सूचना.
https://mptend विश्वविद्यालय 4 में पी,एम उषा के उपकरण / सामग्री क्रय करने हेतु अधिकृत विक्रेता अथवा निर्माता से
Pp: ptenders.gov.in पर ऑनलाइन निविदा आमंत्रित की जाती है।
- : अनुमानित | धरोहर राशि | प्रपत्र की
| 2026_JIWAJ $27 bul कीमत
~ —527327_) | Supplyand Installation of | ,20,00,000/- | 3,60,000/- | 33,500:
Open Gym and Fitness
Equipment
2 | 2026_JIWAJ_527330_I. Automatic Granulator 4
WAT 827330 लिए आह
2026 ग७७7 875ऊ3_]। फण्लाऋए Chart (Small 20,00,000/- | “60,000/- | ~2,000/-
Animai Blood Pressure "
Measuring Instrument - j
NIBP & Ipp
| | 2026_JIWAJ_527336_I, | Digital 4,85,000/- | 5550/- | io0o/-
Spectrophotometer
2026_JIWAJ_ 527338_ | Teleprompter with 3,50,000/- | 20.S00/- 2,000/-
Camera and Compatible
core i-7 Laptop
6 | 2026 _JIWAJ_527339_i | Automatic Sonicator 2,000/-
7 | 2026_JIWAJ_527340_I_ | Paraffin Frobedding Bath 2,300/-
|8 | 2026_ग9/&7_ उ27347 | Stectrical Stimulation 32,00.000/- | 3,000/- | 4,000/-
9 | 2026_JIWAJ_527342_I CPM Therapy (Knee) 3,04,000/-
७ आह WAS 5273434
निविदा प्रपत्र एवं निविदा की समस्त शर्तों का अवलोकन विश्वविद्यालय की वेबसाइट Www. jiwajiedu पर भी किया
जा सकता है।
4. ऑनलाईन निविदा क्रय करने की प्रारम्भ दिनांक 40.08.2026 तक 05:00 PM तक
2. ऑनलाईन निविदा क्रय करने एवं जमा करने की अंतिम दिनांक 34.08.2026 तक 5:00 PM तक
3. ऑनलाईन टेन्डर खोलने की दिनांक 04.09.2026 तक 05:00 PM तक
4, निविदा की शैष तिथियों सम्पूर्ण जानकारी, शर्ते एवं समस्त संशोधन केवल उपरोक्त auld गई वेबसाइड पर देखी जा
सकती है इस हेतु अलग से कोई विज्ञापन,समाचार पत्रों में प्रफाशित नही किया जायेगा। *
5. कार्य/सामग्री की मात्रा कम// ज्यादा भी हो सकती है। ‘cata के
6. निविदा स्वीकृत,/अस्वीकृत / निरस्तीकरण या संशोधन के अधिकार कुलसचिव, जीवाजी विश्वविद्यालय. ग्वालियर
पास रहेंगे। g

<!-- page 2 -->

/ NOTICE INVITING TENDER DETAILS
ka Description
ft | Department Name Jiwaji University, Gwalior -474044 (M.P.)
Tender Subject Supply, Installation &Commissioning of
wa Paraffin Embedding Bath
a ee
[4. | Products/Equipments/item (both hardware and software)
sania हि masimns Po
| 7. | Paraffin Embedding Bath Rs. 200/-
6. | EMD/Bid security Registrar,
Payable to Jiwaji University,Gwalior -47407 (M.P.)
EMD has to be paid online through
www. mptenders.gov.in
7. | Tender Fee The tender fee to be submitted online through
(non-refundable) www.mptenders.aov.in paid in the favor of Registrar,
Jiwaji University, Gwalior.
| | Downloading of Tender | www.mptenders.gov.in www.jiwajiiedu
Documents
* | Submission of E-Bid www.mptenders.gov.in
For any delay, University cannot be held responsible.
0. | Price Bid Opening www.mptenders.gov.in
Place of Technical 80... Administration Block,
Opening Jiwaji University, Gwalior (M.P.
Officer Inviting Registrar,
Bids/Contact Person Jiwaji University,
Gwalior - 474 074, (M.P.
| 73. | Eligibility Criterion As per “Special Terms and Conditions”
Procedure For Bid e-BID has to be submitted through
Submission www.mptenders.gov.in.alongwith the documents as per
special terms and conditions,
Thebidding documents have to be submitted to:
The Registrar,
Jiwaji University, .
Gwalior- 474074(M.P.)
Note: Registrar will not hold any risk and responsibility for
non-visibility of the scanned document or the loss
of documents intransit.
eae General Terms and As per tender document
Conditions
5 a aS
acts y = Page 2 of 6

<!-- page 3 -->

SPECIAL TERMS AND CONDITIONS
any/ the tenderer should be in existence for the last S years. —
2 The caune tenderer should have at least one Service Centre in India.
| 3. The tenderer should be a Manufacturer or the authorized distributor/dealer of the
uipment/item manufacturer,

4. The suche firm should have an average annual tumover of at least Rs. 70,000/-
(Rupees Seventy Thousand only) for the last three financial years preceding the |
date of tender. Copy of Audited Balance Sheet of the firm with Audit Report / CA
certified turnover certificate with UDIN number / Copies of GST Return should be
submitted as a proof,

5. Delivery Period: The delivery should be made within 30 days from the date of
receipt of purchase order by the tenderer.

6. Warranty: All items/equipments supplied by the tenderer shall be under on-site
Comprehensive warranty for a period as specified in the “Technical Bid” from the
date of installation by the manufacturer or its representative. Comprehensive ’

warranty should explicitly include all spare parts and system consumable parts. Any
repair work or replacement of spares needs to be done on site and the manufacturer
must confirm this in the quotation.
7. Installation: The installation should be done at the respective Laboratories as
mentioned in the Annexure —07 at no extra cost.

8, Response Time: The response time of the tenderer to attend to any complaint upon

receipt of the complaint/information from the user should not be more than 48 hours.

9. Advance payment either direct or through bank will not be accepted in any case. As

per rule, full payment will be made after receipt of material, inspection thereof and
after satisfactory installation and working of the entire equipment/item. LC will be
opened in case of imported equipments/items, if quoted in foreign Currency. The
currency quoted must be of the country of origin.

0. Taxes will be applicable as per State/Central government guidelines.

/4.The bidder shall be responsible for getting the consignment cleared and deliver the
goods. The expenses on it and concessional duties, if any should be included in the
cost of the equipmentiitem. ‘

72.The tenderer should avoid the use of vague terms such as “extra as applicable”.

Such tenders will be rejected,

3.Printed conditions on the back of the offer submitted will not be binding unless
separately mentioned.

74. Quotations for the accessories to be considered together as one unit and thus total
price shall be treated as your bid for the tender. Optional items may be quoted
separately. Where the equipment/item offered is controlled by a preloaded personal
computer and it is possible to use an indigenous PC, the same should be quoted
instead of an imported PC. The same would apply to a printer or any compiled other
accessory or subsystem.

5.Following documents should be submitted along with tho bidding form
otherwise the tenders are liable to be disqualified:

i. Proof of Registration/Incorporation Certificate indicating that the Company/the

tenderer Is in existence for the last 5 years.
werk Page 3 ०6
L ANS =
है! क्र

<!-- page 4 -->

i ing Documents indicating that the tenderer is the Manufacture or the
{ मर Papeete dealer of the corrempeiding equipment / item Manufacturer
ili, Supporting documents for registration of the Micro & Small Enterprises (MSEs)
and Start-Ups of Madhya Pradesh only for the tendered items, if applicable
7 iv. Copy of PAN No issued by Income tax department and IT retums for the last
three financial years preceding the date of tencer
v. Copies of GST Registration Certificate and GSTR 38 of last three months
vi Proof of average annual turnover of Rs. 70,000/- (Rupees Seventy Thousand
only)for the last three financial years preceding the cate of tender (copies of
Audited Balance Sheet of the firm with Audit Report / CA certified turnover
Certificate with UDIN number / Copies of GST Return)
vi, — Supporting document indicating that the Company or tenderer have at least one
Service Centre in India
vill List mentioning the addresses and contact persons with phone numbers of the
Service Centers
ix, The list of customers, to whom the bidder had supplied identical materials in the
past
x Declaration on Rs. 500/- notarized stamp paper as per Annexure - 07

xi Online EMD of Rs. 2400/- (Rs. Two Thousand one hundred only) submission

slip drawn in favor of “Registrar, Jiwaji University, Gwalior.

xii ‘Special Terms and Conditions'duly signed & office Seal affixed as a token of

acceptance of Special Terms and Conditions.
xii Documents in supports of Technical Specifications for the equipmentiitem as
mentioned in Annexure - 02, clearly mentioning the make and model
Note:

The Registrar, Jiwaji University, Gwalior will not hold any risk and responsibility
for Non-visibility of scanned document or non-receipt of hardcopies or loss in
transit

I The Documents that are received in time will only be considered for Technical Bid
Evaluation.

Ul. The tenderer will be disqualified at any stage of the tender process. if found to
have mislead or furnished false information in the Forms/Statements/Certificates
submitted in proof.

'V. The Registrar, Jiwaji University, Gwalior does not bind himself to accept the
lowest or any tender and he reserve the right to reject any offer without assigning
any reason.

6.Each page of the tender should be signed and stamped by the bidder,
TENDERER
Signature & Seal
Si L शा jo _—
L ait. se lesm
) हे Page 4046

<!-- page 5 -->

A ‘INSTRUCTIONS TO BIDDERS'

The Instructions given below must be read very carefully, as failure in compliance with any

of these may render the offer liable for rejection. If a bidder has any doubt about the

meaning of any stipulation herein, General Purchase Condition, specification of materials or
any other enclosed document, he should immediately obtain the clarification/information in
writing.

4. Ernest money Deposit (EMD) '

i) E-Tender shall be submitted online along with an earnest money without which
tenders will not be considered, The amount should be deposited online.

2) The Micro & Small Enterprises (MSEs) and Start-Ups of Madhya Pradesh registered
for the tendered items shall be exempted from payment of Earnest Money under
provisions of M. P, Bhandar Kraya Niyam and Sewa Uparjan Niyam 2045 {as
amended in 2022).

3) Refund of earnest money:

a, The eamest money of unsuccessful tenderer shall be refunded soon शीश
finalization of Tender.

b. The eamest money of successful tenderar shall be refunded after installation
and commissioning of the equipment/item supplied at site and after furmishing
of Performance Bank Guarantee,

4) The EMD shall be forfeited, if:

a. Bidder withdraws the bid before expiry of its validity. ९

9. Successful bidder does not accept the order or fails to enter into a contract
within validity period of offer.

0. Successful bidder fails to furnish Security Deposit within one month of
intimation/ date of issue of Purchase Order,

2. Acceptance of University Payment Terms:
The Standard Payment terms shall be -
|. 400% of all inclusive prices of the materials will be paid on receipt and acceptance
of the material in good condition, installation and commissioning of the
equipmentiitem supplied at site and after furnishing of Performance Bank
Guarantee equal to 3% of the tender value in cash or Demand Draft, FDR, Banker’s
Cheque and Irrevocable Bank Guarantee of any Commercial Bank.

I LC will be opened in case of imported equipments/items if quoted in foreign
Currency. The currency quoted must be of the country of origin, Company/bidder
should attach a letter in a sealed envelope stating in which currency they have
quoted the price in price bid form.

3. Price Basis:
The prices quoted shall be on FOR destination basis as per annexure-0/ and also shall
include: by
et Set Ss
ae i ee
L, ae 26 | " +s Page ५०१6

<!-- page 6 -->

a) Transit Insurance
( b) All Taxes, Duties and Levies,
4. Delivery:
The Supply, Installation, and Commissioning of the material: The bidder shall offer hig best,
realistic and firm delivery, which shall be specific and guaranteed, Delivery period shall be
reckoned from the date of P.O, which is the first intimation of acceptance of bidder's offer,
Final date of delivery shall be evidenced by date of dispatch of materials as per
transporter’s Lorry Receip/Goods ReceipwRR/PWB/AWB. For delivery beyond contractual
delivery period, provisions of ‘General Purchase, conditions’ shall apply.

5. It is not binding on university to accept the lowest or any bid. The University reserves the
right to place orders for individual items with different bidders and to revise the quantities at
the time of Placing the order and in such event also, the quoted rates, terms and conditions
shall apply. The order for the materials may also be split up between different bidders to
facilitate quick delivery of critically required materials, University further reserves the right to
accept or reject any/all bids without assigning any reason thereof, Final decision on bids
also depends on the components/accessories/additional features offered.

6. Orders placed against this tender enquiry shall be subject to ‘General Purchase Conditions
of University, copy of which is enclosed. Bidders are requested to confirm acceptance of
these conditions into in their Offer.

7. Make/Brand of items offered shall be specified failing which offers are liable to be rejected.
It shall be appreciated if one copy of detailed descriptive literature/ Pamphlets is enclosed .

along with the offer which may help technical evaluation. In a case material offered is ISI
Marked /tested at any Govt. Recognized test house; copies of relevant certificates shall be
furnished along with the offer.
Oa क्र
कप ~ रा
Me शत rai es
lL - Page 6 of I6

<!-- page 7 -->

a GENERAL PURCHASE CONDITIONS
SECTION -।
GENERAL
| i. The following terms and expressions used herein shall have the meaning as indicated
therein Supplier / Vendors; shall mean the individual firm or Partnership firm or company
whether incorporated or otherwise in whose name the purchase order is addressed and
Shall include its permitted assignees and successors, Purchaser shall mean Registrar
Jiwaji University, Gwalior - 47404
2. Reference: The purchase order Aumber must appear on all the correspondence,
packing slips, invoices, drawing or any other document or Paper connected with the
Purchase order:
3. Waiver: Any waiver by the purchaser of the terms and conditions of the purchase order
shall not constitute any right for Subsequent waiver of any other terms or conditions
4. Sub-letting and Assignment: The Supplier shall not sublet, transfer or assign this order
or any part thereof or interest therein or benefit or advantage, thereof in any manner. है
5. Supplier Liability: Supplier hereby accepts full responsibility and indemnifies the
University and shall hold the University harmless from all acts of omission and
commission on the part of the supplier, his agents, his subcontractors and employees in
execution of the purchase order. The Supplier also agrees to defend and hereby
undertakes to indemnify the University and also hold it harmless from any and all claims
for injury to or death of sny and all Persons including but not limited to his/her employees
and for damage to the Property arising out of or in connection with the performance of
the work under the purchase order.

6. Checking/Testing: Upon receipt at our Stores, if the equipmentiitem does not meet the
Specifications, they shall be rejected and returned to the supplier for repair/modification
etc. or for replacement. In such cases all expenses including to-and-fro freight, re-
packing charges, transit insurance etc. shall be to the account of supplier,

7. Packing and Marking: All Mmaterials/equipmentitem shall be securely packed to the
requirements of transportation by Air/Rail/Road/Sea. All exposed services! connections/,
protrusions shall be properly protected, All unexposed part shall be packed with .
due care and the packages should bear the words ‘handle with care’, The packing

fequirements of Air/Rail/Road transport shall be complied with so as to obtain clear
Airway/Railway Receipt/Lorry Receipt i.e. without any qualifying remarks. All Packages
and unpacked materials shall be marked with the name of Consignor, Consignee,
purchase order No., gross and Net weight, sign of handling, if any, with indelible paint in
English at least at two places. In case of bundles, metallic plates marked with the above
details shall be tagged to such bundles.

8. Dispatch of Materials: The supplier is responsible for the safe delivery of the goods in
good condition at destination stores. The supplier should acquaint himself of the
conditions relating to handling and transport of the goods to destination and shall include
and provide for security and protective packing of the goods so as to avoid damage in
transit.

; of sm
Vv a yu 2 ५ Page 7036
> &
3...

<!-- page 8 -->

9 Validity of offers The offers shall be valid for a period of 90 days (Depending on the
type of equipment/item) from the date of opening of bids The periad of validity cannot be
counted from any other date other than the date of opening the trds Ouring this period

y the tenderer shall not be permitted to withdraw or vary his offer made and if the tenderer
does so, the EMD shall be forfeted

70 Jurisdiction All and any disputes or diarence arising out of or touching this onder shalt!
be decided only by the Courts or Tribunals situated in Gwalior

44 The Registrar Jhwaji University, Gwalior does not bind himsalt ta accent the lowest or
any fender and he reserves the right to reject any offer without assigning any mason

SECTION
FINANCIAL
7 Prices
Prices quoted shall be inclusive of all ares including GST
2. Terms of payment
a) oe by the purchaser shall be made online only, Bank charges if any shall be home by
the supplier
9) If the supplier has received any overpayments by mistake or if any amounts are dus to the
University from the supplier due to any other reasons and when it is nat possible to racaver
Such amount under the present purchase order, the University reserves the nght to collect the
rams ~~ any other amounts and/ or Bank Guarantee given by the supplier due to or with the
vers!
3. Liquidated Damages! Failure and Termination
3. In the event of any delay in the supply of material beyond the stipulated date of
completion including any extension permitted in writing, the University reserves the night
to recover from the supplier a sum equivalent to 0.5% of the value of delayed materiais/
equipment/tem for each week of delay and part thereof Subject to a maximum of 5% of
the total value of the order
5 Alternatively. the University reserves the right to give the contract elsewhere at the sole
risk ang cost of the supplier and recover all such extra Cost incurred by the University in
procuring the materials from the other source.
6. Alternatively, University may cancel the Purchase Order completely or partly without
Prejudice to its nght under the alternatives mentioned above
4 Delivery Schedule
Time is essence of this order and no delay shall be allowed in the delivery ume/ delivery
Schedule mentioned in the purchase order.
5 Performance Bank Guarantee:
The supplier shal! ensure that all matenials/equipmentitems under this Purchase order snail
Conform to University’s requirements and specifications. An additional Security in the form of
Performance Bank Guarantee is essential for Satisfactory performance of the équipmenvitem
over 8 period of time in view of this, the supplier shall be required to furnish a Performance
Bank Guarantee equal to 3% of the tender value in cash or Demand Draft, FOR, Banker's
Cheque and Irrevocable Bank Guarantee of any Scheduled Bank/Commercial Bank with validity
as per the provisions of M. P. Bhandar Kraya Niyam and Sewa Uparjan Niyam 2045 (as
amended in 2022)
In case any deficiencies are found Guning this period, the same shall be
repaired/rectified/replaced tree of cost The Unversity shail at its discretion have recourse to
_ 9. Ca
. £ Page 8 of 6

<!-- page 9 -->

4 the said Performance Bank Guarantee for recovery of any or all amount due from the supplier in
connection with the purchase order including of guarantee obligations.
6 = Insurance:
Supplier shall arrange suitable insurance cover at his risk and cost for the transit of the
equipmentiitem upto for installation and testing.
F 7 Removal of rejected goods and Replacement
93, If upon delivery, the materiaVequipmentitem is found not in conformity with the
specifications stipulated in the purchase order, whether inspected and approved earlier, or
otherwise, such material/ equipmentiitem will be rejected by the University or his
authorized representative. A notice to this effect shall be issued to the supplier, normally
within 30 days from the date of receipt of materials at our Stores.

0. Supplier shall arrange suitable replacement supplies and remove the rejected goods within *

30 days from the date of notice failing which, the goods shall be dispatched to, vendor by
road transport on ‘Freight to Pay basis at supplier's risk and cost.

6. External damages or shortages that are prima-facie as a result of fough handling in transit
or due to defective packing shall be intimated to the supplier within, a period of one month
of the receipt of the materials, spares etc. In case of Internal defects, damages of
shortages of any internal part, which cannot ordinarily be detected on a superficial visual
examination, due to bad handling in transit of defective packing or any other reason, it
should be intimated to the supplier within 3 months from the date of receipt of the material.
In either case the damaged or defective material should be replaced by the supplier free of
costs,

d. If no steps are taken within 45 days of receipt of intimation of defects or such other
reasonable time as the University may deem proper to afford, the University may without
Prejudice to its other rights and remedies rrange for repairs/rectification of the defective

materials or replace them €ntirely and recover the expenditure incurred on account of
the sections from the deposits such as EMD, SD and performance guarantees or other
monies available with the University or by resorting to legal action.
8 Force Majeure: -

3) The supplier shall not be liable for delay or failing to supply the material for reasons of
Force Majeure such as Act of God, Act of War, Act of Public Enemy, Natural Calamities,
fires, Floods, Frost, Strikes. Lockouts etc. Only those causes which have duration of more
than 7 days shall be considered for force Majeure.

b) The Supplier shall within 0 days from the beginning of such delay notify the University in
writing the cause of delay. The University shall verify the facts and grant such extension of
time as facts justify.

¢) No price variation shall be allowed during the period of force Majeure and liquidated
damages would not be levied for this period.

At the option; of university, the order may be cancelled. Such cancellation, would be

without any liability whatsoever on the part of the University, In the event of such

cancellation, supplier shail refund any amount advanced or paid to him by the University
and deliver back any materials issued to him by the University and release facilities, if any,
provided by the University.
- (४ shot Page 9 of 36
Se = ae
Ly Se mY sells

<!-- page 10 -->

i Annexure - 04
Schedule of Quantity
[ S.No. | Description of Equipment / item [Quantity
Address where the equipment / item is to be installed
(Supply, Installation and Commissioning of Equipment / Item at)
Institute of Paramedical Sciences
Jiwaji University हि
Gwalior -474044 (M.P.)
Lv wer Sik er
—— Page 20 of 6
