---
doc_id: "f9d26a9a4ea5ce4b"
source_url: "https://www.cpct.mp.gov.in/per/g01/pub/1172/ASM/WebPortal/1/Hindi/PDF/CPCT_Nov17_Exam_Advertisment.pdf"
ministry: "Computer Proficiency Certification Test (CPCT), Madhya Pradesh"
title: "Notification/Advertisement"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "62d996a73bb44b4a"
---

<!-- page 1 -->

File No.MAPIT-Proj0CP(Fin)/8/2017-CPCT
33
Receipt No : 15054/2017/Admin Division
