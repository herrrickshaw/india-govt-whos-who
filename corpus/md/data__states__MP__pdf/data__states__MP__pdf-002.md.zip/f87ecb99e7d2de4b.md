---
doc_id: "f87ecb99e7d2de4b"
source_url: "https://esd.mponline.gov.in/Ql_ESd/MPEDGENDOC/Documents/RulesAndRegulation_2025.PDF"
ministry: "Madhya Pradesh Electricity Inspectorate"
title: "Rules and Regulation for Applying under Supervisory exam."
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "dbaf62cb839dd78d"
---

<!-- page 1 -->

ता के. — — * om
t
Rules and Regulation for Applying Under Supervisory Exam
l- Applying under mining
A- If Candidate have: 0+2 with (PCM)+ITI (Electrician trade)+ 5 years
Experience, candidate will give paper Ist 4th & mining oral/practical.
B- if Candidate have: 0+2 with (PCM)+ tar mistry (wiremen) permit passed in 2
Subject (2 out of 4) +5 years’ experience. Candidate will give paper Ist 4th & mining
oral/practical.
C- If Candidate have: degree/diploma in engineering (other than Electrical)+ 2
years experience. Candidate will be eligible to give paper :,4t% & mining
oral/practical.
D- If candidate have: degree/diploma in (Electrical)+ 2 years experience.
Candidate will be eligible to give Paper 49 & mining oral/practicat only.
5 मनन नल किक २० मिए तक
2- Applying under non mining
A- If candidate have: 0+2 with (PCM)+ITI (Electrician trade)+5 years experience,
candidate will be eligible to give paper st, 2nd, 3r4and non mining oral/practical.
B- If candidate have: 0+2 with (PCM)+ tar mistry (wiremen) permit passed in 2
subject (2 out of 4)+5 years experience, candidate will give paper Ist, 2nd, 3rd & NON
mining oral/practical.
C- If candidate have: degree/diploma/polytechnic in engineering (other than
Electrical)+ 2 years experience, candidate will give paper Ist ,2nd, 3rd & NON mining
oral/practical.
D- If candidate have: degree/diploma in (Electrical)+ 2 years experience,
candidate will be eligible to give paper 3rd only.
3- Applying under both for mining/non mining, rules will be taken
Commonly as mention above.

<!-- page 2 -->

- विद्युत पर कर एवं शुल्क

4. Mandatory Terms and Conditions a भारतीय बिजली नियमावली
के अन्तर्गत फीस

I. It is mandatory that the departmental fee for mining and non mining is Rs.40/-
for each examination and in case of Both department fees will be Rs 80 and to be
paid by cyber treasury.
2. Work experience from outside the State of Madhya Pradesh is not acceptable
And not allowed.
3. The experience of the Contractor will only be valid when candidate has been
Registered as a trainee in the MP. Licensing Board (Electrical safety
Department).
4. Only High Tension Consumer work experience will be acceptable.
5. It is mandatory that the applicant is being lived in Madhya Pradesh State for
at least 3 years.
6. Experience Certificate should be issued on Institution's Letter-head including
The competency of the Institution, Name and the designation of the issuing
Officer with their email id & mobile number.
7. 2 years work experience is mandatory after the completion of Diploma
/Degree in Engineering.
8. 5 years work experience is mandatory after the completion of 2th PCM+ITI
(Electrician trade)
9. 5 years work experience is mandatory after the completion of 2¢h
PCM+ wireman permit any 2 subject. (Domestic, industrial, overhead,
Underground)
0. Work experience is not acceptable before last 5 year.
4. If the candidate is applying for mining subject then the experience is
Mandatory for mining work. (ex:-coal mines)
