---
doc_id: "caed4f2b23a83d1d"
source_url: "https://www.mptransco.in/Content/Miscellaneous/Press_Release/MPERC_Chairman.pdf"
ministry: "Madhya Pradesh Power Transmission Company Ltd. (MPPTCL), Madhya Pradesh"
title: "Notice regarding Cancellation of advertisement published in News papers on 14.08.2024 for appointment on the post of Chairperson, MPERC"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2da1ecf05de795df"
---

<!-- page 1 -->

GOVERNMENT OF MADHYA PRADESH
ENERGY DEPARTMENT

MANTRALAYA, VALLABH BHAWAN

No,.&S0

Bhopal, dated 13 APR 2026

/2195683/2024/13/14

Notice of Cancellation
This is to inform that the Public Notice issued on 13.08.2024 and

advertisement published in News papers on 14.08.2024 and in extended dates

thereafter, for appointment on the post of Chairperson, Madhya Pradesh
Electricity Regulatory Commission (MPERC) stands cancelled.

(v.K. Gaur)

Officer on Special Duty
