---
doc_id: "e3a25ea0fed9ceba"
source_url: "https://mpkrishi.mp.gov.in/hindisite_new/pdfs/SeedProcessingUnitGuideline_English.pdf"
ministry: "Farmer Welfare and Agriculture Development Department, Madhya Pradesh"
title: "For the selection of beneficiaries for the establishment of “Seed Processing and Seed Storage Units at Gram Panchayat Level” under the Seed Component of the National Food Security and Nutrition Mission (NFSNM)"
date: ""
pages: 20
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "a8a3483afe813682"
---

<!-- page 1 -->

Directorate of
Farmer Welfare and Agriculture Development
Vindhyachal Bhawan, Bhopal Madhya Pradesh
Notice for Selection of Beneficiaries

Under the National Food Security and Nutrition Mission (NFSNM) — Seed
Component, applications are hereby invited for the selection of eligible beneficiaries for
the establishment of "Seed Processing and Seed Storage Unit at the Gram Panchayat
Level”.

The application of beneficiaries shall be carried out through the office of the
Deputy Director, Farmers’ Welfare and Agriculture Development Department of the
concerned district.

Detailed information regarding eligibility criteria, rules & conditions, and the
application procedure is available on the official website of the department:
mpkrishi.mp.gov.in.

Only applications received 05 October 2026 from the date of publication of this
Notice shall be considered valid, Digitally signed by

Umashankar Bhargav
Date: 7-09-2026
326:08:36
Director
Farmer Welfare and Agriculture
Madhya Pradesh

<!-- page 2 -->

| |
F. No. 2-33/2024-NFSNM
भारत सरकार/ Government of india
कृषि एवं किसान कल्याण मंत्रालय/ Ministry of Agriculture and Farmers Welfare
कृषि एवं किसान कल्याण विभाग / Department of Agriculture and Farmers Welfare
फसलें एवं पीएचएमएफ प्रभाग/ Crops & PHMF Division
Krishi Bhawan, New Delhi |
Dated: 6.04.2025

To,

The APC/Principal Secretary/Secretary (Agriculture),

All States/Union Territories

Subject: Revised guidelines of National Food Security & Nutrition Mission
(NFSNM) from FY 2025-26-reg.

Respected Sir/Madam,

The undersigned is directed to inform that Cabinet has approved continuation of
Centrally Sponsored Schemes namely Pradhan Mantri Rashtriya Krishi Vikas Yojana
(RKVY) and Krishonnatti Yojana (KY) from 07.04.2027 to 34.03.2026. The National Food
Security Mission (NFSM) has been renamed as National Food Security & Nutrition
Mission (NFSNM) and has been brought under Krishonnatti Yojana (KY). Also,
the erstwhile Sub-Mission on Seed & Planting Material (SMSP) is subsumed under
NFSNM as NFSNM: Seed Components.

2. Accordingly, the guidelines have been revised and the revised guidelines of
NFSNM is enclosed herewith for kind information and necessary action. The guidelines
will be effective from 0.04.2025.
3. It is requested to circulate the revised guidelines to all concerned stakeholders.
The copy of the revised guidelines of NFSNM will also be made available on the website
of this Department. हु
Enclosure: Revised NFSNM guidelines १ की
रा (Rabindra Prasad)
Director (Crops)
0i-23386684
Copy to:
4. PS to Hon’ble Minister for Agriculture & Farmers Welfare, Krishi Bhawan, New

Delhi.

2. PS to Hon'ble MoS (Shri Ramnath Thakur), Krishi Bhawan, New Delhi.

3. PS to Hon'ble MoS (Shri Bhagirath Choudhary), Krishi Bhawan, New Delhi.
4. PPS to Secretary (A&FW), Krishi Bhawan, New Delhi.

5. PPS to Secretary (DARE) & DG (ICAR), Krishi Bhawan, New Delhi.

<!-- page 3 -->

Fee |
se

6. PPS to all Additional Secretaries, DA&FW, Krishi Bhawan, New Delhi.

7. PPS to Agriculture Commissioner, DA&FW, Krishi Bhawan, New Delhi.

8. DDG (Crop Science), ICAR, DARE, Krishi Bhawan, New Delhi.

9. 006 (Agri. Extension), ICAR, DARE, Pusa Campus, New Delhi.
i0. PPS to all Joint Secretaries/Advisors, DA&FW, Krishi Bhawan, New Delhi. |
i4. ADG (O&P)/ADG (Seed), ICAR, Krishi Bhawan, New Dethi.

42. Commissioner/Director (Agriculture), Department of Agriculture of all States/UTs.

3. Director (RKVY), DA&FW, Krishi Bhawan, New Delhi.

4. Director of all Crop Development Directorates, DA&FW.

5. DC (Seeds)/DC(QC)/DS(Seeds), DA&FW, Shastri Bhawan, New Delhi.

6. Under Secretary (Seeds), DA&FW, Krishi Bhawan, New Delhi.

47. Under Secretary (KY), DA&FW, Krishi Bhawan, New Delhi.

8. Under Secretary (CA-V) DA&FW, Krishi Bhawan, New Dethi.

9. AC (Crops and Seeds)/CU-! Section/CU-I Section/CU-IV Section/NFSNM Section,
DA&FW, Krishi Bhawan, New Delhi.

<!-- page 4 -->

| z GOL

; fra titer
Intervention under NFSNM: Seed
Components (erstwhile Sub-Mission for
© Seed and Planting Material)  _—j

पे 5i| Page

<!-- page 5 -->

6. SEED PROCESSING AND SEED STORAGE UNIT AT GRAM PANCHAYAT 7
LEVEL ,

Objective

To ensure the local availability of quality seeds of high-yielding varieties for farmers, it is
essential to organize seed production programs and carry out activities such as seed processing,
cleaning, grading, packaging, and storage within the vicinity. In this regard, the Government of India
(Gol) provides 00% assistance for 50% of the establishment cost of a Seed Processing Plant (500
MT capacity with a minimum of TPH capacity) and a Seed Storage Godown (500 MT capacity) at
the Gram Panchayat level, with a maximum assistance limit of Rs. 40 Lakhs (whichever is less).
Pattern of Assistance

i. The 50% grants-in-aid will be provided by Gol to the eligible agencies through State
Department of Agriculture for setting such units at Gram Panchayat level.

ii, | The State Department of Agriculture has to transfer this amount to concerned eligible agency
at the earliest.

ili. The Seed Processing Plant of 500 MT capacity & minimum of 7 TPH capacity shall be
installed and Seed Storage Godown of 500 MT shall be constructed. The specifications may
be seen at Table-H.

iv. Maximum assistance per unit is 50% for the complete setup cost limited to Rs. 40 Lakh. The
rest amount will be borne by the agency.

Norms for construction of Seed Processing cum Seed Storage Godown
The construction of Seed Processing-cum-Godown must adhere to the highest standards in
line with the norms set by the State Government. It should include an approach road for easy access,
proper drainage systems, and facilities for seamless loading and unloading of seed stocks
Additionally, any changes in the proposed location for setting up the Seed Processing and Seed |
Storage Godown require prior approval from the Government of India (Gol).
Eligibility Criterion & Implementation Strategy

i. The Seed Processing Plant and Seed Storage Godown can be established on government
land, government seed farms, Panchayat-owned land, or land owned by the implementing
agency.

ii.  Grants-in-aid will be provided to implementing agencies that already possess the necessary
land and manpower to establish and operate the seed processing and storage facilities. Costs
related to land and its registration will not be covered under any circumstances.

iii. | The concerned State Agriculture Department will closely monitor the procurement of seed
processing machinery and equipment, as well as the construction of Seed Storage Godowns

67 | Pag

<!-- page 6 -->

5
. iv. All installed machinery and construction work must adhere to the highest standards.

After the unit is established, day-to-day operations will be carried out by the implementing
agencies under the overall supervision of the State Agriculture Department.

vi. Upon the completion of the installation of the Seed Processing Plant and construction of Seed
Storage Godowns, the State Agriculture Department will assess the quality of work and
submit the Physical and Financial Progress Report, Utilization Certificate, Photographs, and
Geo-coordinates to the Government of India (Gol).

vi. The State Government may introduce additional guidelines at its discretion.

viii, Indicative details of essential and supporting equipment, items, and machinery can be
referred to in Table-H.

Implementing Agencies

i. Farmers Producing Organizations (FPOs) and Multi-State Cooperatives that are actively

engaged in seed production and have a minimum of 2 years of experience in the field of seed
production are eligible for assistance.

Note: The infrastructure created under this component will be mapped on SATHI portal. The seed

production done by the agency shall be carried-out through SATHI Portal only. Those

States/UTs/Agencies that are not using SATHI Portal will not be eligible for assistance.

Specifications & Cost Norms

= Sr SSS

| Table-H: Assistance for SPP-cum-SSG at Gram Panchayat Level (capacity of 500 MT)

| Details Minimum Minimum Dimension | TotalArea | Assistance |

Annual | Capacity (in meters) (in sqm) (in Lakh) |
Capacity (in TPH) | |
| (in MT) |

| Seed 500 7 TPH 45Xi0M 450 sqm 50% cost for |

Processing establishment of SPP |
Plant | |& SSG limited upto Rs.
Seed Storage 500 “5 x 20M 40 lakhs per unit |

| Godown (whichever is less)
|. The list of essential equipment/ items/ machinery for SPP includes Elevators, Pre-cleaner, Seed,
Grader, Indented Cylinder, Gravity Separator, Seed Treatment and Packing Machine, Digital)
Weighing Machine, Sewing/ Stitching and Sealing Machine. |

| IL The supporting equipment/ items/ machinery for SPP may include Weight Bridges, Moisture

| Meter Digital Type, Electronic/ Electrical Control Panel, Air-Compressor, Generator Set, and

| other related L__ Meesedmeciney calmer ecreansanddefee . | equipment, screens and devices. j

|

68 | Page

<!-- page 7 -->

= 49042/04/2023-SD.I Zag — 3
= भारत सरकार
. Government of India
कृषि एवं किसान कल्याण मंत्रालय
Ministry of Agriculture and Farmers Welfare
कृषि एवं किसान कल्याण विभाग
Department of Agriculture and Farmers Welfare
बीज प्रभाग/ Seeds Division.
wee
कृषि भवन, नई दिल्‍ली
दिनाक. मई 2025
To, दी
The APC/ Principal Secretary/ Secretary (Agriculture),
All States/ Union Territories
Subject: Implementation of Revised Guidelines under the National Food Security and
Nutrition Mission (NFSNM) - Approval of Seed Component and Related Instructions
Sir/Madam,
lam directed to refer to the revised guidelines issued under the National Food Security
and Nutrition Mission (NFSNM) vide letter No. 2-33/2024-NFSNM dated 6.04.2025. These
guidelines incorporate changes in the cost-sharing pattern between the Centre and the States/UTs,
introduction of new interventions, and updated cost norms.
2. As you are aware, the Annual Action Plans (AAPs) for most States/UTs have already been
finalized and communicated. In light of the revised guidelines, certain modifications in the approved
AAPs may be necessitated. The matter has been examined in the Department, and in-continuation
of the earlier communications regarding AAP approval by the Department of Agriculture & Farmers
Welfare (DA&FW), | am directed to convey the adoption of folloing procedure for operating the Seed
Component (formerly Known as SMSP) of NFSNM for your State/UT:

i, The approved funds shail be utilized strictly as per the revised guidelines and cost norms,
and within the sanctioned allocation. If needed, physical targets of Seed Component maybe
suitably revised to adjust the intervention within given allocation.

ii. Any deviation or modification in the approved AAP, if required, must be duly communicated
to both the Krishonnati Yojna (KY)-Cell and the Seed Division of the Ministry.

ili. | Approval of the State Level Sanctioning Committee (SLSC) is obtained in due course for any
such changes in the AAP.
3. States/UTs are requested to take necessary action accordingly and ensure full compliance
with the revised guidelines. .
Yours faithfully,
yw 2
J (M. of Banerjee)
Deputy Secretary to the Govt. of India.
Email * raj.rao@nic.in
Copy to:
4. PPS to Joint Secretary (Seeds), DA&FW, Krishi Bhawan, New Delhi
2. DC (Seeds)/ DC (QC) - with request ६0 bring this to the notice of all concerned.
3. Under Secretary (KY Cell} - for information.

<!-- page 8 -->

मध्यप्रदेश शासन
किसान कल्याण तथा कृषि विकास विभाग
भोपाल
क्र./ई-4-बी/बीज/४78।|५७/बीज गोदाम /2025/ १० 26 भोपाल दिनांक- |-॥/ 2025
प्रति,
4. संयुक्त संचालक,
किसान कल्याण तथा कृषि विकास
संभाग समस्त ............(म.प्र.)
2. उप संचालक,

किसान कल्याण तथा कृषि विकास

जिला समस्त ............(म.प्र.)
विषय- राष्ट्रीय खाद्य सुरक्षा एवं पोषण मिशन - बीज घटक (Interventions under NFSNM: Seed
Components) अन्तर्गत “ग्राम पंचायत स्तर पर बीज प्रसंस्करण एवं बीज भण्डारण इकाई ” स्थापना
क्रियान्वयन हेतु मार्गदर्शी निर्देश |

कृषि एंव किसान कल्याण मंत्रालय, कृषि एंव किसान कल्याण विभाग भारत सरकार के पत्र क्र.
49042/0॥/2023-80.। दिनांक 22 मई 2025 से कृषि उन्नति योजना (4438) के घटक NPSNM - Seed
Component के क्रियान्वयन हेतु दिशा-निर्देश 2025 जारी किये गये है। उक्तानुसार NESNM - Seed Component
के क्रियात्वयन हेतु जारी दिशा-निर्देश के उपधघटक - (6) के तहत ग्राम पंचायत स्तर गर बीज प्रसंस्करण एबं बीज
क्षण्डारण इकाई स्थापना लागत का 50 प्रतिशत अथवा प्रति इकाई रू, 40.00 लाख अधिकतम के मान से विन्तीय
प्रावधान किया गय्या है।

उक्त के अनुक्रम में सचिव, म.प्र. शासन से अनुमोदित वार्षिक आयोजना अनुरूप कृषि एंव किसान
कल्याण मंत्रालय, कृषि एंव किसान कल्याण विभाग भारत सरकार नई दिल्‍ली का पत्र क्र. 388 (MP 496) , दि.
29-08-2025 गे ग्राम पंचायत स्वर पर थीज प्रसंस्करण एवं वीज भण्डारण इकाई स्थापना हेतु 42 इकाई हेतु wa
इकाई रू. 40.00 लाख के मान से Feat राशि रू, 480.00 लाख की मदर सेंकशन प्राप्त है । तदानुक्रम में ग्राम
पंचाय्रत रतर पर बीज प्रसंस्करण wt बीज भण्डारण इकाई योजता क्रियान्वयन, मॉनीटरिंग एवं मूल्याकन 24
निम्नानुसार कार्यकारी निर्देश जारी किये जा रहे हैं-
L. उद्देश्य

ग्राम पंचायत स्तर पर बीज प्रसंस्करण एवं बीज भण्डारण इकाई स्थापना का मुख्य उद्धेश्य किसानों के
लिए sy उपज देने वाली किल्‍्मों के भुणवत्तापूर्ण बीजों की स्थानीय उपलब्धता सुनिश्चित करने हेतु बीज उत्पादन
कार्यक्रमों का आयोजन और आसपास के क्षेत्र में वीज प्रसंस्करण, सफाई, ग्रेडिंग, पैकेजिंग और भंडारण att
अनिवार्य सुविधाओं /गतिविधियों का संचालन सुनिश्चित करना ।
EXE-L-BWNFSNM 24777 SCOmt STL_ona fear FA S00 mt. गेडाम१५७० Has सोदाम दिशा निर्देश,0०७६ डर

<!-- page 9 -->

2. पात्र एजेंसी -

24 ऐसे किसान उत्पादक संगठन (FPO) wa बहु-राज्य सहकारी समितियाँ जो बीज उत्पादन में सक्रिय रूप
से संलग्न हैं और जिनके पारा बीज उत्पावन के क्षेत्र में न्यूनतम 2 वर्ष का अनुभव है, योजनान्दर्गत facts
सहायता के लिए wean दी जायेगी।

2.2. पात्रता ay एजांसेंयों द्वारा किया जाने वाला बीज उत्पादन कार्यक्रम SATHI पोर्टल के माध्यम से ही
किया जाना अनिवार्य है इस हेतु मध्यप्रदेश राज्य बीज प्रमाणीकरण संस्था का पंजीयन होना झावश्यक
होगा।

2.3 वे एजेंसियाँ जो SATHI drée का उपयोग नहीं कर रही हैं, सहायता के लिए पात्र नहीं होंगी ।

2.4... योजताल्तर्गत निर्मित अबसंरचना का मानचित्रण SATHI पोर्टल पर किया जाएगा ।

3. वित्तीय सहायता का स्वरूप -

3.000 Tas स्तर पर न्यूनतम Stes क्षमता के एक बीज प्रसंस्करण संयंत्र के साथ 500 मीट्रिक टन
क्षमता के एक बीज भंडारण गोदाम की स्थापना के लिये लागत के 50% अथवा अधिकतम राशि रू.
40.00 लाख रुपये, जो भी कम हो, की केन्द्रीय सहायता का प्रावधान है।

3.2. शासन द्वारा ग्राम पंचायत स्तर पर बीज प्रसंस्करण एवं बीज भण्डारण इकाई स्थापना लागत के 50
प्रतिशत अथवा अधिकतम राशि रू. 40 लाख रुपये प्रति इकाई के मान से भुगतान किया जायेगा है, शेष
लागत राशि का चयनित हितग्राही सह क्रियान्वयन संस्थाओं द्वारा स्बंय बहन किया जावेगा ।

4. बीज प्रसंस्करण - सह - बीज भंडारण गोदाम के निर्माण के मानदंड-

4.40 बीज प्रसंस्करण एवं बीज भंडारण गोदाम का निर्माण राज्य सरकार द्वारा निर्धारित तकनीकी मानदंडों के
अनुरूप उच्चतम मानकों के अनुसार किया जाता है।

4.2. निर्मित बीज प्रसंस्करण एवं बीज भंडारण गोदाम तक सुगम पहुँच के लिए एक पहुँच मार्ग, उचित जल
निकासी व्यवस्था और बीज भंडार की निर्बाध लोडिंग-अनलोडिंग की सुविधाएँ शामिल होनी चाहिए।

4.3... बीज प्रसंस्करण एवं बीज भंडारण गोदाम की स्थापना के लिए प्रस्तावित स्थान में क्रिसी भी परिवर्तन के
लिए भारत सरकार से पूर्व अनुमोदन आवश्यक |

5. पात्रता मापदंड एवं कार्यान्वयन रणनीति -

5.4. उन कार्यात्वयन एजेंसियों को अनुदान सहायता प्रदात की जाएगी जिनके पास बीज प्रसंस्करण ud
भंडारण सुविधाओं की स्थापना एवं संचालन हेतु आवश्यक भूमि एवं मानव संसाधन पहले से ही उपलब्ध

5.2. बीज प्रस॑स्करण संयंत्र एवं बीज भंडारण गोदाम शासकीय भूमि, शासकीय बीज फार्म, पंचायत के
स्वामित्व वाली भूमि या कार्यान्वयन एजेंसी के स्वामित्व वाली भूमि पर स्थापित किए जा सकते हैं ।

5.3 भूमि एवं उसके पंजीकरण से संबंधित लागत किसी भी परिस्थिति में शासन द्वारा बहन नहीं की जाएगी।

EE-LBYNESNM अंतर्गत ५00४0 _ DNA दिखा निर्दे॥५५०७ mt. गंडाम ५७00 Hea गोटम दिला Shs: doe 2

<!-- page 10 -->

5.4 बीज प्रसंस्करण मशीनरी एवं उपकरणों की खरीद के साथ ही बीज भंडारण गोदामों के निर्माण किसान
कल्याण तथा कृषि विकास विभाग के सक्षम अधिकारियों की सघन निगरानी में किया जायेगा।

5.5 सभी स्थापित मशीनरी एवं निर्माण कार्य में उच्चतम मानकों का पालन किया जायेगा।

5.6 इकाई स्थापित होने के बाद, कार्यान्वयन एजेंसियों द्वारा किसान कल्याण तथा कृषि विकास विभाग के
सक्षम अधिकारियों के समग्र पर्यवेक्षण में दैतिक कार्य किए जाएँगे ।

5.7 बीज प्रसंस्करण संयंत्र की स्थापता और बीज भंडारण गोदाम का तिर्माण पूर्ण होते पर किसान कल्याण
तथा कृषि विकास विभाग द्वारा भदिशित सक्षम अधिकारियों के दल द्वारा कार्य क्री गुणवत्ता का आकलन
किया जायेगा और संचालनालय को भौतिक और वित्तीय प्रगति रिपोर्ट, उपयोग प्रमाण पत्र, फोटोग्राफ
और भू निर्देशांक (७७० Tag) सहित प्रस्तुत करेगा ।

5.8 आवश्यक एवं सहायक उपकरणों, बस्तुओं और मशीनरी का सांकेतिक विवरण तालिका-/ में दिया गया
है।

6. विनिर्देश एवं लागत मानदंड -

6.4. बीज प्रसंस्करण संयत्र के लिए आवश्यक उपकरणों/वस्तुओं/मशीनों की सूची में लिफ्ट, प्री-क्लीनर, बीज
ग्रेडर, gece सिलेंडर, ग्रेविटी सेपरेटर, बीज उपचार और पैकिंग मशीन, डिजिटल sea मशीन,
सिलाई/सिलाई और सीलिंग मशीन शामिल हैं।

6.2 बीज प्रसंस्करण संयत्र के लिए सहायक उपकरणों/वस्तुओं/मशीनों में वेट ब्रिज, डिजिटल प्रकार का नमी
मीटर,इलेक्ट्रॉनिक / विद्युत नियंत्रण पैनल, एयर कंप्रेसर, जनरेटर सेट और अन्य संबंधित मशीनरी,
उपकरण, स्क्रीन और उपकरण शामिल हो सकते हैं।

= FESS Panchayat Level (capacity of 500 MT)
Details | Minimum | Minimum ; Dimension} Total Assistance
a Capacity | (in meters)| Area Gin |
Capacity (in TPH) | (in Lakh) |
_ (in MT) sqm)
Seed 500 TTPH | ISXi0M[ 450sqm| 50% cost for
Processing Plant | ॥ | establishment of
i. i SPP & SSG limited |
Seed Storage 500 TT , 5४20४ , upto Rs.
Godown | i | 40 lakhs एल unit |
oe _ | (whichever is less). |
7. हितग्राही संस्थाओं के चयन में प्राथमिकता हेतु मानदण्ड —

74 प्रदेश के से जिले जहाँ पूर्व में योजनान्तर्गत ग्राम पंचायत स्तर पर 500 मै. aa गोदाम सह बीज
wien इकाई स्थापित नहीं हुई है उन जिलों में नवीन हितग्राही चयन हेतु प्राथमिकता दी जायेगी ।

7.2... निर्धारित गानदण्ड एबं भारत रारकार से रवीकृत लथ््य अनुरूप आवेदन द्ेतु समाचार पत्र में विज्ञापग
जारी की जायेगी ।

EAE-L-B\NFSNM अंवर्शद Soom STL ana दिशा निर्देश।500 mt. torn soo Aer itera दिशा Se doen 3
