---
doc_id: "fab984620ebbda5d"
source_url: "https://www.bgtrrdmp.mp.gov.in/PDF/vehicleTender2018.pdf"
ministry: "Bhopal Gas Tragedy Relief and Rehabilitation Department, Madhya Pradesh"
title: "Private Vehical Tender 2018-2019"
date: ""
pages: 21
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2459c13ed6c6612b"
---

<!-- page 1 -->

fufonk izi= dzekad-

lapkyuky;]Hkksiky]xSl =klnh jkgr ,oa iquokZl
1]f'kokth uxj Hkksiky
dk;kZy; gsrq ekfld ¼iw.kZdkfyd½@nSfud nj ij izk;osV okgu
¼VsDlh dksVs½ ls miyC/k djkus gsrq fufonk izi=

fufonk izi= ,oa 'krsZ o"kZ 2018&19
fufonk izi= tek djus dh vafre frfFk-28 ebZ]2018
le;%nksigj&2%30 cts rd
fufonk izi= [kksyuss dh vafre frfFk-28 ebZ]2018
le;%nksigj&3%30 cts
fufonk izi= [kksyuss dk LFkku&lapkyuky;]Hkksiky xSl
=klnh jkgr ,oa iquokZl]01 f'kokth uxj]Hkksiky

fufonk izi= 'kqYd #-250-00

<!-- page 2 -->

fooj.k rkfydk
fufonk dh 'krsZ ,oa izfdz;k
Hkkx&1&dk;kZRed ,oa rduhdh fooj.k
l-dz- fo"k;
01 dk;kZRed vko';drk,a
02 rduhdh vko';drk,a
Hkkx 2&lkekU; funsZ'k ,oa foRrh; fofunsZ'k
l-dz- fo"k;
03 fufonk izfdz;k

04

05

06
07

3-1 fufonk izi= dk ewY;
3-2 fufonk nLrkost
3-3 fufonk izLrqr djus gsrq LFkku ,oa le;
3-4 fufonk izfdz;k dk fujlu
3-5 foyac ls izkIr fufonk,a
3-6 fufonkvksa dk [kksyk tkuk
3-7 fufonkvks dk ewY;kadu
3-8 fufonk layXu djus gsrq nLrkostks dk fooj.k
fufonkdkjksa dh vgZrk,a
4-1 vgZrk,a
4-2 rduhdh izLrko
4-3 foRrh; izLrko
4-4 gLrk{kj ,oa ineqnzk
4-5 fufonk dk izLrqrhdj.k
4-6 fufonk izLrko ds oS/krk dh vof/k
4-7 fufonk es la'kks/ku
4-8 izLrko dh Hkk"kk
4-9 njsa
4-10 vik=rk,a
4-11 la'kks/ku ,oa fufonk okil ysuk
4-12 'krksZ dh xzkg~rk dh larqf"V
vuqca/k dk fu"iknu
5-1 fufonk dh izfrHkwfr (Earnestmoney deposit)
5-1 fu"iknu izfrHkwfr (Performance Guarantee)
5-3 vuqca/k es gLrk{kj
5-4 lsok,a ,oa okjaVh
5-5 isukYVh
5-6 vuqca/k dh 'krksZ dk mYya?ku
Hkqxrku
fookn dk fujkdj.k

i`"B dz01
01
i`"B dz02
02
02
02&3
03
03
03
03
03
04
04
04
04
04
04
04
05
05
05
05
05
05
05
05
06
06
06
07
07
08
08

<!-- page 3 -->

izi=ksa dk fooj.k
l-dz- fo"k;
1
2
3
4
5
6
7

lwpuk i=
?kks"k.kk i=
lqj{kk fuf/k@fufonk dh izfrHkwfr (Earnestmoney deposit)
fufonk dh 'krsZ rFkk fu;e ls lgefr
fufonkdkj Onkjk rduhdh fcM esa izLrqr dh tkus okyh tkudkjh
vuqca/k dk izk#i
foRrh; izLrko izkbl fcM

izi=
izi=& v&1
izi=& v&2
izi=& v&3
izi=& v&4
izi=& v&5
izi=& v&6
izi=& c

<!-- page 4 -->

¼1½

lapkyuky;]Hkksiky xSl =klnh jkgr ,oa iquokZl]-01]f'kokth uxj Hkksiky
dzekad@okgu@izk-@xSjkiq@2018]
Hkksiky] fnukad
fufonk dh 'krsZ
Hkkx&1]dk;kZRed ,oa rduhdh fooj.k
01- dk;kZRed vko';drk,a%&
lapkyuky;]Hkksiky]xSl =klnh jkgr ,oa iquokZl]Hkksiky ds vk/khu vko';drk vuqlkj
fdjk, ds 03 okgu ekfld ¼iw.kZdkfyd½ ,oa nSfud vk/kkj ij miyC/k djkus gsrq o"kZ 2018&19
,d o"kZ ds fy;s fufonk,Wa lhy can fyQkQs esa vkef=r dh tkrh gSA vko';drk vuqlkj okguksa
dh la[;k esa deh ;k c<+ks=h dh tk ldrh gSaA okgu dh nj 1000 fd-eh -¼isVªksy@Mhty½
pkyd lfgr ekfld jfuax ds vk/kkj ij gksxhA blds vykok i`Fkd ls vko';drk ds vk/kkj
ij eq[;ky; es nSfud vk/kkj ij ,oa eq[;ky; ls ckgj nkSjs ij tkus gsrq Hkh nj layXu izi= esa
nh tkosA

02 rduhdh vko';drk,a%&
2-1 okgu 01o"kZ ls vf/kd iqjkus Lohdkj ugh fd;s tkosxsA fufonkdkj Onkjk iznk; fd;s
tkus okys okgu u;s rFkk vPNh fLFkfr es gksuk pkfg;sA
2-2 okgu pkyd dh M;wVh le;&lhek dk;kZy;hu vko';drkuqlkj gksxhA
2-3 okgu pkyd dk ekfld osru VªsoYl ,tsUlh Onkjk Hkqxrku fd;k tkosxkA
2-4 okgu dh ejEer dk leLr O;; VªsoYl ,tsUlh Onkjk ogu fd;k tkosxkA
2-5 le;&le; ij okguksa ij gksus okyh lfoZflx dh ftEesnkjh VªsoYl ,tsUlh dh gksxhA
lfoZflax vof/k ds 2&3 fnu iwoZ lfoZflax djkus gsrq lacaf/kr vf/kdkjh dks voxr djkuk
vko';d gksxk o lfoZflax vof/k esa ,tsUlh Onkjk vU; okgu miyC/k djkuk gksxkA
2-6 okgu dh bZ/ku O;oLFkk lacaf/kr ,tsUlh dh gksxhA
2-7 czsd Mkmu@okgu ejEer@okgu pkyd dh vuqifLFkfr eas mldh oSdfYid O;oLFkk dh
ftEesnkjh VªsoYl ,tsUlh dh gksxhA oSdfYid O;oLFkk u fd;s tkus dh fLFkfr esa foHkkx
Onkjk ekfld ns;d jkf'k ls vko';d dVkS=k fd;k tkosxkA
fujUrj&2

<!-- page 5 -->

¼2½
2-8 okgu ds jksM VsDl]Vksy VsDl]bUL;ksjasl ,oa vU; vko';d [kpksZ ds fy;s ;g dk;kZy;
ftEesnkj ugha gksxkA
2-9

vko';drkuqlkj okgu pkyd dks okgu le; vof/k ls vf/kd ,oa ftys ds
ckgj Hkh pykuk iM+ ldrk gSA

2-10 okgu ds lkFk ykWx cqd la/kkfjr djuk vfuok;Z gSA
2-11 VªsoYl ,tsUlh@okgu dk vkj0Vh0vks0 dk;kZy; es VsDlh dksVas esa iathd`r gksuk vfuok;Z
gSA
Hkkx 2&lkekU; funsZ'k ,oa foRrh; fofunsZ'k
3- fufonk izfdz;k%&
3-1 fufonk izi= dk ewY;&fufonk QkeZ 'krsZ ,oa izi= dh izfr v/kksgLrk{kj drkZ ds dk;kZy;
dh foRr 'kk[kk dsa fnukad 28-05-2018 ls nksigj 2%30 cts rd # 250@&¼#-nks lkS
ipkl ek=½ uxn tek dj izkIr fd;k tk ldrk gSA fufonk QkeZ dz; 'kqYd okil
ugha fd;k tkosxkA fufonk QkeZ vgLrkarj.kh; gSA
3-2 fufonk nLrkost&fufonkdkj dks fufonk nks fyQkQksa ^^,** ,oa ^^ch** esa cUn dj izLrqr
djuk gksxkA
v- fyQkQk ^^,** esa fuEukuqlkj vfHkys[k@izi= jgsxs%&
izi=&v&1 lwpuk i= ¼fyQkQk&,&eas j[kk tk,½
izi=&v&2 ?kks"k.kk i= ¼fyQkQk&,&esa j[kk tk,½
izi=&v&3 lqj{kk fuf/k ¼fyQkQk&,&esa j[kk tk,½
izi=&v&4 fufonk dh 'krsZ ,oa fu;e ls lgefr i= ¼fyQkQk&, esa j[kk tk,½
izi=&v&5 fufonkdkj Onkjk rduhdh fcM gsrq izLrqr dh tkus okyh tkudkjh
lwpuk i=
6- izi=&v&6 vuqca/k dk izk#i
7- okguks dk fooj.k
12345-

c- fyQkQk&ch&esa fuEukuqlkj vfHkys[k@izi= jgasxasA
1- izi= ^^c** foRrh; fufonk izkbt fcM ¼fyQkQk&ch esa j[kk tk;s½
3-3 fufonk izi= izLrqr djus gsrq LFkku ,oa le;& fufonk izi= fufonk izdk'ku frfFk ls
fnukad- 28-05-2018 ds nksigj 1%30 cts rd dk;Zy;hu dk;Z fnolksa esa fu/kkZfjr 'kqYd
tek dj lapkyuky;]Hkksiky xSl =klnh jkgr ,oa iquokZl]01 f'kokth uxj Hkksiky ls
izkIr fd;s tk ldrs gSa ,oa mlh fnukad dks nksigj 2%30 cts rd Vs.Mj ckDl es tek
fd;s tk ldrs gSaA
fujUrj&3

<!-- page 6 -->

¼3½
izkIr fufonk, mlh fnu lk;% 3%30 cts mifLFkr fufonkdkjks ds le{k lapkyuky;]Hkksiky
xSl =klnh jkgr ,oa iquokZl] 01]f'kokth uxj Hkksiky esa [kksyh tk;sxhA leLr fufonk,a
dk;kZy; esa j[ks lhycan ckWDl esa gh Mkyh tk;sxh vU; fdlh LFkku vFkok O;fDr dks nh
xbZ fufonk,a Lohdkj ugh dh tkosxhA
3-4 fufonk izfdz;k dk fujlu& lapkyd]Hkksiky xSl =klnh jkgr ,oa iquokZl]Hkksiky dks fcuk
dksbZ dkj.k crk;s fufonk izfdz;k dks fujLr djus dk vf/kdkj gksxkA fujlu dh fLFkfr esa
fufonk izi=ks dh jkf'k okil ugh dh tkosxhA
3-5 foyac ls izkIr fufonk,&fufonk dh vafre fnukad]28-05-2018 ds nksigj 2%30 cts ds i'pkr~
izkIr fufonk,a Lohdkj ugha dh tkosxhA Mkd ls foyac ls izkIr fufonkvksa dh ftEesnkjh
lapkyuky;]Hkksiky xSl =klnh jkgr ,oa iquokZl]Hkksiky dh ugh gksxhA
3-6 fufonkvksa dk [kksyk tkuk&mijksDrkuqlkj fu;r fnukad ok le; rd izkIr fufonk;sa fnukad]
28-05-2018 dks vijkUg%3%30 cts lapkyuky;] Hkksiky xSl =klnh jkgr ,oa
iquokZl]]01]f'kokth uxj] Hkksiky eas xfBr lfefr ds le{k [kksyh tk;sxhA ;fn mDr
fu/kkZfjr frfFk dks vodk'k ?kksf"kr fd;k tkrk gS rks vxys dk;Z fnol dks fufonk [kksyh
tk;sxhA fcuk lhy can fyQkQs esa izkIr ,oa dVh QVh fufonk,a fcuk fopkj ds gh fujLr
dj nh tk;sxhA fof/kor izkIr fufonkvks dk igys fyQkQk ^^,** [kqyus ds le;
fufonkdkj Lo;a ;k mldk vf/kd`r izfrfuf/k Lo;a ds O;; ij mifLFkr jg ldrs gSA
3-7 fufonkvksa dk ewY;kadu&fufonkdkjksa ls izkIr fyQkQk ^^,** eas layXu nLrkostks dk
lapkyuky; ]Hkksiky xSl =klnh jkgr ,oa iquokZl]Hkksiky es xfBr lfefr Onkjk ewY;kadu
fd;k tk;sxk ,oa vgZrk,a iwjh u djus okys fufonkdkjks ds izLrko fujLr djus dk
vf/kdkj mDr lfefr dks gksxk rFkk mDr es ;ksX; ik;s x;s fufonkdkjks dk fyQkQk
^^ch** [kksyk tk;sxkA
3-8 fufonk layXu djus gsrq nLrkostks dk fooj.k&fufonk izi= tek djrs le;
fuEufyf[kr nLrkost tks Lo;a lR;kfir gks layXu djuk vfuok;Z gksxkA
123456-

laLFkk dk iath;u dzekad rFkk izek.k i= dh Nk;k izfrA
VªsoYl ,tsUlh@okgu dk vkj-Vh-vks-esa VsDlh dksVs esa jftLVªMZ gksus dk izek.k i= dh Nk;k
izfrA
okgu pkyd ds oS| yk;lsal dh Nk;k izfr ,oa ih- ,Q- dVkS=as dh Nk;k izfrA
th-,l-Vh iznkrk ds #i esa iath;u gksus dk izek.k i= dh izfrA
vk;dj ds LFkkbZ ys[kk la[;k ¼iSu uEcj dh izfr½
okguksa dk LokfeRo laca/kh izek.k&i=@vuqca/k@iath;u izek.k i= dh izfrA
fujUrj&4

<!-- page 7 -->

¼4½
04 fufonkdkjks dh vgZrk,a&
4-1 fufonkdkj Onkjk izLrqr fufonk ds oS| gksus ds fy;s fufonk ds lkFk fuEu
nLrkostks dk layXu gksuk vfuok;Z gS%&
foxr nks o"kksZ esa lQyrkiwoZd fd;s x;s dk;ksZ ¼odZ dEiyh'ku lfVZfQdsV½ dh lacaf/kr
'kkldh; foHkkx]fuxe]eaMy ds izek.k&i= dh Lo;a izekf.kr izfr;kWA
2 fufonkdrkZ dks foxr 03 o"kksZ dk vk;dj fjVuZ dh lR;kfir izfr izLrqr djuk gksxhA
3 fufonkdrkZ dk ;fn bl dk;kZy; ds deZpkjh@vf/kdkjh ls dksbZ laca/k gks rks mldk
fooj.k nsaA
4- fufonkdrkZ Onkjk fiNys o"kZ tek fd;s x;s th-,l-Vh dh lR;kfir izfr izLrqr djuh gksxhA
1-

4-2 rduhdh izLrko&
1- okgu pkydks dk ekufld ,oa 'kkjhfjd Lrj lekU; Lrj dk gksuk pkfg,A
2- okgu pkydks dk esfMdy fQVusl izek.k i=]pfj= izek.k i= ,oa igpku i= okafNr
gksxkA
3- okgu pkydks dk iqfyl lR;kiu fufonkdrkZ dks Lo;a djok dj izLrqr djuk vfuok;Z
gksxkA
4- fufonkdrkZ dks fufonk vkosnu djrs le; okgu pkydks dh lwph nsuk vfuok;Z gksxk ,oa
fufonkdkj dks viuh rjQ ls okgu pkydks dks fu/kkZfjr dh xbZ LoPN onhZ iguuk gksxh
blds fy;s dk;kZy; ds Onkjk dksbZ Hkh jkf'k i`Fkd ls ns; ugha gksxhA
4-3 foRrh; izLrko&fufonkdrkZ Onkjk fufonk esa ?kksf"kr jkf'k eas Hkkjr ljdkj ,oa jkT; ljdkj
ds lHkh VsDl lEefyr gksxas lkFk gh fufonk dk;Za ds laiknu djus okys lHkh deZpkfj;ksa
dh M;wVh jksLVj]yscj]jftLVªs'ku 'kqYd Hkfo"; fuf/k ¼ih-,Q-½ ],oa vU; VsDlst bR;kfn
lfEefyr gksxasA bldk dksbZ Hkh Hkqxrku vyx ls bl dk;kZy; Onkjk ns; ugha gksxkA
4-4 gLrk{kj ,oa in eqnzk&fufonknkrk dks fufonk dh 'krksZ ds ,oa layXu leLr izi=ks ds
leLr i`"Bkas ij uke ,oa gLrk{kj dj jcj LVkEi yxkuk vfuok;Z gksxkA
4-5 fufonk dk izLrqrhdj.k&fufonk izLrqr djus gsrq dk;kZy; esa lhy can ckDl j[kk gksxk
ftlesa fufonk dk fo"k; Li"V vafdr gksxkA fufonk ds nksukas fyQkQksa ds Åij Li"V #i
ls fdjk;s ds okgu gsrq fufonk ,oa fyQkQk ^^,** vFkok ^^ch** fy[kk gksuk pkfg;sA
mijksDr nksukas fyQkQs ml ckWDl ds vanj Mkyuk gksxkA vlqfo/kk dh fLFkfr es lgk;d
lapkyd]foRr]Hkksiky xSl =klnh jkgr ,oa iquokZl ls laidZ fd;k tk ldrk gSA
4-6 fufonk ds izLrko ds oS|rk dh vof/k&vuqca/k dh vof/k ,d o"kZ ds fy, gksxhA ,d o"kZ
i'pkr~ ;fn lQyrkiwoZd dk;Z vuq#i fu"ikfnr ikbZ tkrh gS rks vuqca/k dh vof/k nksukas
i{kkas dh lgefr ls vkxkeh fufonk izfdz;k iw.kZ gksus rd vFkok vf/kdre nks ¼2½ o"kZ ds
fy;s c<k+bZ tk ldrh gSA
fujUrj&5

<!-- page 8 -->

¼5½
4-7 fufonk es la'kks/ku&,d ckj fufonk dk;kZy; eas izLrqr djus ds mijkUr mlesa fdlh Hkh
izdkj dk la'kks/ku ugh fd;k tk;sxk ,oa fufonk QkeZ dh vafre frfFk ds i'pkr~~ dksbZ
fufonk izkIr ugh dh tk ldsxhA
4-8 izLrko dh Hkk"kk&izLrko dh Hkk"kk fgUnh ,oa fyfi nsoukxjh gksuk pkfg,A izLrko lqLi"V
,oa vklkuh ls xzkg~; gksuk pkfg;sA izLrko eas dkaV&NkaV ugha gksuk pkfg,A rduhdh
izLrko eas izR;sd dkaV&NkaV ij fufonkdkj ds gLrk{kj gksuk pkfg,A fofRr; izLrko es
fdlh Hkh izdkj dh dkaV&NkaV ekU; ugha gksxhA
4-9 njsa&njkas dk mYys[k dsoy foRrh; izLrko esa fu/kkZfjr LFkku ij gksuk pkfg,A
4-10 vik=rk,a&fufonk izi=ksa eas mYysf[kr fdlh Hkh 'krZ dks iw.kZ u djus ij fufonkdkj
Lor%vik= ekuk tk;sxkA
4-11la'kks/ku ,oa fufonk okil ysuk &fufonk izLrqr djus ds mijkUr mleas fdlh Hkh izdkj dk
la'kks/ku laHko ugha gSA fufonk okil ysus gsrq fufonk [kksyus dh fnukad dks fufonkdkj
lapkyd]Hkksiky]xSl =klnh jkgr ,oa iquokZl Hkksiky dks fyf[kr vkosnu nsdj fufonk izfdz;k ls
vyx gks ldrk gSA ,slh fLFkfr esa fufonkdkj ds nksuks fyQkQs ewyr%okil dj fn;s tk;sxasA
4-12'krksZ ds xzkg~rk dh larqf"V& ftl fufonk drkZ ds i{k esa fufonk Lohd`r gksxh mlds laca/k
es ;g Hkh ekuk tk;sxk dh mles mDr lHkh 'krksZ dks vPNh rjg ls i<+ yh ,oa le> yh gSA os
lHkh 'krsZ mls Lohdk;Z gSa rFkk mUgh 'krksZ ds varxZr mlus fufonk gsrq fufonk izLrqr dh gSA
05 vuqca/k dk fu"iknu&

5-1 fufonk dh izfrHkwfr (Earnestmoney deposit)&fufonkdkj dks fufonk ds le;
izfrHkwfr (Earnestmoney deposit) rhuks okguks ds fy;s jkf'k #-21000@&¼#-bDdhl gtkj½
ek= lapkyd]Hkksiky xSl =klnh jkgr ,ao iquokZl]Hkksiky ds uke ls LVsV cSad vFkok fdlh Hkh
jk"Vªh;d`r cSad ls fMekaM Mªk¶V]fe;knh tek jlhn]cSdlZ pSd vFkok cSad xkjaVh ds #i es tek
djuh gksxkA fufonk dh izfrHkwfr]fufonk dh vafre oS/krk frfFk ds ckn iSrkyhl fnu dh vof/k
ds fy, oS/k gksuk vko';d gSaA vlQy fufonkdrkZvksa dh fufonk dh izfrHkwfr jkf'k okil dj
nh tkosxh]ijUrq f)rh; U;wure nj nsus okys fufonkdkj dh /kjksgj jkf'k lQy fufonkdkj ls
vuqca/k ij gLrk{kj ds ckn okil dh tkosxhA fufonk Lohd`r dh lwpuk ds 15 fnol ds Hkhrj
vuqca/k ugh fd;s tkus dh n'kk esa fufonk izfrHkwfr jkf'k 'kklu ds i{k esa jktlkr dj yh
tkosxhA
fujUrj&6

<!-- page 9 -->

¼6½
5-2 fu"iknu izfrHkwfr (Performance Guarantee)& lQy fufonkdkj Onkjk izLrkfor njksa
ds okf"kZd jkf'k ds 05 izfr'kr izfrokgu ijQkjesal flD;wfjVh (Performance Guarantee) LVsV
cSad vkQ bafM;ka vFkok fdlh Hkh jk"Vªh;d`r cSd ls ,Q-Mh-vkj-ds #i es ,d o"kZ ds fy;s
lapkyd]Hkksiky xSl =klnh jkgr ,oa iquokZl]01]f'kokth uxj Hkksiky ds uke tek djuh gksxhA
ijQkjesal flD;wfjVh lQyrkiwoZd dk;Z lekfIr ij fufonkdkj dks okil dj fn;k tk;sxkA
fu/kkZfjr ijQkjesal flD;wfjVh tek ugh djus dh fLFkfr es vuqca/k ugh fd;k tkosxk ,oa
fufonk ds le; izLrqr izfrHkwfr (Earnestmoney deposit) jkf'k jktlkr dj yh tkosxhA
5-3

vuqca/k esa gLrk{kj&fufonkdrkZ dh fufonk foHkkxh; lfefr Onkjk Lohd`r gksus ij
fufonkdrkZ dks Lo;a ds [kpZ ij #i;s]500@&ds ukWu T;wfMf'k;y LVkEi ij vuqca/k
fufonk Lohd`fr ls 15 fnol ds vanj djuk gksxkA vuqca/k izi= ij nksuks i{kksa ds
gLrk{kj ,oa xokgksa ds gLrk{kj ds mijkar gh iw.kZ ekuk tk,xkA fufonkdrkZ ds Onkjk
viuh vksj ls nh xbZ dksbZ Hkh 'krZ ekU; ugha gksxhA

5-4 lasok,a ,oa okjaVh&dk;Z LFky ij fufonkdrkZ rFkk mlds okgu pkyd 'kjkc vU; eknd
oLrqvksa dk lsou ugh djasxas rFkk mudk O;ogkj vf/kdkjh ,oa deZpkjh;ksa ds izfr lkSE; ,oa
uezrkiwoZd gksuk pkfg;sA f'kdk;r izkIr gksus ij vuqca/kdrkZ ds fo#) n.MkRed dk;Zokgh
dh tkosxh]tks vkfFkZd 'kkfLr lacaf/kr deZpkjh dks gVkus fo"k;d gks ldsxhA

5-4&1 lkekU;r%vko';drk gksus ds 12 ?kaVs iwoZ okgu ds iznk; gsrq fjDohth'ku fufonkdkj dks
Hkstk tkosxk]ftldk ikyu fufonkdkj dks djuk gksxkA miyC/k djkbZ tkus okyh okgu
VSDlh dksVs esa iathd`r gksuk vfuok;Z gSA

5-4&2 ;fn fufonkdkj vuqca/k vof/k esa le; ij okgu miyC/k djkus esa vleFkZ gksrk gS rFkk
lapkyuky;]Hkksiky xSl =klnh jkgr ,oa iquokZl Hkksiky Onkjk cktkj ls okgu izkIr fd;k
tkrk gS rks lapkyuky;]xSl jkgr ,oa iquokZl Hkksiky dks bl izdkj gksus okyh {kfr dh
olwyh fufonkdkj ls dh tk ldsxhA fufonkdkj ds lkFk lapkyuky;]Hkksiky xSl =klnh
jkgr ,oa iquokZl Hkksiky ds vuqca/k dh vof/k lkekU;r% ,d o"kZ ds fy, gksxkA ;fn
vuqca/k dh vof/k esa fufonk dk dk;Z mRd`"V jgk rks vuqca/k dh vof/k vkxs Hkh c<+kbZ tk
ldsxhA

5-4&3 okgu pkyd fufonkdkj dk O;fDr gksxk ftldk fdlh Hkh izdkj dk O;;
lapkyuky;]Hkksiky xSl =klnh jkgr ,oa iquokZl Hkksiky Onkjk ogu ugh fd;k tkosxkA
okgu pkyd fdlh ,sls u'ks dk vfn ugh gksuk pkfg;s ftls okgu pkyd ds fy;s fdlh
izdkj ls izfrcaf/kr fd;k x;k gksA okgu pkyd dk O;ogkj fouez rFkk 'kkyhu gksuk
pkfg,A pkyd ds ikl oS| yk;lsal ewy #i ls j[kk tkuk vfuok;Z gksxkA
fujUrj&7

<!-- page 10 -->

¼7½

5-4&4 iznk; fd;s okgu ds laiw.kZ vfHkys[k ges'kk okgu esa miyC/k jguk vfuok;Z gksxk rkfd
vkj-Vh-vks-fujh{k.k@iqfyl fujh{k.k esa fdlh izdkj dh vfiz; fLFkfr fufeZr u gksA

5-4&5 izokl dh n'kk es Vksy VsDl dk Hkqxrku fufonkdkj djsaxk]ftldh izfriwfrZ izek.k
¼jlhn½ izLrqr djus ij foHkkx Onkjk dh tk ldsxhA

5-4&6 okgu iznku djrs le; bZ/ku vk;y QqyVSad dj Hkstk tkuk vfuok;Z gksxkA
5-4&7 okgu ds lkFk iath;u chek ,oa vU; vko';d nLrkost ewy #i ls gksuk vfuok;Z

gksxkA ftUgs l{ke vf/kdkjh Onkjk ekWxs tkus ij izLrqr djus dh tckcnkjh okgu ds
lkFk x;s pkyd dh gksxhA pkyd Onkjk fd;k x;k dksbZ O;ogkj fufonkdkj ds Onkjk
fd;k x;k ekU; gksxkA ;fn M;wVh ds le; okgu ls lacaf/kr dksbZ nq?kZVuk ?kfVr gksrh
gS rks mldk laiw.kZ nkf;Ro fufonkdkj rFkk okgu pkyd ij gksxkA lapkyuky; blds
fy;s fdlh izdkj ls mRrjnk;h ugha gksxkA

5-4&8 M;wVh ds le; okgu eas fdlh izdkj dh [kjkch mRiUu gksus ij fufonkdkj dks rRdky
vU; okgu miyC/k djkuk gksxkA

5-4&9 okgu Onkjk lkSih x;h ,oa laikfnr dh xbZ M;wVh dk fjdkMZ okgu pkyd dks M;wVh
ds nkSjku vius ikl lqjf{kr j[kuk vfuok;Z gksxkA
5-5 isukWYVh& ;fn okgu pkyd fu/kkZfjr le; ij okgu lfgr mifLFkr ugh gksrk gS ,oa cxSj
lwpuk ds vuqifLFkr jgrk gS]ftldh f'kdk;r lacaf/kr okgu mi;ksxdrkZ vf/kdkjh Onkjk
dh tkrh gS rks ml ekWg ds ns;d ls fu;ekuqlkj jkf'k fufonkdkj ds ns;d ls dkV yh
tk;sxhA
5-6 vuqca/k dh 'krksZ dk mYy?ku& fufonkdrkZ ds okgu pkydks dk O;ogkj larks"kizn u gksus
ij deZpkfj;ksa Onkjk f'kdk;r izkIr gksus ij vFkok fdlh Hkh izdkj dh 'krksZ dk mYy?ku
djus ij fufonkdrkZ ds fo#) vkfFkZd n.M lacaf/kr dehZ dks gVkuk ;k xaHkhj izdj.k es
vuqca/k lekIr djus dh dk;Zokgh dh tk ldsxhA bldk iw.kZ vf/kdkj lapkyd]Hkksiky
xSl =klnh jkgr ,oa iquokZl Hkksiky dks gksxk rFkk fu"iknu izfrHkwfr dh iwjh vFkok
vkaf'kd jkf'k tIr dh tk ldsxhA
fujUrj&8

<!-- page 11 -->

¼8½
06 Hkqxrku
6-1 vuqca/kdrkZ Onkjk ekWg dh lekfIr ds mijkUr vkxkeh ekWg dh 05 rkjh[k rd fdjk;s ij
fy;s x;s okgu dh la[;k ds eku ls ns;d izLrqr fd;k tk;sxkA dk;kZy; Onkjk ijh{k.k
mijkUr bu ns;dkas dk Hkqxrku vuqca/kdrkZ ds cSad vdkmaV eas fd;k tk;sxkA
07 fookn dk fujkdkj.k&
fdlh Hkh fookn ,oa 'krksZ dh vogsyuk vFkok vopkj ;k dnkpkj dh fLFkfr esa fufonk
fujLr djus laca/kh leLr vf/kdkj lapkyd]Hkksiky xSl =klnh jkgr ,oa iquokZl]Hkksiky
ds ikl loZnk lqjf{kr jgsxkA izdj.k esa U;k;ky;hu ifjfLFkfr;ksa mn~Hkwr gksus ij izdj.k
Hkksiky fLFkr U;k;ky; esa gh py ldsxkA

lapkyd]
Hkksiky xSl =klnh jkgr ,oa iquokZl]Hkksiky

<!-- page 12 -->

izi=&v&1
@@lwpuk i=@@
¼fyQkQk&,&es j[kk tk;½
izfr]
lapkyd]
Hkksiky]xSl =klnh jkgr ,oa iquokZl]
01]f'kokth uxj]Hkksiky
fo"k;%&lapkyuky;]Hkksiky xSl =klnh jkgr ,oa iquokZl]Hkksiky dk;kZy; varxZr
ekfld ¼iw.kZdkfyd½@nSfud nj ij okgu miyC/k djkus gsrq izk;osV okgu
¼vkj-Vh-vks- dk;kZy; es iathd``r½ VsDlh dksVs dh Bsds ij ysus ckcr~A
egksn;]
nSfud lekpkj i=---------------------------------------------esa izdk'ku ds Onkjk Kkr gqvk gS
fd lapkyuky; Hkksiky xSl =klnh jkgr ,oa iquokZl Hkksiky ds dk;kZy; gsrq
ekfld ¼iw.kZdkfyd½@nSfud nj ij okgu miyC/k djkus ds fy, fufonk vkeaf=r
dh xbZ gS]bl gsrq esjs Onkjk fufonk ls lacaf/kr fuEu izi= gLrk{kj dj vkids
dk;kZy; esa tek fd, tk jgs gSa%&
1. Vsªoy ,tsalh@okgu dk VsDlh dksVs es vkj-Vh-vks- es jftLVMZ gksus ckcr~ izek.k
i= dh izfrA
2. vk;dj ds LFkk;h ys[kk la[;k ¼isu uEcj½ dh izfrA
3. th-,l-Vh iznkrk ds #i esa iath;u gksus dk izek.k i= dh izfrA
4. vkj-Vh-vks- Onkjk VsDlh dksVs esa ,tsalh@okgu dk iath;uA
5. uxj fuxe ls tkjh xqek'rkA
6. bZ-,e-Mh-dh jkf'k #----------------@&,Q-Mh-@fMekaM Mªk¶V@cSadlZ psd dz----------------------

------fnukad------------------fnukad---------------------LFkku------------------------

uke@gLrk{kj
QeZ dk uke------------------------

<!-- page 13 -->

izi=&v&2
@@?kks"k.kk&i=@@
¼fyQkQk&,&es j[kk tk;½
1. eSa@ge@QeZ dk uke----------------------------------------------------------------------------------------------Hkkjr

dk@ds ukxfjd gwW@gSA ¼vkxkeh fcUnqvksa esa eSa@ge v/kksgLrk{kdrkZ
fufonkdrkZ ds fy;s iz;qDr gksxk½
2. eS@ge Hkkjrh; lafonk vf/kfu;e ds vuqlkj lafonk ds fy;s l{ke gwW@gSA
3. eq>s@gesa ekfld@nSfud nj ij okgu miyC/k djkus ds dk;ksZ ds fy;s

e/;izns'k 'kklu ds fdlh Hkh foHkkx Onkjk cfg"d``r ugha fd;k x;k gSA
4. eS@ge fdlh ,sls dkUVªsDVj tks fd e-iz-'kklu ds fdlh Hkh foHkkx Onkjk

cfg"d``r fd;k x;k gks] ds uk rks vfHkdrkZ gwa@gS vkSj u gh mlds fy;s
dk;Z djrk gwW@djrs gSA
5. esjs@gekjs Onkjk iznRr okgu ,oa okgu pkydksa ds dk;Zs dh xq.koRrk Bhd

u ik, tkus ij mlls tks Hkh uqdlku gksxk mldh iw.kZ ftEesnkjh
esjh@gekjh Lo;a dh gksxhA
6. esjs@gekjs Onkjk fufonk dh 'krksZ ds vykok vU; dksbZ 'krZ izLrqr ugh dh

xbZ gSA
7. eSa@ge

Je dkuwuksa ,oa cky Je vf/kfu;e ds izko/kkuksa dk iw.kZr%ikyu
d#Wxk@djsaxasA

fnukad---------------------LFkku------------------------

¼fufonkdkj ds gLrk{kj½
uke%&----------------------------------iwjk irk%&--------------------------------------------------------------------------Qksu ,oa eks-ua-

<!-- page 14 -->

izi=&v&3
@@lqj{kk fuf/k@@
¼fyQkQk&,&es j[kk tk;½
fufonk dh izfrHkwfr (Earnestmoney deposit)&jkf'k dk fooj.k ntZ dj
lacaf/kr ewy nLrkost ds lkFk izFke fyQkQs esa j[kus gsrqA
dk;kZy; dk uke&%lapkyd]Hkksiky xSl =klnh jkgr ,oa iquokZl]Hkksiky gsrq
ekfld@nSfud nj ij okgu miyC/k djkukA
Bsdk gsrq tek vusZLVeuh (Earnestmoney) ls lacaf/k ,l-ch-vkbZ-@jk"Vªh;d``r
cSad ,Q-Mh-vkj- dk fooj.k%&
dzekad

,Q-Mh-vkj-dk ,l-ch-vkbZ-@
dz-,oa fnukad jkf"Vªh;d``r
cSad dk uke
,oa 'kk[kk

jkf'k

tkjh gksus dk
fnukad

cS/krk vof/k

dk;Z dk uke--------------------------------------------------------------------------------------------------------fufonk dzekad------------------------fnukad------------------------------------------------------------fnukad---------------------LFkku------------------------

¼fufonkdkj ds gLrk{kj½
uke%&----------------------------------iwjk irk%&--------------------------------------------------------------------------Qksu ,oa eks-ua-

<!-- page 15 -->

izi=&v&4
@@fufonk dh 'krsZ ,oa fu;e ls lgefr i=@@
¼fyQkQk&,&es j[kk tk;½
eS---------------------------------------------------------iq=---------------------------------------------------------------------okLrs QeZ----------------------------------------------------------------------------vkids dk;kZy; Onkjk
foKkfir fufonk esa Hkkx ysuk pkgrk@pkgrh gwWA esjs Onkjk fufonk dh 'krksZ gsrq
fu/kkZfjr i= dz-----------------@izk-ok-@2018&19 -----------------Hkksiky fnukad----------------------------esa fufonk dh 'krksZ ds varxZr Hkkx 1 ,oa 2 esa of.kZr dafMdk dz-01 ls 07
rd dh dafMdkvksa ,oa muds varfuZfgr leLr midafMdkvksa dk v/;;u dj
fy;k gS rFkk eSa muls lger gwW ,oa ;fn esjh fufonk ekU; dh tkrh gS rks
fu/kkZfjr 'krksZ ds vk/kkj ij vuqca/k gsrq lger gwWA

fnukad----------------------

¼fufonkdkj ds gLrk{kj½

LFkku-----------------------uke%&----------------------------------iwjk irk%&--------------------------------------------------------------------------Qksu ,oa eks-ua-

<!-- page 16 -->

izi=&v&5
@@fufonkdkj Onkjk rduhdh fcM gsrq izLrqr dh tkus okyh tkudkjh@@
¼fyQkQk&,&es j[kk tk;½
fufonkdkj dk uke%&
dzekad
rduhdh ekin.M
1
vusZLV euh lapkyd]Hkksiky xSl =klnh jkgr
,oa iquokZl Hkksiky ds uke ls fMekaM Mªk¶V]
fe;knh tek jlhn]cSdlZ pSd tks Hkksiky 'kgj
esa fLFkr 'kk[kk ij ns; gks layXu djsaA
2
VsªsoYl ,tsalh@okgu dks vkj-Vh-vks-esa jftLVMZ
gksuk vfuok;Z gSA izek.k i= layXu djsaA
3
vk;dj ds LFkk;h ys[kk la[;k ¼isu-ua-½ dh izfr
,oa rhu o"kZ ls Hkjh tkus okyh bade VsDl dh
izfr;kaA
th-,l-Vh iznkrk ds #i esa iath;u gksus dk
4
izek.k i= dh izfrA
5
uxj fuxe Onkjk tkjh xqek'rk yk;lsal dh
izfr
okgu pkyd ds ih- ,Q- dVkS=as dh Nk;k
6
izfrA

fnukad---------------------LFkku------------------------

fjekdZ

¼fufonkdkj ds gLrk{kj½
uke%&----------------------------------iwjk irk%&--------------------------------------------------------------------------Qksu ,oa eks-ua-

<!-- page 17 -->

izi=&v&6
@@vuqca/k dk izk#i@@
lapkyuky;]Hkksiky xSl =klnh jkgr ,oa iquokZl]01]f'kokth uxj]Hkksiky ds
dk;kZy; gsrq okgu la[;k okgu ekfld ¼iw.kZdkfyd½@nSfud nj ¼VsDlh dksVs½ ij miyC/k
djkus gsrq lapkyd]Hkksiky xSl =klnh jkgr ,oa iquokZl]Hkksiky tks bl vuqca/k ds izFke
i{k gksaxas rFkk--------------------------------------------------------------------------tks bl vuqca/k esa f)rh; i{k gksaxas ds
e/; vkt fnukad-------------------------dks vauqca/k lEikfnr fd;k tk jgk gSA fufonk izi= esa nh
xbZ leLr 'krsZ bl vuqca/k dk Hkkx gksxhA ;g vuqca/k ekfld ¼iw.kZdkfyd½@nSfud nj ij
okgu miyC/k djkus gsrq izkIr fufonk lacaf/k dk;Zokgh fnukad------------------esa Lohd`r U;wure
nj izLrqr djus okys fufonkdrkZ--------------------------------------------ds e/; gSaA
vuqca/k ds fu;e ,oa 'krsZ%&
1. fufonk dh 'krksZ ds varxZr Hkkx&1 ,oa Hkkx&2 esa of.kZr dafMdk dz-1 ls 7 rd dh

dafMdkvksa ,oa muds varfuZfgr leLr midafMdkvksa dk vuqca/kdrkZ ,tsUlh dks
ikyu djuk vfuok;Z gksxkA
2. ekfld ¼iw.kZdkfyd½@nSfud nj ij okgu miyC/k djkus dh O;oLFkk ds varxZr

dk;Zjr deZpkfj;ksa dh tku&eky dh lqj{kk lacaf/kr ,staslh dh jgsxhA
3. Vs.Mj Lohd`r vkns'k ls ,d o"kZ ds fy, ;g O;oLFkk gksxh];fn QeZ ekfld

¼iw.kZdkfyd½ okgu@nSfud nj ij miyC/k djkus es vlQy gksrh gS ;k le; iwoZ
Bsdk NksM+ nsrs gS rks ,slh fLFkfr esa muds Onkjk tek fu"iknu izfrHkwfr
(Performance Guarantee) tIr dj fy;k tkosxk ,oa Bsdk fujLr dj fufonk
izfdz;k esa f)rh; U;wure nj okyh fufonknkrk dks fn;k tkosxkA
4. ekfld ¼iw.kZdkfyd½ nj ij okguksa dh la[;k de vFkok vf/kd djus dk vf/kdkj

lapkyd]xSl jkgr ,oa iquokZl]Hkksiky ds ikl lqjf{kr gksxkA
5. okgu pkyu dk;Z esa rSukr deZpkjh dkuwuh rkSj ij vPNsa pfj= okys gksus pkfg,

bldh ftEesnkjh QeZ dh gksxh ,oa pkydks dks LoPN onhZ iguuk vfuok;Z gksxh
blds fy, dk;kZy; Onkjk dksbZ Hkh jkf'k i``Fkd ls ns; ugh gksxhA
6. QeZ dks fufonk Lohd``r gksus ds i'pkr~ okgu pkydksa ds uke irk ,oa ikliksVZ

lkbt ds QksVks ,oa oS/k Mªk;foax yk;lsUl dh Nk;k izfr bR;kfn dh tkudkjh
dk;kZy; es izLrqr djuk gksxhA

<!-- page 18 -->

¼2½
7-dk;Z LFky ij Bsdsnkj rFkk mlds deZpkjh 'kjkc vU; eknd oLrqvksa dk lsou ugh
djsxs rFkk mudk O;ogkj turk ,oa deZpkfj;ksa ds izfr lksE; ,oa uezrk iwoZd gksuk
pkfg, f'kdk;r izkIr gksus ij Bsdsnkj ds fo#) n.MkRed dk;Zokgh dh tkosxhA tks
vkfFkZd 'kkfLr lacaf/kr okgu pkyd ,oa okgu dks gVkus fo"k;d gks ldsxh ,slh fLFkfr
es nwljk okgu pkyd miyC/k djkuk gksxkA

8-lacaf/kr QeZ@okgu dz- dks vkj-Vh-vks-esa VsDlh dksVs es iathd``r gksuk vfuok;Z gSaA
9-;g fufonk ,d o"kZ ds vuqca/k ds fy;s ekU; dh tkosxh ,oa dk;Z larks"ktud gksus
ij nksuks i{kksa dh lgefr ls lapkyd]xSl jkgr ,oa iquokZl]Hkksiky Onkjk ¼vf/kdre nks
o"kZ½ fufonk dks leLr 'krksZ vuqlkj c<+kbZ tk ldrh gSaA

10-vuqca/kdrkZ Onkjk ekg dh lekfIr ds mijkUr vkxkeh ekg dh 05 rkjh[k rd ns;d
izLrqr djuk gksxkA dk;kZy; Onkjk ijh{k.k mijkUr bu ns;dks dk Hkqxrku Vh-Mh-,ldkV dj vuqca/kdrkZ ds cSad [kkrs esa fd;k tk;sxkA
10-1

ekWg ds fu/kkZfjr dk;Z fnol es okgu pkyd okgu ysdj lacaf/kr okgu
mi;ksxdrkZ vf/kdkjh ds ikl ugh igqp ikrk gS rFkk muds Onkjk f'kdk;r
djusa ij ns;d ls #-500@& izfr fnol dh n.MkRed dVkSrh dh tkosxhA

10-2

dk;kZy; es ekfld nj ij yxk;s x;s okgu ds fujh{k.k@vkdyu ds nkSjku
okgu Bhd gkyr es u ik;s tkus ij izfr dk;Z fnol ds eku ls ekfld
ns;d ls vf/kdre 5 izfr'kr dh jkf'k dVkS=s ds #i es dkVh tk ldsxh
,oa f'kdk;r dh rhu ls vf/kdokj iqujko`fRr gksus ij vuqca/k fujLr fd;k
tk ldsxkA

11- ;fn fdlh fufonkdrkZ ds lkFk fookn mRiUu gksrk gS rks 'krksZ ds vuqlkj ekU;
;ksX; ugh gks rks lapkyd]xSl jkgr ,oa iquokZl]Hkksiky dk fu.kZ; vafre gksxkA
12-

fdlh fookn ,oa 'krksZ dh vogsyuk vFkok vopkj ;k dnkpj.k dh fLFkfr es
fufonk fujLr djus laca/kh leLr vf/kdkj lapkyd]Hkksiky xSl =klnh jkgr ,oa
iquokZl ds ikl loZFkk lqjf{kr jgsxkA izdj.k es U;k;ky;hu ifjfLFkfr;kW mn~Hkwr
gksus ij izdj.k Hkksiky fLFkr U;k;ky; es gh py ldsxkA

13- ns;d ls fu;ekuqlkj le;&le; ij izpfyr vk;dj ¼Vh-Mh-,l-½ dh dVkSrh dh
tkosxhA

<!-- page 19 -->

¼3½
14- fufonkdrkZ Onkjk fufonk esa ?kksf"kr jkf'k eas Hkkjr ljdkj ,oa jkT; ljdkj ds lHkh
VsDl lEefyr gksxas lkFk gh fufonk dk;Za ds laiknu djus okys lHkh deZpkfj;ksa
dh M;wVh jksLVj]yscj]jftLVªs'ku 'kqYd Hkfo"; fuf/k ¼ih-,Q-½]th-,l-Vh- ,oa vU;
VsDlst bR;kfn lfEefyr gksxasA bldk dksbZ Hkh Hkqxrku vyx ls dk;kZy; Onkjk
ns; ugha gksxkA
15 okgu fdjk;k Hkqxrku ds i'pkr th-,l-Vh dVkS=k dh jlhn bl dk;kZy; dks
nsuk gksxk rkfd okgu dk ekfld Hkqxrku fd;k tk;sxk A
16-

fufonk vkea=.k lwpuk fufonk izi= ,oa okgu iznkrk QeZ@laLFkk Onkjk izLrqr
mijksDr fofHkUu lR;kfir izk#i ds vax gksxsA

17- vuqca/k vof/k esa okgu ds fdjk;s es dksbZ ifjorZu ugh gksxk vkSj dksbZ vU; 'krZ
ekU; ugh gksxh ;fn mYysf[kr 'krkZs ds vfrfjDr vkQj es vU; 'krZ nh tkrh gS
rks fufonk foHkkx dks ekU; ugha gksxhA

izFke i{kdkj

f}rh; i{kdkj

xokg%&

xokg%&

1-

1-

2-

2-

<!-- page 20 -->

izi=&c
@@foRrh; izLrko izkbt&fcM@@
¼fyQkQk ch esa j[kk tk,½
dk;kZy; dk uke%&dk;kZy;]lapkyuky; Hkksiky xSl =klnh jkgr ,oa
iquokZl]Hkksiky gsrq ekfld ¼iw.kZdkfyd½@nSfud nj ij okgu miyC/k djkusa ds
laca/k esaA
fufonk dzekad------------------------

fnukad--------------------------

fufonk izi= vuqlkj okgu laca/kh tkudkjh ,oa okgu ds fy;s ekfld@nSfud njsa
¼Hkkjr ljdkj ,oa jkT; ljdkj ds lHkh izdkj ds VsDl lfgr½

l-dz-

okgu dk uke

'kks#e nj ¼ExShowroom
Price½

1-

2

1000 fd-ehekfld nj
¼iw.kZdkfyd½
ij fdjk;k
jkf'k

3

4

nSfud nj
ij fdjk;k
jkf'k
¼4]?kaVs 40 fdeh-]
8]?kaVs 80 fdeh,oa 16 ?kaVs 250
fdeh-½

5

1000 fd-ehekfld pyus
ds i'pkr
vfrfjDr izfr
fd-eh dh nj
ls jkf'k
6

TATA MOTORS

1234-

ZEST-XE-WHITE

Rs.661195/-

ZEST-TXM-WHITE

Rs.725491/-

ZEST-SMS-WHITE

Rs.751686/-

ZEST-XT-WHITE

Rs.814026/-

MARUTI- SUZUKI

5678-

DZIRE-LDI-WHITE

Rs.656000/-

DZIRE-VDI-WHITE

Rs.744000/-

DZIRE-ZDI-WHITE

Rs.806000/-

CIAZ DELTA-DIESEL

Rs.987300/-

TOYOTA

910-

HYPO-ETIOS-GD-WHITE

Rs.765600/-

HYPO-ETIOS-GXD-WHITE

Rs.804800/-

fnukad---------------------LFkku------------------------

¼fufonkdkj ds gLrk{kj½
uke%&---------------------------------iwjk irk%&----------------------------

<!-- page 21 -->

------------------------------------------------
