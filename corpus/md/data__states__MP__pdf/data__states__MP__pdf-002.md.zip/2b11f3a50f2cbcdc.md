---
doc_id: "2b11f3a50f2cbcdc"
source_url: "https://portal.mpcz.in/upload_files/pdf/home/latest_news_and_updates/Consumers_Rules_2020.pdf"
ministry: "Madhya Pradesh Madhya Kshetra Vidyut Vitaran Co. Ltd., Bhopal, Madhya Pradesh"
title: "Electricity (Rights of Consumer) Rules, 2020"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9ab61985fa424750"
---

<!-- page 1 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : ऄसाधारण

13

NOTIFICATION
New Delhi, the 31st December, 2020
G.S.R. 818(E).—In exercise of the powers conferred by sub-section (1) read with clause (z) of subsection (2) of section 176 of the Electricity Act, 2003 (Act 36 of 2003), the Central Government hereby
makes the following rules, namely:1.

Short title and commencement.- (1)
Consumers) Rules, 2020.

(2)

They shall come into force on the date of their publication in the Official Gazette.

2.

Definitions.- (1) In these rules, unless the context otherwise requires,-

These rules may be called the Electricity (Rights of

(a)

―Act‖ means the Electricity Act, 2003;

(b)

―applicant‖ means an owner or occupier of any premises who files an application form
with a distribution licensee for supply of electricity, increase or decrease in sanctioned load
or contract demand, change in title or mutation of name, change in consumer category,
disconnection or restoration of supply, or termination of agreement, shifting of connection
or other services as the case may be, in accordance with the provisions of the Act, rules and
regulations made thereunder;

(c)

―application‖ means an application form complete in all respects in the appropriate
format, as specified by the Commission, along with documents and other compliances;

(d)

―billing cycle or billing period‖ means the period for which regular electricity bills as
specified by the Commission, are issued for different categories of consumers by the
distribution licensee;

(e)

―Commission‖ means the State Electricity Regulatory Commission constituted under
section 82 of the Act;

(f)

―Consumer‖ means any person who is supplied with electricity for his own use by a
distribution licensee or the Government or by any other person engaged in the business of
supplying electricity to the public under the Electricity Act, 2003 or any other law for the
time being in force and includes any person whose premises are for the time being
connected for the purpose of receiving electricity with the works of a distribution licensee,
the Government or such other person, as the case may be;

(g)

―days‖ means clear working days;

(h)

―disconnection‖ means the physical separation or remote disconnection of a consumer
from the distribution system of the distribution licensee;

(i)

―fixed charges‖ has the same meaning as per the provisions of the prevailing Tariff Order
issued for the distribution licensee by the Commission;

(j)

―maximum demand‖ means the highest load measured in average kVA or kW at the point
of supply of a consumer during any consecutive period of thirty minutes or as specified by
the Commission, during the billing period;

(k)

―occupier‖ means the owner, tenant or person in occupation of the premises where
electricity is used or proposed to be used;

(l)

―point of supply‖ means the point, as may be specified by the State Commission, at which
a consumer is supplied electricity;

(m) ―prosumer‖ means a person who consumes electricity from the grid and can also inject
electricity into the grid for distribution licensee, using same point of supply;
(n)

―temporary connection‖ means an electricity connection required by a person for meeting
his temporary needs such as(i) for construction of residential, commercial and industrial complexes including pumps
for dewatering;
(ii) for illumination during festivals and family functions;

<!-- page 2 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(iii) for threshers or other such machinery excluding agriculture pump sets;
(iv) for touring cinemas, theatres, circuses, fairs, exhibitions, melas or congregations.
(o)

―unauthorised use of electricity‖ has the meaning as assigned to it under section 126 of
the Act.

(2)
The words and expressions used and not defined in these rules but defined in the Act shall
have the meanings assigned to them in the Act and in absence thereof, the meanings as commonly
understood in the electricity supply industry.
3.

Rights and Obligations.- It is the duty of every distribution licensee to supply electricity on request
made by an owner or occupier of any premises in line with the provisions of Act. It is the right of
consumer to have minimum standards of service for supply of electricity from the distribution licensee
in accordance with the provisions made in these rules.

4.

Release of new connection and modification in existing connection.- (1) The distribution
licensee shall prominently display on its website and on the notice board in all its offices, the
following; namely:(a) detailed procedure for grant of new connection, temporary connection, shifting of meter or,
service line, change of consumer category, enhancement of load, reduction of load or
change in name, transfer of ownership and shifting of premises etc;
(b) address and telephone numbers of offices where filled-up application forms can be
submitted;
(c) address of website for online submission of application form;
(d) complete list of copies of the documents required to be attached with the application;
(e) all applicable charges to be deposited by the applicant.

(2)

Application forms for all type of connections as well as modification in existing connection shall be
available at all the local offices of the distribution licensee free of cost as well as on its website for
free download.

(3)

The distribution licensee shall create a web portal and a mobile app for submission of online
application forms.

(4)

The applicant shall have an option to submit an application form in hard copy form or an electronic
means such as online through web portal or mobile app of distribution licensee.

(5)

In case hard copy of the application form is submitted, the same shall be scanned and uploaded on
the website as soon as it is received and acknowledgement with the registration number for that
applicant shall be generated and intimated to the applicant.

(6)

In case of online application form through web portal or mobile app of distribution licensee, the
acknowledgement with the registration number shall be generated on submission of application.

(7)

An application, complete with all the required information, shall be deemed to be received on the
date of generation of acknowledgement with registration number. In case of hard copy submission,
the acknowledgement with registration number shall be generated within such period as may be
specified by the Commission, not exceeding twenty four hours, of receipt of the application,
complete with all the required information.

(8)

The application tracking mechanism based on the unique registration number shall be provided by
the distribution licensee through web-based application or mobile app or through SMS or by any
other mode to monitor the status of processing of the application like receipt of application, site
inspection, issuance of demand note, external connection, meter installation and electricity flow.

(9)

For new connections up to a load of 10 kW or such higher load as may be specified by the
Commission, the application form shall be accompanied with only two mandatory documents(1) identity proof (i.e. Passport, Aadhar Card etc.) of the applicant; and
(2) proof of applicant’s ownership or occupancy over the premises for which new connection is
being sought or in the absence of any proof of ownership or occupancy, any other address poof not

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : ऄसाधारण

15

given as part of identity proof under (1) above. For new connections beyond the specified load, and
modification of existing connection, the Commission shall explicitly specify the documents
required to be submitted with the application.
(10)

In case, an agreement is required to be executed between distribution licensee and the consumer, the
same shall become the part of the application form and there shall not be any requirement of a
separate agreement form.

(11) The Commission shall specify the maximum time period, post submission of application complete in
all respect, not exceeding seven days in metro cities, fifteen days in other municipal areas and thirty
days in rural areas, within which the distribution licenses shall provide new connection and modify an
existing connection:
Provided that where such supply requires extension of distribution mains, or
commissioning of new sub-stations, the distribution licensee shall supply the electricity to such
premises immediately after such extension or commissioning or within such period as may be
specified by the Commission.
(12) If a distribution licensee fails to supply electricity within the period specified by the Commission, it
shall be liable to a penalty as may be determined by the Commission, which shall not exceed one
thousand rupees for each day of default.
(13)

For electrified areas up to 150 kW or such higher load as the Commission may specify the connection
charges for new connection shall be fixed on the basis of the load, category of connection sought and
average cost of connection of the distribution licensee so as to avoid site inspection and estimation of
demand charges for each and every case individually. The demand charges, in such cases, may be
paid at the time of application for new connection.

5. Metering – (1) No connection shall be given without a meter and such meter shall be the smart prepayment meter or pre-payment meter. Any exception to the smart meter or prepayment meter shall
have to be duly approved by the Commission. The Commission, while doing so, shall record proper
justification for allowing the deviation from installation of the smart pre-payment meter or prepayment meter.

(2)

At the time of seeking a new connection the consumer shall have the option to (a) purchase the meter, MCB or CB and associated equipment himself; or
(b) require that the meter, MCB or CB and associated equipment be supplied by the distribution
licensee, on payment of applicable charges.

(3)

The distribution licensee shall ensure that tested and sealed meters of approved meter
manufacturers are available to consumers for purchase and information of the places from where
the consumers can purchase them is made available on its website.

(4)

The meter shall be read at least once in every billing cycle in urban as well as rural areas by an
authorised representative of the distribution licensee.

(5)

In case of smart meters, the meters shall be read remotely at least once in every month and in case
of other pre-payment meters, the meters shall be read by an authorised representative of the
distribution licensee at least once in every three months. The data regarding energy consumption
shall be made available to the consumer, through website or mobile App or SMS, etc. Consumers
having smart pre-payment meters may also be given the data access for checking their consumption
on real time basis.

(6)

For post payment meters, if the meter is inaccessible to the meter reader on two consecutive meter
reading dates, the consumer shall have the option to send the picture of the meter indicating the
meter reading and date of meter reading through registered mobile or through e-mail. In such a
case, distribution licensee may not send any notice or provisional bill to the consumer

(7)

Testing of meters shall be done by the distribution licensee within a period as may be specified by
the Commission, not exceeding thirty days, of receipt of the complaint from the consumer about
their meter readings not being commensurate with his consumption of electricity, stoppage of
meter, damage to the seal, burning or damage of the meter, etc.

<!-- page 4 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(8)

No test fee shall be charged from the consumer at the time of reporting if the meter is found to be
defective or burnt due to reasons attributable to the consumer, the consumer shall bear the cost of
new meter and test fee shall be charged from the consumer through subsequent bills.

(9)

The distribution licensee shall give a copy of the meter test report to the consumer duly signed by
both the distribution licensee or their authorised representatives and the consumer, and retain one
such copy as acknowledgment. The distribution licensee shall communicate the date and time for
such test to the consumer and convey the said consumer to present at the site for testing. However, if
the consumer chooses not to be present at the site for testing, the distribution licensee will carry out
such testing and shall give the copy of the meter test report to the consumer for signing.

(10)

In case, during testing, the meter is found to be inaccurate, the excess or deficit charges shall be
adjusted in the subsequent bills as specified by the Commission.

(11)

If a consumer disputes the results of testing, the meter shall be tested at a third party testing facility
selected by the consumer from the list of third party testing agencies approved by the Commission.
If it is successfully established that the results of this test are contrary to the results of the test
performed by the distribution licensee, then the cost of undertaking such test shall be borne by the
distribution licensee. However, in case it is established that the results of this test are same as the
results of the test performed by the distribution licensee in sub-rule (7), then the cost of undertaking
such test shall be borne by the Consumer. The meter test results and the meter data shall be issued to
the consumer after such test has been completed and the said results are final and binding on both
the consumer and the distribution licensee.

(12)

The list of third party agencies approved by the Commission shall be available in their various
offices as well as on the website of the distribution licensee.

(13) Replacement of defective or burnt or stolen meters shall be done,-

(a) either on consumer’s complaint or upon inspection by the distribution licensee, if the meter is
prima facie found to be defective or burnt or stolen not due to causes attributable to the
consumer, the licensee shall restore supply through a new meter at its own cost within the
timelines as specified by the Commission;

(b)

if, after investigation, it is found that the meter has become defective or burnt or stolen due
to causes attributable to the consumer, the necessary charges shall be recovered from the
consumer as specified by the Commission;

(c) within a time period, to be specified by the Commission not exceeding twenty-four hours in
urban areas and seventy-two hours in rural areas by the distribution licensee.
(14) Non-availability of meter shall not be a reason for delay in restoration of supply.
(15) If the meter is installed outside the consumer’s premises, distribution licensee shall be responsible for
safe custody of the meter, and if the same is installed within the consumer’s premises, the consumer
shall be responsible for the safe custody of meter.
6.

Billing and payment – (1) Tariff for each category of consumers shall be displayed on distribution
licensee’s website and consumers shall be notified of change in tariff including fuel surcharge and
other charges, a full billing cycle ahead of time, through distribution licensee’s website as well as
through energy bills.

(2)

The distribution licensee shall prepare the bill for every billing cycle based on actual meter reading,
except where pre-payment meters are installed, and the bill shall be delivered to the consumer by
hand or post or courier or e-mail or any other electronic mode at least ten days prior to the due date
of payment.

(3)

In case of non-receipt of original bill, the consumer shall be entitled to get a duplicate copy of the
bill and shall also have the option to deposit self-assessed bill as per the procedure approved by the
Commission:
Provided that the excess or deficit payment, as the case may be in case of self-assessment,
shall be adjusted in the next bill or bills, as the case may be.

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : ऄसाधारण

17

(4)

In case of pre-payment metering, the distribution licensee shall issue the bill, to the consumer, on
his or her request.

(5)

The distribution licensee shall intimate the consumer about despatch of bill through SMS or email,
or by both, SMS and e-mail, immediately and the intimation shall consist of the details of bill
amount and the due date for payment.

(6)

The distribution licensee shall also upload the bill on its website on the day of bill generation:
Provided that the billing details of last one year for all consumers shall also be made
available on the licensee’s website.

(7)

The distribution licensee shall issue the first bill within a time period to be specified by the
Commission, not exceeding two billing cycles, of energising a new connection where post payment
meters are installed.

(8)

In case the consumer does not receive the first bill within such period, he may complain, in writing,
to the distribution licensee and the distribution licensee shall issue the bill within a time period, not
exceeding seven days.

(9)

The distribution licensee shall not generate more than two provisional bills for a consumer during
one financial year and if the provisional billing continues for more than two billing cycles except
under extraordinary situation due to force majeure, the consumer may refuse to pay the dues until bill
is raised by the distribution licensee as per actual meter reading.

(10) If any bill is served with a delay of such period as specified by the Commission, not exceeding sixty
days, the consumers shall be given a rebate of two to five percent as specified by the Commission.
(11) The information regarding the authority with whom grievance or complaint pertaining to bill can be
lodged shall be provided along with the bill and the same shall also be made available on distribution
licensees’ website.
(12) In case of vacation of premises, the distribution licensee shall arrange to take a special reading of the
meter on receiving the consumer’s written request and issue a final bill including all arrears till the
date of billing and issue a No-Dues Certificate on receiving final payment, within a time period not
exceeding seven days from the receipt of such final payment.
7. Method of payment of Bills .- (1) Consumer shall have the option to pay bills online or offline.
(2) Bill amount of more than one thousand rupees or an amount specified by the Commission shall
mandatorily be paid online. Commission shall specify a suitable incentive or rebate for payment through
online system.
(3) For bill amounts less than or equal to one thousand rupees consumer may pay the bill through cash or
cheque or demand draft or electronic clearing system at designated counters of a bank or through credit or
debit cards or online payment through distribution licensees’ web portal or any digital mode of payment
and any change or further addition in the mode of payment shall be more user friendly for the consumers
than the prevailing system.
(4) The distribution licensee shall establish online portal as well as sufficient number of collection centres
or drop boxes at suitable locations with necessary facilities, where consumer can deposit the bill amount
with ease.
8. Advance payment of bills.- (1) In case of post payment meters, when a domestic consumer gives prior
information in writing about his continued absence from residence, the distribution licensee shall not send
any notice or provisional bill to the consumer provided that the consumer pays the fixed charges for such
period in advance and his supply line shall not be disconnected.
(2) Interest shall be paid on advance amount paid under sub-rule (1), at such rate as may be decided by the
Commission.
9. Disconnection and reconnection .- (1) (a) In case a consumer desires that his meter to be permanently
disconnected, he shall apply for the same to the distribution licensee and the licensee shall arrange for a
special meter reading and prepare a final bill.
(b) The disconnection shall be done immediately after payment of the final bill. The balance amount due to
any consumption between the final reading and the permanent disconnection, if any, may be adjusted

<!-- page 6 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

against the security amount with the distribution licensee. The remaining security deposit shall be refunded
to the consumer within such period as specified by the Commission, not exceeding seven days.

(2)

In case the disconnection has been done on account of non-payment of past dues, the licensee shall
reconnect the consumer’s installation within such time as specified by the Commission, not
exceeding six working hours of receipt of past dues and other charges as applicable.

(3)

Pre-payment meters will be designed to automatically cut off supply when the amount credited is
exhausted. This shall however not be treated as a disconnection and the supply will be resumed
whenever the meter is recharged.

10. Reliability of supply.- (1) The distribution licensee shall supply 24x7 power to all consumers.
However, the Commission may specify lower hours of supply for some categories of consumers like
agriculture.

(1) The Commission shall specify the following parameters to maintain the reliability of supply by the
distribution licensee; namely:(a)

total duration and frequency of outages per consumer in a year a. System average interruption duration index (SAIDI);
b. System average interruption frequency index (SAIFI);

(b)

the minimum outage time (in minutes) that the distribution licensee shall consider for the
calculation of SAIDI or SAIFI, as the case may be

(2) The distribution licensee shall put in place a mechanism, preferably with automated tools to the extent
possible, for monitoring and restoring outages.
11. Consumer as prosumer.-(1) While the prosumers will maintain consumer status and have the same
rights as the general consumer, they will also have right to set up Renewable Energy (RE) generation unit
including roof top solar photovoltaic (PV) systems – either by himself or through a service provider.
(2) Renewable Energy (RE) generation unit may also be set up on other part of the premises of the
prosumers, apart from the roof, however the total generation capacity of the RE unit shall not exceed
the limit as specified by the Commission.
(3) The Commission shall lay down regulations on Grid Interactive Roof top Solar PV system and its
related matters with timelines of not exceeding six months from the date of notification of these rules,
in case the same has not been notified.
(4) The regulations on Grid Interactive Roof top Solar PV system and its related matters shall provide for
net metering for loads up to ten kW and for gross metering for loads above ten kW.
(5) The distribution licensee shall facilitate the process for setting up of RE generation system at
prosumers’ premises. In this regard, the licensee shall(a)

create an online portal for receiving applications from prosumers for installation,
interconnection and metering of distributed renewable energy systems or devices at their
premises, and update the same on a regular basis;

(b)

prominently display on its website and in all its offices, the following; namely:(i)

detailed standardized procedure for installation and commissioning of roof top solar
system;

(ii)

a single point of contact to facilitate the consumers in installation of roof top solar
system from submission of application form to commissioning.

(iii)

address and telephone numbers of offices where filled-up application forms can be
submitted;

(iv)

complete list of documents required to be furnished along with such applications;

(v)

applicable charges to be deposited by the applicant;

(vi)

empanelled list of service providers for the benefit of consumers who want to install
roof top solar PV system through service providers; and

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : ऄसाधारण

19

(vii) financial incentives to the prosumers, as applicable under various schemes and
programmes of the Central and State Governments;
(6) The distribution licensee shall ensure that-

(i)

application forms shall be accepted online or through hard copy;

(ii)

in case the application form submitted in hard copy form, the same shall be scanned and
uploaded on the website as soon as it is received and acknowledgement with the
registration number for that application shall be generated and intimated to the
applicant;

(iii)

in case the application form received online through web portal of the distribution
licensee, the acknowledgement with the registration number shall be generated on
submission of application;

(iv)

application shall be deemed to be received on the date of generation of
acknowledgement with registration number; and

(v)

the application tracking mechanism based on the unique registration number shall be
provided by the distribution licensee through web-based application or any other mode
to monitor the status of processing of the application like receipt of application, site
inspection, meter installation and commissioning, etc.

(7)

The technical feasibility study shall be completed within the time period specified by the
Commission, not exceeding twenty days and the outcome of the study shall be intimated to the
applicant.

(8)

During the time period from the feasibility study till the completion of installation, in case, there
is any requirement of upgradation of distribution infrastructure like augmentation of service line,
distribution transformer capacity, etc., for installation of the required capacity of solar PV
system, the same shall be carried out by the distribution licensee or consumer, as the case may
be.

(9)

After installation of solar PV system, the consumer shall submit the installation certificate to the
distribution licensee. The licensee shall complete signing of connection agreement, installation
of meter and successful commissioning of the solar PV system within the timelines specified by
the Commission which shall not be more than thirty days from the date of submission of the
installation certificate. Formats of contract agreement and installation certificate shall be placed
on web-portal of the distribution licensee.

(10)

Consumer shall have the option of purchasing the requisite meter himself which shall be tested
and installed by the distribution licensee.

(11) The timelines as specified by the Commission shall be adhered to by the distribution
licensee. In case of delay, the licensee may take approval from the Commission in specific
cases along with justification for the same.
(12) In case of any delay on the part of distribution licensee without any just cause, the Licensee
shall be liable to pay compensation to the consumer at a rate which shall not be less than
five hundred rupees per day for each day of default.
(13)

The energy generated by prosumer shall be adjusted against energy consumed or the bill amount,
depending on whether net metering or gross metering is applicable.

(14)

The distribution licensee shall pass on the financial incentives to the prosumers, as may be
provided under various schemes and programmes of the Central and State Governments.

12.
Standards of performance .- (1) The Commission shall notify the standards of performance for
the distribution licensees as per sub-section (1) of section 57 of the Act and in consonance with the rules or
regulations made thereunder.
(2) The Commission shall determine the compensation amount to be paid to the consumers by the
distribution licensees for violation of standards of performance as per sub-section (2) of Section 57 of the
Act.

<!-- page 8 -->

20

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

13. Compensation mechanism .- (1) Consumer shall be automatically compensated for those parameters
which can be monitored remotely when it can be successfully established that there is a default in
performance of the distribution licensee.
(2)
The Commission shall notify regulations for establishment of mechanism, by the distribution
licensee, for automatic payment of compensation amount determined under the provisions of sub-section
(2) of section 57 of the Act within six months from the notification of these rules.
(3)
The Commission shall oversee that the distribution licensee designs and maintains its distribution
system in such a way that there is a gradual increase in the list of parameters, which can be monitored
remotely and for which automatic compensation can be made to the consumer.
(4)
The standards of performance for which the compensation is required to be paid by the distribution
licensee include, but are not limited to, the following, namely:(i) no supply to a consumer beyond a particular duration, to be specified by the Commission;
(ii) number of interruptions in supply beyond the limits as specified by the Commission;
(iii) time taken for connection, disconnection, reconnection, shifting;
(iv) time taken for change in consumer category, load;
(v) time taken for change in consumer details;
(vi) time taken for replacement of defective meters;
(vii) time period within which bills are to be served;
(viii) time period of resolving voltage related complaints; and
(ix) bill related complaints.
(5) The distribution licensee, within six months from the date of notification of the regulations by the
Commission under sub-rule (2), shall create an online facility on which consumers may register and
claim the compensation amount. The information in this regard shall be widely circulated among
consumers through appropriate means including mass media, bills, SMS, e-mails or by uploading on
licensee’s website.
(6) In all cases of compensation, the payment of compensation shall be made by adjustment against current
or future bills for supply of electricity, within stipulated time from the determination of claim as
specified by the Commission.
14. Call Centre for Consumer Services .- (1) For providing common services like new connection,
disconnection, reconnection, shifting of connection, change in name and particulars, load change,
replacement of meter, no supply, the distribution licensee shall establish a centralised 24x7 toll-free call
centre with effect from such date as may be specified by the Commission.

(2) While other modes to provide services like paper application, email, mobile, website, etc., may
continue, the licensees shall endeavour to provide all services through a common Customer Relation
Manager (CRM) System to get a unified view of all the services requested, attended and pending, at
the backend for better monitoring and analytics.

(3) The CRM shall have facilities for sms,email alerts, notifications to consumers and officers for events
like receipt of application, completion of service, change in status of application, etc; online status
tracking and auto escalation to higher level, if services are not provided within the specified time
period.
15. Grievance redressal mechanism .- (1) The distribution licensee shall establish Consumer Grievance
Redressal Forum (CGRF) under sub-section (5) of section 42 of the Act at different levels to cater the
needs of the sub- division, division, circle, zone, company level. The forum shall be headed by an
officer of the licensee of appropriate seniority. The forum shall consist of officers of the licensee and
have not more than four members as consumer and prosumer representatives. The Appropriate
Commission shall nominate one independent member who is familiar with the consumer affairs. The
forum may be assigned different types of grievances depending on the nature of the grievance and the
level at which it can be best resolved.

<!-- page 9 -->

[भाग II—खण्ड 3(i)]

भारत का राजपत्र : ऄसाधारण

21

Provided that the manner of appointment and the qualification and experience of the
persons to be appointed as member of the forum and the procedure of dealing with the grievances of
the consumers by the Forum and other similar matters would be as per the guidelines specified by the
Commission.
(2) The licensee shall specify the time within which various types of grievances by the different levels of
the forums are to be resolved. Normally, a grievance shall be decided with in a period of thirty days
and in any case not exceeding forty five days from the date of receipt of such grievance. The
consumer aggrieved by the decision of sub-divisional or divisional or circle forum will have the
option to approach the company level forum before making an appeal to the Ombudsman.
(3)

If a consumer's grievance is not redressed by the company level forum within the specified time or the
consumer is not satisfied with the disposal of his grievance, he will be free to approach the
Ombudsman appointed by the Commission.

(4) The distribution licensee shall give wide publicity of the forum office, its complete address, contact
details and procedure for registration of grievances through print and electronic media and notice
boards of its various offices and also intimate the same to the consumers through electricity bills.

(5) The distribution licensee shall set up a mechanism for monitoring of the grievances redressal.
(6) The licensee will send quarterly reports to the Ombudsman and to the Commission, in respect of
standards of performance, other performance parameters and consumer grievances related information
showing the extent to which the time schedule has been followed in redressing the consumer
grievances.

(7) The performance of CGRF shall be monitored by the Commission.
16. General Provisions.- (1) The distribution licensee shall provide access to various services such as
application submission, monitoring status of application, payment of bills, status of complaints raised
,etc., to consumers through its website,web portal, mobile app and its various designated offices areawise.

(2) The distribution licensee shall provide all services such as application submission, payment of bills,
etc., to senior citizens at their door-steps.

(3) The details of scheduled power outages shall be informed to the consumers. In case of unplanned
outage or fault, immediate intimation shall be given to the consumers through SMS or by any other
electronic mode along with estimated time for restoration. This information shall also be available
in the call center of the distribution licensee.

(4) For creating proper awareness among consumers and licensee staff, the distribution licensee shall
ensure to undertake the following steps, namely:(a) Manual of procedure for providing common services and handling customer grievances
shall be made available for reference of consumers at every office of the distribution
licensee and downloadable from its website
(b) The distribution licensee shall publish the guaranteed standards of performance along with
compensation structure, information on procedure for filing of complaints, in the bills for
month of January and July. If it is not possible to publish the same at the back of the bills,
the distribution licensee shall publish it on a separate hand out and distribute it along with
the bills.
(c) The distribution licensee shall arrange to give due publicity through media, TV,
newspaper, website and by displaying in boards at consumer service related offices to bring
awareness of consumer rights, standards of performance, compensation provisions,
grievance redressal, measures for energy efficiency and any other schemes of the
distribution licensee.
(d) The distribution licensee shall arrange to display feeder wise outage data, efforts made for
minimising outages, prevention of theft or unauthorised use of electricity or tampering,
distress or damage to electrical plant, electric lines or meter and results obtained during the
year, on its website.

<!-- page 10 -->

22

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(e) Whenever the existing meters are to be replaced by any new technology meters, the
distribution licensee shall take adequate measures to create consumer awareness regarding
the advantages of such replacement. Distribution licensee shall issue a public notice in at
least four daily newspapers. Such information shall also be displayed in conspicuous
manner on the distribution licensee’s website and the distribution licensee shall indicate the
area wise schedule of dates for replacement of such meter.
[F. No. 23/05/2020-R&R]
GHANSHYAM PRASAD, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
signed by
and Published by the Controller of Publications, Delhi-110054. MANOJ Digitally
MANOJ KUMAR
KUMAR
VERMA

VERMA
Date: 2020.12.31
22:47:54 +05'30'
