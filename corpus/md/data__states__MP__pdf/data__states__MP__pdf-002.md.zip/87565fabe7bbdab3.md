---
doc_id: "87565fabe7bbdab3"
source_url: "https://collegeholkar.org/iqacdoc/13_IT_PolicyHSC.pdf"
ministry: "Government Holkar (Model, Autonomous) Science College, Indore, Madhya Pradesh"
title: ""
date: ""
pages: 12
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "0f803257482ccb7a"
---

<!-- page 1 -->

कं IT Policy
Govt. Holkar
(Model Autonomous)
Science College,
Indore (M.P.)
— — ५० Lim
| | = ०: .॥॥ ||
Ja @ nll
Il ee ian”
cS Re व a ie ca
" a | रे Version : 2.0

<!-- page 2 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
bY,
पं 9
Dr. Suresh T. Silawat
Principal
Govt. Holkar (Model Autonomous) Science College, Indore
FOREWORD

In the age where Information Technology is making progress by leaps and bounds, we
have devised a dynamic IT policy to provide state-of-the-art education facilities.

Realizing the importance of these systems, Govt. Holkar (Model, Autonomous) Science
College, Indore took initiative in the year 200/ to establish a basic network and IT infrastructure
inthe college campus.

Facilities like online admission, exam results, registrations, submission of various forms,
deposit of fees, etc. are provided to the students. They are not only user friendly and student-
centric but also provide IT facilities to the students.

Our institution also promotes in-house development of such services and has provision
for rewarding its students, faculty, and staff who contribute to the development,
implementation, and execution of the services.

|, as the Head of the Institution, assure each one of you full support in enhancing the
facilities and making use of technology to promote the interest of the students.

Dr. Suresh T. Silawat
Principal
(4)

<!-- page 3 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
| Vision and Mission of the Institute |
Vision:
To make our youth the torch-bearer of knowledge, and to continue the rich
legacy of imparting scientific education and groom them on an intellectual,
social and humane platform.
Mission:
e To create an innovative ecosystem for the promotion of scientific
temperament.
e Toenrich the academics with state-of-the art technology and innovation at
par with the global standards.
e Toimpart Skill-based training relevant to local and global needs.
e Todevelop a well-groomed and empowered youth.
e Tonurture a socially responsible and value-driven generation.
(2)

<!-- page 4 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
POLICY ON INFORMATION TECHNOLOGY (I T)
Content

i. Preamble
2. Scope
3. Objectives
4. Role and responsibility of the Committee
5. Guidelines of IT policy
6. Amendment
7. Publication
8. Important Links
(3)

<!-- page 5 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
POLICY ON INFORMATION TECHNOLOGY (I T)
Nowadays, Internet and intranet systems have become an integral part of
educational institutions. Several online services are made available to the
academic fraternity through these systems. Realizing the importance of these
systems, Govt. Holkar Science College, Indore took initiative in the year 2097 to
establish a basic network and IT infrastructure on the college campus. Thus, an IT

Policy has been designed in such a way, so as to make users aware of the procedures

that are undertaken for managing the network.

Preamble:

This policy document is recognized as the “Policy on Information Technology (IT)” of

the Government Holkar (Model Autonomous) Science College, Indore.

The college makes use of several IT and network support services. The college

communicates to all its stakeholders through email, and webservice. It providesa variety

of technology resources to all its teaching faculty, students, and support staff. All users
are expected to use these resources in an efficient and ethical manner.

In our institution, E-Governance services are made available through the institutional

web portal. These services include online admission, exam results, registrations,

submission of various forms, and deposit of fees. All these services are user and
student-centric.

Govt. Holkar Science College also promotes in-house development of such services

and has provision for rewarding its students, faculty, and staff who contribute to the

development, implementation, and execution of these services.

For the effective use of IT facilities, the following problems are generally encountered in

day to day working:

e The uncontrolled and free web access obstructs the network speed, thus, affecting
quality of work.

e Bandwidth choking due to heavy download.

e When users are given free access to the internet, non-critical repeated downloads
may clog the traffic, resulting in poor quality of service thereby affecting critical users
and application performance.

e Viruses spread very fast over insecure LANs through intranet, and exploits
vulnerabilities of operating systems that may result in data loss or break in service.

(4)

<!-- page 6 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
Scope:
This IT Policy is applicable to—Students, faculty, and staff. The purpose of designing IT
policy is to educate and guide the users and the IT resource administrators on issues
related to the proper and ethical use of Information Technology .According to the policy,
any activity regarding the use of institutional IT facilities, that is illegal or unauthorized will
be considered a breach of the college rules and provisions made in the IT Policy.
Objectives:
i. Tocreate asecure and efficient IT environment.
2. Toprovide internet and network support services.
३. To facilitate communication within the campus and provide study material to the
students.
4. Toidentify unauthorized and malicious activities.
5. To promote paperless work in the office.
Committee:
A committee is constituted for the effective implementation of IT policy, which is as
follows:
4. Chairman: Principal
2. Members:
e 2to3senior faculty members and
e to2technical staff.
Role and Responsibility of the Committee:
{. ITH/Winstallation:
The committee will observe certain precautions while getting their computers or
peripherals installed so that he/she may face minimum inconvenience caused due to
interruption of services or hardware failures. The mandatory steps to be followed at IT
Hardware installation are:
Warranty and Annual Maintenance Contract
All computers purchased by any department should be covered with minimum 3-years
on-site comprehensive warranty. After the expiry of the warranty, the computer must be
covered under an annual maintenance contract.
Power Connections to Computers and Peripherals
All the computers and peripherals should be connected to the electrical point strictly
through UPS or stabilized power supply. Regular check for proper earthing should be
performed by all departments to avoid any hardware damage.Network Cable
(5)

<!-- page 7 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)

Connections

While connecting the computer or peripherals to the network, the connecting

networkcable should be away from any electrical/electronic equipment, as they interfere

with the network communication. Further, no other electrical/electronic equipment

should be shared with the power supply to which the computer and its peripherals are

connected.

File and print sharing

File and print sharing facilities on the computer over the network to be installed onlywhen

it is absolutely required. When files are shared through the network, they should be

protected with passwords and should be in accordance with the access rule.

2. S/Winstallation and licensing:
Any computer purchases made by an individual department must be installed with
necessary licensed software (Operating System, Antivirus, and necessary
application software). Preference will be given to the installation and use of open-
source software products, OS andits updating Single/personal users to make sure
that respective computer systems install updated OS with respective service
packs/patches, particularly with Windows-based OS.The latest service
packs/patches help in fixing bugs and vulnerabilities in the OS that was periodically
detected by Microsoft. Free OS updates are available on theofficialwebsiteof the
company.

Antivirus S/W and its updating

All computer systems used in the college will have anti-virus software installed, andthey

should be active at all times. The single/personal use of a computer system willbe

responsible for keeping the computer system compliant with this virus protectionpolicy.

Backup of Data

Users should perform regular backups of their vital data. Virus infections often destroy

data on an individual's computer. Without proper backups, recovery of destroyed files

may be impossible. At the time of OS installation, it is advised that the computer's hard

disk is partitioned into two volumes typically C and D. OS and other software should be

on the C drive and the user's data files on the D drive.

Guidelines of policy:

4. Unacceptable Use:
Users are prohibited from engaging in any activity that is illegal under local, state,
federal, or international law or is in violation of the college policy. The categories and
lists below are by no means exhaustive, but attempt to provide a framework of
activities that come under the category of unacceptable use.

e Excessive non-priority use of computing resources.

e Unacceptable system and network activities, inappropriate or malicious use of IT

(6)

<!-- page 8 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
systems.
e Misuse of electronic communications.
2. S/Wasset management:

The College follows the policy of using licensed software on its network.

Allpurchased computers use licensed operating systems and tools. Any software

will be purchased either with perpetual licenses or on an annual subscription basis.

The old software must be upgraded with a higher version for enhanced features or

better performance.

3. Green Computing:
College has a commitment to maintain and improve the “Green Ethos” on thecollege
campus. It is a continuous process of review and exploration, of improving
technologies and practices.
The objectives of our core green computing policy are:
e Benefit the environment by conserving resources.
e Reduce e-waste.
e Reduce costs through enhanced efficiency and staff awareness.
e Purchase the green certified peripherals.
e Paperless office-work.
4. Website Hosting Policy:

a. Holkar college has an official website https:/Awww.collegeholkar.org for public
access. Departments have pages on the official website. As of date, the Web
Team at the IT cell is responsible for maintaining the official website of the
institution.

b. Any department or an individual requires to publish any official content on the
college website may send it to the IT cell after getting approval from the
principal. IT cell will facilitate in creating and updating of the content on the
website.

c. College has its Learning Management System (LMS) to cater to the academic
needs ofthe students and faculty as well. LMS is used for the administration,
documentation, tracking, reporting, automation, and delivery of lectures and
study material, and conduction of training programs. The link to the LMS is
https://www.Ims.holkar.org/, This website contains material for general
information purposes only.

5. Database Use Policy

This Policy relates to the databases maintained by the institution administration

under the institution's e-governance. Data is a vital and important Institution

resource for providing useful information. Its use must be protected even when the
(7)

<!-- page 9 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
data may not be confidential. The college has its own policies regarding the creation
of databases and access to information and a more generic policy on data access.
Combined, these policies outline the institution's approach to both the access and
use of this institution's resources. Holkar College is the owner of the data of all the
institutional data generated in the institution.

Individual Sections or departments generate portions of data that constitute the

Institution's database. They may have custodianship responsibilities for portions of

that data.

Here are some general policy guidelines and parameters for Sections, departments,

and administrative unit data users:

4. The institution's data policies do not allow the distribution of data that is
identifiable to a person outside the institution.

2. Data from the Institution's Database including data collected by departments or
individual faculty and staff are for internal institution purposes only.

6. Video Surveillance Policy:

The college has installed a video surveillance system on the campus and various

buildings, with the primary purpose of reducing the threat of crime generally,

protecting the college campus to ensure the safety of staff, students and visitors.

4. The system comprises: Fixed position cameras; Pan Tilt and Zoom cameras;
Monitors: Multiplexers; digital recorders.

2. Cameras will be located at strategic points on the campus, principally at the
entrance and exit points of sites and buildings.

3. Signs will be prominently placed at strategic points and at the entrance and exit
points of the campus to inform staff, students, visitors, and members of the public
thata CCTV/IP Camera installation is in use.

4. Although every effort has been made to ensure maximum effectiveness of the
system it is not possible to guarantee that the system will detect every incident
taking place within the area of coverage.

5. Images captured by the system will be monitored and recorded in the Security
Control Room, "the control room".

6. Digital recordings are made using digital video recorders operating in time-
lapsemode. Incidents may be recorded in real-time.

AMENDMENTS
e The Institute shall examine its “Policy on Information Technology (IT)” on a
regular basis and change it as necessary to comply with national policies and
directives issued by competent apex bodies.
e Pertaining to any contradiction in any Policy of the Institution, the later revised policy
will take precedence.
(8)

<!-- page 10 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
PUBLICATION OF POLICY ON INFORMATION TECHNOLOGY (IT)
The Policy on Information technology shall be widely publicized among the Institute's
stakeholders with all the possible means, as well as prominently displayed on the
Institutional Website to attract the attention of concerned stakeholders.
Important Links:
* https:/Avww.indiacode.nic.in/bitstream/I23456789/376//it_act_2000_updated.pdf
* https://eprocure.gov.in/cppp/rulesandprocs/kbadgkdicswfjdelrquehwuxcfmijmuixngudufgbuu_
bqubfugbububjxcafvsbdihbafGhdfgFHytvhRtMjk4NzY= dec208/orientation.pdf
(9)
