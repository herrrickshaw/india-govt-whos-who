---
doc_id: "a65b74ada5cbda0a"
source_url: "https://www.digialm.com/per/g01/pub/1172/EForms/image/Notification.PDF"
ministry: "Computer Proficiency Certification Test (CPCT), Madhya Pradesh"
title: "Notification/Advertisement"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "fab99b70c9fb4eca"
---

<!-- page 1 -->

aimr, oe.oz.zolg c 14.07.2019
CompurEn PRoRoercy Ce11pqro1

T."I fF[-'

Madhya Pradesh Agency tor Promotion._o, tnrormafion
_Technotogy fi/],
State 1T Center,47-A, Arera Hlll, Bhoprl-462011

EXAM REGISTRATION OPENS

ilAP lT/CPCT/Exam/201I
q.g. er|TFr ERr {a4,rt +.q.rR id enqa?riE cPcT r6i{ {r€
{Er alrln 6 frhs frqrii qii
c{ 6qz?
Frqfra iigFfiil + frq qrqlq qen{{ foqrrr fi o{rhngqR (cpcT +}d c{ sqd*r) {q-{r
6"qar +* d 6q1er su-dr cqpfl-6'{q cfl?n (cpcr) 6r otr ort nc ora qM t t
: 5:tdn{ 2019 d 17 q-drE 2019 ir6,
cfie hfu , 4 BTrrR 2019. {Pd-cR

qr+{i ql { {$q{ s..i fr ftft : i9 wr{ zors i zr q66 2919
a CPCI.!0trr dqa, ift, s-+{, .{Ffic{, iRqF, {T,R, qE{I { rffdhd at wqfi I
a qqffi 6i Stfi d fu cpgr.i*fi wsR fii6 (UtoAt) + Bqr qrt I
a kr urqffii 6,1 oflqR fiqi6 cpcT { q-$-{q cft t, {d cpcT +}d c{ ctiTdrfl Bn+6{ 6.{
qrFrr olrrR fiqi6 q+{< 6flC
a cPcT hqq gft-6r { Gnn { vi{ { grn tq ft+r oc-cer ang ,rg *
a cPcT hqq gR6r i furfiit t d?ifud fr{q csmar 6{ri qq t avr oqo a1 !fu.n et
eirtrc 6r nr6q cpcT +t( cr Jrffq I
a CPCT c0m sq{ft l{qE crT6rftf{-{{q \Ei Rqc gft-6r aqr i{Fn* cfrFBri 6r rfrrf{d
Hs{ CPCT +}d (www.cpct.mp.gov.in) qr srsdr-t
a {d (giginat) rtdgm rr<r+ rd ari qr ff trfte{r #{ ii rilr fr,rtqia * qlg,ft I
a ,iIlqEl id fr or1.n'r (dq.{ qE zrfffh) { fihd rm aFrcFi t
Sqr <a 1On *r 91.:it* \'{ R+ +ri qrcr { esmq +,ftrinffi 6l trSHr t ftq .ar+d-{
ofrdEc e q{+ Eti I 3rr+(6 iflrm .i*{r Mp.ontine *. xiosts t rfi o-r rrcri *
q.s. qqq 9437 6 I 42266t 201 I
.xhP6 {q *rdc'G infusrft
Note : MAPTT tstr iq q ftrS fi Ii!?rI {l CPCT cireM eq :il,rrn {ff Bqr .,ql;
I

r

t

t

r

r

|

arddq aldqq{ {*, wo {Hrfi {qrrr, Ed{

ffio.or

wo riqtq{ q.sd, adl * 3ltnq 6rcH { qrft6 frnq .ri q6 s{ + fuq
,3[tilrnft
org # ffi +Ezic E$Grfrq &zr si trq sc6{qT t qM \,6 s{ iE fucrfufR-d
qr<r t r fqo
,3n+r6 Brr{r *ntie cRrs Frie zo.oz:org ai ac6r 3.00 d;6rqi;
6r{q,€T q-+, qE
dfl?;r dqFr, td< { sqr qr{ (6m t t frF+<r rqa 6.+ rq {qr} +1 ffir
c" or-+ F+qa m
{uva fuqp1 61
rr ?qr qr sntl-+s foqr qr ro-dr t I
cr. dqticq irt ix ga qdr
enftm { aifua +qrr

6tr-

(q{i

*t{!ft mqi +{ t)

.

mrqiqq ir$qq

2:

6lqta{ 6r{qR-{ zi*, c-d dqFr{ Fqpr, sdr
crcifiq 6r{crdm t+, cd Ti€Err TiqFt ra-drq
oqlry 6r{crdr {*, qd Tisnrl riqn, +qq

t

l.

{*, w dsrrrc qvsd, !d{

s. arql-cq ordqmq .i*, re risnn rqrr, {elih

ffarA{qr

I

0l

;

{
0t
OI

?

I

,
