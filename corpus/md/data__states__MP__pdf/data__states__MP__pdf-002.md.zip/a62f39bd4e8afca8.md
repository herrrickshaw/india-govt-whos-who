---
doc_id: "a62f39bd4e8afca8"
source_url: "https://portal.mpcz.in/upload_files/pdf/mperc_regulation/tariff_details/Tariff%20orders/SOP_Visitor.pdf"
ministry: "Madhya Pradesh Madhya Kshetra Vidyut Vitaran Co. Ltd., Bhopal, Madhya Pradesh"
title: "SOP-Visitor"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8dfe5aa0b87eb448"
---

<!-- page 1 -->

Online Appointment by Visitor himself
• Visit website http://mpcz.swagatam.gov.in and register yourself with your
mobile number of email id.
• On registration, the user gets a One-Time Password (OTP) on his / her
Mobile phone. The OTP allows the user to confirm the registration;
• Log in using registration details and select Office and officer with whom
appointment is sought. Also input your preferred slots for date and time;
• The request for meeting is submitted to the concerned officer. The
concerned officer will schedule the appointment based on his
engagements. The visitor gets email and SMS alert on his mobile phone as
soon as the appointment is fixed;
• Visitor logs into the system and prints his Gate Pass;
• Visit the office at the appointed time. The Visitor may kindly take the
entered Digital ID for his / her identification purposes; and
• In the event of change of appointment timing, the Visitor gets SMS and
email alert
Designed by NIC,MPSC,Bhopal

<!-- page 2 -->

Open Swagatam application in any browser using URL
http://mpcz.swagatam.gov.in Below Landing page of Swagatam
will display. Click on Visit Registration

Designed by NIC,MPSC,Bhopal

<!-- page 3 -->

Visitor Registration link

Designed by NIC,MPSC,Bhopal

<!-- page 4 -->

Fill in the visitor’s profile details and click on Next button Duplicate
mobile won’t be register Password must be of 8 characters with one
lower case, one upper case and one special character

Designed by NIC,MPSC,Bhopal

<!-- page 5 -->

Once the registration complete visitor can login using
either using mobile OTP or email with password

Designed by NIC,MPSC,Bhopal

<!-- page 6 -->

As soon as user OTP is verified, user can login in to the
Swagatam application and Visitor Dashboard will be visible .

Designed by NIC,MPSC,Bhopal

<!-- page 7 -->

On home page, click on Apply for Daily Visit Pass
button

Designed by NIC,MPSC,Bhopal

<!-- page 8 -->

1. Fill in the details and submit the form
2. Specify the meeting date and time.
3. User will also receive an acknowledgement message on his/her registered mobile
number.

Designed by NIC,MPSC,Bhopal

<!-- page 9 -->

1. After submission acknowledgement will be Generated,
2. Sms will also sent to Visitor

Designed by NIC,MPSC,Bhopal

<!-- page 10 -->

Visitor Dashboard

Designed by NIC,MPSC,Bhopal

<!-- page 11 -->

Print Visitor Slip

Designed by NIC,MPSC,Bhopal

<!-- page 12 -->

Approved Visitor Pass

Designed by NIC,MPSC,Bhopal

<!-- page 13 -->

Thanks
