---
doc_id: "82dd7bd3e64fde0d"
source_url: "https://sampada.mp.gov.in/public/PDF/part_2.pdf"
ministry: "Directorate of Estates, Madhya Pradesh"
title: "आवास आवंटन संशोधन नियम -Part-II"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3ec80b0fbacbe8b4"
---

<!-- page 1 -->

'.

/

,'
q?Zq.}CT Ylr{r{

r"

rrs
c-\ fsrq|;{t) F{qr-l
{arirq, q6q q31,-qTqld
:: ![I+yi::

qlcrd.Rrio l)/os/zota
qF o1-25l2olszdr-c(s) ,, qlcrfi Rrf, rn!5-6tq 3rriln sTFfs{ F-4IT-2000 n fuc 'd
qyilF{ F{i{ 04.'102013 t qFilVsc qfFI YIrs{ gfl-{ 6$ q}qra p"'o fl'rotq sTrqrq
S ftc trrc*s g@ ffid qq*) a1 st ft-{io 01 3rdqfl zot+ t ftqqqlr
'IEi

Mfta eqar i :-

\

G orfqril o} 3nqff{ eifc:

ers-*t'q s{ffi

?i{rl 'iTltl-{i
+rrs l{'m
fl7rq {Fr{n
lFi'Ti i{{rl
Til[.i
ifiF.i'q al'1i
qs \ d las'{- $

sII Tg

M

srfi-- li*rO | 319[1n :ffiq;

c-{ (fi}q.
q{'Fo i}nrsT
i

ft;r=r jFa,vnr

(1)

(r)

,l

ql

07000

2

t{l

3z4oo+1oooo i€-q qr 3TE-fi

-s)oi

--- ri' '-'
lol

"

'l

3C0'.''l

....-:^.^:--

sl
.1,

\tr'
\II

b

r,,
7 ; .:9{

is-i q'r 3Tft"6

rlor

3soo

1s6oo+6600 tle-t qt srB-fi

1500

3000

so0 |

l sto

37400+B7oo

'!_'*.-.--_.i

15600+s4oo

szDo+z8oo

szoo+1soo

t

,.. _,",-:---:i

I

.:',

l

I

'3{Ig

r'as .tv*nlan L:ltter806

*s-t qr e{Rfi

i

iii
L__

i

---

'

,r(' i

ts-t sT q'ft-o'

i

){) i-- oo,r

I

il
i

:,

!

I Ana r._l

goc'''

I

----r--

I

li

i

'l

*e-t 1II cTR"m

12.'o-

anoo

600i

i

l
I

lc

|

20)

i...-

10C',

<!-- page 2 -->

//277

z. wqtfro'
deTT

{tvq - qrdvrFro sqe-c S s{Ero-FerZ6{q-rfiTvr oi sTnrq sfitfi
sTrsrg

ffi

qfiIal T{

sqltEd enltcs $4 qr

{iF6 qtR-fi f$-iTqr

1

(z)

(3)

(4

1

qI

12000

30000

2

tll

9600

24000

3

7200

18000

4

6000

15000

3600

9000

240Q

6000

1200

3 000

400

1000

5

\t"

6

'ta

\q

I

3.

TrFifq rq slft qtw dqfrdqt a) aqr fs Xa d cr<.lo sTrfl-s

s;rcTq

qgg (Y

Eifu6 qrfrfi Rt{rqT

I

-z

I

^-A\ll

24000

'li

1200

| 600

3000
1000

.\'. .'.,: :\vil:1lirn I.irttcrSl_)?

<!-- page 3 -->

/ /3/ /
crtf, ssrT{ d erB6.rftZddirTtr"r o} cirsr€. 3rF.{
iF.

3flinq

t|tnt.q qY
qikdF qrfk6 fu-rTuT

4"ft
(1

2

I

ql

cq

J

30000

r#

24000

.t

cnsftRfr o) crq dH srd 116 qrsr

4

q-d*awqlfrr,ft

I

18C00
t qnnn

\rtF.
o

\,I I

6000

Ts'

I

2.

'3rd',qlqrm furf, cnqhtq 3flqrcT 3rrq-.q frqq-zooo ti

ft-g rq vri::r

ftlio o<.ro.zors t Tfi-c s-$ d -t t ei-+ (nc*- 01.10.2016) a\ qtz f :,i.:ir) ,"
dErdq gffi (qrR--r fu-irqD FujwT + rsr{uil or ft-rtzFror q{ d rqj.-ro i:;-;r i
srrda &;qi.ad

s.

;

ato ffiTI frqTq A-iT wfi aM d q-or.i rf ftqtra oq e iiii:.:.,r ,,,. ,:
fu"sT qTt &rr$
'r+r+ fu{ffi d nav tqgfi € rrd
4.
srs-frtq ormrq T6 { srftRR MlT old 6Tr\ \n.d o1 fuift ,l d,-;
frqfor frrilT Etgr gqtrrd qTIF+?q er?ns ftFlq at 4e1i ar g,lF*kor
fr-;qr ,.rri,r
3lR irETgR drq-{fc g-tr (qTft6- fr-wer)
or frrfiirr fu-qr qn"{r
5'
fuer gwraq \i-q ll.cT.ffs gg]-d-q lrrt qr irrfldh?.I erov
aei d -"irriir+
q6 ffi{ fr-vrqr) s-r fuwT ff -.JRrT€r{ fu-ql cirdT B
r

r

r

cqq?Tr d qrqqra d'nq +i
Tt-,l] .'rrr)-ytrriqp

-=---"1'/' | V/-l-'i
--",--t
.? /--.+-tt
A-1--A\
1:i:.1tqJi-fl IEqcitl

tq \=|fos

qErlyr :;r:=r
rre l)',.-r,
''

tv '' '' r

..\...xs A\.iuitan Lancr$0S

..

'

<!-- page 4 -->

, / /4/ /
qlq'Ffl' fri-io

y'eioq o-q'iet \s o1-25/2on/A-\O)

ll /os/zot+

qRfrfr:-

r. cqritt {dqcra S qfuq, dqrd
2. q€T+srnn cwnitt r+ft{i FlBc)

3 T6rd-smn.f+sr qd rdE[ff) qqq'irT -flfr'fi/dqtst

4. qgu qRs. qqrtaT wsc, 3s f* 6rqfdq, riTmq-qlqra
5. srEIST. {tvrFr qusa -{fr"fi (cqri{T)
o. gf.,i."'ir, gE 'yrfi€q W<t6fia;fr-')
7. rgs qgq. lwv-i:t frqrq Hqr sR-qriT'q. l1l'Ta

I

3 €Itr elrqtflq, gs sfr-a, qarq-q- q)qld
s. s{i"gffi. qqstcT rr+q. T{ t{d
I

1c. {rr{FI d qqro fr{rrf q. q. I
11. TFrKI RrFrEqeI q. q. I

12 qr{fl s1{Fft{ 3flli.Fi, (qnrq'?vt)
13 fi {t3 fti-enaer(tr"4q-A:T)

14 Tiqlef6, d.{ sd c|€l gqrcrfldq. q. q.*'rd t
15. ri"IFffi. dqer q-qrcrnrdq q. g. qlqra i

io. u.ft11ot tr*. dl5 B=iirT q.g6 E;r{,iE -1, 2 \'q r dcff,
17 ir{F fu"ml fttqr€-q 3rGroT'fi. trqqan i
i3 j.\,,,1 11i{q. T?'.iir :Lqt r{iiGi,{l{ii;t / -{l---'q i :l t\r'l
ft"qnr, d'qra
t

I

*rrr qarrrt qti srr;rsq-.F'

orffi l+g +rilrt-o

t

t

-''-'r-

re--."'r,
//
c_./.
Jl -4-1
sq qFFr

, qgqqtYr vngn, ryd fue.l

q
