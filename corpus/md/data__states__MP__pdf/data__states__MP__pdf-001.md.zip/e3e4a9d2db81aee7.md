---
doc_id: "e3e4a9d2db81aee7"
source_url: "https://www.dauniv.ac.in/adminassets/pdf/10-27-2026_1252pm68081.PDF"
ministry: "Devi Ahilya Vishwavidyalaya, Indore, Madhya Pradesh"
title: "Notification & Abhivachan Letter for M.B.A. (Full Time), MBA (FA), (FT), (MM), (IB) (BE), (HA) III Sem. -2026 Students"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8727d08d671513ad"
---

<!-- page 1 -->

efr 3rF@r Mq-Eqrf,q, {d{
ilro : vfim7wF+c / 2026/ 16 88
7 7atuAa+,7 7
t-fi 3rtr@T mqqrdq, E-dq t q-{q frft-q sqeflE} d sqTRffi qqfrq
(quffir) \qfi.q FT{iRq-d vsFFrriPiq), (sTt{ is), (q-dtu'r n c) (q-<-CrTq-d
d:*i"1, (ffiq E-51qlft-m), qq,fi,q (ffe-d qsfrrc:I{) qqTnq d E-fiq t+qq
qem gq ffiq t+{{{
o1 qfienl qfd qcfq{ zozo d srqrT E\'ft r td fuqrfr ftITftl
qfidfi al scqT qn t 3rBo d-fiT Gr-gd"f t t'E Efiq enTd{ qfte{r d fu erqq B
qq g-{d an Ffiq Q+wq of qfien qRuTl-q d g-+q*r'r (Review) tg 3rTdt{ fuq rrqt
q
qfren
d oeil sm Q-tEsq fr g-qtg"T q-RqH qpq B-tr Eti a1 TeTRIT qfrq enTrq
n qfufud dqr qrsA-t d i-d freT"ft €d-r{ 3Ift-flq qa C rKFq qqq G G-ffq
et qfr d qrer 3fq-i
ti{fl al or-m-qfi at qfr. trfiq e-+w{ g+fta"r (Review) T$-Eqfren
3ififi qa sqfi
s{€rFT d edfr-d o-{cncn{ iqgqRqroq o.rqfdq ti u-rgo o.f f,Ifu
qften
3ffii fro qrqtT of qr. ed t oiF-fl{ {fl sTR|q s.r e}.qr fu ffiq ti\Er
qR"ilq d g+€rer"T q qMq q{ sra Eti et E:ri ii fr tA q-freilffr or qfreil qRuTIq
qfreil n sFqfud E\ {6r d
EiR-d fuqT qri t ut-{ Toio, qlqfffi 5s t B-ftr
t

BqirfirJqTq q-fflr qTK o{i w

qifr fu-qr qr qd-.n

'

fi Memq gr{r tS qqeilffr or qfreil qRqI{

t

sqfDrf, qw1-q t€ qteilRfq) d qftm eil-aq{ qT gsr6 i+
o-rqfaq qfrerr fu}TFr fr uqo dn I
q* a;rro-<
i

*

ffiqurd{

g:l n: qfisr,/FF{n/ zoza\688

tnro 2 I oCI 20?6

qftfuft :q-no ---{dtfl, )fi7F
i. effqn qtqrEfiq E+zrT
B fr n eq eqrfl{ o) 3rc-i dffiq Rt'rTt"Tf{ qt ii rrqqx gcr d sq d ft[tr
erlqR-a of
2. q.qrd qqrfl"d/eqflqrqf, {ffid
t

s-mTRrd o-i

at eN rpnei Yq elrqeqm od-qrfr dg

rpnef iRro
3. qcFf{|t]lel, El-l-O-qfq,
r

4. qrq{f, slQro-rft, eTT{Ft 3Tffi,
5. e-dX-s d wR-+7qd.nfus d F-fr
6. qqqil7rffiq ftqTiT d g1qfi-a T{6Ff.5
7. c.Tffi fu, 3il-$ d.8-€1,
8. qq-fr e-mut qeT
e. Fdtu oer, of dr vgnef q.)-Ro
I

ro. vqffi. T{qrf,q t.oT.ft.fr., E-dl

E/Shiva Rana/A 17 /23\026

(qterr)

w

<!-- page 2 -->

(3rffi q0eTr qR'unq dfud q 6ti of ft€Tfr n sTffis-q t u-qa fuqT qd

t)

/ /efuqqn-qT / /
q @raTwrx or w)

E)wr o-ror7o-rft i tu d sqfr.q quffirq) vq.frq

fr'dT fr

qsftFeqq), Fnq is),

(R-qiq E-or{rfuffi), sq,fr,q. (ffi-d \sfrRy|q)
Frde"T n-Mrc), (wqig|qd
qeftqqmq
q-fterTrfr
2026 qftsr
Efiq
+ Hqffo. sq qfrryfu-d e\ ver,zr-fr Ct +{r T{ qfreTr w.ft.q,
Wffirq) vq.ft.q. luruifru-o qsfrFepTql, lvttt -s), (qrdfrFr nffid), (sq*ismd

ffis),

++si r{q{

d sq n

fr ffid
t

ffin), (ffis wrfrfttr), wfr.q. (ffi.ed wmeqrq) ffi=q t+s{ g+€teru or qRorq
GTft dft.a q-St E il tr fr qe'qq{ o-KrT7ovft (fu qR tt s-ff *ircq d qRqq emffi
saor d Tq qfteTr fr qFqfu'd Eti of sT-fflT TS ell-ft t ai +ft qe qftffir s6; ftEs ffi
qry.ft | {s sqq q q oii terft-o oTffi T€t o-silT7orffi | dsTT vs €EisT fr tt aq ot$
!-il.qN T€t fu-qT qTilfi I gS ffiqqnq oT Fpfq Wh, qrq *.n
t

Osr-r rcrJ

fl-qro-q

3rJfrqrfr---n ,i,
lq-l lcp
I

6E/wdT d rylo, Hqfu-o- ss * sqit.ffi qften q qfufr'f, oqtf

eiofuoTwulFro 3r-o- FqrT$Trr ffi

1qrdq a) 3r-)R-a fu-i urifi

t

r

oqquro-of d uwmq

qfadrlRvro(wteTr+ of tes cTfu-d o-t)

&--

(wr<q5 \'q.fr.qTqoodq d sqqtT *g)
wTd/wrer q-T qrq--

d wfr.q. Tft'q

€i-gmq|6

e+si *rRR zozo of qfteil d qften Grfn{q ve fu ffiq frio frfl fudq go- vr*u
of t unluEn gM cnF-{q{ qa G orar qqr mqqTdq o-rqldq fr q*n o-rfl f,{d .rd d
t

fo{Ftrq sTFrorfr d swrrs
E/Shiva Rana/A 17 /23LO26/70

&'
