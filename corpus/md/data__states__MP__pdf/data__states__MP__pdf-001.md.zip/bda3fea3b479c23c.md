---
doc_id: "bda3fea3b479c23c"
source_url: "https://www.rvskvv.net/images/Vacancies/Advt%2035%20Guidelines.pdf"
ministry: "Rajmata Vijayaraje Scindia Krishi Vishwavidyalaya (RVSKVV), Gwalior, Madhya Pradesh"
title: "Guidelines"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f1f28fe967eac2fc"
---

<!-- page 1 -->

Rajmata Vijayaraje Scindia Krishi Vishwa Vidyalaya, Gwalior (M. P.)
GUIDELINES FOR THE RECRUITMENT PROCESS
Advt No.: IPRO/Reg./RPC/Advt. No. 35th/2026-27/61, Date: 01.06.2026
As per Point No. 4 of the Advertisement and with the approval of the Competent
Authority, the recruitment process for the advertised posts vide Advertisement No.
IPRO/Reg./RPC/Advt. No. 35th/2026-27/61, dated 01.06.2026 shall include following
stages:
1. Eligibility Determination Process (EDP)
2. Competence Evaluation Test (CET)
3. Scorecard-Based Eligibility Determination (SCBED)
4. Interview-Based Evaluation (IBE)
In the first stages, eligibility will be checked primarily and the ineligible applicants
shall not be considered for the next stages of the process. The marks distribution for the
subsequent stages of the recruitment process will be as follows:
Maximum Weightage/
S. No.
Recruitment Stage
Marks
1
Competence Evaluation Test (CET)
40 Marks
2
Scorecard-Based Eligibility Determination (SCBED)
40 Marks
3
Interview-Based Evaluation (IBE)
20 Marks
Total
100 Marks
The detailed procedure for each stage is given below.
1.

ELIGIBILITY DETERMINATION PROCESS (EDP)

1.1 This process will be conducted by the Provisional Eligibility Determination
Committee (PED-C). The committee will conduct a preliminary scrutiny of all
applications for the minimum academic qualifications, age and caste/ category and
other terms and conditions as well as other eligibility criteria/ specified conditions in
the advertisement. Candidates who fail to meet the minimum qualifications,
conditions, or submit the required documents will not be considered for the next
stages.
1.2 During the preliminary screening, if the committee observes that any information
provided by a candidate lacks the required details as per the instructions, or contains
false disclosures, or if any document in the application is found to be incomplete,
untrue, fake, incorrect, defective, or outside the purview of the specified qualifications,
eligibility, or conditions, the committee shall be authorized to declare the said
candidate ineligible and reject their application.
1.3

The list of eligible and ineligible candidates prepared by the committee will be
published on the university website, clearly indicating the reason for the ineligibility
of ineligible candidates. Only the candidates found eligible will be permitted to
participate in the subsequent stage, i.e. the Competence Evaluation Test (CET).

2.

COMPETENCE EVALUATION TEST (CET)

2.1 A Competence Evaluation Test (CET) shall be conducted in this stage. The date, time
and other details of the examination shall be notified on the University website.
The syllabus for this CET has been uploaded on the website.
Guidelines of recruitment - Advt No.35| Page 1 of 4

<!-- page 2 -->

2.2 The candidates will have to pay a fee of Rs 400 + 18% GST for the CET as mentioned
in the point 4(7) of the advertisement. The link for the fee payment shall be available
on the university website from 24.09.2026 to 05.10.2026. If any candidate fails to pay
the required fee, he/she shall not be allowed to appear in the examination and not
considered in subsequent stages.
2.3 Admit cards shall also be made available on the University website/ MP Online portal
before 7 days of the date of CET.
2.4 The CET shall consist of 100 objective-type questions, with one mark for each
question. Accordingly, the CET shall carry a maximum of 100 marks. The duration of
the examination shall be 90 minutes. The syllabus for the CET is available on
university website.
2.5

There shall be a provision for negative marking in the CET. For every incorrect
answer, 0.25 mark (one-fourth mark) shall be deducted. Thus, for every four incorrect
answers, one mark shall be deducted from the marks obtained.

2.6 Minimum qualifying marks in CET are given below:
S. No.
(a)
(b)
(c)
(d)
(e)
(f)

Category
Scheduled Tribe (ST)
Scheduled Caste (SC)
Other Backward Classes (OBC)
Economically Weaker Section (EWS)
Persons with Disabilities (PwD)
Unreserved (UR)

Minimum Qualifying Marks
40%
40%
45%
45%
45%
50%

Qualifying in the CET is mandatory for consideration in the subsequent stages
of the recruitment process.
2.7 It is not mandatory for all candidates declared 'qualified' in the CET to participate in
the subsequent stages. Participation in future stages for qualified candidates will be
governed by the notification dated 14.08.2023. A category-wise merit list of
candidates declared 'qualified' in the CET will be prepared; from this list, a minimum
of three and a maximum of eight meritorious candidates per advertised post will be
selected for the subsequent process. This process will be conducted category-wise for
each advertised post.
For example: If the number of advertised posts in a category is 01 (one), a
maximum of eight candidates will be selected for the next stage. If the number of
advertised posts in a category exceeds by 01 (one), then 03 applicants will be added
in it thus total 11 applicants for the two posts will be selected. Subsequently, for each
additional advertised post, 03 applicant will be added to the count for the next stage.
2.8 If two or more candidates declared 'qualified' in the CET and hold the same marks at
the last position of the category-wise merit list (prepared based on the required number
of posts), all such candidates with equal marks will be included in the merit list and
will be considered for subsequent stage; they will be assigned the same rank and listed
alphabetically by name.
2.9 The marks obtained in the CET shall be converted to a maximum of 40 marks for the
purpose of determining the final merit. The CET marks shall be multiplied by a factor
of 0.40. Example: If a candidate obtains 60 marks out of 100 in the CET, he/she will
receive 60 × 0.40 =24 marks out of 40 for the CET component.
2.10 The result of the Competence Evaluation Test (CET) shall be published on the official
website of the University.
Guidelines of recruitment - Advt No.35| Page 2 of 4

<!-- page 3 -->

3. SCORECARD-BASED ELIGIBILITY DETERMINATION (SCBED)
3.1 The Scorecard-Based Eligibility Determination of the shortlisted candidates will be
conducted by the Scorecard-Based Eligibility Determination Committee (SCBED-C)
on the basis of the prescribed scorecard and the documents submitted by the
candidates.
3.2 The SCBED-C shall perform the following functions:
(i)

To thoroughly re-examine the eligibility of the prescribed number of eligible
candidates' applications, in accordance with the rules specified in Point No.2.7. If
the committee finds any candidate's application to be 'ineligible', it shall be
authorized to reject that application, citing the reason(s) for doing so.

(ii)

The Scorecard-Based Eligibility Determination Committee (SCBED-C) shall
prepare individual scorecards for all these candidates; these shall be kept in a
sealed envelope maintaining strict confidentiality until the interview process is
concluded.

(iii)

The Scorecard-Based Eligibility Determination Committee (SCBED-C) shall also
prepare a summary sheet of the scorecards for all these candidates; this shall be
kept in a sealed envelope maintaining strict confidentiality until the interview
process is concluded.

(iv)

In addition to the above, the Scorecard-Based Eligibility Determination
Committee (SCBED-C) shall prepare a list of all these candidates in alphabetical
order also. Call letters for the interview shall be issued to the candidates based on
this list.

3.3 The SCBED shall carry a maximum of 80 marks on the basis of modal scorecard. The
marks obtained by a candidate shall be converted to a maximum of 40 marks for the
purpose of determining the final merit. The marks obtained in the SCBED shall be
multiplied by a factor of 0.50. Example: If a candidate obtains 50 marks out of 80 in
the SCBED, he/ she will get 50 × 0.50 =25 marks out of 40 for this SCBED
component.
4.

INTERVIEW-BASED EVALUATION (IBE) AND APPOINTMENT

4.1 Based on the alphabetical list prepared by SCBED-C, interview call letters will be
issued to eligible candidates via e-mail and Speed Post at least 07 days prior to the
date of the interview.
4.2 If any discrepancy or false disclosure is observed by the Committee regarding the
documents submitted with the application, a written record shall be prepared, and
action will be taken to exclude the candidate from the interview process in accordance
with the prescribed procedure; furthermore, depending on the gravity of the matter, a
criminal case may be registered against the candidate, and legal action may be
initiated. In the event of cancellation, a cancellation order citing the specific reason
shall be issued to the candidate immediately and an acknowledgment of receipt
obtained from the candidate and kept on record

Guidelines of recruitment - Advt No.35| Page 3 of 4

<!-- page 4 -->

4.3 The Interview-Based Evaluation (IBE) will be conducted by the ‘Interview and
Selection Committee (ISC)’, constituted in accordance with University Statutes. The
Interview-Based Evaluation (IBE) shall carry a maximum of 20 marks.
4.4

The Interview and Selection Committee (ISC) shall evaluate each candidate's
performance in the interview and award marks out of 20. The average of the individual
scores/ marks awarded by the ISC Chairperson and members to determine the final
marks and an ‘Integrated Result Sheet’ will be prepared and signed by the Committee.
Until this process is complete, the candidates' marks obtained in the CET and SCBED,
as well as the previously prepared merit/ ranking list, will not be disclosed to the
Interview and Selection Committee (ISC).

4.5 Once the Integrated Result Sheet has been prepared and signed by all concerned, the
envelope containing the marks from the Competence Evaluation Test (CET) and the
sealed envelope of summary sheet of scores i.e. SCBED will be opened before the
Interview and Selection Committee (ISC). The ISC will then proceed to add these
marks to the interview scores. Before opening of the envelopes, the committee will
sign to verify that the envelopes remain sealed.
4.6 Based on the aforementioned three components, the Interview and Selection
Committee (ISC) will prepare a statement of the candidates' total marks and compile
the final merit list/ ranking of the candidates who appeared for the interview, starting
with the highest total score.
4.7 If the total marks obtained by more than one candidate are found to be equal, priority
shall be accorded as follows:
(a) In the event of a tie in total marks, the older candidate shall be given priority.
(b) If ages are also equal, priority shall be determined based on the marks obtained
according to the model scorecard.
(c) If the marks obtained according to the model scorecard are also equal, priority
shall be determined based on the marks obtained in the qualification/eligibility
examination.
(d) If the marks obtained in the qualification/ eligibility examination are also equal,
priority shall be determined based on the marks secured by the candidates in the
scorecard under the categories of (1) academic qualification, (2) publications, and
(3) work experience, in that order.
4.8 Appointment letters will be issued sequentially to the high-ranking candidates in each
category according to the number of advertised posts based on the final merit
list/ranking, starting from the candidate with the highest marks.
4.9

In all matters relating to the recruitment process, the decision of the Competent
Authority shall be dealt with in accordance with the applicable rules, regulations and
statutory provisions. If any computer or clerical error is found during the selection
process or even after the issuance of results, the University reserves the right to rectify
or withdraw or cancel the process.

******

Guidelines of recruitment - Advt No.35| Page 4 of 4
