---
doc_id: "2d66adebced5ebdc"
source_url: "https://mpkrishi.mp.gov.in/hindisite_New/pdfs/Govt_Order_Transfer_2026_SEC_1_14_AGR.pdf"
ministry: "Farmer Welfare and Agriculture Development Department, Madhya Pradesh"
title: "शासन के निर्देश"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9d5d5abf29f9bbed"
---

<!-- page 1 -->

GhHIC5 1/1/3/O002/2026-sec-1-14(AGR)

rrer, faia 25-5-2026

ufa,

fauy:- q 2026

31GIŞ FTGlGU 3HTàTGH

AIdl

faies 22-5

HEA FYIGGUT 31GIŞA
2/

3/

4/

3rfgeorit/hMutt at 3farid: EHRMS

3İias hT GGI

(31T)

<!-- page 2 -->

//2/7

GhHT5 1/1/3/0002/2026-sec-1-14(AGR)

ufafafu:
1. yey

Hulcs,AI

2. HAlCF fa

3fiac|

6. HĦ yrslll Hl5 31cT HHl

TureT, fich 25-5-2026
