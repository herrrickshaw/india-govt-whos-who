---
doc_id: "5bb8119bf7e6ddba"
source_url: "https://mphousing.in/pdf/GST%20TDS%20Guidline.pdf"
ministry: "M.P. Housing and Infrastructure Development Board, Madhya Pradesh"
title: "G.S.T. Guideline 2019"
date: ""
pages: 19
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "75fe514d89eb1354"
---

<!-- page 1 -->

SEC 51 OF CGST ACT,2017

1

<!-- page 2 -->

INTRODUCTION
TDS under GST will be applicable Under the GST
regime we have the basic 3 kinds of taxes. – CGST,
SGST and IGST. In addition, as per the GST law, certain
categories of registered persons will be required to
deduct taxes while making payments to supplier i.e
TDS and deposit it with the government. Let’s try to
understand TDS related procedures under GST.from
1st October 2018.

2

<!-- page 3 -->

What is TDS under GST?
Tax Deducted at Source (TDS) is one of the ways to
collect tax based on certain percentages on the amount
payable by the receiver on goods/services. The
collected tax is a revenue for the government.

3

<!-- page 4 -->

Who could be liable to deduct TDS under GST
law?
 A department or an establishment of the Central Government or State
Government; or
 Local authority; or- (MPHIDB)
 Governmental agencies; or
 Such persons or category of persons as may be notified by the Government.

As per the latest Notification dated 13th September 2018, the following
entities also need to deduct TDS An authority or a board or any other body which has been set up by Parliament
or a State Legislature or by a government, with 51% equity ( control) owned by
the government.
 A society established by the Central or any State Government or a Local
Authority and the society is registered under the Societies Registration Act,
1860.
 Public sector undertakings.

4

<!-- page 5 -->

When will the liability to deduct TDS be attracted? What is the rate
of TDS?

TDS is to be deducted at the rate of 2 percent on
payments made to the supplier of taxable goods and/or
services, where the total value of such supply, under an
individual contract, exceeds Two Lakh Fifty
Thousand Rupees. No deduction of Tax is required
when the location of supplier and place of supply is
different from the State of the registration of
the recipient.

5

<!-- page 6 -->

No TDS Required

Place of

Supplier

Maharashtra

Place of
Supply

Maharashtra

Place of
Recipient

• Madhya
Pradesh

6

<!-- page 7 -->

TDS Required : IGST@2%

Place of

Supplier

Maharashtra

Place of
Supply

Madhya
Pradesh

Place of
Recipient

• Madhya
Pradesh

7

<!-- page 8 -->

TDS Required : SGST@1% & CGST@1%

Place of

Supplier

Madhya
Pradesh

Place of
Supply

Madhya
Pradesh

Place of
Recipient

• Madhya
Pradesh

8

<!-- page 9 -->

Registration requirements of Deductor ?
A person who is liable to deduct TDS has to
compulsorily register and there is no threshold limit
for this. The registration under GST can be obtained
without PAN and by using the existing Tax Deduction
and Collection Account Number (TAN) issued under
the Income Tax Act. Thus it can be said having TAN is
mandatory.

9

<!-- page 10 -->

When and to whom should the TDS be paid?
TDS shall be paid within 10 days from the end of the
month in which tax is deducted. The payment shall be
made to the appropriate government which means:
 The Central Government in case of the IGST and the
CGST
 The State government in case of the SGST

10

<!-- page 11 -->

What are the provisions relating to the issue of TDS
certificates under the GST law?

As in Income Tax Law, here also the person deducting
tax has to issue the TDS certificate in form GSTR-7A to
the concerned person within 5 days of depositing the
tax to the government. Failure to do so will make the
person liable to pay a late fee of Rs. 100 per day up to
a maximum of Rs. 5000.

11

<!-- page 12 -->

Amount on which GST TDS to be deducted ?

 Amount excluding GST

Basic Amount

CSGTCharged

SGST Charged

Rs.100000

Rs.9000

Rs.9000

Total Bill
Amount
Rs.118000

Hence GST
TDS to be
deducted on
Rs.100000
and not on
Rs.118000

12

<!-- page 13 -->

Which form is required to file the TDS return?
The person deducting tax is required to file a TDS
return in form GSTR-7 within 10 days from the end
of the month. When GSTIN of the unregistered
supplier is not available, their name can be mentioned.
The robustness of the system reflects these filled-in
details in the electronic ledger of the supplier.

13

<!-- page 14 -->

What is the benefit of TDS to the deductee
(Supplier)?

 Automatic reflection in the electronic ledger of the

deductee (supplier)
 Deductee can claim credit in his electronic cash ledger
of this tax deducted and use it for payments of other
taxes.

14

<!-- page 15 -->

How is Refund of TDS possible under GST?
 If any excess amount is deducted and paid to the

government, a refund can be claimed as this is not the
tax amount that the government has a right on.
 However, if the deducted amount is already added to
the electronic cash ledger of the supplier, the amount
so added cannot be got back as a refund by the
deductor. Deductee can claim a refund of tax subject
to refund provisions of the act.

15

<!-- page 16 -->

Accounting Heads to be Operated
At the Time of
Deduction

At the time of Payment
of Tax to Government

Credit HOA

Debit HOA

• 83 24 04- CGST
• 83 24 05- SGST
• 83 24 06- IGST

• 83 24 04- CGST
• 83 24 05- SGST
• 83 24 06- IGST

16

<!-- page 17 -->

Summary of Provision
• Sec. 51 (CGST Act & SGST Act); Sec. 20 (IGST Act).
Relevant Section

When to
Deduct?

Rate at which
Deducted?

Form or Return
to be Furnished?

• The specified class of person* shall be required to deduct tax at source on the
payment made or credited to the supplier. where the total value of supply
under a contract exceed Rs.2,50,000/-excluding GST.

• Intra State: 2% (CGST 1% + SGST 1%) or Inter State: 2% IGST

• Form GSTR – 7

17

<!-- page 18 -->

Due date to
file Return?

Due Date to
Deposit TDS
Under GST with
the Government?

Who is
required to
issue TDS
Certificate?

Form?

• Within 10th of succeeding month.
• Within 10th of succeeding month in which
TDS deducted.
• Deductor (the person who is deducting
tax).
• Form GSTR-7A

18

<!-- page 19 -->

Due Date to
Issue
Certificate?

Late fees if not
issued within
Time??

Who is
required to
issue TDS
Certificate?

When TDS
not to be
Deducted?

• Within 5 days of crediting the amount to the
Government.
• Within 10th of succeeding month in which TDS
deducted.

• Rs.200 per day (Rs.100 CGST + Rs.100 SGST) from the
expiry of the 5th day till the certificate is issued.
• When both the place of supplier as well as the place of
supply are different from that of the place of recipient.

19
