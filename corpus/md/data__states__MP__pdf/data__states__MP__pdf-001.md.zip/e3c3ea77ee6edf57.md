---
doc_id: "e3c3ea77ee6edf57"
source_url: "https://collegeholkar.org/iqacdoc/04_Consultancy_Policy.pdf"
ministry: "Government Holkar (Model, Autonomous) Science College, Indore, Madhya Pradesh"
title: ""
date: ""
pages: 12
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "fb3d72c4c451b060"
---

<!-- page 1 -->

हर seer
Consultancy Policy
NS Holkar
(Model Autonomous)
Science College,
Indore (M.P.)
A
Far | 2 ae 2 @ | A Aaa
i oa ॥ | bibs.
॥#& ४ एड ee ig
ae या

<!-- page 2 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
bY,
कर ?
(
., * ©
i)
Dr. Suresh T. Silawat
Principal
Govt. Holkar (Model, Autonomous) Science College, Indore
FOREWORD
We are pleased to introduce the consultancy policy as per the norms of the Higher
Education Institution. Consultancy primarily refers to "Knowledge Exchange" and makes it
easier to build ties with businesses, the public sector, and other groups. In particular, it
promotes close ties with other educational institutions, governmental and non-governmental
organisations, businesses, the community, and people. This policy document is recognized as
the “Consultancy Policy” of the Government Holkar (Model, Autonomous) Science Institution,
Indore, M.P.

Faculty & staff members of the institution are encouraged to undertake
institution supported consultancy and external work, provided it does not conflict with the
interests of the institution. Consultancy policy will increase the professional and/or academic
competence and experience of the faculty & staff members. Such activities will generate
additional revenue for the faculty & staff members and result in increased funding for the
Institution. This policy is applicable to all faculty & staff members of the institution.

This will create and enhance linkages between the HEI and other organisations/
agencies and aid the institution in areas such as hi-tech research opportunities, student
placements, and help the institution to achieve its mission-of knowledge acquisition and
transfer and thus impacting the local and regional economy in vision with the Goal-8 of the
sustainable Development Goals - 2030.

| express my gratitude to my team for bringing forth a viable consultancy policy
for an enriching experience.

Dr. Suresh T. Silawat
Principal
(4)

<!-- page 3 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
| Vision and Mission of the Institute |
Vision:
To make our youth the torch-bearer of knowledge, and to continue the rich
legacy of imparting scientific education and groom them on an intellectual,
social and humane platform.
Mission :
e To create an innovative ecosystem for the promotion of scientific
temperament.
e Toenrich the academics with state-of-the art technology and innovation at
par with the global standards.
e Toimpart Skill-based training relevant to local and global needs.
e Todevelop a well-groomed and empowered youth.
e Tonurture a socially responsible and value-driven generation.
(2)

<!-- page 4 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
Consultancy Policy
Content
4. Preamble
2. Aims and Objective
3. Formal Frame Work
4. Institution Supported Consultancy
5. Compensation for Institution Supported Consultancy.
6. Reporting
7. Accounting
8. Patent
9. Ambiguity
40. Amendment
44. — Publication
2. Acknowledgment
(3. | Annexures
(3)

<!-- page 5 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
Consultancy Policy

In Higher Education Institutions, consultancy primarily refers to "Knowledge Exchange"

and makes it easier to build ties with businesses, the public sector, and other groups. In

particular, it promotes close ties with other educational institutions, governmental and
non-governmental organisations, businesses, the community, and people.

Preamble:

In terms of teaching-learning approaches, research initiatives, infrastructural facilities,

well established institutions offer their consultation services to others. This policy offers

a well-defined concept line of procedural inputs to the faculty & staff, who want to offer

their services as consultants. The institution serves as an encouraging measure, to

share their expertise and knowledge with other institutions and industries.

This policy document is recognized as the “Consultancy Policy” of the Government

Holkar (Model, Autonomous) Science Institution, Indore, M.P.

Aims & Objective:

Consultancy is an important work through which knowledge and expertise of faculty &

staff members can flow to other external agencies. But without proper policy this work

cannot be implemented in this institution. The Holkar institution authorities recognize the
need and importance of consultancy services for our faculty and faculty & staff members
and institution.

# "Consultancy" refers to the application of existing knowledge; expertise and skills

and includes other activities which are analogous to consultancy activities such as

business partnership or ownership etc.

The major objective of drafting this consultancy policy is to provide guidance regarding:

e Knowledge and expertise sharing with external agencies.

e Developing academic relationship with other institutions and agencies.

e Promoting and facilitating better collaboration with Industries etc.

e Generating revenue for the institution.

Formal Framework:

This policy will guide regarding the implementation of consultancy procedures to be
followed in this institution. Parties engaged in creations of original and innovative work
include faculty, faculty & staff and other employees.

4.. The purpose of this policy is to formulate the principles and procedures governing
consultancy as well as other outside services undertaken by faculty & staff
members of the institution.

(4)

<!-- page 6 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)

a. Faculty & staff members of the institution are encouraged to undertake institution
supported consultancy and external work, provided it does not conflict with the
interests of the institution.

b. Consultancy policy will increase the professional and/or academic competence and
experience of the faculty & staff members and will provide a continuous
professional competency enhancement opportunity in the areas of academics and
research:

c. This will create and enhance linkages between the HE! and other organisations/
agencies and aid the institution in areas such as hi-tech research opportunities,
student placements, and helps the institution to achieve its mission-of knowledge
acquisition and transfer and thus impacting the local and regional economy in vision
with the Goal-8 of the sustainable Development Goals - 2030.

d. Will generate additional revenue for the faculty & staff member and increased
funding for the Institution.

e. This policy is applicable to all faculty & staff members of the institution.
2. Institution Supported Consultancy:
#"Institution Supported Consultancy" means consultancy provided through a
contract entered into by the institution or one of its subsidiaries with a third party, in which
the consultancy will be performed by a faculty & staff member within his or her area of
academic, research or administrative expertise. This consultancy is supported by the
institution and may involve the use of institutional resources, intellectual property and
other appropriate resources.

a. Institution supported consultancy arrangements are only permitted where the work
is distinct from any or other work undertaken on the institution's behalf (in order to
avoid a faculty & staff member competing for contracts with the institution).

b. Afaculty / staff member may only agree to provide institution supported consultancy
services in accordance with terms and conditions approved by the Principal.

c. A maximum of not more than 60 days per year may be devoted to institution
supported consultancy

d. The Principal's approval is required to ensure compliance with cost recovery
guidelines, protection of the institution's IP and the appropriateness of contractual
terms including those relating to liability and IP.

e. Charges for the use of institution resources will normally be based on the full cost of
the resources as determined by the institution/department and agreed by the
faculty & staff member and the Head of the Department.

f. In case the H.O.D. denies a faculty & staff member authorisation to perform the
institution supported consultancy, the faculty & staff member may appeal in writing
to the Principal. The Principal will be the final authority to resolve issues regarding
consultancy and it will be binding for all the parties to abide by it.

(5)

<!-- page 7 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)

g. Institution supported consultancy will not be allowed in the following circumstances
e When the consultancy services are to support projects, such as research

projects, being conducted by the institution.

e When such consultancy would contractually preclude the institution or its faculty
& staff from engaging in other research or other consultancy.

e When the consultancy calls for the rendering of expert opinion/ evidence in
courts of law, arbitrations, or before parliamentary committees, the consultancy
may only be undertaken with permission of the Principal.

h. Faculty/staff member must declare annually in their declaration regarding outside
consultation activity, the number of days spent on institution supported consultancy
services and comply with all relevant institution policies such as those governing
conflicts of interest or intellectual property.

Compensation for Institution Supported Consultancy:

A. Cost of consultants’ time including intellectual fee:

i. Institution 20%

ii. Department 20%

iii, Principal Consultant 60%

B. Expenses other than above charges will include-

a. Travelling expenses and allowance

b. Equipments

c. Stationary

d. Charges towards analysis/testing from outside agency

e. Supporting faculty & staff

f. Contingency etc.

g. Service tax etc. ifany.

Reporting:

Faculty & staff members must report their consultancy and outside services to their

H.O.D. and Principal annually, and to the extent required, make disclosures required by

the conflicts of interest policy or declaration of outside interests.

Accounting:

For this consultancy charges shall be applicable as per institution's financial procedure

(6)

<!-- page 8 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
the consultancy amount/charges will be deposited in the account of the Principal and he
shall be authorized to release the funds for the expenditure during and after the
consultancy period.

Patent:
Out of the sales made for a patent emerging from consultancy work, an annual royalty
will be divided equally between the principal consultant and the institution.
Ambiguity:
In case of any ambiguity, the decision taken by the Principal shall be final.
Amendments
e Thelnstitute shall examine its “Consultancy Policy” on a regular basis and change it
as and when necessary complying with the institutional policies and directives.
e Pertaining to any contradiction in any Policy of the Institution, the later revised policy
willtake precedence.
Publication of Consultancy Policy
The Consultancy Policy shall be widely publicized among the Institute's stakeholders
with all the possible means, as well as prominently displayed on the Institutional Website
to attract the attention of concerned stakeholders.
(7)

<!-- page 9 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
ACKNOWLEDGEMENTS
Adocument on “Consultancy Policy” has been drafted under the guidance of an Expert
Committtee: Dr. R. C. Dixit (Convener), Dr. S. K. Choure (Member), Dr. N. Kaurav
(Member), Ms. Nirmala Katare (Staff member), Mr. Dinesh Nagar (Staff Member), Ms.
Roshni Chadar (Student member), Sahil Chouksey (Student Member).
IQAC acknowledges Dr. Suresh T. Silawat (Principal), Dr. 5.0. Gupta (Vice-principal),
Dr. R.C. Dixit (Administrative Officer) and all the Head of the Departments for their
guidance and extensive support during the preparation of this document. We also thank
Dr. Swagata Gupta (Master Facilitator) for her valuable inputs during the draft
preparation and Dr. Kanta Mulchandani for her meticulous proof reading of the policy
draft. IQAC also thanks Mr. Bhagwan Suman and Mr. Ankiteshwar Shukla for their
compiling assistance. All the other members of IQAC also need a special mention for
their suggestions and guidance during the preparation of the policy.
IQAC acknowledges and appreciates the earnest efforts made by the Expert Committee
and all others in preparing this document.
Dr. Bijendra Rai Dr. Nagesh Dagaonkar
Coordinator, NAAC Coordinator, |QAC.
(8)

<!-- page 10 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
ANNEXURE -I
Consultant Certificate
4. Certified that this consultancy assignment shall not clash with my teaching in the
department or any other official duty at the institution.
2. Thatthe interest of my department/institution shall not suffer.
3. That the duration of my total consultancy works in a calendar year shall not exceed
more than 60 days (60 days in a calendar year, including holidays).
4. That the total annual income of my all consultancy work shall not exceed my total
emoluments for six months in the calendar year.
(Consultant's Signature)
NAM? ..............--------------००००--०००००००-०-०--
छ69ं9ाधा0णा:..............----०-००० ० "त््न्ज-_-"--«
छए0७7शागशाए:........ . ००००० ०० त्त््>्न्ननन ५५
Address (Office) (Residence)
Head of the Department's Recommendations:
(Principal)
Signature with official stamp
(9)
