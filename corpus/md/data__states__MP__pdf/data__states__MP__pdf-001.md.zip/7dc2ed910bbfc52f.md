---
doc_id: "7dc2ed910bbfc52f"
source_url: "https://sscmpr.gov.in/newlook/downloads/noticeboard/CorringendumMP11626_13072026.pdf"
ministry: "Staff Selection Commission (SSC), Madhya Pradesh Region"
title: "चयन पद परीक्षा, फेज-XIV-2026, पोस्ट कोड एमपी11626 ई.सी.जी. तकनीशियन(कनिष्ठ) हेतु सुद्धिपत्र       Corrigendum for the post of E.C.G. Technician (Junior) Post Code MP11626 under Selection Post Examination, Phase-XIV/2026."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c230a5695bc23834"
---

<!-- page 1 -->




फाइऱ संख्या- 4/1/2026-SP/Exam-II(MPR)
भारत सरकार

कर्मचारी चयन आयोग
(र्ध्य प्रदे श क्षेत्र)

कार्र्मक ऱोक र्शकायत एवं पेंशन र्ंत्राऱय,

5 वाa ताऱ, र्नवेश भवन, एऱआईसी पररसर-2

ददनांक- 13/07/2026
Government of India
STAFF SELECTION COMMISSION (MPR)
M/o-Personnel, Public Grievances & Pensions
5th Floor, Investment Building, LIC Campus-2,
Pandri, Raipur (C.G.)-492 004
Phone-2960440/41/42

पंडरी, रायपुर, छत्तीसगढ़- 492004
------------------------------------------------------------------------------------------------------------------------------------------

CORRIGENDUM
In continuation of the Notice of Selection Posts Examination, PhaseXIV/2026, it is hereby informed to all the concerned candidates that the Pay Level
prescribed for the concerned post(s) was inadvertently mentioned as Pay Level-5.
Now, as per the revised RR and request as received from the User Department,
the Pay Level for the said post(s) may be read as Level-4 instead of Level-5.
Accordingly, all candidates are advised to take note of the above correction. All
other terms and conditions of the Notice shall remain unchanged.
Details:Post Name: ECG Technician (Junior)
Post Code MP11626
User Department: Central Government Health Scheme, New Delhi

This has the approval of the competent authority.
SSC, MPR Raipur
