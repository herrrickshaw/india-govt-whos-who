---
doc_id: "afe2b5f5e0fd39d6"
source_url: "https://www.mppmcl.com/_files/ugd/3be482_034382cf1bcd41a6bace43ea10a5472f.pdf"
ministry: "M.P. Power Management Company Limited, Jabalpur, Madhya Pradesh"
title: "Inter Company Transfer"
date: ""
pages: 64
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d54d27a9726cfc91"
---

<!-- page 1 -->

TENTATIVE CONSOLIDATED LIST OF PERSONS, WHO HAVE EXERCISED THE OPTIONS/REPRESENTATIONS FOR THE COMPANIES IN ORDER OF PREFERENCE
CIRCULAR NO.01-07/Convenor-AC/5110-5111 DATED 13-9-2011
Order of Preference
SN
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35

NAME (S/Shri/Smt.)
B. P.Shrivastava
B.L.Newal
Shirish Kumar Shah
Sudama Prasad Soni
Vijendra Nanavati
Rajiv Shrivastava
Ashok Kumar Saxena
Raju Dehariya
Pradeep Kumar Singh
Arvind Kumar Kulshrestha
Prem Singh Tekam
Kailash Singh Rajput
Anil Kumar Agrawal
Munavver Ibrahim
Shrayansh Raja Nahar
Suresh Kumar Khiani
Prabhakar A.R.Bende
Naresh Kumar Jain
Shivaji Choudhary
Mansingh Dixit
Shubhash Gajendra Gadkar
Vinod Kumar Kaithwar
Laxman Das
Vinod Kumar Kailasia
Sanjay Pendore
Yashwant Kumar Shilpkar
P.C. Nimare
Ravindra Dwivedi
Som Deo Singh
Markandey Sharma
Sanjay K. Bhagwatkar
S. L. Karwadiya
Prahlad Gupta
Swami Prasad
Shrikant Jahagirdar

Employee
Number
82972777
93111283
85052131
89970139
91116102
82974369
91393569
89410251
82976737
82978204
90530410
90586024
82971530
89324915
82975093
82973387
82971837

85053089
82979368
92036630
94340303
90290874
93420213
89324949
82971529
92430510
94470042
93421475
93420295
94340583

Designation
CE (T&D)
CE (Gen)
CE (Gen)
CE (Gen)
CE (Gen)
C E (Civil)
ADDl.CE (T&D)
ADDl.CE (T&D)
ADDl.CE (T&D)
ADDl.CE (T&D)
ADDl.CE (T&D)
ADDl.CE (T&D)
ADDl.CE (T&D)
ADDl.CE (T&D)
ADDL CE (Gen)
ADDL CE (Gen)
ADDL CE (Gen)
ADDL CE (Gen)
ADDL CE (Gen)
ADDL CE (Gen)
ADDL CE (Gen)
ADDL CE (Gen)
ADDL CE (Gen)
ADDL CE (Gen)
ADDL.CE (Civil)
ADDL.CE (Civil)
ADDL.CE (Civil)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)

Place of Posting
CE (W&P), EZ, JBP
CE(Gen),SSTPP,Khandwa
ED (MM)Genco,JBP
ED (Engg), Jabalpur
CE (R&M),Genco,JBP
ADDL. SECRETARY (P)-I
CE(JR), EZ, Jabalpur
CMD (CZ), Bhopal
CE (Comm) EZ, JBP
Chief (Vig.), EZ, JBP
Addl.Secy.EZ,JBP
CMD (CZ), Bhopal
CE(ADB-RAPDRP), EZ, JBP
CE(W&P), EZ, JBP
CE(PRG)Genco, JBP
ED(HR& Admn.), Genco JBP
CE(LD), Genco,JBP
ED (O&M)Gen. JBP.
ED (O&M)Gen. JBP.
CE(PRG)Genco, JBP
THP, Sirmour, Rewa
SGTPS, Birsinghpur
Addl CE (O&M)I,Birsinghpur
STPS, Genco, Sarni
CE (GR)Gwalior
CE (RR) Rewa
SSTPP,Khandwa
ED (T&P), Transco, Jabalpur.
City Circle, CZ, Bhopal
CE (W&P), EZ, JBP
CE(JR), EZ, JBP
SE(O&M) Circle,CZ, Rajgarh
CE (RR) Rewa
Addl. Secy. (EZ), JBP
CE (RR) EZ, Rewa

Present
Company /
MPSEB
EZ
Genco
Genco
Genco
Genco
MPSEB
EZ
CZ
EZ
EZ
EZ
CZ
EZ
EZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
CZ
EZ
Genco
Transco
CZ
EZ
EZ
CZ
EZ
EZ
EZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Transco
Transco
Tradeco
Transco
CZ
Tradeco
Transco
Tradeco
Transco
Transco
Tradeco
Transco
Transco
Tradeco
Transco
Tradeco
Tradeco
Transco
Tradeco
Transco
Tradeco
Transco
Genco
Genco
Transco
Tradeco
Tradeco
Transco
Transco
WZ
WZ
CZ
WZ

--------

----------------------Genco
CZ
----CZ
Transco
------

-----------------------------Transco
------

------

CZ
Tradeco
-Tradeco
Tradeco
Transco
--Transco
Tradeco
Transco
Transco
-Transco
CZ
Transco
Tradeco
-Transco
--Transco
Transco
Tradeco
-----

-----------------------Transco
------

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
----No
No
No
No
Yes
No
Yes
No
Yes
No
No
No
No
No
Yes
Yes
Yes
No
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
No
No
Yes
Yes
Yes
No
----Yes
Yes
YES
NO
Yes
No
Yes
Yes
Yes
Yes
---------

<!-- page 2 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73

Nishikant-V. Bhagwat
Awadhesh Kumar Verma
M. P. Chincholkar
D. G. Dandvate
W. P. Malviya
Bhikam Singh
Devendra Kumar
F K Meshram
Mahesh Kumar Nanhariya
A. K. Meshram
Suryabali
Anoop Kumar Shrivastava
Sudhir Kumar Saxena
Shiv Kumar Sharma
Hemant Kumar Pathak
Mrinmay Kanti Majumdar
Rakesh Dayal Saxena
Jaidev Mukherjee
P.K. Nema
R.P. Pandey
Prateesh Kumar Dubey
Saraj Chauhan
Suresh Baribe
Avinash Kumar Muley
Prakash Chandra Soni
S K Jain
Anil Kumar Sharma
B K Soni
HS Namdeo
Shriram Dhade
Anworul Haque Rizvi
Rajeev Shrivastava
S M Solapurkar
J L Dixit
Vinod Bhoware
Anand Kumar Tiwari
S K Mishra
H K Waikar

Employee
Number
93420634
93460044
82976638
93421582
90530279
93421889
92384244
90587568
94340667
91453108

82977511
85050598
85052149
82978170
82970888
82979319
91014199
85052016
91117745
92054963
82974831
91115625
91112119
82978733
85050714
89042427
85053162
89971947
89970304
88037147
82977801
89970584
91055060

Designation
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
S.E. (T&D)
SE (T&D)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)

Place of Posting
SE (O&M), EZ, Tikamgarh
(O&M) Dn Agar
CMD (CZ), Bhopal.
CE (T&C) JBP.
ED (HRD) JBP
(STM) Dn Dhar
CE(SR), EZ, JBP
CE (BR), Bhopal
MTRU, Jabalpur
CE(JR), EZ, JBP
CGM (Sectt), Jabalpur
CZ Bhopal
CE (Corp. Service), , JBP.
OSD (R.O.), Tradeco, Bhopal.
STPS, Genco, Sarni
CE(PRG), Genco,JBP
GM(IPC) Genco, Jabalpur
CE (PRG), Genco, JBP
CE (PRG), Genco, JBP
SE(O&M), Silpara, Rewa
CE(PRG), Genco,JBP
CE(Gen),SSTPP,Khandwa
SE(MM)-I, Sarni
ED (Engg), Jabalpur
ED (Engg), Jabalpur
ED (Engg), Jabalpur
ED (Engg), Jabalpur
ED (Engg), Jabalpur
CE (O&M)Hydel,JBP
SGTPS, Birsinghpur
SE (MM)III,Birsinghpur
Addl CE (O&M)I,Birsinghpur
SGTPS, Birsinghpur
CE (R&M),Genco,JBP
CE (R&M),Genco,JBP
CE (R&M),Genco,JBP
CE (Gen.Stores),JBP
STPS, Genco, Sarni

Present
Company /
MPSEB
EZ
WZ
CZ
Transco
Transco
WZ
EZ
CZ
EZ
EZ
Tradeco
CZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

WZ
CZ
Tradeco
WZ
EZ
Transco
CZ
Tradeco
Transco
Transco
Transco
Tradeco
Transco
Tradeco
Tradeco
Transco
Tradeco
Transco
Transco
Tradeco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Transco

--Transco
----Transco
---Transco
Transco
Transco
Transco
-Transco
--Transco
--Transco
--------Tradeco
-Transco
Transco
----

---

---

---

CZ

EZ

WZ

---------Transco
------------------Genco
-------

---------Transco
--------------------------

---------Transco
--------------------------

Option
Option
for
for
personal Associati
hearing on/ Union
------------Yes
No
Yes
Yes
No
No
No
No
No
No
Yes
No
----Yes
Yes
Yes
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
No
Yes
Yes
Yes
Yes
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes

<!-- page 3 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

74
75
76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
94
95
96
97
98
99
100
101
102
103
104
105
106
107
108
109
110
111

Kailash Kumar Jain
Rajendra Kumar Markam
Shailendra Kumar Pandey
S R gadhewal
Ashish Kumar Chakrawarty
N. K. Saxena
Hemraj Singh Thakur
AK Pathak
Harsh Wardhan Vyas
Mukul Beotra
Prakash Kumar Chaturvedi
Bhushan M Lele
Sant Charan Sahu
R. K. Chopra
O. L. Bamaniya
S. C. Sagar
Sunil Deshpande
Santosh Kumar Gupta
N. R. Goyal
N. R. Binjhare
Ajay Kumar Apte
S.K. Tiwari
S.S.Yadav
S K Pandey
Akhilesh Kumar Agrawal
R. K. Khendelwal
Abhay Khare
Dhiraj Kumar Muniya
Lalit Kumar Soneji
Sadhana Dixit
Anil Saxena
Shyam Sunder Dubey
Rajesh Kumar Jain
Shibu Samuel
R. P. Patel
Manoj Kumar Kori
S. S. Agrawal
M. G. Sharma

Employee
Number
85052024
92300077
85051407
85051902
85050110
82978667
82973973
82979335
82978428
82970020
82974336
91520584
91558907
89973547
93971099
89971906
91459534
82979657
90337808
91392901
82971358
92580033
84618899
90340447
87427017
88443567
89539950
92478989
93421616
94340492
89442683
89569577
89413304
82974526
84479664

Designation
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Gen)
SE (Civil)
SE (Civil)
SE (Civil)
SE (Civil)
SE (Civil)
SE (Civil)
SE (Civil)
SE (Civil)
SE (Civil)
SE (Civil)
SE (Civil)
SE (Civil)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)

Place of Posting
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
(O&M)-I, Genco, Sarni
ED (MM)Genco,JBP
ED (MM)Genco,JBP
ED (O&M)Gen. JBP.
ED (O&M)Gen. JBP.
ED (O&M)Gen. JBP.
Genco, Jabalpur
Deputation to MPRRDA, BPL
Addl. Secy. EZ, Jabalpur
CE (UR), WZ, Ujjain.
SE (Civil) Circle Sagar
CMD (CZ), Bhopal.
CE (JR), East Zone, JBP
CE (C ) P&D-Proj.,JBP
SE (O&M)CircleBhopal
SGTPS, Birsinghpur
CE(Gen),SSTPP,Khandwa
SE(Civil) C&M, Sarni
EZ JBP
CE(W&P) EZ, JBP
ED (Trans). JBP.
Addl. Secy., MPPKVVCL, JBP
CGM (R.O.) MPPTCL, Bhopal
EE (City) Dn., EZ, Rewa
Addl. Secy. (EZ), JBP
EE (O&M) Dn Mehidpur
EE(O&M) Dn Harda
Corporate Office, EZ, JBP
EE (T) Dn.-IIJBP
SE (EHT-Maint.)Trancso. JBP
SE (O&M) Circle Betul.
ED (Liaison ) Tradeco, Bhopal
EE (O&M) Dn Ujjain

Present
Company /
MPSEB
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
CZ
EZ
WZ
EZ
CZ
EZ
Genco
CZ
Genco
Genco
Genco
EZ
EZ
Transco
EZ
WZ
EZ
EZ
WZ
CZ
EZ
Transco
Transco
CZ
Tradeco
WZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
Genco
Genco
Transco
Genco
WZ
Transco
Transco
CZ
Tradeco
Transco
Transco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
WZ
CZ
Transco
Tradeco
Transco
EZ
EZ
Transco
Tradeco
Transco

Transco
-Tradeco
-Tradeco
Tradeco
--Tradeco
Transco
Transco
Transco
Transco
-Genco
Transco
Genco
Genco
-EZ
Transco
-Tradeco
Transco
--Tradeco
WZ
-Tradeco
-Transco
--Transco
-EZ
--

-----Genco
------CZ
--CZ
Transco
WZ
-Genco
Genco
-----EZ
CZ
-Transco
-WZ
----Transco
--

-------------

-------------

WZ
---Tradeco
CZ
-Transco
------WZ
Transco
-WZ
-CZ
----CZ
--

EZ
---CZ
Tradeco
-WZ
------CZ
EZ
--------WZ
--

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
Yes
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
----------------No
No
Yes
Yes
No
No
Yes
No
-----------------------------

<!-- page 4 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
135
136
137
138
139
140
141
142
143
144
145
146
147
148
149

Madhulika R. Badlani
Sampurnanand Shukla
Chandramani Prasad Singh
K. M. Singhal
Kishore K Khattar
Santosh Kumar Gupta
B. L. Warkade
Rajiv Kumar Gupta
Dr. A. P. Varma
Dinesh Shakyawar
T. D. Dwivedi
A. K. Tiwari
Deepa Sapre
SS Sapre
Praveen Kumar Jain
Anand Tiwari
Satish Kumar Sinha
Surendra Kumar Gupta
B.S.Kaurava
Prem Singh Chouhan
Sanjay Kumar Nema
Basant Kumar Jhariya
M.S. Pachori
Ajay Kumar Mangal
Santosh Kumar Mishra
R.H.Verma
Yadaorao Mandalekar
Sanjay Kumar Okhade
Shishir K. Shrivastava
A. G. Deole
Shailendra Janardan
Amit Khare
Ramnaresh Singh Thakur
Ravindra Kumar Sahu
Muni Deo Sharma
Deepak Kumar Vyas
Surendra Kumar Solanki
Ashok Kumar Tiwari

Employee
Number
89970163
89569394
89611270
90610600
93420832
89432510
91531771
92353000
93325932
95470025
89569379
91552322
82975367
82974856
89972416
82975887
90441716
93410239
92430718
91456458
89433104
92572279
93325981
91395011
93972634
91558824
89971161
92353992
91453198
89410532
90441948
91552545
89970238
92360336
90530535

Designation
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)

Place of Posting
SE (AMR) Jabalpur.
SE (AMR) Jabalpur
EE (O&M) Dn Sausar
EE (MT) Dn Ujjain.
SE (EHT) Transco, Indore
EE(O&M) Dn. Waraseoni
EE (STM) Dn Seoni
EE (O&M) Dn Shahdol
CMDBhopal
EE (STM) Dn Chhindwara
SE(O&M) Chhindwara
EE (Store ) Satna
CE (RR) Rewa
EZ, Jabalpur
CE (Comml-EZ), JBP.
CE(O&M-Pur),EZ,JBP
Corporate Office (WZ), Indore
EE (STC)DnChhindwara
ED(Trans.),JBP.
CE (IR), WZ, Indore.
Rajgarh Dn.
SE(O&M) CircleBhopal
CGM(BR)Bhopal
EE, O&M Dn., Dabra
EE,Area Stores,JBP.
EE(City) East Dn., Gwalior
EE (O&M) Dn., CZ, Narsinghgarh
CE(Comm.), EZ,JBP
STC (O&M) Dn., EZ, JBP
CE(GR), CZ, Gwalior
CE(FS) EZ, JBP
CMD (CZ), Bhopal
CMD (CZ), Bhopal
CE(O&M-P), EZ, JBP
EE(O&M) Dn. Lahar, CZ
On deputation MPERC,Bhopal
EE (O&M) Dn, WZ, Tarana
Corporate Office EZ,JBP

Present
Company /
MPSEB
EZ
EZ
EZ
WZ
Transco
EZ
EZ
EZ
CZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
WZ
EZ
Transco
WZ
CZ
CZ
CZ
CZ
EZ
CZ
CZ
EZ
EZ
CZ
EZ
CZ
CZ
EZ
CZ
Transco
WZ
EZ

Pref-1
Transco
CZ
Tradeco
Transco
WZ
Transco
Transco
Tradeco
CZ
Transco
Transco
Transco
EZ
-Tradeco
Transco
Tradeco
CZ
Tradeco
WZ
Tradeco
CZ
Tradeco
Transco
Transco
Transco
Genco
Tradeco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
Transco
Tradeco

Pref-2
EZ
-Transco
WZ
-Genco
-Transco
-WZ
EZ
----Tradeco
WZ
--CZ
Tradeco
-CZ
Tradeco
Transco
-Transco
-Tradeco
Transco
--Tradeco
-Transco
Transco
---

Pref-3

Pref-4

Pref-5

Tradeco
-EZ
--EZ
----WZ
--------EZ
Transco
-WZ
WZ
Transco
---EZ
---Transco
-Transco
----

-------------------Transco
Transco
-EZ
EZ
Transco
-------WZ
-Transco
----

-------------------Genco
---Genco
Transco
-------CZ
-Transco
----

Option
Option
for
for
personal Associati
hearing on/ Union
----------------------------------------------No
No
Yes
Yes
No
No
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
Yes
No
Yes
Yes
Yes
No
No
No

<!-- page 5 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

150
151
152
153
154
155
156
157
158
159
160
161
162
163
164
165
166
167
168
169
170
171
172
173
174
175
176
177
178
179
180
181
182
183
184
185
186
187

K. D. Chaturvedi
Anil Kumar Agrawal
R. K. Thukral
Girdhari Lal Pandey
N. K. Jain
Sanjay Nihalani
B. K. Sharma
R. K. Sthapak
Parmanand Mishra
Premsheel Bhatnagar
Arvind Kumar Sharma
Naveen Pandey
Ashish Kumar Shukla
Pyush Kumar Hajela
V. K. S. Parihar
Pradeep Choudhary
Prem Prakash Sahu
Sunil Kumar Khare
Sheetal Kumar Jain
Rajesh Kumar Shrivastava
Deo Prakash Singh
Sewak Ram Yemde
Smt. Babita Gajhbiye
G.P.Singh
Prakesh Kumar Dubey
A. K.Shrivastava
V S Pani
Rajesh Kumar Sharma
Shriram Pandey
Santosh Kumar Mulmule
Asha Ram Verma
Aradhana Shrivastava
Amar Singh
Shriram Soni
Sanjay Solanki
Umesh Jain
S. K. Giriya
Ashish Patel

Employee
Number
87432132
82976786
93326047
90310184
90530568
93325917
90483817
94340527
82972165
88438278
91552347
91531243
94230394
83397957
91558948
93327004
85393055
93326542
93325610
89324881
89569485
94340534
93020070
89569411
89972706
89973760
90310367
89431348
90310425
90310242
82975219
90440585
85250164
92580703
91558956
91570754
85052818

Designation
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)

Place of Posting
CE ( LD),Transco,JBP
CE (O&M-Pur), EZ, JBP
SE(O&M) CZ, Bhopal
CE(Comm) EZ, JBP
EE(MT) Dn., EZ, JBP
SE (City) Cir. CZ,Bhopal
LMTC (EZ), Katni
EE(O&M) Dn, EZ, Balaghat
CE(Comm) EZ, JBP
CE (W&P), EZ, JBP
EE (EHT) Cons. Dn.Transco, Gwalior
EE(STC), EZ, Rewa
EE (STM) Dn., EZ, JBP
EE ( Central City). Dn., CZ, Gwalior
CMD, CZ, Bhopal.
SE(O&M), CZ, Hoshangabad
SE(O&M), CZ, Hoshangabad
CMD, CZ, Bhopal
SE(City) CZ, Bhopal
CE( BR) CZ, Bhopal
CMD, CZ, Bhopal
CE(RAPDRP), EZ, JBP
CE(JR), EZ, JBP
SE(O&M), EZ, Rewa
CE (O&M-Pur) JBP
EE(O&M) Dn, CZ, Sihore
City Dn.(N),JBP
SE (AMR),EZ,JBP
EE(O&M) N. Dn. EZ,Rewa
CE (T&C), JBP
SE(O&M), EZ, Rewa
CE(Comm) EZ, JBP
City Dn., Vijay Nagar,EZ,JBP
CE (Gen), Sarni
STM Dn.,Narsinghpur
EE (MT) Dn., EZ, Rewa
EE (City) Dn Katni
Addl.Dir.(F&A), JBP

Present
Company /
MPSEB
Transco
EZ
CZ
EZ
EZ
CZ
EZ
EZ
EZ
EZ
Transco
EZ
EZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
EZ
EZ
EZ
EZ
CZ
EZ
EZ
EZ
Transco
EZ
EZ
EZ
Genco
EZ
EZ
EZ
Genco

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Tradeco
Transco
Transco
Transco
Tradeco
Tradeco
TRadeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco

---

------Genco
EZ
-Transco
-EZ
Transco
Transco
----CZ
----WZ
-WZ
Transco
---WZ
---Transco
----

-------

-------Genco
-Transco
--Transco
Transco
-----------EZ
Transco
---Genco
---Tradeco
----

CZ
-WZ
CZ
Transco
Transco
Tradeco
Transco
-Tradeco
Transco
Transco
Transco
CZ
CZ
Transco
Transco
Transco
Transco
Transco
-Transco
-Tradeco
Transco
-Tradeco
-CZ
Tradeco
-Tradeco
Transco
WZ
-Tradeco

EZ
CZ
-Transco
--Transco
Transco
---------EZ
-CZ
Transco
---Tradeco
---Transco
----

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
Yes
No
Yes
No
No
No
Yes
No
Yes
Yes
No
No
Yes
No
No
No
Yes
Yes
Yes
No
Yes
No
Yes
No
No
No
Yes
No
No
No
No
No
Yes
Yes
No
No
Yes
Yes
Yes
Yes
Yes
Yes
No
No
No
No
Yes
No
No
No
No
No
No
No
Yes
Yes
No
No
Yes
No
No
No
No
No
Yes
Yes
Yes
No
Yes
No
No
No
Yes
Yes

<!-- page 6 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

188
189
190
191
192
193
194
195
196
197
198
199
200
201
202
203
204
205
206
207
208
209
210
211
212
213
214
215
216
217
218
219
220
221
222
223
224
225

Gurdeep Singh Khanuja
Sanjay Kanoje
Shiv Narayan Verma
Kamlesh Kumar Sharma
R.S.Singrol
B. C. Bhattacharya
Shankarlal Bamhore
Deepti Mishra
M. K. Choudhaiy
Pavan Kumar Jain
Smt. Sapna Jain
Sunil Kumar Tiwari
Sanjay Kumar Baghel
Mahesh Chandra Gupta
M S Anand
Ashok Kumar Saxena
Sapna Jain
U K Tiwari
Anjali Agarwal
Narendra Kumar Sharma
Ajay Kumar Jain
Vijay Datatray Joglekar
R K Pathak
A G Deole
Raj Burman Saxena
Baljeet Singh Khanooja
A. K. Updhyaya
P. K. Phadnis
S. L. Patidar
Manoj Mandloi
Devendra Kumar Mangal
N. Mathur
Anish Kumar Singhai
Vivek Narad
Milind Bhandarkar
Naresh Parashar
Khalid Nafees
Subodh Mandvikar

Employee
Number
93326120
92610194
92470151
84367902
93972691
94340428
94340568
93325890
94340626

82974798
94340725
91552553
89432841

93326105
93326717
81972935
92358850
93326154
91320779
93050044
92054947
85052073
89043250
85050770
91112399
91112408
89973075
91112381
89972440
93110178
82978725

Designation
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (T&D)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)

Place of Posting
EE,City (N), Bhopal
STM Dn., WZ,Ujjain
STC Dn,WZ, Ujjain
City.Dn.(E),WZ,Ujjain
SE (O&M).EZ,Rewa
SE (O&M), EZ, Narsinghpur
SE(O&M) CZ, Bhopal
SE(O&M) CZ, Bhopal
EE(O&M) Dn, EZ,Pandhurna
CMD ,WZ , Indore
CMD CZ, Bhopal
O/o CMD (Transco),JBP
CE(Comm.)EZ, JBP
CE (W&P) EZ JBP
STM City Circle EZ
CMD Bhopal
CMD Bhopal
SE (O&M) Cir.JBP
CMD Bhopal
EHT Construction Dn.Transco
CMD Bhopal
EE O&M Dn., Baidhan
City Dn.(N),JBP
M T I Dn. CZ, Gwalior
City Dn.(W),Bhopal
Deputation to NVDA, Bhopal
SE (Trainee), , Sarni
SE (OPN)-II STPS, Sarni
CE (Gen), Sarni.
OSD (R.O.), Tradeco, Bhopal.
SGTPS, Birsinghpur
CE(Gen) SGTPS, Genco Birsinghpur
CE(PRG), Genco,JBP
CE (PRG), Genco, JBP
CE (PRG), Genco, JBP
CE (PRG), Genco, JBP
CE (PRG), Genco, JBP
CE (PRG), Genco, JBP

Present
Company /
MPSEB
CZ
WZ
WZ
WZ
EZ
EZ
CZ
CZ
EZ
WZ
CZ
Transco
EZ
EZ
EZ
CZ
CZ
EZ
CZ
Transco
CZ
EZ
EZ
CZ
CZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco

Pref-1

Pref-2

Tradeco
Tradeco
Tradeco
Tradeco
Genco
Transco
Tradeco
Tradeco
Transco
Transco
Tradeco
EZ
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
Tradeco
Tradeco
WZ
WZ
WZ
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco

Transco
--Transco
-EZ
--Tradeco
-CZ
--Transco
Transco
-CZ
Transco
--CZ
Transco
Transco
Transco
Transco
-CZ
Transco
CZ
Transco
Transco
CZ
-------

Pref-3
CZ
----Tradeco
-----------Transco
---Genco
Transco
----Genco
-----------

Pref-4

Pref-5

-----------------Transco
---------------------

-----------------Transco
---------------------

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
Yes
No
No
No
No
No
No
No
No
Yes
No
Yes
No
Yes
No
No
No
Yes
Yes
Yes
No
No
No
No
No
No
No
No
No
Yes
No
Yes
No
Yes
Yes
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
Yes
----------Yes
Yes
No
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes

<!-- page 7 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

226
227
228
229
230
231
232
233
234
235
236
237
238
239
240
241
242
243
244
245
246
247
248
249
250
251
252
253
254
255
256
257
258
259
260
261
262
263

C.Radhakrishnan
Rajesh Verma
Khomanlal Bisane
Naveen Kumar Upadhyay
Santosh Kumar Shukla
Raj Bardhan Singh Tiwari
Salil Choudhary
Rajesh Shrivastava
Ashok Sharma
N. K. Brahme
Subodh Verma
Subodh Nigam
Satendra Narayan Singh
V. C. Tailor
Arjun Singh Rathore
Dilip Kumar Mandloi
N. P. Sharma
S. A. Godbole
Kamil Ahemed Siddiqui
C. K. Sentiya
Narendra Gupta
R. V. Koranne
Ashok Bhole
Rakesh Kumar Jain
D K Ghirnikar
Vijay Pimpalapure
Shashank S Datar
Vimla Rai Diwan
Pradeep Kumar Selot
Sudhir Sharma
Bashruddin Khan
AK Sharma
Shyam Sunder Saraf
AK Bhatnagar
Abhishek Jain
RS Sharma
Indriya Daman Kaushik
Rakesh Kumar Gautam

Employee
Number
81974436
82979780
90019256
90296368
89041404
90291823
89972671
93970704
91393734

85051786
85052693
91059897
91115724

89041247
82976349
91111490
90291856
93970654
93050085
82978659
89040843
82978907
91115849
82970376
85051258
91014231

Designation
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)

Place of Posting
CE (PRG), Genco, JBP
CE (PRG), Genco, JBP
SE (Services-II),Birsinghpur
SE(O&M), Silpara, Rewa
SE(O&M), Silpara, Rewa
SE(O&M), Silpara, Rewa
CE(Cor. Service), Genco, JBP
CE(CS), Genco, JBP
SE (City), CZ, Gwalior
On Deputation NVDA,Bhopal
SE(OPN)-I, Sarni
Addl.CE (Constn.), Sarni
Addl.CE (Constn.), Sarni
STPS, Sarni
SE (Maint.) PH-II,Sarni
CE(Gen),SSTPP,Khandwa
CE(Gen),SSTPP,Khandwa
CE(Gen),SSTPP,Khandwa
CE(Gen),SSTPP,Khandwa
CE(Gen),SSTPP,Khandwa
CE (Gen), Sarni
CE (Gen), Sarni
CE (Gen), Sarni
SE(Opn)210MW,Chachai
CE (Gen.Stores)JBP
CE (O&M-Hydel)JBP
ED (Engg), Jabalpur
ED (Engg), Jabalpur
ED (Engg), Jabalpur
ED (Engg), Jabalpur
ED (Engg), Jabalpur
ED (Engg), Jabalpur
ED (Engg), Jabalpur
ED (Engg), Jabalpur
ED(HR&A) Genco, JBP
CE (O&M)Hydel,JBP
THP, Sirmour, Rewa
THP-I, Sirmour, Rewa

Present
Company /
MPSEB
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
CZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
WZ
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco

-Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
EZ
--Transco
Transco
Transco
EZ
-----Transco
Transco
Transco
Transco
-Transco
-Tradeco
Transco
-------Transco
Transco

-Genco
----Transco
------Genco
-----------Genco
-------------

------Transco
--------------------------------

------Transco
--------------------------------

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
Yes
Yes
No
Yes
Yes
Yes
No
Yes
No
Yes
No
Yes
Yes
Yes
Yes
No
No
Yes
No
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
Yes
No
Yes
No

<!-- page 8 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

264
265
266
267
268
269
270
271
272
273
274
275
276
277
278
279
280
281
282
283
284
285
286
287
288
289
290
291
292
293
294
295
296
297
298
299
300
301

S D Upadhyay
Vijay Katiyar
Krishna Bihar Birthire
C S Verma
Sanjay Bhargava
Gafoor Rehman
Mahendra Lal Patel
Hari Krishna Tripathi
Ram Prasad Pandey
Vivek Bajhal
Yogendra Singh Sengar
Virendra Singh Mall
Bipin Chandra Joshi
K L Sharma
Kailash Nath Sharma
Smt Manisha Lavania
H S Sengar
R K Jain
Udit Agarwal
A K Vishwakarma
Arvind Kumar Saxena
Ravindra Kumar Bhageria
Raghvendra Shrivastava
Deepak Namjoshi
Vilas Ramakant Sambre
Gurunath Sreenivas
Kiran Kumar Patel
Ramlal Kadwe
B P Goutam
A K Choukse
Manash Kumar Banerjee
B R Ghogare
Satish Dube
K P S Verma
Shubhash Chandra Gupta
Shashi Kant Malviya
Chandra Pal Thukral
Govindram Gupta

Employee
Number
89043185
90013177
89040892
91110048
85050788
90015446
91115831
89041163
89040703
92036390
89042518
89970543
89972755
91051952
92057636
85053393
89970931
85051323
85052479
85051398
85051893
86058441
91111748
86058632
92057628
92054906
85052123

85053238
85050763
85050805

Designation
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)

Place of Posting
ED (HR&A),Jabalpur
SE (Opn)-3, Birsinghpur
SGTPS, Birsinghpur
SGTPS, Birsinghpur
SGTPS, Birsinghpur
SGTPS, Birsinghpur
SE(M/M)III, Birsinghpur
Addl CE (O&M)I,Birsinghpur
SGTPS, Birsinghpur
CE (Gen),Birsinghpur
SGTPS, Birsinghpur
SGTPS, Birsinghpur
CE (R&M),Genco,JBP
CE (R&M),Genco,JBP
CE (Gen.Stores),JBP
CE (Gen.Stores),JBP
SE (Opn)3,STPS,Sarni
STPS, Sarni
SE(Opn.)-II, Chachai
CE(Gen), Bir.
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
SE (MM)-I Sarni
SE (MM)-I Sarni
CE (Gen), Sarni

Present
Company /
MPSEB
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco

Pref-1

Pref-2

Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
CZ
Tradeco
Tradeco
Tradeco
Tradeco

------------Tradeco
----Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
-Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco

Pref-3
------------Genco
---------Genco
--EZ
---CZ
---------

Pref-4

Pref-5

-----------------------

---------------------------------------

EZ
----------------

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
Yes
No
No
No
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
Yes
Yes
Yes
No
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
No
Yes
No
Yes
Yes
No
Yes
Yes
Yes
No
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes

<!-- page 9 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

302
303
304
305
306
307
308
309
310
311
312
313
314
315
316
317
318
319
320
321
322
323
324
325
326
327
328
329
330
331
332
333
334
335
336
337
338
339

Rajeev Singh
Deepak Kumar Kashyap
Satyendra Singh
Anurag Mishra
Vivek Kumar Agrawal
Anurag Prasad Dixit
Ram Awatar Sharma
Vijay Kumar Rathore
Rajesh Kumar Gupta
Jitendra Singh Khotra
Rajeshwar Pd Bajpai
Ashutosh M Sahastrabudhe
Rajendra Kumar Patel
Sanjay Kumar Jain
Sanjay Kumar Tripathi
Subodh Kumar Bajpai
Prasant Kumar Saxena
Shishir Jaiswal
Rajesh Kumar Khare
Subhash Deshpandey
Joy Dev Bose
Pramod Kumar Khare
Radheshyam Sharma
Arvind Beohar
Neeraj Vyas
Pankaj Shukla
Rajeev Kumar Gupta
Prabhat Dixit
Pradyumn Kumar Choudhary
Girish Vyas
P. L. Barange
Santosh Kumar Shrivastava
S.K. Talreja
Sunil Kumar Singhai
Devendra Mehta
Ashok Kumar Dubey
Himmat Singh Thakur
Manoj Kumar Chatterjee

Employee
Number
85050333
85051308
89972458
89972549
82971010
89972135
89972572
85052560
89971749
89971483
89971260
82978121
92036580
85050325
82978014
89043029
82979889
82979946
85053096
89041206
89972341
93327185
83610542
90530378
85052396
93420170
91114494
90441146
82971589
89970642
82976976
90442029
92036440
82978873

Designation
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Gen)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)

Place of Posting
CE (Gen), Sarni
SE (ET&)I-III, Sarni
SE (O&M) RHPS, Chanderi
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
ED (MM)Genco,JBP
ED (MM)Genco,JBP
ED (MM)Genco,JBP
ED (MM)Genco,JBP
ED (O&M)Gen. JBP.
ED (O&M)Gen. JBP.
ED (O&M)Gen. JBP.
ED (O&M)Gen. JBP.
ED (O&M)Gen. JBP.
ED (O&M)Gen. JBP.
CE(PRG)Genco, JBP
CE(PRG)Genco, JBP
On Deputation to Khandwa
ED (HR&A),Jabalpur
NVDA, Bhopal
THP, Sirmour
Area Store, Ujjain
CMD (EZ), JBP
CMD (WZ) Indore
SSTPP, , Khandwa
EE ( C ) Bhopal
CE(Civil)P&D-Proj.Gen.JBP
ADDL. SECRETARY (P)-I
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY (P)-I
ADDL. SECRETARY
MD, Bansagar, THPCL, CZ, JBP.

Present
Company /
MPSEB
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
WZ
EZ
WZ
Genco
Transco
Genco
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
CZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Tradeco
CZ
Transco
CZ
Transco
WZ
Tradeco
Transco
Tradeco
Transco
Tradeco
Tradeco
Tradeco
Tradeco

Tradeco
Tradeco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
-CZ
Tradeco
----Tradeco
-Tradeco
Transco
Transco
Transco
Transco
-Transco
Tradeco
--Genco
Genco
WZ
-Transco
-Transco
Genco
Transco
Transco
Transco
Transco

---

---

--------------------Transco
-Transco
----WZ
-----

EZ

CZ
----

CZ
-Tradeco
-----EZ
-----Transco
-Transco
----Transco
Genco
-Genco
-Genco
Tradeco
Genco
Genco
Genco
Genco

-----------------Transco
-Transco
----Tradeco
----EZ
EZ
EZ
EZ
EZ
--

--

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
Yes
Yes
Yes
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
------------------------Yes
No

<!-- page 10 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

340
341
342
343
344
345
346
347
348
349
350
351
352
353
354
355
356
357
358

Sunil Kumar Choubey
Amit Kumar Shravastava
Ramkrishna Chouksey
Rakesh Malhotra
Madan Mohan Bhatt
R. N. Dwivedi
Prakash Gupta
H.S.Gupta
Raman Mehta
U K Mehara
Chandra Mohan Raizada
Pradeep Kumar Nema
Gopal K Mishra
Narendra Kumar Mishra
Amar Khare
Virendra Kumar Sahu
Rajesh Grover
Vinod Kumar Birthire
Santosh Kumar Gupta

359
360
361
362
363
364
365
366
367
368
369
370
371
372
373
374
375
376

Sudhir Damodar Pendse
Anoop Kumar Shrivastava
Ratan Kumar Gupta
C.K.Jain
Anindya Kumar Khare
Bharat Hingwey
Gyan Shankar Mishir
Manoj Kumar Verma
Nitin Khatri
Vijayendra Singh
Shivraj Kumar Dohare
Laxmi Prasad Jaiswal
Anand Kumar Soni
Dayal Prakesh Shrivastava
Rajesh Kumar Basu
Arun Kumar Shakya
Anand Prakash Shukla
Mahesh Chandra Maltare

Employee
Number
89410631
90440536
89970577
89972508
92036507
90295832
91392876
93970217
91535609
82979540
82976240
85472023

89972077
89972102
91114528
93970174
93326849
89972028
82979649
90565648
86449599
94437645
92441128
89433195
91395052
85441580
93513959
81978643
90465970
90483866
91555102
83365022

EE (CiviL)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
SE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
EE (Civil)
AEE (Civil)
EE (Civil)
EE (Civil)

CMD CZ, Bhopal
CE (Civil),Genco, JBP
ADDL. SECRETARY (P)-I
EE(Civil)-II ,SSTPP,Khandwa
SSTPP,Khandwa
MHEP, Genco Mandleshwar
CMD CZ, Bhopal
Addl.CE (Civil),SSTPP,Khandwa
EE,Admn.Complex,JBP
SE (Civil) EZ JBP
Addl.Dir.(F&A), JBP
ED (Finance), JBP
City Maint,Dn,Chachai
CE (CE), Genco, JBP
Silpara, Rewa
ADDL. SECRETARY
ADDL. SECRETARY (S)
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I

Present
Company /
MPSEB
CZ
Genco
MPSEB
Genco
Genco
EZ
CZ
Genco
Tradeco
EZ
Genco
Tradeco
Genco
Genco
Genco
MPSEB
MPSEB
MPSEB
MPSEB

EE (Civil) ( * )
EE (Civil)
EE (Civil) TBPS
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)

On deputation to MPRRDA
ADDL. SECRETARY (S)
Cor.Office,EZ,JBP
City Dn. (S), Gwalior
CMD (EZ), JBP
EE (City) S.Dn.,EZ, Rewa
JE (D/C), WZ, Berchha
EE (City) EZ, JBP
CE (W&P) JBP
EE(O&M) Dn. Rural Satna
EE (O&M) Dn Waraseoni
EE (STM) Dn., EZ, Shahdol
EE (O&M) Dn., EZ, Mandla
EE (O&M) EZ, Baidhan
EE (STC) Khandwa
EE (O&M) CZ, Mehgaon,
EE (O&M) Dn. Damoh
EE (O&M) Dn. Sonekatch

Transco
MPSEB
EZ
CZ
EZ
EZ
WZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
WZ
CZ
EZ
WZ

Designation

Place of Posting

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Tradeco
Tradeco
Transco
Transco
Transco
Genco
Tradeco
Transco
Genco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Transco

--Tradeco
--Tradeco
CZ
-Transco
Tradeco
--Tradeco
Transco
CZ
Tradeco
Tradeco
Tradeco
Tradeco

-----Transco
--------Transco
--Genco
--

------------------

--------------------

Genco
Transco
Transco
Transco
Tradeco
Genco
Transco
Tradeco
Tradeco
Transco
CZ
Transco
Transco
Transco
Transco
Transco
Transco
Transco

Transco
Tradeco
Tradeco
Tradeco
---Transco
--WZ
Genco
--Genco
CZ
Tradeco
Transco

CZ
-Genco
CZ
---EZ
--Transco
---WZ
-Genco
Transco

EZ
-WZ

EZ
--

EZ
Genco
------CZ
--------

--WZ
------CZ
--------

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
No
No
Yes
No
Yes
Yes
Yes
Yes
Yes
No
Yes
No
Yes
Yes
Yes
No
Yes
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
Yes
No
Yes
Yes
Yes
No
-Yes
Yes
----------------

-No
Yes
----------------

<!-- page 11 -->

Order of Preference
SN
377
378
379
380
381
382
383
384
385
386
387
388
389
390
391
392
393
394
395
396
397
398
399
400
401
402
403
404
405
406
407
408
409
410
411
412
413
414

NAME (S/Shri/Smt.)
Shankarlal Soni
Ashok Kumar Dixit
Dinesh Kumar Khare
Pramod Kumar Gangele
Akhilesh Kumar Gupta
Vivek Mathur
A. S. Raghuwanshi
Rakesh Kumar Shrivastava
Ram Kumar Pandey
A. K. Tyagi
Shrikant Vishnu Bhadkamkar
Keshav Kumar Dubey
N. P. Malviya
Abdul Wakeel
Yogeshchandra Vorey
B. L. Patel
Ravindra Kumar Khare
S. C. Jain
V. Ramesh Iyer
Ramesh Prasad Kanyakubj
Mahendra Kumar Ahirwar
Prabhat Kumar Saxena
Jagdish Singh Chouhan
Ramji Lal Pathak
Rajveer Singh
Gulab Singh Verma
Vinayak Baraskar
Rajnish Kumar Reja
Kailash Chandra Parmar
Sanjay Arora
Aditya Kumar Gupta
Bharat Shrivastava
Vijay Kumar Sontakke
Arvind Kumar Tiwari
Jitendra Singh
Yogesh Kumar Dixit
Ram Narayan Garg
Ashok Kumar Jain

Employee
Number
89470115
93215178
91340520
89434499
92321986
88449135
89531080
91648864
90641738
92323508
83978195
85449971
90643576
89567209
87434541
92320132
90317882
93550985
89432411
83349421
85448908
84391019
84447471
85611464
93576352
89434276
93380390
91052595
86425971
93326519
87387120
93020245
84343738
88438963

Designation
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)

Place of Posting
Nalkheda, D/c, Town, WZ.
(O&M) DnItarsi.
EE (STM) Dn., CZ, Rajgarh
EE (O&M) DnRajgarh.
Addl. Secy. EZ, Jabalpur.
Corporate Office JBP
(O&M) DnVidisha
EE (MT) EZ, Rewa.
EE (City) Dn. Rewa.
EE (City) Dn. West ,Indore.
EE (STC), Dn Barwaha
EE (City) Dn. WBhopal.
EE (O&M) Dn. Mandleshwar
CE (O&M- Pur) JBP.
AE (TSG) Sub. Dn.,Badwani
EE (O&M) Dn Satna
EE (City) West Dn. JBP.
AE Morba Bedan , Rewa Region.
SE(O&M)CircleBhopal
EE (O&M) Dn Rewa.
CMDBhopal
CE (Commercial) JBP
EE (City) Dn. EZ, Sagar
EE (O&M) South Dn. EZ, Damoh.
EE (North)Dn., CZ, Gwalior
EE(O&M), EZ, Maihar
Addl.EE (O&M), WZ,Tarana
CMD (CZ), Bhopal
EE,O&M Dn,CZ, Bhopal
EE (City) South Dn.,EZ,JBP
EE(O&M) Dn. CZ, Datia
ED(O&M-Gen), JBP.
EE (STM) Dn. WZ, Khandwa
EE(O&M) Dn.,CZ, Bhopal
EE(City) E.Dn., CZ, Gwalior
CMD EZ, JBP
EE(O&M) Dn. EZ, Junnardeo
CE (Commercial),JBP

Present
Company /
MPSEB
WZ
CZ
CZ
CZ
EZ
EZ
CZ
EZ
EZ
WZ
WZ
CZ
WZ
EZ
WZ
EZ
EZ
EZ
CZ
EZ
CZ
EZ
EZ
EZ
CZ
EZ
WZ
CZ
CZ
EZ
CZ
Genco
WZ
CZ
CZ
EZ
EZ
EZ

Pref-1

Pref-2

Pref-3

Genco
Genco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
Transco
Transco
Transco
Tradeco
CZ
Tradeco
Tradeco
Transco
Transco
Tradeco
Tradeco
Transco
Transco
EZ
Transco
Transco
Tradeco
Transco
Tradeco
CZ
Tradeco
WZ
EZ
Transco
Tradeco
Tradeco
Tradeco
Genco
Transco
Transco
Tradeco

Transco
Transco
Transco
Transco
-Tradeco
Transco
Tradeco
Genco
Tradeco
Transco
-Transco
-Genco
Tradeco
Transco
Transco
-WZ
-Transco
-Transco
Genco
Transco
----Genco
Transco
Genco
Transco
Tradeco
Tradeco
---

-Tradeco
CZ
CZ
--CZ
Genco
-------EZ
EZ
EZ
-EZ
-Transco
-Genco
----------Transco
WZ
---

Pref-4

Pref-5

--

---------------------Transco
-----------------

CZ
EZ
---WZ
--------------Transco
-----------------

Option
Option
for
for
personal Associati
hearing on/ Union
--------------------------------------------Yes
No
YES
NO
Yes
No
No
Yes
Yes
No
Yes
No
No
No
No
No
No
No
Yes
No
Yes
Yes
No
No
Yes
No
Yes
No
Yes
No
No
No

<!-- page 12 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

415
416
417
418
419
420
421
422
423
424
425
426
427
428
429
430
431
432
433
434
435
436
437
438
439
440
441
442
443
444
445
446
447
448
449
450
451
452

Chandramani Singh Yadav
Alok Das
Avaneesh Shukla
Sanddep Kumar Kalara
Kalimullha Khan
Ajay Kumar Sharma
Bhagwan Singh Patel
D. S. Thakur
Ajay Pal Singh Chauhan
Hariom Tailor
Sanjeev Tripathi
K. P. James
Rajendra Singh
Ramesh Kumar Soni
Ramesh Chandra Sahu
Sunil Kumar Nagariya
Sawal Singh Yadav
Ravi Shankar Mishra
Ajay Kumar Nanda
Vinod Rai
Satish Kumar Jain
Mahesh Chandra Malviya
Neeraj Kumar Kuchya
T S Raghu
Shiv Kumar Tripathi
H S Shrivastava
Lokesh Malviya
Sharad Vishwakarma
Vinod Kumar Malviya
Santosh Kumar Jain
A L Thakkar
Vijay Kumar Sharma
Saurabh Shrivastava
J. S. Nanda
Nitendra Singh Uikey
R. K. Agrawal
Arvind Kumar Banwasi
Shrikant Kumar Sharma

Employee
Number
84448370
89361678
93052016
85390317
90484070
86391131
89559387
89567902
92430725
91057017
93056439
92632536
90442094
90575357
89377483
91518109
85472881
89423626
92431293
91534873
91644573
90442235
85447181
87447775
92441136
93020253
89610785

90520361
93326641

95972657
88447304

Designation
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)

Place of Posting
CE (WS&P), EZ, JBP
SE (APDRAP )Cell JBP
On Deputation NVDA,Bhopal
EE (City) N. Dn., CZ, Gwalior
EE (City) N. Dn., CZ, Gwalior
EE (O&M) Dn. CZ, Malanpur
EE (O&M) Dn.EZ, Beena
EE (STM) Dn., EZ, JBP
EE(O&M) Dn, EZ, JBP
SE(OPN)-I, Sarni
SE(OPN)-I, Sarni
EE( City) E. Dn.,WZ,Ujjain
EE(O&M) Dn. Umariya
EE(O&M) N.. EZ,Rewa
SE (AMR),EZ,JBP
Bargi D/c & LD Sub Dn
City Constn.,CZ,Bhopal
Barwaha Rural
EE (O&M),Gadarwara
City Dn.(E),Katni
EE (O&M) Dn. EZ, Beena
O&M Dn., Mhow
EE,City Dn.(W),JBP
City Dn.(N),JBP
City Dn.(N),JBP
City Dn.(N),JBP
O/o CE (Com)-EZ, JBP
City Dn., Panna
City Dn.(E), WZ, Ujjain
AE,City EHT, WZ, Ujjain
City Dn, Ujjain
City Dn.(E), Ujjain
Corp.Office,CZ,Bhopal
EE (STM) Dn. EZ, Sagar
EE (O&M) Dn. CZ, Guna.
CMD (CZ), Bhopal
EE (STC), CZ, Bhind
EE (O&M) Dn. EZ, Shahdol

Present
Company /
MPSEB
EZ
EZ
Genco
CZ
CZ
CZ
EZ
EZ
EZ
Genco
Genco
WZ
EZ
EZ
EZ
EZ
CZ
CZ
EZ
EZ
EZ
WZ
EZ
EZ
EZ
EZ
EZ
EZ
WZ
WZ
WZ
WZ
CZ
EZ
CZ
CZ
CZ
EZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Tradeco
Tradeco
Tradeco
WZ
WZ
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Genco
Tradeco
Transco
Transco
Tradeco
EZ
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Tradeco
Transco
Transco
Tradeco
Tradeco
Tradeco
Transco
CZ
EZ
Tradeco
EZ
Tradeco

---Tradeco
Tradeco
Tradeco
-Tradeco
---Genco
-Transco
-Transco
-Transco
Tradeco
Tradeco
EZ
Tradeco
Transco
Transco
Transco
Transco
Transco
Tradeco
-Transco
Transco
Transco
Tradeco
Transco
Transco
CZ
Transco
Transco

---Transco
Transco
Transco
-----Tradeco
---Transco
-CZ
--WZ
--Transco
Transco
Transco
---WZ
WZ
-CZ
WZ
Tradeco
-WZ
EZ

----------------

----------------

EZ

EZ

-Genco
-----Transco
Transco
Transco
-------Tradeco
WZ
----

-------Transco
Transco
Transco
-------------

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
No
No
Yes
Yes
No
No
No
No
Yes
No
No
No
Yes
No
No
No
No
No
No
No
No
No
--Yes
No
Yes
No
No
No
Yes
Yes
Yes
No
No
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
Yes
No
YES
NO
YES
NO
Yes
No
No
No
No
No

<!-- page 13 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

453
454
455
456
457
458
459
460
461
462
463
464
465
466
467
468
469
470
471
472
473
474
475
476
477
478
479
480
481
482
483
484
485
486
487
488
489
490

Rakesh Tripathi
C. S. Shukla
Amar Singh Vaskale
Pranab Kumar Roy
Rajendra Singh
Anand Mahakar Thosar
T S Raghu
R Vishwanathan Iyar
A V Rammohan Rao
Prabhat Shrivastava
Mahendra Kumar Jain
Basantilal Dubey
Pramod Yadav
Jyoti Xalxo
P. K. Upadhyay
Tej Singh Rathore
Somdev Sharma
Pramod singh Bundela
Atul Vadzikar
S.P. Nishad
Ram Bhuwan Tiwari
Rajinder Singh Pall
Jyotirmoy Ghosh
Anil Pujara
Ajay Singh Dewde
Suresh Lele
Mahendra Kumar Patil
Ku.Chetna Parmar
DS Khare
Ram Datt Sharma
Chandra Bhushan Mishra
Gopal Chitnis
M Shri Rama Murty
Rajesh Kumar Tiwari
Ajit Singh Rajput
Datta Thakre
Smt Jyoti Gaikwad
L K Dixit

Employee
Number
91577154
89446676
88439300
90565622
86448949
85447181
93320728
89442957
85976651
85976701
91055136
93051984
93111241
86058400
91055185
92050532
86058582
86058376
90013184
90295410
93110210
91052554
91052570
86035598
91012748
92054054
91970796
81972463
93052115
90013219
91052679
85977468
91015213
85976676
91057470
86058327
86058599

Designation
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (T&D)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)

Place of Posting
EE(City) South Dn.CZ, Bhopal
EE(STC) Dn. EZ,Sidhi
WZ, Shujalpur
CE(JR), EZ, JBP
EE( O&M), EZ, Umaria
EE (STM) Dn.O&M Cir.JBP
City Dn. North, JBP
CMD Bhopal
EE (O&M)East Dn,JBP
CE (O&M:Hydel)JBP
CE (O&M:Hydel)JBP
SE (OPN)-II, , Sarni.
SE (OPN)-I, , Sarni
SE(OPN)-II, , Sarni.
SE (OPN)-II, , Sarni.
SE (OPN)-II, , Sarni
On Deputation to NVDA,BPL
STPS, Genco, Sarni
SE (Services-II),Birsinghpur
SE (Services-II),Birsinghpur
SE(O&M), Silpara, Rewa
CE(PRG), Genco,JBP
On Deputation NVDA,Bhopal
SE (MM)PH-II, Sarni
CE(Gen),SSTPP,Khandwa
CE(Gen),SSTPP,Khandwa
CE(Gen),SSTPP,Khandwa
CE (Gen.Stores)JBP
SE (O&M), Barginagar
SE(M/M)III, Birsinghpur
SE(M/M)III, Birsinghpur
SGTPS, Birsinghpur
SE(M/M)III, Birsinghpur
SGTPS, Birsinghpur
SE (Opn)III,Birsinghpur
SE (Opn)3,STPS,Sarni
STPS, Genco, Sarni
SE(Opn)PH-3,Genco,Sarni

Present
Company /
MPSEB
CZ
EZ
WZ
EZ
EZ
EZ
EZ
CZ
EZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

CZ
Transco
Transco
Transco
Genco
Transco
Transco
Tradeco
Transco
Tradeco
Tradeco
WZ
Tradeco
CZ
Transco
WZ
Tradeco
Tradeco
Transco
Transco
Tradeco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco

WZ
Tradeco
-Tradeco
-Transco
Transco
--Transco
Transco
Transco
Transco
-CZ
-Tradeco
Transco
-Tradeco
Transco
-------Tradeco
------Tradeco
Tradeco
Tradeco

-Genco
---Transco
Transco
----Genco
--Tradeco
-Tradeco
-----------Tradeco
--------EZ

-----Transco
Transco
---------Transco
-----------Transco
----------

------Transco
---------Transco
-----------Transco
----------

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
No
No
Yes
No
No
No
No
No
Yes
Yes
No
No
No
No
No
No
Yes
Yes
Yes
Yes
----------Yes
Yes
No
No
Yes
Yes
Yes
Yes
Yes
No
Yes
Yes
Yes
No
No
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
Yes
No
Yes
Yes
No
Yes
Yes
Yes
No

<!-- page 14 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

491
492
493
494
495
496
497
498
499
500
501
502
503
504
505
506
507
508
509
510
511
512
513
514
515
516
517
518
519
520
521
522
523
524
525
526
527
528

Mihir Kumar Roy
Prakash Narayan Barange
Ashok Dhomne
Prafull Kotwalla
Yashwant K Shrivastava
Satyendra Verma
Santosh Kumar Rai
Goverdhan Teckwani
Nikunj Bihari Soni
Nand Kishore Lohare
Shankar Rao Mudaliar
Brijendra Kumar Sharma
Ruchi Kaushal
Sampann Kulshrestha
Raja Ram Patidar
Sabal Singh Patel
Sunil Kumar Gahriya
Pankaj Shrivas
Prakash Chandra Mukati
Himanshu Prakash Pathak
Raj Kumar Shrivastava
Jayant Agasty
Prakash Kumar Shrivastava
Rajendra Prasad Rakhya
Bhola Nath Chaudhary
Aman Loomba
Anand Hundikar
Bohat Singh Thakur
G K Dixit
Vinay Nandan
Shailendra Suhani
O P Verma
Arun Kumar Bharadwaj
P K Chautre
Arun Yadav
Dinesh Prakash Mishra
Dilip Kumar Somani
V D Tripathi

Employee
Number
91057040
92054955
91052638
91052604
91052588
91052620
90046136
93052131
86055100
91052546
91055202
81977538
92053584
92053577
91052000
54050133

91048024
81974634
90046847
81975193
93973012
90013234
91970598
85976742
86058384
86054326
91050384
87051256
91057504
91050351
91055318

Designation
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)

Place of Posting
SE(Opn)PH-3,Genco,Sarni
SE(Opn)PH-3,Genco,Sarni
SE(Opn)PH-3,Genco,Sarni
SE(Opn)PH-3,Genco,Sarni
SE(Opn)PH-3,Genco,Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
SE(O&M), Silpara, Rewa
SE(OPN), PH-II, Birsinghpur
SE (ET&)I-III, Sarni
SE (ET&)I-III, Sarni
SE (ET&)I-III, Sarni
SE (ET&)I-III, Sarni
EE ( C ) C&M-II, Sarni
SE (MM)-I ,Sarni
EE Sub LDC, Indore
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
Addl.Dir(F&A)MPPGCL
ED (MM)Genco,JBP
City Circle, Garha Zone
ED (O&M)Gen. JBP.
ED (O&M)Gen. JBP.
ED (O&M)Gen. JBP.
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni

Present
Company /
MPSEB
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
EZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
Tradeco

Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
--Transco
-Transco
Transco
Transco
--Tradeco
-Tradeco
Tradeco
Tradeco
Transco
-Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
-Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
--Transco
Transco

---

---

---------------------------------------

CZ
------------------------Genco
-----EZ
---Genco

EZ
----------------------------------CZ

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
Yes
No
Yes
Yes
Yes
No
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
No
No
Yes
No
Yes
No
Yes
Yes
--Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
Yes
Yes
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
Yes
Yes
Yes
Yes
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
No
Yes
Yes
Yes
No
Yes
Yes
Yes
No
Yes
No

<!-- page 15 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

529
530
531
532
533
534
535
536
537
538
539
540
541
542
543
544
545
546
547
548
549
550
551
552
553
554
555
556
557
558
559
560
561
562
563
564
565
566

Mahendra Kumar
Deepak Kamavishdar
R K Malhotra
Yashwant Warathe
Rajesh sahariya
Iliyas Rijwan Khan
Mahesh Prasad Malviya
Anand Gupta
Prakash Wekhande
Dhanraj Kori
Kailash Prasad Sharma
Sanjeev Arora
Ashwini Kumar Saxena
Uday Singh Raghuwanshi
Prakash Gupta
Anurodh Shrivastava
Sanjay Kumar Agrawal
Ashok Kumar Joshi
Rajnish Kumar Chaturvedi
D R Pandey
Rajesh Kumar Jain
Arvind Saxena
Madan Kumar Kori
Arun Kumar Khare
Soumitra Kumar Banerjee
Sujeet Kumar Shrivastava
Ashok Kumar Dubey
Rizwan Ullakhan
Sanjay Kumar Jain
R. S. Sanodiya
Ramakant Gupta
Manoj Kumar Sharma
Subodh Kumar Jain
M. N. Khan
Surendra Kumar Lamba
Ashok Kumar Koushik
Sureshchandra Rajvaidhya
Jay Gopal Bansod

Employee
Number
86058335

92301653
91057421
54050240
91056985
86058649

91055144

90585646
92386075
85052354
90420082
90420117
90295683
83343978
91970011
93440996
90293869
90417070
91394450
83344075
89410839
95322557
90293836
90560516
90297101
93420147
93460135
90295997

Designation
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
AE (Gen)
EE (Civil)TBPS
EE (Civil)TBPS
EE (Civil)TBPS
EE (Civil)TBPS
EE (Civil)TBPS
EE (Civil)TBPS
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)

Place of Posting
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
CMD Bhopal
CMD (CZ), Bhopal
EE (Civil), Birsinghpur
EE(Civil)-I ,SSTPP,Khandwa
EE(Vig), Betul
Civil Maint.Dn,Chachai
EE (C )GCL, Sarni
Corporate Office, EZ, JBP
SE (Civil), ATPS, Chachai.
AE (Vigiliance ) EZ, Shahdol.
Chief (Vig.) EZ, JBP
Chief (Vig.) JBP
SE (Civil) -3, , Silpara
(O&M) DnItarsi
CGM (GR)Gwalior.
AE (Vig.) EZ, Seoni
CE(Gen),Singaji TPS,Khandwa
EE (Civil)-I, SSTPP, Khandwa
SSTPP, . Khandwa
SE (Civil) Rewa.
Civil Sub-Dn. Sidhi
CE (IR), WZ, Indore.
EE (Civil) Dn Khandwa
Vigilance Dn Chhindwara

Present
Company /
MPSEB
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
CZ
CZ
Genco
Genco
CZ
Genco
Genco
EZ
Genco
EZ
EZ
EZ
Genco
CZ
CZ
EZ
Genco
Genco
Genco
EZ
EZ
WZ
WZ
EZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
CZ
Tradeco
Tradeco
Tradeco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Tradeco
Genco
Transco
Genco
Genco
Genco
Genco
Transco
Genco
Genco
Transco
Transco
CZ
Transco
Genco
CZ
Transco
Transco
Genco

-CZ
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
-Transco
-Tradeco
Transco
Transco
CZ
CZ
Transco
-Genco
Transco
Transco
Genco
-Tradeco
Transco
Transco
--Transco
Genco
Tradeco
Transco
Tradeco
Transco
Genco
Genco
Genco
--

--------

-------Transco
-----CZ
-CZ
-------EZ
WZ
WZ
--WZ
---WZ
Tradeco
WZ
CZ
CZ
--

----------------

WZ
---CZ
-WZ
-CZ
--Tradeco
-Tradeco
--Transco
Tradeco
Tradeco
--CZ
EZ
-Tradeco
CZ
EZ
Transco
Tradeco
WZ
--

CZ
-------CZ
EZ
CZ
--Tradeco
---EZ
-Tradeco
WZ
---

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
No
No
Yes
Yes
Yes
Yes
No
Yes
Yes
Yes
Yes
Yes
No
No
No
No
No
No
Yes
No
Yes
No
Yes
Yes
Yes
Yes
Yes
No
Yes
No
Yes
No
Yes
Yes
Yes
No
Yes
No
No
No
-----------------------------------

<!-- page 16 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

567
568
569
570
571
572
573
574
575
576
577
578
579
580
581
582
583
584
585
586
587
588
589
590
591
592
593
594
595
596
597
598
599
600
601
602
603
604

Premlal Randhey
Pramod Kumar Jain
Prashant Gupta
Rajesh Kumar Jain
Sudhir Kumar Shrivastava
Mahendra Kumar Pal
Ashok Kumar Naik
Brij Bhushan Panchal
Vinod Kumar Maru
Jitendra Singh Kalchuri
Indramani Prasad Mishra
Sudhir Kumar Pandey
Harnarayan Mahour
Dwarka Prasad Gurjar
Akhilesh Shrivastava
Rakesh Kumar Jain
Anil Kumar Mishra
Vijay Kumar Pandey
U.P.S. Sikarwar
B. K. Kushwaha
Deepak Kumar Dubey
Abhay Gumasta
Bhagwaticharan Hemat
S. P. Saole
A. K. Mahajan
S.V. Raich
S.D. Pare
Pravin Kumar Saxena
R. K. Ram
Surendra Kumar Dubey
Keshav Kumar Malviya
Subhash Shukla
R K Ram
D. P. Verma
G.P.Mishra
Vishwanath Mitra
Arvind Kumar Sharma
J. P. Shrivastava

Employee
Number
92332467
90440412
91971562
91114163
91395029
93550183
94340311
93326930
84612513
87031026
91531268
93971396
92481934
86423132
90019736
92036416
89972713
93460110
84614278
90294065
90296243
91972511
91380798
93460085
90291377
90294073
91114338
92544293
93410228
84614261
90019653
88432207
88437122
90563825

Designation
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (Civil)
AE (T&D)TBPS
AE (T&D)TBPS
AE (T&D)TBPS
AE (T&D)TBPS

Place of Posting
EE (Vig.) EZ, Rewa.
AE (Vig.), EZ, Narsinghpur
Corporate Office JBP
SE (Civil) Dist. JBP.
SE (O&M) CZ, Shivpuri.
Vig. Team Flying Damoh.
SE (Civil) Jabalpur.
SE (Civil) S&I, ., Bhopal
Addl.CE (Civil),Khandwa
Chief (Vig.) JBP
EE (Vig.) Rewa
ADDL. SECRETARY (P)-I
EE (Civil)Gwalior
SE (Civil), Transco,Indore
EE (Civil) Dn. CZ, Gwalior
SE (Civil), Genco, Birsinghpur
SE (Civil), MHEP, Genco
EE(Civil)-I ,SSTPP,Khandwa
Addl. CE(Civil),I ,SSTPP,Khandwa
EE(Civil)-II ,SSTPP,Khandwa
STPP,Khandwa
EE(Civil)-II ,SSTPP,Khandwa
EE(Civil)-II ,SSTPP,Khandwa
EE(Civil)-II ,SSTPP,Khandwa
EE(Civil)-I ,SSTPP,Khandwa
Addl.CE (Civil),SSTPP,Khandwa
Addl.CE (Civil),SSTPP,Khandwa
EE (C ) S&I, Rewa
EE(Vig.) CCF/s-01 JBP
STPS, Genco, Sarni
STPS, Genco, Sarni
SE(Civil),WZ,Indore
Vig., Jabalpur
EE(Civil)-I ,SSTPP,Khandwa
AE (O&M) EZ, Hatta
EE( O&M), EZ, Umaria
AE (RES), EZ, JBP
EE (O&M)Dn Patan

Present
Company /
MPSEB
EZ
EZ
EZ
EZ
CZ
EZ
EZ
Genco
Genco
EZ
EZ
MPSEB
CZ
Transco
CZ
Genco
EZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
EZ
Genco
Genco
WZ
EZ
Genco
EZ
EZ
EZ
EZ

Pref-1

Pref-2

Pref-3

Genco
Tradeco
Transco
EZ
Genco
CZ
EZ
Tradeco
Transco
Tradeco
Genco
Tradeco
Transco
Tradeco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Genco
Tradeco
Transco
Tradeco

Transco
Transco
Tradeco
EZ
Transco
Genco
-Transco
WZ
-Transco
Transco
CZ
-Tradeco
Transco
----Genco
------Tradeco
-Tradeco
Tradeco
---Transco
Transco
Tradeco
Transco

EZ
Genco
Genco
EZ
-Transco
----EZ
Genco
Genco
-------WZ
------Transco
-------Transco
-Genco

Pref-4

Pref-5

CZ

----

--EZ

EZ
--

WZ
----CZ
EZ

-Tradeco
----WZ

--------EZ

--------CZ

------------

-------

EZ

-----------------

Option
Option
for
for
personal Associati
hearing on/ Union
--------------------------No
No
No
No
Yes
No
No
No
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
Yes
No
No
Yes
No
Yes
No
Yes
No
--Yes
No
Yes
Yes
No
No
No
No
No
No
---

<!-- page 17 -->

Order of Preference
SN
605
606
607
608
609
610
611
612
613
614
615
616
617
618
619
620
621
622
623
624
625
626
627
628
629
630
631
632
633
634
635
636
637
638
639
640
641
642

NAME (S/Shri/Smt.)
Yogesh Kumar Upadhyay
Rajesh Kumar Shrivastava
Brijkishore Gangrade
G. H.Bhavsar
K. N. Dwivedi
Prakashchandra Gupta
S.S.Thakur
Ajay Pratap Singh Bhadoriya
Arun Sahu
Arvind Kumar Vishwakarma
Ashok Kumar Gupta
Devendra Giri Goswami
J.L.Soni
Sanjay Kumar Dealia
Mehul Mehta
Pramod Mandloi
Suneel Kumar Tiwari
D. K. Kushwaha
A. K. Karoliya
Ashok Kumar Verma
Somesh Singh Kushwaha
Hokam Singh Patidar
Prakesh Chandra Nagar
S. K. Devkar
Jagannath Patidar
Sahebrao Makode
Chaitanya R. Rawal
Dilip Singh Arora
Mahesh Kumar Bajpai
Niranjan Kumar Soni
Santosh Kumar Sharma
Satishchandra Mohadkar
Vijay Kumar Vyas
Anil Acharkate
D. L. Koshta
Milind Kadre
Rajkumar Gayki
Ghanshyam Sharma

Employee
Number

84441400
91460434
88611099
92643419
91577139
91577146
88397608
91558849
90430024
93576923
93411907
90360346
88439375
89436123
85424651
90328913
83616226
90442284
83615178
93576907
93576881
84522357
86361366
91334001
84367506
90641720
83394724
91394278
84474723
88610513
89326606
84366630
89385586
91322543
86390779
90329432
84475480

Designation
AE (T&D)TBPS
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)

Place of Posting
STC Dn,WZ, Ujjain
EE (City) Dn. East, Jabalpur.
EE (O&M)Dn. Mandleshwar
EE(O&M)Dn Barwani
SE (O&M), WZ, Jhabua
AE(City)Sehore
EE(City) East Dn.CZ,Bhopal
EE(Testing)Dn.,Gwalior
SE(City) CircleGwalior
RMS (Cell) JBP
EE (O&M) Dn Itarsi
EE(STC) Dn.EZ, JBP
EE (O&M) Dn Shajapur
RMS (Cell) JBP
EE (City) Dn., West JBP
EE (O&M) Dn Deepalpur.
CMD (CZ), Bhopal
EE (O&M) Dn Shujalpur
EE (O&M) Dn. Rehali
EE (O&M) Dn Agar
EE (O&M) Dn., Narsinghgarh
EE (O&M) Dn., Narisinghgarh
EE (O&M) Dn Mahidpur
EE (O&M), WZ, Neemuch .
EE (O&M) Dn., Khargone
EE(O&M) Dn Dewas
AE (City Wes ) Dn. Ujjain
EE (O&M) Dn., Sonekatch.
EE (T) Dn.-II Gwalior
Nalkheda (D/c) Rural, WZ.
EE (City) Dn Dewas.
EE (O&M) Dn.Sehore
EE (O&M) Dn Sonekatch.
CMD BPL
EE(O&M) Dn Rajgarh (Biaora)
EE (O&M) DnBioara
EE (O&M) Dn. Obedullaganj,
EE (O&M) Dn Ujjain

Present
Company /
MPSEB
WZ
EZ
WZ
WZ
WZ
CZ
CZ
Transco
CZ
EZ
CZ
EZ
WZ
EZ
EZ
WZ
CZ
WZ
EZ
WZ
CZ
CZ
WZ
WZ
WZ
WZ
WZ
WZ
Transco
WZ
WZ
CZ
WZ
CZ
CZ
CZ
CZ
CZ

Pref-1

Pref-2

Transco
Transco
Genco
Transco
EZ
Transco
Transco
CZ
Transco
Tradeco
Transco
Genco
CZ
Tradeco
Transco
Transco
Transco
Transco
CZ
Transco
WZ
WZ
Transco
CZ
Transco
Transco
Transco
CZ
CZ
Tradeco
Transco
Transco
CZ
Transco
WZ
WZ
Transco
Transco

-Tradeco
-Transco
EZ
-Transco
---Transco
Transco
CZ
-EZ
Tradeco
-Transco
Tradeco
-CZ
--WZ
Transco
Transco
-CZ
CZ
Transco
-Tradeco
CZ
-WZ
Transco
CZ
--

Pref-3

Pref-4

Pref-5

--

---Transco
--CZ
-------Genco
---------Transco
--CZ
CZ
-----WZ
----

---Transco
--Genco
-----------------Transco
--CZ
CZ
-----WZ
----

EZ
-Transco
EZ
-Tradeco
-------Tradeco
--Genco
--Transco
---Transco
--CZ
CZ
Transco
--CZ
-WZ
----

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
---------------------------------------------------------------------------

<!-- page 18 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

Employee
Number

643
644
645
646
647
648
649
650
651
652
653
654
655
656
657
658
659
660
661
662
663
664
665
666
667
668
669
670
671
672
673
674
675
676
677
678
679
680

Suryabali Singh Yadav
Amita Gangra
Arvind Kumar Joshi
Manoj Kumar Jain
R. G. Shukla
Om Prakash Singh
Shambhudayal Gupta
Nitin Girdonia
Vijay Singh Panwar
Ambarish Joshi
Kapil Bhargava
Premendra Kumar Bhasin
Vishwas Kelkar
Pankaj Yadav
Anil Kumar Dwivedi
R. S. Vishwkarma
Surendra Nath Sharma
Vinod Kumar Jain
Mukesh Chand Jain
Vijay Singh Chouhan
Banshilal Sahu
Mohd. Aiyub Ali
Mahesh Agrawal
Pradeep Kumar Jain
Mukesh Saxena
Ved Prakash Dwivedi
Pradeep Kumar Saxena
Madhusoodan Patidar
Abhay Kumar Sen
C. L. Mali
Dinesh Kumar Agrawal
Ajay Agrawal
H. N. Budholiya
I. K. Kukreja
M. L. Gourawat
Ranjan Dutta
Mukesh Chand Maltare
D.S. Thakur

88361158
91970143
91610021
92550267
90359322
89445257
84447273
90464114
83616127
91329431
91577113
89327869
90328285
92441425
89326077
90464345
89537046
91418010
89444200
91610112
88430838
86448857
83619328
84367811
91393627
92340701
90560350
92641371
88439425
89551583
91531813
90352955
91320281
86397519
88472236
84443702
84443900
85972196

Designation
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)

Place of Posting
EE (O&M) Dn Tarana
SE (AMR) Jabalpur.
EE (O&M) Dn Shajapur
EE (STM) Dn Sagar
EE (O&M) Dn Panna.
132KV S/s, Mansakra Sehora
EE (O&M) Dn Patan
EE (City) Dn Burhanpur.
EE (O&M) Dn Nagda
EE (City) Dn. WestBhopal.
EE (City) Dn.WestBhopal.
EE (City) Dn. WBhopal.
EE (City) Dn. WBhopal.
EE (O&M) Dn. Baidhan
EE ( City) Dn Rewa.
EE (O&M) Dn Anuppur
EE (O&M) Dn Rewa
EE (O&M) Dn Banda
EE (City) Dn. W Jabalpur.
EE (E) Dn Chhindwara
EE(O&M) Dn JBP
EE (O&M) Dn. EZ, Waraseoni
EE (O&M) Dn Bagli
EE (O&M) Dn Dewas
EE (City )Dn. EastGwalior.
EE (O&M) DnItarsi
EE (O&M) Shahdol
EE(O&M) Dn Khargone-II
EE (O&M) Dn., EZ, Mandla
EE(O&M) Dn. EZ, Dindori
EE (O&M) Dn Panna
D/cShivpuri
EE (O&M) DnVidisha
Addl SE (City)North Dn Gwalior.
EE (O&M) Dn Garoth
EE(City) East Dn.EZ,JBP
EE,Discom,Control Centre,JBP
CE (JR), JBP

Present
Company /
MPSEB
WZ
EZ
WZ
EZ
EZ
Transco
EZ
WZ
WZ
CZ
CZ
CZ
CZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
WZ
WZ
CZ
CZ
EZ
WZ
EZ
EZ
EZ
CZ
CZ
CZ
WZ
EZ
EZ
EZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Transco
Transco
Transco
EZ
Tradeco
Genco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
WZ
Transco
Genco
Tradeco
CZ
Transco
Transco
Transco
Transco
Transco
Genco
CZ
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Genco
Transco
Transco
Transco

Transco
Transco
-Genco
--Transco
Transco
-Transco
Transco
Transco
CZ
Genco
Genco
WZ
WZ
Tradeco
Transco
Transco
Tradeco
Tradeco
Genco
-Transco
Transco
CZ
Transco
Tradeco
Tradeco
-Tradeco
WZ
Tradeco
Tradeco
EZ
---

Genco
--Tradeco
--Genco
Tradeco
-CZ
CZ
CZ
-Tradeco
Transco
WZ
EZ
Transco
EZ
Genco
-EZ
--Transco
Tradeco
CZ
Genco
Transco
Genco
---Genco
Transco
----

-------

-------

CZ

WZ
-------

CZ
CZ
WZ
CZ

------EZ

--WZ
-EZ
--Transco
CZ
CZ
Tradeco
Transco
EZ
---CZ
-----

-WZ
Genco
--EZ
-EZ
--Transco
-CZ
-Transco
----------

Option
Option
for
for
personal Associati
hearing on/ Union
----------------------Yes
No
------------------------------------------------No
No
Yes
No

<!-- page 19 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

681
682
683
684
685
686
687
688
689
690
691
692
693
694
695
696
697
698
699
700
701
702
703
704
705
706
707
708
709
710
711
712
713
714
715
716
717
718

Smt Anjana Thakur
Rajesh Tiwari
Ramnaresh Upadhayay
Vinod kumar Pandey
Surendra Pal Singh
Jeevan Lal Tejraj
Ramesh Singh Kushwah
M K Bhaiji
Sumiran Kumar Rai
Sanat Desai
Sriniwas Sen
Praveen Kumar Gupta
M Prabhakar
Smt Anita Mehta
Mukesh Chand Sharma
Satish Kumar Kohli
Jitendra Mohan Kulkarni
Chandra Mohan Jain
Santosh Kumar Tiwari
Arjun Singh Rajput
K K Mishra
J L Bisen
Manoj Kumar Soni
Ravikant Sharma
Jalaj Mitra
Shailendra Kumar Shah
Hiralal Patel
Ram Kumar Lodhi
Mahendra Kumar Namdeo
P K Sahu
Bhagwan Singh Sisodiya
A. K. Devlalikar
Ramnarayan Katare
P.K. Swrankar
Sanjay Kumar Jain
Rajesh Kumar Sahaya
Kedar Nath Pandey
Anita Sharma

Employee
Number
85975406
89434474
89566763
90535211
90562792
91327402
91561604
92300233
85971256
91971133
91970622
81974063
91970788
92046126
91971919
95970314
83341398
88341183
90355758
89436165
92441466
93576071
93576873
89611106
89341514
84441524
91416329
87432802
89361470
91360295
91481620
89534860
91555929
85976429
85399259

Designation
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)

Place of Posting
SE (AMR),EZ,JBP
SE (AMR),EZ,JBP
EE(O&M) Dn Panna
D/C. Bansagar,
EE (O&M) Dn Damoh (S)
SE,City Cir.,Bhopal
City Dn.(S), Bhopal
Nagod Town) D/C Maihar
CE (SLDC), MPPTCL,JBP
EE Sub LDC, Indore
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CE (SLDC), MPPTCL,JBP
CMD(EZ), JBP
EE,City Dn.(W),JBP
O&M Dn., Chhatarpur
City Dn.(N),JBP
City Dn.(N),JBP
Load Mgmnt,Bhopal
City Dn.(S), Bhopal
City Constn.Dn,WZ,Ujjain
City Sub Dn,Gotegaon
EE (MT), EZ, JBP
EE(O&M) , EZ, Beena
EZ Shahpura
EE (O&M) Dn. WZ, Shajapur.
EE (O&M) Dn. WZ, Shujalpur
EE (City) Dn.CZ, Gwalior.
EE (O&M) Dn. CZ, Guna
EE (O&M) N. Dn. EZ,Damoh
EE (O&M) N. Dn. EZ,Damoh
EE (City) East Dn., EZ,JBP
MT Dn. I, Gwalior

Present
Company /
MPSEB
EZ
EZ
EZ
EZ
EZ
CZ
CZ
EZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
EZ
EZ
EZ
EZ
EZ
CZ
CZ
WZ
EZ
EZ
EZ
EZ
WZ
WZ
CZ
CZ
EZ
EZ
EZ
CZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
CZ
Transco
Transco
Transco
EZ
Transco
Genco
Tradeco
Genco
Transco

--Tradeco
Genco
Tradeco
--Transco
Tradeco
-Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Genco
Tradeco
-Transco
Transco
Transco
Transco
CZ
Transco
-Tradeco
-CZ
Tradeco
-Transco
EZ
-Transco
Transco
-Tradeco

----Genco
--Transco
------------Transco
Transco
Transco
-----CZ
Genco
-Genco
Transco
--Genco
-Transco

-------Transco
------------Transco
Transco
Transco
------EZ
---------

-------Transco
------------Transco
Transco
Transco
------WZ
---------

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
No
No
--No
No
--Yes
Yes
Yes
Yes
No
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
Yes
Yes
No
Yes
No
No
No
No
No
No
No
Yes
Yes
No
No
Yes
No
No
No
No
No
No
No
NO
NO
YES
NO
No
No
No
No
No
No
No
No
Yes
No
Yes
No

<!-- page 20 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

719
720
721
722
723
724
725
726
727
728
729
730
731
732
733
734
735
736
737
738
739
740
741
742
743
744
745
746
747
748
749
750
751
752
753
754
755
756

Mohd Zuber Khan
L. N. Patidar
B.B. Tiwari
Ravikant Sharma
R. N. Katare
Dharmendra K. Dubey
S. K. Bhavsar
Shivkant Hajjari
Rajesh Kumar Gupta
Ramchandra Vegurlekar
S. K. Pathak
Dinesh Kumar Kushwaha
Sunil Kumar Nadekar
Arvind Kumar Jain
S.K. Chaturvedi
N.K. Thakre
S.K. Mourya
Rajeshwari Prasad Tiwari
Prakash Chandra Vishwakarma
Krishna Kumar Asati
Santosh Kumar Upadhyay
Ramgopal Chouksey
Rajiv Kumar Jain
R. K. Sharma
Anil Kumar Gupta
Hanuman Prasad Pandey
Sunil Kumar Mishra
Parameshwar Dayal Gautam
A. P. Singh
D.K. Goyal
Bhupinder Singh Bhave
Shishir Kumar Sharma
M. Kailash Nath
M.M. Pandey
Rajeev Kumar Jain
Anil Kumar Pandey
K. K. Patel
Jagdish Prasad Asati

Employee
Number
92642030
92320447
88362701
84390276
92356672
85399473
90569441
92551521
84619468
89566730
90412485

90587948
92340841
84443348
90340356
91556877
89567589
93441028
90442136
92486321
91340537
89566558
92397692
92552841
92440831
91583253
84346674
90327551
90327568
90569053
91325505
91562487
92553831

Designation
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)

Place of Posting
EE(O&M) Dn. CZ|,Rajgarh(Biaora)
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE (City) Dn, CZ, Gwalior
SE (City) CZ, Gwalior
SE (City) CZ, Gwalior
JE (D/c), WZ, Khedi
EE (City) Dn. EZ, Sagar
EE(O&M) Dn. EZ, Sagar
EE( City) W. Dn., EZ, JBP
JE (Res), EZ, Satna
EE(O&M) Dn. EZ, Satna
EE(O&M) Dn., EZ, Pandhurna
JE (D/c), CZ, Guna
EE(City) Dn. EZ, Katni
EE(O&M) Dn. EZ, Sansour
EE(City) Dn. EZ, JBP
EE(City) Dn. EZ, JBP
EE (O&M) Dn. EZ, Beena
EE (O&M) Dn, EZ, JBP
EE (O&M) Dn, EZ, JBP
AE (D/c), EZ, Polipathar
EE (O&M) Dn, EZ, Rewa
EE (City) N. Dn., CZ, Gwalior
EE ( C City). Dn., CZ, Gwalior
EE(O&M), EZ, Sidhi
EE (City) N.Dn., CZ, Gwalior
EE(STC) Dn., EZ, Sagar
EE (STM) Dn., EZ, JBP
EE ( C City). Dn., CZ, Gwalior
EE(STC) Dn. EZ, Narsinghpur
AE, CZ, Hoshangabad
EE(O&M) Dn.,CZ, Bhopal
EE (City) Dn. EZ, Rewa
EE(O&M) Dn., EZ, Rewa
AE (O&M), CZ, Sironj
EE(O&M) Dn., EZ, Sagar
EE(O&M) Dn., EZ, Sagar

Present
Company /
MPSEB
CZ
CZ
CZ
CZ
CZ
CZ
Wz
EZ
EZ
EZ
EZ
EZ
EZ
CZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
CZ
CZ
EZ
CZ
EZ
EZ
CZ
EZ
CZ
CZ
EZ
EZ
CZ
EZ
EZ

Pref-1

Pref-2

WZ
CZ
CZ
Transco
EZ
Transco
Genco
Transco
Transco
Transco
Transco
Trasnco
Transco
Transco
Transco
Transco
Transco
Genco
Transco
Transco
Transco
Tradeco
Transco
WZ
Tradeco
Transco
Tradeco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
Transco
EZ
WZ
Transco

Transco
WZ
CZ
Transco
EZ
WZ
Genco
Tradeco
Tradeco
-Tradeco
Genco
Tradeco
CZ
Tradeco
Tradeco
-Tradeco
WZ
Transco
Transco
--Transco
-Genco
-Tradeco
-WZ
EZ
Transco
CZ
WZ
-EZ
Tradeco
Tradeco

Pref-3
CZ
--Transco
EZ
--Genco
Genco
-Genco
Tradeco
Genco
-EZ
Genco
-Transco
-Transco
Transco
--Tradeco
---Genco
--Tradeco
--Transco
-EZ
Transco
Genco

Pref-4

Pref-5

---Transco
EZ
----------EZ
-----------------Genco
--Genco
--

---Transco
EZ
----------------------------------

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
No
No
No
No
Yes
No
No
No
No
No
No
No
Yes
No
Yes
No
No
No
No
No
No
No
Yes
Yes
No
No
No
No
No
No
No
No
Yes
No
No
No
Yes
No
Yes
No
No
No
Yes
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
No
No
No
No
Yes
No
Yes
No
No
No
Yes
No
No
No
Yes
No
Yes
No

<!-- page 21 -->

Order of Preference
SN
757
758
759
760
761
762
763
764
765
766
767
768
769
770
771
772
773
774
775
776
777
778
779
780
781
782
783
784
785
786
787
788
789
790
791
792
793
794

NAME (S/Shri/Smt.)
D G Goswami
Praveen Kumar Bhatnagar
Surendra Pal Singh
Jitendra Shreemali
Atul Arun Desai
D. B. Jain
Naresh Kumar Jain
Rupendra Kumar Sharma
Vivek Bharadwaj
B. N. Chourasia
Ashit Kumar Verma
K. R. Kartha
Harsh Samvedi
Sabyasachi Banerjee
Ghanshyam Prasad Sharma
Shujauddin Khan
Nitin Bhagwat
Jaiprakash Soni
Prashant K. Soni
Manoj Bhide
Prafulla Dixit
Rakesh Kumar Badal
R.P.S.Tomar
Vinay Shankar Mavlankar
A. K. Gupta
M. K. Chaturvedi
Prakash Waghmare
Dilip Kumar Jain
Mohd. Shahnawaz
Anil Bajpai
Atulkant Dixit
Shivcharan Karode
Pradeep Kumar Pandey
K. K. Karma
Sharad Kumar Gupta
R. R.Koshta
Prakash Sajan Rokde
Dhirendra Kumar Khare

Employee
Number

97390148

89398380
92383890
85970034
91111582
81975334
85975595
86058292
91055251
91117118
81970369
86035003

92383171
89471724
84612521
83393890
90463736
90296210
91011568
91114701
90443373
93410593
91410975
90294321
90294305
90043496
91112738
85057769
90293877

Designation
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (T&D)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
JE (Gen)
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE (Civil)TBPS
AE(Civil)TBPS
AE(Civil)TBPS
JE (Civil)

Place of Posting
EE(STC)JBP
EE(O&M) Dn. CZ, Datia
EE (O&M) South Dn, EZ, Damoh.
EE(O&M) Dn. WZ,Khangone
EE (MT)Dn., CZ, Gwalior
SE(O&M), ,Chanderi
SE (O&M) Pench, Totladoh.
SE (O&M), MHPS, Shivpuri
SE (O&M), MHPS, Shivpuri
SE (O&M), , Shivpuri
SE (OPN) -I, , Sarni.
OSD (R.O.), Tradeco, Bhopal.
SE,ET&I,SGTPS,Bir'pur
SE,ET&I,SGTPS,Bir'pur
SE(ET&I), II, Birsinghpur
RABSHPS,Barginagar
SE (OPN) MM-III, Genco, Sarni
CE (Gen) Genco, Sarni.
210 MW (ATPS),Genco, Chachai
EE ( C ) C&M-II, Sarni
STPS, Genco, Sarni
EE (Civil) No.5, Genco, Rewa
EE (Civil)-II, Mandleshwar
EE (Civil), CZ, Gwalior
EE (Civil)-II, Mandleshwar
EE(Civil)-II ,SSTPP,Khandwa
SE (Civil) CZ, Bhopal
SE(O&M) , EZ, Sagar
EE (C ) S&I, Rewa
O&M Dn., Jabalpur
SE(O&M) CZ, Bhopal
EE(Civil)-II ,SSTPP,Khandwa
EE(Civil)-II ,SSTPP,Khandwa
EE(Civil)-I ,SSTPP,Khandwa
Corporate Office,Indore
EE(Civil)-I ,SSTPP,Khandwa
EE ( C ) C&M-II, Sarni
SE (Civil) S&I, M/M, JBP

Present
Company /
MPSEB
EZ
CZ
EZ
WZ
CZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
CZ
Genco
Genco
CZ
EZ
Genco
EZ
CZ
Genco
Genco
Genco
WZ
Genco
Genco
Genco

Pref-1

Pref-2

Pref-3

Pref-4

Transco
Transco
Tradeco
Transco
Tradeco
Transco
Transco
Transco
Transco
EZ
Tradeco
Tradeco
Transco
Transco
Transco
Tradeco
Tradeco
CZ
Transco
Transco
Tradeco
Transco
Transco
Transco
WZ
Transco
Genco
Transco
Tradeco
Genco
Tradeco
Transco
Transco
Transco
Tradeco
Transco
Transco
Tradeco

-Genco
-WZ
Transco
CZ
Tradeco
-----Tradeco
Tradeco
Tradeco
-Tradeco
-Tradeco
Tradeco
--Transco
-Transco
-EZ
-Transco
Genco
Genco
-----Tradeco
Tradeco

-Tradeco
----EZ
---------Tradeco
-----WZ
------Genco
CZ
--------

------WZ
---------Tradeco
------------Genco
CZ
--------

Pref-5
-----------------------------Genco
---------

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
No
No
YES
NO
No
No
Yes
No
--------------No
No
No
No
Yes
Yes
Yes
Yes
NO
NO
NO
NO
No
No
No
No
Yes
No
YES
NO
No
No
No
No
No
No
Yes
Yes
No
No
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
Yes
No
No
Yes
Yes
Yes
No
---

<!-- page 22 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

795
796
797
798
799
800
801
802
803
804
805
806
807
808
809
810
811
812
813
814
815
816
817
818
819
820
821
822
823
824
825
826
827
828
829
830
831
832

Satendra Singh Chouhan
Prafulla Kumar Thakkar
Anurag Agnihotri
V. K. Ratley
Sanjay Kumar Neema
Mahesh Kumar Sharma
Sudhir Joseph
Laxminarayan Tiwari
Natthe Khan
Shailendra Kumar Awasthi
Raj Kumar Gupta
P. R. Mirchandani
Mahesh Kumar Sharma
Arun Kurapa
Vijay Kumar Agrawal
Mukesh Kumar Sachadeva
S. K. Upadhayay
T. R. Sahu
Gajraj Singh
Anil Kumar Shrivastava
Suresh Kumar Chouhan
Nagendra Kumar Lakhera
P. K. Sharma
A. K. Gupta
Nitin Kumar Hinge
Padamakar Gajbhiye
Suresh Kumar Singh
Rajiv Sharma
Vinod Kumar Diwan
Deendayal Ramtake
Rajendra Kumar Soni
Alok Chakra Naik
Narendra Singh Bundela
Pradeep Kumar Gupta
Vinay Kumar Shrivastava
Sudeep Kumar Jain
Amar Das Sameriya
Santosh Kumar Verma

Employee
Number
83395607
90463264
91017300
86424379
86423108
87610563
85970423
90462944
91011576
93111043
81972612
93057510
93057726
91411057
94387543
90295709
81972513
88380901
89446818
86440995
90463512
84347226
87520904
90463736
87520300
91113463
95320361
92441342
91972230
90297218
90294313
90461342
91553881
93057528
94320552
95322580

Designation
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)
JE (Civil)

Place of Posting
EE( Civil)Gwalior
Area Store, Ujjain
Civil Sub. Dn. Katni
Flying Squad Satna
On deputation to MPRRDA,
SE (City) Gwalior
Chief (Vig.) JBP
EE (City), WZ, Khandwa
EE (Civil-OPN) Dn., Chachai
Addl. EE (Civil), Chhindwara
EE (O&M) Dn Jabalpur
EE (O&M) Dn., Lahar
EE (Civil) Guna
SE (Civil) S&I, , Bhopal
SE (Civil) S&I, , Bhopal.
AE (Civil) EZ, Satna.
EE (City) Dn. South, JBP.
EE (Civil)Gwalior.
EE O&M Dn.Narsinghpur
Addl. Secy. Jabalpur.
EE(O&M) Dn Badwani
EE (Vigilance) EZ, Mandla
EE (City) East Dn Ujjain.
EE (C ) Dn.MHEP,Mandleshwar
EE(Civil) Dn.WZ, Ujjain
EE (O&M) Sansour, East Zone
South Dn., Bhopal
AE Sub Dn. (Civil),EZ Damoh
EE (City) E.Dn,EZ, JBP
EE (City) W.Dn,EZ, JBP
EE(Civil)-II ,SSTPP,Khandwa
EE(Civil)-II ,SSTPP,Khandwa
EE (City) Dn. EZ, Sagar
SE(O&M) , EZ, Sagar
STPS, Genco, Sarni
EE(O&M) , EZ, Beena
EE(Civil)-II ,SSTPP,Khandwa
STPS, Genco, Sarni

Present
Company /
MPSEB
CZ
WZ
EZ
EZ
WZ
CZ
EZ
WZ
Genco
Transco
EZ
CZ
CZ
Genco
Genco
EZ
EZ
CZ
EZ
EZ
WZ
EZ
WZ
Genco
WZ
EZ
CZ
EZ
EZ
EZ
Genco
Genco
EZ
EZ
Genco
EZ
Genco
Genco

Pref-1

Pref-2

Pref-3

Pref-4

Transco
Transco
Transco
Transco
Transco
Genco
Tradeco
Genco
CZ
Genco
Genco
Transco
Genco
Transco
CZ
EZ
Tradeco
Genco
Transco
Genco
Genco
Transco
Transco
Transco
Transco
Genco
CZ
Genco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco

CZ
Genco
Tradeco
Genco
WZ
Transco
Transco
-Genco
-Transco
CZ
Transco
CZ
Tradeco
Genco
Transco
Transco
Genco
Tradeco
Genco
Genco
WZ
-Genco
Genco
-Transco
Transco
Transco
---Genco
Tradeco
----

Genco
-EZ
Tradeco
-Tradeco
Genco
---Tradeco
Tradeco
WZ
Genco
Genco
Transco
Genco
CZ
Tradeco
Transco
Transco
-Genco
-WZ
--CZ
-----Tradeco
-----

Tradeco
--EZ
-CZ
EZ
---EZ
-EZ
-Transco
Tradeco
-Tradeco
EZ
-----CZ
--EZ
-----------

Pref-5
WZ
--CZ
--CZ
-----CZ
----WZ
------EZ
--WZ
-----------

Option
Option
for
for
personal Associati
hearing on/ Union
------------------------------------------------------No
No
No
No
No
No
Yes
No
Yes
No
Yes
Yes
No
No
No
No
Yes
No
Yes
No
Yes
No

<!-- page 23 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

833
834
835
836
837
838
839
840
841
842
843
844
845
846
847
848
849
850
851
852
853
854
855
856
857
858
859
860
861
862
863
864
865
866
867
868
869
870

Chetan Kumar Jaiswal
S.K. Shukla
Mukul Mehrotra
Manjit Singh
Arun Kumar Geety
Swapnaja Okhade
Shishir Kumar Tiwari
Rajesh Kumar Parashar
S K Agarwal
M. M. Bhave
Alok Kumar Mishra
R. Vidyadharan
Shashi Kumar Tiwari
Shiv Kumar Khare
Satish S Dighe
M.I.Khan
Mahendra Kumar Sharma
Subhash Chand Mishra
Smt. Sunanda Sinhal
V. K. Upadhyay
Rajeev Mehta
Alok Shrivastava
Dilip Gopalrao Shahoo
Krishna Kumar Shukla
Kashi Patil
T. P. Chourasia
G. Ravindranathan Nair
P. A. Johnson
Sudevan B.K.
P.K.Gopalkrishnan Nair
Thomas Varghese
Ranjna Pendore
Maheshwari R.Varan
Dhaniram Dhurve
Sandeep Pendore
John Mathew K
Kalpana Munje
Makhan Lal Soni

Employee
Number
82976141
82977271
91048073
89970924
92057560
89972614
90295626
85051794
89970254
91970846
93421145
86057527
93972816
81974824
92340354
89971500
89971228
90290882
90441112
88445118
85421087
93972931
81978288
83978393
92052132
83979383
83970060
92450020
85449617
95970256
95970339
84972742
93010162
93010279
89324675
84972800
91538826

Designation
Addl.Dir.(F&A)
Addl.Dir. (F&A)
Jt.Director (F&A)
Jt.Director (A/cs)
Jt.Director
Jt.Director
Jt.Director
Jt. Director(A&CM)
Jt. Director (A/c)
Dy. Director
Dy. Director
A.O.
A.O.
A.O.
A.O.
IRO
Welfare Officer
Welfare Officer
Welfare Officer
Sr. Law Officer
Law Officer
Law Officer
Staff Officer
Staff Officer
Staff Officer
P.S.
P.S.
P.S.
P.S.
P.S.
P.S.
P.A.
P.A.
P.A.
P.A.
P.A.
P.A.
P.A.

Place of Posting
Director (Fin), Tradeco,JBP
Addl.Director ,EZ, JBP
Director (Fin), Tradeco,JBP
ED (Finance), JBP
OSD (R.O.), Tradeco, Bhopal.
CFO, EZ, JBP
Director (Fin), Tradeco,JBP
Genco, Jabalpur
Transco, Jabalpur
Dy. Dir (P&PF) , MPPTCL, JBP.
RO, MP Tradeco, Bhopal.
GM (F&A), Tradeco., JBP
Sr.AO (JC), EZ, JBP
Jt. Dir. (B&CM), Tradeco,JBP
Addl.Dir. (B&CM)
IRO
Addl. Secy JBP
IRO
CE(JR), EZ, JBP
Addl. Secy. Jabalpur
Sr.Law Officer
ADDL. SECRETARY (S)
ADDL. SECRETARY
ADDL. SECRETARY
CE (JR) EZ, Jabalpur
ADDL. SECRETARY
CMD JBP.
ADDL. SECRETARY
ADDL. SECRETARY (S)
Secretary
Dir. (V&S), Tradeco, Jabalpur.
ADDL. SECRETARY (P)-I
IRO
CE (Gen), Chachai
CGM (BR)Bhopal.
OSD (R.O.), Tradeco, Bhopal.
CMD Bhopal.
CE (RR),EZ,Rewa

Present
Company /
MPSEB
Tradeco
EZ
Tradeco
Genco
Tradeco
EZ
Tradeco
Genco
Transco
Transco
Tradeco
Tradeco
EZ
Tradeco
Tradeco
MPSEB
EZ
MPSEB
EZ
EZ
MPSEB
MPSEB
MPSEB
MPSEB
EZ
MPSEB
EZ
MPSEB
MPSEB
MPSEB
Tradeco
MPSEB
MPSEB
Genco
CZ
Tradeco
CZ
EZ

Pref-1

Pref-2

Transco
Transco
Transco
Genco
CZ
Tradeco
Transco
Transco
Transco
CZ
Transco
Genco
Transco
Transco
Genco
Genco
Genco
Genco
Transco
Genco
Tradeco
Transco
Transco
Tradeco
Genco
Transco
Transco
Transco
Transco
Genco
Genco
Transco
Genco
Transco
Tradeco
Tradeco
WZ
EZ

-Tradeco
--Tradeco
--Tradeco
-WZ
-CZ
Tradeco
Genco
-Tradeco
-Transco
Genco
Transco
-Tradeco
Tradeco
Transco
-Tradeco
Tradeco
Tradeco
Genco
Transco
Tradeco
Genco
Transco
Tradeco
Transco
Transco
-Genco

Pref-3

Pref-4

Pref-5

--

-----

---------Transco
------

EZ
--Transco
----EZ
-Transco
---Transco
-EZ
-Tradeco
-Genco
Genco
--Genco
-Genco
Tradeco
Tradeco
Transco
Tradeco
Tradeco
EZ
-Genco
-Transco

WZ
----Tradeco
-----EZ
-Tradeco
----EZ
--EZ
-EZ
EZ
--EZ
EZ
--WZ
-Tradeco

------

---

---

--EZ
---

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
No
No
Yes
No
No
No
--No
No
Yes
No
Yes
No
No
No
------No
No
Yes
No
No
No
------No
No
No
No
No
No
Yes
No
----No
No
--------No
No
No
No
---------------

<!-- page 24 -->

Order of Preference
SN
871
872
873
874
875
876
877
878
879
880
881
882
883
884
885
886
887
888
889
890
891
892
893
894
895
896
897
898
899
900
901
902
903
904
905
906
907
908

NAME (S/Shri/Smt.)
Smt. Sumanlata Dixit
R.M. Khan
Kamal Kishore Shrivastava
Y K Bhawsar
K Vishwanath
Gopal Krishna Nair
Rajendra Prasad Chouksey
Rupa Kanojiya
Ajay Arnold
Lata Jha
Madan Gopal Sharma
Deepak Kumar Arse
S. S. Reddy
Narendrajeet Singh
Aruna Boriya
N.K. Jain
Jairam Patel
Prakesh Chand Nema
R.P. Pal
Virendra Kumar Shrivastava
VGK Murthy
M. A. Beg
Ajith Prasad V.
Neeraj Dubey
Smt. Sandhya Weekey
L S Thakur
Smt. Usha Patani
Alka Sharma
Arun Kumar Yadav
Chandra Prabha Masih
Mahendra Kumar Soni
Mithoo Lal Jain
Sudhir Kumar Soni
Balvinder Kapoor
Sumitra Pandey
Anita Kothale
Suresh Kumar Chouksey
B.B.Khampariya

Employee
Number
84974598
89322844
83393866
83978443
92053949
92052272
91416543
93571072
83978450
83976173
83976067
89443475
83970093
83977312
95970396
83979821
83974384
93973269
88426182
91970565
95930933
83970078
91971711
85970430
85972279
91970523
83973162
89340219
85975843
81972166
90443497
81977520
85972931
83971159
85972535
85972484
85972121
91970961

Designation
P.A.
P.A.
P.A.
P.A.
P.A.
P.A.
Sr. Steno
Sr. Steno
Sr. Steno
Sr. Steno
Sr. Steno
Sr. Steno
Sr. Steno
Sr. Steno
Sr. Steno
P.A.
Sr. Steno
Sr. Steno
Sr. Steno
Sr Steno
Sr Steno
Sr.Steno
Sr.Steno
Sr. Steno
Jr.Steno
Addl P A
Addl P A
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno

Place of Posting
ADDL. SECRETARY (P)-I
SE (City) CZ, Bhopal
CE(O&M) Hydel, Genco,JBP
Addl Dir (B&CM)
ED(HR&A) Genco, JBP
STPS, Genco, Sarni
EE (O&M) Dn., EZ Katni
GM (O&M) CircleRajgarh
CE (JR) Jabalpur
CE (JR) EZ, JBP
SE (AMR) Jabalpur
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
CE(O&M-Pur),EZ,JBP
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
SR. L.O.
ADDL. SECRETARY (P)-I
CMD, WZ, Indore
Addl.Secy.EZ,JBP
Jt.Dir (A/cs), Jabalpur
ADDL. SECRETARY
CE(PRG), Genco,JBP
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (S)
CE (O&M-P) JBP
SE (O&M) Cir., JBP
IRO
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (S)
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I

Present
Company /
MPSEB
MPSEB
CZ
Genco
Tradeco
Genco
Genco
EZ
CZ
EZ
EZ
EZ
Tradeco
Tradeco
EZ
MPSEB
MPSEB
MPSEB
MPSEB
WZ
EZ
Tradeco
MPSEB
Genco
MPSEB
MPSEB
EZ
EZ
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
CZ
CZ
Transco
Tradeco
Tradeco
Tradeco
WZ
Transco
Transco
Transco
Tradeco
Tradeco
EZ
Transco
Transco
Tradeco
Transco
Transco
Tradeco
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Tradeco
Tradeco
Transco
Tradeco

Genco
-Genco
Genco
Transco
--WZ
Tradeco
Genco
-Transco
Transco
Transco
Genco
Genco
Genco
Tradeco
Transco
-Tradeco
Tradeco
-Transco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Genco
Tradeco
Transco
Tradeco
Tradeco
Transco
Genco
Tradeco
Transco

--Transco
EZ
Genco
--WZ
EZ
Tradeco
-WZ
WZ
Genco
Tradeco
Tradeco
Transco
Genco
Transco
----Genco
Genco
-EZ
Genco
Genco
Tradeco
Genco
EZ
Genco
Genco
Genco
Transco
Genco
Genco

---

---

WZ

EZ

-----Genco
--EZ
-Tradeco
EZ
EZ
EZ
EZ
-----EZ
EZ
--EZ
EZ
EZ
EZ
Genco
EZ
EZ
EZ

--------Genco
---

---

---------

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
No
No
Yes
No
Yes
No
No
No
Yes
No
------------------------No
No
No
No
Yes
No
No
No
Yes
No
--No
No
No
No
Yes
No
-----------------------

<!-- page 25 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

909
910
911
912
913
914
915
916
917
918
919
920
921
922
923
924
925
926
927
928
929
930
931
932
933
934
935
936
937
938
939
940
941
942
943
944
945
946

Ashok Kumar Saxena
Ramnaresh Sharma
Khamraj Patley
Usha G. Nair
Mukesh Kumar Gupta
Rajendra Kumar Hingare
Suresh Kumar Dongre
Rakesh Kumar Soni
Girish Kumar Sharma
Suman Raikwar
C. F. Wilson
Manoj Nair
Rajnish Pawar
Waman Rao Deshmukh
Kulvinder Kaur Grover
Anil Kumar Thakre
Kaushlendra Tiwari
Munendra Prasad Pandey
Raghuraj Singh
Prem Kumar Malviya
Pradeep Kumar Joshi
Jaya Keswani
Deepak Singh Rahangdale
Ram Gopal Soni
Yogendra Kumar Patwari
M.S. Sahu
M K Tiwari
Shivprakash Shukla
M. H. Ahmed
S. K. Mankar
Harish Jangde
Jagdish Prasad Soni
Rajnish Kumar Khampariya
Bhupinder Singh Rajput
Rajendra Kumar Patel
Mohd. Wahid
Smt Kamini Tiwari
Mrs Anita Harsh Pillai

Employee
Number
88362122
83393627
93350022
85971990
92054178
92053543
91971159
88391825
85974465
89324808
94327671
89324733
94327689
90440346
91972123
91971877
91110113
91539120
94327887

85054581
85972485
88443088
85975851
89550255
89446585
89535339
85972915
89567747
91114593
85973194
91972305
89436116
91971232

Designation
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno

Place of Posting
SE (O&M), WZ, Shajapur
City Dn. Central, Gwalior
SE (O&M) EZ, Tikamgarh
CE (O&M-Pur) Jabalpur.
CE (FS) Jabalpur.
CE (Gen), Sarni.
CE (Gen), Sarni
Chief (Vig.) JBP
EE (City) Dn. SGwalior
EE (MT) Dn Jabalpur.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal
CE (JR) Jabalpur
CE (JR) Jabalpur
CMD JBP.
CE (RR),EZ,Rewa
CE (RR),EZ, Rewa
EE(O&M) Dn.CZ,Vidisha
SE (O&M), Gwalior
EE (EHT) Constn., Transco, Damoh.
CE(JR)EZ, JBP
SE (EHT) Conts., Transco, Bhopal
Secretary
SE (O&M), EZ, Narsinghpur
CE (O&M-P) JBP
EE(O&M) Dn., EZ, Sagar
EE(Store), EZ, JBP
Addl. Secy. EZ, JBP
CMD (EZ), JBP
SE(O&M), EZ, Shahdol
CE (Works-Pur) Jabalpur
IRO
Joint Dir(A/cs),Jabalpur
CE (Commercial),JBP
CE (PRG), MPPGCL,JBP
CE (PRG), MPPGCL,JBP

Present
Company /
MPSEB
WZ
CZ
EZ
EZ
EZ
Genco
Genco
EZ
CZ
EZ
Tradeco
Tradeco
Tradeco
Tradeco
EZ
EZ
EZ
EZ
EZ
CZ
CZ
Transco
EZ
Transco
MPSEB
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
MPSEB
Tradeco
EZ
Genco
Genco

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Tradeco
WZ
Tradeco
Genco
CZ
CZ
Transco
Tradeco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
Tradeco
EZ
EZ
Tradeco
Transco
EZ
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Genco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco

Transco
Transco
CZ
Transco
---Tradeco
Transco
EZ
Transco
Transco
-Transco
-Genco
Transco
-Genco
Transco
Genco
-Transco
Tradeco
Genco
--Tradeco
Tradeco
--Tradeco
Transco
Tradeco
Genco
----

Genco
--Genco
---Genco
Genco
-CZ
CZ
-CZ
-Transco
--Transco
-Tradeco
---Tradeco
--Transco
---Genco
Transco
------

-----------

-----------

WZ
WZ

EZ
EZ
--

WZ

-EZ

-----------------EZ
Transco
------

------------------Transco
------

Option
Option
for
for
personal Associati
hearing on/ Union
------------------------------------------NO
NO
No
No
Yes
No
No
No
Yes
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
Yes
No
Yes
No
No
No
Yes
No
Yes
No

<!-- page 26 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

947
948
949
950
951
952
953
954
955
956
957
958
959
960
961
962
963
964
965
966
967
968
969
970
971
972
973
974
975
976
977
978
979
980
981
982
983
984

Smt. Pratima Soni
Ramnath Ghoghare
PK Shrivastava
Smt Sarojini Solanki
Smt Christina Suresh
A K Parashar
Vidanesh Kumar Malviya
Ajit Kumar Rai
Sanjeev Seth
Ashok Kumar Gupta
Sabu Kuruvilla Mathew
R. R. Kushwaha
D. L. Babu
Chandra Kant Dave
Parvez Alam
Satish S. Motiwale
Ajay Kumar Gupta
Piyush Gupta
Prabodh Kumar Khare
Rajendra Kumar Pahurkar
Praddep Kumar Tiwari
Rakesh Kumar Pathak
Pankaj Swamy
Dr. Sunil Kumar Verma
Dr. Anil Kumar Agnihotri
Dr. Vijaya Agnihotri
Dr. D. S. Rana
Dr. Parineeta Tembhurne
Dr. Ashok Kumar Sharma
Dr. Uma Sharma
Sheela Roy
Dr. Pankaj Verma
Dr. Mrs. Anita Verma
N. D. Pradhan
A.H. Shah
B.L. Kosta
S. K. Sen
AP Tiwari

Employee
Number
89436215
91972396
89431199
93973434
81974113
91115757
89471294
81974477
89973109
82976034
89973067
82976852
83972065
85972071
88971603
83972157
85053303
92057552
90015355
92057735
93970281
93972956
94050027
90297027
90297035
92057578
93110285
82979129
82979186
91570845

89550072
85445235
84971653
84970473

Designation
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Jr.Steno
Steno Typist
Programmer
Programmer
Programmer
Sr. EDP Officer
EDP Officer
Punch Room Supervisor
Operation Supervisor
Operation Supervisor
Sr.Chief Chemist
Sr. Chemist
Sr.Chemist
Sr.Chemist
Chemist
P.R.O.
Publicity Officer
SR. M.O.
Medical Officer
Medical Officer
Medical Officer
Medical Officer
Medical Officer
Medical Officer
Medical Officer
Medical Officer
Medical Officer
Senior Ado.
Ad.O.
Ad.O.
Ad.O.
Ad.O.

Place of Posting
Jt.Dir (A/cs), Jabalpur
CE (O&M-Pur) Jabalpur.
EZ, Jabalpur
CE (O&M:Hydel)JBP
CE (R&M),Genco,JBP
SGTPS, Birsinghpur
STPS, Genco, Sarni
EE (Area Store), EZ, JBP
ED (CS&A) Jabalpur.
On deputation MPERC,Bhopal
EZ, Jabalpur
ED (CS&A) Jabalpur
ED (CS&A) Jabalpur.
RMS Cell JBP
Under Addl. Secy JBP
CE (RAPDRP-ADB),EZ,JBP
CE(Gen),Sarni
STPS, Genco, Sarni
Sr. Chief Chemist, Sarni
Sr. Chief Chemist, Sarni
Sr. Chief Chemist, Sarni
PRO
PRO
Hospital, ., Sarni
Hospital, Sarni
Hospital, Sarni
Hospital, Ujjain
SE (O&M) ., Bargi Nagar
Chief GMGwalior.
Chief GMGwalior.
Sehore Dispensary
STPS, Genco, Sarni
STPS, Genco, Sarni
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (S)
ADDL. SECRETARY
SGTPS, Birsinghpur

Present
Company /
MPSEB
Tradeco
EZ
EZ
Genco
Genco
Genco
Genco
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
Genco
Genco
Genco
Genco
Genco
MPSEB
MPSEB
Genco
Genco
Genco
WZ
Genco
CZ
CZ
Transco
Genco
Genco
MPSEB
MPSEB
MPSEB
MPSEB
Genco

Pref-1

Pref-2

Pref-3

Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
CZ
Transco
Transco
Transco
Transco
Transco
EZ
Tradeco
Transco
Genco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
CZ
CZ
CZ
Tradeco
CZ
CZ
CZ
CZ
CZ
Transco
Transco
Genco
Transco
Transco

Tradeco
Tradeco
Tradeco
Tradeco
---Transco
-WZ
Genco
Genco
Genco
--EZ
Transco
Tradeco
Transco
Genco
Transco
EZ
EZ
-WZ
WZ
-Genco
---WZ
WZ
Tradeco
Tradeco
Tradeco
Tradeco
--

-Genco
Genco
----EZ
-Transco
-EZ
Tradeco
---Genco
-Tradeco
Transco
Genco
Transco
Transco
-Tradeco
Tradeco
-Transco
---Tradeco
Tradeco
Genco
Genco
Transco
Genco
--

Pref-4
---------------------Genco
Genco
----EZ
-----EZ
EZ
EZ
EZ
--

Pref-5
----------------------

----CZ
------

--

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
No
No
Yes
No
Yes
No
No
No
No
Yes
Yes
No
No
No
--Yes
Yes
Yes
No
----------Yes
No
Yes
Yes
Yes
No
Yes
No
Yes
No
------------------Yes
No
Yes
No
Yes
No
--------No
Yes

<!-- page 27 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

985 Pramod Kagde
986 Vijay Kumar Doiphode
987 Ganpat Prasad Arya
988 Hari Prasad Jawarkar
989 Suresh Chandra Choudhary
990 Hari Singh Jatav
991 Prafull Kumar Beohar
992 J N Rathore
993 M. K. Kanojiya
994 Radha Sengar
995 Krishan Kumar Gupta
996 Subhash Kumar Sijariya
997 R. C. Keshwani
998 Baban Kamle
999 Dilip Kukde
1000 I. K. Agrawal
1001 Sunil Singh Chandel
1002 K. N. Yadav
1003 Shankarlal Shayk
1004 Prem Nath Dawne
1005 Hariom Raipure
1006 Ashok Kumar Dubey
1007 B.N. Das
1008 Rambali Gupta
1009 Rajendra Kumar Agrawal
1010 Deep Lal Patel
1011 Usha Deshkar
1012 S. S. Thakur
1013 Vijay Kumar Dongre
1014 R. D. Brahma Bhatt
1015 Aditya Pratap Singh
1016 Ramesh Kumar Bisoriya
1017 Premdas Mane
1018 Sudesh Kumar Likhar
1019 Ramakant Dubey
1020 M. L. Burman
1021 A. K. Bachkaiya
1022 S. K. Mishra

Employee
Number
92050128
81970533
89398654
90569029
90562040
91323640
87436969
93571379
85973921
84972296
81978189
83977734
84979457
84971090
86440855
83619799
92383304
87438642
87436068
84970622
84970762
88444128
84979340
83970813
92054822
84971802
84367596
89534811
84364916
83392447
88391782
91531417
90566836
88440092
91531342

Designation
Ad.O.
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
Section Officer
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I

Place of Posting
STPS, Genco, Sarni
Tradeco, Jabalpur
EE (City) S. DnGwalior
RAO Sidhi
RAO Sidhi
EE(O&M) Dn.CZ,Vidisha
CE(JR) JBP
City Dn.(S), Bhopal
EE (O&M) Dn.,Rajgarh
ADDL. SECRETARY (P)-I
PRO
ADDL. SECRETARY (P)-I
ADDL. SECRETARY
ADDL. SECRETARY
Sr. A. O. WZ, Dewas.
IRO
ADDL. SECRETARY (S)
AO , CZ, Morena
AO , CZ, Morena
Jt.Dir (A/cs), Jabalpur
STPS, Genco, Sarni
ADDL. SECRETARY
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (S)
CE(SR) EZ, Sagar
Chief (Vig.) EZ, JBP
EE (STC) Dn Ujjain
EE (City) Dn Satna
EE (O&M) Dn Shujalpur
City Dn, EastGwalior
EE (City) S. Dn.Gwalior
EE ( City ) Dn. Rewa.
SE (E.T & I)-III, Birsinghpur
EE (O&M) Dn Gadarwara
SE (OPN)-III, , Birsinghpur.

Present
Company /
MPSEB
Genco
Tradeco
CZ
EZ
EZ
CZ
EZ
CZ
CZ
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
WZ
MPSEB
MPSEB
CZ
CZ
Tradeco
Genco
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
EZ
EZ
WZ
EZ
WZ
CZ
CZ
EZ
Genco
EZ
Genco

Pref-1

Pref-2

Tradeco
Transco
Tradeco
Genco
Genco
Tradeco
Tradeco
CZ
WZ
Tradeco
Tradeco
Transco
Transco
Transco
Genco
Tradeco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
EZ
Genco
CZ
Transco
Tradeco
Genco
EZ
Transco
Transco

-Genco
Transco
Transco
Transco
Transco
Transco
-WZ
Transco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
Genco
Tradeco
-Transco
Tradeco
Genco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Genco
EZ
Transco
Transco
-Transco
Transco
Transco
Tradeco
Tradeco

Pref-3

Pref-4

Pref-5

--

----------

----------

--------

--------

EZ
EZ
EZ
EZ
EZ
EZ
Transco
-EZ
---------

Transco
-EZ
---------

EZ
-Tradeco
Tradeco
---WZ
Genco
Genco
Genco
Genco
Genco
Transco
--Tradeco
EZ
--Genco
Tradeco
Genco
Genco
Genco
Genco
Transco
-EZ
----Tradeco
--Genco

EZ
EZ
EZ
EZ
EZ

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
Yes
No
------------------------YES
YES
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
-----------------------------------

<!-- page 28 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1023 Bharat Bhushan Sharma
1024 Madhusudhan Bhattacharya
1025 Nandkishore Chowkikar
1026 K. B. Gambhir
1027 Rekha Gupta
1028 Sudhma Prasad Soni
1029 Suresh Kumar Dubey
1030 D. V. Chaudhari
1031 Sandhya Sharan Namdeo
1032 R. K. Burman
1033 Rajneesh Raikwar
1034 A. P. Singh
1035 N. K. Birtharia
1036 Gopal Das Gupta
1037 Sashikant Chaturvedi
1038 Pandhari Nath Mandlekar
1039 Krishandeep Saxena
1040 A.N.Chaturvedi
1041 Chandrashekhar Burman
1042 Ravibala Gupta
1043 Sanjay Kumar Deopujari
1044 Prakash Mishr
1045 Sarvesh Kumar Singh
1046 Subhash P Rambhal
1047 Rajnish Kumar Pathik
1048 Girja Shankar Saxena
1049 Dilshad Khan
1050 Vishnupant Joshi
1051 Sushil Kumar Gupta
1052 Ramesh Chandra Chouhan
1053 Ajay Kumar Noriya
1054 Jagesh Jharia
1055 D. P. Ahuja
1056 Ashok Kumar Kori
1057 Chandraprakash Shrivastava
1058 Jagdeo Dubey
1059 Ashok Govind Talegaonkar
1060 Smt. Sandhya Bairagi

Employee
Number
92320661
94320925
87470075
92480713
91560846
90565390
89323529
87449291
90465020
92340130
92430279
90567289
88440309
87382949
92357350
92056273
83390045
88447155
84975019
87436786
87441365
91531326
89560329

83478923
84618320
92340536
85440848
94321006
89559288
84613692
92350097
89398240
88432347

Designation
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I

Place of Posting
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
RAO Indore.
A.O. (O&M), CircleBhind
EE (O&M) Dn Anuppur.
RAO Sidhi
SE (Civil) EZ, Rewa.
Sr. A.O Chhindwara
EE (O&M) Dn Mandla
CE (Works-Pur) JBP.
EE (O&M) Dn Lakhnadon
EE (City) Dn. Satna
EE (O&M) Dn Gadarwara
(O&M) Dn Guna
EE (O&M) DnGanjbasoda
CMDBhopal.
EE City Central Dn.,CZ,Gwalior
CE(JR) JBP
CE(O&M-Pur),EZ,JBP
EE (City) E. Dn.JBP
CE(JR) JBP
CE (RR),EZ, Rewa
CE (RR),EZ, Rewa
City Dn.(S), Bhopal
City Dn.(S), Bhopal
Sr. A.O. WZ, Dewas
Sr. A. O. WZ, Dewas.
Sr. A. O. WZ, Dewas.
RAO, WZ, Indore.
RAO, Transco, WZ, Indore
EE (FS), EZ, JBP
EE(O&M) Dn. EZ, Mandla
SE (City) CZ, Bhopal
Dir. (V&S), Tradeco, Jabalpur.
EE(O&M) Dn. CZ, Gwalior
EE( City) W. Dn., EZ, JBP
SE (City) Circle Gwalior.
EE (City) W. Dn. EZ, JBP

Present
Company /
MPSEB
Tradeco
Tradeco
Transco
CZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
CZ
CZ
CZ
CZ
EZ
EZ
EZ
EZ
EZ
EZ
CZ
CZ
WZ
WZ
WZ
WZ
WZ
EZ
EZ
CZ
Tradeco
CZ
EZ
CZ
EZ

Pref-1

Pref-2

Tradeco
Tradeco
Genco
Transco
Genco
Genco
Transco
Tradeco
Transco
Genco
Transco
Genco
Tradeco
Transco
Transco
CZ
Transco
Transco
EZ
Transco
Genco
EZ
-CZ
CZ
Transco
Transco
Transco
WZ
WZ
Tradeco
Transco
CZ
Tradeco
Transco
Genco
Transco
Genco

Transco
-Genco
Tradeco
Genco
Transco
Tradeco
Transco
WZ
-Genco
Transco
Tradeco
---Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
-------WZ
Transco
Tradeco
--Transco
--Transco

Pref-3
CZ

Pref-4
WZ

--CZ
-Tradeco
CZ
-Genco
-Genco
-Tradeco
-----Genco
-Tradeco
Genco
-------WZ
-Genco
--Transco
--Tradeco

--WZ
--EZ
---Genco
-Tradeco
--------CZ
-------WZ
----Transco
----

Pref-5
Genco
---------Genco
-Tradeco
--------WZ
-------WZ
----Transco
----

Option
Option
for
for
personal Associati
hearing on/ Union
--------------------------------------------------YES
NO
YES
NO
YES
NO
NO
NO
Yes
No
Yes
No
Yes
No
No
No
No
No
Yes
Yes
No
No
Yes
Yes
No
No

<!-- page 29 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1061 S.R. Mandsourwale
1062 Smt. Jyoce Gadekar
1063 S. A. Qureshi
1064 Rajesh Kumar Choubey
1065 P.D. Singh Baghel
1066 Kashi Prasad Verma
1067 Dayanand Dwivedi
1068 Rakesh Kumar Mishra
1069 Brajendra Kumar Singh
1070 D V Choudhary
1071 Ramakant Pagare
1072 Suresh Kumar Namdeo
1073 N K Gupta
1074 Mahesh Kumar Verma
1075 Sudhir Verma
1076 A K Shahi
1077 Smt Shobha Yadav
1078 Narendra Kumar Pandey
1079 Jagannath Gawande
1080 M Moosa Israiz
1081 Salak Ram Pal
1082 A K Shrimal
1083 Suresh Kumar Dhantole
1084 Ramnaresh Singh Parihar
1085 Dinesh Kumar Gupta
1086 Santosh Kumar Gupta
1087 J.P.Patel
1088 Amarjeet Singh Malhotra
1089 Shiv Kumar Vishwakarma
1090 L. N. Ramje
1091 Govind Prasad Shukla
1092 Harish Kumar Chopra
1093 Sharda Prasad Sen
1094 R. S. Rathore
1095 Neeta Shrivastava
1096 Sanjay Kumar Pashine
1097 S. S. Rajpoot
1098 Sanjay Ramchandra Fadnavis

Employee
Number
83397553
83970763
90532845
90536250
90565671
90534742
90534057
92359973
85972332
84978913
84974390
89436761
90356105
91110196
84978129

92053528
84366318
83348027
81970582
81971143
81972456
84970738
84970837
84971744
84971793
84979978
84970655
83970961
84971843
84976603
83977932
84971892
84971298

Designation
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
O.A.GR-I
Addl.OA Gr.I
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-I
O.A.GR-I
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II

Place of Posting
EE ( Central City). Dn., CZ, Gwalior
CE (Works-Pur) Jabalpur
RAO,EZ, Sidhi
SE(O&M), EZ, Satna
SE(O&M), EZ, Satna
EE(O&M), EZ, Sidhi
EE(O&M) N. Dn. EZ,Rewa
EE(O&M) Dn. EZ,Baidhan
RAO,EZ, Sidhi
Sr. A.O. EZ Chhindwada
B&CM, Jabalpur
B&CM, Jabalpur
ED (Finance), JBP
CE (Commercial),JBP
EE City Katni EZ
SGTPS, Birsinghpur
SE (S) II, STPS, Sarni
Dir.(V&S) Tradeco JBP
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
West Dn., Ujjain
EE(O&M) Dn. EZ,Sansour
EE (City )East Dn. JBP.
ADDL. SECRETARY
CE(O&M-Pur), EZ, JBP
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
IRO
PRO
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)

Present
Company /
MPSEB
CZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
Tradeco
Tradeco
Tradeco
EZ
EZ
Genco
Genco
Tradeco
Genco
Genco
Genco
WZ
EZ
EZ
MPSEB
EZ
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Genco
Transco
Genco
Genco
Genco
Transco
Transco
Tradeco
Transco
Transco
Transco
Tradeco
CZ
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Tradeco
Genco
Genco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco

-Transco
Transco
Tradeco
Transco
Transco
Genco
-Genco
--Genco
Genco
Tradeco
EZ
-Tradeco
-Transco
Tradeco
Tradeco
Tradeco
Tradeco
Genco
Tradeco
Genco
Transco
Tradeco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Genco
Transco
Transco
Genco

-Transco
-Genco
Tradeco
-Genco
------Tradeco
-------Genco
Genco
Tradeco
--Genco
Genco
Genco
Transco
Transco
Genco
Genco
Genco
Transco
Genco
Genco
Transco

-Transco
----Genco
------Tradeco
------------EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ

-Transco
-----------Tradeco
-------------

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
Yes
Yes
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
Yes
No
No
Yes
Yes
No
No
No
Yes
No
Yes
No
Yes
No
No
No
Yes
No
--No
No
No
No
-------------------------

<!-- page 30 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1099 Mahesh Prasad Namdeo
1100 Kamal Bhan Singh Senger
1101 Dinesh Kumar Choudhary
1102 M.K. Shrivas
1103 P.K.S.Parihar
1104 Mahesh Kumar Kosthi
1105 Pradeep Kumar Shrivastava
1106 R.K. Bajpai
1107 Rakesh Kumar Mishra
1108 Mayashanker Dubey
1109 R. K. Tiwari
1110 S. K. Bhattachrya
1111 Sanjeev P.Toley
1112 Vinod Kumar Kashyap
1113 Ramesh Kumar Parsai
1114 Surendra Kumar Pathak
1115 R. C. Agarwal
1116 Girish Kumar Acharya
1117 Leelawati Jhariya
1118 Jayant Tiwari
1119 Anil Kumar Gupta
1120 Naresh Kumar Bhanariya
1121 Rakesh Kumar Telang
1122 Rajesh Kumar Shrivastava
1123 Ranjana Dikshit
1124 Prakash Chandra Jain
1125 Anita Bais
1126 Mamevin Pandey
1127 Pushpraj Singh
1128 Ajay Hari Kapre
1129 Dilip Kumar Singh
1130 G. S. Bobada
1131 Mamta Kajve
1132 N. K. Goel
1133 Pramila Chopra
1134 Rajiv Sharma
1135 Vinayak Naik
1136 Anil Kumar Adkane

Employee
Number
88431159
81971028
81971937
84971901
84970812
84977007
84973708
83971026
83974335
81973503
83977775
83974004
84971777
84976116
88433667
83970945
84362168
91540830
85422671
90440065
90340778
92350270
87433734
90531277
90357581
91411197
91411247
90010264
97390098

83977924
81970137
88391114
89394348
83390418
90431949

Designation
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-I
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II

Place of Posting
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
SR. L.O.
SR. L.O.
City Dn. Central, Gwalior.
SE(Civil) Circle, WZ, Ujjain
AE (D/C) Gosalpur
Sr. A.O. (WZ), Indore
Addl. Secy JBP
EE (O&M) Dn Parasia
EE (O&M) Dn. EZ, Tikamgarh
EE( Area Store) JBP
EE (City) Dn Satna
EE (STM) Dn., Chhatarpur
(O&M) DnItarsi
(O&M) DnItarsi
EE (Civil)-I, ., Chachai
EE (City) S. Dn.Gwalior
EE (City) Dn. SGwalior
EE (City) Dn., SGwalior
CE (JR) EZ, JBP
CE (JR) Jabalpur.
EE (City) Dn. S.Gwalior
EE (City) S. DnGwalior
City Dn. SGwalior
EE (O&M) Dn Patan

Present
Company /
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
CZ
WZ
EZ
WZ
EZ
EZ
EZ
EZ
EZ
EZ
CZ
CZ
Genco
CZ
CZ
CZ
EZ
EZ
CZ
CZ
CZ
EZ

Pref-1

Pref-2

Pref-3

Pref-4

Transco
Tradeco
Tradeco
Tradeco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Genco
CZ
Tradeco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
Transco
Transco
Tradeco
Tradeco
Tradeco
Transco

Tradeco
Transco
Transco
Transco
Tradeco
Tradeco
Genco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Tradeco
Genco
WZ
Genco
Transco
-Transco
-Tradeco
Transco
Transco
-Transco
Transco
Transco
Genco
Tradeco
Transco
Transco
Transco
Tradeco

Genco
Genco
EZ
Genco
Genco
Genco
Transco
Genco
Genco
Genco
Genco
Genco
EZ
Genco
Genco
Genco
--Tradeco
-Tradeco
--Genco
-EZ
Transco
--Genco
Genco
Genco
-Genco
-Genco
---

EZ
EZ
Genco
EZ
--EZ
-EZ
EZ
EZ
EZ
Genco
EZ
EZ
EZ
---------CZ
Transco
------------

Pref-5

---------WZ
-------------

Option
Option
for
for
personal Associati
hearing on/ Union
-----------------------------------------------------------------------------

<!-- page 31 -->

Order of Preference
Employee
Number

1137 J. P. Mishra
1138 Rajendra Kumar Kori
1139 Uma Kant Sharma
1140 M. L. Mehra
1141 Ram Shanker Dubey
1142 V. Ramesh Iyer
1143 Abhay Kumar Upadhyay
1144 Arvind Kumar Saraf
1145 C. S. Rajan
1146 Kamal Kumar Jain
1147 Madan Vinayak Shukla
1148 Mukund K. Vaishnav
1149 Raj Prakash Sahu

89535222
83346618
92350691
88440150
86448303
90586818
89324717
89324683
89324709
89324782
83977015
92320587
94321154

O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II

Sr. A.O. EZ, Rewa
EE (O&M) Dn Patan
Sr. A. O Rewa.
EE (O&M) Dn Gadarwara
SE (City) Circle JBP.
EE (City)Dn. South JBP.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
OSD(R.O.), Tradeco, Bhopal.
Dir. (Fin) Tradeco, Jabalpur.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.

Present
Company /
MPSEB
EZ
EZ
EZ
EZ
EZ
EZ
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco

1150 Ramesh Kumar Moolchandani
1151 S. C. Tiwari
1152 Satish Chandra Dubey
1153 Subhash Narayan Kale
1154 Sudhir Vasant Joshi
1155 Yashwant Bagairiya
1156 Ramesh Kumar Mishr
1157 V. K. Nema
1158 Rakesh Chautervedi
1159 Ramkumar Rai
1160 Vinod Kumar Kawle
1161 Arvind Kumar Jain
1162 Rakesh Kumar Upadhyay
1163 Ashok Kumar Verma
1164 Dinesh Shrivastava
1165 Rajesh Beohar
1166 Rekha Shrivastava
1167 Shrikant Raizada
1168 Vijay Singh Thakur
1169 Murarilal Shrivastava
1170 Nagarjun Pandey
1171 Rambaran Soni
1172 S. M. Chitale
1173 Vishnu Prakash Sharma

89322217
94320974
85442414
89322167
95320196
92320950
89560337
85446952
92321909

O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II

OSD (R.O.), Tradeco, Bhopal
OSD (R.O.) Tradeco, Bhopal.
OSD(R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
RAO Sidhi
EE (City) Dn. W Jabalpur.
EE (City) Dn. East Bhopal
EE (City Central )Dn.Gwalior
CE (UR), WZ, Ujjain
EE (O&M) Dn Jabalpur
EE(O&M) Dn JBP
EE (A/s) JBP.
(O&M) Dn. Chhatarpur,
EE (STM) City Dn. JBP.
Sr. A. O. (JC) JBP.
Head (Vig.) EZ, JBP.
EE (O&M) Dn. Narsinghpur
A.O., , Sirmour.
EE (O&M) Dn. Ganjbasoda
IRO
SE (O&M) CZ, Shivpuri.
EE (O&M) Dn Mandsaur.

Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
EZ
EZ
CZ
CZ
WZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
Genco
CZ
MPSEB
CZ
WZ

SN

NAME (S/Shri/Smt.)

84615078
88439516
85440186
88449689
90350777
88432289
84972619
84972312
89433997
92059383
81972968
88383086
84472966

Designation

Place of Posting

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Genco
Transco
Genco
Tradeco
Transco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Tradeco
Tradeco

Transco
Transco
Transco
Transco
Genco
Genco
Transco
Transco
Transco
Transco
-CZ
--

-Transco
Tradeco
-Tradeco
Tradeco
Genco
-Genco
CZ
-WZ
--

-Transco
EZ
---WZ
-CZ
WZ
-Transco
--

------CZ

Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Genco
Transco
Transco
Transco
EZ
Tradeco
Tradeco
Transco
Transco
Transco
Genco
Tradeco
Transco
Transco
Transco
Transco
Tradeco
Tradeco

Transco
CZ
Transco
Transco
Transco
Transco
Transco
Genco
-Transco
EZ
-Transco
Tradeco
--Transco
Transco
-Transco
-Tradeco
Transco
Transco

Genco
-Genco
Genco
CZ
CZ
Tradeco
--Transco
EZ
-Genco
Genco
--Tradeco
--Transco
--WZ
Genco

CZ

WZ

-WZ
EZ
-EZ
--

--WZ
Genco
WZ
-------------Transco
---CZ

--CZ
-Genco
-------------Transco
-----

Option
Option
for
for
personal Associati
hearing on/ Union
-----------------------------------------------Yes
---

---------------------No
---

<!-- page 32 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1174 Jaishankar Soni
1175 Madhukar Khandagre
1176 Anand Kumar Jain
1177 Anil Kumar Majumdar
1178 Atival Prasad Paras
1179 Avinash Kumar Dixit
1180 Ramanuj Verma
1181 Chhedi Ansari
1182 Lekhram Bhor
1183 Siddharth Kumar Mishra
1184 V. K. Ambere
1185 Sharad Chandra Dubey
1186 Subhash Kumar Dahariya
1187 Abhilash Jain
1188 Anil Kumar Vyas
1189 Ashok Kumar Parmar
1190 Chandrashekhar D Golaith
1191 Devendra Kumar Dave
1192 K C Lodhi
1193 Ku. Karuna Shrivastava
1194 Prabhakar Shende
1195 Smt Bharti Gargav
1196 Smt Kamlesh Saxena
1197 Smt Vimla Soni
1198 Sunanda Raxit
1199 Sunita Shrivastava
1200 US Sen
1201 Vinod Kumar Joshi
1202 AB Pandey
1203 Ashok Kumar Mishra
1204 Jai Shankar Prasad Trivedi
1205 OP Kushwaha
1206 R S Dwivedi
1207 Rajkeshar Pandey
1208 Ravendra Prasad Dwivedi
1209 Ashok K Rajput
1210 Om Prakash Kushwaha
1211 Ashok Kumar Pandey

Employee
Number
84478237
85058872
89430556
83363803
93360054
91397768
89530942
85440830
89443681
87449516
87448633
93340072

89566806
89530629
89530496
89566813
89560700
90293100

89539637

Designation
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II

Place of Posting
SE (Civil) S&I, , Bhopal
CE(Gen) Sarni
EE (O&M)Dn Patan
Sr. A. O Dewas
Sr. A.O Dewas
SE (O&M) CZ, Bhind
CE (RR) Rewa
CE(JR) JBP
CE(JR) JBP
Sr.A.O.EZ, Chhindwara
CE(JR) JBP
Addl.Secy.(EZ),JBP
EE(STC) Dn.EZ, JBP
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
CE (RR),EZ, Rewa
CE (RR),EZ, Rewa
CE (RR),EZ, Rewa
CE (RR),EZ, Rewa
CE (RR),EZ, Rewa
CE (RR),EZ, Rewa
CE (RR) Rewa
GM (O&M), Gwalior
GM (O&M), Gwalior
EE (O&M) Dn Rewa

Present
Company /
MPSEB
Genco
Genco
EZ
WZ
WZ
CZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
CZ
CZ
EZ

Pref-1

Pref-2

Tradeco
Tradeco
Transco
Transco
Transco
Transco
-Transco
Tradeco
Genco
Transco
Transco
Transco
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
EZ
-EZ
EZ
EZ
EZ
EZ
Transco
Transco
Genco

Transco
CZ
Tradeco
Transco
Transco
Tradeco
-Genco
Transco
Transco
Genco
-Genco
-------------------Transco
-Genco
WZ
-Transco

Pref-3

Pref-4

Pref-5

---------------------------------

---------------------------------

CZ
------Tradeco
-Tradeco
Tradeco
-Tradeco
-------------------Genco
-Transco
Genco
-EZ

CZ

WZ
--

CZ

-WZ

--CZ

--WZ

Option
Option
for
for
personal Associati
hearing on/ Union
-----------------------------------------------------------------------------

<!-- page 33 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1212 Chandrakant Tiwari
1213 Rajnish Kumar Tiwari
1214 Dinesh Kumar Douraya
1215 Kundanlal Sen
1216 B. K. Sharma
1217 Vriendra Singh Bundela
1218 S.K.Yadav
1219 Vaidhyanath Namdeo
1220 Narendra Kumar Soni
1221 B. K. Nanda
1222 Dharamdas Patel
1223 L. P. Ahirwar
1224 Bal Krishna Gupta
1225 R. K.Vijayvargiya
1226 V.K. Shukla
1227 Surendra Kumar Soni
1228 Ravishanker Choukse
1229 Smt. Anuradha Thakre
1230 Dinesh Shrivastava
1231 Kishor Kumar Nigam
1232 Anant Kumar Singh
1233 Prakash Kumar Rajak
1234 Dhanesh Kumar Pare
1235 Vijay Kumar Jain
1236 Albert Vaigas
1237 Sushilchandra Jain
1238 Laxmikant Mishra
1239 Kiran Khosla
1240 Kanchhedi Lal Soni
1241 Smt. Girija Upadhyay
1242 Smt. Sushma Pillai
1243 Subhash Kumar Vyas
1244 Deepak Dinkar Devshtali
1245 Sudhir Kumar Tiwari
1246 C. S. Jain
1247 Smt. Varsha Sant
1248 Smt. Gargi Babulkar
1249 Syed Asif Masood

Employee
Number
83343424
83344695

83362862
84978319
89560353
90642256
91324241
91531441
93320537
88432297
83363810
90550277
83974319
83977602
83979334
92352283
84971785
84971835
84971884
84973682
87443625
90581868
84975126
84979960
88438930
93320314
95320238
89323081
95320056
85440112
91570373
94328240
93321254
93325156

Designation
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II

Place of Posting
EE(Civil) Dn., EZ,Chhindwara
ADDL. SECRETARY (S)
Sr. A. O. WZ, Dewas
EE (EHT) Transco, Damoh
D/c, Sarangpur, WZ.
Sr. A. O. WZ, Dewas.
SE (O&M), EZ, Narsinghpur
CE (RR), EZ, Rewa.
Sr. A. O. , WZ, Dewas.
EE (City) East Dn., CZ, Bhopal.
CE (RR), EZ, Rewa.
EE (City) East Dn. CZ, Bhopal.
EE,Area Stores,JBP.
EE (City) West Dn., WZ, Ujjain
EE (Store), EZ, Sagar
ADDL. SECRETARY
CE(O&M-Pur), EZ, JBP
CE (Works-Pur) Jabalpur
EE(O&M) Dn. EZ, Chhatarpur
RAO (EZ), Chhatarpur
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
SE (City) Cricle, EZ, JBP.
Area Stores, EZ, JBP
Area Stores, EZ, JBP
CE (O&M-Pur) Jabalpur.
CE (Works-Pur) Jabalpur
EE (City) Dn. ,EZ,JBP
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
Addl.Secy. (EZ),Jabalpur
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal

Present
Company /
MPSEB
EZ
MPSEB
WZ
Transco
WZ
WZ
EZ
EZ
WZ
CZ
EZ
CZ
EZ
WZ
EZ
MPSEB
EZ
EZ
EZ
EZ
MPSEB
MPSEB
MPSEB
EZ
EZ
EZ
EZ
EZ
EZ
CZ
CZ
CZ
CZ
EZ
CZ
CZ
CZ
CZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Transco
EZ
WZ
Transco
Tradeco
EZ
Transco
Transco
EZ
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Genco
Transco
Transco
Transco
Genco
Tradeco
Tradeco
Tradeco
Transco
Transco
Tradeco
Tradeco
Tradeco
Transco
Transco
CZ
CZ
CZ
CZ

Tradeco
Tradeco
Transco
-WZ
Transco
-Transco
Transco
-Transco
-Genco
Genco
-Tradeco
Genco
Transco
-CZ
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
-Transco
Transco
Transco
Tradeco
Transco
-----

Genco
Genco
--WZ
Transco
-Genco
Transco
-Genco
-Tradeco
--Genco
Tradeco
Transco
-Transco
-Genco
-----Transco
-WZ
WZ
WZ
EZ
Transco
-----

----------------

----------------

-Transco
-WZ
-------Transco
-EZ
EZ
EZ
WZ
Transco
-----

-Transco
---------Transco
-Genco
Genco
Genco
Genco
Transco
-----

EZ

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
Yes
No
YES
YES
NO
NO
NO
NO
YES
YES
YES
NO
YES
YES
YES
YES
NO
NO
YES
YES
NO
NO
Yes
No
Yes
No
No
No
--Yes
No
No
No
No
No
No
No
Yes
No
Yes
No
No
No
No
Yes
Yes
No
Yes
No
No
No
No
No
Yes
Yes
No
Yes
No
Yes
No
No
Yes
Yes
Yes
No
No
No
No
No
No
No
No
No

<!-- page 34 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1250 Hemant Kumar Telang
1251 Smt. Kumud Shrivastava
1252 Smt. Rajni Sharma
1253 Smt. Uma Batham
1254 Smt. Sashi Amadakar
1255 Prabhat Kumar Khatri
1256 Suresh Kumar Soni
1257 Avinash Nerkar
1258 Rajesh Kumar Soni
1259 Harish Kumar Agrawal
1260 P.K. Naik
1261 Daan Singh Mehra
1262 Ramesh Kumar Mishra
1263 Dinesh Kumar Sharma
1264 Ravi Kumar Sharma
1265 V. S. Rajput
1266 Laxminarayan Raikwar
1267 Vijay Kumar Choudhary
1268 Rajendra Kumar Neekhar
1269 Rakesh Kumar Jain
1270 Purshottam Lal Shrivastava
1271 Sunderlal Boriya
1272 Rajendra Kumar Jain
1273 Shyamlal Gonekar
1274 Sudeb Bhattacharya
1275 Narendra Kumar Kesharwani
1276 A. K. Shrimal
1277 Anil Kumar Harshe
1278 Anil Mathur
1279 Smt. Nishat Begum
1280 S.P.Jadiya
1281 Shobhnath Tiwari
1282 Deen Bundhu Golchha
1283 Ajay Kumar Dubey
1284 Rajesh Saxena
1285 Gangadhar Dhokekar
1286 Vijay Bakhariya
1287 Smt. Meena Watwani

Employee
Number
90357707
92320892
93320272
89325847
92320927
87433148
90581850
89391799
92384088
85977716
85422549
88395321
92481579
87449367
91412955
92520542
87433114
88447170
87441422
92430759
87449390
93340097
92340288
88430524
88449671
88380117
90355719
81978445
84972536
83973998
89412264
89433971
85420295
83395044

Designation
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II

Place of Posting
SE (City) CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
Jt.Dir.(B&CM),Tradeco,JBP
EE(O&M) Dn. EZ, Shahdol
Dir. (V&S), Tradeco, Jabalpur.
EE(O&M) Dn. CZ, Gwalior
AO (O&M)Cir. CZ, Datia
CE(Pur), EZ, JBP
Sr. A. O., WZ, Indore
EE(O&M) Dn., EZ, Satna
SE (City) CZ, Gwalior
EE (City) N. CZ, Gwalior
EE(City) Dn., EZ, JBP
EE (O&M) Dn. CZ, Hoshangabad
ED (BR) CZ, Bhopal
Sr.AO, JC, Jabalpur
Sr. A.O. (JC), EZ, JBP
SE (O&M) Cir., JBP
EE(Vig.) O&M F.S.02, JBP
EE (City) Dn.EZ, Jabalpur
EE(O&M) Dn. EZ, Amarwara
EE(O&M) Dn. EZ,Sansour
EE (MT) Dn. Jabalpur
EE( City)E. Dn., WZ, JBP
CE(O&M-Pur) Jabalpur
SE(City) CZ, Guna
EE(South) Dn.EZ,JBP
EE(O&M) Dn, EZ, Panna
CFO (EZ), JBP
EE(City) N. Dn. EZ, JBP
Jt. Dir. (B&CM), Tradeco,JBP
Addl.Secy.EZ,JBP
SE (O&M) Cir., JBP
SE(O&M), WZ, Indore
EE ( C City). Dn., CZ, Gwalior

Present
Company /
MPSEB
CZ
CZ
CZ
CZ
CZ
Tradeco
EZ
Tradeco
CZ
CZ
EZ
WZ
EZ
CZ
CZ
EZ
CZ
CZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
WZ
EZ
CZ
EZ
EZ
EZ
EZ
Tradeco
EZ
EZ
WZ
CZ

Pref-1
CZ
CZ
CZ
CZ
CZ
Genco
Genco
Tradeco
Transco
Transco
Transco
Transco
Genco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Tradeco
Transco
Transco
Tradeco
Transco
Transco
Transco

Pref-2

Pref-3

Pref-4

Pref-5

--

------Transco
--EZ
Transco
----Tradeco
-Transco
Tradeco
Tradeco
--Genco
-Genco
-Genco
Genco
--Transco
--------

----------Transco
------Transco
---------EZ
-----------

----------Transco
----------------------------

CZ
CZ
CZ
CZ
-Genco
--WZ
Transco
-Transco
Genco
Genco
Genco
Transco
Transco
Genco
Genco
Tradeco
-Transco
Tradeco
Tradeco
-Tradeco
Transco
-Tradeco
Transco
Transco
Genco
--Tradeco
-Transco

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
Yes
No
No
No
No
No
No
No
No
No
No
No
Yes
Yes
No
Yes
No
No
No
No
No
No
Yes
Yes
Yes
No
No
No
No
No
Yes
No
Yes
No
No
No
No
No
No
No
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
No
No

<!-- page 35 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1288 Rakesh Kumar Tiwari
1289 Ajay Sahatrabudhe
1290 Shankar Singh Panwar
1291 Virendra Kumar Jain
1292 Amarnath Mukherjee
1293 G.P. Mishra
1294 Shalani Raj
1295 Dinesh Chandra Sharma
1296 Satya Prakash Shrivastava
1297 S.K. Goyal
1298 Smt. Pushpa Shukla
1299 Deepak Kumar Bhandari
1300 B.K. Soni
1301 Smt. Veena Shrivastava
1302 Prabhunath Singh Sisodiya
1303 S.K.Dave
1304 Kallu Khan
1305 Anil Kumar Saxena
1306 Rajendra Kumar Tripathi
1307 Raj Narayan Singh Baghel
1308 Kamata Prasad Namdeo
1309 Munnalal Dwivedi
1310 Neeraj Kumar Pandy
1311 Mahendra Pratap Singh
1312 Ram Krishna Gupta
1313 Lakhan lal Tripathi
1314 Praveen Kumar Shrivastava
1315 O P Sharma
1316 C.M. Dubey
1317 Bhimsen Tripathi
1318 Surendra Kumar Tiwari
1319 Ramesh Pd Shukla
1320 Santosh Kumar Dave
1321 Sudama Singh Thakur
1322 Ajay Kumar Raikwar
1323 Manjula Choudhary
1324 Shrawan Kumar Choursiya
1325 Smt Nalini Shrivastava

Employee
Number
81972067
85391587
92482437
92551109
85447041
84447588
89394843
91485324
8939583
85399341
87387865
85446993

83970986
85361656
90531244
91530419
89560254
89568660
92353216
88449150
90432194
90563361
91322311
91380343
91412880
81971523
83978625
84970705
81977950
91554541
90531285
91554658
83612167

Designation
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.Gr-II
O.A.GR-II

Place of Posting
CFO (EZ), JBP
EE (Valu.) CZ, Gwalior
EE(City) N.Dn., CZ, Gwalior
EE(O&M) Dn., EZ, Rehli
EE (STM) Dn., EZ, JBP
EE (STM) Dn., EZ, JBP
EE (STM) Dn., EZ, JBP
EE (O&M) Dn. CZ, Dabbra
EE (O&M) Dn. CZ, Dabbra
EE ( C City). Dn., CZ, Gwalior
EE ( C City). Dn., CZ, Gwalior
CMD, CZ, Bhopal
SE (FS), EZ,JBP
CE (RAPDRP/ADB), EZ, JBP
WZ, Shujalpur
CE(W&P), EZ, JBP
EE(O&M) Dn. WZ, Agar
SE(O&M), EZ, Satna
SE(O&M), EZ, Satna
SE(O&M), EZ, Satna
EE(O&M), EZ, Sidhi
EE(O&M) N. Dn EZ,Rewa
EE(O&M) N. Dn. EZ,Rewa
EE(O&M) N. Dn. EZ,Rewa
Addl.Secy.EZ,JBP
EE( O&M), EZ, Umaria
EE(O&M) Dn. Hoshangabad
E E (O&M) Guna
AE, CZ, Hoshangabad
Joint Dir(A/cs),Jabalpur
Joint Dir(A/cs),Jabalpur
Joint Dir(A/cs),Jabalpur
Sr AO (CAU),JBP
Addl.Secy.EZ,JBP
EE (Store), EZ,Sagar
Addl.Secy.EZ,JBP
EE (O&M) Dn Beena
Addl.Secy.EZ,JBP

Present
Company /
MPSEB
EZ
CZ
CZ
EZ
EZ
EZ
EZ
CZ
CZ
CZ
CZ
CZ
EZ
EZ
WZ
EZ
WZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
CZ
CZ
CZ
Tradeco
Tradeco
Tradeco
Tradeco
EZ
EZ
EZ
EZ
EZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Genco
Transco
Genco
Tradeco
Transco
Tradeco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Tradeco

--Genco
Transco
-Genco
--Tradeco
-----Transco
Transco
-Tradeco
Tradeco
Tradeco
Genco
Genco
Genco
Genco
-Genco
-WZ
------Transco
Transco
EZ
--

--Tradeco
Transco
-----------Transco
-Genco
Genco
Genco
---Genco
---WZ
------Genco
Transco
---

---------------Transco
-------Genco
-----------Transco
---

---------------Transco
-------------------Transco
---

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
No
No
Yes
No
Yes
No
No
No
No
No
Yes
No
No
No
No
No
Yes
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
Yes
Yes
Yes
Yes
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
No
No
No
No
Yes
Yes
No
No

<!-- page 36 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1326 Raj Kumar Singh Rajput
1327 Abhimanyu K Shrivastava
1328 Saiyad Rafiuddin
1329 Badurddin Ansari
1330 Rajesh Kumar Goutam
1331 Anand Mohan Garg
1332 Sukesh Chandra Ghosh
1333 Akshya Kumar Jain
1334 Sanjay Achyut Indurkar
1335 S R Bahadur
1336 Ajay Chate
1337 Rajesh Kumar Pandey
1338 D K Raikwar
1339 Y K Khare
1340 Amar Singh Rathore
1341 N S Thakur
1342 Ram Singh Rawat
1343 A K Pandey
1344 Sajjan Singh Yadav
1345 Vishnulal Ahirwar
1346 Rajkishore Pathak
1347 K P Pandey
1348 V K Pandey
1349 P K Verma
1350 Smt Gyanmala Sharma
1351 Pradeep Kumar Bhargava
1352 Rajnikant Shukla
1353 Mrs. Rashmi Kagde
1354 S K Bhoyar
1355 H S Purviya
1356 Vilash Mahalley
1357 C P Mishra
1358 Sunil Kumar Gurjar
1359 Kundan Singh Mathur
1360 Surendra Kumar Soni
1361 Smt Shobha Rathore
1362 Ghanshyam Prasad Dubey
1363 S.K. Sharma

Employee
Number
84970886
90568831
83978781
84446838
88436257
84978562
85975298
84978384
83976109
92050268
81974799
87430193
92350493
92430668
87433122
91325505
92489069
93020310
93411055
90047893
91014463
91011865
84616514

86056941

81974725
81970617
81974808

Designation
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-II
O.A.GR-III
O.A.GR-III
O.A.GR-III

Place of Posting
Addl.Secy.EZ,JBP
CE (Commercial),JBP
EE (Commercial),JBP
City Dn. North
City Dn. North
Jt.Dir (A/cs), Jabalpur
Jt.Dir (A/cs), Jabalpur
Jt.Dir (A/cs), Jabalpur
ED(HR&A) Genco, JBP
ED(HR&A) Genco, JBP
SE (OPN)-II, , Sarni
CE(PRG)Genco, JBP
CE (PRG), Jabalpur
CE (PRG), Jabalpur
CFO (EZ), Jabalpur
Addl Secy (EZ),JBP
EZ, Jabalpur
D/C Sironj, cir. Vidisha
MT Dn. I, Gwalior
EE, Mandla
SE (O&M) Cir., JBP
SGTPS, Birsinghpur
SGTPS, Birsinghpur
SGTPS, Birsinghpur
STC City Dn, WZ, Ujjain
SE (S) II, STPS, Sarni
EE (O&M)Dn., JBP
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
EE (O&M) Dn. EZ, Banda
Addl.SE(E)City Dn,Ujjain
ADDL. SECRETARY
Joint Dir(A/cs),Jabalpur
Pipariya D/C (O&M) JBP
ADDL. SECRETARY (P)-I

Present
Company /
MPSEB
EZ
EZ
EZ
EZ
EZ
Tradeco
Tradeco
Tradeco
Genco
Genco
Genco
Genco
Genco
Genco
EZ
EZ
EZ
CZ
CZ
EZ
EZ
Genco
Genco
Genco
WZ
Genco
EZ
Genco
Genco
Genco
Genco
Genco
EZ
WZ
MPSEB
Tradeco
EZ
MPSEB

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Tradeco
Transco
Transco
EZ
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco

-Genco
----Tradeco
Tradeco
Tradeco
Tradeco
CZ
----Transco
Tradeco
EZ
-Transco
Transco
----Tradeco
Transco
-Tradeco
Transco
Transco
Transco
Transco
Transco
Tradeco
-Transco
Genco

---------------Transco
-EZ
-Transco
Transco
-----Genco
-----Transco
Transco
--Transco
Tradeco

---------------Transco
---Transco
Transco
------------Tradeco
--Tradeco
EZ

---------------Transco
---Transco
Transco
------------Genco
--Tradeco

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
No
No
No
No
No
No
No
No
No
No
Yes
No
Yes
No
No
No
No
No
Yes
No
Yes
Yes
Yes
No
Yes
No
No
No
Yes
No
No
No
Yes
No
No
No
No
No
Yes
No
No
Yes
No
Yes
No
Yes
No
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
Yes
No
Yes
No
Yes
No
No
No
No
No
Yes
No
Yes
No
---

<!-- page 37 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1364 Radha Sharma
1365 Brijesh Chandra Shrivastava
1366 Smt Kumkum Khare
1367 Chandrika Prasad Jaiswal
1368 Rakesh Kumar Sakalle
1369 Raj Kumar Namdeo
1370 Ajay Ushekwar
1371 Ravendra Prakash Saxena
1372 Shailendra Kumar Shukla
1373 Usha Gupta
1374 Haribhau Sherekar
1375 R. P. Tonte
1376 Sanjay Pol
1377 Anima Jha
1378 Sanjay Kumar Anand
1379 Sunetra Khadson
1380 D.K.Mendiratta
1381 Ramgopal Dubey
1382 V.V.Khandalkar
1383 Jyotish Prasad Yadav
1384 Sunil Kumar Punewar
1385 Sudhir Kumar Chouksey
1386 Ashok Kumar Kewat
1387 Suhas Korde
1388 Ramesh Kumar Kosta
1389 P.K.Goswami
1390 Bharti Shrivastava
1391 Rajnish Kumar Sharma
1392 Rakesh Kumar Verma
1393 Deepak Deshmukh
1394 Mohd Salim Khan
1395 Ravindra Singh Rajput
1396 Sitaram Sharma
1397 Smt Arti Sirothia
1398 Smt Kusumlata Moure
1399 Smt. Yalna Naydu
1400 Sushil Joshi
1401 NK Dwivedi

Employee
Number
90328558

85449640
92340719
93442596
86441043
85975348
81971656
83979598
91410843
84443835
90010272
91014637
91972685
95971261
88436000
83972461
88436265
87446470
85970621
93972790
91451532
92554995
81974162
93440153
85977674
85441390
81974220

Designation
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III

Place of Posting
CGM(BR)Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
PRO
ADDL. SECRETARY (S)
ADDL. SECRETARY (P)-I
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
SR. L.O.
SR. L.O.
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY
ADDL. SECRETARY
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
Ar Rural Umaria EZ

Present
Company /
MPSEB
CZ
CZ
CZ
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
EZ

Pref-1
Transco
CZ
CZ
Tradeco
Tradeco
Transco
Tradeco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Tradeco
Transco
Transco
Tradeco
CZ
CZ
CZ
CZ
CZ
CZ
CZ
Tradeco
Genco

Pref-2

Pref-3

Pref-4

--

-Transco
-EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
-EZ
-EZ
EZ
-------CZ
Genco

CZ
WZ

EZ

-Transco
Transco
Tradeco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Tradeco
Transco
Tradeco
Tradeco
Transco
-------Transco
Genco

-Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
-------Genco
Genco

Pref-5
-Genco
--

---------

Option
Option
for
for
personal Associati
hearing on/ Union
-----------------------------------------------------------------------------

<!-- page 38 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1402 Preeti Sahu
1403 Tripti Pandey
1404 Manisha Joshi
1405 Sumita Soor
1406 Zachariah P.I.
1407 Rajesh Tamhane
1408 S. K. Gupta
1409 Kanhiya Lal Sulodiya
1410 Ramayan Prasad Tiwari
1411 M. K. Namdeo
1412 Rakesh Jain
1413 Sarita Jain
1414 Shanker Kushwaha
1415 Ashiya Perveen Khan
1416 Sapna Guha
1417 Gyaneshwar Sharma
1418 Hari Prakesh Chatterjee
1419 R. K. Chawla
1420 R. S. Chimania
1421 Ramratan Soni
1422 Mehboob Khan
1423 Udaybhanu Singh Kushwaha
1424 A. K. Dubey
1425 Anand Kumar Galar
1426 Gendalal Patel
1427 Kamlesh Prasad Rathore
1428 Mohanlal Malviya
1429 Rajendra Kumar Dewan
1430 Sudhir Kumar Khare
1431 Sunil Kumar Bhargava
1432 Sunil Kumar Malviya
1433 Sunita Toley
1434 A. K. Tiwari
1435 Badri Prasad Sharma
1436 Dinesh Prasad Tripathi
1437 Gunwantrao Patankar
1438 Neelam Sharma
1439 Ravindra B. Bawaskar

Employee
Number
91610195
92520204
89610546
91542793
93020369
91453371
91340454
84364064
91532068
85361763
89550239
93550225
92055300
85974572
92430378
93470051
92440816
88432396
84362324
90562272
92573053
85361755
91413664
91470251
91414415
89412059
90468552
91411221
81971102
88432313
87470869
94343918
93573706
88449986
87361042
84391596

Designation
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III

Place of Posting
EE (STM) Dn.,Dewas
EE (STC) City Dn.,Indore.
EE ( City) Dn Ujjain.
SE (O&M) EZ, JBP
SE(O&M) EZ, JBP
SE(O&M) Pench, Totladoh.
SE (O&M) Circle, EZ, JBP
EE(O&M) Dn Shujalpur.
EE (O&M) Dn., EZ, Anuppur
SE (Civil) S&I M/m, JBP
CE (SR) Sagar
CE (SR) EZ, Sagar
EE (O&M) Store-II, Sarni
SE (Works) EZ, JBP
Chief (Vigilance), EZ, JBP
EE (O&M) Dn. Mahidpur
Addl. Secy. (EZ), JBP
CE (Works & Pur) JBP
D/C, WZ, Kanod
EE(O&M) Umariya
EE (O&M) Dn., Sonekatch
EE (O&M) Dn Agar
(O&M) Dn.Itarsi
EE (O&M)DnItarsi
(O&M) DnItarsi
(O&M) DnItarsi
(O&M) Dn.Itarsi.
(O&M) Dn Itarsi
CE (O&M-Pur) Jabalpur.
EE (O&M) Dn. Jabalpur
(O&M) DnItarsi
CE (Works & Pur) JBP
EE(O&M) DnRajgarh
EE (O&M) DnBioara
RAO (THP) , Sirmour
EE (O&M) N. Dn.CZ, Betul
EE ( A/S), CZ, Gwalior
EE (A/S)Gwalior

Present
Company /
MPSEB
WZ
WZ
WZ
EZ
EZ
Genco
EZ
WZ
EZ
Genco
EZ
EZ
Genco
EZ
EZ
WZ
EZ
EZ
WZ
EZ
WZ
WZ
CZ
CZ
CZ
CZ
CZ
CZ
EZ
EZ
CZ
EZ
CZ
CZ
Genco
CZ
CZ
CZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
CZ
Genco
Transco
Transco
Transco
CZ
Transco
Transco
Transco
Genco
Genco
CZ
Tradeco
CZ
Genco
Transco
Transco
Transco
Transco
Transco
Transco
Genco
Tradeco
Transco
Transco
WZ
WZ
Transco
Genco
Transco
Transco

Transco
----Transco
-Transco
Genco
--Transco
Tradeco
-Genco
-Genco
-CZ
Transco
CZ
--Transco
Transco
Genco
Genco
Transco
Transco
Transco
Transco
Tradeco
WZ
------

--------

--------Genco
--Transco
----Genco
--EZ
CZ
--Transco
---CZ
--Genco
--------

----------------Genco
------Transco
---------------

CZ
Genco
--Transco
----Genco
-CZ
Genco
CZ
--Transco
Transco
--Transco
Tradeco
-Transco
Genco
WZ
------

Option
Option
for
for
personal Associati
hearing on/ Union
-----------------------------------------------------------------------------

<!-- page 39 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1440 Padam Kumar Jain
1441 Babugeer Goswami
1442 Rajendra Kumar Sharma
1443 Rakesh Bhushan Sharma
1444 Ravishankar Mishra
1445 Umakant Chouksey
1446 Ashok Kumar Gupta
1447 Lalsingh Baghel
1448 Sanjay Kumar Shukla
1449 Savita Khare
1450 Kamal Kishore Shukla
1451 N. K. Diwedi
1452 Ghanshyam Gautam
1453 Lakhan Singh Rajput
1454 Rajkishore Sharma
1455 Rakesh Kumar Chourisiya
1456 Ramcharitra Dwivedi
1457 Sashi Bhushan Patel
1458 Shankardhar Koshta
1459 Shiv Kumar Tiwari
1460 Anil Koundal
1461 Arvind Malviya
1462 Kanhiyalal Suhanda
1463 Kunda Desai
1464 Sanjeev Kumar Pare
1465 Shubhada Joshi
1466 Surendra Kumar Shrivastava
1467 Sushil Kumar Shrivastava
1468 Vijay Pankaj Verma
1469 Vinod Kumar Agrawal
1470 Rajesh Jakhmola
1471 Hemant Mehta
1472 M. H. Siddiqui
1473 Nikhil Pachpore
1474 Rakesh Jain
1475 Shamsut Huk Siddiqui
1476 Surendra Kumar Chouksey
1477 Chandramani Prasad Mishr

Employee
Number
91483659
84364080
88470025
89550206
87387857
92340486
88399017
91648137
91371391
91555465
95322671
90568873
99530544
86340733
90353796
91370898
91560557
92441441
85974092
89444929
91371657
88442379
88431984
86420725
88443625
85971248
88441892
84446978
90353077
87340039
12121212
91970219
89550387
89324790
89323157
89324725
88434441
89568347

Designation
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III

Place of Posting
EE (O&M) Dn,Ashoknagar
EE (O&M) Dn Shujalpur
EE (O&M) Dn Ujjain
EE (O&M) Dn Raheli.
EE (O&M) Dn Ashoknagar.
EE (O&M) Dn Lakhnadon
SE ( City) CircleGwalior
City Dn. S.CZ, Gwalior
CE (JR) EZ, Jabalpur
CE (JR) Jabalpur
SE (Civil) S&I, , Bhopal
JE (D/c) Umariya (Rural)
EE (North) Dn. Rewa.
EE (O&M) Dn Jabalpur.
EE (North ) Dn. Rewa.
EE (O&M) Dn. Patan
EE (O&M) Dn Patan
EE (O&M) Dn Patan.
EE (O&M) Dn JBP.
EE (O&M)Dn. Patan.
EE (City) Dn. South JBP.
EE (O&M) Dn Narsinghpur
EE (City) Dn. South,Jabalpur.
EE (A/s), WZ, Indore.
EE (O&M) Dn Narsinghpur.
SE (City) Circle JBP.
EE(O&M) Dn Gadarwara
EE (O&M) Dn Gadarwara
SE (City) Circle JBP.
EE (O&M) Dn Gadarwara
EE (City)Dn. EastBhopal.
M.D. (Tradeco), JBP.
OSD (R. O.) Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Trdeco, Bhopal.
Dir. (Fin), Tradeco, Jabalpur.
EE (City) Dn Rewa.

Present
Company /
MPSEB
CZ
WZ
WZ
EZ
EZ
EZ
CZ
CZ
EZ
EZ
Genco
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
WZ
EZ
EZ
EZ
EZ
EZ
EZ
CZ
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
EZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Genco
Transco
CZ
Genco
Genco
Transco
Transco
Tradeco
Tradeco
Transco
Tradeco
Genco
Genco
Genco
Genco
Transco
Genco
Transco
EZ
Transco
Transco
CZ
Tradeco
CZ
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Tradeco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Genco

-Tradeco
---Transco
-Transco
Transco
Tradeco
Transco
Genco
Genco
EZ
-Tradeco
Tradeco
--Transco
Genco
-Genco
-Genco
Genco
--Tradeco
Genco
Transco
WZ
Transco
CZ
CZ
-Genco
Transco

-----Transco
--Genco
Genco
CZ
Genco
Genco
--Genco
Transco
--Transco
Tradeco
-------Genco
Tradeco
CZ
-Genco
Transco
---Tradeco

-----Transco
-----Genco
Genco
------Transco
------------EZ
WZ
-----

-----Transco
------Genco
------Transco
------------CZ
EZ
-----

Option
Option
for
for
personal Associati
hearing on/ Union
-----------------------------------------------------------------------------

<!-- page 40 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1478 Krishna Uttam Singh Rajput
1479 Mahendra Singh Rajput
1480 Vinay Kumar Das
1481 Tirath Prasad Soni
1482 Shriram Solanki
1483 Virendra Kumar Mishra
1484 Sudhma Prasad Awasthi
1485 Awdesh Chandra Mishra
1486 M. D. Farooque
1487 Rekha Jadhav
1488 Dinkar Rao Gungalkar
1489 Razia Sultana
1490 Virendra Singh Chouhan
1491 Ajay Kumar Shrivastava
1492 Kamal Kishore Pawa
1493 Santosh Kumar Kathal
1494 D. N. Sharma
1495 Janki Prasad Patel
1496 Pradeep Shukla
1497 Urmi Mittal
1498 Ramkripal Patel
1499 S K Jaiswal
1500 Sushma Devi Patel
1501 Taiyyab Ali
1502 Umakant Pathak
1503 Rajendra Sharma
1504 Ramkailash Sharma
1505 Vinit Gangakhedkar
1506 D. K. Gupta
1507 Gopal Saxena
1508 Jitendra Singh
1509 M. S. Thakur
1510 Manoj Kumar Dixit
1511 Nilima Musley
1512 Rajesh Kumar Sharma
1513 Ramesh Prasad Sharma
1514 Saikh Abdul Hakim
1515 Saiyad Imran Hussin

Employee
Number
86340089
91470418
91416436
87360557
84367662
84363604
92321148
85420817
89394751
88520366
93325247
84443975
90356618
88449978
90324250
88380968
90430172
85360377
97440638
91531987
89531305
92532232
89535264
90538512
90431162
92340370
86384946
88380703
87441471
88611123
91412906
85360062
89412744
91557890
88447840
91641694

Designation
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III

Place of Posting
Sr. A.O Chhindwara.
EE (O&M) Dn. Narsinghpur
EE (O&M) DnHarda
JE (D/C) Chandia
EE (O&M) Dn Kannod.
EE(O&M) Dn Kannod
EE (O&M) Dn Agar.
EE (City) Dn. SouthBhopal.
Sr. A. O Indore
EE (O&M) DnGwalior.
CE (UR) WZ, Ujjain.
Sr. A.O. (CAU) CZ, Bhopal
EE(O&M) Dn. EZ, Jabalpur
RMS EZ, Rampur, JBP
EE (City) East Dn JBP.
Addl. Secy. (WZ), Indore
EE (City) Dn. , WZ, Ujjain
Addl. Secy. JBP.
Sr. A.O., WZ , Indore.
EE (O&M) Dn., EZ , Sihora
CE (RR),EZ, Rewa
CE (RR) Rewa
CE (RR),EZ, Rewa
CE (RR),EZ, Rewa
CE (RR),EZ,Rewa
CE (Gen) , Khandwa
CE (Gen.) , Khandwa
SE(O&M) Circle Chhindwara
SE (O&M)Shivpuri
RAOShivpuri
CMD (CZ), Bhopal
EE (O&M) Dn Ujjain
CE (BR) CZ, Bhopal.
EE (City) East Dn Ujjain.
CE (BR) CZ, Bhopal
EE (O&M) DnGanjbasoda
EE ( MT) Dn.-I CZ, Bhopal.
CE (BR)Bhopal

Present
Company /
MPSEB
EZ
EZ
CZ
EZ
WZ
WZ
WZ
CZ
WZ
CZ
WZ
CZ
EZ
EZ
EZ
WZ
WZ
EZ
WZ
EZ
EZ
EZ
EZ
EZ
EZ
Genco
Genco
EZ
WZ
CZ
CZ
WZ
CZ
WZ
CZ
CZ
CZ
CZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Genco
Transco
EZ
Genco
CZ
CZ
CZ
Tradeco
Transco
Transco
Transco
Transco
Genco
Tradeco
Transco
Transco
Transco
Genco
Transco
Tradeco
EZ
EZ
EZ
EZ
EZ
EZ
EZ
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco

Transco
-Transco
Genco
CZ
-Transco
Transco
--Transco
WZ
Transco
Transco
Genco
CZ
Transco
Transco
-Transco
-Genco
-Genco
-EZ
-Genco
Transco
Transco
Tradeco
---CZ
EZ
Transco
Transco

Tradeco
-Tradeco
Genco
------Transco
Transco
Tradeco
Genco
Tradeco
CZ
Transco
--Genco
-Transco
-Transco
---Transco
-CZ
------Transco
Transco

--Genco
Genco
---------CZ
-----CZ
-Tradeco
-Tradeco
------------Transco
Transco

---Tradeco
---------WZ
-----WZ
----------------Transco
--

Option
Option
for
for
personal Associati
hearing on/ Union
-----------------------------------------------------------------------------

<!-- page 41 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1516 Santosh Kumar Shrivastava
1517 Sushil Shridhar Joshi
1518 Praveenchand Jain
1519 Sasi. K.P.
1520 B. L. Singh
1521 Kamal Kishore
1522 Kamlesh Kumar Sahu
1523 M. K. Shrivastava
1524 Ravindra Panikar
1525 Satish Kumar Gupta
1526 Suneela Rajput
1527 Vijay Singh Thakur
1528 Ajay Ubhegaonker
1529 Anant Gyaneshwar Joshi
1530 Christopher Noronha
1531 Krishna Kumar Dubey
1532 Rita Ganguli
1533 Satyanarayan Jaiswal
1534 Shankar Singh Rajput
1535 Kamlesh Kumar Lachhani
1536 Smt. Sarita C
1537 Mohanlal Agrawal
1538 Anil Kumar Gupta
1539 R C Kushwaha
1540 Kanhaiyalal Jha
1541 Santosh Janjire
1542 Shrad Zokarkar
1543 Shyamala S.K. Nair
1544 Brijesh Narayan Sharma
1545 Gulab Chand Gupta
1546 Omprakesh Yadav
1547 Prasant Kumar Bagaddeo
1548 Amlendra Kumar Rajak
1549 Kalu Ram Sen
1550 K.B. Singh
1551 Vimla Prasad Pandey
1552 Dev Kumar Jain
1553 B. L. Patel

Employee
Number

90325167
92640738
94321162

91371383
90371228
87449532
89434341
87436893
91454304
87340153
93340015
85975067
89446726
91360287
93111200

91970359
90562149
86383187

91360254
92630754
93020021
90433002
91340165
83973667
91550425
91538719
91553048
84971991

Designation
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-II
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III

Place of Posting
EE (O&M) Dn Ujjain.
EE (City) South Dn. Bhopal.
SE(O&M), WZ, Barwani
CGM(BR)Bhopal
EE(O&M) Dn. Umariya
EE(O&M) DN. DEWAS
EE (O&M)Dn Patan
EE(C.D.S.),Dn.EZ, JBP.
CE(JR) JBP
EE (City)DnJBP
EE(City) W. Dn.EZ,JBP
EE(City) East Dn.CZ,Bhopal
EE(Store)Dn. Chhindwara
EE(Store)Dn. Chhindwara
EE(STC) Dn.EZ, JBP
EE(STC) Dn.EZ, JBP
EE(STC) Dn.EZ, JBP
EE(O&M)Dn.WZ, Shajapur
EE(FS) EZ, JBP
City Dn.(S), Bhopal
City Dn.(S), Bhopal
CFO(EZ), JBP
CE (RR),EZ, Rewa
SE (O&M), Gwalior
Division.II, Shivpuri
Sr. A. O. WZ, Dewas.
Sr. A. O. , WZ, Dewas
Sr. A.O., WZ, Dewas
EE (City) East Dn., CZ, Bhopal.
EE,Area Stores,JBP.
Sr. A.O.(JC), EZ, JBP
SE(O&M), EZ, Chhindwara
ADDL. SECRETARY (S)
EE (O&M) N. Dn. EZ,Damoh
EE (STC) Dn. EZ,Sagar
RAO (EZ), Chhatarpur
EE(O&M) Dn. EZ, Sagar
ADDL. SECRETARY (P)-I

Present
Company /
MPSEB
WZ
CZ
WZ
CZ
EZ
WZ
EZ
EZ
EZ
EZ
EZ
CZ
EZ
EZ
EZ
EZ
EZ
WZ
EZ
CZ
CZ
EZ
EZ
CZ
CZ
WZ
WZ
WZ
CZ
EZ
EZ
EZ
MPSEB
EZ
EZ
EZ
EZ
MPSEB

Pref-1

Pref-2

Pref-3

Transco
Tradeco
Genco
Transco
Genco
Transco
Transco
Transco
Tradeco
Tradeco
Genco
Transco
Tradeco
Transco
Tradeco
Transco
Transco
Genco
Tradeco
CZ
CZ
Transco
EZ
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
CZ
Transco
Genco
Transco
Tradeco

-Transco
Genco
Transco
Genco
-Tradeco
-Transco
-Transco
Tradeco
Genco
Genco
-Genco
-Transco
------Genco
Transco
---Genco
Genco
Genco
Tradeco
CZ
-Transco
-Transco

-Genco
-Transco
--Genco
---Tradeco
-EZ
Tradeco
-Tradeco
-Transco
-------Transco
---Tradeco
Tradeco
Transco
-CZ
---Genco

Pref-4

Pref-5

-CZ
-Transco
---------EZ
-------------------CZ
-----

-WZ
-----------EZ
-------------------CZ
-----

Option
Option
for
for
personal Associati
hearing on/ Union
--------------------------------------------------YES
YES
YES
YES
YES
NO
NO
NO
Yes
No
No
No
Yes
No
No
No
No
No
No
No
No
No
No
No
No
No

<!-- page 42 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1554 Rajkumar Verma
1555 Awadh Bihari Singh Kushwaha
1556 Ram Prasad Deshmukh
1557 Raju Khan
1558 Devendra Kumar Yadav
1559 Tarun Kumar Sen
1560 Smt. Lajwanti Adwani
1561 Mansa Pradhan
1562 Komal Hemnani
1563 Omprakash Nathani
1564 Durgesh Kumar Verma
1565 Kanhaiya Bijlani
1566 Pradeep Singh
1567 Ashok Kumar Arya
1568 Smt. Abha Shadilay
1569 Ramesh Prasad Omare
1570 Rajesh Kumar Tanwar
1571 Smt. Soukat Janh
1572 Smt. Asha Deshpande
1573 Santosh Kumar Shrivastava
1574 Ajay Kumar Kharate
1575 Manoj Kumar Pashine
1576 B.L.Singh
1577 Keshri Prasad Verma
1578 Chitranjan Rai
1579 Gajendra Singh Chouhan
1580 Dinesh Kumar Agrawal
1581 P. N. Saxena
1582 Neeraj Khare
1583 Naresh Kumar Goswami
1584 Raghunandan Tripathi
1585 Ghanshyam Prasad Kushwaha
1586 Smt. Suchita Katarni
1587 Yogendra Kumar Saxena
1588 Kamlesh Kumar Vishwakarma
1589 Laxmikant Murab
1590 Pramod Kumar Chouhan
1591 F. B. Rodrigues

Employee
Number
84972023
91317444
90414127
90417120
91327278
91327286
94321146
91327303
92320039
89411498
91573161
93360095
91327385
87520580
89411267
90320449
92321072
91328516
90583699
85972378
92340024
90566851
91561125
91530427
91486257
88447220
90630756
95360044
91556893
85391397
86385547
90371095
91633642
91411429
87433031

Designation
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-II

Place of Posting
ADDL. SECRETARY (S)
EE(O&M) Dn., CZ,Gwalior
EE (S) Dn.,CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
CE (BR) CZ, Bhopal
EZ, Panna
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
Dir. (V&S), Tradeco, Jabalpur.
Dir. (V&S), Tradeco, Jabalpur.
Dir. (V&S), Tradeco, Jabalpur.
EE( O&M), EZ, Umaria
EE( O&M), EZ, Umaria
EE( O&M), EZ, Umaria
EE(STM), CZ, Bhind
SE (O&M), EZ, Narsinghpur
EE(O&M) Dn. CZ, Gwalior
EE(O&M) Dn. CZ, Gwalior
SE(O&M) Cir.,CZ, Gwalior
EE(O&M) Dn., EZ, Sagar
JE EZ, Birsinghpur
EE (City) Dn., CZ, Gwalior
EE (City) N. CZ, Gwalior
EE(City) Dn., EZ, JBP
AE (City) D/c CZ, Hoshangabad
AE (City) D/c CZ, Hoshangabad
ADDL. SECRETARY (S)

Present
Company /
MPSEB
MPSEB
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
EZ
CZ
CZ
CZ
Tradeco
Tradeco
Tradeco
EZ
EZ
EZ
CZ
EZ
CZ
CZ
CZ
EZ
EZ
CZ
CZ
EZ
CZ
CZ
MPSEB

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Genco
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
Transco
CZ
CZ
CZ
CZ
Tradeco
Tradeco
Tradeco
Genco
Genco
Transco
Genco
Transco
Transco
Transco
Transco
Transco
Genco
Transco
Transco
Transco
Tradeco
Tradeco
Transco

Tradeco
-Transco
Tradeco
----------Transco
-CZ
CZ
----Genco
--Transco
Genco
-Transco
Tradeco
Transco
Transco
--Genco
Transco
Transco
Genco

---Transco
---------------------Tradeco
--------Tradeco
-Genco
Tradeco

----

----

WZ

EZ
----------------------------------

EZ

-----------------------------------

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
Yes
Yes
No
No
No
Yes
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
Yes
No
No
No
No
No
No
No
No
No
Yes
No
Yes
No
No
No
No
No
No
No
No
No
No
No
Yes
No
Yes
No
Yes
No
No
No
No
No
No
No
Yes
No
No
No
No
Yes
No
No
Yes
No
No
No

<!-- page 43 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1592 Shivpujan Singh
1593 Dilip Kumar Dodhe
1594 Nirmal Kumar Shukla
1595 Narendra Kumar Tiwari
1596 Smt. Satnam Kaur Bhamra
1597 H.G. Gurjar
1598 Deodass Chourasia
1599 Ramesh Prasad Namdeo
1600 Shrikant Kale
1601 Suresh Kumar Soundhiya
1602 Smt. Leela Singh Gour
1603 Smt. Renuka Sharma
1604 Smt. Alka Tiwari
1605 Kamlesh Kumar Goyal
1606 Jitendra Jain
1607 Dharamveer Singh Bhadoriya
1608 R.P. Chheepa
1609 Rajbihari Mandal
1610 Kaushal Kishore Upadhyay
1611 Balram Sen
1612 Smt. Vaidha R. Nadu
1613 Kushal Pal Singh
1614 Devendra Singh
1615 Ashok Kumar Gupta
1616 Smt.Anjana Paigwar
1617 B.B. Sharma
1618 Pawan Kumar Patel
1619 Prem Kumar Shrivastava
1620 Jawaharlal Tiwari
1621 Ram Tribhuwan Sharma
1622 Ram Bahadur Singh
1623 Raj Kumar Mishra
1624 Saroj Kumar Wankhede
1625 Vinod Kumar Washington
1626 Priyanka Naik
1627 Jalaj Kumar Bichpuriya
1628 Sapan Kumar Chakarborty
1629 Harish Muley

Employee
Number
87437073
88340193
88430169
88431506
88438815
88610521
90440115
90562827
81971127
85975439
93514329
91559078
91970929
89398638
92470275
93397931
89446031
92480837
93397519
89550247
88437453
92580660
85611217
91370568
90443423
90568956
89560394
89567969
89560452
89564420
90415166
84976024
93973335
90532210
90532853
90643619

Designation
O.A.GR-I
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III

Place of Posting
ADDL. SECRETARY (S)
SE(O&M), EZ, Chhindwara
ADDL. SECRETARY (S)
CE(O&M-Pur),EZ,JBP
ADDL. SECRETARY
EE(O&M) Dn, CZ, Hoshangabad
Addl. Secy. EZ, JBP
EE(O&M) Dn, EZ, Panna
CE(O&M-Pur), EZ, JBP
CE(O&M-Pur), EZ, JBP
EE (C. City) Dn.CZ,Gwalior
EE (C. City) Dn.CZ,Gwalior
EE (C. City) Dn.CZ,Gwalior
EE (C. City) Dn.CZ,Gwalior
EE (C. City) Dn.CZ,Gwalior
EE (C. City) Dn.CZ,Gwalior
EE (O&M) Dn, EZ,Narsinghpur
AO , CZ, Morena
EE (City) N. Dn., CZ, Gwalior
EE(O&M) Dn., EZ, Rehli
EE (City) W. Dn. EZ, JBP
EE (City) W. Dn. EZ, JBP
EE (City) W. Dn. EZ, JBP
EE(O&M) Dn., WZ, Shajapur
EE(O&M) Dn. EZ, JBP
CE(W&P), EZ, JBP
EE Call Centre).EZ,JBP
SE(O&M), EZ, Satna
RAO,EZ, Sidhi
EE(O&M) N. Dn. EZ,Rewa
RAO,EZ, Sidhi
EE(O&M) Dn. EZ,Baidhan
EE (S) Dn.,CZ, Bhopal
CE(O&M-Pur), EZ, JBP
Addl.Secy.EZ,JBP
Addl.Secy.EZ,JBP
EE (STM) Dn Satna
AE, CZ, Hoshangabad

Present
Company /
MPSEB
MPSEB
EZ
MPSEB
EZ
MPSEB
CZ
EZ
EZ
EZ
EZ
CZ
CZ
CZ
CZ
CZ
CZ
EZ
CZ
CZ
EZ
EZ
EZ
EZ
WZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
CZ
EZ
EZ
EZ
EZ
CZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Genco
Transco
Transco
Transco
Transco
Genco
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Tradeco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Genco
Transco
Transco
Genco
Transco
Transco
Tradeco
Transco
Tradeco

Tradeco
Transco
Tradeco
Genco
Tradeco
--Transco
-Transco
Transco
Transco
---Transco
Tradeco
Genco
Transco
Transco
Genco
Tradeco
Tradeco
Transco
Transco
Transco
-Tradeco
Genco
-Genco
Genco
Transco
Tradeco
Transco
Genco
CZ
--

-Tradeco
-Tradeco
---Transco
--Genco
------Tradeco
Tradeco
Transco
Tradeco
Genco
--Tradeco
Transco
-Genco
------Transco
Transco
Tradeco
--

------------------

------------------------Tradeco
Transco
--------Transco
-Genco
--

WZ
------Tradeco
Transco
--------Transco
-WZ
--

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
Yes
No
Yes
No
Yes
No
No
No
Yes
Yes
No
No
Yes
No
No
No
No
No
Yes
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
Yes
No
Yes
No
No
No
Yes
No
No
No
Yes
No
Yes
No
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
Yes
No
No
Yes
No
Yes
No
No
No
No
No
No
No
Yes
No
Yes
Yes

<!-- page 44 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1630 Kamal Nayan Maurya
1631 Vimal Kumar Vilas
1632 Ram Bhakta Paroha
1633 R K Patel
1634 Dilip Singh Meena
1635 Hanumandeen Gupta
1636 Anil Kumar Agrawal
1637 Brij Mohan Tiwari
1638 Vighnesh Kumar Yadav
1639 Rakesh Kumar Manocha
1640 S K Mishra
1641 Elizabeth Yadav
1642 K K Mishra
1643 Anil Kumar Sharma
1644 Rajkumar Verma
1645 Smt Gita Bhattacharya
1646 Ramesh Datt Pandey
1647 Govind Das Yadav
1648 P P Bhoyarkar
1649 Smt Vijay Kumar Rathore
1650 J W Kharpate
1651 Satyanarayan Sharma
1652 Mahesh Prasad Mishra
1653 R N Patel
1654 Smt Kavita Vishnoi
1655 Dinesh Kumar Khare
1656 Ajesh Kumar Tiwari
1657 R D Rajak
1658 Smt Sujata Rao
1659 Rajesh Kumar Gupta
1660 Sharad Kumar Nema
1661 Awadesh Pathak
1662 Deepak Wanikar
1663 Santosh Patro
1664 Ashok Kumar Mishra
1665 Purshottam Das Agarwal
1666 G P Haldkar
1667 K K Patel

Employee
Number
91340355
91411651
90431923
87340161
91416527
90566885
91546092
90442151
91978021
81972786
90585364
87436075
89432619
93020427
91638039
85971040
85447658
85977898
81978072
85970571
91970904
91536812
89531354
89435910
92430551
89431505
93441052
85972007
92531341
92340031
92340156
92340164
92340172
94437538

89047434
93111218

Designation
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III

Place of Posting
CE (JR), JBP
AE (Rural D/c)Hoshangabad
Panagar D/c Rural
AE (STM)Dn. JBP
AE, CZ, Hoshangabad
D/C, Bansagar, Shahdol
Addl.Secy. (EZ),Jabalpur
Joint Dir(A/cs),Jabalpur
Joint Dir(A/cs),Jabalpur
Sr AO (CAU),JBP
Sr AO (CAU),JBP
CE (Commercial),JBP
EE City North Dn. EZ
EE City North Dn. EZ
City Dn. North
Jt.Dir (A/cs), Jabalpur
Jt.Dir (A/cs), Jabalpur
Jt.Dir (A/cs), Jabalpur
Jt.Dir (A/cs), Jabalpur
Jt.Dir (A/cs), Jabalpur
Jt.Dir (A/cs), Jabalpur
EE,City Dn., Rewa
EE (N) Dn.,Rewa
EE, City (N)Dn, JBP
AE, Adhartal-II
AE, Adhartal-II
AE, Adhartal-II
Tradeco, Jabalpur
CE (O&M:Hydel)JBP
ADDL. SECRETARY (S)
Addl.Secy.EZ,JBP
EE (MT), EZ, JBP
CE (JR) Jabalpur
Adhartar-2,(N) Dn., JBP
EE (O&M), Sihora
EE (O&M), Sihora
SGTPS, Birsinghpur
SGTPS, Birsinghpur

Present
Company /
MPSEB
EZ
CZ
EZ
EZ
CZ
EZ
EZ
Tradeco
Tradeco
Tradeco
Tradeco
EZ
EZ
EZ
EZ
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
EZ
EZ
EZ
EZ
EZ
EZ
Tradeco
Genco
MPSEB
EZ
EZ
EZ
EZ
EZ
EZ
Genco
Genco

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Tradeco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco

Genco
Tradeco
Transco
Tradeco
Genco
-Tradeco
---Genco
-EZ
---Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Genco
Transco
EZ
EZ
EZ
EZ
Tradeco
Tradeco
Tradeco
Transco
---Transco
Transco
---

--Transco
-Transco
-----------------Genco
------Genco
Genco
---Transco
Transco
---

----------------------------------Transco
Transco
---

----------------------------------Transco
Transco
---

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
Yes
No
Yes
No
Yes
No
Yes
Yes
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
No
No
No
No
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
No
No
No
No
Yes
No
Yes
No
No
Yes
No
Yes

<!-- page 45 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1668 G D Pandey
1669 Sanjay Patil
1670 Vijay Kumar Nigam
1671 MP Tiwari
1672 Anna Kumar Raut
1673 O P Patankar
1674 C G Yerpude
1675 N K Gurjar
1676 L N Trivedi
1677 S K Yadav
1678 Gopal Ram Arora
1679 Dilip Kumar Saxena
1680 Shailendra Kumar Shukla
1681 Vishwanath Banerjee
1682 Kamlesh Pateriya
1683 J.S. Sonkeshariya
1684 Rakesh Bhargava
1685 Ram Swaroop Sharma
1686 J K Sarawan
1687 S. K. Shukla
1688 S. K. Shukla
1689 M. S. Gidiyan
1690 Vijay Kumar Kanojia
1691 Anil Kumar Patel
1692 Amit Kumar Yadav
1693 Shivmani Sharma
1694 Brajesh Kumar Awasthi
1695 Praveen Kapoor
1696 Sanjay Singh
1697 Ashwani Kumar Pandey
1698 Lalman Kushwaha
1699 Rameshwar Chouhan
1700 Umrao Singh Parmar
1701 Rammani Mishra
1702 Kalish Kumar Choudhary
1703 Biransingh Dohaiya
1704 P. P. Awasthi
1705 Abdul Hakim

Employee
Number
91459550
92360279
85612280

81971656
85976189
85976171
89394645
90018622
91972461
98970113
91972453
92551711
99440123

85975033
91110501
89975026
95970941
85424742
83615574
90332345
93973376
90520122
91110444

Designation
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
O.A.GR-III
Security Officer
Security Officer
Security Officer
Security Officer
Security Officer
Security Officer
Security Officer
Security Insp.
Security Insp.
SSI
SSI
SSI
SSI
SSI
SSI
SSI
SSI
Head Security Guard
Head Secruity Guard
Sr. SG
Sr. SG
Sr. SG
Sr. SG
Sr. SG

Place of Posting
SGTPS, Birsinghpur
STC Constn Dn,WZ,Ujjain
STC City Dn, WZ, Ujjain
SE (S) II, STPS, Sarni
SE (S) II, STPS, Sarni
SE (S) II, STPS, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
STPS, Genco, Sarni
GM (O&M), Gwalior
ADDL. SECRETARY (S)
EE (MT)EZ,JBP
Head (Vig.) EZ, JBP.
CE (JR) JBP
CE(Gen),SSTPP,Khandwa
EE,Area Stores,EZ,JBP
Dir.(V&S),JBP
Dir. (V&S), Tradeco, Jabalpur.
Dir. (V&S), Tradeco, Jabalpur.
SE(O&M), Genco, Barginagar
SE(O&M), EZ, Sagar
CMD (WZ), Indore
SE (Civil)-I ,THP, Sirmour
SE(O&M) Rajghat, Chandari
CE (Gen), , Chachai.
Dir. (V&S), Tradeco, JBP
Dir. (V&S), Tradeco, JBP
Dir.(V&S),JBP
CE(GR), CZ, Gwalior
EE (A/s), WZ, Indore
EE (Store) Dn Ujjain
CE(RR) Rewa
SE(O&M) Pench, Totladoh.
EE (O&M) Dn Jawara
AE, MPPTCL, Birsinghpur Pali
JE, WZ, Maxi.

Present
Company /
MPSEB
Genco
WZ
WZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
CZ
MPSEB
EZ
EZ
EZ
Genco
EZ
Tradeco
Tradeco
Tradeco
Genco
EZ
EZ
Genco
Genco
Genco
Tradeco
Tradeco
Tradeco
CZ
WZ
WZ
EZ
Genco
WZ
Transco
WZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Tradeco
Genco
Transco
Transco
Genco
Tradeco
Genco
EZ
Genco
WZ
EZ
Genco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Genco
Transco
EZ
Genco
CZ

---Tradeco
Tradeco
Tradeco
-Tradeco
Tradeco
Transco
-Genco
Tradeco
-Genco
--Transco
Tradeco
Genco
Transco
Tradeco
--Tradeco
EZ
WZ
---Transco
--Transco
Tradeco
Transco
---

--------------Transco
--Transco
Transco
Transco
----WZ
Transco
EZ
---EZ
--EZ
EZ
Tradeco
---

-----------------Transco
------CZ
Transco
----CZ
--CZ
-Genco
---

-----------------Transco
------Transco
Transco
----Genco
--Tradeco
-CZ
---

Option
Option
for
for
personal Associati
hearing on/ Union
No
Yes
No
No
No
No
Yes
No
No
No
Yes
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
--Yes
No
No
No
----Yes
No
Yes
No
No
No
No
No
NO
NO
Yes
No
Yes
No
------------No
No
Yes
No
No
No
No
No
--------YES
NO

<!-- page 46 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1706 Mangal Prasad Mishra
1707 Ram Mani Mishra
1708 Raj Kumar Pandey
1709 Kamalbhan Singh
1710 Banshilal Sadhuram
1711 Dafedar Singh
1712 Dhan Singh Gautam
1713 Suresh Kumar Sharma
1714 Brijesh Kumar Choubey
1715 Bhagwat Singh Pal
1716 Rajbhan Singh Rana
1717 Rajkumar Singh Senger
1718 Harprasad Gautam
1719 Shauqat Iqbal
1720 Sumer Singh Kourav
1721 Ramashankar Shukla
1722 A.P. Ahirwar
1723 Basant Singh Rajput
1724 Jagdish Prasad Pandey
1725 Sandhya Chouhan
1726 Anita Pillai
1727 Anita Singh
1728 Dorathi E. J. Arlane
1729 Shaylet Mary's Davis
1730 Esther Caesar
1731 R .K. Mojeslal
1732 Sunil Kumar Dubey
1733 Durga Prasad Rajput
1734 Ramashankar Patel
1735 Sanjay Talapalliwar
1736 Pravin Meghraj Pacholy
1737 V. K. Solanki
1738 Jitendra Singh Rana
1739 Kunjbihari Singh
1740 Manoj Kumar Sharma
1741 R. S. Patel
1742 Ramesh Kumar Asati
1743 Devendra Singh Parihar

Employee
Number
90292770
90332345
89558554
87434260

92397536
85424727
90610261

90019298
87428312
85972519
89558546
89557473
89385321
91290063
83393866
98110116
83973402
94050761
92059459
92059599
91012319
94050860
85972030
92059532
89395874
91012236
91012243
91012277
91012269
92059540

Designation
Sr. SG
Sr. SG
Sr. SG
Sr. SG
Security Guard
Security Guard
Security Guard
Security Guard
Security Guard
Security Guard
Security Guard
Security Guard
Security Guard
Security Guard
Security Guard
Security Guard
Security Guard
Security Guard
Security Guard
Staff Nurse
Staff Nurse
Staff Nurse
Sister Incharge
Nursing Sister
Nursing Sister
Radiographer
Lab. Technician
Lab. Technician
Pharmacist
Pharmacist
Pharmacist
Pharmacist
Pharmacist
Pharmacist
Pharmacist
Pharmacist
Pharmacist
Pharmacist

Place of Posting
SE (O&M),.Genco,Silpara
CE (RR),EZ, Rewa
400 Sub Stn.,Bina
Director V&S), Tradeco,JBP
EE (City) W. Dn.WZ, Indore.
AE (Civil)EZ, Shahdol
EE (O&M) WZ, Shajapur.
SE (O&M),Sagar.
EE (A/s), WZ, Indore
CE (Gen), ., Birsinghpur
SE (O&M) . Rajghat, Chandari
EE(O&M) Dn,WZ,Dhar
EE .Transco,Damoh
City Dn.(S), Bhopal
EE(O&M) Dn Mhow
Dir. (V&S), Tradeco, Jabalpur.
220 KV S/s, Transco, Damoh
220 KV S/S,Sagar
220 KV S/S,Sagar
ED (HRD & Adm.) Jabalpur
Hospital , Birsinghpur
Hospital, Birsinghpur.
SE (O&M) , Bargi Nagar
Hospital, Sarni
CE (Gen) SSTPP, Khandwa
Hospital, Sarni
Hospital, Sarni
Sr. M.O. Chachai
Hospital, , Sarni
Sr. Medical Officer,Sarni
Hospital, Sarni
Hospital, Sarni
Hospital, Ujjain
Sr. M .O. Chachai
Sr. M.O. Chachai
Sr. A.O. Chachai
Sr. M.O. Chachai
Hospital, Genco, Barginagar

Present
Company /
MPSEB
Genco
EZ
Transco
Tradeco
WZ
EZ
WZ
Genco
WZ
Genco
Genco
WZ
Transco
CZ
WZ
Tradeco
Transco
Transco
Transco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
WZ
Genco
Genco
Genco
Genco
Genco

Pref-1

Pref-2

EZ
Genco
EZ
EZ
EZ
Transco
CZ
Transco
CZ
Transco
Genco
EZ
Tradeco
CZ
Transco
Tradeco
EZ
EZ
EZ
Tradeco
Tradeco
Tradeco
Tradeco
CZ
Tradeco
CZ
CZ
Tradeco
Tradeco
CZ
WZ
CZ
CZ
Tradeco
Tradeco
Tradeco
Tradeco
CZ

Transco
Transco
-Transco
-Genco
-CZ
--Genco
EZ
--Transco
-Transco
-----Genco
Tradeco
CZ
Tradeco
WZ
-WZ
CZ
CZ
WZ
-----Tradeco

Pref-3

Pref-4

Pref-5

--

-Tradeco
--------Genco
-----------CZ
---Transco
--Tradeco
-WZ
-------

-EZ

CZ

--------Genco
EZ
----------Transco
---EZ
-CZ
CZ
Tradeco
WZ
-------

--------Genco
-----------EZ
---Tradeco
--Tradeco
-WZ
-------

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
Yes
No
No
No
No
No
----------------------No
No
No
No
No
No
No
No
------------------------------------Yes
No

<!-- page 47 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1744 Chandra Prakash Golait
1745 Krishna Kumar Sharma
1746 P D Shrivastava
1747 Suman Lata Patel
1748 Smt. M Satyathi
1749 Hari Singh Gound
1750 Dilip Chaturvedi
1751 Heeralal Singh
1752 S. K. Tiwari
1753 A. K. Jain
1754 M. K. Solanki
1755 Amar Singh Thakur
1756 Sunil Kumar Uprit
1757 Bhagwati Sharan Sharma
1758 Mukul Kumar Dutta
1759 Rameshwar Prasad Namdeo
1760 Shyamlal Yadav
1761 Habib Ullah Khan
1762 Shivnarayan Patil
1763 Mohan Singh Kushwaha
1764 Vijay Kumar Pashine
1765 Kashiram
1766 Naval Singh Patel
1767 Mathura Prasad Patel
1768 Babulal Dhobi
1769 Bhojraj Chouksey
1770 Kadhorilal Gond
1771 Komal Singh Mehra
1772 Bherala Nahar Singh
1773 Atmaram
1774 Ebrahim Shah
1775 Ghisulal
1776 Parasram
1777 Bhikharam Gond
1778 Banshraj Prajapati
1779 Babulal Kurmi
1780 Dayaram Chandrawanshi
1781 Kailash Vishwkarma

Employee
Number
91579289
92301265
89321268
91110295
91579309
91290022
81975251
91013993
92037406
85050226
91116789
85052412
92441459
86449962
89447237
95320949
95322325
95320916
95320931
93440236
95321293
86441621
84444205
84444213
88449399
86449970
86424478
84612991
84613841

92482189
89442428
92441227
83343846
95320683

Designation
Pharmacist
Pharmacist
Pharmacist
ECG Technician
ANM
Ward Boy
Librarian
Leadig Fireman
Fire Officer
Fire Officer
Asstt. Fire Officer
Horticulturist
Civil Supervisor
Civil Supervisor
Civil Asstt.
Civil Asstt.
Civil Asstt.
Civil Asstt.
Civil Asstt.
Civil Asstt.
Sr.Civil Attd.
Sr.Civil Attd.
Sr.C.Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.

Place of Posting
Hospital, Transco, Sihore
Hospital, Sarni
Sehore Dispensary
Hospital, Birsinghpur
Sehore Dispensary
Hospital (THP) . Sirmour
ADDL. SECRETARY (P)-I
Dir. (V&S), Tradeco, Jabalpur.
Dir. (V&S), Tradeco, Jabalpur.
CE(Gen),SSTPP,Khandwa
CE (Gen) Chachai.
EE ( C ) C&M-II, Sarni
SE (Civil) Dist. JBP.
SE (Civil) Dist. JBP.
EE(C ) Admn.M.Dn.JBP.
SE (Civil) Dist JBP.
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) Dist JBP.
SE (Civil) CZ, Bhopal
(Civil),EZ, Narsinghpur
SE (Civl) Dist. JBP.
(Civil),EZ, Narsinghpur
(Civil),EZ, Narsinghpur
(Civil),EZ, Narsinghpur
(Civil) Narsinghpur
Addl. EE (Civil), WZ, Dhar
SE (Civil) Dist Ujjain
EE (Civil) Dn Ujjain
AE(Civil) Sub-Dn.-IIIBhopal
AE(Civil) Sub-Dn.-IIIBhopal
EE (O&M) Dn Shajapur
SE (Civil) Dist. JBP.
(Civil) Narsinghpur
AE (Civil), Seoni
SE (Civil) CZ, Bhopal

Present
Company /
MPSEB
Transco
Genco
Transco
Genco
Transco
Genco
MPSEB
Tradeco
Tradeco
Genco
Genco
Genco
EZ
EZ
Tradeco
EZ
CZ
CZ
CZ
CZ
EZ
CZ
EZ
EZ
EZ
EZ
EZ
EZ
WZ
WZ
WZ
CZ
CZ
WZ
EZ
EZ
EZ
CZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

CZ
Tradeco
CZ
Tradeco
CZ
Tradeco
Tradeco
Genco
Genco
Transco
CZ
Transco
Tradeco
EZ
Transco
EZ
Genco
Genco
CZ
CZ
EZ
CZ
EZ
EZ
EZ
EZ
EZ
EZ
Transco
Transco
Transco
Transco
Transco
CZ
EZ
EZ
Transco
CZ

------Transco
Tradeco
Tradeco
--Tradeco
Transco
---Transco
Transco
CZ
Transco
EZ
----------CZ
CZ
---WZ
--

-------

------Genco
-----EZ
---Tradeco
EZ
CZ
-EZ
-Tradeco
----------------

-------

EZ
Transco
Transco
---Genco
---EZ
Tradeco
CZ
-EZ
------------------

---------WZ
WZ
CZ
-EZ
------------------

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
--Yes
No
--Yes
No
----No
No
No
No
Yes
No
--Yes
Yes
--------Yes
Yes
Yes
No
Yes
Yes
No
Yes
--No
No
------------------------------Yes
Yes

<!-- page 48 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1782 Babulal Maviya
1783 Prahlad Singh
1784 Narbada Prasad
1785 Girdharilal
1786 Dharmu
1787 Mushtaq
1788 Ramdev
1789 Wahid
1790 Babulal Maviya
1791 Cheddilal
1792 Sukhdev
1793 Ramcharan
1794 Hukumchand Sharma
1795 Tulsi Ram
1796 Mohbat Khan Gouri
1797 Ganesh Ram
1798 Memud Ali
1799 Rajesh Sarathe
1800 Chainu
1801 Ghansulal
1802 Narayan
1803 Smt. Sonya Bai
1804 Dayaram Chandrawanshi
1805 Mukesh Kumar Joseph
1806 Jamil Khan Pathan
1807 S. C. Jain
1808 Madanlal Verma
1809 Kamal Kumar Sharma
1810 Madhu Chandel
1811 Purshottam Shihmare
1812 Vilas Bidwaikar
1813 Ram Prasad Markam
1814 Pooran Lal Choudhary
1815 Mahendra Kumar Prajapati
1816 Prem Kumar Srivas
1817 Neelesh Kumar Punwatkar
1818 Harnarayan singh Jatav
1819 Umesh Kumar Sahu

Employee
Number
95320832
95321062
95321054
95321260
95321252
95321161
95321310
95321005
95321228
95321277
95321236
95321129
95321145
95321988
95321996
95322077
95321871
95321095
95321194
89443442
88437999
91480796
83471183
91520337
93573144
88434657
92633138
85442849
91554252
84363413
95380547
92485083
85447371

Designation
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attdt.
Civil Attd.Gr.II
Civil Attd.Gr.II
TS Gr.II
Testing Super.
Sr. Testing Asstt.
Sr. Testing Asstt.
Sr. Testing Asstt.
Sr. Testing Asstt.
Sr. Testing Asstt.
Sr. Testing Asstt.
Sr. Testing Asstt.
Sr. Testing Asstt.
Sr. Testing Asstt.
Sr. Testing Asstt.
Sr. Testing Asstt.
Sr. Testing Asstt.
Sr. Testing Asstt.

Place of Posting
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
EE(Civil) Dn., Tradeco, JBP
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
EE(MT)EZ, JBP
EE(Civil) EZ, Chhindwara
EE(MT)EZ, JBP
EE (O&M) Itarsi
EE (T) Dn. MPPTCL, Gwalior.
EE (STM) Dn Dewas
EE (T) Dn. Ratlam
EE (O&M) DnHoshangabad
EE (O&M) Dn.Narsinghgarh
EE (O&M) Dn JBP
AE (HTM) North Dn., Indore
EE(MT), EZ, JBP
EE (STM) Dn., EZ, Sagar
EE(STM) Dn., WZ, Ujjain
EE (MT)EZ,JBP
MT Dn. I, Gwalior
EE(MT)EZ, JBP

Present
Company /
MPSEB
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
Tradeco
CZ
CZ
CZ
EZ
EZ
EZ
CZ
Transco
WZ
Transco
CZ
CZ
EZ
WZ
EZ
Ez
WZ
EZ
CZ
EZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
EZ
Transco
Transco
Transco
Transco
WZ
Transco
Transco
CZ
Transco
WZ
Transco
EZ
EZ
Transco
Transco
Genco
Transco
Transco
Transco
Transco

------------Tradeco
WZ
WZ
WZ
WZ
--CZ
----Transco
-Transco
--EZ
---Genco
Genco
-WZ
--

------------Transco
EZ
EZ
EZ
EZ
-------Transco
----EZ
---Genco
--EZ
--

-------------

-------------

WZ
Genco
Genco
Genco
Genco
-------Transco
----EZ
---------

EZ
Transco
Transco
Transco
Transco
-------Transco
----EZ
---------

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
Yes
No
No
No
No
No
Yes
No
No
No
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
Yes
No
Yes
No
Yes
No
Yes
No
No
No
No
No
No
Yes
No
No
No
No
--No
No
----------------No
No
Yes
Yes
No
No
No
No
Yes
No
No
No

<!-- page 49 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1820 Jagdev Prasad Shyam
1821 R. P. Chourey
1822 R. D. Gupta
1823 Vinod Kumar Gour
1824 Devi Singh Patel
1825 Beni Prasad Patel
1826 Vijay Kumar Wasnik
1827 Madan Singh Ladiya
1828 Deepak Kumar Joshi
1829 Surendra Kumar Suhane
1830 Umesh Kumar Som
1831 Ajay Kumar Umale
1832 Ashok Kumar Ojha
1833 V. K. Sharma
1834 Mishri Prasad Sharma
1835 Ram Ruchi Sharma
1836 Sanat Kumar Dubey
1837 Vijay Kumar Shrivastava
1838 Manoj Kumar Dubey
1839 Sanjay Kumar Pawar
1840 Lajjaram Sharma
1841 Manish Paliwal
1842 Ashok Kumar Bhathri
1843 Bhagirath Mehara
1844 Gokul Prasad Kushwaha
1845 Sanjay Falke
1846 Amos Sikka
1847 Rajendra Singh Rajput
1848 Bharat Kumar Mishra
1849 Achhelal Patel
1850 Bhupindra Prasad Pathak
1851 Saghir Ahmad
1852 Mukesh Kumar Sondhiya
1853 Ashok Kumar Yadav
1854 Sunil Kumar Badodiya
1855 Rajendra Sharma
1856 Aslam Khan
1857 Shriram Kinkar

Employee
Number
91381390
93410461
85396124
88444714
88441090
92326817
97574323
89442353
88430854
93576030
97390164
88391452
90296532
90292275
90294388
90296525
91320687
92632841
89392608
98390171
91419090
93410453
91418838
92328523
93576317
87446117
91467181
92355930
89531593
96580294
91381325
90644947
88471106

Designation
TA Gr.I
TA Gr.I
TA Gr.I
TA Gr.I
TA Gr.I
TA Gr.I
TA Gr.I
TA Gr.I
TA Gr.I
TA Gr.I
TA Gr.I
TA Gr.I
TA Gr.I
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.

Place of Posting
AE (LTMT) CZ, Guna
AE, CZ, Hoshangabad
EE(O&M) Dn. CZ,Gwalior
EE(STM), EZ, Narsinghpur
EE(STM), EZ, Narsinghpur
EE(O&M) Dn.EZ, Narsinghpur
EE(O&M), EZ, Narsinghpur
EE (STM) Dn., EZ, JBP
EE(HT) D. WZ,Ujjain
EE (STM) Dn.O&M -I,.JBP
AE (Sub Dn.) CZ Narsinghgarh
MT Dn. I, Gwalior
City(STM)_Dn,Gwalior
EE ( Commu.) Transco.,Gwalior.
Addl. CE, Sirmour
Addl. CE (Gen), Sirmour
Addl. CE (Gen.), Sirmour
Addl. CE (Gen.) Sirmour.
EE (O&M) Dn Khandwa
EE (O&M) Dn Shujalpur
EE (T) Dn.-I Gwalior
EE (Tesing) Dn.-II Gwalior
(O&M) Dn.Itarsi
(O&M) DnItarsi
(O&M) DnItarsi
EE(O&M) DnItarsi
EE (O&M) Dn.Rajgarh (Biaora)
EE (O&M)Dn Pipariya
JE Rampaily
EE (O&M) Dn Burhanpur.
EE (O&M) Dn Rewa.
EE (MT) Dn Rewa.
AE (O&M) EZ, Lakhnadon
EE (O&M) Dn.CZ, Rajgarh
EE(O&M) DnHoshanabad
EE (O&M) Dn Mandleshwar
EE (O&M) Dn Sitamou
EE (O&M) Dn Kannod

Present
Company /
MPSEB
CZ
CZ
CZ
EZ
EZ
EZ
EZ
EZ
WZ
EZ
CZ
CZ
CZ
Transco
Genco
Genco
Genco
Genco
WZ
WZ
Transco
Transco
CZ
CZ
CZ
CZ
CZ
CZ
EZ
WZ
EZ
EZ
EZ
CZ
CZ
WZ
WZ
WZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

EZ
Transco
Transco
CZ
Transco
Transco
Transco
Transco
Transco
Transco
EZ
Transco
Transco
CZ
Genco
Genco
Genco
Genco
Transco
CZ
CZ
CZ
Transco
Transco
Transco
Transco
EZ
EZ
Transco
EZ
Genco
Genco
Transco
EZ
Transco
Transco
Transco
EZ

---Transco
-Transco
--Transco
-EZ
--WZ
----Genco
Transco
WZ
CZ
-Transco
Transco
CZ
EZ
EZ
Genco
Transco
Transco
Transco
Transco
-Genco
-Transco
--

-----Transco
--Transco
-EZ
-------WZ
-EZ
CZ
--Transco
--Genco
---Tradeco
Transco
-CZ
-Transco
--

-----Transco
--Transco
-EZ
----------CZ
--Transco
--Transco
----Transco
---Transco
--

-----Transco
--Transco
-EZ
----------CZ
--Genco
--EZ
--------Transco
--

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
Yes
No
Yes
No
Yes
No
No
No
Yes
No
Yes
No
No
No
No
No
No
No
No
No
Yes
No
No
No
---------------------------------------------------

<!-- page 50 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1858 Naarendra Singh
1859 Omveer Singh
1860 Narendra Singh
1861 S. M. Tripathi
1862 Bharat Dubey
1863 Rajendra Prasad Patel
1864 Rameshwar Dayal Chandel
1865 Manoj Vaidhya
1866 Ramvishal Patkar
1867 Mukesh Kumar Sharma
1868 Rajiv Kumar Sharma
1869 Ujjawal Kumar Mungi
1870 Kamlesh Kumar Sen
1871 Pradeep Dabadhgaon
1872 Vipin Sapre
1873 Vishnu Prasad Rathore
1874 Satyanarayan Modi
1875 Shrikant Chourha
1876 Mukesh Kumar Sahu
1877 Ashok Kumar Sharma
1878 Ramesh Kumar Sharma
1879 Rajnish Kumar Pandey
1880 Om prakash Gautam
1881 Manishankar Pathak
1882 Rameshchandra Kashyap
1883 Ramkhilawan Chkrawarty
1884 M.S. Rajpoot
1885 K. K. Chourasiya
1886 Ashok Kumar Sharma
1887 Santosh Kumar Jha
1888 R. K. Sharma
1889 Roopnarayan Vyas
1890 Ramakant Singh
1891 Mukesh Kumar Sahu
1892 Sunil Kumar Jaiswal
1893 Mithlesh Kumar Gupta
1894 Ashok Kumar Shukla
1895 Suveer Singh Yadav

Employee
Number
91520378

91536200
89532427
92481356
99440116
89551120
90470609
98390139
83367150
89445091
84447556
93398129
88362486
88361059
95361349
95380571
89442741
94321989
85397576
90442755
88446198
92440625
89392599
88446180

92486990
90586313
83970268
84612489

Designation
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
Testing Asstt.
TA Gr.I (TBPS)
T A Gr.II
T A Gr.II
T A Gr.II
T A Gr.II
T A Gr.II
T A Gr.II
T A Gr.II
T A Gr.II
T A Gr.II
T A Gr.II
T A Gr.II
T A Gr.II
T A Gr.II
T A Gr.II
TA Gr.II
Sr.Draftsman
Draftsman (C)
Draftsman (C)

Place of Posting
EE (O&M) DN Jawara
EE (City)Dn.Dabra
O&M Dn.Jaora.
33 KV S/s Mhow Ganj, EZ, Rewa
EE (MT-1)Bhopal.
EE (City) Dn Rewa
EE(Testing)Dn.,Transo,Guna
AE, 132 KV S/s JBP
EE(O&M) Dn Raheli.
EE (Stores), WZ, Ujjain
EE (T) Dn.-II Gwalior
EE (City) Dn.,WZ, Dewas
EE (MT), EZ, JBP
EE (STM) Dn., EZ, JBP
STM Dn., WZ, Ujjain
WZ, City, Dewas
WZ, City, Dewas
AE , City Damoh
EE(O&M) Dn Sihora.
City(STM)_Dn,Gwalior
AE(LTMT),CZ,Gune
JE, D/c,Rampur
CMD (CZ), Bhopal
EE (City) East Dn.,WZ,Ujjain
EE(O&M) Dn. CZ, Datia
EE(O&M) Dn.EZ, Narsinghpur
EE(O&M) Dn.EZ, Narsinghpur
EE(O&M) Dn.EZ, Narsinghpur
EE(City) E.Dn., CZ, Gwalior
EE (STM) Dn., EZ, JBP
EE(HT) D. WZ,Ujjain
AE (HT/M) City Dn. Ujjain
EE(City) Dn. EZ,Satna
EE, STM Dn., O&M Cir.2,JBP
EE,City Dn.,Vijay Nagar,JBP
City Dn.(S), Bhopal
SE (Civil) Dist JBP.
SE (Civil) Circle -Dist, Indore

Present
Company /
MPSEB
WZ
CZ
CZ
EZ
CZ
EZ
Transco
Transco
EZ
WZ
Transco
WZ
EZ
EZ
WZ
WZ
WZ
EZ
EZ
CZ
CZ
EZ
CZ
WZ
CZ
EZ
EZ
EZ
CZ
EZ
WZ
WZ
EZ
EZ
EZ
CZ
EZ
WZ

Pref-1

Pref-2

Pref-3

Pref-4

EZ
Transco
EZ
Transco
Transco
EZ
CZ
EZ
Genco
Transco
CZ
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Genco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Genco
Transco
Transco
CZ
EZ
Transco

Transco
Transco
Transco
Genco
Transco
Genco
----CZ
Transco
--Transco
--Tradeco
EZ
-Transco
Genco
-Transco
------Transco
Transco
Transco
-Tradeco
----

Tradeco
Transco
Tradeco
-Transco
Transco
----CZ
Transco
--Genco
------Transco
-Transco
------Transco
Transco
--Genco
----

Genco
-Genco
-Transco
Tradeco
----CZ
------------Transco
------Transco
Transco
-------

Pref-5
CZ
-CZ
-Transco
------------------Transco
------Transco
Transco
-------

Option
Option
for
for
personal Associati
hearing on/ Union
----------------------Yes
No
No
No
No
No
No
No
Yes
No
Yes
No
Yes
Yes
Yes
No
No
No
Yes
No
Yes
No
Yes
No
No
No
No
No
Yes
No
Yes
No
Yes
No
No
No
No
No
No
No
No
No
Yes
No
No
No
No
No
-------

<!-- page 51 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1896 Santosh Gautam
1897 Sanjay Kumar Jain
1898 Krishna Kumar Gautam
1899 Ganga Prasad Dwivedi
1900 Sudhir Kumar Joshi
1901 Ashok Kumar Kakde
1902 S. K. Mishra
1903 Hariom Banke
1904 Sharad Joshi
1905 Satish Kumar Batham
1906 Sahid Nasir Ali
1907 Komal Singh Chouhan
1908 Anil Kumar Gour
1909 Hemraj Patley
1910 Akhilesh Kumar Jaiswal
1911 J.G. Khatri
1912 Mahesh Dutt Malviya
1913 Ashok Kumar Goure
1914 Irfan Ahmed Qureshi
1915 Sunil Kumar Upadhyay
1916 H. K. Namdeo
1917 Sanjay Moharir
1918 Dharmendra Kumar Soni
1919 Anil Rawerkar
1920 Sahib Rao Patil
1921 Lokesh Shrivastava
1922 Shivkant Dixit
1923 Abdul Salim Khan
1924 Goutam Mukherjee
1925 Omprakash Saini
1926 Harikishan Bairagi
1927 Shyam Rao Khade
1928 Vincent Farnandis
1929 Mahadeo Pd. Dubey
1930 Sher Bahadhur Pal
1931 Anil Kumar Marmat
1932 Hemraj Prajapati
1933 Abdul Laik

Employee
Number
91971654
86440136
81970823
90293083
88449845
83970326
85975397
85471934
84973856
93320594
95320147
91485043
81974055
90430157
88393755
90520171
85974424
84973914
81972547
89520380
95322697
93380219
90294214
86440970
91970458
86051595
92046357
91972594

54110241

Designation
Addl.Draftsman©
ADM (C)
ADM (C)
ADM (C)
ADM (C)
ADM (C)
ADM (C)
ADM
ADM
ADM
ADM
ADM
ADM
ADM
ADM
ADM
ADM
ADM (Civil) TBPS
DOA Gr.I
DOA Gr.I
DOA Gr.I
DOA Gr.I
DOA Gr.I
DOA Gr.I
DOA Gr.I
DOA Gr.I
DOA Gr.I
DOA Gr.I
DOA Gr.I
Sr.Plant Asstt
Plant Asstt.
Plant Asstt.
Plant Asstt.
Plant Asstt.
Plant Attd. GR-II
Plant Attd. GR-II
Plant Attd.
Plant Attd.

Place of Posting
Addl.Secy.EZ,JBP
Addl. Secy JBP
C.S & CC, Tradeco, JBP
EE (O&M) Dn. Rewa
CE (JR) JBP
EE (O&M), WZ, Barwani
ADDL. SECRETARY (S)
(O&M) DnItarsi
CE(O&M-Pur),EZ,JBP
GM(O&M) Circle,CZ,Gwalior
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
EE(O&M) Dn. CZ, Gwalior
SE(Civil), Tradeco, JBP
SE(O&M), EZ, JBP
Addl.Secy EZ, JBP
STPS, Genco, Sarni
EE (Civil) Dn. CZ, Gwalior
SE(O&M),WZ, Ujjain
Addl.Secy. (EZ),Jabalpur
CE (Works-Pur) Jabalpur
CE (Works-Pur) Jabalpur
EE (O&M), Dn. EZ, Amarkantak
SE (Civil) Dist Ujjain.
SE (C) S&I, , Bhopal
CE(GR)Gwalior
EE (Civil)-4, THP, , Sirmour
EE (O&M) Dn. North, Betul
EE (City) E. Dn.JBP
LD, MPSEB, JBP
EE (O&M) Store-II, , Sarni
SE(O&M) Gen. Rajghat, Chandari.
Genco
Genco
SE (Services)-II, Genco, Sarni.
SE (Services)-II, Genco, Sarni
SE (OPN)-II, Birsinghpur
SE (OPN), ,Sarni

Present
Company /
MPSEB
EZ
EZ
Tradeco
EZ
EZ
WZ
MPSEB
CZ
EZ
CZ
CZ
CZ
CZ
Tradeco
EZ
EZ
Genco
CZ
WZ
EZ
EZ
EZ
EZ
WZ
Genco
CZ
Genco
CZ
EZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Transco
Genco
Genco
EZ
Transco
Transco
Genco
Transco
Tradeco
CZ
Transco
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Genco
Transco
Transco
Transco
CZ
Genco
Transco
Transco
WZ
Genco
Transco
Transco
WZ
WZ
EZ
CZ

Transco
Genco
Genco
-Transco
CZ
Genco
Transco
Transco
-Transco
Genco
Genco
Genco
Tradeco
---Transco
Transco
-Genco
Genco
WZ
CZ
Genco
-Genco
Genco
Genco
Transco
Genco
Genco
Tradeco
-----

Transco
-EZ
-Tradeco
-Tradeco
Genco
--WZ
Transco
WZ
Tradeco
Genco
---Transco
Tradeco
--Genco
-Tradeco
CZ
-Genco
Tradeco
--Genco
-------

Transco
-----EZ
Genco
--EZ
Tradeco
------Transco
Genco
--Genco
-Genco
Tradeco
-Genco
---Genco
-------

Transco
-----Transco
--Genco
EZ
------Transco
--------Genco
---Genco
-------

Option
Option
for
for
personal Associati
hearing on/ Union
--------------------No
Yes
Yes
Yes
Yes
No
No
Yes
Yes
No
No
No
No
No
No
No
Yes
No
Yes
No
No
No
No
No
No
No
------------Yes
No
----Yes
No
Yes
No
YES
NO
YES
NO
-----

<!-- page 52 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1934 Lakhan Choudhary
1935 Vinod Kumar Shukla
1936 Maansingh Juzarsingh
1937 Amar Dhapad
1938 Ashok Thete
1939 Gendalal Yadav
1940 Jagdish Prasad
1941 Jamuna Prasad
1942 Maksood Ali
1943 Mallu Singh
1944 Mathura Prasad
1945 Rajulal
1946 Ram Narayan
1947 Ram Samura
1948 Shrawan Tripathi
1949 Sudesh Pillai
1950 Suresh Saini
1951 Trishul Lal Kori
1952 Ram Naresh Soni
1953 Babulal Kumawat
1954 Pyarelal Thakur
1955 Chandan Sigh
1956 Ramashankar Yadav
1957 Kundanlal Batham
1958 Abdul Rafiq
1959 Kunjilal
1960 B. Rupchand
1961 Achhemiya
1962 Jagdish Prasad Kushwaha
1963 Kanhaiyalal Ramratan
1964 Ramniwas Yadav
1965 Munne Khan
1966 Kashiram
1967 Bhagchand Batham
1968 Mohd. Sabeer
1969 Mehfuj
1970 Mukhatyar Alam
1971 Rajmal Sharma

Employee
Number

84617728

97470239
14530929

93323788
92321503
93327763
92321684
92321536
92323797
92323201
83362432
92484481
93329256
93327524
92321635
93327839
93327789
93328035
86361985

Designation
Plant Attd.
Sr.Line Assist.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Asstt.
Line Inspector
Line Man
Line Man
Line Man
Line Man
Line Man
Line Man
Line Man
Line Man
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM

Place of Posting
CE (Gen), Sarni
33/11 KV S/s, CZ, Gwalior.
EE (City) East Dn Ujjain.
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
EE(O&M) Dn Jawad
EE (O&M) Dn Rewa.
EE(O&M) Dn. WZ, Kannod
AE(TSG), JBP
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
Genco, Chachai
City Dn. WZ, Dewas
EE(O&M) Dn. EZ,Beena
CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal

Present
Company /
MPSEB
Genco
CZ
WZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
WZ
EZ
WZ
EZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
Genco
WZ
EZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ

Pref-1

Pref-2

WZ
Transco
Transco
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
EZ
Transco
Transco
Transco
CZ
CZ
CZ
CZ
CZ
CZ
CZ
Genco
Transco
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ

-Genco
WZ
---------------Genco
Transco
-CZ
CZ
CZ
CZ
CZ
---Transco
--CZ
CZ
CZ
CZ
CZ
CZ

Pref-3
--Genco
---------------EZ
--------------------

Pref-4

Pref-5

---

-------------------

WZ
---------------WZ

CZ
--------------------

--------------------

Option
Option
for
for
personal Associati
hearing on/ Union
--------------------------------------No
Yes
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
YES
NO
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No

<!-- page 53 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

1972 Muzfar Ali
1973 Sayed Saraft Ali
1974 Mahaboob Khan
1975 Gajendra
1976 Thakur Singh Uday Singh
1977 Ravindra Gahlot
1978 Jeewanlal Rajput
1979 Shabbir Ahmed
1980 Nanuram
1981 Narayan Ji
1982 Nandau Patel
1983 Parasram Ubnare
1984 Dayashankar Tiwari
1985 Kailash Narayan Yadav
1986 Radheraman Tripathi
1987 Prem lal Pali
1988 Tularam
1989 Nand Kishore
1990 Choonu Singh
1991 Ganga Prasad Rathore
1992 Radhika Prasad Dubey
1993 Sharif Ahmed Ansari
1994 Kallu Kori
1995 Chhogalal
1996 Atmaram Verma
1997 Ghanshyamdas Bairagi
1998 Rameshchandra Punajee
1999 Mohanlal Ramchanra
2000 S. K. Birhole
2001 Amar Singh Raghuwanshi
2002 Ramesh Kumar Tiwari
2003 Ramchandra Verma
2004 Ramcharan Verma
2005 Ajay Bhosale
2006 Moti Singh
2007 Satish Kumar Singh Tomar
2008 Kamta Prasad Dahiya
2009 Ramanuj Sharma

Employee
Number
93327664
93324323
93327995
89325756
90461912
83616085
89325368
90328111

94340245

91561786
88433352
93328191
91415024
89435373
91561109
90569301
85361805
88341523
92410355
87611033
88611172
89670158
87610696
90582635
90465822
89561699
86360368
84365310
90465203
91397628
92486445
14530663

Designation
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM
ALM
Sr.Line Attdt.
Sr.Line Attdt.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.

Place of Posting
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
SE(O&M) WZ, Burhanpur
EE (LTMT)Dn., WZ, Ujjain
AE (STM) ,CZ,Bhopal
AE (STM) ,CZ,Bhopal
EE (O&M) Dn, WZ, Agar
EE (O&M) Dn, WZ, Agar
Genco, Chachai
EE(Store), EZ, Chhindwara
EE(City) Dn.,Khandwa
EE( O&M) Dn Shajapur
D/C, Bansagar, Shahdol
AE (Adhartal City) EZ
EE(City) South Dn.CZ, Bhopal
EE (O&M) DnVidisha
EE (O&M) Dn Raheli
EE (O&M), EZ, Anooppur
EE (O&M) Dn. Anooppur
EE (O&M) Dn Shujalpur
AE(D/c) EZ, Chachi
EEPipariya
EE (City) East Dn Ujjain
EE (City) East Dn Ujjain
EE(City) East Dn Ujjain
EE (City) East Dn Ujjain.
EE (O&M) City Dn Chhindwara
EE City Dn., WZ, Khandwa
AE, Dist. Centre Chachai
EE (O&M) Dn Shajapur.
EE (O&M) Dn Shujalpur
EE (O&M) Dn.-II, Khandwa
33/11 KV S/sGwalior
33/11 KV S/s Gwalior
EE (O&M) Dn Rewa
EE (O&M) Dn Rewa

Present
Company /
MPSEB
CZ
CZ
CZ
CZ
WZ
WZ
CZ
CZ
WZ
WZ
Genco
EZ
WZ
WZ
EZ
EZ
CZ
CZ
EZ
EZ
EZ
WZ
EZ
CZ
WZ
WZ
WZ
WZ
EZ
WZ
EZ
WZ
WZ
WZ
CZ
CZ
EZ
EZ

Pref-1
CZ
CZ
CZ
CZ
CZ
Transco
Transco
Transco
Transco
Transco
Genco
Genco
Transco
CZ
Genco
Transco
CZ
Transco
Genco
Genco
Genco
Transco
Genco
EZ
Transco
Transco
Transco
Transco
Transco
Transco
Genco
Transco
Tradeco
Genco
Transco
Transco
Genco
Transco

Pref-2

Pref-3

Pref-4

Pref-5

----

-----

CZ
Transco
CZ
CZ
---Transco
Genco
--Genco
CZ
--Genco
Genco
-Genco
CZ
WZ
WZ
WZ
WZ
Transco
Genco
Genco
-Transco
WZ
Genco
Genco
-Tradeco

CZ
Transco
------WZ
-------Genco
---Genco
Genco
Genco
Genco
Transco
WZ
Genco
----WZ
-EZ

-----Transco
------------------WZ
WZ
WZ
WZ
Transco
-Genco
------WZ

----------------------------Transco
--------CZ

CZ

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
No
No
No
No
No
No
Yes
No
Yes
No
No
No
Yes
No
Yes
No
No
No
No
No
No
No
No
No
Yes
No
No
No
No
No
No
No
-------------------------------------------

<!-- page 54 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

2010 Suriendra Kumar Rajak
2011 Shivram Singh
2012 Omprakash Dubey
2013 Ramesh Kumar Verma
2014 Ashok Kumar Lotan Singh
2015 Chander Singh Dewda
2016 Oukarlal Mohanlal Bharati
2017 Radheshyam Meena
2018 V. K. Shukla
2019 Anil Agrawal
2020 Chaturgiri Goswami
2021 Hubbilal
2022 Hukum Chand
2023 Jagmohan Saxena
2024 Mahesh Kumar
2025 Narayan Singh
2026 Ramesh chandra Jaiswal
2027 Wasiuddin
2028 Lalchand Jatav
2029 Mukundilal
2030 Devdayal Rathore
2031 Tularam
2032 Avinash Singh Kushwaha
2033 Mohan Lal Modi
2034 Laxman Dhurve
2035 Suresh Chandra Yadav
2036 Babulal Kumawat
2037 Omprakash Pandey
2038 Mukesh Patel
2039 Ramratan Shakay
2040 Janved S/o Chaukariya
2041 Babulal
2042 Suraj Sakaya
2043 Gulab Singh Rajput
2044 Devendra Singh
2045 Makhanlal
2046 Mohan Kanojiya
2047 Bhagirath

Employee
Number
89532740
83366657
90562693
85611811
86360723
86360558
84478849
86470324

99576261
91579911

84360245
85427118
87470810
89361975
89470148
92360167
92481769
90327809
89325632
93327797
97470395
93328803
97470577
89326449

Designation
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Sr.Line Attd.
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper

Place of Posting
EE (O&M) Dn Rewa.
EE (O&M) Dn Sonkatch
EE(O&M) Dn Umariya
JE (D/C) WZ, Nemawar
EE (O&M) Dn.WZ, Shajapur
EE (City ) East Dn Ujjain.
EE (O&M) Dn Gandhisagar.
EE (O&M) Dn Garoth.
EE (MT-1)Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
EE(City)Dn Dewas
City Dn.(S), Bhopal
JE (D/c) Narsinghgarh ®
EE (Vig.) Dn. Rajgarh
EE (O&M) Dn.Vidisha
City Dn.(S), Bhopal
JE, WZ, Maxi.
City Dn., WZ, Dewas.
EE (EHT) Transco, Nagda
EE (O&M) Dn.,WZ, Sitamau
City Dn., WZ, Dewas
EE (O&M) Dn., WZ, Sitamau.
City Dn. WZ, Dewas.
EE(O&M) Dn. WZ, Shajapur
EE(EHT) Maint.,Transco,Gwalior
EE (O&M) Dn. Bhopal
CZ, Bhopal
CZ, Bhopal
CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal

Present
Company /
MPSEB
EZ
WZ
EZ
WZ
WZ
WZ
WZ
WZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
WZ
CZ
CZ
CZ
CZ
CZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
Transco
CZ
CZ
CZ
CZ
CZ
CZ
CZ

Pref-1

Pref-2

Genco
CZ
Transco
CZ
CZ
Transco
Genco
Genco
Transco
CZ
CZ
CZ
CZ
CZ
CZ
CZ
Transco
CZ
EZ
Transco
Transco
CZ
CZ
Transco
Genco
Transco
Transco
Transco
Transco
CZ
CZ
WZ
CZ
CZ
CZ
CZ
CZ
CZ

Transco
CZ
Genco
-CZ
Transco
--Transco
-------Transco
-EZ
Transco
WZ
--Transco
-Transco
Transco
Transco
Transco
-WZ
WZ
---CZ
CZ
CZ

Pref-3

Pref-4

--

Pref-5

--

--

CZ

CZ

CZ

---Transco
--Transco
----------Transco
Tradeco
----Transco
-Transco
--Transco
--------

---Transco
--Transco
----------Transco
CZ
------Transco
--EZ
--------

---Transco
--Transco
----------Transco
----------Genco
--------

Option
Option
for
for
personal Associati
hearing on/ Union
--------------------------------------------NO
NO
YES
NO
YES
NO
NO
NO
YES
NO
NO
NO
YES
NO
Yes
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No

<!-- page 55 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

2048 Israr
2049 Brajmohan
2050 Atik Mohd.
2051 Suresh Kumar
2052 Raishuddin
2053 Gopal Mishra
2054 Nizumuddin
2055 Achhemiya
2056 Pooran Singh
2057 Sanjay Kanojiya
2058 Shahrao
2059 Ashok Mehta
2060 Nathuram Prajapati
2061 Deshraj
2062 Ramanuj Morya
2063 Liyakat
2064 Praveen Kumar
2065 Ramvaran
2066 Abdul Bari
2067 Phoolsingh
2068 Vimlesh Chaturvedi
2069 Nahadu Dhurve
2070 Shankarlal Champalal
2071 Prakash Singh Gond
2072 Harish Chand Rao
2073 Somat Singh
2074 Santosh Carpainter
2075 Shanker Rao Thakre
2076 Basheer Khan
2077 Awantilal
2078 Badari Prasad
2079 Bharu Singh
2080 Gopal Singh Rajput
2081 Ashok Shrivas
2082 Mohanlal Sarathe
2083 Vijay Kumar Vishwakarma
2084 Mahipal Singh Goand
2085 Manoj Ram Singh Prajapati

Employee
Number
93328266
93328274
93329280
93329520
89326530
93329025
89325681
93329545
92573319
89326523
93328324
93329066

93328076
89326416
89326639
93329132
93328902
93328167
91380947
93324257
88383177
92325248
88360340
93442414
84361012
84364270
87425599
84365491
88435721
90643329
91415009
90413624
97360472

Designation
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Helper
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.

Place of Posting
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(O&M) Dn. CZ, Datia
AE (City) D/c CZ, Hoshangabad
EE (City) N. CZ, Bhopal
AE, CZ, Kalapipal
EE (O&M) Dn., CZ, Shivpuri
EE(O&M), CZ, Vidisha
City Dn. WZ, Dewas.
EE (Transmission-Store), JBP
EE (O&M) Dn., WZ, Shajapur
EE (O&M) Dn Shujalpur
EE (O&M) Dn Shujalpur
EE (O&M) Dn Shujalpur
EE (O&M) Dn JBP.
EE (O&M) Dn Barwani
(O&M) DnItarsi
(O&M) DnItarsi
EE (EHT-M)Dn.,Transco,JBP
EE (City) Dn Dewas

Present
Company /
MPSEB
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
WZ
Transco
WZ
WZ
WZ
WZ
EZ
WZ
CZ
CZ
Transco
WZ

Pref-1
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
WZ
Transco
WZ
Transco
Transco
Transco
Transco
EZ
CZ
Transco
Transco
Transco
EZ
Transco
Transco
Transco
Genco
CZ

Pref-2
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
--Transco
Transco
-CZ
--Transco
WZ
-WZ
WZ
WZ
-EZ
Transco
----

Pref-3

Pref-4

Pref-5

---------------------Transco
-----CZ
-----------

---------------------Transco
-----Genco
-----------

---------------------------Tradeco
-----------

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
Yes
No
No
No
No
No
Yes
No
No
No
Yes
No
-----------------------

<!-- page 56 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

Employee
Number

Designation

Place of Posting

2086 Gulabrao Pawar
2087 Balram Singh
2088 Satish Choudhary

90470137
97630353
97360860

Line Attdt.
Line Attdt.
Line Attdt.

EE (Area Store), Mandsaur
EE (EHT) Maint. Dn.Gwalior
EE (O&M) Dn Kannod

2089 Bhagwan Swaroop Shrivastava
2090 Omprakash Ebne
2091 Bhagwan Singh Baghel
2092 Madan Mohan Malviya
2093 Anil Kumar Sharma
2094 Dhaniram Patel
2095 Omprakesh Ramdas
2096 Pratap Singh Parihar
2097 Raju Kori
2098 Gupteshwar
2099 Durga Prasad Manzi
2100 Kemla Prasad
2101 Kartar Singh Parmar
2102 Heeralal Prajpati
2103 Ravi Kushwaha
2104 Rahis Khan
2105 Premlal Rajak
2106 Shivsharan Rajak
2107 Vishram Kumar
2108 Vijay Singh Majhi
2109 Chandrakishore Panwar
2110 Sheikh Sakoor
2111 Deepak Joshi
2112 Ramnaresh Singh
2113 Mohd. Hassin Khan
2114 Jagdish Meena
2115 Keshav Prasad Garg
2116 Sunil Kumar Bhoomarkar
2117 Tularam Batthom
2118 Vikram Singh Kalmodiya
2119 Ghanshyam Burman
2120 Madhhu Lal Lodhi
2121 Raja Bhaiya Mishra
2122 Rohini Prasad Dubey
2123 Shankar Lal Dhurve

95360573
97360638
89394702
97360456
95360870
95520317
85361268
95360747
96520266
89324253
97360654
95470364
93411286

Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.

EE (STM) Dn Dewas
EE (City) Dn Dewas.
EE EHT (Maint) Dn. Gwalior
EE (City) Dn Dewas.
EE(O&M)Dn Bagli
EE (O&M) Dn Ratlam
EE (O&M) Dn Bagli.
EE (O&M) DN Bagli
EE (O&M) Dn Ratlam
EE (City)Dn. SouthBhopal
EE (O&M) Dn Kannod
EE (O&M) Dn Jawad
EE ( Trans-Store) Itarsi
EE(O&M) Dn Kannod
EE EHT (Maint) Dn. Gwalior
EE (O&M) Dn Kannod
EE (O&M) Dn Shajapur.
EE(O&M) Dn Shajapur
EE (O&M), WZ, Shajapur
EE (O&M) Dn Sitamhow
(O&M) DnItarsi
(O&M) DnItarsi
AE (Rural D/c)Hoshangabad.
EE (O&M) Dn., , Silpara
EE (STM) Dn Mandsaur
EE (O&M) Dn Shajapur.
EE (O&M) Dn Rehli
EE (O&M) Dn Sonkatch
EE(O&M) Dn Sonkatch
EE (O&M) Dn Shajapur.
EE (O&M) Dn JBP.
EE (O&M) DN JBP.
EE (O&M) Dn JBP.
EE (O&M) Dn JBP.
EE (O&M) Dn JBP.

91467561
90295832
95470208
95470173
95470604
95470728
93411758
89412529
90297002
98470188
94360045
89553779
95360029
95360283
89360274
88435952
85441714
88439037
89433757
89435878

Present
Pref-1
Company /
MPSEB
Transco
WZ
CZ
Transco
CZ
WZ
Transco
WZ
CZ
WZ
CZ
Transco
CZ
WZ
CZ
WZ
EZ
WZ
CZ
WZ
CZ
WZ
CZ
WZ
Transco
CZ
CZ
WZ
EZ
WZ
CZ
Transco
CZ
WZ
CZ
Transco
CZ
WZ
EZ
WZ
EZ
WZ
EZ
WZ
CZ
WZ
Genco
CZ
Transco
CZ
Transco
CZ
Genco
Genco
CZ
WZ
Transco
WZ
Transco
EZ
CZ
WZ
CZ
WZ
Transco
WZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ

Pref-2
Genco
WZ
CZ
--WZ
----CZ
--CZ
EZ
CZ
CZ
WZ
----Transco
Transco
-Genco
-WZ
--CZ
CZ
-------

Pref-3
CZ
EZ
---Transco
--------EZ
--Transco
----CZ
Transco
-Tradeco
----CZ
CZ
-------

Pref-4

Pref-5

-Transco
Transco

-Genco
--

---

--Genco
-----------Genco
-----Transco
---------------

EZ
-----------EZ
-----Transco
-------CZ
-------

Option
Option
for
for
personal Associati
hearing on/ Union
------------------------------------------

------------------------------------

<!-- page 57 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

2124 Shiv Ram Raghuwanshi
2125 Vimlesh Patle
2126 Vitthal Rao Deshmukh
2127 Hansraj Bharti
2128 Rajbali Giri
2129 Kanhaiyalal Kourav
2130 Sudhir Kumar Shrivastava
2131 Pramod Tiwari
2132 Ram Kailash Verma
2133 Ramnarayan Pasi
2134 Sunil Kumar Singh
2135 Haripal Singh Jadon
2136 Narayan Singh
2137 Punoo Mistri
2138 Premlal Yadav
2139 Santosh Kumar Parashar
2140 Sohan Suryavanhsi
2141 Motilal Yadav
2142 Nandlal Yadav
2143 Sukhendra Singh
2144 Sarnam Singh
2145 Rammilan Patel
2146 Shyamrao Makode
2147 Mahipal Yadav
2148 Rakesh Kumar Kushwaha
2149 Sanjay Shriwas
2150 Santosh Kumar Soni
2151 S.Amalraj
2152 Jay Prakash Biyani
2153 Navraj Rai
2154 Dayaram Thakur
2155 Rakesh Kumar Choudhary
2156 Saleem Khan
2157 Bhagwanlal Koli
2158 S.K. Dehariya
2159 Ashok Kumar Choure
2160 Darpan Singh Rawat
2161 Haridas Khatarkar

Employee
Number
91326296
96580443
93329405
95520201
95520184
89422900
89422883
92310992
93551306
92537579
95360060
97360258
90351535
85444337
89412876

97520052
90480868
95470389
89414053
95470109
92646230
96447527
93441499
90536656
90328392
89324477
97360373
97470478
97360423
89340242
91412799
84522035
92411089

Designation
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.

Place of Posting
EE (O&M) Dn Narsinghpur
EE (O&M) Dn. EZ, Waraseoni
OSD (R.O.), Tradeco, Bhopal.
EE (O&M) Dn Jawara
EE (O&M) Dn Jawara
Addl. EE (HTM) Indore
Addl. EE (HTM) ,Indore
EE (O&M) Dn Rewa
EE (O&M) Dn Rewa.
EE (O&M) Dn Rehli
EE (O&M) Dn. Sirmour
EE (O&M) Dn Agar.
EE (O&M) DN Sonkatch
AE 220KV S/s Birsinghpur Pali
EE (O&M) DnBetul
EE (O&M) DnHoshangabad.
EE (O&M) Dn. NorthBetul
EE(O&M) Dn Umariya
EE(O&M) Dn Umariya
EE(O&M) Dn Umariya
EE (O&M) Dn Agar
EE (O&M) Dn Jawad
132/33 KV Sub station Betul.
EE(O&M ) Dn Garoth
EE (O&M) Dn Barwani.
EE (E&M) Adm. Comp. JBP.
EE (E&M), Adm. Comp. JBP.
JE (EZ), Bangaon
EE (O&M) Dn Ujjain
OSD (R.O.), Tradeco, Bhopal.
EE (O&M) Dn Sonkatch
EE (O&M) Dn., WZ, Sonkatch
EE (O&M) Dn Jawad
EE(O&M) Dn Sonkatch
EE(Store)Dn. Chhindwara
EE (O&M) Dn.Hoshangabad
EE(City) East Dn.CZ,Bhopal
EE(EHT-M)Dn. Itarsi

Present
Company /
MPSEB
EZ
EZ
Tradeco
WZ
WZ
WZ
WZ
EZ
EZ
EZ
EZ
WZ
WZ
Transco
CZ
CZ
CZ
EZ
EZ
EZ
WZ
WZ
Transco
WZ
WZ
EZ
EZ
EZ
WZ
Tradeco
WZ
WZ
WZ
WZ
EZ
CZ
CZ
Transco

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

CZ
Transco
Tradeco
EZ
EZ
CZ
CZ
Transco
Genco
Transco
Genco
CZ
CZ
Genco
Genco
Genco
Genco
Genco
Genco
Genco
CZ
EZ
Genco
EZ
CZ
Transco
Transco
Tradeco
Transco
Tradeco
CZ
EZ
CZ
CZ
Transco
Genco
Transco
Genco

---Transco
Transco
Transco
Transco
Genco
---CZ
CZ
-Genco
Transco
Genco
------EZ
Transco
--Transco
-Transco
CZ
EZ
CZ
CZ
Genco
-Transco
--

---Tradeco
Tradeco
--EZ
---CZ
CZ
-Genco
-Genco
------EZ
-----CZ
-EZ
CZ
CZ
EZ
-Transco
--

---Genco
Genco
--WZ
------Genco
-Genco
------------WZ
-Tradeco
CZ
CZ
-----

---CZ
CZ
--CZ
------Genco
-Genco
------------Genco
--CZ
CZ
-----

Option
Option
for
for
personal Associati
hearing on/ Union
-----------------------------------------------------------------------------

<!-- page 58 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

2162 Newa Ram
2163 Hajari Lal Yadav
2164 Sant Kumar Dubey
2165 Santosh Kumar Rai
2166 Raghunath Chhopde
2167 Ramniwas Kushwaha
2168 Ranveer
2169 Kaleshchand Jawariya
2170 Shyamlal Rathore
2171 Jagdish Prasad
2172 Jai Singh
2173 Mohan Singh
2174 Mohanlal
2175 Ramesh Chandra Patidar
2176 Ravindra Kumar Soni
2177 Tholuram
2178 Yashpal Singh
2179 Balakram Malviya
2180 Rajendra Kumar Sharma
2181 Vijay Kumar Patel
2182 Bablu Batanlal
2183 Mohan Mali
2184 Rambabu Ramcharan Jatav
2185 Surendra Singh Yadav
2186 Balram Prajapat
2187 Mahipat Kushwaha
2188 Musarat Khan
2189 Surjeet Singh Kushwaha
2190 Babu Khan Mohd. Khan
2191 Naresh Singh Kushwaha
2192 Chandrabhan Singh Panwar
2193 Ramesh Kushwaha
2194 Banshilal
2195 Ashok Kumar Kushwaha
2196 Anwar Khan
2197 Bhupendra Singh Harinkhede
2198 Satyanarayan Joshi
2199 Bhupendra Singh

Employee
Number

95360234
95360706
95470231
91320687
95361125
95360201
89554710
90417492
86421383
95360994
88360746
89360646
96360010
90552090
97470354
86611109
93411187
97360497
97360745
92481686
95361167
95470869
95610225
97470197
95360242
83395697
97360596
97360836
88520267
91573681
97360829
89361594
87470703

Designation
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.

Place of Posting
City Dn.(S), Bhopal
EE (O&M) Dn., WZ, Shajapur
EE (O&M) Dn Shajapur.
EE (O&M) Dn Shajapur
EE(O&M) City Dn Khandwa
EE (O&M) Dn Shajapur.
EE (O&M) Dn Shajapur.
EE (O&M), WZ, Shajapur
Dist. Centre, RulerHoshangabad
EE (O&M) Dn Shujapur.
EE (O&M) Dn Sujalpur
EE (O&M) Dn Shujalpur
EE (O&M) Dn Shujalpur
EE (O&M) Dn., WZ, Shujalpur
EE (O&M) Dn Shujalpur
EE (O&M), Dn Shujalpur
EE (O&M) Dn Shujalpur.
EE (City ) Dn. Khandwa
EE (O&M) Dn Mehidpur
EE (O&M) DnItarsi
EE (City ) Dn Dewas
EE (City) Dn. WZ Dewas
EE (O&M) Dn., WZ, Dewas
EE (City) Dn Dewas.
AE (D/c) WZ, Panwadi
AE (D/c) WZ, Panwadi
EE (O&M) Dn Shajapur
EE (O&M) Dn Shajapur
EE (O&M) Dn. -II, WZ, Khandwa
EE (O&M) Dn. , WZ, Alirajpur.
EE (O&M) Dn Bagli
EE(O&M) Dn Bagli
EE (O&M) DnBiaora
EE (O&M) Dn Jhabua
EE (O&M) Dn Agar.
EE (O&M), WZ, Dewas
JE (D/C) Runiga, WZ
EE (O&M) Dn Garoth.

Present
Company /
MPSEB
CZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
CZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
CZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
WZ
CZ
WZ
WZ
WZ
WZ
WZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

CZ
CZ
EZ
EZ
Transco
CZ
CZ
CZ
Transco
CZ
CZ
CZ
Tradeco
Tradeco
Tradeco
CZ
CZ
Transco
Transco
EZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
EZ
CZ
WZ
CZ
Transco
EZ
Transco
Genco

----Genco
---CZ
---Transco
Transco
Transco
----EZ
------CZ
-------CZ
-Transco
--

-----

--------------------

--------------------

WZ
--------------EZ

EZ
-------

CZ

EZ
-------

CZ
------------

------------

-------------------

Option
Option
for
for
personal Associati
hearing on/ Union
-----------------------------------------------------------------------------

<!-- page 59 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

2200 P C R Luhar
2201 Aslam Khan
2202 Krishna Narayan
2203 Laxmi Narayan
2204 Manohar Prasad Malviya
2205 Ramjeet Giri
2206 Sodan Singh
2207 Tara Singh
2208 Maan Singh
2209 Dinesh Kushwaha
2210 Naval Kishor
2211 Suresh S/o Sultan Singh
2212 Harish Kumar
2213 Devilal Jha
2214 Parasram
2215 Gurunarayan Bamne
2216 Bhopat Singh Sahu
2217 Rakalesh Viswakarma
2218 Dattatare Jegurikar
2219 Gulab Rao Pawar
2220 Govind Das Prajapati
2221 Mohd. Ayub
2222 Arvind Kumar
2223 Ramayan Prasad
2224 Sunil Kumar
2225 Rizwan Ahmed
2226 Dharam Giri
2227 Mohd. Jameel
2228 Chimanlal
2229 Nafis Khan
2230 Yusuf Khan
2231 Niyamat Khan
2232 Radharaman Bairagi
2233 Sunil Kumar Yadav
2234 Riyaz Ali
2235 Dilip Choudhary
2236 Mohanlal Patel
2237 Prashant Bedekar

Employee
Number
87470774

92641728
95610217

95360672
95320965
83343805
89445471
95360169
91557651
93551363
94322251
93328225
89325715
93329198
93328613
89326564
89326431
89326191
93327961
93329058
91320638

89360167
83977859
89327711

Designation
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attdt.
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II

Place of Posting
EE (O&M) Dn Garoth.
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
City Dn.(S), Bhopal
EE (O&M) Dn. Raisen
AE (220 KV), Transco, Indore
EE(EHT) Maint.,Transco,Gwalior
EE(EHT) Maint.,Transco,Gwalior
EE(EHT) Maint.,Transco,Gwalior
EHT (Maint) Dn., Transco,Gwalior
SE (Civil) CZ, Bhopal
EE (O&M) Dn., WZ, Ratlam
EE(STM), EZ, Narsinghpur
EE (O&M) Dn. EZ, Narsinghpur
EE( O&M) Dn Shajapur
Sub A/S Mandsoe WZ
SE(O&M), EZ, Sagar
EE(O&M), Dn. EZ, Beena
EE (O&M) Dn. Mandideep
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
Bagrodha(D/c) Sironj,CZ,Bhopal
EE (Vig.) FS-16, EZ, JBP
JE, WZ, Shujalpur
EE (City) Dn. WZ, Dewas
EE (STM) Dn., EZ, JBP
EE (City) E. Dn. CZ, Bhopal

Present
Company /
MPSEB
WZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
Transco
Transco
Transco
Transco
Transco
CZ
WZ
EZ
EZ
WZ
WZ
EZ
EZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
EZ
WZ
WZ
EZ
CZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Genco
CZ
Transco
CZ
CZ
Tradeco
CZ
CZ
WZ
WZ
CZ
CZ
CZ
CZ
Transco
Genco
Transco
Genco
Transco
Transco
Transco
Transco
Transco
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
CZ
WZ
Genco
Genco
Transco
Transco
Transco

-----Tradeco
---WZ
WZ
WZ
WZ
WZ
CZ
CZ
Genco
Genco
-Genco
-EZ
Genco
------------Transco
-Tradeco

------

-----Transco
---WZ
EZ
EZ
EZ
Genco
-------------------------

----------Genco
Genco
Genco
Transco
-------------------------

CZ
---WZ
Transco
Transco
Transco
EZ
-----CZ
-------------------

Option
Option
for
for
personal Associati
hearing on/ Union
------------------Yes
No
No
No
No
No
No
No
Yes
No
Yes
Yes
Yes
No
Yes
No
Yes
No
Yes
Yes
--No
No
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
Yes
No
No
No
Yes
No
Yes
No
No
No
Yes
No

<!-- page 60 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

2238 Ramdayal Shrawan
2239 Anil Kumar Digraskar
2240 Ramesh Kumar Pal
2241 Badri Prasad Kushwaha
2242 Sharan Kishori Bajpai
2243 Rajesh Kumar Soni
2244 Dulichand Soni
2245 Chhjedi Pandey
2246 Mahesh Batham
2247 Ramyag Yadav
2248 Ranjan Singh
2249 Lalji Tripathi
2250 Vikas Kumar Temley
2251 Mohd. Ajam
2252 Ram Paltu Yadav
2253 Ganesh Prasad Dwivedi
2254 Jageshwar prasad Napit
2255 Udaybhan Pandey
2256 Madhav Singh Sahu
2257 Ranjan Singh Chandravat
2258 Dinesh Kumar Shrivastava
2259 Mahmood Khan
2260 Gulab Singh
2261 Mahadev Prasad Soni
2262 Gulab Rao Niranjane
2263 Ashok Singh
2264 Abrar Ahmed
2265 Abdul Nazir Khan
2266 Ramprakash Goutam
2267 Mohan Lal Soni
2268 Saji Thomas
2269 Mohd. Aavid
2270 Ramdayal
2271 Sarif
2272 Shankar Ingalkar
2273 Suraj Prasad Rathore
2274 Babulal Choudhary
2275 Susheel Kumar Sondhiya

Employee
Number
92329737
90635573

Designation

Line Attd.Gr.Ii
Line Attd.Gr.II
Line Attd.Gr.II
Line Attd.Gr.II
88432801 Line Attd.Gr.II
85975090 Line Attd.Gr.II
92440849 Line Attd.Gr.II
93550381 Line Attd.Gr.II
Line Attd.Gr.II
92327906 Line Attd.Gr.I
86610861 Line Attd.Gr.I
86444435 Line Attd.Gr.I
86443973 Line Attd.Gr.I
91579465 Line Attd.Gr.I
94328885 Line Asstt.Gr.II
95105978 Helper
90580118 Helper
90568378 Helper
93327680 Line Helper
Addl. ALM
874441662 Attd. Gr.II
95322706 Driver
94322920 Driver
90418994 Driver
88449754 Driver
96381635 Driver
Driver
Driver
Driver
84975836 Driver
Driver
92322377 Driver
92571719 Driver
93329644 Driver
83344042 Driver
Driver
84978640 Blue Printer
73973616 Daftary

Place of Posting
EE(O&M), CZ, Vidisha
EE (O&M) Dn Shajapur
AE(TSG), JBP
AE(TSG), JBP
AE (Adhartal City) EZ
AE (Adhartal City) EZ
EE (MT)Dn. MRP
EE (MT), EZ, JBP
EE (O&M) Dn. WZ, Badwani.
EE(O&M) Dn., CZ, Vidisha
EE (City) Dn., WZ, Ujjain
EE (STM) Dn., EZ, JBP
EE (STM) Dn., EZ, JBP
EE City) Dn.CZ,Sihore
EE( (MT-1), CZ, Bhopal
D/C. Bansagar,
D/C. Bansagar,
D/C, Bansagar, Shahdol
CZ, Bhopal
EE (City) West Dn., WZ, Ujjain
EE (STM) Dn., EZ, JBP
SE (Civil) S&I, , Bhopal.
OSD (R.O.), Tradeco, Bhopal.
EE (O&M) DnHoshangabad.
SE (Civil) Dist. JBP.
EE (O&M) DnPichhore
City Dn.(S), Bhopal
AE (STC), WZ, Khandwa
EE(EHT) Maint.,Transco,Damoh
CE(JR)EZ, JBP
CMD (CZ), Bhopal
SE (City) CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
EE(City) South Dn.CZ, Bhopal
SE (City), EZ,JBP
EHT Construction Dn.Transco
ADDL. SECRETARY
CE(O&M-Pur) JBP

Present
Company /
MPSEB
CZ
WZ
EZ
EZ
EZ
EZ
EZ
EZ
WZ
CZ
WZ
EZ
EZ
CZ
CZ
EZ
EZ
EZ
CZ
WZ
EZ
Genco
Tradeco
CZ
EZ
CZ
CZ
WZ
Transco
EZ
CZ
CZ
CZ
CZ
EZ
Transco
MPSEB
EZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
EZ
Transco
Transco
Transco
Transco
Transco
Transco
CZ
Transco
Transco
Transco
Transco
Transco
Transco
Genco
Genco
Genco
CZ
Transco
Transco
Tradeco
Tradeco
Transco
EZ
EZ
CZ
Genco
EZ
Tradeco
Tradeco
CZ
CZ
CZ
Transco
CZ
Tradeco
Tradeco

----Transco
Genco
--Transco
Tradeco
Transco
--Transco
Transco
----Genco
-Transco
---CZ
-Transco
--Transco
-CZ
CZ
-CZ
Transco
Transco

----------Transco
--Transco
Transco
----Tradeco
-CZ
---CZ
-WZ
--------EZ
Genco

----------Transco
--Transco
Transco
----WZ
-----Transco
----------Genco
--

----------Transco
--Transco
Transco
----CZ
-----Transco
------------

Option
Option
for
for
personal Associati
hearing on/ Union
No
No
Yes
Yes
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
Yes
No
No
No
No
No
No
No
No
No
NO
NO
No
No
------------NO
NO
Yes
No
Yes
No
Yes
No
No
No
No
No
No
No
Yes
No
No
No
-----

<!-- page 61 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

2276 Nandlal Verma
2277 Rammanohar Kaithwas
2278 Tara Singh Thakur
2279 Ram Kumar Ben
2280 Govind Prasad Thakur
2281 S. K. Telang
2282 Jeevanlal Rajak
2283 Salim Ali
2284 Ramswaroop Battham
2285 Mulam Chand
2286 Chintaman Bihare
2287 M S Tekam
2288 Ramesh Kumar Verma
2289 R. P. Lodhi
2290 T. C. Navik
2291 Murlidhar Heera
2292 Rameshchandra Choure
2293 Santosh Singh Baghel
2294 Chandrakanta Carpainter
2295 Rajbahadur Singh Baghel
2296 Ramesh Kumar Ban
2297 Chandan Singh
2298 Lalji Ram
2299 Rajendra Prasad Patel
2300 Ramyash Shukla
2301 Sachhidanand Pandey
2302 Saheb Rao Kavadkar
2303 Chhote Lal Tiwari
2304 Ram Gopal Kushwaha
2305 Aditya Kumar Verma
2306 Chandra Pratap Sharma
2307 Gorelal Sharma
2308 Kaushal Prasad Verma
2309 Lal Bahadur Singh Chouhan
2310 Ramawtar Patel
2311 Ramgopal Verma
2312 Satyapal Sharma
2313 Ashok Khare

Employee
Number
83525915
89422751
84971983
83978161
87436563
88430250
84971968
91321058
85398525
91553106
91113919
81973305
85447307
92301307
95971212
90417872
89412314
93576824
92441152
93516044
94321469
89322308
89323362
89324774
90328160
89535370
90568993
92532216
89567811
91531540

91535715
91535483
91531615
90328632

Designation
Daftary
Daftary
Daftary
Daftary
Daftary
Daftary
Daftary
Daftary
Daftary
Daftary
Daftary
Daftary
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon

Place of Posting
EE (O&M) Dn Jawara
SE (Civil) Circle- Dist Indore
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
SR. L.O.
PRO
ADDL. SECRETARY (S)
SE (City) CZ, Bhopal
EE ( Central City). Dn., CZ, Gwalior
Joint Dir(A/cs),Jabalpur
SE(O&M), EZ, Chhindwara
SGTPS, Birsinghpur
PRO
SE(O&M) JBP
SE (O&M) Pench, Totladoh
CE (APDRP) JBP
(O&M) DnItarsi
(O&M) DnItarsi
SE (Civil), S&I, ., Bhopal
EE (O&M) Dn Patan
EE (O&M), Dn JBP.
OSD (R.O.), Tradeco, JBP.
OSD (R.O.), Tradeco, Bhopal
OSD (R.O.) Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
OSD (R.O.), Tradeco, Bhopal.
EE (City) Dn Rewa.
EE (O&M) DN Anuppur.
CE (RR),EZ, Rewa
CE (RR),EZ,Rewa
CE (RR),EZ,Rewa
CE (RR)EZ, Rewa
SE (Civil)- Distn. JBP.
CE (RR),EZ, Rewa
CE (RR),EZ, Rewa
CE (RR),EZ, Rewa
EE (MT-1)Bhopal.

Present
Company /
MPSEB
WZ
WZ
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
CZ
CZ
Tradeco
EZ
Genco
MPSEB
EZ
Genco
EZ
CZ
CZ
Genco
EZ
EZ
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
CZ

Pref-1

Pref-2

Pref-3

Pref-4

EZ
Transco
Transco
Genco
Tradeco
Transco
Transco
CZ
Transco
Transco
Genco
Transco
Tradeco
Transco
Tradeco
Transco
Transco
Genco
WZ
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Genco
Genco
EZ
EZ
EZ
EZ
Genco
EZ
EZ
EZ
Transco

Transco
-Genco
Transco
Transco
Tradeco
Tradeco
--Genco
Transco
-Transco
-Transco
Genco
-Transco
CZ
-Transco
Transco
Transco
---Genco
Transco
Genco
-Genco
--Transco
Genco
Genco
-Transco

Tradeco
-Tradeco
Tradeco
Genco
Genco
Genco
-----Genco
--Tradeco
-Transco
Transco
--------Tradeco
Genco
-Transco
---Transco
Transco

Genco
-EZ
EZ
EZ
-EZ
-----EZ
----Transco
----------Genco
--------Transco

Transco

Pref-5
CZ
--

----------Transco
-------------------Transco

Option
Option
for
for
personal Associati
hearing on/ Union
--------------No
No
No
No
Yes
No
Yes
No
No
Yes
No
No
---------------------------------------------------

<!-- page 62 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

2314 Nirmala Singh
2315 Ramdyal Kachhi
2316 Kailash Babu Saini
2317 Moolchand Yadav
2318 Omprakesh Kushwaha
2319 Ramsajiwan Patel
2320 Ravi Shanker
2321 Tulsiram Yadav
2322 Ranjeet Kaur Lamba
2323 Bali Ram Kirme
2324 Rampal Viswakarma
2325 Udaybhan Kushwaha
2326 Mathura Prasad Shukla
2327 S.M. Tiwari
2328 Kalish Kumar Pathak
2329 Kandhi Lal Pal
2330 Indra Raj Giri
2331 Jote Ram Yadav
2332 Somnath Sen
2333 S. P. Sharma
2334 Veerbhan Prasad Patel
2335 Lal Singh Yadav
2336 Mani Das Kushwaha
2337 Vinod Kumar Vishwakarma
2338 Anandilal Tiwari
2339 Laxmi Prasad Yadav
2340 Mahesh Singh Thakur
2341 Gangadeen Verma
2342 Jhallu Prasad Kurmi
2343 Vinod Kumar Garg
2344 Vijay Kumar Balmik
2345 Dev Narayan Mishra
2346 Ravendra Kumar Verma
2347 Arun Kumar Singh
2348 Rajendra Kumar Verma
2349 Ramkushal Verma
2350 Sharad Kumar Raikwar
2351 Sandeep Kumar Parate

Employee
Number

85971933
85975257
91970978
84972156
91971547
85971842
95970652
83979532
85449682
95971403
84971330
93973004
95971106
84972395
93973400
91970953
85971735
88448616
93973731
85971769
95971683
95970446
83977882
83979607
88433683
91971083
93973292
85973228
83979557
95970883
95971519
95971188
95611629
91972560
95971626
95973010

Designation
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon

Place of Posting
EE(O&M) Dn.CZ,Betul
CE(O&M-Pur),EZ,JBP
City Dn.(S), Bhopal
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
IRO
IRO
IRO
SR. L.O.
SR. L.O.
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY (S)
ADDL. SECRETARY
PRO
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I
ADDL. SECRETARY (P)-I

Present
Company /
MPSEB
CZ
EZ
CZ
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB
MPSEB

Pref-1

Pref-2

Pref-3

Genco
Transco
CZ
Transco
Transco
Transco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco
Tradeco
Transco
Tradeco
Tradeco
Tradeco
Transco
Transco
Transco
Transco
Transco

-Tradeco
-EZ
EZ
Tradeco
Transco
Tradeco
Tradeco
Genco
Tradeco
Genco
Genco
Genco
Transco
Genco
Genco
Transco
Transco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Transco
Transco
Tradeco
Transco
Transco
Transco
Tradeco
Tradeco
Genco
Tradeco
Tradeco

---Tradeco
Tradeco
Genco
EZ
Genco
Genco
-Genco
Tradeco
Tradeco
Tradeco
Genco
Transco
Tradeco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Genco
Tradeco
Genco
Genco

Pref-4
---Genco
Genco
EZ
Genco
EZ
EZ
-EZ
EZ
EZ
EZ
EZ
EZ
-EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ
EZ

Pref-5
----

Option
Option
for
for
personal Associati
hearing on/ Union
-----------------------------------------------------------------------------

<!-- page 63 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

2352 Mangal Deen Patel
2353 Dhanraj Choudhary
2354 Gopal Yadav
2355 Laxminarayan Yadav
2356 Revti Bai Gupta
2357 Mohan Sen
2358 Dashrath Prasad
2359 Rohini Prasad Pathak
2360 Narmada Prasad Pradhan
2361 Kishanlal Rajput
2362 Shiv Naryan Yadav
2363 Garibdas Malviya
2364 Farida Bano
2365 Ramayan Prasad Patel
2366 Vijay Joshi
2367 Shivbhan Patel
2368 Vikramaditya Patel
2369 Ramprasad Sharma
2370 Ramji Prasad Soni
2371 Shyamlal Kushwaha
2372 Ramlallu Patel
2373 Bhola Kushwaha
2374 Diwakar Prasad Kushwaha
2375 Smt. Rajkali Sen
2376 Jaihind Khare
2377 Sudarshan Prasad Mishra
2378 Badri Nath Jha
2379 Suresh Prasad Pathak
2380 Narmada Prasad Kachhi
2381 Smt Anjana Kushwaha
2382 Santlal Maravi
2383 Devendra Kumar Chaubey
2384 Ram Daras Kushwaha
2385 Anant Kumar Kushwaha
2386 Ashok Kumar Yadav
2387 Ram Dulare Kushwaha
2388 D K Verma
2389 Tuc Bhadhaur

Employee
Number

93412094

95437537
83973089
83979961
84972031
95320287
91327344
91327369
95323596
85970076
95971097
85975249
87449664
89446057
88442206
89441819
91561661
85970555
91115930
85977808
85972957
81972182
93973137
85972908
96447709
95971873
93441036
91970887
91972099
85038684
93972972

Designation
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon
Peon

Place of Posting
ADDL. SECRETARY (P)-I
EE (O&M) DnHoshangabad
Sr. A. O. WZ, Dewas.
EE (O&M) Dn., CZ, Guna
EE (O&M) Dn. EZ, Narsinghpur
EE, STC Dn.,JBP.
CGM (Comm.)Trading
CE(O&M-Pur), EZ, JBP
ED (Finance), JBP
SE (Civil) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
SE (City) CZ, Bhopal
CE(O&M-Pur), EZ, JBP
ED (HR&Ad.), Genco,JBP
ADDL. SECRETARY (S)
CE(JR), EZ, JBP
EE(O&M) Dn.EZ, Gadarwara
SE(O&M), EZ, Narsinghpur
ADDL. SECRETARY (S)
CE (RAPDRP/ADB), EZ, JBP
RAO,EZ, Sidhi
Joint Dir(A/cs),Jabalpur
Joint Dir(A/cs),Jabalpur
Joint Dir(A/cs),Jabalpur
Joint Dir(A/cs),Jabalpur
ED (Finance), JBP
ED (Finance), JBP
CE(RAPDRP) EZ
CE (PRG), MPPGCL,JBP
AO (F&A), MPSEB,JBP
Jt.Dir (A/cs), Jabalpur
Sr AO (CAU),JBP
CE(O&M-Pur), EZ, JBP
Secretary
SE (O&M) Cir., JBP
SGTPS, Birsinghpur
Fin. (Advisor), Tradeco,JBP

Present
Company /
MPSEB
MPSEB
CZ
WZ
CZ
EZ
EZ
Tradeco
EZ
Tradeco
CZ
CZ
CZ
CZ
EZ
Genco
MPSEB
EZ
EZ
EZ
MPSEB
EZ
EZ
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
Tradeco
EZ
Genco
Tradeco
Tradeco
Tradeco
EZ
MPSEB
EZ
Genco
Tradeco

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
Transco
Transco
CZ
Tradeco
Genco
Transco
Transco
Tradeco
CZ
CZ
CZ
Transco
WZ
Transco
Genco
Tradeco
Genco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
Transco
WZ
Transco
Transco
Transco
Transco
Transco
Transco
Tradeco

Tradeco
Transco
-Transco
-Transco
---Transco
----Tradeco
Tradeco
-Transco
Transco
Tradeco
-Genco
--------Genco
--Genco
Genco
Tradeco
-Transco

Genco
Transco
---Genco
---WZ
--------------------CZ
--Tradeco
---Transco

EZ
Transco
-------EZ
-----------------------------

Transco
-------Genco
-----------------------------

Option
Option
for
for
personal Associati
hearing on/ Union
----NO
NO
NO
NO
YES
NO
Yes
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
No
Yes
No
Yes
No
No
No
No
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
Yes
No
No
No
Yes
No
No
No
Yes
No
Yes
No
Yes
No
No
No
Yes
No
No
Yes
Yes
No

<!-- page 64 -->

Order of Preference
SN

NAME (S/Shri/Smt.)

2390 Rakesh Yadav
2391 Laxman Prasad Yadav
2392 Rajesh Kumar Rajak
2393 Satendra Kumar Pandey
2394 Savitri Bai Jharia
2395 Baby Annarao Dubey
2396 Nafisa Begam
2397 Smt. Ram Bai
2398 Premlata Batham
2399 Babulal Sen
2400 Mishrilal
2401 Kishore Verma
2402 Abdul Sattar
2403 Mishrilal
2404 Pyari Bai
2405 Jumman

Employee
Number
93973277
99440172
89446602
85972220
85972212
98470048
91327377
95320493
95322102
90463520
95321392
91327385
95321384

Place of Posting

Designation
Peon
Peon
Cleaner
Cleaner
Farrash
Farrash
Farrash
Farrash
Farrash
Khansama Helper
Khansama Helper
Helper to Khansama
Sweeper
Sweeper
Sweeper
Sweeper

ADDL. SECRETARY (S)
Secretary
SE (Civil) Dist. JBP.
EE (O&M) Dn Sidhi
ADDL. SECRETARY (P)-I
ADDL. SECRETARY
EE (O&M) Dn Garoth
City Dn.(S), Bhopal
SE (City) CZ, Bhopal
SE (Civil) CZ, Bhopal
SE (Civil) CZ, Bhopal
AE (Civil) WZ, Khangone
City Dn.(S), Bhopal
SE (Civil) CZ, Bhopal
SE (City) CZ, Bhopal
SE (Civil) CZ, Bhopal

Present
Company /
MPSEB
MPSEB
MPSEB
EZ
EZ
MPSEB
MPSEB
WZ
CZ
CZ
CZ
CZ
WZ
CZ
CZ
CZ
CZ

Pref-1

Pref-2

Pref-3

Pref-4

Pref-5

Transco
Transco
EZ
CZ
Transco
Transco
CZ
CZ
-CZ
CZ
Transco
CZ
CZ
CZ
Transco

Tradeco
Genco
EZ
-Tradeco
Tradeco
---Tradeco
WZ
------

-Tradeco
EZ
-Genco
Genco
---Transco
EZ
------

---

---

EZ

EZ
--

--

----

----

EZ
EZ

WZ
Genco
------

EZ
Transco
------

Option
Option
for
for
personal Associati
hearing on/ Union
Yes
No
No
No
------------No
No
No
Yes
Yes
No
----No
No
No
No
No
Yes

( * ) Subject to final decision of Writ Petition under consideration of Hon'ble High Court.
(Rajiv Shrivastava)
AS (P)-I, MPSEB &
Convenor, Working Committee
