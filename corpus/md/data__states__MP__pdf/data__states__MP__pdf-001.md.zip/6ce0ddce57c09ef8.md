---
doc_id: "6ce0ddce57c09ef8"
source_url: "https://portal.mpcz.in/upload_files/pdf/home/latest_news_and_updates/Circular_Employee_of_the_Month_Recognition_Program_FY_2026-27.pdf"
ministry: "Madhya Pradesh Madhya Kshetra Vidyut Vitaran Co. Ltd., Bhopal, Madhya Pradesh"
title: "Circular Employee of the Month-Recognition Program FY 2026-27"
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ecff3ecd1761c0ec"
---

<!-- page 1 -->

UADEYAPRADESE UADEYA KSEETRA
VIDYTIT VITARAIT COUPAITY LIUITID
(Goverament of M.p. Uaderta

""1*;Hff;ff#f?,,i# @,fl,
t g_

Webslte: u.urr,.mpcz.co.in
lstrffi0mflIootc$rstmi
CrN: U4o logMp2oo2scco 1s 1 - =_
SO 9OO 1:2O 15 CERTIFIEDI

ED I nr 1 a{bncR/ 1 1,

622- L3

Circular

Bhopal dated: 3l

EMPIToYEE or rHE MONTH- RrcocNrrroN pRocRAM Fy 2C/26-27.

The Madhya Pradesh Madhya Kshetra Vidyut Vitaran Company Ltd. (MPMKryCL)
is pleased to continue the Employee of the Month Recognition program
for the Financial
Year 2026-27, which was initiated in Fy 2025_26.

A. O&'EICTIVT
The Employee of the Month initiative aims to foster a culture of recognition
and
appreciation within the organization.It is designed to:

a) Encourage a healthy competitive spirit.
b) Motivate employees to enhance their performance.
c) Recognize those who consistently demonstrate outstanding dedication and

excellence in their work.
This program seeks to boost morale and inspire employees to realize
their full
potential.

B. SCOPE
Each month, the top three performing employees from every

division of the company

will be selected as Emplogees of the Monthbased on their performance.
winners will
be announced by the first week of the following month
throughout the year.

C. AlryARD & RECOGNITION
a) Certificate of Recognition
Top three employees..from each City/o&M Division will receive
a certificate of
outstanding perform€u1ce, awarded ty the respective Circle's General
Manager
during the first week of every month. (Format in Annexure-I)
b) Disptay Banner/Flex
A flex/banner featuring the name, designation, posting location
and photograph of
the selected employees will be displayeJ at the respective Division
offices . (Format

in Annentre-Il)
c) Company trIebsite Display
The names, designations, posting locations and photographs

of the award.ees, along

oelzj

<!-- page 2 -->

with the selected performance par€rmeters on which they were evaluated, will be
showcased on the company website each month.

D. ELIGIBILITY
a) All regular, contractual and outsourced personnel working in City Zones, Town
Z-ortes, and DCs are eligible. However, being recognized under this program does not
confer eligibility of outsourced personnel for future employment on a regular or
contractual basis.
b) An employee may be nominated only once per quarter within a financial year.
c) Employees against whom a Departmental Inquiry or Show Cause Notice is pending

will not be eligible for nomination under usual circumstances.

E. MONTHLY PERI'ORMANCE PARAMETERS
Selection wil1be based on a set of performernce pararneters related to revenue generation

and consumer satisfaction.

a) Five key activities (subject to change) *i11 be identified for each month by the
Corporate Office. An indicative list of performance activities is enclosed in
Annexure-Ill.

b) Each Circle's General Manager may add up to two additional activities relevant
to their area specific operations.

F. SELDCTION PROCESS
a) Five (variable) monthly activities identified by the Corporate Office will carry 80%
of the total evaluation weightage (equal or variable distribution).

b) Up to two additional activities (lOo/o each or variable) may be selected by the
Circle's General Manager, making up the remaining 2O%.
c) If no additional parameters are specified by the Circle's General Manager, the
Corporate Office parameters will account for the full 1OO%.

d) Supporting data will be sourced from the company's IT systems or relevant
registers maintained ateach Zone I DC.

e) Managers/Assistant Managers of each Zone/DC will nominate one employee
based on performance against the selected parameters. The individual scorecard will
be filled for each nominated personnel in Individual scorecard (Annexure-IV)and will
be forwarded to the Division Office for recommendation by the Deputy General
Manager.

<!-- page 3 -->

f) The Deputy General Manager of Divisions wil send the duly recommended Dirision

scorecards (Annentre-V)to their respective General Managers. The General Manager.
along with the HR Officer of the Circle, will Iinalize tlle top three emplo.v-ees per
division based on the scorecards.

G. EUPLOYEE OF THE MONTH AWARD ANNOUNCEMENT
a) Winners will be announced by the Sth of each month. Employees will be felicitated

with a certilicate by the respective Circle's General Manager. If necessary, this may
be delegated to the Deputy General Manager of the concerned Division.

b) Awardee details, including passport-size photographs, must be sent to the IT
Department at the Corporate Oflice for website publication by the first week of each
month.

H. MODE OF IMPLIMENTATION
The program will initially be implemented offline. An online module is under
development, which will later automate the nomination, evaluation and
announcement processes through an IT platform.

I. FUND
a) Each City/O&M Division is allotted t3,6OO for the printing of Emplogee of the Month
banners/flexes for 12 months (April 2026 to March 2027 ,, at t3OO per month.

Total allocation: {3,600 x 55 Divisions = {1, 98,000

b) The PRO Section of the Corporate Office is allocated t19,8OO for printing 1,980
certificates (55 Divisions 3 employees x 12 months), at t1O per certificate.
"

This initiative, commencing in AprtL2O26 (FY 20.26-271, marks a significant step
towards cultivating a motivated, high-performing and cu stomer

sed workforce.

Enclosures: Annexures I to V.

0

IC

(Sampurnanand Shuklaf
Gener{2I'ranaser (Admin & PGRI

<!-- page 4 -->

MD/MK/A&PGR/

Bhopal dated:

Copy To:1. The Director CommerciaTl Technical/PDTc, O/o MD (CZ) MPMKWCL, Bhopal.
2. The Chief General Manager (HR&A) O/o MD, MPMKWCL, Bhopal.
3. The Chief Financial Officer, O/o MD, MPMKWCL, Bhopal.
4. The Chief General Manager Commercial/ Vigilance/ Rural Project/Urban
Project/ IT/SCADAlR lProcurementl Olo MD, MPMKWCL, Bhopal.
5. The Chief General Manager (BR)/ (GR), MPMKWCL, Bhopal/Gwalior .
6. The Deputy Chief General Manager (CommerciallHTlcivil/NCE/Works &
Planning/QCMM/ROC, O/o MD, MPMKWCL, Bhopal.
7. The
(HRGeneral
(HR-I)/Admin/PGR/
Manager
tI) I I*gaJ I ITl Civil/ O&M / Commercial/WORKs & PLANNING / (MAINTENANCE &
BREAKDOWN/Procurement, O/o MD, MPMKWCL, Bhopal.
8. The DGM (Commercial/Admin/PGR/Estt./HR-I, II,III,IV,V,VI/Rec./IT/Works &
Planning/Procurement/NCE/QCMM/SM&O)/Scada/Rural/Urban, O I o MD,
MPMKWCL, Bhopal.
e. The Dy. Genera-l Manager (HR), (BR/GR)/ (CitV)/ (O&M), MPMKWCL........
10. The Sr. Publicity Officer/ Sr. Security Officer, Of o MD, MPMKWCL, Bhopal.
11. The PS to MD, MPMKWCL, Bhopal.
12. The Company Secretar5r, O/o MD, MPMKWCL, Bhopal.
13. Manager (HR)-(V/Admin and PGR), O/o MD (CZ) Bhopal.
t4. Manager (HR)/Accounts Officer (BR)/ (GR) / (City)/(O&M), MPMKWCL
15. Accounts Officer, (HOAU), O/o MD (CZ) Bhopal,
16. Legal Officer, O/o MD (CZ\ Bhopal
t7. Sr. Steno to MD/Jr. Steno to CGM (HR&A) O/o MD {CZ),Bhopal.
18. The Section Officer (Estt)/ (conlidentia-l Section), o/o MD, MpMKwcL, Bhopal.
19. The Webmaster, O/o MD, MPMKWCL, Bhopal-For Information and necessary
action. The aforesaid order may invariably be posted on theAompany's website.
20. Data Cell/Order File/Serial Copy/Library.

blC*,\f,

4

Manager (Admin & PGR)

<!-- page 5 -->

3479801/2025/MKVVCL-CO(A&P)

w

ANrcer.uce

a.u. itrtrr eln fr{F frdtsu 6ttfr frft}s, ailurfr

sant rri Rqirs

EMPI-OYNE OF TNf MONTH CNRTIFICATE

frvcr qrsr

t fu *7ag'ry5/9$...........

qtFrrr
...........ci IIIE...-.............- eo-... *

(Fr{rfuf,/€frq7anqqq*fl) orqfaq
fti\ "WI{ dfqr cqsr" c}w d irqfrdfrnn rrrntl
xrE vrErter ontntr) q-s. qq a\T Ergil fumq cftr$ exr qrr q) €)yr{ ftX rA qteor{ t frrq m[rJr &t{r
o*, 11 qrrSi aqril sfirr frril t ffi 6 qi:q q#iqil u) *{rr sfir *f,TrEq Fr&rn t

ffi

3rrr* sirorttrr qfu ff mrqqr CI-r& tl

TSTFT

qgtcdsrr (*ra/rta.riw)

fu{iqt

q.c. cq dn Egtrfrtrtlt ffi

16
File No. MKVVCL/26/0534/2025-APGR-MKVVCL (Computer No. 721745)
Generated from eOffice by RAJENDRA KUMAR HINGWEY, J.STENO(RKH)-ADMIN & GPR, JUNIOR STENOGRAPHER, MADHYA KSHETRA VIDYUT VITRAN COMPANY LIMITED on 26/03/2026 11:00 am

Aiftb, .....-....-....

-I

<!-- page 6 -->

3479801/2025/MKVVCL-CO(A&P)

I
1.OF

'tt

ANN€XU(E - IL

iF,rqkm 3q ardtmsm ( tt6{/ rfl ,uffi . ) T[8:[ril[, ., ..,, ., ..., . .,.,lei

4

a

6ru{6s ffilr[liro (srfl./su.)/(err{)

a

Tm....

3M a{r6............... 2025 d

orffi em ffi fua rqe ord Glurca d frrA oud em rsfud

a

er{E
3@rffir
ffau

G'EftI

ffi

16@ m
ffiIET

mt

ardt

HIIET

0cimt

ltrkn

drdr/fr.6

!ta/td.
irtt!"'

ft-

rd{d 6ftt61 +1 qsd frt rrra *fffi d g*rorrmv

qru etrr frgd fd-d{ut iisfr ffi., frqrm
# qrweET
,ifrtr!"I.
M
hm
qfti-a-.

arn,

afrqrf,-aozoz:;website : portal.mpcz.in
17

File No. MKVVCL/26/0534/2025-APGR-MKVVCL (Computer No. 721745)
Generated from eOffice by RAJENDRA KUMAR HINGWEY, J.STENO(RKH)-ADMIN & GPR, JUNIOR STENOGRAPHER, MADHYA KSHETRA VIDYUT VITRAN COMPANY LIMITED on 26/03/2026 11:00 am

t

tollof,, us on :
O fb,com/mpcr.bhopal
I x.com/mpeDiscom
O @JansamparkMPcz

I

mpmkwclbhopal

<!-- page 7 -->

4283207/2025/MKVVCL-CO(A&P)
Annexure-III
01- Serving the highest number of new connections
(Agricultural, TC, DLF, etc.).
02- Prompt release of NSC/Highest number of NSC
served as percentage of total consumers.
03- Implementation of load enhancements.
04- Reporting of power theft (direct or metered).
05- Reporting of tariff misuse cases.
06- Meter replacement/installation
connections).

(Urban,

07- Identifying tampered
Metering Project.

under

meters

NDL,

the

IP

Smart

08- DTR-wise energy auditing and remedial measures.
09- Effective disconnection and DTR lifting.
10- Physical verification of disconnected services.
11- Conversion from non-payee to payee consumers.
12- Recovery of dead arrears.
13- Reporting of fictitious connections.
14- Withdrawal of false demands.
15- Consumer indexing.
16- KYC implementation.
17- Reporting/removal
jumperings.

of

agriculture-DL

cross-

18- Fast and satisfactory resolution of consumer
complaints and CM Helpline complaints.
19- Maintenance of lines and DTRs.
20- Minimizing breakdowns/tripping in urban and
industrial areas/Minimum tripping.
21- Feeder-wise energy accounting.
22- Feeder-wise tripping numbers.
23- Feeder-wise tripping duration.
24- % maintenance completed.
25- Planned shutdown + Breakdown numbers.
26- Highest number of pump load checking
percentage of toal Pump Connections.

as

27- PM Surya Ghar net meter agreement within 02 days.
28- PM Surya Ghar inspection approval within 07 days.
29- RPU, CRPU increase.
30- Financial progress - Project.
31- Physical progress - Project.
32- Physical progress - SSTD.
33- Recovery of arrears30
under Samadhan Yojna.
File No. MKVVCL/26/0534/2025-APGR-MKVVCL (Computer No. 721745)
Generated from eOffice by RAJENDRA KUMAR HINGWEY, J.STENO(RKH)-ADMIN & GPR, JUNIOR STENOGRAPHER, MADHYA KSHETRA VIDYUT VITRAN COMPANY LIMITED on 26/03/2026 11:00 am

<!-- page 8 -->

3479801/2025/MKVVCL-CO(A&P)

limployee of thc Month -*Month

20 25- 26" -lndividual Score-card (Annexure-rv)

Name of Cily ZonelTown 7.one/ DC....
Name of Employee
Designation
................EmpIoyee code............
S.No.

A. Actlvities Selected by

Corporate Offlco

Scor€ /16 €ach (variable
as per number of

lotal Score/8o (Total Scorc/loo

Grand lotal

s€orehoo

a(tivltlrrl

if no activities selected by Circle
office!

score/10 each

Total Score/20

Remarks

1

2
3
4
5

Or more

S.No.

B. Activities Selected by Circle

Office

1

2

Name of Manager/Asst. Manager

Signature

18
File No. MKVVCL/26/0534/2025-APGR-MKVVCL (Computer No. 721745)
Generated from eOffice by RAJENDRA KUMAR HINGWEY, J.STENO(RKH)-ADMIN & GPR, JUNIOR STENOGRAPHER, MADHYA KSHETRA VIDYUT VITRAN COMPANY LIMITED on 26/03/2026 11:00 am

Date

<!-- page 9 -->

3479801/2025/MKVVCL-CO(A&P)

S.No

II

Employee Name,
Deslgnation and
employee code

t{ame ot clty

Zonefiown

zonelDc

I

II

lactivitv 2

ll.':',ffi ls'o'."rie

Division (Annexure-v)

2025-26"-

Employce of thc Month - -"Month
Activity 3
score/16

IIIII]

|

I III
III

ru;*llx;l; lt#xsl *.,:;l; '""," more
I

Signature
Signature

Name of GM

Rank

I

rII
II

Name of DGM

Total
Score,/10O

19
File No. MKVVCL/26/0534/2025-APGR-MKVVCL (Computer No. 721745)
Generated from eOffice by RAJENDRA KUMAR HINGWEY, J.STENO(RKH)-ADMIN & GPR, JUNIOR STENOGRAPHER, MADHYA KSHETRA VIDYUT VITRAN COMPANY LIMITED on 26/03/2026 11:00 am

I

III
Date
Date

Remarks
