---
doc_id: "d2f6fc46ac6f0f0d"
source_url: "https://tfri.icfre.gov.in/tender/tender11.pdf"
ministry: "ICFRE - Tropical Forest Research Institute, Jabalpur, Madhya Pradesh"
title: "विश्राम गृह/छात्रावास में, विभिन्न प्रशिक्षणों/कार्यशालाओं/ सेमिनारों और अन्य आधिकारिक कार्यक्रमों के दौरान खानपान सेवाएं (नाश्ता, दोपहर का भोजन, रात्रि भोजन, हाई टी आदि) प्रदान करने के लिए दर अनुबंध हेतु पैनल बनाना"
date: ""
pages: 22
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "fafaa0f1ec77db71"
---

<!-- page 1 -->

jaq

Price: Rs. 590/-

नननिदा दस्तािेज़
TENDER DOCUMENT

2025-26
विश्राम गृह/छात्रािास में, निनभन्न
प्रनिक्षणों/कायािालाओं/ सेनमनारों
और ऄन्य अनधकाटरक कायाक्रमों के
दौरान खानपान सेिाएं (नाश्ता,
दोपहर का भोजन, रानत्र भोजन, हाइ
िी अदद) प्रदान करने के नलए दर
ऄनुबंध हेतु पैनल बनाना

भा.िा.ऄ.नि.प. ईष्ण कटिबंधीय िन ऄनुसंधान संस्थान
भारतीय िाननकी ऄनुसंधान एिं निक्षा पटरषद
(पयाािरण, िन एिं जलिायु पटरितान मंत्रालय,
भारत सरकार के अधीन एक स्िायत्त पटरषद)
जबलपुर- 482021, मध्यप्रदेि
ICFRE-TROPICAL FOREST RESEARCH INSTITUTE

Indian Council of Forestry Research & Education
(An Autonomous Body of Ministry of Environment,
Forest & Climate Change, Govt. of India)
Jabalpur-482021, Madhya Pradesh

1

Empanelment for Rate
contract to provide
Catering Services (for
Breakfast, Lunch,
Dinner, High Tea etc) in
Rest House/Hostel,
during different
trainings/workshops/semi
nars and other official
programmes
intermittently

<!-- page 2 -->

ऄग्रेषण पत्र
(नननिदादाता द्वारा भरा जाना)
ददनांक:
सेिा में,
ननदेिक
भा.िा.ऄ.नि.प. - ईष्ण कटिबंधीय िन ऄनुसंधान संस्थान
पीओ: अरएफअरसी, मंडला रोड, जबलपुर - 482021, मध्य प्रदेि
निषय: भा.िा.ऄ.नि.प. - ईष्ण कटिबंधीय िन ऄनुसंधान संस्थान जबलपुर में

‘निश्राम गृह/छात्रािास में, निनभन्न

प्रनिक्षणों/कायािालाओं/ सेनमनारों और ऄन्य अनधकाटरक कायाक्रमों के दौरान खानपान सेिाएं (नाश्ता, दोपहर का भोजन, रानत्र
भोजन, हाइ िी अदद) प्रदान करने िास्ते दर ऄनुबंध हेतु पैनल बनाने के नलए’ एक िषा हेतु दर ऄनुबंध नननिदा।
संदभा: अपकी नननिदा सूचना क्रमांक: 120-(A)/Catering/Estate/TFRI/JBP/593, ददनांक 28/07/2025
महोदय,
अपके नननिदा दस्तािेज़/नननिदा प्रपत्र में निननर्ददष्ट दकए गए ऄनुसार भा.िा.ऄ.नि.प. - ईष्ण कटिबंधीय िन ऄनुसंधान
संस्थान जबलपुर में ‘निश्राम गृह/छात्रािास में, निनभन्न प्रनिक्षणों/कायािालाओं/ सेनमनारों और ऄन्य अनधकाटरक कायाक्रमों के
दौरान खानपान सेिाएं (नाश्ता, दोपहर का भोजन, रानत्र भोजन, हाइ िी अदद) प्रदान करने िास्ते दर ऄनुबंध हेतु पैनल बनाने
के नलए’ एक िषा हेतु दर ऄनुबंध के नलए नननिदा प्रस्तुत की जानी है।
नननिदा प्रपत्र िुल्क के नलए ननदेिक, भा.िा.ऄ.नि.प. - ईष्ण कटिबंधीय िन ऄनुसंधान संस्थान, जबलपुर को देय रुपये
590/- (ऄक्षरों में रुपये पााँच सौ नब्बे मात्र) की रानि का ड्राफ्ि क्र. ............................. ददनांक ......................... बैंक का
नाम ………………................................. अपके कायाालय में ददनांक ............................... को प्रस्तुत कर ददया है।
साथ ही बोली

सुरक्षा रानि ( EMD) का ड्राफ्ि क्र. . ............................. ददनांक ........... .................. बैंक का नाम

……….............………… अपके कायाालय में ददनांक .............................. को प्रस्तुत कर ददया है।
नननिदा संबंधी सभी ननबंधन एिं ितों को पढ़ नलया है एिं समझ नलया है। नननिदा की ननबंधन एिं ितों की पालना
करने हेतु सहमनत प्रदान की जाती है।
नननिदा दस्तािेज के सभी पृष्ठों में , घोषणा पत्र में , निननर्ददष्ट स्थान पर तथा संलग्न प्रमाण पत्रों/दस्तािेजों में फमा की
मुहर सनहत निनधित हस्ताक्षर कर ददए गए हैं तथा निननर्ददष्ट स्थान पर अिश्यक प्रनिनष्टयााँ कर दी गयी हैं।
भिदीय
संलग्न: यथािर्णणत
नननिदादाता/ऄनधकृ त हस्ताक्षरकताा के
मुहर सनहत हस्ताक्षर
नाम तथा पूरा पता

2

<!-- page 3 -->

भा.िा.ऄ.नि.प. - ईष्ण कटिबंधीय िन ऄनुसंधान संस्थान, जबलपुर
नननिदा प्रपत्र (नननिदादाता का नििरण)
1

नननिदादाता का नाम (बडे ऄक्षरों में)

2

नननिदादाता के नपता का नाम (यदद लागू
हो)

३

नननिदादाता की फमा का नाम

4

फमा का पूणा स्थायी पता

5

नननिदादाता की पंजीकरण / िीएन (TAN)
संख्या

6

मोबाआल नंबर, फोन नंबर और इ मेल नंबर

7

जी.एस.िी. संख्या (GST No.)

8

पैन संख्या (PAN No.)

9

फमा के बैंक का ितामान नाम, पूणा पता और
खाता संख्या

3

<!-- page 4 -->

(ICFRE-TROPICAL FOREST RESEARCH INSTITUTE)
(Indian Council of Forestry Research & Education)
PO: RFRC, Mandla Road, Jabalpur - 482021, Madhya Pradesh
No. 120-(A)/Catering/Estate/TFRI/JBP/593
Dated:

28/07/2025

भा.िा.ऄ.नि.प.- ईष्ण कटिबंधीय िन ऄनुसंधान संस्थान, जबलपुर में "विश्राम गृह/छात्रािास में, निनभन्न
प्रनिक्षणों/कायािालाओं/सेनमनारों और ऄन्य अनधकाटरक कायाक्रमों के दौरान खानपान सेिाएं (नाश्ता, दोपहर का भोजन,
रानत्र भोजन, हाइ िी अदद) प्रदान करने के नलए दर ऄनुबंध हेतु पैनल बनाना" आच्छु क पार्टियों से नननिदाएं अमंनत्रत की
जाती है।
Tenders are invited from the interested parties for "Empanelment for Rate contract to provide Catering
Services (for Breakfast, Lunch, Dinner, High Tea etc) in Rest House/Hostel, during different
trainings/workshops/seminars and other official programmes intermittently" in ICFRE-Tropical Forest
Research Institute, Jabalapur.
नननिदा प्रपत्र / नननिदा दस्तािेज प्राप्त एिं जमा करने की जानकारी
नननिदा प्रपत्र/नननिदा दस्तािेज िुल्क ₹ 590/- (500+18% GST = ₹ 590/-) (गैर-िापसी योग्य) नगद या नडमांड
ड्राफ्ि के रूप में , जो दक ननदेिक , ईष्ण कटिबंधीय िन ऄनुसंधान संस्थान, जबलपुर के नाम बना कर आस कायाालय/संस्थान के
लेखानुभाग को प्रस्तुत करके या Director, TFRI Bank A/c No. 325702011000102 (Union Bank of India, TFRI
Branch, Jabalpur), IFSC Code: UBIN0564885 में जमा कर ईसका प्रमाण प्रस्तुत करके , ददनांक 30 -07-2025 से
18-08-2025 तक (प्रातः 10:00 बजे से िाम 5:00 बजे तक) आस कायाालय से प्राप्त दकये जा सकते है । नननिदा प्रपत्र िेबसाआि
https://tfri.icfre.org/tenders या https://www.icfre.org/tenders से डाईनलोड दकया जा सकता है । जो भी इच्छु क
विविदादाता नननिदा प्रपत्र ईक्त िेबसाइट से डाउिलोड करें गे, उन्हें नननिदा प्रपत्र शुल्क ₹590/- (₹500 + 18% GST) (ग़ैरिापसी योग्य) का भुगताि करिा होगा तथा भुगताि का प्रमाण, विम्नािुसार सील बंद बडे वलफाफे के साथ इस कायाालय में
जमा करिा अवििाया होगा। नननिदा प्रपत्र/नननिदा दस्तािेज आस कायाालय/संस्थान के सम्पनत्त ऄनुभाग से प्राप्त दकये जा

सकते हैं तथा जमा सम्पनत्त ऄनुभाग में दकया जाना है ।
ईपरोक्तानुसार नननिदा का नाम नलखा हुअ सील बंद बडा नलफा फा आस कायाालय में ददनांक 19-08-2025 दोपहर
3:00 बजे तक प्राप्त हो जाना चानहए। आस नलफाफे में दो ऄलग ऄलग सील बंद छोिे नलफाफे रखे होने चानहए जो एक तकनीकी
बोली का होगा

(नननिदा दस्तािेज के सभी पृष्ठों में

पत्रों/दस्तािेजों को संलग्न कर ईसमें फमा की मुहर सनहत

, घोषणा पत्र में , निननर्ददष्ट स्थान पर तथा मांगे गए प्रमाण
निनधित हस्ताक्षर कर तथा निननर्ददष्ट स्थान पर अिश्यक

प्रनिनष्टयााँ कर तथा ऄन्य सम्बंनधत दस्तािेज आस नलफाफे में रखे जायेंगे )

। दूसरा नलफाफा नित्तीय बोली का होगा (आस

नलफाफे में ददए गए प्रारूप में नसफा नित्तीय बोली की दर ईद्धृत कर रखा जायेगा

। प्रारूप पृष्ठ संख्या 16, ऄनुलग्नक- III में

ईपलब्ध है) । नलफ़ाफे में साफ़ तौर पर ‘तकनीकी बोली’ और ‘नित्तीय बोली’ नलखा होना चानहए । ननयत समयािनध के पश्चात्
प्राप्त नननिदा प्रपत्र को स्िीकार नहीं दकया जायेगा । नननिदा प्रपत्र पूणा रूप से भरे होना चानहए
करना एिं सभी दस्तािेजों के पृष्ट पर फमा की मोहर सनहत हस्ताक्षर दकये जाना है

। सभी दस्तािेजों को संलग्न

। ददनांक 19-08-2025 दोपहर 3:30 बजे

प्राप्त नननिदा (तकनीकी बोली) खोली जाएगी । आच्छु क नननिदाकार (तकनीकी बोली और नित्तीय बोली) खुलने के समय स्ियं
ईपनस्थत हो सकते हैं ऄथिा ऄपना प्रनतनननध भेज सकते है । तकनीकी बोली में सफल नननिदाकार को पृथक से नित्तीय बोली
खुलने की सूचना दी जाएगी ।
नोि: नननिदा प्रपत्र िुल्क का प्रमाण जमा न करने की नस्थनत में नननिदा ऄस्िीकार कर दी जाएगी । ईक्त नलफ़ाफा को
डाक द्वारा भी उपर ददए गए पते पर भेजा जा सकता है ।

4

<!-- page 5 -->

समय – सारणी

नननिदा दस्तािेज नबक्री िुरू होने की तारीख

ददनांक 30-07-2025, प्रातः 10:00 बजे

नननिदा जमा दकए जाने की अरं भ की तारीख

ददनांक 30-07-2025, दोपहर 03:00 बजे

नननिदा दस्तािेज नबक्री समानप्त की तारीख

ददनांक 18-08-2025, िाम 5:00 बजे

नननिदा जमा दकए जाने की समानप्त की तारीख

ददनांक 19-08-2025, दोपहर 3:00 बजे

नननिदा खुलने की तारीख

ददनांक 19-08-2025, दोपहर 3:30 बजे

नननिदा की ऄंतिास्तु
CONTENT OF TENDER
1. बोली दाता के नलये ननदेि, ऄनुलग्नक-I/Instructions to bidder, Annexure-I
2. ननयम ि ितें, ऄनुलग्नक-II/Terms & Conditions, Annexure-II
3. खाद्य पदाथों की दर/मूल्य निभाजन सूची ( नित्तीय बोली), ऄनुलग्नक-III/Rate List/Price breakup of food items
(Financial Bid), Annexure-III
4. काया का दायरा, ऄनुलग्नक-IV/Scope of Work Annexure-IV
5. बोली सुरक्षा घोषणा, ऄनुलग्नक-V/Bid Security Declaration, Annexure-V

5

<!-- page 6 -->

ऄनुलग्नक-I /Annexure-I
बोलीदाता के नलये ननदेि /Instructions to Bidders
1.

मुख्य बबदु /Key points:

 नननिदादाता को नननिदा प्रपत्र के मूल्य के तौर पर रुपये

590/- का नडमांड ड्राफ्ि ननदेिक, ईष्ण कटिबंधीय िन

ऄनुसंधान संस्थान जबलपुर के पक्ष में बना कर कायाालयीन समय पर ननयत समयािनध तक प्राप्त दकये जा सकते है
और नननिदा प्रपत्र प्राप्त करते समय फमा का लेिर हेड लाना होगा।
 नननिदादाता द्वारा नननिदा प्रपत्र कायाालयीन समय पर ननयत समयािनध तक जमा दकये जा सकते है ।
 बोलीदाता प्रत्येक अआिम के अधार पर प्रनत प्लेि, कप, थाली, नग अदद की दर दिााएगा। आन दरों का ईपयोग
िास्तनिक ऑडार के समय दकया जायेगा। 
The bidders will quote the unit rates per plate, cup, thali, nos. etc. depending upon the individual item.
These rates will be used at the time of actual.
 कायाालयीन प्रयोजनों के नलए िास्तनिक अिश्यकता की सूचना समय-समय पर सेिा प्रदाता को दी जाएगी, जो
अयोजन के अधार पर ईच्चतर गुणित्ता/मानक की हो सकती है, ऄनुलग्नक III में मांगी गइ दर दिाायी जा सकती है ।
The actual requirement for official purposes will be intimated to the service provider from time to
time, which may be of higher quality/standard depending on the event; a rate may be quoted as
demanded in annexure III.
 सेिा प्रदाता तदनुसार संस्थान को प्रदाय की गइ सेिाओं के नबल अपूर्णत/काया अदेि के साथ प्रस्तुत करे गा।
 The Service Provider shall accordingly submit the bill for the services provided to the Institute along
with the supply/work order.
 भुगतान की ितें: संस्थान के िल अनधकाटरक बैठकों, प्रनिक्षणों अदद के नलए अदेनित िस्तुओं/सेिाओं के नलए
भुगतान करे गा। संस्थान द्वारा दकसी भी प्रकार का ऄनग्रम भुगतान नहीं दकया जाएगा। तथानप, यदद
प्रनिक्षण/सेनमनार/ऄन्य कायाक्रम एक सप्ताह से ऄनधक ऄिनध के हैं तथा प्रनिक्षण/सेनमनार/ऄन्य कायाक्रमों में भाग लेने
िाले प्रनतभानगयों की संख्या 25 से ऄनधक है, तो संस्थान बोलीदाता के ऄनुरोध पर तथा अिंटित काया के
सफलतापूिाक पूरा होने तथा ईसके नलए नबल प्रस्तुत करने पर काया अदेि के अंनिक भुगतान पर निचार कर सकता
है।
Payment terms: The institute will make payments only for the items/services ordered for official
meetings, trainings, etc. No advance of any kind will be made by the Institute. However, if the
trainings/seminars/other programmes are of more than 1 week duration and the number of participants
in the trainings/seminars/other programmes is more than 25, the Institute may consider part payment
of the work order on the request of bidder and successful completion of allotted work and submission
of bills for the same.
 संस्थान ऄपने कमाचाटरयों/ग्राहकों को प्रदान की गइ सेिाओं/बेची गइ िस्तुओं के नलए सेिा प्रदाता के प्रनत ईत्तरदायी
नहीं होगा। आन ग्राहकों को प्रदान की गइ सेिाओं के नलए भुगतान एकत्र करना सेिा प्रदाता की एकमात्र नजम्मेदारी है।
The Institute will not be responsible to the Service Provider for the services provided/ items sold by it
to the individual employees/customers. It is the sole responsibility of the Service Provider to collect
payments for the services provided to these customers.
2.

रुपये 30000/- की बोली सुरक्षा रानि (EMD) ननदेिक िीएफअरअइ, जबलपुर के पक्ष में नडमांड ड्राफ्ि के रूप में
होनी चानहए जो जबलपुर में देय हो। बोली सुरक्षा (EMD) के नबना सभी नननिदाएं सरसरी तौर पर खाटरज कर दी
जाएंगी।
Bid Security (EMD) of Rs 30000/- must be in the form of Demand Draft in favor of Director TFRI,
Jabalpur payable at Jabalpur. The Tenders without Bid Security (EMD) will be summarily rejected.

3.

बोली सुरक्षा (इएमडी) की हाडा कॉपी ननधााटरत समय पर ननदेिक, ईष्णकटिबंधीय िन ऄनुसंधान संस्थान, जबलपुर,
6

<!-- page 7 -->

मध्य प्रदेि-482021 के कायाालय में पहुंच जानी चानहए।
Hard Copies of Bid Security (EMD) must reach the Office of the Director, Tropical Forest Research
Institute, Jabalpur, Madhya Pradesh-482021 on scheduled.
4.

सफल बोलीदाताओं की बोली सुरक्षा ननदेिक िीएफअरअइ, जबलपुर के पक्ष में नडमांड ड्राफ्ि के रूप में प्रदिान
नसक्योटरिी जमा करने पर जारी की जाएगी।
The Bid Security of the successful bidders will be released on submission of Performance Security in
form of Demand Draft in favor of Director TFRI, Jabalpur.

5.

ऄसफल बोलीदाताओं की बोली सुरक्षा रानि नननिदा प्रदक्रया पूणा होने के बाद 30 ददनों की ऄिनध के भीतर नबना
दकसी ब्याज के जारी कर दी जाएगी।
The bid security amount of the unsuccessful bidders will be released without any interest within a
period of 30 days after completion of the tender process.

7. नननिदा को ऄंनतम रूप ददए जाने की नतनथ से ऄनुबंध की ऄिनध तक ननष्पादन सुरक्षा रानि बरकरार रखी जाएगी।,
नजसके पश्चात काया ननष्पादन सुरक्षा रानि, नबना दकसी ब्याज के , ऄनुबंध की समानप्त के पश्चात जारी कर दी जाएगी,
बिते दक ऄनुबंध की सभी ितें पूरी की गइ हों। दर ऄनुबंध को अपसी सहमती से सक्षम प्रानधकारी द्वारा ईनचत समझी
गइ ऄिनध के नलए बढ़ाया जा सकता है।
The Performance Security will be retained for the period of Contract from the date of finalization of the
Tender after which, the Performance Security, without any interest will be released after expiry of the
contract, subject to fulfillment of all the terms & conditions of the contract. The Rate Contract with
mutual consent may be extended for a period as deemed fit by the Competent Authority.
8. नननिदाकताा को ऄपना प्रस्ताि िापस लेने या ईसके ननयमों और ितों को संिोनधत करने की ऄनुमनत नहीं होगी।
यदद नननिदाकताा यहां दी गइ ितों का पालन करने में निफल रहता है या दरें बताने के बाद पीछे हि जाता है, तो बोली
सुरक्षा की ईपरोक्त रानि जब्त कर ली जाएगी।
Tenderer shall not be permitted to withdraw his/her offer or modify the terms and conditions thereof. In
case the Tenderer fail to observe and comply with stipulation made herein or he/she/it backs out after
quoting the rates, the aforesaid amount of Bid Security will be forfeited.
9. बोली सुरक्षा की रानि पर ब्याज के संबंध में िीएफअरअइ के निरुद्ध कोइ दािा नहीं दकया जा सके गा।
No Claim shall lie against TFRI in respect of interest on the amount of Bid Security.
10. एक नननिदाकताा/बोलीदाता के िल एक ही नननिदा दस्तािेज प्रस्तुत करे गा।
One Tenderer/Bidder will submit only one tender document.
11. िेंडर दस्तािेज़ में छे डछाड और संिोधन करना सख्त िर्णजत है। यदद िेंडर दस्तािेज में दकसी भी तरह से छे डछाड या
संिोधन पाया जाता है, तो िेंडर को ऄस्िीकार कर ददया जाएगा, बोली सुरक्षा रानि जब्त कर ली जाएगी और
िेंडरकताा/बोलीदाता को काली सूची में डाल ददया जाएगा।
Tampering and modification of the Tender document is strictly prohibited. In case tender document is
found to be tampered or modified in any manner, the tender will be rejected, the Bid Security will be
forfeited and the Tenderer/ Bidder will be blacklisted.
12. नननिदा का ऄनुमाननत मूल्य/नननिदा लागत 10 लाख से 15 लाख तक है जो 25% तक बढ़ या घि सकता है।
Approximate value of tender/Tender cost varies from 10 lakhs to 15 lakhs which may increase or
decrease by 25%.
13. ननदेिक, भा.िा.अ.नि.प.-ईष्ण कटिबंधीय िन ऄनुसंधान संस्थान जबलपुर को ऄनधकार होगा दक:
(क) प्रस्ताि को पूणातया ऄथिा ईसके दकसी भाग को स्िीकार करें ऄथिा ऄस्िीकार कर दें
(ख) प्राप्त सभी प्रस्ताि ऄथिा दकसी प्रस्ताि को पूणातया ऄथिा ईसके दकसी भाग को ऄस्िीकार कर दें
(ग) नननिदा सूचना को रद्द कर दें ऄथिा िानपस ले लें
(घ) दकसी नननिदा या ईसके भाग को रद्द कर दें ऄथिा स्िीकार करें
(ङ) नननिदा प्रस्ताि की ितो के निचलन/ऄंतर को नबना कारण बताए स्िीकार या ऄस्िीकार कर दें
14. नननिदा की िैधता हेतु नननिदा दस्तािेज़ पर हस्ताक्षरकताा / हस्ताक्षरकतााओं को यह स्पष्ट करना होगा दक िह/िे दकस
7

<!-- page 8 -->

प्रानधकार से नननिदा प्रस्तुत कर रहा है

/ रहें है यथा पूणा

स्िानमत्ि / ननमााणकताा / साझेदार / प्रनतनननध (ऄिनी)

(साक्ष्य ददया जाना होगा) के तौर पर ऄथिा ऄनधकृ त डीलर /प्रनतनननध(साक्ष्य ददया जाना होगा) के तौर पर नननिदा के
साथ ऄपेनक्षत होने पर प्रानधकार पत्र संलग्न न होने की दिा में नननिदा ऄस्िीकार की जा सकती है ।
15. फमा को नननिदा दस्तािेज़ के सभी पृष्ठों पर हस्ताक्षर कर मुहर लगानी होगी ।
16. सक्षम प्रानधकारी आस नननिदा हेतु न्यूनतम दर पर नननिदा स्िीकार करने के नलए बाध्य नही है । चूाँदक निश्वसनीयता
तथा गुणित्ता का ध्यान रखना जरूरी है।
17. ईष्ण कटिबंधीय िन ऄनुसंधान संस्थान जबलपुर में सरकारी कायाक्रम के दौरान कै िररग सर्णिस व्यिस्था के नलए इमेल या नलनखत कायाादेि प्राप्त होने के बाद सेिा प्रदाता कायाादेि के ऄनुसार भोजन अदद की अपूर्णत की व्यस्था ननयत
समयािनध में करे गा
18. यदद न्यूनतम दर पर बोली देने िाला सेिा प्रदाता सेिा देने से मना कर देता है ऄथिा कायाादेि प्राप्त होने के बाद काया
ननष्पादन में ऄसफल रहता है तो कायाादेि पैनल में ऄगले ईच्चतर बोलीदाता को ईसी दर (पूिा िाली न्यूनतम दर) पर
जारी दकया जा सके गा। गैर अपूर्णतकताा फमा के इएमडी , परफामेंस नसक्योटरिी तथा फमा के बकाया नबल भुगतान, यदद
कोइ हो तो, जब्त कर नलए जायेंगे । आस नस्तनथ में ननदेिक, ईष्ण कटिबंधीय िन ऄनुसंधान संस्थान, जबलपुर के अदेि
ऄंनतम होंगे।
19. काया अदेि प्राप्त करने िाली फमा भोजन परोसने के नलए ऄच्छी गुणित्ता िाली क्रॉकरी का प्रयोग करे गा

। यदद यह

पाया जाता है की काया अदेि प्राप्त करने िाली फमा प्लानस्िक के फें कने योग्य िस्तुओं (नडस्पोजेबल) का प्रयोग कर रही
है ि ऄनुनचत रूप से ननस्तारण कर रही है तो ईन से जुमााना िसूल दकया जा सके गा ऄथिा जुमााने की रानि ईनके
ननष्पादन सुरक्षा रानि से िसूल दकया जा सके गा । नडस्पोजल ि प्लानस्िक अदद प्रदूषण कारी िस्तुएाँ ईपयोग में लेने की
मनाही होगी।
20. ननदेिक, ईष्ण कटिबंधीय िन ऄनुसंधान संस्थान, जबलपुर के पास दकसी भी नननिदा पर सम्पूणा रूप से या ईसके
ऄंि पर अदेि देने का ऄनधकार है

। दस्तािेजों की ितो में निरोधाभास होने पर आस सम्बन्ध

में ननदेिक , ईष्ण

कटिबंधीय िन ऄनुसंधान संस्थान, जबलपुर का ननणाय ऄंनतम तथा बाध्यकारी होगा तथा नननिदाकार/सेिा प्रदाता
द्वारा स्िीकाया होगा।
21. ननम्ननलनखत दस्तािेज़ों को निनधित हस्ताक्षर के बाद क्रमिार संलग्न करें । साथ ही, प्रत्येक दस्तािेज़ के अगे पृष्ठ
संख्या भी ऄंदकत करें । यदद पृष्ठ संख्या के ऄभाि के कारण नननिदा मूल्यांकन में कोइ त्रुटि होती है, तो बोलीदाता स्ियं
आसके नलए ईत्तरदायी होगा:The following documents are to be enclosed serial wise after duly signed. Also, indicate the
page nos. against each of it. If any mistake occurs in tender evaluation due to absence of page numbers,
the bidder himself will be responsible for it :तानलका I/Table I
S.No.

i.

ऄपलोड दकए जाने िाले प्रमाणपत्र / दस्तािेज / Certificates/Documents to
be uploaded

खाद्य सुरक्षा और मानक ऄनधननयम, 2006 के तहत िैध लाआसेंस की प्रनत ऄथाात
FSSAI का प्रमाणन की प्रनत (यदद बोलीदाता FSSAI प्रमाण पत्र प्रस्तुत करने में
निफल रहता है, तो बोलीदाताओं द्वारा ऄन्य अिश्यक दस्तािेज प्रस्तुत करने के
बािजूद तकनीकी मूल्यांकन में अिंटित ऄंक िून्य '0' होंगे और ईक्त बोली को
ऄस्िीकार कर ददया जाएगा) / Copy of Valid License under Food Safety
and Standards Act, 2006 i.e. Copy of Valid FSSAI Registration
certificate (If the bidder fails to submit FSSAI certificate, the marks
allotted in the technical evaluation will be zero '0' inspite of submission
of other required documents by the bidders and the said bid will be
8

प्रासंनगक दस्तािेज (पृष्ठ
संख्या) / Relevant
document (Page
No.)

<!-- page 9 -->

rejected)
ii.

बोली सुरक्षा/EMD के रूप में जमा दकए गए 30000 रुपये के नडमांड ड्राफ्ि /
Demand Draft of Rs 30000/-submitted as Bid Security/EMD

iii.

पैन काडा तथा जी.एस.िी. पंजीकरण की प्रनत / Copy of PAN card and GST
Registration
नपछले 03 नित्तीय िषों के अयकर टरिना की प्रनत / Copy of Income Tax
Return for the last 03 financial years
स्थानीय स्तर पर पंजीकृ त कायाालय/व्यिसाय को प्रमानणत करने के नलए दस्तािेज़
की प्रनत / Copy of document to prove Registered office/business at local
level
सरकारी संगठन/पीएसयू/मान्यता प्राप्त निश्वनिद्यालयों में खानपान सेिाओं में काया
ऄनुभि का प्रमाण की प्रनत (सहायक दस्तािेज़ - काया अदेि/संतोषजनक ननष्पादन

iv.
v.

vi.

टरपोिा अदद के रूप में) । न्यूनतम ऄनुभि 1 िषा और ऄनधकतम 7 िषा या ईससे

vii.

ऄनधक (ऄंक अिंिन मानदंड के नलए तानलका II में क्रम संख्या 5 देखें) / Copy of
Evidence of Work Experience in Catering Services in Govt.
organization/PSU/Recognized Universities (Supporting documents – in
the form of work order/satisfactory performance report etc.).
Minimum experience 1 year and maximum 7 years or above (Refer
S.No. 5 in Table II for marks allocation criteria)
फमा/व्यनक्त अदद को 100/- रुपये या ईससे ऄनधक के गैर-न्यानयक स्िाम्प पेपर पर
निीनतम नोिरीकृ त िपथ-पत्र संलग्न करना होगा (नननिदा प्रकािन/अरं भ नतनथ से
नननिदा समानप्त नतनथ तक जारी दकया गया) नजसमें यह दिााया गया हो दक िह या
ईसकी फमा काली सूची में नहीं है। ऄन्यथा ईक्त बोली को ऄस्िीकार कर ददया
जाएगा (आस नस्थनत में, बोलीदाताओं द्वारा ऄन्य अिश्यक दस्तािेज प्रस्तुत करने के

viii.

बािजूद तकनीकी मूल्यांकन में अिंटित ऄंक िून्य '0' होंगे)
The firm/individual etc. must enclose a latest notarized affidavit on
non- judicial stamp paper of Rs. 100/- or more (issued from the tender
publish/start date and by the tender end date) indicating that he or
his firm is not blacklisted. Otherwise the said bid will be rejected (In
this condition, the marks allotted in the technical evaluation will be
zero '0' inspite of submission of other required documents by the
bidders)
कोइ ऄन्य प्रासंनगक दस्तािेज़/प्रमाणपत्र की प्रनत / Copy of Any other
relevant documents/certificates

प्रमुख, सुनिधायें एिं सेिायें
Head Facilities & Services
भा.िा.ऄ.नि.प.- ईष्णकटिबंधीय िन ऄनुसंधान संस्थान
ICFRE-Tropical Forest Research Institute
जबलपुर/Jabalpur, मध्यप्रदेि/Madhya Pradesh

9

<!-- page 10 -->

ऄनुलग्नक-II / Annexure-II
ननयम ि ितें / Terms and Conditions
1. ऄनुबंध की ऄिनध: ऄनुबंध प्रारं भ में एक िषा की ऄिनध के नलए होगा नजसे अपसी सहमनत अगे बढ़ाया जा
सकता है।
Period of Contract: The contract will be initially for a period of one year which may be extended
further with mutual consent.
2. ननयत नतनथ के बाद प्राप्त ऄधूरे प्रस्ताि और नननिदाओं पर निचार नहीं दकया जाएगा। संस्थान दकसी भी डाक देरी
और बोली सुरक्षा की प्रानप्त में देरी के नलए नजम्मेदार नहीं होगा।
Incomplete proposals and tenders received after due date shall not be entertained. The Institute shall
not be responsible for any postal delay and delay in receipt of the Bid Security.
3. संस्थान द्वारा प्राप्त कोइ भी बोली जो िांनछत ननयमों और ितों को पूरा नहीं करती है, ईसे सीधे ऄस्िीकार कर ददया
जाएगा और आस संबंध में कोइ भी पत्राचार नहीं दकया जाएगा।
Any bids received by the Institute which does not fulfill the desired terms and conditions shall be
rejected outright and no communication in this regard shall be entertained.
4. बोली सुरक्षा जब्त की जा सकती है:
a. यदद बोलीकताा बोली िैधता की ऄिनध के दौरान ऄपनी बोली िापस ले लेता है।
b. सफल बोलीकताा के मामले में, यदद बोलीकताा ननम्ननलनखत में निफल रहता है:
i. काया अदेि स्िीकार करने में।
ii. ननष्पादन सुरक्षा प्रस्तुत करने में।
The bid security may be forfeited:
a.
If a bider withdraws his bid during the period of bid validity.
b.
In the case of a successful bidder, if the bidder fails:
i.
To accept the Work Order.
ii.
To furnish Performance Security.
5. प्रदिान सुरक्षा रानि: सफल बोलीदाता, नजसे 'सेिा प्रदाता' कहा जाता है, को 1,00,000/- रुपये की ननष्पादन/प्रदिान
सुरक्षा रानि जमा करनी होगी। प्रदिान सुरक्षा रानि ननदेिक TFRI, जबलपुर के पक्ष में ऄकाईं ि पेयी नडमांड ड्राफ्ि के
रूप में जमा की जाएगी, जो जबलपुर में देय होगी। सफल बोलीदाता को ऄपने प्रस्तुत दस्तािेज में ददए गए पते/फोन
नंबर पर इमेल/एसएमएस/डाक के माध्यम से अनधकाटरक संचार प्राप्त होने के एक सप्ताह के भीतर ननष्पादन सुरक्षा
रानि जमा करनी होगी।
Performance Security amount: The successful bidder referred to as ‘Service Provider’ shall furnish
the Performance Security amount of Rs 1,00,000/-. Performance Security amount will be furnished as
an Account Payee Demand Draft in favour of Director TFRI, Jabalpur payable at Jabalpur. The
successful bidder must submit performance security amount within a week from receipt of official
communication through email/SMS/post on addresses/phone number provided in their submitted
document.
6. ननष्पादन सुरक्षा ऄनुबंध की ऄिनध के नलए िैध होगी। यह रानि ऄनुबंध के सफलतापूिाक पूरा होने के बाद, ऄनुबंध
के तहत सेिा प्रदाता के सम्पूणा दानयत्िों की समानप्त के पश्चात नबना दकसी ब्याज के सेिा प्रदाता को जारी की जाएगी।
The Performance Security shall be valid for the period of the contract. It shall be released to Service
Provider after successful completion of the contract and completion of the Service Provider's entire
obligations, under the CONTRACT without any interest.
7.

सफल नननिदाकताा, नजसे अगे 'सेिा प्रदाता' कहा जाएगा, को ननष्पादन सुरक्षा जमा करने के बाद 500/- रुपये के
गैर-न्यानयक स्िाम्प पेपर पर संस्थान के साथ एक समझौता करना होगा।
The Successful Tenderer herein after referred to as ‘Service Provider’ have to enter into an agreement
with the Institute on non-judicial stamp paper of Rs 500/- after submission of Performance Security.

8. बोलीदाताओं को बोली के साथ ऄनुलग्नक-I (बोलीदाताओं के नलए ननदेि) की तानलका I में ईनल्लनखत दस्तािेज़ प्रस्तुत
करने होंगे। कोइ भी ऄननिाया दस्तािेज़ प्रस्तुत न करने पर ईनकी बोली रद्द की जा सकती है।
The documents mentioned in Table I of Annexure-I (Instructions to Bidders) along with the bid are
required to be submitted by the bidders. Failure to submit any mandatory document may lead to
cancellation of their bid.
9. सेिा प्रदाता को खाना पकाने और परोसने के क्षेत्र के ऄंदर और बाहर साफ-सफाइ और स्िच्छता बनाए रखनी होगी।
10

<!-- page 11 -->

सेिा प्रदाता को प्रनिक्षु ऄनधकाटरयों, कमाचाटरयों एिं संस्थान के निश्राम भिन के अगंतुकों को TFRI द्वारा स्िीकृ त
दरों पर स्िच्छ भोजन और ऄच्छी गुणित्ता िाली चाय, कॉफी, भोजन, नाश्ता और ऄन्य सामान ईपलब्ध कराना
होगा।
The Service Provider shall maintain cleanliness & hygiene within & outside cooking and serving area.
The Service Provider will have to provide hygienic food and good quality tea, coffee, meals, snacks
and other items to the Trainee officers, employees and visitors in Rest house at the rates approved by
TFRI.
10. सेिा प्रदाता को यह सुनननश्चत करना होगा दक ईनके द्वारा ननयोनजत व्यनक्त ईनचत िदी/ड्रेस कोड में हों, ऄच्छी
अचार संनहता बनाए रखें तथा ईनमें अिश्यक काया कौिल हो।
The service provider must ensure the persons engaged by them are in proper uniform/dress code,
maintain a good code of conduct and have required working skills.
11. सेिा प्रदाता को बैठकों/सम्मेलनों अदद के दौरान स्िीकृ त दरों पर कायाादेि ऄनुसार िीएफअरअइ के ननदेिक
कक्ष/सम्मेलन हॉल में चाय/कॉफी/स्नैक्स परोसना होगा। ईसे अिश्यकतानुसार नाश्ता, दोपहर का भोजन और रानत्र
भोजन परोसना होगा।
The Service Provider will have to serve tea/ coffee/ snacks in the Conference Hall/ Chamber of
Director, TFRI during meetings/Conferences etc as per work order at approved rates. He will have to
serve breakfast, lunch and dinner as and when required.
12. संस्थान के िल अनधकाटरक बैठकों, प्रनिक्षण अदद के नलए ऑडार की गइ िस्तुओं/सेिाओं के नलए भुगतान करे गा।
The institute will make payments only for the items/services ordered for official meetings, trainings,
etc.
13. सेिा प्रदाता को खाना पकाने और परोसने के नलए अिश्यक बतान, ईंधन/िानणनययक एल.पी.जी. और ऄन्य ईपकरणों
की व्यिस्था स्ियं करनी होगी। हालााँदक, ईसे यह सुनननश्चत करना होगा दक आस्तेमाल दकए जाने िाले बतान और
किलरी साफ, स्िास््यकर, ऄच्छी गुणित्ता का और कायाक्रम की अिश्यकता के ऄनुसार हो । आसके ऄलािा, ईसे
ईंधन के रूप में जलाउ लकडी का ईपयोग करने की ऄनुमनत नहीं दी जाएगी।
The Service Provider will have to arrange his/her utensils, fuel/commercial LPG and other equipment
required for cooking and serving. However, he must ensure that the utensils and cutlery used are
clean, hygienic, of good quality and as per requirement of the programme. Moreover, he shall not be
allowed to use firewood as fuel.
14. आस ऄनुबंध की ऄिनध के दौरान ऄनुबंध से ईत्पन्न दकसी भी हानन, क्षनत या देयताओं के नलए निभाग नजम्मेदार नहीं
होगा तथा माल की हानन की भरपाइ करना सेिा प्रदाता की नजम्मेदारी होगी।
For any loss incurred, damages that occurred liabilities arising out of the contract during the currency
of this contract, the department, shall not be responsible and it shall be the responsibility of the Service
Provider to make good the loss of goods.
15. भोजन की गुणित्ता बनाए रखने के नलए प्रमुख (सुनिधाएं एिं सेिाएं) या दकसी ऄन्य प्रानधकृ त ऄनधकारी द्वारा समयसमय पर अकनस्मक ननरीक्षण दकया जाएगा।
To maintain the quality of food, random inspections will be conducted from time to time by the Head
(Facilities & Services) or any other authorized official.
16. यदद दकसी निनिष्ट काया अदेि के ऄंतगात सेिाएाँ संतोषजनक नहीं पाइ जातीं, तो भुगतान हेतु प्रस्तुत नबल पर 2%
का जुमााना लगाया जाएगा। आसके ऄनतटरक्त, यदद ऄसंतोषजनक सेिाएाँ पुनः दोहराइ जाती हैं, तो ऄनुबंध दकसी भी
समय रद्द दकया जा सकता है और ईनकी ननष्पादन सुरक्षा रानि जब्त की जा सकती है।
If services against a particular work order is not found satisfactory, a fine of 2% will be imposed on
the bill submitted for payment. Further, the contract may be cancelled at any time if unsatisfactory
services are repeated again and their performance security amount may be forfeited.
17. यदद दकसी ननयत खाद्य पदाथा की निकायत नलनखत में प्राप्त होती है तो ईस ननयत ददन/ ददनों की पूरी तथा अंनिक
रानि का भुगतान सेिा प्रदाता से िसूला जायेगा ऄथिा ईनके ननष्पादन सुरक्षा रानि से कािा जायेगा ।
If any complaint is received in writing regarding any specific food item, then the full or partial
payment amount for that specific day/days will be recovered from the service provider or deducted
from their performance security amount.
18. सेिा प्रदाता दो महीने की पूिा सूचना नलनखत में देकर ऄनुबंध समाप्त कर सकता है। यदद सेिा प्रदाता दो महीने की
पूिा सूचना ददए नबना ऄनुबंध ऄिनध समाप्त होने से पहले ऄनुबंध समाप्त करता है, तो ईसकी/ईनकी ननष्पादन सुरक्षा
रानि और बकाया नबल भुगतान, यदद कोइ हो तो, जब्त कर नलया जाएगा और ईसे/ईसकी फमा को काली सूची में
11

<!-- page 12 -->

डाला जा सकता है।
Service Provider may terminate the contract by giving 2 months prior notice in written. In case the
Service Provider terminates the contract before the end of the contractual period without giving 2
months prior notice, his/their performance security amount and outstanding bill payment if any will be
forfeited and he or his firm may be blacklisted.
19. सेिा प्रदाता संस्थान पटरसर में िराब पीने की ऄनुमनत नहीं देगा या ईसे सुनिधाजनक नहीं बनाएगा।
The Service Provider shall not allow or facilitate the consumption of Alcohol in the institute premises.
20. सेिा प्रदाता दकसी भी प्रकार की िराब/गुिखा/तम्बाकू /नसगरे ि/पान मसाला/बीडी या ऄन्य कोइ भी मादक पदाथा नहीं
बेचेगा। यदद कोइ निचलन पाया जाता है तो सेिा प्रदाता पर प्रत्येक निचलन के नलए 1000/- रुपये का जुमााना
लगाया जाएगा।
The Service Provider shall strictly not sell any Alcohol/ Gutka/Tobacco/ Cigarette/ Pan Masala/ Bidi
or any other intoxicant. If any deviation is noticed, penalty of Rs.1000/- shall be levied on the Service
Provider for each such deviation.
21. सेिा प्रदाता संस्थान की संपनत्त को ईनके /ईनके कमाचाटरयों द्वारा पहुाँचाए गए दकसी भी नुकसान या क्षनत के नलए
नजम्मेदार होगा, नजसके नलए सेिा प्रदाता ईक्त नुकसान या क्षनत की भरपाइ करने के नलए ईत्तरदायी होगा। दंड की
मात्रा ननदेिक, अइसीएफअरइ-िीएफअरअइ/सक्षम न्यायालय द्वारा तय की जाएगी। ऄनुबंध ऄिनध के दौरान
ऄनुबंध/काया अदेि की पूर्णत के दौरान ईनके कमाचाटरयों या ऄन्य लोगों को होने िाली दकसी भी चोि/मृत्यु की पूरी
नजम्मेदारी सेिा प्रदाता की होगी।
Service Provider will be responsible for any loss or damage to Institute’s property caused by them/
their workers for which service provider will be liable to compensate the said loss or damage. The
quantum of penalty will be decided by the Director, ICFRE-TFRI/competent court. Any injury/death
arising to their workers or to others during the fulfillment of the contract/work order during the
contract period is the sole responsibility of the Service Provider.
22. स्थानीय कानून द्वारा ऄपेनक्षत सम्बंनधत निभागों में ऄपने ऄननिाया पंजीकरण जैसे 'पकाए गए खाद्य पदाथा बेचने के
नलए, आत्यादद' सेिा प्रदाता द्वारा स्ियं ही दकया जाएगा और समय-समय पर ईसका निीनीकरण दकया जाएगा तथा
िीएफअरअइ आसके नलए नजम्मेदार नहीं होगा।
Their mandatory registration with the relevant departments as required by local law like 'For selling
cooked food items etc.' shall be done and renewed periodically by the Service Provider himself and
TFRI shall not be responsible for the same.
23. सेिा प्रदाता को दर मदों की सूची प्रदर्णित करनी होगी। सेिा प्रदाता को सुझाि या निकायत पुनस्तका भी रखनी
होगी।
The Service Provider shall display list of the rate items. The Service Provider will also keep a
suggestion or complaint book.
24. यदद सेिा प्रदाता अइसीएफअरइ-िीएफअरअइ द्वारा सूचीबद्ध/ऄनुमोददत दरों से ऄनधक कीमत पर िस्तुएं बेचता
हुअ पाया जाता है, तो ईसे प्रत्येक ईल्लंघन पर दंनडत दकया जाएगा।
In case of Service Provider is found selling items at a price higher than empanelled/approved rates
from ICFRE-TFRI, he shall be penalized per violation.
25. सेिा प्रदाता द्वारा ननयोनजत समस्त जनिनक्त का खचा सेिा प्रदाता द्वारा स्ियं िहन दकया जाएगा तथा िह सम्बंनधत
कमाचाटरयों की न्यूनतम मजदूरी, कमाचारी भनिष्य नननध, कमाचारी रायय बीमा, ईनकी ईम्र अदद के संबंध में ऄपने
द्वारा तैनात दकए जाने िाले कार्णमकों से संबंनधत सभी िैधाननक प्रािधानों के कायाान्ियन के नलए नजम्मेदार एिं
ईत्तरदायी होगा। कानून के तहत ननधााटरत िैधाननक प्रािधानों को बनाए रखने में सेिा प्रदाता की निफलता के कारण
होने िाली चूक के नलए अइसीएफअरइ-िीएफअरअइ नजम्मेदार नहीं होगा।
All manpower expenses employed by the service provider shall be borne by the service provider
himself and shall be responsible & liable for the implementation of all statutory provisions regarding
personnel to be deployed by him in respect of minimum wages, Employees provident fund,
Employees State Insurance, their age etc. ICFRE-TFRI will not be responsible for default on account
of failure of the Service Provider to maintain statutory provisions prescribed under law.
26. यदद सेिा प्रदाता दकसी भी तरह से काया ननष्पादन में या दकसी हानन, क्षनत व्यय या ईसके दकसी भाग की पूर्णत करने
में चूक करता है, तो संस्थान के नलए हानन की िसूली करना िैध होगा।
The service provider if in any manner defaults in the performance or in making good of any losses,
damage expenses or any part thereof, then it shall be lawful for the Institute to recover the loss.
27. यदद दकसी भी पटरनस्थनत में या ननयमों ि ितों के संबंध में सेिा प्रदाता और अइसीएफअरइ-िीएफअरअइ के बीच
12

<!-- page 13 -->

कोइ ऄसहमनत या नििाद ईत्पन्न होता है, तो िे प्रत्यक्ष बातचीत द्वारा मामले को सौहादापूणा ढंग से हल करने का हर
संभि प्रयास करें गे।
If any disagreement or dispute arises between the Service Provider and the ICFRE-TFRI under any
circumstances or in connection with the terms & conditions, they shall make every effort to resolve
the matter amicably by direct negotiation.
28. ऄपटरहाया पटरनस्थनतयााँ : कोइ भी पक्ष, पक्ष के ननयंत्रण से परे कायों के पटरणामस्िरूप ननष्पादन में देरी या
निफलताओं के नलए नजम्मेदार नहीं होगा। ऐसे कायों में दैिीय अपदाएाँ, हडतालें, तालाबंदी, दंगे, युद्ध की घिनाएाँ,
महामारी, कायाान्ियन के बाद लगाए गए सरकारी निननयमन, संचार लाआन की निफलता, भूकंप अदद िानमल हैं,
लेदकन आन्हीं तक सीनमत नहीं हैं।
FORCE MAJEURE: Neither party shall be responsible for delays or failures in performance
resulting from acts beyond the control of the party. Such acts shall include but not be limited to acts of
God, strikes, lockouts, riots, acts of war, epidemics, Government regulation imposed after the
implementation, communication line failure, earthquakes etc.
29. सेिा प्रदाता और संस्थान के बीच ईत्पन्न होने िाले सभी नििादों को मध्यस्थ के पास भेजा जाएगा। मध्यस्थ की
ननयुनक्त ननदेिक, अइसीएफअरइ-िीएफअरअइ द्वारा की जाएगी। लागू मध्यस्थता प्रदक्रया मध्यस्थता और सुलह
ऄनधननयम, 1996 के ऄनुसार होगी। ऄन्यथा संबंनधत िाद जबलपुर नस्थत सक्षम न्यायालय में ही प्रस्तुत दकया जा
सके गा ।
All disputes that may arise between the service provider and the Institute will be referred to the
arbitrator. The arbitrator will be appointed by the Director, ICFRE-TFRI. The applicable Arbitration
procedure will be as per the Arbitration and Conciliation Act, of 1996. Otherwise the related case can
be presented only in the competent court situated in Jabalpur.
30. आस कॉन्रैक्ि में GFR 2017 के ननयम 225 के प्रािधान लागू होंगे।
The provisions of Rule 225 of GFR 2017 will be applicable in this contract.
31. यदद एक से ऄनधक H1 बोलीदाता आस नननिदा के नलए ऄहाता प्राप्त करते हैं तो नननिदा मूल्यांकन सनमनत बोलीदाता के
चयन/दकसे पहले ऄनुबंध की पेिकि की जाएगी, का ननणाय लेगी।
If more than one H1 bidder qualify for this tender the Tender Evaluation Committee will decide the
selection of bidder/to whom contract will be offered first on the basis of experience and other relevant
criteria.

मूल्यांकन / EVALUATION
बोनलयों के मूल्यांकन में दो बोली मूल्यांकन प्रदक्रया ऄपनाइ जाएगी:
Two bid evaluation procedure will be adopted in evaluating the bids:

(i)

तकनीकी मूल्यांकन - नित्तीय बोली खोलने से पहले, प्रनतभागी बोलीदाताओं द्वारा प्रस्तुत
तकनीकी बोनलयों का मूल्यांकन अिश्यक प्रमाणपत्रों/दस्तािेजों के अधार पर दकया जाएगा।
तकनीकी मूल्यांकन में ऄहाता प्राप्त करने िालों की ही नित्तीय बोनलयााँ खोली जाएाँगी।
Technical evaluation - Evaluation of technical bids submitted by the participant
bidders will be carried out on the basis of the required certificates/ documents prior
to opening of the financial bid. Those who qualify in technical evaluation, only their
financial bids will be opened.

(ii)

नित्तीय मूल्यांकन - संबंनधत बोलीदाताओं की नित्तीय बोनलयों के मूल्यांकन के बाद, ऄंनतम रूप
से योग्य बोलीदाता को नीचे दिााए गए संयुक्त तकनीकी और नित्तीय स्कोर के अधार पर

13

<!-- page 14 -->

नननिदा मूल्यांकन सनमनत ( TEC) द्वारा सफल H1 घोनषत दकया जाएगा और आस प्रकार,
ऄनुबंध प्रदान करने के नलए पात्र होगा।
Financial evaluation - After evaluation of financial bids of the relevant bidders,
finally qualified bidder will be declared successful H1 by Tender Evaluation
Committee (TEC) on the basis of combined technical and financial score as
indicated below and hence, eligible for award of contract.
तकनीकी मूल्यांकन/ Technical Evaluation
मूल्यांकन सनमनत नीचे ननर्ददष्ट मूल्यांकन मानदंड और स्कोररग प्रणाली को लागू करते हुए ऄपना मूल्यांकन करे गी। प्रत्येक
प्रनतदक्रयािील तकनीकी बोली को एक तकनीकी स्कोर ददया जाएगा (St)।
The evaluation committee will carry out its evaluation applying the evaluation criteria and scoring system as
specified below. Each responsive technical bid will be attributed a technical score (St).

तकनीकी मूल्यांकन मानदंड के नलए अबंटित ऄंक आस प्रकार हैं:The marks allotted in technical evaluation criteria are as under:तानलका II/Table II
क्र.सं. /
S.No.

नििरण /Particulars

ऄनधकतम
ऄंक /
Maximum
Score/Marks

1.

िैध FSSAI पंजीकरण प्रमाणपत्र की प्रनत / Copy of Valid
FSSAI registration certificate

15

2.

जीएसिी और पैन पंजीकरण की प्रनत / Copy of GST and
PAN Registration

10

3.

नपछले 03 नित्तीय िषों के अयकर टरिना की प्रनतयां (प्रत्येक

15

4.

िषा के टरिना के नलए 5 ऄंक) / Copies of Income Tax
Return for the last 03 financial years (5 marks for
each year return)
स्थानीय स्तर पर पंजीकृ त कायाालय/व्यिसाय को प्रमानणत

10

5.

करने के नलए दस्तािेज़ की प्रनतनलनप / Copy of document
to prove Registered office/business at local level
सरकारी संगठन/पीएसयू/मान्यता प्राप्त निश्वनिद्यालयों में
खानपान सेिाओं के काया ऄनुभि के साक्ष्य की प्रनतयां
(सहायक दस्तािेज - काया अदेि/संतोषजनक प्रदिान टरपोिा
अदद के रूप में) / Copies of Evidence of Work
Experience of Catering Services in Govt.
organization/PSU/Recognized Universities
(Supporting documents – in the form of work
order/satisfactory performance report etc.)
14

50

प्राप्तांक /
Score/Marks
Obtained

प्रासंनगक
दस्तािेज
(पृष्ठ संख्या)
/Relevant
document
(Page
No.)

<!-- page 15 -->

नीचे ददए ऄनुसार नििरण: / Break up as below:
i)

1 से 3 िषा का ऄनुभि / Experience from 1 – 3
years (30 marks);

ii) 3 िषा से ऄनधक और 5 िषा तक का ऄनुभि /
Experience more than 3 years and upto 5
years (40 marks);
iii) 5 िषा से ऄनधक और 7 िषा तक या ईससे ऄनधक का
ऄनुभि / Experience more than 5 years
and upto 7 years or above (50 marks)
Total

100

बोलीदाता को ऄपनी प्रस्तुत बोनलयों के नित्तीय मूल्यांकन के नलए तकनीकी मूल्यांकन में 100 में से कम से कम 70 ऄंक प्राप्त
करने होंगे।
The bidder must obtain at least 70 marks out of 100 in technical evaluation to be considered for financial
evaluation of their submitted bids.
नित्तीय मूल्यांकन/ Financial Evaluation
मूल्यांकन सनमनत यह सत्यानपत करे गी दक सभी नित्तीय बोनलयााँ पूणा हैं और ईनमें कोइ गणना संबंधी त्रुटियााँ नहीं हैं। सबसे कम
नित्तीय बोली (Fm) लगाने िाले बोलीदाता को 100 ऄंकों का नित्तीय स्कोर (Sf) ददया जाएगा। िेष बोलीदाताओं के नित्तीय
स्कोर की गणना ननम्ननलनखत सूत्र का ईपयोग करके की जाएगी:
Sf= 100 × Fm/Fx (जहााँ Fx नित्तीय बोली की रानि ऄथाात बोली मूल्य है)
The evaluation committee will verify that all financial bids are complete and without computational errors. The
bidder quoting the lowest financial bid (Fm) will be awarded a financial score (Sf) of 100 points. The financial
scores of the remaining bidders will be calculated using the following formula:
Sf= 100 × Fm/Fx (Where Fx is amount of financial bid i.e. bid value)
बोली को ऄंततः ईनके संयुक्त तकनीकी स्कोर (St) और नित्तीय स्कोर (Sf) के ऄनुसार ननम्न सूत्र का ईपयोग करके रैं क दकया
जाएगा:
S = St × T% + Sf × F%, जहााँ S = संयुक्त स्कोर।
सबसे ज़्यादा संयुक्त स्कोर (S) िाले बोलीदाता को H1 रैं क दी जाएगी, ईसके बाद H2, H3, और आसी तरह अगे भी। कॉन्रैक्ि
H1 रैं क िाले बोलीदाता को ददया जाएगा।
Bid will finally be ranked according to their combined technical score (St) and financial score (Sf) using the
formula:
S = St × T% + Sf × F%, where S = Combined score.
The bidder with the highest combined score (S) will be ranked H1, followed by H2, H3, and so on. The
contract will be awarded to the H1-ranked bidder.
{िेदिकल नबड को ददया जाने िाला िेिेज (T%) 60% है और फाआनेंनियल नबड को ददया जाने िाला िेिेज (F%) 40% है}
{The weightage (T %) given to the technical bid is 60% and the weightage (F %) given to the financial bid is
40%}
नोिः नित्तीय मूल्यांकन एकल आकाइयों के मूल्यांकन के बाद कु ल मूल्य के अधार पर दकया जाएगा।
Note: Financial evaluation shall be done on the basis of Total value after evaluating the individual entities.
15

<!-- page 16 -->

ऄनुलग्नक- III/Annexure-III
खाद्य पदाथों की दर/मूल्य निभाजन सूची (नित्तीय बोली)/
Rate List/Price breakup of food items (Financial Bid)
{नोि: आस नित्तीय बोली में दरें तकनीकी बोली जमा करते समय ईद्धृत नहीं की जानी चानहए। बनल्क, आन्हें
ऄलग से ईद्धृत दकया जाना चानहए और ऄलग नलफाफे में जमा दकया जाना चानहए। कृ पया निस्तृत
जानकारी के नलए आस दस्तािेज़ के पृष्ठ संख्या 4 का संदभा लें}
{Note: The rates in this Financial bid should not be quoted while submitting the Technical bid. Rather, these should be
quoted separately and submitted in a different envelope. Please refer pg no. 4 of this document for detail information}
अनधकाटरक बैठकों/प्रनिक्षणों/सम्मेलनों/ सेनमनारों/निश्राम गृह अदद में

Sl.
No.

Quantity

परोसी
जाने िाली िस्तुएं /Items to be served in official
meetings/trainings /conferences/seminars/rest house etc
1.
2.
3.

4.

5.

6.

Black Tea/Milk Tea/ Green Tea/Tea

1 cup (150ml)

Coffee

1 cup (150ml)

Breakfast [Category-I]
 Bread butter/Bread omlette/Bread
jam/Sandwitch/Aloo paratha/Paratha with curd/Puri
sabji
 Tea/coffee
 Seasonal fruits

For 1 person

Breakfast [Category-II]
 Bread butter/Bread omlette/Bread
jam/Sandwitch/Aloo paratha/Paratha with curd/Puri
sabji/Poha-Jalebi/Idli-sambhar/Sambhar bada/Masala
For 1 person
Dosa
 Corn flakes with milk
 Tea/coffee
 Seasonal fruits
 Sweets like Gulab Jamun/Rasgulla/ Halwa
Evening Tea – snacks
 Tea/coffee
 Snacks like cookies/biscuits etc.
 Potato chips
 Bhajia

For 1 person

Hi-Tea:
 Sweet–1 Pc (Rasgulla/Gulab Jamun/ Burfi etc.)
 Cookie–2Pcs (Standard Make)
 Roasted dry fruit (8-10pcs)
 Potato chips
 Cutlet/Sandwich–1Pcs
 Tea/Coffee (150ml)
16

For 1 person

Rate (Rs) inclusive
of GST

<!-- page 17 -->

7.

8.

9.

Lunch/Dinner [Category – I]
 Seasonal vegetables (dry cooked)
 Daal Fried
 Plain Rice – good quality
 Tawa Roti
 Salad

For 1 person

Lunch/Dinner [Category – II (a): Veg]
 Seasonal vegetables (dry cooked)
 Paneer/kofta/mushroom
 Daal Fried
 Plain Rice – good quality
 Tawa Roti
 Curd
 Salad, Papad & Pickle
 Packaged drinking water

For 1 person

Lunch/Dinner [Category – II (b): Non-Veg]
 Seasonal vegetables (dry cooked)
 Fish/chicken
 Daal Fried
 Plain Rice – good quality
 Tawa Roti
 Curd
 Salad, Papad & Pickle
 Packaged drinking water

For 1 person

10.

Normal Buffet Lunch/Dinner [Category – III]
 Mix Green Vegetable – Dry cooked
 Matar Paneer / Shahi Paneer/Malai Kofta
 Daal Fried
 Fish / Chicken
 Plain Rice / Jeera Rice/Veg Pulao (Good quality
For 1 person
rice like Superior Basmati etc)
 Tawa roti/Tandoori roti/Missi roti/Naan
 Puri
 Curd/Veg Raita/Boondi Raita
 Salad, Papad & Pickle
 Dessert like Gulab Jamun/Rasgulla/ Rasmalai/Halwa
 Packaged drinking water

11.

Special Buffet Lunch/Dinner [Category – IV]
 Starter (Soup/cold drinks and snacks etc.)
 Special Seasonal Vegetables – Dry cooked
 Boiled Mix Veg
17

<!-- page 18 -->














Special Kadai Paneer / Shahi Paneer/ Malai Kofta
Daal Fried
Special Fish / Chicken
Plain Rice / Jeera Rice/Veg Pulao (Good quality
rice like Superior Basmati etc)
Tawa roti/Tandoori roti/Missi roti/Naan
Puri
Curd/Veg Raita/Boondi Raita
Salad, Papad & Pickle
Dessert like Gulab Jamun/Rasgulla/
Rasmalai/Halwa/Ice cream/Fruit cream
Fresh fruits
Mouth Freshner (Saunf/Elaichi etc)
Packaged drinking water

For 1 person

TOTAL
टिप्पणी 1: ईपरोक्त मूल्य निभाजन (प्रत्येक श्रेणी के खाद्य पदाथों के नलए जीएसिी सनहत दर) को दिााते हुए नित्तीय बोली को
भागीदार बोलीदाताओं द्वारा ईनकी दरों के योग के साथ भरा जाना है।
बोलीदाताओं को सलाह दी जाती है दक िे खाद्य पदाथों की ऄच्छी गुणित्ता को ध्यान में रखते हुए ईपरोक्त खाद्य
पदाथों के नलए ईनचत दरें ईद्धृत करें । ऄत्यानधक कम या ऄनधक दर ईद्धृत करने पर नित्तीय मूल्यांकन चरण में बोली
ऄस्िीकृ त हो सकती है।
Note 1: The Financial Bid indicating the above price breakup (rate inclusive of GST against each category of
food items) is to be filled by the participant bidders along with the Total of their rates.
Bidders are advised to quote reasonable rates for the above food items considering the good quality
food items. Quoting extreme low or high rate may attract rejection of bid at financial evaluation stage.

टिप्पणी 2: िराब/गुिका/तम्बाकू /नसगरे ि/बीडी/पान या ऄन्य निीले पदाथा का ईपयोग/नबक्री सख्त िर्णजत होगी।
Note 2: Use/Sale of Alcohol/Gutka/Tobacco/Cigarette/Bidi/Pan any intoxicants shall be strictly prohibited.
Signature of the bidder……………………………………………………………...
Name of the bidder…………………………………………………………………..

Stamp of the bidder………………………………………………………………….

18

<!-- page 19 -->

ऄनुलग्नक-IV/Annexure-IV
काम का दायरा/SCOPE OF WORK
1. प्रनिक्षु ऄनधकाटरयों, कमाचाटरयों और अगंतुक मेहमानों के नलए हाइ िी, नाश्ता, दोपहर का भोजन, रात का खाना,
स्नैक्स अदद ईपलब्ध कराना जो दक ऄनधभोग और ददए गए ऑडार पर ननभार करता है। सारा खाना पटरसर के ऄंदर ही
पकाया जाना है। अइसीएफअरइ-िीएफअरअइ स्थान और नबजली ईपलब्ध कराएगा।
Providing High Tea, Breakfast, Lunch, Dinner, Snacks, etc for Trainee officers, employees and guests
depends upon the occupancy & orders placed. All the food is to be cooked inside the premises only.
ICFRE-TFRI will provide space & electricity.
2. सेिा प्रदाता द्वारा परोसी जाने िाली सभी िस्तुएाँ ऄच्छी गुणित्ता िाली और स्िच्छ होनी चानहए। मेनू अआिम की
मात्रा और गुणित्ता प्रानधकरण द्वारा ऄनुमोददत ऄनुसार प्रदान की जाएगी। दोपहर के भोजन, रात के खाने और चाय
और कॉफी की तैयारी के नलए ईपयोग की जाने िाली सामग्री की मात्रा नननिदा दस्तािेज़ के ऄनुलग्नक- III में ननधााटरत
मानदंडों के ऄनुसार होनी चानहए।
All items served by the service provider should be of good quality and hygienic. The quantity and
quality of menu items shall be provided as approved by the authority. The quantity of the ingredients to
be used for preparation of lunch, dinner and tea & coffee shall be in accordance with norms laid down
vide Annexure-III of the tender document.
3. सेिा प्रदाता यह सुनननश्चत करे गा दक ईसके सभी कमाचारी खाद्य पदाथा पकाते और परोसते समय ईच्च मानकों का पालन
करें । अइसीएफअरइ-िीएफअरअइ को दकसी भी दुघािना के नलए नजम्मेदार नहीं ठहराया जाएगा और सेिा प्रदाता के
कमाचाटरयों को हुइ दकसी भी चोि या मृत्यु के संबंध में कोइ मुअिजा नहीं ददया जाएगा। लागू कानून/ननयमों के तहत
यह सेिा प्रदाता की पूरी नजम्मेदारी होगी।
Service Provider shall ensure that all their employees practice high standards while cooking & serving
food items. ICFRE-TFRI is no way shall be held responsible for any accidents, and shall not pay any
compensation in respect of any injury or death caused to the workers of the Service Provider. It will be
the sole responsibility of the Service Provider under applicable law/rules.
4. खानपान सेिाएं: सेिा प्रदाता संस्थान द्वारा अदेि ददए जाने पर ताजा और साबुत भोजन/दोपहर का भोजन, रात का
खाना, चाय और कॉफी/पेय पदाथा तथा ऄन्य खाद्य पदाथा तैयार करके परोसेगा। मेनू ऄनुलग्नक-III में ददया गया है तथा
संस्थान की अिश्यकताओं के अधार पर आसमें पटरितान दकया जा सकता है। आसमें आन-डाआबनग और आन-रूम सेिा के
नलए ऄच्छी िदीधारी कमाचारी िानमल हैं; जैसा दक मामला हो सकता है, मानक खानपान अिश्यकताओं के ऄनुरूप
लागू होता है।
Catering Services: The service provider shall prepare and serve fresh and whole meal/lunch, dinner,
tea & coffee/beverages, and other eatable items as and when ordered by the Institute. The menu is
placed at Annexure-III and the same is subject to change based on the requirement of the Institute. It
includes the well-uniformed personnel for service in dining and in-room service; as the case may be
applicable in line with the standard catering requirements.
5. भोजन का प्रकार: भोजन का प्रकार (नाश्ता, दोपहर का भोजन, रानत्र भोजन, स्नैक्स और पेय पदाथा) चुनने का
निकल्प संस्थान के पास सुरनक्षत रहेंगे अिश्यकता के ऄनुसार ।
Type of Meal: Options to choose type of meal (Breakfast, Lunch, Dinner, Snacks, and
Beverages) will be with the Institute as per the requirement.
6. अहार के प्रकार: प्रमुख अहार के प्रकार िाकाहारी और मांसाहारी हैं ।
Type of Diet: The types of Major diet are vegetarian and non-vegetarian.
7.

सेिा प्रदाता िीअइपी सेिाओं, प्रनिक्षण कायाक्रमों, सम्मेलनों और नििेष समारोहों के नलए सभी क्रॉकरी अआिम

ईपलब्ध कराएगा। ईनके पास परोसने के नलए अिश्यकतानुसार गमा और ठं डे क्रॉकरी होने चानहए ।
Service Provider will provide all the crockery items for VIP services, training programs, conferences,
and Special get- together. They should have serving crockery - hot & cool as per requirement.
8. सेिा प्रदाता ऄपने खचा पर पुनलस ऄनधकाटरयों द्वारा ऄपने द्वारा ननयुक्त कर्णमयों के चटरत्र और पूिािृत्त का सत्यापन
करिाने की व्यिस्था करे गा, तथा यह सुनननश्चत करे गा दक ऐसे दकसी व्यनक्त को काम पर नहीं रखा जाएगा, नजसके
चटरत्र और पूिािृत्त का सत्यापन नहीं दकया गया है। दकसी भी मामले में, नजस व्यनक्त की ननयुनक्त पर ऄनधकारी द्वारा
19

<!-- page 20 -->

अपनत्त की जाती है, ईसे सेिा प्रदाता द्वारा तुरंत बदल ददया जाएगा।
The Service Provider will arrange to carry out, at his own cost, the verification by the Police Authorities
of the character and antecedents of the personnel engaged by him for the job, and ensure that no person,
whose character and antecedents have not been so verified, shall be employed. In any case, any person
whose engagement is objected to by authority shall be promptly replaced by the Service Provider.
9.

सेिा प्रदाता को बनार की सफाइ/सर्णिबसग/प्रनतस्थापन तथा व्यािसानयक एलपीजी गैस लाआन की मरम्मत और
रखरखाि का काया एक कु िल व्यनक्त को ननयुक्त करके ननयनमत रूप से करना होगा। ईपरोक्त काया करते समय सुरक्षा
प्रदक्रयाओं का पालन दकया जाना चानहए।
The Service Provider shall carry out the cleaning/servicing/replacement of burners and repair &
maintenance of the Commercial LPG Gas line regularly by deploying a skilled person. While carrying
the above jobs safety procedures must be followed

10.

ऄनुलग्नक-III में ईनल्लनखत खाद्य पदाथों के नलए ऑडार देने का ननणाय संस्थान द्वारा कायाक्रम की अिश्यकता और
मामले के अधार पर दकया जाएगा।
Placing of order for food items as mentioned in Annexure-III will be decided by the institute as per
requirement of programme and case to case basis.

11. सेिा प्रदाता पटरसर में और ईसके अस-पास ऄच्छी हाईसकीबपग बनाए रखेगा और पटरसर में जल ननकासी व्यिस्था
बनाए रखेगा तथा कू डे/बचे हुए भोजन अदद का ननपिान ऄपने जोनखम और लागत पर करे गा। टरफाआनरी पटरसर के
बाहर कू डे/बचे हुए भोजन/ऄपनिष्ट का ननपिान ननर्ददष्ट स्थान पर करना सेिा प्रदाता के ऄनधकार क्षेत्र में होगा।
The Service Provider shall maintain Good Housekeeping IN and AROUND the premises and shall also
maintain the drainage system in the precincts and disposal of Garbage/leftovers etc. at his own risk &
cost. The disposal of garbage/leftover/waste outside the refinery premises to the designated place will be
in the scope of the Service Provider.

नोि: यदद नननिदा दस्तािेज के बहदी संस्करण और ऄंग्रेजी संस्करण के बीच कोइ िकराि या ऄसंगनतपाइ जाती है, तो
नििाद की नस्थनत में न्यायानलन कायों हेतु ऄंग्रेजी संस्करण मान्य होगा।
Note: If there is any conflict or inconsistency between the Hindi version and the English version
of the tender document, then English shall be the governing and prevailing version.

20

<!-- page 21 -->

ऄनुलग्नक-V

बोली सुरक्षा घोषणा
ददनांक:

बोली संख्या.

प्रनत,
ननदेिक
अइसीएफअरइ-ईष्णकटिबंधीय िन ऄनुसंधान संस्थान जबलपुर-482021
मध्य प्रदेि
मैं/हम ऄधोहस्ताक्षरकताा घोषणा करते हैं दक:
मैं/हम समझते हैं दक, अपकी ितों के ऄनुसार, बोनलयों को बोली सुरक्षा घोषणा द्वारा समर्णथत होना चानहए।
मैं/हम स्िीकार करते हैं दक यदद मैं/हम बोली ितों के तहत दकसी दानयत्ि का ईल्लंघन करता हाँ/करते हैं तो मैं/हम
ऄनधसूचना की नतनथ से दो िषा के नलए अपके साथ दकसी भी ऄनुबंध के नलए बोली लगाने से ऄयोग्य हो सकते हैं
क्योंदक मैं/हम
a) बोली के रूप में ननर्ददष्ट बोली िैधता की ऄिनध के दौरान नननिदा से ऄपनी/हमारी बोली को िापस ले
नलया/संिोनधत/संिोनधत, ख़राब या कम कर ददया है; या
b) बोली िैधता की ऄिनध के दौरान क्रेता द्वारा हमारी बोली की स्िीकृ नत की सूचना ददए जाने के बाद
(i) यदद अिश्यक हो तो ऄनुबंध ननष्पाददत करने में निफल या मना कर ददया, या
(ii) बोलीदाताओं को ददए गए ननदेिों के तहत प्रदिान सुरक्षा प्रदान करने में निफल या मना कर ददया।
मैं/हम समझते हैं दक यदद मैं/हम सफल बोलीदाता नहीं हैं, तो यह बोली सुरक्षा घोषणापत्र ननम्ननलनखत में से
पहले िैध नहीं रहेगा
(i) सफल बोलीदाता के नाम की अपकी ऄनधसूचना प्राप्त होने पर; या
(ii) मेरी/हमारी बोली की िैधता की समानप्त के तीस ददन बाद।
हस्ताक्षर (प्रानधकृ त ऄनधकारी का):
नाम (प्रानधकृ त ऄनधकारी का)

:

पदनाम (प्रानधकृ त ऄनधकारी का):
(बोलीदाता का पूरा नाम डालें) के नलए और ईसकी ओर से बोली पर हस्ताक्षर करने के नलए निनधित ऄनधकृ त:
ददनांक:
कॉपोरे ि मुहर:
(नोि: संयुक्त ईद्यम के मामले में, बोली सुरक्षा घोषणापत्र संयुक्त ईद्यम के सभी भागीदारों के नाम पर होना
चानहए जो बोली प्रस्तुत करते हैं)

21

<!-- page 22 -->

Annexure-V
Bid Security Declaration
Date:

Bid No.

To
The Director
ICFRE-Tropical Fores Research Institute Jabalpur-482021
Madhya Pradesh
I/We the undersigned, declare that:
I/We understand that, according to your conditions, bids must be supported by a Bid Securing Declaration.
I/We accept that I/We may be disqualified from bidding for any contract with you for two years from the date of
notification if I am /We are in a breach of any obligation under the bid conditions because I/We
a) Have withdrawn/modified/amended, impairs or derogates from the tender, my/our Bid during the period of
bid validity specified in the form of Bid; or
b) Having been notified of the acceptance of our Bid by the purchaser during the period of bid validity
(i) Fail or refuse to execute the contract, if required, or
(ii) Fail or refuse to furnish the Performance Security, under the Instructions to Bidders.
I/We understand this Bid Securing Declaration shall cease to be valid if I am/we are not the successful Bidder,
upon the earlier of
(i) The receipt of your notification of the name of the successful Bidder; or
(ii) Thirty days after the expiration of the validity of my/our Bid.
Signature (of authorized official)

:

Name (of authorized official)

:

Designation (of authorized official)

:

Duly authorized to sign the bid for and on behalf of (insert complete name of Bidder)
Date :

:

Corporate Seal :
(Note: In case of a Joint Venture, the Bid Securing Declaration must be in the name of all partners to the Joint
Venture that submits the bid)

(END OF DOCUMENT)

22
