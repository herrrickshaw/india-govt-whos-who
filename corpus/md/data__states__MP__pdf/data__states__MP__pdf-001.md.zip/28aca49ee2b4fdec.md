---
doc_id: "28aca49ee2b4fdec"
source_url: "https://collegeholkar.org/iqacdoc/05_e-governance_PolicyHSC.pdf"
ministry: "Government Holkar (Model, Autonomous) Science College, Indore, Madhya Pradesh"
title: ""
date: ""
pages: 11
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "2251047327e933d3"
---

<!-- page 1 -->

6 en
e-sovernance Policy
NG Holkar
(Model Autonomous)
Science College,
Indore (M.P.)
y
—_ ame. कि
ar | 2 @264¢@ | ae
IL ns -५॥|॥॥॥॥.
—- of alan को a
A. if Le
al . 7“ ba Ge Version : 2.0

<!-- page 2 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
bY,

कर ?
(

., * ©

i)

Dr. Suresh T. Silawat
Principal
Govt. Holkar (Model, Autonomous) Science College, Indore

FOREWORD

It is envisaged that all the services of the Institution will be successfully implemented in
phases under the e-Governance plan according to the National e-Governance Plan and Digital
India flagship initiatives of the Government of India.

This policy is recognized as “The E-Governance Policy” of the Government Holkar
(Model, Autonomous) Science College, Indore, MP, and provides a documented roadmap for
the implementation of the policy by ensuring the best practices related to use and
implementation in the maximum possible areas of e-Governance Services.

Technology has infiltrated every part of our lives. This technological era has enhanced
the governance structure of the Institute for its overall development. With an increasing
demand for transparency in administration, faster information transfer, implementation of new
solutions and ideas across different departments of the Institution, our aim is smooth data
transition to facilitate enhanced decision making process.

Through e-Governance, the Institution would ensure that all its services are promptly
delivered to and are accessible by the teachers, students, staff, and all other stakeholders.
Benchmarking efficiency, transparency, accountability, and convenience for all the stakeholders
is the core idea behind the implementation of this policy and it is a step further towards the
promotion and implementation of e-Governance in the Institution.

Through e-Governance, the Institution would ensure that all its services are promptly
delivered to and are accessible by the teachers, students, staff, and all other stakeholders.

Dr. Suresh T. Silawat
Principal
(4)

<!-- page 3 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
| Vision and Mission of the Institute |
Vision:
To make our youth the torch-bearer of knowledge, and to continue the rich
legacy of imparting scientific education and groom them on an intellectual,
social and humane platform.
Mission:
e To create an innovative ecosystem for the promotion of scientific
temperament.
e Toenrich the academics with state-of-the art technology and innovation at
par with the global standards.
e Toimpart Skill-based training relevant to local and global needs.
e Todevelop a well-groomed and empowered youth.
e Tonurture a socially responsible and value-driven generation.
(2)

<!-- page 4 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
THE E-GOVERNANCE POLICY
Content
4. Preamble
2. Introduction
3. Scope
4. Objectives
5. Policy and Area of Implementation
e Website
e General Administration
e Student Admission
e Examination Management
e Library Management
e Financial Management
e ICT Implementation
6. Student Participation in Governance
(3)

<!-- page 5 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
THE E-GOVERNANCE POLICY
Information and Communication Technology (ICT) enabled technology can
transform Governance by the adoption of global best practices in Governance.
Based on the Information Technology Act, 2000 of the Government of India, it is
mandated that public services are to be delivered electronically wherever and to
the extent possible. It is the power of e-Governance that imparts good
governance, empowers the stakeholders, lowers the process cost, and time,
upgrades the administrative performance (e-Administration), enhances its
services, provides fast services, and so on. This policy highlights Government
Holkar (Model, Autonomous) Science College, Indore's stride towards building
global competencies.
Preamble:
It is envisaged that all the services of the Institution will be successfully implemented in
phases under the e-Governance plan according to the National e-Governance Plan and
Digital India flagship initiatives of the Government of India.
This policy is recognized as “The E-Governance Policy” of the Government Holkar
(Model, Autonomous) Science College, Indore, MP, and provides a documented
roadmap for the implementation of the policy by ensuring the best practices related to
use and implementation in the maximum possible areasof e-GovernanceServices.
Introduction:
Technology has infiltrated every part of our lives. This technological era has enhanced
the governance structure of the Institute forits overall development. Globalization is a gift
of technology, and the notion of E-governance was established as a result of technology
and its benefits. With an increasing demand for transparency in administration, faster
information transfer, implementation of new solutions and ideas across different
departments of the Institution enables smooth data access and enhanced decision-
making. E-governance aims at planning and facilitating any infrastructure for the
deployment of cutting-edge applications and deployment solutions for the smooth
administration of the institute. In addition, the transaction costs can be cut down and
services can be made more accessible.
Scope
The scope of this policy extends to the following areas:
e Website
e General Administration
e StudentAdmission
(4)

<!-- page 6 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)

e Examination Management

e Library Management

e Financial Management

e ICTImplementation

Objectives

Through e-Governance, the Institution would ensure that all its services are promptly

delivered to and areaccessible by the teachers, students, staff, and all other

stakeholders. Benchmarking efficiency, transparency, accountability, and

conveniencefor all the stakeholders is the core idea behind the implementation of this

policy and it is a step further towards the promotion and implementation of e-

Governance in the Institution.

This policy has been drafted keeping in mind the following objectives:

e This policy aims at strengthening the leadership by providing a simple and efficient
system of governance within the institution in the area of E-governance.

e Toprovide online service facilities to all the stakeholders.

e To provide easy and quick access to information for all the stakeholders and
promote transparency and accountability in all the functions of the Institution.

e Topromote and move towards a paperless environmentin the college.

e This will optimize the administration's performance in decision-making.

e This will enhance the overall efficiency of the faculties as well as the administration
and thus improve the quality of the work culture in the Institution.

e The Institute shall comply with the e-governance norms and policies of Govt. of
India and Govt. of Madhya Pradesh.

Policy & Areas of Implementation

The IT Centre, Holkar Science (Model, Autonomous) College, Indore shall act as an

implementing Agency for all e-Governance implementation in the institution. IT Centre

shall coordinate the overall implementation of the policy.

The Institution has implemented E-Governance in the following areas, which is regularly

upgraded:

Website

e The College strives to showcase its vibrant self and activeness through its website.

e The website of an institution is its face; therefore, it should showcase its vibrant self
and activeness through its website.

(5)

<!-- page 7 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)

e = Allthe activities, important notices, courses offered, etc should be timely updated.

e _ Training should be given to the administrative and teaching staff to make important
updates on the website.

e AWebsite Committee should be in place to monitor the input Institution's website.

e The IT departmentshall look after the process of updating, maintaining, and
working on the website on a regular basis.

e Asandwhen required, the website should be upgraded.

e All the important notifications have to go live on the website as and when they are
released.

General Administration

e The Institution is governed by the Department of Higher Education, Govt. of
Madhya Pradesh, and all its communication with the higher authorities is governed
through the Official website and email.

e The Administration communicates with teaching and non-teaching staff through
email and LMS Platform.

e = Allthe important administrative information including notices is regularly published
on the website.

e Biometric attendance for all staff members.

e Campus with wi-fiinternet facility.

e _Toprogress towards Paperless Culture, institution promotesusage of Google sheet
/ Google forms / Google Docs for data collection from Various Departments,to
prepare notices and activity reports and prepare Feedback forms and get online
feedback fromstudents, teachers, alumni, and employers.

e Thecollege campus is equipped with CCTV cameras installed at various places for
e-surveillance.

e Additionally, institutionally designed LMS and WhatsApp Groups are used to
disseminate general and specific information to students and are also used for
Mentor-mentee interaction.

Student Admission

e The institution follows the centralized admission procedure as per the guidelines of
the Online admission procedure ofthe Department of Higher Education, Govt. of
Madhya Pradesh since 202.

e The admission portal takes careof all the processes from initial data filling by the
institution, from filling by students, verification of the documents, generation of the
admission list, payment of Admission fees, and generation of receipt and
admission letter, all are through e-mode.

(6)

<!-- page 8 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)

Examination Management

e Examination Management is efficiently handled through Examination
Management System.

e Filling examination forms, obtaining admit cards, uploading of mark sheets, etc.
everything is done through e-mode.

e The Examination Department monitors the complete process of examination and
its management under the guidance of the examination controller of the institution.

Library Management

e Keeping in pace with the modern internet age,the library is also modernized by
automating it with LMS, SOUL 2.0 Software.

e E-resources such as NLIST-INFLIBNET and DELNET should be regularly
procured for increasing access to faculty, researchers, and students.

e Appropriate training for the staff and students should be provided for the use of e-
learning of these e-resources.

e _Theinstitution must strive to provide remote-access facilities to all its stakeholders.

Financial Management

e TheAccounts Section maintains its account on Tally.

e Latest versions of the software to be procured and used by the institution to
maintain financial records effectively and efficiently.

° Profit and loss, Balance Sheets are generated through this software only. All the
analysis reports are also being generated through Tally.

e 2070 security measures should be taken for maintaining the confidentiality of the
transactions.

e Updating of the existing software and training of upgraded software to the existing
staff must be done regularly.

e The Institution also uses multiple software like Integrated Financial Management
System (IFMS) and Public Financial Management System (PFMS) for the
management of the funds received from the Governmentfor disbursement of salary
to respective bank accounts, generating salary slips, TDS, Provident Fund,
Allowances, etc.

e All Payments should be done and received through online modes such as NEFT,
RTGS, Bank Transfers, etc.

ICT Implementation (Hardware Infrastructure & Software Infrastructure):

As per the | T Policy of Holkar Science (Model, Autonomous) College, Indore.

Student Participation in Governance

(7)

<!-- page 9 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
Being an integral part of the institute campus, the students have a stake in the
governance of the institution. The various policies and procedures laid down by the
institution in the administrative and academic governance shall also have the
involvement of the students. The students should be encouraged to put forth their views
and suggestions, for strengthening decision making. Therefore, all the students who
are enrolled or are going to be enrolled in the institution are advised to uphold the policy
and inform the institution of any violation of it and assist in the qualitative effectiveness in
the implementation of the E-governance policy.

Amendments

e The Institute shall examine its “E-Governance Policy” on a regular basis and
change it as necessary to comply with national policies and directives issued by
competent apex bodies.

e Pertaining to any contradiction in any Policy of the Institution, the later revised
policy will take precedence.

Publication of E-Governance Policy

e The “E-Governance Policy” shall be widely publicized among the Institute's
stakeholders with all the possible means, as well as prominently displayed on the
Institutional Website to attract the attention of concerned stakeholders.

Important links

° https://www.digitalindia.gov.in/content/e-governance-%E2%80%93-reforming-
government-through-technology

e https://www.meity.gov.in/divisions/national-e-governance-plan

० https://www.edaksh.mp.gov.in/index.php?/about-
us#:~:text=The%20Project%20%E2%80%9Ce%2 DDaksh%E2%80%9D, of %20India%20an
d%20State%20Government

e http://deanofstudents.ucsc.edu/student-conduct/student-handbook/pdf/20.0-
policystudent-participation-governance.pdf

(8)

<!-- page 10 -->

Govt. Holkar (Model, Autonomous) Science College, Indore (M.3.)
ACKNOWLEDGEMENTS
Apolicy document on “E-Governance” has been drafted under the guidance of an Expert
Committtee: Dr. Aparna Gandhe (Convener), Dr. Meenal Shrivastava (Member), Prof.
Vinod Rathod (Member), Mr. Sanju Sen (Staff member), Mr. Sandeep Sharma (Staff
Member), Mr. Amit Kumar Pal (Student member), Ms. Anjali Parihar (Student Member).
IQAC acknowledges Dr. Suresh T. Silawat (Principal), Dr. 5.0. Gupta (Vice-principal),
Dr. R.C. Dixit (Administrative Officer) and all the Head of the Departments for their
guidance and extensive support during the preparation of this document. We also thank
Dr. Swagata Gupta (Master Facilitator) for her valuable inputs during the draft
preparation and Dr. Kanta Mulchandani for her meticulous proof reading of the policy
draft. IQAC also thanks Mr. Bhagwan Suman and Mr. Ankiteshwar Shukla for their
compiling assistance. All the other members of IQAC also need a special mention for
their suggestions and guidance during the preparation of the policy.
IQAC acknowledges and appreciates the efforts made by the Expert Committee and all
others in preparing this document.
Dr. Bijendra Rai Dr. Nagesh Dagaonkar
Coordinator, NAAC Coordinator, |QAC
(9)
