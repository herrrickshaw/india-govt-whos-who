---
doc_id: "2b51eeebaeae05ec"
source_url: "http://rvskvv.net/images/Notice_ICAR_NTS_16.08.21_b.pdf"
ministry: "Rajmata Vijayaraje Scindia Krishi Vishwavidyalaya (RVSKVV), Gwalior, Madhya Pradesh"
title: "Notice_ICAR_NTS_Amendment"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b4fc088d553117d9"
---

<!-- page 1 -->

INDIAN COUNCIL OF AGRICULTURAL RESEARCH
Krishi Anusandhan Bhavan – II, Pusa,
New Delhi – 110012
(Agricultural Education Division)

Dated: 10th August, 2021

F. No. Agril. Edn./1/17/2012-Exam Cell Vol. II

AMENDMENT IN ELIGIBILITY REQUIREMENTS FOR THE AWARD OF ICAR
NATIONAL TALENT SCHOLARSHIP (NTS)
It is for the information of candidates aspiring to appear in ICAR’s AIEEA (UG)
and (PG)-2021 examination that the extant eligibility requirements for the award of ICAR
National Talent Scholarship through these examinations mentioned in the respective
Information Bulletins (uploaded on NTA website www.nta.ac.in and http://icar.nta.ac.in) in
Chapter-2, clause 2.7-Conditions for the award of NTS-2021 of UG and Chapter-2, clause
2.7-Conditions for the award of ICAR-PG Scholarship and NTS (PG)-2021 for PG (including
bullet para-6 under Note or elsewhere) stands amended.
Now the lines....“Further they should also note that from the Academic Session 2021-22
onwards, irrespective of affiliation, whether it is ICAR DUs or DARE (3 CAUs) or SAUs or
CUs with Agriculture Faculty for all accredited AUs, the award of NTS would be only for
15% seats of UG and 25% seats of Masters degree programme” are to be treated as
withdrawn. Rest of the conditions in the Information Bulletins for the award of NTS-2021
UG and PG remains unchanged.
This is issued with the approval of Competent Authority in the Council.

Sd/Controller of Examinations (Agril. Edn.)
