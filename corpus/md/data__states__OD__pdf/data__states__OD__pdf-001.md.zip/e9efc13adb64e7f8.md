---
doc_id: "e9efc13adb64e7f8"
source_url: "https://missionshakti.odisha.gov.in/sites/default/files/2022-11/Joint%20Guidelines%20School%20uniform%20in%20SSD%20school.pdf"
ministry: "MIS System for Mission Shakti Portal, Odisha"
title: "Download(680.46 KB)"
date: ""
pages: 14
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "c460daeaabd1569a"
---

<!-- page 1 -->

ges
®
GOVERNMENT OF ODISHA
No.___2\\153 /SSD  Dt._03.1).202
STSCD-PRMS-MISC-0005-2021
From

Smt. Sujata R. Karthikeyan, IAS Smt. Ranjana Chopra, IAS

Commissioner-cum-Secretary, Principal Secretary,

Mission Shakti Department ST & SC Dev Department
To

All Collectors
Sub: Guidelines for selection of SHGs for supply of School Uniforms in SSD Schools
Madam/ Sir,

Self-Help Groups under Mission Shakti today undertake a wide range of economic
activities and generate substantial incomes, enabling financial stability and empowerment of
lakhs of women in the State. The ST & SC Development, Minorities & Backward Classes
Welfare Department, Odisha is operating 1734 schools with approximately 4.6 lakh ST/SC
students (both boarders and day scholars) across the state.

Presently the cost towards two pairs of uniform for students studying in Std 1-VIII is Rs
400 per annum. Students studying in Std IX to XII are provided with 2 pairs of uniforms annually
@ Rs 1000 per child. Presently funds towards procurement of 2 pairs of uniforms per student
for all the classes are placed with concerned Headmasters who procure them from the local
market.

As per the Cabinet decision to make provisioning of Government services & procurement of
goods worth Rs.5000 Crore through Mission Shakti SHGs in five years, the ST SC Development
Department has collaborated with Mission Shakti to supply the required uniforms.

Coverage:
4.6 lakh students studying in 1734 SSD Schools across the state.

<!-- page 2 -->

1. Selection and Engagement of SHGs for Supplying School Uniforms in SSD Schools
A. Selection of SHG:

a) SHGs nominated for supplying school uniforms should be of impeccable past record
both in terms of activity and financial management.

b) SHGs fulfilling the following parameters may be considered for selection to supply
school uniforms.

1. SHGs members preferably should have past experience in stitching dress
materials and should have sewing machine / tailoring equipment.
11. | SHGs should be willing and able to take up this activity with own savings /
bank linkage.
Ill. 51105 to have an active bank account with regular monthly savings by its
members.
IV. SHG to have regular and systematic book keeping relating to Meeting Register
and updated Pass Books.
B. Process of Selection of SHG:

a) The Block Development Officer and CDPO along with Welfare Extension Officer
(WEO) shall give wide publicity and awareness among the SHGs on the proposed
activity. Mission Shakti field functionaries will facilitate awareness among the SHGs
in coordination with the field functionaries of SSD Department.

b) The Eol shall be published at the offices of the PA ITDA, DSWO, DWO, DEO,
BDOs, CDPOs, BEO, Special Officer (SO) - Micro Project Areas (MPAs), AWCs
and BLF office for a period of 15 days. The same shall be shared with the Block Level
Federation (BLF) and Gram Panchayat Level Federation (GPLF) for awareness of
SHGs & the Federation. The format for Expression of Interest for SHGs is enclosed
herewith as Annexure I.

†. ` SHGs shall apply in the prescribed form, in the office of the concerned CDPO
within the scheduled time.
II. Block wise panel of eligible SHGs shall be maintained for uninterrupted
supply.
111. In case no SHGs is found eligible in a particular area, viable and willing SHGs
from within the block may be tagged.
2

<!-- page 3 -->

IV. In case of non-availability of a SHG the concerned Head Master can procure
the same from the open market following due procedures with due approval
from DWO.

C. Block Level Selection Committee:Block Level Selection Committee consisting of
following officials shall examine the received Expression of Interest of SHGs.This
committee shall be formed constituting the following members.

1. `` Block Development Officer (BDO) -Chairperson

Il. Child Development Project Officer (CDPO) - Convener

111. Welfare Extension Officer (WEO) - Member

IV. Block Project Coordinator (BPC) & Block Project Manager (BPM), Mission
Shakti - Member

V. 2 Headmasters of SSD schools from the block as nominated by the WEO-
Member

D. Selection of SHG by the Committee

I, The committee shall assess school uniform requirement (Boys & Girls for Std
I to Class XII)

11. | The Block Level Selection Committee shall scrutinize the proposals of SHGs.
If required, the committee may conduct field visit to ascertain the eligibility of
SHGs.

111. Based on the selection criteria (Annexure-II) and received proposals from the
SHGs, the committee shall select SHGs for supply of school uniforms and
share the selected list with the Headmaster.

E. Supply Order:

1. ` On selection of SHGs, Headmaster shall place supply order with a copy to
WIO indicating the name of the SHGs, boys and girls (Class wise) requirement
of uniforms to SSD School (Sample format enclosed as Annexure 111).

11. ` SHGs shall submit one sample uniform (boy and girl) to the Headmaster within
one week of placement of supply order observing norms as specified in the
supply order. The sample uniform will be accounted for in the supply of the
1451 lot.

3 |

<!-- page 4 -->

111. ` In consultation with the SHGs concerned, a distribution schedule period shall
be worked out (School wise) from the receipt of supply order so that supply of
two sets of uniforms will be on time and distributed by Ist week of July.

IV. Uniforms shall be delivered at the School point with proper receipt of the
concerned Headmaster.

Vv. Failure to deliver uniform as per the schedule will lead to cancellation of supply
order.

VI. Incase there is shortfall of delivery by any SHG against scheduled programme
as per the supply order, immediate arrangements to be made for supply through
other SHGs from the panel.

F. Settlement of Dues:
a) Payment shall be released by the Headmaster to the SHGs only against the claim bills
basing on acknowledgment receipt of delivery of school uniform
b) The SHGs shall submit the acknowledgment Receipt of school uniform to the

Headmaster (Receipt and Model Claim bill enclosed as Annexure IV & V

respectively).

c) Dues of the SHGs shall be settled within 15 days on receipt of claims of the SHGs.

Only e-payments to be done into the accounts of SHGs for supply of school uniform.

In no case, bills shall be pending beyond one month.

G. Monitoring:
WEOs and Mission Shakti functionaries shall monitor timely & uninterrupted supply
of school uniform as per the schedule and settlement of claims.
Yours faithfully,
Commissioner-cum-S¢Cretary to Govt., Principal Secretary/to Govt.,
Department of Mission Shakti ST & SC Developrient Department
4

<!-- page 5 -->

Annexure I
Office of the DSWO
Model Advertisement for inviting Expression of Interest for Supply of School
Uniforms for students studying in schools run by ST & SC Development Department
No: Date:
Expression of Interest from the interested SHGs / SHG Federations having willingness and
aptitude for the activity titled Supplies of School Uniforms for students studying in
schools run by ST & SC Development Department is invited to submit their proposal
before the concerned CDPO in the mentioned below format within 15 (fifteen) days of this
notice i.e. by towards Supply of School Uniforms for students studying in
schools run by ST & SC Development Department. SHGs should be from the same GP
where they propose to take up the activity.
Signature of the DSWO
Date:
Enclosure: SHG Selection Criteria & Brief activity guidelines
NB: The applicant SHG can get the detailed information on the activity and student
strength from the concerned WEO and BPC, Mission Shakti of the concerned block.
5

<!-- page 6 -->

Format
Eol for taking up the activity:
1. Name of the SHG: ୧
2. SHG Address: Village _ Post Office
GP Block 8
District PIN
ICDS Project
3. Year of Formation:
4. Name of village/ward where the activity will be taken up:
5. Whether the SHG is involved in tailoring activity (Yes/ No)-
(Self-Declaration of the SHG shall be attached)
6. Bank and Branch Name:
7. Funds available in the Savings Bank Account:
(a) Regular Saving (Yes/ No)
(b) Amount of savings (in Rs.):
(c) Whether Loan taken (Yes/No), if yes, mention the number of times loan availed
(d) Mode of loan repayment (Regular/irregular):
(୯) Meeting Register maintained (Yes/No):
(f) Cash Book maintained (Yes/No):
10. Contact No:
11. Resolution of the SHG to take up the activity is enclosed (Yes / No):
Name & Signature of the Authorized Person of the SHG
Date:
Acknowledgement
Received the Expression of Interest from SHG, Village „ 00
date for the activity ‘Supply of School Uniforms for students studying
in schools run by ST & SC Development Department’.
Signature of the CDPO / Authorized Signatory
Date:
6

<!-- page 7 -->

Annexure 11
Recommendation of Block Level Selection Committee on SHGs / SHG Federations for the scheme titled ' , ...................'
Whether |
Amount | Weather Maintaining the SHG
Name] Name Name Name Date of | Bank | Branch Bank of Loan Mode of loan meeting es 8001 involved in
ଗଲ ‘of: of GP of formation | Name | Name ୦0 ମା savings | taken repaymient Register | maintained tailoring
SHG | Block Village Number in Rs. | (Yes/No) (Regular/irregular) (Yes/No) (Yes/No) activities
(Yes / No)
୮1 2 [3 4 ] 5 [oe 7 ୌ ୫ | ୨ 1 | 1 | 2 | 89 14 _
ଓ a ‰ ‰୍‌୍‌. _‰___. |
Welfare Extension Block Project Block Project Child Development Project Block Development Officer
Officer Coordinator Manager Officer
7

<!-- page 8 -->

Annexure-III
Model Supply Order
Now
Date:

Considering the Expression of Interest received from the SHGs /
Federation, the SHG / Federation is placed with order for supply of school uniform as
detailed against each @ Rs. per uniform. The uniform set for boys studying in Std
I-VIII shall be navy blue colour half pant / white half shirt. For girls studying in Std I to
V uniform set shall be sky/navy blue colour frock. For girls studying in Std VI to VIII
uniform set shall be sky/navy blue kurti and white colour chuddidar and white colour
dupatta. The uniform set for boys shall be navy blue colour full pant and white colour
half shirt and for girls sky/navy blue kurti and white colour chuddidar and white colour
dupatta for Std [X to XII students. The uniform shall be delivered to the concerned
Headmaster on proper receipt as per the scheduled period. The SHG shall deliver number
of sets of school uniform as detailed at Column No. 9 of the below mentioned table to
Headmasters of SSD schools as per the timeline. However, uniform should be supplied
as per the measurement of the students (Boys & Girls). The progress of supply of school
uniform will be verified by the ICDS / Mission Shakti functionaries. In case the SHG is

lagging behind the timeline, alternative arrangement will be made.
8

<!-- page 9 -->

Name of SSD School:

Name of Village/ Ward:

Name of GP/ULB:
୧୧୧ ee {$|
a ee | |
ପଯ ୫ | ଚ
a
a
a
୮୮୧୦ es
Se ଓ
a }୬}}॥ୈ୦ୌେ“।
ଏ

୨

<!-- page 10 -->

On receipt of order from the Headmaster, the SHG / Federation shall deliver one sample
school uniform meant for boys and girls each within one week to the concerned
Headmaster on proper receipt to ascertain the quality of uniform. Thereafter the
Headmaster shall issue go-head letter to the concerned SHGs subject to verification of
one sample pair of uniform. The balance number of uniforms shall be delivered to
concerned Headmaster on proper receipt as per the schedule date line.
Signature of the Headmaster & date
Block
Memo No. Date. Copy forwarded to the CDPO,
Headmaster
Memo No. Date. Copy forwarded to the WEO/ DWO
Headmaster
10
