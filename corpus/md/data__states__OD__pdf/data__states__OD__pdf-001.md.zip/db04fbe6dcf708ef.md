---
doc_id: "db04fbe6dcf708ef"
source_url: "https://inpr.odisha.gov.in/sites/default/files/2026-10/15901%201st%20Corrigendum_0.pdf"
ministry: "Information and Public Relations Department, Odisha"
title: "Download(611.91 KB)"
date: ""
pages: 2
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "912e4f84eb970da5"
---

<!-- page 1 -->

Government of Odisha
Information and Public Relations Department
aie
IPR-FP-IITF-0002-2026/__ /590/ {PR Dated:
କୁ 48* Corrigendum
Tender Call Notice No. 15323 Dtd:30.09,2026
In continuation of the TCN No. 15323 Dtd:30.09.2026 inviting bids for “Selection of
Art Firm/Design Firm/Designer/Fabricator for Odisha Pavilion at IiTF-2026”, it is hereby
informed to all concerned that following modifications are made in the RFP/tender
document.

After discussion with the prospective bidders in the pre-bid meeting held on 06.10.2026
following provisions/clauses of the ୮୮୮ No 15323 Dated 30.09.2026 of | & PLR.
Department are modified as here under.

1. Point No. 5 of Eligibility Criteria (Page-10) may be read as “The Bidder must have
qualified manpower to supervise the execution of work on the spot. One of them
should be the conceptualizer having educational qualification in DIPLOMA/
Bachelor’s /PGDIPLOMA /Master’s

in Architecture / Interior Design / Fine Arts / Applied Arts / Design / Visual
Communication or allied field.

2. Point No. ଘ of Evaluation and Selection Procedure (Page-11) may be read as
“Educational qualification proof of the conceptualizer (Should be from a Govt.
recognized institution or University in Architecture / interior Design / Fine Arts /
Applied Arts / Design / Visual Communication or allied field).

3. Point No. 6 of Eligibility Criteria (Page-10) may be read as "The Bidder must have
minimum average annual turnover of = 4,00,00,000 (Rupees Four Crores) for
last three consecutive financial years duly certified by CA ending on
31.03.2025. The audited balance sheet of last three financial years must
be submitted.

4. Point No. 6 of EMD (Earnest Money Deposit) is added as “EMD will be exempted
to the eligible agencies as per provisions of MSME guidelines.”

5. Point No. 2 of Eligibility Criteria (Page-10) may be read as “The bidder shall provide
the details of the ownership of the company/agency”.

6. Point No. 11 of Details of the Bidder (Page-20) may be read as “Proof of ownership
of Company/Agency”.

Mba)

Si eee

Birector, ।&ମମ୍‌ `
IPR-FP-IITF-0002-2026/01/2026

<!-- page 2 -->

Memeo No. ^ = _APR., BBSR, Dated_09))//808/ _
Copy forwarded to the PS to Additional Chief Secretary to Govt., | & PR for kind
information of Additional Chief Secretary to Govt., Director (Technical)
respectively. Qed ¬=
Te AGee
Deputy Director
Memo No. 15G02 , 416 _ 03 //7/£୯୬୦
Copy forwarded to the System Analyst for information and necessary action. He is
requested to take appropriate steps for uploading the Request for Proposal (RFP) in the
website of Information & Public Relations Department _https://inpr.odisha.gov.in/ &
website of Govt. of Odisha https://odisha.gov.in. ନୁ '୧୭୬ ୨
Oe ee
Depufy*Director
Memo No 15904 , Date. O8{10(B086
Copy forwarded to the Superintendent, Issue Section for information and
necessary action. He is requested to display the 18! Corrigendum Notice in the Notice
Board of this Department. he =
97:75
Deputy ୭୯୦୮
IPR-FP-IITF-0002-2026/01/2026
