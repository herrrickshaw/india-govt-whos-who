---
doc_id: "60e3cbea0f1e8cfb"
source_url: "https://missionshakti.odisha.gov.in/sites/default/files/2022-11/Paddy%20Procurement%20guideline%20with%20letter.pdf"
ministry: "MIS System for Mission Shakti Portal, Odisha"
title: "Download(675.25 KB)"
date: ""
pages: 15
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "fdeb2b08c6404511"
---

<!-- page 1 -->

Government of Odisha
Department of Women & Child Development and Mission Shakti
Directorate of Mission Shakti

No: WCD-MS-0152-2019- /3/6 / DMS{WCDMS) Date: / 3/09 AG .
From

Sri S. S. Nayak, OAS

Joint Secretary to Govt.
To

The Collectors

(Bhadrak, Nuapada, Bargarh, Kalahandi, Ganjam, Subarnapur, Sambaipur,

Bolangir, Koraput)

Sub: Paddy Procurement by WSHGs / SHG Federations during Kharif paddy
procurement.
Ref: (i) This Directorate letter no WCD-MS-963-2019/DMS dated 19.07.2019 ( Bargarh ,

Kalahandi, Ganjam, Sambalpur, Bolangir Koraput , Bhadrak , Nuapada)

(1) This Directorate letter no WCD-MS-1086-2019/DMS dated 08.08.2019.
(iii) This Directorate letter no WCD-MS-1127-2019/DMS 1086 dated 17.08.2019

( Bhadrak , Nuapada)

Madam / Sir,

In inviting a reference to the subject cited above, | am directed to say that the
guidelines for selection and functioning of WSHG / SHG Federation as agent of OSCSC
Ltd / other State agencies for the purpose of paddy procurement during Kharif season is
enclosed herewith.

It is requested to facilitate selection of willing and capable WSHGs / SHG
Federations to take up the activity, in accordance with the enclosed guidelines.

Enel.- (i) Guideline
(ii) Annexure-l, ||, ||| & IV
Yours faithfully
\ \
Joint Secretary ।୩ର୍ଖୌ ହୁ
Memo !4୦.//୭/ 3 ` IDMS(WCDMS) Date: Cacia ;

Copy forwarded to the PS to the Commissioner cum Secretary, Food Supplies &
Consumer Welfare Department for kind information of the Commissioner cum Secretary
with reference to the FS & CW Department Letter No. 13820 dated. 12.09.2019.

Joint Secretary to CaN
Mission Shakti Bhavan, Pokhariput, Bhubaneswar-751030, Odisha
Tel: 0674 2974093, Mail: pmumissionshakti@gmail.com

<!-- page 2 -->

Memo No./3/& `` /DMS(WCDMS) Date: /2/p- 7/2470 .
Copy forwarded to the Managing Director, OSCSC for kind information.
ଞ୍ଜ
Joint Secretary to Govt.
Memo No. /3/7 /DMS (WCDMS) Date: (3/09/0079.

Copy forwarded to Civil Supplies Officers (CSOs) of Bargarh, Kalahandi, Ganjam,
Subarnapur, Sambalpur, Bolangir, Koraput, Bhadrak and Nuapada district for information
and necessary action.

\
Joint Secretary to କା 4
Memo No./2 ୨୮୬ /DMS (WCDMS) Date: (5/07, ? /27⁄7 .

Copy forwarded to DSWOs of Bargarh, Kalahandi, Ganjam, Subarnapur,
Sambalpur, Bolangir, Koraput, Bhadrak and Nuapada district for information and
necessary action.

ent

Joint Secretary to Sot N94
Memo No./>2/ JDMS(WCDMS) Date: / 3/09 [R09 :
Copy to Guard file. /
ଥି
Joint Secretary to କମ”
Mission Shakti Bhavan, Pokhariput, Bhubaneswar-751030, Odisha
Tel: 0674 2974093, Mail: pmumissionshakti@gmail.com

<!-- page 3 -->

BY FAX/POST
GOVERNMENT OF ODISHA
FOOD SUPPLIES AND CONSUMER WELFARE DEPARTMENT
RK
No. [3820 Bhubaneswar, 9160 __ / ଣ୍‌... ୩ ' /'

FSCW-PL-PRC-0037-2016
From

Shri Bijay Kumar Prusty, OAS(S)

Joint Secretary to Govt.

To

Commissioner-cum-Director,

Directorate of Mission Shakti,

Deptt. of Women & Child Development and Mission Shakti
Sub: WSHGs participation under Paddy Procurement.

Ref.: Your letter No. 1253 dated 31.8.2019
Madam,

In inviting a reference to the letter and subject cited above, I am
directed to send herewith the signed copy of “Guidelines for Selection and
Functioning of WSHG/ SHG Federation as Paddy Procurement Agent of
OSCSC Limited/ Other State Agencies” for your kind information and
necessary action.

Yours faithfully,
fiz
12. + . । 7
Joint Secretary to Govt.

<!-- page 4 -->

Guidelines for Selection and Functioning of WSHG/ SHG

Federation as Paddy Procurement Agent of OSCSC Limited/

Other State Agencies
1. Selection of Purchase centre/ Market Yards

a. Where any Gram Panchayat is not represented by PACS/ LAMPCS,
WSHG/ SHG Federations may be appointed to procure paddy in that
GP on behalf of OSCSC Ltd.

9, Where a PACS is operating Paddy Procurement Centres (PPCs)
covering more number of GPs and unable to manage them
smoothly, some of such GPs may be entrusted to capable WSHG/
SHG Federation.

c. The area of operation of the WSHG/ SHG Federation shall be clearly
specified in the appointment orders. The area may include a full
Gram Panchayat or specified villages of that GP.

d. WSHGs/ SHG Federation shall procure paddy at Paddy Procurement
Centres(PPCs) opened by them or they would be tagged to existing
nearest market yards operated by Regulated Marketing
Committees(RMCs). PPCs/ Market Yards shall have infrastructure
like Office room for computerisation of paddy procurement,
electricity connection, covered structure for storage of paddy, rest
shade for farmers, weigh bridge/ weighing scale, moisture metre,
analysis kits through concerned RMC & shall have all weather road
connectivity. Besides, other equipment as prescribed by the Civil
Supplies Corporation shall be made available by the RMC.

e. Since a number of WSHGs shall procure paddy procure for the first
time they may be tagged only to existing market yards operated by
RMCs,

2. Selection of WSHG/ SHG Federation

a. WSHG/ SHG Federations nominated for participation in Paddy
Procurement should be of impeccable past record both in terms of
activity and financial management.

1

<!-- page 5 -->

b. SHGs fulfilling the following parameters may be considered for
selection as agents of OSCSC Ltd. for paddy procurement.

i. WSHG/ SHG federation must have completed 2 years of
existence.

ii. WSHG/ SHG federation should belong to the same GP where
paddy procurement operations are being proposed. Preference
may be given to WSHG/ SHG federation from GP headquarter
village or nearby villages within 1 to 2 KMs radius, as they have
to attend the market yards on daily basis & purchase/ delivery
of paddy may go for late hours.

iii, The WSHG/ SHG federation must have an active bank account
with regular monthly saving by WSHG/ SHG _ federation
members.

iv. The WSHG/ SHG federation must have availed bank credit and
should be regular with the repayment schedule. Due care shail
be taken to access their financial position to procure paddy.

v. The WSHG/ SHG federation should have regular and systematic
book keeping relating to Meeting register and updated Pass
Book.

c. The WSHG/ SHG federation shall procure paddy at PPC or RMC
market yards. The RMC yard must have necessary electricity
connection. The WSHG/ SHG federation shall have IT infrastructure
(one laptop/ desktop, a printer and an inverter), internet
connectivity and shall deploy a Data Entry Operator from among the
WSHG member/ members of SHG federation. It shall avail a Digital
Signature Certificate out of its own expense for transacting business
in the digital mode under P-PAS (Paddy Procurement Automation
System).

d. Advertisement of Expression of Interest for paddy procurement
through WSHG/ SHG federation shall be notified at the Office of the
DSWO & at concerned Office of the CDPOs & shall be displayed at
concerned AWCs for at least 15 days. The format for Expression of
Interest by WSHG/ SHG federations is enclosed herewith as

2

<!-- page 6 -->

Annexure-I. This shall also be shared with the Block Level
Federation.

€. The Sub-Division Level Committee comprising Sub-Collector,
DSwo, ARCS, ACSO, concerned CDPOs, concerned BDOs/
Tahsildars, Inspector of Supplies of the concerned blocks and
Mission Shakti officials will examine the received Expression of
Interest of WSHG/ SHG federations (format enclosed as Annexure-
II) and recommend the suitable WSHG/ SHG federations.

f. The District Level Committee comprising PD, DRDA, Sub-Collector,
DSWO, CSO, DRCS, LDM and District Mission Shakti Officials, will
examine the recommendation of the Sub-Divisional committee and
recommend for appointment.

g. Collector may appoint WSHG/ SHG federation recommended by the
District Level Committee under paddy procurement for a specified
area. The District Collector shall have discretion to review the
recommendation and may take appropriate decision in selecting
suitable WSHGs/ SHG Federations.

3. Registration of WSHGs to Procure Paddy

a. District Managers of OSCSC Ltd. shall enter into a tripartite
agreement with the WSHG/ SHG federations & DSWO for
engagement of WSHG/ SHG federations in Paddy procurement. The
signature of the President/ Secretary of the WSHG/ SHG federations
on the agreement shall be authenticated by the DSWO.

b. Training shall be given by the CSO-cum-District Manager to the
DSWO, concerned CDPOs, Members of the WSHG/ SHG federations
and DEO on FAQ specifications of paddy, MSP, operations at Paddy
Procurement Centres, handling of equipment’s and online transfer of
MSP dues

c. Selected WSHG/ SHG federation shall have PAN card (under Income
Tax), required to avail DSC (Digital Signature Certificate), which is
prerequisite to operate P-PAS (Paddy Procurement Automation
System) for procurement of paddy.

3

<!-- page 7 -->

d. One DEO (Data Entry Operator) shall be engaged, from among the
WSHG/ SHG federation members or a woman having proficiency in
computer operation to operate purchase through P-PAS &
procurement data uploading in the FS & CW Department website.

e. One Laptop with printer and invertor for power back up, internet
connectivity are required for on-line & off line paddy procurement.

f. The WSHG/ SHG federation shall register themselves on the website
of the FS & CW Department (foododisha.in) with the assistance of
the CSO-cum-District Manager and then conduct farmer registration
activities for each procurement season under guidance of the CSO-
cum-District Manager. They shall collect fresh applications from new
farmers and renew registration of existing farmers of villages/ GP
allotted through a web-based software application called Farmer
Registration. Purchase Officer and DEO of WSHG/ SHG federation
shall be trained by OSCSC on FAQ specifications of paddy, MSP,
operations at Paddy Procurement Centres, handling of equipment
and online transfer of MSP dues.

g. On priority they shall be linked to banks and Mission Shakti Loans
shall be disbursed to them to enable them to have working capital.

4. Migration of Farmers’ Data
CSO shall ensure that the data of registered farmers be migrated
from PACS to respective SHG/ federation. The registered farmers of the
earmarked GP or earmarked village shall be migrated from the PACS to
respective WSHG/ SHG federations appointed for concerned GPs by the
CSO-cum-District Manager & DRCS. On migration of farmer’s data,
WSHG/ SHG federation can procure paddy from the registered farmers.
5. Procurement Operation

a. WSHG/ SHG federation shall procure paddy from farmers registered
on the website of FS & CW Department, as per the surplus paddy
available with them. The WSHG/ SHG federation shall not procure

4

<!-- page 8 -->

more than the quantity of paddy authorised to purchase by the
Collector/ CSO.

b. The quality check of paddy to be procured as per the FAQ (Fair
Average Quality) will be done by the concerned RMC officials.

c. Procurement related transactions shall be recorded through a Web-
based software application called Paddy Procurement Automation
System (P-PAS).

d. The OSCSC shall credit the MSP for the paddy procured by the
WSHG/ SHG federation from a registered farmer direct to the
farmer’s bank account through payment gateway of Odisha State
Cooperative Bank at Bhubaneswar.

e. The President/ Secretary of the WSHG/ SHG federation shall act as
Purchase Officer for procurement of Paddy and upload advice online
for payment of MSP dues for paddy procured from a registered
farmer on the same day of purchase.

f. The Paddy procured shall be handed over to the custom miller or his
authorised agent tagged to the WSHG/ SHG federation on proper
acknowledgement through a document which is system generated
and called Transit Pass-cum-Acceptance Note.

g. DSWO shall be the Nodal Officer for purchase of paddy through
WSHG/ SHG federations in the district. CDPO as well as Inspector of
Supplies having jurisdiction shall be monitoring officers in respect of
WSHG/ SHG federations procuring paddy.

h. WSHG/ SHG federation shall follow Operational Guidelines of OSCSC
Ltd. setting out norms/ procedures for conduct of procurement by
WSHG/ SHG federations.

i. Paddy shall be procured in RMC Yard only. WSHG/ SHG federation
shall ensure, in coordination with RMC, that required equipment and
materials such as tarpaulins are available at the Paddy Purchase
Centres (PPCs) or Mandis operated by them. The secretary, RMC
concerned shall provide all the necessary equipment to the WSHG/
SHG federation for conducting procurement operations.

5

<!-- page 9 -->

4. The RMC concerned shall provide minimum amenities, like drinking
water, toilet and rest shed with seating facilities to the farmers.

k. Mandi Handling Operations in the PPCs and payment of charges
thereof shall be regulated as per the rates decided by the OSCSC
Ltd.

|. WSHG/ SHG federation shall ensure proper maintenance of records
and registers (prescribed by OSCSC) in connection with purchase of
paddy from farmers.

m.WSHG/ SHG federation shall be paid commission and Mandi Labour
Charges (if actually performed) at the rates fixed by OSCSC Ltd.

n. Collector may form a district level committee comprising CSO,
DSWO (as convenor), DRCS/ ARCS and secretary, DCCB to resolve
difficulties noticed in operation of WSHG/ SHG federations in paddy
procurement activities.

o. MD, OSCSC is authorised to prescribe additional guidelines to
facilitate participation by WSHG/ SHG federations in procurement
operations.

6. Activities at Purchase Centre

a. On arrival of paddy as per the Token Slip, paddy shall be unloaded
by the farmers at the purchase centre.

b. Sample of paddy shall be drawn & quality analysis shall be made by
the RMC staff & FAQ (Fair Average Quality) paddy shall be
purchased.

©, ` Weighment of paddy shall be made & Purchase-cum-Vendor receipt
shail be generated.

d. Mandi handling charges shall be borne by the WSHG/ SHG
federations, to be reimbursed by the OSCSC Ltd.

e. On procurement of paddy, Transit Pass-cum-Acceptance Note shall
be generated and paddy shall be delivered to tagged Custom Millers
on that day.

6

<!-- page 10 -->

i. Supervision & Monitoring

Since WSHG/ SHG federation will be procuring Paddy for the first
time in the market yards, a team of officials consisting of Tahasildar/
BDO, CDPO/ ICDS Supervisor, Marketing Inspector & other officials shall
be earmarked for each purchase centre to guide & support them.

They will interact with the WSHG/ SHG federation members & will
solve all issues pertaining to procurement.

If WSHGs/ SHGs federations do not work as per prescribed norms
or where unauthorised persons/ male family members are employed by
WSHGs to conduct operations, they will be debarred from the
procurement process.

8. Documentation / records

a. One Farmers Control Register shall be maintained at the purchase
centre to regulate arrival of paddy as per handling capacity of the
purchase centre, Format is enclosed as Annexure — III.

b. One Welcome Farmer’s Register shall be maintained to indicate the
token availed by farmers, arrival of paddy. Format is enclosed as
Annexure = IV.

€. Token slip to farmers shall be issued as per the farmer's control
register through P-PAS. During issue of Token slips due care shall
be taken to verify the ID proof of the farmers & to verify their Bank
account to avoid mismatch for transfer of MSP (Minimum Support
Price). One copy of token slip shall be retained by the WSHG / SHG
federation.

d. On purchase of paddy, Purchase-cum-Vendor receipt shall be
generated and one copy shall be given to the farmer & one copy
shall be retained.

€. Procured paddy shall be delivered to Custom Miller on generating
Transit Pass cum Acceptance Note by the WSHGs. One copy shall be
handed over to the Custom Miller & paddy shall be delivered, one
copy to the CSO-cum-District Manager. One copy is to be retained
by the WSHG/ SHG federation.

7
