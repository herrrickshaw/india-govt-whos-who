---
doc_id: "d0aa12be93bddd9b"
source_url: "https://www.gacrkl.ac.in/ug-exam-regulation.pdf"
ministry: "Government Autonomous College, Rourkela, Odisha"
title: "Rules & Regulations"
date: ""
pages: 21
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "45f2b9a1bf4c4b55"
---

<!-- page 1 -->

Model Regulation for Under Graduate Programme for
+3 (B.A/B.Com/B.Sc)
(As per CBCS System) From the Session 2019-20
Universities/Autonomous/Degree colleges of Odisha

1. Outlines of Choice Based Credit System(Arts / Science / Commerce stream)

Core Course(14 papers) for Bachelorsdegree in a particular discipline :
The course designed for papers under this category aim to cover the basics that a student is expected to
imbibe in that particular discipline. A course, which should compulsorily be studied by a candidate as
a core requirement is termed as a Core course. In BA Pass course, MIL1, MIL2, English1 and
English2 are also core courses. The Institution/student may refer to the Corresponding Language
syllabus for the same.
Discipline Specific Elective (DSE) Course( 4 Papers)
Elective courses offered under the main discipline/subject of study is referred to as Discipline Specific
Elective. The list provided under this category are suggestive in nature and each University has
complete freedom to suggest additional papers under this category based on their expertise,
specialization, requirements, scope and need.
Dissertation/Project: An elective course designed to acquire special/advanced knowledge, such as
supplement study/support study to a project work. A candidate studies such a course on his own with
an advisory support by a teacher/faculty member is called dissertation/project.
Generic Elective (GE) Course( 4 papers)
An elective course chosen from an unrelated discipline/subject, with an intention to seek exposure
beyond discipline/s of choice is called a Generic Elective. The purpose of this category of papers is to
offer the students the option to explore disciplines of interest beyond the choices they make in Core
and Discipline Specific Elective papers. Universities can offer two papers each in two subjects as
GE or four papers one subject. The BA pass course also offers 2 GE papers. Depending on the
subject, GE1 and GE2 listed in each Honours syllabus may be used as models for the purpose.
Ability Enhancement Compulsory Courses (AECC):
Paper I : Environmental Science.
Paper II :MIL Communication ( English / Odia / Hindi / Sanskrit / Urdu / Telugu )

Skill Enhancement Courses (SEC):
These courses may be chosen from a pool of courses designed as per the availability of courses and
faculty/suitability of thecollege ,to provide skill-based knowledge. The main purpose of these courses
is to provide students life-skills so as to increase their employability. A Student opting for Honours
would have to take two SEC and a student offering Pass papers would take four papers of SEC. Some
of the subject syllabi have also provided options in SEC.

1|Page

<!-- page 2 -->

The Autonomous institution/University through its Board of Studies need to suggest the necessary
qualifications for teaching of the ability and skill courses. However, as a general practice, Specific
language teachers can be assigned to teach AECC2. Life Science Faculty can be assigned to
Environment Studies, English Faculty for Communicative English, Mathematics faculty to
quantitative aptitude and Logical Reasoning, computer science or IT faculty for ICT related courses,
commerce faculty for financial skills etc.
An undergraduate degree with Honours in a discipline may be awarded if a student completes 14 core
papers in that discipline, 2 Ability Enhancement Compulsory Courses (AECC), minimum 2Skill
Enhancement Courses (SEC), 4 papers from a list of Discipline Specific Elective and 4 papers from
one discipline or 2 papers each in two disciplines other than his /her core discipline.
ELIGIBILITY
Higher Secondary / +2 / Senior Secondary or any other equivalent examination passed from any
Board / Council established by the Govt. of India or any State Govt. or any other equivalent
examination recognized by Central Board of Secondary Education/ Council of Higher Secondary
Education, Govt. of Odisha/ Dept of Higher Education / Dept. of Industry or any other Dept of
Govt. of Odisha. Those joining B.Sc. Programme must have passed the above examination under
the faculty of Science/ Technology / Engineering/ Pharmacy etc. There shall be no such
restriction for joining BA/ B.Com stream.
Students ordinarily may be selected for admission through merit in the qualifying examination.
DDCE would admit students on first come first serve basis. The Govt. of Odisha may lay down
admission process for colleges under its control. Directorate of Distance & Continuing
Education would decide its own admission policy.
2.

DURATION:
Three years of degree programme will have six semesters. Odd semester (i.e. 1st, 3rd& 5th
semester) is from 1st June to 30thNovember and the examination shall be held normally in the
month of November. Even semester (i.e. 2nd, 4th& 6th semester) is from 1stDecember to 31stMay
and the examination shall be held normally in the month of April/May. However, the Final
Semester shall be conducted in April and it is desirable that the result shall be publishedwithin
30 days and not beyond 45 days from the date of completion of the examination. A student
would be required to complete the course within six academic years from the date of admission.

3.

COMPULSORY REGISTRATION:
a. Registration for the 1st semester examination is compulsory and will be at the timeof
admission.All the students admitted in 1st semester of a college will compulsorily be registered
by the University. A registration / examination card will be issued tocandidates admitted and
that will remain valid till completion of the course. There will be no need toissue admit card
for every semester.The candidates fulfilling the attendance norms and other eligibility criteria
will be allowed to appear the examination.Students will not be required to fill up any form for
the University examination for regular papers. Examination Fee will be collected at the time of
admission/readmission and affiliated Colleges will be required to send the appearing
studentslist along with the requisite fees to the university before the cut off date for each
semester.If a student does not appear for all the papers in both first and second semester
examinations, his admission for the said course will be cancelled. Concerned universities will
notify all fees to be paid before admission process.

2|Page

<!-- page 3 -->

b. For students desiring to appear in any back paper(s), they would be required to fill up the
examination forms.Those who fail in any paper in asemester or unable to appear in any
semester or unable to submit forms for back papers of 2/3/4/5/6 may appear in those papers in
subsequent semester examination within 6 years from the date of admission to that course. A
student must clear backlog papers (failed) within 6 academic years starting from the year of
admission batch.
c. Back papers are to be permitted in consecutive semesters for the first attempt at clearing back
paper. Subsequent attempts will be allowed in alternate semester (eg :A student failing in a
paper of Semester- I, will be allowed to appear for the paper in Sem II. If he/she fails to clear
this back paper in Sem II, he will get the next opportunity in Sem IV, Sem VI etc. only), This
practice is to ensure earliest opportunity to the student as well as timely conduct of regular
paper exams.
4.

ATTENDANCE:
1.
2.

A candidate shall be required to attend at least 75% of the lectures in theory and practical
classes taken separately.
Condonation may be granted by the Principal (In case of affiliated Colleges) to the extent of
15% in exceptional cases i.e. serious illness & hospitalization, accident, mishap in the family
or deputation by the college for any specific work for which the period of his/her absence shall
not be counted towards the calculation of attendance on the condition that students concerned
submit a certificate to that effect from the appropriate authority.
Further to the above, the Principal may grant further condoning of shortage in attendance to
the extent of 10% in respect of candidates who represent the University or State for InterUniversity or inter-state competitions in Games and Sports or attending different recognized
National level camps.
Under no circumstance, the condoning shall be beyond 25%.
This clause shall not be applicable for Distance Education

3.

4.
5.
5.

DURATIONOF THE EXAMINATIONS - MID SEMESTER & END SEMESTER:
The Choice Based Credit System (CBCS) examination shall be implemented in Semester
pattern.Examination timetable for the odd semester will be communicated by 20 th June and even
semester by 7th December. Each semester examination shall consist of a Mid-Semester
(Internal) Examination and End Semester examination. Mid Semester examination shall be
conducted only for theory papers. End Semester Examination in theory papers carrying full
marks above 50(e.g. 60, 75, 80 etc) shall be of 3 hours duration and practical shall be of 3hours
(for full marks carrying 25). On the other hand, theory papers carrying 50 marks or below
shall be of 2 hours duration.

6.

MID SEMESTER EXAMINATION:
6.1. Mid semester examination will be of 01 hour duration for 20/15 marks(20 for subjects having

no practical and 15 for subject with practical papers). There shall be no pass mark in Mid
Semester examination. The type of questions will be decided by the college authority.
6.2. The Mid-Semester Examination shall be conducted and valued by the Teacher(s) who are
teaching the corresponding paper or by any external faculty in the college(s). A student who
fails to appear in a Mid-Semester Examination will be allowed one more chance to take the
same examination. There will be no provision to re-appear in the Mid-Semester Examination
for improvement.
6.3. The College has to conduct the Mid Semester Examination between 15 th September to 30th
October for1st, 3rd, & 5thSemester and in between1st March to 15th March for 2nd, 4th, & 6th
3|Page

<!-- page 4 -->

Semesterrespectively and will feed the marks online under the University/College
Examination management System within 15 days from the date of examination. In case of
Mid Semester examination of Semester-I, marks shall be fed by 30th November.
6.4. The College authority will preserve the answer script of the Mid Semester examination for
06 months from the date of publication of result of concerned semester for reference.

7.

6.5

The College authority of the valuation zones/University authority will preserve the answer
Script of the End Semester examination for 06 months from the date of publication of result
for reference.

6.6

For DDCE students, DDCE shall frame its policy for Mid Semester examination.

6.7

A student has to appear the Mid Semester Examination. Absence in a Mid Semester paper
will be declared as failed in that Paper. A student who was absent in the Mid
Semesterexamination during both the chances but has passed at the University End Term
examination shall be treated as failed in that Semester. Such candidates would be required to
appear the Mid-Semester Examinations in subsequent semester.
MARK DISTRIBUTION:

A. Subjects Without Practical :
Mid Semester
20
B. Subjects With Practical :
Mid Semester

End Semester
80

Total
100

End semester
Total
A-Theory
B-Practical
15
60
25 (20 + 05 (Record))
100
C. Projects : The mark distribution would be subject specific. In general, the Project report will
carry 80 marks and viva voce/Seminar will carry 20 marks. The report marks will be subdivided as :
Introduction and context : 10 marks; Literature survey : 10 marks; Actual project work methodology :
20 marks, Results, discussion, critical analysis : 10 marks; Clarity of thought and aesthetics of report :
10 marks
8. POLICY ON DSEPAPERS

a. DSE – 4 for Honors students (6th Semester) will be a paper like the other three DSE papers. For
students who have secured 60% in aggregate or above (or equivalent CGPA) in their first three
semesters, colleges can exercise the option of offering a project to such students. Unless
explicitly indicated in the respective subject curriculum, the recommended marking scheme
will have about 60 % in the project report 40% in a Seminar cum Viva Voce). The Project
paper will not have Mid Semester Examination and it will be evaluated by an Internal
Examiner specified by the college.
b. DSE Papers for Honours. Students may or may not have the Practical component as
proposed by the respective Board of Studies. If there is no practical, tutorial classes are
allotted as per the 5+1 formula.
c. Individual faculty of the college are to prepare the list of probable project topics under their
guidance for a batch in the beginning of the fifth semester to facilitate the students and such list
to be notified by the college for information of students. Evaluation of project shall be
completed before the commencement of the End Semester Examination of Semester-VI .
9.

GRADE SYSTEM IN EACH PAPER (MID +END SEM EXAM) IN A SEMESTER
9.1

GRADING SYSTEM
4|Page

<!-- page 5 -->

Qualification
Outstanding
Excellent
Very Good
Good
Above Average
Fair
Pass
Fail
Absent
Malpractice

Qualification

Grade

Outstanding
Excellent
Very Good
Good
Above average
Fair
Pass
Fail
Absent
Malpractice

'O'
'A+'
'A'
'B+'
‘B’
'C'
'D'
'F'
‘ABS’
‘M’

Grade
'O'
'A+'
'A'
'B+'
‘B’
'C'
‘D’
'F'
‘ABS’
‘M’

Mark Secured from 100
90-100
80-89
70-79
60-69
50-59
45-49
40-44
Below 40
00
00

Mark Secured
from 100
90-100
80-89
70-79
60-69
50-59
45-49
40-44
Below 40
00
00

Grade
Point
10
9
8
7
6
5
4
0
0
0

Grade Point
10
9
8
7
6
5
4
0
0
0

Classification for
Hons.
First Class Hons.

Classification
for Pass

Pass
Second Class
Hons.
Fail
Fail
MP

a. The candidate obtaining Grade-F is considered failed and will be required to clear the back
paper(s) in thesubsequent examinations within the stipulated time.
b. For candidate in both Pass and Honours Courses securing ‘B’ Grade and above in aggregate in
their first appearance will be awarded Distinction. However, students who could not appear at
an examination due to they representing the University or State in Inter-University or InterState competitions in Games and Sports at national/international level or attending National
level NCC/NSS camps will get one chance exemption for distinction.
c. FAIL/MP/HARD CASE and Back Paper Clearance candidates in any Semester Examination
are not eligible for award of Distinction.
9.2

A student’s level of competence shall be categorized by a GRADE POINT AVERAGE to be
specified as follows .
SGPA -

Semester Grade Point Average

CGPA -

Cumulative Grade Point Average

(a) GRADEPOINT

- Integer equivalent of each letter grade

(b) CREDIT
-Integer signifying the relative emphasis of individual course
item(s) in a semester as indicated by the Course structure and syllabus.
5|Page

<!-- page 6 -->

CREDIT POINT- CREDIT× GRADE POINT for each course item
CREDIT INDEX:

∑CREDIT POINT of

course items ineach Semester

CREDIT INDEX
∑ CREDIT

GRADE POINT AVERAGE =
SEMESTER GRADE POINT AVERAGE (SGPA ) =

CREDIT INDEX for each semester
∑ CREDIT

CUMULATTIVE GRADE POINT AVERAGE (CGPA) =
th
CREDIT INDEX of all semesters upto 6 sem
∑ CREDIT
9.3.

Paper Type, Subject, Credit, Grade, SGPA& CGPA in the last semester result shall be
reflected in the Grade Sheet.

9.4

The details of grading system shall be printed on the backside of University Mark-sheet.

9.5

Formula for Equivalent Percentage of Marks:
The following formula will be used to obtain the equivalent percentage of marks for the CGPA
awarded to the students of the University.

Case a. Equivalent Percentage of Mark = (CGPA – 0.50) × 10 ; for
4<CGPA≤10
Case b. Equivalent Percentage of Mark = CGPA × 10 for CGPA≤4
9.6

Illustration of Computation of SGPA and CGPA and Format for transcripts of Courses :

A.
B.A. / B.Sc. / B.Com. Honors Course (The Actual Semester wise course
organization is also available in individual syllabus.
Course

Grade
Letter

Credit

Grade
Point

Credit Point
= (Credit ×
Grade Point)

SGPA =
(Credit point/
Credit)

Semester I
C-1

06

A

8

48

C-2

06

B+

7

42

AECC-1

04

B

6

24

GE-1

06

B

6

36

Total

22

150

6.8 (150/22)

Semester II
C-3

06

B

6

36

C-4

06

C

5

30
6|Page

<!-- page 7 -->

AECC -2

04

B+

7

28

GE-2

06

A+

9

54

Total

22

148

6.73 (148/22)

Semester III
C-5

06

A+

9

54

C-6

06

0

10

60

C-7

06

A

8

48

SEC-1

04

A

8

32

GE-3

06

0

10

60

Total

28

254

9.07 (254/28)

Semester IV
C-8

06

B

6

36

C-9

06

A+

9

54

C-10

06

B

6

36

SEC-2

04

A+

9

36

GE-4

06

A

8

48

Total

28

210

7.5 (210/28)

Semester V
C-11

06

B

6

36

C-12

06

B+

7

42

DSE-1

06

0

10

60

DSE-2

06

A

8

48

Total

24

186

7.75 (186/24)

Semester VI
C-13

06

A+

9

54

C-14

06

A

8

48

DSE-3

06

B+

7

42

DSE-4

06

A

8

48

Total

24

192

8.0 (192/24)

CGPA
7|Page

<!-- page 8 -->

GRAND
TOTAL

148

1140

7.7(1140/148)

Consolidated SGPA table for six semesters :
Sem – I

Sem – II

Sem – III

Sem – IV

Sem – V

Sem - VI

Credit : 22
SGPA : 6.8

Credit : 22
SGPA : 6.73

Credit : 28
SGPA : 9.07

Credit : 28
SGPA : 7.5

Credit : 24
SGPA : 7.75

Credit : 24
SGPA : 8.0

Thus, CGPA = (22 x 6.8 + 22 x 6.73 + 28 x 9.07 + 28 x 7.5 + 24 x 7.75 + 24 x 8.0)/ 148 = 7.7

B.

B. Sc. PASS Course
Credit

Grade
Letter

Grade
Point

Credit Point
= (Credit ×
GradePoint)

DSC-1A

06

B

6

36

DSC-2A

06

B+

7

42

DSC-3A

06

C

5

30

AECC -1

04

B

6

24

Total

22

Course

SGPA =
(Credit Point/
Credit)

Semester I

132

6.0(132/22)

Semester II
DSC-1B

06

B

6

36

DSC-2B

06

B

6

36

DSC-3B

06

C

5

30

AECC-2

04

A+

9

36

Total

22

138

6.27(138/22)

Semester III
DSC-1C

06

A

8

48

DSC-2C

06

A+

9

54

DSC-3C

06

A

8

48

SEC-1

04

A

8

32

Total

22

182

8.27(182/22)
8|Page

<!-- page 9 -->

Semester IV
DSC-1D

06

C

5

30

DSC-2D

06

B

6

36

DSC-3D

06

B+

7

42

SEC-2

04

A+

9

36

Total

22

144

6.54(144/22)

Semester V
DSC-1A

06

B

6

36

DSC-2A

06

A+

9

54

DSC-3A

06

A

8

48

SEC-3

04

B

6

24

Total

22

162

7.36(162/22)

Semester VI
DSE-1B

06

B+

7

42

DSE-2B

06

B

6

36

DSE-3B

06

C

5

30

SEC-4

04

C

5

20

Total

22

128

5.82(128/22)

132

886

6.71

CGPA
Grand
Total

(886/132)

Consolidated SGPA table for six semesters :
Sem – I

Sem – II

Sem – III

Sem – IV

Sem – V

Sem - VI

Credit : 22
SGPA : 6.0

Credit : 22
SGPA : 6.27

Credit : 22
SGPA : 8.27

Credit : 22
SGPA : 6.54

Credit : 22
SGPA : 7.36

Credit : 22
SGPA : 5.82

Thus, CGPA = (22 x 6.0 + 22 x 6.27 + 22 x 8.27 + 22x 6.54 + 22 x 7.36 + 22 x 5.82)/ 132 = 6.71

9|Page

<!-- page 10 -->

C.

B.A. PASS Course

==================================================================
Paper+ Practical Paper + Tutorial
I. Core Course (6 Credits) (12 Papers) 12X4= 48 12X5=60
Two papers – English
Two papers – MIL
Four papers – Discipline 1.
Four papers – Discipline 2.
Core Course Practical / Tutorial* 12X2=24 12X1=12 (12 Practicals)
II. Elective Course (6 Credits) (6 Papers) 6x4=24 6X5=30
Two papers- Discipline 1 specific
Two papers- Discipline 2 specific
Two papers- Inter disciplinary
Two papers from each discipline of choice
and two papers of interdisciplinary nature.
Elective Course Practical / Tutorials* 6 X 2=12 6X1=6 (6 Practical/ Tutorials*)
Two papers- Discipline 1 specific
Two papers- Discipline 2 specific
Two papers- Generic (Inter disciplinary)
Two papers from each discipline of choice including papers of interdisciplinary nature.
Optional Dissertation or project work in place of one elective paper (6 credits) in 6th
Semester
III. Ability Enhancement Courses
1. Ability Enhancement Compulsory Courses (AECC)
(2 Papers of 4 credits each) 2 X 4=8 2 X 4=8
Environmental Science
English/Hindi/MIL Communication
2. Skill Enhancement Courses (SEC) 4 X 4=16 4 X 4=16
(4 Papers of 4 credits each)
__________________ ________________
Total credit= 132 Total = 132
Institute should evolve a system/policy about ECA/ General
Interest/Hobby/Sports/NCC/NSS/related courses on its own.
*wherever there is a practical there will be no tutorial and vice-versa.

.
Course

Credit

Grade

Grade

Credit Point

SGPA = (Credit
10 | P a g e

<!-- page 11 -->

Letter

Point

= (Credit ×
Grade point)

Point/Credit)

Semester I
MIL-1

06

A

8

48

DSC-1A

06

B

6

36

DSC-2A

06

A

8

48

AECC-1

04

B+

7

28

Total

22

160

7.27(160/22)

Semester II
MIL-II

06

A+

9

54

DSC-1B

06

B+

7

42

DSC-2B

06

B+

7

42

AECC-2

04

B

6

24

Total

22

162

7.36(162/22)

Semester III
English -I

06

B

6

36

DSC-1C

06

A

8

48

DSC-2C

06

B

6

36

SEC-1

04

A

8

32

Total

22

152

6.91(152/22)

Semester IV
English - II

06

B+

7

42

DSC-1D

06

A+

9

54

DSC-2D

06

A

8

48

SEC-2

04

B

6

24

Total

22

168

7.63(168/22)

Semester V
SEC-3

04

A+

9

36

11 | P a g e

<!-- page 12 -->

DSE-1A

06

A

8

48

DSE-2A

06

A+

9

54

GE-1

06

A+

9

54

Total

22

192

8.73(192/22)

Semester VI
SEC-4

04

A+

9

36

DSE-2A

06

B

6

36

DSE-2B

06

A

8

48

GE-2

06

A

8

48

Total

22

168

7.63((168/22)

CGPA
7.59
Grand Total

132

1002

1002/132

Consolidated SGPA table for six semesters :
Sem – I

Sem – II

Sem – III

Sem – IV

Sem – V

Sem - VI

Credit : 22
SGPA : 7.27

Credit : 22
SGPA : 7.36

Credit : 22
SGPA : 6.91

Credit : 22
SGPA : 7.63

Credit : 22
SGPA : 8.73

Credit : 22
SGPA : 7.63

Thus, CGPA = (22 x 7.27 + 22 x 7.36 + 22 x 6.91 + 22 x 7.63 + 22 x 8.73 + 22 x 7.63)/ 132 = 7.59
Transcript (Format): Based on the above recommendations on Letter grades, grade points and SGPA
and CGPA, the Higher Education Institutions(HEI) may issue the transcript for each semester and
a consolidated transcript indicating the performance in all semesters.

C.

B.Com PASS Course
Credit

Grade
Letter

Grade
Point

Credit Point
= (Credit ×
Grade point)

Core-I

06

A

8

48

Core-II

06

B

6

36

GE-I

06

A

8

48

Course

SGPA = (Credit
Point/Credit)

Semester I

12 | P a g e

<!-- page 13 -->

AECC-1

04

Total

22

B+

7

28
160

7.27(160/22)

Semester II
Core-III

06

A+

9

54

Core-IV

06

B+

7

42

GE-II

06

B+

7

42

AECC-2

04

B

6

24

Total

22

162

7.36(162/22)

Semester III
Core-V

06

B

6

36

Core-VI

06

A

8

48

GE-III

06

B

6

36

SEC-1

04

A

8

32

Total

22

152

6.91(152/22)

Semester IV
Core-VII

06

B+

7

42

Core-VIII

06

A+

9

54

GE-IV

06

A

8

48

SEC-2

04

B

6

24

Total

22

168

7.63(168/22)

Semester V
Core-IX

06

A+

9

54

Core-X

06

A

8

48

DSE-I

06

A+

9

54

DSE-II

06

A+

9

54

Total

24

210

8.75(210/24)

Semester VI
Core-XI

06

A+

9

54

Core-XII

06

B

6

36

DSE-III

06

A

8

48
13 | P a g e

<!-- page 14 -->

DSE-IV

06

Total

24

A

8

48
186

7.75((186/24)

CGPA
7.63
Grand Total

136

1038

1038/136

Consolidated SGPA table for six semesters :
Sem – I

Sem – II

Sem – III

Sem – IV

Sem – V

Sem - VI

Credit : 22
SGPA : 7.27

Credit : 22
SGPA : 7.36

Credit : 22
SGPA : 6.91

Credit : 22
SGPA : 7.63

Credit : 24
SGPA : 8.75

Credit : 24
SGPA : 7.75

Thus, CGPA = (22 x 7.27 + 22 x 7.36 + 22 x 6.91 + 22 x 7.63 + 22 x 8.75 + 22 x 7.75)/ 132 = 7.63
Transcript (Format): Based on the above recommendations on Letter grades, grade points and SGPA
and CGPA, the Higher Education Institutions(HEI) may issue the transcript for each semester and
a consolidated transcript indicating the performance in all semesters.

D. Schedule of Teaching :
Course

Max mark

No. of periods per Total
hoursrequired
for
week
completion of each paper of the
course

CORE/GE/DSE/DSC 100

6

50+10

CORE/GE/DSE/DSC 75

4

40

AECC

100

4

40

SECC

100

4

40

PRACTICAL

25

1 practical class

20

Self study

--

Dissertation
or 100
Project as DSE -IV

E. Eligibility of departmental teachers to teach AECC and SEC papers :
Course

Name of the course

AECC

Environmental study

Teachers of the dept eligible
to teach

14 | P a g e

<!-- page 15 -->

AECC

MILCommunication(Eng/Odia/Hindi/Sans/Urdu/Telugu

Concern Language dept

SEC
Spl.

Quantitive Aptitude and Logical Reasoning

Mathematics/Computer
Science

SEC

Modern office management

Computer
Science/Commerce

SEC

Leadership and personality development

Psychology

SEC

Financial Literacy and Banking

Commerce

SEC

Data analysis and computer application

Computer Science

SEC

Fashion Technology

Home Science

Universities may introduce the above all/some SEC courses or design new course . In case any new
course under SEC is designed by the University ,the departmental teachers eligible to teach it should
be spelled out .
10.

11.

REPEAT EXAMINATION:
10.1

A student has to clear back paper(s) (if failed) by appearing at subsequent
/alternate semester examinations within six academic years from the year/session of
admission. (refer Clause 3)

10.2

A student may appearinimprovement (having passed in that paper) in any number of
papers ONLYONCE in thenext semester examination.

CREDIT/GRACE/HARD CASE RULE:
11.1

CREDIT
On the basis of complaints received from the examinees/subject teachers, the Board of
Conducting Examiners (BCE) prior to evaluation may recommend for award of Credit on
specific question, if they are convinced the question is either out of course or wrong. This
credit has to be extended to all examinees on the said question excepting to the
examinees who have submitted a blank answer book.

11.2

GRACE
Before publication of results, the BCE may recommend for award of Grace Mark in a
particular paper if they are convinced that the general performance of candidates in that
paper is poor and deserves special consideration. While suggesting grace mark, the BCE
must take the performance of the examinees in the said paper for the last three respective
examinations. The Controller of Examinations has to submit the previous results for three
years before the BCE for consideration. The recommendation of BCE has to be placed
before the Vice-Chancellor for consideration and approval.

11.3

HARD CASE RULE

(a)

2% ofthe total as grace mark subject to maximum of 5 (five) marks in single paper
shall be given to pass in a semester. This shall be applicable in each semester.
(* maximum 8 mark out of total 400 and 10 mark out of 500 per Semester)
15 | P a g e

<!-- page 16 -->

(b)

Maximum 0.5 (point five percent) grace mark (2 marks)can be given for award of ‘B’
Grade in 6th semester in aggregate.This is applicable provided the candidate has not
availed grace mark underClause-11.1.

(c)

Maximum 0.5 (point five percent) grace mark (2 marks) can be given for award of ‘B+’
Grade in 6th semester in aggregate. This is applicable provided the candidate has not
availed grace mark underClause-11.1.

12. EXAMINATION QUESTION PATTERN
12.1

The duration of end semester examination is as reflected in Clause No.5 above.

12.2

For subjectsother than language subjects and without having practical, full marks are
100 per paper out of which 20 marks are allotted for Mid-Semester Examination
(Internal) and 80 marks are for end semester examination.
a.
b.
F.
G.
H.

12.3

The question papers shall be divided into four parts
Part I will carry 12 one mark questions in the form of fill in the blanks and one
word answer. (12 marks)
Part II will carry 10 two mark questions of which 8 have to be answered. The
answer should be within two to three sentences maximum. (16 marks (8X2))
Part III will carry 10 three mark questions of which 8 have to be answered. The
answer should be within 75 words maximum. (24 marks (8X3))
Part IV will carry 4 seven mark questions of EITHER OR format. The EITHER
OR in question can be from same or different units of the paper. The answer
should be within 500 words maximum. (28marks (7X4))

For subjects other than language subjects and with practical, full marks are 100 per
paper out of which 15 marks is allotted for Mid- Semester Examination, 60 marks is
for End Semester Examination and 25 marks is for practical.

a. The question papers shall be divided into four parts
b . Part I will carry 8 one mark questions in the form of fill in the blanks and one word
answer. (08 marks(8X1)
c. Part II will carry 10 one point five mark questions of which 8 have to be answered. The
answer should be within two to three sentences maximum. (12 marks (8X1.5))
d Part III will carry 10 two mark questions of which 8 have to be answered. The answer
should be within 75 words maximum. (16 marks (8X2))
e Part IV will 4 numbers of six mark questions of EITHER OR format. The EITHER OR
in question can be from same or different units of the paper. The answer should be
within 500 words maximum. (24 marks (6X4))
f Practical will carry 25 marks out of which 05 will be for records ,05 for viva voce and
15 for the core experiment .
12.4
For Language courses like Odia, Hindi, Sanskrit, English, the question pattern and
marking scheme will be as given in the respective curriculum. For
12.5

For Autonomous Colleges, each department shall have a designated Teacher in-charge
of Examination to be decided by the Principal in addition to the Controller of
Examinations of the College.For non autonomous college, the principal or the teacher
nominated by the principal will be responsible for conducting examinations.

16 | P a g e

<!-- page 17 -->

13.

12.6

Suitable modifications may be made by the Autonomous Colleges keeping in view the
UGC Guideline for Autonomous Colleges, University as well as state government’s
Guidelines from time to time. .

12.7

The board of studies in each subject are required to prepare Question Banks in each
paper and submit it to the controller of Examination.

MINIMUMPERCENTAGE AND MARKS TO BE SECURED FOR PASSING:
13.1

Paper without Practical :

Mid
End
Semester Semester

Pass Mark – End
Semester
30% out of 80
(i.e. 24 marks)

Total

Paper Pass Mark

40 out of 100
By taking both components
(i.e. Mid-Sem + End Sem Exam.)
End Semester(University Examinations) Total Mark: 80, 30% out of 80 (i.e. 24 mark)
Total Mark: 100 (40% out of 100)
No Pass mark for Mid Semester Exam. A student has to appear the Mid Semester Exam.
Securing ‘ABS’ in both the chances in Mid Semester examinations, the student will be
declared fail in that paper, though he/she secures pass mark in theory papers.

20

80

a.
b.
c.

13.2

100

Paper with Practical :

Mid
Sem

End Semester
ATheor
y

15

60
a.
b.
c.
d.

Pass Mark
A-Theory

BPractical

30% out of 60
(i.e. 18 mark)

25

Tota
l

Paper Pass Mark

100

40 out of 100
By taking (i.e. Mid-Sem +
End Sem Exam + Practical)

Pass Mark
B-Practical
40% out of 25
(i.e. 10 mark)

End Semester(University Examinations) : Total Mark: 60, 30% out of Total Mark(i.e.
18 mark)
Minimum pass mark for practical paper is 40%.
Total Mark: 100 (40% out of 100)
No Pass mark for Mid Semester Exam. A student has to appear the Mid Semester
Exam. Securing ‘ABS’ in both the chances in Mid Semester examination, student will
be declared fail in that paper, though he/she secures pass mark in theory and practical
paper.
NB:
In order to clear a Semester examination a candidate is required to pass in all theory
& practical papers/project component of the said semester.

14.

EVALUATION RESPONSIBILITY

14.1

SCHEME OF VALUATION
Scheme of valuation has to be prepared by subject experts, preferably members of Board of
Conducting Examiner for every paper and has to be supplied to the valuation zones by the
Controller of Examination before evaluation.

17 | P a g e

<!-- page 18 -->

14.2:

RESPONSIBILITY OF EXAMINER
(a) The concerned Examiners are solely responsible for evaluation of Mid Semester, Practical
and End Semester Examinations. He/She is also responsible for maintaining all records to
justify his/her evaluation scheme and marks thereof.
(b) Neither the Principal nor the Management of the collegeshall have the right/power to change
the Mid Semester marks awarded by a teacher. However, if the Principal is convinced that
the Mid Semester marks awarded by a teacher is biased, he/she shall appoint a committee
where the teacher concerned will be a member for review. The decision of the committee
shall be final and binding. The decision with the revised marks shall be sent to the University
for necessary Action.
(c) Internal examiners for practical subjects should be appointed from among the teachers of the
department eligible as per University statute on rotation basis and no single teacher be
appointed for all the papers of a particular examination as far as possible.

15.

DISCIPLINARY ACTION AGAINSTUNFAIR MEANS IN EXAMINATIONS
A student adopting malpractice and/or showing any indiscipline behavior, violating
code of conduct [ Which includes: Use of programmable calculators, mobile phones(except the
paper in which it is asked to use such tools )/ smart watch (even in switch off mode), document
or any electronic devices having memory chips, leaving the Examination Hall within the first
hour from the commencement of the examination, talking to other examinees in the
Examination Hall, trying to give any help to others or trying to seek any help from others
inside or outside the Examination Hall, using question papers and/or answer scripts for
communicating with fellow examinee, exchange of question papers and answer scripts with
other examinees/outsiders, writing answers in question papers, writing obscene or filthy
languages in answer scripts, taking away the answer scripts or any examination
materials/papers to the outside of the examination hall without intimation/permission from the
concerned authority of the examination etc.]
a. Will be awarded “M” grade having 0(zero) Grade Point in the paper/papers concerned
and he/she will be warned by the University with a copy to the parents/guardians or a
notice in the official website of the University for the first offense.
b. For repeated offense as described above in subsequent semesterexaminations inspite of
the warning issued previously or grave misconduct despite warnings, he will be awarded
“M” grade having 0(zero) Grade Point in all the papers of that examination and will be
expelled from the college for one year.
c. Any student found man-handling/threatening the officers/staff connected with the
examinations (Invigilator, Centre Superintendent, Supervisors, Principal, Members of
Flying squad, etc.) will be awarded “M” grade having 0(zero) Grade Point in all the
papers of that Examination and will be expelled from the college for one year.Other
disciplinary actions as deemed fit as per the Odisha conduct of examination Act-1988
orUniversity first statute -1990 or IPC would be initiated by the University/college.

16.

RE-ADDITION/RE-CHECKING AND UN-EVALUATED PORTION:
16.1 A Student may apply through his/her college for Re-addition/Re-Checking of a paper within 15
calendar days from the date of publication of the results in each Semester. In case, there is any
answer left unvalued, the same will be placed before the Board of Conducting Examiners of the
respective subjects for valuation. The photocopy of answer scripts and information regarding readdition of marks will be intimated to the candidate within 45 days.
18 | P a g e

<!-- page 19 -->

16.2 There will be no re-evaluation processes of the answer scripts. However, in case of serious

irregularities in evaluation detected/pointed out, the answer book has to be placed before a
high level committee consisting of one member of the Examination Committee, one
member of Board of Conducting Examination. and one subject expert for assessment
provided the difference in marks claimed is more than 10% of total marks in the paper. .If
the new mark awarded by the high level committee is more than 5% of the total mark, the
new mark is to be accepted. The recommendation of high level committee will be accepted
under approval of the examination committee/Vice-Chancellor.
17.

GRADE SHEET:
At the end of 6 (six) Semester, a Grade sheet shall be made available to each student as per
Clause 8.1. However, if a student requires additional copies, he/she should apply through the
college with prescribed fees. Provisional Grade sheets for each semester will be sent to the
Colleges through online mechanism. The final Grade sheets for each semester along with
provisional certificate will be provided by the University at the end of the course i.e. after 6 th
Semester Examination.

18.

UNIVERSITY REGISTRATION CARD:
A student is issued University Registration Card at the time of admission. University
Registration number continues to be his/her Registration number for all examinations during
his/her tenure of study. This card is also essential for admission of the student to a college and
his/her eligibility to attend classes in a college. This is an IMPORTANT document and the
student must possess it throughout his/her course under the University.
In the event of a student losing his/her University Registration Card, he/she should
immediately lodge a FIR in the nearest Police Station. He/She should apply through the
College for issue of duplicate Registration Card with prescribed fee. The application form will
be made available in the University counter/website. The application form accompanying
thecopy of FIR and prescribed fee andrecommended by the concerned principal should be sent
to the Controller of Examination, of the concerned Universities by Speed Post/Registered Post.

19.

AUTONOMOUS COLLEGES:
All the Autonomous Colleges under different Universities will follow these regulations from
the admission session 2019-20 onwards. The Semester wise results of all Autonomous
Colleges will be prepared by their respective Controller of Examinations (as per this
regulation) and submitted to the University for approval of the Vice-Chancellor and
publication of results.

20.

PRINCIPLES FOR AWARD OF MEDALS:
The University shall award University Rank after taking in to account the aggregate
(including all subjects i.e. (core, DSE, AECC, SEC, GE) score of toppers in each Bachelor
Honours subject amongst all the affiliated colleges.The University shall preserve the script of
the final semester for all the toppers for nine months. Among these, whoever secures the
highest CGPA in aggregate shall be declared best Graduate under a stream (BA Hons./B.Sc.
Hons./B.Com. Hons.etc.)
Student transferred after 1st semester examination cannot be given position or
medal under autonomous colleges. Students who have been granted credit waiver under credit
transfer system can’t be awarded Gold medal or position.

20.1.

Eligibility for Award of Degree
19 | P a g e

<!-- page 20 -->

A candidate will be eligible for award of BA/B.Sc./B.Comdegree if he/she satisfies all the
following conditions:
a. Has cleared (minimum pass grade) in all subjects and obtained requisite number of credit
points in all Semester.
b. Has secured a minimum Cumulative Grade Point Average.
20.2.

Criteria for Award of Gold Medals

a.The best graduate / university gold medal winner will be selected based on the highest
Cumulative Grade Point Average secured by the graduate passing out in the academic year.
b. .For award of gold medal, more than one candidates may be declared Joint winner if they have
same CGPA.
c. Student appearing for Back/Improvement/Reappear Examination shall not be considered for
award of Gold Medal. This will not be applicable to the exemption given to students missing
examination due to participation in National/International events by officially representing the
State or the country.
d. Students who availed hard case benefitin any semester examination shall not be considered for
award of Gold Medal.
21.

COMMITTEE FOR CREDIT TRANSFER:
There should be a committee consisting of the following officials to consider all cases of credit
transfer:

1.
2.
3.
4.
5.
22.

Chairman, P.G. Council
Director, College Development Council
All Deans of Faculties of the University
Controller of Examinations
Deputy Controller of Examinations

-

Chairman
Member
Members
Member
Convener

RE-ADDITION OF MARKS AND PHOTO COPY OF ANSWER SCRIPTS:
22.1

A candidate desiring for re-addition of marks/photo copy of answer scripts may apply for
the same in the prescribed application form available in the college concerned with
application fees as applicable for re-addition of marks per paper and for photo copies of
answer scripts per paper within 15 days from the date of publication of the result. Here
publication means the date on which the result of the particular candidate has actually been
published.

22.2

All the Principals of the college are to provide prescribed application form of the
University to the students of their college downloading from the website of the concerned
Universities and receive the said application dully filled by the candidate with the
prescribed fee within 15 days from the date of publication of the result . After completion
of 15 days from the date of publication of the result, a list of applicants specifying
Sl.No./Roll No./Subject-Paper/Name of the valuation zone for re-addition/rechecking of
marks or obtaining photo copies of answer scripts must be prepared valuation zone/college
wise and the same list to be send to the controller of examination of the concerned
University along with the application fees received from the student as demand draft made
in favor of the Comptroller of Finance or through electronic transfer (as applicable) of the
concerned University within five days from the last date of receiving such applications.

22.3

All the Zone Supervisors of the concerned valuation zone colleges are required to keep all
the valued answer scripts of their zone for four months with them from the date of
publication of the concerned result and accept all the applications in prescribed forms for
20 | P a g e

<!-- page 21 -->

supply of photo copies/re-addition of marks from the concerned section of the University.
They must supply of photo copies/re-addition of marks and reply verifying the valued
answer scripts by the zone supervisor of their Colleges/valuation center to the controller of
examination of concerned University for compliance to the Principal of the concerned
college within two months after the receipt of application from the University.
22.4 All the Zone Supervisors will be provided 60% of amount as advance received from the
students. Any discrepancies detected during the re-addition of marks are to be brought to
the notice of the Controller of Examinations for revision of marks at University level. After
completion of four months from the date of publication of the result ,all the valued answer
scripts/list of application form for re-addition of marks/ obtaining photo copies of answer
scripts/bills vouchers thereof/balance amount to be submitted to the University (Balance
amount to be deposited as Bank Draft in favour of the Comptroller of Finance,of the
Universities or transferred to his account through e-transaction.No student shall be
entertained for any enquiry pertaining to the above process at the University level.
Any contingency/question arising out the Regulation or not covered under the above
Regulation shall be referred to the Controller of Examinations and decision shall be taken under
approval of the Vice-Chancellor.

Members of Regulation Framing Committee

21 | P a g e
