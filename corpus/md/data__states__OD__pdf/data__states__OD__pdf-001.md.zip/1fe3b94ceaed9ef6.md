---
doc_id: "1fe3b94ceaed9ef6"
source_url: "https://industries.odisha.gov.in/sites/default/files/2024-05/1086-%20OPERATIONAL%20GUIDELINES%20ON%20EXEMPTION%20FROM%20PAYMENT%20OF%20PREMIUM%20FOR%20CONVERSION%20OF%20LAND%20FOR%20INDUSTRIAL%20USE.pdf"
ministry: "Industries Department, Odisha"
title: "Download(601.69 KB)"
date: ""
pages: 13
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b6c58dc8a1baaa70"
---

<!-- page 1 -->

OPERATIONAL GUIDELINES ON
EXEMPTION FROM PAYMENT OF PREMIUM LEVIABLE FOR CONVERSION OF
LAND FOR INDUSTRIAL USE.
[Para 4. 5.1 (d) of IPR - 2022]
1. Short Title: - Operational guidelines on exemption from payment of premium
leviable for conversion of land for industrial use.
2. Extent: - It shall extend to the whole of the State of Odisha.
3. Commencement: - It shall come into force from the "Effective Date" of Industrial
Policy Resolution, 2022 i.e. 01.12.2022
4. Terms and Expressions: -Terms and expressions used in this operational
guideline, but not specifically defined here, shall have the same meaning as in
Industrial Policy Resolution, 2022.
5. Policy Provisions: -

Para- 4. 5.1 (d) of Industrial Policy Resolution, 2022
New industrial units in Priority and Thrust sectors and existing industrial units
in Priority and Thrust sectors taking up expansion/ modernization/ diversification
will be granted 100% exemption under the provisions of clause-C of Section-73 of
Orissa Land Reforms (OLR) Act, 1960 from payment of premium, leviable under
provisions of clause-C of Section 8(A) of the OLR Act 1960 on production of
eligibility certificate from the Director of Industries, Odisha for Large Industries and
Medium Enterprises and G.M, RIC/DIC for Micro and Small Enterprises.
6. Eligibility: 1. New Micro, Small & Medium Enterprises and Large Industries in

Priority and Thrust sectors
2. Migrated industrial unit in Priority and Thrust sectors treated as new
industrial unit.
3. Existing MSME or Large Industries in Priority and Thrust sectors taking
up expansion / modernization /diversification (EMO) as defined in IPR
4. Industrial unit, that has availed this incentive under any scheme of the
State Govt. or the Central Govt. or any Financial lnstitution(s), shall be
eligible for the differential amount of benefit only.
7. Time frame for filing application: I. Eligible Industrial unit shall file its claim complete in all respect, after
acknowledgement of EIN / letter of PEAL approval in case of new
MSME unit / Industrial Entrepreneurs' Memorandum (IEM)/ letter of
PEAL approval in case of new Large Industry and within the period of
implementation i.e. three years for Micro, Small & Medium Enterprises
and five years for Large Industries from date of first fixed capital
investment.

<!-- page 2 -->

2. In the delay in implementation of the project or submission of
application beyond the control of the entrepreneur may be condoned
on a case-to-case basis by an Empowered Committee.
8. Procedure: 1. Eligible industrial unit in Thrust or Priority sector claiming exemption
from payment of premium leviable for conversion of land for industrial
use shall submit application in the prescribed form appended to this
operational guideline at Annexure-'A' along with copies of all relevant
documents as mentioned in the Checklist at Annexure-'B' including
affidavit as mentioned in Annexure-B1 to the General Manager,
Regional Industries Centre I District Industries Centre in duplicate in
case of Large Industries & Medium Enterprises and in single in case of
Micro & Small Enterprises.
2. Copies of the documents as indicated in the checklist shall be self attested by Proprietor / Managing Partner / Managing Director /
Authorized Signatory.
3. On receipt of application with copies of relevant documents, the
acknowledgement as prescribed at Annexure-'C' shall be dispatched to
the applicant by the designated authority on the day of receipt. The
designated authority may authorize any of his officers for the purpose.
4. General Manager, RIC / DIC shall examine the eligibility, asses the
quantum of land to be utilized for industrial purpose and sign the
Certificate of verification prescribed at the bottom of the application and
in respect of Large Industries & Medium Enterprises transmit one set of
Application with copies of relevant documents to the Director of
Industries, Odisha within 3 days under intimation to industrial unit and
IPICOL.
a. In case of Micro & Small Enterprises, General Manager, RIC /
DIC shall examine the eligibility, sign the letter and Certificate of
verification prescribed at the bottom of the application and
recommend for exemption of premium for actual quantum of
land to be utilized for industrial purpose to the concerned
Tahsildar in the format as at Annexure -D under intimation to
industrial unit within 10 days of receipt of proposal.
b. Director of Industries, Odisha in case of Large Industries &
Medium Enterprises shall examine the eligibility and recommend
for exemption of premium for actual quantum of land to be
utilized for industrial purpose to the concerned Tahsildar in the
format as at Annexure -D under intimation to industrial unit &
IPICOL/RIC/DIC in case of Large Industries only within 15 days
of receipt of proposal from RIC /DIC.
c. The actual quantum of land to be utilized for industrial purpose
is to be assessed by RIC/DIC. The help of team from DI, Odisha
or/and IPICOL may be availed for actual land assessment.

<!-- page 3 -->

9. The amount of exemption (in INR) allowed may be intimated by concerned
Tahasildar to the concerned designated authority recommended for such
exemption.
10. Rejection:- In case of rejection of application at RIC / DIC / Director of
Industries, Odisha / Tahasildar concerned, the reasons of rejection shall be
communicated to the applicant unit by the concerned authority as early as possible
or within a maximum period of 25 days of receipt of application from the claimant
unit in the format prescribed at Annexure - ' E'.
11. Miscellaneous:11.1 RIC / DIC / Director of Industries, Odisha / Tahasildar may inspect the
industrial project site individually/ jointly, if felt necessary.
11 .2 The amount of exemption allowed shall be recoverable with penal
interest as decided by the authority on following eventsA. If the information furnished is found to be false/ incorrect / misleading or
mis-represented and there has been suppression of facts / materials or
allowed in excess of the amount actually admissible for whatsoever
reason.
B. If the industrial unit fails to commence production within three
years for Micro, Small & Medium Enterprises / five years for Large
Industries from the date of starting first fixed capital investment.

11.3 The delay in implementation of the project and/or submission of
application beyond the control of the entrepreneur may be condoned on a
case-to-case basis by an Empowered Committee.
11.4 Where any doubt arises regarding implementation of these rules, the
same shall be referred to Government of Odisha in the Industries Department
whose decision shall be final and binding on all the parties as envisaged
under Para 10 (e) of IPR-2022.

11.5 Time limit prescribed in this guideline is of working days only.
12. This has been concurred in by the Finance Department vide file No. FIN- ES2MISC-0002-2023.

<!-- page 4 -->

GOVERNMENT OF ODISHA
INDUSTRIES DEPARTMENT

****
Memo no.

t 0&6

/., Bhubaneswar Dated

IND-Hl2-GUID-0001-2022

1-\ 2., \~2.3"

Copy forwarded to All Departments/All Heads of Departments/ All PSUs/ All
Revenue Divisional Commissioners/All Collectors/ All DICs/AII RICs/ Head Portal
Group, IT centre, Secretariat, Bhubaneswar/ All Sections of Industries
Departments/Guard File for information and necessary action.

(1
Additional

--~').1

etaPy1"o Government.

0

<!-- page 5 -->

Annexure-A

APPLICATION FOR EXEMPTION FROM PAYMENT OF PREMIUM LEVIABLE FOR
CONVERSION OF LAND FOR INDUSTRIAL USE.
(Para 4. 5.1 (d) of IPR - 2022)
Application received incomplete in any respect shall be liable for rejection
(Strike out whichever is not applicable)

From :
M/s.
At
PO
Dist.
To

Sub:

General Manager,
Regional Industries Centre/ District Industries Centre-----Exemption from payment of premium leviable for conversion of land for
industrial use under the provisions of Industrial Policy Resolution, 2022.

Sir,
In accordance with the provisions laid down in Industrial Policy Resolution,
2022, its operational guidelines notified by Revenue & Disaster Management
Department, Government of Odisha, claim for exemption of premium leviable for
conversion of land for industrial use is submitted with following particulars.
1

Category of the Unit

..

New Micro / Small / Medium Enterprises / Large
Industries in Thrust or Priority Sector / Existing
Industrial units ( Micro / Small / Medium Enterprises
I Large Industries in Thrust or Priority Sector) taking
up Expansion / modernization / diversification.
2

Thrust Sector I Priority SectOi

3

Address of Registered office

4

Type of organization (Proprietorship / Partnership /
Co-operative / Private Limited / Public Limited)

5

Name of Proprietor/ Managing Partner I Managing
Director/ Authorized Signatory

..

<!-- page 6 -->

..

6

Date of first fixed capital investment i.e. land /
building / plant & machinery and balancing
equipment.

7

EIN /PC/ IEM & Production Certificate/ I L No.
and date/ PEAL approval Letter No date

8

Items of manufacture/ activity (Proposed/ Existing
/ E/M/D)

.
.. Item

Quantity

Value

(I)
(ii)
9

Proposed date of production / Date of Production

10

Proposed location & Present status of the Project

11

Name of the Financer with details of Loan applied
for / sanctioned / availed

12

Cost of the Project (New / Existing & E/M/D)

..

13 Area of Land required as per DPR / Project report
14 Area of Land acquired
15 Particulars of Land to be converted
Mouza

IKhata No

IPlot No

..

IArea

j Present Kisam

I, Sri _ _ _ _ _ _ s/o ____at present _ _ _ _ (designation) of M/S
_ _ _ _ _ certify that the information furnished as above is true and correct to
the best of my knowledge and belief.
I hereby undertake to abide by the terms and conditions prescribed under the
provisions of Industrial Policy 2022 and its operational guidelines
I hereby undertake that the industrial unit shall commence production within
stipulated time of three years for Micro, Small & Medium Enterprises / five years for
Large Industries from the date of starting first fixed capital investment.
I shall repay the amount of exemption allowed with penal interest as decided
by the authority1.

11.

If the information furnished is found to be false/ incorrect / misleading or misrepresented and there has been suppression of facts / materials or allowed in
excess of the amount actually admissible for whatsoever reason.
If the industrial unit fails to commence production within three years for three
years for Micro, Small & Medium Enterprises / five years for Large Industries
from the date of starting first fixed capital investment.

<!-- page 7 -->

Copies of relevant documents in support of information / facts furnished above
are enclosed here with.
Enclosure :1.

2.
DateSignature of the Proprietor/ Managing Partner/ Managing Director I
Authorized Signatory in full and on behalf of M/s--------------------PlaceCERTIFICATE OF VERIFICATION
Certified that the information furnished as above has duly been verified and
found correct. The captioned industrial Unit ie M/s -------------- At ---------- Po--------Dist---------- bearing EIN No---------- Dt------ / IEM No--------- Date ------------- is eligible
at avail exemption from payment of premium leviable for conversion of land for
industrial use under the provisions laid down at Para --------- of Industrial Policy
Resolution, 2022 at the extent of------------- Acres of Agricultural Land is being used
/ proposed to be used for industrial purpose.
General Manager,
RIC/ DIC-----------

<!-- page 8 -->

Annexure -8

CHECK LIST
Copies of documents to be attached with the application shall be self-attested by Proprietor/
Managing Partner/Managing Director/ Authorized Signatory
(Strike out whichever is not applicable)
1

Entrepreneurs Identification Number/ Production Certificate I IEM / Industrial License/ Letter on
PEAL approval

2

Power of Attorney / Board Resolution / Society Resolution, as applicable, while signing as
Partner I Managing Director/ Authorized person.

3

Certificate of registration under Indian Partnership Act1932 I Societies Registration Act- 1860 /
Certificate of incorporation (Memorandum of Association & Article of Association) under
Company Act-1956

4

Document in support of date of first investment in fixed capital of industrial unit i.e. land /
building / plant & machinery and balancing equipment

5

Provisional certificate on Priority Sector / Thrust Sector Status

6

Approved Detailed project report as approved by DSWCA / SLSWCA / HLCA

7

Appraisal & approval in support of expansion / modernization / diversification

8

Land document with land particulars to be converted for industrial use.

9

Valid statutory clearances / approvals / permissions for authorities including OSPCB, as
applicable

10

Undertaking on non-judicial Stamp Paper duly signed by the applicant in the format Annexure- 81.

<!-- page 9 -->

Annexure - 81

UNDERTAKING
(Strike out whichever is not applicable)

1. This is to certify that the information furnished in the application for availing
Exemption from payment of premium leviable for conversion of land for
industrial use under the provisions of Industrial Policy Resolution, 2022 are
true to the best of my / our knowledge & belief.
2. This is to certify that 1st . fixed capital investment in the new project/ for taking
up expansion / modernization I diversification of the existing industrial unit has
commenced on or after the effective date of IPR-2022 i.e. 01.12.2022.
3. The proposed new project / existing project taking up expansion /
modernization I diversification has duly been apprised and approved by---------

4.

Further, I / we undertake to repay the amount of premium exempted or any
part thereof with interest if,

A. The information furnished is found to be false I incorrect I misleading or missrepresented and there has been suppression of facts / materials I exempted in
excess of the amount actually admissible for whatsoever reason.
B. The unit does not qualify the definition of Expansion / Modernization /
Diversification as in Annexure-1, Definition & Interpretations of IPR- 2022.
C. The unit does not go into production within three years for Micro, Small &
Medium Enterprises/ five years for Large Industries from the date of starting
first fixed capital investment.
D. The industrial unit shifts its location without prior approval of RIC / DIC /
Director of Industries, Odisha / MSME Department/ Industries Department.

Place:
Date:
Signature of the Proprietor / Managing Partner I
Managing Director I Authorized Signatory in full
for and on behalf of

M/s ............ .

<!-- page 10 -->

Annexure-C
(FOR OFFICE USE)

OFFICE OF THE GENERAL MANAGER, RIC / DIC ----Letter No.---------------- I Date------------------

Acknowledgement
(To be issued on the day of receipt)
(Strike out whichever is not applicable)

To
Sri
------------M/ s.

------------

Received the application for ---------------------------------------------------------- under the
provisions of INDUSTRIAL POLICY RESOLUTION-2022 and its operational
guidelines along with documents mentioned below from M/s------------------ At/PO---------------Dist. _on dt. -----through post/ person.
List of documents
1.
2.
3.
Signature with seal & date---------Annexure-C
(TO BE DISPATCHED TO THE APPLICANT)

OFFICE OF THE GENERAL MANAGER, RIC/ DIC----Letter No.---------------- / Oate------------------

Acknowled g eme nt
(To be issuedon the day of receipt)
(Strike out whichever is not applicable)

To
Sri
------------M/ s.

------------

Received the application for ---------------------------------------------------------- under the
provisions of INDUSTRIAL POLICY RESOLUTION -2022 and its operational
guidelines along with documents mentioned below from M/s------------------ At/PO---------------Dist. _ on dt. -----through post/ person.
List of documents
1.
2.
3.
Signature with seal & date----------

<!-- page 11 -->

Annexure-D

OFFICE OF THE DIRECTOR OF INDUSTRIES, ODISHA / THE GENERAL
MANAGER, RIC/ DIC ----Letter No.---------------- I Date-----------------(Strike out whichever is not applicable)

CERTIFICATE
From:

To
The Tahsildar,

Sub:- Exemption from payment of premium leviable for conversion of land for industrial use
under the provisions of Industrial Policy Resolution, 2022.
Sir,
In accordance with the provisions laid down in Industrial Policy Resolution, 2022 and its
operational guidelines and Notification no.__ dated. _ _ _-of R & OM Department, I
recommend for exemption from payment of premium leviable for conversion of land for
industrial use-------------------- in favour of M/s ________, At ___ P.O. _ _ Dist._
bearing EIN /PC/ IEM / I L No._
date_/ PEAL approval L No._ date_. The particulars are
.
beow.
I
given
1 Category
New Micro / Small / Medium Enterprises / Large Industries under Thrust or Priority Sector/ Existing
Micro / Small / Medium Enterprises / Large Industries under Thrust or Priority Sector taking up
expansion , modernization and diversification

2

Priority Sector/Thrust Sector (Specify the Sector)

3 Address of Registered office
4
5

6

Type of organization (Proprietorship / Partnership / Co-operative / Private
Limited / Public Limited)
Name of Proprietor/ Managing Partner/ Managing Director I Authorized
Signatory
Detail Particulars of land to be converted for industrial use.

Mouza

I Khata No

I Plot No

I Area

Present Kisam

The amount of exemption (in INR) allowed may be intimated to the undersigned for record.
Yours faithfully,
Encl. As above. (Copy of Land Documents)
Director of Industries, Odisha /
General Manager, RIC/ DIC-----)

<!-- page 12 -->

Memo No. _ _ _ _/ dt.
Copy forwarded to Sri. _ _ M/s_ _ , At
information.

P.O ._ _

Dist. _ _ for

Director of Industries, Odisha /
General Manager, RIC/ DIC-----)
Memo No. - - - -/ dt.
Copy forwarded to the Managing Director, IPICOL, IPICOL HOUSE,
Bhubaneswar for favour of information.

Janpath,

Director of Industries, Odisha
I
General Manager, RIC/ DIC-----)

<!-- page 13 -->

Annexure-E
(Strike out whichever is not applicable)

OFFICE OF THE DIRECTOR OF INDUSTRIES, ODISHA, CUTTACK /THE
GENERAL MANAGER, RIC/ DIC----Letter No.----------------/ Date-----------------From:

To
Sri - - - - - M/s
-----------At - - - - - - - - -P.O. - - - - - Dist.- - - - - - - This is to inform that The application for exemption from payment of premium leviable for conversion of
land for industrial use under the provisions of Industrial Policy Resolution, 2022
made by
M /s _ _ _ _ _ _ bearing EIN / PC /IEM / IL No/ PEAL approval L
No. _ _ _ _ _ Dt_____ on dt._____ is rejected due to following
reasons.
(Specify the reasons)
1.

2.
3.

4.
(Signature)

1.
2.
3.
4.
5.
6.
7.

ABBREVIATIONS
IDCO- Odisha Industrial Infrastructure Development Corporation
DIC- District Industries Centre
RIC-- Regional Industries Centre
OLR-Orissa Land Reforms
PEAL- Project Evaluation and Allotment of Land
SLNA- State Level Nodal Agency
DLNA- District Level Nodal Agency
