---
doc_id: "88cc9d7a383eefaa"
source_url: "https://food.odisha.gov.in/sites/default/files/2020-03/corrigendum19693.pdf"
ministry: "Food Supplies and Consumer Welfare Department, Odisha"
title: "Download(111.83 KB)"
date: ""
pages: 1
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "9eba5d5dd0915047"
---

<!-- page 1 -->

ନଃ craft ୭୧୭
ତତ
ହେଃ (୦୭ 050 A Fax No.-0674-2395291
® ରା  ୧୮୦୩୧॥୦.-2393038
ଥେ ଏ ODISHA STATE CIVIL SUPPLIES CORPORATION LTD.,
‰) Plot No. C/2, Nayapalli, Bhubaneswar-751012
a (A Govt. of Odisha Undertaking)
Estt(Hdqrs.)-11/2018(Pt.2), No. 3 Date: ` /, | ' ର ୬୬.
Corrigendum
In continuation to this Advertisement No.-19693 dated-31.12.2019, this is to
inform that the column “Grade” shall be read as “Number of Post” instead of Grade
which is a typographical error.
ମହ୍‌”
| :'“ . ୬୫) ›
Managing Director
Memo No. 1 Date. ` |, |. ଯଆଣିାଂ
Copy forwarded to:-
1. The FA & CAO, OSCSC Ltd., Bhubaneswar for information and necessary
action.
2. The Company Secretary, OSCSC Ltd., Bhubaneswar for publication in the
websites.
) | , ୬୭୬୦
Managing Director
