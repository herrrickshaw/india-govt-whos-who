---
doc_id: "daa921ec7bdd66f9"
source_url: "https://coop.odisha.gov.in/sites/default/files/2021-12/sanction%20of%20funds.pdf"
ministry: "Co-operation Department, Odisha"
title: "Download(544.01 KB)"
date: ""
pages: 4
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "cd3dea6470a1bdd6"
---

<!-- page 1 -->

+ 77,775. ଓଃ Catan `.
Vn.
of bx \* \
| wie GODISH ^ STATE AGRICULTURAL MARKETING BOARD
5 . ଵ ୮) Plo 800 (P), Baramunda, Post-Khandagiri, Near Indian Oil Petrol Pump Bhubaneswar
22 A ଯ.ପଏ@0674-2351311, Fax: 0674-23513,16, Email: osamboard99@yahoo.com, Website: osamboard.org
“ ଥି ଅସ
%. ae 5 °
~OperbatteeNe OD aE - Dated :22:.3.08. 1!
——— Mkt-lll-1/2019-16
Te WO- ୬ ege

The Commissiqner-cum-Secretary to Govt., AY ଥ୍‌ I

Cooperation Department, Odisha
Sub: Proposal for sanction of funds under the scheme “Strengthening and Development of

Agricultural Marketing Infrastructure” for the year 2017-18, utilization of fund for up-

a gradation of e-NAM Mandis of the State
Aad ret Letter No.413, dated-02.06.2017 of Director Agricultural Marketing, Odisha.
5 Madam,

In inviting a kind reference to the letter on the subject, | am to submit that, proposal was
submitted for sanction of Rs.300.03 Lakhs under the scheme “Strengthening and Development of
Agricultural Marketing Infrastructure” for the year 2017-18 in favour of 06 nos. of RMCs as per the
list submitted in the letter under reference

In the meantime, 47 nos. of markets in the state are being proposed for coverage under e-
National Agriculture Market (e-NAM) platform of Govt. of India for online trading of agricultural
produce to provide remunerative price to the farmers. List of Mandis with commodities to be
traded in the proposed e-NAM Mandis is enclosed. Detailed DPR for the concerned Mandis is
being prepared for obtaining support from the Govt. of India for infrastructure and other support
admissible under the scheme. However, on receipt of login and passwords, pending approval of

ମନ୍ଦା DPRs for financial support from Gol, in order to immediately start e-NAM operations, those Mandis
\ 4} needs to be upgraded by creating / providing additional need based infrastructure like
ର
Ps computer/hardware, repair and renovation of required and setting up of assaying facilities to run
the e-NAM operation in the interest of farmer producers of the State

At this juncture, it is proposed that, the earmarked fund of Rs.300.03 lakhs may be
sanctioned and distributed equally among these 47 nos. of RMCs implementing the Gol
programme for up-gradation of facilities for e- NAM Mandis

| would therefore request you to kindly approve coverage of 47 additional Mandis under e-
NAM and reconsider the proposal submitted earlier for sanction amongst 47 nos. of RMCs /
Markets as per the list enclosed

Yours faithfully,
A
ଠା
W2\
- Member Secretary
Io 9, a OSAM Board, Bhubaneswar.
Memo No 5A / କି Date 2 3.4 2. ee

Copy forwarded to the Director of Agricultural Marketing, Odisha for information and

necessary action W
Member Secretary
OSAM Board, Bhubaneswar.

<!-- page 2 -->

Proposal for Sanction of funds under the Scheme "Strengthing & Development of Agricultural Marketing Infrastructure" for the
year 2017-18
Provision of Computers/ Hardwares for 47- Identified RMCs under eNAM Scheme
Item wise
anes . , Quantity Total . Cost Involved .
. ited Total Pi
SINo. Description of equipments/ materials Per RMCs | Quantity estimat te per each RMC otal Price
Unit Price
Desktop- Lenovo - (Core i3 (6th Gen)/4 GB
1 |DDR4/1 TB/Free DOS) (Black, 5.2 kg, 20 2 50000 100000 4700000
Inch Screen)
Laptop- HP 15, Core i5 7th Gen - (8 GB/1 TB
2 ` |HDO/Windows 10 Home/2 GB Graphics) 1 47 60000 60000 2820000
15g-br011TX Laptop
i 2") (EPSON, {- TM-
Laser Printer (Copy, Scan & Fax): HP Model: 1 47 28000 28000 1316000
U227fdw
|_5 [2 kVA Online UPS 3572000 [ %}୬©୬>.>*ˆ..‰%‹.‰`'. `. | ।
| 6 _ [Internet (Dongle) 259500 Including existing 10 RMCs under eNAM
40000 18800 [Od
| 8 jProjectorsereen Pata ୭୦ । ୩୭୦୦ ୭୪୨୦ [CSC~—SSCSCSCS
Total Costing 5938 | 3336. | 2566 | 5 ¬]
** Computers/ Hardware for 47 mandis @ Rs:3,33,000/- * 47 Mandis = Rs: 1,56,51,000/-
It is proposed to provide 30 nos. of dongle for 10 existing eNAM Mandi previously selected @Rs: 1500/- * 30 Dongle= Rs: 45000/-
2 nos. of dongle proposed to be used at OSAM Board for the purpose of eNAM work @Rs: 1500/- * 2 Dongle = Rs: 3000/-
Total Cost invioved for Computer & Hardware for selected eNAM mandis comes to Rs: 15699000/-
** Repair, Renovation & Setting up Assaying Lab for eNAM per each mandi (Max. Rs: 3,04,340/- )
** Repair, Renovation & Setting up Assaying Lab for eNAM per each mandi Rs: 3,04,340/- * 47 Mandis = Rs: 1,43,04,000/-
** Total Cost to be expended on 47 selected eNAM mandis = Rs: 1,56,99,000 + Rs: 1,43,04,000 = Rs: 3,00,03,000/-

<!-- page 3 -->

„>
¬ List of markets proposed to be integrated with eNAM
SI. | Name of the Name of the MY covered | Name ofthe | Name of the identified
No. District RMC under Gen / Market commodity to be
TSP treated under eNAM
1 | Balasore MMY, Balasore
Jaleswar Gen MMY, Jaleswar | Ground nut, Beetle
leaf,
Potato
2 । Bhadrak MMY, Bhadrak
Chandbali Gen MMY Sun flower
Chandbali
3 Cuttack Gen Ghasiput MY _ | Vegetable, Bengal
୩ କ୍‌ ଯୋ
Jagatsinghpur | Jagatsinghpur MMY, Green gram, Tomato
Jagatsinghpur
Cashew nut, Vegetable
Jajpur Gen MMY, Jajpur Black gram, Ground
nut
6 Kendrapada_ | Kendrapada MMY, Black gram, Jute,
Kendrapada Tomato
7 Khorda Balugaon MMY, Cashew nut, Green
_"" ଆ" "= ୩ ୩
୮୦ ati Gen ivy, ati
Puri Nimapara Gen MMY, Beetle leaf, Coconut
୨ ୩ ee ଖୋ ତ ।୩୦୧୩୩ ।
୬ ଜ୍ଞ [Anueut । Gen MMY, Angul Red gram, mango,
_ sweet potato
_ [  __ ଫ୍ାନଞା [Gen "| SMY, Bamur
10 Bolangir Bolangir Gen Bijakhamar Cotton
Sub MY
| | Patnagarh Gen MMY, Cotton, Pointed gourd
Joginanda
MMY, Attabira_| Pointed gourd
Baragarh Gen MMY, Tomato, ginger, brinjal
Padampur Gen MMY, Cabbage, tomato,
i ଜକ ନୁ ସମ ୩୩୦୭ ।
Deogarh Deogarh Gen Mohua Flower, W
MY Melon
13 Dhenkanal Dhenkanal Gen Mahisapato Mango, sweet potato
।” ୩ [Pret [er ଧା [Mone resent ।
| Gen Cashew nut, mango
MY
| Kamakhyanagar | Gen Jiramalli Sub Ground nut,
MY watermelon

<!-- page 4 -->

୯ ୭୭ ୮୮୨ PT
Keonjhar TSP Dhenkikote Mango, Tamarind,
ee ଯା ୩
Mayurbhanj MMY, Mohua flower,
Baripada vegitable
୮୦ ଖୋଖା । TSP MMY, Betnoti | Sabai grass,
watermelon
¦ tamarind
Joy (୩୫ | 5 MMY Udala
16 | Sonepur Biramaharajpur | Gen Bada Cotton
Sub MY
| Dunguripali |
Sambalpur
nut, watermelon
| | Sargipali TSP Kainsara Sub Tomato, Mohua flower
MY
Nuagaon Sub Mohua flower, sal
MY | seed, capsicum
Boudh
Pf Mohua flower ।
| 19 | Ganjam | Bhanjanagar_ Gen ୫୯୯୭ । Cashewnut ୦୦
} | T Digapahandi “Gen | Digapahandi [Cotton ¡``
| THinjticut [Gen Hinjlicut™ [Green gram
TSP Karlapada
୮ tunagarh ଓ୧୮ Uchhala
Po Gretta Ground nut
୧ କୋ ଓମ Utkela Cotton ୦୦୦
+ ଜଳ ାକଳା ` ‰ ୯୩ ଲ oer
Kandhamal
କାଚ
Baipariguda
a ବବଵ ର
Malkangiri | Ground nut
PRs (Titseed) ।
a ଯଯ ୦
LC ୪୮ Cashew nut
