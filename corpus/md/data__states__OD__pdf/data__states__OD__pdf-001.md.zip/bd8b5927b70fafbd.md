---
doc_id: "bd8b5927b70fafbd"
source_url: "https://www.bput.ac.in/old-site/documents/bput_1522563492.pdf"
ministry: "Biju Patnaik University of Technology (BPUT), Odisha"
title: "Caution Against Fake Digitally Managed Forged & Fabricated Notification Regarding Even Semester Examinations 2017-18."
date: ""
pages: 1
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "09ca041fe48506bd"
---

<!-- page 1 -->

BIJL PATNAIK UNIVERSITY OF TECHNOLOGY, ODISHA
os, ROURKELA :
No. BPUT/ Exam /1590/ 18
Date 01.04.2018
PUBLIC NOTICE
CAUTION FAKE, DIGITALLY MANAGED. FORGED. & FABRICATED NOTIFICATION
± has come to the notice of the university authorities that a notification relating to Even
Semester Examination (Regular & Back) 2017-18 is being circulated in the electronic media [What's
App]. Such notice bears the No BPUT / EXAM / 21125 / 2018 date 31.03.2018, is not signed and it
has not been published by the Biju Patnaik University of Technology, Odisha, Rourkela. This
notification is fake, forged, fabricated and the handiwork of unscrupulous elements and an attempt
to disrupt the smooth conduct of ongoing even semester examinations as per schedule notified by
the University
All University examinations of 02.04.2018 and thereafter shall be conducted (୬3 per
schedule notified earlier.
notification (s) from university web portal www.bput.2c.in only and cautioned not to be misied by
dle
Memo No. 1591/2018 Date 01.04.2018
Copy to: ‘All Principal / Director (s) of Constituent and Affiliated Colleges | Centre
Superintendents of Even Semester Examinations: 2017-18 for information and
| "୯ ୮୬ «Alte
Memo No. 1592/ 2018 Date 01.04.2018
Copy to: ‘OSD to Hon'ble Vice Chancellor / Registrar | Dy. Director Examination (s) / JE-
Examination- General | Information Officer | e-Examination Cell and e-Notice Board-
University Web Portal for information and necessary action and record. 37
.
