---
doc_id: "0debfad3c86f0bf6"
source_url: "https://fard.odisha.gov.in/sites/default/files/2023-10/guidelines%20for%20fodder%20development%20for%20fy%202023-24.PDF"
ministry: "Fisheries and Animal Resources Development Department, Odisha"
title: "Download"
date: ""
pages: 25
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "93358afa3dbae045"
---

<!-- page 1 -->

GOVERNMENT OF ODISHA
FISHERIES & ARD DEPARTMENT
॥୦. [OPC ` / ମନନ, ot 31-F+23
File No. FARD-VP-3VP-0016-2023
From
Shri Gangadhar Nayak, OAS (S.S)
Special Secretary to Govt.
To
The Director, AH & VS, Odisha, Cuttack
Sub:- Guidelines for implementation of the State Sector Scheme" Fodder
Development" for the year 2023-24.
Sir
| am directed to enclose herewith the copy of the approved guidelines for
implementation of the State Sector Scheme" Fodder Development" for the year 2023-24 ,
for taking necessary action at your end.
Yours te
APF
Special Secretary to Govt.
Memo Nol 9 67 jearo, ot_ 2! F223
Copy forwarded to the Finance Section, F & ARD Department for infor mation.
Ne 4 iad
Special Secretary to Govt.

<!-- page 2 -->

GUIDELINE FOR IMPLEMENTATION OF THE
PROGRAMME ON BACKYARD AZOLLA CULTIVATION
BY WOMEN FARMERS FOR LIVESTOCK
CONSUMPTION - 2023-24
UNDER STATE SECTOR PLAN PROGRAMME SCHEME
“FODDER DEVELOPMENT”
DIRECTORATE OF ANIMAL HUSBANDRY AND
VETERINARY SERVICES, ODISHA, MANGALABAG,
| CUTTACK.

<!-- page 3 -->

` Programme details of Azolla Cultivation Programme during 2023-24

Azolla Cultivation Programme involving women Dairy in the entire state covering
all 314 blocks (6794 Gram Panchayats) of the State will be taken up.
I. During 2023-24, 3140 units of cemented Azolla units to be established Detail of
target for each district is enclosed herewith at ANNEXTURE- I.
Il. This programme is to produce Azolla in their backyard for feeding the animals to
increase the profit margin on milk production by reducing the consumption of the
concentrate feed.
Ill. One farming family will be assisted with one Azolla unit for larger coverage and that
will serve as a source of Azolla Seed Culture unit for the other interested farmers of that
locality in future.
IV. The establishment cost of one cemented Azolla Unit is Rs.3000/- and it is a
onetime back ended assistance to the farmer.
Modes of operandi for Azolla cultivation programme

e Azolla Cultivation Programme is targeted for the women dairy farmers having at
least 2 lactating large animals and each farming household will be assisted
with one no of Azolla production unit.

e It will be implemented in all blocks and Gram Panchayats of the district.

+ The BVO will select the women farmer in consultation with the Para-Vet/LI of the
locality for implementation of the programme.

* The selected beneficiary list of the block on submission by BVO to be scrutinized
& approved by the District level fodder development committee under the
Chairmanship of CDVO prior to release of input/funds.

e The beneficiary selected in the district should be communicated to the
Directorate (both hard & soft copy) in the prescribed proforma enclosed herewith
annexed at ANNEXTURE-II. ”

e The Go-ahead letters to the selected women farmers to be issued by the CDVOs.

e The detail & elaborate Azolla pit structure, with Azolla production method and
feeding practice as a leaf-let written in ‘ODIA’ must be enclosed with the Go-
ahead letter.

e The farmer to be advised to report the local Veterinary Officer/ LI regarding
completion of the civil construction within the stipulated time mentioned in the
Go-ahead letter. Then she will arrange all other required inputs (as described in
the leaf let) for starting the production of Azolla.

+ The demonstration on the Azolla cultivation will be the responsibility of the local
LI with the assistance of the fodder staff posted at CDVO/ SDVO offices.

e The Utilization Certificate on completion of the programme may be sent to the
Directorate by the CDVO. 0

<!-- page 4 -->

ANNEXURE - I
DISTRICT WISE TARGET OF AZOLLA UNITS AND CORRESPONDING BUDGET
PROVISION UNDER THE STATE SECTOR SCHEME DURING THE YEAR 2023-24,
୮5, |Name of the|No. of] No. of | No. of cemented Azolla unit Fund allocation |
୧୯୩ District blocks GP | ୩୩୧୨ for 2023-24 _ © Rs.3000/- per |
| Gen| SC ST] Total| Unit (Rs. 11 |
L- _ _|  _ | -.- 1404 __. .
2. _ | Balasore 12 356 ¦ 99 28 | 38 ¦ 165 | __ _. _4,95 ¦
୫୮ Bargarh 353 | 70 120 27 | 117 | 3.51)
(4. [Bhadrak ୨୧ 1॥। 61 101 | 3.03 '
5. 317 | 88 34 __ 4.41]
6._|Boudh 32 _ _ ` 0.
8. _ 000881) ` 70 ots _7 | 32 [0.96 :
9. _| Dhenkanal 8 212 | 58 | 17 | 23 | 98 | 2.4
10. | Gajapati 41 16 | 69 | 2.07.
11, [Ganjam 139 140 53 | 232 | 6. |
!2. [Jagatsinghpur| ® [168 | ¬ 16 | 21 | 92 | 2.76, |
13, [vapor ` 10 | 311 | 87 | 24 | 33 | 14 | 432
4. 78 122 [6 | 8 36 _ ' ` ` 108 ।
| 15. _[Kalahandi 13 | 310 | 86 | 24 33 | 143 | 4.29)
|16._| Kandhamal 12 ` 1 171 | 47 ` | 13. 19 | 79 ft == =: ୮
| 17. | Kendrapara 9 249 | 69 | 20 | 26 | 115 | _ 3.45 |
| ୮18, ` Keonjhar 13 | 297 82 | 23 | 32 | 1397 | 4.1),
| 19. | Khordha 190 | 53 | 15 | 20] 88 | 2.64
| 20. [Koraput 6 ¬ 19 126 | il | 3.33!’
| (a1. [Malkangis | 7 [| ri | 30 [9 [ 12 | 51 __ _ 1.53 ¦
| 93. [Nabarangapur[ 10 _ | 189 | 52 20 587 |... 261)
2୭ [Nayagarh [| 8 | 194 | s4 | ts [ 21 [90 1 2.70.
| bas Nuapada 36 _ | 10 | 15 | 61 | 188
। ଓ ମଯ 28 75 1228 12 1 ` 372 `
27. | Rayagada is. 25 | 14] 20 | 84 282 |
| (28, |Sambalpur__| 9 | 138 | 38 | 11 | 15 64 07 «92
। ।୮2୨୩୩॥୮୭୮୭୮୩୮ । 6 | 109 | 30 ୩ । i ¬ 0 5555 1.50'
[30._| Sundargarh 279 76 _ 22 30 1128 ୮" a8
7601, | 314 | 6795. 1881 |534 725| 3140 ___94.20
(Rupees Ninety four lakh twenty thousand) only
Dy. \y> Additional Director (LD)
\t Cy
: a

<!-- page 5 -->

(
Annexure-II
FORMAT FOR SUBMISSION OF BENEFICIARY LIST FOR BACKYARD AZOLLA CULTIVATION PROGRAMME 2023-24
Sl. |Name ofthe | Address | Adhhar Contact Bank details ; Category Go-ahead
women Village No. No. (Put a ‘tic’ Mark in letter issued
farmer P.O. the right category
G.P = Name of the Bank b=] ୦ ୩ ( “= ଓ
Fi (`
Block "Branch E a a ଞ୍ଚ ଦର
„ A/c 710 ରମ 5 sf
„ IFS Code ୪ # a
A
District Fodder Officer ADVO (LP/ AW) Chief District Veterinary officer
lu
ee

<!-- page 6 -->

DIAGRAM OF CEMENTED AZOLLA PIT
ଏ 6 feet —__________»
*NB: The structure should be so constructed that there should not be any seepage of
water.
a
^

<!-- page 7 -->

GUIDELINE FOR SEASONAL FODDER CULTIVATION IN
FARMERS FIELD DURING KHARIF/ RABI SEASON
| 2023-24
UNDER STATE SECTOR SCHEME
“FODDER DEVELOPMENT”
DIRECTORATE OF ANIMAL HUSBANDRY AND
VETERINARY SERVICES, ODISHA, MANGALABAG,
CUTTACK.

<!-- page 8 -->

. This guideline is being issued for implementation of seasonal fodder minikit
~ demonstration programme during Kharif/ Rabi season 2023-24 under State sector
scheme- “Fodder Development”.
Programme details of Seasonal fodder minikit demonstration programme during
2023-24
It is proposed to take up seasonal fodder cultivation programme in the entire
state covering 30 districts through distribution of Fodder Seed Minikits both in Kharif &
Rabi Season.
I. During Kharif 2023-24, 30000 Nos. of minikits are to be supplied to the selected
farmer/ beneficiaries.
Il. During Rabi season 2023-24, 10000 Nos. of minikits to be supplied to the selected
farmer/ beneficiaries.

Ill. The minikits will be procured from Govt. approved seed supplier/ Own farm
produced fodder seed and distributed to the dairy farmers of each block selected by
BVO and Livestock Inspector and duly approved by District Level Fodder
Development Committee under the Chairmanship of the Chief District Veterinary
Officer.

| Ill. One farmer can be provided at least one minikit covering an area of 0.25 acre anda
maximum upto 20 minikits covering an area of 5.00 acres.

The Kharif season each minikit contains the seeds of Maize (AT), Cowpea (EC-4216).
The Rabi season minikits contain the seeds of Oats (Kent), Berseem (Mascavi)
Operational guideline for the programme in the Farmers field

* Each Fodder seed minikit for Kharif season minikit (comprises of 3 Kg. of Maize
(AT) 120 & 1 Kg. of Cowpea (EC-4216) 1 pkt ) while the Rabi season minikit
(comprises of 3 Kg. Oats (Kent) seed- 1 pkt. and 1 Kg. Berseem (Mascavi) seed - 1
pkt.) will be supplied to the farmer free of cost for cultivation of seasonal fodder
crop with a maximum limit of 20 kits covering an area over 5 acres.

e During selection of beneficiary MPCS members, Fodder Cooperative members,
SHG/ NMPS/ CAE/ DEDS/ MKUY/ Goshala to be considered, besides SC, ST
and Women farmers should be given preference for selection of beneficiary.

e During selection of beneficiary the no. of beneficiary targeted under each category
must be selected and under every category, 33% women farmers are certainly
included. If the special drive beneficiaries are not available then the left over
target under that particular category may be diverted for the general category
maintaining the 2/3": 1/3'4 proportion with male and female farmers |
respectively. ;

* The approved list of beneficiaries should be communicated to the Directorate
(both hard & soft copy) as per the proforma enclosed at ANNEXURE - II.

e Each beneficiary may be provided with at least one no. of minikit to maximum 20
nos of minikit for fodder cultivation over 0.25 Ac to 5.00 Ac as each kit covers an
area of 0.25 Ac.

lu)

<!-- page 9 -->

। କୁ
। LEE ———— = -"

+ Inclusion of Farm Pond Plus beneficiary to be taken in a priority basis

* The fodder cultivation in farmers’ field should be Geo-tagged for documentation.

* At least 5 No of crop cuttings per variety over 1sq meter area can be taken from
the farmers’ field to obtain the average green fodder yield over 1 Ac area.

* Each beneficiary must be provided with leaflet in ‘Odia’ on methodology of
seasonal fodder cultivation.

* For timely distribution of the minikits to the farmers door step with in the
district, Preparation of leaflet and transportation of the minikits from the district
level storage points to the farmers door step the requisite funds @ Rs 15/- per
minikit will be allotted shortly. ଛି

* Similarly for preparation of fodder seed minikit produced at own farm and its
transportation to the district HQ storage points Rs.25/- for each kit to be
provided to the concerned fodder seed farm and Rs.15/- will be allotted to the
respective CDVOs for internal distribution of fodder seed minikits.

| Procurement and distribution Plan of Fodder minikits:

1, The Fodder seed minikits will be supplied to respective district headquarters from
the Directorate & departmental fodder sced production farms.

2. From District Headquarter the minikits is to be supplied to the farmers’ field
through the concerned BVOs for which Rs 15/- per Minikit will be allocated to
the concerned CDVOs for logistic charges towards internal distribution within the
district, preparation of leaflet on package of practices of seasonal fodder crops & °
documentation charges etc.

District wise diversion list of fodder seed minikit is enclosed for reference at
ANNEXURE - I
District wise and category wise target for selection of beneficiaries is attached in `
ANNEXURE - Il
YV 36! ୮୫୫୬
Gal
Dy. Additional eho {LD) .
Wry (|
1

<!-- page 10 -->

ANNEXRUE - | ¥
District wise target of Minikit and fund allocation for transportation of minikits for Seasonal Fodder Cultivation during the year 2023-24
Budget allocation for leaf let preparation &
No. of transportation of minikits from District storage
| ୦୮ ଓ Gr block Rabi Total eae to farmers door step @ Rs.15/- per Fs
__ (In Rs.)
at + 331 19875
2 356 1573 523 31440
ର ଏ ଓଲା 7 ୭୨୫୪ ୨୧୦୧ 320 | 1283
6 [Boudh ଓ 9୧ ଉଇ ton | tos PO ୦୭୦
୫ |Deogarh ଓ 0309 Pts sae ସୁ ୨୦
। ୨ | Dhenkanal | 8 212 | 36 Pa fam 87200 |
7
Ganjam 22
+ Re —fiesersngheur [a ±: age °''
458
14__| sharsuguda 5 78
15 ` | Kalahandi _ 13 310 _ 456. 27375
16 ` | Kandhamal 12 755 ___ 252 1007 — 15105
|_17_|Kendrapara | ଠଠ ୬4୩୨ ।୯୦୨୨ 366 21975
13 | 297 1311 1749
10 | 130 839 280 19 16785
240 353 1413 | 21195
Malkangiri ସ୍‌ eet 654
Mayurbhanj 26 2379 | 35685
_ 23 1113 | 16695
୦4 [Nayagarh | | aa a7 285.
193 771
[26 [Pui ଏକ ଓଃ ।।୫ ସୁ ୮୮୦ ଓ3670
28 | Sambalpur p 9 | ass | ରେ 2002 ଏ 80 |
29 | Subarnapur_— ୧ | 09 | asa | ୮ | waz 8880 |
[30 | Sundargarh ।୮ | 279 | aga | aa | toa | 2660 |
