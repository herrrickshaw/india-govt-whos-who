---
doc_id: "a02cbe60d8e53adc"
source_url: "https://bhubaneswarcuttackpolice.gov.in/wp-content/uploads/2025/11/3250-CP-Traffic-Dt.24.11.2025_compressed.pdf"
ministry: "Police Commissionerate, Bhubaneswar-Cuttack, Odisha"
title: "Promulgation of Order U/s- 28 & 29 of OUP Act."
date: ""
pages: 4
method: "tesseract:ori+eng"
script: "ORIYA"
needs_ocr: false
sha1: "97803a1ca5e15295"
---

<!-- page 1 -->

ପୋଲିସ କମିଶନରେଟୁ
ଭୁବନେଶ୍ବର-କଟକ
ଭୁବନେଶ୍ବର
ଅଦେଶ ସଂଖ୍ଯା: ୩୨୭୫ ଅ/ିପି-ଟ୍ରାଫିକ୍‌ ତାରିଖ: ST /୧୧/୨୦୨୫
=< < =
ଓଡିଶା ଅର୍ବାନ ପୋଲିସ (୦)୮) ଆଇନର ଧାରା ୨୮ ଏବଂ ୨୯
ଅନୁଯାୟୀ ଆଦେଶର ପ୍ରଣୟନ
+*#8%+
ଏହା ଦେଖାଯାଇଛି ଯେ, ଭୁବନେଶ୍ବର ସହରର ବିଭିନ୍ନ ପ୍ରମୁଖ ରାସ୍ତାରେ ଯାନବାହାନର
ଅନିୟମିତ ପାର୍କିଂ ଯାନବାହନ ଚଳାଚଳରେ ବାଧା ସୃଷ୍ଟି କରୁଛି, ଯାହା ଫଳରେ ଭିଡ଼, ଯାତୀମାନଙୁ ଅସୁବିଧା
ଏବଂ AMINE TAK ପ୍ରତି ସମ୍ଭାବ୍ୟ ବିପଦ ସୃଷ୍ଟି ହେଉଛି।
ଭୁବନେଶ୍ବରରେ ସୁନିୟନ୍ତ୍ରିତ ଟ୍ରାଫିକ୍‌ ପରିଚାଳନା ଏବଂ ଯାତ୍ରୀ ମାନଙ୍କ ସୁରକ୍ଷା କୁ ଦୃଷ୍ଟିରେ
ରଖ୍‌ , ଏବଂ ଓଡ଼ିଶା ସହରାଞ୍ଚଳ ପୋଲିସ ଆଇନ, ୨୦୦୩ ର ଧାରା ୨୮ ଏବଂ ୨୯, (ଓଡ଼ିଶା ଆଇନ ୨୦୦୭
ର ଧାରା ୮), ଭୁବନେଶ୍ବର-କଟକ ପୋଲିସ କମିଶନରେଟ (ଟାଫିକ୍‌ ଏବଂ ସାର୍ବଜନୀନ ଶୃଖଳା) ନିୟମାବଳୀ,
୨୦୦୮ ର ନିୟମାବଳୀ ୧୯ ଏବଂ ୨୧ ଏବଂ ଭାରତୀୟ ନାଗରିକ ସୁରକ୍ଷା ସଂହିତା (BNSS), ୨୦୨୩ ର ଧାରା
୧୬୩ ଅନ୍ତର୍ଗତ କ୍ଷମତା ବ୍ୟବହାର କରି, ମୁଁ EQA ଏସ୍‌.ଦେବ ଦଉ ସିଂହ, (ଭା . ପୋ . ସେ .), ଆରକ୍ଷୀ
ଆୟୁକ୍ତ ଭୁବନେଶ୍ବର-କଟକ, ଲିଖୂତ ଆଦେଶରେ ଜନସାଧାରଣଙ୍କୁ ଜଣାଇ ଦେଉଛି ଯେ ନିମ୍ନଲିଖୁତ
ରାସ୍ତାରେ ଯାନବାହନ ପାର୍କିଂ ନିଷେଧ କରାଯାଇଅଛି:
୧. ` ରାଜଭବନ ଛକ ରୁ ଜୟଦେବ ବିହାର ଛକ ଦେଇ କଳାରାହାଙ୍ଗ। ଛକ |
୨. ଏୟାରପୋର୍ଟ ରୁ ଆଚାର୍ଯ୍ୟ ବିହାର ଛକ ଦେଇ ନାଲକୋ ଛକ |
୩. ` ଶିଶୁଭବନ ଛକ ରୁ ରାଜମହଲ ଛକ ଏବଂ ମାଷ୍ଟର SUA SS ଦେଇ ବାଣୀବିହାର ଛକ |
୪. ରଶୁଲଗଡ଼ ଛକ ରୁ ଜୟଦେବ ବିହାର।
୫. ଶ୍ରୀୟା ଛକ ରୁ ପିଏଚଡି ଅଫିସ।
୬୭୬. ବାପୁଜୀ ନଗର।
୭. ଆଇଡିବିଆଇ ବ୍ୟାଙ୍କ ଛକ ଠାରୁ ଏମାୟାର ହୋଟେଲ ଦେଇ ଏନଏଟ-୧୬ |
୮. ` ଆଲୋକ ଭାରତୀ ବିଲ୍ଲିଂ ଠାରୁ ଶହୀଦ ନଗର ଦୁର୍ଗା ପୂଜା ମଣ୍ଡପ, ଜନପଥ ରୋଡ |
୯. ଜନପଥ (କଲ୍ୟାଣ Grad) ଠାରୁ ସ୍ପର୍ଶ ହସ୍ପିଟାଲ ଚରକ ମେଡିକାଲ ଷ୍ଟୋର |
୧୦. FG ସର୍ଭିସ ଷ୍ଟେସନ ଜନପଥ ଠାରୁ ଶହୀଦ ନଗର ଏଣ୍ଟ୍ରି ପଏଣ୍ଟ |

<!-- page 2 -->

ଯି _ ବ୍ୟବସାୟ କେନ୍ଦ୍ର, ଶିକ୍ଷାନୃଷ୍ଠାନଂ ହସ୍ପିଟାଲ ଏବଂ ଯାନବାହାନ ଯାତାୟାତର ବୃଦ୍ିକୁ ଦୃଷ୍ଟିରେ
AL, IEAES ଟ୍ରାଫିକ୍‌ ପରିଚାଳନା ଏବଂ ଜନସାଧାରଣଙ୍କ ସୁରକ୍ଷା ନିମନ୍ତେ , ନିମ୍ନଲିଖୂତ ରାସ୍ତାଗୁଡ଼ିକରେ
ପାକିଂ ନିଷେଧ କରାଯାଉଛି:
୧. ଗୋପବନ୍ଧୁ ଛକ ଠାରୁ କଳ୍ପନା ଛକ (ଉଭୟ ପାର୍ଶ୍ଵ) |
୨.  କଳାରାହାଙ୍ଗା ଛକ ଠାରୁ ନନ୍ଦନକାନନ ଛକ (ଉଭୟ ପାର୍ଶ୍ଵ) |
୩. ଉଭୟ ପାର୍ଶ୍ଵ ଯର୍ଭିୟ ରୋଡ଼ ଦେଇ ଜୟଦେବ ବିହାର ଛକ ଠାରୁ ତମାଣ୍ଡୋ ଛକ |
୪. ` ଜୟଦେବ ବିହାର ଛକ ଠାରୁ ଏକାମ୍ର କାନନ ପାର୍କ ରୋଡ଼ (ଉଭୟ Ald) ଦେଇ ସି.ଆର.ପି
ଛକ ।
୫. ` ସିଆରପି ଛକ ଠାରୁ ୟୁନିଟ - ୮, ଡି.ଏ.ଭି. QM (ଉଭୟ Ald) 6ea ପାଏଁର ହାଉସ୍‌ ଛକ |
୬. ଫାୟାର ଷ୍ଟେସନ ଛକ ଠାରୁ ସିଟି ମହିଳା ମହାବିଦ୍ୟାଳୟ ଛକ (ଉଭୟ ପାର୍ଶ୍ଵ) ଦେଇ
ଜାଗମରା ଛକ ।
୭. ଖଣ୍ତଗିରି ଛକ ଠାରୁ ପୋଖରୀପୁଟ ଛକ (ଉଭୟ ପାର୍ଶ୍ଵ) |
୮. FAIA ଅଣ୍ତର ପାସ ଠାରୁ ଆଇଡି ମାର୍କେଟ (ଉଭୟ ପାର୍ଶ୍ବ) ଦେଇ ଜୟଦେବ ବିହାର |
୯. ` କୀଟ ଛକ ଠାରୁ ସିଲିକନ ଇଞ୍ଜନିୟରିଂ କଲେଜ (ଉଭୟ ପାର୍ଶୃ) ଦେଇ ଇନଫୋସିଟି ଛକ |
Co, ଡମଣା ଛକ ଠାରୁ ଶୈଳଶ୍ରୀ ବିହାର (ଉଭୟ ପାର୍ଶ୍ଵ) |
୧୧.  ଜାଭିୟର ଛକ ଠାରୁ ଉକ୍ଳ SICIM (ଉଭୟ Ald) ଦେଇ ସାଇ ମନ୍ଦିର ଛକ |
ଏହି ଆଦେଶର QFE ମୋଟର ଯାନ (ସଂଶୋଧନ) ଆଇନ, ୨୦୧୯ ର ଧାରା ୧୭୭
ଏବଂ ଭାରତୀୟ ନ୍ୟାୟ ସଂହିତା, ୨୦୨୩ ର ଧାରା - ୨୨୩(ଖ) ଅନୁଯାୟୀ ଏକ ଦଣ୍ରନୀୟ ଅପରାଧ ଅଟେ |
ଏହା ବ୍ୟତୀତ ମୋଟର ଯାନ ଆଇନ-୧୯୮୮ ର ଧାରା-୧୨୭ ଅନୁଯାୟୀ ଉପରୋକ୍ତ
ଆଦେଶର ଉଜ୍ଲଂଘନ କରୁଥୁବା ଯାନବାହନଗୁଡ଼ିକୁ କ୍ରେନ ସାହାଯ୍ୟରେ ଟାଣିନିଆଯିବ ଏବଂ ସେହି
ଯାନବାହନର ମାଲିକ ଜୋରିମନା ବ୍ୟତୀତ କ୍ରେନ ବବାଦକୁ ଖର୍ଚ୍ଚ ଅଲଗା ଭାବେ ପଇଠ କରିବେ ।
ଉପରୋକ୍ତ ଆଦେ ଶଟି ପ୍ରଖ୍ୟାପନ ହେବା ତାରିଖରୁ ଅନ୍ୟାଦେଶ ପର୍ଯ୍ୟନ୍ତ ବଳବତ୍ତର ରହିବ।
ଏନଂ 9G, LB of
(ଡକ୍ଟର ଏସ୍‌.ଦେବ ଦଉ ସିଂହ, ଭା.ଫୌଁ.ସେ.)
ଆରକ୍ଷୀ ଆୟୁକ୍ତ,
ଭୁବନେଶ୍ବର-କଟକ |

<!-- page 3 -->

7882)
POLICE COMMISSIONERATE
BHUBANESWAR-CUTTACK
BHUBANESWAR
ORDER No. 3250 /CP-Traffic Date. 24 1/11/2025
Promulgation of Order U/s- 28 & 29 of OUP Act

Whereas, it has been observed that indiscriminate parking of vehicles on
various major roads of Bhubaneswar city is causing obstruction to the free flow of traffic,
leading to congestion and inconvenience to commuters, and poses potential hazards to
public safety.

And whereas, it is deemed necessary to regulate parking in the larger
interest of smooth traffic movement and enhance commuter safety in Bhubaneswar,
and in exercise of the powers vested under Sections 28 and 29 of the Odisha Urban
Police Act, 2003 (Odisha Act 8 of 2007), read with Regulations 19 and 21 of the
Bhubaneswar—Cuttack Police Commissionerate (Traffic & Public Order) Regulation,
2008, and U/s 163 of Bharatiya Nagarik Suraksha Sanhita (BNSS), 2023, | Dr. S.Dev
Datta Singh, IPS, Commissioner of Police, Bhubaneswar-Cuttack, do hereby order that
parking of vehicles will continue to be prohibited on the following stretches of road.
¥ Raj Bhawan Square to Kalarahanga Chhak via Jaydev Vihar.

2. Airport to NALCO Chhak via Acharya Vihar.
3: Sishubhawan Chhak to Vanivihar via Rajmahal Square and Master

Canteen Square.

4. Rasulgarh Chhak to Jaydev Vihar.

5. Sriya Chhak to PHD Office.

6. Bapuji Nagar.

i. IDBI Bank Square to Veterinary College, NH-16 via Empire Hotel.

8. Alok Bharati Building to Saheed Nagar Durga Puja Mandap at Janpath.
9. Janpath (Kalyan Jewelers) to Charak Medical Store via Sparsh Hospital.
10. Trupti Service Station of Janpath to Saheed Nagar Entry Point.

And whereas, many growing business hubs, educational institutions,
hospitals, have led to increasing volume of vehicular traffic, and in order to ensure the
free flow of traffic and safeguard public safety, parking of vehicles is strictly
prohibited on the following roads.

1) Gopabandhu Square to Kalpana Square (both sides).

2) Kalarahanga Chhak to Nanadankanan Square (both sides).

3) Service road on both sides from Jaydev Vihar to Tamando Square.

4) Jaydev Vihar to CRP Square via Ekamra Kanan Park road.

5) CRP Square to Power House Square via Unit-VIII, DAV School (both
sides).

<!-- page 4 -->

6) Fire Station to Jagamara Sqaure via City Womens College Square (both

sides).

7) Khandagiri Square to Pokhariput Square (both sides).

8) Nayapalli U/P towards Jaydev Vihar via ID Market (both sides).

9) KIIT Square to Infocity Square via Silicon Engineering College (both
sides).

10) Damana Square to Sailashree Vihar (both sides).

11) Xavier Square to Sai Temple via Utkal Hospital (both sides).

Violation of the instant order will be deemed to be an offence and
punishable as per u/s 177 of the MV (Amendment) Act, 2019 compoundable with fine, in
addition to Section — 223(b) of Bharatiya Nyaya Sanhita, 2023.

Further, the violation of the above order will also attract provision of
Section- 127 of the MV Act-1988, which authorizes a Police Officer having jurisdiction to
tow vehicles causing impediment to the flow of traffic and when such vehicle is towed,
the owner of the vehicle shall be responsible for all towing costs, besides any other
penalty.

The above order shall come into force w.e.f. the date of promulgation of
the order. ।

ଆଇ

(Dr. S.Dev Datta Singh, IPS)
Commissioner of Police,
Bhubaneswar-Cuttack.

Memo No. 328) = /CP-Traffic Dt. 24.11.2025

1. Copy forwarded to the Collector and District Magistrate, Khurda for
information and necessary action.

2. Copy forwarded to the Commissioner, Bhubaneswar Municipal
Corporation, | Bhubaneswar, the Vice-Chairman, Bhubaneswar
Development Authority, Bhubaneswar, the CEO, BSCL, Bhubaneswar and
the Director, | & PR Deptt., Bhubaneswar for information and necessary
action.

3. Copy forwarded to the Addl. Commissioner of Police, Bhubaneswar —
Cuttack / the Dy. Commissioner of Police, Bhubaneswar for information.

4. Copy forwarded to the Asst. Commissioner of Police, (Traffic),
Bhubaneswar, IIC Traffic P.S.-l, Bhubaneswar and IIC Traffic P.S.-Il,
Bhubaneswar for information and promulgation by means of pasting on
notice board. They also instructed to ensure proper implementation of the
above order.

5. Copy forwarded to the ACP, PRO / ACP, IT & SM, C.P. Hdqrs.,
Bhubaneswar for information and wide publication in 2 prominent
newspaper (one English and one Odia) and publication in the website of
Commissionerate Police.

021

Commisstoner of Police,

Bhubaneswar-Cuttack.
Address — Bidyut Marg, Bhubaneswar, PIN-751001
Tele: 0674-2530016, Mail- dcp-traffic.odpol@od.gov.in
