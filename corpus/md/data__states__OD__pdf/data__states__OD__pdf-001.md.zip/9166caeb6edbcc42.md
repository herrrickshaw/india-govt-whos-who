---
doc_id: "9166caeb6edbcc42"
source_url: "https://finance.odisha.gov.in/sites/default/files/2020-04/Guidelines.pdf"
ministry: "Finance Department, Odisha"
title: "କେନ୍ଦ୍ରୀୟ ପ୍ରାୟୋଜିତ ଯୋଜନା (ସିଏସଏସଏସ) ମଧ୍ୟରେ…"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "22465bb56893656b"
---

<!-- page 1 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT

***
NO---Frn--_p-F_-BT-_o~L~~~_1-of'-4----~'

Date

From
Sri D. Biswal,
Deputy Secretary to Government.
To
The Additional Chief Secretary to Government/
Principal Secretaries to Government/
Commissioner-cum-Secretaries to Government/
Special Secretary to Government/
E.LC-cum-Secretary to Government
All Departments of Government
Sub: Guidelines for Flexi-Funds within Centrally Sponsored Plan
Schemes (CSSs)
Sir,
I am directed enclose a copy of the Guidelines for Flexi-Funds
within Centrally Sponsored Plan Schemes issued by Plan Finance-II
Division, Department Expenditure, Ministry of Finance, Government of
India for favour of kind information and necessary action.
Yours faithfully,

D:tc~-e,

Deputy
Memo

\

NO_-----L.J-+q.L..-...<12'---_~,

Date

set~9-,. \ "\~
to Govt.

2d/ 11~~V

Copy with copy of the enclosure forwarded to FAs/AFAs of all
Departments of Government for information and necessary action.

und~:e~r
Memo No_----!..-.} qL....:.-}

4+---~,

Date

Govt.

'-lL/ /Aff/y

Copy with copy of the enclosure forwarded to all Budget and
\ Expenditure Branches of Finance Department for information and
\ necessary action.

*,"",'()\.~'".
Under Secretary to Govt.

<!-- page 2 -->

F.No.55(5)/PF.I1J20J

J

Ministry of Finance
Departmen of K penditure
Plan Finance-If Division
New Delhi, dated .January 6, 2014
Office Memorandum

Subject:
(CSSs).

Guidelines

for Flexi-Funds

within Centrally

Sponsored

Schemes

Objectives
The introduction of a flexi-fund component within the Centrally
Sponsored Schemes ceSS) has been made to achieve the following objectives:To provide flexibility to States to meet local needs and requirements
within the overall objective of each programme or scheme;
(ii)
To pilot innovations and improved efficiency within the overall
objective of the scheme and its expected outcomes;
(Hi) To undertake mitigation/restoration
activities in case of natural
calamities in the sector covered by the CSS.
Budgetary Allocation
(i)

2.
Central Ministries concerned shall keep at least 10% of their Plan budget
for each CSS as flexi-funds, expect for Schemes which emanate from a
legislation (e.g. MGNREGA), Of, schemes where the whole or a substantial
proportion of the budgetary allocation is flexible (e.g. RKVY)
Allocation of State Share
3.
After approval of the Plan Budget, Central Ministries shall communicate
tentative allocations for each CSS to States including the allocation of flexifunds by the end of May of every financial year. In the CSS that are demanddriven or project-driven and it is not feasible to make allocations to States,
tentative allocations
for a quarter/half-year/year
hall invariably
be
communicated to sates by the end of May of every financial year. Allocation to
the States shall be based on transparent and equitable criteria. Central Ministrie
shall make allocations for 10% of flexi-funds for the CSS amongst States in the
same proportion as tentative State allocations in the 90% portion of the CSS.

<!-- page 3 -->

(

4.
Flexi-funds will be a part of the CSS and the name of the oncerned C -'r..;
will preced the word 'flexi-funds. in the communication to States I'here will
be no separate budget and account head for this purpose.
5.
As flexi-funds are a part of the concerned C S, the same State share
(including beneficiary contribution, if any) would be applicable for the flexifund component as well. However, States may provide additional share
(including beneficiary contribution, if any) over and above the required State
share for the flexi-funds component of the allocation for the CSS.
Use of flexi-funds
6.
States may use the flexi-funds for the CSS to meet the objectives
mentioned above in accordance with the broad objectives of the main Scheme.
The flexi-funds may also be utilized for mitigation/restoration activities in the
event of natural calamities in accordance with the broad objectives of the CSS.
However, the specific guidelines of the CSS, applicable for 90% of the CSS
allocation, will not be essential for the Flexi-funds component of the CSS,
except for State share requirements.
7.
The flexi-funds of a CSS in a particular sector, however, shall not be
diverted to fund activities/schemes in other sectors. For example, if a particular
CSS relates to elementary education, the flexi-funds for that scheme can only be
used for elementary education and not for agriculture or any other sector. But it
would be permissible to converge flexi-funds of different schemes to improve
efficiency and effectiveness of outcomes.
8.
The purpose of providing flexi-funds is to enable Sates to undertake new
innovative schemes in the particular area covered by the CSS. Flexi-funds shall
not be used to substitute State's own non-Plan or Plan schemes/expenditure. It
shall also not be used for construction/repairs of offices/residences
for
Government officials, general publicity, purchase of vehicles/furniture for
offices, distribution of consumer durables/non-durables, incentives/rewards for
staff and other unproducti ve expend iture.
9.
Schemes taken LIp with Flexi-funds shall invariably carry the name of
concerned CSS.
10.
The State-level Sanctioning Committee (SLSC) may sanction projects
under the flexi-funds component. States. will be not be required to send the
project to Ministries for approval under the flexi-funds window as the SLSC
will have a representative of the concerned Ministry and Planning Commission.

<!-- page 4 -->

tates wishing to use flexi funds as part of the normal 9()<~'(,component

are free

to do so.

Release of Flexi-funds
11.

Release

of flexi-funds

along with the normal

on a pro rata basis

under CSS. ln other words,

no separate system

releases

for release or for utilization
12. Flexi-funds

for each CSS may be made
certificates

for flexi-funds

would be required.

within each CSS will be subject to the same audit requirements

as the main CSS including

& Auditor

the audit by the Comptroller

General

of

may

be

India (CAG).

Monitoring & Evaluation
13.

Web-based

designed

requirements

by adding modules

for reporting

the use of flexi-funds

to the existing MIS. Outcomes

(medium

term) and

outputs (short term) need to be part of the MIS along with pictures/images
good practices

to ensure greater transparency

For this purpose,

and cross-learning

web portal for sharing best practices

is proposed

and

across States.
to be created

in Planning Commission.
14.

Evaluation

processes

of flexi-funds

including

those by Ministries,

(PEO) and Independent
and by independent

may be done through

Evaluation

third parties.

designed in such a manner

Programme

Organisation

the existing
Evaluation

(lEO),

Terms and conditions

that outcomes

of the Scheme

Planning

evaluation

Organisation
Commission

for evaluation

may be

as a whole as well as

flexi-funds are well identified/measured.
15.

These guidelines

will be applicable

from the frnancial year 2014-15.

1~.;iA

~~ 6) 1/

(Dr. Saurabh Garg)
Joint Secretary (Plan Finance-IT)
Government of India
To,
1. Secretaries,
All the Departments/Ministries
Government of India.
2. Chief Secretaries,
All StateslUnion Territories.

1

,

I~
