---
doc_id: "a03fabd89d3d9ec6"
source_url: "https://forest.odisha.gov.in/sites/default/files/2022-03/Odisha%20Subordinate%20Forest%20Service%20%28Method%20of%20Recruitment%20and%20Conditions%20of%20Service%20of%20Foresters%29%20Rules%2C%202018._0.pdf"
ministry: "Forest, Environment and Climate Change Department, Odisha"
title: "Download(243.05 KB)"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8ded7b854f0c0d1c"
---

<!-- page 1 -->

EXTRAORDINARY
PUBLISHED BY AUTHORITY
No. 185

CUTTACK,

MONDAY,

JANUAR Y

21,

2019/MAGHA 1, 1940

FOREST & ENVIRONMENT DEPARTMENT
NOTIFICATION
The 19th January, 2019
No.1396/F&E. — In exercise of the powers conferred by the proviso to Article 309
of the Constitution of India and in supersession of the Odisha Subordinate Forest Service
(Method of Recruitment and Conditions of Service of Foresters) Rules, 1998 except as
respects things done or omitted to be done before such supersession, the Governor of
Odisha is pleased to make the following rules to regulate the method of recruitment and
conditions of service of Foresters, namely:—
1. Short title and commencement:— (1) These rules may be called the Odisha
Subordinate Forest Service (Method of Recruitment and Conditions of Service of
Foresters) Rules, 2018.
(2) They shall come into force on the date of their publication in the Odisha Gazette.
2. Definition:— (1) In these rules, unless the context otherwise requires,—
(a) “Appointing Authority’’ means the Divisional Forest Officer Concerned;
(b)“Commission” means the Odisha Subordinate Staff Selection Commission;
(c)“Chairman” means the Chairman of the Odisha Subordinate Staff Selection
Commission;
(d) “Department of Government” means the Forest and Environment Department;
(e)“Divisional Forest Officer” means the Divisional Forest Officer of the Division;
(f) “Government” means the Government of Odisha;
(g) “Scheduled Castes and Scheduled Tribes” shall have reference to the
Scheduled Castes and Scheduled Tribes specified in the Constitution
(Scheduled Castes) Order, 1950 and the Constitution (Scheduled Tribe) Order,
1950, as the case may be, made under Article 341 and 342 of the Constitution
of India, respectively;
(h) “Selection Board” means the board constituted under rule- 9;

<!-- page 2 -->

2

(i) “SEBC” means the Socially and Educationally Backward Classes referred to in
the Odisha Reservation of Posts and Service(for Socially and Educationally
Backward Classes) Act, 2008(Odisha Act 6 of 2009);
(j) “Service” means the Odisha Sub-ordinate Forest Service;
(k) “Year” means the Calendar year;
(l) “PCCF” means the Principal Chief Conservator of Forests, Odisha;
(m) “RCCF” or “CCF” means the Regional Chief Conservator of Forests or the
Chief Conservator of Forests as the case may be;
(n) “Sports Person” means a person who have been be issued with identity card
as sportsmen by the Director, Sports;
(o) “Ex-Servicemen” means a person as defined in the Odisha Ex-Servicemen
(Recruitment to State Civil Services and Posts) Rule,1985;
(p) “Committee” means the Departmental Promotion Committee of the Division;
(2) All other words and expression used in these rules but not specifically defined
shall, unless the context otherwise requires, have the same meaning as respectively
assigned to them in the Odisha Service Code.
3. Constitution of Service:—(1)The Service shall consist of the following posts,
namely:—
(i) Forester and
(ii) Deputy Ranger.
(2) The service of each Division Forest Office in respect of Foresters shall form a
separate cadre.
4. Method of Recruitment:— Subject to other provisions made in these rules,
recruitment to the post of Forester in the Division office shall be made by the following
methods, namely:—
(i) Not more than 50% (fifty percent) of the vacancies shall be filled up through
direct recruitment by the Commission ; and
(ii) Not less than 50% (fifty percent) of the vacancies shall be filled up from
among the eligible Forest Guards of the concerned Division.
5. Reservation:— Notwithstanding anything contained in these rules reservation of
vacancies or posts, as the case may be, for—
(a) Scheduled Castes and Scheduled Tribes shall be made in accordance with
the provisions of the Odisha Reservation of Vacancies in posts and
Services (for Scheduled Castes and Scheduled Tribes) Act,1975 and the
rules made there under; and

<!-- page 3 -->

3

(b) SEBC, women, sportsmen, Ex-servicemen shall be made in accordance
with the provisions made under such Act, rules, orders or instructions
issued in this behalf by the Government from time to time.
(c) No Persons with Disabilities shall be eligible to be appointed to the service
except the following 2 categories of PwD as per prescribed percentage of
reservation.
i) Leprosy Cured Persons
ii) Acid Attack Victims;
Provided that in case of non-availability of suitable PwD candidate for recruitment
the reserved posts may de-reserved and filled up by a person other than a person with
disability.
6. Recruitment Procedure:— (1) Recruitment to the post of Forester shall be
made by way of competitive examination to be held once in a year preferably in the month
of January. For the purpose, the Requisitioning Authority shall file requisition to the Odisha
Subordinate Staff Selection Commission in the month of January indicating category wise
and Division wise break up in the post of Forester keeping in view the need for effective
cadre management, administrative convenience etc.
(2) The competitive examination shall be conducted by the Commission. The date
and the places of the examination shall be fixed by the Commission.
(3) The standard, syllabus and subjects of examination shall be decided by the
Commission.
7. Eligibility criteria for Direct Recruitment:— In order to be eligible for direct
recruitment a candidate must,—
(1) be a citizen of India.
(2) have attained the age of 18 years and not be above the age of 32 years as
on month in the year of examination.
Provided that the upper age limit in respect of reserved categories of candidates
referred to rule 5 shall be relaxed in accordance with the provisions of the Act, rules,
orders or instructions, for the time being in force, for their respective categories.
(3) be able to read, write and speak Odia; and have—
(a) passed Middle school examination with Odia as a language subject; or
(b) passed Matriculation or equivalent examination with Odia as medium of
examination in non-language subject; or

<!-- page 4 -->

4

(c) passed in Odia as language subject in the final examination of Class VII
from a school or educational institution recognized by the Government of
Odisha or the Central Government; or
(d) passed a test in Odia in Middle English School Standard conducted by
the School & Mass Education Department.
(4) The Persons with Disabilities candidates except 2 categories of PwD i.e.
Leprosy Cured Persons and Acid Attack Victims, shall not be eligible for the post.
(5) not have more than one spouse living:
Provided that the Government may, if satisfied that such marriage is permissible
under the personal law applicable to such person or there are other grounds for doing so,
exempt any person from the operation of this rule.
(6) have possessed +2 Science from recognized University, Institution or Board as
the case may be with knowledge in basic Computer skills.
8. Vacancies:— The vacancies in the sanctioned post, to be filled up in a year shall
be determined by the Divisional Forest Officer concerned by the first day of January of the
year in which the recruitment is made keeping in view the need for effective cadre
management, administrative convenience etc.
9. Selection Board for Physical Efficiency Test:— The Commission shall
constitute the Selection Board for Physical Efficiency Test consisting of the following
members, namely:—
(a) Collector of the District in which
Forest Division is situated

:

Chairman

concerned Division

:

Member

(c) District Welfare Officer

:

Member

:

Member

:

Member Secretary

(b) Divisional Forest Officer of

(d) Medical Officer in the rank
of Assistant Surgeon
(e) Assistant Conservator of Forests
Headquarters of the Division

One of the Assistant Conservator of Forests of the Division as Member Secretary
will be decided by the Divisional Forest Officer in which forest Division is situated.
However, in absence of Assistant Conservator of Forests in the Division, the Regional
Chief Conservator of Forests concerned may appoint any Assistant Conservator of Forests
of other Divisions under his administrative control to function as Member Secretary.

<!-- page 5 -->

5

10. Physical standard:— (1) The minimum physical standard of the candidates
shall be as follows for different categories:—
Category of Candidate

Minimum
Minimum
Minimum Chest (in cm)
Height
Weight
Un-expanded
Expanded
(in cm)
(in Kg.)
Men
UR/SEBC/SC
168
55
81
86
ST
158
50
81
86
Women UR/SEBC/SC/ST
153
45
(2) The Candidates shall be examined by the Chief Medical Officer of the District to
testify that they possess sound health and general physical fitness for arduous outdoor
work essential for the service.
(3) The candidates must be of sound health, good physique and active habits and
be free from organic defect or bodily infirmity.
11. Select list:— (1) The Commission shall prepare a list of successful candidates
in order of merit on the basis of total marks secured in the Physical Efficiency Test and
Written Test taken together. This list shall contain the names of the successful candidates
equal to the number of vacancies. This list after being approved by the appointing authority
shall form the ‘Select list’.
If the aggregate marks obtained by two or more persons are equal then,
(a) The candidate securing higher marks in Physical Efficiency Test shall be
placed above the other candidate in the select list.
(b) If the marks in the Physical Efficiency Test are also same, the candidate
securing higher marks in the written test shall be placed above the other
candidate in the select list.
(c) If the marks in written test are same then the candidate older in age shall be
placed above other candidate in the select list.
(2)The select list prepared under Sub-rule (1) shall remain valid for a period of one
year from the date of its approval by the appointing authority or till the next Select list is
drawn up whichever is earlier.
12. Seniority:— (1) The inter se seniority of the Foresters shall be determined with
reference to his position in the select list prepared by the Commission.
(2) The promotees shall be en-bloc senior to the direct recruitees of the same year.
13. Allotment of marks:—The recruitment shall be conducted for total marks of
100 (one hundred) and the distribution/award of marks for different tests shall be as
follows, namely:—

<!-- page 6 -->

6

(a) Physical Standard (05 marks):—
The bonus mark will be awarded to all categories as per their height (in cm) as
follows, namely:—
Men

UR/

168 cm

169-170

171-173

174-176

177-179

180 and

SEBC/SC

0 mark

1 mark

2 marks

3 marks

4 marks

above
5 marks

ST

158

159-160

161-163

164-166

167-169

170 and

0 mark

1 mark

2 marks

3 marks

4 marks

above
5 marks

Women

UR/

153

154-155

156-158

159-161

162-164

165 and

SEBC/

0 mark

1 mark

2 marks

3 marks

4 marks

above

SC/

5 marks

ST
(b) Sports (10 marks):—
Candidates possessing sports and athletic certificate shall be awarded marks, in the
following manner, namely:—
(i) Representing the Country and participating in a competitive International Sports
meet/Championship and winning medal.
(a)For a Gold medal (or first position) = 10 Marks
(b) For a Silver medal (or second position) = 09 Marks
(c)For a Bronze medal (or third position) = 08 Marks
(ii) Representing the State and participating in a competitive in open National
Championship and winning medal.
(a) For a Gold medal (or first position) =08 Marks
(b)For a Silver medal (or second position) =07 Marks
(c) For a Bronze medal (or third position) =06 Marks
(iii) Representing the State and participating in open
National Championship without medal = 05 Marks.
(iv) Representing the District/Circle in Junior/Senior/
Inter-District meet in State Level Sports = 04 Marks
(v) Sports achievement in the discipline other than 26 listed below shall not be
considered for award of marks.

<!-- page 7 -->

7

i

Athletics

x.

Football

xix.

Rowing

ii.

Archery

xi.

Gymnastics

xx.

Shooting

iii.

Badminton

xii.

Hockey

xxi.

Swimming

iv.

Basket Ball

xiii.

Judo

xxii.

Table Tennis

v.

Body Building xiv.

Kabadi

xxiii. Tae Kwon Do

vi.

Boxing

xv.

Karate Do

xxiv. Volleyball

vii.

Cricket

xvi.

Kayaking & Canoeing xxv.

viii. Cycling

xvii.

Lawn Tennis

ix.

xviii. Power Lifting

Equestrian

Weight Lifting

xxvi. Wrestling

(c) Physical Efficiency Test- (30 Marks):—
The candidate qualifying in the following physical tests shall be allowed to
subsequent written test.
(i) Male Candidate (Total Marks 30)
(a) Walking Test (10 Marks) – Qualifying distance 25 Kms.
Within 2.30 hrs.

10 marks

Between 2.31 to 3.00 hrs.

07 marks

Between 3.01 to 3.30 hrs

04 marks

Between 3.31 to 4.00 hrs

02 marks

Beyond 4.00 hrs.

Disqualify

(b) Cycling Test (05 Marks) – Qualifying distance 1.6 Kms
Within 3 mins.

05 marks

Within 4 mins.

04 marks

Within 5 mins.

03 marks

Within 6 mins.

01 mark

Beyond 6 mins.

Disqualify

(c) High Jump (05 Marks) – Qualifying height-1.22 mtrs.
If cleared in First chance

05 marks

If cleared in Second chance

03 marks

If cleared in Third chance

02 marks

(d) Broad Jump (05 Marks) – Qualifying length-3.66 mtrs.
If cleared in First chance

05 marks

If cleared in Second chance

03 marks

If cleared in Third chance

02 marks

(e) Rope Climbing (05 Marks) – Qualifying height-6 mtrs.

<!-- page 8 -->

8

(f)

If cleared in First chance

05 marks

If cleared in Second chance

03 marks

If cleared in Third chance

02 marks

Swimming – Qualifying length 40 mtrs.
Distance covered within 8 mins.–qualifying
otherwise participant will be disqualified

(ii) Female Candidate (Total Marks 30)
(a) Walking Test (10 Marks) - Qualifying distance 16 Kms.
Within 2.30 hrs.

10 marks

Between 2.31 to 3.00 hrs.

07 marks

Between 3.01 to 3.30 hrs.

04 marks

Between 3.31 to 4.00 hrs.

02 marks

Beyond 4.00 hrs.

Disqualify

(b) Cycling Test (06 Marks) – Qualifying distance 1.6 Kms.
Within 5 mins.

06 marks

Within 6 mins.

04 marks

Within 7 mins.

03 marks

Within 10 mins.

01 mark

Beyond 10 mins.

Disqualify

(c) High Jump (07 Marks) – Qualifying height 1.00 mtrs.
If cleared in First chance

07 marks

If cleared in Second chance

04 marks

If cleared in Third chance

03 marks

(d) Broad Jump (07 Marks) – Qualifying length 2.75 mtrs.
If cleared in First chance

07 marks

If cleared in Second chance

04 marks

If cleared in Third chance

03 marks

(e) Swimming – Qualifying length 40 mtrs.
Distance covered within 10 mins.–qualifying otherwise participant will be disqualified
(d) Witten Test (50 Marks):—
The candidates having minimum physical standard as prescribed under sub-rule(1)
of rule-10 and after qualifying the Physical Efficiency Test as prescribed under rule-13 will
be allowed to appear for the written test with basic computer knowledge.

<!-- page 9 -->

9

There shall be 50 marks for written test to be held in Optical Mark Recognition
System with Multiple Choice Questions by the Commission.
(e) N.C.C. (05 Marks):—
The bonus mark will be awarded to the candidates as follows:—
National Cadet Corps “C” certificate - 5 Marks
National Cadet Corps “B” certificate - 3 Marks
National Cadet Corps “A” certificate - 2 Marks
14.Recruitment by way of promotion:—The Forest Guard shall be eligible to be
considered for promotion to the post of Forester subject to satisfaction of the following
conditions, namely:—
(a) He/she shall have completed a minimum of 10 years of continuous service
in the cadre of Forest Guard;
(b) He/she shall have the minimum educational qualification of 10th pass;
(c) He/she shall have passed the Forest Guard training Course; and
(d) He/she shall not be Persons with Disabilities except Leprosy Cured Person
and Acid Attack Victim.
15.Criteria for promotion/selection:— The promotion of Forest Guard shall be
according to the merit with due regard to seniority.
Performance Report for last 5 (five) years of service of Forest Guards shall be
examined by the Departmental Promotion Committee of the Division.
16. Constitution of Committee/Board:— (1) There shall be constituted a
Departmental Promotion Committee consisting of the following members to consider the
cases of promotion from Forest Guard to Foresters, namely:—
(a) Divisional Forest Officer of the Division

: Chairman

(b) District Welfare Officer

: Member

(c) Representative of the Collector,
preferably member of Odisha Administrative Service

: Member

(d) Assistant Conservator of Forests of the
Headquarters of the Division

: Member Secretary

(2)The recommendation of the Committee shall be valid and can be operated upon
notwithstanding the absence of any one of its members other than the Chairman:
Provided that the member so absent was duly invited to attend the meeting of the
Committee and the majority of members of the Committee attended the meeting.

<!-- page 10 -->

10

17. Procedure for Selection by the Committee:— (1) The Committee shall meet
at least once in a year preferably in the month of January to prepare a list of
officers/employees, as are held by them, suitable for promotion to the next higher grade
taking into account the existing vacancies of the year.
(2)

The

Committee

while

considering

the

promotion

cases

of

suitable

officers/employees and preparation of the list shall follow the provisions of –
(a) the Odisha Reservation of Vacancies in Posts and Services (for Scheduled
Castes and Scheduled Tribes) Act,1975 and the rules made there under;
(b) the Odisha Civil Services (Zone of Consideration for Promotion) Rules,1988;
(c) the Odisha Civil Services (Criteria for Promotion) Rules,1992, and
(d) the Odisha Civil Services (Criteria for Selection for Appointment including
Promotion) Rules, 2003.
18. Select list and validity:— (1)The Departmental Promotion Committee of the
Division shall prepare a list of candidates suitable for promotion equal to the number of
vacancies.
(2)The prepared list of sub-rule(1) shall remain valid for a period of one year from
the date of its approval or till drawal of the next select list whichever is earlier.
19. Promotion of Forester to the rank of Deputy Ranger:— Under Odisha
Subordinate Forest Service, the post of Deputy Ranger shall be a promotional post.
(1) The posts of the Deputy Ranger shall be filled up by way of promotion from the
rank of Forester at State level.
The number of vacancies of the posts of the Deputy Ranger cadre shall be notified
by respective circles as on 1st January and accordingly the process for promotion shall be
started preferably in the month of January of every year. A Forester may be eligible for
promotion to the post of Deputy Ranger subject to fulfilling the following criteria namely:—
(a) He/she shall have completed a minimum of 05 (five) years of service in the
cadre of Forester.
(b) He/she shall have minimum educational qualification of 10+2 pass or
equivalent standard.
(c) He/she shall not be Persons with Disabilities except Leprosy Cured Person
and Acid Attack Victim & should be medically fit.
(d) He/she should have passed the Forester training.
(e) The vacancies of Deputy Ranger posts will be calculated taking into account
vacancies of all Divisions under the Forest & Environment Department.

<!-- page 11 -->

11

(2) The promotion of Forester to the rank of Deputy Ranger shall be made on the
basis of seniority with due regard to merit.
(3) There shall be constituted a Departmental Promotion Committee consisting of
the following officers to consider the matter of promotion from Forester to the post of
Deputy Ranger.
(a) Principal Chief Conservator of Forests,
Odisha, Bhubaneswar

:

Chairman

:

Member

:

Member

:

Member

:

Member

:

Member Secretary.

(b) A Representative of the Principal
Chief Conservator of Forests (WL),
Odisha, Bhubaneswar
(c) A representative of the Principal Chief
Conservator of Forests (KL),
Odisha, Bhubaneswar
(d) A Representative of the Scheduled
Tribes & Scheduled Castes Development
Department
(e) Chief Conservator of Forests (Personnel &
Administration), Office of the Principal
Chief Conservator of Forests, Odisha,
Bhubaneswar
(f) Senior Administrative Officer, Office of the
Principal Chief Conservator of Forests,
Odisha, Bhubaneswar

20. Training:— On receipt of select list of various categories of candidates from the
Commission, the appointing authority shall intimate Chief Conservator of Forests, Training
and Development, Cuttack for allotment of seats in the training institution.
21.Allotment for training:— The Chief Conservator of Forests, Training and
Development, Cuttack after receiving intimation from the appointing authorities shall
prepare a consolidated list of trainees for undergoing training School wise in different
sessions and send the same to Principal Chief Conservator of Forests, Odisha for
approval. After obtaining such approval, the Chief Conservator of Forests, Training and
Development, Cuttack shall notify the names of candidates for undergoing the training.
22. Stipend and Duration of training:— The candidates selected by the
Commission shall undergo training course in any of the Forester training school for a
period of one year with effect from the date of joining in the training institute to which they

<!-- page 12 -->

12

will be deputed. The new recruitees will be paid stipend as per the guide lines of the
Finance Department applied to contractual employees. The Forest Guard selected for the
post of Forester shall be paid their usual salary from respective Division during the period
of training. The Forest Guard selected for the post of Forester through promotion shall
undergo 4 (Four) months training course.
23. Bond:— The selected candidates shall have to execute a bond prior to joining
the training as prescribed by the Forest and Environment Department.
24. Probation:— (1) Every person appointed to the service by direct recruitment
shall be on probation for a period of two years and when appointed on promotion shall be
on probation for a period of one year from the date of joining the post;
Provided that the appointing authority may, if think fit in any case or class of cases,
extend the period of probation:
Provided

further

that

such

period

of

probation

shall

not

include,—

(a) extraordinary leave;
(b) period of unauthorized absence; or
(c) any other period held to be not being on actual duty.
(2) A probationer may for good and sufficient reasons to be recorded in writing be
terminated from service in case of appointment made by direct recruitment and be
reverted to his former post in case of appointment made on promotion by Government at
any time without previous notice during the period of probation including extension of such
period, if any.
25. Relaxation:— Whenever it is considered by the Government that it is
necessary or expedient to do so in the public interest, they may, by order and for reasons
to be recorded in writing, relax any of the provisions of these rules in respect of any class
or category of persons.
26. Interpretation:— If any question arises relating to the interpretation of any
provision of these rules, it shall be referred to the Government in Forest and Environment
Department whose decision thereon shall be final.
By Order of the Governor
S. C. MAHAPATRA
Additional Chief Secretary to Government

Printed and published by the Director, Printing, Stationery and Publication, Odisha, Cuttack-10
Ex. Gaz. 2136-173+100
