---
doc_id: "b06d14f0a1fafc7d"
source_url: "https://law.odisha.gov.in/sites/default/files/2026-10/Shree%20Jagannath%20Temple%20Land%20Management%20Rules%2C%202026_0.pdf"
ministry: "Law Department, Odisha"
title: "Download(286.47 KB)"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eecce98c0c881093"
---

<!-- page 1 -->

EXTRAORDINARY
PUBLISHED BY AUTHORITY
No.4220,

KATAKA, FRIDAY,

SEPTEMBER 11, 2026/BHADRA

20, 1948

LAW DEPARTMENT
NOTIFICATION
The 11th September, 2026
S.R.O. No.743/2026 — In exercise of the powers conferred by Section 32 read with
sub-section (2) of Section 16 of the Shree Jagannath Temple Act, 1955 (Odisha Act 11 of
1955) and in supersession of the Uniform Policy, 2003 and amendments made therein, the
State Government do hereby make the following Rules to carry out the purposes of the
said Act, namely:
1. Short title and commencement.— (1) These rules may be called the
Shree Jagannath Temple Land Management Rules, 2026.
(2) They shall come into force on the date of their publication in the
Odisha Gazette.
2. Definitions.— In these rules, unless the context otherwise requires,—
(a) “Act” means the Shree Jagannath Temple Act, 1955;
(b) “Administrator” means the Administrator appointed under sub-section (3) of
Section 19 of the Act;
(c) “ALSS” means Average

Land Sale Statistics of fifty per cent of the total

number of sale deeds or the agreement to sale in which the highest sale price
has been mentioned in preceding three years;
Explanation.—For determining the average sale price, fifty per cent of the total
number of sale deeds or agreements to sale executed during the preceding
three years, having the highest sale prices in descending order, shall be taken
into account.
(d) “Appellate Authority” means the State Government for hearing appeal under
rule 16;

<!-- page 2 -->

2

(e) “Beneficiary” means an applicant applying for settlement of SJT land under
this rule from amongst any of the following categories or any other person
deriving interest from them.—
(i) Sevak;
(ii) Sevak Nijog;
(iii) Non Sevak; and
(iv) Math.
(f) “Chief Administrator” means the Chief Administrator appointed under
sub-section (1) of Section 19 of the Act;
(g) “Commercial Land” means any land which is used, or is capable of being
used, for the purpose of generating income through activities other than
residential or agricultural and includes land over which commercial
establishments such as shops, offices, hotels, warehouses, markets, industrial
units or other establishments of similar nature are constructed, maintained, or
operated:
Provided that, a residential property which is sublet or leased exclusively
for residential purposes shall not be deemed to be a commercial land;
(h) “Competent Authority” means the authority competent to sanction sale or
settlement of SJT land as provided in these rules;
(i) “Decimal (dec.)”- means a unit of area which represents one-thousandth
(1/1000) of an Acre.;
Explanation: For the purposes of these Rules, one Acre shall be deemed to
comprise 1,000 decimals.
(j) “ DLC Land” means any non-forest kissam (classification) of Government or
private land featuring natural vegetation, plantations, or even barren land that
is explicitly recorded in the District Land Committee (DLC) in pursuance of the
direction of the Hon’ble Supreme Court in T.N. Godavarman Thirumulpad v.
Union of India, W.P. (C) No. 202/1995;
(k) “DLSC” means the District Level Land Sub-Committee constituted under
rule 5;
(l) “Nijoga” means an association of Sevakas recognized by SJTMC;
(m) “Portal” means the online land management interface notified by the State
Government for receipt, processing and tracking of land-related applications;

<!-- page 3 -->

3

(n) “Record-of-Rights of Shree Jagannath Temple” means the Record of Rights
prepared under the Puri Shree Jagannath Temple (Administration) Act, 1952
(Orissa Act XIV of 1952);
(o) “Settlement’’ means

grant of allotment, regularization, or conferment of

occupancy, leasehold, or ownership rights over SJT land in favour of the
beneficiary by the Competent Authority in accordance with the provisions of
this rule;
(p) “Sevak” means a person as defined under clause (d-1) of sub-section (1) of
Section 4 of the Act;
(q) SJMBSC

means

“Shree

Jaganntha

Mahaprabhu

Bhumi

Sanchalan

Committee” created in the District Collectorate as provided in sub-rule (5) of
rule 4;
(r) “SJTA” means the Shree Jagannath Temple Administration as defined under
the Act;
(s) “SJT land” means land belonging to Shree Jagannath Temple, Puri and
recorded in the revenue Record of Rights in the name of Shree Jagannath
Mahaprabhu Bije Puri marfat Shree Jagannath Temple Managing Committee,
Puri or in the name of Shree Jagannath Mahaprabhu Bije Puri Marfat any
other private individual or in specific instances where it is recorded as Lord
Jagannath Bije Puri in Khewat No.1 of revenue Record of Rights;
(t) “SJTMC” means the Shree Jagannath Temple Managing Committee
constituted under section 6 of the Act;
(u) “State Government” means Government of Odisha in the Law Department;
and
(v) “Working Chairman” means the Working Chairman appointed under clause(b)
of sub-section (1) of Section 6 of the Act.
(2) All other words and expressions used in these rules but not defined hereinbefore
shall have the same meaning as respectively assigned to them in the Act.
3. Applicability.— The provisions of these rules shall be applicable to all SJT land in
the State of Odisha except Ekharajat Mahal and Sateisi Hazari Mahal Estates unless
specifically provided by the State Government.

<!-- page 4 -->

4

4. Procedure for submission and initial processing of applications for purchase or
settlement of SJT land.—(1) All applications for settlement of SJT land shall be made
within a period of two years through the online Portal in the form as may be prescribed by
the State Government.
Explanation: The period of two years shall commence from the date on which the
portal is made available and notified for public use.
(2) Every application shall be accompanied by a non-refundable processing fee of
Rs. 1,000/- (Rupees One Thousand) only, to be paid online through the Portal.
(3) The applicant shall, along with the application, upload self-attested scanned
copies of the following documents, as available with him, namely:—
(a) Record of Rights (ROR);
(b) Any registered deed of conveyance;
(c) Revenue Rent Receipts;
(d) Legal Heir Certificate, if necessary; and
(e) Any other document substantiating the claim of possession.
(4) On receipt of the application, a system generated message shall automatically
be transmitted to the Collectorate of the concerned district with a unique application
number.
(5)The concerned District Collector shall constitute a committee namely
Shree Jagannath Mahaprabhu Bhumi Sanchalan Committee (SJMBSC) to function with
the Additional District Magistrate (Revenue) as the Nodal Officer for verification of the
applications.
(6) The SJMBSC shall verify each application within 7 days and shall forward the
same to the concerned Tahasildar through the Portal within 15 days for field enquiry and
verification.
(7) The Tahasildar after field enquiry shall prepare and submit a Report to the Nodal
Officer of SJMBSC within 30 days, containing the following details namely:— site-visit
memorandum, land schedule, trace-map, Sabik-Hal comparison, particulars of possession,
flow of title, supporting documents and recommended Bench Mark Value (BMV) and
Average Land Sale Statistics (ALSS) of the preceding three years obtained from the
Sub-Registrar office, together with his recommendation on market rate and proposed
valuation for DLSC consideration. Tahasildar shall clearly identify ‘jungle’ kisam land by
making sabik-hal correlation and as per judgment of the Hon’ble Supreme Court in (T.N.
Godavarman Thirumulpad v. Union of India, W.P. (C) No. 202/1995) and he shall, in no
case, recommend for settlement of any type of forest or DLC land.

<!-- page 5 -->

5

(8) The Nodal Officer of SJMBSC shall scrutinize the case record and the
Tahasildar's report and shall submit the same before the DLSC within a period of 7 (seven)
days.
5. Constitution and Functions of District Level Land Sub-Committee (DLSC) and
SJTMC.—(1) The DLSC in each district shall consist of:
(i)

Collector and District Magistrate – Chairperson;

(ii)

Additional District Magistrate (Revenue) – Member; Nodal officer of the
SJMBSC;

(iii)

Sub-Collector of the concerned Sub-Division – Member;

(iv) Deputy Collector (Revenue) – Member-Convener;
(v)

Tahasildar of the concerned Tahasil – Member; and

(vi) The Chairperson may co-opt any other official as a member if deemed
necessary.
(2) The DLSC shall meet at least once in every month to dispose of the applications
submitted to it by SJMBSC and may convene the meeting earlier in cases of urgency.
(3) The DLSC shall have the Authority to require the applicant to produce the
original copies of the documents submitted by him for the purpose of verification, as and
when deemed necessary.
(4) In case of any defect or deficiency in the application or supporting documents,
the applicant shall be granted 30(thirty) days time to rectify the same, failing which the
application may be rejected.
(5) The DLSC shall examine the case record and shall submit a copy of the entire
record to SJTMC within 7 (seven) days for obtaining a No Objection Certificate.
(6) On receipt of the request, the SJTMC shall convey its decision to DLSC within
30 days:
Provided that SJTMC may constitute a Land Sub-Committee to take a decision on
behalf of SJTMC and in absence of such Land Sub-Committee, the Chief Administrator,
SJTA shall be competent to take a decision.
(7) Upon receipt of the No Objection Certificate (NOC) from the SJTMC, the DLSC
shall, within fifteen days, submit the case records to the Competent Authority with any one
of the following recommendations, together with reasons thereof:—
(i) sale or settlement; or
(ii) rejection; or
(iii) further enquiry on specific points.

<!-- page 6 -->

6

(8) All recommendations of DLSC shall be uploaded in portal and intimated to the
SJTA with statement of reasons thereof.
6. Competent Authorities and Delegation of Powers.—(1) Subject to the provisions of
these rules, Collector, RDC and the Principal Secretary to Government, Law Department
are the Competent Authorities to sanction sale or settlement of SJT land, as per the limit
of area specified in the Schedule-I:
Provided that no Authority shall sanction the sale or settlement of land in excess of
the limit of the area as specified in the Schedule-I.
(2)The Competent Authority as the case shall take a final decision on the
recommendation of the DLSC assigning reason thereon and shall communicate its
decision to SJTMC for implementation.
(3) In all circumstances the Competent Authority shall dispose of the case within one
month from date of receipt of recommendation of DLSC;
7. Valuation.—(1) The assessment of consideration money for settlement of SJT
Lands other than commercial land shall be made by SJTA as provided in Schedule II
and III:
Provided that, land of the Bijesthali of Mathas upto Ac 0.100 dec having seva puja
in Shree Jagannath Temple as per Record-of-Rights of Shree Jagannath Temple shall be
settled without any consideration money:
Provided further that homestead land exceeding Ac. 0.100 dec. and up to Ac. 0.250
dec. may be settled at the prevailing BMV or ALSS valuation, whichever is higher, where
such land has been in continuous possession of the Matha for more than 30 (thirty) years
as on the cut-off date.
Explanation: SJTMC shall be competent to take decisions regarding the existence of seva
puja of a Matha for Shree Jagannath Temple.
8.Valuation of Commercial Land.—(1) The consideration money for commercial land
upto Ac 0.250 dec shall be valued at quadruple of the Bench Mark Value (BMV) or ALSS
valuation whichever is higher:
Provided that where any portion of homestead land is being used for commercial
purposes, the valuation shall be made proportionately based on the extent of land so used
for commercial purposes:

<!-- page 7 -->

7

Provided further that, where more than fifty percent of the homestead land is being
used for commercial purposes, the entire extent of such land shall be treated as
Commercial Land for the purpose of valuation under these rules.
9. Cut-off date and eligibility for reckoning duration of possession.—(1) The
cut-off date for reckoning the duration of possession shall be dated 28th February, 2019.
(2) Period of occupation by the applicant shall be assessed from the report of the
Tahasildar and the documents produced by the applicant proving proper and continuous
possession till the cut-off date.
10. Payment and Registration.—(1) Upon sanction of sale or settlement by the
Competent Authority, a demand notice shall be issued by the Chief Administrator through
the Portal and physical mode calling upon the applicant to deposit the consideration
money within 3 (three) months from date of receipt of the demand notice.
(2) Payment shall be made in online mode (RTGS, NEFT, UPI etc) to the
designated account or by account payee Bank Draft/Banker’s Cheque in favour of 'Chief
Administrator, Shree Jagannath Temple, Puri', and evidence of payment shall be uploaded
on the Portal or submitted to SJTA office.
(3) If the applicant fails to deposit the consideration money within three months, the
sanction shall lapse automatically and the application shall stand rejected:
Provided that, SJTA, for reasons to be recorded in writing, may extend time upto
one year, in which case interest at twelve percent (12%) per annum shall be charged from
the expiry of the three months period until the date of payment.
(4) Stamp duty and registration fees as applicable shall be assessed and paid by
the applicant on the consideration money as finally determined.
(5) The Chief Administrator may authorize the Deputy Administrator (Revenue) or
any other officer in the Temple Administration to execute appropriate deeds of conveyance
on behalf of SJTMC to create title in favour of the transferee or beneficiary as the case
may be. A copy of such deed shall be tagged to the case record within fifteen (15) days of
registration.
(6) After execution of deed of conveyance, the concerned Tahsildar, upon receipt of
intimation, shall record the purchased area or land in favour of the purchaser under
Sthitiban status by correcting both land record and map.
(7) On receipt of confirmation message of such correction of land record as per
deed of conveyance, the case record shall stand closed.

<!-- page 8 -->

8

11. Jurisdiction of SJTMC for direct transfer of SJT Land to the Government and
other

purposes.—(1) SJTMC may, subject to the approval of the State Government,

transfer SJT land for public purposes in favour of the Government, Government Agencies
or Government Corporations or any other entity as recommended by the Government
where valuation shall not be less than the Bench Mark Value (BMV) or ALSS whichever is
higher.
(2) SJTMC may, subject to prior approval of the State Government, transfer SJT
lands situated in priority locations including lands adjoining National Highways, State
Highways, Expressways, important roads, upcoming urban centers, or otherwise reserved
for strategic temple requirements through a transparent public auction or e-auction to the
highest bidder where such alienation is essential for the best interest of Shree Jagannath
Temple.
12. Cancellation of Settlement or Sale Obtained by Fraud.—(1) Any settlement,
sale, transfer, or regularisation of SJT land obtained through fraud, misrepresentation,
suppression of material facts, forged or fabricated documents, impersonation, or collusive
arrangements shall be liable to cancellation by the SJTMC on the recommendation of the
Competent Authority.
(2) No order of cancellation under sub-rule (1) shall be passed unless the person
concerned has been given a reasonable opportunity of being heard.
(3) Upon cancellation, the land shall re-vest in SJTA free from all encumbrances,
and any rights created there under shall stand extinguished.
(4) Cancellation under this rule shall be without prejudice to any civil, criminal, or
other legal proceedings that may be initiated against the persons responsible.
13. Digital Mapping of SJT Land and Information Management in Portal.—(1) The
SJTA, in consultation with the Department of Revenue and Disaster Management and the
concerned District Collectors, shall make endeavour to prepare a comprehensive digital
mapping and inventory of all SJT lands through Geographic Information System (GIS)
technology within such time as may be specified and shall maintain a publicly accessible
digital dashboard in portal containing details of SJT lands, including location, area,
classification, present status, encroachment status, auction notices, settlement status, and
such other particulars as may be specified, subject to restrictions relating to sensitive or
protected information.

<!-- page 9 -->

9

(2) The digital inventory and GIS records maintained under these rules shall be
periodically updated and verified by the District Collector concerned in co-ordination with
SJTA.
(3) The State Government may issue guidelines or Standard Operating Procedures
for implementation of GIS mapping, drone survey, geo-tagging, digital inventory
management, and integration of land records under these Rules.
(4) The GIS database and digital inventory prepared under this rule may be used for
prevention of encroachment, detection of unauthorized occupation, monitoring of litigation,
protection of temple properties, and planning for future institutional and religious
requirements of SJTA.
(5)The Portal shall, subject to such restrictions as may be specified for protection of
sensitive information, provide access to the applicants on following information, namely:
(a) Status of applications;
(b) Land particulars and classification;
(c) Recommendations of the District Level Land Sub-Committee (DLSC);
(d) List of approved and rejected applications along with reasons thereof;
(e) Auction and e-auction notices;
(f) Final settlement or sale orders; and
(g) Any other information as may be made available by SJTA.
(6) The Portal may be integrated with existing Bhulekh or Bhunaksha portal of R & DM
Department in respect to SJTA land for real-time updating.
14. Miscellaneous Provisions.— (1) The State Government may, after consultation with
SJTMC, issue Standard Operating Procedures or Guidelines for streamlining disposal of land
sale and settlement cases and for operation of the Portal.
(2) Each District Collector shall, make every endeavour to update land records
pertaining to SJT land in their District and cause entries to reflect 'Shree Jagannath
Mahaprabhu Bije- Puri marfat Shree Jagannath Temple Managing Committee' in the
Record of Rights where applicable.
(3) Each District Collector shall submit an annual action plan and annual
performance report to SJTMC indicating status of updating of land records, disposal status
of purchase or settlement cases, eviction of encroachments under sub-section (1) of
section 16-A, and recovery of certificate dues to make SJT land free from encumbrances.

<!-- page 10 -->

10

(4) Any officer having direct or indirect interest in the land shall recuse
himself/herself from the proceedings.
(5) In case of any ambiguity during implementation, clarification shall be obtained
from the State Government which shall be final.
(6) In order to determine the category of beneficiary, the status of the applicant shall
be taken into consideration irrespective of the status of the person from whom he derived
interest.
(7) For the purpose of determination of ceiling of area and valuation under these
rules, fragmented holdings, partitions, transfers, or applications made in the name of family
members, associates, agents, or related persons shall be aggregated and treated as a
single holding where the Competent Authority is satisfied that such fragmentation, transfer,
or arrangement has been effected with the intention of circumventing the ceiling limits or
valuation provisions applicable to Commercial Land.
(8)

Notwithstanding anything contained hereinbefore, the State Government in

consultation with SJTA may exercise the right to deny an alienation at any stage of the
application where the recommended land has been identified, reserved or protected by the
State Government or SJTA for religious, heritage, environmental, institutional, pilgrim,
tourism, or strategic public purposes connected with the administration and development
of Shree Jagannath Temple and its associated institutions.
15. Transitional and Saving Provisions.—(1) Applications pending as on the date of
commencement of these rules shall be processed under the provisions of this rule.
(2) Actions taken in good faith under the earlier Uniform Policy, 2003 and Amended
Uniform Policy, 2019 shall be validated unless otherwise set aside by a competent judicial
forum.
(3) Rejection of the application under Uniform Policy, 2003 and Amended Uniform
Policy, 2019 shall not be a bar for making a fresh application under this rule.
16. Appeal.— (1) Any beneficiary aggrieved by an order of the Competent Authority
under these rules may prefer an appeal before the Appellate Authority within 30(thirty)
days from the date of uploading of such order on the portal.
(2) Every memorandum of appeal shall be accompanied by a self attested copy of
the impugned order and copies of relevant documents relied upon by the appellant.

<!-- page 11 -->

11

(3) The Appellate Authority may, if satisfied that the appellant was prevented by
sufficient cause from filing the appeal within the prescribed period, condone the delay for
reasons to be recorded in writing.
(4) The Appellate Authority shall provide reasonable opportunity of hearing to the
appellant and to such other persons or authorities as may be considered necessary before
passing any order.
(5) The Appellate Authority may call for records from the concerned Authority,
undertake further enquiry if necessary, and pass such order as it deems proper, including
confirmation, modification, remand, or setting aside of the impugned order.
(6) Every appeal shall, as far as practicable, be disposed of within a period of 6(six)
months from the date of filing of the appeal.
(7) The order passed by the Appellate Authority shall be uploaded on the portal and
communicated to the appellant, the SJTA and the concerned Competent Authority.
(8) No appeal shall operate as an automatic stay of the impugned order unless
specifically ordered by the Appellate Authority.
(9) The Appellate Authority may dismiss any appeal summarily where the same is
found to be frivolous, vexatious, or not maintainable, for reasons to be recorded in writing.

<!-- page 12 -->

12

SCHEDULE-I
[See sub-rule(1) of rule 6]

Competent
Authority

Homestead Land

Agricultural Land

Collector

Upto
dec

Upto 1 Acre

NA

1 Acre to 2 Acre

NA

NA

Upto Ac 0.250 dec

RDC
Principal
Secretary to
Government,
Law Department

Ac

0.050

Ac 0.050 dec to
Ac 0.100 dec
Above 0.100 to
Ac 0.250 dec

Commercial Land

<!-- page 13 -->

13

SCHEDULE-II
[See sub-rule(1) of rule 7]

Homestead Land
1. Consideration value of Homestead Land with area upto Ac 0.100 dec shall be
assessed in the following manner:
Sl.
No.

Period
of Percentage of Bench Mark Valuation (BMV) or Average
occupation as Land Sale Statistics(ALSS) whichever is higher, to be paid
on 28.02.2019 at the following rates
By Non Sevaks

By Sevaks

By Sevak
Nijogas

1

Above 30
years

10%

5%

7.5%

2

20-30 years

15%

7.5%

10%

3

12-20 years

25%

12.5%

15%

2. Homestead Land beyond Ac 0.100 dec and upto Ac 0.250 dec. shall be assessed
as per BMV or ALSS valuation whichever is higher.

<!-- page 14 -->

14

SCHEDULE-III
[See sub-rule(1) of rule 7]

Agricultural Land
For settlement of agricultural land having flow of title from 1927 settlement or
applicable sabik settlement as the case may be shall be assessed as per the following
table;
Sl.
No.

Categories
beneficiaries

of Consideration Price to be fixed as per the
extent of land
Upto 1 Acre

1 Acre to 2 Acres

2

Sevakas

50% of BMV or ALSS BMV or ALSS
valuation whichever valuation whichever
is higher
is higher

3

Sevaka Nijog having BMV or ALSS
sevapuja
as
per valuation whichever
Record-of-Rights
is higher

Double of the BMV
or ALSS valuation
whichever is higher

[No.12653—JTA-MISC-04/2023/L.]
By Order of the Governor
PABITRA MOHAN SAMAL
Principal Secretary to Government

Printed and Published by the Director, Printing, Stationery and Publication, Odisha, Kataka-10
OGP/SBP Ex.Gaz.2910-183+200
