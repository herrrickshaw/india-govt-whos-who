---
doc_id: "cc8cffe7d12eca14"
source_url: "https://igitsarang.ac.in/assets/documents/notice/corrigendum_notice__1599296738.pdf"
ministry: "Indira Gandhi Institute of Technology, Sarang, Odisha"
title: "file_download"
date: ""
pages: 1
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "d789928fe0ca18cf"
---

<!-- page 1 -->

` INDIRA GANDHI INSTITUTE OF TECHNOLOGY
SARANG: DHENKANAL-759146
NO.IGIT/Aca &Exam/1680 Dated-04.09.2020
Corrigendum to notice No.IGIT/Aca. & Exam./1667/IGIT dtd.31.08.2020
In partial modification to this office notice No.IGIT/Aca. &
Exam./1667/IGIT dtd.31.08.2020, this is for information of all gt" semester
B.Arch. students that Semester Registration Fees be deposited as per details
given below:-
(i) Regular 9" semester B.Arch. students Rs.27,600/- instead of Rs.28,700/-
Students those who have taken study loan from different Banks are
advised to pay semester registration fee and Examination fee in the following
bank account through RTGS/NEFT system and upload the same in the Google
form and produce the original transfer slip with bank forwarding letter at the
time of reporting.
(i) Semester Registration fee for Regular B.Tech/ B.Arch/ M.Tech/
MCA/M.Sc. students - Bank A/c- No.37716788959 (Principal, IGIT,
Sarang, SBI IGIT, Sarang, IFS code No. SBIN0010246)
(ii) Semester Registration fee for B.Tech. Self Finance course students —
Bank A/c No.30471552713 (Principal S.F. Course IGIT, Sarang, SBI IGIT,
Sarang, IFS code No. SBINO010246)
(iii) ` Examination fees for all students- Bank A/c No.37718855596 ( Dean,
A&E, IGIT, Sarang, SBI IGIT, Sarang, IFS code No. SBINO010246)
Important for all students
All Students are advised to deposit the Registration and Examination fees
very carefully in SBI collect of IGIT, Sarang as per category mentioned in the
above referred notice/corrigendum and upload copy of the SB collect challan
NEFT & RTGS transfer slip and the original copy be submitted in concerned
department/section at the time of reporting in the Institute. Students those who
have change their branches from CSE/ETC to other branches will have to deposit
the registration fee under B.Tech. S.F. category.
| olc B Cue
Copy to:- 1, Institute Notice Boards for information of all concerned.
2. All HODs/HOOs for kind information & necessary action. _ ;
3. Accounts Officer for information & necessary action.
4. Prof G.Ghose, In-charge of Institute website for information & n.a.
5. P.A. to Director for kind information of Director.
