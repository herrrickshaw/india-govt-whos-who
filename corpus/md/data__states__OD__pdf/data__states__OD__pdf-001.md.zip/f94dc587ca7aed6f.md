---
doc_id: "f94dc587ca7aed6f"
source_url: "https://dfb.odisha.gov.in/sites/default/files/2023-02/Notification%20No.%202063%20dtd.%2023.02.2023.pdf"
ministry: "Directorate of Factories and Boilers, Odisha"
title: "Download(1.31 MB)"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "95d6447527297a67"
---

<!-- page 1 -->

GOVERNMENT OF ODISHA
LABOUR & E.S.I. DEPARTMENT
NOTIFICATION
Bhubaneswar, Dated the 2 3 - 2 - 2 3
No.LESI-LL2-FM-0008-2017- 2063/LESI, Whereas the draft of certain rules
which the State Government proposed to make in exercise of the powers conferred
by section 20 of the Dock Workers (Safety, Health and Welfare) Act, 198.6 (54 of
1986) was published as required under section 22 of the said Act in the Extraordinary issue of the Odisha Gazette No. 2771 dated the 26th September, 2022
under the notification of the Government of Odisha in Labour and ESI Department
No. LL2-FM-0008-2017-8036/LESI, dated 26th September, 2022, inviting
objections and suggestions from all persons likely to be affected thereby before
expiry of a period of forty-five days from the date of publication of the said
notification in the Odisha Gazette;
And whereas, no objection or suggestion has been received from any
person within the period so stipulated in respect of the said draft;
Now, therefore, in exercise of the powers conferred by section 20 of the
said Act, the State Government do hereby make the following rules, namely:1.

Short title, application and commencement. — (1) These rules may be

called the Odisha Dock Workers (Safety, Health and Welfare) Rules, 2023.
(2)

They shall apply to all ports other than the major ports in the State

of Odisha defined in the Major Ports Act, 1963 (38 of 1963).
(3)

They shall come into force on the date of their publication in the

Odisha Gazette.
2.

Definitions. — (1) In these rules, unless the context otherwise requires,(a)

"Act" means the Dock Workers (Safety, Health and Welfare) Act,
1986 (54 of 1986);

(b)

"Chief inspector" means Director of Factories and Boilers, Odisha;

(c)

"Government" means the Government of Odisha in Labour and
Employees State Insurance Department;

(d)

"Inspector" means Joint Director or Deputy Director or Assistant
Director of Factories and Boilers;

<!-- page 2 -->

(e)

"other ports" mean all ports other than the major ports in the State
of Odisha;

(0

"regulations" means the Odisha Dock Workers (Safety, Health and
Welfare) Regulations, 2023; and

(g)
(2)

"section" means section of the Act.

All other words used in these rules and not defined but defined in the Act

or the regulations shall have the same meaning respectively assigned to them in
the Act and regulations.
3.

Inspection procedure. — An Inspector shall exercise the powers conferred

upon him under the Act and the regulations.
4.

Notice to employer. — The Inspector shall, after every inspection visit, as

may be deemed necessary, issue an improvement notice or a prohibition notice
pointing out the non-compliance of the provisions of the Act or the regulations to
the owner or master or officer-in-charge of the ship or their agent or the employer
of the dock workers in Form IX appended to the regulations.
5.

Compliance of previous inspection reports. — An Inspector shall, at each

inspection, ascertain to what extent any shortcomings notified in a previous
inspection have been rectified and the notices previously issued have been
complied with and his findings and any shortcomings which may come to light
during the inspection, together with any order passed by him under the Act or the
regulations shall be recorded in an inspection register required to be maintained
for the purpose.
6.

Notice. — Any notice or order required or intended to be served under the

Act or the regulations, may be served, —
(a)

on any person by delivering it to him, or by leaving it at, or sending

it by Registered Post or e-mail to the ship, premises or registered office as
the case may be;
(b)

on any firm by delivering it to any partner of the firm or by leaving

it at, or sending it by Registered Post to the office of the firm; or

2

<!-- page 3 -->

(c)

on any company by delivering it to any of the directors or the

person in charge of operations in the dock premises or by sending it by
Registered post to the office of the company.
7.

Show cause notice.— An Inspector may, as deemed necessary, issue show

cause notice and prohibition order and prosecute the port authority, firm or
company, who by himself or through his agent is responsible for non-compliance
of the provisions under the Act and the regulations.
8.

Inquiry into causes of accidents.— An Inspector shall conduct inquiry into

causes of any accident or dangerous occurrence, which he has reason to believe
was caused as a result of collapse or failure of lifting appliance, loose gear,
transport equipment etc., or non-compliance with any of the provisions of the Act
or the regulations.
9.

Advisory Committee.—(1) The Advisory Committee under section 9 shall

be constituted to advise upon such matter arising out of the administration of the
Act and the regulations. The Advisory Committee shall consist of the following
nine members to be appointed by the State Government, namely:(i)

The Chief Inspector and other two members representing the State

Government;
(ii)

Three members representing organisation of employers of dock

workers as the State Government may consider appropriate; and
(iii)

Three members representing organisations of dock workers, as the

State Government may consider appropriate :
Provided that any vacancy occurring in the Advisory Committee
shall, as soon as possible, be filled by the State Government by appointing
new members representing the organization as provided in this sub-rule :
Provided further that the State Government may remove any
member from the Advisory Committee, without assigning any reasons.
(2)

The Chief Inspector shall be the Chairman of the Advisory Committee.

(3)

The members of the Committee shall be appointed for a period of three

years.

3

<!-- page 4 -->

(4)

An officer of the organization of the Chief Inspector shall function as the

Secretary to the Advisory Committee and shall be entitled to attend and take part
in the meetings of the Committee, but he shall not have a right to vote.
(5)

The Chairman shall convene meetings of the Advisory Committee as often

as considered necessary, by giving notice of at least 15 (fifteen) days and the
Chairman shall also forward to the members the agenda for the meeting before the
meeting is held.
(6)

The decision taken by the Committee shall be forwarded by the Chairman

to the State Government, along with comments and recommendations on the
actions to be taken thereon.
(7)

A report of the action taken on the decisions of the Advisory Committee

shall be presented to the Committee by the Chairman at its next meeting.
10.

Inquiry Procedure.— (1) Any competent person appointed by the State

Government for the purpose of inquiring into the causes of any accident, diseases
connected with dock work under the provisions of section 10 shall make inquiry in
the following manner, namely:(a) Date, time and place of holding the inquiry shall be fixed and may be
varied, notice of which shall be given not less that thirty days in writing of
such date, time and place to every person entitled to appear at the inquiry
whose name and address are known to the competent person:
Provided that with the consent of all such persons, the competent
person may give such lesser period of notice as shall be agreed to with
those persons:
Provided further that where it becomes necessary or advisable to
vary the time or place fixed for the inquiry, the competent person shall give
such notice of the variation as may appear to it to be reasonable in the
circumstances.
(b) The notice given under clause (a) of this sub-rule shall state the name of
the competent person and the names of assessors, if any, appointed to assist
the competent person in the inquiry.
(2)

Without prejudice to the provisions of sub-rule (1), the competent person

shall also for the purpose of notifying to the persons who may in any way be

4

<!-- page 5 -->

•
concerned with the subject matter of the inquiry, take one or more of the following
steps, namely:(a) publish notice of the inquiry in one or more newspapers, including
where appropriate, newspapers circulating in the locality or area in which
the subject matter of the inquiry arose; and
(b) give such other notice of the inquiry as appears to the competent person
to be appropriate and the requirements as to the period of notice contained
in clause (a) of sub-rule (1) shall not apply to any such notices.
11.

Persons to appear at inquiry.— (1) The persons entitled to appear at the

inquiry shall be,(a) any competent person under sub-rule (1) of rule 10;
(b) any enforcing authority concerned;
(c) any employers' association or trade union of employees;
(d) any person who was injured or suffered damage as a result of the
accident of occurrence, situation, disease or other matter which is
the subject of the inquiry, or his representative;
(e) the owner of any premises in which the accident, occurrence,
situation or other matter occurred or arose;
(f) any person carrying on dock work giving rise to the accident,
occurrence, situation or other matter which is the subject of the
inquiry; and
(g) any other person at the discretion of the appointed competent
person.
(2)

The following shall represent at the inquiry, —
(a) a corporate body may be represented by its secretary or by any
other officer appointed for the purpose, or by a counsel or solicitor;
or
(b) a Government Department, an employers'association or a trade
union may be represented by a counsel or solicitor; or
(c) where there are two or more persons having a similar interest in
the matter under inquiry, the competent person may allow one or
more persons to appear for the benefit of some or all persons so
interested.

<!-- page 6 -->

•
(3)

The competent person appointed by the State Government under section

10, may, either of his own motion or on the application of any person entitled or
permitted to appear, cause to be served on any person appearing to him to be likely
to be able to give material evidence or to produce any document likely to be
material evidence, a notice requiring that person to attend at the inquiry at the time
and place specified in the notice to give evidence or produce the document.
(4)

A person on whom a notice is served under sub-rule (3) may apply to the

competent person either at or before the inquiry to vary or set aside the
requirement, and where he does so before the inquiry he shall give notice of his
application to the person, if any, who applied for the notice under sub-rule (3) to
be served.
(5)

Except as otherwise provided in these rules, the procedure at and in

connection with an inquiry shall be at the discretion of the competent person who
shall state at the commencement of the hearing the procedure which, subject to
consideration of any submission by the persons appearing at the inquiry, he
proposed to adopt and shall inform those persons what he proposes as regards any
site inspection arising out of the hearing.
(6)

Except as provided in the sub-rule (1) of rule 12, the inquiry shall be held

in public.
12.

Inquiry in public.— (1) The competent person appointed by the State

Government under section 10 shall conduct the inquiry under rule 10 in public,
unless:(a) the State Government is of the opinion that the matters of the inquiry or
any part of it are of such nature that it would be against the interests of
national security to hold the inquiry in public and directs the competent
person to hold the inquiry in camera; or
(b) on an application made to him by any party to the inquiry, decides to
hold the inquiry or such part of it in camera, if he is of the opinion that the
holding of pulic inquiry will lead to disclosure of information relating to a
trade secret:
Provided that information disclosed to any person by hearing of
evidence in the circumstances mentioned in clause (a) or clause (b) shall
not be disclosed by him except for the purpose of the inquiry.
6

<!-- page 7 -->

(2)

Persons entitled or permitted to appear shall be heard in such order as the

competent person appointed by the State Government under section 10, may
determine.
(3)

Persons entitled to appear shall be entitled to make an opening statement,

to call evidence and to cross-examine persons giving evidence, but any other
person appearing at the inquiry may do so only to the extent permitted by the
competent person appointed by the State Government under section 10.
(4)

Where the competent person appointed by the State Government under

section 10 so requires, witnesses shall give evidence on oath, and for that purpose
he may administer an oath in due form.
(5)

Any evidence may be admitted at the discretion of the competent person

appointed by the State Government under section 10, who may direct that
documents to be tendered in evidence may be inspected by any person entitled or
permitted to appear at the inquiry and that facilities be afforded to him to take or
obtain copies thereof.
(6)

The competent person appointed by the State Government under section

10, shall be entitled, subject to disclosure thereof at the inquiry and making
available copies thereof to the persons appearing at the inquiry, to take into
account any written representation or statement received by him before the inquiry
from any person.
(7)

The competent person appointed by the State Government under section 10

may from time to time adjourn the inquiry and where he does so shall give
reasonable notice to every person entitled or permitted to appear at the inquiry of
the date, time and place of the adjourned inquiry:Provided that where the date, time and place of the adjourned inquiry are
announced at the inquiry, no further notice shall be required.
(8)

The competent person appointed by the State Government under section 10

and any person appointed to assist him in the inquiry may, where necessary for the
purpose of the inquiry, at any reasonable time enter and make an inspection of any
ship or premises to which the inquiry relates and any thing in them.
(9)

The competent person appointed by the State Government under section 10

shall after the close of inquiry make a report in writing to the State Government,
which shall conclude the findings of the facts and his recommendations, if any, or
his reasons for making any recommendation.
7

<!-- page 8 -->

(10) Except where the said report is to be published, in whole or in part, the
State Government shall send to any person, who appeared at the inquiry, a copy of
the report or so much of it as the competent person appointed by the State
Government under section 10 thinks fit.
By order of the Governor

cf›

(R. • s • Ci opoLlAr-h)
Commissioner-cum-Secretary to Government

Memo No. 20 6 4-1 /LESI, Dated 2 3 • 2 .23
Copy forwarded to the Director, Printing, Stationery and Publication,
Odisha, Cuttack with a request to publish this notification in an extraordinary issue
of odisha Gazette.

Additional
Memo No. 266 5 /LESI, Dated 2 3 , 2 -23
Copy forwarded to all Departments for information and necessary action.

Additional S

' overnment

/LESI, Dated 23,2 - 23
Memo No. 2 6
Copy forwarded to the Director of Factories & Boilers, Odisha / Director,
Ports and Inland Water Transport, Odisha for kind information and necessary
action.

Additional

8

rnment
