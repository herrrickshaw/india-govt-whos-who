---
doc_id: "1aa9fa88a11fdc5b"
source_url: "https://msme.odisha.gov.in/sites/default/files/2020-10/OKVIB%20Resolution%201960.pdf"
ministry: "Micro, Small and Medium Enterprises (MSMEs) Department, Odisha"
title: "Download(194.77 KB)"
date: ""
pages: 27
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5e48a6a63d796d0d"
---

<!-- page 1 -->

The Orissa Khadi and Village Industries Board Regulations, 1960
Published vide Notification No. 10525-OK and UIB, dated 29th August, 1960,
Orissa Gazette Part 3/2-10-1960
or452
Notification No. 10525-OK and UIB, dated 29th August, 1960. - In exercise of
the Powers conferred by Section 36, of the Orissa Khadi and Village Industries
Board Act, 1955 (Orissa Act No. 3 of 1956), and with the previous sanction of the
State Government in this behalf, the Orissa Khadi and Village Industries Board do
hereby make the following, regulations, namely :
1. Short title and commencement.- (1) These regulations may be called the
Orissa Khadi and Village industries Board Regulations, 1960.
(2) They shall come into force at once.
2. Definitions.- (1) In these regulations, unless there is anything repugnant in the
subject or context(i) "Government" means the Government of Orissa;
(ii) "Fund" means the fund constituted under Section 23 of the Orissa Khadi and
Village Industries Board Act, 1955 (Orissa Act No. 3 of 1955);
(iii) "Provident Fund" means the fund specified in Regulation No. 53;
(iv) "disciplinary authority" means the authority competent under the regulations
to impose a penalty on an employee of the Board.
(2) All other words and expressions used but not defined in these regulations shall
have the meanings respectively assigned to them in the Orissa Khadi and Village
Industries Board Act, 1955 (Orissa Act No. 3 of 1956) and the rules made
thereunder and the respective codes and rules of the Government of Orissa.
(3) Government reserve the right either to suspend or modify any of the provisions
in the Regulations if at any time it is considered so expedient.
3. Application.- (1) These regulations apply to all employees.

<!-- page 2 -->

(2) Nothing in these regulations shall operate either to deprive any person of any
right or privilege to which he is entitled by or under any law or by the terms of any
contract or agreement subsisting between Such persons and the Board or to confer
on him any right or privilege in respect of any matter for which specific provision
is made by the terms of any contract or agreement between himself and the Board.
4. Interpretation.- If any matter relating to the interpretation of these
regulations arises, the same shall be referred to the President whose decision
thereon shall be final.
5. Custody of common seal.- The common seal shall remain in the custody of
the President. The President may by written orders delegate the custody of the
seal to the Secretary.
6. Channel of correspondence.- The Secretary and subject to his control, the
Deputy Secretary and Assistant Secretary shall carry out all correspondence
on behalf of the Board.
All correspondence emanating from the Board shall be in the name of the Secretary
and all correspondences with the Board shall be addressed to the Secretary.
7. The Secretary.- The Secretary of the board shall be an officer of the State
Government employed as such in ex officiocapacity and his conditions of
service will be regulated under the relevant rules of the Government.
8. Classification of employment.- (1) The employees of the Board shall fall
under two categories, namely, (1) regular establishment; and (2) schematic
establishment.
[(2) All posts under the Board shall be classified by the Board into Class I, Class
II, Class III and Class IV as specified in Schedule I hereto annexed.
Provided that at the tine of creation of a new post not mentioned in Schedule I, the
Board will specify the class under which the post will be included.]
[9. Authorities. - Appointment to the different classes of posts under the Board
specified in Column 1 of Schedule thereto appended shall be made by the
authorities specified in Column 2 thereof. The authorities specified in Columns 3
and 5 of the Schedule shall be the disciplinary authority and this appellate authority
respectively in regard to penalties specified in Regulation 29 and referred to in
Column 4 of the said Schedule.]
10. Probation.- Every appointment to a post in regular establishment in Classes I,
II and III, shall be subject to probation or trial for a period of one year which
is liable to be extended further by the appointing authority at his discretion. A

<!-- page 3 -->

person who has successfully, completed his period of probation shall be
confirmed at the earliest opportunity.
11. Termination of probation.- The appointing authority may before the expiry
of the period of probation or trial, for reasons to be, recorded in writing,
terminate the probation of any person and revert him to his permanent post
under the Board or discharging him from service of the Board, if he is a direct
recruit. In the latter case a notice of one month shall be given before discharge
or the employee shall be paid one month's emolument in lieu thereof. If any
leave is granted, the period of notice and leave should run concurrently and for
this purpose "emoluments" shall include "leave allowances".
12. Disqualification for appointment.- Any person who has been convicted of
offences involving moral turpitude or who has been dismissed from the
service of the Central or State Government or of any local authority or any
person who has been declared medically unfit, shall be disqualified for
appointment under the Board.
13. Certificates.- Every person appointed for the 1st time to a post in regular
establishment of the Board, shall produce certificate of age and health before
the Secretary. The medical certificate shall be in the following form and it
shall be annexed to the first bill submitted for the pay of the person concerned.
"I hereby certify that I have examined A. B., a candidate for employment
as................ under the Orissa Khadi and Village Industries Board and cannot
discover that he/she has any disease (communicable or otherwise), constitutional
weakness or bodily infirmity, except...........I do not consider this a disqualification
for employment in the office of........A.B.'s age is according to hit own
statement..........years and by appearance about years.
Medical Officer"
14. Security.- The Board shall demand such security, as it may consider
necessary, from any employee of the Board, but the amount of the security so
demanded shall not exceed the amount of cash as handled by the employee.
The rules laid down in the Orissa General Financial Rules Volume I, in this behalf
shall be followed mutatis mutandis in matters relating to security deposit. For this
purpose, the words "State Government", "Government servant" and "Head of
Department" wherever they occur shall mean "the Board", "the employees of the
Board" and "the President" respectively.
[15. Retirement. - (1) A Board employee may retire from service any time after
completing thirty years' qualifying service or on attaining the age of fifty years, by
giving notice in writing to the appropriate authority at least three months before the
date on which he/she wishes to retire or by giving the said notice to the said

<!-- page 4 -->

authority before such shorter period as the Board may allow in any case. It shall be
open to the appropriate authority to withhold permission to retire to an employee
who seeks to do so under this rule, if he/she is under suspension or if enquiries
against him/her are in progress. The appropriate authority may also require an
officer to retire in public interest any time after he/she has completed thirty years
qualifying service or attains the age of fifty years, by giving a notice in writing to
the said employee at least three months before the date on which he/she is required
to retire or by giving three months' pay and allowance in lieu of such notice :
Provided that a review shall be conducted in respect of the Board employee on
completion of thirty years of qualifying service or fifty years and fifty-five years of
age in order to determine whether he or she should be allowed to remain in service
up to the date of the completion of the age of fifty-eight years or retired on
completion of fifty years or fifty-five years, as the case may be. The Review
Committee will consist of the following members :
(i) Director of Industries, Orissa
(ii) Deputy Secretary to Government, Industries Department;
(iii) Secretary, O.K. and V.I. Board.
(2) Except as otherwise provided above, the date of compulsory retirement of an
employee of the Board, except Class IV employees, is the date on which he or she
attains the age of fifty-eight years. The age of compulsory retirement of an
employee belonging to Class IV is 60 years.]
16. Service Book.- (1) A Service Book shall be maintained in such form, as
prescribed by the State Government for their employees, for every officer or
servant of the Board. The service book will be a record of the service and shall
Contain no remarks on work or conduct.
(2) The Secretary or any other appointing authority under him shall be responsible
for the correct and up-to-date maintenance of the service book. He shall record an
annual certificate of verification in the service books relating to the employees
under him as early as possible after the end of every year.
17. Character roll.- In addition to a service book, a character roll shall be
maintained by the head office namely Secretary or any other appointing
authority or the head of any Organisation, of a Scheme as shall be determined
by the President. A character roll shall be maintained in such form as

<!-- page 5 -->

prescribed by the Board with the approval of Government for their employees
in which shall be entered censures, punishments and commendations. Adverse
remarks against an employee, if any, shall be communicated to him. It shall be
treated as a confidential record. It shall contain a yearly report on the work of
the employee concerned. Every year in the month of April the Head of the
office shall enter his report on the work of each employee under him in regard
to the preceding year. The report shall be forwarded to the President through
the Secretary who will record his comments with his signature and date.
Reports of all employees with the comments of the President shall then be
deposited with the Head of the office for safe custody.
18. Promotion and efficiency.- (1) All promotions to higher grades or ranks shall
be on the basis of merit and ability. None shall be promoted who is not on the
basis of his record and in the opinion of the appointing authority fit for
promotion and of those who are fit only the fittest shall be promoted to any
particular vacancy, the factor of seniority being taken into account only when
all other factors and particularly the factor of merit are equal.
(2) There shall be no bar for reverting an employee from a higher post to which he
may have been promoted on an officiating or trial basis, if he is not found up to the
mark.
(3) Efficiency bars in the time-scales of pay shall be rigorously applied and none
shall be allowed to cross a bar unless the Head of the office is satisfied that he has
attained a reasonable standard of efficiency.
(4) Annual or periodical increments in pay scales shall not be allowed as a matter
of course, and normally an employee who has been adversely reported on, during a
year shall not be allowed his increment until he earns a good report.
19. Advance increment.- The Board may, in exceptional circumstances, grant an
increment in advance to an employee in consideration of his special
qualifications or experience or of other reasons.
20. Establishment list.- The Secretary shall early in April each year, prepare a
detailed statement of all posts in the regular establishment under the Board
existing on the 1st April.
21. Seniority.- The relative seniority of employees in any grade shall be
determined according to the dates of continuous appointment to that grade.
Employees promoted on the same date shall keep the position inter sewhich
they held in the lower grade from which they were promoted. Seniority of
persons appointed from outside at the same time shall be determined
according to the order of merit or preference indicated at the time of selection
for appointment.

<!-- page 6 -->

22. Reduction of establishment.- When any post or posts are abolished, persons
shall be selected for discharge or reversion on the basis of juniority, unless for
reasons to be recorded the services of any person are considered indispensable
by the Board.
Explanation - An appointment, the pay of which is reduced, shall be deemed to be
abolished within the meaning of this regulation.
23. Order for abolition of posts.- (1) An order for abolition of a post or for
reduction of the emoluments of an appointment shall not be brought into
operation, in the case of a permanent employee of regular establishment,
before the expiry of 3 months after the notice has been given to the employee
affected and in other cases before the expiry of one month after the service of
the notice ;
Provided that no officer or servant shall be discharged on the abolition of any
appointment unless he cannot be provided for otherwise.
(2) In the case of an employee on leave, the order shall not be brought into
operation before the leave expires, but the leave and the period or notice should run
concurrently.
24. Schematic establishment.- Schematic establishment includes such staff as
may be entertained for execution of particular schemes sanctioned by the
Board from time to time and does not form part of the permanent and regular
establishment of the Board; provided that the Board may declare any person or
group of persons forming part of the schematic establishment to be treated as
members of the regular establishment for purpose of leave, retirement benefits
and such other benefits as provided in these regulations for the regular
establishment.
25. The engagement of members of schematic establishments who are appointed
for a specific work, lasts only for the period during which the work lasts. If
discharged, otherwise than for serious misconduct before the completion of
the work for which they are engaged, they are entitled to a month's notice or a
month's pay in lieu of notice but otherwise, with or without notice, their
engagement terminates when the work ends or the scheme is completed. If
they desired to resign their appointments, they must give a month's notice of
their intention to do so, failing which they will be required to forefeit a
month's pay in lieu of such notice. The terms of engagement should be clearly
explained to the persons employed in circumstances mentioned above.
26. The members of the schematic establishment are entitled to leave salary as
admissible to temporary Government servants but they are not entitled to leave

<!-- page 7 -->

salary or travelling or other allowances or to any retirement benefits as
admissible to permanent Government servants except in the following cases :
(a) Leave with full pay on Sundays and other holidays as declared by the Board;
(b) Travelling allowance under Regulation 41 may be allowed by the Secretary for
journeys performed in the interest of the work on which they are employed.
Note - This regulation is not intended to interfere with the discretion of the
Secretary or any other officer authorised by him to grant short casual leave on full
pay or on reduced wages subject to such general rules regarding the grant of casual
leave to regular establishment as may be prescribed by the Board.
27. Transfer of members of regular establishment to schematic
establishment.- The Secretary may, in the interest of the work of the Board,
transfer an employee of the regular establishment to a schematic establishment
for any period ; provided that all his prospects and privileges of service in the
regular establishment shall be protected for so long as he would have
continued, but for his transfer to schematic establishment to hold a post in the
regular establishment.
28. Suspension.- (1) The appointing authority or any authority to which it is
subordinate or any other authority empowered in that behalf by the President
may place an employee of the Board under suspension(a) where a disciplinary proceeding against him is contemplated or is pending, or
(b) where a case against him in respect of any criminal offence is under
investigation or trial.
(2) An employee of the Board who is detained in custody, whether on a criminal
charge or otherwise, for a period exceeding forty-eight hours, shall be deemed to
have been suspended with effect from the date of detention, by an order of the
appointing authority and shall remain under suspension until further orders.
[29. Punishment. - Subject to the provisions of these regulations the following
penalties may for good and sufficient reasons and as hereinafter provided, be
imposed oil an employee of the Board, namely :
(i) Fine;
(ii) Censure;

<!-- page 8 -->

(iii) Withholding of increment or promotion;
(iv) Recovery from Day of the whole or any part of any pecuniary loss caused to
Board by negligence or breach of orders;
(v) Suspension;
(vi) Reduction to a lower service grade or post or to a lower timescale or to a lower
stage in a time-scale;
(vii) Compulsory retirement;
(viii) Removal from the service of the Board which does not disqualify from future
employment;
(ix) Dismissal from the service of the Board which ordinarily disqualifies from
future employment :
Provided that the penalty of fine shall be imposed only on Class IV employees.
Explanation - The following shall not amount to a penalty within the meaning of
this rule :
(1) Non-promotion of an employee of the Board after consideration of his case to a
grade or post for promotion to which he is eligible;
(2) Reversion to a lower grade or post of an employee officiating in a higher grade
or post on the ground that he is considered after being tried in the said grade or
post to be unsuitable for such higher grade or post or on administrative grounds
unconnected with his conduct;
(3) Reversion to his permanent grade or post of an employee appointed on
probation or on trial basis to another grade or post during or at the end of the
period of probation or trial in accordance with the terms of his appointment;
(4) Replacement of services of an employee whose services have been borrowed
from Government or any authority under the control of Government, or a local
Government at the disposal of the authority which had lent his services;

<!-- page 9 -->

(5) Termination of the service of the employee appointed on probation or trial
during or at the end of the period of probation or trial or of a person employed
under an agreement in accordance with the terms of such agreement;
(6) Compulsory retirement of an employee in accordance with the provisions
relating to his superannuation or retirement.]
30. Procedure for imposing major penalties.- Without prejudice to the
provisions of the Public Servants (Enquiry) Act, 1850, no order imposing any
of the penalties specified in Clauses (v) to (vii) of Regulation 29 shall be
passed on an employee of the Board (other than an order based on facts which
have led to his conviction in a criminal Court) unless he has been informed in
writing of the grounds on which it is proposed to take action, and has been
afforded an adequate opportunity of defending himself. The grounds on which
it is proposed to take action shall be reduced to the form of a definite charge or
charges which shall be communicated to the person charged together with a
statement of the allegations on which each charge is based and in any other
circumstances which it is proposed to take into consideration in passing orders
on the case. He shall be required within a reasonable time, to put in a written
statement of his defence and to state whether he desires to be heard in person.
If he so desires, or it the authority concerned so directs, an inquiry shall be
held. At that enquiry oral evidence shall be heard and recorded as to such of
the allegations as are not admitted and the person charged shall be entitled to
cross-examine the witnesses, to give evidence in person and to have such
witnesses called as he may wish ; provided that the Inquiring Officer may, for
special and sufficient reasons to be recorded in writing refuse to call a witness.
The proceedings shall contain a sufficient record of the evidence and a
statement of the findings and the grounds thereof. The disciplinary authority
shall, if it is not the inquiring authority, consider the record of the inquiry
record its findings on each charge and pass appropriate orders on the case.
The regulation shall not apply where the person concerned has absconded, or
where for other reasons impracticable to communicate with him. All or any of the
provisions of this regulation may, in exceptional cases, for special and sufficient
reasons to be recorded in writing, be waived, where there is a difficulty in
observing exactly the requirements of the regulation and those requirements can be
waived without injustice to the person charged.
31. Procedure for imposing minor penalties.- No order imposing any of the
penalties specified in Clauses (i) to (iv) of Regulation 29 shall be passed
except after the employee is informed in writing of the proposal to take action
against him and of the allegations on which it is proposed to be taken and

<!-- page 10 -->

given an opportunity to make any representation, if any, taken into
consideration by the disciplinary authority.
32. Appeals.- An employee of the Board may appeal against an order of
suspension or an order imposing upon him any of the penalties specified in
Regulation 30 to the authority specified in this behalf either in Schedule II or
by a general or special order or where no such authority is specified, to the
authority to which the authority imposing the immediately subordinate.
33. Period of limitation for appeals.- No appeal shall be entertained unless it is
submitted within a period of three months the date on which the appellant
receives a copy of the order appealed against :
Provided that the appellate authority may entertain the appeal after the expiry of
the said period, if it is satisfied that the appellant had sufficient cause for not
submitting the appeal in time.
34. Form and contents of appeal.- (1) Every person submitting an appeal shall
do so separately and in his own name.
(2) The appeal shall be addressed to the authority to whom the appeal lies, shall
contain all material statements and arguments on which the appellant relies, shall
not contain any disrespectful or improper language, and shall be complete in itself.
35. Submission of appeal.- An appeal shall be submitted through the Head of the
office to which the appellant belongs or belonged and through the authority
from whose order the appeal is preferred and shall be accompanied by a copy
of the orders appealed against.
36. Withholding of appeals.- (1) The authority which made the order appealed
against may withhold the appeal if(i) it is an appeal against an order from which no appeal lies ; or
(ii) it does not comply with any of the provisions of Regulation 34; or
(iii) it is not submitted within the period specified in Regulation 33 and no cause is
shown for the delay ; or
(iv) it is a repetition of an appeal already decided and no new facts or
circumstances are adduced :
Provided that an appeal withheld on the ground only that it does not comply with
the provisions of Regulation 34 shall be returned to the appellant and if re-

<!-- page 11 -->

submitted within one month thereof after compliance with the said provisions,
shall not be withheld.
(2) Where an appeal is withheld, the appellant shall be informed of the fact and the
reasons therefor.
37. Transmission of appeal.- (1) The authority which made the order appealed
against shall without any avoidable delay, transmit to the appellate authority
every appeal which is not withheld under Regulation 34, together with its
comments thereon and the relevant records.
(2) The authority to which the appeal lies may direct transmission to it of any
appeal withheld under Regulation 36 and thereupon such appeal shall be
transmitted to that authority together with the comments of the authority
withholding the appeal and the relevant records.
38. Consideration of appeals.- (1) In the case of an appeal against an order of
suspension, the appellate authority shall consider whether in the light of the
provisions of Regulation 28 and having regard to the circumstances of the case
the order of suspension is justified or not and confirm or revoke the order
accordingly.
(2) In the case of an appeal against an order imposing any of the penalties specified
in Regulation 29, the appellate authority shall consider(a) whether the procedure prescribed in these regulations has been complied with,
and, if not, whether such non-compliance has resulted in failure of justice;
(b) whether the findings are justified; and
(c) whether the penalty imposed is excessive, adequate or inadequate; and, after
such consideration pass such orders as it thinks proper.
39. Implementation of orders in appeal.- The authority which made the order
appealed against shall give effect to the orders passed by the appellate
authority.
40. General conditions of service.- Unless otherwise provided in these
regulations, the rules in the Orissa Service Code, Volume I with all its
Appendices, except Appendices 1 to 4, 8 and 12, as amended from time to
time by the Government shall apply to the employees of the Board mutatis
mutandis. For this purpose, the words "Government", "Government servant"
and "Head of Department" wherever they occur except in Chapter-I of the

<!-- page 12 -->

Code shall mean "the Board" "the employees of the Board" and "the
President" respectively. "Superior Service" referred to in the Orissa Service
Code shall mean posts in Classes I, II and III and "Inferior Service" shall mean
posts in Class IV.
41. Travelling allowance.- The Orissa Travelling Allowance Rules, as amended
from time to time by Government shall be applicable to the officer and
servants of the Board in the same manner as applicable to Government
servants of similar standing and status. "Government", "Government servant"
and "Head of Department" wherever they occur in the rules shall mean
respectively "The Board", "Employees of the Board" and "the President".
42. Grant of leave.- The employees of the Board shall be governed by the Orissa
Leave Rules, 1939 as amended from time to time by Government.
[43. Advance. - (1) Motor Car advance - The Orissa Khadi and Village Industries
Board may in the interest of the Board, sanction an advance for purchase of motor
car to a Board employee whose monthly basic pay is not less that Rs. 1,200 ;
provided that such an advance may also be sanctioned to a Board employee whose
monthly basic pay is not less than Rs. 1,000 where in the opinion of the Board the
employee is required to make official tours for not less than 7 days in a month.
(ii) Limit of advance-The maximum limit of the advance for purchase of motor car
shall be Rs. 30,000 or 20 monthly pay of the employee or the anticipated price of
the motor car, whichever is the least :
Provided that in case of second and subsequent advance the Board employee will
be eligible to the difference between the maximum admissible limit and the sale
proceeds of the old vehicle left over with employee after repayment of the earlier
outstanding advance including interest.
(iii) Recovery - The principal will be recovered into more than 100 consecutive
monthly instalments and the interest in subsequent 22 consecutive monthly
instalments. The recovery of interest will commence from the month following that
in which the whole of the principal has been repaid. A loanee, however, if he so
desires be permitted to repay the advance In a smaller number of instalments.
(iv) Rate of interest-The rate of interest chargeable on such advance is 8 per
cent per annum.
(v) Time-gap-The time-gap between the first advance and the subsequent advance
shall be at least 5 (five) years. The period of five years shall count from the date of
sanction of the last advance.

<!-- page 13 -->

(2) Motor cycle/scooter advance-(i) Criteria-The Orissa Khadi and Village
Industries Board may, in the interest of Board, sanction an advance for purchase of
motor cycle/scooter to a Board employee whose monthly basic pay is not less than
Rs. 600 :
Provided that such an advance may also be sanctioned to a Board employee whose
monthly basic pay is not less than Rs. 400 if in the opinion of the Board, the
employee is required to perform official tour for not less than 7 days in a month.
(ii) Limit of advance - The maximum limit of the advance for purchase of
motorcycle/scooter shall be Rs. 6,000 or the cost of the vehicle whichever is less:
Provided that in case of second and subsequent advances the Government servant
will be eligible to the difference between the maximum limit of Rs. 6,000 and the
sale proceeds of the vehicle left over with the Government servant after repayment of the earlier outstanding advance including interest.
(iii) Recovery-The principal will be recovered in not more than 60 consecutive
monthly instalments and the interest in maximum 8 consecutive monthly
instalments. The recovery of interest will commence from the month following the
one in which the whole of the principal has been repaid.
(iv) Rate of interest-The rate of interest chargeable on such advance is 7 per
cent per annum.
(v) Time-gap-The time-gap between the first advance and the subsequent advance
shall be at least 4 (four) years. The period of four years shall count from the date of
sanction of the last advance.
Notes - (i) If actual price paid both for motor car/cycle excluding cost of insurance,
transportation from the place of purchase or subsequent repairs is less than the
advance taken, the balance shall forthwith be refunded to Government, though the
mortgage bond should be for the full amount drawn from the Treasury.
(ii) The amount of advance for purchase of motor car/cycle/scooter the manner of
its recovery, etc. shall be prescribed by Board from time to time basing on the
orders issued by Government in Finance Department;
(3) (i) Bicycle advance-Bicycle advance can be granted to all intending Class II
and Class IV employees of the Board.

<!-- page 14 -->

(ii) Limit of advance-The maximum limit of advance for purchase of bicycle shall
be Rs. 300 or the cost of the cycle whichever is lower.
(iii) Recovery - In case of Class III employees of the Board the Principal will be
recovered in maximum of 15 consecutive monthly instalments and interest in 1
(one) instalment. But in case of Class IV employees the Principal will be recovered
in maximum of 30 consecutive monthly instalments and interest in subsequent 1
(one) instalment.
(iv) Rate of interest-The rate of interest chargeable on such advance is six and half
per cent per annum. The time-limit between the first and subsequent advance shall
be at least 3 (three) years.
(v) Time-gap-The period of 3 years shall count from the date of sanction of the last
advance.
(4) All such advance may be sanctioned to a permanent or a temporary employee,
but in case of a temporary employee, a surety bond shall be furnished from a
permanent employee of the Board not below the rank of the loanee.]
44. to 46.[* * *]
45. Transfer of motor car or cycle.- Except when he proceed on long leave or
retires from the services of the Board, an officer or servant who has purchased
a motor car, or motor cycle with the aid.of an advance granted under these
regulations which has not been fully repaid, shall not transfer such car or cycle
without the previous sanctions of the Board. The Board may permit such
transfer to an officer to whom it might grant an advance under Regulation 44;
provided that such officer or servant makes a declaration acknowledging that
he is aware, that the car or cycle transferred to him remains subject to the
mortgage bond executed under Regulation 50 and that he is bound by its terms
and provisions.
46. An officer or servant who Sells a motor car, or motor cycle before the advance
that has been granted to aid for its purchase has been fully repaid, shall
immediately after such sale apply the sale proceed, or such portion thereof, as
may be necessary, to the payment of the amount of the advance still unpaid;
provided that when the car or cycle is sold only in order that another car or
cycle may be purchased, the Board may permit an officer or servant to use the
proceeds for such purchase subject to the following conditions, namely :
(a) the advance outstanding shall not be permitted to exceed the cost of the new
car, or cycle;

<!-- page 15 -->

(b) the advance outstanding shall continue to be repaid at the rate previously fixed;
and
(c) the new car or cycle shall be insured and mortgaged to the Board in the manner
prescribed in Regulation 49.
49. Execution of mortgage bond.- Every officer or servant to whom an advance
is granted for the purchase of a motor car or motor cycle, shall immediately
after the purchase thereof execute in favour of the Board a mortgage bond in
respect of such car or cycle in the form annexed to these regulations.
50. An officer or servant who fails to comply with the requirement of Regulation
49 shall refund the whole amount advanced on the outstanding thereof unless
he shows cause to the satisfaction of the Board why such refund should not be
made.
51. An officer or servant to whom an advance is granted for the purchase of motor
car or motor cycle shall purchase the same within six months of the date on
which the advance is granted to him and shall insure the same within one
month from the date of purchase. He shall renew such insurance from time to
time until the whole amount of the advance is repaid and the amount of such
insurance during any period shall not be less than the outstanding balance of
the advance due from him at the beginning of the period.
52. Retirement benefits.- The employees of the Board shall not be entitled to any
pension except the gratuity and the Contributory Provident Fund benefits
admissible under these regulations.
53. Contributory Provident Fund.- The Board shall establish and maintain a
Provident Fund referred to in regulations as 'Provident Fund' for the benefit of
its employees and administer it.
54. Constitution of the provident Fund.- The Provident Fund shall be formed
out of and maintained by (1) subscriptions from subscribers ; (2) contributions
from the Board ; and (3) interest derived from investments or paid from the
general fund of the Board.
55. Subscriptions.- The employees of the Board, shall be eligible to subscribe to
the Contributory Provident Fund maintained by the Board; provided that such
employees are considered by the Board likely to continue his service of the
Board for not less than three years and the Board is not paying any pensionary
contribution for them nor are they entitled pension from Government. No
employee shall be qualified to contribute to the Provident Fund before he
attains the age of twenty.
56. Realisation of subscriptions.- When emoluments are drawn from regular
establishment, recovery of subscription to the Provident Fund and of principal
and interest on advances shall be made from emolument themselves. When
emoluments are drawn from any other sources the subscribers shall forward
his dues to the Secretary.

<!-- page 16 -->

57. Contribution.- (1) The contribution of the Board shall be 61 per cent of the
subscriber's emoluments drawn on duty and shall be credited to his account
annually before the 31st March or whenever the account is closed. Should a
subscriber elect to subscribe during leave, his leave salary shall for the
purpose of these regulations, be deemed to be emoluments drawn on duty.
(2) The amount of contribution payable shall be rounded to the nearest rupee.
(3) When a subscriber in the service of the Board is temporarily transferred to the
service under another local authority or the State Government, the local authority
or the State Government, as the case may be, shall pay to the
Provident Fund of the Board a contribution calculated at 6¼ per cent of the
subscribers' emoluments drawn on duty under such local authority or the State
Government.
58. Authority.- The authority competent to sanction advances shall be the
Secretary in case of Class III and Class IV employees and the President in
case of Class I and Class II employees.
59. Interest.- The Board shall pay to the credit of the account of a subscriber
interest at such rate as Government may from time to time prescribe for the
payment of interest at subscriptions of their employees.
60. Other conditions.- Subject to the conditions laid down in Regulations 53 to
59 the Contributory Provident Fund Rules (Orissa), applicable to Government
servants shall apply to the employees of the Board. The words "Government",
"Government servant", "Governor of Orissa", "Account Officer" and the
"Fund" wherever they occur in these rules, shall mean the "Board" the
"employees of the Board", the "President", the "Secretary" and "the
Contributory Provident Fund managed by the Board" respectively.
[61. Gratuity shall be granted for good and efficient service to the employees on
the regular or schematic establishments of the Orissa Khadi and Village Industries
Board irrespective of the benefit of Contributory Provident Fund.
62. (1) No gratuity shall be admissible to the following category of employees :
(i) Casual and non-regular employees;
(ii) Employees on contract basis;
(iii) Apprentices and trainees;

<!-- page 17 -->

(iv) Re-employed persons;
(v) Government servants and other employees on deputation;
(vi) Trading staff;
(vii) Honorary workers;
(viii) Employees on daily wages;
(ix) Any other class of employees not specifically made eligible for this benefit.
(2) No gratuity under this regulation shall be admissible to an employee of the
Board to whom pensionary contribution as in case of Government servants is made
applicable or entitled to any retrenchment compensation under provisions of the
Industrial Disputes Act, 1947 or any other law for the time being in force.
(3) No gratuity shall be admissible to any employee who resigns form his or her
service or his or her services are terminated for misconduct, inefficiency,
misappropriation and embezzlement.
63. (1) Gratuity shall be granted in the following cases :
(i) Discharge on abolition of post;
(ii) Permanent incapacity due to bodily or mental infirmity;
(iii) Superannuation;
(iv) Voluntary retirement or compulsory retirement.
(2) Except in case of death, gratuity shall be admissible only after five years of
qualifying service. Qualifying service referred to the above will mean all service
rendered under the Orissa Khadi and Village Industries Board after completion of
18 years of age and shall include the past service in the All-India Khadi and
Village Industrial Board/ Commission, provided such service is continuous, except
period of service rendered as apprentice and extraordinary leave without leave
salary.

<!-- page 18 -->

(3) For the purpose of computing years of service, a period in excess of six months
of service will be calculated as a year and the period less than six months shall be
eliminated.
64. The amount of death-cum-retirement gratuity will be equal to 15 days
emoluments a year for 20 years.
65. In case of death the amount of gratuity will be calculated under Regulation 64
above or as worked out below whichever is more(i) During the 1st year the qualifying service, two months' emoluments of service;
(ii) After one year but before 5 years of service, six months' emoluments;
(iii) After 5 years of service, twelve months' emoluments.
66. Gratuity under these regulations shall be granted by a resolution of the Board.
The rates laid down in Regulations 64 and 65 shall be regarded as maximum
and may not be sanctioned unless the service rendered was satisfactory. In any
case where the service rendered by an employee has not been thoroughly
satisfactory the Board may by an order make such reduction in the amount
payable as it thinks proper.]
67. An employee part of whose service has been in Class IV and part in other
class or classes may either count(a) the whole as In Class IV service towards gratuity on the Class IV scale ; or
(b) the part in Class IV service towards gratuity on the Class IV scale and the part
of service in other class of classes in the scale prescribed for those classes.
Under Clause (a) the gratuity shall be calculated on the pay (whether in Class IV
service or in service of other classes) which the employee drew at the time, the
gratuity becomes payable under Regulation 62 (4) or immediately before
admission to the Contributory Provident Fund of the Board, as the case may be.
Under Clause (b) the gratuity on each scale shall be calculated on the pay which
the servant drew at the time of transfer from or promotion from Class IV to Class
III and at the time the gratuity becomes payable under Regulation 62 (4) or
immediately before admission to the Provident Fund respectively. If a servant is
reduced from a higher class to Class IV for misconduct no gratuity shall be paid to
him under this regulation, except with the special sanction of the Board.

<!-- page 19 -->

Explanation - The gratuity for Class IV service together with the gratuity for
service in other classes shall not exceed the amount of gratuity that would be
admissible, if the whole service were treated as service in the class of service he
last held.
[68. Nomination. - (1) Every employee shall make a nomination conferring on one
or more persons of his/her family the right to receive the gratuity in the event of
his/her death while in service or after quitting service but before payment of the
gratuity is made, indicating the shares payable to each member. In the case of
employee having no family, the nomination may be made in favour of a person or
persons, or a body corporate.
If at the time of making nomination the employee has no family, he or she shall
provide in the nomination that it shall become invalid in the event of his or her
subsequently acquiring a family.
(2) In the event of there being no nomination, the gratuity on death pay be paid in
the manner indicated below :
(i) if there are one or more surviving members of the family as in (i) to (iv) below,
it may be paid to all such members other than a widowed daughter, in equal shares;
(ii) if there are no such surviving members of the family, but there are one or more
surviving widowed daughters and/or one or more surviving members of the family
as in (v) to (ix) below, the gratuity may be paid to all such members in equal
shares.
Family shall include the following :
(i) Wife in the case of a male employee;
(ii) Husband in the case of a female employee;
(iii) Sons;
(iv) Unmarried and widowed daughters;
children;

including step children and adopted

(v) Brothers below the age of 18 years and
widowed;
Including step brothers sisters and step sisters

unmarried

and

<!-- page 20 -->

(vi) Father;
(vii) Mother;
(viii) Married daughter; and
(ix) Children of a pre-deceased one.
69. Application for gratuity.- (1) (a) An employee who is eligible for gratuity
under these regulations shall submit an application for the payment thereof to
the Secretary of the Board.
(b) Every application for gratuity under Clause (ii) of Regulation 63 shall be
accompanied either by a certificate of a Registered Medical Practitioner or the
Head of the Office, to the effect that the applicant is incapacitated for further
service.
(c) Where an employee dies in service or before submitting his application for
gratuity the application for gratuity shall be made by the persons entitled to the
gratuity under Regulation 68 or if such person is a minor or otherwise
incapacitated by the guardian of such person.
(2) After the Board proposes to grant the gratuity applied for, the Secretary shall
draw up an application for gratuity in Form No. 2 annexed to these regulations.]
70. Conduct.- The Board's employees shall be subject to the same rules of
conduct as are applicable to Government servants.
71. Authority and functions of the Secretary and Assistant Secretary.- The
Secretary shall be responsible for executing the orders of the Board and the
President. With the approval of the President certain functions may be
entrusted to the Assistant Secretary to be performed by him subject to the
control and responsibility of the Secretary.
72. Duties and functions of the Khadi Organiser.- The Khadi Organiser is
responsible for efficient management of the Khadi Organisation under the
Board and scheme or schemes connected with any other matters relating to the
Khadi Industry.
73. Duties of the Head Assistant.- The Head Assistant is responsible for the
efficiency of the office of the Board and his work is of utmost importance. He
must see that the staff is fully employed. He must inspect the tables of
Assistants daily. He must see that cases are properly and punctually submitted
and that drafts on orders are promptly put up and issued. He must take

<!-- page 21 -->

personal interest in the work of each Assistant. He must give advice to the
Assistants and help them at every stage.
74. Duties of Assistants.- The work in the office of the Board is distributed
among the Assistants by the Head Assistant who should however report to the
Secretary or Assistant Secretary for confirmation of the specific duties
assigned to each Assistant. In addition to these duties every Assistant is bound
to undertake when the necessity arises, any other work which may be given to
him by the Head Assistant.
75. Duties of the Senior Accounts Assistant.- The Senior Accounts Assistant
shall be responsible for all the matters connected with cash, stationery, and for
the upkeep of the accounts. He is responsible for preparation of all bills of
officers and the staff and for disbursement of the amounts. He is to submit the
annual establishment list. All valuable cheques need be entered in the register
and kept in the custody of the Senior Accounts Assistant. All orders
sanctioning leave and increment need be communicated to him (Account
Section). All statements of services of any officer prepared at the time of his
retirement shall, if the pay of the officer is disbursed by the Senior Accounts
Assistant, be sent to the latter for verification. The Senior Accounts Assistant
shall be in charge of the Contributory Provident Fund of the Board.
[Schedule]
[Regulation 8]
Name of the Posts
Administrative
(Regular
Establishment)
(1)
Class I
1. Financial Adviser
and Chief
Accountants Officer
2. Deputy Secretary
Class II
1. Publicity Officer
1.
2. Accounts Officer
3. Audit Officer
Class III
1. Senior Head
Assistant
2. Junior Head

Technical (Regular
Establishment)

Schematic
Establishment

(2)

(3)

Nil

Nil

Development
Officer (1)

Nil

1. Organiser PC.P.
I.
(1)
2. Leather Supervisor

Bee-keeping
Scheme

<!-- page 22 -->

Assistant
3. Grade-I Assistant

3. Pottery Supervisor 1. Bee-keeping field
man (47)

4. Grade-I Assistantcum-Stenographer
5. Grade-I Store
4. Fibre Supervisor
2. Nursery Keeper
keeper
6. Manager, Central 5. Processing of
II. Potter,
Vastragar
Cereals and Pulses
Demonstration
Industry Supervisor
Squad
7. Grade-II Assistant 6. Villages Oil
1. Pottery Instructor
Supervisor
8. L.D. Assistant
7. Soap Supervisor
2. Master Potter
9. Statistician
8. Gur and Khandsari
Supervisor
10. Economic
9. Bee-keeping
III. Cottage Match
Investigator
Supervisor
11. Scribe
10. Handmade Paper 1. Cottage Match
Industry Supervisor
Supervisor
12. Head Typist
11. Honey Processing IV. Fibre Scheme
Assistant
13. Senior Typist
12. Junior Supervisor 1. Fibre Mechanic
Carpentry and
Blacksmithy
14. Typist
13. Soap Mistry
15. L.D.-cum-Typist
14. Gur Mechanic
16. Despatcher
15. Ghani Mistry
17. Diarist
16. Bee-keeping
Fieldman (1)
18. Driver
19. Record-Keeper
20. P.A. to President
21. Grade-II
Stenographer
22. Assistant
Storekeeper
23. Senior Accountant
24. Grade-I Accountant
25. Junior Accountant
26. Senior Auditor
27. Junior Auditor
28. Electrician
Class IV
1. Daftary
2. Treasury Sarkar
3. Attender
4. Peon and Orderly

<!-- page 23 -->

5. Peon-cumWatchman
6. Cleaner
7. Watchman
8. Mali
9. Sweeper

Revived Saranjam Karyalaya
Class III

1. Manager Nil
1. Wood cutter
2. Store-keeper2. Carpenter for
cum-Assistant
Bee-hives
3. Accountant-cum- 3. Blacksmith-cumBill Collector
Tinsmith-cumWelder
Class IV 1. Watchman-cum- 4. Mechanic-cumPeon
Turner
2. Watchman

Schedule
[Regulation]
Description Appointing Disciplinary Penalty as Appellate Remarks
of post
authority authority per
authority
Regulation
29 of
O.K.V.I.
Board
Regulation
(1)
(2)
(3)
(4)
(5)
(6)
Class I
Board
Board*
All
Government *In case of
excluding
deputation
(1)
the parent
department
wilt be the
disciplinary
authority
Class II
Board
Board*
Ditto
Government
Class III
President President* Ditto
Board
Class IV Secretary
All
President

Form No. 1
[Regulation 50]
Form of Mortgage bond for motor car/cycle advance

<!-- page 24 -->

This indenture made this.....................day of between...............(hereinafter called
the borrower) of the one part ; and the Orissa Khadi and Village Industries Board
(hereinafter called the Board) of the other part;
Whereas the borrower has applied for an advance to purchase the
motor.............described in Schedule hereto on the terms of provision contained in
Regulations 44 to 52 of the regulations issued under the Orissa Khadi and Village
Industries Board Act, 1955 (hereinafter referred to as the said regulations which
expression shall where the context so admits include any amendment thereof or
addition thereto for the time being in force). Now this indenture witnesseth that in
consideration of the sum of Rs...............on or before the execution of these presents
paid by the Board to the borrower (the receipt whereof the borrower hereby
acknowledges) he, the borrower, doth hereby assign and transfer unto the Board all
that motor car more particularly described in the Schedule hereunder written by
way of security for the said sum of Rs.......... and interest thereon calculated
according to the said regulations and the borrower doth further agree and declare
that he will duly pay to the Board the sum of Rs.............aforesaid or the balance
thereof as shall not have repaid at the date of these presents by equal payments of
Rs.............each on the first day of every month after the date of these presents and
will pay interest on the sum owing calculated according to the said regulations in
the manner provided by the said regulations ; provided always and it is hereby
agreed and declared that if the borrower shall at any time make default in the
payment of any of the said instalments for the period of ten days after the time
hereinbefore provided for payment thereof or if the borrower shall leave the
service of the Board or if the borrower becomes insolvent or makes any
composition or arrangement with his creditors or if any one shall take proceedings
in execution of any decree or judgement against the borrower the whole of the said
principal sum which shall for the time being remain unpaid together with interest
thereon calculated according to the said regulations shall forthwith become payable
and it is hereby agreed and declared that the Board may on the happening of, any
of the events hereinbefore mentioned seize and take possession of the said motor
car and either remain in possession thereof without removing the same or else may
remove and sell the said motor car either by public auction or private contract and
may out of the sale moneys retain the principal sum aforesaid or so much thereof
as may for the time being remain unpaid and interest thereon calculated according
to the said regulations, all costs, charges, expenses and payments incurred or made
in maintaining, defending or realizing his rights hereunder and shall pay over the
surplus if any to the borrower, his executors, administrators or representative and
the borrower hereby further agrees with the Board that he will not permit or suffer
the said motor car to be destroyed or injured or to deteriorate in a greater degree
than it would deteriorate by reasonable wear and tear thereof and will whenever the
said motor car is injured or deteriorated forthwith repair and make good the same
and will keep the said motor car, insured against loss or damage by fire or accident.

<!-- page 25 -->

In witness whereof the said hereunto (borrower) hath set his hand to the Schedule
above referred to.
In the presence of..........
and.........
Signed by the said borrower
Signature of (borrower)
Form No. 2
[Regulation 71]
Application for gratuity
1. Name of applicant...........
2. Father's name...........
3. Residence, showing village and district...............
4. Present or last employment including establishment..........
5. Date of beginning of service..............
6. Date of ending service...............
7. Length of service, including interruptions of which.......
Class IV
Other class non-qualifying and interruptions
8. Class of gratuity applied for and cause of application........
9. (Average) emoluments or pay...............
10. Proposed gratuity.............
11. Place of payment..............
12. Date of applicant's birth by Christian era............
13. Height.........
14. Indentification marks.............
15. Date...........
Signature of President

<!-- page 26 -->

History of the Service (showing interruption) of 1
2
3
4
5
6
7
8
9
10
11
Establishm Appointm Pay Actin Date of Date Period Period Remar How Remark
ent
ent
g pay beginni of
reckone not
ks
verifie s of the
ng
endin d as
reckon
d
Secreta
g
service ed
ry
Rs.n Rs.n
Yrs. Mont Days
P
P.
hs

Total period of service
Class IV
Other classes
Remarks by Head of Office
1. As to character and past conduct of applicant...........
2. Explanation of any suspension or degradation............
3. Regarding any gratuity or pension already received by applicant...
4. Any other remarks............
5. Specific opinion of Head Office whether the service claimed is established and
should be admitted...........
Certificate and Report
Certified that (subject to the remarks recorded below) qualifying service in Class
IV, Classes I, II and III has been proved for.........years.........months..........days and
that a gratuity not exceeding Rs...... is admissible.
The calculations have been duly verified.
Secretary
Application for Gratuity
Date of application.......
Name of applicant.........

<!-- page 27 -->

Last appointment..........
Class of gratuity.........
Amount of gratuity sanctioned.........
Date of commencement............
Date of sanction..........
Secretary
President
Orissa Khadi and Village Industries
Board, Bhubaneswar
