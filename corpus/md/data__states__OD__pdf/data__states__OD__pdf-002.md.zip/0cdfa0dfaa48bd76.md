---
doc_id: "0cdfa0dfaa48bd76"
source_url: "https://www.ocac.in/sites/default/files/2026-10/Corrigendum_Date%20extension_Wifi_HED.pdf"
ministry: "Odisha Computer Application Centre (OCAC), Odisha"
title: "Corrigendum_Date extension_Wifi_HED.pdf"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "030ea6dfa4eb4c9c"
---

<!-- page 1 -->

Corrigendum
RFP for Selection of System Integrator (SI) for Selection of Agency for Campus
Wi-Fi Implementation at State Public Universities under Higher Education
Department, Government of Odisha.
Important: The corrigendum is to be read,duly signed and submitted along with the
RFP document published on the Official website of OCAC (www.ocac.in), OCAC eTender Portal https://enivida.odisha.gov.in and Official website of Govt. of Odisha
(www.odisha.gov.in)
(RFP Enquiry No. : OCAC-SEGP-INFRA-0029-2026/ENQ/26049, Dated 03.08.2026)
Last Date and Time for Submission of Bid document:02/11/2026 by 4:00 PM
and Opening of Bid Document: 02/11/2026 at 05:00PM
