---
doc_id: "d62dfbb1a54b4e3c"
source_url: "https://agrisnetodisha.ori.nic.in/No726.pdf"
ministry: "AGRISNET - Directorate of Agriculture & Food Production, Odisha"
title: "Guideline on safe use of pesticides."
date: ""
pages: 10
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "76b579dd3d001657"
---

<!-- page 1 -->

DEPARTMENT OF AGRICULTURE & FARMERS EMPOWERMENT
DIRECTORATE OF AGRICULTURE AND FOOD PRODUCTION, ODISHA
Notification No. APP--0001-2023/ ril dt

FAG ` Aaril dt 23 3 OS / 2622
: Sub: Guideline on Safe Use of Pesticides in Crop Pest Management
The copy of the approved Guideline on ‘Safe Use of Pesticides in Crop Pest
Management’ is enclosed herewith for necessary implementation and wide circulation
among all stake holders.
a7)
Director ଛି
Food Produetjofy, Odisha
Memo No. +} Ax AgriL/PPIat 23// O3/ do a3
Copy along with enclosure forwarded to the PS to Hon'ble Minister A&FE and
FARD for kind perusal of Hon’ble Minister.
5୦/85 850
Food ୮୮ ୦୩୩2 , Odisha
Memo No. Agril./PP/dt =
F28 23/05/2023
Copy along with enclosure forwarded to the PS to the Principal Secretary to
Govt. A &FE Department for kind perusal of Principal Secretary.
| ୨୨୪୪ 9?
| ୮୦୦ '% 4୦୭, Odisha
MemoNo. FQ] Agril/PP/dt ଣ୍‌ 3 3/0 5/2623
Copy along with enclosure forwarded to the Director of Horticulture, Odisha /
Director of Soil Conservation & Watershed Mission, Odisha / MD APICOL/ MD,OAIC/
MD OSSC Ltd/MD MARKFED? Director ,| MAGE /Director OSSOPCA for information and
necessary action.
Director of Agri fect.»
Food P Odyatign; disha
Memo No. 730 Agril/PPidt 3 fos} 2023
Copy along with enclosure forwarded to the Collector-cum-District Magistrate
(All) for information and necessary action.
orate କିଟ
Food Prodyetion} Odisha
MemoNo. f 3) Agril/PPidt ର୍‌ 3 3/0 ୦ /2୬ 4
Copy along with enclosure forwarded to the CDAOs / ADOs (All) / Principal RITE
® (All) / SITE , Bhubaneswar for information and necessary action.
one ee?
Food Produetidn, Odisha

<!-- page 2 -->

ୂ୍‌ଵ୯୬୫୫୬‰‰୫୫ଅଅନଚଜଚକକଚକଚ ାଚଜାୀୌାାନନ୮ନଇନ(।( ମଚ ଚା ଚଜ୦୧୧_ —
Memo No. 232 AgrLIPRIat 23 40୭ / 2024
Copy along with the enclosure forwarded to the Head, Crop Protection Division
,ICAR-NRRI / Dean Extension OUAT / Director (IT) , NIC ,Bhubaneswar for
information and necessary action.
7 Director of Agti ଏ 2
Food Production “Odisha
Memo No. 733 Agril./PP/dt AYV05/ 2422
Copy forwarded to the JDA (All) / Scheme Officers (All) / Programme Manager,
KSK / Team Lead ,KONNECT / Head AMAKRUSHI helpline for information and
necessary action.
Director 10 ୦୬
Food ୮୮୦୨୯୦୮୨୮,୭୦୪୮୩୫

<!-- page 3 -->

୮୮୮
GUIDELINE ON SAFE USE OF PESTICIDES IN CROP PEST MANAGEMENT
DEPARTMENT OF AGRICULTURE & FARMERS EMPOWERMENT, ODISHA
Background:
| Chemical pesticides played a major role in minimizing the crop loss due to
disease -pests incidence, however, indiscriminate and non-judicious use of
chemical pesticides in agriculture has resulted in several associated adverse effects
such as destruction of bio-control agents, development of resistance in pests, pest
resurgence, human and animal health hazards, pesticides residues in food, fruits
and vegetables, fodder, soil and water, ecological imbalances and environmental
pollution etc. Therefore, Government has adopted Integrated Pest Management
(IPM) as cardinal principle and main plank of plant protection in the overall Crop
Production Programme which is to be strictly followed. IPM is an eco-friendly
approach which encompasses cultural, mechanical, biological and need based
chemical control measures. The IPM approach is being implemented and
disseminated through various ongoing schemes/projects in the state.
Although pesticides play a vital role for management of pests they are to be
used in a safe and judicious manner. Using pesticides incorrectly can put animals,
plants and the environment at serious risk. Further it is to say that unnecessary use
of pesticides has increase the cost benefit ratio of the crop creating economical loss
to the farmers. Some-time unnecessary over or low dose of pesticides application
create resistance or resurgence to the pests and imbalance the environment. For
these reasons, before application of pesticides farmers should take care “which,
how, when and where to use the pesticides”.
The objective of this Guidance document is to reflect information on
regulations and safe use of pesticides for disease pest management in the state.
The guidance document also covers different precautionary methods used for
reduction of exposure of pesticide residues in human being through food
commodities.
Key Takeaways:
* To check excessive and unauthorized use of pesticides in crops and food grains
* To grow safe food grains and keep the farmers more aware about Safe Use of
pesticides
* Strictly follow the major uses of pesticides approved /certified by Central
Insecticides Board , Govt of India
* To implement the objectives of the Insecticides Act, 1968 with a view of regulating
the import, manufacture, sale, transport, distribution and use of insecticides in order
to prevent risk to human beings and animals.
¢ A panel of experts from concerned Department of OUAT also recommends the
products on the basis of CIB recommendation ( major uses of insecticides,
fungicides, herbicides, bio-pesticides etc available in the GOI portal ppqs.gov.in
website) .
APP-PP-PP-0001-2023/01/2023

<!-- page 4 -->

* A pesticide dealer can sell pesticides to farmers only as per the prescription issued
by the Agriculture Officer or scientists from OUAT / KVKs.

* Food grains samples to be sent to NRRI , Cuttack for testing the Pesticide Residue
on food grains.

* Various precautions need to be taken while handing the pesticides at all stages
including at house hold levels.

* General hygiene, personal protection, proper storage, proper disposal of
pesticides needs to be taken by the pesticides dealers and the farmers.

| * To take stringent action through rigorous Enforcement activities to check the
spurious use of pesticides .
Problems to be addressed:

* Incorrect use of Pesticides leads to environmental risk.

* Inappropriate use of pesticides leads to resistance of pest.

* Lethal doses may lead to pest resurgence.

* Mishandling lead to health hazardous.

* Push sells by the pesticides dealer leading to phytotoxicity and health hazards

Guidelines:

1. Pesticides Recommendation for Crop Pest Management

* Central Insecticides Board & Registration Committee (CIB &RC) under Ministry of
Agriculture and Farmers Welfare ,Govt. of India is statutory body for registration of
the all pesticides and the Board approves the use of all pesticides crop and pest
wise, the shelf life and waiting period for all types of registered pesticides and
publish the list under the title, “major uses of Pesticides, bio-pesticides, herbicides
etc” in the ppqs.gov.in website.

* The major approved uses of bio-pesticides, insecticides, fungicides, herbicides etc
shall be used as the yard stick for recommendation by experts from OUAT / ICAR
institutes and the extension functionaries.

* QUAT or KVK or ICAR scientists can only recommend the pesticides etc as per CIB
recommendation. They can also recommend the product for additional pests or
crop only after successful trials or research works made by them.

* Any Agriculture Officer or OUAT /KVK/ICAR Scientists can issue prescription to the
farmer for pest or weed management either after pest surveillance or by direct
contact using the CIB approved list.

* The pesticide dealer shall sell the pesticides only as per prescription issued by
Agriculture Officer or OUAT /KVK/ICAR Scientists.

2. Pest Surveillance & Pest Management:

* The pest monitoring & surveillance will be regularly done as per the guideline
communicated vide scheme Need Based Plant Protection under -State Plan.

* Survey and surveillance for pest and diseases with main emphasis to forewarn the

APP-PP-PP-0001-2023/01/2023
|

<!-- page 5 -->

farmers on the potential epidemics of crop pests.
* Farmers will be advised to adopt Integrated Pest Management practices throughout
i the cropping season instead of going directly for application of chemical pesticides.

* The farmers who have covered under pest surveillance and if having any pest

incidence with moderate to high intensity are eligible to get 50 % financial

i. % assistance as per scheme norm and online permit should be generated in his/her
favor as per the recommendation of the Expert Committee / Central Insecticides
Board.

* The Pest Management advisory should be disseminated to the farmers in right time
to minimize the crop losses caused by pests and diseases

* Encourage farmers to use various ecologically sustainable pest management
approaches rather than relying only on chemical pesticides.

* Promote use of bio-pesticides & bio-control agents in plant pest management.

* Conserve the diverse Agro- ecosystem for build-up of various natural enemies for
plant pests.

* Create awareness amongst farmers on (i) Safe and judicious use of chemical
pesticides (ii) To follow the label claims and instructions on dose and use as
approved by CIB&RC.

* Popularizing IPM in farming community by imparting training to Agriculture /
Horticulture Extension Functionaries and Farmers at Grass Root Level by
organizing Farmers Field Schools.

* Rearing biological control agents for their field use and conservation of naturally

occurring bio-agents.

। * Promotion of bio-pesticides and neem based pesticides as alternative to chemical

: pesticides.

* To play a catalytic role in spread of innovative IPM skills to extension workers, land
farmers equally to resource-poor and resource-rich states.

* In case of incidence of major pest like BPH, FAW etc joint field surveillance with
KVK scientists should be made regularly followed by issuance of Advisory and daily
reporting.

3. Safe Use of Pesticides

Proper training in the handling and application of pesticides is important, especially for

professional applicators/ agricultural worker. For considering the proper training to the

agricultural workers a massive awareness campaign cum training programme on safe
use of pesticide will be carried out in the areas of more pesticide consumption like

Bargarh , Cuttack, Sambalpur etc.

IEC Campaigns are to be organised for increasing farmers awareness with a focus on

| safe use of pesticides and to reduce the use of chemical pesticides in those areas with
the following precautions while purchasing, during storage, while handling ,while
preparing spray solution .
APP-PP-PP-0001-2023/01/2023

<!-- page 6 -->

a. While Purchasing
> Purchase pesticides / bio-pesticides only from Registered pesticide dealers having
valid Licence as per the prescription received from Agriculture Officer or KVK /
QUAT scientists.
» Purchase only just required quantity of pesticides for single operation in a specified
. area.
୧ See approved labels on the containers/packets of pesticides.
> See Batch No., Registration Number, Date of Manufacture/ Expiry on the labels.
» Purchase pesticides well packed in containers.
> Do not purchase pesticides without a prescription of Agriculture Officer or KVK
scientist.
> Do not purchase pesticides from foot path dealers or from un-licenced person.
> Do not purchase pesticide in bulk for whole season.
> Do not purchase pesticides without approved label on the containers.
୧ Never purchase expired pesticide.
» Do not purchase pesticides whose containers are leaking/loose/ unsealed
b. During Storage
୨ Store the pesticides away from house premises.
» Keep pesticides in original containers.
> Pesticides/weedicides must be stored separately.
୭ Where pesticides have been stored, area should be marked with warning signs.
> Pesticides be stored away from the reach of the children and live stocks.
୭ Storage place should be well protected from direct sunlight and rain
Never store pesticide in house premises.
> Never transfer pesticides from original to another containers.
> Do not store insecticides with weedicides.
+> Do not allow children to enter the storage place.
» Do not allow children to enter the storage place.
APP-PP-PP-0001-2023/01/2023

<!-- page 7 -->

୨ Pesticides should not be exposed to sunlight or rain water
c. While Handling
୭ Keep pesticides separate during transportation.
° Bulk pesticides should be carried tactfully to the site of application
> Never carry/transport pesticides along with food/fodder/other eatable articles.
o Never carry bulk pesticides on head, shoulder or on the back
d, While Preparing spray solution
୨ Always use clean water.
Use protective clothing viz., hand gloves, face masks, cap, apron, full trouser, etc. to
cover whole body.
3 Always protect your nose, eyes, ears, hands, etc. from spill of spray solution
୨ Read instructions on pesticide container label carefully before use.
2 Prepare the solution as per requirement.
» Granular pesticides should be used as such
2 Avoid spilling of pesticides solutions while filling the spray tank.
3 Always use recommended dosage of pesticide.
| ୭ No activities should be carried out which may affect your health
2 Do not use muddy or stagnant water.
୨ Never prepare spray solution without wearing protective clothing.
୭ Do not allow the pesticide/its solution to fall on any body parts.
୭ Never avoid reading instructions on container’s label for use.
| 2 Never use left out spray solution after 24 hours of its preparation.
| ୨ Do not mix granules with water.
୨. Do not smell the spray tank.
3 Do not use overdose which may affect plant health and environment.
୧ Do not eat, drink, smoke or chew during whole operation
APP-PP-PP-0001-2023/01/2023

<!-- page 8 -->

4, Personal protection from pesticide residues through food chain

Under ideal conditions, the pesticide residues left in/on the food commodities are not

supposed to pose any harm to the consumers. However, as a precautionary principle,

following measures can be taken at the household level:

* Read pesticide Labels properly for safety instructions (warnings) and directions of
use.

* * Store pesticides at a place that can be locked and is not accessible to unauthorized
people or children.

* Left-over insecticide suspension can be disposed off properly by pouring it into a
specially dug hole in the ground or a pit latrine. It should not be disposed of where it
may enter water used for drinking or washing, fish ponds or rivers.

* The reuse of pesticide containers is risky and not recommended. Pesticide
containers should be rinsed as soon as they are empty, completely filled with water,
and allowed to stand for 24 hours. They should then be emptied, and the process
repeated twice.

* Do not eat, drink or smoke while using insecticides. Take a shower or bath at the
end of the day.

* Gloves should be worn when handling the insecticide concentrate and preparing the
insecticide mixture.

5. Safe Use Practices to reduce/ eliminate pesticide residues

Pesticides are toxic to both pests and humans. However, they need not be hazardous

to humans and non-target animal species if suitable precautions are taken. Most

pesticides will cause adverse effects if intentionally or accidentally ingested or if they
are in contact with the skin. Pesticide particles may be inhaled with the air while they
are being sprayed. An additional risk is the contamination of drinking-water, food or
soil. Special precautions must be taken during transport, storage and handling.
Methods to reduce the Pesticide Residues from the Food Products
Following methods can be used for reducing the pesticide residues in most of the
foods:-

‹ Scrub firm fruits and vegetables, like, melons, root vegetables, like, carrot and
tubers like potatoes. Soft brush can be used to scrub the fruits and vegetables for
five to ten seconds before rinsing with slightly warm water.

* Pesticide residues can be reduced from the food products by washing. Washing in
clean running, preferably drinking water reduces pesticide residues as it has
abrasive effect. About 75-80% of pesticide residues on the surface of cereals,
pulses, fruits and vegetables are removed by washing with water. Washing with 2%
of salt water will remove most of the contact pesticide residues that normally appear
on the surface of the fruits and vegetables. The pesticide residues that are on the
surface of the grapes, apples, guava, plums, mangoes, peaches, pears etc, and

APP-PP-PP-0001-2023/01/2023

<!-- page 9 -->

vegetables like tomatoes, brinjal, okra require 2-3 washings.

* Carrot, okra, brinjal, cabbage and cauliflower can be washed with 1 percent
tamarind solution.

* Vinegar Soak: Whip up a solution with 10 percent white vinegar and 90 percent

2 water and soak fruits and vegetables in them. Stir them around and rinse
thoroughly.
* Blanching: Blanching is a short treatment in hot water or steam applied to most of
| the vegetables. Certain pesticide residues can effectively be removed by blanching.
But before blanching it is very important to thoroughly pre-wash the fruits and
vegetables.

* Peeling: Contact pesticides that appear on the surface of the fruits and vegetables
can be removed by peeling. Peeling and trimming fruits like mango, citrus, apple,
pear, peach, kiwi and vegetables like gourds reduces pesticide residues.

* Discard outer layer of leafy vegetables like cabbage, lettuce etc before washing as
they grow close to the ground where soil could be tainted.

* Vegetables and some of the fruits which are consumed along with the peel, can be
soaked in water for half-an-hour to one hour and rinsed a few times before use.

| Soaking fruits and vegetables five to ten minutes in a solution of diluted form of
| hydrochloric acid with four tablespoons of salt and juice of half a fresh lime and
। rinsing thoroughly with clean water helps in reducing residues. Use of dilute
| vinegar/acetic acid followed by thorough rinsing is also recommended.

| 6. Quality Control and Enforcement

* The Quality Control Inspector in exercise of the power shall inspect the premises of
the pesticide dealer not less than 3 times in a year and submit a report to licensing
and appellate authority

* The QC inspector to examine the pesticide dealer points in order to ascertain as
per provision of Insecticides Act and Rule and to stop the distribution of the sale or
use of the insecticides which has the reason to believe is distributed /sold /used in
contravention to the Act and maintain all records of inspections

* The Quality Control Inspector should take stringent action as per the rules mentioned
in the Insecticides Act & Rule and the Hand Book of QCI ‘Legislations and
Enforcement for Seeds, Fertilizer, and Insecticides’.

* Random Pesticides samples to be sent by the inspector to the laboratory for analysis
covering all dealers and manufacturers in the locality.

* 100 number of pesticides samples to be collected from the urban areas for testing
the pesticide residue of food grains.

* The State as well as district level flying squad should take stringent action against
the spurious pesticides during inspection as per Insecticides Act and Rule.

* All the registered pesticide dealers to be made compulsory to stock bio-pesticides,
pheromone traps & lures.

* No pesticide dealer / manufacturer can stock or sell pesticides in the residential

APP-PP-PP-0001-2023/01/2023

<!-- page 10 -->

: ୯
areas and nearby residential areas.

7. Awareness Campaigns on Pesticide Management

+ As per Operational guideline of need based plant protection 200 numbers of Pest
Management Farmers Camps with Safe Use of pesticides will be organised in the

: pest endemic pockets or during the occurrence of alarming pests like BPH, Fall
Army Worm, Swarming Caterpillar, Tobacco caterpillar etc.

* Five numbers of Mega IEC campaigns cum Mela for 500 farmers with door to door
campaigns by volunteers and Mobile miking on'Safe Use of pesticide
management’ will be organised in five districts having higher consumption of
pesticides and higher number of pesticide dealer each year. Importance will be
given for mobile awareness campaigns on safe use of pesticides and Grow safe
Food to create awareness among the various stakeholders. The Action Plan under
IEC scheme will be submitted for Govt approval by JDA Information in consultation
with JDA Plant Protection

The guideline for Safe use of pesticides for pest management should
strictly be followed by the extension functionaries and the pesticide dealers /
manufacturers .Any deviation to the above guideline noticed /reported at any level
shall be treated as an offence.

a
22 -CS-22Y
! APP-PP-PP-0001-2023/01/2023
