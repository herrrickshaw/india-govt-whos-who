---
doc_id: "f869a4ffbbfa996b"
source_url: "https://oredaodisha.com/wp-content/uploads/2025/07/OEM-Empanelment-Order.pdf"
ministry: "Odisha Renewable Energy Development Agency (OREDA), Odisha"
title: "Provisional Empanelment of OEMs (Solar Module, Inverter, Battery, MMS, SLS) under OREDA Ltd."
date: ""
pages: 6
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "f7f3a073edb27d97"
---

<!-- page 1 -->

(Under the Department of Energy Government of Odisha)
(CIN No: U351050D2024SGC045786)
{ (ISO 9001:2008 / ISO 14001:2004)
ORES> S/59, MANCHESWAR INDUSTRIAL ESTATE
BHUBANESWAR-751010, ODISHA
Website: www.oredaodisha.com E-mail: ceoreda@oredaorissa.com
Order No 2/66 JoREDA 110. Dated. 14) / 10/2025
PD- Is52/10874
Office Order

With reference to Tender Call Notice No. 3535/0REDA Ltd. dated 31.08.2024, &
2941/OREDA Ltd., dated 06.09.2025 the provisional empanelment lists of Original Equipment
Manufacturers (OEMs) under the following categories are hereby published:

* Annexure-I: Solar PV Module

* Annexure-ll: Inverter

* Annexure-lll: Battery

* Annexure-IV: Module Mounting Structure

e Annexure-v: Solar Street Lighting System
Please note that these provisional lists are subject to cancellation in the event of any
deviations identified during factory visits or due to any other administrative reasons.
The final empanelment list will be published in due course.

LM ne
Chief Executive Officer

<!-- page 2 -->

Annexure-I
Category- Solar PV Module

ଞ୍ଚ, | Name of the Provisionally qualified OEM
M/s. ICON Solar-EN Power Technologies Pvt. Ltd.
Mis. Aditi Solar Pvt. Ltd.,
Mis. Novasys Greenery Pvt. Ltd.
| 4 | M/s. Contendre Greenergy Limited
Ms. HR Solar Solution Pvt. Ltd.
| _ 6 _ ¦ Mis. KLK Ventures Private Limited
Mis. Pahal Solar Pvt. Ltd.
| 8 | M/s. Premier Energies
| 9 | M/s. Sahaj Solar
M/s. Sunbond Energy Pvt. Ltd.
Mis. Surya International Enterprises Pvt. Ltd.
M/s. Rayzon Solar
Mis. Vikram Solar Limited

por

Assistant Director (Tech.) Joint Direct 44 :
~ OREDA Ltd. OREDA Ltd.

<!-- page 3 -->

` Annexure-ll
iS | Name of the Provisonally qualified OEM
Ksolare Energy Pvt. Ltd.
Statcon Energiaa Pvt. Ltd.
M/s Power One Micro System Pvt. Ltd.
Mis. Ecosi Energy Pvt. Ltd.
Mis. Gayatri Engineering Construction & Consultancy Pvt. Ltd.
„74
1*
` ୬
CS tit
* asistant Director (Tech.) Joint Directo ta. \.
OREDA Ltd. OREDA Lis.

<!-- page 4 -->

` Annexure-lll
Category- Batte
ଞ୍ଚ, । Name of the Provisionally qualified OEM
M/s. Racyl Udyog
Mls. Okaya Power Pvt. Ltd.
M/s. Mars (India) Antennas & RF Systems Pvt. Ltd.
| 4 | M/s. Devang Solar Pvt. Ltd.
Mis. Coslight India Telecom Pvt. Ltd.
| 6 | M/s. NED Energy Ltd.
M/s. Ecosi Energy Pvt. Ltd.
| 8 | Mis. Exide Industries Pvt. Ltd,
as
47
Ae
1
6 85
ech.’
¢ a ant Directo! (
istant Director (Tecn.) Joint .
#5୭୭ OREDA Ltd. OREDALtd

<!-- page 5 -->

Annexure-IV
Category: Module Mounting Structure
Name of the Provisionally qualified OEM / Authorized Channel
partner / Distributor
M/s. Swakriti Renewables
Ms. Gayatri Engineering Construction and Consultancy Pvt. Ltd.
Mis. Raydean Enterprises Pvt. Ltd.
| 4 | M/s. Surya International Enterprises Pvt. Ltd.
4
M/s. Shanti Associates (Authorized Channel partner / Distributor of
Strolar Mounting Systems Pvt. Ltd. in Odisha)
5
ls | M/s. Sunrack Technologies LLP
G
Wy ee
Pig pas
; Tech.) Director (Tech.
Assistant Director ( Joint
OREDA Lia. OREDA Ltd.

<!-- page 6 -->

Annexure-V
Category- Solar Street Lighting System
| 51 146 | Name of the Provisionall qualified OEM
M/s. Amrut Energy Pvt. Ltd.
Mis. Sunlight Infra Energy Pvt. Ltd.
M/s. Devang Solar Private Limited
| 4 | Mis. Nessa Illumination Technologies Pvt. Ltd.
M/s. Ecosi Energy Pvt. Ltd.
27
^?
ae '
(Tech.
ନ int Direct
“assistant Director (Tech.) ୬୨ OREDA Ltd.
OREDA Ltd.
