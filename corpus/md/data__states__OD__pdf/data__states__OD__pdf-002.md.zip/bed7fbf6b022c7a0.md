---
doc_id: "bed7fbf6b022c7a0"
source_url: "https://www.municipalcollegerkl.com/tender_files/tender_notice_1676549371.pdf"
ministry: "Municipal College, Rourkela, Odisha"
title: "Download"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "09a841c7f6bc534c"
---

<!-- page 1 -->

HE PRINCIPAL MU N ICIPAL COLLEG E, ROUR(ELA

No .......,................../MCR

The Principal of Muhlcipal coltese, Rourketa hereby hvites proposatt lrom reput€d
ellgible fims/ ManufacturcB/ Authorize.l deate6/ supptiere to.ated within srate oaodisha

for slpply ol Chss Room Furnirure, Glrt,s Hosret Fumtture, Laboratory Furnitne, Laboratory
Equipments, Desktop Compure6 Ups, printer, CCrVCameEwith tBralanon, Books
CSCS Syllabus), War.r pqrifier, Fire Extingukher,

{As per

Atr Conditioner, hverteB & Battery und€r

OHEPEE Glant atthe.ollece Dremises.

The rnterested FIrfrs may vhit rhe col.ge w€bsire i.e,
and download the Request ror Proposat {Rfpt
documents, or virit the.ollege oft.e for debir inforharionand submit their seated proposal

tothe Principal byepe.d post/Regktered postas per the rermr and.on.lirion, nentioned in
the RrP do.uments, so as to reach the (orrese off.e on or before 23.03.2023112:00 Noon).
The authority rese.ves rhe rlght to extend, a(.ept or ieje.r any or a[ the proposal without

a$igniry any reson thereoL

1,a2

d-

h

Pn-r pal
pattoteBp
I
no-..etd

MemoNo ....... /McR oate ..15/12J.tj))

ropl ro: 'o,h8e No.i "wBodrd/_!a taTd,. Ro-.tetd, --e tine. ot hod, Rontctd to.
pub ication ofthe Advertkement tn th€ir a Odkha editons/SriD.R. Mohanty,
Store (eeperto
up oad thet€nder documents in the colese website/Accounts section/
Office nt. ror.ecord

A))
,r]fl,
