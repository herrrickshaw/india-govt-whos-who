---
doc_id: "db1ef63ccbdb42d4"
source_url: "https://www.ocac.in/sites/default/files/2026-10/Corrigendum_Date%20Extension_WIFI.pdf"
ministry: "Odisha Computer Application Centre (OCAC), Odisha"
title: "Corrigendum-III extension of submission date"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1b5447d30da42292"
---

<!-- page 1 -->

Corrigendum
RFP for Selection of System Integrator (SI) for Selection of Agency for Campus Wi-Fi
Implementation at State Public Universities under Higher Education Department,
Government of Odisha.
Important: The corrigendum is to be read,duly signed and submitted along with the RFP
document published on the Official website of OCAC (www.ocac.in), OCAC e-Tender
Portal https://enivida.odisha.gov.in and Official website of Govt. of Odisha
(www.odisha.gov.in)
(RFP Enquiry No. : OCAC-SEGP-INFRA-0029-2026/ENQ/26049, Dated 03.08.2026)

Last Date and Time for Submission of Bid document:26/10/2026 by 5:00 PM
