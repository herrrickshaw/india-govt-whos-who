---
doc_id: "d3cdba579c5a1d8e"
source_url: "https://handloom.odisha.gov.in/sites/default/files/2022-01/Resolution.pdf"
ministry: "Handlooms, Textiles & Handicrafts Department, Odisha"
title: "Download(296.09 KB)"
date: ""
pages: 2
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "ec7ac721a45f8952"
---

<!-- page 1 -->

GOVERNMENT OF ODISHA
HANDLOOMS, TEXTILES & HANDICRAFTS DEPARTMENT
± ± ± ±
No.V-Tex-24/2021/ 31036900162021/_ 15% _/u,T&H dated the 06 /o1 | 2022
RESOLUTION

Sub: Creation of one post of Deputy Director of Textiles (Promotional) in lieu of abolition of one

post of Asst .Director of Textiles in the Textile Cadre.

The restructuring of the Odisha Textiles Service cadre was under consideration of the
Government on account of exigencies of public service and in the light of activities in the handloom
sector in Bargarh District including the functioning of Sambalpuri Bastralaya, Bargarh and other
important projects.

Government after careful consideration have decided to create one post of Deputy Director of
Textiles (Level-13) at Bargarh in lieu of abolition of one post of Assistant Director (Promotional), Level-10
in the Textile Cadre.

Accordingly, the cadre strength of the Odisha Textile Service with break up of Existing Strength
and revised strength will be as follows.
la Name of the post Existing Strength Revised Strength

1 Assistant Director of 17 (09 Direct Recruitee, through 16 ( 09 Direct Recruitee,
Textiles OPSC + 08 Promotee, through through OPSC + 07
promotion from the feeder post of Promotee, through
Weaving Supervisor.) promotion from the feeder
post of Weaving Supervisor.)
Deputy Director of Textiles 07 (Promoted from the feeder 08 (Promoted from the
post of Assistant Director of feeder post of Assistant
Textiles) Director of Textiles)

This has been concurred in by F.D in their OSWAS file No.FIN-ES2-MISC-054-2021.

ORDER:- Ordered that this Resolution be published in the extraordinary issue of the Odisha Gazette
and copies thereof be forwarded to all Department of Government / All Heads of
Department /Accountant General (Audit), Odisha/ Accountant General (A&E), Odisha,
Bhubaneswar /Secretary, Odisha Public Service Commission, Cuttack /Secretary to
Governor, Odisha.

By order jovernor
Le
5\* a
( ShubhaSarma )
Commissioner-cum-Secretary to Government
PTO

<!-- page 2 -->

//2//
Memo No. is\ /H,T&H, Bhubaneswar dated the © 6 /*/2°22-

Copy forwarded to the Director, Printing, Stationery & Publication, Odisha, Cuttack for
Publication of the Notification in the next issue of the Odisha Gazette with a request to supply 300
copies of the Notification to this Department. sé

He
we
୩୧୪୬
Under Secretary to Government
Memo No. AGO /H,T&H, Bhubaneswar dated the ୦6 /‹4 | ୦୯୬୨.
Copy forwarded to the Accountant General (A&E), Odisha, Bhubaneswar for information,
z Vv
୪୫୬୪
ସ୍‌
é ନ Under Secretary to Government.
Memo No. A /H,T&H, Bhubaneswar dated the 06 Jot /2022—
Copy forwarded to the Director of Textiles and Hand looms, Odisha, Bhubaneswar” ୮
information and necessary action. a,
₹ 755
LiLo
Under Secretary to Government
Memo No, 162 /H,T&H, Bhubaneswar dated the oG Jor / 2022 _ _
Copy forwarded to the Special Secretary, OPSC, 19, P.K.Parija Road, 8750 98 ‘or
information and necessary action. a
Sy od
KL
yvese
C Zz Under Secretary to Government
Memo No. 4G? /H,T&H, Bhubaneswar dated the o6 /01/20>2_
Copy forwarded to Private Secretary to Hon'ble Chief Minister/ P.S. to Hon'ble Minister OY
for information. so
CAs
XY oS
Gu Under Secretary to Government
Memo No.. 1 \ /H,T&H, Bhubaneswar dated the OG [or / 2୦ > i oa
Copy forwarded to Sr. P.S. to Chief Secretary/ P.S. to D.C.-cum-ACS/ Sr. P.S. to Commissioner-
cum-Secretary to Government, HT&H Department for kind information. wy
Se
ial
Under Secretary to Government
Memo No. 465 /H,T&H, Bhubaneswar dated the 6€ Jot [20°22
Copy forwarded G.A. (SE) Department/Finance Department/Confidential Section, HT &
Deptt./ Guard file (10 copies) for information and necessary action. 7
ବ୍‌ —
we
46 ¿£ Under Secretary seoreraisent
Memo No. /H,T&H, Bhubaneswar dated the o6 Je /2022
Copy forwarded to Sri 8.R. Thanapati, Section Officer of this Department for information and
necessary action. He is requested to upload a copy of this Resolution in the Official Website of
Handlooms, Textiles & Handicrafts Department. we”
MSF
Under Secretary to Sévernment
