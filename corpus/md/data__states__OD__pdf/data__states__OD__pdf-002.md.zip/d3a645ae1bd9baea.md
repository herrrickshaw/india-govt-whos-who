---
doc_id: "d3a645ae1bd9baea"
source_url: "https://dhe.odisha.gov.in/sites/default/files/2024-10/Guideline%20for%20scholarship%20under%20e-medhabruti%20for%20the%20AY%202022-23_0.pdf"
ministry: "Higher Education Department, Odisha"
title: "Download(804.05 KB)"
date: ""
pages: 20
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "3279adfea97ae1cb"
---

<!-- page 1 -->

<. GOVERNMENT OF ODISHA
HIGHER EDUCATION DEPARTMENT
KEK

No. HE-SLR-POLICY-0003-2022 GS IESF /HE, Dated: 2-22-4222.
From:

Smt. Prativa Sahu, OAS (S),

Joint Secretary to Government.
To:

All Departments of Government/

All Colleges/

All State Universities/

Biju Patnaik University of Technology, Chhend Colony, Rourkela, Odisha- 769015/

Orissa University of Agriculture and Technology, Unit 8, Near Post
Office,Surya Nagar, Bhubaneswar, Odisha 751003/

Central University of Odisha, Koraput, Central Silk Board Building,

Landiguda, Koraput /

Centurion University, HIG-5, Phase-1, BDA Duplex, Pokhariput, BBSR-751020/
KIIT University, Bhubaneswatr/
Siksha 'O' Anusandhan University, Bhubaneswar, Khandagiri Square, BBSR, Orissa/
Veer Surendra Sai University of Technology, Burla, Sambalpur, Odisha-768018/
NIT, Sector-1, Rourkela-769008/
IT, Argul, Jatni Road, Kansapada, BBSR-752050/

AIIMS, Sijua, Patrapada,BBSR-751019/

NISER, At/Po. - Jatni, Khurda-752050/

IISER, GOVT. ITI Building, Eng. School Junction, Brahmpur-760010 /

Indian Institute of Mass Communication, Sanchar Marg, Dhenkanal-759001 /

IIM, Jyotivihar, Burla,Sambalpur-768019/

National Law University, Odisha, Naraj Road, Sector 13, Cuttack-753015/

Indian Institute of Tourism & Travel Management, Phase 5 Road, Dumduma, BBSR
751019/

Institute of Mathematics & Applications, Andharua, BBSR-751029 /

Institute of Hotel Management, Catering Technology & Applied Nutrition,

Veer Surendra Sai Nagar, BBSR-751007.

Sub:- Guidelines for award of different scholarships under "e-Medhabruti" Scheme.

The undersigned is directed to say that a copy of the revised 'Guidelines' for selection
of students for award of different scholarships under “e-Medhabruti” scheme under Higher
Education Department is hereby circulated for general dissemination and necessary action.

The School & Mass Education Department / Skill Development & Technical
Education Department / Agriculture & Farmers Empowerment Department / Fisheries &
Animal Resources Department / Health & Family Welfare Department /ST & SC, M &
OBC Welfare Department are requested to circulate the attached guidelines among the
educational institutions coming under their administrative control.

All the Universities are requested to circulate the revised 'Guidelines' among the
educational institutions affiliated with them.

Yours faithfully,
/ Qe ୨୬୦୮
Wr
Joint Secretary to Government
FLO:

<!-- page 2 -->

Memo. No. 47, PEFIHE Dated: > ±. A227 -

Copy along with the copy of the 'e-Medhabruti Guidelines’ forwarded to the P.S. to
Hon’ble Minister, Higher Education / P.S. to Principal Secretary to Government, Higher
Education Department, Odisha, for information of the Hon’ble Minister and the Principal
Secretary respectively.

ଏର ୨୮
Joint Secretary to Government
Memo. No. 4496.4 /HE Dated_ 46. 2242222,

Copy along with the copy of the 'e-Medhabruti Guidelines' forwarded to the Director
of Higher Education, Odisha, Bhubaneswar / General Manager(Admin), OCAC / All the
Regional Directors of Education for information and necessary action.

See
Joint Secretary fo & emment
Memo. No. 4/966/HE Dated: > .×> ଅଥ

Copy along with the soft copy of 'e-Medhabruti Guidelines' forwarded to the Program
Manager, CSM Technology Pvt. Ltd., 6th Floor, OCAC Tower, Acharya Vihar,
Bhubaneswar-751013 with a request to float the ‘Guidelines’ in the State Scholarship Portal.
He is requested to float the guidelines and instruction manual separately as a scroll in
addition to displaying under “Guidelines” tab.

Sedan
Joint Secretary to ୯୫ ent
Memo. No. 4/ 8S Z/HE Dated 46-47 EF

Copy along with the soft copy of the 'e-Medhabruti Guidelines' forwarded to all the
Officers of Higher Education Department for information.

Seer
Joint Secretary to Gov ent

<!-- page 3 -->

` Guidelines for Scholarship under_e- Medhabruti Scheme
(UG Merit, PG Merit, Technical & Professional)
Objective:-

The Government of Odisha in Higher Education Department have been awarding
scholarship each year under the Scheme ‘e-Medhabruti' out of State budget to provide
financial assistance to meritorious students of Odisha whose parental income does not
exceed 6.00 lakhs.

Type, Number & Amount of Scholarships:-
It is envisaged to provide the following types of scholarships as below:

Rate of Amount of

Category No. of scholarshi scholarship

of Merit | Scholarship P | tobe paid

per year at a time

3500 10,000/- 20,000/-
3500 for U.G.

courses The number of
(Detail scholarships under
course list is a particular
at category may be

Tech. . As per increased by the

& Appendix-I!) ୮ Govt. depending

3 Prof. 10,000/- course on the number of
Merit 2500 for P.G. duration | eligible students
courses applied and
(Detail validated in other
course list is categories in an
academic year.
at
Appendix-ll)

Duration of Scholarship:-

A student will be eligible for the scholarship for a total duration of the course. One-
time scholarship for the entire duration of the course shall be disbursed in the first
semester/year as detailed in the table.

In case any student, after availing one-time scholarship under one course, joins
another course i.e. like students joining engineering, medical, and other professional
courses during +3 and any other course having a higher scholarship amount, then the
student will be entitled to the differential amount only. The differential amount will also
be released in the first semester/year of the new course.

e.g.

<!-- page 4 -->

Courses applicable under e-Medhabruti (Scholarship):- "
U.G. Merit:- For pursuing +3 Degree Course (B.A./ B.Sc./B.Com.) and courses such as `
BBA/BCA/BJMC etc. having duration of 3 years.
P.G. Merit:- P.G. courses in Arts / Commerce / Science/ other Post Graduate courses
which are of non-professional in nature and the minimum eligibility criteria for admission
to such courses is Degree in Arts / Science / Commerce. An illustrative list of P.G. courses
applicable for e-Medhabruti is mentioned in Appendix-!.
Technical_& Professional _Merit:- Undergraduate & Postgraduate Professional
degree courses and Integrated courses mentioned in the guidelines are eligible under this
head. The list includes B.E./B.Tech/ MBBS/ BDS/ BHMS/ BAMS/ B.Pharm/ B.Sc. (Nursing)/
B.Sc: (Agriculture)/MBA/MCA/M.Tech/Integrated M.Sc. etc. which are duly recognized by
the respective Government Regulatory Bodies such as All India Council for Technical
Education (AICTE), Medical Council of India (MCI), Dental Council of India (DCI), Central
Council of Indian Medicine (CCIM), Central Council of Homeopathy (CCH), Indian Nursing
Council (INC), University Grants Commission (UGC), etc.. Details of Professional degree
courses applicable for e-Medhabruti are mentioned in Appendix- Il.
Eligibility conditions:-
i. The student must be a permanent resident of Odisha State.
ii. The income of the parents of the student from all sources shall not exceed Rs.6.00 lakh
per annum.
iii. The Student must have secured a minimum of 60% marks in the previous qualifying
examination for different categories of merit scholarships as mentioned against each.
iv. Students shall apply for e-Medhabruti only in the year of joining (1st yr. of the Degree
course).
Scholarship Eligibility for e-Medhabruti
Type
Must have passed +2 of CHSE, Odisha / Class — XII or
equivalent exam with 60% or more marks from an
U.G Merit institution recognized by CBSE / ICSE and pursuing regular
Degree Course / +3 course in any of the recognized
Colleges / Institutions / Universities.
Must have passed +3 Degree or equivalent exam with 60%
or more marks from a recognized Institute and pursuing
୮. ©. Merit regular course in one of the disciplines (where scholarship
is offered) in any of the recognized Colleges / Institutions /
Universities.
Must have passed +2 of CHSE / Class — XII or equivalent
exam from an institution recognized by CBSE / ICSE or +3
Technical Degree / equivalent course (only for Master courses) with
Professional
Merit 60% or more marks and pursuing regular Technical &
Professional courses in the Colleges / Institutions
recognized by respective regulatory authorities.
(Contd.)

<!-- page 5 -->

`` `` £×୦|(1510015 510 € ୩୪5 not eligible for scholarship):-

The following types of students shall not be eligible for e-Medhabruti scholarship: -

1. Students pursuing their higher study through open universities or distance learning
/correspondence.

2. Students pursuing Self Financing General UG/PG courses.

3. Students already availing scholarships for pursuing higher study under any other
schemes of State or Central Govt.

4. Students pursuing Diploma level courses are not eligible for e-Medhabruti Scholarship
(Technical / Professional).

5. Students of M.Phil and Ph.D. and students of B. Ed and M.Ed are not eligible for U.G,
P.G. or Technical & Professional merit Scholarship under e-Medhabruti.

6. Students admitted to the College/Institute/University not approved by concerned
regulatory bodies (like AICTE, MCI, UGC etc.).

7. Students studying abroad.

8. Students completing one Technical/Professional course pursues another
Technical/Professional course of same level are not eligible.

9. Students not validated by the concerned Principal/institution during 1st year of her/his
admission.

District-wise Target and Merit based District wise selection:-

i. The target of each category of merit scholarship distributed among all districts

proportionately basing on the population data of the District.

ii. Final Merit/Selection lists of the students will be drawn in terms of aggregate ©
percentage of marks obtained in the last qualifying examination from among the
validated students in the respective category of merit, district wise. The mode of
selection for scholarship shall be made through descending order of merit till it
reaches the eligible quota of scholarship. For example, a student who has secured
92% of mark in the last examination shall come first then the one who has secured
91% mark and so on.

iii, In case of a tie in percentage of marks under a particular type of scholarship and
some are to be left out due to exceeding maximum quota of scholarship, then the

parental income ceiling will be considered, i.e. the student with lower parental
income ceiling will get preference.

iv. The CBSE/ICSE grading system in the form of CGPA, i.e. Grade Points shall be
converted to the percentage by multiplying with 9.5 formula Percentage (%), i.e.
CGPA x 9.5.

Procedure for Application:-

Eligible students including outside students (residents of Odisha but studying outside
Odisha) are required to apply online for scholarship by visiting the portal
https://scholarship.odisha.gov.in/. The online application and authentication
procedure, list of documents required for availing scholarship are explained in the
instruction manual available in the portal.

<!-- page 6 -->

Miscellaneous:-
* For any query or help, students & other stakeholders may contact scholarship Sanjog
Hipline 155335,/1800-345-6770 & Department Phone Number - 0674-2396550 (10:00AM
to 5:00 PM) or E-mail to scholarshiphed@gmail.com/ scholarshiphedgov@gmail.com/.
By Order of Governor 5
hs bap. id)
Principal Secretary to Government
Department of Higher Education
୮ 7 \”7,

<!-- page 7 -->

`` Instruction Manual
ˆ Announcement and Mode of Submission of Application for Scholarship
Applications will be invited once in a year on the Odisha State Scholarship Portal
(https://scholarship.odisha.gov.in/). Short notification will be uploaded in the Higher
Education Department website. Physical application would not be accepted. Only verified
online applications will be considered for award of scholarship.
The Odisha State Scholarship Portal
The Odisha State Scholarship Portal is an integrated e-Governance Portal for automation,
streamlining & effective management of scholarship schemes implemented by the
Government of Odisha across Departments like ST & SC Development, Higher Education,

School & Mass Education, Labour & ESI, Skill Development & Technical Education and

Agriculture. This common platform will provide one stop solution to eligible students to

make an informed choice from amongst various scholarship schemes and avail the benefit

in a seamless and transparent manner. The features like Aadhaar based registration,
integration with other on-line platforms/ data-bases relevant to scholarship programme
like SAMS, e-District Portal, Digi locker, BSE database has been inbuilt in the architecture
for ease of information sourcing and to minimize duplication and ensure leakage free
scholarship disbursal. The State Scholarship Portal has been linked with the State Treasury

Portal IEMS for automated payment directly in bank-accounts of beneficiaries.

Step wise description of the application process

‘Online: ୦୩୮୧ ¦ ¦ en
ae Scholarship ୩ Registration । ୬୮୬୮ = Processing Scholarship
¦ Portal ` "ଏ “ ; ଏମଖାଠାଃ୮୩୮୮  । ହି ¦ Disbursement

i. Eligible students including Outside students (residents of Odisha but studying outside
Odisha) are required to apply online for scholarship by visiting the portal
https://scholarship.odisha.gov.in/. Click Registration link at the portal, if you are new
user. Existing user can click on the login button.

ii. Enter the Aadhaar number and proceed further. Aadhaar is made mandatory for
availing scholarship. Registration on the portal is completely based on Aadhaar. In one
Aadhaar only single registration is allowed. Please provide correct Aadhaar number of
self in the prescribed field. In case it is found that Aadhaar number provided by student
is wrong or not his/her, the application is liable to be rejected.

iii. As per the item 35 of Chapter Vil of Aadhaar (Targeted delivery of financial and other
subsidies, benefits and services) ACT, 2016, if a person enter Aadhaar number of any
other person and attempt to impersonate another person, dead or alive, real or
imaginary, she/he shall be punishable with imprisonment for a term which may extend
to three years and shall also be liable to a fine which may extend to ten thousand
rupees.

iv. The undertaking that | have read the above statements & agree with the conditions.
Further, | hereby state that | have no objection in authenticating myself with Aadhaar
based authentication system through Bio-metric/or One Time Pin (OTP) data for the
purpose of availing benefit of Post-matric Scholarship.

v. Check your registered mobile or email to get the user ID and password.

vi. Click login link at the portal and enter User ID and password to apply the
scholarship.

<!-- page 8 -->

vii. Provide all necessary details like personal, academic, eligibility and bank information. `"

viii. Click on the "Save as draft" button to draft the information or click on "Next" button to ହ
save and proceed the scholarship form.

ix. The preview of the completed form will appear on the page. Download the forms and
take its print out.

X. The students are required to submit the office copy of the application along with other

relevant documents to the Institutes where he/she has been studying.

xi. Concerned students are advised to keep the applicant copy for their future reference.

xii. The online authentication procedure for availing scholarship is explained in the

instruction manual available in the portal https://scholarship.odisha.gov.in/.

xiii. Application which is not validated/ authenticated by the Institute will be treated as

“Invalid”.

xiv. The merit/ selection list as per quota would be generated from the verified applications.

List of Documents required for Scholarship
The following eligible documents will be uploaded at the time of applying under the
scheme.

1. Residence certificate to be issued by the competent authority, i.e. from the concerned
Tahasildar/Addl.Tahasildar. The students whose parents are working under Odisha State
Govt. can produce resident proof from the employer.

2. Proof of annual income of the current financial year to be issued by the competent
authority, i.e. the Revenue Officer not below the rank of Tahasildar or Addl. Tahasildar.

3. Mark sheets of last qualifying examination as required for different categories of merit.

4. Bank Account details of the student concerned (First page of bank account containing
account number and IFSC).

5. College ID card issued by the concerned authority. While in the absence of the same, the
student may provide Admission receipt/Letter of Undertaking with proper validation
from concerned college authority in which the academic session is mentioned (Anyone).

6. Aadhaar Card of the student concerned.

General Criteria/ Limitations for Award of Scholarship:

i. The scholarships meant for U.G & P.G shall be awarded district wise and separate
selection list will be prepared for each district.

ii. If any of the authenticated records are found to have invalid documents, the case will
be summarily rejected.

iii. Any type of wrong entry made by students, i.e. parental income, maximum and secured
mark, district name mentioned in the Resident Certificate, percentage of mark which
lead to rejection of application/the student fails to be in the final merit list, then he/she
is solely responsible for it.

<!-- page 9 -->

`` Procedure for Disbursement:
` The scholarship would be sanctioned subject to fulfillment of the prescribed
eligibility criteria by the students and validation/authentication by the Principals/Head of
the concerned colleges/institutes in online mode only. Scholarship will be paid to the
selected students by the Higher Education Department through DBT (Direct Benefit
Transfer) mode and will be transferred to Bank account of the beneficiaries.

The students must have an active and valid account in any scheduled bank
which has Electronic Clearing System (ECS)/ Core Banking facility to facilitate
transfer of scholarship amount directly to their account.

The bank account must be in the name of the applicant/student only. Student must enter
their bank/branch name, saving bank account number and IFSC very carefully to ensure
smooth transfer of scholarship_amount.

Role and Responsibility of Colleges/Institutes/University

+ The Head of Institution / Principal has to constitute a Scholarship Cell and declare one
senior faculty as the Nodal Officer of the Scholarship Cell.

« The Nodal Officer has to formulate plan and programme for better awareness of the
students about the scholarships granted by Government of Odisha through the State
Scholarship Portal.

+ The Nodal Officer has to constitute a committee of three members.

+ The Committee has to :

i) Download the list of students applied for scholarship (scheme wise), available
in the report site of the portal.

ii) Scrutinize the applications received in the institute log in under different
scheme basing on the eligibility criteria.

iii) The Committee has to ensure the genuineness of the student, i.e. he/she is
studying in the College/Institution for the particular year.

iv) The Committee has to ensure that no student pursuing any Self Financing
Course in General U.G. / P.G. Merit.

v) Check correctness of data regarding parental income, marks secured, bank
Account details, College ID card and residence.

vi) If any error is found, the Principal/Head of Institution will rectify/revert the
applications to students for rectification and resubmission within seven days
for consideration.

vii) Prepare the eligible/Ineligible list in the prescribed format( to be downloaded
from the portal). Format has been detailed in Appendix III.

viii) Sign the report and countersign the same by Head of Institution / Principal &
upload the report in the portal.

© If all data are correct, the Head of Institution / Principal will authenticate the record of
the student to be considered for scholarship by the Department.

« Merit or selection list for particular category of merit will be drawn only from the
records authenticated by the Principal/Head of institutions within the timeline given for
the purpose.

© The institution will be held solely responsible for disbursement of scholarship amount
to any ineligible student as the selection list for any particular category of merit will
be drawn only from the records authenticated by the Principal/Head of institutions.

<!-- page 10 -->

Duties of OCAC through the Service Provider “

i. Complete online system for SAMS and Non-SAMS Colleges will be done in the ୮
prescribed criteria mentioned in the e-Medhabruti guidelines.

ii. Make all necessary changes/modification in the software to facilitate the students,
Institutions and Higher Education Department a hassle free platform to operate.

iii. Technical support to all stakeholders shall be provided by OCAC, BBSR.

iv. Submission of Validated data of all categories of merit (One time residual) within 7
days of closure of Principal/Head of the Institution validation for scrutiny, preparation
of selection list at the level of Department.

V. Online uploading of guidelines, instructions, letters and round-wise selection list (one
time residual) which have been processed for payment.

vi. One Technical person needs to be deputed to the Department to resolve all technical
issues.

Role of Higher Education Department

* Inviting online applications for award of e-Medhabruti scholarship through advertising
in print and electronic media.

* Preparation of merit/selection list of category basing on the authenticated application
submitted by the institution and the selection list prepare and uploaded by the
institution.

* Online payment to eligible candidates through IFMS only.

Miscellaneous:

* For any query or help, students may contact scholarship section on landline number

0674-2396550 or e-mail/scholarshiphedgov@gmail.com/.
N
/^_: ୮ [ .. © ky ¬
Principal Secretafty to Government
Department of Higher Equation
1
