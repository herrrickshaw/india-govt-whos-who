---
doc_id: "a6b3e193ebedb5c2"
source_url: "https://ct.odisha.gov.in/sites/default/files/2020-02/Notification_1571741926.pdf"
ministry: "Commerce and Transport Department, Odisha"
title: "Download(1.03 MB)"
date: ""
pages: 2
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "0a8725a08efacc55"
---

<!-- page 1 -->

୭ ସ୍ୟ Government of Orissa aiid କ୍‌
Commeycu & Transport (Commarce) Department is
5 //୦୨ ୬ ‡ = / .
Bo Pub-2/69~ /! 2G _Com., Dtd.BBSR, the 30h 50°
Foom ` . ଥି
3124 ` R.C,Dash, କୁ
under Seceetary to Government.
To : ˆ
` the Director, ଓ - ୧
Printing-Stationery. & Publication;
Orissa, Cuttsck,
Subs Publication 2f Notification, Resolutions etc,
of Semi G.vernment, Autoaonmous bodies & Public
in che Orissa Gazettc.
Sir,
In inviting reference to your letter No,1080/PSP
` dtd.7.2.89 on the abcve subject, I am directed to say that
the Orissa Gazette is, the news-paper of Government published
by the Orissa Government Press wherein the matters published .
are concerned with business of Government, Semi କୀ
Cpeotral Governmgnt; Court of Law as re as public etc, Fr
walsh there. a legal gupport of the Acts Rules etc., on
Aiminzrstration Grvm* ana legal issues. `
As per Appendix *D' and para 'C' of Rule 78 of
the Government Press Mamual Part-I, the jobs of Government,
Centcal Government, Semi Government, Autonomous bodies,
public etc. are allowed to be printed/published in the
Orissa Gazette after necessary sanction/approval of cither
commerce Department or other sanctioning authority as the
casé may be. The Government Press have to refuse to accept
those matters of printing in support of whicl such sanction
approval of the appropriate authority is not available.
io
ଥୁ In the mean while the list indicated in the Said
Appendix has been modified after issue of this Department
Memorandum No.9977/Com., dtd.13.10.87. As such, prior approval
- of Commerce & Transpcrt(Commerce) Dapartment is necessary
“ for publicaticn. of the jobs in the Orissa Gazette in respect
vf nen-Governncht, institutions like Corporations, Boards,
Manicipalitics, Universities, Offices ୦୮ Government of India, କୁ
i's registered’ Ass: ciation, Public, individuals etc. which is
supported ky vdrious Acts, Rules ‘cr, Orders of Court of Law.
Therefore, the aforesaid instituticns is'well as the company,
individuals ran not Send their jcbs as and when they so
like direct ୦ the Orissa Governm:t Press ‰ -hout approval
୦୮ Government in the ୦୦୮୮ ୦୦ &. Ti aport (Conmererc:) Dupartme nt.
: Conte. = + 2, <

<!-- page 2 -->

. ` -2- "

As per sub-rule 2~-a of the para 40 of the Orissa_
Government Press Manual Part-II approval of thé Secretary of
an Administrative Department is necessary in regard to :
publication of urgent notifications of Government in the 2
Orissa Gazette, Similarly item No.2-b of the Rule 40 of. the
said manual stipulates the necessity of approval of the

-  ceoneerned Secretary/additional Secretary/Joint Seere tary/
Deputy Seerctary/Under Sucretary/Assistant Secretary of the
“écuwinistrative Department for publication of a job in the’
Extra ordinary issue of the Orissa Gazette. ———
ଏ ୦୭ aot ୦୨୦ ୦ ୦ = „-==2. :

As such, the Director,P.S.&P is authorised to
get the matters of the non-Government organisation © like ©
Corporaticns, Bodies etc. published in the Orissa Gazette
only after the appreval of apprepriate authority i.e. Commerce
and Transport (Commerce) Department, as they are the final
authcrity on the matters of printing and publications of
Orissa Gazette,

` Yours faithfully
Tee
8 ` ଏ cy?
. Under Secretary td Government.
Memo Nog 160 /Com, ,Dtd. 20//90

Copy forwarded ୧୯୦ all-Departments of Government/
All Heads 2f Department for information.

They arc requested to issue necessary instructions ©
to the Corpor wtions/Boards/Universities/Minicipalities etc.
under their Administrative Control for necessary guidance
uncer intimeticn to this Department, `

Receipt of the memo may please be acknowledged.
\\ ae ୨ ୬୫୩"
` † >!
Under Secreta: to Govérnment.
Memo No. M6! /Com. ,Dtd. 20/1/90

Copy ୯୬ Master Guard file/Printing Branch.

q (Ale =) `
Under Secretary © 2 Government.
