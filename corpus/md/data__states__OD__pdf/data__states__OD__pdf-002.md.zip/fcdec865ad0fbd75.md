---
doc_id: "fcdec865ad0fbd75"
source_url: "https://www.optcl.co.in/Writereaddata/NewsArea/OfficeOrder_16413.pdf"
ministry: "Odisha Power Transmission Corporation Limited (OPTCL), Bhubaneswar, Odisha"
title: "Temporary Arrangement for Execution of work-Addition of Two Elevators and Development of Mezzanine Floor Areas in OPTCL Tech Tower Building."
date: ""
pages: 3
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "7d851dc5928e4bc3"
---

<!-- page 1 -->

OFO-14/57/2026-CWD-BBSR 1/26136/2026
= -_ == = ==

GSE VQIS ARK ସଅଂଚୋରଣ ନିଗମ M8.

HN ODISHA POWER TRANSMISSION CORPORATION LIMITED
$| (A Government of Odisha Undertaking)
¿ Regd.Office: OPTCL TECH TOWER, Janpath, Saheed Nagar,
Fs ˆ Bhubaneswar, Khurda, Odisha-751007.
IOPTCL Telephone: (0674) 2542269, 2542743 (EPABX), Website: www.optcl.co.in
- " CIN: U401020R2004SGC007553
Siena: Ul | i  ଵ -୭
No.GL-ViI-5/2020(Pt.)- 163% /Dated, 06 -{0- 2026
OFFICE ORDER
Subject: Temporary Arrangements for Execution of the Work “Addition of
Two Elevators and Development of Mezzanine Floor Areas in
OPTCL Tech Tower Building”.

In view of the proposed construction activities for the above-mentioned
work, and with a view to ensuring safe, smooth and uninterrupted execution of
the work while minimizing inconvenience to employees, visitors and other
building users, the following temporary arrangements shall be implemented
during the construction period.

. Accordingly, the concerned Department/Team shall make necessary ar-
rangements and ensure implementation of the following activities:
Activity Concerned
Dept./Team
Relocation of Ganesh Idol
¢ The existing Ganesh idol shall be tem-
porarily shifted and placed at Wing 2 at
Ground Floor (GF). SE (Civil) / Elec-
1 * A suitable and aesthetically appropriate tidal Mulutenange $
= pedestal/platform shall be provided for
safe and proper placement of the idol. Cell
* The shifting and placement shall be car-
ried out carefully, ensuring due respect
and maintaining the overall appearance
of the premises.
Fabrication Area
* The front driveway portion of Tech Tower
Building shall be utilized as a temporary
fabrication area for carrying out fabrica-
tion-related activities associated with the
work.
* The fabrication area shall be properly | SE (Civil) /
2. barricaded and demarcated. HRD(Caretaking
* Adequate safety measures, warning sig- | Branch) /
nage, lighting and access control shall be
provided to ensure the safety of employ-
ees, visitors and construction personnel.
* The contractor shall ensure that the fab- *
rication activities do not obstruct emer-
gency access or essential building ser-
vices.
Contd..P/2

<!-- page 2 -->

=
OFO-14/57/2026-CWD-BBSR 172613672026
oo.
Vehicle Movement and Parking କୁ
* During the execution period, vehicle
movement shall be restricted to the front
entrance of Tech Tower Building.
* Vehicles shall enter through the desig-
nated entry gate and proceed towards the
exit gate through the peripheral area of
3. the building, as per the approved move- | HRD (Gen. Admn.
ment arrangement. Branch) / CSO
* No vehicle shall be permitted to park
within designated construction/work area
at Basement-1 and Basement-2.
* Necessary barricading and signage shall
be provided to segregate construction-re-
lated movement from regular vehicular
and pedestrian movement.
Entry/Exit of Employees and Visitors
# + In view of the proposed construction activ-
ities at the main entrance/front portion of
the building, entry and exit of employees
and visitors through same area shall re-
main restricted during the construction
period.
4 + Employees and visitors shall use the rear- | HRD (Gen. Admn.
© side entry/exit doors of Wing-1 and Wing- | Branch) / ୦5୦
2 for access to the building.
* Appropriate directional signage shall be `
installed to guide employees and visitors
to the designated entry/exit points.
+ The access arrangements shall be main-
tained safely and shall not obstruct emer-
gency evacuation routes.
Control of Noise Pollution
* Necessary measures shall be adopted to
minimize and control noise generated dur-
ing construction activities.
+ Noisy construction/fabrication activities
shall, as far as practicable, be scheduled
5: during suitable working hours so as to | SE (Civil)
minimize disturbance to the regular func- .
tioning of the office.
* The contractor shall provide suitable
equipment/methods for noise reduction
wherever required and shall ensure com- e
pliance with applicable safety and envir-
onmental requirements.
Contd..P/3

<!-- page 3 -->

—
OFO-14/57/2026-CWD-BBSR 1/26136/2026
Be
The above temporary arrangements shall be imposed to facilitate uninter-
rupted execution of the work while minimizing inconvenience to the employees,
visitors to Tech Tower Building.
This issues with approval of Competent Authority.
ନାନା
Chief General Manager (HRD)
Memo No. $6414 /Dated, 06 -42- 2026
Copy to All CGMs / Company Secretary / CLD, SLDC, Mancheswar,
କମ Bhubaneswar / All Sr.GMs / All GMs / All DGMs / All AGMs / All
Managers/ S.E.(Civil) I/C / Land Officer / CSO, OPTCL / All Branch
officers of Corporate Office of OPTCL for information.
bres it
Wr ar
DGM (HRD) Gen. (Admn.
© to:
1. 5୮୮5 to CMD, OPTCL for kind information of CMD. :
2. Sr.PS/PA/SA to all Functional Directors for kind information of
Directors.
3. CGM (IT) for kind information and necessary action with a request
to-upload the above office order in Official Website of OPTCL.
