---
doc_id: "129e93efcff7cd4d"
source_url: "https://www.pheoodisha.gov.in/system/files_force/Corrigendum%201982.pdf?download=1"
ministry: "Public Health Engineering Organisation (PHEO), Odisha"
title: "Corrigendum 1982.pdf"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9249a47711ba59ee"
---

<!-- page 1 -->

T he O rissa G a zette
EXTRAORDINARY
PUBLISHED BY AUTHORITY

No. 665 CUTTACK FRIDAY, MAY 14, 1982/SRAVANA 24, 1904

No.14117-PLW-7/82-HUD
GOVERNMENT OF ORISSA
HOUSING & URBAN DEVELOPMENT DEPARTMENT
CO RRIGENDU M
Th e 6th Mar ch 1982
Subject:

Tariff for supply of water for domestic as well as industrial and commercial uses in
Urban Local Bodies.

Ref:

Govt. in H&U.D.Deptt.Resolution No.3840/HUD., dated the 1st December 1980
No.4229-HUD., dated 3rd February 1981.

In exercise of the powers conferred under Rule 40 of the Orissa Water Works (Urban Local
Bodies) Rules, 1930, the State Government do hereby make the following amendment to the said
Rules and order that the same be given effect to from the 1 st December 1980.
“The word ‘State’ shall be inserted before the words ‘Government Quarters’ appearing in
Note IV under Rule-15 of the said Rules”.

ORDER:
Ordered that this Corrigendum be published in the Orissa Gazette and copies of the
same forwarded to all Departments of Govt. /all Heads of Deptt./Accountant General,Orissa/
Deputy Accountant General, Orissa/all Revenue Divisional Commissioners/Chief Engineer, PH
(Urban)/Chief Engineer,RWSS/all District Magistrates/ Director, Municipal Administration and
Ex-Officio Addl. Secretary to Govt.,H&U.D.Deptt. / all S.Es, PH & RWSS/ all E.Es, PH &
RWSS/ all Executive Officers of Municipal Corporations, Municipalities & Notified Area Councils
/ Estate Officer, G.A.Deptt. / Rent Officer, GA (Rent) Department.
By Order of the Governor
Sd/- R.M.SENAPATI
Secretary to Government
