---
doc_id: "ef52eda3494aaafb"
source_url: "https://www.pheoodisha.gov.in/system/files_force/Resolution%201994.pdf?download=1"
ministry: "Public Health Engineering Organisation (PHEO), Odisha"
title: "Resolution 1994.pdf"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dfcae67db3bffec3"
---

<!-- page 1 -->

T he O rissa G a zette
EXTRAORDINARY
PUBLISHED BY AUTHORITY

No. 475 CUTTACK MONDAY, MAY 2, 1994/SRAVANA 12, 1916

No.9717-PLW-86/92 (Pt.3)-HUD
GOVERNMENT OF ORISSA
HOUSING & URBAN DEVELOPMENT DEPARTMENT
RESO LU T IO N
Th e 31st March , 1994
One of the critical determinants of evaluation of towns and cities throughout the World is
the availability of water sources. For that matter any human settlement can not take its roots
without water which is the basic need of mankind.
With the rapid growth of urbanization the gap between the demand and supply of water to
cater to the requirement of the population is increasing. Unless adequate measures both physical
and financial are taken up, the growth of towns and cities will not only be strangulated but will
cause serious misery of the citizens.
It is with this background the State Government have initiated steps to arrange adequate
institutional fund to meet the gap between demand and supply of drinking water for the towns and
cities. The Housing & Urban Development Corporation (HUDCO) have started providing
financial assistance for augmentation of water supply to a number of towns of the State. In view of
this it is essential that the loan received from the HUDCO should be repaid back in time in order
to avail additional resources from HUDCO for additional towns.
The HUDCO have already sanctioned the water supply schemes for Bhubaneswar, Cuttack,
Kendrapara and Sambalpur which are now under process of implementation. Considering the
implications of timely repayment of loan to HUDCO and to get the financial assistance from
HUDCO on a continuous basis for other towns, Govt. after careful consideration have decided to
impose front end fee (advance registration charges) at the rate of Rs.5000, for all new water supply
connection to each individual holding house. In order to implement this decision, Govt. have been
pleased to decide the following modalities.
8. Bhubaneswar Development Authority will collect Rs.5000 from each applicant for
approval of building plan. It may be desirable to ensure receipt of the front end fee
along with the building permission application form. A separate account of such fees

<!-- page 2 -->

shall be maintained by the B.D.A. which will only be utilized for repayment of loan to
HUDCO. There shall not be any diversion of this fund for any other purpose. A
quarterly statement of fund received on this head may be submitted to Govt. in every
first month of the succeeding quarter.
9. For towns other than Bhubaneswar, namely Cuttack, Kendrpara & Sambalpur, the
OWSSB is the borrowing agency and also implementing the water supply schemes.
Cuttack Development Authority, Sambalpur, Revisional Improvement Trust, Special
Planning Authority, Kendrapara shall ensure that each applicant shall apply to the said
agencies for building permission along with the copy of the receipt of Rs.5000
depsosited with OWSSB. The OWSSB should make necessary arrangement to receive
the fron end fees at the respective towns so that inconvenience is not caused to the
people. The OWSSB shall maintain a separate account for the receipt of the front end
fees and shall ensure that this amount is not diverted for any other purposes except for
repayment of loan to HUDCO.
10. The concerned offices of the PH Engineering Organisation shall take action for giving
water connection only after ensuring that the building plans have been approved by the
concerned agencies with effect from the 1st April 1994. In case where the building plans
have been approved prior to the 1st April 1994 but water supply connection has not
been taken, it may be ensured that before water supply connection is given the applicant
should produce a copy of the receipt of payment of Rs.5000 towards front end fee with
the concerned authorities.
This order will come in to force from the 1st April 1994.
By Order of the Governor
Sd/F.B.DAS
Commissioner-cum-Secretary to Government
