---
doc_id: "cbc2bb4ed815f9f7"
source_url: "https://food.odisha.gov.in/sites/default/files/2024-12/Price%20Policy%202024-25.pdf"
ministry: "Food Supplies and Consumer Welfare Department, Odisha"
title: "Download(4.74 MB)"
date: ""
pages: 6
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "8b4eb8e56dcbef35"
---

<!-- page 1 -->

୨” BY FAX/Post
GOVERNMENT OF ODISHA
FOOD, SUPPLIES & CONSUMER WELFARE DEPARTMENT
No. 10876 /FS&CW., Bhubaneswar Dated 25/⁄22/2227
FSCW-PL-POL-0001-2017
From

Shri Sudam Charan Mandal, OAS(SS)

Special Secretary to Government
To

The Managing Director,

OSCSC Ltd., Bhubaneswar

All Collectors
Sub: Price Policy for Kharif Crops for Marketing Season (KMS) 2024-25 — Fixation

of Minimum Support Prices (MSPs) - reg.

Madan/ Sir, :

In inviting a reference on the subject cited above, | am directed to send
herewith a copy of letter No. 3(16)/2023-Py.| dated 19.07.2024 received from
Department of Food and Public Distribution, Ministry of Consumer Affairs, Food and
Public Distribution, Govt. of India, New Delhi alongwith a copy of letter No. 6-1/2024-
MSP-ES dated 26.06.2024 of DA&FWE and SD, Ministry of Agriculture Farmer
Welfare, Gol, New Delhi respectively relating to Price Policy for Kharif Crops for
Marketing Season (KMS) 2024-25 - Fixation of Minimum Support Prices (MSPs) for
your kind information and appropriate follow up action in the matter.

Yours faithfully,
Ap
Special Secretary to Government
Memo No.___jo33-7 /FS&CW., Dated_2s/ ©2/222
Copy along with copy of its enclosure forwarded/to Additional Secretary to
Government, Agriculture & FE Department for information and necessary action.
Special Secretary to Gdverhment
MemoNo.___/0398 _/FS&CW., Dated ` ୧୧./୦' 74
Copy along with copy of its enclosure forwarded to General Manager, FCI,
Bhubaneswar for information and necessary action.
cap}
Special Secretary t ephment
Memo No.___Jo£79 /FS&CW., Dated___ 257 ©772527/
Copy along with copy of its enclosure forwarded to all Chief ୦.୭.୦.$/ ୦.୭.୦.$
for information and necessary action.
Special Secretary to a Tha
M

<!-- page 2 -->

_ ୧୭୪୫ ¬ ୩୭୪୦୮୮୭
oY
i ¬- ˆ No. 3(16)/2023-Py.|
4 g WW g Government of India
୮ istry of Consumer Affairs, Food and Public Distribution
* i Department of Food and Public Distribution
ee ae Krishi Bhawan, New Delhi.
Dated 19-07-2024
LO;
1. The Addl. Chief Secretary/Principal Secretary/Secretary,
Department of Food and Civil supplies,
All State Governments/UT Administrations.
2. The Chairman and Managing Director,
Food Corporation of India,
Qs 16-20, Barakhamba Lane, New Delhi.
୧୩୮ Subject: Price Policy for Kharif Crops of Marketing Season (KMS) ,2024-25 —
` Fixation of Minimum Support Prices (MSPs) - reg.
es
¥0୪" Madam/Sir,
Anal) | am directed to refer to the subject cited above and to state that the
Department of Agriculture & Farmers Welfare, Government of India vide its letter
No. 6-1/2024-MSP-ES dated 26.06.2024 (copy enclosed) conveying Minimum
Support Prices (MSPs) fixed for all mandated Kharif Crops (Fair Average Quality)
ର or Kharif Marketing Season 2024-25.
a)
2. It is requested that wide publicity may be given to the MSPs fixed by the
Department of Agriculture & Farmers Welfare, Government of India for
pfocurement in KMS 2024-25, so that the farmers are well informed about MSPs
ou announced in the States/UTs concerned for their participation in MSP programme.
Gv Yours faithfully,
ହୃ Signed by Deependra Singh
« Encl: As above. Date: 19-07-2024 14:27:17
(Deependra Singh)
Under Secretary to the Govt. of India
E-mail: uspy1 .fpd@nic.in
Copy to:
1. Executive Director (Procurement), FCI Hqrs, New Delhi.
2. Executive Directors, FCI, All Zones.
3. Adviser (FE), DA&FW, DES, Krishi Bhawan, New Delhi.
4. General Managers, FCI, All Regions.
Copy also to:
5. PS to Minister (CA, F&PD).
6. PS to MoS (CA, F&PD)
p v3

<!-- page 3 -->

7. Sr. PPS to Secretary, F&PD.
8. PPS to AS & FA, DFPD.
9. PPS to JS (P&FCI), DFPD.
10. PPS/PS to Sr. EA/Principal Adviser (Cost)/JS (BP&PD)/JS (Storage)/JS
(Admn & IC)/Adviser (Cost)/CCA, DFPD.
11. All Directors/DS/JC(S&R), DFPD.

<!-- page 4 -->

= No 6-1/2024-MSP-ES
Government of India
Ministry of Agriculture and Farmers Welfare
Department of Agriculture & Farmers Welfare
Economics, Statistics & Evaluation Division
(MSP Unit)
ତା
Krishi Bhawan, New Delhi
Dated: 28June, 2024
Subject: Price policy for Kharif Crops for Kharif Marketing Season (KMS)
2024-25-- Fixation of Minimum Support Prices.

Government of india has fixed the Minimum Support Prices (MSPs) for all
mandated Kharif Crops (Fair Average Quality) for Kharif Marketing Season
(KMS) 2024-25. MSP of mandated Kharif crops for marketing season 2024-25 is
as under:

- Commodity > A ¦
(Fair Average । Variety | ମୀ `` ।
reals | | i
ଗମ ଲେ ae |
| Grade 'A' 2320
a ଚଵଠ୫”୮୭ See
Bajra 2625
୯୬ ଇଂ ।
<p Ragi | 4290
| Maize | 2225
¦ 1
ଦା ere ୧୮୮୧ ।
Moong | Soir. 4
Te
| Oilseeds | |
| Groundnut 6783 |
|“...  -- ବିଚ `
Sunflower seed 7280
[Soyabean । Yellow ae 4602
Page 1 of 3

<!-- page 5 -->

y
କ୍‌
\
. oy = .
ae aS
Commodity
(Fair Average Variety Minimum Support
Quality) Price (in ଝି per quintal)
Sesamum 9267
Nigerseed aos ose ୩୩7,
Commercial
Medium Staple (Staple length
(mm) of 24.5 - 25.5 and
| Cotton Micronaire value of 4.3 - 5.1). 7121
| Long Staple (Staple length (mm)
of 29.5 - 30.5 and Micronaire
value of 3,5 ¬ 4.3) _ : 7521
2 The prices for different variety groups of rice be derived from the MSPs of
paddy because of hulling/milling ratios as well as the processing and incidental
charges obtaining in different states.
3. ` 718 prices of other varieties of cotton will be fixed by the Ministry of Textiles
keeping in view the normal market price differentials and differentials between their
staple lengths, micronaire value and other technical parameters.
4, In case of cereals and coatse cereals, Food Corporation of India (FCI) and
other designated State Agencies would continue to provide price support to the
farmers, State Governments will undertake procurement of coarse grains with the
prior approval of Government and would distribute the entire procured quantity under
National Food Security Act (NFSA). The subsidy will be provided only for the quantity
issued under NFSA. National Agricultural Cooperative Marketing Federation of india
Limited (NAFED), Small Farmers Agri ¬ Business Consortium (SFAC) and other
designated Central Agencies would continue to undertake Procurement of pulses
and oilseeds. Cotton Corporation of India (CCI) will be the central nodal agency for
undertaking price support operations for cotton. The losses, if any, incurred by the
nodal agencies in. such operations may be fully reimbursed by the Government as
per the guidelines.
5. The Ministries/Departments concerned are requested to take necessary action
for providing price support operations as well as for wide dissemination of related
information.
be Wenren Cy
(୦.ମ; Srivastava)
Adviser (MSP),
Tel; 011-23382523
1. Secretary, Department of Economic Affairs, Ministry of Finance, North Block, New
Delhi
Page 2 of 3 `
‘ u

<!-- page 6 -->

;ଁ `- 2. Secretary, Department of Expenditure, Ministry of Finance, North Block, New Delhi
3. Secretary, Department of Food & Public Distribution, Krishi Bhawan, New Delhi :
= 4. Secretary, Department of Consumer Affairs, Krishi Bhawan, New Delhi

5. Secretary, Department of Commerce, Udyog Bhawan, New Delhi

6. Secretary, Ministry of Textiles, Udyog Bhawan, New Delhi

7, CEO, NITI Aayog, NIT! Bhawan, New Delhi

8, Chairman, CACP, Krishi Bhawan, New Delhi.

9, Additional Secretary (l&PS), Department of Agriculture & Farmers Welfare, Krishi
Bhawan, New Delhi.

10, Joint Secretary (Policy), Department of Food & Public Distribution, Krishi Bhawan,

11. Joint Secretary (Marketing), Department of Agriculture & Farmers Welfare, Krishi
Bhawan, (with request to direct the concerned officers for arrangements on displaying
MSP in the APMC mandis).

12,.DDG (Extension), Indian Council of Agriculture Research, Krishi Anusandhaan
Bhawan, Pusa, New Delhi-110012 (with request to direct KVKs to disseminate the
MSP to farmers).

Internal Circulation to:

1. All Additional Secretaries of DA&FW
2. All Joint Secretaries of DA& FW
3. All Advisers of DA& FW
4. PS to Hon'ble Minister for Agriculture and Farmers Welfare
5. PS to Hon'ble MoS for Agriculture arid Farmers Welfare
6, PS to Secretary, DA&SFW
7. PPS to Principal Economic Adviser, DA&FW 3
8. PPS to Sr. Economic & Statistical Adviser, DA& FW

Page 3 of 3

7¿
