---
doc_id: "e4aae65d4b6d0db5"
source_url: "https://odishaconstruction.com/wp-content/uploads/2025/07/Office_order_CWS_31.pdf"
ministry: "Odisha Construction Corporation Limited, Bhubaneswar, Odisha"
title: "Office Order"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8fa736557c5bff6b"
---

<!-- page 1 -->

ODISHA CONSTRUCTION CORPORATION LTD.
( A Government of Odisha Undertaking )
CENTRAL WORKSHOP, RASULGARH, BHUBANESWAR-751010

Email : smppmcws@gmail.com

Phone 0674 : 2580106
FAX:
0674-2587321
Email : smppmcws@gmail.com
GSTIN - 21AAACO2571K2ZM

No. OCC/CWS/PROC/ VRM(V-I) /_2506__/

Dtd.__04.07.2025___/

OFFICE ORDER
This office quotation call notice No.OCC/CWS/PROC/ VRM(V-I) / 31 /2025-26 dated.23.06.2025 due on
03.07.2025 for “ Supply of spares for MIG welding machine (ESAB Make Ayuto K-400) for Central Workshop,
Rasulgarh, Bhubaneswar. ” is hereby cancelled .
Sd/-

SENIOR MANAGER (MECH.)-I

Cancellation (2025) 106
