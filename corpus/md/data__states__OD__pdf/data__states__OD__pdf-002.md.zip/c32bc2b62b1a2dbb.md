---
doc_id: "c32bc2b62b1a2dbb"
source_url: "https://fmuniversity.nic.in/getdata?dir=InstituteNotice&rid=inotice1055_9920261788964567440.pdf"
ministry: "Fakir Mohan University, Odisha"
title: "CORRIGENDUM Postponement of guest faculty walk-in interviews for four specific departmentsChemistry, Geography, Urdu, and Zoology :"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e7ea368eed8dd2cf"
---

<!-- page 1 -->

No: Estt.(T)-II-42/2026/ 7924

Date: 09.09.2026

CORRIGENDUM
In partial modification to this Office Notification No. Estt.(T)-II-42/2026/7549
Dtd-01.09.2026, the Walk-In-Interview scheduled to be held on Dt-16.09.2026 for
engagement of Guest Faculty (for Regular P.G. Departments) in the subject of Chemistry,
Geography, Language & Literature (Urdu) and Zoology are hereby postponed until further
notification.
However, the Walk-In-Interview for remaining subjects (for Regular P.G. and SelfFinancing courses) shall be held as per the schedule notified by the above Notification.

By order of Vice Chancellor

Registrar
Memo No: 7925

Date: 09.09.2026

Copy forwarded to:
1)
2)

3)
4)

The Officer-in-charge, University Website with a request to upload the
Corrigendum in the University Website for general information.
The HODs and Coordinators of all P.G. Departments for information. They are
requested to post the Corrigendum in the Notice Board of their respective
Departments.
The P.A to Vice-Chancellor/ Steno to Registrar/ Chairman, P.G. Council/
Comptroller of Finance/ Controller of Examinations for information.
Editor, the Times of India, BBSR (National Edition)/ the Samaja, Balasore
(all Odisha Edition) for information with a request to publish the Corrigendum
on dt-10.09.2026 positively confiding (6×6) Sq.cm size and submit the bills
(in duplicate) as per I&PR rate, Govt. of Odisha for release of payment.

Registrar
