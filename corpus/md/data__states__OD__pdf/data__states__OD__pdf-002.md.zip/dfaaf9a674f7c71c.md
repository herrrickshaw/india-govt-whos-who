---
doc_id: "dfaaf9a674f7c71c"
source_url: "https://www.gacrkl.ac.in/notice/tender/list-gacr.pdf"
ministry: "Government Autonomous College, Rourkela, Odisha"
title: "[ List-1 ]"
date: ""
pages: 26
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "67cd36918ca0dee2"
---

<!-- page 1 -->

| ves Debortment ©{ | ୩୩୧. and) 1୭16
“Be fli, ay
| As Rasees 4
ଆ ate 4 Ganegh Prasad Dash ବ
Chart 4 and 2)
2 Ettues ¿ Badtan and useotem by NG Profle eine? ।
Si ଜନ"
. ` ® & ମାଠ, ef nate ଭୁ een ।
| ×. (ଓ ୭୧୪୫୦୯୮୬ Ro~dlis comaned) a କା । `.
। B+ Lootemponeny Golan =, m> ¥, nahadlven
| £ \ ୦୩୦୦
| ର ‘A VO Sanh
| 6. owes ot ମୁଖେ ‘ae by ଘା chandse
| ୮ ଅଧା a Peopanised) M4 Bacant Kamen ।
and tte “rite Dark
$: ` (୬୯୫୦ medsea! ଖର ai ୧୭୧ Tagedew 4
୩ Ae Toinednetion ଏ cool ao Meath chhanalacen |
ଉନ
।୪, ` ଞ୍ୟଇ୍ୟା ୭ 20 ମଧ୍ଧ ୨((୧୯-† by chhaga Red । ୫
Masthode
Ly elle 04୬
ଓ 63 ୫2୬୮ ! ` ` 0 !'; ୧୩୮୬

<!-- page 2 -->

Book List
Dept. of Political Science & Public Administration, GACR-2025-26
Sl. Title of the Books Author Publisher | No. Cost | Approximat
No of e cost
Cop
ies
1 An Introduction to O.P Gauba National
| Political Theory Paper 3 | Rs.400/ | Rs.1200/
| Publication
Kuldeep Fadia Bhawan
ଧାଵା ୩୩
Publications 2 | Rs.400/ | _ 1:5.800/
ଯୋ । ଆୟା
Theo! publication
5 Disaster Management Sulphey MM PHI 2 | Rs.600/ | Rs,1200/
re Learning . „ | ଜୈ .. - ରଛ୍‌ ରର
Publication
ମାଲ orm ମଜ
Publication `
Bhuyan Publication
ମଲା PO ad
Publication
। ଜାରକା el
Concepts Ramaswam; Publication
। ମଲନ Le
। India Publication
11 Manisha Pearson 2 | Rs.200/ | Rs.400/
Human Rights Gender and Priyam Publication
Environment Krishna Menon
Madhulika
Banarjee
12 S.Chand & Rs.600/ Rs.600/
Principle and Practice of L.M Prasad Sons
Management
କଲଲ ଲବି କୁ ୩୭୩୦
International Relation Study IQ Study IQ
Pst ଏଲତ ୩ ୩୪ ।
Modern World History Norman Lowe | Mastering | 2 Rs.428/,| Rs.856/
Publication
Administration in India Sachdeva Publication
_ Boo
Ola cea । | ania 1 ent of Political Science.
୪ ନ Autonomous College
Rourkela

<!-- page 3 -->

। ‘
Rural Development: Katar Singh & Atlantic 2
Principles Policies and | Anil Shishodia | Publication Rs.500/ | Rs.1000/
Management
Total
Amount=Rs
.12,806/
GQ
DepartiBignnoie of ODS cience
Govt. Autonomous College a
Dept.of Political Scigneg © 10010110 Administration

<!-- page 4 -->

Post Graduate Dept. of PHYSICS
Book List
pope eee ee
Cost(Rs.)
1. Introduction to David Griffiths WILEY-VCH 1 4,109/- ¬
ମା
Particles
2. Classical Herbert Pearson 1 800/
Mechanics Goldstein
Charles P.
Poole
John Safco
Introduction to David J. Pearson 1 700/
- Quantum ~ Griffiths
Mechanics
ee ଜକ ଏକ
Mechanics Zettiley
csi ee
Flectrodynamics Griffiths
6. Elemenis of D. $. Mathur 5. Chand 1 500/
Properties of
Matter
#// ୮
(100)

<!-- page 5 -->

od PC, Degrshiman ୧୧ ded nA,
| ST
a ee
| I Prebali thy nd Mathematica Gtbisticn ± copy = 1625/—
| a he
4. Objedive Shdiaticg 2 ୦୫୬ _ F452
M4 S.c. Gupta, Son} cov kena Gop, = 1540/ _
| ୬, Srtroducton te. Linear Reqvession Andy sie, Leste „ 2655/-_
b Povalen CQ Montgorrery
Cy Edition ;
4. ` Time. ୧୫ tnaly xix and oh Applications Lorie 6405/_.
by Robes- ୩: Shumway David &. Stofter
if Editien, S vero ¬
aa Teh| = ‰ 12,665
tye ୬”
ଥୁ

<!-- page 6 -->

DEPARTMENT oF MATHEMATICS ,GACR
Book LIST
|-|Pigferential Calculus |Shanti Navayon| Ss. Chane . ୭ 99 0
PuK- Mittal Publ tcaction
-9.| Calculus (4th ୭/:/୮୩୨ | 4B Thomas, | Pearson ୬7/* ୬6
| Ril Franey Education
3. Contemporary Abstract Toseph Narosa Publishing 590100
Algebra CAth Edetion) | A. Gallian House
A. Elementary Number |David M- TMH Publeshing) ୬୦୩୬=।172:୬
| | theory Céth Elition) | Burton Company
ra Introduction -%© Real} RG: Bartle John Weley & + £24.00
Analgsis Card Editon Jd Rs cheybLert Song
Fundamentals of . GQ: Das Amel |TMH Publishing 559.00
6. Macthemotteal Analysis |S: Pactanayak | Company”
7 [PDE for Engineers % 2 ¥? Sharma Navesa Publishing !( ୭୬ © ©6
and ୬୦୯୮୧॥୩୮ଏ୯୮୭୩୪୭ kedax Stngh House
re କାଠି ଓ ଦା SH-Pyedbe . Ll
¢. ¦; ; YG, | Prentice Ha .
Linear Algebra Av Inge j 2 of ` = ୩. 775 X2eI550- Ot
` > ` &- ` 1523,
~ Tan Tnteoduction to |v Krishnamurti East -West
Linear Algebra VP, Matnya | Press Pvt. 3062 =612:00
Tel Avrora '
` ` Hob ;
Bept- of Mothemal te:

<!-- page 7 -->

GEOLOGY DEPARTMENT
GOVERNMENT AUTONOMOUS COLLEGE, ROURKELA
¦; . Pravalika
Remote Sensing Geology | Ravi P. Gupta [Springer | 1 | 1800 1800
Geostatistics with ତ
TOTAL = Rs. 7060/-
posh Oise —
HOD (1/0)
Department of Geology.

<!-- page 8 -->

No .
[1 [Spectroscopy | Kaur | Pragati = | 2 900 % 1800 |]
Compounds
4, Spectroscopy of inorganic J. Singh, M.D. | New Age 1 435 435
Compounds Pandey and Jaya
Singh
Core) : Publishing
House
emcee fee ଆ ସି |
Publication.
Signature of HOD 6 3. OL. 2@ 27

<!-- page 9 -->

7. 6. DePpartmout of Commerce ,
Coo vt. Auto. College, Rourkela
Book-Li sd
ଏ  ଲାଜନଗ ୭୭ | pubtsner ଆଲୋ ।
No. Titles of book Author Publisher Cost
lr [Sze [sata sae |
1 | Financial Accounting _| Radhaswamy Sultan Chand & Sons 995
୭୩୭୧ ବିକା [Moco Hi ୫୫୩୭ ୦
2 Bharat Tulsian McGraw Hill Education 820
ସା ର ଅସନ ଆ
3 | Management L.M. Prasad Sultan Chand & Sons 395
|___6| Strategic Management | AzharKazmi | McGraw Hill Education | 650 |
lagi ରଖା କା
Research Methodology | Gaurav Garg Publishers 450
sleds ଇସି କଳ ୩୦
Management Dr. R.P. Rustagi Taxman 580
| iolemtonen 5 Aswatn —_[tinalayaPubenion | 700
Environment K Aswathapa Himalaya Publication 700
a ଇସ
11 | Derivative Cengage Niti Nandini Chatnani 370
| tal managment” [siete [snataaPucsion | s00
12 | Management Shrlekar Himalaya Publication 800
କୋଇ ଦେ ୫ ୦
13 | Management Janakiramanan Pearson 839
Chandrahauns
14 ମମ ଖା୩(। ୩୦ [iran [remo | saa
avs
%

<!-- page 10 -->

LIST OF BOOKS
PG DEPARTMENT OF ZOOLOGY
Ra Title of Books Publisher Approx, Unit Cost
Principles And Techniques | Cambridge
Of Biochemistry And Wilson And | University 1 1600/
rg „ Molecular Biology (8 Walker Press Indian 7
` edition) edition
ˆ Textbook of PK. inte re 1
2, Environmental Mehapatra ମମ 500/- ˆ
Biotechnology (2013) apal ୮୩ ishing
ouse
. Campus
Environmental
3, ; $ Varun Mehta Books 1 750/-
a Biotechnology (2011) Ree
Discovery
Bio techniques of Ecology ୩ Publishing 695/-
umar
House
+. 1,]. Balinsky Thomson .
5, An Introduction fo andB.C. | Press(India) | 1 700/-
ଣି Fabian Lid
: . Dr V.K. 5 Chand & I
eta =
! RK.
1: Comparative Anatomy of Saxena, Viva Books 2 1435/-
ˆ Vertebrates (2020) Sumitra Originals
Saxena
se A Narosa
Principles of Animal Ashok Publishing 700/-
Taxonomy Verma House
Introduction to Pranab
Biostatistics: A Textbook kumar 5 Chand & Ps | 395/-
of Biome Banerjee pany -
Hee -
ତ ` H.O.D
' PG Department of Zoology
. . ୮ .
