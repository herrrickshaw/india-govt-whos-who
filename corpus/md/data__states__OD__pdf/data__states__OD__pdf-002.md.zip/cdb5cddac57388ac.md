---
doc_id: "cdb5cddac57388ac"
source_url: "https://ga.odisha.gov.in/sites/default/files/2026-08/Combined%20Technical%20amendment%20%202026.pdf"
ministry: "General Administration and Public Grievance Department, Odisha"
title: "Download(226.33 KB)"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "53b47835277ce87c"
---

<!-- page 1 -->

EXTRAORDINARY
PUBLISHED BY AUTHORITY
No.746, CUTTACK, THURSDAY, FEBRUARY 19, 2026 / MAGHA 30 , 1947
GENERAL ADMINISTRATION & PUBLIC GRIEVANCE DEPARTMENT
NOTIFICATION
The 19th February, 2026
No.5583─GAD-FE-OSSC-0013/2022/Gen.─ In exercise of the powers conferred
by the proviso to Article 309 of the Constitution of India, the Governor of Odisha is
pleased further to amend the Combined Technical Services Recruitment Examination
Rules, 2022, namely :−
1. Short title and commencement.- (1) These rules may be called the Combined
Technical Services Recruitment Examination (Amendment) Rules, 2026.
(2) They shall come into force on the date of their publication in the Odisha Gazette.
2. In the Combined Technical Services Recruitment Examination Rules, 2022 (herein
after referred to as said rules), in rule 3, for the proviso thereto, the following proviso
shall be substituted, namely:−
“Provided that the Government may include or exclude any Service or Post in or
from Schedule-I and include or exclude any Syllabus in or from Schedule-II for
regulating direct recruitment to that Service or Posts by notification in the
Odisha Gazette.”.
3. In the said rules, for the Schedule-I, the following Schedule shall be substituted, namely:“ SCHEDULE-I
SL
NO
(1)
(1)

Recruitment Rules or Resolution or

Name of the Post

Executive Instruction

(2)

(3)

Junior

Engineer

under

Engineer-in-Chief of Recruitment and Conditions of Service)

(Water
Handloom,

(Civil) Odisha Diploma Engineers’ Service (Methods

Resource), Rules -2012.
Textiles

Handicrafts Department

and

<!-- page 2 -->

2

and other Departments and
Heads of Department.

(2)

Junior Engineer (Civil or Odisha
Electrical

or

Muncipal

Engineering

Service

Automobile) (Recruitment and Conditions of Service)

under Housing & Urban Rules, 2016.
Development Department.
(3)

Junior Engineer (Electrical) Odisha Diploma Engineers’ Service (Method
under

Engineer-in-Chief of Recruitment and Condition of Services)

(Electricity)-cum-Principal

Rules -2012.

Chief Electrical Inspector,
Odisha
(4)

Junior

Engineer Odisha Diploma Engineers’ Service (Method

(Mechanical)

under of Recruitment and Condition of Services)

Engineer in Chief (Water Rules -2012
Resource),

and

other

Department and Heads of
Department.
(5)

Junior

MVI

under Odisha Subordinate Transport Engineering

Commerce and transport services Rules -1996 & Amendment Rules2014

Department.
(6)

Junior Mining Officer under Odisha Sub-ordinate Mineral Administration
Director

of

Mines

and Service (Method of recruitment and condition

Geology

of service of Junior Mining Officer and
Assistant Mining Officer) Rules, 2021.

(7)

Planning Assistant Under H Odisha Municipal Planning Service (Method
& UD Department

of Recruitment and Conditions of Service)
Rules, 2017.

(8)

Laboratory Assistant under The Odisha Staff Selection Commission shall
Directorate

of

Export decide

Promotion and Marketing.

the

examination

syllabus
in

and

pattern

of

consultation

with

the

concerned Departments or HoDs by invoking
powers envisaged under the rule 13 of OSSC

<!-- page 3 -->

3

Rules, 1993 and its subsequent amendments
till date.
(9)

Laboratory Attendant under The Odisha Staff Selection Commission shall
Directorate

of Export decide

Promotion and Marketing.

the

examination

syllabus
in

and

pattern

of

consultation

with

the

concerned Departments or HoDs by invoking
powers envisaged under the rule 13 of OSSC
Rules, 1993 and its subsequent amendments
till date.
(10)

Tracer under Directorate of The Odisha Staff Selection Commission shall
Town Planning.

decide

the

examination

syllabus
in

and

pattern

of

consultation

with

the

concerned Departments or HoDs by invoking
powers envisaged under the rule 13 of OSSC
Rules, 1993 and its subsequent amendments
till date.
(11)

Tracer (State Cadre field)

1. Odisha Ministerial Services (Methods of

under Engineer-in-Chief,

Recruitment and Conditions of Service in

Rural works.

the District offices of Department of Rural
Development) Rules, 2023 or any rules
framed by the concerned Department.
2. In case, there are no recruitment rules
framed,

the

Odisha

Staff

Selection

Commission shall decide the syllabus and
pattern of examination in consultation with
the concerned Departments or HoDs by
invoking powers envisaged under the rule
13

of

OSSC

Rules,

1993

and

its

subsequent amendments till date.
(12)

Tracer under Engineer-in-

Odisha Ministerial Services (Methods of

Chief, Water Resources.

Recruitment and Conditions of Service in the
District offices under Department of Water
Resources) Rules, 2019.

<!-- page 4 -->

4

(13)

Architectural Assistant

Odisha Junior Architectural Service (Method

under Chief Architect

of Recruitment and Conditions of Service)
Rules, 1994.

(14)

Cameraman under I & PR

Odisha Information and Public Relations

Department

Technical Service (Method of Recruitment
and Conditions of Service) Rules, 2024.

(15)

Photographer under I & PR

Odisha Information and Public Relations

Department

Technical Service (Method of Recruitment
and Conditions of Service) Rules, 2024.

(16)

Sound Recordist under I &

Odisha Information and Public Relations

PR Department

Technical Service (Method of Recruitment
and Conditions of Service) Rules, 2024.

(17)

Mechanic under I & PR

Odisha Information and Public Relations

Department

Technical Service (Method of Recruitment
and Conditions of Service) Rules, 2024.

(18)

Video Film Editor under I &

Odisha Information and Public Relations

PR Department

Technical Service (Method of Recruitment
and Conditions of Service) Rules, 2024.

(19)

Assistant Operator under I

Odisha Information and Public Relations

& PR Department

Technical Service (Method of Recruitment
and Conditions of Service) Rules, 2024.

(20)

Junior Draughtsman under

The Odisha Staff Selection Commission shall

HoD Cadre

decide

the

examination

syllabus
in

and

pattern

of

consultation

with

the

concerned Departments or HoDs by invoking
powers envisaged under the rule 13 of OSSC
Rules, 1993 and its subsequent amendments
till date. ”

By Order of the Governor
SURESH KUMAR VASHISHTH
Principal Secretary to Government
Printed and Published by the Director, Printing, Stationery and Publication, Odisha, Cuttack-10
OGP/SBP Ex.Gaz.6036-183+45
