---
doc_id: "3d0dbafee1f481b5"
source_url: "https://cms.bhubaneswarone.in/uploadDocuments/Tender/TenderFile_020260814_171004.pdf"
ministry: "Bhubaneswar Development Authority, Odisha"
title: "(616/13-Aug-2026)"
date: ""
pages: 1
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "d28e2d71286c1a0c"
---

<!-- page 1 -->

BHUBANESWAR DEVELOPMENT AUTHORITY
AKASH SHOVA BUILDING,
SACHIVALAYA MARG, BHUBANESWAR - 751001
Visit us at. hitp:/vww.bda, gov.in
—————_ ଜଜ”? ନ ଜଦ-ଦ‰୦ˆ ବ୦“‰?ନ¡-
i No. £/6_ ର BDA, Bhubaneswar the ୨୬୭ # Aug’2026
Office Order
Tender invited vide Bid Identification No-360 dated 13.05.2026 for the work “Provision
of Solar Street Lights in different Parks in Bhubaneswar (Part-1 & Part-II)” is here by cancelled
due to administrative ground. କ୍ତ
Nyy
(୬୩୩୬
on ecutive Engine;
jvision-IV, bag Ye
Memo No. G/T dated 13 - / 6 9026 ଓ
Copy to C.A to V.C for kind information of the Vice Chairman, BDA, Bhubaneswar.
Executive Pngine T
ivision-IV, BD fo
Memo No. bIE dated / 2 08 ORs Bip 5୭
Copy submitted to the Chief Engineer-Cum-Engineer Member, BDA Bhubaneswar for
favour of kind information. ~ Aa ୧
(# ଣା
@ - 7 Executive Engineer
Branson, BDAK«
Memo No. L/9 dated 73 08 AWE | Sar
Copy submitted to the Superintending Engineer, Division No. I & III, B.D.A/ Executive
Engineer, II, V & Chief Horticulturist, BDA, Bhubaneswar for information.
oo ngineei a ୦୭
Vision-IV, apa ୪5୨
Memo No. BA? ଏ 7 7 0s AIRE ! XN
Copy to the Sr. Managef (IT), BDA, Bhubaneswar for information and necessary action.
(୯୪୯
Executive Engine:
. ୮ Bip ison BDAXa  -
al ne
