---
doc_id: "3d8cdcfebb10de23"
source_url: "https://cdn.bseodisha.ac.in/images12/Tender-Waste-paper-2024.pdf"
ministry: "Board of Secondary Education, Odisha"
title: "» Tender Notice fo Waste paper-2024"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c3d4f0d5d7aac763"
---

<!-- page 1 -->

BOARD OF SECONDARY EDUCATION, ODISHA, CUTTACK.
TENDER CALL NOTICE
No 123/(Store-I)/ dt. 08.01.2024
Sealed tenders in the prescribed format in double sealed cover paper for sale of
following categories of waste paper for recycling only are invited from the intending Paper Mills /
waste paper dealers having valid GST Regd. No. and PAN card. The tender paper can be
downloaded from the website www.bseodisha.ac.in from 10 a.m on 09.01.2024 The tenderer
shall deposit Rs.5,000/-+(GST@18%) amounting to Rs 5,900/- ( Rupees Five Thousand Nine
Hundred ) only

towards the cost of tender paper in shape of Bank draft payable at Cuttack in

favour of Secretary ,Board of Secondary Education,. Odisha along with the tender paper. The
tenderers are required to submit the tender paper duly filled in all respect, with all requisites and
EMD of Rs.50,000/-(Rupees Fifty thousand) only in shape of Bank draft drawn in favour of
Secretary , B.S.E. Odisha, payble at Cuttack by Speed Post or by hand. The tender should
reach the office of the undersigned on or before 16.01.2024 up to 4.00P.M. . The same will be
opened on 17.01.2024 at 12 noon in the presence of the tenderers or their authorised
representatives, if any along with a power of attorney.
Details of waste paper and their offset price
Sl.
No.

Categories of Waste Paper

Approximate Quantity

Offset price per MT

1

Used and unused damaged
Answer Books

127 M.T

Rs.39,555.00 + GST

2

Obsolete Text books

1 M.T.

Rs.34,590.00 + GST

3

Other waste paper / miscellaneous

5 M.T.

Rs.32,999.00 + GST

The authority of the Board reserves the right to accept or reject any or all tenders
without assigning any reason there of.

Sd/SECRETARY

Page 1 of 10

<!-- page 2 -->



PLACE OF SUBMISSION OF TENDER
(I)

SEALED TENDER BOX PLACED AT THE
CONFERENCE HALL OF THE B.S.E. ,ODISHA ,
CUTTACK .

( II )

REGD. POST / SPEED POST ADDRESSED TO
SECRETARY, B.S.E. ODISHA, CUTTACK-753001



Downloading of Bid DOCUMENTS
at 10.00 A.M



CLOSING DATE OF RECEIPT OF TENDER PAPER
16.01.2024 4.00 P.M.



OPENING DATE & TIME FOR TENDER
17.01.2024 AT 12 NOON.



PLACE OF OPENING OF TENDER -

from 09.01.2024

CONFERENCE HALL OF B.S.E., ODISHA, B.K.ROAD,
CUTTACK.

Page 2 of 10

<!-- page 3 -->

BOARD OF SECONDARY EDUCATION ,ODISHA, CUTTACK -753001
Tender Form for purchase of Waste Paper
FINANCIAL BID
1. Full Name & Address of the Mill/Firm/ Contractor :
Telephone/Fax Number:-E-Mail ID:
Mobile No:
2. Pan No. & Date :
3. Self attested true copies
of PAN Card, audit
Report & Income Tax
Return of last year to be
attached.
4. a) GST Registration :
No._____________ Dt.____________
YES/ NO

b) GST Deposit Receipt for last Qtr.:
5. Excise /DIC/ PMI Registration No. _______date ________

YES/ NO

6. Earnest Money- Rs.50,000/-( Rupees Fifty thousand only)
in shape of Bank Draft payable at Cuttack drawn on any
Nationalize Bank in favour of Secretary, Board of Secondary Education Odisha.
D.D No.
:
Date
:
Name of the Bank :
7. Cost of Tender Form –
Rs.5,900/-( Rupees Five thousand Nine hundred only)
in shape of Bank Draft payable at Cuttack
drawn on any Nationalize Bank
in favour of Secretary, Board of Secondary Education Odisha.
B.D No.
:
Date
:
Name of the Bank :
8. Details of Waste Paper for sale:
Sl.
No.
1

Approximate
Quantity

Categories of Waste Paper

Quoted price
per MT
/- + GST

Used and unused damaged Answer Books
127 M.T

2

Obsolete Text books

1 M.T.

/- + GST

3

Other waste paper / miscellaneous

5 M.T.

/- + GST

9. Validity of order: 12 months from the date of agreement/ work order.

Place:

Signature of Tenderer
with Designation & Seal

Date :

Page 3 of 10

<!-- page 4 -->

BOARD OF SECONDARY EDUCATION , ODISHA,CUTTACK -753001
ENCLOSURE TO TENDER FORM
Annexure – A
TECHNICAL BID
1. E.M.D. in shape of D.D. of Rs.50,000/-

Yes/ No

2. Cost of Tender Papers in shape of D.D. of Rs-5,900/-

Yes/ No

3.

(a) Valid GST Registration Certificate

Yes/ No

(b) GST deposit Receipt for last Qtr.

Yes/ No

(c ) Self-attested true copies of PAN Card,
and Income Tax Return last year
(d) Valid Excise Registration Certificate/ D.I.C/
P.M.I Certificate. ( Annexure- ‘C’ )
4. Power of Attorney if any of the Tenderer
5. List of organizations from whom waste paper
were purchased by Tenderer in the past.

Yes/ No

Yes/ No
Yes/ No
Yes/ No

6. Certificate for acceptance of Tender Document as per Annex. B Yes/No
7. Undertaking that the waste paper will be used for recycling only Yes/ No

Place:

Signature of Tenderer
with Designation & Seal

Date:

Note:- The tenderer will have to produce original documents refer to in Item
No.3 above for verification at the time of opening of tender.

Page 4 of 10

<!-- page 5 -->

Annexure- B
(Certificate to be recorded by the tenderer while submitting other)

We have carefully read and understood the important instructions from Para
from 01 to 16 and all terms and conditions Para 01 to 18 of Tender Form. We hereby
agree to abide by them without any prejudice and reservation.

Place:

Signature of Tenderer
with Designation & Seal

Date:

Page 5 of 10

<!-- page 6 -->

Annexure- C
(Format for production of Excise/DIC/ PMI Clearance Certificate.)

It is certified and declared that M/S (Name of Tenderer) ____________
has been registered under Excise/DIC/ PMI Department vide No.____________
dt.______________ and the above certificate is valid and also available in the
records of concerned department.

Signature:
Designation:
Name of the Excise/ DIC/PMI Officer:
Seal of the Excise/ DIC/PMI Department.

Page 6 of 10

<!-- page 7 -->

BOARD OF SECONDARY EDUCATION ,ODISHA, CUTTACK -753001
IMPORTANT INSTRUCTIONS TO THE TENDERERS FOR PURCHASE OF WASTE PAPER

1.

2.

3.

The tenderers are requested to submit their bid in double sealed cover i.e. Technical
Bid in one and Financial Bid in another. The envelope containing Technical Bid
should be super scribed as “Technical Bid” and the envelope containing financial
bid need to be super scribed as “Financial Bid”. Both the bids should be kept in
another sealed envelope & then be submitted.
Tender shall be submitted in prescribed form only and shall be completed in all
respects. Incomplete tender will be rejected.

The Tender to be submitted accompanying the following documents:
(i) A sum of for Rs.50,000/- (Rupees Fifty thousand only) as earnest money
deposit in shape of D.D. drawn on any Nationalized Bank payable at Cuttack
in favour of Secretary, Board of Secondary Education , Odisha, Cuttack753001. Tender without required amount of E.M.D. shall not be taken into
consideration. The earnest money deposit will be forfeited, if the tenderer fails
to execute the contract after acceptance of his offer by Board of Secondary
Education, Odisha within the time stipulated..
(ii) A separate Demand Draft Rs.5,900/-(Rupees Five thousand Nine hundred
only) should be deposited as cost of Tender Form fee (non-refundable)
drawn
on any Nationalized Bank payable at Cuttack in favour of Secretary, Board of
Secondary Education,, Odisha, Cuttack- 753001.
(iii) Self attested true copy of valid GST registration certificate.
(iv) Self- attested true copy of PAN card and Income Tax return of last year.
(v). The tenderer not personally remaining present and sending authorized
representative should attach a certified copy of the Power of Attorney issued in the
name of the attorney holder that the latter would attend the tender opening at the
office of the B.S.E, Odisha, Cuttack on the date of opening of tender would be
authorized to sign the tenders, agreements and other relevant documents.
(vi) Experience in details of purchase of waste paper by the tenderers in last two
years from other organisations/ Institutions/ Govt. Dept. etc., if any. An under taking
that the waste paper purchased by the Tenderer shall be utilised for recycling but
not for virgin pulp.

4.

Tender submitted without the document at Sl. No.3 above is liable to be
rejected without reservation.
5.
All documents furnished by the tenderer as per Sl.3 at above should be duly
certified and submitted in the Tender. Original copies of the documents
should be produced for verification at the time of opening of Tender.
6. (i) The tender shall remain valid up to 12 months from the date of agreement/
work order. However the authority of the Board reserves the right to extend the
validity period for sufficient reasons.
(ii) In the event the Tenderer fails to lift the waste paper within the time stipulated
in the work order the Board reserves the right to cancel the work order and the
Security amount shall be forfeited.
Page 7 of 10

<!-- page 8 -->

(iii) The time scheduled in the work order is only indicative and Board may
change the schedule and call upon the tenderer to lift the waste paper, by altering the
schedule in which event the tenderer shall lift the same during the agreement period.
Failure on the part of the tenderer shall be considered as violation of tender
conditions. .
7.

Offers having conditions other than that specified herein shall not be
considered and treated as invalid.

8.

(a) Rates should be quoted in the Tender Form excluding GST . Tenderers
quoting multiple rate will be rejected.
(b) GST will be charged in the bill on the date of lifting as fixed by the Govt.

9.

GST applicable will be charged extra on the quoted price.

10.

The President, B.S.E.,Odisha reserves the right to split the estimated quantity
for distribution of the lifting orders at acceptable rates to other tenderers.

11.

The price quoted is confidential. The Award of Contract (AOC) will be
considered on highest bidding rate approved by the authority for each
category. The President reserves the right to accept/ reject any offer even
though a Tenderer is H-1.
The successful tenderer shall have to deposit the total cost of waste paper
as will be determined by the authority of the Board in the manner directed
before lifting of waste paper.

12.

13.

The President reserves the right to allot the tender by splitting the categories
of waste paper and is at liberty to allot the tender of each category to different
tenderers.

14.

(i) The last date and time for the receipt of tenders complete in all respects is
on or before 16.01.2024 up to 4.00 pm. and The tenders received thereafter
shall not be considered on any ground.

15.

16.

(ii) The Tender will be opened on 17.01.2024 at 12 noon. Changes if any will
be communicated.
The right to accept or reject any tender or all tenders (Fully/Partly) without
assigning any reason is reserved by the President, B.S.E, Odisha.
Any dispute related to this tender and arising out of terms and conditions
thereof, the same will be subject to Cuttack judicial jurisdiction only.

Page 8 of 10

<!-- page 9 -->

BOARD OF SECONDARY EDUCATION, ODISHA, CUTTACK-753001
Terms and Conditions of the Tender for sale of Waste Paper

1.

The Tenderers who intend to recycle waste
paper only are allowed to
participate in the tender for purchasing waste paper from Board of Secondary Education,
Odisha, Cuttack.
2.
The successful tenderer shall have to furnish an undertaking to the effect that the
materials purchased will be directly put into digesters for pulping and any deviation
detected later shall entail action as per law.
3.
(a) The tenderer are requested to submit copy of valid GST registration certificate
and PAN card along with the tender.
(b) The tenderers are also required to submit attested photo copy of the registration
certificate of Excise/DIC/ P.M.I industries Dept., Cuttack along with the tender.
4.
The tenderers are required to deposit Rs.5,900/- ( 5,000/- + GST18%) only towards
cost of Tender Paper in shape of Bank Draft drawn in favour of Secretary, Board of
Secondary Education, Odisha, Cuttack - 753001.
5.
The tenderers are required to deposit Rs.50,000/- (Rupees Fifty thousnad) only
towards EMD in shape of Bank Draft drawn in favour of Secretary, Board of Secondary
Education, Odisha, Cuttack - 753001. The EMD of unsuccessful tenderers will be
refunded soon after
finalization of tender.Tender without EMD shall be rejected.
6.Tenderers shall quote their rate per MT in the Tender.
7. GST applicable will be charged extra on the quoted price.
8. Incomplete tenders / tenders without EMD/ Tenders without copy of the valid GST
Registration certificate, photo copy of PAN card / cost of Tender form shall be
rejected.
9.
The successful tenderers shall have to deposit Rs.1,00,000/- (Rupees One lakh)
only as security money in shape of Bank Draft in favour of Secretary, Board of Secondary
Education, Odisha, Cuttack, payable at Cuttack within a period of 05 days from the receipt
of assignment order from the Board, failing which the order shall be treated as cancelled
and in that case the EMD shall be forfeited. The security money will be refunded after
certification by the store section of the Board to ensure that all the waste paper have
been lifted by the tenderers for which the tender was invited. If the tenderer
fails to
lift all the waste paper or delay in lifting the paper the EMD and/ or security money will
be forfeited.

10. The successful tenderer shall have to deposit the total cost of waste paper as
will be
determined by the authority of the Board in the manner directed before
lifting of waste paper.
11. The cost of lifting and transporting of waste papers shall be borne by the
tenderer.
12. The weighment of loaded and unloaded vehicle carrying waste paper will be made
in the weighbridge in presence of the officials of BSE (O) in order to determine the quantity
of waste paper and the cost of the same shall be borne by the tenderer.
13. The tender shall remain valid up to 12 months from the date of agreement/ work
order. However the authority of the Board reserves the right to extend the validity period
for sufficient reasons.
14. (i) The quality and quantity of waste paper may be inspected by the tenderers before
quoting rates of each item.

(ii) In the event the Tenderer fails to lift the waste paper within the tim e stipulated
in the work order the Board reserves the right to cancel the tender and the Security
Page 9 of 10

<!-- page 10 -->

amount in deposit shall be forfeited.
(iii) The time scheduled in the work order is only indicative and Board may
change the schedule and call upon the tenderer to lift the waste paper, by altering
the schedule in which event the tenderer shall lift the same during the agreement
period. Failure on the part of the tenderer shall be considered as violation of tender
conditions. .
(iv) The last date and time for receipt of Tender complete in all respect is on or
before 16.01.2024 up to 4.00 P.M and the Tenders received their after shall not be
considered on any ground. The Tender will be opened on 16.01.2024 at 12 noon.
A change if any will be communicated.
15.

(i) Details regarding sale, submission and opening of Tender are as follows:

Sl.No

Details

1
2

Downloading of Tender Papers
Last date of Tender Submission

4.

Submission of Demand Drafts towards cost
of Tender Form/EMD so also all the documents
in original for verification

5

Tender Opening

Opening Date
16.01.2024

Closing
Date

Hrs.

Hrs.

10.00 A.M
16.01.2024 4.00 p.m
17.01.2024 12 noon

17.01.2024

12 noon

No deviations in the above scheduled will be entertained by the Board.
(ii) Any short of terms and conditions proposed by the tenderer shall not be
accepted.
16. Approximate quantity of waste paper with their offset price is given below:
Sl.
No.

Categories of Waste Paper

1

Used and unused damaged Answer

2

Obsolete Text books

3

Other waste paper / miscellaneous

Books

Approximate
Quantity

127 M.T

1 M.T.
5 M.T.

Offset price
per MT

Rs.39,555.00 + GST
Rs.34,590.00 + GST
Rs32,999.00 + GST

17. In case of any dispute arising in course of transaction of business the
decision of President, B.S.E, Odisha, Cuttack shall be final and binding on the
part of the tenderer.
18. The President reserves the right to accept or reject any or all tenders without
assigning any reasons thereof.

Sd/SECRETARY

Page 10 of 10
