---
doc_id: "64b6df07c74ffdea"
source_url: "https://cdn.bseodisha.ac.in/images12/CCTV_Tender_Paper_12_01_2024.pdf"
ministry: "Board of Secondary Education, Odisha"
title: "CCTV Tender Paper"
date: ""
pages: 7
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "052062bd110fcbb4"
---

<!-- page 1 -->

SEES
/ Soy „¥ BOARD OF SECONDARY EDUCATION, ODISHA,
; Vo CUTTACK
es
Notification No _ © 80 /(Exam.Conf)/ Dt_| afer / ଥିଣଥଥ
TENDER NOTICE FOR TEMPORARY INSTALLATION OF CCTV CAMERAS AND VIDEO
SURVEILLANCE SYSTEMS AT DIFFERENT EXAMINATION CENTRES ALL OVER THE
STATE OF ODISHA IN CONNECTION WITH ANNUAL HSC, SOSC & MADHYAMA
EXAMINATION 2024
†. INTRODUCTION
Board of Secondary Education (BSE), Odisha, Cuttack invites techno-commercial proposal for the following
services for the upcoming examinations:
A. Artificial Intelligence based Live CCTV surveillance with Video Analytics features
B. Live CCTV Surveillance during Examinations at multiple Exam centres
C. CCTV recording during Examinations at multiple Exam centres
D. Setting up of Integrated Command Control Centre at BSE HQ for Live CCTV monitoring feed
E. GPS Tracking of Squad members
11. BIDDER PRE-QUALIFICIATION CRITERIA
1. `` Bidder should be a Central/State PSU registered under any Ministry of Govt of India or Govt. of
Odisha and should be into existence in India for last 7 years as on day of bidding.
11. Bidder should be profitable in last 5 FYs and should have an Average Annual Turnover of INR 100
Crores during the last three financial years i.e. FY 2020-21, 2021-22 & 2022-23
iii, ` Bidder should be in the business of delivering Examination based services at least for last 5 years
as on day of bidding.
iv. Bidder should be profitable in last 5 FYs and should have an Average Annual Turnover of INR 100
Crores from Examination based projects during the last three financial years i.e. FY 2020-21, 2021-
22 & 2022-23.
v. Bidder must be ISO 9001 as on day of bidding.
vi. Bidder should submit their Company Registration certificate, PAN and GST certificate along with
their Technical Bid.

vii. ` Bidder should have experience of delivering services of CCTV surveillance in any Examination
based project in India in last 5 years as on day of bidding.

viii. | Bidder should have experience of setting up Command Control centre in any Examination based
project for any Govt. Client of India in last 5 years as on day of bidding.

ix. Bidder has to bid for all the required services as part of Scope of work of this tender. Conditional /
Partial bid will be rejected out rightly.

x. Consortium / Joint venture bid won't be allowed.

xi. To ensure the IT security and encryption of CCTV data feeds, Bidder should submit MAF from
OEM of VPN hardware along with their certification such as CE/RED, UKCA, CITC, ISACA,
RCM, CB, E-MARK, GCF and declaration of software security.

xii. To ensure the IT security and encryption of CCTV data feeds, Bidder should submit MAF from
OEM of CCTV hardware along with their certification such as ISO 14001, ISO 27001, ISO 45001,
Full time ONVIF member, UL and GDPR compliant and should be into existence in India since
last 10 years as on day of bidding with manufacturing in India since last 5 years.

xiii. | OEM of UPS should have certification such as ISO 9001, TL9000, BIS, CE, ROHS, FCC, MII
certificate (class 1) certified, E-waste EPR registration certificate of producer from CPCB received
in last 3 months as on day of bidding. =

xiv. Technical Demonstration will also be called between the bidders and will be a rejection criteria in
case Committee doesn’t find it satisfying.

Page 1 of 7

<!-- page 2 -->

GE
fork fy BOARD OF SECONDARY EDUCATION, ODISHA,
vos CUTTACK
Wee
xv. Bidder should submit self-attested documentary evidence complying with all points of “Bidder PQ’
criteria and ‘Technical specifications’ of this Bid along with their Technical Bid.
Ill. SCOPE OF WORK
Category A: Artificial Intelligence based Live CCTV surveillance with Video Analytics features at
Classrooms and Strong room
BSE Odisha is keen to implement Artificial Intelligence based Video Analytics features during the Live CCTV
surveillance system at Exam centres.

1. Installation of CCTV, DVR/NVR, adequate HDD storage, UPS backup of 15 minutes, dedicated Internet

bandwidth, Public IP(s) & its accessories at each Exam hall on rental basis.
2. Generation of Alerts
(i) ifany movement is detected at Entry/Exit Gates during Examination.
(ii) if the furniture inside the classrooms is not properly arranged
(11) if the cameras are offline or are tempered by Masking or Black Screen
(iv) ` if Invigilator is not moving even after the specified time/ Inactivity is detected in Invigilator’s
movement
(v) _ if there are more than allowed number of people in Question Paper Room during the defined hours
(vi) ` in case of detection of Crowd/ Fight/ Conflict inside the Classroom
(vii) Intrusion detection: Intrusion alerts based on Intruders within a defined perimeter (Region of
interest)
(viii) List of cameras which are completely offline or not available for analysis for certain duration

3. On identification of any type of violation, an Alarm should be raised at the Integrated Command Control
centre situated at BSE Odisha HQ.

4. The confidentiality of data is very important and therefore, it would be the responsibility of the Service
Provider to maintain data security of highest standards.

5. The list of cameras to be installed by Service Provider and related details along with Locations would be
made available at least 2 weeks before the commencement of CCTV monitoring activity.

6. The Service Provider should provide access to a dashboard with real time updates to violations.

Category B: Live CCTV Surveillance during Examinations

1. Installation of CCTV Color cameras should be made at least one day in advance from the scheduled date
of examination and/or in such a way that the CCTV are required to be functional for one hour before the
scheduled time of commencement of the examination and 0.5 hour after the completion of the
examination.

2. To organize and provide required manpower to install the CCTV devices at the Centers.

3. CCTV feed data should travel through secured VPN Tunnel and one copy should be maintained at Cloud
based storage.

4. Cameras should be connected to Internet and Service Provider has to ensure that at least 90% live camera
feed is made available at HQ control room at all times during the entire duration of examination.

5. Live Camera feed should be made available at 30 Districts(s) as well. Service provider has to provide the
web link to access the live feed and training should be imparted to DEO staff for functioning of VMS
software. However, IT Infrastructure such as LED, Desktop/Laptop and Internet connectivity at each
DEO office will be arranged by the DEO office itself.

6. During the period of examination, CCTV facility shall not be interrupted due to any technical fault, etc.,
and the Service Provider shall take due care of functioning of CCTV with adequate backup of CCTV
during the conduct of examination and as per the time period mentioned in the Work Order of respective
assignments.

Page 2 of 7

<!-- page 3 -->

. ୪୪5
ରନର ‘3, BOARD OF SECONDARY EDUCATION, ODISHA,
| 4)
“୭ ”† CUTTACK
NOAA
SUE

7. UPS or Diesel Generator Power backup arrangement would come under the scope the BSE Odisha. In
addition to this, Service Provider has to arrange 15 minutes backup at each exam centre for their CCTV
infrastructure.

8. The hardware required for the job shall be procured and maintained by the Service Provider and Training/
sensitization of staff deployed at the examination Centres shall be imparted by the Service Provider.

9. Internet and other arrangements on every Exam center would be in the scope of Service Provider.

10. Service Provider should have adequate number of Color CCTV cameras available (as backup) in case of
emergency.

11. The recorded videos shall be handed over to the authority of the Board in external hard disks within 30
days from the date of last examination. In case of immediate requirement, the vender will have to provide
video footage of a centre, of a day or days immediately.

12. Installation and commissioning of CCTV at every Examination center at the time of examination
conducted by BSE, ODISHA, as per requirement on turnkey basis for close observation of activities of
the candidates.

13. Service Provider has to install CCTV camera as directed by BSE, ODISHA at the time of giving Work
order.

Category C: CCTV recording during Examinations

1. ` It includes installation of CCTV cameras along with the requisite hardware and software for the CCTV
surveillance system at the designated location i.e., Exam Centres/Nodal Centres

2. The supplier should provide turn-key solution for the entire site.

3. The DVR shall be connected to the display unit of the examination centre.

4. All the cameras installed in the centre shall be connected to the DVR for uninterrupted recording of
videos. The DVR will be placed in the centres, in the room of Centre superintendent or any room selected
by him.

5. UPS or Diesel Generator Power backup arrangement would come under the scope the BSE Odisha.

6. ` 71 installation will be for a period as mentioned in financial bid, during conduct of HSC Examination
likely to be held in the month of February- 2024.

7. Installation will be made at approximately multiple examination centres located throughout the state.

8. The recorded videos shall be handed over to the authority of the Board in external hard disks within 30
days from the date of last examination. In case of immediate requirement, the vender will have to provide
video footage of a centre, of a day or days immediately.

9. The format of video must be easy and should be played in VLC Media Player/ Window Media Player
with clear vision.

10. The External hard disk shall contain video folder of individual centre. Videos shall be arranged date wise,
Camera wise. Video footage of exam hall shall be from 30 minutes before start of exam till 15 minutes
after the exam gets over but the strong room camera video footage shall be continuous and uninterrupted
from starting of exam day till the completion of examinations.

Category D: Setting up of Integrated Command Control Centre at BSE HQ for Live CCTV monitoring

feed

1. Service Provider has to setup Integrated Command Control centre at the Office of BSE Odisha on a rental
basis for a period as defined in Financial bid.

2. Service Provider will be provided a Hall room space for establishment of ICCC at BSE Odisha HQ.

3. Service Provider has to setup below mentioned IT items:

a. Video wall having 8 LED’s (In case of space constraint, it could be split into 2 parts)
b. LED size should be of minimum 50 inches
୦. Video Wall Controller
d. Adequate Laptop / Desktop and latest Windows Operating system for smooth controlling &
functioning of Video wall
Page 3 of 7

<!-- page 4 -->

EEE PWS LLL LLL LLL LLL LLL
BR

q ୮ > BOARD OF SECONDARY EDUCATION, ODISHA,

±

& ® CUTTACK

SEES
e. Internet line of 100 Mbps bandwidth
£. Suitable IT Software’s to safeguard the Data privacy
4. For multiple streaming/viewing of live CCTV Feed in HQ control room, the LED screens set up by the
Service Provider should be able to identify state, city, examination centre and exam room.

5. Computer/ Laptop and manpower will be provided by Service Provider in HQ Control Room.

6. Service Provider has to do a makeover of the Hall room completely which should include setup of below
mentioned non-IT items:

a. Acrylic frame for Video Wall with BSE Odisha office logo branding

b. Red carpet flooring

©. Furniture works including sitting Workstation table with Chair

d. Miscellaneous table

€. Sofas for Dignitaries

f. Decorative and Wall coverings

g. Planters and Green elements

h. Cabling Infrastructure: Standardized cabling for all IT setup to be installed as part of this Job Work.
Install necessary cables and connectors at the ICCC hall for smooth functioning of the ICCC.
Cabling should be done in such a way that the aesthetic of the ICCC is maintained.

7. Service Provider has to arrange and setup the IT and Non-IT/ Hardware and Software items on a rental
basis only and has to remove the complete infrastructure/setup immediately after the project duration is
over, or in case decided otherwise by the BSE Odisha and confirmed through a written notice.

8. Service Provider has to deploy Technical Manpower for the functioning of the Video wall, as & when
required by the BSE Odisha.

9. Service Provider will be responsible to arrange food and lodging facility of its own for their own
manpower.

10. BSE Odisha will make available and arrange:

a. SPOC for this project work

b. Access to ICCC room during office hours

୧. Access to ICCC hall room during extended hours, if required for early setup

ଏଁ. Power supply in the ICCC room

e. Proper Lights & Air Conditioning of ICCC room

£. Physical security of Infrastructure to be setup as part of this Job Work

g. Generator Power backup for ICCC room
Category E: GPS Tracking of Squad members
The service provider is responsible for delivering a comprehensive GPS tracking solution for the Squad
Officers, equipped with the following features:

1. GPS Tracking via Android Application: The service provider shall provide an Android-based
application that allows real-time GPS tracking of each squad officer and in case, they are travelling their
official vehicles then provision of vehicle GPS tracking should also be provisioned.

2. One-time User registration: While the user download the application through the APK file or link,
user should be allowed to register in the application by clicking their live photograph and OTP based
verification of phone number should also be done.

3. FR-Based Attendance: The application must record attendance once per day at the start of each
working day for the Squad officers to ensure the authenticity and security of the user profiles.

4. Real-time Location Updates: GPS tracking must provide location updates at regular intervals, with a
frequency of every 15-30 minutes to ensure accurate location monitoring.

5. Health Status Monitoring: The system should monitor the health status of each device and notify if
any device goes offline for more than 30 minutes. i

6. Summary Report Generation: Enablement of a downloadable summary report for each Android
application user.

Page 4 of 7

<!-- page 5 -->

ଣା ® ` BOARD OF SECONDARY EDUCATION, ODISHA,
¥ <p CUTTACK
oy,

7. Exam Centre Mapping: The Android application must include a feature to map exam center

coordinates on the application map.

8. Geo-Fencing: The system should allow for the creation and management of geo-fences, enabling alerts

to be triggered when squad officers enter or exit specified geographical areas.

9. Report submission: Squad officer, if required, should be allowed to share the images of Case sheets

relevant to any Exam centre through the Android application.
10. User Manual: The service provider should provide user video & document manual to access the
Android application and its functionalities.
11. BSE Odisha will make available and arrange:
a. Each Squad officer should have their own fully charged battery Android mobile device with
active Internet at all the times while on official duty.
b. BSE Odisha should make available the Name, Contact details of squad officers at least 2 weeks
in advance to the service provider.
Iv. PAYMENT TERMS
1. 30% of the value of work order at the time of Go-Live of all the Venues.
2. Rest 70% after completion of project duration.
3. Payment will be made within 15 days(s) of submission of Invoice along with Go-Live document proof,
signed by the concerned authority from BSE, Odisha.
ହୁ BID SECURITY
10% of the value of work order raised during the contract validity period and may be furnished in the form of
Bank Guarantee as performance security. Earned money security value of Rs.50,000/- to be deposited through
RTGS in Board’s SBI Accounts No:-37526804456, IFSC Code- SBIN0001663 at the time of submission of
tender paper through online.
VI. CONTRACT VALIDITY
Rate Card will be valid for a period of two (2) years with an extension clause of another one year with mutual
consent, from the date of signing of service agreement between successful bidder and BSE Odisha.
VIL. MODE OF SUBMISSION
The sealed techno-commercial offer shall be submitted by the interested Firms through Email at
admin _bseodisha.od@nic.in on or before 05.00 PM on January 21, 2024 in two different PDF files (separately
for Technical & Financial Bid) addressing to the Secretary, B.S.E., Odisha, Cuttack. The Financial Bid will
be in Password locked encrypted format. The sealed documents will be opened on January 22, 2024 at 11:00
AM. The participating firms or their representatives are at liberty to attend the proceedings of opening of the
tender.

After opening the technical bid, the selected Bidder shall be required to give live demonstration/
presentation of the proposed project on the same day by 02.00 PM.. The qualified firms will be intimated to
send the financial Bid Password between 03.00 PM to 3.30 PM for opening of financial bid at 04.00PM.on
the same day i.e. 22/01/2024 .

Page 5 of 7

<!-- page 6 -->

Se
4 Ze
/ EF BS
j & ୮ ‰ BOARD OF SECONDARY EDUCATION, ODISHA,
| ଏ Bb CUTTACK
Oe,
j VII. PENALITY
is Non execution or non-completion of assigned work in time or execution of work without specification as
laid down by the Board will result in penalty which will be decided by the President, B.S.E. Odisha,
Cuttack.
2. The President, B.S.E.(O), Cuttack reserved the right to reject any or all offers without assigning any
reasons thereof depending upon merit/ quality and factors in the interest at the Board.
IX. FINANCIAL BID FORMAT
1, Name of firm
2. Registration no. of the firm
3. Name of the proprietor
4. Address of the firm
eee Minimu Minimum Per Camera
ae SERVICE ee Period m No. of uOM Unit Price hire
ORY DESCRIPTION ee Duration*** No. of Venue or S (Exel. GST) Charges
Days** User** (Excl. GST)
A Artificial Intelligence 8to10 Feb 20to 14 150 Per ୧ z
| based Live CCTV March 4 Venue
| surveillance with Video
Analytics features at
| Classrooms and Strong
| room 3 = ae Giga Ss eRe es 5205 SE RGN is < aS
B Live CCTV Surveillance 8to10 ୫୬୬୮ 12 to 23 312 Per ଝି z
Service during March 5 | Venue
| Examination as ୮୩୦୮ | |
Scope of Work EE eee eee eee eee eee
` € CCTV recording (Non- 810 10 ` ୮୪୯୬ 20 to 14 600 Per ଝି z
Live) of Examination March 4 ‘Venue
Centres during
Examinations as ୮୦୮
scope of work 2555-05-05 |£ 5 Ss Se el eee Lee
| ` 9 ` Setting up of Integrated 1 Feb 9 26 1 Per = z
| Command Control to Venue
| Centre at BSE HQ for March 5
| Live CCTV monitoring
L_ feedasperscopeofwork | oe!
` E ୦୮୭ Tracking ofusersof ୩୩ Feb 20 to 14 80 Per |< < |
Flying Squad team । Sess Seren Abs ore 21:22 ee ani Ser ie nee
|
|! _ ୩୩୩ ୩୪ ୩ ୩ „“ ୮ ସ। „୫୩ ଘା ।॥ କମା
× Technical Bid of intended firms
1. Name of the Firm
2. Address: With email ID / Mobile No.
3.(i) Name of the Proprietor
(ii) Registration no of the firm from any approved authority of Odisha or Central
Agency.(copy of the Registration Certificate to be furnished).
(iii) Core business area of operation
(iv) No of years in the business
Page 6 of 7
i

<!-- page 7 -->

Fron
coy BOARD OF SECONDARY EDUCATION, ODISHA,
ar, CUTTACK
୯୧୮୮୭୬୨୪
(v) PAN No. (Xerox copy of PAN card to be attached).
4. Client reference and brief details of the similar projects undertaken if any.
5. Schematic diagram of the proposed system
6. Approach paper for the proposed project.
7. Any other relevant information.
8. Audited financial statement for the last one year.
9. GST No:-
(Copy of GST Registration Certificate to be attached)
10. GST Clearance Certificate.(Deposit receipt of last Qrs).
11. IT Clearance Certificate.(of last Qrs).
12. EMD (refundable ) in shape of RTGS.
Signature of the Tenderer
*The firms qualifying for the technical bid will be intimated to send the PW for opening of Financial Bid.
** Number of CCTV / Days / Venue / User: Bidder has to quote considering the minimum numbers as
mentioned above. Venue / User count may increase/ decrease, if required and would be intimated to successful
service provider well in advance.
*** Period Duration: Duration is mentioned for the year 2024.
**** Grand Total: Service provider with lowest Grand total will be declared L1 and awarded complete work
order immediately.
a ॥ 121।\ 2221
Secretary
B.S.E. Odisha, Cuttack
Page 7 of 7
