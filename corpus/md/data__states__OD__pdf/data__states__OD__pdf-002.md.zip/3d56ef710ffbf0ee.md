---
doc_id: "3d56ef710ffbf0ee"
source_url: "https://inpr.odisha.gov.in/sites/default/files/2025-10/1st%20Corrigendum.pdf"
ministry: "Information and Public Relations Department, Odisha"
title: "Download(416.52 KB)"
date: ""
pages: 2
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "7cabea878f1f3738"
---

<!-- page 1 -->

Government of Odisha
= Information and Public Relations Department
` *## J . / 2 wo
/¿⁄ ⁄/2/452
ipR-EP-GP-0003-2025/, /5£/2 [IPR vores, CLIOLPO C
15 Corrigendum
Tender Call Notice No. 15037 ptd:06.10.2025
In continuation of the RFP No. 45037, Dated 06.10.2025 Inviting eligible bidders to
“Conceptualize, Design and Fabricate the Odisha Pavilion at India International Trade Fair(IITF)-2025,
Bharat Mandapam, New Delhi“, itis hereby informed all concerned that some modifications are made
in the RFP document. please visit the website ie. https://inprodisha.gow.in & https://odisha. ov.in.for
detailed information
15614 /, E = Ak
Memo No. P dak BBSR, Dated /6 ¿/#22 S
Copy forwarded to the PS to Additional Chief Secretary to Govt., | & PR for kind information of
Additional Chief Secretary to Govt., Director (Technical) respectively. pee.
a Ze
¿୭୩ ନି
1: ie y ହି ma Deputy Director
Memo No”, a Date. ¿5 ‘0 202
Copy forwarded to the System Analyst for information and necessary action. He is requested to take
appropriate steps for uploading the Request for Proposal (RFP) in the website of Information & Public
Relations Department ।୩୯୮୦୭: inpr.odisha.gov.in & website of Govt. of Odisha
hetps://odisha.gov.in.
4 5
ah ) Any AG
sft ^ Deputy Dire: Nb
50. % _ | | ae ¿/'>⁄‰>2« ଆଖୀ
Copy forwarded to the Di j i .
ହଉ ନୀ ନ Y 5 to 8 (ADVT) for information and necessary action. He
publish the 1 corrigendum notice w.r.t. caption No. 2-12 on 07.10.2025.
bora 95
yrs
୮୮୮୭ 5
deputy ୮୮୩୦ ୮

<!-- page 2 -->

5 8 SS ae ``
\
: ୩
\
\
After discussions with the Prospective bidders in the pre-bid Meeting held on 13.10.2025,
the following Provisions/clauses of the RFP No. 15037 Dated 06.10.2025, of the 1apR Department
are hereby modified as under:
1. Inthe Preliminary Scrutiny (1* Stage) Section, the Point no. (P) shall be read as “Turn-over
Certificate of last 5(Five) years ending on 303.2024 duly certified by the CA” (Refer page 11
of the RFP document)
2. In the Tech-3 Section (Legal Constitution & Number of Years of Existence), under the sub-
section “GST Registration and Return Filing Status”, the supporting document requirement
shall be read as “Registration Proof: Up-to-date GSTR-3B filing copies.”
S4/—
DIRECTOR
