---
doc_id: "0aaeaab89fb472ff"
source_url: "https://www.opgc.co.in/plc/Environment_Policy.pdf"
ministry: "Odisha Power Generation Corporation Ltd., Odisha"
title: "Environment Policy"
date: ""
pages: 1
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "ec66b28ff46c37f9"
---

<!-- page 1 -->

v
re Environment Policy €
୧୮ ଂ
୦୮୦୦
OPGC understands the importance of the Environment and Jn recognition of the interests of the
society in securing sustainable industrial growth, compatible with a wholesome environment, OPGC
affirms to adhere the highest possible levels of performance in environmental compliance, practices,
stewardship and assigns high importance to promote and maintain a pollution-free environment in
all its activities.
Objectives
. To adopt a pro-active approach and place environmental aspects as one of the prime
consideration in decision-making process.
e To comply with all applicable laws governing environment protection through
appropriate mechanisms.
. To constantly improve upon the standards of pollution control and provide a leadership
in environment management.
e To ensure efficient and optimal use of resources such as land, water, fuel, construction
materials, oils, and chemicals etc. especially the non-renewable ones.
` To use non-polluting and environment-friendly technology.
e To monitor regularly air, water, land, noise and other environmental parameters.
e To spearhead waste management by adopting the 3Rs principle (Reduce, Re-use and
¥ * Recycle) and safe disposal.
. To develop employees’ awareness on environmental responsibilities and encourage
adherence to sound environmental practices.
° To work closely with Government and local authorities to prevent or minimise adverse
consequences of the industrial activities on the environment.
` To actively participate in social welfare and environmental development activities of the
locality around its Units.
e To create carbon sink by adding green cover in and around ITPS.
5 224 _
Effective from: 12.08.2025 Sri Anjana Ranjan Dash
Director (Operations) & Occupier
