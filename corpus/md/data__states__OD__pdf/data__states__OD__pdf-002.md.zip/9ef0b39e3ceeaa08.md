---
doc_id: "9ef0b39e3ceeaa08"
source_url: "https://odishatransport.gov.in/Application/uploadDocuments/Notification/Rules_1789661569.pdf"
ministry: "Odisha Motor Vehicle Department"
title: "VIRTUAL HEARING OF CASES CAUSE LIST ON 18.09.2026 AT 11:30 A.M"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c975e1c8a4433860"
---

<!-- page 1 -->

BEFORE THE TRANSPORT COMMISSIONER, ODISHA
Cause List for 18.09.2026
Following cases will be taken up for virtual hearing through video conferencing at 11.30 A.M.
Sl.
No.
1.
2.
3.
4.
5.

Case No.
TRA No.5 of
2026
TRA No.6 of
2026
Misc. Case
No.33 of 2026
Misc. Case
No.31 of 2026

Name of
parties
Sri Ladi Tukaram Vrs. TROcum-RTO, Rayagada
Bijay Kumar Mahapatra Vrs.
TRO-cum-RTO, Cuttack
Nirmala Chandra Sahoo Vrs.
Arabinda Lenka
Pradeep Kumar Patel Vrs.
Pradeep Kumar Debta
Pradeep Kumar Patel Vrs.
Pradeep Kumar Debta

Name of the Advocate

Remarks.

Sri H. P. Mohanty, Adv.
Addl. Standing Counsel (Tr.)
Mr. K. Mohammad, Adv.
Addl. Standing Counsel (Tr.)
Sri S. Mishra, Adv.

Tax Matter

Permit matter

Sri H. P. Mohanty, Adv.

Permit matter

Sri H. P. Mohanty, Adv.

W.P. (C)
No.17668/2026

Tax Matter

<!-- page 2 -->

Guidelines to attend virtual hearing through V.C. in Microsoft Team on 18.09.2026
•
•
•
•

For Desktop/Laptop user, Click on the link and select continue on this browser.
For Smart Phone user, download Microsoft Teams App from Google Play store and install.
Click on the link, then click on join hearing.
In the place of type your name, follow below format for hearing before Transport
Commissioner, Odisha.
Format :- Sl. No.<space> vehicle No. of owner or objector or petitioner or opp. Party or
respondent.
Details of virtual hearing of cases through video conferencing in Microsoft Team
on 18.09.2026

Date

Hearing
details

Time

Link for VC

18.09.2026

Cases
at Sl.
No.01
to 05 of
cause
list.

11.30
A.M.
to
12.30
P.M.

https://teams.microsoft.com/meet/416735460575987?p=mj6y6nu85qQ59ZR2uE
