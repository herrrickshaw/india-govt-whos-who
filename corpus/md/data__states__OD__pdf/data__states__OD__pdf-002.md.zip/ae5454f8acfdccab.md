---
doc_id: "ae5454f8acfdccab"
source_url: "https://it.odisha.gov.in/sites/default/files/2025-11/Gazette%20Notification%20of%20IT%20Policy%20-%202025.pdf"
ministry: "Electronics and Information Technology Department, Odisha"
title: "Download(421.35 KB)"
date: ""
pages: 26
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6f532b8201aa3f0b"
---

<!-- page 1 -->

EXTRAORDINARY
PUBLISHED BY AUTHORITY
No.4604, CUTTACK,

TUESDAY, OCTOBER

28,

2025/ KARTIKA 6,

[No.4882─EIT-DEV-II-POL-0001/2025/E&IT.]
ELECTRONICS & INFORMATION TECHNOLOGY DEPARTMENT
RESOLUTION
The 9th September, 2025
Odisha Information Technology (IT) Policy – 2025
Table of Contents
1. State of IT Industry in India......................................................................

3

2. State of IT Industry in Odisha.................................................................... 4
3. IT Initiatives in Governance in Odisha....................................................... 7
4. Vision.......................................................................................................... 9
5. Objective..................................................................................................... 9
6. Mission........................................................................................................ 10
7. Investment Facilitation Mechanism............................................................. 11
8. Eligibility for Incentives............................................................................... .12
9. Commencement and Eligibility................................................................... .13
10. Incentives.....................................................................................................14
1. Land................................................................................................ 14
2. Capital Investment Subsidy.............................................................16
3. Specific Incentives for IT Parks....................................................... 16
4. Rental Subsidy................................................................................ 17
5. Power Incentive............................................................................... 18
6. SGST Reimbursement.....................................................................18
7. Interest Subsidy............................................................................... 18
8. Recruitment Assistance................................................................... 18
9. Skilling and Development................................................................ 19
1. Human Capital Upskilling Subsidy....................................... 19

1947

<!-- page 2 -->

2

2. Internship Subsidy............................................................... 19
3. Skill Development Initiative..................................................19
10. Marketing Incentive......................................................................... 19
11. Patent Registration Incentives........................................................ 20
12. Reimbursement of PF/ESI contribution........................................... 20
13. Research and Development Incentive.............................................20
14. Support for development of a Cable Landing Station..................... 20
15. Specific Incentives for Large & Mega IT Investments..................... 21
16. Incentives for Center of Excellence (CoE)...................................... 21
17. Innovation/ Acceleration Fund......................................................... 21
18. Incentives on AI Compute................................................................ 22
11. Public Procurement & Procurement of IT Software & Services by
Government.................................................................................................. 22

12. Governance Mechanism.............................................................................. 23
13. Annexures.................................................................................................... 25
1. Exemption from State Pollution Control Act.................................. …25
2. Self-certification allowed under various Acts.................................…25
3. Exemption of IT/ITES establishments in the State from the applicability of Section-7
of the Odisha Shops and Commercial Establishments Act,
1956................................................................. ……………………….25
4. IT declared as Public Utility Services................................................. 26

<!-- page 3 -->

3

1. State of IT Industry in India
Introduction
The Indian IT industry has undergone significant transformation, becoming a
cornerstone of the global technology landscape. With its robust growth trajectory and a
diverse range of services, it stands as a vital player in the economy.
Indian IT sector
NASSCOM estimates that India’s technology industry is estimated to grow 8.4% in
FY23 – from US$226 billion in FY22 to US$245 billion in FY23. As of FY23, India’s
technology industry is estimated to employ over 5.4 million talent pool with net addition of
290,000 hires across the technology industry workforce in FY22. Digital revenue is
estimated to be at US$73-77 billion and accounts for 32-34% share of the total industry
revenue at 16% annual growth.
India’s technology industry exports, at US$194 billion are expected to grow at
11.4% whereas domestic technology sector is expected to reach US$51 billion, growing at
4.9% YoY supported by continued investments by enterprise and the government. India’s
domestic technology adoption is driven by cloud adoption and deals focusing on digital
transformations in existing and niche verticals. Government, with its various innovative
initiatives, act as enabler by building public platforms, digital public infrastructure and other
projects promoting ‘Digital India’.
Fuelled by the escalating demand for digital transformation and technology adoption
across various sectors, the growth of the Indian IT industry is led by the following key
drivers:
 Digital Transformation: Businesses are increasingly investing in digital technologies

to enhance operational efficiency, improve customer experiences, and drive
innovation.
 Cloud

Adoption: The migration to cloud computing is accelerating, with

organizations seeking better scalability and cost efficiency.
 Artificial Intelligence and Automation: The integration of AI, machine learning, and

automation technologies is reshaping service delivery and opening new business
avenues.
 Remote

Work Trends: The COVID-19 pandemic has resulted in a lasting shift

towards remote work, increasing the demand for IT services that facilitate remote
collaboration and security.
 Startup Ecosystem: The growth of startups in sectors like fintech, healthtech, and

edtech is spurring innovation and increasing the demand for IT services.

<!-- page 4 -->

4
 Government

Initiatives: Initiatives such as Digital India and Make in India are

promoting investment in technology infrastructure and supporting the growth of the IT
sector.
Outlook
The Indian IT industry is expected to maintain its growth momentum, driven by
widespread technology adoption across various industries, particularly in healthcare,
education, and finance. Key trends shaping the future include:
 Digitalization:

Digitalization in Odisha offers immense potential to boost

economic growth, improve the quality of life for citizens, and foster a more
inclusive and sustainable development model. With strategic investments in
infrastructure, education, healthcare, and governance, Odisha can fully
harness the power of digital technology to propel itself into the future.
 Cybersecurity:

As digital operations expand, the focus on cybersecurity

solutions will intensify to protect data and infrastructure.
 Skill Development: There is an urgent need for upskilling and reskilling the

workforce to meet the demands of emerging technologies. It is crucial for
empowering the state's youth, improving employability, and driving economic
growth.
 Sustainability: Companies are increasingly prioritizing sustainable practices

and solutions, aligning with global trends toward environmental responsibility.
Focusing on green industries like renewable energy, eco-tourism, and
sustainable fisheries can diversify Odisha's economy while creating long-term,
environmentally friendly employment opportunities.
2. State of IT Industry in Odisha
With a population exceeding 45 million, Odisha has made significant strides in various
sectors, including agriculture, manufacturing, and tourism. In recent years, the state
has emerged as an attractive destination for Information Technology (IT) and
Information Technology Enabled Services (ITES), driven by a strategic focus on
economic diversification and job creation. The Government of Odisha has prioritized the
development of the IT sector, implementing initiatives aimed at fostering innovation and
entrepreneurship to capitalize on the region's potential.
Substantial investments in infrastructure have led to the establishment of technology
parks, such as Infocity and Infovalley in Bhubaneswar, which are equipped with modern

<!-- page 5 -->

5

facilities and amenities to support IT companies. This includes high-speed internet
connectivity, data centers, and co-working spaces. Furthermore, initiatives have been
taken to create a conducive environment for IT investments by offering incentives such as
tax breaks, subsidies, and support for research and development.
Odisha boasts a growing pool of skilled professionals, thanks to several reputable
educational institutions that emphasize technical education and IT training, ensuring a
steady supply of talent to meet the demands of the industry. As a result, the IT ecosystem
in Odisha is flourishing, with an increasing number of national and international companies
establishing operations and a surge in startups specializing in sectors such as fintech,
healthtech, and e-commerce.
The strategic location of Odisha, combined with its developing infrastructure and
favourable business environment, has attracted significant investments from major IT
firms, particularly in areas like e-governance, which aims to digitize public services and
improve citizen engagement, and healthcare technology, where the demand for digital
solutions is rapidly growing. Moreover, the state's commitment to promoting research and
development in emerging technologies, such as artificial intelligence, machine
learning, and blockchain, positions it well to become a hub for tech innovation. Overall,
Odisha is positioning itself as a key player in the Indian IT landscape, poised for
continued growth and innovation, with the potential to become a leading destination for
technology and entrepreneurship in the country.
IT Infrastructure in Odisha
Odisha has made significant strides in developing its IT infrastructure to support the
growing technology sector. Key components include:
 Technology Parks: Technology parks in Odisha, such as Infocity, Infovalley, and

STPI, are vital to the state's growing IT infrastructure. Infocity, located in
Bhubaneswar, offers world-class facilities for IT and IT-enabled services, while
Infovalley provides modern infrastructure for both startups and larger businesses on
the city's outskirts. The 6 STPI sub-centres in Odisha which form part of the national
network, supports the IT sector with technical support, infrastructure, and business
incubation. These parks not only foster innovation and attract investments but also
contribute to skill development and job creation, positioning Odisha as a key player in
India's IT industry.
 Internet Connectivity: The state has enhanced its internet connectivity with robust

broadband services, facilitating high-speed access for businesses and residents.

<!-- page 6 -->

6

Initiatives to expand fiber optic networks are underway, improving access in rural and
semi-urban areas.
 Skill

Development Centers: Several institutions and training centers focus on

enhancing the technical skills of the workforce, ensuring a steady supply of talent for
the IT industry. Programs aimed at upskilling professionals in emerging technologies
are being implemented to meet industry demands.
Telecom Infrastructure in Odisha
The telecom infrastructure in Odisha has seen substantial investment, supporting
both urban and rural connectivity:
 Mobile Network Coverage: Major telecom operators have established extensive

mobile network coverage across the state, ensuring connectivity in remote areas.
The availability of 5G services has improved communication and access to digital
services.
 Fiber Optic Networks: The rollout of fiber optic networks is enhancing broadband

connectivity, providing high-speed internet access to businesses and households.
The state's focus on expanding these networks is crucial for supporting IT and digital
services.
 Government

Initiatives: The government has undertaken initiatives to improve

digital infrastructure, such as the BharatNet project, which aims to connect rural
areas with high- speed internet, thereby facilitating e-governance and digital literacy.
Power Infrastructure in Odisha
A stable power supply is essential for the growth of the IT and telecom sectors.
Odisha has made considerable investments in power infrastructure:
 Generation Capacity: The state has a diverse energy mix, including thermal, hydro,

and renewable energy sources. Major power plants, such as the NTPC Talcher
Super Thermal Power Station, contribute significantly to the state’s electricity
generation.
 Renewable

Energy Initiatives: Odisha is actively promoting renewable energy

sources, particularly wind and solar power, to meet the increasing demand for
electricity while ensuring sustainability.
 Distribution Network: Odisha's power distribution network is managed by GRIDCO

and its privatized subsidiaries (TPCODL, TPNODL, TPWODL, TPSODL). The
privatization of these distribution companies has improved efficiency and service
quality. The network delivers electricity across urban and rural areas, with upgrades
like smart grids and rural electrification.

<!-- page 7 -->

7

Transport Infrastructure in Odisha
Transport infrastructure is vital for facilitating the movement of goods and people,
supporting economic growth in the state:
 Road Network: Odisha has an extensive road network, including national and state

highways, that connects major cities and rural areas. The government is investing in
road development projects to improve connectivity and reduce travel times.
 Rail Connectivity: The state has a well-developed railway network that connects it to

various parts of India. Key railway stations serve as important junctions, facilitating
the movement of goods and passengers. Projects to enhance rail infrastructure and
increase freight capacity are underway.
 Airports: Odisha’s key airports provide essential connectivity across the region. Biju

Patnaik International Airport in Bhubaneswar is the primary airport in the state,
offering domestic and international flights. Madhusmita Airport in Jharsuguda, Veer
Surendra Sai Airport in Sambalpur, and Rourkela Airport serve regional routes, while
Utkela Airstrip in Kalahandi supports the southern part of the state. These airports
support vital passenger and cargo movement with plans for further expansions to
enhance connectivity and airport facilities to boost tourism and business travel.
 Ports: Odisha has a significant coastline along the Bay of Bengal, with major ports

like Paradip and Dhamra facilitating maritime trade. The development of port
infrastructure is crucial for enhancing trade logistics and supporting the state's
economy.
3. IT Initiatives in Governance in Odisha
Odisha has made significant strides in leveraging Information Technology to
enhance governance, improve public service delivery, and promote transparency. Some
notable recent initiatives include:
 Student Academic Management System (SAMS)

Launched in 2009, SAMS is an integrated portal which provides a common platform
for admission into various courses across the State through e-Admission and also several
e- Services to students at institution level through e-Administration.
 OdishaOne

OdishaOne is a comprehensive and transformative effort by the state Government
to better integrate G2C services and improve quality of service delivery with enriched
citizen experience. The portal is a front-end interface for all e-Governance Applications of
various Departments. It is envisaged to integrate more than 200 Government-to-Citizen
(G2C) services in OdishaOne portal.

<!-- page 8 -->

8
 i3MS

Odisha is endowed with about one third of the estimated national mineral
resources. To streamline the mining operations including tracking of end to end mineral
transaction, in 2010 Odisha started implementing a comprehensive Information
Technology based e-Governance initiative by the Department of Steel & Mines. The
system has been designed to automate all processes as per the Central Acts and State
Rules, it also shares data in real time with Ports, Railways, Commercial Tax, Income tax,
Treasury &Surface transport database etc. Also, the system facilitates multiple
departments to play their respective part in updating valuable information that helps in
curbing down any illegality/irregularity.
 SUBHADRA Scheme

“SUBHADRA” is a flagship scheme by the Women and Child Development
Department, Government of Odisha aimed at empowering women through financial
support, enhanced digital literacy, and access to social safety nets. The scheme provides
direct benefits and incentivizes digital transactions, focusing on improving the socioeconomic conditions of women and their families.
 Odisha Statewide Area Network (OSWAN)

OSWAN is a robust digital communication network established to connect various
government offices across the state. This initiative enables seamless communication and
data sharing among government departments, improving the efficiency of governance and
service delivery.
 Sustainable Urban Services in a Jiffy by Odisha Government (SUJOG)

The Housing and Urban Development Department has launched Sustainable Urban
Services in a Jiffy by Odisha Government (SUJOG) with the objective of introducing egovernance service across all the 114 ULBs of the state. The programme incorporates a
State-wide Service Delivery Infrastructure, supported by a chain of Citizen Service Centers
(CSCs) and by utilizing advanced ICT tools.
 Grievance Redressal Mechanism (Janasunani)

The government has implemented a digital grievance redressal system to address
citizen complaints and issues related to public services. Citizens can lodge complaints
online, and the system ensures timely responses and resolutions, thereby enhancing the
overall effectiveness of governance.
 Social Protection Delivery Platform (SPDP)

As a part of building an integrated beneficiary database, SPDP has been
conceptualised as a comprehensive system designed to create a Unified Social Registry

<!-- page 9 -->

9

Information System by integrating data from various government departments into a
single, organized framework. It aims to ensure faster, fairer, and more accurate delivery of
benefits, significantly improving the lives of vulnerable populations. SPDP improves the
efficiency of public service expenditure by eliminating duplication, inclusion, and exclusion
errors, detecting fraud, and standardizing data structures for seamless integration across
schemes.
 Computer Emergency Response Team-Odisha (CERT-O)

Computer Emergency Response Team-Odisha (CERT-Odisha or CERT-O) in line
with CERT India (CERT-IN) will act as the nodal agency to cater to crisis situations in
Cyber Security matters to promote a secured and thriving ecosystem for Odisha.
 Cyber Security Operation Centre (C-SOC)

Cyber Security Operation Centre (C-SOC) has been established in the state for
obtaining strategic information regarding incidents, threats towards Odisha State IT/ICT
infrastructure for creating incident response, crisis management through effective
predictive, preventive, protective, response and recovery actions and support to protect
resilience of State IT/ICT and other critical infrastructures.
 Intellectual Property safeguard

A robust monitoring framework will be established to address issues related to IP
theft and fraudulent companies, fostering a secure and trustworthy environment that
supports Odisha's vision to become a global IT destination.
4. Vision
The policy aligns with Odisha's visions for 2036 and 2047, paving the way for the
state to become a powerhouse in the IT and electronics sectors. This strategic roadmap
aims to drive economic growth while contributing to India's digital future. By emphasizing
sustainable development, technological innovation, and digital inclusion, Odisha’s E&IT
Department is positioning the state to meet evolving global demands and foster a
knowledge-driven economy. With a clear and structured approach, the policy strengthens
the IT ecosystem in a phased manner, encompassing BPM & IT services, consulting, and
Tech/SaaS.
5. Objective
The key objectives of the policy are:
a. Creation of direct and indirect employment opportunities for 1 million people in the
IT/ITeS sector.
b. To act as a catalyst in the development and growth of the IT/ITeS ecosystem in the
state

<!-- page 10 -->

10

c. Create an investor friendly business environment for IT/ITeS companies to establish
and expand their operations in Odisha
d. To encourage large scale investments IT/ITeS sector through provisions for large
projects
e. To enable the creation of high-skilled IT human resource in the state
f. Position Odisha as an R&D hub in the field of IT/ITeS
6. Mission
a. Attracting new investments by creating world class infrastructure and promoting
investor facilitation.
b. Supporting existing investments in the State in this sector.
c. Promoting Tier-II & III cities and towns as IT destinations and aiding in setting up
required infrastructure including IT parks for enabling them to attract IT investments
and thereby enhancing employment opportunities.
d. Launching digital literacy programs and skill development centres to upskill the
workforce in emerging technologies like AI, machine learning, cybersecurity,
robotics, and blockchain, thus adding to a future-ready job-force.
e. Generate employment opportunities through IT investments in the state.
f. Ensuring a digitally connected Odisha for spurring growth in demand for digital
services by promoting creation of requisite digital infrastructure.
g. Promoting the innovation ecosystem in the State along with the promotion of
emerging Technologies such as such as Cyber Security, Data Analytics, Mobile
Tech/5G, IoT, Augmented Reality & Virtual Reality, Cloud computing, Deep
learning, Blockchain, Artificial Intelligence, Machine Learning, etc. R&D activities,
design and development of new products, services, processes and business
models in Industry 4.0 etc.
h. Incentivize adoption of green technologies for energy efficient operations with
effective disposal of e-waste coupled and use of renewable sources of energy in the
State to develop a Greener-Odisha.
i.

Facilitate more women, ST/SC and differently abled persons to participate in the IT
sector by bringing in suitable policy interventions and fiscal incentives.

j.

Facilitate the digital transformation of public services by harnessing advanced
technologies to promote transparency, efficiency, and accessibility. Through robust
e-governance initiatives, empower citizens and enable inclusive governance across
Odisha.

<!-- page 11 -->

11

k. To promote centres of excellence/ skill development centres for creating a highly
skilled talent pool in the latest technology and future skills like AI, machine learning,
cybersecurity, robotics, cloud computing, IoT, data science, and blockchain, etc., to
fulfil the demands of the industries.
xx. Odisha's strong infrastructure, world-class educational institutions, research
centres, and robust IT sector provide a solid foundation for AI integration across key
areas such as healthcare, education, agriculture, disaster management, and
governance. By leveraging AI to drive innovation and efficiency in these domains,
the state is paving the way for a smarter, more resilient, and technologically
advanced future.
7. Investment Facilitation Mechanism
The Government of Odisha has developed an online Single Window portal, GO SWIFT
i.e. Government of Odisha – Single Window for Investor Facilitation and Tracking, to
transform the B2G interface through the entire investment lifecycle. GO SWIFT is a key
business reform undertaken by the state government with the objective to provide all
requisite information/clearances to investors in a hassle-free and paper-less manner. The
portal is a “Onestop Solution” for information on clearances required; land banks available;
application, payment, tracking & approval of G2B services; risk-based synchronized
inspection by regulatory agencies; incentive administration; post land allotment services;
grievance redressal; and dovetailing CSR activities with the developmental goals of the
State. Odisha Incentive Management System (OIMS) will be integrated with Go Swift for
the information related to Units to reduce redundancy.
There shall be a 3-tier Single Window Clearance mechanism for approval of IT/ITeS
projects as enumerated below:
i. Investments up to INR 50 crore - Special Single window Clearance Committee
(SSWCC) under the chairmanship of Secretary, Electronics & IT, Govt. of Odisha.
ii. Investments above INR 50 crore and up to INR 1,000 crore – State Level Single
Window Clearance Authority (SLSWCA) members as constituted under the Odisha
Industries Facilitation Act, (OIFA) 2004, under the chairmanship of Chief Secretary,
Govt. of Odisha.
iii. Investment above INR 1,000 crore - High Level Clearance Authority (HLCA) headed
by the Chief Minister with members as constituted under the Odisha Industries
Facilitation Act, (OIFA) 2004.
Odisha Computer Application Centre (OCAC) will provide secretarial assistance to the
SSWCC. The SLSWCA shall have the power to direct concerned departments or

<!-- page 12 -->

12

authorities to issue required clearances within the specified time limit, subject to
compliance of the provisions of the applicable Acts and rules or orders and instructions in
force.
The SSWCC or SLSWCA shall carry out the following functions:
i. Issue approvals of projects as required under the appropriate rules as and when
necessary.
ii. Issue deemed approvals as provided in OIFA as and when necessary.
iii. Review and monitor the processing of applications cleared earlier and sent to
Competent Authorities
iv. SSWCC shall approve the disbursement of incentives for all projects approved
under the Single Window mechanism. The committee will also oversee the
implementation of policy, monitor project progress, and address stakeholder
grievances.
The above guidelines related to the Investment Facilitation Mechanism have been
drawn from the Industrial Policy Resolution (IPR) 2022 of Odisha.
8. Eligibility for Incentives
The incentives and offerings mentioned in this policy apply to all eligible IT units. These
are in addition to any incentives that they may be entitled to avail from the Government of
India.
Eligible Units are defined as under:
‘Eligible Unit’ means any new unit having a minimum of 10 employees on its payroll or
an existing unit having undergone expansion and having a minimum of 15 employees on
its payroll after expansion or a unit undertaking expansion.
o New Unit:
o A new unit means an IT/ITeS unit that has obtained registration under the

Companies Act/ LLP Act/ Partnership/ Proprietorship and is setting up or
commenced its commercial operations in Odisha during the policy period.
o An existing unit outside Odisha state carrying out new investment in the

IT/ITeS industry at any location in Odisha and commencing commercial
operation during the operative period of the Policy shall be considered as a
new unit.
o An existing unit within Odisha state carrying out new investment in the IT/ITeS

industry in another district of Odisha will be considered a new unit.

<!-- page 13 -->

13
o Existing Unit:

Any IT/ITeS unit which has been registered under the Companies Act/LLP
Act/Partnership/Proprietorship and already running its operations within the state.
o Expansion f Unit:
o Expansion of unit means an existing unit in Odisha undertaking expansion

such that the total headcount of employees on its payroll, increases by 10 per
cent in any last 3 consecutive years from the date of its gazette notification or
by 500 employees, whichever is lower, till the end of IT policy 2025.
o Such unit(s) shall be applicable for one time approval during the Policy period

to avail all incentive covered under the policy.
o For the purpose of expansion, only the employees engaged in payroll of the

unit shall be considered.
o Migrated Units from Odisha IT Policy 2022
o A new IT/ITeS unit, which has been setup during the operative period of

Odisha IT Policy 2022 or approved under Odisha IT Policy 2022, but has not
availed any incentive under Odisha IT Policy 2022 shall be considered as
migrated to the current policy and shall be eligible for incentives under this
policy
o However, if IT/ITeS unit has been setup, but not obtained approval of the

Special Single Window Clearance Committee (SSWCC) or State Level Single
Window Clearance Authority (SLSWCA) or High-Level Clearance Authority
(HLCA), as applicable, the unit shall have to first obtain approval through the
Single Window Mechanism via Go-Swift.
Further details and modalities for availing benefits for new unit, existing unit and
expansion of unit shall be outlined in the Operational Guidelines to provide more clarity.
9. Commencement and Eligibility
The Odisha IT Policy 2025 shall come into force from the date of its gazette
notification. This policy will supersede Odisha IT Policy 2022.
Odisha IT Policy 2025 will remain in force for a period of 5 years from its date of
gazette notification or till it is substituted by another policy. The State Government may at
any time amend any and/or all provision(s) of this policy.
Any IT/ITeS unit that is established and commences commercial operations in
Odisha after the notification of the Odisha IT Policy 2025, as well as IT/ITeS units set up
and operationalized after the IT Policy 2022 but did not avail of any incentives, shall be
eligible for assistance or incentives under this policy.

<!-- page 14 -->

14

Existing units that expanded during this period without availing benefits under the IT
Policy 2022, will also be covered under this policy, subject to meeting the conditions
specified in Clause 8 of the policy. Detailed eligibility criteria and modalities for availing
these benefits will be outlined in the Operational Guidelines.
Units cannot avail incentives under more than one sectoral policy of Government of
Odisha. However,
i. Units which have been approved under IT Policy 2022 will remain eligible to avail
incentives as per IT Policy 2025. Eligible units who have not availed incentives during
the previous policy period may claim incentives in retrospect under this policy.
ii. Odisha registered IT startups which commence commercial operations post
notification of IT Policy 2025 can avail incentives under the policy provided the same
incentives are not availed under Odisha Startup Policy.
iii. Units covered under IT Policy 2022 shall continue to avail the admissible incentives of
the same policy as per eligibility and for the time-period for which those units are
eligible.
iv. If a unit has availed similar incentive under any other scheme of the state government
or the Government of India or any government agency or financial institution, it shall
be eligible for the differential amount of benefit only under this policy.
v. A unit shall only be eligible to apply for incentives within the time limit as prescribed in
the operational guidelines of the IT Policy 2025 for the different category of incentives.
Doubts relating to interpretation of any term and/or dispute relating to the operation
of any provision under this policy will have to be referred to the E&IT Department,
Government of Odisha for clarification/resolution and the decision of the Government in
this regard will be final and binding on all concerned.
Execution of various provisions covering the incentives, concessions etc. will be
subject to the issue of detailed operational guidelines/ statutory notifications, wherever
necessary in respect of each item by the concerned Department.
Eligibility of IT units to avail specific incentives would be spelt out in detail in the
operational guidelines to the Policy, which shall be approved by the Government and
notified separately.
10. Incentives
1. Land
 Rate for allotment of land:
o For IT/ITeS Units, Government land will be allotted at prevailing rates notified

by Government, as applicable for industrial units.

<!-- page 15 -->

15
o For IT Towers, Government land will be allotted / converted at the notified

benchmark rate in BDA/ CDA area. However, for non-BDA and non-CDA area,
the land will be allotted / converted at the IDCO notified rate for social
infrastructure.
o For IT Parks, Government land will be allotted through auction, specifically for

the purpose.
 Allotment of land to IT Units will be based on project assessments.
 Minimum land areas:
o IT Towers shall have minimum built-up area of at least 50,000 sq. ft. and can

be developed on land parcels up to 5 acres.
o IT Parks shall be developed on a land area of more than 5 acres.
 For IT Units and Towers, the Government shall extend 100% exemption of stamp

duty on lease/ sale agreement of land or built-up space allotted by Government/
IDCO/ designated development authorities.
 The eligible units will be entitled to get 100% reimbursement of conversion fee and

registration fee. The same shall also be applicable for the eligible companies for
developing IT Parks/ IT Towers in the State.
 IT units meeting the following criteria shall be considered for allotment of Land:

The unit must have been in continuous commercial operation for a minimum period of
three (3) years preceding the date of application. This criteria shall be relaxed to one (1)
year for IT Units established by Women, SC/ST and specially abled entrepreneurs.
For BDA and CDA area, the minimum area allotted to IT Units shall be 0.5 acre,
provided that the entity can demonstrate employment of minimum 200 employees. IT Units
shall be entitled to additional 0.5 Acre of land on each additional 100 employee
demonstrated.
For non-BDA and non CDA area, the minimum area allotted to IT Units shall be
0.5 acre, provided that the entity can demonstrate employment of minimum 100
employees. IT Units shall be entitled to additional 0.5 Acre of land on each additional 100
employee demonstrated.
 For Centres of Excellence (CoEs), R&D units, and product-based companies where

the resource requirement is lower compared to conventional IT service companies,
land shall be allocated based on the recommendation of OCAC, considering merit
and on a case-to-case basis.

<!-- page 16 -->

16
2. Capital Investment Subsidy

A. IT/ITeS Units
 30% of the Fixed Capital Investment (FCI), excluding cost of land, will be

reimbursed to IT/ITeS units.
 For IT/ITeS Units being established in non-BDA and CDA areas, an additional

10% of the FCI will be reimbursed.
B. AVGC Units
 40% of the Fixed Capital Investment (FCI), excluding cost of land, will be

reimbursed to Animation, Visual Effects, Gaming, and Comics (AVGC) units.
C. Development of Co-Working Space
To augment the availability of Co-working spaces in the State, Government will
incentivize development of Co-working spaces by Developers/ Aggregators. Both built-up
spaces and dedicated buildings/ towers shall be incentivized. The Capital Investment
Subsidy available under this clause is outlined below:
FCI
Category

Eligibility
Criteria

Type

Capital Investment Maximum
Subsidy
Limit

FCI >= INR Developers/ Leased space Reimbursement of
2 Cr
Aggregators
25% of FCI

Up to INR 5 Cr

D. IT Towers
 30% of the Fixed Capital Investment (FCI), excluding cost of land, will be

reimbursed for IT Towers.
 For IT Towers, a minimum of 70% of the built-up area should be allocated to

IT/ITeS units and maximum of 30% of built-up area shall be allowed for
support infrastructure services which will include public utility services,
cafeteria, food zones, restaurants, recreational centres.
 For

IT Towers being established in non-BDA and non- CDA areas, an

additional 10% of the FCI shall be reimbursed.
E. IT Parks
 30% of the Fixed Capital Investment (FCI), excluding cost of land, will be

reimbursed to IT Parks.
3. Specific Incentives for IT Parks
Considering the growing demand of space from IT industry for starting operations
from the State, the State Government will facilitate and encourage private initiatives to

<!-- page 17 -->

17

setup IT parks in strategic locations of Odisha. The following incentives will be provided to
IT Parks over and above other incentives stated in the IT Policy:
a. The Government shall extend 100% exemption of stamp duty on first transaction
and 100% exemption on subsequent transaction on lease / sale agreement of land
or built-up space allotted by Government/ IDCO/ designated development
authorities to eligible IT units or to other agencies for developing of IT Parks.
b. Minimum area to be created for processing and non-processing zone: The
Processing zone which will be dedicated for core IT activities shall be minimum
70% of the super built-up area / space. The balance area can be developed as nonprocessing zone.
c. Of the minimum 70% built-up area dedicated to the Processing zone, 10% shall be
earmarked as furnished space for allocation as Plug and Play incubation/Managed
Office Space and co-working space to start-ups and innovation centres.
d. The processing zone would consist of only IT/ ITES/ESDM/R&D units such as IT
companies, GCCs, Tech Startups, BPOs / KPOs, ESDM Companies etc. The nonprocessing zone can include support facilities, public utility services, Hostels,
Serviced Apartments, Guest houses, Commercial areas, Cafeteria, Food zones,
Educational Institutions, Healthcare Facilities, Restaurants, Recreational Centres,
Sport Centres, Hotels and open spaces. Residential units cannot be created or sold
within the non-processing zone.
4. Rental Subsidy
Sl. Incentive
Eligibility
No. Category
Criteria
1 Co-working Units with
Space /
minimum 10
Incubation employees
Space
2 Lease Rental Units with
minimum 20
employees

Incentive Detail
Reimbursement of 50% of per seat cost per month
for a period of 3 years up to INR 3,000 per
employee
IT units taking up rental space in buildings with a
minimum built-up area of 50,000 sq. ft. shall be
eligible for rental reimbursement of up to INR
2,000 per employee per month for a period of five
years, based on either the actual number of
employees or the number derived from the leased
area, calculated at a minimum of 30 sq. ft. per
employee - whichever is lower.
Units taking up rental spaces Governmentdesignated facilities shall be eligible for
reimbursement of monthly rent at INR 20 per sq.
ft., excluding operations and maintenance costs.
The reimbursement shall be limited to a maximum
of 30 sq. ft. per allotted seat per employee.

<!-- page 18 -->

18

5.

Power Incentive

a) Eligible IT units/ Towers/ Parks shall be provided 100% exemption/
reimbursement from payment of Electricity Duty for 5 years from the date of
commencement of commercial operations in the state.
b) Power Tariff of INR 2.00 per unit shall be reimbursed for power purchased and
consumed from local DISCOMs for 5 years from the date of commencement of
commercial operations in the state. IT units shall be eligible for Power at
Industrial tariff.
c) 100% exemption of cross subsidy surcharge and additional surcharges and
state transmission charges on renewable energy procured from state based
renewable energy plants /GRIDCO for 5 years from the date of procurement of
renewable energy for commercial operations in the state.
6. SGST Reimbursement
Eligible IT units/ Towers/ Parks shall be eligible for reimbursement of 100% of net
SGST paid, overall limited to 200% of the cost of plant and machinery, excluding cost of
land, provided that the SGST reimbursement shall be applicable only to the net tax paid
towards the state component of GST, after full adjustment of available and eligible input
tax credit against the output tax liabilities. The definition of “plant and machinery” shall be
outlined in the operational guideline.
7. Interest Subsidy
 Eligible IT units/Towers/Parks will be entitled to get interest subsidy @5% per annum
on long term loans availed from recognized financial institutions and banks, subject to
a maximum of INR 10 Crores per year for 5 years from the date of commencement of
commercial operation.
 The Government shall encourage women, SC/ST & Disabled entrepreneurs by
providing them additional interest subsidy of 1% per annum over and above the
instant incentive.
8. Recruitment Assistance
 One time recruitment assistance of INR 25,000 per newly recruited employee at
executive positions on company payroll (Outsourcing staff, Facility management staff
etc. shall not be considered for availing recruitment assistance), limited to a total of
INR 50 lakhs per unit for 5 years from the date of commencement of commercial
operations in Odisha.
 This incentive is applicable only to Odisha domicile employees deployed in Odishalocated units.

<!-- page 19 -->

19

9. Skilling and Development
i. Human Capital Upskilling Subsidy
50% reimbursement of training fees for obtaining industry recognized skill
certifications in Emerging technologies limited to INR 50,000 per employee, subject
to an overall ceiling of INR 20 lakhs per unit for 5 years.
ii. Internship Subsidy
 Units availing any assistance under this policy will be encouraged to hire interns
on the basis of the following criteria:
a. Each unit must take annually a minimum of 2 interns or 2.5% of the unit’s total
employee strength, whichever is greater but limited to 100 interns per year.
b. The interns need to be trained for a period of six months for which the
reimbursement would be provided.
c. The reimbursement is for a maximum of 100 interns per unit per year.
 Units can get a reimbursement of 50% of the stipend paid for each intern limited to
INR 7,500 per intern per month
 Eligible units can however get full reimbursement of stipend paid for each intern,
limited to INR 12,000 provided such interns are selected/ sponsored through
SDTE/ OSDA limited to maximum 20 interns per year.
 Incentives shall be extended only to students who are domicile of Odisha or those
who are pursuing graduate-level or higher education from institutions located within
the State of Odisha.
 This mechanism of hiring interns is to be treated independently of the Scheme of
Apprenticeship by Government of India and shall be treated separate to this Policy.
iii. Skill Development Initiative


The Skill Development & Technical Education (SDTE) department shall
come up with necessary incentive provisions for the establishment of highend training institutes imparting training in emerging technologies in demand
by the IT/ITeS industry within the state of Odisha.

10. Marketing Incentive


Reimbursement would be provided as per norms indicated below for
participating in designated state/national/ international exhibitions and
approved trade delegations. These incentives are also available to
recognized Industry Associations. Companies can avail this incentive

<!-- page 20 -->

20

maximum 3 times for 5 years post the commencement of commercial
operations in the State:
 For events held within India - 50% reimbursement of expenses capped at INR 1.5
lakhs per event
 For events held outside India - 50% reimbursement of expenses capped at INR 5
lakhs per event
For Associations/ Industry bodies – Capped at INR 20 Lakhs per event
participation for international events. This can be availed maximum of 3 times by an
Industry Association within the policy period. Odisha-based units to be given
preference to participate in the event.
Companies can claim marketing incentives either directly or from association/
industry bodies.
11. Patent Registration Incentives
100% of actual filing costs on awarded patents - Maximum INR 5 lakhs for domestic
patents and INR 10 lakhs for international patents.
12. Reimbursement of PF/ESI contribution
Eligible units shall be granted 100% reimbursement of the employer’s contribution
towards ESI and EPF for 5 years for skilled, semi-skilled & highly skilled workers who are
domicile of the state. All the procedures related to ESI and EPF applications and
reimbursement shall be done via online mode through EPFO system.
13. Research and Development Incentive
IT/ITeS units, academic institutions, R&D organizations, and reputed technical and
scientific institutions shall be eligible for reimbursement of up to 50% of the investments
made towards research and development (R&D) in the IT/ ITeS Sector, subject to a
maximum of INR 10 crore per unit/ institution. IT/ITeS units must submit a brief note
detailing the technical and commercial justification for R&D activities undertaken in the
project, which shall be subject to approval of the nodal agency.
14. Support for development of a Cable Landing Station
 Capital Investment Subsidy of 25% of the eligible Fixed Capital Investment (FCI),
subject to a maximum limit of INR 20 crores.
 Investment made on civil works for constructing the building of CLS along with
network hardware (excluding expenditure towards cable laying and network cables)
shall be admissible.

<!-- page 21 -->

21

 All other incentives applicable to IT units shall also be extended to the operators of
the neutral cable landing station as well as to all the service providers who will be
utilizing the facility.
 In case if any Service Provider/ Hyper-scaler is interested to invest in submarine
cable system, the Govt. shall provide the viability gap funding. The amount of
funding shall be decided by State government on case-to-case basis.
15. Specific Incentives for Large & Mega IT Investments
 In order to attract Developers of national and international repute and large
and mega IT Investments of more than INR 250 Crores and/ or to create large
employment opportunities of more than 2,000 people, a special package of
incentives and concessions may be extended on a case-to-case basis.
 Such decisions shall be made by High-Level Committee under the
Chairmanship of the Chief Secretary, taking into account the benefits to the
State.
 The Cabinet shall approve such proposals duly recommended by the HighLevel Committee.
 These benefits shall be available to both new units as well as existing large
units undertaking expansion within the State.
16. Incentives for Center of Excellence (CoE)
 To

promote CoEs in engineering colleges, educational institutes, other

recognised organisations and state/central promoted agencies in Odisha:
The CoE shall focus areas on areas like Artificial Intelligence(AI), Cyber
Security, Extended Reality(XR),AR,VR, Automation, Blockchain, Big Data, Cloud
Computing, Internet of Things (IoT), Machine Learning(ML), Clean-tech, Edu-tech,
Agri-tech, Health-tech, Defence-tech, Space-tech and other areas of social or
national importance.
 Stamp

Duty/Registration/Conversion Charges: 100% exemption of Stamp

Duty/registration/conversion charges.
 Capital Investment subsidy: The State Government may invest up to 50% of the

Fixed Capital Investment (FCI) in CoE projects depending on the specifics of the
project or reimburse 50% of FCI, as applicable.
 Other incentives applicable to IT units shall also be extended to CoEs.
 If a new product is successfully developed and accepted, then the state government

can procure the same based on the recommendation of High-Level Committee,
without

going

through

tender

process.

This

assistance

solutions/products developed in Government partnered CoEs.

is

available

to

<!-- page 22 -->

22

17. Innovation/ Acceleration Fund
The State will support companies/ matured Deep-Tech Start-ups in IT & related
sectors and provide assistance through the Startup Policy of the State.
18. Incentives on AI Compute

The state government will provide incentives for startups, enterprises, academia,
and educational institutions that utilize AI Compute, Network, Storage, AI Platforms, and
Cloud Services offered by agencies empanelled under the IndiaAI initiative. These
incentives aim to accelerate the adoption of cutting-edge AI infrastructure, drive digital
transformation, and foster the development of innovative AI-driven solutions across
various sectors within the state. The incentives will be extended to the following
categories:
 End users (except MSME) as per categories under India AI mission utilizing
compute from an India AI Mission-empaneled vendor and availing incentives under
the mission will receive additional 40% reimbursement of the cost incurred for
compute usage from government of Odisha.
 As per the India AI mission, MSMEs utilizing compute services will be eligible for
additional reimbursement of up to 40% of the total cost.
 Under the India AI mission, early-stage startups utilizing compute services will be
eligible for an additional 10% reimbursement of the total compute usage, further
supporting innovation and AI adoption.
 The AI Cell, established under the supervision of the E&IT Department/OCAC, will
be responsible for evaluating and verifying proposals seeking additional state
incentives. This assessment will focus on the technological feasibility, scalability,
and potential economic and social impact of the proposed AI solutions. Incentives
will be granted only to entities that align with the state's AI policy.
11. Public Procurement & Procurement of IT Software & Services by Government
 Odisha Government has made a mandate of spending 1% of Budget by every
department towards IT implementation. E&IT Department will plan and assist other
departments in finding technology-driven solutions related to individual department’s
activities. It will work with other Government departments to identify and recommend
the most appropriate technology, solution for them to improve the efficiency of the
department, increase the output or can contribute to better delivery of citizen
services.

<!-- page 23 -->

23

 To promote the local small IT companies & ecosystem, award of Project cost up to
INR 5 Crore shall be awarded to only SME/ MSME units operating from the State
provided a high-level committee certifies that such solution providers are present in
Odisha.
 Government, while awarding projects of more than INR 5 Crores, would stipulate
mandatory local participation & collaborative arrangement (minimum 25% for
deployment and maintenance components) for implementation with local enterprises
with experience and know- how.
12. Governance Mechanism
 The High-Level committee, constituted under the Chairmanship of the Chief
Secretary, Government of Odisha, to consider a special package of incentives for
mega projects shall also be responsible for condonation of delay of all projects as
well as addressing matters referred to it by the State Single Window Clearance
Committee (SSWCC).
 A “Policy Advocacy & Vision Group (PAVG)” will be established to serve as a think
tank and key advisory body on a wide range of policy-related matters. Comprising
intellectuals, professionals, and practitioners from diverse domains such as
academia, research, and industry, the PAVG will play a pivotal role in facilitating the
effective and timely implementation of the IT Policy. It will also ensure that the
policy's objectives are fully realized. PAVG must include at least two experts from
local industries.
 The Odisha Computer Applications Centre (OCAC) will be the Nodal Agency
responsible for the implementation and monitoring of various activities under this
Policy on behalf of the Electronics & Information Technology Department. The
Investment Promotion and Information Technology Promotion (IP&ITP) Cell at
OCAC will serve as both the Project Implementation Unit (PIU) and the Project
Management Unit (PMU) for the implementation of the Odisha IT Policy and utilize
the IT Promotion Fund allocated by the E&IT department for the purpose of
implementing and supporting IT promotion initiatives. Electronics & Information
Technology Department will create a separate entity for development of the sector,
attract investments, implement the policy, ensure talent development and create
necessary infrastructure for the sector, in the state of Odisha, within the current
financial year.

<!-- page 24 -->

24

 The Electronics & Information Technology Department will periodically review the
implementation of the policy for facilitation and mid-course correction where
required with approval from Government.
 Doubts relating to interpretation of any term and/or dispute relating to the operation
of any provision under this policy shall be referred to the E&IT Department for
clarification / resolution. The decision of Government in this regard shall be final and
binding on all concerned.

<!-- page 25 -->

25

Annexure
1. Exemption from State Pollution Control Act
IT units that are currently exempted from the purview of Acts/ Rules/ Orders/
Notification as administered by Odisha State Pollution Control Board (OSPCB) will
continue to do so. New units would also enjoy such exemption.
However, the units availing the benefits of the policy should also comply with the E-Waste
Management 2022 Rules & its amendments as outlined by OSPCB.
2. Self-certification allowed under various Acts
IT units shall be waived off from the routine inspection by Labour Department and
shall be allowed for electronic filing of all legal returns/ forms etc. Government shall allow
self- certification of the records/ registers maintained by IT companies as far as possible
under the following laws in consonance with the objectives of these Acts, barring
inspections arising out of specific complaints:
 The Factories Act 1948
 Shops & Commercial Establishments Act
 The Payment of Wages Act, 1936
 The Minimum Wages Act 1948
 The Employment Exchanges (Compulsory Notification of Vacancies) Act 1959
 The Contract Labour [Regulation & Abolition] Act, 1970
 The Maternity Benefit Act, 1961
 Payment of Bonus Act, 1965
 Inter State Migrant Workmen [Regulation of Employment and Conditions of
Service] Act, 1979
 The Child Labour (Prohibition & Regulation) Act, 1986
 The Sexual Harassment of women at workplace (Prevention, Prohibition and
Redressal) Act, 2013
 Bonded Labour System (Abolition) Act, 1976
 Workmen’s compensation Act
 Payment of Gratuity Act
 The Orissa Industrial Employment (standing orders) Central Rules, 1946
3. Exemption of IT/ITES establishments in the State from the applicability of
Section 7 of the Odisha Shops and Commercial Establishments Act, 1956
As per Government of Odisha, Labour & ESI Department Notification No. LESILL1-III- 0010-2024 – 906, dated the 1st February, 2024, IT/ITeS establishments in

<!-- page 26 -->

26

the State are exempt from applicability of Section 7 (hours of work) of the said Act,
subject to the following conditions:


The total number of hours of work including overtime shall not exceed
twelve (12) hours in any day.



The total number of overtime hours worked by an employee shall not
exceed one hundred and forty-four (144) during a period of three months.

4. IT declared as Public Utility Services


State Government has declared IT units as Public Utility Services under the
provisions of the Industrial Disputes Act, 1947 to exempt them from the
disruption caused by general strikes and bandhs.



The IT Industries are serving global customers on 24 x 7 x 365 basis.
Government shall facilitate granting of permission to work on a 24 x 7 model
given the nature of work in IT industry.
******

(The Resolution is issued on approval of the State Cabinet in their 25th Meeting on dated
25th August, 2025 as communicated by the Parliamentary Affair Department vide their
Memo No. 6599, dated the 26th August, 2025 ).
The Policy shall be in operation for 5 years or till substituted by another policy from the
date of its Gazette Notification. However, the State Government may at any time amend
any provision of this Policy.

ORDER:
Ordered that the resolution be published in an Extraordinary issue of the Odisha Gazette
and copies thereof be forwarded to all departments of Government, all Heads of
Departments, all Public Sector Undertakings.

By Order of the Governor
VISHAL KUMAR DEV

Principal Secretary to Government

Printed and Published by the Director, Printing, Stationery and Publication, Odisha, Cuttack-10
OGP/SBP Ex.Gaz.3814-183+100
