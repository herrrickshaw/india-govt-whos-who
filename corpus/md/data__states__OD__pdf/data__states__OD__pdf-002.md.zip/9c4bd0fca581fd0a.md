---
doc_id: "9c4bd0fca581fd0a"
source_url: "https://health.odisha.gov.in/sites/default/files/2023-06/Notification%20No.%2014527%20dtd%2019.06.2023_%20Extension%20of%20tenure%20of%20Dr.%20lalatanedu%20Sarangi_%20Director%2C%20AHPGIC%2C%20Cuttack%20w.e.f.%2021.06.2023.PDF"
ministry: "Health and Family Welfare Department, Odisha"
title: "Download(459.01 KB)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ae993ed6d34e31ed"
---

<!-- page 1 -->

GOVERNMENT OF ODISHA
HEALTH & FAMILY WELFARE DEPARTMENT

NOTIFICATION
No. PT1-HFW-MEI-AHRCC-0005-2020-

k-1

/H Dated

1,9

In continuation to this Department Notification No. 6290 dated 18.03.2023, the tenure of
Dr. Lalatendu Sarangi, Director, AHPGIC, Cuttack is extended for a further period of 3 (three)
months w.e.f. 21.06.2023 or till joining of the regular Director at AHPGIC, Cuttack, whichever is
earlier, in exigencies of public service.
By order of the Governor

9 ot I /.3

Commissioner-cum- ecreitary to Government

Memo No.
)96-/H Dated 19 C3L
Copy forwarded to the Special Secretary to Hon'ble Chief Minister, Odisha / PS to Hon'ble
Minister, Health & FW for kind information of Hon'ble Chief Minister and Hon'ble Minister,
respectively.

Additional Secr= tary o Government
Memo No. 1, 5 D-9 /H Dated
t
Copy forwarded to P.S. to Chief Secretary, Odisha/ P.S. to Commissioner-cum-Secretary
to Government, Health & FW Department for kind information of Chief Secretary and
Commissioner-cum-Secretary, respectively.
oer
Additional Secret= to government
Memo No.
/531:) /H Dated
19 -- cDt=
Copy forwarded to the AG(A&E), Odisha, Bhubaneswar/ RDC, Central Division, Cuttack/
Collector & D.M , Cuttack/ Director, Red Cross, Blood Bank/ Deputy Commissioner of Police,
Cuttack/ FA-cum-Special Secretary, Health & FW Department / All Directors, Health & FW
Department / Director, PGIMER and Capital Hospital, Bhubaneswar/ Director, VIMSAR, Burla/
Dean & Principal, all Government Medical Colleges/ Superintendent, all Government Medical
College and Hospitals/ FA-cum-CEO, Composite Health Directorate, Odisha, Bhubaneswar/
Superintendent, SVPPGIP (Sishu Bhawan), Cuttack / Principal, SCB Dental College, Cuttack /
Guard file with 5 spare copies for information and necessary action.
3,0-3
Additional Secretary to
overnment
tck:
Li 5-3 1 /H Dated
Memo No.
/ 9 °A.
Copy forwarded to GA & PG Department/ Finance Department for kind i formation.

tck-C
13
Additional Secreta to G ernment

Memo No.
Vkj -S 32--/H Dated
19 -CD6' ' )1(3)3
Copy forwarded to Dr. Lalatendu Sarangi, Director, AHPGIC, Cuttack for information and
necessary action.
06
Additional Secretary to Ggternment
