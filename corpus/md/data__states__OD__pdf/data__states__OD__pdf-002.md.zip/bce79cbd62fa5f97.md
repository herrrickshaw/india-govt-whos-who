---
doc_id: "bce79cbd62fa5f97"
source_url: "https://finance.odisha.gov.in/sites/default/files/2022-06/Compilation%20of%20Circulars%2C%202021-22.pdf"
ministry: "Finance Department, Odisha"
title: "Download(15.28 MB)"
date: ""
pages: 267
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "03b49dec36f2652a"
---

<!-- page 1 -->

For Official Use Only

GOVERNMENT OF ODISHA

COMPILATION OF IMPORTANT
CIRCULARS AND ORDERS ISSUED BY
FINANCE DEPARTMENT
2012-13

2021-22

FINANCE DEPARTMENT

<!-- page 2 -->

<!-- page 3 -->

TABLE OF CONTENTS
Sl.
No.

Resolution/Notification/Office
Memorandum letter No. & Date

1

2

Subject

Page

3

4

1-19

20-28

Matters relating to Budget

1

FIN-WM-CMS-0001-2021
17597/F., Dt.-05.07.2021

Guidelines for timely spending of budgetary grants
through implementation of Cash Management System
in the selected Departments through Quarterly
Expenditure Allocation (QEA) and Monthly Expenditure
Plan (MEP) in the Financial Year 2021-22.

2

FIN-BUD1-BT-0003-2021
20560 /F., Dt.-04.08.2021

Proposals
for
Supplementary
Statement
Expenditure for the financial year 2021-22.

3

FIN-BUD1-BT-0006-2021
27381/F., Dt.-29/09/2021

Preparation of Revised Estimates for 2021-22 and
Budget Estimates for 2022-23.

29-34

4

FIN-WM-BT-0001-2021
7792/F., Dt.-31.03.2022

Regulation of Expenditure out of the Vote on Account
for the year 2022-23.

35-54

of

Matters relating to Odisha Treasury Code

1

2

3

4

FIN-TRY-MEET-0001-2017(PTII)10987/F., Dt.- 07.04.2021

Submission of request for withdrawal of final GPF/TPF
amount by the retiring/retired State Government
employees and procedure for revalidation of final GPF
/TPF authorities

57-61

FIN-TRY-MISC-0015-2020
11437/F., Dt.- 08.04.2021

Process Re-engineering in transfer of P.L. funds from
one account to another across the treasury and
transfer of funds from P.L. Account to Executing
Agencies under Public Works Division of Works and
Forest Divisions of Forest & Environment Department.

62-65

FIN-TRY-PEN-0001-2021
32321/F., Dt.-22.11.2021

Amendment of pension forms prescribed under Odisha
Aided Educational Institutions Employees Retirement
Benefit (OAEIERB) Rules, 1981 read with Executive
Instruction No-11931/EYS Dated: 21.03.1983 issued
by Education and Youth Services Department

66-93

Extension of the dateline for submission of Annual Life
Fin-Try-Misc-0017-2016 36074/F.,
Certificate for the Year 2021 by the Pensioners /
Dt.-28.12.2021
Family Pensioners in the Treasuries / Banks

94

5

PT1-FIN-TRY-PEN-0002-2014
36289/F., Dt.-29.12.2021

Periodic Identification of pensioners/ family pensioners
for seamless disbursement of Pension.

95-98

6

PT1-FIN-TRY-PEN-0002-2014
36299/F., Dt.-29.12.2021

AMENDMENTS

99-103

7

FIN-TRY-PEN-0001-2021
5726/F., Dt.-09.03.2022

Procedure
for
Online
Submission
of
Pension
Application in case of Retiring/Retired Employees of 104-114
Aided/ULB/Taken over Educational Institutions.

8

PT2-FIN-TRY-MISC-0007-2017
7917/F., Dt.-31.03.2022

Electronic storage and retrieval of Pension Payment
Orders (PPO) in DigiLocker for the pensioners drawing 115-120
their pension from State Government.

Page 1 of 4

<!-- page 4 -->

Sl.
No.

Resolution/Notification/Office
Memorandum letter No. & Date

1

2

1

FIN-CS2-ALW-0017-2019
28337/F., Dt.- 08.10.2021

Sanction of Dearness Allowance @ 11% enhancing the
existing rate from 17% to 28% with effect from
123-124
01.07.2021 in favour of State Government employees
drawing pay in Revised scale of Pay, 2017.

2

FIN-CS3-PEN-0002-2020
28447/F., Dt.- 08.10.2021

Sanction of Dearness Relief (T.I) @ 11% enhancing
the existing rate from 17% to 28% w.e.f. 01.07.2021
125-126
in favour of the State Government pensioners/ family
pensioners.

3

FIN-CS2-ALW-0005-2017
28937/F., Dt.-18.10.2021

Sanction of Dearness Allowance @ 25% enhancing the
existing rate from 164% to 189% with effect from
127-128
01.07.2021 in favour of State Government employees
drawing pay in pre-revised scales of Pay, 2008.

4

FIN-CS2-ALW-0017-2019
37/F., Dt.-03.01.2022

Sanction of Dearness Allowance @ 3% enhancing the
existing rate from 28% to 31% with effect from
129-130
01.07.2021 in favour of State Government employees
drawing pay in Revised scale of Pay, 2017.

5

FIN-CS3-PEN-0002-2020
94/F, Date: 03.01.2022

Sanction of Dearness Relief (T.I) @ 3% enhancing the
existing rate from 28% to 31% in favour of the State
131-132
Government pensioners/ family pensioners with effect
from 01.07.2021.

6

FIN-CS2-ALW-0005-2017
757/F., Dt.-10.01.2022

Sanction of Dearness Allowance @ 7% enhancing the
existing rate from 189% to 196% with effect from
133-134
01.07.2021 in favour of State Government employees
drawing pay in pre-revised scales of Pay, 2008.

Subject

3
Matters relating to Dearness Allowance & T.I.

Page
4

Matters relating to OGFR
1

FIN-COD-MISC-0007-2019
11858 /F., Dt.- 13.04.2021

2

FIN-COD-MISC-0015-2019
13012/F., Dt.- 28.04.2021

3

PT14-FIN-COD-MISC-0007-2019
14602/F., Dt.-20.05.2021

4

FIN-COD-MISC-0007-2019
281/F., Dt.-05.01.2022

5

PT15-FIN-COD-MISC-0007-2019
290/F., Dt.-05.01.2022

Bid Security / Earnest Money Deposit (EMD)

137

Sanction of Grant-in-Aid, Maintenance of accounts
138-140
thereof and submission of Utilization Certificate.
Preference to Local MSEs/Start-ups in Procurement of
Works

141

Bid Security / Earnest Money Deposit (EMD)

142

Performance Security

143

Matters relating to DFPR
1

FIN-COD-RULE-0002-2018
27047/F., Dt.-27.09.2021

Amendment of Delegation of Financial Power Rule,
1978.

147-164

2

FIN-COD-RULE-0002-2018
30824/F., Dt.-06.11.2021

OFFICE ORDER

165

Page 2 of 4

<!-- page 5 -->

Sl.
No.

Resolution/Notification/Office
Memorandum letter No. & Date

1

2

1

FIN-GIS2-MISC-0006-2019
28557/F., Dt.-08.10.2021

RESOLUTION

169-171

2

FIN-GIS2-MISC-0006-2019
32458/F., Dt.-23.11.2021

CHANGE OF HEAD OF ACCOUNT

172

Subject

3
Matters relating to Group Insurance Scheme

Page
4

Matters relating to Service Condition

1

Stepping up of pay of senior employee with junior
FIN-CS1-PAY-0018-2020 15601/F employee in the event of promotion of junior
175-176
Date: 07.06.2021
employee in the same grade in the cadre after availing
MACP under ORSP Rules, 2017.

2

FIN-CS2-ALW-0017-2019
30794/F., Dt.-06.11.2021

Entitlement to Special Leave in respect of persons
engaged through outsourcing by service providing
agencies/contract basis in different Departments.

177

3

FIN-PCC-PAY-0006-2017
30722/F., Date: 06.11.2021

Revision of monthly consolidated remuneration for
contractual including the outsourced personnel.

178

Matters relating to NPS

1

FIN-NPS-SCHEME-0009-2019
12025/F, Date: 15.04.2021

Counting of Past Services for Death-cum-Retirement
Gratuity (DCRG) in respect of Central Government/
Indian Railways/Other State Government employees
covered under National Pension System (NPS) on their
subsequent appointment in State Government.

2

FIN-NPS-SCHEME-0002-2019
13925/F, dated 10.05.2021

Revised procedure for submission of online application
in IFMS for generation of Permanent Retirement
182-184
Account Number (PRAN) in
National Pension
System (NPS).

3

FIN-NPS-SCHEME-0002-2021
14037/F, Date 11.05.2021

Procedure for online submission of NPS contribution in
respect of Government employees who are under
deputation to various organizations or are not drawing 185-191
their salaries through Treasuries - revision of
remittance of NPS contributions.

4

FIN-NPS-SCHEME-0004-2021
15180/F., Dated 02.06.2021

Clarification regarding deduction and credit of arrear
New Pension System (NPS) contribution for the period
prior to a generation of PRAN and commencement of 192-196
regular contribution in the National Securities
Depository Ltd. (NSDL) system - modification thereof.

5

FIN-NPS-SCHEME-0003-2021
No.15727/F., Dated 8.6.2021

NOTIFICATION

197-198

6

FIN-NPS-RULE-0002-2019
No.20094/F Dated 29.07.2021

NOTIFICATION

199

7

FIN-NPS-SCHEME-0001-2019
No.28746/F Dated 11.10.2021

NOTIFICATION

200-201

8

PT3-FIN-NPS-SCHEME-0001-2019
No.28581/F., Date: 11.10.2021

181

Release of 10% towards NPS Contributions out of the
balance arrear due arising from revision of pay under 202-203
ORSP Rules, 2017.

Page 3 of 4

<!-- page 6 -->

Sl.
No.

Resolution/Notification/Office
Memorandum letter No. & Date

1

2

Subject

Page

3

4

9

FIN-NPS-SCHEME-0001-2019
No.29478/F., Dt. 27.10.2021

Drawal and remittance of monthly matching
Government contribution @ 14% and drawal of
differential arising due to enhancement of matching
204-207
Government contribution from 10% to 14% w.e.f.
01.04.2019 in respect of employees covered under
National Pension System(NPS).

10

PT3-FIN-NPS-SCHEME-0001-2019
No.32609/F,
Dt.24.11.2021

Clarification regarding operational procedure to be
adopted for drawal of 10% of the balance arrear due
208-209
arising from revision of pay under ORSP Rules, 2017
towards the NPS Contribution only.
Drawal of 30% of the arrear salary due to revision of

11

PT3-FIN-NPS-SCHEME-0001-2019 No. pay under ORSP Rules, 2017 for the employees

594/F, Dt. 07.01.2022

covered under NPS and deduction of employee's
contribution towards NPS.

210-211

Matters relating to OFS Cadre Restructure
1

1

FIN-OFS2-CADRE-0005-2020
19375/F., Dt.-23.07.2021

FIN-PUIF-FININC-0001-2019
22857 /F., Dt.-19.08.2021

Restructuring of the Cadre of Odisha Finance Service
215-233
(OFS)
Miscellaneous Matters
Selection of Banks for handling business and deposits
of State Public Sector Undertakings (SPSUs) and State
237-240
Level Autonomous Societies (SLASs) for the Year 202122

2

FIN-AA-CAG-0001-2020
23930/F., Dt.-31.08.2021

Time bound compliance on Inspection Reports Draft
Audit Notes, Drafts Audit para, C&AG Para, ATN on
recommendations of Public Accounts Committee & 241-245
COPU (Committee on Public Sector Undertaking),
submission of UCs and AC/DC Bills.

3

FIN-CODE-MISC-0012-2019
24980/F., Dt.- 07.09.2021

Fixation of Monetary limit for Khadi Towels

246

4

FIN-COD-MISC-0007-2021
27486/F., Dt.-30.09.2021

Revision of monetary limit for supply of hot weather
liveries to Group-D Employees of State Government.

247

5

FIN-CS2-ALW-0009-2021
28422/F., Dt.-08.10.2021

Revision of Washing Allowance in favour of all regular
Group-D employees of the State Government.

248

6

FIN-CI-INV-0005-2019
31428/F, Dt. 12.11.2021

Payment of Dividend by Public Sector Undertakings/
249-253
Cooperatives electronically through IFMS.

7

FIN-COD-MISC-0007-2021
33167/F., Dt. 30.11.2021

Revision of monetary limit for supply of cold weather
liveries to Group-D Employees of State Government.

254

8

FIN-COD-MISC-0009-2021
34763/F., Dt.-14.12.2021

Revision of monetary limit for expenditure on light
refreshments
served
in
meetings/
discussion.....regarding

255

9

FIN-BUD1-BT-0003-2018
6998/F., Dt.- 23.03.2022

Ceiling on Honorarium payable to a Government
256-257
Employee.

10

FIN-COD-MISC-0007-2021
7682/F., Dt.-30.03.2022

Revision of monetary limit for supply of cold weather
liveries to State Government Drivers.

258

11

FIN-COD-MISC-0007-2021
7687/F., Dt.-30.03.2022

Revision of monetary limit for supply of cold weather
liveries to State Government Drivers.

259

Page 4 of 4

<!-- page 7 -->

MATTERS RELATING
TO BUDGET

<!-- page 8 -->

<!-- page 9 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
OFFICE MEMORANDUM
No. 17597 /F.,

Date: 05.07.2021

FIN-WM-CMS-0001-2021

Sub:

Guidelines for timely spending of budgetary grants
through implementation of Cash Management System in
the
selected
Departments
through
Quarterly
Expenditure Allocation (QEA) and Monthly Expenditure
Plan (MEP) in the Financial Year 2021-22.
Pursuant to the provisions of sub-section (1-a) of Section 8 of

the Odisha Fiscal Responsibility & Budget Management Act, the State
Government do hereby lay down the following Guidelines for timely
spending of budgetary grants through the Cash Management
System in 2021-22. The system was initially adopted in respect of
the

10

Demand

for

Grants

administrated

by

large

spending

Departments during the financial year 2010-11. Thereafter, it has
been extended to 10 more Departments during 2011-12 to 2017-18.
All these 20 Departments will also continue to remain under the
purview of Cash Management System in 2021-22. The list of these
20 Departments and the Demand for Grants is furnished in
Annexure-I.

2.
The Cash
objectives: Objectives of
the Cash
Management
System

Management

System

has

the

following

i.

Even pacing of expenditure within the financial year.

ii.

Reduce rush of expenditure during the last quarter
especially in the last month of the financial year.

iii.

Front loading of expenditure in the 1st three quarters of
the financial year so that corrective measures can be
taken in the mid-year to achieve the fiscal objectives.

iv.

Curb

the

tendency

of

parking

of

funds

Government Account.
v.

Effective monitoring of the expenditure pattern.

vi.

Improve the quality of expenditure.

vii.

Better Ways & Means Management.

outside

<!-- page 10 -->

Revised
Classification
of State Govt.
expenditure

3.

On removal of Plan-Non-Plan distinction in Budget, the

formats of various budget documents have been revised which now
distinguishes the budgetary allocation in terms of revenue and
capital expenditure and not in terms of Plan and Non-Plan. The
State Government budgetary expenditure has been classified into
following four broad categories in the Annual Budget for the year
2021-22.
A.

Administrative Expenditure:
(i)

Establishment,

Operations

&

Maintenance

(EOM)

Expenditure
(ii)
B.

Debt Servicing Expenditure

Programme Expenditure:
(i)

State Sector Schemes

(ii)

Central Sector Schemes

(iii) Centrally Sponsored Schemes
C.

D.

Disaster Response Funds:
(i)

State Disaster Response Fund

(ii)

National Disaster Response Fund

Transfers from State:
(i)
Union Finance Commission Transfers to Local Bodies
(ii) State Finance Commission Transfers to Local Bodies
(iii) Other Transfers

4.
Online
module for
QEA & MEP

Online module for Quarterly Expenditure Allocation

(QEA) & Monthly Expenditure Plan (MEP) under

Cash

Management System in BETA :
(i)
Hitherto, Quarterly Expenditure Allocation (QEA) for
Programme Expenditure (State Sector Schemes, Central Sector
Schemes, Centrally Sponsored Schemes), Administrative & other
Expenditure in respect of each Demand for Grant for all the four
quarters was being worked out and communicated by Finance
Department along with these guidelines. The concerned
Departments were required to work out Monthly Expenditure Plan
(MEP) on the basis of the Quarterly Expenditure Allocation.

2

<!-- page 11 -->

(ii) However, it has been decided to provide an online
platform to the Departments to update their Quarterly Expenditure
Allocation (QEA) and Monthly Expenditure Plan (MEP) in Budget
Execution Technique Automation (BETA) System for the year
2021-22. This will ensure effective monitoring of monthly and
quarterly expenditure pattern through online system.
(iii) Accordingly, a simple module has been developed in
BETA system where the Quarterly Expenditure Allocation (QEA) for
all the four quarters and indicative Monthly Expenditure Plan (MEP)
for all the months in respect of the Departments have been
prepopulated by Finance Department.
(iv)

The

concerned

Departments

are

required

to

update/change their QEA and MEP in line with the broad principles
indicated in this Office Memorandum and submit the same online in
the system for approval of Finance Department in Ways & Means
Branch. A brief user manual with screen shots in this regard is
enclosed at Annexure-II for reference and guidance of all the
Departments.
(v)
access

The Financial Advisors/AFAs of Departments shall
the

developed

webpage

with

their

user

credentials/log in Ids in BETA system and update/change
the QEA and MEP in line within the broad principles. The
Secretary of the respective departments shall approve the
updated QEA and MEP in BETA module and send the same to
Finance Department for approval.
5.

The broad features of the Cash Management System are

indicated hereafter: (i)

The minimum level of expenditure up to the 3rd

quarter i.e. 60% of the gross provision made in the Budget
Estimate for 2021-22, not only under Administrative & other
Expenditure

and

Programme

Schemes,

Central

Sector

Schemes)

taken

together

Expenditure

Schemes,
but

also

(State

Sector

Centrally

Sponsored

under

Programme

Expenditure alone under the Cash Management System is
non-negotiable. The six (06) number of Departments i.e.
Works, Housing & Urban Development, Water Resources,

3

<!-- page 12 -->

Rural Development, Forest & Environment Departments and
Department of Agriculture & Farmers’ Empowerment, should
endeavor to incur expenditure to the extent of 25%, 15%
and 20% of the Gross provision in the Budget Estimate in the
1st,

2nd

and

3rd

Quarter

respectively,

taking

into

consideration their working season. The other fourteen (14)
Departments should aim at achieving expenditure level of
15%, 15% and 30% of the Gross provision in the Budget
Estimate in the 1st, 2nd and 3rd Quarter respectively. Failure
to reach the prescribed level of expenditure up to the end of
3rd Quarter i.e. 60% of the gross provision made in the
Budget Estimate for 2021-22, not only under Administrative
& other Expenditure and Programme Expenditure (State
Sector

Schemes,

Sponsored

Central

Schemes)

Sector

taken

Schemes,

together

but

Centrally

also

under

Programme Expenditure alone, will result in resumption of
the shortfall by Finance Department.
(ii)

The limit of expenditure indicated in

the online

module for the first three quarters is the minimum; however, the
Administrative Departments are free to enhance the MEP &
QEA of first three quarters for their respective Departments
in accordance with the broad principles indicated in Para 7 and
seek approval of Finance Department in the online module
after making necessary up-dation/changes in the online module
(iii) The limit of expenditure for the fourth quarter (40% of
the

Gross

provision

in

the

Budget

Estimate)

and

monthly

expenditure for the month of March (15% of the Gross provision in
the Budget Estimate) provided in the online module is the
uppermost ceiling which should not to be exceeded in any case.
Quarterly
Expenditure
Allocation
(QEA)

6.

If necessary, the Quarterly Expenditure Allocation for

all the four quarters for all the 20 Demand for Grants may be
modified by the Administrative Departments in accordance
with their work plans/programme implementation schedule
within the minimum limit of expenditure for the 1 st three
Quarters

and

the

broad

principles

indicated

in

these

guidelines and submitted to Finance Department through
online in BETA by 30.07.2021 for approval.

4

<!-- page 13 -->

Features of
the Cash
Management
System &
Enhanced
Delegation

7.

(I)

Monthly Expenditure Plan (MEP) of each Department for

January to March shall be subject to the following limits:(a) MEP for the month of March shall not exceed 15%
of the Budgeted Provision (Budget Estimate).
(b)

MEP for the month of January to March has to be

so fixed that the QEA for the last quarter shall not exceed 40% of
the overall Budgeted Provision (Budget Estimate) and 40%
of the provision under Programme Expenditure (State Sector
Schemes,

Central

Sector

Schemes,

Centrally

Sponsored

Schemes) (Budget Estimate).
(II)

The Administrative Departments are authorized to sanction

expenditure

under

Administrative

&

other

Expenditure,

Programme Expenditure (State Sector Schemes, Central
Sector

Schemes,

Centrally

Sponsored

Schemes)

and

Transfers from State, up to the limit of the QEA including
expenditure for grants and subsidies, subject to the following
stipulations:
(a)

Central Sector Schemes and Centrally Sponsored

Schemes : Normally, expenditure for these schemes is to be made
against availability of Central Assistance only during 2021-22.
Instances have come to notice of Finance Department that the
Administrative Departments are presenting bills in the treasuries for
drawal of fund only on the basis of sanction order issued by the
respective Line Ministry of Government of India without checking
the

position

of

receipt

of

central

assistance

by

the

State

Government. The position of receipt of central assistance is updated
every

day

in

the

Finance

Department

website

(http://finance.odisha.gov.in/important-links/receipt-centralassistnace ). The concerned scheme officer and Financial
Advisor/

Assistant

Financial

Advisor

should

check

the

position of receipt of CA from the website of Finance
Department

before

sanction/release/drawal

of

funds.

However, in case of urgent necessity for release of funds for
continuing schemes, the Administrative Departments can incur
expenditure to the extent of 50% of the provision made in the
Budget Estimate for the year 2021-22 or 50% of the annual

5

<!-- page 14 -->

allocation made by the concerned line Ministry of Government of
India whichever is less, during the first two quarters of the financial
year in respect of continuing Central Sector Schemes and
Centrally

Sponsored

Schemes

pending

receipt

of

Central

Assistance with concurrence of the Financial Advisor/A.F.A of the
Department. Further, in case of continuing schemes, the
Administrative Departments can incur expenditure on the
salary component in anticipation of receipt of Central Assistance
up to 31.12.2021 without concurrence of Finance Department. On
receipt of Central Assistance, it will be first adjusted towards the
advance release made by the State Government.
(b)

In case of EAPs in the pipe line, expenditure should

be incurred only if agreement with the Donor Agency has been
signed and the date of effect of the agreement has been notified.
(c)

The

Administrative

Departments

would

obtain

approval of Project Approval Committee/Empowered Committee for
sanction of the entire provision made in their Demand for Grant for
share capital/loan to PSUs and Co-operatives, in one go, by 30th
June, 2021 and then release the amount with prior approval of
Finance Department subject to recovery of outstanding Government
dues and opening of Escrow Account. Besides, Grant-in-aid and
subsidy

to

PSUs/Co-operatives

shall

be

released

by

the

Administrative Departments subject to adjustment of outstanding
Government dues, opening of Escrow Account and within the limit of
the Quarterly Expenditure Allocation (QEA) and Monthly Expenditure
Plan (MEP).
(d)

In case any Administrative Department intends to

grant any relief to any PSU/Co-operative in recovery of outstanding
Government dues while releasing Share capital/loan or subsidy,
prior concurrence of Finance Department would be necessary.
(e)

Release of funds in respect of schemes/ provisions

reserved for Post Budget Scrutiny would be subject to prior
approval

of

Finance

Department/Planning

Department as the case may be.

6

&

Convergence

<!-- page 15 -->

(f)

If, any provision in the Budget Estimate is surrendered

in one Demand and equivalent additional provision is taken in
another Demand in the Supplementary Statement of Expenditure,
then the budgeted provision will be deemed to have been reduced
to that extent and the MEP & QEA are to be modified accordingly.
(g)

Allotment

for

Works

Expenditure

of

Forest

&

Environment, Rural Development, Water Resources, Housing &
Urban Development, Energy & Works Department against Budget
provision, N.H. Credit and Deposits, based on budgetary allotment
and accounts of the Division/Project, drawn through cheques, would
continue to be routed through Works Expenditure module of the
Treasury Portal and regulated by Finance Department Circular No.
28777(6)/F, dated 24.06.2011. The Controlling Officers are advised
to distribute budgetary allotment in respect of works expenditure to
the Divisions/projects through Works Expenditure module of the
Treasury Portal.
(h)

Separate expenditure sanction would also

be

necessary in case of Works expenditure/projects governed by Public
Works Department Code, in terms of the provisions contained in
Rule- 17 (d) of the Delegation of Financial Powers Rules,1978 as
amended from time to time.
(i)

Guidelines for utilization of provisions made for

different works under Programme Expenditure of Works, Rural
Development, Housing & Urban Development and Water Resources
Department and construction of buildings issued vide Finance
Department O.M No. 15744/F, dated 05.04.2012 should be followed
scrupulously for release of the budgetary allocation for these works.
(III)

The Administrative Departments are to fix the QEA and

MEP of Controlling Officers based on the QEA and MEP for the
Demand for Grant and the Controlling Officers in turn may ask the
DDOs to spend the provision in accordance with their own QEA and
MEP.

7

<!-- page 16 -->

8.

Sanction of expenditure for new schemes or new

services, existing schemes where scope of the scheme is
proposed to be altered substantially and/or cost estimate of
projects/schemes are to be revised :

Recently, revised

guidelines have been issued in Finance Department O.M. No.
9523/F, dated 22.03.2021 for formulation, appraisal and approval
of

new

schemes

or

new

services,

existing

schemes

under

Programme Expenditure and Administrative Expenditure where
scope or cost estimate is proposed to be substantially altered and
schemes continuing without approval. Mere provision in the Budget
does

not

entitle

the

Administrative

Departments

to

incur

expenditure unless the process of systematic appraisal and approval
has

been

completed.

Sanction

of

expenditure

for

these

schemes/services can only be made after completion of the
process of appraisal and approval by competent authority
within the limit prescribed in paragraph-7.
9.

The limits indicated in the QEA and MEP is calculated at

the Demand for Grant level as a whole allowing inter-se
variations between months within a quarter and across the
sectors

i.e.

Administrative

&

other

Expenditure

and

Programme Expenditure (State Sector Schemes, Central
Sector Schemes, Centrally Sponsored Schemes) within the
broad parameters indicated in Para-7 and Para-12. The
Administrative Departments and the Controlling Officers should
distribute allotment under each sector among the DDOs broadly in
accordance with the QEA and MEP for the entire year.
10.

Savings if any, under any QEA would not normally be allowed

to be carried over to the next quarter. The Administrative
Departments requiring modification of MEP, which affects QEA,
should seek approval of Finance Department in the online
module after making necessary up-dation/changes in the online
module. However, they would be free to adjust the spillover of MEP
of one month in the next month within the same quarter if it is
within the limits of QEA. The facility will be provided in the online
module

for

necessary

up-dation/changes

in

QEA

and

MEP

accordingly. The Departments are required to follow the process as

8

<!-- page 17 -->

per the user manual and submit the modified QEA and MEP for
approval of Finance Department.
11. In case Finance Department in Ways & Means Branch do not
approve for modification of MEP and QEA within 15 days in the
online module it will be deemed to have been approved.
12. (i)
The Ways & Means Branch of Finance Department are to
monitor Grant-wise & Controlling Officer-wise Expenditure for each
quarter.
(ii) After receipt of Grant-wise & Controlling Officer-wise
Expenditure for the month of December, Ways & Means Branch of
Finance Department will calculate the progressive expenditure up to
December under each Demand for Grant.
(iii) At the end of 3rd quarter, the following expenditure
targets have to be met by the Departments concerned:
(a) the aggregate expenditure under Administrative
& other Expenditure and Programme Expenditure (State
Sector
Schemes,
Central
Sector
Schemes,
Centrally
Sponsored Schemes) should reach the minimum level of 60% of
the Budget provision; and
(b) expenditure under Programme Expenditure
(State Sector Schemes, Central Sector Schemes, Centrally
Sponsored Schemes) should also reach the minimum level of
60% of the Budget provision.
If any of the above two conditions are not fulfilled by
any Department, then the concerned Department would be
required to surrender the provision equal to the amount of
shortfall in expenditure from the prescribed minimum level.
Illustration : (A) If the expenditure of a Department covered
under the Cash Management System falls short of 60% of overall
Budget provision by Rs.„X‟ but exceeds 60% under Programme
Expenditure (State Sector Schemes, Central Sector Schemes,
Centrally Sponsored Schemes), then Rs.„X‟ is to be surrendered
by that Department.

9

<!-- page 18 -->

(B) If the expenditure of a Department covered under Cash
Management System exceeds 60% of the overall Budget provision
but falls short of 60% of Budget provision under Programme
Expenditure (State Sector Schemes, Central Sector Schemes,
Centrally Sponsored Schemes) by Rs. „Y‟ then the concerned
Department will have to surrender Rs. „Y‟ under Programme
Expenditure (State Sector Schemes, Central Sector Schemes,
Centrally Sponsored Schemes).
(C) If the expenditure of a Department covered under the Cash
Management System falls short of 60% of the overall Budget
provision by Rs.„X‟ and 60% of the Budget provision under
Programme Expenditure (State Sector Schemes, Central
Sector Schemes, Centrally Sponsored Schemes) by Rs.„Y‟ then
the concerned Department will have to surrender Rs.„Y‟ under
Programme Expenditure (State Sector Schemes, Central
Sector Schemes, Centrally Sponsored Schemes) and Rs. ( „X‟ „Y‟) from the overall Budget provision. Where Rs.„X‟ is less than
Rs.„Y‟ then only Rs.„Y‟ is to be surrendered under Programme
Expenditure (State Sector Schemes, Central Sector Schemes,
Centrally Sponsored Schemes).
(iv) The Administrative Departments and the Controlling
Officers need to reconcile the expenditure reported by the
Accountant General (A&E) up to the month of December and
surrender the provision equal to the differential between the
progressive expenditure and 60% of the Budget Provision as
indicated in the Illustration above.
(v) Surrender of the provision should be made through the
Budget interface module of IFMS and the surrender relating to
works expenditure is to be made through Works Expenditure
module of IFMS.
13.
The Monthly Expenditure Plan and Quarterly Expenditure
Allocations are to be made in gross terms.
14.
The Integrated Financial Management System (IFMS)
has been so enabled that it will not admit expenditure in
excess of 40% of Budget Provision during the last quarter
and 15% in the month of March under any Demand for Grant
under the Cash Management System.

10

<!-- page 19 -->

15. Funds should not be drawn from the Treasury/Bank
without immediate requirement for payment. As such no
drawal should be made to make advance payments except in terms
of valid agreements in order to meet the monthly/quarterly
expenditure targets.
16. (i) As stipulated in Subsidiary Rule 242 of Orissa Treasury
Code, Volume - I, money should not be drawn from the Treasury
unless it is required for immediate disbursement. Besides, it is
stipulated in Rule-6 of O.G.F.R, Volume-I that unless otherwise
expressly authorized by any law or rule or order having the force of
law, moneys may not be removed from the Government Account for
investment or deposit elsewhere without the consent of the Finance
Department. Further, Rule-141 (3) of Odisha Budget Manual
provides that no money should be drawn from the Treasury unless
it is required for immediate payment. It is not permissible to draw
money from the Treasury and keep them in Banks without sanction
of Finance Department. Money should not be drawn from the
Treasury simply on the ground that the charges have been
sanctioned by competent authority. Nor is it permissible to draw
money from the Treasury and then place it in deposit in order to
avoid lapse of allotment. The system of electronic disbursement of
Government payments directly to the beneficiary account has been
introduced vide Finance Department O.M. No. 27444/F, dated
26.7.2012 with the objective of direct payment to the beneficiaries
and vendors and to prevent parking of funds in bank accounts by
the DDOs. However, instances have come to the notice of
Government that money drawn by the DDOs is being kept unutilized
for indefinite period. This adversely affects the Ways and Means
position of the State. Drawal and retention of funds results in
deferment/deprivation of the expenditure on priority items which
are linked with developmental activities.
(ii) Instructions have been issued vide Finance Department
letter No.23583/F, dated 10.07.2019 and letter No.32215/F, dated
21.11.2014 that money should not be drawn from the Treasury by
the DDOs unless it is required for immediate disbursement. Unauthorized parking of Government money in Bank Account in
contravention of financial rules and instructions issued by Finance
Department is strictly prohibited. It has been stipulated in the

11

<!-- page 20 -->

above-mentioned circulars of Finance Department that if any
such instance of un-authorized parking of money is noticed,
the concerned DDO shall be liable for disciplinary action
under Rule –15 of the OCS (CC&A) Rules, 1962. As per
instructions issued vide Finance Department Circular No. 32215/F.,
dated 21.11.2014, the Heads of Department and Collectors shall
cause enquiry into the matter of unauthorized parking of
Government money in bank accounts after obtaining information
from
the
Treasury
Officers/
Drawing
and
Disbursing
Officers/Autonomous Agencies of the Districts. In case, instances of
irregularity are found, the matter should be reported to respective
Heads of the Department/ Administrative Department. They
should take disciplinary action against the concerned
sanctioning authority as well as the DDO, committing such
irregularity, under intimation to Finance Department and
ensure that funds are drawn and transferred to
implementing agencies only for actual expenditure and not
for parking in Bank Account. The sanctioning authority and
the Drawing & Disbursing Officers shall strictly follow these
instructions.
17.
Sanction of funds out of Budgetary Provision would be
regulated in terms of the provisions of the preceding paragraphs.
18. The gross provision in the respective Demand for Grant and
minimum indicative limit of quarterly expenditure allocation for all
the four quarters of 2021-22 is provided in the online module for
guidance. The Administrative Departments are free to enhance the
MEP & QEA of first three quarters for their respective Departments
in accordance with the instructions contained in the preceding
paragraphs and furnish the same to Finance Department in the
online module by 30.07.2021.
The Administrative Departments concerned should issue
suitable instructions to the Controlling Officers to implement the
Cash Management System and help improve the public
expenditure management.
By order of Governor
Sd/Principal Secretary to Government

12

<!-- page 21 -->

ANNEXURE–I

Sl.
No.

Demand
No.

Name of the Department

1

07

Works

2

09

Food Supplies and Consumer Welfare

3

10

School & Mass Education

4

11

ST & SC Development

5

12

Health & Family Welfare

6

13

Housing & Urban Development

7

17

Panchayati Raj & Drinking Water

8

19

Industries

9

20

Water Resources

10

22

Forest & Environment

11

23

Agriculture & Farmers‟ Empowerment

12

28

Rural Development

13

30

Energy

14

31

Handlooms, Textiles & Handicrafts

15

33

Fisheries & Animal Resources Development

16

36

Women & Child Development and Mission Shakti

17

38

Higher Education

18

39

Skill Development & Technical Education

19

40

20

41

Micro, Small and Medium Enterprises
Department of Social Security & Empowerment
of Persons with Disabilities

13

<!-- page 22 -->

ANNEXURE - II

User Manual

Online module for updation of Quarterly Expenditure Allocation
(QEA) & Monthly Expenditure Plan (MEP) under Cash Management
System in BETA

14

<!-- page 23 -->

1.
The updation of Quarterly Expenditure Allocation (QEA) and Monthly
Expenditure Plan (MEP) in Budget Execution Technique Automation
(BETA) System for the year 2021-22 is to be initiated by concerned
FA/AFA of the Administrative Department on the BETA System. Open web
browser and open the URL: http://onlinebudget.gov.in . This can be
accessed by concerned FAs with their user credentials. User id and
password is case sensitive.

2.
After the successful login the following screen is displayed. Click on
“View & Update QEA & MEP indicated by FD” under the menu “Cash
Management” as shown in the shown in the screenshot below.

15

<!-- page 24 -->

3.
After clicking on “View & Update QEA & MEP indicated by FD” under
the Cash Management menu the following page will appear.
The
“Quarterly Expenditure Allocation (QEA”) for the Financial Year 20212022” worked out by Finance Department will be prepopulated. The
concerned Departments are required to update/change their QEA, if any,
in line with the broad principles indicated in the Office Memorandum.
After necessary updation/ changes are given effect, click on “SAVE”. If it
is felt that the QEA and MEP indicated by Finance Department do not
require any updation/change, the Department may directly click on
“SAVE” button.

4.
After changes are incorporated and the “SAVE” button is clicked as
illustrated in the last step, the sheet under “Monthly Expenditure Plan
(MEP) for the Financial Year 2021-2022” will be auto-populated based on
the updated QEA. However, necessary changes in MEP may be made in
accordance with the broad principles indicated in this Office
Memorandum. After changes are given effect, click on “SAVE” button.
Finally, send the updated QEA and MEP for approval of concerned
Department Secretary by clicking on “Send Proposal To Secretary For
Approval” button.

16

<!-- page 25 -->

5.
Then concerned Department Secretary may give approval to the
submitted QEA and MEP proposal and submit the same to Finance
Department by clicking on the “Send Proposal To FD For Approval”

6.
Subsequently, to modify/revise QEA and MEP click on
“Revise/Modify QEA/MEP” under the Cash Management menu. The
following screen will appear. A/D can modify/revise QEA and MEP as per
stipulated guidelines of the Cash Management Circular. Then follow the
same procedure as original proposal as illustrated above to obtain
approval for revised/modified proposal from the Finance Department.
Note- Revision/modification of QEA and MEP can only be done after
original QEA and MEP proposals are sent to FD and are also approved by
FD)

17

<!-- page 26 -->

18

<!-- page 27 -->

7.
By clicking on “View QEA & MEP Reports” under the Cash
Management menu, original report, latest revised report (if any) and
transaction history of QEA and MEP proposals of the concerned
Department can be viewed as shown in the screenshot below.

19

<!-- page 28 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No. 20560 /F.,
Date: 04.08.2021
FIN-BUD1-BT-0003-2021

From
Shri Vishal Kumar Dev, IAS,
Principal Secretary to Government
To
All Additional Chief Secretaries/
Principal Secretaries/
Commissioner-Cum-Secretaries/
Secretaries to Government.
Sub: Proposals for Supplementary Statement of Expenditure for
the financial year 2021-22.
Sir/Madam,
I am directed to say that Supplementary Statement of Expenditure
for the financial year 2021-22 is likely to be presented in the Odisha
Legislative Assembly some-time in coming months. Accordingly, proposals
for inclusion in the Supplementary Statement of Expenditure are required
to be submitted to Planning & Convergence Department and Finance
Department strictly in accordance with the guidelines indicated below.
2.
Government’s current-year priorities : State is fighting the
pandemic with the approach of saving lives and providing livelihoods are
the priorities during the pandemic period. The Odisha Budget, 2021-22
was presented in the Assembly on 22nd February, 2021 prior to onset of
the second wave of pandemic. The focus of the Budget was on
enhancement of capital expenditure, strengthening the health care –
through up-gradation of existing facilities and building new state-of-art
medical infrastructure, creating industrial and skill development hubs,
boosting tourism and transforming rural and urban Odisha, so as to put
the economy on the right track.
3.
Economic and Fiscal outlook : The State is successfully fighting
with the 2nd wave of COVID and possibility of a 3rd wave cannot also be
ruled out. Under these circumstances, the recovery of the national and
subnational economies is likely to be gradual. Hence, the State may have
to downgrade the growth expectation to 9% in 2020-22 compared to

20

<!-- page 29 -->

original estimate of 11.5% projected at the time of formulation of Annual
Budget, 2021-22 primarily because of lower level of economic activities
due to COVID induced lockdown. However, own revenue during first
quarter of the year 2021-22 has shown substantial increase of about
117% mainly because of lower base and substantially higher collection
of Mining revenue during the current year. Compared to April-June, 2020,
the growth revenue from all the sources has registered a growth of 24%.
The total expenditure (other than debt servicing) during the first quarter
of FY 2021-22 is 17.33% of the Budget Estimate 2021-22 compared to
14.35% previous year. Though the expenditure has shown visible
progress during the month of June, 2021, further effort is required to
increase the pace of expenditure particularly Capital Expenditure to
enhance the level of economic activity thereby creating employment
opportunity as part of counter-cyclical fiscal policy measures. At the same
time, there is need to ensure that the current lockdown imposed for
containing COVID cases does not substantially affect the revenue
collection.
4.
Exercise for re-prioritization of the Budget : While formulating
the Annual Budget, 2021-22, the limit of fiscal deficit of 3.5% of GSDP
was fully employed for financing the Budget. Though there is fiscal space
to avail more borrowing during the year 2021-22, the slow recovery of
GSDP along with the anticipated 3rd wave of pandemic will destabilize the
debt sustainability achieved by the State by prudent financial
management practices over the years. However, Covid-19 management
related expenditures, expenditure relating to livelihood and completion of
the ongoing CAPEX projects are to be assessed by the Departments in a
holistic manner, so that economic activities in the State will rebound to
the level prior to onset of the pandemic. Hence, Supplementary
Statement of Expenditure, 2021-22 is proposed to be an exercise
for re-prioritization of the Budget in which the Administrative
Departments would be allowed to augment the provision in one unit only
by locating equivalent savings in some other unit of expenditure.
However, high priority Capital projects, COVID related packages &
other announcements made by Government from time-to-time and
proposal for enhancing livelihood activities shall be fully funded.
5.
Supplementary proposals based on actual need and spending
capacity : It is observed very often that Supplementary Provisions, more
so Programme Expenditure, are being made without due care and
caution, which result in substantial surrender of funds at the end of
the FY, with instances of total surrender of funds being more than
the supplementary provisions in some previous years. Such large-

21

<!-- page 30 -->

scale surrender of Supplementary provision is being adversely
commented upon by the C&AG year after year. Therefore, Supplementary
proposals should not be prepared in a routine manner; rather should
receive personal attention of the concerned estimating and controlling
officer, so that the proposals are based on actual need and should
commensurate with the actual spending capacity.
6.

Preparation of supplementary proposals during FY 2021-22
Keeping in view the above stipulations, Supplementary Schedules
under Administrative Expenditure, Programme Expenditure, Disaster
Response Funds and Transfers from State need to be furnished in the
following manner: 6.1

Expenditure related to COVID management
The State Government has taken several pro-active steps for
effective COVID management. Various initiatives have been taken in
health sector, social security transfers, special package for farmers as well
as generating livelihood and employment opportunities. Several
announcements including incentives for various COVID affected sections
of the society have also been made. All these initiatives and
announcements would be fully funded.
6.2 Recoupment of Advance from Odisha Contingency Fund
(OCF)
Advance from Odisha Contingency Fund (OCF) sanctioned from time
to time are to be recouped in Supplementary Statement of Expenditure.
In absence of recoupment, it would not be possible to sanction further
advance to meet any urgent requirement. Hence, proposals are to be
submitted for recoupment of any outstanding advance from Odisha
Contingency Fund (OCF) in the Supplementary Statement of Expenditure,
2021-22. The recoupment orders particularly should be issued by
the concerned Administrative Departments based on the actual
expenditures incurred in implementation of emergent initiatives
and not against the total fund sanctioned as advance out of the
corpus of OCF. While submitting schedules for recoupment, the Letter
No. and the date of the sanction of OCF advance and details of head of
account should be clearly indicated.
6.3

Provision for Pay and D.A.

Sufficient provision has already been made for Pay and DA in 202122 (BE). Besides additional provision under the unit salary shall only be
allowed, if the provision becomes inadequate due to filling up of posts or
otherwise. Wherever required, it should be met by locating savings from
the existing provision for re-allocation.

22

<!-- page 31 -->

6.4 Provision of outstanding House Rent, Electricity Dues, Water
Charges and Municipal Dues
If the Budget provision in respect of House Rent, Electricity Dues,
Water Charges and Municipal Dues falls short of the requirement,
proposal should be submitted for provision for the differential amount.
6.5 Regularization of Advance Expenditure incurred by way of
Authorization
In some cases, Engineering Departments have been authorized
(under para 3.7.1(b) of the OPWD Code Vol.-I) to go ahead with the
works and to incur expenditure in absence of Budget provision.
Regularization of such expenditure should be processed indicating
savings/ specific source of funding, if any, for Supplementary provision
both under Administrative Expenditure and Programme Expenditure, as
the case may be.
6.6

Decretal Dues and Land Acquisition Charges

(a) Amounts required for compliance of Court decrees in respect of
Land Acquisition Cases, which have no scope for appeal should be
proposed for inclusion in the Supplementary Budget under the “Charged”
section. All proposals for decretal dues should be furnished with sufficient
justification with firm decision of Government to implement the orders of
the Hon‟ble Court without going for further appeal or revision.
(b) Normal Land Acquisition charges wherever necessary for projects/
schemes should be proposed under the “Voted” section under the Detailed
Heads meant for the project/ scheme.
6.7

Technical Supplementary

Requirement of fund to meet the additionalities in needy
sectors by locating savings or for accounting adjustment without
any additional cash outgo, if any, should be proposed. For
example, transfer of provision from Revenue Account to Capital
Account or from Voted to Charged or vice-versa. Accounting
adjustment in respect of receipt of External Assistance under direct
payment procedure for Externally Aided Projects should also be done in
the Supplementary Statement of Expenditure. The EAP Branch of Finance
Department will ask the Administrative Departments to submit the
proposals to P&C Department.

23

<!-- page 32 -->

6.8 Additional requirement under State Sector Schemes funded
by State Government
If any new scheme is required for provision of emergent public
service, execution of infrastructure projects, generation of livelihood
opportunities, etc., the same can be taken up only after appraisal by
EFC/SFC following the due procedure as laid in Finance Department
Circular No.9523/F dated 22.03.2021 and with specific concurrence of
Finance Department for any expenditure under such scheme. For such
exigency, the Departments are required to propose for reallocation of
provision within the existing ceiling within the similar or same resource
head and Demand. Proposals for additional provision in one unit should be
matched by equivalent savings within the similar or same resource head
and Demand.
6.9

Centrally Sponsored Schemes (CSS)

(i)
Government of India, in the meanwhile, have revised the procedure
for release of funds under the Centrally Sponsored Schemes (CSS) vide
Office Memorandum No.F. No1 (13) PFMS/FCD/2020 dated 23.03.2021.
The State Government is now required to maintain separate Budget lines
for Central and State Share under each CSS in the Detailed Demand for
Grants (DDG), and make necessary provision of the State Share in the
State's Budget. While releasing funds to Singe Nodal Account (SNA), the
Integrated Financial Management System (IFMS) should provide these
Budget heads which would, then, be captured in PFMS through treasury
integration.
(ii) Further, the above revised procedure provides that, in the
beginning of a financial year, the Line Ministries/ Departments will release
not more than 25% of the amount earmarked for a State under a CSS.
Additional central share (not more than 25% at a time) will only be
released upon transfer of the stipulated State Share to the SNA and
utilization of at least 75% of the funds released earlier (both Central and
State Share) and compliance of the conditions laid down during the
previous sanction.
(iii) In order to comply to the new guidelines for ensuring smooth flow
of central assistance to the State, two separate line items xxxxx-Central
Share of CSS and xxxxx-State Share of CSS have been created. The
Centrally Sponsored Schemes where no additional provision is required,
Administrative Departments shall propose for token provisions in the
above two units. However, where there is need for additional provision,
proposal may be submitted in above two units proportionate to the
sharing pattern.

24

<!-- page 33 -->

6.10 Limitation in cases where expenditure till 31st July, 2021
under a unit is within 25% of Budget provision
Proposals involving additional requirement under units, where
expenditure till 31st July, 2021 is less than 25% of Budget provision, shall
not be considered for inclusion under the Supplementary Statement of
Expenditure for the year 2021-22.
7.
Improper Assessment of the requirement and accountability
under the FRBM Act : All Administrative Departments should make
realistic assessment of requirement for the Supplementary Statement of
Expenditure, so that scarce resources can be utilized effectively,
efficiently and in a prudent manner. Sound fiscal management is,
therefore, of vital importance to Government. Further, the FRBM Act
envisages that Budget provision should be made on realistic basis. Hence,
it is made clear that any deviation in this regard would attract personal
liability under the provision of the FRBM Act.
8.

Submission of Budget Proposal and Time Schedule

(i)
The Administrative Departments are requested to formulate the
Supplementary proposals expeditiously in accordance with the guidelines
indicated above and submit their proposals online to Finance Department
following the procedure detailed at Annexure-I as per the time schedule
given below:
a.

In case of Administrative Expenditure, the proposals should be
submitted online to Finance Department latest by the 25th
August, 2021.

b.

The Programme Expenditure proposals should be submitted to
Planning and Convergence Department also by 25th August,
2021. The Planning and Convergence Department shall
communicate
ceiling
to
Administrative
Departments
thereafter. The Administrative Departments shall make
scheme-wise distribution of the ceiling and submit it to
Planning and Convergence Department subsequently.

c.

The Programme Expenditure proposals after concurrence of
Planning & Convergence Department should then be
submitted to Finance Department.

(ii) The system will not allow processing of Budget proposals after the
due date as mentioned above. Hence, due care should be taken to stick to
the stipulated deadlines.

25

<!-- page 34 -->

(iii) Submission of papers or conduct of meeting in physical form shall
be avoided. Any document to be submitted in support of any proposal is
to be uploaded in BETA or to be sent to the concerned Branch Officer
electronically by e-mail/ WhatsApp. Similarly, any consultation, if required
for finalization of Budget proposal, is to be done in virtual mode following
all COVID-19 guidelines.
The Administrative Departments are, therefore, requested to
instruct all the Controlling Officers under them to adhere to the guidelines
and timelines mentioned in the foregoing paragraphs scrupulously. This
circular is being hosted in the website of Finance Department
(https://finance.odisha.gov.in/ ) for information of all concerned.
Yours faithfully,
Sd/(V.K. Dev)
Principal Secretary to Government

26

<!-- page 35 -->

ANNEXURE-I
PROCESS FOR SUBMISSION OF BUDGET PROPOSAL
(i)
The proposal for Administrative Expenditure, Disaster Response
Funds and Transfers from State shall be submitted by the Controlling
Officer(s) to the Administrative Department using IFMS platform.
The consolidated proposal of all Controlling Officers of an Administrative
Department will be transferred from IFMS to the “Online Budget
Compilation System - BETA” seamlessly through web service. The
Administrative Departments after due scrutiny of the consolidated
proposal will submit the same to Finance Department using Online
Budget Compilation System (URL http://onlinebudget.gov.in/BETA/ ) in
Secretariat LAN.
(ii)
Similarly,
Programme
Expenditure
proposals
for
the
Supplementary Statement of Expenditure, 2021-22 shall also be initiated
in the Budget preparation module of IFMS. The Controlling Officers are
required to submit the proposal to the Administrative Department using
IFMS platform. The Controlling Officer shall enter their Programme
Expenditure proposals using the chart of account. The existing charts of
account/ schemes are linked to the respective heads of development/
resource head. In case of entering new schemes/ chart of account, the
Controlling Officers are required to link it to the appropriate heads of
development/ resource head by selecting from the list. The proposals
submitted by the Controlling Officers are to be scrutinized by the
concerned Administrative Department and the consolidated
proposal is to be submitted by the Administrative Department. The
consolidated proposal of all Controlling Officers of an Administrative
Department will be transferred from IFMS to the "Online Budget
Compilation System" (BETA) seamlessly through web service. The heads
of development-wise proposal would be available to the Planning &
Convergence
Department
in
BETA
in
the
URL
http://onlinebudget.gov.in/BETA/. Planning & Convergence Department shall
allocate ceiling online as per heads of development. The Administrative
Departments shall distribute the ceiling online among the development
sector schemes which shall be approved by Planning & Convergence
Department online. The Administrative Departments, then, would be
required to submit the Programme Expenditure proposals in charts of
account to Finance Department using Online Budget Compilation System
in Secretariat LAN using the URL http://onlinebudget.gov.in/BETA/. The

27

<!-- page 36 -->

Programme Expenditure proposals are also required to be
submitted using the online system of IFMS and Budget application
as the default mode.
(iii)
While submitting the proposals for Supplementary Statement
of Expenditure, 2021-22, the Administrative Departments would be
required to identify savings under some units of expenditure to make
provision afresh or by way of augmentation in some other units of
expenditure through re-allocation. In order to ensure availability of
adequate funds equivalent to savings located, the Administrative
Departments would have to indicate availability of funds under a
particular unit in IFMS and block the said savings under that unit until
it is utilized through Supplementary linked surrender/ re-appropriation.
IFMS will block the allocation identified as savings and not allow any
further distribution/ utilization till the process of Supplementary linked
surrender and re-appropriation is over

28

<!-- page 37 -->

No.

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
*******
2 7 3 8 1_ _/F,
Date: 2 9/0 9/2 0 2 1

FIN-BUD1-BT-0006-2021

From
Sri Vishal Kumar Dev, I.A.S.
Principal Secretary to Government
To

All Secretaries to Government/
Heads of Departments

Sub: Preparation of Revised Estimates for 2021-22 and Budget
Estimates for 2022-23.
Sir/Madam,
I am directed to say that the process of formulation of Revised
Estimates for 2021-22 and Budget Estimates for 2022-23 are to be
initiated and completed in time for enabling Finance Department to
present the budget in the Odisha Legislative Assembly at the appropriate
time. In addition to the general instructions contained in Chapter- III of
Odisha Budget Manual, following supplementary instructions are to be
followed while framing the Revised Estimates for the current year
2021-22 and Budget Estimates for the financial year 2022-23.
2.
Government’s strategic priorities for the next five
years : State economy is gradually recovering from the contraction in
the fiscal year ended March, 2021. The severe second wave of COVID-19
pandemic has affected the manufacturing and service sector recovery in
the State. The State has been fighting the pandemic since March, 2020
with objective of saving the life and livelihood of the people. The priorities
of the State Government in the medium-term still remains to achieve
Sustainable Development Goals through faster reduction of poverty,
increasing farmers‟ income by crop diversification and direct benefit
transfer, providing piped drinking water to all, making available quality
affordable health care facilities, enabling quality education & skill
development, providing quality physical infrastructure for improving
economic activities. State Government is in mission mode to empower
women in every sphere of economic activities, modernise the health
facilities at PHC level and building world class tertiary healthcare facility in
the State and providing IT enabled platforms in primary education

29

<!-- page 38 -->

institutes at the village level, so that state could achieve an inclusive
growth.
3.
Economic Outlook: Global economy is projected to grow at 6%
during 2021-22 and 4.9% during 2022-23. IMF has projected India‟s
economy to grow around 9.5% during this fiscal and will have a growth of
8.5% during 2022-23. The recovery in 2021-22 is projected to be slower
than anticipated earlier owing to the impact of second wave and threat of
subsequent waves of the pandemic. In case of Odisha, the economy is
projected to grow by about 9.5% in 2021-22 and it is expected to register
a growth of about 9% during 2022-23.
4.
Resource Outlook: There is optimism in the resource outlook
during the FY-2021-22 both at national and sub-national level owing to
the recovery of the economy from the contraction during 2020-21. State
Government has been consistently monitoring the revenue collection with
a specific focus on arrear revenue. The efforts of the State Government in
the mining sector have substantially enhanced overall collection of the
State‟s own tax and non-tax so far compared to previous year.
Considering the year 2020-21 as an aberration, the growth of the own tax
and non-tax revenue is still modest when compared to the level of
collection in 2019-20 and a time lag of 2 years. The receipt of share tax
and grant-in-aid from Centre till August, 2021 has declined compared to
2020-21. State‟s own revenues are expected to register moderate growth
in FY 2022-23. The GST compensation to bridge the gap between the
protected revenue and actual collection will continue till June, 2022.
Considering all the factors, spending is expected to increase by about 17
percent in FY 2022-23 over the current year‟s revised estimates.
5.
FRBM compliance : The Odisha FRBM Act, 2005 mandates the
State to generate revenue balance and contain the fiscal deficit within 3%
of GSDP. The 15th Finance Commission has already submitted its report
for period 2021-22 to 2025-26. 15th Finance Commission in its report has
worked out the debt path for the states which is as below:
Table-1.1
Indicative Deficit and Debt Path for State Governments by
15th Finance Commission (% of GSDP)
Sl.
No.
1.
2.
3.

Item

2020-21

2021-22

2022-23

2023-24

2024-25

2025-26

Revenue Surplus
Fiscal Deficit
Total Liabilities

0.1
-4.5
33.1

0.5
-4.0
32.6

0.8
-3.5
33.3

1.2
-3.0
33.1

1.7
-3.0
32.8

2.5
-3.0
32.5

30

<!-- page 39 -->

However, the fiscal policy of the State will be guided by the principle
of long-term fiscal sustainability keeping in view the contraction of the
GSDP due to the impact of COVID-19 as well as its susceptibility to
natural calamities. Thus, the State Government would try to adhere to
FRBM requirements for Revised Estimates, 2021-22 and Budget
Estimates, 2022-23, which are given below :
Indicators
Revenue Surplus (+)/ Deficit (-)
(% of GSDP)
Fiscal Deficit (% of GSDP)

2021-22 (BE)
(+)1.03%
(-) 3.49%

IP/ RR Ratio

5.76%

Year-end debt stock
(% of GSDP)

18.99%

6.

2021-22 (RE)
Revenue
Surplus
(-) 3.5%
10%
(upper limit)
25%
(upper limit)

2022-23 (BE)
Revenue
Surplus
(-) 3.5%
10%
(upper limit)
25%
(upper limit)

Preparation of annual budget for FY 2022-23

As part of the PFM reform, the State Government had introduced
a new budget making process for preparation of Annual Budget, 2020-21.
The preparation of budget for FY 2022-23 will be based on the principles
adopted for Annual Budget, 2021-22 which inter-alia include advanced
budget calendar, macro-fiscal forecasting and advanced indication of
Departmental ceilings (both for Administrative and Programme
Expenditure). The Departments will be given 2-3 months‟ time to have
thorough scrutiny and prioritization of the Budget proposals within the
ceiling communicated. All the departments will be communicated with a
multi-year ceiling, so that Departments would have predictability in fund
flow and can make multi-year project planning.
Following budget process will be adopted for FY 2022-23 and
longer time will be allocated for submission of expenditure estimates by
15th December, 2021.
i.

Ceiling will be communicated through BETA system on broad
category of expenditure with flexibility to the Departments to
prioritize the expenditure within the broad ceiling.

ii.

Each Administrative Department will receive their departmental
ceiling disaggregated by Administrative Expenditure (Salaries,
Maintenance and others), Programme Expenditure (State Sector
Schemes, Centrally Sponsored Schemes, and Central Sector
Schemes), Transfers from State (Central Finance Commission,
State Finance Commission and others) and Disaster Response
Funds (SDRMF and NDRMF).

iii.

Previously established norms and practices should be adopted
for preparation of estimates by Departments within the ceilings

31

<!-- page 40 -->

communicated. To this end, the guidelines for determining
Administrative Expenditure are given in tabular form at
Annexure –I.
iv.

Finance Department in consultation with the Planning &
Convergence Department will bring out a “Fiscal Strategy
Paper” indicating the assumptions for revenue and expenditure
projections in the medium term and the outlook for the State
economy and finances.

v.

The Annexures in which various budget related information are
being collected have been rationalized and steps are taken to
collect more information from the database available in various
systems. Other documents like Statement under FRBM Act,
Gender & Child Budget document etc. would be prepared mostly
by using the information from budget database.

7.
Preparing Budget
Programme Expenditure

Estimates,

2022-23

in

respect

of

i.

Sectoral priorities are to be identified in line with State priorities
and SDGs where ever relevant. Allocation under State Sector
Schemes should not be made for schemes not appraised by
EFC/SFC as the case may be.

ii.

Allocation for Centrally Sponsored Schemes and Central Sector
Schemes should be proposed taking into account the likely level
of Central Assistance to be received for the schemes for the
budget year within the overall ceiling communicated for the
sectors.

iii.

Government of India, in the meanwhile, have revised the
procedure for release of funds under the Centrally Sponsored
Schemes (CSS) vide Office Memorandum dated 23.03.2021. The
State Government is now required to maintain separate Budget
lines for Central and State Share under each CSS. In order to
comply to the new guidelines for ensuring smooth flow of central
assistance to the State, two separate line items 78768-Central
Share of CSS and 78769-State Share of CSS have been created.

iv.

Earmarking of allocation for different Schemes under the
Programme Expenditure for Tribal Sub-Component and
Scheduled Caste Sub-Component is to be done as per the norm.

v.

Break-up of allocation under Programme Expenditure for District
Sector and State Sector Schemes is to be made as per the
current practice.

32

<!-- page 41 -->

vi.

8.

Convergence of extra-budgetary resources to budgetary
resources and between budgetary resources is to be made a part
of the budgetary exercise to ensure productive output.
Completion of Annexures.

Some information along-with the budget proposals are collected for
budget scrutiny at Finance and P&C Departments. With automation of
budget preparation process and availability of various data in BETA and
IFMS, it has now become possible to fetch a number of information from
the systems without depending upon the Departments. The three
annexures now prescribed will seek information on position, man-power &
salary requirement, grant-in-aid salary requirement and vehicle position.
Even the manpower and salary related annexures would be made
available to the DDO with pre-populated data from HRMS, which are to be
verified and modifications to be made, if required. This will make it simple
and easy for all budget estimating officers to complete the annexures.
The relevant annexures to be completed are as below:
i.

Annexure-II: Sanctioned Strength,
position and salary requirement

ii.

Annexure-III: Estimate of Grant-in-aid Salary

iii.

Annexure-IV: Position of vehicles and related expenditure

9.

Vacancies

and

Man-in-

Process for Submission of Budget Proposal

(i)
There will be no change in budget making process in the IFMS
system for the DDOs and the Controlling Officers for processing the
budget proposal for the financial year 2022-23.
(ii)
However, ceilings will be communicated in the BETA system at
the broad expenditure category as mentioned in para-6(ii). Departments
are required to map the budget proposals to the broad ceilings.
Proposals beyond the ceiling will not be allowed to be processed
in BETA system.
10.
Conducting pre-budget consultation meetings : All COVID19 protocols and social distancing norms shall be strictly followed in
conduct of pre-budget consultation meetings. Hence, all such meetings to
be conducted by Finance Department as well as Planning & Convergence
Department shall be convened only through virtual platform.

33

<!-- page 42 -->

11.
Budget calendar and timelines for completing the budget
estimates
A lot of information is to be collected and compiled before the
budget is placed before OLA. Hence, budget documents are to be
prepared in a tight time schedule. Therefore, all Departments and
Controlling Officers are required to adhere to the timeline mentioned in
the following table.
Date
15th December, 2021
16th -31st December, 2021

3rd February, 2022

th

5 February, 2022
7th - 10th February, 2022

Activity
Submission of proposals for Budget
Estimates, 2022-23
Pre-budget consultation meetings
Revision of estimates after Pre-budget
consultation and Union Budget, 2022-23
Meeting with Secretaries of major
spending Departments by Chief
Secretary/ DC-cum-ACS
Approval of Annual Budget, 2022-23 by
the Council of Ministers

2nd week of February, 2022

Drafting of budget documents

3rd week of February, 2022

Budget presentation by Minister, Finance

End March, 2022

Presentation of Appropriation bill

Responsibility
Administrative
Departments
Finance
Department
P&C Department
Finance
Department
P&C Department
Finance
Department
P&C Department
Finance
Department
Finance
Department
Finance
Department
Finance
Department

Enclosures: List along with proforma

Yours faithfully,
Sd/Principal Secretary to Government

34

<!-- page 43 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No. 7792 /F,
Date: 31.03.2022
FIN-WM-BT-0001-2021

From

Vishal Kumar Dev, I.A.S.,
Principal Secretary to Government.

To
The Additional Chief Secretaries/
Principal Secretaries/
Commissioner-cum-Secretaries/
Secretaries to Government/
All Heads of Departments.
Sub: Regulation of Expenditure out of the Vote on Account for the
year 2022-23.
Madam/Sir,
I am to say that the Administrative Departments will be
authorized to incur expenditure for four months of the Financial
Year 2022-23 beginning from 1st April, 2022 to 31st July, 2022 as
soon as the Appropriation (Vote on Account) Bill for 2022-23 is
passed by the State Legislature and enacted.

Revised
Classificati
on of State
Govt.
expenditure

2.
On removal of Plan & Non-Plan distinction in Budget, the
formats of various budget documents have been revised which now
distinguishes the budgetary allocation in terms of revenue and
capital expenditure and not in terms of Plan and Non-Plan. The
State Government budgetary expenditure is now classified into the
following four broad categories.
A.

Administrative Expenditure:

(i) Establishment, Operations & Maintenance (EOM) Expenditure
(ii) Debt Servicing Expenditure
B.

Programme Expenditure:
(i) State Sector Schemes
(ii) Central Sector Schemes
(iii) Centrally Sponsored Schemes

35

<!-- page 44 -->

C.

D.

Disaster Response Funds :
(i)

State Disaster Response Fund

(ii)

National Disaster Response Fund

Transfers from State :
(i)

Union Finance Commission Transfers to Local Bodies

(ii) State Finance Commission Transfers to Local Bodies
(iii) Other Transfers
3.
It is necessary to expedite the pace of expenditure during the
st
1 quarter of the financial year as it is the working season before
the onset of monsoon. The Departments should, therefore,
carefully chalk out their work programme from the beginning
of the financial year and make available the provision made
in the Demand for Grants and Appropriations within the
overall limit indicated in the Voted, charged, Revenue and
Capital section of the Vote on Account under column (5) and
(6) of the Vote on Account, 2022-23 to the spending Units by
31st March, 2022 itself. The guiding principles and modalities for
sanction and release of funds in terms of the Vote on Account,
2022-23 are specified below.

Guiding
Principles
for
implementati
on of Budget

4.
Keeping the above mentioned objective in view, while
sanctioning funds, the following guidelines are to be observed by all
the Departments including the 20 Departments covered under the
Cash Management System.
(i)
Expenditure on creation of capital assets and completion of
projects; economy in Administrative Expenditure on establishment,
operations and maintenance should be given top most priority.
(ii)
Funds should be released according to a definite action plan
for achieving the quantifiable physical target fixed for the year. The
Secretaries of Administrative Departments are to review
physical achievement against expenditure by 15th of every
month against monthly/quarterly targets.
(iii) Central
Schemes:

Sector

Schemes

36

and

Centrally

Sponsored

<!-- page 45 -->

(a) Normally, expenditure for these schemes is to be
made against availability of Central Assistance only
during 2022-23. Instances have come to notice of Finance
Department that the Administrative Departments are
presenting bills in the treasuries for drawal of fund only on
the basis of sanction order issued by the respective Line
Ministry of Government of India without checking the
position of receipt of central assistance by the State
Government. The position of receipt of central assistance is
updated every day in the Finance Department website
(http://finance.odisha.gov.in/important-links/receipt-centralassistnace). The concerned scheme officer and Financial
Advisor/ Assistant Financial Advisor should check the
position of receipt of CA from the website of Finance
Department before sanction/release/drawal of funds.
(b) However, in case of urgent necessity for release of
funds for continuing schemes, the Administrative
Departments can incur expenditure to the extent of 50% of
the provision under the respective scheme or 50% of the
annual allocation made by the concerned line Ministry of
Government of India whichever is less, during April to July,
2022 in respect of continuing Central Sector Schemes,
Centrally Sponsored Schemes pending receipt of Central
Assistance with concurrence of the Financial Advisor/A.F.A of
the Departments. Further, in case of continuing
schemes, the Administrative Departments can incur
expenditure on the salary component up to 50% of the
provision, during April to July, 2022 in anticipation of receipt
of Central Assistance up to 31.07.2022 without concurrence
of Finance Department subject to the overall limit
indicated in the Voted, charged, Revenue and Capital
section of the Vote on Account under column (5) and
(6) of the Vote on Account, 2022-23. On receipt of
Central Assistance, it will be first adjusted towards the
advance release made by the State Government.
(c) The
Administrative
Departments
should
furnish
Utilisation Certificate and Statement of Expenditure in time
to the respective Line Ministries of Government of India in
order to obtain the Central Assistance due.
(d) Department of Expenditure, Ministry of Finance,
Government of India have issued revised procedure for

37

<!-- page 46 -->

release of funds under the Centrally Sponsored Schemes
(CSS) and monitoring utilization of the funds released. As per
the revised procedure, separate budget lines for Central and
State share under each Centrally Sponsored Schemes have
been created in the Detailed Demand for Grants (DDG).
Accordingly, to facilitate monitoring of the receipt and
utilization of central assistance, sanction order for Central
share and State share under each Centrally Sponsored
Scheme should be issued separately. The sanction order
should be generated through the sanction order module of
IFMS.
(e) Besides, Department of Expenditure, Ministry of
Finance, Government of India have issued guidelines to be
adopted by the States regarding payment of salaries,
remittance of statutory dues and other deductions of
employees engaged in implementation of certain CSS such
as Samagra Siksha, ICDS etc. vide their letter
F.No.1(13)/PFMS/FCD/2020, dated 8th March, 2022. The
copy of the same has been shared with all the concerned
vide FD letter No.5990/F, dated 11th March, 2022. As per the
said guidelines, the entire central share released by
Government of India along with the corresponding State
share for CSS will be transferred to the Single Nodal Account
(SNA). Further, separate budget lines for the salary portion
of employees‟ engaged in implementation of CSS have been
created in the State budget. The expenditure towards salary
portion under CSS will be initially borne by the State
Government and booked under these heads. The record of
deductions from their salary such as GPF, GIS, ITAX etc. will
be maintained in HRMS. After disbursement of salaries, a
claim for the gross amount will be raised with the SNA and
single Nodal Agency will book the expenditure under salary
component and deposit back the same to the corresponding
Head of Account. The amount received from the SNA, will be
classified as reduction of expenditure (minus debit) setting
off the expenditure initially booked against salary to ensure
that the above expenditure will not entail any additional cash
outgo for the State.
(iv) In case of EAPs in the pipe line, expenditure should be
incurred only if agreement with the Donor Agency has been signed
and the date of effect of the agreement has been notified.

38

<!-- page 47 -->

(v) The Administrative Departments would obtain approval of
Project Approval Committee/Empowered Committee for sanction of
the entire provision made in their Demand for Grant for share
capital/loan/Grant in Aid/Subsidy to PSUs and Co-operatives, in one
go, by 30th June, 2022 and then release the amount with prior
approval of Finance Department subject to recovery of outstanding
Government dues and opening of Escrow Account.
(vi) Grant-in-aid and subsidy to PSUs/Co-operatives shall be
released by the Administrative Departments subject to adjustment
of outstanding Government dues, opening of Escrow Account and
within the limit indicated in Para 13 (I) in case of the
Administrative Departments not covered under the Cash
Management System. However, the Administrative Departments
covered under Cash Management System are authorized to sanction
such expenditure up to the limit of the Quarterly Expenditure
Allocation (QEA) and Monthly Expenditure Plan (MEP).
(vii) In case any Administrative Department intends to grant any
relief to any PSU/Co-operative in recovery of outstanding
Government dues while releasing Share capital/loan or subsidy,
prior concurrence of Finance Department would be necessary.
(viii) Release of funds in respect of schemes/provisions reserved for
Post Budget Scrutiny would be subject to prior approval of Finance
Department/Planning & Convergence Department as the case may
be.
(ix) Statutory dues viz. Sales Tax/VAT, GST, Municipal Tax,
compensation for land acquisition etc. as well as electricity dues,
water charges and Rents, Rates and Taxes, both current and
arrears, should be cleared on the basis of provision made in the
Budget after verification and scrutiny and rebate where-ever
available should be availed. If for any delayed payment
surcharge is levied, it would be the personal responsibility of
the concerned Head of Office/DDO. The State Government has
also introduced an online system named Government Consumer
Revenue Collection System (GCRCS) for electronically receiving
electricity bills, making payment and periodic monitoring of pending
bills vide FD Letter No-7728/F Dt. 08.03.2021. DDOs shall use this
facility for prompt payment of electricity dues. However, the DDOs
are required to record a certificate on the body of the bill to be
presented in Treasuries in respect of electricity dues that "the

39

<!-- page 48 -->

payment relates only to the official use/ consumption and
does not include any dues related to residential connection".
(x) 50% of the annual allocation under M.V., Telephone, T.E. and
Office Expenses should be distributed in such a manner so that it
will meet the requirement for four months of the Financial Year
2022-23 beginning from 1st April, 2022 to 31st July, 2022.
(xi) The
maintenance
expenditure
under
Administrative
Expenditure {Establishment, Operations and Maintenance
(EOM) Expenditure} for Roads & Bridges, Buildings, Urban Water
Supply, Rural Water Supply, Major, Medium & Minor Irrigation,
Flood Control work etc. should be limited to 50% of the Annual
Provision and spent according to the Annual Maintenance Plan
formulated by the concerned Administrative Department in
consultation with Finance Department. However, the allocation for O
& M expenditure in respect of Urban Water Supply, Rural Water
Supply, Major, Medium & Minor Irrigation, Flood Control work etc.
may exceed the limit of 50% of Annual Provision in case of
necessity in consultation with Financial Advisors of the Departments
subject to the overall limit indicated in the Voted, Charged,
Revenue and Capital section of the Vote on Account under
column (5) and (6) of the Vote on Account, 2022-23.
(xii) Creation of posts would require prior concurrence of
Finance Department. Proposals for creation and filling up of posts
should be made only if the posts are essential for delivery of public
services or developmental needs. Proposals for creation of new
posts should be accompanied with detail position of sanctioned
strength, men in position and vacancy of all categories of posts of
the concerned Department. Before processing such proposals, the
Administrative Department should make an assessment of the
redundant posts available in their Department which can be
abolished in lieu of creation of the new posts. In case men are in
position against the redundant posts, the Administrative
Department may also propose for suitable redeployment of such
personnel. Proposals for creation of new posts shall not be
considered by Finance Department unless the same is accompanied
with an assessment of available redundant posts. Besides, creation
of new posts would be considered by Finance Department only if at
least 85% of the sanctioned posts of the relevant category have
been filled up. Permission of the Empowered Committee constituted
in terms of Finance Department Resolution No. 22989/F, dated

40

<!-- page 49 -->

05.08.2014, would be required for filling up of base level vacant
posts meant for direct recruitment. While submitting such
proposals, the Administrative Department are to prepare
Memorandum as stipulated at (III) of the above mentioned Finance
Department Resolution along with information required in
Annexure-I, II and III thereof including assessment of redundant
posts for abolition/re-deployment.
(xiii) Finance Department encourages hiring of private vehicles in
place of Government owned vehicles. In terms of Finance
Department Office Memorandum No. 27037/F, dated 08.10.2015
and OM No.30464/F,06.09.2019, the Administrative Departments
shall be competent to take a decision at their level for hiring of
private vehicle for official use in substitution of existing Government
vehicle after completion of the process of condemnation and auction
of old vehicle and deposit of the sale-proceeds in treasury.
However, hiring sought without condemnation of existing vehicles
and hiring of vehicles for new offices will require prior concurrence
of Finance Department. Purchase of new vehicles should be
avoided. In case it is absolutely necessary to purchase new vehicles,
the concerned Departments are required to strictly follow the
instruction issued vide Finance Department letter No.5421/F, dated
14.02.2020 and prior concurrence of Finance Department will be
required for the purpose. It would normally be considered on
replacement basis only and on the certificate of the Secretary of the
Department regarding availability of a Driver whose residual service
period should be at least equal to the life period of a new vehicle
and deposit of the sale proceeds of the condemned vehicle in
Government Account.
(xiv) Concurrence of Finance Department would not be necessary
for purchase of machinery and equipment if it is within the overall
limit of sanction of the Administrative Departments as well as
overall limit indicated in the Voted, Charged, Revenue and Capital
section of the Vote on Account under column (5) and (6) of the Vote
on Account, 2022-23.
(xv) State Compensatory Afforestation Fund: Provision has
been made towards „State Compensatory Afforestation Fund‟ in
Demand No.22 in the Vote on Account, 2022-23. However,
availability of provision does not automatically entitle the
Administrative Department for drawal of funds. It is contingent upon
availability of balance in the State Fund. In other words,

41

<!-- page 50 -->

expenditure can only be made to the extent of the amount available
in the State Fund. The Financial Adviser/AFA of Forest and
Environment Department shall check availability of balance in the
State Fund while processing proposals for sanction/drawal of funds
out of Vote on Account, 2022-23. Besides, the Forest and
Environment Department are required to furnish copy of monthly
breakup of estimated expenditure from 1st April, 2022 to 31st July,
2022 to Finance Department by 15th April, 2022.
Sanction &
Release of
Funds
from Vote
on Account

5.
Expenditure is to be incurred only on exsisting
establishments and ongoing schemes and programmes. The
Administrative Departments are requested to follow the instructions
mentioned below, while allocating funds and incurring expenditure
in respect of each unit of appropriation out of the provision made in
the Demand for Grants and Appropriations and limit indicated in the
Vote on Account 2022-23. It must be ensured that no
expenditure on a New scheme/programme is incurred until
the Demands for the whole year are passed by the
Legislative Assembly and the related Appropriation Bill is
enacted.
(I) Expenditure under a minor head during 1st April, 2022
to 31st July, 2022 should ordinarily be limited to 50% of the
provision under Administrative Expenditure, Programme
Expenditure (State Sector Schemes, Central Sector Schemes,
Centrally Sponsored Schemes) and Transfers from State
made for the financial year, 2022-23, in the Demand for
Grants and Appropriations. However, in case of Calamity
Relief and Election related expenditure, the Departments can
spend up to the full provision under these Units. In all other
cases, the expenditure can be exceeded in the functional
major/minor heads subject to the overall limit indicated in
the Voted, Charged, Revenue and Capital section of the Vote
on Account under column (5) and (6) of the Vote on Account,
2022-23, with prior concurrence of Financial Advisor/A.F.A
of the Department.
(II) Detail unit of appropriation like Pay, DA, HRA etc. have been
indicated below the minor head. The details of the provision below
the minor head up-to the unit of appropriation has been made
available through the Budget Interface and Works expenditure
module
and
placed
in
the
Treasury
portal
(http://www.odishatreasury.gov.in/www.ifmsodisha.gov.in).

42

<!-- page 51 -->

Accordingly, the Administrative Departments/Controlling Officers
need to assess their requirements under each unit of appropriation
and issue allotment order to concerned DDOs. For assessment of
the requirement under different units of appropriation, the following
procedure shall be adopted.
(a) Allotments
should
be
distributed
to
meet
the
requirement for a period of four month only for each unit
of appropriation.
(b) For salary components, calculation should be made as follows:
i)

Pay – 50%
distributed.

of the provision for 2022-23 should be

ii)

D.A at the prevailing rate should be worked out, on
the requirement under Pay.

iii) H.R.A. - As per the admissible rate for four months.
iv) Un-utilized leave salary of retired Government Servants
and those retiring between 01.04.2022 to 31.07.2022
should also be paid in full.
v)

Depending on urgency, arrear salary (30% & 20% of the
arrear salary arised out of 7th Pay Commission if undrawn
during 2021-22) may be released within 50% of the
annual provision.

(c) For non-salary components unit-wise provision should be
calculated by taking 10% increase over the expenditure made in the
year 2021-22 excluding the provision for non-recurring expenditure
like purchase of vehicles and contingencies etc. The recurring
expenditure under non-salary components is to be considered while
calculating 50% of the unit-wise provision for the year 2022-23 for
distribution.
i)

While calculating 50% of the Budget provision under
Administrative Expenditure, Programme Expenditure
(State Sector Schemes, Central Sector Schemes, Centrally
Sponsored Schemes) and Transfers from State, the
sectoral
allocation
i.e.
provision
made
under
Administrative Expenditure, Programme Expenditure
(State Sector Schemes, Central Sector Schemes, Centrally
Sponsored Schemes) and Transfers from State should be

43

<!-- page 52 -->

calculated separately. Expenditure is to be incurred
only on exsisting establishments and ongoing
schemes and programmes.
ii)

Expenditure
for
the
continuing
Central
Sector
Schemes/Centrally Sponsored Schemes out of the Vote on
Account, 2022-23, only should be considered, subject to
the limit of Vote on Account and receipt of Central
Assistance. The state share is to be released in accordance
with receipt of Central Assistance. However, in case of
urgent
necessity
for
release
of funds,
the
Administrative Departments can incur expenditure to the
extent of 50% of the provision under the respective
scheme or 50% of the annual allocation made by the
concerned line Ministry of Government of India whichever
is less, during April to July, 2022 in respect of continuing
Central Sector Schemes, Centrally Sponsored
Schemes pending receipt of Central Assistance with
concurrence of the Financial Advisor/A.F.A of the
Departments. Further, in case of continuing schemes,
the
Administrative
Departments
can
incur
expenditure on the salary component up to 50% of
the provision, during April to July, 2022 in anticipation of
receipt of Central Assistance up to 31.07.2022 without
concurrence of Finance Department.
Illustration :
In case of a Centrally Sponsored Schemes with financing
pattern of CS:SS - 60:40, if the budget provision is
Rs.100.00 crore, on receipt of CS of Rs.30.00 crore, CS of
Rs.30.00 crore together with SS of Rs.20.00 crore can be
released,subject to the overall limit indicated in the
Voted, Charged, Revenue and Capital section of the
Vote on Account under column (5) and (6) of the
Vote on Account, 2022-23.

iii) Prior concurrence of Finance Department and Planning &
Convergence Department would be necessary for release
of funds in case of items of expenditure reserved for post
budget scrutiny.

44

<!-- page 53 -->

iv) The Administrative Departments including those covered
under the Cash Management System can sanction
expenditure on existing schemes when the scope of the
scheme is proposed to be substantially altered and /or
cost estimate of projects/schemes are to be revised, only
after completion of the process of appraisal and
approval by the competent authority as prescribed
in Finance Department O.M. No.1068/F, dated
10.01.2013 read with Rule-17-A of the Delegation
of Financial Power Rules, 1978 and the Demands
for the whole year are voted by the Legislative
Assembly and the related Appropriation Bill is
enacted.

Priority
areas of
expenditure

Submission
of
Utilisation
Certificate

6.
While releasing funds, priority should be given for
programmes/schemes
where
expenditure
is
reimbursable,
completion of the incomplete projects under the Zero Based
Investment Review and State‟s Own Flagship Programme e.g.- (i)
EAP, RIDF, LTIF and other Resource Tied up schemes under
Programme Expenditure, (ii) Central Sector Schemes and Centrally
Sponsored Schemes, (iii) State Sector Schemes under Programme
Expenditure like ABHADA, BASUDHA, Madhubabu Pension Yojana,
Mission Shakti, MAMATA, Biju Setu Yojana, Parvati Giri Mega Lift,
Biju Swasthya Kalayan Jojana, Mukhyamantri Swasthya Seva
Mission etc. (iv) Disaster Response Funds.
7.
While scrutinizing proposals for sanction of expenditure during
1ts April 2022 to 31st July 2022 of the year 2022-23, the progress
of submission of Utilization Certificate in respect of expenditure
incurred up to the preceding month and expenditure incurred during
2021-22 should be reviewed by the Administrative Departments. It
should be ensured that the implementing agencies utilize the
scheme funds transferred to them. Before releasing money to the
implementing agencies it should be ensured that the implementing
agencies have utilized the funds transferred to them in the previous
years and the same has not been lying unutilized and parked by the
implementing agencies in Bank Account. The Financial
Adviser/AFAs of Administrative Departments and Financial
Advisers and Chief Accounts Officer/Accounts Officers of
Heads of Departments and other offices should strictly

45

<!-- page 54 -->

adhere to the instructions laid down in Finance Department
letter No.23583/F, dated 10.07.2019.
The following certificate shall be recorded in the
Sanction Order for release of fund to implementing agency :
“the amount released to the implementing agency during
2021-22 has been utilized and the amount released prior to
that has been fully utilized and the same is not lying
unutilized & parked in bank account.”
The time limit for submission of Utilization Certificate in
respect of grant in aid provided by State Government and grants
received from Government of India as indicated in Finance
Department O.M. No.21241/F, dated 17.07.2014 is to be
scrupulously adhered to. The Financial Advisers and Assistant
Financial Advisers are required to enforce the discipline while
concurring in the proposal for sanction of grant-in-aid.
Even
pacing of
expenditure

8.
(i) Flow of expenditure should be evenly paced and
commensurate with the revenue receipts. Therefore, it is necessary
to formulate quarterly and monthly expenditure plans from the
beginning of the year to avoid rush of expenditure towards the
year-end. In order to achieve this objective, completion of the
formalities relating to sanction and release of funds in the early part
of the financial year would accelerate the pace of expenditure in the
1st three quarters. The expenditure in the last quarter of the
financial year and in the month of March ought to be within 40%
and 15% respectively of the Annual Budget provision.
(ii) The system of Global Allotment regarding personal
entitlements has been introduced vide Finance Department
letter No. 9755/F dated 18.03.2020 by which the funds in
respect of Budgetary units mentioned therein are to be
allotted to the respective Controlling Officer by the
Administrative Departments and the Drawing and Disbursing
Officers (DDOs) have been allowed to draw funds as per the
requirement from the central allocation available with the
respective Controlling Officers. There would be no need for
distribution of allotment in respect of personal entitlements under
the specified Heads/Units of expenditure below the level of
Controlling Officer. Hence, the Administrative Departments will have
to release the allotment relating to personal entitlements under the

46

<!-- page 55 -->

specified Heads/Units at one go from the beginning of the financial
year subject to the overall limit indicated in the Voted,
Charged, Revenue and Capital section of the Vote on Account
under column (5) and (6) of the Vote on Account, 2022-23.
In this regard, guidelines enshrined in Finance Department letter
No.9755/F dated 18.03.2020 may be scrupulously followed.
(iii) Similarly, the system of Global Allotment has also
been introduced for Festival Advance and interest bearing
advances like House Building Advance and
Advance for
purchase of Motor Car/Motor Cycle. The budgetary allocation in
respect of these advances is provided in Demand No.5–Finance
Department centrally. Henceforth, it will not be required to make
specific allotment of funds to the DDOs in respect of these advances
which can be drawn following the detail procedure enshrined in
Finance Department letter No. 33907/F dated 03.10.2019 and letter
No. 9755/F dated 18.03.2020 subject to the overall limit
indicated in the Voted, Charged, Revenue and Capital section
of the Vote on Account under column (5) and (6) of the Vote
on Account, 2022-23.

Online
distribution
of allotment
to DDOs
through
Treasury
Portal

9.
(i)
Instructions have been issued to all Departments
vide Finance Department Letter No.7563/F, dated 30th
March, 2022 to complete the process of distribution of
allotments to the D.D.Os within the limit of expenditure
mentioned in the Vote on Account, 2022-23, through Odisha
Treasury
Portal
(http://www.odishatreasury.gov.in/
th
www.ifmsodisha.gov.in) from 30
March, 2022 to 31st March,
2022. The detailed DDO-wise Budget Allotments should be
distributed forthwith through Odisha Treasury Portal(http://www.odishatreasury.gov.in/www.ifmsodisha.gov.in)
if
not
already done, in order to enable the Treasuries/Special
Treasuries/Sub Treasuries to check the bills against budgetary
allotment through IFMS. The DDOs need not wait for ink-signed
copy of the allotment. However, the budgetary units of
appropriation which are covered under Global Allotment
System need not be allocated to the DDOs by the respective
controlling Officers.
The detailed provision made in the Demand for Grants
and Appropriations and the limit of expenditure indicated in
the Vote on Account, 2022-23 will be made available in the

47

<!-- page 56 -->

Budget Interface and works expenditure module of IFMS
Portal
(http://www.odishatreasury.gov.in/www.ifmsodisha.gov.in)
enabling Administrative Departments to distribute the
allotments within the limit of expenditure mentioned in the
Vote on Account.
Accordingly, the Treasury Portal should capture the unit-wise
expenditure allowed against the provision made in the Demand for
Grants and Appropriations and the limit of expenditure indicated in
Vote on Account, 2022-23 and account for the expenditure against
these units against the provisions made for the whole year after the
Annual Budget, 2022-23 is passed by the Legislative Assembly and
the related Appropriation Bill is enacted. The Treasuries and SubTreasuries should, therefore, insist on full accounting
classification i.e. detailed description from Major Head to
Unit of appropriation in the Bills presented for drawal.
(iii) Allotment for Works Expenditure of Forest &
Environment, Rural Development, Water Resources, Housing &
Urban Development, Energy & Works Department against Budget
provision, N.H. Credit and Deposits based on budgetary allotment
and accounts of the Division/Project, drawn through cheques, would
continue to be routed through Works Expenditure module of the
Treasury Portal and regulated by Finance Department Circular No.
28777(6)/F, dated 24.06.2011. The Controlling Officers are advised
to distribute budgetary allotment in respect of works expenditure to
the Divisions/projects through Works Expenditure module of the
Treasury Portal.
(iv) Separate expenditure sanction would also be necessary
in case of Works expenditure/projects governed by Public Works
Department Code, in terms of the provisions contained in Rule-17
(d) of the Delegation of Financial Powers Rules,1978 as amended
from time to time.
(v) Guidelines for utilization of provisions made for different
works under Programme Expenditure of Works, Rural
Development, Housing & Urban Development and Water Resources
Department and construction of buildings issued vide Finance
Department O.M No. 15744/F, dated 05.04.2012 should be followed
scrupulously for release of the budgetary allocation for these works.

48

<!-- page 57 -->

10. Sanction of expenditure for new schemes or new
services, existing schemes where scope of the scheme is
proposed to be altered substantially and/or cost estimate of
projects/schemes are to be revised:
It may be noted that every scheme needs to be
appraised in order to ensure optimum utilization of available
resources and appropriate cost benefit in the interest of the
public.
Recently, revised guidelines have been issued in Finance
Department O.M. No. 9523/F, dated 22.03.2021(which shall come
into force w.e.f dt.01.04.2021) for formulation, appraisal and
approval of new schemes or new services, existing schemes under
Programme Expenditure and Administrative Expenditure where
scope or cost estimate is proposed to be substantially altered and
schemes continuing without approval. It is observed that new
schemes having significant financial implication are being
announced by Administrative Departments and scope of existing
schemes are being substantially altered and/or cost estimate of
schemes are being revised without following the procedure of
systematic appraisal and approval. It is impressed upon the
Administrative Departments that prior to launch/announcement of a
new scheme and revision of scope of existing schemes involving
substantial alteration and/or cost estimate of the scheme, the
procedure for systematic appraisal and approval as enshrined in
Finance Department Office Memorandum No.9523/F, dated
22.03.2021 should be scrupulously followed. Mere provision in
the Vote on Account does not entitle the Administrative
Departments to incur expenditure unless the process of
systematic appraisal and approval has been completed.
Sanction of expenditure can only be made after completion
of the process of appraisal and approval by competent
authority within the limit of sanction prescribed in
paragraph-12 in case of the Administrative Departments not
covered under the Cash Management System and up to the
limit of the Quarterly Expenditure Allocation (QEA) and
Monthly
Expenditure
Plan
(MEP)
in
case
of
the
Administrative Departments covered under the Cash
Management System.
11. Budgetary funds will in no case be transferred to Civil
Deposit.

49

<!-- page 58 -->

Cash
Management
System for 20
Departments

12. (i) Cash Management System was introduced in 10 key
spending Departments in 2010-11. Thereafter, it has been extended
to 10 more Departments during 2011-12 to 2017-18. For these 20
Departments, the minimum level of expenditure up to the 3rd
quarter i.e. 60%, not only under Administrative Expenditure,
Programme Expenditure (State Sector Schemes, Central
Sector Schemes, Centrally Sponsored Schemes) and
Transfers from State taken together but also under
Programme Expenditure alone under the Cash Management
System is non-negotiable. Failure to reach the prescribed
level of expenditure will result in resumption of the shortfall
by Finance Department. Separate instructions will be issued
by Finance Department in this regard.
(ii) Enhanced delegation for sanction of funds by the
Administrative Departments covered under the Cash
Management System: The Administrative Departments are
authorized to sanction expenditure under Administrative
Expenditure, Programme Expenditure (State Sector Schemes,
Central Sector Schemes, Centrally Sponsored Schemes) and
Transfers from State up to the limit of Quarterly Expenditure
Allocation (QEA) for the first quarter and Monthly Expenditure Plan
for the month of July, 2022 including expenditure for grants and
subsidies, subject to the procedure and limit of expenditure
indicated in paragraph-5 in respect of sanction and release of funds
from Vote on Account including expenditure for grants and
subsidies, subject to the stipulations prescribed in paragraph 4.

General
limit of
Sanction

13.
(I) General limit of sanction: The Administrative
Departments not covered under the Cash Management System are
authorized to sanction expenditure up to Rs.1500.00 lakh at a time
under Administrative Expenditure & Transfers from State and
Rs.3000.00 lakh under Programme Expenditure (State Sector
Schemes, Central Sector Schemes, Centrally Sponsored
Schemes) subject to the procedure and limit of expenditure
indicated in paragraph-8 in respect of sanction and release of funds
from Vote on Account. Sanction of expenditure exceeding these
limits would require prior concurrence of Finance Department.
(II) Full power for sanction of expenditure in specific cases :
Notwithstanding the limits indicated at Sub-Para(I) above but
subject to the procedure and limit of expenditure indicated in

50

<!-- page 59 -->

paragraph-8 in respect of sanction and release of funds from Vote
on Account, the Administrative Departments are fully empowered to
sanction expenditure for:
(a) Provisions made under Disaster Response Funds
against Relief expenditure and provisions made under
Administrative
Expenditure
and
Programme
Expenditure towards Grant-in-aid (salary) for Aided
Educational Institutions, Scholarship and Stipend to SC & ST
Students, SOAP, NOAP, ODP, Modernization of State Police
Force (including advance payment to Ordnance Factories for
procurement of arms and ammunitions) and other Security
Related Expenditure.
(b) All resource-tied up schemes and State‟s Own Flagship
Programmes like BASUDHA, Madhubabu Pension Yojana, Biju
Swasthya Kalyan Jojana, Mukhyamantri Swasthya Seva
Mission, Biju Setu Yojana, under Programme Expenditure.
14. (i) As stipulated in Subsidiary Rule 242 of Orissa Treasury
Code, Volume - I, money should not be drawn from the Treasury
unless it is required for immediate disbursement. Besides, it is
stipulated in Rule-6 of O.G.F.R, Volume-I that unless otherwise
expressly authorized by any law or rule or order having the force of
law, moneys may not be removed from the Government Account for
investment or deposit elsewhere without the consent of the Finance
Department. Further, Rule-141 (3) of Odisha Budget Manual
provides that no money should be drawn from the Treasury unless it
is required for immediate payment. It is not permissible to draw
money from the Treasury and keep them in Banks without sanction
of Finance Department. Money should not be drawn from the
Treasury simply on the ground that the charges have been
sanctioned by competent authority. Nor is it permissible to draw
money from the Treasury and then place it in deposit in order to
avoid lapse of allotment. The system of electronic disbursement of
Government payments directly to the beneficiary account has been
introduced vide Finance Department O.M. No. 27444/F, dated
26.7.2012 with the objective of direct payment to the beneficiaries
and vendors and to prevent parking of funds in bank accounts by
the DDOs. However, instances have come to the notice of
Government that money drawn by the DDOs is being kept unutilized
for indefinite period. This adversely affects the Ways and Means
position of the State. Drawal and retention of funds results in

51

<!-- page 60 -->

deferment/deprivation of the expenditure on priority items which
are linked with developmental activities. In order to prevent drawal
of money and retention thereof in shape of cash/bank draft, the
DDOs must record a certificate on the body of the bills presented
after 31st March, 2022 as follows:
“the money drawn in cash/bank drafts up to the period
31.03.2022
has
been
disbursed
by
now
except
Rs._____________which would be disbursed by 30.04.2022 at the
latest”.
(ii) Similarly, while presenting the pay bill for April, 2022 to
be paid on or after 01.05.2022, the D.D.O must record a certificate
that:
“all money drawn in cash/bank draft up to the period 31.03.
2022 have been fully disbursed and no amount is lying un-disbursed
with him”.
(iii) While presenting the pay bill for the month of May,
2022 onwards, the D.D.O. must record a certificate to the effect
that:
“the money drawn in shape of cash/bank draft through the
bills presented during the previous months has been disbursed
except the money drawn in A.C. bills and the amount now proposed
for withdrawal in this bill in shape of Cash/Bank draft shall be
disbursed within a period of 15 days from the date of actual drawal
from the Bank/Treasury”.
(iv) While scrutinizing the bills to be presented during 202223, the Treasury Officers must check and ensure that a certificate is
recorded on the body of the bill by the D.D.O. concerned to the
effect that no amount of money drawn from Treasury/Bank has
been kept in deposit account without specific prior approval of
Finance Department.
(v) It is observed that the cash balance Certificate is being
furnished in a routine manner although huge amounts remain undisbursed for a long period, which seriously affects the Ways &
Means position. The DDOs shall furnish a cash balance report
as on 16.04.2022 in the enclosed proforma (at Annexure) to
the Collector of the District by 22.04.2022.The Collector in
turn will report directly to Finance Department (Ways &
Means Branch) the name of DDOs who have drawn money up
to 31st March 2022 but have not disbursed it by 16.04.2022.

52

<!-- page 61 -->

A copy of such report should also be endorsed to the
concerned Heads of Department.
(vi) Instructions have been issued vide Finance Department
letter No.23583/F, dated 10.07.2019 and letter No.32215/F, dated
21.11.2014 that money should not be drawn from the Treasury by
the DDOs unless it is required for immediate disbursement. Unauthorized parking of Government money in Bank Account in
contravention of financial rules and instructions issued by Finance
Department is strictly prohibited. It has been stipulated in the
above mentioned circulars of Finance Department that if any
such instance of un-authorized parking of money is noticed,
the concerned DDO shall be liable for disciplinary action
under Rule –15 of the OCS (CC&A) Rules, 1962. As per
instructions issued vide Finance Department Circular No. 32215/F.,
dated 21.11.2014, the Heads of Department and Collectors shall
cause

enquiry

into

the

matter

of

unauthorized

parking

of

Government money in bank accounts after obtaining information
from

the

Treasury

Officers/

Drawing

and

Disbursing

Officers/Autonomous Agencies of the Districts. In case, instances of
irregularity are found, the matter should be reported to respective
Heads
should

of

the

Department/

Administrative

take

disciplinary

action

Department.

against

the

They

concerned

sanctioning authority as well as the DDO, committing such
irregularity, under intimation to Finance Department and
ensure

that

funds

are

drawn

and

transferred

to

implementing agencies only for actual expenditure and not
for parking in Bank Account. The sanctioning authority and
the Drawing & Disbursing Officers shall strictly follow these
instructions.
Administrative Departments are to sanction and release funds
for expenditure out of the Vote on Account, 2022-23 in accordance
with the aforesaid instructions.
Yours faithfully,
Sd/Principal Secretary to Government

53

<!-- page 62 -->

Annexure
CASH BALANCE REPORT OF DDOS AS ON 16.04.2022

Name &
Name of the
UnUnTotal
Designation
Heads of
disbursed
disbursed
amount of
of the
Department/ amount out amount out
unD.D.O.
Administrative of money
of money
disbursed
Department
drawn
drawn in
money
before
March, 2022
01.03.2022

1

2

3

4

5

Break-up of
the
un-disbursed
amount
i.e. whether
kept in
cash/B.D./
Banker’s
Cheque/DCR
or
in
unauthorized
Bank
Account.

Reasons for
drawal &
retention of
the undisbursed
amount in
violation of
SR 242 of
OTC Vol-1.

6

7

Signature

Designation of D.D.O.

54

<!-- page 63 -->

MATTERS RELATING
TO TREASURY

<!-- page 64 -->

<!-- page 65 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No. 10987/F.,
Dt. 07.04.2021
FIN-TRY-MEET-0001-2017(PT-II)

OFFICE MEMORANDUM
Sub: Submission of request for withdrawal of final GPF/TPF
amount by the retiring/retired State Government employees
and procedure for revalidation of final GPF /TPF authorities
The disbursement of Final General Provident Fund (GPF) and Teacher
Provident Fund (TPF) amount to the retired State Government/ Aided and
Taken over Educational Institutions employees is being guided as per
Odisha General Provident Fund rule and Odisha Aided Educational
Institutions Employees Provident Fund Rules 1983. To facilitate faster
and timely disbursement of the Final Provident Fund to the retired
Government Servants/ legal heirs of the deceased Government
employees, the State Government vide Finance Department O.M.
No.29598/F, dated 06.11.2020 have centralized disbursement of the
same by the State Pension Treasury (Nodal Treasury) for the entire State
with effect from 1st November, 2020 against the digitally signed electronic
authorities issued by the O/o Principal Accountant General (A&E), Odisha
and Controller of Accounts, Odisha.
Accordingly, the Drawing and Disbursing Officers (DDOs) of the State
Pension Treasury (SPT) prepare the bills online in IFMS, make electronic
disbursement to the Bank Accounts of the beneficiaries and submit
electronic voucher and accounts to the O/o Principal Accountant General
(A& E) Odisha.
In the meantime, following major issues have been identified by the
O/o Principal Accountant General (A&E), Odisha:
1.

Delayed drawal/ non drawal of final GPF/TPF amount by the
concerned DDOs within the validity period of the Authorities
issued by Principal Accountant General (A&E), Odisha and
Controller of Accounts, Odisha prior to the decision taken by
State Government for migration to centralized disbursement
through SPT, leading to unnecessary harassment, increase in
grievances and financial liability on the State exchequer.

57

<!-- page 66 -->

2.

Submission of re-validation request by the DDOs and Treasuries
to concerned GPF Issuing Authorities (A.G and Controller of
Accounts) violating proper procedure and without proper
checking of disbursement status leading to possibility of double
drawal against the Authorities.

3.

Drawal of GPF authority after expiry of validity period of six
months.

4.

Difficulties in fetching Bank Account details of some beneficiaries
from IFMS at the time of disbursement by SPT due to absence of
the same in the digitally signed final GPF/TPF Electronic
Authorities issued by Accountant General (A & E) /Controller of
Accounts.

5.

Possibility of drawal by the DDO of the retiring Government
employee under Sub-Rule 4 of Rule 15 of Odisha GPF Rule after
sending the final GPF proposal to AG for issue of Final GPF
authority thereby leading to excess authorization and drawal by
SPT.

6.

Continuation of manual authorities by Accountant General (A
&E) in favour of the DDOs for residual balances of GPF even
after implementation of centralized disbursement through State
Pension Treasury, which assents to a dual system of disbursal
process.

To overcome the above difficulties and for complete centralization of
disbursement of final GPF/TPF amount to the retired State Government
employees/ Legal heirs of the deceased State Government employees at
the level of State Pension Treasury, the State Government have decided
for some procedural changes for the disbursement of the pending final
GPF/TPF authorities issued prior to 1st November, 2020 in case of
Accountant General (A & E) and 22nd January, 2021 in case of Controller
of Accounts, re-validation of final GPF/TPF Authorities pending with the
Accountant General (A & E) / Controller of Accounts, submission of Final
GPF/ TPF application by the Drawing and Disbursing Officer (DDO) for
issue of Final GPF/TPF Authorities by Accountant General (A & E) /
Controller of Accounts and issue of authority for GPF residual balance by
the Accountant General (A & E) .
The details are as follows:
A.

Authority of Residual Balances and Revalidation of all Final
GPF/TPF Authorities pending at the level of DDO and
Treasuries after expiry of the validity period (6 months):

58

<!-- page 67 -->

The DDOs will return all final GPF/TPF Authorities, which are pending
with them after validity period to the issuing authority i.e., A.G (A&E)/CoA
for revalidation.
The request letter for re-validation shall be supported with nondrawal certificate by the DDOs on the body of the Authority along with the
Bank details like Bank Account Number, IFSC, MICR of the Bank Branch
and Mobile number of the retired Government employee/Legal heirs of the
deceased Government employee to whom payment is authorized.
Copy of the request letter for revalidation should be forwarded to
the State Pension Treasury by the DDOs providing the details of the bank
account of the beneficiaries.
The Treasury Officer will simply return the invalid Authorities to
AG/CoA with a non-payment certificate on the body of the authority.
After receipt of revalidation request from the DDO, after due
verification, the AG/CoA will issue another digitally signed Authority in
favour of the State Pension Treasury. The re-validated final GPF/TPF
Authority will contain the Bank Account details of the beneficiary, as
provided by the DDO, to speed up the process of disbursement by State
Pension Treasury.
From the date of effect of this memorandum, no authority will be
issued by the Accountant General/Controller of Accounts in favour of the
initiating DDOs. All revalidated as well as authorities for residual GPF/TPF
balances, shall be issued in favour of “The Treasury Officer, State Pension
Treasury” to ensure complete centralized drawal and disbursement. An
SMS alert will be sent to the retired Government employee and SPT for
information. In case of difficulty in uploading such authorities in IFMS,
the digitally signed authorities may be forwarded to the SPT from a
designated mail of the issuing authority i.e. bofm.od@nic.in
/coaorissa@rediffmail.com/ to the designated mail of SPT i.e.
state.pension@orissatreasury.gov.in. Any change of designated mail of
the GPF/TPF issuing authorities shall be duly communicated to the State
Pension Treasury.
The retired Government employee can download his/her personal
copy from the portal of Accountant General (A & E), Odisha and Controller
of Accounts by using his/ her GPF/TPF Number. The DDO of the retired
Government employee can only view the details of the authority like
Authority No, GPF No., Series and Amount etc. To avoid any irregular bill
preparation and submission by the DDO, the provision for downloading of
the Final Provident Fund authority in IFMS in the DDO interface has not
been provided for the time being, which is subject to reconsideration.
Once payment is completed by SPT, the status of the authority will be
updated on real time basis for the DDO in IFMS.

59

<!-- page 68 -->

The DDOs are required to complete the drawal and disbursement of
the valid authorities pending with them as on the date of this
memorandum. Treasuries are required to furnish a list of undisbursed
authorities as per their record, to the Directorate of Treasuries &
Inspection for necessary follow up with concerned authorities to finish the
DDO level pendency as a one-time measure.
B.

Submission of Applications by the Drawing and Disbursing
Officer (DDO) for issue of Final GPF/TPF Authorities to
Accountant General (A & E) / Controller of Accounts.

In the existing process, Form O.T.C. 80-A (for Gazetted Officers)/
Form O.T.C. 80-B (for Non-Gazetted Officer)/ Form O.T.C. 80-C (For
Nominee/ any other claimant) are being used by the Retiring/Retired
State Government employees / Nominee-Legal heir of the deceased State
Government employees for final payment of balances in their GPF/TPF
Accounts. Those Applications are forwarded to concerned Issuing
Authorities after due verification by the concerned Head of Offices.
In order to accelerate the process of disbursement of final GPF/TPF
balances to the beneficiaries, henceforth, all Head of Offices shall
mandatorily mention the DDO code, the Bank Account details like Bank
Account Number, IFS Code, MICR of the Bank Branch and Mobile number
of the beneficiaries and other documents at the time of forwarding the
Applications in Form O.T.C. 80-A/B/C to Accountant General/ Controller of
Accounts.
Copy of form OTC-80-A/B/C along with the details of the
beneficiaries‟ bank accounts may be forwarded to the SPT by the DDOs.
Accountant General/ Controller of Accounts will issue digitally signed
Final Provident Fund Authority, containing the Bank Account details and
Contact number of the beneficiary, DDO code of the Head of Office from
which the application was originally initiated in favour of Treasury Officer,
State Pension Treasury.
On receipt of digitally signed PF Authority from AG, the SPT would
link up the same with the beneficiaries‟ bank account details forwarded by
the DDO for making payment.
C.

Possibility of advance GPF/TPF drawal by the DDO of the
retiring Government employee under Sub-Rule 4 of Rule 15 of
Odisha GPF Rule after sending the final GPF proposal:

Error! Filename not specified. In case, the DDO of the retiring
Government employee due to some proved urgent requirement of the
retiring employee is obliged to sanction and draw part final GPF amount
under Sub-Rule 4 of Rule 15 of Odisha GPF Rule, after submission of the
final GPF Application to the O/o Principal Accountant General (A&E),

60

<!-- page 69 -->

Odisha/ Controller of Accounts should immediately obtain prior approval
of the GPF Issuing Authorities through mail (bofm.od@nic.in
/coaorissa@rediffmail.com/) under intimation to State Pension Treasury
(state.pension@orissatreasury.gov.in). The GPF Issuing Authorities should
intimate the fact of approval to the Treasury officer, State Pension
Treasury through the designated mail. The final authority will be issued
only after confirmation of part final withdrawal by the DDO.
The procedural changes shall be effective from the date of issue of
this Memorandum.
By order of the Governor
Sd/(A.K.K. Meena)
Principal Secretary to Government

61

<!-- page 70 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
****
No. 11437/F.,
Dt. 08.04.2021
FIN-TRY-MISC-0015-2020

OFFICE MEMORANDUM
Sub: Process Re-engineering in transfer of P.L. funds from one
account to another across the treasury and transfer of funds
from P.L. Account to Executing Agencies under Public Works
Division of Works and Forest Divisions of Forest &
Environment Department.
Banking deposit accounts are maintained in Treasuries and Sub
Treasuries by Local Bodies, Zilla Parishads, Panchayat Samitis, State and
District level Statutory and Autonomous Bodies as well as State declared
Special Purpose Vehicle (SPV) like Odisha Mineral Bearing Area
Development Corporation (OMBADC). The Administrators of such banking
account known as Personal Deposit/Personal Ledger Accounts make
payment to their employees, vendors, suppliers and contractors through
electronic cheque using IFMS platform which is guided by Finance
Department Office Memorandum No. 32152/F, dated 15.12.2015.
Administrators of P.L. Accounts transmit fund to different
Works/forest Divisions for execution of developmental works. Presently,
to facilitate such transfer, P.D. Administrators draw money from their P.L
Account through electronic Cheques and credit the same to the Bank
account of concerned Works/Forest divisions. The concerned Divisions
have to again withdraw the money from their Bank Account and deposit
the same with Treasury in shape of challan to make the fund available
under their Deposit head to carry out the Deposit work.
In this process, due to non-availability of an automated process of
fund transfer along with appropriate accounting adjustment cash
transactions takes place leading to delay in execution of development
work. Further, it also leads to unnecessary cash outgo from Government
Account and may remain parked there till not deposited by the concerned
authorities in their Deposit head in the Treasury.
To overcome such difficulties, necessary customization has been
made in IFMS to facilitate an automated process for transfer of fund from
the P.L. Account of an Administrator to respective Executing Agencies
under Works and Forest & Environment Department along with accounting
adjustment by reflecting the transferred fund in their Consolidated
Treasury Receipt (CTR).

62

<!-- page 71 -->

Henceforth, the PD Administrators shall follow the new automated
process for transfer of fund from their P.L. Account to Deposit Account of
respective Executing Agencies. The operational process for such
automated fund flow along with role and responsibility of PD
Administrator and Treasury in the process are outlined and attached as
“Annexure-I”.
Sd/Principal Secretary to Government

63

<!-- page 72 -->

ANNEXURE- I
OPERATING PROCESS FOR AUTOMATED FUND FLOW FROM P.L
ACCOUNT OF P.D ADMINISTRATORS TO DEPOSIT ACCOUNT OF
PUBLIC WORKS/ FOREST DIVISIONS.
Role of P.D. Administrator
i.

After receipt of approved Detailed Project Report (DPR) and fund
requisition statement from respective Executing Agencies, the
Administrator will issue sanction order for necessary transfer of fund.
Sanction order will contain the details of By Transfer to be made in
favour of Public Works/ Forest Divisions.

ii.

The Administrator will issue electronic cheques in the online P.L.
interface of IFMS for transfer crediting the amount in favour of the
respective Executing Agencies.

iii.

For online transfer of fund, the P.L. operator will login to the P.L.
Application of IFMS and will choose and save the Payment
Type/Cheque Type as “Transfer to Work Operator”.

iv.

Upon saving Payment/Cheque Type along with Scheme Id. from
which fund needs to be transferred and amount, concerned Operator
will choose the Executing Agency to whom the fund needs to be
transferred by selecting Work Operator Details Menu in the system.

v.

For the convenience of the Operator in choosing the agency facility
for short listing and searching an agency on the basis of its attached
treasury is available in IFMS. The operator will first choose Parent
Treasury
(District/Special
Treasury)
and
Treasury
(District/Special/Sub Treasury) to find the desired Executing Agency
which is attached to that treasury.

vi.

The P.L. Operator will forward the electronic payment request
generated at his level in IFMS to the “Approver”. The P.L. Approver
will approve the payment request and generate electronic cheque for
transfer of fund in favour of the desired Executing Agency.

vii.

The authorised officer will take a print out of the electronic cheque
and submit the same to treasury along with submission of e-Book of
Drawal as per the usual process.

viii.

After the electronic cheque is approved and advised at the level of
treasury, the fund will be seamlessly transferred in favour of the
concerned Executing Agency and it will be reflected in the CTR of
concerned Executing Agency maintained in the destination treasury.

ix.

After the e-cheque is approved for payment by treasury, the fund
transferring P.L. Administrator shall log into P.L. Application by using
the IFMS User credential and choose the e-Cheque Reference Id. of

64

<!-- page 73 -->

concerned cheque from the “Task List”. He/ She will take a print out
of the Beneficiary Details of that e-cheque reflecting the status of
payment as complete.
x.

The Administrator will send the print copy along with a forwarding
letter to the concerned Executing Agency under Works/ Forest
Division confirming the transfer of funds thereby.

xi.

IFMS is customized to generate a fund transfer/expenditure report at
the level of concerned transferring Administrator showing the details
of Beneficiary-wise/Operator-wise status of expenditure. In case of
fund transfer to Works/Forest Divisions, the CTR details will also be
available for the Administrators in the system generated report.

Role of Treasury
i.

ii.
iii.

iv.

v.

The concerned Treasury will receive the P.L. cheques and after due
verification, the electronic cheque will be approved in the treasury
application as per extant procedure.
The Treasury will generate P.L. advice separately from the treasury
application of IFMS
Upon approval and subsequent advice generation w.r.t. the eCheque, the concerned P.L. Payment Head of Account (HoA)
8443/8448-00-xxx-yyyy-zzzzz-abc is debited in the initiator treasury
where the P.L. Account is maintained. Simultaneously, a virtual
Challan worth the e-Cheque amount is generated in the Receipt side
of the same initiator treasury under the HoA8782-00-110-xxxxyyyyy-zzz. The credit entry shall appear in the system generated
“Schedule of Receipt”. The operation of Head 8782-00-110 is
applicable only in case of inter-Treasury transfer. In case of intraTreasury transfer, the P.L. Account Head 8443/8448 shall be debited
and 8782-00-102/103 Head shall be credited.
In the destination Treasury where the concerned Executing agency is
mapped, a virtual „refund of receipt‟ bill will be generated under the
HoA 8782-00-110-xxxx-yyyyy-zzz. The remittance transferred in
favour of the Executing Agency will be reflected as deposit under the
Head of Account 8782-00-102-1683-91028-690 in case of Public
Works Division & under HOA 8782-00-103-1683-91014-000 in case
of Forest Division by generating virtual challan in an automated
process. Treasury will provide CTR to concerned Public Work/ Forest
Division accordingly.
The concerned Public work Division/Forest Division will create
necessary deposit balance under Part-III Deposit Work using the
Works Module of IFMS and WAMIS as per the extant process of
“Deposit of Work”.

65

<!-- page 74 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No. 32321 /F,
Date. 22.11.2021
FIN-TRY-PEN-0001-2021

OFFICE MEMORANDUM
Sub: Amendment of pension forms prescribed under Odisha Aided
Educational Institutions Employees Retirement Benefit
(OAEIERB) Rules, 1981 read with Executive Instruction No11931/EYS Dated: 21.03.1983 issued by Education and Youth
Services Department
Authorisation of pension / family pension /other pensionary benefits
to the employees of Aided / Urban Local Bodies / Taken Over Educational
Institutions is governed by the provisions of Odisha Aided Educational
Institutions Employees Retirement Benefit (OAEIERB) Rules, 1981 read
with Executive Instruction No-11931 dated 21.03.1983, OCS(Pension)
Rules 1992, the Odisha Municipal Employees Pension Rules,1989
depending upon the nature and category of service of the employees.
2. In the extant process, the pension forms as prescribed vide
Executive instruction No-11931, dated 21.03.1983 are being used for
processing of pension applications of the employees of Aided/ ULB/ Taken
Over Educational Institutions. Filing up of the existing forms requires high
degree of manual intervention at all stages. Scrutiny of these forms takes
a lot of time at the level of both the Pension Sanctioning Authority and
the Pension Issuing Authority i.e. the Controller of Accounts, Odisha. This
leads to delay in disbursement of pensionary benefits to the pensioners.
3. In order to reduce the requirement of manual intervention, for
faster processing as well as for tracking of pension applications, State
Government is considering introduction of online mode of pension
processing, starting from submission of the pension application in respect
of the employees of Aided/ULB/taken over Educational Institutions
through the IFMS portal. Many of the information to be captured in the
amended pension forms can be prefilled from the employee record
available in IFMS/HRMS while submitting the pension applications through
IFMS, once the online application process is implemented.
4. Keeping in view the above facts and to ensure transparency and
hassle-free processing of pension applications, the State Government

66

<!-- page 75 -->

have decided to amend the pension forms as prescribed in the Executive
instruction No-11931, dated 21.03.1983 in line with the pension forms
prescribed under Odisha Civil Services (Pension) Rules, 1992 with some
additional information to cater to the need of online processing of pension
application. The list of newly prescribed pension forms vis-à-vis the
existing pension forms is appended at Annexure-A.
5. This shall come into force for all pension applications received by
Head of the Office / Pension Sanctioning Authority on or after 01.12.2021
irrespective of the date of retirement of the employees.
6. Concurrence of School & Mass Education Department, Higher
Education Department and Housing & Urban Development Department
has been obtained in OSWAS Files: FIN-SOS1-PEN-0003-2021, FIN-TRYPEN-0001-2021 and PT1-FIN-TRY-PEN-0001-2021 respectively.
7. Provisions of Odisha Aided Educational Institutions Employees
Retirement Benefit (OAEIERB) Rules, 1981, Executive Instruction No11931 dated 21.03.1983, OCS (Pension) Rules 1992, and Odisha
Municipal Employees Pension Rules, 1989 stand amended accordingly.

By order of the Governor,
Sd/(Vishal Kumar Dev)
Principal Secretary to Government

67

<!-- page 76 -->

ANNEXURE-A
Sl.
No.

2
3

Existing Pension
Forms
Form 1A, 1B, 1C,
1D
Form 2
Form 3

4

Form 4

5
6
7

Form 4A
Form 4B
Form 4C

8

Form 5 &6

9

Form 5A

10

Form 7

11

Form 9

12

Form 10

13

Form 11

14

Form 12

15

Form 21

16

Form 22

17

No form
prescribed

1

PURPOSE
Nomination for DCRG (For LTA pension &
DCRG)
List of Employees to retire
Application for pension
Assessment & Calculation of pension &
Gratuity
Sanction of Pension
Forwarding letter
Form of surety bond
Information to the family of deceased for
grant of DCRG
Declaration of Retiring
Application for grant of DCRG on death of
Govt. servant
Application for grant of FP on death of a Govt.
Servant/ Pensioner
Assessment & sanction of FP/DCRG on death
of a Govt servant while in service/ Pensioner
Details of Family
Form for Forwarding papers for FP/DCRG on
death of a Govt Servant /Pensioner
Sanction of FP to Child on death of pensioner
without living widow
Sanction of FP on remarriage /death of Widow
Family pensioner
Sanction of Provisional pension
/FP/CVP/DCRG

68

Amended New
Forms
Form C
Form A
Form E
Form F
Form F
Form G
Form P & Q
Form H
Form E
Form J
Form K
Form L
Form D
Form M
Form R
Form S

Form N

<!-- page 77 -->

PENSION FORM – A
[See Executive Instruction Para 1(2)]
(Information on list of employees due to retire in the succeeding calendar year)

List of Govt./Aided/ULB servants employed in the office / Department
__________________________ who are due to retire by the end of 31st December of the
succeeding calendar year.

Sl. No

Name of the Employee

Designation

Date of Birth (dd/mm/yyyy)

Date of super- annuation
(dd/mm/yyyy)

GPF / Account Number

Whether action for processing of
pension paper initiated in
advance as per Rule.(Yes / No)

1

2

3

4

5

6

7

(The List is to be sent by 31st of July each year by the Head of Office to the Controller of
Accounts ,Odisha, Bhubaneswar,/ Appointing Authority / Administrative Department
concerned / Director of Treasuries & Inspection, Odisha, Bhubaneswar / Estate Officer
(if the Govt./Aided/ULB servant is allotted a Government Accommodation).

Signature of the Head of Office

69

<!-- page 78 -->

PENSION FORM – C
[See Para 13 of Executive Instruction]
NOMINATION FOR PAYMENT OF ARREARS OF COMMUTATION VALUE /
DEATH-CUM- RETIREMENT GRATUITY AND LIFE TIME ARREARS OF
PENSION.
In the event of my death, I,
hereby
nominate
the
person/persons mentioned below, who is/are members of my family/not a part of my family confer on
his/her/them the right to receive the arrears arising out of commutation value of pension / gratuity
sanctioned but remaining unpaid/ life time arrears of pension/ other arrears payable to me, the
payment of which have been authorised by the State Government but remained unpaid and confer
on him/her/them the right to receive the arrears to the extent specified below against each.

Original
nominee(s)

Alternate nominee(s)

Names and Relationship with Date of Birth of
the Nominee
address of
the
nominee/nominee Government/Aided (dd/mm/yyyy)
s.
/ ULB Employee

1

2

3

Percentage
of share of
Arrears

Percentage of
Name, address,
share of
relationship and
Arrears
date of birth of the
person or persons,
if any, to whom the
right conferred as
the nominee, shall
pass in the event of
the nominee predeceasing the
Government/Aided/
ULB Employee or
the nominee dying
after the death of
Government/Aided/
ULB Employee but
before receiving
payment of share of
arrears.

4

5

6

Note:1. Any Retiring Govt./Aided/ULB employee desirous of assigning different nominees for different type of claims may fill in
separate forms of nomination and submit it to the pension sanctioning authority/Head of Office.
2. All columns should be filled in so as to cover the whole amount of the arrears with reference to the percentage.
3. This nomination supersedes previous nomination if any furnished by him/her.
4. The Govt./Aided/ULB servant shall draw lines across the blank space below the last entry to prevent the insertion of any
name after he has signed.
5. Strike out which is not applicable.
Dated this....................day of month ...................., 20......at..................................................
Signature of two witnesses:
1.
2.
Signature of the Govt./Aided/ULB Employee.
Signature of the Head of Office
accepting the nomination

70

<!-- page 79 -->

PENSION FORM – D
(See Odisha Aided Educational Institutions Employees Retirement Benefit (OAEIERB) Rules,
1981, Odisha Aided Educational Employees (Non-Government fully aided primary school
teachers) Retirement Benefit Rules, 1986)

(Information on details of family)
1. Name of the Government/Aided/ULB Employee: 2. Designation:3. Date of Birth as per service book : 4. Date of Appointment :5. Details of the members of my family* as on ……………
SL.
NO.

Name of the
members of the
family*

Date of Birth
(dd/mm/yyyy)

Relationship with the
Government
/Aided/ULB
Employee

Remarks
if any

1.
2.
3.
4.
5.

I hereby undertake to keep the above particulars up-to-date by notifying to the
Head of office any addition or alterations in the family.

Signature of the Govt/Aided/ULB Employee
Place :
Date :
* Family for this purpose means family as defined in clause (b) of sub-rule (17) of Rule
56 of the Odisha Civil Services (Pension) Rules , 1992.
** Wife and Husband shall include respectively judicially separated wife and husband.

71

<!-- page 80 -->

PENSION FORM-E
[See Executive Instruction Para 5(2)]
(Application by the Retiring Government/Aided/ULB Servant for
sanction of
Pension, Gratuity and Commuted Value of Pension)
PART-I
Name of the Government/Aided/ULB Servant (In Block Letters)
1

2 Father/Spouse Name

Father:Husband/Wife :-

Date of Birth( by Christian Era) as recorded in
3 the Service Book
4Date of Joining in Service/Appointment
5Date of Retirement

6Post last served and the name of the Office
Type of Pension applicable (Super-Annuation /
Pension on Voluntary Retirement / Invalid
Pension /Pension on Compulsory / Retirement /
Compensation Pension)
7
Previous Pension/Family Pension received ,if any,
from other source / military / civil
Please indicate the details PPO/FPPO
8 No.- Amount of Pension & date from which
received.

Permanent Address:9

Address for Correspondence
1
0(where the Pensioner intends to reside after
retirement)
Mob No:
Email Id:

72
