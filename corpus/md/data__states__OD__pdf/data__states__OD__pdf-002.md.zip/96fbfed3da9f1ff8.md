---
doc_id: "96fbfed3da9f1ff8"
source_url: "https://odishatransport.gov.in/Application/uploadDocuments/Notification/Rules_1790601814.pdf"
ministry: "Odisha Motor Vehicle Department"
title: "DETAILS OF VIDEO CONFERENCING PERMIT HEARING MEETING IN MICROSOFT TEAM ON 30TH SEPTEMBER,2026"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0cef2a2038077586"
---

<!-- page 1 -->

Guidelines to attend VC in Microsoft Team on 30th September,2026
• For Desktop/Laptop User, Click on the link and Select Continue On this Browser.
• For Smart Phone User, Download Microsoft Teams App from Google Play store and Install.
• Click on the Link, then click on Join meeting.
• In the place of type Your Name, follow below format for STA Permit
Meeting. Format: Sl No <space> Vehicle No of Owner or Objector
• For Technical Assistance, please contact: 9338408000
Details of Video Conferencing Permit Hearing Meeting in Microsoft Team on
30th September,2026
STA INTER REGION PERMIT MEETING (SL No111-160) TIMING (11:30AM-01:30PM) : Click on the below link
https://teams.live.com/meet/9360920248738?p=rfHHOqFxKlREg28p8B

•

STA INTER REGION PERMIT MEETING (SL No 161 - 212) TIMING (03:30 PM – 05:30 PM): Click on the below Link
https://teams.live.com/meet/9331382760459?p=L7h9K8VpZaxPSZzj3l

<!-- page 2 -->
