---
doc_id: "11facdeb097edc3c"
source_url: "https://odishaconstruction.com/wp-content/uploads/2025/06/Office_orded_22.pdf"
ministry: "Odisha Construction Corporation Limited, Bhubaneswar, Odisha"
title: "Office Order"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b4c45aced8e76ed5"
---

<!-- page 1 -->

ODISHA CONSTRUCTION CORPORATION LTD.
( A Government of Odisha Undertaking )
CENTRAL WORKSHOP, RASULGARH, BHUBANESWAR-751010

Email : smppmcws@gmail.com

Phone 0674 : 2580106
FAX:
0674-2587321
Email : smppmcws@gmail.com
GSTIN - 21AAACO2571K2ZM

No. OCC/CWS/PROC/ MW-01/_2258_/

Dtd._16.06.2025___/

OFFICE ORDER
This office quotation call notice No.OCC/CWS/PROC/ MW-01/ 22 /2025-26 dated. 06.06.2025 due on
13.06.2025 for “ Supply of key material for Kanupur Irrigation Project. ” is hereby cancelled .

Sd/SENIOR MANAGER (MECH.)-I

Cancellation (2025) 94
