---
doc_id: "0bb71e4f27caf3ca"
source_url: "https://missionshakti.odisha.gov.in/sites/default/files/2026-08/Tender%20Conference%20AV%20System%20Final.pdf"
ministry: "MIS System for Mission Shakti Portal, Odisha"
title: "Download(592.87 KB)"
date: ""
pages: 50
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "80046d23becd8497"
---

<!-- page 1 -->

Notice No:1003

Date:25.08.2026

NOTICE INVITING TENDER (NIT)
FOR SUPPLY, INSTALLATION, TESTING, COMMISSIONING, INTEGRATION AND
COMPREHENSIVE WARRANTY SUPPORT OF DIGITAL CONFERENCE AUDIO-VISUAL &
DISPLAY SYSTEM
State Mission Director-cum-CEO, Odisha Livelihoods Mission (OLM), Mission Shakti Department, Govt. of
Odisha invites sealed Tenders from eligible firms/agencies for “Supply, Installation, Testing,
Commissioning, Integration and Comprehensive Warranty Support of Digital Conference AudioVisual & Display System at the Conference Hall of SMMU, OLM, Bhubaneswar”. Bidders fulfilling
the prescribed eligibility criteria of the tender can access and download the complete bid Document and
other details from https://missionshakti.odisha.gov.in/.
The bid calendars under the end-to-end process are:
Sl. No.
Critical Events
Time Line
1
Date of Issue of Tender
29.08.2026
2
Last Date and Time for Submission of Bid
21.09.2026,3.00 PM
3
Opening of Technical Bid
21.09.2026,4.00 PM
4
Opening of Financial Bid
21.09.2026,5.00 PM
*In case of time constraints, a separate date for opening of the Financial Bid will be communicated in
advance.

The proposal complete in all respects must reach at State Mission Director-cum-CEO, Odisha
Livelihoods Mission, SIRD & PR Campus, Unit-VIII, Bhubaneswar-751012 by Speed Post/
Registered Post/ Courier only latest by 21.09.2026, 3:00 P.M. in a sealed envelope clearly mentioning on
the top of it " SELECTION OF AGENCY FOR SUPPLY, INSTALLATION, TESTING, COMMISSIONING,
INTEGRATION AND COMPREHENSIVE WARRANTY SUPPORT OF DIGITAL CONFERENCE AUDIOVISUAL & DISPLAY SYSTEM AT THE CONFERENCE HALL OF SMMU, OLM, BHUBANESWAR.”. The
proposals received beyond the last date and time will be rejected. In case of any Addendum/ Clarification/
Corrigendum/ Extension regarding this tender, the same will be published in the above-mentioned official
websites only. The authority reserves the right to reject any/ all proposals without any reason thereof.
-SdState Mission Director-cum-CEO
Odisha Livelihoods Mission
Memo No: 1004

Date: 25.08.2026

Copy to Additional Secretary, Department of Mission Shakti, for kind information of Commissioner cum
Secretary, Department of Mission Shakti. Further, it is requested to publish the advertisement in the
website of Department of Mission Shakti for wide publicity.
-SdState Mission Director-cum-CEO
Odisha Livelihoods Mission

Page 1 of 50

<!-- page 2 -->

Odisha Livelihoods Mission
Department of Mission Shakti
Government of Odisha

NOTICE INVITING TENDER (NIT)

“FOR SUPPLY, INSTALLATION, TESTING,
COMMISSIONING, INTEGRATION AND COMPREHENSIVE
WARRANTY SUPPORT OF DIGITAL CONFERENCE AUDIOVISUAL & DISPLAY SYSTEM”

Odisha Livelihoods Mission,
SIRD & PR Campus, Unit-VIII, Bhubanswar-12
Date: 29.08.2026

Page 2 of 50

<!-- page 3 -->

INDEX
Section

BRIEF DESCRIPTION

PAGE

I

Bid Data Sheet

04-04

II

Instructions to Bidders

05-09

III

Scope of Work & Technical Specifications

10-20

IV

General Terms & Conditions

21-26

V

Technical Bid Submission Forms

27-40

VI

Financial Bid

41-43

VII

Annexures

44-50

Page 3 of 50

<!-- page 4 -->

Section – I
Bidder’s Data Sheet
Sl.
No.

Particular

1

Name of the Client

2

Name of Work

3
4
5

11

Method of Selection
Availability of RFP Document
Date of Issue of RFP
Deadline for Submission of
Pre-Proposal Query
Pre-Bid Meeting through
virtual/ Offline mode
Clarification of pre-bid queries
Last Date for submission of
Proposal
Date of opening of Technical
Proposal
Date of opening of Financial
Proposal

12

Tender Processing Fee

13

Earnest Money Deposit (EMD)

14
15
16
17
18

Performance Security
Bid Validity
Completion Period
Warranty
Mode of Submission

19

Address for Submission

20

Contact Person & Mob No

6
7
8
9
10

Details
State Mission Director-cum-CEO, Odisha Livelihoods Mission,
Department of Mission Shakti, Government of Odisha
Supply, Installation, Testing, Commissioning, Integration and
Comprehensive Warranty Support of Digital Conference AudioVisual & Display System
Least Cost Selection (L1)
29.08.2026
29.08.2026
07.09.2026, 3.00 PM
07.09.2026, 4.00 PM
10.09.2026, 5.30 PM
21.09.2026, 3.00PM
21.09.2026, 4.00PM
21.09.2026,5.00PM
(In case of time constraints, a separate date for opening
of the Financial Bid will be communicated in advance)
₹1,180/- (Including GST) through Demand Draft in favour of
Odisha Livelihoods Misson NRLM EFMS
₹1,00,000/- Demand Draft in favour of Odisha Livelihoods
Misson NRLM EFMS
3% of Contract Value
180 Days
28 Days from the date of LoA
Minimum Two (2) Years Comprehensive On-site Warranty
Registered Post / Speed Post / Courier Only
State Mission Director-cum-CEO, Odisha Livelihoods Mission,
SIRD & PR Campus, Unit-VIII, Bhubaneswar – 751012
Deputy CEO (Administration & Procurement), OLM
Contact No-9937462008)
procure.olm@gmail.com
https://missionshakti.odisha.gov.in
Conference Hall, OLM, Bhubaneswar
Indian Rupees (INR)
English

21
Email
22
Website
23
Place of Opening
24
Currency
25
Language
Definitions
For the purpose of this Tender:
• "Client" means Odisha Livelihoods Mission (OLM), Department of Mission Shakti.
• "Bidder" means the firm/company submitting the bid.
• "OEM" means Original Equipment Manufacturer.
• "Contract" means the agreement executed between OLM and the successful bidder.
• "LoA" means Letter of Award.
• "SITC" means Supply, Installation, Testing and Commissioning.
• "Warranty" means Comprehensive On-site Warranty including labour, spare parts, firmware
updates, software updates and maintenance.

-SdState Mission Director-cum-CEO
Odisha Livelihoods Mission
Page 4 of 50

<!-- page 5 -->

SECTION – II
INSTRUCTIONS TO BIDDERS
2.1 Introduction
Odisha Livelihoods Mission (OLM), Department of Mission Shakti, Government of Odisha intends to procure
a complete Digital Conference Audio-Visual & Display System for its Conference Hall at the State
Mission Management Unit (SMMU), Bhubaneswar.
The selected bidder shall be responsible for the design, supply, installation, testing, commissioning,
programming, integration, calibration, documentation, user training and comprehensive on-site warranty
support of the complete system in accordance with the specifications contained in this Tender Document.
The bidder shall quote for the complete system and no partial quotation shall be accepted.
2.2 Eligibility Criteria
The bidder must satisfy the following minimum eligibility requirements:
I.

Bidder to submit BID Specific Authorization with OEM Letter head with contact details like (Name,
Email ID & Phone Number) of the signatory with the ink signed document of Audio System & LED
TV. Revalidation from Local OEM representative for the Audio System & LED TV OEM is mandatory.

II.

The Bidder should have a Minimum Average Annual Turnover of Rs 200.00 lakhs during three
financial years of 2022-23, 2023-24, and 2024-25. Bidder should submit B/S, P&L and ITR for the
consecutive three years. Also the Latest month GSTR 3B Copy to attach.

III.

The Bidder must be in a business of supplying and implementation of Single Work Order of 100.00
lakh or more of any product from any Govt. Of Odisha Departments within the last three years .

IV.

Bidder to Submit proper compliance sheet in OEM Letter head for LED TV and Audio System with
the company seal & signed by the local Partner Business Manager.

V.

Data Sheet has to be provided for Camera, Audio System, LED TV and Speaker products.

VI.

Bidder Should be ISO 9001 & ISO 14001 Certified. LED TV OEM Should have ISO 9001:2015, ISO
27001:2013, ISO 14001:2015 & ISO 45001:2018.

VII.

Bidder must have a registered office in the state of the Consignee location for faster and better
Service, Support, and Documentary Proof to be uploaded along with the Bid Documents. (I.e-Rent
Agreement).

VIII.

Bidder must submit the affidavit properly notarized regarding non-blacklisted on twenty rupees
Stamp paper from Odisha Govt. Organization in Non-Judicial Stamp Paper within Bid Period must be
addressed to the buyer authority with also acceptance of all terms and condition.

IX.

LED TV OEM should have presence in India for more than 20 years (Certificate of Incorporation
required).

X.

LED TV OEM should have minimum annual turnover of Rupees 500 Crores (each year) during last
three financial years in India.
LED TV OEM should have Registered Office in Odisha from last 6 years (Valid document is
required).

XI.

Page 5 of 50

<!-- page 6 -->

XII.

XIII.
XIV.
XV.
XVI.
XVII.
XVIII.
XIX.

XX.

XXI.

LED TV OEM should have complete direct service set-up in Odisha with a service team of minimum
2 trained Service Manager/Engineers on OEM’s payroll. They should have either Bachelor / Diploma
degree (Valid document is required for both service centre & Manager/Engineers).
LED TV OEM should have at least one direct service centre in Odisha. (Valid documents required for
verification.) for providing quick on-site support.
Audio System OEM must provide Service Center Details within Odisha.
LED TV OEM must provide Escalation Matrix of Telephone Numbers for Service Support with
Dedicated/toll Free Telephone No. for Service Support.
Bidder should submit Odisha GST, PAN & Udyam certificate.
Audio System OEM must have factory registration and trademark certificate.
The rate should be quoted inclusive of all taxes, transportation & installation.
The buyer has the right to disqualify without a single clarification to any bidder if any of the
documents supplied by the seller is found to be forged/shortfall. After disqualification, no
representation will be accepted. Product specifications and terms are to be verified by the higher
competent authorities so no representation will be considered.
This office reserve the right to accept or reject any or part of the bid and to cancel the bidding
process at any time without assigning any reason thereof and no intimation will be made to the
bidder in the matter.
Any legal disputes subject under jurisdiction of Bhubaneswar.

2.3 Tender Cost
The bidder shall submit a Tender Processing Fee of ₹1,180/- (including GST) in the form of a
Demand Draft drawn in favour of "Odisha Livelihoods Mission NRLM EFMS" payable at Bhubaneswar.
The Tender Processing Fee is non-refundable.
2.4 Earnest Money Deposit (EMD)
The bidder shall furnish an Earnest Money Deposit (EMD) of ₹1,00,000/- (Rupees One Lakh only) in
the form of a Demand Draft/Banker's Cheque drawn in favour of "Odisha Livelihoods Mission NRLM
EFMS" payable at Bhubaneswar.Bids received without the prescribed EMD shall be rejected.The EMD of
unsuccessful bidders shall be refunded without interest after completion of the tender process.The EMD of
the successful bidder shall be returned after submission of the Performance Security.
The EMD shall be forfeited if:
•

the bidder withdraws the bid during the validity period;

•

the bidder refuses to accept the Letter of Award;

•

the bidder fails to execute the agreement;

•

the bidder fails to submit the Performance Security within the stipulated time.

2.5 Performance Security
•

•

•

The successful bidder shall furnish a Performance Security equal to 3% of the Contract
Value in the form of a Bank Guarantee or Demand Draft in favour of Odisha Livelihoods
Mission NRLM EFMS within 15 days from the date of issue of the Letter of Award.
The Performance Security shall remain valid throughout the contract period and shall be released
after successful completion of all contractual obligations and expiry of the warranty period, subject
to satisfactory performance.
Failure to submit the Performance Security shall result in cancellation of the award and forfeiture of
the Earnest Money Deposit.

Page 6 of 50

<!-- page 7 -->

2.6 Validity of Bid
The bid shall remain valid for a period of 180 days from the last date of submission of bids.No bidder shall
withdraw or modify the bid during this period.
2.7 Preparation of Bid
The bidder shall prepare the proposal in English language.
The proposal shall consist of:
Part-A : Technical Bid
containing:
•

Eligibility Documents

•

Technical Forms

•

Supporting Documents

•

Annexures

Part-B : Financial Bid
containing only the prescribed Financial Bid.
No price information shall be included in the Technical Bid.
Any violation shall lead to rejection of the proposal.
2.8 Submission of Bid
The proposal shall be submitted in three-envelope system.
Envelope–1
Technical Bid
Envelope–2
Financial Bid
Envelope–3
Main Envelope
The third envelope shall contain both Envelope-1 and Envelope-2.
The main envelope shall clearly mention:
•

Tender Number

•

Name of Work

•

Name of Bidder

•

Address of Bidder

•

Contact Number
Page 7 of 50

<!-- page 8 -->

•

Email Address

The proposal shall be sent only through:
•

Registered Post

•

Speed Post

•

Courier

Hand delivery or submission through e-mail shall not be accepted. Late bids shall not be considered.
2.9 Opening of Bids
•
•
•
•

The Technical Bids shall be opened first on the scheduled date in the presence of the
representatives of the bidders.
Only one authorized representative from each bidder shall be permitted to attend the bid opening.
The Financial Bid of only those bidders who qualify the Technical Evaluation shall be opened
subsequently.
The date and time of opening of the Financial Bid shall be asper bidding schedule.

2.10 Clarification of Bids
•
•
•

During evaluation, OLM may seek clarifications from bidders.
The bidder shall furnish the clarification within the stipulated time.
Failure to provide clarification may lead to rejection of the proposal.

2.11 Evaluation Methodology
Evaluation shall be carried out in two stages.
Stage–I
Technical Evaluation
Only bidders satisfying all eligibility conditions shall qualify for financial evaluation.
Stage–II
Financial Evaluation
The Financial Bids of technically qualified bidders shall be opened.
The bidder quoting the Lowest Evaluated Total Price (L1) for the complete scope of work shall
normally be considered for award of the contract.
In the event of a tie in the evaluated bid price, the bidder having the higher average annual turnover over
the last three financial years shall be considered the preferred bidder.
2.12 Rejection of Bids
OLM reserves the right to reject any bid if:
•

required documents are not submitted;

•

the bidder does not satisfy the eligibility criteria;

•

the bid is incomplete;

•

the bid contains false information;
Page 8 of 50

<!-- page 9 -->

•

the bid is conditional;

•

the bid is unsigned;

•

the bid is received after the due date;

•

the Financial Bid is included in the Technical Bid;

•

the bidder has been blacklisted by any Government organization;

•

the bidder attempts to influence the evaluation process.

2.13 Right of Acceptance
•
•

OLM reserves the right to accept or reject any or all bids without assigning any reason whatsoever.
OLM also reserves the right to annul the tender process at any stage without incurring any liability
to the bidders.

2.14 Fraud and Corrupt Practices
•
•

The bidders shall observe the highest standards of ethics during the procurement process.
Any attempt to influence the procurement process through fraud, bribery, collusion, coercion,
misrepresentation or corrupt practices shall result in rejection of the bid and may lead to blacklisting
and legal action.

2.15 Conflict of Interest
•
•

The bidder shall disclose any actual or potential conflict of interest.
Any bidder having a conflict of interest affecting the procurement process may be disqualified.

2.16 Confidentiality
•
•

All information provided by OLM shall be treated as confidential.
The successful bidder shall not disclose any information relating to the project without prior written
approval from OLM.

2.17 Governing Law and Jurisdiction
•
•

This Tender and the resulting Contract shall be governed by the laws of India.
All disputes arising out of the Tender or the Contract shall be subject to the exclusive jurisdiction of
the competent courts at Bhubaneswar, Odisha.

Page 9 of 50

<!-- page 10 -->

SECTION – III
SCOPE OF WORK & TECHNICAL SPECIFICATIONS
3.1 Objective
Odisha Livelihoods Mission (OLM), Department of Mission Shakti, Government of Odisha intends to
establish a modern, integrated Digital Conference Audio-Visual & Display System in the Conference Hall of
State Mission Management Unit (SMMU), Bhubaneswar.
The objective is to provide a reliable, user-friendly and technologically advanced conference system for
conducting meetings, presentations, video conferences, workshops and official events with high-quality
audio and visual communication.
The selected bidder shall be responsible for the complete design, supply, installation, testing,
commissioning, integration, programming, calibration, documentation, user training and comprehensive onsite warranty support of the entire system.
3.2 Scope of Work
The scope of work shall include, but shall not be limited to, the following:
A. Design
The bidder shall carry out a detailed site assessment and prepare a complete system design, including:
•

Equipment layout in 2D Design.

The proposed design shall be approved by OLM before commencement of installation.
B. Supply
Supply of all hardware, software, accessories and materials necessary for successful implementation of the
complete Digital Conference Audio-Visual System.
The supply shall include all cables, connectors, adapters, mounting accessories, network accessories,
power supplies and consumables required for complete functioning of the system.
No additional payment shall be made for any item not specifically mentioned but required for proper
functioning.
C. Installation
Installation shall include:
•

Conference discussion system

•

Chairman discussion units

•

Delegate discussion units

•

DSP

•

Power amplifier

•

Wall speakers

•

PTZ Camera

•

Commercial Displays
Page 10 of 50

<!-- page 11 -->

•

Wireless Presentation System

•

AV Rack

•

Network Switch

•

Structured Cabling

•

Power Cabling

•

Cable Dressing

•

Mounting Hardware

Installation shall be neat, aesthetically finished and professionally executed.
D. Programming & Integration
The bidder shall configure and integrate all supplied equipment into one seamless operational system.
This shall include:
•

DSP Programming

•

Audio Routing

•

Camera Presets

•

Display Configuration

•

Controller Programming

•

Audio Optimization

E. Testing & Commissioning
The bidder shall conduct complete testing including:
•

Functional Testing

•

Audio Testing

•

Video Testing

•

Microphone Testing

•

Speaker Testing

•

Camera Testing

•

Display Testing

The system shall be commissioned only after successful completion of all tests.
F. Documentation
The bidder shall submit:
•

User Manual

•

Installation Manual

•

OEM Datasheets

•

Product Brochure
Page 11 of 50

<!-- page 12 -->

•

As-built Drawings

•

Warranty Certificates

G. Training
The bidder shall provide on-site operational training to officers nominated by OLM.
Training shall include:
•

System Operation

•

Conference Unit Operation

•

PTZ Camera Operation

•

Display Management

•

Basic Troubleshooting

Training manuals shall be provided in soft copy.
H. Warranty Support
Comprehensive on-site warranty shall be provided for Two (2) years.
The warranty shall include:
•

Labour

•

Spare Parts

•

Firmware Updates

•

Software Updates

•

Maintenance

•

Breakdown Maintenance

•

Technical Support

Page 12 of 50

<!-- page 13 -->

3.3 Bill of Quantities (Indicative) and Specification
Sl.
No.

ITEM

QTY

1

CHAIRMAN UNIT
FREE / REQUEST Mode Selection. Priority Function to override all Delegates.
LCD: Displays the Working Status and battery charge status. Microphone Indicator
Ring LED.
Power Supply: 2 pcs., AA, Alkaline Batteries. Equipped with a dedicated Priority Button
that plays a subtle chime and instantly mutes or overrides all active
Real-time status display shows critical data at a glance, including unique microphone
ID, Room ID, and remaining battery life.
Powered by a 3.7V / 1450mAh rechargeable Li-ion battery that delivers up to 8 hours of
continuous operation on a full charge.
Features a dedicated headphone output jack, a convenient Type-C charging port, and
individual volume adjustment buttons.
Does not include a microphone stem out of the box.

3

2

DELEGATE UNIT
Power/TALK Button.
LCD: Displays the Delegate Unit No. and battery charge status. Microphone Indicator
Ring LED.
Power Supply: 2 pcs., AA, Alkaline Batteries. Built-in individual volume adjustment
buttons let participants fine-tune their voice pick-up levels right from the desk
Accompanied by a smart LED indicator ring on the compatible microphone heads to
visibly show when the channel is live.
The unit features an automatic power-down mechanism that shuts off the delegate mic
when the main host receiver is turned off, conserving battery life
For a functional boardroom setup, the delegate unit communicates wirelessly with the
Model Host Unit and is moderated by the Model Chairman Unit, which features priority
muting over all active delegates.

20

3

SHOTGUN MICROPHONE , For use with Chairman Unit DCW-8501C and Delegate Unit
DCW-8502D.
SGM-40 Shotgun Mic 225 mm (8.80"). Easy to connect. A modern, low-profile
alternative to traditional, flexible gooseneck microphones.
super-cardioid shotgun capsule creates a tight pickup zone directly in front of the
speaker, aggressively rejecting side-axis ambient room echo or neighboring delegate
voices.
The short, 225 mm rigid body sits below eye level, ensuring the speaker’s face remains
unobstructed on camera tracking systems and video screens
Weighing 190g with a metal build and a screw-on interlock connection, it provides a
stable and premium table-top aesthetic for corporate boardrooms.

23

Page 13 of 50

<!-- page 14 -->

4

HOST UNIT
Carrier Frequency 2.4GHz (2400-2483MHz) Adaptive Digital FHSS Technology.
Operating Range upto 40 meters.Frequency Response 70-15,000Hz.
Power Supply: 12V DC from AC Adapter.
Host unit should be used together CWS-8100C Chairman Unit, CWS-8200D Delegate
Units and GN -45 Gooseneck Microphones. It serves as the master receiver unit. It
must be paired with compatible Chairman Units and Delegate Units to form a complete
working system.
The overall DCW-8500 system architecture is scalable and can support up to 255
wireless delegate units.
Offers multiple managed speech modes including LIMIT (caps the number of open
active microphones) and FIFO (First-In, First-Out, where newer speakers queue out
older ones)
Features multi-color display data (showing operation modes, battery status, room IDs)
and supports PC connectivity for DSP software management. The host unit must be
connected to an external power amplifier and passive speakers to deliver room-wide
sound.
Formatted as a standard 19-inch (482.6mm) rack-mountable chassis for easy
commercial integration into A/V server racks.

1

5

Sleek, Low-Profile On-Wall Loudspeaker, Transducers: 120 mm (4.5 in) polypropylene
cone woofer and
0.79 in titanium dome tweeter
Power handling: 50W continuous pink noise, 100W continuous program
15° down-tilted coverage allows flush-to-wall mounting,Transformer Taps-100V: 25 W,
12.5 W, 6.3 W

6

6

6 Mic & 2 Aux Inputs. With Built-in MP3 player.
Bluetooth facility.
Preamplifier and Line Output for connecting to a Booster
Amplifier and for recording the programme.
Line Input for connecting the output from any external
PA Mixer or another Amplifier.POWER OUTPUT -300W Max., 250W RMS at 10% THD ,
SPEAKER OUTPUT -4Ω, 8Ω, 70V & 100V

1

7

2×2 USB Audio Interface, Studio Quality(16Bit/48kHz) Digital Recording.
Features two inputs (Mic/Line & Instrument Level) and
two outputs.
Extreme low-Latency digital streaming.
Switchable Phantom power.
Supports Windows/Android & Mac iOS.
Compatible with popular DAW softwares.
USB 2.0 Bus-powered.
Compact durable Aluminum body.

1

Page 14 of 50

<!-- page 15 -->

8

Dual Handheld UHF Wireless Microphone System,Up to 200 Selectable Frequencies
Frequency Response - 50Hz-15kHz
Polar Pattern Cardioid - Output
Balanced XLR and Unbalanced ¼" Jack
Power Req. (Hand mic)2 x 1.5V AA
Power Req. (Receiver)
12VDC Adapter, 240V AC 50Hz

1

9

FHD Pro 12X camera designed for
remote video conferences,with HD CMOS image sensors,
offering a video resolution of 1080P60fps. With a wide
FoV long zoom lens paired with a PTZ.Utilizing a 1/2.8-inch, 2.07 million pixels HD
CMOS sensor, delivering superior image quality
with a maximum resolution of 1920x1080.Supports control through RS232 (optional
RS485)
serial ports, network, and USB interfaces,
meeting various application needs.Focal Length f3.5mm~42.3mm, F1.8~F2.8,Video
Format
YUY2: Max. 1080P60；H.264 AVC: Max. 1080P60；MJPEG: Max. 1080P60；H.264
SVC（Optional）: Max.1080P60Frame Rate 50Hz: 1fps ~ 50fps, 60Hz: 1fps ~60fps

1

10

4K60Hz 1x4 HDMI Splitter | 4K60Hz 4:4:4 | Dolby Vision & HDR | 4k > 1080p DownScaler

1

11

HDMI CABLE-2.1V

2

12

HDMI CABLE-2.0V

2

13

PHONO TO PHONO CABLE

3

14

INTERFACE CABLE-5 MTRS

1

15

1.5 SQ MM, 2 CORE SPEAKER CABLE

100

16

17U RACK

1

17

INSTALLATION CHARGES OF TOTAL SETUP

1

18

Wireless AV Presenter INTERFACE Receiver Button OPERATING SYSTEM
COMPATIBILITY HDMI Type A / USB 3.0 / USB 2.0 / 3.5mm Audio / RJ-45 USB Type A
Windows Mac OS MOBILE PLATFORM COMPATIBILITY Windows7/Windows 8/ Windows
8.1/ Windows 10 Mac OSX 10.6/10.7/10.8/10.9 Android iOS WIRELESS TRANSMISSION
Android 5.0 and above iOS 9.0 and above Protocols Transmission Bandwidth
Transmission Distance Number of Users Resolutions ENVIRONMENTAL 802.11 b/g/n,
Airplay and Custom Protocols 300 Mbps 40m 30 1024*768 to 1920*1080 Temperature
Range Humidity Range ELECTRICAL & PHYSICAL Operating: +5° C to +45° C Storage:
-20° C to +60° C Operating: 0 to 85% Relative Humidity, No Condensation Storage: 0
to 90% Relative Humidity, No Condensation

1

19

Physical

Inch
Resolution

65
3840 x 2160 (UHD)

3

Page 15 of 50

<!-- page 16 -->

Video

Audio

Refresh Rate

60 Hz

HDR_HDR 10 Pro

Yes

Game Optimizer

Yes

Audio Output

10W + 10 W

AI Sound

Yes

Dolby Atmos

Yes

AI Accoustic Tuning

Yes

BT Sound Sync

Yes

Processor

Smart Function

Connectivity

Ports

Dimension &
Weight

a7 Gen8 AI Processor
4K

Home Dashboard

Yes

Web Browser

Yes

Pre-Loaded App

Yes

Magic Remote Compatibility

Yes

Free Chennels (India)

Yes

HDMI eARC

Yes

WiFi

Yes

Screen Share ( Miracast)

Yes

Air Play

Yes

Bluetooth

Yes

Google Assistance

Yes

Amazon Alexa

Yes

ThinQ AI

Yes

Voice Recognition ( Standerd)

Yes

HDMI In

3

RF In

Yes

USB

yes

RJ45

Yes

Dimension with Stand (W x H x D)

1455 x 904 x 269
mm

Page 16 of 50

<!-- page 17 -->

Dimension without Stand (W x H x D)

1455 x 841 x 67.9
mm

Dimension in Shipping (W x H x D)

1580 x 950 x 162
mm

Weight Without Packing/Without Stand
Power ( Unit:
Watts)

Power Supply (Volt, Hz)
Stand-by

Warranty

PANEL
20

Connectivity

AC 100~240V, 50/60
Hz
Under 0.5 W

Certification
Accessory

16.5Kg

BIS
Remote Type

Magic Remote

Power Cable

Yes ( 1.5M)

3 years

On-site
Screen Size (Inch)

98"

Panel Technology

ADS

Back Light Type

Direct

Aspect Ratio

16:9

Native Resolution

3840 x 2160 (UHD)

Refresh Rate

60Hz

Brightness

500nit (Typ.)

Contrast Ratio

1,200:1

Dynamic CR

200,000:1

Color Gamut

DCI-P3 88%↑

Viewing Angle (H x V)

178 X 178

Color Depth (Number of Colors)

8bit + FRC,
1.07Billion colors

Response Time

8ms (G to G)

Surface Treatment (Haze)

25%

Life time

30,000(Typ.)

Operation Hours (Hours/Day)

16/7

Portait / Landscape

Yes / Yes

HDMI In

3, HDMI1/HDMI2 :
HDCP 2.2/1.4

1

Page 17 of 50

<!-- page 18 -->

(Jack Interface)

Mechanical

HW Feature

SW Feature

HDMI3 : HDCP 1.4
DP In

1, HDCP2.2/1.3

DVI-D In

1, HDCP1.4

Audio In

Yes

RS232C In

Yes, 4pin Phone-jack

RJ45(LAN) In

Yes

IR In

yes

USB In

USB2.0 Type A(1)

HDMI Out

Yes

Audio Out

Yes

RS232C Out

Yes, 4pin Phone-jack

Daisy Chain

Yes(Input HDMI, DP,
DVI / Output HDMI)

Bezel Color

Black

Bezel Width

Even bezel : 17mm

Weight (Head)

78Kg

Packed Weight

105Kg

Monitor Dimensions (W x H x D)

2198 x 1253 x
79.5mm

Carton Dimensions (W x H x D)

2455 x 1458 x
288mm

Handle

Yes

VESATM Standard Mount Interface

800 x 400 or 800 x
800

Internal Memory (eMMC)

16GB

Wi-Fi/BT (Built-in)

Yes

Temperature Sensor

Yes

Auto Brightness Sensor

Yes

Acceleration(Gyro) Sensor

Yes

Local Key Operation

Yes

Local Contents Scheduling

Yes

Page 18 of 50

<!-- page 19 -->

Group Manager

Yes

USB Plug & Play

Yes

Fail over

Yes

Booting Logo Image

Yes

No Signal Image

Yes

RS232C Sync

Yes

Local Network Sync

Yes

PIP

Yes

PBP

Yes, (4)

Screen Share

Yes

Video Tag

Yes,(4)

Play via URL

Yes

Screen Rotation

Yes

External Input Rotation

Yes

Gapless Playback

Yes

Tile Mode Setting

Yes, (Max. 15x15)

Setting Data Cloning

Yes

SNMP

Yes

ISM Method

Yes

Auto Set ID

Yes

Status Mailing

Yes

Control Manager

Yes

Crestron Connected

Yes

Smart Energy Saving

Yes

PM mode

Yes

Wake on LAN

Yes

Network Ready

Yes

Beacon

Yes

HDMI-CEC

Yes

Page 19 of 50

<!-- page 20 -->

Environment
Conditions

Power

Power
Consumption

SOUND

CERTIFICATION

Warranty

SI Server Setting

Yes

webRTC

Yes

Pro:Idiom

Yes

Operation Temperature

0 °C to 40 °C

Operation Humidity

10 % to 80 %

Power Supply

AC 100-240V~,
50/60Hz

Power Type

Built-In Power

Typ.

430

Max.

560

BTU (British Thermal Unit)

1467 BTU/Hr(Typ.),
1911 BTU/Hr(Max)

Smart Enegy Saving (70%)

301W

DPM

0.5W

Power off

0.5W

Speaker (Built-in)

10W X 2

Safety

CB / NRTL

EMC

FCC Class "A" / CE /
KC

2 years

On-site

Page 20 of 50

<!-- page 21 -->

SECTION – IV
GENERAL TERMS & CONDITIONS
4.1 Award of Contract
The contract shall be awarded to the bidder whose bid is found to be substantially responsive, technically
qualified, and who has quoted the Lowest Evaluated Total Price (L1) for the complete scope of work.
OLM reserves the right to negotiate with the successful bidder, wherever considered necessary, in
accordance with the prevailing Government procurement guidelines.
4.2 Letter of Award (LoA)
The successful bidder shall be issued a Letter of Award (LoA) by Odisha Livelihoods Mission.
The bidder shall acknowledge the acceptance of the Letter of Award within seven (7) days from the date
of its receipt.
Failure to accept the LoA within the stipulated period may result in cancellation of the award and forfeiture
of the Earnest Money Deposit (EMD).
4.3 Execution of Agreement
The successful bidder shall execute a formal Agreement with Odisha Livelihoods Mission on Non-Judicial
Stamp Paper of appropriate value within 15 days from the date of issue of the Letter of Award.
The Agreement shall remain valid till completion of the contract including the warranty obligations.
4.4 Performance Security
The successful bidder shall furnish a Performance Security equal to 3% of the Contract Value in the
form of Bank Guarantee/Demand Draft/Fixed Deposit Receipt in favour of "Odisha Livelihoods Mission
NRLM EFMS".
The Performance Security shall be submitted within 15 days from the date of issue of the Letter of Award.
Failure to submit the Performance Security shall result in cancellation of the award and forfeiture of the
Earnest Money Deposit.
The Performance Security shall be released after successful completion of the contract and warranty
period, subject to satisfactory performance.
4.5 Completion Schedule
The successful bidder shall complete the entire scope of work within 28 (twenty-eight) days from the date
of issue of the Letter of Award (LoA), as per the following schedule:
A. Within 21 days: Site Survey, System Design, Supply of Equipment, Installation and Integration.
B. Within the subsequent 7 days: Testing, Commissioning, User Training and Final Acceptance.
Accordingly, the complete system shall be installed, integrated, tested, commissioned, training completed
and finally accepted within 28 days from the date of issue of the LoA

Page 21 of 50

<!-- page 22 -->

4.6 Inspection
OLM reserves the right to inspect all materials and equipment supplied under the contract.
Inspection may be carried out:
•

During Delivery

•

During Installation

•

During Commissioning

•

After Completion

Any equipment found defective, damaged or not conforming to the specifications shall be replaced by the
successful bidder at no additional cost.
4.7 Acceptance Test
After completion of installation, the bidder shall conduct a comprehensive Acceptance Test in the presence
of OLM officials.
The Acceptance Test shall include:
•

Physical Verification

•

Functional Testing

•

Audio Performance Test

•

Video Performance Test

•

Microphone Test

•

Camera Test

•

Display Test

•

User Demonstration

Only after satisfactory completion of all tests shall the Final Acceptance Certificate be issued.
4.8 Payment Terms
Payment shall be released in the following manner:
Milestone
Payment
After successful supply of all equipment at
75%
site
After successful installation, testing,
15%
commissioning and integration
After final acceptance, submission of
documentation and completion of user
10%
training
The following documents shall be submitted for release of payment:
•

Tax Invoice

•

Delivery Challan

•

Installation Certificate & Warranty Certificate

•

Training Completion Report
Page 22 of 50

<!-- page 23 -->

Applicable statutory deductions shall be made as per Government rules.
4.9 Warranty
The successful bidder shall provide Comprehensive On-site Warranty for a minimum period of Two
(2) Years from the date of issue of the Final Acceptance Certificate.
The warranty shall include:
•

Labour Charges

•

Spare Parts

•

Firmware Updates

•

Software Updates

•

Technical Support

•

Corrective Maintenance

•

Replacement of defective parts

•

Transportation Charges

No additional payment shall be made by OLM during the warranty period.
4.10 Service Level Agreement (SLA)
The bidder shall ensure the following service standards during the warranty period:
Particular
Complaint Registration
Response Time
Fault Rectification
Replacement of Major Equipment
Preventive Maintenance

Requirement
24 × 7
Within 24 Hours
Within 48 Hours
Within 14 Days
Once Every Year

If any equipment cannot be repaired within the stipulated period, the bidder shall provide an equivalent or
higher specification standby unit until the defective equipment is repaired or replaced.
4.12 Penalty for Delay
If the successful bidder fails to complete the work within the stipulated period, Liquidated Damages (LD)
shall be imposed at the rate of 0.5% of the Contract Value per week or part thereof, subject to a
maximum of 3% of the total Contract Value.
If the delay exceeds the maximum permissible period or the penalty reaches 3% of the Contract Value,
OLM reserves the right to terminate the contract and forfeit the Performance Security.

4.13 Replacement of Defective Equipment
Any equipment found defective during installation, commissioning or warranty period shall be replaced with
a new unit of the same or higher specification within 14 days from the date of notification by OLM.
Refurbished or repaired equipment shall not be accepted as replacement.

Page 23 of 50

<!-- page 24 -->

4.14 Insurance
The successful bidder shall be responsible for transit insurance and insurance of all supplied equipment
until the Final Acceptance Certificate is issued by OLM.
Any damage occurring during transportation, storage or installation shall be rectified by the bidder at its
own cost.
4.15 Safety Requirements
The successful bidder shall comply with all applicable safety standards while executing the work.
The bidder shall provide all necessary Personal Protective Equipment (PPE) to its personnel.
The bidder shall be solely responsible for any accident, injury or damage occurring during execution of the
work.
4.16 Quality Assurance
All equipment supplied under this contract shall:
•

Be brand new.

•

Be unused.

•

Be free from manufacturing defects.

•

Be sourced from Original Equipment Manufacturers (OEMs).

•

Conform to applicable BIS/IEC/ISO standards.

•

Be supplied with original accessories.

Refurbished, repaired or second-hand equipment shall not be accepted.
4.17 Force Majeure
Neither party shall be liable for failure or delay in performing its obligations if such failure or delay is
caused by events beyond its reasonable control, including but not limited to:
•

Natural Calamities

•

Flood

•

Earthquake

•

Cyclone

•

Fire

•

Pandemic

•

Epidemic

•

War

•

Riot

•

Civil Disturbance

•

Government Restrictions

Page 24 of 50

<!-- page 25 -->

The affected party shall notify the other party in writing within seven (7) days of occurrence of such
event.
4.18 Termination of Contract
OLM may terminate the contract by giving written notice if the successful bidder:
•

Fails to perform contractual obligations.

•

Abandons the work.

•

Becomes insolvent or bankrupt.

•

Submits false information.

•

Is blacklisted by any Government Department.

•

Fails to maintain the required Service Levels.

•

Breaches any material condition of the contract.

Upon termination, OLM may engage another agency to complete the work at the risk and cost of the
defaulting bidder.
4.19 Confidentiality
The successful bidder shall maintain strict confidentiality regarding all information, documents, drawings,
software, data and records received from OLM.
No information shall be disclosed to any third party without prior written approval of OLM.
This obligation shall survive even after completion of the contract.
4.20 Intellectual Property Rights
All drawings, reports, designs, layouts, configurations, documentation and deliverables prepared under this
contract shall become the exclusive property of Odisha Livelihoods Mission.
The bidder shall not claim any ownership or copyright over such documents.
4.21 Sub-contracting
The successful bidder shall not assign or sub-contract the whole or any part of the work without prior
written approval of OLM.
Any unauthorized sub-contracting shall be treated as a breach of contract.
4.22 Taxes & Duties
The bidder shall quote prices inclusive of all applicable taxes, duties, freight, insurance, loading, unloading,
installation and commissioning charges.
Any statutory variation in GST during the contract period shall be governed by the applicable Government
rules.
4.23 Applicable Law
This Tender and the resulting Contract shall be governed by the laws of India and the Government of
Odisha.

Page 25 of 50

<!-- page 26 -->

4.24 Settlement of Disputes
The parties shall make every effort to resolve disputes amicably through mutual consultation.
If the dispute remains unresolved, the matter shall be referred to the State Mission Director-cum-CEO,
OLM, for resolution.
If the dispute still persists, it shall be subject to the exclusive jurisdiction of the competent Courts at
Bhubaneswar, Odisha.
4.25 Right to Accept or Reject
Odisha Livelihoods Mission reserves the right to:
•

Accept or reject any bid.

•

Reject all bids.

•

Cancel the tender process.

•

Modify the scope of work.

•

Reduce or increase the quantity of items.

•

Annul the procurement process at any stage without assigning any reason and without incurring
any liability to the bidders.

Page 26 of 50

<!-- page 27 -->

SECTION – V
TECHNICAL BID SUBMISSION FORMS
TECH – 1
COVERING LETTER

(On the Letter Head of the Bidder)
Date: ___________
To
The State Mission Director-cum-CEO
Odisha Livelihoods Mission
Department of Mission Shakti
SIRD & PR Campus
Unit-VIII, Bhubaneswar – 751012
Subject:
Submission of Technical Bid for Supply, Installation, Testing, Commissioning, Integration and
Comprehensive Warranty Support of Digital Conference Audio-Visual & Display System at the
Conference Hall of SMMU, Odisha Livelihoods Mission, Bhubaneswar.
Reference:
Tender No. _____________ Dated _____________
Madam,
Having examined the Tender Document, we, the undersigned, hereby submit our Technical Bid for the
above-mentioned work.
We certify that:
1.
2.
3.
4.

We have carefully read and understood all the terms and conditions of the Tender Document.
We agree to execute the work strictly in accordance with the Tender conditions.
We agree to keep our bid valid for 180 days.
We have not been blacklisted by any Central Government, State Government, PSU or Autonomous
Body.
5. All information furnished in this proposal is true and correct.
6. We understand that Odisha Livelihoods Mission reserves the right to reject any or all bids without
assigning any reason.
Authorized Person Details
Name
Designation
Mobile
Email
Address
For and on behalf of
(Name of Bidder)
Authorized Signatory
Seal

Page 27 of 50

<!-- page 28 -->

TECH – 2
BIDDER'S GENERAL INFORMATION
Particular

Details

Name of Bidder
Registered Office
Correspondence Address
Telephone
Mobile
Email
Website
Type of Organization
Year of Establishment
PAN
GSTIN
Registration Number
MSME Registration (if
applicable)
Authorized Signatory
Designation
Contact Number
Email Id

Page 28 of 50

<!-- page 29 -->

TECH – 3
FINANCIAL INFORMATION
(To be certified by Chartered Accountant)
Financial Year

Annual Turnover (₹)

2022–23
2023–24
2024–25

Average Annual Turnover
₹ ___________________
Certified that the above information is true and based on audited financial statements.
Chartered Accountant
Name
Membership Number
UDIN
Seal
Signature

Page 29 of 50

<!-- page 30 -->

TECH – 4
EXPERIENCE OF THE BIDDER
Works Executed
Sl

Name of Client

Nature of
Work

Contract
Value (₹)

Completion
Date

Completion
Certificate
Attached

Attach
•

Work Order/Completion Certificate

Page 30 of 50

<!-- page 31 -->

TECH – 5
MANUFACTURER'S / OEM AUTHORISATION FORM

(To be submitted on the Original Letter Head of the Manufacturer / OEM)
Tender No.: _________________________
Date: _______________________________
To
The State Mission Director-cum-CEO
Odisha Livelihoods Mission (OLM)
State Mission Management Unit (SMMU)
Bhubaneswar – Odisha
Subject:
Manufacturer's Authorization for Supply, Installation, Testing, Commissioning and Warranty
Support of Digital Conference Audio-Visual & Display System
Dear Sir,
We, M/s. __________________________________________, having our registered office at
____________________________________________, are the Original Equipment Manufacturer (OEM) of
the products mentioned below.
We hereby authorize M/s. ____________________________________________
to submit bid against the above tender and, if awarded, to supply, install, commission, integrate and
provide comprehensive warranty support for our products.
We further certify that:
1. The above products are genuine OEM products.
2. Spare parts shall be available for a minimum period of five (5) years from the date of installation.
3. The products are not End-of-Life (EOL) or End-of-Support (EOS).
4. We shall honour the warranty obligations through the authorized bidder.
5. Necessary technical support shall be extended during installation, commissioning and warranty
period.
For and on behalf of (OEM Name)
Authorized Signatory
Name :
Designation :
Seal
Date :
Attach Manufacturer Authorization Letters.
Page 31 of 50

<!-- page 32 -->

TECH – 6
DECLARATION OF TECHNICAL COMPLIANCE

(To be submitted on Bidder's Letter Head)
Tender No. _______________________
Date _____________________________
To
The Chief Executive Officer
Odisha Livelihoods Mission
Bhubaneswar
Subject: Declaration of Compliance to Technical Specifications
Sir,
We hereby declare that all equipment proposed by us against this Tender fully complies with the Technical
Specifications prescribed in Section-III of the Tender Document.
We further certify that:
1.
2.
3.
4.
5.
6.
7.
8.
9.

All products offered are brand new and unused.
All equipment shall be supplied from the respective OEM.
All products conform to internationally accepted quality standards.
All accessories required for successful installation and operation have been included in our offer.
No refurbished, obsolete or discontinued products have been offered.
The offered equipment shall fully support interoperability and seamless integration.
We have enclosed complete OEM technical literature, brochures and datasheets.
We agree to provide demonstration of the offered equipment whenever required by OLM.
We agree to replace any equipment found non-compliant during inspection or acceptance testing
without any additional cost.
10. We accept all terms and conditions mentioned in the Tender Document.
We understand that any false declaration shall render our bid liable for rejection.

Authorized Signatory
Name
Designation
Seal of Bidder
Date

Page 32 of 50

<!-- page 33 -->

TECH – 7
LIST OF PROPOSED EQUIPMENT

(To be submitted on Bidder's Letter Head)
Tender No. _____________________
Bidder Name ____________________
Schedule of Offered Equipment
Sl.
No.

Equipment

Qty.

1

Wireless Chairman Unit

3

2

Wireless Delegate Unit

20

3

Shotgun Microphone

23

4

Wireless Conference Host
Unit

1

5

Wall Mounted Speaker

6

6

Mixer Power Amplifier

1

7

USB Audio Interface

1

8

Dual Wireless Handheld
Microphone

1

9

PTZ Camera

1

10

Wireless Presentation
System

1

11

Commercial Display – 98"

1

12

Commercial Display – 65"

3

13

17U Equipment Rack

1

14

HDMI Splitter

1

15

HDMI 2.1 Cable

2

16

HDMI 2.0 Cable

2

17

Phono Cable

3

18

Interface Cable

1

19

Speaker Cable

100
Metres

20

Installation, Integration &
Commissioning

1 Lot

Offered
Make

Offered
Model

Country of
Origin

Warranty

N.A.

N.A.

India

2 Years

Page 33 of 50

<!-- page 34 -->

Declaration
We certify that:
•

The above information is true and correct.

•

All equipment offered conforms to the Technical Specifications.

•

OEM authorization and product datasheets have been enclosed.

•

The quoted models shall remain unchanged during execution of the contract unless approved in
writing by OLM.

•

We shall supply all accessories, connectors, mounting hardware, software (if any), licences, cables
and consumables required for successful installation and commissioning of the complete system
without any additional financial implication to OLM.

Authorized Signatory
Name:
Designation:
Seal of Bidder
Date:

Page 34 of 50

<!-- page 35 -->

TECH – 8
PROJECT IMPLEMENTATION SCHEDULE

Activity

Duration

Site Survey
System Design
Supply
Installation
Programming
Integration
Testing
Commissioning
Training
Documentation
Final Handover

Total Completion Period:28 Days

Authorized Signatory
Seal

Page 35 of 50

<!-- page 36 -->

TECH – 9
WARRANTY, MAINTENANCE & SERVICE LEVEL COMMITMENT

(To be submitted on the Bidder's Letter Head)
Tender Details
Tender No.: ___________________________
Name of Work: Supply, Installation, Testing, Commissioning, Integration and Comprehensive Warranty
Support of Digital Conference Audio-Visual & Display System at State Mission Management Unit (SMMU),
Odisha Livelihoods Mission, Bhubaneswar.
Declaration
We, M/s. ____________________________________________, hereby undertake and commit
that, in the event of award of the above work, we shall provide comprehensive warranty,maintenance and
technical support services in accordance with the Tender Conditions.
1. Comprehensive Warranty Commitment
We hereby certify that:
1. All equipment supplied under this contract shall be brand new, unused and free from manufacturing
defects.
2. The complete Audio-Visual Conference System shall be covered under a Comprehensive On-site
Warranty for a period of two (02) Years from the date of successful installation, testing,
commissioning and acceptance by Odisha Livelihoods Mission.
3. Comprehensive Warranty shall include, but not be limited to:
Repair of defective equipment.
• Replacement of defective components.
• Replacement of defective accessories.
• Firmware upgrades.
• Software updates (where applicable).
• Configuration support.
• Calibration.
• Labour charges.
• Travelling expenses.
• Transportation charges.
• Installation charges for replacement items.
No additional financial liability shall accrue to OLM during the warranty period.
•

2. Preventive Maintenance Commitment
We undertake to carry out Preventive Maintenance of the complete system during the warranty period.
The preventive maintenance shall include:
•

Physical inspection of all equipment.

•

Cleaning of equipment.

•

Inspection of wiring and connectors.
Page 36 of 50

<!-- page 37 -->

•

Tightening of loose connections.

•

Audio level calibration.

•

Video calibration.

•

Functional testing.

•

Battery health verification.

•

Firmware update.

•

Software update (where applicable).

•

Performance verification.

Maintenance Schedule
Activity

Frequency

Preventive Maintenance Visit Once every Year
System Health Check

Yearly

Battery Inspection

Yearly

Firmware Update

As released by OEM

Calibration

Yearly

Performance Verification

Yearly

Minimum One (01) Preventive Maintenance Visits shall be carried out every year.
3. Breakdown Maintenance
The bidder shall provide unlimited breakdown maintenance during the warranty period.
The bidder shall attend all complaints reported by OLM without any limitation on the number of service
calls.
4. Service Level Agreement (SLA)
The bidder agrees to maintain the following minimum Service Levels.
Particular
Complaint Registration
Response Time
Fault Rectification
Replacement of Major Equipment
Preventive Maintenance

Requirement
24 × 7
Within 24 Hours
Within 48 Hours
Within 14 Days
Once Every Year

5. Standby Arrangement
If any equipment cannot be repaired within the stipulated time, the bidder shall provide an equivalent or
higher specification standby equipment at no additional cost until the defective equipment is repaired or
replaced.

Page 37 of 50

<!-- page 38 -->

6. Availability of Spare Parts
The bidder undertakes that genuine OEM spare parts shall remain available throughout the warranty
period.
Only OEM-approved spare parts shall be used.
7. Software/Firmware Support
The bidder shall provide:
•

Firmware upgrades.

•

Security updates.

•

Configuration support.

•

Bug fixes.

•

Compatibility updates.

during the entire warranty period without any additional cost.
8. Technical Support
The bidder shall provide technical support through:
•

Telephone

•

E-mail

•

Remote Assistance

•

On-site Engineer

whenever required by OLM.
9. Service Log Book
The bidder shall maintain a Service Log Book containing:
•

Complaint Number

•

Date & Time of Complaint

•

Engineer Name

•

Fault Description

•

Action Taken

•

Parts Replaced

•

Date of Restoration

•

Signature of OLM Representative

The Service Log Book shall be submitted to OLM after every preventive maintenance visit and service call.
10. Training Support
Page 38 of 50

<!-- page 39 -->

The bidder shall provide on-site operational training to the designated officials of OLM covering:
•

System operation.

•

Conference management.

•

Display operation.

•

PTZ camera operation.

•

Wireless presentation.

•

Routine troubleshooting.

•

Basic maintenance.

Training shall be conducted after successful commissioning of the system.
11. Warranty Exclusions
The warranty shall not cover damage arising from:
•

Natural calamities.

•

Fire.

•

Flood.

•

Earthquake.

•

Lightning.

•

Riot.

•

Intentional misuse.

•

Unauthorized modification by persons other than the bidder or OEM-authorized personnel.

Normal wear and tear of consumable items shall be governed by the respective OEM warranty policy.
12. Penalty for non-performance
Failure to meet the Service Level commitments may attract action as per the terms and conditions of the
Contract, including imposition of liquidated damages, recovery of costs incurred by OLM for arranging
alternative services, or any other contractual remedies available under the agreement.

Page 39 of 50

<!-- page 40 -->

TECH – 10
UNDERTAKING

I/We hereby certify that:
•

The information furnished in this Tender is true and correct.

•

No material information has been concealed.

•

We agree to abide by all the terms and conditions of the Tender.

•

We understand that any false declaration shall result in rejection of our bid.

•

We accept that the decision of Odisha Livelihoods Mission shall be final and binding.

Name of Bidder
Authorized Signatory
Date
Seal

Page 40 of 50

<!-- page 41 -->

SECTION – VI
FINANCIAL BID-1

(To be submitted in a Separate Sealed Envelope)
Name of Work: Supply, Installation, Testing, Commissioning, Integration and Comprehensive Warranty
Support of Digital Conference Audio-Visual & Display System at the Conference Hall of State Mission
Management Unit (SMMU), Odisha Livelihoods Mission, Bhubaneswar.
SCHEDULE OF PRICES

Sl.
No.

Description of Item

Unit

Qty. Unit
Rate
(₹)

1

Wireless Chairman Discussion Unit (Complete with
Rechargeable Battery & Charging Accessories)

No.

3

2

Wireless Delegate Discussion Unit (Complete with
Rechargeable Battery & Charging Accessories)

No.

20

3

Shotgun Microphone (Compatible with Chairman &
Delegate Units)

No.

23

4

Wireless Conference Host Unit

No.

1

5

Wall Mounted Speaker

No.

6

6

Mixer Power Amplifier (300 Watt RMS or Higher)

No.

1

7

USB Audio Interface

No.

1

8

Dual Handheld UHF Wireless Microphone System

Set

1

9

Full HD PTZ Camera (12X Optical Zoom or Higher)

No.

1

10

HDMI Splitter (4K UHD)

No.

1

11

Wireless Presentation System

No.

1

12

Commercial Display – 98 Inch UHD

No.

1

13

Commercial Display – 65 Inch UHD

No.

3

14

AV Equipment Rack (17U Floor Standing)

No.

1

15

HDMI 2.1 Cable

No.

2

16

HDMI 2.0 Cable

No.

2

17

Phono Cable

No.

3

18

Interface Cable (5 Metres)

No.

1

19

Speaker Cable (2 Core, 1.5 Sq.mm)

Metre 200

Total Amount
Including GST
(₹)

Page 41 of 50

<!-- page 42 -->

20

Complete Installation, Testing, Commissioning,
Programming, Integration, Calibration,
Documentation & User Training

Lot

1

Notes
1. Financial Bids of only technically qualified bidders shall be opened.
2. The contract shall ordinarily be awarded to the Lowest Evaluated Responsive Bidder (L1).
3. Any arithmetical error shall be corrected by OLM during evaluation. In case of discrepancy between
unit rate and total amount, the unit rate shall prevail, and the total shall be corrected accordingly.
4. In case of a tie in the evaluated price, the bidder with the higher average annual turnover during
the last three financial years shall be considered the preferred bidder.

Authorized Signatory
Name:
Designation:
Company Seal:
Date:

Page 42 of 50

<!-- page 43 -->

FINANCIAL BID-2
Price Declaration
We hereby certify that:
1. The quoted prices are inclusive of:
•
•
•
•
•
•
•
•
•
•
•
•
•

Supply of all equipment
Freight, Insurance, Loading & Unloading
Installation & Commissioning
Programming & System Integration
Calibration & Testing
Mounting Hardware
Interconnecting Cables & Connectors
Accessories
Documentation
User Training
Comprehensive On-site Warranty for Two (2) Years
Maintenance during Warranty Period
All taxes and duties with GST.

2. No additional payment shall be claimed from Odisha Livelihoods Mission for any item required for
successful installation and operation of the complete system.
3. The quoted price shall remain firm throughout the contract period.
Notes for Bidders
1. The bidder shall quote against all items. Partial quotations shall not be accepted.
2. The quantities indicated are indicative. OLM reserves the right to increase or decrease the quantity
at the time of award.
3. Any item, accessory, mounting hardware, software licence, cable, connector, adaptor, power supply
or consumable required for successful installation and commissioning but not specifically mentioned
in the BOQ shall be deemed to be included in the quoted price.
4. The Grand Total Price (Including GST) shall be considered for financial evaluation and
determination of the Lowest Evaluated Bid (L1).
5. The bidder shall mention the Make and Model of each quoted item separately in the Technical Bid.

Authorized Signatory
Name:
Designation:
Company Seal:
Date:
Page 43 of 50

<!-- page 44 -->

SECTION –VII
ANNEXURES

ANNEXURE – A
BID SUBMISSION CHECKLIST

Name of Bidder : __________________________
Sl.
No.
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
18
19
20
21

Description

Submitted
(Yes/No)

Page No.

Covering Letter (TECH-1)
Bidder Information (TECH-2)
Financial Information (TECH-3)
Experience Details (TECH-4)
OEM Authorization (TECH-5)
Declaration of Compliance (TECH-6)
List of Proposed Equipment (TECH-7)
Project Schedule (TECH-8)
Warranty Support Details (TECH-9)
Undertaking (TECH-10)
Tender Processing Fee DD
EMD DD
Certificate of Incorporation
PAN
GST Registration
Audited Balance Sheets
Turnover Certificate
Experience Certificates
OEM Authorization Letters
Affidavit of Non-Blacklisting
No Deviation Certificate
Undertaking

Authorised Signatory

Seal

Page 44 of 50

<!-- page 45 -->

ANNEXURE – B
AFFIDAVIT
NON-BLACKLISTING CERTIFICATE
(To be executed on Non-Judicial Stamp Paper Rs 20)
I/We hereby declare that our organization has not been blacklisted, debarred or banned by any Central
Government, State Government, PSU, Autonomous Body or Statutory Authority as on the date of
submission of this Tender.
We further certify that no criminal proceedings involving fraud, corruption or financial irregularities are
pending against our organization.
If any information furnished above is found to be false, Odisha Livelihoods Mission shall have the right to
reject our bid and forfeit the EMD.

Date:
Authorized Signatory
Seal

Page 45 of 50

<!-- page 46 -->

ANNEXURE – C
NO DEVIATION CERTIFICATE

We hereby certify that all the specifications, terms and conditions mentioned in the Tender Document have
been fully accepted.
No deviation whatsoever has been taken.

Name of Bidder
Authorized Signatory
Seal

Page 46 of 50

<!-- page 47 -->

ANNEXURE – D
PERFORMANCE SECURITY FORMAT
(Bank Guarantee)
(To be issued by Scheduled Commercial Bank)

Whereas Odisha Livelihoods Mission has awarded the Contract to
M/s ____________________________
For Supply, Installation, Testing, Commissioning, Integration and Comprehensive Warranty Support of
Digital Conference Audio-Visual & Display System,
we hereby undertake to pay Odisha Livelihoods Mission any amount up to 3% of the Contract Value
without demur whenever demanded.
This guarantee shall remain valid until completion of the contract including warranty obligations.

Authorized Bank Signatory

Page 47 of 50

<!-- page 48 -->

ANNEXURE – E
INSTALLATION CERTIFICATE

Certified that Supply, Installation, Testing and Commissioning of the Digital Conference Audio Visual
System has been completed satisfactorily.

Representative of Bidder

Representative of OLM
Date

Page 48 of 50

<!-- page 49 -->

ANNEXURE – F
FORMAT OF AGREEMENT

This Agreement is executed on this _____ day of __________ 2026 between
Odisha Livelihoods Mission, Department of Mission Shakti, Government of Odisha
AND
M/s __________________________
for
Supply, Installation, Testing, Commissioning, Integration and Comprehensive Warranty Support of Digital
Conference Audio Visual & Display System.
The Agency agrees to execute the work in accordance with the Tender Document, Letter of Award and
terms of the Agreement.
The Contract shall remain valid until completion of all contractual obligations including the warranty period.
Signed on behalf of

Odisha Livelihoods Mission
and

Successful Bidder

Page 49 of 50

<!-- page 50 -->

ANNEXURE – G
FORMAT OF POWER OF ATTORNEY
Know all men by these presents that we,
M/s _______________________
hereby appoint
Shri/Smt _______________________
to act as our lawful Attorney for signing, submitting and representing us in connection with this Tender.

Authorized Signatory

Company Seal

Page 50 of 50
