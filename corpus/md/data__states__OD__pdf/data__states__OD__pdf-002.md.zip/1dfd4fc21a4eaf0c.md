---
doc_id: "1dfd4fc21a4eaf0c"
source_url: "https://www.opgc.co.in/OPGC_FINAL_PIM.pdf"
ministry: "Odisha Power Generation Corporation Ltd., Odisha"
title: "OPGC Disinvestment- Preliminary Information Memorandum"
date: ""
pages: 153
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6e5be31e08b52053"
---

<!-- page 1 -->

PRELIMINARY INFORMATION MEMORANDUM
&
Global Invitation for Expression of Interest
for
DISINVESTMENT OF 49% EQUITY STAKE OF
ODISHA POWER GENERATION CORPORATION LIMITED

by
DEPARTMENT OF ENERGY, GOVERNMENT OF ODISHA

(Strictly Private & Confidential)

Transaction Advisor

SBI Capital Markets Limited
Kolkata Office: 9th Floor, Jeevan Deep, 1, Middleton Street, Kolkata, West Bengal 700 071
Head Office: 202, Maker Tower ‘E’, Cuffe Parade, Mumbai 400 005
January,2023

<!-- page 2 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

Disclaimer Notice
SBI Capital Markets Limited (“SBICAP” or “Transaction Advisor” or “Advisor”) has been retained as
Advisor by Department of Energy, Govt of Odisha (“GOO”) for advising and managing the proposed
disinvestment of 49 per cent equity shareholding held by GOO in Odisha Power Generation Corporation
Limited (hereinafter referred to as "OPGC" or "the Company"), pursuant to work order dated December
27, 2022 and Tripartite Agreement dated January 9, 2023 (aforesaid proposed disinvestment hereinafter
referred to as the “Transaction”). The sole purpose of this Preliminary Information Memorandum
(hereinafter referred to as the "PIM") is to provide the recipient with limited and selected information
pertaining to the Company in deciding to submit an Expression of Interest (“EOI”) in respect of the
Transaction. Unless otherwise specified, the information contained herein is as of September 30, 2022 and
may be subject to material updates, revision or amendment at the sole discretion of GOO/OPGC, without
requirement of prior notices to the Bidders or any other person. Neither GOO/OPGC nor the Advisor,
undertake to update this PIM, and do not intend for this PIM to form the basis of an investment decision or
a decision to participate in the Transaction. Interested bidders are advised to conduct their own investigation
and analysis of OPGC in connection with a possible Transaction. This PIM is not intended to form the basis
for any investment decision.
The PIM may include certain estimates, projections, statements, targets and forecasts with respect to the
Plant/industry in which the Plant operates and these are based on the various assumptions made by the
Company. Actual results may differ materially from these forward-looking statements due to various factors.
You should note that past performance is not a guide for future performance of the Company. The summary
of financial information has been obtained from the audited annual financial statements (unless otherwise
specified) and may differ from the actual numbers to the extent of approximations or use of rounded numbers.
Unless stated otherwise the industry data has not been independently verified by SBICAP, the Company, the
GOO or any of their affiliates or advisors. The data used in these sources may have been reclassified by
SBICAP for the purposes of presentation. The GOO, the Company, SBICAP and their respective advisors
undertake no obligation to provide the recipient with access to any additional information or to update this
PIM with additional information or correct any inaccuracies herein, which may become apparent. SBICAP
has not independently verified any of the information and data contained herein. Neither GOO, the Company
nor SBICAP (nor any of their respective affiliates, subsidiaries, advisors, and agents), (i) make any
representations or warranties, express or implied, as to the accuracy, or completeness of such information
and data, (ii) take any responsibility for, or will accept any liability whether direct or indirect, express or
implied, contractual, tortuous, statutory or otherwise, in respect of, the accuracy, completeness, authenticity,
correctness and fairness of the information or for any of the opinions contained in the PIM or for any errors

2

<!-- page 3 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

or omissions or for any loss/damage be it tangible or intangible, howsoever arising, from the use of this

PIM and iii) take any responsibility or accept any liability for any other written or oral communications
transmitted to the recipient by or on behalf of Company or SBICAP or GOO or any of their advisors in
the course of your evaluation of any transaction involving the Company. Accordingly, neither GOO, the
Company, the Advisor nor any of their respective directors, officers, retainers, consultants, agents, employees
or advisers take any responsibility for, or will accept any liability whether direct or indirect, express or
implied, contractual, tortuous, statutory or otherwise, in respect of, the accuracy, completeness, authenticity,
correctness and fairness of the information or for any of the opinions contained in the PIM or for any errors
or omissions or for any loss/damage be it tangible or intangible, howsoever arising, from the use of this PIM
and therefore, any liability or responsibility of the GOO, Company and the Advisor is expressly disclaimed.
The views or opinions in this PIM have been expressed in good faith and are based on records/ information
available as of September 30, 2022 unless otherwise specified. Any liability arising out of or in connection
with this PIM, whether directly or indirectly, is hereby expressly disclaimed. Each interested bidder must
conduct its own analysis of the information contained in the PIM and is advised to carry out its own
investigation in relation to the Company and the Plant, and any and all matters pertinent to the Transaction
and to seek its own advice from professionals in relation to entering into any agreement or arrangement
relating to the Company. The interested bidder should rely on their own judgment only, in assessing business
conditions and prospects of the Company.
This PIM has been delivered to you for information purposes only, without any regard to specific objectives,
suitability, financial situations and needs of any particular person and does not constitute any
recommendation, and should not be construed as an offer or invitation for sale or the solicitation of an offer
to buy, purchase or subscribe to any securities, if any, mentioned therein, and neither this document nor
anything contained herein shall form the basis of or be relied upon in connection with any agreement,
arrangement, contract or commitment whatsoever. This document does not solicit any action based on the
materials contained herein and is made available upon the express understanding that you will use it only
for the purpose set forth above. The PIM is being made available on the understanding that the recipient
agrees to, and will, keep the PIM and any information contained herein or any written or oral information
made available separately in connection with the PIM confidential, and that the recipient shall, upon request
by SBICAP, promptly return, without retaining any copy thereof, all such materials (including this PIM)
as may be received from SBICAP and/or the Company.
All acts, deeds and things done or caused or intended to be done, by the Company and the Advisors hereunder
are based on and in reliance of your acceptance of the terms and conditions of this Disclaimer.

3

<!-- page 4 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

GOO, the Company and the Advisor undertake no obligation to provide the recipient with access to
additional information or to update this PIM or to correct inaccuracies herein. In no circumstances will the
Advisor be responsible for any costs, losses or expenses, etc. incurred in connection with any appraisal,
review or investigation in relation to the Transaction.
This PIM has been prepared by SBICAP based upon information available to the public and sources, believed
to be reliable. This document has not been approved and will or may not be reviewed or approved by any
statutory or any regulatory authority or any stock exchanges. This document may not be all inclusive and
may not contain all of the information that the recipient may consider material.
This document and information contained herein or any part of it does not constitute or purport to constitute
investment advice or recommendation that may be contained herein have not been based upon a
consideration of the investment objectives, financial situation or particular needs of any specific recipient
and should not be printed, reproduced, transmitted, sold, distributed or published by the recipient without
the prior written approval from SBICAP.
Neither GOO, the Company, the Advisor nor any of their respective affiliates, directors, employees, agents
or representatives shall be liable for any losses whether direct or indirect, incidental, special or consequential
including lost revenue or lost profits that may arise from or in connection with the use of this PIM. This
PIM may contain confidential, proprietary and/or legally privileged information and it must be kept
confidential by the recipient. Further, no representation or warranty, expressed or implied, is made or given
by or on behalf of the Company, the Advisors or their respective affiliates, nor any person who controls it or
any director, officer, employee, Advisor or agent of it, or affiliate of any such person or such persons as to
the accuracy, authenticity, completeness or fairness of the information or opinions contained in this
document and the Company, the Advisors and their respective affiliates and such persons do not accept any
responsibility or liability for any such information or opinions and therefore, any liability or responsibility
is expressly disclaimed. The logos and trademarks used in this document are owned by the respective owners
and are used for representation purpose only without any explicit permission of the owners.
This PIM is divided into chapters & sub-sections only for the purpose of reading convenience. Any partial
reading of this PIM may lead to inferences, which may be at divergence with the conclusions based on the
entirety of this PIM. Further, by accepting a copy of this PIM, the recipient accepts the terms of this Notice,
which forms an integral part of this PIM.
Note: Capitalized terms not defined shall have the same meaning ascribed to them in the Request for
Expression of Interest.

4

<!-- page 5 -->

Part A - Preliminary Information Memorandum

5

Odisha Power Generation Corporation Limited

<!-- page 6 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

TABLE OF CONTENTS

LIST OF TABLES ................................................................................................................................ 10
LIST OF FIGURES .............................................................................................................................. 11
PART A –PRELIMINARY INFORMATION MEMORANDUM ............................................... 14
1.

INTRODUCTION....................................................................................................................... 15

2.

COMPANY OVERVIEW ........................................................................................................... 17

3.

4.

2.1

Introduction...................................................................................................................... 17

2.2

Capital Structure of OPGC ............................................................................................. 17

2.3

Shareholding Pattern ...................................................................................................... 17

2.4

Board of Directors of OPGC ........................................................................................... 18

2.5

Financial Overview ......................................................................................................... 19

2.6

Group Overview .............................................................................................................. 20

DETAILS OF OPGC ................................................................................................................... 21
3.1

Plant Location and Connectivity ................................................................................... 21

3.2

Land Details ..................................................................................................................... 22

3.3

Details of OPGC Phase I (2x210 MW)........................................................................... 22

3.4

Details of OPGC Phase II (2x660 MW) ......................................................................... 25

3.5

Equipment Details ........................................................................................................... 28

3.6

Statutory Clearances ....................................................................................................... 29

3.7

Details of Operational Performance.............................................................................. 31

3.8

Human Resource Details ................................................................................................ 32

3.9

Future Expansion Plans .................................................................................................. 33

3.10

Other infrastructures....................................................................................................... 33

FINANCIAL PERFORMANCE OF OPGC ............................................................................. 35
4.1

Profit and Loss Statement (Standalone) ....................................................................... 35

4.2

Balance Sheet (Standalone) ............................................................................................ 36

6

<!-- page 7 -->

Part A - Preliminary Information Memorandum

5.

6.

7.

Odisha Power Generation Corporation Limited

4.3

Profit and Loss Statement (Consolidated) ................................................................... 39

4.4

Balance Sheet (Consolidated)......................................................................................... 40

ODISHA COAL AND POWER LTD – MINE DETAILS..................................................... 41
5.1

Background ...................................................................................................................... 41

5.2

Board of Directors of OCPL ........................................................................................... 42

5.3

Location & Accessibility ................................................................................................. 42

5.4

Area of the Project ........................................................................................................... 42

5.5

Mine Details of OCPL ..................................................................................................... 43

5.6

Mine Plan .......................................................................................................................... 43

5.7

Mine Area Break up ........................................................................................................ 44

5.8

Land Use Pattern ............................................................................................................. 45

5.9

Operational Performance Highlights ........................................................................... 45

5.10

Borrowing Details:........................................................................................................... 48

5.11

Mode of Dispatch ............................................................................................................ 48

5.12

Pending Resettlement & Rehabilitation (R&R) activities : ......................................... 48

5.13

List of Approvals and Clearances obtained ................................................................. 49

Value Drivers ............................................................................................................................... 52
6.1

Strengths .......................................................................................................................... 52

6.2

Opportunities .................................................................................................................. 53

Appendix ...................................................................................................................................... 54
7.1

Appendix I: Audited Financial Statement of OPGC & OCPL................................... 54

PART B – REQUEST FOR EXPRESSION OF INTEREST ........................................................... 55
1.

Definitions ................................................................................................................................... 56

2.

Introduction ................................................................................................................................. 60
2.1

Transaction Background................................................................................................. 60

2.2

Contact Details ................................................................................................................. 61

2.3

Important Dates ............................................................................................................... 61

7

<!-- page 8 -->

Part A - Preliminary Information Memorandum

3.

4.

5.

Odisha Power Generation Corporation Limited

2.4

Contents of EOI Request................................................................................................. 61

2.5

Clarification ...................................................................................................................... 62

Transaction ................................................................................................................................... 64
3.1

Salient Features of Transaction ...................................................................................... 64

3.2

Process for the Transaction ............................................................................................ 64

Instructions To Interested Bidders .......................................................................................... 66
4.1

General Conditions ......................................................................................................... 66

4.2

Amendment to EOI Request .......................................................................................... 67

4.3

Submission of Expression of Interest ............................................................................ 68

4.4

Evaluation of EOI ............................................................................................................ 73

4.5

Governing Law / Jurisdiction ........................................................................................ 73

Eligibility Criteria ....................................................................................................................... 74
5.1

Eligibility Criteria ............................................................................................................ 74

5.2

Formation of SPV............................................................................................................. 87

5.3

Other Terms and Conditions ......................................................................................... 91

6.

Disqualification........................................................................................................................... 95

7.

Annexures..................................................................................................................................... 99
Annexure 1: Format for Letter of EOI ..................................................................................... 99
Annexure 1A - Undertaking in Relation to Ultimate Beneficial Ownership ................ 108
Annexure 2: Form A (forming an integral part of the EOI)............................................... 109
Annexure 3: General Power of Attorney .............................................................................. 116
Annexure 4: Power of Attorney in favour of Lead Member ............................................. 119
Annexure 5: Format for Consortium Agreement (In case IB is a Consortium) ............. 122
Annexure 6: Confidentiality Undertaking ........................................................................... 128
Annexure 7: Format of Affidavit ............................................................................................ 140
Annexure 8: Declaration / Disclosure on order/ pending investigation /proceedings by any
Court/ regulatory authority ..................................................................................................... 142

8

<!-- page 9 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

Annexure 9: Advertisement .................................................................................................... 144
Annexure 10: Undertaking by Parent.................................................................................... 145
Annexure 11: Certificate of Shareholding Pattern.............................................................. 147
Annexure 12: Certificate of Eligibility for Participation in the Transaction ................. 148
Annexure 13: Certificate of Fulfilment of Financial Criteria............................................ 149
Annexure 14: Certificate of Fulfilment of Technical Criteria........................................... 152

9

<!-- page 10 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

LIST OF TABLES
Part A: PRELIMINARY INFORMATION MEMORANDUM
Table 2-1: Capital structure and shareholding pattern of OPGC ........................................................17
Table 2-2: Shareholding pattern of OPGC ..............................................................................................17
Table 2-3: Brief Profile of Board of Directors of OPGC (as on December 31, 2022) ..........................18
Table 2-4: Key financial indicators of OPGC ..........................................................................................19
Table 3-1: Major Equipment of OPGC Phase I .......................................................................................28
Table 3-2: Major Equipment of OPGC Phase II .....................................................................................28
Table 3-3: Pending Construction work for OPGC .................................................................................28
Table 3-4: List of Approvals and Clearances of OPGC .........................................................................29
Table 3-5: Operational Parameters of OPGC Phase I ............................................................................31
Table 3-6: Operational Parameters of OPGC Phase II...........................................................................31
Table 3-7: Coal Consumed by OPGC ......................................................................................................32
Table 3-8: Secondary Oil Consumed by OPGC .....................................................................................32
Table 3-9: Human Resource Details of OPGC........................................................................................32
Table 3-10: Mini Hydel Projects of OPGC ..............................................................................................33
Table 4-1: P&L (Standalone) – OPGC ......................................................................................................35
Table 4-2: Balance Sheet (Standalone) - OPGC ......................................................................................36
Table 4-3: Fund based outstanding position of OPGC as on December 31, 2022 .............................36
Table 4-4: Non-Fund based outstanding position of OPGC as on December 31, 2022 ....................37
Table 4-5: Contingent Liabilities of OPGC as on Sept 30, 2022............................................................38
Table 4-6: Summary of Contractor Claims .............................................................................................38
Table 4-7: P&L (Consolidated) – OPGC ..................................................................................................39
Table 4-8: Balance Sheet (Consolidated) - OPGC ..................................................................................40
Table 5-1: Board of Director and KMP for OCPL ..................................................................................42
Table 5-2: Mine Details of OCPL Mine ...................................................................................................43
Table 5-3: Mining plan of OCPL Mine ....................................................................................................44
Table 5-4: Mine Area Breakup of OCPL Mine .......................................................................................44
Table 5-5: Land Use of OCPL Mine .........................................................................................................45
Table 5-6: Operational Performance of OCPL........................................................................................45
Table 5-7: Borrowing Details of OCPL ....................................................................................................48

10

<!-- page 11 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

Table 5-8: Mine Area Breakup of OCPL Mine .......................................................................................49

PART B – REQUEST FOR EXPRESSION OF INTEREST
Table 2-1: Important Dates .......................................................................................................................61
Table 5-1: Illustrative Example 1: Consortium members and eligibility criteria ..............................80
Table 5-2: Illustrative Example 2: Consortium members and eligibility criteria ..............................81
Table 5-3: Illustrative Example 3: Consortium members and eligibility criteria ..............................82
Table 5-4: Illustrative Example 4: Consortium members and eligibility criteria ..............................83
Table 5-5: Illustrative Example 5: Sole Interested Bidder and eligibility criteria ..............................84
Table 5-6: Illustrative Example 6: Sole Interested Bidder and eligibility criteria ..............................85
Table 5-7: Illustrative Example 6: Sole Interested Bidder and eligibility criteria ..............................86

LIST OF FIGURES
Part A: PRELIMINARY INFORMATION MEMORANDUM
Figure 2-1: Group Overview of OPGC, OCPL .......................................................................................20
Figure 3-1: Location of OPGC Plant ........................................................................................................21

PART B – REQUEST FOR EXPRESSION OF INTEREST
Figure 5-1: Diagrammatic Scheme for Sole Bidder SPV Formation ....................................................88
Figure 5-2: Diagrammatic Scheme for Consortium SPV Formation ...................................................90
Figure 7-1: Notification ........................................................................................................................... 144

11

<!-- page 12 -->

Part A - Preliminary Information Memorandum

AES
AIF
BTG
BOP
CIM
CMPDI/CMPDIL
CWIP
DIN
DPR
EBITDA
FGD
FSA
GoI
GOO
GRIDCO
IB
Kwh
LA
MCL
MoEF
MGR
MT
MTPA
MU
MW
OCPL
OHPC
OPGC
PAN
PAT
PBDT
PBDIT
PFC
PIM
PGCIL
PPA
REC
R&M
Rs.
YTD

Odisha Power Generation Corporation Limited

ABBREVIATIONS
AES Corporation, USA
Alternative Investment Fund
Boiler Turbine Generator
Balance of Plant
Confidential Information Memorandum
Central Mine Planning and Design Institute
Capital work in progress
Director Identification Number
Detailed Project Report
Earnings before Interest Tax Depreciation and Amortization
Flue Gas Desulphurization
Fuel Supply Agreement
Government of India
Government of Odisha
GRIDCO Ltd
Interested Bidder
Kilowatt Hour
Legal Advisor
Mahanadi Coalfields Ltd
Ministry of Environment and Forest
Merry Go Round Railway Siding
Metric Tonne
Metric Tonne Per Annum
Million units
Megawatt
Odisha Coal and Power Ltd
Odisha Hydro Power Corporation Ltd
Odisha Power Generation Corporation Ltd
Permanent Account Number
Profit after Tax
Profit before Depreciation and Tax
Profit before Depreciation, Interest, and Tax
Power Finance Corporation
Preliminary Information Memorandum
Power Grid Corporation of India Ltd
Power Purchase Agreement
REC Ltd
Renovation & Modernisation
Indian Rupees
Year To Date

12

<!-- page 13 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

IMPORTANT NOTICE
Odisha Power Generation Corporation Limited (“OPGC” or “the Company”) was incorporated
on November 14, 1984 with the main objective of establishing, operating & maintaining thermal
power generating stations. OPGC has an operational capacity of 1,740 MW as on 31.12.2022 with
Phase I (Unit 1 and 2) of 2 x 210 MW and Phase II (Unit 3 and 4) of 2 x 660 MW capacity. OPGC is
currently held 100% by Government of Odisha as on 31.12.2022.
The Department of Energy, Government of Odisha decided (GOO) has decided for disinvestment
of 49% equity shareholding of OPGC which is currently held by GOO to a technically and
financially capable buyer, identified through a two-stage procedure.
This Preliminary Information Memorandum (PIM) and Request for Expression of Interest (EOI
Request) has been prepared for providing information about the Company and the Transaction to
the Interested Bidders and inviting Expressions of Interest from Interested Bidders for the
disinvestment of 49% equity shareholding of OPGC.
This document has been divided into 2 parts:
•

Part A: Preliminary Information Memorandum

•

Part B: Request for Expression of Interest

The Preliminary Information Memorandum (“PIM”) and Request for Expression of Interest (“EOI
Request”) are available for downloading from websites of OPGC at www.opgc.co.in, Department
of Energy, Government of Odisha at www.energy.odisha.gov.in and Transaction Advisor at
www.sbicaps.com.

13

<!-- page 14 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

PART A –PRELIMINARY INFORMATION MEMORANDUM

14

<!-- page 15 -->

Part A - Preliminary Information Memorandum

1.

Odisha Power Generation Corporation Limited

INTRODUCTION

Odisha Power Generation Corporation Limited (“OPGC” or “Company”) was incorporated on
November 14, 1984 as a wholly owned Government Company of the State of Odisha with the main
objective of establishing, operating & maintaining thermal power generating stations. As on date,
OPGC has an operational capacity of 1,740 MW with Phase I (Unit 1 and 2) of 2 x 210 MW and
Phase II (Unit 3 and 4) of 2 x 660 MW capacity. As on December 31, 2022, OPGC is 100% owned
by Govt of Odisha
In FY 22, the Company was able to generate 2,956 MUs with PLF of 80.34% from Phase I and 7,237
MUs with PLF of 62.58% from Phase II. Till December 31, 2022 (FY 2023 YTD), the Company was
able to generate ~2,010 MUs with PLF of ~72.50% from Phase 1 and ~6,715 MUs with PLF of 77.08%.
The Company has achieved turnover of ~Rs 2,852 Crore with EBITDA of ~Rs 887 Crore in FY 2022.
EBITDA margin for FY 2022 has been ~31%. As per half-yearly FY 2023 financial, the Company
has achieved turnover of ~Rs.1,762 cr with EBITDA of ~Rs.696 cr. As on 30.09.2022, the Net Worth
of the Company stands at ~Rs.3,056 cr.
OPGC’s Phase I comprising of Unit 1 and Unit 2 having total generation capacity of 420 MW (2x210
MW). The first unit of OPGC commenced operations in December 1994 while the second unit
commencing operations in June 1996. The Company has a PPA with GRIDCO Ltd (GRIDCO) for
Phase I of the plant for 100% offtake of the power generated, and the same is valid up to June, 2026
as per terms of the Bulk Power Supply Agreement entered into between OPGC and GRIDCO dated
13th August 1996 and further amended by Supplemental Agreement dated 19th December 2012.
The Company appointed a consultant for preparing a Detailed Project Report (DPR) to explore the
possibility of extension of Phase 1 plant life beyond June 2026. As per the findings of the DPR, a
Renovation & Modernisation (R&M) plan was recommended which broadly includes the
following:
(i)
(ii)
(iii)

Improvement in PLF and the reduction in Station Heat Rate;
Reduction in Auxiliary Power Consumption; and
Reduction in Specific Oil Consumption

Further, it was envisaged that on implementation of the R&M plan, Phase 1’s life would be
extended by 15 years beyond June 2026. The same is being evaluated by OPGC management.
OPGC procures coal for Phase I (Unit 1 and 2) through Coal Supply Agreement with Mahanadi
Coal Fields Limited (MCL) wherein coal is supplied from Lakhanpur Coal mines through a
dedicated Merry Go Round (MGR) railway network. The Coal Supply Agreement is for supply of

15

<!-- page 16 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

2.7 MMT of Coal per year and this arrangement is valid till end of FY 2029. Coal requirement of
Phase II (Unit 3 & 4) is being met from the captive coal blocks managed by Odisha Coal and Power
Limited (OCPL). OCPL was incorporated in the year 2015. As on December 31, 2022, OPGC and
GOO holds 51% and 49% of OCPL’s shareholding. OCPL is engaged in mining and extraction of
coal for supplying it to the thermal power plants of OPGC. OCPL has been allocated with two
contiguous coal blocks, namely Manoharpur and Dip-side of Manoharpur by Ministry of Coal,
Government of India. The coal blocks are located in IB Valley coalfield in Sundargarh District,
Odisha.
OPGC has 100% Power Purchase Agreements (PPA) with GRIDCO for Phase I valid till 30.06.2026.
For Phase II, OPGC has PPA with GRIDCO and as per its terms 75% of power is being purchased
by GRIDCO under long term PPA and the balance 25% is being sold in open market by GRIDCO
till 31.03.2023. From April 2023 onwards, 100% of the power to be directly sold to GRIDCO for a
period of 25 years under long term PPA.
OPGC is contemplating expansion of its present capacity through implementation of Phase III by
installing Units 5 & 6 having capacity of 660 MW each. OCPL has extractable reserve of 636 Million
Metric Tonnes (MMT) and its peak rated capacity is 16 MMT per year, which is sufficient to meet
the requirement of 4x660 MW units for more than 40 years. Common Infrastructure, Land for
expansion of plant and the Merry Go Round (MGR) system are in the possession of OPGC.
The Company's authorized capital as on September 30, 2022 is Rs. 3,000 Crore (3,00,00,000 equity
shares of Rs. 1,000.00 each), issued and subscribed capital is Rs. 2,029.49 Crore (2,02,94,974 shares
of Rs. 1,000.00 each) and paid up share capital is 2,029.49 Crore (2,02,94,974 shares of Rs. 1,000.00
each). As on December 31, 2022, GOO is holding 100% shareholding of OPGC.
The Department of Energy, GOO has decided for disinvestment of 49% equity shareholding of
OPGC which is currently held by GOO to a technically and financially capable buyer, identified
through a two-stage procedure.
This Preliminary Information Memorandum (PIM) has been prepared with the purpose of
providing information regarding OPGC and solicit Expression(s) of Interest from Interested
Bidders for sale of 49% stake in the Company.

16

<!-- page 17 -->

Part A - Preliminary Information Memorandum

2.

2.1

Odisha Power Generation Corporation Limited

COMPANY OVERVIEW

Introduction

OPGC was incorporated on November 14, 1984 with the main objective of establishing, operating
& maintaining thermal power generating stations. OPGC first had set up 2 x 210 MW (Phase I)
thermal power station at Banaharpalli (IB Thermal Power Station) in the district of Jharsuguda
(Odisha). The first unit of Phase I commenced operations in 1994 while the second unit of Phase I
commenced operations in 1996. OPGC thereafter expanded Phase II ( Unit 3 and 4) of 660 MW
each (total capacity of 1320 MW Phase II) in the vicinity of the existing plant. Unit 3 commenced
commercial operations in July 2019 and Unit 4 achieved commercial operations in August 2019.
OPGC currently is a 100% Government of Odisha (GOO) owned company. Presently, OPGC is
contemplating expansion of its present capacity through implementation of Phase III by installing
Units 5 & 6 having capacity of 660 MW each.

2.2

Capital Structure of OPGC

The Capital Structure of OPGC, as on September 30, 2022, is given below:Table 2-1: Capital structure and shareholding pattern of OPGC
Amount
(Rs. Crore)

Particulars
Authorized capital
3,00,00,000 equity shares of Rs. 1,000/- each
Issued & Subscribed Capital
2,02,94,974 equity shares of Rs.1,000/- each
Paid Up Capital
2,02,94,974 equity shares of Rs.1,000/- each
Source: Audited FY 2023 Half-Yearly Financials of the Company
Note: Share Application money received from GOO - Rs.38 Cr on 31st December 2022

2.3

3,000.00
2,029.49
2,029.49

Shareholding Pattern

The Shareholding Pattern of OPGC, as on December 31, 2022, is given below:Table 2-2: Shareholding pattern of OPGC
No of
Shares held
2,02,94,974
2,02,94,974

Particulars
Governor of Odisha
TOTAL
Source: Company

17

% of
holding
100.00
100.00

Amount
(Rs. Crore)
2,029.49
2,029.49

<!-- page 18 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

Brief History of OPGC
In 1999, as a part of the restructuring of the power sector in the state, the GOO divested 49% of its
equity in OPGC to AES Corporation, USA (“AES”). AES was holding the 49% till 2020. In
September 2020, AES offered to sale its stake to a separate entity. Based on the terms of the
Shareholders' Agreement (SHA) between GOO and AES, GOO decided to exercise its Right of First
Refusal (RoFR) by acquiring the 49% stake in OPGC. Based on the decision of the Government,
Odisha Hydro Power Corporation (“OHPC”) as nominee of GOO acquired the 49% stake offered
by AES. The acquisition was completed in December 2020.
In FY 2022, OPGC further issued 20,70,000 equity shares of Rs 1,000 each at par in favour of the
Governor of Odisha amounting to Rs 207 Crore. Thus on March 31 2022, the stake of OHPC has
been reduced to 44% and the stake of GOO has increased to 56% in OPGC. Presently in FY 2023,
GOO has acquired the shareholding of OHPC pursuant to the Share Purchase Agreement (SPA)
executed on December 26, 2022. As on December 31, 2022, OPGC is wholly owned by GOO.

2.4

Board of Directors of OPGC

The Board of Directors of OPGC comprised the following members:
Table 2-3: Brief Profile of Board of Directors of OPGC (as on December 31, 2022)
Age
(in
years)

Educational
Background and
years of
experience

01710101 ABRPD7060M

53

M.TECH,
IAS, RR 1993

Managing
Director

07800722 AHNPM5452E

63

B.Sc, ENGG.
(MECH.)

Director, OPGC

02791739 ABDPM8880A

59

B.Sc, ENGG.
(MINING)

09206773

57

B.Sc, ENGG.
(MECH.)

Name of
Director/
KMP

Designation

Mr.
Nikunja
Bihari Dhal, IAS

Chairman

Mr.
Prasanta
Kumar Mohapatra
Mr.
Mishra

Sariputta

DIN

PAN

Mr.
Manas
Ranjan Rout

Director
(Operation)

Mr.
Yudhisthir
Nayak, IAS

Director
(Nominee Govt
of Odisha)

08569358 AAVPN0502D

Mr.
Hrudaya
Kamal Jena, OAS

Director
(Nominee Govt
of Odisha)

09235054

Source: Company

18

AAUPR1539B

AGJPJ3294L

43

<!-- page 19 -->

Part A - Preliminary Information Memorandum

2.5

Odisha Power Generation Corporation Limited

Financial Overview

Key financial indicators of OPGC (standalone) for the past 5 years ended March 31, 2022 and HY
months ended 30.09.2022 are provided below.
Table 2-4: Key financial indicators of OPGC
Rs. Crore
HY FY
2023
1,762

Sales
Sales Growth
Expenses
EBITDA
EBITDA%
Finance Cost
Depreciation
Other Income
PBT
Tax
PAT
PAT%

FY 2018
(Aud.)
597
-17.23%
579
18
3.04%
0
25
16
9
4
5
0.80%

FY 2019
(Aud.)
863
44.44%
594
269
31.14%
0
21
25
272
100
171
19.87%

FY 2020
(Aud.)
1,624
88.14%
1,180
443
27.29%
467
210
20
-213
-72
-142
-8.72%

FY 2021
(Aud.)
2,378
46.47%
1,591
787
33.11%
723
311
15
-231
-40
-191
-8.01%

FY 2022
(Aud.)
2,852
19.93%
1,965
887
31.09%
734
302
15
-134
-31
-103
-3.59%

Paid Up Capital
Reserves & Surplus
Net Worth

1,580
1,133
2,713

1,822
1,300
3,122

1,822
1,157
2,979

1,822
968
2,790

2,029
862
2,892

2,029
1,026
3,056

5,480

6,882

7,181

7,056

6,518

6,328

5,557

6,966

7,255

7,126

Short Term Borrowing

-

-

205

831

1,492

1,417

Trade Payables
(Current)

36

48

57

115

164

199

619

457

824

351

346

316

728

611

1,120

1,335

2,106

2,055

Net Block+CWIP
Inventory

7,869
44

9,415
59

9,814
130

9,778
142

9,865
212

9,748
209

Trade Receivables
(Current)

99

348

469

453

570

605

Particulars

Non-Current
Borrowings
Total Non-Current
Liabilities

Other Financial
Liabilites
Total Current Liabilities

19

6,592

1,066
696
354
151
14
221
57
164

6,402

<!-- page 20 -->

Part A - Preliminary Information Memorandum

Particulars
Cash & Bank
Total Current Assets

FY 2018
(Aud.)
493
682

FY 2019
(Aud.)
332
837

Odisha Power Generation Corporation Limited

FY 2020
(Aud.)
184
895

FY 2021
(Aud.)
110
810

FY 2022
(Aud.)
223
1,077

Source: Audited Annual Reports and Unaudited FY 2023 Half-Yearly report
Note: Please refer to the financial results uploaded at www.opgc.co.in for further details.

2.6

Group Overview

Figure 2-1: Group Overview of OPGC, OCPL

Further details about OPGC and OCPL are provided in subsequent sections.

20

HY FY
2023
182
1,145

<!-- page 21 -->

Part A - Preliminary Information Memorandum

3.

3.1

Odisha Power Generation Corporation Limited

DETAILS OF OPGC

Plant Location and Connectivity

OPGC’s plant is located at Ib Thermal Power Station, Banharpali, Jharsuguda, Odisha-768234. The
plant is in proximity to the coal block owned by its joint venture company (JV) namely Odisha
Coal and Power Ltd (“OCPL”). It is located at a distance of:
i.

Around 20kms from Belapahar Railway Station

ii.

Around 44 kms from Jharsuguda Airport

The location of the plant is as follows:
Figure 3-1: Location of OPGC Plant

Source: DPR prepared by Development Consultants Pvt Ltd

21

<!-- page 22 -->

Part A - Preliminary Information Memorandum

3.2

Odisha Power Generation Corporation Limited

Land Details

Following is a snapshot of the land area of the OPGC’s thermal power Plant:

502.75

Govt.
Land
(acres)
827.71

Forest
land
(acres)
609.80

1,940.26

-

12.50

-

12.50

MGR Rail Line (unit- 3 & 4)

206.54

103.23

428.09

737.86

4

MCL ( Lakhanpur, Ib Valley &
Orient area) Lease land

92.27

59.30

113.76

265.33

5

Pending land- MGR

-

0.77*

-

0.77

6

Ash Pond - Tilia

273.25

83.95

-

357.20

7

Ash Pipe Corridor (Unit 3 & 4)

-

68.47

-

68.47

1,074.81

1,155.93

1,151.65

3,382.39

Sl. No.

Description

Pvt. Land
(acres)

1

Total Ib Thermal Power Station

2

Hydrogen Plant

3

TOTAL

Total
(acres)

* Land already under use

3.3

Details of OPGC Phase I (2x210 MW)

OPGC as its maiden venture had set up two units of 210 MW thermal power station at Banaharpalli
(IB Thermal Power Station) in the district of Jharsuguda (Odisha) in December 1994 (unit 1) and
June 1996 (unit 2). Phase I was commissioned at a total cost of Rs. 1,135 crores with an equity
contribution of Rs. 525 Crore.
The below write up regarding the plant facilities of OPGC Phase I is as per the information
provided by the Company.
3.3.1

Boiler Turbine Generator (BTG)

Two units of 210MW Turbine Generator Sets fed by steam from pulverized coal fired boiler having
subcritical steam parameters.
• The Steam turbine 210MW capacity is of Kraft Werk Union (KWU-Germany) design and
supplied by BHEL. The turbine is condensing, tandem compounded, horizontal, reheat type,
single shaft machine. It has got separate high pressure, intermediate and low-pressure parts.
The HP part is a single cylinder, single flow with 25 reaction stages, Double flow IP turbine
with 20 reaction stages per flow and Double flow LP turbines with 8 reaction stages per flow.
The turbine rotors are rigidly coupled with each other and with generator rotor. The turbine
is designed for main stream inlet parameters of around 147.1 Kg/cm2 (a) pressure and
543C (5C) temperature, reheat steam temperature of 543C (5C) at IP turbine inlet with

22

<!-- page 23 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

design exhausting condenser pressure 0 . 9 3 k s c and design condenser cooling water
temperature of 32C.
• The electric Generator is BHEL make, three-phase, directly coupled, two-pole machine capable
of generating 210 MW at generator terminals after meeting power requirement for excitation
at a power factor 0.85 (lag). The generator would deliver power at 15.75 KV, 3 pH, 50 Hz with
short circuit ratio not less than 0.49. The static excitation system is with brush and having
DAVR control.
• The Steam Generator/ Boiler is BHEL (C.E. Design) make, subcritical steam generator units,
pulverized coal fired, balanced draft, single reheat, natural circulation, single drum, dry
bottom type with capacity of appx 690TPH.
3.3.2
•

Balance of Plant
Coal Handling System: Coal handling facility, which comprises of unloading from
BOBRN wagons and stacking by stacker and reclaimer in the coal yard. Coal is finally
transported to the boiler area through conveyors and fed to the bunker level conveyors.
System capacity considered is 2000 TPH.

•

Ash Disposal System: Bottom and fly ash is extracted in lean slurry form and is
transported to the Ash Pond in lean slurry form without causing damage to the
environment. There are four ash slurry disposal series with four pumps in each series for
discharging ash in ash pond located at a distance of about 6Kms.

•

Cooling System: Semi-open recirculating condenser cooling system with wet-type
Induced Draft RCC (fill) Counter Flow Cooling Towers.

3.3.3

Ash Pond

There are three ash ponds in OPGC I named as ash ponds A, B & C. Ash Pond B is exhausted and
has been capped. Ash pond C and A are in service but, ash pond A is about to get exhausted. The
life of Ash Pond C is likely to get exhausted by December 2024.
3.3.4

Merry Go Round Railway

For OPGC I, there is an FSA with MCL (Mahanadi Coal Field Ltd.). OPGC has constructed a siding
at Lakhanpur Coal mines of MCL (Chharla siding) and the coal from the mines is transported to
the siding and loaded on to the MGR rakes of OPGC by MCL and from there on it is moved to the
plant by using the Merry-Go-Round system owned by OPGC.
3.3.5

Power Purchase Agreement (PPA)

PPA dated 13th August 1996 was executed between OPGC and GRIDCO and came into force w.e.f
01.01.1995. GRIDCO has agreed to receive full quantum of power generated from the two units of

23

<!-- page 24 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

210 MW each at IB Thermal Power Stations (ITPS) of OPGC at the outgoing terminals of 220 KV
lines switchgear at ITPS. The existing terms of the PPA are valid till 30.06.2026.
As per information provided by the Company, Phase I does not meet the latest Emission Norms unless FGD
is installed. The timeline allowed as per the guidelines of Ministry of Environment, Forest and Climate
Change (MOEFCC) for setting up FGD is till December 2027. OPGC has initiated the activities for
installing FGD plant. In addition to it, OPGC is also considering Renovation & Modernisation (R&M) of
its existing Phase 1 plant infrastructure for extension of plant life by 15 years beyond June 30, 2026. Towards
the same, the feasibility study including DPR (detailed project report) and RFP preparation has been
completed. The proposal for execution of R&M project including FGD retrofit with extension of PPA by
15years beyond 30th June 2026 (present PPA expiry period) is approved by OERC. The tender process for
selection of vendor to implement FGD project and methodology to select the vendors for R&M work are in
process. Coal for Phase I beyond 31st March 2029 is expected to be secured from OCPL Mines for which
application process has been initiated.
3.3.6

Sources of Water

Water allocated from the Hirakud Reservoir by the Department of Water Resources (DOWR) for
supply of water of 12.26 cusec. OPGC has executed the water supply agreement with Department
of Water Resources, GOO in March 2017. At present though the agreement for drawal of water has
expired, there is no bottlenecks in the drawal of water and payment against the same. The
Company is in process of renewing the same. The Company is paying the bill regularly and
maintaining a bank draft of amount equivalent to water charges of 3 months and a bank guarantee
equal to water charges of 9 moths as a security deposit in advance with DOWR.
3.3.7

Sources of Coal

OPGC has entered into an agreement with Mahanadi Coal Fields Limited (MCL) for Supply of
Coal. As per the agreement, MCL shall supply 2.7 MMT of Coal p.a year till March 31, 2029. The
grade of coal is G14. The coal for OPGC Phase 1 is being transported from Chharla siding of MCL
by MGR system owned by OPGC for a distance of about 11 KM.
3.3.8

Sources of Secondary oil

Currently, the plant is using only LDO which is received by road tankers and subsequently stored
in tanks for use in the boilers. OPGC has agreement with Indian Oil Corporation Ltd (“IOCL”) for
supply of secondary oil from Vizag Terminal

24

<!-- page 25 -->

Part A - Preliminary Information Memorandum

3.3.9

Odisha Power Generation Corporation Limited

Power Evacuation

Power generated from the Phase I is evacuated through four numbers of 200KV Line (IbBudipadar line-1, Line-2, Line-3 & Line-4)

3.4

Details of OPGC Phase II (2x660 MW)

OPGC initiated capacity expansion in FY 2007-08 by two more additional units of 660 MW each.
The construction commenced in March 2014. The total cost of the projects as approved by the board
of OPGC is ~Rs. 11,150 Crore with an equity contribution of 25%. The Debt of 75% is shared equally
between Power Finance Corporation Ltd (PFC) and REC Ltd. Unit 3 achieved COD on 3rd July
2019 and Unit 4 achieved COD on 21st August 2019.
3.4.1

Boiler Turbine Generator (BTG)

Two units of 660MW Turbine Generator Sets fed by steam from pulverized coal fired boiler having
supercritical steam parameters.
• The Steam turbine is BHEL/Siemens make, multi-stage, multi-cylinder, tandem compound,
single reheat, condensing type machine operating at 3000 rpm with minimum seven (7)
uncontrolled extractions for regenerative feed heating. The turbine is designed for main
stream inlet parameters of around 247 Kg/cm2 (a) pressure and 565C (5C) temperature,
reheat steam temperature of 593C (5C) at IP turbine inlet with design exhausting
condenser pressure 0 . 1 0 1 5 ( ata) and design condenser cooling water temperature of 33C.
•

The electric Generator is BHEL/Siemens make, three-phase, directly coupled, twopole machine capable of generating 660 MW at generator terminals after meeting
power requirement for excitation at a power factor 0.85 (lag). The generator would
deliver power at 21 KV, 3 pH, 50 Hz with short circuit ratio not less than 0.48.

•

The Steam Generator/ Boiler is BHEL make, supercritical once-through steam
generator units, pulverized coal fired, balanced draft, single reheat, dry bottom type,
two pass arrangement with capacity of appx 2100 TPH.

3.4.2
•

Balance of Plant
Coal Handling System: Coal handling facility, comprises of unloading from railway
wagons and stacking by stacker and declaimer in the coal yard. Coal is transported to
the boiler area through conveyors and fed to the bunker level conveyors. System
capacity considered is 3000 TPH.

•

Ash Disposal System: As per the DPR of Phase II, the dry fly ash from the silos will be
used for fly ash brick manufacturing; lightweight aggregates manufacturing, cement

25

<!-- page 26 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

admixtures etc. In the event of disruption in off take of fly ash from the plant, unutilized
fly ash will be disposed through High Concentration Slurry Disposal (HCSD) system. Fly
Ash will also be progressively back filled into Manoharpur mines which is the owned by
OCPL and any other mines which will be obtained from MCL
Presently, Bottom ash is extracted in lean slurry form and transported to the Ash pond in
lean slurry form without causing damage to the environment. Fly ash from the power
plant is evacuated in dry form and disposed through HCSD system to the Ash Pond of
Units 3 & 4 (for first five years) and later on, it is planned to be transported to mine for
mixing with OB and backfilling.
•

Cooling System: Semi-open recirculating condenser cooling system with wet-type
Induced Draft RCC Counter Flow Cooling Towers.

3.4.3

Ash Pond

There are two ash ponds (Phase I & II) located at a distance of 14kms from the plant site. The
location of the ash pond area is known as Tilia. For bottom ash disposal, there are two series with
five pumps in each series. For fly ash disposal, there are three HCSD pumps with three ash
disposal lines.
3.4.4

Flue Gas Desulphurization (FGD) plant

OPGC conducted the tendering for FGD plant through a domestic competitive bidding. Price
discovery was done through reverse e-auction approach. On conclusion of the bidding process,
Letter of Intent (LOI) has been issued in favour M/s ISGEC on March 2020. Estimated project cost
is ~Rs.1,086 cr.
3.4.5

Merry Go Round Railway

Coal from OCPL mines located at Manoharpur & Dip-side Manoharpur (47kms away from the
plant) is transported by using the MGR Rail system owned by OPGC and unloaded at the plant
site at track hoppers of OPGC Phase 2.
There are seven LOCO Engines and 170 (145 in place and 25 under procurement) BOBRN wagons
for transportation of Coal. MGR system is managed by OPGC O&M team.
3.4.6

PPA

OPGC has a PPA with GRIDCO for the Phase II and as per its terms 75 % of the capacity i.e 990
MW (75 % of 1320 MW) would be sold to GRIDCO from the date of commencement till 31st
March’2023 and thereafter from 1st April 2023 onwards 100% of the capacity would be sold to
GRIDCO for a period of 25 years. For the balance 25% till 31st March 2023, PPA has been entered

26

<!-- page 27 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

through a supplementary agreement executed in Jan’2019 between GRIDCO and OPGC whereby
such capacity are being sold in short term market through GRIDCO till 31st March 2023.
3.4.7

Sources of Water

Water requirement for Phase II is estimated at 4100 cu.m/hr . Hirakud Reservoir has been allocated
by DOWR for supply of water of 40.72 cusec. OPGC has executed the water supply agreement
with DOWR, GOO in March 2017. At present the agreement for drawal of water has expired. The
Company is in process of renewing the same. However, the Company is paying the bill regularly
and maintaining a bank draft of amount equivalent to water charges of 3 months and a bank
guarantee equal to water charges of 9 moths as a security deposit in advance
The length of the intake channel is around 5.6 km.
3.4.8

Sources of Coal

Coal for Phase II is being supplied from Manoharpur and Dip-side Manoharpur coal blocks by
Ministry of Coal, Government of India, in Ib Valley area with net Geological Reserve of 978.4
million tonnes and extractable reserve of 636.30 million tonnes with specified end use plants as
Unit nos 3,4,5 & 6 of OPGC. The integrated Manoharpur and Dip side of Manoharpur coal mine
is having a life of 44years with a Peak Rated Capacity of 16MTPA from FY 2025-26.
Odisha Coal and Power Limited (OCPL) (a joint venture of OPGC & GOO with shareholding of
51% and 49% respectively), is allotted with the Manoharpur and Dip-side Manoharpur coal blocks.
OCPL has developed the blocks and supplying coal through OPGC owned dedicated railway
infrastructure. The coal for OPGC Phase II is being transported from Manoharpur siding of OCPL
by MGR system for a distance of about 47 KM.
The following features in system design are adopted:
•

An in-plant storage of 10 days is planned.

•

The height of coal stack is contained within 10 m.

•

Crushed coal of (-) 20 mm is stacked to avoid self-ignition

3.4.9

Sources of Secondary Oil

Light Diesel Oil (LDO) is to be used for cold start-up and Heavy Fuel Oil (HFO) as support fuel
for flame stabilization. As per the DPR, the existing Fuel oil system of LDO for Phase 1 is adequate
to meet the requirement of LDO for 2 × 660 MW units 3 & 4. Two (2) nos. HFO tanks of capacity
4000 m3 each have been installed for Phase 2. LDO and HFO is received from Vizag terminal of
IOCL to the plant site by road tankers and is unloaded by using existing HFO/LDO unloading
system of Phase 1. OPGC has an agreement with IOCL for supply of necessary secondary oil.

27

<!-- page 28 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

3.4.10 Power Evacuation
Presently, the power is being evacuated through the following 2 numbers of 400KV Line:
•

400kV D/C, OPTCL transmission line, in service

•

400kV D/C, PGCIL transmission line, in service

3.5

Equipment Details

List of equipment and executing agency are provided as follows:
3.5.1

Phase I

Table 3-1: Major Equipment of OPGC Phase I
Agency
BHEL
BHEL
i.
Odisha Construction Corporation
ii.
BEL,
iii.
Ashok Bricks, Belpahar
BSBK,Villai
Local contractor
Source: Company

3.5.2

Area
Main Plant (BTG)
Balance of Plant
Ash Pond (493 Acre)

Ash water recycling system
Township

Phase II

Major executing agencies for Phase -II (2 X 660 MW) are as below:
Table 3-2: Major Equipment of OPGC Phase II
Agency
Area
BHEL
Main Plant (BTG)
BGRE
Balance of Plant
Larsen &Toubro Ltd
Merry Go Round (47 KM)
Shree Balajee Equipment Pvt Ltd Ash Pond (357 Acre)
Driplex
Ash water recycling system
NCC
Township
ISGEC
FGD
Source: Company

3.5.3

Update on pending construction works

Following are the pending construction works for Phase II:
Table 3-3: Pending Construction work for OPGC

28

<!-- page 29 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

–Roads & Drains -600mtr & 800 mtr.
–Crains & Hoists
Balance of Plant (BOP)

–Roof treatment of buildings-7760 Sqmt.
–Side stream filter for U3
–Part of FDA & PA system
–Balance capability and PG test
–Performance Guarantee test of Both units

Boiler Turbine Generator
(BTG)

–U #3: ~70 MT Structural balance Erection (Boiler & lift Structure,
Platforms, Weather Protection Structure)
–U #3: ~15 MT Insulation & cladding balance
–U #3: Structural Painting—40% Balance

Ash Water Recovery
System (AWRS)

–Preparation for PG test & Full handover of AWRS system is under
progress
–CTBDT Commissioning

Source: Company

3.6

Statutory Clearances

Following is the list of key approvals and clearances obtained for OPGC Phase I and Phase II:
Table 3-4: List of Approvals and Clearances of OPGC
Permits
Plant
SN
/License
Issuing Authority
Description
Boiler No. OR1
Asst. Director Factories & Boilers Jharsuguda
512 (Unit-1)
Asst. Director Factories & Boilers Jharsuguda
Boiler No. OR2
(Validity extension for another 1 yr. is under
516 (Unit-2)
process)
Coal
Storage
3
and
Deputy Director Mines Sambalpur
Consumption
OPGCLDO & HFO
Phase I
4
Deputy Chief Controller of Explosive BBSR.
Storage
MGR
Diesel
5
Deputy Chief Controller of Explosive BBSR.
Storage
6
Hydrogen Gas
Deputy Chief Controller of Explosive BBSR.
7
Chlorine Gas
Deputy Chief Controller of Explosive BBSR.
Factory License
8
Chief Inspector of Factories, Odisha
(Renewal)

29

Validity
20.07.2023
19.08.2023

05.11.2025
31.12.2027
31.12.2027
30.09.2026
30.09.2024
31.12.2022

<!-- page 30 -->

Part A - Preliminary Information Memorandum

Plant

SN

9
1
2
3
4
5
6
OPGCPhase
II

7

8

9
10
11
12

Permits
/License
Description

Consent Order
(Unit-1 & 2)
Auxiliary Boiler
Boiler No. OD347 (Unit-3)
Boiler No. OD301 (Unit-4)
Coal
Storage
and
Consumption
LDO & HFO
Pump
Hydrogen Gas
(200
Nos
Cylinder)
Chlorine
Gas
(CW-16
Nos
Cylinder)
Chlorine
Gas
(RW-78
Nos
Cylinder)
Factory License
(Renewal)
Consent Order
(Unit-3 & 4)
Consent Order
(Railway
Siding)
Consent Order
(Township)

Odisha Power Generation Corporation Limited

Issuing Authority
(validity extension for another 1 yr. is under
process)
Member of secretary, State Pollution Control
Board, Odisha
Asst. Director Factories & Boilers Jharsuguda

Validity

31.03.2023
01.08.2023

Asst. Director Factories & Boilers Jharsuguda

04.11.2023

Asst. Director Factories & Boilers Jharsuguda

26.04.2023

Deputy Director Mines Sambalpur

12.11.2023

Deputy Chief Controller of Explosive BBSR.

31.12.2027

Deputy Chief Controller of Explosive BBSR.

30.09.2030

Deputy Chief Controller of Explosive BBSR.

30.09.2030

Deputy Chief Controller of Explosive BBSR.

30.09.2029

Chief Inspector of Factories, Odisha
(Validity extension for another 1 yr. is under
process)
Member of secretary, State Pollution Control
Board, Odisha
Member of secretary, State Pollution Control
Board, Odisha
(*Handed over to MCL)
Member of secretary, State Pollution Control
Board, Odisha

31.12.2022
31.03.2023
31.03.2023
31.03.2024

Source: Company
Note: The above list is indicative only. Further details will be shared to the Shortlisted Bidders in Stage II of
the Transaction.

30

<!-- page 31 -->

Part A - Preliminary Information Memorandum

3.7

Odisha Power Generation Corporation Limited

Details of Operational Performance

Following is a snapshot of major operational performance parameters of OPGC plants in last 3
financial years:
3.7.1

Operational Parameters

Table 3-5: Operational Parameters of OPGC Phase I
Gross
Year

Generation

PLF %

AUX%

(MUs)
FY

2023

(till

SP Oil
(Ml/KwH)

Sp Coal
(Kg/
KwH)

2,009.815

72.5

11.83

0.448

0.905

FY 2022

2955.802

80.34

11.26

0.402

0.878

FY 2021

2609.84

70.93

11.71

0.53

0.946

FY 2020

2643.65

71.65

11.45

0.589

0.868

FY 2019

3085.45

83.86

10.74

0.385

0.831

FY 2018

2842.35

77.25

11.09

0.501

0.909

December)

Source: Company

Table 3-6: Operational Parameters of OPGC Phase II
Gross
Year

Generation

PLF %

AUX%

(MUs)
FY

2023

(till

SP Oil
(Ml/KwH)

Sp Coal
(Kg/
KwH)

6,715.22

77.08

5.62

0.14

0.707

FY 2022

7236.554

62.58

6.41

0.298

0.749

FY 2021

5967.429

51.61

6.77

0.386

0.798

FY 2020

3852.243

49.13

7.02

1.4333

0.754

December)

Source: Company

31

<!-- page 32 -->

Part A - Preliminary Information Memorandum

3.7.2

Odisha Power Generation Corporation Limited

Coal Consumption

Table 3-7: Coal Consumed by OPGC
Coal Consumption (MT)
Period

Phase I

Phase II

FY 2019-20

22,94,455

29,06,487

FY 2020-21

24,68,005

47,62,143

FY 2021-22

25,95,424

54,17,921

FY 2022-23
(till Dec 2022)

18,19,535

47,44,963

Source: Company
3.7.3

Secondary Oil Consumption

Table 3-8: Secondary Oil Consumed by OPGC
Period

Secondary Oil Consumption (KL)
Phase I

Phase II

FY 2019-20

1556.287

5521.229

FY 2020-21

1383.474

2294.143

FY 2021-22

1186.913

2159.79

901.047

940.485

FY 2022-23
(till Dec 2022)
Source: Company

3.8

Human Resource Details

Following are the details of Human resources in OPGC as on November 30, 2022:
Table 3-9: Human Resource Details of OPGC
Particulars

Executive

Non-Executive

Regular Executives

272

188

Project Roll Executives

33

Outsourcing

27

Any Other Category

32

03 (Direct Contract)

TOTAL

555

Source: Company

32

<!-- page 33 -->

Part A - Preliminary Information Memorandum

3.9

Odisha Power Generation Corporation Limited

Future Expansion Plans

Ministry of Coal has allocated two coal blocks namely Manoharpur and Dip-side of Manoharpur
with a reserve of 636.31 Million Ton for 4x660MW units of OPGC ( Unit 3,4,5 & 6). Unit 3&4 have
achieved COD in July & Aug’19 respectively.
Planning for Unit 5 & 6 is in preliminary stage. Coal, water, common infrastructure including land
for second MGR track is available. Utilization of power generated from Unit 5 & 6 shall be decided
by OPGC in consultation with the Government of Odisha / GRIDCO.

3.10

Other infrastructures

Government of Orissa had constituted an agency named Orissa Renewable Energy Development
Agency (OREDA) to carry on construction of Small Hydro stations in the state. Thereafter, the then
I & P (Irrigation & Power) Dept., Govt. of Odisha decided for implementation of micro/mini–
Hydel Schemes in the State of Odisha. OPGC has been authorized by the government as promoting
agency for micro/mini–Hydel Projects in place of OREDA.
In view of above decision, OPGC undertook 7 (seven) Projects as below:
Table 3-10: Mini Hydel Projects of OPGC
Sl. No.
Name of the Project
1
BADNALA
2
HARABHANGI
3
BANPUR
4
ANDHARIBHANGI
5
BIRIBATI
6
BARBORIA
7
KENDUPATNA
Source: Company

Capacity
2 X 325 KW
2 X 1000 KW
2 X 150 KW
1 X 325 KW
2 X 325 KW
2 X 325 KW
2 X 250 KW

Two contractors namely M/s TEW Ltd (Triveni Engineering Works Limited, New Delhi) & M/s
PPGM (Punjab Power Generation Machines Ltd, Chandigarh) were engaged on Turnkey Basis
during December-1990 to construct and complete of the above projects.
Three out of the seven projects namely Kendupatna, Biribati & Andharibhangi were
commissioned on 23.01.94, 20.02.94 & 26.4.2009 respectively and are now in active condition,
excluding Andharibhangi, which needs a design (Gate) modification. The remaining four projects
namely, Harabhangi, Badnala, Banpur and Barboria are now in inactive condition due to change
of location, change of design & non-completion of civil works in time. The revival of 05 (Five)

33

<!-- page 34 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

projects is under active consideration of the OPGC management for which process has been
initiated.
OPGC has already invested ~Rs.19.86 cr for seven projects and also received subsidy of ~Rs.3.38
lakhs for above six projects except Banpur from Ministry of Non-conventional Energy Sources
(MNES). OPGC availed loans from IREDA for these hydel projects and the same has been fully
repaid.

34

<!-- page 35 -->

Part A - Preliminary Information Memorandum

4.

4.1

Odisha Power Generation Corporation Limited

FINANCIAL PERFORMANCE OF OPGC

Profit and Loss Statement (Standalone)

Table 4-1: P&L (Standalone) – OPGC
(Rs Crore)
Particulars

FY 2018

FY 2019

FY 2020

FY 2021

FY 2022

2,852
597
863
1,624
2,378
Sales
19.93%
-17.23%
44.44%
88.14%
46.47%
Sales Growth
1,965
579
594
1,180
1,591
Expenses
887
18
269
443
787
EBITDA
31.09%
3.04%
31.14%
27.29%
33.11%
EBITDA%
734
0
0
467
723
Finance Cost
302
25
21
210
311
Depreciation
15
16
25
20
15
Other Income
-134
9
272
-213
-231
PBT
-31
4
100
-72
-40
Tax
-103
5
171
-142
-191
PAT
-3.59%
0.80%
19.87%
-8.72%
-8.01%
PAT%
Source: Annual Report, Audited Financials of the Company, unaudited half-yearly financials

H1 FY
2023
1,762
1,066
696
354
151
14
221
57
164

Comments:
1. OPGC Phase II has started commercial production in FY 2020 and accordingly the topline
has increased. Following is a summary of units generated :

Particulars
Generation (in MU)
Sales (in MU)

FY 2018

FY 2019

FY 2020

FY 2021

FY 2022

2,842.35
2,511.80

3,085.45
2,738.98

6,495.79
5,903.08

8,577.27
7,864.71

10,192.35
9,382.03

H1 FY
2023
5,554.58
5,149.73

Further details of Operational performance of both Phase 1 and Phase II plants are provided
in Section 3.7.
2. Company has started interest servicing for the loans availed for OPGC Phase II from FY
2020 onwards. Interest expenses for Phase II loans have been capitalized upto FY 2019.

35

<!-- page 36 -->

Part A - Preliminary Information Memorandum

4.2

Odisha Power Generation Corporation Limited

Balance Sheet (Standalone)

Table 4-2: Balance Sheet (Standalone) - OPGC
(Rs Crore)
Particulars

Paid Up Capital
Reserves & Surplus
Net Worth
Non-Current
Borrowings
Total Non-Current
Liabilities
Short Term Borrowing
Trade Payables
(Current)
Other Financial
Liabilities
Total Current Liabilities

FY 2018
(Aud.)

FY 2019
(Aud.)

FY 2020
(Aud.)

FY 2021
(Aud.)

FY 2022
(Aud.)

HY FY
2023

1,580
1,133
2,713

1,822
1,300
3,122

1,822
1,157
2,979

1,822
968
2,790

2,029
862
2,892

2,029
1,026
3,056

5,480

6,882

7,181

7,056

6,518

6,328

5,557

6,966

7,255

7,126

6,592

6,402

-

-

205

831

1,492

1,417

36

48

57

122

164

199

619

457

824

346

346

316

728

611

1,120

1,335

2,106

2,055

Net Block + CWIP
7,869
9,415
9,814
9,778
9,865
Inventory
44
59
130
142
212
Trade Receivables
99
348
469
453
570
(Current)
Cash & Bank
493
332
184
110
223
Total Current Assets
682
837
895
810
1,077
Source: Annual Report, Audited Financials of the Company, unaudited half-yearly financials

9,748
209
605
182
1,145

Comments:
1. Following is updated borrowing position of OPGC as on December 31, 2022:
Table 4-3: Fund based outstanding position of OPGC as on December 31, 2022
Sl.
No.
1
2

Bank / FIs

Union Bank of India
Power
Finance
Corporation Ltd

Type
of
Expo
sure
CC
TL

Purpose

Working Capital
Unit 3&4 (2x660 MW)
Project

36

Sanctioned
(Rs Cr)
500.00
4,181.25

0.49

Inte
rest
Rate
(%)
7.70

3,313.45

8.81

Balance (Rs
Cr)

<!-- page 37 -->

Part A - Preliminary Information Memorandum

Sl.
No.

Bank / FIs

Type
of
Expo
sure

3

Power
Finance
Corporation Ltd

TL

4

Power
Finance
Corporation Ltd

STL

5

REC Ltd

TL

6

REC Ltd

TL

7

REC Ltd

MTL

8

REC Ltd

MTL

9

Indian Bank

TL

Odisha Power Generation Corporation Limited

Purpose

Inte
rest
Rate
(%)

434.40

85.38

8.75

250.00

228.50

6.00

3,181.25

2,242.31

8.81

434.40

88.64

8.7

500.00

333.33

8.75

250.00

200.00

6.00

1,000.00

1,000.00

7.75

10,731.30

7,492.10

Sanctioned
(Rs Cr)

Unit
Environment
Retrofit Project

3&4

Working Capital
Unit 3&4 (2x660 MW)
Project
Unit
3&4
Environment Retrofit
Project
Working Capital
Working Capital
Unit 3&4 (2x660 MW)
Project

TOTAL

Balance (Rs
Cr)

Source: Company
OPGC has conducted an exercise to refinance existing term loans of PFC and REC for the purpose
of reduction of interest rates. Towards the same, OPGC has received Term Loan sanction letters
from various PSU banks. OPGC has availed Term Loan of Rs.1,000 Cr from Indian Bank and prepaid the same to REC on 30.12.2022. With respect to other sanctions, OPGC is in the process of
availing Term Loan at reduced Rate of Interest and the process is ongoing.
Further, OPGC has received sanctions from PFC and REC for a total sum of ~Rs.1,000 cr for FGD
and R&M project of OPGC Phase I. The facilities have not been drawn yet.

Table 4-4: Non-Fund based outstanding position of OPGC as on December 31, 2022
Sl. No.

Bank / FIs

Type of Exposure

1

Axis Bank Ltd.

Bank Guarantee

2

Union Bank of India

Bank Guarantee

37

Purpose
Security
for
Water
charges
favouring
Executive
Engineer,
Main Dam Division,
Burla
Security
for
Transmission
Charges
favouring CTUIL

Sanctioned (Rs
Cr)

31.71

30.90

<!-- page 38 -->

Part A - Preliminary Information Memorandum

Sl. No.

Bank / FIs

Type of Exposure

3

Union Bank of India

Letter of Credit

4

Union Bank of India

Letter of Credit

Odisha Power Generation Corporation Limited

Sanctioned (Rs
Cr)

Purpose
Security for
Railway
Freight favouring SEC
Railway
Security for Railway Epayment
of
Freight
favouring SEC Railway

5.50

0.20

Total Non-Fund Based

68.31

Source: Company
2. Following is a snapshot of the Contingent Liabilities of OPGC as on September 30, 2022:
Table 4-5: Contingent Liabilities of OPGC as on Sept 30, 2022
Sl. No
Particulars

HY FY 23 (A)

1

Income Tax Demands

4.15

2

Indirect Tax Demands (Sales Tax)

0.16

3

Indirect Tax Demands (Service Tax)

1.48

4

Claims of Contractors and others

1,021.86

5

Outstanding Letter of credit & guarantees

46.73

6

Other Money for which the Company is contingently
liable
TOTAL

134.56
1,208.95

Source: Unaudited half-yearly financials
In addition to the abovementioned liabilities, following are the details of status of various claims
of EPC contractors:
(Rs. In Cr)
Table 4-6: Summary of Contractor Claims
Sl No

EPC
Contractor
Name

Package

Contractor
Claim
amount

OPGC Claims
Back Charge

1

BHEL

BTG

115.67

38

61.63

Remarks

LD

430.00

LD Notified. Back
charge disputed
(Not considered as
contingent liability in
financial statement)

<!-- page 39 -->

Part A - Preliminary Information Memorandum

Sl No

EPC
Contractor
Name

Package

Odisha Power Generation Corporation Limited

Contractor
Claim
amount

OPGC Claims
Back Charge

2

BGRE

BOP

3

L&T

MGR

217.30

4

SBEL

Ash Pond

5

TWL

Supply of
Wagons

Considered
in
Contingent
liability
table

Remarks

LD

92.65

245.00

7.23

114.22

10.64

8.23

-

Total

332.97

172.15

1) LD Notified.
2) Contractor Claim
amount
includes
extended stay claim
of INR 125.05 Cr
Back charge disputed
(Not considered as
contingent liability in
financial statement)
Under
ICC
Arbitration
1)
Back
Charge
Amount
includes
unadjusted advance
of INR 10.39 Cr.
2) Under Arbitration
1) LD recovered.
2) Under Arbitration

797.45
969.60

Source: Company

4.3

Profit and Loss Statement (Consolidated)

Table 4-7: P&L (Consolidated) – OPGC
(Rs Crore)
HY FY
2023
1,762

Particulars

FY 2018

FY 2019

FY 2020

FY 2021

FY 2022

Sales
Sales Growth
Expenses
EBITDA
EBITDA%
Finance Cost
Depreciation
Other Income
Share of Profit/(Loss) from
JV

597
-17.23%
579
18
3.04%
0
25
16

863
44.44%
594
269
31.14%
0
21
25

1,624
88.14%
1,180
443
27.29%
467
210
20

2,378
46.47%
1,591
787
33.11%
723
311
15

2,852
19.94%
1,965
887
31.09%
734
302
15

1,066
696
39.52%
339
151
14

-2

-1

-1

-1

74

320

39

<!-- page 40 -->

Part A - Preliminary Information Memorandum

Particulars

FY 2018

Odisha Power Generation Corporation Limited

FY 2019

FY 2020

FY 2021

FY 2022

7
270
-214
-232
-60
PBT
4
100
-72
-40
-31
Tax
3
170
-143
-191
-28
PAT
0.54%
19.71%
-8.78%
-8.05%
-1.00%
PAT%
Source: Annual Report, Audited Financials of the Company, unaudited half-yearly financials

4.4

HY FY
2023
540
57
483

Balance Sheet (Consolidated)

Table 4-8: Balance Sheet (Consolidated) - OPGC
(Rs Crore)

Paid Up Capital
Reserves & Surplus
Net Worth

FY
2018
1,580
1,130
2,710

Non-Current Borrowings
Total Non-Current Liabilities
Short Term Borrowings
Trade Payables- (Current)
Other Financial Liabilities
Total Current Liabilities

5,480
5,557
36
619
728

Particulars

FY 2019

FY 2020

FY 2021

FY 2022

1,822
1,295
3,118

1,822
1,151
2,974

1,822
961
2,784

2,029
937
2,966

HY FY
2023
2,029
1,420
3,450

6,883
6,966
48
457
611

7,181
7,255
205
57
824
1,120

7.056
7,126
831
122
351
1,335

6,518
6,592
1,492
164
346
2,106

6,328
6,402
1,417
199
316
2,055

7,869
9,415
9,814
9,778
9,865
Net Block + CWIP
44
59
130
127
212
Inventory
Trade Receivables-(Current)
99
348
469
453
570
493
332
184
110
223
Cash & Bank
682
837
895
795
1,077
Total Current Assets
Source: Annual Report, Audited Financials of the Company, unaudited half-yearly financials

40

9,748
209
605
182
1,145

<!-- page 41 -->

Part A - Preliminary Information Memorandum

5.

5.1

Odisha Power Generation Corporation Limited

ODISHA COAL AND POWER LTD – MINE DETAILS

Background

Odisha Coal and Power Limited (OCPL) is a company incorporated under the Companies Act
2013, India and is a Government Company as defined by Section 2(45) of the Companies Act, 2013.
OCPL is a joint venture company of OPGC and GOO with a shareholding pattern of 51% and 49%
respectively.
OCPL has been allocated with two coal blocks on 30th March, 2015, namely Manoharpur and Dipside of Manoharpur by Ministry of Coal, Government of India. The coal blocks are located in IB
Valley coalfield in Sundargarh District, Odisha. Manoharpur and Dip side of Manoharpur block
are contiguous blocks having common boundary.
Initially, the Coal Block were allotted to OPGC in 2008. At the time of allocation to OPGC,
Manoharpur block was fully explored and Dip side of Manoharpur block was regionally explored.
The first Mining Plan was approved for Manoharpur block in August 2008. The Revised Mining
Plan along with Mine Closure Plan (Revision-I) was prepared covering the latest resource data,
information available and various updated concerns and issued subsequently in July 2013 to
Ministry of Coal (MoC) and the same was approved in 11 December 2013.
The Supreme Court of India through its judgment dated August 25, 2014 read with its order dated
September 24, 2014 (collectively the “Supreme Court judgment”) had cancelled allotment of 204
coal blocks including the Manoharpur and Dip side coal blocks allotted to OPGC. Subsequent to
the Supreme Court judgment, the Coal Mines (Special provisions) Ordinance 2014 and Coal Mines
(Special provisions) Second Ordinance, 2014 (collectively the “Ordinance”) were promulgated and
the Coal Mines (Special Provisions) Rules, 2014 (the “Rules”) were framed for auction and
allotment of all blocks which were subject to cancellation pursuant to the Supreme Court
judgment. Further, the Coal Mines (Special Provisions) Act, 2015 (the “Act”) was enacted which
replaced the ordinance.
OCPL was thereafter formed for allotment of the cancelled coal mines to secure coal to OPGC.
OCPL applied for allotment of Manoharpur and Dip-Side Manoharpur Coal Blocks through
Government dispensation route on 27th February, 2015 under the section 5(1) of the Coal Mines
(Special Provisions) Act, 2015 and was declared as a successful allottee on 24th March, 2015.
Thereafter, OCPL signed Allotment Agreement with the Nominated Authority, Ministry of Coal,
Government of India on 30th March, 2015. The Specified End Use of the are OPGC Phase II and
Phase III expansion of power plant of OPGC’s units 3,4,5,6 each of 660MW.

41

<!-- page 42 -->

Part A - Preliminary Information Memorandum

5.2

Odisha Power Generation Corporation Limited

Board of Directors of OCPL

The list of Board of Directors of OCPL as on December 31, 2022 is as follows:
Table 5-1: Board of Director and KMP for OCPL
Name of
DIN/DPIN/PAN
Designation
Director

Age
(in years)

Educational
Background

Beginning
Date

01710101

NIKUNJA
BIHARI
DHAL

Chairman

20/06/1969
53 Yrs.

MTech

01/06/2020

02791739

SARIPUTTA
MISHRA

Wholetime
Director

21/04/1963
59 Yrs.

BE(Mining)

22/09/2022

07800722

PRASANT
KUMAR
MOHAPATRA

Nominee
Director

02/07/1959
63 Yrs.

BTech

27/04/2021

09206773

MANASA
RANJAN
ROUT

Nominee
Director

05/05/1964
58 Yrs

BTech,
MTech
(Quality
Design)

27/04/2021

09355946

SAMBIT
PARIJA

Nominee
Director

20/01/1972
51 Yrs

BSc
(Geology)

16/09/2021

Source: OCPL

5.3

Location & Accessibility

The mine is located in IB valley in Sundergarh district. Following are the connectivity details:
•

Nearest Railway station – Hemgiri station is ~20 kms away

•

Nearest National / State Highway /Approach road - 0.7km from Sundergarh-Hemagir BRO
road Durubaga-Kanaktura-Dudka PMGSY road runs through the property and is being
diverted along the periphery

5.4

Area of the Project

As per the DPR prepared by CMPDI, the Manoharpur and Dipside of Manoharpur Block cover an
area of ~13.39 sq km with maximum extent of 3.8 km along east-west and 4.7 km along north-south
direction.

42

<!-- page 43 -->

Part A - Preliminary Information Memorandum

5.5

Odisha Power Generation Corporation Limited

Mine Details of OCPL

Manoharpur and Dip-Side Manoharpur Coal Blocks are integrated into one Mine of 16 MTPA
Peak rated capacity. Following are the mine details of OCPL:
Table 5-2: Mine Details of OCPL Mine
Particulars

Revision-III Mining Plan (At 16 MT Cap)

Name of Mine

Manoharpur & Dip-side Manoharpur Integrated
Mine

Type of Mining

Open Cast

Grade of Coal

G14

Lease Area

1781.591 Hectare
(Manoharpur block land acquired under LA Act
and Dip-Side block land acquired under CBA
A&D Act.)

Project Area

1848.379 Hectare

Extractable Reserve

636.309 million tonne

Overburden

1747.41 Cum

Average Stripping Ratio

2.746 cum/t

Production Capacity

16 Million Ton from Year 7

Life of Mine

44 years

Mine Operator

BGR Infra,Hyderabad /contract tenure 10 years

Detailed Feasibility Report

CMPDIL has prepared Detail Project Report
(DPR) for Manoharpur Coal Block only ( 8
MTPA PRC ).Revised DPR for the Integrated
Manoharpur and Dip-Side Mine (for 16 MTPA
PRC) is under preparation at CMPDIL.

Project Cost

Rs 2374 Crs for 8 MTPA PRC. DPR for 16 MTPA
PRC under preparation.

Source: OCPL

5.6

Mine Plan

Presently, OCPL has got approval for Mine Plan and Mine Closure Plan (Rev III) in September
2019 for peak rated capacity of 16 MTPA. As per the revised mining plan, Manoharpur and

43

<!-- page 44 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

Dipside Manoharpur is fully explored and Geological Report (GR) prepared by CMPDI is
available. Following is a snapshot of the mining plan:
Table 5-3: Mining plan of OCPL Mine
Particulars

Manoharpur Coal Block

Peak Rated Capacity

Dip-Side Coal Block
16 MTPA

Mine Operation Start Date

01 November 2018

Coal Production Start Date

10 October 2019

Coal Dispatch Start Date

14 December 2019

Date
of
Operation

30.09.2021

Commercial

Dip-Side Coal Block is
contiguous with Manoharpur
Coal Block.No independent
Mining in Dip-side block is
proposed in revised Mining
Plan (Rev-III).

Production Planning

FY21: 2 MT (Pre-COD)
FY22: 5 MT
FY23 : 8 MT
FY24: 10 MT
FY25: 13 MT
FY26-FY63: 16 MT
FY 64: 14 MT
FY65 : 8 MT (Mine Closure Period)

Total Production Plan from
COD

631 Million Ton

Total Extraction Reserve

636.309 Million Ton

Source: OCPL

5.7

Mine Area Break up

The following table presents the break up of mine area:
Table 5-4: Mine Area Breakup of OCPL Mine
Sl. Land
Area inside coal mine (in

Area outside coal mine (in

Ha)

Ha)

Total (in Ha)

1

Private

348.746

196.201

544.947

2

Govt.

514.852

169.936

684.788

3

Forest

474.287

144.357

618.644

Total

1337.885

510.494

1848.379

Source: Company; Mine Plan

44

<!-- page 45 -->

Part A - Preliminary Information Memorandum

5.8

Odisha Power Generation Corporation Limited

Land Use Pattern

The below table presents the break of land usage pattern:
Table 5-5: Land Use of OCPL Mine
Sl No Land use pattern "Ha"

Area in Ha

1

Excavation Area

1234.44

2

Topsoil Dump

10.84

3

External Dump

269.51

4

Safely Zone

16

5

Nala division

5.36

6

Road & Infrastructure area

7

Garland drain

6.77

8

Embankment

16.85

9

Green Belt

50

10

Water body

8.56

11

Undisturbed area

8.095

Total Lease area

1781.591

Colony for Owner, MO and others

66.788

Total Project area

1848.379

12

155.166

Source: Company; Mining Plan
Out of the abovementioned land details, the land required for operation of Manoharpur Coal
block, i.e. 1067Ha, has already been acquired. Further for the dip side of Manoharpur Coal block,
land acquisition is under process which are as follows:
•

Section-11(1) under Coal Bearing Areas (Acquisition and Development) Act, 1957 notified
on 07.09.2020.

•

5.9

FC stage –I for 342.87Ha of land is at PCCF level
Operational Performance Highlights

Following is a snapshot of the extraction from OCPL mines from the beginning of FY 2019:
Table 5-6: Operational Performance of OCPL
(figures in Metric Tonne)
Despatch within the state
Month

Production

Apr-19

0.000

Captive

Non
Captive
sold (to
MCL)

Non
Captive
sold to
Others

Total

0.000

0.000

0.000

0.000

45

Despatc
h
outside
state

Total
Despatch

0.000

0.000

<!-- page 46 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

Despatch within the state

Captive

Non
Captive
sold (to
MCL)

Non
Captive
sold to
Others

Total

Despatc
h
outside
state

Total
Despatch

Month

Production

May-19

0.000

0.000

0.000

0.000

0.000

0.000

0.000

Jun-19

0.000

0.000

0.000

0.000

0.000

0.000

0.000

Jul-19

0.000

0.000

0.000

0.000

0.000

0.000

0.000

Aug-19

0.000

0.000

0.000

0.000

0.000

0.000

0.000

Sep-19

0.000

0.000

0.000

0.000

0.000

0.000

0.000

Oct-19

0.000

0.000

0.000

0.000

0.000

19482.900

0.000

Nov-19

0.000

0.000

0.000

0.000

0.000

0.000

0.000

Dec-19

94194.340

0.000

60125.020

0.000

60125.020

0.000

60125.020

Jan-20

194913.990

0.000

146526.600

0.000

146526.600

0.000

146526.600

Feb-20

149628.140

0.000

147834.500

0.000

147834.500

0.000

147834.500

Mar-20

544557.300

0.000

160623.280

0.000

160623.280

0.000

160623.280

1002776.67
0

0.000

515109.400

0.000

515109.400

0.000

515109.400

39983.570

0.000

84155.840

0.000

84155.840

0.000

84155.840

May-20

0.000

0.000

155617.880

0.000

155617.880

0.000

155617.880

Jun-20

38500.000

0.000

152302.140

0.000

152302.140

0.000

152302.140

Jul-20

102037.970

0.000

148281.870

0.000

148281.870

0.000

148281.870

Aug-20

115464.890

0.000

115464.890

0.000

115464.890

Total
FY
2020
Apr-20

15085.000

0.000

Sep-20

87985.790

0.000

95522.930

0.000

95522.930

0.000

95522.930

Oct-20

149800.000

0.000

100867.220

0.000

100867.220

0.000

100867.220

Nov-20

155188.000

0.000

203574.460

0.000

203574.460

0.000

203574.460

Dec-20

193550.000

0.000

196932.480

0.000

196932.480

0.000

196932.480

Jan-21

295526.760

0.000

175406.300

0.000

175406.300

0.000

175406.300

Feb-21

311924.940

0.000

183095.680

0.000

183095.680

0.000

183095.680

Mar-21

611720.430

0.000

192468.970

0.000

192468.970

0.000

192468.970

2001302.46
0

0.000

1803690.66
0

0.000

1803690.66
0

0.000

1803690.660

Total
FY
2021
Apr-21

183968.390

0.000

142193.520

0.000

142193.520

0.000

142193.520

May-21

184014.490

0.000

136006.110

0.000

136006.110

0.000

136006.110

Jun-21

144218.375

166856.570

209184.960

0.000

376041.530

0.000

376041.530

Jul-21

303652.898

410019.720

170467.270

0.000

580486.990

0.000

580486.990

Aug-21

363977.070

348952.330

129148.910

0.000

478101.240

0.000

478101.240

Sep-21

363547.315

432266.570

48733.270

0.000

480999.840

0.000

480999.840

Oct-21

600202.312

550415.960

0.000

0.000

550415.960

0.000

550415.960

Nov-21

581564.53

496157.00

0.000

0.00

496157.00

0.000

496157.00

46

<!-- page 47 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

Despatch within the state

Captive

Non
Captive
sold (to
MCL)

Non
Captive
sold to
Others

Total

Despatc
h
outside
state

Total
Despatch

Month

Production

Dec-21

545746.15

439654.83

0.000

70061.90

509716.73

8475.39

518183.12

Jan-22

592933.16

435310.44

0.000

39443.08

474753.52

11524.61

486278.13

Feb-22

588883.10

486308.93

0.000

147856.94

634165.87

0.000

634165.87

Mar-22

798658.08

379266.10

0.000

297405.68

676671.78

3966.57

680638.35

Total
FY
2022

5251365.87

4147415.75

835734.04

554767.60

5537917.39

23966.57

5561883.96

Apr' 22

6,83,915.03
0

4,38,608.60

Nil

3,12,664.12

7,51,272.72

2,753.47

7,51,272.72

May'
22

9,10,990

4,61,313.70

Nil

2,68,081.00

7,29,394.70

7,279.95

7,29,394.70

June'
22

7,87,349

5,27,321.50

Nil

2,43,570.22

7,70,891.72

6,000.00

7,70,891.72

5,56,009

4,52,016.61

Nil

2,75,023.73

7,27,040.34

3,610.21

7,27,040.34

6,44,406

5,06,161.60

Nil

2,89,555.98

7,95,717.58

389.79

7,95,717.58

6,49,877

5,38,745.10

Nil

1,61,349.94

7,00,095.04

7,00,095.04

7,18,838

5,97,265.30

Nil

85,686.48

6,82,951.78

6,82,951.78

6,35,807

6,19,865.20

Nil

88,830.35

7,08,695.55

Dec 22

6,06,727

6,32,543.90

17,091.06

6,49,634.96

FY
2023
(YTD)

61,93,918.0
7

47,73,841.51

17,54,531.5
8

65,15,694.3
9

July' 22

Aug' 22

Sep' 22

Oct 22

Nov 22

Source: OCPL

47

467.31

7,08,695.55
6,49,634.96

20,500.73

65,15,694.39

<!-- page 48 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

5.10 Borrowing Details:
Following are the borrowing details of OCPL as on 31.12.2022:
Table 5-7: Borrowing Details of OCPL
Purpose

Sanctioned
Limit
(Rs.
Crore)

O/s Amount
(Rs. Crore)

ROI (%)

Fund based

Project TL

500.00

290.93

7.35%

PNB

Fund based

Project TL

536.00

349.49

8.10%

PNB

Fund based

Project TL

296.00

9.00

7.70%

REC Ltd

Fund based

Project TL

275.30

239.99

9.42%

1,607.30

889.41

Bank / FIs

Type
of
Exposure

Union Bank of India

TOTAL
Source: OCPL

5.11 Mode of Dispatch
The coal transportation arrangement to OPGC is as follows:
Coal extracted from Manoharpur Mine is dumped in Receiving Pit of CHP and from there on it is
loaded on to OPGC Rakes through RLS system. Mine CHP is having over ground bunker of
30,000T capacity. OPGC has also constructed a wharf wall siding near the mine premises along the
MGR line to load the coal in case of unavailability of CHP. The loaded rakes from the Mine will be
transported through a 47km MGR line constructed and operated by OPGC. The MGR is integrated
with Indian Railways at OPGC end.
Surplus coal beyond the requirement of OPGC linked units, is placed for e-auction sale as and
when required, and auctioned quantity is lifted by consumers through road cum rail modes.

5.12 Pending Resettlement & Rehabilitation (R&R) activities :
•

R&R activities in Manoharpur Coal Block is completed. Out of 419 Project Affected
Families, 358 are relocated to R&R Colony and 61 opted for self-relocation.

•

Mine working of Manoharpur Mine shall reach Dip-Side Coal block in 12th year of
operation (FY32).

•

Land acquisition notifications under CBA (A&D) Act is complete for Dip-Side Block and
compensation assessment is in progress.

•

There are four villages to be relocated in Dip-Side Coal Block area. The estimated numbers
of Project Affected Families in dip-Side block is 361 as per Socio-Economic Survey
Report,2021. Assessment of compensation to tenants is in progress. R&R colony site is
identified in the acquired area of existing R&R Colony of OCPL

48

<!-- page 49 -->

Part A - Preliminary Information Memorandum

Odisha Power Generation Corporation Limited

5.13 List of Approvals and Clearances obtained
Following is a list of key approvals and clearances obtained by OCPL:
Table 5-8: Mine Area Breakup of OCPL Mine
Permits/ Licenses
Issuing
SN.
Description
Authority
Manoharpur Coal Mine
Mining Plan & Mine Closure Ministry of Coal
1.
Plan Revision-III (16 MTY)
Ground Water permission for Central
Ground
2.
R&R colony
Water Authority
Non-Mineralisation Zone
Directorate
of
3.
Geology, Odisha
A. Forest Clearance to OCPL
Ministry
of
(Manoharpur Mine) -8MTY Environment
&
B. Forest Clearance for Dip- Forest Clearance
4.
side Manoharpur Block and
Climate
forwarded to PCCF on Change (MoEF &
30.12.2022.
CC)
A. Environment Clearance to Ministry
of
OCPL (Manoharpur Mine) Environment
&
-8MTY
Forest Clearance
B. Environment Clearance to and
Climate
5.
OCPL -16MTY pending Change (MoEF &
with MoEF&CC for want of CC)
FC Stage – I of Dip-side
Block.
Road Diversion Permission in Department
of
favour of OCPL
Rural
6.
Development,
GOO
Consent to Establish for Coal State
Pollution
7.
Mine in favour of OCPL Control
Board,
(8MTY)
Odisha
Consent to Establish for R&R State
Pollution
8.
Colony in favour of OCPL
Control
Board,
Odisha
Nalla Diversion Permission in Department
of
9.
favour of OCPL
Water Resources,
GOO
Grant of 1.602 Cusec of water Department
of
10. from Hirakud Dam
Water Resources,
GOO

49

Date of
Issue

Validity

26.09.2019
08.11.2015
17.10.2015

Renewal in
progress.
-

30.11.2015

-

30.12.2015

-

18.01.2016

-

28.03.2016

Renewal in
progress

28.03.2016

-

12.04.2016

-

27.07.2021

-

<!-- page 50 -->

Part A - Preliminary Information Memorandum

SN.
11.

12.
13.
14.

15.
16.
17.
18.
19.
20.
21.
22.
1.
2.

3.
4.
5.

Permits/ Licenses
Description
Rephasing of Water drawal
from Hirakud Dam
Power supply permission for
R&R
colony
Phase-I
at
Sukhabandh
Site
Specific
Wildlife
Conservation Plan
Environment Clearance for
R&R Colony to OCPL
Consent to Operate for new
R&R Colony of OCPL in
Sukhabandh
Permanent Power drawal from
NTPC
Grant Order for Mining Lease
Manoharpur Mine
Mining Lease Execution
Consent to
Operate for
Manoharpur
coal
block
(8MTY)
Explosives License

Odisha Power Generation Corporation Limited

Issuing
Authority
Department
of
Water Resources,
GOO
WESCO

Date of
Issue
27.07.2021

26.04.2016

-

PCCF & CWW,
Odisha
Forest
&
Environment
Department, GOO
State
Pollution
Control
Board,
Odisha
WESCO, DISCOM

30.08.2016
& 4-10-21
12.09.2016

-

29.09.2016

31.03.2026

16.08.2016

-

Deptt. of Steel &
Mines

31.12.2016

-

SPCB

17.05.2017
28.02.2018

31.03.2022

PESO

31.05.2018

Renewal in
progress.
Renewal in
progress
-

NOC for drawal of Ground CGWA
19.07.2018
Water
Mine Opening Permission
CCO
28.08.2018
Dip-side Manoharpur Coal Mines
Grant Order for Prospecting GOO
08.01.2016
License (PL) Deed
PL Execution & Registration
09.02.2016
&
10.02.2016
Permission for drilling of Forest
& 10.12.2016
boreholes in forest area
Environment
Department, GOO
Completion of exploration &
19.01.2018
preparation of GR
Mining Plan & Mine Closure Ministry of Coal
26.09.2019
Plan (Rev-III)

50

Validity

-

-

-

-

<!-- page 51 -->

Part A - Preliminary Information Memorandum

SN.
6.

Permits/ Licenses
Description
Site-specific
Wildlife
Conservation Plan
Garia Nalla Diversion

7.

8.

Mine Opening Permission

Odisha Power Generation Corporation Limited

Issuing
Date of
Validity
Authority
Issue
PCCF & CWW, 04.10.2021
Odisha
Recommended by
Water Resources
Department, Govt.
of Odisha on dtd.
01.12.2022.
Dip-Side Block is contiguous with Manoharpur
Mine

Source: OCPL
Note: The above list is indicative only. Further details will be shared to the Shortlisted Bidders in Stage II of
the Transaction.

51

<!-- page 52 -->

Part A - Preliminary Information Memorandum

6.

6.1
•

Odisha Power Generation Corporation Limited

VALUE DRIVERS

Strengths
Stability of operations through availability of power purchase agreement: OPGC
had already entered into a long-term Power Purchase Agreement (PPA) for supply of
100% of power generated with GRIDCO for Phase I in an agreement dated 13th August
1996. This Phase has never faced any issue in evacuation of power. The validity of the
PPA is till FY2026. The proposal for execution of Renovation & Modernisation (R&M)
project including FGD retrofit with extension of PPA by 15years beyond 30th June 2026
(present PPA expiry period) is under approval by OERC.
For Unit 3 & 4 of Phase II, through an agreement dated 20th December 2018 the
Company has entered into a Long term PPA for supply of upto 75% of the power
generated from the 2x660 MW units till March,2023 and 100% of the power generated
from the units for 25 years thereafter. Balance 25% capacity of Phase II shall be sold in
the open market till March 2023, and GRIDCO shall endeavour to procure this 25%
also on best efforts basis.

•

Coal sourcing from OCPL by MGR: OPGC has developed Manoharpur and Dip side
Manoharpur coal block through its JV company OCPL. The entire coal requirement of
OPGC Phase II & III will be catered by OCPL. For smooth transportation of coal from
OCPL, OPGC has installed Merry Go Round (MGR) railway system along with a wharf
wall siding at mines end. OCPL has constructed a state of the art CHP with 30,000T
over ground bunker and Rapid Loading System having a capacity of 4000TPH to load
the coal on to the rakes of OPGC.

•

Commissioning of Unit 3 & 4: OPGC has commissioned Unit 3 & 4 having combined
capacity of 2x660 MW as part of Phase II of the project. Phase II is built on super critical
parameters having visibility on supply of fuel, water, secondary oil and other
resources. PPA and proper evacuation systems are also in place.

•

Availability of Resources: OPGC Phase I has FSA agreement with Mahanadi Coalfield
Ltd (MCL) and it has been supplying power to GRIDCO as per the existing PPA. There
has been no major issues in terms of procurement of raw materials and evacuation.
OPGC Phase II is running on coal from OCPL mines supplied to OPGC plant through
MGR siding. PPA with GRIDCO is in place and evacuation has begun. OPGC has
following arrangement in place for other key project requirements:

52

<!-- page 53 -->

Part A - Preliminary Information Memorandum

6.1

Odisha Power Generation Corporation Limited

Strengths
o Agreement with Department of Water, GOO for supply of ~ 52 cusec of water
for Phase I and Phase II
o

Agreement with IOCL for supply of secondary fuel

o

Dedicated power evacuation infrastructure with PGCIL and OPTCL

o

Tie ups with reupted agencies for execution of key project related work and
O&M

6.2
•

Opportunities
OPGC Phase III and coal from Integrated Manoharpur and Dipside Manoharpur
coal blocks: OPGC is planning for construction of Phase III having capacity of 2x660
MW. Coal from Integrated mine owned by OCPL having a Peak Rated Capacity of
16MTPA and life of 44years shall be used for the proposed Phase III project.
Further towards Phase III, OPGC has acquired the requisite land, necessary approvals
from GRIDCO has already been sought and other necessary steps have been initiated
by OPGC management towards implementation of the same by FY 2030.

•

Growing domestic demand – In India current power productions levels are not
enough to meet demand. Annual demand outstrips supply by about 7.5%. Demand for
electricity is expected to increase – per capita consumption of electricity is estimated to
be at 1,894.70 TWh by FY22.Various reforms being undertaken by the Government are
positively impacting India’s power sector. In wake of the surging domestic coal
production, the country’s power sector is becoming increasingly stable. Hence,
company’s future plan for executions of Phase III maybe beneficial.

53

<!-- page 54 -->

Part A - Preliminary Information Memorandum

7.

7.1

Odisha Power Generation Corporation Limited

APPENDIX

Appendix I: Audited Financial Statement of OPGC & OCPL

The audited financial statement of OPGC upto FY 2021-22 along with unaudited half-yearly results
of FY 2023 can be accessed at the link below:
https://www.opgc.co.in/fin/a3.asp
The audited financials of OCPL upto FY 2021-22 along with unaudited half-yearly results of FY
2023 can be accessed at the following link:
http://www.ocpl.org.in/Financial.asp

54

<!-- page 55 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

PART B – REQUEST FOR EXPRESSION OF INTEREST

55

<!-- page 56 -->

Part B – Request for Expression of Interest

1.

Odisha Power Generation Corporation Limited

DEFINITIONS

Capitalized terms defined herein shall bear the meaning ascribed thereto in this Request for
Expression of Interest (EOI Request). Additionally, in this EOI Request, unless there is anything
repugnant to the subject or context thereof, the expressions listed below shall have the following
meanings:
“Advisors” shall refer to Transaction Advisor and Legal Advisor
“Associate Company” shall have the same meaning as defined under the Companies Act, 2013,
as amended.
“Affiliate” in relation to a Person (not being a natural person), means any entity or Person, which
Controls, is Controlled by, or is under the direct or indirect common Control of such Person;
“Consortium” shall refer to a group of maximum four (Four) Eligible Entities that have
collectively submitted an EOI in accordance with the provisions of this EOI Request and pursuant
to a consortium agreement entered into amongst them;
"Consortium Member(s)" means an Eligible Entity participating in the Transaction as part of a
Consortium.
“Consortium SPV” means a Company incorporated in India by Consortium Members in the
event it is designated as the Successful Bidder, as more particularly described in Clause 5.1.(3)
“Control” shall have the same meaning as assigned to it in Clause (27) of section 2 of Companies
Act, 2013, as amended
“Definitive Agreements” shall mean agreements to be entered into between Government of
Odisha, the Company and the Successful Bidder, and/or Parent meeting financial criteria on
behalf of the Successful Bidder (in case of a Sole Bidder), SPV / Consortium SPV (as applicable)
and Consortium Members, as the case may be, to effectuate the sale of 49% equity.
"Eligible Entity" shall mean the following domestic or international entity(ies), eligible to
participate in this bid process and submit an EOI in response to and in accordance with this EOI
Request
1. A company incorporated in India under the Indian Companies Act, 1956, or Companies
Act, 2013,;
2. A company incorporated outside India;
3. A limited liability partnership under the Limited Liability Partnership Act, 2008;

56

<!-- page 57 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

4. A limited liability partnership incorporated outside India;
5. SEBI Registered Alternative Investment Funds (AIF);
6. Funds incorporated outside India, which is eligible to invest in India under the laws of
India (subject to such parties obtaining all statutory approvals from GoI/FIFP/RBI etc. by
themselves)
Eligible Entity mentioned in point 3 to 6 above can only bid as a part of Consortium and not
as a Sole Bidder.
“Expression of Interest or EOI” shall mean and include any document submitted by an Interested
Bidder, in response to this EOI Request, in accordance with the terms and conditions as set out
herein
“Fee” shall mean a non -refundable fee of Rs.5 (Five) Lakhs, to be submitted by the Interested
Bidder alongwith the EOI, in the form and manner prescribed in Clause 4.3. It is clarified that no
Invoice/ GST Credit would be provided for the Fee.
“Governmental Authority” shall mean any government authority, statutory authority,
government department, agency, commission, board, tribunal or court or other law, rule or
regulation making entity having or purporting to have jurisdiction on behalf of the Republic of
India, State of Odisha or any state or other subdivision thereof or any municipality, district or
other subdivision thereof.
“Government or GOO” shall mean Department of Energy, Government of Odisha
“Government Company(ies)” shall have the meaning ascribed thereto under the Companies Act,
2013.
“Grave offence” for this purpose shall include
a) SEBI / RBI orders which directly relate to “Fraud” as defined under the provisions of the SEBI
Act, 1992 / RBI Act, 1934 and any of the regulations made thereunder, each as amended from time
to time;
b) SEBI orders which cast a doubt on the ability of the IB to hold the stake in Company;
c) Any conviction by a court of law in India or abroad;
d) Where SEBI has issued an order of prosecution against the IB, disqualification will arise only
on conviction by court of law.

57

<!-- page 58 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

“Group Company(ies)” means a company(ies) which is/are an Affiliate of another company.
“Interested Bidder or IB” shall mean an Eligible Entity, submitting the EOI, either independently
or collectively as a Consortium. For avoidance of doubt the term IB will also include collectively
all Consortium members and/or any SPV incorporated by the Consortium/IB. Any reference to
an Interested Bidder shall include its successors and permitted assigns, as the context may require
“Lead Member” shall mean such Consortium Member holding at least forty percent (40%) equity
shareholding on a fully diluted basis ( i.e. holding at least 40% of in the equity shareholding on a
fully diluted basis of the Consortium SPV) and is designated as Lead Member as per the
Consortium Agreement executed among all the Consortium Members.
“Legal Advisor” shall mean Cyril Amarchand Mangaldas
“OPGC” means Odisha Power Generation Corporation Limited, the Company wherein 49%
equity stake is proposed to be divested in the current transaction.
“Parent” means the entity into which the accounts of the IB/Consortium Member are
consolidated.
"Person" means any individual, company, firm, association, trust, or any other organization or
entity (including the Government and any governmental or administrative subdivision).
“Place of Effective Management” shall have the meaning ascribed thereto in the Finance Act,
2015 to be determined in accordance with guidelines issued by Central Board of Direct Taxes
vide F. No. 142/11/2015-TPL dated January 24, 2017.
“Promoter” shall have the same meaning as defined under the Companies Act, 2013 and the
Securities and Exchange Board of India (Issue of Capital and Disclosure Requirements)
Regulations, 2018, as amended.
“Promoter Group” shall have the same meaning as defined under the Securities and Exchange
Board of India (Issue of Capital and Disclosure Requirements) Regulations, 2018, as amended.
“RBI” means Reserve Bank of India.
“Request for Expression of Interest or EOI Request” means this request for expression of
interest together with the annexures and documents referred herein, including the Preliminary
Information Memorandum and any addenda to this EOI Request.
“SEBI” means Securities Exchange Board of India.
“Shortlisted Bidders” shall refer to all those IBs who have been shortlisted for participating in
the Stage II of the Transaction, as more particularly described in Clause 3.2.A. (iii).

58

<!-- page 59 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

“Subsidiary company or Subsidiary (ies)” shall have the same meaning as assigned to it in
Clause (87) of section 2 of Companies Act, 2013 as amended.
“Successful Bidder” shall mean the Shortlisted Bidder that is finally selected in accordance with
Clause 3.2.B to enter into Definitive Agreements.
“Transaction” shall mean disinvestment of 49% equity stake in the Company.
“Transaction Advisor” shall mean SBI Capital Markets Ltd.

59

<!-- page 60 -->

Part B – Request for Expression of Interest

2.

2.1

Odisha Power Generation Corporation Limited

INTRODUCTION

Transaction Background

Odisha Power Generation Corporation Limited (“OPGC” or “the Company”) was incorporated
on November 14, 1984 with the main objective of establishing, operating & maintaining thermal
power generating stations. OPGC as a part of its maiden venture had set up 2 x 210 MW (Phase
I) thermal power station at Banaharpalli (IB Thermal Power Station) in the district of Jharsuguda
(Odisha). The first unit of Phase 1 commenced operations in 1994 while the second unit of Phase
1 commenced operations in 1996. OPGC thereafter expanded Phase II ( Unit 3 and 4) of 660 MW
each (total capacity of 1320 MW Phase II) in the vicinity of the existing plant. Unit 3 achieved
COD in July 2019 and Unit 4 achieved COD in August 2019.
OPGC procures coal for Phase I (Unit 1 and 2) through Coal Supply Agreement with Mahanadi
Coal Fields Limited (MCL) wherein coal is supplied from Lakhanpur Coal mines. The Coal
Supply Agreement is for supply of 2.7 MMT of Coal per year till FY 2029. Coal Requirement for
OPGC Phase II (Unit nos 3 &4) iwill be met from the captive coal blocks of Odisha Coal and
Power Limited (OCPL) and the same is currently in force. Odisha Coal and Power limited (OCPL)
incorporated in the year 2015. As on December 31, 2022, OCPL’s shareholding is held by OPGC
having 51% shareholding and Government of Odisha having 49% shareholding. OCPL is
engaged in mining and extraction of coal for supplying it to the thermal power plants of OPGC.
OCPL has been allocated with two coal blocks, namely Manoharpur and Dip-side of Manoharpur
by Ministry of Coal, Government of India. The coal blocks are located in IB Valley coalfield in
Sundargarh District, Odisha
OPGC has 100% PPA with GRIDCO for Phase I valid till 30.06.2026. For Phase II, OPGC has PPA
with GRIDCO for power generated in excess of 75% of PLF which would be sold to GRIDCO till
31.03.2023. The balance 25%, is to be sold in short term market through GRIDCO till 31.03.2023.
From April 2023 onwards, 100% of the power to be directly sold to GRIDCO for a period of 25
years.
OPGC is contemplating expansion of its present capacity through implementation of Phase III by
installing Units 5 & 6 having capacity of 660 MW each. OCPL has extractable reserve of 636
Million Metric Tonnes (MMT) and its peak rated capacity is 16 MMT per year, which is sufficient
to meet the requirement of 4x660 MW units for more than 40 years. Common Infrastructure, Land
for expansion of plant and the Merry Go Round (MGR) system are in the possession of OPGC.
OPGC is currently held 100% by Govt of Odisha. The Department of Energy, Government of
Odisha has decided for disinvestment of 49% equity shareholding of OPGC to a technically and
financially capable buyer, identified through a two-stage procedure.

60

<!-- page 61 -->

Part B – Request for Expression of Interest

2.2

Odisha Power Generation Corporation Limited

Contact Details

All enquiries related to the Transaction should be addressed to the following representatives of
SBICAP at common email id OPGC.disinvest@sbicaps.com:
Mr. Arun Kumar Jain
Senior Vice President & Head
Kolkata Regional Office
SBI Capital Markets Ltd.
Contact : 033 – 2302 3243
OPGC.disinvest@sbicaps.com
All such enquiries should be emailed not later than the date mentioned in Clause 2.3. All
communications shall clearly bear the following identification/ title:
"Queries/ Request for Additional Information: PIM for Disinvestment of Odisha Power
Generation Corporation Limited”
Interested Bidders (IBs) should note that all correspondence, enquiries, clarifications in relation
to the Transaction should be routed and addressed only to the Transaction Advisor at the above
mentioned e-mail address. Neither members of OPGC nor Government of Odisha shall be
responsible in any manner to reply to any communication directly to the IBs or to respond to any
communication sent directly to them by the IBs. All responses to queries will be provided without
revealing the source of the query. Further, members of OPGC or Government of Odisha reserve
the right to not respond to queries or clarifications sought and to not provide information in
addition to the information provided herein.

2.3

Important Dates

Table 2-1: Important Dates
Event

Date

Publication of Advertisement, Floating of EOI Request and PIM

January 17, 2023

Last Date for invitation of Queries through email/ physically

February 01, 2023

Last date & time for Submission of EoIs physically at Kolkata office (Due

February 28, 2023

Date)
Note: Please refer Section 4.3 below for mode of Submission of EoI ; The above dates may change at the
discretion of GOO and the detailed dates and schedule for subsequent activities shall be provided in RFP

2.4

Contents of EOI Request

1) An advertisement has been issued in the newspapers inviting IBs to submit their EOIs to
participate in the Transaction. A copy of the advertisement is enclosed as Annexure 9.

61

<!-- page 62 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

2) This EOI Request contains the following:
a. Brief description of the Transaction
b. Instructions to Interested Bidders
c.

Eligibility criteria

d. Conditions/ Circumstances which may lead to Disqualification of IBs
e. Format of EOI Letter
f.

Form A (forming an integral part of EOI Letter)

g. Format of General Power of Attorney
h. Format of Power of Attorney in favour of Lead Member
i.

Format for Consortium Agreement

j.

Confidentiality Undertaking

k. Format of Affidavit
l.

Format of Declaration/ Disclosure with respect to order/ pending investigation
/proceedings by any Court/ regulatory authority

m. Advertisement inviting EOI
n. Undertaking by the Parent (in the event Sole IB meets Financial Criteria through Parent)
o. Format of Certificate of Shareholding Pattern
p. Format of Certificate for Eligibility for Participation
q. Format of Certificate of Fulfilment of Financial Criteria
r.

Format of Certificate of Fulfilment of Technical Criteria

3) This PIM and EOI Request along with annexures have been uploaded on websites of OPGC
at

www.opgc.co.in,

Department

of

Energy,

Government

of

Odisha

at

www.energy.odisha.gov.in and Transaction Advisor at www.sbicaps.com. Following receipt
of EOI Request, Interested Bidders are required to respond in the format as detailed in this
EOI Request along with a non-refundable Fee as detailed in Clause 4.3.

2.5

Clarification

Any queries or request for clarification/additional information concerning this EOI Request shall
be submitted on the letterhead of the IB duly signed by its authorized signatory physically at the
below mentioned address or the scanned copy of such a letter shall be mailed at
OPGC.disinvest@sbicaps.com , not later than the date mentioned in Clause 2.3.

Mr. Arun Kumar Jain
Senior Vice President & Head
Kolkata Regional Office

62

<!-- page 63 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

SBI Capital Markets Ltd.
9thFloor, Jeevandeep Building
1, Middleton Street
Kolkata – 700071
1) The communications shall clearly bear the following identification/ title:
"Queries/ Request for Additional Information: PIM for Disinvestment of Odisha Power
Generation Corporation Limited”
2) All queries or request for clarification/additional information should be sent in the following
format:
S. No.

Clause No.

Clarification/

Additional Rationale

Information required

for

clarification

additional information required

Bidders are requested to note at the time of submission of queries that due diligence related clarificatory
matters would be taken up in Stage II of the Transaction by TA, Company

63

or

<!-- page 64 -->

Part B – Request for Expression of Interest

3.

3.1

Odisha Power Generation Corporation Limited

TRANSACTION

Salient Features of Transaction

The broad terms of the Transaction are detailed as below:
1) OPGC operates a thermal power station across two phases having capacities of 2x210 MW
(Phase I) and 2x660 MW (Phase II) at Banaharpalli (IB Thermal Power Station) in the district
of Jharsuguda (Odisha).
2) The Department of Energy, Government of Odisha has decided for disinvestment of 49%
equity shareholding of Odisha Power Generation Corporation Limited (OPGC) which is
currently held 100% by by GoO. The shareholding will be disinvested to a technically and
financially capable buyer, identified through a two-stage procedure.
3) The Shortlisted Bidders would be required to quote on an Equity Value basis for 49%
shareholding of OPGC.

3.2

Process for the Transaction

The process for the Transaction has been divided into two stages, as detailed below:
A. Stage I:
i.

Through this EOI Request, GOO is providing the Interested Bidder with instructions for
submitting its Expression of Interest to the Transaction Advisor, which would be used for
prequalifying the Interested Bidder in accordance with the criteria specified herein in
order to proceed with the Transaction.

ii.

The EOIs will be evaluated based on the Eligibility Criteria and Disqualification
conditions detailed in this EOI Request.

iii.

The Interested Bidders which qualify in accordance with the terms of this EOI Request
and are shortlisted to proceed with the Transaction, shall be referred to as the “Shortlisted
Bidders”. The Transaction Advisor would directly advise the Interested Bidder regarding
their qualification as ‘Shortlisted Bidder” in due course.

iv.

The Interested Bidder would also have to submit a Demand Draft of Rs.5,00,000 (Rupees
Five Lakh Only) towards non-refundable fee drawn in favour of “SBI Capital Markets
Limited – Fee for EOI”, payable at New Delhi. Alternatively, NEFT transfer may be made
to following account of SBI Capital Markets Limited:

64

<!-- page 65 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

Name: SBI Capital Markets Limited – Fee for EOI
A/c No: 37340369409
IFSC: SBIN0004803
Branch Address: SBI, Overseas Branch, Jawahar Vyapar Bhawan, Delhi 110 001

B. Stage II:
i.

The Shortlisted Bidders will be provided access to virtual data room (VDR) and also be
allowed site visit for conducting a due diligence on the Company. Draft Definitive
Agreement (s) would also be shared with Shortlisted Bidders which shall provide further
details of the Transaction subject to the IB having satisfactorily entered into a
confidentiality undertaking (at the time of submission of EOI).

ii.

The Shortlisted Bidders would be required to undergo a transparent bidding process for
acquisition of 49% shareholding of OPGC, in accordance with the terms of the Request
for Proposal (RFP) which would be shared at the time of calling for financial bids.

iii.

The Shortlisted Bidders shall be required to deposit an earnest money (in the nature of
Payment Security Bank Guarantee) at Stage II and the quantum would be advised as part
of RFP.

iv.

Site visit (cost of which will be borne by the Shortlisted Bidders) would be scheduled to
facilitate the Shortlisted Bidders in their assessment of the Plant at the discretion of the
Company. The modalities related to the visit and due diligence will be informed by
Transaction Advisor to Shortlisted Bidders separately.

v.

The Shortlisted Bidders shall carry out their own due diligence, independent assessment
and appraisal of the plant and the Transaction. The Company or their respective
consultants, agents, officials, Advisors and employees make no representations, in
relation thereto and shall not be liable in any manner whatsoever.

vi.

The financial bids shall be submitted by the Shortlisted Bidders in the manner to be
provided in the RFP.

vii.

Setting up of Reserve Price – The GOO shall set up the reserve price for the Transaction
after the receipt of the financial bids, but prior to opening of the financial bids. The reserve
price shall be confidential and shall not be known to bidders.

viii.

The Shortlisted Bidder, after approval of the GOO, would be designated as the
“Successful Bidder”.

65

<!-- page 66 -->

Part B – Request for Expression of Interest

4.

4.1

Odisha Power Generation Corporation Limited

INSTRUCTIONS TO INTERESTED BIDDERS

General Conditions

1) PIM and EOI Request is available for downloading from websites of OPGC at
www.opgc.co.in,

Department

of

Energy,

Government

of

Odisha

at

www.energy.odisha.gov.in and Transaction Advisor at www.sbicaps.com.
2) The documents including this PIM and EOI Request and all attached documents are and shall
remain or become the properties of the GOO and are transmitted to the IBs solely for the
purpose of preparation and submission of an EOI in accordance herewith. IBs are to keep all
data/ information of OPGC (shared as part of the Transaction) as strictly confidential and shall
not use it for any purpose other than for preparation and submission of their EOI/ financial
bid.
3) The Interested Bidders shall bear all costs associated with the preparation and submission of
the EOI and also all costs associated with conducting the due diligence. The
Advisors/GOO/Company shall not, under any circumstances, be responsible or liable for any
such costs, whether direct, incidental or consequential and no cost incurred by the IBs in this
regard shall be borne by the Company, GOO or the Advisors.
4) The Interested Bidders are expected to carry out their own investigations and other
examination in relation to the Transaction before submitting their EOIs.
5) Interested Bidders shall have satisfied themselves of their queries before participating in the
Transaction.
6) Notwithstanding anything to the contrary contained in this PIM, the detailed terms specified
in the Definitive Agreement(s) shall have overriding effect; provided, however, that any
conditions or obligations imposed on the IB hereunder shall continue to have effect in
addition to its obligations under the Definitive Agreement(s).
7) EOIs are liable to be rejected by GOO if IBs fail to meet the qualifying eligibility criteria as
specified in section titled ‘Eligibility Criteria’ and/or are disqualified in accordance with the
conditions specified in section titled ‘Disqualifications’ in this EOI Request or for any other
reason deemed fit, or even without assigning any reason whatsoever.
8) GOO reserves the right to modify/postpone/cancel or call off the Transaction without
communicating any reasons whatsoever. In such an event no financial obligation whatsoever
shall accrue to GOO, the Company, the Advisors or any of their respective officers,
employees, Advisors or agents.

66

<!-- page 67 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

9) The GOO/ Company/ Advisors, and their respective officers, employees and agents or
Advisors shall not be liable for any omission, mistake or error in respect of any of the above
or on account of any matter or thing arising out of or concerning or relating to the PIM or the
EOI process, including any error or mistake therein or in any information or data given by
the Transaction Advisor.
10) The GOO/ Company/ Advisors reserves the right not to respond to questions raised or
provide clarifications sought, at their sole discretion if considered inappropriate or prejudicial
to do so or even otherwise. Nothing contained in this document shall be taken or read as or
construed or deemed as compelling or requiring the GOO/ Company/Advisors to respond to
any question or to provide any clarification to the IBs. No extension of any time and date
referred to in this EOI Request shall be granted on the basis or grounds that the GOO/
Company has not responded to any question/ provided any clarification.
11) Notwithstanding anything contained in this EOI, the GOO reserves the right to reject any or
all EOIs on the grounds of national interest, national security, public interest or any other
grounds without communicating any reasons thereof and without any liability or any
obligation for such rejection.

4.2

Amendment to EOI Request

At any time prior to the Due Date for submission of EOI, GOO may, for any reason, whether at
its own initiative or in response to clarifications requested by any Interested Bidder, modify this
EOI Request by the issuance of an addendum. Any addendum/clarification issued shall be
uploaded on websites of of OPGC at www.opgc.co.in, Department of Energy, Government of
Odisha at www.energy.odisha.gov.in and Transaction Advisor at www.sbicaps.com.
In order to afford the Interested Bidders a reasonable time for taking an addendum into account,
or for any other reason, GOO may, in their sole discretion, extend the Due Date for submission
of EOI.

67

<!-- page 68 -->

Part B – Request for Expression of Interest

4.3

Odisha Power Generation Corporation Limited

Submission of Expression of Interest
a) The Expression of Interest (EOI), conforming to the conditions of this EOI Request shall
be submitted physically along with all annexure(s) duly filled in, in original, at following
address on or before the scheduled date and time mentioned in Clause 2.3.
Mr. Arun Kumar Jain
Senior Vice President & Head
Kolkata Regional Office
SBI Capital Markets Ltd.
9th Floor, Jeevandeep Building
1, Middleton Street
Kolkata – 700071
b) EOIs shall be submitted during the working hours (Monday to Friday 10:00 a.m. to 5:00
p.m.) on or before scheduled date and time as stipulated in Clause 2.3.
c) Submission of the EOI by any other electronic means/ email and/ or facsimile, etc. will not
be accepted.
d) The completed forms, “Annexures” of the bid shall be considered a part of the Definitive
Agreements in the case of Successful Bidder.
e) The EOIs received after the appointed time and date at Clause 2.3 will be rejected.
f)

The Interested Bidder shall submit the EOI physically by mentioning the page number on
each document and to be submitted in sequence in a sealed, covering envelope clearly
marked “Private and Confidential – Expression of Interest for the Disinvestment of
Odisha Power Generation Corporation Limited” in different file folders as per the
following directions:
Covering envelope:
Envelope 1:
1. Demand Draft of Rs.5,00,000 (Rupees Five Lakh Only) towards non-refundable fee
drawn in favour of “SBI Capital Markets Ltd. –Fee for EOI”, payable at New Delhi.
Or NEFT in favour of following account of SBI Capital Markets Limited:
Name: SBI Capital Markets Limited – Fee for EOI
A/c No: 37340369409

68

<!-- page 69 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

IFSC: SBIN0004803
Branch Address: SBI, Overseas Branch, Jawahar Vyapar Bhawan, Delhi 110 001
Note: In case of NEFT Transaction, please provide details of NEFT UTR as part of Envelope 1
Envelope 2:
2. EOI Letter in the format specified in Annexure 1.
3. Duly filled in Form A by IB/ each Consortium Member in case of a Consortium/ IB
and the Parent of the Sole Bidder in the event IB is a Sole Bidder meeting any of its
Eligibility Criteria through its Parent as per Annexure 2, including the following
major supporting documents:
a. Executive summary providing brief description for the IB and (where applicable)
for each Consortium Member, IB and the Parent of the Sole Bidder in the event IB
is a Sole Bidder meeting any of its Eligibility Criteria through its Parent,
containing details like Ownership Structure, Identity of the natural persons who
are the ultimate beneficial owners of the IB/ each Consortium Member, the Place
of Effective Management of business of the IB/ Parent of Sole Bidder and each
Consortium Member (“Place of Effective Management” means the place where
key management and commercial decisions that are necessary for the conduct of
business of an entity as a whole are, in substance made.), etc. write up on business
history and growth, business areas / activities, respective revenue details etc., it
shall include a brief commentary on the capability of the IB / IB and the Parent of
the Sole Bidder in the event IB is a Sole Bidder meeting any of its Eligibility
Criteria through its Parent / Consortium Members, as demonstrated, inter alia, in
its past track record, to run its own business.
b. Contact information of the IB/ IB and IB and the Parent of the Sole Bidder in the
event IB is a Sole Bidder meeting any of its Eligibility Criteria through its Parent
/ each Consortium Member including full name, address, telephone and facsimile
numbers, e-mail address and the names and the titles of the persons who are the
principal points of contact for each member and identifying lead Consortium
Member. Details of the website of the IB/ IB and the Parent of the Sole Bidder, in
the event IB is a Sole Bidder meeting any of its Eligibility Criteria through its
Parent / each Consortium Member are also to be provided.
c.

Basic information pertaining to incorporation and commencement of business for
IB/ IB and the Parent of the Sole Bidder, in the event IB is a Sole Bidder meeting
any of its Eligibility Criteria through its Parent / each Consortium Member.

69

<!-- page 70 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

d. Certified true copies of the following documents to be submitted. However, if IB/
IB and the Parent of the Sole Bidder, in the event IB is a Sole Bidder meeting any
of its Eligibility Criteria through its Parent / any Consortium Member cannot
submit any of the following documents, it shall state reasons for the same:
i. Memorandum of Association
ii. Articles of Association
iii. Certificate of Incorporation
iv. Certificate of Commencement of Business
v. Charter Documents
vi. Other Constitution Documents i.e. Partnership Deed etc. as may be
applicable
vii. Registration Certificate for AIFs
e. A certificate for list of Board of Directors and key management personnel duly

signed by the respective Company Secretary or any other officer in-charge of
secretarial/legal affairs of IB/ Parent of Sole Bidder in the event IB is a Sole
Bidder meeting any of its Eligibility Criteria through its Parent /Consortium

Member
f.

A

certificate

by

an

independent

chartered

accountant/statutory

auditor/Company Secretary or any other officer in-charge of secretarial/legal
affairs for the shareholding pattern of the IB/ Parent of Sole Bidder in the event
IB is a Sole Bidder meeting any of its Eligibility Criteria through its Parent /each
Consortium Member. (As per Annexure 11)
g. A certificate duly signed by Company Secretary or any other officer in charge of
secretarial/legal affairs, of IB/ IB and the Parent of the Sole Bidder, in the event IB
is a Sole Bidder meeting any of its Eligibility Criteria through its Parent / each
Consortium Member certifying their respective eligibility to participate in the
Transaction. (as per Annexure 12)
h. A statutory auditor certificate (in case IB is a Company)/ independent chartered
accountant certificate (in case IB is not a Company) of IB/ Parent of the Sole Bidder,
in the event IB is a Sole Bidder meeting any of its Eligibility Criteria through its
Parent / each Consortium Member certifying the fulfillment of Financial Criteria
as specified in the Eligibility criteria section. (as per Annexure 13)
i.

A certificate from Company Secretary/ Authorized Representative certifying the
fulfillment of Technical Criteria as specified in the Eligibility criteria section (in

70

<!-- page 71 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

case the same is met through Parent or Subsidiary of Sole Bidder, certificate from
Company Secretary/ Authorized Representative of Parent/ Subsidiary is required
to be submitted) (as per Annexure 14)
j.

Audited Financial Statements (on standalone and consolidated basis)/Annual
Reports for the previous five financial years for complete accounting period of
12 months.
All financial statements/ annual reports/ net worth certificate submitted should
be certified by authorized signatory.
In case the IB/ IB and Parent of Sole Bidder/ any Consortium Member cannot
submit the consolidated financial statements as mentioned above, it shall specify
reasons for the same.

k. Documents such as a board or shareholders’ resolution in favor of the person
executing the Power of Attorney for the delegation of power on behalf of the IB/
Consortium Member. (The date of execution of board or shareholders’ resolution
should be prior to the date of execution of the Power of Attorney)
l.

Management Organization: An overview of IB’s/ IB and the Parent of Sole
Bidder/

each Consortium Member’s senior management and organization

structure certified by the company secretary or any other officer in charge of
secretarial/legal affairs of the IB/ each Consortium Member.
m. International Operations/ Joint Venture/Alliances: Brief note of IB’s/ IB and
Parent of Sole Bidder/ Consortium Member’s international operations, joint
ventures, alliances (whether international or domestic, which the IB considers as
being material (directly or indirectly) to its business and/ or the Transaction),
including incorporation details, registered office, nature and size of such
operations, equity ownership/ effective management and control (as applicable).
n. Details of those companies and professional firms, if any, who are (or will be)
advising the IB/ IB and Parent of Sole Bidder/ Consortium/ Consortium Member
for the Transaction, together with the names of the principal individual Advisors
at those companies and firms.
o. Details of contingent liabilities and outstanding litigations, which if materialised,
would have or would reasonably be expected to have a material adverse effect on
the business, operations (or results of operations), assets, liabilities and/or
financial condition of the IB/ Consortium Member/ IB and Parent of Sole Bidder

71

<!-- page 72 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

(in case reliance is placed upon for meeting eligibility criteria), or other similar
business combination or sale.
p. If the IB/Parent of the IB in case of Sole Bidder/any Consortium Member is a
foreign entity/ overseas corporate body, specify list of statutory approvals from
the Government of India/ the Reserve Bank of India/ Department for Promotion
of Industry and Internal Trade relevant ministry/ any other Government agency,
specifying whether the same is applied for/ to be obtained/ awaited.
4. Undertaking in relation to Ultimate Beneficial Owner (as per Annexure – 1A).
5. Appropriately executed and legally enforceable General Power of Attorney
authorizing the signatory of the EOI to commit the IB/ each Consortium Member (as
per Annexure – 3).
6. Appropriately executed and legally enforceable Power of Attorney authorizing the
lead Consortium Member to do all acts, deeds and things as may be necessary in
connection with the Consortium’s Bid for the Transaction (as per Annexure 4)
7. In case of a Consortium, a Consortium Agreement duly executed amongst each of the
Consortium Members (as per Annexure 5).
8. Duly executed Confidentiality Undertaking (as per Annexure 6).
9. Duly executed Affidavit by IB / Lead Member of Consortium / Parent of Sole Bidder
(as per Annexure 7).
10. Declaration / Disclosure on order/ pending investigation /proceedings by any Court/
regulatory authority (as per Annexure 8).
11. Undertaking by Parent of Sole Bidder (as per Annexure 10)
g) Unless otherwise specified, a copy of any document that is not the original, shall be a
certified true copy (duly verified by a notary) for submission. Documents executed and
issued overseas will also have to be apostilled/ consularised using the procedure as per
applicable law.
h) The EOI and all related correspondence and documents in relation to the EOI shall be in
English language. Any documents that are not in the English language shall be
accompanied by an official translation duly notarized and apostilled/ consularised by the
Indian mission of the home country.

72

<!-- page 73 -->

Part B – Request for Expression of Interest

i)

Odisha Power Generation Corporation Limited

GOO/ Transaction Advisor shall bear no responsibility for non-receipt of documents sent
by post/courier/fax.

j)

Any additional information supplied subsequent to the Due Date of submission of EOI as
prescribed in Clause 2.3, unless the same has been expressly sought for by GOO/
Transaction Advisor, shall be disregarded.

k) EOIs shall be opened only after the due date and time of submission of EoIs.

4.4

Evaluation of EOI

1) Any condition or qualification or any other stipulation contained in the EOI shall render the
EOI liable to rejection as a non-responsive EOI.
2) The GOO reserves the right to call for any additional document (s)/ information / physical
copies of any document from the IBs, which may be considered necessary, without any
liability to the Company.
3) The Transaction Advisor may seek appropriate clarifications from the IB, if required, while
examining the EOI.
4) The GOO reserves the right to verify all statements, information and documents submitted
by the IB in response to the EOI Request, or the EOI process and the IB shall, when so required
by the GOO, make available all such information, evidence and documents as may be
necessary for such verification. Any such verification or lack of such verification, by the GOO
shall not relieve the IB of its obligations or liabilities hereunder nor will it affect any rights of
the GOO thereunder.

4.5

Governing Law / Jurisdiction

1) This EOI Request and all matters incidental hereto shall be governed by and construed in
accordance with the laws of India. All disputes arising out of and in connection herewith shall
be subject to the exclusive jurisdiction of the courts at Mumbai.

73

<!-- page 74 -->

Part B – Request for Expression of Interest

5.

5.1

Odisha Power Generation Corporation Limited

ELIGIBILITY CRITERIA

Eligibility Criteria
The Eligibility Criteria for the IBs are as follows:
1) Incorporation Criteria:
a. Any Eligible Entity which is permitted to invest under the laws of India (subject to such
entity obtaining all statutory approvals by themselves from the GOI, Department for
Promotion of Industry and Internal Trade, RBI, relevant ministry etc. as applicable) can
submit an EOI either independently or as a Consortium Member. (“Interested Bidder”)
b. No IB shall submit more than one EOI. An IB submitting EOI independently or as a
Consortium Member shall not be entitled to submit another EOI either independently or
as a member of any other Consortium, as the case may be.
c.

The ultimate beneficial owner for any IB should not be the same as that of any other IB or
of any Consortium Member. In case of a Consortium, the ultimate beneficial owner of any
member of the Consortium should not be the same as that of any member of any other
Consortium or that of any sole bidder. In this regard, the IB/consortium member shall
submit an undertaking in form of Annexure 1A.
Note: “Ultimate Beneficial Owner” shall have the same meaning as “significant beneficial
ownership” defined in the Companies (Significant Beneficial Owners) Rules, 2018 (as amended).
In case of any IBs who are funds (including alternate investment funds), ultimate beneficial owner
would mean the investment management entity which manages the investments of the fund and
not the investors who have invested in the fund.

2) Financial Criteria:
The Interested Bidder shall satisfy the following financial criteria:
a. Net-worth: The Interested Bidder should have a Minimum Net-worth of Rs.2500 Crore
or USD 330 Mn (Rs/$ conversion of 75.8071considered as per FBIL https://fbil.org.in/ as
on 31.3.2022) as per the latest full accounting period audited balance sheet which shall
not be as of a date earlier than 31st December 2021. For avoidance of doubt, it is clarified
that the net worth of a Sole Bidder will be considered on a consolidated basis. If a Sole
Bidder is found to be satisfying net worth criteria on the basis of its Parent’s net worth,
the consolidated net worth of its Parent will be considered.
Explanation: Net-worth shall mean

74

<!-- page 75 -->

Part B – Request for Expression of Interest

•

Odisha Power Generation Corporation Limited

In case of a company– “Net-worth” shall be calculated as the aggregate value of the paidup share capital (including equity and preference share capital in nature of equity), and all
reserves created out of the profits and securities premium account, after deducting the
aggregate value of the accumulated losses, deferred expenditure, Intangible Assets,
redemption reserves, reserves made for any specific purpose, miscellaneous expenditure not
written off as per the latest full financial year audited balance sheet which shall not be as of a
date earlier than 31st December 2021, but does not include reserves created out of revaluation
of assets, write-back of depreciation and amalgamation.
Further, the cross holding of investments amongst the Consortium Members is also to be
deducted where the IB is a Consortium. It is clarified that Cross holding refers to investment
of any 1 Consortium Members in other Consortium Member and/or vice versa. Aggregate
cross holding of all Consortium Members would be deducted where the IB is a Consortium

•

In case of LLP - “Net-worth” shall be calculated as Partners’ Capital and all reserves created
out of the profits, after deducting the aggregate value of the accumulated losses, deferred
expenditure, Intangible Assets, redemption reserves, reserves made for any specific purpose
and miscellaneous expenditure not written off, as per the latest full financial year audited
balance sheet which shall not be as of a date earlier than 31st December 2021, but does not
include reserves created out of revaluation of assets, write-back of depreciation and
amalgamation. Further, the cross holding of investments amongst the Consortium Members
is also to be deducted where IB is a Consortium.

•

In case of AIF/ Fund – Net worth shall be considered as committed capital or 0.25 times of
Assets Under Management.
In case AIF forms the consortium with its investee company, adjustment for cross holdings
shall be carried out in determination of Net Worth of AIF.

b. Revenue: The Interested Bidder should have Revenue of at least Rs. 3,500 Crore in
each of the immediately preceding three audited full accounting period.
Explanation: Revenue shall mean Net sales from Operations
If a Sole Bidder is found to be satisfying Networth criteria on the basis of its Parent’s Networth,
the Revenue of its Parent will be considered.

75

<!-- page 76 -->

Part B – Request for Expression of Interest

c.

Odisha Power Generation Corporation Limited

Profitability: The “Cash Accruals” of the Interested Bidder must be ‘positive’ in at
least three (3) of the immediately preceding five (5) audited full accounting period.
Explanation: Cash Accruals shall mean Profit after Tax plus Depreciation and Amortization.
If a Sole Bidder is found to be satisfying Networth criteria on the basis of its Parent’s Networth,
the Cash Profit of its Parent will be considered.

d. Financial Criteria shall be assessed on the basis of:
i.

In case of entities other than AIFs:
•

Audited financial statement of an Interested Bidder (on consolidated basis),
for full financial year (and not partial accounting period) which shall not be
as of a date earlier than 31st December 2021.

•

If the audited financial statements are not available for the immediately
preceding financial year, unaudited/provisional numbers as certified by the
statutory auditors (in case of an unlisted company) or information
contained in Quarterly Limited Review report(in case of a listed company)
shall be considered.

•

The Financial Criteria should be certified by a statutory auditor (in case of
a company) or an independent chartered accountant (in case of other
Eligible Entities).

ii.

In case of AIFs/ Funds: A certificate from Statutory Auditor or an independent

chartered accountant certifying Assets Under Management or Committed
Capital shall be submitted. Certificate should not be older than 3 months from the
date of EOI Request.
e. Where the financial statements are expressed in a currency other than the Indian Rupee,
the eligible amount as described above shall be computed by taking the equivalent
amount at the exchange rates prevailing on the dates of such financial statement as
stipulated by Reserve Bank of India/ Financial Benchmarks India Limited (FBIL). All
financial information required for satisfying the eligibility criteria shall be represented
in Indian Rupees.
f.

The Financial Eligibility criteria may be satisfied either by the IB or its Parent (in case
of Sole Bidder only). It is clarified that in addition to the eligibility requirement on
Ultimate Beneficial Ownership, two or more IBs cannot use financial strength of the

76

<!-- page 77 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

same Parent. Such Parent in addition to the documents stipulated in this EOI Request
may be required to sign Definitive Agreement(s) or other additional documents and
compliance with lock in requirement as may be specified in the RFP.
g. Only Sole Bidder is allowed to rely on Parent Net worth, Revenue, Profitability for
qualification.

h. The combined / cumulative Net Worth of the Consortium should meet the minimum
Net Worth criteria mentioned, calculated as follows:

Net Worth of the Consortium = [(Net Worth of Lead Member) + (Net Worth of member
2) + (Net Worth of member 3) + (Net Worth of member 4)].
3) Technical Criteria:
a) The Technical Criteria can be met by:
i.

The Interested Bidder, or

ii.

Parent Company of the Sole IB, or

iii.

Subsidiary over which Interested Bidder exercises direct or [indirect Control]

b) Minimum five (5) years of experience of running an operational Thermal Power Plant
of minimum of 2000 MW (Captive Power Plant or Independent Power Plant).
Note: In case Sole Bidder is placing reliance on Parent for meeting financial criteria, Technical
Criteria cannot be met through Subsidiary over which Sole Bidder/Interested Bidder exercises
direct or indirect control

4) Conditions for bidding by Consortium:
Eligible Entities are permitted to form a Consortium to participate in the Transaction. The
maximum number of members, including Lead Member, in a consortium should be [4 / four].
A member of a consortium cannot participate simultaneously as a part of another consortium
or as a sole bidder.
a. Lead Member: The Consortium shall have only one (1) Lead Member.
b. Minimum stake requirement:

77

<!-- page 78 -->

Part B – Request for Expression of Interest

i.

Odisha Power Generation Corporation Limited

Lead Member shall hold at-least 40% equity shareholding on a fully diluted basis
in the Consortium (i.e. holding at least 40% equity shareholding on a fully diluted
basis of the Consortium SPV to be promoted in case it becomes the Successful
Bidder)

ii.

Each Consortium Member shall hold at least 10% equity shareholding on a fully
diluted basis in the Consortium (i.e. holding at least 10% equity shareholding on
a fully diluted basis of the Consortium SPV to be promoted in case it becomes the
Successful Bidder)

iii.
c.

Consortium Member cannot rely on Parent for meeting financial criteria

Financial Criteria
i.

Net-worth:
•

Where IB is a Consortium, the Combined Net-worth of all the Consortium
Members should meet the Minimum Net-worth Criteria as mentioned in
Clause 2(a) above.

Explanation: Combined Net worth = (Net-worth of Lead Member) + (Net-worth of
Member 2) + (Net-worth of Member 3) + (Net-worth of Member 4)
•

The Lead Consortium Member shall have a Net-worth contribution, of at least
40%, towards the calculation of Minimum Net-worth for testing its eligibility

Explanation: Lead Member should have Net Worth of at-least 40% of the Minimum
Net-worth Criteria as mentioned in Clause 2(a) above i.e. 40% of Rs. 2500 crore i.e. Rs
1000 crore or 40% of USD 330 Mn i.e. USD 132 Mn (Rs/$ conversion of 75.8071
considered as per FBIL https://fbil.org.in/ as on 31.3.2022).
•

Each Consortium Member shall have a positive Net-worth.

d. Revenue:
Where IB is a Consortium, Lead Member who meets the Technical Criteria, must
meet the Minimum Revenue Criteria as mentioned in Clause 2 (b) above.

78

<!-- page 79 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

e. Profitability Criteria:
Where IB is a Consortium, all Consortium Members (excluding AIF) must meet the
Profitability Criteria as mentioned in Clause 2 (c) above.
f.

Technical Criteria
Where IB is a Consortium, the Technical Criteria stipulated in Clause 3 above, shall
have to be met by the Lead Member of the Consortium.

Illustrative Examples
The following examples illustrate the compliance of IB with Eligibility Criteria. The below
examples are illustrative and solely for the purposes of reference to the IBs and meant for
guidance only.

79

<!-- page 80 -->

Part B – Request for Expression of Interest

Odisha Power Generation Corporation Limited

Table 5-1: Illustrative Example 1: Consortium members and eligibility criteria

Description

% Stake in Consortium (i.e. equity share capital of the Consortium SPV)
Net-worth/ AUM (in case of AIF) (Rs. Crore)
Revenue (Rs. Crore)

Details of Consortium Members
M1 (Lead Member)
M2
M3
M1 is engaged in Thermal
AIF
Non Power Sector Company
Power Generation for the past 5
/LLP
financial years with >2000 MW
capacity
50%
30%
20%
950
4,800
800
>=3,500 in each of immediately
NA
<3,500, in each of
preceding 3 FYs
immediately preceding 3 FYs
(+ve) in 2 out of immediately
NA
(+ve) in 3 out of immediately
preceding 5 FYs
preceding 5 FYs
Eligibility of Members

Cash Profit (+/-)
Eligibility criteria
Technical criteria
Net-worth Criteria
- Combined Net-worth of Consortium to be minimum Rs. 2,500
crore
- Lead Member: Lead Member to have minimum 40% Net-worth
contribution
- Each Consortium Member to have +ve Net-worth

✓

NA

NA

950
4,800
800
Combined Net-worth Rs. 2,950 crore (950+0.25X4,800+800)

NA
NA
NW of 950 < 1,000(40%X 2,500)
✓

✓

✓

Revenue Criteria:
✓
- Alteast Rs. 3,500 crores in each of the immediately preceding 3 FYs
NA
NA
- To be met by Lead member
Profitability Criteria:
- Positive Cash Profit in atleast 3 of the immediately preceding 5

✓
NA
FYs
- To be met by all Consortium members (excluding AIF)
Consortium fails to meet the eligibility criteria for networth and profitability of lead member

80

Eligibility of
Consortium
✓
✓

✓
✓


