---
doc_id: "85fdecfeb4bb731f"
source_url: "https://inpr.odisha.gov.in/sites/default/files/2025-10/15484%202nd%20Corrigendum_1.pdf"
ministry: "Information and Public Relations Department, Odisha"
title: "Download(318.88 KB)"
date: ""
pages: 1
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "582affff7a40e15a"
---

<!-- page 1 -->

Government of Odisha
Information & Public Relations Department
୫୫୫୫
Letter No. RF P-cp-0014-2025/154 84 _apr, BBSR, Date: _ /1]1015155.
TCN No.14220/IPR
Date: 17.09.2025
In continuation of the Tender Notice issued vide no. 14220 Dtd:17.09.2025, it is hereby
informed that point-5 of Eligibility Criteria related to experience of similar work shall
be read as follows:
“The bidder must have executed a minimum work of similar nature (outdoor hoarding)
worth Rs. 3 crores during last 5 years i.e. from 2019-20 to 2023-24 in any Government/
PSUs (State or Central) Projects-executed either directly with them or through
federations such as FICCI, CH, ASSOCHAM ete. for such govt. departments or
PSUs/Corporate Sector (SEBI listed only).”
This corrigendum shall form an integral part of the tender document. All other terms
and conditions of the tender remain unchanged.
Sd]
DIRECTOR
Memo No. tSY85 _/ipr., 889, Datead_tY} | \ of ANAS
Copy forwarded to the PS to Additional Chief Secretary to Govt., | & PR for kind information
of Additional Chief Secretary to Govt., Director (Technical) respectively. A
5
Deputy Sec! ଵେ
Memo No a ୪୯ , 2016 _ ! ଏ ଖେ
Copy forwarded to the System Analyst for information and necessary action. He is requested
to take appropriate steps for uploading the Request for Proposal (RFP) in the website of
Information & Public Relations Department https://inpr.odisha.gov.in/ & website of Govt. /
of Odisha https://odisha.gov.in. er, 5. ୩୬
5
ren
Deputy Secretaryto Govt.
Memo No Sy RG , 0316. | ୯ \6 (0:50
Copy forwarded to the Dy Secretary to Govt. (ADVT) for information and necessary ea
action. He is requested to publish the 2™ corrigendum notice w.r.t. caption No. Z-10 on A
07.10.2025. \e
୦୧
Deputy Secretary to Govt.
