---
doc_id: "bf35de0b0da5b6d6"
source_url: "https://cdnbbsr.s3waas.gov.in/s36832a7b24bc06775d02b7406880b93fc/uploads/2026/10/202610101824980330.pdf"
ministry: "Odisha Joint Entrance Examination (OJEE), Odisha"
title: "SCHEDULE AND INSTRUCTIONS FOR PROVISIONAL ADMISSION TO BAMS/BHMS (2 nd ROUND COUNSELLING)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3fa47abf63ad811d"
---

<!-- page 1 -->

ODISHA JOINT ENTRANCE EXAMINATION - 2026
(OJEE – 2026)
No. OJEE / 0577

Date: 09.10.2026

SCHEDULE AND INSTRUCTIONS FOR PROVISIONAL ADMISSION TO
BAMS/BHMS (2nd ROUND COUNSELLING)
All the candidates, who have got allotment in the 2nd Round must personally report
at the office of Odisha Joint Entrance Examination (OJEE), at Gandamunda,
Bhubaneswar on the notified date and time with all certificates, mark sheets, CLC
and other required documents in original for provisional admission. Go through the
detail instructions mentioned at ‘B’.

A.

REPORTING SCHEDULE:

VENUE: - OJEE OFFICE, GANDAMUNDA, BHUBANESWAR
DATE

14-10-2026
14-10-2026
14-10-2026
14-10-2026
14-10-2026
14-10-2026
14-10-2026
14-10-2026
14-10-2026

COLLEGE ALLOTTED

Dr. Abhina Chandra Hom. Med. College &
Hospital, Bhubaneswar
Utkalamani Homeopathic Med. College &
Hospital, Rourkela
Odisha Medical College of Homeo. &
Research, Sambalpur
Biju Pattnaik Homeo. Medical College &
Hospital, Berhampur
Gopabandhu Ayurveda Mahavidyalaya,
Puri
Government Ayurvedic College, Balangir
Kaviraj Ananta Tripathy Sharma
Ayurvedic College & Hospital, Ankushpur,
Ganjam (KATS)
Sri Sri Nrusinghnath Ayurvedic College &
Research Institute, Paikmal, Bargarh
Sri Sri College of Ayurvedic Science and
Research Hospital, Sri Vihar,
Bidyadharpur, Arilo, Cuttack

STREAM

TIME

BHMS

10.30 AM TO 11.30 AM

BHMS

11.30 AM TO 12.30 PM

BHMS

12.30 PM TO 01.30 PM

BHMS

02.00 PM TO 03.00 PM

BAMS

10.30 AM TO 11.30 AM

BAMS

11.30 AM TO 12.30 PM

BAMS

12.30 PM TO 01.30 PM

BAMS

02.00 PM TO 03.00 PM

BAMS

03.00 PM TO 04.00 PM

<!-- page 2 -->

B.

INSTRUCTIONS:

•

The allotted candidate should exercise the option for Freeze or Float using login id.

•

Admission Fees Rs. 8,500/- must be paid online (using respective login id).

•

Candidates are required to bring all certificates / marksheets / CLC and other
required documents in original (with another set of photocopies) during reporting
for provisional admission at OJEE Office, Gandamunda, Bhubaneswar.

•

On deposit of prescribed admission fees, successful verification of all required
documents and on submission of Nativity Certificate and CLC in original, the
candidate will receive provisional admission letter from OJEE Office along with
acknowledgement of submitted documents.

•

Either the candidate alone or with only one of his / her guardians, should come with
all other necessary documents, to the OJEE Office on the scheduled date and time to
complete the formalities of provisional admission.

•

Candidates are advised not to report at their allotted College at this stage and they
must wait till the entire counselling and admission process is completed.

•

After final counselling is over, OJEE will send the list of admitted students along with
the admission fees to the concerned Institute. The Institutes will, in turn, complete the
final admission.

•

If any amount is to be refunded to the candidates, it will be done after final admission
dates. Refund will be processed by OJEE and paid to the candidate as per Government
procedure.

*NB: IN CASE OF ANY REVISION OF THE FEE STRUCTURE AS PER
GOVERNMENT ORDER, THE SAME SHALL AUTOMATICALLY BE
APPLICABLE.
==============================================================
Sd/Chairman, OJEE
