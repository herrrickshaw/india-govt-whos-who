---
doc_id: "6a5201eabdcaaa0b"
source_url: "https://panchayat.odisha.gov.in/sites/default/files/2026-03/5th%20SFC%20GIA%20GUIDELINES.pdf"
ministry: "Panchayati Raj & Drinking Water Department, Odisha"
title: "Download(3.97 MB)"
date: ""
pages: 36
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "58e3bbc0d98ca00c"
---

<!-- page 1 -->

ee Us. ,=୩୬୬- ଓଡିଶା ସରକାର ଓଡିଶା ଲୋକସେବା ଭବନ
` CBR? ® 64 TPDAIAS AG B ପାନୀୟ ଜଳ ବିଭାଗ ` eesaeoe
| ’ pa . va KO GOVERNMENT OF ODISHA ey Odisha Lokseva Bhawan
। SE ୯୮୩୦ PANCHAYAT ॥& & ଠନା/ାପ6 WATER, `° ୩୭୩୩ ୟା, 5) 0:୭୩୨୭୪୭୮୧୫ 001
ae DEPARTMENT
No__NVABIR ` / Date ୯୯୪ OA, BOBO
PR-SFC-SCHEME-0010-2020
From
Shri Deoranjan Kumar Singh, IAS
Principal Secretary to Government.
To
All Collectors
All Project Directors, DRDAs
Sub:- Comprehensive Guidelines on Utilization of Grants-in-Aid under
different components as recommended by the 5" State Finance
Commission for the period from 2020 - 21 to 2025 - 26 (6 years).
Madam / Sir,
In inviting a reference to the Subject cited above, | am directed to say that
taking into account the local needs, the 5" State Finance Commission has
recommended Grants-in-Aid for the following sector specific need of the Local
Bodies and Subsequently, the State Government have also accepted the
same in the ATR on recommendations of 5" State Finance Commission.
The comprehensive Guidelines for Utilization of each of Grants-in-Aid are
given below. The objective and the mode of release of funds are mentioned
separately under each Grant-in-aid, whereas the provisions for Maintenance
of Accounts & Audit, Monitoring and Supervision, Submission of Utilisation
Certificate and Social Audit are applicable to all the Grants-in-aid.
PAGE REFERENCE
/Sl.| Grants-in-Aid (Component wise) ` | Page ‘|
No
| _ |
1 | Drinking Water (Piped Water Supply) & Tubewell System 2-4
\_|GolarEnegy) ୮୮୮୭ ୧ Tee |
2 | Allweather connectivity .‰_‰_‰__%__© ae See
| 3 | Provision of facilities at G.P. headquarters ` ଏ | 25 ¬
¢-{Provision of Street ୮୦୨୭ ୭୩୦
। 5 [Development of Rural ଳା 122 1]
0 6 [Maintenance of Capital Assets [43-14]

<!-- page 2 -->

(2)
|_7_| Maintenance of Primary School Buildings _ | 15-16
8 | Preservation and development of Water Bodies 17-18
9 | Creation of capital assets for revenue generation. ___ 19-20 |
10 | Funds for innovative practices _ 21-22
11_| Creation of Data Centres ୂ 23 - 24
12 | Creation of infrastructure for Banking facilities at GP 25 - 26
headquarters. _ -
I. DRINKING WATER (PIPED WATER SUPPLY) &
TUBE WELL SYSTEM ( SOLAR ENERGY) :
On the recommendations of 5th State Finance Commission and the Action
Taken Report thereof, Government have decided to allocate a sum of
Rs.750.00 crore for pipe water supply and Rs.250.00 crore for installing solar
energy based tube well system with overhead tank for the period from 2020-
21 to 2025-26. The yearwise break up of pipe water supply and tube well
system (Solar Energy) is given below:
YEARWISE FUND ALLOCATION
| (Rs.in Crore)
COMPONENT | 2020-21 | 2021-22 | 2022-23 | 2023-24 | 2024-25 | 2025-26 | 2020-26
_PWS Projects 125.00 | 125.00 | 125.00 125.00 ` 125.00 125.00 750.00
Tube well
system (Solar 41.66 | 41.66 41.67 41.67 41.67 41.67 250.00
jenergy) | | _ ` ] ` |
a. Objective:

The drinking water sector in rural areas is largely dominated by hand
pumps though pipe water supply schemes have been executed in some
areas. However, the major challenges witnessed in this sector are the
problems of salinity, fluoride, chloride and iron, affecting the ground water and
surface water in some cases. The Commission has recommended Rs. 750.00
crore to take care of water stressed pockets. Besides, there is a requirement
of meeting drinking water needs in small villages/hamlets having population of
less than 100. The Commission also recommended Rs.250.00 Crore for
installing solar energy based tube well system with overhead tank for drinking
water facility to small villages/hamlets having acute water scarcity.

eee

<!-- page 3 -->

: (3)

b. Mode of Release of fund:

(i) The Grants-in-aid earmarked for “Drinking water (PWS)" and “Tube
well system (Solar energy)" will be released to the EIC, RWSS in two
instalments, one in April/May and the other in October/November,
by the Department with the Condition that the EIC, RWSS has to
prepare the Annual Action Plan and furnish the same to PR&DW
Department for approval & release of funds

(ii) The Grants-in-aid “Drinking water (PWS)" is to be utilised in water
stressed pockets having problems of Salinity, fluoride, chloride and
iron, affecting the ground water and surface water and the Grants-in-
aid “Tube well system (Solar energy)” is to be utilised to meet drinking
water needs in small villages/hamlets having population of less than
100.

(iii) After approval of Projects by the Department, EIC, RWSS will be
responsible for implementation of the work through the concerned
Executive Engineer and submission of utilization certificate.

(iv) The allotment will be in favour of the concerned Executive Engineer.

(v) Works expenditure and accounts of the projects is to be routed through
works expenditure module of IFMS. The fund transferred to Executive
Engineers is required to be remitted to Treasury under Major Head
8782 and the particulars of the deposit with reference to the Challan
are to be entered in IFMS. Thereafter, the Work ID is to be created in
IFMS and the same work is to be created in WAMIS wherein the work
ID of IFMS is fetched in WAMIS.

(vi) All payments are to be made in IFMS.

(vii) On account release of fund for the 1st instalment will be made. While
releasing the 2"° instalment, AD is to ensure utilisation of at least 30%
of the fund allocated in 1st instalment.

(viii) From 2" year Onwards, on account release is to be made for the 1st
instalment of the year and the 2 instalment shall be released on the
receipt of UC for at least 50% of the Grant released during previous
years. +»

ଖା
୬ˆଅଓ୨ଅୟଅଓଅ (>ଂଫ ଡଦ୦ୟଡ୫4&«"ଆ ମମ ଆ ›୬୮୫ ନନ୮ତ୍‌୍‌ର୍କୁର୍ ଇସ  କକ¬ କକ ୍ଣରେ଼ଯଭୟୱସୱୟ ଘୟଭୟ୬ଘୟଢ %ଯଢ-ଯଢ_ଯଝ¬>ୃ ୍ଚଚ << ଚ କଣ

<!-- page 4 -->

(4)

(ix) The detail record of expenditure against the grant is to be maintained
by the Grantee

(x) ` Photographs of the project before commencement, during execution
and after completion should be taken and kept in the Case Record and
to be uploaded online

(xi) Projects taken up under this grant should not overlap with any existing
State or Central Scheme. In such cases, where there is provision of
fund under any State or Central Schemes, then equivalent amount as
recommended by the Commission shall be deducted from the State
Scheme or it may be treated as contribution/share of State
Government / Local Bodies in case of Central Scheme.

CCC

<!-- page 5 -->

` (5)

Il. ALL WEATHER CONNECTIVITY :

On the recommendations of 5th State Finance Commission and the Action
Taken Report thereof, Government have decided to allocate a sum of
Rs.586.15 Crore for all-weather connectivity for the period from 2020-21 to
2025-26. The year wise breakup of the same is given below:

YEAR WISE FUND ALLOCATION
FEAR MISE FUND ALLOCATION
{Rs.in Crore)
UI h
Al weather
a. Objective:

All-weather road connectivity is an important component of rural
development. Villages and habitations get isolated due to lack of road
communication and are unable to avail the benefits of various Government
welfare schemes. The Commission considered it necessary to allocate some
funds for providing all weather connectivity to such villages/hamlets.
Information obtained from Planning & Convergence Department reveals that
there are 4322 habitations involving a distance of 11723 Kms to be made
motorable. Estimating an allocation of Rs.5.00 lakh per km., the Commission
recommends a total amount of Rs.586.15 crore for the purpose.

b. Mode of Release of funds :

(i) The Grants-in-aid earmarked for the Purpose will be released by the
Department in two instalments one in April/May and the other in
October/November directly to the PL Account of the Panchayat Samiti
through PL Module of IFMS.

(1) Funds will be utilised @ Rs.5.00 lakh per Km for construction of all-
weather connectivity road to villages/hamlets from the nearest
motorable road and the balance requirement of funds can be met
through convergence with MGNREGS or OSR of the GP etc.

<!-- page 6 -->

(6)

(iii) |The project proposals are to be submitted to Collectors of the
Districts who will scrutinise and then submit the same to PR&DW
Department for approval. PR & DW Department in consultation with
P&C Department will approve the proposals.

(iv) As far as practicable, minimum Grade-I| metalling shall be taken up
in the inter village roads and required nos. of culverts and bridges to
be given in the estimate so that all weather connectivity can be
ensured

(v) On account release of fund for the 1“ instalment will be made. While
releasing the 2” instalment, AD is to ensure utilisation of at least
30% of the fund allocated in 1st instalment.

(vi) From 2™ year onwards, on account release is to be made for the 1“
instalment of the year and the 2" instalment shall be released on
the receipt of UC for at least 50% of the Grant released during
previous year.

(vii) Photographs of the project before commencement, during execution
and after completion should be taken and kept in the Case Record
and to be uploaded online before release of Final payment to the
executant.

(viii) Projects taken up under this grant should not overlap with any
existing State or Central Scheme. In such cases, where there is
provision of fund under any State or Central Schemes, then
equivalent amount as recommended by the Commission shall be
deducted from the State Scheme or it may be treated as
contribution/share of State Government/Local Bodies in case of
Central Scheme wy

ee #é#é...........gggw#ws.eeeeeeeeeeeeeee

<!-- page 7 -->

: (7)

Ill. PROVISION OF FACILITIES AT GP HEAD QUARTERS :

On the recommendations of 5th State Finance Commission and the

Action Taken Report thereof, Government have decided to allocate a sum of

Rs.679.80 crore for the provision of facilities at GP Headquarters for the

Period from 2020-21 to 2025-26. The year wise breakup of the same is given

below:

YEAR WISE FUND ALLOCATION
(Rs.in Crore)
SEE of ooo
facilities at GP | 113.30 | 113.30 113.30 | 113.30 | 113.30 | 113.30 679.80
headquarters
a. Objectives:
In recent years, the headquarters of each GP has become a hub of
Public service delivery where distribution of pensions to the old, disabled,
widows as well as distribution of benefits under various welfare schemes take
place. Besides, some GPs also function as the agency under the Public
Distribution System for distribution of rice and other commodities, As a result,
Congregation of the general public including old and infirm takes place on
different days in a month at the GP headquarters. The Commission felt it
necessary that facilities such as provision of waiting shed, separate toilet
facilities both for men and women and provision of safe drinking water are
essential for providing the basic minimum facilities.
b. Mode of Release of Funds:

(i) The Grants-in-aid earmarked for the purpose will be released in two
instalments one in April / May and the other in October / November
by the Department directly to the PL Account of the Panchayat Samiti
through PL Module of IFMS for construction of waiting shed, separate
toilet facilities both for men and women and provision of safe drinking
water at GP headquarters.

ee
rr —————s—

<!-- page 8 -->

(8)

(ii) An amount of Rs.10.00 lakh per GP shall be utilised during the award
period and the balance requirement if any is to be met from other
sources,

(||) Proposals from at least 1/6"" nos. of GPs shall be included in each year.
The Proposals will be submitted bythe BDO to the Collector for
scrutiny. After necessary verifications the proposals shall be submitted
to PR&DW Department for approval. The GPs having sufficient
space shall be taken up in the 1st stage and accordingly, proposals for
the subsequent years shall be approved.

(iv) On account release of fund for the 1* instalment will be made. While
releasing the 2”° instalment, AD is to ensure utilisation of at least 30%
of the fund allocated in 1st instalment.

(v) From 2°° year onwards, on account release is to be made for the 1*
instalment of the year and the 2™ instalment shall be released on the
receipt of UC for at least 50% of the Grant released during previous
year

(vi) Photographs of the project before commencement, during execution
and after completion should be taken and kept in the Case Record and
to be uploaded online before release of Final payment to the executant.

(vii) Projects taken up under this grant should not overlap with any existing
State or Central Scheme. In such cases, where there is provision of
fund under any State or Central Schemes, then equivalent amount as
recommended by the Commission shall be deducted from the State
Scheme or it may be treated as contribution/share of State
Government/Local Bodies in case of Central Scheme.

My
TT ବ ବଚ  ଚ ଚଚ୍।୍କକକ.୍‌ଚ୍୍.ୟ୍‌6.।୍‌୍‌ ୦ {୯ ୍‌ପ୍‌େ୍‌୍‌୍‌୍‌  ]0୍‌'']‹'୍‌‹''‹ୀୈ_ୈ୯

<!-- page 9 -->

` (9)

IV. PROVISION OF STREET LIGHT:

On the recommendations of 5th State Finance Commission and the

Action Taken Report thereof, Government have decided to allocate a sum of

Rs.340.00 crore for the Provision of street light for the period from 2020-21 to

2025-26. The year wise breakup of the same is given below:

YEAR WISE FUND ALLOCATION
== _ ୭୭ FUND ALLOCATION
(Rs. in crore)

(ଆକ) _" 25) 27 | 2827 22 ୮ 5822 23 2825 20 ¶ 2020 26 | 202୭ 26 227 2 `

ମମ ନଜ 56.67 | 56.67 | 340.00
Street Lights ` ` ` ` ` ˆ
a. Objective:

The 4" SFC had recommended Provision of 10 street lights in a village
in every GP. There are still uncovered villages to be provided with street
lights. Wherever electricity has not reached the villages, the option of Solar
lighting can be explored, so that the villages are not deprived of the benefit of
Street lights. An amount of Rs.340.00 crore is recommended by the
Commission towards provision of Street lights in such villages
b. Mode of release of Funds:

(i) The Grants-in-aid earmarked for the purpose will be released in one go
during the financial year directly to the PL Account of the Executive
Officer, Zilla Parishad through PL Module of IFMS.

(ii) The earmarked funds for Provision of street light in the villages shall be
considered inviting State level tender for the district-wise proposals and
funds will be placed with the Executive Officer, Zilla Parishad for
execution of the work through the approved contractor and submission
of UC.

Ax

<!-- page 10 -->

(10)

(iii) Proposal of the uncovered most populous village of each GP shall be
enlisted by the Executive Officer, Zilla Parishad each year for providing
10 nos. of street lights (LED lights).

(iv) The tender cost of each project of each GP shall be shared out of the
allocation provided under street light head to Zilla Parishad and balance
matching share to be borne by the Gram Panchayat as to be derived
after the tender process is over.

(v) The Executive Officer, Zilla Parishad will be the implementing agency of
the work.

(vi) An Annual Action Plan and a Perspective Plan for the award Period is to
be prepared by the Executive Officer, Zilla Parishad and to be submitted
to PR&DW Department through Collector concerned.

(vii) From 2" year onwards, on account release is to be made for the 1*
instalment of the year and the 2nd instalment shall be released on the
receipt of UC for at least 50% of the Grant released during previous year

(viii) Projects taken up under this grant should not overlap with any existing
State or Central Scheme. In such cases, where there is provision of fund
under any State or Central Schemes, then equivalent amount as
recommended by the Commission shall be deducted from the State
Scheme or it may be treated as contribution/share of State Government /
Local Bodies in case of Central Scheme.
i...
