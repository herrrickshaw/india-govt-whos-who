---
doc_id: "acb3b2a18e53b3ed"
source_url: "https://www.bput.ac.in/old-site/documents/bput_1511140180.pdf"
ministry: "Biju Patnaik University of Technology (BPUT), Odisha"
title: "Downloading of Examiner(s) Appointment Order for E-Evaluation of Odd End Semester (Regular/Back) Examination:2017-18(1st Phase)"
date: ""
pages: 1
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "1795c07390ffaab4"
---

<!-- page 1 -->

oe
| ୭ BISU PATNAIK UNIVERSITY OF TECHNOLOGY, ODISHA
୪୪୫୧. ROURKELA
<2 Sea
No. BPUT / 24101/ 17
Date 18.11.2017
NOTICE
DOWNLOADING OF EXAMINER (S) APPOINTMENT ORDER FOR E-EVALUATION OF ODD END
SEMESTER (REGULAR / BACK) EXAMINATION: 2017-18 (17 PHASE)
In continuation to this University Notice No BPUT / 23777 | 17 dated 07.11.2017, and
BPUT / 24098/17 dated 18.11.2017, It is for the information of all Principal / Director (s) of
Constituent / Affiliated Colleges, Registered Teachers eligible for appointment as an Examiner
for UG | PG Courses that the eligible registered teachers of university after updating their
subject (s) etc in www.bputodisha.in will download Examiner Appointment Order on-line after
approval by the University.
The eligible teacher shall upload name and subject code, Branch and download from ¥
University portal www.bputodisha.in. w.e.f. 20.11.2017. oy ae
x3.
wae ad,
Memo No 24102 / 2017 Date 18.11.2017
Copy to: All Principal / Director (s) of Constituent and Affiliated Colleges, and E-
Evaluation Coordinators for information and necessary action / record. They are
requested to circulate amongst the member Faculties of the College on Top
Priority. VY
Directo ୮୭.
Memo No 24103 / 2017 Date 18.11.2017
Copy to: OSD to Vice Chancellor for kind information of Hon’ble Vice Chancellor / PA to
Registrar / Finance Officer / Director (CD / P & IT / Dy. Director Examination (s) /
e-Examination Cell / M/s Globarena Technologies Pvt. Ltd / Information Offic ୮
and Notice Board for information and necessary action / record. Nye
Director ୨୬୮୨
