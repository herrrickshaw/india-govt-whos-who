---
doc_id: "ea978e5e03bd8bba"
source_url: "https://agri.odisha.gov.in/sites/default/files/2025-03/SCHEME%20GUIDELINES%20%281%29_0_0.pdf"
ministry: "Agriculture and Farmers Empowerment Department, Odisha"
title: "Download(2.93 MB)"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9eb4e2e70e39512a"
---

<!-- page 1 -->

SCHEME GUIDELINES
ON
" INNOVATIVE PROJECTS"

DEPARTMENT OF AGRICULTURE AND
FARMERS' EMPOWERMENT
GOVT. OF ODISHA

<!-- page 2 -->

Content
1. Background

01

2. Scheme/Programme Objectives

02

3. Coverage under the Scheme/Programme and duration.

02

4. Implementation of the Scheme/Programme

03

5. Source of funding for the Scheme/Project and fund flow mechanism

06

6. Intended Scheme/Programme Outcome

07

7. Monitoring & Evaluation mechanism

08

8. Forms for application by the beneficiaries (if any) to be annexed...

09

<!-- page 3 -->

ANNEXURE-IV

Scheme Guidelines on "Innovative Projects"
1. Background:
Agriculture and allied sectors are the backbone of the Indian economy and so
also of our state, Odisha. About 83 percent of population of our State live in rural areas
and about 48.8 percent of its work force are employed in agricultural sector. The State
has witnessed a decline in its operational area from 48.52 lakh ha in 2011-12 to 46.19
lakh ha in 2015-16 due to rapid urbanization and its diversion to non-agricultural use.
Accordingly, the average size of land holding for all social groups in the state too has
declined to 0.95 ha. Today, farmers' main concern is on declining farm income on the
one hand and the increasing cost of inputs on the other.
Eradication of poverty, improving quality of life, achieving the Millennium
Development Goals (MDGs), enhancement of employment opportunities and highergrowth are priority objectives for our State. Among others, innovation and technology
have an important role in overcoming limitations of resources, optimal utilization of
existing resources.
In this context, Innovation is not only about developing new technology or
product but also includes an innovative approach to business model, service, process,
and structure or system which has value for the farmer and farmers' group. Hence,
innovation can be applied to sectorial development, discipline, or technology or any
process, structure and model in our agricultural system to bring about change for
adding value to farming community at large. Keeping in view the myriad problems and
a bare necessity for adding value in various socio-economic sectors in the state to
address the development concerns of large population, there is an urgent need for
innovation and technology application aiming at inclusive development and growth.
The Department of Agriculture and Farmers' Empowerment, Odisha strives to
promote novel and improvised approach in the form of innovative projects. The
objective of projects under this sector will be targeted to implement a time-bound
programme to demonstrate an approach that is likely to have far reaching implications
to reinforce in sustaining poverty alleviation efforts.

<!-- page 4 -->

This Guideline encompasses in its ambit a) Scheme/Programme objectives, b)
Coverage of targeted beneficiaries, eligibility criteria, quantum of benefits, etc., c) Nittygritty of Schematic implementation, d) Funding sources & fund flow mechanism, e)
Outcome and f) Monitoring & evaluation aspects.
2. Scheme/Programme Objectives:
Objectives:
•

The objective of Projects will be to implement a time-bound programme to
demonstrate an approach that is likely to have wider implications to augment the
income of the farmers and give a fillip to the sustaining poverty alleviation
measures.

•

Such innovations should be based on the novel and improvised approach with
emphasis on accrual of benefits to the farming community with quantifiable outcome
and deliverables within timeline.

•

The scheme is intended to lay emphasis on thrust area (sectors) as outlined
adopting innovative methods.

•

The "Innovative projects" scheme, is intended to focus more meaningfully on grey
area like Agri-Tech challenges with meticulous planning so that the farming
community can reap the harvest in the long run seamlessly.

•

Taking a cue from the improvised techniques adopted by farmers in other States
and International arena, the Scheme intends to improve upon varieties of seeds and
other species in Odisha in keeping with the Agro-Climatic condition of our State so
that it will come in handy to our farming community.

•

The Scheme aims at exploring reachability of new Germ-Plasms near the door of
common farmers to toe the line of market-led Agri-Enterprises.

•

The Department of Agriculture & Farmers' Empowerment looks forward to give
importance to Agri-enterprises with forward linkage of processing, packaging,
producing ready to eat finished product and e-marketing for value addition.

3. Coverage under the Scheme/Programme and duration [(i) In case of Capital
projects, length/area, etc. of the work with detailed break-up as well as intended
benefit to the public;(ii) In case of Social sector projects, the Target Beneficiaries,
eligibility criteria, quantum of benefit to be detailed]:
A. Coverage (Thrust area of the scheme):
The proposals shall preferably be considered from the innovative angle in the
following priority sectors;
• Precision technologies for agriculture, aquaculture and livestock,
• Regenerative agriculture and GAP (Good Agricultural Practice),
• Promoting use of Drone technology for different agricultural applications,
• Promotion of sustainable farming system, i.e. organic/natural/carbon farming,
• Remote Sensing and Geospatial technologies for assessing and optimization
of agriculture land use,
2

<!-- page 5 -->

•
•
•
•
•
•
•
•
•

Certification and marketing of Organic Produces,
Innovations in ICTs, Sensors and Geo-spatial technology for Digital
Agriculture,
Innovations for effective digital agricultural extension services,
Climate resilient agricultural practices for diverse agro-ecosystem,
Strengthening agricultural supply chain and marketing system using block
chain technologies,
Innovations for post-harvest management system and value addition of farmproduce,
Potato and Onion seed production technology,
Promotion of Orchid in low lying paddy areas under CDP,
Any other innovative concepts & combination of concepts contributing to
development of Agriculture.

B. Eligibility Criteria (Implementing Agencies):
Innovative projects will be undertaken either individual Agency-wise or on a
partnership mode involving Government Departments / Agencies, State Agriculture
University, State / National / International Research Institutes / Organizations, ICAR
Institutions and other Organizations having partnership experience with Department of
Agriculture and Farmers' Empowerment, Odisha.
The above organizations having innovative concept and experience of project
research and implementation are eligible for submitting project proposal.
The above Agencies / Organizations / Institutions / Universities having adequate
manpower and infrastructure may propose projects under priority sector (Thrust area) to
the Department of Agriculture and Farmers' Empowerment, Odisha. The proposal must
be submitted in the format given in Annexure-I. Proposals received in any other format
and without required documents will not be considered. The project proponent should
submit 3 hard copies of the proposal in A4 size paper along with the soft copy through
mail.
4. Implementation of the Scheme/ Programme (with the definite role of the
stakeholders at the State I District / Implementation level):
The proposals to be submitted on Innovative projects will be primarily scrutinized
and evaluated by the Internal Screening Committee (ISC).
• Scrutiny of proposals by Internal Screening Committee (ISC)
Scrutiny of the project proposals will be done by the Internal Screening Committee
(ISC) and which in turn will be submitted before Project Selection Committee (PSC)
constituted by Government of Odisha in A & FE Department for final evaluation and
3

<!-- page 6 -->

approval.
The ISC will examine the proposal in term of profile and experience of the Project
Proponent, Justification from innovative angle and feasibility of the project, budget
details, modalities for implementation, time schedule for completion etc.
The project proponents will be invited to give presentations before the Internal
Screening Committee (ISC) to justify their proposals.
The Internal Screening Committee (ISC) will shortlist the proposals based on
scoring & evaluation. The Chairperson of the Committee will devise the scoring format &
ensure item-wise scoring of the projects based on the concept, type of innovation,
feasibility of the project, implementation methodology, benefit of the target group, impact
of the project etc.
The shortlisted proposals evaluated from each angle along with Scoring and
comments of the Internal Screening Committee will be placed before the Project
Selection Committee (PSC).
Composition of the Internal Screening Committee (ISC):
SI No
1
2
3

Designation

Membership

Chairperson
Director, A & FP (0) / Horticulture
Representatives of Directorates under DA & FE other
Member
than the Directorate, the Chairperson represents
Subject matter experts from OUAT/ Other Reputed
Members
National / International Institutions (outside the State)

4

FA-cum-Joint Secretary

Member

5

Under Secretary, AET

Member Convenor

Note: The Internal screening committee (ISC) will be headed by the Concerned
Director; the project proposal comes within the jurisdiction.
Experts having outstanding experiences in field of Agriculture will be invited to the
Screening Committee for selection of the Innovative Project proposals.
•

Sanction of proposal by Project Selection Committee (PSC)
The Project Selection Committee (PSC) will examine the project proposals based on

the evaluation and score given by the Internal Screening Committee (ISC).
The PSC, at the time of selection of the project, may also prescribe necessary change
in implementation modalities, area of operation, project cost and duration etc.
4

<!-- page 7 -->

The Project Selection Committee reserve the right to select or reject any of the
proposals without assigning any reason thereof.
The composition of the Project Selection Committee (PSC):
SI.
No

Membership

Designation

1

Principal Secretary to Govt., A & FE Dept.

Chairperson

2

Director Agriculture & FP(0)

Member

3

Director of Horticulture(0)

Member

4

Vice Chancellor (VC), OUAT, Bhubaneswar

Member

5

FA cum Spl. Secretary to Govt. A & FE Dept.

Member

6

Expert Members from OUAT / Other Reputed National /
International Institutions (outside the State)

Member

7

Member Convenor
Special Secretary, AET, DA & FE
After the finalization of the selection procedure and approval of PSC, the selected

Project Proponent will be informed to submit their acceptance letter within a week to the
Department.
The Project Proponent or any member related to those Organizations / Institutions
may not be included as a Member in the Internal Screening Committee (ISC) and Project
Selection Committee (PSC) for that particular project / projects of that Organization /
Institution.

Flow Chart of Project Screeninq/Approval Process
DA & FE (Nodal Department)

Inviting application from
Implementing Agencies

Internal Screening
Committee (ISC)

Screening of Innovative
Projects proposed

Final Selection

<=1

Project Selection
Committee (PSC)
5

<!-- page 8 -->

The maximum project cost under innovative category will be up-to Rs.5.00 Crores
subject to modification with recommendation of Project Selection Committee (PSC).
The duration of the project will be for a maximum period of three years. The
effective date of implementation will be from the date of release of funds.
The Department of Agriculture and Farmers Empowerment will provide overhead
cost of 8% within the total Project estimated cost and 2% of the Project cost may be
provided after satisfactory completion of the project works in scheduled time.
5. Source of funding for the Scheme / Project and fund flow mechanism:
This is a new State sector scheme under Head "2562-Innovative Projects" with
total cost of the Scheme, duration and the Nodal Department as mentioned below:

Duration of the
Scheme

Five Years
(From 2022-23 to
2026-27)

Total Cost of the Scheme

SI No

Year

1

2022-23
2023-24
2024-25
2025-26
2026-27
TOTAL

2
3
4
5

Proposed
cost
10.00 Cr
15.00 Cr
20.00 Cr
25.00 Cr
30.00 Cr
100.00 Cr

Name of the Nodal
Department

Department of
Agriculture and
Farmers'
Empowerment,
Government of
Odisha

After sanction & release order from DA&FE, Funds will be sanctioned and
released by the Department directly in favour of the concerned Directorates under whose
jurisdiction the innovative project falls within.

•

Concerned Directorate under A & FE, Odisha will be the Agency for the execution of
that Innovative project through selected project proponent.

•

The project cost to be released to the project proponent will be routed through the
concerned Directorate.

The procedure for release of funds will be as follows:
•

The fund will be released to the head of the Organization or to the Organizational
account against the receipt of funds requisition.
6

<!-- page 9 -->

•

The first installment of the fund will comprise of 50% of the annual budget of the
approved project or as would be decided by concerned Director.

•

The second installment will be released basing on the utilization of 75% of the
released funds and submission of Utilization Certificate.

•

This process will continue in usual manner there on till the disbursement of total
project funds.

•

Three copies of the project completion report along with soft copy to be submitted to
the concerned Directorate with a copy to A&FE Department. The Director, concerned
will countersign the Project Completion report and submit to DA&FE.

•

Similarly, collection of Utilization Certificate (UC) and Project completion report etc.
will be submitted by the nodal Directorate to the Department.

•

In case of project involving more than one Directorate, fund transfer order may be
made as per the decision of the Project Selection Committee (PSC).

Flow Chart of Funding Pattern
DA & FE
(Nodal Department)

Respective Directorates

Project Implementing
Agencies
6. Intended Scheme / Programme Outcome:
The scheme is intended to lay thrust on area / sectors outlined here adopting methods
aimed at achieving the broad outcome beneficial to farmers;
•

Promotion of projects with innovativeness in Agricultural sector.

•

Concentrating on non-paddy crops with crop diversion method.

Reduction of input costs and maximizing production & productivity from
agriculture through promotion of improved technology/method.
• Creation and Development of Agri-enterprises.

•

•

Undertaking measures with sole objective of accruing financial benefits to farmers.
7

<!-- page 10 -->

7. Monitoring & Evaluation mechanism:
•

The Implementing Agencies shall submit half yearly and annual progress report in
detail indicating achievements and any key issues in implementation.

•

On completion of the project, the implementing agency shall submit a final completion
report on the implementation, learning and suggestions for scaling-up and
incorporation of the learning to the concerned Directorate with a copy to the
Department of Agriculture and Farmers Empowerment, Odisha.

•

The project monitoring and evaluation will be done by the A & FE Department
through concerned Directorates. The observations of the evaluation of the project will
be incorporated in the project deliverables for the rest of the project period to get a
quality output.

•

The DA & FE may engage the representative for onsite visit and evaluation of the
project at regular interval.

•

There will be provision for third party evaluation of the Projects.

•

Quarterly Review of the Scheme will be made at the Departmental Level and Monthly
Review to be made by Concerned Directorates.

•

Monitoring of the Projects will be made by respective Directorates regularly.

•

The project proponent would furnish the audited statement of expenditure as may be
applicable and Utilization Certificate for the amount actually utilized towards the
project in the prescribed format at the end of each financial year as well as a
consolidated statement of expenditure to be submitted to their respective nodal
Directorate with a copy to the Department of Agriculture and Farmers Empowerment,
Odisha. The Utilization Certificate must be submitted in the format given in Annexure-

General Conditions
•

Project is not transferable in any case.

•

It is mandatory to post the Success Stories and evaluation report of the Project on the
website of the Institution / Organization with copy to concerned Directorate.

• The Department of Agriculture & Farmers' Empowerment being the nodal Department
of the scheme reserve the right to insert or delete any of the clause there under in the
guidelines as and when required.

8

<!-- page 11 -->

Flow Chart of Monitoring and Evaluation Process
DA & FE

ar
QUARTERLY
REVIEW

MONITORING

a
-u

Respective Directorates
(Monthly Review)

Project Implementing
Agencies

8. Forms for application by the beneficiaries (if any) to be annexed:
(As annexed below in four parts-Part I, 11, Ill & IV).

9

<!-- page 12 -->

Annexure —I
FORMAT FOR THE SUBMISSION OF PROPOSALS BY PROJECT PROPONENT
PART I : PROJECT SUMMARY
1. Name of the Project:
2. Name of the Villages, GP, Block and District in which this project will be implemented:
3. Project Objectives:
4. Innovative Elements/Components of the Project:
5. Project Cost & Period:
6. Background of the project & features which make it innovative or innovativeness of
the proposed project. [Include here the justification for why the project is being
proposed as innovative project]
7. Project components
8. Outcome / Deliverables and their Expected Impact (In bullet form):
9. Details of the target beneficiaries to be covered by this project: a. Total number of
beneficiaries to be covered: b. Profile of the beneficiaries: [these may be SCs, STs,
minorities, female headed households, persons with disabilities, the destitute, migrant
labourers, and especially vulnerable occupational groups such as street vendors, rag
pickers, domestic workers, beggars, construction workers, etc.]
PART II: IMPLEMENTING AGENCY DETAILS
10.Name of the Implementing Agency:
11.Name & Contact details of the Project Proponent, Implementing Agency:
12.Legal status of the Implementing Agency:[e.g. registration status and details]
13.Last 3 years audited financial statements (in annexure):
14.Bank details of the Implementing Agency to which funds are to be released:
15.Experience of the agency in implementation of similar projects: [*include a detailed
profile of the implementing agency in annexure to the proposal]
PART III:PROJECT IMPLEMENTATION & MONITORING DETAILS
16. Project Strategy: [Specify here the manner in which the project will achieve the
goals and key outcomes proposed]
10

<!-- page 13 -->

17. Key outcomes of the project: [specify here the expected benefits / impact of the
project in terms of indicators such as increased reach of social mobilization,
increase in income of the target group, sustainability of enterprise of the target
group, increased each of credit facilities to the target group, increase in efficiency
(time and cost), etc.]
18.Role of partner agencies (if any): [this could include line departments, and any
others take holder institution—clearly indicate their responsibilities and their impact
on the project]
19.Modalities for implementation of the project: [describe here how various inputs
such as technical inputs, raw materials, infrastructure development, marketing,
training, etc., will be secured and managed]
20.Benchmark survey for indicators on the basis of which the project would be
implemented, monitored and evaluated
21.Quarter-wise Action Plan/Milestones for implementation
PART IV: FINANCE
22.This section should focus on the cost estimates, budget for the project, means of
financing and phasing of expenditure.

11

<!-- page 14 -->

Annexure-11
FORM O.G.F.R. 7-A.
(See Rule 172)

Form of Utilization Certificate for the year 20

I hereby certify that the grant placed at my disposal/at the disposal of
and the amount available for expenditure
in the year
during the said year as follows:I. (a)
(b)

...Rs.
...Rs.

Unspent balance to the end of the year
Grant received during the year of

Quote the number and date of authorization issued by Accountant-General,
Orissa. Whenever it is dependent on such authority and in other cases only the
number and date of sanction and designation of sanctioning authority.
(F.D. Memo No. 30007 (144)-F., dated the 27 th July, 1962,)
...Rs.

Total
II. Expenditure during the year:(i)
(ii)

Out of unspent balance as in 1(a) above
Out of the grant referred to in 1(a) above
Total

...Rs.
...Rs.
...Rs.

III. Unspent balance at the end of the year
shown as
I further certify that the expenditure of Rs.
2.
has been expended solely on
expenditure in the year
and for no other purpose
under my charge within the jurisdiction of *
)
shown
as
balance at the end of the
and that the sum of Rs.
is available for expenditure and no part of it has
year
been diverted to other purposes.
I further certify that a list of works on which the expenditure of Rs.
has been incurred and the amount spent on each has been prepared and
is maintained in my office
in the office of the
3.

Principal Secretary to Government
Department of Agriculture & FE
12
