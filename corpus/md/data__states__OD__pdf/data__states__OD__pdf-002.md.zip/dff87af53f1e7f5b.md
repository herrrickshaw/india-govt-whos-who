---
doc_id: "dff87af53f1e7f5b"
source_url: "https://urban.odisha.gov.in/sites/default/files/2023-10/20617%20Incentive%20Guidelines.pdf"
ministry: "Housing and Urban Development Department, Odisha"
title: "Download(2.45 MB)"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8350f70eb88e32d8"
---

<!-- page 1 -->

Government of Odisha
Housing & Urban Development Department
3rd

oor, Kharavel Bhavan, Unit-V, Bhubaneswar, PI :751001

***
No.

.;J,0611

/HUD,

Date

_-wa2""",,_'o ,--R::........::,J::::....>..-..:..:...- __

HUD-FUND-POUCY-0003-2020

From

G. Mathi Vathanan, IAS
Principal Secretary to Government
To

All the Commissioners of Municipal Corporations
. All the Executive Officers of Municipalities and N.A.Cs
Sub:

GUIDELINES ON UTILISATION
OF GRANTS-IN-AID
FOR INCENTIVE
TH
GRANTS RECOMMENDED BY 5 STATE FINANCE COMMISSION FOR THE
PERIOD FROM 2021-22 TO 2025-26 (5 YEARS).

Madam /Sir
I am directed to say that on the recommendation of 5th State Finance Commission
and the Action Taken Report thereof, Government has decided to transfer fund amounting
to Rs.50.00 crore as Grants-in-aid covering the period of five years towards Incentive grants
to Urban Local Bodies during the award period of 2021-22 to 2025-26. The year wise
allocation of fund is detailed below:

2021-22
10.00

2022-23

Rs. in Crore
2024-25
2025-26

2023-24

10.00

10.00

10.00

2021-26

10.00

50.00

1. OBJECTIVE OF THE SCHEME:
The 5th State Finance Commission

have recommended

for an incentive

structure

to

incentivise the Urban Local Bodies to augment their Own Sources of Revenue (OSR). The
Commission recommended that the ULBs which achieve higher rate of growth from their
own source of revenue than the State's average growth

rate need to be incentivised.

While awarding the incentive grants, the performance of ULBs should be assessed on the
basis of the audited accounts.

2. Eligibility Condition for accessing Performance Incentive:
The Urban Local Bodies which achieved higher rate of growth in their own source of
revenue than the State's average growth rate shall be eligible for the incentive grant. The
ULB which achieved minimum amount of Rs.10, 000/- in OSR during year before previous
year are eligible to get the incentive grants.
For the purpose ULBs have to claim the incentive grants by submitting following
document:
• Copy of the Audited Accounts of the year before previous year showing 0
sources of Income not below the Rs.10,OOO/- (Rupees Ten thousand)only

-6{-

y~
V

<!-- page 2 -->

•

c:nrlv.tirVl 0

sources of Income

(For Example to claim the I cen ive grants for the year 2021-22, ULB has to
submit audited accounts of the year 2019-20 and provisional accounts for the
year 2020-21)

3. Mode of distribution of grant:
The inter se distribution
done proportionately

of the grants among the eligible ULBs under the scheme will be

on the basis of percentage of growth achieved by them during

previous year.

4. Utilization of Incentive Grants:
•

The incentive grants made available to the ULBs shall be utilised for creation and
maintenance of Income generating assets of the ULBs.

•

The grant under the scheme may be dovetailed with other admissible government
gr.ant for expenditure.

•

The projects approved by respective Municipal Councils are to be taken up under
direct supervision of the ULBs and to be reviewed from time to time till completion of
the work.

•

List of projects as approved by the Municipal Councils are to be submitted to H & UD
Department.

•
,

The codal provisions will be followed strictly at the time of execution of the work.

;

5. Mode of Selection &. Release of funds:
The incentive grant to the eligible ULB will be released directly to the PL account of the
concerned ULBs through PL module of IFMS in one go during a financial year subject to
receipt of following information and documents for evaluation.
•

The ULBs have to submit their proposals along with required documents by end of
November each year.

•

The H & UD Department has to scrutinise the proposals submitted by different Urban
Local Bodies through
"-

Administration

a Committee

under the Chairmanship

of Director

Municipal

and select the eligible ULBs.

6. Maintenance of Accounts &. Audit
•

Separate book of Account to be maintained by the ULBs for Incentive Grants.

•

The Project approved by the concerned Municipal Council is to be taken up under
direct supervision of the N.A.C., Municipality and Municipal Corporation (as the case
may be) and to be reviewed from time to time till completion of the work.

•

Inventory Assets Register has to be maintained by the ULB in the prescribed format /
Form OGFR 30A in terms of Rule-17(S)(i) of the OGFR and shall be uploaded online.

•

The utilisations of fund under Incentive grants are subject to audit by the Local Fund
Audit Organisation

of State, internal audit of the H & UD Department

Annual Technical Inspection of C & AG.

7. Monit()ring and supervision:

as well as

<!-- page 3 -->

3
•

e District Level Monitoring Committee in each district
vide

Rnance Department

ich as been co

Resolution No.16885/F da ed 4.6.2020

Chairmanship of Collector & OM with PO, DUDA and Representa fves of

e
e

e

Departments as Members and PO, DRDA as Member Convenor shall revie

e

demand and collection of own sources of revenue, progress of expenditure,
submission of utilisation certificate etc. on quarterly basis.
• Every ULB need to share under public disclosure law as incorporated in OM Act, 1950
and OMC Act, 2003, with public through Notice Board, paper advertisement and web
information on quarterly basis their work plan, on-going projects, projects to be aken
up, cost of project and status of each of the projects.
8. Submission of Utilisation Certificate:
•

The Utilisation Certificate in duplicate shall be furnished by the grantee (ULB) in Fo
OGFR-7A duly countersigned by the countersigning authority as per the FD 0
0.21241/F, dated 17.07.2014 and such other instructions issued from time to time.

is Guideline supersedes all other instructions communicated by H & UD Department
as ell as
a ce Department earlier in this regard.
o eve, on-going projects taken up under the previous guidelines will continue to be
gove ed by e said guidelines.
Housing & Urban Development Department will be competent to clarify doubts if any
and ensure removal of the bottlenecks if any for implementation of the scheme and
utilisation of funds and relaxing any of the conditionality for release of grants under special
circumstances with due approval of HLMCand concurrence of Finance Department.
This has duly been vetted by Finance Department and approved by High Level
Monitoring Committee (HLMC).
Yours faithfully,

~06

~J.,~, ~~r

Memo No.
J~ tHUD, Date
Copy forwarded to Finance (Budget-6) Department for information and necessary
action.
~

~~

\-r. -:r\

""t;.Id.l.
Additional Secretary to Go rnm nt
Memo No.~HUD,
Date Oi·'~' ~0<2~
Copy forwarded to all Collectors & District Magistrates / all Project Director, District
Urban Development Agenciesfor information and necessaryaction.

<!-- page 4 -->

4

emo

~6J

~,l~. ~~I

o.
/HUD/ Date
Copy forwarded to 5.0. to Principal Secretary to Government/ p.s. to F.A.-cumSpecial Secretary/ H & UD Department for kind information of the Principal Secretary and
F.A.-cum-Special Secretary.

~ob2(

f2 ' ~O:ll

Memo No.
/HUD/ Date
0).
Copy forwarded to all Section of H & UD Department (Except Issue & Diary Section)
for information and necessary action.
The RTI Section is requested to upload the guidelines in public domain under Section
4(1) (b) of the RTI Act/ 2005.

,

,
