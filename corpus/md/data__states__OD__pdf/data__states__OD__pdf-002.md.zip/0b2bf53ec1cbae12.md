---
doc_id: "0b2bf53ec1cbae12"
source_url: "https://fmuniversity.nic.in/getdata?dir=InstituteNotice&rid=inotice1005_8820261786195685755.pdf"
ministry: "Fakir Mohan University, Odisha"
title: "CORRIGEND UM NOTICE ADMISSION NOTICE FOR Ph.D. 2026-27 (Executive Ph.D.) :"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6e1531b764ae9fc5"
---

<!-- page 1 -->

FA.KIR MOHAN UNIYXRSITY
Qasn Vhar, Ffuapadtri, Bala**r*, Odisha. Pin- 75S08t]
D
Date: o D' , og, ?t 2/
No. FMU/PGC/VII- I 212025 I
CORRIGEND UM NOTICE
Sub: ADMISSION NOTICE FOR Ph.D. 2026-27 (Executive Ph.D.)

In partial modification of the admission notice for Ph.D. Programme 2026-27 issued
vide Notice No. 958, dated 17-07-2026, it is hereby notified for information of all concerned
that the last date for submission of online applications for admission into the Ph.D. Programme
2026-27 has been extended from 28-07-2026 to 14-08-2026. Accordingly, the revised schedule
is as follows:

EVENTS
Last date of Online Registration
Last date of submission of soft copy of the application along
with other documents to the email:
dyc oe_fmu @r e diffmail. c om

Revised DATE
14-08-2026
15-08-2026 (by 05:00 PM)

* 17-08-2026 (bv 03:00 PM)
Publication of list of eligible/ ineligible applicants by the
respective Depts. in the University website
* 17-08-2026 (by 08:00 PM)
Downloading of Admit Card for attending viva-voce/
interview
*t8-08-2026
Date of viva-voce/interview
*24-A8-2026 (by 05:00 PM)
Publication of Result by respective Departments
* 28-08-20 26 to 29 -08 -2026
Date of Admission and payment of fees
*0t-09-2026
Date of commencement of classes
N.B. *mark indicates the tentative dates
'A11
other terms and conditions of the Admission Notice/ Information Bulletin shall
remain unchanged.
By order of the Vice-Chancellor

vb

MemoNo. tt

to:
Copy forwarded "(

cil

Chairman,

Date:

D?'d8,Q,t Ql

1. O.I.C, University Website for information with a request to upload the same in the
University website.
2. P.A.to V.C.l Steno to Registrarl COEI COF/ Director, Dr. H.K.M. Libraryl Director,
Students' Welfare F.M. University, Baleshwar for information and necessaryaction.
3. HODs and Coordinators of all P.G Departments F.M. University, Baleshwar for
information and necessary action
P.G.
