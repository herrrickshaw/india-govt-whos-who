---
doc_id: "1cb78ddd5eb42dcc"
source_url: "https://fmuniversity.nic.in/getdata?dir=InstituteNotice&rid=inotice985_31720261785482368054.pdf"
ministry: "Fakir Mohan University, Odisha"
title: "Admission Notification for Distance Courses :"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "dc17536012f7070c"
---

<!-- page 1 -->

CENTRE FOR DISTANCE AND ONLINE EDUCATION (CDOE)

FAKIR MOHAN UNIVERSITY
(OLD CAMPUS), JANUGANJ, VYASA VIHAR, BALASORE - 756019

ADMISSION NOTIFICATION : 2026-2027

Letter No: FMU/CDOE/ESTT-50/2026/710
Date: 30.07.2026
Applications are invited from Eligible candidate for admission into the following UGC approved programmes (UG & PG)
under ODL mode for the Academic Year 2026-2027, Academic Session beginning August, 2026.

COURSES OFFERED

Opening Date: 01.08.2026

Post- Graduate (PG) Programmes

P
G

PG Courses

Duration

Eligibility

MA in Odia

2 years

Any Graduate

MA in English

2 years

Any Graduate

MA in Sanskrit

2 years

Any Graduate

P
R MA in Economics 2 years
MA in Political
O
2 years
Science
G
MA in History
2 years
R
A
MA in Sociology
2 years
M MA in Social Work 2 years
M
MA in Education
2 years
E
S Master in Commerce 2 years
MLIS

1 years

Any Graduate
Any Graduate
Any Graduate
Any Graduate
Any Graduate
Any Graduate
Any Graduate
BLIS

Closing Date: 31.08.2026

Under Graduate (UG) Programmes

U
G
P
R
O
G
R
A
M
M
E
S

UG Courses
Duration
Eligibility
B.A. in Odia
4 years +2/lntermediate
(Hons)
B.A. in English
4 years +2/lntermediate
(Hons)
B.A. in Sanskrit
4 years +2/lntermediate
(Hons)
B.A. in Economics
4 years +2/lntermedlate
(Hons)
B.A. in Pol. Sc.
4 years +2/lntermediate
(Hons)
B.A. in Hist (Hons) 4 years +2/lntermediate
B.A. in Sociology
4 years +2/lntermediate
(Hons)
BBA
4 years +2/lntermediate
B.A. in Education
(Hons)

4 years +2/lntermediate

B.Com.

4 years +2/lntermediate

BLIS

1 Year

Any Graduate

REGULAR PG/UG CONTINUING STUDENTS ARE ALSO ELIGIBLE FOR APPLYING FOR ADMISSION IN ABOVE ODL PROGRAMMES
UNDER DUAL DEGREE MODE.
ALL PROGRAMMES ARE RECOGNISED BY UGC & ARE SAME IN STATUS WITH DEGREES OFFERED BY THE REGULAR UNIVERSITIES.

Admission Procedure:
Visit the website at https://fmuniversity.in and click on CDOE menu link for detail information. The Candidates can apply
online through URL: https://fmuniversitycdoeadm.samarth.edu.in/ link by filling up the given criteria and payment of
requisite fees for consideration of the admission into concerned Programme.

For any further Information, please Contact:- 9439515579/ 7008555647/ 9861260546/ 7854009290/
7008040325/ 9692678737/ 8114834622 during office Hours from 10.30 A.M.- 5.00 P.M.
Sd/- DIRECTOR
