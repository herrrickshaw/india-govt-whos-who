---
doc_id: "af8be6f2b1a9fdcd"
source_url: "https://finance.odisha.gov.in/sites/default/files/2021-07/Compilation%20of%20Circular%20Report%20for%202020-21.pdf"
ministry: "Finance Department, Odisha"
title: "Download(6.89 MB)"
date: ""
pages: 267
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4a6bf6d7f1143fdf"
---

<!-- page 1 -->

For Official Use Only

GOVERNMENT OF ODISHA

COMPILATION OF IMPORTANT
CIRCULARS AND ORDERS ISSUED BY
FINANCE DEPARTMENT
2012-13

2020-21

FINANCE DEPARTMENT

<!-- page 2 -->

TABLE OF CONTENTS
Sl.
No.

Resolution/Notification/Office
Memorandum letter No. & Date

1

2

Subject

Page

3

4

Matters relating to Budget
1

No.FIN-BUD2-BT-0003-2020-15343/F., Dt.- Mopping up of Government money parked outside the Public
16.05.2020
Account by DDOs and Implementing Agencies.

1-3

2

Special drive for payment of pending dues of different MSMEs,
No.FIN-BUD2-BT-0003-2020-15352/F., Dt.Industries, Municipalities and Utilities during COVID-19
16.05.2020
pandemic.

4-5

3

Verification and Reconciliation of Departmental receipt and
No.FIN-BUD2-VR-0001-2020-19623/F., Dt.expenditure figures for 2020-21 with those of Accountant
02.07.2020
General (A & E), Odisha.

6-10

4

No.FIN-BUD1-MISC-0003/2020-20042/F., Adoption of expenditure rationalization measures in the wake
Dt.-07.07.2020
of economic downturn due to the global pandemic Covid19.

11-15

5

No.FIN-BUD1-MISC-0003-2020-22855/F.,
Admissibility of long term advance for purchase of Computers.
Dt.-03.08.2020

16

6

No.FIN-BUD1-BT-0004-2020-29018/F., Dt.- Preparation of Revised Estimates for 2020-21 and Budget
29.10.2020
Estimates for 2021-22.

17-30

7

Compliance to audit observation on mis-classification
No.FIN-BUD2-CAG-0002-2020-33453/F.,
between capital and revenue heads of accounts during 2019Dt.-17.12.2020
20.

31-33

8

Relaxation in expenditure rationalization measures adopted in
No. FIN-BUD1-MISC-0003/2020-07/F., Dtthe wake of economic downturn due to the pandemic
01.01.2021
Covid19.

34-37

9

Withdrawal of expenditure rationalization measures adopted
No.FIN-BUD1-MISC-0003/2020-5980/F.,
in the wake of economic downturn due to the pandemic
Dt.-19.02.2021
Covid-19.

38

10

No.FIN-BUD2-BT-0003-2020-7936/F., Dt.- Prompt payment of pending dues of different MSMEs,
10.03.2021
Industries, Municipalities and Utilities.

39-40

11

No.FIN-FR-VR-0001-2020-9523/F., Dt.22.03.2021

Systematic appraisal and approval of new schemes or new
services, existing schemes under Programme Expenditure and
Administrative Expenditure where the scope or cost estimate is
proposed to be substantially altered and schemes continuing
without appraisal.

41-73

12

Relaxation of the deadlines for financial sanction, issue of
No.FIN-WM-BT-0001-2018-9792/F., Dt.- allotment and drawal of funds in the remaining part of the
24.03.2021
current financial year in respect of Centrally Sponsored
Schemes (CSS) and Central Sector Schemes.

74-75

13

No.FIN-WM-BT-0001-2021-10641/F., Dt.- Regulation of Expenditure out of the Annual Budget for the
30.03.2021
year 2021-22.

76-90

Matters relating to Odisha Treasury Code
1

No.FIN-TRY-MEET-0001/2017-14315/F.,
Dt.- 30.04.2020

Payment of cashless payment eco-system using Unified
Payment Interface (UPI).

91-92

2

Process for Bulk disbursement of financial benefits to
No.FIN-TRY-MISC-0025/2013-19190/F.,
beneficiaries of schemes using the integrated platform of
Dt.- 29.06.2020
IFMS, Departmental IT system and e-Kuber.

93-99

3

Issue and delivery of Digitally Signed e-Authorities for pension,
NO. FIN-TRY-MEET-0001/2017(PART-II)- commutation, gratuity by Principal Accountant General
19753/F., Dt.-03.07.2020
(A&E), Odisha and Treasury Officer to the pensioner/family
pensioner.

100-105

Page 1 of 3

<!-- page 3 -->

Sl.
No.

Resolution/Notification/Office
Memorandum letter No. & Date

Subject

Page

1

2

3

4

4

NO. FIN-TRY-MEET-0001/2017(PART-II)- Disbursement and Accounting of GPF final Payments in a
26968/F., Dt.-06.10.2020
single Nodal Treasury.

106-108

5

No. FIN-TRY-BT-0001-2020-6868/F., Dt.- Measures to prevent rush of expenditure towards the fag end
26.02.2021
of the Financial Year, 2020-21.

109-116

6

Online Distribution of allotments through IFMS Portal by all
No. FIN-TRY-BT-0002-2017-10176/F., Dt.- Administrative Departments to Controlling Officers and from
26.03.2021
Controlling Officers to DDOs/ Divisions/ Projects for Annual
Budget 2021-22.

117-118

Matters relating to OGFR
1

No. FIN-COD-MISC-0008/2017-27928/F.,
Preference to Local MSEs/Start-ups in Public Procurement
Dt. 16.10.2020

2

No. FIN-COD-MISC-0007/2019-27945/F., Restriction on Public Procurement from bidders of certain
Dt. 16.10.2020
countries

127-137

3

No. FIN-COD-MISC-0008/2017-1492/F.,
Dt. 13.01.2021

Procurement
Marketplace.

138-139

4

No. FIN-COD-MISC-0007/2019-8943/F.,
Dt. 18.03.2021

Bid Security / Earnest Money Deposit (EMD)

140-141

5

No. FIN-COD-MISC-0007/2019-8952/F.,
Dt. 18.03.2021

Performance Security

142-143

of

Goods

and

Services

in

electronic

119-126

Matters relating to GPF
1

No. FIN-CS3-ADV-0002/2020-34905/F.,
Dt. 31.12.2020

Liberalisation of provisions for withdrawal from General
Provident Fund.

145

Matters relating to DA/TI

1

No. FIN-CS2-ALW-0005/2017-15231/F.,
Dt. 15.05.2020

Sanction of Dearness Allowance @ 10% enhancing the
existing rate from 154% to 164% with effect from 01.07.2019 in
favour of State Government employees drawing pay in prerevised scales of Pay, 2008.

147-148

2

No. FIN-CS3-PEN-0002/2020-985/F., Dt.
08.01.2021

Sanction of Dearness Relief (TI) @ 5% enhancing the existing
rate from 12% to 17% with effect from 01.07.2019 in favour of
the State Government Pensioners/family pensioners.

149

Matters relating to GST
1

No. FIN-CT1-TAX-0002/2020-18491/F.,
Dt. 22.06.2020

Notification

151-152

2

No. FIN-CT1-TAX-0002/2020-18548/F.,
Dt. 22.06.2020

Notification

153

3

No. FIN-CT1-TAX-0001/2020-19365/F.,
Dt. 30.06.2020

Notification

154

4

No. FIN-CT1-TAX-0001/2020-20219/F.,
Dt. 08.07.2020

Notification

155

5

No. FIN-CT1-TAX-0001/2020-22397/F.,
Dt. 05.08.2020

Notification

156-172

6

No. FIN-CT1-TAX-0001/2020-22401/F.,
Dt. 05.08.2020

Notification

173

7

No. FIN-CT1-TAX-0036/2020-23839/F.,
Dt. 25.08.2020

Notification

174

8

No. FIN-CT1-TAX-0001/2020-24115/F.,
Dt. 28.08.2020

Notification

175-176

9

No. FIN-CT1-TAX-0001/2020-27246/F.,
Dt. 08.10.2020

Notification

177

10

No. FIN-CT1-TAX-0001/2020-27254/F.,
Dt. 08.10.2020

Notification

178
Page 2 of 3

<!-- page 4 -->

Sl.
No.

Resolution/Notification/Office
Memorandum letter No. & Date

Subject

Page

1

2

3

4

11

No. FIN-CT1-TAX-0002/2020-28138/F.,
Dt. 19.10.2020

Notification

179

12

No. FIN-CT1-TAX-0001/2020-28901/F.,
Dt. 28.10.2020

Notification

180-198

13

No. FIN-CT1-TAX-0001/2020-31745/F.,
Dt. 27.11.2020

Notification

199-212

14

No. FIN-CT1-TAX-0002/2020-31751/F.,
Dt. 27.11.2020

Notification

213

15

No. FIN-CT1-TAX-0002/2020-31803/F.,
Dt. 01.12.2020

Notification

214-215

16

No. FIN-CT1-TAX-0002/2020-31810/F.,
Dt. 01.12.2020

Notification

216-217

17

No. FIN-CT1-TAX-0002/2020-32713/F.,
Dt. 09.12.2020

Notification

218

18

No. FIN-CT1-TAX-0001/2020-23/F., Dt.
01.01.2021

Notification

219

19

Procurement of goods and services by Government
No. FIN-CT1-TAX-0006/2021-4699/F., Dt.
Departments and Government entities/agencies and TDS
09.02.2021
under GST.

20

No. FIN-CT1-TAX-0002/2020-6736/F., Dt.
Notification
26.02.2021

220-227
228

Matters relating to Odisha Finance Service Rules
1

No. FIN-OFS2-CADRE-0005/202018014/F., Dt. 17.06.2020

Restructuring of the Cadre of Odisha Finance Service (OFS)

2

No. FIN-OFS2-CADRE-0006/201818342/F., Dt. 19.06.2020

Notification

231

3

No. FIN-OFS2-CADRE-0014/201519393/F., Dt. 01.07.2020

Notification

232

229-230

Miscellaneous Matters
1

No. FIN-CT1-TAX-0022/2020-15383/F.,
Dt. 16.05.2020

Notification

233

2

No. FIN-CS3-MISC-0003/2020-20088/F.,
Dt. 07.07.2020

Office Memorandum

234

3

No. FIN-CS3-MISC-0003/2020-21363/F.,
Dt. 18.07.2020

Remuneration during lock down period.

235

4

No. FIN-CS3-PEN-0009/2020-22073/F.,
Dt. 04.08.2020

COVID-19 Warrior Family Assistance for Anganwadi Worker.

236-239

5

No. FIN-CS3-PEN-0009/2020-22086/F.,
Dt. 04.08.2020

COVID-19 Warrior
employees.

Family

Assistance

for

Government

240-243

6

No. FIN-CS3-PEN-0009/2020-22094/F.,
Dt. 04.08.2020

COVID-19 Warrior
employees.

Family

Assistance

for

Government

7

No. FIN-CS3-PEN-0009/2020-22099/F.,
Dt. 04.08.2020

COVID-19 Warrior
employees.

Family

Assistance

for

Government

8

No. FIN-CS3-PEN-0009/2020-22104/F.,
Dt. 04.08.2020

COVID-19 Warrior Family Assistance for ASHA.

9

No. FIN-CT1-TAX-0025/2013-28051/F.,
Dt. 19.10.2020

Notification

244-247
248-253
254-257
258

Page 3 of 3

<!-- page 5 -->

MATTERS RELATING
TO BUDGET

<!-- page 6 -->

COVID-19
URGENT
GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No. 15343/F.,
Date: 16.05.2020
FIN-BUD2-BT-0003-2020

From
Sri Ashok Meena, IAS
Principal Secretary to Government
To
The Additional Chief Secretaries/
All Principal Secretaries/Secretaries to the Government
All Heads of the Department/All Collectors
Sub: Mopping up of Government money parked outside the Public
Account by DDOs and Implementing Agencies.
Madam/Sir,
I am directed to say that COVID-19 related lock-down has affected the
activities across all the sectors of the economy resulting in limited resource
flow to the State Government exchequer. The Stat e Government will have to
discharge its committed liabilities and also finance COVID-19 management
activities.
2.
In this scenario, as the tax and non-tax revenue is adversely affected,
any parking of the Government money in bank accounts is not only affecting
the cash balance of the State, but also having a negative carry on the
interest accrued against such idle Government money when compared to
the cost of borrowing.
3.
Unauthorized parking of Government money outside the Public
Account in contravention of financial rules and instructions issued by Finance
Department has been discouraged by the State Government vide FD Letter
No.23583/F dated 10.07.2019 read with FD Letter No.32215/F dated
21.11.2014.
4.
Now as a measure to improve the cash balance of the State
Government for financing the COVID-19 related emergent expenditure and
other committed expenditure, it is decided that Government money parked
in Bank accounts by DDOs and Implementing Agencies without
authorization, would be ploughed back to the State Government Account.
Accordingly, the Administrative Departments should take immediate steps in
1

<!-- page 7 -->

mopping up of the Government Money parked in Bank accounts classified as
below :
i.

State Sector Scheme money parked in the bank account for more than
2 years: Administrative Departments should instruct all DDOs and
Implementing Agencies under them to deposit State Sector Scheme
money parked in the bank account for more than 2 years in the
Treasury immediately. The remittance to the State treasury is to be
made against the specific Major Head and Sub Major Head, under
which it was granted, mapped to Minor Head “911-Deduct Recoveries
of Overpayments- 1889-Deduct Recoveries- 49015-Deduct Recoveries
of Overpayments” (as per para 3.10 of List of Major and Minor Heads).

ii.

Money in respect of closed schemes or schemes no more in operation
for more than 2 years parked in the bank account: Money in respect of
closed schemes or schemes no more in operation for more than 2
years parked in the bank account are also to be deposited back in
State Government exchequer. Administrative Departments should also
instruct all DDOs and Implementing Agencies under them to deposit
the money in respect of closed schemes and schemes no more in
operation for more than 2 years parked in the bank account in the
Treasury immediately. The remittance to the State treasury is to be
made against the specific Major Head and Sub Major Head, under
which it was granted, mapped to Minor Head “911-Deduct Recoveries
of Overpayments- 1889-Deduct Recoveries- 49015-Deduct Recoveries
of Overpayments” (as per para 3.10 of List of Major and Minor Heads).

iii.

Accrued interest on Government money deposited in Bank account:
The interest accrued on account of such parking of Government
money in bank accounts by DDOs and Implementing Agencies unless
specifically mentioned for utilization for the scheme (in the scheme
guideline or separate instruction) is to be remitted to the Treasury in the
Head of Account "0075- MISCELLANEOUS GENERAL SERVICES - 00-800OTHER RECEIPTS - 0097- Misc. Receipts - 02082- Miscellaneous other
Receipts".

iv.

Unclassified amount parked in Bank Account of DDOs and
Implementing Agencies: Any unclassified amount parked in Bank
Account of DDOs and Implementing Agencies is also to be deposited
back in the State Government account as miscellaneous
receipt. Administrative Departments should also instruct all DDOs and
Implementing Agencies under them to deposit all such unclassified
amount of money in the Treasury in the Head of Account "0075MISCELLANEOUS GENERAL SERVICES - 00-800-OTHER RECEIPTS - 0097Misc. Receipts - 02082- Miscellaneous other Receipts".

2

<!-- page 8 -->

4.
All the Administrative Departments and Heads of the Departments are
here by requested to ensure that the DDOs and Implementing Agencies
under their control deposit the above parked money into the State Treasury
within a period of one month from the date of issue of this letter. The Financial
Advisors/ Asst. Financial Advisors of the Departments and Chief Accounts
Officers/ Accounts Officers of the Heads of the Departments should monitor
and verify the bank accounts of the DDOs and Implementing Agencies. The
DDOs should furnish a certificate to the Treasury along with the salary bill for
the month of May, 2020 that they have deposited the entire parked fund
available in the bank accounts held by them as per this letter into
Government Account, failing which the salary bills for the month of June,
2020 onwards would not be processed by the concerned Treasuries/Special
Treasuries/ Sub-Treasuries till such exercise is completed and the certificate is
furnished. Further, Administrative Departments are requested to review the
action taken by DDOs under their control and also by all PSUs/ Societies/
Autonomous Bodies and any other entity set up by Government under their
Department to comply with above instructions.
5. In case there would be requirement for expenditure in respect of any of
the existing/ closed schemes in future, funds would be made available
through re-budgeting under those schemes.
6. Any Department, Heads of department, DDO or implementing Agency
seeking any clarification relating to classification of the money parked and
the appropriate Head of Account to deposit the money, can make
reference directly through e-mail to budgetofficer.od@gov.in or by WhatsApp
to (+91)9438161111. Clarification to the concerned authority would be sent
through return mail or by WhatsApp at the earliest.
Yours Faithfully,
Sd/Principal Secretary to Government

3

<!-- page 9 -->

COVID-19
URGENT
GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No. 15352 /F
Date.16.05.2020
FIN-BUD2-BT-0003-2020

From
Shri Ashok Meena, IAS
Principal Secretary to Government
To
The Additional Chief Secretaries/
All Principal Secretaries/Secretaries to Government
All Heads of the Department/All Collectors
Sub: Special drive for payment of pending dues of different MSMEs,
Industries, Municipalities and Utilities during COVID-19 pandemic.
Sir/ Madam,
I am directed to say that much of the economic activity in the State
has been severely affected during this COVID-19 related lock-down resulting
in sharp drop in revenue earning of all organizations providing goods and
services, which include MSMEs, Industries, Municipalities and Utilities.
Government is taking various measures to fight this crisis on multiple fronts. So
as to make good the financial distress of these entities to some extent and
enable them to better cope with this period of economic slowdown, it has
been decided to undertake following measures.
2. Payment of pending claims, liabilities etc. : Government Offices, State
PSUs and other Government autonomous bodies procure goods and
avail services from MSMEs, Industries, Municipalities and Utilities. Hence, their
due entitlements are required to be settled in time by concerned authorities.
Keeping in view the difficult times due to COVID-19 related lock-down, all
Government Offices, State PSUs and other Government autonomous bodies
are instructed that all dues/claims of MSMEs, Industries, Municipalities and
Utilities should be released immediately within two weeks. This will help these
entities in tiding over period of extremely low revenue realisation thereby
improving their financial health to some extent.

4

<!-- page 10 -->

3.
Release of EMDs, Security Deposits or Performance Securities : In order
to ensure proper and timely execution of a contract, the executing entities
deposit refundable sum of money as EMDs, Security Deposits or Performance
Securities, as per the terms and conditions of the contract, with the Executing
Authorities. All such deposits are usually refunded by the concerned
authorities once the contract is successfully executed. However, any such
deposits held by the authorities where the due period is already over and the
work has been completed must be released with immediate
effect. All Government Offices, State PSUs and other Government
autonomous bodies are instructed to ensure release of the same within a
period of two weeks.
4.
Payment of pending dues to Utilities and Municipalities : Pending
electricity dues, water dues, holding taxes and other dues payable to Utilities
and Municipalities are to be cleared by the Government Offices, State PSUs
and other Government autonomous bodies at the earliest.
I would, therefore, request you to kindly complete the payment of all
pending claims/ dues, and release of EMDs, Security Deposits or Performance
Securities to the MSMEs, Industries, Municipalities and Utilities within a period of
two weeks, i.e. not later than 31st May, 2020 to enable them to effectively
tackle the crisis posed by COVID-19 and continue to deliver better service.
Once this exercise is completed, a consolidated report relating to all entities
under the control of concerned Departments may be compiled by 5th June,
2020. Respective FAs may furnish the consolidated information to Finance
Department by 10th June, 2020.

Yours faithfully,
Sd/Principal Secretary to Government

5

<!-- page 11 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No. 19623/F.,
Date: 02.07.2020
FIN-BUD2-VR-0001-2020

From
Shri Ashok Meena, I.A.S.,
Principal Secretary to Government
To
Additional Chief Secretaries/
Principal Secretaries/
Commissioner-cum-Secretaries/
Secretaries/Special Secretaries to Govt.
All Heads of Departments.
Sub:

Verification

and

Reconciliation

of

Departmental

receipt

and

expenditure figures for 2020-21 with those of Accountant General
(A&E), Odisha.
Sir/ Madam,
I am directed to say that, monthly verification and reconciliation of
Departmental figures with Principal Accountant General (A&E) relating to
receipts and payments in the Consolidated Fund of the State Government is
necessary to watch the trend of receipts as well as payments and avoid
misclassification of receipts and expenditure which results in incorrect
reporting of receipts and expenditure.
2.

(i)
Further, the expenditure incurred under a particular scheme is
required to be reconciled/verified with the Principal Accountant
General (A&E), Odisha for issue of Audit Certificate by the Accountant
General (G&SSA and E&RSA), Odisha. Without such Audit Certificate,
Government of India and External Funding Agencies will not allow
reimbursement of expenditure. It is, therefore, necessary that
Controlling Officers/Heads of the Departments should reconcile the
accounts with Accountant General (A&E), Odisha on monthly basis as
per schedule.
(ii)
During the year 2019-20, the dates fixed by Principal Accountant
General (A&E), Odisha for verification/ reconciliation of expenditure for
6

<!-- page 12 -->

different months were communicated to the Controlling Officers/ Heads
of Departments in Finance Department Circular No.30342/F., dated
06.09.2019 and despite repeated request, some of the Controlling
Officers/ HODs did not ensure verification/ reconciliation, and for which
concern was expressed by the Accountant General (A&E), Odisha.
3.
The Controlling Officers are required to reconcile their receipts and
expenditure with that of the Principal Accountant General (A&E), Odisha as
per Rule-25 and Rule-319 (vi) of O.G.F.R. Volume-I. The online reconciliation
facility has been made available in the Treasury Portal. In this facility, the
expenditure and receipt data compiled in the VLC system of Principal
Accountant General (A&E), Odisha is being uploaded into the Treasury Portal
through the Principal Accountant General (A&E), Odisha interface in the
IFMS. The data pertaining to expenditure and receipts generated from the
VLC system is becoming the basis of reconciliation of accounts between the
Controlling Officer & Principal Accountant General (A&E), Odisha. However, it
will take some time for the receipt reconciliation module to be fully
functional. Till such time, the receipt reconciliation can be carried out through
communication of suggestion for change or correction to the O/o the
Principal Accountant general (A&E), Odisha manually.
4.
The Controlling Officers’ reconciliation functionality in the Treasury
Portal is carried out in two separate stages: At t he first inst ance, t his
funct ionality provides facility for correct ion of account s bet ween t he Drawing
& Disbursing Officer and t he Treasury/Sub-Treasuries before t he submission of
mont hly account s t o Principal Account ant General (A&E), Odisha. In t he
second st age, the receipt and expenditure report s compiled by t he Principal
Account ant General (A&E), Odisha are made available t o t he Cont rolling
Officers in t he Treasury Port al.
5.
The DDO-wise break up of expenditure/receipt details in the Treasuries
are provided to each Controlling Officers against the respective Chart of
Accounts both in the consolidated manner and also in details,
challan/voucher–wise, for identification and settlement of the discrepant
items of receipts and expenditure.
6.
Further, the Treasury/Sub-Treasury Officers are required to ensure that
the DDOs under their jurisdiction should verify and submit the proposal for
correction of accounts, if any, in the online reconciliation module prior to
finalization of Treasury accounts. The facility of accounting classification of all
vouchers passed for payment at the Treasury level will be made available to
7

<!-- page 13 -->

the DDO in the online reconciliation functionality. If there is any misclassification in booking of the receipt/expenditure at the Treasury level or
otherwise, the DDO shall send a proposal for correction of accounts to the
Treasury Officer/Sub-Treasury Officer before closure of monthly accounts, i.e.
before 3rd day of the subsequent month. The proposal received from the
DDO will be examined by the Treasury and necessary correction may be
made in the accounts. The effective use of this functionality will substantially
reduce the possibility of mis-classification at the level of Accountant General
(A&E), Odisha as they are importing data from IFMS and the burden of
monthly accounting reconciliation for the Controlling Officers. The COs may
impress upon DDOs under their control to ensure that the head classification
booked by the treasuries are correct.
7.
After submission of Treasury accounts, the proposal for correction has
to be submitted by the DDO to their respective Treasuries who shall forward it
to the Principal Accountant General (A&E), Odisha for acceptance. On
receipt of approval from the Principal Accountant General (A&E), Odisha,
Treasury Accounts will be revised by the Treasury Officer. Treasury will not
accept any proposal of DDO relating to budgeted heads after sub mission of
accounts to AG.
Secondly, if any correction of account is made through the process of
reconciliation between the Controlling Officer and the Principal Accountant
General (A&E), Odisha, the same will also be reflected in the Treasury
Accounts and shall be communicated to the DDO. The DDO/Controlling
Officer shall verify the same from the reports available and update their
records accordingly.
8.
The Controlling Officers are required to cause verification of the monthwise payment & receipt details in the Controlling Officers reconciliation
functionality of Treasury Portal and indicate the discrepant items and
suggest corrections/ transfer entry online to the Principal Accountant General
(A&E), Odisha, or their acceptance of the accounts as compiled in the VLC
system. In case of any discrepancy, the Controlling Officers are required to
mention the details and suggest the appropriate Chart of Account in which
the expenditure/receipt should be booked. In case where the Controlling
Officer has no knowledge as to where the receipt or expenditure would be
booked, it should mark the reported figure as not related to them and may
also record his/her specific observation in the remark field.

8

<!-- page 14 -->

9.
On receipt of the online request from the Controlling Officer, the
Principal Accountant General (A&E), Odisha shall examine each such
suggestion for rectification/ transfer entry and carry out the adjustment on
the basis of vouchers/ challan and also the data available at their end. If the
suggestion is accepted, then the Principal Accountant General (A&E),
Odisha will instruct the Treasuries to rectify the accounts wherever required
within a defined time frame which is to be given effect to through the
Treasury Portal. On acceptance of the request of the Controlling Officer by
the Principal Accountant General (A&E), Odisha, the Treasury accounts
should be revised in the Treasury Portal. The Treasury Officers are required to
submit revised account as per the prescribed procedure. The Principal
Accountant General (A&E), Odisha will download the revised electronic
accounts into the VLC after submission of system generated revised Treasury
Accounts by the Treasury Officer.
10.
Where the Principal Accountant General (A&E), Odisha does not
agree to the suggestion of the Controlling Officer the request may be
rejected with reasons or suggestions. The Cont rolling Officer in such a case
can either accept the suggestion of Principal Accountant General (A&E),
Odisha leading to confirmation of provisional account or may send back to
Principal Accountant General (A&E), Odisha with a request to reconsider its
decision. It may also suggest a fresh Chart of Account along with the request
for reconsideration. Subsequently, the Principal Accountant General (A&E),
Odisha will indicate the appropriate head of account for classifying the
receipt and expenditure and intimate the Controlling Officers in writing the
reasons for non- acceptance.
11. The reconciliation can be taken up by the officials of the Controlling
Officers by using their own User ID & Password subsequently for the remaining
part of the financial year as per the programme schedule. In case of failure
on the part of the officials of the Controlling Officer to reconcile the
expenditure in time, a system generated mail will be sent to the
Administrative Department, Finance Department and Principal Accountant
General (A&E), Odisha.
12.
Office of the Principal Accountant General (A&E) , Odisha has fixed
the following deadline for the monthly verification/reconciliation of
expenditures during the year 2020-21 in their letter No.VLC (B&R)/Recon.
2020-21/38 dated 18.06.2020.

9

<!-- page 15 -->

Cut-off date for receipt of
alteration proposal/
acceptance letter

Month of Account

Uploading of Data in
iFMS

April, 2020

17.06.2020

May, 2020

02.07.2020

June, 2020

31.07.2020

19.08.2020

July, 2020
August, 2020

31.08.2020
05.10.2020

16.09.2020
22.10.2020

September, 2020

03.11.2020

20.11.2020

October, 2020
November, 2020
December. 2020

03.12.2020
31.12.2020
01.02.2021

18.12.2020
20.01.2021
17.02.2021

January, 2021
February, 2021

04.03.2021
02.04.2021

19.03.2021
20.04.2021

March, 2021

13.05.2021

31.05.2021

17.07.2020

13.
The reconciliation of the receipt can be made by the Controlling
Officer after downloading the report on receipts from the Treasury portal. The
suggestion for correction can be made manually in the usual process till the
software development in respect of such reconciliation is complete. The time
schedule prescribed for reconciliation of expenditure is also to be followed in
case of receipts. A list containing the names of the Controlling Officers
responsible for reconciliation of various kinds of receipts is enclosed in the
Annexure-I which is indicative.
14.
It has been stated that reconciliation of receipt and expenditure figures
beyond the above time schedule shall not be entertained and the figures
booked by Principal Accountant General’s office will be treated as final and
will be reflected in the Finance and Appropriation Accounts for the year
2020-21.
15.

I would, therefore, request you to kindly issue necessary instructions to

the Controlling Officers for causing online reconciliation of Departmental
expenditure figures and also carry out verification of departmental receipts
by the prescribed time-frame.
Yours faithfully,
Sd/Principal Secretary to Government
10

<!-- page 16 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No.20042/F
Date: 07/07/2020
FIN-BUD1-MISC-0003-2020

From
Shri Ashok Meena, IAS
Principal Secretary to Government
To
The Additional Chief Secretaries/
Principal Secretaries/
Commissioner-cum-Secretaries/
Secretaries to Government
All Departments
Sub: Adoption of expenditure rationalization measures in the wake of
economic downturn due to the global pandemic Covid19.
Sir/ Madam,
I am directed to say that we are going through a crisis of
unprecedented nature due to the global pandemic COVID-19. It has posed
challenges in every sphere of our life. The State Government has been
fighting the pandemic with all its might to minimize the casualty. Strategic
imposition of shutdowns/lockdowns at various places could ensure minimum
spread of virus. However, nation-wide lockdown/ shutdown have interrupted
the economic activities which resulted in shortfall in realization of resources.
On the other hand COVID management would require higher expenditure.
There would also be higher spending need for generating employment and
livelihoods for the most affected sections of the society.
2. Therefore, all Administrative Departments are required to prioritize their
expenditure needs in order to limit the expenditure within the resources
available with priority to make fiscal space for COVID-19 related expenditure.
Accordingly, it has been decided to adopt the following expenditure
rationalization measures until further orders :
3.

Rationalisation of expenditure on travel and vehicle:
a. There shall be complete ban on purchase of new vehicles for the
next two years.
11

<!-- page 17 -->

b. Travel/ official tours have to be avoided in general. Video
Conferencing / use of IT for meetings/ official work should become
preferred default mode.
c. There shall be complete ban on travel outside the country and air
travel in business class using government funds. Air journey should be
avoided and meetings through Video Conferencing may be
preferred. In exigencies, approval of authority one level higher than
the present delegation would be required for journey by air.
d. There shall be complete ban on journey by train in 1 st class AC by
Government Officers.
e. New hiring of vehicles would require concurrence of Finance
Department. Expenditure on POL shall be minimized.
f. No Officer while on tour shall be allowed reimbursement for
occupancy in any hotel in Delhi, Kolkata, Mumbai and Chennai
except when the Home Department has regretted availability of
accommodation in the respective Government Bhawans or Niwas.
4.

Rationalisation of Establishment Expenditure :
a. There shall be complete ban on purchase of new equipment except
medical equipment and equipment required for internal security.
However, equipment required for promoting digital communication
can be procured with concurrence of Finance Department.
b. There shall be complete ban on expenditure on renovation,
remodelling, furnishing etc. and purchase of furniture and fixtures in
Government Offices.
c. There shall be complete ban on meetings, seminars, workshops and
hosting of Official lunch and dinner in hotels through Government
funds. Video Conferencing should be the preferred mode for
meetings and conferences.
d. There shall be complete ban on sanction and drawl of new Longterm Advances (HBA, Motor Car Advance, Computer advance etc.)
and other advances. However, if a part of the HBA out of the total
sanctioned amount is drawn, the balance will be allowed to be
drawn.
e. There shall be complete ban on LTC for two years i.e. till 31st March,
2022.
f. Strict economy should be observed in the use of paper and other
stationary articles. Use of electronic mode of communication (such
as OSWAS, e-dispatch, e-Office etc.) along-with digital/e-signatures
should be the preferred mode instead of physical communication
using paper.
12

<!-- page 18 -->

g. Expenditure out of the provision „Other Contingencies‟ to be kept at
the minimum level. Only expenditure relating to COVID
management and other essential expenditure like purchase of office
stationeries etc. may be incurred. There shall be no expenditure on
purchase of office furniture/ fixtures and furnishing. Expenditure out
of the provision „Other Contingencies‟ will be capped at 60% of the
Budget Provision for the whole year.
h. Most economic scheme with unlimited call facility may be opted to
minimize the telephone expenses.
5.

Recruitment and Man power engagement:
a. There shall be a complete ban on creation of new posts except for
Health & Family Welfare Department. In case there is absolute
necessity for creation of posts for modernization of administration or
effective implementation of development and welfare programmes,
the same shall be considered only against abolition of equivalent
posts with concurrence of Finance Department.
b. There shall be automatic abolition of redundant posts which have
remained vacant for more than 5 years. All the Administrative
Departments are to issue formal abolition order by 31 st July 2020 and
furnish a report to Finance Department and G.A and P.G
Department.
c. New engagement of consult ants, outsourcing and engagement of
retired Government employees shall be restricted and prior
concurrence of Finance Department would be required for the
purpose.

6.

Austerity in implementation of Schemes :
a. No new State Schemes/ Projects to be taken up by Administrative
Departments except Health & Family Welfare Department. However,
if any new scheme is essentially required for emergent public service,
the same can be taken up only after appraisal by EFC/SFC following
the due procedure and with specific concurrence of Finance
Department for any expenditure under such scheme.
b. There shall be capping of expenditure on continuing State Schemes
for the current financial year 2020-21 except schemes relating to
Livelihoods in Agriculture & allied sector and expenditure for
combating COVID-19. The list of such schemes will be shared with
the Administrative Departments separately.
13

<!-- page 19 -->

c. Operation and Maintenance expenditure can be incurred only after
approval of Annual Maintenance Plan (AMP) by Finance
Department. Engineering Departments to prepare their AMP for the
year 2020-21 limiting it to a level of 60 % of the Budget provision, in
consultation with Finance Department initially and on availability of
resources balance work could start after November-2020.
d. Administrative expenditures, if permitted as part of State Scheme
guidelines, should be minimized and restricted below 1% of the funds
in that scheme. In case some manpower has been engaged for
monitoring the scheme and there is difficulty in meeting their salary
due to the above restriction, concurrence of Finance Department
would be required for such additional expenditure.
e. No expenditure for renovating and re-furnishing of Offices, guest
houses and Government buildings will be permitted. Expenditure for
repair and renovation of Government quarter should be minimized.
Expenditure of more than Rs.5 lakh for repair and renovation of any
Government Office building and more than Rs.2 lakh for repair and
renovation of any Government residential quarter during this year
would require approval of Government.
f. No expenditure should be incurred for construction of new statues
and beautification of parks and public places during this year should
be avoided.
g. New tender of execution of works, procurement of goods and
services is t o be avoided. However, if it is necessary to meet any
emergent public service, floating of new tender exceeding value of
Rs.5 crore and procurement of goods and services exceeding value
of Rs.25 lakh would require prior concurrence of Finance
Department. For values less than indicated here, Administrative
Department need to take approval of Government before floating
tender/ bid.
h. If a tender has already been floated, the same is to be reviewed
and if it is not urgent in nature, the same should be cancelled and
work/ procurement order should not be issued. Tenders related to
new official buildings, Guest houses and Residential buildings shall be
cancelled forthwith for a period of two years till 31 st March, 2022.
i. Expenditures in respect of Centrally Sponsored Schemes (CSS) shall
be incurred only after receipt of Central Share. In case of salary
component of the CSS, expenditure can be incurred without receipt
of Central Assistance only with concurrence of Finance Department.
Financial Advisors of the Administrative Department shall ensure the
discipline. The relaxation allowed in this regard in the para-10(ii) of
14

<!-- page 20 -->

j.

7.

„Regulations to incur expenditure out of Budget Provision‟ circular
issued vide FD Letter No-10324/F Dt.23.03.2020 has been withdrawn
and communicated vide FD Letter No-15275/F Dt.15.05.2020.
RIDF, EAP and other resource tied up projects and schemes may be
implemented in time bound manner. Incomplete and on-going
capital works should be completed to realize the intended public
benefits. However, project s which have long gestation period may
be deferred.

Applicability to
organizations

aided

institutions / Cooperatives / autonomous

These restrictions, as may be relevant, shall also be applicable to all
Aided Institutions/ Co-operatives/ Autonomous Organizations in which the
State Government has explicit or implicit financial stake.
I would, therefore, request you to kindly adhere to the above
expenditure rationalization measures and instruct the COs/ DDOs under your
control accordingly so as to enable the State Government to meet the
expenditure requirement in effective management of COVID-19.

Yours faithfully,
Sd/Principal Secretary to Government

15

<!-- page 21 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No.22855/F.,Bhubaneswar,

Date: 03/08/2020

FIN-BUD1-MISC-0003-2020

OFFICE MEMORANDUM
Sub: Admissibility of long term advance for purchase of Computers.
State Government had imposed ban on long-term advances including
advance for purchase of computers in para-4(d) of Finance Department
Office Memorandum No.20042/F, dt.07.07.2020 as part of adoption of
expenditure rationalization measures in the wake of economic downturn due
to the global pandemic Covid19. However, considering the prevailing
pandemic situation for facilitating work from home, in partial relaxation of the
aforesaid provision Government has been pleased to allow drawal of longterm advance for purchase of computers.
By order of Governor
Sd/Principal Secretary to Government

16

<!-- page 22 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No.29018 /F,
Date: 29/10/2020
FIN-BUD1-BT-0004-2020

From
Sri Ashok Meena, I.A.S.
Principal Secretary to Government
To
All Secretaries to Government/
Heads of Departments
Sub: Preparation of Revised Estimates for 2020-21 and Budget Estimates for
2021-22.
Sir/Madam,
I am directed to say that the process of formulation of Revised
Estimates for 2020-21 and Budget Estimates for 2021-22 are to be initiated and
completed in time for enabling Finance Department to present the budget in
the Odisha Legislative Assembly at the appropriate time. In addition to the
general instructions contained in Chapter- III of Odisha Budget Manual,
following supplementary instructions are to be followed while framing the
Revised Estimates for the current year 2020-21 and Budget Estimates for the
financial year 2021-22.
2.
Government’s strategic priorities for the next five years : COVID-19
pandemic has posed a tremendous challenge to every sphere of
Governance. The State has been fighting the pandemic since March, 2020
and the battle against the virus is likely to continue for some more time. While,
priorities of the State Government in the medium-term still remains to achieve
Sustainable Development Goals through faster reduction of poverty,
increasing farmer‟s income, providing piped drinking water to all, making
available quality affordable health care facilities, enabling quality education
& skills development, providing quality physical infrastructure for improving
economic activities and empowering women, ST, SC & other vulnerable
populations to enhance their participation in economic activities, but in short run effective COVID management, saving lives and providing livelihoods to
the people will remain priority.
17

<!-- page 23 -->

3.
Economic Outlook : Global economy is projected to grow at (-)4.9%
during 2020-21 and the COVID-19 pandemic has had a more negative
impact on activity in the first half of 2020 than anticipated, and the recovery
is projected to be more gradual. I n 2021 global growth is projected at 5.4
percent. IMF has projected contraction of Indian economy around 4.5%
during this fiscal and will have modest recovery of 6% during 2021-22. In case
of Odisha, the economy is projected to contract by about 1-2% in 2020-21
and it is expected to register a growth of about 7% during 2021-22.
4.
Resource Outlook : The economic contraction both at national and
sub-national level, will adversely impact the collection direct and indirect
taxes during 2020-21 and also in 2021-22. So, the share tax and the grant -inaid receivables from Centre will be affected during 2020-21 as well as in
2021-22. To counter the adverse impact of shut down and lock down on
State‟s resources, the State Government has taken some timely steps to raise
one-time revenues through renewal of mining leases and mopping up of
unused money parked in bank accounts. These efforts have substantially
reduced the resource gap and overall collection of the State‟s own tax and
non-tax till August, 2020 is marginally less compared to previous year.
However, if the effect of one-time collection is taken out, most of the own
revenue items are underperforming. Considering the likely level of Central
Assistance and expected receipts from own revenue, the estimated shortfall
in revenue during the current year would be of the order of 20-25%. Hence,
the State may have to depend upon higher borrowing during the current
year to finance higher spending on pandemic management. State‟s own
revenues are expected to register moderate growth in FY 2021-22 primarily
due to contraction of base and moderate growth expectations for the State
economy. The GST compensation in the year 2021-22 would depend on the
performance of the economy. Besides, there still remains uncertainty on the
quantum of Share in Central Taxes as the State‟s horizontal share may get
changed in the final report of the 15 th Finance Commission. Considering all
the factors, spending is expected to increase by about 12 percent in FY 202122 over the current year‟s revised estimates.
5.
FRBM compliance : The Odisha FRBM Act, 2005 mandates the State to
generate revenue balance and contain the fiscal deficit within 3% of GSDP.
Considering the higher resources requirement by the States to fight COVID-19
and maintain the standards of service delivery to the public, the Government
of India have decided to allow additional fiscal deficit of 2% of GSDP,
increasing the borrowing limits of the State from 3% to 5% during 2020-21. This
additional borrowing is linked to four sect or specific reforms, which the State
18

<!-- page 24 -->

Government is trying to achieve to become eligible for the additional
borrowing. The contraction of the GSDP coupled with higher borrowing can
jeopardise the debt sustainability unless a prudent fiscal path is adopted in
medium term. Thus, the State Government would try to adhere to FRBM
requirements for Revised Estimates, 2020-21 and Budget Estimates, 2021-22
are as below:
Indicators

2020-21 (BE)

2020-21 (RE)

2021-22 (BE)

Rev enue Surplus (+)/ Deficit () (% of GSDP)

(+)1.58%

Rev enue Surplus

Rev enue
Surplus

Fiscal Deficit (% of GSDP)

(-) 3.00%

(-) 3.5%

(-) 3%

I P/ RR Ratio

5.76%

Year-end debt stock
(% of GSDP)

18.99%

10%
(upper limit)
25%
(upper limit)

10%
(upper limit)
25%
(upper limit)

6.

Preparation of annual budget for FY 2021-22 :

As part of the PFM reform, the State Government had introduced a
new budget making process for preparation of Annual Budget, 2020-21. The
preparation of budget for FY2021-22 will be based on the principles adopted
for Annual Budget, 2020-21 which int er-alia include advanced budget
calendar, macro-fiscal forecasting and advanced indication of
Departmental ceilings (both for Administrative and Programme Expenditure).
The Departments will be given 2-3 months‟ time to have thorough scrutiny
and prioritization of the Budget proposals within the ceiling communicated.
All the departments will be communicated with a multi-year ceiling, so that
Departments would have predictability in fund flow and can make multi-year
project planning.
Following budget process will be adopted for FY 2021-22 and longer
time will be allocated to provide expenditure estimates by 15 th December,
2020.
i.

ii.

Ceiling will be communicated through BETA system on broad
category of expenditure with flexibility to the Department s to prioritize
the expenditure within the broad ceiling.
Each Administrative Department will receive their departmental
ceiling disaggregated by Administrative Expenditure (Salaries,
Maintenance and others), Programme Expenditure (State Sector
19

<!-- page 25 -->

iii.

iv.

v.

vi.

7.

Schemes, Centrally Sponsored Schemes, and Central Sector
Schemes), Transfers from State (Central Finance Commission, State
Finance Commission and others) and Disaster Response Funds (SDMRF
and NDMRF).
Previously established norms and practices should be adopted for
preparation of estimates by Departments within the ceilings
communicated. To this end, the guidelines for determining
Administrative Expenditure are contained in tabular form at
Annexure – I.
Expenditure rationalization measures communicated vide Finance
Department letter no 20042/F dated 07.07.2020 shall remain in force till
end of the financial year 2021-22. Hence, proposals of Administrative
Departments for the Revised Estimates for 2020-21 and Budget
Estimates for 2021-22 are should be in adherence to above guidelines.
Finance Department in consultation with the Planning &
Convergence Department will bring out a “Fiscal Strategy Paper”
towards the month of November, 2020 indicating the assumptions for
revenue and expenditure projections in the medium t erm and the
outlook for the State economy and finances.
The Annexures in which various budget related information are being
collected have been rationalized and steps are taken to collect more
information from the database available in various systems. Other
documents like Statement under FRBM Act, Gender & Child Budget
document etc. would be prepared mostly by using the information
from budget database.

Preparing Budget
Expenditure :

Estimates,

2021-22

in

respect

of

Programme

a. Sectoral priorities are to be identified in line with State priorities and
SGDs where ever relevant. Allocation under State Sector Schemes
should not be made for schemes not appraised by EFC/SFC as the
case may be.
b. Allocation for Centrally Sponsored Schemes and Central Sector
Schemes should be proposed taking into account the likely level of
Central Assistance to be received for the schemes for the budget
year within the overall ceiling communicated for the sectors.
c. Earmarking of allocation for different Schemes under the Programme
Expenditure for Tribal Sub-Component and Scheduled Caste SubComponent is to be done as per the norm.

20

<!-- page 26 -->

d. Break-up of allocation under Programme Expenditure for District
Sector and State Sector Schemes is to be made as per the current
practice.
e. Convergence of extra-budgetary resources to budgetary resources
and between budgetary resources is to be made a part of the
budgetary exercise to ensure productive output.
8.

Completion of Annexures :

Some information along-with the budget proposals are collected for
budget scrutiny at Finance and P&C Departments. With automation of
budget preparation process and availability of various data in BETA and IFMS,
it has now become possible to fetch a number of information from the
systems without depending upon the Departments. The three annexures now
prescribed will seek information on position, man-power & salary requirement,
grant -in-aid salary requirement and vehicle position. Even the manpower
and salary related annexures would be made available to the DDO with prepopulated data from HRMS, which are to be verified and modifications to be
made if required. This will make it simple and easy for all budget estimating
officers to complete the annexures. The relevant annexures to be completed
are as below :
i.
ii.
iii.
9.

Annexure-II: Sanctioned Strength, Vacancies and Man-in-position
and salary requirement
Annexure-III: Estimate of Grant -in-aid Salary
Annexure-IV: Position of vehicles and related expenditure
Process for Submission of Budget Proposal :

(i)

(ii)

There will be no change in budget making process in the IFMIS
system for the DDOs and the Controlling Officers for processing the
budget proposal for the financial year 2021-22.
However, ceilings will be communicated in the BETA budget
preparation system at the broad expenditure category as
mentioned in para-6(ii). Departments are required to map the
budget proposals to the broad ceilings. Proposals beyond the ceiling
will not be allowed to be processed in BETA system.

10.
Conducting pre-budget consultation meetings : All COVID-19 protocols
and social distancing norms shall be strictly followed in conduct of prebudget consultation meetings. Hence, all such meetings to be conducted by
21

<!-- page 27 -->

Finance Department as well as Planning & Convergence Department shall
be convened only through virtual platform.
11.

Budget calendar and timelines for completing the budget estimates

A lot of information is to be collected and compiled before the budget
is placed before OLA. Hence, budget documents are to be prepared in a
tight time schedule. Therefore, all Departments and Controlling Officers are
required to adhere to the timeline mentioned in the following table.
Date
October, 2020
Nov ember, 2020
15t h December,
2020
16t h -31st
December, 2020
3 February, 2021
rd

5t h February, 2021
7t h -10t h February,
2021
2nd w eek of
February, 2021
3rd w eek of
February, 2021
End March, 2021

Activity
Virtual
Training
sessions
for
departments
Fiscal Strategy Paper
Submission of proposals for Budget
Estimates, 2021-22
Pre-budget consultation meetings
Rev ision of estimates after Pre-budget
consultation and Union Budget,
2020-21
Meeting w ith Secretaries of major
spending Departments by Chief
Secretary/ DC-cum-ACS
Approv al of Annual Budget, 2020-21
by the Council of Ministers
Drafting of budget documents

Responsibility
Finance Department
Finance Department
Administrativ e
Departments
Finance Department
P&C Department
Finance Department
P&C Department
Finance Department
P&C Department
Finance Department
Finance Department

Budget presentation by Minister,
Finance
Presentation of Appropriation bill

Finance Department
Finance Department

Enclosures: List along with proforma.
Yours faithfully,
Sd/Principal Secretary to Government

22

<!-- page 28 -->

ANNEXURE-I
Guidelines for preparation of budget proposal for Administrative Expenditure
Sl. No.

Unit of Expenditure

Percentage growth

1

Pay

3% on account of Annual
increment

2

Dearness Allowances

28% of Basic Pay

3

HRA

@ 12% of the Pay or the
double the HRA paid in 201920, whichever is less

4

Requirement on account of
MACPS

To
be
mentioned
for
assessment of the total salary
requirement.

5

7th CPC arrear

No need to submit. FD will
work out and make necessary
provision.

6

Consolidated
pay
contractual appointees.

7
8

for

Remarks

No salary provision against
the vacant posts except in
cases where Finance
Department has explicitly
allowed filling up of vacancies

Should be shown separately

Salary/ wages of work
charged/ Job Contract/ NMR/ As per existing norm
DLR
Same level of B.E 2020-21
Telephone, TE and OC
(BE)

9

Decretal dues and
Acquisition Cases

Land

10

RCM

@Rs.2000/- per head

11

MV (PoL)

Same level of B.E 2020-21
(BE)

12

MV (Hiring charges)

As per approved rate.

13

LTC

Nil

14

RRT, Municipal Tax, Water
Charges, Electricity charges

As per actual requirement

15

O&M Expenditure

Same level of B.E 2020-21
(BE)

16

Debt servicing cost

As per actual requirement

17

Loans & Advances

Only Computer Advance

As per actual requirement

Finance Department letter no
20042/F dated 07.07.2020
may be referred

23

Subject to preparation of
Annual Maintenance Plan

<!-- page 29 -->

Annexure-IIA

Sanctioned Strength, Vacancies and Man-in-position and salary requirement
D.D.O of _________________________________( Name of the Establishment)
Category :

(Administrative EXP/Programme Expenditure/Disaster Management/Transfer from State)

Sub Category:
Sector :

E.O.M/DSE/SSS/CS/CSS/NDRF/SDRF/SFC/CFC/

State Sector/District Sector

Chart of Account:

Major Head

Sub-Maj Head

Minor Head

Sub-Head

Voted/Charged

Abstract of Employee Strength

Sl. No.

Group

Sanctioned
Strength

1

2

3

Vacancy as on
01.03.2020

Anticipated
vacancy from
01.03.2020 to
01.03.2021

Total Vacancy
(4+5)

Men in
position as
on
01.03.2021

Vacancy likely to be
filled up (+)/arise due
to retirement etc.(-)
during the next Year

Anticipated Men in
position for whom
budget provision is
proposed

4

5

6

7

8

9

GROUP-A
GROUP-B
GROUP-C
GROUP-D

24

<!-- page 30 -->

Detailed calculation of Salary

SL No.

Name of the
incumbent

Employee
ID

Group

Current
Basic Pay

Basic Pay
(as on 1st
March Next
year)

Total yearly
Requirement Arrear Pay
under Pay (136)
- 855
(Col. 5 x 12)

1
2
Total

1

Additional Amount
due to increment/
Arrear Pay not
drawn earlier (+)

2

Exclusions for the
incumbents likely
to be absent or on
deputation (-)
Total Provision

25

DA
156

HRA
403

OA
523

RCM
516

Total

<!-- page 31 -->

Annexure-IIB
Information on Contractual Employees
D.D.O of _________________________________( Name of the Establishment)
Category

(Administrative EXP/Programme Expenditure/Disaster Management/Transfer from State)

Sub Category:

E.O.M/DSE/SSS/CS/CSS/NDRF/SDRF/SFC/CFC/

Sector

State Sector/District Sector
Major Head

Chart of Account:

Sub-Maj Head

Minor Head

Sub-Head

Detailed
Head

Actual Exp
during 202021 upto ____

2020-21
Revised
Estimate

Voted/Charged

Details of contractual employees engaged
Name of the Posts

No. of post as
on 31.03.2020

Increase (+) or Decrease
(-) in Man in Position
during 01.04.20 to
31.03.2021

Total man in
position as on
01.04.2021

26

Actual Exp
during 201920

2021-22 B.E.

<!-- page 32 -->

Annexure-IIIA
Estimates of Grants-in-aid Salary
(AE, PE Separately)

Scale of
Pay

(1)
(a)

Total
sanctioned
and
approved
strength

No. of
Vacancies
as on
01.03.2021

Sharing
pattern
by State
Govt.

RE for
202021

(2)

(3)

(4)

(5)

Estimate of current salary for 2021-22

Pay

DA
@12%

HRA

RCM

OA

Total
(6 to
10)

(6)

(7)

(8)

(9)

(10)

(11)

Arrears
salary if
any; give
the
particulars

Additionality
on account
of RACP

Total
estimates
for 2021-22
(11+12)

(12)

(13)

(14)

Teaching posts

(b) Non-Teaching posts
(c)

Total (a+b)

1.

For salaries drawn under direct payment system information in respect of Colleges, Secondary Schools and Primary Schools be compiled and
furnished in separate statements. The information for Secondary Schools and Primary Schools be furnished in separate statements for each
Inspector of Schools and each District Inspector of Schools.
In regard to grant-in-aid to meet the share up to a particular limit similar information may be furnished separately for Colleges and Schools in
separate Statements.
The H & U.D. Department need furnish similar information in respect each U.L.Bs provided with grants-in-aid upto a specified percentage of pay
and Dearness Allowance.

2.
3.
4.

Panchayati Raj Department shall furnish in respect of the posts for which Govt. provides Grants-in-aid.

5.

Agriculture Dept./Industry Dept./H & FW Dept. and other Departments providing Grants-in-aid for salary are also to furnish.

27

<!-- page 33 -->

Annexure-IIIB
(For School & Mass Education Department / Higher Education Department only)
Particulars of staff strength, men in position & posts abolished in respect of aided private Schools / Colleges under Administrative Expr.
/ Programme Expr.
(Rs. in Trs.)
No. of
Current
employees
No. of
requirement in
receiving GIA in
schools/Colleges
the prerespect of those
receiving GIA
revised scale
Schools /
per annum.
Colleges
(1)

(2)

(3)

Arrears in the
pre-revised
scale, if not
paid, & carried
over to
2020-21

Total for
2020-21 in
the
Prerevised
scale (3+4)

Differential
amount of salary
on the revised
scale of pay for
the year 2020-21
only

Arrear
differential
pay in the
revised
scale upto
31.03.2020

Total
differential
arrear
(6+7)

(4)

(5)

(6)

(7)

(8)

28

<!-- page 34 -->

Annexure-IIIC
Information on teaching and non-teaching posts, vacant posts, vacant posts abolished, men in position etc. under grant-in-aid fold.
(For School & Mass Education Department/ Higher Education Department only)
(Separately for Administrative Expr. and Programme Expr.)
(Rs. In Trs.)
Name of the
School/College

Total teaching posts receiving Grant-in-aid
No. receiving
1/3rd
2

1

Vacant posts if any receiving
GIA as on 01.03.2019
Teaching
11

Nonteaching
12

Total
(11+12)
13

No. receiving
2/3rd
3

No. receiving
full.
4

14

Nonteaching
15

Men in position as on 28.02.2020 after abolition of the
vacant posts indicated in Col.22

No. receiving
1/3rd
6

Total

Vacant posts abolished by
30.10.2019
Teaching

Total

Total teaching
and nonteaching posts
(5+9)

9

10

No. of non-teaching staff receiving Grant-in-aid

Total
(14+15)
16

5

No. receiving
2/3rd
7

No. receiving
full.
8

Men in position as on 01.11.2019
Teaching
17

Nonteaching
18

Total
(17+18)
19

Annual requirement of Grant-in-Aid salary for men in
position as in Col.25

Teaching

Non-Teaching

Total (23 +24)

Teaching

Non-teaching

Total (26+27)

23

24

25

26

27

28

29

Vacant Posts anticipated to be
abolished as on 28.02.2020
Teaching
20

Remarks

29

NonTeaching
21

Total
22

<!-- page 35 -->

Annexure-IV
Information on Vehicles
D.D.O of _________________________________( Name of the Establishment)
Category : (Administrative EXP/Programme Expenditure/Disaster Management/Transfer from State)
Sub Category :
Sector :

E.O.M/DSE/SSS/CS/CSS/NDRF/SDRF/SFC/CFC/

State Sector/District Sect or

Chart of Account:

Major Head

Sub-Maj Head

Minor Head

Sub-Head

Detailed Head

Object Head

Voted/ Charged

397-MV
20009-Hire

Details of Vehicles Deployed
Category of
Vehicles
(Government/
Hired)

No. of Vehicles
as on
31.03.2019

Additional No. of
Vehicles during
01.04.19 to
31.03.2020

Total Vehicles
as on
01.04.2020

Actual Exp
during 2018-19

Actual Exp
during 2019-20
upto ____

2019-20
Revised
Estimate

2020-21 B.E.

1

2

3

4

5

6

7

8

30

<!-- page 36 -->

Ashok Meena, IAS
Principal Secretary to Government
D.O. No. 33453
FIN-BUD2-CAG-0002-2020

Date:- 17.12.2020

Dear Sri Basantiaji,
Sub:

Compliance to audit observation on mis-classification between capital
and revenue heads of accounts during 2019-20.

This has reference to Letter No-AA-Fin-1-1-(2019-20)-231 Dt.12th October,
2020 on the abov e subject. Clarification is sought for on the mis-classification to
the tune of Rs.5,942.66 crore of rev enue expenditure under capital/ loan Major
Heads in respect of 17 nos. of Grants w ith 26 nos. of Major Heads. The audit
observ ations w ere looked into carefully, and a compliance note w as sent by
Finance Department v ide Letter No-30942/F Dt.20.11.2020 w herein it w as stated
that the accounting treatment of the grants should be considered from the
ow nership point of v iew i.e Grants for Creation of Capital Assets.
2.
Subsequently, the issue w as discussed in the Exit Conference held on 26th
Nov ember, 2020. I n this regard, I w ould like to draw your kind attention to Rule-30
and 31 of Gov ernment Accounting Rules, 1990 regarding the criteria for
determining w hether expenditure should be classified under heads of Capital
Section or Rev enue Section of the Consolidated Fund. Expenditure of a capital
nature to be classified in the Capital Section shall broadly be defined as
expenditure incurred with the object of either increasing concrete assets of a
material and permanent character. Expenditure on a temporary asset or
expenditure on Grants-in-aid to local bodies or institutions for the purpose of
creating assets which will belong to these local bodies or institutions to be
classified as Revenue Expenditure.
3.
The basic principles gov erning the allocation of expenditure on a Capital
Scheme, betw een Capital and Rev enue accounts is that Capital account
should bear all charges for the first construction and equipment of a project as
well as charges for intermediate maintenance of the work while not yet opened
for service. It would also bear charges for such further additions and
improvements as may be sanctioned under rules made by competent authority.
How ev er, rev enue account shall bear all subsequent charges for maintenance
and all w orking expenses.
4.
I n most of the cases pointed out by the audit, the w orks are executed by
separate societies/ institutions. Audit has pointed out that the societies /
institutions being separate legal entities, the expenditure should hav e been
booked as grants to the entities and thus treated rev enue expenditure. This is,
how ev er, in contradiction of the fact that the societies/ institutions/entities in all
these cases are only implementing agencies for creation of Assets for the
Gov ernment and to be ow ned by the Gov ernment. I n case of construction of
31

<!-- page 37 -->

Medical College buildings, the assets are kept in the books of Works Department
though the institutions are giv en some operational autonomy. Similarly, in case of
piped w ater supply projects under BASUDHA, the assets created are ow ned by
the State Gov ernment but is handed ov er to GPs or other institutions to operate.
Hence, the expenditure in all such cases should be booked under Capital
Section in terms of Rule-30 of Gov ernment Accounting Rules, 1990 as the assets
created are ow ned by the State Gov ernment. Besides, in certain cases, the
amount has been w rongly draw n in Grant-in-Aid bills, w hich may be procedural
lapse, but the expenditure in such cases has been incurred for Capital asset
creation ow ned by the State Gov ernment and thus should be treated as Capital
expenditure.
5.
For example, in case of PMGSY w ork, audit has pointed out that at the
time of release of fund from the State exchequer to the PMGSY society, the
expenditure is booked under Capital Sector ev en though no asset is created at
that point of time. Hence, it should be treated as rev enue expenditure. I t is
submitted that it is only as per Gov ernment of I ndia guidelines for the Scheme,
fund is released to the society account w ithin a specific timeline of receipt of the
Central Assistance. But, ultimately the fund is utilized to create road asset w hich is
ow ned by the State Gov ernment. State Gov ernment accounts are maintained
on cash basis (not accrual basis). Thus, if it is treated as rev enue expenditure at
the time of release, there is no scope on a later date to book it as Capital
expenditure w hen the actual asset is created. Hence, w e do not agree to the
audit observ ations for booking it as rev enue expenditure.
6.
I w ould also like to appraise the position on grants to Energy sector as a
glaring example suggesting treatment of grants as capital expenditure. The
focus point of Audit observ ation is on grants released to distinct legal entities like
OPTCL. I t is claimed in Audit that as the grants w ere utilised by these legal
entities for creation of assets like pow er transmission and distribution infrastructure
w hich w ere then accounted for in the balance sheet of the concerned entities,
such grants should be accounted for as rev enue expenditure as per prov isions of
I GAS 2. I t is once again reiterated that the concerned entities in such cases are
acting as implementing agencies. The assets so created out of these grants are
ow ned by the Gov ernment and does not form part in Balance sheet of entities
as an asset. I t is w orth mentioning that such entities are entitled to take 6%
superv ision charges on implementation of such infrastructure projects for the
Gov ernment.
Clause 14 of I GAS 2 states that “Grants-in-aid are classified and
accounted for as rev enue expenditure in the Financial Statements of the grantor
irrespectiv e of its ultimate application by the grantee. This position holds true
ev en in those cases w here Grants-in-aid are utilized by the grantee for the
purpose of creation of assets. Receipts of grants-in-aid are also required to be
treated as rev enue receipts in the Financial Statements of grantee
Gov ernment.”
32

<!-- page 38 -->

I t may kindly be appreciated that such transfers are actually not an “Aid”
to such institutions nor they are in the nature of subsidy/ incentiv es to promote
industries. Funds hav e been placed at their disposal for creation of Assets for the
Gov ernment and as such they are not entitled to treat the stated grants as their
rev enue income. Fact stands that OPTCL is a 100% Gov ernment ow ned
corporation.
I n a remote imaginary situation, if at all, such assets take a part in the
balance sheet of such entities, the source of funding (the grant by Gov ernment)
cannot be treated as a rev enue income by the entity and therefore, at best,
can be treated as deferred rev enue expenditure in their balance sheet (a
matching liability against the asset) w hich can be amortised ov er the serv ice life
of the asset.
7.
Again in the case of grant 34, Cooperation department, it has been
contended in Audit that payments made to Odisha State Co-operativ e
Marketing Federation Limited w as in the nature of an interest free loan of Rs. 40
crores, This entity does not hav e any material sources of income independent of
the State Gov ernment and hence, repayment of the interest free loan w ould be
dependent on release of further loans/ grants from the State Gov ernment. The
statement is factually w rong in so far as that the Federation hav e their
identifiable source of income and the amount is repaid by them by 28th
February each year. Therefore treatment of the same as rev enue expenditure is
not appropriate.
Similar being the observ ation of Audit in almost all cases, it is submitted
that the expenditure may be treated as Capital expenditure of the Gov ernment
as the assets created are ow ned by the State Gov ernment. We w ould take steps
to correct the procedural lapses pointed out in the audit observ ations. I t is
therefore, requested that the audit observ ations in this regard may kindly be
dropped and w here it is not possible to drop the audit observ ations, v iew s of
Finance Department may be incorporated in the notes to accounts.
With w arm Regards,
Yours sincerely,
Sd/(Ashok Meena)
Sri Bibhudatta Basantia, IA&AS
Principal Accountant General (A&E)
Odisha, Bhubaneswar

33

<!-- page 39 -->

No. 07/F

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
Date: 01/01/2021

FIN-BUD1-MISC-0003-2020

From
Shri Ashok Meena, IAS
Principal Secretary to Government
To
The Additional Chief Secretaries/
Principal Secretaries/
Commissioner-cum-Secretaries/
Secretaries to Government
All Departments
Sub: Relaxation in expenditure rationalization measures adopted in the
wake of economic downturn due to the pandemic Covid19.
Ref:

Finance Department Letter No. 15275/F dated 15/05/2020, 20042/F
dated 07/07/2020 and 31785/F dated 01/12/2020.

Sir/ Madam,
I am directed to invite reference to FD Letter No. 20042/F dt.07.07.2020
read with Letter No.31785/F dt.01.12.2020 and to say that Government had
adopted some expenditure rationalization measures in the wake of
economic downturn due to the pandemic Covid-19. As a result of some
innovative resource mobilization measures, constant monitoring and partial
recovery of the State economy, the resources of the State are now looking
up. Now, in order to augment spending in priority sectors, it has become
necessary to bring in some more relaxation in the expenditure rationalization.
2.
The Cash Management System involving 20 spending Departments was
put on hold for the financial year 2020-21 till further orders vide FD Letter
No.15275/F dated 15/05/2020 in view of the uncertainty associated with the
revenue realization during the year. Public expenditure being the major
source of generation of livelihood and augmenting the buying capacity of
the individuals, there is a need to expedite the pace of programme
expenditure by the 20 spending departments covered under Cash
Management System.
34

<!-- page 40 -->

3.
It has been stipulated in the Para -6 of FD Letter No15275/F dated
15/05/2020 that the 20 major spending departments covered under Cash
Management System can sanction Programme Expenditure up to 30 crore at
a time. Keeping in view the ensuing working season in the state, Government
has been pleased to enhance the sanctioning power of the 20 spending
Departments covered under Cash Management System from Rs.30.00 crore
to Rs.100 crore at a time under programme expenditure for State Sector
Schemes. Regarding expenditure from the allocation made in BE &
Supplementary Budget, 2020-21 under Central Sector Schemes and Centrally
Sponsored Schemes, all the Departments can sanction expenditure upto the
extent central share available along with the admissible state share under
such scheme. The other provisions prescribed in the FD Letter No15275/F
dated 15/05/2020 will remain unaltered.
4.
Further to facilitate higher public spending in priority sectors,
Government has pleased to relax some expenditure rationalization measures
adopted vide Finance Department Letter No 20042/F dated 07/07/2020 read
with 31785/F dated 01/12/2020 as detailed below:
Para
No

Expenditure Rationalization Measures as
per Letter No 20042/F dated 07/07/2020
and further relaxed vide F.D letter No
31785/F dated 01/12/2020

Relaxation as per this Letter

4.g

Expenditure out of the prov ision „Other
Contingencies‟ to be kept at the
minimum lev el. Only expenditure relating
to COVI D management and other
essential expenditure like purchase of
office stationeries etc may be incurred.
There shall be no expenditure on
purchase of office furniture/ fixtures and
furnishing. Expenditure out of the
prov ision „Other Contingencies‟ w ill be
capped at 60% of the Budget Prov ision
for the w hole year. The same w as further
relaxed to 75%. Vide F.D letter No
31785/F dated 01/12/2020.
Operation
and
Maintenance
expenditure can be incurred only after
approv al of Annual Maintenance Plan
(AMP)
by
Finance
Department.
Engineering Departments to prepare
their AMP for the year 2020-21 limiting it
to a lev el of 60 % of the Budget prov ision,

Expenditure out of the prov ision
„Other Contingencies‟ w ill be w ithin
the Budget Provision for the w hole
year

6.c

35

Expenditure out of the prov ision
„Operation and Maintenance‟ w ill
be w ithin the Budget Prov ision for
the w hole year only after approv al
of Annual Maintenance Plan (AMP)
by Finance Department.

<!-- page 41 -->

Para
No

Expenditure Rationalization Measures as
per Letter No 20042/F dated 07/07/2020
and further relaxed vide F.D letter No
31785/F dated 01/12/2020

Relaxation as per this Letter

in consultation w ith Finance Department
initially and on av ailability of resources
balance w ork could start after
Nov ember-2020. The same w as further
relaxed to 75% Vide F.D letter No 31785/F
dated 01/12/2020.

5.
These relaxat ions, as may be relevant, shall also be applicable to all
Aided Institutions/ Co-operatives/ Autonomous Organizations in which the
State Government has explicit or implicit financial stake.
I would, therefore, request you to kindly instruct the COs/ DDOs under
your control accordingly, so as to enable the State Government to meet the
developmental requirement at the time of COVID-19.
Yours faithfully,
Sd/Principal Secretary to Government

36

<!-- page 42 -->

ANNEXURE-I
Sl. No.

Demand No.

Name of the Department

1

07

Works

2

09

Food Supplies and Consumer Welfare

3

10

School& Mass Education

4

11

ST & SC Dev elopment

5

12

Health& Family Welfare

6

13

Housing& Urban Dev elopment

7

17

Panchayati Raj & Drinking Water

8

19

I ndustries

9

20

Water Resources

10

22

Forest& Env ironment

11

23

Agriculture& Farmers' Empow erment

12

28

Rural Dev elopment

13

30

Energy

14

31

Handlooms, Textiles & Handicrafts

15

33

Fisheries& Animal Resources Development

16

36

Women& Child Dev elopment and Mission Shakti

17

38

Higher Education

18

39

Skill Dev elopment & Technical Education

19

40

Micro, Small and Medium Enterprises

20

41

Department of Social Security & Empow erment of
Persons w ith Disabilities

37

<!-- page 43 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No. 5980/F.,
Date: 19.02.2021
FIN-BUD1-MISC-0003-2020

From
Shri Ashok Meena, IAS
Principal Secretary to Government
To
The Additional Chief Secretaries/
Principal Secretaries/
Commissioner-cum-Secretaries/
Secretaries to Government
All Departments
Sub: Withdrawal of expenditure rationalization measures adopted in the wake of
Ref:

economic downturn due to the pandemic Covid-19.
Finance Department Letter No.20042/F dated 07.07.2020, Letter No.31785/F
dated 01.12.2020 and Letter No.07 dated 01.01.2021.

Sir/ Madam,
I am directed to inv ite reference to FD Letter No. 20042/F dt.07.07.2020
read w ith Letter No.31785/F dt.01.12.2020 and Letter No.07 dated 01.01.2021
and to say that Gov ernment had adopted some expenditure rationalization
measures in the w ake of economic dow nturn due to the pandemic Cov id-19.
With constant monitoring of the pandemic situation, full scale resumption of
economic activ ities and v accination driv e across the country, the State
economy is experiencing recov ery resulting in improv ement in resource
realization of the State Gov ernment. The priority has now shifted tow ards higher
inv estment in priority sectors for rev iv al of the economy and employment
generation.
2.
I n order to facilitate higher public spending in priority sectors during the
remaining period of the FY 2020-21 as w ell as in the coming financial year,
Gov ernment has been pleased to w ithdraw the expenditure rationalization
measures imposed v ide Finance Department Letter No 20042/F dated
07.07.2020. This w ithdraw al shall also be applicable to all Aided I nstitutions/ Cooperativ es/ Autonomous Organizations.
I w ould, therefore, request you to kindly instruct the COs/ DDOs under your
control accordingly, so as to enable the State Gov ernment to achiev e the
desired dev elopment needs.
Yours faithfully,
Sd/Principal Secretary to Government
38

<!-- page 44 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
NO. 7936/F

Dt. 10.03.2021

FIN-BUD2-BT-0003-2020

From
Shri Ashok Meena, IAS,
Principal Secretary to Government.
To
The Additional Chief Secretaries/
All Principal Secretaries/Secretaries to Government
All Heads of the Department/All Collectors

Sub: Prompt payment of pending dues of different MSMEs, Industries,
Municipalities and Utilities.
Ref: Finance Department Letter No.15352/F, Dt.16.05.2020.
Sir/ Madam,
In inviting reference to the above letter, I am directed to say that all
Departments of the State Government were requested to ensure timely
release of pending dues, payments, liabilities, EMDs, Security Deposits etc to
mitigate the financial distress faced by the MSMEs, Industries, Municipalities
and Utilities due to COVID-19 pandemic. Accordingly, budget provisions were
made during Annual Budget -2020-21 and Supplementary Budget, 2020-21 for
unhindered flow of liquidity to these sectors.
2.
As a model buyer or receiver of the services rendered by different
entities, it is the duty of all Offices of the State Government to clear their
justified dues routinely in a time bound manner. This will not only improve the
credibility of the Government, also the services would become available at a
competitive price.
3.
Similarly, the dues of the utilities like electricity charges, water tax,
holding taxes are also required to be cleared by due date as delay in
payment will hinder the cash flow of the utilities and it will be difficult for them

39

<!-- page 45 -->

to provide services at desired level. On the other hand, with timely payment
of utilit y dues, the State Government can also avail rebates.
4.
Government has gone for settlement of arrear electricity dues of all
State Government Offices outstanding as on 31st March, 2020 vide Finance
Department Notification No-34020/F Dt.21.12.2020. Hence, the State
Government Offices have to make payment of electricity dues pertaining to
the current financial year 2020-21 onwards. Any payment made by any
Office towards the prior period will be adjusted against the current dues by
the corresponding DISCOM. However, each Government Office needs to
make prompt payment of current electricity dues.
I would, therefore, request you to kindly complete the payment of all
pending claims/ dues, and release of EMDs, Security Deposits or Performance
Securities to the MSMEs, Industries, Municipalities and Utilities by end of the
current financial year. Any dues of above nature pertaining to current
financial year should not be kept pending to be carried forward to the next
financial year. Carry forward of pending ut ility payments to the next financial
year without sufficient justifications would be viewed seriously.
Yours faithfully,
Sd/Principal Secretary to Government

40

<!-- page 46 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No. 9523/F.,
Date: 22.03.2021
FIN-FR-VR-0001-2020

OFFICE MEMORANDUM
Sub: Systematic appraisal and approval of new schemes or new services,
existing schemes under Programme Expenditure and Administrative
Expenditure where the scope or cost estimate is proposed to be
substantially altered and schemes continuing without appraisal.
Reference is invited to Finance Department OM No.1068/F
Dt.10.01.2013 regarding the guidelines for systematic appraisal and approval
of new schemes or new services. Abolition of Plan and Non-Plan distinction
has necessitated reviewing the existing guidelines for appraisal and approval
of new schemes or new services.
2.
After careful consideration, it has been decided to prescribe the
revised guidelines for formulation, appraisal and approval of new schemes or
new services, existing schemes under Programme Expenditure and EOM
Expenditure where the scope or cost estimate is proposed to be substantially
altered and schemes cont inuing without appraisal.
3.
To ensure efficient management of public expenditure, it would be
necessary to adopt the following principles for considering scheme
formulation and implementation.
i.
No new scheme or sub-scheme will be initiated without prior inprinciple approval of Planning & Convergence Department and
Finance Department.
ii.
The Administrative Departments should endeavour to merge,
restructure or drop existing schemes and sub-schemes that have
become redundant or ineffective with the passage of t ime.
iii.
Planning & Convergence Department and Finance Department
reserve the right to merge, restructure or drop any existing schemes
and sub-schemes, in consultation with the Administrative
Department concerned to enhance efficiency and improve
economies of scale in the execution of Government programs.
iv.
Schemes continuing without appraisal, along with status and
reasons for absence of appraisal, would be required to be
appraised for further continuance with due justification.
41

<!-- page 47 -->

v.

vi.

4.

While submitting a new scheme, a careful rationalisation must be
done through merger and dropping of redundant schemes/subschemes.
The duration of a scheme shall not be more than 5 years. Any
scheme which the implementing Department will want to continue
beyond 5 years, the appraisal should be in the 5th Year, much
ahead of pre-budget scrutiny for next financial year.

Concept note for in-principle approval of new scheme:
i.

ii.

5.

The Administrative Department shall prepare a Concept Note in
Annexure-I using BETA application in consultation with the
concerned Financial Adviser and send the same to Planning &
Convergence Department followed by Finance Department with
approval of the Secretary of the Department.
Finance Department, taking the views of the Planning &
Convergence Department into account, if finds the proposed new
scheme acceptable shall convey in-principle approval both in the
file and BETA application. Along-with the in-principle approval,
Finance Department will allot funds for preparation of DP/ DPR out
of the central allocation made in Finance Department budget for
pre-project activities.
Preparation of Detailed Paper (DP) or Detailed Project Report (DPR):

i.

ii.

iii.

iv.

Once in-principle approval is given, the Administrative Department
may go ahead with preparatory activities and prepare a detailed
paper (for new schemes) or detailed project report (for new
projects) as the case may be.
The Detailed Paper (DP) containing the scheme description and
the Detailed Project Report (DPR) containing particulars of the
project must be prepared by the Administrative Department in the
format at Annexure-II adhering to the instructions and guidance
provided in the Concept Note. They can utilize the fund allocated
by Finance Department for preparation of DP/ DPR including cost
of availing services of consultants for the purpose.
Planning & Convergence Department and Finance Department
shall review the proposal as contained in the DP/DPR as per the
concept note and accord their approval to the Administrative
Department if they find the DP/DPR appropriate. Planning &
Convergence Department and Finance Department may suggest
necessary modifications to the DP/DPR if required.
The Administrative Department shall send the modified DP/DPR to
Planning & Convergence Department and Finance Department
42

<!-- page 48 -->

v.

6.

along with Expenditure Finance Committee (EFC)/ Standing
Finance Committee (SFC) memorandum containing key aspects of
the proposal for approval.
Financial Advisor of the Administrative Department shall convene
the meeting of EFC/SFC to discuss the DP/DPR and EFC/SFC
memorandum for review and recommendation. The EFC/SFC may
recommend the proposal without any changes or suggest some
modifications in the design, scope, outlay, etc. In case the EFC/SFC
proposes any change, the Administrative Department shall make
necessary modifications in the DP /DPR, which shall be put up for
approval of competent authority. The approved DP / DPR shall be
uploaded to BETA system for record.
Appraising and Approving Authority and Financial Limits:

The delegation of powers for appraisal of new scheme / service,
schemes continuing without appraisal or where the scope of an existing
scheme is proposed to be substantially altered shall be subject to appraisal
at different levels depending upon the financial limit of the estimated outlay
of the scheme/ service as indicated below:
Financial
Limit
Up to Rs.5.00
crore

Appraisal Forum
Concerned Administrative Department in consultation with the
Financial Advisor (FA) of the Department

Standing Finance Committee (SFC) of the Administrative
Department under the Chairmanship of Secretary concerned with
Above Rs.5.00
Financial Advisor as Member- Convenor, Special Secretary/
crore and up to Additional Secretary/ Joint Secretary in-charge of the scheme
Rs.50.00 crore
concerned in the Department, concerned Heads of Department,
representative of Finance Department, Planning & Convergence
Department and representative of related Department, if required.
Expenditure Finance Committee (EFC) chaired by the
Above Rs.50.00 Secretary, Finance, and consisting of Secretary of the
crore and upto
Administrative Department and FA, concerned Heads of
Rs.100.00 crore Department, representative of Planning & Convergence
Department and representative of related Department, if required.
EFC chaired by the Secretary, Finance and consisting of
Above Rs.100.00
Secretary of the Administrative Department and FA, concerned
crore and upto
Heads of Department, representative of Planning & Convergence
Rs.250.00 crore
Department and representative of related Department, if required.
EFC chaired by the Secretary, Finance and consisting of
Above Rs.250.00
Secretary of the Administrative Department and FA, concerned
crore
Heads of Department, representative of Planning &

43

Approval
Forum
Secretary of the
Administrative
Department

Minister in charge of
Administrative
Department

Minister in charge of
Administrative
Department

Chief Minister

State Cabinet

<!-- page 49 -->

Note :
i.

ii.

The financial limit above are wit h reference t o t he t ot al size of t he
scheme/ project being posed for appraisal and includes budget ary
support , ext ra- budget ary resources, ext ernal aid, debt/equity/loans et c.
for ent ire durat ion of t he scheme.
Delegat ed powers should be exercised only when t he budget ary

iii.

allocat ion or medium-t erm scheme out lay as approved by Finance
Depart ment is available.
While exercising delegat ed powers, concerned depart ment should

iv.

7.

ensure t he proposals are subject t o rigorous examinat ion in project
design and delivery, and careful at t ent ion should be paid t o recurring
liabilit ies and fund availabilit y aft er adjust ment of t he commit t ed
liabilit ies.
Financial Advisor of t he Administ rat ive Depart ment may seek
part icipat ion of t he Finance Depart ment in SFC meet ings, if required.
Appraisal of on-going projects/schemes which have not passed
through appraisal forum:

The State Government introduced the mechanism for systematic
appraisal and approval of new schemes or new services vide Finance
Department OM No.1068/F Dt.10.01.2013. A number of schemes are
continuing prior to introduction of the appraisal mechanism and till now those
have not passed through appraisal forum. These schemes are required to be
appraised / reviewed to assess their need for continuance or change in
scope in the current scenario. Mid-term review of such Scheme/Project is to
be done mandatorily as a pre-condition for their appraisal. Accordingly, all
continuing schemes which have not passed through appraisal forum shall
have to be appraised following the same principle that is adopted for
appraisal of new schemes/ projects.
While preparing the EFC/ SFC memorandum, the Administrative
Departments are required to provide information on past performance (both
physical and financial performance) of the project/ scheme for the entire
period of operation. If the project/ scheme is in operation for a substantially
longer period of time, at least performance (both physical and financial
performance) for last five years may be provided. Evaluation and impact
assessment for all high value projects (project cost exceeding Rs.200 crore) is
to be conducted engaging a third party and the major findings of the
evaluation report is to be brought before the EFC/ SFC for consideration of
continuance of the project/scheme. However, quite a number of projects
44

<!-- page 50 -->

are continuing prior to the appraisal mechanism came into force. Hence, for
continuance of these schemes during FY 2021-22, the Departments are
required enter the past information of the Scheme/ Programme in the format
at Annexure-V using BETA system. However, the process for appraisal and
approval of the continuing scheme has to be completed before closure of
the FY 2021-22 for becoming eligible for budget allocation in the next
financial year.
8.

Appraisal of projects/schemes which are due for completion and their
continuance is necessary :

The on-going projects/ schemes whose period of appraisal/ approval is
due for completion are required to be appraised/ approved again before
the date of expiry for further continuance. Mid-term review of such
Scheme/Project is to be done mandatorily as a pre-condition for their
appraisal. While preparing the EFC/ SFC memorandum, the Administrative
Departments are required to provide information on past performance (both
physical and financial) of the project/ scheme for the entire period of
operation. Evaluation and impact assessment for high value projects (project
cost exceeding Rs.200 crore) is to be conducted engaging a third party and
the major findings of the evaluation report is to be brought before the EFC/
SFC for consideration of continuance of the project/scheme. The process for
appraisal and approval of those projects/ schemes is required to be
completed before closure of the project period for budget allocation in the
successive financial year.
9.

Delegation in respect of Revised Cost Estimate:

The Revised Cost Estimate (RCE) of the projects / schemes which have
earlier gone through appraisal forum have to be appraised and approved in
the following manner:
i.

ii.

Any increase in costs of the Projects/Schemes with original outlay
upto ₹50.00 crore involving increase in costs more than 20% of the
original costs after excluding the increase due to statutory levies,
exchange rate variation, price escalation within the approved time
cycle would require appraisal by the SFC headed by the Secretary
of the Administrative Department concerned with approval of the
concerned Minister-in-charge.
Any increase in costs of the Projects/Schemes with original outl
ay above ₹50.00 crore and upto ₹100.00 crore involving increase
of more than 20% after excluding the increase due to statutory
45

<!-- page 51 -->

iii.

iv.

levies, exchange rate variation, price escalation within the
approved time cycle will require appraisal by EFC headed by the
Secretary, Finance Department and approval of the Minister,
Finance.
Any increase in costs of the Projects/Schemes with original outl
ay above ₹100.00 crore and upto ₹250.00 crore involving increase
of more than 20% arising due to time overrun, change in scope,
under-estimation, etc. (excluding statutory levies, exchange rate
variation, price escalation within the approved time cycle as well
as the cases involving further cost increase) will require appraisal by
EFC headed by the Secretary, Finance Department and approval
of the Chief Minister.
Any increase in costs of the Projects/Schemes with original outlay
above ₹250.00 crore arising due to t ime overrun, change in scope,
under-estimation, etc. (excluding statutory levies, exchange rate
variation, price escalation within the approved time cycle as well
as the cases involving further cost increase) will require appraisal by
EFC and approval of t he State Cabinet.

10.

Medium Term Outlay:
Since individual projects are prepared and appraised at various points
in time during the financial year, there is a need to validate whether the
project cost is within the existing Medium-Term Expenditure Framework
(MTEF). For this the Administrative Department must provide a statement
indicating the MTEF allocations, the sectoral/ program outlays as per the
approved MTEF, expenditures and existing project sanctions / commitments
till date, possible cost escalations and to determine the fiscal space for the
proposed project(s). In case of any emergency, where there would be
necessity to bring out a new scheme of contingent/ unforeseen in nature and
it would not be possible for the Administrative Department to accommodate
the resource requirement within the approved MTEF for the Department, they
may come to Finance Department with adequate justification for arranging
resources for the new scheme.
11.

Procedure for appraisal by SFC /EFC:

Appraisal is a process which helps the Government to select
schemes/projects for funding through the budgetary mechanism. Appraisal is
required to indicate public benefit and outcomes/ outputs of the scheme
along with measurable milestones. The objective of appraisal is two-fold: (a)
to enable selection of only such schemes/projects as are relevant and
justified; and (b) to ensure that the scheme/project has been so designed as
46

<!-- page 52 -->

to meet the objective of equity, economy, efficiency and effectiveness.
Following procedure should be adhered to for appraisal by SFC / EFC.
i.

The entire process of appraisal of new scheme / service, schemes
continuing without appraisal or where the scope of an existing
scheme is proposed to be substantially altered would be processed
electronically. A separate module is developed for appraisal of
schemes in BETA system managed by Finance Department.
The
Administrative
Department
shall
prepare SFC/EFC
Memorandum using BETA system in the prescribed format
appended to this Office Memorandum at Annexure-III. The
memorandum should include the assessment of the project with
regard to their specific contribution in the following aspects :

ii.

a.

b.

c.

d.
e.

f.

Environmental related assessment: Environmental related
assessment should be undertaken, wherever required and
measures identified to mitigate adverse impact, if any. Issues
relating to land acquisition, diversion of forest land, rehabilitation
and resettlement should be addressed. Where it is not feasible to
quantify the environmental impact, a brief write-up may be
given.
Disaster resilience: Whether the project is secured against natural
/ man-made disasters like floods, cyclones, earthquakes,
tsunamis etc. Besides indication may be made as to justify the
contribution of the project towards Disaster resilient measures.
Sustainable Development Goals: Emphasis should be made to
highlight the integration of the 17 broad Sustainable
Development Goals to the new projects. The impact analysis
should be spelt out clearly the particular Sustainable
Development Goals to be addressed with the implementation of
the project.
Gender and child sensitivity: Whether the project is Women or
child centric and how it is addressing the issues.
Regional balance: Emphasis to be given to highlight how the
proposed Scheme intends to reduce regional imbalance.
Involvement of local Governments and communities in scheme
implementation should also be highlighted.
Financial Analysis (Internal Rate of Return): Internal Rate of Return
(IRR) is to be calculated in case of projects which are likely to
have or generate direct revenue streams, (such as toll rates or
any other relevant revenue stream). In calculating IRR the total
project cost is calculated based on capital costs i.e. civil
47

<!-- page 53 -->

construction cost, pre-operative charges, escalation & interest
during construction and compare that with the discounted value
of the future revenue streams to determine whether the project is
financially viable. For calculation of the IRR, the concept note at
Annexure-VI can be referred.
g. Financial Analysis (Economic Rate of Return): Economic Rate of
Return (ERR) is to be calculated in case of projects which are not
likely to generate direct revenue streams. IRR/ERR calculation
should include the cost of land acquisition.
iii.
The Secretary of the Administrative Department shall approve the
Memorandum after which the Administrative Department shall
circulate the same to Finance Department, Planning &
Convergence Department and other Departments electronically
through BETA system whose functional jurisdiction as per the Rules of
Business is likely to be affected.
iv.
In case of new Social Sector Schemes, ST & SC Development
Department, W&CD & Mission Shakti Department, and SSEPD
Department shall be consulted. The consulting Department on
receipt of the Memorandum shall within two weeks‟ time furnish
their views electronically through BETA system to the Administrative
Department. In case no views is received from the consulting
Departments within the two weeks‟ time, the Chairman of the
Committee, after end of the timeline, shall fix up a date for the SFC
/ EFC meeting. Views received after end of the two weeks‟ time
from the consulting Department shall not be taken into
consideration for appraisal.
v.
After receipt of views / comments from the consulting Departments,
the Administrative Department will prepare a statement showing
the observations of the consulting Departments and response of the
Administrative Department to each such observation. After that,
with the request from the Administrative Department, the Chairman
of the Committee shall fix up a dat e for the SFC / EFC meeting. The
statement will be circulated along with the notice for convening
the meeting. At least three clear days will be allowed between the
issue of the notice for meeting and the scheduled date of the
meeting.
12.
Procedure for approval of new scheme/project, schemes continuing
without appraisal or alteration of existing scheme:
i.
After appraisal of the new scheme / project, schemes continuing
without appraisal or alteration of existing scheme and cost estimate
of the scheme/project to be revised, the concerned Administrative
Department will take the approval of the Competent Authority as
48

<!-- page 54 -->

ii.

iii.

iv.

v.

indicated in the Approval Forum in column (1) of para-6 keeping in
view the provisions of Rules of Business and internal delegation
made within the Department.
The Administrative Department will issue minutes of the SFC/ EFC
within seven days after end of the meeting. The approved minutes
shall be uploaded in the BETA system. After issue of the minutes of
the meeting, the Administrative Department will move the proposal
to get the approval of the concerned approving authority as
indicated in the Forum Column (3) of para-6 within two weeks‟ time.
After approval of the scheme/ project by the competent authority,
the Administrative Department shall issue a detailed scheme
guideline clearly mentioning the target beneficiary along-with
benefit, mode of implementation as well as roles and responsibilities
of various implementing authorities. The template for preparation of
scheme guidelines is at Annexure-IV.
Schemes funded under RIDF, EAP, Finance Commission grants, etc.
are not required to be placed for appraisal and or approval of the
SFC/EFC as these are governed by separate appraisal and
approval mechanisms (RIDF projects are appraised / approved by
High Power Committee and EAPs through State Level Project
Management Committee chaired by Chief Secretary).
This instruction shall be deemed to be a part of the Odisha General
Financial Rules and Delegation of Financial Power Rules and the
relevant provisions t hereof would stand modified /revised
accordingly. The financial limits stipulated in para-6 above will
automatically stand revised as and when the Delegation of
Financial Power Rules is amended from time to time.

This supersedes all instructions on systematic appraisal and approval of
new schemes or new services and the schemes where the scope is proposed
to be substantially altered issued vide Finance Department OM No.1068/F
Dt.10.01.2013. This has been concurred in by the Planning & Convergence
Department in their file No. PC-PRGI-SFCEFC-0009-2020 dated 16.07.2020.
By order of the Governor
Sd/Principal Secretary to Government

49

<!-- page 55 -->

Annexure-I
CONCEPT NOTE FOR IN-PRICIPLE APPROVAL OF NEW SCHEME
1.

Scheme Outline
a)
b)
c)
d)
e)
f)

g)

h)

i)

2.

Title of the Scheme.
Name of the Implementing Agency: (Department/ Autonomous
Body/ PSU)
Total Cost of the proposed Scheme/Project
Source(s) of financing the Scheme /Project: (State funding/ EAP/
RIDF/ Others (to be specified))
Proposed duration of the Scheme
Whether any pre-investment activity is contemplated for the
Scheme/ Project? If yes, what is the proposed pre-investment
cost component - wise?
Is there an overlap with an existing scheme/sub-scheme? If so,
how duplication of effort and wastage of resources are being
avoided?
Whether possibilities of convergence with other schemes having
similar objectives to the proposed new scheme have been
explored? (If yes, give a brief outline)
In case of an umbrella scheme (program) give the details of
schemes and sub-schemes under it along with the proposed
outlay component - wise.
Outcomes and Deliverables

a)
3.

Stated aims and objectives of the Scheme
Justification for the new Scheme/Project

Give a summary note on rational and justification for introduction of new
Scheme/ Project.
a)
b)

The justification for taking up/ continuing the project or
scheme may be provided.
The alternatives that have been considered before firming
up the design of the project may be stated. (This should also
include alternate modes of the project delivery, e.g.
outsourcing, PPP etc. that have been considered).

50

<!-- page 56 -->

c)

d)

4.

Please state whether the project proposal has objectives
and which overlap with projects/ schemes being
implemented by the same or another agency (Department/
Government Agency). In cases of overlap, please state why
the project / scheme needs to be considered as a separate
standalone effort.
Whether any scheme under Centrally Sponsored Scheme
(CSS) is existing with similar objectives. If so, the reason for
proposing such new scheme under State Sector Scheme
(SSS) may be justified.

Objective and Target Beneficiaries: If the scheme is specific to any
location, area and segment of population, please give the details and
basis for selection.
a)

4.

Please bring out specific interventions directed in favour of
social groups, namely SC, ST, differently abled, minorities and
other vulnerable groups. (select from drop down)
b)
If the scheme has any gender balance aspects or
components specifically directed at welfare of women,
Children please bring them out clearly? (Specify the
percentage of women centric or Child-centric component
of the scheme.) (select from drop down)
c)
In case of beneficiary-oriented schemes, indicate the
mechanism for identification of target beneficiaries and the
linkage with Aadhaar/ UID numbers. (select from drop down)
d)
Wherever possible, the mode of delivery should involve the
Panchayati Raj Institutions (PRIs) and Urban Local Bodies
(ULBs). Where this is intended, the preparedness and ability
of the local bodies for executing the proposal may also be
indicated.
Environmental related assessment and social impact: Indicate the likely
effect (positive/ negative) of the project/scheme on the environment
and the mitigation strategy. Also identify stakeholder groups that are
likely to experience major welfare losses (or gains) due to the project
and how the project has addressed the same.

5.

Disaster resilience: Whether the project is secured against natural /
man- made disasters like floods, cyclones, earthquakes, tsunamis etc.

6.

Sustainable Development Goals: How the Scheme/Project is integrated
to the Sustainable Development Goals. Indicate the Goals including
t he Target s of t hat Goals that it strives to achieve by 2030.
51

<!-- page 57 -->

Annexure-II
GENERIC STRUCTURE OF A DETAILED PAPER/ DETAILED PROJECT REPORT
i.

ii.

iii.

iv.

v.

vi.

vii.

Context/Background: This section should provide a brief description of
the sector/ sub-sector as well as the national strategy and policy
framework. This section should also provide a general description of
the scheme/ project being posed for appraisal.
Problems to be addressed: This section should elaborate the problem
to be addressed through the project/ scheme at the local/ regional/
state level. Evidence regarding the nature and magnitude of the
problems should be presented, supported by baseline data/ survey/
reports etc.
Aims and Objectives: This section should indicate the development
objectives proposed to be achieved, ranked in order of importance.
The outputs/deliverables expected for each development objective
should be spelt out clearly.
Strategy: This section should present an analysis of alternative strategies
available to achieve the development objectives. Reasons for
selecting the proposed strategy should be brought out. Basis for
prioritization of locations should be indicated (wherever relevant).
Opportunities for leveraging government funds through public-private
partnership or savings through outsourcing must be explored. This
section should also provide a description of the ongoing initiat ives, and
the manner in which duplication can be avoided and synergy created
with the proposed scheme/ project.
Target Beneficiaries: There should be clear identification of target
beneficiaries. Stakeholder analysis should be undertaken, including
consult ation with stakeholders at the time of scheme/ project
formulation. Options regarding cost sharing and beneficiary
participation should be explored and incorporated in the project.
Impact of the project on weaker sections of society, positive or
negative, should be assessed and remedial steps suggested in case of
any adverse impact.
Legal Framework: This section should present the legal framework, if
relevant within which the scheme/project will be implemented, as well
as the strengths and weaknesses of the legal framework in so far as it
impacts on achievement of stated objectives.
Environmental related assessment: Environmental related assessment
should be undertaken, wherever required and measures identified to
mitigate adverse impact, if any. Issues relating to land acquisition,
diversion of forest land, rehabilitation and resettlement should be
52

<!-- page 58 -->

viii.

ix.

x.
xi.

xii.

xiii.

xiv.

xv.

xvi.

addressed. Where it is not feasible to quantify the environmental
impact, a brief write up may be given.
Disaster resilience: Whether the project is secured against natural /
man- made disasters like floods, cyclones, earthquakes, tsunamis etc.
Besides indication may be made as to justify the contribution of the
project towards Disaster resilient measures.
Sustainable Development Goals: Emphasis should be made to highlight
the integration of the 17 broad Sustainable Development Goals and
Targets to the new projects. The impact analysis of the scheme on
concerned SDG indicator should be spelt out clearly.
Gender and child sensitivity: Whether the project is Women or child
centric and how it is addressing the issues.
Regional balance: Emphasis to be given to highlight how the proposed
Scheme intends to reduce regional imbalance and missing links
targeting a particular region. Involvement of local Governments and
communities in scheme implementation should also be highlighted.
Technology: This section should elaborate on the technology choices, if
any; evaluation of the technology options, as well as the basis for
choice of technology for the proposed project.
Management: Responsibilities of different agencies for project
management or scheme implementation should be elaborated. The
organization structure at various levels, human resource requirements,
as well as monitoring arrangements should be clearly spelt out, taking
into account the existing manpower and other resources.
Finance: (a) This section should focus on the cost estimates, budget for
the scheme/project, means of financing and phasing of expenditure.
Options for cost sharing and cost recovery (user charges) should be
explored. Infrastructure projects may be assessed on the basis of the
cost and tenor of the debt. Issues relating to project sustainability,
including stakeholder commitment, operation-maintenance of assets
after project completion and other related issues should also be
addressed in this section.
(b) Financing of projects/ schemes through extra-budgetary resources
like DMF, OMBADC etc. may be explored before posing the
expenditure under State Plan.
Time Frame: This section should indicate the proposed zero date for
commencement and also provide a Project Evaluation and Review
Technique (PERT)/ Critical Path Method (CPM) chart, wherever
relevant.
Cost Benefit Analysis: Financial and economic cost -benefit analysis of
the project should be undertaken wherever such returns are
quantifiable. Such an analysis should generally be possible for
53

<!-- page 59 -->

xvii.

xviii.

xix.

xx.

infrastructure projects, but may not always be feasible for public goods
and social sector projects. Even in the case of latter, the project should
be taken up for working out some measurable outcomes/ deliverables
suitably defined.
Risk Analysis: This section should focus on identification and assessment
of implementation risks and how these are proposed to be mitigated.
Risk analysis could include legal /contractual risks, environmental risks,
revenue risks, project management risks, regulatory risks, etc.
Outcomes: Success criteria to assess whether the development
objectives have been achieved should be spelt out in measurable
terms. Base-line data should be available against which success of the
project will be assessed at the end of the project (impact assessment).
Similarly, it is essential that base- line surveys be undertaken in case of
large, beneficiary-oriented schemes. Success criterion for scheme
deliverables/outcomes should also be specified in measurable terms to
assess achievement against proximate goals along with appropriate
continuous monitoring strategy.
Evaluation: Evaluation arrangements for the scheme/project, whether
concurrent, mid-term or post -project should be clearly spelt out. It may
be noted that continuation of schemes from one period to another will
not be permissible without a third-party evaluation.
Executive Summary: A self-contained Executive Summary should be
placed at the beginning of the document. In cases where only a
Concept Paper or Feasibility Report is attached to the EFC proposal, it
should cover the main points mentioned in the generic structure
above.

54

<!-- page 60 -->

Annexure-III
FORMAT FOR EFC/SFC MEMORANDUM FOR APPRAISAL OF SCHEMES
1.

Scheme Outline :
a) Title of the Scheme.
b) Name of the Implementing Agency: (Department/Autonomous
Body/ PSU)
c) Total Cost of the proposed Scheme/Project
d) Source(s) of financing the Scheme /Project: (State funding/ EAP/
RIDF/ Others (to be specified))
e) Whether any pre-investment activity was undertaken or is
contemplated for the Scheme/ Project? If yes, whether preinvestment cost has been included in the Scheme/ Project proposal?
f) Proposed duration of the Scheme

2.

Project Status :
a) Nature of the Scheme /Project: ( Infrastructure/ Social Sector/
Subsidy/ Other Economic Sector/ Others (to be specified))
b) Whether a New or a Continuing Scheme?
c) In case of a Continuing Scheme,
i. Whether the old scheme was evaluated and what were the main
findings?
ii. Which existing schemes/sub-schemes are being dropped, merged
or rationalized?
iii. Year-wise physical and financial performance (If, the project is
continuing for more than 5 years, performance for last 5 years may
be given)
Year

Financial performance

Physical performance

Target

Target

Achievement

Achievement

iv. In case of New Scheme,
1. Whether in-principle Government approval has been
obtained?
2. Whether a Concept Paper or a Detailed Paper (DP) has been
prepared and stakeholders consulted?

55

<!-- page 61 -->

3. Is there an overlap with an existing scheme/sub-scheme? If
so, how duplication of effort and wastage of resources are
being avoided?
4. Whether possibilities of convergence with other schemes
having similar objectives to the proposed new scheme have
been explored? (If yes, give details)
5. In case of an umbrella scheme (program) give the details of
schemes and sub-schemes under it along with the proposed
outlay component -wise.
Note: It may kindly be not ed t hat t he word scheme here is used in a generic
sense. It includes programs, schemes and sub-schemes, which, depending on
need, can be appraised and approved as st and-alone cost cent ers.
3.

Outcomes and Deliverables :
a) Stated aims and objectives of the Scheme
b) Nature of expenditure for the Scheme: Revenue or Capital or both
(quantify) in Table: 1.
c) Indicate year-wise outputs/deliverables in a tabular form (Table:2).
d) Indicate Outcomes of the Scheme in the form of measurable
indicators which can be used to evaluate the proposal periodically.
Baseline data or survey against which such outcomes should be
benchmarked should also be mentioned.
e) Indicate other schemes/sub-schemes being undertaken by
Departments which have significant outcome overlap with the
proposed scheme. What convergence framework has been evolved
to consolidate outcomes and save public resources?
Table 1: Revenue/ Capital Expenditure
Year/ Cost

Year-1

Year-2 &
so on

Total

Revenue
Capital
Total
Table 2: Year-wise outputs/deliverables
Components

Year-1
Physical
Financial

Year-2 & so on
Physical
Financial

1
56

Total
Physical
Financial

<!-- page 62 -->

Components

Year-1
Physical
Financial

Year-2 & so on
Physical
Financial

Total
Physical
Financial

2
so on
Total

Table 3: Outcomes of the scheme in form of measurable indicators
Components

Indicator

Baseline data

Target
(Year-wise)

Outcome

1
2
so on
4.

Justification for the new Scheme/Project:

Give a summary note on rational and justification for introduction of
new Scheme/ Project.
1. The justification for taking up/ continuing the project or scheme may
be provided.
2. The alternatives that have been considered before firming up the
design of the project may be stated. (This should also include
alternate modes of the project delivery, e.g. outsourcing, PPP etc.
that have been considered).
3. Please state whether the project proposal has objectives and which
overlap with projects/ schemes being implemented by the same or
another agency (Department/ Government Agency). In cases of
overlap, please state why the project / scheme need to be
considered as a separate standalone effort.
5.

Objective and Target Beneficiaries:

If the scheme is specific to any location, area and segment of
population, please give the details and basis for selection.
1. Please bring out specific interventions directed in favour of
social groups, namely SC, ST, differently abled, minorities and
other vulnerable groups. (select from drop down)
2. If the scheme has any gender balance aspects or components
specifically directed at welfare of women, Children please
bring them out clearly? (Specify the percentage of women
57

<!-- page 63 -->

centric or Child-centric component of the scheme.) (select
from drop down)
3. In case of beneficiary-oriented schemes, indicate the
mechanism for identification of target beneficiaries and the
linkage with Aadhaar/ UID numbers. (select from drop down)
4. Wherever possible, the mode of delivery should involve the
Panchayati Raj Institutions (PRIs) and Urban Local Bodies (ULBs).
Where this is intended, the preparedness and ability of the local
bodies for executing the proposal may also be indicated.
6.

Environmental related assessment:

Environmental related assessment should be undertaken, wherever
required and measures identified to mitigate adverse impact, if any. Please
indicate the likely impact (positive/ negative) of the project/scheme on the
environment and the mitigation strategy.

Environmental parameters

Direct Impact
(+) or Risk (-)

(L/M/H)*

Proposed Mitigation
or Enhancement
Measures

Air emissions and air quality
Energy use and conservation
Wastewater and water quality
Water use and conservation
Use of hazardous materials
Waste production/ management/
treatment
Land contamination/ land use, soil
sealing
Biodiversity and natural resources/
possible impacts on protected areas
Noise impacts/ vibrations
Climate Change (mitigation/
adaptation) impacts
Possible direct / indirect,
cumulative/ short-term, long- term
impacts
* L-Low, M- Medium, H-High

7. Social impact assessment:
This involves identifying stakeholder groups that are likely to experience
major welfare losses (or gains) due to the project and how the project has
addressed the same.
58

<!-- page 64 -->

1. Gender, child and nutrition sensitivity: Whether the project is
Women child or nutrition centric. (Select from the drop down)
Indicate (1 or 2 or 3)
1. upto30%
2. More than 30% below 100%
3. 100%

Remarks

Gender Sensitivity
Child Sensitivity
Nutrition Sensitivity

2. Impact on other social sector issues:
Social impact parameters Direct Impact (+)
or Risk (-)
Labour and working
conditions
Occupational health and
safety
Community health, safety &
security
Land acquisition and
involuntary resettlement
Minority groups
Poverty impact
Regional/ local economic
development
Cultural heritage

(L/M/H)*

Proposed Mitigation or
Enhancement Measures

* L-Low, M- Medium, H-High

8.

Disaster resilience:

Whether the project is secured against natural / man- made disasters
like floods, cyclones, earthquakes, tsunamis etc.
Natural Disaster
Cyclones
Earthquakes
Flood
Drought
Any other, please specify

Measurable Unit

59

Sustenance level of the project

<!-- page 65 -->

9.

Sustainable Development Goals:

How the Scheme/Project is integrated to the Sustainable Development
Goals? Indicate the Goals that it strives to achieve by 2030.

Name of
the
Scheme
1

10.

Integration
Covered
with Odisha
SDG
under SDG
SDG Indicator
Target
Goal
Framework
(OSIF)
2
3
4

Baseline
(of Col 4)
5

Achievement to be
made against Baseline
by the end of project
Period
(Year-wise)
6

Regional Balance:

How does the Scheme/Project intend to reduce regional imbalance?
Indicate participation of local bodies and communities in implementation
process.
Name of the
Scheme/
Project

Benefits
proposed to
accrue

1

2

11.

Areas proposed to
be covered
Districts

Blocks

3

4

Involvement of Local
Bodies & Communities
5

Cost Analysis:
a)

b)

Provide the project cost estimates for its scheduled duration along
with a break-up of year-wise, component -wise expenses segregated
into non- recurring and recurring expenses (Table :1).
In case the land is to be acquired, the details of cost of land and cost
of rehabilitation/resettlement, if any. It may also be indicated which
agency is providing for it, and in case the cost of land is to be booked
to the project, whether it has been included in the estimates (Table:2).

60

<!-- page 66 -->

Table-1
Year-1
Components

Recurring

NonRecurring

Year-2 & so on
Total

Recurring

NonRecurring

Total Project cost
Total

Recurring

NonRecurring

Total

1
2
So on

Table-2
Purpose for which Agency providing the
Area required Cost of Acquisition Cost of resettlement
land is required
land

c)
d)
e)

f)
g)

h)

i)

j)

Estimated expenditure on project administration (including expenses
on consultants, etc.) may be separately indicated.
In case pre-investment activities are required, how much is proposed
to be spent on these, with detailed activity wise.
The basis of these cost estimates along with the reference dates for
normative costing may be provided. The firmness of the estimate may
be indicated along with the cost components that can vary the
factors that could cause the v ariation and the extent of the expected
variation.
In case the project/ scheme involves pay-out of subsidy, the year wise
expected outgo, up to the last year of payout, may be indicated.
In case the project / scheme intends to create capital assets, employ
specialized manpower or involves other activities that necessitate a
Recurring Cost of Capital Expenditure (RCCE) (e.g. maintenance and
upkeep costs of assets, salary costs of manpower, etc.) over the
lifetime of the asset, such expenditures, on an annual basis, may be
indicated in the project proposal.
It may also be stated whether the agency which would be assigned
this legacy responsibility has been consulted and has agreed to bear
the continuing recurring expenditure. (e.g. the PRIs / ULBs may need
to incur the maintenance and upkeep costs of assets created under
the Scheme).
The cost towards salary / fees /emoluments of the project human
resources as being proposed should be indicated (procedure for
seeking approval of the human resource requirements is however
detailed at Para-12 below).
The component of the costs that will be shared by the State
Government/ PRIs/ ULBs may be indicated.
61

<!-- page 67 -->

k)

In the event of fund transfer being made to PRIs / Urban Local Bodies
or other organizations, “grants for creation of capital assets” may be
indicated separately.
In case committed liabilities are created, who will or has agreed to
bear the legacy burden? In case assets are created, arrangements
for their maintenance and upkeep?

l)

12.

Project Human Resources:
a) Indicate the Administrative Structure for implementing the Scheme/
Project. Usually creation of new structure, entities, etc. should be
avoided.
b) Manpower recruitment, if any. In case posts (permanent or temporary)
are intended to be created, such proposal may be sent on file to
Finance Department separately. Such proposals may be sent only after
the overall project proposal is recommended by the appropriate
appraisal body (SFC, EFC, etc.). However, posts can be created only
after approval / concurrence of Finance Department is obtained.

Nature of post
(Temporary/
Permanent)

Post Description

No. of Posts

Cost involved

Remark

c) Please indicate whether the nodal officer directly in charge of the
project has been identified. Details about his status, past experience in
executing similar projects and balance tenure left for steering the
project may also be mentioned.
Designation of
Nodal Officer

Post Status

Experience in
executing similar
projects

Balance
tenure of
service

Remark

d) In case outsourcing of services of hiring of consultants is intended, brief
details of the same may be indicated. It may also be certified that the
OGFR provisions will be followed while engaging the agency/
consultant.
e) In case additional manpower requirement, please indicate the phased
requirement over the project timeline (i.e. year-wise break-up of the
manpower requirement).
Year

Category of
manpower required

No. of manpower
required

62

Cost involved

Remark

<!-- page 68 -->

13.

Project Financing :
1. The source of financing for the project may be indicated. Detailed
break- up of budgetary support, internal and extra-budgetary sources,
external aid, etc. should be given.
2. Indicate the cost component, if any that will be shared by the State
Government, Central Government, local bodies, user beneficiaries or
private parties in Table 1 & Table 2 below.
3. The availability of funds in the budget of the present year and the
requirements projected may be mentioned. In case of any deviations,
please indicate how the gap will be addressed.
4. If external sources are intended, the sponsoring agency may indicate
whether such funds have been tied up. In case firm commitment is not
available, alternate programs for arranging funds may be indicated.

Year Component

Funding
type

Source of
funding

Subsidy
payout

Maintenance
Cost

Salary Remarks

Table -1
Sharing of cost component (year/ component/ funding type/ funding source)

Components

Total
Cost

Year-1
Subsidy
pay-out

%

Year-2 & so on
Total
Subsidy
%
Cost
pay-out

Total
Cost

Total
Subsidy
pay-out

%

1
2
so on
Table 2
Year-1
Year-2 & so on
Total
Maintenance
Maintenance
Maintenance
Components
Cost of Capital Salary Total Cost of Capital Salary Total Cost of Capital Salary Total
assets
assets
assets
1
2
so on

14.

Medium Term Outlay:

Since individual projects are prepared and appraised at various points
in time during the financial year, there is a need to validate whether the
project cost is within the existing MTEF. For this the Administrative Department
must indicate:
63

<!-- page 69 -->

a)
b)
c)
d)

The MTEF allocations,
The sectoral/program outlays as per the approved MTEF
Expenditures and existing project sanctions / commitments till date,
Possible cost escalations and to determine the fiscal space for the
proposed project(s).

Name of the
Scheme/ Project

15.

16.

Allocations as per MTEF
Y
Y+1
Y+2

Sectoral/
program
outlays

Expenditure
Commitments till
date

Possible cost
escalations

Project Viability:
a) In case projects which have identified stream of financial returns, the
financial internal rate of return may be calculated. The hurdle rate is
considered at 12%.
b) In case of projects where financial returns are not readily quantifiable
(typically social development projects), the economic rate of return
may be estimated.
Monitoring and Evaluation :
a)
b)
c)

d)
e)

f)

Indicate the Project Management/ Implementing Agency.
Amount charges payable, if any.
Mode of implementation of individual works (Departmental / Third
Party or others).
The monitoring framework for t he project / scheme may be
indicated. The arrangements for audit of the project may also be
stated.
Measurable parameters for evaluation of impact and outcome
with reference to the scheme objective should be indicated.
Period of evaluation such as mid-term / concurrent / post project
etc. and method of evaluation viz. In-house / third party will also
be provided.
Indicate the findings of mid-term review of on-going
projects/schemes which have not passed through appraisal
forum, and projects/schemes which are due for completion and
their continuance is necessary so as to assess the overall progress
till date.

64

<!-- page 70 -->

Name of the
Scheme/
Project

Scheduled date
Date of commencement
of Completion

1

2

17.

Beneficiaries

3

4

Benefits
accrued
5

Expenditure
incurred
6

Project / Scheme sensitivities
a)

b)

18.

Results of mid-term review

Any foreseeable constraints / uncertainties which can affect the
technical design, costing and implementation of the project may
be indicated.
The likely impact of these constraints / uncertainties on the project
parameters may be stated. In particular, the sensitivity of the
project cost, project schedule and project viability towards the
possible constraints / uncertainties may be mentioned.

Revised Cost Estimate (RCE) Proposals
1. Details of physical progress achieved and expenditure incurred
and commitment made so far should be given.
2. Date of latest approved, revised and proposed completion
schedule of the project along with time overrun and reasons
thereof should be elaborated. Revised cost as proposed may be
given.
3. Reasons of increase in cost may be given in the following manner
i. Price Escalation
ii. Foreign Exchange variation
iii. Statutory levies
iv. Change in Scope
v. Addition / deletion
vi. Under-estimation
vii. Others (to be specified)
4.
5.

6.

The underlying justification for increase in cost due to various
factors may be explained.
Effect of revision in capital cost estimates on cost of production
and profitability / viability with reference to earlier approved
capital cost of the project.
Evaluation Reports by in-house / external agencies, Audit Reports
etc. on the outcome of the projects, if any, should be brought out
in the memorandum.
65

Areas
covered
7

<!-- page 71 -->

7.

19.

Report of Departmentally related Standing Committee, if any, to
fix the responsibility for cost and time overrun along with action
taken report on its recommendations may be appended with the
memo to Finance Department.

Approvals and Clearances:

Requirement of mandatory approvals and clearances from various
local, state and national bodies and their availability may be indicated in a
tabular form (land acquisition, environment, forestry, wildlife etc.)
Sl. Approvals/ Clearances
No.

Agency Concerned

Availability (Y/N)

20.

Comments of the Financial Advisor of Administrative Department, P &
C Department, and other Departments may be summarized in tabular
form along with how they are being internalized and used to improve
this proposal.

21.

Approval Sought:
Secretary to the Government
Department of..........................

66

<!-- page 72 -->

Annexure-IV
TEMPLATE FOR PREPARATION OF SCHEME GUIDELINES
1. Background
2. Scheme/ Programme Objectives
3. Coverage under the Scheme/ Programme and duration [(i) In case of
Capital projects, length/ area etc of the work with detailed break-up
as well as intended benefit to the public; (ii) In case of Social sector
projects, the Target Beneficiaries, eligibility criteria, quantum of benefit
to be detailed]
4. Implementation of the Scheme/ Programme (with definite role of the
stakeholders at State/ District/ implementation level)
5. Source of funding for the Scheme/ Project and fund flow mechanism
6. Intended Scheme/ Programme Outcome
7. Monitoring & Evaluation mechanism
8. Forms for application by the beneficiaries (if any) to be annexed

Secretary to the Government
Department of..........................

67

<!-- page 73 -->

Annexure-V
To capture information pertaining to all on-going State Sector Schemes
1.

Scheme Outline
a) Title of the Scheme.
b) Whether the Scheme is appraised or not: Yes / No
c) Name of the Implementing Agency: (Department/Autonomous
Body/ PSU)
d) Total Cost of the Scheme/Project:
e) Source(s) of financing the Scheme /Project: (State funding/ EAP/
RIDF/ Others (to be specified))
f)
Duration of implementation of the Scheme
g) Year-wise physical and financial performance of the Scheme
h) In case of an umbrella scheme (program) give the details of
schemes and sub-schemes under it along with the proposed
outlay component - wise.

2.

Outcomes and Deliverables
a)

3.

Stated aims and objectives of the Scheme

Justification for the Scheme/Project

Year

Expenditure incurred

Physical performance
Target
Achievement
(Units)
(Units)

Remarks

Give a summary note on rationale and justification for introduction of
the Scheme/ Project.
1.
2.

3.

The justification for taking up/ continuing the project or scheme
may be provided.
The alternatives that have been considered before firming up
the design of the project may be stated. (This should also
include alternate modes of the project delivery, e.g.
outsourcing, PPP etc. that have been considered).
Please state whether the project proposal has objectives and
which overlap with projects/ schemes being implemented by
the same or another agency (Department/ Government
Agency). In cases of overlap, please state why the project /
68

<!-- page 74 -->

4.

scheme needs to be considered as a separate standalone
effort.
Objective and Target Beneficiaries: If the scheme is specific to any
location, area and segment of population, please give the details
and basis for selection.
a)

5.

Please bring out specific interventions directed in favour of
social groups, namely SC, ST, differently abled, minorities and
other vulnerable groups. (select from drop down)
b) If the scheme has any gender balance aspects or components
specifically directed at welfare of women, Children please
bring them out clearly? (Specify the percentage of women
centric or Child-centric component of the scheme.) (select
from drop down)
c) In case of beneficiary-oriented schemes, indicate the
mechanism for identification of target beneficiaries and the
linkage with Aadhaar/ UID numbers. (select from drop down)
d) Wherever possible, the mode of delivery should involve the
Panchayati Raj Institutions (PRIs) and Urban Local Bodies (ULBs).
Where this is intended, the preparedness and ability of the
local bodies for executing the proposal may also be indicated.
Sustainable Development Goals: How the Scheme/Project is
integrated to the Sustainable Development Goals. Indicate the
Goals including t he Target s of t hose Goals that it strives to achieve
by 2030.

69

<!-- page 75 -->

Annexure-VI

CONCEPT NOTE ON CALCULATION OF ECONOMIC IRR (EIRR)
FOR EFC PROJECTS
1.

An Overview of Economic Analysis of a Government Project

Economic analysis helps to design and select a project that contributes
to the welfare of the state. The tools of economic analysis can help answer
various questions about a project‟s impact on society, and on various
stakeholders. It also facilitates risk identification and sustainability assessment
of projects. It determines whether the arrangements for cost recovery are
efficient and equitable.
2.

Rationale for Government Involvement and the Concept of Economic
Analysis

The economic appraisal of a Government project is important as it
ascertains the overall impact of the project on State's economy. Economic
analysis of Government provides the linkage of the project with the overall
economy of the state.
3.

Cash Outflow

Expected Cash Outflow refers to all types of expenses incurred for a
project. It is reckoned each year. Revenue Expenses such as Maintenance,
Repairs, Operations etc. and capital expenses such as project cost are to be
quantified over the project life.
4.

Cash Inflow

Expected Cash Inflow refers to the flow of income from a project. It is to
be identified each year. The income from the project in a year is expected
from past expense as well as expenses in current year.
5.

Economic Life of a Project

It is the number of years over which both cash inflow and cash outflows
are expected.
 If number of years for expected cash inflow are higher than the
number of years for expected cash outflow, then economic life will be
equal to number of years for expected cash inflow.
 If number of years for expected cash inflow are less than the number of
years for expected cash outflow, then economic life will be equal to
number of years for expected cash outflow.

70

<!-- page 76 -->



6.

Otherwise, number of years for expected cash inflow will be equal to
number of years for expected cash outflow, which will be the
economic life of the project.
Hurdle Rate (HR)

The cost of fund for the project is taken as “Hurdle Rate”. This is cost of
funds for the state. The cost of funds to the state is the market borrowing cost
of the state. State‟s borrowing cost in open market is linked to REPO Rate. It is
observed that the 10 Year market borrowing of the state is Repo Rate plus 250
basis points. Hence, hurdle rate is pegged as repo rate plus 2.5%.
7.

The Economic Internal Rate of Return (EIRR)

EIRR is the generally accepted quantitative measure of the economic
attractiveness of a project. If the EIRR of a project is greater than the hurdle
rate/cost of borrowing, then project is economically viable. The EIRR indicates
whether the project is efficiently using the state's resources. The EIRR is
calculated from expected cash inflow and cash outflow of the project over
the economic life of the project.
8. Economic Value Addition (EVA)
The EVA is the difference between EIRR and HR. The EVA will be positive
if EIRR exceeds HR. In this case, the EFC project is Economically Viable. In
case of negative EVA, the project is not Economically Viable. However, EVA
neutral project is considered as Economically Viable.
9. Illustrative Example
The Project is about construction of 125 nos. of “Elementary School
Complex” in the state. The Project life is assumed to be 15 Years. The salient
features of this project are illustrated below.
A.

Expenditure Recognition (Cash Outflow)





The Unit cost of Capital Expenses (Unit Capex) for setting up a school
complex is assumed at Rs. 1.5 crore. In every year, the cost escalation
on account of capex is assumed at 5%. This cost escalation includes
inflation on account of capital goods, non-current expenses etc. Since,
the capex is assumed to be for 5 Years, the year wise unit capex is
calculated accordingly.
It is assumed that there will be no capex after 5th Year of the project
life.
The OPEX (Maintenance, Repair and Operational Expenditure),
however, will continue till the end of the project life (15th Year).
71

<!-- page 77 -->






B.

The Unit cost of Operational Expenses (Unit OPEX) for making the school
complex is assumed at Rs. 0.25 crore. Every year, the cost escalation on
account of Opex is assumed at 6%. This cost escalation includes
inflation on account of wages & other recurring spending etc. Since,
the Opex is for 15 Years, the year wise unit Opex is calculated
accordingly.
The total expense for 125 nos. of “Elementary School Complex” is
calculated at Rs. 353 crores over 15 years of project life.
The year wise total expenses (Capex and Opex) are discounted (at
assumed discount rate of 6.5%) to arrive at Present Value (PV) of the
expenses.
Income Recognition (Cash Inflow)














C.

It is assumed that 25 nos. of School Complex will be completed each
year. These 25 nos. of schools in each year are taken as “Output” per
year. Total number of school complexes to be built in 15 years is
assumed at 125.
The economic benefit from this “Output” will be measured in terms of
“Improvement in Gross Enrollment Ratio”.
The economic benefit in a particular year is determined by considering
the existing output as well previous output. For example, in 3 rd Year, the
economic benefit is appraised taking 75 nos. of schools completed
over 3 years. This is taken as “Cumulative Output”.
Therefore, the effect of “Cumulative Output” at the end of the year
would be considered to measure the economic benefit in each year.
The economic benefit from each school will be translated to monetary
value by selecting an appropriate conversion factor.
This conversion factor will recognize the unit value of output for this
project. In our case, the conversion factor is “School Fee” charged
from the new enrolments.
If private schools would have built, owned, and operated these school
complexes at these particular locations, then it is assumed that Rs.0.40
crore would have been collected as fees, in first year, from new
enrollments in each school complex.
Hence, the unit value is recognized at Rs.0.40 crore. This unit value and
progressive output at the end of the year will result in Economic Cash
Inflow every year.
Economic Value Addition



The Economic Value Addition (%) is the difference between EIRR and
HR.
72

<!-- page 78 -->





In our example, EIRR is calculated from a stream of cash inflows and
discounted value of cash outflows over 15 years.
The EIRR is estimated at 11.8% and Hurdle Rate is pegged at 6.5%.
Hence, EVA is 5.3%.
The Economic Analysis of this EFC Project “School Complex in
Elementary Education” confirms that the project is economically
viable, and it has positive economic value addition.

73

<!-- page 79 -->

GOVERNMENT OF ODISHA
FINANCE DEPARTMENT
***
No. 9792/F.,
Dated 24.03.2021
FIN-WM-BT-0001/2018

From
Shri Ashok K. Meena, I.A.S.,
Principal Secretary to Government.
To
The Additional Chief Secretaries/
Principal Secretaries/
Commissioner-cum-Secretaries/
Secretaries to Government
All Heads of Department.
Sub: Relaxation of the deadlines for financial sanction, issue of allotment
and drawal of funds in the remaining part of the current financial year
in respect of Centrally Sponsored Schemes (CSS) and Central Sector
Schemes.
Sir,
I am directed to say that Finance Department have earlier intimated
the Departments and Heads of Department to avoid rush of expenditure
towards the fag end of the financial year and stick to the deadlines fixed for
sanction, issue of allotment, re-appropriation and surrender of funds,
submission of bills in the Treasuries and submission of proposal to Finance
Department for release of funds in letter No.4108/F, dt.04.02.2021, letter
No.6417/F dated 24.02.2021 and letter No.6868/F, dated 26.02.2021.
2.
The Administrative Departments were advised vide Finance
Department letter No.4108/F, dt.04.02.2021 that budgetary Allocation
pertaining to Central Sector Schemes and Centrally Sponsored schemes may
not be surrendered in a routine manner where there is likelihood of receipt of
Central Assistance and scope for expenditure towards the end of the
financial year. In case of late receipt of Central Assistance beyond the
stipulated deadline, the Administrative Departments would move Finance
Department for ext ension of the deadlines to facilitate expenditure. Further,
the Departments are required to submit the claims/bills relating to Central

74

<!-- page 80 -->

Sector Schemes and Centrally Sponsored Schemes (CSS), the Central
Assistance for which is received on or after 20.03.2021 by 26.03.2021.
3.
However, in the past years, Central Assistance in respect of Centrally
Sponsored Schemes (CSS), Central Sector Schemes were received on the last
2-3 days of the financial year. It is understood that some Administrative
Departments are anticipating receipt of Central Assistance in the last few
days of the current financial year.
4.
In view of administrative convenience and the desirability of avoiding
lapse of budget provision, the Administrative Departments are hereby
allowed to issue sanction orders for release of funds, allotment orders and
present bills/claims in the Treasuries by 12 Noon of 31 st March, 2021 relating to
Centrally Sponsored Schemes (CSS) and Central Sector Schemes without
referring the same to finance Department.
However, t he concerned Departments should in their own interest,
ensure encashment of all claims presented in the Treasury/Bank before 31 st
March, 2021 as the centralized and computerized payment Platform of the
R.B.I and Core Banking System of Agency Banks may not process the last
minute transactions.

Yours faithfully,
Sd/Principal Secretary to Government

75
