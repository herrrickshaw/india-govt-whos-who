---
doc_id: "b4f5e601dee6aadb"
source_url: "https://agri.odisha.gov.in/sites/default/files/2025-03/Revised%20Guideline_.pdf"
ministry: "Agriculture and Farmers Empowerment Department, Odisha"
title: "Download(46.57 KB)"
date: ""
pages: 14
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "192105220ef88be4"
---

<!-- page 1 -->

Guideline of the Scheme “Training and Capacity Building” under the
State Plan Scheme, FY- 2022-23 to 2026-27, DoH
1. Background:
In Odisha, present gross cropped area under horticulture sector is 13.61 lakh hectares,
which is about 20% of the net sown area. It can safely be increased to 20 lakh hectares during
coming ten years. Out of a total of 41 lakh hectares covered under paddy during Kharif season,
Upland paddy constitutes about 9.58 lakh hectares. Some of these upland paddy areas and some
medium land under irrigated ayacuts may be suitably diversified for horticulture plantations and
vegetables cultivation.Despite of the scopes and opportunities in Horticulture sector, there is a
large disparity between the per capita income in farm sector and the non-farms. Therefore, it is
essential to deal with those issues which affect the income level of farmers. It is quite distressing
that the farmers feel at the lowest rung in the social hierarchy. It will be an important task to bring
back the glory and self-respect of the farming community. There is no policy tool that can achieve
this directly. A wholesome policy framework for the benefit of the farmers of the state is now
brought out with a focus more on the economic wellbeing of the farmers, rather than just on
production and growth. Advanced Horticultural Technologies developed at the research stations
should be disseminated to the farm, for the overall benefit of the farming community. This noble
activity facilitates in bridging the identified technological gaps existing with the farmers. The major
function of extension is accomplished through dissemination of farm information, training of
farmers and extension functionaries, educating the farmers through field activities such as
demonstration, field visit, field days, farm advisory service, exposure visit and capacity building of
extension personnel etc. The farming community can avail the services of the extension machinery
to get the solutions to their farming problems and to increase their economic status. As a
component of training and capacity building, training through exposure visits and organisation of
workshops have assumed greater significance in recent times. Training of Horticulture extension
professionals and farmers has emerged as an important intervention to improve their
competencies, Capacity building and ultimately increase in horticulture crop production and
productivity. Keeping these in view, it is proposed to organize Capacity Building Training/exposure
visits/ workshops for various extension personnel i. e. like HEWs/HOs/ AHOs/AAE/ AEE/EE ADHs/
DDHs and farmers.

2. Scheme/ Programme Objectives:
a.

To enhance the performance level of various actors involved in Extension setup for better
management of Horticultural Technology System.

b. To improve the techno- managerial skills of the extension professionals.
c.

To improve knowledge, attitude and practice of extension professionals on the
management skills like planning, communication, motivation, leadership, time management
etc.

d.

To enable the extension functionaries for effective and efficient dissemination of
technology to the farming community.

e.

To redefine the role and responsibilities of the Horticulture Extension Machinery by
suitably up-scaling the up-to-date technical knowhow of the field extension set up.

f.

To share their experience with farmers regarding technology adoption for increasing

crop

DHO-SECII-TRNG-0001-2022/01/2025

<!-- page 2 -->

Production and productivity.
g. To enhance the sustainable net income of the farmers by providing trainings and
exposure
Visits on new horticultural technologies directly and through technology
dissemination by
the extension functionaries.

3. Coverage under the scheme/Programme and duration
It is proposed to train up HEWs/HOs/ AHOs/AAEs/ AEEs/ EEs/ ADHs/ DDHs and farmers
on various aspects of Horticulture. The training and exposure visits would be conducted at premier
Training Institutes of Govt. of India and outside India with high credibility so that the extension
functionaries and farmers would undergo training of due worth. The grass root field functionaries
like AHOs/AAEs/HOs/HEWs will be trained at the Four Horticultural Training Institutes of the State
or any other National level Institute/ICAR Institute (if decided)/ any other Institute of repute (If
decided) located inside the State. The Officers along with the progressive farmers will be sent for
exposure visit outside the country. Block/ State level workshop will be organized to create
awareness on different schemes and activities of the Department. The programme duration will be
for 5 (five) years from 2022-23 to 2026-27.

4. Implementation of Scheme / Programme
A. Operational Guidelines of “Training & Capacity Building- through Exposure
Visit to the training institutes located outside the state
a. For Group DDHs/ADHs/EEs/AEEs/AHOs
1. The Directorate of Horticulture, Govt. of Odisha, is interested in capacity building of their
officers by implementation of the state sector scheme “Training and Capacity Buildingthrough Exposure Visit of Horticulture Extension Personnel (DDHs/ ADHs/EEs/ AEEs/AAEs/
AHO/) to the training institutes located outside the State. For this purpose, some apex
national institutes will be identified where Directorate of Horticulture, Govt. of Odisha would
like to send their officers for advanced training in better management, principles and
practices in the field of Horticulture as agreed upon by them.
2. The Directorate of Horticulture, Govt. of Odisha will request the training institutes to
specifically organize training programmes of 5 days and exposure visit of 3 days for a batch
of 30 participants each to cover the key areas.
3. The schedule for the programmes as well as the mode of expenditure for each course of 8
days duration for 30 nos. of participants should be mutually agreed upon and be decided by
the faculty of training institutes & Director of Horticulture, Odisha, Department of Agriculture
and Farmers’ Empowerment, Govt. Of Odisha, Bhubaneswar.
4. The fund for Training & capacity building through exposure visit will be placed to the
selected Training Institute from Directorate of Horticulture, Odisha according to the approved
cost structure.
5. Each Training-cum-Exposure Visit will be of 8 days duration (5+3) excluding journey days.

6. In each Training Programme, 30 nos. of officers will be nominated and trained which will be
comprised of DDHs/ ADHs/EEs/ AEEs/AAEs/ AHO covering 30 districts.
7. The entire training schedule & allotted slots as agreed upon will be communicated to all
concerned officers by the DoH.
8. Under the scheme “Training & Capacity Building- through Exposure Visit of Horticulture
Extension Personnel (DDHs/ ADHs/EEs/ AEEs/AAEs/ AHO) one of the officers as approved
by DoH will lead the team and others will assist him.

DHO-SECII-TRNG-0001-2022/01/2025

<!-- page 3 -->

9. The team leader of the batch of officers will lead the team to the selected training institute
and the exposure visit.
10. He should ensure 100% attendance in his batch & any substitution on medical ground only
may be done sufficiently ahead of the journey with prior approval of DoH.
11. The TA to the participants will be reimbursed as per latest OTA Rules by their respective
District Heads (DDH/ADH) on production of original tickets/ proof towards the mileage.
12. After completion of the training programme the Training Institute will furnish the paid
vouchers and list of officers attended in duplicate to the Directorate within fifteen days of
date of completion of training for necessary adjustment of the advance amount received by
the institute and refund back surplus amount if any to DoH, Bhubaneswar.
13. The team leader will submit a brief technical report with some good photographs on the
training course and Exposure Visit for appraisal of the higher authority (both soft & hard
Copies) within Seven days of completion of training-which is mandatory.
14. He shall take necessary steps to maintain proper discipline and cordial atmosphere among
the participating officers during the journey as well as training and exposure visit period.
15. He shall contact and coordinate the participating officers as and when needed up to
completion of the training programme for smooth execution of the scheme.
16. The administrative expenses (@2% of Project Cost) tentatively estimated in the project may
be utilized towards computer peripherals, Installation of a Software for preparation of a
database on the project implementation. This should be utilized after due approval of DoH.
Cost Structure for 30 Participants

Sl
No

Particulars

Amount
(Rs)

1

Bus/Train fare for 30 nos of Persons from
Headquarters
to
Bhubaneswar-Training
Institute outside State & back to Head
Quarters

3,00,000

2

DA as per the OTA Rules for 30 nos of
participants

1,50,000

3

Conveyance and accommodation at Visiting
State for 3 Days (Exposure Visit)

1,87,500

4

Miscellaneous
expenditure
including
honorarium to resource persons, pen, bag,
documentation, banner, Photographs, ID
Cards, Medicines etc

37,500

5

Institutional Charges

6,37,500

TOTAL

DHO-SECII-TRNG-0001-2022/01/2025

13,12,500

<!-- page 4 -->

b. For Group HOs/HEWs
1. The Department of Agriculture and Farmers’ Empowerment, Govt. of Odisha, is interested in
capacity building of their grass root level officers by implementation of the state sector
scheme “Training and Capacity Building- through Exposure Visit of Horticulture Extension
Personnel (HO/HEW) to the training institutes located outside the State. For this purpose,
some apex national institutes will be identified where Directorate of Horticulture, Govt. of
Odisha would like to send their grass root level officers for advanced training in better
management, principles and practices in the field of Horticulture as agreed upon by them.
2. The DoH, Govt. of Odisha will request the training institutes to specifically organize training
programmes of 5 days and exposure visit of 3 days duration for a batch of 30 participants
each to cover the key areas.
3. The schedule for the programmes as well as the mode of expenditure for each course of 8
days duration for 30 nos. of participants should be mutually agreed upon and be decided by
the faculty of training institutes & Director of Horticulture, Odisha, Department of Agriculture,
Govt. Of Odisha, Bhubaneswar.
4. The fund for Training-cum-exposure visit will be placed to the selected Training Institute from
DoH, Odisha according to the approved cost structure.
5. Each Training-cum-Exposure Visit will be of 8 days duration (5+3) excluding journey days.

6. In each Training Programme, 30 nos. of HO/HEW will be nominated and trained covering 30
districts.

7. The entire training schedule & allotted slots as agreed upon will be communicated to all
concerned officers by the DoH .
8. Under the scheme “Training & Capacity Building- through Exposure Visit of Horticulture
Extension Personnel (HOs/HEWs) one of the grass root level officers as approved by DoH
will lead the team and others will assist him.
9. The team leader of the batch of grass root level officers will lead the team to the selected
training institute and the exposure visit.
10. He should ensure 100% attendance in his batch & any substitution on medical ground only
may be done sufficiently ahead of the journey with prior approval of DoH.
11. The TA to the participants will be reimbursed as per latest OTA Rules by their respective
District Heads (DDH/ADH) on production of original tickets/ proof towards the mileage.
12. After completion of the training programme the Training Institute will furnish the paid
vouchers and list of Extension Personnels attended in duplicate to the Directorate within
fifteen days of date of completion of training for necessary adjustment of the advance
amount received by the Institute and refund back surplus amount if any to DoH,
Bhubaneswar.
13. The team leader will submit a brief technical report on the training course and Exposure Visit
for appraisal of the higher authority (both soft & hard Copies) within seven days of
completion of training-which is mandatory.
14. He will take necessary steps to maintain proper discipline and cordial atmosphere among
the participating officers during the journey as well as training and exposure visit period.
15. He will contact and coordinate the participating officers as and when needed up to
completion of the training programme for smooth execution of the scheme.
16. The administrative expenses (@2% of Project Cost) tentatively estimated in the project may
be utilized towards computer peripherals, Installation of a Software for preparation of a
database on the project implementation. This should be utilized after due approval by DoH.
Cost Structure for 30 Participants

DHO-SECII-TRNG-0001-2022/01/2025

<!-- page 5 -->

Sl
No

Particulars

Amount
(Rs)

1

Bus/Train fare for 30 nos of Persons from
Headquarter
to
Bhubaneswar-Training
Institute outside State & back to Head
Quarters

2,25,000

2

DA as per the OTA Rules for 30 nos of
participants

1,50,000

3

Conveyance and accommodation at Visiting
State for 3 Days (Exposure Visit)

1,87,500

4

Miscellaneous
expenditure
including
honorarium to resource persons, pen, bag,
documentation, banner, Photographs, ID
Cards, Medicines etc

37,500

5

Institutional Charges

3,37,500

TOTAL

9,37,500

c. For Farmers
1. The Department of Agriculture and Farmers’ Empowerment, Govt. of Odisha, is interested in
capacity building of farmers by implementation of the state sector scheme “Training and
Capacity Building- through Exposure Visit of farmers to the training institutes located outside
the State. For this purpose, some apex national institutes will be identified where Directorate
of Horticulture, Govt. of Odisha would like to send the farmers for advanced training in better
management, principles and practices in the field of Horticulture as agreed upon by them.
2. The Directorate of Horticulture, Govt. of Odisha will request the training institutes to
specifically organize training programmes of 5 days duration for a batch of 30 participants
each to cover the key areas.
3. The schedule for the programmes as well as the mode of expenditure for each course of 5
days duration for 30 nos. of participants should be mutually agreed upon and be decided by
the faculty of training institutes & Director of Horticulture, Odisha, Department of Agriculture,
Govt. Of Odisha, Bhubaneswar.
4. Provision will be made for carrying out training and exposure visit of 300 nos. i.e. 30
nos./group of farmers outside the state for 5 days in each year covering 30 districts. The
target to each district will be communicated by the Directorate of Horticulture.
5. For selection of farmers under Training & Capacity Building through Exposure Visit to the
training institutes located outside the state, the guideline of National Horticulture Mission
(NHM) will be followed.
Criteria for selection of farmers

DHO-SECII-TRNG-0001-2022/01/2025

<!-- page 6 -->

i) The farmers selected for exposure visits outside the State should be a progressive farmer
ii) Age of the selected farmer should be preferably between 18-55 years.
iii)Farmers may be
programme/scheme.

selected

basing

on

their

involvement

in

Horticulture

vi) The selected farmers should have at least 3 years plantation/cultivation experience.
v) New farmer may be selected each year. Any repetition of the individual farmer is not
permissible.
vi) Prior to selection the past output delivery track record of the farmers should be
thoroughly checked by the field staff in order to prevent the unscrupulous drain out of the
scarce public resources.
vii) The list of farmers should be approved by the District Mission Committee.
ix) The AHOs are required to give certificate judiciously after proper verification of the
candidate and this certificate should contain the remarks of the AHO and sent to the
concerned DDH/ADH for approval.
Cost structure for 30 nos. of farmer for 5 days

1

Transportation (To & Fro), Transportation
from AHO/Hort point to journey start point

Rs.60000.00

2

Daily Allowance to each farmer @ Rs.200/per day for 5 days

Rs.
30000.00

3

Transportation in field visit & accommodation
in the visiting state to each farmer @ Rs.300/per day

Rs.45000.00

4

Local
Conveyance,
Training
Kits,
Arrangements and Misc. including unforeseen
expenses

Rs.
15000.00

TOTAL

Rs.
150000.00

6. The funds for the purpose will be placed to the selected Training Institute from

Directorate
of Horticulture, Odisha according to the NHM cost structure.
7. The list of progressive farmers selected by the DDH/ADH will be communicated to the DoH.

8. The TA to the farmers will be reimbursed by their respective District Heads (DDH/ADH) on
production of original tickets/ proof towards the mileage.
9. After completion of the training programme the Training Institute will furnish the paid
vouchers and list of officers attended in duplicate to the Directorate within fiftee days of date

DHO-SECII-TRNG-0001-2022/01/2025

<!-- page 7 -->

of completion of training for necessary adjustment of the advance amount received by him
and refund back surplus amount if any to Directorate of Horticulture, Odisha Bhubaneswar.

B. Operational Guidelines of “Orientation/ Induction/ Refresher Training &
Capacity Building to be conducted at Training Institutes present in the State.
a. Training & Capacity Building at Horticulture Training Institutes
1. For Horticulture Extension Personnel/ Officer (HEW/HO/ AHO/ AAE)
There are 4 training institutes existing under the Directorate of Horticulture namely
1.

School of Horticulture, Khordha.

2.

Horticulture Training Institute, Kalinga, Kandhamal

3.

Horticulture Training Institute, Nildunguri, Sambalpur.

4.

Centre of Excellence, Deras, Khordha

The infrastructures and the technical staffs of the institutes will be utilized for the said
purpose. However, at the time of need experts in relevant fields will be called for conducting
trainings. Functionaries of SPMUs engaged under different schemes will be called for imparting
trainings on different aspects of programme management.
District wise Training Institutes
SoH,
Khordha

HTI,
Kalinga

HTI,
Nildungri

CoE, Deras

Cuttack

Kandhamal

Sambalpur

Angul

Dhenkanal

Koraput

Bolangir

Balasore

Gajapati

Malkangiri

Bargarh

Bhadrak

Ganjam

Nawrangpur

Boudh

Jagatsinghpur

Khurda

Raygada

Deogarh

Jajpur

Nayagarh

Jharsuguda

Kendrapada

Puri

Kalahandi

Keonjhar

Nuapada

Mayurbhanj

DHO-SECII-TRNG-0001-2022/01/2025

<!-- page 8 -->

Subarnapur

Sundergarh

1. The training duration may vary basing on the nature of training programme i.e Orientation/
Induction/ Refresher Training programme.
2. In each Training Programme meant for Group-‘HO/HEW’ 40 nos. of participants in the
category of HO/HEWs (Both regular & Contractual) will be trained.
3. In each Training Programme meant for Group-AHO/AAE 40 nos. of participants in the
category of AHOs /AAEs will be trained.
4. The entire training schedule & allotted Range wise slots should be prepared by the training
institute & be communicated to the concerned DDHs for facilitation of nomination in time.
5. The concerned DDHs are to send the nominated participants to the training institute as per
their schedule received under intimation to the Directorate.
6. Overlapping of the participants in the training programmes against the same course for the
second time should be avoided strictly while nominating.
7. Priority should be given to the field extension personnel who have not undergone any
refresher’s training previously.
8. Top most emphasis should be given to nominate the recently engaged contractual HEWs to
enable them to be tuned with latest technology as well as different flagship Programmes
launched by the Department.
9. The detailed course module along with the resource persons and time schedule are to be
prepared by the Training Institutes in consultation with OUAT/ Directorate/IMAGE and to be
intimated to this Directorate for approval of Directorate of Horticulture.
10. The Course curricular & mode of imparting training should preferably be in Odia so as to
enable the trainees to completely grasp the subject matter and make the farmer aware of the
technologies in their respective areas.
11. Pre evaluation and post evaluation test of the trainees should be conducted on the very first
day and last day of the training respectively by the training institute and an abstract on
evaluation should be sent to the Directorate for preparation of project completion report.
12. The hard copies of the courses should be prepared by the host training institute and
distributed to the trainees in the form of a book-let during the training programme.
13. The technical field visit is mandatory for all trainees so as to enable them to see
advancements in hi-tech Horticulture after which an assignment should be submitted by the
trainees on splitting them into Ten separate groups. The said assignment is to be collected &
evaluated on the eve of closing hour.
14. The Officers from the Directorate should be provided with time slot for appraising the
trainees on Govt. initiatives & latest Horticulture schemes in operation as resource
personnel.
15. Funds will be placed to the concerned Training Institutes for the purpose by the Directorate
of Horticulture.
16. Batch wise/ Course wise Progress Report and utilization certificate of funds sanctioned
should be submitted to the Directorate soon after completion of each training programme.
17. At the end of training Programme of each batch a copy of the reading material, documented
soft copy & Photographs should be sent to the Directorate by the training Institute
immediately to facilitate preparation of project completion report.
18. Proper steps should be taken by the host training institutes and DDH/ ADH of concerned
districts to ensure 100% attendance in each batch of training. Report on attendance of each
batch of training should positively be communicated to the Directorate on the very first day of
training (i.e. by 3.00 P.M.) through e-mail-supportdho.od@nic.in

DHO-SECII-TRNG-0001-2022/01/2025

<!-- page 9 -->

Cost Structure (for 5 Days)

Sl
No

Item

1

Training Materials

Rate
(Rs)

Nos

Amount
(Rs)

a.

Training Bag

350

40

14000

b.

Writing Pad

50

40

2000

c.

Writing Pen

50

40

2000

d. ID Card

20

40

800

e.

Pencil,eraser
&sharpner

20

40

800

2

Reading Material
(Hard copy/soft
Copy)

130

40

5200

3

Certificate, Group
Photo & Photo
folder

180

40

7200

4

Honorarium to
Resource
Persons(Towards
delivering lecture,
interaction and
Group acticities)

1000

10

10000

5

Honorarium to
Resource Persons
during field visits

500

1

500

6

Lodging @Rs 50/& Boarding @ Rs
350/-per Day -5
Days(Total Rs
400/-)

2000

40

80000

DHO-SECII-TRNG-0001-2022/01/2025

<!-- page 10 -->

7

Travelling
Expenses to the
Participant(To &
Fro journey
reimbursement as
admissible)

800

40

32000

8

Payment to the
Course Coordinator

1500

LS

1500

9

Hiring of IT/Audio
Visual operator
(including 1 day
preparatory) 6
days @ Rs 250/
per Day

1500

LS

1500

10

Hiring of AC
Vehicle/POL for
Field Visit etc

8500

LS

8500

11

Misc
Contingencies LS

5000

LS

5000

1000

LS

1000

a. Maintenance of AV
aids

b.

Maintenance of
Hostel and Training
Hall

c.

Maintenance of
Elect. & PHD

d.

Charges of
Telephone/internet
and electric bills

e. Other need based
consumable items

12

Other Expenses

Grand Total

DHO-SECII-TRNG-0001-2022/01/2025

172000

<!-- page 11 -->

NB: Intercomponental changes towards cost of components may be adjusted as per
requirement of the training within the cost of package approved for a single training.

b. Training & Capacity Building at ICAR Institutes/National level Institute/any
other Institute of repute (if decided) located inside the State
1. For Horticulture Extension Personnel/ Officers (HEW/HO/ AHO/ AAE)
2. For Farmers of the State
1. In special case, any ICAR Institute/National level Institute (If interested)/ any other Institute
of repute (If decided) may be taken into consideration where Directorate of Horticulture, DA
& FE, Govt. of Odisha would send their Extension Personnel/ Officers for advanced training
in better management, principles and practices in the field of Horticulture as agreed upon by
them.
2. The duration, module, batch size and cost structure of training programmes for each group
should be mutually agreed upon and be decided by the faculty of training institutes &
Director of Horticulture, Odisha, Department of Agriculture and Farmers’ Empowerment,
Govt. Of Odisha, Bhubaneswar.
3. The fund for Training & capacity building will be placed to the selected Training Institute from
Directorate of Horticulture, Odisha according to the approved cost structure out of the funds.
4. The entire training schedule & allotted slots as agreed upon will be communicated to all
concerned officers by the DoH.
5. The TA/DA to the officers/ Extension Personnel will be reimbursed as per latest OTA Rules
by their respective District Heads (DDH/ADH) on production of original tickets/ proof towards
the mileage/TA Bill.
6. The TA/DA to the farmers will be reimbursed by their respective District Heads (DDH/ADH)
on production of original tickets/ proof towards the mileage.
7. After completion of the training programme the Training Institute will furnish the paid
vouchers and list of officers/ Extension Personnel/ Farmers attended in duplicate to the
Directorate within fifteen days of date of completion of training for necessary adjustment of
the advance amount received by the institute and refund back surplus amount if any to DoH,
Bhubaneswar.

C. Operational Guidelines of “Training & Capacity Building through Exposure
Visit of Officers (DDH/ADH/EE/AEE/AAE/AHO) along with progressive Farmers
outside the country”
1. Each year Two frontline Officials along with Two nos. of progressive farmer (age 18-55
years) involved in a particular schematic intervention will be sent for exposure visit outside the
Country.
2. The DDH/ADH (Independent) will submit the name of the Officer and progressive farmer
along with detailed bio-data and documentation of the involved project with approval the
Chairman, DMC-cum-Collector-cum-DM of concerned districts to DoH atleast two months
before scheduled programme intimated to them for obtaining necessary approval and
clearance at Govt. level.
3. Any Officer may be allowed to visit outside the country only once in his service carrier.
Likewise any progressive farmer should be allowed to avail the opportunity only once.
4. Officers having less than one year service to his retirement should not be allowed for the

DHO-SECII-TRNG-0001-2022/01/2025

<!-- page 12 -->

above said purpose.
4. As the funds required depends on the country to be visited, lump sum amount of Rs.2.50
Lakh per person for 07 (5+2 )days programme will be taken for budget calculation.
5. The funds for the purpose will be placed to the Officers of DoH from Directorate of
Horticulture, Odisha according to the approved cost structure.
6. After completion of the training programme the Officer will furnish the UC and list of officers
and farmers attended in duplicate to the Directorate within fifteen days of date of completion
of training for necessary adjustment of the advance amount received by them and refund
back surplus amount if any to DoH, Bhubaneswar.

D. Operational Guidelines of “Training & Capacity Building of farmers through
organisation of Block/ District/ State level Workshop
1. Horticulture is one of the driving factors for crop diversification programme. So, in
order to accommodate more numbers of farmers in the programme provision will be
made to organize Block/ State level Workshops.
2. Each year 942 nos. of block level, and 01 no. of State level need based workshop will be
organized.
3. The funds provision for organisation of block and state level workshop will be Rs.0.50 Lakh,
Rs. 2.00 Lakh respectively.
4. The funds for the purpose will be placed to the DDH/ADH for organization of Block/ State
level workshops from Directorate of Horticulture, Odisha according to the approved cost
structure.
5. There should be wide publicity on organisation of workshop so as to have a great gathering
of target groups (farmers). All Officials under Directorate of Horticulture will facilitate.
6. Priority should be given for inviting Delegates from all India level to replicate the best
practices of Horticulture in our State.
7. The DDH/ADH will disburse the DA/TA to the participants on production of original tickets/
proof towards the mileage.

8. After completion of the workshop the DDH/ADH will furnish the paid vouchers and list of
farmers attended in duplicate to the Directorate within fifteen days of date of completion of
training for necessary adjustment of the advance amount received by him and refund back
surplus amount if any to DoH, Bhubaneswar.
Indicative Estimate for One day block level workshop
Sl. No.

Item of Work

1.

Training
arrangement
(Training Hall hire charges/
Audio Visual Aid/ Office
Stationary)

2.

Refreshment of Trainees
(Tea/ Snacks/ Working lunch)

DHO-SECII-TRNG-0001-2022/01/2025

Unit

Unit
Rs.)

LS

100

200

Cost

(In

Total (In Rs.)

6,500

20,000

<!-- page 13 -->

3.

Training Material (Book or
Printing material/ Pen/ Pad/
Folder)

100

150

15,000

4.

Honorarium
Person

5

500

2,500

5.

Travelling
trainees

100

50

5,000

6.

Misc. contingency

LS

1,000

to

Resource

allowances

to

Total

50,000

(Rupees Fifty
Thousand only)
NB: Intercomponental changes towards cost of components may be adjusted as per
requirement of the workshop within the cost of package approved for a single workshop.

5. Source of Funding for the Scheme/Project and Fund Flow
Mechanisma. The source of fund will be from State Plan Budget.
b. The funds for Training & Capacity building through exposure visit of Extension personnel
group DDHs/ADHs/AHOs (Outside the state), Exposure Visit of extension personnel Group
HOs/HEWs (outside the state), Exposure visit of farmers outside the State will be placed to
the Training Institute from Directorate of Horticulture, Odisha for conducting Training &
Exposure Visits. Funds for TA of Extension Personnel/ Officer will be placed to the District
Heads (DDH/ ADH).
c. The funds for exposure visit of Officer along with progressive farmer outside the country, will
be placed to the Officers of DoH from Directorate of Horticulture, Odisha.
d. The funds for Orientation/ Induction/ Refresher Training of HEWs/HOs/ AHOs/ AAEs for 5
days (At 04 Training Institutes of the State), will be placed to the Institutes from Directorate
of Horticulture, Odisha. In special case, funds may be placed to ICAR Institutes/National
level Institutes (If interested)/ any other Institute of repute (If decided) located inside the
State for conducting training and exposure visit of Extension personnel/ Officers/Farmers.
e. The funds for organisation of block/ state level need based workshop will be placed to the
DDH/ADH from Directorate of Horticulture, Odisha according to the approved cost structure.

Financial Abstract
Sl
No

Financial Year

Tentative Requirement of funds under
the Scheme (in Rs)

1

2022-23

10000000

DHO-SECII-TRNG-0001-2022/01/2025

<!-- page 14 -->

2

2023-24

147750000

3

2024-25

100000000

4

2025-26

100000000

5

2026-27

100000000

TOTAL

457750000

(Forty-Five Crore Seventy-Seven Lakhs Fifty Thousand only)

6. Intended Scheme/Outcome:
The trained extension personnel from outside the state training Institute will render
technical training to the grass root extension functionaries on different latest technical aspects
relating to Horticulture. The grass root field functionaries so trained will create a substantial base at
the farming community for yield optimization and enhancement of net farm income. The trained
farmers will create a pool of knowledge at the farm level for the overall development of the farming
community.

9. Database Creation, Monitoring, Evaluation & Assessment mechanism
a. The list of total no. of trainees who have successfully completed training in each category
will be the Training Institutes in both soft and hard copies for creation of database at State
level.

b. Monitoring will be done by Directorate of Horticulture, Odisha.
c. Audit of the Scheme will be done according to the norms of Finance Department.
d. Concurrent evaluation at the end of the 1 st year and 3rd year of implementation will
be carried out for early identification of bottlenecks, if any. At the end of the project
cycle i.e. five year period final evaluation will be carried out.

DHO-SECII-TRNG-0001-2022/01/2025
