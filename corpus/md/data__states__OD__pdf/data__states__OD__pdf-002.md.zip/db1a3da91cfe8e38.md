---
doc_id: "db1a3da91cfe8e38"
source_url: "https://www.optcl.co.in/Writereaddata/NewsArea/One_time_Scholarship_Circular-2025-26.pdf"
ministry: "Odisha Power Transmission Corporation Limited (OPTCL), Bhubaneswar, Odisha"
title: "Scholarship Circular for the Academic Year 2025-26."
date: ""
pages: 7
method: "tesseract:ori+eng"
script: "LATIN"
needs_ocr: false
sha1: "f943835ab5158d13"
---

<!-- page 1 -->

> 5 <a EEE Ee Oe: ` ଗା
@PTC.-13018/12/2025-FUND-TERMINAL BENEFITS 172677572026
| RS ssa Sque a& eoing Gaa ଲିଃ,
| ap : ODISHA POWER TRANSMISSION CORPORATION LIMITED
¬ a (A Government of Odisha Undertaking)
| Regd.Office: OPTCL Tech-Tower, Janpath, Saheed Nagar, Bhubaneswar-751007
। (‰|‰¢୮୦୩୨୧୬ Telephone: (0674) 2542269, 2542743 (EPABX), Website: www.optcl.co.in
| CIN:U41020R2004SGC007553 ;

File No. FW-Fund-215/2011 3d Date : i 3 ନ୍‌

is / 577 a6. 10.2026

All the Unit Heads,

OPTCL/GRIDCO/SLDC.

Sub:- Regarding One Time Scholarship for the Academic year 2025-26.

Sir,

Applications in the prescribed form (enclosed at Annexure-“A”) are invited from the

Provident Fund subscribers of the OSEB EPF Trustee Board for payment of one time scholarship to

the wards of the subscribers in recognition of their meritorious performance in the examinations for

the Academic Year 2025-26.

The eligibility criteria and the scholarship amount are mentioned in detail in the statement at

Annexure-"B",

HOW TO APPLY:

1) The application form (Prescribed format enclosed at Annexure-A) duly filled in, signed by
the subscriber and countersigned by the concerned Unit head may be forwarded by the
respective DDO (i.e. Zone/ Circle/ Hars/ SLDC DDO) in original to the Secretary, OSEB EPF
TRUSTEE BOARD, on or before the prescribed date.

th The application should be supported by (a) copy of mark sheet of Examination passed (b)
Rank card (c) identity card of the College/University as evidence in support of taking
admission in professional/technical course (d) Certificate from Govt. of Odisha, Dept. of
Sports & Youth Services (e.) Cancelled Cheque / Bank passbook showing account number
& IFSC, duly attested by the concerned Unit Head/ Concerned DDO (i.e. Zone/ Circle DDO).

Where the ward of the subscriber is eligible for more than one scholarship,
application for only one as per the choice of the applicant should be submitted with
the relevant documents as only one scholarship shall be awarded in a year. If the
application is submitted by one applicant in more than one category, then the
applications submitted will be considered for only one category.

Il) The belated applications (if any) only for the Academic Year 2024-25 in the prescribed
format for the said Academic Year (enclosed at Annexure-“C”) duly filled in, signed by the
subscriber and countersigned by the concerned Unit Head may be forwarded by the
respective DDO (i.e. Zone/ Circle/ Hqrs/ SLDC DDO) in original to the Secretary, OSEB
EPF TRUSTEE BOARD before the scheduled date. The eligibility criteria and the
scholarship amount will be same as was earlier-issued for the Academic Year 2024-25.

<!-- page 2 -->

4 fh a
OPTCL-13018/12/2025-FUND-TERMINAL BENEFITS 172677872026
MISCELLANEOUS:

1. Last date of submission of application is Dtd.15.12.2026.

2. The application should be duly filled-up. Before forwarding the same by the DDO of ‘
concerned unit (Circle/Zone/ Hqrs/ SLDC), they should ensure that the signature of the
applicant, countersignature of unit head & office Seal etc. in the application are in order. All
supporting documents are signed by the applicant.

3. The incomplete application received without supporting documentary proof and application
received after the last date of receipt will not be taken into consideration. The decision of the
Trust in this regard is final & binding.

4. All offices are requested to circulate the application form among their respective employees
who are the subscribers of OSEB EPF Trustee Board during FY2025-26 and FY2024-25 (for
belated cases).

5. The scholarship amount will be released to the wards directly through NEFT/RTGS to
their bank account after handing-over scholarship certificate.

Yours faithfully,
Encl : As above. eo
C.G.M. (F), Funds-cum-Secretary,
OSEB EPF Trustee Board
Memo No. 3422 Date: RO’, 10.2026
Copy forwarded to Sr. P.S. to CMD, OPTCL/ P.S. to M.D., GRIDCO/ P.S. to Director
(Finance), OPTCL// P.S. to Director (Project), OPTCL/ P.S. to Director (Operation), OPTCL/ P.S. to
Director (Finance), GRIDCO/ P.S. to Director (7&80), GRIDCO/ P.S. to Director (Commercial),
GRIDCO/ P.S. to Director (SLDC), for kind information of CMD,OPTCL/M.D.,GRIDCO/ Director
(Finance), OPTCL/ Director (Project), OPTCL/ Director (Operation), OPTCL/ Director (Finance),
GRIDCO / Director (T& BD), GRIDCO/ Director (Commercial), GRIDCO/ Director (SLDC >
DGM. (୮), Funds
Memo No. 313 Date: ଣ୍ଠ 10-20%6
Copy forwarded to All C.G.M.s/ Sr. G.M.s/ G.M.s/ D.G.M.s/ A.G.M.s/ Managers/ Dy.
Managers/ Asst. Managers/ Jr. Managers of OPTCL/GRIDCO/SLDC for information and nec ary
action. ‘at
ey _-
DGM. (F), Funds
Memo No. 314 Date: ˆ 106
Copy to C.G.M. (IT) with a request to publish in the website.
DGM. (୮), Funds

<!-- page 3 -->

OPTCL-13018/12/2025-FUND-TERMINAL BENEFITS 1726775/2026
ANNEXURE-“A”
~~ × ୮ -~ -_
ଓଡ଼ିଶା VQIS AR MPOIQE ASIA M8.
SHS:
101 ODISHA POWER TRANSMISSION CORPORATION LIMITED
2020 = (A Government of Odisha Undertaking)
¡୭୮ ୬୩ ୭4 1 —Regd.Office: OPTCL Tech-Tower, Janpath, Saheed Nagar, Bhubaneswar-751007 :
sa slag Telephone: (0674) 2542269, 2542743 (EPABX), Website: www.optcl.co.in ;
CIN:U41020R2004SGC007553
ar Ce Sm
OSEB EPF TRUSTEE BOARD
APPLICATION FORM FOR SANCTION OF ONE-TIME SCHOLARSHIP FOR THE ACADEMIC YEAR
2025-26
bs Name & Designation of
Subscriber (In Block Letter) 5
#; Employee ID 4
3. Contact Mobile No. :
4, PF Alc No. 3
5. Present Office Address
| (Name of unit where working) :
| 6. Name of the Son/Daughter for
| Whom scholarship is applied. 2
| 7; Name of the School/College last
। Attended by the Son/Daughter ଧୀ
।
| 8, Exam for which scholarship applied for
¦
4 9. Bank details of the Ward :
| Bank Name 8
¦ Alc Number :
| IFSC ଏ
10. (I) Examination passed for 10", +2, +3 (Hons), 85/50
a) Name of Examination passed
b) Name of the Board/Council/University
c) Month & year of passing
d) Total Marks/Total Marks in +3 (Hons.)
e) Marks secured/ Marks secured in +3 (Hons.)
¦ f) Percentage of marks/ Percentage in +3 (Hons.)
g) Grade secured & Equivalent percentage (If Applicable)
h) Name of the institution in which he/she
has taken admission
| ll) In case of Engineering, NATA.
QUAT, MBA Admission
&) Qualified in All India JEE (Main)/ JEE (Adv)/ OUAT.
* Rank :
£) B-Arch (NATA)
* Percentage >

<!-- page 4 -->

OPTCL-13018/12/2025-FUND-TERMINAL BENEFITS 126775/2026
c) MBA
(i) CAT/XAT-Percentile
(1) OJEE- Rank
d) Name of Institution in which he/she has taken
Admission (proof of taking admission s
To be submitted).
Il, Admission in Medical ‘
a) NEET Rank ତ
* Admission in AIMS
* Admission in other Medical/BDS Colleges
of Govt. :
b) Name of Institution in which he/she has taken
Admission (proof of taking admission ‡
To be submitted).
IV. In case of NTSE, NDA, INTER (CA/CMAICS), Gold medalist! 5 yr. Int, Law
a) Category under which the candidate is eligible
for scholarship. :
b) Documentary proof in support of eligibility 5
c) Name of the Institution in which he/she
has taken admission (proof of taking admission
is to be submitted if applicable.) £
V. 10 case of Sports (State Level/ National Level)
a) Category & Sports for which the candidate is
Eligible for scholarship 5
b) Documentary proof in support of eligibility ‡
DECLARATION
| do hereby undertake that the information furnished above are true. In case it is discovered at any
stage that the above information are false and not supported by genuine documents, | do undertake to
refund the amount along with the interest @10% pa to Trustee Board without any condition.
SIGNATURE OF THE SUBSCRIBER
OFFICE OF THE
Memo No. = | Dated :
Forwarded to Chief General Manager (F), Funds, 5" Floor, OPTCL Tech Tower, Saheed Nagar,
Bhubaneswar-751007 for sanction of the Scholarship amount in accordance with the letter No.
dtd. of OPTCL. The particulars furnished above have been verified with
teference to the supporting documents and found correct.
COUNTER SIGNATURE OF UNIT HEAD (WITH SEAL) SIGNATURE OF DDO (WITH SEAL)

<!-- page 5 -->

ହୂ ` ଏ < ୨ ®+". eee eR 5 787. ` ଖୀ
OPTCL-13018/12/2025-FUND-TERMINAL BENEFITS 172677572026
ANNEXURE-“B”
Name of the Exam. Passed Minimum Qualifying Yage of Marks Scholarship
Entitlement ‘
Rs.
National Talent Search Exam (NTSE) | Eligible to get scholarship from (NTSE) 20,000/-
th Minimum qualifying marks should be 70% z
୬; 10" Exam (HSC, ICSE, CBSE) and above for HSC, CBSE, ICSE. 17,000/-
| la. | +2 Exam (Science/Arts/Commerce) | 65% & above. 19,000/-
|
| 60% & above in Honors/ 70% & above
+3 Exam (with Honours), BBA/BCA (which is equivalent to honors) for BBA & 22,000/-
BCA only.
In case of JEE (Main) General Rank up to
ମି 7 2,50,000 in All India level irrespective of free/
pe Sts all une payment seat, subject to taking admission 25,000/-
and in case of OUAT having rank up to 100
and subject to taking admission.
Medical Odisha State /All India, : nee
6. National Eligibility-cum-Entrance ୟୋ ¥ in Govt. Medical/BDS 25,000/-
Test.(NEE ହି
7 National Aptitude Test in Architecture | Minimum NATA score is 60% subject to 25,000/-
: NATA). taking admission
le | CMA (Inter), CA (Inter), CS (Inter) Pass intermediate Exam 25,000/-
Any rank in All India Entrance Examination
: 5 yrs. Integrated Law subject to taking admission in National 30,000/-
University.
Securing minimum 90 percentile in
10. | Admission in MBA Course CAT/XAT, OJEE General Rank up to 10,000 35,000/-
Subject to taking admission in MBA course.
11. | AIMS (Medical MBBS), IIT (B.Tech/ | Subject to taking admission in AllMS(Medical 35,000/-
ˆ _ ¦ Integrated M.Sc.) MBBS), IIT(B Tech/ Integrated M.Sc) e
a‘ In any discipline in Graduation from any
1⁄2 | Gold Medalist recognized University/Autonomous college. SBi000!
Subject to submission of Certificate from
13 | State level sports achievement Govt. of Odisha, Dept. of Sports & Youth 17,000/-
Services.
Subject to submission of Certificate from
14 | Central level sports achievement Govt. of Odisha, Dept. of Sports & Youth 20,000/-
Services.

<!-- page 6 -->

= Se _ ¬ ଖ୍‌"; ୨୩୨୮ ୩୧" ar es ee ` ୩" + ମା
OPTCL-13018/12/2025-FUND-TERMINAL BENEFITS \726775/2026
ANNEXURE-“C”
× ୪୮୮ -~ = =
op ଓଡ଼ିଶା MQIS AR ସିଂଚାରିଣ SAA Ms.
ae ODISHA POWER TRANSMISSION CORPORATION LIMITED
ot (A Government of Odisha Undertaking)
OPTCL Regd.Office: OPTCL Tech-Tower, Janpath, Saheed Nagar, Bhubaneswar-751007
Uieline of Oaisha Telephone: (0674) 2542269, 2542743 (EPABX), Website: www.optcl.co.in
CIN:U41020R2004SGC007553
ae Se eae  _‰_..‰ଫ‰:ପଥ.... ଥାକ
B EP TEE BOARD
APPLICATION FORM FOR SANCTION OF ONE -TIME SCHOLARSHIP FOR THE ACADEMIC YEAR
2024-25
fe Name & Designation of
Subscriber (In Block Letter) :
va Employee ID :
3. Contact Mobile No. 3
4. PF Alc No. 5
ରଚି Present Office Address
(Name of unit where working) ‡
6. Name of the Son/Daughter for
Whom scholarship is applied. 2
we Name of the School/College last
Attended by the Son/Daughter ନୁ
8. Exam for which scholarship applied for :
9, Bank details of the Ward t
Bank Name 3
Alc Number $
IFSC 3
10. (I) Examination passed for 10", +2, +3 (Hons), BBA/BCA
a) Name of Examination passed
b) Name of the Board/Council/University
c) Month & year of passing
d) Total Marks/Total Marks in +3 (Hons.)
6) Marks secured/ Marks secured in +3 (Hons.)
f) Percentage of marks/ Percentage in +3 (Hons.)
g) Grade secured & Equivalent percentage (If Applicable)
h) Name of the institution in which he/she
has taken admission
Il) In case of Engineering, NATA. rs
OUAT. Admissi
a) Qualified in All India JEE (Main)/ JEE (Adv)/ OUAT.
= Rank 2
£) B-Arch (NATA)
* Percentage

<!-- page 7 -->

। ` ସକ
OPTCL-13018/12/2025-FUND-TERMINAL BENEFITS 172677572026
c) MBA
(i) CAT/XAT-Percentile
(1) OJEE- Rank
d) Name of Institution in which he/she has taken
Admission (proof of taking admission
To be submitted).
lll, Admission in Medical — ‘
a) NEET Rank ‡
* Admission in AllIMS
* Admission in other Medical/BDS Colleges
of Govt. :
b) Name of Institution in which he/she has taken
Admission (proof of taking admission ;
To be submitted).
lV. In case of NTSE, NDA, INTER (CA/CMAICS), Gold medalist/ 5 yr. Int. Law
a) Category under which the candidate is eligible
for scholarship. 4
£) Documentary proof in support of eligibility ଧୁ
c) Name of the Institution in which he/she
has taken admission (proof of taking admission
is to be submitted if applicable.)
V. In case of Sports (State Level/ National Level)
8) Category & Sports for which the candidate is
Eligible for scholarship ହି
Documentary proof in support of eligibility
DECLARATION
| ୦0 hereby undertake that the information furnished above are true. In case it is discovered at any
stage that the above information are false and not supported by genuine documents, | do undertake to
refund the amount along with the interest @10% pa to Trustee Board without any condition.
SIGNATURE OF THE SUBSCRIBER
OFFICE OF THE
Memo No. | Dated :
Forwarded to Chief General Manager (F), Funds, 5" Floor, OPTCL Tech Tower, Saheed Nagar,
Bhubaneswar-751007 for sanction of the Scholarship amount in accordance with the letter No,
dtd. of OPTCL. The particulars furnished above have been verified with
teference to the supporting documents and found correct.
COUNTER SIGNATURE OF UNIT HEAD (WITH SEAL) SIGNATURE OF DDO (WITH SEAL)
