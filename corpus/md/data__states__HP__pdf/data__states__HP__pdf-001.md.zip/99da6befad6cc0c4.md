---
doc_id: "99da6befad6cc0c4"
source_url: "https://cdn.s3waas.gov.in/s368d30a9594728bc39aa24be94b319d21/uploads/2020/08/2020082751.pdf"
ministry: "Kullu"
title: "Procedure and Rules for purchase of Stores"
date: ""
pages: 45
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "320b2d7975408351"
---

<!-- page 1 -->

Government of Himachal Pradesh
Directorate of Industries
“Store Purchase Organization”
No. Ind /SP (Misc) F (6-10)4/80-111

Dated, Shimla-171001 24.10.2013

Notification
The Government of Himachal Pradesh vide Notification No.Fin
©A(3)5/2005 dated 12-08-2009

issued by the Principal Secretary (Finance) has notified

Himachal Pradesh Financial Rules ,2009. Rule 192 of said Rules empowers the Controller of
Stores in Department of Industries to issue detailed instructions and guidelines for procurement
of goods and services from time to time in consultation with the Govt. for implementation by
different Departments of the State.
Therefore, in exercise of the powers vested in me under Rule 192 of
HPFR, 2009 and in consultation with the Govt., detailed instructions and guidelines for
procurement of goods

are hereby issued for implementation by different Departments of the

State.
All the Heads

of

the

Department/Boards/Corporations

/Autonomous

bodies are required to follow these instructions and guidelines while doing the procurement of
goods

and also issue instructions to their respective subordinate offices to follow the same in

letter and spirit.
These Rules shall not apply to the State Govt. undertakings/Corporations
who have their own Purchase rules duly approved by the Finance Department.
The Procedure and Rules for the purchase of stores by all Departments
and offices of the Government of Himachal Pradesh (Appendix 10 to HPFR, 1971 Vol-II)
amended up to 14.03.2000 are hereby repealed.
The detailed instructions and guidelines
the D e p a r t m e n t a l w e b s i t e

http://himachal.nic.in/industry

have also been uploaded in
for

convenience o f a l l

P u bl i c Procurement Entities.
Sd/Controller of Stores,
Himachal Pradesh

<!-- page 2 -->

Encls. Ind /SP (Misc) F (6-10)4/80-111

dated 24.10.2013

Copy forwarded for information and necessary action to:1.

2.
3.
4.
5.
6.
7.
8.
9

The Principal Secretary (Industries) to the Government of Himachal Pradesh,
Shimla-171002 w.r.t. his letter No.
Ind-II(F)2-4/98-III-Loose dated.16.07.2013 for
information.
All the Administrative Secretaries to the Govt. of H.P. Shimla-2.
All the Heads of the Departments/Managing Directors of the Corporations/ Boards
and Autonomous Bodies in Himachal Pradesh.
All the Deputy Commissioners in Himachal Pradesh.
All the Direct Demanding Officers in H.P.
All the General Managers, District Industries Centres/Member secretaries, SWCAs
in H.P
The Controller Printing and Stationery Department, Shimla-5 for publication in the
electronic Gazette.
The Private Secretary to the Controller of Stores, H.P. Shimla-1
P.A. to the Addl. Controller of Stores, H.P. Shimla-1.
Sd/Controller of Stores,
Himachal Pradesh

<!-- page 3 -->

Detailed Instructions and guidelines for Procurement of goods and services by all
the departments and Offices of Govt. of Himachal Pradesh.
PREAMBLE
The procurement of goods in the State is being carried out under the Store
Purchase Rules as incorporated in the Appendix 10 of HPFR-1971 Vol. II as amended upto
14-03-2000. These Rules are called “Procedure and Rules for the purchase of Stores by all
Departments and offices of Government of Himachal Pradesh.” The State Government while
making it mandatory for all the procurement agencies under the Government to follow the
tendering process in public procurement, has also initiated a series of procurement reforms.
It has been felt that there is a need for standard procurement procedure supported by the
procurement reforms such as e-Government Procurement (e-GP) so as to render the
process of procurement of goods, works and services by procurement Entities in transparent
and efficient manner.
Therefore, in exercise of the powers conferred by Rule 192 of the H.P. Financial Rules,
2009 the detailed instructions and guidelines for procurement of goods and services are
enumerated in succeeding paragraphs.
Every Department/Corporations/Boards/ Autonomous Bodies and Other Public Sector
Undertakings spend a sizeable amount of its budget for purchasing various types of goods to
discharge the duties and responsibilities assigned to it. It is imperative that these purchases
are m a d e following a u n i f o r m , systematic, efficient and cost effective procedure,
in accordance with the relevant rules and regulations of the Government. Public buying
should be conducted in a transparent manner to bring competition, fairness
and
elimination
of arbitrariness
in
the
system.
Public
Procurement Procedures
must conform to exemplary norms of best practices to ensure efficiency, economy and
accountability in the system.
To achieve what has seen stated in the above paragraph, it is essential that the
purchase officials be provided with all the required rules, regulations, instructions, directions
and guidance on best practices in the form of detailed instructions and guidelines for
procurements of goods & services.
In pursuance of this policy the following instructions and guidelines are prescribed and
except in the case of those stores and articles for the purchase of which special orders are
issued by Himachal Pradesh Government, these instructions shall be applicable to all
purchases of stores made through Himachal Pradesh Stores Department and to all
purchases of stores made by the Heads of Departments and other Offices:1. All Articles given in Annexure-I shall be purchased through the Store Purchase
Organisation except where otherwise provided in these rules or elsewhere. Articles of stores
covered in Annexure-V to these, Rules shall be purchased by the respective departments
through their respective Departmental Standing Purchase Committees which shall be
constituted with the prior approval of the Finance Department, purchases by these
committees shall be made according to the Rules and Procedures of the Store Purchase
Organisation and policy of the Government as in force from time to time. Any other item not

1

<!-- page 4 -->

covered in Annexure-I or Annexure-V to these Rules shall also be purchased through the
Store Purchase Organisation. A committee under the chairmanship of the Controller of
Stores/ Additional Controller of Stores, HP will review the list in Annexure-I and make
additions or deletions to the list in the month of December every year.
2. The purchase of country made machinery, imported machinery and equipment and all
other stores available ex-stock in India shall be made through the Stores Department or
Standing Purchase Committee, as the case may be.
3. The indents on the Stores Purchase Organisation shall be placed as soon as allotment of
funds is received and not held back till the close of financial year when there is always a
great rush of indents which possibly cannot be coped with by store purchase Organisation.
Indents received after 5th February of each year shall not be entertained by the Store
Purchase Organisation for arranging supply within the current financial year as it ordinarily
takes 6/8 weeks to finalise a Purchase case.
In case where indents are not received by the above date N.A.C. will not be issued by the
Store purchase Organisation for items which could not be brought on rate contract due to
non-receipt of indents.
4. Stores will be indented in accordance w i t h I.S.I. marking. In the absence of these, they
should conform to ISI Code of specification determined by the State Government, if any. In
the case of uncommon items, an approved sample or pattern shall be furnished for
guidance. The sample will be got approved by the Technical Officer of the Store
Purchase Organization in Industries Department. A reference to previous supply shall be
made when the same stores are required again but in no case shall a particular make or
brand be insisted upon, as this restricts competition to the disadvantage of the buying
department.
5. (i)The Heads of Departments shall consolidate their normal and recurring requirements of
stores as defined in annexure I, and place indents on the Controller of Stores, in a
consolidated form. In emergent cases, direct indents from subordinate officers, as nominated
by Heads of Departments from time to time, shall be entertained by the Controller of Stores.
(ii) W hile placing the indents, the indenting officers shall certify that necessary funds exist to
meet the liability and that competent sanction to the purchase has been obtained by them.
6. Indenting Officers can indicate the time to be allowed to tenderers for submission of their
tenders. In case an item is to be specially imported, they should take into consideration the
time required by various firms to obtain the prices from abroad.
7. Every Purchasing authority shall be competent to effect purchase without inviting
quotations, provided that the value of articles to be purchased shall not exceed Rs.3000/in a case and the total value of such purchases made during a financial year shall not
exceed Rs. 50000/- in all.
8. For indents valuing less than Rs. 10.00 lacs
the system of “limited Tenders” i.e. direct
invitation to all known firms supplying that item/material may be adopted. The number of
firms addressed should not be less than six and number of offers/quotations/tenders received
should not be less than three. The process of limited tender shall be initiated by individual
Department/ Corporation/ Board/ Autonomous body and other public sector undertaking at
their own level.

2

<!-- page 5 -->

9. (i) All indents valuing Rs.10 Lacs and above or such limit as may be prescribed shall be
advertised by the Store Department and Public P rocurement Entity as the case may be in
the press in a consolidated tender notice. Copies of tender notices shall simultaneously be
forwarded to manufacturers or their branch offices in India or accredited agents whose
lists are sent by the indenting officer, as also those suppliers whose addresses happen to be
available on the approved list of the Stores Department. It shall invariably be specified in the
tender‟s notice that the power is reserved to reject any or all the tenders received, without
the assignment of a reason. Furthermore the tenderers shall initial all corrections in the
tender and non-compliance with this condition will render the tenders liable to rejection.
(ii) The advertisement shall be issued and regulated in the manner prescribed by
Government from time to time. The emphasis will be on e-procurement, which means that
e-tendering process will be adopted by all Public Procurement Entities including Store
Purchase Organisation.
iii) The consolidated advertisements should be published regularly on 15th and the last date
of each month. Special advertisements, however, for emergent demands may be issued by
the Controller of Stores from time to time.
(iv) A period of 3 weeks from the date of publication shall be given for the receipt of tenders,
except in case of urgent demands where the period may be reduced to 2 weeks. The
controller of Stores/Additional Controller of Stores in Store Purchase Organisation/ Head of
the Public Procurement Entity or any Gazetted officer authorized by him is the competent
authority to decide the nature of urgent demand.
(v) The tenders received in manual form shall be collected in a locked box to be opened on
the day fixed for the purpose and in the case of e-tendering bids/tenders shall be received in
concerned organization’s web portal.
(vi) The tender shall be opened by a panel of 3 Gazetted officers, of whom 2 will be from
the Store Department and one will be a representative of user Department. The Store
Department will intimate to the user Department the date fixed for opening of tender, at least
a fortnight in advance to enable him to depute his nominee.
(vii) The tenders received till the fixed time and date will be opened by the panel of officers,
who shall sign all sheets in the tender forms where rates are given and in the presence of
such tenderers who may be present at the opening.
(viii) All alterations or cuttings in the tenders shall be initialled by the panel of officers.
(ix) All samples received at the time of opening shall be signed by the members of the panel.
No sample will be entertained after the prescribed time.
10. Under Advertised/Open Tendering Method, tenders shall be invited from all potential
bidders through open public advertisement. Any person or firm may participate in response to
such advertisement. The following procedure shall be adopted for Advertised/open Tendering
method of tenders:(i)

The tenders shall be submitted in a sealed cover, duly super scribed giving the
serial number of the tender and the date of opening and addressed to the
Controller of Stores, Himachal Pradesh;

3

<!-- page 6 -->

(ii)

The tenders in a sealed cover shall comprise two separate envelopes. Each
envelop shall contain separately the TECHNICAL BID and the FINANCIAL BID;

(iii)

The envelopes shall be marked as “TECHNICAL BID” AND “FINANCIAL BID”
in bold and legible letters to avoid any confusion;

(iv)

Initially, only the envelope marked: TECHNICAL BID” shall be opened. No decision
regarding disqualification or rejection of any bid shall be conveyed in bid opening
session.

(v)

The envelope marked as “FINANCIAL BID” shall be retained in the custody
W ithout being opened;

(vi)

The TECHNICAL BID shall be evaluated in a manner prescribed in advance,
without reference to the price and reject any proposal/bid which does not conform
to the specified technical criteria;

(vii)

The mandatory and non-mandatory documents should specifically be mentioned in
the tender document;

(viii)

During the technical evaluation no amendments in the technical proposal shall be
permitted;

(ix)

The FINANCIAL BID shall be opened publicly at a time, date and venue
announced and communicated to the technically qualified bidders in advance;

(x)

After the evaluation
and approval
of the technical proposal, the
“FINANCIAL BID” within the bid validity period, shall be opened of the technically
qualified/accepted
bids only. The financial bids found technically nonresponsive shall not be opened and;

(xi)

The bid found to be the lowest evaluated bid shall be accepted.

11. After the receipt of tenders, a comparative statement of rates shall be prepared and in
the case if e-tendering comparative statement will automatically generated by the software
and the tenders may be scrutinized by a committee constituted by Controller of Stores/Addl.
Controller of Stores from time to time.
12. (i) Due consideration shall be given to the views of Indenting Officer and when it is not
proposed to accept such recommendations, the view of his next higher authority shall be
obtained before rejecting his recommendations.
ii) W hen it is necessary to accept tenders other than the lowest, Tender scrutiny committee
scrutinizing the tenders shall record in writing the reasons for accepting the tenders other
than the lowest.
(iii) In the Stores Department such powers for acceptance of tenders as may be approved by
Government from time to time, shall be exercised and above the limits so prescribed, prior
approval of Government, in the Industries Department shall be obtained, whose authority
shall be final.

4

<!-- page 7 -->

13. (i) The amount of earnest money shall be deposited by the tenderer with their
tenders, which may be regulated in following manner:Sr.No

Amount of Purchase Value of Rate Contract/tender

Earnest Money

1

Rs.2 lacs to 5 lacs

Rs.10,000/-

2.

above Rs.5 lacs to 10 lacs

Rs.25,000/-

3.

above Rs.10 lacs to 50 lacs

Rs.50,000/-

4.

above Rs.50 lacs to 1crore

Rs.2,50,000/-

5.

above Rs.1 crore

Rs.5,00,000/-

Note; The minimum amount of earnest money will not be less than Rs.10000/- in any case
except as provided under sub rule (iii) of Rule 13.
However, as and when the name of a firm is included in the approved list of contractors and
it deposits the appropriate permanent earnest money, the condition of depositing earnest
money alongwith the tenders would not apply. Registered local
Micro & small scale
enterprises, which are also registered with the State Store Purchase Organisation, shall be
exempted from the deposit of permanent earnest money and also earnest money alongwith
the tenders for such items. Similarly small scale industrial units registered with the D.G.S.&D
or N.S.I.C. shall also be exempted from the deposit of earnest money alongwith the tenders
for such items for which they are registered with the D.G.S.&D or N.S.I.C. Himachal
Pradesh. State Government undertakings and the Government of India Undertakings shall
also be exempted from the deposit of earnest money alongwith the tenders.
(ii) W hen big firms do not comply with this requirement or certify that they have already
deposited the security with the Director General of Supplies and Disposals or are registered
with the department, the question of foregoing the earnest money or of asking the firms to
deposit it immediately may be gone into in individual cases. Tenders of big firms should not
be rejected merely because they do not deposit earnest money along with the tenders. The
officer competent to accept the tender shall be competent to waive this condition.
iii) W hen quotations are invited for supply of stores valuing less than Rs.10,000 the
tenderers shall not ordinarily be required to furnish earnest money if the authority inviting the
quotations is satisfied as to the financial position of the firm.
(iv)
The local registered enterprises which are also registered with the Store Purchase
Organisation are exempted from depositing security amount while entering into rate contract
with them. The other firms /stockists shall deposit the amount of security money and be
regulated in the following manner, while entering into rate contract with firms:Sr.No.

Amount of Estimate Value of Rate Contract
/Tender

Performance security

1

Rs.2 lacs to 5 lacs

Rs.10,000/-

5

<!-- page 8 -->

2.

above Rs.5 lacs to 10 lacs

Rs.25,000/-

3.

above Rs.10 lacs to 50 lacs

Rs.70,000/-

4.

above 50 lacs to 1crore

Rs.5,00,000/-

5.

above Rs.1 crore

Rs.10,00,000

Note:
case.

The minimum amount of security money shall not be less than Rs.10000/- in any

14. Samples wherever required, shall be submitted on or before the tender date by the local
tenderers and in the case of outstation tenderers within 10 days of the tender date but on or
before the date of opening of tenders.
15. In case of large variety of material for which rigid standards cannot be laid down the
alternative approved brands of various makers shall be specified in the tender notices and
purchases made direct from the manufacturers or their accredited agents, representatives or
stockists rather than from the retailers.
16. W hen bulk supplies are arranged the approximate delivery period for part supplies shall
be indicated in the schedule and the tenderers called upon to intimate whether they will
adhere to it. They may, however, be given an option to vary the delivery dates slightly.
17. Late tenders/quotations shall not be considered, but where it is deemed necessary, in
view of the rates quoted within time being high or otherwise not acceptable, all the tenderers
and other known suppliers shall be given an opportunity to requote in sealed covers by a
fixed date.
18. (1) W here the suppliers are required to quote on the prescribed tender form, the
following tender fee is fixed:Estimated value of the order

Cost of tender

(i)Upto Rs 1.00 Lac
Rs.100/ii)From Rs. 1.00 Lac to Rs.5 Lac.
Rs.300/(iii)Above Rs. 5 Lac
Rs.500/In the case of annual rate contract the cost of tender form is fixed Rs.500/-.
(2) These shall be available for sale at the following places or any other place which may be
notified from time to time:a) at the office of the Controller of Stores, Himachal Pradesh.
b) at the office of the General Manager, District Industries Centres in Himachal
Pradesh,
Deputy
Director
of
Industries,
Single
window
clearance
agencies,(SW CA), Baddi, and all .Member Secretary, SW CA in H.P.
c) Himachal Pradesh Pavilion Pragati Maidan, New Delhi.
Note:

The tender forms in respect of tenders invited through e-tendering will be
uploaded in the web portal of the Department.
All the Industrial units of Himachal Pradesh registered with the Store Purchase
Organisation and the industrial units registered with the D.G.S. &D or N.S.I.C will be supplied

6

<!-- page 9 -->

tender forms free of cost for such items for which they are registered with them on the
production of attested copy of valid registration certificate.
(3) The tender fee shall not be refundable under any circumstances.
19. (a) Limited Tender System i.e. by inviting quotations from a large number of registered
firms:This system shall be adopted only for immediate requirements of stores and the emergency
shall be established and certified by the indenting office in writing and unless competitive
tenders from at least 3 firms are received the quotations shall be rejected. If the demand
happens to be very urgent, the authority next above the indenting officer, may be consulted
before rejection, and if that authority recommends that the purchase be effected on the basis
of the number of tenders received and certifies that the rates in tender, proposed to be
accepted, are reasonable, suitable action shall be taken in the Stores Department after
referring the matter to the authority next above that ordinarily competent to sanction
purchase.
19.(b) Advertised Tender System:(1)This method shall be used for procurement of goods of estimated value of Rs.10.00 lacs
(ten lacs rupees) and above or such limit as may be prescribed. Advertisement in such cases
shall be given in the official Gazette of Himachal Pradesh and at least in two leading daily
newspaper having wide circulation.
(2)The Controller of Stores/ Public Procurement Entity having its web site shall also publish
all its advertised tender enquiries on the web site and provide a link with web site.
(3) The Controller of Stores/ Public Procurement Entity shall also post the complete tender
documents in its web site and permit prospective bidders to make use of the documents
downloaded from the web site. Specific mention shall be made in the tender documents for
comprehensive maintenance contract where ever required. If such a downloaded tender
documents are priced, there shall be clear instructions for the bidder to pay the amount
alongwith the bid.
(4) The number of firms/bids received in the advertised tender system shall not be less
than three. If the number of firms/bid received is less than three, then normally such tender
may be rejected and process of re-tendering may be initiated. However, If the demand
happens to be very urgent, the authority next above the indenting officer, may be consulted
before rejection, and if that authority recommends that the purchase be effected on the
basis of the number of tenders received and certifies that the rates in tender, proposed to be
accepted, are reasonable, suitable action shall be taken in the Stores Department after
referring the matter to the authority next above that ordinarily competent to sanction
purchase.
(5) If after the technical scrutiny of tender, only one or two firms qualify for financial bid, then
their financial bids shall be opened and rate contract/supply order shall be issued subject to
the approval of the Government. The Administrative Department of concerned Department
will be competent to approve such Proposals. In other cases,

7

<!-- page 10 -->

rate contract/supply order shall be issued according to the financial power vested/delegated
in favour of competent authority.
19. (c) Single tender system i.e. by obtaining tenders from one firm in case of articles of
proprietary nature available from one source:Articles of proprietary nature shall be purchased according to financial powers
delegated to officers, after obtaining, a certificate from the manufacturers or sole agents that
the rates quoted by them are minimum and identical to those approved by the Director
General of Supplies and Disposals or the rates that they would quote to that Organisation or
to any other State in the country.
19 (d) The Controller of Stores/ Addl. Controller of Stores shall be competent to issue rate
contracts of the same item of specific brands of national/ International repute of the
manufacturers at different rates in such cases in which he is competent to approve the rates
and in cases which are beyond his competency with the prior approval of the Govt.
The financial powers of officers of the Stores Department for calling such
quotations/tender shall be determined and fixed by Government from time to time.
19(e) By negotiation with Government Institutions or Government owned Corporations:Purchases can be affected by negotiations from Government Institutions or Government
owned Corporations by the Stores Department in exercise of powers that may be delegated
to officers of that department by the competent authority, from time to time. Items
manufactured by Government owned institutions, corporations and boards which are not
manufactured by Micro & small scale industries within the Pradesh may be purchased
directly by the concerned department.
19(f) By negotiation with private parties in case of emergencies:This system should be adopted very sparingly in emergencies, and when it becomes
necessary to do so, the attention of the authority next above the authority ordinarily
competent, both in the indenting department and in the Stores Department, shall be drawn to
such a case before doing so. Such powers as may be delegated to officers of Stores
Department from time to time, shall be exercised.
19 (g) By purchase Committee approved by Government from time to time:W here it is not possible to obtain competitive tenders or quotations or to lay down
comprehensive and complete specifications, the purchases shall be made by Purchase
Committees as may be appointed by the competent authority from time to time.
19 (h) By Departmental Standing Purchase Committees. All the departments will constitute
their Standing Purchase Committees with the prior approval of the Finance Department.
These Committees will have no connection with the Stores Purchase Organisation but for
the bigger departments like Public W orks and Forest, at the time of constitution of these
committees, the Finance Department will nominate one representative of the Store Purchase
Organisation. These Purchase Committees will have no limit of their financial powers but
where the cost of any single item exceeds Rs.20 lacs prior approval of the Government in the
concerned administrative Department shall be obtained.

8

<!-- page 11 -->

The Departments and Purchase Committees shall ensure that:(i) Purchases are made according to the instructions & guidelines of the Store Purchase
Organisation herein and policy of the Government as in force from time to time.
(ii) W hile making purchases, it would be certified that local Industrial units or Himachal
Pradesh Government owned bodies do not manufacture these items and that there is no
rate contract entered into by the Controller of Stores. For such items that are manufactured
by local Industrial units or Government owned bodies but because of urgent nature of
demand or because the demand is in excess of the capacities of the units or for any such
reason due to which it is not possible to procure supplies from such units, in time, no
objection certificate shall be obtained from the Controller of Stores.
19(i) By obtaining no objection/non- availability certificate:Controller of Stores/ Addl. Controller of Stores will be competent to issue no objection
certificate/non-availability certificate upto the powers of purchases vested in him. In case of
purchase of petty store articles the G.M. DIC of a Distt. will be competent to issue NOC/NAC
to the DDO‟s upto Rs.50,000/- per item annually in their respective districts. For other
cases which are not within his competency the Administrative Departments will be
competent to issue NAC after obtaining clearance from the Industries Department .NOC in
respect of items not covered in Annexure-I & V shall be issued by the Controller / Additional
Controller of Stores, H.P .if the same has not brought on rate contract.
19 (J) By placing direct order against rate contract.
(i)
the Store Purchase Organisation will, to the extent possible, enter into rate contract
for items of general use. All Heads of Departments will be direct Demanding Officers in
respect of rate contracts entered into by D.G.S&D but they will operate those rate contracts
only if these items are not manufactured by the local units, Government bodies etc., and
there is no rate contract by the Controller of Stores.
(ii)
Controller of Stores will have the powers to enter into rate contract on the same
terms and conditions as those entered into by the D.G.S & D.
Note:- Approval of Government in the Industries Department, whose authority shall be final
shall be obtained in cases where the amount involved exceeds that for which powers have
been delegated to officers of the Stores Department, under the above rule.
20.
The Officers of the HIMACHAL PRADESH Government shall exercise such powers
in the matter of local purchases of stores as may be delegated to them by the State
Government from time to time.
Note: - After exhausting all sources of supplies, individual departments may make local
purchases subject to the limits given in annexure IV. These powers will be exercised only if
the items are not manufactured by the local industrial units and Government bodies and
there is no rate contract for these items finalized by the Controller of Stores.
21.
For purchase of articles (irrespective of cost), the Stores Department shall enter into
Rate or Running Contracts. The Government Officers should not purchase these articles
from any other source, but place an order direct on the firm concerned. If the firms fail to
supply, the articles may be purchased from other sources, and if the rate be higher, the firm
having the Rate or Running contract will be liable to reimburse the extra expenditure

9

<!-- page 12 -->

Incurred by the Government. There should be a clause to this effect in the Rate or Running
Contract.
Note: A Rate Contract is a contract for the supply of stores at a specified rate. No quantities
are mentioned and the contractor is bound to accept any order which may be placed with
him. A Running Contract is a contract for the supply of an approximate quantity of stores at a
specified price during a certain period. Such a contract shall be entered into in respect of
stores of standard types, which are in common and regular demand and the prices of which
are not subject to appreciable market fluctuations.
22. (i)(1) Purchase Preference: Purchase preference means the preference to local Micro
and Small Scale units in which while placing orders purchase preference shall be given to
local manufacturers and at least 25% of the total orders shall be placed with them on
lowest approved rates, wherever applicable provided such products meet the required
quality standards.
Provided that the minimum purchases from local manufacturers as provided in the
Rules 22(i)(1) above shall not be applicable in respect of items which in the opinion of the
Head of Department is an item of sophisticated nature and high technology and precision
standards.
Provided further, where it is not possible to procure at least 25% from the local
manufacturers, the Head of Department for reasons to be recorded in writing may purchase
from other firms on rate contract.
22(i)(2) Parallel Rate Contract: A parallel rate contract is a contract entered into with the one
or more local m a n u f a c t u r i n g unit(s), on the lowest approved rates, whose products fulfil
the technical requirements laid down under following c o n d i t i o n s :a) If the loc al unit(s) had par t ic ipat ed in t he o r igina l t ender an d was f ound t o be
t ec hnic all y qual if ied, wit hout pr ior appr ov al of t he G ov er nment .
(b) If the unit(s) had not taken part in the original t e n d e r , having come into production after
the tender was opened, only with the prior approval of the Government.
(c) If the local unit(s) start manufacturing concerned items after opening of the
tenders, such unit(s) can b e considered for the award of parallel rate contract with the prior
approval of the Government and also after the samples of the item(s) are approved by the
Controller of Stores.
d) In the case of ISI products, if the unit(s) which have taken part in the tender was not in
possession of the ISI certificate at the time of opening of tenders, may also be awarded
parallel rate contract at its request if the unit produces ISI certificate after finalization of
tender and issue of rate contract by the Controller of Stores.
The Controller of Stores reserves the right to make offer of parallel rate contract under
clauses a) to d) above to only those local unit(s) whose quoted rates fall within 15% of the
lowest quoted rates.
22. (ii)(a) All Government Departments, autonomous Bodies, Government Corporations,
Boards etc., should get the job works done such as conversion of Billets into M.S. Round,
etc. Body buildings of Trucks and Buses and conversion of Coil into G.I. W ire etc., against

10

<!-- page 13 -->

the rate contract issued by the Controller of Stores or after obtaining the “No objection
certificate” from him.
(b) In execution such job works, like raw materials i.e. Billets and M.S. Coil etc., are to be
made available to the Contractor/local unit, by the Department, Corporations and Boards
etc., and the local units are not required to meet the cost of even transportation thereof to
the factory premises.
(c) For executing such job work the local Micro & Small Scale Industrial units be allowed
purchase preference.
23. (i) All articles purchased through the Store Purchase Department shall, before
acceptance, be subject to inspection by the Store Inspection Officer or such other officer as
may be authorized by the Controller of Stores or Indenting Officer provided that the
inspection shall be carried out by the Departmental Officer invariably in association with two
technically competent officials.
ii) 100%
payment
will be made within 21 days against physical delivery of
inspected/accepted stores duly supported with satisfactory inspection note and after receipt
of correct goods at consignee’s site/ destination except in cases covered by sub clause (v) of
this rule where percentage payment be limited to 90%.
(a) an inspection note, signed by an officer of the stores Organisation, bearing the seal of his
office, which should clearly indicate that the goods were sealed in his presence in token of
acceptance, and
(b) railway receipt or goods receipt indicating that the consignment has been booked at
railway risk or at the risk of approved goods carrier.
iii) In a few cases like chemicals, glassware, crockery, inflammable, l i q u i d s etc., the
railway or goods transport carriers may not book the consignment at their risk, for want of
elaborate packing. In such cases, the supplier may choose to send the consignment duly
insured and whenever this is done, 80 percent payment may be allowed even if the railway
receipt is at owner‟s risk as losses in such cases can be recouped from the insurance
companies.
(iv) The disbursing officer shall be responsible to see that balance payment to suppliers are
positively made within 30 days of receipt of goods by consignees, correct to the
specifications as laid down in the order or within such time as may be agreed to and
prescribed by the Stores Department in individual cases.
(v) In the case of machinery where its satisfactory working is required to be examined,
balance payments should be arranged immediately on satisfaction about the condition of the
machinery and even in case where it is to be set up and tested, not later than 3 months of
receipt by consignee unless otherwise mentioned in Schedule “A”.
(vi) W hen the payment is not cleared within the prescribed period, the heads of Departments
will be personally responsible to report the cases, explaining clearly the reasons of delay to
the Administrative Secretary who in turn shall inform the Minister-in-charge of his
department, W here delay in payment is more than one month over and above the prescribed
maximum limit the Administrative Secretaries shall personally explain the reasons to the
Minister-in-charge of their respective Departments concerned as well as to the Chief
Minister.
24. Orders placed by the Stores Department shall not be cancelled or terms and particulars
thereof modified by indenting department except to the extent as may be approved by the
Stores Department in writing in each case.

11

<!-- page 14 -->

25. In cases where there is delay on the part of contractors in the supply of Stores, and
articles supplied do not conform to the prescribed samples, specifications, etc., or are not of
the specified number, weight, volume etc., the Stores Department with the prior approval of
the Government in the Industries Department whose authority shall be final, may deduct
payment for short supply and in addition impose a penalty subject to the conditions,
contained in the agreements, executed in each case. W here the failure, partial or total, on
the part of a contractor to supply articles leads to purchase of those articles from another
sources at a higher rate, the contractor shall also be liable to pay the excess expenditure
incurred on such purchase. The penalty so imposed and excess expenditure so incurred will
be recoverable from the securities of the contractors, deposited with the Stores Department
or their pending bills or both.
26. The Himachal Pradesh Government in the Industries Department, in consultation with
the Finance Department, where necessary, may sanction a departure from these rules in
any individual case, if public interest so requires. All applications for such sanctions should
be made through the Administrative Department concerned. The opinion of Stores
Department shall, however, be obtained before sanctioning such departures.
27. (i) The Stores Department can make purchase of stores on behalf of other states and
Co-operative Societies etc., on payment of 2% departmental charges. Local bodies/
Government undertaking/ Boards/ Corporation etc., have been exempted from this payment.
It is obligatory for autonomous bodies and Government corporations and Boards to operate
on the same rate contract which are entered into by the Controller of Stores/Addl. Controller
of Stores except such Local bodies/ Govt. Undertaking / Boards/ Corporations etc. which
have their own set of rules regarding purchase of store articles duly approved by the Finance
Department of the State Government.
(ii) The charges so recovered from local bodies, other States, Co-operative societies
etc., will be credited to the revenue of the State being receipts in respect of the Stores
Department.
28. The Stores Department will maintain a list of approved contractors who apply to the
department for registration on the prescribed form alongwith requisite documents and pay
the prescribed registration fee. The registration of each contractor may be renewed in the
succeeding year, If his performance remains satisfactory on payment of the prescribed fee.
The cost of registration form, registration fee and renewal fee shall be as under:Cost of application form
Rs. 100/Registration fee
Rs.1000/-Renewal fee per year
Rs.1000/Benefits to registered tenderers:1. The local industrial units registered with Store Purchase Organisation are
exempted from submission of Tender Fee.
2. The local industrial units registered with Store Purchase Organisation are exempted
from submission of Earnest Money.
3. The local industrial units registered with Store Purchase Organisation are exempted
from submission of Security money.
4. The local industrial units and supplier registered with Store Purchase Organisation are
included in the mailing list of Store Purchase Organization and intimation with
regard to forthcoming Notice inviting Tenders (NIT) are sent to them from time to
time.

12

<!-- page 15 -->

29.

The financial power of officers of the Stores Department in the matter of purchase of
Stores/ NOC will be as under:
Financial Limit

Particular

Industry
Minister

Secretary
Industries

Controller
Stores

of

Power in respect of
issuing
of
rate
contracts/approval
of
rates.
Powers of Purchase of
Stores through open
tender
Power in respect of
issuing NOC/NAC

Full Power

1.00 Crore

60.00 Lakhs

Additional
Controller of
Stores
30.00 Lakhs

Full Power

50.00 Lakhs

25.00 Lakhs

15.00 Lakhs

Full Power

30.00.Lakhs

15.00 Lakhs

10.00 Lakhs

The above f i n a n c i a l P o w e r s w i l l be enhanced/modified b y the State G o v e r n m e n t a s
and when necessary.
30. Tenderers/quotations f o r purchase o f stores required for public service shall be invited
on prescribed form (Annexure-II) a p p l i c a t i o n s for registration of contractors will be made
on the form at Annexure-III.
31. If after the issue of rate contract the prices of the raw material (from official source only)
or the taxes subsequently would go up, the Controller of Stores shall be competent to
operate price escalation clause to the extent admissible as per the delegated powers.
However, the Controller of Stores shall inform the Government of the action taken in such
cases in due course.
Repeal and Savings:
(1) The Store Purchase Rules i.e. “Procedure and Rules for the purchase of Stores by all
Departments and offices of Government of Himachal Pradesh.” Is also hereby
repealed.
(2) Notwithstanding
such repeal,
any form(s)
instructions(s),
notification(s),
delegation(s), clarification(s) code(s) or any other correspondence of any type issued
or made under the rules so repealed, so far as they are not inconsistent with these
rules, shall remain in force until superseded under these rules;
(3) If there arises any difficulty (ies) or doubt(s) in implementation of any
provisions of these instructions and guidelines, matter will be referred to the
Government, and decision of the Government shall be final.
Sd/Controller of Stores,
Himachal Pradesh

13

<!-- page 16 -->

ANNEXURE –“I”
CODIFIED L I S T OF ITEMS OF STO RES FOR WHICH RATE
CONTR ACT FINALISED BY THE STORE PURCHASE ORGANISATION.
Sr. No.
1
2

Code
C-01
C-02

Name of item(s)
Acids & Chemicals
a) Bleaching Powder
b) Bactocare Pulse (W ater purif ying chemicals) Alumina
Ferric

3

C-20

4

C-25

5

C-26

6
7
8
9
10
11
12

C-29
C-33
C-39
C-40
C-47
E-05
E-06

Building Lime
Hydrated Lime & Quick Lime
b)Unslacked Lime.
Soap & Detergents
Phenyl
a) Paints & Varnishes
b) Quality Paints of National repute
Tyres & Tubes
H.D.P.E. Pipes.
Microscopes & Optical Instruments.
H.D.P.E. Storage Tanks.
High Density Polythene W oven Fabric(Geo-Mambrane)
Electrical Power Cable & W ires
Electrical Appliances
a) Household Electrical
Appliances.
i) Electrical Radiators (Room Heaters).
ii) Blower-cum-Room Heater.
iii) Electric Stoves.
iv) Electric Kettles & Jugs.
v) Coffee Percolator
vi) Heating elements.
vii) Thermostats.
viii) Electric portable lamps
stands and brackets.
ix) Electric Hot Plates.

13

14

E-06(01) Electrically Heat Pillar/Tower Type Heaters(Radiators)
E-08
Electric Fans.
a) Ceiling fans. b) Table fans.
c) Pedestal fans. d) Exhaust fans
E-09
Electric Fittings /Luminaries:
a) Striplite Patti fittings.
b) Box type fittings.
c) Industrial fittings.
d) Decorative fittings.
e) Street Light fittings
f) Acylic sheds shades &
accessories

14

<!-- page 17 -->

15

E-10

Electric Lamps, Tubes & Accessories.
a) Tungston filament lamps
b) Tubular fluorescent lamps,
Compact lamps, Compact
fluorescent lamps.
c) Mercury vapor lamps.
d) Sodium lamps.
e) Neon light lamps.
f) Ballasts f o r f l u o r e s c en t l a m p s , M V l a m p s a n d
Sodium lamps.
g) Capacitors.
h) Starters.

16

E-12

Switchgears and Control Gears
a)Carriers & bases used in requirable type electrical fuse
(kit-kat)
b) Circuit breakers.
c) Relays.
d) Distribution boards.
e) Moulded circuits breakers and distribution boards.
Wire Accessories.
(i)Switches/Sockers & others wiring accessories:
a)Bakelite switches & sockets.
b) Piane/flush type &
Switches & Sockets.
c) Bakelite/flush type plug.
d) Ceiling roses.
e) Holders.
f) Battons.
g) Boards,
h) Blocks.
i) Bakelite sheets.
j) Gutties.
k) i) Link clips.
ii) Rigid steel conduits & accessories.

E-12(02)

17

E-14

18

E-14(03)
E-17

19

E-18

Electric Motor Generators:
a)Electric Motors.
b) Electric Generators.
c)Servo Voltage Stabilizer

E-18(01)

Electric Motors (ISI Marked)

20
21

M-01
M-02

Adhesive insulating tapes for electrical purposes.
Refrigeration & Air Conditioning Equipment:
a) Deep freezers.
b) Refrigerators.
c) W ater Coolers.
d) Bottle Coolers
e) Ice cans.
f) Room Air Conditioners.

Nuts & Bolts.
G.I .W ire (Galvanised Iron W ire
Mild Steel wire for General Engineering Purpose (M.S/Hot
Dip-Galvanized/ Electro-Galvanized)
15

<!-- page 18 -->

22
23
24

M-03
M-07
M-08

25

M-11

Barbed W ire and U- Staples.
Sewing Machine.
RCC Pipes & Collars
(Reinforced cement concrete).
a) Electric Resistance W elded Pipe (ERW Pipes) Not
Slotted.
b) Electric Resistance W elded Pipe (ERW Pipes) Slotted.
Cast Iron Pipes.
c)All welded stainless steel cage.

M-11(02) Drive casting pipes.
M-11(03) Iron steel cage.
26

M-14

Pipe Fitting
a) Galvanised Iron Malleable pipe fitting.
b) W rought Steel Pipe fitting
c) Cast Iron Fittings.

27

M-15

a)Gun Metal Gate Valves
b)Gun Metal Glove Valves
c)Gun Metal Check Valves
d)Foot Valves
e)Reflex Valves
f) Sluice Valves, Cast Steel (Forged Carbon Steel) valves
g) Reflex Cast Steel (Forged Carbon Steel) valves.
h)G.I. Sluice valves

28
29
30
31
32

M-16
M-19
M-21
M-25
M-27

M.S. Flanges (Mild Steel Flanges).
Sanitary Fittings
Mild Steel W elded Tanks (M.S. W elded Tanks).
Building Material, Hardware
Agricultural Machineries
a) Power operated wheat thrashers.
b) Power operated wheat shellers.
c) Corn shellers.
d) Power operated Chuff cutters.
e) Power operated Chuff cutter-cum-wheat thrashers.
f) Seed grader-cum-cleaner.
g) Hand operated chuff cutters.
h) Manually operated chuff cutters.

33

M-28

Agriculture Implements/Tools.
a) Plough,
b)Set of hand tools
c) Plough shares.
d) SS Plough.
e)Three type cultivator
f) Single Row Bar Harrow (Bullock drawn),
g) Disc .Narrow (Bullock drawn).
h) Seed-cum-Fertilizer Drill (Bullock drawn).
i) Hand Rake.
j) Hand finger type welder
k) Digging Nee.
l) Serrated sickle
m) Pattella-cum-Pudler.
16

<!-- page 19 -->

34

M-29

35

M-30(01)

Agriculture Equipments
a) Storage Bins
b) Atta Boxes

36

M-38

Road & Forest Tools.
a)Road and Forest Tools
b)Tools Basked ,W ood handle for pick axes etc.
Inter Link Chain (Galvanized/ Mild Steel Chain Link Fence
Fabric for fencing purposes only)
Survey and Drawing Machinery

37

M-39

Survey and Drawing Instruments/Equipment.

38

M-43

Sheet Metal Products:
a)Iron boxes/Trunk
b) G.I.Buckets.
c) W ire Buckets.
d) Coal Char Buckets.
e) Heating Stoves / Pipes/ Trays
f) Angithies.

39

M-44
M-44(01)
M-44(02)

40
41
42

M-45
M-49
M-58

43
44

M-59
M-61

45

M-61(01)
M-61(02)
M-65
M-65(01)

M-30(02)

46

48
49
50

M-71
M-71(01)
M-73
M-78
M-79

51

M-83

52

M-84

53

M-88

47

Steel Almirah and Cabinets.
Modular Furniture and W ork Stations
Pre-School Material
(See-Saw-W ooden Chowki, Iron Swing, Slider, Round
About etc.)
Iron Safe/Chest.
Paint Brushes.
a) Fire Fighting Machinery.
b) Fire Fighting Equipment /Accessories .
W ooden Furniture.
Readymade doors, W indows Frames Shutters & Iron Grills
etc.
Aluminium Doors, W indows etc.
Highway Guard Rail System
Cement (PPC & OPC)
Triangular Polyester Fibre for all kinds of cement
Mortar/Concrete works.
Sign Board/Side Board
Delineators/Logo Sign Board
Nursery Protection Tools/ Equipment.
Cold Tyre Retreading.
Road & W ater Supply Equipment.
a) W heel Barrow.
b) Grit Heating Vessels.
c)Bitumen Heating Vessels
d)Cholorinator Tank.
Diesel Engine.
Iron & Steel
a) M.S. Rounds.
b) Ribbed Steel.
c) Angle Iron.
d) Channels.
e) High Strength Deformed Steel Bars and W ires for
concrete reinforcement.(Tor Steel)
Air Compressor & Portable Diesel Engine.
17

<!-- page 20 -->

54
55
56
57
58
59
60
61
62
63

M-99
M-103
M-104
M-105
M-113
M-114
M-115
M-116
M-117
M-118
M-118(01)

64

M-119
M-119(01)

Stainless Steel Utensils.
Stainless Steel W ater filter/ Purifier.
Ball Bearing
Cement Hollow Blocks.
Spare Parts for Plumbing Kit.
W elded Steel W ire Mesh Fabric
Plumbing Kit
LP Gas infrared Heater.
Steel/Fibre Reinforced Concrete (SFRC) Main Hole Cover.
Gabions Boxes and Gabion Mattresses
Gabion Boxes(Mechanically W oven, Double Twisted,
Hexagonal Mesh Gabions
Hydro Pipe Machinery/ Equipments.
Hydro Pipe Machinery/ Equipments

65

M-120

W eighing Scale

66

M-121

67
68
69
70

M-122
M-123
M-124
M-125

Reinforced Cement Concrete Fence Posts & Cement
Concrete Flooring Tiles
W eighing bridge
Height measuring stand with weighing scale
W ater proofing material
Petrol/Diesel Generating Sets

71

M-126

Vehicles

72

T-02

Bed Sheet

73

T-03

Bed Covers /Pillow Covers

74

T-04

Textile Floor Coverings:
a) Druggets W oollen.
b) Druggets Cotton.
c) Coir Carpets.
d) Synthetic Vinyl (Non-W oven)
e) Godown covering.

75
76
77

T-05
T-06
T-07

78
79

T-08
T-09

Jute matting.
Coir Matting.
Mattresses/Pillows/Cushions:
(a) Rubberized Coir Mattresses, Pillows & Cushions.
(b) Latex Rubber Foam Mattresses, Pillows & Cushions.
(c) Polyurethane Mattresses, Pillows & Cushions.
(d) Cotton Mattresses, Pillows & Cushions.
(e) Rubber Sheetings.
Curtains, Tapestry Upholstery cloth.
Durries & Patties:
(a) Durries for Floors.
(b) Durries for beds.
(c) Durries Patties for Schools.

80
81
82
83

T-22
T-27
T-34
U-01
U-01(01)
U-03

84

Umbrella.
Cotton, Popline, Long Cloth & Khaddar
Terrycot Cloth.
Sports Goods & W ears
Multygym Equipment
Marble Tiles/Chips.
18

<!-- page 21 -->

TENDER FORM
Controller of Stores,
HIMACHAL PRADESH
(INSTRUCTION TO TENDERERS)

ANNEXURE II

1.
Quotations must be enclosed in a properly sealed envelope addressed to the
Controller of Stores, Himachal Pradesh by designation and not by name. The quotations
must be superscribed “quotations” for the supply of……………….. during the year ……. As
called for in the Tender Notice dated ………… The quotations must reach the Controller of
Stores Himachal Pradesh before 11.30 AM of the date mentioned in the Tender Notice.
The Tenderer is required to submit the tender application in a sealed cover containing two
separate envelopes. One envelop shall contain “Technical Bid” and second envelop shall
contain “Financial Bid”. The envelopes shall be marked as “Technical and Financial Bid”.
1.

Technical Bid Envelop:- This envelop shall contain Tender Form and terms &
conditions of the tender schedule “A” both duly signed alongwith attested copies of
required documents as mentioned in the terms and conditions, Earnest Money as
prescribed in tender schedule in the shape of FDR duly pledged in favour of the
Additional Controller of Stores, H.P., if applicable and the tender fee of Rs. 500/in the shape of Demand Draft in the name of Additional Controller of Stores,
H.P., if applicable. The Technical Bid Envelop shall be opened on the date of opening
of tender.
2. Financial Bid Envelop:- This envelop shall contain Schedule “A” of rates only.
The Financial Bid shall be opened of the technically qualified bids only. The
financial bids of technically rejected bidders shall not be opened.
2. In the event of the quotations being submitted by a firm it must be signed separately by
each member thereof, in the event of the absence of any partner, it must be signed on his
behalf by a person holding a power of Attorney authorizing him to do so or in the case of a
Company the quotations should be executed in the manner laid down in the said Company‟s
Article of Association. The signatures on the quotations should be deemed to be authorized
signatures.
3. All the columns of the quotations form shall be duly, properly and exhaustively filled in.
The rates and the units shall not be overwritten. Quotations shall always be both in figures
and words. The words “No Quotation” should be written across any or all of the items in the
schedule for which a tenderer does not wish to tender and in the case of e-tendering column
of rates should be left blank. Any omission in filling the columns of units and rates may debar
a quotation from being considered. All corrections must be signed by the tenderers.
4. Samples must be sent of all items quoted for wherever required and specifically
mentioned in Schedule-A. Such samples must be submitted and delivered in person or
through their authorized representatives to the Incharge, Sample Room of the Controller of
Stores, Himachal Pradesh situated at Bemloe, Shimla-171001. Samples should bear a

19

<!-- page 22 -->

sealed label, marked with the tenderers name and address and reference to the item no. in
schedule. All instructions regarding the samples specified in the notice should be compiled
with.All samples except those against accepted quotations must be removed by the supplier
on a date to be specified by the Controller of Stores, Himachal Pradesh failing which the
sample will become the property of the Government and no claim thereof will be considered.
Loss of samples or damage or wear and tear or injury by testing, exposure, experiment etc.
shall be no ground for compensation in any form. Similarly the successful party who is put on
rate contract shall remove their samples deposited against the rate contract after 90 days
and before 120 days of the expiry of the rate contract whereafter the same shall become the
property of the Government and will be disposed off under the orders of the Controller of
Stores, in such manner as he may decide without giving any notice to the Contractor.
5. Earnest money as specified under rule 13(i) in the shape of Bank guarantee /Fixed Deposit
Receipt (FDR) irrevokeable duly pledged in favour of the Additional Controller of Stores,
HIMACHAL P R A D E S H should be furnished with each tender. The tenderers or the firms
who have deposited permanent earnest money or registered with this Organisation as local
manufacturers need not deposit this amount and in such cases the tenderer must send
attested copy of the registration c e r t i f i c a t e . Similarly Small Scale Industrial
Units
registered with the DGS&D or NSIC are exempted from the deposit of earnest
money alongwith the tenders for such items for which they are registered with the
DGS&D or NSIC in such cases they must sent attested copy of the registration
certificate. The successful tenderer may be required to deposit in addition as security for
due performance of the contract an amount as specified under Rule 13(IV) of the
approximate value of the estimated supply. However, local units of HIMACHAL
PRADESH who possess valid registration certification of Controller of Stores/Addl. Controller
of Stores, HIMACHAL PRADESH are exempted from furnishing the security.
6. The tender must be accompanied by General Sales Tax, Central Sales Tax clearance
certificates showing the clearance of taxes upto 31st March of the preceding year. Tenderers
who enclose current registration certificate of HIMACHAL PRADESH Store Purchase
Organisation need not enclose these certificates. However, the Government of India/
Himachal Pradesh Government Undertakings and such tenderers holding current valid
registration with the DGS&D and also small scale industrial units registered with the National
Small Industries Corporation will be exempted from furnishing such clearance certificates.
Local Industrial units who attached with the tender an attested copy of the permanent
registration certificate issued by the General Manager, District Industries Centre concerned,
will also be exempted from furnishing such clearance certificates but will have to submit no
dues certificate from the concerned General Manager, DIC.
7. Prices should be firm validity of rates must not be less than 90 days where the period of
validity is specifically mentioned as 90 days or more and the tenders does not send any
intimation by a registered post after expiry of such specified period, the validity of rates shall
be deemed to have been extended till the date of issue of telegram/letter of acceptance in
favour of tenderer.
8. The Controller of Stores/Addl. Controller of Stores, HIMACHAL PRADESH reserves the
right of rejection/approval of all or any of the tender(s) without assigning any reasons thereto
and reserves the right to negotiate with any of the tenders where deemed necessary and to
award parallel rate contract to any or all of the participating tenderers.

20

<!-- page 23 -->

9. No tender will be considered unless and until all the documents are properly signed.
10. The quotation will be regarded as constituting an offer or offers open to acceptance on
whole or in part or parts at the discretion of controller of Stores, upto.......... .(date)
11. In the event of tender being accepted, the quotations will be converted into a contract
which will be governed by the conditions given in Schedule “B” (Annexed) read with these
instructions.
12. The Controller of Stores/Addl. Controller of Stores, HIMACHAL PRADESH is authorised
to debar any party or parties from future participation in the Purchase Programme of the
Stores Purchase Organisation and from having any such dealings with any Government
/Corporate body etc. in the State of Himachal Pradesh for a period not exceeding one year
from the date of issue of such orders, when such parties quote rates in respect of various
items of store for which tenders were invited by the Store Purchase Organisation and are the
lowest, but such parties decline to enter into rate contract.
13. The tenderer who wish to file appeal against the award of rate contract may do so within
30 days of the award of rate contract and the appeal shall lie to the Secretary (Ind.) or any
other authority as may be notified by the Government.
14. The rates should be quoted F.O.R destination anywhere in Himachal Pradesh unless
otherwise specifically mentioned in the Schedule “A” of the rate contract.
15. ISI marked products will be given preference. The tenderers quoting ISI marked products
shall have to attach attested copy of the valid ISI marking licence.
16. 100% payment will be made within 21 days against physical delivery of
inspected/accepted stores duly supported with satisfactory inspection note and after receipt
of correct goods at consignee‟s site/ destination.
17. Rate, specification, measurement and quantum etc. must be quoted in metric system
and filled only in the Schedule “A” and no where else.
18. W here samples are considered to be got tested, tenderers will have to furnish testing fee
on demand otherwise earnest money will be forfeited to the Government.
19. The tenderer must attach copies of their existing rate contracts, if any, with the DGS&D
or any other State Government‟s.
20. Test reports from the test houses recognised by State/Central Government must be
supplied with the tenders where-ever required as mentioned in Schedule “A”.
21. All photo copies, which are required to be attached with the tender should be got
attested from a Gazetted Officer.
22. Inspection of factory premises may be carried out by the Controller of Stores and Addl.
Controller of Stores or his authorised representative to ensure the genuineness of the firm as
well as to verify the capacity/ quality of product being manufactured by the firm.

21

<!-- page 24 -->

23. Sales Tax, Excise duty, other taxes be indicated separately otherwise rates will be
deemed to be inclusive of such levies/ taxes and no future increase in duty/taxes will be
allowed.
24. In case where it has not been specifically indicated in the Schedule “A” that only
manufacturers can participate in the tenders, in such cases the tenderers other than
manufacturers should attach authorisation letter from such principal manufacturers
alongwith the tender.
25. Price fall clause- The offer of rates by the tenderer will be subject to the price fall clause
i.e. if any item is offered at a lower rate by the tenderer at any other State/place in India, he
shall not charge higher rate for the item offered in the tender. In the event of higher rates
offered by such tenderer, the rates so offered by such party can be rejected at any stage.
26. Tenderers who do not fulfill the above mentioned requirements, their tender will be liable
for rejection.
I/W e hereby quote to supply the goods and material at the rates specified in the schedule “A”
and within the time specified as set forth in the conditions of contract given in schedule “B”.
The terms and conditions given in schedule “B” will be binding upon me/us in the event of
the acceptance of my/our tender.
I/W e herewith enclose Bank guarantee /Fixed Deposit Receipt (FDR) irrevokeable for a sum
of Rs...............as
earnest money and should I/W e fail to execute an agreement
embodying the said conditions and deposit the security as laid down, in the form within 10
days of the acceptance of my/our tender, I/we hereby agree that the above sum of earnest
money shall be forfeited to the Controller of Stores, Himachal Pradesh.

Read and accepted.

Signature of the Tenderers

22

<!-- page 25 -->

SCHEDULE „ A‟
While filling up of this schedule the tenderer ARE REQUESTED TO go through the
columns of the tender form, conditions detailed therein and the terms and conditions
of the NIT.
Tender Notice No.
Trade Group:
Code No:
Date and time of receipt
of tender.
Date and time of opening:
Price of tender set:
ANNUAL RATE CONTRACT FOR THE SUPPLY OF:
Item Code

General Descriptions /ISI Specification.

Tender Rate

Unit

Name, Address and Signature of the tenderer

23

<!-- page 26 -->

SCHEDULE „ B‟
CONDITION OF CONTRACT
This contract is to last from.........to.........but in the event of any breach of the
agreement at any time on the part of the contractor the contract may be terminated
summarily by the Controller of Stores, Himachal Pradesh........without compensation to the
contractor.
Any change in the constitution of the firm shall be notified forthwith by the contractor
in writing to the authority sanctioning the contract and such change shall not relieve any
former member of the firm from any liability under the contract.
No new partner/partners shall be accepted in to the firm by the contractor in respect
of this contract unless he/they agree to abide by all its terms, conditions and deposit with the
officer sanctioning the contract a written agreement to this effect. The contractor‟s receipt of
acknowledgment or that of any partners subsequently accepted as above shall bind all of
them and will be sufficient discharge for any of the purposes of the contract.
2. The Contractor will supply nothing but genuine articles described in column 2 of
Schedule A,of the rate contract from time to time in such quantities as may be entered in the
indents sent at the rates set forth in column 3 of Schedule A of the rate contract for use in
offices/institutions/ departments under the administrative control of Government of the
Himachal Pradesh, as may be required by the Indenting Officers. No guarantee can be given
as to the quantity which will be ordered during this period. The purchaser reserves the right
of placing orders of store items as given in Schedule “A” with one or more contractors as he
may think fit and the contractor binds himself not to revoke this contract during the said
period. The Controller of Stores/Addl. Controller of Stores, HIMACHAL PRADESH reserves
to himself the right to obtain contracted items of stores when available from any Government
department/ approved source without any pre-judice to this contract. He further reserves the
right to negotiate any of the tenderers and award parallel rate contract to any or all of the
participating tenderers.
3. The articles to be supplied under this contract will be of the quality equal and
answerable in every respect to the specifications given in the list accompanying with the
tender and approved by the Controller of Stores, Himachal Pradesh. The Contractor shall be
responsible for all complaints as regard the quality. In case any of dispute regarding quality
of articles, the decision of the Controller of Stores/Addl. Controller of Stores, Himachal
Pradesh will be final and binding on the contractor. It will be open to the Controller of
Stores/Addl. Controller of Stores, or any Indenting Officer to send samples submitted by the
tenderer/ contractor to any laboratory for chemical analysis and the cost thereof will be
borne by the tenderer/contractor.
4. The Controller of Stores/Addl. Controller of Stores, Himachal Pradesh may, by
notice in writing call upon the contractor to supply additional articles to serve as sample, and
upon receiving such notice in writing the contractor shall at his own cost be bound to supply
the additional samples, such additional samples being in all respects of the same quality as
the sample first supplied.

24

<!-- page 27 -->

5. The contractor will be responsible for damage or loss in transit and replace goods
broken or lost within 10 days from the date of notice thereof.
6. All goods must be dispatched within 45 days of the receipt of supply order by the
contractor unless otherwise specifically mentioned in Schedule “A” of rate contract.
7. Conditions as to time for performance whether laid down herein or in any indent
shall be always regarded as the essence of the contract.
8. The Controller of Stores, HIMACHAL PRADESH or the Additional Controller of
Stores or any of the experts attached to the Industries Department of HIMACHAL PRADESH
or the Indenting Officer or any other officer or person duly authorized in writing by the
Controller of Stores Himachal Pradesh shall have the power to inspect the Stores before,
during or after manufacture, collection, dispatch transit or arrival and to reject the same or
any part or portion after the written approval of the Controller of Stores, Himachal Pradesh. If
he or they be not satisfied that the same is equal or according to the samples submitted by
the contractor. The contractor shall not charge or be paid for supplies rejected as above and
such supplies shall be removed by the contractor at once and at his own expense. He shall
neither claim nor be entitled to payment for any damage that rejected supplies may suffer
from any harm whatsoever incidental to a full and proper examination and test of such
supplies. Government shall be under no liability whatever for rejected supplies and the same
will be at the contractor‟s risk. Rejected supplies shall be removed by the contractor within
10 days after notice has been issued to him of such rejection and failing such removal
rejected goods will be at contractors risk and Government may charge the contractor rent for
the space occupied by such rejected goods.
9. The contractor shall provide without any extra charge all materials, tools labour
and assistance of every kind which the aforesaid officer may consider necessary for any test
or examination which he may require to be made on the contractor‟s premises and shall pay
all cost attendants thereon. In the case of stores inspected at maker‟s premises the maker
shall provide all facilities including testing appliances, for making necessary tests other than
special test or independent tests. Failing the facilities at his own premises for making the
tests, the contractor shall bear the cost of carrying out tests elsewhere. The contractor shall
also provide and deliver free of charge at such place as the aforesaid officer may direct
such materials as he may require for tests by chemical analysis or independent testing
machine. If for the purpose of determining the quality of stores the above said officer finds it
necessary to have the stores tested at the test house or laboratory expenses incidental to
the test shall be borne by the contractor. On the failure of the contractor to pay the expenses
within ten days of the receipt of intimation in this behalf from the Inspecting Officer, the
Controller of Stores shall have the right to deduct the amount from the security deposited by
the contractor and if the amount so deducted is not deposited within 10 days, the Controller
of Stores may treat the default as a breach of the agreement and proceed under clause (i) of
the agreement without further notice. Further the aforesaid officer shall have the right to put
all articles or materials to such tests as he may think proper for the purpose of ascertaining
whether the same are in accordance with the specifications or sealed sample mentioned in
the tender and to cut out or off/or destroy a portion not exceeding 2 percent from each

25

<!-- page 28 -->

delivery for such purpose the quantity so cut out or off and/or destroyed as aforesaid shall be
replaced by the contractor free of charge.
10. Packing cases, containers, gunny packages etc. which may be used for purpose
of packing and which are delivered with stores will not be returned and paid for unless
specially stipulated and then at contractor‟s expense.
11. Unless otherwise specified in a requisition bills for the whole of the goods
referred to in each indent in triplicate will be prepared and submitted by the contractor to the
consignee for direct payment under intimation to the Controller of Stores, Himachal Pradesh
.The full amount will be paid on receipt of stores, in good condition after their verification as
regards specification etc. Should the payment of any bill be not made within three months
from the date of its submission, the party to whom the bills were forwarded should be
addressed first. Failing satisfaction the matter should be reported to the Controller of Stores,
Himachal Pradesh. All such complaints should give(i)
(ii)
(iii)
(iv)
(v)
(vi)

the number and date of the requisition.
the designation of the requisitioning officer.
the designation and address of the consignee.
the designation and address of the officer to whom the bill was sent by the
Contractor.
the number of the bill and date on which the bill was sent to the officer
mentioned in (iv) above.
Full referenced to reminders if issued.

12(i)
W ith every dispatch of goods or material under this contract invoices in triplicate will
be prepared by the contractor. Invoices in duplicate, are to be sent by the contractor to the
Indenting Officer, the duplicate to be returned by the Indenting Officer with the quantities or
number received duly noted thereon and the third copy to be sent by the contractor to the
Controller of Stores, Himachal Pradesh for record in his office.
(ii)
Railway/goods receipt where ever applicable will be forwarded to the
consignee immediately after despatch of stores. Should any demurrage charge be incurred
owing to delay on the part of the contractor in forwarding the railway receipt, the amount of
such charge will be deducted from the bill.
(iii) The Contractor shall dispatch material „Freight paid‟ in all cases where his offer is
F.O.R. destination. In the even of his failure to do so, a penalty of 5 percent will be charged
on the amount paid as freight by the Indenting Officer on his behalf.
(iv) The contractor will send to the Controller of Stores/Addl. Controller of Stores,
HIMACHAL PRADESH, quarterly statement of the goods supplied under this arrangement in
the following form which should reach before the 15th July, 15th October, 15th January
and 15th April positively:-

26

<!-- page 29 -->

Name of
Office

Indent No.

Name of
Articles

Quantity or Number
supplied and to whom
supplied and where

Value of
Supplies
Rs.

Remarks

In the event of failure to submit the said statement within 90 days of the expiry of the rate
contract the security money/earnest money deposited by the Contractors shall automatically
stand forfeited to the Government without any further notice to this effect.
(v) All dispatches by rail/road will be made at contractors risk and expense.
(vi) If, during the currency of the contract the specification of any article or articles to be
supplied thereunder a r e changed the contractor shall continue to comply with demands
for the supply of the said article/ articles in accordance with the new specifications at a rate
to be mutually agreed to in writing at the time of such change and in default of such
agreement the contract in so far as it relates to the said article or articles in respect of which
no agreement has been arrived at shall terminate but no such change shall effect the supply
of any other articles under the contract or entitle the contractor to any compensation.
13. In the event of withdrawal or discontinuance of any article or articles and
consequent ceasing of or reduction in demand the contractor shall not be entitled to any
compensation. Government will however make all reasonable endeavors to give a warning
of any impending complete withdrawal or of any reduction seriously effecting quantities likely
to be required under contract.
14. The time for and date of delivery or dispatch stipulated in the said schedule shall
be deemed to be
the essence of the contract and should the contractor fail to deliver or
dispatch any consignment within the period prescribed for such delivery or dispatch in the
said schedule then without prejudice to his rights otherwise the purchaser shall be entitled to
recover from the
contractor a sum of equal to 2 per cent of the contract price of
such consignment for each and every month or a part of a month during which the supply of
dispatch of such consignment may be in arrears or alternatively at the option of the
purchaser. The purchaser, shall be entitled to purchase such consignment (or if not available
the best and the nearest available substitute therefore) else where on the account and at the
risk of the contractor or to cancel the contract, and the contractor shall be liable for any loss
or damage which the purchaser may sustain by reason of such failure on the part of the
contractor.
15. The contractor acknowledges that he has made himself fully acquainted with all
the conditions and circumstances under which the supplies required under the contract will
have to be made or furnished and with all the terms, clauses, conditions, specifications and
other details of the contract and the contractor shall not plead ignorance of any of those as
excuse in case of complaint against or on rejection of supplies tendered by him or with a
view either to asking for enhancement of any rates agreed to in the contract or to evading
any of his obligations under the contract.

27

<!-- page 30 -->

16. No payment will be made in advance for any supplies under this contract.
17. (i) The contractor shall not:a) assign or subject the contract without written approval of the officer sanctioning the
contract.
(b) disclose details of the conditions governing this to unauthorised person (Indenting
against this contract is permissible only for the bonafide use of Government departments
and quasi-public and not for private parties or for the private use of the Government officers).
(ii) In the event of the contractor failing duly and properly to fulfill or committing
breach of any of the terms and conditions of this contract or repeatedly supplying goods
liable to rejections hereunder or failing, declining, neglecting or delaying to comply with any
demand or requisition or otherwise not executing the same in accordance with the terms of
this contract or if any contractor or his agent or servants being guilty of fraud in respect of
the contract or any other contract entered into by the contractor or any of his partners or
representatives thereof with the Government directing, giving promising or offering any
bribes, gratuity, gift, loan, perquisite, reward or advantages pecuniary or otherwise to any
person in the employment of Government if any of his partners become insolvent or apply for
relief as insolvent debtor or commence any insolvency proceeding or make any
compositions with his/their creditors or attempts to do so then without prejudice to
Government’s right and remedies otherwise Government shall be entitled to terminate this
contract forthwith and to blacklist the contractor for a period not exceeding one year from the
date of issue of such orders, and purchase or procure or arrange from Governments stocks
or otherwise at the contractor’s risk and at the absolute discretion of the Controller of Stores/
Addl. Controller of Stores, Himachal Pradesh as regard the manner, place or time of such
purchases, such supplies as have not been supplied or have been rejected under this
agreement or are required subsequently by Government there under and in cases, where
issues in replacement are made from Government’s stocks or supplies, the cost of value of
such stocks or supplies, together with all incidental charges or expenses, shall be
recoverable from the contractor on demand and the contractor shall not be entitled to benefit
from any profit which may thus accrue to Government.
18. If any question, difference or objection whatsoever shall arise in any way
connected with or arising out of this instrument or the meaning or operation of any part
thereof or the rights, duties or liabilities of either party then save in so far as the decision of
any such matter is hereinbefore provided for and has been so decided, every such matter
including whether its decision has been otherwise provided for and or whether it has finally
decided accordingly or whether the contract should be terminated or has been rightly
terminated in whole or part and as regards the rights and obligations of the parties as the
result of such termination shall be referred for arbitration to any officer appointed by
Himachal Pradesh Government acting as such at the time of reference and his decision shall
be final and binding and where the matter involves a claim the amount if any awarded in
such arbitration shall be recoverable in respect of the matter so referred.
19. If the price of a contracted article is controlled by Government, the payment will in
no case be made at higher rate than the controlled rate.

28

<!-- page 31 -->

20 (i):The price charged for the stores supplied under the contract by the contractors
shall in no case exceeds the lowest price at which the contractor sells the stores or offers to
sell stores of identical description to any person/organizations including the purchaser or any
department of the Central/State Government or any statutory undertakings of the Central or
State Government, as the case may be during the period till performance of all supply orders
placed during the currency of the rate contract is completed.
(ii) If at any time, during the said period the contractor reduces the sale price or sells
or offer to sell such stores to any person/organization including the purchaser or any
department of Central/State Government or any statutory Undertaking of the Central or State
Government as the case may be at a price lower than the price chargeable under the
contract, he shall forthwith notify such reductions or sale or offer of sale to the Controller of
Stores/ Addl. Controller of Stores, HIMACHAL PRADESH and the price payable under the
contract for the store supplied after the date of coming into force of such reductions of sales
or offer of sale shall stand correspondingly reduced. The above stipulation will however, not
apply to:
(a)
Export by the Contractor.
(b)
Sale of goods such as drugs which have expired dates.
(iii) The Contractor shall furnish the following certificate to the concerned purchasing
departments‟ alongwith each bill for payment for supplies made against the rate contract:“I/W e certify that there has been no reduction in sale price of the stores of description
identical to the stores supplied to the Government under the contract herein and such stores
have not been offered/sold by me/ us to any person/ organization including the purchaser or
any department of Central Government /State Government or any statutory undertaking of
the Central or State Government as the case may be upto the date of bill/ the date of
completion of supplies against all supply/ orders placed during the currency of the rate
contract at a price lower than the price charged to the Government under the contract except
for quantity of stores mentioned in sub clauses(a) and (b) of sub para (ii) of para-20 of the
Schedule “B”.
21. All disputes shall be settled within the jurisdiction of the High Court of Himachal
Pradesh.
22. The earnest money/ security money shall be addressed to the Addl. Controller of
Stores, Himachal Pradesh in the shape of Bank guarantee /Fixed Deposit Receipt (FDR) issued
by any Nationalized Bank.
WARRANTY CLAUSE:
The contractor/seller hereby declare that the goods/ stores/articles sold to the buyer
under the contract shall be of the best quality and workmanship and shall be strictly in
accordance with the specifications and particulars contained/ mentioned in the Schedule “A”
of
the rate contract
and the contractor/seller
hereby guarantee
that the said
goods/stores/articles would continue to conform to the description and quality aforesaid for a
period of....days/months from the date of delivery of the said goods/stores/articles to the
purchaser and that notwithstanding the fact that the purchaser (Inspector) may have
inspected and/or approved the goods/stores/ articles, if during the aforesaid period
of....days/ months the said goods/stores/ articles be discovered not to conform to the

29

<!-- page 32 -->

description and quality or have deteriorated (and the decision of the purchaser in that behalf
will be final and conclusive) the purchaser will be entitled to reject the said goods/stores/
articles or such portion thereof as may be discovered not to conform to the said description
and quality. On such rejection the goods/ stores/articles will be at the seller‟s risk and all the
provisions herein contained relating to rejection of goods, etc., shall apply. The
contractor/seller shall, if so called upon to do, replace the goods etc. or such portion thereof
as is rejected by the purchaser such damages as may arise by reason of the breach of the
condition herein contained. Nothing herein contained shall prejudice any other right of the
purchaser in that behalf under this contract or otherwise.
In witness thereof the parties have hereinto set their hands on the dates indicated
below:1. (In the case of Firm)
Signed by the above named firm of through partner of the firm.
Date

Signature

2. (In the case of a company)
The seal of the...........................Company Limited, was affixed by virtue of the
resolution of the Board No.........date..........the............day of..........20.

Dated

Director‟s Signatures

Seal
Dated

Secretary‟ signature

(in either case)
in the presence of(i) Signature Address Description
(ii) Signature Address Description
Signed by...........
Dated......
Signature of......................
on behalf of the Government of
Himachal Pradesh.

30

<!-- page 33 -->

ANNEXURE-III
APPLICATION FOR REGISTRATION AS APPROVED CONTRACTORS OF STORES
DEPARTMENT, HIMACHAL PRADESH.
1. Name of the firm.........
2. Address.......
3. Head Office......... Branch
Office........... Telegraphic
Address.....Tel. No.
4. Is the firm/factory registered under:(a) The Companies Act, 1956 or Factories Act.
(b) The Indian partnership Act, 1932.
(c) If not, who are the owners.
Please give full address of all partners in the case of firm and extent of share held
by each.....
Are you a manufacturer.........if so please give:(i) Details of Stores manufactured, specifying each item........
(ii) Full address of factory owned by you...........
(iii) Small scale Industries, registration number........
5. Are you a manufacturers agent, If so, please state:
(i) Name and address of each manufacturer.........
(ii) Store manufactured by each....
(iii) Do you hold the sole agency or you only stock goods?
(iv) Do you also stock other goods? If so, please give details with address..........
6. Please give name and address of your bankers.....
7. Are you on the list of approved contractors of any other authority if so, please
give details......
8. Have you executed any contract in the past? If so, please give details..............
9. Did you apply for registration with this department before? If so, with what
result..........
10. Give details of any contracts executed during the last six months for any
Government Department......
11. Your VAT Registration No. and the District in which it is registered
12. CST Registration No. and the District in which it is registered
DECLARATION TO BE MADE BY THE APPLICANT
I/we hereby declare that the above entries made by me/us on this day of.......are
true to the best of my/our knowledge.

Signature of applicant
1. W itness......
Address.....
2. W itness......
Address.......

31

<!-- page 34 -->

ANNEXURE-IV
POWERS OF LOCAL PURCHASES UNDER RULE 20.
1.

2.

Administrative
Deptt
(except Public works
Deptt.)
Heads of Deptt.

3.
4.

Controlling officers
Head of Office.

5.
6.

Chief Engineers
Superintending
Engineers
Executive Engineers

7.
8.

Assistant Engineers/
Sub-Divisional Officer.

Rs.5,00,000/- in each case.

Rs.2,00,000/- for each item in a financial year in respect of
each Head of office.
Rs.1,00,000/- for each item in a financial year.
Rs.3,000/- for each item provided the value does not
exceed Rs.50,000/- in a financial year.
Rs.3,00,000/- for each item without any limit.
Rs.2,00,000/- for each item in a financial year subject to
the condition that it does not exceed Rs.10 lakh.
Rs.15,000/- for each item in a financial year subject to the
condition that it does not exceed Rs.50,000/-.
Rs.3000/-for each item in a financial year subject to the
condition that it does not exceed Rs.50,000/-

32

<!-- page 35 -->

SCHEDULE - “C”
CONDITIONS OF RATE CONTRACT
1. Under the contract indents/Supply orders should reach the contractor by the last
date of the validity of the contract. The supplies will have to be made within the specified
time against the indents/supply orders under this contract upto the last date of the validity
according to the terms and conditions of the agreement under the contract. Even if in certain
cases the supplies cannot be arranged upto the last date of the validity period of the same
will have to be made.
No action will be required on the indent/supply orders which are received after the
last date of the period of contract. Such indents/supply orders will have to be returned to the
concerned Demanding Officer with a note that no supply can be made as the period of rate
contract has expired.
2. As mentioned in Schedule “A”.
3. The goods will be inspected by the consignee before dispatch at the specified
place duly authorized in writing by the Controller of Stores/ Addl. Controller of Stores,
Himachal Pradesh Supply orders can be placed by any Demanding Officer of the Himachal
Pradesh Government under this contract. The Controller of Stores, Himachal Pradesh or the
Addl. Controller of Stores, or any of the experts attached to the Industries Department of
Himachal Pradesh or the Indenting Officer, or any other officer or person shall have the
power to inspect the stores, before, during or after manufacture collection, dispatch, transit
or arrival and to reject the same or any part or portion. If he or they be not satisfied that the
same is equal or according to the sample submitted by the contractor can reject the same.
The contractor shall not charge or be paid for supplies rejected as above and such supplies
shall be removed by the Contractor at once and at his expense. He shall neither claim nor be
entitled to any payment for any damage that the rejected supplies may suffer from due to
any harm whatsoever incidental to a full and proper examination and test of such supplies.
The Government shall be under no liability whatsoever for rejected supplies and the same
will be at the contractor‟s risk. Rejected supplies shall be removed by the contractor within
10 days after notice has been issued to him of such rejection, and failing such removal
rejected goods will be at contractor‟s risk and Government may charge the contractor rent
for the space occupied by such rejected goods.
4. The contractor shall provide without any extra charge all materials, tools, labour
and assistance of every kind which the aforesaid officer may consider necessary for any test
or examination which he may require to be made on the contractor‟s premises and shall pay
all cost attendant thereon. In the case of stores inspected at maker‟s premises the maker
shall provide all facilities including testing appliances, for making necessary tests other than
special test or independent tests. Failing to provide such facilities at his own premises for
making the tests, the contractor shall bear the cost of carrying out tests elsewhere. The
contractor shall also provide and deliver free of charge at such place as the aforesaid officer
may direct such materials as he may require for tests by chemical analysis or independent
testing machine. If for the purpose of determining the quality of stores, the aforesaid officers
finds it necessary to have the stores tested at the test house or laboratory, expenses

33

<!-- page 36 -->

incidental to the tests shall be borne by the contractor. On the failure of the contractor to pay
the expenses within ten days of the receipt of intimation in this behalf from the Inspecting
Officer, the Controller of Stores/ Addl. Controller of Stores, shall have the right to deduct the
amount from the security deposited by the contractor and if the amount so deducted is not
deposited within 10 days, the Controller of Stores/ Addl. Controller of Stores, may treat their
default as a breach of the agreement and proceed under clause-1 of the agreement without
further notice. Further, the aforesaid officer shall have the right to put all articles of materials
to such tests as he may think proper for the purpose of ascertaining whether the same are in
accordance with the specification of sealed sample mentioned in the tender and to cut out or
off/or destroy a portion not exceeding 2 percent from each delivery for such purpose the
quantity so cut out or off /or destroyed as aforesaid shall be replaced by the c o nt r a ct or
free of charge.
5.Price fall clause- The offer of rates by the tenderer will be subject to the price fall
clause i.e. if any item is offered at a lower rate by the contractor at any other State/place in
India, he shall not charge higher rate for the item offered in the tender. In the event of higher
rates offered by such tenderer, the rates so offered by such party can be rejected at any
stage.
The Contractor shall furnish the following certificate to the concerned purchasing
departments alongwith each bill for payment for supplies made against the rate contract:“I/W e certify that there has been no reduction in sale price of the stores of description
identical to the stores supplied to the Government under the contract herein and such stores
have not been offered/sold by me/ us to any person/ organization including the purchaser or
any department of Central Government or any Department of State Government or any
statutory undertaking of the Central or State Government as the case may be upto the date
of bill/ the date of completion of supplies against all supply/ orders placed during the
currency of the rate contract at a price lower than the price charged to the Government
under the contract except for quantity of stores categories under sub clause(a) and (b) of
sub para (ii) of para-20 of Schedule “B”.
6. All goods must be dispatched within 45 days of the receipt of supply order by the
contractor unless otherwise specifically mentioned in Schedule “A” of the Rate Contract.
7. 100% payment will be made within 21 days against physical delivery of
inspected/accepted stores duly supported with satisfactory inspection note and after receipt
of correct goods at consignee‟s site/ destination.
8. (i) W ith every dispatch of goods or material under this contract, invoices, in
triplicate, will be prepared by the contractor, invoices in duplicate, are to be sent by the
contractor to the Indenting Officer. The duplicate be returned by the Indenting Officer with
the quantities or number received duly noted thereon and the third copy to be sent by the
contractor to the Controller of Stores/ Addl. Controller of Stores, Himachal Pradesh, for
record in his office.
(ii) Railway/Goods Receipt wherever applicable will be forwarded to the consignee
immediately after dispatch of stores. Should any demurrage charge be incurred owing to

34

<!-- page 37 -->

delay on the part of the contractor in forwarding the Railway/goods receipt as the case may
be, the amount of such charge will be deducted from the bill.
(iii) The contractor shall dispatch material “Freight - paid” in all cases where his offer
is F.O.R. destination in the event of his failure to do so, a penalty of 5 percent will be
charged on the amount paid as freight by the Indenting Officer on his behalf.
(iv) All dispatches by rail/road will be made at contractor‟s risk.
9. No guarantee can be given as to the quantity which will be ordered during this
period. But the purchaser undertakes to order from the contractor all stores as detailed in
Schedule “A” which he requires to purchase, except that he reserves the right of placing the
contract with one or more contractors as he may think fit and the contractor binds himself not
to revoke this contract during the said period.
10. W hile placing orders preference shall be given to local manufacturers and atleast
25% of the total orders shall be placed with them on the lowest approved rates provided
such products meet the required quality standards. The minimum purchase from local
manufactures shall not be applicable in respect of items which in the opinion of the Head of
Department is an item of sophisticated nature and high technology and precision standards.
If it is not possible to purchase atleast 25% from the local manufacturers, the HOD‟s for
reasons to be recorded in writing may purchase from other firms on rate contract.
11. The rates should be quoted F.O.R. destination any where in Himachal Pradesh
unless otherwise specifically mentioned in the Schedule “A” of rate contract.
12. The contractor will be responsible for damage or loss in transit and replace goods
broken or lost within 10 days from the date of notice thereof.
13. Refund of the amount of security and earnest money deposited by the firm will be
made after three months from the date of expiry of the contract or after the date of
satisfactory completion of the given supply orders, keeping in view both these conditions
while making applications for refund of the amount of security, the concerned firm will have
to furnish a certificate that the supply of all the supply order received by it, have been made
to the consignee according to the prescribed specifications to their entire satisfaction.
14. All disputes shall be settled within the jurisdiction of the High Court of Himachal
Pradesh.
Sd/Addl. Controller of Stores
Himachal Pradesh,
for and on behalf of
Governor of Himachal Pradesh.

35

<!-- page 38 -->

ANNEXURE –“V”
LIST OF ITEMS TAKEN OUT FROM THE PURVIEW OF
STORE PURCHASE ORGANISATION
S.No.
1
2
3
4
5
6
7
8

Code
C-03
C-04
C-05
C-06
C-07
C-08
C-09
C-10

9
10
11
12
13
14
15
16
17
18

C-11
C-12
C-13
C-14
C-15
C-16
C-17
C-18
C-19
C-21

19
20
21
22
23
24
25
26
27
28
29
30

C-22
C-23
C-24
C-27
C-28
C-30
C-31
C-32
C-34
C-35
C-36
C-37

31
32

C-38
C-41

Name of Items.
Explosives
English Medicines(Tablets)
English Medicines (Injectable/Eye & Ear Drops).
English Medicines (Capsules).
English Medicines (Ointments/Creams).
English Medicines (Syrup/Mixtures).
English Medicines (Powders).
Cases for Medical purpose:
(a) Oxygen I.P.
(b) Nitrous Oxide I.P.
Ayurvedic Medicines.
Ayurvedic Raw Herbs.
Veterinary Medicines (Injectable/Ear & Eye drops).
Veterinary Medicines (Capsules).
Veterinary Medicines (Ointment/Creams).
Veterinary Medicines (Syrups/Mixtures).
Veterinary Medicines (Powder/Vegetable Products).
Allopathic Kits.
Ayurvedic Kits.
Pesticides/Insecticides:
(a) Insecticides/ Fungicides/ Harbicides / W eedicides/ Pesticides/
Agrochemical
(b) Organic Based Pesticides.
(c) Fungicides.
Microneutriants.
Stickers.
Tree Spray Oils.
Coal, Coke & Firewood.
Chlorinators.
Retreading/Recapping/Resoling of old tyres .
Polythene films and canal lining.
Polythene Bags (L.D.P.E. Bags).
L.D.P.E. Pipes.
Laboratory Appliances.
Thermometer.
(a) Hospital Instruments/Equipments/Incinerator/Appliances.
(b) Dental Material, Instruments & Appliances.
(c) Dental Unit with Chair.
Dairy & Poultry Equipments.
(a) Plastic Charts.
(b) Soil Testing kits.

36

<!-- page 39 -->

33
34
35
36
37
38

C-42
C-43
C-44
C-45
C-46
E-01

39
40

E-02
E-03

41

E-04

42

E-06

43
44

E-07
E-11

45

E-13

Rubber Tubing & Rubber Water Hung Pipes.
Veterinary Equipments& Medicines Kits.
Veterinary 1st Aid Kit/Veterinary Instruments/Equipments.
Medical Instruments/Appliances etc. (Ayurvedic).
Bitumen emulsion for Road (Cationic Type) to IS: 8887/95(First Revision).
Automobile Electrical Equipments:
(a) Automobile Electric horns & their spares.
(b) Auto relays.
(c) Auto Coils.
(d) Terminal Connectors.
(e) Auto cables & W ires.
(f) Generator (dynamo).
(g) Regulator.
(h) Auto Switcher.
(i) Auto Lights.
(j) Electrical W ind Screen system.
(k) Auto lamps.
Batteries for motor vehicles
Cinematographic projection Equipments.
(a) Motion picture projectors.
(b) Overhead projectors.
(c) Slide projectors.
(d) Film cum slide projectors.
Photographic Equipments:
a) Cameras.
b) Flash lights.
c) Studio Lights.
d) Photo films.
Electrical Appliances:
(i) Laboratory Electrical Appliances:
(a) Electric Furnaces.
(b) Electric Ovens.
(c) Electric baths.
(d) Centrifuge.
(e) Autoclaves.
(f) W ater stills.
(g) Distillation & Digestion units.
(h) V.D.R.I. Rotators.
(i) Shaking machine Kahn's.
Electrical Emergency Lights
Electrical Instruments & Integrated meters:
(a) Ph. meters.
(b) Colorimeters.
Sound Recording and Reproducing Equipments.
(a) Public address system.
(b) Amplifier.
(c) Microphones.

37

<!-- page 40 -->

46

E-15

47

E-16
(i)

(ii)

(iii)

48
49

E-19
E-20

50

E-21

(d) Microphone Stands.
(e) Sound columns
(f) Reflex horns.
(g) Loud Speakers.
(h) Conference system.
Voltage correcting/ Regulating devices:
a)Automatic Voltage Stabilizer.
b)Manual Voltage Stabilizer
Electromedico Equipments:
Diagnostic dedical X-Ray Equipments:
(a) X-Ray units/machines.
(b) M.M.R. Cameras.
X-Ray Equipments & Accessories:
(a) Developing tanks.
(b) X-Ray Cassettes.
(c) Intensifying Screens.
(d) Developing hangers.
(e) Half film blockers.
(f) Dark room safe light.
(g) VCT Unit.
(h) X-Ray Lead rubber protecting apprens.
(i) Load rubber gloves.
(j) Lead goggles.
(k) Lead screens.
(l) Lead figures.
(m) Lead letters.
(n) X-Ray viewing box.
(a) Electro cardiogram.
(b) Radio frequency diathermy apparatus.
(c) Leproscopy system.
(d) Suction machine.
(e) Operation theater lights & fittings.
(f) Sterilizers.
(g) Autoclaves.
Electronic/Quartz Clocks.
Intercommunication system:
(a) Intercoms.
(b) Telephones peripherals.
Electronic Audio & Video Equipments:
(a) Transistorised Radios.
(b) Tape recorders.
(c) Record Players.
(d) Two-in-one.
(e) Stereo system of records.
(f) Cassettes Recorders deck system.
(g) Audio Cassettes.
(h) Video Cassettes.

38

<!-- page 41 -->

51

E-22

52
53
54
55
56
57

E-23
E-24
E-25
M-05
M-06
M-09

58
59
60
61
62
63
64
65
66
67

M-10
M-12
M-13
M-17
M-18
M-20
M-22
M-23
M-24
M-26

68
69
70
71
72
73
74
75

M-31
M-32
M-33
M-34
M-35
M-36
M-37
M-40

76

M-41

77
78
79
80

M-42
M-46
M-47
M-48

(i) Black & W hite Televisions.
(j) Colour Televisions.
(k) Video Cassette Recorder/Player.
Electronic Equipments/systems for use in office.
(a) Computer & its peripherals.
(b) Calculators.
(c) Electronic Typewriters.
(d) Photostat machine/photo coppier.
(e) Past Repller.
Fax Machine (Photo copies).
Earth leakage Circuit Breakers/High Frequency Electric chocks/blast.
E.P.A.B.X. Machine (E.P.A.B.X. System).
Steel W ire Ropes
Knitting Machines
Asbestos Cement Pressure Pipes and Couplings (AC Pressure Pipes and
coupling
G.I. Pipes (Galvanised Iron Pipes).
Cast Iron Pipes (C.I. Pipes).
Aluminum Irrigation Pipes with fittings and sprinkler equipment.
Pig Lead (Soft)
Water Meters
Hydrams.
Mild Steel bolted tanks (MS Tanks).
Pressed Steel Tanks (P.S. Tanks).
G.I. Sheet Tanks (Galvanised Iron Sheet).
Plant/Crops Protection Equipments:
(a) Power sprayers for plant/crop protection.
(b) Foot sprayers and accessories for plant/crops protection.
(c) Knap sacks sprayers and accessories for plant/crops protection.
(d) Hand operated sprayers for plant/crops protection.
Road and Forest Machinery.
ITI/Polytechnics tools/Equipments.
Polytechnic/ITI Machineries.
Pneumatic Drill Roads
Drill Rods with coupling and accessories.
Pneumatic Tool hose with clamps and couplings
Immersion Vibrators and Exploders.
W eight and Measures.
(a) Machinery.
(b) Instruments/Equipments.
Metrological Instruments.
a) Rain Gauge.
b)Snow Gauge
Locks
Plastic Moulded Furniture
Hospital Asceptic Steel Furniture.
Road Brushes

39

<!-- page 42 -->

81
82
83

M-50
M-51
M-52

Tins/Tins Cans.
Auto Leaf and Leaf springs.
Conversion of M.S. Billets into :a) MS Rounds.
b) Tor Steel.
c) Rabbed steel.
d) Angle Iron.
e) Channels.
f) Flats. g) Joists.
h) Plates.

84

M-53

85
86

M-54
M-55

87
88
89
90
91

M-56
M-57
M-60
M-62
M-63

92
93

M-64
M-66

94
95
96
97
98
99
100
101
102

M-67
M-68
M-69
M-70
M-72
M-74
M-75
M-76
M-77

103

M-80

Conversion of MS Coil into:a) G.I. Wire.
b) Barbed Wire
c) U-Stepples.
Bee hives and Bee Keeping accessories.
Seed Testing Laboratory:
(a) Machinery.
(b) Equipments.
Mono Metal.
AC Sheets for roofing.
Plywood.
Boat and Boats Appliances.
Horticulture Tools Equipments and Accessories:
(a) Sceatrues of standard sizes.
(b) Grafting/Prunning Knives with Blade and Handles.
(c) Budding Knives.
(d) Prunning Saws.
(e) Prunning-cum-Plucking Ladders.
Machinery Tools Equipments& in Fruit Canning Units.
Veterinary Equipments/Accessories:
(a) Horizontal Liquid Nitrogen Tank.
(b) Liquid Nitrogen Storage Tank.
(c) Semen Pressing & Sealing Container.
(d) Auto Fillings & Sealing Machine for Straw.
(e) Auto Printing and Machine for Straw.
(f) Phase Contrast Microscope.
Photo Cabinets.
Driving Licence System.
Malaria Pumps
Medical Gas Cylinder.
Bio-gas Double Burner Chullah/Stove.
Spare Parts for Strrup Pump.
Fibre Class Sheet.
Telescopic Type Hydraulic shock observers for Automotive Suspension.
(a) Fabrication of Gypsy Body.
(b) Fabrication of Mahindra & Mahindra Jeep.
(c) Fabrication of Bodies for Light Vehicles.
Flush Door Shutters.

40

<!-- page 43 -->

104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129

M-81
M-82
M-85
M-86
M-87
M-89
M-90
M-91
M-92
M-93
M-94
M-95
M-96
M-97
M-98
M-100
M-101
M-102
M-106
M-107
M-108
M-109
M-110
M-111
M-112
M-113

130

T-01

131
132
133
134

T-10
T-11
T-12
T-13

135
136
137
138
139
140
141
142

T-14
T-15
T-16
T-17
T-18
T-19
T-20
T-21

Rigid P.V.C. Pipes for irrigation and Sewerage.
Air Spray Vacuum Cleaner.
H.D.P.E. Sprinkler (ISI Marked).
Solar W ater Heaters/Solar Cookers.
G.I. Sheet Drum.
Self Prining & Submercible Pump & Contrifugal Pump
Red Mud Plaster.
Intensifying Compound, Mortar Mud Plaster and Chunik.
Main hole Covers.
RCC Fencing Poles.
Portable Smokeless Chullah & Chimneys.
File Racks.
Rubber Moulded Items.
Explosive Materials.
Drip Irrigation System.
Welding Electrodes
Bottle Caps.
Machinery & Equipments for preparation of Ayurvedic Medicines.
Ballot Box
Cement W ater Tanks
Paint of Steel Almirah (Job work).
Soil Testing Kits.
Electric Drilling Machine
Mini Liquid Nitrogen Plant.
Mini Foundries for indoor and outdoor Decorations.
Gasket shellac compound (adhesive) 50ml & 100ml packings. Emery
papers, Emery cloth, Rexene cloth and Auto Elect low tension wire.
W oollen Blankets:
(a) Hospital Blankets.
(b) Barrack Blankets.
(c) Blankets for Rest Houses/Circuit Houses.
Tents, Shamianas & Kanats.
Tarpaulins.
Towels & Dusters.
Garments:a) W oollen Garments.
b) Cotton Garments.
Jerseys & Socks.
Pagree Cloth.
Mazri Cloth, Cotton & Cotton Buckrum.
Drill Cloth.
Cellular Cloth.
Cotton Niwar/Nylon Niwar.
Uniform Equipments.
(a) Canvas Cotton.
(b) Ground Sheet s.
(c) Hood Cloth.

41

<!-- page 44 -->

143

T-23

144

T-24

145

T-25

146

T-26

147

T-28

148
149

T-29
T-30

150
151
152
153
154

T-31
T-32
T-33
T-35
T-36

155

T-37

156
157
158
159
160
161
162

T-38
T-39
T-40
T-41
T-42
T-43
T-44

Coats:
(a) Rain Coats.
(b) Parkha Coats.
(c) Short Coats.
Ropes and Cordages:
a) Manila Ropes.
b) Sisal Ropes.
c) Jute Ropes.
d) Coir Ropes.
Yarns:
a) Jute Twins.
b) Coir Twins.
c) Jute Spun Yarns.
d) Hemp Spun Yarns.
Textile waste:
a) Cotton Yarn W aste.
b) Old Dhoties.
c) Terring Outfits.
Bags and Sacks:
a) Gunny Bags.
b) Craft Pater Bags.
c) Potato Bags.
d) Fertilizer Bags.
e) HDPE Sacks/Bags.
Hessian Cloth.
Textile Nettings:
a) Mosquito Nets.
(b) Nylon Anti Hailing Nettings.
(c) Swarm Catching Nets & Baskets.
W oollen serge.
W oollen Great Coat Cloth/Drab Mixture Cloth W oollen.
Angola & Berthia cloth.
Mountaineering Equipments.
Footwears:a) Leather Footwears.
b) Rubber Footwears.
c) Canvas Footwears.
Traveling Equipments:a) Brief Cases.
b) Holdols.
c) Suit Cases.
Surgical Dressings.
W ool Cotton observant & Non observant.
Coated Cloth (Fabrics).
Flexible Floor Covering (PVC)
Rubber Tubing & Rubber Water Hose Pipes.
Denim Cloth.
Basta cloth, Latha cloth, Mussavis, Laminating rolls.

42

<!-- page 45 -->

163
164

T-45
U-02

165

U-04

166
167

U-05
U-06

168
169
170

U-07
U-08
U-09

171
172
173
174

U-10
U-11
U-12
U-13

W oollen yarn, cotton yarn.
Blood Bank Equipment
(a) Pressure Cooker.
Laboratory Appliances:a) Laboratory Glasswares
b)Hospital Laboratory Appliances:
c) School College Laboratory Appliances.
01) Laboratory Glasswares.
02) Bottle& Closers.
03) Laboratory Equipments (Physics).
04) Laboratory Equipments(Chemistry)
05) Laboratory Equipments (Biological /Botany).
Integrated Science Kit.
Maps & Charts (Teaching & Learning Materials):
(a) Maps, Educational Charts, Globes.
(b) Science Kits, Mini Tool Kit & Mathematics Kit.
(c) Playing Articles, Toys, Puzzle, W isdom Block.
(d) Musical Instruments.
Cans, Bottles, Jars for packing of Fruits products.
Plastic Buckets.
Equipments for repair & Maintenance of Electrical Domestic Appliances
Commercial Garments Designing & Tool Equipments for Trainees.
W ater Testing Kits/ Horrocks Appliances.
Electrical Equipments/Appliances.
Fish feed ingredients, Hatchery/farm/fishing Equipments.
Hydrometer, Revenue locks, Bung rode, testing glasses, dipp rods,
Thermometer, saccharmeter, floats rods, gauging rods.

43
