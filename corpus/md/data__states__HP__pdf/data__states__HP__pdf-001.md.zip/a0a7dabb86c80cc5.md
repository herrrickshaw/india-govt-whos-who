---
doc_id: "a0a7dabb86c80cc5"
source_url: "https://www.hp.gov.in/hpdmer/file.axd?file=2026%2f4%2fAppointment+order+of+Sr.+Resident+-Tutor+Specialist+-in+all+the+Govt.+Medical+Colleges-AIMSS+Chamiana2026.PDF"
ministry: "Directorate of Medical Education & Research, Himachal Pradesh"
title: "Appointment order of Sr. Resident -Tutor Specialist -in all the Govt. Medical Colleges-AIMSS Chamiana"
date: ""
pages: 10
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "18708b4a9dbc17cc"
---

<!-- page 1 -->

I

Directorate ofMedic.l Eddc,tion & Research
Hima.hal Ptadesh, Shinla _9

:'

t '

HtaBdr'l| a-J71oN

No. HFW (DME) B (2)- 163/2019-V-XVII
' OFfiCE ORDEB'

On thc basis of recotumendalions of the Counselling
( omrrl_ee (\r. Re.idenL{Lror SPe-iajnrr dd a' per aPprdal 'onve)co fe Go\4
I lo' inS
,'a" r"u* N"r+n-e_eOb.l '0)r_llerlr\_B ddLed 2'0d '02o Ihe
lLrnr \oe idl I
-ndior. ., l rO D e!r, re ||( 'b) rl f" r'red "I Sr nF o r'
'er'oJ "iru. :e.r n rrrr
c. \4ed:.Jl r'ol. e, \lv\s.

Name of Medical College/

SrN

AIMSS, Chamiana in

GDO/
which Direcl

D€Partmei

Df. caurav

z

Kumd

Dr Di!\a Rana

l

Dr. Uria Bali

4

Di. Tanu Priya Kaushal
Dr. Supdra

I

D.. RPCMC. Tanda
IGMC, Shimla
Pl. JLNGMC, Chamba

CDO
CDO

GDO

cDo

1

Dr Abhindy Chau|an

8

9

Dr. Ankush BhaSta
Dr. P.iyanka

IGMC, Shimla
SLBSGMC, Mandr
Dr. RPGMC, Tuda
SLBSGMC. Mandi
IGMC, Shimla
Dr. RKGMC,Hamirpur

l0

Dr. Neha Bab'rdur

Dr. YSPGMC,Nahan

t1

Dr. GudinderK,ur

5
6

l2

ll
l4
15

19

20

2l

Df. YSPGMC,Nahm
DePar tment of ImcreencY Medicine
Dr. RPGMC, Tanda.
Dr. Marinder Singh
SLBSGMC. Mandi at Nerchowk
Dr. RPGMC, Tmda
Dr. Lalesh Saphia
Dr. RPGMC, Tmda
Dr. Nmdini Sharma
Dr. RKGMC, Hamirpur
Dr. Pankit Shek]ld
Dhimm
Dr.
I Dr. YSPGMC, Nahan
LDf. RPGMC, Tmda
eoftDent of BiochemisirY
Dr RPGl,rC, Tanda
DeDarinent of CommunitY M€dicD!
Dr. RKGMC,Ilamirpur
Dr. Parul Sethi
IGMC, Shimla

Dned

cDo
GDO
GDO
GDO
GDO
GDO

tcDo
GDO
GDO
GDO
GDO
CDO

cDo
UDO

cDo
GDO

<!-- page 2 -->

t'!"i" -or tlt"ai"ut Cott"g"l GDO/
AIMSS, Cbaniana in rvhich Direct
o".-"rq!sg'\rya&s q !!rro'
o**G"-"r
"r
IGMC, Shimla

Dr. Abhina\ Chasata

zl lor. upasaa chauhll

Dneci
GDO

SLBSGMC, Mmdi

-ooo
cDo
26

i-,

cnt,'tfnrlocrinoloE).
^r[r{( ahrmixna ShtmlJ

-L--i::

2l

Dr. Anran Shma

28
29

Dr. Priya Kumtr'
Dr. Josinde

t;;-cDo

Dr. RPGMC,Tanda

DeDrrt netrtof Gerertl M€dicine

Hamimxr

Dr. RKGMC,
IGMC, Shnnh

1

GDO

Sinsh
Pul!4q _ _ ,1
rtment o{ so.qery
1

l0
3t
32

IGMC,

Dr. Rohii Negi
Dr.

Shimla

DT.RPGMC,T+44 .

I

GDO

A!v!!.!lt4!r!!4irllql!- GDO
Dr-q!a!!q!Ic-Inent
of Paediatijcs Surse4
DeParri

33
34

l5
36

lAIMSS, chamiana
-ucpari :ment
ofBlood Bank
Dr. Aishsarya sh4lrlla - lAIMSS, Chamiana
Mi.rotriolosv

rffi
"3l-ffi;,"m"oi"r*

'-""i "f

D. Pm!lIg!4!!L Dr. RPGMC,Tanda

l8

Dr. Meenakshi Thakur

12
13
45

D partment ol

i-''Drl!Ernilq

lcDo

lcDo
GDO

l1
39
40

GDO

Dr. Anshu Attfl

un('

n. aPGMa T.nda
n. pl.;Mr- Hamimur

Dr. Tenzindsomo Tenga PIJLNGMC, Chamba
DeDtr lmepf of ODhthalmology
Dr. Arushi Rattan
LrGMc, shimla
pr. RPGMC, Tmda
I
Dr. Sejal Karoch
Dr. Navneetjlg!4- Dr. RPCMC, Tdda
Dr- YSPGMC, Nahd
Dr. Prithai
I Df. YsPGMc. Nahan
Dr. Deeksha Dogra

-GDO
CDO
I

GDO
GDC)

GDO
GDO
GDO

l

<!-- page 3 -->

Nane of M€di@l College/ GDO/

Sr. l\

AIMSS, Chrmirna in wbich Direct
DeDr rtmcn t of O rthop.edics

)t

Dr Kru'l\a
l)L Ri.lEbh Cupra
Df DixilCautaD

Dr RPCMC. Tanda
lCNlC, Sl ml.r
Dr R(C\IC. HJmirpur

Dr. Sudhir Kunar

D YslC\lC NihJn
SIBSGMC,MMdi

52

Dr Rahul

Dr. RKGMC, Ham'rpur
SLBSGMC. Mandi

51

Dr. Diksha Thakur
Dr. Shivani Thakur

50

5t

55

56
57
58
59
60

6l
62

6l
65
66
67

AIMSS, Chamiana Shinla
AIMSS, Chamiana, Shimla
Otorhinolaryneolosy ENT
Dr. Priyanka Bhatia
IGMC, Shimla
Der artmetrt ofPaediatrics
Dr. Shikla Shamr
Dr. RPGMC, Tanda
Dr Anui Guler a
Dr. RPGMC, Tanda
Dr. Subhi Bhani
Dr RPGMC;Tmda
ICMC, Shimla
Dr. Swari Chandel
SLBSGMC, Mddi
ICMC, Shimla
De,rarrment otPatholoqy
Dr. Pranav
D,. RKCMC,Ildirpur
Dr. Abhishek Ddoach
IGMC. Shimla
Dr RXGMC, Hmirpur
Dr RPCMC, Tanda
Dr. Shrlera Khinder
SLBSCMC, Mandi
Dr. Kailasb Mohan
Dr. RKGMC, HamiQur
Bhandari

CDO
CDO
CDO
CDO
GDO
CDO
CDO
GDO
GDO

cDo
GDO
CDO

Diect
6DO
GDO
GDO

cDo
GDO
GDO
GDO

Direct
CDO

lh€nt olPlcrmacolosy
68

Dr. Chandni Ralhour

69
70

Dr. Sachin Shama

1),

72

Dr. Sakshi Shama

Pt. ILNGMC, Chdmba
SLBSGMC, Mddi aI Nerchosk
Dr. RPCMC, Toda
Dr. RPCMC, Tanda
Dr. RKGMC, Hanirlu

GDO
GDO
GDO
GDO

cDo

<!-- page 4 -->

Sr.l

Name of Medical Coueg€/ GDO/

13

SLBSGMC,Mandi
DT.RPGMC, Tanda
Dr. RPGMC, Tdda
IGMC, Shi'nla
Dr. RKG\4C, Ham'rpur
rtment ofPsychirby
ICMC, Shi,nla

AIMSS, Chamiana in which Direct

1
74
75

D!. Rohir Raher
Dr Kanu Kapoor

76
71

De
78

Dr. Shubhm Shree

79
80

D!. Kird Shtuma
IGMC, Shimla
Dr. vaishali Sandal
IGMC, Shimla
(Jili
Dr.
Sahore
Dr. RPCMC, Tuda
Dr. Swati Sharma
Dr. RPCMC, Tanda
DeDrrtment of Rrdio -diaenosis
Dr. Neha Devi
Dr. RPGMC, Tanda
Dr. Dolly Rana
Dr RPCMC, Tanda
Dr. Rishav Dhimu
Dr RPGMC, Tanda
Dr. RPGMC, Tanda
Dr. Ariu Sharna
Dr. RPCMC, Tmda
AIMSS, Chamiana
Dr. Rishika
ICMC, Shimla
ICMC, Shimla
Dr. Smili Shma
ICMC, Shimla
Dr. RKCMC, Hamirpur
Dr. Disvijay Sinsh
Dr. RKCMC, Hamirpur
Kaushal
DeDartmetrt of RadiothelaDv
Dr. RPGMC Tanda
Dr. Maitry Acharya
Dr. YSPGMC,NaI'M
Tuberculosis & RespiraiorY
IGMC, Shimla
Dr. Sherup Chhoden
Dr. Hhesh Thakur
Dr. RPCMC, feda

8l
82

8l
84
85
86
87
88
89
90
91

92

9l
94
95
96
97

GDO
GDO
GDO
GDO

cDo
GDO

cDo
Direct
6DO
CDO
GDO
GDO

cDo
GDO
GDO
GDO
GDO
GDO

cDo
GDO
GDO

cDo
Direcl

cDo
GDO

Th€ appoinfment h further subi€ct to fouowips terms and conditiotrs

r

<!-- page 5 -->

I

. Tho offer of appointnent is ordinarilv for a Period of three yea6 on tenure
wh;ch shall be
basis subject to salhfactory vearlv perfomance appraisals
Delaitment'
broughl 10 the norice of rhe PrinciPal bv the concemed Head of

of a Senior

The Principal shall indmate the Govement if lhe services
noHalisfaclory
Resident /Tutor Specialisl need 1o be disconrinued in view of

so

performance . The post occuPied bv rhe Senior Residenl /Tutor Specialist
fall lacant onll ifthe tenure is comfleted OR he^he lendere resienation

$,ill

OR hisi her seNices arc rerNnated

2. The cudidates (Direct Candidates) shall sive lesal undenaking in the
thal he /
form of afndavit with the concemed Principal at lhe lime ofjoining
/increment and
she shall not cla;m for regularization/continualiodpromotion

olher arcillary benefit against these tenure Posls on omPlellon of

their

reslective tenure i.e. 3 (thJee) veds
3. The GDO candidates shall aLso give legal underts'king ;n

the form of
shall

affidavil with the concemed Principal al rhe tine ofjoining thal he /she
lhese
not cla;n regularizalioi./continxadon md other ancillaf, benefit against
The
tenure posrs on completion of lheir respective renure i e thiee veds
the legal
Principal, concemed shall be the competent authority lo ensure thal

undenaking in the fom of afiidavit is submitled bv the concemed Aelecred
candidales before, their joinins

4. The above selecled candidaie shalL aplointed /selected on rempoFry basis
and shall not confer dy righl of regularizatioi/conlinualion/promotion
my olher anclllary benefits againsl the tenurc posi hehheselecled

and

5. The candidale shau not claim that his/ her sNices nav be conrinued ln
all case, tudher extcnsion can be granled on the recommendalions of the
of
Principal concemed as well as keePing in view of the larger public inieresl
patienl cale and the co\t will be cory)etent authorily for the same
6.

Ifthe Go\'l. does noi gidt 6melv extension desPite the recomendations
be
lhe concemed Principal, the sewices of lhe cddidate will autonaricallv

<!-- page 6 -->

teminated fiom the next day after the completion ofhither normaltenure i.e.03

7.

The appoiDtee cmot claim for rcgularizalion ofhis /hd senices ai:er

coftpletion oftenue.
8. The p.ivate practice will not be pennissible.

9. No TA,DA will be adnissible to join the assisment.

10. Tbc durointcc $ill troL bc allowcd to change the speciality/ depafi'nent in

IL

lhe candidate altointed as Senior Resident will only be entilled for 15
Edned leave + l2 casual leave in a calendar yed md vacations as per Govt.
Notification issued in this regard fiom time to time. In case of SrR€sidenlsfiutor Specialist (Direct Cddidate or GDO) the leave of 15 days and
12 days shall lapse at the end of a calendar year if unavailed. In case of Sr.

Residentfiutor Specialist (GDO reguld) the xnavailed EL shall be credited to
their accout as pe. H.P. Govt. Leave Rules. hovided that ihe concemed Senior
Residents/ Tutor Slecialisl will be entitled to get winter/summer vacation only

afier conpleting six monihs period ;f his / her Sr. Residency/
Tulorship(Specialist) in the departnenl. Any leave/vacalion availed beyond
vacationsleave as admissible io Sr. Residents shall require extension of lenure to
secure relevant leachiDg cerlifi cation.

13. The cddidates who have availed maiemity /palemity leave during lhe
period of Senior Residency/Tuiorshi! (Slecialist) shall be enlitled to glant of
leacbing experience for the period ofmatemity /palemity leave admisible as per

la. (i) The appoiniee(s) belonsing to GDO shall continue to dmw the
emolumenls and pay adnissible to himher wilh due allowances od increments
during lhe period of Senior Residency /Tutor Sp€cialisl.

(ii).The Direct candid{es rvho joib as Senior Resident ffuror Specialist
shall be eugible to dmw the pay as prescribed for a Senior Residentflutor
Slecialist which is as xnder

:

<!-- page 7 -->

Rs 1,00,000/-fixed per monft

15 The salary ofthe Sr. Residen Tutor Special;st shall be draM against
the sanclioned post of Sr. Resident / Tuto. Specialist in that Govl. Medical
College / Institution. The GDOS selected for Sr. Residency will tumish their
'Last Pay Ceftificate' (LPC) duly issued by their last establishmenl for lhe
purpose ol d.arving selaq' agaiNt fte post of Sr. ResideDt li,Lor Specialisl
Once appoinled, Ihe incurnbenl can be remoled from the post any time atter
joiniDe h case of miscoDducr, nisbebaviour, acts of connnisio../omjssion,
unbecohing of a lublic sewmt.

16. The HOD will make a formal request in Miting to the Principal ofthe
Medical College for removilg the delinquent appointee. The Principal ofthe
Medical College will take final decision in the matter after hearing both the

17. It will be necesary to give due optornrrily to the concerned Sr. Residenv
Tuto! Slecialist to explain hir/her posilion.
18. The Principal shall foNdd hi$her rcconmendations to the Govenhent,

ddlhc final decisionshall be taken at the level ofcovenlnent.
19. Simildly, iflhe lerfomance ;s nol salisfactory as relorted by the Head of
lhe departnent during mual performmce appraisals. lhe Principal shall hear
the parties dd foMdd the case to the Govement for discontinuation of
seNices, ifso roquircd alongwirh his/her findinss ud rccommendalions .

20. Sr. Residenl /Tutor S?ecialis! shall have to give one nonth\ notice
or salary in lietr thereof to resign md the concemed Principal will accePl
The candidales at Sr. No. 26, 27. 32, 33, 51, ed 54 have been
selected in rhe super-specialily. lhe completion of their Senior Residency
(SR-ship) in these depaithenrs shall nolbe considered for any academic or
promotional purloses in lhe tuture.

2l

<!-- page 8 -->

22.

The Direct candidales a.e required to submit chdacler certilicate
issued by the Tebsildar concemed fiom where candidates belong al the
tine ofjoining in the College.

23.

The candidate(s) working on resular/adhoc/conlract or in RKS
shall have to submil his/her relieving orders /lete. from respechve
depaftment at the time ofjoinins fa;lins which his,herjoining will not be

24. The direct candidate is required to get him,4ler medicall) exaNined
tion Medical Board of concerned Medical Colleges /lnslitulion betbrc
joning failisg rvhich their joining report shall nor be etucnained bv thc
Iflhe terms and conditions are acceptable, he^he should join the
assig ment in the concemed medical collese /AIMSS, Chamiana on or
before 11.05.2026 (exceF the followins candidates) posit;velv failing

25.

which this offer of appointnent shall sland cancelled autohalicallv and no
turlher con espondence shallbe entetained in lhis behalt

Name of Medical Colleee/
AIMSS, Chamiana in which

Seat wiu be

aPpornled

Sr.Resident
Specialist

IGMC, Sh;nla
Departmen! of OphthalmologY

04.05.2026
05.05_2026
1o I1.05.2026

Dr. D€eksha
Dogra

Dr. YSPGMC, Nahan
Deparhent of Ophthalmology

20.05.2026

Dr. Rahul

SLBSGMC, Mandi
Depanment of Onhopaedics

I l-05.20:6

21.05.2026 to
26.05.2026

\2.05.2026
t 7.05.2026

Note:l. In additiah to abare, all the terns and cohtlitians nchtioke.)
the Resident Doctar Palic, .lated 10.1A.2a25 as ahended ion tihe
tine, shall bearylicdble ryon the aforesaid selected cdhdidates

<!-- page 9 -->

Note:2. Ifah! discrepMies dre nated in the sdid otder , the same hdy
be intimdted to th6 Directarate itumediatel:1.

Through Official Wcbsite

(\r*[.l,p.go\.in/hpdfr er)

Endst. No. as abover- 12

lliDachal Pradesh

/

.

. :_

. -. i-.

Dated:

l The Secretary @ealth) to the covr. of Himachal pradesh for
infonnation w.r.t. letle! uder reforence please.
2. The Director ofHealih Senices, Himachal pradesh for infotuarion
ano necessary acxon please.

3. The Directo. Dental Healrh Services, Hp for infonnaiion md
necessary acuon Prease.

4.The Principal. IGMC, Shimla for infomarion and necessary action

5. The Principal, Dr. RPGMC, Tdda for infomauor d,u rccessuy
6. The Principal, Dr. YSPGMC, Nahan for intomarion and nece$ary

7. The Princilal, SLBSGMC, Mandi for infornation md necessary
8. The Principal, P!. JLNGMC. Chamba for informaiion ud necesary

9. The Principal, Dr. RKGMC, Hamiipur for infomation and
necessary acnon please,

10. The Principal, AIMSS Chmida for infomation dd necessary

<!-- page 10 -->

11. The CoE cum-Mcmber Secretary , couDsclling Commitlcc(Sr'
Residen/rutor Specialist) for inlbrmltion and necessary aclton please

Dtre..orMcdj,r I ducir on & \e..drf
HiDachal Pradeslr
