---
doc_id: "d1d8dd348dcdd8a3"
source_url: "https://www.baddiuniv.ac.in/wp-content/uploads/2025/12/Library-Advisory-CommitteeLAC.pdf"
ministry: "Baddi University of Emerging Sciences & Technology, Himachal Pradesh"
title: "Library Advisory Committee(LAC)"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "272acbaef7293daa"
---

<!-- page 1 -->

ia eae li “एगा"एणहतताएनज्ाएस्‍तफनाः
को . . ° .
cy Baddi University
Hi a} Bre eine ciation e rechincloey
ce Of Emerging Science & Technolo;
No. : BUEST/CL//A¢/2025/ OF Dated; 24 January 2025
Circular
The following Library Advisory Committee (LAC) has been constituted by the Vice-Chancellor of Baddi
University of Emerging Science & Technology. The Advisory committee will hold meetings at least
twice in a year to review activities and plan for future expansion of the library.
Chairman: Dr. Khushmeet Kumar- Dean Academics
Member: Ms. Agrima Singh - Assistant Professor (CSE)
Member: Dr. Savita — Associate Professor (SOAS)
Member: Dr. Nisha Kumari- Assistant Professor (SOS)
Member: Ms. Shweta Kumari-Lecturer (SMS)
Member: Ms. Navpreet Kaur-Assistant Professor (SOMS)
Member: Ms. Kavita Chaudhary- Associate Professor (B.Sc.Nursing)
Member: Mr. Peerzada Muhammad Iflaq- Assistant Professor (MIRT)
Member: Mr. Satpal- Student Representative 24UBA006 (SIMS)
Member: Ms. Khushi- Student Representative 23UPTO2] (BPT)
Member secretary: Ms. Sarita Bagri-Assistant Librarian
The committee will decide the main frame work for betterment of Central Library. AX
Wr
N
9
nea i
Copy to:
4, Secretary for his kind information
Copy to:
4. Vice-Chancellor for his kind information
2. Deans(SEET,SPES, SMS, SOAS, R&D, Academics& Admin.& Students welfare)
3. Controller of Examinations
4, Director-Finance/Training & Placement/Admission
5. HODs/ Co-coordinators (ME, EE, CE, ECE, CSE/IT,CA)
6. Proctor-cum-Chief Warden
7. Assistant Registrar(Accounts/Admin/Human Resources)
8. Librarian
9, Copy to all members of the Committee
