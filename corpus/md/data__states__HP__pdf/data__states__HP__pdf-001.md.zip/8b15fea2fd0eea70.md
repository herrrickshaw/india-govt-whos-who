---
doc_id: "8b15fea2fd0eea70"
source_url: "https://hpsvacb.hp.gov.in/storage/app/media/uploaded-files/pro-forma-for-prosecution-sanction-order-for-gazetted-officer-public-servent-in-service.pdf"
ministry: "State Vigilance & Anti Corruption Bureau, Himachal Pradesh"
title: "Pro-Forma For Prosecution Sanction Order (For Gazetted Officer-Public servent in Service).pdf"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "2d53aad718542fb0"
---

<!-- page 1 -->

PROFORMA-E
PRO-FORMA FOR PROSECUTION SANCTION ORDER
(In respect of Gazetted Officer/ Public Servants in service)
Whereas, FIR No. dated under section has been
lodged at PS SV&ACB on the complaint of Sh.
against_ on the allegation that And whereas, the
investigation of the case was conducted by the SV&ACB and during the course of investigation
it has been established that ___—_ (highlight role of the accused)
OIE ree A eae NT etek be et ei ele
And whereas, the said act(s)
of aforesaid accused namely, constitute the commission of the offences punishable
under section(s) of the Indian Penal Code. And whereas, |
(Name and Designation), being the competent authority, to remove the said accused
(Name) from his office after fully and carefully examining the records furnished by
SV&ACB including FIR, statements of witnesses, documents seized during investigation, charge
sheet and other relevant material/facts arising out of the aforesaid FIR, am prima facie
satisfied that the aforesaid accused namely. has committed offence(s) of
which are punishable under the Indian Penal Code and after applying my mind
independently consider that aforesaid accused namely___ should be prosecuted before the
Court of law keeping in mind the public interest and the protection available to the accused
against whom the prosecution sanction is sought. हे
Now, therefore, | (name and designation), hereby
accord the prosecution sanction under section 97 Code of Criminal Procedure, in FIR No.
dated for offence(s) punishable under section(s) of the Indian
Penal Code, for the prosecution of the aforesaid accused namely i oe eand-any omen
offence(s) punishable under any other provisions of law in respect of the acts aforesaid and for
taking cognizance of the said offence(s) by a Court of competent jurisdiction.
‘ Name and designation of the authority
/?२०८२८:७०९ ८८8 ८2००// ८८४ (With the Seal of the Authority)
— Recktaghgy,
ve “
soo :
Rajah vera
