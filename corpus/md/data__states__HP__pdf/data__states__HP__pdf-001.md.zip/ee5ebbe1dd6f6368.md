---
doc_id: "ee5ebbe1dd6f6368"
source_url: "https://www.himtu.ac.in/sites/default/files/2026-09/22092026_Tender%20notice%20canteen.pdf"
ministry: "Himachal Pradesh Technical University, Himachal Pradesh"
title: "Download"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "4804ed8c62cb6340"
---

<!-- page 1 -->

Himachal Pradesh Technical University
@ (A State Government University)
~ VPO Daruhi, Teh& Distt. Hamirpur (H.P.) - 7700
Phone :( 0972) 226902, Fax: (0972) 22690],
E-mail ID: purchaseofficerhptu@gmail.com website: www.himtu.ac.in
No. HimTu-4(Estate)A-27/2025- 44 Dated: 2>०१ ] 2024
TENDER NOTICE
Tenders are invited through online on HP _ e-procurement portal:
http://nptenders.gov.in for Outsourcing of Canteen Services of H.P. Technical University,
Hamirpur (H.P.)-7700l.The Scope of Work and terms & conditions of the tender can be
downloaded from HP e-procurement portal.
ek fficer,
H.P. Technical University,
Daruhi, Distt. Hamirpur (HP)
