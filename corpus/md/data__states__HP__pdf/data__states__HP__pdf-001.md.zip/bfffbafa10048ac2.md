---
doc_id: "bfffbafa10048ac2"
source_url: "https://cdn.s3waas.gov.in/s3b534ba68236ba543ae44b22bd110a1d6/uploads/2021/11/2021112570.pdf"
ministry: "Shimla"
title: "R & P Rules of Senior Assistant"
date: ""
pages: 5
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "45e15db5cd81869a"
---

<!-- page 1 -->

| (Authoritative English Text of Government Notification No. Per (AP)-C-A (3)-7/20\
| | B-Begett as required under clause (3) of Article 448 of the ( OL if
Government of Himachal Pradesh
Department of Personnel (AP-ID)
No. Per (AP)-C-A (3)-7/200 Dated: Shimla-I7I 002A "August, 20)
NOTIFICAT ION
. In exercise of the powers conferred by proviso to Article 309 of the
Constitution of India, the Governor, Himachal Pradesh, in consultation with the
, Himachal Pradesh Public Service Commission is pleased to make the Common
Recruitment and Promotion Rules for the post of Senior Assistant, Class-IIl, (Non-
Gazetted, Ministerial Services) in various Departments of the Government of Himachal
Pradesh as per Annexure-A attached to this notification, namely:-
i]
i Short title and Il. ( )). These rules may be called the Himachal Pradesh.
| Commencement. Department of Personnel, Senior Assistant, Class-Ill.
(Non Gazetted, Ministerial Services) Common
Recruitment and Promotion Rules, 20!.

(2) These rules shall come into force from the date of
publication in the Rajpatra, Himachal Pradesh.

(3) These rules shall be applicable to all the Government

हि Department of State of Himachal Pradesh =

4 Provided that these Rules shall not apply to the
posts of the Vidhan Sabha Secretariat/ High Court of
HP.

Repeal and Savings 2. (l) The method of recruitment provided in Recruitment and
Promotion Rules for the posts of Senior Assistant
under various Departments of the Himachal Pradesh
Government issued from time to time, shall cease to
operate:

(2) Notwithstanting such repeal, any appointment made or
anything done or any action taken under the rules so
repealed under sub-rule () of this rule, shall be deemed हु
to have been validly made or done or taken under these
rules.

. By order
Principal Secretary (Personnel) to the
Government of Himachal Pradesh.

Endst. No. Per (AP)-C-A (3) -7/200 Dated : Shimla-!7] 002, August, 20!].

Copy forwarded to:

L. All the Additional Chief Secretaries/ Principal
Secretaries/Secretaries/Additional Secretaries/ Deputy
Secretaries/Under Secretaries to the Govt. of H.P. Shimla-2.

2. All the Divisional Commissioners in Himachal Pradesh.

3. ‘All the Heads of Departments in Himachal Pradesh.

4. All the Deputy Commissioners in I Jimachal Pradesh.

5. Secretary, [.P. Public Service Commission, Shimla-2.

6. Secretary, H.P. Subordinate Services Selection Board, Hamirpur.

Te Joint Legal Rememberancer-cum-Joint Secretary (Law) to the Govt. of

Himachal Pradesh.
8. 250 spare copies. १९४७७
Under Geeistary (Personnel) to the
Government of Himachal Pradesh.

<!-- page 2 -->

का,
ही
ss f Eenmot Recruitment & Promotion Rules fi Annexure-A
azetted-Ministerial Services) in various Depart, of Senior Assistant, Class-Ill (Non-
fi: L. Name of Post : ह ents of Himachal Pradesh Government
Be ५ Senior Assistant
हि 2. Number of Posts + :
"  fiecowesines Seaie ment
contetiied Dp m time to time in the
r ed Departments,
3. gs
Classification : Class-III (Non-Gazetted)
. (Ministerial Services).
4. Scale of Pay 3
2 : Pay band: Rs. 0300-34800 + 3800 Grade Pay
5. “ Fon”? 4
idee कक Q Non-Selection:
Selection” Post
6. Age for Direct : NA.
recruitment
7. Minimum है NA. -
है Educational and
other 4
है qualifications
required for i
direct न जि
recruitment Lo
8. Whether age and Age : N.A.
. educational
qualifications Educational As prescribed against Col. No. I]
prescribed for Qualifications “below.
direct recruits :
will apply in the
case of the .
promotees i
9. Period of Two years subject to such further extension for a period not
Probation, if exceeding one year as may be ordered by the competent
any - authority in special circumstances and for reasons to be
recorded in writing.
0.° Method of {00% by promotion failing which on secondment basis.
recruitment,
whether by हि
direct . 3
recruitment or
by promotion,
deputation, है
transfer and the . :
हे percentage of न
posts to be
filled in by . :
various =
methods :

<!-- page 3 -->

f
f 2.

ll. In ; case of By Promotion from amongst the Common Clerical cae of
recruitment by Clerks/lunior Assistants of concefned Depa... sents
promotion Possessing ten years regular service or regular combined
deputation, with continuous adhoc service rendered, if any, in the grade, ‘
transfer, grades failing which on secondment basis from amongst the
from . which — incumbents of this post working in the identical pay scales
promotion/ from other H.P, Government Departments :
deputation/ Provided that such incumbents/ Clerks who have been
transfer is to be promoted from Class-IV or appointed on compass.onate
made grounds will be eligible for promotion to the post of Senior

Assistant, only if, they possess the educational qualification

of L0+2 as prescribed for direct recruitment to the post of

Clerk. *
Provided that for the purpose of promotion every employee shall have to serve

atleast one term in the Tribal/Difficult areas subject to adequate number of post(s)

available in such areas:

Provided further that the proviso (I) supra shall not be applicable in the case of
those employees who have five years or less service, left for superannuation.
: Provided further that Officers/Officials who have not served atleast one tenure

in Tribal/difficult area shall be transferred to such area strictly in accordance with

his/her seniority in the respective cadre.

Explanation I:-For the purpose of proviso | supra the “term” in Tribal/Difficult areas

shall mean normally three years or less period of posting in such areas keeping in

view the administrative requirements and performance of the employee.

Explanation H:- For the purpose of proviso I supra the Tribal/Difficult Areas shall be
as under:- .

l. District Lahaul & Spiti.

2; Pangi and Bharmour Sub Division of Chamba District.

कं Dodra Kawar Area of Rohru Sub-Division.

4. Pandrah Bis Pargana, Munish Darkali and Gram panchayat Kashapat, Gram

Panchayats of Rampur Tehsil of District Shimla.

5. Pandrah Bis Pargana of Kullu District.

6. Bara Bhangal Areas of Baijnath Sub Division of Kangra District.

7 District Kinnaur.. .

8. Kathwar and Korga Patwar Circles of Kamrau Sub Tehsil, Bhaladh Bhalona

and Sangna Patwar Circles of Renukaji Tehsil and Kota Pab Patwar Circle of Shillai

Tehsil, in Sirmour District.

9. Khanyol-Bagra Patwar Circle of Karsog Tehsil, Gada-Gussaini, Mathyant,

Ghanyar, Thachi, Baggi, Somgad and Kholanal of Bali-Chowki Sub Tehsil, Jharwar,

Kutgarh, Graman, Devgarh, Trailla, Ropa, Kathog, Silh-Badhwani, Hastpur,

Ghamrehar and Bhatehar Patwar Circle of Padhar Tehsil, Chiuni, Kalipar, Mangarh,

Thach-Bagra, North Magru and South Magru Patwar Circles of Thunag Tehsil and

Batwara Patwar Circle of Sunder Nagar Tehsil in Mandi District. है हु

ql) In all cases of promotion, the continuous adhoc service rendered in the feeder

post, if any, prior to regular appointment to the post shall be taken into account
towards the length of service as prescribed in these Rules for promotion subject to the
conditions that the adhoc appointment/promotion in the feeder category had been
made after following proper acceptable process of selection in accordance with the
provisions of R & P Rules:

न : -3-

<!-- page 4 -->

f =
/ (कह in हि हा ae ee a unter Person becomes eligible for .
f adhoc basis followed by regular हिना oe वादा me “nee -_ a
4 as appointment) in the feeder post in view of the
provisions referred to above, all persons senior to him in the respective
. category/post/cadre shall be deemed to be eligible for consideration and placed above
the junior person in the field of consideration:

Provided further that all incumbents to be considered for promotion shall
possess the minimum qualifying service of at least three years or that prescribed inthe
Recruitment & Promotion Rules for the post, whichever is less:

Provided further that where a person becomes ineligible to be considered for

promotion on account of the requirements of the preceding proviso, the person(s)
junior to him shall also be deemed to be ineligible for consideration for such
promotion. . हु
Explanation:-The last proviso shall not render the junior incumbents ineligible for
consideration for promotion if the senior ineligible persons happened to be ex-
servicemen recruited under the provisions of Rule-3 of Demobilized Armed Forces
Personnel (Reservation of Services in Himachal State Non-Technical Services) Rules,
972 and having been given the beriefit of seniority thereunder or recruited under the
provisions of Rule-3 of Ex-Servicemen (Reservation of Vacancies in the Himachal
Pradesh Techniéal Service) Rules, l985 and having been given the benefit of seniority
thereunder.
(2). Similarly, in all cases of confirmation, continuous adhoc service rendered on
the feeder post, if any, prior to the regular appointment against such posts shall be
taken into account towards the length of service, if the adhoc appointment/promotion
had been made after proper selection and in accordance with the provision of ve
Recruitment & Promotion Rules:

Provided that inter-se-seniority as a result of confirmation after
taking into account, adhoc service rendered . as referred to above shall remain
unchanged. है
2 ~ If a Departmental Promotion As may be constituted by the Govt. from

ड़ -. Committee exists, what is its time to time.

composition; Lo.
I3 Circumstances under which As required under the Law.

the HPP.S.C, is to be

consulted in making

recruitment, है
[4 Essential requirement for a N.A.

direct recruitment;

fer
i ———

<!-- page 5 -->

—~4-
45 Selection for appointment to NA
the हे post by — direct a
i6 Tecruitment; है
Reservation; The appointment to the service shail be
subject to orders regarding reservation in the
service for Scheduled Castes/ Scheduled
Tribes/Other Backward Classes/other
categories of persons issued by the Himachal
7 D a Pradesh Government from time to time.
epartmental Examination Not Applicable.
I8 Power to Relax; Where the State Govt. is of the opinion that it
है is necessary or expedient to do so, it may, by
हि order for reasons to be recorded in writing
and in consultation with the Hi.P, Public
_ Service Commission, relax any of the
. provision (s) of these Rules with respect to
any class or category of person (s) or post (s).
ae Ra मर
