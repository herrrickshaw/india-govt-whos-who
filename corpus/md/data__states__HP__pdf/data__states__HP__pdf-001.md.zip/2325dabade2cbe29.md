---
doc_id: "2325dabade2cbe29"
source_url: "https://hpbiodiversity.gov.in/Pdf/Office%20Order%20to%20Get%20NoC%20From%20HPSBB%20for%20Renewal%20of%20licenses%20of%20Bioresource%20Traders%20and%20User%20Industries.pdf"
ministry: "Himachal Pradesh State Biodiversity Board, Himachal Pradesh"
title: "Office Order regarding NOC From HPSBB for Renewal of licenses of Bioresource Traders and User Industries"
date: ""
pages: 3
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "d16d2c80229c0426"
---

<!-- page 1 -->

/ हि Himachal Pradesh State Biodiversity Board
\ “१५ Paryavaran Bhawan, US Club, Shimla-7] 00] (HP)
Neonat Phone: 0I77-2920003, 2656559, Email; hpbiodiversityboard@gmail.com
No. HPSBB/F(27)-2/I8-4&o Dated: |S November 2022
OFFICE MEMORANDUM
Subject: Licenses of traders and manufacturers involved in trade and/or
utilization of Himachal based biological resources NOT to be renewed
without NoC from the HP State Biodiversity Board.

The Biological Diversity Act, 2002, provides for conservation of Biological
Diversity, sustainable use of its components and fair and equitable sharing of the benefits
arising out of the use of biological resources, knowledge and for matters connected
therewith or incidental thereto. The said Act and related instruments, especially Section 7,
provides for submission of prior intimation by the Traders and Manufacturers to the State
Biodiversity Board concerned. Further, Rule / (9) of the Himachal Pradesh Biological
Diversity Rules, 20l9, empowers the State Biodiversity Board to prohibit or restrict any
activity which is detrimental or contrary to the objectives of conservation and sustainable
use of biodiversity or equitable sharing of benefits arising out of such activities.

Despite a number of directions, it has been reported that most of the traders
and manufacturers involved in trade and/or utilization of Himachal based biological
resources are not doing compliance as per provisions of the Biological Diversity Act, 2002,
therefore, in pursuance to the Section 23 of the Biological Diversity Act, 2002 and Rule
I] (79) of the Himachal Pradesh Biological Diversity Rules, 209, it has been decided that
the licenses of traders and manufacturers involved in trade and/or utilization of Himachal
based biological resources by the concerned licensing authorities are NOT to be renewed
without NoC from the Himachal Pradesh State Biodiversity Board. These NoCs would be
issued by the Himachal Pradesh State Biodiversity Board to these traders and/or
manufacturers on their registration with the Biodiversity Board.

v ae idan IAS)
Mentber Secretary,
HP State Biodiversity Board, Shimla- L.
Endst No. As above-44g 40 -to 493, Dated: IS Novembey 2022
Copy to the following for record and necessary compliance:
i) Director Industries, Department of Industries, Majitha house, Chota Shimla,
Shimla-2.

<!-- page 2 -->

4
ii) Director Ayurveda, B-26 Ayurved Bhavan, Shimla Bypass, SDA Complex,
Kasumpti, Shimla-9.
iii) Principal Chief Conservator of Forests (HoFF), HP Forest Department, Talland,
Shimla.
iv) Principal Chief Conservator of Forests (Wildlife), HP Forest Department,
Talland, Shimla
v) Managing Director, HP State Forest Development Corporation, Van Nigam
Bhawan Block, No. , SDA Complex, Kasumpti, Shimla-9.
vi) The Director, Department of Environment, Science & Technology, U.S. Club,
Shimla-l.
vii) The Member Secretary, State Pollution Control Board, Phase-III, New Shimla-
9.
viii) The Member Secretary, HIMCOSTE, 34-SDA Complex, Kasumpti, Shimla-9.
ix) | Labour Commissioner-cum-Director Employment HP, New Himrus Building,
Circular Road, Shimla, H.P
x) Commissioner, Shimla Municipal Corporation, Old Judicial Complex, Near DC
Office, The Mall Shimla-l.
xi) | Commissioner, Palampur Municipal Corporation, Palampur, District Kangra
Himachal Pradesh-7606.
xii) Commissioner, Dharamshala Municipal Corporation, Near Fire Station,
Dharamshala, Himachal Pradesh-7625.
xiii) Commissioner, Mandi Municipal Corporation, Mandi, Himachal Pradesh-
7500.
xiv) Commissioner, Solan Municipal Corporation, Solan, HP-l 7322.
xv) All Deputy Commissioners, Himachal Pradesh.
xvi) The Chief Executive Officer, Baddi-Barotiwala-Nalagarh-Development
Authority, EPIP Phase-I, Jharmajri, Baddi, District Solan (HP).
xvii) Shri Aditya Agnihotri, Director, Himachal Pradesh State Office of CII, Block
No. 3, Dakshin Marg, Sector 3l-A, Chandigarh-l60047.
xviii) Shri Narender Bhardwaj, Chairperson, State Chapter of PHD Chamber of
Commerce and Industry, Anand Vas, Khalini, Shimla-2.
xix) oa ce a Head, Punjab, Haryana & Himachal Pradesh Regional Advisory
uncil of FICCI, SCO-20-2, Sector-9 D, Madhya Marg, Chandigarh-60009.
xx) President, Baddi-Barotiwala-Nala है soa os
E a-} garh Industries Association, EPIP-Jharmajri
Road, EPIP Phase I, Jharmajri, Baddi, District Solan, H.P. 7403. ’
xxi) President, Parwanoo Industries Association, C, Cc ildi
ies C , C/o HPCED Building, Department
of Industries Complex, Sector-I, Parwanoo, District Solan, HP. |

<!-- page 3 -->

xxii) President, Drug & Pharma Association, C/o M/s Int .
Ltd., Moginand, Kala Amb, District Sirmour, HP. erated Laboratories Pvt
xxiii) President, Laghu Bharti Udyog Association, Biologics & Psychotropi .
Pvt. Ltd., Nahan Road, Kala Amb, District Sirmour, HP. » ies: That
xxiv) President, Industries Association, Kala Amb, C/o Ruchira Paper Mills Pvt, Ltd.
Trilokpur Road, Kala Amb, District Sirmour, HP. °
xxv) President, Himachal Chamber of Commerce and Industries, Industrial Area,
Chamber House, Gondpur, Paonta Sahib, District Sirmour, HP.
xxvi) President, BBT Industries Association, Roshan Nagar, VPO Bathu, Tehsil
Haroli, District Una.

xxvii) President, Haroli Block Industries, C/o Kaushal Roller Flour Mills Pvt. Ltd., 3-
Industrial Areas, Tahliwal, District Una, HP.

xxviii) President, Mehatpur Industries Association, Spatia Chemicals, Block No. 76-
77, Industrial Area, Mehatpur, District Una, HP.

xxix) President, Gagret Industries Association, The Amb Sub Division Industries
Association, CO JK Gases, Industrial Area Gagret, District Una, HP.

xxx) All bio-resource based industry units and traders involved in utilization and
trade of biological resources (Situated with in the State and outside the State of
Himachal Pradesh).

xxxi) Guard file.

v ८05
Mem! ena
HP State Biodiversity Board; Shimla-].
