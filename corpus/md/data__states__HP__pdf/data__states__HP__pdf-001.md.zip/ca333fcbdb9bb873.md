---
doc_id: "ca333fcbdb9bb873"
source_url: "https://planning.hp.gov.in/NewReleases\PI_Notification.pdf"
ministry: "Planning Department, Himachal Pradesh"
title: "Regarding instructions for implementation of the Annual Plan provisions during financial year."
date: ""
pages: 8
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "0545536abcb5aa30"
---

<!-- page 1 -->

५ PERSONAL ATTENTION

No: PLG (PI) 7-42/2047

Government of Himachal Pradesh

“Planning Department”

From
Addl. Chief Secretary (Planning)to the

Government of H.P., Shimla-2.

To

All the Administrative Secretaries to the

Government of H.P., Shimla-2. ह

Dated: Shimla-2, the 2! March, 20/8
Subject: Regarding instructions for implementation of the

Annual Plan provisions during the financial year.

Sir/ Madam,

As you are aware, that Planning Department has been
issuing instructions regarding the implementation of the Annual Plan
provisions during the course of the financial year, from time to time.
These instructions are either in the shape of an advice on AD’s file or in
the shape of a letter. Now Planning Department has compiled these
instructions in this one letter for the easy facilitation of files/ papers
related to the Annual Plan provisions.

In continuation of this Office letter no. PLG (PI) -23/205
dated 23 May, 20{5 and PLG (PI)I-45/20/6 dated 46" December,
206 (copies enclosed for ready reference), the instructions contained in
these letters and other relevant instructions are as per details below.
These instructions will be applicable to all the three Sub Plan i.e.
General Plan (GP), Scheduled Caste Sub Plan (SCSP) and Tribal
Sub Plan (TSP).

4. Any proposal under GP will be forwarded to the Planning
Department; SCSP proposal to the Department of SCs’, OBCs’,
Minority Affairs and Specially Abled and TSP proposals to Tribal
Development Department (TDD).

contd./-

<!-- page 2 -->

.......__॒_॒_॒॒॒॒_____ हरा
हु a2:-

2. Provisions under Demand No. 34 (TSP) are earmarked to the
extent of 9% of the total Plan Outlays and similarly provisions
under Demand No. 32 (SCSP) are earmarked to the extent :
25.9%, so any additional demand/ re-appropriations during a
financial year needs to be subsumed within the overall
savings/surrenders under TSP/SCSP during the course of the
financial year.

A. EAPs’ & CSSs’ Instructions

. Administrative Department(s) are competent to utilize budgeted
State Share(s) to the extent of the released matching Central
Share(s) under the Centrally Sponsored Scheme (CSS). Any
shortfall will automatically be surrendered.

2. Expenditure under CSSs’ will be strictly in compliance of
rules/norms/guidelines framed under the CSSs’.

3. Under CSSs', any proposal involving creation/filling up of posts,
purchases of vehicles/furniture items will be moved to Finance
Department (FD) for examination.

4. Similar conditions as elaborated in the above three points will be
applicable under the Externally Aided Projects (EAPs’).

B. Re-appropriation/ Diversion Instructions Diversion Instructions

. Budgeted funds will not be allowed to be re-appropriated /
diverted from one Demand to another Demand.

2. Re-appropriation / diversion are not permissible from (i)
budgeted PLAN provisions to NON-PLAN provisions (ii) from
Capital Head provisions to Revenue Head provisions and vice —
versa.

3. Re-appropriation / diversion are not permissible from Earmarked
Sectors to Non-Earmarked Sectors.

4. Re-appropriation / diversion are not permissible from Earmarked
provisions kept as Central Share; under any Externally Aided
Project (EAP) or any other earmarking(s) to meet State Share
provisions and vice versa.

contd./-

<!-- page 3 -->

. "3:-

5. Similar condition, as elaborated in point no.8, will be applicable
for the provisions of Externally Aided Projects (EAPs), Rural
Infrastructure Development Fund (RIDF) (NABARD) and any
Scheme/ Department specific earmarkings, done by Planning
Department.

C. After finalization/ passing of SDGs’

4. No additionality proposal will be considered once the
Supplementary Demands for Grants (SDGs) have been finalized.
ADs’ may move such proposals for additionality before 34°
January of the financial year.

2. After the finalization of the SDGs’, for meeting the demand of
additional funds, if required, AD(s) may move proposals, for re-
appropriation, but within the Demand size and that too from
Capital Head to Capital Head and Revenue Head to Revenue :
Head only.

D. Capital Head related Instructions

4. Under Capital Head works, no proposal needs to be sent to
Planning/Finance Department (s) if the re-appropriation/diversion
of funds for various works is within the same Head of Account
(HoA) and the works are budgeted in the financial year. The
competent authority in the Departments may decide such
proposals, considering administrative requirements and
Administrative Secretary of the Department may approve such
re-appropriations.

2. While allocating funds for Capital Works and RIDF Works, AD’s
may ensure the order of priority, which should normally be (i)
works nearing completion; (ii) works under construction and (iii)
Really New Schemes (RNS) works. This prioritization will result
in focused allocation of funds and will help in early completion of
all on-going works.

3. AD may ensure especially the PWD, IPH, HIMUDA etc include
the provisions of Supply of Power (SoP), Water Supply etc in the
overall estimated cost of the work.

contd./-

<!-- page 4 -->

..__________॒_॒_॒_॒_॒_॒_॒॒_॒_॒_॒_॒॒_॒_॒_॒॒__॒॒॒_॒॒__ >>) ना _
, 4:- .
है 4. AD’s may also ensure that the cost of Net Present Value (NPV) / है
Compensatory Aforestation (CA) under any capital work is
included in the overall estimated cost of the work so the pace of
the work is not hampered for want of funds.
E. General Instructions

{. In addition to all above the instructions issued, vide letter no.
PLG (PI) -23/20i5 dated 23 May, 20i5 and PLG (?॥)-
45/206 dated 76" December, 2046, as referred in para 2 of the
letter, may also be adhered too.

2. Any proposal for additionality to be moved to Planning
Department; Department of SCs’, OBCs’, Minority Affairs and
Specially Abled and Tribal Development Department (TDD)
should be strictly as per the details required in letter no. PLG
(Pl)4-5/2046 dated 46" December, 20/6

3. These instructions may be followed in conjunction with the
instructions issued by Finance Department vide letter No.
Fin-F-(A)--/2004, dated 3 June, 204 and amendments
carried out from time to time, regarding delegation of
financial powers and revision of economy instructions.

Yours faithfully,
Skank 7
(Dr. Shrikant Baldi)
Addl. Chief Secretary (Planning) to the
GoHP Shimla-2
Telefax:- 077- 262 698
e-mail:- hp_planning@yahoo.com
Endst. No: As above. Dated: Shimla-2, 2 March, 2048.
Copy forwarded to all the Heads i i
& necessary action. of Department(s) for information
(Dr. Basu Sood)
Adviser (Planning), H.P., Shimla-2

<!-- page 5 -->

- IMPORTANT
= INSTRUCTIONS

No: PLG (PI) 4-23/2045

Government of Himachal Pradesh

_ Planning Department
From .
Pr. Secretary (Planning & Finance) to the
Govt. of H.P., Shimla-2
To
Me 4. All Administrative Secretaries to the
GoHP, Shimla-2.
2. All Head of Departments,
Himachal Pradesh

Dated: Shimla-2, the 23" May, 2045.

Subject: Regarding re-appropriation/diversion proposals for various
works under Capital Head.
Sir/Madam,

The departments of Planning & Finance receive Proposals from
various departments for re-appropriation/ diversion of funds for various
capital works of the department, in a Particular financial year. To cite an
example, a department may feel that depending upon its priority, availability
of land, forest clearances and other relevant factors etc., more funds may
be required to be Spent on a particular work, diverting funds from another
sanctioned work.

The matter has been examined in Planning & Finance
Department(s). It is clarified that:-

I. No proposal needs to be sent to Planning/Finance Department (s) if
the re-appropriation/diversion of funds for various works is within the
same Head of Account (HoA) and the works are budgeted in the “
financial year. The competent authority in the Departments may
decide such proposals, considering administrative requirements.

contd../-

<!-- page 6 -->

IS '—ST LLL
32s
2. The order of preference for earmarking of funds for Capital Works
should normally be (i) works nearing completion; (ii) works under
construction and (iii) RNS works. This prioritization will help in early
completion of all on-going works.
3. These instructions may be followed in conjunction with the
, instructions issued by Finance Department vide letter No. Fin-F-
* (A)-4-4/2004, dated 3° June, 2044, regarding delegation of
financial powers and revision of economy _ instructions,
especially with respect to SOEs* 26 {relating to Minor Works} and
SOE 27 {Major Works}.
Yours faithfully,
s)<
(Dr. Shrikant Baldi)
Pr. Secretary (Planning & Fin.) to the
Government of HP, Shimla-2.
Telefax: 077- 262 698/262 6327
e-mail- hp_plannina@yahoo.com

<!-- page 7 -->

. r : PERSONAL ATTENTION
No: PLG (PI) -75/2046
Government of Himachal Pradesh
: Finance and Planning Departments :
From
Addl. Chief Secretary(Finance & Planning) to the
Governmentiof Himachal: Pradesh, Shimla-2.
To. i :
Alt:Admmittistrative Secretaries to the है
Government of Himachal Pradesh. So
Dated: Shimia-2, the 46" Bedommbur., 2046.
Subject: Instructions/ Checklist for Budget/ AdditionalityProposals for
हु Existing/ New Schemes on Plan/ Non-Plan Side.
ह Sir/Madam, * पे ह
ः It has been observed that financial proposals for re-appropriation/
additional funds sent by the Administrative Departments are sometimes incomplete
in one or other respect, leading to delay in disposal. For sending complete and
systematic proposals, Planning/ Finance Departments have prepared’ a checklist,
which may be adhered to before sending any financial proposal. The checklist is as
under:- : न
4. Name of the scheme under which re-appropriation/ additionality is required.
2. Brief history of the scheme/proposal’ for which re-appropriation/
additionality is required.
3. Ongoing or new scheme whether the Scheme is under Plan or Non-Plan?
4. Whether scheme is Centrally Sponsored Scheme or State Scheme.
5. Sharing pattem of the scheme in case of Centrally Sponsored
Scheme(CSS) and whether Central Share: released by Gol has been
released. :
6. ॥ case of State Scheme- current outlays, year of approval, total estimated
है cost of the scheme, estimated date of completion and number of
हि beneficiaries benefitted. ry -
* 7. Head of Account(HoA)/ SOE in which additionality is sought.
. 8. Required amount for re-appropriation/ additionality.
9. Mentioning of Budget Estimates(BEs)/ Provision in Current Financial
Year(CFY) for the scheme in all the Demands for Grants (viz; General/
SCSP/TSP).
40.Scope of savings in the BEs of the CFY.
i 4. Copies of letters/ sanctions of Gol where matching State Share is required/
demanded.
2. Any other information which department feels is required to be sent.

<!-- page 8 -->

EEE हमला ____न+
=2-
You are requested to kindly direct your offices to adhere to the __
‘instructions contained in above checklist for early and correct disposal of the
* proposals. है

Yours faithfully,

Sa
- (Dr. Shrikant Baldi)
Addl. Chief Secretary(Finance & Planning) to the
Government of H.P., Shimla-2
Telefax:- 077- 262 698/262 6327
@-mail:- hp_planning@yahoo,com

Endst. No: As‘above. Dated : Shimia-2, the 4% Doster, 206.
है Copy forwarded to all the Head of Departments,. Himachal Pradesh

for information: & necessary action. , .
है so, —
Addl. Chief Secretary(Finance & Planning):to-the:
ee Government of SPE PS RitnIa 2 |
है t
