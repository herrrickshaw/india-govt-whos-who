---
doc_id: "caefb607d78c4dbf"
source_url: "https://eudyan.hp.gov.in/cms/media/frknms2c/g5_tender_document.pdf"
ministry: "Horticulture Department, Himachal Pradesh"
title: ""
date: ""
pages: 40
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c2953df9b6904dd6"
---

<!-- page 1 -->

DEPARTMENT OF HORTICULTURE, GOVERNMENT OF HIMACHAL PRADESH

REQUEST FOR QUOTATIONS
– SUPPLY of GOODS

OFFICE EQUIPMENT AND PMU FIELD EQUIPMENT

“HIMACHAL PRADESH SUBTROPICAL HORTICULTURE, IRRIGATION AND
VALUE ADDITION PROJECT: PROJECT READINESS FINANCING
PROJECT
(HP-SHIVA PRF)”
PROJECT NUMBER: IND-6036
SEPTEMBER, 2021

<!-- page 2 -->

REQUEST FOR QUOTATION
OFFICE EQUIPMENT AND PMU FIELD EQUIPMENT

(RFQ- G5)
Project Title

: Himachal Pradesh Subtropical Horticulture, Irrigation and Value Addition Project:
Project Readiness Financing Project (HP-SHIVA PRF)

Source of Funding
Contract Ref

: Asian Development Bank
: _______________

To

: _______________

Date of Issue of Request:

Sir/Madam:
1. The Department of Horticulture, Government of Himachal Pradesh (Purchaser) hereby requests you
to submit price quotation/(s) for the supply of the following items:
Lot 1 – Laptop A
Lot 2 – Laptop B
Lot 3 – Laptop C
Lot 4 – Desktop (All in one)
Lot 5 – UPS
Lot 6 – Tablets
Lot 7 – Hand Held GPS Device
Lot 8 – Photostat Machines
Lot 9 – Printer, Scanner and Copier (Colour)
Lot 10 – Printer, Scanner and Copier (B&W)
Lot 11 – Video Conference Systems
Lot 12 – TV Screens for Video Conference Systems

To assist you in the preparation of your price quotation we enclose the necessary Supply and Delivery
Schedule, Technical Requirements and Specifications, Form of Quotation and draft Contract.
2. If you/your firm, however, falls under any of the following conditions, your proposal shall not be
considered:
(a) you/your firm are/is not a citizen/national of an Asian Development Bank (ADB) member country;
or
(b) you/your firm have/has been associated with the firm that prepared the design and specifications,
or engaged in the preparation of the Project for which the contract that is subject of this request
for quotations was identified; or
(c) you/your firm are/is owned by the Purchaser; or
(d) you/your firm are/is currently sanctioned or temporarily suspended by the Asian Development
Bank for a violation of its Anticorruption Policy (1998, as amended to date),;or
(e) the importation of goods or services from your country or any payment to persons or entities in
your country is prohibited in compliance with a decision of the United Nations Security Council
under Chapter VII of the Charter of the United Nations.

<!-- page 3 -->

3. To be qualified:
a) Supplier must be original manufacturer or authorized dealer of the items covered by this
Request for Quotation (RFQ) and, as evidence, supplier must also attach
(i)
Certificate of Authorization from the manufacturer and/or documentary evidence of
Authorized Dealership of the manufacturer;
(ii)
Proof of you/your firms experience as a supplier in at least one contract in the last 3 years
of a size and nature similar to the items in the supply schedule of this contract.
(iii)
Copy of PAN
(iv)
Copy of GST Registration certificate
(v)
Copy of Manufacturer’s license (to be provided if available with the bidder and which may
be requested subsequently by the Purchaser if not immediately available)
(vi)
Copy of Bidder’s sale license.
a. In case of imported material, proof of import permission from the Competent Authority should be
attached; and
b. The supplier must ensure the conformity of items being supplied with the technical specification
prescribed in this RFQ.
4. Your quotation should be submitted in accordance with the following instructions, procedures and
terms and conditions of the Contract.
Preparation of Quotations
a) Your price quotation/(s) shall be for any or all of the Lots as described in the attached
documents and to be submitted only using the attached Form of Quotation with the priced
Supply and Delivery Schedule (Attachment I) and Technical Specifications (Attachment II).
The currency of quoted prices and payment shall be Indian Rupees;
b) You are required to quote for the entire quantity of goods in a particular Lot as indicated in
Attachment 1 including delivery to all locations as indicated thereof.
c) The prices should be quoted for supply and delivery to respective location within Himachal
Pradesh, as specified in Attachment 1 of this RFQ document, and should be accompanied by
adequate technical documentation and catalogue(s) and other printed material or pertinent
information (in Hindi or English language) for each item quoted. You are also required to indicate
the Technical Specifications of the offered goods in Attachment II.
d) You shall submit quotations online only as per provisions of www.hptenders.gov.in for the above
items. Your quotation must be typed or written in indelible ink and shall be signed by you or your
authorized representative. Without a signature in your Form of Quotation, your quotation will not
be considered further;
e) Your quotation(s) should be valid for a period of 180 days from the deadline for submission of the
quotation/(s) as indicated below. If you withdraw your quotation during the validity period and/or
refuse to accept the award of a contract when and if awarded, then you will be excluded from the
list of Suppliers for the project for two years.
Submission and Opening
(a) Your Form of Quotation with the required documents may be submitted electronically in
accordance with provisions provided at www.hptenders.gov.in on or before 14.10.2021, 13:00
hours (IST).
(b) Quotations shall be opened (i) in public, in the presence of participating suppliers’ representatives
who choose to attend 14.10.2021 at 14:00 hours (IST) at the Directorate of Horticulture,

<!-- page 4 -->

Navbahar, Shimla – 2, H.P.
Evaluation and Comparison
a) Quotations determined to be substantially responsive to this Request for Quotation will be
evaluated by comparison of their offer prices. A quotation is not substantially responsive if it
contains material deviations or reservations to the terms, conditions, and specifications in this
Request for Quotation;
b) Quotations which do not offer the full quantity of goods as indicated in Attachment 1 of this
Request for Quotation including delivery to all locations as indicated will be treated as nonresponsive
c) In case of quotations which do not specifically indicate the Transportation Cost (as indicated in
Attachment 1 of this Request for Quotation), such cost will be deemed to be included in the Total
Price and no additional amount will be allowable for this.
d) Quotations are required to specifically indicate the GST amount as indicated in Attachment 1 of
the request for Quotation. In case of quotations which do not indicate the GST amount, such
amount will be deemed to be included in the Total Price and no additional amount will be
allowable for this.
e) Evaluation will be carried out by the Purchaser Lot wise and contract awarded Lot wise.
f)

In evaluating the quotations, the Purchaser will adjust for any arithmetical errors as follows:
(i) where there is a discrepancy between amounts in figures and in words, the amount in words
will govern; and
(ii) where there is a discrepancy between the unit rate and the line item total resulting from
multiplying the unit rate by the quantity, the unit rate as quoted will govern.
If you refuse to accept the correction, your quotation will be rejected.

Award of Contract
g) The Purchaser shall award the contract to the Supplier whose quotation has been determined to
be substantially responsive to this Request for Quotation and who has offered the lowest price
quotation for the respective individual Lots.
h) The Supplier whose quotation has been accepted will be notified by the Purchaser within
20 (twenty) days from the date of submission of quotation through the return of a copy of the
Form of Quotation with Acceptance signed by the authorized representative of the Purchaser;
i)

Purchaser reserves the right to increase or decrease the order quantity up to +/- 25% at quoted
unit rates

j)

The successful Supplier shall sign the Contract governed by the Terms and Conditions. In
addition to the quoted price, the contract price shall include Goods and Services Tax (GST), if
applicable, in India.

5. Further information can be obtained from:
Name
: Mr. Manoj Sharma, Assistant Procurement Manager
Address
: Department of Horticulture, Navbahar, Shimla, Himachal Pradesh 171002
Telephone
: 9418434963
Fax
: 0177-2842389
E-mail
: manojsharma3006@gmail.com

<!-- page 5 -->

6. The Purchaser intends to apply funds from the Asian Development Bank (ADB) for eligible
payments under the Contract resulting from this Request for Quotation.
7. Under ADB’s Anticorruption Policy (1998, as amended to date),suppliers shall observe the highest
standard of ethics during the procurement and execution of such contracts. ADB may reject a
proposal for award, and may impose sanctions or other remedial actions on parties involved, if it
determines that the supplier recommended for award or any other party, directly or through an agent,
has engaged in corrupt, fraudulent, collusive, coercive, or obstructive practices or other integrity
violations in competing for, or in executing, the Contract. At the time of submission of your quotation,
you should not be in ADB’s sanctions list. A firm/individual shall not be eligible to participate in any
procurement activities under an ADB-financed, -administered, or -supported project while under
temporary suspension or debarment by ADB pursuant to its Anticorruption Policy, whether such
debarment was directly imposed by ADB, or enforced by ADB pursuant to the Agreement for Mutual
Enforcement of Debarment Decisions.
8. You/your firm, joint venture partners, associates, parent company, affiliates or subsidiaries, including
any subcontractors or suppliers for any part of the Contract, are not, or have never been, temporarily
suspended, debarred, declared ineligible, or blacklisted by the purchaser’s country, any international
organization, and other donor agency.
If so debarred, declared ineligible, temporarily suspended, or blacklisted, please state details (as
applicable to each joint venture partner, associate, parent company, affiliate, subsidiaries,
subcontractors, and/or suppliers):1
(a) Name of Institution: __________________
(b) Period of debarment, ineligibility, or blacklisting (start and end date): ____________
(c) Reason for the debarment, ineligibility, or blacklisting: ________________________
9. You/your firm’s, joint venture partners’, associates’, parent company’s affiliates’ or subsidiaries’,
including any subcontractors’ or suppliers’, key officers and directors have not been [charged or
convicted] of any criminal offense (including felonies and misdemeanors) or infractions/violations of
ordinance which carry the penalty of imprisonment.
If so charged or convicted, please state details:2
(a) Nature of the offense/violation: __________________
(b) Court/Area of jurisdiction: __________________
(c) Resolution (i.e. dismissed; settled; convicted/duration of penalty): __________________
(d) Other relevant details:
10. You/your firm understands that it is your obligation to notify ADB should you/your firm, joint venture
partners, associates, parent company, affiliates or subsidiaries, including any Subcontractors or
Suppliers, be temporarily suspended, debarred or become ineligible to work with ADB or any other
multilateral development banks, the purchaser’s country, international organizations, and other donor
agencies, or any of your key officers and directors be charged or convicted of any criminal offense or
infractions/violations of ordinance which carry the penalty of imprisonment.
11. Any misrepresentation that knowingly or recklessly misleads, or attempts to mislead may lead to the
automatic rejection of the quotation/bid or cancellation of the contract, if awarded, and may result in
remedial actions, in accordance with ADB’s Anticorruption Policy (1998, as amended to date) and
Integrity Principles and Guidelines (2015 as amended from time to time).
12. A bidder shall not have a conflict of interest. All bidders found to have a conflict of interest shall be

1 Any such disclosure shall be forwarded by the Purchaser to ADB.
2 Any such disclosure shall be forwarded by the Purchaser to ADB.

<!-- page 6 -->

disqualified.
13. Please confirm by fax/e-mail the receipt of this request and whether or not you will submit the price
quotation(s).
Sincerely,
______________________
(Purchaser)
The Project Director
Himachal Pradesh Subtropical Horticulture,
Irrigation and Value Addition Project(HPSHIVA)
Department of Horticulture, Himachal Pradesh
Navbahar, Shimla, 171002
E-Mail: pmuhpshiva@gmail.com
Tel.: +91 177 2842390/ 2841120

<!-- page 7 -->

Attachment I – LOT 1
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
LAPTOP-A

Items

Unit

Quantity
(A)

Unit Price
(B)
Rs*

Goods’ Cost,
C = (A x B)
Rs*

Transportation
Cost (D)
Rs*

Total Price,
C + D,
Rs**

GST

Total
Quotation
Price incl GST

Location and Delivery
Period
PMU (HPSHIVA)
Directorate of Horticulture,
Navbahar, Shimla, HP

Laptop

Nos

03
Delivery: Within 2 months
of award of contract

Total

3

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 8 -->

Attachment I – LOT 2
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
LAPTOP-B

Items

Laptop

Total

Unit

Quantity
(A)

Nos

03

Nos

05

Nos

05

Unit Price
(B)
Rs*

Goods’
Cost,
C = (A x B)
Rs*

Transportation
Cost (D)
Rs*

Total
Price,
C+D
Rs**

GST

Total
Quotation
Price incl GST

Location and
Delivery Period
PMU (HPSHIVA)
Directorate of Horticulture,
Navbahar, Shimla, HP
Delivery: Within 2 months of
award of contract
PIU, Jal Shakti Vibhag,
Hamirpur, HP
Delivery: Within 2 months of
award of contract
PIU, DOH, Navbahar, Shimla,
HP
Delivery: Within 2 months of
award of contract

13

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 9 -->

Attachment I – LOT 3
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
LAPTOP-C
Items

Laptop

Total

Unit

Quantity
(A)

Nos

07

Nos

10

Nos

11

Nos

10

Nos

4

Nos

4

Nos

3

Unit Price
(B)
Rs*

Goods’
Cost,
C = (A x
B) Rs*

Transportation
Cost (D)
Rs*

Total
Price,
C+D
Rs**

GST

Total Quotation
Price incl GST

Location and
Delivery Period
DDH Bilaspur, HP
Delivery: Within 2 months of
award of contract
DDH, Hamirpur, HP
Delivery: Within 2 months of
award of contract
DDH, Kangra, HP
Delivery: Within 2 months of
award of contract
DDH, Mandi, HP
Delivery: Within 2 months of
award of contract
DDH, Solan, HP
Delivery: Within 2 months of
award of contract
DDH, Sirmour, HP
Delivery: Within 2 months of
award of contract
DDH, Una, HP
Delivery: Within 2 months of
award of contract

49

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 10 -->

Attachment I – LOT 4
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
DESKTOP (ALL IN ONE)

Items

Unit

Quantity
(A)

Nos

05

Nos

05

Nos.

10

Desktop

Total

Unit
Price
(B)
Rs*

Goods’
Cost,
C = (A x
B) Rs*

Transportation
Cost (D)
Rs*

Total
Price,
C+D
Rs**

GST

Total Quotation
Price incl GST

Location and
Delivery Period
PMU (HPSHIVA)
Directorate of Horticulture,
Navbahar, Shimla, HP
Delivery: Within one month
of award of contract
PIU, Jal Shakti Vibhag,
Hamirpur, HP
Delivery: Within one month
of award of contract

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 11 -->

Attachment I – LOT 5
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
UPS HARDWARE FOR DESKTOP

Items

Unit

Quantity
(A)

Nos

05

Nos

05

Nos

10

UPS

Total

Unit
Price
(B)
Rs*

Goods’
Cost,
C = (A x
B) Rs*

Transportation
Cost (D)
Rs*

Total
Price,
C+D
Rs**

GST

Total Quotation Price
incl GST

Location and
Delivery Period
PMU (HPSHIVA)
Directorate of Horticulture,
Navbahar, Shimla, HP
Delivery: Within one month of
award of contract
PIU, Jal Shakti Vibhag, Hamirpur,
HP
Delivery: Within one month of
award of contract

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 12 -->

Attachment I – LOT 6
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
TABLET

Items

Tablet

Unit

Nos

Quantity
(A)

100

Unit
Price
(B)
Rs*

Goods’
Cost,
C = (A x
B) Rs*

Transportation
Cost (D)
Rs*

Total
Price,
C+D
Rs**

GST

Total Quotation
Price incl GST

Location and
Delivery Period
PMU (HPSHIVA)
Directorate of Horticulture,
Navbahar, Shimla, HP
Delivery: Within 2 months of
award of contract

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 13 -->

Attachment I – LOT 7
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
HAND HELD GPS DEVICE

Items

Hand Held GPS
Device

Unit

Nos

Quantity
(A)

07

Unit
Price
(B)
Rs*

Goods’
Cost,
C = (A x
B) Rs*

Transportation
Cost (D)
Rs*

Total
Price,
C+D
Rs**

GST

Total Quotation
Price incl GST

Location and
Delivery Period
PMU (HPSHIVA)
Directorate of Horticulture,
Navbahar, Shimla, HP
Delivery: Within 2 months of
award of contract

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 14 -->

Attachment I – LOT 8
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
PHOTOSTAT MACHINE

Items

Photostat Machine

Total

Unit

Quantity
(A)

Nos

03

Nos

01

Nos

01

Unit
Price
(B)
Rs*

Goods’
Cost,
C = (A x
B) Rs*

Transportation
Cost (D)
Rs*

Total
Price,
C+D
Rs**

GST

Total Quotation
Price incl GST

Location and
Delivery Period
PMU (HPSHIVA)
Directorate of Horticulture,
Navbahar, Shimla, HP
Delivery: Within 2 months of
award of contract
PIU, DOH, Navbahar,
Shimla, HP
Delivery: Within 2 months of
award of contract
PIU, Jal Shakti Vibhag,
Hamirpur, HP
Delivery: Within 2 months of
award of contract

05

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 15 -->

Attachment I – LOT 9
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
PRINTER, SCANNER, COPIER (COLOR)

Items

Printer,
Scanner,
Copier (Colour)

Total

Unit

Quantity
(A)

Nos

02

Nos

01

Nos

01

Unit
Price
(B)
Rs*

Goods’
Cost,
C = (A x
B) Rs*

Transportation
Cost (D)
Rs*

Total
Price,
C+D
Rs**

GST

Total Quotation
Price incl GST

Location and
Delivery Period
PMU (HPSHIVA)
Directorate of Horticulture, Navbahar,
Shimla, HP
Delivery: Within 2 months of award of
contract
PIU, Jal Shakti Vibhag, Hamirpur, HP
Delivery: Within 2 months of award of
contract
PIU, DOH, Navbahar, Shimla, HP
Delivery: Within 2 months of award of
contract

04

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 16 -->

Attachment I – LOT 10
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
PRINTER, SCANNER, COPIER (BLACK & WHITE)

Items

Printer, Scanner,
Copier (Black &
White)

Total

Unit

Quantity
(A)

Nos

05

Nos

01

Nos

01

Unit
Price
(B)
Rs*

Goods’
Cost,
C = (A x
B) Rs*

Transportation
Cost (D)
Rs*

Total
Price,
C+D
Rs**

GST

Total Quotation
Price incl GST

Location and
Delivery Period
PMU (HPSHIVA)
Directorate of Horticulture,
Navbahar, Shimla, HP
Delivery: Within 2 months of
award of contract
PIU, Jal Shakti Vibhag,
Hamirpur, HP
Delivery: Within 2 months of
award of contract
PIU, DOH, Navbahar,,Shimla,
HP
Delivery: Within 2 months of
award of contract

08

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 17 -->

Attachment I – LOT 11
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
VIDEO CONFERENCE (VC) SYSTEM

Items

Video Conference
System

Total

Unit

Quantity
(A)

Nos

01

Nos

01

Nos

01

Unit
Price
(B)
Rs*

Goods’
Cost,
C = (A x
B) Rs*

Transportation
Cost (D)
Rs*

Total
Price,
C+D
Rs**

GST

Total Quotation
Price incl GST

Location and
Delivery Period
PMU Directorate of
Horticulture, Navbahar,Shimla,
HP
Delivery: Within 2 months of
award of contract
PIU, Jal Shakti Vibhag,
Hamirpur, HP
Delivery: Within 2 months of
award of contract
PIU, DOH, Navbahar,Shimla,
HP
Delivery: Within 2 months of
award of contract

03

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 18 -->

Attachment I – LOT 12
SUPPLY AND DELIVERY SCHEDULE
Office Equipment and PMU Field Equipment
TV SCREEN FOR VC SYSTEM

Items

TV Screen

Total

Unit

Quantity
(A)

Nos

03

Nos

01

Nos

01

Unit
Price
(B)
Rs*

Goods’
Cost,
C = (A x
B) Rs*

Transportation
Cost (D)
Rs*

Total
Price,
C+D
Rs**

GST

Total Quotation
Price incl GST

Location and
Delivery Period
PMU
Directorate of Horticulture,
Navbahar, Shimla, HP
Delivery: Within 2 months
of award of contract
PIU, Jal Shakti Vibhag,
Hamirpur, HP
Delivery: Within 2 months
of award of contract
PIU, Deptt. Of Horticulture,
District Bilaspur, HP
Delivery: Within 2 months
of award of contract

05

In accordance with Purchaser’s right to quantity variation under 4(i) of Request for Quotation Letter, the quantity of the items contracted for supply
may vary from the quantity mentioned in the Supply and Delivery Schedule.

<!-- page 19 -->

Attachment II
Technical Requirements and Specifications
Office Equipment for PMU Field Equipment are to be supplied to 7 districts for official use under the
Himachal Pradesh Subtropical Horticulture, Irrigation and Value Addition Project (HPSHIVA). The Itemwise technical requirements and specifications of the required items are indicated herein.
Bidder is required to indicate the offered Technical Specifications in the following Attachment II Schedules
and submit it along with the Price Quotation.

<!-- page 20 -->

Attachment II – Lot 1
LAPTOP-A (PMU)
S.
No.

Item

Purchaser’s Required Specifications

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:
1
2

Operating System
Processor

3
4

Memory
Display & Graphics

5

Ports

6
7

Hard Drive
Network Interface

8

Software

9
10

Keyboard
Webcam

11
12
13

Battery
Wireless connectivity
Warranty

14
15

Bag
Installation Support and
Demonstration of
Commissioning

Window10 or latest (Licenced)
Core i7 (4.7 GHz Processor) 10th
Gen or Equivalent
8GB DDR4 (2x4GB) or more
14" FHD, Backlit, 1920x1080,
multitouch enable, IPS
1 Superspeed USB type c, display
port 1.4, 2 superspeed USB type
a5Gbps, 1HDMI 2.0, 1AC smartpin,
head phone/ mic combo
HDD 512GB and 1TB SSD
Intel Wi-Fi6Ax201(2x2) & Bluetooth
5 combo
MS Office 2019 or latest preferrably
with key, pre installed (Licenced)
Backlit, English(India)
Wide vision 720p HD with integrated
dual array digital microphones
Li-ion Fast charging upto 8 hrs
Wifi & bluetooth combo
3 Year
For Warranty purposes, the Supplier
is responsible for collection and
delivery of the equipment from the
Purchaser’s premises
bag to carry laptop
Required at Delivery Site/s

<!-- page 21 -->

Attachment II – Lot 2
LAPTOP-B (PMU/PIU)
S.
No.

Item

Purchaser’s Required Specifications

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:
1

Operating System

2

Processor

3
4

Memory
Display & Graphics

5

Ports

6
7

Hard Drive
Network Interface

8

Software

9

Keyboard & Mouse

10
11
12

Camera
Battery
Warranty

14
15

Bag
Installation Support and
Demonstration of
Commissioning

64 -bit Microsoft Window10 or latest
(Licenced)
11th Gen Core i5 (4.2 GHz Processor)
or Equivalent
16GB DDR4 (2x8GB)
15.6" Full HD, Anti-Glare, Backlit,
1920x1080,NVIDIA GeForce
MX450(2GB GDDR5)
1Superspeed USB type- C, 1-2
Superspeed USB Type-A; HDMI 2.0: 1
Headphone/ microphone Combo
HDD 512GB and 1TB SSD
Intel Wi-Fi6Ax201(2x2) & Bluetooth 5
combo
MS Office 2019 or latest preferrably
with key, pre installed (Licensed)
Backlit, English(India) with mouse
track pad
Integrated HD Camera with Mic
Li-ion Fast charging upto 8 hrs
3 Year
For Warranty purposes, the Supplier is
responsible for collection and delivery
of the equipment from the
Purchaser’s premises
bag to carry laptop
Required at Delivery Site/s

<!-- page 22 -->

Attachment II – Lot 3
LAPTOP-C (FIELD OFFICES)
S.
No.

Item

Purchaser’s Required Specifications

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:
1

Operating System

2

Processor

3
4

Memory
Display & Graphics

5

Ports

6
7

Hard drive
Network Interface

8

Software

9

Keyboard & Mouse

10
11
12

Camera
Battery
Warranty

14
15

Bag
Installation Support and
Demonstration of
Commissioning

64 -bit Microsoft Window10 or latest
(Licensed)
11th Gen Core i5(4.2 GHz Processor)
or Equivalent
8GB DDR4 Expandable upto 16 GB
15.6" Full HD, Antiglare, Backlit,
1920x1080
1Superspeed USB type- C, 1-2
Superspeed USB Type-A; HDMI 2.0: 1
Headphone/ microphone Combo
At least 512GB SSD
Intel Wi-Fi6Ax201(2x2) & Bluetooth 5
combo
MS Office 2019 or latest preferrably
with key, pre installed (Licensed)
Backlit, English(India) with mouse
track pad
Integrated HD Camera with Mic
Li-ion Fast charging upto 8 hrs
3 Year
For Warranty purposes, the Supplier
is responsible for collection and
delivery of the equipment from the
Purchaser’s premises
bag to carry laptop
Required at Delivery Site/s

<!-- page 23 -->

Attachment II – Lot 4
DESKTOP (ALL IN ONE)
S.
No.

Item

Purchaser’s Required Specifications

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:
1

Operating System

2

Processor

3
4

Memory
Display & Graphics

5

Ports

6
7
8
9
10
11
12

Expansion Slot
Minimum 2M. 2Slots
Internal Bays
External Bays
Hard drive
Keyboard & Mouse
Software

13
14

Wireless
Webcam

15

Warranty

16

Installation Support and
Demonstration of
Commissioning

64 -bit Microsoft Window10 or latest
(Licensed)
Core i5 10th Gen. or Higher , 2.0 GHz
or Equivalent
8GB DDR4 Expandable upto 32 GB
23.8" with 1440x900 FHD resolution
or higher with Intel Graphic
integrated
1 Superspeed USB type a5Gbps, 1
Headphone/ microphone Combo,
HDMI Port
2M.2(1 for SSD, 1 for WLAN)
1M.2 for Wi-Fi, 1M2 for PCleSSD
1x3.5 Bay, 1x2.5 Bay
1x Slim ODD
512 GB SSD and 1TB HDD or more
Wireless
MS Office 2019 or latest preferrably
with key, pre installed (Lincensed)
Wifi and bluetooth combo
Camera with integrated dual array
digital microphones
3 years
For Warranty purposes, the Supplier
is responsible for collection and
delivery of the equipment from the
Purchaser’s premises
Required at Delivery Site/s

<!-- page 24 -->

Attachment II- Lot 5
UPS HARDWARE FOR DESKTOP

S.
No

Item

Purchaser’s Required Specifications

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:
1.

Capacity

600 VA Offline

2.

Certifications

3.

Input Voltage Range

1) CE/Equivalent Certificate.
2) Should be EU RoHS / WEEE/ ISO
14001 Compliant
160 V AC - 270V AC

4.

Nominal Output Voltage 220/230/240 VAC +/- 3%

5.
6.

Output Voltage
regulation
Output Load capacity

7.

Overload capacity

8.
9.

Storage/Operating
Temp.
Short Circuit

10.

Surge / Spikes

Electronic current limit on inverter
mode/ MCB protection on Mains
mode
Through Line Filters

11.

DC under voltage

Yes

12.

Overload

Yes

13.

ALARMS

Mains failure, Fault conditions, Low
battery, Overload

14.

Warranty

15

Installation Support and
Demonstration of
Commissioning

Minimum 2 year
For Warranty purposes, the Supplier
is responsible for collection and
delivery of the equipment from the
Purchaser’s premises
Required at Delivery Site/s

230+/- 3 % ( on Battery )
600 VA (Minimum 20 Minutes battery
backup)
At 120% load minimum 1 Min
0 – 45 °C

<!-- page 25 -->

Attachment II – Lot 6
PRINTER SCANNER COPIER (BLACK & WHITE)
S.
No.

Item

Purchaser’s Required Specifications

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:
1

Product Type

2

Print Speed & Time

3
4

Memory
Duty Cycle

5
6
7

Automatic paper Sensor
Processor speed
Top Key feature

8
9
10
11

Yield
Connectivity
Scan resolution & Type
Media size custom

12
13

Print quality
Copier specification

14
15

System requirement
Warranty

16

Installation Support and
Demonstration of
Commissioning

Laser Print, Scan, Copy- Black &
White
upto 20 pages per minute Black(A4),
7.6 Sec
64MB
Upto 20,000 Pages under normal
busy office environment
Yes
500 MHz
Scan to PDF, ID copy, 150 sheet Input
tray, LCD control panel
2500 pages
Hi seed USB2.0 Built in Wi-Fi802.11
Flat Bed, 600ppi
Media sizes supported:A6,A5, A4,
Letter ,4.13x5.85 to 8.5x11.69"
Min. 600x600x2dpi
Upto99 copies,25-400%, Light/dark
option
Window OS, Apple OS, Mac OS
Minimum 1 year
For Warranty purposes, the Supplier
is responsible for collection and
delivery of the equipment from the
Purchaser’s premises
Required at Delivery Site/s

<!-- page 26 -->

Attachment II – Lot 7
PRINTER SCANNER COPIER (COLOUR)
S.
No.

Item

Purchaser’s Required Specifications

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:
1

Product Type

2

Print speed & Time

3
4
5
6

Memory
Duty Cycle
Processor speed
Top Key feature

7
8
9
10
11
12
13
14

Yield
Connectivity
Scan resolution
Media size custom
Print quality
Copier specification
System requirement
Warranty

15

Installation Support and
Demonstration of
Commissioning

Inkjet Color Print, Scan, Copy,ADF &
Wireless
11-5ppm/Black- Color(A4,ISO),76
Sec.,14-22cpm/Color-Black (Draft) &
2-10cpm/ Color-Black(ISO)
256MB
Upto 1000 Pages
1.2 GHz
Scan to PDF, 35 pages ADF, 2.2"
Touch screen
6000 Black, 8000 Color Pages
Dual Band Wi-Fi
1200ppi
7.62x10.16 to 21.59x35.56
Min. 1200x1200dpi
Upto99 copies,25-400%
Window OS, Mac OS
Minimum 1 year
For Warranty purposes, the Supplier
is responsible for collection and
delivery of the equipment from the
Purchaser’s premises
Required at Delivery Site/s

<!-- page 27 -->

Attachment II – Lot 8
TABLET
S.
No.

Item

Purchaser’s Required Specifications

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:
1
2

3
4
5
6

Display
Camera
SIM
Processor
RAM
ROM
External Memory
Support

7

Operating system

8

Connectivity

9

Sensors

10

Battery
Colour
Warranty

11
12

13

Installation Support and
Demonstration of
Commissioning

10 inch or above TFT
8MP Main, 5 MP Front,
FHD(1920x1080)
Yes (Micro/ Nano)
Octacore 2GHz, 1.8GHz
3GB or more
32GB
Micro SD upto 1TB
Android 9.0 or preferrably latest
version
USB 2.0 ,GPS, 4G, 802.11a/b/g/n/ac
2.4G+5GHz, Wi-Fi direct, Bluetooth
5.0
Accelerometer, Gyro sensor,
Geomagnetic, Hall, Light sensor
Min. 7000mAh
Gold/Silver/Black/ Grey
Mínimum 1 year
For Warranty purposes, the Supplier
is responsible for collection and
delivery of the equipment from the
Purchaser’s premises
Required at Delivery Site/s

<!-- page 28 -->

Attachment II – Lot 9
HAND HELD GPS DEVICE
S.
No.

Purchaser’s Required Specifications

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:

3

High sensitivity GPS, GLONASS, other reciver
with quad helix antenna
8MP or more autofocus camera with
automatic geotagging
Wireless connectivity via bluetooth

4

SIM Module for data transfer

5

Sunlight readable color screen

6

Custom attribute collection capabilities

7

10

Supports computer based PC software for
data processing
Rechargeable NiMH pack or Lithium battery
pack
Hi speed USB & NMEA 0183 compatible
interface
Memory 8GB or more- micro SD support

11

waypoint/location 5000 or more

12

Custom map & satellite imagery support

13

High sensitivity GPS, GLONASS, other receiver
with quad helix antenna
Mínimum 1 year
For Warranty purposes, the Supplier is
responsible for collection and delivery of the
equipment from the Purchaser’s premises
Installation Support and Demonstration of
Commissioning required at deliver site/s

1
2

8
9

14

15

<!-- page 29 -->

Attachment II – Lot 10
PHOTOSTAT MACHINE

Item

Purchaser’s Required Specifications

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:
1

15

Warm-Up Time (Time from
device power on, until copy
ready)
Recovery from sleep mode
First Copy Time (A4)
Memory
Power Supply
Power Consumption
Maximum Power
Consumption:
When the machine is in the
Sleep mode:
Toner Yield (A4, 6%
coverage)
Drum Yield
Copy/Print Speed A4
Copy/Print Speed A3
Print Resolution
Page Description
Language(s)
Print OS Compatibility

16
17

Interface
Network

18
19
20

Others (Local Print/Scan)
Network Protocol

21
22

Copy Resolution
Multiple Copies/Prints

2
3
4
5
6
7
8
9
10
11
12
13
14

Approximately 13s

Approximately 4.3s
Approximately 7.4s
512 MB
220 to 240 V AC, 50/60 Hz, 2.7 A
1.5 kWh
2W
10000 sheets (A4, 6% coverage) or
more
65 000 sheets or more
22 ppm (Minimum)
11 ppm (Minimum)
600 x 600 dpi
UFRII LT (Standard), PCL6 (Optional)
Windows 10/8.1/7, Windows Server
2008/2008 R2/2012/2012 R2/ 2016,
Mac OS X 10.9.5
Ethernet 100Base-Tx/10Base-T (IEEE
802.3 compliant), WLAN IEEE
802.11b/g/n
USB2.0 x 1
TCP/IP (IPv4/IPv6), USB
Frame type: Ethernet II
Print applications:
LPD/Raw/IPP/IPPS/WSD/Mopria
/Google Cloud
Print/AirPrint/Windows10 Mobile
Print
600 x 600 dpi
999 copies

<!-- page 30 -->

23
24

Magnification
Destination

25

Scan Speed (Simplex, A4,
200dpi)

27
28
29

SEND Resolution
SEND File Format
Destination

30
31

Supported Protocol
Scan Speed (Simplex, A4,
300 dpi)

32

Scan Resolution

33

Scan File Format

34

Scan OS Compatibility

35

Network

36

Paper Sizes
Cassette 1

37
38

Cassette 2
Multi Purpose Tray

39

40
41
42
43

43

Paper Input Capacity
(Standard)
Cassette 1
Cassette 2 (Optional)
Multi Purpose Tray
Warranty

Installation Support and
Demonstration of
Commissioning

25% -400% (1% increment)
Scan to Email (SMTP), network folders
(SMB)
BW: 13 sheets/min (Minimum)
Colour: 6 sheets/min (Minimum)
BW/Colour 300 x 300 dpi
PDF/Compact PDF/JPEG/ TIFF
MF Scan Utility, application
compatible with TWAIN/WIA
TCP/IP, USB
BW: 23 sheets/min (Minimum)
Colour: 12 sheets/min (Minimum)
BW: 600 x 600 dpi
CL: 300 x 600 dpi
TIFF/JPEG/PNG/PDF(Compact,
Searchable)/PDF(Divided into SinglePage Files)
Windows 10/8.1/7, Windows
Server2008/2008 R2/2012/2012
R2/2016,
Mac OS X 10.9.5
Standard: IP/Mac Address Filtering,
TLS Encrypted Communication, SNMP
V3.0, IEEE 802.1X, IPv6, SMTP
Authentication, POP Authentication
before SMTP
A3,B4,A4R,A4,B5,B5R,A5R,India-LGL,
FOOLSCAP
A3,B4,A4R,A4,A5,B5,B5R
A3,B4,A4R,A4,B5,B5R,A5,A5R,IndiaLGL,
FOOLSCAP, Envelope (COM 10,
Monarch, ISO-C5, DL)

250 sheets (80g/m²)
250 sheets (80g/m²)
80 sheets (80g/m²)
3 year
For Warranty purposes, the Supplier
is responsible for collection and
delivery of the equipment from the
Purchaser’s premises
Required at Delivery Site/s

<!-- page 31 -->

Attachment II – Lot 11
ROOM BASED ENDPOINT VIDEO CONFERENCE SYSTEM

Sr.
No.

Description

Specification Parameter

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:
1

Package

2

Video Standards and
Resolutions

3

Content Standards and
Resolutions

4

Audio Standards and
Features

5

Video and Audio Inputs

Full HD 1080p60 PTZ Camera, Codec,
Microphone Array, Cables and
Wireless Remote Control/Touch
Panel
It should support H.323 & SIP
standards for communications.
It should support interoperability
and bandwidth saving using video
compression H.261, H.263, H.264
AVC, H.264 SVC, H.264 High
Profile/H.265
It should support 1080p 60 fps,
1080p 30 fps, 720p 60 fps, 720p
30fps & 4CIF.
It should support content sharing
using standard based H.239 &
BFCP.It should also support audio
from PC used for content sharing.
It should transmit both people and
content both simutaneously to the
far end location at 1080p 30fps
It should support G.711, G.728,
G.729A, G.722, G.722.1, G.722.1
Annex C, G.719, AAC-LD or better
It should support 20kHz or better
bandwidth with crystal clear audio
and stereo sound.
Automatic Gain Control and
Automatic Noise Suppression
Keyboard noise reduction and
instant adaptation echo cancellation
1 x HDMI/HDCI input for connecting
main FHD camera
1 x HDMI/DVI input to share FHD
content from PC/Laptop/Document
camera.
1 x VGA input for content sharing
through PC/Laptop alongwith audio.

<!-- page 32 -->

6

Video and Audio Outputs

7

Other Interfaces

8

Camera

9

Network Features

10

Multisite Feature

11

Security

1 x Microphone Input or more with
support for minimum 4 mics. The
bidder needs to quote 1 microphone
with 360 degree coverage from day
one with mute/unmute button on
the microphone.
1 x RCA/3.5mm stereo line-in
2 x HDMI output for connecting
primary & secondary FHD display.
1 x RCA/3.5 mm stereo line-out
1 x 10/100/1000 Ethernet port
2 x USB for software upgrade and
connecting external devices
1 x RS-232 interface to integrate the
system with external room controller
1/2.33" CMOS Sensor or better
The camera should support
minimum 10x optical zoom, PAN +/100°, Tilt +20/-30° & minimum 10
camera presets.
The camera system should be future
upgradable (via additional system)
for advanced voice & facerecognition technology such that it
automatically scans the room and
seamlessly commands the main
camera to appropriately frame the
users/speaker during a call without
any manual intervention.
Video Conference Camera and Codec
should be controlled using same
remote control/touch panel.
H.323 and SIP bandwidth support
from 64 kbps to 6 Mbps or more
Must support IPv4 and IPv6 from day
one on both H.323 and SIP.
Auto Gatekeeper Discovery, Auto SIP
Registrar Discovery, IP Precedence,
Diffserv & QoS with support for
H.323 based lost packet recovery.
It should support inbuilt multiparty
feature with support for 1+5 sites at
HD resolution with all sites
encryption in future via adding
software license.
Media Encryption (H.323, SIP): AES128, AES-256
Authenticated access to admin
menus, web interface and telnet API

<!-- page 33 -->

12

Other features

13

Compatibility

14

Others

15

Warranty

16

Installation Support and
Demonstration of
Commissioning

Local account password policy
configuration
Local and LDAP Directory support
H.460.18, H.460.19, SSL, TLS, HTTP,
HTTPS, H.235.6 support
End Point should be compatible and
configurable with the polycom real
presence clariti MCU
The proposed system must support
PAL/equivalent with PTZ camera.
The codec must be based on ITU
standards & hardware based. No
software based solution will be
accepted. All components of the VC
system like Codec, Camera,
Microphones and Wireless Remote
Control/Touch Control Panel should
be from the same OEM.
The complete solution should be
from the same OEM with minimum 1
year of warranty
For Warranty purposes, the Supplier
is responsible for collection and
delivery of the equipment from the
Purchaser’s premises
Required at Delivery Site/s

<!-- page 34 -->

Attachment II – Lot 12
TV SCREEN FOR VIDEO CONFERENCE SYSTEM

S.
No.

Parameter

Minimum Specification

Bidder’s Offered Specifications
(Bidder to indicate here)

Manufacturer:
Brand and Model:
1
2
3
4
5
6
7
8
9

Size
Resolution
Brightness
Response time
Connectivity
View Angle
Audio
Operating Voltage
Accessories

10

Warranty

11

Installation Support and
Demonstration of
Commissioning

55" Backlit Display or higher
4K UHD or higher
500cd/m3
8 ms or less
HDMI in, VGA in, USB 2.0
176 Degree(H) & 176 Degree (V)
20 Watts
AC 110 ~ 220V, 50/60 HZ
Power Cord, IR Remote Control
(With battery), Wall mount and
Stand kit
3 Years Comprehensive
For Warranty purposes, the Supplier
is responsible for collection and
delivery of the equipment from the
Purchaser’s premises
Required at Delivery Site/s

<!-- page 35 -->

FORM OF QUOTATION
(OFFICE EQUIPMENT AND PMU FIELD EQUIPMENT)
_________ (Date)
To:
The Project Director,
Himachal Pradesh Subtropical Horticulture, Irrigation and Value Addition Project: Project Readiness
Financing Project (HP-SHIVA PRF)
Department of Horticulture,
Navbahar, Shimla, Himachal Pradesh 171002
We offer to execute the___________________________________________[name and number of
Contract and item reference] in accordance with the Contract Terms and Conditions and the priced Supply
and Delivery Schedule
accompanying this
Quotation for the
Contract
Price
of
_________________________[amount
in
words
and
numbers]
(______________)
[name
of
currency]_____________. We propose to complete the delivery of Goods described in the Contract within
the Delivery Time indicated in the priced Supply and Delivery Schedule (Attachment 1) and in
accordance with the Technical Specifications (Attachment II).
This Quotation and your written acceptance will constitute a binding Contract between us. We
understand that you are not bound to accept the lowest or any Quotation you receive.
We hereby confirm that this Quotation complies with the Validity of the Offer and Warranty
conditions imposed by the Request for Quotation document and the Contract Terms and Conditions,
respectively.
We: (a) are a national of an ADB member country; (b) have not been associated with the firm that
prepared the design and specifications of the contract that is subject of this request for quotation; (c) are
not owned by the Purchaser; (d) are not currently sanctioned or temporarily suspended by the Asian
Development Bank; and (e) to the best of our knowledge, is not prohibited from being contracted in
compliance with a decision of the United Nations Security Council.
Name of Supplier

: ________________________________

Authorized Signature

: ________________________________

Name of Signatory

: ________________________________

Title of Signatory

: ________________________________

Address

: ________________________________

Telephone Number

: ________________________________

Fax Number, if any

: ________________________________

Email address (optional): ________________________________

<!-- page 36 -->

ACCEPTANCE
The Purchaser accepts the Supplier’s offer to supply and deliver the goods. Attached is the Contract with
accepted Contract price for Supplier’s signature to be submitted to the Purchaser within 15 days from
receipt. Please provide a Performance Security for the due performance of the Contract, within 15 days of
receipt of this returned Form of Quotation, in the amount equivalent to 10% of the Contract Price, either
in the form of Fixed Deposit Receipt (FDR) or Bank Guarantee (BG) in favor of “The Project Director,
Himachal Pradesh Subtropical Horticulture, Irrigation and Value Addition Project”.
Name of Purchaser

: ________________________________

Authorized Signature: ________________________________
Name of Signatory

: ________________________________

Title of Signatory

: ________________________________

Date

: ________________________________

<!-- page 37 -->

CONTRACT
Name of Country: India
Project Name: Himachal Pradesh Subtropical Horticulture, Irrigation and Value Addition Project:
Project Readiness Financing Project (HP-SHIVA PRF)

Name of Contract: Supply of goods office furniture, equipment and material under HPSHIVA PRF
Contract Number: 19-27 (EAP-HPSHIVA-E-TENDER-G5)2020-21
This Contract is entered into on ______[date] day of ______[month]_,____ __[year], between the
Department of Horticulture, Government of Himachal Pradesh (hereinafter called “the Purchaser”) on the
one part, and _________________________[name of Supplier] (hereinafter called “the Supplier”) on the
other part.
Whereas the Purchaser has requested for quotation for ‘office furniture, equipment and material’ to be
supplied by Supplier in accordance with the Contract and has accepted the Quotation by the Supplier in
the amount of ________________________________[amount in words]_______________[amount in
figures]hereinafter called “the Contract Price”.
The Purchaser and the Supplier agree as follows:
1. The following documents shall be deemed to form and be read and construed as part of this Contract,
viz:
a) Form of Quotation, with priced Supply and Delivery Schedule
b) Contract Terms and Conditions; and
c) Technical Specifications
2. Taking into account payments to be made by the Purchaser to the Supplier as provided herein, the
Supplier hereby enters into this Contract with the Purchaser to execute and complete the supply of
goods under the Contract and remedy any defects therein in conformity with the provisions of this
Contract and its Terms and Conditions.
3. The Purchaser agrees to pay the Supplier, in consideration of the supply and delivery of the goods
and the remedying of defects therein, the Contract Price as indicated and accepted in the Form of
Quotation, under payment terms stipulated in the Contract Terms and Conditions.
IN WITNESS whereof the parties hereto have executed the Contract under the laws of India on the date
indicated above.

Signature and seal of the Purchaser:
For and on behalf of

Signature and seal of the Suppler:
For and on behalf of

_____________________________
Name of Authorized Representative

_____________________________
Name of Authorized Representative

<!-- page 38 -->

CONTRACT TERMS AND CONDITIONS
Project Name: Himachal Pradesh Subtropical Horticulture, Irrigation and Value Addition Project: Project
Readiness Financing Project (HP-SHIVA PRF)
Purchaser: Department of Horticulture, Himachal Pradesh
Package No.19-27 (EAP-HPSHIVA-E-TENDER-G5)2020-21

1.

Definitions
(a)

(b)
(c)

(d)
(e)
(f)

“Contract” means the agreement entered into between the Purchaser and the Supplier,
together with the Contract Documents referred to therein, including all attachments,
appendixes, and all documents incorporated by reference therein.
“Contract Documents” means the documents listed in the Agreement, including any
amendments thereto.
“Contract Price” means the price payable to the Supplier as specified in the Agreement,
subject to such additions and adjustments thereto or deductions therefrom, as may be
made pursuant to the Contract.
“Delivery” means the transfer of the Goods from the Supplier to the Purchaser in
accordance with the terms and conditions set forth in the Contract.
“Completion” means the fulfilment of the delivery and any related service by the Supplier in
accordance with the terms and conditions set forth in the Contract.
“Goods” means the that the Supplier is required to supply ‘office equipment and PMU field

equipment’ to the Purchaser under the Contract.
(g)
(h)

(i)

“Purchaser” means the entity purchasing the Goods and Related Services, i.e. Department
of Horticulture, Himachal Pradesh.
“Supplier” means the natural person, private or government entity, or a combination of the
above, whose bid to perform the Contract has been accepted by the Purchaser and is
named as such in the Agreement, and includes the legal successors or permitted assigns
of the Supplier.
“ADB” is the Asian Development Bank.

2.
2.1

Applicable Law
The Contract shall be interpreted in accordance with the laws of India.

3.
3.1

Language
All communications and documents related to the Contract shall be in English or Hindi.

4.
4.1

Assignment
Any assignment of this Contract or of any rights hereunder, in whole or in part without the prior
written consent of the Purchaser shall be void.

5.
5.1

Fraud and Corruption
This Contract shall be covered by the provisions of ADB’s Anticorruption Policy (1998, as
amended to date) and Integrity Principles and Guidelines (2015, as amended from time to time)
that requires Borrowers (including beneficiaries of ADB-financed activity), as well as Suppliers
and Contractors under ADB-financed contracts, to observe the highest standard of ethics during
the procurement and execution of such contracts.

<!-- page 39 -->

6.
6.1

Fixed Contract Price
The prices indicated in the Form of Quotation are firm and fixed and not subject to any
adjustment during contract performance.

7.
7.1

Delivery Schedule
The delivery should be completed as per schedule indicated in the Supply and Delivery
Schedule but not exceeding two months from the date of signing of contract.

8.

Required Technical Specifications (with attachments as necessary)
(a) General Description
(b)
Specific details and technical standards
(c)
Performance Parameters
Supplier confirms compliance with above specifications.

9.
9.1

Delivery and Documents
Upon delivery, the Supplier shall provide the following documents to the Purchaser:
(a) copies of the Supplier’s invoice showing goods’ description, quantity, unit price, and total
amount;
(b) manufacturer's or supplier's warranty certificate; and
(c)
certificate of origin.
If goods are coming by courier or transportation, the supplier shall also provide prior to delivery,
copies of documents that will enable the Purchaser to receive the goods. The above documents
shall be received by the Purchaser at least one week before arrival of the goods and, if not
received, the Supplier shall be responsible for any consequent expenses.

10.
10.1

Taxes and Duties
The Supplier shall be entirely responsible for all taxes, duties, license fees, etc., incurred until
delivery of the contracted Goods to the Purchaser.

11.
11.1

Payment
Payment of the contract price shall be made in the following manner:
(a)
(b)
(c)

10% within 14 days of signing the contract. Payment shall be made upon presentation by
the Supplier of verifiable proof of availability of goods ready for shipment/delivery.
80% within 30 days from receipt by the Purchaser of the delivered goods on site in
accordance with the contract including the required documents; and
10% within 14 days upon submission of the Supplier’s claim supported by the Acceptance
certificate issued by the Purchaser.

12.

Warranty

12.1

Goods offered should be covered by manufacturer’s warranty as mentioned in the technical
specifications from the date of delivery to the Purchaser.

12.
13.1

Defects
All defects will be corrected by the Supplier without any cost to the Purchaser within 30 days from
the date of notice by Purchaser.

<!-- page 40 -->

13.
14.1

Resolution of Disputes
The Purchaser and the Supplier shall make every effort to resolve amicably by direct informal
negotiation any disagreement or dispute between them under or in connection with the Contract.
In the case of an unresolved dispute between the Purchaser and the Supplier, the dispute shall
be settled in accordance with the provisions of the Arbitration and Conciliation Act, 1996.

14.
15.1

Failure to Perform
The Purchaser may cancel the Agreement if the Supplier fails to deliver the Goods, in accordance
with the above terms and conditions, despite a 14-day notice given by the Purchaser, without
incurring any liability to the Supplier.

15.
16.1

Force Majeure
The Supplier shall not be liable for penalties or termination for default if and to the extent that its
delay in performance or other failure to perform its obligations under the Contract is the result of
an event of Force Majeure.
(a) For purposes of this Clause, “Force Majeure” means an event beyond the control of the
Supplier and not involving the Supplier’s fault or negligence and not foreseeable. Such
events may include, but not restricted to, act of the Purchaser in its sovereign capacity,
wars or revolutions, fires, floods, epidemics, quarantine restrictions, and freight embargoes.
(b) If a Force Majeure situation arises, the Supplier shall promptly notify the Purchaser in
writing of such condition and the cause thereof. Unless otherwise directed by the Purchaser
in writing, the Supplier shall continue to perform its obligations under the Contract as far as
is reasonably practical and shall seek all reasonable alternative means for performance not
prevented by Force Majeure event.

16.
17.1

Termination Due to Integrity Violation
The Purchaser may terminate this Contract, in whole or in part, if the Supplier, in the judgment of
the Purchaser has engaged in integrity violations in accordance with Clause 5 [Fraud and
Corruption], in competing for or in executing this Contract.

17.
18.1

Accounts and Records
The Supplier shall keep accurate and systematic accounts and records in respect of the delivered
goods in such form and detail as are customary in the industry, for a period of no less than
3 years after the expiration or termination of this Contract.

18.
18.1

Suspension of ADB Loan or Credit
In the event that ADB suspends the Loan or Credit to the Purchaser, from which part of the
payments to the Supplier are being made,
(a) the Purchaser is obligated to notify the Supplier, with copy to the Purchaser’s representative,
of such suspension within 7 days of having received ADB’s suspension notice.
(b) if the Supplier has not received sums due it within the 28 days for payment provided for in
Clause 11 [Payments], the Supplier may immediately issue a 14-day termination notice.

19.

Other Criteria
The bidder shall also include a Health and Safety COVID-19 Plan, in accordance with the
relevant government regulations and guidelines on COVID-19 prevention and or in the
absence thereof, to international good practice guidelines such as World Health Organization.
2020. Considerations for public health and social measures in the workplace in the context of
COVID-19. Geneva. Available here: https://www.who.int/publications-detail/considerationsfor-public-health-and-social-measures-in-the-workplace-in-the-context-of-covid-19] Absence
of or incomplete submission may result in rejection of bid.
