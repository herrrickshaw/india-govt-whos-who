---
doc_id: "3f498c0a1b5fdcec"
source_url: "https://www.hrtchp.com/web-content/pdf/2026/NOTICE_Carbon_Credits.pdf"
ministry: "Himachal Road Transport Corporation (HRTC), Himachal Pradesh"
title: "Tender cancellation Notice for the Selection of Agency for the Carbon Credits for Himachal Road Transport Corporation."
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "9d57b7235bc0b8d3"
---

<!-- page 1 -->

Notice
va The RFP invited for the Selection of Agency to Develop and Assist in
alidati _ i
idation (by Monitoring, Reporting, Verification — MRV), Registration,
Verificati we :
7 ation, and Monetization of Carbon Credits for Himachal Road Transport
orporati i
poration, Himachal Pradesh for a period of 5 years in official website of the
igh https://www.hrtehp.com
C hittps://www.hrtehp.comin the E-Tendering menu under the General
Informati https://hptenders.gov.in
nformation orhttps://hptenders. ov.in on 4.03.2026, has been cancelled.
Date : 4.07.2026
Sd/-
Divisional Manager (Tech)
HRTC, Shimla-7003
