---
doc_id: "a5d7ff3eced512e6"
source_url: "https://cdn.s3waas.gov.in/s3577bcc914f9e55d5e4e4f82f9f00e7d4/uploads/2026/01/17691445269432.pdf"
ministry: "Chamba"
title: "extension orders (297 KB)"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d1e0426517c6f504"
---

<!-- page 1 -->

W774546/2026

No.

Government of Himachal Pradesh
Office of the Deputy Comnmissioner Chamba
District Chamba

CBA-SK-18(10y/2013 Voll.-1-194-1223 Dated Chanba

21, January, 2026.

OFFICE ORDER
In continuation of this office order No. CBA-SK-1810)/2013 Vol.-I|-6876-6903, dated
08.01.2026, it is hereby ordered that the last date for inviting applications for re-engagement o teued
Tehsildars / NaibTehsildars / Kanungos / PatWais apainst vacant Tehsil / Sub-Tehsil / Kanungo / Patwar

Circles on remuneration basis under the establishment of the Deputy Commissioner, Chamba District,
Chamba, from eligible candidates on need basis, is extended up to 31.01.2026, in the public inierest.

Signed by
Mukesh Repaswal

Dae:Mukesh
20-01-2026
Repaswal, 19:35:33
Deputy Commissioner
Disrict Chamba (H.P.

Endst. No. As Above

94-|223

Dated

2,January 2026

Copy forwarded for information and necessary action to:
1.

The ACS-cum-F.C. (Revenue) to the Government of Himachal Pradesh, Shimla.

2.

The Director, Land Records of Himachal Pradesh Shimla.

3. The Divisional Commissioner Kangra at Dharamshala (HP).

Allthe Sub Divisional Officers (Civil) in District Chamba (HP).

4

All the Tehsildars/Naib-Tehsildars in District Chamba (HP).
5
6. The DIO, NIC Chamba with the request to upload advertisement along with proforma /application
form on the official website of this office.
7. The District Public Relation Officer, Chamba for wide publicity.

8. Notice Board of the Deputy Commissioner Office Chamba (HP).
9.

Guard File.

Signed/

Deputy Commissioner
District Chamba (H.P.
