---
doc_id: "b9e4eb88cbfa7ded"
source_url: "https://lad.hp.gov.in/sites/default/files/documents/RPDyDir2015.pdf"
ministry: "Himachal Pradesh State Audit Department, Himachal Pradesh"
title: "Deputy Director/ Deputy Controller (Class-I Gazetted)"
date: ""
pages: 7
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "1acf621b03a36c5e"
---

<!-- page 1 -->

_ इस्‍क्‍' कलश डहर:झ-डझ अ--. -_ .
Y sssthoritative English Text of this Nobtication/No.t -58/69-Fin (LA) Part (), dated : og
J+: vilas required under clause (3) of Articles 348 of the Constitution of India. Articles 348 of the Constitution of India. iB
po ~ Government of Himachal Pradesh हे | :
7 Local Audit Department. } |
ie i
NOTIFICATION | |
In exercise of the powers conferred by proviso to Article 309 of the ' i
Constitution of India, the Governor, Himachal Pradesh, in consultation with the a
Himachal Pradesh Public service Commission, is pleased to make the Recruitment ue
and Promotion Rules for the post of Deputy Director/Deputy Controller (Local Audit : Ba
Department), Class-! (Gazetted) in the Local Audit Department, Himachal Pradesh as 4 |
per Annexure “A” attached to this notification, namely:- | pa
|
| Short title | | | - | (i) = rules may be called = Himachal Pradesh Local i | ॥
| Commencement. Audit Department Deputy Director/ Deputy Controller ॥ )
| Class-I (Gazetted) Recruitment and Promotion Rules, Pope
a || }2009 /ऑ॒_ ae
(ii) | These rules shall come into force from the date of 07
| Fy publication in the Rajpatra, Himachal Pradesh. be ee
| Repeal and | 2. | (i) | The Himachal Pradesh local Audit, Department Deputy : 4
Saving. Director/Deputy Controller(Local Audit) (Class-I- Pa
Gazetted) Recruitment and Promotion Rules, 996 |
| notified vide this Department Notification No.-58/69- |
। | Fin (L.A.) Vol-Xl, dated 23.0.996 as amended from
et tt __| time to time are hereby repealed.  _ : :_ . // |;
| | | (ii) | Notwithstanding such repeal, any appointment made or i
| | | anything done or any action taken under the Rules so |
| | | repealed under Sub-rule 2(i) supra shall be deemed to ke
| j | have been validly made, done or taken under these ; | :
0७9. 7.08... os
By Order *
Principal Secretary (Finance) to the :
Government of Himachal Pradesh.
ndst. No.4-§8/69-Fin(LA) Part(Xl), dated, Shimla-77009, the %
Copy forwarded to the following: 4 5 | a 0° 4
| The Secretary to the Governor, H.P., Shimla-77002.
2. The Secretary, H.P. Public Service Commission, Shimla-2.
3 The Special Secretary (Finance-Reg.) to the Govt. of H.P.Shimla-2
| The Deputy Secretary (Personne!) Apptt.-H) to the Govt. of PLP. #
5, A.L.D. (H) Law Department, H.P., Shimla-777002.
6. Shri Chaman Lal, Junior Assistant for publication in the website of Extra-
Ordinary Gazetie. \
7 Suard file (wi 5 spare copie जला
7. Guard file (with 25 spare copies) i 4 ) 7
Special Secretary (LAD) to the
Govt. of IJimachal Pradesh, Shimla-2.

<!-- page 2 -->

fi —SSSSSSSSSsS0—(—(”$(—0€0, MO OOOESESTC oe —————————————
J ie “e
po . —& Annexure-A.
Y Recruitment and Promotion Rules for the post of Deputy Director/ Deputy
J Coals ler Class-l (Gazetted) Post of in the Local Audit Department, Himachal
{ ra = een माासेसललामक3बल->»>
व. | Name of the Post; Deputy Director/ Deputy Controller, (LAD)
(2. | Number of posts; 6690.
«लत >#+ बन eS | नानक दकसलमनननन बल»
| 3. | Classification; Class-| (Gazetted)
| a | Scale of pays |S Rs.7880-220-600-275-0300-340-77660 “|
et Whether selection post or | Selection.
| | non-selection post;
220 ee | मल
| 6. Age for direct recruitment; | Not applicable
(7. | ‘Minimum Educational | Not applicable
| | qualifications required for
| direct recruits;
ro. | Whether age and | Age : Not applicable.
|
| Educational Qualifications | Education Qualification : Not applicable.
| ; prescribed for direct
| ‘recruits will apply in the |
| case of the promotee(s)? |
। 5. Period of probation, if] Two years subject to such further extension for a
j any; period not exceeding one year as may be ordered
| by the competent authority in special circumstances
| |
| and reasons to be recorded in writing.
0.) Method of recruitment, | “400% by promotion. ———~—S
whether by direct |
|| recruitment or by :
i | promotion, deputation,
| | transfer and the
| | percentage of posts to be
‘filed in the various
_ methods.
if Ia case or recruitment by | By promotion from amongst the Assistant
| promotion, deputation, | Director/Assistant Controller (LAD) having three
‘transfer, grades from| years regular servi¢e or regular combined with
| .
| which promotion 7) continuous adhoc service rendered, if any, in the
| | deputation / transfer is to | grade, failing which by promotion from amongst the
| | be made. Assistant Director/ Assistant Controller (LAD) having
I = 5
| Ef |

<!-- page 3 -->

i — _ 9 _ | See

7 oo RSE iby selves is Foyle Somnlied | he o|

j e continuous adhoc service rendered if any combined | |

| | as Assistant Director/Assistant Controller (LAD) and ।

| | Section Officer(LAD) out of which two years service : ।

as Assistant Director/Assistant Controller (LAD) है |

। | shall be essential. {

| (4)In all cases of promotion, the continuous adhoc | |

| service rendered in the feeder post, if any, prior to Io |

| regular appointment to the post shall be taken into | |

। account towards the length of service as prescribed Lo |

in these rules for promotion, subject to the condition [os i

that the adhoc appointment/promotion in the feeder be

| category had been made after following proper |; |

| acceptable process of selection in accordance with i o&

| the provision of R&P Rules: । ;

| Provided that In all cases where a Junior i

| person becomes eligible for consideration by virtue '

| of his/her tota! length of service (including the hoy

| service rendered on adhoc basis, followed by i है | |

regular service/appointment) in the feeder post in ot

view of the provision referred to above, all persons :

| senior to him/her in the respective r |

| category/post/cadre shall be deemed to be eligible vf

| for consideration and placed above the junior person : |

in the field of consideration: tf

Provided that all incumbents to be considered ! ।

| for promotion shall possess the minimum qualifying |

| service of at least three years or that prescribed in| _ |

| the R&P Rules for the post, whichever is less : |

है Provided further that where a_ person ।

| becomes ineligible to be consideration for promotion i

। on account of the requirements of the proceeding !
| proviso, the person(s) junior to him/her shall also be
| deemed to be ineligible for consideration for such

yy

<!-- page 4 -->

हा ...लबलबल>---+नमनननमनरपप77८7“त7याणएणएखणघं।७५थणथदघ२ब+-777॥ह#त०-++-.---ेे॥ेफेै ते "नम अमन किक >> 33. ५०५] [
Wa pn erent a a prt ९० f
| promotion,
J’. Explanation: :
| । हु The last proviso shall not render the junior
fi | incumbents ineligible for consideration for Promotion
| | if the senior ineligible persons happened to be ex— |
| | servicemen recruited under the provisions of Rule-3 i
| | | of Demobilized Armed Forces Personnel ‘
| | | (Reservation of Vacancies in Himachal State Non- !
| | Technical Services) Rules, 972 and having been
| | given the benefit of seniority there under or recruited ts
/ | under the provisions of Rule 3 of the Ex-servicemen |
| | | (Reservation of vacancies in the Himachal Pradesh es
| | Technical Services) Rules, 985 and having been ‘
| । given the benefit of seniority there under. : है
| | | (2) Similarly, in all cases of confirmation continuous ;
| | adhoc service rendered on the feeder post, if any,
i | prior to the regular appointment/promotion against |
। | | such post, shall be taken into account towards the |
| | length of service if the adhoc appointments/ | ५
। | | promotion had been made after proper selection and | ve
| | accordance with the provision of the Recruitment |
। | & Promotion Rules; i i
| Provided that inter-se-seniority as a result of
| confirmation after taking into account, adhoc service | ५
| rendered as referred to above shall remain
| unchanged”. |
jis. if a Departmental | As may be constituted by the Government from time. |
| | Promotion Committee } {6 time fost
| exists, what is its ‘ | &
। composition? |
/ ic. Circumstances under} As required under the law. रो |
q ewhich =the — Himachal ’ |
| Pradesh Public Service |
| Commission is to be
| | consulted in | making |
| ) recruitment. | दि

<!-- page 5 -->

की ््/्/््/्/् ् ््॒£ऋ = ie
Jf essential requirement for | Not applicable |
J ysensionen. के |
% | 3.) Selection for appointment | Not applicable i
| | to the post by direct ।
| | recruitment |
| '6. | Reservation; The appointment to the service shall be subject to |
orders regarding reservation in the service for I

| | Scheduled Casts/ Scheduled Tribes/ Other Ez
| | Backward Classes / Other categories of persons |
| ! issued by the Himachal Pradesh Government from |
es time to time. |
7 | Departmental | “Every member of the service shall pass a’ |

| | Examination; Departmental Examination as prescribed in the H.P. ४
। | Departmental Examination Rules, 997 i
“8. | Powertorelac 7“ | Where the State Government is of the opinion that it |
is necessary or expedient to do so, it may by order |
| for reasons to be recorded in writing and in |
| \ | consultation with the Himachal Pradesh Public
। Service Commission relax any of the provision(s) of |
| | | these Rules with respect to any Class or category of |
i | _ | person(s) or post(s). ।
Noh क मोकसतनम> के pn |
t
i
i

‘

<!-- page 6 -->

रे ल्‍- —
62५ LO
fll» Pm
‘ / को आय
बिक हिमाचल प्रदेश सरकार ees
This is a digitally signed Gazette, to verify click here.
राजपत्र, हिमाचल प्रदेश
हिमाचल प्रदेश राज्य शासन द्वारा प्रकाशित
RFT, GR 6 AF, 208/75 WT, 934
हिमाचल प्रदेश सरकार
स्थानीय लेखा परीक्षा विभाग
अधिसूचना
शिमला-474002, 5 मार्च, 2043

सख्या : 4-58,//69-फिन(एल0ए0)पार्ट(।).---हिमाचल प्रदेश की राज्यपाल, भारत के संविधान के
अनुच्छेद 309 के परन्तुक द्वारा प्रदत्त शक्तियों का प्रयोग करते हुए, इस विभाग की अधिसूचना
संख्या:(-58 / 69-फिन।(एल0ए0)पार्ट()), तारीख 4 मार्च, 2009 द्वारा अधिसूचित हिमाचल प्रदेश स्थानीय लेखा

* परीक्षा विभाग, उप निदेशक,//उप नियन्त्रक, वर्ग-4 (राजपत्रित) भर्ती और प्रोन्नति नियम, 2009 का और
संशोधन करने के लिए निम्नलिखित नियम बनाती है, अर्थातः-

4. संक्षिप्त नाम और प्रारम्भ--() इन नियमों का संक्षिप्त नाम हिमाचल प्रदेश स्थानीय लेखा परीक्षा
विभाग, उप निदेशक /उप नियन्त्रक, वर्ग-4 (राजपत्रित) भर्ती और प्राने नति (प्रथम deter) fas, 2073 है।
249-राजपत्र / 2043-6-3--2043 (709)

|

<!-- page 7 -->

u — ‘
— Th
70 राजपत्र, हिमाचल प्रदेश, 6 मार्च, 2043 /45 फाल्गुन, 7934
(2) ये नियम राजपत्र, हिमाचल प्रदेश में प्रकाशित होने की तारीख से प्रवृत्त होगें |
ह 2. उपाबन्ध “क” के स्तम्भ 2 का संशोधन.-हिमाचल प्रदेश, स्थानीय लेखा परीक्षा विभाग, उप
j निदेशक /उप नियन्त्रक, वर्ग-4 (राजपत्रित) भर्ती और प्रोन्नति नियम, 2009 के उपाबन्ध “क” में :-
y स्तम्भ संख्या 2 के सामने विद्यमान उपबन्धों के स्थान प्रर निम्नलिखित रखा जाएगा, अर्थात :-
“7 (सात)”
| हस्ता /-
। प्रधान सचिव (वित्त) ।
[Authoritative English Text of this Notification No. /-598/69-7#7%(0.4)747(7) 4व/९व॑ ... ... ... ....
as required under clause (3) of Articles 348 of the Constitution of India]
LOCAL AUDIT DEPARTMENT
NOTIFICATION
क्राक्रावन7 77002, ऊँ ६० 2073
No. -58/69-]0(,4)74॥().---॥ #छटंइ९ of the powers conferred by proviso to Article
309 of the Constitution of India, the Governor, Himachal Pradesh, is pleased to make the following
Rules further to amend the Himachal Pradesh, Local Audit Department, Deputy Director/Deputy
Controller, Class-I (Gazetted) Recruitment and Promotion Rules, 2009 notified vide this
Department Notification No. l-58/69-Fin(LA)Part(), dated 04-03-2009, namely:—
l. Short title and Commencement—(l) These rules may be called the Himachal
Pradesh Local Audit Department, Deputy Director/Deputy Controller, Class-I (Gazetted)
Recruitment and Promotion (First Amendment) Rules, 203.
(2) These rules shall come into force from the date of publication in the Rajparta,
Himachal Pradesh.
2. Amendment of the column 2 of Annexure-“A”.—In Annexure-“A” to the Himachal
Pradesh Local Audit Department, Deputy Director/Deputy Controller, Class-I(Gazetted)
Recruitment and Promotion Rules, 2009 :
‘ (a) For the existing provisions against column No 2, the following shall be substituted,
namely:—
(b) “7 (seven)”
Sd/-
Principal Secretary (Finance).
