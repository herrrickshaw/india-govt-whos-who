---
doc_id: "b62aa198cddabdd5"
source_url: "https://hpsvacb.hp.gov.in/storage/app/media/specificCurrupt.pdf"
ministry: "State Vigilance & Anti Corruption Bureau, Himachal Pradesh"
title: "The Himachal Pradesh Prevention of Specific Corrupt Practice (Amendment) Act, 1983"
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "87aa29f115dce472"
---

<!-- page 1 -->

The Himachal Pradesh Prevention of Specific Corrupt Practice (Amendment)
Act, 1983
Act 3 of 1984

Keyword(s):
Construction, Controller, Officer-incharge, Officer of work Department,
Supervisory Officer, Work, Work Department
Amendment appended: 20 of 2000

DISCLAIMER: This document is being furnished to you for your information by PRS
Legislative Research (PRS). The contents of this document have been obtained from sources
PRS believes to be reliable. These contents have not been independently verified, and PRS
makes no representation or warranty as to the accuracy, completeness or correctness. In
some cases the Principal Act and/or Amendment Act may not be available. Principal Acts
may or may not include subsequent amendments. For authoritative text, please contact the
relevant state department concerned or refer to the latest government publication or the
gazette notification. Any person using this material should take their own professional and
legal advice before acting on any information contained in this document. PRS or any persons
connected with it do not accept any liability arising from the use of this document. PRS or any
persons connected with it shall not be in any way responsible for any loss, damage, or distress
to any person on account of any action taken or not taken on the basis of this document.

<!-- page 2 -->

<!-- page 3 -->

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

<!-- page 15 -->

<!-- page 16 -->

<!-- page 17 -->
