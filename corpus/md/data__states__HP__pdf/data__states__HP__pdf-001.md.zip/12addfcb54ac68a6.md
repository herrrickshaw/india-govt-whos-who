---
doc_id: "12addfcb54ac68a6"
source_url: "https://hperc.org/wp-content/uploads/2016/03/hydro_power_policy_developmemt.pdf"
ministry: "H.P. Electricity Regulatory Commission (HPERC), Himachal Pradesh"
title: "Policy on Hydro Power Development"
date: ""
pages: 43
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "f9cada1008d23568"
---

<!-- page 1 -->

POLICY ON
HYDRO POWER DEVELOPMENT
Ae :
Government of India
Ministry of Power
(August, 998)

<!-- page 2 -->

Se _ नमन नमन मनन मनन क नमन मन कक ++_+_+म _- कक न न>न___+++ञञ+++++-.
POLICY ON HYDRO POWER DEVELOPMENT

i, NEED FOR AHYDEL POLICY
Hydro power is a renewable economic, non polluting and environmentally
benign source of energy. Hydro power stations have inherent ability for
instantaneous starting, stopping, load variations etc. and help in improving
reliability of power system. Hydro stations are the best choice for meeting the
peak demand. The generation cost is not only inflation free but reduces with
time. Hydroelectric projects have long useful life extending over 50 years and
help in conserving scarce fossil fuels. They also help in opening of avenues for
development of remote and backward areas.
Our country is endowed with enormous economically exploitable and viable
hydro potential assessed to be about 84,000 MW at 60% load factor (,48,700
MW installed capacity). In addition, 678.8 MW in terms of installed capacity
from small, mini and micro hydel schemes have been assessed. Also, 56
sites for pumped storage schemes with an aggregate installed capacity of
94,000 MW have been identified. However, only 75% of the hydroelectric
potential has been harnessed so far and 7% is under various stages of
development. Thus, 78% of the potential remains without any plan for
exploitation.
Despite hydroelectric projects being recognised as the most economic and
preferred source of electricity, share of hydro power has been declining steadily
since 963. The share of hydro power has been continuously declining during

LL दी ्ताकछक  %सससफससंसससस न65फ आफरडसससससससससससअनइनइन_नकनस्‍ैिनैतकय_त_फखफणफ?ण?सय?य य-ंच ft)

<!-- page 3 -->

ooo > >> मत कक ननननन++»

the last three decades. The hydro share has declined from 44 per cent in 970
to 25 per cent in 998. The ideal hydro thermal mix should be in the ratio of
40:60. Because of an imbalance in the hydel thermal mix especially in the
Eastern and Western regions, many thermal power stations are required to
back down during off peak hours. The capacity of the thermal plants cannot be
fully utilised resulting in a loss of about 4 to 5 per cent in the plant load factor.
Even if the share of hydro power is to be maintained at the existing level of 25
per cent, the capacity addition during the 9" and 70" Plan would work out to
23,000 MW. If the share were to be enhanced to 30 per cent, it would require
a further addition of 0, 000 MW of hydro capacity.
The constraints which have affected hydro development are technical (difficult
investigation, inadequacies in tunnelling methods), financial (deficiencies in
providing long term financing), tariff related issues and managerial weaknesses
(poor contract management). The hydro projects are also affected by geological
surprises (especially in the Himalayan region where underground tunnelling is
required), inaccessibility of the area, problems due to delay in land acquisition,
and resettlement of project affected families, law & order problem in militant
infested areas.

2. Objectives ५
The programmed capacity addition from hydel projects during the 9" Plan is
985 MW, of which Central Sector and State Sector will contribute 3455 MW
and 5840 MW respectively and the balance 550 MW will be contributed by the

Private Sector. Sanctioned and ongoing schemes under implementation will

SS EEE —————————LLk$&E$L=$L—_—=

<!-- page 4 -->

enable a capacity addition of 59i2 MW during the 0" Plan, of which 990 MW,
3872 MW and 050 MW will be the contribution of Central, State and Private
Sectors respectively. In addition, 2 projects (565 MW) have been identified for
advance action in the 9" Plan for benefits in the 0" Plan.
The Government of India has set the following objectives for accelerating the
pace of hydro power development:-
(i) Ensuring targeted capacity addition during 9th Plan:
The 9th Plan programme envisages capacity addition of 985 MW from hydel
projects in the total capacity addition of 40245 MW. The Central Sector hydel
projects would contribute 3455 MW, State Sector would add 580 MW and
Private Sector 550 MW. Keeping in view that the achievement in 8th Plan had
been dismal, the Government is determined to ensure that no slippage is allowed
to occur and the targeted capacity addition in the 9th Plan is achieved in full.
(ji) Exploitation of vast hydroelectric potential at a faster pace:
The Government would initiate advance action for taking up new hydro projects
since the ongoing projects will contribute a very small percentage of the desired
capacity addition envisioned for 70th Plan and beyond. Towards this end,
Government would take up for execution all the CEA cleared projects, and
take steps to update and obtain clearances for pending DPRs. Measures for
vigorously starting survey and investigations for new green field sites would
also be implemented shortly. In addition, Government is keen to restart and
Er

<!-- page 5 -->

————— ____
activate the hydro projects which are either languishing for want of funds or are
remaining dormant due to unresolved inter-State issues.

(iii) Promoting small and mini hydel projects
Small and mini hydel potential can provide a solution for the energy problems
in remote and hilly areas where extension of grid system is comparatively
uneconomical and also along the canal systems having sufficient drops. The
small hydro potential could be developed economically by simple design of
turbines, generators and the civil works. Small and mini hydel capacity
aggregating to about 340 MW is in operation, and Government is determined
to provide thrust for developing the assessed small hydel potential at a faster
pace henceforth.

(iv) Strengthening the role of PSUs/SEBs for taking up new hydel projects:
In view of the poor response of the private sector so far in hydro development
which may persist for some more years, the involvement of public sector in
hydel projects would not only have to continue but will also have to be enlarged.
There are categories of projects such as multi-purpose, projects involving inter-
State issues, projects for peaking power and those involving rehabilitation and
resettlement which may be taken up and implemented more easily in public
sector. Similarly, mega hydro projects in the North and North Eastern region
would also have to be executed by CPSUs in case the State or the private
sector is not in position to implement these projects.

<!-- page 6 -->

(v) Increasing private investment:

Even though public sector organisations would play a greater role in the
development of new schemes, this alone would not be adequate to develop
the vast remaining hydro potential since it will require huge investments which
are difficult to be supported from the budget/plan assistance in view of competing
demands from the various sectors. A greater private investment through IPPs
and joint ventures would be encouraged in the coming years and required
atmosphere, incentives and reliefs would be provided to stimulate and maintain
a trend in this direction.

3. Policy Instruments है
To achieve the above stated objectives for faster development of hydro potential,
the Government proposes to take the following steps and measures: -

3.. Funding
All the ongoing Central Sector hydroelectric projects namely Nathpa Jhakri
(7500 MW), Tehri Stage | (000 MW), Ranganadi Stage | (405 MW), Dulhasti
(390 MW), Dhauliganga (280 MW), Doyang (75 MW) and Rangit (60 MW)
would be provided with full budgetary support till completion. Government of
India will also provide budgetary support for the new projects to be taken up by
the CPSUs during the Sth Plan. The actual utilisation of the funds on the ongoing
Central Sector hydel projects has been Rs.6/6.87 crores in 997-98 and the
budget provision for 998-99 has been increased to Rs.2070 crores. Therefore

3
LE >>

<!-- page 7 -->

वन नमन ननननननन मनन ननन न ननननननननन कक न नम मनन
the remaining three years of the 9" Plan would require about Rs.5896 crores
on the ongoing Central Sector projects (excluding NEC projects). Having regard
to the large capacity addition envisaged in the State Sector (58/0 MW) it is
necessary to (a) provide a mechanism for funding hydro projects by earmarking
funds in the plan allocation of the State Governments by the Planning
Commission; and (b) organising supplementary funding of hydel projects where
more than 50 per cent of the expenditure has already been incurred.
The monitoring of all the ongoing projects will be intensified and a task force
would be constituted for this purpose. The progress of important projects in
the State and Central Sector would be reviewed at the level of Minister/
Secretary(Power) and all measures will be taken so that there is no slippage in
the schedule for completion of the ongoing projects.

3.2 Power Development Fund
The survey and investigation of hydro projects have been discontinued since
long in the States due to paucity of funds. As a result, there are not enough
projects right now that could be taken up in the next 2 to 3 years and get
completed in the 0" Plan or early " Plan. It is necessary to carry out survey
and investigations continuously and prepare a shelf of projects for execution
over a decade and more.
In case fully investigated projects with Detailed Project Reports are offered to
private developers, their response could be more favourable. If pre-construction
activities and enabling works could be completed and these sites offered to

<!-- page 8 -->

SS — — — — — —  _ _+«»
IPPs the chances of IPPs opting to invest in these projects would further improve.
Further this would reduce the gestation period which would make investment
in hydro projects more attractive.

The above approach is possible and successful only if a dedicated fund is
available for this purpose.

It is proposed to levy a Power Development Cess at 0 paise per kwh of
electricity consumed in the country. The levy of cess was recommended by
the Sub Committee of the NDC Committee on Power which gave its report in
January, 994. The cess would be levied on the electricity billed by SEBs/
Electricity Departments/Bulk licensees/Distribution licensees. The State/UT
Governments would be responsible for the collection of the cess. The amount
would thereafter be credited to a “National Power Development Fund". Itis expected
that about Rs.3000 crores per annum can be realised by levying a cess of 0
paise per kwh.

It would be necessary to establish a legal and organisational frame work for
levy ofacess, Electricity being a Concurrent Subject, the Central Government
is empowered to legislate on all aspects of electricity including the levy of
cess, the proceeds of which is to be utilised for power development. In order
to levy a Power Development Cess, it would be necessary for Parliament to
enact a legislation on the subject. The cess will be imposed on the consumption
of electricity throughout the country. The State Electricity Boards will be the
responsible agencies for the collection of cess. The proceeds of the cess will
be shared with the State/UT Governments and the Central Government. Two-

NN सससस सयअऔअआ छक्‍छअझ»>आ$$औ$&»8$आ/।$।:|:::>आख झा घौघछखाझऋझखाझाझाझाखाऋखऋझाधाखा॑धाधौधौधधधधधधध&स्स्छ्ध_,!'ध  खफेनननगनत"-.-.-_-_-_ _ण_. गो 7

<!-- page 9 -->

thirds of the amount realised from the State/UT Government will be allocated
to the respective government to be utilised for power development. This amount
would be released from the National Power Development Fund for financing
schemes/projects recommended by the State Government. The remaining one-
third will be utilised by the Central Government for promoting hydel projects in
the Central Sector and for investment in transmission lines for evacuation of
power from mega hydel projects which will benefit more than one State.
3.3. Basin-wise Development of Hydro Potential

The assessment of hydro potential in 845 identified conventional hydro projects
and 56 pumped storage projects is on the basis of desk studies using toposheets
and discharge data. Further, detailed studies to firm up the parameters of the
projects as identified by CEA would be taken up on the basis of development
of hydro potential in a basin as a whole for maximising benefits and prioritising
execution of projects. These studies will be done in close co-ordination with
CWC and Planning Commission and in harmony with development for other uses
of water like irrigation, drinking water etc. While CEA would carry out these
studies, CPSUs/other Central Goverment Organisations and State authorities would
do the investigations and prepare the detailed project reports, by adopting an
integrated approach towards planning and development of the various projects,
evacuation arrangement and environmental impact assessment. This would enable
an optimal harnessing of hydro potential in each river basin.

<!-- page 10 -->

—— नमन नममनमरऋ>ल्‍रल्‍ननंंऋ>2>०_०-ो)ोपनन>>>>>+++++

३.4 Advance Action for Capacity Addition 800 7्का ब्रा 9९ए/णात॑
Government will take immediate steps to tie up funding, execution agencies
and convey investment decision for schemes already accorded techno
economic clearance of CEA. As far as Central Sector is concerned, NHPC
would take up Chamera Stage II (300 MW), Parbati Stage-II (800 MW), and Kol
Dam (800 MW) in HP; Teesta Stage V (50 MW) in Sikkim, Loktak Downstream
(90 MW) in Manipur and NEEPCO will take up Tuivai (20 MW) in Mizoram,
Lower Kopili ({50 MW) in Assam, Kameng (600 MW) and Ranganadi Stage II
(760 MW) in Arunachal Pradesh (after the consent of the State Govt. has been
obtained). In addition THDC would take action to start activities on Tehri Stage II
(7000 MW) and Koteshwar (400 MW) in UP. Similarly NJPC would also take up
Rampur Project (535 MW) in HP. These projects would require budgetary support
of about Rs.2000 crores in the 9" Plan.

3.5 Survey & Investigations
As a long term strategy efforts will be made to ensure that DPRs which are
under various stages of processing for accord of TEC by CEA are finalised
and cleared so that a start could be made on these projects in the next one or
two years. Survey and investigation of the potential hydro sites on an advanced
scientific basis would be essential requirement for the future. The progress on
this front has been dismal given the funds constraint and outdated technology.
The funding agencies like World Bank and ADB have shown their interest
towards funding the survey and investigation activities for hydroelectric projects.
Concerted efforts would be made towards availing the funds quickly. This

NS  ...zzzhh»™=aaR 9
