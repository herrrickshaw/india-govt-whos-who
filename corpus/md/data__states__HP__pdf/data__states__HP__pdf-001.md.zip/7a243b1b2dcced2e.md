---
doc_id: "7a243b1b2dcced2e"
source_url: "https://www.hpseb.in/irj/go/km/docs/internet/New_Website/Pages/HPSEBL/whatsnew/moa_1.pdf"
ministry: "Himachal Pradesh State Electricity Board Limited (HPSEBL), Himachal Pradesh"
title: "Memorandum of Association"
date: ""
pages: 35
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cd20b4ff794d0b07"
---

<!-- page 1 -->

HPSEBL
THE COMPANIES ACT, 1956

(COMPANY LIMITED BY SHARES)
CIN NO: (U40109HP2009SGC031255)
GST NO: (HPSEBL 02 AACCH4894EHZB)

REGISTERED & CORPORATE OFFICE
Himachal Pradesh State Electricity Board Ltd (a state
Govt.Undertaking) Vidyut Bhawan Kumar House Shimla Himachal
Pradesh. PIN- 171004.

<!-- page 2 -->

p`a$p 1
pMjaIkrNa p`maaNa–p~
ka^pao-roT phcaana saM#yaa :

U40109HP2009SGC031255

2009 - 2010

maOM etdWara sa%yaaipt krta hU^ ik maOsasaHimachal Pradesh State Electricity Board Limited

ka pMjaIkrNa‚ kmpnaI AiQainayama‚ 1956 (1956 ka 1) ko AtMga-t Aaja ikyaa jaata hO AaOr yah
kmpnaI p`a[vaoT ilaimaToD hO.
yah inagamana–p~ Aaja idnaaMk tIna idsambar dao hjaar naaO kao maoro hstaxar sao caNDIgaD maoM jaarI ikyaa jaata
hO.

Form 1
Certificate of Incorporation
Corporate Identity Number : U40109HP2009SGC031255
2009 - 2010
I hereby certify that Himachal Pradesh State Electricity Board Limited is this day
incorporated under the Companies Act, 1956 (No. 1 of 1956) and that the company
is private limited.

Given under my hand at Chandigarh this Third day of December Two Thousand
Nine.
(Dr. RAJ SINGH)

kmpnaI rijasT/ar

/Registrar of Companies

pMjaaba‚ ihmaacala p`doSa evaM caNDIgaD
Punjab, Himachal Pradesh, and Chandigarh

kmpnaI rijasT/ar ko kayaa-laya AiBalaoK maoM ]plabQa p~acaar ka pta :
Mailing Address as per record available in Registrar of Companies office:
Himachal Pradesh State Electricity Board Limited
Vidyut Bhawan, HPSEB, Shimla-171004, Shimla - 171004,
Himachal Pradesh, INDIA

<!-- page 3 -->

Baart sarkar–ka^pao-roT kaya- maM~alaya

kmpnaI rijasT/ar kayaa-laya‚ pMjaaba‚ ihmaacala p`doSa evaM caNDIgaD
ilaimaToD kmpnaI ko $p maoM pirvait-t haonao ko pirNaamasva$p‚ kmpnaI ko naama maoM pirvat-na ka nayaa
inagamana p`maaNa–p~
ka^pao-roT phcaana saM#yaa : U40109HP2009SGC031255
maOsasa- Himachal Pradesh State Electricity Board Limited
ko maamalao mao‚ maOM etdWara sa%yaaipt krta hU^M ik maOsasaHimachal Pradesh State Electricity Board Limited

jaao maUla $p maoM idnaaMk tIna idsambar dao hjaar naaO kao kmpnaI AiQainayama‚ 1956 ³1956 ka 1´ ko AtMga-t maOsasaHimachal Pradesh State Electricity Board Limited

null
Himachal Pradesh State Electricity Board Limited

hao gayaa hO AaOr yah p`maaNa–p~‚ kiqat AiQainayama kI Qaara 23³1´ ko AnausarNa maoM jaarI ikyaa jaata hO.
yah p`maaNa–p~‚ maoro hstaxar Wara caNDIgaD maoM Aaja idnaaMk Aaz jaUna dao hjaar dsa kao jaarI ikyaa jaata hO.

GOVERNMENT OF INDIA - MINISTRY OF CORPORATE AFFAIRS
Registrar of Companies, Punjab, Himachal Pradesh, and Chandigarh
Fresh Certificate of Incorporation Consequent upon Change of Name on
Conversion to Public Limited Company
Corporate Identity Number : U40109HP2009SGC031255
In the matter of M/s Himachal Pradesh State Electricity Board Limited
I hereby certify that Himachal Pradesh State Electricity Board Limited which was originally incorporated on Third
day of December Two Thousand Nine under the Companies Act, 1956 (No. 1 of 1956) as Himachal Pradesh
State Electricity Board Limited having duly passed the necessary resolution on null in terms of Section 31/ 21
read with Section 44 of the Companies Act, 1956; the name of the said company is this day changed to Himachal
Pradesh State Electricity Board Limited and this Certificate is issued pursuant to Section 23(1) of the said Act.

Given under my hand at Chandigarh this Eighth day of June Two Thousand Ten .

(Prahlad

Meena )

]p kmpnaI rijasT/ar / Deputy Registrar of Companies

pMjaaba‚ ihmaacala p`doSa evaM caNDIgaD
Punjab, Himachal Pradesh, and Chandigarh
kmpnaI rijasT/ar ko kayaa-laya AiBalaoK maoM ]plabQa p~acaar ka pta :
Mailing Address as per record available in Registrar of Companies office:
Himachal Pradesh State Electricity Board Limited
Vidyut Bhawan, HPSEB, Shimla-171004, Shimla - 171004,
Himachal Pradesh, INDIA

<!-- page 4 -->

THE COMPANIES ACT, 1956
(COMPANY LIMITED BY SHARES)
MEMORANDUM OF ASSOCIATION
OF
HIMACHAL PRADESH STATE ELECTRICITY BOARD LIMITED
(A State Government Undertaking)
NAME OF THE COMPANY :

Himachal Pradesh State Electricity Board Limited.

REGISTERED OFFICE

:

State of Himachal Pradesh

OBJECTS

:

The objects for which the Company is established are:

MAIN OBJECTS
Acquire, establish,
Construct
and
operate extra high
voltage,
high
voltage,
medium
voltage
and
low
voltage lines and
associated
substations.

A). Main objects to be pursued by the Company on
its incorporation:
1. To plan, promote, organize, maintain and operate an
integrated power distribution system in all aspects including; to
acquire, establish, construct erect, lay, operate, run, manage,
maintain, enlarge, alter, renovate, modernize, work and use in the
State of Himachal Pradesh and elsewhere, extra high voltage
(EH\/), high, voltage (HV) Medium Voltage (MV) and low voltage
(LV) lines and associated sub-stations, including distribution
centers, cables, wires, accumulators, plants, motors, meters,
apparatus, computers and materials connected with transmission,
distribution, supply of electrical energy, communication and
telemetering equipment.
:

2. To plan, promote, organize, maintain and execute Power
Projects within and outside the State of Himachal Pradesh
including execution of new projects.
3. To undertake, for and on behalf of others the erection,
operation, maintenance, management of extra high voltage, high
voltage, medium voltage and low voltage lines and associated
sub-stations, equipment apparatus, cables and wires.
Purchase and sale of
electrical energy and
co-ordinate
other
companies

4. To carry on the business of purchasing, selling, trading
electrical energy and co-importing, exporting, wheeling, trading of
electrical energy, including formulation of tariff, billing and
collection thereof.
5. To execute Power Purchase Agreements with Transmission
company/companies, generating companies, Central and State
generating
stations,
regional
Electricity
Boards/Companies/neighboring States/utilities and other entities.
6. To execute agreements for sale of power to distribution

<!-- page 5 -->

companies and other persons and to co-ordinate, aid and advise
on the activities of other companies and concerns, including
subsidiaries, associates and affiliates engaged in generation,
transmission, distribution, supply and wheeling of electrical
energy.
7. To schedule and dispatch generation of all units connected to
the State Power system including the centrally owned generating
stations in respect of the share assigned to the State.
Plan, investigate and
prepare - Project
Reports and load
forecast
and
finalization
of
contract
for
purchase
of
electrical
energy
from new generating
plants.

8. To study, investigate, collect information and data, review
operations, plan, research, design and prepare project reports,
diagnose-operational difficulties-and weaknesses, and advise on
the remedial measures to improve and modernize existing EHV,
HV, MV, LV line and substations.
9. To forecast load and plan generation in consultation with
transmission
company/companies
and
generating
stations/companies.
10. To tender and finalize contracts for purchase of electrical
energy from new generating plants.
11. To undertake the Transmission, SLDC and allied activities, if
assigned by the State Government, subject to the provisions of
the Central Electricity Act, 2003.
12. To regulate and control the terminal/retirement benefits of the
retirees of erstwhile HPSEB and of erstwhile HPSEB employees
such as pension, gratuity, leave encashment etc.

OTHER OBJECTS
Control
and
ordination

B. Objects incidental or ancillary to the attainment of the
main objects

Co- 1. To co-ordinate the activities of its subsidiaries to determine
their economic and financial objectives/targets and to review,
control, guide and direct their performance with a view to
secure optimum utilization of all resources places at their
disposal.
Manufacturing,
2. To carry out the business of purchasing, selling, importing,
trading and other
exporting, producing, trading, manufacturing or otherwise
business
dealing in all aspects of planning, investigation, research,
design and preparation of preliminary, feasibility and Detailed
Project Report, afforestation and environmental development,
construction, generation, operation and maintenance of
hydroelectric projects, distribution and sale of hydroelectric
power, hydroelectric power development, ancillary and other
allied industries and for that purpose to install, operate and
manage all necessary plants, establishments and works.

<!-- page 6 -->

Agent
of
Public 3. To act as an agent of Government/ Govt. Company/
Sector
Financial
Corporation/Public sector financial institutions, to exercise all
Institutions
the rights and powers exercisable at any meeting of any
Company engaged in the planning, investigation, research
design and preparation of preliminary, feasibility, and Detailed
Project
Report,
construction,
generation,
operation,
maintenance of hydroelectric power stations and projects,
distribution and sale of hydroelectric power in respect of any
shares held by the Government, Public financial institutions,
Nationalized Insurance Companies with a view to secure the
most effective utilization of the financial investments and loans
in such companies and the most efficient development of the
concerned industries.
As a helper and 4. To arrange, secure and make available to its subsidiaries and
servicing agency for other concerned with the discharge of duties of the Company,
the subsidiaries.
such facilities, resources, inputs and services as may be
required.
To obtain charters, 5. To enter into any arrangement with the Government of India or
concession etc.
Government of Himachal Pradesh or any Local or State
Governments or with Authorities, International, National, local
municipal or otherwise or with any person for the purpose of
directly or indirectly carrying out the - objects or furthering the
interests of the Company or its members and to obtain from any
such Government, State Authority or person any charters,
subsidies, loans, indemnities, grants, contracts, decrees, rights,
sanctions, privileges, licenses or concessions whatsoever,
(whether statutory or otherwise), which the Company may think it
desirable to obtain and carry out, exercise and comply with the
same.
Borrowing power
6. Subject to the provisions of Section 58A of the Companies Act,
1956 and Rules framed there under to borrow money or to
receive money or deposits for the purpose of financing the
business of the company either with security or mortgage or other
security charges on the undertaking or all or any of the assets of
the Company including uncalled capital and to increase, reduce
or pay of any such securities.
To acquire and lease 7. To acquire by purchase, lease, exchange, hire or otherwise to
property
conduct and maintain factories, works, buildings, apartments,
plants, machinery and hereditaments of any tenure or description,
situated in India or in any other part of the world and any estate
or interest therein and any rights over or connected with land so
situated and turn the same to account in any manner as may
seem expedient, necessary or convenient to the Company for the
purpose of the business.
To acquire business/ 8. To acquire, possess and undertake the whole or any part of
Companies
the business, assets, property, goodwill, rights and liabilities of
any person, firm, society, association, corporation or company
carrying on any business, which the Company is authorized to
carry on.

<!-- page 7 -->

To obtain authority 9. To obtain, apply for, arrange for the issue or enactment of
etc. to carry out its order or Act of Legislature or Act of Authority in India or any other
objects.
part of the world for enabling the Company to obtain powers,
authorities, protection, financial and other help, necessary or
expedient to carry out or extend any of the objects of the
Company or for any other purpose which may seem expedient
and to oppose any proceedings or application or any other
endeavors, steps or measures, which may seem calculated
directly or indirectly steps to prejudice the Company's interest.
To acquire
how etc.

know- 10. To apply for, purchase or otherwise acquire any trade marks,
patents, brevets or inventions, licenses, concessions and the like,
conferring any exclusive or non-exclusive or limited right to use of
any secret or other information as to any invention which may
seem capable of being used for any of the purposes of the
Company or the acquisition of which may seem calculated,
directly or indirectly, to benefit the Company and to use, exercise,
develop or grant licenses in respect of or otherwise turn to
account the property, right or information so acquired.
To
undertake 11 (a) To establish, provide, maintain and conduct or otherwise
research,
subsidise research laboratories and experimental workshops for
development
and scientific, technical or research experiments and to undertake
training
and carry on directly or in collaboration with other agencies
scientific and technical research experiments and tests of all
kinds and to process, improve and invest new products and their
techniques of manufacture as to promote, encourage, reward in
every manner, studies and research, scientific and technical
investigations and invention of any kind that may be considered
likely to assist, encourage and promote rapid advances in
technology, economics, import substitution or any business which
the Company is authorized to carry on.
b) To establish, maintain and operate technical training
institutions and hostels for engineers of all types and all other
technical staff and artisans and mechanics of all types and kinds
and accountants and others in India or in any part of the world; to
make such other arrangements as may be expedient for the
training of all categories of officers, workers, clerks, storekeepers
and other personnel likely to be useful to or assist in any
business, which the Company is authorized to carry on.
To improve property 12. To sell, improve, manage, develop, exchange, loan or lease
etc.
or let, under lease, sub-let, mortgage, dispose of, deal with in any
manner, turn to account or otherwise deal with any rights or
property of the Company.
To invest money
13. To accumulate funds and invest or otherwise employ moneys
belonging to or with the Company and not immediately required,
in the purchase or acquisition of any shares, securities or other
investments (not being shares in this Company) whatsoever,
whether movable or immovable, upon such terms as may be

<!-- page 8 -->

To undertake joint
ventures

To
provide
welfare
employees.

for
of

To sell property

To
enter
contracts

into

thought proper and from time to time to vary all or any such
investments in such manner as the Company may think fit.
14. Subject to the provisions of Section 391 to 394 of the
Companies Act, 1956 or any other applicable provision of the Act
amalgamate or merge with or to amalgamate, any other
Company or Companies to be a part of schemes for rescheduling
and arrangement including consolidation, merger and division of
companies enter into partnership or into any arrangements for
sharing profits, union of interest, co-operation, joint venture,
reciprocal concession or otherwise, with any person or company
or companies, enter into working arrangements of all kinds with
companies, corporations, firms or persons and also to make and
carry into effect arrangements with respect to union of interest or
amalgamation either in whole or in part.
15. To provide for the amelioration and welfare of persons
employed or formerly employed' by the Company and the'
families, dependants of such persons by building or contributing
to the building of houses, dwellings or by grants of money,
pensions, allowances, bonuses or other payments or by creating
and from time to time subscribing or contributing to provident fund
and other associations, institution, funds or trusts or by helping
persons employed by the Company to effect or maintain
insurance on their lives by contributing to the payment of
premium or otherwise and by providing or subscribing or
contributing towards places of instructions and, recreations,
hospitals and dispensaries, medical and other attendance and
other assistance as the Company shall think fit.
16. To sell or dispose of the undertaking of the Company or any
part thereof for such consideration as the Company may think fit
and in particular for shares, debentures or securities of any other
association, corporation or company, to promote or aid in the
promotion of any other company or partnership for the purpose of
acquiring all or any of the properties, rights or liabilities of the
company or for any other purpose which may seem directly or
indirectly calculated to benefit the Company.
17. (a) To enter into agreements and contracts with foreign
individuals, companies or other organizations for purchase of
equipment and for technical, financial or any other assistance, for
carrying out all or any of the objects of the Company.
(b ) To enter into any arrangement with any Central or State
Government or State, Municipal, Local Authority or otherwise that
may seem conducive to the Company's objects and to obtain
from any such Government or authority any rights, privileges and
concessions and to carry out, exercise and comply with any such
arrangements, rights, privileges and concessions
(c) To enter into contracts of indemnity and guarantee.

<!-- page 9 -->

(d) To apply for tender, purchase or otherwise acquire any
contracts and concessions for or relating to the main objects of
other Company.
To
establish 18. To establish and maintain agencies, branches and local
agencies etc.
registers, to procure registration or recognition of the company
and to carry on business in any part of the world and to take such
steps as may be necessary to give the Company such rights and
privileges in any part of the world as are possessed by local
companies or partnerships or as may be thought desirable.
To subscribe shares 19. To subscribe for, underwrite, purchase, or otherwise acquire
and to hold, dispose of and deal with the shares, stocks,
securities and evidence of indebtedness or the right to participate
in profits or ether similar documents issued by any Government,
Authority, Corporation or body or by any Company or body of
persons and any option or right in respect thereof.
To
create 20. To create any depreciation fund, reserve fund, sinking fund,
depreciation
insurance fund or any other fund, whether for depreciation or for
funds
repairing, improving, extending or maintaining any of the
properties of the company or redeemable preference shares or
for any other purpose whatsoever conducive to the interests of
the Company.
To open accounts in 21. To open an account or accounts with any individual, firm or
banks
company or with any bank or bankers and to pay into and
withdraw money from such account or accounts.
To acquire part of
22. To acquire and hold all or any of the share or loan capital or
companies
other securities of any other Company or body and to sell or
dispose of or transfer any such shares, loan interest, securities.
To
carry
on 23. To promote, organize or carry on the business of consultancy
consultancy
services in any field of activity in which it is engaged in.
services
To promote other 24. To promote or concur in the promotion of any company, the
companies
promotion of which shall be considered desirable in furtherance
of the objects or any object of the Company.
To
collect 25. To arrange, receive and collect all relevant information in
information etc.
regard to any business carried on by the Company.
To
act
as
entrepreneur.
To
carry
convenient
business:

an 26. To act as an entrepreneur on behalf of the Central or any
State Government, to identify new areas of economic investment
and to 'undertake or help in the undertaking of such investments.
on 27. Generally to do all such other things as may be deemed
to incidental or conducive to the attainment of the above objects or
any of them and to carry on any business which may be
conveniently carried on in connection with any of the Company’s
objects or are calculated directly or indirectly to enhance the
value of or render profitable any of the company’s property or
rights.
OTHER OBJECTS

<!-- page 10 -->

To carry on the
business of carriers
by land etc.
To deal with goods
etc. dealt with by
subsidiaries.

1. To carry on the business of carriers by land, sea and air as
may be required from time to time.

2. To carry on the business of trading in and dealing in any
manner whatsoever in all commodities, goods and things,
manufactured, produced or dealt with in any manner by any of
the subsidiaries of the Company.
To deal in goods and 3. To trade in and carry on business in goods and services of the
services
nature not enumerated above which may seem to the Company
capable of being conveniently and profitably carried on by the
Company.
All such objects or functions, which the company is authorized to
undertake.
LIMITED LIABILITY
IV. The liability of the Members is limited.
SHARE CAPITAL
V.
The Authorized Share Capital of the Company is
Rs.1100,00,00,000/- (Rs. One thousand One hundred Crore only)
divided into 11,00,00,000 (Eleven Crore) Equity Shares of
Rs.100/-each.
We, the several persons, whose names, addresses and occupations are subscribed
below, are desirous of being formed into a Company in pursuance of this
Memorandum of Association and we respectively agree to take the number of shares
in the capital of the company set opposite our respective names:
Name of subscriber,
No. of
Signature
Signature of Witnesses,
address, description
equity
of
their address,
and occupation, if
shares
subscriber
description and
any
occupation, if any
taken by
each
subscriber
1. Smt. Asha Swarup, IAS,
Chief Secretary to the Govt.
of Himachal Pradesh
2. Sh. Ravinder Kumar Jain,
IAS, Chairman
HPSEB,Shimla-171004
3. Sh. S.K. B. S. Negi, IAS
Member (Finance &
Accounts))
HPSEB, Shimla -171004
4. Sh. Bhagat Singh Negi
Member (Projects)
HPSEB, Shimla-171004

200
(Two
Hundred)
200
(Two
Hundred)
200
(Two
Hundred)

Signed in my presence

Sudershan Kumar Sharma

200
(Two
Hundred)

5. Sh. Surendra Kumar
200
(Two
Chaudhary
Hundred)
Member (Operation)
HPSEB, Shimla-171004
Total:
1000
Dated: This day 19.11.2009

(One thousand)

<!-- page 11 -->

(THE COMPANIES ACT, 1956)
COMPANY LIMITED BY SHARES
ARTICLES OF ASSOCIATION
OF

HIMACHAL PRADESH STATE ELECTRICITY BOARD LIMITED
(A State Government Undertaking)

INTERPRETATION
Interpretation

1.

In the interpretation of the Memorandum of Association and
these Articles, the following expressions shall have the
following meanings unless repugnant to the subject or
context.

The Act or
the said Act

“The Act” or the “said Act” means “ the Companies Act, 1956”
as amended up to date or other Acts for time being in force in
India containing the provisions of the Legislature in relation to
Companies.

The Board or
Board of
Directors

“The Board” or the “Board of Directors” means a meeting of
the Directors duly called and constituted or as the case may
be, the Directors assembled at a Board or the requisite
number of Directors entitled to pass a circular resolution in
accordance with the Act.

Busbar rate

Means the cost of generation of power per unit of energy at
Powerhouse busbar of the project, determined from time to
time by the company, based upon all costs of generation
including return on equity in accordance with the standard
guidelines of Govt. of India and the cost of free power supply
to Himachal Pradesh.

Capital

“Capital” means the Capital for the time being raised or
authorized to be raised for the purpose of the company.

Chairman

“Chairman” means the Chairman of the Board of Directors for
the time being of the company.

The Company
or this
Company

“The Company” or “This Company” means HIMACHAL
PRADESH STATE ELECTRICITY BOARD LIMITED”.

Directors

“Directors” means the Directors for the time being of the
Company or as the case may be, Directors assembled at a
Board.

<!-- page 12 -->

Dividend

‘Dividend’ includes bonus shares.

Executors or
Administrator

“Executor” or “Administrator” means a person who has
obtained probate or letters of Administration, as the case may
be, from some competent Court.

Expression in
the meaning in
Articles

Subject as aforesaid, any words or expression defined in the
Act shall, except where the subject or context forbids, bear the
same meaning in these Articles.

Gender

Words importing the masculine gender also include the
feminine gender.

The Government

“The Government” means the Government of the State of
Himachal Pradesh.

Government
of Himachal
Pradesh
*H.P.S.E.B.*

“Government of Himachal Pradesh” means Government of the
State of Himachal Pradesh.

Government
Corporation.
The Governor

“HPSEB” means The Himachal Pradesh State Electricity
Board.
“Government Corporation” means (i) a Corporation
established by the Government under any law in force for the
time being, and (ii) a Government Company as defined in the
Act.
“The Governor” means the Governor of the State of Himachal
Pradesh.

Marginal Notes

The marginal notes hereto shall not affect the construction
hereof.

Month

“Month” means a calendar month.

Office

“Office” means the Registered office for the time being of the
company.

Persons

“Persons” include Corporation and firms as well as individuals.

Plural number

Words importing the plural number also include the singular
number.

Register

“Register” means the register of members to be kept in
pursuance to the Act.

Registrar

“Registrar” means the Registrar of the Companies of the State
in which the Registered Office of the Company is situated.

Seal

“Seal” means the Common Seal for the time being of the
Company.

<!-- page 13 -->

Singular Number

Words importing the singular number include the plural
number.

Shares

“Shares” means the shares or stock into which the capital is
divided and the interest corresponding with such shares or
stock.

These Presents
or
Regulations

“These Presents” or “Regulations” means these Articles of
Association as originally framed or altered from time to time
and include Memorandum where the context so required.

Writing

“Writing” shall include printing and lithography and any other
mode or modes of representing or reproducing words in a
visible form.

Table 'A'
not to
apply

2.

The Regulations in Table ‘A’ in the first schedule to the Act
shall not apply to the Company except so far as the same are
repeated or contained in or expressly made applicable by
these Articles or by the Act.

Company to
be governed
by these
Articles

3.

The Regulations for the management of the company and for
the observance of the members thereof and the
representatives shall, subject as aforesaid and to any exercise
of the statutory powers of the company in reference to the
repeal or alteration of or addition to its Articles of Association
by Special Resolution, as prescribed or permitted by the Act,
be such as are contained in these Articles.

Company is
a Public
Company

4.

“The Company”
accordingly:-

a)

Deleted

b)

Deleted

c)

The Government of Himachal Pradesh is entitled to and shall
subscribe to the equity capital of the company.

d)

Deleted

Capital
Shares
Allotment of
Shares

and 5.

6.

is

a

Public

Limited

Company”

and

The The Authorized Share Capital of the Company is
Rs.1100,00,00,000/- (Rs. One thousand One hundred Crore
only) divided into 11,00,00,000 (Eleven Crore) Equity Shares
of Rs.100/-each.
Subject to the provisions of the Act and these Articles and to
right of the Government, the Shares shall be under the control
of the Board of Directors, who may allot or transfer or
otherwise dispose off the same.
CERTIFICATES

<!-- page 14 -->

Members right to
Certificates

7.

Every person whose name is entered as a member in the
Register shall, without payment, be entitled to a certificate
under the common seal of the company specifying the share
or shares held by him and the amount paid thereon.

Issue of
new 8.
certificate in
place of one
defaced, lost
or destroyed

If a share is defaced, lost or destroyed, it may be renewed in
accordance with the Share Certificate Rules under the Act on
payment of fee, as may be prescribed by any law and on such
terms, if any, as to evidence and indemnity and the payment
of out of pocket expenses incurred by the company in
investigating evidence as the Directors think fit.

Transfer and Transmission of Shares
Transfer
and 9.
Transmission of
Shares.
a)

The right of members to transfer their shares shall be in
accordance with the provisions of the Companies Act.

Register
of transfers

10.

The company shall keep a book to be called the Register of
Transfers and therein enter the particulars of several transfers
or transmission of any shares.

Execution
of transfer

11.

The instrument of transfer of any share in the company shall be
executed both by the transferor and the transferee, and the
transferor shall be deemed to remain holder of the share until
the name of the transferee is entered in the register of members
in respect thereof.

12.

Nothing contained in Article 9 shall prejudice any power of the
company to register as shareholder any person to whom the
right to any share in the company has been transmitted by
operation of law.

Transmission
Shares

of

(deleted)

Increase, Reduction and Alteration of Capital
Increase
of capital

13.

Subject to the approval of the Government and subject to the
provisions of the Act, the Company in a General Meeting may
increase the Share Capital by such sum to be divided into
shares of such amount as the resolution shall prescribe.

<!-- page 15 -->

On what
condition
new shares
may be
issued.

14.

When to be
offered to
existing
members

15. T The new shares, (resulting from an increase of capital as
aforesaid) may be issued or disposed of in accordance with the
provisions of articles.

New shares
to be same as
original
Capital.

16.

Except so far as otherwise provided by the conditions of issue
or by these Articles, any capital raised by the creation of new
shares shall be considered part of the original capital and shall
be subject to the provisions herein contained with reference to
the payment of calls and installments, transfer and
transmission, forfeiture, lien, surrender, voting and otherwise.

Reduction of
Capital

17.

Subject to the provisions of Sections 100 to 104 of the Act and
the approval of the Government in this behalf, the company
may, from time to time, by special resolution, reduce its capital
by paying off capital or canceling capital which has been lost or
is unrepresented by available assets or is superfluous or by
reducing the liability on the shares or otherwise as may seem
expedient, and capital may be paid off upon the footing that it
may be called upon, again or otherwise , and the Board may,
subject to the provisions of the Act, accept surrenders of
shares.

Consolidation of 18.
Share Capital

Subject to the Provisions of the act the Company in a General
meeting may from time to time sub-divide or consolidate its
shares or any of them and exercise any of the other powers
conferred by sub –section (i) (a) to (e) of section 94 of the act,
and shall file with the registrar such notice in exercise of any
such powers as may be required by the act.

Issue or new 19.
share certificate
in place of one
lost, destroyed or
defaced

If a share certificate is defaced, lost or destroyed, it may be
renewed on such terms, if any, as to evidence and indemnify
and the payment of out of pocket expenses incurred by the
Company investigating evidence as the Board may think fit.

Funds
of 20.
Company not to
be employed for
purchase of its
shares etc

Except to the extent allowed by the Act, no part of the funds of
the Company shall be employed in the purchase of or in loans
upon the security of the Company’s shares.

Subject to the provisions of the act and subsequent approval of
the Government, new shares shall be issued upon such terms
and conditions and with such rights and privileges annexed
thereto as the general meeting resolving upon the creation
thereof shall direct. Provided that no shares (not being
preference shares) shall be issued carrying voting right or rights
in the company as to dividends, capital or otherwise, which are
disproportionate to the rights attaching to the holders of other
shares (not being preference shares).

<!-- page 16 -->

LIEN
Company’s
on Shares

lien 21.

The Company shall have a first and paramount lien on every
share (not being fully paid share) for all money whether
presently payable or not called or payable at a fixed time in
respect of that share, and the Company shall also have a lien
on all shares (other than fully paid shares) standing registered
in the name of single person, for all moneys presently payable
by him or his estate to the Company, but the Directors may
declare any share to be wholly or in part exempt from the
provisions of this clause. The Company’s lien, if any, on a
share shall extend to all dividends payable thereon.

Enforcement
lien by sale

of 22.

The Company may sell, in such manner as the Board thinks fit,
any shares on which the Company has a lien but no sale shall
be made (a) unless a sum in respect of which the lien exists is
presently payable; or (b) until the expiration of fourteen days
after a notice in writing, stating and demanding payment of such
part of the amount in respect of which the lien exists as is
presently payable has been given to the registered holder for
the time being of the share, or the person entitled by reason of
his death or insolvency.

Application
of 23.
proceeds of sale

The proceeds of the sale shall be received by the Company and
applied in payment of such part of the amount in respect of
which the lien exists as is presently payable and the residue, if
any, shall (subject to like lien for sums not presently payable as
existed upon the shares prior to the sale) be paid to the shares
at the date of the sale. The purchaser shall be registered as the
holder of the shares and he shall not be bound to see to the
application of the purchase money, nor shall his title to the
shares be affected by any irregularity or invalidity in the
proceedings in reference to the sale.

CALLS ON SHARES
Calls

24.

a). The Board, may from time to time, make calls upon the
members in respect of any moneys paid on their shares and not
by the conditions of allotment thereof made payable at fixed
times; provided that no calls shall exceed one fourth of the
nominal value of the share or be payable at less than one
month from the date fixed for the payment of last preceding call.
b) Each member shall, subject to receiving at least fourteen
days notice specifying the time or times and place of payment,
pay to the Company, at the time or times and place so specified

<!-- page 17 -->

the amount called on his shares.
c) A call may be revoked or postponed at the discretion of the
Board.
d). A call shall be deemed to have been made at the time when
the resolution of the Board authorizing the call was passed and
may be required to be paid by installments.
Several and Joint 25.
responsibility of
joint
share
holders

The joint holders of a share shall be jointly and severally liable
to pay all calls in respect thereof.

When interest on 26.
call payable

The provisions of these Articles as to payment of interest shall
apply in the case of non-payment of any sum which, by the
terms of issue of share become payable at a fixed time, whether
on account of the amount of the share or by way of premium, as
if the same had become payable by virtue of a call duly made
and notified.
The Board may, if it thinks fit, receive from any member willing
to advance the same all or any part of the moneys uncalled and
unpaid upon any share held by him and upon all or any of the
moneys so advanced may (until the same would, but for such
advance, become presently payable) pay interest at such rate
not exceeding, without the sanction of the Company in General
Meeting, six percent per annum as may be agreed upon
between the member paying the sum in advance and the
Directors.

Payment
in 27.
anticipation
of
call may carry
interest

If a sum called in respect of share is not paid before or on the
day appointed for payment thereof, the person from whom the
sum is due shall pay interest, as the Directors may determine
from the day appointed for the payment thereof to the time of
the actual payment, but the Board shall be at liberty to waive
payment of that interest wholly or in part.

FORFEITURE OF SHARES
Forfeiture
Shares

of 28.

If a member fails to pay any call or installment of a call on the
day appointed for payment thereof, the Board may, at any time
thereafter during such time as any part of such call or
installment remains unpaid, serve a notice on him requiring
payment of so much of the call or installment as is unpaid,
together with any interest which may have accrued.
The notice shall name a further day not being earlier than the
expiration of fourteen days from the date of service of the notice
is to be made and shall state that, in the event of non-payment

<!-- page 18 -->

on or before the time appointed, the shares in respect of which
the call was made will be liable to be forfeited.
Forfeiture
Share
resolution
notice

of 29.
by
after

If the requirements or any such notice as aforesaid are not
complied with, any share in respect of which the notice has
been given, may at any time thereafter, before payment
required by the notice has been made, be forfeited by the
resolution of the Board.

Disposal
of 30.
forfeited share

A forfeited share may be sold or otherwise disposed off on such
terms and in such manner as the Board thinks fit, and at any
time before a sale or disposition, the forfeiture may be cancelled
on such terms as the Board thinks fit.

Holder
of 31.
forfeited share to
cease to be a
Member

A person whose shares have been forfeited shall cease to be a
member in respect of the forfeited shares, but shall not
withstanding the forfeiture, remain liable to pay to the Company
all moneys which, at the date of forfeiture were presently
payable by him to the Company in respect of the shares, but his
liability shall cease if and when the Company shall have
received payment in full of all such moneys in respect of the
shares.

Declaration
forfeiture

A duly verified declaration in writing that the declarant is a
Director, the Manager, Secretary or Treasurer of the Company,
and that. a share in the Company has been duly forfeited on a
date stated in the declaration, shall be conclusive evidence of
the facts therein stated as against all persons claiming to be
entitled to the share and the receipt of the Company for the
consideration, if any, given for the share on any or disposal
thereof, shall constitute a good title to the share and the person
to whom the share is sold or disposed of shall be registered as
the holder of the share and shall not be bound to see to the
application of the purchase money, if any, nor shall his title to
the share be affected by any irregularity or invalidity in the
proceedings in reference to the forfeiture, sale or disposal of the
share.

of 32.

Borrowing Powers
Powers to
Borrow

33.

Subject to the provisions of Section 58A, 292 and 293 of the
Act, and Government Guidelines issued from time to time, the
Board may by means of resolution passed at meetings of the
Board from time to time, accept deposits or borrow and/or
secure the payment of any sum or sums of money for the
purpose of the Company.

<!-- page 19 -->

Issue at discount
etc. or with
special privileges

34.

Subject to Sections 79 and 117 of the Act and the approval of
the Government, any bonds, may be issued at a discount,
premium or otherwise and with any special privileges as to
redemption, surrender, drawings and allotment of shares.
GENERAL MEETINGS
All general meetings other than annual general meetings shall
be called extraordinary general meetings.

Notice to
General Meetings

35.

At least ‘twenty one clear days’ notice in writing, specifying the
place, day and hour of general meetings, with a statement of
the business to be transacted at the meeting shall be served on
every member in the manner provided by the Act but with the
consent, in writing, of all the members entitled to receive notice
of same, any general meeting may be convened by such
shorter notice and in such manner as those members may think
fit.

Holding
of 36.
Annual General
Meeting

Except in case when for any special reason time for holding any
annual general meeting (not being the first annual general
meeting) is extended under section 166 of the Act, shall be held
in accordance with section 166 and 210 of the Act.

When
Extra- 37.
Ordinary General
Meeting to be
called

1). The Board may, whenever it thinks fit, shall when required,
call an extraordinary general meeting.

Non receipt
notice
not
invalidate
proceedings

of 38.
to

The accidental non-receipt of any such notice by any member
shall not invalidate the proceedings of any meeting.

Business
of 39.
Annual General
Meeting

The business of an annual general meeting shall be to receive
and consider profit and loss account, the balance sheet, and
the report of the Directors and of the Auditors, to declare
dividends and to transact any other business which under these
Articles ought to be transacted at an annual general meeting in
terms of section 173 (1) of the Act. All other business
transacted at an annual general meeting and all business
transacted at an extraordinary meeting shall be deemed special
business.

2). If at any time all the directors are not within India, directors
capable of acting, who are sufficient in number to form a
quorum, any director or any two members of the Company may
call an extra-ordinary general meeting, in the same manner as
nearly as possible, as that in which such a meeting may be
called by the Board.

<!-- page 20 -->

Omission to give 40.
notice not to
invalidate
a
resolution
passed.
Quorum
41.

The accidental omission to give notice to or the non receipt
thereof by any member shall not invalidate any resolution
passed at any such meeting.
Five (Five) Members present in person shall be quorum for a
general meeting of the company.

Chairman of
General Meeting

42.

The Chairman of the Board of Directors shall be entitled to take
the Chair at every General Meeting, if there be no such
Chairman, or if at any Meeting he shall not be present within
fifteen minutes after the time appointed for holding such
Meeting or is unwilling to act as Chairman, the members
present shall choose another Director as Chairman, and, if no
Director shall be present, or if all the Directors present decline
to take the Chair, then the members present shall choose one
of the members to be the Chairman.

Chairman’s
decision
Conclusive

43.

The Chairman of any meeting shall be the sole judge of the
validity of every vote tendered at such meeting. The Chairman
present at the taking of a poll shall be the sole judge of the
validity of every vote tendered at such poll.

Power to adjourn 44.
General Meeting

The Chairman may, with the consent of any meeting at which a
quorum is present, and shall, if so directed by the meeting
adjourn the meeting from time to time and from place to place
but no business shall be transacted at any adjourned meeting
other than the business left unfinished at any meeting from
which the adjournment took place. When a meeting is
adjourned for one month or more notice of the adjourned
meeting shall be given as in the case of an original meeting.
Save as aforesaid, it shall not be necessary to give any notice
of an adjournment of the business to be transacted at an
adjourned meeting.
At any general meeting a resolution put to vote of the meeting
shall be decided on a show of hands, unless a poll is (before or
on the declaration of the show of hands) demanded in
accordance with the provisions of the Act, and unless a poll is
so demanded, a declaration by the Chairman that a resolution
has, on a show of hands been carried unanimously or by
particular majority, or lost and any entry to that effect in the
book of the proceedings of the company shall be conclusive
evidence of the fact, without proof of the number or proportion
of the votes recorded in favour of or against the resolution.

Proof of passing 45.
of a resolution
where poll not
demanded

Poll

46.

Equality of votes

47.

If a poll is duly demanded, it shall be taken in such manner as
the Chairman directs and the results of the poll shall be deemed
to be the resolution of meeting at which the poll was demanded.
In the case of an equality of votes, whether on a show of hand
or on a poll, the Chairman of the meeting at which the show of

<!-- page 21 -->

hands take place, or at which the poll is demanded shall be
entitled to a second or casting vote.
When poll can be 48.
taken
without
adjournment

A poll demanded on the election of a Chairman or on a question
of adjournment shall be taken forthwith. A poll demanded on
any other question shall be taken at such time as the Chairman
of the meeting directs

Chairman’s
decision
conclusive.

The Chairman of any meeting shall be the sole judge of the
validity of every vote tendered at such meeting. The Chairman
present at the taking of a poll shall be the sole judge of the
validity of every vote tendered at such poll.

49.

Votes of Members
Votes

50.

Every member entitled to vote and present in person or by
proxy shall have one vote on a show of hands and upon a poll
one vote for each share held by him.

Votes in
respect of
shares of
deceased
member

51.

Any person entitled under the transmission clause to transfer
any shares may vote at a General Meeting in respect thereof as
if he was the registered holder of such shares provided that at
least 72 hours before the time of holding the meeting or
adjourned meeting as the case may be at which he proposes to
vote he shall satisfy the Directors of his right to transfer such
shares unless the Directors shall have previously admitted his
right to vote at such meeting in respect thereof.

Form
of proxy

52.

Every instrument of proxy for a specified meeting or otherwise
shall as nearly as circumstances will admit, be in the form or to
the effect following;

HIMACHAL PRADESH STATE ELECTRICITY BOARD LIMITED
I___________________________a member of_____________do
hereby appoint _________________of_____________(or failing
him)______________________of____________________as my
proxy to attend and vote for me and on my behalf at the
Annual/Extraordinary General Meeting of the company to be held
on the________________day of _____________________and at
any adjournment thereof.
As
witness
my
hand
this___________________day
of_______________
Signed by the said____________________

<!-- page 22 -->

Company not
bound to
recognize any
interests
in shares
other than
that of the
registered
holders.

53.

Save as herein otherwise provided, the Directors shall be
entitled to treat the person whose name appears on the
register of members as the holder of any share as the absolute
owner thereof and accordingly shall not (except as ordered by
a Court of competent jurisdiction or as by law required) be
bound to recognize any benami trust or equitable, contingent or
other claim to or interest in such share on the part of any
person whether or not it shall have expressed or implied notice
thereof.

Board of Directors
Company to be
managed by a
Board of
Directors

Number of
Directors

Appointment
Board of
Directors

54.

The business of the Company shall be managed by a Board of
Directors.
(a) The following are the first directors of the Company:-

1.

Smt. Asha Swarup, IAS

2.

Sh. Ravinder Kumar Jain, IAS

3.

Sh. S.K.B.S. Negi, IAS

4.

Sh. Bhagat Singh Negi,

5.

Sh. Surendra Kumar Chaudhary

55.

The GOVERNMENT OF HIMACHAL PRADESH, shall, from time
to time, determine the number of Directors of the company which
shall not be less than three (3) and not more than Fifteen (15).
Six (6) of the Directors shall be Whole-Time Directors, out of
which One (1) will be the Managing Director, Two (2) Directors
(Electrical), One (1) Director (Civil/Mechanical) and
One (1)
Director (Finance), One (1) Director (Personnel) and others shall
be part time Directors. The Chief Secretary of GOVERNMENT
OF HIMACHAL PRADESH shall be the Chairman of the
Company unless otherwise decided by the GOVERNMENT OF
HIMACHAL PRADESH.
a) The Chairman, all other Members of the Board of Directors
shall be appointed by the GOVERNMENT OF HIMACHAL
PRADESH.

of 56.

b) The GOVERNMENT OF HIMACHAL PRADESH, may, from
time to time appoint any of the Directors, to the office of the
Managing Director, of the company for such term and
remuneration (whether by way of salary or other wise) as it
may think fit.

<!-- page 23 -->

Terms and
conditions
of the
appointment
Board of
Directors

57.
of

Alternate Director 58.

a). The Directors shall be paid such salary and/or allowance as
the GOVERNMENT OF HIMACHAL PRADESH, may, from time
to time, determine subject to the provisions of the Act.

b) The GOVERNMENT OF HIMACHAL PRADESH, may at any
time remove any Director either part-time or whole-time from
office at its absolute discretion.
In place of a Director who is out of India or is about to go out of
India or who expects to be absent for not less than three months,
the GOVERNMENT OF HIMACHAL PRADESH may appoint, in
consultation with the Chairman of the company, any person to be
alternate Director during his absence out of India and such
appointee, whilst he holds office as an Alternate Director, shall be
entitled to notice of meetings of the Board and to attend and to
vote there at accordingly.

Meeting of Board 59.
and Quorum

The Board of Directors may meet together for the transaction of
business once at least in every three months and at atleast 4
such meetings shall be held every year. They may adjourn and
otherwise regulate their Meeting and proceedings as they think fit
and may determine the quorum necessary for the transaction of
the business. Until otherwise determined one third of the total
strength of Directors (any fraction contained in that one third
being rounded off as one) or minimum two disinterested
Directors, whichever is higher shall be a quorum.

Delegation
of powers

a). Subject to the provisions of Sections 292 and 293 of the Act,
the Board of Directors may, from time to time, entrust and confer
upon the Chairman, Managing Director, Director for the time
being such of the powers as it may think fit and may confer such
powers for such time and to be exercised for such objects and
purposes and upon such terms and conditions and with such
restrictions as it may think expedient and may, from time to time,
revoke, withdraw, alter or vary all or any such powers.

Powers of
Chairman

60.

61.

b). The Chairman or Managing Director may sub delegate the
powers to such officers as deem fit for efficient and day-to-day
functioning of the Company.
a). The Chairman shall reserve for decision of GOVERNMENT
OF HIMACHAL PRADESH any proposals or decisions of the
Board of Directors or any matter brought before the Board
which raises in the opinion of the Chairman, any important
issue and which is on that account fit to be reserved for the
decision of GOVERNMENT OF HIMACHAL PRADESH and
no decision on such an important issue shall be taken in
absence of the Chairman.

<!-- page 24 -->

b). Without prejudice to the generality of the above provision, the
Board shall reserve for the decision of GOVERNMENT OF
HIMACHAL PRADESH any matter related to:(i). Agreement involving foreign collaboration proposed to be
entered into by the company.
(ii). The annual and five year annual plans for development and
the Company’s capital budget.
(iii). Winding up of the company.
(iv). Sale, lease, disposal or otherwise of the whole or
substantially the whole of the undertaking of the company.

Powers of
GOVERNMENT
OF HIMACHAL
PRADESH to
issue directives

62.

(v) Appointment of any person who has attained the age of 58
years (other than foreign technical personnel) on a pay/salary
of Rs.50,000/- per month and above including pension and/or
pension equivalent to retirement benefits.
Notwithstanding any thing contained in all these Articles,
GOVERNMENT OF HIMACHAL PRADESH may, from time to
time, issue such directives or instructions as may be considered
necessary in regard to conduct of business and affairs of the
Company and in like manner may vary and annul any such
directive or instruction. The Directors shall give immediate effect
to the directives or instructions so issued. In particular,
GOVERNMENT OF HIMACHAL PRADESH shall have the
powers:
(i). To give directive to the Company as to the exercise and
performance of its functions in matters involving national security
or substantial public interest.
(ii). To call for such returns, accounts and other information with
respect to the property and activities of the company as may be
required from time to time.
(iii). To provide wholly or partly owned Company(ies) or
subsidiary(ies) including participation in their share capital
irrespective of the sources from which the operations of such
companies are to be financed
(iv). To determine in consultation with the Board long term
financial and economic objectives of the company.
(v). To take decisions regarding entering into partnership and /or
regarding arrangements sharing profits.

<!-- page 25 -->

Provided that all directives issued by GOVERNMENT OF
HIMACHAL PRADESH shall be in writing addressed to the
Chairman/Managing Director. The Board shall, except where
GOVERNMENT OF HIMACHAL PRADESH considers that the
interest of national security requires otherwise, incorporate the
contents of directives issued by GOVERNMENT OF
HIMACHAL PRADESH in the annual report of the company
and also indicate (its impact on the financial position of the
company.
63.

No action shall be taken by the Company in respect of any
proposal or decision of the Directors reserved for the approval of
GOVERNMENT OF HIMACHAL PRADESH until its approval to
the same has been obtained. GOVERNMENT OF HIMACHAL
PRADESH shall have the power to modify such proposal or
decision of the Directors.

Directors may be 64.
Directors of
Companies
promoted by
the Company

A Chairman or Directors of this Company may be or become a
Director of any company promoted by this Company or in which it
may be interested as a vendor, member or otherwise and no
such Director shall be accountable for any benefit received as
Director or Member of such Company.

Omission to
give notice

65.

The accidental omission to give notice of any meeting of the
Directors to a Director shall not invalidate any resolution passed
at any meeting.

Question of
Board meeting
how decided

66.

Who is to
preside at
the meetings
of the Board

67.

A Director may at any time convene a meeting of Directors,
Questions arising at any meeting shall be decided by a majority
of votes and in case of an equality of votes, the Chairman shall
have a second or casting vote.
All meetings of the Directors shall be presided over by the
Chairman, if present. If at any meeting, the Chairman is not
present at the time appointed for holding the same, the Directors
shall choose one of the Directors then present to preside at the
meeting.

Board may
set up
committees

68.

The Board, may subject to the provisions of Section 292 of the
Act, delegate any of its powers to committees consisting of such
member or members of its body as it thinks fit, and it may from
time to time, revoke such delegation. Any committee, so formed
shall in the exercise of the powers so delegated conform to any
regulations that may, from time to time, be imposed on it by the
Directors. The proceedings of such a Committee shall be placed
before the Board of Directors at its next meting.

<!-- page 26 -->

Meetings of
69.
committees, how
to be
governed

The meetings and proceedings of any such Committee consisting
of two or more members shall be governed by the provisions of
the Act for regulating the meetings and proceedings of the
Directors, so far as the same are applicable thereto and are not
superseded by any regulations made by the Directors under the
last preceding Article.

Chairman of
meetings of
Committees

70.

A committee may elect a Chairman at its meetings, if no such
Chairman is elected, or if at any meeting the Chairman is not
present within 15 minutes after the time appointed for holding the
same, the members present may choose one of the members to
be Chairman of the meeting.

Specific powers 71.
given
to
Directors

Subject to the provisions of the Act and without prejudice to the
general powers conferred by these Articles, the Directors shall
have the following powers, that is to say powers:

To make
laws

bye

(i). To make, vary and repeal, from time to time, bye-laws for the
regulation of the business of the Company, its officers and
servants;

To pay and
charge
interest
etc.

(ii). To pay and charge to the capital account of the company any
interest lawfully payable there at under the provisions of the
Act.

To acquire
property

(iii).To purchase, take on lease or otherwise acquire for the
Company property, rights or privileges which the company is
authorized to acquire at such price and generally on such
terms and conditions as they think fit.

To pay for
property in
debentures

(iv).To pay for any property or rights acquired by or services
rendered to the Company, either wholly or partially in cash, or
in shares, bonds, debentures, debenture stock or in shares
that may be issued either as fully paid up or with such amount
credited as paid up thereon as may be agreed upon, and any
such bonds, debentures, debenture stock or other securities
may be either specifically charged upon all or any part of the
property of the Company and its uncalled capital or not so
charged.

To secure
contracts by
mortgage

(v).To secure the fulfillment of any contracts or engagements
entered into by the Company by mortgaging or charge of all or
any of the property of the Company and its unpaid capital for
the time being or in such other manner as they think fit;

To refer to
arbitration

(vi).To refer any claim or demand by or against the company to
arbitration and observe and perform the awards;

<!-- page 27 -->

To invest
money

(vii).To invest in such securities as may be approved by
GOVERNMENT OF HIMACHAL PRADESH and deal with any
of the moneys of the Company upon such investment
authorized by the Memorandum of Association of the
Corporation (not being shares in the company) and in such
manner as they think fit and, from time to time, vary and
realize such investments.

To give
Bonus and to
create Provident
Fund

(viii).To provide for the welfare of the employees or ex-employees
of the company or of its predecessors in business and the
wives, widows and families or the dependents or connections
of such employees or ex-employees by building or
contributing to the building of houses, dwellings or chawls or
by grants of money, allowances, bonuses, profit sharing
bonuses or benefit of any other kind or by creating and from
time to time subscribing or contributing to provident and other
association, institution funds, profits sharing or other scheme
or trusts or by providing or subscribing or contributing
towards places of instruction and recreation, educational
institutions, hospitals and dispensaries, medical and other
attendances and any other form of assistance, welfare or
relief as the Directors shall think fit.

To subscribe
to other
funds

(ix).To subscribe or otherwise to assist or to guarantee money to
scientific institutions or objects.

<!-- page 28 -->

To create
depreciation
and other
funds

To create
posts

(x).To set aside before recommending any dividend out of the
profit of the Company such sums as they may think proper for
depreciation or to Depreciation Fund, Reserve or to Reserve
fund to meet contingencies or Insurance Fund or any special
or other Fund to meet contingencies or to repay redeemable
preference shares and for
special
dividends and for
equalizing dividends and for repairing and replacements,
improving, extending and maintaining any part of the
properties of the company and for such other purposes
(including the purposes referred to in the sub clause ix) as the
Directors may, in their absolute discretion think conducive to
the interest of the company and to invest the several sums so
set aside or so much thereof as required to be invested upon
such investments (Subject to the restriction imposed by the
Act) as the Directors may think fit, and from time to time to
deal with and vary such investments and dispose of and apply
and expend all or any part thereof for the benefit of the
company in such manner and for such purposes as the
Directors (subject to such restriction as aforesaid) in their
absolute discretion think conducive to the interest of the
company notwithstanding that the matters to which the
Directors apply or upon which they expend the same, or any
part thereof, may be matters to or upon which capital moneys
of the company might rightly be applied or expended and to
divide the Reserve Fund into such special funds as the
Directors may think fit and to employ the assets constituting all
or any of the above funds, including the Depreciation Fund, in
the business of the Company or in the purchase or repayment
of Redeemable Preference Shares and that without being
bound to keep the same separate from the other assets, and
without being bound to pay or allow interest on the same,
with power, however to the Directors at their discretion to pay
or allow to credit such fund interest at such rate as the
Directors may think proper, not exceeding six percent per
annum.
(xi).To create such posts with the prior approval of the State
Govt., other than those to which appointment is made by
GOVERNMENT OF HIMACHAL PRADESH as
may be
considered necessary, for the efficient conduct of the
Company’s affairs and to determine the scale of pay and other
terms thereof except for posts(s) immediately below the Board
level for whom the scale of pay and other terms will be
decided by GOVERNMENT OF HIMACHAL PRADESH.

<!-- page 29 -->

To appoint
officers

(xii).Subject to Article 61 to appoint and at its discretion remove
or suspend all such officers and employees from permanent,
temporary or special services as it may, from time to time,
think fit and to determine their powers and duties and fix their
salaries or emoluments and require security in such instances
and to such amounts as it may think fit and also without
prejudice as aforesaid from time to time to provide for the
management and transaction of the affairs of the Company in
any specified locality in India in such manner as it thinks fit ;

Authority to
Sub-delegate
Powers

(xiii).Subject to section 292 of the Act, to sub-delegate all or any
of the powers, authorities and discretion for the time being
vested in the Directors, subject, however, to the ultimate
control and authorities being retained by it.
(xiv).Any such delegate or attorney as aforesaid may be
authorized by the Directors to Sub-Delegate all or any of the
powers, authorities and discretion for the time being vested in
them; and

To lend
money

(xv).To lend moneys to subsidiaries and associated Organization,
on such terms and conditions as they may consider
desirable.
THE SEAL

The seal and its 72.
custody

a).The Board of Directors shall provide a Common Seal for the
purpose of the Company and shall have power from time to
time to destroy the same and substitute a new seal in lieu
thereof. The Board of Directors shall provide for the safe
custody of the seal.

Issue of
the seal

b).The seal of the company shall not be affixed to any
instrument except by the authority of a resolution of the Board
or a Committee of the Board authorized by it in that behalf
and except in the presence of at least two Directors and of
the Secretary or such other persons as the Board may
appoint for the purpose and those two Directors or such other
persons as aforesaid shall sign every instrument to which the
seal of the Company is so affixed in their presence.
Division of Profits and Dividend

<!-- page 30 -->

Division of
Profit

73.
(i)

The profits of the Company available for payment of dividend
subject to any special rights relating thereto created or
authorised to be created by these presents and subject to the
provisions of the Act and these presents as to the reserve fund
and amortisation of capital shall be divisible among the members
in proportion to the amount of capital paid-up by them
respectively. Provided always that (subject as aforesaid) any
capital paid-up on a share during the period in respect of which a
dividend is declared shall only entitle the holder of such share to
an apportioned amount of such dividend as from the date of
payment.

(ii)

No dividend shall be declared or paid by the company for any
financial year except out of profits of the company for that year
arrived after providing for the depreciation in accordance with
the provisions of sub-section (2) of section 205 of the Act or out
of profits of the company for any previous financial year or years
arrived after providing for the depreciation in accordance with
applicable laws and remaining undistributed or out of both or out
of moneys provided by the government for the payment of
dividend in pursuance of a guarantee given by the government.
No dividend shall carry interest against the Company.

(iii)

For the purpose of the last preceding article, the declaration of
the dividend as to the amount of the profits of the company shall
be conclusive.

(iv)

Subject to the provisions of section 205 of the Act as amended,
no dividend shall be payable except in cash.

(v)

A transfer of shares shall not pass the right to any dividend
declared thereon after transfer and before the registration of the
transfer.

(vi)

Any one of the several persons who are registered as the joint
holders of any shares, may give effectual receipts for all
dividends and payments on account of dividends in respect of
such shares.

(vii)

Unless otherwise directed any dividend may be paid by cheque
or demand draft or warrant or such other permissible means to
the registered address of the member or person entitled or in the
case of joint holding, to the registered address of that one whose
name stands first in the register in respect of the joint holding
and every cheque, demand draft or warrant so sent shall be
made payable to the member or to such person and to such
address as the shareholder or the joint shareholders in writing
may direct.

<!-- page 31 -->

The Company in
74.
General Meeting
may
declare a
dividend

The company in a General Meeting may declare a dividend to be
paid to the members according to their respective rights and
interest in the profits and may fix the time for payment but no
dividend shall exceed the amount recommended by the Board.

Interim dividend

The Directors may, from time to time, pay to the members such
interim dividends as in their judgment the position of the
Company justifies.

75.

Accounts
76.

The Directors shall cause to be kept proper books of accounts in
accordance with the provisions of section 209 of the Act with
respect to :a)
b)
c)

all sum of money received and expended by the company
and the matters in respect of which the receipts and
expenditure take place;
all sales and purchases by the company;
the assets and liabilities of the company where the
company has a branch office, the company shall be
deemed to have complied with this Article if proper books of
accounts relating to the transactions affected at the branch
office are kept at the branch office and proper summarized
returns, made up to date at intervals of not more than three
months, are sent by the Branch Office to the company at its
Registered Office or other place in India at which the
company’s books of accounts are kept as aforesaid.

The books of account shall be kept at the registered office of the
company or at such other place as the Board shall think fit and
shall be open to inspection by any Director during business
hours.
Inspection by
members of
accounts and
books of the
company

77.

The Directors shall, from time to time, determine whether and to
what extent and at what time and places and under what
conditions or regulations the accounts and books of the
company or any of them shall be open to the inspection of the
members not being Directors but no member (not being a
Director) shall have right of inspecting any account or book or
document of the Company, except as conferred by law or
authorized by the Board or by the company in General Meeting.

<!-- page 32 -->

Audit
Accounts to
be audited
annually

78.

Once at least in every financial year the account of the Company
shall be examined and the correctness of the profit and loss
accounts and Balance Sheet ascertained by one or more
auditors.

Appointment
Auditors

of 79.

The auditor/auditors of the Company shall be appointed or
reappointed in accordance with the provisions of Section-619 (2)
of the Companies Act 1956.

Auditors right
to attend
meetings

80.

The auditors of the company shall be entitled to receive notice
of and to attend any General Meeting of the company at which
any accounts which have been examined or reported on by them
are to be laid before the company and may make any statement
or explanation they desire with respect to the accounts.

When accounts
to be
deemed finally
settled

81.

Every account of the company when audited and adopted by a
general meeting shall be conclusive.

Notice
Notice on
persons
acquiring shares
on
death or
insolvency of
members

82.

A notice may be given by the Company to the persons entitled to
a share in consequence of death or insolvency of a member by
sending it through the post in a prepaid letter addressed to them
by name or by the title or representatives of the deceased or
assignee of the insolvent or by any like description at the
address (if any) in India supplied for the purpose by the persons
claiming to be so entitled or until such an address has been so
supplied by giving the notice in any manner in which the same
might have been given if the death or insolvency had not
occurred.

<!-- page 33 -->

WINDING UP
Distribution
assets

of 83.

If the company shall be wound up and the assets available for
distribution among the members as such shall be insufficient to
repay the whole of the paid up capital, such assets shall be
distributed so that as nearly as may be, the losses shall be
borne by the members in proportion to the capital paid up at the
commencement of the winding up, on the shares held by them
respectively. And if in a winding up, the assets available for
distribution among the members shall be more than sufficient to
repay the whole of the paid up capital such assets shall be
distributed amongst the members in proportion to the original
paid up capital as the shares held by them respectively. But this
clause is to be without prejudice to the rights of the holders of
shares issued upon special terms and conditions.

Secrecy
Secrecy Clause

84.

No members shall be entitled to visit or inspect the Company’s
work without the permission of Director or to require discovery of
or any information respecting any detail of the Company’s
trading or any matter which is or may be in the nature of a trade
secret, or secret process which may relate to the conduct of the
business of the Company and which in the opinion of the
Directors, will be inexpedient in the interest of the members of
the company to communicate to the public.

Indemnity and Responsibilities
Director’s
others
right to
indemnity

and 85.

a). Subject to the provisions of section 201 (1) of the Company’s
act., every Director, Manager, Auditor, Secretary or other
officer or employees of the company shall be indemnified by
the company against and it shall be the duty of the Directors
out of the funds of the company to pay all costs, losses and
expenses (including traveling expenses) which any such
Director, Manager, Officer or employee may incur or become
liable to by reason of any contract entered into or act or deed
done by him or them as such Director, Manager, Officer or
servant or in any other way in the discharge of his duties and
the amount for which such indemnity is provided shall
immediately attach as a lien on the property of the company
and have priority as between the Members over all other
claims.

<!-- page 34 -->

b). Subject as aforesaid every Director, Manager or officer of the
company shall be indemnified against any liability incurred by
him or them in defending any proceedings whether civil or
criminal in which judgment is given in his or their favor of in
which he is or they are acquitted or in connection with any
application under section 633 of the Act in which relief is
given to him or them by the Court.
Not responsible
for acts
of others

86.

Subject to the provisions of section 201 of the Act, no Director,
Manager or other officer of the company shall be liable for the
acts, receipts, neglects or defaults of any other Director or officer
or for joining in any receipt or other act for the sake of conformity
or for any loss or expense happening to the company through
insufficiency or deficiency of title to any property acquired by the
order of the Director for or on behalf of the company or for the
insufficiency or deficiency of any security in or upon which any of
the moneys of the company shall be invested or for any loss or
damage arising due to the bankruptcy, insolvency or tortuous act
of any person, company or corporation with whom any money,
securities or effects shall be entrusted or deposited or for any
loss occasioned by an error of judgment or oversight on his or
their part or for any other loss or damage or misfortune
whatsoever, which shall happen in the execution of duties of his
or their office or in relation thereto unless the same happens
through his own dishonesty.

Ownership
Pattern
and Equity
Holding:

87.

The equity of the Himachal Pradesh State Electricity Board
Limited shall be contributed by the Government of Himachal
Pradesh.

Benefits

88.

The benefits accruing from the Himachal Pradesh State
Electricity Board Limited shall be shared by the Government of
Himachal Pradesh only.

<!-- page 35 -->

Name of subscriber,
address, description
and occupation, if
any
On behalf of Governor:
1. Smt. Asha Swarup, IAS, Chief
Secretary to the Govt. of Himachal
Pradesh
2. Sh. Ravinder Kumar Jain, IAS,
Chairman HPSEB,Shimla-171004
3. Sh. S.K. B. S. Negi, IAS
Member (Finance & Accounts))
HPSEB, Shimla -171004
4. Sh. Bhagat Singh Negi
Member (Projects)
HPSEB, Shimla-171004
5. Sh. Surendra Kumar Chaudhary
Member (Operation)
HPSEB, Shimla-171004

Dated: this day 19.11.2009

Signature
of
subscriber

Signature of
witnesses and
their addresses,
description and
occupation, if any

Signed in my presence

Sudershan Kumar Sharma
