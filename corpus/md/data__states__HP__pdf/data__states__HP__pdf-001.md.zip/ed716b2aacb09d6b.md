---
doc_id: "ed716b2aacb09d6b"
source_url: "https://www.gcsolan.ac.in/pdf/wdc/report-on-Vishaka-Guidelines-lecture.pdf"
ministry: "Government College Solan, Himachal Pradesh"
title: "View PDF"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3a6240d35fc493f4"
---

<!-- page 1 -->

Government Degree College, Solan (H.P.)

Affiliated to Himachal Pradesh University, Shimla – 171005 Accredited by NAAC with Grade B++
WOMEN EMPOWERMENT /WOMEN GRIEVANCE REDRESSAL CELL
Report on Awareness Lecture on Vishaka Guidelines and POSH Act
August 21, 2025
The Committee Against Sexual Harassment and Women Empowerment Cell of Government College,
Solan, organised an awareness lecture on the Vishaka Guidelines and the Prevention of Sexual
Harassment (POSH) Act, 2013, in the College Hall on August 18, 2025, at noon. The chief guest for the
event was Dr. Maneesha Kohli, Principal, GC Solan. The session aimed to sensitise students and staff
about legal safeguards against sexual harassment and the role of institutions in ensuring a safe
environment.
The event commenced with Dr. Priyanka Bhardwaj, Assistant Professor of Hindi and a member of the
Women Cell, who apprised the audience about the various activities undertaken within the purview
of the Cell. The sensitisation lecture was conducted by Prof. Aalisha Chauhan, Assistant Professor of
English and a member of the Women Cell, who provided valuable insights about the origin of the
Vishaka Guidelines, the provisions of the POSH Act, and the functioning of Internal Complaints
Committees. The lecture also included case studies and interactive discussions, making the session
engaging and informative. The efforts of all the members of the Women Cell in contributing to the
smooth organisation of the lecture were deeply appreciated
Students and faculty actively participated and clarified their queries. The programme concluded with
a vote of thanks by the Women's Cell coordinator. Overall, the event successfully raised awareness
about gender justice and the importance of maintaining a respectful campus atmosphere.

Convenor
Women Cell

Principal
G. C. Solan
