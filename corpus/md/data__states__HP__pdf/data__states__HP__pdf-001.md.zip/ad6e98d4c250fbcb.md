---
doc_id: "ad6e98d4c250fbcb"
source_url: "https://ddtg.hp.gov.in/wp-content/uploads/2021/08/corrigendum-of-tender-for-hiring-five-outsource-vehicle-taxi-on-monthly-rental-basis.pdf"
ministry: "Digital Technologies and Governance Department, Himachal Pradesh"
title: "Tender notice for hiring five outsource vehicle (taxi) services on monthly rental basis (OLD)"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "9b977d8e306d364b"
---

<!-- page 1 -->

ia Society for Promotion of IT and E-Governance
Short TermTender
for Hiring of Five Outsource Vehicle Services (TAXI)
on monthly rental basis in the Office of
HP Society for Promotion of IT and E-Governance
Tender No: DIT-B0I5/47/20I8- E-77
७ |
U unachal
dit
Department of Information Technology,
Government of Himachal Pradesh,
IT Bhawan, Shoghi Bypass Road, Mehli,
Shimla, Himachal Pradesh — 703
Tel: 0I77- 262894;
Email:dirit-hp@gov.in;
l

<!-- page 2 -->

<< सससत?तणतएणछ6७टक्‍तय।+ ee नमक ——————_—_ ee
= orrigendum
Tender Reference Number: No. | DIT-B0I5/47/208- E-77
Tender Name: Tender for Hiring of five outsource vehicles Services (TAXI) on monthly
rental basis in the office of HP Society for Promotion of IT and E-Governance
Schedule of events
Last date (deadline) for submission th .
. 3'" August, 202] time up to 4:00 PM
of bids
a Date of Bid Opening 3" August, 202 at 3:00 PM
The bid Submission date for the tender is extended to I3" August, 202I as mentioned
above in the Schedule of events table.
ae > AI
Di r (IT)-tum}Member Secretary (EC),
Department of Information Technology,
Government of Himachal Pradesh.
2
