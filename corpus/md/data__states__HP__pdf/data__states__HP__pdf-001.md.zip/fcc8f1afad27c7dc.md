---
doc_id: "fcc8f1afad27c7dc"
source_url: "https://cdn.s3waas.gov.in/s37647966b7343c29048673252e490f736/uploads/2026/07/17854808055915.pdf"
ministry: "Lahaul And Spiti"
title: "Tender Docs (5 MB)"
date: ""
pages: 7
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "1148789a6d620bf8"
---

<!-- page 1 -->

॥ Zod OFFICE OF DEPUTY COMMISSIONER DISTRICT LAHAUL
०८७७४ rm E-mail de-lah@nic.in Phone No. 0900-20250
—_oo_ EE Ee
Table of Contents
The office of Deputy Commissioner-cum- Chairman, Tribal Fair Organization
Committee Lahaul Spiti invited sealed covered bids in 2 covers system for under
mentioned work from the eligible contractors/firms.
Sr. | Name of Work EMD
No.
Hiring of Orchestra for | 3 days 30,000/- 500/-
stage at Police Ground
Keylong during Tribal
Fair 2026 wef
4.08.2026 to
6.08.2026.
Key Dates:-
Sr. Particular Time
No.
Date of Online Publication download 30.07.2026 | 03:00 PM
start date
2 Bid submission start date 3.07.2026 | 0:00 AM
Bid submission close date 05.08.2026 | 2:00 PM
[4 _| Date of opening of Bids 05.08.2026 | 03:00 PM
The interested parties/Firms can submit the bid on or before the last date and time
mentioned above. The tender must be accompanied with an earnest money of Rs.
30,000/- (Thirty Thousand Rupees) only in the shape of Demand Draft duly pledged
in the name of Deputy Commissioner-cum- Chairman, Tribal Fair Organizing
Committee Lahaul & Spiti at Keylong. The tenders without earnest money or short or
not in form/specified above will be rejected straightway.
AC to ih Chairman,
Tender Committee,
Tribal Fair Organization Committee.

<!-- page 2 -->

Annexure-I
SCOPE OF WORK:-
The Tribal Fair- 2026 will be held Keylong w.e.f. 4.08.2026 to
6.08.2026. During this Festival Cultural programme will be held in the evening at
Police Ground Keylong w.e.f 4.08.2026 to 6.08.2026in which various Hindi,
Punjabi and Himachali singers will give their performances the following instruments
as per the term and conditions thereafter are required to perform with Orchestra for
cultural nights at Police Ground Keylong stage during Tribal Fair-2026.
Sr. [Pescrintion Qty. Proposed
No
कं
[6 _| Electric Pad/Octopod
[8_|
[97
[Cows SCP #४ट
Note:- The above requirement is tentative and the final order will be at the
discretion of the Organizing Committee. The layout of the venue and stage of
the culture evenings ie. Police Ground, Keylong may be inspected by the
interested parties on their own before quoting the rates and proposed quantity
of the equipment.
l. The rates of the above items should be quoted on per unit basis for each item
separately for all three days on the above format. The quoted price shall be
| inclusive of all taxes.
| 2. The Orchestra Party should have experience of participation in 2 National level
fair/festivals and three State level/ JIT/IIM/ renowned Medical
| Collage/Universality or Corporate shows during the last 5 years..
| 3. The bidder should attach the ITR of last three financial years with the
' technical bid.
| 4, The Orchestra Party must have atleast 6 to 7 members in its team. a
| 5. The Orchestra Party must have the Musical instrument as detailed Financial
| Bid (Annexure-]).. Oe
| Assistat sioner ee
Density Commision Dr
Lanead Spti, Diet
| . ‘

<!-- page 3 -->

/ 6. The quoted price shall be inclusive of all taxes. Tax at source as applicable
/ shall be deducted from the rates quoted by the parties,
7. No advance payment shall be made and the payment shall be made after
/ successful completion of the job to the satisfaction of the procurement
/ committee. The payment shall be released on the recommendation of the
committee. The payment shall be paid after deducting TDS as Applicable
8. Bidders should submit technical and financial bids. The technical bid and the
financial bid shall be sealed by the bidder in separate covers duly super-
scribed. Cover -I contain all required technical documents along with EMD
and Cover-II contain only Financial Bid. Both these sealed covers shall be put
in a bigger cover which shall also be sealed and duly super-scribed and
captioned as, “providing Orchestra Parties during the Tribal Fair Lahaul
& Spiti-2026, scheduled to be held at Keylong from I4th August, 2026 to
6th August, 2026.

¢ The First Envelope must contain the Technical proposal and
must be super scribed in bold letters as "TECHNICAL BID", and
shall contain the documents as prescribed in the Check list for
Technical Bid.

e The Second Envelope must contain the Financial Proposal in the
prescribed Performa given at Annexure III (should be submitted
in separate sealed cover not with the technical bid.) duly filled in
and must be super scribed in bold letters as "FINACIAL BID".
Financial bids only of the technically acceptable offers, shall be
opened for further evaluation and ranking before awarding the
contract. No conditional bid shall be accepted.

9. The Firm will be responsible himself for the custody and safety of items
supplied.
0.The committee shall reserve the rights to change about the make of the
equipment/brand at the time of finalization of tender.
I.The Deputy Commissioner-cum Chairman Tribal Fair Organizing Committee
reserves the right to cancel all or any tenders without assigning any reason.
AC to oY raemon,
| Tender Committee,
| Tribal Fair Organization Committee.
|
|
} ee मम पक

<!-- page 4 -->

| Annexure-II
Particulars of the Firm/Party ete: of the Firm/Party ete:
], Name of the firm ete. :
2. Head Office Address
3. Office Address
4. Type of Organization : Individual / Partnership / Incorporated/
5. Copy of firm's/company's registration attached (Yes/No)
6. Amount of EMD deposited
a) Draft/ Challan.
b) Bank Detail
c) Amount
7. DD of Tender Fee, (please provide details)
8. Supporting documents in connection with experience attached (yes/no)
9. Undertaking as per point No 5 of Term & conditions. attached (Yes/No) :
!0, Name and address of the authorized signatory / contact person for this Tender :
I]. Whether letter of Authority for : attending bid opening attached (Yes/No) enclosed
with Tender ? attached (Yes/No)
2. Whether PAN copy attached (Yes/No)
3. Copy of GST certificates attached (yes/No)
4. Copies of ITRs for the last 3 years attached (Yes/No)
5. Copy of first page of Bank Pass book/ statement attached (Yes/No) :
i6. Acceptance letter of having Orchestra Party consisting of atleast 6 to 7 members
7. Undertaking as per annexure-V attached (Yes/No)
Date: Signature of Bidder
Place Name
With seal of the Firm
0०970 Cosson vy
Lena Sp Diabet

<!-- page 5 -->

५ वि A
Financial Bid for stage at Police Ground Keylong nnexure III
pos
fi (Name & E
Address of the firm) hereby quoted the lump-sum rates as given below: t हु
ORCHESTRA PARTY i
rh Description Qty. Unit Rates | Total Amount | !
° Proposed | (inclusive of all (inclusive tax and | t
taxes and | GST) | $
charges: ]
] |
पर /[' |
वा [री [र(र् ्इ् |
Dholak & Hand Sonie [7 | t
Tabla Set i
See palOaopes [PP
es
[8 _| Drum Set (Pearl i | t
[>| Punjabi Dhol व्यय '
Rate offer for all items for feeds LR days w.e.f. 4.08.2026 to 6.08.2026 है
Further following are the names of the musician(6-7 who play the instruments) with
full address
ionature of Bidder Name t
Date: Signature i =
With seal of the Firm |
Place
20००० E
Desty Comino 7 ५
Laneu! Sed, District Re

<!-- page 6 -->

Check list of
हे . Techni : A
gre technical bid should contain Daa bid (Envelope-) nnexure IV
T . Owing di
separate cover. The financial bid will be chen calles (self attested) sealed in
the technical parameters based on the followin: हि OF those bidders who qualify
must be containing in Technical Bid: & documents. All these documents
Documents Requirement
No Attached at Page No.
/
coms for Technical Bid (annexure-II) ee
opy of Tender documents duly si a PT
ages(Annexure ~I) y signed exch
D.D. of Tender fee. LT
[EMD COSCO
[6 | Copy of Registration of firm | |
Copy of GST certificate | ऊऋई
|8__| Copy of PAN No. of Firm [oo
|9 | Copy of Authorization of firm िििशिश
0 | Undertaking as per point no 8 of Terms & | |
conditions.
Under taking regarding Annexure -V [|
Copies of ITR as required. Cd
Co
Experience Certificates( Relevant documents) [t~—“CSCS
Copy of Ist page of Bank passbook/ Statement. [._._.... फ ् ।
Note: All papers should be self attested.
Date: , Signature of Bidder Name
Place With seal of the Firm
Agoistant Lamar
Deputy Ce: nes
Lenaa! Spt, Datsict

<!-- page 7 -->

d
Annexure-V
Undertaking
_ & Address of the firm/ Contractor)
hereby declare that I have read the tender document thoroughly and understand
the scope of work before quoting the rate of each items. I further declare that I
have visited the site/ sites as mentioned in tender document before quoting the
rates. I also declare that I will perform all the work up to the satisfaction of the
4 Authority and for any violation penalty can be imposed on me as per the term &
j
j conditions of Tender document and prevailing law.
Date: Signature of Bidder Name
Place With seal of the Firm
|
|
| ०००० 0 etsioero
{ Deputy Corre श्र
। (नल्थ आॉ0 बा
i .
i
i
i
|
;
।
||
a
