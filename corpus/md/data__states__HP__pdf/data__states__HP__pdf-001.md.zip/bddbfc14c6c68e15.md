---
doc_id: "bddbfc14c6c68e15"
source_url: "https://planning.hp.gov.in/NewReleases\Equal_opportunity_policy.pdf"
ministry: "Planning Department, Himachal Pradesh"
title: "Equal opportunity policy in respect of employees of Planning Department"
date: ""
pages: 4
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "d2dfd46b7db022b6"
---

<!-- page 1 -->

Government of Himachal Pradesh
Planning Department
G Sh"
No. PLG(B)I-3/20I6 Shimla-2,the Dated Feb,2020
NOTIFICATION
The Governor, Himachal Pradesh in exercise of the
powers conferred under Section 2! of The Rights of Persons with Disabilities
Act, 20I6, is pleased to notify Equal Opportunity Policy for Persons with
Disabilities employees in respect of Planning Department in the State of HP as
per Annexure “A” with immediate effect.
हु By Order
Principal Secretary (Planning) to the
Government of Himachal Pradesh.
Endst. No: As above Dated: Shimla-2, the ab rebruary, 2020
Copy forwarded to :-
l. The Commissioner (Disability)-cum-Additional Chief Secretary
(SJ&E) to the Govt. of Himachal Pradesh.
2. The Director, Empowerment of SCs, OBCs, Minorities & Specially
abled, H.P., Shimla-!7009.
Deputy ng (Plan a ) to the
: Government of Himachal Pradesh.
Scanned with CamScanner

<!-- page 2 -->

. c
, Annexure “A”
Equal Opportunity Policy in respect of employees of Planning Department, Himachal
Pradesh, Shimla-2.
Background: ५

The Government of India has enacted Rights of Persons with Benchmark
Disabilities (RPwD) Act, 20I6, The Section 2I(I) states that every establishment shall
notify Equal Opportunity Policy and also Section 2(2) of the Act, envisages that every
establishment shall register a copy of the said policy with the State Commissioner for the
Persons with Disability.

Objective

This Policy aims to safeguard the equality of self-determination, dignity and
inclusion of Persons with Benchmark Disability employees working in the Planning
Department Headquarter as well as at Districts level offices.

The objectives of this policy is to ensure that all the Persons with Benchmark
Disability Employees of this Department are not only to improve the quality of life of
person with benchmark disability, but also to promote and safeguard equality, self-
determination, dignity and social inclusion of persons with benchmark disability.

The Persons with Benchmark Disabilities include those who have long-term
physical, mental, intellectual or sensory impairments and possesses certificate of disability
issued by a competent authority under section 57 of the RPwD Act, 20I6.

Applicability

This Policy is applicable to the Employees having Benchmark Disability of the

Department. This Policy is consonantly applied throughout the period of employment of
(ha the employee right from his recruitment till his/her employment in the Department.
Policy

it is the policy of Planning Department, Himachal Pradesh, to provide equal
employment opportunities, without any discrimination on the grounds of caste, colour,
disability, marital status, nationality, race, religion, sexual orientation. The Planning
Department, H.P. retrieve to maintain a work environment that is free from any
harassment based on above considerations. This Equal Opportunity Policy is subject to
applicable regulations, qualifications and merit of the individual. This Policy will
consistently be applied throughout the period of employment of the individual, right from
the recruitment process till retirement from service.

Equal Opportunity and Non- Discrimination

in accordance with the provisions of the Rights of Persons with Disabilities Act,
20I6 and Rules, 20I7, it is the policy of Planning Department to ensure that the work
environment is free from any discrimination against the Persons with Benchmark
Disabilities. Further, the Planning Department will take all actions to ensure that a
conducive environment is provided to persons with benchmark disabilities to perform their
role and excel in the same. The Planning Department strives towards establishing systems
and processes to ensure:

Scanned with CamScanner

<!-- page 3 -->

« oa |
oA |
|
|
( |
५ \. That appropriate facilities and amenities would also be provided to persons with |
disabilities to enable them to effectively discharge their duties in the establishment
$ and no officer/official shall be deprived of his or her personal liberty on the ground
ofdisability.
2. That provision shall be made for an accessible environment, accessible buildings
and availability of assistive paraphernalia as required to enable the persons with
benchmark disabilities to effectively discharge their duties in the establishment.
3. That a Grievance Redressal Mechanism for addressing the matters relatedto the
employment of persons with benchmark disabilities is available. Joint Director
(Planning) is the Grievance Redressal Officer which will look after all the
grievances of the PwDs in the Planning Department and the same is accountable to
Adviser (Planning).
4. That the various Divisions in the Planning Department Headquarter level and in
the respective District Planning Offices at Districts level will ensure that if any
grievance does arise & is brought up to the concerned committee/officer with
respect to selection of Person(s) with Benchmark disabilities for any position,
. training, promotion, transfer posting, leave, assistive aid & preference in
accommodation allocation etc. is dealt with in a fair and equitable manner free
. from anydiscrimination.
5. That no opportunities are denied to persons with disabilities merely on the ground
of hisdisability.
6. No discrimination practices are to be engaged in the course of employment of
persons with a benchmark disability, including recruitment and career
advancement or not to dispense with or reduce in rank an employee who acquires a
disability during his or her service. Provided that if an employee after acquiring
disability is not suitable for the post he was holding, shall be shifted to some other
Ws post with the same pay scale and service benefits. Provided further that if it is not
possible to adjust the employee against any post, he may be kept on a
supernumerary post until a suitable post is available or he attains the age of
superannuation, whichever isearlier.
Identification of Posts for Reservation
The Planning Department, H.P. Shimla-2, shall identify the posts reserved for
Persons with Benchmark Disabilities as per section 34(I) of the RPwD Act, 206 that
provides of 4% reservation to the Persons with Benchmark Disabilities. The information
regarding identified posts and vacancies would be notified and uploaded on the website of
this Department. The identified posts shall be filled up by the Planning Department as per
the directions issued by the State Govt. from time to time and the same shall also be
furnished to the employmentexchange.
Manner of Selection
The Planning Department adopts the selection policy of the State Government
regarding filling up of posts reserved for the Persons with Disabilities.
Leave .
The Specially Abled employees of this Department will be governed by the rules of
leave specified by the State Government from time totime.
Scanned with CamScanner

<!-- page 4 -->

+k
# Liaison Officer
f
The Administration (Establishment) of the Planning Department will ensure a
Liaison officer is designated at Headquarter level to oversee the provision of required
facilities/amenities including the process of recruitment of Persons with Benchmark
Disabilities. Such Officer shall be accountable to Adviser (Planning) directly. Joint
Director (Planning) will be the liaison officer will look after the recruitment of Persons
with Benchmark Disabilities.
Complaints/Grievance and their Disposal
A register of complaints/grievances has been maintained in the office and a
Grievance Redressal Officer has been appointed to hear the pleading/request/grievances
of Persons with Disabilities working in the Planning Department.
Responsibility
¢ Planning Department is responsible for utilization of up to date information
regarding applicable laws and rules for Persons withDisabilities.
© District Planning Officers at District level are responsible for giving effect to this
policy at districtlevel.
* Any employee who violates this policy shall be dealt in accordance with applicable
rules andlaws.
Communication of Policy
This policy will be available to all employees via the Planning Department website
i.e. hpplanning.nic.in
Maintenance of Record
Records shall be maintained as per the provisions of laws and the rules there under,
shail maintain in relation to the matter of employment, facility provided and other
necessary information in compliance with the provisions of laws.
This policy shall be displayed on the Planning Department website
hpplanning.nic.in or at conspicuous places.
Ql 8०४० :
(Ramesh Chand’Sharrha)
Deputy Secretary (Planning) to the
Government of Himachal Pradesh.
Scanned with CamScanner
