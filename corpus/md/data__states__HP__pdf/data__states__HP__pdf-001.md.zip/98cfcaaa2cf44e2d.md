---
doc_id: "98cfcaaa2cf44e2d"
source_url: "https://rggec.ac.in/wp-content/uploads/2026/07/OFFICE-ORDER-REGARDING-ANTI-RAGGING-SQUAD.pdf"
ministry: "Rajiv Gandhi Government Engineering College (RGGEC), Kangra, Himachal Prades"
title: "OFFICE ORDER REGARDING ANTI-RAGGING SQUAD"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "52f12a89e0743fee"
---

<!-- page 1 -->

Se OFFICE OF THE DIRECTOR CUM PRINCIPAL
a oO RAJIV GANDHI GOVT. ENGINEERING COLLEGE
Beme 7 ei KANGRA AT NAGROTA BAGWAN, VPO MASSAL,
x ay > wh TEHSIL NAGROTA BAGWAN, DISTT. KANGRA (HP)-76047
eS EES (hPUreoe ovine MAIL epee ofice@umal com, WEBLINK: wonssgpseacin =z (Approved by: AICTE, New Delhi; Affiliated to: HPTU, Hamirpur (H.P.)
कि शत. 0892-24988; 8-6]: regec.office@gmail.com; WEBLINK: www.rggec.ac.in
No. SS Dated: |2-9-909¢
OFFICE ORDER
In Supersession of previous office order No. 269 Dated 23-06-2025, In order to look into the
_ issues of menace of ragging and to comply with the order of Hon’ble Supreme Court Order Dated 8th
May 2009, an Anti-Ragging Squad at RGGEC, Nagrota Bagwan is reconstituted with immediate effect.
. The following are the members of the squad:
|]. Pr. Mobit Dhiman, Prof. ME [Convener | 948070377 ere
Dr. Mahesh Sehra, Asso. Prof.CE 948532792
5h. Harsh Kumar, AP-Physics |_Member | 70802829
r. Vishal Chaudhary, AP, CE | Member | 70868032
Dr. Pankaj Sharma, AP-Chemistry [Member | 9857265826
| 6 Mrs. Radhika, AP, EE | Member | 8728823698
Bh. Raman Sharma,, AP, ME il [Member _|948030643
[8 Ar. Harshodaya Bhardwaj, AP, BArch, | Member _| 8628936730
| 9 | ” Ashish Sharma, AP, ECE [Member | 94864507
नाप ज हु जान आय
ue
DA
Di rincipal
Rajiv Gandhi Govt. Engg. College
Kangra Nagrota Bagwan
a
No. Rggec/NGB/Trg. (Anti Ragging)/2026- Yasy-Y7S% Dated: 7-2-2026
Copy forwarded to: - है
, The Director, Technical Education, Vocational & Industrial Training, HP Sundernagar Distt.
Mandi for information please. :
2. Sh. Munish Bhardwaj, OIC website cum AP ECE with request to upload on college website.
3. Mr. Vivek Mankotia, AP, ECE & OIC AICTE, RGGEC for information please.
4. All above mentioned committee members for Information Please.
5. Student Notice Board.
HX
Me Director/Principal
Rajiv Gandhi Govt. Engg. College
= at a Bagwan
q <
ce Scanned with OKEN Scanner
