---
doc_id: "97bceff4bd20ed74"
source_url: "https://www.himfed.com/assets/tender/TENDERCA2026.pdf"
ministry: "Himachal Pradesh State Co-operative Marketing & Consumers Federation Ltd., Himachal Pradesh"
title: "E-tender for Calcium Nitrate Plain and Nitrate Boronated -2026-27"
date: ""
pages: 14
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "fc9954f3febe7caf"
---

<!-- page 1 -->

a
[HIMFED)
THE H. P. STATE COOPERATIVE MARKETING AND CONSUMERS FEDERATION
LIMITED, CIRCULAR ROAD, VICTORY TUNNEL SHIMLA -77003.
Email Address: fdohimfed@amail.com_ Address: fdohimfed@qmail.com PHONE NO. - 077-2657580, 2659039, 282022
E- TENDER NOTICE FOR PROCUREMENT OF CALCIUM NITRATE PLAIN AND CALCIUM NITRATE PLAIN AND
BORONATED ON CONSIGNMENT BASIS FOR THE YEAR 2029-47. BASIS FOR THE YEAR 2026-27.

Online tenders are hereby invited from all the eligible bidders holding a valid
licence/registration under the Fertilizer (Control) Order, 985 (FCO, 985) in the State
of Himachal Pradesh for the supply of approximately 000 MT of Calcium Nitrate Plain
and 500 MT of Calcium Nitrate Boronated conforming to the specifications prescribed
under FCO, 985, on consignment basis during the financial/operational period from
25..2026 to 3.0.2027, on F.O.R. basis at various retail outlets of HIMFED in
Himachal Pradesh. ,

The tender documents may be downloaded from the https://hptenders.gov.in.
The cost of the tender document, as specified below, shall be deposited either in the
form of a Bank Draft/NEFT in favour of the Managing Director, HIMFED, Shimla-3,
payable at any scheduled bank at Shimla, or directly into the HIMFED bank account
mentioned below through NEFT:

HIMFED Current Account No.: 0835924452
Bank: State Bank of India, Kalibari Branch, Shimla
IFSC Code: SBINO00078
Proof of payment of the tender document cost and Earnest Money Deposit (EMD), as
applicable, shall be uploaded along with the Technical Bid and shall also be submitted
in a sealed envelope as prescribed in the tender documents.
In case the tender document cost and EMD is deposited through Demand Draft, the
original instrument must reach the office of the Managing Director, HIMFED, Shimla-
49..2026 up to 5:00 PM. Failure to submit the original instrument within the stipulated
time shall render the tender liable to rejection and the tender shall not be considered.
Payment through cheque shall not be accepted towards the tender document cost
and/or EMD.
_ Instructions for E-Tendering
4d: The tenderer should register himself on Website
https://hptenders.gov.in and obtain user ID, Password, before
bidding. In case of any problem contact Marketing Assistant (Fert.)
9872-64762 and for any technical assistance you may contact
Programmer (IT), Himfed, on phone No. 9480-79977, 987054407.
2. Entire tender process will be carried out online through above
mentioned website: Tenderer are advised to procure E-Token/Digital
Signing Certificate from suitable vendors or from any authorized
agency. lY
८
(्ह्र Scanned with OKEN Scanner

<!-- page 2 -->

जी
f
५ / 3. Before submission of online bids, bidders must ensure that scanned
f copies of all necessary documents clearly readable in single PDF have
f been uploaded with the bid.

4. Tenderer are advised to check/see website https://hptenders.gov.in
and __ https://himfed.com regularly to check for any
amendment/corrigendum in the tender document. All subsequent
notifications/amendments/notices shall be published on the aforesaid
website only.

Tenders received on or before the deadline will be opened on the date and at the
time specified in the Tender Notice/Tender Document. Bidders/tenderers or their
authorized representatives may attend the tender-opening process. If the scheduled
tender-opening date is subsequently declared a public holiday, the tenders will be
opened on the next working day.

The e-tender documents shall be uploaded in two Parts: -

a. Technical Bid: It shall contain scanned copies of all required documents,
certificates etc. as specified in tender document duly filled in and digitally signed.

b. Financial Bid: It shall contain financial bid/BOQ uploaded in xls format which
will be available for bidders on website https://hptenders.gov.in. The financial
bid/BOQ will not be accepted in physical form.

c. The bidder will qualify the technical bid who addresses all requisite parameters
mentioned in the technical bid (Annexure A) and will be eligible thereafter only for
opening of financial bid.

All the documents must be scanned and uploaded in single pdf format.
DOCUMENTS DOWNLOAD START AND END | 30/70/2026 to 48/4/2026 है
गण
LAST DATE FOR UPLOADING OF TENDER | 9/47/2026 up to 5:00 PM हे ~ I
| DOCUMENTS AND BID SUBMISSION |
DATE AND TIME OF OPENING OF TECHNICAL 20/7/2026 at :00 AM |
HIMFED SHIMLA-3. :
COST OF TENDER DOCUMENT SET Bank Draft/NEFT Rs. 5000.00
EARNEST MONEY DEPOSIT हु Bank Draft RTGS Rs. 400000.00 |
Oh |
| Dr. gear Vermd
Ma naging Director
Him We
2
SG Scanned with OKEN Scanner

<!-- page 3 -->

TERMS & CONDITIONS FOR SUPPLY OF CALC)

4.

a) The Tenderers shall quote separate rates for the supply of Calcium Nitrate Plain
and Calcium Nitrate Boronated fertilizer on consignment basis.

b) The rates shall be quoted on a per metric tonne (PMT) basis inclusive of GST,
F.O.R. HIMFED fertilizer stores.

c) The supplier shall supply the fertilizer on consignment basis, as per the
specifications and quality standards prescribed under the Fertilizer (Control)
Order, 985. The supplies shall be made strictly in accordance with the supply
orders/purchase orders issued by HIMFED Head Office Shimla, from time to time
during the period from 25/4/2026 to 3/0/2027.

d) If the Government of India revise or change the applicable fertilizer rates for any
reason, and such change results in a financial loss to HIMFED, the supplier will
be responsible for bearing and compensating HIMFED for that loss.

e) The material supplied by the supplier shall be fresh stock and shall conform to
the prescribed quality and specifications. The quantity of material mentioned in
the Tender Notice is indicative and may be increased or decreased as per the
actual requirements of HIMFED. Conditional tenders shall not be accepted under
any circumstances. The specimen signatures of the person authorized to sign the
tender documents, agreement and other related documents shall be duly
attested by the Head of the Company and must be accompanied by a valid
authorization letter or resolution authorizing such person to sign the documents
on behalf of the company. The Managing Director, HIMFED reserves the right to
accept or reject any or all tenders without assigning any reason whatsoever

f) The supplier will have to organize farmer's awareness camps throughout the
state on regular intervals in association with the field officers of the HIMFED.

g) If any stock remains unsold after the expiry of the tender period and the rates
finalized in the subsequent/fresh tender are lower than the existing rates, the
supplier shall either reduce the rates of the remaining unsold stock to the rates
finalized in the fresh tender or lift the balance unsold stock . Such lifting of the
balance stock shall be completed within one month, entirely at the supplier's own
cost and expense.

h) The Supplier shall not independently supply CALCIUM NITRATE PLAIN AND
BORONATED fertilizer to any private or Government dealer within the State of
Himachal Pradesh during the tender period. All such supplies intended for private
or Government dealers within the State shall be routed exclusively through
HIMFED. In the event of any violation of this condition, the Management of
HIMFED shall reserve the right to forfeit the Earnest Money Deposit (EMD) and हु
Performance Security Deposit of the Supplier, in accordance with the terms and
conditions of the tender. LL :

all
(@: Scanned with OKEN Scanner

<!-- page 4 -->

J
हैँ 2. PRICE
ce The supplier shall supply the fertilize ili

Himachal Pradesh at the rates नाता in the tender ese Rtoh THE गा
subsequently negotiated and finally approved by HIMFED, strictly on
consignment basis and in accordance with the settled terms and conditions. The
tates quoted by the supplier shall be inclusive of all applicable taxes, duties,
levies and other charges as applicable from time to time. However, the base
price and GST shall be clearly mentioned separately in the price
quotation/invoice.

3. EARNEST MONEY DEPOSIT.
The tender document shall be accompanied with Earnest Money Deposit (EMD)
of 24,00,000/- (Rupees Eleven Lakh only), as specified in the Tender Notice, in
the form of an Account Payee Bank Draft or through RTGS in favour of the
Managing Director, HIMFED, payable at Shimla. The tender document
submitted without the prescribed EMD shall be liable to rejection. The EMD
deposited by the unsuccessful tenderer shall be refunded after completion of the
tender process. The EMD of the successful tenderer shall be refunded only after
the entire stock of fertilizer supplied by the Supplier has been sold from HIMFED
stores, subject to compliance with all the terrns and conditions of the tender.

4. PERFORMANCE SECURITY.
The successful tenderer shall deposit Performance Security equivalent to 3% of
the total contract value in the form of an Account Payee Demand Draft or
through RTGS in favour of the Managing Director, HIMFED, payable at Shimla,
before signing the agreement. The Performance Security shall serve as security
for due and faithful performance of the contractual obligations and may be
forfeited in case the successful tenderer fails to make the required supplies
within the stipulated tender period or withdraws/backtracks from its
commitments under the agreement for any reason. The performance security of
the successful tenderer shall be refunded only after the entire stock of fertilizer
supplied by the Supplier has been sold from HIMFED stores, subject to
compliance with all the terms and conditions of the tender.

5. RISK AND COST CLAUSE FOR FAILURE TO SUPPLY.

In the event that supplier fails to supply fertilizers in accordance with the
schedule specified in the supply order, fails to deliver the material within the
stipulated time, or supplies material that does not conform to the specifications
and standards prescribed under the Fertilizer (Control) Order (FCO), including
the applicable Packaging and Labelling requirements and the Weights and
Measures (Packaged Commodities) Rules, HIMFED shall be entitled to take
appropriate action against the supplier. i may include blacklisting ie

ne pais ee
SG Scanned with OKEN Scanner

<!-- page 5 -->

/ Poet Sac s nen fg Sees ia EMD a
' ation of legal proceedings as applicable. No
हित गत SEARS Consignment received that fails to conform to the
ray be incrensed Gr गाल standards ‘rules, The quantity of fertilizer required
है ased at the discretion of the Managing Director,
HIMFED, according to the requirements of HIMFED, The Managing Director,
HIMFED Shall also reserve the right to accept or reject any or all tenders without
assigning any reason whatsoever.
6 SUPPLY ORDER / DESPATCH INSTRUCTIONS/ TURNOVERS/
EXPERIENCE.

(a). The HIMFED Head Office Shimla shall place supply orders/dispatch instructions
for fertilizers according to its requirements, clearly specifying the quantities to be
supplied to the respective HIMFED godownsf/fertilizer stores. Upon receipt of the
dispatch programme or schedule, the supplier shall dispatch the fertilizer to the
designated HIMFED fertilizer stores strictly in accordance with the prescribed
schedule and shall ensure that the entire indented quantity is supplied within the
time limit stipulated in the respective supply order. In the event of failure on the
part of the supplier to supply the required quantity within the stipulated period, the
Management of HIMFED shall reserve the right to forfeit the Earnest Money
Deposit (EMD) and Performance Security Deposit of the supplier, in accordance
with the terms and conditions of the tender.

(b). The supplier should have a minimum annual turnover of %5 crore (Rupees Five
Crore only) in each of the last three financial years preceding the tender, duly
certified by a Chartered Accountant (CA).

7. DELIVERY ~
The supplier shall ensure the timely delivery of the entire ordered quantity of
fertilizer to the designated HIMFED fertilizers stores located in different districts
of Himachal Pradesh. The supplier shall be solely responsible for ensuring that
the quantity dispatched reaches the respective fertilizers stores in full and in
good condition. Any shortage, loss, or discrepancy in the quantity of fertilizer
found during transit shall be the sole responsibility of the supplier, and the
supplier shall be liable to make such shortage at its own cost in accordance with
the terms and conditions of the tender.

8. PACKING
a) The fertilizer shall be supplied in new, sound, strong and machine-stitched
HDPE bags of 25 kg capacity, with the Maximum Retail Price (MRP) clearly
printed on each bag. The bags used for packing shall be in good condition and
free from any defect. Old, torn, cut, damaged, mutilated or otherwise defective
bags shall not be accepted by HIMFED. |

5
GC scanned with OKEN Scanner

<!-- page 6 -->

/ (b) The supplier shall e
i/ and shall be inclusive of al apallnettRe is Clearly Printed on each fertilizer bag
rules and regulations, 3x68, in accordance with the applicable
9. INSPECTION AND SAMPLING
Pre-dispatch Samples shall be drawn from th ier’
and subsequent Samples shall be drawn fro th Supplier's buffer godown,
designated HIMFED fertilizers stores. The sariplgs shal te collected b हि
i ili an
00 886 Ze" Inspector, duly authorized under the Fertilizer (000०)
the State Government “oat for chemical analysis to any laboratory notified by
shall dispatch the f rf entral Government under the said Order. The supplier
standard ertilizer from its buffer godown only after receipt of the
ard laboratory test report in respect of the pre-dispatch samples. The
laboratory test report of the samples so drawn and analyzed shall be final and
binding on both Parties. In the event that any sample is found to be substandard
Or not conforming to the specifications prescribed under the Fertilizer (Control)
Order, 985, the supplier shall be solely responsible for all legal, civil and other
Consequences arising from the’supply of such non-conforming material.
40. QUALITY SPECIFICATIONS
In the event that any consignment is found not to conform to the
contractual specifications or the standards prescribed under the Fertilizer
(Control) Order, 985, HIMFED shall have the tight to reject such consignment.
The supplier shall remain responsible for maintaining the quality of the fertilizer a
stocks in accordance with the prescribed specifications, including the quality and
condition of the material contained in intact bags, until their final disposal by
HIMFED. All stocks supplied shall be fresh, of good quality and packed in sound
and standard packaging. HIMFED shall have the right to draw samples from the
supplied stocks, and the cost of such sampling shall be borne by the supplier.
The supplier shall be solely responsible for the quality of the product and for any
consequences arising from the failure of samples to meet the prescribed
standards. In such an event, all criminal, civil and financial liabilities arising from
the non-conforming or substandard material shall be borne entirely by the
supplier, and appropriate action shall be taken in accordance with Clauses 5 the
tender terms. Any claim, compensation or liability raised by farmers or
consumers on account of such substandard or non-conforming fertilizer shall also
be the sole responsibility of the supplier and shall be paid by the supplier.
44. BILLING AND PAYMENT
a) The payment against the supplies made under the contract shall be processed
and released by the HIMFED Head Office, Shimla, in accordance with the
applicable terms and conditions of the tender ‘ supply order. ५
CG Scanned with OKEN Scanner

<!-- page 7 -->

Tl ;
/ ” पीर Head! ies, Shimla; ores Spare he eae eee et
j shall be duly supported by ail is Fale don न re ee
ferme "andl Gondilene ot quisite documents and shall comply with the
of the tender and the relevant Supply Orders. Payment
shall be released by the HIMFED Head Office, Shimla, only against the i
of fertilizer actually sold. ‘ : quantity

c) The bills pee by the supplier shall clearly and accurately indicate the name
of the fertilizer, quantity supplied/received in both weight and number of bags.
batch number, supply order number, and date of receipt. The supplier shall
ensure that all such details are properly mentioned in the bills and correspond
with the actual material supplied and the relevant supply order for verification and
processing of payment.

0) The supplier shall submit a separate invoice for each godown/destination along
with the respective supplies. Each invoice shall be raised strictly as per the GST
number of the concerned HIMFED Area Office and shall contain all applicable
GST and other statutory details required under the prevailing rules and
regulations.

e) No bills shall be accepted and processed for payment unless they contain all the
details specified above. Bills submitted without the prescribed information shall
be liable to rejection or returned to the supplier for necessary rectification.

f) The supplier shall submit the bills to Himfed Head Office Shimla and to the
concerned HIMFED Area Office within one week from the date of supply.

9) The supplies shall be made strictly on an F.O.R. basis and the supplier shall be
responsible for arranging the transportation and delivery of the fertilizer to the
designated HIMFED destinations in accordance with the terms and conditions of
the tender and the respective supply orders.

h) Payment to the supplier shall be made through RTGS against duly verified and
accepted invoices, subject to compliance with all applicable terms and conditions
of the tender and supply order. Any invoice that does not conform to the
prescribed requirements or lacks the required details and supporting documents
shall be returned to the supplier forthwith and shall not be processed for payment
until the deficiencies are duly rectified.

i) The payment of bills shall be made by HIMFED Head Office only, after deduction
of all applicable. taxes, duties, levies and statutory deductions as per the
prevailing rules and regulations. HIMFED shall not be responsible for any delay

, in processing or payment of bills that are submitted late, incomplete, or contain
an incorrect GST number. HIMFED shall also not be held responsible for any
delay in payment arising due to unforeseen, unavoidable or circumstances
beyond its control. No interest or other compensation shall be payable by
HIMFED on account of any delay in release of payment.

j) The HIMFED shall have right to recover any amount due from the supplier under
any other agreement from the amount payable under this agreement. This right
shall be without prejudice to any other action’ proceedings which HIMFED may
take to recover the outstanding dues from Ye

7
GC scanned with OKEN Scanner

<!-- page 8 -->

x) The supplier shall also submi i ,
/ the concerned. HIMEED rae we ells for the supplied quantity through email to
copies, » In addition to submitting the requisite hard

)) The supplier shall en ७

statutory taxes with tHe abnee timely deposit of ST and all other applicable

cerned Government authorities and shall duly fi

GST returns and statutory statements within th ee uly file all

@ prescribed time limits.

43. CENTRAL SUBSIDY. :
eka veoh Une clearly indicating the prices inclusive of any
wherever required, i shall provide the necessary purchase certificate,
Gover , ) accordance with the subsidy scheme notified by the

nment of India. Such purchase certificates shall be issued in the name of

the concerned Manufacturer/PSU/Marketer, as applicable. However, HIMFED
shall not be responsible or liable for any subsidy claim, reimbursement, or
settlement thereof made by the supplier, and the supplier shall be solely
responsible for pursuing and obtaining any subsidy due under the applicable
Government scheme.

44. GENERAL

a) Any subsequent change made in the Fertilizer Distribution, Control, Subsidy
Policy by the Government of India and State Govt. of Himachal Pradesh would
be applicable to parties. है

b) HIMFED reserves the right to cancel and reject the supply order, either wholly or
partially, if the material supplied at the designated destination(s) is found to be
substandard, or if there is any inordinate delay in supply or any other major
default or fault on the part of the supplier. In such circumstances, HIMFED shall
also have the right to procure the required material from other supplier(s) at the
risk, cost and consequences of the defaulting supplier/firm, without being
required to issue any separate notice to the supplier in this regard. HIMFED shall
further have the right to issue supply orders in phases, depending upon its
requirements and operational requirements during the tender period.

c) The supplier shall strictly comply with all applicable rules, regulations,
procedures, orders and statutory requirements governing the manufacture,
supply, movement, packaging, labelling, sale and distribution of fertilizers,
including the provisions of the Essential Commodities Act, 7955, the Fertilizer
(Control) Order, 985, the Fertilizer (Movement Control) Order, 973, the
Standards of Weights and Measures (Packaged Commodities) Rules, 977, and
any other applicable law, notification, Government order or regulation in force
from time to time. The supplier shall be solely responsible for ensuring that all
supplies made under the tender remain compliant with such statutory and
regulatory requirements throughout the contractual period.

d) The Managing Director, HIMFED reserves the right to blacklist the supplier from
participating in future HIMFED tenders in the “ly failure to supply the

8
(@: Scanned with OKEN Scanner

<!-- page 9 -->

indented quantity within the st
standard, defecti © stipulated period or j
/ ective, or Non-conforming rae erin case of Supply of sub-
e) The supplier shall, whereve
indicating the name ver applicable, submit a न
imported, ame of the country from which the शिरकत tae
f) The material shall be sold/distributed onl ial has been
हे 0| ;
ae report Us Standard analysis Wee orate een a
supplier's godown conform t aetna
standards under the applicable rul ‘0 the prescribed specifications and
the material shall be permitted ru es and regulations. No sale or distribution of
been received. until the requisite standard analysis report has
45. INDEMNIFICATION
A .
AU a oral be bound to supply fertilizer stocks strictly in
(Control) Order, 4 cae Ire and standards prescribed under the Fertilizer
eae b : he. supplier shall indemnify and keep HIMFED
" nified against any claim, loss, damage, cost, expense or liability suffered or
incurred by HIMFED arising out of any deficiency in the quantity or quality of the
fertilizer, any claim made by any person, farmer or consumer using the fertilizer,
or any failure of samples drawn by the Authorized Fertilizer Inspector. The
supplier shall be solely responsible for all consequences arising from such
claims, losses or failure of samples. The Managing Director, HIMFED shall also
reserve the right to forfeit the EMD and Performance Security of the successful
tenderer if the supplier fails to make the requisite supplies within the stipulated
tender period as per HIMFED’s requirements or withdraws, backs out or fails to
honour its commitments under the agreement for any reason.

46. | The Managing Director, HIMFED reserves the right to cancel the tender awarded
to the successful tenderer, either wholly or partially, at any stage, without
assigning any reason whatsoever. Such cancellation shall be at the discretion of
the Managing Director, HIMFED, and the supplier shall have no right to claim
compensation or damages on account of such cancellation.

47. ARBITRATION
In the event of any dispute arising out of or in connection with the contract or
supply orders, including any dispute relating to the interpretation or
implementation of the terms and conditions, delay in delivery, or any other matter
arising during the course of the contract, the dispute shall be referred to the
Registrar, Cooperative Societies, Himachal Pradesh, Shimla-9, for adjudication in
accordance with the provisions of the Himachal Pradesh Cooperative Societies
Act, 7968, and the rules made thereunder. The decision of the Registrar,
Cooperative Societies, Himachal Pradesh shall LD final and binding on both
parties. LD

. , 9
CG Scanned with OKEN Scanner

<!-- page 10 -->

v
THE H- Pp. STATE COOPERATIVE MARKETING AND CONSUMERS FEDERATION
LIMITED, CIRCULAR ROAD, VICTORY TUNNEL SHIMLA -74003.
TECHNICAL BID (PLEASE UPLOAD THE SCANNED COPIES OF DOCUMENTS IN
SAME SEQUENCE )
रा Annexure-A
i Name of the tenderer _,
2 Permanent Address with copy of address proof
|
‘Address of the Head Office of the tenderer =
Phone No. / Fax / e-mail ID हे है ह |
|
5 Amount Deposited : Amount in Rupees Particular Date Name of Bank |
I) Cost of tender 5,000/- |
document and Processing
Fee (Non Refundable) |
NEFT/DD
(Scanned copies to be
uploaded)
2) Earnest Money :
Deposit (Through (EI
DepeENGS! Demand | 200.000" (Eleven ra
Draft )
(Scanned copies to be
uploaded)
: ee
6 | GSTNo. |
|
7 -TScanned Copy of the Licence under the Fertilizer |
(Control) Order, | 985 (FCO, 985), valid in the State
of Himachal Pradesh.
Scanned Copy of proof of stock position/Bill of Ladin;
. oo गे थी
i0 | Scanned copy of Registration No/date of License and
valid up to: |
a je eee
0
CG Scanned with OKEN Scanner
