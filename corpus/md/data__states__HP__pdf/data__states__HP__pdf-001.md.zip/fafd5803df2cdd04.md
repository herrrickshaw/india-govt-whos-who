---
doc_id: "fafd5803df2cdd04"
source_url: "https://cdn.s3waas.gov.in/s3766ebcd59621e305170616ba3d3dac32/uploads/2026/08/17876595955246.pdf"
ministry: "Kinnaur"
title: "Order regarding Declaration of No Parking Zone at Pooh (120 KB)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "21a33a8a95b6c1b5"
---

<!-- page 1 -->

DC-KNR-G006/3/2025-HRC-DC OFFICE KINNAUR-Part(1)

I/953355/2026

OFFICE OF THE DISTRICT MAGISTRATE,
KINNAUR DISTRICT RECKONG-PEO, HIMACHAL PRADESH
No. KNR-IX-30 (MLC)/2026-

the August, 2026

ORDER
Subject:

Declaration of Specified Stretches of Link Road, Pooh, as “No
Parking Zones”.

Whereas, a proposal has been received from the Additional District
Magistrate, Pooh, based on the specific recommendations and field reports submitted by the
Station House Officer (SHO), Police Station Pooh regarding declaration of “No Parking
Zone” on link road Pooh;
And Whereas, it has been brought to notice that frequent traffic
congestion occurs regularly on the Link Road stretching from the Pooh Bus Stand to the
Community Health Centre (CHC) Pooh, which hinders public convenience and severely
obstructs the smooth movement of emergency vehicles on the route from Pooh bus stand to
CHC Pooh;
Now Therefore, I, Dr. Amit Kumar Sharma, IAS, District Magistrate,
Kinnaur at Reckong Peo, in exercise of the powers vested in me under Sections 115, 116, and
117 of the Motor Vehicles Act, 1988, and in the interest of public safety and general
convenience, do hereby order and declare the following stretches on the Link Road in Pooh
village as a "NO PARKING ZONE" with immediate effect:
1. Both sides (Hill-side & Valley-side) of the road within the Pooh Main Bazar area.
2. Both sides (Hill-side & Valley-side) of the intersecting roads at the Mane Fhane
point.
3. Both sides (Hill-side & Valley-side) of the road in front of Rinku Lala's shop.
4. Both sides (Hill-side & Valley-side) of the road at Nanak Chowk.
5. Both sides (Hill-side & Valley-side) of the road stretching from Nanak Chowk to
CHC Pooh.
6. Both sides (Hill-side & Valley-side) of the road stretching from Pooh Bus Stand to
Pooh Main Bazar.
Furthermore, the following directions are also issued for strict compliance:
1. The Additional District Magistrate, Pooh, shall function as the Nodal Officer for
monitoring and coordinating implementation of this Order in consultation with the
H.P. Public Works Department and the Police Department.
2. The Superintendent of Police, Kinnaur at Reckong Peo, shall ensure strict
enforcement of this Order by deploying adequate police/traffic personnel at the
notified locations and by taking action against violators in accordance with law.

<!-- page 2 -->

DC-KNR-G006/3/2025-HRC-DC OFFICE KINNAUR-Part(1)

I/953355/2026

3. The Executive Engineer, HPPWD, Kalpa shall immediately install standard
regulatory "NO PARKING" signboards and paint yellow edge lines at all the
locations specified in this Order.
Any vehicle found parked in violation of this Order shall be liable for prosecution,
imposition of penalty, towing, or any other action as permissible under the provisions of
the Motor Vehicles Act, 1988, and the rules framed thereunder.
This Order shall come into force with immediate effect and shall remain in force until
further orders.
Given under my hand and seal of office on this _____ day of August, 2026.

(Dr. Amit Kumar Sharma, IAS
District Magistrate,
Kinnaur District at R-Peo (H.P.)
Dated:, 2026.

Endst. No. KNR-IX-30 (MLC)/2026Copy forwarded for information and necessary action.
1. The Superintendent of Police, District Kinnaur at Reckong Peo, for immediate
deployment of police personnel at notified locations.
2. The ADM Pooh, for strict compliance, monitoring, and execution oversight at the
designated No Parking Zones.
3. The Executive Engineer, Kalpa for Install regulatory "No Parking" signboards
and paint yellow edge lines at designated points.
4. The SHO Pooh, for execute ground enforcement and keep the CHC Pooh route
completely clear 24/7.
5. The DPRO, Kinnaur at Reckong Peo for wide publicity of this Order through
print, electronic and social media.
6. Guard file.
Digitally signed
District Magistrate,
Kinnaur District at R-Peo(H.P.)
