---
doc_id: "3c73f1bb6a8ade9e"
source_url: "https://khadi.hp.gov.in/wp-content/uploads/2026/08/Tender-DoucumentSale-Shop-Kangra-1.pdf"
ministry: "Himachal Pradesh Khadi & Village Industries Board, Himachal Pradesh"
title: "Download"
date: ""
pages: 25
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9fa887dac75fe9d3"
---

<!-- page 1 -->

H.P. Khadi & Village Industries Board
Cleave Land Shimla-171004
Ph. No. 0177-2652407, 2653229, 2812280, Telefax: 01772802724
e-mail: khadi-hp@nic.in

No. Him. K&VIB/3/Sale Shops/ Kangra/ 2025-26/
TENDER NOTICE
The Chief Executive Officer, H.P. Khadi & Village Industries Board (HPKVIB),
Cleave Land, Shimla-171004 invites Tenders/bids under Two Bid System i.e. Technical Bid and
Financial Bid from registered firms/Proprietors/Individual/SHGs/etc for renting out its Sale
Shop and vacant shed as per details given here under:Sr.
No
.

Name of Sale
Shop and cost of
Tender Fee

EMD

1.

Sale Shop &
shed at Kangra,
Distt. kangra.
(approx.
Area
1237 sq. ft)

Rs.
100000/-

Cost of tender =
Rs. 5000/-

Period of
Rent
agreement/
contract/
10 Years

Period of sale
of
tender
document

Last date for
submission
of Tender

Date of opening of tender

24/08/2026 to
11/09/2026
upto 5.00 PM

15/09/2026
upto 12.00
PM

Technical
Bid
15/09/2026 at 2.00 PM
Financial Bid: will be
subject to evaluation &
outcome of TB and will
be opened accordingly on
the same day or later date
for which intimation will
be given on the same day.

The tender documents for Sale Shop and the vacant shed at Kangra can be
purchased from the Office of CEO H.P. Khadi & V.I. Board Shimla-4 on a payment of Rs.
5000/- (Non-refundable) respectively through cash / DD drawn in favour of Chief Executive
Officer, HPKVIB Shimla-4 or online/NEFT/RTGS to A/c No “10835935282”, SBIN0000718
(SBI Kali Bari Shimla-3). The tender documents can also be download from website
https://khadi.hp.gov.in only after depositing the requisite tender fee online.
Dr. Jitender Kumar(HPAS)
Chief Executive Officer

<!-- page 2 -->

H.P. Khadi & Village Industries Board
Cleave Land Shimla-171004
Ph. No. 0177-2652407, 2653229, 2812280,
e-mail: khadi-hp@nic.in

Tender No: Him. K&VIB/SS Kangra/2025-26/

Date:_______

Tender for renting out Sale Shop & Shed
The H.P. Khadi and Village Industries Board intends to invite sealed tenders/bids
from interested parties i.e. Firms/Proprietors/Individual/SHGs/ for renting out
/leasing out of its Sale Shop and shed measuring 1237 sq. ft situated at The Near
Bus Stand, Kangra Distt. Kangra for running the activities under the ambit of
KVI sector and/ or marketing of KVI products etc. Tender form & further detail
can be obtained from the office of undersigned or can be download from website
https://khadi.hp.gov.in. The cost of tender form is Rs. 5000/- which can be paid
in cash or online/NEFT/RTGS to A/c No “10835935282”, SBIN0000718 (SBI Kali Bari
Shimla-3). In case of online payment of tender cost, the participating bidder shall inform
about the same through email id khadi-hp@nic.in.

The last date of submission of tender is 15-09-2026 upto 12.00 PM by post or by
hand.
Chief Executive Officer.

<!-- page 3 -->

H.P. Khadi & Village Industries Board
Cleave Land Shimla-171004
Ph. No. 0177-2652407, 2653229, 2812280,
e-mail: khadi-hp@nic.in

CHECK LIST OF THE DOCUMENT TO BE ATTACHED WITH
TECHNICAL BID OF THE TENDER FORM
Note :1): Please check whether the copies of the following document have been attached
with the tender or not
Note :2) All Technical Bid document( along with Annexure A, B, C,D & E and Form –I &
II ) must be submitted separately in sealed Envelope– I, Technical bid.
S.N
1

2

Particulars
Introduction, Eligibility Condition, Bidder*s profile
/Eligibility Criteria, Terms & Conditions, Special Terms &
Conditions ,(Annexure –“A”,”B”,”C”,”D” & “E”) for
running sale shop Kangra duly filled in signed & stamped
Copy of Aadhar Card

3

Copy of Pan Card

4

Undertaking as per Annexure-I (affidavit on Rs 100/-)

5

Earnest Money of Rs 100000 /- deposit as mentioned in the
tender form in the form of Demand Draft in favor of CEO
H.P Khadi & village Industries Board Shimla -4
Undertakings as per Annexure –“ Form- II”) (affidavit on
Rs 100/-)
Self Attested copy of GST(TIN ) issued by GST authorities
Receipt of Tender Form ( Rs 5000/- ) attached
Bank details:
Turnover certificate
Registration No. of the proprietorship/firm etc
EMD (DD attached)

6
7
8
9.
10.
11.
12

Yes

No

Yes

No

Checklist of enclosed document in “ Envelope II” Financial Bid :
S.N

Particulars

1

As per annexure “III”

<!-- page 4 -->

H.P. Khadi & Village Industries Board
Cleave Land Shimla-171004
Ph. No. 0177-2652407, 2653229, 2812280,
e-mail: khadi-hp@nic.in
Tender No: Him. K&VIB/ S.S Kangra/2025-26/Inviting offer from Bidders (Individual/Firms/Society/SHG etc.) for running Sale Shop on
rental basis at Near Bus Stand, Kangra District Kangra, H.P.
Date of Issue of Tender:

24-08-2026

Last Date and time for sale of tender:

11-09-2026 upto 5.00 PM

Period of collection of tender:

24-08-2026 onwards

Last Date & Time of submission of Tender:

15-09-2026 upto 12.00 PM (by post/by hand)

Date & Time of Opening of Technical Bid:

15-09-2026 at 2.00 PM

Date & Time of Opening of Financial/Price Bid:

It will depend on the evaluation of technical bids
and date of opening of financial bids will be
communicated accordingly
Chief Executive Officer,
H.P. Khadi & Village Industry Board Cleave
Land Shimla-4
5000/- not refundable

Address for submission of Tender:

Cost of Tender:
Earnest Money Deposit(EMD)

Rs. 100000/- (Rupees One lakh Only) in the shape
of Demand Draft in favor of CEO HP Khadi
Village Industries Board Shimla-4

If the date of opening of tender is declared a Holiday, the tender shall be opened on the next working
date the same time as fixed for the original date for this purpose.

<!-- page 5 -->

Annexure-“A”
H.P. Khadi & Village Industries Board
Cleave Land Shimla-171004
Ph. No. 0177-2652407, 2653229, 2812280,
e-mail: khadi-hp@nic.in
Tender No: Him. K&VIB/ SS Kangra/2025-26/-

I.

Introduction:

The H.P. Khadi and Village Industries Board invites properly sealed bids/
tenders in Two- Bid system (Technical & Financial) from eligible and willing
registered Agencies / firms/ Individuals/SHGs etc for renting out of its Sale Shop
and vacant shed measuring approx. 1237 sq. ft. situated at Near Bus Stand, Kangra
Distt. Kangra for running only activities under the ambit of KVI sector (
Manufacturing, Services and /or marketing/sale of KVI products etc).
II Tenders for renting out Shop at Near Bus Stand, Kangra, Distt. Kangra
1.
Scope of Services:
i)
The H.P. Khadi and Village Industries Board is interested in inviting bids for
leasing out/renting out of its Sale Shop and shed located at very busy and
commercially located at Near Bus Stand, Kangra Distt. Kangra for running only
activities under the ambit of Khadi and Village Industries and/ or marketing of
KVI products etc.
ii)
The interested registered agencies/firms/proprietors/SHGs etc. may
personally visit the campus/premises/site at Near Bus Stand, Kangra, Distt Kangra
to have the first-hand information about the shop located in the campus/premises
and submit their bids. However, HPKVIB does not take any responsibly for the
minimum business from shop. Bidders are advised to visit the site/premises before
bidding. Interested parties can inspect the premises on any working day from start
date of the bid till the end date of the bid. They may contact I/c Sale Shop, I/c
ADO Office HPKVIB, Kangra, Distt. Kangra (Contact No. 88940-40402) during
the office hours (10.00 to 17.00 hrs) on any working day for ascertaining the
potential of business/job requirements and any other additional information/
clarification required by them. The cost of any such visit shell be entirely at the
bidder*s own expenses.
iii) All Interested Bidders are required to submit their bids in two bids system
for opening/running shop at Near Bus Stand, Kangra Distt. Kangra. Technical

<!-- page 6 -->

Specification/Eligibility Criteria and General Terms & Conditions and other details
are available in Annexure “A” to “ E”.
III Cost of tender: The bidders/ Tenders will have to make payment of Rs 5000/- ( Rupees
five thousand only ) in respect of tender form fee non refundable to be deposited online in A/c
No “10835935282”, SBIN0000718 (SBI Kali Bari Shimla-3) or cash and copy of the receipt
/counterfoil therefore be submitted /attached with the tender document .
IV Tender document & Opening of tender: The tender document can be

obtained from the Office of Chief Executive Officer, H.P. Khadi and Village
Industries Board, Shimla or by sending a request through email at khadi-hp@nic.in
The last date for submission of complete tenders is 15-09-2026 up to 12.00 PM at
Head Office, Shimla. The tender/bids will be opened on 15-09-2026 at 2.00
PM in the presence of those tenderers who may desire to present at that time. The
Technical Bid will be opened first and financial bids of only those firms, which
fulfill the technical eligibility/criteria will be opened. The date and time for
opening of Financial Bids will be intimated to the bidders in due course.
V Instructions to bidders for preparation and Submission of Bids:
(i)
Bidders are requested to go through the tender advertisement/notice and
tender document containing terms and conditions etc carefully to understand the
documents required to be submitted for evaluation. Please note the numbers of
covers in which the bid documents have to be submitted, the number of documents
including the names and contact of each of document that need to be submitted.
Any deviations from these may lead to rejection of bid for evaluations.
(ii) Bid received through e-mail will not be considered for evaluation.
(iii) Bidders need to submit ^^Earnest Money Deposit** in form of Demand
Draft drawn in f/o “Chief Executive Officer, H.P. Khadi and Village Industries
Board, Shimla** for taking part in the bidding process.
(iv) The bidder has to attach the duly signed and sealed copy of this tender
document and attach the same along with technical documents.
(v)
Bidders are requested to note that they should necessarily submit financial
Bids in the format provided (Annexure-III) only and no other format is acceptable.
(vi) Any queries relating to tender document and terms & conditions contained
therein should be addressed in written format to the Tender inviting Authority or
the concerned person well in time prior to submitting bid.

<!-- page 7 -->

VI: Submission of Bids:
Tenders shell be submitted in Two Bid System. The interested registered agencies/
individuals/ properties have to submit the Technical Bids and Financial Bids in the
prescribed Performa. All the documents along with sighed copy of tender
document are to be kept in duly sealed one envelope superscribed/ written as
^^Technical Bids** Second envelop duly scaled shell have only financial bid super
scribed/ written as ^^Financial Bids** Both the envelope shell be super-scribed and
kept into a duly sealed third envelope. Third envelop must be addressed to the
^^Chief Executive Officer, H.P. Khadi and Village Industries Board, Cleave land,
Shimla-171004** and clearly written as below: “Tender Invited for Running
Sale Shop Kangra, Distt. Kangra”
VII: Earnest Money Deposit (EMD): The bidders need to submit EMD along
with technical bid, for an amount of Rs. 100000/- (Rupees One lakh only) in the
form of Demand Draft drawn in the f/o Chief executive Officer, H.P. Khadi and
Village Industries Board, payable at ^^Shimla** The EMD amount of the
unsuccessful bidders will be returned within 30 days of award of Offer Letter/LOI/
signing of agreement to/with the successful bidders. The EMD of successful
bidders will be returned on submission Security deposit or converting EMD into
security amount.
VIII: Offer letter/Letter of Intent (LoI) to the selected applicants/Bidder: To
be communicated to Successful Bidders. The successful bidders shall acknowledge
the same and will revert with the letter of acceptance of the contract with 7 days of
issuance of LOI.
IX: Commencement of Operation:
i) The successful bidder (license) shall start service within 30 days from the
date of lease order/Offer letter/LOI.
ii) The successful bidder will be allowed to the business upon the satisfaction of
other formalities like payment of Security Deposit within 15 days from the
date of Offer letter/LOI and Execution of Agreement on stamp paper of
requisite amount. The agreement should be registered with appropriate
authority. The cost of stamp duly to be borne by the Prospective bidder
himself/herself.

<!-- page 8 -->

iii) The successful bidder is free to run the business as per the time and days
fixed by the District administration/State Govt. and the Tenant is bound to
follow the same.
iv) The Sale Shop or premises will be given “as is where is basis” along with
Khadi stock (material/products) valuing approx. Rs.10.84 lakh to the
successful bidder. Any modification, changes, alterations, repairs, if any
required shall be undertaking by the successful bidder at her/his own cost
with prior permission of the CEO, H.P. Khadi and Village Industries Board,
Shimla.
X: Security Deposit: The successful bidder shall deposit the security amount of
Rs. 150000/- (Rupees One lakh fifty thousand only) with H.P. Khadi and
Village Industries Board, Shimla. The Security amount shall be made in the
form of Demand Draft in favour of CEO, H.P. Khadi and Village Industries
Board, payable at Shimla. It shall not carry any interest from the part of H.P.
K&VIB.
XI: Payment Terms: The rent payment frequency is monthly and the monthly rent
amount along with GST shall be paid advance on or before 7th of every
month/quarter as per the agreement terms & conditions . The payment shall
be made through account payee Cheque/DD/RTGS/NEFT. The rent shall be
payable in favour of Chief Executive Officer, H.P. Khadi and Village
Industries Board, Shimla.
(Signature of tenderer)
Seal………………………….
Name: ………………………
Address……………………...
Tel. No. & Email ID………

Annexure-“B”

<!-- page 9 -->

H.P. Khadi & Village Industries Board
Cleave Land Shimla-171004
Ph. No. 0177-2652407, 2653229, 2812280,
e-mail: khadi-hp@nic.in
Tender No: Him. K&VIB/ SS Kangra/2025-26/-

1. ELIGIBILTY CONDITIONS:
The applicants shall meet the following requirements through supporting
documentation :
(a)
The applicant/ bidder i.e. individual/ proprietor/ agency/Firm/SHGs shall
be a registered proprietorship/firm etc. copy of registration certificate etc.
shall be submitted. (Udyog Aadhar registration or Udyam registration
etc.).
(b)
Copy of Goods & Service Tex Registration(GST Registration No.)
(c)
Copy of PAN either of individual or firm.
(d)
The applicant should be having an active bank account & details are be
mentioned in Annexure-“C”
(e)
Undertakings on a non-judicial stamp paper of 100/- in Performa as
provide in Annexure-I & II
(f)
Average turn over of the bidder should be above Rs.50.00 lakh in the last
3 years (2023-24, 2024-25 & 2025-26) and certificate to this effect be
submitted duly signed and sealed by the CA
(g)
The bidder shall submit the undertaking to the effect that he/she will run
the Sale Shop for the activities coming under the ambit of KVI
sector(manufacturing, Service) and/or marketing/sale of KVI products
etc.
(h)
The bidder shall have Aadhar No.
(i)
EMD of Rs. 100000/- in the shape of DD in favour of CEO, H.P. K&VIB
Shimla.
II: ^^Tender for Renting out Sale Shop Situated at Near Bus Stand, Kangra
Distt. Kangra
(a) Envelope-1 (Technical Bid):
Duly filled proforma for the technical bid (Envelop-1) shall be kept in Envelop-1
and it should also contain the following:
(a)
(b)

All supporting document of the bidders responses duly filled and signed
EMD for an amount of Rs. 100000/- in form of DD drawn in f/o ^^Chief
Executive Officer, H.P. Khadi and Village Industries Board, Shimla-4**

<!-- page 10 -->

(c)

payable at ^^Shimla**
Bidder should stemp & sign on all pages of this tender document and
submit the same by keeping it in the Envelop-1

*All pages submitted in technical bid (Envelop-1) shell be serially numbered,
indexed and the documents shell be used as final for all purposes.
(b) Envelope-II (Finance Bids):
It should contain Price Bid only (as per Performa for Finance Bid in Annexure-III)
and it should not be enclose in the envelope meant for technical bid.
Overwriting / correction in the commercial bid are not permitted and any such
overwriting in commercial bid will lead to its rejection.
(c) Envelope-III: Both Envelope 1 & II shall be properly sealed and kept in
Envelope –III.
Note: No. additional /tender documents will be accepted after the expiry of
stipulated date and time for the purpose under any circumstances what so ever.
However, CEO, H.P. Khadi and Vill. Industries Board reserves the right to seek for
any clarification from the bidders either through email or through regd. Post etc, if
there is any ambiguity in the documents submitted by the bidder, and the bidder
needs to respond to the clarification sought by H.P. K&VIB within 2 days of
receipt of communication from H.P. K&VIB.
Place:
Date:

(Signature of tenderer)
Seal………………………….
Name: ………………………
Address……………………...

Annexure-“C”

<!-- page 11 -->

H.P. Khadi & Village Industries Board
Cleave Land Shimla-171004
Ph. No. 0177-2652407, 2653229, 2812280,
e-mail: khadi-hp@nic.in

Eligibility Conditions (Technical Bid Document):
Sr.
No.

Particulars

Response to be fined by bidder

1.

Name of establishment

Individual/Proprietorship/partner
ship Agency etc. (Tick the
relevant one)

2.

Name of the individual/ Owner/
Proprietor/ Firm etc
Name and Address of the
authorized person to whom all
references can be made by the
HPK&VIB
a. Permanent Address:

3.

4.

5.

6.

7.

8.

b. Correspondence Address
Contact Detail:
a. Registered address of the
individual / firm /agency etc.:
b. Email ID:
c. Phone No.:
Registration Number and Date of
registration of firm / agency etc.
(if applicable)
a. Registration No.
b. Date
of
Registration.
(Certificate of incorporation /
registration copy to be
enclosed)
Copy of Goods & Service Tax
Registration Certificate (GST) (if
applicable)
PAN No. of individual / firm
agency etc.
(Copy to be enclosed)

9. Aadhar No.(copy to
enclosed)
10. Bank Account Details:

be

Page No. at which
supporting
document attached

<!-- page 12 -->

a. Account No.
b. Name and address of the
Bank
c. IFSE code
(Cancelled cheque / copy of
bank account to be enclosed)
11. Undertakings on a nonjudicial stamp paper of Rs.
100/- in Performa as
provided in Annexure-I &II
12. Name of the Activities to be
undertaking in the Sale shop,
Kangra Distt Kangra. Pl
mention specific activities
clearly under the ambit of
KVI
sector
and/or
marketing/sale
of
KVI
products etc. Undertaking to
this effect be submitted.
13. Average
Turn
over
certificate of the last 3 years
duly signed and stamped by
the CA
14. Any
other
additional
information, tenderer wishes
to provide to the tendering
authority
like
past
experience etc. (details to be
provided
&
supporting
documentary evidences to be
attached)

Place:
Date:

(Signature of tenderer)
Seal………………………….
Name: ………………………
Address……………………...

Annexure-“D”

<!-- page 13 -->

H.P. Khadi & Village Industries Board
Cleave Land Shimla-171004
Ph. No. 0177-2652407, 2653229, 2812280,
e-mail: khadi-hp@nic.in
Terms and Conditions for renting out Sale Shop situated at Near Bus Stand, Kangra
Distt. Kangra.
1.The ^^Owner** shall mean ^^H.P. State Khadi & Village Industries Board** through its Chief
Executive Officer called “Lesser”.
2. The ^^Tenant** shall mean a person/Firm/Individual who pay Rent (Money) to the owner
for running the Sale Shop & shed measuring 1237 sq. ft. on rental/lease basis called
“Lessee”.
3. The ^^Rent/Lease Agreement** shall mean an agreement between the successful
tender/bidder and the Chief Executive Officer to whom the permission is accorded by the
owner i.e. run the Sale Shop for activities(s) under the ambit of KVI sector and/ or
marketing or sale of KVI products/items etc.
4. The Rate shall mean Rent per month.
5. That the tenant shall ensure to run the Sale Shop & shed for the activities under the ambit of
KVI sector and also mentioned in the tender/bid document.
6. That in case the tenant fails to run Sale Shop & shed for the activities mentioned in the
bid/tender document or running activity(s) other than the activities mentioned in the
bid/tender without the prior approval of the owner, CEO, H.P. Khadi and Village Industries
Board the owner/Khadi Board is at liberty to terminate the agreement during the currency of
agreement period executed with the tenant and the premises will be evacuated without
assigning any reason(s) what so ever.
7. That the tenant shall obtain all due permits, necessary approval, clearance and sanction etc
from the competent authority for all commercial activities as mentioned in the bid/tender by
the bidder and submit copies of the same to HPKVIB within 30 days of issue of Offer
letter/LOI or signing of lease/rent agreement. Further tenant shall register himself/herself
under shop & Establishment act and submit the copies of certificate to HPKVIB. Submission
of documents is at the responsibility of tenant.
8. The tenancy shall be initially for a period of 10 years which can be renewed/extend further
for a period of 5 years at a time, provided that the tenant is running the sale shop properly
and is also being properly maintained to the satisfaction of the owner by the tenant. After
completion of total of 10 years, the tenant shall not reserve the rights to the rented/leased
shop or may grant further extension until finalization of all previous due rent and satisfaction
of the owner.
9. The minimum bidding price is Rs.40000/- /-only per month (Rs. Forty Thousand Only). A
bid lower than the minimum bidding price shall be rejected out rightly.

<!-- page 14 -->

10. The tenderes/tenant shall while quoting monthly rent of the shop, also be required to
purchase the existing Khadi Stock valuing approx. Rs. 10.84 lakh( or as per the actual
stock available at the time of handing over the shop) . The value of the stock will be
determined by the I/c Sale Shop Kangra as per the norms/verified sale rate list and
shall not be negotiated. The successful bidder shall deposit the full cost/value of verified
Khadi stock in addition to the quoted monthly rent, within the stipulated period i.e. 7
days from the date of issuance of allotment letter. Failure to deposit the cost of Khadi
stock within the prescribed period shall render the allotment liable to be cancelled and
the EMD/security deposit may be forfeited.
11. The purchase of Khadi stock shall be mandatory condition for acceptance of the rent
bid/quotation, and any bid without undertaking to purchase the Khadi stock shall be
treated as non-responsive and rejected. The tenant shall purchase 100% of the existing
Khadi stock, no partial purchase shall be permitted. After purchase, the tenant shall be
solely responsible for the sale, storage, condition and disposal of the same.
12. The amount paid for purchase of Khadi stock shall be separate and shall not be
adjusted against monthly rent or security deposit.
13. Increase in standard rent shall be @ 10% automatically after every 3 years on the last
paid monthly rent and if there is any dispute between the landlord and the tenant in regard
to any increase or decrease in rent such dispute shall be decided by the Rent controller.
14. In case of non-payment of rent for a period of two continuous months the owners reserve the
right to initiate all legal action/process to vacated the premise and the earnest/security money
shall be forfeited. The tenant shall have no claim what so ever reading any valuable materials
and articles kept by tenant in the premise/building in this case.
15. In case of 3 accumulative defaults on account of non –payment of rent for 2 continuous
months during the tenancy of rent agreement, the Board may terminate the rent agreement
and tenant shall be liable for eviction.
16. The earnest money of the successful bidder shall be converted into performance security and
shall remain with the owner till three months after expiry of the tenancy period and shall be
released subject to the transfer of possession of complete premise/ building/ belongings/fixed
assets etc by the tenant at the satisfaction of the owner. In case of any damage/breakage
found to the building/premises/fixed assets, etc at the time of handing over the
premise/building etc the tenant shall have to get same done/restore at his own cost and to the
complete satisfaction of the power failing which security money will be forfeited.
17. That the tenant intends to carry on/run any other Khadi and Village Industries activity under
the ambit the KVI sector, he shall have to clearly mention the name of KVI activity to be
undertaken in the building/premises in the Bidder’s profile (Sr. No. 12 of Annexure-A). Any
change/addition to run the other Khadi & Village Industries activities or marketing of KVI
activities during the currency of agreement period shall be subject to the prior
permission/approval from the owner of the premises.

<!-- page 15 -->

18. That in case tenant intends to make any renovation/alteration or add new construction
(like office, hall etc) in the building/premises/Sale Shop Kangra of the Khadi Board
situated at Near Bus Stand, Kangra Distt. Kangra at his/her own cost, he/she shall have
to submit the proposal along with drawing/estimates etc for the same to obtain prior
approval for the same from the Owner i.e. Khadi Board and all necessary approval/
NOC etc required thereof from concerned department/office for the same will have to
be obtained by the tenant himself/herself at his/her own cost. The tenant has no right
what so ever on any renovation/alteration or new construction done by him/her after
the completion/termination of agreement period.
19. The tenant shall have to run and maintain the building, Sale Shop etc. during the tenancy
period at his own cost.
20. The possession of the premises (building, etc.) shall be handed over to the tenant after
execution of rent agreement.
21. The tenant shall obtain a receipt/certificate along with list of articles/etc. with complete
specification/description while taking over the possession of the premises/Sale Shop
(building, etc.) from the owner/ authorized representative of the owner which shall also list
the damages/breakages, if any, noted at the time of taking over by the tenant.
22. All the electricity and water supply charges or any other taxes levy-able shall be paid by
tenant.
23. The tenant shall have the responsibility to keep the premises/Sale Shop neat & clean
including the open area to the satisfaction of the owner. The tenant shall also make the
adequate arrangements for watch & ward of building/ Sale Shop ensure safety, breakage and
any theft of the material fixed in the building including sale shop at his own cost.
24. The tenant shall not temper/deface/alter or add anything to the accommodation provided to
him. He shall not be allowed to remove anything provided in the building/Sala Shop by the
owner with out the prior approval of the owner i.e. C.E.O., H.P. Khadi and Village Industries
Board.
25. The premises shall not be used in any way for gambling or any other illegal/unauthorized
purpose/activities.
26. In case of any violation with regard to the use of the premises/Sale Shop the
tenancy/rent/lease agreement shall be canceled with immediate effect without any notice and
the security deposited shall be forfeited by the owner.
27. The owner and his representative shall have unrestricted right of inspection of the premises
i.e. building, Sale Shop to satisfy himself/herself that the terms and conditions of agreement
are strictly complied with.
28. The tenant shall take necessary precaution for carrying out work to avoid any damage to the
structural/machineries/parts etc. The tenant will rectify any damages done to building, sale
shop etc. at his own cost.

<!-- page 16 -->

29. That the owner shall make repairs like white washing/painting etc of the building as per the
requirement and other kinds of repairs will also be done by the tenant immediately including
machineries parts & equipments, glass panes, window and electrical fittings etc.
30. The tenant shall not further sublet/sublease the Sale Shop wholly or partially to any other
person/firm, in case such discrepancy or complaint comes to the notice of the owner the rent
agreement shall be cancelled and tenant has to vacate the Sale Shop within 7 days and
security deposited will be forfeited.
31. The tenant shall not use the rental accommodation/premises/ Sale Shop for a purpose other
than that for which it has been rented out.
32. The employees/workers employed by tenant for works in Sale Shop shall be purely his
employees and not of the owner in any respect. No child labor shall be employed as per lay
33. The intending tenders/bidders are requested to visit and see over the site/premises of the sale
shop (i.e. Building, & Equipments) before submitting the tender.
34. The Chief Executive Officer reserves the right to reject or accept the tender without assessing
any reason.
35. In case of any dispute between the owner and the tenant the jurisdiction of the court shall be
at Kangra.

(Signature of Tenderer)
Seal………………………………..
Name of the Tendrer…………
Address: ……………………………

<!-- page 17 -->

Annexure-“E”
H.P. Khadi & Village Industries Board
Cleave Land Shimla-171004
Ph. No. 0177-2652407, 2653229, 2812280,
e-mail: khadi-hp@nic.in

I:
(a)

(b)

(c)

(d)
(e)

(f)
(g)

(h)

(i)
(j)

Special terms and Conditions:
In case, of non-eviction of shops/ after permitted period, HPK&VIB may
take a decision to charge double rent from the tenant with initiation of
legal action as per Rent control Act/law.
The Tenant will not be permitted to authorize any sublease/sublet or any
other firm to run the shop rented/leased to him/her without the prior
permission of HPK&VIB.
The lessee shall be in-touch with ADO/DO HPK&VIB Kangra on regular
basis and will also maintain his own register for attending any complaints/
suggestion from residents/ customers.
The H.P. Khadi and Village Industries Board reserves the right to
terminate the lease by giving one month’s notice.
The rented/leased shop is public premises as defined in the Public
Premises (Eviction of Unauthorized Occupants) Act, 1971. Dispute
between the parties shall be decided as per the said act and fall within the
jurisdiction Kangra at Dharamshala only.
The tenant/lessee shall, at its own cost and expenses, put up fire fighting
equipment, fitting etc.
The tenant/lessee shall be responsible for the maintenance of high
standard of cleanness and proper repairs of the premises and also for
repair and maintenance of fixtures. Fitting and additional facilities such as
electricity, etc. The tenant/lessee shall also ensure proper sanitation,
prevention of infectious diseases, control and prevention of nuisance at
the premises, control of insects, rodents etc.
The lessee shall ensure the items sold/served from the premises/sale shop
are of standard quality and/ or in case of any food items, the same are also
of requisite hygiene and quality standards and conform to the prevention
of food Adulteration Act. 1954 and any other guidelines, standards, etc.
issued by Authorities concerned from time to time.
A rate list must be displayed at prominent places in the Sale shop/ outlet.
The Tenant/Lessee, his agents and servants shall observe/perform and
comply with all applicable laws/rules and regulation of the Shop &

<!-- page 18 -->

(k)

II:

Establishment Act. This also included Agreement compliance of laws
relating to hygiene, storage, sanitation, product quality and disposal of
water & waste material etc.
On the expiry of the period of the agreement or on its termination as the
case may be, the tenant shall deliver vacant possession of the premises
intact to the owner on the last day of contract. In the event of the
tenant/lessee fails to deliver the vacant possession of the shop to the
owner, the owner shall have the right to take possession of the putting his
own lock and key to the said premises and shall entitle the tenant to
forfeit the Security Deposit. The articles if any left by the tenant, will be
kept in public auction within a month of taking over the premises by the
owner.
Acceptance/termination of bid:

The CEO, H.P. Khadi and Village Industries Board reserves the right to accept or
reject any bid, and to annul the bidding process and reject all bids, at any time prior
to award of contract without assigning any reason(s) whatsoever and without
thereby incurring any liability to the affected bidders on the grounds of
HPK&VIB’s action.
III: Termination of Contract, Vacant Possession etc.
(a)

(b)

(c)
(d)

(e)

The Chief executive Officer, H.P. Khadi and Village Industries Board reserves
the right to terminate the contract at any time after giving one months notice
without assigning any reason(s). The decision of the CEO, HPK&VIB in this
regard shall be final and binding on the tenant/lessee. The tenant, if he/she so
desires, may seek termination of the contract by serving a notice period of not
less than two months.
The tenant/lessee shall peacefully handover the possession of vacant shop to
the owner, on the expiry of agreement/lease period, without raising any dispute
whatsoever.
The tenant/lessee shall not deal with or indulge in any illegal activity in the
sale Shop.
The tenant/lessee shall not make any unauthorized encroachment or put up any
permanent structure or make any alternation or additions in the premises
without prior written consent of the owner.
The tenant/lessee will be at liberty to remove all the movable
articles(machinery/equipment etc) brought by the tenant in the premises/Sale

<!-- page 19 -->

(f)

(g)

(h)
(i)

(j)

shop during the continuance of the contract, before delivering possession of
the shop.
In case of loss or damage caused to any of the fixtures etc. provided by the
owner and HPK&VIB has right to recover the cost of same from the tenant or
Security deposit.
In case of the death/demise of the tenant/lessee during the agreement/lease
period, the contract shall be treated as cancelled and legal heirs/representation
or successors of the lessee shall not be entitled to claim any right over the
rented/leased shop.
The tenant/lessee shall keep the ambience clean and shall not litter garbage
untidy.
The tenant/lessee and its staff shall behave in civilized manner and will stay
neat & clean. The PVR. (Police Verification Report) of such staff will be the
responsibility of the tenant/lessee.
In case of pre-mature termination of agreement/lease by the tenant/lessee or
cancellation of agreement/lease due to breach of contract terms and conditions
by tenant/lessee, the Security deposit amount and advance rent paid by the
tenant/lessee will be forfeited.

IV:

Statutory Obligations:

(a)

The tenant/lessee shall keep the H.P. Khadi and Village Industries Board
indemnified from all acts of omission, defaults, breaches and/or any claim
damages, loss or injury and expenses to which HPK&VIB may be put to or
involved as a result of tenant’s/lessee’s failure to fulfill any of the obligation
hereunder and /or under status and /or any bye- law or rules framed there
under or any of them.
H.P. K&VIB shall be entitled to recover any such losses or expenses which
may have to suffer or incur on account of such claims, demand, loss or injury
from the Security Deposit of the tenant/lessee without prejudice to its any
other rights under the law.
H.P. K&VIB will not be liable for any act or breach or omission by
tenant/lessee in regards to the statutory obligations whatsoever and shall in no
case be responsible or liable in case of dispute, prosecution or awards made by
Court of Law or other Govt. agencies.
In case of any accident arising out of and in the course of this agreement, H.P.
K&VIB will not be responsible for payment of any compensation under any
other law. It will be the sole responsibility of the tenant/lessee for payment
towards loss or compensation whatsoever. The person engaged by

(b)

(c)

(d)

<!-- page 20 -->

(e)

(f)

tenant/lessee shall be treated, as tenant’s/lessee’s own employees and can
claim no privileges from HPK&VIB. The sole responsibility of all legal or
financial implication would rest with the tenant/lessee. The lessee will be
directly responsible for administration of his employees as regards their wages,
uniforms, general discipline and proper conduct etc.
The tenant/lessee will have to obtain general insurance against risk, fire
accident for his belongings etc. at his own cost and option and shall provide a
copy of the same to HPK&VIB, if taken.
All the taxes / levies/fee charges payable to Govt. Deptt./Local bodies shall be
paid by the tenant/lessee & no claim whatsoever shall be paid by the
HPK&VIB.

V: Penalty provision:

(a)
(b)
(c)
(d)

In the option of the H.P.K&VIB, if the service provider/Tendrer/Bidder fails to
execute the AGREEMENT/TENDERS terms mutually agreed and entered into the
agreement to the satisfaction of the Owner, The H.P. K&VIB has the right to take
following actions:
Imposition of fine for branch of contract terms and conditions.
Forfeiture of Security deposit amount either partially of fully.
Termination of agreement by giving one months notice.
In case of repeated complaint are received, the HP K&VIB may conduct an inquiry
and may take appropriate decision, even to terminate the agreement/lease deed and
also to forfeit the Security Deposit.
VI: Code of Ethics:
The Tenderer should observe the highest standard of either and should not
indulge in the corrupt, fraudulent, anti-competitive and coercive practices either
directly or indirectly, at any stage during the tendering process or during
execution of resultant contracts. If the bidders are found involved in any such
activity, action will be initiated to debar the bidder.
VII: ARBITRATION AND RESOLUTION OF DISPUTES :

(a)

In case of any dispute and difference of opinion arising out of this contract, both
parties shall try to resolve the same amicably by mutual consultation duly
recorded.

<!-- page 21 -->

(b)

(c)

If the parties fail to resolve the dispute by such mutual consultation then either
of the party (depending on the position of the case) shall give notice to other
party of its intention to commence arbitration as per Indian Arbitration and
Conciliation Act. 1996.
All the disputes will be subject to the jurisdiction of Court situated at Kangra.

Signature with Seal)
Name: ______________
Department: __________
Date: _______________

<!-- page 22 -->

Annexure-I
DECLARATION REGARDING ACCEPTANCE OF TERMS AND CONDITIONS
CONTAINED IN THE TENDER DOCUMENT.
(Affidavit duly attested by Public Notary/ Oath Commissioner)
To,
____________________________
____________________________
_____________________________
Dear Sir,
I have carefully gone through “terms and conditions in the tender document
regarding the tender for renting out Sale Shop & vacant shed, Kangra, Distt. Kangra and declare
that all the terms & conditions/ provisions of this document are acceptable to me/ my
Company/Firm. I further certified that I am authorized signatory of my Company/Firm and I am
therefore competent to make this declaration. I further declare that none of the Employee of the
Board is related to me.

Yours faithfully,
Signature:
Name ___________________________
Designation ______________________
Company/Firm ____________________
Address _________________________

<!-- page 23 -->

Annexure-II
Undertaking (non-judicial stamp paper of Rs. 100/-)
I/we have read and understood the contract of tender No. Him.K&VIB/SS
Kangra/2025-26/ and agree to a bid by all the terms and condition of this tender
and undertaking the following.
1. I/we also confirm that in the event of my/our tender being accepted, I/we hereby undertaking
to furnish Performa Security/ Security deposit, as mentioned in the bid document.
2. I/We further undertaking that none of the individual / proprietor /Directors of firm
was or is proprietor or Partner or Director of any firm with whom the government
have banned /suspended. I/we further undertake to report to the CEO, HPK&VIB,
Shimla immediately after we are informed but, in any case, not later than 15 days,
if any firm in which Proprietor/Partners/Directors are proprietor or Partner or
Director of such a firm which is banned/suspended in future during the currency of
the contract with you.
3. I/We agree that all disputes, if arising related to this tender, shall be within the jurisdiction of
courts of Kangra at Dharamshala Distt. Kangra.
4. I/We undertaking that the firm/company etc. has never been blacklisted by any of the
Central/Govt. organization and no criminal case is pending against the firm/company.
5. That the information supplied by the firm/company /bidder in the bid are true and nothing has
been concealed and in case at any stage any information is found false our Security deposit can
also be cancelled by the CEO, HPK&VIB.

6. I/We undertake to obtain all the required documents/certifications from concerned authorities at
my own cost and submit the same to H.P. Khadi and Village Industries Board.
7. H.P. Khadi & Vill. Industries Board’s, Authorities may make surprise inspection to ensure
proper maintenance and sanitation condition.
8. I/We undertake to submit that that I/we shall run the Sale Shop & vacant shed for the activities
mentioned in the tender document as specified at Sr. No. 12 of the eligibility
conditions/Technical bid and in the offer letter/LOI issued by the HPKVIB. In case authorities of
HPKVIB found that I/we are not running the activities as specified/mentioned in the above
during the currency of tenancy period/agreement, I/we shall be liable to any action as deem fit by
the HPKVIB authority, even evection of the premises and the security amount shall also stands
forfeited.
9. I/We undertake to submit that I/we shall purchase the existing Khadi Stock valuing approx. Rs.
10.84 lakh as mentioned in the tender document.( or as per the actual stock available at the time
of handing over the shop).
Signature of Bidder with seal

<!-- page 24 -->

Annexure-III
PROFORMA FOR FINANCIAL BID
To,
The Chief Executive Officer
H.P. Khadi and Village Industries Board,
Shimla-171004.
Sub.:

Financial Bid
(Renting out of Sale Shop & shed at Kangra, Distt Kangra)

Sir,
With reference to your tender No. Him. K&VIB/SS Kangra/2025-26
dated ______ on the subject mention above, the undersigned have read & agreed
all the terms and condition of the tender and quote the rates as under:Sr
no.
1.

Particulars

In Rs.

In Words

Rent per month quoted for
Sale shop & shed at
Kangra (approx Area1237
sq feet)

Note: Reserve price: Rs. 40000/- per month + GST will be extra as applicable.
I/We undertake that if our bid is accept, we will run the shop by observing all
terms & conditions mentioned in the referred tender document.
I/we undertake that the Khadi stock(items/products) at the time of taking over the
shop for rental purpose will be purchased and the said amount be deposited with
the Board.
Signature of Bidder with seal
Name __________________________
Designation ______________________
Company/Firm ____________________
Address ____________________________

Date:
Note. 1: Further, the bidders whose rate are highest will be leased/rented out the
Sale Shop for operating particular nature of shop. In case of the highest quoted
rates of more then one bidder are becoming same, an exclusive limited bidding will
be conducted among the same rate quoted bidders on a same date., bidders on a
scheduled date, The date & venue of bidding will be intimated to those bidders
well in time.
Note. 1: Bids quoted lesser then the minimum/ base rents indicated in the tender
document will be rejected straightaway.

<!-- page 25 -->
