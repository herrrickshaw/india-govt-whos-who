---
doc_id: "e46dc16bfded6fda"
source_url: "https://cdn.s3waas.gov.in/s3766ebcd59621e305170616ba3d3dac32/uploads/2025/07/17531616864344.pdf"
ministry: "Kinnaur"
title: "Final Tender Document Karcham Lake Tourism Development Society Kinnaur Tourism"
date: ""
pages: 42
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "851d71eb94789468"
---

<!-- page 1 -->

Invitation of Bids
For
Selection of Operators
For
Conducting Water Sports activities
At
Karchham Dam,
District Kinnaur, Himachal Pradesh
Issued by
Chairman, The Karcham Lake Tourism Development Society (TKLTDS),
District Kinnaur, Himachal Pradesh, 172107
Tel. No.01786-222253, Email: sdmklp-kin-hp@nic.in
Website: https://hpkinnaur.nic.in

1|Page

<!-- page 2 -->

Chairman, The Karcham Lake Tourism Development Society (TKLTDS)-cum-Deputy
Commissioner, Kinnaur, Tehsil Kalpa, and District Kinnaur, Himachal Pradesh
Bid Invite Notice
The Karcham Lake Tourism Development Society (TKLTDS) invites Bids from leading
reputed Water Sports Operators/Agencies for leasing out Adventure Water Sports activities
at Karchham Lake, Tehsil Sangla, District Kinnaur, Himachal Pradesh.
Name of Adventure Pre-Bid Meeting Last Date for Bid Opening
Activity

Submission

of Opening

Technical Bids Financial Bids

Selection of Operator 1st August 2025 (at 22nd August 2025 29th August 2025 12th
for

Water

Sports 11:00 AM)

Activities

(as

per

Annexure

IV)

at

(by 05:00 PM)

of

(at 11:00 AM)

September

2025 (at 11:00
AM)

Karchham Lake, Tehsil
Kalpa, District Kinnaur,
Himachal Pradesh.

The Bid Document, containing detailed Terms and Conditions, Scope of Work, License Fees,
Eligibility Criteria, and Instructions to Bidders, can be:


Downloaded online from the official district website: https://hpkinnaur.nic.in



Or collected offline from the Office of the Deputy Commissioner-cum-Chairman,
TKLTDS, District Kinnaur, Himachal Pradesh, during working hours up to the Bid Due
Date.



Chairman, TKLTDS reserves the right to accept or reject the bid without any reason
thereof.

Chairman
The Karcham Lake Tourism Development Society

2|Page

<!-- page 3 -->

INDEX
S.

Name of Section

Page No.

No.
1

DISCLAIMER

4

2

LETTER OF INVITATION

5

3

BACKGROUND

6

4

LIST OF IMPORTANT DATES

7

5

SCOPE OF WORK

8

6

DEFINITIONS

9-10

7

INSTRUCTIONS TO BIDDERS

11-19

8

DETAILS ON BID PARAMETERS

20

9

BID EVALUATION PROCESS

21-25

10

GENERAL TERM & CONDITIONS

26-33

11

ANNEXURE-I: LETTER OF APPLICATION

34-35

12

ANNEXURE-II: GENERAL INFORMATION

36

13

ANNEXURE-III: FORMAT FOR TECHNICAL PROPOSAL

37-38

14

ANNEXURE-IV: Details of Adventure/water Sports activities at
Karchham Lake, Tehsil Kalpa, District Kinnaur, Himachal Pradesh

39

15

ANNEXURE-V: Performance Bank Guarantee Format

40-41

16

Annexure- VI: Communication regarding permission for water sports
activities in Karcham Dam, Kinnaur, H.P.

42

3|Page

<!-- page 4 -->

1. DISCLAIMER
a. The information contained in this Bid or subsequently provided to the Bidder(s),
whether verbally or in documentary or any other form, is provided by or on behalf of
the TKLTDS (the “Authority”) on the terms and conditions set out in this Bid
Document.
b. This Bid is neither an agreement nor an offer by the Authority to the prospective
Bidders. It is intended solely to assist Bidders in preparing their proposals. While the
Authority has taken due care in the preparation of this Bid Document, the
information provided does not purport to be exhaustive or accurate in every respect.
The selection of Bidders shall be carried out under the Quality and Cost Based
Selection (QCBS) method, with 30% weightage assigned to the Technical Bid and 70%
to the Financial Bid. Bidders are encouraged to conduct their own due diligence and
obtain independent advice as necessary.
c. Information provided may include interpretation of legal or regulatory frameworks.
The Authority shall not be liable for the accuracy of any such interpretations and
encourages Bidders to seek independent legal counsel.
d. The Authority, its employees, and advisors make no representation or warranty and
shall not be liable under any law for any loss, damage, or expense arising from the
use of information in this Bid Document, including its accuracy, completeness, or
reliability, or from participation in the bidding process.
e. The Authority may, at its sole discretion, amend, update, or supplement the
information in this document and will notify all bidders either by email or by
publishing the updates on its official website.
f. Issuance of this Bid Document does not imply any obligation on the part of the
Authority to award the contract or select any Bidder.
g. The Bidder shall bear all costs related to the preparation and submission of its Bid,
including any presentations or demonstrations. The Authority shall not be liable for
any such expenses, regardless of the outcome of the bidding process. However, the
Authority will strive to ensure transparent communication and fair evaluation
throughout the bidding process.

4|Page

<!-- page 5 -->

2. LETTER OF INVITATION
Date: ________
Subject:

Selection of Operators for Water Sports activities (Jet Scooters & Speed
boats) at Karchham Lake, Tehsil Kalpa, District Kinnaur, Himachal Pradesh.

Dear Sir,
The Karcham Lake Tourism Development Society—TKLTDS (The “Authority”) is inviting
agencies for operations of Water Sports activities (as per Annexure IV) at Karchham Lake,
Tehsil Kalpa, District Kinnaur, Himachal Pradesh.
The Authority invites bi ds from eligible Agencies/Individual Operators, engaged in
operations of Adventure Water Sports Activities and registered under Ministry of Tourism,
Government of India or registered under the Himachal Pradesh State Government subject
to the guidelines issued by Department of Tourism, Govt of Himachal Pradesh (If Bidder is
not registered with Department of Tourism, Govt of Himachal Pradesh, then successful
bidder will have to register within 45 days from the receipt of LOI).
The requirements & evaluation procedure is mentioned in Section 7 of this Bid
Document.
The prospective Bidders can download the bid document from https://hpkinnaur.nic.in
Further, Iin light of the site-specific nature of the activities and associated environmental,
regulatory, and safety considerations, the Authority will conduct a detailed pre-bid meeting
(online/offline) followed by a joint site visit, to facilitate assessment of location feasibility
for water sports activities. Date and venue of the Pre-Bid Meeting will be updated on the
official website and communicated to all bidders who have downloaded/purchased the Bid
Document.

Bidders

are

encouraged

to

submit

questions

in

advance

to:

dtdokinnaur@gmail.com/ sdmklp-kin-hp@nic.in

Authorized Signatory

5|Page

<!-- page 6 -->

3. BACKGROUND:
a. Name of Ac ti v i ty : Selection of Operator for Water Sports Activities (Jet Scooters,
Speed Boats, and Pedal Boats etc. as per Annexure IV) at Karchham Lake, Tehsil
Kalpa, District Kinnaur, Himachal Pradesh.
b. Objective & Scope: The Karchham Lake Tourism Development Society (TKLTDS)
intends to promote regulated and eco-sensitive adventure water sports at Karchham
Lake, Tehsil Kalpa, District Kinnaur, Himachal Pradesh, as detailed in Annexure IV of
this Bid Document. To this end, TKLTDS invites bids from experienced and reputed
national or international operators/agencies to run such activities under a license
agreement governed by the terms specified in this document, including the License
Fee clause (refer Section 5-f). Further as per permission granted by the Himachal
Pradesh Tourism & Civil Aviation Department vide order dated 06/12/2024, water
sports activities shall be permitted to operate exclusively in the stretch from Ralli
Bridge to outfall of Baspa-II HEP and from Sangla Bridge to Karcham Dam conducted
atleast 200 metres away from the main gates of Karcham Dam, district Kinnaur, in
accordance with the recommendations of the Technical Committee constituted
under Chapter III, Rule 9 of the HP Water Sports & Allied Activities Rules, 2021.
i. For the purposes of this bid, “Adventure Activities” shall mean: “A commercially
operated service that offers guided, supervised, and recreational adventure
activities—specifically, water sports as listed in Annexure IV—for various user
categories under safe, regulated conditions.”
c. Bid Document Download: The complete Bid Document can be:
i. Downloaded from the official district website: https://hpkinnaur.nic.in, OR
ii. Collected in hard copy from the office of the Chairman, TKLTDS, during working hours
before the Bid Due Date.
d. Key Information:
Item

Amount

Bid Document Fee (Non-refundable)

Rs. 2,000/- (inclusive of GST)

Earnest Money Deposit (EMD)

Rs. 20,000/-

Note: Both Bid Document Fee and EMD must be submitted offline, as per Clause 3 -d of this Bid Document.

6|Page

<!-- page 7 -->

e. LIST OF IMPORTANT DATES
List of Important Dates of Submission of Bids: Sl. No.
1.

Particulars
Name of Work

2.

Mode of Submission of Bid

3.
4.
5.

Period & Time for Downloading /
Purchasing Bid Document
Date & Time of Pre-Bid Meeting
Mode of Pre-Bid Meeting

6.

Venue for Submission / Opening of Bids

7.
8.
9.

Last Date & Time for Submission of Bids
Date & Time of Opening of Technical Bids
Technical Presentations by Responsive
Bidders

10.

Declaration of Technical Evaluation
Results
Date & Time of Opening of Financial Bids
Tentative Date for Issuance of Letter of
Intent (LOI)
Tentative Date for Signing of Agreement
Officer Inviting Bids

11.
12.
13.
14.

Details
Selection of Operators for Water Sportsrelated adventure activities (as per
Annexure-IV) at Karchham Lake, Tehsil Kalpa,
District Kinnaur, Himachal Pradesh.
Offline at O/o Deputy Commissioner cum
Chairman TKLTDS, Kinnaur.
From 23rd July 2025 (10.00 am) to 22nd
August 2025(05.00 pm)
1st August 2025, at 11.00 am
Offline / Online (as decided by TKLTDS);
includes site feasibility briefing, Q&A, and
indicative tour plan.
O/o Deputy Commissioner cum Chairman
TKLTDS, Tehsil Kalpa, District Kinnaur,
Himachal Pradesh
22nd August 2025, up to 5.00 pm
29th August 2025, at 11.00 am
29th August 2025, immediately after
technical bid opening, or as scheduled by
TKLTDS
3rd September 2025
12th September 2025, at 11.00 am.
20th September 2025
30th September 2025
Nodal Officer, Tender Processing cum
Technical Evaluation Committee, TKLTDS

Note: The above schedule is tentative and subject to change at the sole discretion of the Authority (TKLTDS),
without assigning any reason. Any such change shall be communicated through a corrigendum on the official
website or via written/email communication. The Authority shall not be liable for any costs, damages, or
liabilities arising out of any such rescheduling or administrative delays.

Contact:
Bidders may contact the TKLTDS for queries by mailing to: dtdokinnaur@gmail.com
Contact No. 01975-222253, Website: https://hpkinnaur.nic.in

7|Page

<!-- page 8 -->

f. Scope of Work:
i.

Deployment of approved equipment and qualified manpower at the Karchham
Lake, Tehsil Kalpa, District Kinnaur, Himachal Pradesh for the particular activity (as
mentioned in Annexure IV), for which the bidder is selected for.
ii. Operate & Manage adventure activities (as mentioned in Annexure IV) at the
location, conforming to Himachal Pradesh Water Sports and Allied Activities
Rules, 2021, notified by State Government with all requisite registrations/NOCs,
along with, following due guidelines issued from time to time by Department of
Tourism & Civil Aviation, Himachal Pradesh.
iii. The licensed operator shall strictly conduct water sports activities only within the
approved streches: from Ralli Bridge to outfall of Baspa-II HEP and from Sangla
Bridge to Karcham Dam conducted atleast 200 metres away from the main gates
of Karcham Dam, district Kinnaur, as per the permission granted by the
Department of Tourism & Civil Aviation, Himachal Pradesh dated 06/12/2024 and
the recommendations of the Technical Committee constituted under Chapter III,
Rule 9 of the HP Water Sports & Allied Activities Rules, 2021.
iv. The selected Bidder shall be responsible for obtaining all required regulatory
approvals, land permissions, NOCs, licenses, and environmental clearances within
sixty (60) days from the date of issuance of the Letter of Intent (LOI). The Authority
shall provide necessary facilitation and support by coordinating with the relevant
departments. In case of genuine delay due to reasons beyond the control of the
selected Bidder, the Authority may, at its sole discretion, allow an extension of up
to thirty (30) additional days for completion of these formalities.
v. Successful bidder will strictly follow the rules and regulations like Equipment care
and maintenance, Inspection and Maintenance procedure, SOP and Operating
Instructions, Risk Mitigation, Emergency medical and rescue services on-site and.
medical concerns etc. issued by the Department of tourism (if any).
vi. Maintenance and upkeep of all related infrastructure.
vii. The successful Bidder must ensure full compliance with safety protocols as per
Himachal Pradesh Water Sports and Allied Activities Rules, 2021. The Bidder shall
obtain and maintain comprehensive insurance covering:
1. Public liability
2. Third-party injury/damage
3. Accidental injury/death of participants
4. Property damage
viii. Revenue & Ticket Prices: Ticket charges shall be proposed by the Operator and
approved by TKLTDS. The Authority will adopt a pricing band approach to allow
operational flexibility and seasonal adjustments. An annual escalation of up to 5% on
ticket prices will be permitted, subject to TKLTDS approval.
ix. Avoid unauthorized usage of location and infrastructure.

8|Page

<!-- page 9 -->

4. DEFINITIONS
In this Bid Document, unless the context otherwise requires or provides for, the following
words and expressions shall have the meanings as are hereinafter respectively assigned to
them:
a) “Applicable Laws” means all laws, ordinances, rules, regulations, by-laws, and
guidelines applicable in the jurisdiction of the Project Site, including those related
to tourism, water sports, safety, environment, and water use.
b) “Authority” means the Karchham Lake Tourism Development Society (TKLTDS),
which is responsible for issuing this Bid and overseeing the project.
c) “Bid” means the proposal, including Technical and/or Financial Bids, submitted by
a Bidder in response to this Bid Document.
d) “Bidder” means any individual, company, partnership firm, or legal entity
incorporated or established under applicable laws of its country of origin that
submits a Bid pursuant to this Bid Document.
e) “Bid Document” means this document, including all annexures, formats,
instructions, amendments, addenda, and clarifications issued by the Authority from
time to time.
f) “Bid Due Date” means the last date for submission of Bids as specified in this Bid
Document.
g) “Business Day” means any day on which the offices of TKLTDS are open for official
business.
h) “Dam Authority” means the entity responsible for operations and regulation of the
Karchham Dam, with which scheduling coordination may be required for safe
operation of water sports.
i) “EMD” means the Earnest Money Deposit to be submitted as part of the Bid.
j) “Letter of Intent” (LOI) means the letter issued by the Authority to the Successful
Bidder indicating its intention to award the License Agreement.
k) “License Agreement” means the agreement to be executed between the Authority
and the Successful Bidder outlining terms, conditions, rights, and obligations for
operating the licensed activities.
l) "License Fee" means the fee payable (as per Section 5-f of the bid), by the Successful
Bidder for the right to operate the permitted activities at the Project Site, which
shall remain fixed during the initial two (2) year license period. Any revision shall
apply only at the time of extension and shall be subject to a minimum 5% annual
increase or adjustment based on prevailing market conditions, at the sole discretion
of TKLTDS.
m) “Operating Period” means the duration for which the Successful Bidder is
authorized to conduct water sports activities under the License Agreement.
n) “Operator” means the Successful Bidder authorized by the TKLTDS to operate and
manage the permitted water sports activities.

9|Page

<!-- page 10 -->

o) “Pre-Bid Meeting” means the meeting conducted by the Authority to provide
clarifications and address queries from prospective Bidders prior to submission of
Bids.
p) “Project Site” means the designated operational area at Karchham Lake, Tehsil
Kalpa, District Kinnaur, Himachal Pradesh, where the licensed water sports activities
are to be carried out.
q) “Similar Projects” means previously executed projects involving operation of
similar water-based adventure activities, under any State Government, Central
Government, or Government-approved authority.
r) “Successful Bidder” or “Preferred Bidder” means the Bidder whose Bid has been
accepted and who has been issued a Letter of Intent by the Authority.
s) “Technical Requirements” means the set of technical criteria and conditions
detailed in this Bid Document.
t) “TKLTDS” refers to the Karchham Lake Tourism Development Society.
u) “Water Sports” means commercial adventure activities conducted on water,
including but not limited to Jet/Water Scooter, Banana Ride, Donut/Sofa Ride,
Power Boats, Speed Boats, Motorboats, and Pedal Boats.

10 | P a g e

<!-- page 11 -->

5. INSTRUCTIONS TO BIDDERS
a. Scope of the Bid:
i. Bids

are

invited

from

reputed

and

experienced

Adventure

Activity

Operators/Individuals for operating water sports activities as detailed in Annexure
IV. Bidders must possess the necessary technical and financial capabilities as outlined
in this document.
ii. The Bid Document can be downloaded from https://hpkinnaur.nic.in or collected
physically from the office of the Chairman, TKLTDS, Kinnaur, before the Bid Due Date.
All supporting documents, as per this bid document, must be submitted separately
for each activity applied for.
iii. Bid Document Fee and Earnest Money Deposit (EMD) must be submitted offline only,
in the manner and timelines specified in Clause 3-d.
b. Fraud and Corrupt Practices:
i. Bidders shall maintain the highest standards of integrity and ethics. TKLTDS defines
the following prohibited practices:
1. Corrupt Practice: Offering, giving, receiving, or soliciting anything of value to
influence decisions improperly;
2. Fraudulent Practice: Misrepresentation or omission of facts to mislead for
undue advantage;
3. Collusive Practice: Agreement between parties to restrict competition or
influence outcomes unfairly;
4. Coercive Practice: Harming or threatening harm to influence actions;
5. Obstructive Practice: Destroying or falsifying evidence, or intimidating
individuals to hinder investigations.
ii. If TKLTDS determines that any Bidder has engaged in such practices, the Bid shall be
rejected, the EMD forfeited, and the Bidder may be blacklisted from future tenders.
iii. TKLTDS reserves the right to inspect or audit the bidder’s records related to the bid
process and agreement execution.
c. Bid Preparation:

11 | P a g e

<!-- page 12 -->

i.

All entries in the Bid must be typed or clearly written, without overwriting.
Corrections must be countersigned. Unsigned or incomplete documents may be
rejected.

ii.

Bidders must ensure that they fully meet the eligibility criteria (technical and
financial) prior to bid submission.

iii.

Site visits are encouraged. Bidders must assess local conditions, infrastructure,
regulatory requirements, and operational challenges independently. No costs
incurred for bid preparation or site visits shall be reimbursed.

iv.

Bids shall remain valid for 180 days from the Technical Bid Opening Date. TKLTDS
may request a written extension of the bid validity. If the Bidder refuses such
extension, the EMD shall be forfeited.

d. Bid Submission:
1. Bids must be submitted offline before the Bid Due Date at the following
address: “O/o Chairman-cum-Deputy Commissioner, TKLTDS, Tehsil Kalpa,
District Kinnaur, Himachal Pradesh”.
2. Bids must be submitted in a sealed outer envelope titled “Selection of
Operator for Water Sports Activity” and should contain the following three
sealed inner envelopes:
a. Envelope A – Technical Bid: Signed Bid Document (each
page signed), Annexures II & III with attachments,
Presentation, Letter of Invitation, and documentary
proofs for eligibility, clearly marked as “TECHNICAL BID”.
b. Envelope B – Financial Bid: Financial Bid in the format
prescribed (Annexure V), clearly marked as “FINANCIAL
BID”.
c. Envelope C – Fee/EMD Documents: Proof of payment of
Bid Document Fee and EMD.
3. All documents must be signed either by the Bidder or an authorized
representative (with proof of authorization enclosed).

12 | P a g e

<!-- page 13 -->

4. Late bids or bids submitted in incomplete formats will be summarily rejected.
TKLTDS reserves the right to forfeit EMD for bids rejected due to noncompliance.
5. Required Documents: Each Bid must contain:
a. Signed copy of the complete Bid Document.
b. Proof of eligibility and relevant experience.
c. Certificate of authorization (if applicable).
d. Proof of payment of Bid Document Fee (offline only).
e. Proof of Earnest Money Deposit (EMD) (offline only).
f. Properly filled and signed Technical and Financial Bids.
e. Bid Process
i. Submission of Bids: Bids must be submitted offline at the address specified in this
Bid Document, no later than the Bid Due Date. If the Bid Due Date is declared a public
holiday, the deadline shall extend to the next Business Day during working hours.:
ii. Modification and Extension: The Authority may, at its sole discretion, modify, clarify,
or supplement any part of this Bid Document by issuing written Addenda. Such
Addenda shall be published on the designated website and/or shared with
prospective Bidders by email. If necessary, to give Bidders sufficient time to respond
to such changes, the Authority may also extend the Bid Due Date.
iii. Clarifications During Evaluation: The Authority may seek written clarifications or
additional documents from any Bidder during evaluation. The Bidder must respond
within seven (7) Business Days of such request. Failure to respond within this period
may result in rejection of the Bid and forfeiture of the EMD.
iv. Opening of Bids: Bids shall be opened at the “O/o Chairman TKLTDS cum Deputy
Commissioner, District Kinnaur, Himachal Pradesh” as per the schedule mentioned
in Section 3(e), in the presence of Bidders or their authorised representatives who
wish to attend. Late or incomplete Bids will be summarily rejected.
v. Evaluation of Bids: The evaluation and selection of the Successful Bidder shall follow
the Quality-cum-Cost Based Selection (QCBS) method, as detailed in Section 7 of this
Bid Document. Bidders will be evaluated based on a three-stage process:
13 | P a g e

<!-- page 14 -->

1. Stage 0 – Test of Responsiveness
2. Stage 1 – Technical Evaluation (Minimum qualifying score: 50 out of 100)
3. Stage 2 – Financial Evaluation
vi. The final selection will be based on a weighted composite score, with 30% weightage
to the Technical Score and 70% to the Financial Score, as per the formula and criteria
defined in Section 7.
vii. Award of License: Following the QCBS evaluation, the Bidder with the highest
composite score shall be declared the Successful Bidder for each permitted activity.
The Authority shall issue a Letter of Intent (LOI) and proceed with execution of the
License Agreement upon fulfilment of all requirements.
viii. Inspections & Compliance: The Technical Committee constituted by the Authority
shall conduct periodic inspections of equipment and operations to ensure
compliance with safety, environmental, and technical standards prescribed by the
State Government and the Authority.
ix. Right to Reject: The Authority reserves the right to reject any or all Bids without
assigning any reason, subject to compliance with principles of transparency and
fairness. Canvassing, misrepresentation, or influence during any stage of the process
shall lead to immediate disqualification and forfeiture of EMD.
f. License Fee & Payment Terms:
i.

The Successful Bidder shall pay a License Fee to TKLTDS for the right to operate
each of the following water sports activities at Karchham Lake, Tehsil Kalpa,
District Kinnaur, Himachal Pradesh.

ii.

Bidders must quote rates for all listed activities; partial bids will not be accepted.
The License shall be valid for an initial period of two (2) years, extendable by one
(1) year based on satisfactory performance and subject to a minimum 5% annual
increase or adjustment as per prevailing market conditions, at the sole discretion
of TKLTDS.

iii.

The License Fee shall remain fixed for the initial two-year license period. Any
revision shall apply only at the time of extension.

14 | P a g e

<!-- page 15 -->

Minimum Reserve Price (per activity per item per year):
Sr

Activity

No.

Minimum Reserve Price Rates Quoted by Bidder
(excluding GST)

(excluding GST)

1.

Jet/Water Scooter

Rs. 100000

Rs. ___________

2.

Power/Speed Boat

Rs. 100000

Rs. ___________

3.

Pedal Boat

Rs. 50000

Rs. ___________

4.

Kayak

Rs. 50000

Rs. ___________

Total

Rs. ___________

Rs. ___________

Note: The total quoted license fee shall be evaluated as the cumulative amount for all
activities combined, and bids shall be considered only if amounts are quoted for each activity
listed in Annexure IV. Further discussions regarding feasibility, operational safety, and industry
experience related to each activity listed in Annexure IV will be held during the Pre-Bid
Meeting. Based on feedback received, TKLTDS reserves the right to include, exclude, or modify
any activity prior to final bid submission. Such changes, if any, will be notified through an
official Addendum. The licensee must comply with all norms and performance standards set
by TKLTDS and/or the Himachal Pradesh Tourism & Civil Aviation Department, including any
review committee recommendations.

iv.

Payment Schedule:
1. Security Deposit: The Successful Bidder shall deposit 10% of the total quoted
License Fee (excluding GST) as interest-free security, in the form of a Bank
Draft, before execution of the License Agreement. The Successful Bidder shall
furnish a Performance Bank Guarantee equivalent to 10% of the total quoted
License Fee (excluding GST), as per the format in Annexure V. This amount is
non-adjustable and will be refunded upon successful completion of the license
term, provided there is no breach or default.
2. Instalment Plan:
a. 1/3rd of the total quoted License Fee (plus GST) shall be paid immediately
upon issuance of the Letter of Intent (LOI) and prior to execution of the
License Agreement.
b. The remaining amount shall be paid in two equal instalments as follows:
i. First Instalment: Within 100 days from the date of execution of the
License Agreement

15 | P a g e

<!-- page 16 -->

ii. Second Instalment: Within 200 days from the date of execution of the
License Agreement
3. Additional Activities: In case the Licensee proposes to introduce any additional
water sports activities beyond those specified, prior approval from TKLTDS is
mandatory. If approved, a proportionate increase in the License Fee (plus
applicable GST) shall be levied.
g. Post Selection:
i. Letter of Intent (LOI): Following the selection of the Successful Bidder, the Authority
shall issue a Letter of Intent (the “LOI”) in duplicate. The Successful Bidder shall,
within seven (7) days of receipt (physical or electronic), sign and return one copy of
the LOI as acknowledgment. If the Successful Bidder fails to acknowledge the LOI
within this period, and no extension is granted upon written request, the Authority
reserves the right to withdraw the LOI without any liability, forfeit the EMD, and
consider the next eligible Bidder or re-invite Bids.
ii. License Agreement Execution: The execution of the License Agreement shall
constitute the formation of a binding contract. The agreement period shall be as
defined in Section 6 – Table A.
iii. Preconditions for Signing the License Agreement: The Successful Bidder shall sign
the License Agreement within seven (7) days of fulfilling all the following conditions,
which must be completed within sixty (60) days from the date of issuance of the
Letter of Intent (LOI), extendable by an additional thirty (30) days at the discretion of
the Authority:
1. Submission of the Operation Performance Security as outlined in Section 6 –
Table A.
2. Payment of the initial instalment of the License Fee, as per the terms in Section
5-f.
3. Obtaining all necessary regulatory approvals, registrations, permissions, and
No Objection Certificates (NOCs), including those from the Himachal Pradesh
Tourism & Civil Aviation Department.
iv. Commercial Operation Date (COD): The Successful Bidder shall commence
operations within 100 days from the date of LOI, or as per an agreed implementation
schedule. Failure to do so without valid reasons may result in termination of the
16 | P a g e

<!-- page 17 -->

Agreement, forfeiture of the Operation Performance Security, and issuance of a fresh
RFP or invitation to the next eligible Bidder, after due notice and hearing.
v. Inspection of Equipment: Before the start of operations, the Technical Committee
constituted by the authority or constituted under the relevant rules, shall inspect all
equipment. Regulatory checks will also be conducted as per state government
norms. Technical Committee will check the equipment before the start of
Commercial activity at the Karchham Dam, Tehsil Kalpa, District Kinnaur, Himachal
Pradesh and Regulatory Committee will also check the equipment as per the Rules
notified by the State Government.
vi.

Non-fulfilment of Preconditions: Failure to meet any precondition for License
Agreement execution shall result in withdrawal of the LOI and forfeiture of EMD.
The Authority may proceed to award the license to the next highest-ranked Bidder
or re-invite Bids.

h. Earnest Money Deposit:
i.

In the event of bidder who has submitted the bid wants to withdraw the bid after
the last date of submission of bid, the EMD of such bidder shall be forfeited.

ii.

EMDs of unsuccessful Bidders (except those disqualified under Section g or for
misconduct) will be refunded within 30 Business Days after acceptance of LOI by
the Successful Bidder. No interest shall be payable.

iii.

EMD of Successful Bidder Shall be adjusted toward the Operation Performance
Security/Bank Guarantee required under the License Agreement. It will not carry
any interest.

iv.

Grounds for Forfeiture of EMD: The EMD may be forfeited if the Bidder:
1. Withdraws their Bid after technical qualification but before signing the
Agreement.
2. Fails to execute the License Agreement within the prescribed timeline without
valid justification.
3. Is found, upon investigation, to have misrepresented facts, concealed material
information, or submitted false documents.
4. Attempts to unduly influence the evaluation or decision-making process.

17 | P a g e

<!-- page 18 -->

i. Blacklisting: The Authority may blacklist the Bidder for up to 3 years for misconduct,
misrepresentation, or breach of bid conditions. Such blacklisting shall be preceded
by a written notice and an opportunity to be heard.
j. General:
i. Influence and Unethical Practices: Any effort by a Bidder to influence the Authority
or its officials shall lead to disqualification and forfeiture of EMD, and may attract
further penal action after a show-cause notice.
ii. Delays in Submission: TKLTDS shall not be responsible for any postal or transmission
delays in receipt of Bids or any associated documents.
iii. Bid Evaluation: All evaluations will be conducted strictly in accordance with
applicable law and the terms of the Bid Document.
iv. Dispute Resolution: Any dispute, difference, or claim arising out of or in connection
with this Bid process, including but not limited to interpretation of its terms,
evaluation, disqualification, award, implementation obligations, or any incidental
matter (collectively “Disputes”), shall be resolved in the following manner:
1. Conciliation First: The Dispute shall first be referred in writing to the
Chairman, The Karcham Lake Tourism Development Society (TKLTDS), or to an
officer duly nominated by the Chairman, for resolution through conciliation.
The conciliator shall endeavor to resolve the matter within thirty (30) days of
receipt of the written reference. The conciliation process shall be informal and
non-binding unless the parties expressly agree otherwise in writing.
2. No Arbitration: If the Dispute remains unresolved after the conciliation period,
the matter shall not be referred to arbitration. The parties expressly waive any
right to initiate or invoke arbitration proceedings, including under the
Arbitration and Conciliation Act, 1996 or any subsequent enactment or
amendment thereof.
3. Jurisdiction: All unresolved disputes shall be subject to the exclusive
jurisdiction of the competent Civil Courts at Kinnaur, Himachal Pradesh. By
submitting a Bid, all Bidders irrevocably and unconditionally accept the
jurisdiction of such courts and waive any objections on the grounds of
inconvenient forum, lack of jurisdiction, or any similar claim.

18 | P a g e

<!-- page 19 -->

4. Binding Nature: This Clause shall be binding upon all Bidders and shall survive
the completion or termination of the Bid process and the License Agreement,
if executed.
v. Bidder's Acknowledgment: By submitting the Bid, the Bidder confirms that they:
1. Have fully examined and understood the Bid Document.
2. Have obtained all necessary information and documents.
3. Assume responsibility for any inadequacy in the submitted information.
4. Are aware of all legal, regulatory, and operational requirements.
5. Acknowledge that no claim for damages, extension, or termination shall lie on
the grounds of inaccurate information provided by the Authority.
6. Do not have any conflict of interest with respect to this Bid.
7. Agree to be legally bound by the undertakings and terms set out in the Bid.

19 | P a g e

<!-- page 20 -->

6. DETAILS ON BID PARAMETERS:
Table A
Particular
Bid Document
Fee
EMD
Validity of Bid &
EMD
Pre-bid Meeting
Bid Parameter
Bid Submission
Date & Venue
Bid Opening
Evaluation
Process
Agreement
Period

Operational
Performance
Security

20 | P a g e

Details
Preparation of Bids
Rs. 2,000/- (incl. GST). Payable offline as per Clause 3-d.
Rs. 20,000/-. Payable offline as per Clause 3-d.
180 days from the Bid Due Date.
Date & Venue: As specified in Section 3-e or any amendments thereof.
Bid Submission
Annual License Fee (exclusive of GST), which must exceed the reserve
amount defined under “License Fee.”
As specified in Section 3-e or as amended.
Bid Opening & Evaluation
As per schedule in Section 3-e or as amended.
As per Section 7: QCBS method (70% Financial Bid + 30% Technical
Score).
Post-selection & Execution
The License shall be valid for a period of two (2) years. The term may be
extended by one (1) additional year based on satisfactory performance,
at the sole discretion of the Authority. In case of extension, the License
Fee for the third year shall be subject to a minimum 5% escalation or
revision as per prevailing market conditions, whichever is higher.
10% of final Bid amount as Bank Guarantee/FDR/DD, submitted before
start of operations. Interest-free and forfeitable in case of default.

<!-- page 21 -->

7. BID EVALUATION PROCESS
a. Opening of Bids: The Authority shall open the Bids as per the schedule mentioned
in the Bid Document, at the place specified in Section 3-e of this Bid Document, in
the presence of the Bidders or their authorized representatives who choose to
attend.
b. . Evaluation & Selection Process:
i. The selection of the Successful Bidder shall follow a Quality-cum-Cost Based
Selection (QCBS) method, with 30% weightage for Technical Score and 70%
weightage for Financial Score. The evaluation will be conducted in the following
stages, on a per-activity basis:
1. Stage 0 – Test of Responsiveness
2. Stage 1 – Technical Evaluation
3. Stage 2 – Financial Evaluation
ii. Progression Through Stages: Only those Bidders found responsive in Stage 0 shall be
evaluated in Stage 1. Only Bidders securing a minimum of 50 marks out of 100 in
Stage 1 (Technical Evaluation) shall qualify for Stage 2 (Financial Evaluation).
1. Stage 0: Test of Responsiveness: Prior to the detailed evaluation, the
Authority shall determine whether each bid is substantially responsive to the
requirements of the Bid Document. A bid shall be considered responsive only
if:
a.

It is received in the prescribed format, signed, sealed, and submitted on
or before the Bid Due Date.

b.

It includes the Bid Fee, Processing Fee, and EMD as specified.

c.

It includes necessary documentary evidence establishing the technical
and financial capabilities of the Bidder.

d.

It does not contain material deviations, conditions, or reservations.

e.

Note: Minor deficiencies may be clarified/corrected at the discretion of
the Authority within a specified time frame.

2. Stage 1: Technical Evaluation:
a. Responsive Technical Bids shall be evaluated based on the criteria
outlined below.

21 | P a g e

<!-- page 22 -->

DETAILED TECHNICAL EVALUATION TABLE (Maximum Marks: 100)
S.
Criteria
No.
1
Relevant
Experience in
Water Sports
/ Adventure
Tourism /
Outdoor
Operations

2

Operational
Readiness –
Equipment
Availability

3

Safety
Measures &
Risk
Management

4

Qualified
Manpower

22 | P a g e

Max.
Scoring Sub-Criteria
Marks
20
Based on type and years of
experience:
 Category A – Direct operation
of water-based or adventure
tourism activities (e.g., jet
skiing, scuba, parasailing,
kayaking,
boating):
• 1–2 years: 12–14 marks
• 3–4 years: 15–17 marks
• 5+ years: 18–20 marks
 Category B – Outdoor
tourism/recreation activities
(e.g., ziplining, trekking, ecocamps):
• 1–2 years: 10–12 marks
• 3–4 years: 13–14 marks
• 5+ years: 15 marks
 Category C – General
hospitality
(no
activity
management):
• 3–5 years: 6 marks
• 5–10 years: 8 marks
• 10+ years: 10 marks
 Category D – Startups ≤ 2
years
(without
prior
experience, but meeting
other technical criteria): 5
marks
15
Based on number and quality of
water sports equipment (owned
or leased):
• Less than 5 units: 5 marks
• 5–10 units: 10 marks
• More than 10 units: 15 marks
15
• Deployment of certified safety
personnel – 6 marks
• Standard Operating
Procedures (SOPs), emergency
response plans – 5 marks
• Insurance coverage, safety
gear – 4 marks
10
2 marks per full-time certified
operator/lifeguard (up to 5 staff)

Documents Required
Work Orders,
Experience/Completion
Certificates, Company
Incorporation
Certificate,
Startup/MSME
Registration (if
applicable)

Equipment Invoices,
Lease Agreements,
Ownership Proof,
Photos

Safety Training
Certificates, SOPs,
Emergency Protocols,
Insurance Policies

Staff List with CVs,
Training/Certification

<!-- page 23 -->

5

6

Financial
10
Capability
(Net Worth)
Presentation
30
& Operational
Plan

• ₹5–7 lakh – 5 marks
• ₹7–10 lakh – 7 marks
• >₹10 lakh – 10 marks
Assessed by Evaluation
Committee based on:
• Company profile, experience
relevance – 5 marks
• Operational deployment &
logistics plan – 5 marks
• Equipment planning &
infrastructure – 5 marks
• Safety preparedness &
environmental compliance – 5
marks
• Innovation & service model – 5
marks
• Regulatory and community
compliance approach – 5 marks

(e.g., PADI, WSIA, DG
Shipping)
CA-certified Net Worth
Certificate, Audited
Balance Sheet
PowerPoint or
Multimedia
Presentation, Concept
Notes, Deployment
Charts, Visuals, SOP
Highlights

b. Technical Scoring Methodology:
i. The maximum Technical Score is 100 marks.
ii. Each bid will be evaluated against the criteria listed above, and
marks will be awarded accordingly by the Evaluation Committee.
iii. The Bidder shall submit all relevant details, documents, and
supporting evidence for technical evaluation strictly as per the
format prescribed in Annexure III, failing which the bid may be
deemed non-responsive.
iv. The technical scores of all qualified bidders shall then be
normalized out of 30, using the formula:
1. Normalized Technical Score (Tn_i) = (T_i / T_highest) × 30
Where:
T_i = Technical marks obtained by the bidder
T_highest = Highest technical marks obtained among all
bidders
Tn_i = Normalized Technical Score (out of 30)

23 | P a g e

<!-- page 24 -->

c. Only those bidders who secure a minimum of 50 marks out of 100 in
technical evaluation shall qualify for financial bid opening and final
evaluation.
3. Stage 2: Financial Evaluation: The financial bids of technically qualified bidders
shall be evaluated. The Financial Score will be calculated based on the quoted
license fee as per Section 5-f of this document.
a. The highest quoted license fee (H1) will receive a normalized financial
score of 70, and other bids will be scored proportionally using the
formula:
b. All other bids will be scored proportionally using the formula:
i. Normalized Financial Score (Fn_i) = (F_i / F_highest) × 70
Where:
F_i = Financial bid value of the bidder
F_highest = Highest financial bid among all
technically qualified bidders
Fn_i = Normalized Financial Score (out of 70)
4. Final Evaluation and Selection: The final score for each technically qualified
bidder shall be computed using the QCBS method, as follows:
a. Final Score (S_i) = Normalized Technical Score (Tn_i) + Normalized
Financial Score (Fn_i)
b. The bidder with the highest Final Score (S_i) shall be declared the
Successful Bidder for the respective Water Sports activity (as per
Annexure-IV).
5. Other Conditions:
a. In case In case of a tie, the bidder with the higher Technical Score (T_i)
shall be selected. If a tie persists, preference will be given to the bidder
with greater relevant experience.
b. In the event that the Successful Bidder withdraws or fails to comply with
the post-award requirements, the Authority may consider the nextranked Bidder and offer the opportunity to match the winning license
fee.
c. If only one bid is received, the Authority may, at its discretion:
24 | P a g e

<!-- page 25 -->

i. Invite fresh bids, or
ii. Evaluate the sole bid subject to meeting all technical criteria and
reasonableness of the quoted license fee.
d. The Authority reserves the right to cancel or amend the bidding process
at any stage without assigning any reason.

25 | P a g e

<!-- page 26 -->

8. GENERAL TERMS & CONDITIONS
a. Post-Selection Conditions:
i. The Selected Agency/Operator shall prepare and present a conceptual
plan with a detailed layout of activity zones, common facilities, and
infrastructure before the Authority for approval.
ii. The Selected Agency/Operator shall present valid documentary proof of
having acquired equipment as per the approved concept and shall
demonstrate availability of technically qualified manpower as per the
Himachal Pradesh Water Sports and Allied Activities Rules, 2021. All
equipment shall conform to international safety standards and be
certified by the Technical Committee as constituted by the Government
of Himachal Pradesh.
iii. The Bidder must agree to operate strictly within the zones permitted by
the HP Tourism & Civil Aviation Department, as per the order dated
06/12/2024. Operations shall be confined to stretches from Ralli Bridge
to outfall of Baspa-II HEP and from Sangla Bridge to Karcham Dam
conducted atleast 200 metres away from the main gates of Karcham Dam,
district Kinnaur, in line with the recommendations of the Technical
Committee formed under Rule 9 of the HP Water Sports & Allied Activities
Rules, 2021. Said land shall not be used for any unrelated commercial
activity.
iv. Upon satisfactory compliance with all pre-operational requirements, the
License Agreement shall be executed with the Selected Agency/Operator.
v. The equipment shall be inspected by the designated Technical Committee
in accordance with the prevailing government rules and norms.
vi. The Regulatory Committee shall further verify compliance on a periodic
basis, per statutory mandates.
vii. The Operator/Agency shall operate strictly within the demarcated zone
authorized by TKLTDS and/or the Department of Tourism & Civil Aviation.
viii. All physical infrastructure, including jetty, fuel storage, sanitation,
manpower deployment, buildings, and support facilities shall be
developed by the Operator at its own cost.
26 | P a g e

<!-- page 27 -->

ix. TKLTDS shall not be held liable in case of accidents, injuries, or loss of life.
All such liabilities shall be exclusively borne by the Selected
Agency/Operator.
x. The License Agreement shall be valid for a period of two (02) years,
extendable by one (01) year upon satisfactory performance, solely at the
discretion of the Authority and subject to revised terms, including license
fee.
xi. E-ticketing shall be mandatory. The Operator must produce ticketing
records upon request by the Authority.
xii. The Operator shall ensure that at least 70% of the non-technical staff are
residents of Himachal Pradesh, in line with the employment preference
policy of the Government of Himachal Pradesh.
xiii. TKLTDS may authorize operation of additional Jet Scooters or Speed
Boats, or other equipment mentioned in Annexure IV, on the same
license fee, if required.
xiv. All safety norms prescribed under the HP Water Sports & Allied Activities
Rules, 2021 (including any future amendments) shall be followed strictly
by the Operator.
b. During Execution:
i. Compliance with Laws, Permissions, and Safety:
1. The Operator shall ensure full compliance with applicable central and
state laws, including Himachal Pradesh Water Sports and Allied Activities
Rules, 2021, related to safety, environment, sanitation, and tourism
activities. Cleanliness and safety at the site shall be the sole responsibility
of the Operator.
2. The Operator shall implement all safety standards as per Himachal
Pradesh Water Sports and Allied Activities Rules, 2021, and other
applicable laws.
3. The Operator shall strictly adhere to the operational boundaries
approved by the HP Tourism & Civil Aviation Department, and ensure no
activity takes place within 200 metres of the dam. The Operator shall also
comply with all conditions laid down by the Technical Committee
27 | P a g e

<!-- page 28 -->

constituted under Rule 9, Chapter III of the HP Water Sports & Allied
Activities Rules, 2021.
4. The Operator shall secure and maintain all necessary permissions,
approvals, licenses, and consents, at its own cost, for the entire tenure of
the License.
5. Waste management shall be the Operator’s responsibility, and all waste
shall be disposed of in compliance with local environmental and
municipal norms.
6. The Authority shall not be vicariously liable for any act of the Operator.
The Operator agrees to indemnify TKLTDS against all third-party claims,
damages, or penalties arising due to its operations.
7. TKLTDS, the Department of Tourism, or the Government of Himachal
Pradesh shall bear no liability in the event of any mishap during
operations. The Operator shall assume full responsibility for any loss of
life, injury, or damage to property.
ii. Insurance Requirements: The Operator shall obtain and maintain insurance
policies for all passengers and staff covering the following:
Type of Injury

Insurance Cover (per person)

Minor Injury

₹50,000

Major Injury

₹2,00,000

Death

₹5,00,000

Proof of valid insurance shall be furnished prior to the commencement of
operations.
iii. Payment Defaults and Termination:
1. In case of default in payment of the License Fee or failure of cheque
clearance within ten (10) days from the scheduled due date, the Operator
shall be liable to pay interest at the rate of 12% per annum, calculated on a
daily basis, for each day of delay.
2. If the default continues for more than fifteen (15) days, the Authority may
issue a written notice of intent to terminate the Agreement. If the Operator
fails to remedy the default within seven (7) days from receipt of such notice,

28 | P a g e

<!-- page 29 -->

the Authority shall have the right to terminate the Agreement and take over
possession of the premises, without further liability.
3. The Operator shall deploy POS, e-ticketing systems, QR-code based payment
options, or other digital infrastructure at their own cost, as may be directed
by the Authority, and maintain records for audit and revenue monitoring.
iv. Operational Conditions:
1. No permanent structures shall be allowed at the operational site.
2. TKLTDS shall provide land and water access within 1 km radius of the notified
sites near Karchham Dam. No infrastructure support beyond this shall be
provided.
3. The Operator shall display their business name along with “The Karcham
Lake Tourism Development Society” on all branding material. The Operator
shall conduct all water sports activities strictly within the designated
stretches from “Ralli Bridge to outfall of Baspa-II HEP and from Sangla Bridge
to Karcham Dam conducted atleast 200 metres away from the main gates of
Karcham Dam, district Kinnaur” as approved by the Himachal Pradesh
Tourism & Civil Aviation Department vide order dated 06/12/2024.
Operations must be, in line with the recommendations of the Technical
Committee constituted under Chapter III, Rule 9 of the HP Water Sports &
Allied Activities Rules, 2021.
4. The Operator shall ensure compliance with all technical and safety directives
issued in this regard and shall not undertake any activity outside the
approved area.
5. No unrelated commercial boards or advertisements shall be permitted at the
site.
6. Operator must furnish monthly operational data and financial statements
upon request.
7. An Independent Expert appointed by TKLTDS may conduct quarterly review
of investment progress and operational compliance. Further the operator
would be subject inspections by Regulatory Committee as well as Technical
Committee, created within the ambit of Himachal Pradesh Water Sports and
Allied Activities Rules, 2021.
29 | P a g e

<!-- page 30 -->

v. Hiring of Manpower & Payment of Salaries:
1. The Selected Operator/Agency shall engage adequately trained and licensed
personnel, as required under the HP Water Sports & Allied Activities Rules,
2021 (as amended from time to time), for operating the Adventure Activities
Centre. The Operator shall ensure that:
2. All personnel deployed for technical operations are qualified, licensed, and
meet the competency criteria laid down under the applicable Rules.
3. At least 70% of the non-technical manpower is hired from the State of
Himachal Pradesh, in line with the employment policy of the Government of
Himachal Pradesh.
4. The Operator shall be solely responsible for payment of salaries, wages,
benefits, leave, and other statutory dues to their employees, including those
under:
a. The Contract Labour (Regulation & Abolition) Act, 1970,
b. Employees’ State Insurance Act,
c. Minimum Wages Act,
d. Workmen’s Compensation Act, and
e. Other applicable labour laws in force from time to time.
f. The Authority shall not be responsible in any manner for any claims,
dues, or disputes arising between the Operator and its employees. No
employee of the Operator shall have any claim of employment or
service against the Authority or TKLTDS at any point during or after the
agreement period. The Selected Operator shall indemnify and hold
harmless the Authority from all claims, liabilities, costs, penalties, or
expenses arising out of any non-compliance with labour laws or
employee-related disputes.
c. Dispute Resolution: Any dispute, difference, or claim arising out of or relating to this
bid process or any matter incidental thereto, including the interpretation of terms,
disqualification, selection, or award, shall first be referred for resolution to the
Chairman, The Karcham Lake Tourism Development Society (TKLTDS) or an officer
duly nominated by the Chairman, who shall attempt to resolve the matter through
conciliation within thirty (30) days of such reference. If the conciliation fails, no
30 | P a g e

<!-- page 31 -->

arbitration shall be undertaken in connection with such matters. Any unresolved
dispute shall be subject to the exclusive jurisdiction of the competent Civil Courts at
Kinnaur, Himachal Pradesh. All bidders, by participating in this process, expressly
submit to such jurisdiction and waive any objections on the ground of forum non
conveniens or jurisdiction.
i. Any future directives issued by the Government of Himachal Pradesh or
Government of India shall be deemed automatically incorporated into this
agreement and binding on the Operator.
ii. Operator shall operate only those adventure activities as per Annexure IV. No
other activities are permitted.
iii. Subletting or transfer of rights under this License Agreement is strictly
prohibited.
iv. The Operator shall independently arrange all utilities and infrastructure at its
own cost.
d. Continuity of Operations: The Operator shall ensure uninterrupted operations of
the licensed activities during the committed operational season, except in cases of
Force Majeure or other valid reasons communicated and approved in writing by the
Authority. If the Operator ceases operations for a continuous period exceeding 30
(thirty) days without prior written approval from the Authority, a written notice
shall be issued to the Operator seeking justification. If the Operator fails to resume
operations within 30 (thirty) days from the receipt of such notice, or fails to provide
a satisfactory response, the Authority reserves the right to terminate the
Agreement and forfeit the Operation Performance Security/Bank Guarantee
without further notice.
e. Non-Exclusivity of License: The license granted under this Agreement is nonexclusive. The Authority reserves the right to grant similar licenses to other eligible
operators to conduct the same or comparable activities within the designated area.
However, such additional licenses may be granted only at a license fee equal to or
higher than the fee quoted by the selected operator under this Agreement. The
Authority shall not be under any obligation to consult or obtain the consent of the
Licensee while exercising this right.

31 | P a g e

<!-- page 32 -->

f. Breach of Agreement: In the event of non-payment of the License Fee or any other
dues payable to the Authority, including statutory obligations towards any
government body, or in case of breach of any of the terms and conditions of the
Agreement by the Selected Bidder/Operator, the Authority shall have the right to
invoke and appropriate the Operation Performance Security/Bank Guarantee,
either in whole or in part, without prior notice and without prejudice to any other
remedy available. Upon such encashment and appropriation, the Selected
Bidder/Operator shall be required to replenish the Operation Performance
Security/ Bank Guarantee to its original value or furnish a fresh security within thirty
(30) days from the date of encashment. Failure to replenish the Operation
Performance Security/ Bank Guarantee within the stipulated period shall constitute
a material breach of the Agreement, and the Authority shall be entitled to terminate
the Agreement with immediate effect and take over the premises and assets, if any,
without further notice.
i. The Authority or its designated officers may inspect the site for safety and
compliance at any time.
ii. Any breach of operational boundaries as notified under Government order
dated 06/12/2024 shall constitute a material breach of this Agreement,
entitling the Authority to terminate the license forthwith, and forfeit the
Performance Security.
iii. Upon material breach, the Authority shall issue a 30-day rectification notice.
Failure to rectify may lead to immediate termination. Criminal offenses shall
result in automatic cancellation.
g. Force Majeure: No party shall be liable for failure or delay in performance due to
Force Majeure events, including natural calamities, war, terrorism, or government
actions. Prolonged Force Majeure exceeding 60 days may result in mutual
termination without penalty.
h. Environmental Compliance: The Operator shall ensure zero ecological damage and
comply with all environmental regulations. Any breach shall attract liability for
restoration and penalties.

32 | P a g e

<!-- page 33 -->

i.

Data Sharing: The Operator must maintain and share operational data and financial
records in formats prescribed by TKLTDS. Manipulation or failure to report shall be
a material breach.

j.

Grievance Redressal: The Operator shall establish and publicize a grievance
mechanism. All complaints must be resolved within 48 hours and a summary
submitted monthly.

k. Public Liability Insurance: In addition to passenger insurance, the Operator must
hold valid Public Liability Insurance covering all third-party risks and shall indemnify
the Authority for any such claims.
l.

Cultural Sensitivity & Ecological Boundaries: The Operator shall refrain from
disrupting local customs or operating in environmentally restricted zones. Cultural
decorum must be always respected.

m. Exit Clause: The Licensor may terminate the agreement by giving a one-month
notice in emergent circumstances. The Licensee may exit with a three-month
advance notice or by paying three months’ license fee in lieu thereof.

33 | P a g e

<!-- page 34 -->

9. Annexure I
LETTER OF APPLICATION
(On the Letterhead of the Applicant)
Date:
To
The Chairman,
The Karcham Lake Tourism Development Society,
Tehsil Kalpa & District Kinnaur,
Himachal Pradesh
Subject:-

Application for Selection of Operator for Water Sports Activities (Jet
Scooter, Pedal Boats & Speed Boats etc. as per annexure iv) at
Karchham Lake, Tehsil Kalpa, District Kinnaur, Himachal Pradesh.

Sir,
With reference to the Bid Document issued by TKLTDS for the abovementioned purpose, we, the undersigned, being duly authorized to represent and act on
behalf of ………………………………… (hereinafter referred to as “the Bidder”), hereby submit
this Proposal in response to the said Bid for selection as Operator for conducting water
sports activities at Karchham Lake, Himachal Pradesh.
We confirm that we have examined and understood the complete Bid Document, including
all its annexures, amendments, and corrigenda, and we hereby express our full willingness
and commitment to undertake the said activities in accordance with the terms and
conditions set forth therein.
We

confirm

that

our

proposal

is

valid

for

a

period

of

12

months

from_________________________________ (insert the Bid Due Date) and amendments
thereon.
We declare and confirm as under:
i. That all the information and statements made in this Proposal are true, complete,
and accurate to the best of our knowledge and belief.
ii. That this Proposal is made in good faith and that no attempt has been made or
will be made by us to induce any other bidder to submit or not to submit a
proposal for the purpose of restricting competition.

34 | P a g e

<!-- page 35 -->

iii. That our Proposal is valid for a period of twelve (12) months from the Bid Due
Date as mentioned in the Bid Document.
iv. We understand that any omission, commission, or misstatement in factual
declarations made by us shall render our Bid liable to rejection at any stage of the
bidding process or after the award of the project. The Authority reserves the right
to take appropriate action including rejection, forfeiture of security, or
blacklisting, as may be deemed fit.
v. That we agree to be bound by all the terms and conditions of the Bid Document
and any corrigenda issued thereafter.
vi. That in the event of being selected as the Successful Bidder, we undertake to sign
the License Agreement within the prescribed timeline and fulfill all requirements
set forth in the Bid Document.
We understand that the Authority reserves the right to accept or reject any or all Proposals
and to annul the bidding process at any time, without thereby incurring any liability to us.
Yours faithfully,

For and on behalf of
Name of Bidder
Duly signed by the Authorized Signatory of the Bidder
(Name, Title and Address of the Authorized Signatory

35 | P a g e

<!-- page 36 -->

10. Annexure II
General Information:
S.
No
1
2

Particulars

3
4
5
6
7
8
9
10
11
12

Country of Incorporation
Date of Incorporation/Registration
Registered Address of the Bidder
Communication Address
Mobile No.
Landline (if any)
Email ID
PAN No.
GSTIN
Aadhaar / Voter ID / Passport (for
individuals)
Main Line of Business
Proposed Role in the Project
Name & Contact Details of Primary
Contact Person

13
14
15

16

Name of the Bidder Entity
Constitution of the Bidder

Details of Authorized Signatory

Bidder's Response

Individual / Proprietorship / Partnership / Pvt.
Ltd. / Public Ltd. (Tick as applicable)

Attach self-attested copy
Attach self-attested copy
Attach self-attested copy
Briefly mention relevant experience
Operator for Water Sports Activities
Name:
Designation:
Mobile No.:
Email ID:
Name:
Designation:
Mobile No.:
Email ID:
(Attach Authorization Letter/Board Resolution)

……………………………….
(Authorized Signatory of Bidder)

36 | P a g e

<!-- page 37 -->

11. Annexure III
Format for Technical Proposal
Bidders are required to submit detailed technical credentials in the format below. All entries must
be typed, and clearly numbered and indexed. Incomplete submissions or missing documentation
may result in disqualification during Technical Evaluation.
S.

Evaluation Criteria

Bidder’s Input / Details

Supporting Documents (Y/N)

Relevant

Years of Operation: ______

Work Orders

No.
1.

Experience in Water Type of Projects:

Experience Certificates

Sports / Adventure Category: A / B / C / D

Company

/ Outdoor Tourism

Certificate

(as per Clause 2 –

Startup/MSME Registration (if

Technical Evaluation

applicable)

Incorporation

Table)
2.

Operational

Type(s): ______

Readiness

– Owned / Leased

Equipment

Equipment Invoices
Ownership / Lease Agreements

Total Units: ______

Photographs

Availability
3.

Safety Measures & Certified Safety Personnel: Training Certificates
Risk Management

Yes / No

SOPs / Emergency Protocols

SOP / Emergency Plans: Insurance Policies
Attached
Insurance Coverage: Yes /
No
4.

Qualified

No. of certified full-time Staff List

Manpower

operators/lifeguards:

CVs

______

Valid

Training/

Certification

Documents
5.

Financial Capability Net Worth as on ______: ₹ Net
– Net Worth

______

Worth

Certificate

(CA-

certified) Audited Balance Sheet
(last FY)

6.

Presentation
Operational Plan

& Submitted: Yes / No

Print Copy/ Soft Copy (USB or

Contains: Operational Plan / Email)
Company

Profile

/

Equipment

Layout

/

Community Engagement /
SOPs etc.

37 | P a g e

Remarks

<!-- page 38 -->

Declaration by the Bidder:
I/We hereby declare that the information provided above is true and correct to the best of our
knowledge. We understand that any omission, misstatement, or misrepresentation in factual
statements may render our bid liable for rejection at any stage and may lead to termination of the
license agreement if awarded. The Authority reserves the right to take appropriate legal or
administrative action accordingly.

For and on behalf of:
[Name of the Bidder]
(Signature of Authorized Signatory)
Name: ______________________
Designation: __________________
Date: __________
Place: __________

38 | P a g e

<!-- page 39 -->

12. Annexure IV
Adventure activities at Karchham Lake, Tehsil Kalpa, District Kinnaur, Himachal Pradesh
Water Sports Activities:
Location

District

At Karchham Lake from Ralli Bridge

Kinnaur

Permissible Activities
1. Jet/Water Scooter(s)

to outfall of Baspa-II HEP and from

2. Power/Speed Boat(s)

Sangla Bridge to Karcham Dam

3. Pedal Boat(s)

conducted atleast 200 metres away

4. Kayaks

from the main gates of Karcham

(All activities to be undertaken with prior

Dam, Tehsil Sangla & Kalpa, district

written approval of TKLTDS and in

Kinnaur, H.P.

compliance with applicable safety,
environmental, and tourism regulations.)

Additional Operational Guidelines:
1. The project area is situated in proximity to JSW Karcham Wangtoo Hydro Electric Plant,
Dam site, and while the site has been notified for water sports by the Department of
Tourism & Civil Aviation, actual operations shall be conducted only during hours when dam
operations and power generation activities are minimal or suspended, as determined by
the dam authority.
2. Operators shall strictly adhere to any scheduling restrictions or time slots prescribed by
TKLTDS in consultation with the dam management authorities to ensure safety and
coordination.
3. All water sports activities must comply with the Himachal Pradesh Water Sports and Allied
Activities Rules, 2021, and any applicable directives issued by the Department of Tourism
& Civil Aviation or Department of Sports & Youth Affairs or dam authorities.
4. Environmental & Safety Requirements: Bidders shall use eco-friendly fuels, wherever
feasible, low-noise engines, and operate within site capacity while ensuring deployment
of life jackets, safety boats, certified operators, trained first responders, and strict
adherence to all seasonal, weather-related, and Authority-issued restrictions.
5. Proposal of Additional Activities: Bidders interested in proposing additional water-based
or compatible adventure activities may submit such proposals during the pre-bid meeting
or in writing. Approved proposals may be incorporated via an addendum at the Authority's
discretion.

39 | P a g e

<!-- page 40 -->

13. Annexure-V
Format for Performance Bank Guarantee
(To be executed on non-judicial stamp paper of appropriate value)
To
The Chairman,
The Karcham Lake Tourism Development Society (TKLTDS),
Tehsil Kalpa, District Kinnaur,
Himachal Pradesh – [PIN]
PERFORMANCE BANK GUARANTEE
THIS DEED OF GUARANTEE made this ___ day of ________, 20 by___________ [Name of the Bank],
having its Registered Office at _____________________________, and a branch at
___________________________, (hereinafter referred to as the “Bank”, which expression shall
unless repugnant to the context or meaning thereof, be deemed to include its successors and assigns)
in favour of The Karcham Lake Tourism Development Society (TKLTDS) (hereinafter referred to as the
“Authority”), having its office at __________________.
WHEREAS:
A. __________________[Name of the Selected Agency], having its registered office at
____________________ (hereinafter called “the Agency”), has been selected for undertaking the
work of __________________________________ (insert brief description of project/activity), in
pursuance of the Letter of Intent (LoI) / License Agreement dated __________ (hereinafter referred
to as “the Contract”).
B. The Contract requires the Agency to furnish an unconditional and irrevocable Performance Bank
Guarantee for an amount of ₹__________ (Rupees ___________ only) as security for due and faithful
performance of its obligations under the Contract, including compliance with applicable laws, rules,
regulations, and fulfilment of contractual obligations.
C. At the request of the Agency, the Bank has agreed to provide this guarantee.
NOW THEREFORE THIS DEED WITNESSETH AS FOLLOWS:
The Bank hereby irrevocably and unconditionally guarantees and undertakes to pay to the Authority,
immediately on demand in writing, an amount not exceeding ₹__________ (Rupees
_________________________ only), without any demur, reservation, recourse, contest, or protest
and without any reference to the Agency.
The Bank further agrees that the Authority shall be the sole judge as to whether the Agency is in
default in the due and faithful performance of its obligations under the Contract and the decision of
the Authority in this regard shall be final and binding on the Bank, without any scope of dispute or
inquiry.
The Bank shall make the payment upon the Authority’s first written demand, notwithstanding any
dispute or objection raised by the Agency or any third party and the Bank shall not require the
Authority to prove or show grounds or reasons for its demand or the sum specified therein.
This Guarantee shall be irrevocable and remain in full force and effect until a period of sixty (60) days
from the date of successful completion of the Contract or closure/termination of agreement,
whichever is later, unless extended by the Authority.
The Bank further agrees that this Guarantee shall not be affected by any change in the Constitution of
the Agency or the Bank or the Authority or by any variation or amendment in the terms of the Contract
or extension of time or waiver granted by the Authority to the Agency and that the Bank’s liability
under this Guarantee shall be absolute and unconditional.
This Guarantee shall be governed by and construed in accordance with the laws of India and shall be
subject to the exclusive jurisdiction of the courts located in Kinnaur, Himachal Pradesh.

40 | P a g e

<!-- page 41 -->

IN WITNESS WHEREOF, the Bank has caused this Guarantee to be executed under its common seal or
the hand of its duly authorised representative on the day, month, and year first written above.

Signed, Sealed and Delivered
For and on behalf of
[Name of the Bank]
Signature: __________________________
Name: _____________________________
Designation: ________________________
Seal of the Bank: _____________________
Date: _______________/ Place: ______________

41 | P a g e

<!-- page 42 -->

14. Annexure- VI
Communication regarding permission for water sports activities in Karcham Dam

42 | P a g e
