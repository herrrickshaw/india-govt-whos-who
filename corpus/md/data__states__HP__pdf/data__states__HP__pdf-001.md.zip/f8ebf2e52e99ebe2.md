---
doc_id: "f8ebf2e52e99ebe2"
source_url: "https://cdn.s3waas.gov.in/s3766ebcd59621e305170616ba3d3dac32/uploads/2025/10/17599032723526.pdf"
ministry: "Kinnaur"
title: "Tender_DDHE_Library_books new"
date: ""
pages: 31
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7c7b113f6b806b85"
---

<!-- page 1 -->

Office of the
Deputy Director of School Education
(Secondary)
District Kinnaur at Reckong Peo , Himachal
Pradesh
Tel.01786-222221 E-mail- ddhekinnaur@rediffmail.com
OfficialWebsite: https://www.hpkinnaur.nic.in/
No: EDN-KNR-(1)G-2/24 MPLAD

NOTICE INVITING TENDER (NIT)
Sealed tenders/bids under two bid system (i.e. Technical Bid & Financial/Price Bid) are hereby
invited from interested and eligible Book Publishers/Book sellers/Authorized Firms/Dealers on Open
Tender Basis by the undersigned, for the Supply of Various Library Books (As per List enclosed as
Annexure-A) in the 25 selected Govt. Schools of District Kinnaur Himachal Pradesh (List of Schools
enclosed as Annexure-B).
The tender document can be purchased from the Office of the DDSE(SEC) District Kinnaur at
Reckong Peo HP on all working days (between 10AM to 3PM) or the complete tender document along
with its terms & conditions can be viewed and downloaded from the official website of the Deputy
Commissioner Kinnaur HP i.e. https://www.hpkinnaur.nic.in/ subject to deposit of prescribed tender fee.
The cost of Tender Form will be Rs. 1000/- only to be deposited in the shape of demand draft drawn in
favour of DDSE(SEC) District Kinnaur (HP) payable at Reckong Peo (HP).
The last date for receipt of duly filled tender in this Office, in prescribed format and in conformity
to all the requirements enshrined in the tender document shall be 28.10.2025 till 03:00 PM, which shall be
opened on the scheduled date/time as given in the tender document, in presence of the interested
bidders/their authorized representatives or agents, if any, who choose to remain present for witnessing the
tender opening process.
Any corrigendum/addendum etc. to tender/bidding documents shall be available on website only
and bidders are advised to visit the official website of the Deputy Commissioner , Kinnaur HP i.e.
https://www.hpkinnaur.nic.in/ regularly, till the deadline for submission of tender is over.
Sd/Dy Director of School Education (Sec.)
District Kinnaur at Reckong Peo
Himachal Pradesh.
Dated:

Endst. No. A/A
Copy to:
1. The Director Information & Public Relation,HP Shimla with the request to give wide publicity to
the tender by publishing in two daily leading news paper having wide circulation in HP and other
states.
2. Nodal Officer (IT/e-gov) office of the Worthy Deputy Commissioner , Kinnaur with the request to
upload the complete tender document on the official website of the Kinnaur Administration.
3. DA (Store) DDSE(SEC) Office Reckong Peo for info. & further n/a.

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 2 -->

TENDER/BID DOCUMENT
FOR SUPPLY OF LIBRARY BOOKS


Instructions to the Bidder
 Scope
 Key Dates/Venue
 Eligibility Criteria and Terms & Conditions
 Earnest Money Deposit
 Price
 Taxes & Other Duties
 Bid Validity
 Preparation & Submission of Bids
 Signing of Bid
 Evaluation of Bids and Award



General Terms & Conditions





















Contract agreement
Performance security
Price variation clause
Delivery of supplies
Packing
Transit insurance
Delay in delivery
Force majeure
Inspection
Guarantee/warranty
Sample of books
Payment
Telegraphic quotation
Late tender
Amendments/addendums
Contrary conditions
Dispute and arbitration

Annexure- 1 to 10 & A,B
 Tender Submission/Forwarding letter
 Annual Turnover Statement
 Past Performance & Experience Declaration
 Declaration by the Bidder of Eligibility/Qualifications
 Declaration (having gone through and accepted all terms & Conditions)
 Authorization of Bidder by the Firm
 Verification (correctness of documents/certificates)
 Financial Bid
 Rate Reasonability Certificate
 Checklist
 Annexure-A (List of Schools)
 Annexure-B (04 pages- List of Books)

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 3 -->

TENDER (BID) DOCUMENT FOR SUPPLY OF LIBRARY BOOKS
• INSTRUCTIONS TO THE BIDDER
1. SCOPE: 1. *Tenders are hereby invited from interested/authorized/eligible Book sellers/Publishers/
authorized dealers/firms who fulfill the Technical eligibility and Financial criteria as mentioned
in the tender document, for the Supply of Various Library Books (As per Annexure-A) in the
25 selected Schools of District Kinnaur Himachal Pradesh (As per Annexure-B),
I.
2. *The tender document can be purchased from the Office of the DDSE(Sec) District Kinnaur
HP or the complete bid document along with its terms & conditions can be viewed and
downloaded from the official website of the Deputy Commissioner , Kinnaur HP
subject to deposit of prescribed tender fee by the bidder/firm.
3. *The cost of Tender Form will be Rs. 1000/- only (Non Refundable) to be deposited in the
shape of demand draft drawn in favour of DDSE(SEC) District Kinnaur (HP) payable at
Reckong Peo (HP).
4.*The bidders are requested to submit their Tender document a/w Fee, EMD & all required
documents in the manner and as per the requirement specified in this Bid document.
5. Procuring & Payment Authority/Buyer/Purchaser:
“Dy Director of School Education (Sec)Distt Kinnaur HP”
6. Consignee:
7. Delivery Location:

Each Head of the Govt. School (Annexure-B).
Library Room of concerned Govt. school/institution.

2. KEY DATES & VENUE: -

1.

Last Date & Time for submission of Tender
28.10.2025 till 12:00 PM
bids

2.

Date & Time for opening of Technical Bid 28.10.2025 at 02:00 PM
of Tender Form

3.

Schedule of Finance Bid

28.10.2025 at 04:00 PM

4.

Venue of Tender opening process

Office of the
Dy Director of School Education (Secondary)
Distt Kinnaur,at Reckong Peo, H.P.

5.

Bid Validity period

90 days from date of opening of financial bids

6.

For any query/clarification contact on

Email: ddhekinnaur@rediffmail.com,
Tel. No : 01786-222221

Note: - If the date fixed for the opening of Technical Bid is declared as a holiday, the Bid shall be
opened on the next working day at the same time schedule as fixed for the original date for this
purpose.
Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 4 -->

3. ELIGIBILITY CRITERIA AND TERMS & CONDITIONS: A. The interested Bidder shall fulfill/possess necessary eligibility criteria (as given below) to successfully
apply for the bid and discharge its obligation under the terms of this tender document for further
evaluation process:SN Description
1.
2.

Documents required

Tender Form Fee (Non Refundable):

Rs.1000/- (One Thousand only)
Earnest Money (EMD)*:

Rs.70,000/- (Sixty Thousand only)
3.
4.

Registered Firm/Legal Entity:
The Bidder should be a proprietors/Firm/Company.
OEM /Authorization Certification: -

Bank Draft duly drawn in f/o
DDSE(SEC) Kinnaur at Reckong Peo HP
payable at Reckong Peo HP.
DD/FDR duly pledged in f/o
DDSE(SEC) Kinnaur HP payable at
Reckong Peo HP
Copy of Registration Certificate issued by
Competent Authority.
OEM/ Authorization Certificate

Only Book Seller/Publishers/ Authorized dealer/firm can
apply for the bid.
5.

6.

7.

8.

9.

Turnover and Financial soundness*:
 The Bidder should have minimum average turnover of Rs. Audited Balance Sheets and Profit and Loss
10,00,000 per year in the last any continuous three (03) Account of last three years (Both duly
certified by the CA Certificate with CA’s
financial years (from 2022-23, 2023-24 to 2024-25).
Registration Number and Seal)
 The Bidder should be a profit making entity and have long
term profitability duly exhibited through the audited annual
financial statements (B/S, Income Statements) for last 03
FYs.
Work Orders/ Agreement/ Completion
Past Experience*:
The Tenderer should have minimum 03 years experience for Certificate from the Client concerned.
same/similar supplies/services and should have produced or
supplied the Library Books or like material of approximate
amount of Rs. 4 to 5 Lakhs & above in Government/ PSUs/
Corporate sector for last 03 financial years i.e. 2022 to 2025.
Copies of GST and PAN.
Tax Registration Certificate:
The bidder should have a valid registration number of :
(Duly signed & stamped)
 GST where his business is located.
 PAN Number
Non-blacklisting affidavit duly attested by
Non-Blacklisting:
The bidder must furnish a certificate confirming non- notary on Rs. 50/- stamp paper will be
blacklisting status.
provided by the bidder.

Tax Clearance:
No GST liability or Tax clearance certificate.
The bidder should have cleared his Tax/GST dues, if any to
the State Government/Central Government.

10. Income Tax Return
11. ISO Certification:

Certified copies of the last return filed for
quarter ending June 2025 and/or
CA certificate stating that no Tax/GST due to
the State Government/Central Govt.

Copies of IT Returns of FY (2023-24 or
2024-25)
Certificate thereof

The Bidder must have ISO 9001 certification for the
supplies/items required.
Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 5 -->

12. Mandatory Undertaking:
 A declaration by the Bidder as regard to Qualification Declaration to be given on on bidder’s letter
under Section 7 and to abide by the regulations enshrined head to abide by the same and
under Section 11 of the Code of Integrity Act shall be
given and
 The bidder will also submit an undertaking stating therein
that he/she has thoroughly gone through the tender A declaration on Non Judicial stamp paper
document and understood it and accepts all the terms and valuing Rs.100/- be furnished.
conditions mentioned in the tender.

* Note: The Startup Enterprises/Units in Micro and Small Scale Categories in this Sector/service are
exempted from the deposit of EMD/prior experience/turnover requirements provided they meet the
requisite quality standards and other specifications as laid down in the tender. Supporting
documents (Copy of Registration with said Agencies) should invariably be submitted with the
technical bid, for said exemption.
After scrutiny of the Technical Bids, the Financial Bid of only technically qualified bidders shall be
considered for further financial scrutiny & comparison to decide and declare lowest successful bidder (L1
who quoted lowest rate/price for the supplies in question).
B. OTHER TERMS AND CONDITIONS: 1.

Tenders not submitted in the prescribed manner/format shall not be considered and will be
rejected out rightly. Tender without tender fee and/or earnest money will not be considered.
2. DDSE(SEC) reserves the right to reject any or all the tenders without assigning any reason. Part
rate or Conditional or telegraphic or alternative tenders will not be accepted.
3. Tender fee is non-refundable.
4. Mere issuance of this Bid document to prospective Bidder shall not be construed that such a
bidder automatically fulfills the prescribed eligibility Criteria. Bidder's offer is liable to be rejected
if they don't submit any of the certificates / documents sought in the Bid document.
5. Whether the bidder meets the specific eligibility Criteria or not? shall be checked or ascertained,
on opening of their bids and scrutinizing the documents so furnished by them along with their
Bid, by the Purchase Committee of this office.
6. Technical Bids shall be opened at 02:00 PM on dated 28-10-2025 by the Purchase Committee in
the presence of the bidders or their representatives, who wish to remain present.
7. Financial Bids only of technically qualified shall be opened.
8. The bidding process shall be subject to the provisions of the HPFR, 2009 and Himachal Pradesh
Procurement Rules made there under.
9. Since, MRP is mentioned on the books, trade discount on books be mentioned on the MRP, which
should not be less than 15 Percent of MRP. Bidder offering higher discount will be given
preference but there shall be no compromise with the quality of the goods/items required.
10. Expense on account of Advertisement of Tender (incl. Newspapers), shall be recovered from
successful bidder.
Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 6 -->

11. Bidders are advised to check applicable GST on their own before quoting the rates. Buyer will not
take any responsibility in this regards. GST reimbursement will be as per actual or applicable rates
(whichever is lower), subject to the maximum of quoted GST %.
12. Any condition quoted in tender document may be relaxed by the DDSE(SEC) District Kinnaur
(HP) in consultation with Purchase Committee/Section Officer (HPFAS) to meet out the
requirement of items and/or wherever & whenever such necessity arises.
4. EARNEST MONEY DEPOSIT (EMD): (i)Bidder shall have to submit EMD @ Rs. 70,000/- (Seventy Thousand only) in the form of crossed
Demand Draft or duly pledged Fixed Deposit Receipts, duly drawn in favour of ‟Deputy Director,
School Education(Secondary), Kinnaur HP” payable at Reckong Peo (HP).
(ii)The bid shall not be entertained in any case received without the requisite EMD.
(iii)The EMD of unsuccessful bidder will be refunded to them on their written request or as is
decided by the undersigned and no interest will be paid on such EMD. Earnest Money of successful
tenderer shall remain in the custody of the Buyer till the entire supply of goods is made to the best
of satisfaction of the Buyer.
(iv)EMD should be submitted with the technical bid. The Earnest money in the shape of Bank
Guarantee or any other form will not be entertained.
(v)No interest shall be payable on the amount of earnest money. The tenders of those bidders/firms
who do not deposit the earnest money in the prescribed manner will be summarily rejected and their
tenders will not be opened.
1. The EMD shall be forfeited in the following cases: i. If the Bidder withdraws its bid or varies any of the terms & conditions in regard thereto
during the bid validity period
Or
ii. If the bidder indulges in Corrupt, Fraudulent, Collusive or Coercive practice(s)
Or
iii. If the bidder does not accept the correction of its Bid Price, if any
Or
iv. If the successful bidder fails or refuses to accept/ execute the Supply Order when
required.
v.
Or
vi. In the case of a successful Bidder, if the Bidder fails to execute the Contract agreement
within the specified time limit and/or to furnish the required Performance Security, in
accordance with T&C.
5. PRICE: The Rates shall be explicitly quoted for items required and shall be Firm, Final &
F.O.R. destination based (i.e. Library Room of concerned school/institution) inclusive of all taxes &
duties as applicable under law and other costs on account of Transportation, Insurance, terminal
damages if any etc.
Trade discount not less than 15% on the Maximum Retail Price (MRP) shall be provided. Bidder
offering higher discount will be given preference but there will be no compromise with the quality
of the goods required and/or other terms of the tender document. In this regard, the decision of the
Purchase Committee/DDSE(SEC) Kinnaur at Reckong Peo HP shall be final and binding on all the
stakeholders/concerned person.
Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 7 -->

TAXES AND OTHER DUTIES.
I.
Taxes, duties and levies, prior to deadline for submission of bids shall be mentioned in Financial
Bid i.e. Schedule of Quantities & Prices.
II.
All taxes & duties mentioned in the financial bid as per clause 6(i) above will be paid/
reimbursed against proper invoice as per rules/documentary evidence and restricted to the total
amount of Taxes & Duties in Financial Bid subject to clause 6(iii) below. No other taxes and
duties shall be payable/ reimbursable by Deputy Director School Education (Secondary)
Kinnaur HP.
III.
Statutory variation, in Taxes and Duties or levy of any new Tax after deadline for submission of
bid will be adjusted/ reimbursed against production of documentary evidence.
IV.
TDS applicable for the said items shall be deducted at source by Deputy Director School
Education (Secondary) Kinnaur for which TDS certificate will be issued.
6. BID VALIDITY
The rates will be valid for 90 days from the date of opening of the Financial Bid.
7. PREPARATION AND SUBMISSION OF BID:
The bid/quotation shall have to be submitted by the bidder concerned in two-envelope system in the
following manner:
I.ENVELOPE NO.1 shall be super scribed as "Technical Bid” and shall contain the following
documents/certificates as enshrined/required under the provisions of this tender document: SN.
Particulars
1.
Forwarding letter (Anenxure-1)
2.
Checklist (Anneuxre-10)
3.
Tender Form Fee Rs.1000/- only in the form of DD
4.

EMD Rs.70,000/- only in DD/FDR shape as directed.

5.
6.
7.
8.

Certificate of Registration/Legal entity issued by the Govt./Comp. authority
Certificate of OEM/ Authorized dealership / Book seller/Publisher
MSMEs/Startup certification, if any

9.

Work Orders/ Agreement/ Completion Certificate from the Client concerned (for
last 03 financial years i.e. 2022 to 2025.)

10.
11.
12.
13.
14.
15.

ISO/ISI/BSI certification
Duly signed & stamped copy of GST No. & PAN No. of the firm
No Tax liability/Tax clearance certificate
Non-blacklisting Undertaking/ Affidavit
Copies of Income Tax Return of previous year (2023-24 or 2024-25)

16.

A declaration on Non Judicial stamp paper valuing Rs. 100/- in lieu of
having been thoroughly read, understood & accepted in all respects.
Certificate on official letter head of the firm duly verifying/submitting:
Name & Address of the bidder’s banker, Bank Account No. IFSC/MICR

17.

Remarks
DD No.…………
Date…………….
DD/FDR No.………
Date…………….

Audited Balance Sheets and Profit and Loss Account of last three years (Both
duly certified by the CA Certificate with CA’s Registration Number and Seal)
(from 2022-23, 2023-24 to 2024-25).

Declaration to be given on on bidder’s letter head to abide by the Code of Integrity

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 8 -->

Code for NEFT/RTGS purpose.
II.ENVELOPE NO. 2 (Schedule of Quantity & Price) shall be super scribed as “Financial bid” and
shall contain the following:
i. Financial Bid as per Annexure-8 duly filled (quoting prices (in INR) for each product/item,
correct in all respects), signed and stamped.
ii. Rate Reasonability Certificate (Annexure-9) to the effect that the offered rates in tender are
at par with and/or lesser than the prices charged from other Govt. Deptt./Semi
Govt./PSUs/Corporate Institutions (to be provided on official letter head of the firm with
specific mention of NIT/Tender reference).
iii. No Commercial deviation is acceptable. Bidders will submit No deviation Certificate of
Commercial/arithmetical accuracy.
III.ENVELOPE NO. 3: Both the Envelopes 1&2 shall be put in a third bigger envelope duly super
scribed as “NIT reference No. & Due date of opening i.e. _______” on top of the envelope and
complete address of the bidder along with their telephone & fax numbers at bottom left corner and
should reach on or before due date & time on the following address:Dy Director of School Education(Sec), Kinnaur at Reckong Peo (H.P.) Pin No. 172107.
IV.Failure of the bidder to submit any of the above-mentioned documents with their technical bid may
render their bid liable for rejection on grounds of being non-responsive to/ non-compliant with
tender requirements.
8. SIGNING OF BID
i. Complete Bid document duly filled in all respects and all the pages of Bid should be serially
numbered, signed on each page by the contractor/bidder either by himself/herself or his/her
authorized signatory/representative.
ii. Any Authorization to sign on behalf of the Bidder shall consist of “Power of Attorney” by the
Bidder (or) the change in bidder shall be resolved by the firm/ company itself, which shall be
immediately communicated to this office/Purchase Committee.
iii. A person signing the Bid form or any documents forming part of the Bid on behalf of another
person/firm should have an authority to do so and if, on enquiry it appears that the person(s) so
signing the bid/other documents had no authority to do so, the Bid shall be rejected straightway and
hold the signatory liable for all costs, consequences and damages under the civil and criminal
remedies available.
9. EVALUATION OF BIDS and AWARD: 1. The Purchaser/purchase committee will examine the bids to determine whether they are complete
in all respect, free from any computational errors and whether the bids are generally in order,
conforms to all the terms, conditions and specifications of the Tender documents without any
deviations or not/otherwise?
2. At First, Technical Bids so received will be opened and scrutinized by the Purchase
committee as per prescribed eligibility criteria to filter out technically eligible firms/bidders
for further evaluation process.
3. The Evaluation process shall be subject to the provisions of the HPFR, 2009, Himachal Pradesh
Procurement Rules made there under, other instructions issued by the Govt. of HP.
4. After technical evaluation, Financial Bids only of those bidders, who qualify the Technical
Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 9 -->

Bid eligibility criteria will be opened and considered for comparison to select the Lowest
Bidder as L1 for further award of work. Though DDSE(SEC) Kinnaur at Reckpong Peo (in
consultation with the Purchase Committee) reserves the right to place order upon more than one
firm in case it is necessitated to execute the orders in time without seeking any consent of the L1
Bidder, which shall be binding on that firm.
5. During bid evaluation, the Purchaser may ask the bidder for clarification of its bid, if any. The
response of Bidder shall be in writing and no change in the price or substance of the bid shall be
sought, offered or permitted. However, if required for reasonability of the price quoted,
negotiation can be called by the Purchase Committee.

• GENERAL TERMS & CONDITIONS: 1. CONTRACT AGREEMENT
The Firm will have to enter into a “Contract Agreement” with the Buyer for carrying out the aforesaid
work, within a week of the receipt of the supply order. Only the Contractor or his authorized
representative of executive level will be allowed to sign the Contract Agreement. In case Contract
Agreement is not entered within the stipulated period, the supply order will be cancelled without any
further notice and the Earnest Money/Performance security deposited with DDSE(SEC) , Kinnaur HP
will be forfeited.
2. PERFORMANCE SECURITY:
The successful bidder/supplier shall furnish/deposit Performance Security of Rs. 1,25,000/- ( One
Lakh Twenty Five thousand Only) in the shape of FDR duly pledged in the name of the “Deputy
Director School Education(Sec.) District Kinnaur HP payable at Reckong Peo HP” strictly within
one week of the receipt of supply order.
Performance Security shall remain valid for a period of Sixty (60) days from the date of completion of
contract including warranty and guarantee period to the best of satisfaction of Procuring authority.
a. The Performance security shall be partially or fully forfeited, if at any stage;
i. any of the information given/ declaration/certificate is found false or incomplete and/or
ii. tenderer/ bidder refuses/ disagrees to accept or comply with the terms & conditions of the tender and/or
Contract agreement.

3. PRICE VARIATION CLAUSE
The offer of rates by the bidder/firms will subject to the price fall clause i.e. if any item is offered at
a lower rate by the bidder at any other place/state in India, he shall not charge higher rate for the
item offered in the tender. In any case, it comes to notice of the Purchase Committee that the rates
so quoted are higher then the same shall not be accepted and rejected accordingly at any stage. Rate
Reasonability Certificate as required above shall be enclosed with the Technical Bid.
4. DELIVERY OF SUPPLIES
The material shall have to be supplied and installed at the designated Govt. Sr. Secondary
Schools/Govt. High Schools of this District (Annexure- B) within 20 days from the date of receipt
of supply order, which shall be reckoned from the 5th day of issuance of Supply order. Otherwise,
the Purchaser reserves the right to cancel the supply order without any liability/financial obligation
Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 10 -->

and to charge the supplier with monetary penalty for any loss occurred as a result of supplier’s
failure to fulfill its obligation to deliver the required goods within the term specified.
5. PACKING
The supplier shall provide proper and adequate packaging to the Books/goods in accordance with
commercial best practices to ensure that material supplied to the Purchaser is free of damage. The
firm shall use commercially reasonable efforts to utilize recycled and/or recyclable packaging
materials. Expenses incurred by the Purchaser due to Supplier's non-compliance with such
instructions, will be charged to the Suppliers account or deducted from the total payment to be made
to the firm concerned. The Purchaser reserves the right to reject any and/or all material, deemed by
the Purchaser to have been inadequately packaged/damaged/distorted items.
6. TRANSIT INSURANCE
The supplies shall be got insured by the supplier from Firm’s premises up to respective F.O.R.
destination at their own risk and cost.
7. DELAY IN DELIVERY
After placement of the supply order, if the supplier fails to supply the ordered goods in full at
respective Govt. Schools in Distt Kinnaur HP within the stipulated delivery period or non
compliance with the prescribed specification/terms of the tender, he shall, without prejudice to any
other right or remedy of the Buyer on account of such default, pay compensation for delay in supply
@ 0.5 percent per week, on the purchase value of undelivered goods/items for the period of
delay, subject to a maximum of 5% (five percent) of the Supply Order value. The amount of
compensation may be adjusted/withheld/deducted or set-off against any sum due or payable to the
Supplier/Vendor under this or any other contract with the Buyer. The payment or deduction of such
compensation shall not relieve the Supplier from his other obligations and liabilities under the
Contract.
8. FORCE MAJEURE
The failure of a Party to fulfill any of its obligations under the terms of the Tender
documents/contract agreement shall not be considered to be a breach of, or default insofar as such
liability arises from an event of Force Majeure, provided that the Party affected by such an event
takes all reasonable precautions, due care and reasonable alternative measures, all with the objective
of carrying out the terms and conditions of this tender document/contract agreement. A “Force
Majeure” is an event beyond the reasonable control of a Party which makes that Party’s
performance impossible or so impractical as reasonably to be considered impossible and includes
riot, civil disorder, earthquake, fire, explosion, flood or other adverse weather conditions, strikes, or
confiscation or any other action by governments.
9. INSPECTION
The Inspection committee of the school concerned shall inspect the ordered items to ensure
compliance with the terms & conditions of the tender document, conformity to the specifications and
good condition before delivery of items is accepted by the consignee concerned (i.e. Head of the
Institution/school). The Purchaser reserves the right to reject any and/or all material, found to be not
in consonance/conformity with the terms specified in the tender document/agreement.
Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 11 -->

10. GUARANTEE/WARRANTY
The material (requisitioned Library books) shall be free from all sorts of printing defects, poor paper
quality and shall be duly guaranteed/ warranted against any manufacturing defect and poor
workmanship for a period of 12 months from the date of supply or as per manufacturer’s standard
Guarantee/Warranty policy, whichever is more. In case of any discrepancy/defect found in supplied
material, the same shall have to be replaced, free of cost, by the supplier within a reasonable period
of time.
The amount of Performance Security/Security Deposit shall be retained by the undersigned for a
period of two months from the date of completion of supplies as a safeguard against any defect
appearing in the Books so supplied within this period.
11. SAMPLE OF BOOKS
Sealed samples of 30 different books (as mentioned in Annexure-A) is mandatory to be deposited by
the bidder with the Store In-charge of this Office, which will be evaluated along with financial bid.
12. PAYMENT.
No advance payment would be made in any case. Only after satisfactory completion of supplies in
each institution, payment would be made after statutory deduction/ other deductions as may be
applicable.
Payment shall be made through electronics mode i.e. RTGS/ NEFT. The necessary bank charges, if
any shall be borne by the supplier.
13. TELEGRAPHIC QUOTATION
Telegraphic quotations or quotations received through Fax/E-Mail shall not be considered for
evaluation purposes.
14. LATE TENDER
Late tenders i.e. tenders received beyond the expiry of stipulated date & time/posted either on or after
the prescribed stipulated date & time, shall not be accepted and rejected straightway.
15. AMENDMENTS/ADDENDUMS
If any amendment/clarification is carried out in the technical specifications and bid terms &
conditions or any other information, the same will be uploaded on the website DC KNR
(https://www.hpkinnaur.nic.in/). It will not be intimated to individual bidder. The Interested bidders
are advised to check the website regularly.
16. CONTRARY CONDITIONS
Unless mentioned in contrary in the bid, it shall be presumed that all the terms and conditions
stipulated in this tender document are acceptable, in totality, to the bidder.
17. DISPUTE AND ARBITRATION
Any dispute pertaining to this tender or its contract, will subject to Distt. Kinnaur (H.P.) court
jurisdiction only.

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 12 -->

ANNEXURE-1
Tender Submission / Forwarding Letter
To,

The Deputy Director of School Education,(Secondary)
Kinnaur at Reckong Peo (HP)
Subject:

Submission of Bid for your office Tender Ref. No. ………………… Dated………………….

Sir/Madam,

1.

2.

3.
4.
5.

6.
7.

We, the undersigned, do hereby declare that:
I/We have thoroughly gone through all the Terms & Conditions of the Tender document and its
addendum/modifications so circulated by the DDSE(SEC) Kinnaur at Reckong Peo (HP), for the supply
of Library books at 25 designated Govt. Schools and are agree to abide by all the Terms & Conditions
enshrined therein.

We are participating in this bid in the capacity of ……………………………. (OEM/Supplier/
Service Provider). Certificate of authorized/valid Dealer and registration of organization is also
enclosed with the Bid.
I/We are not participating, as Bidders, in more than one Bid in this bidding process, in the
bidding document.
Our firm, its affiliates or subsidiaries, including any subcontractors or Service Provider has not
been debarred/ blacklisted by the State Government or the Procuring Entity.
I/We understand that you are not bound to accept the lowest evaluated Bid or any other bid that
you may receive and we agree to permit the DDSE(SEC) Kinnaur at Reckong Peo or its
representative to inspect our accounts and records and other documents relating to the bid
submission and to have them audited by auditors, if any appointed by the DDSE(SEC) Kinnaur
at Reckong Peo (HP)
I/We declare that we have complied with and shall continue to comply with the provisions of the
Code of Integrity for Bidders as well as the Bidding document.
I/we accept all the terms, conditions and provisions of this bid document.

Dated:

Yours faithfully,

Signature with seal of the Supplier/Authorized person
Name & Address:
Designation:
Tele. No./Mob. :
E-mail:

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 13 -->

ANNEXURE-2

Annual Turnover Statement
The Average Gross Annual Turnover of M/S............................................ (Name of Firm), an
addressee of …………………......................................, for the past three (03) years (2022-25) or any three
continuous years is given below and certified that the statement is true and correct:-

SN.
1.
2.
3.

Financial Years

Total
Average Gross Annual Turnover

Date:

Turnover in Lakhs (Rs.)

Rs.

______Lakhs

Rs.

______Lakhs

Signature of the bidder

Signature & Seal of C.A.

Name & Address:
Tel. No.
Mob. No.

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 14 -->

ANNEXURE-3

Past Performance & Experience Declaration
(supporting documents to be submitted with the technical bid)
I/We....................................................... (Name of firm
of books/printing material as per detail given below:-

Financial
year

Name &
Address of
the Buyer
Deptt./Org.

Work
Order
No.
and
date

Description
of supplies
and
quantity/
units
ordered

) do hereby certify that we have supplied various kind

Date of
completion of
delivery/ service
completion
As per
Actual
contract

Were
the
services done
/supplies
made
in
complete &
satisfactory?

Remarks,
if any

Total

Place:
Date:
Signature of Bidder with Seal

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 15 -->

ANNEXURE-4
DECLARATION BY THE BIDDER REGARDING ELIGIBILITY/ QUALIFICATIONS
In relation to my /our bid submitted to DDSE(SEC) Kinnaur at Reckong Peo (HP) for procurements of
Library Books in response to their Notice Inviting Bid No. ................................ Dated.............................,
I/We hereby declare that:

1. I/We possess the necessary professional, technical, financial, managerial resources and
competence required by the bidding document issued by the Procuring Entity;
2. I/We have fulfilled my/our obligation to pay the applicable taxes payable to the Union and the
StateGovernment or any local authority as specified in bidding document;
3. I/We are not insolvent, bankrupt or being bound up, not have my/our affairs administered by
a court or a judicial officer, not have my /our business activities suspended and not subjected
of legal proceedings for any of the foregoing reasons;
4. I/We and/or our directors and officers not have been convicted of any criminal offence related
to my /our professional conduct or the making of false statement or misrepresentations as to
my/our professional conduct or the making of false statements or misrepresentations as to
my/our qualifications to enter into a procurement contract within a period of three years
preceding the commencement of this procurement process, or not have been otherwise
disqualified pursuant to debarment proceedings;
5. I/We do not have a conflict of interest as specified in the Act, Rules and the Bidding
Document,which materially affects fair competition;
6. I / We hereby declare that we shall abide by the Code of Integrity for Public Procurement as
mentioned under Para of your Tender document and have no conflict of interest as mentioned
under the Para of Tender.
7. I/We do not have any debarment by any other procuring entity.
If this declaration is found incorrect at any time then without prejudice to any other action
that maybe taken as per the provisions of the applicable Act and Rules thereto prescribed by Govt. of
HP, my/our EMD/ Performance security may be forfeited in full and our bid, to the extent if
accepted, may be cancelled.

Date:
Place:

Signature & Seal of bidder with Address

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 16 -->

ANNEXURE-5

(ON A NON JUDICIAL STAMP PAPER OF RS. 100/-)

DECLARATION
I/We
Proprietor/Managing

M/s.

…………………………………………………………

Partner/

Managing

Director/

Partner

having

its

represented
Registered

at…………..…………………… and its workshops/offices at ….…………………… ……… do

by

its

Office
declare

that I/we have carefully read all the conditions of Bid No. .......................... Dated...............................
including all the amendments in Ref. No. ………………… Dtd. ______________ for supply/ services for
library books and accepts all the terms &conditions of bid includingamendments, if any.
I/We agree that the Procuring authority/Buyer may forfeit EMD and/or Performance security
and debar me/us for any period specifying in orders, if any information/document furnished by us is proved to
be false/fabricated at the time of inspection and not complying with the terms and conditions of the bid
document as presented in the bid, its addendum/modification and other relevant documents.

Signature & Seal of bidder
Name & Address:

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 17 -->

ANNEXURE-6
(On letter head of the firm and duly notarized)
AUTHORISATION OF BIDDER BY THE FIRM
To,
The Deputy Director of School Education(Secondary),
Kinnaur at Reckong Peo (HP).
Subject:

Regarding authorization of the Bidder by the Firm.

Dear sir,
Kindly refer to your NIT Ref. No. …………………… dated ……………………, we do hereby
declare that:
1. I/we .................................……… (Name) for M/S......................................................................................
(Firm), having Workshop/Office at ..............................................................(Address of Factory / Office)
hereby authorize

Mr. …………………………....................... (Name & Designation of Bidder). to

submit a Bid, process the same further and enter into a contract with you against your requirement as
contained in the above referred Bid documents/NIB for the above goods/work/ service delivered by us.
2. I/we obtain the approval of Board of Directors of our Firm in the meeting No. . ....................................... held on
dated........................at Agenda No.............................. (Copy of approval enclosed).
3. I/we further confirm that no individual other than Mr................................................................(Name &
Designation of Bidder ), is authorized to submit a Bid, process the same further and enter into a contract with
you against your requirement as contained in the above referred Bid documents for the above goods/services
delivered by our Firm.
4. I/we also hereby extend our full guarantee, CMC as applicable as per Bid conditions of Contract, read with
modifications/addendum, if any, in the General/Special Conditions of Contract for the goods and services
offered for supply by the authorized Bidder/Signatory against this Bid document.
5. I/we also hereby confirm that we shall also be responsible for the satisfactory execution of contract placed on the
authorized Firm.
6. This authorization shall be valid till the completion of the rate contract period for related services or Guarantee
and Comprehensive Maintenance obligations if applicable etc., whichever is later.
7. The attested photocopy of photo ID/Voter ID/Driving License/Any other equal document for authorized
person is enclosed herewith.
Yours faithfully,

(Name & Signature of authorized signatory of firm/bidder)
For M/s ................................................................................

Accepted by the authorized person Mr. ...................................... (Signature, Name & Address)

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 18 -->

ANNEXURE-7
VERIFICATION
I/we………………………………………………S/o………………...…..............……………
Aged..........…year

residing at………………………………………

being

the

Authorized

Bidder/

Proprietor/ Partner/Director of the Firm M/S ……………………………………………..verify and confirm
that the contents of bidding documents, its addendum/modifications, bidding forms and other information
submitted for NIT

No… …………………………. are true and correct to the best of my knowledge and

nothing has been concealed therein.
I/We agree that the Procuring authority/Buyer may forfeit EMD and/or Performance security and debar
me/us for any period specifying in orders, if any information/document furnished by us is proved to be
false/fabricated at the time of inspection and not complying with the terms and conditions of the bid document
as presented in the bid, its addendum/modification and other relevant documents.

Signature of Bidder..............................
Name: ..................................................
Address: ...............................................
Mobile No............................................
E-mail

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 19 -->

ANNEXURE-8

FINANCIAL BID
(Schedule of Quantity & Price)
For Supply of Library books at 25 Govt. Schools
S

Description of the work

N.

Unit/

Per

Unit Total

Qty.

FOR Cost

FOR Discount on

cost (in Rs.)

MRP

(in Rs.)
1.

25 No.
Library books
(Total 284 No. of Books, as per Annexure-A,
will form one quantity/unit)
 FOR of
each quantity will be
designated library in the School (List
of Places of Schools is attached as
Annexure –B)



The FOR cost shall include all
applicable taxes and duties (as per
extant
laws/rules
of
the
Central/State Govt.) be quoted for
above items.
Total

(Name, Signature of Tenderer)
Designation & Stamp

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 20 -->

ANNEXURE-9

(On letter head of the firm)

RATE REASONABILITY CERTIFICATE

We,

_________________________________,

hereby

certify

that

the rates quoted by our firm for the library book so required to be supplied in the Govt. schools are
reasonable and not more than as charged to other Govt. Deptt./Semi Govt./PSUs/Corporate
Institutions for similar supplies in the recent past.

Seal & Signature of Contractor /
Auth. Signatory of firm
With full address

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 21 -->

ANNEXURE-10

CHECK LIST (to be enclosed with Technical Bid)
CERTIFICATES/DOCUMENTS/ANNEXURES TO BE SUBMITTED WITH TECHNICAL BID (Please check following
enclosures before submitting the bid)
SN

Check-List of Documents/Declaration

1.

Whether Tender Form Fee @ Rs.1000/- only in
prescribed manner has been enclosed.
Whether EMD Rs.70,000/- (Seventy Thousand only) in
prescribed manner has been enclosed.
Whether forwarding letter (Anenxure-1) has been
enclosed
Whether supplier is Registered Proprietor/legal entity
Mention Registration No.
Whether the bidder is OEM/Authorized Dealer/ Book
seller/Publisher/?
Whether the Bidder have minimum average turnover of
Rs. 10,00,000 per year in the last any continuous three
(03) financial years (from 2022-23, 2023-24 to 202425)
Whether the Bidder should be a profit making entity and
have long term profitability duly exhibited through the
audited annual financial statements (B/S, Income
Statements) for last 03 FYs.
Whether the bidder have minimum 03 years experience .
for same/similar supplies/services and have produced or
supplied the Library Books or
like material of
approximate amount of Rs. 4 to 5 Lakhs & above in
Government/ PSUs/ Corporate sector for last 03
financial years i.e. 2022 to 2025.
Whether products have ISO/ISI/BSI certification
Whether signed duly stamped copy of GST No./PAN of
bidder/firm has been enclosed.
Whether No GST liability or Tax clearance certificate
enclosed as prescribed
Whether Non-blacklisting Undertaking/ Affidavit has
been enclosed
Whether Copies of Income Tax Return of previous year
(2023-24/2024-25) has been enclosed as prescribed.
Whether original Tender form/document have been
thoroughly read & understood in all respects and all
pages thereof have been duly signed with firm seal.
Declaration on Non Judicial stamp paper of Rs. 100/be submitted.
Whether Name & Address of the bidder’s banker, Bank
Account No. IFSC/MICR Code has been submitted a/w
tender form for NEFT/RTGS purpose.
Whether all above mentioned documents of Technical
Bid duly page numbered, signed & stamped/attested are
sealed properly in a separate envelope with
superscription & name & address of bidder/firm.

2.
3.
4.
5.
6.

7.

8.

9.
10.
11.
12.
13.
14.

15.

16.

YES/
NO

PAGE
No.

Remarks
DD No.…………
Date…………….
FDR No.…………………
Date…………….

Certificate of Registration or legal entity.
Certificate of OEM/Auth. dealership/
Book seller/Publisher
Audited Balance Sheets and Profit and
Loss Account of last three years (Both
duly certified by the CA Certificate with
CA’s Registration Number and Seal)
-Do-

Work Orders/ Agreement/ Completion
Certificate from the Client concerned

Signature of Tenderer /Authorized Signatory
Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 22 -->

Name of the Firm with full address & Seal

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 23 -->

Annexure-A
हायर सेकेंडरी स्कूल@हाई स्कूल के पुस्तकालय हे तु चयनित पुस्तक ों की सूची
क्र-सों-

पुस्तक का िाम

लेखक

मूल्य

1

भारतीय स्त्री रत्न

नीरु मलिक

450.00

2

भारत की शूरवीर मलििाएं

डॉ. बानो सरताज

495.00

3

अं तरााष्ट्रीय ख्यालत प्राप्त भारतीय वैज्ञालनक

एम.पी. कमि

550.00

4

अं तरााष्ट्रीय ख्यालत प्राप्त भारतीय सालित्यकार

एम.पी. कमि

550.00

5

लवशाि भारत के मिान आचाया

उषा लशवागी

395.00

6

नोबेि पुरस्कार लवजेता भारतीय

एम.पी. कमि

495.00

7

िमें गवा िै तुम पर

एम.पी. कमि

595.00

8

भारतीय स्वतंत्रता संग्राम में मलििाएं

बनो सरताज

450.00

9

वीरांगनाएं जो अमर िो गई

सत्यपाि सत्यम

395.00

10

अलिं सा दू त मिात्मा गांधी

प्रेम गोपाि लमत्ति

395.00

11

भारत के भक्तिकािीन संत

उषा लशवागी

450.00

12

स्त्री शक्ति के स्तंभ

नीरु मलिक

400.00

13

मिान लवभूलतयां

मु केश नादान

300.00

14

दे श के गौरव भारत रत्न

राकेश शमाा

595.00

15

िमारे भारत रत्न

ममता लमश्रा

500.00

16

िमारे पद्म भूषण

ममता लमश्रा

595.00

17

िमारे पद्म लवभूषण

ममता लमश्रा

495.00

18

क्ांलतवीर लकशोर

सुिक्षणा

450.00

19

भारत की सन्नाररयां

लवभा गुप्ता

450.00

20

स्वातंत्रय वीर सावरकर

राकेश कुमार आया

450.00

21

अलभज्ञानम शाकुन्तिम

अमिेश कुमार

450.00

22

भारतीय संस्कृलत के वािक

राकेश शमाा लनशीथ

800.00

23

योगीराज दयानन्द

सुदशान भालिया

500.00

24

भारत के वीर क्ांलतकारी

लवभा गुप्ता

395.00

25

भारत की क्ांलत और उसके नायक

मु केश नादान

400.00

26

अमर शिीदों की अमर गाथा

रचना भोिा यालमनी

300.00

27

प्रेमचन्द दपाण

माणकिािा

595.00

28

भारत की 41 प्रथम मलििाएं

डॉ. बानो सरताज

300.00

29

लवश्व के प्रमु ख तानाशाि

एम.पी. कमि

495.00

30

भारत की मिान आध्याक्तत्मक लवभूलतयां

एम.पी. कमि

495.00

31

लशक्षक बनें जग गढें

संतोष कुमार

595.00

32

राजा राममोिन रॉय तथा अन्य िे ख

डॉ. लवद्यासागर आनन्द

595.00

33

कलियुग दपाण

सुदशान भालिया

595.00

34

1111 अनू ठे तथ्ों का ज्ञानकोश

संजय भोिा धीर

495.00

35

एकता और आस्था के प्रतीक

संजय भोिा

350.00

36

आधु लनक लवश्व में रामायण की प्रासंलगकता

लवद्यासागर आनन्द

450.00

37

दे श लवदे श का सामान्य ज्ञान एवं मनोरं जक तथ्

संजय भोिा धीर

595.00

38

गलणत के रोचक खेि एवं मनोरं जक पिे लियां

संजय भोिा धीर

500.00

39

आतंकवाद धमाके मौत सन्नािा

एम.पी. कमि

595.00

40

स्वाधीनता आन्दोिन का स्वलणाम इलतिास

शंकर बाम

395.00

41

इलतिास कुछ ऐसा िै

राकेश कुमार आया

350.00

42

लिन्दी लशक्षण कैसे करें

आशा अय्यर

450.00

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 24 -->

43

जि संसाधन समग्र लववेचन

शोभा अग्रवाि

450.00

44

िमारे व्रत पवा और त्योिार

लवभा गुप्ता

350.00

45

प्राचीन भारतीय राजनय में गुप्तचरों का मित्व

अमिेश कुमार लमश्र

495.00

46

वास्तु लवधा के व्यविाररक अनु प्रयोग

वी.के. पंलडत

250.00

47

अनं त से अनं त की ओर

लवजेन्द्र लसंि

550.00

48

लबखरे मोती

लवजेन्द्र लसंि

450.00

49

भारत की राजनीलत और िोकतंत्र

राकेश कुमार आया

500.00

50

पंचायती राज तब और अब

राकेश शमाा

595.00

51

भारतीय राष्ट्र की समस्याएं और उनके समाधान

राकेश कुमार आया

395.00

52

अतीत की छाया में वतामान

राकेश कुमार आया

400.00

53

लशक्षात्मक प्रसंग

संजीव श्रीवास्तव

395.00

54

जयंलतयां और लदवस िमारे गौरव

मोना सूद

350.00

55

मजिब निीं लसखाता लिन्सा बैर द्वे ष

संजय भोिा

395.00

56

युद्ध त्रासदी लवनाश रिपात

एम.पी. कमि

595.00

57

बेलियां अजन्मी अवांलछत

एम.पी. कमि

595.00

58

स्त्री अक्तिता और अक्तस्तत्व

एम.पी. कमि

595.00

59

पेोषण एवं आिार

सुरेन्द्र श्रीवास्तव

450.00

60

लदनकर के काव्य में सांस्कृलतक चेतना

अनु पमा

595.00

61

शतरं ज नीयम और जानकारी

सुरेन्द्र श्रीवास्तव

300.00

62

कुश्ती नीयम और जानकारी

सुरेन्द्र श्रीवास्तव

250.00

63

लवलभन्न खेिों के लनयम एवं शारीररक लशक्षा

संजय भोिा धीर

450.00

64

कबड्डी लनयम और जानकारी

सोनू कुमार

300.00

65

िॉकी लनयम और जानकारी

सोनू कुमार

300.00

66

एथिे लिक्स लनयम और जानकारी

सोनू कुमार

300.00

67

खेि लशक्षण एवं प्रलशक्षण

सोनू कुमार

300.00

68

फुिबाि लनयम और जानकारी

सोनू कुमार

300.00

69

वॉिीबाि एवं बास्केिबाि लनयम और जानकारी

सोनू कुमार

300.00

70

लिन्दी मु िावरा कोश

डॉ. रामगोपाि भारतीय

495.00

71

लिन्दी किावत कोश

नीरज लमवारी नीरज

495.00

72

प्रलसद्ध क्ां लतकारी कोश

मु केश नादान

450.00

73

आयान मु िावरे एवं िोकोक्ति कोश

लवभा गुप्ता

350.00

74

आयान लिन्दी सूक्ति कोश

मु केश नादान

250.00

75

योग द्वारा स्वास्थ्य रक्षा

डॉ. नवनीत वार्ष्णेय

300.00

76

िमारा स्वास्थ्य खानपान और उपचार

लनरुपमा

450.00

77

रोग और उनके घरे िु उपचार

सुदशान भालिया

300.00

78

फि सक्तियों में लछपा सेित का रिस्य

डॉ. सुबोध कुमार

400.00

79

स्वस्थ रिें सुन्दर लदखें

उषा लशवांगी

450.00

80

जीवन शैिी जलनत बीमाररयां

शंभु सुमन

395.00

81

प्राकृलतक औषलधयां जीवन रक्षक मसािे

सुनीता सुमन

450.00

82

योगासन करें स्वस्थ रिें

सुरेश लसन्हा

450.00

83

प्राकृलतक औषलधयां फि और सक्तियां

सुनीता सुमन

495.00

84

िाइम मै नेजमें ि

मु केश नादान

450.00

85

युवाओं के लिए कॅररयर

जयवीर लसंि

450.00

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 25 -->

86

सफिता के अचूक मं त्र

मलनका वमाा

450.00

87

पयाावरण संरक्षण और कॅररयर लवकल्प

सुबोध गगा

450.00

88

कैसे बनाएं बच्ों का भलवष्य उज्ज्वि

रचना भोिा यालमनी

595.00

89

मलििाओं के लिए कॅररयर

जयवीर लसंि

495.00

90

बॉडी िैं ग्वेज

सुबोध गगा

450.00

91

साईंस एवं िें क्नोिॉजी में कॅररयर

डॉ. सुबोध कुमार

400.00

92

कॅररयर आफ्टर स्कूि

अश्वनी वत्य

400.00

93

पयाावरण एवं कॅररयर

डॉ. सुबोध कुमार

400.00

94

कैसे बढ़ाएं अपनी िरण शक्ति

सुरेंद्र श्रीवास्तव

300.00

95

कैसे रखें लदमाग को रोगमु ि

सुरेंद्र श्रीवास्तव

300.00

96

िम सफि क्ों निीं िोते

मलनका वमाा

495.00

97

बचपन दशा और लदशा

मु केश नादान

495.00

98

गृलिणी एक सुपर वूमन

रचना भोिा यालमनी

495.00

99

व्यक्तित्व लवकास कैसे करें

आशुतोष स्वामी

395.00

100

अच्छा कैररयर सफि जीवन

मु केश नादान

395.00

101

जीवन को उपयोगी कैसे बनाएं

एम.एि. शमाा

350.00

102

मन के नयन िजार

एम.एि. शमाा

450.00

103

सफिता का राज-प्रबंधन

संतोष राष्ट्रप्रेमी

350.00

104

समय की एजेन्सी

डॉ. संतोष गौड़

400.00

105

मे री भारत यात्रा

राजेश श्रीवास्तव

400.00

106

मन की गुक्तियां कैसे सुिझाएं

एम.एि. शमाा

450.00

107

समय प्रबंधन और िघु व्यवसाय

मनीष मािे श्वरी

395.00

108

छोिी मोिी बड़े काम की बातें

एम.एि. शमाा

350.00

109

बच्ों का लवकास आपके िाथ

डॉ सुबोध कुमार

395.00

110

सफिता आपकी मु ट्ठी में कैसे िो

डॉ सुबोध कुमार

395.00

111

साइबर अपराध समस्या समाधान और कररयर

अश्वनी वत्स

400.00

112

धमा लनष्ठ पांडव नीलतलविीन कौरव

सुदशान भालिया

300.00

113

जािन्वी लिन्दी लनबंध

संतोष गौड़

350.00

114

नारी लशक्षा साधन और स्वास्थ्य

लनरुपमा

450.00

115

भ्रूण ित्या दोषी कौन

मु केश नादान

450.00

116

लवज्ञान के अद् भुत चमत्कार

लनरुपमा

450.00

117

लवलचत्र एवं लविु प्त जन्तु

श्वेता रस्तोगी

350.00

118

लवलचत्र कीि पतंगे

श्वेता रस्तोगी

350.00

119

रिस्यमय मानव शरीर

सुरेश लसन्हा

450.00

120

रसायन लवज्ञान एक नजर

सुरेश लसन्हा

450.00

121

जीव जगत के अद् भुत प्राणी

श्वेता रस्तोगी

350.00

122

पेड़-पौधों का रोचक संसार एवं उपयोलगता

लनरुपमा

495.00

123

लवज्ञान की अद् भुत खोजें

मु केश नादान

495.00

124

पयाावरण संरक्षण िर नागररक का दालयत्व

सुदशान भालिया

595.00

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 26 -->

125

मानव जगत का रोचक लवज्ञान

मु केश नादान

395.00

126

लवज्ञान की जादु ई दु लनया

लनरुपमा

300.00

127

आओ जानें ब्रिमांड को

लवभा गुप्ता

250.00

128

आओ जानें इं िरने ि को

लवभा गुप्ता

300.00

129

लवज्ञान वैज्ञालनक और आलवष्कार

रे नु श्रीवास्तव

300.00

130

आओ जानें अं तररक्ष को

लवभा गुप्ता

350.00

131

आओ जानें लवज्ञान के चमत्कार

रे नु श्रीवास्तव

450.00

132

लवज्ञान की नई नई खोजें

लवभा गुप्ता

350.00

133

लवज्ञान आश्चयाजनक लकन्तु सत्य

मु केश नादान

450.00

134

वन संरक्षण तथा पयाावरण

सुदशान भालिया

550.00

135

रं ग लबरं गे पक्षी

सुरेश लसन्हा

550.00

136

प्राकृलतक मिालवनाशर ििरें ...िावा...भूकम्प...

एम.पी. कमि

595.00

137

प्रदू षण का किर

मु केश नादान

450.00

138

थिचर पशु

सुरेश लसन्हा

300.00

139

वायु वायुमंडि और जिवायु

वीर कुमार अधीर

250.00

140

ज्ञान लवज्ञान

यशवंत कोठारी

300.00

141

जीव जगत का उदय और लवकास

वीर कुमार अधीर

200.00

142

जि िी जीवन िै

वीर कुमार अधीर

300.00

143

लवज्ञान जगत की कुछ लवभूलतयां

वीर कुमार अधीर

300.00

144

प्रदू षण मु ि धरती

सुदशान भालिया

595.00

145

कल्याणकारी आलवष्कार एवं खोजें

मोना सूद

495.00

146

जीव जन्तुओं का रोचक लवज्ञान

लनरुपमा

495.00

147

पाक लवज्ञान कोश

अचाना गोयि

495.00

148

भुट्टे के व्यंजन

डॉ. रूलच बागड़दे व

200.00

149

आिू एक स्वाद अने क

रुलच बागड़दे व

250.00

150

अनमोि प्रेरक प्रसंग

लशखा

300.00

151

ज्ञान वैभव

िरीराम भारती

300.00

152

ज्ञान ज्यालत

िररराम भारती

450.00

153

लचंतन के अद् भुत क्षण

डॉ. सत्यदे वा आजाद

250.00

154

तेनािीराम के मनोरं जक लकस्से

िक्ष्मी जैन

300.00

155

भाग्य से श्रेष्ठ बुक्तद्ध

डॉ. िररलसंि पाि

450.00

156

जब जागो तभी सवेरा

डॉ. धनप्रकाश गुप्त

250.00

157

जैसा मन वैसा वरदान

डॉ. िररलसंि पाि

400.00

158

प्रेरणादायक पौश्रालणक कथाएं

िक्ष्मी जैन

300.00

159

करलयर लनदे शान और परामश

एम. एि. शमाा

395.00

160

अकबर बीरबि के लशक्षाप्रद एवं मनोरं जक लकस्से

ईशान शमाा

300.00

161

मनु कनु और मौसी व अन्य किालनयां

अलनता सुरलभ

250.00

162

शत शत नमन काकोरी

डॉ. इन्दू अजनबी

300.00

163

ररचाएं

मं गिा रामचन्द्रन

300.00

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 27 -->

164

अतीत का आं चि

कना ि पुरुषोत्तम गुप्त

450.00

165

दू ध का दू ध पानी का पानी

सुदशान भालिया

395.00

166

रोमांलचत करती सच्ाईयां

सुदशान भालिया

395.00

167

मे री बेितरीन किालनयां

प्रेमचन्द

395.00

168

मोिे राम शास्त्री तथा अन्य व्यंग्यात्मक किालनयां

प्रेमचन्द

395.00

169

तीन श्रेष्ठ नािक

काजी मु श्ताक अिमद

395.00

170

लमजाा गालिब की िवेिी और दो डरामे

काजी मु श्ताक अिमद

450.00

171

वैकफील्ड नगर का पदरी

औलिवर गोक्तमिथ

450.00

172

मिाभारत की प्रेरक कथाएं

मृ दुिा गुप्ता

200.00

173

जीवन िो ऐसा

सुमेर लसंि

395.00

174

प्रेरक प्रसंग मिापुरुषों के संग

सुदशान भालिया

350.00

175

भरत-त्रयी भारतोदय

धनप्रकाश गुप्त

300.00

176

मनु और भारत की राज्यव्यवस्था

राकेश कुमार आया

595.00

177

सतसंग की मिीमा

लवजेन्द्र लसंि

595.00

178

वमचसा

डॉ. एम.जी. लिमये

595.00

179

नारी और गृि लवज्ञान

सुदशान भालिया

350.00

180

जािन्वी लिन्दी अं ग्रेजी सूक्ति कोश

लवभा गुप्ता

495.00

181

राष्ट्र लचंतन की आवश्यकता

राकेश कुमार आया

350.00

182

मिात्मा गांधी की लवचारधारा आज भी प्रासंलगक

राकेश शमाा लनशीथ

550.00

183

दलक्षण भारतीय व्यंजन

मं गिा रामचन्द्रन

500.00

184

जूलियस सीजर

शेक्सपीयर

250.00

185

िै मिे ि

शेक्सपीयर

400.00

186

शीतकािीन किालनयां

शेक्सपीयर

350.00

187

लकंग िीयर

शेक्सपीयर

400.00

188

औथेिो

शेक्सपीयर

300.00

189

भारतीय उद्योग उन्नलत की ओर

राकेश शमाा लनशीथ

495.00

190

भारत के प्रलसद्ध मं लदर और उनका इलतिास

ए. लत्रपाठी

450.00

191

आधे भारत का संघषा

नीिमलण शमाा

695.00

192

इिे क्त्रालनक एवं िे खन मीलडया में कॅररयर

मो. आलमर

450.00

193

मे रे मानस के राम

राकेश कुमार आया

495.00

194

मनोंरजक पिे लियां

अचाना गोयि

300.00

195

सािस और वीरता की किालनयां

मु केश नादान

350.00

196

मिापुरूषों की लशक्षाप्रद कथाएं

राजेश गुप्ता

350.00

197

वीर बािा िक्ष्मीबाई

मु केश नादान

350.00

198

वीर बािकों की किालनयां

लनरुपमा

350.00

199

पशु पलक्षयों की लशक्षाप्रद किालनयां

राजेश गुप्ता

350.00

200

लशकारी का लशकंजा तथा अन्य किालनयां

मु केश नादान

350.00

201

पौरालणक बाि कथाएं

जािन्वी पाराशर

350.00

202

आं खों वािे अं धे

अं जू पाराशर

350.00

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 28 -->

203

मिामू खा और अन्य मनोरं जक किालनयां

िालदा क

350.00

204

मू खा मं गिू

संजय भोिा

350.00

205

किावतों की किालनयां

मु केश नादान

350.00

206

लशक्षाप्रद बाि कलवताएं

डॉ. सुधाकर आशावादी

350.00

207

भारत के वीर बािक बालिकाएं

सुभाष अग्रवाि

350.00

208

सांस्कृलतक बाि कथाएं

रचना भोिा यालमनी

350.00

209

प्रेरणादायक बाि कथाएं

रचना भोिा

350.00

210

झूठे बेर तथा अन्य किालनयां

रचना भोिा यालमनी

350.00

211

अलभमन्यु वध

संजय भोिा

350.00

212

मां कौन

संजय भोिा

350.00

213

शेर और पुजारी

स्नेि िता

350.00

214

चन्दू की इमानदारी

स्नेि िता

350.00

215

मिापुरुषों के अनमोि वचन

लनरुपमा

350.00

216

चमत्कार

स्नेि िता

350.00

217

दो दे शों का राजा

मोलनका शमाा

350.00

218

लशकारी और कबूतर

रचना भोिा यालमनी

350.00

219

दान की मलिमा

रचना भोिा यालमनी

350.00

220

बच्ो की लफल्में लफल्मों में बच्े

डॉ. बानो सरताज

350.00

221

किालनयों में किालनयां वािनों की किालनयां

डॉ. बानो सरताज

350.00

222

पुत्र की प्रलतज्ञा

लवभा गुप्ता

350.00

223

पेड़ और शेर

लवभा गुप्ता

350.00

224

सच्ी दोस्ती

लवभा गुप्ता

300.00

225

राजा और नाई

माधवी

350.00

226

घमं डी भैंसा और शेर

डॉ. रवना

350.00

227

दु ष्ट् संगती कभी ना कीजे

माधवी

300.00

228

इमिी की पेड़

डॉ. रवना

350.00

229

बाि मन की सतरं गी कलवताएं

नवीन डीमरी

350.00

230

पोखू का घमं ड

मिावीर रवांल्टा

350.00

231

ढे िा और पत्ता

मिावीर रवांल्टा

350.00

232

कर भिा िो भिा

मृ दुिा गुप्ता

350.00

233

िाथ जो कल्पतरू िैं

लवजय कुमार

350.00

234

नै लतक कथाएं एवं प्रेरक प्रसंग

बृजेश गुप्ता

350.00

235

प्रेरणात्मक प्रसंग

लवभा गुप्ता

300.00

236

बच्ो की पंचतंत्र

लवजय कुमार

350.00

237

सत्य का चमत्कार

लदने श पाठक शलश

350.00

238

न्यायधीश की दक्षता

लवभा गुप्ता

300.00

239

दो लकशोर उपन्यास

डॉ. जगदीश व्योम

350.00

240

सबसे अच्छा उपिार

लकशोर श्रीवास्तव

300.00

241

पयाावरण पृथ्वी और जीवन

मनीष मिे श्वरी

350.00

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 29 -->

242

नकि का फि

लकशोर श्रीवास्तव

350.00

243

बदिाव

लकशोर श्रीवास्तव

350.00

244

सदाचार का बि

डॉ. रचना

350.00

245

स्वस्थ तन स्वछ मन

पंकज

350.00

246

बोिने वािी लचलड़या

लदने श पाठक शलश

350.00

247

स्वालमभि ने विा

मृ दुिा गुप्ता

350.00

248

में ढकों की मू खाता

डॉ. रचना

350.00

249

आओ जानें पलक्षयों को

लकशोर श्रीवास्तव

350.00

250

चेतन्य की धुन

लवभा गुप्ता

350.00

251

प्यासी लचलड़या

पुनीत कुमार

350.00

252

बंदर और िाथी

लवमि लमत्ति

350.00

253

बुद्धूमि

गंगाराम शमाा

350.00

254

चतुर िोमड़ी

लवभा गुप्ता

350.00

255

िोभी ब्रिमण

लवभा गुप्ता

350.00

256

लगजूभाई की बाि किालनयां - 1

लगजूभाई

350.00

257

लगजूभाई की बाि किालनयां - 2

लगजूभाई

350.00

258

मखमि की जूती

माधवी लबष्ट्

350.00

259

सच्ा िकड़िारा

रवीन्द्र गुप्ता

350.00

260

सच्ा पड़ोसी

लवजय कुमार

350.00

261

बच्े की लजद

अशोक श्रीवास्तव

350.00

262

एकता में शक्ति

लवभा गुप्ता

350.00

263

Glimpses of the Masterminds

Dr.premkumari nahata

595.00

264

Good Manners & Etiquettes Everyday

K.K. Singh

595.00

265

Emotional Intelligence

K.K. Singh

495.00

266

Top 10 Terminologies

Sanjay Bhola Dheer

895.00

267

Teaching English Language

Dr. Sarika Mukesh

595.00

268

The world as we saw it

col P D gupta

395.00

269

Developing creativity and mastery in english grammar

Dr. om subhash

395.00

270

Classics in nut shell

Dr.premkumari nahata

495.00

271

Child Abuse : A Curse on Human Race

M.P. Kamal

595.00

272

Our Padma Bhushan Awardees

Krishna Kumar

695.00

273

Our Padma Vibhushan Awardees

Dr.premkumari nahata

695.00

274

Wildlife Sanctuaries In India

Sanjay Bhola Dheer

795.00

275

Mughal Emperors In India

Sanjay Bhola Dheer

695.00

276

Indian Heroes & Heroines of World War II

Rajinder Kaur Lotay

600.00

277

Rajinder Kaur Lotay

600.00

278

Mahatma gandhi & His Spiritual Successor Acharya
Vinoba Bhave
A Decolonised Historian Vidya Sagar Anand

Rajinder Kaur Lotay

600.00

279

B.R. Ambedkar

Rajinder Kaur Lotay

600.00

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 30 -->

280

Three Great Indian Stalwarts

Rajinder Kaur Lotay

600.00

281

The Teacher Speaks

Dr. Bano Sartaj

495.00

282

Environmental Changes : Cause and Impact

V.K. Mishra

450.00

283

Indian Political Thinkers & Philosophers

Md. Amir

450.00

284

Climate & Nature Changes In India

V.K. Mishra

450.00

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department

<!-- page 31 -->

Annexure-B

SELECTED SCHOOL LIST IN KINNAUR(H.P.)
Sr.No.
1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.

School Name
GHS. Chaura
GHS Chholtu
GHS Kangos
GHS Nathpa
GHS Panvi
GHS Ramani
GHS Sungra
GHS Yangpa-1
GHS Yulla

GSSS Chhota Kamba
GSSS Rupi
GHS Asrang
GHS Nako
GHS Shalkhar
GHS Thangi
GSSS Leo
GHS Chansu
GHS Themgrang
GSSS Barang
GSSS Batseri
GSSS Brua
Devi Chandika GSSS Kothi
GSSS Pangi
GSSS Reckong peo
GSSS Shong

Block
Nichar
Nichar
Nichar
Nichar
Nichar
Nichar
Nichar
Nichar
Nichar
Nichar
Nichar
Pooh
Pooh
Pooh
Pooh
Pooh
Kalpa
Kalpa
Kalpa
Kalpa
Kalpa
Kalpa
Kalpa
Kalpa
Kalpa

Note:- This is the digital copy of tender for informatory. The original copy of tender is received from concerned department
