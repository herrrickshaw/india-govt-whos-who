---
doc_id: "f1d73bdacd2f843a"
source_url: "https://ayurveda.hp.gov.in/Modification.pdf"
ministry: "Ayurveda Department, Himachal Pradesh"
title: "Modification order in respect of Appointment order of Panchkarma Massures in AYUSH VIBHAG"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "794f71a898089c8e"
---

<!-- page 1 -->

ee “रा
AYUSH VIBHAG,
HIMACHAL PRADESH, SHIMLA-I72009,
कै h
|
3 श >5/20|
| No.Ayu.H(B)(I5)-5/2000(Panchkarma) Dated, eta
| OFFICE ORDER ft
In continuation of this office order of even number 2263]-94 dated
22.09.2023 the place of posting of the following candidates is hereby modified as under:-
[ Sr. No. | No. | Name & Address of the Candidates Station ofposting |
Vijay Singh S/o Sh.Thakur Dass | Regional Ayurvedic Hospital, Shimla
Vill. Jailidhar P.O. Ghaini Tehsil
Suni Distt Shimla Pin Code-7007
02. Kushager Kashyap S/o Sh.S under| Nature Care Unit, Ocl, Una,
| Chand VPO = Janjellj Tehsil
Kumarsian Distt. Shimla |72024
|  videsb Ga
| Himachal Pradesh.
Endst.No. As above. 2964)- 42 dated 23\24\2.3 Shimla-I7009
Copy forwarded to the following for information and further necessary action:~
ql: The Secretary (AYUSH) to the Govt. of H.P., Shimla-2.
2. The District Ayush Officer, Una H.P. with the direction to verify the relevant
documents/certificate at the time of joining.
sh The Medical Superintendent of RAH Shimla.
4. The Incharge of Nature Care Unit, Oel, Una,
5s The BMO/CMO Shimla, & Una H.P.
6. The Individual concerned (By name by Speed/Registered post.)
de Guard file/Personal file.
«
| 0८0 कक
| Himachal Pradesh.
Scanned with CamScanner
