---
doc_id: "eadd17a7d84fb49d"
source_url: "https://www.hpgic.co.in/tenders/Notification..pdf"
ministry: "Himachal Pradesh General Industries Corporation Ltd. (HPGIC), Himachal Pradesh"
title: "Notification Regarding Direct Recruitment"
date: ""
pages: 4
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "8d5df740d074a425"
---

<!-- page 1 -->

7 / re / ae
Government of Himachal Pradesh
Department of Personnel -
Appointment-II
No.Per(AP.B)B(I5)-5/20i4 Dated Shimla-7002,\T-04-207
NOTIFICATION
The Governor of Himachal Pradesh is pleased to
order to discontinue/dispense with the process of holding
interviews in respect of direct recruitment for making
recommendations for Class-III and IV posts/services under the
State Government with immediate effect. The Governor of :
Himachal Pradesh is further pleased to order that the selection to
all Class-II] and IV posts/services under the State Government
shall be made on the basis of merit of written examination or
prescribed educational qualification followed by evaluation, based
on the following parameters:
for Class-II | for Class-IV
posts posts
a soe
i) Weightage for the |2.5 Percentage
minimum educational | (two&a of marks
qualification as per the | half) obtained in .
Recruitment & Promotion qualifying
Rules. examination
{Percentage of marks to be
obtained in the educational calculated
qualification would be out of 85.
multiplied by 0.025. For For
example, an individual has example, 8 }
secured 50% marks in the candidate |
required educational getting 50%
qualifications, he/she will marks in
be allowed ,25 marks (50 Matric
X0.025=2.25)} ' will be |
given 42.5
6, : marks.
| |

<!-- page 2 -->

है ०
ii) | Belonging to notified [ (०७) 3 (०९)
Backward Area or
Panchayat, as the case may
ba .
iii) | Land less family/ family | i (one) 2 (two)
having land less than ॥
Hectare to be certified by
the concerned Revenue
Authority
iv) | Non-employment i (one) 25
Certificate to the effect that (Two &a
none of the family half)
members is in .
Government/Semi
Government.
v) | Differently abled persons |i(one) ~ | i(one)
with more than 40% नि
impairment / disability/
infirmity 5
vi) |NSS (atleast one year)  | (णा९) (one)
certificate holders in NCC /
The Bharat Scout and
Guide. Medal winner in
National level sports
competitions
vii) |BPL family having family | 2 (two) 2.5 (Two &
annual income (from all ahalf)
sources) below % 40,000/-
or as prescribed by the
Govt. from time to time.
|
/single woman. half)
५) 9 है
2 .

<!-- page 3 -->

| वक्त |
| -33 —
IL
x) |Training of atleast 6 | i(one)
months duration related to
the post applied for from a
recognized
University/Institution. :
xi) | Experience upto a |25 2.5
maximum of 5 years in | (twoanda | (twoanda
Govt./semi-Govt. half) half)
organisation relating to the
post applied for (0.5 mark
only for each completed
year).
Pro-rata weightage for more/less than 5% interviews
marks at present will be given accordingly.
as Where skill test and physical test, different from the
personal interview, are the requirement/essentiality of recruitment
process, these tests shall continue and only be of qualifying nature.
3. For already notified vacancies by the recruiting |
authorities prescribing personal interview, which have not been |
completed as yet, either the posts shall be re-advertised to the
extent of dispensing with the personal interview and parameters as है |
above may be adopted OR selection process shall be completed by |
34-05-2047 by the respective recruiting authorities. In case(s) where
advertisement for filling up of vacancies has been issued by the
recruiting agencies but the written examination hasn't been held in ।
such cases, the recruiting agencies will issue supplementary
advertisement immediately clarifying that after written examination
no interview will be held and the above parameters will be applicable
for selection.
3

<!-- page 4 -->

है ee ee — का | धर
/ _
4. For isolated/specific post(s), if any, for which
personal interview is considered absolutely essential, the prior
concurrence of Department of Personnel and Finance Department
shall be obtained.
. By Order
V.C.Pharka
Chief Secretary to the
Government of Himachal Pradesh
No.Per(AP.B)B(i5)-5/204 Dated Shimla-7002, IT -04-20i7
Copy is forwarded for information and necessary action to:
i. The Pr. Secretary to HE Governor, Himachal Pradesh, Shimla-2
2. Pr. PS to Chief Minister, Himachal Pradesh, Shimla-7002
3. Sr. PS to Chief Secretary to the Govt. of Himachal Pradesh. Shimla-
474 002
4. All Administrative Secretaries to the Govt. of Himachal Pradesh.
Shimla-7 002
5. All Heads of Departments in Himachal Pradesh
6, _ All Divisional Commissioners in Himachal Pradesh
7. All the Deputy Commissioners in Himachal Pradesh
8. All the Chairman/Managing Directors / Registrars / Secretaries of
Boards /Corporations /Universities /Autonomous Bodies in
Himachal Pradesh
9. The Secretary, Himachal Pradesh Public Service Commission,
Shimla-2
0. The Secretary, H.P. Staff Selection Commission, Hamirpur-7700
il. The Special Secretary (GAD) to the Government of Himachal
Pradesh, Shimla w.r. to item no. 9 of Council of Ministers meeting
held on 30-03-207.
32. Branch Guard File/ Spare copies - 20 :
४ cod ee,
Under Secretary (Personnel) to the
Government of Himachal Pradesh
Tel. 077-2628499
4
