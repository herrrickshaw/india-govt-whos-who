---
doc_id: "7d9b011beb7bc5fb"
source_url: "https://www.hp.gov.in/hpdmer/file.axd?file=2018%2f6%2fNOTICE+INVITING+EXPRESSION+OF+INTEREST+FOR+OPENING+OF+B.SC.+NURSING+COLLEGE+AND+GENERAL+NURSING+AND+MIDWIFERY+(GNM)+TRAINING+SCHOOLS+AT+TANDA+LOCATION+IN+HIMACHAL+PRADESH..pdf"
ministry: "Directorate of Medical Education & Research, Himachal Pradesh"
title: "NOTICE INVITING EXPRESSION OF INTEREST FOR OPENING OF B.SC. NURSING COLLEGE AND GENERAL NURSING AND MIDWIFERY (GNM) TRAINING SCHOOLS AT TANDA LOCATION IN HIMACHAL PRADESH."
date: ""
pages: 9
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9398f5403c94e6c5"
---

<!-- page 1 -->

GOVERNMENT OF HIMACHAL PRADESH
DEPARTMENT OF MEDICAL EDUCATION & RESERACH,
KASUMPTI SHIMLA-171009
NOTICE INVITING EXPRESSION OF INTEREST FOR OPENING OF B.SC. NURSING COLLEGE
AND GENERAL NURSING AND MIDWIFERY (GNM) TRAINING SCHOOLS IN HIMACHAL
PRADESH.
*****************
The Department of Medical Education and Research, Government of Himachal Pradesh
intends to establish the B.Sc.(Nursing) Colleges and General Nursing and Midwifery (GNM) Schools in Himachal
Pradesh under Public Private Partnership at the following preferred location as per the direction of the Government
letter No. HFW-B(F) 4-8/2016-Loose dated 22.07.2017 :-

Sr. No

Preferred
Location

Name of Course & No. of
Seats

1

Tanda

GNM
60

Name of Govt. Health
Institutions proposed for
attachment

B.Sc (Nursing)
60

Dr. RPGMC, Tanda

Any interested organization under the Central Government, State Government, Local
Body or private of Public Trust, Mission, Voluntary registered under Society Registration Act or a Company
registered under company’s act may submit EOI on the prescribed application form alongwith details of
Documents indicated on application form and also with a Demand Draft amounting to Rs. 50,000/- only for initial
inspection chargeable form each application for each location drawn in favour of Director of Medical Education
& Research, Himcahal Pradesh.
The interested parties may send in their Expression of Interest on or before 20.06.2018
before 5.00 PM at the address given below and the covering envelope containing the EOI should be inscribed
Expression of Interest for opening of Nursing College/Schools at (location to be specified). For any
clarification/details contact: Director Medical Education and Research, Block No. 18-B, SDA Complex
Kasumpti, Shimla-171009, H.P (0177-2620733, 2624895).
The Govt. Notification No. HFW-B(F)4-3/2006 dated 7.06.2008, No. HFW-B(F)43/2009-I dated 14.03.2011, HFW-B(F)4-3/2009-I dated 23.07.2011, No. HFW-B(F)4-3/2006 dated
16.07.2012 containing the details of Govt. Health Insitutions and criteria for evaluation of applications &
documents required with the EOI is available on the website of the department (www.hp.gov.in/hpdmer).
Note: The party/Trust/Society who have already applied for opening of GNM Schools/B.Sc.Nursing College
under preferred location Tanda will also submit fresh proposal alongwith supporting documents.

Sd/Medical Education & Reseerch
Block No. 18-B, SDA Complex
Kasumpti, Shimla-171009, H.P

<!-- page 2 -->

DEPARTMENT OF MEDICAL EDUCATION & RESEARCH,
HIMACHAL PRADESH , KASUMPTI SHIMLA-171009.
-----------APPLICATION FORM FOR OPENING OF GENERAL NURSING AND MIDWIFERY SCHOOL AND B.Sc NURSING, COLLEGE FOR GRANT OF
NO OBJECTION CERTIFICATE BY THE STATE GOVERNMENT (FOR ANNUAL ADMISSION CAPACITY OF 40-60 STUDENTS EACH
RESPECTIVELY ) FOR THE YEAR.
1.

(a) Name of the Trust / Society / Organization __________________________________

(b) Whether registered or not

___________________________________

(c) Date of registration ___________________________________
2.

Course applied for________________________________________________________

3.

Annual Intake Capacity applied for___________________________________________

4.

Location of Proposed School ________________________________________________
(with complete Address) ____________________________________________________
____________________________________________________

5.

Net Worth of the Application (Minimum 40 Lakh for ANM School__________________
(Minimum 50 Lakh for GNM School__________________
(Minimum 1 core for B.Sc Nursing ___________________

6.

Land Area: ___________________________________________

<!-- page 3 -->

Sr.
No
.
1.

a) PHYSICAL FACILITES REQUIRED:
Particulars

INC Norms(area in Sq.ft.)
B.Sc
54,470 Sq. ft.

PBB.Sc

Available with Applicant

ANM
Total
Built
up 25685 Sq. ft.
area(40-60 Students)
(i) Constructed Area 10060 Sq. ft.
for teaching block
a)Lecturer Hall
2@1080Sq.ft
2160
b)Fundamental
of 1500Sq.ft.
nursing

GNM
37,500 Sq. ft

M.Sc

3@900=
2700 Sq,ft
1500 Sq. ft

4@1080 Sq.ft.
4320 Sq. ft
1500 Sq. ft

2@1080 Sq.ft. 2@1080 Sq.ft.
2160 Sq. ft.
2160 Sq. ft.
--------------

c) Advance Nursing -------------Skill Lab

900 Sq.ft

. -------------

--------------

d)CHN

---------------

900 Sq. ft

900 Sq. ft.

--------------

e) Nutrition

900 Sq. ft.

900 Sq. ft.

900 Sq. ft.

--------------

f) OBG & Pediatrics ------------Lab

900 Sq. ft.

900 Sq. ft

--------------

g) Pre-clinical Science ------------Lab.
h) Computer Lab
i) Multipurpose Hall
1500Sq. ft.

900 Sq. ft.

900 Sq. ft

--------------

1500 Sq . ft.
3000 Sq. ft.

1500 Sq . ft.
3000 Sq. ft.

---------------------------

j) Common Room

----------

1100 Sq. ft

1100 Sq. ft.

--------------

k) Staff Room

500 Sq.ft.

1000 Sq. ft

1000 Sq. ft.

--------------

ANM GNM

B.Sc

Future
Provision
PB B.Sc

M.Sc

20,000 Sq. ft. 23,720 Sq. ft.

Note: - For Post Basic B.Sc and M.Sc Nursing courses area will remain same as B.Sc Nursing, but additional two classrooms for Post Basic and two classrooms for M.Sc Nursing are required.
Labs can be shared for all nursing programme.

Remarks

<!-- page 4 -->

2.

l)Principal Room

--------------

300 Sq. ft.

300 Sq. ft.

--------------

m) Vice- Principal

------------

200 Sq. ft

200 Sq. ft.

--------------

n) Library & Study

1200 Sq. ft.

2,400 Sq. ft

2,400 Sq. ft.

--------------

o) A.V. Aids Room

600 Sq. ft.

600 Sq. ft

600 Sq. ft.

--------------

Sq. 800 Sq. ft.

--------------

p) One room for each --------HOD

800
ft.each

q) Faculty Room
r) Provision for toilets

2,400 Sq. ft.
1,000 Sq. ft

2,400 Sq. ft.
1,000 Sq. ft.

---------------------------

17,500 Sq.ft

30,750 Sq. ft

30,750 Sq. ft

1200 Sq.ft
500 Sq. ft.

(ii) Constructed Area 15625 Sq. ft
for hostel block
a)Single Room
-------------b)Double Room
12000 Sq. ft

9,000 Sq. ft. 24,000 Sq. ft.
24,000 Sq. ft.
9000 (50 sq.
ft. for each
student)
c) Sanitary (One latrine 500 Sq. ft
1800 Sq. ft
500 Sq. ft
500 Sq. ft
& one bathroom for 5
One latrine &
students)
One Bath room
(for
60
students) – 600
× 3 = 1800
d) Visitor Room
250 Sq. ft
500 Sq. ft
500 Sq. ft
500 Sq. ft
e) reading Room
125 Sq. ft
250 Sq. ft
250 Sq. ft
250 Sq. ft
f) Store Room
250 Sq. ft
500 Sq. ft
500 Sq. ft
500 Sq. ft
g) Re-creation Room
250 Sq. ft
500 Sq. ft
500 Sq. ft
500 Sq. ft
h) Dining Hall
1500 Sq. ft
3,000 Sq. ft
3,000 Sq. ft
3,000 Sq. ft
i)Kitchen & Store
750 Sq. ft
1,500 Sq. ft 1,500 Sq. ft
1,500 Sq. ft
j)Warden’s room
-------------450 Sq.ft
Note: - Hostel area for Post Basic B.Sc N and M.Sc Nursing course will remain same as B.Sc Nursing course but additional hostel rooms to accommodate nursing students are required
as 50 Sq. ft carpet area for each student. Sr. NO. 2 part (c,d, e, f, g, h, i, can be shared.

<!-- page 5 -->

a) OFFICE REQUREMENT/ OTHER FACILITIES
Sr.
No.
1.

Particulars

2.

Vice-Principal’s office

3.

Faculty Members

4.
5.
6.

Record Room
Common Rooms
Others facilities

7.
8.
9.

Garage
Fire Extinguishers
Playground

Principal’s office

INC Norms
ANM
GNM
B.Sc
PB B.Sc
M.Sc
Separate Office with attach toilet at provision for visitors room independent telephone and intercom facilities
connected with hospital and hostel
Separate Office with attach toilet at provision for visitors room independent telephone and intercom
facilities connected with hospital and hostel
Adequate number of office Adequate number of office rooms in proportion to the number of
rooms in proportion to the teaching faculty. One office room should accommodate 2 teachers
number of teaching faculty.
only. Separate toilet facility should be provided for the teaching
One office room should faculty with hand washing facility. There should be a separate toilet
accommodate 2 teachers only. for male teachers. The size of the room should be 200 sqr. ft.
Separate toilet facility should Separate chambers for heads of the department should be there.
be provided for the
teaching faculty with hand
washing
facility.
There
should be a separate toilet for
male teachers.
1
1
1
1
1
Minimum of 3 common rooms
Safe drinking water adequate sanitary/ toilet Students’ welfare hall of size 400 sqr.
facilities, separately for male and female
ft. Indoor games hall of size 4000 ft.
Safe drinking water and adequate
sanitary/toilet facilities should be
available for both men and women
separately in the college in each floor
common toilets for teachers (separate
for male and female) i.e 4 toilets with
Wash basins. Common toilets for
students (separate for male and female)
12 with Wash Basins for 60 students.

Available
Applicant

with Future
Provision

Remarks

<!-- page 6 -->

(C ) (i) CLINICAL FACILITES
Sr. Particulars
No.
1.

2.

Hospital

ANM

GNM

Parent
hospital
/Distt.
Hospital
having
150 Beded
occupancy
60%
to
70%

Parent
hospital
having
minimum
200
functional
beds
having
75%
occupancy

INC Norms
B.Sc
PBB.Sc

M.Sc

Parent
hospital
having
minimum
300
functional
beds having
75%
occupancy

Parent
Govt. Hospitals
hospital
Name of No.
having
Hospitals
Beds
minimum
300
functional
beds having
75%
occupancy.

3.
4.

Distribution of Beds
-Medical
30
45
30
30
-Surgical
30
45
30
30
-OBG
30-50
45
30
30
-Paediatrics
30-50
30
20
20
-Orthopaedics
10
15
10
10
-Eye/ENT
20
-Cardio thoracic
-Critical Care
-Neurospeciality
-Oncology speciality
-OrthopaedicSpeciality
-Psychiatric
50
-Gastroentrology
-Nephro-Urology speciality
Students Patients ratio 1:3
The size of the hospital/ Nursing home for affiliation should not be less than 50 beds.

(C)

(ii)

DETAILS

OF

THE

DISTANCE

&

BED

STRENGTH

Available with Applicant

Future
Provision

Remarks

Private Hospitals
of Name
Hospitals

of No.
Beds

of

TO

PROPOSESD

50
50-100
250-500
50-100
250-500
50
100
250-500
50
50-100
50-100

OF

THE

HOSPITALS

THE

INSTITUTION

_____________________________________________________________________________________________________________________________________________
______________________________________________________________________________________________________________________________________________

<!-- page 7 -->

(d) HOSTEL FACILITIES
Sr.
Particulars
No.
1.
Main Hostel
2.
Hostel Room
3.
Toilet and Bathroom
4.
Re-creation
5.
Visitor’s Room
6.

Kitchen & Dining Hall

7.

Pantry

8.
9.
10.
11.
12.

Washing & ironing Room
Seek Room
Room for night duty nurses
Guest Room
Warden’s Room

13.

Canteen

14.

Transport

INC Norms
Separate hostel for male and female students
One room for 2 students with furniture
Toilet and bathroom facilities should be provided on each floor of the students hostel
There should be facilities for indoor and outdoor games
There should be a visitor room in the hostel with comfortable seating, lighting and toilet
facilities.
There should be a hygienic kitchen and dining hall to seat at least 80% of the total students
strength at one time
with adequate tables, chairs, water coolers, refrigerators and heating facilities. Hand washing
facilities must be
provided.
One pantry on each floor should be provided. It should have water cooler and heating
arrangements
Facility for drying and ironing clothes should be provided in each floor

Warden should be provided with a separate office room besides her residential accommodation.
Intercom facility with school & hospital shall be provided.
There should be provision for a canteen for the students, their guests, and all other staff
members.
School should have separate transport facility under the control of the Principal. 25 and 50 seats
bus is preferable and number of transport shall be as per students strength.

e) RESIDENTIAL ACCOMMODATION:
f) CRECH (Give Details)
g)STAFF FOR HOSTEL (Give Details)

Available
Applicant

with Future
Provision

Remarks

<!-- page 8 -->

h) TEACHING FACULTY FOR AN ANNUAL INTAKE OF 40-60 STUDENTS AS PER QUALIFICATION PRESCRIBED BY INC:
Sr.
No.
1.
2.
3.
4.
5.
6.
7.
8.

Particulars
Principal
Vice
Principal
Professor
Associate
Professor
Assistant
Professor
Lecturer
Tutor

ANM
1
-

GNM
1
1

-

B.Sc
1
1

INC Norms
PB B.Sc
1
1

Available with Applicant
M.Sc
-

0

1

-

0 (40-60)1 (61-100)
2

2

1

-

3

3

4

16

10-18 (40-60)19-28 (61-100)
Non-teaching staff as per INC norms

10-18 (40-60)2-10 (61-100)

Future
Provision

Remarks

2
-

Note: - Student Teacher ratio 1:10

Declaration:I ________________________________hereby certified that, supported document attached by me and the above information is correct & true
best of my knowledge.

Signature
Name of Applicant:Address:Contact No:-

<!-- page 9 -->

1.

LIST OF DOCUMENTS REQUIRED TO BE ATTACHED;
1. Copy of Registration / Incorporation Certificate in case of Institutions.
2. Memorandum of Association.
3. Certificate regarding net Worth (Rs 40.00 Lakh for ANM Course, Rs 50.00 Lakh for
GNM & Rs 100.00 Lakh for B.Sc Nursing).
4. Balance sheet and Audited Financial Statements (last three years ending.31 th March).
5. Inspection
Fee
(Demand
Draft
No.
_____________________
dated
_________________) i.e Rupees Fifty Thousand Only in favour of Director, Medical
Education & Research, H.P Shimla-9 which is Non-Refundable.
6. The details of Land area available with Society or its members along with documentary
proof.
7. The details of building for teaching and hostel block along with constructed area
available.i.e. 25,500 sq.ft for ANM, 37,500 sq.ft for GNM and 54,470 sq.ft. for B.Sc
Nursing (Copy of Blueprint & Revenue Record with Map).
8. The details of proposed Multispecialty Private Hospital along with bed strength and
clinical facilities available (Copy of affidavit on Stamp Paper duly signed by the 1 st Class
Magistrate).
9. Details of Nursing teaching faculties etc. available (Copy of Undertaking required)
10. Financial liability of applicant society for running such courses.
11. Detailed
guidelines
are
available
in
www.indiannursingcouncil.co.in
&
http://www.indiannursingcouncil.org/nursing-programs.asp?show=guide
and
www.hp.gov.in/hpdmer.

Signature of the Applicant with Seal
