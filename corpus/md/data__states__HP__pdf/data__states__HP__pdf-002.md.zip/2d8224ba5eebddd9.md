---
doc_id: "2d8224ba5eebddd9"
source_url: "https://www.hptax.gov.in/public/notifications/17823727846a3cd9b0c6272.pdf"
ministry: "Excise and Taxation Department, Himachal Pradesh"
title: ":: Public Notice regarding e-Action for Re-Allotment of Retail Excise Vends L-2 Sarkaghat Near Hosital Road L-2 Sarkaghat L-14 Paplog & L-14 Sadhot of Distt Mandi for the Remaining Period of the Financial Year 2026-27 ending on 31/03/2027"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "abeae83129e74d4f"
---

<!-- page 1 -->

श ~ PUBLIC NOTICE
GOVERNMENT OF HIMACHAL PRADESH
DEPARTMENT OF STATE TAXES AND EXCISE
e-AUCTION FOR RE-ALLOTMENT OF RETAIL EXCISE VENDS L-2 SARKAGHAT(NEAR HOSPITAL ROAD),
L-2 SARKAGHAT, L-4 PAPLOG, & L-4 SADHOT OF DISTRICT MANDI FOR THE REMAINING PERIOD
OF THE FINANCIAL YEAR 2026-27 ENDING ON 3.03.2027
In compliance to the Order No.EXN-CZ-Excise-406 dated 24-06-2026 and letter No. EXN-CZ-

Excise-408 dated 24-06-2026 the e-auction for re-allotment of retail Excise Vends L-2 Sarkaghat

(Near Hospital road), L-2 Sarkaghat, L-4 Paplog, & L-4 Sadhot of District Mandi H.P are invited for

the remaining period of the financial year 2026-27 ending on 3.03.2027. The date and time of e-

auction for re-allotment of above said retail liquor vends are mentioned below:-

i e-Auction Date &Time
Publishing | Document/ | Document/ | Approval Approval Auction Auction End
Date & Application | Application | (Scrutiny) (Scrutiny) Start Date Date & Time
Time submission | submission | Start Date | End Date & | & Time
| Pm
&Time Time
27.06.2026 | 27.06.2026 | 27.06.2026 | 27.06.2026 | 27.06.2026 | 27.06.2026

iL The process of auction shall also be executed through online mode (e-Auction). The link of e-
Auction portal has been provided on the official website of the Department of State Taxes & |
Excise, Himachal Pradesh (www.hptax.gov.in) and e-governance portal for excise function
(https://egovef.hptax.gov.in/). The e-Auction portal can also be directly accessed using link:
https://eauction.gov.in/ngauction.

2. The e-Auction of the Retail Liquor Units shall be governed by the provisions of the H.P.
Excise Policy for the financial year 2026-27 and such terms & conditions as have been
notified by the Commissioner of State Taxes & Excise, Himachal Pradesh.

3. The detailed terms & conditions of e-Auction of the Retail Liquor Units/Vends are available
in the H.P. Excise Policy for the financial year 2026-27 and the official website of the
Department of State Taxes & Excise, Himachal Pradesh (www.hptax.gov.in). All intending
bidders are advised to go through the same thoroughly before submitting the bids.

4. All details regarding the Retail Liquor (Excise) Units/Vends and other connected details are
available with the office of Dy. Commissioner of State Taxes & Excise, Mandi, District
Mandi (Contact No. 0905- 22286) The H.P. Excise Policy for the financial year 2026-27 is
available on the official website of the Department of State Taxes & Excise, Himachal Pradesh
(www.hptax.gov.in).

5. The e-Auction process will be subject to approval by the Commissioner of State Taxes &
Excise, Himachal Pradesh, who reserves the right to reject the same without assigning any
reason.

6. The date & time are liable to be changed by the Commissioner of State Taxes & Excise,
Himachal Pradesh, without assigning any reasons.

Ts Applicants may deposit the required amount in advance into their top-up account using the
“Auction Top-Up payment option available on the e-Auction portal. At the time of
submitting the application, he/she may utilize the deposited top-up balance for making the
necessary payments

8. Applicants are advised to regularly visit www.hptax.gov.in for updates, notices, Excise Policy
2026-27, Standard Operation Procedure (SOP) and further instructions.

sorte
, Distt. Panic ae, कि
० ७ अनि पकल a नी ननननननन>+++..

<!-- page 2 -->

१
Endst. No. EXN-MND-Excise-Unit 47(/)-2026-27- 2८५९ - 2 6 ८8 ००९: 95-०८-१०३१८
Copy forwarded for information and necessary action to:

, The Principal Secretary (ST&E) to the Government of Himachal Pradesh, Shimla- for
information, please.

2. The Commissioner, State Taxes & Excise, Himachal Pradesh for information please.

3. The Director, Department of information and Public relations, H.P Shimla-2. It is requested
that publicity be given to the e-auction process by publishing the aforesaid programme in the
following newspapers (Hindi & English) having wider circulation for one day only.

a. The Indian Express (English)
b. Punjab Kesari ( Hindi)
4. The Jt. Commissioner of State Taxes & Excise, (Admin.), H.P.
5. The Addl. /Jt. Commissioner of State Taxes & Excise (SZ/CZ/NZ) Shimla/-Mandi/ Palampur,
Himachal Pradesh.
6. The Addl. Commissioner of State Taxes & Excise (GST) Himachal Pradesh.
7. The Addl. Commissioner of State Taxes & Excise (D) Himachal Pradesh.
8. The Addl. Commissioner of State Taxes & Excise (IT) Himachal Pradesh with the request to
upload the Public Notice on the website of the department.
9. The Joint Commissioner of State Taxes & Excise, GST Zone (SZ/NZ/CZ) Parwanoo / Palampur
and Una, Himachal Pradesh.
0. The Dy. Commissioner of State Taxes & Excise, I/C District Shimla / Solan / BBN Baddi / Sirmour
/ Bilaspur / Hamirpur / Kullu / Kangra / Nurpur/ Una & Chamba, Himachal Pradesh.
l. The Asstt. Commissioner of State Taxes & Excise I/c Distt. Kinnaur at Reckong Peo, H.P.
2. Copy to Notice Board of this office.
De onset eeeBnreeneon
neshar eR Sve Mana H.-P
| |
