---
doc_id: "3d2dddf93fec9f70"
source_url: "https://rggec.ac.in/wp-content/uploads/2026/09/Corrigendum-II-Gym-Tender.pdf"
ministry: "Rajiv Gandhi Government Engineering College (RGGEC), Kangra, Himachal Prades"
title: "Corrigendum-II (Gym Tender) Dated 08/09/2026"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "82b42c1cb112151d"
---

<!-- page 1 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM
EQUIPMENT AT RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

CORRIGENDUM-II
Tender Reference No.: RGGEC/NGB/STORE/GYM/TENDER/2026

Tender Title: Supply, Installation and Commissioning of Indoor Gym Equipment at RGGEC,
Kangra at Nagrota Bagwan (H.P.)
Subject: Clarification regarding Display/Console Features of Item Nos. 1, 2 & 3 and
Extension of Last Date for Submission of Bids.
In continuation of the above-mentioned tender, the following clarification/amendment is
hereby issued:
1. Clarification regarding Display/Console Features – Item Nos. 1, 2 & 3
The following provision shall be read against Item Nos. 1 (Treadmill), 2 (Elliptical Trainer) and
3 (Gym Bike):
“Display/console may additionally provide Body Fat %, BMI, BMR and Body Type, wherever
available. These shall be treated as additional/desirable features and shall not be mandatory for
technical compliance.”
Accordingly, non-availability of the above-mentioned features in above mentioned items shall not
render the offered equipment technically non-compliant, provided that all other mandatory
technical specifications and requirements stipulated in the tender are duly complied with.
2. Extension of Last Date for Submission of Bids
The last date and time for submission of bids, as specified in the tender document, is hereby
extended up to 18.09.2026 at 01:00 PM.
All other terms, conditions and technical specifications of the tender shall remain unchanged.
This corrigendum shall form an integral part of the tender document.

Sd/Director-cum-Principal
Rajiv Gandhi Govt. Engg. College
Kangra at Nagrota Bagwan, H.P.
