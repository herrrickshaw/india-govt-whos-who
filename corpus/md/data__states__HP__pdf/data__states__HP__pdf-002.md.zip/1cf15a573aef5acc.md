---
doc_id: "1cf15a573aef5acc"
source_url: "https://ddtg.hp.gov.in/wp-content/uploads/2025/12/Condemnation-Policy-Himachal-Pradesh-30-1.pdf"
ministry: "Digital Technologies and Governance Department, Himachal Pradesh"
title: "Policy & Guidelines for Condemnation of Obsolete/ Unusable IT/ Electronic Equipment of Himachal Pradesh"
date: ""
pages: 9
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "cac24ed038d6e4a3"
---

<!-- page 1 -->

एछा-6044/2/2020- 586॥04-6007 ॥665944/2025
Department of Digital Technologies & Governance
Government of Himachal Pradesh
Perry
No. DIT-F0/2/2020-IT SECTION-GoHP (E-7304)—20 Dated: st haugust, 2025
NOTIFICATION
Subject:- Policy & Guidelines for Condemnation of Obsolete/ Unusable IT/Electronic
Equipment of Himachal Pradesh.

Various Government Departments, Boards, Corporations, Organizations, and other
bodies under the Government of Himachal Pradesh frequently refer matters related to the
declaration of unserviceable electronic/IT equipment and subsidiary items as obsolete to this
Department, recognizing it as the Nodal Department for IT and Electronics. However, in the
absence of a defined Policy in this regard, the Department of Digital Technologies and Governance
has not been in a position to provide a standard document or procedure for declaring IT/Electronic
items as obsolete and unserviceable.

To address this gap, a Committee of Experts was constituted by the Department of
Digital Technologies and Governance, to examine and determine the recommended lifespan of
various categories of IT/Electronic equipment used across Government Departments, Boards,
Corporations, and Organizations. This includes peripherals and subsidiary equipment such as
servers, storage devices, routers, switches, desktops, printers, UPS systems, etc.

Based on the committee’s recommendations and the observations above, the
policy/guidelines for the condemnation of Obsolete/ Unusable IT/ Electronic equipment have been ~
formulated and are hereby notified at Annexure A. These guidelines shall be applicable to all
Government Departments, Boards, Corporations, and Organizations under the Government of
Himachal Pradesh, all Autonomous Bodies, Local Bodies and all Public Sector Undertakings
(PSUs) under the Government of Himachal Pradesh.

This issue with the approval of Government of Himachal Pradesh.

=<
--By Order--
4 Secretary (DT&G) to the
; — Government of Himachal Pradesh.
——

<!-- page 2 -->

एछा-+704॥/2/2020+ा 586॥03-60/7 66594/2025
Endst. No. As above Dated: Ms ugust, 2025
Copy for information to:- ‘
I. All the Administrative Secretaries to the Government of Himachal Pradesh
2. All the Head of the Departments to the Government of Himachal Pradesh
3. All the Divisional Commissioners, Himachal Pradesh
4. All the Deputy Commissioners, Himachal Pradesh
5. All the Managing Director/Chairman, a if Himachal
Pradesh.
>
a aes
ay ५१२४६
(Dr. Nipun \findal, TAS)
Director,
Department of Digital Technologies & Governance,
Himachal Pradesh
2

<!-- page 3 -->

एछा-7044/2/2020- 5६6॥03-50#7 66594/2025
La NS Vb;
Waa रे न 5
Ce 2 बस
—
RS 7"... ्ाधााबाधाा
GB ferec ven सरकार नाना
ANNEXURE A
Policy & Guidelines
For .
Condemnation of Obsolete/ Unusable IT/ Electronic Equipment
In Himachal Pradesh
Department of Digital Technologies and Governance,
Government of Himachal Pradesh,
IT Bhawan, Mehli, Shimla 703
Tel: 0477-262 894
EMAIL: - dirit-hp@nic.in “2
S
ea
3

<!-- page 4 -->

DIT-F0/2/2020-IT SECTION-GoHP /665974/2025
Contents
4. INTRODUCTION .......sccccssssecsssssssseeessesnssssssssseeeseuuusssssssssssessiuessisssessseeseneessssssees 5
2. ICT PRODUCTS/EQUIPMENT........::.cccccsssssscscssssscsssesssssssssssssssssssssssssstssnssssisssstsssssssees 5
3. CLASSIFICATION OF ICT EQUIPMENT AND LIFESPAN............sssssssssssssssssssses 6
4. MODE AND PROCEDURE OF CONDEMNATION .............cssssssssssssssesssesssseseseseeseee 7
5. DATA SECURITY AND SANITIZATION REQUIREMENTS PRIOR TO
DISPOSAL .0.....ecsscssscssssssssssesssesensensssseeeesestnnnnsnnseeeeesssiiunssssseeeeessesssiussssseeeseeseeeesnes 8
2.
6
—\
4

<!-- page 5 -->

छा-704॥/22020-7 566॥03-509#7 W66594/2025

4. INTRODUCTION

While there has been increasing growth of ICT infrastructure in all Government
Departments and greater reliance on ICT for office automation in the daily functioning

of Government offices, there has also been a rising number of ICT
products/equipment in Government offices across the State that are either becoming
non-repairable, beyond economical repair, or technologically obsolete.

This policy applies to the condemnation of obsolete, e-waste, and unusable IT and ,
electronic equipment by Himachal Pradesh State Government Departments and
ensures that an appropriate level of discipline and compliance with legal or policy
requirements is applied across the State.

These guidelines are applicable to:

a) All Government Departments under the Government of Himachal Pradesh

b) All Autonomous Bodies/Local Bodies under the Government of Himachal

Pradesh

c) All PSUs under the Government of Himachal Pradesh

2. ICT PRODUCTS/EQUIPMENT

ICT Products/Equipment includes the following items:

a) Personal Computers .
b) Servers

c) Laptops :

d) Printers

e) Scanners

f) UPSs

g) Data Communication Equipment

h) Dumb Terminals

s_ i) Package Software
py
‘\
ee

<!-- page 6 -->

एा-7044/2/2020-ा 58603-5007? /665974/2025
j) Photocopier/Xerox Machines
k) Network Equipment
!) Handheld/Portable Devices
m) Other Electronic Items
हैं The above list is not exhaustive and is subject to the interpretation/approval of the
concerned Department.
3. CLASSIFICATION OF ICT EQUIPMENT AND LIFESPAN
A number of unusable, irreparable, or redundant IT and electronic equipment are
lying in the stores of various Government Departments of Himachal Pradesh, on
account of outdated technology and non-usability. These items may either already
be obsolete or on the verge of obsolescence and, hence, being part of electronic
waste, need to be declared obsolete.
In this context, the Ministry of Electronics & Information Technology (MeitY),
Government of India, vide DO No. 7()/2022-CSD dated 8.0.2022, has also
pointed out that the use of out-of-date operating systems and IT equipment must be
discontinued as it makes sensitive government IT systems susceptible to
. cyberattacks.
Depending upon the nature, intensity of usage, maintenance cost, serviceability,
technological obsolescence, and _ technological upgrades, the ICT
products/Equipment are classified into the following categories for the purpose of
condemnation:
Category Items Life for Disposal /
ae End of Life
e Printing Consumables
|. Immediate (Ink, Toners, Cartridges) No residual value
Obsolescence / * DVDs, CDs, Floppies determined. However,
Use-and-Throw e UPS Batteries proper inventories of
Products ~ Digital Audio Tapes (DAT) aaa issue ry
+ Linear Tape OpeniL TO} Condemnation tate.
would be maintained in
< order to keep an
2 accounting system.
. 6
ee
"|

<!-- page 7 -->

छा-7044/2/2020-ा 5६670003-60#7 ॥665944/2025
e Laptops, Notebooks,
Il. Fast Ultrabooks, Tablets, 5 Years
Obsolescence / Phablets, Chromebooks,
Low Life Notepads, Convertibles
Products * Mobile Phones
e Pen Drives
e External HDDs
है e Servers, Desktops
Il. Medium e Printers, Scanners, 7 Years
Obsolescence / Copiers ¢
Medium Life ° MFDs
Products ¢ Typewriters
e Cameras
e Projectors
e VC Setups
e UPS
e Networking items
e FAX, EPABX
IV. Slow ¢ Attendance Systems 0 years .
Obsolescence / ¢ Cameras, DVD Players
oe Life * TVs (LCD/LED)
roducts e Other Electronics
3.4 The table describes only the average life of the equipment; however, all
items (except those under Category |) can be used beyond the specified
lifespan as long as they continue to serve their intended purpose. The
above lifespans are indicative. Equipment may be used beyond these
periods if they remain functional and meet operational requirements. .
3.2 IT Hardware and Electronics items that have been damaged beyond repair
due to fire or any other reason beyond human control can also be termed
as Physically damaged and thus declared as obsolete.
3.3 Upon completion of the productive life period, items may be replaced with
equipment of the latest configurations, if required. हि
4. MODE AND PROCEDURE OF CONDEMNATION
4./ All concerned Departments, Autonomous Bodies/Local Bodies, and PSUs
under the Government of Himachal Pradesh wishing to dispose of ICT-
—s हे
a ह

<!-- page 8 -->

DIT-F0/2/2020-IT SECTION-GoHP /665974/2025
related products/equipment shall constitute a committee as per Rule-45
for the Disposal of Goods, as per HPFR 2009 or as amended from time to
time.

4.2 The committee shall assess equipment based on physical condition and’
functionality, repair and maintenance history, technological obsolescence,

है cost-effectiveness of repairs, security risks associated with outdated
systems and hold detailed deliberations on the Equipment details (make,
model, serial number), date of procurement and usage history and
undertake condemnation only after detailed justification.

4.3 The disposal of condemned items shall be carried out only through the
registered and authorized e-waste recyclers by the Pollution Control Board
or their authorized collection centres through the process of auction as
prescribed in HPFR and other Government instructions.

5. DATA SECURITY AND SANITIZATION REQUIREMENTS PRIOR TO
DISPOSAL

Below are the detailed instructions and requirements to ensure no data retention on

the devices/ eWaste / Unusable IT & Electronics equipment, before disposal:

: a) Ensure backup of all necessary data from the device/storage and validate the

integrity of the backup.

b) Remove any configurations or software specific to the organization's operations
from servers/storage and network devices.

c) Wipe all data and configurations on the device using industry-standard data
destruction methods.

d) Use reputable data destruction software, ensuring the software is configured to
perform multiple passes of data wiping.

e) Store the data in a secure environment until the data wiping process is completed.

f) If software-based wiping is insufficient or not feasible, perform physical
destruction of the hard drives.

g) Follow environmental and safety guidelines for hardware destruction.

hi
> 8

<!-- page 9 -->

एछा-+704॥/22020-+ 5६6003-60#7 ॥665944/2025
h) After the data wiping process, conduct a thorough verification to ensure that all
data and configurations have been securely wiped.
Sz
a Mf Jeo कक
9
