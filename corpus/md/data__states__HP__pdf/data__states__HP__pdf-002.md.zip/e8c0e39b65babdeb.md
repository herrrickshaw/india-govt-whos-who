---
doc_id: "e8c0e39b65babdeb"
source_url: "https://hpbiodiversity.gov.in/BMC/PBR%20Guidelines.pdf"
ministry: "Himachal Pradesh State Biodiversity Board, Himachal Pradesh"
title: "Guidelines for PBR"
date: ""
pages: 64
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e74108c270d56940"
---

<!-- page 1 -->

<!-- page 2 -->

People’s Biodiversity Register

Revised PBR Guidelines 2013
(Based on the guidelines issued by NBA in 2009)

National Biodiversity Authority

5th Floor, TICEL Bio Park, Taramani,
Chennai 600 113, Tamil Nadu,

<!-- page 3 -->

NBA/PBR/02

-

PBR Guidelines, 2009
Revised Guidelines, 2013

National Biodiversity Authority
5th Floor, TICEL Bio Park, Taramani,
Chennai 600 113, Tamil Nadu,
Tel: 91-044-2254 1075 / 2254 2777
Fax: 91-044-2254 1200
Email: secretary@nbaindia.in
www.nbaindia.org

2

<!-- page 4 -->

Part I
1.0

The Biological Diversity Act, 2002 & Rules, 2004

The Biological Diversity Act, 2002 (No. 18 of 2003) was notified by the Government of India on 5th
February, 2003. The Act extends to the whole of India and reaffirms the sovereign rights of the country
over its biological resources. Subsequently the Government of India published Biological Diversity Rules,
2004 (15th April, 2004). The Rules under section 22 states that ‘every local body shall constitute a
Biodiversity Management Committee (BMC’s) within its area of jurisdiction’.
2.0

People’s Biodiversity Registers and the role of the Biodiversity Management Committee

The mandate of the Biodiversity Management Committee has been clearly highlighted in the
Biological Diversity Rules 2002 as follows:
•

The main function of the BMC is to prepare People’s Biodiversity Register in consultation with the local
people. The Register shall contain comprehensive information on availability and knowledge of local
biological resources, their medicinal or any other use.

•

The other functions of the BMC are to advice on any matter referred to it by the State Biodiversity
Board or Authority for granting approval, to maintain data about the local vaids and practitioners using
the biological resources.

•

The Authority shall take steps to specify the form of the People’s Biodiversity Registers, and the
particulars it shall contain and the format for electronic database.

•

The Authority and the State Biodiversity Boards shall provide guidance and technical support to the
Biodiversity Management Committees for preparing People’s Biodiversity Registers.

•

The People’s Biodiversity Registers shall be maintained and validated by the Biodiversity Management
Committees.

3.0

People’s Biodiversity Registers and the role of National Biodiversity Authority (NBA)

The National Biodiversity Authority shall provide guidance and technical support to the Biodiversity
Management Committee (BMC) for preparing People’s Biodiversity Register.

3

<!-- page 5 -->

People’s Biodiversity Registers and the role of State Biodiversity Board (SBB)
The State Biodiversity Board (SBB) would provide necessary training to the Technical Support Group
(TSG) of the district and enable smooth functioning and aid in networking for creation and maintenance of
People’s Biodiversity Registers (PBRs).
People’s Biodiversity Registers and Role of the Technical Support Group (TSG)
The Technical Support Group (TSG) will consist of experts from various disciplines and line departments,
universities, research institutes, colleges and schools and non-governmental organizations. The Technical
Support Group will provide technical inputs and advice to the BMCs on identification of plants and animals,
monitor and evaluate the PBR exercise, examine confidential information and advice on legal protection,
maintain a database of local and external experts on biodiversity
4.0

People’s Biodiversity Registers (PBR)

The evolution of human societies over several millennia is closely related to plants and animals. The
domestication of crop plants and farm animals about 12000 years ago revolutionized the human civilization
by creating more stabilized societies. The early historic and medieval period gradually reduced human
interaction with the wild plants and animals. The development of modern science and technologies during
the industrial and post-industrial period did not do away with our link to nature. Different groups of people
continue to depend on natural resources at varying scales. Some draw resources from across continents
while others within a country or a region. There are also people continue to depend on locally available
biodiversity and bio-resources for their livelihoods. Such population who are directly dependent on local
biological resources have, through their keen sense of observation, practices, and experimentation
developed and established a body of knowledge that is passed on from generation to generation. Some are
widespread traditional knowledge like cultivation practices; others are highly specialized such as bone
setting or jaundice, which are generally passed only to close members of the family.
India is land of biological and cultural diversity. It is one of the mega biodiverse countries of the world. It
also the home of a large number of tribal groups, pursuing different kinds of nature based livelihoods. In
addition, a large number of farming and fishing communities and nomadic groups posses traditional
knowledge of varying degrees. The development of modern science and technologies notably
biotechnology and information technologies have increased the value of biodiversity and associated
knowledge including traditional knowledge (TK) .The growing importance of biodiversity, bio-resources and
4

<!-- page 6 -->

associated knowledge is fairly well understood. The first step towards conservation is sustainable utilization
of biodiversity and its documentation. Biodiversity and associated knowledge is found in different
ecosystems, under different legal management regimes and hence the results and manner of
documentation will also differ.
The present manual guidelines have drafted taking into consideration different ecosystems and include the
rural, urban and protected areas. The guidelines may be customized and further information may be added
to enrich the effort. It is important to keep in mind some of the issues related to PBRs:
•

It is to be undertaken in a participatory mode involving varying sections of village society.

•

While documenting, the knowledge and views of both genders are to be recorded.

•

Information provided by people need to be collated, analysed and crosschecked by the members of
the Technical Support Group (TSG) before documentation.

•

The PBR is important base document in the legal arena as evidence of prior knowledge and hence
careful documentation is necessary.

•

The document should be endorsed by the BMC and later publicized in the Gram Sabha / Gram
Panchayat / Panchayat Samiti.

The document can be a very useful tool in the management and

sustainable use of bioresources. The document can also be a very useful teaching tool for teaching
environmental studies at schools, colleges and university level
•

The document should be periodically updated with additional and new information as and when
generated.

4.1

The PBR Process

The preparation of People’s Biodiversity Registers (PBRs) involves the active support and cooperation of a
large number of people who need to share their common as well as specialized knowledge. One of the first
steps for preparing a PBR is to organize a group meeting to explain the objectives and purpose of the
exercise. Different social groups in the village need to be identified for purpose of data collection from those
groups. In an urban situation, spots where biodiversity are important need to be identified for the purpose of
the study and documentation. The documentation process includes information gathered from individuals
through detailed questionnaire, focused group discussion with persons having knowledge and published
secondary information.
5

<!-- page 7 -->

4.2

Documentation of Traditional Knowledge (TK) related to biodiversity

Documentation of knowledge of individuals with regard to biodiversity and its uses is an important part of
PBR.

Every effort should be made to identify the persons with proven knowledge of local biodiversity;

special attention should be given to the elderly persons who can also provide informations on the
biodiversity which was available in the past but no longer seen at present. In some cases focus group
discussion may be held for the purpose of documentation.
4.3

PBR Methodology

The PBR is a participatory process requiring intensive and extensive consultation with the people. The
objectives and purpose is to be explained in a group meeting in the presence of all sections of people in the
Panchayat, members of the BMC, students, knowledgeable individuals and all those interested in the effort.
Documentation includes photographs (including digital images), drawings, audio and video recordings and
other records like printed material.
4.4

Process in PBR Preparation
Step

1:

Formation of Biodiversity Management Committee (BMC)

Step

2:

Sensitization of the public about the study, survey and possible management

Step

3:

Training of members in identification and collection of data on biological resources
and traditional knowledge

Step

4:

Collection of data. Data collections includes review of literature on the natural
resources of the districts, Participatory Rural Appraisal (PRAs) at village level, house
hold interviews, individual interviews with village leaders and knowledgeable
individuals, household heads, key actors of the panchayat raj institutions and NGOs
and direct field observations

Step

5:

Analysis and validation of data in consultation with technical support group and BMC

Step

6:

Preparation of People’s Biodiversity Register (PBR)

Step

7:

Computerization of information and resources

6

<!-- page 8 -->

Peoples’ Biodiversity Register (PBR): General Details
Name of the Panchayat Samity:
Taluk:
District:
State:
Geographical Area of the Panchayat Samity:
Population under the Panchayat Samity: Total
Male
Female
Habitat and Topography:
Climate (Rainfall, Temperature and other weather patterns)
Land Use (Nine fold classification available with village records)
Date, Month and Year of PBR preparation
Management Regime: Reserve Forests (RF) / Joint Forest Management (JFM) / Protected Areas
(PA) / Community Owned and Managed Forests (COM)

Annexure 1
Details of Biodiversity Management Committee (BMC) of the panchayat (One elected Chairperson
and six persons nominated by the local body; not less than one third to be women and not less
than 18% belonging to SC/ST)
1) Name of the Chairperson:
Age:
Gender:
Address:
Area of specialization:
2) Name:
Age:
Gender:
Address:
Area of specialization:
3) Name:
Age:
Gender:
Address:
Area of specialization:
4) Name:
Age:
Gender:
Address:
Area of specialization:
5) Name:
Age:
Gender:
Address:
Area of specialization:

7

<!-- page 9 -->

6) Name:
Age:
Gender:
Address:
Area of specialization:
7) Name:
Age:
Gender:
Address:
Area of specialization:

Annexure 2
List of Vaids, hakims and traditional health care (human and livestock) practitioners residing and or
using biological resources occurring within the jurisdiction of the village
Name:
Age:
Gender:
Address:
Area of Specialization:
Location from which the person accesses biological material:
Perception of the practitioner on the resource status:
Medicinal use:
Name:
Age:
Gender:
Address:
Area of Specialization:
Location from which the person accesses biological material:
Perception of the practitioner on the resource status:
Medicinal use:
Name:
Age:
Gender:
Address:
Area of Specialization:
Location from which the person accesses biological material:
Perception of the practitioner on the resource status:
Medicinal use:

Annexure 3
List of individuals perceived by the villagers to possess Traditional Knowledge (TK) related to
biodiversity in agriculture, fisheries, and forestry
Name:
Age:
Gender:
Address:
Area of specialization:

8

<!-- page 10 -->

Name:
Age:
Gender:
Address:
Area of specialization:
Name:
Age:
Gender:
Address:
Area of specialization:
Name:
Age:
Gender:
Address:
Area of specialization:

Annexure 4
Details of schools, colleges, departments, universities, government institutions, non-governmental
organization and individuals involved in the preparation of the PBR
1) Contact Person
Name and Address:
2) Contact Person
Name and Address:
3) Contact Person
Name and Address:
4) Contact Person
Name and Address:
You may add names of more institutions / NGO / Individuals, etc. if necessary.

Annexure 5
Details of access to biological resources and traditional knowledge granted, details of the
collection fee imposed and details of the benefits derived and the mode of their sharing
No

Name and address of the
Person /institution/
company/ others

Local and Scientific Name of
the biological material
Accessed and quantity

Date and resolution of the
BMC and endorsement by
the panchayat

Details of
collection
fee
imposed

Anticipated
mode of sharing
benefits or
quantum of
benefits shared

End of Part I

9

<!-- page 11 -->

Part II

PBR – Formats
AGROBIODIVERSITY
Format 1: Crop Plants
1.
Crop

Rice

2.
Scientific
Name
Oryza
sativa

3.
Local
Name

4.
Variety

Veliyan

5.
Landscape
/ Habitat
Lowland
valleys

6.
Approx.
area
shown

7.
Local Status
Past

Present

Plenty

Rare

8.
Special
features
Tall
variety
High yield
Resistant
to drought,
flood, pest
& diseases

9.
Cropping
season

10.
Uses

11.
Associated
TK

12.
Other
details

Food
Fodder
Roofing
Fuel

Provides
more
energy

Suitable
for
“Valicha”
cultivation

13.
Source of
Seeds/Plants

14.
Community/
Knowledge
Holder
Kurichiya
Kuruma
W. Chetty

The format 1 could be used for documenting information about Millets, Cereals, Oil seeds, Commercial crops, Tuber crops, Vegetables,
Legumes, Aromatic crops etc. The column No. 9 ‘other details’ vary with the nature of crops. For measuring local status, there need to
identify a particular year – significant changes in ecology occurred – and compare the status as past and present (past = before the
particular incident). We have to list out all possible features of a crop/plant and give short forms of the same. If relevant, cultivation
practices, propagation techniques, usage etc can be included in the column 8, in associated TK.

10

<!-- page 12 -->

Format 2: Fruit Plants
1.
Plant

2.
Scientific
Name

3.
Local
Name

4.
Variety

5.
Landscape /
Habitat

6.
Local Status
Past Present

7.
Source of
Seeds/Plants

8.
Season of
Fruiting

9.
Associated
TK

10.
Uses

11.
Other
details
market /
own use

12.
Community /
Knowledge
holder

11

<!-- page 13 -->

Format 3: Fodder Crops / Species
1.
Plant

2.
Scientific
Name

3.
Local
Name

4.
Landscape /
Habitat

5.
Local Status
Past
Present

6.
Source of Plants /
Seeds

7.
Associated
TK

8.
Part
Used

9.
Other
details

10.
Community /
Knowledge holder

Other details include fodder for which animal, special features, medicinal uses if any, seasons of availability, propagation methods, collecting from wild or
cultivated etc.

12

<!-- page 14 -->

Format 4: Weeds
1.
Plant

2.
Scientific
Name

3.
Local
Name

4.
Affected
crop

5.
Impact

6.
Landscape /
Habitat

7.
8.
Local Status
Uses
Past Present if any

9.
Management
options

10.
Associated
TK

11.
Other
details
like
exotic

12.
Community /
Knowledge
holder

Other details may include how long the weeds have been suppressing/adversely affecting the crops in this locality, when it came under notice, intensity of
natural multiplication etc
13

<!-- page 15 -->

Format 5: Pests of Crops
1.
Host

2.
Insect /
Animal

3.
Scientific
name

4.
Local
name

5.
Habitat

6.
Time / season
of attack

7.
Management
mechanism

8.
Associated
TK

9.
Other
details

10.
Community
knowledge holder

Other details may include possible reasons for insects/animal attack

14

<!-- page 16 -->

Format 6: Markets for Domesticated animals
1.
Name of the
market &
location

2.
Weekly (D)/
Fortnightly (D) /
Monthly (D) /
Biannual (M) /
Annual (M)
[1]

3.
Types of
animals
bought and
sold
[2]

4.
Types and Average
Number of animals
transacted in a day

5.
Places from
which
animals are
brought

6.
Places to which
the animals are
sold / transported

7.
Name and
location of
fish market

8.
Types of
fishes
sold

9.
Source
of fish

Note: [1] (D) – day; (M) – month;
[2] Types of animals may include: Poultry / Sheep / Goats / Cattle / Ducks / Pigs / Donkeys / Mules / Horses / Camels / Others (Specify)
15

<!-- page 17 -->

Format 7: Peoplescape
1.
Community
&
Population

2.
Families &
Major
occupation

3.
Suboccupation

4.
Depending
Landscape

5.
Major
resources
accessed and
seasons of
access

6.
Landscape
management
practices

7.
Resource
management
practices

8.
Cast
/
tribe

9.
Social
condition

10.
Nature of
inhabitants

11.
No.
of
HHs

Major occupation may be farming. Sub-occupations could be fishing, collection of NTFP animal husbandry, artisans, services
Examples of depending landscapes are agriculture landscape, rivers, forest etc.
Major resources accessed could be agriculture resources of different nature, fish, birds, water, mud, and etc
How the community manages the landscapes they use for satisfying different needs, their strategies and perception
How the community manages the resources they access for satisfying different needs, their strategies and perception, conflicts etc
16

<!-- page 18 -->

Format 8: Landscape
1.
Major Landscapes
Agricultur
al land

Pon
d

Fallo
w
land

2.
Sub Landscape
s

3.
Feature
s and
approx.
area

4.
Ownershi
p

5.
Genera
l flora

6.
Genera
l fauna

7.
User
group
s

8.
Manageme
nt practices

9.
Genera
l uses

10.
Associate
d TK

11.
12.
Other Communit
detail y accessed
s

Provide a brief description of landscapes such as forests, plantations, cultivated land, estuary, pond, lake or other elements

17

<!-- page 19 -->

Format 9: Waterscape
1.
2.
Waterscape Subelement type type

3.
4.
Features Ownership
and
approx
area

5.
General
flora

6.
General
fauna

7.
Major
uses

8.
User
groups

9.
Management
practices

10.
General
uses

11.
Associated
TK

12.
Other
details

13.
Community
accessed

Examples: Ponds, Streams, Rivers, Lake, Canal, Tubewell, Dug well etc.,

18

<!-- page 20 -->

Format 10: Soil type
1.
Soil Type

2.
Color & Texture

3.
4.
Features Soil management

5.
Plants / crop suitable

6.
Flora and fauna

7.
Associated TK

8.
Other information

19

<!-- page 21 -->

DOMESTICATED BIODIVERSITY
Format 11: Fruit Trees
1
Plant
Type

2
Local
Name

3
Scientific
Name

4
Variety

6
Landscape/
Habitat

7
Local Status
Past Present

8
Source of
plant/seeds

9
Season
of
Fruiting

10
Uses
(usage)

11
Associated
TK

12
Other
details
market/own
use

13
Community/
Know. holder

20

<!-- page 22 -->

Format 12: Medicinal Plants (Herbs, Shrubs, Trees etc.)
1.
Plant
Type

2.
Local
Name

3.
Scientific
Name

4.
Variety

5.
Landscape/
Habitat

6.
Source of
plant/seeds

7.
Local status
Past Present

8.
Uses
(usage)

9.
Part
used

10.
Associated
TK

11.
Other
details
market/own
use

12.
Community/
Know.
Holders

Note: Uses: Food/ Veterinary Medicine,/ Human Medicine (Sub-divisions like for children, women etc),/ Agricultural Purpose (Bio-pesticide)
Other details: Propagation methods, / Harvesting period,/ Cultivated or collected from wild or both,/ Perennial/annual/seasonal

21

<!-- page 23 -->

Format 13: Ornamental Plants/ Trees/Climbers etc.
1.
Plant
Type

2.
Local
Name

3.
Scientific
Name

4.
5.
Variety Source of
plant/seeds

6.
Commercial/
noncommercial

7.
8.
Uses Associated
TK

9.
Other
details

10.
Community/ Know.
holder

22

<!-- page 24 -->

Format 14: Timber Plants / Trees
1.
Plant
Type

2.
Local
Name

3.
Scientific
Name

4.
Habitat

5.
Local status
Past Present

6.
Wild/ homegarden

7.
Other
uses
(multi)

8.
Associated
TK

9.
Other
details

10.
Community/ Know.
holder

23

<!-- page 25 -->

Format 15: Domesticated Animals
1.
Animal
Type

2.
Local
Name

3.
Scientific
Name

4.
5.
Breed Features
(local/
hybrid)

6.
Method
of
keeping

7.
Local
status
Past

Present

8.
Uses

9.
Associated
TK

10.
Commercial
rearing

11.
Other details
including
products and
services

12.
Community
Know.
Holders

Uses include milk, meat, skin, fur and etc
24

<!-- page 26 -->

Format 16: Culture Fisheries
1
Fish
Type

2
Local
Name

3
Scientific
Name

4
Variety

5
Features

6
Waterscape
(pond/bheri/talao)

7
Local status

8
Uses

Past Present

9
Associated
TK

10
Commercial
rearing

11
Other
details

12
Community
Know.
Holders

Note: Other details include mode of catching fish, time of availability, breeding time, feeds and etc
25

<!-- page 27 -->

Format 17: Markets / Fairs for Domesticated Animals, Medicinal Plants and other products
1.
2.
Name of the Location
Weekly
Market / Fair

3.
Weekly /
Fortnightly &
Others
Bi-annual /
Annual

4.
Day
held

5.
Month incase of
bi-annual or
annual market
fair

6.
Types of
animal
bought and
sold

7.
Number of animals
(average)
transacted in a day

8.
Places from
where the
animals are
arrived

9.
Places to where the
animals are
transported

26

<!-- page 28 -->

WILD BIODIVERSITY
Format 18: Trees, Shrubs, Herbs, Tubers, Grasses, Climbers etc.
1.
Plant
Type

2.
Local
Name

3.
Scientific
Name

4.
5.
Habit Habitat

6.
Local status
Past Present

7.
Commercial /
own use

8.
Part
collected

9.
Associated
TK

10.
Other
details

11.
Community
Knowledge Holder

27

<!-- page 29 -->

Format 19: Wild Plant Species of Importance
1.
Sl. No.

2.
Local Name

3.
Scientific Name

4
Variety

5.
Importance
(as economic, social,
cultural etc.)

6.
Status

28

<!-- page 30 -->

Format 20: Aquatic Biodiversity
1.
Local
Name

2.
Scientific
Name

3.
4.
5.
Variety Features Habitat

6.
7.
Local Status Uses
Past Present

8.
Associated
TK

9.
Other
details

10.
Community/ Knowledge
Holder

Other details may include mode of catching fish, time of availability, breeding time, etc

29

<!-- page 31 -->

Format 21: Wild Aquatic Plant Species of Importance
1.
Sl. No.

2.
Local Name

3.
Scientific Name

4.
Variety

5.
Importance

6.
Trends

30

<!-- page 32 -->

Format 22: Wild Plants of Medicinal Importance
1.
Plant (Herb,
Shrub, Tree)

2.
Local
Name

3.
Scientific
Name

4.
Variety

5.
Landscape /
Habitat

6.
Local Status
Past Present

7.
Associated
TK

8.
Uses
(usage)

9.
Part
used

10.
Other details
market/ own
use

11.
Community/
Knowledge
Holder

Note: Uses: Food/Veterinary Medicine/Human Medicine (Sub-divisions like for children, women etc)/Agricultural Purpose (Bio-pesticide)
Other details: Harvesting period /Perennial/annual/seasonal

31

<!-- page 33 -->

Format 23: Wild relatives of Crops
1.
Local
Name

2.
Scientific
Name

3.
Associated
crop

4.
Landscape /
Habitat

5.
Local Status
Past Present

6.
Uses
(usage)

7.
Part
Used

8.
Associated
TK

9.
Other
details

10.
Community / Know
holder

Note: Other details may include ‘function as a substitute plant’ in the absence of a particular plant

32

<!-- page 34 -->

Format 24: Ornamental Plants
1.
Local
Name

2.
Scientific
Name

3.
4.
Variety Habitat

5.
Commercial / Non-commercial
Uses

6.
Associated
TK

7.
Any other
Detail

8.
Community/ Knowledge
Holder

33

<!-- page 35 -->

Format 25: Fumigate / Chewing Plants
1.
Plant (Herb,
Shrub, Tree)

2.
Local
Name

3.
Scientific
Name

4.
5.
Variety Habitat

6.
Local Status
Past Present

7.
Uses
(usage)

8.
Part
used

9.
Associated
TK

10.
Other details
(mode of use)

11.
Community
knowledge holder

34

<!-- page 36 -->

Format 26: Timber Plants
1.
Local Name

2.
Scientific Name

3.
4.
5.
Habitat Local Status Other Uses, if any
Past Present

6.
Associated TK

7.
Other Details

8.
Community/ Knowledge Holder

35

<!-- page 37 -->

Format 27 A: Coastal and Marine Flora
1.
Plant
Type

2.
Local
Name

3.
Scientific
Name

4.
Habitat

5.
Local Status
Past Present

6.
Parts
Collected
(if any)

7.
Commercial
Uses
(if any)

8.
Other
Uses

9.
Associated
TK

10.
Community/
Knowledge Holder

36

<!-- page 38 -->

Format 27 B: Coastal and Marine Fauna
1.
Animal
Type

2.
Local
Name

3.
Scientific
Name

4.
Habitat

5.
Local Status
Past Present

6.
Parts
Collected
(if any)

7.
Commercial
Uses
(if any)

8.
Other
Uses

9.
Associated
TK

10.
Community/
Knowledge Holder

37

<!-- page 39 -->

Format 28: Wild Animals (Mammals, Birds, Reptiles, Amphibia, Insects, others)
1.
Animal
Type

2.
Local
Name

3.
Scientific
Name

4.
5.
Habitat Description

6.
Season
when
seen

7.
Local Status
Past Present

8.
Uses
(if
any)

9.
Associated
TK

10.
Mode of
Hunting,
collecting (if
any)

11.
Other
details

12.
Community/
Knowledge
Holder

38

<!-- page 40 -->

URBAN BIODIVERSITY
Format 29: Flora
1.
2.
Sr. No. Local Name

3.
Scientific Name

4.
Type of Plants

5.
6.
Habitat Flowering Season

7.
Remarks (Rare / Common etc.)

Note: Separate format should be used for road side plantation / Parks and Gardens / Housing estate / Commercial
buildings/ other institutional areas, Private club premises and also for Aquatic (water) habitat and
Terrestrial (land) habitat
39

<!-- page 41 -->

Format 30: Fauna
1.
2.
3.
Sr. No. Local Name Scientific Name

Note:

4.
Type of Animals (Mammals / Birds / Fish / Insect etc.)

5.
6.
Habitat Remarks (Rare / Common etc.)

Separate format should be used for road side plantation - habitat / Parks and Gardens / Housing estate /
Commercial buildings/ other institutional areas, Private club premises and also for Aquatic (water) habitat
and Terrestrial (land) habitat

39

<!-- page 42 -->

Format 31: Any other information of local importance
1.
2.
Sr. No. Information of local importance

3.
Remarks

End of Part II

40

<!-- page 43 -->

Part III

Guide to Field Study
Profile of the Study Area
3.1 General Profile
Each study area has its own characteristics. The PBR is to include the general
profile of the area – its geographical location, district, block, gram panchayat, J.L
no. from Mouza / Ward map, altitude, latitude, longitude (whenever possible).
The boundary of the study area and also its connectivity should be additional
point in the general profile.
3.2 Socio-Economic Profile
An outlined socio-economic profile of the study area will help to understand
people’s dependency on the biological resources, either for internal use or for
external supply. The following information will be required to get the socioeconomic profile:
•

Population – to get the total population of the study area individual household
survey is to be carried out with reference to the following parameters.
♦

Total number of members
- Male below 18 years, 18 – 65 years, above 65 years
- Female below 18 years, 18 – 65 years, above 65 years
- Literacy rate
- Male –
4-18 years, 18-65 years, above 65 years
- Female –
4-18 years, 18-65 years, above 65 years

•

Drinking water –

Source, Number (in case of dug well and tube well)

•

Sanitation

Sanitary latrine present or absent

•

Land holding
- Agricultural land –

-

Upto 5 cottah,
5 cottah – 1 bigha,
1 – 5 bigha,
Above 5 bigha
(1 cottah – 720 sq.ft; 1 bigha – 14400 sq.ft)

40

<!-- page 44 -->

•

Occupation
- Agriculture
- Fisheries
- Animal husbandry
- Trading
- Manufacturing
- Other unorganized worker
- Organized worker

•
•
•
•

Family wise monthly income
Healthcare and dependency on traditional medicine
Fuel use and source
Daily food habit
- Staple food
- Pulses
- Vegetables
- Oilseeds
- Fish, egg, meat

•

Domesticated animals – number, types and breed (e.g., cow, goat, chicken,
duck)
Type of housing – Kutchha, Pucca
Respondent’s awareness to biological diversity

•
•

Special focus should be given to the more knowledgeable individual, men and
women. During the survey, the following format may be used for recoding of
information of knowledgeable individuals:

41

<!-- page 45 -->

Natural Resources: Survey and Documentation
Natural Resources include non-living elements like air, water, soil, minerals and
also living elements like, plants, animals and microorganisms. Together the nature
provides the life sustaining system.

1.0 Non-Living Natural Resources
1.1 Land Resource:
Land and soil is a vital resource supporting biological diversity. Soil is not an inert
substance. It provides shelter to tiny microbial organisms like bacteria and fungi as
also micro arthropods and earthworms, not easily visible to naked eyes.
In order to understand land and soil, it is therefore essential to prepare a basic
target area (urban, non-forest rural, forest, mountain, coastal, island etc.) based
land use map. To prepare such a map one has to study the following:
For Urban Area:
(I)

Land for human habitation
a. How much land is used
b. What type of land is preferred

(II)

Roads
a. Length of the Pucca road
b. Length of the Kutchha road

(III)

Institutional and Commercial Area
a. Small scale industries
b. Markets
c. Institutions like office, educational institution

(IV)

Parks, Gardens and Open Space
a. Total park and garden area
b. Total open space area

42

<!-- page 46 -->

(V)

Wetlands
a. Name, location, ownership, area and current uses of wetlands
(Details are given under Water Resource)

(VI)

Rivers / Canals / Creeks – to understand the flowing water profile (if
any)
a. Length of the river/canal
b. Current uses of river/canal water

For Non-Forest Rural Area:
(I)

Agricultural Land
a. How much water is accumulated in low, medium and high land?
b. Whether such land is used for single crop, two crops or more?
c. What type of irrigation is currently practiced?
d. What are the major crops used for cultivation?

(II)

Wetlands
a. Name, location, ownership, area and current uses of wetlands in the
village (Details are given under Water Resource)

(III)

Land for human habitation
a. How much land is used?
b. What type of land is preferred?

(IV)

Fallow Land
a. Area of fallow and their location
b. Vegetation in the fallow land
c. Fauna in the fallow
d. Whether it is used for any religious purposes?
e. Whether permanent fallow or current fallow?

(V)

Rivers / Canals / Creeks – to understand the flowing water profile
a. Origin of the river/canal
b. Length of the river/canal
c. Current uses of river/canal water
43

<!-- page 47 -->

(VI)

Roads
a. Length of the Pucca road
b. Length of the Kutchha road

(VII) Jungle / bushes / forest patch
a. Location
b. Area
(VIII) Sacred Grove / Pond
a. Location
b. Area
c. History
d. Salient features
For Forest Area:
(I)

General features
a. Forest types (Deciduous, evergreen, dry, wet etc.)
b. Area under closed forest
c. Area under open forest
d. Category of forest (protected, reserved, unclassed)

(II)

Wetlands
a. Name, location, area and current uses of wetlands (Details are given
under Water Resource)

(III)

Rivers / Canals / Creeks – to understand the flowing water profile
a. Origin of the river/canal
b. Length of the river/canal
c. Current uses of river/canal water

(IV)

Forest village, if any
a. Location of the village
b. Size of the village
c. Road length and type
44

<!-- page 48 -->

(V)

Sacred Grove / Pond
a. Location
b. Area
c. History
d. Salient features

For Mountain Area:
(I)

General features
a. Altitude
b. Slope

(II)

Land under Forest
a. Forest types (Deciduous, evergreen, dry, wet etc.)
b. Area under closed forest
c. Area under open forest
d. Category of forest (protected, reserved, unclassed)

(III)

Barren land

(IV)

Landslide zone

(V)

Agricultural Land
a. How much water is accumulated in low, medium and high land?
b. Whether such land is used for single crop, two crops or more?
c. What type of irrigation is currently practiced?
d. What are the major crops used for cultivation?
e. Area under abandoned Jhum land
f. Area under terrace cultivation

(VI)

Wetlands
a. Name, location, ownership, area and current uses of wetlands in the
village (Details are given under Water Resource)

(VII) Land for human habitation
a. How much land is used?
b. What type of land is preferred?
45

<!-- page 49 -->

(VIII) Rivers / Canals / Creeks – to understand the flowing water profile
a. Origin of the river/canal
b. Length of the river/canal
c. Current uses of river/canal water
(IX)

Roads
a. Length of the Pucca road
b. Length of the Kutchha road

(X)

Jungle / bushes / forest patch
a. Location
b. Area

(XI)

Sacred Grove / Pond
a. Location
b. Area
c. History
d. Salient features

For Coastal Area:
(I)

General features
a. Location
b. Length of coastline
c. Current uses:
i. Human habitation
ii. Area without habitation
iii. Coastal industries
iv. Coastal fisheries
v. Coastal forest
vi. Coastal agriculture
vii. Coastal road
viii. Coastal wetland

Note: Details under each category can be followed as given above.

46

<!-- page 50 -->

After studying the above, a Land Use Map is to be prepared on the basis of Mouza
map to
a. Demarcate target areas
b. Identify parcel of land under each category (as shown above under I ,
II, III……)
c. Color code the land uses on the map
1.2 Water Resources
Water is a vital resource sustaining life forms. Collect the information on
ground water (from dug well data and hand pump data) and surface water
and document
•

Surface Water Resource

a. River, Canal, Wetland – location / name
b. Area
c. Uses – drinking / cooking / irrigation
d. Produces of wetlands – fishes / vegetables / flower / aquatic plant
e. Birds in the wetland
f. Does the wetland acts as receptacle during flood / serve as water
recharging area?
g. Recreational use
•

Groundwater Resources (except in Mountain ecosystem)

a. Number of hand-pumps used for lifting drinking water and approx.
depth of each
b. Number of shallow and deep tube wells used for irrigation –
horsepower of motors used for each, hours of operation per day
2.0 Living Natural Resources
2.1 Animal Diversity (Fauna)
•

How to observe animals in the field?
In every target area, diverse groups of animals can exist in tropical climates.
These may include animals without backbones (invertebrates) like
earthworm, insects, spiders, scorpions, mollusks etc., or animals with
backbones like fishes, toads and frogs, snakes, lizards, turtle, tortoises, birds
and mammals (squirrels, rat, mole, civet cat, fox etc). Since the animals
occur at different period of time and season, they have to be observed both
47

<!-- page 51 -->

seasonally and also diurnally (day and night). Some animals are best
observed during early morning (e.g., Birds) or at the dusk time (e.g., Bat)
while others may be observed before the day temperature increase (e.g.
Butterflies). It has to be remembered that animals inhabit different habitats
viz., upper branches of the tree, grassland, banks of river, deep foliage,
holes in the tree trunk, under the bark, on the ground or underground.
• Selection of sites for observation
It will be useful to select the best possible site for observation where diverse
biological species may be available. These may include the agricultural
land, culturable fallow, village orchards, village ponds, forest patch, canal
side and roadside. A complete information base can only emerge if year
round, seasonal observations and recording is carried out.
A brief outline of methods of observation for selected group of animals is
given below:
2.1.1 Invertebrate Animals
Invertebrate animals can occur both in land and water in specific habitat condition
(under the stone, in rotten logs, in the flowers, on fruit trees, in bushes, in
agricultural fields etc.). The smallest invertebrate animal called protozoa (body
with single cell) cannot be seen by naked eyes but they may exist in soil, water
even within the body of the human being or other animals. Normally the visible
animal species are recorded in PBR. These include:
2.1.1.1 Earthworms
Earthworms normally live in mineral rich soil. To observe and collect earthworm
specimen:
 Select agricultural and other land; make 1 ft x 1 ft x 1 ft deep cavity at least
in 5 / 10 places and collect earthworm sample in small plastic glass vial
containing 70-80 percent alcohol (spirit).
 Note the date, time and place of collection in the field notebook.
 Local names can be further validated by scientific names once identified by
a subject specialists.
2.1.1.2 Insects & Spiders
Insects comprise the largest number of living organisms in the world. So far nearly
8,50,000 species of insects have been documented in the world. Scientists believe
this is only 4-5 percent of the total insects species that may exist in today’s world;
48

<!-- page 52 -->

that means 95 percent of the insects are yet to be described and named. Obviously,
the largest numbers are expected from southern tropical countries including India.
So far only 6.5 percent of the insect species of the world have been recorded from
India. Out of 29 orders of insects, representatives of 27 orders have been located in
the country.
Usually insects are considered as enemies to the human society because they cause
considerable damage to the agricultural crop and many species can act as vectors
and transmit pathogens causing serious diseases in plants, animals and human
being (Cholera, Malaria, Kala Azar, Dengue are some of the insect borne diseases).
On the other hand, a number of insects offer useful services to the plant kingdom
and to the human society as pollinators, as natural enemies for pests, as providers
of silk, honey, lac etc. Insects are the largest group of pollinators in the natural
world.
Spiders may occur in several forms. Spiders act as predators for many of the
insects and provide food to the higher animals like lizards and birds.
In general, the goods and services from insects and the spiders can be listed as
follows:
•
•
•
•
•
•
•
•

Provide honey, lac and silk.
Act as pollinators in agriculture, forestry and horticultural crops.
Act as food in many parts of the world.
Act as predator for pest insects (larva of Lady bird beetle)
Help to increase fertility of the soil (soil inhabiting insects)
Provide aesthetic pleasure and lessons in social behavior (e.g., butterflies
and honey bees)
Many insects and spiders are used for medicinal purposes by the tribal
communities
Play an important role in the food chain in nature.

¾ General Characteristics of Insects
Insects and spiders have jointed legs; the same character can also be seen in
crustacean (Prawn, Shrimp and Crabs), centipedes and millipedes. Insects have
normally a pair of antenna and an exoskeleton. Adult insects have three
distinct parts – head, thorax and abdomen. Insects have three pairs of legs and
usually one or two pairs of wings. Male and female insects may vary in colour,
shape and size.

49

<!-- page 53 -->

¾ Collection and Observation
To collect insects and spiders, several methods can be used viz.,
Hand collection with a soft camel hair-brush (soft body insects) or with
a pair of forceps. Such insects are normally preserved in 70 percent
alcohol in glass vial.
• Net collection – Butterflies and other flying insects can be collected
with the help of a specially prepared aerial net with a long handle or
with a sweeping net attached to a short handle.
• Traps – Insects can also be collected by setting up different types of
traps, viz.,
− Light trap: Light attracts insects at night especially at dark
nights. An illuminated electric bulb or a petromax lamp can be
used as a light source in the open field; a piece white cloth (3 ft X
3 ft) may be placed on the grass near the light source; when the
insects are attracted to the light and settle on the white cloth they
can easily be collected.
− Pitfall Trap: This is a simple devise of using a plastic cup (9 cm X
8 cm), which is placed in a dug out pit at the floor level. Such
cups are covered by a wire mesh and then by leaves and twigs.
The cups should contain some attractant food or liquid. Such
containers should be kept for 3-days and then taken out for
observation.
•

¾ To observe and collect insects:
 Select a site and demarcate an area measuring 50m X 10m.
 Observe and collect the insects and spiders by hand, net and traps (for
methods, see above).
 This can be repeated depending on the total area of the selected site.
 To preserve the collected specimens, first kill the insects and spiders using
chloroform or benzene. Preserve butterflies and moths in envelops in dry
condition and other insects in plastic or glass viol containing 70% alcohol
(spirit).
 Put serial number in the collected specimens and write it in the field
notebook. Also note the date, time, description of the site, type of insect
collected and number of each type.
¾ Identification of collected insect specimen:
Firstly, it should be identified whether the collected specimen is insect or not.
For this following steps to be adopted:
50

<!-- page 54 -->

 Presence of two pairs of antennae and not less than five pairs of legs –
crustacean
 Presence of four pairs of legs and no antenna – arachnid
 Presence of three pairs of legs and adult specimen possessing wings (except
in some cases like Springtails, Lice, Earwigs etc.) – insect
¾

Characteristics of insects of different orders:

Insects are divided into 29 orders. The characteristics of most common insects are
given below:
A. Odonata:
i. Two pairs of wings with several or many cross veins
ii. Large compound eyes present on the head
iii. Three pairs of legs with exoskeleton
e.g. Dragonflies, Damselflies
B. Orthoptera
i. i. Two pairs of wings, fore wings are thin, hind
wings are large with cross veins
ii. Hind legs are thick and long, used for jumping
e.g. Grass hoppers, Crickets
C. Phasmida
i. Body flat leaf like or long and slender, stick like
ii. Wingless
e.g. The Walking Sticks,
D. Dictyoptera
i. Body flattened, swift on foot
ii. Upper wings are bright and thin
iii. Lower wings with cross veins
e.g. Cockroaches

51

<!-- page 55 -->

E. Mantodea

i. Two pairs of wings present
ii. Front legs adapted for catching insect preys
e.g. Praying Mantis

F. Isoptera
i. Soft body
ii. Wings are equal in size and with indistinct veins
iii. In some forms wings are absent.
iv. Winged insects normally comes out during rainy
season.
e.g. Termites, White Ants
G. Thysanoptera
i. Small in size
ii. Pigmented body
iii. Thin wings with veins and hairs
e.g. Thrips
H. Heteroptera
i. Large, hard body
ii. Fore wings thick, sometimes needle like
iii. Hind wings with cross veins
iv. Suck blood from other animal’s body
e.g. Bug
I. Homoptera

i. Generally small insect
ii. Soft legs, two pairs of wings with cross veins
iii. Anterior part of head with sucking mouthparts
iv. Wing less insects are also found in some stage of
life cycle
e.g. Aphids, Cicada, White flies, Leaf hoppers

52

<!-- page 56 -->

J. Coleoptera
i. Two pairs of wings, fore wings hard called elytra,
hind wings with cross veins
ii. Bright in colour
e.g. Lady bird beetle, Dung beetle
K. Hymenoptera
i. Two pairs of wings with cross veins
ii. Hind wings are always smaller than fore wings
e.g. Honey bee, Ant, Wasps
L. Diptera
i. Generally smaller in size
ii. Only fore wings present with less cross veins
e.g. Flies, Mosquito
M. Lepidoptera
i. Two pairs of wings with fine scales
ii. Body and wings are thin and flat
iii. Wings are bright in colour
e.g. Butterflies, Moths
N. Thysanura

i. Small, wing less, soft body
ii. Whole body is covered with silvery hairs
e.g. Silverfish, Bristletails

O. Collembola

i. Small, wing less, soft body
ii. Spring like structure present at the end of the tail,
help in jumping
e.g. Springtail
53

<!-- page 57 -->

2.1.1.3 Mollusk
Mollusks are represented by snails, mussels etc. They can be found in marshy
areas as well as in the high land. Observation place for mollusks may be marshy
land, agricultural field during monsoon, bund area of the field etc.
2.2 Vertebrate Animals
2.2.1 Fishes
Fishes can be found from small ponds, beels and rivers in the village. Fishes can be
distinguished based on the structure, scales, colour, size etc. A total of 2586 species
of fishes have been recorded from India.
To observe fish diversity of the particular place :
 Collect the names of fishes cultured in the village wetlands
 Collect the names of non-cultured fishes
 Also collect the information regarding the fishes which are not found
nowadays from elderly people
2.2.2 Amphibia
The group amphibian is represented by frogs, toads and newts. They are the cold
blooded animals. Night time is the best time to observe Amphibia. In India about
209 species of amphibians have been recorded. Frogs and toads eat harmful insects
of paddy field and therefore beneficial for the human being.
To observe and collect Amphibia specimen
 Pit fall trap can be used near the water bodies or paddy field. The trapped
specimen can be collected and observed later on. Amphibia can also be
collected by cloth nets and by hand.
 Species can be identified by the call of the Amphibia
2.2.3 Reptiles
Reptiles include snakes, lizards, crocodiles, turtles etc. Snakes may be poisonous or
non-poisonous. A total of 485 species of reptiles are found in our country. These
animals can be found during day time as well as night time.
Reptiles may be observed
54

<!-- page 58 -->

 at the selected sites by direct sighting (on trees, on ground, under stone, in
crevices, near water)
 by the molt of the snakes
 from the elderly people about the common reptiles found in the area
2.2.4 Birds
Birds are colorful feathered animals. The male and female birds can be easily
distinguished as the males are more colorful than females. Early morning and
dusk time are the best for observing birds. The call, colour, structure of wing, beak,
legs etc. are important for observing a bird species.
Birds can be observed at the places where insects, amphibia, reptiles etc are
observed.
 Select 50 m., long site. Imagine a circle of 10 m., radius at the two end points
of the 50 m., long site.
 Stand at the centre of the circle and observe the birds for 10-15 minutes.
 Note the name of the known birds. Record major features of the unknown
birds.
2.2.5 Mammals
Mammals are placed at the highest level of animal kingdom. They are
characterized as warm-blooded animals with hairy body and by the presence of
mammary glands. In India, a total of 372 species of mammals are found. The smell,
call, foot-print, excreta etc., are important for observing mammalian species.
Generally most of the mammalian species come out during night. Therefore for
direct observation, night time is preferred. Indirect information may be collected
from their foot-print, call, habitat etc.
2.2.6 Domesticated Animals
Domesticated animals include cow, buffalo, sheep, goat, poultry chicken, duck etc.

55

<!-- page 59 -->

Figure: Different types of Legs of Birds

Woodpecker

Kingfisher

Cormorant

Eagle

Pigeon

Palm Swift

Figure: Different types of Beaks of Birds

Eagle

Fantail Snipe

Egret

Parakeet

Vulture

Duck

56

<!-- page 60 -->

3.0 Plant Diversity (Flora)
Plant kingdom can be divided into Gymnosperms and Angiosperms.
3.1 Gymnosperms
Gymnosperms are non-flowering plant group and reproduces by spores. This
group can be divide into three sub-groups:
•
•
•

Thalophyta: Generally once-celled or multi cellular body. In case of multicellular species, body parts cannot be differentiated. e.g. Algae, Fungi
Bryophyte: Small, shoot, leaves present, generally grows on marshy land.
e.g. Moss
Pteridophyte: The plant is having distinct root, shoot and leaves. Vascular
bundle present. e.g. Fern

3.2 Angiosperms
These are the flowering plants and reproduce by seed. This group is further
divided into two groups:
a. When the seeds are open without any external coating. e.g. Pine, Cycas
b. When the seeds have outer seed coating. This may again be divided into
two groups called Monocot and Dicot. The first one having only one
undivided seed, like rice and wheat and the second one has got divided
seed, like gram, mango etc.
The dicot group is again divided into following three sub-groups:
3.2.1 Herbs:
 Plants with soft shoot
 Herbs can be on the basis of duration of lifecycle.
 Life cycle completes in one year. e.g. Paddy, Wheat
 Life cycle completes in two years. e.g. Radish
 Life cycle completes in more than two years. e.g. Ginger
 Herbs can also be divided in to climbers and creepers
3.2.2 Shrubs:
 The plants larger than herbs but smaller than trees.
 Woody stem, medium height, branched. e.g. China rose,

57

<!-- page 61 -->

3.2.3 Trees:
 Plants with long, woody stem.
 Branching out after a certain height from the ground. e.g. Mango, Banyan

Observation Procedure for Plants
a. Wild Plants:
 Demarcate 50 m., long area
 Demarcate five 10 m., X 10 m., quadrant, one at the middle of 50 m., length
and two each at the two sides of end two points
 Write description of the site
 Write down the uses of the plants especially medicinal use, abundance, and
plants, which were present and used in the earlier times but no longer
available. this data can be collected from the help of local villagers specially
the elderly people.
b. Agricultural Crop Plants
Agricultural crops include cereals, pulses, vegetable, spices, oil seeds, fiber
yielding plants, sugar yielding plants, cultivated fruit and flowers, green manure
etc.
[S=Summer; M=Monsoon; PM=Post Monsoon; W=Winter]
Paddy:
Paddy can be of many varieties, both indigenous as well as high yielding. Farmers
are the best source for getting the information regarding cultivation of rice
varieties. The morphological characters to be noted are:





Total plant: seedling height, plant height
Culm: culm number
Leaf: leaf length and width, leaf angle, flag leaf angle and colour
Panicle: panicle type, length, weight, secondary branching pattern,
number of grains, proportion of sterile grains, panicle axis
 Grain: grain length and width, 100-grain weight, brown rice length
and width, brown rice colour, aroma etc
Disease and pest resistance of plants may be observed directly by the rate
incidence of pest insects and diseases.

58

<!-- page 62 -->

c. Horticultural Plants
This includes flowering and fruit-bearing plants like Mango, Guava, China Rose,
Jasmine etc.
d. Timber yielding Plants
This type includes woody plants grown for timber. E.g. Teak, Mahogany etc.

Preparation of herbarium sheets for identification of plant species
Herbarium sheets are important tools for identification of plants species. Specimen
can be kept for many years as herbarium sheet for future research. Herbarium
sheets must be prepared in case the plants cannot be identified at the site.
Following materials are needed for herbarium sheet preparation:
 Bag (jute, paper, polythene) for keeping the specimen collected
 Knife for cutting the plant specimen
 Note book and pencil for note down the information required
 Weight for pressing the plant specimen between newspapers
Procedure:
 Collect the plant specimen with leaves, flower and fruit. The size of the
specimen must be 30 cm. x 20cm. Put necessary label with number, location,
date of collection and name of the collector.
 Now write down these information in the notebook for future reference
 Put the specimen in between two newspapers and place the leaves, flowers
and fruit properly
 Put the specimen within the paper on a plain surface and place some weight
on it
 Change the newspaper as and when required for complete drying the
specimen.
 Place the dried specimen outdoor for sun-drying
 Take a hard art paper of size 41.7 cm., X 26.5 cm. Place the dried specimen
at the center of the paper and glued or stitched it with the paper.
 Put herbarium label at the lower right hand side of the herbarium sheet
with information like scientific name, family, location/place, date, collects
name, altitude from msl etc.
This complete herbarium sheet can be preserved for many years with proper care.

59

<!-- page 63 -->

3.3 Medicinal Plants Survey
In case the area in rich in medicinal plants, special focus is to be given to document
the resources and its current use pattern.
Based on the results of the
documentation the BMC will be in a position to determine the resource potential,
prospects of cultivation, sustainable use and trading.
3.4 Ritualistic and Social Use of Biodiversity
The population in the study area may use different biological resources for
religious and other ritualistic purposes. In the rural areas, such materials are
normally collected from nature but in the urban areas such materials are traded
through commercial stores.

End of Part III
60

<!-- page 64 -->

Certificate for People’s Biodiversity Register

Annex- III

CERTIFICATE
(as per Rule 22(10) of the Biological Diversity Rules 2004)

This People’s Biodiversity Register (PBR) has been endorsed vide
resolution

no…………..dt…………..

by

the

………………………….

Biodiversity Management committees (BMC) under the supervision and
guidance of …………………….…….………………………… a NGO/national
institution/organization

under

the

overall

supervision

of

…………………..Biodiversity Board. The data has been processed, analyzed
and interpreted by …………….…………………………….. a NGO/ national
institution/organization, Biodiversity Board, school teachers, subject matter
specialists, students & others. This is the I/II/III/final phase of preparation of
PBR.
Biodiversity Management Committees
1. Chairman

signature with seal & date

2. Secretary of BMC
(if appointed)

signature with seal & date

3. Counter signature of representative of
NGO/organization/individual involved in PBR exercise.

Counter Signature with seal & date
Member Secretary, SBB
or
Authorized official of SBB

1
