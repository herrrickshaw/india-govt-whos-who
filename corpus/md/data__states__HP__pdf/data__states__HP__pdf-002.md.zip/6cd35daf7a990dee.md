---
doc_id: "6cd35daf7a990dee"
source_url: "https://hpsvacb.hp.gov.in/storage/app/media/uploaded-files/pro-forma-for-prosecution-sanction-order-for-retired-public-servent-who-could-have-been-removed-by-board-corporation-society.pdf"
ministry: "State Vigilance & Anti Corruption Bureau, Himachal Pradesh"
title: "Pro-Forma For Prosecution Sanction Order (For Retired Public Servent who Could Have been Removed by Board-Corporation-Society).pdf"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "e6d72ba676799e53"
---

<!-- page 1 -->

PRO-FORMA-D
PRO-FORMA FOR PROSECUTION SANCTION ORDER
(For Retired Public Servants who could have been removed from office by the Board/
Corporation/ competent removal authority after getting approval from Managing Committee
of registered co-operative society, at the time of alleged commission of offence) .

Whereas, FIR No.___ dated. under section, _ has been lodged at PS
5४&४९8 on the complaint of Sh.___ against. ______on the allegation
पक 2 And whereas<the investigation of the case was conducted by the SV&ACB
and during the course of investigation it has been established that (highlight role of the
accused),

And whereas, the said act(s) of aforesaid accused namely, constitute the commission of the
offences punishable under section(s) of the PC Act, 988. And whereas, the aforesaid accused
namely _____ has retired from service and at the time of the alleged commission of offence the ee
(Name of the Board/ Corporation), was competent to remove the said accused (Name) from
office. The records furnished by SV&ACB including FIR, statements of witnesses, documents seized
during investigation, charge sheet and other material arising out of the aforesaid FIR for seeking
Prosecution sanction in respect of ____— (Name of the accused) were placed before the Board/
Corporation/ competent removal authority after getting approval from Managing Committee
of registered co-operative society in its meeting held on ___ (Date). after carefully considering
the material placed before above stated authorities, it was prima facie satisfied that the aforesaid
accused namely has committed offence(s) of which are punishable under the
Prevention of the Corruption Act, 988 and should be prosecuted before a court of law. The Board/
Corporation/ competent removal authority after getting approval from Managing Committee
of registered co-operative society, has therefore resolved to accord prosecution sanction under
section 9 Prevention of Corruption Act, 988 in FIR No. dated for offence(s)
punishable under section(s) of the Prevention of Corruption Act, 988, for the prosecution
of the aforesaid accused namely and any other offence(s) punishable under any other _
provisions of law in respect of the acts aforesaid and for taking cognizance of the said offence(s) by a
Court of competent jurisdiction. Now, therefore, | (name and
designation), hereby convey the prosecution sanction under section 9 Prevention of Corruption Act,
988 in FIR No. dated. against the aforesaid accused___ (Name).
PX fceR 3 asel! te Name and designation of the authority
sas Re Lah , LL) lo (With the Seal of the Authority)
Vetkd,
x oto : ;
Raph vewma
