---
doc_id: "ccdefcd0315f22ea"
source_url: "https://rggec.ac.in/wp-content/uploads/2026/03/Tender-offiline-mode-for-Supply-of-Printed-Books-for-Library.pdf"
ministry: "Rajiv Gandhi Government Engineering College (RGGEC), Kangra, Himachal Prades"
title: "Tender offiline mode for Supply of Printed Books for Library"
date: ""
pages: 29
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a267b78f017daf9e"
---

<!-- page 1 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com

NOTICE INVITING TENDER (NIT)
Tenders (in offline mode only) are invited from registered publishers or authorized dealers for
the supply of printed books to the Library of Rajiv Gandhi Government Engineering College,
Kangra at Nagrota Bagwan (H.P.) for the financial year 2025–26.
The tender document can be viewed and downloaded from https://rggec.ac.in from 15-03-2026
to 06-04-2026 up to 12:00 PM. The bids will be accepted upto 06-04-2026 (01:00 PM). The technical
bids will be opened on 06-04-2026 at 3:00 PM.
Tender Fee: ₹500/EMD: ₹50,000/Tender Fee may be submitted in the form of a DD from any scheduled bank. EMD must be
submitted as FDR pledged in favor of the Director/Principal, RGGEC Kangra.
Corrigenda
or
updates
will
be
available
only
at
https://rggec.ac.in/
The undersigned reserves the right to reject any or all bids without assigning reasons.
-SdDirector-cum-Principal
Rajiv Gandhi Govt. Engg. College
Kangra at Nagrota Bagwan (H.P.)

1

<!-- page 2 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
TENDERING SCHEDULE:
Date of publication of tender on institute
website/newspapers

15-03-2026

Period for downloading the tender
document from institute website

16-03-2026 to 06-04-2026 (12:00 noon)

Bid submission start date

16-03-2026

Last date and time for submission of bid

06-04-2026 up to 01:00 PM

Date & Time for opening of Technical Bid

06-04-2026 at 03:00 PM
Venue: O/O Director/Principal, Rajiv Gandhi
Government Engineering College, Kangra at
Nagrota Bagwan, District Kangra, H.P.-176047
Rs. 500/- (Demand Draft {Non-Refundable})

Cost of the tender document
Earnest Money Deposit (EMD)

Performance Security

2

The Tender must be accompanied by an Earnest Money
Deposit (EMD) of Rs. 50,000/- (Rupees Fifty
Thousand) only in the form of Fixed Deposit Receipt
(FDR) duly pledged in favour of Director/Principal,
RGGEC Kangra at Nagrota Bagwan, H.P.
MSME registered agency can be given exemption only
in EMD.
5% of the total contract value to be submitted within 15
days from the date of signing of the agreement on nonjudicial stamp paper. The security deposit shall be
refunded to the supplier after 60 days of the expiry or
termination of the contract. The security deposit shall
not carry any interest.

<!-- page 3 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
1.

IMPORTANT INSTRUCTIONS TO THE BIDDERS
1.1. Bids (in offline mode only) are invited, for and on behalf of Director/Principal RGGEC Kangra at Nagrota
Bagwan (H.P.) from established, reputed, and experienced publishers or their authorized dealers/representatives
for the purchase of various Indian & Foreign Books (print version only) as per details at Annexure-E, for the
Central Library of RGGEC Kangra at Nagrota Bagwan (H.P.)
1.2. Tender Document: The “Tender Document” consists of the Tendering Schedule, Instructions to bidders,
General Terms and Conditions, Technical bid form and Financial Bid form & List of Books. The supply, upon
order placement, will be governed by these documents collectively.
1.3 All bids must be accompanied by a Tender Cost /Bid Price and Bid Security (EMD) as specified in the bid
document and must be delivered along with other necessary documents specified in the tender document herein
to the RGGEC office on or before the last date and time indicated in the tender schedule; failing which tender/bid
will not be considered.
1.4 The main cover Sealed Envelope, super-scribed as “Tender for Library Books” should contain two sealed
envelopes:
(i)
(ii)

Technical Bid Envelope,
Financial Bid Envelope.

1.5 Technical Bid Envelope should contain the following documents:
(i)
(ii)
(iii)

(iv)

(v)
(vi)

GST Number Document
PAN Document
Price of Bidding Document i.e. Tender Cost/Bid Price [Non-Refundable] amounting to ₹ 500.00 (₹
Five Hundred Only) in the form of DD from any nationalized bank in favour of Director/Principal
Rajiv Gandhi Government Engineering College, Kangra at Nagrota Bagwan, District Kangra, HP,
PIN-176047
Refundable Earnest Money (EMD/Bid Security) amounting to ₹ 50,000.00 (₹ Fifty Thousand Only)
in the form of DD/FDR from any nationalized bank in favour of Director/Principal Rajiv Gandhi
Government Engineering College, Kangra at Nagrota Bagwan, District Kangra,HP, 176047
Details of the bidder as per Annexure No. A
Documents mentioned under check list in Technical Bid Annexure No. B

1.6
Financial Bid Envelope should contain Rate quoted/Discount offered on prescribed format given as
Annexure No. D
1.7 Both the envelopes i.e. Technical Bid Envelope and Financial Bid Envelope shall be superscribed as
“Technical Bid” and “Financial Bid” respectively.
1.8 Both the envelopes i.e. “Technical Bid Envelope” and “Financial Bid Envelope” should be sealed
properly and placed in the main cover Sealed Envelope as mentioned at point 1.4 above.
1.9 The single offer without complete documents mentioned above will be rejected and no
correspondence in this regard will be sent to the bidder.
1.10 The technical bid will be opened first and shall comprise the required documents mentioned in the checklist
(Annexure-B). Bids lacking in any of the documents specified in the technical bid shall be rejected. The
Financial bid will be opened only for those bidders who qualify for the Technical Bid.

3

<!-- page 4 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
1.11. The scope of work shall include complete supply of books mentioned in financial bid including quality
check, packing, transportation, insurance, and any other services associated with the delivery of Books. The
successful bidder will assume full responsibility of the complete supply until final acceptance.
1.12. It will be imperative for each bidder to fully acquaint themselves with all the local conditions and factors
which would have any effect on the performance of the supply. No request for the change of price, or time,
schedule of delivery of books shall be entertained after supply order because of any local conditions or the
factor.
1.13. The bidders will not form a part of the cartel and put in supporting quotations for some other company.
This will debar the company from participating in other tenders floated or to be floated by the purchaser.
1.14. Eligibility Criteria:
a. The annual turnover of the bidder should be Rs. 10 lacs or more during the last three years. The certified
copies from Statutory Auditors should be enclosed with the bid.
b. The bidders shall also be required to submit the copies of PAN, GST, and income tax returns for the previous
years.
c. The bidders must be an authorized distributor, dealer, or supplier of an academic book publisher. A copy of
the registration with the appropriate authority or authorized dealer of the publisher shall also be furnished.
d. The agency will not be allowed to engage any other sub-agency to execute the assigned work/job. In such an
event, the tender will be cancelled, and security money will also be forfeited. A consortium/joint venture is not
allowed under any condition.
e. All the correspondences shall be addressed to the Director/Principal, Rajiv Gandhi Govt. Engg. College,
Kangra at Nagrota Bagwan (H.P.) on rggec.office@gmail.com
f. The bidder shall supply only the latest edition and shall supply minimum of 80% of book titles each from
Annexure E1, Annexure E2 and Annexure E3 as prescribed in Annexure- E.
g. The bidder shall offer a minimum of 20% flat discount on complete lot.

2.

BID SECURITY/EARNEST MONEY.
2.1. Bid Security/EMD amount should be enclosed along with the Technical Bid for an amount of Rs.
50,000/- (Rupee fifty thousand) only in respect of items at Annexure-E in the shape of FDR or a DD from
any Scheduled Bank duly pledged in the name of “Director/Principal, RGGEC Kangra at Nagrota Bagwan
(H.P.)”, failing which the tenders will be outrightly rejected. Bid Security/EMD, if already deposited against
other tenders, shall not be adjusted against this tender.
2.2. The EMD of the successful bidder shall remain with the institute till the completion of work/receiving
of satisfactory performance certificate from the committee of the institute. Any breach in terms and conditions
of this document or work/supply order by the successful bidder may lead to penalty from EMD submitted.
The Bid security shall be refunded to the unsuccessful tenderer.

4

<!-- page 5 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
2.3 The Bid Security/Earnest Money shall be forfeited:
a) If a Bidder withdraws his bid during the period of bid validity specified by the Bidder in the
Bid;
or
b) In case of the finally selected Bidder, if the Bidder fails;
i) To furnish Performance Security under Clause 3. or
ii) If, at any stage, any of the information/declaration is found false.

3.

PERFORMANCE SECURITY:
The successful bidders shall have to deposit 5% of the value of the contract towards performance security in
shape of either account payee Demand Draft or FDR or Bank guarantee issued by a Nationalized/scheduled
commercial bank in favour of Director/Principal, Rajiv Gandhi Government Engineering College Kangra at
Nagrota Bagwan H.P. The bank guarantee should be valid for 60 days beyond the contract period i.e., total 14
months.

4.

PERIOD OF VALIDITY OF BIDS
Bids shall remain valid for one year from the date of opening of the price bid prescribed by the purchaser or till
the completion of the job, whichever is later, unless otherwise prescribed contrary in the terms and conditions
of this tender document.

5.

THE INSTITUTION HAS THE RIGHT TO ACCEPT ANY BID / TO REJECT ANY OR ALL
BIDS
The Institution reserves the right to accept any bid, to annul the tender process and reject all bids at any time,
without assigning any reason at any stage, without thereby incurring any liability to the affected Bidder or
Bidders or any obligation to inform the affected.

6.

OPENING OF BIDS
6.1 The bids shall be opened on the date and time mentioned in the Tender Notice in the presence of bidders
who opt to be present. If the date fixed for the opening of the tender is declared a holiday, the tenders shall be
opened on the next working day at the same time as fixed for the original date for this purpose. The undersigned
reserves the right to accept or reject any or all tenders in part or whole without assigning any reason whatsoever.
6.2 The bids will be opened in the presence of Bidders/ representative who may like to attend on the scheduled
date and time as mentioned in the tender document. The Bidders/ representatives who are present shall sign a
register as evidence of their attendance. The Bidders' representatives shall furnish a letter of authority to attend
the bid opening. However, the tenders of other participating firms shall not be allowed to be handed over to
them for their inspection. Financial bids of only those Bidders, whose bids are found technically
suitable/qualified, will be opened. The decision of the constituted committee on technical suitability shall be
final & shall not be open for discussion.

7.

SCRUTINY OF BIDS
7.1 The college will examine the bids to determine whether they are complete, whether any computational errors
have been made, whether EMD has been furnished. Whether the documents have been properly signed, and
whether the bids are generally in order.

5

<!-- page 6 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
7.2 The college may waive off any minor infirmity, non-conformity, or irregularity in a bid that does not
constitute a material deviation and that does not prejudice or affect the relative ranking of any bidder as a result
of the technical and financial evaluation.
7.3 Prior to the detailed evaluation, the college will determine whether each bid is acceptable qualitatively, is
generally complete and is substantially responsive to the bid documents. For this determination, a substantially
responsive bid conforms to all the terms, conditions, and specifications of the bid documents without material
deviations, objections, conditional ties, or reservations. A material deviation conditionally or reservation is one
(i) that affects in any sustainable way the scope quality of performance of the contract. (ii) that limits in any
substantial way and or /is inconsistent with the bid documents or the college's rights or the successful bidders'
obligations under the contract (iii) whose rectification would unfairly affect the competitive position of the other
bidders who are presenting substantially responsive bids.
7.4 Arithmetical errors, if any, will be rectified on the following basis: if there is a discrepancy between the unit
price and the total unit price as declared in the Price schedule, the unit price shall prevail and the total price
shall be corrected. If there is a discrepancy between words and figures, the lowest amount will prevail. If the
supplier does not accept the correction of the error, the bid will be rejected.

8.

FINANCIAL BID
The bidder should offer a maximum discount on published/printed price in English/ Hindi/other languages of
Indian or foreign origin and shall in no case be less than 20%. The rates for the books are to be quoted as per
the attached format given at Annexure –D.
Purchase orders shall be awarded based on a comparative evaluation of the quotations received, with the tender
being awarded to the bidder offering the maximum flat discount for the complete lot. Discount to be mentioned
in percentage only.
All prices mentioned should be F.O.R. the destination at Rajiv Gandhi Government Engineering College,
Kangra, at Nagrota Bagwan, H.P.
8.1.
8.2.
8.3.

9.

Bidder shall submit the list of book titles with the exact final rate for all books inclusive of all charges.
The firm has to provide the break-up of expenditure of the final quoted rate for each title as well as total
expenditure for the whole lot.
Once the price of books quoted by the Bidder and accepted by RGGEC Kangra at Nagrota Bagwan
(H.P.), then no additional claims will be admissible on account of any price variation or fluctuation in
market rates.

GST/Excise/Custom Duty/VAT/Entry Tax, and any other levy/surcharge in any shape or by
whatever nomenclature may be included in the quoted amount.

INSTITUTION RIGHT TO VARY QUANTITIES AT THE TIME OF AWARD
The Institution reserves the right to vary the quantities of books as per AICTE requirement or the requirement
of the institution.

10.

NEGOTIATION OF TENDER
10.1.
10.2.
10.3.

6

Before the expiry of the period of bid validity, the college will notify the finally selected Bidder in
writing by registered letter or by mail, and to be confirmed by the bidder in writing by registered letter
or by Hand in person or by mail.
If an extension of the bid validity period becomes necessary, it shall be done only through mutual
agreement between the College and the concerned bidder(s).
The college reserves the right to constitute a negotiation committee, if deemed necessary.

<!-- page 7 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
11.

ISSUE OF SUPPLY ORDER
11.1.
11.2.

12.

At the same time as the College notifies the finally selected Bidder that its bid has been accepted, the
finally selected Bidder shall be issued the supply order, from the office of the Director/Principal,
RGGEC Kangra at Nagrota Bagwan, H.P.
Without prejudice to any legal remedy, failure of the finally selected Bidder to comply with the
requirement of Clause 2.3(a) or Clause 2.3(b) shall constitute sufficient grounds for the annulment of
the award and forfeiture of the EMD, in which event the college may make the award to the next lowest
evaluated bidder or call for the fresh bids.

PAYMENT
The payment for the Indian & Foreign Books shall be made within 90 days after the approval from the inspection
committee. The bill will be raised by the supplier at the rate prevailing on the date when the books are finally
invoiced against the order or procured.

13.

INSPECTION
All books will be accepted only after inspection by the committee of RGGEC Kangra at Nagrota Bagwan (H.P.)
or any officer authorized by the institute.

14.

DELIVERY OF BOOKS
Delivery failure of the Books at the Institute premises shall be completed by the Supplier within 1 month from
the date of supply which a penalty @ 0.5 % of the contract amount shall be charged for every week of delay, up
to a maximum of 10% of the contract amount.

15.

INTELLECTUAL PROPERTY RIGHTS
The supplier shall indemnify the Institute against all third-party claims of infringement of patent, copyright,
trademark, license of industrial design rights, or software piracy arising from the use of the store/goods or any
part thereof. The supplier shall be liable for all civil or criminal liabilities arising at any time during the execution
of the contract.

16.

JURISDICTION
The courts at Kangra/Dharamshala will have the jurisdiction for the trial of any matter, dispute or reference
between the parties arising out of the contract. It is specifically provided that no court outside of and other than
the Courts at Kangra/Dharamshala shall have jurisdiction in the matter.

17.

FORCE MAJEURE
Any failure of omission or commission to carry out the provisions of the contract by the supplier shall not give
rise to any claim by either of the party to contact, if such failure of omission or commission arises from an act
of God, which shall include all acts of natural calamities such as fire, flood, earthquake, hurricane or any
pestilence or from civil strikes, compliance with any stature and/ or regulation of the Government, lockouts and
strikes, riots, embargo or from any political or other reasons beyond the supplier’s control including war
(whether declared or not) civil war or state or insurrection provided that notice or the occurrence of any event
by either party to the other shall be given within two weeks from the date of occurrence of such an event which
could be attributed to Force Majeure conditions.

18.

TERMINATION FOR DEFAULT
The college may, without prejudice to any other remedy for breach of contract by written notice of default sent
to the supplier, terminate the contract in whole or in part
i) If the supplier fails to deliver the Books within time specified in the contract, OR.
ii) If the supplier fails to perform any other obligation under the contract.

7

<!-- page 8 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
19.

PRICE FALL CLAUSE
The offer of rates by the tenders will be subject to the price fall clause i.e. if any item is offered at a lower rate
by the tenderer in any other State/ place in India to any other person/ Organisation/Institution, he shall forth
with notify such reduction or sale to Director/Principal, RGGEC Kangra at Nagrota Bagwan (H.P.) and the price
payable for the books supplied to college after the date of coming into force the such reduction or sale, shall
stand correspondingly reduced even to RGGEC Kangra at Nagrota Bagwan (H.P.)

NOTE: - BIDDER must go through these terms and conditions very carefully and submit an undertaking along with
their signature and stamp in token of acceptance of these terms and conditions in a separate sheet. Any further
changes in the terms and conditions of this tender document, if any, shall only be uploaded on the website of this institute.
Hence, the bidders are requested to keep a watch on the same prior to submitting their bids.

8

<!-- page 9 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com

ANNEXURE-A

DETAILS OF BIDDER
1

Name of the Firm

2

Address of the Firm

3

PAN number

4

GST Number

5

6

7

8

Duly Filed Income Tax
Returns/Certified
Balance Sheets of Last
Financial Years
Tender Fee
Transaction no.
Name of Bank/Branch
Date of Issuing
EMD
DD No./ FDR No.
Name of Bank/Branch
Date of Issuing
To whom all reference
shall be made regarding
this tender inquiry.
(Name, Contact no. and
email address.)

Signature

Name
Designation
Company Seal
Date

9

<!-- page 10 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com

ANNEXURE-B

TECHNICAL BID FORMS
CHECK LIST:
Sr. No.

Particulars

1.

Tender document cost @ 500/- attached

Yes/No

2.

EMD 50000/- attached

Yes/No

3.

Copy of GST attached

Yes/No

4.

Copy of PAN attached

Yes/No

6.

Detail of Bidder (Annexure-A)

Yes/No

7.

Forwarding letter (Annexure-C)

Yes/No

8.

Certificate of registration with authorised dealer/publisher

Yes/No

9.

A certificate from a Chartered Accountant (CA) regarding the Annual Turnover
up to three financial years

Yes/No

10.

Income tax returns for the last 3 financial years.

Yes/No

11.

Whether the tender document is duly signed by the authorized signatory is
attached.

Yes/No

Authorized Signatory:

Signature of Tenderer with seal

10

<!-- page 11 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com

ANNEXURE-C
(LETTER HEAD OF THE BIDDER)

FORWARDING LETTER
To
The Director/Principal
Rajiv Gandhi Govt. Engineering College,
Kangra at Nagrota Bagwan, H.P.-176047
Dear Sir,
1. I/We hereby submit our tender for the purchase of library books.
2. I/We

am/are

enclosing

herewith

the

FDR.

/DD

No

……………………………….

Dated………………………………………. for Rs. 50,000/- (Rupees Fifty thousand) only in respect of items at
Annexure-E of the Tender document, duly pledged in favour of the Director/Principal, Rajiv Gandhi Govt.
Engineering College, Kangra towards EMD. (TENDERS NOT ACCOMPANIED WITH EMD/ BID SECURITY
ALONG WITH THE TECHNICAL BID SHALL BE SUMMARILY REJECTED).
3. I/We have gone through all the terms and conditions of the tender documents before submitting the same.
4. I/We hereby agree to all the terms and conditions stipulated by the Rajiv Gandhi Govt. Engineering College Kangra
at Nagrota Bagwan, including inspection, delivery, and penalty, etc.
5. I/We have noted that overwritten entries shall be deleted unless duly cut & rewritten and initialled.
6. Tenders are duly signed (No thumb impression should be affixed.)
7. I/We hereby, undertake to supply all the books mentioned at Annexure-E of this bid document. However, in case
of non-availability of any book, I further undertake to supply at least 80% of books mentioned at Annexure-E of
this bid document.
Note: All terms and conditions, such as taxes, etc., have been indicated in the bid, failing which it will be presumed that
all the rates are inclusive of all taxes and other terms and conditions are also as per your requirement.
Yours faithfully,
Signature of tenderer:
Full address:

11

<!-- page 12 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com

ANNEXURE- D

FINANCIAL BID FORM
Sr.
No.

Book Name

Authors

Publishers

MRP per unit

No. of copies

Total rate

Grand Total
Flat Discount offered on Grand Total (%)
Total Price after Discount

Note: Total amount should be inclusive of all taxes, packing, transportation, loading- unloading etc.

Authorized Signatory:

Signature of Tenderer with seal

12

<!-- page 13 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com

ANNEXURE- E

LIST OF BOOKS
Total no. of Titles – 398
Total no. of Volumes – 2256 (E1 +E2+E3)
Sr.
No.

Annexure No.

Description of Books

No. of Titles

No. of
Volumes

Min. No. of Titles to
be supplied

1.

E1

Academics books for Civil
Engineering Department

115

1053

80% of 115 = 92

2.

E2

Academics books for Civil
Engineering Department

50

970

80% of 50 = 40

3.

E3

Hindi/ English Literature

233

233

80% of 233 = 187

ANNEXURE-E1
E1-List of Books required for College Library - Civil Engineering Department
Sr.
No.

Book Name

Authors

Publishers

1

Fundamentals of Probability & Statistics

Sultan Chand & Sons

10

2

Introduction to Probability & Statistics
Strength of Materials
Strength of Materials

5

Mechanics of Materials

6
7

Hydraulics and Fluid Mechanics Including
Hydraulics Machines
Surveying, Volume-I

Tata Mcgraw Hill
Edition (Schaum's
Outlines)
S Chand Publisher
Laxmi Publication,
New Delhi
Pearson education
india
Standard Book House

10

3
4

S C Gupta & V
K Kapoor
Seymour
Lipschutz &
John Schiller
R. K. Rajput
Dr. B. C.
Punmia
RC Hibbler

5

8
9

Surveying, Volume-I
Building Materials

10

IKS: The Knowledge system of Bharata

Laxmi Publication,
New Delhi
Standard book house
New age international
publisher
Garuda Prakashan

11

Vedic Physics

13

Dr. P.N. MODI
& S.M. SETH
Dr. B. C.
Punmia
Dr. K. R. Arora
S K Duggal
Prof. Bhag
Chand Chauhan
Keshav Dev
Verma

Motilal Banarasidas
Publishers

No. of copies
Required

10
10
1
15

15
15
20
5

<!-- page 14 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
12

Operations Research

J K Sharma

13

Operations Research

Er. P K Gupta &
Dr. D S Hira

14

Artificial Intelligence: Building Intelligent
Systems

Parag Kulkarni
and Prachi Josh

15

Theory of Structure

16
17

Structural Analysis- I
Soil Mechanics and Foundation Engineering

18

Soil Mechanics in Engineering Practice

19

Soil Mechanics and Foundation Engineering

S.
Ramamrutham
& S. Narayan
SS Bhavikatti
B.C. Punmia,
Ashok Kumar
Jain & Arun
Kumar Jain
Karl Terzaghi,
Ralph B Peck ,
Gholamreza
Mesri
Dr. K. R. Arora

20

Surveying, Volume-II

Dr. B.C. Punima

21
22

Engineering surveying-Vol-II
Remote Sensing and GIS

Dr K R Arora
Basudeb Bhatta

23

Fundamentals of Remote Sensing

24

Remote Sensing and Image Interpretation,
6th Edition

25

Building Construction

26

The text book of Building Construction

27
28

Reinforced Concrete Design
Reinforced Concrete: Limit State Design

George Joseph
and C
Jeganathan
Chipman,
Lillesand ,
Kiefer
B.C. Punmia,
Ashok Kumar
Jain & Arun
Kumar Jain
S. P. Arora and
S.P. Bindra
Devdas Menon
A.K. Jain

29

Limit State Design of Reinforced Concrete
(As per IS 456:2000)

30
31

Structural Analysis- II
Structural Analysis

14

BC Punmia,
Ashok Kumar
Jain and Arun
Kumar Jain
SS Bhavikatti
Devdas Menon

Trinity Press (Imprint
of Laxmi Publications)
New Delhi
S. Chand & Company
Pvt. Ltd., Ram Nagar
New Delhi
Prentice Hall India
Learning Private
Limited
Dhanpatrai Publication

10

Vikas Publishing house
Luxmi Publications

10
15

Wiley India Pvt Ltd

1

Standard Publishers

15

Laxmi Publication,
New Delhi
Standard Publishers
Oxford University
Press India
The Orient Blackswan

10

Wiley India Pvt Ltd

10

Luxmi Publications

10

Dhanpat Rai
Publications
Tata McGraw Hill
Nem Chand &
Brothers, Roorkee
Luxmi Publications

5
10
15

Vikas Publishing house
Narosa Publication

10
10

10
20
20

15
10
10

15

<!-- page 15 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
32
33
34
35

Flow in Open Channels
Open-Channel Hydraulics
Flow through Open Channels
Water Supply Engineering

36

39

Environmental Engineering Water Supply
Engineering - Vol.1
Highway Engineering
Principles and practices of Highway
Engineering
Advanced R.C. C. Design (Vol. 2)

K. Subramanya
Ven Te Chow
KG Ranga Raju
Dr. B.C.
Punmia, Er.
Ashok K. Jain,
Dr. Arun K. Jain
Santosh Kumar
Garg
Khanna & Justo
L.R. Kadiyali, N
B Lal
S.S. Bhavikatti

40
41
42

Design of Reinforced Concrete Structures
Text Book of Railway Engineering
Airport Planning & Design

S Ramamrutham
SC Suxena
Khanna & Arora

43

Environmental Engineering

44
45
46

Environmental Engineering Water Supply
Engineering - Vol. II
Engineering Hydrology
Engineering Hydrology

47

Hydrology: Principles, Analysis, Design

Howard S.
Peavy
Santosh Kumar
Garg
K Subramanya
Rajesh
Srivastava and
Ashu Jain
HM Raghunath

48
49
50

Fundamentals and applications of rock
mechanics
Engineering and general geology
Engineering Geology

51
52

Rock Mechanics for Engineers
Concrete technology, theory and practice

53

Concrete technology, theory and practice

Parbin Singh
Subinoy
Gangopadhyay
B P Verma
M.S. Shetty &
A.K. Jain
SS Bhavikatti

54

Properties of Concrete

Neville

55

A Textbook of Fluid Mechanics and
Hydraulic Machine
A Textbook of Hydraulic Machines
Design and Drawing of Steel Structures
Design of Steel structures

Dr R.K. Bansal

37
38

56
57
58

15

Devashis Dev

R.K. Rajput
SS Bhavikatti
S K Duggal

Tata McGraw Hill
The Blackburn Press
Tata McGraw Hill
Laxmi Publications

20
1
10
10

Khanna Publisher

15

Nem Chand & Bros
Khanna Publisher

10
10

New Age International
Publishers
Dhanpatrai Publication
Dhanpatrai Publication
Nem Chand
Publications
McGraw Hill
Education
Khanna Publisher

10

McGraw Hill
McGraw Hill

15
5

New Age International
Publishers
PHI Learning

10

SK Kataria & sons
Oxford University
Press
Khanna Publishers
S. Chand Publisher

20
10

IK International
Publishing house Pvt.
Ltd.
Pearson Education
India
Laxmi Publications (P)
Ltd
S Chand & Co Ltd
Dreamtech Press
McGraw Hill
Education

10

10
10
10
10
15

5

10
20

10
10
10
10
10

<!-- page 16 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
59
60
61
62

Estimating and Costing in Civil Engineering
Theory and Practice
Estimating, Costing, Specification and
Valuation in Civil Engineering
Irrigation Engineering & Hydraulic
Structures
Irrigation and Water Power Engineering

63
64

Hydrology and Water resource Engineering
Construction, Planning, Equipment and
Methods

65

Project Planning and Control with PERT and
CPM

66
67
68

Solid and Hazardous Waste Management
Dynamics of Structures
Earthquake Resistant Design of Structures

69

Ground Improvement Techniques

70

Environmental Impact Assessment
Methodologies

71

Design of Bridges

72

Essentials Of Bridge Engineering

73

Handbook on Concrete Reinforcement and
Detailing
Geotechnical Engineering_: Principles and
practices of soil mechanics and foundation
engineering
Limit Analysis and Soil Plasticity

74
75

B.N. Dutta
M. Chakraborti
SK Garg
BC Punmia,
Ashok Kumar
Jain and Arun
Kumar Jain
SK Garg
Peurify and
Schexnayder
and Shapira
B.C. Punmia
and K.K.
Khandelwal
M.N Rao
A K Chopra
SK Duggal
BC
Chattopadhyaya,
J. Maity
Anjaneyulu
Yerramilli
(Author), Valli
Manickam
N Krishna Raju
D Johnson
Victor
Bureau of Indian
Standards
V.N.S. Murthy
Chen

76

Soil Testing in theory and Practice Vol
11Geotechnical Testing and Instrumentation

Alam Singh

77

Soil Lab Manual

Das

78

Principles of Foundation Engineering

Das

79

Principles of Geotechnical Engineering

Das

16

CBS Publishers and
Distributors Pvt. Ltd.
M.K. Publishers and
Distributors
Khanna Publishers

10

Laxmi Publications

5

Khanna Publishers
Tata McGraw Hill
Higher Education.

10
10

Laxmi Publications (P)
Ltd

10

BS Publication
Pearson Education
Oxford University
Press
PHI Learning

10
10
10

BS Publications / BSP
Books

5

Oxford & IBH
Publishing Pvt Ltd
Oxford & IBH
Publishing Pvt Ltd
Bureau of Indian
Standards
CBS Publishers and
distributors
New Delhi
Cenage learning India
Edition
CBS Publishers and
distributors
New Delhi
Cenage learning India
Edition
Cenage learning India
Edition
Cenage learning India
Edition

5

20
15

5

5
5
5
10
10
5
10
10

<!-- page 17 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
80

Textbook of Geotechnical Engineering

Das

81

Geotextiles-Emerging Trends

82

Reinforced Concrete

83
84
85

Reinforced Concrete Design
Concrete Technology
Plasticity in Reinforced Concrete

G. Venkatappa
Rao & K Balan
I.C. Syal and
A.K. Goel
S.N. Sinha
M.S. Shetty
Chen

86
87

Concrete Lab Manual
Concrete Lab Manual

88
89

Theory of Beam-Columns, Volume 2: Space
Behaviour and Design
Plain and Reinforced Concrete Vol. I

90

Limit state design and reinforced concrete

Jai Krishna &
O.P. Jain
P.C. Varghese

91

Design Of Reinforced concrete Structures

M.L. Gambhir

92

Properties of Concrete

A.M. Neville

93
94

Earthquake Resistant Design of Structures
Earthquake Resistant Design of Structures

95
96

Earthquake Resistant Building Construction
Earthquake Resistant Design of Structures

B.L. Gupta
Aggarwal and
Shrikhande
Neelam Sharma
Agarwal p

97

Analysis &Design of Substructures
(Limit State Design)
Geotechnical Engineering

Swami Saran

Made Easy

103

GATE 2025-Civil Engineering
ESE-2025 Preliminary Exam: Civil
Engineering Objective Solved Paper Vol-1
ESE-2025 Preliminary Exam: Civil
Engineering Objective Solved Paper Vol-2
GATE-2025: Civil Engineering Previous
Year Solved Papers
GATE 2025-Civil Engineering

104

A Handbook on Civil Engineering

105

Civil Engineering for Competitions

MADE EASY
Editorial Board
R. Agor

98
99
100
101
102

17

M.L. Gambhir
Bureau of Indian
Standards
Chen

C. Venkatramaia

Made Easy
Made Easy
IES Masters

Cenage learning India
Edition
Kerala state Coir
Crop., Allpazha
A.H. Wheeler and Co.
Delhi
Tata McGraw Hill
S.Chand Publisher
Cenage learning India
Edition
Tata McGraw Hill
Publishing House New
Delhi
Cenage learning India
Edition
Nem Chand & Bros
Roorkee
Oxford and IBH
Publishing Pvt Ltd
Standard Publishers
Distributors
Pearson education
India
Standard Publishers
Prentice Hall of India

10

S.K.Kataria and Sons
Standard Publishers
And Distributors
Standard Publishers
And Distributors
New Age
International
Publisher, New Delhi
GK Publications
Made Easy
Publications
Made Easy
Publications
Made Easy
Publications
IES Masters
Publications
MADE EASY
Publications
Khanna Publishers

10
5

5
5
5
5
5
5
5
5
10
5
5
5
10
10

5
15
10
5
5
5
10
5
5

<!-- page 18 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
106
107
108
109
110
111
112
113
114
115

18

SSC-JE 2025 Civil Engineering Previous
Years Topic Wise Objective Detailed
Solution With Theory
Ese 2025 Civil Engineering Topic wise
Solved Paper-I
ESE 2025 Civil Engineering topic wise
solved paper-II
SSC JE Civil Conventional Papers
SSC : JE Civil Engineering(2024) - Previous
Year Conventional Solved Papers- 2
ESE 2025 Mains Examination Civil
Engineering Conventional Paper- I
ESE 2025: Mains Examination: Civil
Engineering Conventional Paper - II
GATE 2025: Engineering Mathematics for
GATE and ESE (Prelims)-Theory and
Previous Year Solved Papers
GATE 2025 : Reasoning & Aptitude for
GATE and ESE (Prelims) - Theory and
Previous Year Solved Papers
General English for GATE and PSUs: 2025

IES MASTER
Team

IES Master
Publications

5

IES MASTER
Team
IES MASTER
Team
IES MASTER
Team
MADE EASY
Team
MADE EASY
Team
MADE EASY
Team
MADE EASY
Team

IES Master
Publications
IES Master
Publications
IES Master
Publications
Made Easy
Publications
Made Easy
Publications
Made Easy
Publications
Made Easy
Publications

5

MADE EASY
Team

Made Easy
Publications

5

MADE EASY
Team

Made Easy
Publications

5

5
5
5
5
5
5

<!-- page 19 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com

ANNEXURE-E2
E-2 List of EED Books required for creating Book Bank in the library
Sr.
No.

Book Name

Authors

Publishers

No. of copies
required

1

Analysis of Electric Machinery and
Drive system

Wiley

20

2

Generalized theory of electrical machines

Paul C. Krause,
Oleg Wasynczuk,
Scott D. Sudhoff
P.S. Bimbhra

20

3

P.S. Bimbhra

IEEE Press, Standard
Publisher and
Distributors, 2001
Prentice Hall of India
TMH

5

5
6

Power Electronics ( 7th edition (1
January 2022))
Power Electronics and Variable
Frequency Drive- Technology and
Application
Digital Design,
Modern Digital Electronics

Khanna Publishers,
Delhi
Khanna Publishers

7

Engineering Circuit Analysis

TMH

20

8

Circuits and Networks- Analysis and
Synthesis
Electric Machinery
Electrical Machinery
Electrical Measurements And Measuring
Instruments
Power System Engineering | 3rd Edition

WiliamHayt and
Jack Kemmerly
A. Sudhakar and S.P.
Shyam Mohan
Fitzgerald&Kingsley
P.S. Bimbhra
A.K. Sawhney

TMH

20

MGH
Khanna Publishers
Dhanpat Rai & Co.

20
20
20

D. P. Kothari;I. J.
Nagrath
C L Wadhwa

McGraw-Hill;

20
20

B.P. Lathi

New Age International
Private Limited
Oxford

Simon haykin
P.S.Bimbhra

Wiley
Khanna Publishers

20
20

B.S. Manke
M Gopal and I J
Nagrath
Dr. B. R. Gupta
A.K. Chakrabathi,
Soni Gupta
Bhatnagar

Khanna Publishers
New Age International
Private Limited
S. Chand
Dhanpat Rai Publisher

20
20

Mc-Graw Hill
Education
New Age International
Private Limited
TMH
Oxford
AJohn Wiley & sons
inc. publication

20

4

9
10
11
12
13

17
18

Electrical Power Systems (Eighth edition
(1 January 2022))
Modern Digital and Analog
communication systems
Communication Systems
Power Electronics ( 7th edition (1
January 2022))
Linear Control System
Control System Engineering

19
20

Generation of electrical energy
A course in electrical power

21

High-Voltage Engineering | 6th Edition

22

High Voltage Engineering Fourth edition
(1 December 2020)
Engineering Electromagnetic
Principles of Electromagnetics
Thyristor Based FACTS Controllers for
Electrical Transmission Systems

14
15
16

23
24
25

19

Bose. B.K.
M. Morris Mano
R.P. Jain,

C. L. Wadhwa
Hayt
Mathew N.O Sadiku
R Mohan Mathur
and Rajiv K Varma

20

20
20

20

20
20

20
20
20
20

<!-- page 20 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
26

28

Understanding Facts: Concepts and
Technology of Flexible AC Transmission
Systems
Non-Conventional Energy Resources |
3rd Edition
Robotics and Control

29
30

A course in Electrical Power
Microprocessor and Microcontroller

31

Microprocessor Architecture,
Programming and Applications with the
8085 6/e

Ramesh Goankar

32

Modern Power System Analysis | 5th
Edition

33

Power system Analysis

34

Fundamentals of Electrical Drives

D P Kothari
(Author), I J Nagrath
(Author), R K Saket
J.J. Grainger, W.D.
Stevenson
G.K. Dubey

35

Digital Signal Processing – 7th Edn.

Ramesh Babu

36

Digital Signal Processing : Principles,
Algorithms, and Applications 4 Edition

37

Utilization Of Electric Energy: Including
Electric Drives And Electric Traction
Art And Science Of Utilisation Of
Electrical Energy
Electric Illumination

Dimitris G
Manolakis, John G.
Proakis
Tarlok Singh

27

38
39
40
41
42
43
44
45
46
47
48
49
50

20

Introduction to Artificial Neural System
Neural Network- Algorithm, applications
and programming Technique
Handbook of Energy Audits
Power Quality
Power Quality
Non-Conventional Energy Resources
Electrical Machine Design
Power station design
Testing , Commissioning , Operation and
Maintenance of Electrical Equipment
Power System Planning
Power Electronics : Circuits Devices and
Applications

Narain G. Hingorani

Wiley India Pvt Ltd

20

B.H. Khan

McGraw Hill Education
India Private Limited
McGraw Hill Education

20

S.K. Kataria & Sons
Dhanpat Rai
Publications
Penram International
Publishing India Pvt
Ltd.

20
20

McGraw Hill

20

Mc-Graw Hill
Education
Alpha science
International Ltd, 2001
SCITECH
PUBLICATIONS
(INDIA) PVT. LTD.
Pearson

20

S.K. Kataria & Sons

20

H. Pratab

Dhanpat Rai & Co.

20

John O.
Kraehenbueshl
Jacek M Zurada
J.A. Freeman

John Wiley & Sons

20

Jaico Publishing House
Addison weley

20
20

Abbi, Y.P. and Jain
Bipin Singh Simmi
P. Burman
C. Sankaran
G.D Rai
A.K. Sawhney
M.V. Deshpande
S. Rao

S. Teri Press
S.K. Kataria and Sons

20
20

CRC Press

20
20
20
20
20

R.L. SUllivan

Tata McGraw Hill
Publishing Company
Ltd, 2012
Prencetice hall of India
Ltd. , 2004

R Mittle (Author), I
Nagrath
J.B Gupta
B Ram

M.H. Rashid

Dhanpat rai
PHI Publication.
Khanna Publishers

5

20

20
20
20

20
20

<!-- page 21 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com

ANNEXURE-E3
E3- List of Hindi /English Literature Books for College Library
Sr.
No.
1

Name of Book

Author

Publisher

Quantity

HP General knowledge (3rd Edition)

Jokta Academy

1

2

Atomic Habits

Suresh Jokta And
Vikash Kumar
James Clear

1

3

Harry Potter complete book series

J.K. Rowling

Random House
Business Books
Harry Potter Books Set

4

Indian GK 2024

Lucent

Lucent publication

1

5

Autobiography of a Yogi
The life of Indira Nehru Gandhi

Yogoda Satsanga
Society of India
Harper Perennial

1

6

Paramhansa
Yogananda
Katherine Frank

7

The art of Happiness

Dalai Lama

Hodder Paperbacks

1

8

Hitchhiker's guide to galaxy complete set

Douglas Adams

Pan Macmillan

1

9

The Great Gatsby

F.Scott Fitzgerald

1

10

Hamlet

11

To Kill a Mockingbird

William
Shakespeare
Harper Lee

Vayu Education of
India
Maanu Graphics
Arrow Books Ltd

1

12

Pride and Prejudice

Jane Austen

Fingerprint! Publishing

1

13

500

Stephanie Meyer

MacLehose Press

1

14

The Subtle Art of Not Giving a F*ck

Mark Manson

HarperCollins
Publisher India Pvt Ltd

1

15

A song of ice and fire

George R.R. Martin

HarperCollins
Publisher India Pvt Ltd

1

16

theory of everything

Stephen Hawking

Jaico Publishing House

1

17

Tomb of sand

Geetanjali Shree

Penguin Random
House India Pvt. Ltd

1

18

The Lamplighters

Emma Stonex

Picador Publishers

1

19

Mahasamar (1-9)

Narendra Kohli

Vani Prakashan

1

20

The Palace of Illusions

Picador India

1

21

Books by Premchand complete set

Chitra Banerjee
Divakaruni
Prem Chand

Maple Press

1

22

Bhagwat Geeta (Hindi)

Iskcon

1

23

The Bhagwat Gita : Symphony of the
Spirit (Hindi)
Persuasion

RR Varma

Bhaktivedanta Book
Trust
Fingerprint! Publishing

Jane Auston

Maple Press

1

24

21

1

1

1

1

<!-- page 22 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
25

The Martian

Andy Weir

Ballantine Books

1

26

Guide

RK Narayan

1

27

Rich dad poor dad

Robert T. Kiyosaki

Indian Thought
Publications
Plata Publishing

28

The Story of My Life

Helen Keller

Fingerprint! Publishing

1

29

100 great business ideas

Jeremy Kourdi

Embassy Books

1

30

The world's best business ideas

Ian Wallis

Jaico Publishing House

1

31

Idea to execution

Nick Sonnerberg

Lioncrest Publishing

1

32

Profit first

Mike Micholowicz

Portfolio Publisher

1

33

Surely You're Joking Mr Feynman

Richard Feyman

Vintage Publishing

1

34

Side hustle

Chris Guillebeau

Pan Macmillan

1

35

Invent it, sell it, bank it

Lori greiner

Ballantine Books

1

36

before you start up

Pankaj Goyal

Fingerprint! Publishing

1

37

The Secret

Rhonda Byrne

Simon & Schuster UK

1

38

Last Queen

Chitra Banerjee
Divakaruni

HarperCollins
Publisher India Pvt Ltd

1

39

How to patent an idea in India

Prasad Karhad

1

40

Satyajit Ray

41

The final adventures of Professor
Shonku
Sapiens

Independently
Published
Penguin Random
House India
Vintage Books

42

Shiva trilogy set

Amish Tripathi

HarperCollins
Publisher India Pvt Ltd

1

43

A thousand splendid suns

Khaled Hosseini

1

44

Geetanjli

Ravindernath Tagore

45

Little women

Louisa May Alcott

46

Devdutt Patnayak

47

Sita : An Illustrated Retelling of
Ramayana
The girl who drank the moon

Bloomsbury
Paperbacks
Rajkamal Prakashan
Pvt. Ltd
Vintage Children's
Classics
Penguin India

1

48

The perfect murder

Ruskin Bond

Algonquin Young
Readers
Rupa Publications India

49

Blue Umbrella

Ruskin Bond

Rupa Publications India

1

50

7 Secrets of Shiva

Devdutt Patnayak

Westland Books

1

51

The palace of illusions

Picador India

1

52

Jaya

Chitra Banerjee
Divakaruni
Devdutt Patnayak

Penguin India

1

53

My Gita

Devdutt Patnayak

Rupa Publications India

1

22

Yuval Noah Harari

Kelly Barnhill

1

1
1

1
1
1

1

<!-- page 23 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
54

Yoga Mythology

Devdutt Patnayak

HarperCollins
Publisher India Pvt Ltd

1

55

Benjamin Franklin

Fingerprint! Pub

1

Nikola tesla

Ingram short title

1

57

The Autobiography of Benjamin
Franklin
My Inventions: The Autobiography of
Nikola Tesla
The Immortals of Meluha (Hindi)

Amish Tripathi

Harper Hindi

1

58

The secret of Nagas (Hindi)

Amish Tripathi

Harper Hindi

1

59

Scion of Ikshvaku

Amish Tripathi

HarperCollins
Publisher India Pvt Ltd

1

60

The oath of the Vayuputras (Hindi)

Amish Tripathi

Harper Hindi

1

61

War of Lanka

Amish Tripathi

HarperCollins
Publisher India Pvt Ltd

1

62

Sita

Amish Tripathi

HarperCollins
Publisher India Pvt Ltd

1

63

Raavan: Enemy of Aryavarta

Amish Tripathi

HarperCollins
Publisher India Pvt Ltd

1

64

Legend of Suheldev

Amish Tripathi

HarperCollins
Publisher India Pvt Ltd

1

65

Suheldev and the battel of Baharaich

Amish Tripathi

HarperCollins
Publisher India Pvt Ltd

1

66

Immortal India

Amish Tripathi

HarperCollins
Publisher India Pvt Ltd

1

67

Dharma: Decoding the epics

Amish Tripathi

HarperCollins
Publisher India Pvt Ltd

1

68

Dharmayoddha Kalki: Avatar of Vishnu

Kevin Missal

Fingerprint! Publishing

1

69

An Era of darkness

Shashi Tharoor

Aleph Book Company

1

70

Foundation

Isaac Asimov

HarperVoyager

1

71

The Da Vinci Code

Dan Brown

Corgi Books

1

72

Deception Point

Dan Brown

Corgi Books

1

73

40 Rules of Love

Elif shafak

1

74

Contact

Carl Sagan

Penguin random House
India
Orbit Books

75

Elon Musk

Ashlee Vance

Virgin Books

1

76

Into the wild

Jon Krakauer

Pan Macmillan

1

77

Shoe Dog

Phil Knight

Simon & Schuster

1

78

The Upanishads

Swami Paramananda

Prakash Books India

1

79

Reflections: Swami Vivekananda

Swami Vivekananda

Om Books
International

1

56

23

1

<!-- page 24 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
80

City of Djinns: A Year in Delhi

William Dalrymple

Penguin Books

1

81

William Dalrymple

Penguin India

1

82

The Age of Kali: Indian Travels and
Encounters
The Power of your Subconscious Mind

Joseph Murphy

1

83

Naruto, Volume 1

Masashi Kishimoto

Srishti Publishers &
Distributors
Simon & Schuster India

84

Naruto, Volume 2

Masashi Kishimoto

Simon & Schuster India

1

85

Naruto, Volume 3

Masashi Kishimoto

Simon & Schuster India

1

86

Buddha

Deepak Chopra

HarperCollins
Publisher India Pvt Ltd

1

87

Sophie's world

Jostein Gaarder

1

88

Certificate Physical and Human
Geography (Indian edition)

89

A brief History of Modern India(2022
edition)

Spectrum Books Pvt.
Ltd.

1

90

Oxford Student Atlas for India(4th
Edition)
Answer Book,10001 Fast Facts About
our World
Knowledge Encyclopaedia Art and
Architecture
1001 Inventions That Changed The
World Since 26,00,000 BCE

Goh Cheng Leong
(Oxford University
Press)
Rajiv Ahir
(Spectrum Books
Pvt. Ltd)
Oxford University
Press
Hector sierra

Orion Publishing
Group
Oxford University
Press

Oxford University
Press
National geographic

1

Wonder House Books

1
1

91
92

1

1

1

94

National Geographic Know Your World

Wonder House
Books
Hachette Book
Publishing India Pvt.
Ltd.
National geographic

95

Introduction to UPANISHADS

Acharya Prashant

96

Think on These Things

J. Krishnamurti

97

Freedom from the known

J. Krishnamurti

98

Bhagavad Gita ( English)

A. C. Bhaktivedanta
Swami Prabhupad

Hachette Book
Publishing India Pvt.
Ltd.
Impulse Marketing,
609, Elegance Tower,
Jasola District Center,
New Delhi, India'
PrashantAdvait
Foundation
Krishnamurti
Foundation India
Krishnamurti
Foundation India
Bhaktivedanta Book
Trust

99

Shrimad Bhagwat Geeta Yatharoop
(Hindi)

A.C. Bhaktivendanta
Swami Prabhupada

Bhaktivedanta Book
Trust

1

100

Advaita Vedanta

Swami Vivekananda

Advaita Ashrama, India

1

101

The Awakening Of Intelligence

J. Krishnamurti

KFI Publications

1

102

Private Life of an Indian Prince

Mulk Raj Anand

HarperCollins
Publisher India Pvt Ltd

1

93

24

1

1
1
1
1

<!-- page 25 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
103

Gone with the wind

Margaret Mitchel

Fingerprint! Publishing

1

104

In Search Of Schrodinger's Cat

Gribbin, John

RHUK Publisher

1

105

Black Holes (L) : The Reith Lectures

Stephen Hawking

Bantam Books

1

106

Albert Einstein

Rupa Publications India

1

107

Relativity: The Special And The General
Theory
The Lord of the Rings

J. R. R. Tolkien

HarperCollins
Publisher India Pvt Ltd

1

108

The Time Machine

H G Wells

Fingerprint! Publishing

1

109

Arthur Conan Doyle

Fingerprint Publishing

1

110

The Complete Novel of Sherlock
Holmes
Kashi Ka Assi (Hindi Edition)

Kashinath Singh

Rajkamal Prakashan

1

111

White as Milk and Rice

Penguin Ebury Press

1

112

Jeevan Jine Ki Kala

Nidhi Dugar
Kundalia
Anand Satyarthi

Diamond Books

1

113

Dhayan sutra

Osho

Diamond Books

1

114

Rashmirathi (Hindi edition)
Akbar & His India

116

How to Avoid a Climate Disaster

Bill Gates

Lokbharti Prakashan
Pvt Ltd
Oxford University
Press
Penguine Books Ltd

1

115

Ramdhari Singh
Dinkar
Habib Irfan

117

David WallaceWells
Richard Dawkins

Penguin Books Ltd

1

118

The Uninhabitable Earth: Life After
Warming
Blind Watchmaker

Penguin Books Ltd

1

119

Dragon Ball Super, Vol. 1

Akira Toriyama

VIZ Media LLC

1

120

Dragon Ball Z, (Vol. 1-Vol-5)

Akira Toriyama

VIZ Media LLC

1

121

One Piece Vol 1 Comic

Author Eiichiro Oda

Viz Media, Subs. of
Shogakukan Inc

1

122

Death Note Black Edition, Vol. 1

Takeshi Obata and
Tsugumi Ohba

Simon & Schuster India

1

123

Death Note Black Edition, Vol. 2

Takeshi Obata and
Tsugumi Ohba

Simon & Schuster India

1

124

Death Note Black Edition, Vol. 3

Takeshi Obata and
Tsugumi Ohba

Simon & Schuster India

1

125

Homo Deus

Yuval Noah Harari

Vintage Books

1

126

Do Epic Shit

Ankur Warikoo

Juggernaut Books

1

127

Iron widow

Xiran Jay Zhao

Rock the Boat Books

1

128

The Guide

RK Narayan

1

129

Malgudi Days

RK Narayan

Indian Thought
Publications
Indian Thought
Publications

25

1
1

1

<!-- page 26 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
130

Cosmos

Carl Sagan

Abacus Books

1

131

Magic of Reality

Richard Dawkins

1

132

Greatest show on earth

Richard Dawkins

133

The Origin of Species

Charles Darwin

Transworld Publishers
Ltd
Transworld Publishers
Ltd
Fingerprint! Publishing

134

The Great arc

John Key

Harper Press

1

135

ISRO:A Personal History

R. Aravamudan

HarperCollins
Publisher India Pvt Ltd

1

136

The Dark Holds No Terrors

Shashi Deshpande

1

137

That Long Silence

Shashi Deshpande

138

Sister of my Heart

139

Vine of Desire

140

The Forest of Enchantments

Chitra Banerjee
Divakaruni
Chitra Banerjee
Divakaruni
Chitra Banerjee
Divakaruni

Penguin Random
House India
Penguin Random
House India
Penguin Random
House India
Little, Brown Book
Group
HarperCollins
Publisher India Pvt Ltd

141

The Secret

Rhonda Byrne

1

142

Women who run with the wolves

Clarissa Pinkola

Manjul Publishing
House
Ballantine Books

143

You are born to blossom

APJ Abdul Kalam

Prabhat Prakashan

1

144

The Universe Always Has a Plan

Matt Kahn

1

145

That Long Silence

Shashi Deshpande

Hay House Publishers
India
Penguin India

146

Thick Nhat Hanh

Rider & Co

1

147

Silence: The Power of quiet in the world
full of noise
A thousand splendid suns

Khalid Husseini

1

148

The seeker of Nothing

Kabir Munjal

Bloomsbury
Paperbacks
Kabir Munjal

149

Three thousand stitches

Sudha Murti

Penguin India

1

150

Shreemad Bhagwad Geeta Yatharth
Geeta (Hindi)

Swami Adgadanand

1

151

Project Hail Mary

Andy Weir

Shree Paramhans
Swami Adgadanandji
Trust
Ballantine Books

152

Rafa :My story
Dawn of the Raj

154
155

There are rivers in the sky
Ikigai

Little, Brown Book
Group
Srishti Publishers &
Distributors
Penguin India
Diamond Books

1

153

Rafael Nadal, John
Carlin
Ranjit Mishra

156

Verity

Sphere books Ltd

1

26

Elif shafak
Francesc García,
Héctor, Miralles
Collen Hoover

1
1

1
1
1
1

1

1

1

1

1
1
1

<!-- page 27 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
157

It ends with us

Collen Hoover

Atria books

1

158

Demon Slayer Volume 1-23

Koyoharu Gotouge

1

159

The Brothers Karamazov

Fyodor Dostoevsky

160
161

The Hidden Hindu (set of 3)
The Boy Who Did Not Sign

Akshat Gupta
Ashish Ranjan

Viz Media, Subs. of
Shogakukan Inc
OM Books
International
Penguin eBury Press
Notion Press

162

The Tell-Tale Brain

V. S. Ramachandran

163

Why Bharat Matters

Dr. S Jaishankar

PenguineRandon House 1
India Pvt Ltd
Rupa Publications India 1

164

Behave

Robert M Sapolsky

Vintage Books

1

165

Revolution 2020

Chetan Bhagat

Rupa publications India

1

166

Brain That Changes Itself

Norman Doidge

Penguine UK

1

167

Manav Samaz

Rahul Sakratiyayan

Lokbharti Prakashan

1

168

Crime and Punishment

Fyodor Dostoevsky

1

169

Tumhari Kshay

Rahul Sakratiyayan

Om Books
International
Rahul foundation

170

Dimagi Gulami

Rahul Sakratiyayan

1

171

What Every Body is Saying

Joe Navarro

172

S. Hussain Zaidi

173

R.A.W HITMAN the real story of agent
Lima
The Art of Being

Sanage publishing
house
William Morrow
Paperbacks
Simon &Schuster India

Erich Fromm

Robinson Books

1

174

THE 48 LAWS OF POWER

Robert Greene

Profile Books

1

175

Kane and Abel

Jeffry Archer

Pan Macmillan

1

176

Not a Penny More, Not a Penny Less

Jeffry Archer

Pan Macmillan

1

177

As the Crow Flies

Jeffry Archer

Pan Macmillan

1

178

The Fourth Estate

Jeffry Archer

Pan Macmillan

1

179

The Prisoner of Birth

Jeffry Archer

Pan Macmillan

1

180

And Thereby Hangs a Tale

Jeffry Archer

Pan Macmillan

1

181

The Hobbit

J.R.R Tolkein

Pan Macmillan

1

182

The Tibetan Book of the Dead

Dalai lama

Penguin classics

1

183

Chess Fundamentals

J.R. Capablanca

Grapevine India

1

184

The book of 5 rings

Miyamoto Musashi

1

185

Think like a monk

Jay Shetty

Shambhala Publications
Inc
HarperCollins
Publisher India Pvt Ltd

186

The Diary of CEO

Steven Bartlett

Ebury Publishing

1

27

1
1
1

1

1
1

1

<!-- page 28 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
187

The art of being alone

Renuka Gavrani

Manjul Publishing
House Pvt Lt
HarperCollins
Publisher India Pvt Ltd

1

188

Lord of the Rings (3 set of box)

J.R.R Tolkein

189

Angels and Demons

Dan Brown

Corgi Books

1

190

Inferno

Dan Brown

Corgi Books

1

191

The Lost Symbol

Dan Brown

Corgi Books

1

192

Digital Fortress

Dan Brown

Corgi Books

1

193

Origin

Dan Brown

Corgi Books

1

194

Mortal Engines

Philip Reeve

Scholastic corporation

1

195

India's most fearless Vol 1
Predator's Gold

Penguin Random
House India
Scholastic corporation

1

196

Shiv Aroor and
Rahul Singh
Philip Reeve

197

Infernal Devices Vol-I

Philip Reeve

Walker Books

1

198

Steve jobs Biography

Walter Issacson

1

199

Assistant commandant :CAPF (Hindi)

Drishti

Little, Brown Book
Group
Drishti

200

Airbus vs Boeing

Rajat Narang

Notion Press

1

201

Percy Jackson( 5 book set)

Rick Riordan

Puffin Books

1

202

Heros of Olympus (5 book set)

Rick riordan

Puffin Books

1

203

Vishwadarshan, A Glimpse of the
Universe
How to Win at Chess: The Ultimate
Guide for Beginners and Beyond

Mahatma Ramratna
Thapaliyal
levi rosman

Fingerprint! publishers

1

Penguine Random
House India

1

205

The descent of AIR INDIA

Jitendra Bhargav

Jitendra Bhargav

1

206

The science of mind Management

Rupa Publications

1

207

The India way

Swami Mukunda
Nanda
S. JAISHANKAR

HarperCollins
Publisher India Pvt Ltd

1

208

India that is Bharat

J SAI DEEPAK

Bloomsburry India

1

209

The 5AM Club

ROBIN SHARMA

Goyal Prakashan

1

210

The Laws of human nature

Robert Greene

Profile Books

1

211

Karma : A Yogis Guide to crafting your
destiny
Mindset : how can you fulfil your
potential
The Mountain Is You

Sadhguru

Penguin publisher

1

Carol S. Dweck

1

Sky High the untold story of Indigo
airlines

Tarun Shukla

Constable and
Robinson Ltd
Amaryllis (An Imprint
of Manjul Publishing
House)
Harper Businesses

204

212
213
214

28

Brianna Wiest

1

1

1

1
1

<!-- page 29 -->

OFFICE OF THE DIRECTOR CUM PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN
Distt. Kangra 176047, Himachal Pradesh
PH./FAX 01892-249188, Email: rggec.office@gmail.com
215

The compound effect

Darren Hardy

Manjul publishing
house
Wisdom Tree India

1

216

Dopamine Detox

Thibaut Meurisse

217

Think Straight

Darius Foroux

Penguin random House
India Ltd
Piatkus Publication

1

218

Deep Work

Cal Newport

219

Do It Today

Darius Foroux

1

Pema Chodron

Penguin random House
India Ltd
Maple Press Pvt Ltd

220

When Things Fall Apart

221

My Life and Work

Henry Ford

Maple Press Pvt Ltd

1

222

Twisted series 4 book set

Ana Huang

Boba press

1

223

White Nights

Fyodor Dostoyevsky

1

224

Murder in the Family

Cara Hunter

225

One Arranged Murder

Chetan Bhagat

226

The Lost Bookshop

Evie Woods

227

The Pumpkin Spice Café

Laurie Gilmore

228

The Midnight Library

Matt Haig

Penguin random House
India Ltd
HarperCollins
Publisher India
HarperCollins
Publisher India
One More Chapter
Books
One More Chapter
Books
Canongate Books

229

Butcher and Blackbird

Brynne Weaver

1

230

A Court of Thorns and Roses

Sarah J. Maas

Little, Brown Book
Group
Bloomsbury Publishing

231

The Bell Jar

Sylvia Path

Rupa Publications

1

232

Good Girl Bad Blood

Holly Jackson

1

233

Icebreaker

Hannah Grace

HarperCollins
Publisher India
Coleen Hoover Books

29

1

1

1

1
1
1
1
1

1

1
