---
doc_id: "34aa96ef6ef5aa1c"
source_url: "https://ayurveda.hp.gov.in/Notification.pdf"
ministry: "Ayurveda Department, Himachal Pradesh"
title: "Notification regarding fee structure committee of AYUSH VIBHAG"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "676fad5fb99137c6"
---

<!-- page 1 -->

| a ee aes eee se 2772. -287 58-५9 52 :79%७52827%::: ५
* i
| at MY ye
G “aa हे 3५३ ॥
| | zovernment of Himachal Pradesh & 3 Z
ley ५ AYUSH VIBHAG Ly 7 wee q_ |
| | > No. AYU-B(I2)-3/206 Dated, Shimla-2, the 926 Pa 2 pet
\ 2, Ff
| NOTIFICATION A 7 |
: noe a ० ‘, Pep छः ;
Oe The G . ot . Ss. Fo] FLO
ars "he Governor, Himachal Pradesh, is pleased to constitute--~*
ye a Fee Structure Committee to consider the fee proposals submitted by the
9 2 we iS Private Ayush Training Institutions for conducting various Ayush courses and |
A Pa to submit its recommendations to the Government after taking into |
ice yD’ consideration whether the proposed fee structure is sufficient for generating
Ww >>... tesources for meeting the recurring expenditure of the Private Institutions and |
8 Savings required for further developments of the Institutions and also not
4 unreasonably excessive, The composition of the Committee will be as under:-
vector ae Name and address for correspondences पलक या
D rec 2. ii | Director Ayush, Himachal Pradesh | Chairperson
Ay? Ay Bs Director, Technical Education, Vocational and Member
a Industrial Training, Himachal Pradesh or his
_ representative
Seibel d oJ 6 Economic Advisor, Department of Economics | Member
& Statistics, Govt. of H.P. Shimla or his व
fs representative
| 6 [err 4, Addl./Joint Director (Admin.), Ayush, H.P. Member Secretary ढ
Bis Deputy Director Ayush (Shimla Zone) Member
{re Secretary, H.P. Technical Education Board, | Member
९५४ Dharmshala
t =e TT, Principal, RGGPG Ayurvedic College & | Member
AN ‘ P: . 3 .
Hospital, Paprola (Kangra) or his representative
having specialization in Panchkarma
8. | Medical Superintendent, RAH Chhota Shimla
Section Officer (SAS) Directorate Ayush, | Member
Shimla __ |
0. Representative of the concerned Private | Member
Institute
The term and conditions for the above "Fee Structure
Committee" shall be as under:-
i No honorarium and allowances shall be payable to the members
of the Fee Structure Committee (Ayush). However, normal
TA/DA as per entitlement will be admissible. ~
a The headquarter of the Fee Structure Committee (Ayush) shall be
the office of Director, Ayush, Himachal Pradesh.
3५ No act or proceedings of the Fee Structure Committee (Ayush)
shall be questioned or shall be invalid merely on the grounds of
the existence of any vacancy or defect in the constitution of the
Fee Structure Committee.
ity a
Scanned by TapScanner

<!-- page 2 -->

J od | मेड
4. The Fee Structure Committee shall meet as and when necessary
or as called by the Chairperson, |
si x ci के e ५ fi
# he Committee shall devise its own procedure for the conduct of |
its business. |
6. All orders and decisions of the Fee Structure Committee of Ayush |
Vibhag shall be authenticated by the Chairperson of the "Fee
Structure Committee of the Ayush Vibhag" or the person duly
authorized by him in this behalf.
: By order ह
Rajeev Sharma
Secretary (A YUSH) to the
Government of Hijnachal Pradesh
Endst. No. As above Dated, Shimla-2 90° June,2022
Copy to:- .
be The Director AYUSH, Himachal Pradesh Shimla-9 with the request to
circulate the copy of notification _amengst all the concernes amengst all the concerned
members of the Committee and further ensure to upload the same on
the department's website.
2) Guard file..
~ Deputy Secretary (AYUSH) to the
Government of Himachal Pradesh
Phone No. 077-2880352
|
|
Scanned by TapScanner
