---
doc_id: "ea0abd47d54de8fe"
source_url: "https://planning.hp.gov.in/NewReleases\circularGOI.pdf"
ministry: "Planning Department, Himachal Pradesh"
title: "Non Operation of MPLADS for two years(2020-21 & 2021-22)(GOI Circular)"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "bf6cb4fa34af2a8d"
---

<!-- page 1 -->

MOST IMMEDIATE
Circular No. E-4/2020-MPLADS (Pt Il)
Government of India
Ministry of Statistics and Programme Implementation
(MPLADS Division)
East Block-6, Level -5,
R.K. Puram, New Delhi - 470066
Dated: 8 April; 2020
Subject: Non-operation of Member of Parliament Local Area Development
Scheme (MPLADS) for two years (2020-2/ & 202-22) for managing the
health and adverse impact of COVID-9 on the society.

COVID-9 has been declared as a global pandemic by World Health
Organization (WHO) and also a “notified disaster’ by Ministry of Home Affairs (MHA),
Government of India. The Government is making all out efforts to manage the
challenges being faced by the entire nationand its adverse impact on society and this
requires pooling of all available physical, financial, medical, technological and other
resources. Accordingly, the Government has decided not to operate the Member of
Parliament Local Area Development Scheme (MPLADS) for two years, that is,
during FY 2020-2 and FY 202-22 and place these funds at the disposal of the
Ministry of Finance for strengthening its efforts in managing the challenges of COVID-
9 and its adverse impact on society.

2. In view of these decisions, the following will come into effect immediately:

a) There shall be no further release of instalments of MPLADSfor 2 years, that
is, during FY 2020-24 and FY 202-22, into the accounts of Nodal District
Authority.

b) The recommended works which are already sanctioned and awarded by the
district authorities to vendors and for which funds are available may be
completed, within the existing available funds, as no more funds will be
released for these works in these 2 years.

0) The Hon’ble Members of Parliament are requested not to recommend any new
work for which funds are not available in the accounts of the District Authority.

d) The Hon’ble Members of Parliament (MP) can change the priority of their earlier
recommendations, if feasible, so that the recommended work can be completed
within the funds already available with the District Authority as no more funds
will be released.

e) The Hon'ble Members of Parliament can also recommend work in pursuance
to the circular No. E-24020/MPLADS-(Pt) dated 24-03-2020 to strengthen the
District Authorities’ efforts in managing the COVID-i9 pandemic for
procurement of necessary PPEs, ventilators, masks etc for medical personnel.
This recommendation of Hon’ble MP will be met from the already available
funds with the respective District Authority by re-prioritising or cancelling the
earlier recommended works.

व

<!-- page 2 -->

f) District Authorities are also advised not to sanction / award any recommended
work for which funds are either not available or cannot be completed within the
available funds as no more funds will be released.

3, The Circular No. E-4/2020-MPLADS-(Pt-II) dated 28-03-2020 is thus redundant
and hereby rescinded.
4. This issues with the approval of Competent Authority. ७...)
een IAT
oe 04?
(Tanweer Qamar Mohammad)
Joint Secretary (MPLADS)
Tele: 04-26/0 6443 (O)
Email: mplads@nic.in
To,

4. All Hon’ble Members of Parliament (Rajya Sabha/ Lok Sabha)

2: Chief Secretaries of States/UTs

3. The Nodal Secretaries of States/UTs

4. The Commissioners of Corporations of Delhi/ Kolkata/Mumbai/Chennai

5: All District Collectors/District Magistrates/ Deputy Commissioners

Copy for kind information to

4: PS to Hon'ble Deputy Chairman, Rajya Sabha

2: PS to Hon’ble Speaker, Lok Sabha

3: PS to Hon’ble MoS(i/C), Statistics & PI

4. PPS to Cabinet Secretary / Additional Secretary / Director Cabinet

Secretariat
5. Secretary, Department of Expenditure, MoF, New Delhi
6. Secretary, Department of Economic Affairs, MoF, New Delhi
7. Secretary/Director General (C & A)/ Additional Secretary (Pl)/Additional
Secretary & FA/ DDG (Admin) / Director (MPLADS) / DS (MPLADS)
8. Additional Director, Committee on MPLADS Branch, Lok Sabha
Secretariat
9. Director, Committee on MPLADS Branch, Rajya Sabha Secretariat
70. All concerned Officers/Officials in MPLADS Division, M/o Statistics & PI
44.__ NIC-MOSPI with the request to upload on the MPLADS portal
2
