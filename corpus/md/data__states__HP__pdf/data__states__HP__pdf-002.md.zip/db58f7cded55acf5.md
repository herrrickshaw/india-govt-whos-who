---
doc_id: "db58f7cded55acf5"
source_url: "https://www.hp.gov.in/hpdmer/file.axd?file=2021%2f2%2fAmendment+in+Gazette+Notification+Regarding+PC%26PNDT+Six+Months+Training+Rules%2c+2020.pdf"
ministry: "Directorate of Medical Education & Research, Himachal Pradesh"
title: "Amendment in Gazette Notification Regarding PC&PNDT Six Months Training Rules, 2020"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "62e84387c4085918"
---

<!-- page 1 -->

The bazette of India
ot-trTH-29062020-220247
CG-DL-E29062020-220247
THTSTRT

EXTRAORDINARY
HTT I - T - T K i)
PARTISection 3-Sub-section (i)
PUBLISHED BY AUTHORITY

, HTAATT TT 29, 2020STNTS 8, 1942
NEW DELHI, MONDAY, JUNE 29, 2020/ASADHA 8, 1942
T

3171
No. 317

T t , 26 ,

STR

) ERT YTT f T FT T
2014
TS THTTN AaTH T T (T TT sfad) (6 qtfT sAr) ffy4Tt,

3A4, 1994 (1994 T 57)

STTUT TÅ
1. (1)

2020

STTT 32 37-STRT (R)

FfTHt T ATA TNTTUT T yà T4TTd Aaa-T

(

sfTd) (6 4Tf

seur)

f a ArHTa=t, 2020
1.

2. mTm y i zæayå fAerm.TT (T T7 sfa) (6 f
H

T

EI JT

2867 GU2020

TEI TT ) ,

sfrem) fAr, 2014 (

<!-- page 2 -->

2

THE

Il () T4TTTH

(T)TT

y

GAZETTE OF INDIA: EXTRAORDINARY

T 7 (ATAq TTT)
20 4

(T) fazit fau 50
(T) 30 -

HifGT T

II. (a) uTA

(T)frat

( TTTAT TTRT YqTT)

60

(T) 40 7T H t f TT

3.fT4 7 H, fAafefaT g

fAEATfe7 ,

aruta

aTHTA fAT ufuz HTATSTH TEATT;
TEATYT

ATÀTEATTI

4. faT 8 Ä, AafaT

fAEf9a zt, 7ta

()T THT AT

Hi ,

-

fTT itR B17

TYTT 1:4 aT

[PANTLSEC. 3(0)]

<!-- page 3 -->

7T I1T 3(1)]

5. f a u 9 u, f A u a t 7

FIT T , 4sta " 1 777ft 2017

7HH T7 "

6. fa4 9 , 9 (1) *Ty d fAAfafera farH A:r4Tftaf4n TT,A4a
ATTT TtAT TAT ZTTT
7. A7H 14 ,

14 (T) F

H AATAYA Tq4 Aq:T4TTUA f4T TTUT, AGTA:

[1.4. 1-11011/11/2019-ttraerE

feauft:T 4

ATRA

TTT7, 7HTTT, TT II,GE -3 TTE (i)

T1.A. 13(7) att 14 (a) TTETTTPTA EU

à Ë

TE Ä Afafm

9 T77A, 2014

reT

az Hvifea ffraT TAT

T.T.. 77 (7) Faara 31 Tt, 2014
119 (7) fèAir 24 t , 2014

T T.

T.BT.f. 60 (a) famiT 28 7 , 2015 at
T.T.fA. 492 (*T) fnt 23 4, 2017

MINISTRY OF HEALTH AND FAMILY

WELFARE

(Department of Health and Family Welfare)
NOTIFICATION

New Delhi, the 26th June, 2020
of sub-section (2) of section 32 of the
G.S.R. 419(E).-In exercise of the powers conferred by clause (i)
of Sex Selection) Act, 1994 (57 of 1994), the
Pre-conception and Pre-natal Diagnostic Techniques (Prohibition
further to amend the Pre-conception and Pre-natal
Central Government hereby makes the following rules
Selection) (Six Months Training) Rules, 2014, namely:
(Prohibition

Diagnostic Techniques
.

ofSex

Diagnostic Techniques
(1) These rules may be called the Pre-conception
2020.
Amendment
Rules,
Sex Selection) (Six Months Training)
and Pre-natal

(2) They shall come into force on the date of their publication

(Prohibition of

in the Official Gazette.

In the Pre-conception and Pre-natal Diagnostic Techniques (Prohibition of Sex Selection) (Six

2.
Months Training) Rules, 2014.(hereinafter referred to as the said rules),
nll

. l a n dh1l he c1Thetihuted namely .

<!-- page 4 -->

THE

GAZETTTE OF

2)The existing

INDIA

:

AORDINARY

PART II SEc. 30))
registered medical
Genetic Clinic or
practitioners,
who
are
Ultrasound Clinic or
ultrasound procedures in a
months training are
Imaging Centre on theconducting
basis of one
exempted from undertaking
year experience or six
the said
competency based assessment as
training
are able to
provided
they
in
specified Schedule 11
qualify the

(3) If a medical
practitioner fails to clear the said
attempts, he shall undertake the
competency based examination after three
complete six months training,
as
purpose of renewal of
provided under these rules, for the
registration."

(b) In Schedule 11. under the
the following items

I1. (a)

heading "Guidelines for assessment for Final
Examination", after items 11,
inserted
shall be
namely:

PRACTICAL ASSESMENT FINAL

EXAMINATION

(a) 20 marks for log book
(b) 50 mnarks for demonstrations
(c) 30 marks viva
I1. (b)

PRACTICALASSESMENT COMPETENCY BASED ASSESSMENT
(a) 60 marks for demonstrations
(b) 40 narks viva

Note: The examiner can choose any FlVE for Final Examination and SIX for Competency Based
Assessment of these TEN for demo and allot 10 marks each
Viva

30 marks on three case situations for Final Examination

four case situations for

and 40 marks on

Competency Based Assessment

3. In rule 7, the following words shall be substituted, namely:-

(b) Medical Council of India recognised institutions offering Post Graduate programmes in
Obstetrics and Gynaecologyor Radiology;
(c) Institutions

Radiology.
4. In rule 8, the

offering full time residency DNB programme in Obstetrics and Gynaecology or

following words shall besubstituted, namely:

(a) Intake for admission to such trainings shall be up to 1:4 teacher to students ratio.

(b) Sclection shall be as per the merit list of the State Post Graduate Entrance Exam or any other
appropriate merit recognised by the Central Governmen/State Governments.

(c) Preference upto 50 percent of the seats shall be given to the Government in service candidates.
(d) Seats as mutually decided by the States/Union Territoriesshall be provided to the candidates from
other States or Union Teritories where there are no accredited institutes for
imparting Six Months
Training in ultrasonography.
5. In rule 9, the following words shall be

deleted, namely:

On or before 1s" January, 2017"
6. In rule 9, the

following rule shall be inserted as 9 (1 ), namely:-

The States/Union Territories shall

medical practitioners within two

complete the Competency based assessment for already registered
years of this notification."

<!-- page 5 -->

[HTT II

VS 3i)1

7. In rule 14, the

HTR TTT97: HTTRUT

following proviso shall be inserted as 14 (a), namely

Certificate for qualifying Six Months
Training in Ultrasonography and Competency based assessment
shall be issued by Director Medical
Education and
the concerned State

Authority

countersigned by

Appropriate

F. No. V.11011/11/2019-PNDT]
DR. MANOHAR AGNANI, Jt. Secy.

Note.- The principal rules were published in the Gazette of India, Extraordinary Part II, Section 3, Sub-section (),
vide number G.S.R 13 (E) and 14 (E), dated the 9thJanuary, 2014 and subsequently amended vide:1.

G.S.R. 77 (E), dated the 31* January 2014;

2

G.S.R. No. 119(E), dated the 24h February, 2014;
G.S.R. No. 60 (E). dated the 28"January, 2015and
G.S.R. No. 492 (E), dated the 23 May, 2017.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. ALOK KUMARo
