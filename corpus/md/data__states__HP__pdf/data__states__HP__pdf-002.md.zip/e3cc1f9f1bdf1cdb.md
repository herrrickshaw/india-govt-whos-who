---
doc_id: "e3cc1f9f1bdf1cdb"
source_url: "https://www.himtu.ac.in/sites/default/files/2025-10/181025_tender_document.pdf"
ministry: "Himachal Pradesh Technical University, Himachal Pradesh"
title: "Download"
date: ""
pages: 9
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "56fb71ee1db48394"
---

<!-- page 1 -->

रच

हा ey Vy HIMACHAL PRADESH TECHNICAL UNIVERSITY

A [ e | je | V.P.O Daruhi, Tehsil & District Hamirpur (H.P.) — 7700

कि एणा6 :( 0972) 226902, 7४१८: (0972) 22690,

See E-mail ID: registrarhimtu@gmail.com, website: www.himtu.ac.in
Tender No. HPTU/Purchase/I5/2025- 8659 Dated: |¢|J0/2025

NOTICE INVITING TENDERS FOR SALE OF 40 PAGES USED ANSWER

SCRIPTS & 08 PAGES PRACTICAL ANSWER SCRIPTS AND OMR SHEETS LEAF
LYING IN HPTU CAMPUS DARUHI, HAMIRPUR.

Sealed tenders are invited from individuals/firms/registered sole
proprietors/partnership firms or companies for the purchase of 40 pages used answer scripts &
08 pages practical answer scripts and OMR Sheets leaf lying at the HPTU campus, Daruhi,
Hamirpur. The detailed tender document with terms and conditions can also be downloaded
from the University website www.himtu.ac.in. Sealed tenders duly filled alongwith the
required documents/bids should reach by registered post or by hand in the office of the
Purchase Officer, HP Technical University, Hamirpur at Daruhi, VPO Daruhi, Tehsil & Distt.
Hamirpur (HP) -7700] by 03..2025 up to 02:00 PM. The sealed tenders will be opened on
03..2025 at 03:00 PM in the said office in the presence of the bidders, who desire to be
present. The undersigned reserves the right to accept or reject or cancel any or all tenders
without assigning any reason. ole

ritthare Officer,
HP Technical University,
Hamirpur, Distt. Hamirpur (HP)
Endst. No. HPTU/Purchase/I5/2025- 9660 —63 Dated: }§ /)0/2025
l. The Coordinator, Nodal Officer (IT), HPTU Hamirpur to publish the Notice alongwith
the Tender document on the official website of University for wide publicity.
2. The Assistant Commissioner to the Deputy Commissioner, Hamirpur with the request to
publish the tender notice on the Notice Board of DC Office, Hamirpur for wide publicity.
3. The District/Assistant Public Relation Officer, Hamirpur for wide publicity of Tender
Notice..
4. The Commissioner, Municipal Corporation, Hamirpur (HP) with the request to publish
the Tender Notice on the Notice Board of Corporation for wide publicity.
heads Orton:
HP Technical University,
Hamirpur, Distt. Hamirpur (HP)

<!-- page 2 -->

; SS) Himachal Pradesh Technical University
{7 ३ (A State Government University)
4 B Village & Post Office Daruhi, Teh& Distt. Hamirpur (H.P.) — 7700I
es Phone :( 0972) 226902, 226907 Fax: (0972) 22690I,
— GST No.: 02AAATH9345MIZH, PAN: AAATH9345M
E-mail ID: purchaseofficerhptu@gmail.comwebsite: www.himtu.ac.in
HPTU/Purchase/Tender/I5 /2025- Date: /2025
TENDER DOCUMENT
For
Sale of 40 pages used answer scripts & 08 pages practical answer scripts and
OMR Sheets leaf lying at HPTU, Hamirpur
Schedule of Tender
Tender document can be downloaded from our website i.e. http/www.himtu.ac.in
Tender fee : 500/- (Rupees Five Hundred only)
Earnest Money Deposit: 20,000/- (Rupees Twenty Thousand only)
Note: - Tender Document can be downloaded from our website www.himtu.ac.in
Table of Contents
Item Page No.
िणां०्ल पाणंधाए वशाक..........................----५--------७७७७७७७- 4
Terms & (७का6ह0ह:&............ .......... .. . «५ «० स०७>«»« «५१ + ४ ०%«>ूब>ब्बब ५१ २«»»०>__+ 597
वल्कागरांध्श 86 (्राए००फ०-)..............................--------. -..... 8
काश्ालंब छा06 (शाए००७०-2)............................................. 9
P ee om er
Himachal Pradesh Technical University,
Hamirpur.

<!-- page 3 -->

HIMACHAL PRADESH TECHNICAL UNIVERISTY

HAMIRPUR (H.P)

ee SSSSSSSSSSSSSSSSSSEE
NOTICE INVITING TENDER

Sealed tenders are invited from the registered sole proprietor/ partnership
firm/agency or company under the ‘Two Bid System’ i.e.Technical Bid &
Financial Bid, for the following work:

No. Value Mone
Sale of 40 pages used
theory and 08 pages

l. जग cae os Rs. 3. Lakh Rs. 20,000/-
lying at VPO Dauthi, (Approx) | (Rs, Twenty
Distt. Hamirpur (HP) Thousand
Sale of used OMR Sheets

2. leaf lying at HPTU Rs. Lakh | only)

Daruhi, Hamirpur (Approx)

The tender document can be obtained on all working days from 8.0.2025
to 03..2025 between :00 AM to 04:00 PM from the office of ‘The Finance
officer, Himachal Pradesh Technical University, Hamirpur (HP) on the payment of
Rs. 500/- (Rupees Five Hundred only), (non-refundable), as demand draft drawn in
favour of ‘The Finance Officer, Himachal Pradesh Technical University payable at
Hamirpur towards the cost/fee of one tender document. Tender document can also
be downloaded from HPTU’s website www.himtu.ac.in and in such a case, the
bidder shall deposit the cost/fee of tender document(s) as demand draft along with
submission of the tender(technical bid), failing which his tender shall not be
entertained.

The EMD of amount mentioned above must be submitted alongwith
Technical Bid in the form of FDR pledged/Demand Draft drawn in favour of ‘The
Finance Officer, Himachal Pradesh Technical University Hamirpur payable at
Hamirpur.

The bidder must submit their bids in two separate envelopes. One envelope
should contain technical bid and second envelope should contain financial bid
and both envelopes be superscribed as ‘Technical Bid’ and ‘Financial Bid’
respectively and bear the name, address of the bidder/firm. Both the sealed
envelopes should be put inside another third main envelope which should be sealed
properly and superscribed as ‘Tender for Sale of Used Answer Scripts’ and duly
addressed to the Purchase Officer, HP Technical University Hamirpur, VPO

<!-- page 4 -->

Daruhi, Distt. Hamirpur (HP) must reach the office before 2:00 PM on dated ------
/2025. It must be noted that at first stage only the technical bids will be opened and
evaluated and after the evaluation of technical bids, the financial bids will be
opened only for the eligible bidders. The tenders of ineligible bidders shall be
summarily rejected in the evaluation process and their financial bids will remain
unopened.

Technical Bids shall be opened at 03:00 PM on the same day ice.,
03..2025 in the presence of the bidders or their authorized representatives
intending to attend the bid opening meeting. Any tender received later than the last
date/time of receiving bids shall be rejected.

However the financial bids will be opened & evaluated at a later stage only
after the evaluation process of technical bids is completed.

Eligibility Criteria: ..

Only the bidders fulfilling the following eligibility criteria/conditions can
participate in the tender. The documents/certificates pertaining to the eligibility
criteria/ conditions duly signed/ stamped by the bidder/ firm/ company should be
submitted in the technical bid:-

l. The bidder must be a registered sole proprietorship/partnership
firm/agency or Company. Self attested documentary proof of registration
of Sole Proprietorship/Partnership firm/agency or Company must be
attached.

2. The bidders must have a valid PAN to participate in the tender and must
submit self attested copy of the same. The PAN must be exactly in the
name of the bidder/firm as under clause ‘A’

3. The bidders must have GST No. and must submit self attested copy of
the same.

<!-- page 5 -->

TERMS AND CONDITIONS

l. The bidders are requested to quote their highest rates in the Financial Bid
based upon the Terms and Conditions forming part of tender document and
after carefully inspecting the materials being sold off on any working day
between !:00 AM to 4:00 PM in the University and any other factor affecting
the lifting or other costs of the materials.

2. Order will be placed to the successful bidder (the one quoting the highest rates
of purchase out of the eligible bidders).

3. The rate in financial bid must be pated above the reserve price of items fixed
by the committee as under:-

Sr. | Description of Items Reserve Price
No.
Sale of used theory and practical answer | 27.50/- per Kg.
scripts Lying at HPTU Daruhi, Hamirpur
2s Sale of used OMR Leaf lying at HPTU 20.00/- per Kg.
Daruhi, Hamirpur

4. In case, the date of submission/opening of the tender happens to be holiday,
the tenders shall be received/opened on the next working day.

5. Any tender received without Earnest Money and without the cost/fee of tender
document in the form as specified in tender document shall not be considered
and shall be summarily rejected.

6. HPTU reserves the right to cancel the tenders or postpone the tender and to
accept/reject any or all tenders without assigning any reason thereof.

7. HPTU reserves the right to split order of the total sale in two or more parts
depending upon the equality of the rate received from the bidders.

8. After getting the order from HPTU, the successful bidder shall start the work
within 5 days of getting the order. Also he will be liable to complete the job
within a period of 5 days from start of work. If the successful bidder does not
start work in time or stop the work midway or leaves the work altogether, his
EMD will be forfeited and the University shall have the right to cancel the
order and to award the tender to the second highest eligible bidder of the
tender.

9. The transfer of the tender documents purchased by one intending bidder to
another bidder is not permissible. Bidder can submit tenders only on the tender
document purchased/downloaded from HPTU website.

l0. Rates are to be quoted in the Financial Bid for per unit (i.e. per kilogram) of
material being sold in the prescribed performa for the estimated quantity of
items mentioned therein. Bidders may note that it is mandatory to quote rate
for the item in separate sealed envelope.

l. Envelope of Financial Bid, failing which tender shall not be considered as
valid and will be rejected.

2. The highest rate quoted by the bidder shall be accepted only if the same is
equal to or above the minimum Reserve Price fixed by the Committee, failing

के which the Committee 89 ॥०809० जात 6 प्रांहाव्० (त-) छ906० (0 accept

<!-- page 6 -->

the minimum Reserve price for sale of item. If the H-I bidder refuses to
negotiate in such a case, the Committee may negotiate with the H-2 bidder for
the same and the order may issued to the H-2 bidder if negotiation is
successful, failing further, the tender shall be cancelled.

3. The successful (H-l) bidder will be required to deposit Rs. One Lakh as
security deposit for acceptance of bid immediately on the intimation given by
the University, failing which the bid shall be rejected and the second Highest
(H-2) bidder will be given the opportunity, without giving any notice to the H-
I bidder.

l4. The estimated quantity of the material to be sold is indicated in the performa
of Financial Bid. The quantity indicated is tentative and may vary to any
extent during actual lifting/weighing of materials. The amount payable to
HPTU will be based upon the actual quantity lifted and the accepted rates.

5.. Bidders are requested to visit HPTU campus on any working day and inspect
the quantity, condition and type of material being sold by HP Technical
University.

6. The rates quoted should be inclusive of all costs, transportation cost etc.
including material movement from actual place of storage which may be from
stores/upper floors/basement etc, loading/unloading of materials, weighing
charges, transportation to destination ete.

7. The rates quoted should be exclusive of GST and GST shall be extra at the
applicable rates from time to time.

I8. The packing of the material will be arranged by the bidder at his own expenses
only. University will not supply any bags/bora/cartons/other items for packing
the material.

9. The successful bidder shall ensure that the above material shall be shredded
properly and shall only be recycled for production of papers/allied products
etc. and shall not be used for any other purpose. An original affidavit duly
attested by Notary Public on a stamp paper of % 50/- shall be furnished by the
successful bidder in this regard before start of lifting of material.

20. The rates accepted by HPTU shall remain valid for a period of one year from
the date of issue of order by HPTU and the items may be sold to the successful
bidder in different lots/phases during the said period.

2l. The Earnest money deposit of the successful bidder will be released on
satisfactory completion of the contract. EMD of the unsuccessful bidders will
be released back afier finalization of the tender process.

22. The successful bidder shall deposit all the sale amount of each weighed
material lot to the HP Technical University Hamirpur before lifting the
material. He will not be allowed to lift the materials before deposit of full
amount to HPTU. The sold material must be lifted by the successful bidder
within 5 days from the issue of letter, failing which the offer/contract may be
cancelled.

23. Security Deposit/EMD of the successful bidder shall be released/ adjusted
after satisfactory completion of the work.

<!-- page 7 -->

IMwe hereby undertake to abide by the terms and conditions of the tender
document. I/we further state that all the information submitted in the technical as well as
financial bid is true and correct to the best of my knowledge & belief.

A Agreed and Accepted
Signature of the bidder with
Date & office seal/stamp

<!-- page 8 -->

क्आरएशकल-
(Technical Bid)
Sale of 40 pages and 08 pages practical used answer scripts & OMR Sheets leaf
lying at HPTU Daruhi, Hamirpur H.P.
an erent neslihan massive
The Technical Bid (envelope-l) superscribed as ‘Technical bid for sale of
used answer scripts & OMR Sheets leaf” containing the following documents and
bearing the name, address/stamp of bidder on the envelope, must be sealed
properly and addressed to the Purchase Officer, Himachal Pradesh Technical
University, Hamirpur:-
l. Duly filled and with each page signed & stamped tender document.
2, Demand Draft of Rs. 500/- drawn in favour The Finance Officer,
Himachal Pradesh Technical University, Hamirpur, payable at
Hamirpur as cost/fee of Tender document.
3. Duly pledged FDR/Demand Draft of a scheduled commercial Bank
of Rs. 20,000/- drawn in favour of the Finance Officer, Himachal
Pradesh Technical University, Hamirpur, payable at Hamirpur as
EMD. Payment through cheque or any other means will not be
accepted.
4. Self attested Documentary proof of registration of Sole
Proprietorship/ Partnership firm/agency or Company.
5. Self attested copy of the PAN.
\ 6. Self attested copy of GST registration.

<!-- page 9 -->

Envelope-2
Financial Bid
Sale of 40 pages and 08 pages practical used answer scripts & OMR
Sheets leaf lying at HPTU Daruhi, Hamirpur H.P.
SS Sec meee ३ ३_३_३॑|॑|॑|॑||| |
l. The ‘Financial Bid’(Envelope-2) superscribed as ‘Financial Bid for
sale of used answer scripts & OMR Sheets leaf ” and containing the
rates duly filled in following performa and bearing the name,
address/stamp of bidder on the envelope must be sealed properly and
addressed to the Purchase Officer, Himachal Pradesh Technical
University, Hamirpur.
2. The Price Bid must be quoted above the reserve price of items fixed
by the committee.
Sr. Description of | (Tentative | Reserve Rate of Rate of
No. Items Quantity & | Price fixed | Purchase Purchase
weight) by (Rs. / (Rs./Kg) (to be
committee | Kg) (to quoted in
be words.
quoted in
figures.
l. | Sale of 40 pages
2,00,000,
& 08 pages used (Answer
theory and मै
5 scripts) 7.50
practical answer
. है (Per kg)
scripts Lying at 2.000 k
HPTU Daruhi, Seca,
A Hamirpur PPFOX.
2. | OMR Sheets leaf (500 kg 0.00
approx.) (Per kg)
IAwe hereby undertake to abide by the terms and conditions of the
tender document.
I/we further state that all the information submitted in the technical as
well as financial bid is true and correct to the best of my knowledge & belief.
Dated: Signature of the Bidder with stamp
