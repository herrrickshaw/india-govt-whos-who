---
doc_id: "d2caaed54ef7c297"
source_url: "https://dest.hp.gov.in/storage/notifications/Not_Polythene05022020.pdf"
ministry: "Environment, Science Technology & Climate Change Department, Himachal Pradesh"
title: "View"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d859035ff1ffcb85"
---

<!-- page 1 -->

.... -.

.

. :i

!·

I.

:;

Government
of Himacb'al
Pradesh
.
·Departbient of Environm~n_t, . Science 4\.Technolo~
'

· .

.

'

/"

..

...

.·

.

.··

.

,·

.~No.' STE-f;;(9)-1/2018-foose Oate.d: Shimla-l ··
NOTIFICATION
' ".;·· ·

<

. .

In additiQn to the. o£fi~r$ ~Jreaqy authorized_·vide O:QtW N{?tific~tiort No: STE..

' F(4)-2/2008date<l 07. 01.2009; N-01SJE..f(4}2/20Q8;.I date<f20 .08.~0lO; Na; · sTB-F(4)-2/2008-

·.u dated Q4;I i.2010, Nd. ,SfE-F(4)..212DQB-II ·cjated·.l5.C)3.20ll · ·& ·20.09,2019 .· ·the Governor,·

- HimachalJ>radesb~ in exetci~e o(pQwer:s conferrea b y section 7(A) and section ll(I) of the
·Himach~ Prade$h.Ngn-.Bio~~gradable Garbage 'c<:~ntrol) Ao4 1995, :is pleased to authorize the·
following pfficers/()fficial~ .of" the various :Dep~enJS . for·'.eff~ctive i~.p1eQ1entatfon .·$4 for
entry ancl~spection uml:e r sectiQrt J(A) and )~ co'tlipqun(t anY offenc~ under the J-Iirn~chaJ
. Pradesb · ~n,~$iod~gradat11eG~age ·· (Control) _ Act; 19.95 or.contravention of ~e ban . im~ose:d
vide:abave referred notificatiqns;.- '·
..
· 1
,

!·

... '

Sr. No. . · Nam~ ·pf·tbt(
_, .De, . ~rtment ··· .

.

'

~-

2..

.Healt)l
'.· ...

..

. _.·
.
. :R.ajneesh, lAS
Secre'tary(Env. Sci. & 'fech.) to the
Government-offfima:ChaJ Pradesh

t

~...

;.

r·
j
!
~

!

· ByOrder,

.~- Eh.~t. No.:: ST·E·-F~(9).:ll.2018~1.~ose

;

· ·· Dated. •.=Sh··· i.mla...-.·2,

Copy fonvarde4 for informatioln and ·necessacy actie>n to:

os .~2020.

1. The Secretary to the Governor, Himacha_lPradesh,Shiml.a;.2 . .
·2. The Pr. Secretary totheChi~fMinister/Himachal Pradesh.Sbimla~2. .
3. The Private Secretaries to the·Cabinet/State Ministers•. Govel'Jlffient of _Himachal Pradesh.
J1. The Private Secretaries te the Chief 'Secret~y·to the Govt.' of Hima~haJ PracJesh.
5. All the Administrative Secretaries to the Gov¢rnment of Himachal Pradesh. · ·
6. The Ditt'Ctor Gen€;)tal of Police, HP with the r~uest that this notification may kindly be
. . circuI~ to,~lrSP', ASP and SDPO!I;>SP.
· '.
.
·
7. All Heaas ofQ~pattment _ofHI°m~chal Pradesh. '
.

~ .

.' .. ~ "'."-a.-\..•l..

-

·'

<!-- page 2 -->

' ~~~~~~~:·:~: h' "~,~,, i~-~~'. -~~-;t~::';: ~.,:~··.'..?~\~;~,~ '.-0)'.f?~-~~:~?~4,
~

.. .. ·

.•2...

..~.

8. · All the Deputy Commissioners ofHimachal Prade~h.
9. All the Divisional Commissioner of Himachal Pradesh. . .
JO. ~e ·Member Secretacy, H.P. State PnllutionCcmtr<>lBoard, Phase-III, New Shimla•9.
··1 L The Pr. Chief Co11servator of Forests, with th'< request thatthis notification may kindly be ·
·_ ~latedtoallRangeOfficer and Dy. Range Officers.
· .· . .
'.
·
f\:j.2<The Director (Environment, ~cience & Technole>gy)> P~avarn Hhawan, Neat U.S. Club
Shimla-1.
·
'
·
·· ·
·
·
13 ~ .Th~ Member .Secretary, !f.P. State Council ·for Science, Techn.ology and Environment
(HIMCQSTE)~- Blo.ckNo. 34, SDAComplex, K~umpati,Shfmla.-9. .
14. All tbe Chamnan/Vice.;chairman ofBoard/Corj:iorf:lti<>n. in H;P. ·.
15. Guard file.
.
.
'

,

.

(SatP~ 4~~.u

Joint Secr.etary (Env. S&T) to th~­
Governm.ent ofHimachalPradesb·
Phone: .0177-2621874

'

.

· ~. .

..

. '

;.

.
