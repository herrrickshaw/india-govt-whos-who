---
doc_id: "0abbdf377c31bed3"
source_url: "https://hpsvacb.hp.gov.in/storage/app/media/Proforma-ViewallNotifications1.pdf"
ministry: "State Vigilance & Anti Corruption Bureau, Himachal Pradesh"
title: ""
date: ""
pages: 4
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "13631da9a5e63857"
---

<!-- page 1 -->

¥% है IMPORTANT
No. rome (Vig.)-B(5)-8/208-iMisc-RD&PR
Government of Himachal Pradesh
Department of Home (Vigilance)
From:
The Principal Secretary (Vig.) to the
: Government of Himachal Pradesh,
Shimla-2.
Te
4, All the Administrative Secretaries to the
Government of Himachal Pradesh, Shimla-2.
2, Allthe Heads of Departments,
in Himachal Pradesh.
3. All the Managing Directors,
PSUs/Boards/Corporation , हु
in Himachal Pradesh
4. All Divisional Commissioners/ Dy, Commissioners
Government of Himachal Pradesh
Dated: Shimia-2 the "26. NI. -2099
Subject:- Prosecution Sanction againsi Public Servants u/s 797 of Cr,
P.C. and u/s 79 of tne P.C. Act.
Sir,
| am directed to refer fo the subject cited above and to say that
this department has already issued instructions from time to time regarding
orders of prosecution sanction.” sanctioning authorities for granting
presecution sanction, stipulated timelines to be followed while granting
prosecution sanction and the format cf sanction order. The tzsi such
insuuction was circulated vide letter No.(Vig)F-(6)/7/98 dated 76.07.2073(this
letter alongwith earlier references is available on the Vigilance link of हि
Rome Department in the official website of the State Government).
2, The Department has been emphasizing the need for quick and
expsditious decision on requests of sanction for prosecuiion received jrorn
the State Vigilance and Aitti-Corruption Bureau(SV&ACB), Himachal Pradesh:

<!-- page 2 -->

4 X
‘Bs
unaer section 79 of the Prevention of Corruption Act and section 97 of the
Code of Criminal Procedure as per procedure laid down in the HP Vigilance
Manual! and guidelines circulated in this regard by the State Government from
time to time It has been observed that despite of repeated requests made by
this Department and tiie SV&ACB, the guidelines/ instructions are still not
being followed strictly by the concerned sanctioning authorities.
3. Various judgments of the Supreme Court have emphasized thal the
order of sanction should be in the form of speaking order disclosing application of
mind of the authority on the material placed before it. The Hon'ble Supreme
Court in case (AIR 997 SC 3400) has clearly held that since the vaiidity of
sanction depends on the applicability of mind of the Sanctioning Authority
to the facts of the case as also the material and evidence collected during
the investigation, is necessarily follows that the Sanctioning Authority has
fo appiy its own independent mind for the generation of genuine
satisfaction whether prosecution has to be sanctioned or noi. The n:ind of
the Sanctioning Authority should not be under pressure from any quarter
ner should any external force be acting upon it to take a decision one way
or other. पे A
Since, the discretion to grant or not to grant sanction

vests absolutely in Sanctioning Authority, its discretion should not be
shown to have been affected by any external consideration.
4 The Hon'ble Supreme Court in Criminal Appea! No, 7838 of 2073 in

z the matter of CBI Vis Ashok Kumar Aggarwal, in para 7 of the judgment
ovserved that “ there is an obligation on the sanction authority to discharge
its duty to give or withhold sanction only after having full knowledge of the
material facts of the case. Grant ef sanction is not a mere formality.
Therefore, the provisions in regard to the sanction must be observed with
camplete strictness keeping in mind the pubiic interest and protection
avaliable to the accused against whom the sanction is sought. S2rciion
lifts the bar for prosectition. Therefore, its no! an acrimonious exarc

<!-- page 3 -->

&
. 3.

but a solemn and sacrosanct act which affords protection to the
Government servant against frivolous prosecution. Further, it is a weapon
to discourage vexatious prosecution and is a safeguard for the innocent,
tough not a shieid for the guilty”.
5. Accordingly the instrictions issued earlier are reiterated and it is
requested to kindly ensure that:-"

a) The original order(s) of prosecution sanction/denial, signed by the
competent authority is(are) sent to the SV&ACB directly in the
manner as specified in the HP Vigilance Manual on prescribed
format, with a copy to the Home(Vigilance) Department for
information.

b) The order of sanction should make it evident that the authority nad
been aware of the relevant facts/ material supplied to him/her and
had applied its mind to all the relevant’: material so supplied to
him/her by the investigating agency.

c) The power to grant sanction is to be exercised strictly keeping in
mind the public interest and the protection available to the
officer(s)/officials(s) against whom the sanction is sought.

d) The sanction of prosecution must be conveyed by the competent

2 authority to the investigating agency most preferably within a period
of three’ months as per the order passed by the Hon'ble High Court
in COPC No. 575 of 2042 titled as Virender Kumar V/s Smt. Bharti
Sihag, Principal Secretary (Forests) & others in its order dated
74.2.202 and provision of para 4/ of Chapter VI of HP Vigilance
Manual as well,

<!-- page 4 -->

_ Eee कक
% |
: : \
wt. -4-

e) The competent authority cannot change its opinion subsequently
once the prosecution sanction has been accorded earlier after due
application of mind on the basis of same facts and circumstances
The competent authority should take care that prosecution sanction
should not be denied on account of irrelevant facts.

f) The sanctioning authority while taking decision on the question of
sanction is not required to meticulously appreciate the evidence
because the question of inadequacy or inconsistency in the
evidence has to be considered by the Trial Court and the
sanctioning authority has to confine only to the allegations against
the concerned officer/ official. है

6. You are, therefore, requested to act accordingly and obtain
approval of Competent Authority as per scheme of the Rule of Business of
the State Government and ensure strict compliance of these guidelines by
the Department(s) and other organization(s) under your administrative
control. Since non- compliance of above guidelines vitiates the sanction
for prosecution, therefore, sanctioning authorities should discharge their
obligation with complete due diligence and would be held responsible for
any deviation or non-adherence in the matter of prosecution sanction if the
validity of sanction were to be questioned at a later stage.
The receipt of this latter may be acknowledged
है Yours faithfully,
-a
(Rakesh Sharma)

Specia! Secretary (Vigilance) to the

Government of Himachal Pradesh

(Phone No. 2624470)
