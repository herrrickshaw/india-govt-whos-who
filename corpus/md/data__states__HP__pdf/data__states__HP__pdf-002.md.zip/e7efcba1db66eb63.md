---
doc_id: "e7efcba1db66eb63"
source_url: "https://rggec.ac.in/wp-content/uploads/2026/08/Revised-GYM-Tender-as-per-Corrigendum-with-updated-BOQ.pdf"
ministry: "Rajiv Gandhi Government Engineering College (RGGEC), Kangra, Himachal Prades"
title: "Revised GYM Tender as per Corrigendum with updated BOQ"
date: ""
pages: 22
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0f915289d7ed77bb"
---

<!-- page 1 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

RAJIV GANDHI GOVT. ENGG. COLLEGE, NAGROTA BAGWAN, KANGRA, H.P.176047

TENDER FOR “SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT
AT RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)”

Page 1 of 22

<!-- page 2 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

INDEX
Sr. No.

Details

Page No.

1.

Notice Inviting Tender

3-7

2.

Information and Instruction for Tenderers

8-9

3.

Scope of Work

10-11

4.

Declaration

12

5.

Warranty Form

13

6.

Acceptance of Tender

14

7.

Agreement Form

15-16

8.

Price bid/ BOQ (Annexure-I)

17

9.

Technical Specifications (Annexure-II)

18-21

Page 2 of 22

<!-- page 3 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

NOTICE INVITING TENDER
RGGEC/NGB/STORE/GYM/TENDER

Dated:

The Director cum Principal, Rajiv Gandhi Govt. Engg. College (RGGEC), Kangra at Nagrota Bagwan, Distt. Kangra
(H.P.) invites bids through Open Tender from eligible Original Equipment Manufacturers (OEMs) or their Authorized
Dealers/Distributors for Supply, Installation and Commissioning of Indoor Gym Equipment for the Institute Gymnasium.
The procurement shall be governed by latest HPFR and applicable Government of Himachal Pradesh procurement rules.
The Original Equipment Manufacturers (OEMs) or their Authorized Dealers/Distributors who has experience for
taking up such work and who satisfies the qualification criteria of bid document need only apply. Detailed scope of work
is described in the tender document and brief description is given in the table below:
Sr.
No.

Name of work

EMD

Cost of tender
form

Eligibility criteria and Scope

1

Supply, Installation and
Commissioning of
Indoor Gym Equipment

Rs.30,000/-

Rs.500/-

As specified in the tender document

at RGGEC, Kangra
at Nagrota Bagwan
(H.P.)

1. The offer should be for the complete job.
2. Availability of bid document: - The bid document will be available on website https://rggec.ac.in w.e.f. 19/08/2026 to
09/09/2026.
3. Mode of submission: Bid should be submitted in physical mode in the office of Director-cum-Principal, RGGEC, Kangra
at Nagrota Bagwan, Distt. Kangra, H.P. Last date of submission of tender document will be 10/09/2026 (1:00 P.M.).

-Sd
Director-cum-Principal
RGGEC, Kangra at Nagrota Bagwan

Page 3 of 22

<!-- page 4 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

4.

Schedule of Tendering

S. No.

Key Events a)

Date & Time
19/08/2026

Date & Time of publication

b) Period of availability of bidding documents on website

19/08/2026 to 09/09/2026

https://rggec.ac.in
1

2

3

c)

19/08/2026

Bid submission start date

d) Last date and time for submission of tender along with the cost of 10/09/2026 (1:00 P.M.)
the tender document, Earnest Money Deposit
10/09/2026 (2:30 P.M.)
a) Time and date for opening of Cover -1 of the bid (the technical
bid)
b) Time and date for opening of Cover -2 of the bid (the financial
bid) of bidders who qualified in part 1 of the bid
To be notified later
Bid validity

90 days from the deadline date for submission of
bids.

5. Bid Covers:
a) The offer should be for complete job of Supply, Installation and Commissioning of Indoor Gym Equipment. The tender
documents shall be submitted physically in two covers: Cover-1: “Technical bid” shall contain all the contents of clause 7.1 of page no.6 of the tender document.
Cover-2: “Financial Bid” shall contain the price bid as per clause 7.2 of page no.6 of the tender document.
b) The bid duly signed & stamped along-with EMD and tender fee must be submitted in physical form in the office of
the undersigned on or before 10/09/2026 up to 1.00 P.M.

6. Eligibility Criteria: 6.1 Legal Status
The bidder shall be Original Equipment Manufacturer (OEM)
OR
Authorized Dealer/Distributor of OEM (Manufacturer Authorization is mandatory)
6.2 OEM Eligibility
OEM shall have minimum Five (05) years’ experience in manufacturing commercial-grade gym equipment.
Documents Required:
I)

Company Registration or Certificate of Incorporation

Page 4 of 22

<!-- page 5 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)
6.3 Similar Experience
During last Three (03) years, OEM/Bidder shall have successfully supplied and installed gym equipment in at
least
Two Government Institutions
AND
Two Commercial Fitness Centers
Documents Required
i) Purchase/ Supply Orders along with Completion Certificates
6.4 Financial Capacity
Average Annual Turnover during last three financial years shall not be less than
Rs. Two Crore for OEM
and
Rs. Ten Lacs for Authorized Dealer
Documents Required
i) CA Certified copy of Average Annual Turnover during last three financial years for OEM.
ii) CA Certified copy of Average Annual Turnover during last three financial years for Authorized Dealer.
6.5 Quality Certification
OEM must possess ISO 9001. Copy of the certificate shall be enclosed.
6.6 Product Documentation
Every quoted item shall be supported by:
OEM Catalogue
i)

Technical Datasheet

ii)

Model Number

iii)

Product Photographs

Any specification not supported by OEM literature shall not be considered.
6.7 Equipment
 Only factory manufactured equipment shall be accepted.
 Locally fabricated equipment, Customized fabricated equipment, Assembled equipment from local market,
Second-hand equipment, Refurbished equipment shall not be accepted.
6.8 Warranty


Minimum Three Years Comprehensive standard across all equipment.

Page 5 of 22

<!-- page 6 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)
6.9 Spare Parts
Bidder shall undertake availability of spare parts for minimum 3 Years.
6.10 Service Support


OEM shall have service network in state of Himachal Pradesh.



Service support details shall be submitted.

7. Instruction regarding bid
The tender shall be submitted in Two parts, viz., Technical bid and Financial bid duly signed and stamped. All the pages
of bid being submitted must be sequentially numbered by the bidder irrespective of nature of content of the documents.
The offers submitted by email shall not be considered. No correspondence will be entertained in this matter.
7.1. Cover-1 (Technical Bid) must contain the following:
(i) Name of firm, addresses, telephone number, mobile No., E-mail ID.
(ii) Copy of certificate of incorporation/ Company registration of Bidder and OEM.
(iii) GST registration certificate.
(iv) PAN card of firm.
(v) CA certificate, showing average turnover above Rs. Two Crore of OEM.
(vi) If bidder is an Authorized Dealer then, CA certificate showing average turnover above Rs. Ten Lacs for last
financial years along with CA certificate, showing average turnover above Rs. Two Crore of OEM must be
submitted.
(vii) An undertaking that the Firm has not ever been black listed by any government/semi- government / board/
Corporation/ Private Organization on bidder’s letterhead.
(viii) Experience in execution of similar works as per Eligibility Criteria clause 6.3. (Purchase/ Supply orders and
Completion certificate)
(ix) Warranty certificate on bidder’s letterhead (minimum Three Years Comprehensive standard across all
equipment)
(x) Product Documentation as per clause 6.6.
(xi) Quality Certification (Copy of ISO 9001)
(xii) Undertaking that OEM has authorized Service Centre in H.P.
(xiii) Declaration Form (as in tender document Page No. 12)
(xiv) Warranty Form (as in tender document Page No.13)
(xv) Bank Demand Draft of Rs. 500/- (Five Hundred only) in favor of Director-cum-Principal, RGGEC, Kangra

at Nagrota Bagwan as tender fee (non-refundable) with date of issue clearly mentioned.
(xvi) FDR/ Bank Guarantee/ DD of Rs. 30,000/- (Thirty Thousand Only) duly pledged in favor of Director-cumPrincipal as EMD.
(xvii) Complete Tender document with stamp & signatures of the bidder on each page.
7.2. Cover-2 shall contain
Financial bid is to be submitted as per format given in Annexure-I. Bidder shall not Tamper/modify downloaded
financial bid template in any manner. In case, if the same is found to be tampered/ modified in any manner, tender will
be completely rejected and EMD would be forfeited.
Page 6 of 22

<!-- page 7 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)
8. Rejection
a) The bid of the tenderer who fail to fulfill the eligibility criteria will be summarily rejected.
b) Joint venture not allowed and No subletting of works by the contractor/firm is permissible.

9. Bid Opening Details:
a) The Technical Bids shall be opened as per opening date & Time notified in the Notice in the office of the undersigned
by the Committee authorized by the competent authority in the presence of such bidders who may wish to be present or
their authorized representatives.
b) The financial bids of only those bidders whose Technical Bids are qualified, shall be opened by the Committee authorized
for the purpose.
c) The date and time of opening of the financial bids shall be intimated to the technically qualified bidders through website
of the college or by e-mail.

Page 7 of 22

<!-- page 8 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)
INFORMATION AND INSTRUCTIONS FOR TENDERERS
The tenderers are advised to study full tender document carefully before tendering and they shall be deemed to have
fully acquainted themselves with the same.
1.

The Tenderers should ensure that the RGGEC shall bear no responsibility for the lack of acquaintance of the site
and other conditions or any information relating thereto, on their part. The consequences of the lack of any
knowledge, as aforesaid, on the part of the tenderer shall be at their risk and cost and no charges or claims
whatsoever consequent upon the lack of any information, knowledge of understanding shall be entertained or
payable by the RGGEC.

2.

The offer should be valid for 90 (Ninety) days from the last date for submission of tender.

3.

The tender should be submitted in physical form in the office of Director-cum-Principal, RGGEC, Kangra and
the same should be signed properly as laid down hereunder: a)

If the tender is submitted by an individual, it shall be signed by the proprietor above his full name and full
name of his firm with its current business address.

b)

If the tender is submitted by a firm in partnership, it shall be signed by all the partners of the firm above
their full name and current business addresses, or by a partner holding the power of attorney of the firm by
signing the tender in which case a certified copy of the power of attorney shall accompany the tender. A
certified copy of the partnership deed and current business address of all the partners of the firm shall
accompany the tenders.

c)

If the tender is submitted by a limited company or a limited Corporation, it shall be signed by a duly
authorized person holding the power of attorney for signing the tender in which case a certified copy of the
power of attorney shall accompany the tender. Such limited company or corporation may be required to
furnish satisfactory evidence of its signature.

d)

All witnesses and sureties shall be persons of status and their full names, occupation and addresses shall be
stated below their signatures. All signatures affixed on each page in the tender will be dated.

e)

The tender for the works shall not be witnessed by a tenderer or tenderers who himself/themselves has/have
tendered or who may and has/have tendered for the same works. Failure to observe this condition shall
render the tender of the tenderer tendering as well as of the witnessing the tender liable to rejection.

f)

The earnest money deposit will be returned to the unsuccessful tenderers within 45 days after finalization
of tender.

g)

The earnest money of the successful tenderer will be returned after he deposits performance security in the
shape of bank guarantee/FDR pledged in favor of The Director cum Principal RGGEC Nagrota Bagwan,
Kangra HP @ 8% of the Total Quoted Value.

h)

The performance security will remain with the institute for a period of 1 year commencing from the date of
successful installation of the equipment.

i)

The Director cum Principal, RGGEC, Nagrota Bagwan shall have the right of rejecting all or any of the
tenders and may reduce the scope of work and also will not be bound to accept the lowest or any other
tender and the Director Cum Principal, RGGEC decision in this regard shall be final and binding on all
Page 8 of 22

<!-- page 9 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)
tenderers.
j)

The tenderers shall not be entitled during the period of validity of their offers, to revoke or withdraw their
tenders or vary any terms in regard thereof without the consent of the Director Cum Principal, RGGEC in
writing. Tenderer shall get his earnest money forfeited for any violation of this clause.

k)

The tenderer will execute the work within 30 days from the date of issue of written order to commence the
work. The Director cum Principal, RGGEC shall have a right to forfeit the earnest money deposited by the
tenderer absolutely without prejudice to other rights and remedies available with RGGEC on the violation
of this clause.

l)

The “Notice Inviting Tender” and this “Information and Instructions for Tenderer” shall form part of the
Tender Documents.

m)

Any addendum/corrigendum issued before the date of opening of tender will form part of tender documents.

n)

Intending tenderers should visit the site, satisfy themselves regarding the site conditions, location of site,
and collect all relevant information required before tendering for the work, tenderer shall be deemed to
have full knowledge of the site, specifications and no excuse as regard to want of information or
clarification shall be considered after the tender has been received. A certificate in this regards is to be
necessarily uploaded in the technical bid.

o)

Terms of Payment-: 100% payment will be made to the supplier on successful completion of delivery and
installation and commissioning of all the equipment at site as per the supply order placed by the respective
units and certificate issued by Committee constituted for this purpose. The quality/ make, brand of
equipment should be strictly as per financial quotation. No advance payment shall be released.

p)

The institute may waive off any minor infirmity, non-conformity, or irregularity in a bid that does not
constitute a material deviation and that does not prejudice or affect the relative ranking of any bidder as a
result of the technical and financial evaluation.

Dated:
Signature of the Contractor

Page 9 of 22

<!-- page 10 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

SCOPE OF WORK
The successful bidder shall be responsible for the complete execution of the work, including but not limited to the following:
1. Supply
The bidder shall supply all commercial-grade gym equipment, accessories, attachments, tools, consumables and other
items as specified in Technical Specifications.
2.

Transportation
The bidder shall transport all equipment to Rajiv Gandhi Government Engineering College, Kangra at Nagrota Bagwan,
H.P., at his own cost, risk and responsibility.

3. Loading and Unloading
Loading, unloading, shifting at designated location and safe handling of all equipment at site shall be the responsibility
of the bidder.
4.

Installation
The bidder shall install all equipment at the locations identified by the Institute in accordance with the manufacturer's
recommendations. The bidder without any additional cost shall supply all fasteners, anchor bolts, fittings and accessories
required for proper installation.

5.

Testing and Commissioning
After installation, each machine shall be tested and commissioned in the presence of the Institute's representatives. The
equipment shall be handed over only after successful testing.

6.

Calibration and Adjustment
Wherever applicable, the bidder shall carry out necessary calibration, alignment and adjustments before commissioning.

7.

Demonstration
The bidder shall demonstrate the proper operation, safety features and maintenance procedures of each equipment to
the satisfaction of the Institute.

8. Documentation
The bidder shall supply:
 User Manual
 Service Manual (where applicable)
 Warranty Cards
 Parts Catalogue (if available)
 Installation Report
 Commissioning Report
9.

Warranty Support
The bidder shall provide comprehensive warranty support as specified in the tender document.
During the warranty period, all repairs, replacement of defective parts, labour, transportation and other incidental
expenses shall be borne by the bidder.

10. Preventive Maintenance
The bidder shall carry out preventive maintenance visits during the warranty period at intervals recommended by the
OEM or at least once every six months. Preventive maintenance reports shall be submitted to the Institute.
11. Breakdown Maintenance
During warranty period, any complaint lodged by the Institute shall be attended within 72 hours.
Equipment remaining non-functional beyond the stipulated period shall be repaired or replaced by the bidder without
additional cost.
Page 10 of 22

<!-- page 11 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)
12. Spare Parts
The bidder shall ensure availability of genuine OEM spare parts for a minimum period of 3 years from the date of
installation.
13. Replacement of Defective Equipment
Any equipment found defective, damaged or not conforming to the tender specifications shall be replaced by the bidder
at no extra cost.
14. Cleaning of Site
After installation, the bidder shall remove all packing material, debris and waste from the premises and leave the
installation site clean.
15. Acceptance
The work shall be considered complete only after:
 Supply of all equipment
 Successful installation
 Demonstration
 Submission of all documents as mentioned under clause 8 of scope of work.
 Acceptance by the Institute
16. Exclusions
No additional payment shall be made for:
 Transportation
 Insurance
 Loading/Unloading
 Installation
 Commissioning
 Demonstration
 Labour
 Tools and Tackles
 Consumables required for installation
 Any other incidental expenses necessary for successful completion of the work.
17. Uniform Make
All strength training equipment and cardio equipment shall be from a single OEM to ensure compatibility, uniformity
and ease of maintenance.
18. OEM Literature
Every quoted model shall be supported by the OEM's official printed or downloadable catalogue and technical
datasheet. Claims not supported by OEM literature shall not be considered.
19. Right of Inspection
The Institute reserves the right to inspect the OEM's manufacturing facility, warehouse or any existing installation
before placement of the purchase/ supply order.

Page 11 of 22

<!-- page 12 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)
(Declaration Form)
To
Director cum Principal,
Rajiv Gandhi Govt. Engg. College,
Kangra at Nagrota Bagwan, H.P. 176047
I/We have read/ examined the following tender documents relating to the work of “Supply, Installation and
Commissioning of Indoor Gym Equipment at Rajiv Gandhi Govt. Engg. College, Nagrota Bagwan, Kangra
(H.P.)”
1.
2.
3.
4.
5.
6.
7.
8.
9.

Notice inviting tender
Information & instructions for bidders
Scope of Work
Declaration
Warranty Form
Acceptance of Tender
Agreement Form
Price bid / BOQ (Annexure-I)
Technical Specifications (Annexure-II)

I/We hereby, tender for execution of the works referred to in the documents mentioned in paragraph 1 above upon
the terms and conditions contained or referred to in the aforesaid documents and in accordance with the specifications,
and other details given therein within the period(s) of completion as given in Notice Inviting Tenders and subject to such
terms and conditions as stipulated.
I/We agree to keep this tender open for acceptance for Ninety (90) days from the date of opening thereof and also
agree not to make any modifications in its terms and conditions of our own accord.
I/We agree if I/We fail to keep the validity of tender open, as aforesaid, or make any modification in the terms and
conditions of my/our tender of our own accord and/or after the acceptance of our tender if I/We fail to commence the
execution of the works, as provided in the document referred to in paragraph 1 above, I/We shall become liable for
forfeiture of my/our earnest money, as aforesaid, and the RGGEC shall without prejudice to any other right or remedy,
be at liberty to forfeit the said earnest money absolutely. Should this tender be accepted, I/We agree to abide by and
fulfill all the terms and conditions and provisions of the above-mentioned tender documents.
I/We certify that the tender submitted by me/is strictly in accordance with the terms, conditions, specifications, etc.
as contained in your tender documents, referred to in paragraph 1 above, and it is further certified that it does not contain
any deviations to the aforesaid document.

Witness:

Signature in the capacity of:

Date:
Address:

Page 12 of 22

<!-- page 13 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

WARRANTY FORM
M/s.
having
its
registered
office
at
__________________
(hereinafter referred to as the Bidder) having carefully studied all the documents,
specifications, etc. pertaining to the contract for “Supply, Installation and Commissioning of Indoor Gym Equipment at
Rajiv Gandhi Govt. Engg. College, Nagrota Bagwan, Kangra (H.P.)”

DO HEREBY WARRANTY THAT
1.

The Bidder is familiar with all the requirements of the contract.

2.

The Bidder is satisfied that the work can be performed and completed as required in the contract.

3.

The Bidder accepts all risks directly or indirectly connected with the performance of the contract.

4.

The Bidder has not been influenced by any statement or promise of the Department but only the contract,
documents.

5.

The Bidder is financially solvent.

6.

The Bidder is experienced and competent to perform the contract to the satisfaction of the RGGEC.

7.

The statement submitted by the Bidder is true.

8.

The Bidder is familiar with all general and special laws, acts, ordinance, rules and regulations of the
municipalities, district, state and central govt. that may affect the work, its performance or personnel employed
therein.

Dated

For & behalf of the Bidder

Page 13 of 22

<!-- page 14 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

To
Director cum Principal,
Rajiv Gandhi Govt. Engg. College,
Nagrota Bagwan, Kangra, H.P.
PIN 176047
Sir,
ACCEPTANCE OF TENDER CONDITIONS
The tender documents for the work “Supply, Installation and Commissioning of Indoor Gym Equipment at
Rajiv Gandhi Govt. Engg. College, Nagrota Bagwan, Kangra (H.P.)” been downloaded by me/us from
https://rggec.ac.in and I/We hereby unconditionally accept the tender conditions and tender documents in its
entirety for the above work.
1.

The contents of the Tender documents have been noted wherein it is clarified that after unconditionally
accepting the tender condition in its entirety, it is not permissible to put any remark(s)/conditions(s) in
the tender enclosed in “Cover-2” and the same has been followed in the present case. In case this
provision of the tender is found violated at any time after opening of the “Cover-1”, I/we agree that the
tender shall be summarily rejected and RGGEC shall, without prejudice to any other right or remedy be
at liberty to forfeit the full said earnest money absolutely.

2.

I/we have not made any misleading or false representation in the forms, statements and attachments in
proof of the qualification requirements. In case this provision of the tender is found violated at any time
before or after opening of the Price bid/Award, I/we agree that the tender/Award shall be summarily
rejected and RGGEC shall, without prejudice to any other right or remedy be at liberty to forfeit the full
said earnest money/any other amount payable under this contract absolutely.

3.

If I/we will not fulfill the minimum qualifying criteria of the tender, I/we not lodge any claim for opening
of “Cover-2” of the tender.

Yours faithfully,
(Signature of the tenderer)
With rubber stamp
Dated:

Page 14 of 22

<!-- page 15 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

AGREEMENT FORM
This agreement made this day of (___________________), between the Director–cum-Principal, Rajiv Gandhi Govt.
Engg. College, Nagrota Bagwan, Kangra (H.P), a State Govt. Engineering College under the Department of Technical
Education, Vocational and Industrial Training, Himachal Pradesh having its Registered Office at Village Massal, P.O.
Nagrota Bagwan, Kangra (H.P), Pin 176047, [hereinafter referred to as “Rajiv Gandhi Govt. Engg. College, Nagrota
Bagwan, Kangra (H.P)” which expression shall include its administrators, successors, executors and assigns] of the one
part and M/s (______________________) (hereinafter referred to as the ‘Contractor’ which expression shall unless the
context requires otherwise include its administrators, successors, executors and permitted assigns) of the other part.
AND WHEREAS (_________________) had participated in the above-referred tender vide their tender dated__________
For the Supply, Installation and Commissioning of Indoor Gym Equipment at Rajiv Gandhi Govt. Engg. College,
Nagrota Bagwan now therefore this deed witnessed as under:

1. AWARD OF CONTRACT
SCOPE OF WORK
Rajiv Gandhi Govt. Engg. College, Nagrota Bagwan, Kangra (H.P) has awarded the contract to (M/S
________________________) for the work of Supply, Installation and Commissioning of Gym Indoor at Rajiv Gandhi
Govt. Engg. College, Nagrota Bagwan on the terms and conditions in its letter of intent No
dated and
the
documents referred to therein. The award has taken effect from _____________(date) i.e. the date of issue of aforesaid
letter of intent. The terms and expressions used in this agreement shall have the same meanings as are assigned to them
in the “Tender Documents” referred to in the succeeding Article.

2. TERMS AND CONDITION
The contract shall be performed strictly as per the terms and conditions stipulated herein and in the following documents
attached herewith (hereinafter referred to as “Contract Documents”).
a)

Rajiv Gandhi Govt. Engg. College, Nagrota Bagwan, Kangra (H.P.) Notice Inviting Tender vide
No.________________________________________date ______and Rajiv Gandhi Govt. Engg. College, Nagrota
Bagwan, Kangra (H.P)’ s tender documents consisting of:

i)

Terms and Condition including Performa & appendices along with amendment(s)/ errata (if any) issued.

b)

(M/S ________________________) letter proposal dated

i)

Letter of Acceptance of Tender Conditions dated

____

and their subsequent Communication:

ii) Warranty form
All the aforesaid contract documents referred to in Para 1 and 2 above shall form an integral part of this Agreement, in
so far as the same or any part thereof column, to the tender documents and what has been specifically agreed to by Rajiv
Gandhi Govt. Engg. College, Nagrota Bagwan, Kangra (H.P.) in its Letter of Intent. Any matter inconsistent therewith,
contrary or repugnant thereto or deviations taken by the Contractor in its “TENDER” but not agreed to specifically by
Rajiv Gandhi Govt. Engg. College, Nagrota Bagwan, Kangra (H.P.) in its Letter of Intent, shall be deemed to have been
withdrawn by the Contractor without any cost implication to Rajiv Gandhi Govt. Engg. College, Nagrota Bagwan,
Page 15 of 22

<!-- page 16 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF INDOOR GYM EQUIPMENT AT
RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)
Kangra (H.P.). For the sake of brevity, this Agreement along with its aforesaid contract documents and Letter of Intent
shall be referred to as the “Contract”.

3. CONDITIONS & CONVENANTS
The scope of Contract, Consideration, terms of payments, advance, security deposits, taxes wherever applicable,
insurance, agreed time schedule, compensation for delay and all other terms and conditions contained in Rajiv Gandhi
Govt. Engg. College, Nagrota Bagwan, Kangra (H.P.)’s Letter of Intent No.
dated
are to be read in
conjunction with other aforesaid contract documents. The contractor shall duly perform the contract strictly and
faithfully in accordance with the terms of this contract.
The scope of work shall also include all such items which are not specifically mentioned in the Contract Documents but
which are reasonably implied for the satisfactory completion of the entire scope of work envisaged under this contract
unless otherwise specifically excluded from the scope of work in the Letter of Intent. Contractor shall adhere to all
requirements stipulated in the Contract documents. Time is the essence of the Contract and it shall be strictly adhered
to. The progress of work shall conform to agreed works schedule/contract documents and Letter of Intent.
This agreement constitutes full and complete understanding between the parties and terms of the presents. It shall
supersede all prior correspondence to the extent of inconsistency or repugnancy to the terms and conditions contained
in Agreement. Any modification of the Agreement shall be effected only by a written instrument signed by the authorized
representative of both the parties.
The total contract price for the entire scope of this contract as detailed in Letter of Intent is Rs.____________
(Rupees
only), which shall be governed by the stipulations of the contract documents.

4. GOVERNING LAW AND JURISDICTION
The Laws applicable to this contract shall be the laws in force in India and jurisdiction of court in Kangra (H.P.) only.
Notice of Default
Notice of default given by either party to the other party under the Agreement shall be in writing and shall be deemed
to have been duly and properly served upon the parties hereto, if delivered against acknowledgment due or by official
e-mail or by registered mail duly addressed to the signatories at the address mentioned herein above.
IN WITNESS WHEREOF, the parties through their duly authorized representatives have executed these presents
(execution whereof has been approved by the Competent Authorities of both the parties) on the day, month and year
first above mentioned.

For and on behalf of

For and on behalf of:

(NAME OF CONTRACTOR/TENDERER)

Director cum Principal

WITNESS:

WITNESS:

1.

1.

2.

2.

Page 16 of 22

<!-- page 17 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF COMMERCIAL GRADE GYM
EQUIPMENT FOR THE INSTITUTE GYMNASIUM AT RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

Annexure-I
I hereby submit financial quotes (including Installation charges, Transportation charges, and including of all taxes) for supply of under mentioned Gym
Equipment (As per Specification given at Annexure-II of the Tender Document) for Supply, Installation and Commissioning of Indoor Gym Equipment at
Rajiv Gandhi Govt. Engg. College, Nagrota Bagwan, H.P.
PRICE BID/ BOQ
(COVER-2 FINANCIAL BID)

Item No.

Item

Qty

1

Treadmill

1

2

Elliptical Trainer

1

3

Gym Bike

1

4

Home Gym

1

5

Smith Machine

1

6

Multi Adjustable Bench

1

7

Olympic Rods

2 Nos. (Total= 40 kg)
Straight Barbells (Various sizes)- 3 nos.
Curled barbells - 2 Nos.
(Total= 63 kg)
1, 2.5, 5, 7.5, 10, 12.5, 15, 17.5, 20 kg - 3 sets
each
22.5, 25, 30 kg- 2 set each
(Total= 428*2 = 856 kg)

8

Barbells

9

Dumbbells Set

10

Dumbbell Rack

1

11

Kettlebell

2, 3, 5 kg- 1 No. each
(Total= 10 kg)

12

Gym Interlock able Floor Mat

485 sq. ft.

13

Olympic Plates

Rate per
unit/ sqft/ kg
(Including
GST)

Amount (Including GST)

Strictly As per Annexure-II of Tender Document

Specifications

2.5, 5, 7.5, 10, 15, 20, 25 kg- 4 No's Each
(Total= 340 kg)

*Note: 1. Please quote “Rate per kg” for item no. 7, 8, 9, 11 and 13

Total
Sign of Bidder with Stamp
Page 17 of 22

<!-- page 18 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF COMMERCIAL GRADE GYM
EQUIPMENT FOR THE INSTITUTE GYMNASIUM AT RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

Annexure-II
Gym Equipment Technical Specifications
Item
No.

1

2

3

Name of
Goods or
Related
Services

Technical Specifications of Item
and/or Bureau of Indian
Standards (BIS) (if applicable)
reference

Treadmill

LCD display showing pulse,
time, RPM/Speed, distance,
calories, heart rate, body fat %,
Speed 0-24 kmph, Inclination 0- BMI, BMR, body type etc.
20%
Various auto programs for
Must include
23''x60'' (min) running surface,
different workout requirements
As
all
emergency stop button
and at least 1 manual program
required
accessories
Max. user weight 130 kg or more, Orthopedic running belt-heavy
AC power 3Hp Motor (6hp peak) duty, sweat proof console,
bottle holder, USB input and
headphone jack on console/
built in speaker

User Manual
Warranty
Installation
and requisite
in scope of
written
vendor
instruction
material

3 year at
least

1

Elliptical
Trainer

Various auto and
user
programs for different workout
requirements
LCD display showing pulse,
time, RPM/Speed, distance,
Must include
calories, heart rate, body fat %,
As
all
BMI, BMR, body type etc.
required
accessories
Pulse sensor, sweat proof
console
Adjustable
floor
levels,
Transportation
wheels,
adjustable swing bar

User Manual
Warranty
Installation
and requisite
in scope of
written
vendor
instruction
material

3 year at
least

1

User Manual
Warranty
Installation
and requisite
in scope of
written
vendor
instruction
material

3 year at
least

1

Gym Bike

Max. user weight 135kg
With adaptor power system
Magnetic motor at least 24
resistance levels

Magnetic brake, V-belt drive,
Tension control system
Max. user weight 130 kg
With adaptor power system

Features

Accessories

Spare
Parts

Various auto and
user
programs for different workout
requirements
LCD display showing pulse,
time, RPM/Speed, distance,
Must include
calories, heart rate, body fat %,
As
all
BMI, BMR, body type
required
accessories
Hand grip pulse sensor,
adjustable seat height, counter
balance
pedals,
transport
wheels

Page 18 of 22

Documents

Installation Warranty of
and
Equipment /
Training
Parts

Qty.

<!-- page 19 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF COMMERCIAL GRADE GYM
EQUIPMENT FOR THE INSTITUTE GYMNASIUM AT RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

4

Compact Design, With leg
extension, leg press, triceps
extension, Hi-Lo pulley, lat pull,
pec-dec, multi-press, abdominal
crunch, Bicep curl, Bench press,
knee raise, chin-up & dip stand
Home Gym
etc.
2 weight stacks with cover at least
70 kg weight each
Steel frame, powder coated,
superior grip material and leather/
leatherette material on seats and
touch points
Min. dimensions:142x221x226
cm
Appropriate arrangement for
holding weight plates on the
frame
Counter Balanced, aluminum
pulley
Moveable Olympic rod with
appropriate system to lock
position

5

Smith
Machine

6

Multiple positions incline, flat,
decline. Adjustable incline for
Multi
barbell set holder and seat
Adjustable
Padded rollers and seat for
Bench
maximum comfort.
Adjustable seat

7

Olympic
Rods

2 Nos
Premium material SS
(Total wt. = 40kg)

Must include
all
accessories,
As
collars,
required
ropes,
Olympic bars
etc. required

User Manual
Warranty
Installation
and requisite
in scope of
written
vendor
instruction
material

3 year at
least

1

Must include
Strong
sturdy
design,
all
Materials- Coated/ Painted Iron
accessories,
Frame .
As
collars,
All cables used should be
required
ropes,
sturdy and properly covered
Olympic bars
with rubber coating
etc. required

User Manual
Warranty
Installation
and requisite
in scope of
written
vendor
instruction
material

3 year at
least

1

Installation
in scope of
vendor

3 year at
least

1

3 year at
least

2 Nos.

Strong
sturdy
design,
MaterialsIron
Frame,
Painted/Powder Coated, Sitting
bench and soft points covered
with premium leather or
leatherette material

As
required

Net weight : 20 kg.
7.2 ft Olympic length.
Material: carbon steel.
High quality nickel chrome
finish.
Shaft diameter : 30mm.
Collars
Sleeve diameter : 50mm.
Sleeve length : 14”.
Max. load capacity : 816 kg /
1800 Lbs.

Page 19 of 22

<!-- page 20 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF COMMERCIAL GRADE GYM
EQUIPMENT FOR THE INSTITUTE GYMNASIUM AT RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)
High quality nickel chrome
finish.
Shaft diameter : 28mm.
Sleeve diameter : 50mm.
Sleeve length : 8”
Straight Barbell
1. Net weight: 10 kg, High
quality nickel chrome finish,
Shaft diameter: 28mm, Sleeve
diameter:
50mm,
Sleeve
length: 8”

8

Barbells

2. Net weight: 13 kg, High
quality nickel chrome finish,
Straight Barbells (Various sizes)Shaft diameter: 28mm, Sleeve
3 nos.
diameter:
50mm,
Sleeve Collars
Curled barbells - 2 Nos.
length: 11”.
(Total wt. = 63 kg)

Straight Barbells3 nos.
3 year at
least

3. 50 mm grip bar, Hard
chrome tempered alloy steel,
Max loading: 1600 lbs., 7.2 ft
Olympic length, Net weight: 20
kg.

Curled barbells 2 Nos.
(Total wt. = 63
kg)

Curled barbells
2 No.; Net weight: 10 kg, High
quality nickel chrome finish,
Shaft diameter: 28mm, Sleeve
diameter:
50mm,
Sleeve
length: 8”.

9

10

1, 2.5, 5, 7.5, 10, 12.5, 15, 17.5,
Dumbbells 20 kg - 3 sets each
22.5, 25, 30 kg- 2 set each
Set
(Total wt. = 428*2 = 856 kg)

Min. dimensions: 72x248x82 cm
Dumbbells Capable of stacking various size
dumbbells
Rack

Premium rubber coated, tear
proof, Weight indication on Collars
each weight

3 year at
least

Installation
in scope of
vendor

Strong
sturdy
design,
Materials- Coated Iron Frame

Page 20 of 22

3 year at
least

1, 2.5, 5, 7.5, 10,
12.5, 15, 17.5,
20kg - 3 sets each
22.5, 25, 30 kg- 2
set each
(Total wt. = 428
kg)

1

<!-- page 21 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF COMMERCIAL GRADE GYM
EQUIPMENT FOR THE INSTITUTE GYMNASIUM AT RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)
11

Kettlebell

2, 3, 5kg- 1 No. each
(Total wt. =10 kg)

12

Gym
Interlock
able Floor
Mat

High-density Rubber, at least
10mm thickness, Textured surface
Interlocking Mats
for maximum traction, dark
colored

Olympic
Plates

2.5, 5, 7.5, 10, 15, 20, 25 kg- 4
No's Each
(Total wt. = 340 kg)

13

Rubber coated with weight
indication
Installation
in scope of
vendor

High grade rubber, tear proof

3 year at
least

2, 3, 5kg- 1 No.
each
(Total wt. =10
kg)

3 year at
least

485 sq. ft.

3 year at
least

2.5, 5, 7.5, 10, 15,
20, 25 Kg- 4 No's
Each
Total wt. = 340
kg)

Sign of Bidder with Stamp

Page 21 of 22

<!-- page 22 -->

TENDER FOR SUPPLY, INSTALLATION AND COMMISSIONING OF COMMERCIAL GRADE GYM
EQUIPMENT FOR THE INSTITUTE GYMNASIUM AT RGGEC, KANGRA AT NAGROTA BAGWAN (H.P.)

END OF TENDER DOCUMENT

Page 22 of 22
