---
doc_id: "29afcab0cf7bfb76"
source_url: "https://ddtg.hp.gov.in/wp-content/uploads/2024/08/HIMSWAN-policy-dated-9-july-24.pdf"
ministry: "Digital Technologies and Governance Department, Himachal Pradesh"
title: "HIMSWAN Policy"
date: ""
pages: 7
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "5383f5afd14e6911"
---

<!-- page 1 -->

DIT-F05(2)//209-IT SECTION-GoHP /436632/2024
DIT-F05(2)/I/209-IT SECTION-GoHP (E-354) ~ 44
Department of Digital Technologies & Governance
Himachal Pradesh
took
From
The Director,
Department of Digital Technologies & Governance,
Government of Himachal Pradesh
To
il the Head of Departments,
Government of Himachal Pradesh
2. All Boards and Corporations,
Government of Himachal Pradesh
th July
Dated: Shimla-7043, the @  sune/2024
Subject: Regarding HIMSWAN Policy for State Government Departments/
Boards/Corporation
Sir,

Please find enclosed herewith a copy of Himachal State Wide Area Networks
(HIMSWAN) Policy for State Government Departments/Boards/Corporations to utilize /
procure HIMSWAN connectivity, so that the HIMSWAN Connectivity services are optimally
utilized.

This is for your information please.

Yours sincerely,
Ny )
Additional Director(IT),
Department of Digital Technologies & Governance,
Himachal Pradesh.
ah ey
Endst.No.: As above Dated: Shimla, ) dune! 2024

Copy forwarded to the Secretary (DTG) to the Government of Himachal Pradesh for
favour of kind information please.

Additional Director(IT),
Department of Digital Technologies & Governance,
Himachal Pradesh.

<!-- page 2 -->

Government of Himachal Pradesh
5 Department of Digital Technologies and Governance i
No.- DIT-F05(2)/4/209-IT SECTION-GoHP (e-354)- Dated: D8 — oG —24
aye
aie
NOTIFICATION
HIMSWAN Policy
(for State Government Departments/ Boards/ Corporations)

Contents

गरयियशा/ कर रत पर न भ मन बज मर ०0५70 05 4440० आस भ बल 0 4 राजद लक >. |

4. Requisition by Government Departments/ 80809/ 0ण"70ण"०रीं०णा३........................................३

2. Shortlisting of TSPs for providing HIMSWAN services at a particular location.................4

3. Commissioning of circuits and third-party AUdIt...............cccssssssssesessessssssssssssseseensssssnenesseeeedl

4.-Payment modalities: 42. Bie eee Sere LEAS \

5. Fate of existing ०णा॥8णी०॥६...................................----००---""___न-नन-नननन्न--तननानननाततलनन 5-56 |
i

<!-- page 3 -->

HIMSWAN Policy
Introduction
The Government of India had approved the Scheme for establishing State Wide
Area Networks (SWANs) across the country, in March, 2005 and provided funds to
the States for the establishment of SWANs and operating and managing the same
for initial period of five years which was further extended to one more year. SWAN
was envisaged as the converged backbone network for data, voice and video
communications throughout the State. The Scheme for establishing State Wide Area
Network (SWAN) across the country was approved to connect all State
Headquarters with District/Sub-Divisional/ Block Headquarters and further down to
Tehsil level. As on date, SWANs are operational in 34 States.
The States are utilizing the core infrastructure of SWAN for providing closed user
connectivity to various Government offices in the State. These offices access their
applications through SWAN in secured environment hosted at State Data Centres |
(SDCs). SWAN has been integrated with National Knowledge Network (NKN) at |
State Headquarter level and SWAN integration with NKN at district level has also i
been initiated and at present more than 500 districts have been integrated with NKN ;
across the country. ;
To monitor the performance of SWANs, the Ministry of Electronics & Information
Technology, Government of India also mandated positioning of Third Party Auditors
(TPAs) in the States.
Accordingly, Himachal Pradesh State Wide Area Network (HI MSWAN) was launched
on 5th February, 2008 to provide secured point to point connectivity to various |
government offices across the State. As on date, 2572 Government Departments / |
Boards / Corporations / Educational Institutions are connected through HIMSWAN.
The connectivity is being provided using latest technology (ie. MPLS line with
dedicated bandwidth on 7: basis) down to Sub Division/ Block/ Tehsil/ Sub Tehsil
level including Police Posts. All government applications hosted in HP SDC (approx.
94) or NIC Data Centre like CCTNS-CAS, eTreasury, eDistrict, eOffice,
HIMBHOOMI, Excise VAT/GST, VAHAN, SARTHI, eParivar, etc. are being accessed
2 HIMSWAN network in a secured manner.
oe
a oa ae |
Vv 2|Page

<!-- page 4 -->

HIMSWAN Policy
Telecom Service Providers (TSPs) have been engaged by the Department of Digital
Technologies and Governance (DDTG) through process of competitive bidding to
provide secured HIMSWAN connectivity to various government offices across the
State using dedicated MPLS / Lease Line link. Till now, cost of HIMSWAN
connectivity for government departments is being borne by the Department of Digital
Technologies & Governance. However, in case of Boards / Corporations, cost of
connectivity is being borne by the concerned Board/ Corporation. The Department of
Digital Technologies & Governance helps Departments/ Boards/ Corporations in
commissioning the HIMSWAN links, monitor HIMSWAN links, prepare uptime and
downtime reports, raise tickets once complaint is received from the end user
Department/ Board/ Corporation and provide Third Party Audit Report to the |
concerned Board/ Corporation for releasing the payments to the Telecom Service
Provider after deducting penalty, if arly, as per the Service Level Agreement signed
with the Telecom Service Providers. However, with the advent and wide spread
usage of applications like eOffice, the demand for HIMSWAN connectivity has i
exponentially increased in the past some time. Since financial liability arises on :
account of each HIMSWAN connection, which is provided through the selected !
Telecom Service Provider, it is imperative to formulate an SOP/ Policy for the
departments for HIMSWAN connectivity so that the services are optimally utilised f
and are within the financial proprietary framework of the State Government.
Accordingly, the following guidelines are being notified as HIMSWAN Policy for the
State of Himachal Pradesh:
. Requisition by Government Departments/ Boards/ Corporations
a. The Government Departments/ Boards/ Corporations shall place
requisition with the Department of Digital Technologies and Governance E
clearly mentioning therein the nature of applicant whether it is a ;
Department or a Board or a Corporation, the nature and names of
applications proposed to be run on HIMSWAN Network and the bandwidth
required.
b. The Department of Digital Technologies and Governance (DDTG) shall
scrutinize each application technically. It has been observed that many
Government Departments/ Organizations place requisition for HIMSWAN
oS connectivity mistaking it for Internet connectivity without the need for |;
ae _——Tmnning any specific applications on the secured network. If on scrutiny, it
3|Page

<!-- page 5 -->

HIMSWAN Policy
is established that the Department/ Organization has no specific
application to be run on HIMSWAN and the applicant body is only in the
need of an internet connection, the DDTG shall advise the Department/
Organization to procure the internet connection locally since the cost of
secured, dedicated, point to point HIMSWAN connectivity is many times as
compared to internet connection of same speed.
2. Shortlisting of TSPs for providing HIMSWAN services at a particular location
a. If the application of Government Department’ Board/ Corporation is found
in order and it is established that they are in need of HIMSWAN
connectivity for the purpose of running applications on secured network,
the DDTG shall forward the request to the shortlisted Telecom Service
Providers to assess the technical feasibility of the site(s).
b. Based on the technical feasibility reported by the Telecom Service
Providers, the work will be assigned to the TSP which has reported the i
site as technically feasible. In case multiple TSPs have reported the site as |
feasible, the work will be assigned by DDTG to the TSP as per criteria |
fixed during tendering process. However, the work shall be awarded only
at L rate arrived at through the process of competitive bidding. In case of ;
Boards/ Corporations, it shall be explicitly mentioned in the work order that
the cost of providing HIMSWAN connectivity shall be borne by the
concerned organization.
3. Commissioning of circuits and third-party audit
a. The TSP which has been entrusted with commissioning of HIMSWAN f
circuit at a particular site shall after commissioning the circuit, submit a f
report to DDTG regarding the same along with acknowledgment of
Satisfactory commissioning by the applicant Department/ Board/
Corporation.
b. Upon receipt of report by TSP, the DDTG shall forward the report to third
party auditor for verification of the links and if such links are verified, the
HIMSWAN connectivity shall be deemed to be commissioned from the
date when the applicant Department/ Board/ Corporation has
eae acknowledged the satisfactory commissioning.
4|Page

<!-- page 6 -->

HIMSWAN Policy

c. After the successful commissioning of the site, the DDTG shall monitor
HIMSWAN links, prepare uptime and downtime reports, raise tickets once
complaint is received from the end user Department/ Board/ Corporation.

4. Payment modalities

a. The TSPs shall raise bills on a quarterly basis in respect of those sites
which have been commissioned and working successfully. The billing
cycle shall start at the end of each quarter and shall include those sites as
well which have been commissioned during the quarter. For instance, the
TSP while raising the bills of first quarter from April to June of a Financial
Year shall include the bills of such sites which have been commissioned in
May or June as well and the next billing cycle of such sites shall continue
along with previously commissioned sites at the end of next quarter.

b. The DDTG on the basis of third party audit shall arrive at payment to be ae
made to a Telecom Service Provider as per the bills raised as 6 |_ 85
after deducting penalties as per Service Level Agreement, if any. In case |
the successful site commissioning took place during the quarter, the part |
payment admissible to the TSP for that particular site shall be calculated ।
on pro-rata basis from the date of commissioning as mentioned at clause
3(b) above.

c. The DDTG shall make admissible payments to the TSPs on quarterly
basis as per bills raised and after due verification in respect of
Government Departments only. These payments shall be charged to the
budgetary outlay provided by the State Government to the Department of
Digital Technologies and Governance under the relevant head. In case, |
there is a shortfall of funds on this account, the Department shall seek
additionality under the relevant head.

d. For the Boards and Corporations, the DDTG after verification and
deduction of penalties, if any, shall forward the bills raised by the TSPs to
their respective offices. The concerned Board/ Corporation shall make
payment directly to the concerned TSP under intimation to the Department

= of Digital Technologies and Governance. In case the concerned Board and
as Corporations fails to make payment within a period of 45 days from the
5|Page

<!-- page 7 -->

HIMSWAN Policy
date of receipt of verified bills from the DDTG, the concerned TSP shall be
at liberty to disconnect the HIMSWAN connectivity.
5. Fate of existing connections
a. As already noted at clause (b), some Departments which do not have any
application to be run through secure HIMSWAN network have been issued :
HIMSWAN connections for internet purposes e.g., Schools, Hospitals etc.
All such connections shall be reviewed by the DDTG through the third
party auditor.
b. In case it is reported that a particular connection is not accessing any
secure application through the HIMSWAN network and is merely using the '
connection for internet purpose, correspondence will be made with that
particular Department/ Organization with the advice to shift to broadband
internet connectivity through open market and with notice that HIMSWAN
connectivity shall be discontinued after 45 days from the date of issue of ;
letter.
Approved vide NN-383 |;
Secretary (DT&G),
Department of Digital Technologies & Governance,
Himachal Pradesh.
Endst.No.: As above Dated:
Copy forwarded to:
. Secretary (DDTG) to the Government of Himachal Pradesh for favour of kind
information please.
2. All the Head of Departments in the Government of Himachal Pradesh for |;
information please. I
3. All Boards and Corporations in the State of Himachal Pradesh for —— |
please. |
oS ae -
“Directo\(DT&G),
Department of Digital Technologies & Governance,
Mehli Shimla -3, Himachal Pradesh.
6|Page
