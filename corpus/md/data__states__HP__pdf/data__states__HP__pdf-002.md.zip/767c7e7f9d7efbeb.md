---
doc_id: "767c7e7f9d7efbeb"
source_url: "https://hpbiodiversity.gov.in/BMC/Notification_threatened_species.pdf"
ministry: "Himachal Pradesh State Biodiversity Board, Himachal Pradesh"
title: "Notification of Threatened Species"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "59df93c53bca7655"
---

<!-- page 1 -->

70

Gazatte.p65

70

12/23/2009, 12:23 PM

<!-- page 2 -->

71

Gazatte.p65

71

12/23/2009, 12:23 PM
