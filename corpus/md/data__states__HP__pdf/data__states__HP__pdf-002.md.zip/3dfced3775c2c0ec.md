---
doc_id: "3dfced3775c2c0ec"
source_url: "https://ayurveda.hp.gov.in/Panchkarma.pdf"
ministry: "Ayurveda Department, Himachal Pradesh"
title: "Notification regarding requisition of 29 posts of Panchkarma Masseurs Class-Iv on Daily Wage basis in AYUSH VIBHAG"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "8512ff511552dace"
---

<!-- page 1 -->

AYUSH VIBHAG,
HIMACHAL PRADESH, SHIMLA-171009.
ADVERTISEMENT
The AYUSH VIBHAG, Himachal Pradesh, Block No. 26, SDA Complex Kasumpati,
Shimla-171009, invites the applications from the desirous/eligible candidates for filling up of 29 Posts of
Panchkarma Masseurs (Class-IV) on Daily wage basis in accordance with the Recruitment & Promotion
Rules for the post of Panchkarma Masseurs (Class-IV) daily wage basis @ 350/- per day.
1

2
3
4

Name
&
Address
of
Employer
Phone
Number, if any
Total No. of
post
Reservation
against
Category

Director AYUSH, H.P., Block No. 26, SDA Complex, Kasumpati,
Shimla-171009, H.P.
0177-2622262
Panchkarma Masseurs-29 (Twenty Nine only) Daily Wage Basis.
Male

Category
Gen
SC
ST
OBC
EWS
Total

Total Number of Posts
08
02
00
03
02
15

Female

5

Minimum
Educational
Qualification
Essential

Gen
08
SC
02
ST
00
OBC
03
EWS
01
Total
14
G. Total
29
a)Essential Qualification(s):
i)
Matric from a recognized Board of School Education.
Provided that the Middle and Matriculation must be passed from any
School/Institution situated within Himachal Pradesh.
Provided further that this condition shall not apply to Bonafide
Himachalis.
ii)

6

Age limit

7

Place
Posting

06 (Six) months Diploma/Training Certificate in Panchkarma from an
institution recognized by the Government of Himachal Pradesh.
b) Desirable Qualifications:
Knowledge of customs; manners and dialects of Himachal Pradesh and
suitability for appointment in the peculiar conditions prevailing in the
Pradesh..
Between 18 to 45 years. (As on 01-01-2022)
(The upper age limit is relaxable by five years for candidates belonging to
Scheduled Caste, Scheduled Tribe and Other backward Classes.
of In Panchkarma Units any where in the State, H.P.

<!-- page 2 -->

8

Mode
Selection

of Selection for appointment to the post in the case of direct recruitment shall be
made on the basis of merit of prescribed educational qualification followed by
evaluation as specified here under:1. Merit of minimum educational qualification, 85 Marks
in terms of the Recruitment & Promotion
Rules, shall be calculated as under:{Percentage of marks obtained in prescribed
educational qualification to be calculated out
of 85 marks. For example, a candidate getting
50% marks in Matric will be given 42.5
marks}
2. Evaluation of Candidate to be made in the 15 marks
following manner:i) Belonging to notified Backward Area
or Panchayat, as the case may be. =01
Mark
ii) Land less family/family having land
less than 1 Hectare to be certified by
the concerned Revenue Authority.
=02 Marks
iii) Non-employment Certificate to the
effect that none of the family
members is in Government/Semi
Government service. =2.5 Marks
iv) Differently abled persons with more
than
40%
impairment/disability/infirmity.=01
Mark
v) NSS (atleast one year)/ certificate
holders in NCC/The Bharat Scout and
Guide/Medal winner in National
Leave sports competitions. =01 Mark
vi) BPL family having annual income
(from all sources) below Rs. 40,000/or as prescribed by the Govt. from
time to time. =2.5 Marks
vii) Widow/divorced
/destitute/single
woman =1.5 Marks
viii) Single daughter/Orphan =01 Mark
ix) Experience upto a maximum of 5
years
in
Government/SemiGovernment Organization relating to
the post applied for (0.5. marks only
for each completed year) =2.5 Marks.

9

How to Apply

The desirous and eligible candidates applying for the post of Panchkaram
Masseur may apply on the prescribed application form which can be downloaded from the Departmental Website (website: Ayurveda.hp.gov.in) alongwith
attested copies of all relevant testimonials/documents so as to show their
age/qualification/Diploma/Degree, experience etc. & Character certificate,

<!-- page 3 -->

10

11

12

13
14

Bonafide certificate & BPL etc. The applications should be addressed to the
Director of Ayush, Himachal Pradesh, Block No.-26 SDA Complex, Kasumpatti,
Shimla-171009. The envelope containing application form should be superscribed as “APPLICATION FOR THE POST OF PANCHKARMA MASSEUR
(Daily wage basis).
Evaluation
The scrutiny/verification and evaluation of documents/certificates shall be made
by constituting a Committee of the departmental officers. The final selection will
be made on the basis of merit of prescribed educational qualification followed by
evaluation as per R&P Rules.
Place and Date Place: Department of AYUSH, H.P., SDA Complex, AYUSH Bhawan,
of
selection
Block No. 26, Kasumpati, Shimla-171009, H.P.
process
Date: To be intimated later on.
Last date of 27-09-2022 ,
submission of 30-09-2022 (for Tribal areas i.e. District L&S, Kinnaur & Pangi, Bharmour area
application
of Chamba District)
TA/DA
No TA/DA for attending interview
Terms
and The appointment shall be subject to the terms and conditions as per policy of the
conditions
Govt. from time to time.
Applications are invited on the format given with this Advertisement.

(Vinay Singh)IAS
Director Ayush
Himachal Pradesh

<!-- page 4 -->

APPLICATION FORM FOR THE POST OF PANCHKARMA MASSEURS (CLASS-IV)
ON DAILY WAGE BASIS.
Space for attested
photograph
(Passport Size)

Last Date of receipt of applications:The last date of receipt of application is -------- and in case of tribal areas the
applications should reach upto------.
01.

Name of Applicant (In Capital Letters) ___________________________________________________

02.

Father’s/Husband’s Name (In Capital Letters) ___________________________________________

03.

Gender(Male /Female) ____________________________________________________________________

04.

Name of Post Applying for___________________________________________________________________

05.

Date of Birth ________________________________________________________________________________

06.

Age as on 01.01.2022______________________________________________________________________

07.

Detail of Educational Qualification ________________________________________________________

Name of
Examination

Roll NO.

Year of
Passing

Name of
Max
Board/University Marks

Marks
Obtained

%age

08.

Professional Qualification __________________________________________________________________

09.

Name of Employment Exchange with
Registration No.

10.

Category to which belong
(proof of the same be attached) __________________________________ ________________________

11.

Nationality____________________________________________________________________________________

12.

Religion______________________________________________________________________________________

: Name
_______________
: No___________________________________

<!-- page 5 -->

13.

Himachali Bonafide__________________________________________________________ Yes/No
(Copy enclosed)

14.
15.

Character Certificate____________________________________________________________Yes/No
(Copy enclosed)
Contact Number________________________________________________________________________

16.

Experience relating to the post applied for, if any ____________________________Yes/No

17.

Have you ever been debarred or disqualified by any Public Service
Commission/Recruitment Board from any of the Examination Selection? ____ Yes/No

18.

Have you ever been convicted by any court for any offence?_________________Yes/No

19.

Permanent Home Address:_________________________________________________________________

________________________________________________________________________________________________________
20.

Address for correspondence: _____________________________________________________________

______________________________________________________________________________________

Signature of Applicant
DECLARATION
I ______________________________________ hereby solemnly declare that I am a
bonafide resident of Himachal Pradesh and all the statements/ particulars furnished by me
in this application are correct and true to the best of my knowledge and belief. In the event
of any information being found false or incorrect, suppressed or ineligibility is detected at
any stage, my candidature shall liable to be rejected/cancelled.
Dated:
Place:

Signature of Applicant
