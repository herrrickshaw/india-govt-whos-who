---
doc_id: "a281b34accd1eecf"
source_url: "https://www.hp.gov.in/hpdmer/file.axd?file=2018%2f6%2fIndian+Nursing+Council+Guidelines+for+opening+of+M.Sc+Nursing+course.pdf"
ministry: "Directorate of Medical Education & Research, Himachal Pradesh"
title: "Indian Nursing Council Guidelines for opening of M.Sc Nursing course."
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0c3356b3301374aa"
---

<!-- page 1 -->

Website: www.indiannursingcouncil.co.in
E-mail : secy2010@indiannursingcouncil.org

Fax: 23236140
Phone : 23235570, 23235619

INDIAN NURSING COUNCIL
COMBINED COUNCILS BUILDING
KOTLA ROAD, TEMPLE LANE
NEW DELHI-110 002
GUIDELINES AND MINIMUM REQUIREMENTS TO ESTABLISH
M.Sc.(N) COLLEGE OF NURSING
Guidelines for Establishment of M.Sc. Nursing Programme

I.

Guidelines and Minimum Requirements for establishment of a
M.Sc. Nursing Programme having recognized B.Sc. (N) College.
1)

Any organization under: (i) Central Government/State
Government/Local body (ii) Registered Private or Public Trust
(iii) Missionary or any other organization registered under
Society Registration Act (iv) Company incorporated under
section 25 of company’s act are eligible to establish M.Sc. (N)
College of Nursing.

2)

Indian Nursing Council recognized B.Sc. (N) College of Nursing
wherein one batch has passed out is eligible to establish M.Sc.
(N) Programme.

3)

Above organization shall obtain the Essentiality Certificate/No
Objection Certificate for the M.Sc. (N) programme from the
respective State Government. The institution name alongwith
Trust Deed/Society address shall be mentioned in No Objection
Certificate/Essentiality Certificate.

4)

An application form to establish Nursing programme is
available on the website viz., www.indiannursingcouncil.org,
which shall be downloaded. Duly filled in application form with
the requisite documents mentioned in the form shall be
submitted before the last date as per the calendar of events of
that year.

1

<!-- page 2 -->

II.

5)

The Indian Nursing Council on receipt of the proposal from the
Institution to start nursing programme, will undertake the first
inspection to assess suitability with regard to physical
infrastructure, clinical facility and teaching faculty in order to
give permission to start the programme.

6)

After the receipt of the permission to start the nursing
programme from Indian Nursing Council, the institution shall
obtain the approval from the State Nursing Council and
University.

7)

Institution will admit the students only after taking approval of
State Nursing Council and University.

Guidelines for Super Speciality Hospital for establishment of a
M.Sc. Nursing Programme
1)

Any organization under: (i) Central Government/State
Government/Local body (ii) Registered Private or Public Trust
(iii) Missionary or any other organization registered under
Society Registration Act (iv) Company incorporated under
section 25 of company’s act are eligible to establish M.Sc. (N)
College of Nursing.

2)

Above organization shall obtain the Essentiality Certificate/No
Objection Certificate for the M.Sc. (N) programme from the
respective State Government. The institution name alongwith
Trust Deed/Society address shall be mentioned in No Objection
Certificate/Essentiality Certificate.

3)

An application form to establish Nursing programme is
available on the website viz., www.indiannursingcouncil.org,
which shall be downloaded. Duly filled in application form with
the requisite documents mentioned in the form shall be
submitted before the last date as per the calendar of events of
that year.

4)

The Indian Nursing Council on receipt of the proposal from the
Institution to start nursing programme, will undertake the first
inspection to assess suitability with regard to physical
infrastructure, clinical facility and teaching faculty in order to
give permission to start the programme.

2

<!-- page 3 -->

5)

After the receipt of the permission to start the nursing
programme from Indian Nursing Council, the institution shall
obtain the approval from the State Nursing Council and
University.

6)

Institution will admit the students only after taking approval of
State Nursing Council and University.

*Super Speciality Hospital are eligible to start M.Sc.(N) provided they
have following respective speciality beds

Cardio thoracic beds


50-100 bedded Cardiac Hospital, which has CCU, ICCU and ICU
units with own thoracic unit or affiliated thoracic unit.

Critical Care beds


250-500 bedded Hospital, which has a 8-10 beds critical care beds
& ICUs

OBG speciality beds
50 bedded parent hospital having:
i.
Mother and neonatal units
ii.
Case load of minimum 500 deliveries per year
iii.
8-10 level II neonatal beds.
iv.
Affiliation with level III neonatal beds
Neuro speciality beds


Minimum of 50 bedded Neuro care institution with advanced
diagnostic, therapeutic and state of the art clinical facilities

Oncology speciality beds


Regional Cancer centers/Cancer Hospitals having minimum 100
beds, with medical and surgical oncology units with
chemotherapy, radiotherapy, palliative care, other diagnostic and
supportive facilities.

3

<!-- page 4 -->

Orthopaedic Speciality beds


250-500 bedded Hospital, which has a 50 orthopaedic beds &
rehabilitation units.

Psychiatric beds


Minimum of 50 bedded institutes of psychiatry and mental health
having all types of patients (acute, chronic, adult psychiatric beds,
child psychiatric beds and de-addiction facilities), with advanced
diagnostic, therapeutic and state of the art clinical facilities.

Paediatrics beds


50-100 bedded paediatric Hospital/ unit with paediatric surgery
and level II or III neonatal units

Gastroentrology beds


50-100 bedded gastroentrology beds

Nephro-Urology speciality beds


50-100 bedded nephro urology hospital with dialysis and kidney
transplants, urosurgery

Minimum Requirement to establish M.Sc. (N) Programme

PHYSICAL FACILITIES

Minimum 2 additional classrooms and one classroom as per the
number of electives.
Note:

Proportionately
the
rooms
&
other
facilities
will
increase/decrease according to the number of students
admitted.

4

<!-- page 5 -->

NURSING TEACHING FACULTY
M.Sc. (N)
If parent hospital is super-speciality hospital like cardio-thoracic
hospital/cancer with annual intake 10 M.Sc(N) in cardio
thoracic/cancer
Professor cum coordinator
1
Reader / Associate Professor
1
Lecturer
2
The above faculty shall perform dual role
B.Sc.(N) and M.Sc.(N)
Sl.
No.
1
2
3
4
5
6

Designation

Professor cum PRINCIPAL
Professor cum
VICE- PRINCIPAL
Professor
Associate Professor
Assistant Professor
Tutor

B.Sc.(N)

M.Sc.(N)

40-60
1
1

10-25

0
2
3
10-18

1*
1*
3*

*1:10 student patient ratio for M.Sc. (N)

One in each specialty and all the M.Sc(N) qualified teaching faculty will
participate in all collegiate programmes.
Teacher Student Ratio = 1 : 10 for M.Sc.(N) programme.
QUALIFICATIONS & EXPERIENCE OF TEACHERS OF COLLEGE OF
NURSING
S.
NO.
1.

POST, QUALIFICATION & EXPERIENCE

Principal cum Professor- 15 years experience with M.Sc.(N) out
of which 12 years should be teaching experience with minimum
of 5 years in collegiate programme.
Ph.D.(N) is desirable
5

<!-- page 6 -->

2.

Vice- Principal cum Professor- 12 years experience with
M.Sc.(N) out of which 10 years should be teaching experience
with minimum of 5 years in collegiate programme.
Ph.D.(N) is desirable

3.

Professor- 10 years experience with M.Sc.(N)
years should be teaching experience.

out of which 7

Ph.D.(N) is desirable
4.

Associate Professor- M.Sc. (N) with 8 years
including 5 years teaching experience

experience

Ph.D.(N) desirable
5.

Assistant Professor- M.Sc. (N) with 3 years teaching experience
Ph.D.(N) desirable

6.

Tutor- M.Sc.(N) Or B.Sc.(N)/P.B.B.Sc.(N) with 1 year experience

6
