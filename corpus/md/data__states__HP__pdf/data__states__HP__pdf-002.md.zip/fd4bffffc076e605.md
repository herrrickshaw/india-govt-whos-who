---
doc_id: "fd4bffffc076e605"
source_url: "https://ayurveda.hp.gov.in/DocumentVerifAMO.pdf"
ministry: "Ayurveda Department, Himachal Pradesh"
title: "Notification regarding Dates for Documents verification of Ayurvedic Medical Officer for Batch wise in AYUSH VIBHAG"
date: ""
pages: 23
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d5e1289c04206325"
---

<!-- page 1 -->

AYUSH VIBHAG
HIMACHAL PRADESH
Ayush Bhawan Block No. 26, SDA Complex, Kasumpti, Shimla- 171009
Phone No. 0177-2622262, 0177-2623066 email-ayur-hp@nic.in

Ayush Vibhag is in process of filling up of the posts of Ayurvedic Medical
Officer through batch wise basis for which applications were invited from
Himachali bonafide candidates having BAMS Degree and also name have been
sponsored by the Employment Exchanges of the state. Schedule for the scrutiny
and verification of documents of the candidates who have applied and those who
have been sponsored by the Employment Exchanges for the post has been issued.
Call letters to the candidates short listed according to record of their passing
year/batch have already been dispatched on their given address. All concerned are
required to appear for scrutiny of documents and verification as per the schedule
given below from 10.00 A.M. onwards in Directorate of Ayush Vibhag, H.P.
Shimla- 9. Detailed category wise schedule is as under :-

General Category
1

Dr. Vandana Chandel W/o. Sh. Sanjeev Chandel,
H.No. 112, Ward No.8 Naya Nagar Hamirpur, HP,
177001

2

Dr. Ekta Priyadarshini D/o. Sh. R.K. Sharma, VPO.
Raipur Maidan, Tehsil Bangana, Distt. Una, HP,

3

Dr. Meenu Saini W/o. Sh. Ajay Singh, Hno. 388 Shiv
Kutir Dehun Saprron Solan Tehsil & Distt. Solan,
HP,

4

Dr. Namarta Sharma w/o. Dr. Sushil Kumar Sharma,
House No. 147, Ward No. 10, Hamirpur, HP

Date fixed for documents
scrutiny/ Verification

17-08-22

<!-- page 2 -->

5

Dr. Neetu Sharma W/o Suresh Sharma, VPO. Lower
Andora, Tehsil Amb, Distt. Una, HP, 177203

6

Dr. Parveen Kumar S/o. Sh. Birla Ram, VPO.
Chanour, Tehsil Dehra, Distt. Kangra, HP, 177113

7

Dr. Shuchi Khanor W/o. Sh. Arun Khanor, Sunil
Rana S/o. Sh. Ranjee Singh Rana, Vill. Pragpur
(Tiyalu), Sub-Tehsil Pragpur, Tehsil Dehra, Distt.
Kangra, HP, 177107

8

Dr. Meenu Saini W/o. Sh. Ajay Kumar Singh, H.No.
388, Shiv Kutir Deonghat, P/o. Saproon, Solan, HP,
173211

9

Dr. Rashmi Mahajan D/o. Sh. Ashok Mahajan,
H.No.552, Depot Bazar, P.o. & Tehsil Dharamshala,
Distt. Kangra, HP, 176215

10

Dr. Arti Sharma D/o. Sh. K.K. Sharma, Ward No. 1,
Krishna Nagar, Hamirpur, HP

11

Dr. Gaurav Phull S/o. Sh. S.K. Pull, Harding Villa
Dhobi Ghat Road Sadhna Ghati Chotta Shimla,
Shimla East Shimla, 171002, HP

12

Dr. Jai Deep S/o Sh. Gulzari Ali, H.No. 384/8 Near
Balkishan Dentist Kahar Gali Nahan, P.O. & Teh.
Nahan, Distt. Sirmour, H.P 173001

13

Dr. Kusum Sharma W/o. Sh. Ashish Rana, Ayurveda
House, Ward No.2, P/o. Bhagsunag, Dharamshala,
Kangra, HP, 176219

14

Dr. Parveen Kumar S/o. Sh. Birla Ram, A1-603 Jal
Vayu Vihar Opp HMV College Workshop Chowk
Jalandhar Punjab, 144008

15

Dr. Praveen Sharma S/o. Sh. Lahori Ram, VPO.
Jahu, Tehsil Bhoranj, Distt. Hamirpur, HP

16

Dr. Purnima Mahajan W/o. Sh. Gaurav Gupta Ward
No. 01 Porian Mohalla, VPO. & Tehsil Sujanpur,
Distt. Hamirpur, HP, 176110

17

Dr. Rahul Dogra S/o. Sh. Pushpinder Kumar Dogra,
VPO. Bhoranj, Tehsil Bhoranj, Distt. Hamirpur, HP

<!-- page 3 -->

18

Dr. Rekha Sharma D/o. Sh. Mehar Chand Sharma
W/o. Sh. Gaurav Pull Harding Villa Dhobi Ghat
Road Sadhna Ghatti Chotta Shimla-2, HP

19

Dr. Sandeep Katoch S/o. Sh. T.C. Katoch, Ward
No.4, Aima Palampur, Distt. Kangra, HP, 176061

20

Dr. Sanjeev Kumar Pathania S/o. Sh. Gandhrb Singh
Adarash Nagar, H# 353 Hamirpur Road Una, Tehsil
& Distt. Una, HP, 174303

21

Dr. Smita Kumari W/o. Sh. Parveen Kumar, VPO.
Chanour, Tehsil Dehra, Distt. Kangra, HP, 177113

22

Dr. Suprit Gupta S/o. Sh. Bipan Gupta, Ward No. 1,
Near PWD Rest House, Sujanpur Tira, Distt.
Hamirpur, HP, 176110

23

Dr. Tarun Rajput S/o. Late Sh. Satyapal Singh, Solan
Homoeopathic Medical colledge & Hospital Barog
Bye Pass Kumarhatti Solan, HP, 173229
Dr. Alpna Sharma D/o. Sh. Brahm Chand, Vill.
Piadkar, P/o. Masiana, Tehsil & Distt. Hamirpur, HP

24
25

26

Dr. Anjali Sapra W/o Sh. Amit Jaswal, C/o Beauty
Corner, Chotta Chowk Nahan, Distt. Sirmour, H.P
173001
Dr. Anu Sharma W/o. Sh. Kashmiri Lal Sharma,
Vill. Alsu, P/o. Dehar, Tehsil Sunder Nagar, Distt.
Mandi, HP, 175030

27

Dr. Anuradha Chaudhary W/o. Susheel Kumar, Moh.
Bangotu (Near Rangmahal), Tehsil & Distt. Chamba,
HP, 176310

28

Dr. Archana Chauhan D/o. Sh. Prithi Chand, Rana
Niwas House No. 596, Ward No-03, Palampur, Teh
Palampur, Distt. Kangra, H.P, 176061

29

Dr. Arvind Vipin S/o. Sh. Chander Knat, Vill.
Harkukar, P/o. & Tehsil Ghumarwin, Distt. Bilaspur,
HP, 174021

30

Dr. Ashima Mahajan D/o. Parveen Kumar, VPO.
Tehsil Jawali, Distt. Kangra, HP, 176023

<!-- page 4 -->

31

Dr. Avinash Sharma S/o. Sh. Puran Chand Sharma,
Vill. Palli, P/o. Jakhara, Tehsil Fatehpur, Distt.
Kangra, HP, 176021

32

Dr. Balbir Singh Thakur S/o. Sh. Dharam Singh
Thakur Shanti Kunj Building Kings Ley Estate, Near
Post Office, Sanjauli Shimla, HP, 171006

33

Dr. Bharti Vaid W/o. Neeraj Joshi, Moh. Bangotu,
Tehsil & Distt. Chamba, HP, 176310

34

Dr. Divya Goswami, D/o. Subhash Sharma, H. No.
73, W/No. 10, Bala Behar, Kullu, HP, 175101

35

Dr. Esha Marwah W/o Sh. Sachin Suri, Moh. Surara,
P/o. Chamba, Tehsil & Distt. Chamba, HP, 176310

36

Dr. Kartik Sharma S/o Sh. R.K. Sharma, Vill.
Kharouth, P.O. Ballah, Teh. Palampur, Distt. Kangra,
H.P 176061

37

Dr. Kuldeep Kumar S/o. Sh. Anant Ram, Vill. Nand
Behal, P/o. Toba, Tehsil Sh. Naina Devi ji, Distt.
Bilaspur, HP
Dr. Mahesh Sharma S/o. Sh. Mahant Ram Sharma,
VPO. Harlog, Tehsil Ghumarwin, Distt. Bilaspur,
HP, 174003

38

39

40
41

42

Dr. Manoj Kumar Mehta S/o. Sh. Gopal Singh Mahta
Estate Below Housing Board Colony Sanjauli, P/o.
Sanjauli, Tehsil & Distt. Shimla, HP, 171006
Dr. Mohini Bisht W/o. Sh. Harinder Patial, VPO.
Mundkhar, Tehsil Bhoranj, Distt. Hamirpur, HP
Dr. Monika Thakur W/o. Sh. Manjeet Singh, VPO.
Kangoka Gehra, Tehsil Dharampur, Distt. Mandi,
HP,
Dr. Nirpuma Thakur W/o. Sh. Sunil Kumar, Vill. &
P/o. Bijhari, Tehsil Bijhari, Distt. Hamirpur, HP,
176040

43

Dr. Pooja W/o. Sh. Shashi Kant, Vill. Jamsai, P/o. &
Tehsil Sarkaghat, Distt. Mandi, HP, 175024

44

Dr. Promila Devi D/o. Sh. Man Singh, Vill. Kallri,
P/o. Nakrana, Tehsil Shi. Naina Devi Ji, Distt.
Bilaspur, HP

<!-- page 5 -->

45

Dr. Rahul Dogra S/o. Sh. Pushpinder Dogra, H. No.
623/A, New Jyoti Nagar, Near Nahar Colony Gate.
Jagadhari, Haryana

46

Dr. Rajeev Nayyar S/o. Sh. G.C. Nayyar, Moh.
Rangmahal, Tehsil & Distt. Chamba, HP

47

Dr. Rajeev Verma S/o. Sh. D.N. Verma Kala
Bhawan Near HP Marketing Board Khalini Shimla-2

48

Dr. Rashmi Mahajan D/o. Late Sh. Ashok Mahajan,
House No. 135, Ward No. 7 Depot Bazar,
Dharmshala, HP, 176215

49

Dr. Ravinder Singh S/o. Sh. Yog Singh, Vill. Bagori,
P/o. Kiani, Tehsil & Distt. Chamba, HP, 176310

50

Dr. Ritika Katoch D/o Sh. Baldev Katoch, V.P.O.
Bhawarna, Teh. Palampur, Distt. Kangra H.P 176083

51

Dr. Ritu Ohri D/o. Sh. Avinash Chander Ohri, W# 5
Mohalla Porian Wala Una, Tehsil & Distt Una, HP,
174303

52

Dr. Sachin Pathak S/o. Sh. Prithvi Raj Pathak, VPO.
Pakka Bharo (Daruhi), Tehsil & Distt. Hamirpur, HP

53

Dr. sanjay Gautam S/o. Sh. Dhian Singh Gautam,
Vill. Pandher, P/o. Thathwani, Tehsil & Distt.
Hamirpur, HP
Dr. Sanjay Kumar S/o. Sh. Ranjeet Singh Thakur,
Ward No. 02 Near P/o. Baba Swaroop Gir, VPO. &
Tehsil Sujanpur, Distt. Hamirpur, HP, 176110

54

55

56

57

Dr. Sanjeev Sharma S/o. Sh. Milkhi Ram, Vill.
Barara, P/o. Dughli, Tehsil Bhoranj, Distt. Hamirpur,
HP
Dr. Shalini Sharma W/o. Vivek Kumar, VPO. Partap
Nagar Amb (Ward No.07), Tehsil Amb, Distt. Una,
HP, 177203
Dr. Shalu Devi W/o. Sh. Ajay Katoch, Ganesh Bazar
Baijnath, Tehsil Baijnath, Distt. Kangra, HP

58

Dr. Shweta Thakur W/o. Yajuvinder Singh Rana,
VPO. Rajpura, Tehsil & Distt. Chamba, HP, 176310

59

Dr. Sumedha W/o. Sh. Ish Uppal, Plot # 33 Industrial
Area Mehatpur, Tehsil & Distt. Una, HP, 174315

18-08-22

<!-- page 6 -->

60

61

Dr. Sunder Kumar S/o. Sh. Gopal Chand, Vill.
Bhawai, P/o. Swahan, Tehsil Sh. Naina Devi Ji,
Distt. Bilaspur, HP
Dr. Varun Garg S/o. Sh. Suresh Kumar Garg, Vill.
Ram Nagar, P/o. Sohari, Tehsil Bangana, Distt. Una,
HP, 177039

62

Dr.Purnima Mahajan W/o. Sh. Gaurav Gupta, C/o
Sh. Sanjeev Mahajan Electoral Officer Room No.
105 Armsdale, HP Sectariat Shimla-2

63

Dr. Aditya S/o. Sh. Suresh Kumar, House No. 115,
Ward No. 4, Shiv Nagar M.C. Area, Tehsil & Distt.
Hamirpur, HP, 177001

64

Dr. Alpana Sharma W/o. Sh. Naveesh Dogra, D/o.
Sh. Brahm Chand, Vill. Piadkar, P/o. Masiana, Tehsil
& Distt. Hamirpur, HP, 177001

65

Dr. Amit Sachdeva S/o. Sh. Pran Nath Sharma, W# 9
Mehta Colony Near Old Bus Stand Una, Tehsil &
Distt. Una, HP, 174303

66

Dr. Amit Sharma S/o. Sh. Suresh Sharma, Vill.
Deothi, P/o. Bahadpur, Tehsil Indora, Distt. Kangra,
HP, 176058

67

Dr. Amita Kumari D/o. Sh. Jagan Nath Sharma.
VPO. Karohta, Tehsil Bhoranj, Distt. Hamirpur, HP
Dr. Anchuk Sharma S/o. Sh. Parveen Sharma, Moh.
Jansali, Tehsil & Distt. Chamba, HP

68
69

Dr. Anjali Jamwal W/o Sh. Anand Guleria, V.P.O.
Drang, Teh. Palampur, Distt Kangra, H.P 176060

70

Dr. Anjali Sapra D/o. Sh. Subhash Sapra, M/S
Beauty Corner Chotta Chowk, Nahan, HP, 173001

71

Dr. Anjana Kumari D/o. Sh. Puran Chand Prasher,
VPO. Rakhoh, Tehsil Sarkaghat, Distt. Mandi, HP,
175042
Dr. Anu Radha Chaudhary W/o. Sh. Susheel Kumar,
Mohalla Bangotu, Tehsil & Distt. Chamba, HP,
176310

72

73

Dr. Anu Sharma D/o. Sh. Sita Ram Sharma, Vill.
Darin, P/o. Dabla, Tehsil Ghumarwin, Distt.
Bilaspur, HP,

<!-- page 7 -->

74

Dr. Anuj Kaushal S/o. Shyam Lal Kaushal, Vill.
Mamooh, P.o. Gurchal, Tehsil Nurpur, Distt. Kangra,
HP, 176202

75

Dr. Anuradha Guleria D/o. Sh. Dalip Singh Guleria,
House No. 3, Ward No. 10, Behind Bus Stand,
Hamirpur, HP

76

Dr. Anuradha Singh Thakur W/o. Sh. Praveen
Kumar, Pine Grove School Kothar Road-Subathu,
Solan, HP, 173206
Dr. Archana Patial W/o. Sh. Anuj Guleria, VPO.
Karyara, Tehsil Dehra, Distt. Kangra, HP, 177117

77

78

Dr. Arun Kumar Bhardwaj S/o. Sh. Kewal Ram, Vill.
Gastari, P/o. Pauria, Tehsil Nerwa, Distt. Shimla, HP

79

Dr. Arun Mehla S/o. Sh. Lekh Ram Mehla, Vill.
Bhagetu, P/o. Mair, Tehsil & Distt. Hamirpur, HP

80

Dr. Ashima Jai Rath W/o. Sh. Sanjeev Kumar, Vill.
Lower Arniala, P/o. Kotla Kalan, Tehsil & Distt.
Una, HP, 174303
Dr. Ashish S/o. Sh. Bhagmal, Vill. Thungali, P/o.
Bharanu, Tehsil Nerwa, Distt. Shimla, HP

81
82

83
84

85

Dr. Ashu Guleria W/o Sh. Mohit Parmar, C/o.
Kushal Singh Parmar, Vill. Ghuggar, Krantichowk,
Tehsil Palampur, Kangra, HP, 176061
Dr. Ashutosh S/o. Sh. R.S. Katoch, VPO. & Tehsil
Indora, Distt. Kangra, HP, 176401
Dr. Astha Puri W/o. Kunal Chadha, H.No. 4,
Aadarsh Colony Balaji Vihar Birta Kangra, HP,
176001
Dr. Avinash Sharma S/o. Sh. Puran Chand Sharma,
T-12/21, Pau Campus Punjab Agricultural University
Feroz Pur Road, Ludhiana (PB)

86

Dr. Bharti Vaid W/o. Sh. Neeraj Joshi, Mohalla
Bangotu, Near Sita Ram Mandir, Tehsil & Distt.
Chamba, HP, 176310

87

Dr. Bhavna Kumari W/o. Sh. Sanjeev Kumar, VPO.
Dungrin, Tehsil Bhoranj, Distt. Hamirpur, HP

88

Dr. Deepti Bedwa D/o. Sh. KL Bias, Vill & P.O.
Saliana, Teh. Palampur, Distt. Kangra, H.P 176103

<!-- page 8 -->

89

90
91

92

93

94
95

96

97

98
99

Dr. Gunjan Naresh Sood, S/o. Sh. Naresh Kumar
Sood, H.No.190, Ward No. 11 Gandhi Nagar, Kullu,
HP, 175101
Dr. Hareshwar Chauhan S/o. Sh. D.S. Chauhan, Vill.
Gharshal, P/o. Devidhar, Distt. Shimla HP, 171214
Dr. Harsh Gupta S/o. Sh. S.M. Gupta, H.No. 79/4,
VPO. Bhojpur, Tehsil Sunder Nagar, Distt. Mandi,
HP, 175002
Dr. Kapil Kant S/o. Sh. Om Prakash, Vill. Jhatwar,
P/o. Dughli, Tehsil & Distt. Hamirpur, HP
Dr. Kapil Sharma S/o Sh. Kapoor Dev Sharma C/o
Neelkanth Palace Ward No.5 (Khopri) Near Bushahr
Regency Hotel Rampur Bsr. Distt Shimla, HP
172001
Dr. Karam Singh S/o. Sh. Paras Ram, Vill. Pathyed,
P/o. Piplughat, Tehsil Arki, Distt. Solan, HP, 173235
Dr. Kuldip Kumar S/o. Sh. Anant Ram, VPO. Toba
Sangwana, Tehsil Naina Devi Ji, Distt. Bilaspur, HP,
174002
Dr. Mahesh Sharma S/o. Sh. Mahant Ram Sharma,
V.P.O. Harlog, Tehsil Ghumarwin, Distt. Bilaspur,
HP, 174003
Dr. Mamta Chauhan W/o. Sh. Vivek Kumar, VPO.
Lanjhta, Tehsil Ghumarwin, Distt. Bilaspur, HP,
174027
Dr. Mamta Kumari W/o. Rakesh Thakur, Village
Jathari, P/o. Jhaniari, Tehsil & Distt. Hamirpur, HP
Dr. Manju Rani W/o. Sh. Arvind Kumar, VPO.
Patlander, Tehsil Sujanpur, Distt. Hamirpur, HP,
176111

100 Dr. Manjula Gupta W/o. Sh. Vineet Gupta, Below
Geeta Adarsh School W No. -7 Gupta Niwas adarsh
Nagar Solan, HP, 173212
101 Dr. Manoj Kumar S/o. Sh. Ramesh Kumar, VPO.
Mahadev, Tehsil Sunder Nagar, Distt. Mandi, HP,
175018
102 Dr. Maruti Anand S/o. Sh. Pawan Kumar Sharma,
VPO. Kotla Kalan, Tehsil & Distt. Una, HP, 174303
103 Dr. Meenakshi D/o. Sh. R.C. Sharma, P/o. Daruhi,
Gopal Nagar, Tehsil & Distt. Hamirpur, HP

<!-- page 9 -->

104 Dr. Meenakshi Sharma D/o. Sh. Duli Chand Sharma
W/o Sh. Rakesh Sharma, Vill Sohal, P/o. Dhami,
Tehsil & Distt. Shimla, 171103
105 Dr. Meenakshi Sharma W/o. Sh. Ashish Sharma, Flat
No. 2, Atlantis Parimahal, Kasumpti Shimla, HP,
171009
106 Dr. Monika Sharma W/o Sh. Nishant Sharma, Vill.
Jhalred, P.O. Banuri, Teh. Palampur, Distt Kangra,
H.P 176061
107 Dr. Monika Thakur W/o. Sh. Manjeet Singh, Flat No.
302 Type-4, Block-D Housing Complex,
SLBSGMCH Nerchowk Mandi, HP, 175021
108 Dr. Monika W/o Sh. Munish Rawat, VPO. Dhirwin,
Tehsil Bhoranj, Distt. Hamirpur, HP
109 Dr. Navdeep Kaur W/o. Sh. Prabhjot Singh, Mayer
Cottage, Near BCS, Vijay Nagar Shimla, HP, 171009
110 Dr. Neeraj Gupta S/o. Sh. Kuldeep Gupta, Moh.
Bangotu, Tehsil & Distt. Chamba, HP, 176310
111 Dr. Neha Sharma D/o. Sh. R.P. Sharma, VPO.
Rehan, Tehsil Nurpur, Distt. Kangra, HP, 176022
112 Dr. Nisha salaria W/o. Sh. Dr. Vikrant Kanwar
AIMS, Bilaspur, HP, 174001
113 Dr. Nishant Sood S/o. Sh. O.P Sood Ward No. 08
Brahmpuri Mohalla, VPO. & Tehsil Sujanpur, Distt.
Hamirpur, HP, 176110
114 Dr. Nitan Raj Handa S/o. Sh. Budhi Prakash Handa,
Moh. Chowgan Lahore Galli, Tehsil & Distt.
Chamba, HP, 176310
115 Dr. Om Prakash Sharma S/o. Late Sh. H.C. Sharma,
Prakash Lodge, Near Hari Niwas, Lower Kaithu,
Shimla, HP, 171003
116 Dr. Pankaj W/o. Sh. Sushil Kumar, Vill. Tikkari,
P/o. Rakhoh, Tehsil Sarkaghat, Distt. Mandi, HP,
175042
117 Dr. Pooja W/o. Sh. Shashikant Guleria, C/o
A.D.Hydro Power LTD, VPO. Prini, Tehsil Manali,
Kullu, HP, 175143
118 Dr. Poonam Kumari W/o. Sh. Vikas Kalia, VPO.
Thathwani, Tehsil Bhoranj, Distt. Hamirpur, HP

20-08-22

<!-- page 10 -->

119 Dr. Poonam Rana W/o. Sh. Ashish Chaudhary, Vill.
Badah, P/o. Mohal, House No. 119/1 Kullu, HP,
175126
120 Dr. Priyanka Guleria W/o. Sh. Digvijay Singh, Ward
No. 1, Vill. Kot, Tehsil Naduan, Distt. Hamirpur, HP,
177033
121 Dr. Rajeev Kumar S/o. Sh. Vipan Chand, VPO. &
Tehsil Pragpur, Distt. Kangra, HP, 177107
122 Dr. Rajeev Nayyar S/o. Sh. Gian Chand Nayyar,
House No. 83, Ward No. 5, Block 3, Jansali, Tehsil
& Distt. Chamba, HP, 176310
123 Dr. Rajiv Verma S/o. Sh. D.N. Verma, Kala Bhawan,
Near HP Marketing Board Khalini, Shimla, HP,
171002
124 Dr. Ramesh Kaundal S/o. Sh. Hans Raj, Flat No. 20
FF, First Floor Mig flats SSST Nagar, Patiala, PB,
147001
125 Dr. Ramit Mahajan, S/o. Sh. Ramesh Kumar, Vill.
Bashing, Banogi, 26/13, P/o. Babeli, Kullu, HP
126 Dr. Ravinder Singh S/o. Sh. Yog Singh, Vill. Bagori,
P/o. Kiani, Tehsil & Distt. Chamba, HP, 176310
127 Dr. Ritika Katoch D/o. Sh. Baldev Katoch, Khera
Road Bhawarna, Tehsil Palampur, Distt. Kangra, HP,
176083
128 Dr. Ritu Ohri D/o. Avinash Chander, Ward No.5,
Pulwala Bazar, Mohalla Ohri , Una, HP, 174303
129 Dr. Rupesh Kumar S/o. Sh. Bhupal Singh, VPO.
Gadheri, Tehsil Sunni, Distt. Shimla, HP, 171019
130 Dr. Samriti Vaidya D/o. Sh. Girish Vaidya, H.No.
287/11 Tarna Hills Mandi, HP, 175001
131 Dr. Sandeep Kaur W/o. Sh. Pradeep Kaur VPO.
Rajera, Tehsil & Distt. Chamba, HP, 176310
132 Dr. Sandeep Kumar S/o. Sh. Prem Nath Lakherwal,
VPO. Utpur, Tehsil Tauni Devi, Distt. Hamirpur, HP
133 Dr. Sandeep Vaid S/o. Late Sh. Shalig Ram Vaid,
Mohalla Surara, Near Govt Boys School, Chamba
Town, HP, 176310
134 Dr. Sanjay Gautam S/o. Sh. Dhian Singh Gautam,
Vill. Pandher, P/o. Thathwani, Tehsil & Distt.
Hamirpur, HP, 177501

<!-- page 11 -->

135 Dr. Sanjay Kumar S/o. Late Sh. Ranjeet Singh, Ward
No. 3, House No. 200 Sujanpur, Tehsil Sujanpur,
Distt. Hamirpur, HP, 176110
136 Dr. Sanjeev Kumar Gupta S/o. Sh. Shyam Lal Gupta,
Main Bazar Sarkaghat, Distt. Mandi, HP, 175024
137 Dr. Sanjeev Sharma S/o. Sh. Milkhi Ram Sharma,
Sanjeevan Clinic, VPO. Lambloo, Distt. Hamirpur,
HP, 177029
138 Dr. Saurav Tandon S/o Sh. Arun Kumar Tandon
Onkar Niwas, Diffarpat Palampur Distt. Kangra, HP,
176061
139 Dr. Sayed Israr Ali Shah S/o. Sh. Dildar Ali Shah,
Moh. Kashmiri, P/o. Chamba, Tehsil & Distt.
Chamba, HP, 176310
140 Dr. Shalu Devi W/o. Sh. Ajay Katoch, Ganesh Bazar,
Baijnath, P/o. & Tehsil Baijnath, Distt. Kangra, HP,
176125
141 Dr. Shaveta Sharma D/o. Sh. RP Sharma, Near
Employment Exchange Hotel Tea Bud Palampur,
Teh.Palampur, Distt Kangra, H.P 176061
142 Dr. Shaweta Sharda W/o. Sh. Sumit Kumar Sharma,
H# 84 W# 4 VPO Basdehra, Tehsil & Distt. Una,
HP, 174315
143 Dr. Shelly Sharma D/o. Sh. Sham Saroop, Vill.
Barota, Po. Thakurdwara, Tehsil Indora, Distt.
Kangra, HP, 176403
144 Dr. shivani Thakur D/o. Sh. Ranjeet Singh, Vill.
Pandwin, P/o. Mair, Tehsil & Distt. Hamirpur, HP
145 Dr. Shuchi Sharma W/o. Sh. Ramneek Sahore, VPO.
Raipur Sahoran Tehsil & Distt. Una, HP, 174315
146 Dr. Shweta Kanwar W/o. Sh. Bhuwan Singh Banyal,
VPO. Jhabola, Tehsil Jhandutta, Distt. Bilaspur, HP,
174030
147 Dr. Shweta Thakur W/o. Sh. Yajuvinder Singh Rana,
Vill. & P/o. Rajpura, Tehsil & Distt. Chamba, HP,
176318
148 Dr. Smita Kumari W/o. Sh. Parveen Kumar, A1-603
Jal Vayu Vihar Opp. HMV College Workshop
chowk, Jalandhar, PB, 144008

<!-- page 12 -->

149 Dr. Smt. Lata Thakur W/o. Sh. Rahul, Vill. Kiari,
P.o. & Tehsil Shahpur, Distt. Kangra, HP, 176206
150 Dr. Surender Kumar S/o. Sh. Gopal Chand, Vill.
Bhuwai, P.o. Swahan, Tehsil Naina Devi, Distt.
Bilaspur, HP, 174310
151 Dr. Tanu Sawal D/o. Sh. B.N. sawal Jutogh Cantt.
Shimla-8
152 Dr. Tungeshwar Kumar S/o. Sh. Paras Ram, Vill.
Kothi, P/o. Shalaghat, Tehsil Arki, Distt. Solan, HP,
153 Dr. Upasana Chib W/o. Sh. Dr. Yash Pal Chandel
Vill. Chhoti Billour, Tehsil Jhandutta, Distt.
Bilaspur, HP, 174031
154 Dr. Vijay Lakshmi Jaswal D/o. Sh. Kuldeep Singh
Jaswal, VPO. Thathwani, Tehsil & Distt. Hamirpur,
HP
155 Dr. Vikas Nard S/o. Sh. Brijmohan Nard, Vill. Hara,
P/o. & Tehsil Fatehpur, Distt. Kangra, HP, 176053
156 Dr. Vikas Verma S/o. Sh. Jagdish Chand, Vill.
Lagyar, P/o. Tihra, Tehsil Dharampur, Distt. Mandi,
HP, 175026
157 Dr. Vinay Kumar S/o. Sh. Ajit Kumar, VPO. Majhog
Sultani, Tehsil & Distt. Hamirpur, HP
158 Dr. Vishal Sharma S/o. Sh. Suresh Kumar Sharma,
House No. LIG-12, Housing Board Colony, Tehsil &
Distt. Hamirpur, HP
159 Dr. Yogesh Kumar Mahajan S/o. Sh. Hem Raj
Hamirpur Road Ghumarwin ward No. 2, P/o. &
Tehsil Ghunarwin, Distt. Bilaspur, HP, 174021

SC Category
1

Dr. Suman Lata W/o. Sh. Amit Kumar, Rz-124, Ground
Floor Vaishali, Dabri Palam Road Near Jindal Public
School, New Delhi, 110045

2

Dr. Lokinder S/o. Sh. Dulchi Ram, Vill. & P/o. Halau,
Tehsil Nerwa, HP, 171210

3

Dr. Manorma W/o. Sh. K.K. Kashyap MIG II, H.No. 271
Housing Board Colony Rakkar, P/o. Jalgran Tabba, Tehsil
& Distt. Una, HP, 174306

Date fixed for documents
scrutiny/ Verification

22-08-22

<!-- page 13 -->

4

Dr. Rajiv Kumar S/o. Late Sh. Vipan Chand, Vill. Garh,
P/o. Pragpur, Tehsil Pragpur, Distt. Kangra, HP, 177107

5

Dr. Rakesh Kumar S/o. Sh. Dharam Pal, Vill. Fadanu,
P/o. Khalardu, Tehsil Sarkaghat, Distt. Mandi, HP,
175024
Dr. Raveesh Malhotra S/o. Sh. Kuldeep Malhotra, VPO.
& Tehsil Jawali, Distt. Kangra, HP, 176023

6
7

8

9

Dr. Sarita Kumari W/o. Sh. Sushil Pundir, Vill. Mohin,
P/o. GopalPur, Tehsil Sarkaghat, Distt. Mandi, HP,
175007
Dr. Saurabh Vashisth S/o. Sh. R.C. Vashishath, Vill. &
P/o. Manoh Sihal, Tehsil Fatehpur, Distt. Kangra, HP,
176053
Dr. Shivani, d/o Sh.Lekh Raj, Vill.and PO Daroh, Tehsil
Palampur, Distt.Kangra, HP 176092

10

Dr. Vishal Kothari S/o. Sh. Desh Deepak, House No.124,
Ward No.-4, Opposite New Bus Stand Nagrota Bagwan,
Tehsil Nagrota Bagwan, Distt. Kangra, HP, 176047

11

Dr. Anamika W/o. Sh. Dhirender Kumar, H. No.91,
W.No. 2, Ram Nagar, P/o. & Tehsil Sarkaghat, Distt.
Mandi, HP, 175024

12

Dr. Anil Kumar S/o. Sh. Daleep Singh, Vill. Thana, P/o.
Buffrian, Tehsil & Distt. Hamirpur, HP

13

Dr. Anju Pundir W/o Sh. Amit Pundir, #245/12 Chakreda
Nahan, Teh. Nahan, Distt. Sirmour, H.P 173001

14

Dr. Arti Bhardwaj D/o. Sh. Balbir Bhardwaj, Vill.
Dabrog, P/o. & Tehsil Sarkaghat, Distt. Mandi, HP,
175024
Dr. Hemant Kumar S/o. Sh. Madan Lal, VPO. Nankhari,
Distt. Shimla, HP, 172021

15
16

Dr. Honey W/o. Sh. Bharat Bhushan, VPO. Bhadsali,
Tehsil Haroli, Distt. Una, HP

17

Dr. Indu Kumari W/o. Sh. Manoj Kumar, Vill. Majhera,
P/o. Kachera, Tehsil Jaisinghpur, Distt. Kangra, HP,
176076

18

Dr. Jeet Bhatia W/o. Sh. Nipun Vardhan, H.No. 69 Diara
Sec. No. 1, Bilaspur Sadar, HP, 174001

19

Dr. Jheel Bhatia W/o. Sh. Nipun Vardhan, Cherry County,
Flat No. 905, A-4 Tower Tech. Zone-IV, GH-05B G.
Noida (W) UP. 201306

20

Dr. Joginder Singh, S/o. Sh. Kartar Singh, Vill. Doh, P/o.
Badhani, Tehsil Bhoranj, Distt. Hamirpur, HP, 176601

<!-- page 14 -->

21

Dr. Jyoti Bhardwaj D/o. Sh. Balbir Bhardwaj, W.No. 7
Dabrog (Maruti Sazuki Compitent), Sarkaghat, Distt.
Mandi, HP, 175024

22

Dr. Kumari shilpa D/o. Sh. BR Chauhan, Vill. Dabrog,
P/o. & Tehsil Sarkaghat, Distt. Mandi, HP, 175024

23

Dr. Manju Bala W/o. Sh. Sanjeev, Vill. Nehrian, Tehsil
Amb, Distt. Una, HP, 177210

24

Dr. Manorma D/o. Sh. K.L. Kashyap, MIG II, H.No.271,
Housing Board Colony Rakkar Una, HP, 174303

25

Dr. Narender Kumar S/o. Sh. Dhani Ram, Vill. Daroh,
P/o. Chamiari, Tehsil Bangana, Distt. Una, HP, 174308

26

Dr. Neeraj Kumar S/o. Sh. Suman Kumar, VPO. Charri,
Tehsil Shahpur, Distt. Kangra, HP, 176217

27

Dr. Neha Jambla D/o. Sh. Hardev Singh, H# 208 W# 1
Prem Nagar Near ISBT Una, Tehsil & Distt Una, HP,
174303

28

Dr. Prashant Sood S/o. Sh. Pirthi Chand Sood, Vill.
Bhadsali (Har), P/o. Bhadsali, Sub Tehsil Ispur, Distt.
Una, HP, 174317

29

Dr. Saurabh Vashishath S/o. Sh. R.C. Vashishath, Vill.
Lubh, P/o. Makhran, Tehsil Jawali, Distt. Kangra, HP,
176023

30

Dr. Shashi Kant S/o. Sh. Kuldeep Chand, Vill. Soutta P/o.
Nagrota Gazian, Tehsil Bhoranj, Distt. Hamirpur, HP

31

Dr. Amit Dhiman S/o. Sh. Kishan Chand, Vill. BhallBhattan, P/o. Jhiralari, Tehsil Barsar, Distt. Hamirpur, HP

32

Dr. Amit Dhiman s/o. Sh. Suresh Dhiman, H. No. / HIG131, Housing Board colony, Hamirpur, HP

33

Dr. Anamika W/o. Sh. Dhirender Kumar, H.No. 91 Ward
No.2 Ram Nagar, P/o. & Tehsil sarkaghat, Distt. Mandi,
HP, 175024

34

Dr. Anil Kumar S/o. Sh. Daleep Singh, Vill. Thana, P/o.
Buffrin, Tehsil & Distt. Hamirpur, HP, 177029

35

Dr. Anju Pundir W/o. Sh. Amit Pundir, # 245/12,
Chakreda Nahan, Sirmour, HP, 173001

36

Dr. Deepti W/o. Manoj Kumar, VPO. Amb, Tehsil Amb,
Distt. Una, HP, 177203

37

Dr. Dinesh Kumar S/o. Sh. Bhagi Rath, Vill. Bir Jol
(Palahi), P/o. Bir Bagehra, Tehsil Sujanpur, Distt.
Hamirpur, HP, 176110

<!-- page 15 -->

38

39

Dr. Domnik Sandhu W/o. Sh. Sunil Kumar, C/o
Gurbachan Singh VPO. Oel, Tehsil Ghanari, Distt, Una,
HP, 177206
Dr. Esha Kaushal D/o. Sh. Sunka Ram Kaushal, Vill.
Kardho, P/o. Paniali, Tehsil Nadaun, Distt. Hamirpur, HP

40

Dr. Hemant Kumar S/o. Sh. Madan Lal Kashyap, Hm-59,
Sec-59, Phase IV, Mohali, S.A.S. Nagar, PB, 160059

41

Dr. Indu Kumari W/o. Sh. Manoj Kumar, State Bank
Institute Of Learning And Development Sector-14
Panchkula, Near Police Station, Haryana, 134109

42

Dr. Jyoti Bhardwaj D/o. Sh. Balbir Bhardwaj, W.No. 7
Dabrog (Maruti Sazuki Compitent), Sarkaghat, Distt.
Mandi, HP, 175024

43

Dr. Kumari Shilpa D/o. Sh. B.R. Chauhan, Metro Town
Society, 52 B Second Floor, Opp. Royal Mansion
Peermuchalla Zirakpur, PB, 140603

44

Dr. Manisha Dhiman D/o. Sh. Prakash Chand Dhiman,
Vill. Dulehra, P/o. , Tehsil & Distt. Hamirpur, HP

45

Dr. Manju Bala W/o. Sh. Sanjeev Kumar, VPO. Nehrian,
Tehsil Amb, Distt. Una, HP, 177210

46

Dr. Meera Devi W/o. Sh. Sunil Kumar, Vill. Rasher, P/o.
Maseran, Tehsil Sarkaghat, Distt. Mandi, HP, 175024

47

Dr. Narender Kumar S/o. Sh. Dhani Ram, Vill. Daroh,
P/o. Chamiari, Tehsil Bangana, Distt. Una, HP,

48

Dr. Neeraj Kumar S/o. Sh. Suman Kumar, H.No. A1-705,
Jal Vayu Vihar, Workshop Chowk Jalandhar, 144008

49

Dr. Neetika Kundailia D/o. Sh. Karnail Singh Lower
Barol, Po. Dari, Tehsil Dharamshala, Distt. Kangra, HP,
176057
Dr. Panjak Bhardwaj S/o. Sh. Nanak Chand Bhardwaj,
VPO. Nabahi, Tehsil Sarkagaht, Distt. Mandi, HP,
175024
Dr. Priyanka D/o. Sh. Karnail Singh Kundalia, Ward No.
13 Lower Barol Near Income Tax office, Tehsil
Dharamshala, Distt. Kangra, HP, 176057

50

51

52

Dr. Rajneesh , S/o Sh.Tulsi Ram, VPO Gugga Saloh,
Tehsil Palampur, Distt.Kangra, HP 176102

53

Dr. Raveesh Malhotra S/o. Sh. Dr. Kuldeep Malhotra,
V.P.O. Tehsil Jawali, Distt. Kangra, HP, 176023

54

Dr. Ritika Kharyal W/o. Sh. Vinod Kaushal, House No.
88A, Ward No. 04, Shiv Nagar, Hamirpur, HP

<!-- page 16 -->

55

Dr. Sarita Kumari D/o. Sh. Girdhari Lal Bhardwaj, Delta
Diagnostic Centre, H.No.5 Opp. Civil Hospital, Sunder
Nagar Distt Mandi, HP, 175018

56

Dr. Satinder Kumar S/o. Sh. Bidhi Singh, Vill. Bagwar,
P/o. Dhamrol, Tehsil Bhoranj, Distt. Hamirpur, HP

57

Dr. Shivani W/o. Dr. Raj Kumar, Vill. Ganesh Bazar, P/o.
& Tehsil Baijnath, Distt. Kangra, HP, 176125

58

Dr. Sita Devi D/o. Krishan Lal Ranta, Vill. Jarla, P/o.
Kadiwan, Tehsil Rohru, Distt. Shimla, HP, 171203

WFF General
1

Dr. Meenakshi D/o. Sh. Hem Raj W/No. 7, VPO. Nadaun,
Tehsil Nadaun, Distt. Hamirpur, HP, 177033

2

Dr. Atul Thakur S/o. Sh. Krishan Kumar Thakur, HIG-11,
Housing Board Colony, Near BSNL Exchange, Bhiuli,
Tehsil Sadar, Mandi, HP, 175001

3

Dr. Meenakshi W/o. Sh. Hem Raj, Ward No. 07, Vill.
Nadaun, P/o. Nadaun, Tehsil Nadaun, Distt. Hamirpur,
HP, 177033

4

Dr. Rajeshwar Singh Thakur S/o. Sh. Bhup Singh Thakur,
House No. 72, Ward No. 8, Naya Nagar, Tehsil & Distt.
Hamirpur, HP

WFF SC
1

Dr. Ritika D/o. Sh. Vijay Kumar, H.No.-683, Ward No. 1,
Krishna Nagar, Near Kendriya Vidya Laya Hamirpur, HP,
177001

ST Category
1

Dr. Sapna Kapoor D/o. Sh. Rattan Singh, Wno. 02, VPO.
Deol (Khas), Tehsil Baijnath, Distt. Kangra, HP, 176125

2

Dr. Virender S/o. Sh. Soni Ram, VPO. Karpat, Tehsil
Udaipur, Distt. L&S, HP, 175142

Date fixed for documents
scrutiny/ Verification

23-08-22

Date fixed for documents
scrutiny/ Verification

23-08-22
Date fixed for documents
scrutiny/ Verification

23-08-22

<!-- page 17 -->

3

Dr. Sapna Kapoor W/o. Sh. WG CDR (Dr) Shiv Kumar,
Dept of Pathology, Command Hospital (WC),
Chandimandir Cantt., Panchkula Haryana, 134107

4

Dr. Ram Singh S/o. Sh. Duni Chand, Vill. Takwas, P.o.
Killar4, Tehsil. Pangi, Distt. Chamba, HP, 176323

5

Dr. Ashish Thakur, s/o Sh.P.L. Thakur, Vill. Kuffa, PO
Killar, Tehsil Pangi, Distt. Chamba,HP -176323

6

Dr. Kunari Ranju Bala D/o. Sh. Jamuna Dass, VPO.
Ribba, Tehsil Moorang, Distt. Kinnaur, HP

7

Dr. Aarti D/o. Sh. Prem Chand, Vill. Rangway, P/o. Lote,
Tehsil, Lahaul, Distt. (L&S), HP, 175133

8

Dr. Asha Bharti W/o. Sh. Dalip Singh, VPO. Pangi,
Tehsil Kalpa, Distt. Kinnaur, HP, 172107

9

Dr. Ashish Thakur S/o. Sh. P.L. Thakur, Civil Hospital
Bagsaid, P/o. Bagsaid, Tehsil Thunag, Distt. Mandi, HP,
175035

10

Dr. Kamal Kishor S/o. Sh. Nirmal Kumar, Vill. Padhru,
P/o Baggi, Tehsil Balh, Distt. Mandi, HP, 175027

11

Dr. Manisha Kumari D/o. Sh. Prem Lal Sharma, Vill.
Chhogjing, P/o. Thirot, Tehsil Udaipur, HP, 175139

12

Dr. Ram Kumar, s/o Sh. Thakur Chand VPO Dharwas,
Tehsil Pangi, Distt. Chamba HP -176323

13

Dr. Ram Singh S/o. Sh. Duni Chand, C/o Bhagi Rath Tea
Stall Summer Hill, Shimla, HPU,

14

Dr. Sanjay Kumar Nehria S/o. Late Sh. Gian Chand
Nehria, Vill. Suwala, P/o. Naganpatt, Tehsil Dharamshala,
Distt. Kangra, HP, 176209

15

Dr. Seema Thakur D/o. Sh. Jaram Singh, Mohala
Sultanpur, Tehsil Chamba, Distt. Chamba, HP, 176314

16

Dr. Virender S/o. Sh. Soni Ram, C/o Dr. Rajinder Rana,
Near old Tehsil, Vill. Bassi, P/o. Bhoranj , 176045

17

Dr. Dalip Singh S/o. Sh. Gopal Singh, VPO. Pangi, Tehsil
Kalpa, Distt. Kinnaur, HP, 172107

18

Dr. Priya Khatana W/o Sh. Hakim Singh Khatana, V.P.O.
Barotiwala, Teh. Baddi, Distt. Solan, H.P 174103

<!-- page 18 -->

19

Dr. Ranju Bala D/o. Sh. Jamuna Dass, House No. 211,
First Floor, Sector 15 Huda Near Hotal sapphire, Jagadhri,
Yamuna Nagar, Haryana, 135003

20

Dr. Ritika Verma D/o. Nanak Chand, Vill. Ambeta, P/o.
Baroti, Tehsil Barsar, Distt. Hamirpur, HP

21

Dr. Rupali Thakur W/o Sh. Sanjay Kumar Nehria, Vill.
Suwala, P/o. Naganpatt, Tehsil Dharamshala, Distt.
Kangra, 176209

22

Dr. Seema Kumari D/o. Sh. Som Parkash, Vill. Patti,
Tehsil Bharmaur, Distt. Chamba, HP, 176315

23

Dr. Tandup Angial S/o. Sh. Chawang Dorje, LBS Mahilla
Ayur. Medical College Bilaspur Haryana, Yumunanagar,
135102

24

Dr. Yatindra Kumari W/o. Sh. Husan Chand, Vill.
Malpur, P/o. Bhud, Tehsil Baddi, Distt. Solan, HP,
173205

OBC Category
1

Dr. Sunny Salehia S/o. Sh. Janak Raj Salehia, VPO.
Haripur, Tehsil Dehra, Distt. Kangra, HP, 176028

2

Dr. Abhey Bhandari S/o. Sh. Hem Raj Bhandari, Ward
No. 9 Nalagarh, Distt. Solan, HP, 174101

3

Dr. Kuldeep Kumar S/o. Sh. Parkash Chand, VPO.
Amboa, Tehsil Ghanari, Distt. Una, HP, 177204

4

Dr. Shiv Kumar S/o. Sh. Laj Pat Rai, Vill. Arniala, P/o.
Kotla, Tehsil Bangana, Distt. Una, HP, 174303

5

Dr. Priyanka W/o. Sh. Navinder Singh, Vill. Gabli Dari,
P.o. Dari, Tehsil Dharamshala, Distt. Kangra, HP

6

Dr. Sanjeev Kumar S/o. Sh. Nikka Ram, VPO. Bharmar,
Tehsil Jawali, Distt. Kangra, HP, 176021

7

Dr. Tamanna Dhatwalia W/o. Sh. Ravi Verma, Vill.
Rajhole, P/o. Tal (Amned), Tehsil & Distt. Hamirpur, HP

8

Dr. Varinder Kumar Dhiman Sh. Shiv Kumar, VPO.
Sanoli, Tehsil & Distt. Una, HP, 174301

9

Dr. Anubha Chandla W/o. Sh. Atul Thakur, VPO. Tihra
(Dhuli), Tehsil Dharampur, Distt. Mandi, HP, 175026

Date fixed for documents
scrutiny/ Verification

24-08-22

<!-- page 19 -->

10

Dr. Anupama Verma W/o. Sh. Anil Kumar, Vill. Thana
Loharan, P/o. Baffrian, Tehsil & Distt. Hamirpur, HP

11

Dr. Anuradha D/o. Sh. Balwant Singh, VPO. Matlahar,
Tehsil Jawali, Distt. Kangra, HP, 176023

12

Dr. Benay Kumar S/o. Sh. Jagdish Ram, Vill. Roda, P/o.
Sainsowal, Tehsil Haroli, Distt. Una, HP

13

Dr. Bindu Choudhary D/o. Sh. B.L. Choudhary Simla RD
Near Passu Bus Stand, VPO. Dhagwar khas (408), Tehsil
Dharamshala, Distt. Kangra, HP, 176001

14

Dr. Gurmel Singh S/o. Sh. Chamel Singh, Vill. Jamuli,
P/o. Gagruhi, Tehsil Jawalamukhi, Distt. Kangra, HP,
176036
Dr. Jagwinder Kaur W/o. Sh. Gurdeep Singh Vill.
Bhaloon, P/o. Kharota, Tehsil Jawali, Distt. Kangra, HP,
176023
Dr. Navjot D/o. Sh. Devinder Singh, VPO. Raisary, Tehsil
& Distt. Una, HP, 174303

15

16
17

Dr. Vishal Choudhary D/o. Harbans Lal, Vill. Tihal, P/o.
Dhasoli, Tehsil Jawali, Distt. Kangra, HP, 176021

18

Dr. Amrit Versha Rai S/o. Sh. Suresh Chand, Vill.
Bharari, P/o. Lehri Sarail, Tehsil Ghumarwin, Distt.
Bilaspur, HP, 174027

19

Dr. Anshul Davku S/o. Sh. Sahib Singh Davku, Vill.
Rasuh, P/o. Ranital, Tehsil & Distt. Kangra, HP, 176029

20

Dr. Gursimran Kour D/o. Sh. Mann Singh, VPO. Katholi,
Tehsil Jawali, Distt. Kangra, HP, 176027

21

Dr. Jaswinder Kashyap S/o. Jaswant Singh, VPO.
Kuneran, Tehsil Ghanari, Distt Una, HP, 177219

22

Dr. Lalit Mohan Mehra S/o. Sh. Jagan Nath Mehra, VPO.
Dada Siba, Tehsil Dada Siba, Distt. Kangra, HP, 177106

23

Dr. Manisha Rani W/o. Lalit Kumar, VPO. Diara, Tehsil
Amb, Distt. Una, HP, 174316

24

Dr. Nitika Saini W/o. Sh. Munish Kumar Dass Villa, W#
8 Pull Wala Bazar, Tehsil & Distt. Una, HP, 174303

25

Dr. Priya Tapsavi D/o. Sh. Darshan Kumar Tapsavi,
H.No. 19, Vill. Baroh, P/o. Raja ka Talab, Tehsil
Fatehpur, Distt. Kangra, HP, 176022

26

Dr. Ritu Kathuroa D/o. Sh. Prakash Singh, VPO. Sakh,
Tehsil Dharamshala, Distt. Kangra, HP, 176215

<!-- page 20 -->

27

Dr. Shivani Verma W/o. Sh. Anmol Kumar, Vill. Lower
Arniala, P/o. Kotla Kalan, Tehsil & Distt. Una, HP

28

Dr. Suresh Kumar S/o. Sh. Jeevan Lal, Vill. Jukain, P/o.
Nabahi, Tehsil Sarkaghat, Distt. Mandi, HP, 175024

29

Dr. Verinder Bhagrai S/o. Sh. Krishan Chand, Vill. Takoli
Girthan, P/o. Takoli, Tehsil Fatehpur, Distt. Kangra, HP,
176021

30

Dr. Vimad Gurang D/o. Ghanshyam Gurung, VPO.
Kakira, Tehsil Bhattiyat, Distt. Chamba, HP, 176313

31

Dr. Vimad Gurung W/o. Sh. Shubham Sen, VPO. Giora,
Tehsil Nurpur, Distt. Kangra, HP, 176201

32

Dr. Vimal Pankaj S/o. Sh. Mehar Chand, Vill. Upper
Barot, P/o. Fatehpur, Tehsil Sarkaghat, Distt. Mandi, HP,
175024
Dr. Vineet Kaur W/o. Sh. Amandeep Singh, Adarsh
Nagar Hamirpur Road Opp Ravindra Cloth House Upper
Arniala Una, Tehsil & Distt. Una, HP, 174303

33

34

Dr. Vinesh Kumar S/o. Sh. Roshan Lal, Vill. Baderah,
P/o. Sohari, Tehsil Bangana, Distt. Una, HP, 177039

35

Dr. Vivek Chand , S/o Sh. Thakur Dass,Vill. & PO Arth
(Lahla), Tehsil Palampur, Distt.Kangra, HP 176059

36

Dr. Alisha Dub D/o. Sh. Mitter Bhushan, # 127, Chotti
Shamshi, Near SK General Store, Distt. Kullu, HP,
175126
Dr. Upasana Chottani D/o. Sh. Jai Chand Chottani, VPO.
Dari, Lower Barol Near ITI, Tehsil D/Shala, Distt.
Kangra, HP, 176057

37

38

Dr. Ravneet Kaur W/o. Rohit Dogra, VPO. Hamboli,
Tehsil Amb, Distt. Una, HP, 174316

39

Dr. Nishant Kumar S/o. Sh. Jatinder Pal, House No. 82
Chopra Niwas Housing Board Colony Nalagarh, Distt.
Solan, HP,

40

Dr. Jagwinder Kaur W/o. Sh. Gurdeep singh, Vill.
Durana, P/o. Dole, Tehsil Jawali, Distt. Kangra, HP,
176210
Dr. Abhinav Choudhary S/o. Sh. Amarjeet Kumar, Vill. &
P/o. Matour, Tehsil & Distt. Kangra, HP, 176001

41

42

Dr. Aman Yadav S/o. Sh. Hari Ram Yadav, Hari Sadan,
Near 33KV Power House, New Kathed, Solan, HP,
173212

<!-- page 21 -->

43

Dr. Rosy Kapil D/o. Sh. Ramesh Kumar, Vill. Jukain, P/o.
Nabahi, Tehsil Sarkaghat, Distt. Mandi, HP, 175024

44

Dr. Varun Deol S/o. Sh. Vijay Rattan, White House,
Rajgarh, VPO. Dehra Gopipur, Tehsil Dehra Gopirur,
Distt. Kangra, HP, 177101

45

Dr. Ritu Kathuria D/o. Sh. Prakash Singh, VILL. & P/o.
Sakoh, Tehsil Dharamshala, Distt. Kangra, HP, 176215

EWS Categoary
1

Dr. Anuradha Singh Thakur W/o. Sh. Praveen
Kumar, Pine Grove School Kothar Road, Sabathu,
Distt. Solan, HP, 173206

2

Dr. Amit Kumar S/o. Sh. Sumer Nath, VPO. Bhatoli
Phakorian, Tehsil Haripur, Distt. Kangra, HP,

3

Dr. Bharat Bhushan Verma S/o. Sh. Arjun Singh,
Vill. Mansui Jhikli, P/o. Bhota, Tehsil Barsar, Distt.
Hamirpur, HP, 176041

4

Dr. Bhartendu Kaushal D/o. Sh. Leela Dhar Kaushal,
VPO. Churag, Tehsil Karsog, Distt. Mandi, HP,
175010
Dr. Kartik Sharma S/o. Sh. R.K. Sharma, Vill.
Kharouth, P/o. Ballha, Tehsil Palampur, Distt.
Kangra, HP, 176064
Dr. Ravinder Kumar S/o. Late Sh. Purshottam
Chand, VPO. Naushera, Tehsil Dehra, Distt. Kangra,
HP, 176029

5

6

7

Dr. Richika Kashyap W/o. Sh. Bharat Bhushan, Vill.
Mansui Jhikli, P/o. Bhota, Tehsil Barsar, Distt.
Hamirpur, HP, 176041

8

Dr. Vinod Kumar S/o. Sh. Milkhi Ram, Vill.
Bhadred, P/o. Grouru, Sub. Tehsil Tihra Dharampur,
Distt. Mandi, HP, 175026

9

Dr. Anamika Sudan W/o. Sh. Sourabh Sharma, VPO.
Nerti, Tehsil Shahpur, Distt. Kangra, HP, 176208

10

Dr. Babita Chauhan D/o. Sh. Ramesh Chand
Chauhan, Vill. Rasoh, P/o. Kanjian, Tehsil Bhoranj,
Distt. Hamirpur, HP, 177025

11

Dr. Gagan Deep S/o. Sh. Asha Ram, Vill.
Ghawandal, Tehsil Sh. Naina Devi ji, Distt. Bilaspur,

Date fixed for documents
scrutiny/ Verification

25-08-22

<!-- page 22 -->

HP, 174310
12

Dr. Gaurav Sharma S/o. Sh. Raj Kumar Sharma, C/o
Aarogyam Clinic Tal, Tehsil & Distt. Hamirpur, HP,
177401

13

Dr. Payal Thakur W/o. Sh. Randhir Singh Guleria,
C/o MR. Deepak Thakur, H.No. 219, Heera Bhawan,
Near Sabzi Mandi, Kather Byepass, Chambaghat,
Solan, HP, 173213

14

Dr. Pushap Raj S/o. Sh. Gopal Singh, VPO. Chhatri,
Sub Tehsil Chhatri, Distt. Mandi, HP, 175047

15

Dr. Sanjeev Thakur S/o. Sh. Prem Chand Thakur,
Vill. Dhar, P/o. Darpa, Tehsil Sarkaghat, Distt.
Mandi. HP. 175042
Dr. Amit Rana S/o. Late Sh. Karam Singh Rana,
VPO. Bari Kalahod, Tehsil Sunder Nagar, Distt.
Mandi, HP, 175002
Dr. Arpana Thakur W/o. Sh. Rishi Raj Jamwal, C/o
Vidya Sagar, W.No. 2 Ramnagar, P/o. & Tehsil
Sarkaghat, Distt. Mandi, HP,

16

17

18

19

20

21

22

23

24

Dr. Balbhadar Singh S/o. Sh. Mohinder Singh, Vill.
Kehrian, P/o. & Tehsil Jawali, Distt. Kangra, HP,
176023
Dr. Kanchan Bala W/o. Sh. Puneet Sharma, Vill.
Chouri, P/o. Thona, Tehsil Sarkaghat, Distt. Mandi,
HP, 175049
Dr. Munish Kumar S/o. Sh. Bhim Singh, Vill. Thana,
P/o. Thana, Tehsil Sujanpur, Distt. Hamirpur, HP,
176110
Dr. Puneet Sharma S/o. Sh. Balwant Sharma, Vill.
Chouri, P/o. Thona, Tehsil Sarkaghat, Distt. Mandi,
HP, 175049
Dr. Rajnish Thakur S/o. Late Sh. Inder Pal, VPO.
Sajao Piplu, Tehsil Dharampur, Distt. Mandi, HP,
175025
Dr. Shashi Kant Sharma S/o. Sh. Nek Ram Sharma,
Vill. Fald Brahaman, P/o. Tour Jajar, Tehsil
Dharampur, Distt. Mandi, HP, 175050
Dr. Sushil Kumar S/o. Sh. Prakash Chand, Vill.
Kapahi, P/o. Sari, Tehsil Dharampur, Distt. Mandi,
HP,

<!-- page 23 -->

25

26
27

28

29
30

31

Dr. Vivek Sharma S/o. Sh. Vijay Sharma,
Sarvodaya-792/1, Room No.-102, Heera Nagar
Hamirpur, HP, 177001
Dr. Anamika Sudan W/o. Dr. Saurabh Sharma, VPO.
Nerti, Tehsil Shahpur, Distt. Kangra, HP, 176208
Dr. Chetan Sharma S/o. Sh. Dumni Ram, Vill. Traur,
P/o. Segli, Tehsil Chachyot, Distt. Mandi, HP,
175029
Dr. Gagan Dhruv S/o. Sh. Raj Kumar, Vill. Bhoor,
P/o. Jhangi, Tehsil Sandhol Distt. Mandi, HP,
176090
Dr. Kartik Kapoor S/o. Mahinder Kumar Kapoor,
H.No. 74/9 Bhagwan Mohalla Mandi, HP, 175001
Dr. Mandeep Kumar S/o. Sh. Gian Chand, Vill.
Benjhi, P/o. Gopalpur, Tehsil Sarkaghat, Distt.
Mandi, HP
Dr. Pankaj Kumar S/o. Sh. Parkash Chand, Vill
Badal, P/o. GopalPur, Tehsil, Sarkaghat, Distt.
Mandi, HP, 175007

32

Dr. Puneet Sharma S/o. Sh. Balwant Chand Sharma,
Vill. Chouri, P/o. Thona, Tehsil Sarkaghat, Distt.
Mandi, HP, 175049

33

Dr. Rama Kumari W/o. Sh. Mahesh Sharma, VPO.
Harlog, Tehsil Ghumarwin, Distt. Bilaspur, HP,
174003
