---
doc_id: "bb065e24e0ac1cef"
source_url: "https://rggec.ac.in/wp-content/uploads/2025/06/Limited-Tender-for-Setting-up-of-HFC.pdf"
ministry: "Rajiv Gandhi Government Engineering College (RGGEC), Kangra, Himachal Prades"
title: "Limited Tender for Procurement of Items for setting up of Housing Facilitation Center"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ddebcf8c826e9c18"
---

<!-- page 1 -->

OFFICE OF THE DIRECTOR – CUM- PRINCIPAL
RAJIV GANDHI GOVT. ENGINEERING COLLEGE
KANGRA AT NAGROTA BAGWAN, DISTT. KANGRA (H.P.) PIN 176047
PH. /FAX: 01892-249188, E-MAIL: rggec.office@gmail.com
WEBLINK: www.rggec.ac.in
No.RGGEC/NGB/STORE/2025-

Dated: -

To

Sub:

Limited Tender for Procurement of Items for setting up of Housing Facilitation
Center (HFC)

This institute intends to procure some items for setting up of HFC in this institute. You
are therefore requested to quote your lowest rates for supply of these items in two separate sealed
envelopes; one for Technical Bid (including EMD) and other for Financial Bid to reach in the office
of undersigned on or before 05/07/2025 by 2:00 PM. The Technical bid shall be opened on 05/07/2025
at 02:30 PM and the financial bid shall be opened on 07/07/2025 at 2:30 PM in the presence of the
bidder or their authorized representative who wishes to be present. The financial bids of only those
bidders shall be opened who qualify technically. The terms and conditions are attached in the form of
Annexure-1 with this letter.
Sr.
No.
1.

2.

Name of Item with detailed specification
Shake Table
The horizontal Shake Table should consist of a connecting rod and a
vibration table. The cam should be connected to a variable speed motor.
Linear guide ways should ensure that the motion of the table is linear. A
circular/rectangular mounting plate should be placed on the vibrating
plate through a T-slot/perforated so that the test structure can be mounted
at top. The table should be able to generate harmonic motions of different
amplitudes and the amplitude of base motions can be varied by changing
the eccentricity of the cam. By varying the speed of the motor, the
frequency content of the base motion can be varied.
Specifications
i) Maximum payload 20 kg
ii) Sliding table dimension 400mm x 400 mm
iii) Motor 1 HP
iv) Frequency 0-20 Hertz
v) Variable frequency
The Shake Table should be supplied with following Models:(a) One storey frame model small
(b) Four storey frame with stiffeners-soft storey model
(c) Two span simply supported beam model
Building Models

Qty. to be
procured
01

1 set

<!-- page 2 -->

(i) Masonry Buildings with Bands
(ii) Confined masonry with confining Column
(iii) RCC Beam Column Slab Joint detail
(iv) Slab only
(v) Beam Cantilever Slab
(vi) Steel Frame with Puff Panel
(vii) LGSF Technology
(viii) Kath Kunni
(ix) Dhaji Diwarti
(x) Thatra

<!-- page 3 -->

ANNEXURE-1
Terms & Conditions:
1

2
3
4
5

6
7

8
9
10

11

12
13
14
15
16
17
18
19
20

Technical Bid & Financial Bid shall be submitted in separate sealed envelopes. The word
'Technical Bid' or 'Financial Bid' should be written on the outer sealed envelope. Both bids
should be further enclosed in the outer sealed bigger envelope and the words ‘Limited Tender
for Setting up of HFC at RGGEC, Kangra at Nagrota Bagwan’ must be written on the top of
the outer envelope.
Financial bids shall be opened only when the bidder qualifies in the Technical bid.
Pre-dispatch inspection may be carried out (if deemed fit by inspection committee) at the cost of
the successful bidder at his premises if necessary.
The firm should have valid GST and PAN, copies of which should be enclosed.
All Tenders/bids must be accompanied with an Earnest Money Deposit (EMD) amounting to Rs.
10000/- (Rs. Ten Thousands only). The EMD shall be attached in the shape of Accounts Payee
duly pledged fixed Deposit Receipts in the favour of Director-cum-Principal, Rajiv Gandhi
Engineering College Kangra at Nagrota Bagwan Distt. Kangra (H.P.)
The Tenders/Bids not accompanied by EMD or incomplete in any respect will be rejected
outrightly.
The successful supplier has to furnish the performance security at the rate of 5% of the contract
value in the form of account payees duly pledged fixed deposit receipts drawn in the favour of
the Director-Cum-Principal, Rajiv Gandhi Engineering College Kangra at Nagrota Bagwan
Distt. Kangra (H.P)
The offer shall be inclusive of all taxes, commissioning, installation and training whenever
required.
If felt necessary, the undersigned may ask for a demonstration/training of the
machinery/equipment at supplier’s cost.
A certificate to this effect that you are the manufacturer of the equipment/Authorized
distributor for the manufacturer or on whose behalf you are quoting the tender must be
submitted and attached in the Technical bid.
The Tender/Bids will be opened on the date and time as mentioned in the tender document and in
the presence of bidders if they wish to be present. However, undersigned reserved the right to
change the date, time and venue of the receipt of the tender without assigning any reason.
Conditional Tenders/Bids and Tender/Bids not submitted on the prescribed tender form are liable
to be rejected.
The quantity of items can be increased or decreased before placing the order.
The supply order shall be issued to the eligible bidder on the availability of funds.
100% payment will be released within one month after the satisfactory installation/testing of
machinery & equipments in the concerned lab/center.
The Warranty/Guarantee shall be effective for the period of at least 12 months from the
date of the actual installation of Machinery/Equipments at the actual location of the lab.
Director-cum-Principal reserves the right to accept or reject all or any of the bids received without
assigning any reason thereof.
Limited tender received in open condition after due date & time will be summarily rejected.
It will be presumed that all the above conditions are acceptable to the bidders applying through
the limited tender.
If the date of opening the tender/quotation happens to be holiday, the tenders/quotation will be
opened on the next working day at the same time.

<!-- page 4 -->

21
22
23
24
25
26
27
28
29
30
31
32
33

Tenders/quotations received through mail, telegraph, fax, conditional tenders/quotation and
without Earnest Money shall not be accepted.
Director-cum-Principal may also appoint a 'Negotiation Committee’ if required.
The bidder will be responsible for damage or loss in transit and goods broken within 30 days from
the date of notice thereof.
GST or any other tax shall be indicated separately otherwise rates will be deemed to be
inclusive of such taxes and no future increase in Duties/Taxes/GST will be allowed.
The bidder has to attach the supporting documents/catalogues for all the quoted items.
The bidders should strictly quote the items according to the specifications mentioned in the tender
document. Any deviation from the required specifications shall not be accepted.
The complete bid should reach in the office of the undersigned on or before the due date and time.
The bid should accompany ITR of previous 2 financial years.
The bidder should attach copy of the supply order of similar type of itms from any 2 reputed
govt. institutes.
The bid offered by the bidders must be valid for six months from the date of opening the tenders.
The bidders must stamp and sign each paper submitted along with their bids.
The rates quoted should be F.O.R. destination at Rajiv Gandhi Engineering College Kangra at
Nagrota Bagwan, Village Massal, Nagrota Bagwan, Distt. Kangra (H.P).
All disputes shall be settled within the jurisdiction of Distt. Court, Kangra (H.P).

Check List of Documents to be attached with Technical Bid :
1
2
3
4
5
6

GST
PAN
EMD amounting to Rs. 10000/Certificate of OEM or authorised distributorship
ITR of previous 2 financial years
Copy of the supply order of similar type of itms from any 2 reputed govt. institutes.

Director-cum-Principal
RGGEC, Nagrota Bagwan
Distt.Kangra (H.P) 176047
………..
(Stamp and Sig. of the firm/proprietor for accepting above terms and conditions)

<!-- page 5 -->

Performa for Financial Bid
(On Tenderer’s Letter Head)
Sr.
No.

Name of Item with detailed specification

1.

01
Shake Table
The horizontal Shake Table should consist of a connecting rod and a
vibration table. The cam should be connected to a variable speed motor.
Linear guide ways should ensure that the motion of the table is linear. A
circular/rectangular mounting plate should be placed on the vibrating
plate through a T-slot/perforated so that the test structure can be mounted
at top. The table should be able to generate harmonic motions of different
amplitudes and the amplitude of base motions can be varied by changing
the eccentricity of the cam. By varying the speed of the motor, the
frequency content of the base motion can be varied.
Specifications
i) Maximum payload 20 kg
ii) Sliding table dimension 400mm x 400 mm
iii) Motor 1 HP
iv) Frequency 0-20 Hertz
v) Variable frequency
The Shake Table should be supplied with following Models:(a) One storey frame model small
(b) Four storey frame with stiffeners-soft storey model
(c) Two span simply supported beam model
1 set
Building Models
(comprising
(i) Masonry Buildings with Bands
of 10
(ii) Confined masonry with confining Column
models)
(iii) RCC Beam Column Slab Joint detail
(iv) Slab only
(v) Beam Cantilever Slab
(vi) Steel Frame with Puff Panel
(vii) LGSF Technology
(viii) Kath Kunni
(ix) Dhaji Diwarti
(x) Thatra

2.

Qty. to be
procured

Rate per Unit
(Including
GST)
