---
doc_id: "bfe882f6eaedb257"
source_url: "https://www.hp.gov.in/hpdmer/file.axd?file=2019%2f10%2fPG(MD-MS-MDS)+Policy.PDF"
ministry: "Directorate of Medical Education & Research, Himachal Pradesh"
title: "PG(MD-MS-MDS) Policy."
date: ""
pages: 23
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "f851ff3936f52b1d"
---

<!-- page 1 -->

f
T
पे “s}UAPLIA}ULIOdNS [edIPayy PUB SISIINC [४०7०५ : y
Ayenseg jo sjsod ayy epnjoui jjeys inq Buysod pjay jo uoNuyep eu) woy em
papnjoxe aq jreys ayeig sy) Jo saBaljog |eB]Ueq /eolpeyy yUeWLUeACs UI s}sod Ue
Buiyoea, ‘sjerdsoj; jeuaay pue sjendsopy jeuoz ‘sreydsoy JOLJsiq ‘sjeydsoy oO
HAID ‘aujusg UNeeH AunWoD ‘aqueg yyeaH (ued Bulpnjour 972g ou) NS
jo SuONNNsU] YYeo}) jesaYyduad snoweA ul Buysod eu) ues jjeys Bunsod plels, 9 L"€
“YSaPeid JBYORWIH ‘YOeasey ९ पणाएजा०न [४०००७
‘JO}O9JIQ ७५) ५४9७ ॥४५७ 3॥00 Vous ul yoleasey 9 ५०॥४०७०य [2009७ ०ण2००७/6,  9%६
“YSOPLl JEYORWUIH ‘SadAeS
फाण्ण+ 2०००-९० ey] UBEW EUS SHO ४०५६४ ७ ,890/09०8 YTEsH ‘JOAIG, PLE
“Ysepely [YDBWI} 'SBOIES WES} /e}UEq
0००३७ ay] URAL FEYS SHAG Yoys ul Sequeg YESH ।श००0 4ण००ग१0, ४॥%६
* -e}0nD eIPUL IY (SOAD-UON) BIND eTEIg Jo seVepIpUeD epnjau! jfeys pue
Od-LIZN yBnowyy ayers 9५ ७ uoyenpeiD ysoq SHuynsund Jo} yyeuaq aayusoul 5
sS]youeqg solAles Bulwure}o you Ss} OUM JO}Op ay) UBEW Heys ,a}epipued Jaq, 68
“Od-L SAN JOU pue UOeUILUeXe soue US eyeledas jo siseq
eu} UO ape ale UOHeNpeI jsOg UI SUdISSIWIPe Yom ० Aeyonpnd YAWdIt
pue wesipueyd YAWIOd ‘I4IEd SWIlIy UBEW jfeys SUONASU] sNOWOUOINY, LL"
AlequUO. ayy Oo} BuiyjAue BuipueysyyMjoN
. uonmyaq —“E
*UOHEOYNOU Jo EVP. auy WO, JosyJe 0} aWoD yeYs Ad!od af
juauaouauiutog =“
+ KOOd Ayepads Jadng/Oe_, UOYS UL YSAPCld [2YOBLUIH JO ae
नगर 94} ul ajqeoydde uoyeonpg jeoIpayy uj sesunoo Ayepads iadng pue uonjenpeld .
80g Ssnouen 0} suotssiupe SuyjeinBe: soy Aoyod, euy paleo aq Aew Aoyod siyL हु
गा। #०पठ
WapuN SB YS@PLld [EYORWIH JO
QEIS au} Ul aIqeal|dde UoVeoNpy jesipe; ul Sesunoo Ayeloads sadng puke UOIJENPesS JSOd SNOWEA
o} sugjssiupe BugeinBes 40) Adiyog Aypejoads sedng/Od Ayjou 0} paseald st ysapeid |९५०४७७॥। :
JO JOUJ2A0D ayy ‘pueGel siy} Ul panss! sUOYeOy)OU snolAsid |JB JO UO|ssesiedns Uy
NOILVSISILON ~~ |
 एछएडट्रएइटपढठ लप 'दाशप्प्रप5एथण्त ॥72502/6-73)8-0यन :०५ alld |
areyony Awe ® YeaH Jo wawHedaq
हि ४४५ 88 USSPUle} [EYORLUIH] JO ]YSWUJOAOS) gape
| cone] “mes |
| AHO eA 9/0 4 |
dl

<!-- page 2 -->

ः री
pue diysuajul Jo uoge|dwos ay] ० 30.9 5फ्र०००७७ ६ SES] Je sBuysod ploy 405 a .
SHG du) Aq safalog jeoIpe Sy} [!2 Ul PayONPUOS aq [EUS smalAeyu] sndweg Ve
: siseq fenjoejuod |"? >
-!spoyjew om} Bumorjoy ayy Aq dn ying aq |Ieys SOS JO asped aL Oo
o . jusweipesuyOaD =F
“sesunod yua|eAInde
yons Aue Jo (Ayeloadg Jadns) SENGMOW/NG apniou! jreys pue uonenpesgy
jsog Jeye pansind sasinoo ey} ueew jleys ,sesinoo Ayeloeds 4७०8, 2॥'॥६
*a}EIS OU] ण 7929094 ५००५
808५ ५०५४ थणाए छएण ity JO s}eas paryun ayy epnjour yeys pue Suyjesunos
ayeig yBnony dn pally ave yoru syeas eu} epnyjoul Heys BOND SIS ShLE
“ysapeid [PYORUWIIH JO SJEIS Oly UBS [EUS PIES, GLEE
: . “sammjeuusoy puog eu) [Je jo SUNYIN,
Jeye SHA eu Aq panss! eyeoytiso sy) ५89० ॥४५५ ,थ8०॥॥००0 diysiosuods, PELE
-asunoo ouy Bulinp puedys Bulmedp Jo; payyus aq you jeys 9५9/9५ ‘pasosuods .
9] 009 & ased Ul ‘eASMOY “AjNp-UO PsJep!suod 9q jJeys UONEIND Ayeloads
uadng juojenpelg 380g Jeu/siy ‘OGD perosuods e jo 9sed Ul ‘sasodund
lle 404 “OAD eu) Aq pansind Bulag sesinog Ayejedg JedngjuoRenpesd 3SOqj JO
asinoo aly Jo uoHeinp pequoseid euy Buynp (aiqeordde !) sjuawelou; enp YM
Buoje saouemoye/Aed/sjuauinjows jo uewAed ayy ueeuU |॥|४५8 diyssosuods, ¢p'L'e”
“gaginoo yuajeainbe yons Aue 20 sasinoo ewoldiG/eNG
JHANWHVSCOW/SW/GW alenpeid iS0g Sy} UeEtL |JYS UONENPEID 380d, ZEVE
‘aiqeordde eq Aew se asinoo Ayjelsedg Jadng pue vojenpeld .
JS0q ansind 0} Ysapeid [eYORUI} ‘SBES YESH ‘oWeIq ayy Aq panss|
ayeoyfieg uoHoelgo ON a4} UAW |I2YS QON HOUS Ul ,४०४॥४७० uonjsalgo ON, LL L'e
"ayeIS OU} JO SaBalJoo IPIUEC/POIPS,
JUSUIUIBADD sNoLleA ay} U} SAOge pUe JOSsa/Ole JUEISISsY FeinBel se Bupyom
ZING Jo juawysiiqeyse ayy Jepun suojoop ayy ueawW yeys Aynoes [BOIPEW, OL'L'E
“YSI] WAY BION e723 oO dn Buymesp jo
asodind ou} Jo, sSunsod pjalj uj Buyvles Jo eaguadul Jo UoNBIND|e0 Joy pexnbex
aq yes pue Bupsod pjey singed @ ul OGD ayy Aq pares powied jenjoe
up Aylyia0 {]2Ys YOU PUE SHC yp Aq PeUBIsLe|UNOD PUE J9AI4O [BOIPA/\| JOIYO J
90५) Aq penss! 9q f/eYS YOIM ayeoyyseo ay} UBELU ॥४१५३४ ,४०॥॥०० SARUEOU, ELE 2
"पृ5998/त6 JEYORWIH JO JU@UILIBACS OY] UBS [JeYS JUBLLIBADDH, 8॥'६
“siseq JoeqUOS /JeijnBias UO peyulodde s0yOp ayy apnjout
Jyeys pue Ysaperd [8प2७०॥- '$900५98 ५॥४०५ “JO}aG oY} Jo JUsWYs|qe}se
eu] JapUN sIO}OP ay} UAW eYS OGD Yous ul ‘seIyO Ajng 9००७७, /+%ट४ te 7

<!-- page 3 -->

rejnwo} Suimojfo} uy Jed
se Bunsod pjay sejnomed e ul pesepuel adlAsas Jo LONBsNp Jenjoe ey} JO) siseq
B]2)-0id UO payndwos aq jeus eaqueou! aBeyusded aU) “W-FYNXANNY Jed se 4
sBunsod play snouea Ul pasepuei SAdIAJAS Jay} LO paseq Od- LAIN U! peuyeyqo a
syew jo eBejusosed jo suey ut aaquedu! JO} pannus aq jeys SOGD 9७१५५ LS LA
“SH eu} Jo oINJeUBIS Ja]UNOD JOY a}B0WIED 90॥0900| 9५) 0099 PU Pi0del OO
BOIAIAS PAUIEYLIEW 94} WO OCH ay) jo siejnoed sojrias ay AJLIOA |JeYs q
JOOIUO [ROIPIW| Jolud Pausaquas ey “Afeyesedes SHC 9५) Aq payoU aq |}eys
YIU yuo, paquoseid eB uo epew aq |jeys UoReaydde ey, “‘Bures Aquasino
S} BYS/ay WOYM JEPUN JeaLO jeolpay! J9IYO [290080009 9५ 0} OA ‘snoijsep
au Aq epeut aq JeYsS ayeoymieg aanuaduy JO souenss| Jo, uoWeoydde ay] ELS
“Buyyasunoo
BIONO seis ey) ul Buyeedde 30 (७० plpea eq Heys aBoyIEg SAnueou|
9५ Jey) paplAoid JoyLN4 "Od-L35IN JO NSE! Jo UOHeJeIDap JO B}ep ey} UO
souasge pazJoyjNeUN Jo yeas AUR JNOUYIM sI|AIas SNonuNUOD paydnuajuyUN
Jo seaX auo ysea] ye peysiduioo aaey om OGD ssoyy Alu 0} panss| 9५
[eys aTeoyID Saqusouy yons ०५ paplacid OGD & Se ae} Oy} ul Buralas JO}
BAHUOUI a4) BuI[feAe 20 9४०॥॥/४० 9/09५9००| प९ ॥० quawaiinbes aq Weys Bay, ZY 'S
“sayepipued OD
ayy Jo Aue 40) Dd-LASN Ul Jeedde 0} DON B JO} JYewWarINbel ou Aq [weys eJ04L L's
Ode L3SN पणप गण oY) UUM LOLENpeIO ysod Burnsind 40j eayusouy | 9
uojenpesg ysoq Buinsind 405 diysuosuods/QON/@AnUSDU] “SG
. / “OU O} OLN WO) So
yUaWWJaAcs su) Aq papioap aq Aew! se siseq JejnBas uo e[wiys ‘UOIssILUWOD
BDIMAS OGNd YSEpeid [EYOPUILY YBNoI) peyonpuoo aq osje Aew jueUYNIOeY टंटए
“AUUIL] O} SLU) LUO JUBLULUBAOS) BU} Aq peylou
Aoyod ayy ym aouepioooe ul pezueinfe: eq Aew sOqd jenjoenuod ay, L'2'y
siseq seinBay =z"
‘ . *‘sesadund jeanoed |e 40) seyepipued fenyoesuos
se payeen eq jjeus pue (Buljim J!) SOdD se anuRuod jjeYs adjAles jesoudued
: JO poled Alo}epUeW ay} PUOASG ByBIS BU) SAJOS OYM SOyepIPURD JOal!q esouL EL'y
. “sHunsod piel SNOWeA 0) SU} 0} BLUR LUO JUSLULAADS) BU}
Aq papjoap eq Aew se SHG 9५३३० 99॥० ०प UI Play aq HEYS SMOIBIUL-UYIEM  2'b'7
“diysusayut .
JO uonatdiuos ay) aicjeq seJepipued Buy 0} panss] aq ||eYys siepso Bunsod a
“

<!-- page 4 -->

v
“Buyjasunoo eIpy|
॥ए 9५) Jor Buueedde aie um SQCD esoY) Joy e[qeoldde eq jyeys eanueoul ON 6.9
हु “OAD eu} Jo pode, yeuosued \ A
ay U) pally oq jeYs ayeoysWEQ SaNUaoUl ॥४पण०० jenpIAIpu! 9५॥ “SelePIPUES XX res
yoanp pue OCD Jo jooedsai ul ysy yew paulquios e dn Buymesp Jo} SING eR Le vale ६
0} apepipueo yore Jo joadses uy (sjulod jewjoap eay {m) eauaoul paynue out Ta
AJLOIUNWLUOD PUB JEQUINU HO! Od-LAIN HEU) yWMBug}e |yLoyN9Q SARUBdUT JO ee
gouenss! Jo} poydde aaey OYM Sa}EpIPUeSd |[2 JO ISI] ०५ aliduioo |eus SHA eUL
“SHa euj Aq sulod [४४००० ०००५ ण 9० 990000/ 208 dn pewuins ‘payeinojeo 3q
jjeus ayepipued seinojed @ Jo, Bunsod play yore JO} aiqeaydde aanuedu su, 8॥9
हु “@Auaou!
ayy JO IyaUaq ay) Buleae ul paysesayU! JOU s! SYs/Sy JEUT pawinseld aq [eys
‘ y asodind guy JO} paqiioseid oyep se] 84} Asidxe ayy asojaq uopeadde eyew 0}
suey OGO Aue 4} “9°}'g esneo sed se UOeOWNOU Ul 99५0प्नप907 powed jo Adxe
ay) Jaye paUIeyayLya aq JBYS a}EoyIWeD SAHUsdu] JO eoueNss] JO} uoneoydde on Z's .
‘Aayeiedas 40 snjosdsoid jo ped eB se sauyie JWG eu)
Aq palijou oq (24s aleoymSD @Aquadu| YONS JO BouUeNss! JO a|npeyos ajep ay. O'S
"yNsOl Od-LSAN JO uopesejep Jo ayep au eq
[eys ayep Yo yno ayy ‘SHA eu} Aq aanUsou| Jo uoyeyndwoa jo asodund eu 403. 99
uo “suoneinBsy Uoneonpy |eaIpay| ByenPelD I8Od .
eIpuy Jo JoUNCD jeolpey Jed se pue ueYyNeYD yBuig Yyseulg Iq SNsleA “SIO
2 ‘dN JO SIS -BLOZ/ZPOs “ON Ieaddy HAIN UL 9L0Z ‘IsNBny BL UO eIpul J
yng ewa:dng 3|q,UoH U3 Aq pesaayep jueuuBpn/ jo sue} ul %0E JO WNWIXeW |
0} yoe{qns aq jm aAguasU! sys “"yeeg Ave qnouy sojies snonuyUod Ur SI
aYS/ay USM BYepP ay} Loy PAUOYOA! ag[AJes Jo 7०००१ ३५०४] 9५ LOYBJEP|SUCo .
हे ojur Buryey payejno|2o eq IM BAHUSOU! BU} ‘ureBe diusodd sulol Aquanbesqns
ays/oy J} ‘Apelwig ‘sores snomeid Aue jo siseq oy} UO eAHUdOU! SIU}
JO yyouag eae ० गवाण| ०व 4०५ ॥९५४ dis OAD woy peubjse Anuenbesgns
sey yng jsed ayy ul OGD & Se perles sey OWM JOJOP Aue ‘Aqesey) Bujueaw
4yuncooe Oyu! Uaye] 9१ ॥8५७ BoIAJas sMoNURUOD Jueseid eu} “SAHUBOU! OU}
Gunndwios yo asodind ey) Joy pues JOULE SONUAUOS B UI, a}2IS OY} JO S9]AJ88
BANOR 9५ ए ale ०५७ 9009 98०॥॥ ॥०० ० aIqeLeEAe ७१ \ xe SANUBOU! SIUL
*aAUBOU JO VONENO}ES OY} 40) JUNCODE OJ] UEYE} Bq ||! Bunsod pjay senoyed
8 Je penies UoNeINp JeMoR au} ‘UoHEISs JayIOUR 0} PoLsd SUWOS JO) payndap
5} OY ING UOHEIs JejnoWed auo ye paysod useq sey 008 seinopied 8 8820 ७|
(\yv aunxeuue) Buysod
uonmpsul senored so} X 8s a ee eoisd :
@anuaoUl paqiiosaid (skep ul) pansas uoyeing anqueoul _ o:
: y

<!-- page 5 -->

. S .
हे “sUONNYISUL snowouoyne \e
jo pionb pasosuods-uou jsuieBe JO Od*lA5N yBnoiyy ayers Pas.
aU) apisino UOHENpe!D \80q JO} pasosuods aq eys OGD ON (e Co -
EISEN YONORy SIS ब्या Spee UCHENpeIg Ios TOF ढ॥79 ™
g-asnejo Jad se sanyeuio) je jo juawying = (q
. “BUIJSSUNOD yeYS 0} JO aJLOyWSD @AQUsoU}
panss] useq aey’pinoys pue paldde eaey pinoys ajepipueo ayy (2
BRIS SUT UGIM UOMENpeID OTTO bb's
:Buymorjo} ayy aq TeYs eyeoyiIe9 djyssosuods Jo souenss|
Joy saysinbel-eid ay, “SHq Su} 0} diyssosuods Jo, A\dde jjeys ajeyg ayy Apis;nO
JO UIYIM UOHeNPLID JS0q Bulsind jo snowsap SOGS sy} ‘Buyesunos eu} ayy bps
diysiosuods  #'५
हे “sjuaumoop
puog jo Burysiuiny saye Ajuo ayeplpued ey} erayjal eys pue g SsNejd Ul paquoseid
Se SONFEUO) ayy ॥४ 9०००४०० प०प EUS SHA SU! ‘Pied yInsed ouy Uy Buole 50|09॥9/
JO} SHO eu} OF Aidde Heys suoHMASUL OU) UL pa}sefes Afuenbasqns aie 0५४ | 'ट'५
Ul] UMOP PIe] SB SUORPUOD O} JO9/qns SUORNSU! SNOLWOUEINe Jo UOReUIWEXS SOUERUS
ain ul Bupeadde 40) diusiosuods/OON pajuerb uaeq eae OM Sejep|pUed . yong 8५9
suoNp}su] snowoUo}Ne JejnoWWed . 7
Aue Jo snjoadsoid eu} ul aolAlas Jessa] Jo }USWId4NOJ By} BuipueysyyMjou .
(2) L'7'g 38 pauinbal se eaisues jo 38/89/884५) 920)94 ०७५०७ 9q JOU I! DON (4)
“uoneulWwexa :
ul Buyeadde Jo) DON JO} SHO ०५ 0} UoHeordde Buje alojaq |
3900 [४97०९ ३9५० ०9५ ०४०५ 009 79०५३७०५०० ०प 4 7०४]४१० 9१ ॥४५७
UONBOYOA YON "piodes 90|0499 990][छ08७० 296 98 Jed{YO {ope JO!UD ‘
peussouoo auy Aq palyJen Ud9q SABY PINOYS Jae SIU} O} P4094 90[0995
JU/S!H “eouasge paziioyjneun Jo yeelg Aue nowrseanues snonujyuos
paydnuajuiun jo sieeh aely} eAey pjnoys pue dejnBes 94 pynoys 909 (४) है
, \ -80०॥0५009 |
Bumoljo, ayy 0} yelgns seymAsuI snowoUCyhe et} yo ejonb peiosuiods eu} ”
ysujebe uojeulWeXe souedue 494) Uy BuLeedde Jo) suoKNysu! SnoWOUOINE Su} :
Woy UORENpeID sog BHuynsind Jo snosisep 5009 oO} Aluo penss! eq #2US OON .b'2"S
suo}Nyysur snowouo;ne jo
syeas ejonb paiosuods ysujeBe uoyenpelg ysod Buynsind 40} diyssosuods/90N 2S .-
4

<!-- page 6 -->

9
39908॥00॥2 प॥॥४0 689 ॥)] 5ण//॥॥०७ श9०७4 90०98 ० एगतक्‍रापह : 4 ase Aey) se Bunooy . \ 7
quasayjip @ UO PUeIS BONO eIpul Ity/ale}g ५० saBaljoo jejuaq/eolpeyy WEWLEACD a
७ a]eIg 94) UIYIM UOeNpeID sod sensind OUM S}BpPIPUeD JOaIP SU) SOUIS “SasJNOo Cc
aanoedsal JIU} Jo UOe/dLU0d Joye Buysod play jo sea Jsuy Aojepuew Burpnjour suze Cc
AY ISCA| Je JO} B}LIS Oty} arvas 0} puog & Ys|UIN! O} eazy [EUS (geinBel) OGD yons
Asond 'aSnod ayy BuuNp aye}ys Oy} Buyrjes ueAa jou ae Aou) pue asinod ay} 6ul:np
gyuswesou! yumBuge Aed jjny way) shed JUSWUIEADS OU} SB ‘suOAM SU] SMOWOUONE
Jo sjeas gjonb pe:osuods UO ajeyg ०५ spis}no UoWeNPeI J8Oq 30] paiosuods
SOCIO JO 980 Ul ‘ALEILUIg “SasinoD eayoadsal Jeu JO uoje|dwos saye Buysod platy jo
4eak ysij Aloyepuely Burpnjour sue6A snoy JSBO| Je 40) BJEIG OY) SALES 0} PUG & YSILINY
है ० %७8॥ ॥8५8 seBaoo [ejUaq/Iecpay) JUAWEACH Ul ayes Buy UILTIM uonenpels
3S0q ensind 0) pasosuods uaeq eaey OM QoequospeinBal) OOH AleAe ‘asunoo Su}
Buunp Aojuas pue seouemoye j]2 YIM Buoye Aed yny ७४9५) 5480 098४ pue uoNenpess) .
Js0g Sujop JO} ayepipues yoee Uo einyipuadxe SANUEISqns SINOUl JUSUILUBADS SU SV ७9
WOTENPeID ISOd 40} PUOg JO SUOHIPUSS pue suey ‘9
“UOISsUpe By} JO UOHE SOULS JO} SINYYSU] JO PEA} 0290299009 BU} O} Bunun
sapiseq payenul 6q yeys sBulpescod Aseurdlosip ‘ayeplpueo OGD JeinBa. jo ased
ul pue yuetueaiBe yRUOS Jo swe} Jad 58 90800 94 ॥४५७ #2900998 70४ PayeUjUe}
pawaap aq }JeUS Sed]AJ9s JAU/SIY OAD JenjoesUod Jo 8sed Ul ‘uolss}wied/uoneubises
Np InoYM a}epipueds JOaJIP ४ 58 woneunieya SouRNUA UONNYSU] SNOWOUO;NY/WeXe .
Da-LAIN प8१०५ गण ०१५ episino Jo Magi vonenpes ysog sujof OO Aue y s's
“suoHepUsWOda! YMBU]E SHG eu} Aq hrouneros @Uy 0} JUas
aq jjeus aseo Jatysiy AjBulpsoaoe pue uoyenpes6 ysod 9७५ ansund : .
oy sjuem ays/ou Jf UB|sal 0} BABY {IM 009 ety ‘asinoo uoenpel
80g auj Jo uOeINp 40} paiInbal aq Aew se sIqISSILIPe JOU St :
७७७8७] JUOIOYINS J) “eABa™ APIS JO} powad puog Bupnjouy paywes6
Bulag anes, ay) Jed se suogipuod ayy o} jOefgns qUEWLEADd
au}, 0] papueuluosds 94 ABW aues ayy ‘eaoqe (q) esneio
jad se onp puly Jo Save] JUaIoWNS sey ayepipue 9५ ॥ '07#७॥७/
JO} SHG etn ० Ajdde jyeys suoNnnysu snowouojne jo e}onb
paiosuodsun ysure6e Jo Od-L3GN yBnoiy) ayeig ey} apisino हु
$8S/NOD UORENPLI ३5०० ० SUOISSIWPe eiNoes oUM SOdD yong (9
“soimy (2297) SOD Jad se aiqissipe asimuayjo
aq sew se ‘onee] Areulpigo eyxg jeaes7] Apmis Burpnyjour
ANP puly Jo 908० eae Aw suOHNSsU] snoWOUC;Ne Jo ejonb
palosuodsun jysuiebe 40 O_-L3IN y6nosy) eyes ey) apisyno
$9sinod uoHeNpeld Jsoq Ul SuOIssIWpe 9॥995 0॥/॥ 9058 ५७8 (q जा

<!-- page 7 -->

६
aun jo Bujseaj9 Injssecons pue synsel Dq Jo UOBJejoap Jo UO e LIVI SHOO/SHA \-
aty Aq penssi aq jJeys seyepipueo yons "jo siepso Buysod play ey, “seyepipued oO
joauip Jo yaadsai ul eeJGep sojeyoeg jeu!5.Q pue enbeyo payepun uowses6e puog a CO
ay) Bulpnjour syweuinoop ay} Jo Apoysno |yy JaA0 ye) YS SHO ay) ‘Aisnoaue}NUIS an
‘a]B]S au] AES 0} Ppapuog ase CUM selEpipuRA esol} |}e Woy suoydo aye) ॥8५९8
pur eBeyoo pauseouce OU} UF MA!AJOPU! Ul YJEAM JONDUOD |JeYs SHA/SHA 2ut ‘aBaloo
jequaq/eolpayy Alena ul uoRenpeld Jsod ey} JO UOHa|dWOD eANe]Ua} el) ७094
SUUOW OML -(saBaijoo aaijoedsel Jo sjedioutld yBnowy sayepipues yoeulp JO eseo ul)
SIG pue (soda J0 8829 UI) SHOG/SHG 44 IleUs se.Bap ssojayoeg feuIBo ey) pue
anbauo payepun ‘Bupyevapun jeBat se puog— syueuinaop 9ety asouy} Jo UEIPOYSNS ay, H°9
“uoloe JO} a{qel] PauieoUOD BU} eYBW |J2YS PU SIU} UI AINp Jo UOHOL|eJep
Auy ‘asinoo ay) 0} ayepIpueds yayip e JO UOISSILUPe Jo Su ०५ Je SJUBLUNDOP Ssauy
3० पणा०७॥०० aunsua 0} aBaljoO jeoIpayy peuseouod jo [४०००० 94} Jo Ayqisuodsas
ajos ayy pue pesosuods 50०4 भू 0५७ arepipues OGD yoee woy syuswNd0p
yons jo Bulysiusny ०५ ainsus 0} SHOC/SHA Jo Aiiqisuodse: ajos ayy eq HeUs ॥ 89
-g aunxeuury Jad se aq jJeyus puog aty jo }eUNOy paquosaid ey] P79
‘yeas Jo aBe}SEM JO} JUSLILSADB |72}S BY} 0} SYA]
OL ‘sy Aed 0} ayqey) 9q yyeys Aauy yom Bure} paquosaid esunoo ay} ajejdwico |
jeys Aouy yeu; puog jo wed B se Buryeyepun ysiuny osje [Jeys sayepipues oUL €'2"9
“juaweelBe puog ay} Jo Wed e eq [eYys stu}
pue junowe oysinbe eu} Jo Uopisodep Jaye Jo posed puog ay] Jo UoHa}du09
yaye Ajuo paseajas aq yeus 9ai6 y Jojayoeq jeujbuo ey, ‘saiBap ayeoydnp
Aue Bululeyqo wo. paueqgep sq हि 929[70४० 9पा 208 voNuajas Yons jnoge
2०७०७०॥७ 94 ॥९४५४ ७०्र5ण/ग9४५१ 0089५ [9090009 9५॥ “(sarepIpued
yup jo ase9 Ul) जात 7५७४ (9068 ॥० 9589 एु) SHAG/SHA oul WIM 99/000
उणु०पण्णव ४जु5७० ॥०प ysodep osje jjeys ;°9 esne|o Jed se ४०॥४०॥०५४० out 2°29
*SUOIIPUOD PUOG SU} JO UOIJE[OIA JO JUBAB U] PSYSeOUS
anbayo ou) 386 0} Aveqy Je 8q TeUS SHA SUL “SHO Jo eweu ay} Ul soe]
OP “sy 0} Suyunowe yueq painpayos & Wo anbeyo psyepun ue Ysiviny osje
हि EUS BJEP|PUD OY) “JUBWUJOAOD 9}2}S By} 0} SBT Op "Sy Sy ABC O} arey |JeYS
ayepipues ou} yoium Buyey powed pequosaid JO) eJe}g By] SAJBS O} Buryeyapun
[४5०७॥ & Jo WHO} 9प UL PUOG e YsiLUN JeYs L°g asnejo Jed se sayepipued eu IY L'2"9
suo} Buymo}|o} Buy UI Bq [BUS |g Bsnej Jed se Pog BY, 2'9 .
“gasinoo Baljoadsel Jou} JO UOIe|duoo Jaye Buysod ploy
० 4896 si AroyepueW Burpnjoul siBac Om} JSEO] Je JO} E}eIS Ol) BABS 0} PUO B YSN}
0} eney |eYs ayepipueo yooup yons Asana ‘puadys jo jusuAed Buipnjou! JUWUIaAC5
au) Aq uoqeonpa jay u| papuadxe seoinosel ey) MalA ul Buidaey ‘IeAaMoy ‘payque
ale sywediajunoo 008 Jey पण५७ ण UOHeseInBas Jo seoueYyO pue (s}USWeOU! pue ‘ a पा

<!-- page 8 -->

8 है टू “
a Neb
“weweelbe C
yejuoo way Jed se fuejes jenjoesjuoo ay} pled aq yeys ¢°g asneo sad se aye}g ayy “oe
ulujim uogenpes Jsod Buinsind 40; perosuods pue siseq yeNUOD UC payulodde soda VL
uayenpelds yso0qg Buunp uoyesaunuey 2
‘asde| Siu;
JO} JUSWLAADD) BU} 0} BIGeJAMSUR aq PINOM SHAQ/SHA 2s "WeASMOL, “SeXy
Od au) Buueasio seu) Jo yuoW eB UNM sBuRsod play Jo} siepso Aue onssi
0} SII2} SHOG/SHAAUeUSAD |ty ase esoyM Ul! eyEpIpUe Joop eso, 2°8'9
“@SINOD JO BIS SU} es0Jeq YAP! paquosa.d
8 ७० UoNdO पृ०5 पृश५७॥ ॥8५५ 8०४०॥००४० yong, ‘eyes ay) ul uoNenpelb
3808 ७७ Bunp puedys Aue aye} 0} BSUS JOU Op OYM seyepipued yOalIp aSOUL L°9"9
rsoeus.s Bumol{o} ay} Ur
SIEPIPUBD jO8IIG JO eso Ut ajqeoldde eq jou [}eYs PUOg Jo UONIPUOD SUL :suONdeoxy g'g
“OUND JEIIPE,) PaUsedUGd ay} Wo4sJ UOe.NS|Baz Jo UOWBaOUeD g* 29
*JO3J9Y} AYISJ@AIUN) POLUBOUO BU} 0} ape
eq |feYs JUeWasiOpUa PUB pauNje: eq Jou {jeUus aaJBap Jojayoeg jeulBUuo ay] F'Z°9
“ayepipueo OMS ay} ysulebe shulpseoojd Aseuydiosip jo uoyeRiU; ¢72°9
“peyseo-ua eq [Jeys SJUaWNDOP pUog Jo Led @ se ayepIpueD aly Aq pey!wigns
anbayo ay} ‘Mel Jo sseooid snp YBnoiy} pesercos aq Ys }UNOWe pucg sul 229
“me| JO SSsd03d anp
UBnoly) pasenooes 8q Weys diysiosuods Buynp eyepipueo oy} 0} pred Auejes eu = ELD
SHO aun Ag payeniul aq jleys sucqoe Bulmorjos
BU} '9°9 SSNE[O UL} PSUY}NO se pUuog JO sue} 94) BuNRIOIA a}ep|pued e jo JUBAS ey ०. 9
“Buysod
Pley Jo 422A ysuy Auoyepueut ayy uiyym Aouapisay 0५०8 JOj sanbel ul Buying 899
पु ‘AJEIS BU} JO BdIAJaS jo poled
Aoyepuew eu) BuLNp OON JO} Isanbesjeaeay ApNys/JOF Joj ysenbes ul Bund = z"9"9
“Ssapso jo soueNss! jo Shep O| ulyM Bunsod pray ueAlh ay) uiof Oo] ainyie; 4°9°9
Lg esneig
एु 079प० 5४ 9०७ 9५३ 8४३७७ ० PUOG ०9५ JO UOHEIOIA e aynyNsUOd [eYs BuIMoyo}; eYUL 9°9
“UOHENPEID jSOq JSJt +णाष रण 5 ०पा
JO 90|0795 ]० poled Asoyepuew eu) BuuNp syepipueo Aue 0} Aduapisay JOIUSS/asinod
Ayepadg sedngsesmoo uonenpeid jsodq puooas 30y payuesd aq IM DON ‘esed OU UY 99
"SHC 9) 0} Woda, 0) UOROS.Ip ay) YM
OSINOS ay} JO UOHE{dWOS jnyssedons Jaye AJUO (BJepIpued JOSIP pue sOdH Bulpnjou)
SOJEp|PUed ay} eAStja! EYS Sfediou PeusoUCco sy; “AoUBoeA 0} yOalqns SWEXZ Od हि -
+

<!-- page 9 -->

: 6
“puog ay} Jo sue} Jed se Aempiul asinoo au} BuIAee} Jo ]USAS UT SUE] OL “SY AK
Aed 0} eaey jJeys OGS sup ‘siu} 0} LONIPpe Uy ‘sayepIPUeO |y} WO Pai@Adda, aq eYS oO
7०७9० siy 70 uosied ayy 0} spew juauiAed ayy pue JOF se pejeey) oq ew pouad {
JEU] {IPeL9 SIy UL ANP PUN JO Brea] JOINS OU S| BJ9U} J] ‘ANP up| Jo aAee] oy) sUIeBe —
pezueinBe: aq Aew uopenpeig jsoq Buunp safayjoD jeolpay ey} Ul quads poad
aul “Kem piur esinoo uoenpes6 jsod sags} OY 8,009 ०७४०५ 7० 'भूफ 0} LOMIPpe UT 26
“ABMpIW
asinoo ay} BulAee] Jo ayep St} Woy psuoyoss aq |eys Buleq-ap jo asodind au} Joy
89k Say Jo pouad SUL “YSIPCIe| EYORWIH JO गण 24} episjno pue UILYIM see SAY
IXOU Ot} JO} LOTENPRJ 3S0qj JO} UOReUILWeXs eoueUe Aue Ul Jesdde-es 0} pauegep oq
seus ays/ey -Aerapiu BSINOD LORENPBID JSOq SU] ४०५७० 'गरथ5 SU) BPISINO JO Sye}g aU} .
uluM UOeNpels ys0g Buinsind 404 diysiosuods poyuesB प9००१ 90४५ ०५/" 8,008 »फ 6
ABMPIWW Bsunod UOHENpelO Iso 5प[श४० 40] छणा७],. 6
quapisey Jolues @ Joy paquosaid se Aed eu] १४४१० ॥ए४प५ ०५ “‘Bunsod
play Jo JeeA ysay AloyepUELL Jo UOHe|GUUOD Jeye seBallog leoIpey) ayy Jo Aue u! Wapisey,
Jolueg se sujof Ajuanbesqns s}epipued jOo.Ip 94) J ‘JaAeMOH ‘Bunsod pial, Aioyepueut
jo poued ayy Buynp sesodind jeonowsd ye JO} SOdD Jenjejuoo se payeal) aq
॥ए०५७ pUe OBO Jo} oIqissiWpe se ayes By) ye Alejes Medp [/EYS SEyEpPIPULD JOOIIG OUL 'S :
: : *JO!RNUOD OU} JO SUA]
jad se Uy O} aigissiupe se “ueyes uy Meup oO} भाणा५०० ॥४५५७ OAD JeMjoejuoo ey{ 2B
“Buysod
play Aloyepuew jo poyed ey} Buynp sjueusesou; pue seouemole enp YIM Jey/uiy
0} eigissimpe Aed pue syueunjows oy) Meyp ० anu}UOd jeYys OCH Jeinfel ey, 48
unsod pyaly Aioyepuew ay} Buynp uoyeseunwiey = “8
: है >]. 8.9 9भाष्ट० 490 58 '30) ७७७०५० ॥|
‘uondeoxa aly o] yoafgns wauy o} a|qeoydde se puedys pied eq jjeys Seyeplpued jooiq EL
. “soyepipueo
ay} wos poseaogal 94 ॥2प5४ powad siyj 2० uosiad ay) 0} epew quswAed ayy -
oue OJ se payeey aq eys pouad yey) ‘ypelo Jey/siy Ul ENP pulj JO SAed] JUsIOIYNS हि
60 9] 9/9५ ॥ 'शाए 00५ jo eres] aly ysuleBe pazpeinBes oq Aew poued paquoseid
au) puokeq uonenpess iscq Buynp yueds poyed exe ay) ‘powed ewiy paquosaid
AU) ULNA LONENPEID ISOq Sy} sjofduos o) ११४ JOU Ss} OD pauosucds ayy ‘aseo
ul ‘powed paquosaid yons Jo} sjuawaroU! Bulpnjou; saouemoyle ‘Aed seinBas ayy pred
aq seus eys/ay pUe LOHENPEID }S0q Jo poled pequoseid ay) BuLinp Ajnp uo payee.) eq -
WeUs ¢°g eSne[O Jed se sUONNINSt SNOWOUOMNe Jo s}ees ejoNb pasosuods UO ayeIS SU)
apisino pue ayeig ey) uly UONenpel6 ysod BuInsind 40] pesosuods sogo JeinBey ८८ नर जा

<!-- page 10 -->

or
. oe
. “suOIINISU] SNOWOUO NE By} A ,
Jo syeas ejonb pasosuods auy ysureBe Buyeadde Jo }deoxe paquosaid sasinoo A
Ayewoads sadng ey) 0} uojeutwexg aouenug leyjo Aue 40 Ayersads sadng ™
-LBSN eIpul iy ay ul Buyeedde Jo) DON Jo juewayNbes OU aq {JeYys B/8UL ELLE
fo SOD 405 diyssosuods/OON Fb
. /O . sasinos Ayejoeds sedng Buinsind 40) diyssosuiodg pue DON “EE
“UoIssIUpe at JO UOTE|JeqUeS JO) SyNyYSUY Jo 989 PeusEdWES ouy Oo} BuNLM .
sopisaq parenit! aq jreys sBulpasooid Aseuydiosip ‘ajepipued OGD Jejn6al ]0, 8889
Ul pue juawaal6e joeNUOd jo swe} Jed se ape aq [feys AleAooal pue payeU|UEy
pawaep aq }}eYs SeoIAses JeY/SsIY OCD fenjoejuoo jo aseo ul ‘uoReUBse! 49५५
BuIPIWqns JNOLIM JO JUBWULBAED BY} LOI} DON Buyje6 inoywm voenpelD ISO sulof
ays/ay 3! puy “sasinoo yons Bululof aojaq sjees Uadojoeulp ysuieBe UOYda!as 4949 UO
uBisol 0} say JEYS d72}S S42 JO jNO Jo UILJIM ayepipueD syenpels Js0g se perosuods
aq 0} 89988 payinbes wnuyul jo UoNIpuco aly Buyyiny jou s| oym 008 Auy POL
“sainy (७४8०7) 539 390 58 uauandD ety Aq 703
Jo ueJ6 au) ide AJuo asunoo aaifap Od puodses Hey} ansund Aew sayepipued yons
Usnamoy “Ayeiads seyjo Aue u! ewoldiq/gnd/ses6eq Od Bulnsind Jo} OON pejues6
94 jou jjeys Ayeioeds uo ul gNC/ewoidiqg Od payaidwics eaey OUMm SOCD oul LOL
"ENG/ewordig Od Jo uons|dw0s
Joye (SeBaljoo jeweqnesipay JuewuseAcg ul Jo sSuysod pay ul eyze) sued eAy
]98B9} 78 JO) V2)S aly Buses soye AjUo ‘Ayeioeds ewes eyy ul 9ei6eq Od Buinsund Jo}
90 ५9५० sq Kew Ayeioads auo ul aNajewordig Od payeidwos eaey om SOdD sul ZOE
. : “sa[Ny AAed] SOD Jed se JUBWLI@ADS au}
Aq 703 Jo jues6 euy eye Ajo asinoo aasBep Od pucses ay) ansind Aew sayepipued
yons ‘uacemop} ‘Ayeroeds Joujo Aue ul a6i6eq Od Buinsind Joy DON/diysuosuods
paquel6 aq jou jreys Ayetoods auo ul aai6aq Od pere|dwoo avey ouUM SOGD SUL L'Ob
suon|pucs Bujmojjoy aur Aq pauienob
aq |JeYs esinod uoHeNpesg jSOq puocges e Bulnsind jo snousap sie oym pue 29]|[89
जछ8 OU} APISINO Jo UILYM UOHENPeID 380, ensind 0} paiosuods useq SsAey OUM SOD SUL
a8in0D UOHeNpesg }SOq PUODAS JO} SUIAL “OL
“s]ULUNDOP JAYJO 0५8
puog um Buoye jediourg pauieauos ay} Aq SHC Su} O} JUas Sq Heys Sased YONs JO
yoadsal tl ॥0]8090०]० "7५०१ OLR JO SUUIE) AU} Jad SB JUALULIEADD 8}2}S OL} O} UAE! OL
“sy Aed 0} eazy jreys Aouy ‘Aempiul 8ssnod al) aAeg] OyM Sayep|pUed Walp JO BSI Uy E'6 . a
