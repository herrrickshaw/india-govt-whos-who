---
doc_id: "b8fd9e368bcbda7c"
source_url: "https://www.hptax.gov.in/public/notifications/17848745986a6306666e514.pdf"
ministry: "Excise and Taxation Department, Himachal Pradesh"
title: ":: Order regarding cultivation of cannabis plant- excluding Charas and Ganja in Himachal Pradesh for industrial purpose"
date: ""
pages: 49
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "b1a498dbb5f6ca6f"
---

<!-- page 1 -->

(Authoritative English Text of this Department Order No. EXIN-F-(I0)-8/202I-Vol-l,
Dated222July, 2026 as required under article 348 (3), of the Constitution of India)
Government of Himachal Pradesh
Department of State Taxes and Excise
File No, EXN-F-(I0)-8/202I-Vol-I Shimla-02, the 22 wy, 2026.
ORDER
In exercise of the powers conferred by section |4 of the Narcotics Drugs and
Psychotropic Substances Act, !985/No 6/ of /985), the Governor of Himachal Pradesh
hereby makes the following Order for cultivation of any cannabis plant (excluding Charas &
Ganja) for industrial purposes only i.e. for processing/extraction and product manufacturing,
namely:-
l. Short title, extent and commencement-(l) This Order may be called the Himachal
Pradesh Narcotic Drugs and Psychotropic Substances Order, 2026
(2) This Order shall come into force from the date of its publication in Rajpatra (e-
Gazette), Himachal Pradesh and shall extend to the whole State of Himachal Pradesh,
2. Definitions- () In this order unless the context otherwise requires:-

(a) “Act” means the Narcotic Drugs and Psychotropic Substances Act, ।985;

(b) "Authorized Laboratory" means any State Government laboratory or any
laboratory authorized by the State Government or any other National
Accreditation Board for Testing and Calibration Laboratorics (NABL) Accredited
Laboratory within the State or outside the State, or any State or Centre
Government scientific institute laboratory equipped with State of the Art
instruments in which scientific or technological research experiments and

Cw measurement may be performed to test the potency of seed, dried botanical
— material and other material pertaining to Cannabis plant for industrial purposes.

(c) “Authorized Seed Supplier" means a person or an organization who has been
granted a license in Form CC-S by Collector (Excise) as appended in Himachal
Pradesh Narcotic Drugs and Psychotropic Substances Rules, 989; and

(d) “Agriculturist" means a landowner who cultivates land personally in an estate
situated in Himachal Pradesh in accordance with the Himachal Pradesh Tenancy
and Land Reforms Act, ।972;

I|Page

<!-- page 2 -->

(e) “Agriculture Officer” means Deputy Director Agriculture (DDAY District
Agriculture Officer (DAO) of the District or any officer nominated by the
Department of Agriculture for the purpose of implementation of this order.

(f) “Collector (Excise)” means any officer appointed by the State Government, under
sub-section (2) of section 5 of the Himachal Pradesh Excise Act, 20] |,

(g) “District Nodal Officer” means any officer of the Department of Agriculture
notified by the State Government

(h) “District Excise Officer “means Deputy Commissioner State Taxes and Excise or
District-in-charge, appointed by the Government under section 6 of the Himachal
Pradesh Excise Act, 20I|;

(i) “District Level Review Committee” means the Committee constituted under rule
34-B of Himachal Pradesh Narcotic Drugs and Psychotropic Substances Rules,
989,

(6) “Designated Area” means such secured area wherein the licensee can perform any
one or all of the activities related to cultivation, extraction, processing, product
manufacturing, warehouse, drying/curing/packaging/waste disposal arca ctc. for
industrial use of the Cannabis plants for industrial purposes (excluding Charas &
Ganja).

(k) “dried botanical material” means the Cannabis plant for _ industrial
purposes(excluding Charas & Ganja) or any of its part that has been dried after
harvest:

(0) “dutiable amount” means the sale value of manufactured product from Cannabis
plants for industrial purposes exclusive of any taxes;

(m)"Commissioner of State Taxes and Excise” means the officer appointed by the
State Government under sub-section (|) of section 5 of the Himachal Pradesh
Excise Act, 20I]:

(n) “Excise Officer” means and includes every officer invested with the powers of an
Excise Officer under the Himachal Pradesh Excise Act, 20I|:

(0) “Essential Narcotic Drug” means any narcotic drug notified by the Central
Government for the Medical and Scientific Purposes. which can be used for drug

4) manufacturing;
a
(p) “Form” means the form appended to this order:
2|Page

<!-- page 3 -->

(q) “Green botanical material” means the Cannabis plant for industrial purposes
(excluding Charas & Ganja) or any of its part that has been freshly harvested;

(r) “Indigenous seed” means those cannabis plants for industrial purposes seeds that
are grown/found in Himachal Pradesh and are native to a particular region or
ecosystem of the State. traditionally used and preserved by the local indigenous
communities over generations and those seeds which have adapted naturally to the
local environment, climate, and soil conditions, often embodying the biodiversity
and agricultural heritage of that area;

(s) “license” means a license granted under this order;

(t) “licensed cultivator” means any agriculturist or partnership of agriculturists or
lease holder or Self-help groups or Farmer Producer Organization(FPO) or any
other Association or Society formed for the purpose of management of post-
harvest operation or for meeting the requirement of minimum land holding for
cultivation or agriculture, horticulture university or research institute or any State
Government department which has obtained license in Form CH-2 under this
order for growing cannabis plant for industrial purposes(excluding Charas &
Ganja)for the purpose of sale to the licensed manufacturer in the State of
Himachal Pradesh;

(u) “licensed manufacturer" means any person, company, corporation, public
undertaking, a body corporate, a cooperative society or other society, club, firm,
Hindu Undivided family or other association of person which has obtained a
license in Form CH-M under this order for possession, processing and sale of
Cannabis plant for industrial purposes based products or its derivative for
industrial purposes;

(v) “pass” means a pass granted under this order;

(w) “permit” means a permit granted under this order;

(x) “Rules” means Himachal Pradesh Narcotic Drugs and Psychotropic Substances,
Rules, ।989,

(y) “State Drug Controller” means the authority appointed by the State Government
and “Director Ayush-cum-Licensing Authority” appointed by the State
Government for the purpose of Ayurveda, Yoga, Unani, Sidha and Homoeopathy
systems of medicines as per the Drug and Cosmetics Act, |940 and Rules, | 945;

(z) Schedule-I” means the schedule appended to this order;

(aa) “THC” means Tetrahydrocannabinol;

(bb) “State” means the State of Himachal Pradesh;

ic
a (ce) “State Government” or “Government” mean the Government of Himachal
— Pradesh: and
3] Page

<!-- page 4 -->

(dd) “State Level Committee” means the Committee constituted under rule 34-A of
Himachal Pradesh Narcotic Drugs and Psychotropic Substances Rules, |989,
(2) Words and expressions used in these order but not defined therein shall have the same
meanings as assigned to them in the Act and rules made thereunder.

3. Cultivation of the Cannabis plants for industrial purposes-The cultivation of the
Cannabis plant for industrial purposes shall be subject to the following conditions and
restrictions, namely:-

(l) Procurement of Seeds:

(a) (i) For cultivation of cannabis for medical & scientific purpose or cannabis plant
for industrial purposes, the seeds shall be procured by the licensed cultivator
locally(indigenously) or from the authorized seed suppliers within the State or
from other States subject to the fulfillment of following conditions:-

(ii) In case of seeds imported from other States and the seeds procured within the
State (including local/ indigenous seeds), the Cultivator licensee shall furnish to
the District Nodal Officer of the Department of Agriculture of concerned district,
atleast 2] days prior to the cultivation of those seeds, documents pertaining to the
purchase of the seeds including a certificate of analysis issued by the authorized
seed supplier from the National Accreditation Board for Testing and Calibration
Laboratories(NABL lab) or any other Government authorized lab specifying the
strength and concentration of cannabinoids including type of seed (Cannabis or
Cannabis plant for industrial purposes, Feminized or otherwise), range of
cannabinoid profiles, including variable levels of Tetrahydrocannabinol(THC)
and Cannabidiol(CBD).

(iii) For industrial use of indigenous seed or seed imported from other State
feminized seeds or otherwise or combination of both can be used.

(b) License for authorized seed supplier:- Any person intending to obtain license of
Authorized Seed Supplier for purchase, storage and supply of cannabis or
Cannabis plant for industrial purposes seeds to the licensed cultivator under the
Himachal Pradesh Narcotic Drugs and Psychotropic Substances Rules, |989 shall
apply to the concerned District Nodal Officer in Form CC-S! appended to the

hb , above rules who shall further forward the application alongwith recommendations
ee) to the District Excise Officer who shall further forward the same to the Collector
(Excise) concerned alongwith recommendations. The License shall be granted by

4|Page

<!-- page 5 -->

the Collector (Excise) of the concerned zone for a period of one year in Form CC-
S appended to the Himachal Pradesh Narcotic Drugs and Psychotropic Substances
Rules, 989 on payment of license fee as specified in Schedule- | annexed to the
above rules. The license shall be subject to renewal on payment of renewal fee as
specified under Schedule-I appended to the Himachal Pradesh Narcotic Drugs and
Psychotropic Substances Rules, ।989.

Provided that the Authorized Seed Supplier holding license in Form
CC-S shall not be authorized to sell seeds to licensees other than the licensees
holding license in Form CC-2, CH-2, CC-MC-2, CH-MC-2, CC-R and CH-R
under this order:

Provided further that the Authorized Seed Supplier holding license in
form CC- § shall store in his premises only those seeds in respect of which the
certificate of analysis has been obtained from the Authorized Laboratory, The
Authorized Seed Supplier will ensure that the seeds imported locally or within
State or within Country are clearly classified. segregated and stored separately
based on seed type ie. Industrial or medical or feminized or otherwise ete.
Further, at the time of purchase of seeds, the authorized seed supplier shall
mandatorily issue certificate of analysis pertaining to quality of seeds sold to the
purchaser:

Provided further that the Authorized Seed Supplier shall keep all the
records pertaining to the procurement of seeds and maintain accounts of seeds
received, sold and held in stock from time to time in a register in Form CC-SR-|
and produce them before the Excise Officer and Agriculture Officer on demand.
All the related licenses for authorized seed supplier shall be non-transferrable and
non-saleable. In case of any violation, the provisions of the Narcotic Drugs and
Psychotropic Substances Act, ]985 and the relevant rules framed thereunder shall
apply.

(2) Application for grant of license for cultivation: —
h (a) The area/ areas for cultivation of cannabis for industrial purpose shall be notified
4 by the Agriculture Department. This area shall be restricted to a compact and
geographically contiguous area for better monitoring. Any person intending to
obtain license for cultivation under this Order in the notified areas may apply to
S|Page

<!-- page 6 -->

the concerned District Nodal Officer in Form CH-| for cultivation of cannabis
plant for industrial purposes on payment of License fee as specified in Schedule-I
who shall further forward the application alongwith recommendations to the
District Excise Officer who shall further forward the same to Collector (Excise)
concerned alongwith recommendations. The Collector (Excise) shall, on receipt of
application and recommendations from the District Excise Officer, grant the
license for cultivation of cannabis for industrial purpose in form CH-2 on payment
of such license fee as specified in Schedule-I appended to these rules subject to
the fulfillment of following conditions:-

(i) the landholding proposed for cultivation individually or collectively shall
not be less than three acres in a geographically contiguous area. The limit of
minimum area shall not apply to Government Departments and research
institutes:

(ii) the applicant shall submit a self-certified undertaking confirming the
accuracy of the land measurement and the location of the landholding
proposed for cultivation, In case of any discrepancy, the applicant’s license
shall be cancelled immediately.

(iii) the applicant shall submit copy of the purchase agreement with the
manufacturer alongwith application for cultivator license. This agreement is
required to safeguard the interest of cultivator and to ensure that a buy-back
mechanism shall be in place beforehand so that the crop grown by the
Cultivator mandatorily be purchased by the manufacturer. No stand-alone
license shall be issued to the cultivator. Both the cultivator and manufacture
licensee shall be jointly responsible for their activities/ operations. In case
of any deviation from the terms and condition of the Cannabis rules, license
shall be cancelled alongwith appropriate action as per the NDPS Act 985
and rules thereof.

(iv) the applicant cultivator shall submit the plan of the landholding alongwith
its Global Positioning System (GPS) co-ordinates, Geo Tagging, designated
area for warehouse alongwith the application:

(v) _ the applicant shall have a warehouse in place prior to start of harvest cycle
for storage of the harvest of the cannabis sown under the provisions of these
orders. which satisfies the security measures as specified under these
orders: and

a (vi) the applicant shall furnish a security of the amount in the shape of Fixed
Deposited Receipt(FDR) pledged /Rank Guarantee in favor of District

Excise Officer equivalent to the amount of annual license fee.
6|Page

<!-- page 7 -->

(0) No license for cultivation and harvesting of cannabis plant for industrial purposes
shall be granted unless the applicant satisfies the following conditions: —

(i) (A) if the applicant is an individual or group or association of farmers, he shall
be an agriculturist(s) or a lease holder;

(B) if the applicant is a cooperative society, it should be registered under the
Himachal Pradesh Cooperative Societies Act, ।968; ज्ञात
(C) self-help group shall be of farmers of Himachal Pradesh;

(ii) The applicant should not be convicted of any offence involving moral
turpitude, corruption, bribery, embezzlement, abuse of power or of functions,
trading in influence, or any offence under any statute.

(iii)It should have an on-site or in-house testing facility approved by (National
Accreditation Board for Testing and Calibration Laboratories to test the
potency of the dried botanical material, or should have an arrangement with
any authorized laboratory.

(iv) The Collector (Excise) may, on the recommendations of the District Nodal
Officer and District Excise Officer, grant or refuse a license to the applicant.
In case of refusal to grant license, the Collector (Excise) shall record in writing
the reasons for doing so.

(v) The license shall be granted for a period of one year and can be renewed
subject to the payment of renewal fee as specified in Schedule-I appended to
these orders. This license shall be non-transferable and non-saleable.
However, in the case of demise of license holder, the licensee may be allowed
to be transferred to legal heir.

(vi)In case of any violation, the provisions of the NDPS Act and the relevant rules
framed thereunder shall apply.

(c) Authorized activities. Subject to the other provisions of this order, a holder of a
license for cultivation shall be authorized to conduct all or part of the following
activities under this order.-

(i) Cultivation of Cannabis plant for industrial purposes in open but fenced
area;
(ii) Harvesting;
a . (iii)Storage of produce in licensed warehouse; and
a (iv)Transportation of the produce from the licensed warehouse to the
manufacturing or processing unil, in accordance with the procedure laid
down under this order.
7| Page

<!-- page 8 -->

(d) Appointment of designated Excise Officer and responsible persons in charge:
(i) (A) the District Excise Officer shall designate an Excise Officer not below the

rank of Assistant State Taxes and Excise Officer to oversee the cultivation of

Cannabis plant for industrial purposes as per this order;

(B) The District Nodal Officer shall designate an appropriate officer to
supervise the cultivation of cannabis plant for industrial purposes as per
this order:

(ii) Each licensed cultivator shall provide and furnish to the inspecting authorities
mentioned in (i) (A) & (B) above all requisite transaction records. video and
security camera recordings, logbooks and weights and measurement scales on
request for inspection. The licensed cultivator shall inform the inspecting
authorities about all current and ongoing developments with respect to the
cultivation of Cannabis plant for industrial purposes and it shall be the duty of
the inspecting authorities to conduct regular inspection at least once in 3
months of the licensed area and the warehouse and make reports on the same:
and

(iii)Each licensed cultivator may appoint a responsible person-in-charge to
conduct requisite activities on his behalf. He shall inform the District Excise
Officer about the appointment of such responsible person-in-charge who shall
approve such appointment after conducting necessary enquiry. An identity
card will be issued by the District Excise Officer to responsible person-in-
charge who shall compulsorily carry the identity card during working hours.
Such responsible person-in-charge should not be convicted of any offense
involving moral turpitude. corruption. bribery. embezzlement. abuse of power
or of functions, trading in influence, or any offence under any statute.

(e) Measurement of area under Cannabis plant for industrial purposes
cultivation and harvesting process:- (i) The applicant while applying for
cultivator license shall submit a self-certified undertaking confirming the accuracy
of the land measurement and the location of the landholding proposed for
cultivation. In case of any discrepancy, the applicant’s license shall be cancelled

be immediately and then the action as warranted under the Narcotic Drugs and
= Psychotropic Substances Act, |985 and the rules framed thereunder shall be taken
against the licensed cultivator:

(ii) all measurements shall be carried out in metric units:

(iii) the land details submitted by applicant shall be subject to cross check by
the designated officer mentioned at (d) (i) (A) & (B) above at any time
during the tenure of the license. In case of any discrepancy, suitable action
to be taken as per provisions of NDPS, Act 985 and Rules framed
thereunder. Further, if required, the designated Excise officer may get the

8| Page

<!-- page 9 -->

land measurement verified by the Tehsildar or any other Revenue Officer
duly authorized in this behalf.

(iv) the licensed cultivator shall declare the details of the entire landholding on
which Cannabis plant for industrial purposes has been cultivated by him
within a fortnight after completion of the sowing process;

(v) after cultivation, but prior to harvesting, the licensee shall produce a self-
certified undertaking confirming that he has cultivated the cannabis plant
for industrial purposes in the licensed area only and has a warehouse in
place alongwith relevant security features as defined under this order in the
designated area and furnish the details of same to the concerned Assistant
State Taxes & Excise Officer(ASTEO)/State Taxes & Excise
Officer(STEO) who shall further make a report to the District Excise
Officer ;

(vi) _ if the Assistant State Taxes and Excise Officer finds that the licensed
cultivator has cultivated the cannabis plant for industrial purposes beyond
the licensed area and has violated any of the applicable provisions, then
the Assistant State Taxes and Excise Officer shall forward the case to the
Collector (Excisc)through District In-charge. The Collector (Excise) after
giving a reasonable opportunity of being heard to the applicant and in case
of any violation shall cancel the license immediately and also take action
as per provisions of Narcotics Drugs and Psychotropic Substances, Act,
985 and Rules framed thereunder,

(vii) the licensed cultivator shall not harvest the produce of cannabis plants for
industrial purposes unless information in this regard has been sent to the

4 authorized Agriculture Officer and Excise Officer in writing at least
ae twenty-one days before the harvest is to begin and written orders to that
effect have been obtained from the District Excise Officer; and
(f) Safety measures:-The licensed cultivator shall ensure that the safety and security
measures as provided below are complied with,-

(i) there shall be proper fencing and Geo Tagging from all sides around the
perimeter of the licensed area for cultivation and warehousing to ensure that
there is no un-authorized access to the licensed premises:

9|Page

<!-- page 10 -->

(ii) there shall be single entry or exit point to the licensed premises:

(iii) cultivated area and warehousing area shall be clearly defined and
warehousing shall be under proper revenue locks:

(iv) the licensed cultivator shall maintain a record of the identity of every
individual entering or exiting the licensed cultivation area:

(v) _ the licensed cultivator shall maintain record of any attempted or actual
unauthorized access to the site, which shall invariably contain among other
things.-

(A) the date and time of the occurrence; and
(B) the measures taken in response to it and the date and time when they were
taken; and

(vi) any incidence attempted or actual access shall be reported by the licensed
cultivator to the District Excise Officer within twenty four hours of

. occurrence of the incidence. The report shall include all necessary details of
the incident as may be asked by the District Excise Officer who shall take
action as per the Narcotics Drugs and Psychotropic Substances Act. |985 or
this order.

(vii) install any IT based system, surveillance cameras or CCTYs in the
Cultivation area.

(viii) maintain a record of the identity of every individual entering or exiting the
licensed cultivation area:

(g) Testing of THC in Cannabis plant for industrial purposes: [he licensee shall
inform the concerned District Excise Officer, thirty days prior to the harvesting of
the Cannabis plants for industrial purposes for the analysis of THC who shall
instruct the designated Excise Officer to collect the samples of the crop.

(i) Recommended standard procedure shall be followed for collection of samples.

(ii) The samples shall be sent to the institute approved by the State Government
for the analysis of the THC in Cannabis plant for industrial purposes. The

८ designated Excise Officer shall ensure special procedure for the confidentiality
of the THC testing process.

(iii)The designated Excise Officer shall submit a report in this regard to the
District Excise Officer who shall subsequently issue the permission to the
Licensee to harvest Cannabis plant for industrial purposes, if the maximum
prescribed quantity of THC in the crop is less than or equal to 0.3 percent.

Provided that, if the quantity of THC exceeds the prescribed
limit, the District Excise Officer shall grant permission to the applicant to
30 |? गह €
