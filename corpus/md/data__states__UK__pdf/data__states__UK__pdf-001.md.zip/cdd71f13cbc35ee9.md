---
doc_id: "cdd71f13cbc35ee9"
source_url: "https://gpkashipur.in/wp-content/uploads/2019/08/Leave-Rules.pdf"
ministry: "Government Polytechnic, Kashipur, Udham Singh Nagar, Uttarakhand"
title: "अवकाश के नियम"
date: ""
pages: 17
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "27c04610350f9811"
---

<!-- page 1 -->

vodk'k fu;e
lUnHkZ %&foÙkh; fu;e laxzg [k.M 2 Hkkx 2 ls 4 v/;k; 10 ewy fu;e 58 ls 104
rFkk lgk;d fu;e 35 ls 172 rFkk le; &le; ij tkjh 'kklukns'k
1

vodk'k dk izdkj

2

vkdfLed vodk'k izfrdj
vodk'k

vftZr vodk'k

vf/kdre ns;
l{ke izkf/kdkjh
14

,oa fu;e

eSuqvy
vkQ
xoZUkesaV vkMZj
ds v/;k; 142
lgk;d fu;e
201
dysUMj o"kZ esa 31 fnu ewy
fu;e
rFkk iwjh lsok esa 300
81&[k
¼1½
lgk;d fu;e
157&d¼1½

3

futh dk;Z ij vodk'k

365 fnu¼LFkkbZ lsok ij½ ewy
fu;e
81&¼[k½¼3½
120fnu¼vLFkkbZ
lsok
ij½
lgk;d fu;e
157&d¼3½
365 fnu
ewy
fu;e
81¼[k½¼2½
ewy fu;e 89]90
rFkk 91 dks Hkh
ns[ksa

4

fpfdRlk vodk'k

5

ekr`Ro vodk'k

135 fnu¼iwjh lsok dky ewy fu;e 101]
esa nks ckj½
lgk;d fu;e
153 o 154 nsa[ksa

6

vlk/kkj.k vodk'k

7

gkWfLiVy vodk'k

vf/kdre 5 o"kZ ¼LFkkbZ
lsok ij½ vf/kdre 3
o"kZ¼24 ekl dh fujarj
lsok gksus ,oa vLFkkbZ
lsok ij½
3 o"kZZ dh vof/k esa esa
vf/kdre 6 ekg

8

v/;;u vodk'k

9

fo'ks"k fodykaxrk vodk'k

ewy fu;e 85]
86 rFkk lgk;d
fu;e 157¼d½
¼4½

vH;qfDr
vkdfLed vodk’k ,d
le; ij 10 ls vf/kd
ns; ugha gS rFkk izfrdj
vodk’k ,d ekg esa 2
fnu A
Hkkjr esa ,d le; ij
120 fnu rFkk Hkkjr ls
ckgj ,d le; ij 180
fnu ls vf/kd ughaAewy
fu;e 81&[k¼nl½
lgk;d fu;e
157¼d½¼1½¼X;kjg½
,d le; ij Hkkjr esa
vf/kdre 90 fnu Hkkjr
ls ckgj 180 fnu
,d ckj esa 60 fnu ls
vf/kd ugh
90 fnu rd fpfdRlk
izek.k i= ds vk/kkj ij
rFkk blls vf/kd vof/k
ds fy;s fpfdRlk ifj’kn
dh laLrqfr ds vk/kkj ij
ns;A
nks cPpksa rd lhfer
jgus ijA ,d cPps ds
fodykax @vlk/; jksx
ls ihfMr gksus ij viokn
Lo:i iwjh lsok esa rhu
ckj ns; gSA
;g vodk'k ys[ks ls ugh
?kVk;k
tkrk
gSA
vlk/kkj.k vodk'k dh
vof/k ds fy;s vodk'k
osru ns; ugha gSA
rhu ekg dh vof/k esa
iw.kZ vodk'k osru rFkk
'ks"k vof/k ds fy;s v}Z
osru ns; gSA
v/;;u vodk'k dky esa
v}Z osru ns; gSA

lgk;d fu;e
155
rFkk
lgk;d fu;e
156 Hkh ns[ksa
,d ckj esa 12 ekg iw.kZ ewy fu;e 64
lsok dky esa 2 o"kZ
,oa
lgk;d
fu;e 146¼d½
24 ekg ls vf/kd ns; ewy fu;e 83 o Pkkj eghus iw.kZ vkSlr
ugha
83¼d½
osru rFkk 'ks"k vof/k esa

<!-- page 2 -->

v}Z osru ijA
10 y?kq—r vodk'k

futh dk;Z ij vodk'k
Lohd`r fd;s tkus ;ksX;
tek dqy vodk'k dk
vk/kk vodk'k y?kqd`r
vodk'k ns;
mijksDr vodk’kksa dks dk;kZy;k/;{k@
Lohd`r djus dk vf/kdkj foHkkxk/;{k@iz”kklfud
foHkkx

ewy
fu;e
81&[k¼4½
ewy
fu;e
87&d¼4½
lgk;d fu;e
35 rFkk lgk;d
fu;e 36 esa
of.kZr inkf/kdkjh

vftZr vodk'k ds HkkWafr
vodk'k ij tkus esa ns;
vodk'k osru ns; gksxkA
vjktif=r dkfeZd ds
fy;s lgk;d fu;e 35
rFkk jktif=r vf/kdkjh
ds fy;s lgk;d fu;e
36 ykxw gksxkA

vodk'k ds lEcU/k esa dqN izeq[k ewy fu;e fuEukuqlkj gSa %&
•
vodk'k dsoy M;wVh nsdj gh mikftZr fd;k tkrk gSA bl fu;e ds fy, okg; lsok esa O;rhr dh
x;h vof/k dks M;wVh ekuk tkrk gS] ;fn ,slh vof/k ds fy;s vodk'k osru ds fy, va'knku dk Hkqxrku
dj fn;k x;k gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 59
•
fo'ks"k fodykaxrk vodk'k ds vfrfjDr ewy fu;eksa ds vUrxZr ns; vU; vodk'k 'kklu ds v/khUkLFk
mu izkf/kdkfj;ksa }kjk iznku fd;k tk ldrk gS ftUgsa 'kklu fu;e ;k vkns'k }kjk fufnZ"V dj nsaA fo'ks"k
fodykaxrk vodk'k 'kklu }kjk Loh—r fd;k tk ldrk gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 66
•
vjktif=r ljdkjh lsodksa dks fo'ks"k fodykaxrk vodk'k ds vfrfjDr] ewy fu;eksa ds vUrxZr
vuqeU; dksbZ Hkh vU; vodk'k fu;qfDr izkf/kdkjh }kjk vFkok foÙkh; fu;e laxzg [k.M 2 ds Hkkx 4
¼fooj.k&i= 4 ds Øe la[;k 5] 8 rFkk 9½ esa mfYyf[kr fdlh vU; fuEurj l{ke izkf/kdkjh
¼dk;kZy;k/;{k½ }kjk izfrfufgr vf/kdkj lhek ds v/khu jgrs gq, iznku fd;k tk ldrk gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds lgk;d fu;e 35
•
jktif=r vf/kdkfj;ksa dks vodk'k nsus ds fy, lk/kkj.kr;k 'kklu dh Loh—fr dh vko';drk gS]
fdUrq foÙkh; fu;e laxzg [k.M&2 ds Hkkx 4 ¼fooj.k i= Øe la[;k 6] 7] 8 o 9½ esa mfYyf[kr fdlh
vU; fuEurj l{ke izkf/kdkjh }kjk izfrfufgr vf/kdkj lhek ds v/khu vFkok fdlh ,sls fuEurj vf/kdkjh
}kjk ftls blds fy;s vf/kdkj izfrfufgr fd;k x;k gks] iznku fd;k tk ldrk gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds lgk;d fu;e 36
60 fnu rd dk vodk’k lHkh foHkkxk/;{kksa }kjk vius v/khuLFk jktif=r vf/kdkfj;ksa dks LohÑr fd;k
tk ldrk gS] c’krsZ fd izfrLFkkuh dh vko’;drk u gksA
¼’kklukns’k la[;k&lk&4&944@nl&66&73] fnukad 16&8&73½
•
foHkkxk/;{k vius v/khUkLFk jktif=r vf/kdkfj;ksa dks izkf/kÑr fpfdRld }kjk iznÙk izek.k&i= ds
vk/kkj ij 3 ekg rd dh vof/k rd dk fpfdRlk izke.k i= ij vodk’k iznku dj ldrs gSA
(’kkldh; Kki la[;k lk&4&1752@nl&200(2)&77 fnukad 20&6&1978)
•
izlwfr vodk’k lacaf/kr foHkkxk/;{k }kjk vFkok fdlh ,sls fuEurj vf/kdkjh }kjk ftls blds fy;s
vf/kdkj izfrfufgr fd;k x;k gks] iznku fd;k tk ldrk gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds lgk;d fu;e 153] 154
vodk'k dh ekax dk nkok vf/kdkj ds #i esa ugh %&
•
fdlh vodk'k dk nkok ;k ekax vf/kdkj Lo#i ugha fd;k tk ldrk gSA vodk'k ysus dk nkok ,sls
ugha fd;k tk ldrk gS tSls fd og ,d vf/kdkj gksA tc tu lsokvksa dh vko';drk,a ,slh vis{kk
djrh gksa] rks fdlh Hkh izdkj ds vodk'k dks fujLr djus ;k vLoh—r djus dk vf/kdkj vodk'k iznku
djus gsrq l{ke izkf/kdkjh ds ikl lqj f{kr gS bl lEcU/k esa vodk'k Loh—r djus okyk vf/kdkjh fdlh
vodk'k dks tufgr esa vLoh—r djus ds fy, iw.kZr;k l{ke gksrk gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 67

<!-- page 3 -->

•

vodk'k lk/kkj.kr;k dk;ZHkkj NksMus ls izkjEHk gksrk gS rFkk dk;ZHkkj xzg.k djus dh frfFk ds iwoZ
fnol dks lekIr gksrk gSA vodk'k ds izkjEHk gksus ds Bhd igys o vodk'k lekfIr ds rqjar i'pkr iM+us
okys jfookj o vU; ekU;rk izkIr vodk'kksa dks vodk'k ds lkFk miHkksx djus dh Loh—fr vodk'k Loh—
r djus okys izkf/kdkjh }kjk nh tk ldrh gSA vodk'k dk vkjEHk lkekU;r% ml fnu ls ekuk tkrk gS
ftl fnu lEcfU/kr deZpkjh@vf/kdkjh }kjk vius d{k@ dk;kZy; dk izHkkj gLrkUrfjr fd;k tkrk gSA
blh izdkj vodk'k ls ykSVus ij izHkkj xzg.k djus ds iwoZ ds fnol dks vodk'k lekIr ekuk tkrk gSA

foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 68
•
fcuk izkf/k—r vf/kdkjh dh iwo Z LohÑfr izkIr fd;s dksbZ ljdkjh lso d vodk'k dky esa dksbZ ykHkizn
O;oLkk; ;k uksSdjh ugha dj ldrk gSA fu;er% vodk'k dky esa dksbZ Hkh jktdh; deZpkjh vU;= dksbZ
lsok /kuksiktZu ds mn~ns'; ls ugha dj ldrk tc rd fd bl lEcU/k esa mlds }kjk l{ke vf/kdkjh ls
iwoZ Loh—fr izkIr u dj yh x;h gksA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 69
tu lsok ds fgr esa vodk'kk/khu lsod dks okil cqykus dk vf/kdkj%&
●tu lsok ds fgr esa vodk'k iznku djus okys izkf/kdkjh dks vodk'kk/khu ljdkjh lsod dks vodk'k dk
iw.kZ miHkksx fd;s fcuk M;wVh ij okil cqykus dk vf/kdkj gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 70
vodk'k ls okil cqyk;s tkus ij ;k=k HkÙkk fuEu 'krksZ ds iwj k gksus ij gh ns; gksxk %&
•
;fn og 60 fnu ls vf/kd ds vodk'k ij x;k gks rks de ls de mldh vk/kh vof/k dk vodk'k
fujLr fd;k x;k gksA
•

•

•

•

•
•

;fn og 60 fnu rd ;k mlls de dh vof/k ds fy;s vodk'k ij x;k gks rks ;g de ls de 30
fnu dk vodk'k fujLr djk;k x;k gksA
¼fu;e 51] foÙkh; fu;e laxzg [k.M&3½
fpfdRlk vodk'k dk miHkksx djus ds mijkUr fdlh Hkh deZpkjh dks lsok esa ;ksxnku djus dh
vuqefr rc rd ugha nh tk ldrh tc rd fd mlds }kjk fu/kkZfjr izi= ij viuk LokLFkrk izek.k
i= izLrqr ugha fd;k tkrk gSA
blh izdkj ;fn l{ke vf/kdkjh pkgs rks vLoLFkrk ij fy;s x;s fdlh vU; Js.kh ds vodk'k
ds ekeysa esa Hkh mijksDr LokLFkrk izek.ki= ekax ldrk gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 71
vodk'k LohdRkkZ vf/kdkjh dh iwoZ Loh—fr ds fcuk fdlh Hkh deZpkjh dks Loh—r vodk'k dh lekfIr
ds 14 fnu ls vf/kd le; iwoZ lsok esa okil vkus dh vuqefr ugha nh tk ldrhA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 72
;fn dksbZ jktdh; deZpkjh vodk'k vof/k dh lekfIr ds mijkUr Hkh vuqifLFkr jgrk gS rks mls ,slh
vuqifLFkfr dh vof/k ds fy, dksb Z vodk'k osru ns; ugha gksxk ,oa mDr vof/k v)Z vkSlr osru ij
vodk'k ds #i esa js[kkafdr dh tk;sxh tc rd fd l{ke vf/kdkjh }kjk vodk'k vof/k c<+k u nh
x;h gksA ;fn ckn esa og vuqifLFkfr dh vof/k dk fpfdRlk ize k.k i= izLrqr djrk gS rks bl vof/k
dks fpfdRlk izek.k i= ij ns; vodk'k ls ?kVk fn;k tk;sxk fdUrq dksbZ vodk'k osru Hkqxrku ugha
fd;k tk;sxkA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 73
vodk'kksijkUr tku cw>dj lsok ls vuqifLFkfr nqO;Zgkj dh Js.kh esa vkrh gS ,oa n.Muh; vijk/k gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 15
fdlh ,d izdkj ds vodk'k dks nwljs izdkj ds vodk'k ds lkFk vFkok Øe esa Loh—r fd;k tk
ldrk gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 81&[k¼6½] 83 ¼4½] lgk;d
fu;e&157&d¼5½ rFkk 154

<!-- page 4 -->

vodk'k osru
vftZr vodk'k vFkok fpfdRlk izek.k i= ij vodk'k ij tkus ls Bhd iwoZ vkgfjr osru dh njksa ij
vodk'k osru vuqeU; gksrk gSA vodk'k vof/k esa ns; izfrdj HkÙkksa ds Hkqxrku ds lEcU/k esa ewy fu;e&93
rFkk lgk;d fu;e 147] 149] 150 rFkk 152 esa O;oLFkk nh xbZ gSA tks fo'ks"k osru rFkk izfrdj HkÙks fdlh
dk;Z fo'ks"k dks djus ds dkj.k ns; gksrs gSa] mUgsa vodk'k vof/k esa nsus dk dksbZ vkSfpR; ugha gS ijUrq tks
fo'ks"k osru rFkk HkÙks oS;fDrd ;ksX;rk ds vk/kkj ij ns;s gksrs gSa ¼LukrdksÙkj HkÙkk] ifjokj dY;k.k HkÙkk]
oS;fDrd ;ksX;rk HkÙkk½ vodk'k osru ds lkFk fn;s tkus pkfg;sA fo'ks"k osru rFkk vU; HkÙkksa dk Hkqxrku
vodk'k ds vf/kdre 120 fnu dh lhek rd vuqeU; gksxkA
'kklukns'k la[;k lk&4&871@nl&1999] fnukad 25 ekpZ] 2000
•
vodk'k iznku djus okys izkf/kdkjh dks vodk'k ds izdkj esa ifjorZu djus dk vf/kdkj ugha gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 87 d rFkk lgk;d fu;e 157&d
•
ljdkjh lsod ftUgsa vodk'k iznku ugha fd;k tk ldrk A
1- ljdkjh lsod dks fuyEcu dh vof/k esa vodk'k iznku ugha fd;k tk ldrkA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 55
2- ljdkjh lsod ftls nqjkpj.k vFkok lkekU; v{kerk ds dkj.k lsok ls fudkyk ;k gVk;k tkuk
visf{kr gks] dks vodk'k Loh—r ugha fd;k tkuk pkfg,] ;fn ml vodk'k ds izHkko Lo#i fudkys ;k
gVk;s tkus dh fLFkfr LFkfxr gks tkrh gks ;k ftldks vkpj.k ds dkj.k mlh le; ;k fudV Hkfo";
esa mlds fo#) foHkkxh; tkWp dk fo"k; cukus okyk gksA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds lgk;d fu;e 101
vodk'k izn ku djuk %&
vodk'k izkFkZuk&i=ksa ij fu.kZ; djrs le; l{ke vf/kdkjh fuEu ckrksa dk /;ku j[ksxas %&


deZpkjh ftlds fcuk ml le; ljyrk ls dk;Z pyk;k tk ldrk gS



vU; deZpkfj;ksa ds vodk'k dh vof/k



fiNyh ckj fy;s x;s vodk'k ls okil vkus ds i'pkr lsok dh vof/k



fdlh vkosnd dks iwoZ esa Loh—r vodk'k ls vfuok;Z #i ls okil rks ugha cqyk;k x;k



vkosnd dks iwoZ esa tufgr esa vodk'k vLoh—r rks ugha fd;k x;k
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds lgk;d fu;e 99

<!-- page 5 -->

vkdfLed vodk'k] fo'ks"k vodk'k] izfrdj vodk'k
eSuqvy vkQ xouZesUV vkMZj ds v/;k; 142 esa vkdfLed vodk'k] fo'ks"k vodk'k vkSj izfrdj
vodk'k ls lEcfU/kr fu;e fn;s x;s gSa ftldk fooj.k fuEukuqlkj gS %&
izLrj 1081 %& vkdfLed vodk'k ds nkSj ku dk;Z dk mÙkjnkf;Ro
vkdfLed vodk'k dh vof/k esa ljdkjh lsod lHkh iz;kstuksa ds fy, M~;wVh ij ekuk tkrk gSA
izLrj 1082 %& vkdfLed vodk'k dh lhek
,d dSyas.Mj o"kZ esa lkekU;rk 14 fnu dk vkdfLed vodk'k fn;k tk ldrk gSA
,d le; esa 10 fnu ls vf/kd dk vkdfLed vodk'k fo'ks"k ifjfLFkfr;ksa esa gh fn;k tkuk pkfg,A

vkdfLed vodk'k ds lkFk jfookj ,oa vU; NqfVV;ksa dks lEc) fd;s tkus dh Loh—fr nh tk ldrh
gSA

jfookj] NqfVV;ksa ,oa vU; ljdkjh fnol ;fn vkdfLed vodk'k ds chp esa iM+rs gSa rks mUgsa tksM+k
ugha tk;sxkA

vR;Ur fo'ks"k ifjfLFkfr;ksa esa l{ke vf/kdkjh 14 fnuksa ls vf/kd dk vkdfLed vodk'k ,d dys.Mj
o"kZ esa Loh—r dj ldrk

fo'ks"k vkdfLed vodk'k
fo'ks"k ifjfLFkfr;ksa esa dqN fnu dh fo'ks"k NqVVh nh tk ldrh gSA
 fyfid oxhZ; LVkQ ds vfrfjDr vU; dks nh x;h fo'ks"k NqfV~V;ksa dh lwpuk ldkj.k iz' kkldh;
foHkkx dks Hkstuh gksxhA
 'kk0la0 ch&820@nks&ch&t~ 55] fnukad 27&12&1955 rFkk ,e0th0vks0 dk iSjk 882 o 1087 jk"Vªh;
rFkk vUrjk"Vªh; [ksydwn esa Hkkx ysus ds fy, p;fur f[kykfM+;ksa dks 30 fnu dk fo'ks"k vkdfLed
vodk'k fn;k tk ldrk gSA
 ekU;rk izkIr lsok la?kksa@ifjla?kksa ds v/;{k ,oa lfpo dks ,d dSys.Mj o"kZ esa vf/kdre 07 fnu dk
rFkk dk;Zdkfj.kh ds lnL;ksa dks vf/kdre 04 fnu dk fo'ks"k vkdfLed vodk'k ns; gksxkA
dk;Zdkfj.kh ds mUgha lnL;ksa dks ;g lqfo/kk vuqeU; gksxh tks cSBd ds LFkku ls ckgj ls vk;saA
¼'kklukns'k la[;k % 1694@dk&1@83] fnukad 5&7&83 rFkk 1847@
dk&4&bZ&,d&81&83] fnukad 4&10&83½
izLrj 1083 %& vkdfLed vodk'k ij eq[;ky; NksM+us dh iwoZ vuqefr
 vkdfLed vodk'k ysdj eq[ ;ky; NksM+us dh n'kk esa l{ke vf/kdkjh dh iwo Z Loh—fr vko';d gSA
 vodk'k vof/k esa irk Hkh lwfpr fd;k tkuk pkfg,A
izLrj 1084 %& leqfpr dkj.k
 vkdfLed vodk'k leqfpr dkj.k ds vk/kkj ij gh Loh—r fd;k tkuk pkfg,A
 ljdkjh nkSjs ij jgus dh n'kk esa vkdfLed vodk'k ysus ij ml fnu dk nSfud HkÙkk vuqe U; ugha
gSaA
izLrj 1085 %& l{ke vf/kdkjh
vkdfLed vodk'k dsoy mUgha vf/kdkfj;ksa }kjk Loh—r fd;k tk ldrk gS ftUgsa 'kklukns'kksa ds }kjk
le;&le; ij vf/k—r fd;k x;k gSA
izLrj 1086 %& vkdfLed vodk'k jftLVj
vkdfLed vodk'k Loh—r djus okys l{ke vf/kdkjh }kjk vkdfLed vodk'k rFkk fucZfU/kr vodk'k
dk ys[kk fuEu izk#i ij vfuok;Z #i ls j[kk tk;sxkA bl jftLVj dk ijh{k.k fujh{k.kdrkZ vf/kdkfj;ksa }kjk
le;&le; ij fd;k tk;sxkA



deZpkjh dk
uke
in uke

Loh—r fd;k x;k vkdfLed
vodk'k
14

13

12

11--------

fucZfU/kr vodk'k
2

1

2

1

<!-- page 6 -->

izLrj 1087 %& fo'ks"k vkdfLed vodk'k dh Loh—fr
fuEufyf[kr ekeyksa esa ljdkjh lsodksa dks fo'ks"k vkdfLed vodk'k Loh—r fd;s tkus dh O;oLFkk dh
x;h gS %&
fooj.k
vof/k
1& fo'ofo|ky; lhusV ds lnL;

;k=k lfgr cSBd dh vof/k

2& ifjokj fu;kstu] ulcUnh ¼iq#"k½

6 dk;Z fnol

3& ulcUnh ¼efgyk½

14 dk;Z fnol

4& oSKkfud] vf/kdkfj;ksa dks fdlh
;k=k le; lfgr odZ'kki dh
odZ'kki@lsfeukj esa 'kks/k&i= i<+us gsrq
vof/k
5& ekU;rk izkIr la?kksa egkla?kksa@ifj”knksa ds okf”kZd vf/kos’ku dh 2 fnu
vof/k & vf/kdre 2 fnu “kklukns’k gksus ij
izLrj 1088 %& Hkkjr o"kZ ls ckgj tkus ds fy;s vodk'k
Hkkjr o"kZ ls ckgj tkus ds fy;s vkosfnr fd;s x;s vodk'k ¼vkdfLed vodk'k lfgr½ dh Loh—fr
l{ke vf/kdkjh }kjk 'kklu dh iwokZuqefr ds ugha nh tk;sxhA
izLrj 1089 %& izfrdj vodk'k
•
vjktif=r deZpkjh dks mPprj izkf/kdkjh ds vkns'kksa v/khu NqfVV~;ksa esa vfrfjDr dk;Z dks fuiVkus ds
fy, cqyk;s tkus ij izfrdj vodk'k fn;k tk;sxkA
•
;fn deZpkjh vk/ks fnu dke fd;k gS rks mls nks vk/ks fnu feykdj ,d izfrdj vodk'k fn;k
tk;sxkA
•
vodk'k ds fnu LosPNk ls vkus okys deZpkjh dks ;g lqfo/kk miyC/k ugha gSaA
•
izfrdj vodk'k dk ns; frfFk ls ,d ekg ds vUnj miHkksx dj fy;k tkuk pkfg,A
•
;fn T;knk deZpkfj;ksa dks izfrdj vodk'k fn;k tkuk gS rks ljdkjh dk;Z esa ck/kk u iM+us dh n`f"V
ls l{ke vf/kdkjh }kjk ,d eghus dh 'krZ dks f'kfFky fd;k tk ldrk gSA
•
nks fnu ls vf/kd dk izfrdj vodk'k ,d lkFk ugha fn;k tk;sxkA
•
vkdfLed vodk'k Loh—r djus okyk vf/kdkjh izfrdj vodk'k dh Loh—fr ds fy, l{ke gSA ;g
vodk'k dsoy vjktif=r deZpkfj;ksa dks ns; gSA

<!-- page 7 -->

vftZr vodk'k
¼foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds v/;k;&10 ½
vgZrk%&
●vftZr vodk'k LFkk;h rFkk vLFkk;h nksuksa izdkj ds ljdkjh lsodksa dks ns; gSA
fu;e %&foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 81&[k ¼1½lgk;d fu;e 157&d
¼1½
vodk'k vof/k o vftZr vodk'k dh x.kuk dh izfØ;k %&
izR;sd dySUMj o"kZ ds fy, 31 fnu dk vftZr vodk'k ns; gksrk gSA igyh tuojh dks 16 fnu rFkk igyh
tqykbZ dks 15 fnu tek fd;k tk;sxkA
•
vodk'k dk fglkc yxkrs le; fnu ds fdlh va'k dks fudVre fnu ij iw.kkZafdr fd;k tkrk gS]
rkfd vodk'k dk fglkc iwjs fnu ds vk/kkj ij jgsA
•
fdlh ,d le; tek vodk'k dk vo'ks"k 300 fnu fu/kkZfjr gSA
•
izR;sd iw.kZ dySUMj ekl ds fy, 21/2 fnu izfrekl dh nj ls iwjs ekg ds vk/kkj ij vodk'k ns;
gksrk gSA
•
tc fdlh N%ekgh esa vlk/kkj.k vodk'k dk mi;ksx fd;k tkrk gS rks lacaf/kr ljdkjh lsods ds
vodk'k ys[ks esa vxys N%ekgh ds fy, tek fd;s tkus okyk vodk'k vlk/kkj.k vodk'k dh vof/k ds
1@10 dh nj l 15 fnu dh vf/kdre lhek ds v/khu jgrs gq, ¼iwjs fnu ds vk/kkj ij½ vftZr
vodk'k de dj fn;k tkrk gSA
•
vftZr vodk'k Loh—fr vkns'k esa vfr'ks"k vodk'k bafxr fd;k tk;sxkA
vodk'k ys[kk %&
●vftZr vodk'k ds lEcU/k esa ljdkjh lsodksa ds lsok iqfLrkdk esa vodk'k ys[ks izi=&11 ?k esa j[ks tkrs gSaA
ewy fu;e 81&[k ¼1½ ¼8½
,d le; ij vftZr vodk'k dh vf/kdre lhek %&
•
;fn lEiw.kZ vodk'k Hkkjro"kZ esa O;rhr fd;k tk jgk gks
•
;fn lEiw.kZ vodk'k Hkkjro"kZ ds ckgj O;rhr fd;k tk jgk gks

120 fnu
180 fnu
ewy fu;e 81&[k

vodk'k osru
●vodk'k dky esa ljdkjh lsod dks vodk'k ij izLFkku ds Bhd igys izkIr gksus okys osru ds cjkcj
vodk'k osru xzgk; gksrk gS
ewy fu;e 87&d¼1½ rFkk lgk;d fu;e 157&d ¼6½
vodk’k osru vfxze :i ls ns; %&
'kklukns'k la[;k ,&1&1668@nl&3&1¼4½&65 fnukad 13 vDVwcj] 1978 ds vuqlkj ljdkjh
deZpkfj;ksa dk muds vodk'k ij tkus ds le; vodk'k osru vfxze /kujkf'k Hkqxrku djus dh vuqefr fuEu
'krksaZ ds v/khu nh tk ldrh gSA
●
;g vfxze /kujkf'k de ls de 30 fnu ;k ,d ekl ls vf/kd dh vof/k ds dsoy vftZr vodk'k ;k
futh dk;Z ij vodk'k ds ekeys esa ns; gksxhA

<!-- page 8 -->

•
•
•

•
•

•
•

•

●

;g vfxze /kujkf'k C;kt jfgr gksxhA
vfxze dh /kujkf'k vfUre ckj fy;s x;s ekfld osru] ftlesa eagxkbZ HkÙkk] vfrfjDr eagxkbZ HkÙkk
¼vU; HkÙks NksM+dj½ Hkh lfEefyr gksaxsA
mijksDr izLrj ,d esa mfYyf[kr izdkj dh vof/k ;fn 30 fnu ls vf/kd vkSj 120 fnu ls vf/kd u
gks rks ml n'kk esa Hkh iwjk vodk'k vof/k dk] ysfdu ,d le; esa dsoy ,d ekg dk vodk'k osru
vfxze Loh—r fd;k tk ldrk gSA
vodk'k osru vfxze ls lkekU; dVkSfr;ka dj yh tkuh pkfg,A
;g vfxze /kujkf'k LFkk;h rFkk vLFkk;h ljdkjh deZpkjh dks ns; gksxhA fdUrq vLFkk;h deZpkjh ds
ekeys esa ;g /kujkf'k foÙkh; gLr iqfLrdk [k.M 5 Hkkx 1 ds iSjk 242 esa nh xbZ vfrfjDr 'krksaZ ds
v/khu feysxhA
ftu vf/kdkfj;ksa ds osru iphZ fuxZr djus dk izkfo/kku gS ,sls vf/kdkjh dks Hkh vfxze /kujkf'k ysus
ds fy, izkf/kdkj i= dh vko';drk ugha gksxhA Hkqxrku Loh—fr ds vk/kkj ij fd;k tk;sxkA
foÙkh; gLr iqfLrdk [k.M&5 Hkkx&1 ds iSjk 249¼,½ ds v/khu ljdkjh deZpkfj;ksa ds fy, vfxze
/kujkf'k;ka Loh—r djus ds fy, l{ke vf/kdkjh vodk'k osru dk vfxze Hkh Loh—r dj ldrk gSA
;g izkf/kdkjh vius fy, Hkh ,slh vfxze /kujkf'k Loh—r dj ldrk gSA
bl iwjh vfxze /kujkf'k dk lek;kstu ljdkjh deZpkjh ds vodk'k osru ds izFke fcy ls fd;k
tk;sxkA ;fn iwjh vfxze /kujkf'k dk lek;kstu bl izdkj ugha gks ldrk gS rks 'ks"k /kujkf'k dh
olwyh osru ;k vodk'k osru ls vxys Hkqxrku ds le; dh tk;sxhA
'kklukns'k la[;k lk&4&438@nl&2000&203&86 fnukad 3 tqykbZ] 2000 }kjk 300 fnu rd dk
vftZr vodk'k udnhdj.k foHkkxk/;{kksa }kjk Loh—r fd;k tk ldrk gSA

Lohd`rk izkf/kdkjh
●
;g vodk'k ml izkf/kdkjh ds }kjk iznku fd;k tk ldrk gS ftldk drZO; ml in dks] ;fn og
fjDr gks] Hkjus dk gskrk gSA

<!-- page 9 -->

futh dk;Z ij vodk'k
¼foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds v/;k;&10 ½
vgrkZ %&
LFkkbZ o vLFkkbZ nksuksa izdkj ds ljdkjh lsodks dks ns; gSA futh dk;Z ij vodk'k vftZr
vodk'k dh gh Hkkafr rFkk mlds fy;s fu/kkZfjr izfØ;k ds vuqlkj izR;sd dys.Mj o"kZ ds fy;s 31 fnu 2
N%ekgh fd'rksa esa tek fd;k tkrk gSA fu;qfDr dh izFke Nekgh rFkk lsok ls i`Fkd gksus okyh N%ekgh ds fy;s]
tek gksus ;ksX; vodk'k dk vkx.ku rFkk vlk/kkj.k vodk'k ds mi;ksx djus ij vodk'k dh dVkSrh fo"k;d
izfØ;k Hkh ogh gS] tks vftZr vodk'k ds fo"k; esa gSA
fu;e %&

foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 81&[k¼3½

vf/kdre vodk'k vof/k rFkk ns; vodk'k %&
LFkk;h ljdkjh lsod %
•
;g vodk'k 365 fnu rd dh vf/kdre lhek ds v/khu tek fd;k tkrk gSA
•
lEiw.kZ lsokdky esa dqy feykdj 365 fnu rd dk gh vodk'k Loh—r fd;k tk ldrk gSA
•
fdlh ,d le; esa Loh—r dh tk ldus ;ksX; vf/kdre lhek fuEukuqlkj gSa %&
iwjk vodk'k Hkkjro"kZ esa O;rhr fd;s tkus ij
90 fnu
iwjk vodk'k Hkkjro"kZ ls ckgj O;rhr fd;s tkus ij
180 fnu
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 81 & [k ¼3½
vLFkk;h ljdkjh lsod %
•
vLFkk;h ljdkjh lsodksa ds vodk'k [kkrksa esa futh dk;Z ij vodk'k fdlh volj ij 60
fnu ls vf/kd tek ugha gksxkA
•
vodk'k ys[k esa 60 fnu dk vodk'k tek gks tkus ij vodk'k tek djuk cUn dj fn;k
tkrk gSA vodk'k ysus ds dkj.k vo'ks"k 60 fnu ls de gks tkus ij vodk'k tek gksu k iqu%
izkjEHk gks tkrk gS] tks iqu% 60 fnu dh vf/kdre lhek ds v/khu jgrk gSA
•
vLFkk;h lsodksa dks futh dk;Z ij vodk'k rc rd Lohdk;Z ugha gksr k gS tc rd fd muds
}kjk nks o"kZ dh fujUrj lsok iwjh u dj yh x;h gksA
•
lEiw.kZ vLFkk;h lsokdky esa dqy feykdj 120 fnu rd dk vodk'k iznku fd;k tk ldrk
gSA
•
vodk'k Loh—fr vkns'k esa vfr'ks"k vodk'k bafxr fd;k tk;sxkA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds lgk;d fu;e 157&d¼3½
vodk'k ys[kk %&
●
vftZr vodk'k ds lEcU/k esa ljdkjh lsodksa dh vodk'k ys[ks izi= &11&M esa j[ks tk;saxsA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e &81 [k ¼3½¼nl½
vodk'k osru
●
futh dk;Z ij vodk'k dky esa og vodk'k osru feyrk gS tks vftZr vodk'k
ds fy;s vuqeU; gksus okys vodk'k osru dh /kujkf'k ds vk/ks ds cjkcj gksA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 87 d¼3½ rFkk lgk;d fu;e
157 d ¼6½ ¼x½

<!-- page 10 -->

Lohd`rk izkf/kdkjh
●
;g vodk'k ml izkf/kdkjh ds }kjk iznku fd;k tk ldrk gS ftldk drZO; ml in dks] ;fn og
fjDr gks] Hkjus dk gskrk gSA
fpfdRlk izek.k&i= ij vodk'k
¼foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds v/;k;&10 ½
vgrkZ %&
LFkk;h lsod %
•
lEiw.kZ lsok dky esa 12 ekg rd fpfdRlk izek.k i= ij vodk'k fu;eksa }kjk fufnZ"V
fpfdRldksa }kjk iznku fd;s x;s fpfdRlk izek.k i= ij vodk'k Lohdkj fd;k tk ldrk gSA
•
mijksDr 12 ekg dk vodk'k lekIr gksus ds mijkUr vkiokfnd ekeyksa esa fpfdRlk ifj"kn
dh laLrqfr ij lEiw.kZ lsokdky esa dqy feykdj 6 ekg dk fpfdRlk izek.k i= ij vodk'k
vkSj Lohdkj fd;k tk ldrk gSA
foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds ewy fu;e 81&[k ¼2½
vLFkk;h lsod %
• ,sls vLFkk;h lsodksa dks tks 3 o"kZ vFkok mlls vf/kd le; ls fujUrj dk;Zjr jgs gksa rFkk fu;fer
fu;qfDr vkSj vPNs vkpj.k vkfn “krksZ dks iwjk djrs gksa LFkk;h ljdkjh lsodksa ds gh leku 12 eghus
rd fpfdRlk izek.k i= ij vodk'k dh lqfo/kk gS] ijUrq 12 ekg ds mijkUr LFkk;h lsodksa dks iznku
fd;k tk ldus okyk 6 ekg dk vfrfjDr vodk'k bUgsa vuqeU; ugha gSA
• “ks’k lHkh vLFkk;h lsodksa dks fpfdRlk izek.k i= ds vk/kkj ij lEiw.kZ vLFkk;h lsokdky esa 4 ekg
rd dk vodk'k iznku fd;k tk ldrk gSA
vodk’k osru %&
• LFkk;h lsodksa rFkk rhu o’kksZ ls fujUrj dk;Zjr vLFkk;h lsodks dks 12 ekg rd dh vof/k rFkk 'ks"k
vLFkk;h lsodksa dks 4 ekg rd dh vodk'k vof/k ds fy;s og vodk'k osru vuqeU; gksxk] tks mls
vftZr vodk'k dk miHkksx djus dh n'kk esa vodk'k osru ds #i esa ns; gksrkA
• LFkk;h lsodksa dks 12 ekg dk vodk'k lekIr gksus ds mijkUr ns; vodk'k ds fy;s vftZr vodk'k
dh n'kk esa vuqeU; vodk'k osru dh vk/kh /kujkf'k vodk'k osru ds #i esa vuqeU; gksrh gSA
● izkf/k—r fpfdRlk izkf/kdkjh dh flQkfj'k ij l{ke izkf/kdkjh }kjk lkB fnu rd dh NqVVh Loh—r
dh tk ldrh gSA bl vof/k ls vf/kd NqVVh rc rd Loh—r ugha dh tk ldrh gS tc rd l{ke
izkf/kdkjh dk ;g lek/kku u gks tk; fd vkosfnr NqVVh dh lekfIr ij ljdkjh deZpkjh ds dk;Z ij
okil vkus ;ksX; gks tkus dh leqfpr lEHkkouk gSA
ewy fu;e 87&d¼2½ rFkk lgk;d fu;e 157&d¼6½]lgk;d fu;e 157&d ¼2½
• tgka fdlh ljdkjh deZpkjh dh viuh chekjh ds mipkj ds nkSjku e`R;q gks tkrh gS vkSj ,sls ljdkjh
deZpkjh dks fpfdRlk vodk'k vU;Fkk ns; gks rks NqVVh Loh—r djus ds fy;s l{ke izkf/kdkjh
fpfdRlk vodk'k Loh—r djsxkA
ewy fu;e&81&[k¼2½¼2½]lgk;d fu;e 87
fpfdRlk izek.k i= iznku djus gsrq vf/k—r fpfdRldksa dk fu/kkZj.k
vf/kdkjh@deZpkjh
izkf/k—r fpfdRld
lewg d ds vf/kdkjh
esfMdy dkyst ds iz/kkukpk;Z@jksx ls lacaf/kr foHkkx ds izksQslj
eq[; fpfdRlk vf/kdkjh
jktdh; vLirky ds izeq[k@eq[;@ofj"B v/kh{kd
jktdh; vLirky ds eq[;@ofj"B dUlYVsUV@dUlYVsUV
lewg [k ds vf/kdkjh
esfMdy dkyst ds jksx ls lacaf/kr foHkkx ds izksQslj@jhMj
jktdh; vLirky ds izeq[k@eq[;@ofj"B v/kh{kd
jktdh; vLirky ds eq[;@ofj"B dUlYVsUV@ dUlYVsUV
lewg x o ?k ds deZpkjh
esfMdy dkyst ds jksx ls lacaf/kr foHkkx ds jhMj@ysDpjj

<!-- page 11 -->

jktdh; fpfdRlky;ksa@vkS"k/kky;ksa@lkeqnkf;d LokLF;
dsUnzksa@izkFkfed LokLF; dsUnzkas esa dk;Zjr leLr Js.kh ds
fpfdRlkf/kdkjh
•

vjktif=r ljdkjh deZpkfj;ksa ds fpfdRldh; izek.k i= ij vodk'k ;k vodk'k ds izlkj ds fy,
fn;s x;s vkonsu i= ds lkFk fUkEu izi= ij fdlh ljdkjh fpfdRlkf/kdkjh }kjk fn;k x;k izek.k i=
yxk gksuk pkfg,
lgk;d fu;e 95

vkosnd ds gLrk{kj----------------------------eSa Jh---------------------------------------------ds ekeys dh lko/kkuh ls O;fDrxr ijh{kk djus ij izekf.kr djrk gw¡ dh
Jh--------------------- ftuds gLrk{kj Åij fn;s gq, gSa----------------------------------- ls ihfM+r gSaA jksx ds bl le; orZeku
y{k.k gSa-----------------------------A esjh jk; esa jksx dk dkj.k-------------------------------gSaA
vkt dh frfFk rd fxudj jksx dh vof/k---------------------fnuksa dh gSA tSlk fd Jh------------------------- ls iwNus
ij Kkr gqvk] jksx dk iw.kZ fooj.k fuEufyf[kr gS------------------------------------A eSa le>rk gw¡ fd iw.kZ#i ls LokLF;
ykHk gsrq fnukad--------------------------- ls fnukad--------------------- rd dh vof/k ds fy, budh M;wVh ls vuqifLFkfr
furkUr vko';d gSA

fpfdRlkf/kdkjh
•
Js.kh ?k ds ljdkjh lsodks ds fpfdRlk izek.k i= ds vk/kkj ij vodk'k ;k vodk'k ds izlkj ds
fy, fn;s x;s vkonsu i= ds leFkZu esa vodk'k Loh—r djus okys l{ke izkf/kdkjh ftl izdkj ds izek.k
i= dks i;kZIr le>sa Lohdkj dj ldrs gSaA
lgk;d fu;e 98
•
ml ljdkjh deZpkjh ls ftlus ,f'k;k esa fpfdRldh; ize k.k i= ij vodk'k fy;k gks M;wVh ij
ykSVus ls iwo Z fuEufyf[kr izi= ij LoLFrk ds izek.k i= dks izLrqr djus dh vis{kk dh tk;sxkhA
lgk;d fu;e 43 d

,rn~}kjk izekf.kr fd;k tkrk gS fd geus@eSaus-----------------------------------------------foHkkx ds Jh-------------------------------------------------------------dh lko/kkuh ls ijh{kk dj yh gS vkSj ;g irk yxk gS fd og vc viuh chekjh ls eqDr gks
x;s gSa vkSj ljdkjh lsok esa Mw;Vh ij ykSVus ;ksX; gSaA
ge@eSa ;g Hkh izekf.kr djrs gSa@djrk gw¡ fd mi;qZDr fu.kZ; ij igq¡pus ds iwoZ geus@eSus ewy
fpfdRlh; izek.k i= dk rFkk ekeys ds fooj.k dk vFkok vodk'k Loh—r djus okys vf/kdkjh }kjk mudk
izekf.kr izfrfyfi;ksa dk ftlds vk/kkj ij vodk'k Loh—r fd;k x;k Fkk fujh{k.k dj fy;k gS rFkk vius
fu.kZ; ij igqpus ds iwoZ bu ij fopkj dj fy;k gSA

lgk;d fu;e&43d
•
jktif=r vf/kdkjh dk fpfdRlk izek.k i= vodk'k ;k mlds izlkj ds fy;s lgk;d fu;e 89 esa
mfYyf[kr izi= esa izek.k i= izkIr djuk pkfg,A izkf/k—r fpfdRlkf/kdkjh }kjk fn;k x;k izek.k i=
i;kZIr gksxkA ;fn laLrqr vodk'k dh vof/k rhu ekg ls vuf/kd gks rFkk izkf/k—r fpfdRlkf/kdkjh ;g
izekf.kr dj nsa fd mudh jk; esa izkFkhZ dks fpfdRlk ifj"kn dh le{k mifLFkr gksus dh vko';drk ugha
gSA
•
tc izkf/k—r fpfdRlk vf/kdkjh }kjk iznÙk izek.k i= esa ljdkjh lsod ds fpfdRlk ifj"kn ds le{k
mifLFkr gksus dh laLrqfr dh tk; vFkok laLrqr vodk'k dh vof/k rhu ekg ls vf/kd gks] ;k 3 ekg ;k
mlls de vodk'k dks 3 ekg ls vkxs c<k;k tk;~] rks lacaf/kr jktif=r ljdkjh lsod dks mijksDr
of.kZr izek.k i= izkIr djus ds ckn vius jksx ds fooj.k i= dh nks izfr;ka ysdj fpfdRlk ifj"kn ds
lEeq[k mifLFkr gksuk gksrk gSA
lgk;d fu;e 89 rFkk 90
•
lgk;d fu;e 91 ds uhps fpfdRlk ifj"kn }kjk fpfdRlk izek.k&i= iznku djrs le; mYys[k dj
fn;k tkuk pkfg, fd lacaf/kr vf/kdkjh dks M;qV h ij ykSVus ds fy;s okafNr LoLFkrk izek.k&i= izkIr
djus ds fy, iqu % ifj"kn ds le{k mifLFkr gksuk gS ;k og ml izek.k&i= dks izkf/k—r fpfdRlk
vf/kdkjh ls izkIr dj ldrk gSA

Lohd`rk izkf/kdkjh

<!-- page 12 -->

●

;g vodk'k ml izkf/kdkjh ds }kjk iznku fd;k tk ldrk gS ftldk drZO; ml in dks] ;fn og
fjDr gks] Hkjus dk gskrk gSA

ekr`Ro ¼izlwfr½ vodk'k
¼foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds v/;k;&10 ½
LFkk;h lsod %
vgrkZ %&
izlwfr vodk'k LFkk;h vFkok vLFkk;h efgyk ljdkjh lsodksa ns; gSA
fuEu nks voljksa ij izR;sd ds lEeq[k vafdr vof/k ds fy, fu/kkZfjr 'krkZsa ds v/khu iznku fd;k
tkrk gS%&
¼1½ izlwfr ds ekeyksa esa
•
•
•

izlwrkoLFkk ij vodk'k izkjEHk gksus ds fnukad ls 180 fnu rdA
vfUre ckj Loh—r izlwfr vodk'k ds lekIr gksus ds fnukad ls nks o"kZ O;rhr gks pqds gksa] rHkh nqckjk
izlwfr vodk'k Loh—r fd;k tk ldrk gSA
;fn fdlh efgyk ljdkjh lsod ds nks ;k vf/kd thfor cPps gksa rks mls izlwfr vodk'k Lohdkj
ugha fd;k tk ldrk] Hkys gh mls vodk'k vU;Fkk ns; gksA

¼2½xHkZikr ds ekeyksa esa
xHkZikr ds ekeyksa esa ftlds vUrxZr xHkZLkzko Hkh gS izR;sd volj ij 6 lIrkg rd
vodk'k ds izkFkZuk i= ds leFkZu esa izkf/k—r fpfdRld dk izek.k i= layXu fd;k x;k gks
vc xHkZikr@xHkZlzko ds izdj.kksa esa ekr`Ro vodk'k rhu ls vf/kd ckj Hkh Loh—r fd;k tk ldrk
gSA
•
xHkZikr@xHkZlzko ds izdj.kksa esa vuqeU; ekr`Ro vodk'k ds lEcU/k esa vf/kdre rhu ckj vuqeU; gksus
dk izfrcU/k 'kklu ds i=kad lk&4&84@nl&90&216&79] fnukad 3 ebZ] 1990 }kjk izlkfjr
vf/klwpuk ds }kjk lekIr dj fn;k x;k gSA
ewy fu;e 101] lgk;d fu;e 153 rFkk th&4&394&nl&216&79] fnukad
04 twu] 1999
•
izlwfr vodk'k dks fdlh izdkj ds vodk'k ys[ks ls ugha ?kVk;k tkrk gS rFkk vU; izdkj dh NqV~Vh
ds lkFk feyk;k tk ldrk gSA
lgk;d fu;e 154
vodk'k osru
●izlwfr vodk'k dh vof/k esa vodk'k ij izLFkku djrs le; izkIr M;wVh osru ds cjkcj vodk'k osru
vuqeU; gksrk gSA
lgk;d fu;e 153
Lohd`rk izkf/kdkjh
●
;g vodk'k ml izkf/kdkjh ds }kjk iznku fd;k tk ldrk gS ftldk drZO; ml in dks] ;fn og
fjDr gks] Hkjus dk gskrk gSA
•
•
•

<!-- page 13 -->

vlk/kkj.k vodk'k
¼foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds v/;k;&10 ½
vgrkZ %&
●
;g vodk”k LFkk;h o vLFkkkbZ nksuksa ljdkjh lsodksa dks ns; gSA
●
tc vodk'k fu;eksa ds v/khu dksbZ vU; vodk'k ns; u gks
•
vU; vodk'k ns; gksus ij Hkh lacaf/kr ljdkjh lsod vlk/kkj.k vodk'k izn ku djus ds fy;s vkonsu
djsaA
•
;g vodk'k ys[ks ls ugha ?kVk;k tkrk gSA
ewy fu;e 85
vf/kdre vodk'k vof/k %&
LFkk;h ljdkjh lsod %
•
LFkk;h ljdkjh lsod dks vlk/kkj.k vodk'k fdlh ,d le; esa ewy fu;e 18 ds micU/kksa ds
v/khu vf/kdre 5 o"kZ rd dh vof/k rd ds fy;s Loh—r fd;k tk ldrk gSA
•
fdlh Hkh vU; izdkj ds vodk'k ds Øe esa Loh—r fd;k tk ldrk gSA
ewy fu;e 81 & [k ¼6½
vLFkk;h ljdkjh lsod %
vLFkk;h ljdkj lsod dks ns; vlk/kkj.k vodk'k dh vof/k fdlh ,d le; esa fuEufyf[kr lhekvksa
ls vf/kd u gksxh%&
• rhu ekl
• N% ekl&;fn lacaf/kr ljdkjh lsod us 3 o"kZ dh fujUrj lsok vodk'k vof/k lfgr iwjh dj yh gks
rFkk vodk'k ds leFkZu esa fu;eksa ds v/khu visf{kr fpfdRlk izek.k i= izLrqr fd;k gksA
• vBkjg ekl&;fn lacaf/kr ljdkjh lsods us ,d o"kZ dh fujUrj lsok iwjh dj yh gks] vkSj og {k;
jksx vFkok dq"B jksx dk mipkj djk jgk gks A
• pkSchl ekl&lEiw.kZ vLFkk;h lsok dh vof/k esa 36 ekl dh vf/kdre lhek ds v/khu jgrs gq, tufgr
esa v/;;u djus ds fy;s bl izfrcU/k ds v/khu fd lacaf/kr lsod us 3 o"kZ dh fujUrj lsok iwjh dj
yh gksA
lgk;d fu;e&157&d¼4½
vodk'k osru %&
●vlk/kkj.k vodk'k dh vof/k ds fy;s dksbZ vodk'k osru ns; ugha gSA
ewy fu;e 85]87¼d½¼4½,oa lgk;d fu;e 157d¼6½¼x½
Lohd`rk izkf/kdkjh
●
;g vodk'k ml izkf/kdkjh ds }kjk iznku fd;k tk ldrk gS ftldk drZO; ml in dks] ;fn og
fjDr gks] Hkjus dk gskrk gSA

<!-- page 14 -->

fpfdRlky; vodk'k
¼foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds v/;k;&10 ½
vgrkZ %&
●
●
●

v/khuLFk lsok ds deZpkfj;ksa dks ftudh M;wVh esa nq?kZVuk ;k chekjh dk [krjk gks] vLoLFkrk ds
dkj.k vodk'k iznku fd;k tk ldrk gSA
ewy fu;e 101lgk;d fu;e 155
;g vodk'k mUgha ljdkjh lsodksa dks ns; gS ftudk osru #i;s 1180¼iqjkus osrueku esa½ izfrekg ls
vf/kd u gksA
,sls leLr LFkk;h vFkok vLFkk;h ljdkjh lsodksa] ftUgsa vius drZO;ksa ds dkj.k [krjukd e'khujh]
foLQksVd inkFkZ] tgjhyh xSlksa vFkok vkS"kf/k;ksa vkfn ls dke djuk iM+rk gS vFkok ftUgsa vius
drZO;ksa] ftudk mYys[k lgk;d fu;e 155 ds mi fu;e ¼5½ esa gS] ds dkj.k nq?kZVuk vFkok chekjh
dk fo'ks"k tksf[ke mBkuk iM+rk gS] dks 'kkldh; drZO;ksa ds ifjikyu ds nkSjku nq?kZVuk ;k chekjh ls
xzflr gksus ij fpfdRlky;@vkS"k/kky; esa mipkj gsrq HkrhZ gksus ij vFkok okg; jksxh ds #i esa
fpfdRlk djkus gsrq iznku fd;k tkrk gSA

vodk’k ns;rk %&
●
●

;g vodk'k pkgs ,d ckj esa fy;k tk; vFkok fd'rksa esa fdlh Hkh n'kk esa 3 o"kZ dh dkykof/k esa 6
ekg ls vf/kd Loh—r ugha fd;k tk ldrk gSA
fpfdRlky; vodk'k dks vodk'k ys[ks ls ugha ?kVk;k tkrk gS rFkk bls u gh vU; ns; vodk'k ls
la;ksftr fd;k tk ldrk gS] ijUrq 'krZ ;g gS fd dqy feykdj vodk'k vof/k 28 ekg ls vf/kd
ugha gksxhA
lgk;d fu;e 156

vodk'k osru
●

fpfdRlky; vodk'k vof/k ds igys 3 ekg rd ds fy;s ogh vodk'k osru izkIr gksrk gS tks osru
vodk'k ij izLFkku djus ds rqjUr iwoZ izkIr gks jgk gksA
rhu ekg ls vf/kd dh 'ks"k vof/k ds fy, x;s vodk'k osru mDr nj ds vk/ks ds fglkc ls fn;k
tkrk gSA
lgk;d fu;e 155 rFkk 156

Lohd`rk izkf/kdkjh %&
●
fpfdRlky; vodk'k ml izkf/kdkjh ds }kjk iznku fd;k tk ldrk gS ftldk drZO; ml in dks]
;fn og fjDr gks] Hkjus dk gskrk gSA

<!-- page 15 -->

v/;;u vodk’k
¼foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds v/;k;&10 ½
vgrkZ %&
●tu LokLF; rFkk fpfdRlk] vUos”k.k] i'kqikyu] Ñf"k] f'k{kk] lkoZtfud fuekZ.k rFkk ou foHkkxksa esa dk;Zjr
LFkk;h ljdkjh lsodksa dks tufgr esa fdUgha oSKkfud] izkfof/kd vFkok blh izdkj dh leL;kvksa ds v/;;u
;k fo'ks"k ikB~;Øe dks iwjk djus ds fy, fu/kkZfjr 'krksaZ ds v/khu v/;;u vodk'k LohÑr fd;k tk ldrk
gSA
●
;g vodk'k Hkkjr esa vFkok Hkkjr ds ckgj v/;;u djus ds fy;s Loh—r fd;k tk ldrk gSA ftu
ljdkjh lsodksa us 5 o"kZ ls de lsok dh gks vFkok ftUgsa lsok fuo`fÙk gksus dk fodYi rhu ;k mlls
de le; esa vuqEkU; gks] mudksa v/;;u vodk'k lk/kkj.kr;k iznku ugha fd;k tkrk gSA
●

vlk/kkj.k vodk'k ;k fpfdRlk izek.k i= ij vodk'k dks NksMdj vU; izdkj ds vodk'k dks
v/;;u vodk'k ds lkFk feyk;s tkus dh n'kk esa ldy vodk'k vof/k ds ifj.kke Lo#i lacaf/kr
ljdkjh lsod dh viuh fu;fer M;wVh ls vuqifLFkfr 28 eghus ls vf/kd ugha gksuh pkfg,A

●

,d ckj esa 12 ekg ds vodk'k dks lk/kkj.kr;k mfpr vf/kdre lhek ekuk tkuk pkfg, rFkk dsoy
lk/kkj.k dkj.kksa dks NksM+dj blls vf/kd vodk'k fdlh ,d le; esa ugha fn;k tkuk pkfg,A

●

lEiw.kZ lsok vof/k esa dqy feykdj 2 o"kZ rd dk v/;;u vodk'k iznku fd;k tk ldrk gSA

vodk'k osru
v/;;u vodk'k dky esa v)Z osru xzkg; gksrk gSA
ewy fu;e 84 rFkk lgk;d fu;e 146&d
Lohd`rk izkf/kdkjh %&
●
;g vodk'k ml izkf/kdkjh ds }kjk iznku fd;k tk ldrk gS ftldk drZO; ml in dks] ;fn og
fjDr gks] Hkjus dk gskrk gSA

<!-- page 16 -->

fo'ks"k fodykaxrk vodk'k
¼foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds v/;k;&10 ½
vgrkZ %&
●
“kklu fdlh ,sls LFkk;h vFkok vLFkk;h ljdkjh lsod dks tks fdlh ds }kjk tkucw> dj pksV
igqapkus ds QyLo#i vFkok vius ljdkjh drZO;ksa ds mfpr ikyu esa ;k mlds QyLo#i pksV yx
tkus vFkok viuh vf/kdkjh; fLFkfr ds ifj.kkeLo#i pksV yx tkus ds dkj.k vLFkk;h #i ls
fodykax gks x;k gks] dks fo'ks"k fodykaxrk vodk'k iznku dj ldrs gSA
●

vodk'k rHkh Loh—r fd;k tk ldrk gS tc fd fodykaxrk] mDr ?kVuk ds fnukad ls rhu ekg ds
vUnj izdV gks xbZ gks rFkk lacaf/kr lsod us mldh lwpuk rRijrk ls ;Fkk lEHko 'kh?kz ns nh gksA
ijUrq ‘kklu fodykaxrk ds ckjs esa larq"V gksus dh n'kk esa ?kVuk ds 3 ekg ds i'pkr izdV gqbZ
fodykaxrk ds fy, Hkh vodk'k izn ku dj ldrs gSA

●

fdlh ,d ?kVuk ds fy, ,d ckj ls vf/kd ckj Hkh vodk'k iznku fd;k tk ldrk gSA ;fn
fodykaxrk c<+ tk;s vFkok Hkfo"; esa iqu % oSlh gh ifjfLFkfr;ka izdV gks tk; rks vodk'k ,sls voljksa
ij ,d ls vf/kd ckj Hkh iznku fd;k tk ldrk gSA

●

vodk'k pSfdfRld ifj"kn }kjk fn;s x;s fpfdRlk izek.k i= ds vk/kkj ij iznku fd;k tk ldrk gS
rFkk vodk'k dh vof/k pSfdfRld ifj"kn }kjk dh x;h laLrqfr ij fuHkZj jgrh gS] ijUrq ;g pkSchl
eghus ls vf/kd ugha gksxhA

vodk'k osru
•
•
•

fo'ks"k fodykaxrk vodk'k vof/k ds izFke 6 ekg rd ljdkjh lsod M;wVh ij ekuk tkrk gSA
rRi'pkr vxys pkj eghus iw.kZ osru ij rFkk
'ks"k 14 eghus v)Zosru ij ;g vodk'k vuqeU; gksrk gSA
ewy fu;e 83 rFkk 83&d

vodk’k Lohd`rkf/kdkjh %&
●
egkefge jkT;iky

<!-- page 17 -->

y?kq—r vodk'k
¼foRrh; gLr iqfLrdk [k.M nks Hkkx 2 ls 4 ds v/;k;&10 ½
vgrkZ
●
y?kq—r vodk'k vyx ls dksbZ vodk'k ugha gSA ewy fu;e 84 ds v/khu mPprj oSKkfud ;k
izkfof/kd vgZrk,as izkIr djus ds fy, v/;;u vodk'k ij tkus okys LFkk;h ljdkjh lsodksa ds
fodYi ij mudh futh dk;Z ij vodk'k Loh—r fd;s tkus ;ksX; tek dqy vodk'k dk vk/kk
vodk'k y?kq—r vodk'k ds #i esa Loh—r fd;k tk ldrk gSA
●

ftruh vof/k ds fy;s y?kq—r vodk'k Loh—r fd;k tkrk gS mldh nqxquh vof/k mlds futh dk;Z
ij vodk'k [kkrs esa tek vodk'k esa ls ?kVk nh tkrh gSA

●

fdlh ,d ckj Loh—r fd;s tkus ;ksX; vodk'k dh vf/kdre vof/k futh dk;Z ij vodk'k dh
Loh—fr gsrq fu/kkZfjr vf/kdre vodk'k ds vk/ks ds cjkcj gSA

●

;g vodk”k rHkh Lohd`r fd;k tk;sxk tc LohdrkZ vf/kdkjh dks ;g lek/kku gks tk;s fd vodk”k
lekfIr ij ljdkjh deZpkjh lsok esa okil vk;sxkA

;g vodk”k ,f”k;k esa 45 fnu rFkk ,f”k;k ls ckgj 90 fnu rd ,d ckj esa Lohd`r fd;k tk
ldsxkA
ewy fu;e 81&[k¼4½
vodk’k osru %&
●vftZr vodk”k dh rjg vodk”k ij tkus ls Bhd igys izkIr osru vodk”k osru ds :i esa vuqeU; gSA
ewy fu;e 87&d¼4½
Lohd`rk izkf/kdkjh %&
●
;g vodk'k ml izkf/kdkjh ds }kjk iznku fd;k tk ldrk gS ftldk drZO; ml in dks] ;fn og
fjDr gks] Hkjus dk gskrk gSA
●
