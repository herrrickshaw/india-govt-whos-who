---
doc_id: "ebdc9040ed36bedc"
source_url: "https://cdnbbsr.s3waas.gov.in/s3020bf2c45e7bb322f89a226bd2c5d41b/uploads/2026/06/20260615987985118.pdf"
ministry: "Directorate of Departmental Accounts, Uttarakhand"
title: "Transfer Order Assistant Accountant 2026"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4f84309844519033"
---

<!-- page 1 -->

l/293797 /2026

,/ftoEodo,/Aogonioozsodqro-gto / 2o2 4 - 2 s

Itt{ndq fuil-Iflq tqt, wKrEFrs,

-r

ze-4ffi rtg sro-q-{rf,r. trtr{r t
-,zfroftodo/dor{NrBorzuofruro--eno
q-croa'
/ zozt-zozs k{i6':: I 9-q{, 2026 I
a o z_1e

orqloq-srq /wnqrf,{q oil-t{r

d fuq qrffi-o wtiqffl{ur oIBEqq zotz gi qn-flcl-t{r riEqT
Bit{rtru-s d-f,
gl-{
rq q-44 4 ftRlfrftI, f,sr
to/XXX-z/2018-30 (ls) zorz frqro oo wqft zota

ffi

i fti

wlrq-$rrr qq fti ,,1 ftffi d rq
srffi-o Term[fliq tg

ils{

fi f{ktraq fuilftq A.sT d ftq;Fmhc A'sT q-d.'f d oTffi d

..TEf, qfrft grr qrffio

rerqrfl{uT olfufrqq zor fr qt{t-i3 (.t-ft-r d eftm cq

ffifun dftol d
t Rrmr;il{uT

t

d-{m
{affimqnT) d st$c fr rrfr qEft d eqwn ftftn frlmi/mTqjad
q-dqq
qTq
S cam, olet-rt-3
crl?Fr-2 il oifu--d E-gnf,f,
d wTs
o) sr-d

d q-d-E-oq rA-{

ffi
M
ffi d qeTH, cFt?H 4 q{ Td-dRI i-{rd fuqT orot t'-

d enqrq trt wtt.IT<r{ut

Elr-rr-13 A si-f,.fd

Termr-drur d u-ol-gsq q-ft{

v6r{r6

iFo

go

{6qrc d-{rfr iDr rerFl

qFI

2

3

4

2

J

nttrq fu-6

Rfr-{ gtdl

g*ft

3rrgkr

or em/orqfdq or

iFI

1

1

ffi

tsrox or

5

er5iu d utm
qT qRT

orqidq geq eE BtDrorft,

{lS .raqra

I

t

ergiu d enut

olffi,

6rq1-ds 5c< qE

ftet{rra

fuorssrs 5-rwfi, Eeikrrrd rz-r(u)

ft=omqrs a}dqrc, qtrn-{d

I

qT qI-{I

rz-r(e)
er5tu d emt
q{ Elrtr
sf,rrqu-s {rsfiq difrahf, 3{Mq-{ ftAyn-fq sdtlg-o-s,
rz-r(u)
qrq-{ EEqqFI trqr<c
rrqeTn
t

t

I

"}qdr,

d unm
q{ qI{I
rz-r(e)
r5ttu d unm
qt qrtl

orqi-flq ryr ufto=n w
4

q

b

sqq Q-+x

fd:i gqtt
46*n wx

fulTrrnqeT, e1|5'

tr*r<c

ea-gnu

ffiq f4tTF-I,

fuml.c,-s-s Tqrat, d-e-Isr

I

r

6rqia.q aq fiffis, <f&roft

qqrs fm. tcrdrd

grcq efr

t

erffi, qrqrdf,

rz-r@

|

orsfilq 3lrgsf,, srs fiteTr \'?i ergrtu d entm
s{ rIItT
olM qvns{ s<Nrcru-s,
r z-r (ir)
trrrc.{

6rqtdq E'lTFfrq q-{rffi,
ftrfr qc qqFT, q-{ E6-fr
t

t

7

o

tgr frqo.
silqf

ftrfi.rrqra,

3rpfts

ffiu u-qrqqfqrdT, fraT
fuar vg+tr olqidq, fteikrrd

Ttrn-da

t

E-<Rqrd
o

orqidq fuar tg+ 3lffi,

orqfaq T€q eR 3lffi,

dfud k6

fuonrq-s ffieui, w+r<
3r"fst fir+q fo-onrwrs
drrrrsl, er&sr)

I

rtqrq-d trrr{c

3{TEI|{

IINT

17-1
3ITEIT{

qr{t

t

17-1
3{IEIIT

ft-Onr-g,rg drfrfgl, el-Sgr

t

qTTI

17-',\

t

1

File No. /AOEOdoU tO{OgftozsOdqro-allo / 2o2 4- 2 s (Com puter No. I I 3 I 1 9 )
12/06/2026 06:20 pm
Generated from eoffice by Tarun Badoni, accountantt, ACCOUNTANT, DEPARTMENTAL ACC DIRECTORATE on

<!-- page 2 -->

l/293797 /2026

,/Aoftoeo/do{osrfuozgodqro-eno / zo2 4 - z 5

6qt-t

10

11

12

13

rwo Rrt

{l{fl

d srun

iT-s+tq tf-fttko

{$c. etris{{

oirsT (qF)Es{)t

elr{lI

orqids ftrm q++r orffi, fuar ra*r erfuorft. qI$
"ql{f,

rz-r(u)

ergttq d 3rnlt,{

q{ qrtt
rz-r(e)

r

|

e,l-Etu d omrtr

il<fifr erqifu-{i M,

qEIFT<

riErfl

3rTF{ gth

sdTd, sqq-qm

q{ qr{I
rz-r(u)

I

l-","=-

I

gcq eE 3Tffi, qqr+d

l"**

I

rgtu d emm
qT qI{I

qq \{{tr6, Eerufi

a- tcrdrd

rz-r(s)

t

lOr*
1-sftfrqq t fttrd qcn€r S ei-{-.ff, wlrcTf,Ril oTffi 61 ft-{Rro fo-qr qrm t fu d gs etrtcr d
d qE qtT orfiill
d fin rfi-{
ft,fd Eti of ftfU vo qwr6 d fi-di orfgffi dt q ro
T6ur qt-d Eq 6TdqT( e-qtut-6' go frtena-u ii sqd-el o-qrn gfrRsf, Tt
2-Bq-t-mqeri qerTqTffid orffi d qqq n c-.t-6 wr q{ orBftqq of qm-zz or ci-Jqrdc 5frRaf,
fuqr qrqte1ERrd furTqJ q olqTrrdit or-jiq t fu oIIirT ft,ff, Eti d sro fuc w?q od5f, c-e
eli d sfl d qqfrrd oTff-fr d tcc 6r or{qq c fu-qr qrqt
a- er-gt)u d enw q-i {affirf,frd oTffi o'r rq-amqot qw qdl tq c-S *fl

ffi

H

t

t

t

E0

/-

(rrn not<)

frtcro
qrim q Fcio:-sqt-ffr{s[r
qfrfrrB:
drWqrsi yq oil-dyrfi

ffifuf,

I

olffi tg ifufl-

r. - sfuq, fro, smqrqts crm{, tf,ir{c
2. - qErisrox, sf,{rso-s trtqq

t

t

3. - qqRn fuilrnwT/zFrqfilrweT

I

4. - qqRrd U€q/qRE otwffilt

Digitally signed by

s. - qqRro s6r{rm' AsrmTi of qk.rrd q-xsd

t

Garrga Prasad

Date: 12-06-2026
L7:54:32
(.rfl q-sr<)

s. - q+qRro$6f{f,a-oront

frtero

2
Fi

le No. ./Boaoiozdogo:rfrozgo*sro

-T2no / 2o2 4- ?5 (computer No. I I 3 I I 9 )

Generated from eoffice by Tarun Badoni, accountantt, ACCOUNTANT, DEPARTMENTAL ACC DIRECTORATE on 12/o5/2026 06:20 pm
