---
doc_id: "0ffbd5cecc9a68c4"
source_url: "https://cdnbbsr.s3waas.gov.in/s37e05d6f828574fbc975a896b25bb011e/uploads/2025/11/20251118713643341.pdf"
ministry: "Medical Education Department, Uttarakhand"
title: "Amendment notice for legal consultent"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "ac28d7c350066643"
---

<!-- page 1 -->

OFFICE OF THE PRINCIPAL, GOVERNMENT MEDICAL
COLLEGE, HALDWANI
Date 4/2/2025
संशोधन सूचना
लीगल कन्सलटेन्ट के Empanelment हेतु इस कार्यालय के विज्ञापन
संख्या-426 (दिनांक 07 /44 /2025) जो दिनांक 08/74/20i5 को प्रकाशित हुआ
था, में 5 वर्ष का अनुभव माँगा गया था, जिसमें संशोधन करते हुए 5 वर्ष के स्थान पर
02 वर्ष किया जाता है, शेष शर्तें यथावत रहेंगी। अधिक जानकारी हेतु
website. www.medicaleducation.uk.gov.in में देखें।
५ राजकीय मेडिकल कॉलेज,
हल्द्वानी (नैनीताल)
| ;
| 4
| '
