---
doc_id: "c2c5cfe2cfbde314"
source_url: "https://www.kmvn.in/medias/tender_document/tender1760805179274214311002423671197919_654000373.pdf"
ministry: "Kumaon Mandal Vikas Nigam Ltd., Uttarakhand"
title: ""
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "226db4b8140c0a48"
---

<!-- page 1 -->

List of Important Dates
Published Date/ Document Download / Sale Start Date

: 23-October-2026

Clarification Start Date

: 23-October-2026 15:00 Hrs

Clarification End Date

: 27-October-2026 12:00 Hrs

Pre Bid Meeting Date

: 27-October-2026 13:00 Hrs

RFP Submission Start Date

: 29-October 10:00 Hrs

RFP Submission End Date

: 09-Nov-2026 17:00 Hrs

RFP Opening Date

: 10-Nov-2026 11:00 Hrs

For any query regarding the RFP, bidder may contact Mr. Naveen Kumar,
Company Secretary, KMVN at their contact Number 9718759227

<!-- page 2 -->

<!-- page 3 -->

<!-- page 4 -->

<!-- page 5 -->
