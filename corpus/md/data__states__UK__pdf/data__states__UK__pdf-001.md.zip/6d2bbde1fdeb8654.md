---
doc_id: "6d2bbde1fdeb8654"
source_url: "https://doonuniversity.ac.in/files/upload/docs/20260813163158cd0985dc32.pdf"
ministry: "Doon University, Dehradun"
title: "Notice Regarding National Scholarship Portal (NSP) Scholarship Applications for AY 2026–27 – Revised Guidelines and Verification Process"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0a26bb041cb698a0"
---

<!-- page 1 -->

' Doon University, Dehradun
Scholarship Cell
No JSoIR-DU 12026 Date | ZAueast 2026

Notice
With reference to notice no 271/R-DU 12026 dated 22 July 2026 regatding registration and
applying for various scholarship schemes under National Scholarship Portal (NSP). It is
hereby informed to all the students willing to aaply for scholarship on the National
Scholarship Portal to go through the process for submission/editing and verification steps
mentioned as annexure on the Ministry of Education, Department of Higher Education,
Government of India letter dated 19ft June, 2026 (copy enclosed) before applying on
National Scholarship Portal (NSF) for AY 2026-27.
Enclosed: as above

&

->

(Durgesh Dimri)
Registrar

Copy to1. PA to VC for kind information of Hon'ble Vice-Chancellor.

2. All HoD's/I/c of Schools for wide circulation among students.
3. Incharge, IT Cell for uploading the notice on University website.
4. All notice boards.

w

(Divendu Rawat)

Assistant Registrar

<!-- page 2 -->

rlYnxw-ttf la,_

I -34/2020-NS. 1 1pt.ii)

a

Coi,e rnment of Indirr
N'linistr -1 of IltIuc:r(ion

l)cpartmrnt of ilighcr lidrrcation
Schollrsh ip Ilivisiorr
:i.*:**.::r

West lllock- l, lVin 9-6,
2nd li'loor, R.K. Puraru Scctor-I,
New l)ethi-t tO066
Ilatcd: l9th .Iunc, 2026

s
-l'o,

l. Additional ChielSeoctary/ Ilr. Secretary. Dlo I'ligher h}Jucation o1'all Srate Covrs/
U"l's Adrrri nist ration
'lhe
2.
Sccretarvi'Clrairrrian" z\ll Statc i:iducatior: lJoard

Subject: Regarding Pre paretlness tlf n-ational Scholarship Porr:rl {Ni;P) lbr r\y 2026-27.
Sir/M:rdarn-

As iloLl mili' be s'.vare, Lhis Dtparlr::ent inrplerr:r:n1s tbe PM-tJSl) {leplr.al S.:crlr
-schernc
of
Scholarship
for Collegr and l-irrivcrsity, Str-rdents ircr.()ss lhc nalion. 'l'he schcrnc is r:nboarcieci
1
0r-.,r l(X-on Natianal Scholar:slrip Portal.

bv\

lr

2. Vide OIvl no. D-120l1i0lil0?5-DBT datecl 12,11.10?5 (copy cnclosed). ttrc Cabiner
fi)
Secretariat has decided tl"rnl, in case it student is in rer:eipi of a Wellhre Scholarship bccorte.s
V ,^
l'or a Merit Scholarship" thc later shall not L:c dcrried to hirr a"s also vict:-ve rsa.
1?F\ \elisiLrlc
z\ccordingll,', thc Natioral Scholarship Portal lirndamerital il'ilnrervark ot""One Srudcnr
rfu*4SIS)
''Onc
\''j;*ft{1)nc
*
Scholarship" is hcing mig.rated to
Str-rilcnt lv{Lrttiplc Scholarships-'' fi'o1r tlie Ay
.ril"ftd@6m7. Wlrere, applicant noLtlci bc tligilrle to avail one l\'lerit.-hased scholarship ak:rrg with
*,:'r'r6ffi]r"'|c trVelfare-basecl scltolarships, sub.lcct to eligihilit-r, conditions. Accorrlinl1ly,. severll
nrodiflcatians in the NSP workfiurv ltavt heen made. r.i,hich are enclosr.l ar ArlnexLrrc. Keeping
Iire:^e changes in vier.v. I:reqLrently i\sked Questiorrs (FAQs) have been pr-epared by NIC-NSt:
and nraclc availairlc in pubiic donrain on the NSP Pt"rrtal tbr the conve6ience olstsflrrrrs.

4-

In vierv of abr:ve, )rou are rcqucstcd to sprciici awareness iibout thc change<1 nro<Jaiitv gf'

the National Scholarship Portal h-v- circulating thc sar-ue rvith the Pliucipais 6l' tlre
schoolsiinstitutions, and Registriirs of'the l-iniversitics and by puhlishing the samr on thc
olllcial r+'e hsite of thc rcspe clivc Boardi I-ligl:cr llch-rcation Dcpartnrerrt,i l:idurational
lnstituti<tns.so that all thc stakeliolders, especiall_y cligible stlrdcnts irre arclequatel.r,* inforrncd
about tht: revised scholarship tl-irrrrer.vork and applic,atiou 6:rocess, thcrebr,v tacilirating rviclcr
outreacll. i.iinei-y subrnis;ion.,i'appliraiirns, c;ptin-liil ulili;:aii*n ol,;rh<.:larsl.:ip opplrtLurities,
and snrtlcth implerncntation of Lhc o'One Studcnt - N{uttiple Schnl:rrships" I'rarncryork f'ronr
;\Y 20?6,-l?.
5. Tliis rnay kinrlly be accordcd 'l'op [)rioriry"

fnclosurr: Ala

Rrs-ftry,s,

qJi. t gr-1q.s.ft.fl'./rI,tiE .zat A

ertrq1 fonm: la /p7lzoz {

iF *+t

\S L!\E)
-*-t-+A._

(q

Ht'mI;

Yours laithlllly

Dcput,v Secretar.v to tlre Covenlnlent of India

-*.

tkb#'

D,luj
,==ffi

<!-- page 3 -->

:

.

Attncxure

1. At Application Submission and liditing

a. Application details tlrrristred during initral applicertiotr subr-l'tissiorr rvortld bc relainecl
and reused t'or all sirhsequent applicatiun

b. For sirhmitting subsequent applications. applicar:ts would only be required trr furr-rish
schertre-specific details and Lrpload relevallt docunlenls.

c. [n cases where au application is marked delectivc" applicants would be pemritted to edit

only schemc-specific dctails. For nrodification olgeneral, academic, institute or course
details, all subrnitrcd appiications u,ould trrst hc requircd to be rllithdrawn.

2- At Ll Vcrification:

a. Trrition Fee, Adrrission Fee and o{her non-re fundable fee components updated during
LI verification olthe tirsr application wanki thcr*aller be auto-populated in suLrsequent
applications.

b. During Ll veril'ication, all applications submitted by the applicant along with their
respective stahrs would be visible to the INO.

c. NIC-i\iSP lurther intbrnred that while marking applicalions as "f)efective", d*ficiencies
would bc categorized separately ;rs:

i.
ii.

detrciencies relating lo scheme-speci*'ic details; and
deficiencies relating to generaUacadenric details.

3. At L2 Verilication
a. All applications subn:itted by an applicant, along with thc.ir rcspective stiltus. w*uld '
simultaneously be visible to all cancerned I-2 Nodal Ollluers. l'his w'ould faci]itate
cr:nsistency in decision-making ilcross nrultiple applications sr-rbnritted by the same
appiicant under dit-ferent scht')larsliip categories. For instance, where an ;rpplicant

subnrits one application lrnder a Weliare-bascd schcnre arrd anotlrer utrder a Merit-based
sch$nic,-the coucerned L2 Nodal Othcers fbr hoth schertres rvould havc visibility of the
other application ancJ its status.

b. Il cases where de ficiencies pertain t* general or actdemic details, all otlrer applications
of the applicaut uvould automaticaily be llagged under "Red Flag" category

I
