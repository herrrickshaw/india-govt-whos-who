---
doc_id: "32c4ebecde4a702e"
source_url: "https://doi.uk.gov.in/upload/2960028674.pdf"
ministry: "Directorate of Industries, Uttarakhand"
title: "Notification"
date: ""
pages: 13
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "3d25108defe9270d"
---

<!-- page 1 -->

रजिस्ट्री सं० डी० एल०-33004/99 REGD. NO. D. L.-33004/99
Fara जयते
cht
Tc -_ d -
Che Gazette of Jndia
असाधारण
EXTRAORDINARY
भाग I—avg ॥
PART I—Section I
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY
सं, i6I) नई दिल्‍ली, बुधवार, मई 2, 20:8 Avra 42, 940
No. I6] NEW DELHI, WEDNESDAY, MAY 2, 20i8/VAISAKHA 2, 940
वाणिज्य और उद्योग मंत्रालय
(भौद्योगिक नीति एवं संवर्धन विभाग)
अधिसूचना
नई दिल्ली, 23 अप्रैल, 208
फा. सं. 2(2)/2048-एसपीएस.--भारत सरकार द्वारा औद्योगीकरण को बढ़ावा देने हेतु हिमाचल प्रदेश और
उत्तराखंड राज्यों में औद्योगिक इकाइयों के लिए औद्योगिक विकास स्कीम, 207 की घोषणा की जाती है।
4. स्कीम शीर्षक :- इस स्कीम को हिमाचल प्रदेश (एचपी) और उत्तराखंड हेतु औद्योगिक विकास स्कीम, 207 कहा
जाएगा।
2. Fate: इस स्कीम में हिमाचल प्रदेश और उत्तराखंड राज्यों को कवर किया जाएगा।
3... शुरूआत तथा अवधि:- यह 07.04.2047 से लागू होगी तथा 34.03.2022 तक प्रभावी रहेगी।
4. Wad:

44 जब तक अन्यथा विनिर्दिष्ट नहीं किया जाये, हिमाचल प्रदेश एवं उत्तराखंड राज्यों में अवस्थित जैव-प्रौद्योगिकी तथा
40 मेगावाट तक जल विद्युत उत्पादन इकाइयों सहित विनिर्माण क्षेत्र तथा सेवा क्षेत्र की सभी नयी औद्योगिक
इकाइयां और पर्याप्त विस्तार करने वाली मौजूदा औद्योगिक इकाइयां इस स्कीम के अंतर्गत प्रोत्साहनों हेतु पात्र होंगी।

4.2. यह स्कीम अनुबंध-। में सूचीबद्ध उद्योगों के संबंध में लागू नहीं होगी।

4.3 सभी पात्र औद्योगिक इकाइयां इस स्कीम के एक अथवा अधिक घटकों से लाभ प्राप्त करने की पात्र होंगी, चाहे ऐसी
इकाइयां भारत सरकार की अन्य स्कीमों के अंतर्गत लाभ प्राप्त कर रही हों।

4.4 सेवा क्षेत्र की औद्योगिक ईकाई के लिए संयंत्र और मशीनरी में भवन के निर्माण की लागत और उस विशेष सेवा
उद्योग के प्रचालन हेतु बुनियादी रूप से आवश्यक वास्तविक परिसंपत्तियां शामिल होंगी लेकिन इसमें भूमि और
उपभोज्य, डिस्पोजेबल अथवा राजस्व प्रभार वाली कोई अन्य मद शामिल नहीं होगी।

2465 GI/20I8 re5)

<!-- page 2 -->

2 THE GAZETTE OF INDIA : EXTRAORDINARY [PART I—SEC. |]
4.5. नयी stents इकाइयां तथा व्यापक विस्तार वाली मौजूदा औद्योगिक इकाइयां इस योजना के तहत पात्र होंगी।
एक नई इकाई को निम्नलिखित शर्तों को पूरा करना होगा: -
(क) पहले से मौजूद किसी व्यवसाय के विभाजन अथवा पुनर्गठन से इसका निर्माण न हुआ हो।
(ख) पहले किसी अन्य उद्देश्य के लिए उपयोग में आने वाले संयंत्र या मशीनरी के किसी नई इकाई में हस्तांतरण से
इसका निर्माण न हुआ हो।
(ग) यह अन्यत्र से विस्थापित नहीं की गई हों और/अथवा यह पहले से मौजूद ईकाई नहीं होनी चाहिए जिसे नया
नाम एवं स्टाइल दिया गया हो।
5 परिभाषाएं

(क) “वाणिज्यिक उत्पादन की शुरूआत' से तात्पर्य है वाणिज्यिक पैमाने पर तैयार माल के विनिर्माण की शुरूआत
जिसका पहले परीक्षण उत्पादन हो चुका हो तथा सम्पूर्ण संयंत्र एवं मशीनरी का संस्थापन हो चुका हो तथा उस
दिन संयंत्र वाणिज्यिक मात्रा में उत्पादों के विनिर्माण के लिए हर प्रकार से तैयार हो तथा विनिर्माण हेतु
अपेक्षित समस्त कच्चे माल, उपभोग वस्तुएं आदि उपलब्ध हों तथा यह केंद्रीय उत्पाद शुल्क/वस्तु एवं सेवा कर
(जीएसटी) प्राधिकरणों के पास पंजीकरण की तारीख के अनुसार हों।

(ख) "प्रभावी कदम' से आशय, निम्नलिखित एक अथवा अधिक कदमों से है:-

a. औद्योगिक इकाई के लिए जारी की गई पूंजी का 0 प्रतिशत अथवा इससे अधिक का भुगतान किया
जा चुका हो।

b. फैक्ट्री भवन के किसी हिस्से का निर्माण हो चुका हो।

6. औद्योगिक इकाई के लिए अपेक्षित किसी संयंत्र अथवा मशीनरी के लिए फर्म आर्डर दिया जा चुका हो।

(ग) तैयार माल' का अर्थ है वस्तुतः किसी औद्योगिक इकाई द्वारा उत्पादित वह माल जिसके लिए वह पंजीकृत है।

(घ) “भैद्योगिक इकाई का अर्थ है सरकार द्वारा विभागीय रूप से संचालित इकाई के अलावा कोई औद्योगिक उपक्रम
अथवा पात्र सेवा क्षेत्र इकाई जो कि वस्तु और सेवा कर के तहत एक पंजीकृत व्यापार उद्यम है।

(ऊ) “विनिर्माण कार्य” का अर्थ है 'बह कार्य जो निर्जीव भौतिक वस्तु अथवा मद अथवा चीज में परिवर्तन लाता है (i)
जिसके परिणामस्वरूप वस्तु, मद अथवा चीज का एक नये तथा विशिष्ट वस्तु अथवा मद अथवा चीज में
कायान्तरण होता है जिसका अलग नाम, गुण तथा इस्तेमाल होता है; अथवा (ii) जिससे एक अलग रासायनिक
मिश्रण अथवा भिन्न ढ़ांचे के साथ एक नयी तथा विशिष्ट वस्तु, मद अथवा चीज का निर्माण होता है।'

(च) 'योग्य सेवा क्षेत्र इकाई' सेवा क्षेत्र में एक उद्यम है, जिसमें काफी पूंजी व्यय की आवश्यकता है और इसमें अत्यधिक
रोजगार सूजन क्षमता है।

(छ) “नई औद्योगिक इकाई'का अर्थ है वह औद्योगिक इकाई जिसने 04 अप्रैल, 2047 को अथवा इसके बाद परन्तु 3
मार्च, 2022 से पहले औद्योगिक ईकाई के रूप में डीआईपीपी पोर्टल पर पंजीकरण कराया हो। ऐसी ईकाई को
पंजीकरण से 48 माह के भीतर वाणिज्यिक उत्पादन/प्रचालन शुरू करना होगा।

(ज) 'मौजूदा औद्योगिक इकाई' का मतलब एक औद्योगिक इकाई जिसने 0.04.207 से पहले व्यावसायिक
उत्पादन/प्रचालन शुरू कर दिया है।

(झ) “पर्याप्त विस्तार” का अर्थ है - क्षमता विस्तार/ आधुनिकीकरण तथा परिवर्तन के प्रयोजन के लिए औद्योगिक इकाई
की संयंत्र एवं मशीनरी में स्थिर पूंजी निवेश के मूल्य में कम से कम 25% बढ़ोतरी।

(ज) "भौतिक कार्यशील पूंजी' को फैक्ट्री द्वारा लेखा वर्ष के अंतिम दिवस को अपने स्वामित्व अथवा धारित अथवा
नियंत्रणाधीन समस्त भौतिक माल सूचियों यथा सामग्रियां, ईंधन एवं स्नेहक, भंडारण आदि जिसका इस्तेमाल
स्वयं फैक्ट्री द्वारा विनिर्मित उत्पाद में अथवा प्रसंस्करण हेतु अन्य को फैक्ट्री द्वारा आपूरित उत्पाद में इस्तेमाल
होता है, को शामिल करने के लिए परिभाषित किया गया है। भौतिक कार्यशील पूंजी में सामग्री भंडार, ईंधन एवं
अन्य भंडार आदि, जिसे स्पष्ट तौर पर पुनः बिक्री के लिए खरीदा गया हो, अर्द्धतयार माल तथा अन्‍्यों का

<!-- page 3 -->

[भाग [-खण्ड |] भारत का राजपत्र : असाधारण 3
प्रगति पर कार्य तथा फैक्ट्री द्वारा बनाया गया माल जो लेखा वर्ष के अंत में बिक्री के लिए तैयार हो, शामिल है।
तथापि, इसमें प्रसंस्करण हेतु अन्यों द्वारा फैक्ट्री को आपूरित सामग्री भंडार, ईंधत, भंडार आदि शामिल नहीं है।
फैक्ट्री द्वारा आपूरित कच्चे माल से अन्यों द्वारा प्रसंसाधित तैयार माल तथा उनके द्वारा धारित माल को शामिल
किया गया है तथा अन्यों द्वारा आपूरित कच्चे माल से फैक्ट्री द्वारा प्रसंसाधित तैयार माल को शामिल नहीं
किया गया है।

(ट) “कच्चा माल' का अर्थ है तैयार माल के विनिर्माण में किसी औद्योगिक इकाई द्वारा वस्तुतः अपेक्षित तथा इस्तेमाल
किया गया कच्चा माल जिसके लिए अनुरोध किया गया है।

(5) 'कार्यशील पूंजी' उपर्युक्त पैरा (झ) में यथापरिभाषित भौतिक कार्यशील पूंजी तथा हस्तगत नकदी तथा बैंक में
जमा तथा लेखा वर्ष के अंत में देय राशि पर प्राप्य राशि के निवल शेष की कुल राशि है।
तथापि, अन्य अप्रयुक्त ओवर ड्राफ्ट सुविधा, समयावधि पर ध्यान दिए बिना मियादी जमा, स्थिर परिसम्पत्तियों
के अर्जन के लिए अग्रिमों, ऋणों तथा स्वामियों एवं भागीदारों द्वारा sah प्रयोजन एवं समयावधि पर ध्यान
दिए बिना अग्रिम, ब्याज सहित दीर्धावधि ऋणों तथा निबेशों को कार्यशील पूंजी से बाहर रखा गया है।

(ड) "संयंत्र और मशीनरी' में स्थल पर स्थापित नए खरीदे गए औद्योगिक संयंत्र और मशीनरी शामिल होंगे। अन्यत्र से
विस्थापित/रिसाइकिल/रिफर्बिश्ड संयंत्र और मशीनरी इस स्कीम के तहत सहायता के पात्र नहीं हैं। स्कीम और
किसी विनिर्माण ईकाई में शामिल किए जाने वाले/हटाए जाने वाले घटक अनुबंध - | में दिए गए हैं। मशीनरी
की खरीद सामान्य मूल्य पर खुले बाजार से की जानी चाहिए। यह सुनिश्चित किया जाएगा कि क्‍या यह खरीद
नजदीकी प्राप्य मूल्य प्रक्रिया का अनुसरण किए बिना किसी संबंधित पक्ष से की गई है।

6 पात्र औद्योगिक इकाइयों को निम्नलिखित प्रोत्साहन प्रतिपूर्ति आधार पर उपलब्ध कराए जाएंगे:

4. ऋण प्राप्त करने के लिए केंद्रीय पूंजी निवेश प्रोत्साहत (सीसीआईआईएसी)

2. केंद्रीय व्यापक बीमा राजसहायता (सीसीआईआई)

6.4 एक Soares area afate होगी जिसके अध्यक्ष सचिब, औद्योगिक नीति एबं संवर्धन विभाग होंगे तथा इसमें
व्यय विभाग के afta तथा नीति आयोग के प्रतिनिधि तथा उस उद्योग के मामले से जुड़े भारत सरकार के संबंधित
मंत्रालयों/विभागों तथा राज्य जहां पर इस स्कीम के अंतर्गत लाभार्थियों के चयन हेतु इन्सेटिव का दावा करने वाली लाभार्थी
इकाई अवस्थित है, के संबंधित मुख्य सचिव/सचिव (उद्योग) शामिल होंगे। प्रोत्साहनों के प्रस्तावों की जांच करते समय लागत
पहलू, परियोजना व्यवहार्यता, बैंक योग्यता तथा प्रोत्साहन प्रदाता जोखिम पूंजी जैसे कारकों पर उचित ध्यान दिया जाएगा।
सूक्ष्म, लघु एवं मध्यम उद्यम (एमएसएमई) के अंतर्गत आने वाली पात्र औद्योगिक इकाइयों को प्राथमिकता दी जाएगी।

6.2 ऋण प्राप्त करने के लिए केंद्रीय पूंजी निवेश प्रोत्साहन (सीसीआईआईएसी)

6.2(क) हिमाचल प्रदेश और उत्तराखंड राज्यों में विनिर्माण एवं सेवा क्षेत्र की कहीं पर भी अवस्थित सभी पात्र नयी

औद्योगिक इकाइयों और पर्याप्त विस्तार करने वाली विद्यमान औद्योगिक इकाइयों को ऋण के लिए (सीसीआईआई) 5

करोड़ रूपये की ऊपरी सीमा के साथ संयंत्र एवं मशीनरी में पात्र निवेश के 30% के हिसाब से केंद्रीय पूंजी निवेश

प्रोत्साहन प्रदान किया जाएगा।

6.2 (ख) डीआईपीपी की उच्चाधिकार प्राप्त समिति द्वारा सहायता प्रस्ताव अनुमोदित किए जाने से पहले किसी

अनुसूचित वाणिज्यिक बैंक अथवा वित्तीय संस्था द्वारा परियोजना लागत का मूल्यांकन किया जाना अपेक्षित होगा।

परियोजना रिपोर्ट पर पूंजीगत व्यय और मंजूरी पत्र तैयार होने के संबंध में बैंक के सक्षम प्राधिकारी द्वारा प्रमाणपत्र जारी
करने के आधार पर तथा संयंत्र एवं मशीनरी के काम शुरू करने पर सम्पूर्ण सहायता जारी कर दी जाएगी।

6.2 (ग) सरकार की लागत के बढ़ने की अवस्था में सहायता राशि बढ़ाने की कोई प्रतिबद्धता नहीं है। परियोजना के

समय-पूर्व बंद होने अथवा बीच में ही छोड़े जाने की अवस्था में सरकार द्वारा जारी की गई सम्पूर्ण सहायता को

डीआईपीपी को लौटाना होगा।

<!-- page 4 -->

4 THE GAZETTE OF INDIA : EXTRAORDINARY [PART I—SEC. |]
6.3 केंद्रीय व्यापक बीमा राजसहायता (सीसीआईआई)
6.3 (क) हिमाचल प्रदेश और उत्तराखंड राज्यों में किसी भी स्थान पर अवस्थित सभी पात्र नई औद्योगिक इकाइयां और
पर्याप्त विस्तार करने वाली विद्यमान औद्योगिक इकाइयां वाणिज्यिक उत्पादन शुरू होने की तारीख से 5 वर्ष की
अधिकतम अवधि के लिए भवन परिसरों तथा संयंत्र एवं मशीनरी के बीमा पर 00% बीमा प्रीमियम की प्रतिपूर्ति हेतु
पात्र होंगी।
6.3 (ख) बीमा राजसहायता के प्रयोजनार्थ, औद्योगिक इकाई का अर्थ है कोई उद्योग जो अखिल भारतीय अग्नि प्रशुल्क के
अनुसार अग्नि नीति a में शामिल है। यह नीति प्रस्तावक द्वारा घोषित बाजार मूल्य पर बीमा कंपनी द्वारा जारी की
जाएगी।
7. बनिवार्य अपेक्षा
7. इस स्कीम के अंतर्गत यह अपेक्षित है कि इस स्कीम के अंतर्गत लाभ हेतु पात्रता से पहले सभी पात्र औद्योगिक इकाइयों
को इस स्कीम के अंतर्गत औद्योगिक नीति एवं संवर्धत विभाग, वाणिज्य एवं उद्योग मंत्रालय, भारत सरकार के पोर्टल के
जरिए पूर्ब पंजीकरण कराना होगा। इस संबंध में, एक ऑनलाइन आवेदन प्रक्रिया विकसित की जाएगी जिसके अंतर्गत
आवेदकों को डीपीआर के साथ आवेदन जमा कराने होंगे।
7.2 औद्योगिक नीति एवं संवर्धन विभाग हिमाचल प्रदेश और उत्तराखंड हेतु औद्योगिक विकास स्कीम के लिए ऑनलाइन
पोर्टल के इस्तेमाल हेतु अलग से विस्तृत अनुदेश जारी करेगा।
7.3 पंजीकरण/सिद्धांततः अनुमोदन के संबंध में इस समिति द्वारा निर्णय किया जाएगा जो अन्य बातों के साथ-साथ
औद्योगिक इकाई की प्राथमिक पात्रता, बजट की उपलब्धता पर विचार करेगी तथा इस स्कीम के अंतर्गत पंजीकरण हेतु
पात्रता का निर्णय करेगी। कोई भी औद्योगिक इकाई हिमाचल प्रदेश और उत्तराखंड हेतु औद्योगिक विकास स्कीम के अंतर्गत
पंजीकरण अथवा लाभों का दावा करने का हक नहीं रख सकेगी बशर्ते कि यह केंद्रीय सरकार द्वारा विशेष रूप से अनुमोदित
हो। राजसहायता के भुगतान में बिलम्ब की वजह को लेकर किसी प्रकार के ब्याज का किसी इकाई द्वारा कोई दावा नहीं
किया जा सकता। इस स्कीम के लाभार्थी को इस स्कीम के शर्त तथा निबंधन का अनुपालन करने का एक शपथ-पत्र प्रस्तुत
करता होगा।
7.4 इन इकाइयों को अनुमोदन प्राप्त होने  8 माह की अवधि में वाणिज्यिक उत्पादन शुरू करना होगा।
7.5 जिन ईकाइयों F 07.04.20(7 को अथवा इसके बाद वाणिज्यिक उत्पादन शुरू कर दिया है उन्हें 30,09.2048 तक
डीआईपीपी में पंजीकरण की अनुमति होगी।
8. नोडल एजेंसी
8. हिमाचल प्रदेश राज्य औद्योगिक विकास निगम लिमिटेड (एचपीएसआईडीसी) और उत्तराखंड राज्य औद्योगिक विकास
निगम क्रमशः हिमाचल प्रदेश और उत्तराखंड राज्यों के लिए स्कीम के विभिन्‍न संघटकों के अंतर्गत प्रोत्साहन राशि के
संवितरण हेतु एक नोडल एजेंसी होगी। एचपीएसआईडीसी और एसआईडीसीयूएल पात्र औद्योगिक इकाइयों के नामित बैंक
खातों में केवल ई-ट्रांसफर के जरिए राजसहायता जारी करेगा।
9. दावों की जांच प्रक्रिया
9.4 डीआईपीपी में पूंजीनिवेश प्रोत्साहन के अंतर्गत प्राप्त राजसहायता के दावों की एक पंजीकृत स्वतंत्र लेखा-परीक्षा
एजेंसी द्वारा पूर्व -समीक्षा की जाएगी। एचपीएसआईडीसी और एसआईडीसीयूएल द्वारा हर बार जारी किए गए दावों के
40% की लेखा परीक्षा पश्चात जांच की जाएगी। डीआईपीपी के मुख्य लेखा नियंत्रक, प्रत्येक वित्तीय वर्ष में जारी किए गए
राजसहायता दावों के 20% की लेखा परीक्षा करेंगे।
9.2 सरकार के पास इस स्कीम के किसी भी भाग में जनहित में संशोधन करने का अधिकार सुरक्षित है।
9.3 इन निर्णयों को प्रभावी बनाने के लिए भारत सरकार के सभी संबंधित मंत्रालयों/विभागों द्वारा अपने संबंधित
अधिनियमों/नियमों/अधिसूचनाओं आदि में संशोधन करने तथा आवश्यक अनुदेश जारी करने की अपेक्षा होगी।

<!-- page 5 -->

[भाग [-खण्ड |] भारत का राजपत्र : असाधारण 3
१0. केंद्र/राज्य सरकार/वित्तीय संस्थाओं के अधिकार
0.4 यदि केंद्रीय सरकार/राज्य सरकार/संबंधित वित्तीय संस्था को इस बात की पुष्टि हो कि किसी औद्योगिक इकाई ने
जाली सूचना देकर धोखे से राजसहायता प्राप्त की है, अथवा यदि यह इकाई वाणिज्यिक उत्पादन के शुरू होने के बाद 5 वर्ष
के भीतर उत्पादन बंद कर देती है तो केंद्रीय सरकार/राज्य सरकार/एचपीएसआईडीसी/एसआईडीसीयूएल उस इकाई को
सुनवाई का अवसर प्रदान करने के बाद ऐसी इकाई को अनुदान अथवा राजसहायता लौटाने के लिए कह सकते हैं। यह
राजसहायताएं डिजिटल भुगतान के जरिए जारी की जाएंगी तथा एचपीएसआईडीसी/एसआईडीसीयूएल लाभार्थी
औद्योगिक इकाइयों के संबंध में डीबीटी मिशन द्वारा अपेक्षित सभी सूचना एकत्रित करेगा जो लाभार्थी ईकाई के प्राधिकृत
हस्ताक्षरकर्ता से इस संबंध में एक शपथपत्र ले सकता है। स्कीम की सभी अपेक्षाओं को पूरा करने वाली लाभार्थी ईकाई को
राजसहायता के वितरण से पूर्व औद्योगिक ईकाई और एचपीएसआईडीसी/एसआईडीसीयूएल के बीच एक क्षतिपूर्ति बंध-पत्र
पर भी हस्ताक्षर किए जा सकते हैं।
0.2 दी गई सूचना को जान-बूझ कर छुपाने अथवा तीसरे पक्ष के जरिए धोखा करने अथवा गैर-हिमाचल प्रदेश/उत्तराखंड
उत्पादन के लिए दावे करने अथवा इसी प्रकार के कदाचार करने पर औद्योगिक इकाई के भावी दावे जब्त कर लिए जाएंगे
तथा पूर्व में दी गई सभी राजसहायताओं की वसूली 5% वार्षिक ब्याज की दर के साथ की जाएगी।
40.3 केंद्रीय वाणिज्य एवं उद्योग मंत्रालय (औद्योगिक नीति एवं संवर्धन विभाग)/संबंधित राज्य सरकार/वित्तीय संस्था के
पूर्व अनुमोदन के बिना किसी औद्योगिक इकाई के स्वामी को आंशिक अथवा समग्र राजसहायता प्राप्त करने के बाद किसी
औद्योगिक इकाई के किसी भाग अथवा सम्पूर्ण औद्योगिक इकाई के स्वामित्व को परिवर्तित करने अथवा इकाई के आकार में
बदलाव करने अथवा वाणिज्यिक उत्पादन शुरू करने के बाद 5 वर्ष की अवधि के अंदर इसके कुल तय पूंजी निवेश के बड़े
हिस्से को बेचने की अनुमति नहीं होगी। ईकाई द्वारा स्थल अथवा संपर्क सूत्र में किसी परिवर्तन के संबंध में डीआईपीपी को
सूचित करना भी अपेक्षित है।
40.4 उन सभी इकाइयों को जिनको एचपीएसआईडीसी/एसआईडीसीयूएल द्वारा राजसहायता वितरित की गई है, दिए गए
आशय हेतु सामान्‍य वित्तीय नियम, 2047 % vrs 72 (ग) में राजसहायता के इस्तेमाल का प्रमाण-पत्र औद्योगिक नीति एवं
संवर्धन विभाग को संबंधित वित्तीय संस्था/राज्य सरकार द्वारा अंतिम किश्त/पूर्ण राशि प्राप्त होने की तारीख से तीन माह
की अवधि के अंदर प्रस्तुत करता होगा।
0.5 राजसहायता प्राप्त करने के बाद, प्रत्येक औद्योगिक इकाई को औद्योगिक नीति एवं संवर्धन विभाग/संबंधित राज्य
सरकार को उत्पादन के बाद 5 वर्ष की अवधि के लिए उत्पादन जारी रखने के संबंध में वार्षिक प्रगति रिपोर्ट (एपीआर)
प्रस्तुत करनी होगी।
44. विस्तृत दिशानिर्देश अलग से जारी किए जाएंगे।
डॉ daar कुमार, संयुक्त सचिव
प्रतिलिपि सूचना और आवश्यक कार्रवाई के लिए प्रेषित:
() भारत सरकार के सभी मंत्रालय/विभाग और नीति आयोग
(i) हिमाचल प्रदेश/उत्तराखंड राज्य के मुख्य सचिव।
(ii) हिमाचल प्रदेश/उत्तराखंड राज्य के सचिव (उद्योग)
(५) हिमाचल प्रदेश राज्य औद्योगिक विकास निगम लि. (एचपीएसआईडीसी), शिमला
(५) उत्तराखंड राज्य औद्योगिक विकास निगम (एसआईडीसीयूएल), देहरादून
प्रति प्रेषित:
() मंत्रिमंडल सचिवालय
() प्रधानमंत्री कार्यालय

<!-- page 6 -->

6 THE GAZETTE OF INDIA : EXTRAORDINARY [PART I—SEC. |]
अनुबंध - |
निषेध-सूची

हिमाचल प्रदेश और उत्तराखंड हेतु औद्योगिक विकास स्कीम, 207 के अंतर्गत निम्नलिखित उद्योग लाभों के लिए पात्र नहीं

होंगे;

(i) केंद्रीय उत्पाद प्रशुल्क अधिनियम, 4985 (986 का 5) की प्रथम अनुसूची के अध्याय 24 के अंतर्गत आने वाले
सभी सामान जो तम्बाकू तथा निर्मित तम्बाकू उत्पादों से संबंधित हैं।

(ii) केंद्रीय उत्पाद प्रशुल्क अधिनियम, 7985 (986 का 5) की प्रथम अनुसूची के अध्याय 2 के अंतर्गत आने वाले
पान मसाला

(ii) पर्यावरण एवं बन मंत्रालय की अधिसूचना सं. एस.ओ.705(ई),दिनांक 02,09.999 तथा एस.ओ.698(ई),
दिनांक 7.06.2003 के अंतर्गत विशिष्ट रूप से उल्लिखित के अनुसार 20 माइक्रोत से कम की प्लास्टिक
शैलियां।

(iv) पेट्रोलियम अथवा गैस शोधशालाओं द्वारा उत्पादित केंद्रीय उत्पाद प्रशुल्क अधिनियम,985 (4986 का 5) की
प्रथम अनुसूची के अध्याय 27 के अंतर्गत आने वाला सामान।

(v) पौधरोपण, शोधशालाएं तथा (0 मेगावाट से अधिक विद्युत उत्पादन इकाइयां।

(vi) कोक (कैलसाइन्ड पेट्रोलियम कोक सहित), Fars ऐश, सीमेंट, स्टील रोलिंग मिल।

(४) पर्यावरण संबंधी मानकों का अनुपालन नहीं करने वाली अथवा पर्यावरण एवं वन तथा जलवायु परिवर्तन
मंत्रालय अथवा राज्य पर्यावरणीय प्रभाव मूल्यांकन प्राधिकरण (एसईआईएए) अथवा संबंधित केंद्रीय प्रदूषण
नियंत्रण बोर्ड/राज्य प्रदूषण नियंत्रण बोर्ड से स्थापना तथा प्रचालन हेतु अपेक्षित सहमति नहीं लेने वाली
इकाइयां इस स्कीम के अंतर्गत राजसहायता हेतु पात्र नहीं होंगी।

(vill) उच्च कीमत के पैकेजिंग तथा प्रसंस्करण को छोड़कर भंडारण के दौरान संरक्षण, साफ-सफाई, प्रचालन, पैकिंग,
रि-पैकिंग अथवा रि-लैबलिंग, छंटनी, खुदरा बिक्री मूल्य में परिवर्तत आदि जैसे कम मूल्य संवर्धन कार्यकलापों
की अनुमति होगी।

(x) सरकार द्वारा कभी भी आवश्यक समझे जाने पर एक अलग अधिसूचना के माध्यम से निषेध सूची में शामिल
कोई अन्य उद्योग/कार्य। यह ऐसी अधिसूचना की तारीख से प्रभावी होगा।

(x) गोल्ड और गोल्ड डोर ।

अनुबंध-॥

क. विनिर्माण क्षेत्र में सीसीआईआईएसी के तहत संयंत्र और मशीनरी के मूल्य की गणना हेतु शामिल किए जाने वाले घटक:

() कर और शुल्क सहित औद्योगिक संयंत्र और मशीनरी की लागत अर्थात विनिर्माण गतिविधियों को पूरा करने के लिए
उपयोग किए जाने वाले प्रमुख उत्पादन उपकरण की लागत।

(i) उत्पादक उपकरण जैसे टूल्स, जिग्स, डाई और Ales, इन्श्योरेंस प्रीमियम आदि की कर और शुल्क सहित लागत।

(॥) संयंत्र की ओर जहां मीटर लगाया गया है, से तैयार वस्तुओं के उत्पादत/डिस्पैच वाले स्थान तक संयंत्र के प्रचालन हेतु
आवश्यक इलेक्ट्रिकल घटक (अर्थात एच.टी. मोटर, एल.टी. मोटर, स्विच बोर्ड, पैनल, कैपेसिटर, रिले, सर्किट ब्रेकर,
पैनल बोर्ड, स्विच गियर)।

(iv) आपूर्तिकर्ता के परिसर से इकाई के स्थान तक संयंत्र और मशीनरी तथा उपकरण लाने के लिए भुगतान किया गया
मालभाड़ा।

(५) भुगतान किया गया ट्रांजिट इंश्योरेंस प्रीमियम।

(vi) उस स्थान तक माल को ढोने में निवेश की गई राशि जहां कच्चे माल के परिवहन और तैयार माल के विपणन के लिए
उसका उपयोग किया गया।

<!-- page 7 -->

[भाग ars |] भारत का राजपत्र : असाधारण 7
ख. fatrater aa में सीसीआईआईएसी के तहत संयंत्र और मशीनरी के मूल्य की गणना हेतु निम्नलिखित घटकों को शामिल
नहीं किया जाएगा:
() माल चढ़ाने और उतारने का भाड़ा
(i) संयंत्र और मशीनरी के लिए शेड/भवन
(#) डीजी सेट, उत्खनन/खनत संबंधी उपकरण, हैंडलिंग उपकरण, ऊपर क (iil) में जिनका उल्लेख किया गया है, उन्हें
छोड़कर अन्य इलेक्ट्रिकल घटकों जैसी विविध नियत परिसंपत्तियां
(५) कच्चे माल और अन्य उपभोज्य भण्डारों सहित कार्यशील पूंजी
(५) चालू करने संबंधी लागत
(५) कैपटिव पावर प्लांट
(शो) भण्डारण उपकरण
(शा) वजन तोलने का उपकरण (वे ब्रिज), प्रयोगशाला परीक्षण उपकरण
ग. विनिर्माण क्षेत्र में उत्यापन एवं स्थापना संबंधी प्रभारों की स्वीकार्यता
उत्थापन एवं स्थापना संबंधी प्रभार का भुगतान, वास्तविक आधार पर किया जाएगा और औद्योगिक इकाई को ऋण प्रदान
करने वाले वित्तीय संस्थानों की मूल्यांकन टिप्पणी में निर्धारित लागत तक सीमित होगा।
MINISTRY OF COMMERCE & INDUSTRY
(Department of Industrial Policy & Promotion)
NOTIFICATION
New Delhi, the 23rd April, 20I8
F. No. 2(2)/20I8-SPS.—The Government of India is pleased to announce Industrial
Development Scheme for the States of Himachal Pradesh & Uttarakhand to boost industrialization,
l. Scheme title: - The scheme will be called Industrial Development Scheme for Himachal
Pradesh (HP) & Uttarakhand, 207.
2., Coverage: - The scheme will cover the States of H.P & Uttarakhand.
3. Commencement and duration: - It will be effective from |,04.207 and will remain in force
up to 3.03.2022.
4. Eligibility:
4 Unless otherwise specified, all new industrial units and existing industrial units undertaking
substantial expansion in manufacturing sector and services sector including Bio-technology and
Hydel Power Generation Units upto !0 MW located in the states of H.P. & Uttarakhand will be
eligible for incentives under the scheme.
4.2 The scheme shall not be applicable to the industries listed in the Annexure - I.
4.3. All eligible industrial units will be entitled to benefits under one or more components of this
scheme, even if such units are getting benefits under other schemes of the Government of India.
4.4 Plant and Machinery for the service sector industrial unit shall include cost of construction of
building and all other durable physical assets basic to the running of that particular service industry
but exclude cost of land and consumables, disposables or any other item charged to revenue.
4.5 New industrial units and existing industrial units on substantial expansion shall be eligible
under the scheme. A new unit will be required to fulfil the following conditions:-

<!-- page 8 -->

8 THE GAZETTE OF INDIA : EXTRAORDINARY [PART I—SEc. I]
(a) it is not formed by splitting up, or reconstruction of a business already in existence.
(b) it is not formed by transfer to the new unit of plant or machinery previously used for
any other purpose.
(c) it has not relocated from elsewhere and/or is not an existing unit reopened under a
new name and style.
5 Definitions

(a) Commencement of Commercial Production’ means starting of manufacture of finished
products on commercial scale which is preceded by trial production and installation of
complete plant and machinery and on that day the plant must be ready in all respects for
manufacture of finished products in commercial quantity and all raw materials, consumables,
etc. required for manufacture are available and as per date of registration with Central
Excise/Goods and Services Tax (GST) authorities.

(b) ‘Effective steps’ means one or more of the following steps:-
(i) that 0% or more of the capital issued for the industrial unit has been paid up.
(ii) that any part of the factory building has been constructed,
(iii) that a firm order has been placed for any plant and machinery required for the industrial

unit.

(c) ‘Finished Goods’ means the goods actually produced by an industrial unit and for which it
is registered,

(d) ‘Industrial Unit’ means any industrial undertaking or eligible service sector unit, other than
that run departmentally by Government, which is a registered business enterprise under Goods &
Services Tax.

(e) ‘Manufacturing Activity’ means ‘an activity which brings about a change in non-living
physical object or article or thing (i) resulting in transformation of the object or article or thing into a
new and distinct object or article or thing having a different name, character and use; or (ii) bringing
into existence of a new and distinct object, article or thing with a different chemical composition or
integral structure’.

(f) ‘Eligible Service Sector Unit’ is an enterprise in the services sector that requires significant
capital expenditure and has significant employment generation potential.

(g) ‘New industrial unit’ means an industrial unit which registers itself on DIPP portal on or after
the first day of April, 20I7 but not later than 3I“ day of March, 2022. Such units have to commence
commercial production/ operation within l8 months of registration.

(h) ‘Existing Industrial unit’ means an industrial unit which commences commercial production/
operation before 0).04.207.

@ ‘Substantial expansion’ means increase by not less than 25% in the value of fixed capital
investment in Plant & Machinery of an industrial unit for the purpose of expansion of capacity /
modernization and diversification.

(j) ‘Physical Working Capital’ is defined to include all physical inventories owned, held or
controlled by the factory as on the closing day of the accounting year such as the materials, fuels &
lubricants, stores etc., that enter into products manufactured by the factory itself or supplied by the
factory to other for processing. Physical working capital also includes the stock of materials, fuels &
stores etc., purchased expressly for re-sale, semi-finished goods and work in progress on account of
others and goods made by the factory which are ready for sale at the end of the accounting year.
However, it does not include the stock of the materials, fuels, stores etc. supplied by others to the
factory for processing. Finished goods processed by others from raw materials supplied by the

<!-- page 9 -->

[भाग ars |] भारत का राजपत्र : असाधारण 9
factory and held by them are included and finished goods processed by the factory from raw
materials supplied by others are excluded.

(k) ‘Raw Material’ means any raw materials actually required and used by an industrial unit in
manufacturing of the finished goods for which it is requested.

0) ‘Working Capital’ is the sum total of the physical working capital as defined in Para (j)
above and the cash deposits in hand and at bank and the net balance of amounts receivable over
amounts payable at the end of the accounting year.

Working capital, however, excludes unused overdraft facility, fixed deposits irrespective of
duration, advances for acquisition of fixed assets, loans and advances by proprietors and partners
irrespective of their purpose and duration, long term loans including interest thereon and
investments.

(m) ‘Plant and Machinery’ shall cover the cost of newly purchased industrial plant and
machinery as erected at site. Relocated / Recycled / Refurbished plant and machinery is not eligible
for assistance under the Scheme. Components to be included / excluded for the purpose of scheme
and for a manufacturing unit is at Annexure II. The purchase of machinery should be from open
market at normal market price. It will be ascertained whether the purchase has been made from a
Related Party without following an arms-length price discovery.
6. The following incentives will be provided to eligible industrial units on reimbursement basis:
l, Central Capital Investment Incentive for access to credit (CCIIAC)
2. Central Comprehensive Insurance Incentive (CCII)
6. There will be an Empowered Committee chaired by Secretary, Department of Industrial
Policy and Promotion with Secretaries of D/o Expenditure, representative of NITI Aayog and
Secretary of the concerned Ministries/Departments of Government of India dealing with the subject
matter of that industry as its members as also the concerned Chief Secretary/Secretary (Industry) of
the State where the beneficiary unit claiming incentive is located for selection of beneficiaries under
the scheme, While examining the proposals for incentive, due consideration will be given to factors
like cost disadvantage, project viability, bankability, employment generation and promoters’ risk
capital. Preference will also be given to eligible industrial units under the Micro, Small and Medium
Enterprises (MSME).
6.2 Central Capital Investment Incentive for access to credit (CCIHAC)
6.2(a) All eligible new industrial units and existing industrial units on their substantial expansion in
the manufacturing and service sector located anywhere in the States of H.P. and Uttarakhand will be
provided Central Capital Investment Incentive for access to credit (CCHAC) @ 30% of the
investment in plant and machinery with an upper limit of Rs.5.00 crore.
6.2(b) The project cost will need to be appraised by a Scheduled Commercial Bank or Financial
Institution before the proposal of assistance is approved by the Empowered Committee of DIPP.
Full assistance will be released on the basis of certificate issued by Competent Authority of the bank
that the capex on the project report and sanction thereof is in place and Plant & Machinery has been
put to use.
6.2(c) The government does not commit itself to increase in the scale of assistance in case of cost
escalation. In case the project is foreclosed or abandoned midway the entire assistance released by
government will be refunded to DIPP.
6.3 Central Comprehensive Insurance Incentive (CCI)
6.3(a) All eligible new industrial units and existing industrial units on their substantial expansion
located anywhere in the states of H.P & Uttarakhand will be eligible for reimbursement of l00%
insurance premium on insurance of building and Plant & Machinery for a maximum period of 5
years from the date of commencement of commercial production/ operation.

<!-- page 10 -->

0 THE GAZETTE OF INDIA : EXTRAORDINARY [PART I—SEc. I]
6.3(b) For the purpose of insurance incentive, ‘industrial unit’ shall mean any industry which is
included in Fire Policy ‘C’ as per All India Fire Tariffs. The policy shall be issued by the Insurance
Company on market valuation to be declared by the proposer.

Ts Mandatory requirement

के This Scheme requires that all eligible industrial units would have to register under the Scheme
with Department of Industrial Policy and Promotion, Ministry of Commerce and Industry, Govt. of
India, through the DIPP portal prior to being eligible for any benefit under this scheme. In this
regard, an online application process shall be developed under which the applicants have to submit
applications along with the DPR.

7.2. The Department of Industrial Policy and Promotion would separately issue detailed
instructions for the use of online portal for Industrial Development Scheme for H.P & Uttarakhand
and registration of eligible units.

79 The final grant of registration/in-principle approval will be decided by the Committee, which
will, inter-alia, consider the prima-facie eligibility of the industrial unit, availability of budget and
decide the eligibility for registration under the Scheme. No Industrial unit will have the right to
register under Industrial Development Scheme for H.P & Uttarakhand or claim the benefits unless it
is specifically approved by the Central Government. No interest on account of delay in payment of
incentive can be claimed by the unit. The beneficiary of this scheme has to furnish an undertaking to
abide by the terms and conditions of the scheme.

7.4 The units should start commercial production within ]8 months of approval.

TS Units which have commenced production on or after .4.20I7 will be allowed to register with
DIPP upto 30.9.208.

8. Nodal agency

8.I The Himachal Pradesh State Industrial Development Corporation Ltd.(HPSIDC) and State
Industrial Development Corporation of Uttarakhand (SIDCUL) will be the nodal agencies for
disbursal of incentives under various components of the Scheme for the States of H.P & Uttarakhand
respectively. HPSIDC and SIDCUL will release incentive only through e-transfer to designated bank
accounts of the eligible industrial units.

9. Process of Scrutiny of claims

9.4 Incentive claims under Capital Investment Incentive received in DIPP will be pre-scrutinized
by a recognized independent audit agency. HPSIDC and SIDCUL will conduct post-audit of 0% of
claims released every time. The Chief Controller of Accounts of DIPP will also conduct post-audit
of 20% of incentive claims released in each financial year.

9.2 Government reserves the right to modify any part of the Scheme in public interest.

9.3. All concerned Ministries/Department of Government of India are required to amend their
respective Acts/ Rules/ Notification etc. and issue necessary instructions for giving effect to these
decisions.

l0. —_ Rights of the Centre/State Government/Financial Institutions

0.. If the Central Government/State Government/Financial Institution concerned is satisfied that
an industrial unit has obtained incentive(s) by misrepresenting an essential fact, furnishing of false
