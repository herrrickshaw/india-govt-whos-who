---
doc_id: "abb858caf72bbf63"
source_url: "https://cdnbbsr.s3waas.gov.in/s33cf2559725a9fdfa602ec8c887440f32/uploads/2025/03/202503111811998990.pdf"
ministry: "Directorate of Training & Employment, Uttarakhand"
title: "M.C.C. Guidelines (727 KB)"
date: ""
pages: 28
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "1f4603d90c3be166"
---

<!-- page 1 -->

Guidelines for
establishment of
Model Career Centres
Date: - 16th March, 2022

The document details out the objective, services and success parameters for establishment
of Career Centres.

<!-- page 2 -->

CONTENTS

S. No

Title

Page No.

1

INTRODUCTION

3

2

OBJECTIVES

3

3

SERVICES TO BE OFFERED THROUGH MODEL
CAREER CENTRE

4

4

ROLE OF GOVERNMENT OF INDIA IN ESTABLISHING
THE MODEL CAREER CENTRE

4-7

5

ROLE OF STATE GOVERNMENT IN ESTABLISHING
THE MODEL CAREER CENTRE

7-9

6

REVIEW AND MONITORING MECHANISM

9-10

7

SUBMISSION OF PROPOSALS

10-11

ANNEXURE A MODEL CAREER CENTRES - SCHEME DETAILS

12-19

ANNEXURE B

PROJECT PROPOSAL

20-24

ANNEXURE C

ACTIVITIES ADMISSIBLE/NOT-ADMISSIBLE FOR
FUNDING FOR ESTABLISHMENT OF MCCS

25

ANNEXURE D

ADDITIONAL GUIDELINES FOR PROPOSALS FROM
INSTITUTIONS OTHER THAN CENTRAL/STATE/UT
GOVERNMENTS

26-27

ANNEXURE E

INDICATIVE ITEM LIST

28

2

<!-- page 3 -->

1. INTRODUCTION
The Directorate General of Employment (DGE), Ministry of Labour and Employment
(MOLE) is implementing the National Career Service (NCS) Project which aims to
provide variety of employment related services. The NCS project include
establishment of Model Career Centres (MCCs) to modernise the Employment related
services.
These guidelines focusses on establishment of MCCs in a phased approach ensuring
that standardized set of services are available all across the country.
So far, 207 MCCs have been approved (including 7 non-funded) under the NCS
project. It is proposed to establish 200 more MCCs primarily in State/UT
Employment Exchanges, Education & Training Institutions, Rural and Semi-urban
centres (KSK, PRI, CSC etc.), Corporate setups, etc. States/UTs interested to set up
such MCCs will be expected to replicate services offered in these centres to other
Employment Exchanges.

2. OBJECTIVES
The MCCs are expected to connect local youth and other job seekers with all
possible/available job opportunities in the vicinity. The MCCs would be undertaking
outreach and counselling activities for the aspiring jobseekers. The Central
Government will provide grant-in-aid upto Rs. 60 lakh for establishment of each new
MCCs.
These MCCs would be provided with appropriate infrastructure for:
a)

Effectively and continuously assessing demand of skills in labour markets;

b)
Guiding youth visiting the MCCs, outreach to schools/ colleges, various
training institutions, on-the-job training, job opportunities, etc., according to their
aptitude and potential;
c)
Connecting youth and other job seekers with jobs through portal, job fairs and
other possible interface with employees such as campus placements.
d)
Mobilizing employers and other placement agencies to connect to NCS for
meeting their HR requirements
e)

Organize at least one job fair in a month and one mega job fair in a year.

f)

Any other functions as may be entrusted by the Central Government.

3

<!-- page 4 -->

3. SERVICES TO BE OFFERED THROUGH MODEL CAREER CENTRE
The activities to be performed by Model Career Centres can be categorized as follows:
3.1 Coverage - Catchment Area: Each Model Career Centre would cater to a
catchment area comprising around 3-4 adjacent districts covering an area of
approximately 100 sq. kms to map out the availability of institutions, industry,
demographics etc. and post the details on the NCS portal for general access.
3.2 Demand side - Industry Interaction: MCCs will undertake market sizing exercise
to estimate the number of employment opportunities in their area, associated skill
requirements, skill training capacity availability etc. This will require close and
constant interface with local industry and employers.
3.3 Supply side - Candidate Engagement: On the supply side, MCCs will provide
counselling services to the job seekers and make them aware of opportunities based
on their skills, area of interest and requirement. MCCs will thus provide a range of
employment related services like career counselling, job matching, employment
market analytics and other value added services.
3.4 Job and Skill Mapping - Model Career Centre will undertake the job skill
mapping for identification of right fit job for candidate.
3.5 Information, Education and Communication (IEC) activities - The MCCs will
increase awareness amongst the various stakeholders like skill training institutes,
assessment bodies, schools and college administration, local community leaders,
government departments and public in general about the services available.
3.6 The MCCs will propagate and provide Last Mile Employability (LME) courses
to aspiring jobseekers which are available on NCS portal for enhancing the
employability of youth.
To operationalize the establishment of MCCs, a Memorandum of Understanding
between Govt. of India and the institutions would be agreed upon and signed, as per
the applicability.

4. ROLE OF GOVERNMENT OF INDIA IN ESTABLISHING THE MODEL CAREER
CENTRE
DGE will provide the following support for establishment of Model Career Centre:

4.1 Capacity Building Program for counsellors in MCCs:
4

<!-- page 5 -->

The training program for counsellors is envisaged to cover the following:
a)

Orientation Program on counselling techniques

b)
Train the trainer programs for counsellor champions to become Master
Trainers
c)

Periodic refresher training

d)

Advanced Training (Specialized career counselling techniques)

4.2 Tools & Aids for undertaking the Career Counselling Activities:
Following is the initial set of toolkit that will be made available to the Model Career
Centres:
a)
Standard operating procedure for handling various kind of candidates whether
literate or illiterate
b)

Psychometric & Aptitude Tests

c)

Psychomotor Testing Kits

d)
FAQs related to various types of career opportunities, skills and popular job
choices
e)

Access to Audio & Video content on career choices

f)

Employment Trends

4.3 Tools & Aids for undertaking the Outreach Activities:
Following is the initial set of toolkit that will be made available:
a)
etc.

Standard operating procedure for organizing a job fair, local industry directory

b)

Standard operating procedure for conducting an outreach program

c)

Publicity Content and guidelines for Mobile Vans

4.4. Establishing the Model Career Centres:
DGE will facilitate establishment of MCCs as per the guidelines issued by DGE. The
States/UTs keen to set up MCCs will be required to prepare proposals in accordance
with these guidelines. These proposals will be placed before the Appraisal Committee
in DGE. The financial assistance will be given to States/UTs through the Single Nodal
Agency (SNA), which will open a Single Nodal Account for this scheme at the State
5

<!-- page 6 -->

Level in a Schedule Commercial Bank authorized to conduct government business
by the State/UT Government as per the procedure prescribed. The details on the
structure and functioning of MCCs are at Annexure A.1
4.5 Young Professionals (YP)/counsellors for assistance in career services:
The MCCs would be the role model for replication of career related services. For
supporting the professional assistance requirement, the Ministry has launched a
Scheme for Young Professionals to be deputed to these MCCs to facilitate the
integration and institutionalization of new processes. The YPs will be deployed in
each MCC for a period of 3 years initially (extendable upto 5 years). After the term of
the YP is over, States/Institution may engage a Young Professional or career
counsellor on part-time/contractual basis from their own resources as per
sustainability plan submitted by the State/UT. These professionals will prepare
regular reports on success parameters, to be shared with all stakeholders and will
identify best practices and bottlenecks in MCC implementation. They will also
coordinate outreach activities to schools/colleges and conduct job-fairs including
interaction with academia, local industry, manufacturing associations, training
providers and other stakeholders.
4.6 Information and communications technology (ICT) platform in form of
National Career Services Portal:
NCS portal will make effective use of technology and provide state-of-the-art ICT
based tools for use by personnel of MCCs in facilitating discharging their duties.
Some of the services that will be made available through NCS portal are:
a)
An updated knowledge repository on Career related content for effective
counselling
b)

Job & Skill Mapping for contemporary/popular careers

c)

Job & Vacancy Postings

d)

Training Calendar & Scheduler

e)

Candidate Registration & Tracking

f)

Skill Assessment and Aptitude Testing interfaces

g)

Job Fairs module for on-line and off-line job fairs

4.7 Skill Enhancement:
DGE will provide the information on schemes sponsored by various central
government ministries in the field of skill enhancement and employment. This
6

<!-- page 7 -->

information can be used by the MCCs for guiding youth on skill and career
opportunities from these schemes, assist them in entrepreneurial pursuits

5. ROLE OF STATE GOVERNMENT IN ESTABLISHING THE MODEL CAREER
CENTRE
The success of the MCCs require active involvement of State governments/ other
sponsoring institutions. Locations where MCCs are being established require a
situational analysis of the catchment area as per the specified format, which covers
distribution of training institutions, educational institutions and nature of industries
etc. The broad contours are described below:
5.1 Sponsoring Institution:
Following institutions may send proposals for establishing MCCs:
a)

Central and State Governments.

b)

Autonomous Training Institutions under Central and State governments.

c)
Educational and Training Institutions recognized by GOI, Central and State
Governments, UGC, State University Act, AICTE.
d) Other reputed institutions/organizations working in the area of career counselling
and skill development.
e)

Corporates, Industry, Industry Associations, Chambers of Commerce etc.

5.2 Current situation analysis of the proposed centre:
A detailed exercise to assess the current situation of the Centre which is proposed to
be established as MCC needs to be undertaken on following parameters to identify
the necessary interventions that will facilitate them to function as MCC:
a)

Adequacy of manpower currently available for each such centre.

b)

Skill/Training needs of current officials to function as career counsellor

c)
ICT infrastructure to discharge the duties (computers, printers, projectors,
audio- video system).
d)

Network Connectivity (Type of connectivity and bandwidth availability).

e)

Electricity and power backup facility.

f)

Water & Sanitation facility.

g)

Space Availability (for students, counsellors etc.).
7

<!-- page 8 -->

h)

Type of premises (owned/rented).

i)

Feasibility of making alterations/renovation in the premises.

j)

Sustainability Plan.

Complete profile of each proposed centre needs to be prepared as per the template
available at Annexure B.
5.3 Identification of suitable location(s) for establishing Model Career Centre:
States/UTs are required to identify suitable centres, which can be transformed as
MCCs. These may be located in education & training Institutions, rural and semiurban centres (KSK, PRI, CSC etc.), employment exchanges etc.
5.4 Establishing suitable sustainability model for Model Career Centres:
States/UTs are required to adopt a suitable sustainability model for smooth and
consistent operations of MCCs which will include recurring expense of funding of
manpower and other operating expenses. Several kinds of models for different
centres may be mixed and matched to ensure that career services are offered in an
uninterrupted manner while maintaining quality of service. Some alternative modes
of funding are:
a) State Government Funding (direct/convergence with other schemes)
b) Public private Partnership (Industry Association Sponsorship/Company
Sponsorship/Pvt. Owned/Partial Ownership)
c) CSR Fund Mobilization for Model Career Centre
d) Jointly operated centre.
MCCs will be allowed to provide additional services to ensure viability within the
overall NCS Policy framework.
DGE will provide the operating expenses for the first year of operation of the MCC
subject to the overall funding scheme and the States/UTs will need to continue the
scheme in subsequent years from their own funds.
Model Career Centres will be allowed to provide additional services to ensure viability
within the overall NCS Policy framework.
DGE will provide the operating expenses for the first year of operation of the Model
Career Centres subject to the overall funding scheme and the States/sponsoring
institutions will need to continue the scheme in subsequent years from their own
funds.
8

<!-- page 9 -->

5.5 Identification of Best Practices related to Industry interaction, Student
Engagement and Outreach Program
States/Institutions need to identify the best practices from various employment
related schemes/programs that have generated interest from Industry/Skill
Institutes/Jobseekers etc. They also need to share the details of schemes/initiatives
which have generated substantial results in the direction of enhancing job seekers
employability. As part of information sharing these best practices will be collated and
shared with other Centres for cross leveraging.
5.6 Collation of Career, Job and Skill related data for hosting on National Portal
States/UTs may have developed rich career related content which is useful for career
aspirants. This content may be collated and made available to the jobseekers across
the country via NCS portal. This will not only benefit the jobseekers but also the
career counsellors who will be able to provide better guidance to the aspirants.
5.7 Appointing Nodal Person for managing the NCS activities
States/UTs are required to appoint a nodal person for the NCS project. He/she will
be responsible for managing the overall operations of the MCCs. He/She will
undertake the following responsibilities:
a)

Operational responsibility for the Project

b)

Formulating Project Proposals

c)

Coordinating with GoI for various projects activities

d)

Hardware roll-out and operationalization of MCCs.

e)

Co-ordination and facilitation of meetings with various agencies

f)

Resolution of all issues for smooth project implementation

6. REVIEW AND MONITORING MECHANISM
Progress of MCC transformation may be monitored using pre-defined and
configurable reports that will be generated based on the data maintained by each
MCC. One of the major success parameters for effectiveness of MCCs will be the
number of youth that are connected to jobs according to their potential.
During the orientation training, the career counsellors will be trained on ways to
develop the action plan specific to their individual centre as well as to conduct the
outreach activities, job fairs and industry interaction. They will also be made aware
9

<!-- page 10 -->

of reporting methods for action plan progress. All activities carried out as part of the
action plan will be tracked using the NCS portal.
6.1 Success Parameters:
Key success parameters for Model Career Centres are as follows:
a)
Number of candidates who have been assessed for skill and aptitude or
counselled on relevant career options.
b)
Number of school counselling sessions, job fairs and other outreach activities
undertaken (with number of candidates/employers participated)
c)

Number of vacancy postings coordinated.

d)

Number of candidates who have been placed through various channels.

e)
Number of candidates who have been placed through enabled matching
services (like Last Mile Employability training, Recognition of Prior Learning etc.).
DGE will also have access to insightful analysis and information that is generated
from the NCS data for each MCC. These could be utilized by stakeholders to refine
guidelines and share best practices for improving the services offered by MCCs.
States/UTs will undertake periodic review of the reports and formulate corrective
action for improving the MCC services.

7.

SUBMISSION OF PROPOSALS

States/UTs/institutions are required to submit proposals for establishment of MCC
based on the template provided in Annexure B which covers the following areas:
a)

Implementing Institution details (Annexure B.1)

b)

Current situation analysis (Annexure B.2)

c)

Infrastructure requirements with financial details (Annexure B.3)

d)

Proposed resource deployment plan (Annexure B.4)

e)

Proposed implementation timelines (Annexure B.5)

f)

Proposed Target Plan (Annexure B.6)

g)

Sustainability Model

An Appraisal Committee has been constituted to set the guidelines for evaluation of
the proposals under the NCS framework based on administrative, technical, financial
parameters including feasibility and viability and this committee will scrutinize the
proposals based on the guidelines evolved. The Appraisal Committee while evaluating
10

<!-- page 11 -->

the proposals will give due weightage to the relevant experience of the Implementing
Institution and ensure equitable distribution of MCCs throughout the country. It
may seek clarifications and suggest modifications on the proposal submitted by the
Implementing Institution, as necessary. The Appraisal committee may relax the
guidelines depending upon the merit of the proposals on a case-to-case basis.

11

<!-- page 12 -->

ANNEXURE A: Model Career Centres - Scheme Details
A.1

Details of Model Career Centres
A.1.1

Staffing Plan

a) States/UTs will ensure that competent staff is made available and retained
for continuity across all the MCCs.
b) Each MCC will have a Centre Manager who will be the overall in-charge for
the management of Centre and be responsible for physical safety and
security of Model Career Centre premises.
c) Centre Manager could also act as a career counsellor. These Centre
managers will plan and strategize the operations of MCC in accordance
with NCS guidelines issued by DGE from time to time. Centre Manager will
act as member secretary for the district level committee under the
chairmanship of District Magistrate for carrying out career services in the
district.
d) Each MCC will also have other counsellors who will be responsible for
providing career guidance to jobseekers and assist Centre manager in
carrying out various outreach and IEC activities such as job fairs, mobile
van tours etc. These counsellors will also undertake the trainings of
voluntary counsellor at block/village level. Roles of Career Counsellors are
at AnnexureA.2
e) Each MCC will have support staff consisting of a Registration Manager and
IT Support technical staff. These will ensure the daily operations of MCC
and assist counselors in the MCC.
f)

Under ‘Young Professionals Program’ of DGE, these young professionals
will be associated with NCS program initially for a period of 3 years which
can be extended upto 5 years. In case, MCC requires the services of a
Counsellor, instead of a Young Professional for better operationalization of
the MCC, States will be encouraged to engage Career Counsellors on parttime /contractual basis.

12

<!-- page 13 -->

g) Following table shows the key staff required for operation of MCC:
Staff Type/Category
Centre Manager (Counsellor)
Other Counsellors
Registration Manager
IT Assistant
Young Professionals /
Counsellor
Support Staff

A.1.2

Number
1
2
1
1
1 (based on requirement)
2

Infrastructure

The following infrastructure is proposed in an MCC:
#
A.1.2.1
A.1.2.2
A.1.2.3
A.1.2.4
A.1.2.5
A.1.2.6
A.1.2.7
A.1.2.8
A.1.2.9
A.1.2.10

Infrastructure/ Item description
Reception cum Registration counter
Waiting area
Technology Lab (no. of work stations)
Individual Counselor room
Group counseling room
Washroom
Drinking Water
Canteen/ Pantry
ICT Infrastructure
Total Area (Sq. ft.)

Quantity
(indicative)
1
40 seats
10-12
3
1
2
To be available
1
To be available
2000#

While a sample layout of a MCC is provided in Annexure A.3, the above
infrastructure items are explained below:
# Relaxation of approx. 20% of the minimum area for operating Model Model Career
Centres can be considered against minimum requirement of 2000 sq. ft. so that basic
physical requirements can be fulfilled. A smaller area may not be able to provide all the
services that MCC should have. This criterion will be applicable for difficult geographical
location, hilly terrain or NER and such locations can be decided on case to case basis.

13

<!-- page 14 -->

A.1.2.1 Reception cum Registration Desk: A MCC will have a reception
cum registration desk at the entrance. The reception area should
have:
I.

II.

Receptionist will have desktop and will help illiterate/ differently
abled jobseeker register on NCS, book slots of counsellors for
counselling etc.
One Landline Phone with intercom facility

A.1.2.2 Waiting Area: A waiting area with around 40 seats should be
available in the Model Career Centre. It should be well-lit and wellventilated. The waiting area should have:
I.

II.
III.

LCD/LED Screen – A LCD/LED screen of approx. 55’’ in size
will be installed and will showcase the jobs opportunities,
career A/V content etc.
Newspapers and Magazine Rack.
Seating capacity for visitors.

A.1.2.3 Technology Room: Technology Room will have facility for
jobseekers to access and update profile, access online career
counselling material and view the audio- video content. This room
will have:
I.
II.
III.

Desktops and seating capacity.
One Landline Phone with intercom facility.
One multifunction Printer.

A.1.2.4 Career Counseling Rooms: MCC will have a Group Counselling
room with an indicative area of 30x20 sq. feet for Group counselling
and individual counselling room with an indicative area of 15x15sq.
feet. This room will have following facilities:
I.

Desktop – Each room will be equipped with one desktop with
internet connectivity to be used by counsellor

II.

One Landline Phone with intercom facility

III.

Seating capacity for 10 visitors for Group counselling and 2-3
visitors for individual counselling.
14

<!-- page 15 -->

IV.

The Group counselling room will also be used to host meetings with
industry personnel to understand their requirements with regards to
personnel and skills. This will enable counsellors to do Market sizing of
skills and jobs which will aid them in providing right guidance to
jobseekers.
One LCD/LED Screen – A LCD/LED screen of approx. 55’’ in size will
be installed in Group counselling room which will showcase jobs
opportunities, job fairs, other career related content etc.

A.1.2.5

Washroom: Separate washroom facility should be available for
genders & Differently Abled. The washrooms should be kept clean
and hygienic.

A.1.2.6 Drinking Water: Drinking water facility should be available for
all staff and visitors of the Model Career Centre.
A.1.2.7

Canteen/Pantry: A breakout area with tea/coffee vending machine
& seating capacity.

A.1.2.8

ICT Infrastructure: Each MCC will have following ICT infrastructure:

1. Desktops connected over a network.
2. Access to desktop/network based tools for various tests.
3. A dedicated internet connectivity with speed of at least 10 Mbps.
4. A multifunction printer with adequate supplies of consumables.
5. A projector and audio video system.
6. Token Display system.
7. Landline Connection.
8. 2 hours UPS backup for all ICT infrastructure.
A.1.2.9 Total Area: A total area of around 2000 sq.ft. is estimated for
setting up of Model Career Centres.
A.1.3

Implementation Strategy

The following strategy will be followed for implementation of MCC:
a) The role of the Central Government would be largely confined to the
guidelines and initial financial assistance for development and
15

<!-- page 16 -->

management of MCC and aspects pertaining to review and monitoring
while implementation of MCC is proposed to undertaken by the
States/UTs/institutions.
b) The financial assistance will be given to States/UTs through the
Single Nodal Agency (SNA), which will open a Single Nodal Account
for this scheme at the State Level in a Schedule Commercial Bank
authorized to conduct government business by the State Government
as per the procedure prescribed.
c) The indicative ceiling of financial assistance provided to each MCC
will be a maximum of INR 60 lakh. This financial assistance can be
utilized for infrastructure like electrical and electronic equipment,
furniture, IT Hardware as well as minor civil works (a list of admissible
expenses are given in Annexure (C). Any expense above INR 60 lakh would
have to be funded by the States/UTs. The funding pattern would be 60%
release in first instalment and 40% release in second instalment. The
MCC would require to submit the following documents before the
release of second instalment: 1. 75% Utilization
Instalment.

Certificate

(12-A/12-C

as

applicable)

of

1st

2. Statement of expenditure signed by financial controller/authorized
financial functionary and duly countersigned by State Director
(Employment/Labour/Industries/Skill)/Labour Commissioner /Head
of Departments of the Concerned MCC.
3. Performance/Outcome of the MCC duly countersigned by State
Director (Employment)/Labour Commissioners/ Head of the
Department of the concerned MCC.
d) The minimum requirements and services of MCC are at Annexure A.4 and
A.5 respectively.
e) Necessary branding standards should be followed to maintain uniformity
and common theme of NCS among States/UTs and with Government of
India.

16

<!-- page 17 -->

A.2 Activities to be performed by Career Counsellor

Roles & Responsibilities of Career Counsellor
Career Counsellor: A career Counsellor counsels others in finding jobs or vocational courses to
help them obtain a job. He holds sessions with students to help them with their career choices.
General Responsibilities of a Career Counsellor are:








Direct counselling of students
o Interact with students, parents, teachers and school
o Maintain updated student profile
o Ascertain the students career preferences
o Conduct skill assessment and aptitude tests
o Provide information on financial aid
o Guide students on right career choice through group counselling followed by face to
face
Counselling of youth/ jobseekers
o Conduct skill assessment and aptitude tests for potential career options
o Provide information on vocational guidance and career opportunities
o Provide information on self-employment and entrepreneurial activities include
financial assistance
o Provide information on various schemes for skill development along with training
providers
o Prepare candidates for interviews through mocks and help in CV building
o Recommend candidates for gap training
o Match job seeker profile with employment opportunities
o Follow up activities
Outreach services like job fairs, mobile services etc.
o Interact with industry for promoting job fairs and identifying career opportunities
o Approach schools and colleges for group counselling and dissemination of
career related information
o Mobilize NGOs and other institutions for collaboration in job fairs and outreach
services
Counselling of counsellors
o Establish a network of counsellors – general and specialized
o Distribution of counselling toolkits to school Counsellors and provide basic training

Desired Traits for a Model Career Counsellor





Good knowledge of counselling techniques
Helpful nature
Positiveapproach
Good communicationskills

17

<!-- page 18 -->

A.3 Sample Layout for MCC

18

<!-- page 19 -->

A.4.

Minimum requirements of MCC
1. Power Backup
2. Min. Area – 2000 sq.ft.
3. State/UT/Institution owned property
4. Differently-abled friendly
5. Easy connectivity through public transport
6. Internet connectivity
7. Preferably near Education & Training Institutions, Rural and Semiurban centres (KSK, PRI, CSC etc.)

A.5 Minimum Services to be provided by each MCC
1.
2.
3.
4.
5.
6.
7.
8.

Registration and Profile Updation
Assessment/Counselling of candidates
Vacancy Posting by Employers
Job Mapping
Job Fair and Recruitment drive
Feedback/ Grievance Redressal
Survey of catchment area
Focused outreach activities for target group using appropriate channels

19

<!-- page 20 -->

ANNEXURE B: Project proposal
B.1 SPONSORING INSTITUTION DETAILS
#
1
2
3

4

5

SPONSORING INSTITUTION DETAILS
Name of State/Institution
Address of proposed Model Career Centre
Contact details of Nodal Person of centre (MCC)
 Name, Designation, Address
 Contact number
 Email ID
Contact details of Nodal Person of State/UT
 Name, Designation, Address
 Contact number
 Email ID
Registered Office (along with details of Registering
Authority)

6

Nature of Business

7

Relevant Experience in Education/ Career related fields

The KYC details of the sponsoring institution would need to be
submitted along with the application.

B.2 CURRENT SITUATION ANALYSIS OF PROPOSED MCC
#
1.
2.
3.
4.

5.

6.
7.
8.
9.

MODEL CAREER CENTRE DETAILS
Address
Office Type (State Owned/Rented)
Total Area (approx.)
Is there a separate counselling room? (If yes then
number of
rooms)
Is there seating facility for students/jobseekers in the
waiting
area? (If yes then number of seats)
Drinking water facility for students/jobseekers
Toilet Facility for students/jobseekers
Is Power Backup available?
Number of desktops in office

20

<!-- page 21 -->

10.

What operating system is available on desktop?
(Windows
XP/Windows7/Linux/Other)
11. Is other IT facility available?
(printing/ scanning/ projector etc.)
12. Internet Facility ( If yes then the speed)
STAFF DETAILS IN PROPOSED CENTRE
13. Total Staff strength
14. Number of counsellors
15. Number of psychologist
16. Number of temporary staff
DEMOGRAPHIC DETAILS OF THE CATCHMENT AREA
17. Names of Districts in Catchment Area
18. Total Population of Catchment Area
19. Literacy Level
20. Major occupation of people
21. Major industry type in the Catchment Area
22. Major skillset of people in the Catchment Area
23. Number of people in working age
24. Number of Universities
25. Number of Engineering Colleges
26. Number of Colleges
27. Number of ITIs
28. Number of schools
29. Number of skill training/vocational training institutes

B.3 INFRASTRUCTURE REQUIREMENTS WITH FINANCIAL DETAILS
FOR MCCs (Refer Annexure E)
#
1

Category
Reception/
Registration
Desk

2

Waiting Area

3

Individual
counsellor room

No

Items
LCD/LED Display
Computers
Chairs
Table
Chairs
Tables
Computers
Phone
Chairs
Tables

21

Quantity

Rate

Total

<!-- page 22 -->

4

Group
Counselling
Room

5

IT Lab

6

Pantry

Computers
Phone
LCD/LED Display
Chairs
Tables
Computers
Phone
Multifunctional
Device
(Printing, scanning
etc.)
Chairs
Tables
Tea/Coffee Vending
Machine
Water Cooler

7

8

Others including
Minor works
(please specify
in detail)
Organization of
Job Fairs (Plan
in detail)

<<At least one job
fair per month and
at least one Mega
Job fair in a year>>

Total
Note: States/Institutions can add more line items within the above 8 categories based
on the identified local needs of the identified career centre. Contingency up to a
maximum of 10% of cost may be included in the project cost.

22

<!-- page 23 -->

B.4.

PROPOSED RESOURCE DEPLOYMENT PLAN (STAFFING)
Sl No

1

PROPOSED IMPLEMENTATION TIMELINES
Sl No

1
2

Milestone

Timeline

Identification of Proposed Centre
Finalization of plan for establishing Model Career
Centre
Initiation of minor work/renovation
Completion of site preparation including
infrastructure
Deployment of proposed staff in the centre
Initiation of operations in Model Career Centre

3
4
5
6
B.6.

Identified (Yes/No)

Centre Manager cum
counsellor
Other Counsellor
Registration Manager
IT Assistant
Support Staff

2
3
4
5

B.5.

Minimum
No.

Staff Type

PROPOSED TARGET PLAN
Target

S.No. Parameter

1

2

3
4
5

Quarter 1 Quarter 2 Quarter 3 Quarter 4

Number of candidates to be
assessed for skill and aptitude or
counselled on relevant career
options
Number of school counselling
sessions or job fairs or other
outreach
activities
to
be
undertaken (with number of
candidates participating)
Number of vacancy postings to be
coordinated
Number of candidates to be
placed through various channels
Number of candidates to be
placed through enabled matching
services

23

<!-- page 24 -->

B.7 PROPOSED SUSTAINABILITY PLAN FOR MCC

DGE will provide one-time funds for meeting expenditure towards
improving the facilities in the MCCs like desktops, display devices etc.
States/Institutions are required to adopt a suitable sustainability model
for smooth and consistent operations of MCC which will include recurring
expense of funding of manpower and other operating expenses.
States/Institutions may mix and match several kinds of models and
ensure that career services are offered in an uninterrupted manner while
maintaining quality of service. Some alternative modes of funding are:
1. State Government Funding (direct/convergence with other schemes):
Various skill, career, livelihood schemes operational in State may be
used to arrange the funds for operational expenses in Career Centre.
In such cases, it is desirable that the institution should obtain the
concurrence of State Government in this regard to avoid duplication
and facilitate convergence of schemes.
2. Public
Private
Partnership
(Industry
Association
Sponsorship/Company
Sponsorship/
Pvt.
Owned/
Partial
Ownership): Various vocational schools, skill institutes and private
players can be contacted for jointly operating Career Centre under PPP
model.
3. CSR fund Mobilization for Career Centre: As part of mandatory CSR
spending, career development and skilling has been identified as one
of the areas in which corporates can spend the CSR funds. Joint
programs with corporate houses can be formulated for executing the
career center operations.
4. Jointly owned centres (2 or more players): Career Center have an
option to co-brand the centers with corporate houses (putting
corporate house logo, naming rights of career center etc.), e.g.
Adoption of various ITIs by Maruti Suzuki, Sponsoring operations of
several vocational training centers in Odisha by Vedanta.
5. Any other suitable activities may be carried out by Career Centres to
generate revenue for sustainable operations. The States/Institutions
should detail out such activities in their proposal for concurrence by
the Appraisal Committee.
States/Institutions are required to provide the approach for choosing
a suitable sustainability model as per their localized environment and
requirements.

24

<!-- page 25 -->

ANNEXURE C: Activities admissible/not-admissible for funding for
establishment of MCCs
C.1.

Activities admissible for funding for establishment of MCCs

C.1.1.

Infrastructure upgradation activities
a. Flooring
b. Partitioning
c. Basic furniture and furnishings
d. Electrical wiring and fittings
e. Renovation of toilets
f. Disabled friendly access
g. Basic pantry equipment
h. Other minor works- distempering, painting repairing etc.

C.1.2.

ICT infrastructure
a. Desktops
b. Multi-function devices, Scanners, Printers etc.
c. Projectors (portable with screen)
d. Internet Connectivity, LAN cabling etc.
e. UPS
f. LCD/LED display
g. EPABX equipment
h. Self-help Kiosks

C.1.3.

Operational expenses for Outreach activities like
a. Job Fairs, outdoor melas, street plays etc.
b. Hiring of Mobile Vans
c. Group counseling sessions

C.2.
Activities NOT Admissible for funding for establishment of
MCCs1. Construction of new building
2. Major civil work
3. Staff Salaries excluding Young Professionals
4. Purchase of vehicles
C.3.

Activities not listed above may be included in the proposal
with relevant justification for approval of the Appraisal
Committee.

25

<!-- page 26 -->

ANNEXURE D: Additional Guidelines for proposals from institutions

other than Central/State/UT governments
1. Type of Institution - The following type of institutions which have been in
operations for at least 3 years can apply:
(a) Institutions or organizations set up as Autonomous Organisation under a
specific statute or as a society registered under the Societies Registration Act,
1860 or Indian Trusts Act, 1882 or other statutes.
(b) Institutions registered as Not-for-profit Section 25 Companies under the
Companies Act, 1956 (Section 8 companies under the Companies Act, 2013).
(c) Universities registered/recognized under Central or State Acts
Exclusions: Institutions which have been blacklisted/debarred/derecognized by central/state government institutions in the last three years
would not be eligible to apply.
2. Documents to be submitted along with the proposal:
a) The Articles of Association, bye-laws, audited statement of accounts,
sources and pattern of income and expenditure etc. of the last 3 financial
years.
b) A statement of purpose giving the institutional profile and clearly
stating the rationale for setting up a Model Career Centre (Not exceeding
1 pages).
c) Annexure A, B and C of the guidelines duly filled up. The following
modifications in the existing guidelines have been made:
The area for operating a Model Career Centre could be relaxed based
on the location and justification.
Rent for premises may not be included in the proposal. They could
charge value added services but registration and general counselling
should be free of charge to job seekers.
The advance release shall be a maximum of 60% of sanctioned
amount. The remaining payment may be released after compliance
validation and receipt of utilization certificate of minimum 75%.
d) The basic services for the NCS project will be made available free of
cost to the candidates. The maximum period for which the grants-in-aid
will be provided shall not exceed 18 months duration. Thus, a
sustainability plan for managing the operations of MCC for a minimum
period of 5 years needs to be proposed.
e) As a part of the key performance indicators, institutions under
categories 1 (a) would be required to submit:
Placement track record of the previous 3 years
26

<!-- page 27 -->

A plan of action giving placement targets for the next 5 years to be
monitored on a 6 monthly basis
The plan should also contain a strategy/proposal for outreach in
the catchment area.
Institutions under categories 1 (c) would be required to submit:
Placement track record of the previous 3 years.
A plan of action giving counselling and placement targets for the
next 5
years to be monitored on a 6 monthly basis.
The plan should also contain a strategy/proposal for outreach in
colleges.
4. Post approval processes:
a) Prior to release of any financial support, institution shall be required
to execute a bond as per the Government Financial Rules (GFRs) and
include provisions for exit management.
b) The MCCs will be required to report their performance through the
NCS portal and be amenable to physical, financial and performance
reviews by DGE or its nominated agencies.
c) All funds released as grants-in-aids shall adhere to the GFR
guidelines. Upon utilization, institutions will be required to submit the
utilization certificate as per the GFRs.
d) For managing the MCC funds, separate accounts (book of accounts,
asset register etc.) may need to be maintained by the institution for audit
and reviews.

27

<!-- page 28 -->

ANNEXURE E: - Indicative Item List to be submitted along with B.3

INDICATIVE ITEMS IN EACH CATERGORY
CATEGORY
ITEMS
#
LCD/LED DISPLAY
A
COMPUTERS
MFDs (MULTIFUNCTIONAL DEVICES)
LAPTOP
PROJECTOR
IT
INFRASTRUCTURE UPS
GENERATOR
AUDIO SYSTEM
INTERACTIVE BOARD
B

Furniture and
Fixtures

C

Minor Civil Work

CHAIRS
TABLES
SPLIT AC
WINDOW AC
WATER COOLER
MODULAR WORKSTATION
TEA/COFFEE VENDING MACHINE
BOOK SHELF
EPBX (UPTO 20 EXTNS.)
FLOORING,PARTITIONING,BASIC
FURNITURE &
FURNISHING,ELECTRIC WIRING AND
FITTING,RENOVATION OF
TOILETS,DISABLED FRIENDLY
ACCESS,BASIC PANTRY
EQUIPMENT,OTHER MINOR WORKDISTEMPERING,PAINTING
REPAIRING ETC.

Qty
2
20
4
2
1
Need Basis
Need Basis
1
1
80
30
5
3
1
20
1
1
1

Atleast, 1
Job fairs
every
month

D
JOB FAIRS

2
Counseling
every
month

E
Vocational
Guidance/ Career
Counselling

(Total 24
Counseling)

28
