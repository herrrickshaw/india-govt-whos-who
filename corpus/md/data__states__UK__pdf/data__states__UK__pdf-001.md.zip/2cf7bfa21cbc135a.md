---
doc_id: "2cf7bfa21cbc135a"
source_url: "https://cdnbbsr.s3waas.gov.in/s3fcdb3b4550e745d29a64a696047067b7/uploads/2025/02/202502251948223424.pdf"
ministry: "Biodiversity Board, Uttarakhand"
title: "Guidelines for Operationalization of BMCs"
date: ""
pages: 98
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e2aba31184d1bf66"
---

<!-- page 1 -->

tSo fofoËkrk izcUËk lfefr ds
lapkyu gsrq fn'kk&funsZ'k
Guidelines for Operationalization of
Biodiversity Management Committees (BMCs)

mRrjk[k.M tSofofo/krk cksMZ
UTTARAKHAND BIODIVERSITY BOARD

mRrjk[k.M tSo fofoèkrk cksMZ

UTTARAKHAND BIODIVERSITY BOARD

<!-- page 2 -->

tSo fofoËkrk izcUËk lfefr (ch0,e0lh0)
ds lapkyu gsrq fn'kk&funsZ'k
Guidelines for Operationalization of
Biodiversity Management Committees (BMCs)

mRrjk[k.M tSofofo/krk cksMZ
UTTARAKHAND BIODIVERSITY BOARD

mRrjk[k.M tSo fofoèkrk cksMZ
UTTARAKHAND BIODIVERSITY BOARD

<!-- page 3 -->

izdk'kd

% mRrjk[k.M tSo fofoèkrk cksMZ
Qst&2] olUr fogkj] nsgjknwu&248006

izdk'ku

% tuojh] 2015

foRrh; lg;ksx

% ^^dSyk'k ifo= Hkw&n`'; laj{k.k ,oa fodkl igy^^
ifj;kstuk

ekxZ n'kZu

% Mk0 jkds'k 'kkg
vè;{k] mRrjk[k.M tSo fofoèkrk cksMZ] nsgjknwu

lEiknd

% Jh th0,l0 ikUMs]
lnL; lfpo] mRrjk[k.M tSo fofo/krk cksMZ] nsgjknwu

lEiknu ,oa
fgUnh vuqokn

% Jh èkuat; izlkn
mi&funs'kd] mRrjk[k.M tSo fofoèkrk cksMZ] nsgjknwu

Publisher

: Uttarakhand Biodiversity Board
108, Phase-2, Vasant Vihar, Dehradun-248006

Published

: January, 2015

Financial Support

: Kailash Sacred Landscape Conservation and
Development Initiative Project (KSLCDI)

Guidance

: Dr. Rakesh Shah
Chairman, Uttarakhand Biodiversity Board,
Dehradun

Editor

: Shri G.S. Pande
Member-Secretary, Uttarakhand Biodiversity Board,
Dehradun

Editor &
Hindi Translation

: Shri Dhananjay Prasad
Deputy Director, Uttarakhand Biodiversity Board,
Dehradun

<!-- page 4 -->

<!-- page 5 -->

iv

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

izkDdFku
tSo fofoËkrk dUosa'ku dk lnL; jk"Vª gksus dh fofËkd izfrc)rk ds n`f"Vxr tSo fofoËkrk vfËkfu;e]
2002 rFkk tSo fofoËkrk fu;e] 2004 ds iz[;kiu ds lkFk gh Hkkjr esa tSo lalkËkuksa ds laj{k.k] iks"k.kh;
mi;ksx rFkk ykHk ds lkE;iw.kZ izHkktu ds ;qx dk lw=ikr gqvkA mDr vfËkfu;e@fu;e ds fofoËk
izkfoËkku] tks fodsfUnzr gksus ds lkFk&lkFk fodklksUeq[k ,oa vfHkuo izd`fr ds gSa] leqnk; dks fofËkd
'kfDr iznku dj mn~n';ksa dh izkfIr gsrq leqfpr volj iznku djrs gSaA
jk"Vªh; tSo fofoËkrk izkfËkdj.k] jkT;ksa ds tSo fofoËkrk cksMZ rFkk tSo fofoËkrk izcUËk lfefr;kW
Øe'k% jk"Vªh;] izknsf'kd rFkk LFkkuh; fudk; Lrj ij vfËkfu;e@fu;e ds fØ;kUo;u gsrq lapkyd
vax gSaA mn~ns';ksa dh izkfIr ds lanHkZ esa tSo fofoËkrk izcUËk lfefr dh Hkwfedk fu%Lkansg lokZfËkd
egRoiw.kZ gSA lfefr dk eq[; dk;Z muds {ks=kUrxZr ik;h tkus okyh lHkh izdkj dh tSo fofoËkrk
dk vfHkys[khdj.k ^^yksd tSo fofo/krk iaftdk** esa djuk gSA blds vfrfjDr lfefr }kjk ^^tSo
lkaLd`frd leqnk; lays[k^^ Hkh fu:fir fd;k tkuk visf{kr gS ftlesa {ks= ds fofHkUu fo"k;ksa ;Fkk
ikfjfLFkfrdh] laLd`fr o vË;kRe] ikjEifjd Kku rFkk lalkËkuksa ls lEcafËkr izpfyr LFkkuh; izFkk dks
vfHkfyf[kr fd;k tkrk gSA
vkuqokaf'kd lalkËkuksa rd igqWp rFkk ykHk dk izHkktu oLrqr% mi;ksxdrkZ rFkk tSo lalkËku iznkrk ds
eË; ,d le>kSrk gS ftlesa mi;ksxdrkZ vkuqokaf'kd lalkËkuksa rd igqWp ds lkis{k iznkrkvksa dks ykHk
nsus ij lger gks tkrk gSA ^^tSo lalk/ku^^ dk rkRi;Z ikSËks] tho&tUrq vkSj lw{e tho ;k muds
Hkkx lfgr muds vkuqokaf'kd inkFkZ ¼ewY;ofËkZr mRiknksa rFkk ekuoh; vkuqokaf'kd inkFkksaZ dks NksM+dj½
ls gSA fu;ekuqlkj vkuqokaf'kd lalkËkuksa rd igqWp gsrq bPNqd fdlh O;fDr@laLFkk ¼mi;ksxdrkZ½
}kjk okf.kfT;d mi;ksx ls iwoZ mlds iznkrk ¼tgkW vkuqokaf'kd lalkËku miyCËk gS½] ls ^^iwoZ lwfpr
lgefr^^ (Prior Informed Consent) izkIr djuk vko';d gSA rRi'pkr mi;ksxdrkZ rFkk iznkrk
vkilh lgefr ls fu;e o 'krsZa fuËkkZfjr djrs gS ftls ^^ijLij lger 'krZ^^ (Mutually Agreed
Term) dgrs gSaA ykHk ds cWVokjs ds fofHkUu :Ik tSls jkW;YVh] la;qDr m|e] izkS|ksfxdh gLrkUrj.k]
dkS'ky rFkk {kerk fodkl vkfn gks ldrs gSaA
tSo fofoËkrk izcUËk lfefr dh lokZfËkd egRoiw.kZ Hkwfedk rFkk vfËkfu;e@fu;e ds mn~ns';ksa dh
izkfIr gsrq lfefr dks muds vfËkdkj] mRrjnkf;Ro ,oa Hkwfedk dk cksËk djk;k tkuk vfrvko';d gSA
mijksDRk ds n`f"Vxr gh jk"Vªh; tSo fofoËkrk izkfËkdj.k }kjk ^^tSo fofoËkrk izcUËk lfefr ds lapkyu
gsrq fn'kk&funsZ'k** fuxZr fd;s x;s gSaA jk"Vªh; tSo fofoËkrk izkfËkdj.k }kjk vaxzsth Hkk"kk esa fuxZr
fn'kk&funsZ'k ds fgUnh :ikUrj.k gsrq Jh Ëkuat; izlkn] mi&funs'kd fo'ks"k cËkkbZ ds ik= gSaA bl
fn'kk funsZ'k iqfLrdk ds f}Hkk"kh; izdk'ku gsrq Jh thŒ,lŒ ik.Ms] lnL;&lfpo rFkk mudh Vhe ds
lHkh lnL; Hkh cËkkbZ ds ik= gSaA
vk'kk gS fd bl fn'kk&funsZ'k ls tSo fofoËkrk izcUËk lfefr dks tkx:d cukus ds lkFk&lkFk
vfËkfu;e@fu;e ds mn~ns';ksa dh izkfIr gsrq lfefr dks l{ke Hkh cuk;k tk ldsxkA
¼Mk- jkds'k 'kkg½
vË;{k]
mRrjk[k.M tSo fofoËkrk cksMZ]
nsgjknwuA
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 6 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

v

Foreword
Being a member of the convention on Biological Diversity (CBD) and its legal obligations, the
enactment of Biological Diversity Act, 2002 and Biological Diversity Rules, 2004 heralded a
new era in India to conserve, manage and share the benefits arising from the use of Biological
resources. The various provision of the said Act/Rules, which are not only decentralized,
development oriented and innovative but also provide ample opportunity to achieve the
objectives by legally strengthening the hands of local communities.
National Biodiversity Authority, Biodiversity Board of States and Biodiversity Management
Committees are the operational arms at Central, State and Local bodies respectively for
implementing the provisions of the Act/Rules. The role of Biodiversity Management
Committee for achieving the objectives is undoubtedly most crucial. The main function
of the BMC is to document all kinds of bio-resources present in their area in “Peoples
Biodiversity Register”. In addition to that, the committee also has to develop “Bio-cultural
Community Protocol” in which diﬀerent features of the area such as ecology, culture and
spirituality, traditional knowledge and local traditions related to the use of bio-resources are
documented.
Access to genetic resource and benefit sharing is a kind of agreement between the user
and the provider of biological resource, in which the user agrees to share benefits with its
provider in lieu of providing access to genetic material. As per rule, it is mandatory for any
interested person/institution (user) to have “prior informed consent” (PIC) for Commercial
use of biological resource from its provider (where genetic material is available). Thereafter,
the user and the provider by mutual consent agree to certain terms and conditions known
as “Mutually Agreed Terms” (MAT). There can be diﬀerent modes of sharing benefits like
royalty, joint venture, technology transfer, skill and capacity development etc.
In view of the crucial role of BMC in achieving the objectives of the act/rule, it is important
to generate awareness among BMCs regarding their rights along with the roles and
responsibilities. Keeping in view the above fact, the “Guidelines for the operationalization” of
BMCs was issued by the National Biodiversity Authority. The eﬀort made by Shri Dhananjay
Prasad, Deputy Director in translating English version of the guidelines into Hindi is highly
appreciated. I also congratulate Shri G.S. Pande, Member-Secretary and his entire team for
publishing the said guideline in bi-lingual form.
I am sure that this guideline will not only help raising awareness among BMCs but also help
in building the capacity of the committee to achieve the objectives of the act/rule eﬀectively.
(Dr. Rakesh Shah)
Chairman
Uttarakhand Biodiversity Board,
Dehradun
"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 7 -->

vi

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

Hkwfedk
Lkjy Hkk"kk esa ^^tSo fofo/krk^^ 'kCn dk rkRi;Z i`Foh ij ekStwn leLr izdkj ds thoksa ls gSA oSKkfud
vuqeku ds vuqlkj i`Foh ij tho&tUrqvksa dh yxHkx 1-0 djksM+ ls 1-50 djksM iztkfr;kW fuokl
djrh gSa ftuesa ls oSKkfudksa }kjk vc rd yxHkx 18 yk[k iztkfr;ksa dh gh igpku dh tk ldh
gSA orZeku esa i`Foh ij yxHkx 727 djksM+ euq"; fuokl djrs gSaA ,d vuqeku ds vuqlkj oSf'od
tula[;k esa izfro"kZ yxHkx 8 djksM+ dh o`f) gksrh gSA bl izdkj izR;sd 12 o"kksZa dh vofËk esa fo'o
dh tula[;k esa yxHkx 100 djksM+ dh o`f) gksrh gSA ;g Hkh vuqekfur gS fd o"kZ 2050 rd fo'o
dh ekuoh; tula[;k 1000 djksM+ ls vfËkd gks tk;sxhA gky ds dbZ oSKkfud vË;;uksa ds vuqlkj
i`Foh ij yxHkx 300 djksM+ euq";ksa ds iks"k.k gsrq gh i;kZIr izkd`frd tSo lalkËku miyCËk gSaA oLrqr%
i`Foh ij ekuoh; tula[;k ls mRiUu vkorZd ncko ds dkj.k ge vius cgqewY; izkd`frd ,oa tSo
lalkËkuksa dks [kksrs tk jgs gSaA
ekuoh; gLr{ksi ds dkj.k foyqIr gksrs tSo lalkËkuksa ds n`f"Vxr o"kZ 1992 esa fj;ks&fM&tSusjks ¼czkthy½
esa vk;ksftr ^^i`Foh lEesyu^^ ds nkSjku ^^tSo fofo/krk dUosa'ku^^ vfLrRo esa vk;kA tSo fofoËkrk
dUosa'ku ¼lafËk½ o"kZ 1993 ls izHkkoh gqvk rFkk orZeku esa Hkkjr lfgr fo'o ds 194 ns'k bl dUosa'ku ds
lnL; gSaA tSo fofo/krk dk laj{k.k] mlds vo;oksa dk iks"k.kh; mi;ksx rFkk vkuqokaf'kd lalkÌuksa
ds mi;ksx ls izkIr ykHk dk lkE;iw.kZ izHkktu bl dUoasU'ku ds eq[; mn~ns'; gSA
fo'o dk 2-7 izfr'kr Hkw&Hkkx] 4 izfr'kr ehBk ikuh] 17 izfr'kr vkcknh rFkk 18 izfr'kr eos'kh
fo|eku gksus ds ckotwn Hkh gekjk ns'k fo'o ds 17 fpfUgr tSo fofoËkrk lEiUure jk"Vªksa es ls ,d
gSA fu%lansg ;g ge lHkh Hkkjrh;ksa ds fy, xoZ dk fo"k; gSA vUrjZk"Vªh; izfrc)rk rFkk dUosa'ku
ds rhu eq[; mn~ns';ksa dh izkfIr ds n`f"Vxr~ Hkkjr ljdkj }kjk tSo fofoËkrk vfËkfu;e] 2002 rFkk
tSo fofoËkrk fu;e] 2004 vfËklwfpr fd;s x;sA mDr vfËkfu;e ds vuqikyu dk nkf;Ro rhu Lrjh;
O;oLFkk ;Fkk jk"Vªh; LRkj ij tSo fofoËkrk izkfËkdj.k] jkT; Lrj ij jkT; tSo fofoËkrk cksMZ rFkk
LFkkuh; fudk; Lrj ij tSo fofoËkrk izcUËk lfefr ij gSA
09 uoEcj 2000 dks xfBr mRrjk[k.M jkT; tSo fofoËkrk ds n`f"Vdks.k ls le`) izns'k gSA 53]483
oxZ fd0eh0 {ks=Qy esa QSys bl izns'k esa 13 ftys] 78 rglhy] 95 fodkl[k.M] 7227 xzke iapk;r
rFkk 15761 xzke fo|eku gSaA o"kZ 2011 dh tux.kuk ds vuqlkj bl izns'k dh tula[;k yxHkx 1-01
djksM+ gSA jkT; ds dqy Hkw&Hkkx dk yxHkx 71 izfr'kr ou Hkwfe rFkk 46 izfr'kr Hkkx oukPNkfnr
gSA fofHkUu izdkj ds tyok;q] LFkykd`fr rFkk ÅWpkbZ okys LFky ;gk¡ fofHkUu ouLifr;ksa ,oa tho
tUrqvksa dks izkd`rokl iznku djrs gSaA ;g jkT; ns'k dh nks ifo=re ufn;ksa xaxk rFkk ;equk dh
mn~xe LFkyh ds vfrfjDRk vius rhFkZ LFkyksa ,oa ioZrh; lqUnjrk ds fy;s Hkh fo[;kr gSA
bl jkT; dh fo'ks"krk ;gka ds fuokfl;ksa dk izd`fr ds lkFk ,d ifo= lEcaËk gSA tSo fofoËkrk dk
laj{k.k ;gka ds yksxksa ds thou&;kiu dh i)fr rFkk izd`fr ds lkFk lkeUtL; mudh lkaLd`frd
fojklr gSA ;gkW ds fuokfl;ksa }kjk yxHkx 1500 izdkj ds fofHkUu vkS"kËkh; ikSËkksa dk bLrseky
ijEijkxr :Ik ls vius rFkk ?kjsyw i'kqvksa ds fofHkUu jksxksa ds mipkj gsrq fd;k tkrk jgk gSA miyCËk
vkS"kËkh; ouLifr;ksa dks fpfdRlk gsrq ijEijkxr :Ik ls mi;ksx dj LoLFk jgus dh dyk ;gkW dh
lakLd`frd ijEijk dk vfHkUu vax gSA
tSo fofoËkrk vfËkfu;e 2002 dh Ëkkjk 41¼1½ ds vuqlkj izR;sd LFkkuh; fudk; ds Lrj ij tSo
fofoËkrk izcUËk lfefr dk xBu visf{kr gSA jkT; ds 7227 xzke iapk;rksa ds vfrfjDr 'kgjh {ks=ksa
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 8 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

vii

Introduction
In simple language, the word “Bio-diversity” encompasses the variety of all life forms on
earth. Scientists have estimated that there are about 1.0 to 1.50 crore species living on our
planet, out of which about 18 lakh species have so far been identified by the scientists. At
present, about 727 crore human population resides on earth. It has been estimated that
there is an annual global increase of about 8 crore population. Therefore, there is an increase
of about 100 crore population in every 12 years period. It has also been estimated that by
the year 2050, the world population may cross 1000 crore. Several recent scientific studies
indicate that earth resources are enough to sustain about 300 crore human population. As
a result of cumulative anthropogenic pressure on earth, we are losing our precious natural
and bio-resources.
Dwindling biological resource due to anthropogenic pressure led to the establishment
of Convention on Biological Diversity (CBD) at Rio de Janeiro in Brazil during ‘Earth
Summit’ in 1992. The CBD came into force in 1993 and 194 countries including India are
party to this Convention. Conservation of Biodiversity, sustainable use of its components
and fair & equitable sharing of benefits arising from the use of Genetic Resources are the
three main objectives of CBD.
Despite having 2.7% of the land area, 4% of fresh water, 17 % of human and 18% of livestock
population of the world, India is one of the 17 identified mega bio-diverse countries of
the world. Undoubtedly, it is a matter of pride for all Indians. In view of the international
obligation and to achieve the three main objectives of the convention, Biological Diversity
Act, 2002 and Biological Diversity Rules, 2004 were notified by the Govt. of India. Its
implementation is to be carried out by three bodies functioning at three diﬀerent levels, i.e.
National Biodiversity Authority at the Central, State Biodiversity Boards at Provincial and
Biodiversity Management Committees at the local level.
Coming into existence on 9th November 2000, Uttarakhand is very rich in biodiversity.
Sprawling over an area of 53,483 Sq. km, the state has 13 Districts, 78 Tehsils, 95 Development
Blocks, 7227 Gram Panchayats and 15761 Villages. As per 2011 census, the state has a
population of 1.01 crore. About 71% of the total area of the state is forest land and 46% is
under forest cover. Several kinds of climate, topography and the altitude provide varied kinds
of habitat for flora & fauna. Apart from having the origin of Ganga and Yamuna, the two
most holy rivers, the state is also known for its pilgrimage and fascinating mountainscape.
The sacred relationship of the residents with nature is the speciality of the state. The
conservation of Biodiversity is an art of living and the harmony with nature is their cultural
heritage. Nearly 1500 species of medicinal plants have traditionally been used in folk system
of medicine for up keep of their health as well as their domesticated animals. The use of
plants as source of herbal medicine is very much prevalent in the traditional health care
systems as a part of their cultural landscape.
"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 9 -->

viii

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

esa fLFkr 03 uxj fuxe] 32 uxj ikfydk ifj"kn rFkk 30 uxj iapk;rksa esa Hkh tSo fofoËkrk izcUËk
lfefr dk xBu fd;k tkuk visf{kr gSA ;g ,d c`gn dk;ZØe gS ftlds fØ;kUo;u gsrq vfËkla[;
ekuoh; cy dh vko';drk gSA mDr vko';drk ds n`f"Vxr mRrjk[k.M 'kklu }kjk 'kklukns'k
la[;k% 1141/x-3-13-08(18)/2010 fnukad 19-11-2013 fuxZr djrs gq;s izHkkxh; oukfËkdkfj;ksa dks
muds vfËkdkfjrk {ks= ds vUrxZr uksMy vf/kdkjh rFkk fMIVh jsatj@ou nkjksxk vFkok ou j{kd
dks tSo fofoËkrk izcUËk lfefr dk lfpo ukfer fd;k x;k gSA
xzke iapk;r Lrj ij tSo fofoËkrk izcUËk lfefr xfBr fd;s tkus gsrq loZizFke xzke iapk;r vË;{k
}kjk xzke lHkk dh vke cSBd cqykdj 06 O;fDr;ksa dk p;u vke jk; ls fd;k tkuk pkfg,] ftlesa
de ls de 02 efgykvksa rFkk 01 vuqlwfpr tkfr@tutkfr dk izfrfufËkRo vo'; gksA rRi'pkr
mlh cSBd esa mDRk p;fur 06 lnL;ksa }kjk vius esa ls gh ,d vË;{k dks fuokZfpr fd;k tkuk
pkfg,A bl izdkj dqy 07 lnL;ksa okyh tSo fofoËkrk izcUËk lfefr esa uksMy vfËkdkjh@izHkkxh;
oukfËkdkjh }kjk ukfer 01 lfpo ds vfrfjDRk 02 efgyk rFkk 01 vuqlwfpr tkfr@tutkfr ds
lnL; rFkk 'ks"k 03 vU; lnL; gkasxsA
tSo fofoËkrk izcUËk lfefr dk eq[; dk;Z muds {ks=kUrxZr ik;h tkus okyh lHkh izdkj dh tSo
fofoËkrk dk vfHkys[khdj.k ^^yksd tSo fofo/krk iaftdk** esa djuk gSA bl iaftdk ds fu:i.k gsrq
foLr`r fn'kk&funsZ'k jk"Vªh; tSo fofoËkrk izkfËkdj.k] psUubZ }kjk fuxZr fd;s x;s gSaA blds vfrfjDr
lfefr }kjk ^^tSo lkaLd`frd leqnk; lays[k^^ Hkh fu:fir fd;k tkuk visf{kr gSA ;g ,d ,slk
vkpkj vfHkys[k gS ftlesa lfefr }kjk vius {ks= ds fofHkUu fo"k;ksa ;Fkk ikfjfLFkfrdh] laLd`fr o
vË;kRe] ikjEifjd Kku rFkk lalkËkuksa ls lEcafËkr izpfyr LFkkuh; izFkk dks vfHkfyf[kr fd;k tkrk
gSA blds vfrfjDRk lays[k esa ogkW miyCËk tSo lalkËkuksa vFkok ikjEifjd Kku rd ckgjh O;fDr@
laLFkk }kjk igqWp@vfHkxE;rk ,oa ykHk ds izHkktu (Access & Benefit Sharing) dks fofu;fer fd;s
tkus gsrq Li"V fucaËku ,oa 'krksZa dk izkoËkku Hkh fd;k tkrk gSA ^^tSo lalk/ku^^ dk rkRi;Z ikSËks]
tho&tUrq vkSj lw{e tho ;k muds Hkkx lfgr vkuqokaf'kd inkFkZ ¼ewY;ofËkZr mRiknksa rFkk ekuoh;
vkuqokaf'kd inkFkksaZ dks NksM+dj½ ls gSA
vkuqokaf'kd lalkËkuksa rd igqWp rFkk ykHk dk izHkktu oLrqr% mi;ksxdrkZvksa rFkk tSo lalkËku
iznkrkvksa ds eË; ,d ,slk le>kSrk gS ftlesa mi;ksxdrkZ vkuqokaf'kd lalkËkuksa rd igqWp gsrq mlds
iznkrkvksa dks ykHk dk mfpr ,oa U;k;iw.kZ cWVokjk djus ij lgefr O;Dr djrk gSA vkuqokaf'kd
lalkËkuksa rd igqWp gsrq bPNqd fdlh O;fDr ;k laLFkk ¼mi;ksxdrkZ½ dks mi;ksx ls iwoZ ml LFkkuh;
fudk; ¼iznkrk½] tgkW vkuqokaf'kd lalkËku miyCËk gS] ls ^^iwoZ lwfpr lgefr^^ (Prior Informed
Consent) izkIr djuk vko';d gSA rRi'pkr mi;ksxdrkZ rFkk iznkrk vkilh lgefr ls fu;e o 'krsZa
fuËkkZfjr djrs gSa ftls ^^ijLij lger 'krZ^^ (Mutually Agreed Term) dgrs gSaA ykHk ds cWVokjs ds
fofHkUu :Ik tSls jkW;YVh] la;qDr m|e] izkS|ksfxdh gLrkUrj.k] {kerk fodkl vkfn gks ldrs gSA bl
izdkj tSo fofoËkrk izcUËk lfefr ^^tSo lkaLd`frd leqnk; lays[k^^ fodflr dj ykHkkfUor gks ldrs
gSaA mDr izfØ;k ls izkIr Ëkujkf'k dk mi;ksx lfefr }kjk {ks= ds tSo fofoËkrk laj{k.k ls lEcafËkr
dk;ksZ gsrq fd;k tk ldsxkA
¼/kuat; izlkn½
mi&funs'kd
mRrjk[k.M tSo fofoËkrk cksMZ

¼th0,l0 ikUMs½
lnL;&lfpo
mRrjk[k.M tSo fofoËkrk cksMZ

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 10 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

ix

As per section 41(1) of Biological diversity Act 2002, it is expected to create Biodiversity
Management committees (BMCs) at every local body level. Apart from 7227 Gram Panchayats,
BMCs also need to be created in 03 Municipal Corporations, 32 Municipal Councils, and 30
Urban Panchayats of the state. It is a vast programme requiring large number of human
resource. Keeping that in view, G.O. 1141/x-3-13-08(18)/2010 dated 19.11.2013 was issued
by the Government of Uttarakhand vide which the Divisional Forest Officers within their
area of jurisdiction have been declared/nominated as Nodal Officers whereas Deputy Ranger/
Forester or Forest Guard have been declared as Secretary of the BMCs.
For constituting BMC at Gram Panchayat level, first of all, a general body meeting shall
be called up by the Pradhan of that Gram Panchayat in which 06 members including 02
women and 01 person belonging to SC/ST category shall be nominated. Thereafter, the 06
nominated members shall elect a Chairperson from amongst themselves in the same meeting.
In this manner, the 07 members Biodiversity Management Committee shall be constituted
representing 02 women members, 01 member belonging to SC/ST category, 01 Secretary
nominated by the Nodal Officer/D.F.O and 03 other members.
The main function of the BMC is to document all kinds of biological resource present in
their area in “Peoples Biodiversity Register”. The term “Biological resource” includes plants,
animals and micro organisms or parts thereof, their genetic material and by-products
(excluding value added products and human genetic material). Detailed guidelines have
been issued by National Biodiversity Authority, Chennai for the preparation of Peoples
Biodiversity Register. In addition to that, the committee is also expected to develop “Biocultural Community Protocol” (BCP). In the protocol diﬀerent features of the area such as
ecology, culture and spirituality, traditional knowledge and local traditions related to the
use of bio-resources are documented. Apart from this, clear terms and conditions are also
provided to regulate the access and benefit sharing mechanism.
Access to genetic resource and benefit sharing is a kind of agreement between the user and
the provider of biological resource, in which the user agrees to share benefits with its provider
in lieu of providing access to genetic material. It is mandatory for any interested person/
institution (user) to have “Prior Informed Consent” (PIC) for commercial use of biological
resource from its provider (where genetic material is available). Thereafter, the user and the
provider agree by mutual consent to certain terms and conditions known as “Mutually Agreed
Term” (MAT). There can be diﬀerent mode of sharing benefits like royalty, joint venture,
technology transfer, capacity and skill development etc. In this manner, the Biodiversity
Management Committee can be benefited by developing Bio-cultural Community Protocol.
The fund generated by way of ABS shall be deposited in the local Biodiversity fund of BMC
which shall be utilized for conserving the Biodiversity and related activities of the area.
(Dhananjay Prasad)
Deputy Director
Uttarakhand Biodiversity Board

(G.S. Pande)
Member-Secretary
Uttarakhand Biodiversity Board

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 11 -->

fo"k;&lwph
Table of Contents
fooj.k

Particulars

1.1

1.2

1.3

Hkkx&I% lapkyu gsrq :i&js[kk
Section I: Operational Aspects

2

izkd`frd lalk/ku ds izcU/ku ls lEcfU/kr vU; xzke Lrjh; lfefr;ksa
dks tSo fofo/krk izcU/k lfefr ds lkFk ,dhd`r fd;k tkuk

2

lapkyu ds fy, le; vof/k

4
5
4
5
4
5
4

Role of SBBs, Institutions and Civil Society in the
formation of BMCs

Integration of BMCs to other village level committees
related to Natural Resources Management

tSo fofo/krk izcU/k lfefr dk dk;kZy;

Office of the BMC
1.5

tSo fofo/krk izcU/k lfefr dk dk;Z&dky

Tenure of the BMC
1.6

tSo fofo/krk izcU/k lfefr dh 'kq:vkrh fuf/k voeqDr djus
lEcU/kh dk;Ziz.kkyh
Methodology of BMC startup fund release

1.7
1.8

tSo fofo/krk izcU/k lfefr;ksa dh Hkwfedk ,oa d`R;

Roles and functions of the BMCs

tSo fofo/krk izcU/k lfefr dh cSBdsa

Meetings of the BMCs
1.9

tSo fofo/krk izcU/k lfefr dh cSBdksa ds dk;Zo`RRk

Minutes of the BMC Meetings
1.10

tSo fofo/krk izcU/k lfefr dh dk;Z ;kstuk

BMC Action Plan
1.11

Page No.

tSo fofo/krk izcU/k lfefr ds xBu esa jkT; tSo fofo/krk
cksMksZa] laLFkkuksa rFkk lH; lekt dh Hkwfedk

Time period for operationalization
1.4

i`"B la-

tSo fofo/krk vf/kfu;e rFkk tSo fofo/krk izcU/k lfefr
lEcUËkh {kerk fodkl

Capacity Building on BD Act and BMCs

3

3

5
6
7
6
7
6
7
8
9
8
9

<!-- page 12 -->

Hkkx II % foRrh; i{k

2.1
2.2

Section II : Financial Aspects

tSo fofo/krk izcU/k lfefr gsrq foRrh; lalk/ku

12

Financial Resources for BMCs

13
12

tSo fofo/krk izcU/k lfefr dk foRr iks"k.k rFkk [kkrksa dk
j[k&j[kko

Funding BMCs and maintenance of their accounts
2.3

/ku dh vfHkj{kk

Custody of Funds
2.4

tSo fofo/krk izcU/k lfefr ds O;; lEcU/kh dk;Z&iz.kkyh

Modus operandi of Expenditure for BMC
2.5

2.6

2.7

yksd tSo fofo/krk jftLVj ds O;; lEcU/kh dk;Z&iz.kkyh
Modus Operandi of Expenditure for People’s Biodiversity
Register

18

Signing of Cheques and support for member of the
Permanent Establishment

19

jksdM+ cgh&[kkrk

18
19
18
19
18
19
18
19
20

O;; ij fu;a=.k

Control of Expenditure
2.9

cSad ls iqu% feyku dk fooj.k

Bank Reconciliation Statement
2.10

O;; dk fooj.k

Statement of expenditure
2.11

17

psd ij gLrk{kj rFkk LFkk;h vf/k"Bku ds lnL;ksa gsrq lgk;rk

Cash Book
2.8

13
14
15
16
17
16

tSo fofo/krk izcU/k lfefr;kW rFkk tSo lalk/ku rd igqWp]
'kqYd vf/kjksi.k rFkk ykHk dk izHkktu

BMCs and Access to Biological Resources, Levy and
Benefit Sharing

21

Hkkx III % rduhdh i{k

3.1

Section III : Technical Aspects

Hkkjrh; lafo/kku dh NBh vuqlwph ls vkPNkfnr {ks=
Areas covered by the 6 Schedule of Indian Constitution
th

22
23

<!-- page 13 -->

3.2

3.3

tSo fofo/krk izcU/k lfefr dks lqn`<+ cukus gsrq rduhdh
lgk;rk lewg

22

Technical Support Groups (TSG) for strengthening BMCs

23
24
25
24

vuqJo.k

Monitoring
3.4

yksd tSo fofo/krk iaftdk dh vfHkj{kk ,oa rRlEcU/kh lwpuk
Custody of PBRs and information therein

3.5

tSo fofo/krk izcU/k lfefr rFkk tSo fofo/krk fojklr LFky

BMCs and Biodiversity Heritage Sites
3.6

fooknksa dk lek/kku

Resolution of Disputes

25
24
25
24
25

fofHkUu ,usDlj dk uewuk izk:i

Model Formats as Annexures

,usDlj 1

xzke iapk;r Lrj ij tSo fofo/krk izcU/k lfefr ds izLRkko dk
uewuk

26

Annexure 1

Model BMC Resolution at Gram Panchayat Level

,usDlj 2

fodkl[k.M@rglhy Lrj ij tSo fofo/krk izcU/k lfefr ds
izLrko dk uewuk

27
30

Annexure 2

Model BMC Resolution at Block/Tehsil Level

,usDlj 3

ftyk iapk;r Lrj ij tSo fofo/krk izcU/k lfefr ds izLrko
dk uewuk

Annexure 3

Model Resolution at Zilla Panchayat Level

,usDlj 4

uxjikfydk ifj"kn Lrj ij tSo fofo/krk izcU/k lfefr ds
izLrko dk uewuk

Annexure 4

Model Resolution of Municipal Council

,usDlj 5

uxj fuxe Lrj ij tSo fofo/krk izcU/k lfefr ds izLrko dk
uewuk

Annexure 5

Model Resolution of Municipal Corporation

,usDlj 6

tSo fofo/krk izcU/k lfefr dh cSBdksa ds dk;Zo`Rr dk izk:i

Annexure 6

Format for recording Minutes of BMC Meetings

,usDlj 7

tSo fofo/krk izcU/k lfefr ds okf"kZd fjiksVZ gsrq uewus dk izk:i

Annexure 7

Model Annual Report format for Biodiversity
Management Committee (BMC)

31
34
35
38
39
42
43
46
47
48
49

<!-- page 14 -->

50

Annexure 8

tSfod lalk/kuksa dk bLrseky dj jgs oS|ksa ,oa O;olkf;;ksa ds
fy, izk:i

Format for Vaids and practitioners making use of
biological resources

51

,usDlj 9

52

Annexure 9

tSfod lalk/kuksa rFkk ikjaifjd Kku rd igqWp vuqeU; djus
lEcU/kh lwpukvksa ds vfHkys[khdj.k dk izk:i

Format for recording information related to access of
biological resources and traditional knowledge granted

,usDlj 10

O;; jftLVj & izek.k i=

,usDlj 11

izkfIr

,usDlj 12

pSd@Mªk¶V jftLVj

,usDlj 13

fcy jftLVj

,usDlj 14

uxn Hkqxrku izek.k i=

,usDlj 15

pSd Hkqxrku izek.k i=

,usDlj 16

izek.k i= jftLVj

,usDlj 17

jksdM+ cgh

,usDlj 18

cSad fooj.kh dk iqu% feyku

,usDlj 19

cgh&[kkrk jftLVj

,usDlj 20

uksMy vfËkdkjh ,oa lfpo ukfer fd;s tkus lEcUËkh 'kklukns'k

,usDlj 21

O;; dk fooj.k

,usDlj 22

mi;ksfxrk izek.k&i=

54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79

,usDlj 8

Annexure 10 Expenditure Register Certificate
Annexure 11 Receipt
Annexure 12 Cheque/Draft Register
Annexure 13 Bill Register
Annexure 14 Cash Payment Certificate
Annexure 15 Cheque Payment Certificate
Annexure 16 Certificate Register
Annexure 17 Cash Book
Annexure 18 Bank Reconciliation Statement
Annexure 19 Journal Register

Annexure 20 G.O. for Nomination of Nodal Officer and Secretary
Annexure 21 Statement of Expenditure
Annexure 22 Utilization Certificate

53

<!-- page 15 -->

2

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

Hkkx&1 % lapkyu dk Lo:i
1-1 tSo fofoèkrk izcUèk lfefr ds xBu esa jkT; tSo fofoèkrk cksMksZa] laLFkkuksa rFkk lH;
lekt dh Hkwfedk
jkT; ,oa LFkkuh; ifjfLFkfr;ksa dh vko';drkvksa dks iw.kZ djus rFkk izHkkoh ijke'khZ izfØ;k
lqfuf'pr djus ds fy, tSo fofoèkrk izcUèk lfefr ds xBu dh izfØ;k esa xzke lHkk ds
vkfnoklh lewgksa rFkk vU; misf{kr leqnk;ksa lfgr lHkh fgr èkkjdksa dks lgHkkxh cuk;k tk;sxkA
tSo fofoèkrk izcUèk lfefr dk xBu laLFkkuksa ;k lH; lkekftd laxBuksa vFkok rduhdh
lgk;rk lewg dh eè;LFkrk ls laHko gks ldrk gSA tSo fofoèkrk lEIkUu laHkkfor {ks=ksa rFkk
,sls LFkkuks tgka yksdfiz; vfHk:fp vFkok leFkZu ifjyf{kr gks] dh igpku dj tSo fofoèkrk
izcUèk lfefr;k¡ LFkkfir dh tk,A tSo fofoèkrk izcUèk lfefr;ksa ds xBu gsrq lnL; lfpo dks
jkT; tSo fofoèkrk cksMZ ls vuqeksnu ysuk pkfg,A TkSo fofoèkrk izcUèk lfefr;ksa dh igpku]
xBu rFkk lapkyu esa rduhdh lgk;rk lewg }kjk gj laHko lgk;rk iznku dj ldrh gSaA
tSo fofoèkrk izcUèk lfefr ds xBu gsrq fuèkkZfjr fufèk ds dqN izfr'kr Hkkx dh
vko';drk jkT; tSo fofoèkrk cksMksZa dks gks ldrh gSA buesa jkT; tSo fofoèkrk cksMZ
}kjk tSo fofoèkrk izcUèk lfefr ds xBu gsrq laHkkfor {ks=ksa dh igpku djus esa lH; lkekftd
laxBuksa rFkk rduhdh lgk;rk lewgksa dks lgHkkxh cukus tSls O;; lfEefyr gks ldrs gSaA
izkd`frd lalkèkuksa ds izcUèku ls lEcfUèkr vU; xzke Lrjh; lfefr;ksa dks tSo fofoèkrk izcUèk
lfefr ds lkFk ,dhd`r djus gsrq LFkkuh; fudk; iz;kl djsxkA

1-2 izkd`frd lalkèku ds izcUèku ls lEcfUèkr vU; xzke Lrjh; lfefr;ksa dks tSo fofoèkrk
izcUèk lfefr ds lkFk ,dhd`r fd;k tkuk
LFkkuh; fudk; }kjk tSo fofoèkrk izcUèk lfefr esa LFkkuh; ifjfLFkfr;ksa ds vkèkkj ij ou@
izkd`frd lalkèkuksa ds izcUèk lfefr;ksa ds lnL;ksa ftles ckxokuh@oS|@ouLifr foKkuh@
vkfnoklh izeq[kksa vkfn dks lfEefyr djrs gq;s xfBr fd;k tk;sxkA jkT; tSo fofoèkrk cksMZ
}kjk tSo fofoèkrk izcUèk lfefr esa lfEefyr fd;s tkus okys O;fDr;ksa dh lq>ko&lwph fuxZr
dh tkuh pkfg,A LFkkuh; vko';drkvksa dks iw.kZ djus gsrq izfrfufèkRo yphyk gksuk pkfg,A
tSo fofoèkrk izcUèk lfefr lEcfUèkr ljdkjksa dh oSèkkfud 'kfDr;ksa@iz'kklfud vkns'kksa ls
xfBr ekStwnk lfefr;ksa ds lnL;ksa esa ls Hkh vius lnL;ksa dk p;u dj ldrh gSaA

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 16 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

3

SECTION–1 : OPERATIONAL ASPECTS
1.1 Role of State Biodiversity Boards, Institutions and Civil Society in the
formation of Biodiversity Management Committees
The process of BMC formation would involve all the stakeholders in the Gram Sabha
including tribal groups and other marginalized communities to ensure an eﬀective
consultative process to meet the requirements of the state and local conditions.
Biodiversity Management Committees formation can possibly be mediated
through institutions or civil society organizations or Technical Support Group
(TSGs). Potential areas rich in biodiversity and locations where there is popular
interest or support should be identified and BMCs established. The MemberSecretary should get approval from the State Biodiversity Board for forming BMCs.
Technical Support Groups can extend all possible help in identification, formation
and operationalization of BMCs.
The State Biodiversity Boards may require a percentage of the funds earmarked for
the establishment of each Biodiversity Management Committees. This may include
costs incurred by the SBBs in involving civil society organizations and TSGs in
identifying potential areas for BMC formation.
The Local body shall make eﬀorts to integrate BMCs to other village level committees
related to natural resources management.

1.2 Integration of Biodiversity Management Committees to other village
committees related to natural resource management
The Biodiversity Management Committees will be constituted by the local body
with members of the participatory forest/natural resources management committee
members, including from members of Horticulture/Vaids/ Foot Botanist/Tribal
heads etc. based on the local conditions. The SBB should issue suggestive list of
persons to be included in the BMC. The representation may be flexible to meet the
local requirements.
The Biodiversity Management Committees may also draw its members from
amongst the existing committees which have been formed under statutory powers/
administrative orders of the respective Governments.
"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 17 -->

4

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

1-3 lapkyu ds fy, le; vofèk
TkSo fofoèkrk izcUèk lfefr ¼ch-,e-lh-½ xfBr gksus ds i'pkr gh blds lapkyu dk dk;Z 'kh?kz
izkjEHk gksuk pkfg, rFkk 12 ekg vofèk esa gh fofHkUu dk;ksZa dks iw.kZ fd;k tk;sA ch-,e-lh- dh
'kq:vkr gsrq fuèkkZfjr fufèk dh cpr 'ks"k èkujkf'k dks ch-,e-lh- }kjk ckn esa mi;ksx esa yk;k
tk ldrk gSA Lohd`r vuqnku ds 50 izfr'kr Hkkx dks cSad [kkrs esa lqjf{kr dj mlds C;kt
dk mi;ksx xfrfofèk;ksa dks lapkfyr fd;s tkus gsrq ch-,e-lh- dks vfèkd`r fd;k tk ldrk gSA

1-4 tSo fofoèkrk izcUèk lfefr dk dk;kZy;
LFkkuh; fudk; }kjk miyCèk djk;s x;s dk;kZy; ifjlj ls dk;Z lapkfyr fd;k tk;sxkA

1-5 tSo fofoèkrk izcUèk lfefr dk dk;Z&dky
tSo fofoèkrk izcUèk lfefr dk dk;Zdky ikWp o"kZ@LFkkuh; fudk; ds dk;Zdky ds le:i gksxk]
;|fi ubZ lfefr ds xBu gksus rd iwoZ xfBr tSo fofoèkrk izcUèk lfefr] dk;Z djrh jgsxhA

1-6 tSo fofoèkrk izcUèk lfefr dh 'kq:vkrh fufèk voeqDr djus lEcUèkh dk;Ziz.kkyh
izR;sd jkT; tSo fofoèkrk cksMZ tSo fofoèkrk le`f) rFkk lkekftd :i ls tkx:d {ks=ksa ds
vkèkkj ij jkT; esa LFkkfir fd;s tkus okys tSo fofoèkrk izcUèk lfefr;ksa dh okLrfod la[;k
fuèkkZfjr djsxkA jk"Vªh; tSo fofoèkrk izkfèkdj.k vius Hkkx dh èkujkf'k jkT; tSo fofoèkrk
cksMZ ls izkIr vuqjksèk ds vuq:i voeqDr djsxkA jkT; tSo fofoèkrk cksMZ dks ;g lykg nh
tkrh gS fd izR;sd tSo fofoèkrk izcUèk lfefr ls O;; dk fooj.k ,oa mi;ksfxrk izek.k i=
izkfIr ds mijkUr 2 ls 4 fdLrksa esa èkujkf'k voeqDr djasA jkT; tSo fofoèkrk cksMZ }kjk fcy
dh izfr izkfIRk gsrq ckè; ugha djuk pkfg,A
Ø-la-

en

1
2

cSad esa [kkrk [kksyus ij
LVs'kujh lfgr vU; dk;kZy;
midj.k [kjhnus gsrq
cSBd djkus gsrq ¼2 cSBd izfr o"kZ½
ch-,e-lh- dks 01 izf'k{k.k&xzke
iapk;r {ks= dh lkekU; tSo
fofoËkrkvksa dh tkudkjh
tSo fofo/krk izcU/k lfefr dk xBu
'kq:vkrh fuf/k ¼;ksx½

3
4

5

iapk;r Lrjh; CykWd Lrjh;
ftyk Lrjh;
ch-,e-lh ¼` esa½ ch-,e-lh ¼` esa½ ch-,e-lh ¼` esa½
10,000

13,344

16,600

15,000

20,000

25,000

3,000

4,000

5,000

7,000

9,328

11,740

25,000

33,328

41,660

60,000

80,000

1,00,000

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 18 -->

5

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

1.3 Time period for operationalization
Once a Biodiversity Management Committees (BMC) is formed, its operation
should commence immediately and a set of tasks completed in a period of 12
months. Any, unspent part of the startup BMC fund BMC may be utilized at a later
date. BMCs may be authorized to retain up to 50% of the sanctioned grant amount
and make use of the interest for conducting their activities.

1.4 Office of the BMC
The BMC will function from the office premise to be provided by the local body.

1.5 Tenure of the BMC
The tenure of the BMC will be five years/co-terminus with the tenure of the local
body however; the existing BMC will continue to operate, until a new committee is
constituted.

1.6 Methodology of BMC Startup Fund Release
Each State Biodiversity Board shall arrive at a realistic number of BMCs to be
established in the state based on biodiversity rich areas and socially conscious areas.
The National Biodiversity Authority (NBA) on its part shall release the amount
requested by the State Biodiversity Boards (SBBs). The SBBs are advised to release
the amount to each BMC in installments (2 - 4 Installments) after obtaining a
Statement of Expenditure and Utilization Certificate (UC). No copies of bills should
be insisted upon by the SBBs.
No

Item

Village Level
BMC (In `)

Block Level
BMC (In `)

District Level
BMC (In `)

1

On opening of Bank Account

10,000

13,344

16,600

2

Purchase of Office Equipment
including Stationary

15,000

20,000

25,000

3

Conduct of meetings

3,000

4,000

5,000

4

One training to BMC and
Panchayat general BD Profile

7,000

9,328

11,740

5

Formation of BMC

25,000

33,328

41,660

Startup Fund (Total)

60,000

80,000

1,00,000

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 19 -->

6

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

1-7 tSo fofoèkrk izcUèk lfefrvksa dh Hkwfedk ,oa d`R;
yksd tSo fofoèkrk iaftdk fu:fir fd;s tkus ds vfrfjDr tSo fofoèkrk izcUèk lfefr;k¡
fuEufyf[kr esa lgHkkfxrk lqfuf'pr djsxh&
• tSfod lalkèkuksa dk laj{k.k ,oa iks"k.kh; mi;ksxA
• LFkkuh; tSo fofoèkrk dh iqoZ voLFkk ikfjfLFkfrdh cgkyhA
• Tkgka rd lEHko gks] jkT; tSo fofoèkrk cksMZ dks ckSf)d lEink vfèkdkj] ikjEifjd Kku
rFkk tSo fofoèkrk ls lEcfUèkr LFkkuh; eqn~nksa ij lEcfUèkr izfrfØ;k@lwpuk nsuk rFkk
jk"Vªh; tSo fofoèkrk izkfèkdj.k dks vko';d izfrfØ;k@lwpuk miyCèk djkukA
• fojklr LFkyksa lfgr fojklrh; o`{kksa] i'kqvksa@lq{e thoksa vkfn rFkk ifo= ouksa ,oa ifo=
ty fudk;ksa dk izcUèkuA
• okf.kfT;d ,oa vuqlaèkku iz;kstuksa ds fy, tSfod lalkèkuksa rFkk@vFkok lac) ikjaifjd
Kku rd igqap dk fofu;euA
• tSo lalkèkuksa ds okf.kfT;d mi;ksx ls mRiUu ykHk dk izHkktuA
• vkfFkZd :i ls egRoiw.kZ ouLifr;ksa@tho&tURkqvksa ds ikajifjd fdLeksa@uLyksa dk
laj{k.kA
• tSo fofoèkrk lEcUèkh f'k{kk ,oa tkx:drk dks c<kok nsukA
• izys[ku rFkk tSo lkaLd`frd izksVksdkWy fodflr djus dh izfØ;k dks lkeF;Zoku cukukA
• iks"k.kh; mi;ksx rFkk ykHk dk izHkktuA
• yksd tSo fofoèkrk iaftdk esa vfHkfyf[kr ikjaifjd Kku dk laj{k.kA

1-8 tSo fofoèkrk izcUèk lfefr dh cSBdsa
tSo fofoèkrk izcUèk lfefr o"kZ esa de ls de 04 ckj rFkk 03 ekg esa de ls de ls ,d ckj
cSBdksa dk vk;kstu djsxkA
cSBdksa dh vè;{krk tSo fofoèkrk izcUèk lfefr ds vè;{k rFkk muds@mudh vuqifLFkfr esa
mifLFkr lnL;ksa esa ls pquk x;k lnL; djsxkA
izR;sd cSBd gsrq vè;{k lfgr rFkk vkfèkdkfjd lnL; dks NksM+dj x.kiwfrZ dh la[;k 03
gksxhA

1-9 tSo fofoèkrk izcUèk lfefr dh cSBdksa ds dk;Zo`RRk
tSo fofoèkrk izcUèk lfefr dh cSBdksa ds dk;Zo`RRk@dk;Zokgh rS;kj dj LFkkuh; fudk;@
uksMy vfèkdkjh dks izsf"kr fd;k tk;sxkA jkT; tSo fofoèkrk cksMZ }kjk cSBdksa ds dk;Zo`RRk]
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 20 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

7

1.7 Roles and Functions of the BMCs
The BMCs would, in addition to the preparation of the People’s Biodiversity Register
(PBR), participate in ensuring:
•

Conservation and sustainable utilization of biological resources.

•

Eco-restoration of the local biodiversity.

•

Proper feedback to the SBB in the matter of IPR, Traditional Knowledge
and local Biodiversity issues, wherever feasible and essential feedback to be
provided to the NBA.

•

Management of Heritage Sites including Heritage Trees, Animals/Micro
organism etc., and Sacred Groves and Sacred Water bodies.

•

Regulation of access to the biological resources and/ or associated Traditional
Knowledge, for commercial and research purposes.

•

Sharing of usufructs arising out of commercial use of bio-resources.

•

Conservation of traditional varieties/breeds of economically important plants/
animals.

•

Biodiversity Education and Awareness building.

•

Documentation, enable procedure to develop Bio-cultural protocols.

•

Sustainable Use and Benefit Sharing.

•

Protection of Traditional knowledge recorded in PBR.

1.8 Meetings of BMCs
BMC shall hold a minimum of 4 meetings in a year, and meet once at least in every
3 months.
The meetings shall be chaired by the Chairperson of the BMC, and in his/her
absence, by any other member elected by the members present.
The quorum at every meeting shall be three including the Chairperson and excluding
official members.

1.9 Minutes of the BMC Meetings
Minutes/proceedings of the BMC Meetings will be drawn and submitted to the
local body/Nodal Officer. The State Biodiversity Board shall provide a format for
"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 21 -->

8

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

cSBd lEcUèkh jftLVjksa ds j[kj[kko] jftLVjksa dks v|ru fd;s tkus lEcUèkh izfØ;k fuèkkZfjr
djus o cSBdksa esa gq;s fopkj&foe'kZ lEcUèkh vfHkys[k] ikfjr izLrkoksa] vkWfMV vkfn izysf[kr
fd;s tkus dk izk:i miyCèk djk;k tk;sxk] ftlls tSo fofoèkrk izcUèk lfefr Lrj ij
izys[ku dh izfØ;k lqfoèkktud gksxh ¼ns[ksa ,usDlj 6½A

1-10 tSo fofoèkrk izcUèk lfefr dh dk;Z ;kstuk
izR;sd tSo fofoèkrk izcUèk lfefr vuqeU; fd;s x;s yksd tSo fofoèkrk iaftdk ls izkIr lwpuk
ds vkèkkj ij ,d dk;Z ;kstuk rS;kj djsxkA rduhdh lgk;rk lewg dk;Z ;kstuk fodflr
djkus esa ekxZn'kZu iznku djsxkA tSo lalkèkuksa ds laj{k.k gsrq mfYyf[kr mik;ksa ds vfrfjDr
dk;Z ;kstuk esa tSo fofoèkrk izcUèk lfefr dfeZ;ksa ds izf'k{k.k dh vko';drk dh igpku rFkk
lEHkkfor oLrqvksa dh lwph dks HkkSxksfyd ladsrd ds :i esa iathdj.k lEcUèkh fopkj dks Hkh
lfEefyr fd;k tk ldrk gSA
LFkkuh; tSo fofoèkrk ds iks"k.kh; mi;ksx lfgr vkS"kèkh; ikSèkksa rFkk lEc) ikajifjd Kku ds
izcUèku gsrq lq{e ;kstuk fodflr djukA

1-11 tSo fofoèkrk vfèkfu;e rFkk tSo fofoèkrk izcUèk lfefr lEcUèkh {kerk fodkl
tSo fofoèkrk vfèkfu;e] 2002 ls lEcfUèkr tkx:drk fodkl] blds foLrkj ,oa tSo fofoèkrk
izcUèk lfefr;ksa ds lapkyu gsrq fof'k"V eqn~nksa ds fufgrkFkZ fuEuor~ lfEefyr gks ldrs gSa&
¼d½ tSo fofoèkrk vfèkfu;e 2002 ds lEcUèk esa tkx:drk QSykuk] tSo fofoèkrk izcUèk
lfefr dh Hkwfedk] vU; lEcfUèkr foHkkxks ;Fkk ou] i;kZoj.k] tutkfr dY;k.k] xzkeh.k
fodkl] Ñf"k] ckxokuh] i'kqikyu] eRL; rFkk typj ikyu] eqxhZikyu] LokLFk] LFkkuh;
fpfdRlk fofèk] f'k{kk vkfnA
¼[k½ vfèkfu;e lEcUèkh tkx:drk fodkl] o`gn Lrjh; tSo fofoèkrk laj{k.k ls lEcfUèkr
fu;e ,oa laLFkkuA
¼x½ jkT;] ftyk rFkk LFkkuh; fudk;ksa ds fuokZfpr izfrfufèk;ksa lfgr ljdkjh rFkk xSj
ljdkjh laLFkkvksa esa izR;sd Lrj ij {kerk fodklA
¼?k½ jkT; tSo fofoèkrk cksMZ }kjk fpfUgr tSo fofoèkrk izcUèk lfefr ds lnL;ksa dh {kerk
,oa dk;Zdq'kyrk dk fodkl&
• yksd tSo fofoèkrk iaftdk rS;kj djukA
• tSo fofoèkrk izcUèk lfefr dh iz'kklfud izfØ;kA
• ys[kk@ys[kk ijh{kk dk vuqj{k.kA
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 22 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

9

drafting of minutes of the meetings, maintenance of meeting register and alike; lay
down the procedures for updating the registers & record of discussions, resolution
made, audit etc., which would facilitate Process Documentation at the BMC level
(see Annexure 6).

1.10 BMC Action Plan
Each BMC shall prepare an Action Plan, drawing information validated in the
People’s Biodiversity Register. The Technical Support Group (TSG) shall guide in
the preparation of the action plan. The Action Plan may include in addition to the
steps outlined for conservation of the bio-resources, the training needs identified
for the personnel of the BMC and the list of potential items for consideration for
registration as Geographical Indicators (G.I.).
To draw a management micro plan for the sustainable use of local biodiversity
including medicinal plants and associated traditional knowledge.

1.11 Capacity Building on BD Act and BMCs
Awareness Building on Biological Diversity Act 2002, its scope and implications
with issues specific to operation of Biodiversity Management Committees (BMCs),
may include:
a) Awareness building on the Biodiversity Act 2002, the role of Biodiversity
Management Committees, the procedure, the role of BMCs with various associated
departments of the Government such as Forest, Environment, Tribal Welfare,
Rural Development, Agriculture, Horticulture, Animal Husbandry, Fisheries and
Aquaculture, Poultry, Heath, Local systems of Medicine, Education etc.
b) Awareness building on the Acts, Rules and Institutions pertaining to the
Conservation of Biodiversity at large.
c) Capacity Building at various levels of Government and Non-Government
Agencies including the elected representatives at state, District and Local levels.
d) Capacity Building and Skill development of BMC members as identified by
SBB. The areas of skill building may include:
•

Preparation of PBR

•

Administrative procedures of BMC

•

Maintenance of accounts/audit
"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 23 -->

10

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

•
•
•
•
•
•

ckSf)d lEink lEcUèkh eqn~nsA
igqWp rFkk ykHk ds izHkktu lEcUèkh eqn~nsA
'kqYd vfèkjksfir djukA
dk;Z;kstuk] izkstsDV fjiksVZ rFkk okf"kZd fjiksVZ rS;kj djukA
tSo fofoèkrk ls lEcfUèkr lHkh vfèkfu;e rFkk fu;ekoyhA
tSo fofoèkrk fojklrh; LFkyksa dk izcUèkuA

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 24 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

•

Intellectual Property Issues

•

Access and Benefit Sharing issues

•

Levy of fees

•

Preparation of Action Plan, Project Report, Annual Report

•

All Acts and Rules pertaining to Biodiversity

•

Management of Biodiversity Heritage Sites

"Biodiversity Conservation ..................... An art of living with nature"

11

<!-- page 25 -->

12

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

Hkkx&2% foRrh; i{k
2-1 tSo fofoèkrk izcUèk lfefr gsrq foRrh; lalkèku
tSo fofoèkrk izcUèk lfefr fuEuor~ Jksrks ls fufèk mRiUu djsxh&
¼d½ jk"Vªh; tSo fofoèkrk izkfèkdj.k] jkT; tSo fofoèkrk cksMZ rFkk jkT; ljdkj ls izkIr
vuqnku rFkk _.kA blds vfrfjDr tSo fofoèkrk izcUèk lfefr fofHkUu vU; Jksrksa]
ftlesa Hkkjr ljdkj rFkk jkT; ljdkj ds ykbZu foHkkxksa] dsUnzh; rFkk jkT; ds vU;
cksMksZa] laLFkkuksa ,oa fuxfer fudk;ksa vkfn lfEefyr gSa] ls fufèk izkIr dj ldrh gSA
¼[k½ 'kqYd] ykbZlsal 'kqYd] dj jksi.k] jkW;YVh vkfn vU; izkfIr;kWA
ikjnf'kZrk] vuqJo.k rFkk tk¡p ds mn~ns'; ls izR;sd tSo fofoèkrk izcUèk lfefr nksuksa Jsf.k;ksa
dh izkfIr;ksa gsrq cSad esa i`Fkd [kkrk laèkkfjr djsxhA

2-2 tSo fofoèkrk izcUèk lfefr dk foRr iks"k.k rFkk [kkrksa dk j[k&j[kko
jkT; tSo fofoèkrk cksMZ dh laLRkqfr ij jkT; ljdkj }kjk izR;sd ftys esa tSo fofoèkrk izcUèk
lfefr ls lEcfUèkr fofHkUu ekeyksa dh ns[k&js[k gsrq uksMy vfèkdkjh ukfer fd;s tk;sxsaA
LFkkuh; ifjfLFkfr;ksa ds izklafxd mi;qDr ykbZu foHkkx ds ,d vfèkdkjh dks uksMy vfèkdkjh
ds :i esa fu;qDr fd;k tk ldrk gS tks jkT; tSo fofoèkrk cksMZ dks fjiksVZ djsxkA ¼ns[ks
,usDlj 20½A
tSo fofoèkrk izcUèk lfefr }kjk fofHkUu Jksrksa tSls jk"Vªh; tSo fofoèkrk izkfèkdj.k] jkT; tSo
fofoèkrk cksMZ] vuqnku] nku] Hkkjr ljdkj rFkk jkT; ljdkj ds fofHkUu ykbZu foHkkx] dsUnzh;
rFkk jkT; ds vU; cksMksZa laLFkkuksa ,oa fuxfer fudk;ksa vkfn ls lalkèku izkfIr gsrq ,d dk;Z
;kstuk cuk;h tkuh pkfg,A
jk"Vªh; tSo fofoèkrk izkfèkdj.k] jkT; tSo fofoèkrk cksMZ ls 'kq:vkrh fufèk izkIr dh tk ldrh
gSA jkT; tSo fofoèkrk cksMZ ds foRr iks"k.k gsrq jkT; ljdkj ctV esa mi;qDr izkfoèkku dj
tSo fofoèkrk izcUèk lfefr;ksa dks jkT; tSo fofoèkrk cksMZ ds ekè;e ls foRrh; lgk;rk miyCèk
djk ldrh gSA
tSo fofoèkrk izcUèk lfefr }kjk cSad esa [kkrk [kkys tkus dks lqfoèkktud cukus gsrq jkT; tSo
fofoèkrk cksMZ ,d leFkZdkjh i= tkjh djsxk ftlesa tSo fofoèkrk izcUèk lfefr dk xBu tSo
fofoèkrk vfèkfu;e] 2002 ds vUrxZr gksus dk mYys[k gksxkA
jkT; tSo fofoèkrk cksMZ ch-,e-lh- dks lhèks èku miyCèk djk;sxk rFkk lEcfUèkr ftyk Lrjh;
uksMy vfèkdkjh@izHkkxh; oukfèkdkjh@ftyk iz'kklu@ftyk ifj"kn~ dks fofèkor lwfpr
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 26 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

13

SECTION–2 : FINANCIAL ASPECTS
2.1 Financial Resources for BMCs
BMCs shall generate funds through the following modes:
a) Receipts (grants and loans) from NBA, SBB and State Government. In addition,
BMCs may access funds from various sources including raising donations, line
departments of Government of India and State governments, other Central and
State Boards, institutions and corporate bodies.
b) Receipts from fee, license fee, levies, royalties and other receipts.
For purpose of transparency, monitoring and follow up, each BMC shall maintain
bank accounts separately for both categories of receipts.

2.2 Funding BMCs and maintenance of their accounts
The State Government on the recommendations of the SBB shall designate Nodal
officers for each of the districts to oversee the various matters of the BMC. An
officer from appropriate line department relevant to the local conditions may be
appointed as Nodal Officers, who will report to the SBB. (see Annexure 20)
BMC should draw a plan of Action for accessing resources from various sources
such as – NBA, SBB, Grants, Donations, Various line departments of Government
of India and the State Governments, other Central and State Boards, Institutions,
Corporate Bodies etc.,
Start up funds may be obtained from the National Biodiversity Authority (NBA),
State Biodiversity Board (SBB). The State government may make appropriate
provision in the budget for funding SBBs and provide financial support through
SBBs to the Biodiversity Management Committees.
The State Biodiversity Board (SBB) shall facilitate the BMC to open a Bank Account
with an Enabling letter that BMC have been formed in accordance with The
Biological Diversity Act, 2002.
The State Biodiversity Board (SBB) shall fund the BMC directly and the concerned
district level Nodal officer/ the DFO/ District Administration/Zilla Parishad shall
be duly informed. The Utilization Certificate (UC) along with the Statement of
"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 27 -->

14

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

djsxkA O;; fooj.k lfgr mi;ksfxrk izek.k i= jkT; tSo fofoèkrk cksMZ dks izLrqr fd;k tkuk
pkfg,A tSo fofoèkrk izcUèk lfefr jk"Vªh; tSo fofoèkrk izkfèkdj.k@jkT; tSo fofoèkrk cksMZ
ds mi;qDr vfèkdkjh] ftuls èkujkf'k izkIr gqbZ] dks mi;ksfxrk izek.k i= nsxkA

tSo fofoèkrk izcUèk lfefr ds lHkh dks"k fuf/k dk lapkyu lfefr ds vè;{k rFkk lfpo ds
}kjk la;qDr :i ls fd;k tk;sxkA
tSo fofoèkrk izcUèk lfefr dk lfpo lfefr ds [kkrksa dk j[k&j[kko djsxkA ys[kkadu izfØ;k
rS;kj dj jkT; tSo fofoèkrk cksMZ }kjk [kkrksa ds j[k&j[kko gsrq izk:i iznku fd;k tk;sxkA
jkT; tSo fofoèkrk cksMZ [kkrksa ds mfpr j[k&j[kko ,oa mlds izLrqrhdj.k dks lqfuf'pr fd;s
tkus gsrq ,d tkWp lwph Hkh rS;kj djsxkA
[kkrksa dk okf"kZd ys[kk ijh{k.k bl dk;Z gsrq fo'ks"k :i ls fu;qDr ys[kk ijh{kd }kjk fd;k
tk;sxk rFkk tSo fofoèkrk izcUèk lfefr }kjk ikfjr fd;s tkus ds mijkUr mls LFkkuh; fudk;
rFkk jkT; tSo fofoèkrk cksMZ dks izsf"kr dh tk;sxhA
tSo fofoèkrk izcUèk lfefr ds lnL;ksa rFkk lfpo dks okf"kZd fjiskVZ rS;kj djus rFkk LFkkuh;
tSo fofoèkrk ds laj{k.k dh izkFkfedrkvksa ds n`f"Vxr ogkW miyCèk lalkèkuksa dks tSo fofoèkrk
izcUèk lfefr }kjk rS;kj dk;Z ;kstuk ds vuq:i mi;ksxh cuk;s tkus lfgr mi;ksfxrk izek.k
i= ,oa ys[kkadu izfØ;k gsrq izf'kf{kr ,oa f'kf{kr fd;k tkuk pkfg,A
jkT; tSo fofoèkrk cksMZ dh laLrqfr ij jkT; ljdkj }kjk {ks=h; eqn~nksa dh izkFkfedrkvksa vkSj
egRo ds n`f"Vxr bl vfèkfu;e ds dk;kZUo;u gsrq i;kZIr dks"k rFkk lg;ksxh LVkQ uksMy@
ftyk Lrj ij miyCèk djk;k tk;sxkA mDr dks"k jkT; tSo fofoèkrk cksMZ ds ekè;e ls

miyCèk djk;h tk ldrh gSA
2-3 èku dh vfHkj{kk
tSo fofoèkrk izcUèk lfefr dh èkujkf'k cSad [kkrs esa j[kh tk;sxhA tSo fofoèkrk izcUèk lfefr
ds èku dh vfHkj{kk dh ftEesnkjh LFkkuh;@ftyk iz'kklu ls lEcfUèkr LFkk;h LFkkiuk ds
dkfeZd dh gS tks izkfIr] tek èkujkf'k ds gLrkUrj.k ds nkSjku lqj{kk ds fy, vko';d dne
mBk;sxk] rFkk ys[kk ,oa ys[kk ijh{kk ds mn~ns';ksa ds fy, mi;qDr vfHkys[k dk j[k&j[kko
djsxkA
tSo fofoèkrk izcUèk lfefr Hkqxrku gsrq psd tkjh djsxk rFkk tgkW rd laHko gks uxn ysu&nsu
ugha djsxkA

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 28 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

15

Expenditure should be submitted to the SBB. The BMC would give Utilization
Certificate (UC) to the appropriate authority from whom they received the funds/
NBA/ SBB etc., as required.
All the funds of the BMC will be operated jointly by the Chairperson and the
Secretary of the BMC.
The Secretary of the BMC will maintain the accounts of the BMC. The accounting
procedures will be drawn up and format for the maintenance of the accounts will
be provided by the SBB. The SBB will also draw a check list to ensure that there is
proper maintenance and submission of accounts.
The accounts would be audited annually by an Auditor specially appointed for the
purpose and after being passed by the BMC will be given to the local body and the
SBB.
The members of the BMC and the Secretary of the BMC should be trained and
educated on the procedure for giving Utilization certificate (UC) and accounting
procedures including preparation of Annual Report and Utilization of the
resources in accordance with the Action Plan drawn up by the BMC, prioritizing
the conservation of the local biodiversity.
The State Government upon the recommendation of the SBB shall provide adequate
fund and support staﬀ at Nodal/district level, to carry out the implementation of
the Act, keeping in view the priorities and importance of the regional issues. Such
funds may be routed through the SBB.

2.3 Custody of funds
The funds of the BMCs will be kept in a bank account. The custody of the funds of the
BMC is the responsibility of the person belonging to the permanent establishment
like/district administration and will take necessary steps for safeguarding during
receipt, deposition and transmission of the money, maintain suitable steps for
safeguarding during receipt, deposition and transmission of the money, maintain
suitable records for purpose of accounting and auditing.
The BMC shall issue cheques for making payments and by and large avoid cash
transactions.

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 29 -->

16

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

tSo fofoèkrk izcUèk lfefr dks lkeku] midj.k] QuhZpj o vU; vkiwfrZ rFkk ijke'kZ] ejEer
rFkk j[k&j[kko tSlh vU; izcUèk lsokvksa] rduhdh lsokvksa rFkk fo'ks"kK dh lgk;rk dh
vko';drk gks ldrh gSA
oLrqvksa rFkk lsokvksa dh vfHkizkfIr] vR;Ur dq'kyrk ,oa foosd'khy <ax ls foRrh; laifRr;ksa
dh èkujkf'k dks è;ku esa j[krs gq, dh tk ldrh gSA LFkkuh; fudk;ksa }kjk [kjhn lEcUèkh
xfrfofèk gsrq izklafxd 'kkflr ekud fu;eksa ,oa fofu;eksa vkfn dk ikyu fd;k tk ldrk gSA

2-4 tSo fofoèkrk izcUèk lfefr ds O;; lEcUèkh dk;Z&iz.kkyh
izR;sd tSo fofoèkrk izcUèk lfefr dks mlds Lrj ds vuq:i 'k:vkrh fufèk iznku djuk rFkk
mlds laforj.k dk rjhdk fuEuor~ gksxkA

2-5 yksd tSo fofoèkrk jftLVj ds O;; lEcUèkh dk;Z&iz.kkyh
yksd tSo fofoèkrk iaftdk dks rS;kj fd;s tkus gsrq èkujkf'k dk mi;ksx fuEuor~ fuèkkZfjr
fofèk ls fd;k tk ldrk gS %
Ø-la-

en

xzke iapk;r
Lrjh; ch-,e-lh
rFkk ih-ch-vkj
¼` esa½

1

ih-ch-vkj- fu:i.k gsrq jkT; tSo
fofoèkrk cksMZ }kjk fd;s tkus okys
xfrfofèk;ksa gsrq fuèkkZfjr èkujkf'k
Qst&I
tkx:drk@lgHkkxh
xzkeh.k
ewY;kadu vH;kl
dkS'ky fodkl@{ks= Hkze.k@cSBdsa
izkjfEHkd vkadM+ksa dk ,d=hdj.k
Qst&II
vkadM+ksa
dk
izlaLdj.k@
vfHkys[khdj.k@izk:i.k
yksd tSo fofoèkrk iaftdk dk eqnz.k

15,000

20,000

30,000

5,000

10,000

15,000

10,000

10,000

20,000

20,000

20,000

35,000

20,000

30,000

40,000

10,000

20,000

30,000

rduhdh lgk;rk lewg@ dkfeZdksa
dk Vh-,-@Mh-,- vkfn
vU; fofoèk O;;
;ksx

25,000

25,000

40,000

10,000

15,000

20,000

1,15,000

1,50,000

2,30,000

1
2
3
4
5
6
7

fodkl [k.M Lrjh; ftyk Lrjh;
ch-,e-lh rFkk
ch-,e-lh rFkk
ih-ch-vkj ¼` esa½
ih-ch-vkj ¼` esa½

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 30 -->

17

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

BMCs may require the procurement of good, equipments, furniture and other
supplies and services like consultancy, upkeep and maintenance, other management
services, technical services and expert assistance.
Procurement of goods and services can be made in a most efficient and judicious
manner keeping in view the financial properties of the funds. Standard rules and
regulations governing purchases etc. on such activity relevant in the Local bodies
may be adhered to.

2.4 Modus Operandi of Expenditure for BMC
A startup fund, appropriate for its level may be provided for each BMCs and a
manner of disbursement would be in the manner prescribe below.

2.5 Modus Operandi of Expenditure for People’s Biodiversity Register
Funds earmarked for preparation of People’s Biodiversity Registers (PBRs) may be
utilized in the following manner:
No.
1

Village level
BMC & PBR
(in `)
Amount apportioned for SBB to
15,000
meet its expenditure for undertaking
various activities during the
preparation of PBR

1
2

PHASE-I
Awareness/PRA Exercise
Skill
development/Field
Meetings

3
4
5
6
7

Item

visit/

Collection of Primary data
PHASE-II
Processing of data documentation/
drafting
Printing cost of PBR
Remuneration/TA/DA to Technical
Support Group/ Personnel
Miscellaneous Charges
Total

Block/Taluk
level BMC &
PBR (in `)
20,000

District level
BMC & PBR
(in `)
30,000

5,000
10,000

10,000
10,000

15,000
20,000

20,000

20,000

35,000

20,000

30,000

40,000

10,000
25,000

20,000
25,000

30,000
40,000

10,000
1,15,000

15,000
1,50,000

20,000
2,30,000

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 31 -->

18

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

2-6 pSd ij gLrk{kj rFkk LFkk;h vfèk"Bku ds lnL;ksa gsrq lgk;rk
tSo fofoèkrk izcUèk lfefr ds vè;{k rFkk lfpo ds }kjk la;qDr :i ls psd ij gLrk{kj
fd;k tkuk pkfg,A lfefr dk lfpo ou@iapk;r jkt@foHkkx vkfn tSls LFkk;h vfèk"Bku
esa ls gksuk pkfg,A tSo fofoèkrk izcUèk lfefr dh ys[kk dk j[k&j[kko lfefr ds lfpo
}kjk fd;k tk;sxkA LFkk;h vfèk"Bku ds lnL; dk ;g dk;Z vfrfjDr izHkkj ds :i esa ekuk
tk;sxkA blfy, izR;sd lfpo dks muds }kjk nh x;h lsokvksa gsrq mi;qDr ekuns; èkujkf'k dk
Hkqxrku fd;k tk;sxkA bl lEcUèk esa jkT; ljdkj }kjk jkT; tSo fofoèkrk cksMZ dh ijke'kZ
ls mi;qDr jktdh; vkns'k@ladYi fuxZr fd;k tk ldrk gSA

2-7 jksdM+ cgh&[kkrk
jksdM+ cgh&[kkrs dk j[k&j[kko tSo fofoèkrk izcUèk lfefr }kjk fd;k tk,xkA jksdM+
cgh&[kkrs esa uxn@cSad ysu&nsu dh lHkh izfof"B;ksa dks vfHkfyf[kr dh tkuh pkfg,A jksdM+
cgh ds ladyu ds nkSjku lHkh izkfIr;ksa@uxn Hkqxrku dh i`"B la[;k o vfHkys[kh; izek.k
i=ksa dk j[k&j[kko vo'; fd;k tkuk pkfg,A uxn Hkqxrkuksa dks Hkh jksdM+ cgh&[kkrs esa
vfHkfyf[kr fd;k tk;sA

2-8 O;; ij fu;a=.k
TkSo fofoèkrk izcUèk lfefr ds vè;{k gj dne ij foRRkh; O;oLFkk ,oa l[r vFkZO;oLFkk ykxw
djus gsrq ftEesnkj gksaxsA
TkSo fofoèkrk izcUèk lfefr ds lfpo fuèkkZfjr rjhds ds vuq:i ys[ks ds v|ru j[k&j[kko
gsrq ftEesnkj gksaxsA

2-9 cSad ls iqu% feyku dk fooj.k
cSad rFkk jksdM+ cgh esa 'ks"k èkujkf'k dk feyku izR;sd ekg ds vfUre fnu esa fd;k tkuk
pkfg, rFkk [ktkaph ¼Cashier½ }kjk iqu% feyku fooj.k rS;kj fd;k tkuk pkfg,A ;fn fdlh
ekg esa foRRkh; O;; u gks] rks ,sls fooj.k rS;kj fd;s tkus dh dksbZ vko';drk ugha gSA

2-10 O;; dk fooj.k
èkujkf'k dh izkfIr ,oa O;; ds mijkUr O;; dh fooj.kh fuèkkZfjr vofèk ds vUnj fufèk miyCèk
djkus okyh laLFkk dks izsf"kr dh tkuh pkfg,A dqy izkIr èkujkf'k ds U;wure 80% èku dk
O;; gks tkus ij fuèkkZfjr izk:i esa mi;ksfxrk izek.k i= izsf"kr dh tkuh pkfg,A ¼ns[ksa ,usDlj
21 rFkk 22½A

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 32 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

19

2.6 Signing of cheques and support for member of the permanent
establishment
Cheques may be signed by the Chairperson and the Secretary of the BMC. The
Secretary should be from permanent establishment like Forest/Panchayat raj/
Department etc. The Secretary of the BMC will maintain the accounts of the BMC.
This task would be treated as an ‘Additional Charge’ for the member of the permanent
establishment. And therefore suitable honorarium in rupees would be paid for the
services rendered to every Secretary. In this regard the State Government may issue
a suitable Government Order/Resolution in consultation with SBB.

2.7 Cash Book
A Cash Book is to be maintained by the BMC. All records of cash/bank transaction
are to be recorded in the cash book. While compiling the cash book, page numbers
of all receipts/cash payments record of certificates must be maintained. Cash
payments must also be recorded in the cash book.

2.8 Control of Expenditure
The Chairperson of the BMC is responsible for enforcing financial order and strict
economy in every step.
The Secretary of the BMC is responsible for maintenance and upkeep of accounts
in the prescribed manner.

2.9 Bank Reconciliation Statement
Balance in Bank and in the cash book should be reconciled in the last day of every
month and the cashier should prepare the reconciliation statement. In case there is
no expenditure, then such statement need not be prepared.

2.10 Statement of Expenditure
A statement of Expenditure upon receipt and expenditure of funds is to be submitted
to the funding agency within the stipulated time. After expenditure of a minimum
of 80% of the funds received, an Utilization Certificate in the prescribed format
shall be submitted. (see Annexure 21 and 22)

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 33 -->

20

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

2-11 tSo fofoèkrk izcUèk lfefr;kW rFkk tSo lalkèku rd igqWp] 'kqYd vfèkjksi.k rFkk ykHk
dk izHkktu
tSo fofoèkrk izcUèk lfefr ,d jftLVj Hkh laèkkfjr djsxh ftlesa TkSfod lalkèkuksa rd igqWp
rFkk ikjaifjd Kku ds mi;ksx dh vuqefr] vfèkjksfir laxzg 'kqYd ,oa izkIRk ykHk o izHkktu
dh fofèk lEcUèkh lwpuk@fooj.k dh izfof"B dh tk;sxh] ftldh tkWp LFkkuh; fudk; }kjk
le;&le; Ikj dh tk;sxhA
laxzg.k 'kqYd] ykHk dk izHkktu rFkk fojklrh; LFkyksa] ifo= ouksa] ty&fudk;ksa vkfn ds
izcUèku ls lEcfUèkr eqn~nksa ij dk;Zokgh jkT; tSo fofoèkrk cksMZ ds ijke'kZ o rduhdh
lgk;rk ls rFkk bl lEcUèk esa jkT; tSo fofoèkrk cksMZ LFkkuh; fo'ks"kKksa dh rduhdh lgk;rk
lewg xfBr dj jkT;@{ks=@ftyk Lrjh; tSo fofoèkrk izcUèk lfefr dks vko';d lgk;rk
iznku djsxhA

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 34 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

21

2.11 Biodiversity Management Committees and Access to Biological
Resources, Levy and Benefit Sharing
The committee (BMC) shall also maintain a Register giving information about
the details of the access to biological resources and traditional knowledge granted,
details of the collection fee imposed and details of the benefits derived and the mode
of their sharing; which shall be intermittently examined by the local body.
The issues related to collection fee, benefit sharing and management of heritage
sites, sacred groves, water bodies etc. will be done in consultation with the technical
support of the SBB, and the SBB shall in this regard set up Technical Support
Groups comprising of local experts provide necessary assistance to the BMC at
State/Regional/District level.

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 35 -->

22

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

Hkkx&3% rduhdh i{k
3-1 Hkkjrh; lafoèkku dh NBh vuqlwph ls vkPNkfnr {ks=
Hkkjrh; lafoèkku dh NBh vuqlwph ls vkPNkfnr {ks=ksa esa tSo fofoèkrk izcUèk lfefr dk xBu
Lok;Rr ftyk ifj"knksa }kjk ekU;rk izkIr LFkkuh; laLFkkvksa ds Lrj ij fd;k tk;sxkA LFkkuh;
fudk; ch-,e-lh- rFkk fo|eku vU; LFkkuh; laLFkkvks dk ,dhdj.k fu;fer leUo; cSBdsa
fuèkkZfjr dj lqfuf'pr djsxkA
mRrjh&iwoZ jkT;ksa ls lEcfUèkr jkT; tSo fofoèkrk cksMZ tkrh; ,oa lkaLd`frd fofoèkrkvksa dks
fofèkor laKku esa ysrs gq;s fopkjksijkUr tSo fofoèkrk izcUèk lfefr ds xBu gsrq lnL;ksa dh
,d lq>ko lwph izLrqr djsxkA

3-2 tSo fofoèkrk izcUèk lfefr dks lqn`<+ cukus gsrq rduhdh lgk;rk lewg
jkT; tSo fofoèkrk cksMZ ftyk Lrj ij tSo fofoèkrk {ks= esa LFkkuh; :i ls dk;Zjr mRd`"V
,oa fo'ks"kK vfèkdkfj;ksa@laLFkkvksa@O;fDr;ksa dh rduhdh lgk;rk lewg dk lw=ikr djsxk]
tks tSo fofoèkrk izcUèk lfefr ds lapkyu esa ekxZ n'kZd gksxkA
LFkkuh; rduhdh lgk;rk lewg dh lgk;rk@funsZ'ku esa tSo fofoèkrk izcUèk lfefr }kjk
yksd tSo fofoèkrk iaftdk dk j[k&j[kko] izek.khdj.k ,oa ekU;rk iznku dh tk;sxh] ftldh
,d izfr jkT; tSo fofoèkrk cksMZ dks izsf"kr dh tk;sxhA
laxzg.k 'kqYd] ykHk dk izHkktu rFkk fojklr LFkyksa] ifo= ouksa o ty fudk;ksa ds izcUèku
gsrq mfpr Lrj ¼jkT;@{ks=@ftyk½ ij xfBr rduhdh lgk;rk lewg tSo fofoèkrk izcUèk
lfefr dks lgk;rk iznku djsxhA
LFkkuh; ifjfLFkfr;ksa ds vkèkkj ij ftyk Lrj ij rduhdh lgk;rk lewg dk xBu ou] d`f"k]
m|ku] i'kqikyu o eRL; ikyu foHkkxksa] LFkkuh; 'kSf{kd ,oa vuqlaèkku laLFkkuksa] Lok;Rr ftyk
ifj"knksa] xSj ljdkjh laxBuksa] tM+h&cwVh fpfdRldksa bR;kfn fofHkUu foHkxksa ds izfrfufèk;ksa ls
gksxkA
rduhdh lgk;rk lewg ouLifr] tho&tUrq ds LFkkuh; uke lwphc) djus rFkk buls
lEcfUèkr ikajifjd Kku ,oa vius {ks=kfèkdkj ds vUrxZr laj{k.k lEcUèkh leqnk;ksa dh ekStwnk
rkSj&rjhdksa dks yksd tSo fofoèkrk iaftdk esa vfHkfyf[kr fd;s tkus dh izfØ;k esa tSo
fofoèkrk izcUèk lfefr dks lgk;rk iznku djsxhA

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 36 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

23

SECTION–3 : TECHNICAL ASPECTS
3.1 Areas covered by the Sixth Schedule of Indian Constitution
In case of sixth schedule areas, BMCs shall be formed at the levels of local institutions
recognized by Autonomous District Councils. The Local Bodies shall ensure that
the Biodiversity Management Committees are integrated with the existing local
institution by cross membership and regular coordination meetings.
The concerned State Biodiversity Board in the North-Eastern states will provide
a suggestive list of members for the constitution of the Biodiversity Management
Committees duly taking into cognizance the ethnic and cultural diversity.

3.2 Technical Support Groups (TSG) for strengthening BMCs
The SBB shall formulate District level Technical Support Groups (TSGs) comprising
of officials/institution/people of excellence and expertise in the biodiversity issues
at local level, which should guide the BMC in its operation.
The People’s Biodiversity Register shall be maintained, authenticated and validated
by the Biodiversity Management Committees with the assistance/guidance of the
local Technical Support Committee, a copy of which would be made available to
the SBB.
The TSGs established at the appropriate level (State/Regional/District) shall assist
BMCs with regard to collection fee, benefit sharing and management of heritage
sites, sacred groves and water bodies.
The Technical Support Group shall be formed at district level including representative
from the departments of Forest, Agriculture, Horticulture, Veterinary and Fishery,
Local Educational and Research Institutions, Autonomous District Councils, Non
Government Organisation, Herbal Practitioner etc. based on the local conditions.
The Technical Support Group shall assist the BMC in listing local names of flora,
fauna, traditional knowledge relating to flora and fauna and current practices
of communities regarding conservation within its territorial jurisdiction, to be
included in the PBR.

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 37 -->

24

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

3-3 vuqJo.k
tSo fofoèkrk izcUèk lfefr ds fØ;kdykiksa dh leh{kk djus rFkk fn'kk&funsZ'kksa dks le;&le;
ij la'kksfèkr fd;s tkus ds mn~ns'; ls jk"Vªh; tSo fofoèkrk izkfèkdj.k izR;sd nks o"kZ esa
vfèkdkfj;ksa] OkSKkfudksa] f'k{kkfonksa] lnL;&lfpoksa rFkk vU; yksxksa ls ,d fo'ks"kK lfefr xfBr
dj ldrh gSA

3-4 yksd tSo fofoèkrk iaftdk dh vfHkj{kk ,oa rRlEcUèkh lwpuk
tSo fofoèkrk izcUèk lfefr eq[; :i ls xkWo ds ckgjh laLFkkvksa ,oa O;fDr;ksa dks igqWp@
mi;ksx fofu;fer djus lfgr yksd tSo fofoèkrk iaftdk esa ntZ@vfHkfyf[kr Kku dh lqj{kk
lqfuf'pr djsxhA jftLVj rd igqWp dh vuqefr dks fyf[kr :i esa ntZ fd;s tkus rFkk
bldk j[k&j[kko jkT; tSo fofoèkrk cksMZ@rduhdh lgk;rk lewg ds ijke'kZ ls fd;s tkus
dh vko';drk gSA yksd tSo fofoèkrk iaftdk ls izkIr fdlh Hkh tkudkjh@Kku ds mi;ksx
dks fofèkor~ ,oa mfpr izdkj ls Lohdkj fd;k tkuk pkfg,A

3-5 tSo fofoèkrk izcUèk lfefr rFkk tSo fofoèkrk fojklr LFky
tSo fofoèkrk egRo okys vfèkdkfèkd {ks=ksa dks tSo fofoèkrk izcUèk lfefr }kjk lqjf{kr j[kus
dks izksRlkfgr fd;s tkus ds mn~ns'; ls tSo fofoèkrk fojklr LFky ?kksf"kr djus okys lfefr;ksa
ds uke ` 50]000@& ¼ipkl gtkj :Ik;s ek=½ dh èkujkf'k jk"Vªhd`r cSad esa tek dh tk;sxhA
mDr èkujkf'k ds C;kt dk mi;ksx tSo fofoèkrk izcUèk lfefr }kjk muds iz;klksa dks etcwr
djus dh xfrfofèk;ksa esa fd;k tk ldrk gSA

3-6 fooknksa dk lekèkku
,d gh ftys eas fLFkr tSo fofoèkrk izcUèk lfefr;ksa ds eè; fookn dks uksMy vfèkdkjh@eq[;
dk;Zdkjh vfèkdkjh] ftyk ifj"kn@ftyk eftLVªsV dks izLrqr fd;k tk ldrk gSA

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 38 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

25

3.3 Monitoring
The National Biodiversity Authority (NBA) may constitute every two years a
Committee of Expert consisting of field officers, scientists, academicians, membersecretaries and others to review the working of BMCs to amend the guidelines from
time to time.

3.4 Custody of PBRs and information therein
The BMC shall ensure the protection of the knowledge recorded in the People’s
Biodiversity Register principally in the matters of regulation of access to agencies
and individuals outside the village limits. Access to registers need to be recorded
in writing and maintained in consultation with SBB/Technical Support Group.
Use of any information /knowledge from PBR should be duly and properly
acknowledged.

3.5 BMCs and Biodiversity Heritage Sites
To incentivize BMCs to protect more areas of biodiversity importance, a sum of Rs
50,000/- (Rupees Fifty Thousand only) would be deposited in a nationalized bank in
the name of BMCs declaring Biodiversity Heritage Sites (BHS). The interest of the
said amount can be used by the BMC to pursue activities that aid in strengthening
the eﬀorts.

3.6 Resolution of Disputes
Disputes between/amongst Biodiversity management Committees in the same
district may be referred to the Nodal Officer/CEO, Zilla Panchyat/District
Magistrate.

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 39 -->

26

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 1
xzke iapk;r Lrj ds izLRkko dk uewuk
xzke iapk;r Lrj ij tSo fofoèkrk izcUèk lfefr dk xBu
izLrko la[;k % ---------------------xzke iapk;r dk uke % ---------------------------------ftyk %-------------------------

fnukad %---------------------------------------fodkl[k.M %-------------------------------

fnukad --------------------dks ---------------------cts -------------------------------LFkku ij --------------------------------------------------------xzke iapk;r ds izèkku Jh@Jhefr--------------------------------------------------------dh vè;{krk esa rFkk mifLFkr
lnL;ksa dh lgefr ls tSo fofoèkrk vfèkfu;e&2002 dh èkkjk 41¼1½ rFkk tSo fofoèkrk
fu;e&2004 ds fu;e 22 ,oa mRrjk[k.M jkT; tSo fofoèkrk fu;ekoyh -----------------------ds vkèkhu
rhu@ikWp o"kksZa gsrq tSo fofoèkrk izcUèk lfefr dk xBu fd;k x;kA
tSo fofoèkrk izcUèk lfefr ds lnL;ksa dk fooj.k
Ø0la0 iwjk uke rFkk irk

vk;q

Js.kh

1

vè;{k

2

efgyk lnL;

3

efgyk lnL;

4

vuq0tk0@vuq0t0tk0 lnL;

5

lnL;

6

lnL;

7

lfpo
¼ukfer½
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

gLrk{kj

<!-- page 40 -->

27

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 1
Model BMC Resolution at Gram Panchayats level
Formation of Biodiversity Management Committees at Gram Panchayats
Resolution No: …………………………..
Name of Gram Panchayat: ……………………
District: ………………………..

Date: ………………………
Taluk/Tehsil: …………………

The Gram Panchayat meeting was held on…………………., at……………..AM/
PM in ………………………….Gram Panchayat office, under the Chairmanship
of Shri…………………………. the President, and with the consent of all the
members,…………… Biodiversity Management Committee was formed under
section 41(1) of Biological Diversity Act 2002 & Rule 22 of Biological Diversity
Rules 2004 and Uttarakhand Biological Diversity Rules ………, for the period of
three/five years.
Details of Biodiversity Management Committee Members
Sl. No. Full Name and Address

Age

Category

1

Chairman

2

Woman member

3

Woman member

4

SC/ST member

5

Member

6

Member

7

Secretary
(Nominated)
"Biodiversity Conservation ..................... An art of living with nature"

Signature

<!-- page 41 -->

28

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

tSo fofoèkrk izcUèk lfefr fuEufyf[kr gsrq mRrjnk;h gksaxs %
1- vius vfèkdkfjrk {ks= ds vUrxZRk tSo lalkèkuksa dk laj{k.k ,oa iks"k.kh; mi;ksxA
2- vius vfèkdkfjrk {ks= ds vUrxZRk tSo lalkèkuksa rd voSèk :i ls igqWp dks jksdukA
3- jk"Vªh; tSo fofoèkrk izkfèkdj.k] psUubZ rFkk mRrjk[k.M tSo fofoèkrk cksMZ dks fofHkUu
fo"k;ksa ls lEcfUèkr vfHker] tc dHkh vko';d gks] miyCèk djkukA
4- vius vfèkdkfjrk {ks= ds vUrxZr okf.kfT;d iz;kstuksa gsrq fdlh O;fDr ls tSo lalkèkuksa
rd igqWp ;k laxzg.k gsrq vfèkfu;e ds vuq:i laxzg 'kqYd yxkuk@olwy djukA
5- tSo lalkèku mi;ksx dj jgs LFkkuh; oS|ksa rFkk O;olkf;;ksa ds lEcUèk esa vkadM+s laèkkfjr
djukA
6- tSo lalkèkuksa rFkk ikjEifjd Kku ds izfr igqWp gsrq vfèkjksfir Qhl ds laxzg.k ds C;kSjs
rFkk izkIr Qk;nksa rFkk muds izHkktu dh fofèk ds C;kSjs ds lEcUèk esa tkudkjh jftLVj
esa vfHkysf[kr djukA
7- tSo fofoèkrk izcUèk lfefr LFkkuh; tSo lalkèkuksa rFkk lEcfUèkr ikjEifjd Kku lEcUèkh
tkudkjh vfHkysf[kr djus dh dk;Zokgh esa Hkh vfuok;Z :i ls lfEefyr jgsaxsA
8- jk"Vªh; tSo fofoèkrk izkfèkdj.k rFkk mRrjk[k.M tSo fofoèkrk cksMZ }kjk le;&le; ij
fn;s x;s fn'kk funsZ'kksa ds vuq:i tSo fofoèkrk fufèk ds mi;ksx ,oa izcUèku dk dk;Z
djukA

¼gLrk{kj ,oa eksgj½
vè;{k@xzke izèkku
xzke iapk;r--------------

¼gLrk{kj ,oa eksgj½
lfpo ¼LFkk;h vfèk"Bku ls½
tSo fofoèkrk izcUèk lfefr
xzke iapk;r-------------

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 42 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

29

The Biodiversity Management Committees will be responsible for:
1.

Conservation and sustainable utilization of Bio-resources within its area of
jurisdiction.

2.

Stop illegal access of Bio-resources within its area of jurisdiction.

3.

Furnishing of opinion to National Biodiversity Authority, Chennai and
Uttarakhand Biodiversity Board on various subjects as and when required.

4.

Levying charges by way of collection fees for accessing/collecting bio-resources
for commercial purpose within area of jurisdiction, as per the act.

5.

Maintain data about local vaidyas and practitioners using biological resources.

6.

Maintain register containing information about details of access of biological
resources and traditional knowledge granted, details of collection fee imposed
and details of benefit sharing derived and mode of their sharing.

7.

The Biodiversity Management Committee will also be involved in documentation
of Biodiversity and associated traditional knowledge.

8.

Management and use of Biodiversity fund as per guidelines provided by the
National Biodiversity Authority and Uttarakhand Biodiversity Board from
time to time.

Signature & Stamp
Gram Panchayat President

Signature & Stamp
Gram Panchayat Secretary/
Member of the permanent establishment

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 43 -->

30

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 2
fodkl[k.M@rglhy Lrj ds izLrko dk uewuk
fodkl[k.M@rglhy iapk;r Lrj ij tSo fofoèkrk izcUèk lfefr dk xBu
izLrko la[;k % ---------------------fnukad %---------------------------fodkl[k.M@rglhy dk uke % ---------------------------------------------ftyk %-------------------------------fnukad ------------------------------------dks -------------------------cts ---------------------------LFkku ij -----------------------------------fodkl[k.M@rglhy ds izeq[k Jh@Jhefr--------------------------------------------------------------------------dh vè;{krk
esa rFkk mifLFkr lnL;ksa dh lgefr ls tSo fofoèkrk vfèkfu;e&2002 dh èkkjk 41¼1½ rFkk tSo
fofoèkrk fu;e&2004 ds fu;e 22 ,oa mRrjk[k.M jkT; tSo fofoèkrk fu;ekoyh -----------------ds
vkèkhu rhu@ikWp o"kksZa gsrq tSo fofoèkrk izcUèk lfefr dk xBu fd;k x;kA
tSo fofoèkrk izcUèk lfefr ds lnL;ksa dk fooj.k
Ø0la0 iwjk uke rFkk irk

vk;q

Js.kh

1

vè;{k

2

efgyk lnL;

3

efgyk lnL;

4

vuq0tk0@vuq0t0tk0 lnL;

5

lnL;

6

lnL;

7

lfpo
¼ukfer½
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

gLrk{kj

<!-- page 44 -->

31

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 2
Model Resolution at Block/Tehsil Level
Formation of BMC at Block/Tehsil Panchayats
Resolution No……………
Date:…………
Name of the Block/Tehsil:……………………….… District: …………………..
The Block/Tehsil Panchayat meeting was held on ………….at…………AM/PM
in ……………………. Block/Tehsil Panchayat office, under the Chairmanship
of Shri…………………………. the President, and with the consent of all the
members,…………….. Biodiversity Management Committee was formed under
section 41(1) of Biological Diversity Act 2002 & Rule 22 of Biological Diversity
Rules 2004 and Uttarakhand Biological Diversity Rules ……., for the period of
three/five years.
Details of Biodiversity Management Committee Members
Sl. No. Full Name and Address

Age

Category

1

Chairman

2

Woman member

3

Woman member

4

SC/ST member

5

Member

6

Member

7

Secretary
(Nominated)
"Biodiversity Conservation ..................... An art of living with nature"

Signature

<!-- page 45 -->

32

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

tSo fofoèkrk izcUèk lfefr fuEufyf[kr gsrq mRrjnk;h gksaxs %
1- vius vfèkdkfjrk {ks= ds vUrxZRk tSo lalkèkuksa ds laj{k.k ,oa iks"k.kh; mi;ksxA
2- vius vfèkdkfjrk {ks= ds vUrxZRk tSo lalkèkuksa rd voSèk :i ls igqWp dks jksdukA
3- jk"Vªh; tSo fofoèkrk izkfèkdj.k] psUubZ rFkk mRrjk[k.M tSo fofoèkrk cksMZ dks fofHkUu
fo"k;ksa ls lEcfUèkr vfHker] tc dHkh vko';d gks] miyCèk djkukA
4- vius vfèkdkfjrk {ks= ds vUrxZr okf.kfT;d iz;kstuksa gsrq fdlh O;fDr ls tSo lalkèkuksa
rd igqWp ;k laxzg.k gsrq vfèkfu;e ds vuq:i laxzg 'kqYd yxkuk@olwy djukA
5- tSo lalkèku mi;ksx dj jgs LFkkuh; oS|ksa rFkk O;olkf;;ksa ds lEcUèk esa vkadM+s laèkkfjr
djukA
6- tSo lalkèkuksa rFkk ikjEifjd Kku ds izfr igqWp gsrq vfèkjksfir Qhl ds laxzg.k ds C;kSjs
rFkk izkIr Qk;nksa rFkk muds izHkktu dh fofèk ds C;kSjs ds lEcUèk esa tkudkjh jftLVj
esa vfHkysf[kr djukA
7- tSo fofoèkrk izcUèk lfefr LFkkuh; tSo lalkèkuksa rFkk lEcfUèkr ikjEifjd Kku lEcUèkh
tkudkjh vfHkysf[kr djus dh dk;Zokgh esa Hkh vfuok;Z :i ls lfEefyr jgsaxsA
8- jk"Vªh; tSo fofoèkrk izkfèkdj.k rFkk mRrjk[k.M tSo fofoèkrk cksMZ }kjk le;&le; ij
fn;s x;s fn'kk funsZ'kksa ds vuq:i tSo fofoèkrk fufèk ds mi;ksx ,oa izcUèku dk dk;Z
djukA

¼gLrk{kj ,oa eksgj½
v/;{k
fodkl[k.M@rglhy iapk;r

¼gLrk{kj ,oa eksgj½
dk;Zdkjh vfèkdkjh
fodkl[k.M@rglhy iapk;r

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 46 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

33

The Biodiversity Management Committees will be responsible for:
1.

Conservation and sustainable utilization of Bio resources within its area of
jurisdiction.

2.

Stop illegal access of bio resources within its area of jurisdiction.

3.

Furnishing of opinion to National Biodiversity Authority, Chennai and
Uttarakhand Biodiversity Board on various subjects as and when required.

4.

Levying charges by way of collection fees for accessing/collecting bio-resources
for commercial purpose within area of jurisdiction, as per the act.

5.

Maintain data about local vaidyas and practitioners using biological resources.

6.

Maintain register containing information about details of access of biological
resources and traditional knowledge granted, details of collection fee imposed
and details of benefit sharing derived and mode of their sharing.

7.

The Biodiversity Management Committee will also be involved in documentation
of Biodiversity and associated traditional knowledge.

8.

Management and use of Biodiversity fund as per guidelines provided by the
National Biodiversity Authority and Uttarakhand Biodiversity Board from
time to time.

Signature & Stamp
President
Block/Tehsil Panchayat

Signature & Stamp
Executive Officer
Block/Tehsil Panchayat

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 47 -->

34

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 3
ftyk iapk;r ds izLrko dk uewuk
ftyk iapk;r Lrj ij tSo fofoèkrk izcUèk lfefr dk xBu
izLrko la[;k % ---------------------fnukad %---------------------------ftyk dk uke % ------------------------------------------------------fnukad --------------------dks ---------------------cts --------------------------- LFkku ij ------------------------------------------ftyk
iapk;r ds vè;{k Jh@Jhefr--------------------------------------------------------------------------------------------------dh vè;{krk
esa rFkk mifLFkr lnL;ksa dh lgefr ls tSo fofoèkrk vfèkfu;e&2002 dh èkkjk 41¼1½ rFkk
tSo fofoèkrk fu;e&2004 ds fu;e 22 ,oa mRrjk[k.M jkT; tSo fofoèkrk fu;ekoyh
-------------------- ds vkèkhu rhu@ikWp o"kksZa gsrq tSo fofoèkrk izcUèk lfefr dk xBu fd;k x;kA
tSo fofoèkrk izcUèk lfefr ds lnL;ksa dk fooj.k
Ø0la0 iwjk uke rFkk irk

vk;q

Js.kh

1

vè;{k

2

efgyk lnL;

3

efgyk lnL;

4

vuq0tk0@vuq0t0tk0 lnL;

5

lnL;

6

lnL;

7

lfpo
¼ukfer½
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

gLrk{kj

<!-- page 48 -->

35

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 3
Model Resolution at Zilla Panchayat level
Formation of Biodiversity Management Committees at Zilla Panchayats
Resolution No……………
Name of the District: …………………………..

Date:…………

The Zilla Panchayat meeting was held on ……………………………………….
at……………….. AM/PM in …………………………. Zilla Panchayat office,
under the Chairmanship of Shri…………………………. the President, and with
the consent of all the members,………….. Biodiversity Management Committee
was formed under section 41(1) of Biological Diversity Act 2002 & Rule 22 of
Biological Diversity Rules 2004 and Uttarakhand Biological Diversity Rules …….,
for the period of three/five years.
Details of Biodiversity Management Committee Members
Sl. No. Full Name and Address

Age

Category

1

Chairman

2

Woman member

3

Woman member

4

SC/ST member

5

Member

6

Member

7

Secretary
(Nominated)
"Biodiversity Conservation ..................... An art of living with nature"

Signature

<!-- page 49 -->

36

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

tSo fofoèkrk izcUèk lfefr fuEufyf[kr gsrq mRrjnk;h gksaxs %
1- vius vfèkdkfjrk {ks= ds vUrxZRk tSo lalkèkuksa ds laj{k.k ,oa iks"k.kh; mi;ksxA
2- vius vfèkdkfjrk {ks= ds vUrxZRk tSo lalkèkuksa rd voSèk :i ls igqWp dks jksdukA
3- jk"Vªh; tSo fofoèkrk izkfèkdj.k] psUubZ rFkk mRrjk[k.M tSo fofoèkrk cksMZ dks fofHkUu
fo"k;ksa ls lEcfUèkr vfHker] tc dHkh vko';d gks] miyCèk djukA
4- vius vfèkdkfjrk {ks= ds vUrxZr okf.kfT;d iz;kstuksa gsrq fdlh O;fDr ls tSo lalkèkuksa
rd igqWp ;k laxzg.k gsrq vfèkfu;e ds vuq:i laxzg 'kqYd yxkuk@olwy djukA
5- tSo lalkèku mi;ksx dj jgs LFkkuh; oS|ksa rFkk O;olkf;;ksa ds lEcUèk esa vkadM+s laèkkfjr
djukA
6- tSo lalkèkuksa rFkk ikjEifjd Kku ds izfr igqWp gsrq vfèkjksfir Qhl ds laxzg.k ds C;kSjs
rFkk izkIr Qk;nksa rFkk muds izHkktu dh fofèk ds C;kSjs ds lEcUèk esa tkudkjh jftLVj
esa vfHkysf[kr djukA
7- tSo fofoèkrk izcUèk lfefr LFkkuh; tSo lalkèkuksa rFkk lEcfUèkr ikjEifjd Kku lEcUèkh
tkudkjh vfHkysf[kr djus dh dk;Zokgh esa Hkh vfuok;Z :i ls lfEefyr jgsaxsA
8- jk"Vªh; tSo fofoèkrk izkfèkdj.k rFkk mRrjk[k.M tSo fofoèkrk cksMZ }kjk le;&le; ij
fn;s x;s fn'kk funsZ'kksa ds vuq:i tSo fofoèkrk fufèk ds mi;ksx ,oa izcUèku dk dk;Z
djukA

¼gLrk{kj ,oa eksgj½
vè;{k
ftyk iapk;r------------

¼gLrk{kj ,oa eksgj½
eq[; dk;Zdkjh vfèkdkjh
ftyk iapk;r--------------------

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 50 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

37

The Biodiversity Management Committees will be responsible for:
1.

Conservation and sustainable utilization of Bio resources within its area of
jurisdiction.

2.

Stop illegal access of bio resources within its area of jurisdiction.

3.

Furnishing of opinion to National Biodiversity Authority, Chennai and
Uttarakhand Biodiversity Board on various subjects as and when required.

4.

Levying charges by way of collection fees for accessing/collecting bio-resources
for commercial purpose within area of jurisdiction, as per the act.

5.

Maintain data about local vaidyas and practitioners using biological resources.

6.

Maintain register containing information about details of access of biological
resources and traditional knowledge granted, details of collection fee imposed
and details of benefit sharing derived and mode of their sharing.

7.

The Biodiversity Management Committee will also be involved in documentation
of Biodiversity and associated traditional knowledge.

8.

Management and use of Biodiversity fund as per guidelines provided by the
National Biodiversity Authority and Uttarakhand Biodiversity Board from
time to time.

Signature & Stamp
President
Zilla Panchayat ........................

Signature & Stamp
Chief Executive Officer
Zilla Panchayat ........................

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 51 -->

38

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 4
uxjikfydk ifj"kn ds izLrko dk uewuk
uxjikfydk ifj"kn Lrj ij tSo fofoèkrk izcUèk lfefr dk xBu
izLrko la[;k % ---------------------uxjikfydk ifj"kn dk uke % --------------------------------------------------------

fnukad %----------------------------

fnukad --------------------dks ---------------------cts -------------------------LFkku ij -------------------------------------------uxjikfydk
ifj"kn ds vè;{k Jh@Jhefr------------------------------------------------------------------------dh vè;{krk esa rFkk
mifLFkr lnL;ksa dh lgefr ls tSo fofoèkrk vfèkfu;e&2002 dh èkkjk 41¼1½ rFkk tSo
fofoèkrk fu;e&2004 ds fu;e 22 ,oa mRrjk[k.M jkT; tSo fofoèkrk fu;ekoyh -----------------ds
vkèkhu rhu@ikWp o"kksZa gsrq tSo fofoèkrk izcUèk lfefr dk xBu fd;k x;kA
tSo fofoèkrk izcUèk lfefr ds lnL;ksa dk fooj.k
Ø0la0 iwjk uke rFkk irk

vk;q

Js.kh

1

vè;{k

2

efgyk lnL;

3

efgyk lnL;

4

vuq0tk0@vuq0t0tk0 lnL;

5

lnL;

6

lnL;

7

lfpo
¼ukfer½
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

gLrk{kj

<!-- page 52 -->

39

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 4
Model Resolution of Municipal Council
Formation of Biodiversity Management Committees at Municipal Council
Resolution No……………..
Date:…………….
Name of the Municipal Council………………….
The Municipal council meeting was held on……… at AM/PM in………….municipal
council office, under the Chairmanship of sri………………………………………
the President and with the consent of all the members,…………….Biodiversity
Management Committee was formed under section 41(1) of Biological Diversity
Act 2002 & rule 22 of Biological Diversity Rules 2004 and Uttarakhand Biological
Diversity Rules………, for the period of three/five years.
Details of Biodiversity Management Committee Members
Sl. No. Full Name and Address

Age

Category

1

Chairman

2

Woman member

3

Woman member

4

SC/ST member

5

Member

6

Member

7

Secretary
(Nominated)

"Biodiversity Conservation ..................... An art of living with nature"

Signature

<!-- page 53 -->

40

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

tSo fofoèkrk izcUèk lfefr fuEufyf[kr gsrq mRrjnk;h gksaxs %
1- vius vfèkdkfjrk {ks= ds vUrxZRk tSo lalkèkuksa ds laj{k.k ,oa iks"k.kh; mi;ksxA
2- vius vfèkdkfjrk {ks= ds vUrxZRk tSo lalkèkuksa rd voSèk :i ls igqWp dks jksdukA
3- jk"Vªh; tSo fofoèkrk izkfèkdj.k] psUubZ rFkk mRrjk[k.M tSo fofoèkrk cksMZ dks fofHkUu
fo"k;ksa ls lEcfUèkr vfHker] tc dHkh vko';d gks] miyCèk djukA
4- vius vfèkdkfjrk {ks= ds vUrxZr okf.kfT;d iz;kstuksa gsrq fdlh O;fDr ls tSo lalkèkuksa
rd igqWp ;k laxzg.k gsrq vfèkfu;e ds vuq:i laxzg 'kqYd yxkuk@olwy djukA
5- tSo lalkèku mi;ksx dj jgs LFkkuh; oS|ksa rFkk O;olkf;;ksa ds lEcUèk esa vkadM+s laèkkfjr
djukA
6- tSo lalkèkuksa rFkk ikjEifjd Kku ds izfr igqWp gsrq vfèkjksfir Qhl ds laxzg.k ds C;kSjs
rFkk izkIr Qk;nksa rFkk muds izHkktu dh fofèk ds C;kSjs ds lEcUèk esa tkudkjh jftLVj
esa vfHkysf[kr djukA
7- tSo fofoèkrk izcUèk lfefr LFkkuh; tSo lalkèkuksa rFkk lEcfUèkr ikjEifjd Kku lEcUèkh
tkudkjh vfHkysf[kr djus dh dk;Zokgh esa Hkh vfuok;Z :i ls lfEefyr jgsaxsA
8- jk"Vªh; tSo fofoèkrk izkfèkdj.k rFkk mRrjk[k.M tSo fofoèkrk cksMZ }kjk le;&le; ij
fn;s x;s fn'kk funsZ'kksa ds vuq:i tSo fofoèkrk fufèk ds mi;ksx ,oa izcUèku dk dk;Z
djukA

¼gLrk{kj ,oa eksgj½
vè;{k
uxjikfydk ifj"kn----------

¼gLrk{kj ,oa eksgj½
eq[; dk;Zdkjh vfèkdkjh
uxjikfydk ifj"kn----------

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 54 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

41

The Biodiversity Management Committee will be responsible for:
1.

Conservation and sustainable utilization of bio resources within its area of
jurisdiction.

2.

Stop illegal access of bio resources within its area of jurisdiction.

3.

Furnishing of opinion to National Biodiversity Authority, Chennai and
Uttarakhand Biodiversity Board on various subjects as and when required.

4.

Levying charges by way of collection fees for accessing/collecting bio-resources
for commercial purpose within its area of jurisdiction, as per the act.

5.

Maintain data about local vaidyas and practitioners using biological resources.

6.

Maintain register containing information about details of access of biological
resources and traditional knowledge granted, details of collection fee imposed
and details of benefits derived and mode of their sharing.

7.

The Biodiversity Management Committee will also be involved in documentation
of biodiversity and associated traditional knowledge.

8.

Management and use of Biodiversity Fund as per guidelines provided by the
National Biodiversity Authority and Uttarakhand Biodiversity Board from
time to time.

Signature & Stamp
President
Municipal Corporation....................

Signature & Stamp
Municipal Commissioner
Municipal Corporation....................

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 55 -->

42

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 5
uxj fuxe Lrj ds izLrko dk uewuk
uxj fuxe Lrj ij tSo fofoèkrk izcUèk lfefr dk xBu
izLrko la[;k % ---------------------uxj fuxe dk uke % --------------------------------------------------------

fnukad %----------------------------

fnukad --------------------dks ---------------------cts -------------------------------LFkku ij -------------------------------------------uxj
fuxe ds vè;{k ¼es;j½ Jh@Jhefr-------------------------------------------------------------------dh vè;{krk esa rFkk
mifLFkr lnL;ksa dh lgefr ls tSo fofoèkrk vfèkfu;e&2002 dh èkkjk 41¼1½ rFkk tSo
fofoèkrk fu;e&2004 ds fu;e 22 ,oa mRrjk[k.M jkT; tSo fofoèkrk fu;ekoyh -----------------ds
vkèkhu rhu@ikWp o"kksZa gsrq tSo fofoèkrk izcUèk lfefr dk xBu fd;k x;kA
tso fofo/krk izcU/k lfefr ds lnL;ksa dk fooj.k
Ø0la0 iwjk uke rFkk irk

vk;q

Js.kh

1

vè;{k

2

efgyk lnL;

3

efgyk lnL;

4

vuq0tk0@vuq0t0tk0 lnL;

5

lnL;

6

lnL;

7

lfpo
¼ukfer½
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

gLrk{kj

<!-- page 56 -->

43

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 5
Model Resolution of Municipal Corporation
Formation of Biodiversity Management Committees at Municipal
Corporation Level
Resolution No…………..
Name of the Municipal Corporation:………………

Date:…………….

The Municipal Corporation meeting was held on…………….……….….at AM/PM
in……………………….. Municipal Corporation office, under the Chairmanship of
Sri……………………………………………..the President, and with the consent of
all the members………….Biodiversity Management Committee was formed under
Section 41(1) of Biological Diversity Act 2002 & Rule 22 of Biological Diversity
Rules 2004 and Uttarakhand Biological Diversity Rule…….., for the period of
three/five years.
Details of Biodiversity Management Committee Members
Sl. No. Full Name and Address

Age

Category

1

Chairman

2

Woman member

3

Woman member

4

SC/ST member

5

Member

6

Member

7

Secretary
(Nominated)
"Biodiversity Conservation ..................... An art of living with nature"

Signature

<!-- page 57 -->

44

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

tSo fofoèkrk izcUèk lfefr fuEufyf[kr gsrq mRrjnk;h gksaxs %
1- vius vfèkdkfjrk {ks= ds vUrxZRk tSo lalkèkuksa dk laj{k.k ,oa iks"k.kh; mi;ksxA
2- vius vfèkdkfjrk {ks= ds vUrxZRk tSo lalkèkuksa rd voSèk :i ls igqWp dks jksdukA
3- jk"Vªh; tSo fofoèkrk izkfèkdj.k] psUubZ rFkk mRrjk[k.M tSo fofoèkrk cksMZ dks fofHkUu
fo"k;ksa ls lEcfUèkr vfHker] tc dHkh vko';d gks] miyCèk djkukA
4- vius vfèkdkfjrk {ks= ds vUrxZr okf.kfT;d iz;kstuksa gsrq fdlh O;fDr ls tSo lalkèkuksa
rd igqWp ;k laxzg.k gsrq vfèkfu;e ds vuq:i laxzg 'kqYd yxkuk@olwy djukA
5- tSo lalkèku mi;ksx dj jgs LFkkuh; oS|ksa rFkk O;olkf;;ksa ds lEcUèk esa vkadM+s laèkkfjr
djukA
6- tSo lalkèkuksa rFkk ikjEifjd Kku ds izfr igqWp gsrq vfèkjksfir Qhl ds laxzg.k ds C;kSjs
rFkk izkIr Qk;nksa rFkk muds izHkktu dh fofèk ds C;kSjs ds lEcUèk esa tkudkjh jftLVj
esa vfHkysf[kr djukA
7- tSo fofoèkrk izcUèk lfefr LFkkuh; tSo lalkèkuksa rFkk lEcfUèkr ikjEifjd Kku lEcUèkh
tkudkjh vfHkysf[kr djus dh dk;Zokgh esa Hkh vfuok;Z :i ls lfEefyr jgsaxsA
8- jk"Vªh; tSo fofoèkrk izkfèkdj.k rFkk mRrjk[k.M tSo fofoèkrk cksMZ }kjk le;&le; ij
fn;s x;s fn'kk funsZ'kksa ds vuq:i tSo fofoèkrk fufèk ds mi;ksx ,oa izcUèku dk dk;Z
djukA

¼gLrk{kj ,oa eksgj½
vè;{k
uxj fuxe---------------------

¼gLrk{kj ,oa eksgj½
eq[; dk;Zdkjh vfèkdkjh
uxj fuxe---------------------

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 58 -->

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

45

The Biodiversity Management Committee will be responsible for:
1.

Conservation and sustainable utilization of bio-resources within its area of
jurisdiction.

2.

Stop illegal access of bio-resources within its area of jurisdiction.

3.

Furnishing of opinion to National Biodiversity Authority, Chennai and
Uttarakhand Biodiversity Board on various subjects as and when required.

4.

Levying charges by way of collection fees for accessing/collecting bio-resources
for commercial purpose within its area of jurisdiction, as per the act.

5.

Maintain data about local vaidyas and practitioners using biological resources.

6.

Maintain register containing information about details of access of biological
resources and traditional knowledge granted, details of collection fee imposed
and details of benefits derived and mode of their sharing.

7.

The Biodiversity Management Committee will also be involved in documentation
of biodiversity and associated traditional knowledge.

8.

Management and use of Biodiversity Fund as per guidelines provided by the
National Biodiversity Authority and Uttarakhand Biodiversity Board from
time to time.

Signature & Stamp
President
Municipal Corporation....................

Signature & Stamp
Municipal Commissioner
Municipal Corporation....................

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 59 -->

46

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 6
tSo fofoèkrk izcUèk lfefr dh cSBdksa ds dk;Zo`Rr dk izk:i
fnukad ----------------------- dks tSo fofoèkrk izcUèk lfefr dh --------------------------------- cSBd dk dk;Zo`Rr
cSBd dk LFkku % ---------------------------------¼d½ cSBd dh dk;Zlwph
i)
ii)
iii)
iv)
v)

¼[k½ izeq[k eqÌksa lfgr vU; dk;Zokgh ij ppkZ ,oa fu.kZ;
i)
ii)
iii)
iv)

¼x½ mifLFkr lnL;ksa rFkk muds inuke ,oa gLrk{kj dh lwph
i)
ii)
iii)
iv)
v)
vi)
vii)

gLrk{kj ,oa eksgj
vè;{k] tSo fofoèkrk izcUèk lfefr

gLrk{kj ,oa eksgj
lfpo] tSo fofoèkrk izcUèk lfefr

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 60 -->

47

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 6
Format for recording Minutes of BMC Meetings
Minutes of the………………………….Biodiversity Management Committee
Meeting held on……………….
Venue of the meeting :…………………………….
(a) Agenda Items of the meeting.
i)
ii)
iii)
iv)
v)
(b) Proceedings including key issues discussed and decisions made:
i)
ii)
iii)
iv)
(c) List of members present and their designation and signature
i)
ii)
iii)
iv)
v)
vi)
vii)

Signature & Stamp
Chairperson of the BMC

Signature & Stamp
Secretary of the BMC

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 61 -->

48

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 7
tSo fofoèkrk izcUèk lfefr ds okf"kZd fjiksVZ gsrq uewus dk izk:i
lfefr dk uke %
2. fjiksVZ ls lEcfUèkr vofèk ¼foRrh; o"kZ½ %
3. dk;kZy; ds dk;ZHkkj dh vofèk ¼vè;{k rFkk lfpo dk uke½ %
4. o"kZ esa fofHkUu dk;ZØeksa gsrq d`r dk;Zokgh dk foLr`r fooj.k %
5. o"kZ ds nkSjku fu"ikfnr xfrfofèk;ksa lEcUèkh foLr`r fjiksVZ %
6. lfefr dh fOkRrh; fLFkfr dk laf{kIr ys[kk %
7. vfèkdkfjrk {ks= dk ekufp= %
8. yksd tSo fofoèkrk jftLVj lEcUèkh dk;Z dh izxfr %
1.

(i) nLrkosthdj.k
(ii) v|ruhdj.k
(iii) jkT; tSo fofoèkrk cksMZ rFkk rduhdh lgk;rk lewg ds ijke'kZ ls ekU;rk

tSo fofoèkrk izcUèk lfefr ds izLRkkoksa ,oa fu.k;ksa ds vfHkys[khdj.k gsrq dk;Zo`RRk jftLVj%
10. tSo fofoèkrk izcUèk lfefr ds izLrko lfgr okf"kZd foRrh; fjiksVZ %
11. vkxarqdksa dh lwph %
12. O;fDr;ksa dh lwph] ftUgsa tSo fofoèkrk izcUèk lfefr }kjk tSfod lalkèkuksa rFkk ijEijkxr
Kku rd igqap iznku dh x;h %
13. tSo fofoèkrk izcUèk lfefr&jkT; tSo fofoèkrk cksMZ&jk"Vªh; tSo fofoèkrk izkfèkdj.k ds
eè; egRoiw.kZ lwpukvksa dk vknku&iznku %
14. QksVksxzkQ] lekpkj drju ¼;fn dksbZ gks½ %
9.

gLrk{kj ,oa eksgj
vè;{k] tSo fofoèkrk izcUèk lfefr

gLrk{kj ,oa eksgj
lfpo] tSo fofoèkrk izcUèk lfefr

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 62 -->

49

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 7
Annual Report Format for Biodiversity Management Committee
1. The name of the committee :
2. The period of which the report relates (Financial Year) :
3. The incumbency of office for the period (Names of the Chairperson and
Secretary) :
4. Detailed statement of programmes of action for the years :
5. Detailed report on the activities performed during the year :
6. A brief account of financial position of the committee :
7. Map of jurisdiction :
8. Progress of work in People’s Biodiversity Register (PBR) :
(i) Documentation
(ii) Updation
(iii) Validation in consultation with the SBB and TSG
9. Minutes Book recording resolutions and decisions made by BMC :
10. BMC Annual Financial Report with resolutions of the BMC :
11. List of Visitors :
12. List of persons provided access to biological resources and traditional knowledge
by BMC :
13. Important communication between BMC-SBB-NBA :
14. Photographs, News clippings (if any) :

Signature & Stamp
Chairperson of the BMC

Signature & Stamp
Secretary of the BMC

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 63 -->

50

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 8
tSfod lalkèkuksa dk bLrseky dj jgs oS|ksa ,oa fpfdRldks ds fy, izk:i
xzke iapk;r ds {ks=h; vfèkdkfjrk ds vUrxZr ogka LFkkuh; :i ls fuokl dj jgs oS|] gdhe
rFkk ikjEifjd LokLF; ns[kHkky ¼ekuo ,oa i'kqvksa½ rFkk@vFkok tSfod lalkèkuksa dk mi;ksx
djus okys O;fDr;ksa dh lwph
1-

uke %
vk;q%
fyax%
irk%
fo'ks"kKrk dk {ks=%
og LFkku] tgkW ls O;fDr tSfod lkexzh rd igqWp cukrk gS%
lalkèku dh fLFkfr ij fpfdRldks dh vo/kkj.kk%

2-

uke %
vk;q%
fyax%
irk%
fo'ks"kKrk dk {ks=%
og LFkku] tgkW ls O;fDr tSfod lkexzh rd igqWprk cukrk gS%
lalkèku dh fLFkfr ij fpfdRldks dh vo/kkj.kk%

3-

uke %
vk;q%
fyax%
irk%
fo'ks"kKrk dk {ks=%
og LFkku] tgkW ls O;fDr tSfod lkexzh rd igqWprk cukrk gS%
lalkèku dh fLFkfr ij fpfdRldks dh vo/kkj.kk%

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 64 -->

51

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 8
Format for vaids and practitioners making use of Biological resources
List of Vaids, hakims and traditional health care (human and livestock) practitioners
residing and or using biological resources occurring within the territorial jurisdiction
of the Village Panchayat.
1.

Name :
Age :
Gender :
Address :
Area of specialization:
Location from which the person accesses biological material:
Perception of the practitioner on the resource status:

2.

Name :
Age :
Gender :
Address :
Area of specialization:
Location from which the person accesses biological material:
Perception of the practitioner on the resource status:

3.

Name :
Age :
Gender :
Address :
Area of specialization:
Location from which the person accesses biological material:
Perception of the practitioner on the resource status:

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 65 -->

52

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 9
tSfod lalkèkuksa rFkk ikjaifjd Kku rd igqWp vuqeU; djus lEcUèkh
lwpukvksa ds vfHkys[khdj.k dk izk:i
tSfod lalkèkuksa rFkk iajkijkxr Kku rd igqWp vuqeU; djus] vfèkjksfir laxzg 'kqYd dk fooj.k
,oa izkIr ykHk rFkk izHkktu ds rjhds dk foLr`r fooj.k
Ø-la-

O;fDr@laLFkku@
dEiuh@vU; dk uke
,oa iw.kZ irk

igqWp (accessed)
ch0,e0lh0
vfèkjksfir
ykHk izHkktu
fd;s x;s tSfod dk izLrko rFkk laxzg.k 'kqYd ds izdkj dk
lalkèkuksa dk
xzke iapk;r ds dk fooj.k
iwokZuqeku
LFkkuh; rFkk
vuqeksnu dk
vFkok lk>k
oSKkfud uke ,oa
fnukad
fd;s x;s ykHk
ek=k
dh ek=k

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 66 -->

53

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 9
Format for recording information related to access of biological
resources and Traditional knowledge granted
Details of access to Biological resources and Traditional knowledge granted, details
of the collection fee imposed and details of the benefits derived and the mode of their
sharing.
S.
Name and address of
No. the Person/institution/
company/others

Local and
Date and
Details of
Anticipated
Scientific
resolution of Collection mode of sharing
Name of the the BMC and
fee
benefits or
biological endorsement imposed
quantum of
material
by the
benefits shared
Accessed and Panchayat
quantity

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 67 -->

54

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 10
O;; jftLVj & izek.k i=
tSo fofoèkrk izcUèk lfefr dk uke %-----------------------------------------------------------------------------------------------------------fcy Øe la[;k %---------------------------------izek.k i= Øe la[;k %-----------------------------------------fnukad %----------------------------------------fnukad %----------------------------------------mi;qZDr fcy esa n'kkZ;h x;h èkujkf'k fuEuor~ [kkrs esa Hkqxrku@tek fd;k x;k %
Ø-la-

[kkrs dk uke

O;; jkf'k

vk; jkf'k

;ksx
`---------------------------------------------- ¼'kCnksa esa½------------------------------------------------------------------------------------------------------------

izek.k i= dh izfof"B jftLVj la[;k-------------------------------dh i`"B la[;k------------------ij ntZ dh x;hA

¼vfèkdkjh ds gLrk{kj½
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 68 -->

55

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 10
Expenditure Register Certificate
Name of BMC ………………………………..………………………..………………
Bill Serial No……………….

Certificate Serial No……………

Date…………………………

Date ………………………….…

Amount mentioned in the aforesaid bill is debited/credited in the following accounts:
S. No.

Account Name

Amount Debited

Amount Credited

Total

Rs…………………(in Words) ……………………………………………………
Entry of the certificate done in register no……………………on page no………….

Signature officer
"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 69 -->

56

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 11
izkfIr
tSo fofoèkrk izcUèk lfefr dk uke %--------------------------------------------------------------------------------------------------iqLrd la[;k %--------------------------- fnukad %----------------------------------------izkfIr la[;k %-----------------------------------------------Jh@Jherh@dk;kZy; % --------------------------------------------------------------------------------------------------------------------------------irk % -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------izkIr fd;k uxn@psd@Mªk¶V cSad dk uke % -----------------------------------------------------------------la[;k %----------fnukad %----------------------------------------ys[kk 'kh"kZd-----------------------------------------ds vUrxZr izkIr èkujkf'k :i;s ¼vadksa esa½ -----------------------------------izkIr èkujkf'k :i;s ¼'kCnksa esa½% ----------------------------------------------------------------------------------------------------------------------fuxZr ^izkfIr jlhn^ psd Hkqxrku izkfIr dh izR;k'kk esa dh x;h gSA

gLRkk{kj ,oa eksgj
lfpo] tSo fofoèkrk izcUèk lfefr@
vkgj.k forj.k vfèkdkjh

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 70 -->

57

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 11
Receipt
Name of Biodiversity Management Committee ……………………………..………
Book No…………………………. Date………………………….
Receipt No………………………..
Mr./Ms./Office…………………………………………………………………………
Address………………………………………………………………………………
…………………………………………………………………………………………
Received cash/cheque/draft of bank………………………………….. no………..…..
Dated……………………………….
Received amount entered under accounting head…………………………………
Received Rupees (in figures)…………………………………………………………
(In words)………………………………………………………………………………
Receipt of payment made subject to realization of the cheque.

Signature & Stamp
Secretary BMC/
Drawing Disbursement officer

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 71 -->

58

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 12
pSd@Mªk¶V jftLVj
tSo fofoèkrk izcUèk lfefr dk uke %-----------------------------------------------------------------------------------Ø-la-

cSad Mªk¶V@psd
vnkdrkZ dk uke

1

2

cSad Mªk¶V@
psd la[;k
rFkk fnukad
3

cSad dk uke

4

Js.kh èkujkf'k ¼`½ vfHk;qfDr

5

6

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

7

<!-- page 72 -->

59

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 12
Cheque/Draft Register
Name of Biodiversity Management Committee : …………………………………
S. No.
(1)

Bank Draft
Cheque Payee
Name
(2)

Bank Draft/
Cheque No. &
Date
(3)

Name of Bank Category Amount Remark
(`)
(4)

(5)

"Biodiversity Conservation ..................... An art of living with nature"

(6)

(7)

<!-- page 73 -->

60

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 13
fcy jftLVj
tSo fofoèkrk izcUèk lfefr dk uke %-----------------------------------------------------------------------------------fnukad

1

fcy fcy dk fcy dh lfpo] ch- Hkqxrku
la[;k izdkj
èkujkf’k ,e-lh-@ dk
vkgj.k
rjhdk
forj.k
vfèkdkjh
ds gLrk{kj

2

3

4

5

6

psd
la[;k
vFkok
izek.k
i=
la[;k

7

vfHk;qfDr
psd
èkujkf’k lfpo]
ch-,ela[;k ¼`½
lh-@
rFkk
vkgj.k
fnukad
forj.k
vfÌdkjh
ds
gLrk{kj
8
9
10
11

uksV %
1- dkWye la[;k& 06 esa uxn vFkok cSad n'kkZ;saA
2- fcy ij Hkh fcy dh Øe la[;k n'kkZ;saA fcy dh Øe la[;k foRrh; o"kZ ds vfUre vadksa
ds vuq:i gksxkA
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 74 -->

61

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 13
Bill Register
Name of Biodiversity Management Committee : …………………………………
Date

Bill
No.

Bill
Bill
Type Amount

(1)

(2)

(3)

(4)

Drawing Payment
Secretary
mode
BMC / Disbursement
officer
signature
(5)
(6)

Cheque
number
or certificate
number
(7)

Cheque Amount Drawing Remark
Number
(`)
Secretary
& Date
BMC/ Disbursement
officer
signature
(8)
(9)
(10)
(11)

Note :
1. Mention Cash or Bank in column no. 6.
2. Bill serial no. should be mentioned on bill also. Bill serial number will be according
to financial year’s end digits.
"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 75 -->

62

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 14
uxn Hkqxrku izek.k i=
tSo fofoèkrk izcUèk lfefr dk uke %-----------------------------------------------------------------------------------------------------------izek.k i= dh Øe la[;k %-------------------------------------------------------foHkkx@'kk[kk dk uke % --------------------------------------------------------------- fnukad % ----------------------------------------------fcy Øe la[;k % ------------------------------ fnukad % -------------------------------------` ---------------------------------------- ¼'kCnksa esa½ %--------------------------------------------------------------------------------------------------------------

dk uxn Hkqxrku fd;k tk;sA Hkqxrku èkujkf'k dks ys[kk 'kh"kZd --------------------------------------------ds vUrxZr izfof"B dh tk;sA Hkqxrku lEcUèkh fooj.k jksdM+ cgh dh i`"B la[;k --------------------------fnukad ----------------------------esa ntZ dj lEcfUèkr dks Hkqxrku fd;k rFkk izkfIr vfHkys[kksa esa j[kkA

gLRkk{kj ,oa eksgj
lfpo] tSo fofoèkrk izcUèk lfefr@
vkgj.k forj.k vfèkdkjh

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 76 -->

63

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 14
Cash Payment Certificate
Name of Biodiversity Management Committee : …………………………………
Certificate Serial No……………………………………………….
Department/Branch Name…………………………………… Date………………
Bill Serial………………………… Date……………………
Rs………………(in Words)…………………………………………………………
Be paid in cash. The payment amount should be entered under……………………
accounting head.
Payment particulars recorded on cash book page number………dated……………
Payment of the concerned done and receipt of the same kept in records.

Signature & Stamp
Secretary BMC/Drawing
Disbursement officer

"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 77 -->

64

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 15
pSd Hkqxrku izek.k i=
dk;kZy; dk uke %--------------------------------------------------------------------------------------------------------------------------------------------izek.k i= Øe la[;k %-----------------------------------------------foHkkx@'kk[kk dk uke % --------------------------------------------------------------------------------- fnukad -------------------------------fcy dh Øe la[;k ---------------------------------------------------------------------------------------- fnukad % -------------------------------` --------------------------------------------------¼'kCnksa esa½ %------------------------------------------------------------------------------------------------------

dk Hkqxrku fuEuor~ psd }kjk dh tk;sA
Ø- la¼1½

uke

pSd la[;k

fnukad

èkujkf'k

¼2½
¼3½
¼4½
¼5½

mijksDr Hkqxrku èkujkf'k dks ys[kk 'kh"kZd ------------------------------------------------------------ds vUrxZr izfof"B
dh tk;sA

gLRkk{kj ,oa eksgj
lfpo] tSo fofoèkrk izcUèk lfefr@
vkgj.k forj.k vfèkdkjh
ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 78 -->

65

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 15
Cheque Payment Certificate
Name of Office:……………………………………………………………………….
Certificate Serial No:……………………
Department / Branch Name:…………………………………………………………
Date………………………
Bill Serial……………………..………………………… Date………………………..
`………………(in Words) ………………………………………………… be made

paid through following cheque.
S. No.
(1)

Name

Cheque Number

Date

Amount

(2)
(3)
(4)
(5)

The above payment amount should be entered under……………………………
accounting head.

Signature & Stamp
Secretary BMC/
Drawing Disbursement officer
"Biodiversity Conservation ..................... An art of living with nature"

<!-- page 79 -->

66

tSo fofo/krk izcU/k lfefr ¼ch0,e0lh0½ ds lapkyu gsrq fn'kk&funsZ'k

,usDlj 16
izek.k i= jftLVj
Ø-la- fcy Øe la[;k ,oa èkujkf’k
uxn Hkqxrku psd Hkqxrku lfpo] ch-,e-lh- vfHk;qfDr
fnukad
izek.k i= la[;k izek.k i= @vkgj.k forj.k
la[;k
vfèkdkjh ds
gLrk{kj
1
2
3
4
5
6
7

ßtSo fofo/krk laj{k.k -------------------- izÑfr ds lkFk thus dh dykÞ

<!-- page 80 -->

67

Guidelines for Operationalization of Biodiversity Management Committees (BMCs)

Annexure 16
Certificate Register
S. No. Bill Serial Amount
No. & Date

(1)

(2)

(3)

Cash
Payment
Certificate
No.
(4)

Cheque
Signature
Remark
Payment
Secretary
Certificate No. BMC/Drawing
Disbursement
officer
(5)
(6)
(7)

"Biodiversity Conservation ..................... An art of living with nature"
