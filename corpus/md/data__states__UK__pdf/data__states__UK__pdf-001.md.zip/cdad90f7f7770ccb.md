---
doc_id: "cdad90f7f7770ccb"
source_url: "https://cdnbbsr.s3waas.gov.in/s33cf2559725a9fdfa602ec8c887440f32/uploads/2026/07/202607021514085464.pdf"
ministry: "Directorate of Training & Employment, Uttarakhand"
title: "SA Transfer Order-2026"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "67922ae2e830e853"
---

<!-- page 1 -->

tqrqts{ frrTrtr, sRlqflur \,ti tErd-s{, fttqffiq
ffinrelw, E€rft (if,rf,rd)
rrii-o 7dfifu(tero) /l-r /enilo / zoza

ftdi-o-3o q;T 2026
orqff,q-sil-t{r

Hfu{r-q} d
\ry{ffT sdrrcru-s d}-fi-ecdi d ftq otff-o. Tafl"il.flut eiHftqq-zotz ti ft.kdqrgs
qn
qr
3ifu-a
ftq oTffii sl-$ erq d
ci-f,.fd nfui"T sfr.fr ggr of r1-ff q-{gfr d enrm
rq ffi se tS E-q sRq-.qi d srq rerqt<${ frrqr qr vu B fu qeffirf,fud 6Tffi6 r€IFII'cNUl
q-fr&Tl frtn C-fl o-rdqn ]IsuI @-{qI
sTapT n=m *i 6 nO t q6 skTr6 d er"Eq qfr{€rr-ft qft
ghpad *11 q-EqRrd Hftolt teililERf, @Tffi-dr d neyn (@'lrT cf,-qgffi of | ci-q5ffi Et-i qd
6.1ffo frqq1EsTq crgn-q o-r*T{ qgur @-{i @t 3r-qB (Joining time) d 3ffio-rcr 6-1 gqrfil Tq
ffi d .rq # o-rt qsq 6-$ d s.R[.f, fr znq sfirr ow q-qgBf, d s-q-sr< rTr, €ngrq qlrl
emts (Journey Time)" or fr sql+{T or sdi t enqr'nRo oTffio. o\ qs q-ots +t frrS q-4-l-{ or
qqorci rff-qf,'r-fi fr# \iTtTr eil-q ren-{r.ilkd qlffif, gRI Tq ffi rellq trt o-rdqx q5o1 q o-{i
rN s-q-d frs-q qNI 24 A 3E-qT{ Eo-srfrro o.rffi qft qfuft | terqrf,R-f, o-lffi+1 @-l qr6
'2026 6I Affi B!-d Tq ffir {.SIFI
ra t eneRo frtqr sri-qT
froq0

qfr{rc

qffIlq

o-dqtt iD-r qrlt

4rrft Rrqr rhrm

{eI=il<KUI d tn-Og5q TS

ffi

3rgfrf,

ffiwc Rrroq

o-rqtf,q tnt;tttl
Eror €-qrqlq-q o-ftlfdq, f-6fl

sd?-f, q

ctrAqfr-

S*q Sflqtw{

fu-ar A-flmw{ olqff,q,

q-{fFa g

r

3i-Asooq-Til-q-o
erdq-fi-

orofcq, teirfl
ffiar Sqrqlqq
oTqfds s-(trqFl
fffa[ sqrqtqq

d-fiq €-qrqtw{ oTqfdq,

wcfB-f, g

t

t_6Rr$
sfuerq si +qrfqq fi?elltrq,

w{lra q

o-rqfdq, ftE-ft

E€tft

orqtf,q tnt qFI

1

I

ffit

crqso-

I

qrq-\{qu@'
2

J

*1I rwilu qun

$) s{q-a f+E

qo el+r

4

rfGF]EI qq-q

\5ftt

aFt

$_EqtIFI'

1. rrfuq

7.

1x-q-{ref gq Gil-{r{rfi. .Frffi i-g nBo

r

t

\ti ffiq-{, sdtrcp-s qlrcrq, twEq

o

t

Rfu-{ s6.rqqg{ rts, qrr'l-{r, trqrqs

qkikaffiq-{erffit

t

I

I

nq {-qHvrt t-ts{/et+q ffio-q GTffi, iEql(q o) qq fr{Yr d srer fu
{€lFrmr{q GIDft.qq of qm ze (to) S clfi-{ TeIFIT<Nur GrreeT (GFIET Eqrrfl=q
aq-{rqc .r< q-ERf-f, (GTq-*s) o-r<r gFtrqo of

8.

l

(=Tk f,{e q"srft) rns
frtqTo, ffi-c-{
rqRHiB-d

2. q-sregt,m-n Gfi-d-{q M
3. BqF-eqm +qiq-Iq-{, zo {ofio ris sf +fr t6-{r({
o<P-o fiat
4. grw/oRw offir7su+Mr
5. e)dq eqrdqq oIffi ot-€msr/t-E-{-{q/A-qsr€-{
6.

I

I

gsrqr{- $6\-*/2-7eftfu(A+ro) /l-t /wrrfio / 2lzo

,;66fu:- ffifud d

I

qiqRrf, olffiqt
Trd q-drq-ff fttvirdq (Aoo)
I

t

t
