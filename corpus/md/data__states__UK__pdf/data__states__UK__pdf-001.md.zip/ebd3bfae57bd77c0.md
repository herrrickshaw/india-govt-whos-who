---
doc_id: "ebd3bfae57bd77c0"
source_url: "https://cdn.s3waas.gov.in/s3a7aeed74714116f3b292a982238f83d2/uploads/2025/06/2025062317.pdf"
ministry: "Bageshwar"
title: "Under the order of Panchayat General Election 2025, Section 163"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d7808b952429c15f"
---

<!-- page 1 -->

1&

1&

re-

1&

,

,

1&

i& -= I&

"':

-1&

1Z

lo'

!fG,,g

lill lJ! 1~i iljf : I I fltl·1 ,I& I 1-1 -~'l
1
!I
.,
1
I
' 1 ~•
J i ~,,.. i;:
I
i 'i
I&
_ t 1!: iJ I&
i
II. i' f
l
~
~
I
~
,,..
& l ~ I&
-- 'I& ~ ~ i ; ~ ~ -ffi '( ~ -lli' •
re I :i& : ~ ! ,..
! - JE • -~ ~ i - Ir$
ff Jg ie 'I&
111 •!I !.,~ !
! 1,•~ ·t ~ ,-~~~J1;ZI~ 1 ,~ ~~
~
%:!_! ~: [l_~u. i ~ ~ ~ti~ !i 1 i i ti~t '1'i -fi1
g:l j!

I!?: ! E

ii§

15

,e

I&

I&

I& .

i§

.J. f€ tr: d,C .,. -

1: -1& t !. ~ t
ti B'. ~ 1 : t ,,.. 1 ! i ,i i ~ 1 !?, !1f1& , t i l f ;ti ;1µ
!!l !¥ ,% ~ j
f ""Jt[
i -l I t ii I ~ 1r ,,, i ii. i ~ - 1;;; r. - f ""
-~ ll~ !-~ii ti1.!i11 Ii; ~i 41Ii ;j; i il~!ii!i.;ii!i-f!-:t i;
1 ! ~i!t!! 1 11 !,~i It ;;1 l !1 !!11:-~rt 1;i!ii~ -iiit~, ~t!t ; :;
;'Ii"

l,t,c,

IJ'

!fG,

~ fi11&;t1& fl{1
~i! "' ~:?1ti1!i~ l!:!~ 1!r ~~i !iii! i, ;i
i:i ~ !~ ilii f ~! ~Ii I ! ~ti I ~i1J! ~ ~::t t; :~ ;f i!i! i'!;

• ><.
,~

..,

f

"I:

.;

:

'IJ' -

.)

-·

.'_,, .I

•

~

It,. <f;;

.,..

: _/

----~

/.

A•-•j•

J :'V
..

'·,

;

~•

-

Wt' ~Iii~ I&,.,. - - """ti'!& !ii. J;; SC ij~
,,,.,,~t1& '-'-Ir 1& .,. i ~ = i
i I i ~ t¥ ! ! - '.; ~ - 1 I j j 1& , 1& t J t ~ : ~ -= _ 1.F-> :ix=dE
<lE w ~ :4 ~-=
<lE ~ i ... 1 t i J. E ~
i:· ·-'!&1&tidi1&1 Eti ii . i1e:~~ 11&1&~!~i~=-it;.ts-~~,.,. i-r~~ ~1&~ -- ~
1&!!f 1~~> fl1&t il!'~~ 1& i ~:,~~ 1!u.w i&.,t? :_.;t: 1i~1i ri~ t/d~1= tccii~.
[ I&: ~f 11&!-/Pr 11,c;l i f 1 - ~l" .- _
Ir .~ - • I ~ -1 -• t t ~
... ~ <jj; -I& ·• ~,
re .

4E ~ ~ I&

~

I

~

~

4

•

"'

\

'. . " "
.\ ,~\

<!-- page 2 -->

tr -~

.

i ! ,~~ I
-!-~ -rsi i ~ -

t,'-:()

..--

..--

~$
It)

:;'.J

-

•

...._

iI

\._r

.

I

0

'"r""'

•

N

o

•

•
('f")

o

LC"J

g o

•

1i 1
!1 l ~~~
~~

.

✓•

I

t:1-

~•
. V

li

9;.;,..~~ :. • ·-\'J'• . . \

\ r"· '
lie r ,~,":
r:· }_;
~\
',t.

' -- ..~.~ ~ .

.

0

i '-g. ,

'j

t N

- 8••

;. N

:T
V

~

:r&

~ .lg

- ?5

r- ~

l

r

~

1?

~

c;
~~

•

-~

.•

t I It -!·I~ 1 ~ \ ii ~
~i ~
i~I 111&J ~ I
ti 1wi :if~ g: i \I&\~ 3
t -rs i ~ ~ i t ~ i J Cf
.lg
i~ .!~
&

r

; ~; fii t. ~ i I
:mi~:1! ;!t

-1== ~, 1& l i 1 ~ 1tr
~~~~~~

~

r

J

••

.""'

~

o

u..,

o

,-..

t

~

o

\,,AJ

o

'-''

.....,,.

•

... ..

-

-

-

~ \~f 1•
t

Q

J

iJ

-i ~·f

I -~

~~

rg ~1

!i
~?1&

-

..-- ..- ..- ..- ..- ..-
