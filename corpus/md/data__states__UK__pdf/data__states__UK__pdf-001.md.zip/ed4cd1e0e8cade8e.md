---
doc_id: "ed4cd1e0e8cade8e"
source_url: "https://cdnbbsr.s3waas.gov.in/s3ac1ad983e08ad3304a97e147f522747e/uploads/2025/01/20250109434034193.pdf"
ministry: "Uttarakhand Housing and Urban Development Authority"
title: "The Uttarakhand Urban and Country Planning & Development Act, 1973 (Town Planning Amendment Act, 2022)"
date: ""
pages: 8
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "209bc8e65c0ea37a"
---

<!-- page 1 -->

उत्तराखण्ड असाघारण गजट, 23 दिसम्बर, 2022 ई0 (पौष 02, 944 शक सम्वत्‌) 9
SS EE SISO Neen e022 92 IN OZ al BS RLS /0 5: ५ >
No. 362/XXXVI(3)/2022/74()/2022
Dated Dehradun, December 23, 2022
NOTIFICATION
Miscellaneous
In pursuance of the provisions of Clause (3) of Article 348 of the
Constitution of India, the Governor is pleased to order the publication of the
following English translation of ‘The Uttarakhand Urban and Country
Planning and Development (Amendment) Act, 2022 (Act No. 8 of 2022)’.
As passed by the Uttarakhand Legislative Assembly and assented to
by the Governor on 22 December, 2022.
The Uttarakhand Urban and Country Planning and Development
(Amendment) Act, 2022
: (Uttarakhand Act No. 8 of 2022)
An
Act
further to amend The Uttarakhand Urban and Country Planning and Development,
973 to the context of State of Uttarakhand.
Be it enacted in the Seventy Third Year of the Republic of India by the Uttarakhand
Legislative Assembly as follows:-
Short title and (2) This Act may be called The Uttarakhand Urban and Country
commenceme Planning and Development (Amendment) Act, 2022.
nt (2) It shall come into force at once.
Amendment of For Sub-section () of section of the Uttarakhand Urban
Section 4 and Country Planning and Development Act, 973 to the
context of the State of Uttarakhand (hereinafter referred to
as the principal Act), the following sub-section shall be
substituted, namely :-
“() This Act may be called the Uttarakhand Urban and
Country Planning and Development Act, 973.”

<!-- page 2 -->

40 उत्तराखण्ड असाधारण गजट, 23 दिसम्बर, 2022 Fo (पौष 02, 944 शक सम्वत्‌)
- of | 3. की oe clause (c), the following clause shall be inserted,
namely:-
“(cc) “State Government” means the State Government of
न Uttarakhand.” f
: (ii) after clause (n), the following clauses shall be inserted,
A namely:-
“(o) “Local Area Plan” means the plan made under
Section 9-A of this Act.”
“(p) “Town Planning Scheme” means the scheme made
under Section 9-A of this Act.” |
Amendment of | 4. In sub-section 2-A(4) of Section 4 of the principal Act after
Section 4 clause (d), the following clause shall be inserted namely:-
“(dd) A full time Joint Chief Administrator appointed by the
State Government.” who shall not be below the rank of
Deputy Secretary/Joint Secretary to the State
2 | Government; धर
Amendment | For the sub-sections (4), (2) & (3) of Section 5 of the principal
Section 5 Act , the following sub-sections shall be substituted as
follows namely:-
/॥(4) The State Government may be notification in the official
Gazette appoint the Chief Administrator, Additional Chief
Administrator, Joint Chief Administrator and the Finance
Controller of the State Authority, as provided in sub-section
2-A of Section 4, who shall exercise such powers and
perform such duties as may be prescribed by regulations or
delegated to them by the State Authority. :
(2) Subject to such control and restrictions as may be
determined by general or special Order of the State ‘
Government, the Chief Administrator or the Additional Chief
Administrator or the Joint Chief Administrator of the State
Authority may appoint number of other officers and
employees as may be necessary for the efficient
performance of the functions of State Authority and may
determine their designations and grades,
(3) The Chief Administrator, Additional Chief Administrator,
Joint Chief Administrator, the Finance Controller and other
officers and employees of the Authority shall be entitled to
receive salaries and allowances from the funds of the State
Authority and shall be governed by such salaries, allowances
and other conditions of Service as may be determined by
regulations made in this behalf by the State Government.”
EE 2

<!-- page 3 -->

उत्तराखण्ड असाघारण गजट, 23 Emer“) Semmes to omen काई 2022 ¥o (पौष 02, 944 शक सम्वत्‌)
Amendment of | 6. The heading of Chapter ॥ of the principal Act shall be
Heading of substituted as follows namely:-
Chapter Ill “Chapter ॥- Master Plan, Zonal Development Plan, Local
Area Plan and Town Planning Scheme.”
Insertion of 7. | (7) After Section 9 of the principal Act, the following section
new section shall be inserted namely:-
SA “9-A Local Area Plan and Town Planning Scheme- ;
हू (3) The Local Authority may make one or more Local Area
Plans or Town Planning Scheme(s) in respect of any
area within its development area with prior approval
of the State Authority, in accordance with the rules
framed by the State Government for the execution of
‘hes the said Local Area Plan or Town Planning Scheme.

(2) The Local Area Plan or Town Planning Scheme so
made shall be examined by the State Authority and
the same shall be submitted to the State Government
for its approval. Monitoring and supervision of these
plans shall be done by the State Authority.

(3) If any area not included, within the development area
of the Local Authority and where the Local Area Plan
or Town Planning Scheme has to be framed and
implemented then the said area will be declared as
the development area of the Local Authority by the
State Government itself or on the recommendation of
the State Authority for the purpose of

J implementation of the Local Area Plan or Town
Planning Scheme :
Provided the State Government may get the work of
construction and implementation of Local Area Plan
or Town Planning Scheme from any other ‘agency
other then the State Authority or the Local
३ Development Authority.
(4) Notwithstanding anything contained in the provisions
of this Act, the Local Area Plan or Town Planning
Scheme shall have an overriding effect over the
Master Plan or Zonal Development Plan prevalent for
५ the time being.”

Amendment of | 8. For the the sub-section (2) of Section 40 of the principal Act

Section 40 the following sub section shall be substituted namely:-
“(2) Every plan shall, as may be after its preparation be
submitted essentially by the Town and Country Planning
Department or any other agency appointed/nominated by
the State Authority to the State Authority, which the State

eee

<!-- page 4 -->

|
42 उत्तराखण्ड असाघारण गजट, 23 दिसम्बर, 2022 Fo (पौष 02, t944 शक AAI)
aE shall submit to the State = for approval
and the State Government may either approve the plan
without modification or with such modifications as it may
| consider necessary or reject the plan with directions to the
| ‘ State Authority for getting a fresh plan prepared accordingly
| “to such directions.”
‘| Amendment of | 9. For the sub-sections (2) & (6) of Section 33 of the principal
Section 3 Act, following sub-sections shall be substituted namely:-
(2) The State Government may make amendments in the
master plan or the zonal development plan or or local area
\ plan or town planning scheme whether such amendments
are of the nature specified in sub-section (4) or otherwise.
(6) If any question arises whether the amendments proposed
to be made by the Town and Country Planning Department or
any other agency appointed/nominated by the State
; Authority or due authorization from the State Authority, are
amendments which agree important alterations in the
character of the plan or whether they relate to the extent of
land uses or the standards of population density, it shall be
referred by the State Authority to the State Government
whose decision on the same shall be final.

Amendment of | 40.| In the principal Act, in section 26, the title with sub-sections :

Section 26 (2) & (3) shall be substituted as follows namely:-

“Fine” (2) Any person who whether at his own instance or at the |
instance of any other person or anybody (including a
department of Government) undertakes or carries out
development of any land in contravention of the master plan or
zonal development plan or local area plan or town planning
otal or without the permission, approval or sanction
tril to in section 4 or in contravention of any condition
He ect to ay such Permission, approval or sanction has

een granted, fine shall be imposed on him as follows : --
i sl aforesaid act committed first time -Rs. 5,000/-
i) et a saa act committed second time- Rs. 40,000/-
oresaid act committed third time - Rs, 20,000/-
In ca | आफ
POPU itera eg pee amount
© such as may be determi
6 a ined by the State
overnment from time to time. 2!
(2) Any person who
uses nas ;
contravention of the 2 बा me = land or building |
imposed on him as follows - oF Section 6 fine shall be

<!-- page 5 -->

उत्तराखण्ड असाघारण गजट, 23 दिसम्बर, 2022 Fo (पौष 02, 4944 शक Wad) 43 |
ee eee Ne ee en
\ i) for the aforesaid act committed first time - Rs. 5,000/-
ii) for the aforesaid act committed second time- Rs. 0,000/-
दर for the aforesaid act committed third time - Rs. 20,000/-
कर In case of the aforesaid continuing act, the amount of
maximum fine shall be such as may be determined by the State
| Government from time to time.
है (3) Any person who obstruct the entry of a person authorized
under Section 25 to enter into or upon any land or building or
harass such person after such entry, fine shall be imposed on
: him as follows -
i) for the aforesaid act committed first time - Rs. 5,000/-
ii) for the aforesaid act committed second time- Rs. 0,000/-
iii) for the aforesaid act committed third time - Rs. 20,000/-
In case of the aforesaid continuing act, the amount of
maximum fine shall be such as may be determined by the State
Government from time to time.
Amendment of | 3.| For the following sub-sections (4) & (3) of Section 26-A the ।
Section 26-A following sub-sections shall be substituted namely:-
ढ([3) In case any person makes any encroachment or creates
। obstruction on any land not being private property, whether
| such land belongs to the authority or vests in its development
area or not, except steps over drain in any public street shall be
punishable with simple imprisonment for a term which may
extend to one year and with fine which may extend to Rs.
20,000/-.
(3) Whoever by placing or depositing building material or any
other thing whatsoever, or otherwise makes any obstruction in
any street or land not being private property, whether such
street or land belongs to or vests in the Authority or not,
except steps over drain in any public street, or placing of
| ‘building material during such period as may be permitted on-
payment of stacking fees on a public street of public place, fine
shall be imposed on him as follows:-
i) for the aforesaid act committed first time - Rs. 5,000/-
ii) for the aforesaid act committed second time- Rs. 0,000/-
iii) for the aforesaid act committed third time - Rs. 20,000/-
In case of the aforesaid continuing act, the amount of
maximum fine shall be such as may be determined by the State
Government from time to time.

<!-- page 6 -->

| 44 उत्तराखण्ड असाघारण गजट, 23 दिसम्बर, 2022 Fo (पौष 02, 944 bub = हे
| Amendment of [42. | For Section 26-D of tHe principal Act, the following section shall
Section 26-D be substituted namely:-
“fine for not “(26-D)(2) Whoever specially entrusted with the duty to stop
| | Preventing . or prevent the encroachment or obstruction under this Act or
| encroachment’ any other Act, or rules or bye-laws willfully or knowingly
| neglects or deliberately omits to stop or prevent such
encroachment or obstruction, fine shall be imposed on him as
follows:-

| ५ | i) — for the aforesaid act committed first time - Rs. 0,000/-
ii) for the aforesaid act committed second time- Rs. 20,000/-
iii) for the aforesaid act committed third time - Rs. 30,000/-

: In case of the aforesaid continuing act, the amount of

maximum fine shall be such as may be determined by the State
Government from time to time.
(2) Departmental Disciplinary action under the provisions of
Uttarakhand Government Servant (Discipline and Appeal)
Rules, 2003 (as amended time to time) shall also be taken
against the duty entrusted person along with fine imposed
under sub-section ([4).

Insertion of 33. | After Section 32 of the principal Act, the following Section shall

| new Section be inserted namely :--
| 32A /(4) The acts committed under Section 26 and sub-Section (3)
“Compounding of 26-A may be compounded by the Vice Chairman of the
7 of acts” concerned Authority.
| (2) An Appeal may be presented before the Commissioner/ |
| Chairman of the concerned Development Authority against the
| order of compounding passed by the Vice Chairman within 30
days.
(3) The acts committed under Section 26-D of the Act may be
compounded by the Vice Chairman of the concerned Authority.
(4) An Appeal may be presented before the Commissioner/
Chairman of the concerned Development Authority against the
order of compounding passed by the Vice Chairman under sub-
section (5) within 30 days, in case the Appointing Authority of
the concerned person is Vice Chairman or otherwise before the
sail Authority. The order passed in an appeal shall be
inal.
(5) The amount determined in the order of compounding
may be recovered as arrears of land revenue,
a Pik coe पद shall be disposed of within
order of compoundi है बह hereof and appeal against the |
essentially” ng shall be disposed of within 30 days |
|
OC 9...

<!-- page 7 -->

उत्तराखण्ड असाघारण गजट, 23 दिसम्बर, 2022 ई0 (पौष 02, 944 शक सम्वत्‌) 45
Amendment ft) Roe Section 48 of the principal Act the following section shall be
Section 48 substituted namely :-

“No court inferior to that of Magistrate of the First Class shall
try an offence punishable under sub-section (4) of Section 26 A
of this Act.”
d Amendment of For the sub-sections (2) and (4) of Section 54 of the principal
Section 54 Act, the following sub-sections shall be substituted namely :--
“(2) The State Authority, may by general or special order,
direct that any power exercisable by it under this Act except
the power to make regulations or byelaws, may also be
exercised by such officer or local Authority, in such cases and
subject to such conditions, if any, as may be specified therein.
(4) The Chief Administrator of the State Authority may by
general or special order direct that any power exercisable by
him under this Act may also be exercised by the Additional
Chief Administrator or Joint Chief Administrator or any other
officer of the State Authority in such cases and subject to such
conditions, if any, as may be specified therein.”
Amendment of After sub Section 2 of Section 55, of the principal Act the
Section 55 following sub Section shall be inserted namely:-
ध[2-0)(4) The State Government may make rules from time to
time by Notification for preparation, implementation and
execution of Local Area Plan(s) and/or Town Planning
Scheme(s).”
Amendment of | 7. | For clause (bb) and clause (cc) of sub-section 2 of Section 56 of
Section 56 the principal Act shall be substituted as follows namely:-
“(bb) The powers and duties of the Chief Administrator,
Additional Chief Administrator, Joint Chief Administrator and
Finance Controller of the State Authority.
“(cc) The salaries, allowances and conditions of service of the
Chief Administrator, Additional Chief Administrator, Joint Chief
Administrator, Finance Controller and other officers and
employees of the State Authority.
By Order,
HIRA SINGH BONAL,
Principal Secretary.
= em 2 2 >> लंबे

<!-- page 8 -->

46 उत्तराखण्ड असाघारण गजट, 23 दिसम्बर, 2022 ई0 (पौष 02, 944 शक सम्वत्‌)
a aE ech at aa i ele a eh कक Ure ४5
Statement of purpose and reasons
Keeping in the view the trend of urbanization due to the increase of
population the State Government is taking serious actions in the directions to give
the concrete shape to the concept of planned development. Development
Authorities has been constituted in every district of the State to ensure the planned
development. In the process of the planned development, it is inevitable to
establish better ‘coordination between authority and the general public and for the
inclusive development it is necessary too. Keeping the public interest paramount,
establishing the- balance between convenience and interests of the common man,
establishing the process of Local regional plan and town planning scheme for well
planned development, preventing the tendency of encroachment by the builder
during construction by imposing fine, with the aim to motivate the personnel of ५
the Authority to discharge their duties with integrity and honesty, the bill is
proposed to put on the table.
2s All the above things have been in the proposed bill.
3. The proposed Bill fulfills the above objectives,
: Prem Chand Agarwal
ge Minister
)
पी0एस0०यू0 (आर0ई0) 22 विघायी / 765-2022-00+500 (कम्प्यूटर,/रीजियो)।
Ee Se ff
