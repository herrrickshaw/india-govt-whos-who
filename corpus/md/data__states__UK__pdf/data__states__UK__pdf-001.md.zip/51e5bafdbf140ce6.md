---
doc_id: "51e5bafdbf140ce6"
source_url: "https://cdnbbsr.s3waas.gov.in/s30fe473396242072e84af286632d3f0ff/uploads/2025/02/202502191483775042.pdf"
ministry: "Agriculture Department, Uttarakhand"
title: "PM- RKVY Guidelines as on 14.11.2024 (PDF 6 MB)"
date: ""
pages: 354
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "5ca1156e19238b4d"
---

<!-- page 1 -->

OPERATIONAL GUIDELINES
FOR
PRADHAN MANTRI RASHTRIYA KRISHI VIKAS YOJANA
(PM-RKVY)

Department of Agriculture & Farmers welfare
Ministry of Agriculture & Farmers Welfare
Government of India
Krishi Bhawan, NewDelhi-110001

<!-- page 2 -->

Contents
Sl. No.

Particulars

Page no.

1

Introduction

8

2

Objectives

9-13

3

Eligibility criteria

14

4
5

14
14

6

Interstate Allocation
Cost norms and Pattern of assistance
Nodal Department of PM-RKVY

14-15

7
8
9

State Level Sanctioning Committee (SLSC)
Project Approval Committee (PAC)
Planning and Sanctioning of schemes

15
16
16-18

10

Release of funds

18

11
12

Pradhan Mantri Janjatiya Unnat Gram Abhiyan
Aspirational Districts and Vibrant Villages

19
19

13

Timeline

19

14

Implementation of PM- RKVY

20

A

DPR Component

20-22

B

AAP Component

23

I

PDMC

23-56

II

SMAM

57-75

III

CRM

76-87

IV

SH&F

88-97

V

PKVY

98-108

VI

RAD

109-120

VII

Agro Forestry

121-129

VIII

CDP

130-135

C

Agri Startup and Accelerator Fund

135

15

Administrative Expenses & Contingencies

136

16

Monitoring & Evaluation

136

17

Convergence

137

18

Changes in PM-RKVY

137

19

Applicability of the guidelines

137

20

Annexures:
1
*** PM-RKVY Guidelines ***

<!-- page 3 -->

Annexure I

Format for submission of Minutes of SLSC

Annexure II

Details of activities/projects as approved by SLSC

Annexure III

Form of Utilization Certificate

141

Annexure IV

Inter State Allocation of the funds under RKVY-RAFTAAR

142

Annexure V

Composition of State Level Sanctioning Committee (SLSC)

143

Annexure VI

Illustrative List Of Projects/Activities That Should Not Be
Funded Under RKVY- DPR Component
Detailed Project Report

144

Illustrative List of Projects that can be funded under RKVYRAFTAAR (Infrastructure & Assets)
Activities relating to Production stream under RKVY- DPR
component
Recommended norms for use of treated sewage quality for
specific activities at point of use
Format for Annual Action Plan– Per Drop More Crop (PDMC)
Format for Physical Progress Monitoring Report for Per Drop
More Crop (Micro Irrigation)
Format for Financial Progress Monitoring Report for Per Drop
More Crop (Micro Irrigation)

146-147

Annexure VII
Annexure VIII
Annexure IX
Annexure X
Annexure XI
Annexure XII a
Annexure XII b
Annexure XIII a
Annexure XIII b
Annexure XIII c
Annexure XIII d
Annexure XIII e
Annexure XIII f
Annexure XIII g
Annexure XIII h

Drip Irrigation Technology-Indicative Bill of Quantities 0.2 ha
Drip Irrigation Technology-Indicative Bill of Quantities 0.4 ha
Drip Irrigation Technology-Indicative Bill of Quantities1.0 ha
Drip Irrigation Technology-Indicative Bill of Quantities2.0 ha
Drip Irrigation Technology-Indicative Bill of Quantities3.0 ha
Drip Irrigation Technology-Indicative Bill of Quantities4.0 ha
Drip Irrigation Technology-Indicative Bill of Quantities5.0 ha
NEH States -Drip Irrigation Technology-Indicative Bill of
Quantities0.2 ha
Annexure XIII i NEH States -Drip Irrigation Technology-Indicative Bill of
Quantities0.4 ha
Annexure XIII j NEH States -Drip Irrigation Technology-Indicative Bill of
Quantities 1.0 ha
Annexure XIII k NEH States -Drip Irrigation Technology-Indicative Bill of
Quantities 2.0 ha
Annexure XIII l NEH States -Drip Irrigation Technology-Indicative Bill of
Quantities 3.0 ha
Annexure XIII m NEH States -Drip Irrigation Technology-Indicative Bill of
Quantities 4.0ha
Annexure XIII n NEH States -Drip Irrigation Technology-Indicative Bill of
Quantities 5.0ha
Annexure XIV Indicative Bill of Quantities (BoQ) for Portable Sprinkler
Irrigation System
2
*** PM-RKVY Guidelines ***

138
139-140

145

148
149
150-153
154
155
156
157
158
159
160
161
162
163
164
165
166
167
168
169
170

<!-- page 4 -->

Annexure XV

Indicative Bill of Quantities (BoQ) for Micro Sprinkler Irrigation
System
Annexure XVI Indicative Bill of Quantities (BoQ) for Mini Sprinkler Irrigation
System
Annexure XVII Indicative Bill of Quantities (BoQ) for Semi Permanent Sprinkler
Irrigation System
Annexure XVIII Indicative Bill of Quantities (BoQ) for Rain-gun Sprinkler
Irrigation System
Annexure XIX Water Quality Criteria In Relation To Clogging
Annexure XX
Guidelines for Selection of Filter
Annexure XXI Indicative Price of Optional Components
Annexure XXII Other Interventions to be provided as optional, if and only if a
farmer opted to install micro-irrigation System in his/her field
Annexure XXIII Gazette Notification
Annexure XXIV List of BIS Standards
Annexure-XXV Pattern of Assistance and Maximum Permissible Subsidy
Annexure-XXVI Procedure for Credit Linked Capital Subsidy
Annexure-XXVII List of Training Programmes conducted at the Farm Machinery
Training & Testing Institutes
Annexure-XXVIII List of institutions approved by the Department for Testing and
Certifying Agricultural Machineries and Equipments
Annexure-XXIX Pattern of Assistance and Maximum Permissible Subsidy for the
Farmers for procurement of crop residue management machines
on individual ownership basis
Annexure-XXX Pattern of Assistance and Maximum Permissible Subsidy per
machine under the projects of Custom Hiring Centres
Annexure-XXXI Procedure for Credit Linked Capital Subsidy on the Custom
Hiring Centres Projects and Paddy Straw Supply Chain Projects
Annexure-XXXII Indicative Capital Expenditure for Setting up Paddy Straw
Supply Chain
Annexure-XXXIII Sample Bilateral Agreement
Annexure-XXXIV User manual for Mobile application
Annexure-XXXV Citizen Charter
Annexure- XXXVI Manual for Soil Health Card Portal
Annexure-XXXVII Guidelines for setting up of Village Level Soil Testing Labs
AnnexureIllustrative list of equipment for setting up of Static Soil Testing
XXXVIII
Laboratory
Annexure-XXXIX Illustrative list of equipment for setting up of Mobile Soil Testing
Laboratory
Annexure-XL
Items and equipment for Strengthening of Static/ Mobile Soil
Testing Laboratory
Annexure-XLI Illustrative list of Equipments for setting up of new State
Fertilizer Testing Labs
Annexure-XLII Illustrative list of Equipments for Strengthening of existing State
Fertilizer Quality Control Laboratory
3
*** PM-RKVY Guidelines ***

171
172
173
174
175
176
177
178
179-182
183-184
185-200
201-202
203-205
206-207
208-209

210-211
212-213
214-215
216-229
230-280
281-284
285-328
329-338
339
340
341
342
343

<!-- page 5 -->

Annexure-XLIII

List of Equipments and Plant and Machinery for Setting up New
Bio-fertilizer and Organic Fertilizer (organic manures) Quality
Control Laboratory
Annexure-XLIV Rain-fed Area Development (RAD) Cost Norms
Annexure-XLV Format for Annual Action Plan (AAP) of RAD
Annexure-XLVI Rainfed Area Development (RAD) Progress Reporting Format
Annexure-XLVII Functions of National/State/District Project Management Team
(PMT)
Annexure-XLVIII Essential qualifications for Support Agency
Annexure-XLIX Roles and Responsibilities of Support Agency
Annexure-XLX Eligible Criteria for Regional Councils
Annexure-XLXI Roles and Responsibilities of Regional Councils as Agencies
endorsing PGS Certification Process
Annexure-XLXII Roles and Responsibilities of Lead Resource Persons (LRPs)
Annexure-XLXIII Methodology for providing certification assistance to individual
farmers/small farmer groups and large contiguous area under
traditional/default organic farming

4
*** PM-RKVY Guidelines ***

344

345
346
347
348
349
350
351
352
353
354

<!-- page 6 -->

Abbreviations
AAP
AIBP
ATMA
BIS
BOQCL
CAFRI
CDP
CHC
CIPET
CRM
CSIR
CST
DA&FW
DAPST
DBT

Annual action Plan
Accelerated Irrigation Benefit Programme
Agriculture Technology Management Agency
Bureau of Indian Standards
Bio-fertilizer and Organic Fertilizer (organic manures) Quality Control Laboratory
ICAR-Central Agroforestry Research Institute
Crop Diversification Programme
Custom Hiring Centre
Central Institute of Plastics Engineering and Technology
Crop Residue Management
Council of Scientific and Industrial Research
Central Sales Tax
Department of Agriculture & Farmers Welfare
Development Action Plan for Scheduled Tribes
Direct Benefit Transfer

DIP

District Irrigation Plan

DLIC
DoLR
DONER

District Level Implementation Committee
Department of Land Resources
Development of North Eastern Region

DPR
DRDA
EC
EMD
FMBs
FMTTI
FPOs
FQCLs
FRA

Detailed Project Report
District Rural Development Agency
Executive Committee
Earnest Money Deposit
Farm Machinery Banks
Farm Machinery Training and Testing Institutes
Farmer Producer Organizations
Fertilizer Quality Control Laboratories
Forest Right Act

GoI
HDPE
HP
HRD
ICAR
ICAR.

Government of India
High Density Polyethylene
Horse Power
Human Resource Development
Indian Council of Agricultural Research
Indian Council of Agricultural Research

ICFRE
ICRAF
ICT
IDWG
IEC
IFS

Indian Council of Forest Research & Education
International Centre for Research in Agroforestry
Information Communication Technology
Inter Departmental Working Group
Information Education and Communication
Integrated Farming System
5
*** PM-RKVY Guidelines ***

<!-- page 7 -->

Indian Meteorological Department
IMD
Integrated Nutrient Management
INM
Intensive Participatory Planning Exercise
IPPE
Indian Space Research Organisation
ISRO
Information Technology
IT
Integrated Watershed Management Programme
IWMP
Kisan Credit Card
KCC
Krishi Vigyan Kendra
KVK
MGNREGA Mahatma Gandhi National Rural Employment Guarantee Act
Million Hectare
Mha
Micro Irrigation
MI
Mission for Integrated Development of Horticulture
MIDH
MIS
MLALAD
MoA
MoJS
MoRD
MPLAD
NABARD

Micro Irrigation System/Management Information System
Member of Legislative Assembly Local Area Development
Ministry of Agriculture
Ministry of Jal Shakti
Ministry of Rural Development
Member of Parliament Local Area Development
National Bank for Agriculture & Rural Development

NABCONS NABARD Consultancy Services
NAC
NCONF

National Advisory Committee
National Centre of Organic and Natural Farming

National Committee on Precision Agriculture and Horticulture
NCPAH
National Executive Committee
NEC
North Eastern & Himalayan States
NEH
North Eastern Region
NER
National Food and Nutrition Security Mission etc
NFNSM
Non-Governmental Organisation
NGO
National Initiative for Climate Resilient Agriculture
NICRA
NMEO-OS National Mission on Edible Oil-Oilseeds
National Mission on Sustainable Agriculture
NMSA
National Rain-fed Area Authority
NRAA
Natural Resource Management
NRM
National Stewardship Council
NSC
Project Approval Committee
PAC
PDMC
PFMS
PGS
PKVY
PMJUGA
PM-RKVY
PMU

Per Drop More Crop
Public Financial Management System
Participatory Guarantee System
Paramparagat Krishi Vikas Yojana
Pradhan Mantri Janjatiya Unnat Gram Abhiyan
Pradhan Mantri Rashtriya Krishi Vikas Yojana
Project Management Unit
6
*** PM-RKVY Guidelines ***

<!-- page 8 -->

PPPAVCD Public- Private Partnership for Agriculture Value Chain Development
Panchayati Raj Institutions
PRIs
Public Sector Undertaking
PSU
Quality Planting Materials
QPM
Research & Development
R&D
Rainfed Area Development
RAD
RKVY-MIS RKVY-Management Information System
State Agriculture Infrastructure Development Programme
SAIDP
State Agriculture Plan
SAP
State Agricultural Universities
SAU
Soil Health and Fertility
SH&F
Soil Health Card
SHC
Self Help Groups
SHGs
Soil Health management
SHM
State Level Executive Committee
SLEC
State Level Sanctioning Committee
SLSC
SMAE
SMAM
STLs
UTs
VLSTLs

Sub Mission on Agricultural Extension
Sub- Mission on Agriculture Mechanization
Soil Testing Laboratories
Union Territories
Village Level Soil Testing Labs

7
*** PM-RKVY Guidelines ***

<!-- page 9 -->

Introduction

1.

Rashtriya Krishi Vikas Yojana (RKVY) was initiated in FY 2007-08 as an umbrella scheme
for ensuring holistic development of agriculture and allied sectors by allowing States to choose
their own agriculture and allied sector development activities as per the State Agriculture Plan.
Till 2013-14, the scheme was implemented as an Additional Central Assistance(ACA) to State
Plan Scheme with 100% central assistance. It was converted into a centrally sponsored scheme
in 2014-15 with 100% central assistance. Later on, the funding pattern of the scheme was
changed in 2015-16 and the ratio of central share and state share was fixed to 60:40 (except for
NER States and Himalayan States where it has been kept as 90:10). For Union Territories the
funding pattern is 100% central grant.

Based on the recommendations of Expenditure Finance Committee and feedbacks received
from States and NITI Aayog, RKVY has been restructured as a cafeteria scheme by merging
the seven Central sponsored schemes and renamed as Prime Minister-Rashtriya Krishi
Vikas Yojna (PM-RKVY) with the vision to enhance efficiency, efficacy and to avoid
duplications, ensure convergence and provide flexibility in planning to the State Governments.

The components of the PMRKVY are as follows: i)

Detailed Project Report (DPR)

ii)

Per Drop More Crop (PDMC)

iii)

Sub- Mission on Agriculture Mechanization (SMAM) including Management of
Crop Residue (CRM)

iv)

Soil Health and Fertility (SH&F)

v)

Paramparagat Krishi Vikas Yojna (PKVY)

vi)

Rain Fed Area Development (RAD)

vii) Agro- Forestry
viii) Crop Diversification Programme (CDP)
ix)

Accelerated Fund for Agri Start-Up

The restructured PM-RKVY will continue to be implemented as Centrally Sponsored Scheme.

8
*** PM-RKVY Guidelines ***

<!-- page 10 -->

2.

Objectives:

The main objective of PM-RKVY scheme is to provide flexibility & autonomy to States for
implementing projects as per the local and farmers’ needs and priorities in agriculture sector to
enhance production and productivity for making farming as a remunerative economic
activity.
The scheme also aims to support and scale up the startups under innovation and
entrepreneurship in various fields of agriculture and allied sectors to enhance income of farmers
and to create employment opportunities for the youth.
Specific objectives of the components under PM-RKVY are as follows:
I.

DPR:
 To strengthen the farmers' efforts through creation of required pre & post-harvest in
agriculture and allied sectors that help in supply of quality inputs, storage, market
facilities, etc. to farmers.
 To provide flexibility and autonomy to States to plan & implement projects as per the
local and farmers needs and priorities from a bouquet of activities in agriculture and
allied sectors.
 To fill the resources, gap of agriculture and allied sectors by providing financial support
to States for undertaking various activities to increase overall growth of agriculture and
allied sectors and farmers’ income.
 To promote agriculture and allied sectors activities of national priorities through
specific initiatives as per the needs from time to time to mitigate specific problems to
enhance production and productivity.

II. PDMC:
 To increase the area under Micro Irrigation technologies in agriculture to enhance water
use efficiency.
 To increase productivity of crops and income of farmers through precision water
management.
 Promote micro irrigation technologies in water intensive/consuming crops like
sugarcane, banana, cotton, paddy etc. and give adequate focus to extend coverage of
field crops under micro irrigation technologies.
9
*** PM-RKVY Guidelines ***

<!-- page 11 -->

 To make potential use of micro irrigation systems for promoting fertigation.
 To promote micro irrigation technologies in water scarce, water stressed and critical
ground water blocks/districts &water intensive/consuming crops like sugarcane,
banana, cotton, paddy etc.
 To link tube-well/river-lift irrigation projects with micro irrigation technologies for best
use of energy both for lifting and pressurized irrigation as far as possible.
 To establish convergence and synergy with activities of on-going programmes and
schemes, particularly with created water source for its potential use, integration of solar
energy for pressurised irrigation etc.
 To promote, develop and disseminate micro irrigation technology for agriculture and
horticulture development with modern scientific knowledge
 To support the initiatives of reuse of waste water in Agriculture/peri-urban Horticulture
through micro irrigation systems.
 To create employment opportunities for skilled and unskilled persons, especially
unemployed youth for installation and maintenance of micro irrigation systems.
III. SMAM:
 To increase the reach of farm mechanization to small and marginal farmers and to the
regions where availability of farm power is low;
 To Promote Custom Hiring Services of agricultural machines to offset the adverse
economies of scale arising due to small landholding and high cost of individual
ownership;
 To create awareness among stakeholders through demonstration, capacity building
activities and differentiated Information, Education and Communication strategies;
 To ensure performance testing and certification at designated testing centers located all
over the country;
(a) CRM:
 To protect environment from air pollution and preventing loss of nutrients and soil
micro-organisms caused by burning of crop residue;

10
*** PM-RKVY Guidelines ***

<!-- page 12 -->

 To promote management of crop residue by retention/incorporation into the soil and
establishing appropriate supply chain for further utilization through the deployment of
appropriate mechanization inputs;
 To create awareness among stakeholders through demonstration, capacity building
activities and differentiated Information, Education and Communication strategies for
effective utilization and management of crop residue.
IV.

SH&F:
 To issue need based Soil Health Cards to the farmers in the country, so as to provide a
basis to address nutrient deficiencies in fertilization practices.
 To strengthen functioning of Soil Testing Laboratories (STLs) through capacity
building, involvement of agriculture students and effective linkage with Indian Council
of Agricultural Research (ICAR)/State Agricultural Universities (SAUs).
 To diagnose soil fertility related constraints with standardized procedures for sampling
uniformly across states and analysis and design taluka/block level fertilizer
recommendations in targeted districts.
 To develop and promote soil test based nutrient management in the districts for
enhancing nutrient use efficiency and build capacities of progressive farmer for
promotion of nutrient management practices.
 To ensure quality control requirements of fertilizers, bio-fertilizers and organic
fertilizers under the Fertilizer (Control) Order (FCO), 1985, including revision of
standards and testing protocols keeping in view the advances in research and
technology and covering organic inputs under quality control regime.
 To promote Integrated Nutrient Management (INM) through judicious use of chemical
fertilizers, including secondary and micronutrients, in conjunction with organic
manures and bio-fertilizers, for improving soil health and its productivity.
 To support augmentation and strengthening of soil and fertilizer testing facilities
 To provide support to School Soil Health Programme
 To provide support to RAWE Programme for Agriculture Graduates

V. PKVY:
 To promote natural resource based integrated and climate resilient sustainable farming
systems that ensure maintenance and increase of soil fertility, natural resource
conservation, on-farm nutrient recycling and minimize dependence of farmers on
external inputs;
11
*** PM-RKVY Guidelines ***

<!-- page 13 -->

 To reduce cost of agriculture to farmers through sustainable integrated organic farming
systems thereby enhancing farmer’s net income per unit of land
 To sustainably produce chemical free and nutritious food for human consumption.
 To protect environment from hazardous inorganic chemicals by adoption of ecofriendly
low cost traditional techniques and farmer friendly technologies
 To empower farmers through their own institutional development in the form of clusters
and groups with capacity to manage production, processing, value addition and
certification management;
 To make farmers entrepreneurs through direct market linkages with local and national
markets
VI. RAD:
 To undertake location specific and landscape-based approach to dry-land areas to
ensure natural resources conservation and sustainable use, strengthening of agriculture
production systems and livelihood development through integration/convergence of
schemes in an area based approach.
 To make agriculture more productive, sustainable, remunerative and climate resilient

by promoting location specific Integrated/Composite Farming Systems;
 To conserve natural resources through appropriate soil and moisture conservation

measures;
 To develop capacity of farmers and stakeholders in conjunction with other ongoing

Missions such as National Food and Nutrition Security Mission, National Initiative for
Climate Resilient Agriculture (NICRA) etc., in the domain of climate change adaptation
measures;
 To improve the productivity of rainfed farming by mainstreaming rainfed technologies

refined under All India Coordinated Research Project on Dry land Agriculture
(AICRPDA-NICRA) and by leveraging resources/provisions made under other Govt
Schemes.

12
*** PM-RKVY Guidelines ***

<!-- page 14 -->

VII. Agro Forestry:
 To encourage and expand tree plantation in a complementary and integrated manner
with crops to improve productivity, additional income generation and improved
livelihoods of rural households, especially the small farmers.
 To ensure the availability of Quality Planting Materials (QPM) like seeds, seedlings,
clones, hybrids, improved varieties, etc. Quality Planting Material (QPM) of healthy,
resilient and adaptable nursery stock raised through seed or vegetative propagation
with an overall goal to improve the quality of the plants available to farmers and
growers.
 To popularize various agroforestry practices/models suitable to different agroecological regions and land use conditions through demonstration plots.
 To create a database, information and knowledge support in the area of agroforestry &
to provide Research & Development (R&D), extension and capacity-building support
to the agroforestry sector.
 To identify and catalyze linkages with traditional and emerging markets for the timber
and non-timber products generated from agroforestry plantation on farmland including
Bio-fuels, matchwood, plywood, silk, fiber, lac, beauty and wellness sector,
handicrafts, construction, etc.
 To promote value addition and processing of agroforestry produce by creating 2 31/2021-NRM-SMAF I/25439/2023 collection and post-harvest facilities for additional
income generation by farmers.
 To provide use of modern technology for monitoring and evaluation (M&E) on the
impact of agroforestry in agro-ecology.

VIII. CDP:
 To demonstrate and promote the improved production technologies of alternate crops

for diversion of paddy cultivation;
 To restore the soil fertility through cultivation of leguminous crops that generates, heavy

biomass and consume lesser nutrient intake crops.

13
*** PM-RKVY Guidelines ***

<!-- page 15 -->

3.

Eligibility Criteria:

PM-RKVY being a Centrally Sponsored Scheme, all States & UTs will be eligible for funding
under PM-RKVY.

4.

Inter-state allocation:

Criteria for interstate allocation is given under the programme components at Annexure IV

5.

Cost Norm & Pattern of Assistance:

The cost norms and pattern of assistance applicable for DPR and each of the AAP components
of PM-RKVY is elaborated in details in para 13 of this guideline. The funding pattern of the
schemes will be in the ratio of 60:40 between centre and state except of 90:10 for NER states
and Himalayan states. For UTs the funding pattern will be 100% central grant.

6.

Nodal Department for PM-RKVY:

Agriculture Department of the States/UTs shall be the nodal department and

Principal

Secretary Agriculture/ACS Agriculture / Agriculture Production Commissioner will be the
nodal officer for implementation of the PM-RKVY scheme. For administrative convenience
and ease of implementation, State

Governments

may identify or create an exclusive

agency for implementing the scheme on a fast-track basis. Even where such an Agency is
created/designated, the entire responsibility of ensuring proper implementation of each
components of PM-RKVY scheme rests with the Agriculture Department of the State. In a
situation where the States notify a Nodal Agency, the costs of running the agency, will have to
be met by them from within the 2.5% limit of allocation available under PM-RKVY for
administrative expenditure. States may supplement any administrative expenditure in excess of
the 2.5% limit, from their own resources.

The Agriculture Department / nodal agency will be also responsible for the following:


Effective coordination, preparation and appraisal of projects, implementing, monitoring
and evaluation with various Departments and implementing Agencies.



Management of funds received from the Central Government and State Government and
its disbursement to the implementing agencies.



Furnishing of utilization certificates (including uploading UCs in PFMS) and reporting
14
*** PM-RKVY Guidelines ***

<!-- page 16 -->

monthly/ quarterly physical & financial progress to the Department of Agriculture &
Farmers Welfare.


To update the web enabled IT based Management Information System of various
components of PM-RKVY regularly

7.

State Level Sanctioning Committee (SLSC):

A State Level Sanctioning Committee (SLSC) headed by the Chief Secretary of the concerned
State/UT will recommend and submit the consolidated Annual Action Plan (AAP) under each
component (both DPR and AAP) of PM-RKVY to Government of India (GoI). The
composition of SLSC is at Annexure V
SLSC should meet twice a year or as and when required to review the implementation of the
scheme.
Roles and Responsibilities of SLSC


To prepare and submit proposals to GoI as per approved guidelines and cost norms
of the respective schemes up to a maximum of 125% of the amount allocated to the
State under PM-RKVY in the prescribed format given at Annexure I.



In case of projects having implementation period spanning more than one financial
year, year-wise phasing of expenditure along with targets/milestones shall be
specifically mentioned in the minutes of the SLSC meetings.



To implement the sanctioned projects under PMRKVY as per the guidelines.



To ensure that all extant procedures and instructions of the GoI are followed so that
the expenditure incurred on implementation of the projects is the barest minimum
with due concern for economy in expenditure and also in conformity with the
canons of financial propriety, transparency and probity.



To ensure that adequate coverage of small and marginal farmers, Scheduled Castes,
Scheduled Tribes, Patta holders under FRA act, women and other weaker segments
of society is to be given while selecting beneficiaries under any components of
RKVY so that the benefits of implementation of a particular component of the
scheme is received by the intended beneficiaries in accordance with guidelines and
policies of the Government.

15
*** PM-RKVY Guidelines ***

<!-- page 17 -->

8.

Project Approval Committee (PAC):
There will be a PAC under the Chairmanship of Secretary, DA&FW, Government of
India consisting of Divisional Heads of the Department and other senior Officers to
examine, deliberate and approve the AAP submitted by the States under PM-RKVY.
The composition of the PAC is as follows:
S. No.

Designation
1

Secretary, Department of Agriculture &

Chairman

Farmers Welfare

9.

2

Additional Secretary & Financial Advisor

Member

3

Additional Secretary, DA&FW

Member

4

Joint Secretary (RKVY)

Member

5

Joint Secretary (PDMC)

Member

6

Joint Secretary (RAD/Agro Forestry)

Member

7

Joint Secretary (M&T)

Member

8

Joint Secretary (INM)

Member

9

Joint Secretary (Crops)

Member

10

Joint Secretary (MIDH)

Member

11

Joint Secretary (Seeds)

Member

12

Agriculture Commissioner

Member

13

Horticulture Commissioner

Member

14

Joint Secretary (PC)

Member Secretary

Planning & Sanctioning of Schemes:

The extant process of formulation and approval of DPR and AAP components of PM-RKVY
will be as follows:
i)
A tentative interstate allocation of funds will be communicated to the State
Governments for DPR & AAP component of PM-RKVY.
ii)

A consolidated component-wise project proposal i.e. AAP/DPR shall be prepared
16
*** PM-RKVY Guidelines ***

<!-- page 18 -->

in the prescribed format incorporating all essential details like feasibility studies,
competencies of the implementing agencies, outputs/outcomes framework, timelines for implementation etc.
iii)

Agriculture Department / Nodal department at state level will propose projects up
to a maximum of 125% of the amount allocated to the state.

iv)

Consolidated AAP should clearly indicate the year- wise physical & financial
targets proposed under each project.

v)

A meeting of SLSC will be convened to scrutinize /examine the projects proposed
by Nodal Department and submit the consolidated AAP for approval by GoI.

vi)

There will be flexibility to States for re-apportion of up to 50% of allocation for
the component from one AAP component to another AAP component of RKVY.
However, re-apportion of the allocation from AAP component to DPR component
or vice versa is not permissible.

vii)

In case one or more AAP components is not feasible to be implemented in a State
due to low demand or some specific reasons, they may be allowed to transfer
funds allocated for that component to another component of their choice after
taking due approval of SLSC.

viii)

RKVY Division, at the end of financial year, will reconcile the component wise
expenditure with the approved outlay and necessary adjustments will be done
while making interstate allocation in subsequent years.

ix)

The nodal department of the States shall ensure that PM-RKVY projects/activities
should not create duplication or overlapping of assistance/area coverage vis-à-vis
other scheme/programmes of State/Central Government.

x)

A presentation of all AAP & DPR components of PM- RKVY will be made by
the State Agriculture Secretary to Project Approval Committee under the
Chairmanship of Secretary, DA&FW. GoI will convey the approval of the
consolidated AAP along with specific comments for each of the projects to the
state.

xi)

SLSC/State will ensure that no project shall be undertaken for implementation if
GOI has not supported the project during AAP meeting.

xii)

Further, if any new project(s) is deemed important for implementation under PMRKVY by the State during the FY, the Nodal Department may send the DPR of
the project(s) to GoI with the consent of SLSC. After detailed examination and
deliberations of the projects by the respective divisions, GoI will convey the
17
*** PM-RKVY Guidelines ***

<!-- page 19 -->

approval of the AAP to the states. The projects have to be undertaken within the
approved allocation of the state.
xiii)

10.

States will be allowed to utilize fund available in PM- RKVY scheme for any
component as an interim measure to ensure that activities of the particular
component of the scheme is not affected for want of funds. However, the activity
for which the fund released under various components should be completed
without any exception by the States subsequently by replenishing the appropriate
amount in respective components.

Release of Funds:

PM-RKVY scheme funds will be released to the States/UTs subject to compliance of
conditions prescribed by Department of Expenditure, Govt. of India & fulfillment of the
following conditions:
 Submission of 100% Utilization Certificates (UCs) of the funds released up to the
previous financial year;
 Submission of physical and financial progress report in the specified format.

The format for submitting Utilization Certificate is given at Annexure III
If a State fails to avail their full allocation, the balance funds may be re-allocated to better
performing States.
The Nodal Agency/Nodal Department of the State/UT shall ensure that component-wise as
well as project-wise accounts are maintained by the Implementing Agencies and are subjected
to the normal process of statutory audit.
An inventory of the assets created under PM-RKVY projects should be carefully maintained
and assets that are no longer required should be transferred to the Nodal Department, for its
use and re-deployment wherever possible. Nodal Agency/Department of the States/UTs should
ensure that the Central Assistance released under the scheme is utilized in accordance with the
approved AAP.
All implementing agencies are required to maintain subsidiary accounts of the grants-in-aid
and get the same audited from a Chartered Accountant.
Grants in aid will be released as per provisions regarding release of funds contained in GFR
2017 and instruction issued in this regard by Government of India from time to time
18
*** PM-RKVY Guidelines ***

<!-- page 20 -->

11.

Pradhan Mantri Janjatiya Unnat Gram Abhiyan :

Ministry of Tribal Affairs has launched Pradhan Mantri Janjatiya Unnat Gram Abhiyan
(PMJUGA) with an aim to improve the socio-economic condition of the tribal communities by
adopting saturation coverage for tribal families in tribal-majority villages and Aspirational
Districts. The Mission will cover approximately 63000 villages viz. (i)Villages with population
of 500 or more and with at least 50% Scheduled Tribe population and (ii)Villages in
Aspirational Districts with 50 or more Scheduled Tribes. Dovetailing schemes and beneficiary
identification (FRA Patta Holders) is to be undertaken effectively while implementing schemes
so as to achieve the Mission objectives.
Department of Agriculture & Farmers Welfare, has been included as one of the priority sector
for the Mission. The financial assistance to these FRA patta holders would be provided from
Development Action Plan for Scheduled Tribes (DAPST) Funds. While implementing PMRKVY scheme, priority should be given to such villages identified for PMJUGA and inclusion
of FRA patta holders should be ensured while selecting beneficiaries. However, the
beneficiary share in respect of patta holders under FRA act will be 10% only in each of
the components of PM-RKVY

12.

Aspirational Districts and Vibrant Villages:

While implementing the PM-RKVY scheme, priority should be given to Aspirational Districts
and Vibrant Villages identified by the Government.

States should ensure that these

Aspirational Districts and Vibrant Villages, if falling in their States, should necessarily be
included in the State Annual Action Plan so that more beneficiaries falling in the Aspirational
Districts and Vibrant villages are covered under the Scheme

13.

Timelines:

As far as possible, the following timeline will be adhered to by the Centre and States.
Communication of allocation to States by GoI

By 30th November

AAP submission by the States with the approval of

By 31st December

SLSC
Presentation of AAP/DPR by States to PAC, DA&FW January- February
Communication of GoI approval to States

By 30th March

Issuance of Mother Sanction/ Release of funds

First week of April

19
*** PM-RKVY Guidelines ***

<!-- page 21 -->

14.

Implementation of Programme Components under PMRKVY

The restructured PM-RKVY scheme has following components:
A. DPR based component.
B. Annual Action Plan (AAP)component.
C. Start-up & Accelerated Fund component.

A. DPR Based Component:
This component will be implemented in a project-based mode. States/UTs will have the
flexibility with the option of proposing projects related to agriculture and allied sectors
(excluding Animal Husbandry and Fisheries) for creation of infrastructure, production
growth, innovative projects etc. States may also take up projects under the scheme in
Public- Private Partnership for Agriculture Value Chain Development (PPPAVCD) mode that

provide additional income to farmers. A revised framework for implementing projects
under PPPVCD framework has been issued separately by DA & FW.
A maximum of 30% of total outlay will be earmarked for Detailed Project Report (DPR)
component including Administrative charges and Startup component. In case of NER &
Himalayan states i.e. Uttarakhand, Himachal Pradesh & UTs, the ceiling will be
maximum 50 % of the total outlay.
Inter State Allocation of Funds:
The quantum of assistance (or fund allocation) to the States will be in accordance with the
parameters and respective weights as explained in Annexure-IV

Cost Norms:
DPR is a gap filling scheme wherein projects related to agriculture and other sectors for
creation of infrastructure and innovative projects that do not fit into the template of existing
schemes of DA&FW are to be proposed by the States.
Activities proposed under RKVY-DPR like creation of infrastructure and value addition linked
production are generally covered under various ongoing schemes/programmes of Central
Government viz. Deptt. of Agriculture and Farmers Welfare, Deptt. of Land Resources,
Ministry of Water Resources, Ministry of Food Processing Industries, Ministry of New &
Renewable Energy, Ministry of Rural Development etc.
20
*** PM-RKVY Guidelines ***

<!-- page 22 -->

 Technical requirements/standards and financial norms (cost norms and pattern of
assistance) etc. specified for these schemes will also be applicable for RKVY-DPR.
 In the absence of such criterion in respect of any component in Central Plan Scheme, norms
and conditions prescribed by respective State Governments for their schemes may be
applied.
 In cases where no Central / State Govt. norms are available, a certificate of reasonableness
of the proposed project will in variably be given by SLSC.
For infrastructure and assets projects, 100% assistance will be provided if these are to be
executed by public sector through PPPAVCD mode. In case of projects taken by Private
sector under PPPAVCD, the assistance will be 50% &25% for infrastructure projects and
production oriented projects respectively. States may refrain from undertaking
activities/components as illustrated in Annexure-VI under RKVY–DPR component.

Preparation of DPR:
DPR component of PM-RKVY will be implemented as a project-based scheme. Thus, DPRs
shall have to be prepared and submitted by the states in the format given at Annexure VII
incorporating all essential details i.e. feasibility studies, competencies of the implementing
agencies, anticipated benefits (outputs/outcomes) that will flow to the farmers/ State, definite
time-lines for implementation etc.
In case of large projects costing more than Rs. 25 crore, DPRs should be subjected to third
party ‘techno-financial evaluation’ and circulated well in advance to concerned Central
Ministries for obtaining comments/observations.
DPRs for all projects should certify that there would be no duplication of funding and/or taking
up similar activities as in other Plan schemes of Central/State Government. The projects under
DPR should be prepared for the following:
i Creation of Infrastructure and Assets: States can establish pre and post-harvest
infrastructure in agriculture and allied sectors under DPR component of RKVY. Projects
will preferably emanate from State Agriculture Plan (SAP) or State Agriculture
Infrastructure Development Programme (SAIDP) that States prepare for the Finance
21
*** PM-RKVY Guidelines ***

<!-- page 23 -->

Commission.
The Asset Building activity consists of creation of various assets like tissue culture labs,
cold storage facilities, infrastructure for sorting, grading, vermin compost units, labs for
production of bio control agents, soil testing labs, etc. The illustrative List of Projects that
can be funded under DPR component of RKVY (Infrastructure &Assets) is given at
Annexure VIII
While a number of infrastructure items are covered under Rural Infrastructure
Development Fund (RIDF) and Viability Gap Funding (VGF) of the Ministry of Finance,
DPR funds should supplement those sources and not replace them. In any case, quantum
of assistance under RKVY should not exceed assistance under VGF. Recurring
expenditure to the extent of human resources requirement on contractual basis and
chemical components to run the testing labs will be allowed under the ceiling of 2.5%
administrative expenditure

ii Production growth: Under this, states can take up innovative projects that take care from
production to marketing of any agriculture sector activities. An illustrative list of activities
which may be taken up under DPR component for production growth is given at Annexure
IX

22
*** PM-RKVY Guidelines ***

<!-- page 24 -->

B. Annual Action Plan (AAP) component:
AAP component will comprise of seven schemes i.e SH&F, PKVY, RAD, PDMC, SMAM
including CRM, Agro-forestry and CDP. A minimum of 70% will be allocated for Annual
Action Plan (AAP) component including Administration, Monitoring and Evaluation purposes.
In case of NER & Himalayan states i.e Uttarakhand, Himachal Pradesh & UTs, the ceiling will
be minimum of 50 % of the total outlay.
Detailed guidelines for implementation of these sub components are as follows.

B.1

Per Drop More Crop:

Per Drop More Crop (PDMC) focuses on enhancing water use efficiency at farm level through
Micro Irrigation viz. Drip and Sprinkler irrigation systems.

B.1.1 Salient Features:
i.

Per Drop More Crop (PDMC) is a Centrally Sponsored Scheme implemented by the
Department of Agriculture and Farmers Welfare (DA&FW) from the year 2015-16 to
promote micro irrigation in the Country to benefit the farmer community. As a part of
the restructuring/rationalization of the schemes of DA&FW, PDMC Scheme is being
implemented under Rashtriya Krishi Vikas Yojana (RKVY) from the year 2022-23.

ii.

District Irrigation Plans (DIP) is the cornerstone for planning and implementation of
PDMC which identifies gaps in irrigation chain after taking into consideration
currently available resources and resources that would be added from ongoing
schemes, both State and Central.

iii.

The Annual Action plans is to be drawn from District Irrigation Plans.

iv.

State irrigation plan focuses on cluster based approach and integrated development of
different components in the irrigation chain.

v.

The scheme is to be implemented through the mechanism of Direct Benefit Transfer
(DBT). Aadhaar details of the beneficiary are required to avail the benefit of the
programme. Aadhaar details need to be linked through a web based registration
process. States/UTs should ensure disbursement of subsidy in a time bound manner.

vi.

The scheme will be monitored through web-portal of PDMC. Physical and Financial
progress achieved during the preceding month is required to be up- loaded by states
23
*** PM-RKVY Guidelines ***

<!-- page 25 -->

on the web-portal of PDMC.
vii.

More focus be given on promotion of micro irrigation in rainfed areas and also for
water intensive/guzzling crops to minimize water requirement.

viii.

The pattern of assistance payable to the beneficiary under the micro irrigation scheme
will be 55% for small and marginal farmers and 45% for other farmers.

ix.

The subsidy payable to the beneficiary will be limited to an overall ceiling of 5 hectare
per beneficiary. Those beneficiaries, who have already availed subsidy benefits for his
/her farm, would be eligible for subsidy again for the same land only after the end of
projected life of the micro irrigation system which is 7 years.

x.

The subsidy payment will be limited to the unit costs specified in the Operational
Guidelines of the scheme. 25% higher amounts will be taken into calculation of
subsidy for the North Eastern, Himalayan States and UTs of JK & Ladakh and 15%
higher for States with low penetration of Micro Irrigation.

xi.

Only BIS marked systems/components can be supplied under the scheme.

xii.

The registration of manufacturers/companies under the scheme will be for a period of
5 years. The registration will be open round the year. The registration will, however,
be subject to satisfactory performance by the company. In case of violations, penalty
provisions have been specified in the guidelines. Repeated failures will lead to deregistration of the company with the approval of SLSC.

xiii.

The company will provide free service after sales to the beneficiary for a period of at
least three years from the date of installation of the system. If it fails to provide free
after sales service, action as appropriate similar to other consumer products may be
initiated.

xiv.

In case the company intends to supply imported components, it shall be eligible for
subsidy under the scheme subject to indigenization of manufacturing of the component
within the country in a period of two years.

xv.

Human resource development is an important component of the scheme and suitable
provisions have been made in the guidelines for creating awareness, organizing
training programs, Skill development and exposure visits etc.

24
*** PM-RKVY Guidelines ***

<!-- page 26 -->

B.1.2 Institutional Architecture
Per Drop More Crop will have the following institutional structure.
National Stewardship Council (NSC): National Stewardship Council(NSC)under the
Chairmanship of Secretary (DA&FW) with the following members will be constituted to
provide strategic direction for guidance and planning for effective implementation of the
scheme;
S. No.

Designation
1

Secretary, Department of Agriculture &
Farmers Welfare

Chairman

2

Additional Secretary & Financial Advisor

Member

3

Additional Secretary, DA&FW

Member

4

Representative
Resources

from

Ministry of

Water

Member

5

Representative
Development

from

Ministry

Rural

Member

6

Representative
from
Department
Agricultural Research & Education

of

Member

7

Representative from Department of Land
Resources

Member

8

Joint Secretary (INM)

Member

9

Joint Secretary (Crops)

Member

10

Joint Secretary (RKVY)

Member

11

Technical Expert of National Rainfed Area
Authority (NRAA)

Member

12

Director, Water Technology Center (WTC),
ICAR

Member

13

Horticulture Commissioner

Member

14

Joint Secretary (NRM & RFS)

Member Secretary

of

Representative from three State Implementing Departments/Agencies; One representative from
Precision Farming Development Centres (PFDC); One Micro Irrigation System
Manufacturer/Industry; President/Representative of the Irrigation Association of India(IAI)
and representative from two FPOs/farmers’ cooperatives may be invited as special invitees.
Inter Departmental Working Group (IDWG): At the State level, under the Chairmanship
25
*** PM-RKVY Guidelines ***

<!-- page 27 -->

of Agriculture Production Commissioner/ Development Commissioner with Secretaries of line
departments as members will be constituted to coordinate the planning and implementation of
the scheme. States may take the advice/input of MI manufacturers by inviting representative
from manufacturers/Micro Irrigation Industries /Irrigation Association of India (IAI) as special
invitee in such Committees.
District Level Implementation Committee (DLIC): Under the Chairmanship of
Collector/District Magistrate/CEO of Zila Parishad/ PD DRDA, Joint Director/Deputy Director
of line departments in the district and progressive farmers, representative of MI industry, and
leading NGO as members to oversee implementation of the scheme and inter-departmental
coordination

B.1.3 District and State Irrigation Plans (DIPs & SIPs):
District Irrigation Plans (DIPs) are the cornerstone for planning and implementation of
different schemes related to irrigation which will identify gaps in irrigation infrastructure after
taking into consideration the District Agriculture Plans (DAPs) vis-à-vis irrigation
infrastructure currently available and resources that would be added from ongoing schemes,
both State and Central.
DIPs present holistic irrigation development perspective of the district outlining medium to
long term development plans integrating three components viz. water sources, distribution
network and water use applications.
The annual action plans for Per Drop More Crop will be drawn from DIPs and implemented
in conjunction with the water sources created under convergence with other State/Central
schemes.

Strategies:i.

Priority should be given for promoting micro irrigation technologies in rainfed areas.
More focus should be given to water scarce, water stressed and critical ground water
blocks/districts to conserve water and get extended coverage in terms of area and time
period for life saving irrigation.

ii.

It is desirable to make potential use of the available water for sustained growth in
agriculture sector. Preference should be given to adopt Micro Irrigation technology in
water guzzling crops like sugarcane, cotton, banana etc. and the state implementing
agencies should take suitable steps like publicity campaigns, policy provisions &
26
*** PM-RKVY Guidelines ***

<!-- page 28 -->

sharing responsibilities with the Micro Irrigation industry so that adoption of
technology is initiated in such crops. Industry related to the specific crops like sugar
factories should be actively involved in promotion of micro irrigation to their farmers
through incentivisation and technical supervision. Apart from horticulture and water
guzzling crops, cereals and pulses may also be brought under the ambit of Micro
irrigation.
iii.

In all the new irrigation commands where hydraulic heads are available, drip irrigation
systems need to be encouraged as it can be operated without additional energy support.

iv.

Facilities of micro irrigation is under utilized if it is not used for fertigation. States
should encourage the use of liquid fertilizers using micro irrigation systems.
Availability of liquid fertilisers, awareness among farmers on the benefits of fertigation
need to be given desired attention for promoting fertigation.

v.

Efforts may be made for integration of micro irrigation with solar pumping units. A
solar water pump has a mini power house at its heart and consists of a calibrated and
matching solar array of modules – tuned with the equivalent power of pump for that
particular application. The solar water pumping system is capable of running all types
of electrical water pumps with applications varying from irrigation to household
demands. Irrigation pumps such as submersible, surface or deep well can also be
coupled with drip irrigation systems to enhance the returns from this configuration. A
2000 Watt Peak (WP) solar water pump is capable of drawing and pumping
approximately 80,000 litres of water per day from a source that is up to 10 meters deep.
This is sufficient to irrigate about 1 ha of land with regular crops.

vi.

The

available

water

sources

or

the

new

sources

those

are being

created need to be used in best possible manner to fulfil the vision of “Har Khet Ko
Pani” through efficient water conservation (Jal Sanchaya) and water management (Jal
Sinchan) practices. It is, in this context, more vital to link most of the water sources
with micro irrigation to get extended coverage for a longer duration.
vii.

PDMC focuses on micro irrigation for enhancing water use efficiency. States may take
up

sources

creation

activities

as

Other

Interventions (OI) under the scheme

and must be linked with Micro Irrigation to make potential use of the available funds
for higher water use efficiency. These activities should be based on actual requirement
and as per the needs of the farmer who adopts the Micro irrigation system.
viii.

The amount for OI activities must be restricted to 20% of the total allocation for
States/UTs and 40% for North East States, Himalayan States & UTs of Jammu Kashmir
27
*** PM-RKVY Guidelines ***

<!-- page 29 -->

and Ladakh.
ix.

Assistance for installation of micro irrigation system is limited to five hectares per
beneficiary. The land holding of a beneficiary to be covered under drip/sprinkler system
could be located in one contiguous area or at different locations, but the financial
assistance will be limited to the overall ceiling of five ha.

x.

Those beneficiaries, who have already availed subsidy benefits for his /her farm, can
not avail the assistance for the next seven years. A beneficiary if availed the benefit of
subsidy for micro irrigation for a particular farm would be eligible for subsidy again
for the same land only after the end of projected life of the micro irrigation system
which is seven years. However, the beneficiary may be allowed to avail effective
differential subsidy in case he intends to install Drip Irrigation System on the same
plot/field from the existing Sprinkler Irrigation System at least after three years to
promote crop diversification irrespective of seven years subsidy cycle.

xi.

The unit cost/BoQs of the MI systems given in the Guidelines are indicative. The
beneficiary will be allowed to opt to make his choice for items/components etc. In case
any deviation from the BoQ, the differential cost shall be borne by the beneficiary
subject to ceiling of unit cost.

xii.

Sometimes beneficiaries may not be able to contribute the requisite amount to adopt
micro irrigation technologies. States/UTs may involve financial institutions like
NBFC/Bank/NABARD to fill the upfront credit gap faced by the farmers for microirrigation adoption. States may facilitate credit facility to farmers (such as enabling
subsidy component as State guarantee).

xiii.

In view of the continuous modernization of agriculture resulting into evolving ways to
improve productivity and sustainability, crops spacings keeps on changing. Financial
assistance for installation of Micro irrigation systems will be based the indicative cost
of MI systems for different spacings and plot sizes provided in the guidelines. In case
of crops with plant spacing other than those mentioned in the Guidelines, the amount
of assistance could be calculated on pro rata/average basis of the nearest plant area.

xiv.

Beneficiaries/Institutions that have opted for contract farming or taken land on lease
are also eligible for obtaining financial assistance under the scheme. However, to
become eligible, the beneficiary/institution shall have to produce lease agreement for a
minimum period of 7 years from the date of approval of application by the MI
implementing agency.

xv.

ICAR, PFDCs, CIPET, ATMA etc. may be involved in planning, implementation,
28
*** PM-RKVY Guidelines ***

<!-- page 30 -->

demonstration, training and evaluation under the scheme. The implementing agency at
the district level will ensure convergence of activities under the programme with the
activities of various departments on water management to get the desired output.
xvi.

Raw material price of polymers &other costs varies a lot because of fluctuation in
national/international prices. Accordingly, periodic review of pricing may be carried
out by the DA&FW, GoI.

xvii.

States must include all Aspirational Districts identified by NITI Aayog in their Annual
Action Plan (AAP)for coverage of Micro Irrigation under the Scheme in these Districts.
Further, priority may be given to Namami Gange Districts/Gram Panchayats (GPs)
along the stretch of river Ganga basin to be included in AAP for Micro Irrigation
coverage.

xviii.

Climate Change is known to have adverse impact on agriculture. Irrigation has been an
effective tool in addressing climatic aberrations like drought, heat wave causing that is
responsible for enormous loss to agriculture. States/UTs must ensure coverage of MI
in dark zones and climatically vulnerable areas. The MI coverage should also be given
priority to the areas under NICRA program of ICAR- CRIDA to promote climate
resilient technologies.

xix.

Micro Irrigation is an important component of various Centrally Sponsored Schemes,
such as, National Mission of Edible Oils – Oilseeds (NMEO-OS), MIDH, NFSM,
NMEO-OP. States/UTs should ensure that installation of Micro Irrigations systems
under these schemes be dovetailed with PDMC. The Annual Action Plan must be
prepared accordingly and progress of Micro Irrigation activity to be reported under the
PDMC scheme.

xx.

States may encourage Automation in the Micro Irrigation Systems for ease of operation
with minimal or no manual intervention thereby achieving greater efficient use of Micro
Irrigation Systems by the beneficiaries. The Automation unit may be linked with solar
energy wherever possible at the farm. It is desirable that States should target5% of
Micro Irrigation coverage under the scheme with Automation. The cost of automation
may vary with the type of Automation adopted by the beneficiary. For adoption of
Automation in the Micro Irrigation system under the scheme, the financial assistance
to the beneficiary will be restricted on the existing rate of subsidy to the indicative cost
of Rs. 40000/ha.

xxi.

Preference for installation of micro irrigation will be given to farmers adopting crop
diversification to enhance the production and their income substantially.
29
*** PM-RKVY Guidelines ***

<!-- page 31 -->

xxii.

The Guidelines for implementation of Pradhan Mantri Kisan Urja Suraksha evem
Utthan Mahabhiyan (PM KUSUM) Scheme, Ministry of New and Renewable Energy
gives preference to farmers using Micro irrigation systems. Accordingly, PDMC should
be converged with PM-KUSUM for promoting use of solar energy with MI systems.
States/UTs to ensure that all solar pump beneficiaries under PM-KUSUM adopt micro
irrigation system.

xxiii.

The Atal Bhujal Yojana (ABY) focuses on sustainable management of ground water
through participatory approach. The PDMC Scheme may be converged with ABY to
achieve the objectives of the schemes.

xxiv.

The Guidelines for New Generation Watershed Development Projects (WDC-PMKSY
2.0) envisage convergence of watershed projects with PDMC. Accordingly, priority
may be given to areas under WDC-PMKSY 2.0 to integrate activities, particularly,
creation of water sources with that of micro irrigation. Similarly, water sources created
under MGNREGS may be integrated with micro irrigation for their potential use.

xxv.

Department of Water Resources, River Development & GR is implementing Command
Area Development & Water Management (CADWM) program. CADWM envisages
the modernization of Irrigation Command Area i.e. providing Pressurized Piped
Irrigation Command (PPIC) for use of Surface Water combined with other sources of
water which provides network of established water source to farm gate for farmer to
adopt micro irrigation in the farm to improve the Water use Efficiency at farm level.
The States/UTs must ensure that the source/infrastructure created under the scheme
shall be utilized for Micro Irrigation in coordination with WRD/CAD agencies.
CADWM program shall be dovetailed with PDMC and it shall be ensured that Water
user Societies covered under modernized CADWM program should be necessarily part
of PDMC for adoption of MI systems. Such convergence shall make it possible to
aggregate large areas under micro irrigation which enable better implementation, cost
effective, maintenance & services and better market linkage of produce.

xxvi.

States/UTs should facilitate the beneficiary of PDMC scheme to avail Soil Health Card
and Kisan Credit Card under the respective programs.

B.1.4 Cluster Approach:
i.

States/UTs should prioritize implementation of MI through Cluster approach to have
effective integration of sources, connectivity, distribution and application. The size of
cluster may be 50 ha. & above in mainland states and 20 ha. in NE & hilly states. Water
30
*** PM-RKVY Guidelines ***

<!-- page 32 -->

User Associations/Groups, Farmer Producer Organizations, Cooperative societies,
Self-Help Groups, Growers’ Associations etc. shall be encouraged to adopt Micro
Irrigation in a cluster. In such cases the beneficiary will be entitled to avail financial
assistance through their respective organizations / bodies. The total financial assistance
available to the individual beneficiary in the group would be 55% under the scheme.
The land holding of the beneficiary should be located in one contiguous area. Such
farmers groups/organizations may be allowed to avail an administrative/institutional
charges @ 3% of the cost of the Cluster.
ii.

The States/UTs may encourage FPOs to take up micro irrigation at community level.
States/UTs may ensure at least 5% micro irrigation target is implemented through
FPOs.

iii.

States/UTs

may

enable

such

farmers’

groups

to

access

capital

from

NBFC/Bank/NABARD so that such cluster implementation could be taken up through
banks with Joint Liability Group (JLG).

B.1.5 Public Private Partnership (PPP-MI) approach:
States/UTs may take up projects with PPP mode of implementation. Public Private Partnership
(PPP) approach in Project mode may be an important step for increasing MI coverage for the
benefit of farming community. State Governments/UTs may take up projects in PPP approach
involving farmer groups, private partners and concerned Departments in the State. Such
projects should focus on improving water use efficiency, productivity, income of farmers,
access to market and positive environment outcomes.
Rationale:
Judicious use of water is important to expand the agricultural area under irrigation. Micro
irrigation promotes adopting optimum cropping pattern and efficient water application, that
utilizes available water resources in an efficient manner. Saving of water will not only help in
extending irrigation coverage but also in enhancing productivity and improving farmland
ecosystem. The water use efficiency in irrigated areas as well as non-irrigated areas is presently
at low level. In future there could be huge stress on water availability for agriculture as a result
of negative impact of climate change. Very few farmers in irrigated commands are adopting
micro irrigation system. Micro-irrigation system is cost intensive and technical with
maintenance requirements. Capital investment in agriculture is still largely in sufficient. Micro
31
*** PM-RKVY Guidelines ***

<!-- page 33 -->

irrigation penetration to small and marginal farmers especially in most rural areas is still
lagging. There is also a need to ensure equitable access of water availability to tail end farmers.
Better market linkage opportunities of farm produce would help in enhancing farmers income.
In this regard, collaborative efforts between the Government and Private partners in promotion
of micro irrigation shall open new opportunities for the benefit of the farming community.
Strategy of PPP- Micro Irrigation:
i.

Public Private Partnership for integrated Project on Micro Irrigation can be executed
through an agreement between State Government and private partners. The arrangement
would involve a whole-lifecycle with a predetermined period where the private partners
can extend support for both implementation (installation, construction etc.) and operation
of the MI systems.

ii.

State /UT Governments may prepare projects involving Corporate/Private Partners/Other
Entities, farmers groups and concerned Institutions/ Departments in the State. Under the
project, allowed activities of PDMC scheme may be taken up through the scheme
following the operational Guidelines. The other activities of the project would be
converged from other schemes/investments from entities of the project. The proposals
shall clearly indicate the interventions being made by the entities, the scale of the project,
approx. number of farmers involved and the expected outcomes in terms of farmers
benefits.

iii.

Various Agri retail business companies may be involved for facilitating market linkages
of farm produce in the project area.

iv.

The aim is to set up PPP based projects wherein entities (eg. FPO/ Farmers Groups,
Private Companies, Concerned Departments of the State etc.) may invest in creation of
Common Infrastructure i.e. Water sources, pressurized pipe networks till farm end gate
from canal /reservoir along with sumps/storages, lifting/pumping facility and the on-farm
Micro irrigation system. Convergence with various related Government schemes may be
made for effective utilization of available resources in the project area.
Corporate/Industries shall be encouraged to participate in the project through their
Corporate Social Responsibilities (CSR) outreached.

v.

The PDMC scheme would be dovetailed with such PPP projects.

vi.

Project document will have clearly marked out convergence of other Centrally Sponsored
32
*** PM-RKVY Guidelines ***

<!-- page 34 -->

Schemes of Ministries as well as State Schemes.
vii.

Transparency of complementary investments of non-Government entities and visibility
of public-domain infrastructure created shall be ensured.

viii.

IT based solutions, use of advanced technologies of Micro Irrigation such as solar energy,
Automation, use of AI, IoT etc. should be given priority for effective implementation &
monitoring. Technologies that are complimentary to micro irrigation in reducing water
losses or evaporation, improve soil water holding capacity etc. should be promoted along
with MI.

ix.

PPP projects should explore carbon market potential which will deliver additional income
to farmers.

Procedure for Implementation:
i.

The project on PPP should include information on geography & climate, potential of
agriculture development, available irrigation infrastructure, potential for micro irrigation,
strategy for development and plan of action proposed to be taken. The document should
focus on adoption of aggregation/cluster approach for coverage of micro irrigation and
linking with available infrastructure, or to be created. Willingness of the farmers to be a
part of the proposed project should also be included.

ii.

The project should reflect the whole-lifecycle with a predetermined period. The project
shall clearly indicate the interventions/responsibilities/role of the entities, the scale of the
project, approx. number of farmers involved and the expected outcomes in terms of
farmers benefits and the way forward.

iii.

Growers/farmers/farmers group under the project would be entitled for assistance under
other schemes of DA&FW/other Departments. The project implementing agency or the
private partner should collect the data and required documentations of all farmers in the
project and facilitate to access the assistance available under the PDMC scheme.

iv.

The State Nodal Department/Agency of PDMC of the State may call for proposals from
entities interested in carrying out the project and short list them based on applicant’s
experience. State can set up a committee to select and finalize the projects.

v.

Proposals shall be submitted to State Governments. The State Government will examine
the project proposal from the viewpoint of suitability to need of the area. If found suitable,
the proposal should be included in the Annual Action Plan of the State to be submit by
33
*** PM-RKVY Guidelines ***

<!-- page 35 -->

the SLSC to DA&FW for approval.
Operational Aspects:
i.

The Implementing Agency need to widely publicize the importance of the scheme at
block and village levels through its existing networks to create awareness among the
farmers.

Organize

District

Level

Seminars/Workshops

involving

MI

Manufactures/Companies. Further, the State Agriculture Extension Units should organize
camps and Trainings in collaboration with MI Manufactures/Companies to explain
system components and their functions, type of micro irrigation for crop, post installation
services and frequency of maintenance etc. Trainings/camps to target the family, not
individual beneficiary. The MI manufacturer / company may provide irrigation schedule
to farmers, make efforts for linkage to agronomic practices.
ii.

Dedicated Implementing Agency/Special Purpose Vehicle (SPV): States/UTs with good
micro irrigation coverage have shown that dedicated Implementing Agency/Special
Purpose Vehicle (SPV) can accelerate the scheme success with overall efficiency.
Therefore, States/UTs should setup a dedicated Implementing Agency/Special Purpose
Vehicle (SPV) at the state level with dedicated manpower to ensure that the needed
attention is given in the implementation of the scheme.

iii.

Dedicated portal for implementation: States having dedicated portal for implementation
have performed better with high level of transparency. Hence, all States/UTs should
develop their own portal dedicated for the implementation of the scheme. Government of
India will also develop a reference portal for use of States. States using its own portals
should make data available to the Government of India portal through APIs.

iv.

All level of implementation including receipt of applications, work order, work
completion, verification, payment release, monitoring, feedback etc. shall be captured by
the State portal developed for the purpose. Also, the Portal should have online workflow,
mapping all levels of implementation to ensure effective monitoring.

v.

The States/UTs shall adopt bio-metric/facial authentication enabled Aadhar based
registration of applicant developed by DA&FW. The details of the applicant, such as,
Name, Gender, Date of Birth, Identifier Name (Father/Spouse Name), etc should be
captured as per the Aadhare KYC. The assistance should be transferred to the Aadhar
seeded and DBT enabled active bank account of the beneficiary through DBT. In case it
is given in kind through Companies, the intimation should be conveyed as SMS to the
beneficiary on his mobile phone with details of assistance. The States/UTs should ensure
34
*** PM-RKVY Guidelines ***

<!-- page 36 -->

that disbursement of subsidy is made a time bound activity.
vi.

All land based interventions should be Geo Tagged/Geo Fenced. Krishi Mapper/Mobile
App developed by DA&FW shall be used for Geo Tagging/Geo Fencing of farmers’ field.
The data captured by the App will automatically link with the State MIS portal through
API.

vii.

The State Implementing Agency will engage Third Party Inspection Agencies (TPIAs)
for conducting inspection/physical verification of the installed Micro Irrigation Systems
at every farmer field. The installed site will be verified by these agencies for material
supplied and also conduct Trial Run at the site. TPIAs should capture and upload
photographs/videos/report of the MI installation at site which should be made available
in the State portal. States/UTs should ensure timely installation and third party
verification of MI installation. The Implementing Agencies must complete the timely
inspection/physical inspection of the MI systems to avoid delay. Ideally, the physical
inspection should be completed within 60 days of installation. Due penalty should be
imposed on supplier if any delay in installation is observed. States/UTs must also ensure
timely release of subsidy/top-up to the beneficiaries.

viii.

All scheme related information including progress and achievements should be captured
by State portal which may be integrated with the National portal through API to ensure
seamless flow of information.

ix.

The beneficiary shall be free to choose MI equipment from any MI manufacturer out of
the approved list of registered manufacturers and also to choose the type of MI system to
be installed as per the system design compatible with his/her cropping pattern.

x.

The State Implementing Agency/ SPV should conduct inspections at the factory site of
the Supplier(s) through Third Party technical agencies such as Central Institute of Plastics
Engineering and Technology (CIPET), ICAR Institutes, State Agriculture Universities
etc. However, if any State/UT has already conducted such inspection of a supplier, the
inspection report (of the supplier) may be considered by other States/UTs also.

xi.

All the Micro Irrigation Systems will be QR Coded. The QR code of the system will be
linked to Unique application no./Sanction ID of the farmer on installation of the system.

xii.

The MI manufacturer/supplier should necessarily generate e-invoice for micro irrigation
system supplied with details of all its components and the e-invoice shall be captured by
the State Portal.

xiii.

A module/hand book may be devised by the Implementing Agency/SPV for the benefit
of the farmers with basket of services which includes Farmer Education & Training
35
*** PM-RKVY Guidelines ***

<!-- page 37 -->

(Agronomy services), maintenance & operating Micro Irrigation Systems etc.
xiv.

The MI supplier Agency should provide necessary services to farmers after installation
trail run of the system for at least three years free of cost. The List of service
centers/offices/offices of authorized distributors with full address/telephone numbers/email should be widely published (Inspection/repair/replacement).

xv.

A toll free customer care number will be provided by the State implementing agency for
providing information related to Micro Irrigation Systems. Also grievance redressal and
feedback system of the beneficiaries should be provided.

xvi.

To ensure strict adherence to quality standards in the use of MIS Components, the
Implementing Agency of the State will ensure the BIS standards of supplied equipment.

xvii.

States to develop modules on several aspects; fertigation schedule, acid treatment, issue
of salts/salinity in water, linkage to agronomic practices, selection of the right system etc.
Further, States to conduct trainings and best practices demonstrations for the beneficiaries
as well as officials/staff for better learning.

B.1.6 Drip Irrigation System for states where it has been well accepted by farmers and
good infrastructure is available
i.

The scheme is well accepted by the farmers and substantial coverage has been made under
micro irrigation system compared to other parts of the country with required
infrastructure and service facilities in the States namely Andhra Pradesh, Delhi, Gujarat,
Haryana, Karnataka, Kerala, Madhya Pradesh, Maharashtra, Rajasthan, Tamil Nadu and
Telangana. These states are considered to be category “A” States with comparatively
better penetration of micro irrigation technologies.

ii.

Drip Irrigation technology involves irrigating root zone through emitters fitted on a lateral
tube as well as inserted within the tubing as emitting pipe. The use of different emitters
will depend upon specific requirements, which may vary from crop to crop.

iii.

Fertigation is important for getting maximum benefits out of the micro irrigation
technology. Therefore, it is mandatory to use a fertigation device by the farmers such as
venturi injector or fertilizer tank on which the subsidy is available.

iv.

Water requirement, age of plant, plant to plant spacing, soil type, water quality and
availability etc are some of the factors which decide the choice of emitting system. The
indicative cost of drip irrigation systems (assuming peak water requirement with source
of water at the corner of plot), for different lateral spacing and plot sizes has been
36
*** PM-RKVY Guidelines ***

<!-- page 38 -->

provided in the guidelines. An indicative list of system components required for installing
a drip irrigation system in the areas ranging from 0.2 ha to 5 ha is at Annexure-XIII(a
to g), on the basis of which subsidy will be calculated as per Table 1:

Table 1: Indicative cost of Drip Irrigation System for calculation of subsidy
(Cost in Rs.)
Spacing
(mxm)

0.2
ha

0.4 ha

1 ha

2 ha

3 ha

4 ha

5 ha

12x12

10526

18009

24586

39098

60704

75521

96166

10x10

10854

18652

26181

42226

65487

82025

104292

9x9

11091

19114

27304

44469

68853

86606

110024

8x8

11330

19711

28777

47314

73272

92615

117529

6x6

12400

21693

34687

57987

93688

113618

142566

5x5

13144

23486

39378

67199

97110

123409

165815

4x4

14602

24326

41534

72799

113560

148684

176964

3x3

15792

26190

47751

82654

127306

160103

200455

2.5x2.5

19516

35393

68234

124216

189724

266274

325233

2x2

23932

41303

83085

161263

234280

325469

399494

1.5x1.5

28106

46995

97245

185324

276767

382246

470306

2.5x0.6

20201

35000

71733

131824

201464

279770

343433

1.8x0.6

24569

42992

91560

173298

260868

355323

442484

1.5x0.6

28003

50116

109531

207860

313909

425189

530905

1.2x0.6 (or
lower spacing)

31436

57241

127501

242422

366950

495055

619326

v.

In case of crops with plant spacing other than those mentioned in above table, the amount
of assistance could be calculated on pro rata/average basis of the nearest plant area (Row
to row x plant to plant spacing in metre). The example is given below.
a. If a subsidy has to be calculated for 1.5 x 1.5mspacing i.e. between 1.0 ha (₹97245)
and 2.0 ha (₹185324), the cost would be: ₹97245 + [(₹185324-₹97245) /(2.0 ha–
1.0ha) x (1.5ha–1.0ha)].
b. If a subsidy has to be calculated for 1.0 ha and 3.5 x 3.5m spacing i.e. between
4.0x4.0m (₹41534) and 3.0x3.0m (₹47751) the cost would be:₹41534+[(₹47751₹41534)/(4.0x4.0–3.0x3.0)X(4.0x4.0–3.5x3.5)].

vi.

The unit cost of Drip Irrigation system varies with respect to plant spacing and location
of the water source. The farmer can avail other interventions as per Annexure XIII (an) as per specific requirement of the field in which micro- irrigation system is to be
37
*** PM-RKVY Guidelines ***

<!-- page 39 -->

installed.
vii.

Assistance under the scheme is available for all types of drip irrigation systems such as
on-line & in-line drip irrigation systems.

viii.

As small farm holdings may not have individual source of water, it would be preferable
to encourage a group of farmers to avail the benefits of drip irrigation through a common
water source.

ix.

A beneficiary having farms located at different places and having different water source
may avail the subsidy as per the guidelines. However, a beneficiary cannot split area at
one location into small pockets of the same crop for claiming assistance under the
scheme. If a beneficiary has more than one crop with different crop spacing being grown
separately in his/her land holding, assistance will be available for installing the drip
irrigation system as per the individual crop spacing, the combined area of which will not
exceed 5 ha per beneficiary.

x.

In case of inter-cropping, assistance will be available for the prescribed plant spacing/
area, subject to the condition that the assistance will be provided only for one crop as per
the farmers’ choice.

B.1.7 Drip Irrigation System in states with low penetration
Based on the prevailing coverage and acceptance by farmers, states namely Bihar,
Chhattisgarh, Jharkhand, Odisha, Uttar Pradesh, West Bengal, Goa, Punjab and Union
Territories have been identified as states with low penetration of micro irrigation technology.
These states are considered as category “B” in terms of implementation of micro irrigation.
The cost of drip system is likely to be higher in these states due to various factors such as lesser
presence of manufacturing companies in these states leading to higher cost of transportation,
the companies will have to make considerable efforts in making the farmers ready for adoption
of technology, and higher cost involved in providing after sales service in these states etc. Thus,
15% higher cost has been taken in consideration while working out the unit cost of drip system
in the table below for these states for the purpose of subsidy calculation as per indicative list
of system components given at Annexure XIII(a - n)

Table 2: Indicative cost of Drip Irrigation System for calculation of subsidy in the states
where penetration level is low (Cost in Rs.)

38
*** PM-RKVY Guidelines ***

<!-- page 40 -->

Spacing
(mxm)

0.2
ha

0.4 ha

1 ha

2 ha

3 ha

4 ha

5 ha

12x12

12105

20710

28274

44962

69810

86849

110591

10x10

12482

21450

30109

48560

75310

94329

119935

9x9

12755

21981

31399

51139

79181

99597

126527

8x8

13030

22667

33094

54412

84263

106507

135159

6x6

14260

24947

39890

66685

107741

130661

163951

5x5

15115

27009

45285

77279

111676

141921

190687

4x4

16792

27975

47765

83719

130594

170987

203508

3x3

18161

30119

54913

95052

146402

184119

230523

2.5x2.5

22444

40702

78469

142848

218183

306215

374018

2x2

27522

47498

95547

185453

269421

374289

459418

1.5x1.5

32322

54044

111832

213122

318282

439583

540852

2.5x0.6

23231

40250

82493

151597

231684

321735

394948

1.8x0.6

28255

49441

105295

199293

299998

408621

508857

1.5x0.6

32203

57634

125960

239039

360995

488967

610541

1.2x0.6 (or
lower spacing)

36151

65827

146626

278786

421992

569313

712224

i.

In case of crops with plant spacing other than those mentioned in above table, the
amount of assistance could be calculated on pro rata/average basis of the nearest plant
area (Row to row x plant to plant spacing in metres) similar to example given in 9.5.

ii.

The assistance will be available for all types of drip irrigation systems; on- line and inline drip irrigation systems.

iii.

In case of inter-cropping, assistance will be available for the prescribed plant
spacing/area, subject to the condition that the assistance will be provided only for one
crop as per the farmers’ choice.

B.1.8 Drip Irrigation System for North Eastern and Himalayan States
The coverage of MI system in North Eastern and hilly region is much low due to poor
infrastructure and difficult terrain. The states namely Assam, Arunachal Pradesh, Manipur,
Meghalaya, Mizoram, Nagaland, Tripura, Sikkim, Jammu & Kashmir, Himachal Pradesh and
Uttarakhand are considered under category “C”. In the Hilly states, following points need to
be kept in mind while designing a drip irrigation system keeping in view the sloppy and
terraced land:
i

It is difficult to lay PVC main and sub-main lines below the ground surface and therefore
HDPE pipes are required in place of PVC.
39
*** PM-RKVY Guidelines ***

<!-- page 41 -->

ii The undulating and vertical slopes would lead to comparatively larger length of pipes.
iii To maintain uniform pressure and to irrigate upper most terrace of land, control valve
should be provided at sub-main/main lines at 4m vertical drop. Accordingly, the number
of flush valves will also increase.
The cost of drip system is likely to be higher in North Eastern & Himalayan states because of
the terrain, higher transport cost, lesser presence of manufacturing companies etc. Therefore,
unit cost of micro irrigation systems is taken 25% higher in these states for the purpose of
subsidy calculations and is given in table below (including 25%) for the indicative list of system
components is at Annexure XIII (a - n)
Table 3: Unit cost for NE&H states
(Cost in Rs.)
Spacing
(mxm)

0.2
ha

0.4 ha

1 ha

2 ha

3 ha

4 ha

5 ha

12x12

13157

22511

30733

48872

75881

94402

120207

10x10

13567

23315

32727

52783

81859

102531

130365

9x9

13864

23893

34130

55586

86066

108258

137530

8x8

14163

24638

35971

59143

91590

115768

146912

6x6

15500

27116

43358

72484

117110

142023

178207

5x5

16430

29357

49223

83999

121387

154262

207269

4x4

18252

30408

51918

90999

141950

185855

221205

3x3

19740

32738

59688

103318

159132

200129

250569

2.5x2.5

24395

44242

85292

155270

237156

332842

406542

2x2

29915

51628

103856

201579

292849

406836

499367

1.5x1.5

35132

58744

121556

231655

345959

477807

587883

2.5x0.6

25251

43750

89666

164780

251830

349712

429292

1.8x0.6

30712

53740

114451

216622

326085

444153

553106

1.5x0.6

35003

62645

136914

259825

392386

531486

663631

1.2x0.6 (or
lower spacing)

39295

71551

159377

303028

458687

618819

774157

In case of crops with plant spacing other than those mentioned in above table, the amount of
assistance could be calculated on pro rata/average basis of the nearest plant area (Row to row
x plant to plant spacing in metres) similar to example given in 9.5.
B.1.9 Sprinkler Irrigation
i.

In sprinkler irrigation, water is discharged under pressure in the air through a set of
nozzles attached to a network of High Density Poly Ethylene (HDPE) pipes,
40
*** PM-RKVY Guidelines ***

<!-- page 42 -->

simulating the rainfall. Sprinkler irrigation systems are suitable for irrigating crops
where the plant density is very high. It is widely used for cereals; pulses; seeds; spices;
and field crops.
ii.

Financial assistance would be restricted as per the cost of High Density Poly Ethylene
(HDPE) pipes used in sprinkler irrigation systems, even though, the beneficiaries may
use aluminum pipes as well. The sprinkler irrigation systems may be portable, mini
sprinklers, micro sprinklers, semi-permanent sprinklers and large volume sprinkler
systems (Rain-guns). Additional 25% and 15% on the indicated unit cost may be
considered for calculation of subsidy for Hilly states including NE region and low
penetrating State respectively.

B.1.10 Portable Sprinkler Irrigation System
i.

In portable sprinkler irrigation systems the HDPE pipes are used for mains and submains which can be shifted from one place to another as per the irrigation schedule
with respect to design layout. These can be used in both, plains as well as in
undulating terrains.

ii.

The indicative number of components required for various area range of sprinkler
irrigation system is annexed. Financial assistance will be provided based on the
number of pipes procured by the beneficiary for the area under reference. An
indicative list of system components required for installing portable sprinkler
irrigation system is at Annexure-XIV on the basis of which subsidy will be
calculated. The indicative cost for various area ranges and pipe sizes is given below
in Table 4below:

Table 4: Indicative Cost of Portable Sprinkler Irrigation System
(Cost in Rs.)
Area

Pipe Dia.(mm)
63

75

90

Upto0.4ha

13211

NA

NA

1ha

21588

24194

0

2ha

31167

34657

0

3ha

NA

NA

46779

4ha

NA

NA

58995

5ha

NA

NA

66789

Note: i) In case of area other than those mentioned in above table, the amount of assistance could be calculated
on pro rata/average basis of the nearest area.

41
*** PM-RKVY Guidelines ***

<!-- page 43 -->

ii) In case of low penetrating states and hilly states including NE region, 15% and 25% higher indicative
cost respectively may be taken for calculation of subsidy.

B.1.11 Micro Sprinklers
i.

Micro Sprinklers are mostly used for irrigating leafy vegetables, nurseries, hardening
of seedlings and a few vegetables. Apart from providing irrigation, the micro
sprinkler also helps in changing the micro climatic conditions near the plant. Micro
sprinklers are low radius sprinklers. The selection of micro sprinklers depends on the
type of crop, soil, types etc.

ii.

An indicative list of system components required for installing a micro sprinkler
system is at Annexure-XV. The indicative cost of Micro Sprinkler irrigation system
at different lateral spacing & area is given in Table5:

Table 5: Indicative Cost of Micro Sprinkler Irrigation System
(Cost in Rs.)
Spacing(mxm)
Area(ha)

5x5

3x3

0.4

32713

38263

1

65102

74259

2

114426

133821

3

164937

191078

4

222721

263852

5

281557

321462

Note: i) In case of area other than those mentioned in above table, the amount of assistance could be calculated
on pro rata/average basis of the nearest area.
ii) In case of low penetrating states and hilly states including NE region, 15% and 25% higher indicative
cost respectively may be taken for calculation of subsidy.

B.1.12 Mini Sprinklers
They are commonly used for close growing crops like groundnut, potato, onion, ginger, short
statured fodder crops, etc. Mini sprinklers are also suitable for frost protection. An indicative
list of system components required for installing a mini sprinkler irrigation system is enclosed
at Annexure XVI. The indicative cost of Mini Sprinkler irrigation system at different lateral
spacing and area is given below in Table 6 below:

42
*** PM-RKVY Guidelines ***

<!-- page 44 -->

Table 6: Indicative Cost of Mini Sprinkler Irrigation System
(Cost in Rs.)
Spacing (mxm)
5x5

Area(ha)

3x3
45694
94134
176766
268422
345497
423236

0.4
1
2
3
4
5

47528
103873
187929
290935
380031
469890

Note: i) In case of area other than those mentioned in above table, the amount of assistance could be calculated
on pro rata/average basis of the nearest area.
ii) In case of low penetrating states and hilly states including NE region, 15% and 25% higher indicative
cost respectively may be taken for calculation of subsidy.

B.1.13 Semi-Permanent Sprinkler Irrigation System
a) In Semi-Permanent Sprinkler System, the piping network for main line and lateral lines
are permanently buried with risers fitted on the lateral lines. The sprinkler nozzles are
fitted on each riser pipe and can be easily shifted from one place to another to irrigate
the required area in shifts as per the irrigation schedule or the crop water requirement.
b) The indicative number of components required for various area ranges of semipermanent sprinkler irrigation systems is enclosed at Annexure XVII
c) The estimated unit cost for various area ranges is given below in Table 7 below:

Table 7: Indicative Cost of Semi-Permanent Sprinkler System
Area(Ha)

Cost(in Rs)
0.4

24919

1

40440

2

77113

3

104083

4

132997

5

161345

Note: i) In case of area other than those mentioned in above table, the amount of assistance could be calculated
on pro rata/average basis of the nearest area.
ii) In case of low penetrating states and hilly states including NE region, 15% and 25% higher indicative
cost respectively may be taken for calculation of subsidy.

43
*** PM-RKVY Guidelines ***

<!-- page 45 -->

B.1.14 Large Volume Sprinkler Irrigation System (Raingun)
1) Large volume sprinkler irrigation systems (Rain guns) are used where larger areas are
to be covered with one or two sprinklers. These sprinklers have a discharge ranging
from 10,000 lph to 32,000 lph and radius of throw from24 m to 36 m. These systems
require high pressure and high discharge pipes & pumps to operate them. These are
preferred for irrigating crops spread over large areas in short time. The indicative list
of components is enclosed at Annexure XVIII.
2) Pivot Irrigation system is used for a much larger area & are not suitable for the
beneficiaries targeted under PDMC. However, if some beneficiary is interested, may
avail financial assistance as per unit cost norms of rain-gun system. The estimated unit
cost for various area is given in Table 9:
Table 9: Indicative Cost of Large Volume Sprinkler (Rain-gun)
(Cost in Rs.)
Area (Ha)

Pipe Dia.(mm)
1
2
3
4
5

63
31684

75
38127

90
NA

NA
NA

48370
NA

NA
62767

NA
NA

NA
NA

72751
79894

Note: i) In case of area other than those mentioned in above table, the amount of assistance could be calculated
on pro rata/average basis of the nearest area.
ii) In case of low penetrating states and hilly states including NE region, 15% and 25% higher indicative
cost respectively may be taken for calculation of subsidy.

B.1.15 Optional Components
1) The use of optional components depends upon the agro climatic conditions of the place &
requirement of the beneficiary. The provision is kept to provide the said component on the
then existing rate of subsidy to the beneficiary; if required & provided. These components
are:
i.

Fertilizer tank - to increase fertilizer use efficiency, fertilizer tanks have been
included in the list of equipment eligible for financial assistance. The beneficiary
can opt for either fertilizer tank or venturi system or automated dosing system
equipment and financial assistance will be provided for either of those components.
44
*** PM-RKVY Guidelines ***

<!-- page 46 -->

ii.

Sand filters/media filters- to remove organic matter and inorganic contaminants
from water sources like rivers, tanks and open wells. Sand/media filters have been
included the financial assistance.

iii.

Hydro Cyclone Filters/Sand Separators - to remove particles of the size of 75
microns (200 mesh) which have a higher density than water, hydro cyclone
filters/sand separators have been introduced as an optional item for which financial
assistance will be provided. These equipments require minimum maintenance and
are useful for cleaning river water, canal water and tube well water which may
contain sand.

iv.

Drip Line Winder- for wrapping the drip laterals has been included for financial
assistance.

2) The detailed guideline for water quality & filters selection is provided at Annexure XX
respectively. The indicative cost of optional components such as sand filters, hydro cyclone
filters and fertilizer tanks is annexed at Annexure XXI
3) States may take up sources creation -Other Interventions (OI) activities under the scheme
and must be linked with Micro Irrigation to make potential use of the available funds for
higher water use efficiency. These activities should be based on actual requirement and as
per the needs of the farmer who adopts the Micro irrigation system. The details of eligible
OI activities for financial assistance and cost Norms is provided at Annexure XXII
4) Optional items if any other than above may be allowed. However, cost of these items will
be borne by the beneficiary.
B.1.16 Key Administrative requirements
(i) The unit cost norms indicated in the guidelines for various technologies/ specifications
are for the purpose of calculating subsidy ceiling amount only i.e. it can be less but not
more than the indicated amount if the cost is more. The actual cost of the system,
however, would vary as per design of the field and other agro climatic conditions. It is
to be ensured that all compulsory system components are provided to the farmer. The
BOQ given in the table is indicative & may vary case to case.
(ii) An individual eligible to receive the benefits under the scheme is required to furnish
proof of possession of Aadhaar Number or undergo Aadhaar registration. If one
individual is eligible but do not possess the Aadhaar number she/he can get enrolled
45
*** PM-RKVY Guidelines ***

<!-- page 47 -->

visiting the Aadhaar enrolment centre. State Government/Union Territories
Administration is required to offer Aadhaar registration facilities to the beneficiaries
who are not enrolled and in case no Aadhaar enrolment centre is available in certain
blocks/ taluka/ tehshil, the nodal department through its implementing agency is
required to provide enrolment facilities at convenient locations in coordination with the
Registrars of UIDAI. Till the time Aadhaar is assigned to individual, she/he can avail
the benefit of the scheme on production of the following documents Aadhaar enrolment
ID slip/ Copy of request for Aadhaar enrolment and Voter Identity Card/ PAN/
Passport/

Ration

Card

/Employee

Govt.

ID/Passbook

of

bank

or

post

office/MGNREGS card/ Kissan photo passbook/ Driving License/ any other document
as specified by State/UT.
(iii)Aadhaar details need to be linked through a web based registration process. The
assistance if given in cash, need to be transferred to the bank account of the beneficiary
and in case it is given in terms of kind through Companies, the intimation be conveyed
as SMS to the beneficiary mobile phone with details of assistance. It should be ensured
that no eligible beneficiary suffers for want of Aadhaar and it would be the
responsibility of implementing agency to ensure that Aadhaar enrolment of such
beneficiaries is carried out on priority. The notification issued in this respect is given at
Annexure-XXIII
(iv) It must be ensured that at least 50% of the allocation is utilised for small, marginal
farmers of which, at-least 30% should be women beneficiaries/farmers. Further, 16.5%
and 8.5% of the total allocation or in proportion of SC/ST population in the district
should be utilised for Special Component Plan (SCP) & Tribal Sub Plan (TSP)
respectively.
(v) Transparency in beneficiary selection – It should be ensured that the Implementing
Agency follows uniform procedures and full transparency in selection of beneficiaries
and release of assistance to the beneficiaries in an efficient manner. Enlisting of the
beneficiaries should be open round the year facilitating submission of applications by
beneficiaries any time for availing the benefit of financial assistance under the scheme.
The state implementing agency need to adopt a web based IT model for implementation
of the scheme. Implementing Agency should ensure that selection of beneficiaries is
done as per details included in the Annual Action Plan for the component for the year
which has been derived from the DIP.
46
*** PM-RKVY Guidelines ***

<!-- page 48 -->

(vi) All level of implementation shall be in the State portal platform developed for the
purpose. The Portal should have online workflow, mapping all levels of implementation
to ensure effective monitoring.
a) Pre-installation activities
 The Implementing Agency need to widely publicize the scheme at the block and
village levels through its existing networks.
 Appoint a nodal officer who is responsible for coordination of the scheme
implementation with the Districts.
 Disseminate the list of suppliers and rate list approved by SLSC to the farmers.
 Organize at least one District Level Seminar/Workshop with the participation
of Industry.
 Compile the application submitted by the farmers and scrutinize, codify and
forward the same to the company’s/Manufacturer’s local office indicated by the
farmer.
 The beneficiary share may be deposited with manufacturer/their representative
or the state nodal agency as per the practices to be adopted by the state with the
approval of SLSC.
 The beneficiary shall be free to purchase MI equipment from any MI
manufacture out of the approved list of registered manufacturers.
b) The manufacturer/company will do/provide the following:
 Assess the crop water requirement as per the crop for which the system is to be
provided.
 Design the system as per the crop water requirement.
 Prepare an estimate of cost and submit it to Implementing agency duly
indicating the time frame in which the system will be installed in the farmer’s
field once work order is issued.
 The Implementing agency will approve the estimate, issue work order and
ensure installation.
 Efforts will be made by the MIS Supplier to ensure coverage of MI in the water
47
*** PM-RKVY Guidelines ***

<!-- page 49 -->

scarce, stressed area, critical ground water districts/blocks and in potential &
untapped area of the State.
c) The Company will install the system and commission it to the satisfaction of the
beneficiary duly ensuring that:
 Quality components having BIS marking are installed in the farmer’s field, and
while making payment the implementing agency will ensure the BIS standard
of supplied equipment, whichever the BIS standard exists.
 The date of manufacturing should be printed on the components as per
prevailing statutory norms.
 Implementing agency will ensure that MI system installed in each field bears
separate QR code.
 The installed system should match the water requirement of the crop.
 Necessary orientation and training is given to the beneficiary on the system
maintenance & irrigating the crop with drip/sprinkler irrigation.
 Proper warranty and a user’s manual for running & maintenance of the system
- whether drip or sprinkler or both- as the case may be is provided to the
beneficiary.
 A certificate towards successful installation/commissioning of the system is
obtained from the beneficiary.
d) Disbursement of assistance post installation.
 Financial assistance to the beneficiary will be limited to the prescribed subsidy
as per unit cost as prescribed under the guidelines or the actual Bill of
Quantities (BoQ) whichever is less. On physical verification of satisfactory
installation of the system & a certificate to that effect from the beneficiary,
Implementing Agency will release payment to the beneficiary electronically in
his/ her bank account.
 The Implementing Agency shall ensure proper invoice with statutory
commercial details i.e. Serial number, GSTIN number etc. printed on it and
countersigned by the authorized representative of the MI System manufacturer
is issued to the beneficiary & subsidy released on the same.
48
*** PM-RKVY Guidelines ***

<!-- page 50 -->

 The manufacturer will install the system as per the agreement with the state
nodal agency and the procedure for payment as decided by the SLSC may be
adopted. Electronic mode of payment is required to be followed for most of the
transactions for implementation of the programme. In case the amount is
placed with manufacturers/ companies/financial institutions on behalf of
beneficiary, the consent of beneficiary is required and the transaction details
need to be conveyed to him over SMS immediately and subsequently in writing
too.
Micro irrigation system may be insured for the period of its expected life and the premium may
be borne by beneficiary/state government based on the decisions to be taken by States.
B.1.17 Registration of manufacturing companies
i

Registration of micro irrigation system manufacturers shall be done with the approval
of SLSC for a period of five years. The registration will be open round the year and a
company can apply at any time. Only those manufacturing companies, which have all
the facilities to ensure supply of quality product as per BIS standards and can provide
prompt after sales services will be registered. The registration will be subject to the
satisfactory performance of the company as assessed by the state implementing agency
and repeated failures will lead to the de-registration by SLSC.

ii The companies willing to participate in the scheme should be manufacturing below
mentioned components and own BIS in their name:
iii In the case of drip irrigation, company must manufacture at least laterals and emitting
devices as specified conforming to BIS standards. For online drip irrigation systems the
company should be manufacturing lateral tubing as well as drippers as per BIS and for
inline drip irrigation systems, the company should be a manufacturer of inline emitting
pipe.
iv In the case of portable sprinkler irrigation system the company should manufacture
coupled HDPE pipes or sprinklers and should possess respective BIS.
v In the case of other sprinkler irrigation systems viz. Mini, Micro, Semi- permanent
sprinkler irrigation systems the company should manufacture either of HDPE/PVC/PE
pipes/nozzles and should possess respective BIS.
vi In the case of large volume sprinkler irrigation system (rain gun sprinklers) the
49
*** PM-RKVY Guidelines ***

<!-- page 51 -->

company should manufacture HDPE pipes or nozzle and should possess respective BIS.
vii The company must provide guarantee of quality assurance of other components which
are not manufactured by them in various technologies covered under the scheme.
viii The company must provide free after sales service to the farmers for three years from
the date of installation of system. Moreover, they should set up service centres for
providing technological support at the grass root level.
ix The registration under the scheme should be open throughout the year to enable
maximum flexibility and open participation.
x The company will supply only BIS marked material. The list of relevant BIS
components is given at Annexure XXIV.
xi In case the company intends to supply imported components, it shall be eligible for
subsidy under the scheme subjected to indigenization of manufacturing of the
component within a period of two years. In case of imported equipment, the technoeconomic analysis report will be provided by NCPAH after proper examination and
verification and submit report to DA&FW.
xii The material should be supplied directly by the manufacturer or their authorized
distributors/dealers. In all cases, the manufacturer should authenticate the invoices.
Such manufacturers shall furnish a Bank Guarantee of quantum of which will be
prescribed by SLSC valid for the period of registration.
xiii Each company may have its own pricing system. However, the company would be
required to submit the same to the Registering Authority/SLSC at the beginning of the
year and as and when the prices are revised by the company.
B.1.18 After sales services & campaigns
i

Operation and Maintenance of the system requires adequate training of beneficiaries
for system operation etc. The manufacturers should have required network for
providing training and after sales service in their areas of operation. The manufacturers
should provide detailed operational and maintenance manual in the local vernacular
language at the time of installation of the system. The beneficiaries should be advised
to follow the instructions provided by the manufacturers for the operation and
maintenance of drip/sprinkler irrigation systems.
50
*** PM-RKVY Guidelines ***

<!-- page 52 -->

ii Service centres and / or offices of drip / sprinkler system manufacturers / authorised
distributors should have facilities to provide technical guidance on system maintenance
schedules, supply spare parts and ensure satisfactory performance of the system during
the warranty period. The manufacturer must also operate a toll free customer care
number where beneficiaries can register their complaints. List of service
centres/offices/offices of authorised distributors with full address/telephone numbers/email should be widely published.
iii After sales service should be provided by the manufacturer/authorized distributor, free
of cost for at least a period of three years. The company shall repair or replace any
components/instruments of the MI system free of cost within warranty period, if they
are found to have manufacturing defects or workmanship defects.
iv Due to normal wear and tear, if any parts/components require repairing/replacement,
the company shall supply the same and recover the cost from the beneficiary after the
free period is over. The company or its authorised representatives shall provide
acid/chlorine treatment to drip system once during the first year of operation of the
system. However, the company should provide training to the beneficiary on this aspect
to enable him to do further treatment by himself.
v If any system manufacturer fails to provide such service, the same should be brought
to the notice of district level committee and SLSC. The manufacturer would be
responsible for any dispute arising from the supply of their product/component directly
or through their authorised distributors/dealers. The Implementing Agency/ SLSC of
each State shall evolve a process and modus operandi to redress the disputes, if any. In
cases where product quality related complaints from beneficiaries are received due
sampling process mentioned in the guidelines shall be followed.
vi The SLSC may take measures against erring companies or their authorized dealers, as
well as their own staff after due hearing in order to safeguard the interests of
farmers/beneficiaries and to ensure effective utilization of public funds. However,
before initiating any action, principle of natural justice should be followed.
vii There could be extension campaigns by the MI companies at a centralized location
having area nodal officials, farmers & other related officials. Various aspects of system
maintenance, acid treatment, fertigation etc. could be covered. The technical support
group NCPAH would maintain a data appropriately to monitor these activities.
51
*** PM-RKVY Guidelines ***

<!-- page 53 -->

viii The State agencies ensure the campaigns by companies should cover all beneficiaries
under warranty period & could be as under:
More than 5000 ha area coverage in the state 6 campaigns 1000-5000 ha area
coverage in the state 4 campaigns Less than 1000 ha area coverage in the state 2
campaigns
ix The States should develop a grievance redresser system for farmers with a unique toll
free number to assist the farmers for their queries and after sale service. If required,
Micro Irrigation installing Company may also be asked to provide a Toll Free number.
B.1.19 Violations & Penalties
i

The Central & State Governments, micro irrigation suppliers/manufacturers and other
stake holders are putting in a lot of efforts for effective operations of micro irrigation
systems. Any wrong operations could lead to system failure & financial loss to the
beneficiary apart from loss of faith in the technology. It is, therefore, important to have
well defined measures / terms for violation of norms by the stake-holders. Any violation
to the quality, maintenance and other parameters need be viewed seriously. The list of
violations mentioned below is not exhaustive and any other deviations, which affect the
implementation of the scheme adversely may be considered by the DMIC/SLC as
deemed fit for smooth functioning of the same.

ii A due process, where show cause is issued and adequate time is allowed for response,
shall be followed and the MI companies as well as the beneficiary shall be adequately
heard and natural justice provided.
iii In case of violations in respect of failure in quality control &quality assurance and to
provide maintenance & after sales service, following penalties shall be imposed:
a) First time in a year, a warning letter may be issued to the manufacturer instructing
to rectify the short coming immediately.
b) Second time in same year, a warning letter may be issued to the manufacturer
instructing to rectify the shortcoming immediately with a penalty of 10% of
invoice value.
c) Third time in same year, a penalty of 25% of invoice value may be charged.
d) Fourth time in same year, a show cause notice may be issued to the company and
the case may be refer to SLSC for de-listing the company for a period of one year
52
*** PM-RKVY Guidelines ***

<!-- page 54 -->

or more as decided by SLSC.
iv The violations with regard to submission of bills without installation/partial installation,
wrong invoicing, variations in component specifications, submission of wrong
documents with reference to pump/system discharge, improper installation, quoting
higher price than approved, deviations from prescribed material specifications etc. may
be dealt with by the SLSC suitably apart from initiating suitable action under the
relevant sections of Indian penal code and other relevant/ appropriate statutory
enactments.
v In case of sale of the MI system to other farmers before expiry of average life of the
system, for which subsidy has been claimed by the beneficiary, legal proceedings
against the beneficiary as per applicable law may be initiated and the beneficiary may
be blacklisted from availing any government assistance in future.
B.1.20 Quality Control
i

Crucial aspect of supply of micro irrigation systems is the quality of hardware which is
delivered to the farmer. It needs to be ensured that quality components having BIS marking
(wherever applicable) are installed in the beneficiary field. Poor quality has an adverse
impact on performance of the system which may affect yield of the crop, quantity of water
applied, quantity of fertilizer delivered to the plant etc. It may also increase energy
consumption. In fact, sub-standard system will not only adversely impact performance,
but could also reduce the durability and the life of the components and/or system.

ii The SLSC shall form joint inspection teams for field inspection and frequent surveillance
by inspection teams will be a regular feature under the Scheme. They will draw random
samples periodically from the field, within a period of three years from the date of
installation of the system. At the time of inspection, the system should be fully functional.
The report should be submitted to the competent authority under SLSC for further action.
iii While one surveillance visit per operative year shall be kept as the general norm, more or
less inspections may be planned depending on the performance or specific guidelines
issued by SLSC.
iv Samples for testing should be collected jointly by the joint inspection team, state nodal
official and the company representatives in triplicate and properly labelled, sealed and
signed. The samples are collected for all major system components, especially pipes &
53
*** PM-RKVY Guidelines ***

<!-- page 55 -->

tubing. One set of samples should be sent to CIPET/BIS or any other approved product
testing laboratory for testing as the SLSC may deem fit, another set is to be preserved in
the custody of nodal officer and the third one is to be with the manufacturer. After
collection of samples at random, they should be coded as per BIS guidelines for the
purpose of security and further reference.
v

Collection of samples with batch number is mandatory. The samples may be collected
from the beneficiaries’ fields as well as the supply chain of the manufacturer after the
product has been dispatched from the manufacturing unit.

vi The quantity of material required for conducting the test is as detailed below:
Sl. No.

Test

Test samples required

Laterals as per IS : 12786 & Emitting Pipes as per IS : 13488
1
Identification & composition analysis
2
Thickness
3
Pressure Test
4
Dimensions
HDPE Pipes IS: 17425:2020
1
Identification & composition analysis

15 meters for laterals. 50 meters for
emitting pipe.

2
Thickness
3
Pressure Test
4
Dimensions
UPVC Pipes IS: 4985
1
Identification & composition analysis

1 mts

2
Thickness
3
Pressure Test
4
Dimensions
Emitters / drippers as per IS : 13487
1
Identification & composition analysis

1 mts

50 Nos
2

Flow Rate

vii The expenditure towards the testing charges shall be met from the administrative charges
under the scheme.
viii The state nodal officer will do proper scrutiny of the test report provided by the testing
laboratory and draw conclusion from the findings regarding conformity or otherwise of
the samples under the test. After scrutiny, the details of test report and results of
conformity/non-conformity shall be placed before SLSC for consideration. In case of nonconformity, SLSC may take action against the company/its authorised dealers as per
penalty clause mentioned in the scheme guidelines. The SLSC shall follow principle of
natural justice and the company as well as the beneficiary shall be heard before taking a
54
*** PM-RKVY Guidelines ***

<!-- page 56 -->

final action in the matter.
B.1.21
i

Human Resource Development and Media

Human resource development is an important component of the scheme. Under the
programme training of farmers, entrepreneurs, field level workers, officers, micro
irrigation technician and farm pond lining technician and trainers’ training may be taken
up.

ii The financial provisions for the same would be as under:
a) Training of stake holders
Rs. 1000/day per farmer including transport
i) Within the State
ii)Outside the State
Project based as per actual
b) Exposure visit of stake holders
Project based as per actual
i) Outside the State
Rs. 4.00 lakh/participants
ii)Outside India

100% of the cost.
100% of the cost.
100% of the cost.
Project Based 100% of
air/rail travel.
Course fee cost to be
funded under Mission
Management

c) Study tour of technical staff/ field functionaries
Rs. 300/day per participant plus TA/DA as admissible 100% of the cost.
i) Within the State
ii) Study tour to Rs. 800/day per participant plus TA/DA as admissible
progressive States/units
100% of the cost.
(group of minimum 5
participants)
Rs. 4.00 lakh/participants
100% of air/rail travel and
iii)Outside India
course fee cost to be funded
under Mission
Management

iii For organization of a workshop/conference or participation in an international event the
financial provision is given below. However, prior approval of DA &FW will be required
for participation in international events.
International level event

Rs. 7.50 lakh per event.

National level event
State level event
District level event

Rs. 5.00 lakh per event.
Rs. 3.00 lakh per event.
Rs. 2.00 lakh per event.

100% of the cost perevent of 4 days, on
pro rata basis.
100% of the cost perevent of two days.
100% of the cost perevent of two days.
100% of the cost perevent of two days.

iv Area wise/District wise Awareness/Publicity creation - awareness creation and publicity
of the micro irrigation technology will be undertaken through print and electronic media
and other methods. The publicity campaigns at block/ district/state level need be
undertaken by the state nodal agencies.
v

The expenses for above Human Resource Development activities and awareness
programmes etc. will be met from the administrative expenses earmarked under the
55
*** PM-RKVY Guidelines ***

<!-- page 57 -->

scheme.
B.1.22 Pattern of Assistance: The total financial assistance available to the beneficiary under
the micro irrigation scheme from both Central and State Governments would be 55% for small
& marginal farmers & 45% for other farmers. The unit cost would be limited to the Indicative
costs mentioned in the guidelines for various technologies and areas as given at Annexure
Nos. XIII (a - n). For the purpose of calculating subsidy the unit cost shall include the
applicable GST.

56
*** PM-RKVY Guidelines ***

<!-- page 58 -->

B.2

SMAM

Agricultural machines take an important role to increase productivity with timely and precise
fieldwork. To promote the usage of farm mechanization and increase the ratio of farm power
to cultivable unit area the scheme will be implemented with the following strategies.
B.2.1 Strategy:
To achieve the objectives of SMAM, the following strategies will be adopted:
 Provide financial assistance to farmers for procurement of farm machinery and
implements on individual ownership basis
 Establish Custom Hiring Centres of location and crop specific farm machinery and
equipments.
 Promote appropriate mechanization technologies for crop production, processing,
value addition and crops bi-product management by way of establishing Village Level
Farm Machinery Banks in identified villages
 Promoting Agricultural Mechanization in North Eastern Region by providing
appropriate agricultural mechanization technologies
 Promoting awareness on farm mechanization among stakeholders through
demonstration, capacity building activities and differentiated Information, Education
and Communication strategies;
 Conducting performance testing for various farm machines and equipments at the four
Farm Machinery Training and Testing Institutes (FMTTIs) and authorized testing
Centres.
B.2.2 Annual Action Plan Components:
The States will submit the Annual Action Plans towards the following components of SMAM.
The funds sharing pattern between Centre and States/UTs will be 60:40 for the normal States,
90:10 for North Eastern and Himalayan States and 100:0 for Union Territories.
S.
Component
No.
1 Financial
assistance to
farmers
for
procurement
of
farm
machinery

Implementing
Financial
Agencies
Assistance
State
(i) Financial
Governments/
assistance @
UTs
50% of the
cost
of
machine for
small
and
57

Eligible
Beneficiaries
Farmers

*** PM-RKVY Guidelines ***

Broad Criteria for
Implementation
(i) Beneficiaries
will be identified
by
the
State/district
nodal agencies in

<!-- page 59 -->

marginal
farmers,
farmers of the
Scheduled
Caste
and
Scheduled
Tribe
category,
women
farmers and
farmers of the
North Eastern
States
and
Himalayan
Regions.

and
equipments on
individual
ownership
basis

a
transparent
manner.
(ii) The areas of
having
lower
level
of
mechanization
may be focused
to
increase
availability
of
appropriate
region and crop
specific
machines.

(ii) Financial
assistance @
40% of the
cost
of
machine for
all
other
farmers
(iii) The machinewise
maximum
permissible
assistance is
indicated in
AnnexureXXV
2

Establishment State
of
Custom Governments/
UTs
Hiring
Centres
(CHCs)

(i) Financial
assistance @
40% of the
project cost for
the
projects
costing up to
Rs. 250 lakhs
(ii) The maximum
permissible
assistance per
machine under
the project will
be
the
maximum
permissible
assistance
indicated
against 40% in
AnnexureXXV
(iii) Financial
assistance to
the agriculture

Rural
(i)
Entrepreneurs
(Rural youth
and farmer as
an
entrepreneur),
Cooperative
Societies of
Farmers,
DAY-NRLM
Self
Help
Groups
(SHGs),
Registered
Farmers
Societies,
Farmer
Producer
Organizations
(FPOs) and
Panchayats

58
*** PM-RKVY Guidelines ***

Custom Hiring
Centres
of
location
and
crop specific
farm machinery
and
equipments,
Post-Harvest
Technology
and
Value
addition
machinery and
precision
farming
technologies
including Kisan
Drones will be
established in
the
districts
identified for
implementation
in the State
AAP.

<!-- page 60 -->

graduate
for
establishment
of Kisan Drone
CHCs will be
@ 50% of the
basic cost of
agricultural
drone and its
attachments or
Rs. 5.00 lakhs,
whichever is
less.
(iv) The CHCs will
be established
under
the
model
of
Credit Linked
Back Ended
Capital
Subsidy as per
the
broad
guidelines
indicated
in
AnnexureXXVI

59
*** PM-RKVY Guidelines ***

(ii) The districts in
State AAP will
include villages
having
low
farm
power
availability and
large
area
under small and
marginal
holdings.
(iii) Any business
model
including the
PPP
models
may be adopted
for expanding
the reach of
mechanization
through CHCs.
(iv) It
will
be
necessary
to
maintain,
upgrade
the
CHCs
from
time to time
(v) From
within
the allocations
made by the
States towards
CHCs/Hi-Tech
Hubs,
an
allocation
of
10% of the
funds shall be
earmarked
towards SHGs
under
DAYNRLM through
State
Rural
Livelihood
Mission
(SRLM) and
through
Agriculture
Department of
the respective
States.
(vi) For
Kisan
Drone CHCs,
the beneficiary
should
have
passed his tenth
examination or
its equivalent
from
a

<!-- page 61 -->

3

State
Establishing
Village Level Governments
Farm
Machinery
Banks (FMBs)

recognized
Board
and
should have a
trained drone
pilot
for
operation
of
drone.
(i) Financial
Cooperative
(i) The
Farm
assistance @ Societies of
Machinery
80% of the Farmers,
Banks may be
project cost for Registered
established in
the
projects Farmer
the
Villages
costing up to Societies,
having
low
Rs.
30.00 Self
Help
level
of
lakhs/project.
Groups, FPOs
mechanization
(ii) The
and
and preferably
beneficiaries
Panchayats
in the
most
may take up
vulnerable
the
projects
rainfed districts
costing more
identified for
than Rs. 30
priority
lakhs. In such
treatment
cases,
the
indicated in the
maximum
Report,
permissible
“Prioritization
financial
of Districts for
assistance will
Development
be restricted to
Planning
in
Rs.
24
India
–
A
lakhs/project.
Composite
(iii) The maximum
Index
based
permissible
Approach”.
financial
The
villages
assistance on
under
individual
Aspirational
machines
Districts should
under the farm
also be given
machinery
preference.
projects may
(ii) From
within
be arrived by
the allocations
doubling the
made by the
maximum
States towards
permissible
FMBs,
an
subsidy
of
allocation
of
40%
as
10% of the
indicated
in
funds may be
earmarked
Annexuretowards SHGs
XXV
(iv) The
FMBs
through State
with
the
Rural
project
cost
Livelihood
above Rs. 10
Mission
lakhs will be
(SRLM) and
established
through
under
the
Agriculture
60

*** PM-RKVY Guidelines ***

<!-- page 62 -->

model
of
Credit Linked
Back Ended
Capital
Subsidy as per
the
broad
guidelines
indicated
in
AnnexureXXVI

4

State
Promotion of NER
Governments.
Agricultural
Mechanization
in
North
Eastern
Region

(i) For purchase
of machines
by
the
farmers on
individual
ownership
basis,
financial
61

*** PM-RKVY Guidelines ***

Department of
the respective
States.
(iii) Farm
Machinery
Banks
may
provide crop
specific
mechanization
services to the
farmers in the
region
including
processing,
value addition
and crop byproduct
management.
(iv) Women Groups
may
be
encouraged to
take
up
processing,
value addition
activities
through
the
FMBs.
(v) The
Women
Self
Help
Gropus
identified under
Namo Drone
Didi Scheme
should be given
preference for
purchase
of
Multi-utility
machines,
which may also
be used for
drone transport.
(vi) Not more than
one tractor may
be
allowed
under
the
projects.
Farmers

(i)

Beneficiaries
will
be
identified by
the
State/district
nodal agencies

<!-- page 63 -->

assistant @
100% of cost
of machine
costing up to
Rs.
1.25
lakhs will be
provided.
(ii) For
establishment
of
Farm
Machinery
Banks
(FMBs),
financial
assistance @
95% of the
project cost
for
the
projects
costing up to
Rs.
30.00
lakhs.
(iii) The
beneficiaries
may take up
the projects
costing more
than Rs. 30
lakhs.
However, the
maximum
permissible
financial
assistance
will
be
restricted to
Rs.
28.50
lakhs/project.
(iv) The
maximum
permissible
assistance per
machine
under
the
Farm
Machinery
Bank project
will
be
calculated by
multiplying
the maximum
permissible
assistance
indicated
against 50%
62

in a transparent
manner.

Cooperative
As indicated against
Societies of 4.3
Farmers,
Registered
Farmer
Societies,
Self
Help
Groups
(SHGs),
FPOs
and
Panchayats

*** PM-RKVY Guidelines ***

<!-- page 64 -->

5

State
Financial
Assistance for Governments/
UTs
Mechanized
operations

in AnnexureXXV by 2
(Two)
and
then
again
multiplying
the same by
0.95.
(v) The FMBs
with
the
project cost
above Rs. 10
lakhs will be
established
under
the
model
of
Credit Linked
Back Ended
Capital
Subsidy as
per the broad
guidelines
indicated in
AnnexureXXVI
(i) The financial Small
and
assistance to Marginal
the small and Farmers
marginal
farmers
of
low
mechanized
regions will
be provided
@ 2000/ha
for hiring of
Drones from
the Custom
Hiring
Centres,
Women
SHGs.
(ii) This
assistance
will
be
available up
to 2 ha land in
a year. The
amount
of
assistance
will
be
proportionate
to the actual
land owned
by
the
farmers.
63

*** PM-RKVY Guidelines ***

(i) The States shall
sign necessary
MoUs
with
CHCs
and
Women SHGs
for providing
services
of
drones to the
small
and
marginal
farmers.
(ii) The area of
kisan
drone
application
should
be
georeferenced
and monitored
online
and
financial
assistance
should flow to
the
farmers
through DBT

<!-- page 65 -->

2.0 Central Components (100% funded by Central Government):
S.
No.
1

Component
Demonstration
of
newly
developed
agricultural/
horticultural/
crop
residue
management
machines postharvest
technologies
and
Kisan
Drones
at
farmers’ fields.

Implementing
Financial Assistance
Broad Criteria for
Agencies
Implementation
FMTTIs,
State (i) Depending on the (i) All
these
identified
requirements, the
demonstrations
institutions, ICAR
implementing
should
be
institutions, ATMA
agencies (except the
georeferenced
and
institutions, KVKs
FPOs)
will
be
properly monitored.
under ICAR/SAUs,
provided grants @ (ii) All
the
National
100% of the cost for
demonstrations will
Innovation
purchase
of
be uploaded on the
Foundation (NIF),
machinery
and
Krishi MApper
PSUs of GOI,
equipments
(iii) The
machines
FPOs.
including
Kisan
procured
for
Drones
for
demonstration may
conducting
their
also be used for
demonstrations on
Custom Hiring to the
the farmers’ fields.
farmers at reasonable
rent.
(ii) The FPOs will be
(iv) The funds provided as
provided grants @
contingent
75% of the cost of
expenditure may be
machines including
used towards hiring of
the kisan Drones.
machines along with
(iii) The Implementing
implements/
selfagencies which do
propelled
not want to purchase
machines/Kisan
the machines for
Drones, expenditure
demonstration, will
towards hands on
hire the machines to
training
and
be
demonstrated
miscellaneous
from the Custom
expenditure such as
Hiring Centres. In
expenditure towards
such
proposals,
transport,
labour,
financial assistance
publicity and printing
@ Rs. 6000 per
of technical literature
hectare to meet
etc. However, these
contingency
funds should not be
expenditure will be
used for recruitment
provided.
of staff, TA/DA of
staff, purchase of
(iv) The rate of grant to
computer,
video
meet the contingent
camera, vehicle etc.
expenditure will be
or
for
any
Rs. 3000/- per
construction.
hectare in the case
implementing
of the implementing (v) The
agencies
will engage
agencies that will be
Krishi
Sakhis
for
provided grants for
collecting
and
purchase
of
uploading
of
equipments
and
data/pictures
of
machines
for
demonstration
and
demonstration.
geo-plotting/polygon
64
*** PM-RKVY Guidelines ***

<!-- page 66 -->

(v) Expenditure
over
and above specified
limits will be borne
by
respective
institutions.

2

Skilling in field
of
farm
mechanization,
post-harvest
management
and
Kisan
Drones

FMTTIs, State (i)
identified
institutions, ICAR
institutions,
ATMA
institutions, KVKs
under ICAR/SAUs

mapping
of
demonstrations
on
Krishi MApper. A
resource fee of Rs.
100 per hectare will
be paid to the Krishi
Sakhis from within
the contingent funds
of demonstration. The
Krishi Sakhis will be
digitally skilled to use
the Krishi MApper
App.
(vi) The Institutions under
ICAR, SAUs and
other
Central
institutions
may
submit
their
proposals
directly.
However,
the
institutions
under
State Governments
will have to route
their
proposals
through
State
Department
of
Agriculture/
Agricultural
Engineering.

Assistance will be (i)
available as per the
Common Norms for
Skill Development
Schemes of the
Government
of
India as notified by
the Ministry of Skill
Development
&
Entrepreneurship
(as may be amended (ii)
from time to time).

(ii) Depending on the
requirements
the
implementing
agencies will be
provided financial
assistance (100 %
grant-in-aid)
for
purchase
of
machinery
and
equipments
for
conducting training.
65
*** PM-RKVY Guidelines ***

The Farm Machinery
Training & Testing
Institutes (FMTTIs)
will organize skill
development
programmes
as
indicated
in
Annexure
–
XXVII(A)
and
XXVII(B).
The States may also
identify
the
institutions
for
organizing the skill
development
programmes
as
indicated
in
Annexure- XXVII
(B).
(iii) The skilling on Kisan
Drones may be taken
through Remote Pilot
Training

<!-- page 67 -->

Organizations
(RPTOs).
(iv) All
implementing
agencies will monitor
the
outcome
of
training in terms of
employment
generation,
selfemployment,
improvement
in
productivity/ skills
etc.
(v) The
Institutions
under ICAR, SAUs
and other Central
institutions
may
submit
their
proposals
directly.
However,
the
institutions
under
State Governments
will have to route
their
proposals
through
State
Department
of
Agriculture/
Agricultural
Engineering.
3

Testing
of
agricultural
machines and
equipments for
performance
evaluation

FMTTIs
and (i)
Authorized Centres
under
ICAR/SAUs/State/
Central
Governments

The implementing (i)
institutions will be
provided one time
grant of Rs. 1.5
crores each as per
their proposals for
augmenting
the
facilities
and (ii)
infrastructure
for
testing.

The grants provided
will not be utilized to
meet the recurring
expenditure
on
testing activities and
purchase of vehicles
etc.
The FMTTIs will
test the machines
and equipments as
(ii) Additional grants up
per
their
to Rs. 1.00 Crore
authorization.
over and above the (iii) The
identified
one time grant may
institutions as per
be provided for
Annexure –XXIX or
creating additional
the institutions as
testing facilities for
may be recognized
testing of
new
in future shall test all
machines as may be
non-self-propelled
approved
by
agricultural
DA&FW.
machines/
equipment.
Other
equipments may be
tested as per the
separate
66

*** PM-RKVY Guidelines ***

<!-- page 68 -->

authorization issued
to individual centers
by DA&FW.
(iv) The testing charges
for the machines and
equipments may be
as fixed by the
Department
of
Agriculture
&
Farmers Welfare.
(v)

All the institutions
shall scrupulously
follow the Test
Regulations and all
other
guidelines
issued
by
the
Department
of
Agriculture
&
Farmers
Welfare
from time to time
(vi) The
Institutions
under ICAR, SAUs
and other Central
institutions
may
submit
their
proposals
for
financial assistance
directly to DA&FW.
However,
the
institutions
under
State Governments
will have to route
their
proposals
through
State
Department
of
Agriculture/
Agricultural
Engineering.

Note:
1. The States may, if they so desire, set aside 25% of budget (including the Central and
State Share) as flexi funds to be spent on any sub-scheme or component or innovation
that is in line with the overall aim and objective of the approved scheme. In this regard
the guidelines for Flexi funds within Centrally Sponsored Schemes of Department of
Expenditure vide Office Memorandum No. 55(5)/PF-II/2011 dated 6th September
2016 shall be scrupulously followed.
2. For the financial assistance for kisan drone, the dones may be supplied as a package
as indicated in the Operational Guidelines of Namo Drone Didi Scheme. The Kisan
Drone specification and training syllabus for drone pilot shall also be as per
Operational Guidelines of Namo Drone Didi Scheme.
67
*** PM-RKVY Guidelines ***

<!-- page 69 -->

3. 2.5% of annual outlay of SMAM will be earmarked for incurring administrative and
other contingent expenses by the States
B.2.3 General Instructions for Smooth implementation of the Scheme:
(i)

The manufacturers eligible for supply of machines based on machine quality
conforming to standard specifications, relevant and valid test report of the
authorized testing institution and availability of product warranty & after sales
service infrastructure from the manufacturer etc. shall be empaneled by the States.
The States shall ensure that the cost of machines are reasonable compared to the
open market prices of the machines. The manufacturers shall observe transparency
in selling prices and the product warranty including after sales services intended to
be provided to the farmers/beneficiaries. The maximum selling prices should be
displayed on the websites of the manufacturers and also in the dealer’s shop.

(ii)

The farmers/beneficiaries will be at their liberty to choose any machine/equipment
and its variants depending on their requirements and as per their choice from within
the empanelled manufacturers by the States and may negotiate the final price after
bargaining with the manufacturer/dealer and the beneficiary will be eligible to get
the applicable subsidy through DBT.

(iii)

In the interest of promoting make in India and Atm-Nirbhar Bharat, it is desired that
the States should not impose huge amount of Earnest Money Deposit (EMD) and
Performance Security, as the manufacturers in small scale sector gets deprived of
their participation in the process carried out by the State Governments for supply of
machines under the scheme. The Performance Security, if at all necessary, may be
3-5% of the value of the contract and may be furnished in the form of Insurance
Surety Bonds, Account Payee Demand Draft, Fixed Deposit Receipt from a
commercial Bank, Bank Guarantee (including e-Bank Guarantee) from a
commercial bank or online payment in acceptable form safeguarding the purchasers
interest in all respects. Insisting on adequate after sales service infrastructure and
blacklisting of the firms for failing to meet their obligations may also be adopted.

(iv)

A comprehensive online system should be developed for implementing the farm
mechanization programmes in the States and it should have arrangements for data
sharing on Central portal i.e. https://agrimachinery.nic.in. The States which does
not have their online portals will have to be on-boarded on the Central portal.
68
*** PM-RKVY Guidelines ***

<!-- page 70 -->

(v)

Manufacturers/suppliers that have tested their products either from FMTTIs or any
identified institute by DA&FW will only be eligible for supply of machines. The
requirement of test report for the agricultural implements and tools costing less than
50,000 (Fifty thousand) may not be necessary. For such machines, self-certification
for the desired specification/ quality/ performance of agricultural implements and
tools may be accepted from manufacturers. However, the test report of the FMTTIs
or authorized testing institutions may be mandatory for the first time manufacturer
of such agricultural implements and tools.

(vi)

The agricultural implements and tools costing less than Rs. 50,000 (Fifty thousand)
as at SI. No (v) above covers only hand tools, non-powered horticultural & garden
tools, animal /manual/ implements required for land preparation/sowing &
planting/inter-cultivation/harvesting and threshing/ transportation operations,
tractor drawn conventional/ mechanical implements such as ploughs, harrows, seed
drills etc. However, a system of random pre/post-dispatch checks of above
agricultural implements and tools shall be evolved by the State Governments and if
the situation warrants, randomly picked up samples of such agricultural implements
and tools shall be tested/ retested from any FMTTI or any authorized testing centre
of DA&FW for asserting their specifications, performance and quality.

(vii)

Every machine costing Rs. 1.00 lakh and above supplied under the scheme shall
mandatorily be georeferenced. The self-propelled machines costing Rs. 1.00 lakh
and above such as tractors, self-propelled crop reaper/reaper cum binders etc.
supplied to individual farmers and Custom Hiring Centres should be installed with
app based AI-powered telematics kit which can track the live movement & location
of machine and keep the daily record of work done by the machine. The dashboard
of the telematics kit shall be available with the beneficiary of the machines/CHCs
and the district as well as State Nodal officer of the scheme. The telematics kit shall
be provided by the manufacturers as standard attachment on their machines
manufactured after 1st June 2023. The establishment of CHCs should be
georeferenced and it should be mandatorily uploaded on the ‘FARMS’ Mobile App

(viii) It shall be mandatory that the all the Data of Custom Hiring Centres/Farm
Machinery capital assets under the scheme including the demonstrations conducted
shall mandatorily be uploaded on the Krishi Mapper.
69
*** PM-RKVY Guidelines ***

<!-- page 71 -->

(ix)

The Soil Health Card may be necessary for getting the subsidy under the Scheme.
If the beneficiary do no possess any Soil Health Card, the soil sample may be
collected from the beneficiary and it may be tested for Soil Health Card generation.
The expenditure may be adjusted with the subsidy amount of the beneficiary.

(x)

The machines supplied under the subsidy programmes should have a standardized
unique identification code provided on the body of the machine by laser cut through
methods in such a way that it is clearly identifiable, visible and is tamperproof. The
guidelines for providing the serial number are as under:

“GJ/6545/444/2023/0001”
Manufacturing Manufacturers ID
Centralized
State Code
Implement
Code
Auto
generated
https://agrimachinery.nic.in/ portal

Year of
Serial Number of
Manufacturing
Machines
Manufactured

through
To be provided by the manufacturer

(a) The type of letter should be ‘Arial Bold, size of letter should be 25 mm. However,
depending on the machine design and space constraints for various machines, the
manufacturers are allowed the font size lesser than the indicated one which can
be conveniently put on the body of the machine provided that the code is clearly
identifiable and visible on the machines.
(b) All the manufacturers have to register themselves on ‘agrimachinery.nic.in’
portal and needs to obtain the registration number.
(c) The agricultural implement/ machinery costing Rs. 1.00 lakh and more should
have laser cut serial number on the main frame which can be viewed from front
side of the implement/machinery and the implements/machines on which laser
cut serial number is not possible, should place of laser cut serial number plate by
welding it on the main frame which can be viewed from front side of the
implement/machinery.
(d) The agricultural implements/machines costing less than Rs. 1.00 lakh should
have engraved serial number on the location of main frame which can be viewed
from front side of the implement/machinery.
70
*** PM-RKVY Guidelines ***

<!-- page 72 -->

(e) The implements/machines having fiber or plastic body on which laser cutting
serial number is not possible, such implement/machine should have engraved
serial number
(f) The manufacturers those who may exhaust the 4 digit serial number due to their
higher production capacities for any particular machine, the States may allow the
manufacturers to use up to 6 digits serial number.
(g) This unique serial number coding system shall be accepted by all the States and
there shall not be any State specific coding system.
(h) Apart from unique identification code, every machine shall also be provided with
labeling plate firmly attached by riveting, hammer drive screws or welding in a
conspicuous and readily accessible position on a part which is normally not likely
to be replaced during use. It shall show clearly and indelibly the information (1)
Complete name and address of the manufacturer (ii) Make & Model of the
machine (iii) Type and size of machine (iv) Unique identification code of the
machine (v) Month and year of manufacture (vi) Required size of prime mover.
(i) The type of letter should be ‘Arial Bold, size of letter should be 25 mm. However,
depending on the machine design and space constraints for various machines, the
manufacturers are allowed the font size lesser than the indicated one which can
be conveniently put on the body of the machine provided that the code is clearly
identifiable and visible on the machines.
(j) All the manufacturers have to register themselves on ‘agrimachinery.nic.in’
portal and needs to obtain the registration number.
(k) The agricultural implement/ machinery costing Rs. 1.00 lakh and more should
have laser cut serial number on the main frame which can be viewed from front
side of the implement/machinery and the implements/machines on which laser
cut serial number is not possible, should place of laser cut serial number plate by
welding it on the main frame which can be viewed from front side of the
implement/machinery.
(l) The agricultural implements/machines costing less than Rs. 1.00 lakh should
have engraved serial number on the location of main frame which can be viewed
from front side of the implement/machinery.
71
*** PM-RKVY Guidelines ***

<!-- page 73 -->

(m) The implements/machines having fiber or plastic body on which laser cutting
serial number is not possible, such implement/machine should have engraved
serial number
(n) The manufacturers those who may exhaust the 4 digit serial number due to their
higher production capacities for any particular machine, the States may allow the
manufacturers to use up to 6 digits serial number.
(o) This unique serial number coding system shall be accepted by all the States and
there shall not be any State specific coding system.
(p) Apart from unique identification code, every machine shall also be provided with
labeling plate firmly attached by riveting, hammer drive screws or welding in a
conspicuous and readily accessible position on a part which is normally not likely
to be replaced during use. It shall show clearly and indelibly the information (1)
Complete name and address of the manufacturer (ii) Make & Model of the
machine (iii) Type and size of machine (iv) Unique identification code of the
machine (v) Month and year of manufacture (vi) Required size of prime mover.
(xi)

The manufacturers eligible for supply of machines based on machine quality
conforming to standard specifications, relevant and valid test report of the
authorized testing institution and availability of product warranty & after sales
service infrastructure from the manufacturer etc. shall be empaneled by the States.
The States shall ensure that the cost of machines are reasonable compared to the
open market prices of the machines. The manufacturers shall observe transparency
in selling prices and the product warranty including after sales services intended to
be provided to the farmers/beneficiaries. The maximum selling prices should be
displayed on the websites of the manufacturers and also in the dealer’s shop.

(xii)

The farmers/beneficiaries will be at their liberty to choose any machine/equipment
and its variants depending on their requirements and as per their choice from within
the empanelled manufacturers by the States and may negotiate the final price after
bargaining with the manufacturer/dealer and the beneficiary will be eligible to get
the applicable subsidy through DBT.

(xiii) In the interest of promoting make in India and Atm-Nirbhar Bharat, it is desired that
the States should not impose huge amount of Earnest Money Deposit (EMD) and
Performance Security, as the manufacturers in small scale sector gets deprived of
72
*** PM-RKVY Guidelines ***

<!-- page 74 -->

their participation in the process carried out by the State Governments for supply of
machines under the scheme. The Performance Security, if at all necessary, may be
3-5% of the value of the contract and may be furnished in the form of Insurance
Surety Bonds, Account Payee Demand Draft, Fixed Deposit Receipt from a
commercial Bank, Bank Guarantee (including e-Bank Guarantee) from a
commercial bank or online payment in acceptable form safeguarding the purchasers
interest in all respects. Insisting on adequate after sales service infrastructure and
blacklisting of the firms for failing to meet their obligations may also be adopted.
(xiv) A comprehensive online system should be developed for implementing the farm
mechanization programmes in the States and it should have arrangements for data
sharing on Central portal i.e. https://agrimachinery.nic.in. The States which does
not have their online portals will have to be on-boarded on the Central portal.
(xv)

Manufacturers/suppliers that have tested their products either from FMTTIs or any
identified institute by DA&FW will only be eligible for supply of machines. The
requirement of test report for the agricultural implements and tools costing less than
50,000 (Fifty thousand) may not be necessary. For such machines, self-certification
for the desired specification/ quality/ performance of agricultural implements and
tools may be accepted from manufacturers. However, the test report of the FMTTIs
or authorized testing institutions may be mandatory for the first time manufacturer
of such agricultural implements and tools.

(xvi) The agricultural implements and tools costing less than Rs. 50,000 (Fifty thousand)
as at SI. No (v) above covers only hand tools, non-powered horticultural & garden
tools, animal /manual/ implements required for land preparation/sowing &
planting/inter-cultivation/harvesting and threshing/ transportation operations,
tractor drawn conventional/ mechanical implements such as ploughs, harrows, seed
drills etc. However, a system of random pre/post-dispatch checks of above
agricultural implements and tools shall be evolved by the State Governments and if
the situation warrants, randomly picked up samples of such agricultural implements
and tools shall be tested/ retested from any FMTTI or any authorized testing centre
of DA&FW for asserting their specifications, performance and quality.
(xvii) Every machine costing Rs. 1.00 lakh and above supplied under the scheme shall
mandatorily be georeferenced. The self-propelled machines costing Rs. 1.00 lakh
73
*** PM-RKVY Guidelines ***

<!-- page 75 -->

and above such as tractors, self-propelled crop reaper/reaper cum binders etc.
supplied to individual farmers and Custom Hiring Centres should be installed with
app based AI-powered telematics kit which can track the live movement & location
of machine and keep the daily record of work done by the machine. The dashboard
of the telematics kit shall be available with the beneficiary of the machines/CHCs
and the district as well as State Nodal officer of the scheme. The telematics kit shall
be provided by the manufacturers as standard attachment on their machines
manufactured after 1st June 2023. The establishment of CHCs should be
georeferenced and it should be mandatorily uploaded on the ‘FARMS’ Mobile App
(xviii) It shall be mandatory that the all the Data of Custom Hiring Centres/Farm
Machinery capital assets under the scheme including the demonstrations conducted
shall mandatorily be uploaded on the Krishi Mapper/Mobile app developed by
DA&FW.
(xix) The Soil Health Card may be necessary for getting the subsidy under the Scheme.
If the beneficiary do no possess any Soil Health Card, the soil sample may be
collected from the beneficiary and it may be tested for Soil Health Card generation.
The expenditure may be adjusted with the subsidy amount of the beneficiary.
(xx)

The machines supplied under the subsidy programmes should have a standardized
unique identification code provided on the body of the machine by laser cut through
methods in such a way that it is clearly identifiable, visible and is tamperproof. The
guidelines for providing the serial number are as under:

B.2.4 Scheme Monitoring
Mechanization & Technology (M&T) Division of Department of Agriculture & farmers
Welfare will be responsible for implementing and monitoring of the Scheme as under:


Visit the states regularly and frequently to provide guidance in organizational and
technical matters.



Help in the implementation, monitoring and evaluation of various interventions in the
scheme and provide feedback reports

74
*** PM-RKVY Guidelines ***

<!-- page 76 -->



Compile materials for capacity building, conduct and participate in the promotional
events such as, workshops/ seminars/exhibitions on different subjects in different
regions of the country.



Undertake

publicity/information

campaign

to

create

awareness

on

farm

mechanization, document and disseminate the success stories.


Assist the State Agencies in concurrent evaluation based on performance indicators



Assess state-wise farm power status, availability and existing gap and identify the
future requirements



In order to enrich the knowledge base of the technical personnel/progressive farmers
involved in the scheme, exposure visit/training of technical staff /officers at
International organizations like IRRI, ICRISAT, CSAM China, NIAE Korea, JICA
Japan, NTTL USA etc. or any other research organization in farm mechanization
within the country and abroad would be organized.



2.5% of annual outlay of the Sub-Mission will be earmarked for incurring
administrative and other contingent expenses towards the above

The component wise details of activities to be undertaken under the scheme are given at
Annexure-(XXV – XXVIII)

75
*** PM-RKVY Guidelines ***

<!-- page 77 -->

B.3

CRM:

A large portion of the paddy straw / crop residues are burnt in the field primarily to clear the
field after the harvest of the preceding crop for the sowing of next crop. Burning these crop
residue causes phenomenal pollution problems in the atmosphere and huge nutritional loss and
physical health deterioration to the soil. It has been estimated that The burning of one tonne of
paddy straw releases 3 kg particulate matter, 60 kg CO, 1460 kg CO2, 199 kg ash and 2 kg SO2.
These gases affect human health due to general degradation in air quality resulting in
aggravation of eye and skin diseases. Fine particles can also aggravate chronic heart and lung
diseases. One ton of paddy straw contains approximately 5.5 kg N, 2.3 kg P2O5, 25 kg K2O, 1.2
kg S, 50-70% of micro-nutrients absorbed by rice and 400 kg of carbon, which are lost due to
burning of paddy straw. Apart from loss of nutrients, some of the soil properties like soil
temperature, pH, moisture, available phosphorus and soil organic matter are greatly affected
due to burning.
Crop Residue Management Options can be classified as in-situ and ex-situ management options.
Retaining, incorporating or mulching the crop residues in the field and decomposing using
consortia of microbes are the two possible in-situ crop residue management options. Baling and
transporting straw from the field is other feasible ex-situ option when alternate, effective and
economically viable usage methods are identified and facilities and infrastructure are created.

It is envisaged that appropriate mix of in-situ and ex-situ crop residue management options
through a holistic approach of providing appropriate solutions, optimally utilizing the existing
resources and establishing appropriate supply chain through a cluster based approach in the
vicinity of various industries utilizing the crop residue will help containing the burning of crop
residues in the open field.

In view of above, the efforts of the States of Punjab, Haryana, Uttar Pradesh, Madhya Pradesh
and NCT of Delhi in addressing the problems of crop residue burning through the interventions
described hereunder:
B.3.1 Strategy:
To achieve the above objectives, a focused approach of providing appropriate and already
accepted machines for in-situ management will be adopted. Optimal utilization of already
76
*** PM-RKVY Guidelines ***

<!-- page 78 -->

available machines and machines that will be made available to fulfil the gaps will be ensured.
A supply chain will be established through a cluster based approach in the vicinity of various
industries utilizing the paddy straw. The supply chain beneficiaries will collect, densify, store
the paddy straw at desired locations and will make available the same to various users or
industries as per requirement. Strategic Information, Education and Communication (IEC) will
also be undertaken with the involvement of all stakeholders for mass awareness of farmers.
I. Financial assistance to farmers for procurement of crop residue management
machines on individual ownership basis:
(a)

Implementing Agencies: State Governments/UTs

(b)

Identification of Beneficiary: Beneficiaries will be identified by the State/district
nodal agencies in a transparent manner. The areas of having larger problems of crop
residue burning may be focused to increase availability of appropriate machines.

(c)

Financial Assistance: The rate of financial assistance will @ 50% of the cost of
machinery. The list of machines identified for crop residue management together with
ceiling limit for subsidy is indicated in Annexure-XXIX

In case of tractor drawn machines, preference may be given to those beneficiaries owning the
compatible tractor for operation of the machine.
II. Establishment of Custom Hiring Centres of Crop Residue Management Machines:
(a)

Implementing Agencies: State Governments

(b)

Composition of Custom Hiring Centres:

(i)

The machines/equipments for establishing Custom Hiring Centres (CHCs)
appropriate for the crop residue management will be selected from within the list at
Annexure-XXIX.

(ii)

Purchase of One tractor of 60 HP & above will be allowed under the project.

(iii) Each CHC should be provided the machines and equipments for the entire operations
of crop residue management.
(iv)

The capacity of the machines may be selected on the basis of area to be covered in
a cropping season.

77
*** PM-RKVY Guidelines ***

<!-- page 79 -->

(c)

Financial Assistance:
Credit Linked Back Ended Subsidy@ 80% of the project cost for the projects of
Custom Hiring Centres (CHCs) costing up to Rs. 30lakhs will be available to Rural
Entrepreneurs (Rural youth and farmer as an entrepreneur), Cooperative Societies of
Farmers, Registered Farmers Societies, Farmer Producer Organizations (FPOs) and
Panchayats. The maximum permissible assistance per machine under the CHC project
is indicated in Annexure-XXX. The maximum permissible subsidy for each project
should not exceed Rs. 24.00 lakhs per project.

The broad Guidelines for Credit Linked Back Ended Subsidy are given in AnnexureXXXI

III. Establishment of crop residue/paddy straw supply chain:
The broader objectives of the crop residue/paddy straw supply chain will be as under:


Enable better environmental practices for ex-situ management crop residue.



Establishing collection infrastructure, bailing, transportation and handling of large
amount of crop residue and creation of storage facilities.



Utilizing the paddy straw in different industries utilizing it such as biomass power
generation units, Biomass co-firing in Thermal Power Plants, Bio-CNG, Bio-Ethanol, etc.



Assured procurement of paddy straw from farmers through the by the paddy straw
aggregators.



Ensure increase in income (both from the produce and later from the sale of paddy
residue) for farmers and enhance rural employment and financial inclusion.
(a)
(b)

Implementing Agencies: State Governments
Financial Assistance:

(i)

Based on the project proposals, a Credit Linked Back Ended Subsidy will be
provided only on the capital cost of machinery and equipment like Higher HP
Tractor, Cutters, Tedder, Medium to Large Balers, Rakers, Loaders, Grabbers and
Telehandlers. The broad Guidelines for Credit Linked Back Ended Subsidy are
given in Annexure-XXXI
78
*** PM-RKVY Guidelines ***

<!-- page 80 -->

(ii)

The projects may be implemented under the bilateral agreement of the end user
industry and the beneficiary. The capital subsidy will be released into the Subsidy
Reserve Fund Account of the concerned borrowers through Direct Benefit
Transfer (DBT).

(iii)

For the project under bilateral arrangement, the financial contribution of each
stakeholder may be as follows:
a) Government (jointly by Central and State Governments) will provide
financial support of 65% up to a maximum limit as indicated in the AnnexureIV. The Government shall implement the intervention through a bilateral
agreement between the Beneficiary and Industries and monitor the
effectiveness with respective State Agriculture Departments to monitor and
manage the project. The expenditure will be met from the flexi funds of the
Crop Residue Management Scheme.
b) Farmer or group of Farmers or Rural Entrepreneurs or Cooperative Societies
of Farmers or Farmers Producer Organizations (FPOs) & Panchayats will
contribute the balance at least 10% and will be the primary aggregator of
feedstock and direct beneficiary of this PPP model. They will perform the
feedstock collection targets in line with the volume and quality guidelines of
the end-use industry/project requirements throughout the life of the
machinery.
c) Industry as primary promoter of the project will contribute the balance project
cost and will act as the Primary consumer of the feedstock collected via
machinery. Industry will be responsible for overall effective machinery
deployment via most suitable machinery manufacturers, training of
beneficiaries, aggregation planning along with volume and quality guidelines,
on-ground execution of aggregation during post-harvest collection period,
pricing of feedstock and offtake guidelines. Industry will be primary
consumer of the feedstock throughout the life of the machinery.

(iv)

For projects which are not under the bilateral arrangement of any end user
industry and beneficiary and the beneficiaries are willing to contribute balance
project cost, the financial contribution in such cases may be as follows:
a) Government (jointly by Central and State Governments) will provide
financial support of 65% upto a maximum limit as indicated in the
79
*** PM-RKVY Guidelines ***
