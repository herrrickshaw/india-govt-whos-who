---
doc_id: "6fedd79b1def30cf"
source_url: "https://cdn.s3waas.gov.in/s36faa8040da20ef399b63a72d0e4ab575/uploads/2026/03/17737469136364.pdf"
ministry: "Nainital"
title: "Excise Policy Rules-2025 (under the three-year period) Application letter for allotment of Uttarakhand Excise Domestic/Foreign Liquor Shops (For biennium 2026-27 and 2027-28)Affidavit for the applicant (341 KB)"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "314f088eb79e5a8e"
---

<!-- page 1 -->

vkcdkjh uhfr fo"k;d fu;ekoyh&2025 ¼f=o"kÊ; ds varxZr½
mÙkjk[k.M vkcdkjh ns'kh@fons'kh efnjk nqdkuksa ds vkoaVu gsrq vkosnu i=
¼o"kZ 2026&27 o 2027&28 f}o"kÊ; gsrq½
vkosnd gsrq 'kiFk i=
¼100 #i;s ds Non Judicial Stamp ij½
vkosnd dk uksVjh ls
izekf.kr uohure~
QksVksxzkQ izLrqr
djuk gksxk

1- ;g fd 'kiFkdrkZ....................................................... iq=@iq=h@iRuh.....................................................
vk;q.................................................................. vuqKkiu la[;k
@ns'kh@fons'kh efnjk
nqdku .................................................... tuin..............................................dk o"kZ 2025&26 gsrq
vuqKkih gSA
irk orZeku fuokl
edku uEcj------------------------------------------uxj@ekSgYyk@xzke@rksd-----------------------------------------------------------------------------Fkkuk@iVokjh iV~Vh------------------------------------------rglhy@mirglhy----------------------------------------------------ftyk-------------------------------------irk LFkkbZ fuokl
edku uEcj------------------------------------------uxj@ekSgYyk@xzke@rksd-----------------------------------------------------------------------------Fkkuk@iVokjh iV~Vh------------------------------------------rglhy@mirglhy----------------------------------------------------ftyk--------------------------------------'kiFk iwoZd vfHkdFku djrk@djrh gwW fd %&
2- ;g fd 'kiFkdrkZ us lh0,y0&5lh ¼ns'kh 'kjkc½ ,oa ,Q0,y0&5Mh ¼fons'kh efnjk½ dh QqVdj
fcdzh dh nqdku -------------------------------------------ftyk--------------------------------------- ds vuqKkiu o"kZ 2026&27
¼fnukad 01-04-2026 ls 31-03-2027 rd½ rFkk vuqKkiu o"kZ 2027&28 ¼fnukad 01-04-2027 ls
31-03-2028 rd½ gsrq vkoaVu djkus gsrq mÙkjk[k.M vkcdkjh uhfr fo"k;d fu;ekoyh] 2025 esa
nh x;h 'krksZ ds vk/kkj ij lger gwWA
3- ;g fd 'kiFkdrkZ us ykbZlsUl dh 'krkZas vkSj izfrcU/kksa dks iwjh rjg ls le> fy;k gS vkSj ;fn
vkosfnr nqdku mls vkoafVr dh tkrh gS rks og fu;eksa] vuqKkiu dh 'krksaZ vkSj ykbZlsUl
izkf/kdkjh }kjk le;&le; ij fn;s tkus okys vU; funZs'kksa dk ikyu djsxk@djsxhA
4- mä vuqKkiu ds fy;s 'kiFkdrkZ vko';d lHkh vgZrk;sa j[krk gSA
5- ;g fd 'kiFkdrkZ Hkkjr dk ukxfjd gS@mRrjk[k.M dk LFkkbZ fuoklh gSA vkosnd rglhy---------------------------------ftyk----------------------------------dk LFkkbZ fuoklh gSA
6- ;g fd 'kiFkdrkZ dh vk;q 21 o"kZ ;k mlls vf/kd gSA
7- ;g fd 'kiFkdrkZ ij u rks ljdkjh vFkok yksd ns;ksa dk cdk;k gS] u gh mudk uke
dkyhlwph esa gS vkSj u gh mRrj izns'k vkcdkjh vf/kfu;e 1910 ¼mRrjk[k.M esa mikUrfjr ,oa
vuqdwfyr½ ds vUrxZr cuk;s x;s fu;eksa ds vUrxZr mUgs vkcdkjh ykbZlsUl /kkj.k djus ls
fooftZr fd;k x;k gSA

<!-- page 2 -->

8- ;g fd 'kiFkdrkZ o mlds ifjokj ds lnL;ksa dk uSfrd pfj= vPNk gS vkSj mUgsa mRrj izns'k
vkcdkjh vf/kfu;e 1910 ¼mRrjk[k.M esa mikUrfjr ,oa vuqdwfyr½ vFkok Lokid ,oa eu%
izHkkoh inkFkZ vf/kfu;e 1985 vFkok rRle; ykxw fdlh vU; fof/k vFkok laKs; vkSj xSj
tekurh vijk/k esa nks’kh ugha ik;k x;k gSA
9- ;g fd 'kiFkdrkZ dks ;fn ns'kh@fons'kh efnjk nqdku vkoafVr dh tkrh gS rks 'kiFkdrkZ }kjk
vkcdkjh uhfr fo"k;d fu;ekoyh&2025 esa fn;s x;s le;kUrxZr okafNr izek.k i= tek dj
nsxk] ;fn 'kiFkdrkZ mDr izek.k i= fu/kkZfjr fnol ds Hkhrj tek ugh dj ik;k rks 'kiFkdrkZ
ds tksf[ke ij nqdku dk vkoaVu fujLr fd;s tkus ij dksbZ vkifRr ugha gksxhA
10- 'kiFkdrkZ }kjk efnjk nqdku ds vkoaVu ds fy, izLrqr fd;s tkus okys izi= gSfl;r] LFkkbZ
fuokl] pfj= izek.k i=] vk/kkj dkMZ] iSu dkMZ] vkbZŒVhŒvkjŒ bR;kfn fookn jfgr gSA
11- ;g fd 'kiFkdrkZ vius mijksä vuqKkiu dk o"kZ 2026&27 o o"kZ 2027&28 gsrq vkoaVu
djkuk pkgrk gSA ;g fd 'kiFkdrkZ ds ikl le;&le; ij ;Fkkla'kksf/kr mRrj çns'k nqdkuksa
dh la[;k ,oa fLFkfr fu;ekoyh 1968 ¼mRrjk[k.M esa mikUrjfr ,oa vuqdwfyr½ ds izkfo/kkuksa o
vkcdkjh uhfr fo"k;d fu;ekoyh&2025 ¼f=o’khZ;½ ,oa vkcdkjh vk;qDr }kjk tkjh fn'kk
funZs'kksa ds vuqlkj nqdku [kksyus ds fy;s mi;qDr ifjlj gS@fdjk;s ij mi;qDr ifjlj ysus
dh O;oLFkk gS ¼tks ykxw u gks mls dkV fn;k tk;½ izLrkfor ifjlj fdlh fof/k ;k fu;eksa ds
izfrdwy ugha cuk;k x;k gS ,oa jksM+ lkbM yS.M dUVªksy ,DV ds izkfo/kkuksa ds vuq:i gSA
12- ;g fd 'kiFkdrkZ }kjk fdlh ,sls fodzsrk vFkok izfrfuf/k ftldh vijkf/kd i`"BHkwfe gks vFkok
tks ladzked ;k Nwr dh chekjh ls xzLr gks vFkok tks 21 o"kZ ls de vk;q dk gks dks fu;qDr
ugha djsxkA
13- ;g fd 'kiFkdrkZ }kjk nqdku vkoaVu ds ckn ikoj vkQ vVkuhZ ds vk/kkj ij fdlh vU;
O;fDr dks nqdku lapkfyr djus gsrq vf/kd`r ugha djsxkA
14- ;g fd 'kiFkdrkZ us ik=rk ls lEcafèkr leLr nLrkost dk;kZy; ftyk vkcdkjh vfèkdkjh
tuin........................................ esa tek djk fn, gSA
15- ;g fd 'kiFkdrkZ dh mijksä nqdku dk o"kZ 2026&27 o o"kZ 2027&28 ds leLr jktLo dks
tek djkus ds fy, çfrc) gS] vkcdkjh uhfr 2025 ds fu;eksa ds vuqdwy vo'ks"k jktLo tek
ugha djkus dh ifjfLFkfr esa nqdku dk fujLrhdj.k fd;s tkus esa mls dksbZ vkifÙk ugh gSA
16- ;g fd 'kiFkdrkZ foÙkh; o"kZ 2026&27 o o"kZ 2027&28 esa fuèkkZfjr jktLo ij nqdku lapkyu
gsrq lger gS vkSj vkcdkjh uhfr fo"k;d fu;ekoyh&2025 vf/klwpuk la[;k% 176@ XXIII-1@
2025&04¼01½@2025 nsgjknwu fnukad% 05] ekpZ] 2025 ds vuqikyu esa iw.kZ fu"Bk ls nqdku@
vuqKkiu dk lapkyu djsxk vkSj fu;eksa ds mYya?ku ,oa jktLo lEcfUèkr vfu;ferrk ugh
djsxk ftlls fd vuqKkiu fujLrhdj.k dh fLFkfr mRiUu gksA
17- ;g fd fu;ekuqlkj fuèkkZfjr le;lhek esa jktLo@,eåthåMhå] çfrHkwfr;ksa dks le; ls tek
ugh djus ds dkj.k nqdku fujLr gksus dh n'kk esa tCr dj yh tk,A
18- ;g fd 'kiFkdrkZ la;qä çkar vfèkfu;e&1910 ¼;Fkk vuqdwfyr ,oa mikUrfjr mÙkjk[k.M jkT;½
,oa lEcfUèkr fu;eksa] vkns'kksa rFkk vkcdkjh uhfr o"kZ 2025 dks Hkyh Hkk¡fr le> fy;k gSA
'kiFkdrkZ vkcdkjh foHkkx }kjk le;&le; ij fn, x, vkns'kksa@funZs'kksa dk ikyu djsxkA
'kiFkdrkZ o"kZ 2026&27 o o"kZ 2027&28 esa QqVdj nqdkuksa ds O;oLFkkiu fu;ekoyh dk ikyu
djsxk vkSj fu;ekoyh ds fdlh çkfoèkku dk mYya?ku ik, tkus ij mldk vuqKkiu fujLr
dj fn;k tk,A
19- ;g fd 'kiFkdrkZ o"kZ 2026&27 o o"kZ 2027&28 gsrq fuèkkZfjr vkosnu 'kqYd ¼çkslsflax Qhl½
fuèkkZfjr okf"kZd jktLo dh tkudkjh Hkyh&Hkk¡fr çkIr dj yh gS rFkk mä ds lEcUèk esa tkjh
v|ru funZs'kksa dk ikyu djsxkA
20- ;g fd 'kiFkdrkZ vius cSad [kkrs ls leLr jktLo tek djsxk vkSj Hkfo"; esa ;fn dksbZ =qfV
ds dkj.k Hkqxrku ¼;fn dksbZ gks rks½ og mä cSad [kkrs esa gh çkIr djus ij lger gSA

<!-- page 3 -->

21- ;g fd 'kiFkdrkZ vkoaVu djus ds mijkar vkoaVu dh vkSipkfjdrkvksa dks fuèkkZfjr le; esa
iw.kZ djsxk vU;Fkk dh fLFkfr esa nqdku dk vkoaVu fujLr dj fn;k tk,A
mijksä Øekad 1 ls ysdj 21 rd nh x;h lwpuk,¡ lgh ,oa lR; gS] esjs }kjk dksbZ
rF; Nqik;k ugh x;k gSA
¼tks ykxw u gks] dkV fn;k tk;s½
LFkku---------------------------------------------fnukad-------------------------------------------le;--------------------------------'kiFkdrkZ
ifCyd uksVsjh dk uke vkSj eksgj
LFkku---------------------------------------------fnukad------------------------------

<!-- page 4 -->

vkcdkjh uhfr fo"k;d fu;ekoyh&2025 ¼f=o"kÊ; ds varxZr½
mÙkjk[k.M vkcdkjh ns'kh@fons'kh efnjk nqdkuksa ds vkoaVu gsrq vkosnu i=
¼o"kZ 2026&27 o 2027&28 f}o"kÊ; gsrq½
lg vkosnd gsrq 'kiFk i=
¼100 #i;s ds Non Judicial Stamp ij½
lg vkosnd dk
uksVjh ls izekf.kr
uohure~ QksVksxzkQ
izLrqr djuk gksxk

1- ;g fd 'kiFkdrkZ....................................................... iq=@iq=h@iRuh.....................................................
vk;q.................................................................. vuqKkiu la[;k
@ns'kh@fons'kh efnjk
nqdku .................................................... tuin..............................................dk o"kZ 2025&26 gsrq
vuqKkih gSA
irk orZeku fuokl
edku uEcj------------------------------------------uxj@ekSgYyk@xzke@rksd-----------------------------------------------------------------------------Fkkuk@iVokjh iV~Vh------------------------------------------rglhy@mirglhy----------------------------------------------------ftyk-------------------------------------irk LFkkbZ fuokl
edku uEcj------------------------------------------uxj@ekSgYyk@xzke@rksd-----------------------------------------------------------------------------Fkkuk@iVokjh iV~Vh------------------------------------------rglhy@mirglhy----------------------------------------------------ftyk--------------------------------------'kiFk iwoZd vfHkdFku djrk@djrh gwW fd %&
2- ;g fd 'kiFkdrkZ us lh0,y0&5lh ¼ns'kh 'kjkc½ ,oa ,Q0,y0&5Mh ¼fons'kh efnjk½ dh QqVdj
fcdzh dh nqdku -------------------------------------------ftyk--------------------------------------- ds vuqKkiu o"kZ 2026&27
¼fnukad 01-04-2026 ls 31-03-2027 rd½ rFkk vuqKkiu o"kZ 2027&28 ¼fnukad 01-04-2027 ls
31-03-2028 rd½ gsrq vkoaVu djkus gsrq mÙkjk[k.M vkcdkjh uhfr fo"k;d fu;ekoyh] 2025 esa
nh x;h 'krksZ ds vk/kkj ij lger gwWA
3- ;g fd 'kiFkdrkZ us ykbZlsUl dh 'krkZas vkSj izfrcU/kksa dks iwjh rjg ls le> fy;k gS vkSj ;fn
vkosfnr nqdku mls vkoafVr dh tkrh gS rks og fu;eksa] vuqKkiu dh 'krksZa vkSj ykbZlsUl
izkf/kdkjh }kjk le;&le; ij fn;s tkus okys vU; funZs'kksa dk ikyu djsxk@djsxhA
4- mä vuqKkiu ds fy;s 'kiFkdrkZ vko';d lHkh vgZrk;sa j[krk gSA
;g fd 'kiFkdrkZ Hkkjr dk ukxfjd gS@mRrjk[k.M dk LFkkbZ fuoklh gSA vkosnd rglhy---------------------------------ftyk----------------------------------dk LFkkbZ fuoklh gSA
5- ;g fd 'kiFkdrkZ dh vk;q 21 o"kZ ;k mlls vf/kd gSA
6- ;g fd 'kiFkdrkZ ij u rks ljdkjh vFkok yksd ns;ksa dk cdk;k gS] u gh mudk uke
dkyhlwph esa gS vkSj u gh mRrj izns'k vkcdkjh vf/kfu;e&1910 ¼mRrjk[k.M esa mikUrfjr ,oa
vuqdwfyr½ ds vUrxZr cuk;s x;s fu;eksa ds vUrxZr mUgs vkcdkjh ykbZlsUl /kkj.k djus ls
fooftZr fd;k x;k gSA

<!-- page 5 -->

7- ;g fd 'kiFkdrkZ o mlds ifjokj ds lnL;ksa dk uSfrd pfj= vPNk gS vkSj mUgsa mRrj izns'k
vkcdkjh vf/kfu;e&1910 ¼mRrjk[k.M esa mikUrfjr ,oa vuqdwfyr½ vFkok Lokid ,oa eu%
izHkkoh inkFkZ vf/kfu;e&1985 vFkok rRle; ykxw fdlh vU; fof/k vFkok laKs; vkSj xSj
tekurh vijk/k esa nks’kh ugha ik;k x;k gSA
8- ;g fd 'kiFkdrkZ dks ;fn ns'kh@fons'kh efnjk nqdku vkoafVr dh tkrh gS rks 'kiFkdrkZ }kjk
vkcdkjh uhfr fo"k;d fu;ekoyh&2025 ¼f=o’khZ;½ esa fn;s x;s le;kUrxZr okafNr izek.k i=
tek dj nsxk] ;fn 'kiFkdrkZ mDr izek.k i= fu/kkZfjr fnol ds Hkhrj tek ugh dj ik;k rks
'kiFkdrkZ ds tksf[ke ij nqdku dk vkoaVu fujLr fd;s tkus ij dksbZ vkifRr ugha gksxhA
9- 'kiFkdrkZ }kjk efnjk nqdku ds vkoaVu ds fy, izLrqr fd;s tkus okys izi= gSfl;r] LFkkbZ
fuokl] pfj= izek.k i=] vk/kkj dkMZ] iSu dkMZ] vkbZŒVhŒvkjŒ bR;kfn fookn jfgr gSA
10- ;g fd 'kiFkdrkZ vius mijksä vuqKkiu dk o"kZ 2026&27 o o"kZ 2027&28 gsrq vkoaVu
djkuk pkgrk gSA ;g fd 'kiFkdrkZ ds ikl le;&le; ij ;Fkkla'kksf/kr mRrj çns'k nqdkuksa
dh la[;k ,oa fLFkfr fu;ekoyh 1968 ¼mRrjk[k.M esa mikUrjfr ,oa vuqdwfyr½ ds izkfo/kkuksa o
vkcdkjh uhfr fo"k;d fu;ekoyh&2025 ¼f=o’khZ;½ ,oa vkcdkjh vk;qDr }kjk tkjh fn'kk
funZs'kksa ds vuqlkj nqdku [kksyus ds fy;s mi;qDr ifjlj gS@fdjk;s ij mi;qDr ifjlj ysus
dh O;oLFkk gS ¼tks ykxw u gks mls dkV fn;k tk;½ izLrkfor ifjlj fdlh fof/k ;k fu;eksa ds
izfrdwy ugha cuk;k x;k gS ,oa jksM+ lkbM yS.M dUVªksy ,DV ds izkfo/kkuksa ds vuq:i gSA
11- ;g fd 'kiFkdrkZ }kjk fdlh ,sls fodzsrk vFkok izfrfuf/k ftldh vijkf/kd i`"BHkwfe gks vFkok
tks ladzked ;k Nwr dh chekjh ls xzLr gks vFkok tks 21 o"kZ ls de vk;q dk gks dks fu;qDr
ugha djsxkA
12- ;g fd 'kiFkdrkZ }kjk nqdku vkoaVu ds ckn ikoj vkQ vVkuhZ ds vk/kkj ij fdlh vU;
O;fDr dks nqdku lapkfyr djus gsrq vf/kd`r ugha djsxkA
13- ;g fd 'kiFkdrkZ us ik=rk ls lEcafèkr leLr nLrkost dk;kZy; ftyk vkcdkjh vfèkdkjh
tuin........................................ esa tek djk fn, gSA
14- ;g fd 'kiFkdrkZ dh mijksä nqdku dk o"kZ 2026&27 o o"kZ 2027&28 ds leLr jktLo dks
tek djkus ds fy, çfrc) gS] vkcdkjh uhfr 2025 ds fu;eksa ds vuqdwy vo'ks"k jktLo tek
ugha djkus dh ifjfLFkfr esa nqdku dk fujLrhdj.k fd;s tkus esa mls dksbZ vkifÙk ugh gSA
15- ;g fd 'kiFkdrkZ foÙkh; o"kZ 2026&27 o o"kZ 2027&28 esa fuèkkZfjr jktLo ij nqdku lapkyu
gsrq lger gS vkSj ç[;kfir vkcdkjh uhfr fo"k;d fu;ekoyh&2025 ¼f=o’khZ;½ vf/klwpuk
la[;k% 176@XXIII-1@2025&04 ¼01½@2025 nsgjknwu fnukad% 05] ekpZ] 2025 ds vuqikyu esa
iw.kZ fu"Bk ls nqdku@vuqKkiu dk lapkyu djsxk vkSj fu;eksa ds mYya?ku ,oa jktLo
lEcfUèkr vfu;ferrk ugh djsxk ftlls fd vuqKkiu fujLrhdj.k dh fLFkfr mRiUu gksA
16- ;g fd fu;ekuqlkj fuèkkZfjr le;lhek esa jktLo@,eåthåMhå] çfrHkwfr;ksa dks le; ls tek
ugh djus ds dkj.k nqdku fujLr gksus dh n'kk esa tCr dj yh tk,A
17- ;g fd 'kiFkdrkZ la;qä çkar vfèkfu;e&1910 ¼;Fkk vuqdwfyr ,oa mikUrfjr mÙkjk[k.M jkT;½
,oa lEcfUèkr fu;eksa] vkns'kksa rFkk vkcdkjh uhfr o"kZ 2025 dks Hkyh Hkk¡fr le> fy;k gSA
'kiFkdrkZ vkcdkjh foHkkx }kjk le;&le; ij fn, x, vkns'kksa@funZs'kksa dk ikyu djsxkA
'kiFkdrkZ o"kZ 2026&27 o o"kZ 2027&28 esa QqVdj nqdkuksa ds O;oLFkkiu fu;ekoyh dk ikyu
djsxk vkSj fu;ekoyh ds fdlh çkfoèkku dk mYya?ku ik, tkus ij mldk vuqKkiu fujLr
dj fn;k tk,A
18- ;g fd 'kiFkdrkZ o"kZ 2026&27 o o"kZ 2027&28 gsrq fuèkkZfjr vkoaVu 'kqYd ,oa vkosnu 'kqYd
¼çkslsflax Qhl½] fuèkkZfjr okf"kZd jktLo dh tkudkjh Hkyh&Hkk¡fr çkIr dj yh gS rFkk mä
ds lEcUèk esa tkjh v|ru funZs'kksa dk ikyu djsxkA
19- ;g fd 'kiFkdrkZ vius cSad [kkrs ls leLr jktLo tek djsxk vkSj Hkfo"; esa ;fn dksbZ =qfV
ds dkj.k Hkqxrku ¼;fn dksbZ gks rks½ og mä cSad [kkrs esa gh çkIr djus ij lger gSA

<!-- page 6 -->

20- ;g fd 'kiFkdrkZ vkoaVu djus ds mijkar vkoaVu dh vkSipkfjdrkvksa dks fuèkkZfjr le; esa
iw.kZ djsxk vU;Fkk dh fLFkfr esa nqdku dk vkoaVu fujLr dj fn;k tk,A
mijksä Øekad 1 ls ysdj 20 rd nh x;h lwpuk,¡ lgh ,oa lR; gS] esjs }kjk dksbZ
rF; Nqik;k ugh x;k gSA
¼tks ykxw u gks] dkV fn;k tk;s½
LFkku---------------------------------------------fnukad-------------------------------------------le;--------------------------------'kiFkdrkZ
ifCyd uksVsjh dk uke vkSj eksgj
LFkku---------------------------------------------fnukad------------------------------
