---
doc_id: "b62a94af45bc3acb"
source_url: "https://cdnbbsr.s3waas.gov.in/s303412aef4dcdee4f934f7bf599f89783/uploads/2026/09/20260928924463489.pdf"
ministry: "Uttarakhand Power Corporation Limited (UPCL), Uttarakhand"
title: "Tender Notice No. 55/EDC Chakrata (K)/2026-27."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "34ebca83be30ccaf"
---

<!-- page 1 -->

UPCL/2470/2026-SE EDC CHAKRATA-U.P.C.L

I/74163/2026

dk;kZy; v/kh{k.k vfHk;Urk
mÙkjk[k.M ikoj dkjiksjs'ku fy0
¼mÙkjk[k.M ljdkj dk miØe½

fo|qr forj.k e.My] pdjkrk ¼eq0&dkylh½] nsgjknwuA
lh-vkbZ-,u- la0 U40109UR2001SGC025867

osclkbV& www.upcl.org] nwjHkk"k&9411746161]
bZ&esy edc.chakrata@upcl.org, edcchakrata@gmail.com

fufonk lwpuk
v/kksgLrk{kjh }kjk fuEufyf[kr dk;kZas gsrq] vk;dj] bZ0ih0,Q0] oLrq ,oa lsokdj ,oa bZ0,l0vkbZ0 esa
iathd`r fo|qr dk;kZas gsrq mRrjk[k.M 'kklu }kjk iznRr ^^,^^ Dykl ykblsUl/kkjd vuqHkoh Bsdsnkjks ls]
eksgjcUn fufonk;sa nks Hkkxks esa ¼izFke Hkkx esa /kjksgj jkf'k] tks vf/k'kklh vfHk;Urk] fo|qr forj.k [k.M]
fodkluxj ds uke cukbZ tk;sxh] 180 fnuks ds fy, oS| gks ,oa fu;e o 'krsZ] izi= bR;kfn rFkk
f}rh; Hkkx esa njas gksa½ fnukad 14&10&2026 dks 15%00 cts rd vkefU=r dh tkrh gSa] ftudk izFke
Hkkx] mlh fnu v/kksgLrk{kjh ds dk;kZy; esa 15%30 cts lkoZtfud :i ls [kksyk tk,xkA fufonk izi=
dk udn 'kqYd dk;kZy; vf/k'kklh vfHk;Urk] fo|qr forj.k [k.M] fodkluxj esa tek djkus ds
mijkUr] fufonk izi= ,oa lEcfU/kr fooj.k v/kksgLrk{kjh ds dk;kZy; ls fnukad 13&10&2026 dks lka;
17%00 cts rd izkIr fd;s tk ldrs gSaA fufonk foØ; djus dh frfFk@[kqyus dh frfFk dks fdlh
dkj.k vodk'k gksus ij mDr dk;Z vxys dk;Z fnol ij gksxkA fdlh Hkh fufonk dks fcuk dkj.k
crk;s vLohd`r@fujLr djus dk vf/kdkj v/kksgLrk{kjh ds ikl lqjf{kr gksxkA foLr`r fu;e o 'krsZ
fufonk izi= eas of.kZr gSA
fufonk la0& 55@fo0fo0e0p0¼dk0½@2026&27: fo|qr forj.k mi[k.M] pdjkrk ds vUrxZr u,
la;kstu fuxZr djus gsrq ,p-Vh@,y-Vh ykbZu ,oa milaLFkku ds fuekZ.k dk dk;ZA
/kjksgj jkf'k :0 70]000-00] fufonk izi= dk ewY; :0 1000-00+th0,l0Vh0 vfrfjDrA

v/kh{k.k vfHk;Urk
