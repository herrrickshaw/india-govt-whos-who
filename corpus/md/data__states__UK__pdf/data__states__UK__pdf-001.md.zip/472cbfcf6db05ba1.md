---
doc_id: "472cbfcf6db05ba1"
source_url: "https://cdnbbsr.s3waas.gov.in/s33cf2559725a9fdfa602ec8c887440f32/uploads/2026/07/202607021797959540.pdf"
ministry: "Directorate of Training & Employment, Uttarakhand"
title: "LDC Transfer Order-2026"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a846579725239389"
---

<!-- page 1 -->

fqrqts{ frrTrrr, gRRT"I gf ffiqq, fttqrrdq
sfrW, E€rft (i-ftdrd)
Tdi-o

7fidrfu$oto) /l-t /eqnto / 2026

-

ffi6_ go q{ 2026
orqfdq-sntsr

crfu{rnI +
d}6-ffi A fuq otffi6 rerFil<rrq orBfutrq-zorz iiq-qfrtrdq5s
cifuT
d
Hfrfr sgr qrt .ffi q-qfr d anw qq frq ffiIffi d s-r-d

1'f,{sriT sd{tcru-s

nfu
wra tg gq sfuc-.rii d qrer reTrrffinT fu-qr qr {6r B fu tefiqr<Rd oTffi6 reffiilEltlt
qsul o-til
oil-Aq trd di * mO t gqr Hkp6 d ci-q{ qRrer-ft of ffien frti C-{r o-drl{
gpfrad *11 sqf,+ro utBolt serTlrfltrd oTHo o) n-<gqri e $DIEI 3i-q5ffi of r erqgm *i qrd
otff@ ftqruqri ei-grru o.rdErq qaq o-Ei et q-qts (Joining time) d 3i-q-fii€r 6-1 sqfrq qq
qrfl
ffi d qq oT odril{ qaq o-G d rswr< fr o-< sd,T oer q-qgEfl d sq{r.il qr, 3i-5rlq
erqts (Journey Time) mr fr sqlnq o-q sdi t *effirf,R-d olffiqt ar\ qs ci-qB fr ftffi q-6-R or
sq-,=i d-qf,'T$ fr# qfiqT et.q turqTf,Rd flffio. gRI Tq ffi rerFt tN qfl*fl{ a5q q o-G
rtr Bq-d fti.€ ffiqr 24 d oEqtq Eu-srfrIo o]ffi qft qTtt t T€nfl-f,R( o]-ffi or qrd

ci-n fd

qq ffi

ero t olrdRd fuqT qr}qT
Tq i-{ffi TE]ET
or terq sq-d qq

m0H0

o.ffi

o.r qFI

qE=TTII

Tfrqrq

ffilt

+lt rotq 1fr-6

ilI

.nHsd
SERTM'

2.

3.

fr trfirT frfE

ffi

fr gfv vra
g-ftI

;TFI

fu-ar tqFiqq
oTqidq, tfi-dTd

ftrot €-qrqmq o.rqldq,

'ffis{

oTqiilq, e-oronft

etfrq €-qrqm-q o.rqlilq,
t-f,{I(q

o-fisd

fildrtqrqls{

ffi-m A-qrqrq-q orqff,q,

T{Eftl-6

oTqfaq, qEil-.KI

fraiqnTB

drt

(((F]EI qqF[

q-{fta q

I

ARfltKT

o-lisd
T{6ftI6

fiileTr

orgk

Tsil=T6ftuf d V61gSq
qtrqftrq o.I
rq

orqff,q tnT "IFI

1

I

{qq d
ee-gtu w

t

3TTEII{ q{ I

I

//

1et< IHe q"srfr) ns
ftAero, ffi-q-{

rqFfiin-d
ggn q- I 373- Bl 7€r&fu$ero) /l-r /rp4,rqrc / r!26
qrrffi
rfi
iBir
eTrq{{fi'
tg
rx-drTei
Wi
ifrfrfr,- ffifuf,
1. qfuq olvd fr-fiT-fl \d ffiq-{, s.f,(Tclu-s qrrcr;l, fuqrqt
2. q-6re€-rdtx Gfi-{rrq M Ek q rrflvqg{ ts, qr.ilqr, irvr<q t
a-{gr(q
3. BqfrAYrfi ffi{, zo {ofro t"s sil
"to
sxifua S-at
4. grwloRw offi/e-q-offi
q-dqt-srZt6-{r$
oTffi
s. fi{q ffi{
qkiD-d
ffiq-q etffit
6.
r. tq {.frknpTq qtw/et+q ffiG-{ GTffi, t6{r{q of gs frftr d qrQr fu'
TQTF1nN,T GTfuFqq qft eTm za (ro) d GTfi{ TsTmr;il{ur sr-tvt T@-IET frtilrnq
t

t

t

.

I

t

il{flt{c .r{ r<Rfd (qq-dt-s) o-sqr SmR-+o of

8. qrqF+rf, orffio
e. rrd q{raft ft-t$-f,q(t-qTo)
t

t

t

v

(qtq R/qwr{t)

ft|sro,'msq 'ot
