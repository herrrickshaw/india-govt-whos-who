---
doc_id: "1c1cfd79ec1d84ef"
source_url: "https://www.kmvn.in/medias/tender_document/tender225966178954645212168187284234608_1484297169.pdf"
ministry: "Kumaon Mandal Vikas Nigam Ltd., Uttarakhand"
title: ""
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e99fd1870bc8bcab"
---

<!-- page 1 -->

fO

FiO-2071/2072/10-4}0T/18-19 fi 08.09.2026

zorofaofAofaO

qao

e|/10-HtT/ 26-27

(s2028

E0Hofaofrofo
