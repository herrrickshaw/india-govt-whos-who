---
doc_id: "8e74af3d2cc6efae"
source_url: "https://ptcul.org/downloads/circulars/doc_193_1878-House-of-Himalayas.pdf"
ministry: "Power Transmission Corporation of Uttarakhand Limited (PTCUL), Uttarakhand"
title: "Regarding House of Himalayas Product"
date: ""
pages: 4
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "d74e79e67065435b"
---

<!-- page 1 -->

@) ee | पावर ट्रॉसमिशन शन ऑफ उत्तराखण्ड feo
(उत्तराखण्ड सरकार का उपक्रम)
CIN:- ७404040२2004560028675
मानव संसाधन एवं प्रशासनिक विभाग
विद्युत भवन, नजदीक-आई0एस0बी0टी0 क्रासिंग, सहारनपुर रोड़, माजरा, देहरादून-248002
PTCUL . E-mail: hr@ptcul.org
ao 0:35—2645249 फैक्स नं० 0435—2645249 वैबसाइट www.ptcul.org
Was FO/ माएसं0एवंग्र0अनु0// पिटकुल / जी-4 दिनांक: ($.40.2026
विषय:-विभिन्‍न स्तरों से प्राप्त सामान्य प्रकरणों के सम्बन्ध में।
समस्त मुख्य अभियन्ता/महाप्रबन्धक,
समस्त अधीक्षण अभियन्ता/उपमहाप्रबन्धक,
समस्त अधिशासी अभियन्ता
कृपया उपरोक्त विषयक अनु सचिव (ऊर्जा) उत्तराखण्ड शासन के पत्र संख्या 438920/ ॥2)/
2026-05-34 / 2044(8-24938) दिनांक 07.0.2026 @ द्वारा अग्रसारित मुख्य सचिव, उत्तराखण्ड शासन के पत्र
संख्या 8i /HOH /2026-27 दिनांक 23.09.2026 की छायाप्रति आपको इस आशय से संलग्न कर प्रेषित की जा
रही है कि कृपया पत्र में दिये गये निर्देशों का स्वयं अनुपालन करत्ते हुए अपने अधीनस्थ कार्मिकों को भी उक्त
का अनुपालन करने हेतु निर्देशित करने का कष्ट करें।
संलग्नक:-यथोपरि | & VY
( )
उपमहाप्रबन्धक (मा0सं0)
wie: /माएसं0एवंग्र0अनु0 / पिटकुल / जी-4 तद्दिनांक
प्रतिलिपि निम्नलिखित को सूचनार्थ एवं आवश्यक कार्यवाही हेतु प्रेषित:-
4. निजी सचिव-प्रबन्ध निदेशक, पिटकुल देहरादून को प्रबन्ध निदेशक महोदय के संज्ञानार्थ प्रेषित।
2. अधिशासी अभियन्ता (सूचना प्रौद्योगिकी), पिटकुल, देहरादून को इस आशय के साथ प्रेषित कि उक्त वर्णित
पत्र को संलग्नक सहित पिटकुल की वैबसाइट पर अपलोड करवाना सुनिश्चित करें।
3. Managing Director, House of Himalayas Ltd. Dehradun
संलग्नकः-यथोपरि। a
(विवेकानन्द)
उपमहाप्रबन्धक (मा0सं0)
Fee एवं पंजीकृत कार्यलयः- विद्युत वन, नजदीक-आई०एसएबी०टी0 क्रासिंग, सहारनपुर रोड़, माजरा, देहराबून - 24802...
दूरभाश io 035—2646000 Hae नं० 035-2643460
D:\desktop\G-4 Govt \2026\G-4 Year 2026\G-4 OM Year-2026.doc

<!-- page 2 -->

ES2-MC/MC/20/2022-I-2-Energy Department | issued Gt) SCFM “ रे ले - | ! (7438920/2026
ip meprcut State /2/०2 ८... 07 एक TE OM ony
संख्या- 42642 60 — (2)/2026-05-34/20i4(E-24938)
प्रेषक, esheets lee Prac Groahy [wear eM) गंफा० | Bae
प्रेम सिंह राणा, नस 5 Tm AKIO =D
अनु सचिव, eran (40/ FoR FTX |
उत्तराखण्ड शासन। क्र
सेवा में,
emer निदेशक, >
यूपीसीएल / पिटकुल / यूजेवीएनएल,
देहरादून।
ऊर्जा अनुभाग-2 देहरादून: दिनांक £:[- अक्टूबर, 2026
विषय- विभिन्‍न स्तरों से प्राप्त सामान्य प्रकरणों के सम्बन्ध में।
है महोदय,
उपरोक्त विषयक निम्नांकित सारणी में उल्लिखित विभिन्‍न विषयों से सम्बन्धित पत्रों की
छायाप्रति मयसंलग्नक प्रेषित करते हुए मुझे यह कहने का निदेश हुआ है कि पत्रों में की गयी
अपेक्षा के अनुरूप नियमानुसार अग्रेत्तर आवश्यक कार्यवाही करते हुए कृत कार्यवाही से
शासन एवं संबंधित पक्ष को अवगत कराये जाने सहित यदि किसी प्रकरण में शासन स्तर से
कार्यवाही / निर्देश अपेक्षित हो तो तत्संबंध में अपनी सुस्पष्ट आख्यासंस्तुति शासन को उपलब्ध
= कर Sap का | दैनांक..... विषय है
| नाम / पदनाम
[सं ॥ —e
ii | अवधेश शिवपुरी, | दिनांक-25.09.2026 | अनियोजित भूमिगत विद्युत लाईन के]
franfi-t9, न्यू बॉक्स हटवाने के संबंध में। (७९७) |
| | बिल्डिंग. राजघाट,
| ara, . जिला
|| हरिद्वार। _
2 विवेक जैन,[दिनांक-25.092026 | अनुमानित eet जमा >|
| | पता-43 बी0, बावजूद लाईन शिफ्टिंग कार्य प्रारम्भ
| | नरेन्द्र न किये जाने के संबंध में। (0९८) |
| | विहार एक्सटेंशन, |
| राजेन्द्र नगर,
। कौलागढ़ रोड, बल जल उन
देहरादून। _ 7
x i : अपर सचिव, | |/43450/2026 उत्तराखण्ड सेवा का अधिकार
है E | | Yosito, सुराज एवं| दिनांक-22.09.2026 ES 204 की धारा 3 के| ८?
जि 4 5 iE silo अनु0-03, | अंतर्गत सेवाओं a उपलब्ध कराये| "एणा
I E i | उत्तराखण्ड जाने हेतु समय सीमा के निर्धारण के
€ FL शासन। जा संबंध में। (Upci/PTcuL/UsVNL)
cr i 4. | ferent 8395/5-02 (2025-26) | रामबाड़ा-गरूडचट्टी-केदारनाथ या| SYM ,६२.
€ goth a दिनांक-26.08.2026 _ _ ——-
E है em HQ) Eee]
EZ a Datla ns
) [200 alto l203 2268 42200 |
4 « ot (7 ४४ __ | Received Bysdfbashel.....

<!-- page 3 -->

&६57-४९/१९/२०/२०२२--२-छाशप्/ Department . 743892Q/2026
| | Seer सकता | त्रा मार्ग पर आवश्यक अवस्थापना | 4
| उत्तराखण्ड | 846737/C.S.0f./2026 | सुविधाओं के विकास हेतु स्थान | .
| | oo. गरूडचट्टी में आवश्यक भवनों के |
|] े | निर्माण के संबंध |
| # ((UPCL/PTCUL/UIVNL).
ks | = Seaman | सत्य के विभिन्‍न विभागों. की | ye
| राजस्व (£54844) | भूमि,/परिसम्पत्तियों पर अतिक्रमण | Oy
ye अनुमाग-02, दिनांक-28.09.2026 | = तत्काल रोके जाने के संबंध । (के
| |] S : # I(UPCL/PTCUL/UJVNL) |
सन _—— ee
/ | Chief Secretary, | 82/HOH/2026-27 Inclusion. of © “House of
Govt. Of . 5 Himalayas” (HOH) Product in कपः
Uttarakhand, Dated-23.09.2026 Official Gifting, Meetings,
Events, and Protocol
| | Requirements, -reg.
| gpg fe} AUP CLPPTCUL/UIVNE)
7. | राम सिंह पंवार, दिनांक-07.092026 | ग्राम चौड़ा में लगे ट्रांसफर aT)
i ग्राम व पो0- aly, सुरक्षित स्थान पर स्थानांतरित किये
संलग्नक यथोपरि
भवदीय,
rest [५.5 रत 0५ ।
per aa na
Date: 67°46-2026
7:05:27

<!-- page 4 -->

y, >
S
CHIEF SECRETARY
Letter No. - 84] Ho nf 02 b-at
Date - 33/09/20 26
4, All Principal Secretaries/ Secretaries, Govt. of Uttarakhand
2. All District Magistrates, Govt. of Uttarakhand
Subject: Inclusion of “House of Himalayas” (HoH) Products in Official Gifting, Meetings, Events, and Protocol
Requirements
Uttarakhand’s vibrant rural economy is powered by the dedication of thousands of women farmers, Self-
Help Groups (SHGs), and local producer collectives. To provide these mountain entrepreneurs with a unified market
identity, direct commercial access, and sustainable economic dignity, the Government of Uttarakhand established
“House of Himalayas” (HoH) as the State’s apex umbrella brand.
launched by the Hon'ble Prime Minister, Shri Narendra Modi Ji, “House of Himalayas” embodies the
vision of taking authentic, pristine mountain produce from Local to Global. Beyond offering premium organic
foodstuff, the brand presents a rich array of local handicrafts, traditional handlooms, eco-printed and vegetable-
dyed stoles, Himalayan spices, wellness herbal infusions, and celebrated Gl-tagged heritage products, each carrying
the authentic spirit and craftsmanship of Uttarakhand.
To set an institutional precedent and promote local enterprise within State governance, all Departments,
District Administrations, Boards, Corporations, and Autonomous Bodies under the Government of Uttarakhand are
<equested to consider including “House of Himalayas” products and curated hampers for official gifting and to consider including “House of Himalayas” products and curated hampers for official gifting and
administrative needs. This includes protocol gifts for visiting dignitaries, delegate kits for seminars and workshops,
elicitation mementos, and official hospitality requirements across all offices’
—— ree rr
Prioritizing local produce and traditional crafts through House of Himalayas across all Districts and
departments will give vital market momentum to our rural entrepreneurs, reinforcing our collective commitment
to women’s economic empowerment and self-reliance (Atmanirbhar Uttarakhand).
The Managing Director, House of Himalayas Ltd., will be co-ordinating with all Dy +. and Districts
for sharing product catalogs, customized corporate gifting packages, and facilitate sttedmlined procurement
०] बह.
SEN, cpr) 2 \ \
| ( DE re’ \gor tlh
i ५, (०) 2 ) 4७४ Ses है" 58 Chief Secretary,
S<(Crig ation £m a Cm a Government of Uttarakhand
6. [०7१ 9470० 2.) N 6
= Copy to:
\ l._ P.S. to Hon'ble Chief Minister, Government of Uttarakhand, for kind information.
\V 2. Secretary, Rural Development Department, Government of Uttarakhand, for interaction.
\ 3. All Head of Departments / Managing Directors of PSUs & Boards, Government of Uttarakhand, for
necessary consideration and action.
§. 6 4 . Lor~ & 4. Managing Director, House of Himalayas Ltd., Dehradun, to initiate coordi h with respective
आर0 मीनाक्षी Gay ) Departments and District administrations. -
प्रमुख सचिव,ऊर्जा एवं _AS-3636 9-36
का पक ऊर्जा, सिंचाई एवं री En (f >) ५5
सिंचाई एवं नियोजन विभाग. ४7४ > ape
उत्तराखण्ड शासन @ + SSS (Anan Baral
vA Chief ose ry,
Wee ee क्र Government of Uttarakhand’,
अपर सचिव (अजीत सिंह) eas ar
सहकारिता एवं ऊर्जा विभाग संयुक्त सचिव 5 आ।
GET पाए है ¢ Ppp
Ciaut of ittarakhand A Qukhach Raad Nahradiin खिल aE 92454-७००74 29700 Fav * 27475
