---
doc_id: "d29b6bbb5cdc07e8"
source_url: "https://cdnbbsr.s3waas.gov.in/s35074dcf630ca6ff1602cc3ac043b698d/uploads/2025/06/20250826751283515.pdf"
ministry: "Uttarakhand Investment and Infrastructure Development Board (UIIDB)"
title: "Service Sector Policy"
date: ""
pages: 15
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "59ac91d056175e45"
---

<!-- page 1 -->

Enclosure of GO Number-138/Ek(O5l/2024lxxvl/2024, Dated 15th March. 2024

Uttarakhand Service Sector Policy-2 024

<!-- page 2 -->

Uttarakhand Service Sector P olicy-2O24

PREAMBtE...
PURPOSE OF THE POIICY.........

ETIGIBITITY BY FOCUS SECTOR..........

INCENTIVES UNDER THE

POLICY.

IMPLEMENTATION OF POTICY

........ L2

<!-- page 3 -->

Utta rakha nd Service Sector P olicy -2024

1

PReaMsLe

Uttarakhand, formed in year 2000, is the 2oth largest economy (absolute GDP terms; FY22) and 12th largest (per
capita terms; FY22) among lndian states. The State has had an impressive growth rate in the first decade of its
formation, largely propelled by capital-intensive manufacturing growth. The service sector, contributing -40%
of the State's GSDP (current prices) has shown the highest growth, at 8.5% to 9% nominal CAGR over last 5 years.
The groMh has been led by knowledge intensive services like tourism, education, health, financial services; and

equally anchored by labour-intensive services like trade, communication, and transport.
ln order to realize the vision of "sashakt Uttarakhand", it is imperative that the State focusses on accelerating
service sector growth. There are numerous service sectors where Uttarakhand enjoys natural advantages, in
terms of its location, Iandscape, and culture. Uttarakhand has been blessed with abundant natural beauty,
towering mountains, dense forests, perennial rivers, serene green surroundings, and cool climate. lt has rich
history in religious traditions and ayurvedic practices. ln this backdrop, Uttarakhand holds great potential to

/

achieve rapid economic growth in strategic service sectors like tourism, lT lTeS, Data Centres, traditional
medicinal practices, residential schools, film & media shooting, and adventure sports. Further, there is need to
augment the secondary & tertiary healthcare system to ensure that the highest standard of healthcare facilities
is available within the State.

W

<!-- page 4 -->

Uttarakhand Service Sector Policy-2024

2

PURPOSE oF THE PoI.Icv

Service sector serves as the cornerstone of progress in any developed economy. As the economy becomes
sufficient in primary production of food & minerals, and as the manufacturing activity is able to meet domestic
demand with exports driving growth - the economy naturally latches onto services for providing the necessary

boost. Contribution of services / tertiary sector in lndia's economy has grown from *40%in 7990% to -55%
presently. Many factors have led to this rapid growth - software services boom, FDI inflows, multi-fold growth
of financial markets, explosion in domestic tourism, focus on better education and healthcare facilities, growing
digital economy, real estate densification, etc.
Service sectdr, along with manufacturing spurt in the initial decade, has propelled the Uttarakhand economy.
The location and landscape of the State positions it advantageously for select service sectors - most pertinent

examples include schools, ayurvedic resorts, data centres, film studios, etc. Hence, the next chapter of
Uttarakhand's growth has to come from the service sector.
Uttarakhand has already instituted multiple schemes to facilitate investor participation, such as MSME policy,

Start-up Policy, Tourism Policy, lT Policy, Film Policy, Mega lndustrial and lnvestment Policy. These policies
provide various incentives towards capital investment, other fiscal incentives, marketing and promotion,
institutional support, etc, Still there is a need to have a comprehensive policy for the service sector, tailored for
various sub-sectors. ln this light, Government of Uttarakhand, acting thorough Department of planning,
("Department" or the "Authority") has introduced this Uttarakhand Service Sector Policy (the "policy"l.

4

<!-- page 5 -->

Utta rakha nd Service Sector P olicy -2024

3 DRrvrrue Pntosopxv
The philosophy of the Policy is to enable targeted growth in Focus Service Sectors by facilitating marquee
projects by large, reputed players which will help generate widespread employment.

a. Focus Service Sectors
The Government of Uttarakhand intends to support the development of enterprises in the following "Focus
Service Sectors". These sectors have been shortlisted, as they are most amenable to State's natural advantages,
and would be instrumental towards building the Uttarakhand brand.
i.

Healthcare - The population of Uttarakhand (including transient population) is expected to grow on
the back of strong economic growth. Thus, there is a need to establish world-class healthcare facilities
within the State.
o Drivers: Large catchment population; minimal presence of major liealthcare providers
o Target: Tertiary care Hospitals (Multi Speciality / Super Speciality)
Wellness & Traditional Medicine - Uttarakhand has strong ecosystem of ayurveda I yoga ltraditional
treatment / wellness centres, which can be further expanded by inviting reputed national and
international wellness and traditional healing brands to set up in the State. There is an opportunity to
establish Uttarakhand as a leading international hub in ayurveda, traditional medicine and wellness.
Drivers: Government of lndia's focus on promoting Ayush practices; strong association of
Uttarakhand with traditional medicinal practices, especially ayurveda and yoga; excellent
green, peaceful, and pristine locations for attracting top rated wellness operators

o

o Target: Lifestyle Centres, Ayurveda, Naturopathy & Traditional Healing, Ayush Centres

Education - Uttarakhand is a hub for premier schools, There is an opportunity to build upon this legacy
and attract K-12 & Higher education institutes of repute to the State - both national and international.
New locations can be explored to set up such education zones.

o Drivers: Strong thriving ecosystem of schools and universities in Dehradun, Mussoorie and
Nainital

o Target: Higher Education institutes & K-12 schools
tv.

Film, Media & Entertainment - ln order to promote film shooting, Uttarakhand has instituted a Film
Policy. The Film Policy is majorly focussed towards promoting film shooting in the State. There is a need
to further capitalize on Uttarakhand's advantage by incentivizing production studios and film cities, This
would exponentially increase economii contribution from film and media in the State. Additionally, the
State would like to promote entertainment avenues in the State targeted at locals and tourists.

o Drivers: Unique backdrops and location, good accessibility, cool climate for outdoor shooting
in summer months, growing film, and OTT media

o Target: Film city, Post-production and Animation Studios, Family Entertainment Centres (FECs)
like Amusement and Water Parks, etc.

Sports - Uttarakhand possesses the right ingredients to promote professional adventure sports and

emerge as an international hub for training in such sports. lt already has training institutes in
mountaineering, and skiing. There is need to establish professional academies, attract world-class
trainers and provide best equipment & facilities in these sports.
Target: Mountaineering, Water-based sports (Kayaking, RaftinE, Canoeing), Winter sports

o

(Skiing; Snowboarding, lce skating), Shooting, Badminton and Boxing.

o Drivers: Uttarakhand has the best accessibility for the target sports. lt already has significant
footfalls of amateurs / semi-professionals in these sports.

<!-- page 6 -->

.
vi.

lT

UttarakhandServiceSectorPolicy-2024

/ tTeS - Uttarakhand already has an lT Policy, geared towards promoting establishment of smaller lT

units in the State. However, for accelerating the ecosystem development, there is a need to attract
large lT players in the State.

o Drivers: Uttarakhand benefits from good connectivity, large talent pool in North lndia, and
most importantly excellent climate and landscape.

, o Target Concepts: Anchor lT Offices, Large format Training Campuses, GCCS

vii.

Data Centre - lndia is expected to witness exponential growth in Data Centre capacity, driven by
increase in digital consumption, 5G rollout, clouds systems, emerging technologies in Artificial
lntelligence, automation, etc. Uttarakhand is aptly positioned to capture a sizeable share of investment
activity projected in the sector.

o Drivers: Uttarakhand provides cool climate (which lowers energy consumption towards
o

cooling in data centres) and abundant green power capacity
Target Concepts: Large format Data Parks, smaller Data Units

viii. Skilling - Skill development is crucial for Uttarakhand's growth. Encouraging the establishment of
Centres of Excellence (CoEs)will drive specialized education, fostering expertise in sectors like AYUSH,

Food Processing, Tourism, etc. This initiative promises to uplift the State's economy and ensure a
sustainable future.

b. Bring-in Reputed Private Players
Uttarakhand is poised to kick-start investments in Focus Service Sectors by attracting large projects / major
players to act as anchors and drive the overall ecosystem. This strategy would best showcase the benefits
Uttarakhand has to offei, build Uttarakhand's reputation, and attract further investments.

c. Boost Local Employment
Government acknowledges that the projects being incentivized through this Policy, should generate
employment opportunities for local population, as well as create avenues to impart training skills to improve
employability, This Policy aims to establish mechanisms to facilitate local employment, ensure balanced
development and improve quality of life for local citizens.

<!-- page 7 -->

L

I

Utta rakha nd Service Sector P olicy -2024

l

4 VtstoN, Mrssrolrt & Oglecnvrs
Vision Statement

"To leverage growth in the Seruices sector to fuel the next phase of Uttorokhond's economic growth,
leveraging the Stote's many natural advontoges".
Mission

a. Capitalize on Uttarakhand's innate advantages in Focus Service Sectors and establish it as a premier hub by
attracting major national / international private sector players,

b. Facilitate investments in Uttarakhand by creating investor-friendly infrastructure, tackling sector-specific
issues, and offering tailored incentives as per sector needs.

c. Capitalize on large projects to kick-start ecosystem creation, provide training and incentives to drive
employability of local population and accelerate service economy growth in Uttarakhand.
Objectives
The Government of Uttarakhand wants to promote the development of Focus Service Sectors in the State,
subject to environmental safety and sustainability considerations. ln this context, the Government would
actively encourage the development of economic hubs dedicated to the Focus Service Sectors, provide support
for setting up and growing the same, and developing the necessary talent pool.
ln this context, the objectives of the Policy are as below:

a. To facilitate private sector investments into Focus Service Sectors in the State.
b. To support development of new Focus Services Sector hubs that would act as seeds for urban development
in the state.

c. To create state-of-art sustainable infrastructure for the new service sector/ economic hubs.
d. To promote inclusive service sector growth and ensure equitable distribution of benefits to local
communities.

e. To diversifo and accelerate Uttarakhand's economic gro.wth, by pursuing avenues in multiple services sectors.

f. To promote balanced regional development by facilitating investments in underdeveloped areas.

g. To build institutional capacity and high-value productive employment opportunities in Focus Service Sectors.
h. To ease clearances in Focus Service Sectors and to create an enabling business environment facilitated by a
single window system.

<!-- page 8 -->

Uttarakhand Service Sector Policy-2024

5 Vnuotrv oF PoucY
This Policy shall remain in effect till Dec 31't, 2030, or until superseded by a new policy. The Government of
Uttarakhand may extend or reduce the period of this Policy as and when required'
lncentives under this Policy shall only be applicable for projects mentioned in the Section 6 of the Policy, which
apply for and achieve ln Principle Approval through a Single Window Clearance after the notification of this
policy and within its validity period. Projects which are already under construction or ready for grounding after
having secured all statutory clearances and permission at the time of Policy notification shall not be applicable

for benefits under the Policy.
Note: Any incentives identified for Focus Services Sectois under Uttorokiand's MSME Policy (2075), Mego
tndustridl and lnvestment Policy (2027), Stort Up Policy (2078), tT Policy (2078), Film Policy (2079), Tourism Policy
(2023) or other policies of the Government of lJttarakhond sholl continue to be opplicoble. ln case of ony overlop

with this Policy, the beneficiory shalt be free to choose incentives under any one of the applicable policies.

<!-- page 9 -->

Uttarakhand Service Sector Policy-2024

6 Elrersr-rrY

BY Focus Secron

Eligibility

Focus Sector
1)

Multi-speciality Hospital

a) Plain Areas - Projects with investments in ECA greater than INR 200 Cr in 5 years
b) Hill Areas - Projects with investments in ECA greater than INR 50 Cr in 5 years
Healthcare
2l

Single super-speciality Hospital

a) Plain Areas - Projects with investments in ECA greater than INR 50 Cr in 5 years
b) Hill Areas - Projects with investments in ECA greater than INR 25 Cr in 5 years
1) Eligible NIC Codes
a) 55101 - Hotels / Motels, Tourist Resorts, Heritage Hotels
b) 82300 - MICE or convention centres
Hospitality

2l Eligible Projects
a) Plain Areas - Projects with investments in ECA greater than INR 200 Cr in 5 years

b) .Hilly Areas - Projects with investments in ECA greater than INR 100 Cr in 5 years

.

Hospitolity projects, which get incentive under this Policy sholl not be eligible for Capitol
Subsidy under Uttqrokhond Tourism Policy 2023. However, such projects may ovail oll other
subsidies / incentives os opplicoble under the lJttarakhand Tourism Policy 2023,

1) Eliglble NIC Codes
a) NIC Code 86901 -Yoga, Ayurveda and Naturopathy, OR
b) Other Ayush Practices - Naturopathy, Unani, Reiki, Homeopathy or any other
traditional medicine or a combination thereof, OR

Wellness and Traditional

c) NIC Code 87200 - Residential Healthcare for detoxification, rehabilitation, OR
d) Nlc code 86100 - Sanatorium

) Ayurveda /
Yoga / Naturopathy /
Medicine

Holistic Healing Centres

2l Eligible Projects
a) Plain Areas - Projects with investments in ECA greater than INR 50 Cr in 5 years
b) Hilly Areas - Projects with investments in ECA greater than INR 25 Cr in 5 years
1)

K-12 school

College / University

K-12 Schools

a) Plain Areas - Projects with investments in ECA greater than INR 50 Cr in 5 years
b) Hill Areas - Projects with investments in ECA greater than INR 25 Cr in 5 years
1) College / University
a) Plain Areas - Projects with investments in ECA greater than INR 100 Cr in 5 years
b) Hill Areas - Projects with investments in ECA greater than INR 50 Cr in 5 years
Note: Only institutes with 1st year student intake capacity of minimum 500 students shall be
eligible for incentlves under this Policy

1) Film city, Post-production and Animation Studios, Family Entertainment Centres (FECs)
like Amusement and Water Parks, etc.
Film, Media &

Entertainment

a) Plain Areas - Film, media, and entertainment sector projects with investments in
ECA greater than INR 100 Cr within 5 years

b) Hill Areas - Film, media, and entertainment sector Brojects With investments in ECA
greater than INR 50 Cr within 5 years

1) Sports facilities and training infrastructure (sports academies, etc.)
a) Plain Areas - Sports facilities & training infrastructure with investments in ECA
Sports

greater than INR 25 Cr within 5 years

b) Hill Areas - Sports facilities & training infrastructure with investments in ECA greater
than INR 15 Cr within 5 years
lT / lTeS

1) lT Campuses & GCCs

W

9

<!-- page 10 -->

Uttarakhand Service Sector Policy-2024

Eligibility

Focus Sector
a)

b)

Data Centres

Plain Areas - lT Campuses & GCCs with investments in ECA greater than INR 100 Cr
within 5 years and minimum permanent direct employment of 1,000 personnel
Hill Areas - lT Campuses & GCCs with investments in ECA greater than INR 50 Cr
within 5 years and minimum permanent direct employment of 500 personnel

1) Data Centres
a) Plain Areas - Data Centres with investments in ECA greater than INR 100 Cr in 5
years

b) Hill Areas - Data Centres with investments in ECA greater than INR 50 Cr in 5 years

Skilling

1) Eligible Units - Centres of Excellence (CoEs) established in the following sectors:
a) AdvancedManufacturing
b) AYUSH
c) Construction
d) Drones
e) Electronics
f) Food Processing
C) Handicrafts
h) Healthcare
i) Horticulture: Fruits, Vegetables, Herbs, Flowers
j) Hospitality
2) Eligible Projects
a) Plain Areas - Projects with investments in ECA greater than INR 1OO Cr within 5
yea rs

b) Hill Areas - Projects with investments in ECA greater than INR 50 Cr within 5 years
a. The maximum investment to be considered for calculation of Capital Subsidy under this Policy shall be
capped at 3 (three) times the minimum / threshold sector-wise investment in ECA defined in the table above;

subject to a maximum Capital Subsidy of INR 100 Cr per project.

b. TotalCapitalSubsidyincentive.underthePolicyshallbecappedatlNR2,500Crforthedurationofthepolicy.
c. Annual In-Principle Subsidy Approved, i.e., total subsidy amount to be disbursed for projects approved within
a specific year under the Policy, shall be subject to the following limits:

Financial Year

Annual ln-Principle Subsidy Amount
(tNR Cr)

FY25

250

FY26

500

FY27

500

FY2B

500

FY29

250

FY3O

250

FY3 1

250

d. The subsidy approval for each year shall be done on a first come first serve basis i.e., projects applying first

for in-principle approval under the Policy shall be given preference, subject to the annual approval limits.
ln case a project falls outside the annual subsidy approval limit for a given year, it shall be waitlisted for the
next year.

f. Subsidy payments shall be made as per pre-determined payment schedules defined under Section 7 of the
Policy

g. ltwill beresponsibilityoftheDepartmenttosanctiontheprojectsandspacedisbursal ofthesubsidywithin
the given limits. Any deviations from the limits will be permitted after approval from the State Level
Empowered Committee (SLEC), formed under the Uttarakhand Enterprises Single Window Facllitation and
Clearance Acl 201,2.

@-

10

<!-- page 11 -->

Uttarakhand Service Sector P olicy-2O2[

h. Any deviations from the limits of INR 2500 cr for the duration of policy, will be permitted after approval of
i.

State Government with due procedure.
The overall subsidy capping and Annual ln-Principle Subsidy Approval limits may be modified in future

depending on the response to the Policy and the powers to make such modifications shall be vested in the
State Government.
t.

The Capital subsidy incentive under the Policy shall be applicable to state Government land only if such land
is allotted through competitive bidding process leading to the determination of prevalent market value

of

the land. ln case State Government Iand is allotted through another process, the provision of Capitalsubsidy
shall be considered by the State Government with reference to the State's Land Allocation policy to be

formulated in future.

L1.

<!-- page 12 -->

Uttarakhand Service Sector Policy-2024

7

INCENTIVES UNDER THE PotIcY

Eligible Projects, fulfilling eligibility conditions laid down in various sectors, shall be eligible for Capital Subsidy
as below:

a. The investor shall be eligible for, and can avail, Capital Subsidy equivalent to 25% of lnvestment in Eligible
Capital Assets in 5 years.

b. The lnvestor shall be given an option to choose amongst 2 Capital Subsidy options detailed below.

c. Option 1: lnvestment milestones linked Capital Subsidy during construction phase - The Capital Subsidy
amount shall be paid by the Government in equal instalments subject to fulfilment of following milestones.
lnstalment 1- completion of 20Yo of Proposed lnvestment (Committed)
lnstalment 2 - completion of 40% of Proposed lnvestment (Committed)
lll. lnstalment 3 - completion of 50% of Proposed lnvestment (Committed)
lV. lnstalment 4 - completion of 80% of Proposed lnvestment (Committed)
V. The last instalment (lnstalment 5) shall be due and payable only when the investor attains / achieves
COD and has completed lOO% of the Proposed lnvestment (Committed) in Eligible Capital Assets,
both within 5 years. For claiming COD, the investor should ensure that all approvals are in place for
commencement of commercial operations of the project.

l.
ll.

i.

lf at the end of 5 years, the Actual lnvestment in Eligible Capital Assets is less than Proposed
lnvestment (Committed) in Eligible Capital Assets, but still higher than the sectoral threshold
(see section 6) and COD has been achieved, the investor would be eligible for proportionately
lower capital subsidy and the last instalment would be suitably adjusted. ln case excess subsidy
has been given in the first 4 instalments, the investor would be required to refund the excess

ii.

capital subsidy received till date with interest at RBI Repo Bate + 4% per annum from date of
release. Failure to do so within 2 months post completion of S-year period would result in
performance security (Bank Guarantee) encashment.
lf at the end of 5 years, the Actual lnvestment in Eligible Capital Assets is equal to or more than
the Proposed lnvestment (Committed) in Eligible Capital Assets, but COD has not been achieved,
the Department / Authority would be empowered to determine whether extension for achieving
COD can be granted or not. ln case the Department / Authority does not grant extension, the

iii.

investor would be required to refund any capital subsidy received till date with interest of RBI
Repo Rate + 4%" per annum from dates of release of subsidy instalments.

lf at the end of 5 years, the actual lnvestment in Eligible Capital Assets is less than Proposed
lnvestment (Committed) in Eligible CapitalAssets and is also lower than the sectoral threshold
(see section 6), the investor would be required to refund any capital subsidy received till date

with interest at RBI Repo Rate + 4% per annum from dates of release. Failure to do so within
2 months post completion of 5-year period would result in performance security encashment.

iv.

Performance security (Bank Guarantee) would be submitted by the investor for release of
lnstalments 1-4. Such securities would be valid for 3 months beyond the completion of 100%
of the Proposed lnvestment (Committed). The performance security shall be a guarantee that
Proposed lnvestment (Committed) in Eligible Capital Assets is achieved within 5 years.

d. Option 2: Payment of Capital Subsidy post completion of investment and attainment of COD - The Capital
Subsidy amount shall be paid by the Government in equal annual instalments as detailed below. Subsidy

under this option shall be calculated basis Actual lnvestment made by the investor during the 5-year period
post in-principle approval. No subsidy shall be payable in case the Actual lnvestment is less than the sector
wise minimum / threshold investments defined under section 6 of the Policy.
lnstalment 1 - One-third (L/3'd) of total Capital Subsidy at the end of financial year in which the
eligible project completes investment and attains COD.
lnstalment 2 and 3 - One-third (1/3'd) of total Capital Subsidy each at the end of subsequent two
financial years

L

ll.

i.

For claiming COD, the investor should ensure that all approvals are in place for
commencement of commercial operations of the project.

@--

1.2

<!-- page 13 -->

Uttarakhand Service Sector Policy-2024

ii.

No Performance security (Bank Guarantee) shall be required if the lnvestor chooses payment

of Capltal Subsidy under this option.
Note, under the Policy the quantum ofsubsidy shall be computed on
Proposed lnvestment (Committed), subject to maximum investment capping defined in Section 6, for

l.

projects availing Option 1.

ll. Actual lnvestment, subject to maximum investment capping defined in Section 6, for projects availing
Option 2,
f.

All lnvestment Commitments in ECA are to be made within 5 years from the date of in-principle approval
under Uttarakhand Enterprises Single Window Facilitation and Clearance Acl 2072.
Projects availing the benefits under this Policy should ensure implementation of Uttarakhand Employment
GO.

h.

lncentives under this Policy shall be applicable on private land and Government land leased to private
i

nvestors.

The State Government and Department of Planning, acting through Uttarakhand lnvestment and
lnfrastructure Development Board (UllDB) or any other proficient Department or Authority, shall from time

to time invite private investors through tendering or auctioning of Government owned land parcels. This
shall be done with the aim to promote private sector participation under this Policy and facilitate the
establishment of specific service sector developments.
lf the annual instalments of Capital Subsidy are delayed beyond 40 days from the date of completion of all
documents of formalities, the Government would pay an interest of RBI Repo Rate on the delayed amount
and also fixed the responsibility and take necessary action for such delay. Detailed Capital Subsidy claims
process shall be notified as part of Policy guidelines.
k.

Projects availing subsidy under the Policy shall have to remain operational for a minimum of 25 years post
COD. lf operations are curtailed before the stipulated 25-year period, the investor will be obligated to

reimburse the proportional subsidy, calculated based on the remaining number of years of mandated
operations divided by 25, with an applicable interest rate of RBI Repo Rate + 4% per annum from the dates
of subsidy release. Where the beneficiary of subsidy fails to repay the subsidy as provisioned in this section,
it will be treated as recoverable as an arrear of land revenue under the Revenue Recovery Act 1890 and
recovered accordi ngly.

13

<!-- page 14 -->

Uttarakhand Service Sector Policy-2024

8

IrupurrurrurnnoN oF Polrcy

Uttarakhand lnvestment and lnfrastructure Development Board, Government of Uttarakhand shall be the
implementation and administrative agency for this Policy. Department of Planning and UIIDB shall formulate
guidelines and institute requisite frameworks for effective implementation of projects & schemes under the
Uttarakhand Service Sector Policy.

lmplementation Mechanism
The Policy shall utilize key institutions already formed under the Uttarakhand Enterprises Single Window
Facilitation and Clearance Act20t2 for approval and disbursements under this Policy,
a. Any investor who wishes to avail incentives and subsidies under this Policy must get the project registered
and simultaneously apply for ln-Principle Approval on the Single Window Clearance System
( https://i nvestutta ra kha nd. u k.gov. i n/)
b. Further, the Policy will use existing District Level Empowered Comrnittee (DLEC), formed under the
Uttaral<hand Enterprises Single Window Facilitation and Clearance Act 2012, for in-principle approval of
MSME projects AND State Level Empowered Committee (SLEC), formed under the Uttarakhand Enterprises
Single Window Facilitation and Clearance Act2012, for in-principle approval of non-MSME projects.
c. The Claim for subsidy shall also be made on the Single Window platform. Mechanism for approval of claims
and grant / disbursement of subsidy shall be notified as part of Policy Guidelines.
Ease of Doing Business and Single Window Clearances

The Policy will benefit from the strategic interventions that State Government has enacted aimed at improving

the business environment.

a. Access to lnformation and Transparency Enablers: The State has done a comprehensive cornpilation of 329
investor-related services across 55 departments on its single window portal. Further, the Governmerrt l-ras
also irrtroduced a help line to address the irrvestor related queries.

b. Environment Registration Enablers: A comprehensive list of procedures and all documents required for
application are available on UEPPCB's website. The Government has also fixed a timeline for approval /
rejection of applications.
c. Single Window: The Single Window Clearance System (SWCS) was formed under "The Uttarakhand
Enterprises Single Window Facilitation and Clearance Acl 20L2" (Uttarakhand Act No. 05 of 2013) to provide
all the requisite clearances / licenses,/ permits etc. required to establish / operate industrial and other urrits.

All necessary clearances shall be accorded to the investor in a time bound manner after the submission of
requisite documents through the Single Window System.
Grievance Redressal related to lmplementation of this Policy
The State Government reserves the right to:

a. Update the list of Focus Services Sectors as it sees fit, at any point during the Policy period.
b. Amend any provision(s) including amendment or withdrawal of any of the incentives and subsidies, as and
when necessary, under the provision of the Policy.

c. Review the matters regarding sanction / disbursement of support to eligible projects Lrnder this Policy.
d. Make / amend the necessary guidelines for implementation of this Policy.
e. ln case of any conflicts, the SLEC may take a decislon in accordance with the prevailing policy / guidelines
and the decision thus taken shall be final and binding on all concerned and its compliance shall be mandatory
for the concerned department / parties.

t4

<!-- page 15 -->

Uttarakhand Service Sector Policy

Drrrrurrtorus

a. Eligible Capital Assets
"Eligible Capital Assets" or "ECA" shall mean and include site-level infrastructure (fencing, construction of
internal roads, and other basic infrastructure facilities); structures & buildings; plants, machinery & equipment,

handling equipment; mechanical, electrical & plumbing installations, fixtures, furniture & fittings; utilities
including waste treatment facilities, transformers, generators, etc., and other support facilities installed for use
in the premises including any installation charges.
ECA shall not include:

e Land
o lntangible assets including, without limitation, lntellectual Property rights and goodwill.

All capital assets should have been paid for and should be owned by the project / investor.

All capital assets should be used and installed only within the Project Site. Eligible investment in ECA shall not
include:

o Pre-construction expenses and cost of consultant
o Capitalized interest
o Working capital
ln case of Expansion projects, the ECA shall be counted only for the expansion component, as per the calculation

outlined above.
b. CoD means the commencement of services rendered / commencement of operation on a commercial scale.

Hill and Plain Regions Definition

Categcry
Hilly
areas

Plain

areas

Area / regions coyared

o Entire area under districts Pithoragarh, Uttarkashi, chamoli, champawat, Rudraprayag,
Bageshwar, Almora, Pauri Garhwal, Tehri Garhwal.

. Areas lying above 800 m from mean sea level in districts Nainital and Dehradun
o Areas lying under 800 m from mean sea level in districts Dehradun and Nainital
o Entire area under districts Haridwar and Udham Singh Nagar

Uttarakhand Employment GO in this document shall mean GO no. 367 / lD / Employment / 2005-06 dated
25 october 2005 and Go no. 429 / lD / Employment / 2005-06 dated 19 November 2005.
Proposed lnvestment (Committed) means the investment amount declared by the investor at the time of
applying for subsidy, to be undertaken for development of ECA for the Eligible Project within 5 years from

the date of in-principle approval under Uttarakhand Enterprises Single Window Facilitation and Clearance
Acl 2Q72.

f. Actual lnvestment means the actual investment made by the investor for development of ECA for the Eligible
Project within 5 years from the date of in-principle approval under Uttarakhand Enterpriqeg Single Window
Facilitation and Clearance Act 2012.

W

(R.Meenaks.

Sundaram)

15
