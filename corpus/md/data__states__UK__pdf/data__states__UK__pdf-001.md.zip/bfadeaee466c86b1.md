---
doc_id: "bfadeaee466c86b1"
source_url: "https://cdnbbsr.s3waas.gov.in/s3c154e8f56c74b3be3008da9bd19d08fc/uploads/2025/07/20250725225390452.pdf"
ministry: "Medical Health and Family Welfare Department, Uttarakhand"
title: "Notification for Surrogacy Rules 2022 (1 MB)"
date: ""
pages: 22
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "524d4259d0053112"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99

REGD. No. D. L.-33004/99

सी.जी.-डी.एल.-अ.-21062022-236719
xxxGIDHxxx
CG-DL-E-21062022-236719
xxxGIDExxx
असाधारण
EXTRAORDINARY
भाग II—खण्ड 3—उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राजधकार से प्रकाजित
PUBLISHED BY AUTHORITY
सं. 439]
No. 439]

नई दिल्ली, मंगलवार, िून 21, 2022/ज्येष्ठ 31, 1944
NEW DELHI, TUESDAY, JUNE 21, 2022/JYAISHTHA 31, 1944

स्ट्वास्ट््य और पररवार कल्याण मंत्रालय
(स्ट्वास्ट््य अनुसंधान जवभाग)
अजधसूचना
नई दिल्ली, 21 िून 2022
सा.का.जन. 460(अ).—कें द्रीय सरकार सरोगेसी (जवजनयमन) अजधजनयम 2021 (2021 का 47) की धारा 50
द्वारा प्रित्त िजियों का प्रयोग करते हुए, जनम्नजलजखत जनयम बनाती है, अर्ाात्:-

1.

संजिप्त नाम और प्रारं भ- (1) इन जनयमों का संजिप्त नाम सरोगेसी (जवजनयमन) जनयम, 2022 है। (2) ये
रािपत्र में अपने प्रकािन की तारीख से लागू होंगे।

(2)

पररभाषाएं -इन जनयमों में, िब तक दक संिभा से अन्यर्ा अपेजित न हो(क)

'अजधजनयम' से सरोगेसी (जवजनयमन) अजधजनयम, 2021 (2021 का 47) अजभप्रेत है;

(ख)

"प्ररूप" से इन जनयमों के सार् संलग्न प्ररूप अजभप्रेत है;

(ग)

'धारा' से अजधजनयम की धारा अजभप्रेत है;

(घ)

उन िब्िों और पिों के , िो इसमे प्रयुि हैं और पररभाजषत नहीं हैं दकन्तु अजधजनयम में पररभाजषत
हैं, वही अर्ा होंगे िो उस अजधजनयम में हैं।

(3)

रजिस्ट्री सरोगेसी जललजनक में जनयोजित व्यजियों के जलए आवश्यकताएं और अहाताएं - सरोगेसी जललजनक के
जलए कमाचाररयों की न्यूनतम अपेिा और उनकी अहाता अनुसूची I, भाग-1 में यर्ा जनर्िाष्ट होगी।

(2)

सरोगेसी जललजनक के जलए उपकरणों की न्यूनतम अपेिा अनुसूची I, भाग 2 में यर्ा जनर्िाष्ट होगी।

4150 GI/2022

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(4)

बोडा के जसफ़ाररि के प्रमाण पत्र प्राप्त करने के जलए आवेिन की रीजत प्ररूप 1 में यर्ा जवजनर्िाष्ट होगा।

(5)

बीमा कवरे ि.- (1) आिजयत मजहला या िंपजत एक बीमा कं पनी से या बीमा जनयामक और जवकास प्राजधकरण
अजधजनयम, (1999 का 41) के उपबंधों के अधीन स्ट्र्ाजपत बीमा जनयामक और जवकास प्राजधकरण द्वारा मान्यता
प्राप्त दकसी अजभकताा से छत्तीस महीने की अवजध के जलए सरोगेट माता के पि में, उतनी राजि िो गभाावस्ट्र्ा से
उत्पन्न होने वाली सभी िरटलताओं के जलए सभी खचों को कवर करने के जलए पयााप्त है और प्रसवोत्तर िरटलताओं
को भी कवर करती है, का एक सामान्य स्ट्वास्ट््य बीमा कवरे ि खरीिेंगे।
(2) आिजयत िंपजत्त/मजहला सरोगेसी (जवजनयमन) अजधजनयम, (2021 का 47) की धारा 2 की उप धारा (1) के खंड
(र्) के अनुसार गारं टी िेते हुए मेरोपॉजलटन मजिस्ट्रेट या प्रर्म श्रेणी के न्याजयक मजिस्ट्रेट के समि िपर् पत्र पर
हस्ट्तािर करें गे।

(6)

सरोगेसी प्रदियाओं के प्रयासों की संख्या- सरोगेट माता पर दकसी भी सरोगेसी प्रदिया के प्रयासों की संख्या तीन
बार से अजधक नहीं होगी।

(7)

सरोगेट माता की सहमजत- सरोगेट माता के सहमजत प्ररूप 2 में यर्ा जनर्िाष्ट होगी।

(8)

सरोगेट माता के गभाािय में आरोजपत दकए िाने वाले भ्रूणों की संख्या -स्त्री रोग जविेषज्ञ उपचार चि के िौरान
एक सरोगेट माता के गभाािय में एक भ्रूण को स्ट्र्ानांतररत करें गी।
परं तु के वल जविेष पररजस्ट्र्जतयों में ही तीन भ्रूणों को स्ट्र्ानांतररत दकया िा सकता है

(9)

वे ितें जिनके अधीन सरोगेसी की प्रदिया के िौरान सरोगेट माता को गभापात की अनुमजत िी िा सकती हैं सरोगेट माता को गभा का जचदकत्सकीय समापन अजधजनयम, 1971 (1971 का 34) के अनुसार सरोगेसी की
प्रदिया के िौरान गभापात की अनुमजत िी िा सकती है।

(10)

सरोगेसी जललजनक के जलए रजिस्ट्री और िुल्क के जलए प्ररूप और रीजत –(1) रजिस्ट्री के जलए एक आवेिन
उन सरोगेसी ललीजनक द्वारा प्ररूप 3 में उपयुि प्राजधकारी को दकया िाएगा िो अजधजनयम में पररभाजषत
सरोगेसी से संबंजधत प्रदियाओं को कर रहे हैं।
(2) रजिस्ट्री के जलए प्रत्येक आवेिन के सार् सरोगेसी जललजनक के जलए िो लाख रुपये का आवेिन िुल्क िेना
होगा।एक बार भुगतान दकया गया आवेिन िुल्क वापस नहीं दकया िाएगा।
परं तु यदि दकसी सरोगेसी जललजनक आदि के रजिस्ट्री के जलए आवेिन उपयुि प्राजधकारी द्वारा अस्ट्वीकार कर
दिया गया है,तो आवेिक द्वारा उसी जललजनक के जलए आवेिन पुनः प्रस्ट्तुत करने पर दकसी िुल्क का भुगतान करने
की आवश्यकता नहीं होगी।
परं तु दक सरकार द्वारा संचाजलत संस्ट्र्ानों में ऐसे प्रजतष्ठान आवेिन के जलए भुगतान नहीं करें गे।

(11)

रजिस्ट्री प्रमाण पत्र की अवजध, रीजत और प्ररूप – (1) उपयुि प्राजधकारी, ऐसी िांच-पड़ताल करने के
पश्चात और स्ट्वयं का समाधान होने के पश्चात दक आवेिक ने सभी आवश्यकताओं का अनुपालन दकया है,
आवेिक को प्ररूप 4 में रजिस्ट्री का प्रमाण पत्र प्रिान करे गा।
(2) रजिस्ट्री प्रमाण पत्र की एक प्रजत रजिस्ट्री सरोगेसी जललजनक द्वारा अपने व्यवसाय के स्ट्र्ान पर एक
ध्यानाकषी स्ट्र्ान पर प्रिर्िात की िाएगी।

(12)

अपील - (1) सरोगेसी जललजनक, या आिजयत मजहला, या िंपजत्त, धारा 13 के अधीन उपयुि प्राजधकारी द्वारा
आवेिन को अस्ट्वीकार करने, जनलंबन या रजिस्ट्री रद्द करने के आिेि से संबंजधत संप्रेषण और धारा 14 के अधीन
प्रमाणपत्रों की अस्ट्वीकृ जत से संबंजधत संप्रेषण, प्राप्त होने की तारीख से तीस दिनों की अवजध के भीतरऐसे आिेि के
जवरुद्ध अपील कर सकते हैं।
(2) अपील का प्ररूप प्ररूप 5 में यर्ा जनर्िाष्ट होगा।

(13)

वह रीजत जिससे िस्ट्तावेिों, अजभलेखों, वस्ट्तुओं आदि को िब्त दकया िाएगा और िब्ती सूची तैयार की िाएगी
और िी िाएगी – (1) प्रत्येक सरोगेसी जललजनक, राष्ट्रीय बोडा या राष्ट्रीय रजिस्ट्री या राज्य बोडा या उपयुि
प्राजधकरण या इस संबंध में अजधकृ त दकसी अन्य व्यजि को स्ट्र्ान, उपकरण और ररकॉडा का जनरीिण करने की
अनुमजत िेगा।

<!-- page 3 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

3

(2) पहले से रजिस्ट्री जललजनक का ऐसा जनरीिण जबना दकसी सूचना के , जललजनक के काम के घंटों के िौरान दकया
िा सकता है।
(3) उपधारा (1) में जनर्िाष्ट अजधकारी यह सुजनजश्चत करें गे दक प्रवेि और खोि प्रदिया सुजवधा में संग्रहीत युग्मकों
या भ्रूणों को िोजखम में न डालें।
(14)

वे जचदकत्सा संकेत िो गभाकालीन सरोगेसी को आवश्यक बनाते हैं -एक मजहला सरोगेसी का जवकल्प चुन सकती है
यदि; (क)

यदि उसका गभााियअनुपजस्ट्र्त या लापता है /या वह असामान्य गभाािय वाली मजहला है (िैसे
हाइपोप्लाजस्ट्टक गभाािय/अंतगाभााियी एडहेसन्स/जर्न एंडोमेररयम/छोटा यूनी-कॉनुाएट गभाािय, टी
आकार का गभाािय) या यदि स्त्री रोग संबंधी कैं सर िैसी दकसी जचदकत्सीय जस्ट्र्जत के कारण गभाािय
को िल्य जचदकत्सा द्वारा हटा दिया िाता है।

(ख)

आिजयत माता-जपता/मजहला िो इन जवरो फर्टालाइज़ेिन/इं रासाइटोप्लाजज्मक स्ट्पमा इं िेलिन के कई
प्रयासों के बाि बार-बार गभाधारण करने में जवफल रहे हैं। (आवताक आरोपण जवफलता)।

(ग)

एक अस्ट्पष्ट जचदकत्सीय कारण से होने वाली एकाजधक गभाावस्ट्र्ा हाजन। अजतरं जित प्रजतरिा प्रजतदिया
के कारण अनएलसप्लेन्ड ग्राफ़्ट ररिेलिन।

(घ)

कोई भी बीमारी िो मजहला के जलए गभाावस्ट्र्ा को व्यवहायाता में लाना असंभव बना िेती है या ऐसी
गभाावस्ट्र्ा िो िीवन के जलए खतरा है।
[फा. सं. यू.11019/15/2022-एचआर(पीटी)]
गीता नारायण, संयुि सजचव
अनुसूची-1
भाग–1
[जनयम 3 (1) िेखें]

(1)

सरोगेसी ललीजनक का स्ट्टाफ़ - सरोगेसी ललीजनक में कम से कम एक स्त्री रोग जविेषज्ञ, एक एनेस्ट्र्ेरटस्ट्ट, एक
भ्रूणजवज्ञानी और एक परामिािाता होगा। जललजनक सहायताप्राप्त िननीय प्रौद्योजगकी स्ट्तर 2 ललीजनक द्वारा
अजतररि कमाचाररयों को जनयुि कर सकता है; साधारणतया जनिेिक, एंड्रोलॉजिस्ट्ट और ऐसे स्ट्टाफ की जनयुजि
करे गा िो जललजनक को दिन-प्रजतदिन के काम में सहायता करने के जलए आवश्यक हो।

(2)

सरोगेसी ललीजनक में डॉलटरों और अन्य कमाचाररयों की अहाता - सरोगेसी ललीजनक में स्ट्टाफ की अहाता
जनम्नानुसार होगी:
(क)

स्त्रीरोग जविेषज्ञ - स्त्री रोग जविेषज्ञ, स्त्री रोग जवज्ञान और प्रसूजत जवज्ञान में जचदकत्सा स्नातकोत्तर होंगी
और प्रसूजत और 50 ओवम जपकअप प्रदियाओं को करने का ररकॉडा होना चाजहए और एक प्रजिजित
एआरटी जविेषज्ञ की िेखरे ख में एआरटी जललजनक में कम से कम तीन वषा का काया अनुभव होना
चाजहए(इस अजधजनयम के लागू होने से पूवा एआरटी या आईवीएफ़ में पेिेवर और या एआरटी जललजनकों
में काम करने वाले स्त्री रोग जविेषज्ञों के मामले में कम से कम तीन वषा के अनुभव के सार् स्त्री रोग
जवज्ञान और प्रसूजत जवज्ञान में स्नातकोत्तर जडग्री और 50 ओवम जपकअप प्रदियाओं का अजभलेख स्ट्वीकाया
होगा); या
दकसी सहायताप्राप्त िननीय प्रौद्योजगकी जललजनक में काम करने के कम से कम तीन वषा के अनुभव के
सार् सुपर स्ट्पेिजलस्ट्ट डॉलटरे ट ऑफ़ मेजडसन/प्रिनन जचदकत्सा में फै लोजिप के सार् स्त्री रोग जवज्ञान और
प्रसूजत जवज्ञान में जचदकत्सा स्नातकोत्तर।

(ख)

एंड्रोलॉजिस्ट्ट: पुरुष बांझपन के जनिान और उपचार में जविेष प्रजििण के सार् यूरोलॉिी में राष्ट्रीय बोडा
के जचरर्िाकल या जडप्लोमेट का मास्ट्टर होगा।

(ग)

भ्रूणजवज्ञानी–(i)दकसी मान्यता प्राप्त जवश्वजवद्यालय से जललजनकल भ्रूणजवज्ञान में स्नातकोत्तर (न्यूनतम
चार सेमेस्ट्टर के सार् पूणाकाजलक कायािम के सार् स्नातक) जिसके सार् मानव युग्मकों और भ्रूणों को
संभालने में मानव एआरटी प्रयोगिाला का तीन वषा का अनुभव; या

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(ii)पीएच.डी. धारक (पूणाकाजलक पीएच.डी. पररयोिना दकसी मान्यता प्राप्त जवश्वजवद्यालय से
जललजनकल भ्रूणजवज्ञान/सहायताप्राप्त िननीय प्रोद्योजगकी/फ़र्टाजलटी) से संबंजधत होनी
चाजहए जिसके सार् मानव युग्मकों और भ्रूणों को संभालने में मानव एआरटी प्रयोगिाला
का एक वषा का अजतररि अनुभव; या
(iii) दकसी मान्यता प्राप्त जवश्वजवद्यालय या संस्ट्र्ान से जललजनकल भ्रूणजवज्ञान (पूणाकाजलक
कायािम) में स्नातकोत्तर जडग्री के सार् मेजडकल स्नातक (एमबीबीएस)या पिु जचदकत्सा स्नातक (बीवीएससी)
जिसके सार् मानव युग्मकों और भ्रूणों को संभालने में मानव एआरटी प्रयोगिाला का िो वषा का अजतररि
अनुभव; या
(iv) एक रजिस्ट्री एआरटी स्ट्तर 2 जललजनक में मानव युग्मक और भ्रूण को संभालने में चार वषा के अनुभव के
अजतररि ऑन-साइट, पूणाकाजलक जललजनकल भ्रूणजवज्ञान प्रमाजणत प्रजििण के न्यूनतम एक वषा के सार् िीवन
जवज्ञान/िैव प्रौद्योजगकी में स्नातकोत्तर।
इस अजधजनयम के लागू होने से पूवा सहायताप्राप्त िननीय प्रौद्योजगकी/इन जवरो जनषेचन जललजनक में काम
करने वाले सभीएम्ब्रायोलॉजिस्ट्टों को, नीचे उजल्लजखत अहाता और अनुभव के सार्, एक बार के उपाय के
रूप में एक भ्रूणजवज्ञानी के रूप में बने रहने की अनुमजत िी िा सकती है।तर्ाजप, इसअजधजनयम के लागू होने
के पश्चात, सभी जललजनक एक मानिंड के रूप में उपरोि दकसी भी अहाता और अनुभव वाले भ्रूणजवज्ञानी को
जनयुि करें गे।

एक रजिस्ट्री सहायताप्राप्त िननीय प्रौद्योजगकी/इन जवरो जनषेचन जललजनक में काम करने के कम से कम
पांच वषा के अनुभव के सार् िीवन जवज्ञान/िैव प्रौद्योजगकी/प्रिनन िीव जवज्ञान/पिु जचदकत्सा जवज्ञान
में स्नातक,जिसने कम से कम 500आईवीएफ़ प्रयोगिाला प्रदियाओं (आईसीएसआई सजहत और भ्रूणों के
िायोजप्रज़वेिन के कम से कम 100चि) को पूरा दकया हो।
(घ) परामिािाता: एक व्यजि िो मनोजवज्ञान/नैिाजनक मनोजवज्ञान/नर्सिंग/िीवन जवज्ञान में दकसी मान्यता
प्राप्त जवश्वजवद्यालय या संस्ट्र्ान से स्नातक है।
(ङ) एनेस्ट्र्ेरटस्ट्ट:एनेस्ट्र्ेरटस्ट्ट एनेस्ट्र्ीजसया मेंमें दकसी मान्यता प्राप्त जवश्वजवद्यालय या संस्ट्र्ान से जचदकत्सा
स्नातकोत्तर होगा।
(च) जनिेिक: जनिेिक के पास जचदकत्सा/िीवन जवज्ञान/प्रबंधन जवज्ञान में में दकसी मान्यता प्राप्त
जवश्वजवद्यालय या संस्ट्र्ान से स्नातकोत्तर जडग्री होनी चाजहए।
अनुसूची- 1
भाग–2
[जनयम 3 (2) िेखें]
1.

उपकरण: - माइिोस्ट्कोप:
(क)

इनलयूबेटर (संख्या में न्यूनतम 02);

(ख)

लैजमनर एयरफ़्लो;

(ग)

स्ट्पमा काउं टटंग़ चैम्ब्बसा;

(घ)

सेंरीफ्यूि;

(ङ)

रे दिज़रे टर;

(च)

िायोजप्रज़वेिन के जलए उपकरण;

(छ)

ओवम एजस्ट्परे िन पम्ब्प;

(ि)

रांसवेिाइनल प्रोब और नीडल गाडा के सार् यूएसिी मिीन;

(झ)

टेस्ट्ट ट्यूब वामार;

(ञ)

एनेस्ट्र्ीजसया ररसजसटैिन रॉली

<!-- page 5 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

5

प्ररूप 1
[जनयम 4 िेखें]
सरोगेसी का लाभ उठाने के जलए भारतीय मूल के िंपजत्त/आिजयत मजहला हेतु
बोडा को संबोजधत आवेिन पत्र
मैं/हम (नीचे दिए गए जववरण के अनुसार) सरोगेसी सेवाओं का लाभ उठाने के जलए जसफ़ाररि प्रमाण पत्र के जलए अनुरोध
करता हूँ/करते हैं
1.

मूलभूत िानकारी

1.1

आिजयत जपता का जववरण:

1.2

1.

नाम:

2.

उपनाम:

3.

िन्म जतजर्:

4.

रि समूह:

5.

आयु वषों में:

6.

ललंग: पुरुष/मजहला

7.

राष्ट्रीयता:

8.

व्यवसाय:

9.

वैवाजहक जस्ट्र्जत: जववाजहत/तलाक़िुिा/जवधवा।

10.

पता: (यदि उपलब्ध हो तो भारत के पते का औरजनवास के वतामान जविेि का जववरण िें)
(i)

वतामान:

(ii)

स्ट्र्ायी

11.

टेलीफोन/मोबइल नंबर (भारत और जनवास के िेि में नंबरों का जववरण)

12.

ईमेल:

13.

सोिल जसलयोररटी नंबर या समकि

14.

पासपोटा नंबर

आिजयत माता का जववरण:
1.

नाम:

2.

उपनाम:

3.

िन्म जतजर्:

4.

रि समूह:

5.

आयु वषों में:

6.

ललंग:

7.

राष्ट्रीयता:

8.

व्यवसाय:

9.

वैवाजहक जस्ट्र्जत: जववाजहत/तलाक़िुिा/जवधवा।

पुरुष

मजहला

<!-- page 6 -->

6

THE GAZETTE OF INDIA : EXTRAORDINARY

10.

[PART II—SEC. 3(i)]

पता: (यदि उपलब्ध हो तो भारत के पते का औरजनवास के वतामान जविेि का जववरण िें)
i)

वतामान:

ii) स्ट्र्ायी

1.3

11.

टेलीफोन/मोबइल नंबर (भारत और जनवास के िेि में नंबरों का जववरण)

12.

ईमेल:

13.

सोिल जसलयोररटी नंबर या समकि

14.

पासपोटा नंबर

सरोगेसी का लाभ उठाने के कारणों का संिेप में वणान करें

घोषणा
मैं घोषणा करता हं दक उपरोि कर्न मेरी सवोत्तम िानकारी और जवश्वास के अनुसार सत्य हैं।
तारीख: ……………………………

आिजयत जपता के हस्ट्तािर

स्ट्र्ान: …………………………..
आिजयत माता के हस्ट्तािर
आवेिन करने के जलए स्ट्वप्रमाजणत िस्ट्तावेि आवश्यक हैं
1.

जववाह का प्रमाण/जववाह का प्रमाण पत्र (यदि लागू हो)

2.

आयु का प्रमाण/िन्म प्रमाण पत्र/10वीं किा का प्रमाण पत्र/या कोई समकि।

(रटप्पण: अजनवायाता का प्रमाण पत्र उपयुि प्राजधकारी से प्राप्त दकया िाना है और जचदकत्सा संकेत प्रमाण पत्र जिला
जचदकत्सा बोडा से प्राप्त दकया िाना है)
प्ररूप 2
[जनयम 7 िेखें]
सरोगेट माता की सहमजत और
सरोगेसी के जलए अनुबंध
मैं,____________________________________
(मजहला),
आयु
_______वषा
(पता)
________________________________________ (आधार संख्या), मेरे स्ट्वयं के __________ (बालकों की संख्या)
हैं बालक/बालकों की आयु __________ (वषा में आयु) है, आिजयत िंपजत्त/आिजयत मजहलाओं, जिनका
नाम_________________ पजत का नाम पत्नी/ ________________ के जलए एक सरोगेट माता के रूप में काया करने के
जलए सहमत हुई हूँ। आिजयत मजहला _______आयु पजत की आयु _____ पत्नी/आिजयत मजहलाओं
ने__________________ उपरोि िंपजत्त के बालक/बालकों के जलए एक सरोगेट माता के रूप में मेरे काया करने के मामले
के संबंध में सरोगेसी जललजनक के डॉ_____________________________ के सार् _______________________को
पूरी चचाा की है।
1.

दक मैं समझती हं दक उपचार के तरीकों में जनम्नजलजखत सजम्ब्मजलत हो सकते हैं:
(क)

फॉजललयुलर ररिू इटमेंट के जलए आनुवंजिक माता की उत्तेिना;

(ख)

अल्रासाउं ड-जनिेजित ऊसाइट पुनप्रााजप्तद्वारा या लैप्रोस्ट्कोपी द्वारा आनुवंजिक माता से एक या एक से
अजधक ऊसाइट्स की पुनप्रााजप्त;

(ग)

अपने पजत के िुिाणु के सार् आनुवंजिक माता से ऊसाइट्स का जनषेचन;

<!-- page 7 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

7

(घ)

पजत के िुिाणु द्वारा एक िाता ऊसाइट का जनषेचन;

(ङ)

ऐसे जनषेचन के पररणामस्ट्वरूप भ्रूण के िायोजप्रज़वेिन द्वारा रखरखाव और भंडारण, जचदकत्सा और
वैज्ञाजनक कमाचाररयों की िृजष्ट में, िब तक यह स्ट्र्ानांतरण के जलए तैयार नहीं हो िाता;

(च)

उपरोि दकसी भी संभावना के माध्यम से प्राप्त भ्रूण का, आवश्यक उपचार के बाि यदि कोई हो, मेरे
गभाािय में आरोपण।

2.

दक मुझे आश्वासन दिया गया है दक ऊसाइट की पुनप्रााजप्त से पहले आनुवंजिक मां और आनुवंजिक जपता की
'एचआईवी' और हेपेटाइरटस 'बी' और 'सी' और अन्य यौन संचाररत बीमाररयों के जलए िांच की गई है और इन
सभी बीमाररयों के जलए सेरोजनगेरटव पाया गया है। तर्ाजप, मुझे यह भी सूजचत दकया गया है दक ‘लवंडो’ अवजध के
िौरान एचआईवी के प्रजत माता या जपता के सेरोपॉजज़रटव बनने का एक छोटा सा िोजखम है।

3.

दक मैं उपरोि प्रदियाओं और ऐसी िवाओं को दिए िाने के जलए सहमजत िेती हं िो भ्रूण स्ट्र्ानांतरण के जलए मेरे
गभाािय को तैयार करने और ल्यूरटयल चरण में सहारे के जलए आवश्यक हो सकती हैं।

4.

दक मैं समझती हं और स्ट्वीकार करती हं दक इस बात की कोई जनजश्चतता नहीं है दक इन प्रदियाओं के
पररणामस्ट्वरूप गभाावस्ट्र्ा होगी।

5.

दक मैं समझती हं और स्ट्वीकार करती हं दक जचदकत्सा और वैज्ञाजनक कमाचारी इस बात का कोई आश्वासन नहीं िे
सकते दक दकसी भी गभाावस्ट्र्ा के पररणामस्ट्वरूप एक सामान्य और िीजवत बच्चे या बच्चों का प्रसव होगा।

6.

दक मेरा िंपजत्त (भावी आनुवंजिक माता-जपता) से संबंध नहीं है या संबंध है _____________________
(संबंध)।

7.

दक मैंने िंपजत्त के सार् सरोगेसी के जचदकत्सा और अन्य खचों और ितों को जलजखत रूप में तैयार दकया है और
अनुबंध की एक उजचत रूप से प्रमाजणत प्रजत जललजनक के पास िमा की गई है, जिसे जललजनक गोपनीय
रखेगा।आिजयत िंपजत्त/मजहला सरोगेट माता के पि में एक सामान्य स्ट्वास्ट््य बीमा कवरे ि, बीमा जनयामक और
जवकास प्राजधकरण अजधजनयम, 1999 (1999 का 41) के प्रावधानों के अधीन स्ट्र्ाजपत बीमा जनयामक और
जवकास प्राजधकरण द्वारा मान्यता प्राप्त एक बीमा कं पनी या अजभकताा से खरीिा गया है।

8.

दक मैं बालक पर अपने सभी अजधकारों को त्यागने और बालक/बालकों को ___________________ को, या
आिजयत िंपजत्त के मामले में _____________ और _____________को, या मेरी गभाावस्ट्र्ा के िौरान उनके
पृर्क होने की जस्ट्र्जत में ______________________________ को, गभाावस्ट्र्ा के िौरान उनमें से दकसी एक
की मृत्यु के मामले में या उत्तरिीवी को, या िोनों की मृत्यु हो िाने के मामले में -------------------------------------- को या गारं टीकताा आिजयत िंपजत्त/मजहलाओं के मामले में ---------------------------------------को, िैसे ही
मुझे अस्ट्पताल या जललजनक या नर्सिंग होम द्वारा ऐसा करने की अनुमजत िी िाती है िहां बालक या बालकों का
िन्म होता है, सौंपने के जलए सहमत हं।

9.

दक मुझे उन सभी नाम (नामों) की जलजखत सहमजत प्रिान की गई है जिनका उल्लेख ऊपर दकया गया है।

10.

दक मैं गभाावस्ट्र्ा के पररणाम के बारे में सरोगेसी जललजनक, ______________ को सूजचत करने का वचन िेती हं।

11.

दक इसकी कोई उत्तरिाजयत्व मेरा नहीं है दक मेरे द्वारा िन्म दिया गया/गए बालक या बालकों हर तरह से
सामान्य होंगे। मैं समझती हूँ दक बालक/बालकों के िैजवक माता-जपता(ओं) का मेरे द्वारा िन्म दिए गए बालक या
बालकों को स्ट्वीकार करने का जवजधक िाजयत्व है और यह दक वतामान जवजध के अनुसार िैजवक माता-जपता के
बालक या बालकों के सभी उत्तराजधकार अजधकार बालक या बालकों के पास होंगे।

12.

दक मुझे गभाावस्ट्र्ा के िौरान बालक/बालकों के ललंग जनधाारण परीिणों करवाने के जलए नहीं कहा िाएगा और
मुझे इस तरह के परीिणों को मना करने का पूरा अजधकार है।

13.

दक मैं समझती हूँ दक गभा का जचदकत्सकीय समापन अजधजनयम 1971 (1971 का 34) के उपबंधों के अधीन
डॉलटरों द्वारा बतायी गई दकसी भी िरटलता के मामले में मुझे गभाावस्ट्र्ा को समाप्त करने का अजधकार होगा।

14.

मैं प्रमाजणत करती हं दक मैंने पहले सरोगेसी के माध्यम से कोई बालक पैिा नहीं दकया है।

15.

दक मेरा 'एचआईवी', हेपेटाइरटस 'बी' और 'सी' के जलए परीिण दकया गया है और भ्रूण स्ट्र्ानांतरण से ठीक पहले
इन वायरस के जलए सेरोजनगेरटव दिखाया गया है।

<!-- page 8 -->

8

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

16.

दक मैं एक बार चि की तैयारी िुरू होने के बाि दकसी भी प्रकार का संभोग नहीं करूंगी।

17.

दक मैं प्रमाजणत करती हूँ दक (क) मुझे दकसी साझा जसटरं ि द्वारा जिरा के माध्यम से कोई िवा नहीं िी गई है; (ख)
मैंने जपछले छह महीनों में रि रान्सफ्यूिन नहीं दकया है।

18.

दक मैं यह भी घोषणा करती हूँ दक मैं जिरा के माध्यम से दकसी िवा का उपयोग नहीं करूंगी, या जचदकत्सीय
सलाह पर प्रमाजणत रि बैंक के माध्यम से प्राप्त रि को छोड़कर रि रान्सफ्यूिन नहीं कराऊंगी।

19.

दक मैं सरोगेसी चाहने वाले पि की पहचान का खुलासा न करने का वचन िेती हं।

20.

दक सरोगेट माता के रूप में मेरी मिि मांगने वाले पि की मृत्यु या अनुपलब्धता के मामले में, मैं इस िम में
बालक/बालकों को ______________________________ या ____________________________ तक
पहुंचाऊंगी; मुझे भ्रूण हस्ट्तांतरण से पहले, उपरोि व्यजियों का एक जलजखत अनुबंध प्रिान दकया िाएगा दक वे
उपरोि संभाव्यता के मामले में बालक या बालकों को स्ट्वीकार करने के जलए जवजधक रूप से बाध्य होंगे। (यदि
लागू हो)

(यदि लागू न हो तो काट िें)
सरोगेसी जललजनक द्वारा पृष्ठांकन
मैंने/हमने व्यजिगत रूप से _____________________ और ______________ को इस सहमजत/अनुमोिन प्ररूप के
जववरण और उस पर उनके हस्ट्तािर करने के जनजहतार्ा के बारे में बताया है, और मानवीय रूप से यर्ासंभव सुजनजश्चत
दकया है दक वह/वे इन जववरणों और जनजहतार्ों को समझ िाएं।
हस्ट्तािर दकए:
(सरोगेट माता)
आिजयत िंपजत्त/मजहला के हस्ट्तािर

सरोगेसी जललजनक से सािी का
नाम, पता और हस्ट्तािर
डॉलटर का नाम और हस्ट्तािर
सरोगेसी जललजनक का नाम और पता
तारीख:
प्ररूप 3
[जनयम 10 िेखें]
आवेिन पत्र
सरोगेसी जललजनक का रजिस्ट्री
सरोगेसी जललजनक का नाम:
सरोगेसी जललजनक का पता:
राज्य: _________________ िहर: ___________________ जपन कोड:
टेलीफ़ोन नम्ब्बर (एसटीडी कोड के सार्) (के वल सरोगेसी जललजनक):
सरोगेसी जललजनक का मोबाइल नंबर
ईमेल (सरोगेसी जललजनक):
वेबसाइट यदि कोई हो

<!-- page 9 -->

[भाग II—खण्ड 3(i)]

1.

भारत का रािपत्र : असाधारण

9

आपके सरोगेसी जललजनक की जस्ट्र्जत:
1. सरकारी

2. जनिी

कोई अन्य, कृ पया स्ट्पष्ट करें ………………………………………………………

2.

आपके सरोगेसी जललजनक की स्ट्र्ापना की तारीख:

3.

लया आपका सरोगेसी जललजनक जनम्नजलजखत अजधजनयमों/प्राजधकाररयों के अधीन रजिस्ट्री है (कृ पया जववरण प्रिान
करें ) हाूँ/नहीं
1. गभा का जचदकत्सकीय समापन अजधजनयम 1971 (1971 का 44)
2. गभाधारण पूवा और जनिान-तकनीक (ललंग चयन प्रजतबंध) अजधजनयम, 1994 (1994 का 57)

4.

लया आपके सरोगेसी जललजनक में जनिेिक हैं
(1. हाूँ

2. नहीं)

क) नाम
ख) अहाता
ग) रजिस्ट्री संख्या यदि लागू हो

5.

स्ट्टाफ का जववरण
पि

नाम

अहाता

रजिस्ट्री संख्या यदि लागू हो

स्त्रीरोग जविेषज्ञ
एनेस्ट्र्ेरटस्ट्ट
जललजनकल भ्रूणजवज्ञानी
एंड्रोलॉजिस्ट्ट
परामिािाता

6.

उपकरणों की सूची

7.

बताएं दक आपके सरोगेसी जललजनक में जनम्नजलजखत में से कौन सी प्रदियाएं जनयजमत रूप से की िा रही हैं
(1. हाूँ

2. नहीं)

(क)

पजत के वीया का उपयोग करके अंतगाभााियी वीयासेचन (आईयूआई-एच)

(ख)

िाता के वीया का उपयोग करके अंतगाभााियी वीयासेचन (आईयूआई-डी)

(ग)

इन जवरो फर्टालाइज़ेिन-एम्ब्रायो स्ट्र्ानांतरण (आईवीएफ-ईटी)

(घ)

इं रा-साइटोप्लाजममक स्ट्पमा इं िेलिन (आईसीएसआई)

(ङ)

वीया का प्रसंस्ट्करण

(च)

रोगी के युग्मकों (िुिाणु और ऊसाइट) और या भ्रूण का भंडारण

(छ)

पूवा आरोपण आनुवंजिक परीिण

(ि)

कोई अन्य प्रदिया, कृ पया स्ट्पष्ट करें ……………………………………

<!-- page 10 -->

10
8.

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

कोई अजतररि िानकारी
घोषणा

मैं घोषणा करता हं दक इस प्ररूप में िी गई प्रजवजष्टयां और इसके सार् प्रस्ट्तुत अजतररि जववरण, यदि कोई हैं,
मेरे सवोत्तम ज्ञान और जवश्वास के अनुसार सत्य हैं।
तारीख: _____________
प्ररूप 4
[जनयम 11 िेखें]
रजिस्ट्री का प्रमाणपत्र
सरोगेसी जललजनक
(िो प्रजतयों में िारी दकया िाए)
प्रमाणपत्र संख्या:
1.

सरोगेसी (जवजनयमन) अजधजनयम, 2021 की धारा 12(1) के अधीन प्रित्त िजियों का प्रयोग करते हुए, उपयुि
प्राजधकारी…………………………. ………………………… पूवोि अजधजनयम के अनुसार सरोगेसी या
सरोगेसी प्रदियाओं को पूरा करने के प्रयोिन के जलए, जनम्नजलजखत सरोगेसी जललजनक को ……………….. को
समाप्त होने वाली ……………… की अवजध के जलए रजिस्ट्री प्रिान करते हैं।
(क)

सरोगेसी जललजनक का नाम और पता:

(ख)

संस्ट्र्ान का प्रकार (सरकारी/जनिी)

2.

यह रजिस्ट्री उि अजधजनयम और उसके अधीन जनयमों के अधीन प्रिान दकया िाता है और इनके दकसी भी
उल्लंघन का पररणाम, पांच वषा की उि अवजध की समाजप्त से पहले इस रजिस्ट्री प्रमाणपत्र का जनलम्ब्बन या
जनरस्ट्तीकरण होगा।

3.

रजिस्ट्री संख्या आवंरटत

4.

के वल रजिस्ट्री के नवीकृ त प्रमाण पत्र के जलए: रजिस्ट्री के पहले प्रमाण पत्र की वैधता की अवजध ……………. से
…………………तक
उपयुि प्राजधकारी के
हस्ट्तािर, नाम और पिनाम

तारीख: ……………..
स्ट्र्ान: ……………….
सील
इस प्रमाणपत्र की एक प्रजत व्यवसाय के स्ट्र्ान पर ध्यनाकषी स्ट्र्ान पर प्रिर्िात करें ।
*िो लागू या आवश्यक न हो उसे काट िें

<!-- page 11 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

11

प्ररूप 5
[जनयम 12 िेखें]
अपील संख्या/20……… राज्य बोडा/राष्ट्रीय बोडा को…………..के जवरुद्ध की गई
......के मामले में:
अपीलकताा का नाम और पता
बनाम
प्राजधकरण का नाम और पता जिसके आिेि को चुनौती िी गई है प्रजतवािी

सबके प्रजत सम्ब्मान ििााते हुए:
उपयुाि अपीलकताा........................संबंजधत उपयुि प्राजधकारी द्वारा................................ (स्ट्र्ान का नाम और पता)
पर अपीलकताा के जवरुद्ध पाररत आिेि के जवरुद्ध अपील करता है
(मामले का जववरण यदि कोई हो)

तारीख.....................
और अपील दकए गए आिेि पर आपजत्त को जनम्नजलजखत आधार प्रस्ट्तुत करता है: 1.

आिेिों की संख्या सजहत आिेि का जववरण, यदि कोई हो, जिसके जवरुद्ध अपील की गई है।

2.

मामले के त्य संिेप में।

3.

उपयुि प्राजधकारी के जनष्कषा जिन्हें चुनौती िी गई।

4.

अपील करने के आधार।

5.

उन सभी िस्ट्तावेिों, जिन पर अपीलार्ी जनभार रहा है, के सार् आिेि की प्रजत संलग्न।

6.

अपील के समर्ान में कोई अन्य िानकारी/िस्ट्तावेज़

प्रार्ाना:
इसजलए अपीलकताा, अपील के अधीन आिेि के ऊपर वर्णात कारणों के जलए प्रार्ाना करता है दक रद्द दकया िाए और
अमान्य घोजषत दकया िाए तर्ा अपीलार्ी के पि में न्यायोजचत एवं उजचत समझे िाने वाले आिेि को पाररत करने की
कृ पा की िाए।

अपीलकताा के हस्ट्तािर
स्ट्र्ान: …………………….
तारीख: ……………………..
सत्यापन
मैं,................... ..... सत्याजपत करता हूँ दक पैरा …………. से …………… तक की सामग्री मेरे सवोत्तम ज्ञान और
जवश्वास के अनुसार सत्य और सही है और कोई भी भाग झूठ नहीं है और उसमें कोई भी आवश्यक बात नहीं जछपायी गई है।

अपीलकताा के हस्ट्तािर

<!-- page 12 -->

12

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

जववरण

पृष्ठ सं.

िस्ट्तावेज़ों की सूची

ि.सं.

MINISTRY OF HEALTH AND FAMILY WELFARE
(Department of Health Research)
NOTIFICATION
New Delhi, the 21st June, 2022
G.S.R. 460(E).—In exercise of the powers conferred by section 50 of the Surrogacy (Regulation)
Act, 2021 (47 of 2021), the Central Government hereby makes the following rules, namely: 1.

Short title and commencement.- (1) These rules may be called the Surrogacy (Regulation) Rules,
2022.
(2) They shall come into force on the date of their publication in the Official Gazette.

2.

Definitions.- In these rules, unless the context otherwise requires; (a) ‘Act’ means the Surrogacy (Regulation) Act, 2021 (47 of 2021);

3.

(b)

‘form’ means a form appended to these rules;

(c)

‘section’ means a section of the Act;

(d)

words and expressions used herein and not defined but defined in the Act shall have the
meanings respectively assigned to them in the Act.

The requirement, and qualification for persons employed, at a registered surrogacy clinic.- (1)
The minimum requirement of staff and their qualification for surrogacy clinic shall be as
specified in Schedule I, Part 1.
(2) The minimum requirement of equipment for surrogacy clinic shall conform to the
requirement as specified in Schedule I, Part 2.

4.

The manner of application for obtaining a certificate of recommendation by the Board shall be as
specified in Form 1.

5.

Insurance coverage.- (1) The intending woman or couple shall purchase a general health insurance
coverage in favour of surrogate mother for a period of thirty six months from an insurance company
or an agent recognized by the Insurance Regulatory and Development Authority established under
the provisions of the Insurance Regulatory and Development Authority Act, (41 of 1999) for an
amount which is sufficient enough to cover all expenses for all complications arising out of
pregnancy and also covering post- partum delivery complications.

<!-- page 13 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

13

(2) The intending couple/woman shall sign an affidavit to be sworn before a Metropolitan Magistrate
or a Judicial Magistrate of the first-class giving guarantee as per clause (q) of sub section (1) of
section 2 of the Surrogacy (Regulation) Act, (47 of 2021).
6.

Number of attempts of surrogacy procedure.- The number of attempts of any surrogacy procedure on
the surrogate mother shall not be more than three times.

7.

Consent of a surrogate mother.- The consent of a surrogate mother shall be as specified in Form 2.

8.

Number of embryos to be implanted in the uterus of the surrogate mother.- The gynaecologist shall
transfer one embryo in the uterus of a surrogate mother during a treatment cycle:
Provided that only in special circumstances up to three embryos may be transferred.

9.

Conditions under which the surrogate mother may be allowed for abortion.- The surrogate mother
may be allowed for abortion during the process of surrogacy in accordance with the Medical
Termination of Pregnancy Act, 1971 (34 of 1971).

10.

Form and manner for registration and fee for a surrogacy clinic.– (1) An application for registration
for a surrogacy clinic shall be made by the surrogacy clinic which is carrying out procedures
related to the Surrogacy, as provided in the Act to the appropriate authority in Form 3.
(2) Every application for registration shall be accompanied by an application fee of rupees two lakhs
for surrogacy clinic and the application fee once paid shall not be refunded:
Provided that, if an application for registration of any surrogacy clinic is rejected by the appropriate
authority, no fee shall be required to be paid on re-submission of the application by the applicant for
the same clinic:
Provided further that such establishment in the government run institutes need not pay for
application.

11.

Period, manner and form for certificate of registration.- (1) The appropriate authority shall, after
making such enquiry and after satisfying itself that the applicant has complied with all the
requirements, shall grant a certificate of registration in Form 4 to the applicant.
(2) A copy of the certificate of registration shall be displayed by the registered surrogacy clinic at a
conspicuous place at its place of business.

12.

Appeal.- (1) The surrogacy clinic, or the intending woman, or couple may, within a period of thirty
days from the date of receipt of the communication relating to order of rejection of application,
suspension or cancellation of registration by the appropriate authority under section 13 and
communication relating to rejection of the certificates under section 14, prefer an appeal against such
order.
(2) The form of appeal shall be as specified in Form 5.

13.

Manner in which the seizure of documents, records, objects, etc., shall be made and seizure list shall
be prepared and delivered.- (1) Every surrogacy clinic shall allow the National Board or National
Registry or State Board or Appropriate Authority or to any other person authorised in this behalf to
inspect the place, equipment and records.
(2) An inspection of an already registered clinic may be done without any notice, during the working
hours of the clinic.
(3) The authorities referred to in subsection (1) shall ensure that the entry and search procedure do
not place at risk the gametes or embryos stored in the facility.

14.

Medical indications necessitating gestational surrogacy.- A woman may opt for surrogacy if; (a)

she has no uterus or missing uterus or abnormal uterus (like hypoplastic uterus or intrauterine
adhesions or thin endometrium or small uni-cornuate uterus, T-shaped uterus) or if the uterus
is surgically removed due to any medical conditions such as gynaecological cancer;

(b)

intended parent or woman who has repeatedly failed to conceive after multiple In vitro
fertilization or Intracytoplasmic sperm injection attempts. (Recurrent implantation failure);

<!-- page 14 -->

14

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

(c)

multiple pregnancy losses resulting from an unexplained medical reason. unexplained graft
rejection due to exaggerated immune response;

(d)

any illness that makes it impossible for woman to carry a pregnancy to viability or pregnancy
that is life threatening.
[F. No. U.11019/15/2022-HR(Pt.)]
GEETA NARAYAN, Jt. Secy.

SCHEDULE 1
Part 1
[See rules 3 (1)]
(1)

Staff of surrogacy clinics.- Surrogacy clinics shall have at least one gynaecologist, one anesthetist,
one embryologist and one counselor. The clinic may employ additional staff by the Assisted
Reproductive Technology Level 2 clinics; normally Director, Andrologist and shall appoint such
staff as may be necessary to assist the clinic into day-to-day work.

(2)

Qualification for doctors and other staff in surrogacy clinics.- The qualification of staff in
surrogacy clinics shall be as under:
(a)

Gyanecologist: The gyanecologist shall be a medical post-graduate in gyanecology and
obstetrics and should have record of performing 50 ovum pickup procedures and at least
three years of working experience in an ART clinic under supervision of a trained ART
specialist (In the case of gynecologists practicing ART or IVF and are working in ART
clinics before the commencement of this Act a post graduate degree in gynecology and
obstetrics with at least three years experience and record of 50 ovum pickup procedures
shall be acceptable); or
A medical post-graduate in gynaecology and obstetrics with super specialist Doctorate of
Medicine/Fellowship in reproductive medicine with experience not less than three years of
working in an Assisted Reproductive Technology clinic.

(b)

Andrologist shall be a Master of Chirurgiae or Diplomate of National Board in urology
with special training in diagnosing and treating male infertility.

(c)

Embryologist: (i) Postgraduate in clinical embryology (graduated with the full-time
program with a minimum of four semesters) from a recognised university or institute with
additional three years of human ART laboratory experience in handling human gametes
and embryos;
(ii) Ph.D. holder (full-time, Ph.D. project should be related to Clinical Embryology/assisted
reproductive technology/fertility) from a recognised university or institute or with an
additional one year of human ART laboratory experience in handling human gametes and
embryos;
(iii) Medical graduate (MBBS) or Veterinary graduate (BVSc) with a postgraduate degree
in Clinical Embryology (full-time program) from a recognised university or institute with
additional two years of ART laboratory experience in handling human gametes and
embryos;
(iv) Postgraduate in life sciences/Biotechnology with at least one year of on-site, full-time
clinical embryology certified training in addition to four years experience in handling
human gametes and embryos in a registered ART level 2 clinics.
As a one-time measure all embryologists working in Assisted Reproductive Technology or In
vitro fertilization clinics before the commencement of the Act, with the following below
mentioned qualifications and experience may be allowed to continue as embryologists. However,
after the commencement of this Act, all clinics will hire Embryologists only with any of the
above-mentioned four qualifications and experience criteria.

<!-- page 15 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

15

Graduate in Life Sciences /biotechnology/ reproductive biology/ veterinary science with at
least five years experience of working in a registered Assisted Reproductive Technology /
In vitro fertilization clinic, who have performed at least 500 IVF lab procedures (including
Intracytoplasmic sperm injection I and at least 100 cycles of cryopreservation of embryos).
(d)

Counselor: A person who is a graduate in psychology or clinical psychology or nursing or
life sciences from a recognised university or institute.

(e)

Anesthetist: Anesthetist shall be a medical postgraduate in Anesthesia from a recognised
university or institute.

(f)

Director: The director should have a post-graduate degree in medical /life
sciences/Management Sciences from a recognised university or institute.
SCHEDULE 1
Part 2
[see rule 3(2)]

1.

Equipments: - Microscope:
(a)

Incubator (minimum 02 in number);

(b)

Laminar Airflow;

(c)

Sperm counting Chambers;

(d)

Centrifuge;

(e)

Refrigerator;

(f)

Equipment for cryopreservation;

(g)

Ovum aspiration pump;

(h)

Ultrasonography machine with transvaginal probe and needle guard;

(i)

Test tube warmer;

(j)

Anesthesia resuscitation trolley.

FORM 1
[See rule 4]
Application Form for Couple of Indian Origin/Intending woman for availing Surrogacy addressed to
Board
I/ We (Details as given below) request for a certificate of recommendation for availing Surrogacy
Services
1.

Basic Information

1.1

Details of Intended Father:
1.

Name:

2.

Surname:

3.

Date of Birth:

4.

Blood Group:

5.

Age in years:

6.

Sex: Male/ Female

<!-- page 16 -->

16

THE GAZETTE OF INDIA : EXTRAORDINARY

7.

Nationality:

8.

Occupation:

9.

Marital Status: Married/ Divorced /Widow.

[PART II—SEC. 3(i)]

10.
Address: (Please give details of Address in India if available and the present foreign
country of residence)

1.2

(i)

Present:

(ii)

Permanent

11.

Telephone/Mob. No. (Details of number in India and the country of residence)

12.

Email:

13.

Social Security Number or Equivalent

14.

Passport Number

Details of the Intended Mother:
1.

Name:

2.

Surname

3.

Date of Birth:

4.

Blood Group:

5.

Age in years

6.

Sex:

7.

Nationality:

8.

Occupation:

9.

Marital Status: Married/ Divorced /Widow.

Male

Female

10.
Address: (Please give details of Address in India if available and the present foreign
country of residence)

1.3

(i)

Present:

(ii)

Permanent

11.

Telephone/Mob. No. (Details of number in India and the country of residence)

12.

Email:

13.

Social Security Number or Equivalent

14.

Passport Number

Briefly describe the reason for availing surrogacy

Declaration
I hereby declare that the above statements are true to the best of my knowledge and belief.
Date: ……………………………

Signature of the Intended father

Place: …………………………..

Signature of the Intended Mother

<!-- page 17 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

17

Self attested Documents required for applying
1.

Proof of marriage / Marriage Certificate (If applicable)

2.

Proof of age/ Birth certificate/10th certificate/ or any equivalent.

( Note: Certificate of essentiality is to be obtained from appropriate authority and Certificate of Medical
Indication is to be obtained from the District Medical Board)
FORM 2
[See rule 7]
Consent of the Surrogate Mother and
Agreement for Surrogacy
I, ____________________________________ (the woman), aged _______ Years (address)
________________________________________ (Aadhar Number), having _______ (Number of children)
child/children __________ (age in years) of my own have agreed to act as a surrogate mother for Intending
couple/intending woman Name _________________ Husband Name _______________ Wife/
________________ Intending woman Age _______ Husband Age _____ Wife/Intending woman
__________________ had a full discussion with Dr. _____________________________ of the Surrogacy
clinic on _______________________ in regard to the matter of my acting as a surrogate mother for the
child/children of the above couple.
1.

That I understand that the methods of treatment may include:
(a)

stimulation of the genetic mother for follicular recruitment;

(b)

the recovery of one or more oocytes from the genetic mother by ultrasound-guided oocyte
recovery or by laparoscopy;

(c)

the fertilization of the oocytes from the genetic mother with the sperm of her husband;

(d)

the fertilization of a donor oocyte by the sperm of the husband;

(e)

the maintenance and storage by cryopreservation of the embryo resulting from such
fertilization until, in the view of the medical and scientific staff, it is ready for transfer;

(f)

implantation of the embryo obtained through any of the above possibilities into my uterus,
after the necessary treatment if any.

2.

That I have been assured that the genetic mother and the genetic father have been screened for
‘HIV’ and hepatitis ‘B’ and ‘C’ and other sexually transmitted diseases before oocyte recovery and
found to be seronegative for all these diseases. I have, however, been also informed that there is a
small risk of the mother or the father becoming seropositive for Human immunodeficiency (HIV)
during the window period.

3.

That I consent to the above procedures and the administration of such drugs that may be necessary
to assist in preparing my uterus for embryo transfer, and for support in the luteal phase.

4.

That I understand and accept that there is no certainty that a pregnancy may result from these
procedures.

5.

That I understand and accept that the medical and scientific staff may give no assurance that any
pregnancy will result in the delivery of a normal and living child or children.

6.

That I am unrelated or related (relation) _____________________________ to the couple (the
would-be genetic parents).

7.

That I have worked out medical and other expenses and conditions of the surrogacy with the couple
in writing and an appropriately authenticated copy of the agreement has been filed with the clinic,
which the clinic shall keep confidential. A General health insurance coverage in favor of the
surrogate mother from an insurance company or an agent recognized by the Insurance Regulatory
and Development Authority established under the Insurance Regulatory and Development
Authority Act, 1999 (41 of 1999) has been purchased by the intending couple/woman.

<!-- page 18 -->

18

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

8.

That I agree to relinquish all my rights over the child and hand over the child/children to
__________________________, or _____________ and _____________________ in case of a
intending couple, or to ______________________________ in case of their separation during my
pregnancy, or to the survivor in case of the death of one of them during pregnancy, or to -------------------------------------- in case of death of both of them, or to -------------------------------------------------- in case of guarantor intending couple/ woman, as soon as I am permitted to do so by the
hospital or clinic or nursing home where the child or children are delivered.

9.

That I have been provided with the written consent of all of those name(s) mentioned above.

10.

That I undertake to inform the surrogacy clinic, ______________________, of the result of the
pregnancy.

11.

That I take no responsibility that the child or children delivered by me will be normal in all
respects. I understand that the biological parent(s) of the child/ children has / have a legal
obligation to accept the child or children that I deliver and that the child or children would have all
the inheritance rights of a child or children of the biological parent(s) as per the prevailing law.

12.

That I shall not be asked to go through sex determination tests for the child/ children during the
pregnancy and that I have the full right to refuse such tests.

13.

That I understand that I would have the right to terminate the pregnancy in case of any
complication as advised by the doctors, under the provisions of the Medical Termination of
Pregnancy Act, 1971 (34 of 1971).

14.

That I certify that I have not born any child through surrogacy before.

15.

That I have been tested for ‘HIV’, hepatitis ‘B’ and ‘C’ and shown to be seronegative for these
viruses just before embryo transfer.

16.

That I shall not have intercourse of any kind once the cycle preparation is initiated.

17.

That I certify that (a) I have not had any drug intravenously administered into me through a shared
syringe; and (b) I have not undergone blood transfusion in the last six months.

18.

That I also declare that I shall not use drugs intravenously, or undergo blood transfusion excepting
of blood obtained through a certified blood bank on medical advice.

19.

That I undertake not to disclose the identity of the party seeking the surrogacy.

20.

That In the case of the death or unavailability of the party seeking my help as the surrogate mother,
I shall deliver the child/children to ______________________ or ___________________________
in this order; I shall be provided, before the embryo transfer into me, a written agreement of the
above persons that they shall be legally bound to accept the child or children in the case of the
above-mentioned eventuality. (If applicable)

(Strike off if not applicable.)
Endorsement by the Surrogacy Clinic
I/we have personally explained to _____________________ and ______________ the details and
implications of his / her / their signing this consent / approval form, and made sure to the extent humanly
possible that he / she / they understand these details and implications.
Signed:
(Surrogate Mother)
Signature of Intending couple/Woman
Name, address and signature
of the Witness from the Surrogacy clinic
Name and signature of the Doctor
Name and address of the Surrogacy Clinic
Dated:

<!-- page 19 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

19

FORM 3
[See rule 10]
APPLICATION FORM
REGISTRATION OF A SURROGACY CLINIC
Name of the Surrogacy clinic:
Address of the Surrogacy clinic:
State: _________________ City: ___________________

Pin Code:

Telephone No. (with STD Code) (Surrogacy clinic only):
Mobile No. of Surrogacy clinic
E-mail (Surrogacy clinic):
Website, if any

1.

Status of your Surrogacy clinic:
1. Government

2. Private

Any other, please specify………………………………………………………

2.

Date of establishment of your Surrogacy clinic:

3.

Whether your Surrogacy clinic is registered under following Acts/Authorities (Please provide
details) Yes / No
1. The Medical Termination of Pregnancy (MTP) Act, 1971 (44 of 1971)
2. The Pre-Conception and Pre-Natal Diagnostic Techniques (Prohibition of Sex Selection) Act,
1994 (57 of 1994)

4.

Whether your Surrogacy clinic has Director
(1. Yes

2. No)

a) Name
b) Qualification
c) Registration No. if applicable

5.

Details of staff
Post
Gynaecologist
Anesthetist
Clinical
Embryologist
Andrologist
Counsellor

6.

List of equipments

Name

Qualification

Registration No. if
applicable

<!-- page 20 -->

20
7.

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

Indicate which of the following procedures are being carried out at your Surrogacy clinic
1. Yes

8.

2. No

(a)

Intra-uterine Insemination using Husband Semen (IUI-H)

(b)

Intra-uterine Insemination using Donor Semen (IUI-D)

(c)

In vitro Fertilization-Embryo Transfer (IVF-ET)

(d)

Intra-cytoplasmic Sperm Injection (ICSI)

(e)

Processing of semen

(f)

Storage of gametes (sperm and oocyte) and or embryos of patient

(g)

Pre-implantation Genetic Testing

(h)

Any other procedure, please specify……………………………………

Any additional Information
DECLARATION

I hereby declare that the entries in this form and the additional particulars (if any), furnished
herewith are true to the best of my knowledge and belief.
Date: _____________
FORM 4
[See rule 11]
CERTIFICATE OF REGISTRATION
Surrogacy Clinic
(To be issued in duplicate)
Certificate No.:
1.

In exercise of the powers conferred under section 12 (1) of the Surrogacy (Regulation) Act, 2021
(47 of 2021), the Appropriate Authority …………………………. …………………………
hereby grants registration to the Surrogacy Clinic named below for purposes of carrying out
surrogacy or surrogacy procedures as per the aforesaid Act, for a period of ……………..years
ending on ………………………
(a)

Name and address of the Surrogacy clinic:

(b)

Type of institution (Government / Private)

2.

This registration is granted subject to the aforesaid Act and Rules there under and any
contravention thereof shall result in suspension or cancellation of this certificate of registration
before the expiry of the said period of three years.

3.

Registration No. allotted

4.

For renewed Certificate of Registration only: Period of validity of earlier Certificate of Registration
from ……………. To …………………
Signature, Name and Designation of
the Appropriate Authority

Date: ……………..
Place: ……………….
SEAL
Display one copy of this certificate at a conspicuous place at the place of business
*Strike out whichever is not applicable or necessary

<!-- page 21 -->

[भाग II—खण्ड 3(i)]

भारत का रािपत्र : असाधारण

21

FORM 5
[See rule 12]
Appeal No./20………Made against …………..to the State Government /Central Government
In the matter of:
Name and Address of Appellant
Versus
Name and Address of the Authority Whose Order is Challenged Respondent

Most respectfully showeth:
The above-mentioned appellant appeals against the order passed by the........................ concerned
Appropriate Authority at ................................................(Name of place and address) against the appellant in
(details of the case if any)
dated.....................
and sets forth the following grounds of objection of the order appealed: 1.

Particulars of the order including number of orders, if any, against which the appeal is Preferred.

2.

Brief facts of the case.

3.

Findings of the Appropriate Authority challenged.

4.

Grounds of appeal.

5.

Copy of the order enclosed along with all the documents relied upon by the Appellant.

6.

Any other information/documents in support of appeal

Prayer:
That the appellant, therefore prays for the reasons stated above the order under the appeal be set aside and
quashed and order deemed just and proper may kindly be passed in favor of the appellant.

Signature of the Appellant
Place: …………………….
Date: ……………………..
Verification
I, ................... ..... do hereby verify that the contents of para ………….to ..................... are true and correct
to the best of my knowledge and belief and no part is false and nothing material has been concealed therein.

Signature of the Appellant

<!-- page 22 -->

22

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

List of Documents
S. No.

Particulars

Page No.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054. MANOJ
Digitally signed by
MANOJ KUMAR VERMA

2022.06.21 20:27:44
KUMAR VERMA Date:
+05'30'
