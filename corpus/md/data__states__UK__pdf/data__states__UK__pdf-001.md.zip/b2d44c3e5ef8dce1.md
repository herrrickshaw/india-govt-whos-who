---
doc_id: "b2d44c3e5ef8dce1"
source_url: "https://cpcb.nic.in/uploads/Projects/Bio-Medical-Waste/BMW_Amended_10.05.2019.pdf"
ministry: "Veer Chandra Singh Garhwali Government Institute of Medical Science and Research, Srinagar, Pauri Garhwal, Uttarakhand"
title: "Bio-medical Waste Management Rules, 2016 (Amended) – 10.05.2019"
date: ""
pages: 2
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "e8da56698a4661b9"
---

<!-- page 1 -->

jftLVªh laö Mhö ,yö&33004@99

REGD. NO. D. L.-33004/99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (i)
PART II—Section 3—Sub-section (i)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la-

ubZ fnYyh] lkseokj] ebZ 13] 2019@oS'kk[k 23] 1941

300]
No. 300]

NEW DELHI, MONDAY, MAY 13, 2019/VAISAKHA 23, 1941

पयावरण, वन और जलवायु परवतन मंालय
अिधसूचना

नई दली, 10 मई, 2019

सा.का. िन. 360(अ).—पयावरण (संरण) िनयम, 1986 के िनयम 5 के उप-िनयम (4) के साथ पठत पयावरण

(संरण) अिधिनयम, 1986 (1986 का 29) क धारा 6, 8 और 25 "ारा #द$त शि&य' का #योग करते *ए, क, -ीय सरकार
उ/त िनयम के िनयम 5 के उप-िनयम (3) के खंड (क) के अधीन जनिहत म, दी गई सूचना क अपेा को समा6त करने के
प7चात, जैव-िचक$सा अपिश8ट #बंधन िनयम, 2016 का और संशोधन करने के िलए िन<निलिखत िनयम बनाती है,
अथात् :—

1.

) इन िनयम' का संि@ नाम जैव-िचक$सा अपिश8ट #बंधन (दूसरा संशोधन) िनयम, 2019 है।

(1

(2) ये

2.

राजपB म, इनके #काशन क तारीख को #वृ$त ह'गे।

िचक$सा अपिश8ट #बंधन िनयम, 2016 (िजसे इसम, इसके प7चात् उ/त िनयम कहा गया है) के िनयम 4
म,, खEड (घ) म, िन<निलिखत Fप8टीकरण अGतःFथािपत कया जाएगा, अथात् :जैव-

करण – शंकाI के दूर करने के िलए यह Fप8ट कया जाता है क ‘‘/लोरीनीकृ त 6लािFटक थैिलय'’’ अिभKि& म, मूB

‘‘पटी

थैिलयां,

बिह:Lाव थैिलयां, उदरीय थैिलयां और वीय जल िनकास थैिलयां सि<मिलत नहM ह'गी।’’

/त िनयम' क अनुसूची 3 क Nम सं. 4 के सामने, Fतंभ (3) क मद सं. (vii) म, जो ‘‘महािनदेशक, सशFB बल
िचक$सा सेवा "ारा #चािलत िचक$सा िनरीण (एमआइ) क', जहाज' पर रोगी क या पनडुSबी, Fटेशन िचक$सा के G-'
तथा अिTम Fथान' म, िFथत ेB अFपताल' को छोड़कर अGय FवाFWय के G-' का िनरीण और िनगरानी (िनयम
9)” म, “(vii)” को8ठक औरअंक के Fथान पर ‘‘(viii)’’ को8ठक और अंक रखे जाएंगे।
3.

उ

[फा.सं. 3-1/2000-एचएसएमडी]

अरिवGद कु मार नौटयाल, संयु/त सिचव
2431 GI/2019

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

टपण : मूल िनयम भारत के

राजपB, असाधारण, भाग-II, खंड 3, उप-खंड (i) म, अिधसूचना सं. सा.का.िन. 343 (अ)
तारीख, 28 माच, 2016 "ारा #कािशत कए गए थे और त$पYात इनम, अिधसूचना सं. सा.का.िन. 234 (अ)
तारीख 16 माच, 2018 और सं. सा.का.िन. 129 (अ) 19 फरवरी, 2019 "ारा संशोधन कए गए थे।
MINISTRY OF ENVIRONMENT, FOREST AND CLIMATE CHANGE
NOTIFICATION
New Delhi, the 10th May, 2019

G.S.R. 360(E).—In exercise of the powers conferred by Sections 6, 8 and 25 of the Environment (Protection)
Act, 1986 (29 of 1986) read with sub-rule (4) of rule 5 of the Environment (Protection) Rules, 1986, the Central
Government, after having dispensed with the requirement of notice under clause (a) of sub-rule (3) of rule 5 of the said
rule in public interest, hereby makes the following rules further to amend the Bio-Medical Waste Management Rules,
2016, namely:—
1.

(1) These rules may be called the Bio-Medical Waste Management (Second Amendment) Rules, 2019.
(2) They shall come into force on the date of their publication in the Official Gazette.

2. In the Bio-Medical Waste Management Rules, 2016 (hereinafter referred to as the said rules), in rule 4, in clause (d),
the following Explanation shall be inserted, namely:“Explanation.- For removal of doubts, it is hereby clarified that the expression “Chlorinated plastic bags” shall not
include urine bags, effluent bags, abdominal bags and chest drainage bags.”.
3. In Schedule III to the said rules, against serial number 3, in column (3), in item (viii), for the brackets and letters
“(viii)”, the brackets and letters “(vii)” shall be substituted.
[F. No. 3-1/2000-HSMD]
ARVIND KUMAR NAUTIYAL, Jt. Secy.
Note: The principal rules were published in the Gazette of India, Extraordinary, Part II, Section 3, Sub-section (i), vide
number G.S.R. 343(E), dated the 28th March, 2016 and subsequently amended vide number G.S.R. 234(E), dated
the 16th March, 2018 and number G.S.R. 129(E), dated the 19th February, 2019.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

signed
ALOK Digitally
by ALOK KUMAR
2019.05.14
KUMAR Date:
11:19:20 +05'30'
