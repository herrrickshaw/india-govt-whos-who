---
doc_id: "e67660bfeba90dff"
source_url: "https://cdnbbsr.s3waas.gov.in/s3c154e8f56c74b3be3008da9bd19d08fc/uploads/2025/07/202507251507514011.pdf"
ministry: "Medical Health and Family Welfare Department, Uttarakhand"
title: "Corrigenda-Surrogacy-(Regulation)-Rules-2022 (389 KB)"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "DEVANAGARI"
needs_ocr: false
sha1: "a01901b4f35cdd80"
---

<!-- page 1 -->

रजिस्ट्री सं. डी.एल.- 33004/99 REGD. No. 0. L.-33004/99
Che G f Indi
ब्ट Oazette of India
Lott. -S). Wer. -37.-992022-24025
CG-DL-E-2022-24025
असाधारण
EXTRAORDINARY
भाग I—que 3---उप-खण्ड (i)
PART II—Section 3—Sub-section (i)
प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY
a mmeepaememmmeememmmmeemmeeememmeeeeeeeee eee
सं. 726) नई दिल्ली, शुक्रवार, नवम्बर I, 2022/कार्तिक 20, 944
No. 726] NEW DELHI, FRIDAY, NOVEMBER II, 2022/KARTIKA 20, 944
च्चचतचतत्ततततततततचचततत ea eer ed
स्वास्थ्य और परिवार कल्याण मंत्रालय
(स्वास्थ्य अनुसंधान विभाग)
शुद्धिपत्र
नई दिल्‍ली, 44 नवम्बर, 2022
सा.का.नि. 84(अ).--भारत के राजपत्र असाधारण, भाग UL, धारा 3, उप-खंड () में 2 जून, 2022 को
प्रकाशित दिनांक 24 जून, 2022 की समसंख्यक अधिसूचना के हिंदी संस्करण में, पृष्ठ संख्या 40 पर प्ररूप 4 के तहत पैरा 2
पंक्ति 2, में पांच वर्ष शब्दों को तीन वर्ष पढ़ा जाए।
[फा. सं. %.079/45/2022-waan (पीटी)]
गीता नारायण, संयुक्त सचिव
MINISTRY OF HEALTH AND FAMILY WELFARE
(Department of Health Research)
CORRIGENDA
New Delhi, the llth November, 2022
G.S.R. 8I4(E)—In the Hindi Version of the Notification of even No. dated 2]* June, 2022 as
Published in the Gazette of India Extraordinary, Part II, Section 3, Sub-section (i) on 2* June, 2022, on
page no. 0 under Form 4 in para 2 line 2, the words five years may be read as three years.
[F. No. U.I09/I5/2022-HR (Pt.)]
GEETA NARAYAN, Jt. Secy.
7484 0/2022
Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New ऐला।- 0064
and Published by the Controller of Publications, Delhi-I0054. 000%७७७ gcwm
