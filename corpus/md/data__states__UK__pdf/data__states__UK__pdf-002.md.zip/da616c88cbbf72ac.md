---
doc_id: "da616c88cbbf72ac"
source_url: "https://scert.uk.gov.in/public/assets/cells/1722323267.pdf"
ministry: "State Council of Educational Research & Training, Uttarakhand"
title: "Guidelines School complex"
date: ""
pages: 19
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "575bed5bb6c5603f"
---

<!-- page 1 -->

Contents
..................................................2




.......................................................................................................2
.................4




................................................................4



........................................................................................................4



.........................................................................................................5



.........................................................5



........................................................................................................6



...................................................................................................................................6



.................................................................................................................7



.............................................................................................7



......................................................................................8
................................................................................8




....................................9



.....................................................9



.............................................................................................................9



.........................................................................................................9



....................................................................... 10



............................................................................................... 10



........................................................................................................ 11



........................................................................................... 11



.............................................................................. 12



................ 12



........................................................................................................ 13



.................................................................................................................. 13



................................................................................................. 14


....................................................................................... 14
................................................................. 14



1

<!-- page 2 -->

Ldwy dkWEIySDl ,d vdknfed bdkbZ gksxhA ftlds }kjk iz”kkldh; fu;a=.k Hkh fd;k tk;sxkA blds
vUrxZrioZrh; {ks=ksa esa 3 ls 5 fdeh rFkk eSnkuh {ks=ksa esa 7 ls 10 fdeh dh ifjf/k esa fLFkr ,d ;k ,d
ls vf/kd ek/;fed fo|ky;ksa vkSj mlds utnhd fLFkr vkaxuokM+h] d{kk 1 ls 5] d{kk 6 ls 8 rFkk
d{kk 1 ls 8 rd lapkfyr izkFkfed ,oa mPp izkFkfed fo|ky;ksa dks feykdj ,d Ldwy dkWEIySDl ds
:Ik esa fodflr fd;k tk,xkA ,d Ldwy dkWEIysDl esa de ls de 5 rFkk vf/kd ls vf/kd 15 fo|ky;
lfEefyr gksaxsA ;fn fu/kkZfjr ifjf/k ds vUrxZr ,d Ldwy dkWEIysDl esa fo|ky;ksa dh la[;k 15 ls
vf/kd gksrh gS rks ogka ij nwljk Ldwy dkWEIysDl cuk;k tk;sxkA
Ldwy dkWEIysDl ds dsUnzh; fo|ky;dks dkWEIySDl Ldwy ds uke ls tkuk tk;sxk] ftldk p;u
fuEufyf[kr ekudksa ds vk/kkj ij fd;k tk;sxkA
 jktdh; ek/;fed fo|ky; ftlesa mPpre d{kk Lrj ;Fkk d{kk 10 vFkok d{kk 12 rd f”k{k.k
gksrk gksAmPPkre d{kk okys fo|ky; ds iz/kkukpk;Z vFkok iz/kkuk/;kid }kjk Ldwy dkWEIySDl dk
usr`Ro fd;k tk;sxkA
 fu/kkZfjr ifjlhek esa dksbZ ek/;fed fo|ky; vofLFkr u gksus dh n”kk esa ml dkWEIySDl dk
usr`Ro egRRke d{kk okyk fo|ky; djsxkA
 ftlesa leqfpr Hkou] iqLrdky;] foKku iz;ksx'kkyk vkSj midj.k] dEI;wVj ySc] d{kk d{k] [ksy
dk eSnku] vkbZ lh Vh ls lEcfU/kr lqfo/kk,a] is;ty O;oLFkk] “kkSpky; vkfn lqfo/kk,a miyC/k
gksaA
 tks fu/kkZfjr ifjf/k esa fLFkr leLr fo|ky;ksa ls ;FkklEHkoleku nwjh ij gks vFkok dsUnz esa
fLFkr gksA
Ldwy dkWEIySDl dk y{; Ldwy ds iz/kkukpk;Z vkSj f'k{kdksa dks ijLij lg;ksx miyC/k djkuk gS]ftlls
mudk vyxko lekIr gksA cgqr&lh iz'kklfud] laLFkkxr] xousaZl vkSj izca/ku lEcU/kh ftEesnkfj;kW
Ldwy dkWEIySDl dks lkSaius ls fuEu laHkkouk,a [kqyasxh%
 f'k{kd] laLFkk&iz/kku vkSj vU; lg;ksxh LVkQ ds thoUr lewgksa dk fodklA
 LFkkuh; Lrj ds lHkh cPpksa dh vkjafHkd ckY;koLFkk f'k{kk ls ysdj d{kk&12 rd dh f'k{kk dks
,d lw= esa cka/kukA

2

<!-- page 3 -->

 iqLrdky;] foKku iz;ksx'kkyk vkSj midj.k] dEI;wVj ySc] [ksy lqfo/kk,a vkfn lalk/kuksa dk
lk>k mi;ksx lEHko gksxkA lkFk gh lkekftd dk;ZdrkZ] lykgdkj ¼dkmUlyj½ laxhr] dyk]
Hkk"kk vkSj 'kkjhfjd f'k{kk] O;kolkf;d f”k{kk ds fo'ks"kK f'k{kdksa tSls ekuoh; lalk/kuksa ls Hkh
Ldwy dkWEIySDl ds lHkh Ldwyksa dks ykHkkfUor fd;k tk ldsxkA
 midj.k] ySc] cqfu;knh lqfo/kkvksa ds lkFk&lkFk f'k{kd] fo|kfFkZ;ksa vkSj lgk;d LVkQ dk ,d
,slk fu.kkZ;d lewg rS;kj gksxk] ftlls dkWEIysDl esa lfEefyr lHkh Ldwyksa dh O;oLFkk dk
izHkkoh usr`Ro] xousaZl vkSj izca/ku lqfuf'pr gks ldsxkA
Ldwy dkWEIySDl cuus ls vkSj dkWEIySDl ds Ldwyksa ds chp lalk/kuksa ds lk>s mi;ksx ls nwljs Hkh cgqr
ls ykHk gksaxs] tSls&
 fo'ks"k vko';drk okys cPpksa ds fy, csgrj lg;ksxA
 fofo/k fo"k;ksa ij vk/kkfjr fo|kFkhZ Dyc vkSj csgrj vdknfed@[ksy@dyk@f'kYi vk/kkfjr
dk;Zdzeksa dk vk;kstuA
 dyk] laxhr] Hkk"kk vkSj 'kkjhfjd f'k{kk vkfn fo’k;ksa ls lEcfU/kr f'k{kdksa ds lk>s mi;ksx ls
d{kkvksa esa bu xfrfof/k;ksa dk izHkkoh lekos'k(
 fo|kfFkZ;ksa ds fy, csgrj lg;ksx dh miyC/krk] “kr izfr”kr ukekadu] mifLFkfr vkSj
miyfC/k;ksa esa lq/kkj rFkk ,l-lh-,e-lh ds ek/;e ls izHkkoh vkSj etcwr xousZal ds lkFk
ghlkeqnkf;d lgHkkfxrk vkSj lykgdkjksa ds ek/;e ls fujh{k.k] fuxjkuhvkSj uokpkjA
 Ldwyksa] laLFkk izeq[kksa] f'k{kdksa] fo|kkfFkZ;ksa] lg;ksxh LVkQ] ekrk&firk] vfHkHkkodksa vkSj LFkkuh;
ukxfjdksa ds cM+s vkSj thoar lewgksa ds vk/kkj ij lalk/kuksa dk dq'ky mi;ksx djrs gq, iwjh
f'k{kk O;oLFkk dks leFkZ cukukA

loZ f”k{kk vfHk;ku ds rgr LFkkfir ladqy lalk/ku dsUnzkas dks gh Ldwy dkWEIySDl ds :i esa
fodflr fd;k tk,xkA izR;sd ladqy lalk/ku dsUnz ds lsfor {ks= esa vkus okys b.Vj dkWyst] jk-ck-b-dkjk-m-ek-fo] jk-d-m-ek-fo] ftlesa Hkh mPpre d{kklapkfyr gks] dks Ldwy dkWEIySDl ds usr`RodrkZ
fo|ky; ds :i esa fodflr fd;k tk,xkA ;fn fdlh ladqy esa loksZPPk d{kk okys ,d ls vf/kd
fo|ky; gksa rks lokZf/kd lalk/ku;qDr ,oa ladqy ds lHkh fo|ky;ksa ds fy, loZlqyHk fo|ky; dks
usr`RodrkZ fo|ky; ds :i esa fodflr fd;k tk,xkA izR;sd Ldwy dkWEIySDl ds vUrxZr vkaxuokM+h ls
ysdj d{kk 12 rd ds lHkh fo|ky; vkPNkfnr gksaxsA usr`RodrkZ fo|ky; ¼ dkWEIySDl Ldwy ½ds
iz/kkukpk;Z Ldwy dkWEIySDl ds iz/kku ds :i esa dk;Z djsaxasAfodkl[k.M Lrj ij dkWEIySDl ds rgr

3

<!-- page 4 -->

vkPNkfnr fo|ky;ksa dh nwjh ,oa HkkSxksfyd ifjfLFkfr;ksa ds n`f’Vxr [k.M f”k{kk vf/kdkjh] blesa rkfdZd
ek=kdj.k dj ldsaxsA

cgqr ls lkoZtfud {ks= ds Ldwyksa dks lkFk ykdj ,d lkaLFkkfud vkSj
iz'kklfud bdkbZ dk xBu fd;k tk,xk ftls Ldwy dkWEIySDl dgk tk,xkA blesa HkkSfrd :Ik ls Ldwyksa
dk LFkku&ifjorZu ugha gksxk vkSj vdknfed ,oa iz'kklfud :i ls Ldwy dkWEIYkSDl dk Hkkx gksus ds
ckotwn gj Ldwy dk lapkyu tkjh jgsxkA
Ldwy dkWEIySDl lkoZtfud f'k{kk O;oLFkk ds 'kSf{kd iz'kklu dh cqfu;knh bdkbZ gksxh vkSj bl :i esa
gh mldk fodkl fd;k tk,xkA
Ldwy dkWEIySDl dk mi;ksx ml vyxko dks lekIr djus esa fd;k tk,xk ftlesa vyx vyx
Ldwyksa ds f'k{kd vkt dke djrs gSaA blls f'k{kdksa vkSj laLFkk iz/kkuksa ds ,d thoar leqnk; dk fuekZ.k
gksxk tks ijLij lg;ksx ls vdknfed vkSj iz'kklfud ekeyksa dh csgrjh gsrq dk;Z djsaxsA
Ldwy dkWEIySDl jkT; ljdkj ds gj Lrj ij iz'kkldksa dks T;knk izHkkoh :Ik ls dk;Z djus esa
ennxkj gksxk D;ksafd Ldwy dkWEIySDl dks ,d bdkbZ ekuk tk;sxk] ftldks lapkyu gsrq i;kZIr
Lok;Rrrk vkSj Lora=rk miyC/k gksxhA
gkykafd Ldwy dkWEIysDl esa lfEefyr izR;sd fo|ky; dks i;kZIr lqfo/kk,a eqgS;k djk;h tk;saxh]
rFkkfi dkWEIysDl cuus ls lk>s mi;ksx }kjk lHkh fo|ky;ksa esa lalk/kuksa dh miyC/krk csgrj gksxhA
mnkgj.k ds fy, leLr fo"k;ksa vkSj d{kkvksa ds f'k{kdksa dh miyC/krk] iqLrdky; ds fy, vf/kd
leqfpr iqLrdsa] lk/ku le`) iz;ksx'kkyk;sa] O;kolkf;d f”k{kk vkSj [ksy&lqfo/kk,a fo|kfFkZ;ksa dks vius
Ldwy dkWEIysDl esa gh miyC/k gksaxhA

 gj Ldwy dkWEIySDl ,d iz”kklfud vkSj vdknfed lEiUu bdkbZ gksxh ftlesa cqfu;knh Lrj ¼3 ls 8
o"kZ dh mez½ ls ysdj d{kk&12 ¼18 o"kZ ½ rd dh f'k{kk miyC/k gks xhA

4

<!-- page 5 -->

 Ldwy dkWEIySDl ds vUrxZr dkEIySDlLdwy ds :i esa ,d ek/;fed fo|ky; ¼d{kk&9 ls 12 rd½
fu/kkZfjr fd;k tk;sxk rFkk dkEIySDlLdwy ls ,d fuf”pr nwjh ij fLFkr iwoZ&izkFkfed ls ysdj
d{kk&12 rd ds leLr jktdh; fo|ky;bl Ldwy dWkEIysDl esa lfEefyr gksaxsA
 lHkh fo|ky;ksa dk p;u mudh ,d&nwljs ls fudVre nwjh ds vk/kkj ij fd;k tk;sxk ftlls
rkfdZd :i ls mfpr HkkSxksfyd lewg cusaA ;fn fdlh dkj.ko'k ,d dkWEIySDl esa dksbZ Hkh ek/;fed
fo|ky; ugha gks tgk¡ ek/;fed d{kkvksa rd f'k{k.k gksrk gks rks mPpre d{kk okys fo|ky; dks gh
dkWEIysDl Ldwy fu/kkZfjr fd;k tk;sxkA
 Ldwy dkWEIysDl gsrq fu/kkZfjr ifjf/k esa fLFkr iwoZ izkFkfed fo|ky;@'kkyk&iwoZ dsUnz
¼izh&Ldwy½@vkaxuckM+h] O;kolkf;d f'k{kk dh lqfo/kk,a] izkS<+ f'k{kk dsUnz ¼AEC½ vkfn Hkh Ldwy
dkWEIysDl esa lfEefyr gksaxsA
 jkT; ljdkjsa fo|ky;ksa ds lewg dk Ldwy dkWEIysDl ds :i esa xBu tula[;k forj.k] lM+d
lqfo/kkvksa vkSj nwljs LFkkuh; ekudksa dks /;ku esa j[kdj djsaxhA blfy, Ldwy dkWEIysDl ds vkdkj
vkSj lajpuk esa rks fofo/krk gks ldrh gS ijUrq bl ckr dk iwjk /;ku j[kk tk;sxk fd ,slk djus ls
fo|kfFkZ;ksa vkSj muds ifjokjksa dh Ldwy rd igqap] f'k{kdksa vkSj laLFkk iz/kkuksa ds lg;ksx gsrq O;oLFkk
vkSj jkT; ljdkj ds fy, iz'kklfud lqxerk lqfuf'pr gksA

 Ldwy dkWEIySDl dk iz/kku mPpre d{kk okys fo|ky; dk iz/kkukpk;Z gksxkA
 og iz'kklfud] foRrh; vkSj vdknfed vf/kdkj lEiUu gksxk ftlls og dkWEIySDl ds lHkh Ldwyksa
ds lefUor fodkl dh ns[k&js[k dj ldsA
 mls CEO,DEO vkSj BEOLrj ds vf/kdkfj;ksa dk i;kZIr iz'kklfud lg;ksx feysxk vkSj lkFk gh
mls iz'kkldh;] foÙk vkSj ys[kk dk;ksaZ ds fy, i;kZIr la[;k esa deZpkjh Hkh miyC/k djk;s tk;saxsA
dkWEIySDl ds nwljs Ldwyksa ds eq[; v/;kid@iz/kkukpk;Z mlds funsZ'kkuqlkj dk;Z djsaxsA
 os feydj ,d Vhe xfBr djsaxs tks dkWEIySDl ds izR;sd Ldwy esa xq.koRrk lq/kkj ds fy, ftEesnkj
gksaxs] ftlesa ukekadu c<+kuk] MªkWi vkmV nj dks U;wure djuk vkSj lHkh cPpksa dks d{kk&12 rd
i<+kbZ tkjh j[kus gsrq izksRlkfgr djuk 'kkfey gSA

 jkT; ds leLr Ldwyksa dks Ldwy dkWEIySDl ds :i esa fodflr fd;s tkus ij fofHkUUk Lrjh; Ldwyksa
ds e/; lalk/kuksa dk vHkh’B mi;ksx fd;k tk ldsxkA blesa fo"k; f'k{kd] O;kolkf;d f”k{kd]

5

<!-- page 6 -->

laxhr vkSj dyk f'k{kd] lykgdkj vkSj leqnkf;d lgHkkxhtSls ekuo lalk/ku rFkk iz;ksx'kkyk,a]
iqLrdky;] LFkkuh; f”kYi ØhM+k LFky tSls HkkSfrd lalk/ku 'kkfey gksaxsA
 Ldwy dkWEIySDl ds Lrj ij ICT midj.k] laxhr ok|&;U=] [ksy midj.k] tSls lalk/kuksa dks c<+kus
vkSj csgrj fd;s tkus ls bu lalk/kuksa dk izR;sd cPPks gsrq lqfu;ksftr mi;ksx fd;k tk;sxkA

 ;FkklaHko gj Ldwy dks mlds lkekU; lapkyu ds fy, i;kZIr lalk/ku iwoZor miyC/k djk;s tkrs
jgsaxsA
 tks lqfo/kk;sa vkSj midj.k gj Ldwy esa nsuk laHko ugha gksxk] mUgsa dkWEIySDl Ldwy ds Lrj ij lk>s
mi;ksx gsrq miyC/k djk;k tk;sxkA mnkgj.k ds fy,] vkWfM;ks&ohfM;ks midj.kksa dks iksVsZcy tujsVj
ds lkFk fofHkUu Ldwyksa rd ys tk;k tk ldsxkA
 blh izdkj dkWEIySDl Ldwy esa ,d vPNh iz;ksx'kkyk] laxhr ok|&;U=] [ksy midj.k lfgr [ksy dk
eSnku gks ldrk gSA ftldk mi;ksx Ldwy dkWEIySDl ds vUrxZr vkus okys izR;sd fo|ky; }kjk
vko”;drkuqlkj fd;k tk,xkA ftls fu;fer :i ls dkWEIySDl ds iwoZ izkFkfed] izkFkfed vkSj mPp
izkFkfed Ldwyksa dks miyC/k djk;k tk ldrk gSA
 dkWEIySDl Ldwy esa ,d fodflr iqLrdky; ¼Rich Library½ dh O;oLFkk gksxh rFkk fudVorhZ
fo|ky;ksa ds cPpksa ds }kjk bl iqLrdky; dk mi;ksx fd;k tk,xkAbl iqLrdky; dks fMftVy
ykbczjsjh ds :i esa fodflr fd;k tk,xk rFkk pj.ko) <ax ls leqnk; ds lnL;ksa ds }kjk Hkh
mi;ksx fd;k tk,xkA
 dkEIySDlLdwy ds iz/kkukpk;Z lHkh lk>s mi;ksx ds lalk/kuksa ds izHkkjh gksaxs vkSj os mudk leqfpr
mi;ksx lqfuf'pr djsaxsA
 dkEIySDliz/kkukpk;Z lalk/ku fodflr djus gsrq lh-,l-vkj-] fo/kk;d fuf/k] iapk;r fuf/k rFkk vU;
foRRkh; lalk/kuksa gsrq vius Lrj ls iz;kl djsaxsA

 dkWEIySDl ds Ldwyksa ds e/; f'k{kdksa dks Hkh vko”;drkuqlkj lk>k fd;k tk,xk ;Fkk ,d fo|ky;
esa fo’k; fo”ks’k ds f”k{kd dks vko”;drk gksus ij vU; fo|ky; esa f”k{k.k dk;Z gsrq dk;ksZftr fd;k
tk ldsxkA

6

<!-- page 7 -->

 ikB~;p;kZ ds vuqlkj ftu {ks=ksa@fo"k;ksa esa ¼cPpksa dh la[;k dks ns[krs gq,½ gj Ldwy esa f'k{kd ugha
fn;k tk ldrk] muds fy, dkWEIySDl Lrj ij f'k{kd fu;qDr fd;s tk,axsA ftlls mudh lsokvksa
dk ykHk dkEIySDl ds lHkh fo|ky;ksa dks fey ldsA mnkgj.k ds fy, Hkk"kk f'k{kd] [ksy f'k{kd]
dyk vkSj laxhr f'k{kd] ;ksx f'k{kd] Ldwy ulZ vkSj lykgdkjksa dks dkEIySDlLdwy ds LVkQ ds rkSj
ij fu;qDr fd;k tk ldrk gS ftlls dkWEIySDl ds lHkh Ldwyksa dks mudh lsokvksa dk ykHk fey
ldsA
 Ldwy dkWEIySDl dh vo/kkj.kk ds vUrxZr dkEIySDlds fdlhLdwy esa,sls f'k{kd dh O;oLFkk djuk
lEHko gksxk tks dkWEIySDl ds Ldwyksa esa vko';drk iM+us ij LFkk;h f'k{kdksa ds vodk'k ds nkSjku
LFkkukiUu f'k{kd ds rkSj ij ogka Hksts tk ldsaA
 Ldwy dkWEIysDl esa ikB~;p;kZ ds {ks=ksa@fo"k;ksa ds vk/kkj ij dkWEIySDl ds lHkh Ldwyksa dh t+:jrksa dk
/;ku j[krs gq, i;kZIr la[;k esa f'k{kd miyC/k gksaxsA

 Ldwy dkWEIySDl esa ml HkkSxksfyd {ks= esa fo|kfFkZ;ksa ,oa izkS<+ f'k{kkfFkZ;ksa dh la[;k ds vk/kkj ij
i;kZIr la[;k esa lg;ksx nsus okys f”kf{kr O;fDRk;ksa dks fpfUgr fd;k tk,xkA
 tks fu;ksftr <ax ls lsfor {ks= esa ekrk&firk vkSj cPpksa ds lkFk tqM+s jgsaxsA os Nk= ukekadu vkSj
mifLFkfr gsrq izsfjr djsaxs] ftlls MªkWi vkmV de fd;k tk ldsxkA
 leqnk; esa fpfUgr O;fDr fo'ks"k vko';drk okys cPpksa dh igpku djus vkSj mudh “kSf{kd fLFkfr
ij /;ku j[kus esa f'k{kdksa dh enn djsaxsA ftlesa ,sls cPpksa ds ifjokjksa vkSj leqnk; ds lkFk tqM+ko
cukuk 'kkfey gSA
 leqnk; eas fpfUgr O;fDr ,l-lh-,e-lh- dks izHkkoh cukus esa Hkh lgk;d gksaxsA
 Ldwy dkWEIySDl ,sls O;fDr;ksa dks mijksDr mn~ns';ksa dh iwfrZ gsrq gj lEHko enn djsaxsA

 gkyk¡fd fo|kfFkZ;ksa dh ns[kHkky vkSj [kq'kgkyh esa f'k{kdksa dh dsUnzh; Hkwfedk gksxh] rFkkfi gj Ldwy
dkWEIySDl esa ;FkklaHko ,d ;k vf/kd lykgdkj miyC/k djok;k tk,xkA
 tks fuEufyf[kr {ks=ksa esa lg;ksx djsaxs %&
ek/;fed d{kkvksa esa fo"k;ksa ds p;u] blesa O;kolkf;d fo"k;] mPp f'k{kk lEcU/kh pquko vkSj
vUrr% thfodk gsrq is'ks dk pquko Hkh 'kkfey gSA
mez vk/kkfjr fodkl ds eqn~nksa ij fo'ks"kdj fd'kksjkoLFkk esa lgk;rk vkSj ijke'kZA

7

<!-- page 8 -->

ruko vkSj euksn'kk lEcU/kh fodkj lesr ekufld LokLF; ds eqn~nksa ij lgk;rk vkSj ijke'kZA
vU; {ks= tks cPpksa ds fodkl gsrq vko”;d gksaA
 ,d ;k ,d ls vf/kd dkWEIysDl ds fy, iw.kZdkfyd ijke'kZnkrk fu;qDr fd;s tk ldrs gSa] tks
fu;fer :i ls Ldwyksa esa tk,axsA

 gj Ldwy dkWEIysDl ds fy, ,d iz'kklfud ;kstuk cukbZ tk;sxhA
 O;kolkf;d vkSj izkS<+ f'k{kk dh xfrfof/k;ka Hkh D;ksafd Ldwy dkWEIysDl ds }kjk fØ;kfUor gksaxh
blfy, HkkSfrd lqfo/kkvksa dks Ldwy le; ds i'pkr~ Hkh mi;ksx esa yk;k tk,xkA blls f'k{kd vkSj
fo|kfFkZ;ksa ds fu;fer dk;Z fcuk O;o/kku ds tkjh jgsaxsA
 iqLrdky;] iz;ksx'kkyk,a] f'kYix`g vkSj [ksy ds eSnku Ldwy le; ds i”pkr bu dk;ZØeksa gsrq
miyC/k j[ks tk,axsA
 d{kk&d{k Hkh Ldwy le; ds i'pkr~ mi;ksx esa yk;s tk ldsaxsA
 vodk'k ds fnuksa esa dqN fo'ks"k dk;ZØeksa ds vk;kstu }kjk Hkh lkaLFkkfud lqfo/kkvksa dk bLrseky
fd;k tk;sxk] tSls f'k{kdksa ds O;kolkf;d fodkl] lkeqnkf;d lsok] izkS<+ f'k{kk] izfrHkk'kkyh cPpksa
vkSj fo'ks"k vko';drk okys cPpksa ij dsfUnzr dk;ZØeksa dk vk;kstuA
 lqfo/kkvksa ds bLrseky dks izksRlkfgr djus ds fy, f'k{kd] fo|kFkhZ vkSj LFkkuh; leqnk; Ldwy esa
miyC/k lqfo/kkvksa ds vf/kdre mi;ksx gsrq vius Lrj ls ;kstuk rS;kj djsaxsA

 Ldwy dkEIySDl dh f'k{kk vk;ksx ¼1964&66½ }kjk dh x;h ifjHkk"kk] tks ewy :i ls NksVs Ldwyksa ds
vyxko dks [k+Re djus vkSj 'kSf{kd miyfC/k;ksa dks csgrj djus ij dsfUnzr Fkh] dks orZeku lUnHkZ esa
foLr`r vFkZ fn;k tk;sxkA y{; ,d HkkSxksfyd {ks= esa ijLij lg;ksxh vkSj lqlaxr 'kSf{kd lqfo/kk,¡
miyC/k djkus dk gS ftuesa 'kkyk&iwoZ@vkaxuokM+h] O;kolkf;d vkSj izkS<+ f'k{kk dsUnz] f'k{kd f'k{kk
laLFkku vkSj CWSN cPpksa ds fy, lgk;rk miyC/k gksA
 ,slk Ldwy dkWEIySDl lkoZtfud f'k{kk O;oLFkk dh izkFkfed iz'kklfud bdkbZ cu tk;sxkA

8

<!-- page 9 -->

 Ldwy dkWEIySDl }kjk ECCE ij vko';d /;ku vkSj tksj fn;k tk;sxkA blds fy, Ldwy dkWEIySDl
ds HkkSxksfyd {ks= ds nk;jsa esa fLFkr ECCE ds lEc) lHkh lkoZtfud laLFkkvksa dks vdknfed]
iz'kklfud vkSj laLkk/ku lEcU/kh lg;ksx iznku fd;k tk;sxkA
 ftu Ldwyksa esa iwoZ&izkFkfed d{kk,a iwoZ ls gh gSa vFkok 'kq: gksuh gSa ogka ;s d{kk,a Ldwy dkWEIySDl
O;oLFkk ds lkFk iwjh rjg ls ,dhd`r djds lapkfyr dh tk,axhA
 bl mís'; dh iwfrZ ds fy, Ldwy f'k{kk foHkkx vkSj efgyk ,oa cky fodkl foHkkx ds chp leUo;
dks lqxe cukus ds fy, jkT; ljdkj dh vksj ls igy dh tk;sxh] jkT; ljdkj@lEcfU/kr
foHkkxviuh leUo; lEcU/kh LFkk;h lfefr ¼LVSafMax desVh vkWu dksvkWfMZus'ku½ ds tfj;s Hkh ,sls
lg;ksx vkSj leUo; ds dk;ZØeksa dks vkSipkfjd :i nsus dh fn'kk esa dke djsxkA

 Ldwy dkEIySDl] O;kolkf;d izf”k{k.k laLFkku] ikWfyVsfDud vkfn laLFkkvksa] LFkkuh; O;olk; ¼m|ksx]
lsok] d`f"k vkfn½] LokLF; dsUnz vkSj vLirky] dykdkj vkSj dkjhxj] vkSj LFkkuh; f'kYi vkSj
ijEijkvksa dk gquj j[kus okys yksxksa dh lk>snkjh esa O;kolkf;d f'k{kk ds cgqr ls ikB~;Øe lapkfyr
dj ldrk gSA
 izkS<+ f'k{kk ds fy, vk/kkjHkwr lqfo/kk,¡ Hkh Ldwy dkEIySDl ds lkFk tksM+h tk ldrh gSa vkSj dkWEIySDl
}kjk lsfor iwjs leqnk; dks miyC/k djkbZ tk ldrh gSaA

 gj Ldwy dkWIySDl ,slh t:jh vk/kkjHkwr lqfo/kk,a rS;kj djsxk ftlls dkWEIySDl ds lHkh fo”sk’k
vko”;drk okys cPpksa (CWSN) ds fy, mi;qDr enn miyC/k djkuk lqfuf'pr gksxkA
 CWSN cPpksa ds fy, dkWIySDl ds fdlh ,d Ldwy esa i<+us dh O;oLFkk gksxhA
 bl gsrq vko';drkuqlkj Ldwy ykus&ys tkus dh lqfo/kk Hkh miyC/k dh tk;sxhA
 fo”ks’k vko”;drk okys cPpksa gsrq Ldwy dkWEIySDl esa ^^Lis”ky ,tqdsVj^^ dh O;oLFkk dh tk,xhA

 Ldwyksa ds lehi fLFkr fo'ofo|ky;] dkWyst vkSj ikWfyVsfDud viuh izklafxd {kerkvksa ds bLrseky
}kjk vius ikl ds Ldwyksa dh miyfC/k;ksa ds lq/kkj esa ;ksxnku nsaxsA fo'ks"kdj ek/;fed Ldwyksa ds

9

<!-- page 10 -->

fy,& fo"k;ksa dh fo"k;&oLrq vkSj iz;ksx'kkyk,a] iqLrdsa vkSj [ksy ds eSnku tSlh HkkSfrd lqfo/kkvksa ds
:i esa] ;g lg;ksx ykHknk;d gksxkA
 Ldwyksa dks O;kolkf;d dkslZ pykus ds fy, fo'ks"k ;ksxnku dh vko';drk iM+rh gS] blds fy, ikl
ds dkWyst vkSj ikWfyVsfDud esa miyC/k lqfo/kkvksa dk bLrseky fd;k tk,xkA
 ftys ds CEOs, DEOs vkSj BEOsLdwyksa ds fy, ;kstuk vkSj lg;ksx lqfuf'pr djus ds fy, mPp
f”k{k.k laLFkkvksa dk lg;ksx Hkh ysaxsA

 Ldwy dkWEIySDl ds lHkh f”k{kd ,d l”kDr leqnk; ds :i esa feydj T;knk izHkkoh rjhds ls vius
O;klkf;d fodkl vkSj Ldwyksa ds miyfC/k Lrj dks csgrj djus ds fy, dke dj ldsaxsA
 vc tcfd f'k{kd Ldwy dkWEIySDl ds Lrj ij fu;qDr gksaxs] mudk vkil esa vkSj ogka ds leqnk; ds
lkFk LFkk;h lEcU/k cuk ikuk laHko gksxkA
 Ldwy dkWEIySDl gsrq uo fu;qDr f”k{kdksa dks dkWEIySDl ds vuqHkoh f”k{kdksa dk ;kstukc) rjhds ls
ekxZn”kZu feyrk jgsxkA

 Ldwy dkWEIySDl dh ,d eq[; ftEesnkjh f'k{kdksa ds lrr O;kolkf;d fodkl dh Hkh gksxhA bl gsrq
,d O;kid f'k{kd fodkl ;kstuk ¼TDP½ fodflr dh tk,xh ftlesa f'k{kd Lo;a ds O;kolkf;d
fodkl gsrq fofo/k rjhdksa dkiz;ksx djsaxsA
 dkEIySDl ds lHkh f'k{kd ,d&nwljs dks lg;ksx ns ldsa vkSj lk>s lh[kus ds volj miyC/k gksa bl
gsrq mUgsa ,d leqnk; ds :i esa fodflr fd;k tk;sxkA
 ijLij lg;ksx vkSj lh[kus gsrq lgdehZ f”k{kdksa ds ;g lgHkkxh lewg gksaxs tks “kSf{kd vk;keksa ds
fodkl ds fy, ijLij lg;ksx ,oa mRlkgo/kZu djrs gq, dk;Z dj ldsaxsA
 lgHkkxh f”k{kd leqnk; }kjk izHkkoh f”k{kd fodflr djus ds fy, Ldwy usr`Ro vkSj vU; lalk/kuksa
}kjk lrr iz;kl dh vko”;drk gksxhA
 izHkkoh leqnk;dSls rS;kj fd;s tk,¡] bl mís'; ls SCERT/SIEMAT@DIETsvkfnfo'ks"k dk;ZØe
rS;kj djsaxsA
 flfoy lkslkbVh ds laxBuksa ¼NGOs½ dks Hkh izsfjr fd;k tk;sxk fd os ,sls leqnk;ksa ds fodkl vkSj
lapkyu esa tqM+s vkSj ;ksxnku nsaA

10

<!-- page 11 -->

 Ldwy dkWEIySDl] ijLij lgHkkfxrk ls lh[kus okys f”k{kd lewgksa ds fy, t+:jh O;oLFkk,a cuk,xk]
tSls fd lkIrkfgd cSBd] f'k{kd vf/kxe dsUnz] vkfnA
 blds vykok CPD ds nwljs ek/;e Hkh miyC/k djk;s tk;saxs] tSls vUrZLdwy dkWEIySDl Hkze.k]
ifjppkZ ,oa lk>snkjh] lsfeukj] 'kSf{kd Hkze.k] d{kk&f'k{k.k ds nkSjku ijke'kZ vkfnA

 DSE vkSj SCERT }kjkvdknfed vkSj f'k{kd lg;ksx ra= ls tqM+s laLFkkuksa ds ek/;e ls Ldwy
dkEIySDl O;oLFkk ls ijLij lkeatL; fcBk;k tk;sxkA blesa CRCs, BRCs vkSj DIETs 'kkfey
gksaxsA
 CRCs dks Ldwy dkWEIySDl ds fy, f'k{kd vf/kxe dsUnzksa ¼TLCs½ ds :i esa fodflr fd;k tk
ldrk gSA
 Ldwy dkWEIySdl ds usr`Ro esa TLCfodflr dh tk,xh ftlesa iz;ksx”kkyk,a] iqLrdky;] iz;ksx
lEcU/kh fdV vkSj f”k{k.k gsrq vkWuykbZu lalk/ku vkfn gks ldrs gSaA ftlls fofHkUu izf”k{k.k]
cSBdsa ,oa vkWuykbZu dk;ZØe lqpk: :i ls lapkfyr gks ldsaxsA
 CRCs,BRCs vkSj DIETs ds dk;Z] Ldwy dkWEIySDl O;oLFkk dh t+:jrksa ds eqrkfcd] vFkkZr
dkWEIySDl ds f'k{kdksa ds O;kolkf;d fodkl dks /;ku esa j[krs gq, fo'ks"kdj f'k{kd leqnk; ds
fodkl ij] dsfUnzr gksaxsA
 bu laLFkkuksa dks viuh vYikof/k ,oa e/;kof/k ;kstukvksa esa Ldwy dkWEIySDl fodkl ;kstuk
¼SCDPs½@Ldwy fodkl ;kstuk ¼SDPs½ dh t+:jrksa dks] ftlesa TLC Hkh 'kkfey gSa] 'kkfey
djuk gksxk vkSj bUgsa iwjk djus esa lg;ksx nsuk gksxkA
 f'k{kd fodkl vkSj vdknfed lg;ksx dh ;kstuk Ldwy dkEIySDl] BRCs vkSj CRCs@DIETs
ijLij ijke'kZ }kjk rS;kj djsaxsA
 DSEvkSj SCERT bl izfØ;k dks lqxe cukus esa iwjk lg;ksx djsaxsA
 jkT; }kjk fofHkUu laLFkkuksa ds chp rkyesy gsrq ,d ;kstuk fodflr dh tk,xh vkSj
SCERT/DIETs blesa lqxedrkZ dh Hkwfedk fuHkk,xhA

 Ldwy dkWEIySDl ds xBu }kjk ijLij lgHkkfxrk vkSj lg;ksx dks lqfuf'pr djrs gq, izR;sd
Ldwy dk lqpk: iz'kklu vkSj izca/ku lqxe fd;k tk;sxkA

11

<!-- page 12 -->

 Ldwy dkWEIySDl esa usr`RodrkZ fo|ky; gh vius lHkh Ldwyksa dh vksj ls iz”kklfud ,oa
vdknfed ekeyksa esa foHkkx ds lh/ks laidZ esa gksxkA

 ladqy Lrjh; Ldwy dkWEIySDl xfBr fd;s tk,axs ftlesa ,d ladqy ds vUrxZr vkus okys
leLr izkFkfed] mPPk izkFkfed] gkbZ Ldwy ,oa b.VjehfM,V Ldwy lfEefyr gksaxsA
 gkykafd dkWEIySDl ds vkdkj esa fofo/krk jgsxh] ,slk lewghdj.k fo|kfFkZ;ksa dh Ldwy rd igq¡p]
iz'kkldh; lqfo/kk vkSj f'k{kd ,oa iz/kkukpk;ksZa ds fy, ,d lg;ksxh O;oLFkk dks lqfuf'pr djus
dh n`f"V ds fy, fd;k tk;sxkA
 bu fo|ky;ksa esa vf/kdre lalk/ku ;qDr ek/;fed fo|ky;ksa dks Ldwy dkWEIySDl usr`RodrkZ
fo|ky; ds :i esa fodflr fd;k tk,xkA
 Ldwy dkWEIySDl xBu ds i”pkr ;fn fdlh Ldwy dh Nk= la[;k ekud ls de gksrh gS rks
,slh fo|ky;ksa dk fudVorhZ fo|ky;ksa esa foyhuhdj.k fd;k tk,xkA
 Ldwy dkWEIySDl ds Ldwyksa esa f'k{kdksa vkSj fo|kfFkZ;ksa dh lqjf{kr igq¡p ds fy, vkokxeu lqfo/kk
¼lkbfdy] cl vkSj vko';drkuqlkj vU; lk/ku tSls& LdkWVZ lqfo/kk½ vkfn miyC/k djkbZ
tk,xhA
 jkT; ljdkj 2023 rd Ldwyksa ds Ldwy dkWEIySDl ds :i esa xBu dh izfØ;k iwjh djsaxhA bl
dk;Z esa i;kZIr ;kstuk vkSj rS;kjh bl ckr dh djuh gksxh fd Ldwy dkWEIySDl ds xBu ds ihNs
dk ewy Hkko] ftlds dsanz esa fo|kfFkZ;ksa ds vf/kxe Lrj esa lq/kkj gsrq f'k{kdksa vkSj iz/kkukpk;ksZa ds
fy, ,d lg;ksxh O;oLFkk fuekZ.k djuk gS] tksfd lHkh fgr/kkjdksa rd vo'; igq¡p tk;sA

 Ldwyksa dks Ldwy dkEIySDl ds :i esa xfBr djus ds izfØ;k eas gj Ldwy dh ekStwnk vk/kkjHkwr
lqfo/kkvksa dk vkadyu vkSj muds mUu;u gsrq ,d&ckj esa i;kZIr lalk/ku miyC/k djkus gsrq
iz;kl fd;k tk,xkA
 d{kk d{k] 'kkSpky;] is;ty] fctyh] pkgjnhokjh vkSj nwljh egRoiw.kZ lqfo/kkvksa vkSj 'kSf{kd
lalk/kuksa dh deh dh igpku dj mudks tYn ls tYn iwjk fd;s tkus dk iz;kl fd;k tk,xkA

12

<!-- page 13 -->

 rRi'pkr] DSE }kjk Ldwy dkEIySDl dks le; le; ij vk/kkjHkwr lqfo/kk,a ,oa ctV
vko”;drkuqlkj miyC/k djkok;k tk;sxkA

 gj Ldwy dkWIySDl esa ,d SCMC gksxh ftlesa dkWEIySDl ds izR;sd Ldwy dk izfrfuf/kRo gksxk]
SCMC dk usr`Ro dWkEIySDl Ldwy dk iz/kkukpk;Z djsaxs A blesa dkWEIySDl ds gj Ldwy ds
iz/kkuk/;kid@iz/kkpk;Z ds vykok ,d f'k{kd] izR;sd Ldwy dh SMC ls ,d lnL; rFkk
flfoy lkslkbVh dk ,d lnL; Hkh lfEefyr gksxkA
 blds vfrfjDr] SCMC esa Ldwy dkWEIySDl ls lEc) lHkh nwljs laLFkkuksa] tSls BRCs, CRCs
tSls vdknfed laLFkkuksa ls Hkh izfrfuf/kRo gksxkA
 SCMC dk dk;Z dkWEIySDl ds lHkh Ldwyksa esas vf/kxe Lrj esa lq/kkj ykuk gksxkA bl mís'; ds
fy, bl lfefr ds lnL; eghus esa de ls de ,d ckj] lnL;ksa ds fy, lqfo/kktud le;
¼fo'ks"kdj ekrk&firk@flfoy lkslkbVh lnL; dks /;ku esa j[krs gq,½ ds vuqlkj cSBd djsaxsA
 bl cSBd esa ijLij fopkj&foe'kZ }kjk Ldwy dkWEIySDl vkSj dkWEIySDl ds lHkh Ldwyksa dh
fodkl ;kstuk,¡ cukbZ tk,axh vkSj ml fn'kk esa mBk;s x, dneksa dh leh{kk gksxhA
 bl cSBd esa fofHkUu SMCs ds izfrfuf/k viuh&viuh SDMC ds lnL;ksa }kjk& mBk;s x,
eqíksa@fn, x, lq>koksa@ntZ dh x;h f'kdk;rksa dks j[k ldsaxs vkSj mu ij fopkj gksxkA
 SCMC fof'k"V nh?kkZof/k mís';ksa ij dke djus ds fy, NksVh Vheksa@lfefr;ksa ds xBu ij
fopkj djsxh] ftlesa O;kolkf;d f'k{kk ij ,dhdj.k] f'k{kdksa ds O;kolkf;d fodkl gsrq
leqnk; dks fodflr djus tSls eqís 'kkfey gSaA

 lgk;d dkfeZdksa dh deh ds n`f’Vxr]Ldwy dkWEIySDl dh O;oLFkk dk;e gks tkus ij DSE}kjk
Ldwy dkWEIySDl dks i;kZIr la[;k esa lgk;d deZpkjh miyC/k djk;s tk;saxs] ftlls Ldwy
dkWEIySDl lqpk: :i ls dk;Z dj ldsA ;s deZpkjh ys[kk dk;Z] lkekU; iz'kklu tSls dkeksa vkSj
vk/kkjHkwr lqfo/kkvksa dh miyC/krk] LoPNrk vkSj j[k&j[kko ds fy, Hkh ftEenkj gksaxsA ;s
lgk;d deZpkjh i;kZIr la[;k esa f'k{kd] lkekftd dk;ZdrkZ vkSj lykgdkjksa ds vykok gksaxsA
 Ldwy dkEIySDl ds iz/kku }kjk bu lgk;d deZpkfj;ksa vkSj ,d ls vf/kd Ldwyksa esa lsok,a nsus
okys f'k{kdksa ds fy, vkokxeu lqfo/kk vFkok vkokxeu HkRRkk miyC/k djk;k tk;sxkA

13

<!-- page 14 -->

 dkWEIysDl dh SCMC/SMC ,oa iz/kkukpk;Z dks f”k{kk ds xq.koŸkk lq/kkj ds fy, fu.kZ; ysus dh
ftEesnkjh dk fodsanzhdj.k fd;k tk;sxkA
 jkT; ljdkj dh Hkwfedk vkSj ftEesnkjh dk ljyhdj.k fd;k tk;sxk ftlls Ldwy dkWEIySDl ,d
iz”kklfud ,oa vdknfed bZdkbZ ds :i esa LFkkuh; Lrj ij O;kid :i ls xq.koŸkk lq/kkj dk iz;kl
dj ldsA
 jkT; ljdkj dks ftyk f'k{kk lfefr ¼District Education Commettie½ uke ls ,d ftyk&Lrjh;
xousZal bdkbZ dk xBu djuk gksxk] tks Ldwy dkWEIySDl vkSj DSE ds chp dh bdkbZ dk dk;Z
djsxhA
 DSE Ldwy dWkEIySDl Lrj ij vius vf/kdkjksa dk fodsanzhdj.k djsxkA
 CEO, DEO vkSj BEO izkFkfed :i ls gj Ldwy dkWEIySDl dks ,d bdkbZ ekudj mlds lkFk
dk;Z djsaxsA
 dkWEIySDl mu fodsUnzhd`r dk;ksZa dh ftEesnkjh Lo;a ysxk tks iwoZ esa DSE ds fujh{k.k vf/kdkfj;ksa
}kjk fd;s tkrs jgs gSa vkSj bl izdkj vius lEc) Ldwyksa ds lkFk dk;Z djsxkA
 DSE }kjk Ldwy dkWEIySDl dks Lok;RRkrk gksxh] ftlls og uS'kyu dfjdqye ÝseodZ ¼NCF½ vkSj
LVsV dfjdqye ÝseodZ ¼SCF½ ds nk;js esa jgrs gq,] lefUor f'k{kk iznku djus vkSj ikB~;p;kZ]
f'k{kk&'kkL= dks ysdj iz;ksx dj ldsasxsA
 bl O;oLFkk ds rgr Ldwy lqn`<+ gksaxs] T+;knk Lora=rkiwoZd dk;Z dj ldsaxs vkSj dkWEIySDl dks
T+;knk jpukRed vkSj tokcnsg cukus dh fn'kk esa ;ksxnku ns ik,axsA

 lHkh 'kSf{kd laLFkkuksa eas usr`Ro ds Lrj ij] vYikof/k vkSj nh?kkZof/k nksuksa ds fy,] ,d ;kstukc)
rjhds ls dke djus dh laLd`fr fodflr dh tk,xhA
 Ldwy SMCs dh Hkkxhnkjh ls vius vius Ldwy dh fodkl ;kstuk,a ¼SDPs½ cuk;saxsA ;s ;kstuk,a
Ldwy dkWEIySDl fodkl ;kstuk ¼SCDPs½ cukus dk vk/kkj cusaxhA SCDP esa Ldwy dkWEIySDl ls
lEc) nwljs laLFkkuksa] tSls O;kolk;fd f'k{kk laLFkku vkfn] dh ;kstuk,a Hkh 'kkfey gksaxhA ;g
SCDP Ldwy dkWEIySDl ds f'k{kdksa vkSj iz/kkukpk;ksaZ }kjk SCDC dh Hkkxhnkjh ls cuk;k tk;sxhA

14

<!-- page 15 -->

 ;kstuk esa ekuo lalk/ku] iBu&ikBu lkexzh] vk/kkjHkwr <+kaps ls lEc) vkSj vU; HkkSfrd lalk/ku]
lq/kkj gsrq fd;s tkus okys iz;kl] foRrh; lalk/ku vksj 'kS{kf.kd miyfC/k;kW 'kkfey gksaxsA
 lq/kkj gsrq fy, tkus iz;klksa esa Ldwyksa ds vf/kxe Lrj lq/kkj gsrq f'k{k.k i)fr;kas vkSj Ldwyh laLd`fr
esa vko';d cnyko ds fy, fd;s tkus okys iz;kl lfgr ,d O;kid vkSj lefUor 'kS{kf.kd
;kstuk'kkfey gksaxsA blesa TDP Hkh 'kkfey gksxk ftlesa Ldwy dkWEIySDl ds leLr fo|kfFkZ;ksa vkSj
f'k{kdksa ds thoar leqnk; cukus dh fn'kk esa fy, tkus okys iz;klksa dk foLr`r forj.k gksxkA
 SDP vkSj SCDP os izkFkfed ek/;e gksaxs tks DSE es Ldwy ds lHkh fgr/kkjdksa dks ,d lw= esa ck¡/kus
dk vkSj lqpk: lapkyu lqfuf'pr djus dk dke djsaxsA
 SDP vkSj SCDP dks lkoZtfud :i ls miyC/k djok;k tk;sxkA
 SMC vkSj SCMCLdwyksa ds dk;Z vkSj fn'kk ij ut+j j[kus ds fy, SDP vkSj SCDP dk mi;ksx
djsaxsA os bu ;kstukvksa ds fØ;kUo;u esa Hkh ennxkj gksaxsA

DSE vius mi;qDr vf/kdkjh] tSls fd BEO ds ek/;e ls gj Ldwy dkEIIySDl ds SCDP dks
Lohd`fr iznku dh tk,xhA

rRi'pkr SCDOs ds vYikof/k ¼,d&o"khZ;½ vkSj nh?kkZof/k ¼03 ls 5 o"kZ½ y{;ksa dh iwfrZ gsrq
vko';d lalk/ku ¼foRRkh;] ekuo vkSj HkkSfrd vkfn½ iznku fd;s tk;saxsA

visf{kr 'kSf{kf.kd miyfC/k;ksa dks gkfly djus ds fy, nwljh t+:jh lgk;rk Hkh Ldwy dkWEIySDl
dks miyC/k djk;h tk,xhA

DSE vkSj SCERT }kjk Ldwyksa ds fy, SDP vkSj SCDP fodflr djus gsrq fof'k"V ekunaM
¼foRRkh; LVkQ vkSj izfØ;k lEcU/kh½ vkSj :ijs[kk ¼ÝseodZ½ nh tk ldrh gSA bu ekunaM+kas vkSj ÝseodZ
esa le;&le; ij la'kks/ku fd;k tk ldrk gSA
gj ftys esa ,d DEC/ZSS gksxh tks ftys dh
Ldwyh f'k{kk ds lapkyu ij ut+j j[ksxh vksj Ldwy] Ldwy dkEIySDl] SCMCs vkSj SMCs ds lapkyu
,oa l'kfDrdj.k ds dk;Z esa enn nsxhA DEC jkT; ds nwljs foHkkxksa] tSls fd efgyk vkSj cky fodkl
foHkkx] LokLF; foHkkx] mPp f'k{kk foHkkx ds lkFk leUo; djsxhA
DEC dh v/;{krk ftyk&vf/kdkjh djsaxs] CEO blds eq[; dk;Zdkjh vf/kdkjh gksaxsA blesa 15
ls 20 lnL; gksaxs ftuesa ekrk&firk] f'k{kd] iz/kkukpk;Z] flfoy lkslkbVh laxBuksa ds izfrfuf/k vkSj
DIET ds iz/kkukpk;Z 'kkfey gksxsA DEC esa f'k{kdksa vkSj iz/kkukpk;ksZa ds vykok f'k{kk esa fo'ks"kKrk j[kus
okys vkSj ml ftys esa lkoZtfud dk;kZsa esa ;ksxnku dh i`"BHkwfe okys de ls de 5 lnL; gksaxsA DEC
esa lHkh BEOs dks Hkh vkeaf=r fd;k tk;sxkA

15

<!-- page 16 -->

lHkh Lrjksa ij lEcaf/kr 'kh"kZ laLFkkuksa }kjk
;kstuk fuekZ.k vkSj leh{kk dh etcwr laLd`fr fodflr dh tk,xhA vkSj SDP,SCDP ,oa DEDP ds
vk/kkj ij ;g leh{kk,a gksaxhA ;kstuk vkSj leh{kk izfØ;k dk mís'; Ldwyksa esa f'k{kk ds lHkh i{kksa dks
fodkl djuk gksxkA
bu leh{kkvksa dk mi;ksx Ldwyh f'k{kk esa f'k{kdksa] iz/kkukpk;ksaZ] lkekftd dk;ZdrkZvksa]
lykgdkjksa] Ldwyksa vkSj Ldwy dkWEIySDl vkfn lHkh ds vPNs iz;klksa vksj ;ksxnkuksa dh igpku djus vkSj
mUgsa iqjLd`r djus ds fy, Hkh fd;k tk;sxkA ;s leh{kk,a gj Lrj ij vxys o"kZ dh ;kstuk fuekZ.k
izfØ;k dk Hkh vk/kkj cusaxhA
Ldwy lkekftd laLFkku gSaA os
leqnk; vkSj mlds fodkl ds vfHkUu vax gSaA Ldwy ds lcls cM+s vkSj utnhdh fgr/kkjd fo|kfFkZ;ksa ds
ekrk&firk gSaA 73osa vkSj 74osa lafo/kku la'kks/ku }kjk jkT;] ftyk vkSj xzke vk/kkfjr f=&Lrjh; O;oLFkk
cukdj iapk;rh jkt vkSj vU; LFkkuh; Lo'kklu ds laLFkkuksa dks lcy cuk;k x;k gSA
fdUrq Ldwy xousaZl ds dk;Z esa SMCs }kjk visf{kr lfØ; Hkkxhnkjh dh fLFkfr vHkh okLrfodrk ugha
cu ikbZ gSA blds cgqr ls dkj.k gSa] ftlesa ekrk&firk esa tkx:drk dh deh] nSfud etnwjh ij
vkfJr ekrk&firk dk SMC dh cSBdksa esa Hkkx ysus esa vleFkZrk] efgykvksa dh Hkkxhnkjh u gks ikuk
vkfnA
&% jkT; }kjk f”k{kk
vf/kdkj vf/kfu;e ds }kjk SMCs ds xBu ds fy, iwoZ esa gh fn'kkfunsZ'k fn, tk pqds gSaA blesa Ldwy
f'k{kd] ekrk&firk] fo|kFkhZ vkSj leqnk; ds yksxksa dk izfrfuf/kRo gksrk gSA SMCs ls ftl Hkwfedk dks
fuHkkus dh vis{kk gS] ml Hkko ls budk xBu fd;k tk;sxk vkSj csgrjh gsrq dne mBk;s tk;saxsA Ldwy
dkWEiySDl eas leqnkf;d lgHkkfxrk okyk ekWMy ykxw fd;k tk;sxkA
SMCs

lHkh Ldwyksa
¼ljdkjh] futh] ljdkjh lgk;rk izkIr vkSj futh xSj&lgk;rk izkIr½ dk lapkyu SMC }kjk fd;k
tk;sxk ftldk xBu RTE vf/kfu;e ds ykxw gks tkus ds ckn vfuok;Z gks x;k gSA jkT; fuEu
fn'kk&funsZ'kksa dk ikyu djrs gq, SMCs ds xBu dh leh{kk dj ldrs gSa %&
a) SMCs esa 10&12 lnL; gksus pkfg, ftuesa ls vf/kdka'k fo|kfFkZ;ksa ds ekrk&firk
fo'ks"kdj ekrk,a gksuh pkfg,A eq[; v/;kid ds vykok nks vkSj f'k{kd blds lnL;
gksus pkfg,A vU; lnL; gks ldrs gSa& ,d ;k vf/kd HkwriwoZ Nk=] ,d iapk;r lnL;
vkSj lkekftd ;ksxnku ds {ks= esa izfr"Bk j[kus okys ,d LFkkuh; O;fDrA

16

<!-- page 17 -->

b) SMC dks ,d v/;{k dk pquko djuk gksxk tks lfefr dk lapkyu djsxk] cSBdsa
vk;ksftr djsxk] cSBdksa dk ,tsaMk r; djsxk] dk;Z izxfr dh leh{kk djsxk vkSj Hkkoh
;kstuk cuk,xkA
c) eq[; v/;kid@iz/kkukpk;Z SMC ds izfr mÙkjnk;h gksxkA SMC ds Åij Ldwy xousZal
dh fuxjkuh djus dh ftEesnkjh gksxhA lkFk gh og 'kS{kf.kd ifj.kkeksa dks ysdj Ldwy
vkSj DSE ¼vkSj mlds inkf/kdkfj;ksa ls½ fopkj foe”kZ dj ldrh gSA SMCs leqnk; eas
,d LokfeRo dk Hkko fodflr djsxh lkFk gh lkekftd ,drk vkSj feytqydj dke
djus dh Hkkouk dks Hkh iksf"kr djsxhA
SMCs dh dk;Ziz.kkyh

dks csgrj vkSj izHkkoh cukus ds fy, lrr :i ls fo'ks"k iz;kl fd;s tk;saxsA
ekg esa de ls de ,d ckj SMC dh cSBd vk;ksftr dh tk;sxhA cSBdsa lnL;ksa ds fy,] fo'ks"kdj
ekrk&firk ds fy, lqfo/kktud le; ij dh tk,axhA lHkh cSBdksa esa gqbZ ckrphr dk C;kSjk j[kk tk;sxk
vksj mls lkoZtfud fd;k tk;sxkA
SMCs ds fy, {kerko/kZu dk;ZØe fu;fer :i ls vk;ksftr fd;s tk;saxasA ;g dk;ZØe DSE ds }kjk
vius ladqy vksj CykWd Lrj ds lalk/ku dsUnz rFkk bl dk;Z esa vuqHko j[kus okyh flfoy lkslkbVh
laxBuksa dh enn ls vk;ksftr fd;s tk;saxsA
LFkkuh; iapk;r ;k okMZ ifj"kn~ ;g fuxjkuh j[ksaxh fd muds vf/kdkj {ks= ds izR;sd Ldwy dh SMCs
dh cSBdsa vk;ksftr gks jgh gSa vkSj os izHkkoh :i ls dk;Z dj jgh gSaA ftys ds f'k{kk iz'kklu dks gj
SMC ds dk;Z dk vkadyu djuk gksxkA
f'k{kdksa vkSj eq[; v/;kidksa ds dk;Z fu"iknu ds izcU/ku esa
SMC ,d eq[; Hkwfedk fuHkk,axhA og f'k{kdksa vkSj eq[; v/;kidksa ds ewY;kadu] ftlesa
ekfld@v)Zokf"kZd@okf’kZd ewY;kadu 'kkfey gS] dk viuh vksj ls le; le; ij voyksdu dj
ldsaxsA SMC ftu ckrksa ij utnhdh utj j[ksxh] muesa 'kkfey gSa f'k{kd fdl gn rd visf{kr
vkpkj&O;ogkj dk ikyu djrs g]Sa tSls Ldwy esa fu;fer mifLFkfr] cPpksa ds izfr O;ogkj] Ldwyh
lalk/kuksa dk lnqi;ksx vkSj bZekunkjhA ;g f'k{kdksa vkSj iz/kkukpk;ksaZ ds okf"kZd ewY;kadu dk vfHkUu vax
gksxkA
SMC }kjk f'k{kdksa@iz/kkukpk;ksZa ds vkpkj&O;ogkj ij IkzkIr fVIi.kh dks mudh osruo`f} vkSj inksUufr
dk vk/kkj cuk;k tk ldsxkA

17

<!-- page 18 -->

SMCs ds ikl ;g

vf/kdkj gksxk fd og Ldwy dh vksj ls Ldwyh ekeyksa eas jkT; vkSj mlds fudk;ksa ds lkFk gLr{ksi dj
ldsA SMC lEcfU/kr eqnksa vkSj f'kdk;rksa ds fuiVkjs dks lqxe cukus ds fy, ,d IT vk/kkfjr
f'kdk;r ntZ djus dh iz.kkyh fodflr dh tk,xhA
LFkkuh; iapk;r@okMZ ifj"kn~ SMC dh vksj ls DSE] ftyk ifj"kn~] ftyk vf/kdkjh vkSj LFkkuh;
fo/kk;d ls ekeyksa dk QkWyks&vi] leFkZu vkSj iSjoh djsxh ftlesa muds vf/kdkj {ks= esa fLFkr lHkh
Ldwyksa esa i;kZIr lalk/kuksa dh miyC/krk 'kkfey gSA BEOs vkSj DEOs ds dk;Z izn'kZu ds ewY;kadu esa
muds {ks= dh SMCs vkSj SCMCs ls O;ofLFkr QhMcSd Hkh fy;k tk;sxkA
eq[; v/;kid@iz/kkukpk;Z Ldwy dk dk;Zdkjh iz/kku gksxk vkSj ml ij Ldwy ds
leLr vdknfed vkSj iz'kklfud ekeyksa dh ftEesnkjh dk vf/kdkj gksxkA og DSE }kjk r; ekunaMksa
vkSj SDP esa fn, foLr`r fooj.k ds vk/kkj ij 'kS{kf.kd ifj.kkeksa ds fy, vkSj Ldwy lapkyu dh lqfprk
cuk;s j[kus fy, SMC ds izfr tokcnsg gksxkA Ldwy usr`Ro dk p;u DSE ;k mi;qDr vf/kdkfj;ksa
}kjk fd;k tk;sxkA ;g p;u ofj"Brk vkSj Js’Brk ds vk/kkj ij gksxk ftls dk;Z izn'kZu ds ewY;kadu
ds vk/kkj ij tkapk tk;sxkA
Ldwy dkWEiysDl }kjk ?kksf"kr ,d :ijs[kk ds vk/kkj ij Lok;Rrrk vkSj foRrh; fu.kZ; ysus dk vf/kdkj
nsdj Ldwy iz/kkukpk;ksaZ dh Hkwfedk dks l'kDr cuk;k tk ldsxkA foRrh; izokg vkSj fu.kZ;ksa ij Ldwy
dkWEiysDl ds eqf[k;k dh fuxjkuh ds vykok SMC ds }kjk Hkh leh{kk dh tk,xhA
f'k{kdksa vkSj iz/kkukpk;ksaZ ij vius laLFkkuksa dks Js"Brk dh
vkSj ys tkus ds fy, ekrk&firk vkSj leqnk; ds lnL;ksa dks lkFk ysrs gq, ,d Vhe ds :i esa dke
djus dh ftEesnkjh cuh jgsxhA ;g Vhe fo|kfFkZ;ksa ds f'k{k.k ds vykok mudh ns[kHkky vkSj [kq'kgkyh
ds fy, Hkh ftEesnkj gksxhA
eq[; v/;kid@iz/kkukpk;Z ds usr`Ro esa f'k{kdksa dh Vhe] vius tSls gh dkWEiysDl ds nwljs Ldwy dh
Vhe ds lkFk lk>snkjh esa] ijLij lgHkkfxrk }kjk Ldwy dk izca/ku djsaxsA ;g Vhe vYikof/k ¼,d&o"khZ;
;k mlls de le; okys½ vkSj nh?kkZof/k ¼3 ls 5 o"kZ½ ds fy, Li"V ikB~;p;kZ] vf/kxe vkSj iz'kkldh;
y{; fu/kkZfjr djsxhA bu y{;ksa ij DSE, SCMC vkSj LFkkuh; SMC ls Hkh lgefr yh tk,xhA buesa
fo|kfFkZ;ksa ds vf/kxe esa lq/kkj vkSj dqy feykdj Ldwyh xq.koRrk esa lq/kkj ds y{;ksa ds lkFk lHkh ds
fy, cqfu;knh lk{kjrk vkSj d{kk 12 rd mez vuqlkj visf{kr vf/kxe Lrj lqfu'fpr djus lEcU/kh
y{; Hkh gksaxsA ukekadu c<+kus] MªkWi vkmV dks lekIr djus vkSj lHkh cPpksa dks d{kk 12 rd Ldwy esa
cuk;s j[kus lEcU/kh y{; Hkh gksaxsA bu lHkh eqn~nksa dks SDP esa txg nh tkuh pkfg,A

18

<!-- page 19 -->

bl Vhe ds ikl SDP ds fØ;kUo;u vkSj y{;ksa dks gkfly djus dh fn'kk esa fu.kZ; ysus dh Lok;Ùkrk
gksxh] SMC bl dk;Z esa lg;ksx vkSj fuxjkuh nksuksa Hkwfedk fuHkk,axhA

19
