---
doc_id: "cf2d3feba351b2f1"
source_url: "https://uou.ac.in/sites/default/files/tender-2017-06/Tender-Printing-Final.pdf"
ministry: "Uttarakhand Open University, Nainital, Uttarakhand"
title: "Download"
date: ""
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "adbfa86a876009c3"
---

<!-- page 1 -->

UTTARAKHAND OPEN UNIVERSITY
University Road, Behind Transport Nagar (Teenpani bypass),
Haldwani, Nainital, Uttarakhand
TERMS AND CONDITIONS FOR EMPANELMENT OF OFFSET PRINTERS

The Terms & Conditions for Empanelment of Offset Printers are as follows:
1. Interested

eligible tenderers may obtain the Tender form, from the office of the

Registrar, Uttarakhand Open University, University Road, Behind Transport Nagar
(Teenpani bypass), Haldwani, Nainital, Uttarakhand between 10.00 a.m to 5.00 p.m on
all working days by paying a (non-refundable) fee of Rs. 1000/- by way of a Demand
Draft in favour of Uttarakhand Open University, Haldwani . The tender document can
also be downloaded from university website www.uou.ac.in but a non refundable amount
of Rs.1000/- is to be paid by way of Demand Draft at the time of submission of the Bid
document. The fees where applicable, may be paid by way of a Demand Draft in favour
of Uttarakhand Open University, Haldwani.
2. Tender complete in all respects, in a sealed cover having two different sealed covers
inside, i.e. TECHNICAL BID in cover A (Form-A) and FINANCIAL BID in Cover B
(Form-B) must be received by the Registrar, Uttarakhand Open University, Haldwani
latest by 5.00 p.m. on 15.07.2017 superscribing type of bid on the envelopes. All the
TECHNICAL BID received within the stipulated time will be opened in the presence of
tenderers or their authorized representatives, who may choose to attend the opening of
tenders in Uttarakhand Open University, Haldwani at 11.00 a.m. on 17.07.2017
The FINANCIAL BIDs will be opened after opening of the TECHNICAL BIDs. It
will not be opened for those tenderers whose Technical Bid does not fulfill the
requirements as laid down.
The decision of the “Vice Chancellor, UOU” shall be final and binding with regard to
opening of the TECHNICAL Bid and the FINANCIAL BID.
3. The rates must be quoted both in words and figures. In case of difference in words and
figures of the rates quoted, the rates offered in words shall be considered as binding. The
tender must be signed by a person duly authorized to bind the tenderers to the contract.
Proof of authorization shall have to be furnished by the tenderer.
4. ELIGIBILITY AND QUALIFICATION REQUIREMENTS OF TENDERERS :
1|Page

<!-- page 2 -->

No tender shall be considered valid if:
a) The Specimens of books/publications printed by firm during the previous years is not
attached. A documentary proof to this effect is to be submitted.
b) The tender document not accompanied by the demand draft of Rs.1000/(Non-refundable).
c) Not submitted in prescribed tender form and not accompanied with the earnest
money of Rs. 1.00 Lakhs (Rupees One Lakhs only) by Bank Draft in favour of,
Uttarakhand Open University, payable at Haldwani. The earnest money must
accompany the Technical Bid.
d) The tender is conditional and inconsistent with the terms and conditions of the
contract given in this document.
e) The tenderer submits more than one tender or authorizes the submission of more than
one tender on its behalf by one or more authorized person(s)/Company(s).
f) Tender is received otherwise than by speed-post/registered post.
g) Tender is received after the deadline for submission of bid.
h) Bid Document: The tenderer is expected to examine carefully all the instructions,
conditions, tender form, specifications, annexures, etc. given in the tender document.
Failure to comply with the requirements of tender submission will be at the risk of
tenderer and Uttarakhand Open University shall not be liable for any damages/claims
arising out of the same.
5. Entire process may be cancelled/postponed by the University on its sole discretion at any
stage without assigning any reason for the same.
6. The printing press shall have to adhere to the time schedule. Non-adherence of time
schedule may cause the depanelment as well as penalty and the other similar
consequences along with forfeiture of security deposit.
7. Before empanelment of the printing press, the University reserves the right to physically
inspect the printing unit/factory to ensure its infrastructure, machines, quality assurance,
equipments and production capacity etc. After ensuring the same the firm shall be
considered for empanelment.

2|P age

<!-- page 3 -->

8. EARNEST MONEY DEPOSIT :
Earnest Money Deposit (EMD) amount of Rs. 1,00,000/- (Rupees One Lakhs only /-)
shall be submitted along with bid documents in the form of Demand Draft from any
commercial bank drawn in favour Uttarakhand Open University payable at Haldwani.
I.

Earnest money of the successful tenderer shall be adjusted against the security
deposit.

II.

Earnest money of the unsuccessful tenderer(s) shall be refunded as early as
possible.

III.

No interest shall be paid on Earnest Money.

IV.

Earnest money shall stand forfeited.
a) If the bid is withdrawn by tenderer at any time before the validity period, or
b) If the successful tenderer fails to execute the contract and/or does not
deposit the security amount within the stipulated period.
c) If the firm, in inspection, is found to have furnished wrong information
regarding infrastructure etc. in the tender document.

9. Award of contract shall be within the sole discretion of University. The University is not
bound to award the contract on the basis of bids received. It shall be open to the
university not to accept any bid and to abandon the contract without disclosing any
reasons. It is also not necessary that the lowest bid shall have to be accepted. The
University reserves the right to reject or accept whole or any part of the tender. The
interest of the university shall be paramount. No bidder shall have any inherent rights for
award of a contract even if the price quoted is the lowest. The decision of the university
on the tender/contract shall be final and binding on the tenderer.
10. SECURITY DEPOSIT of Rs. 500,000/- (Rupees Five Lakhs Only) in the form of
interest free deposit in favour Uttarakhand Open University, Haldwani shall have to be
furnished after empanelment.
a. The Security Deposit can be forfeited by order of the Vice-Chancellor, UOU, in the
event of any breach or non-observance of any of the conditions of the contract. On
the expiry of the contract, such portion of the said security as may be considered by
the Vice-Chancellor, UOU, sufficient to cover an incorrect or excess payment or
penalty for some defect/default etc. may be withheld by the University.
3|P age

<!-- page 4 -->

b. Any sum of the money due and payable to the tenderer(s) including Security Deposit
refundable to him/them under this contract may be appropriated by the UOU and set
off against any claim of UOU in respect of any sum of money arising under any
other Contract (s) made by the Printer with the UOU and for such purpose the UOU
shall be entitled to realize such securities forming the whole or part of any such
Security Deposit in any manner whatsoever as UOU may think fit.
c. The security deposit shall be released by the University only after completion of the
contract period.
11. The University reserves its right to take any such action (s) as it may deem fit against the
tenderer in case of failure on the part of the tenderer for fulfilling the contract apart from
forfeiture of earnest money/security deposits.
12. Acceptance of offer will be communicated in writing by Letter or e-mail. Acceptance
sent by mail shall be equally binding.
13. The terms and conditions of this agreement shall be applicable for all jobs, i.e. course
materials, posters, invitation card, brochures, job work etc. which will be assigned by the
UOU, as per its requirements from time to time.
14. The rates quoted and accepted shall remain firm, valid and not subject to any change on
whatever grounds for a period of one year from the date of acceptance of the contract. It
may be extended by one more year or it may also be curtailed by the University at its sole
discretion, with the approval of competent authority.
15. EMPANELMENT AND CONTRACT PERIOD: The Empanelment and contract (as
also the schedule of rates finalized) would be initially valid for a period of one year.
16. If the date of opening of the tender happens to be a holiday, the tender will be opened on
the next working day following the holiday at 03:00 p.m. at the same venue mentioned in
the tender document.
17. Any bribe, commission, or advantage offered or promised by or on behalf, of the tenderer
to any officer or employee of the University shall ( in addition to any criminal liability
which the tenderer may incur) debar his tender from being considered. Canvassing on
part or on behalf of the tenderer shall also make his tender liable to rejection.
18. The printer should not have been blacklisted by any of the state/ central University or the
other Government Organizations.
4|P age

<!-- page 5 -->

19. The Printing of Self Learning Material (SLM)/Prospectus/other misc. printing jobs is to
be done by the firm with high quality standards as per prescribed format and instructions
given in the work Order by the University.
20. The printing must be of standard in terms of quality. There should not be scum or tint on
the printed pages.
21. Details of printing will be given in the work order. The printing firm will bear the
responsibility to check it thoroughly. The printer will carry out the printing work with
complete safety and self vigilance.
22. After completion of the work order the printer will submit its bills in two copies with
printed samples duly signed & stamped.
23. Liquidated Damages: The Printer shall supply the Printed material at UOU’s MPDD
Godown strictly in stipulated time given in the work order.eg. if 20 days supply period is
given in printing order, days will be counted from the date of issue of work order up to 5
p.m. on 20th working day. Supply days will be given according to the quantity of books
ordered. In case of extension of the delivery period with liquidated damages, the recovery
shall be made on the basis of the following percentages of value of work order which the
printer has failed to supply.
(a) Delay upto one fourth period of the prescribed delivery period

=2.5%

(b) Delay exceeding one fourth but not exceeding half of the prescribed period

=5%

(c) Delay exceeding half but not exceeding three fourth of the prescribed period =7.5%
(d) Delay exceeding three fourth of the prescribed period

=10%

Maximum penalty for the delay will be imposed @ 10%
However, the University has the right to waive off the penalty if delay, is caused due
to the circumstances beyond the control of the printer and intimated by the firm in
advance for delay in supply of print material.
24. The instances like power failure, water shortage or closure of printing press due to an
order imposed by the Factory Inspector or any other Authority shall not be the acceptable
reasons for the delay in delivery.
25. If the supplied printed material is found to be defective the supplier will have to pick up
the same within 15 days of intimation. Subsequently, university will not bear any
5|P age

<!-- page 6 -->

responsibility. In Such a case security deposit may be forfeited and the firm may also be
blacklisted.
26. Printing of Books/ Prospectus shall be done by the firm as per the CD to be supplied by
the University. The color of the booklets shall be as per the order or mutual discussion.
27. Page no. 2 & 3 of cover may contain list of programmes offered by the University in
single color and page no. 4 may contain name, address & phone nos of Regional Centers
and important dates for admission & examination of the University.
28. 2% variation in the supply of Books/ Prospectus for each book/prospectus of ordered
quantity will be admissible. However the payment shall be made on the actual quantity
received. In case of more than 2% short supply of books the unit cost of short supply of
books+ 10 % penalty of the unexecuted work will be deducted from the bill. In case of
more than 2% variation in the ordered quantity the supply will not be accepted by the
store.
29. Art & Chromo Paper for Cover page shall be used by the press. Sample checking of
Books/Prospectus/ of any order may be done by the University. Sample paper testing will
be done by University through any State or Central Govt. testing agencies according to
following norms & standard.
a. SLM (Books) & Prospectus maplitho Paper (writing and printing paper): Testing will
be done according to IS 1848-2007 with 70 GSM on following parameters Grammage
of Paper g/m2, Brightness %, pH, Opacity %. One minute cobb test. g/m2
Brightness% pH. Wax pick. Tear Index mN.m2/g (CD & MD)
b. Cover Page (Art and chromo Paper) Books & Prospectus: Testing will be done
according to IS 7658-2010 with 180 GSM on following parameters Grammage of
Paper g/m2 Brightness% pH Wax pick. Burst Index kpa.m2/g Gloss Value%.
If any failure in testing report of above test if found, the penalty will be deducted
according to following norms:i. Failure in Maplitho Paper( writing and printing paper) of 70 GSM
10% of the bill amount related to such pages shall be deducted.
ii. Failure in Cover Page (Art and chromo Paper) of Books & Prospectus of 180
GSM, penalty of 10% of the bill amount shall be deducted.

6|P age

<!-- page 7 -->

30. Some of the study material may contain such pages, which have graphs, diagrams or
tables. No extra charges shall be given for printing of such pages.
31. The firm shall have to submit a photocopy of the purchase order of Maplitho paper and
Art & Chromo paper which has been used for printing of books and prospectus for
verification purposes.
32. The approved printer/bidder shall use white maplitho paper of size 23×36 inches and Art
and Chromo paper

of

cover

page of any

mill

of Ballarpur/JK/Star/West

Coast/HPC/Andhra/Orient. A certificate of used paper/card sheets shall be given by
the printer/bidder with the bills otherwise no payment will be admissible. Testing
report of the entire lot of purchased maplitho paper and cover page of Art and
Chromo paper lot will also be submitted by printer.
33. The firm has to inform the process of printing at the time of printing of the material
of the University for verification of various aspects of printing before completion of
printing.
34. Charges for Loading/Unloading of print material will be borne by the firm.
35. Any person authorized by the University shall have the right to enter the premises of the
printer where the said printing/binding work is being carried out to inspect the work and
its progress during the work schedule.
36. The University shall have the right to verify the capacity of the printing press as and
when required.
37. If the progress of work at any stage is found to be slower than expected and the
University is convinced that the printer will not be able to complete the work in time, the
University shall cancel the contract in full or in part and give it to another empanelled
printer. In the event of such cancellation, the security deposit of the Bidder shall be
forfeited and the printer will not be entitled to any compensation. The suite for damages
to the University may also be filed.
38. Entire quantity of printed material should be delivered at MPDD godown, UOU,
Haldwani strictly in stipulated time. If 20 days supplying period is given in printing
order, days will be counted from the date of issue of work order till 20th working day upto
5:00 p.m. of office time.

7|P age

<!-- page 8 -->

39. The printer shall deliver the books/prospectus in sets of 25. Printed material will be duly
packed in craft/plane paper and tied with jute strings or machine strappings strong
enough to bear the weight of the bundle. The bundles are to be kept at the directed place
in MPDD Unit of the University.
40. The losses, damages and shortages in transit or otherwise shall be borne by the printer.
41. The printer will supply original CD and finally formatted CD of printed material in
PDF format to the University at the time of submitting the bills otherwise no
payment will be made.
42. In case of misuse of positives/negatives, illustrations, original designs, art-pulls or butter
prints prepared by the press, the University has the right to take possession of such
materials which belong to the University.
43. All the books must be printed by offset printing process only. Books/Prospectus will be
prepared by Perfect Binding.
44. The Security deposit can be forfeited by the order of the Vice-Chancellor, Uttarakhand
Open University, Haldwani in the event of any breach or non- observance of any of the
conditions of contract, sufficient to cover an incorrect or excess payment made on the
bills of the printer.
45. The rates once accepted by the university will remain valid till completion of the
agreement. No increase or decrease will be considered .
46. The copyright of every book shall always rest solely with the University. The printer
is not allowed to use or manipulate any matter or part of any book in any other
manner otherwise action will be taken for blacklisting the firm and lodging the FIR
against the firm.
47. CONTRACT PERIOD: The Contract (the schedule of minimum rates finalized from the
lowest quoted rates by firms) would be valid for a period of one year. It may be extended
by one more year or it may also be curtailed by the University at its sole discretion, with
the approval of competent authority.
48. In matters of interpretation of technical specifications, terms and conditions of
agreement. The decision of the University shall be final and binding upon the contracters.
49. Income Tax and other taxes shall be deducted from the bills of the parties as per rules.
50. The decision of the Vice-Chancellor, UOU, Haldwani shall be final in case of any dispute
regarding the tender.
8|P age

<!-- page 9 -->

51. Quantity and cost of work may be increased or decreased as per the decision of the
University. The expected volume of entire work of the University may range between 5
to 10 crores.
52. Bidder will undertake to treat the agreement and all its terms as confidential. The bidder
shall not disclose it to any third party during the continuance of the terms of this
agreement without prior written consent of the university.
53. In addition to above the Rules of State Government, as amended from time to time by
the Govt. of Uttarakhand shall also be applicable.
54. TDS shall be deducted as per rules of the Central Government.
55. The agreement to be entered into shall be governed, construed and enforced in
accordance with the laws of India.
56. Termination of the agreement for any cause shall not release the contracter from any
liability which at the time of termination has already accrued to another or which
thereafter may accrue in respect of any act or omission prior to such termination.
57. Jurisdiction of all disputes, if any, will be the district of Nainital (Uttarakhand).
58. Only a printer fulfilling the conditions as on the last date of submission of tender should
submit in the tender published by the University for printing and supply of printed
Books/Prospectus etc.
59. The Printers must have their own printing press fully equipped with the minimum
requirements of the following machineries and equipments substantiated with evidences:(a) One four colour offset Printing Machine.
(b) Two Single colour offset Printing Machines.
(c) Folding, Pasting and Binding Machines.
60. Printers registered under various State and Central Acts in India, who have the capacity
of printing and binding of 20,000 books prepared by perfect binding in a month’s time
need to participate. Bidder must have the minimum experience of two years of
providing books to a University, Govt./Semi-Govt./Govt. recognized/ autonomous
institutions.
61. This notification is only for the EMPANELMENT of offset printers.

Registrar
9|P age

<!-- page 10 -->

UTTARAKHAND OPEN UNIVERSITY
University Road, Behind Transport Nagar (Teenpani bypass),
Haldwani, Nainital, Uttarakhand

TECHNICAL BID

S.N.

Items

Particulars

(FORM-A)

Encl No.

1
Particulars of the firm:

(i)

Name of the firm

(ii)

Type of firm
(Individual/Firm/Society/LLP/Company)

(iii) Name of the key person/persons
(iv) Phone Nos. of the key person/persons
(v)

Phone Nos./e-mail ids of the
firm/individuals

(vi) Location/Address of plant
(vii) Location/Address of Office
(viii) PAN of firm/Individual

Encl. No. 1

(ix) TIN of the firm

Encl. No. 2

(x)

Encl. No. 3

Copy of industrial Licence

(xi) Registration/Incorporation Certificate

Encl. No. 4

10 | P a g e

<!-- page 11 -->

2

Particulars of the Bank a/c
(i)
(ii)

Name of the Bank
Address of the Branch

(iii) A/c No.
(iv) Type of a/c
3

(v) IFS Code
EMD of Rs. 1,00,000 /- enclosed in the
Encl. No. 5

prescribed Form C
4

Experience
(i)

Copies of work award letter for
undertaking similar work in Govt. or
other Departments/State/PSUs. List of
Encl. No. 6

Clints to whom the firm is rendering its
service for the last 2 years. . (Certificate
issued by an officer not below the rank
of Section Officer).
(ii)

Certificate regarding the capacity to
print at least 20,000 books in a month’s

Encl. No. 7

time.
5

Proof regarding 1(one) four colour offset
printing machine, 02(two) single colour offset
Encl. No. 8

printing machines and other machines as per
para 59 of tender document.
6

Details of the Machines
(i) Offset Machines
S.No. Name of Machine

Make

Size

Speed/Hour

Color
System

1.
2.
3.
4.
5.
11 | P a g e

<!-- page 12 -->

(ii) Details of other Machines
S.No. Name of Machine

7

Make

Size

Speed/Hour

Other
Particulars

1.
2.
3.
4.
5.
Details of annual turnover of Rs. 50 lakhs of
the firm for the last 2 years (with proof) for the
year 2014-2015 & 2015-2016 in the form of
CA’s certificate/Last 2 years profit and loss a/c
of the firm.

8

(i)

For 2014-15

Encl. No. 9

(ii)

For 2015-16

Encl. No. 10

Copy of latest Income Tax Return for the year
of 2014-2015 and 2015-2016 (both the years).

9

(i)

For 2014-15

Encl. No. 11

(ii)

For 2015-16

Encl. No. 12
Encl. No. 13

Self –declaration certificate that the firm has
never been blacklisted.

10

Encl. No. 14

Declaration Certificate on a Stamp paper of
Rs. 100/- (Performa given in Form D of
Tender document).

Date :
{SIGNATURE & STAMP OF BIDDER}
PLEASE READ THE MANDATORY INSTRUCTIONS ON THE NEXT PAGE.

12 | P a g e

<!-- page 13 -->

N.B. : Please ensure that;
(i)

All the rates quoted must be ‘F.O.R.’ Uttarakhand Open University, Haldwani.

(ii) All the enclosures/documents being submitted must be duly sealed and signed by the
authorized signatory, otherwise the technical bid may be rejected.
(iii) The rates quoted in the ‘Financial Bid’ must exactly be in the same manner as given in
the Proforma B.
(iv) Two sealed envelopes are to be made, i.e., one for the ‘Technical Bid’ and another one
for the ‘Financial Bid’. Both these envelopes are to be properly sealed before keeping
these two envelops in the outer/bigger envelope.
(v) The caption, “For Empanelment for Printing Work”, and proper name and address of
the firm must be given on the outer big envelope containing the two separate envelopes
of technical bid and financial bid.
(vi) The tender will be accepted ONLY BY SPEED POST.

13 | P a g e

<!-- page 14 -->

UTTARAKHAND OPEN UNIVERSITY
University Road, Behind Transport Nagar (Teenpani bypass),
Haldwani, Nainital, Uttarakhand

FINANCIAL BID

(FORM -B)

Nature of Work: Printing of SLM
Printing and supply of Self Learning Material (SLM) on paper size 8.5”x 11” in 70 GSM
Maplitho Paper of A Grade and 180 GSM Art and Chromo paper for Cover Page including
perfect binding and one side lamination (1 and 4 pages) Cover page will be in four color. Mainrunning text will be in single color (Black).
Rates quoted will be per printed page including paper cost. No blank page will be counted for
payment. (amount will be calculated in Paisa per page up to two decimal only (excluding all
taxes). Tax will be paid as per state government rules.
Example: Valid 0.20 0.12 Invalid: 0.213 0.2341
Quantity/
No. of
pages

100
copies

250
copies

500
copies

1000
copies

2000
copies

(Amount in Rs)

(Amount in
Rs)

(Amount in
Rs)

(Amount
in Rs)

(Amount
in Rs)

3000
copie
s
(Amoun
t in Rs)

5000
copies
(Amount
in Rs)

1000
0
copie
s

2000
0
copi
es

(Amoun
t in Rs)

(Amou
nt in
Rs)

More
than
20000
copie
s
(Amount
in Rs)

Upto 100
pages
Upto 200
pages
Upto 250
pages
Upto 300
pages
Upto 350
pages
Upto 400
pages

Date :
{SIGNATURE & STAMP OF BIDDER}

14 | P a g e

<!-- page 15 -->

Nature of Work: Printing of Prospectus
Printing and supply of prospectus on paper size 8.5”x 11” in 70 GSM Maplitho Paper of A
Grade and 180 GSM Art and Chromo paper for Cover Page including perfect binding and
one side lamination (1 and 4 pages). Cover page will be in four colors. Main -running text will
be in single color (Black). Each admission form attached with prospectus will be given Numbering
and Perforation. Rates quoted will be per printed page including paper cost. No blank page will
be counted for payment. (Amount will be calculated in Paisa per page up to two decimal only
(excluding all taxes). Tax will be paid as per state/central government rules.
Example: Valid 0.20 0.12 Invalid: 0.213 0.2341
Quantity/No.
of pages

100
copies

250
copies

500
copies

1000
copies

2000
copies

3000
copies

5000
copies

10000
copies

20000
copies

More
than
20000
copies

Upto 100
pages
Upto 200
pages
Upto 250
pages
Upto 300
pages

Date :
{SIGNATURE & STAMP OF BIDDER}

15 | P a g e

<!-- page 16 -->

Nature of Work: Printing of Annual report and miscellaneous items etc
Printing and supply of Annual report and miscellaneous items etc on paper size 8.5”x 11” in
110 GSM Art Paper and 230 GSM Art and Chromo paper for Cover Page including perfect
binding and one side lamination (1 and 4 pages). Cover page and main-running text will be in
four colors. Rates quoted will be per printed page including paper cost. No blank page will be
counted for payment. (amount will be calculated in Paisa per page up to two decimal only
(excluding all taxes). Tax will be paid as per state/central government rules.
Example: Valid 0.20 0.12 Invalid: 0.213 0.2341
Quantity/No.
of pages
Upto 100
pages
Upto 200
pages
Upto 250
pages
Upto 300
pages
Upto 350
pages
Upto 400
pages

100 copies

250 copies

500 copies

1000 copies

Nature of Work: Designing of Cover page & typesetting
Designing of Cover Page
Typesetting per page

Date :
{SIGNATURE & STAMP OF BIDDER}

16 | P a g e

<!-- page 17 -->

EMD

(FORM- C)

Tender No.:_________________
Date: _________
To,
The Registrar,
Uttarakhand Open University,
University Road, Behind Transport Nagar (Teenpani bypass),
Haldwani, Nainital, Uttarakhand.
Dear Sir,
1. We, undersigned, offer to supply printing items in conformity with the conditions of
contract and specifications for the sum shown in the schedule of prices attached herewith
and made part of this Bid.
2. We undertake, to enter into agreement within one week of being called upon to do so and
bear all expenses including charges for stamps etc and agreement will be binding on us.
3. If our Bid is accepted, we will deposit an amount equal to 2% of the contract sum in the
form of Demand draft or in the form of a bank guarantee for due performance of the
Contract.
4. We agree to abide by this Bid for a period of 60 days from the date fixed for Bid opening
and it shall remain binding upon us.
5. Bid submitted by us is properly sealed and prepared so as to prevent any subsequent
alteration and replacement. Along with the bid, we have submitted EMD of Rs. 10,000/in the form of Demand draft in favour of Uttarakhand Open University.
Dated this____________Day of _______________2017
Signature of
In capacity of
Duly authorized to sign the bid for and on behalf of ___________
Witness________________
Address_________________________________ Signature
17 | P a g e

<!-- page 18 -->

DECLARATION FORM

(FORM-D)

I________________________________Son/Daughter of __________________________
w/o___________________________hereby confirm and declare that my/our firm/company
M/s……………………………………..is not blacklisted/delisted or debarred or on Holiday
list with any Private/Public Ltd. company or of Government Company/Govt. Deptt. from
participating in any tendering process as on date.

In case at any stage, it is found that the information given by me is false/incorrect,
Uttarakhand Open University, Haldwani have the absolute right to take any action as deemed
fit/without any prior intimation to me.

Sign:
For and on behalf of the Bidder
Seal of the Firm.

Name

: _________________________

Position

: _________________________

Date

: _________________________

18 | P a g e
