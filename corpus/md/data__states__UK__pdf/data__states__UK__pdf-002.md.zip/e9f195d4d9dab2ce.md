---
doc_id: "e9f195d4d9dab2ce"
source_url: "https://www.kmvn.in/medias/tender_document/tender100708717794245334955971879175858_258872651.pdf"
ministry: "Kumaon Mandal Vikas Nigam Ltd., Uttarakhand"
title: ""
date: ""
pages: 18
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9ba270e0571a3368"
---

<!-- page 1 -->

dqekÅW e.My fodkl fuxe fy0]
vksd ikdZ gkml] eYyhrky] uSuhrkyA
bZ&fufonk gsrq vkea=.k izi=
mRrjk[k.M ‘kklu] vkS|ksfxd fodkl vuqHkkx&1 dh vf/klwpuk l[;k 977/VII-A-1/2023-24[k/2007
fnuakd 16 twu] 2023 ds }kjk iz[;kfir mRrjk[k.M mi&[kfut ¼ifjgkj½ fu;ekoyh&2023 ,oa ‘kklukns’k
la[;k&1561@VII-1@80&[k@2016 fnukWd 30 flrEcj] 2016 ;Fkkla’kksf/kr ‘kklukns’k la[;k& 621@VII-A-1@80
[k@16 Vh0lh0 nsgjknwu fnukWd 4 twu] 2020 rFkk vf/klwpuk la[;k&96@VII-A-1@23&24[k@2007 fnukWd 20 tuojh]
2023 ,ao ‘kklukns’k la[;k& 1874@VII-A-1@2024@05¼27½@2020 fnukWd 21 vDVwcj] 2024 }kjk izLrkfor fu;eksa ds
vuqlkj dqekÅW e.My fodkl fuxe fy0 }kjk fu/kkZfjr vk/kkj ewY; ds Åij mPpre cksyh gsrq tuin ckxs’oj]
rglhy&didksV {ks=kUrxZr jktLo mi [kfut {ks=] tudqM+h [kM+xsMk ¼1-500 gSDVs;j½ es mi [kfut ds pqxku gsrq
bZ&fufonk vkeaf=r dh tkrh gSA
mDr ykWV fnukWd 20 vDVwcj] 2029 rd fuxe ds i{k esa LOkhd`r gSA fuxe }kjk dsoy fnukWd 20 vDVwcj] 2029
rd dh vof/k ds fy;s mi [kfut ds pqxku gsrq fufonk vkeaf=r dh tk jgh gSA
fufonk ls lEcfU/kr egRoiw.kZ frfFk;kW%&
foKkiu izdk’ku dh frfFk
fnukad 22 ebZ] 2026
uktenders.gov.in ij fufonk viyksM dh frfFk ,oa le; fnukad 22 ebZ] 2026] le; 10-00 cts
uktenders.gov.in ls fufonk MkmuyksM vkjEHk djus dh
fnukad 22 ebZ] 2026] le; 10-30 cts
frfFk ,oa le;
izhfcM ehfVax gsrq frfFk ,oa le;
fnukWd 26 ebZ] 2026] le; 13-00 cts
vkWuykbu bZ&fufonk tek djus gsrq vkjEHk frfFk
fnukad 29 ebZ] 2026] le; 10-00 cts
vkWuykbu bZ&fufonk tek djus dh vfUre frfFk ,oa le; fnukad 06 twu] 2026] le; 13-00 cts rd
rduhdh fufonk [kksyus rFkk bZ&fufonk ds fnukad 06 twu] 2026] le; 13-30 cts
ijh{k.k@ewY;kdau vkjEHk fd;s tkus dh frfFk ,ao le;
lfefr }kjk Rkduhdh fufonk ds ijh{k.k@ewY;kadu ds mijkUr lQy fufonknkrkvksa dh lwph jkT; ljdkj dh
oSclkbV www.uktenders.gov.in esa viyksM djrs gq;s foRrh; fufonk [kksyus dh frfFk ,oa le; fu/kkZfjr fd;k
tk;sxkA
leLr izfrHkkxh fufonknkrkvksa dks lwfpr fd;k tkrk gS fd fufofnr [kuu ykWV ,oa fufonk dh izfØ;k dk foLr`r
fooj.k rduhdh fufonk (Technical Bid) rFkk foRrh; fufonk (Financial Bid) izi= esa fd;k x;k gSA mDr fufonk
izi= fdlh Hkh dk;Zfnol eas dqekÅW e.My fodkl fuxe fy0 ds eq[; dk;kZy;&[kuu vuqHkkx] vksd ikdZ gkml]
eYyhrky] uSuhrky rFkk jkT; ljdkj dh osclkbZV www.uktenders.gov.in ,oa foHkkxh; osclkbZV kmvn.in ls
MkmuyksM dj Hkh izkIr fd;k tk ldrk gS] ftl gsrq :0 30]000-00 ¼rhl gtkj ek=½ ¼th0,l0Vh0lfgr½ ‘kqYd fuxe
eq[;ky;@,u0bZ0,Q0Vh0 ds ek/;e ls fuxe ds [kkrs tek fd;k tkuk vko’;d gksxkA fufonk izi= Ø; fd;s tkus gsrq
tek /kujkf’k izek.k dh izfr rduhdh fufonk (Technical Bid) ds lkFk Hkh viyksM dh tkuh vko’;d gksxh ,oa fufonk
izsf”kr fd;s tkus dh vfUre frfFk ,oa le; ls iwoZ fuxe eq[;ky; esa ewy izfr tek dh tkuh vko’;d gksxhA lHkh
fufonknkrkvksa ls vis{kk dh tkrh gS fd mDrkuqlkj fufonk izi= izkIr dj mldk Hkyh Hkkafr v/;;u djus ds mijkUr gh
fufonk izfØ;k esa izfrHkkx djuk lqfuf’pr djsaA vLi”V ,oa viw.kZ fufonk izi=ksa@vkosnuksa ij fopkj ugh fd;k tk;sxkA
izcU/k funs’kd
1

<!-- page 2 -->

Lkkfj.kh
bZ&fufonk lg
bZ&fufonk izk:i ds
Hkkx
Hkkx&1
Hkkx&2
Hkkx&3
Hkkx&4
Hkkx&5

bZ&fufonk izk:i ds Hkkx dk fo"k;
fufonknkrk gsrq lkekU; fn'kk&funsZ'k
bZ&fufonk dh rduhdh fof’k”Vrk;sa] ‘krsZ ,oa izfrcU/k
mi[kfutksa ds pqxku@[kuu gsrq rduhdh fufonk gsrq izi= dk izk:i
mi[kfutksa ds pqxku@[kuu gsrq foRrh; fufonk dk izk:i
bZ&fufonk gsrq opuc)rk dk çi=

2

Ik`"B la[;k
3 ls 5
6 ls 14
15 ls 16
17
18

<!-- page 3 -->

Hkkx&1
fufonknkrk gsrq lkekU; fn'kk&funsZ'k
1- leLr fufonknkrkvksa ls vis{kk dh tkrh gS fd os fufofnr [kuu ykWV dk Hkyh&Hkkafr Lo;a fujh{k.k dj ysa
rFkk fufofnr [kuu ykWV dh oLrq fLFkfr] mi[kfut dh ek=k ,oa fudklh ekxZ vkfn ds ckjs esa iw.kZ tkudkjh
izkIr dj] vk’oLr gksus ds mijkUr gh fufonk dh dk;Zokgh esa izfrHkkx djsaA fufonk esa izfrHkkx djus ds
mijkUr dHkh Hkh ;fn fufofnr [kuu ykWV ds lEcU/k esa fdlh izdkj dh O;ogkfjd dfBukbZ;k mRiUu gksrh gS
rks bl gsrq fufonknkrk Lo;a mRrjnk;h gksxkA
2- mRrjk[k.M mi&[kfut ¼ifjgkj½ fu;ekoyh&2023 ds vuqlkj jkT; {ks=kUrxZr unh ry jktLo@ou Hkwfe esa
fu;e&20 ¼2½ ds v/khu fpfUgr@foKkfir mi[kfut ykWVksa 5 gS0 rd ds [kuu iV~Vs jkT; ds ewy
fuoklh@fuokfl;ksa dh lfefr;ksa@QeZ@dEifu;kas ,oa 5 gS0 ls vf/kd {ks=Qy ds [kuu iV~Vs Hkkjr ds
ukxfjd@ukxfjdksa dh lafefr;ksa@QeZ@dEifu;ksa dks ifjgkj ij Lohd`r djus dh izfØ;k vkWuykbu bZ&fufonk
ds ek/;e ls rduhdh fufonk (Technical Bid) ,oa foRrh; fufonk (Financial Bid) ij vk/kkfjr gksxh]
ftlesa rduhdh fufonk ,oa foRrh; fufonk dh dk;Zokgh www.uktenders.gov.in ij dh tk;sxhA orZeku esa
jktLo ykWV tudqM+h [kM+xsMk ¼1-500 gSDVs;j½ fnukWd 20 vDVwcj] 2029 rd ‘kklu }kjk fuxe ds i{k esa
Lohd`r fd;k x;k gSA fuxe }kjk dsoy fnukWd 20 vDVwcj] 2029 rd pqxku dk;Z gsrq fufonk;sa vkeaf=r dh
tk jgh gSaA
3- bZ&fufonk izfdz;k esa izfrHkkx djus gsrq www.uktenders.gov.in esa iathdj.k izfdz;k lEiUu djus ,oa
lEizsf”kr leLr lwpukvksa dh ftEesnkjh bPNqd fufonknkrk@cksyhnkrk dh gksxhA fuxe blds fy, ftEesnkj
ugha gksxasA
4- bZ&fufonk gsrq www.uktenders.gov.in ij iathdj.k djrs le; bPNqd fufonknkrk ¼5-00 gS0 rd ds
[kuu ykWV gsrq½ jkT; ds ewy fuoklh@fuokfl;ksa dh lfefr;ksa@QeZ@dEifu;kas ,oa ¼5-00 gS0 ls vf/kd
{ks=Qy ds [kuu ykWV gsrq½ Hkkjr ds ukxfjd@ukxfjdksa dh lafefr;ksa@QeZ@dEifu;ksa }kjk foMlZ (Bidders)
dk uke@QeZ okys QhYM esa LFkk;h fuokl@LFkk;h fuokfl;ksa dh lfefr] tks dksvkWijsfVo lkslkbVh ,DV]
dEiuh ,DV vFkok ikVZujf’ki ,DV ,oa vU; lqlaxr vf/kfu;eksa ds vUrxZr iathd`r gks] ¼tSlh fLFkfr gks½ ds
uke] ‘kq)rk ,oa lko/kkuhiwoZd vafdr fd;k tkuk vko’;d gksxkA xyr vFkok =qfViw.kZ vadu ls fufonk
fujLr dj nh tk;sxh] ftlds fy, os Lo;a ftEesnkj gksaxsA
5- bPNqd fufonknkrk@cksyhnkrk ;g lqfuf’pr dj ysa fd mlds dEI;wVj esa ^^tkok^^ (JRE) lk¶Vos;j dk oS/k
otZu vko’;d :Ik ls yksM gksA oS/k otZu www.uktenders.gov.in ls MkmuyksM Hkh fd;k tk ldrk gSA
6- bPNqd vkosndksa ds fy;s vkWuykbZu fcM@cksyh gsrq fMthVy flXuspj lfVZfQdsV ¼ DSC½ gksuk vko’;d gSA
izR;sd izfrHkkxh cksyhnkrk vius fMftVy flXuspj lfVZfQdsV ds ikloMZ dh xksiuh;rk cuk;s j[kus gsrq
mRrjnk;h gksxkA
7- leLr izfrHkkxh fufonknkrk bZ&fufonk esa izfrHkkx djus ls iwoZ bUVjusV dusfDVfoVh rFkk vU; vko’;d
lqfo/kkvksa dh miyC/krk lqfuf’pr dj ysaA rduhdh ,ao foRrh; fufonk tek djrs le; ;fn bUVjusV usVodZ
dusfDVfoVh vFkok vU; fdlh dkj.k ls fufonk viyksM@tek ugh gksrh gS rks] bldk lEiw.kZ mRrjnkf;Ro
fufonknkrk dk gksxk rFkk bldk fufonk dh dk;Zokgh ij dksbZ izfrdwy izHkko ugh iM+sxkA
8- fufofnr [kuu ykWV ds fy, dqy vk/kkj ewY; = mi[kfut dh ek=k ¼Vu esa½ X ykV gsrq fuxe }kjk fu/kkZfjr
fufonk nj izfr Vu ¼:0 135-50 izfr Vu½ gksxk rFkk dqy vk/kkj ewY; ds 25 % ds lerqY; /kujkf’k] /kjksgj
/kujkf’k (Earnest Money) gksxhA lQy fufonknkrk }kjk fuxe }kjk fu/kkZfjr fufonk nj izfr Vu
:0 135-50 izfr Vu ds Åij njs izsf”kr dh tkuh gksxhA fufonkdkj }kjk izsf”kr fufonk njksa esa th0,l0Vh0 o
Vh0lh0,l0 dk Hkqxrku fuxe dks vfrfjDr :Ik ls fd;k tkuk gksxk A
3

<!-- page 4 -->

9- lQy fufonknkrk }kjk okf”kZd fu/kkZfjr /kujkf’k dk Hkqxrku fuxe }kjk fu/kkZfjr fd’rksa ds vuq:Ik fd;k tkuk
gksxkA fd’r Hkqxrku gsrq fuxe }kjk fu/kkZfjr le; vof/k ds vUrxZr fd’r dk Hkqxrku u fd;s tkus dh n’kk
esa izcU/k funs’kd] dqekÅW e.My fodkl fuxe fyfeVsM dks lQy fufonknkrk dh fuxe esa tek izfrHkwfr
/kujkf’k dks tCr djrs gq, iV~Vk lapkyu gsrq xfBr vuqcU/k dks fujLr djus] fufonkdkj dks fu/kkZfjr vof/k
gsrq dkyh lwph esa Mkyus rFkk ykWV esa mi [kfut ds pqxku gsrq i`Fkd ls dk;Zokgh djus dk vf/kdkj lqjf{kr
gksxkA
10- orZeku esa fuxe }kjk ‘kklu }kjk fu/kkZfjr jk;YVh ,oa vU; ‘kqYdksa rFkk njksa bR;kfn ds vuq:Ik fufonk ds
vk/kkj ewY; dk fu/kkZj.k fd;k x;k gSA Hkfo”; esa ‘kklu@vU; foHkkx }kjk fu/kkZfjr jk;YVh ,oa vU; ‘kqYdksa
rFkk njksa bR;kfn esa ;fn dksbZ lalks/ku fd;k tkrk gS] rks ml n’kk esa lQy fufonkdkj dh fufonk njsa Hkh
rn~uq:Ik lalksf/kr dh tk;sxh] ftldk Hkqxrku djus ij lQy fufonkdkj dks dksbZ vkifRr ugha gksxhA
11- fufonknkrk }kjk vius Digital Signature Certificate (DSC) dh lgk;rk ls fufofnr [kuu ykWV dh
rduhdh fufonk leLr vfHkys[kksa lfgr fufonknkrk@vf/kd`r O;fDr ds }kjk gLrk{kj ds lkFk PDF Format
esa rS;kj dj www.uktenders.gov.in viyksM dh tk;sxhA
12- fufonknkrk }kjk www.uktenders.gov.in ls foRrh; fuoknk dk izk:i BOQ (Excel Format) MkmuyksM
fd;k tk;sxkA fufonk ds fu/kkZfjr izk:i BOQ esa fufonknkrk }kjk la’kks/ku@izfrLFkkiu ugha fd;k tk;sxk
rFkk lEcfU/kr dkWye Hkjus ds ckn www.uktenders.gov.in ij viyksM fd;k tk;sxk] vU;Fkk fufonknkrk
foRrh; fufonk ds vLohdkj fd;s tkus gsrq mRrjnk;h gksxkA BOQ esa fufonknkrkvksa dks dsoy fufonknkrk dk
uke vkSj ewY; ntZ djus dh vuqefr gksxhA
13- foRrh; fufonk dh dk;Zokgh iw.kZ gksus ,ao lQy cksyhnkrkvksa ¼H-1 ls H-3 rd½ dh Øeokj ?kks”k.kk fd;s
tkus ds mijkUr loZizFke foRrh; fufonk dsa lQy cksyhnkrkvksa esa H-1 cksyhnkrk dks muds }kjk izLrqr
mPpre fufonk njks ds vuqlkj vkaxf.kr /kujkf’k dk 25 % ds lerqY; /kujkf’k ¼iwoZ esa tek /kjksgj jkf’k
(Earnest Money) dh /kujkf’k ds vfrfjDr vo’ks”k /kujkf’k½ izfrHkwfr /kujkf’k (Security Money) ds :Ik
esa lkr dk;Zfnolksa esa ,Q0Mh0vkj0 ds :Ik esa tek djkus dk volj iznku fd;k tk;sxkA H-1 cksyhnkrk }kjk
fu/kkZfjr le;kUrxZr ;fn mDr /kujkf’k tek ugha djkbZ tkrh gS rks lEcfU/kr dh tek vusZLV euh (Earnest
Money) dh /kujkf’k dks tCr djrs gq, muds fo:) fu;ekoyh ds fu;e&23 ¼2½ ds vuqlkj dk;Zokgh dh
tk;sxh rFkk dksfVØe esa H-2 cksyhnkrk dks H-1 cksyhnkrk }kjk cksyh x;h mPpre cksyh ij [kuu iV~Vk fy;s
tkus rFkk mPpre cksyh dh /kujkf’k dk iPphl izfr’kr ds lerqY; /kujkf’k ¼iwoZ esa tek /kjksgj /kujkf’k
(Earnest Money) dh /kujkf’k ds vfrfjDr vo’ks”k /kujkf’k½ izfrHkwfr /kujkf’k (Security Money) ds :Ik
esa lkr dk;Zfnolksa esa ,Q0Mh0vkj0 ds :i esa tek djkus dk volj iznku fd;k tk;sxkA mDr izfØ;k
dksfVØe esa H-3 rd viukbZ tk;sxhA H-3 }kjk fu/kkZfjr le;kUrxZr mDrkuqlkj vuqikyu u fd;s tkus dh
n’kk esa bZ&fufonk dh izfØ;k dks lekIr ?kksf”kr djrs gq, iqu% bZ&fufonk dh dk;Zokgh dh tk;sxhA
14- fufonk izi= ds Hkkx&3 rduhdh fufonk pSd fyLV esa visf{kr leLr vfHkys[k fufonknkrk ds }kjk
LogLrk{kfjr gksus vfuok;Z gS] QeZ@dEiuh@lkslkbVh@lfefr ds ekeys esa fufonk izi= ds mDr vfHkys[kksa ij
vf/kd`r O;fDr ds gLrk{kj eksgj lfgr gksus vfuok;Z gS] bl gsrq O;fDr@QeZ ds Hkkxhnkj@dEiuh ds izcU/k
funs’kd@funs’kd@lkslkbVh ds v/;{k@mik/;{k@lfpo@lfefr ds v/;{k@mik/;{k@lfpo ds }kjk fyf[kr
:i ls vf/kd`r fd;s tkus lEcU/kh izek.k i= rduhdh fufonk ds lkFk izLrqr fd;k tk;sxkA rduhdh fufonk
esa okafNr vfHkys[kksa dh tkap ds mijkUr] vfHkys[kksa ds iw.kZ ik;s tkus ij lQy fufonknkrkvksa dh gh foRrh;
fufonk (Financial Bid) [kksyh tk;sxhA vLi”V ,oa viw.kZ vfHkys[kh; fufonkvksa ij fopkj ugh fd;k tk;sxkA
15- bZ&fufonk dh izfØ;k ds nkSjku ,slk izdj.k ftldk mYys[k bl fufonk izi= esa of.kZr fd;k tkuk jg x;k gks
vFkok iw.kZr% Li”V u fd;k tk ldk gks vFkok ,slk lelkef;d izdj.k tks [kfut fodkl ,ao jktLo fgr esa
4

<!-- page 5 -->

vko’;d gks] ,sls izdj.kksa esa izcU/k funs’kd] dqekÅW e.My fodkl fuxe fyfeVsM vfUre fu.kZ; ysus gsrq
izkf/kd`r gS rFkk muds }kjk rRlEcU/kh vU; ‘kklukns’kksa@vuqns’kksa dk vuqlj.k dj O;k[;kfir djrs gq, fu.kZ;
fn;k tk ldsxk] izcU/k funs’kd] dqekÅW e.My fodkl fuxe fyfeVsM dk fu.kZ; vfUre gksxk ,ao loZ i{kksa dks
ekU; gksxkA
16- fufofnr {ks= esa [kuu@pqxku dk;Z eSuqvy fof/k ls fd;k tkuk gS] ds n`f”Vxr lQy fufonknkrk fufofnr
{ks= eas [kuu@pqxku gsrq Je’kfDr dh O;oLFkk Lo;a iw.kZ lsa miyC/k djkuk lqfuf’pr djsxk] Je’kfDr ds
vHkko esa [kuu@pqxku dks izHkkfor ugha ekuk tk;sxkA
17- fufonknkrk futh O;fDr@QeZ@lfefr@lkslkbVh ds }kjk foxr 03 o”kksZ dh vkbZVhvkj ds izfr izLrqr djuh
vko’;d gksxhA
18- fufofnr {ks= ls [kfut dh okf”kZd fu/kkZfjr ek=k dh iw.kZ fudklh u gksus ij vo’ks”k fudklh dh ek=k dks
vxzsRrj [kuu o”kZ esa lek;ksftr ugha fd;k tk;sxk rFkk fufonknkrk ds }kjk mDr o”kZ dh lEiw.kZ iV~Vk
/kujkf’k tek dh tk;sxhA
19- bl fufonk ds lEcU/k esa dksbZ Hkh U;kf;d fookn gksus dh n’kk esa fookn dk U;kf;d {ks= uSuhrky gksxkA
20- fufonk dh leLr dk;Zokgh ¼izh&fcM] rduhdh fufonk ,oa foRrh; fufonk ewY;akdu½ fu/kkZfjr frfFk;ksa esa
dqekÅW e.My fodkl fuxe fy0 ds eq[; dk;kZy;&vksd ikdZ gkml] eYyhrky] uSuhrky esa lEiUu dh
tk;sxhA ftlesa fufonknkrk Lo;a vFkok vius vf/kd`r izfrfuf/k ds ek/;e ls izfrHkkx dj ldrk gSA
21- izcU/k funs’kd] dqekÅW e.My fodkl fuxe fyfeVsM dks ,d vFkok leLr fufonkvksa dks fcuk dkj.k crk;s
fujLr djus dk rFkk fdlh Hkh pj.k esa fufonk izfdz;k dks jn~n djus dk iw.kZ vf/kdkj gksxkA
22- ;g fufonk ekuuh; mPp U;k;ky;@mRrjk[k.M ‘kklu@[kuu funs’kky; nsgjknwu ds funsZ’kksa ds v/khu jgsxhA
fufonk dks Lohd`r@fujLr djus vFkok ykWV esa pqxku dk;ksZ ds lEcU/k esa le;&le; ij ekuuh; mPp
U;k;ky; uSuhrky@l{ke U;k;ky;@mRrjk[k.M ’kklu@[kuu funs’kky; nsgjknwu }kjk ikfjr funsZ’k lQy
fufonkdkj dks ekU; gksaxsA

5

<!-- page 6 -->

Hkkx&2
bZ&fufonk dh rduhdh fof’k”Vrk;sa] ‘krsZ ,oa izfrcU/k
(Technical Specifications)

1- bZ&fufonk gsrq vgZrk;sa%&

bZ&fufonk gsrq unhry fLFkr jktLo Hkwfe ds 5-00 gS0 rd ds [kuu iV~Vs jkT; ds ewy fuoklh@fuokfl;ksa dh
lfefr;ksa@QeZ@dEifu;kas ,oa 5-00 gS0 ls vf/kd {ks=Qy ds [kuu iV~Vs Hkkjr ds ukxfjd@ukxfjdksa dh
lafefr;ksa@QeZ@dEifu;ksa dks Lohd`r fd;s tk;saxsA
2- bZ&fufonk gsrq fucZU/ku%&
1) fdlh O;fDr dks] tks Hkkjrh; jkf”Vªd ugha gS] ftlds fo:) [kfut ns; cdk;k gS] ftlus ml ftys ds
ftykf/kdkjh vFkok jkT; ljdkj }kjk izkf/kd`r vf/kdkjh] tgka og LFkk;h :i ls fuokl djrk gS] ls pfj=
izek.k i= izkIr u fd;k gks] ftlus vius vk/kkj dkMZ@ernkrk igpku i= dh izfr izLrqr u dh gks] tks
O;fDr@QeZ@dEiuh] fdlh Hkh jkT; esa fu;r frfFk ¼ftl frfFk dks fufonk izfdz;k esa Hkkx fy;k tk;sxk½ dks
CySd fyLVsM (Black Listed)@fMckMZ (Debard) u gks] ds lEcU/k es ‘kiFk&i= fufonk izfdz;k esa Hkkx ysus
gsrq izLrqr u fd;k gks] mDr ds vfrfjDr lEcfU/kr QeZ ,oa dEiuh ds ekeys esa] ftlus isu dkMZ] th0,l0Vh0
iathdj.k izek.k] QeZ dk jftLVªs’ku izek.k i=@eseksjs.Me vkQ vkVhZdy (Memorandum of Article) dh
izfr izLrqr u fd;k gks] bZZ&fufonk dh cksyh cksyus ;k iV~Vs ds fy;s fufonk izfdz;k esa Hkkx ysus dh vuqefr
ugha nh tk;sxhA
2) izfrHkkxh cksyhnkrkvks }kjk cksyh dh /kujkf’k mruh gh cksyh tk;sxh] ftldk og Hkqxrku djus es l{ke gksa]
fufonk dh dk;Zokgh dks izHkkfor djus ds mn~ns’; ls cksyh x;h mPprj /kujkf’k ds vuqlkj] mDr /kujkf’k
tek u djk;s tkus ij lEcfU/kr cksyhnkrk ds }kjk tek vusZLV euh (Earnest Money) dks tCr djrs gq,
lQy cksyhnkrk dks jkT; esa [kuu ykWVksa dh fufonkvksa@[kuu iV~Vk@[kuu vuqKk@Hk.Mkj.k vuqKk@LVksu
Øs’kj vuqKk@LØhfuax IykUV vuqKk izkfIr gsrq 01 o”kZ dh vof/k gsrq izfrcfU/kr djrs gq, dkyh lwph esa Mkyk
tk;sxkA
3) O;fDr@QeZ@lfefr@dEiuh@lkslkbVh vkfn dks foHkkx }kjk [kuu iV~Vs dh vkaxf.kr vf/kdre dqy vk/kkj
ewY; ds ‘kr&izfr’kr gSfl;r ds vuq:i gh [kuu iV~Vk@iV~Vs vkoafVr fd;s tk ldsaxs ;fn lQy cksyhnkrk
}kjk izLrqr gSfl;r mlds lQy gq;s [kuu iV~Vksa ds vk/kkj ewY; ls de ik;h tkrh gS rks lQy ?kksf”kr [kuu
iV~Vs ,oa vU; lQy ?kksf”kr [kuu iV~Vksa ds fy, mldh vgZrk lekIr dj nh tk;sxhA
3- bZ&fufonk izi= izk:i ,oa ‘kqYd&
1) bZ&fufonk izi= ,oa fooj.k fdlh Hkh dk;Zfnol eas dqekÅW e.My fodkl fuxe fy0] eq[; dk;kZy;&vksd
ikdZ gkml] eYyhrky] uSuhrky rFkk jkT; ljdkj dh osclkbZV www.uktenders.gov.in ,oa foHkkxh;
osclkbZV kmvn.in ls MkmuyksM dj Hkh izkIr fd;k tk ldrk gS] ftl gsrq :0 30]000-00 ¼rhl gtkj ek=½
‘kqYd fuxe eq[;ky; eas tek dj jlhn izkIr dh tk ldrh gS] fufonk izi= ‘kqYd vkWu ykbZu Hkh tek fd;k
tk ldrk gS] ftl gsrq fuxe ds [kkrs dk fooj.k fuEukauqlkj gSA
[kkrk/kkjd dk uke& dqekÅW e.My fodkl fuxe fy0
cSad dk uke& Hkkjrh; LVsV cSad] eYyhrky] uSuhrky
[kkrk la[;k& 10860835083
vkbZ0,Q0,l0 dksM& SBIN0000687
1)

6

<!-- page 7 -->

fufonk izi= ‘kqYd tek dh ewy izfr dks fufonk tek djus dh vfUre frfFk ,oa le; ls iwoZ fuxe eq[;ky;
vksd ikdZ gkml] eYyhrky uSuhrky esa tek fd;k tkuk vko’;d gksxk ,oa mDr dh ,d izfr rduhdh
fufonk ds lkFk vkWu ykbZu viyksM Hkh djkbZ tkuh vko’;d gksxhA
4- fufofnr mi[kfut ykWV dk fooj.k&
fufonk dk izfr Vu vk/kkj ewY;&:0 135-50 ¼dj vfrfjDr½
ftyk
Rkglhy ykWV dk uke
dqy
[kuu
jktLo [kuu /kjksgj jkf’k gSfl;r
{ks=Qy ;kstuk ds ykWV
gsrq ¼dqy vk/kkj ¼dqy
¼gS0½
vuqlkj vk/kkj ewY; ewY; dh 25 vk/kkj ewY;
ek=k ¼Vu ¼dj
%½
dh 100%½
esa½
vfrfjDr½
/kujkf’k
Ckkxs’oj
didksV tudqMh&[kVxsMk ¼[kkrk 1-500
81]000 :0 135-50 27]43]875 1]09]75]500
la0 &6 ds [ksr l0&128
izfr Vu ¼dj
e0 ,ao [kkrk l0&10 ds
vfrfjDr½
[kljk l0&06 e0] 07
e0] 08e0½
5- rduhdh fufonk (Technical Bid) ds lkFk fuEufyf[kr vfHkys[k layXu gksxas&
1) vkosnd dk vk/kkj dkMZ@ernkrk igpku i= dh izfr] QeZ dh n’kk esa QeZ ds Hkkxhnkjksa ds vk/kkj
dkMZ@ernkrk igpku i= dh izfr rFkk dEiuh ds ekeys esa dkjiksjsV vQs;lZ ea=ky; Hkkjr ljdkj }kjk
fuxZr dEiuh ds izcU/k funs’kd dk Director Identification Number (DIN) ds izek.k i= dh izfr rFkk
dkWijsfVo lkslkbVh ds lEcU/k esa v/;{k] mik/;{k ,oa lfpo dk vk/kkj dkMZ@ernkrk igpku i= dh izfrA
2) vkosnd ds LFkk;h fuokl izek.k&i= dh izfr] QeZ dh n’kk esa QeZ ds Hkkxhnkjksa ds LFkk;h fuokl izek.k&i=
dh izfr rFkk dkWijsfVo lkslkbVh@lfefr ds lEcU/k esa v/;{k] mik/;{k ,oa lfpo ds LFkk;h fuokl
izek.k&i= dh izfrA
3) vkosnd dk v|kof/kd pfj= izek.k i=] lfefr ds ekeyksa esa lfefr ds v/;{k@lfpo dk pfj= izek.k i=]
QeZ ds ekeys esa lHkh Hkkxhnkjksa dk pfj= izek.k i= ,oa dEiuh ds ekeys es bl vk’k; dk ‘kiFk i= fd
dEiuh dks fdlh vijkf/kd okn esa nf.Mr ugh fd;k x;k gSA pfj= izek.k i= ml ftys ds ftykf/kdkjh
vFkok ftykf/kdkjh }kjk ukfer l{ke izkf/kdkjh }kjk iznRr gksxk] tgka vkosnd LFkk;h :i ls fuokl djrk
gksA
4) vkosnd ds iSudkMZ dh izfrA
5) vkosnd ds th0,l0Vh0,u0 dh izfrA
6) vkosnd ds cSad [kkrs dk fooj.k] ftlls bZ&fufonk ls lEcfU/kr leLr foRrh; gLrkUrj.k fd;k tk;sxk] ;Fkk
cSad o ‘kk[kk dk uke] [kkrk la[;k] vkbZ0,Q0,l0lh0 dksM rFkk ,d fujLr psd dh izfrA
7) funs’kd] HkwrRo ,oa [kfudeZ funs’kky;] mRrjk[k.M }kjk izkf/kd`r vf/kdkjh }kjk fufonk izdk’ku ds mijkUr
fufofnr ykWV gsrq tkjh fd;k x;k v|ru [kuu vns;rk izek.k i=A ;fn vkosnd vius x`g tuin ds
vfrfjDr vU; tuin esa fLFkr [kuu ykWV gsrq bZ&fufonk esa izfrHkkx djrk gS rks vius x`g tuin ds
lkFk&lkFk lEcfU/kr tuin gsrq funs’kd] HkwrRo ,oa [kfudeZ funs’kky;] mRrjk[k.M }kjk izkf/kd`r vf/kdkjh
ls ftl tuin dh fufonk esa izfrHkkx fd;k tkuk gS] rks ml ykWV gsrq [kuu vns;rk izek.k&i= izkIr dh
tkuh vko’;d gksxhA
8) dksijsfVo lkslkbVh ds lEcU/k esa dkWih vkWQ jsT;wys’ku ds leLr i`”Bksa dh Loizekf.kr izfrA Hkkxhnkjh QeZ ds
lEcU/k esa Hkkxhnkjh foys[k ,oa QeZ ds iathdj.k] dEiuh ds ekeys esa vkfVZdy vkQ ,lksf’k;s’ku dh izfrA
7

<!-- page 8 -->

fdlh Hkh jkT; es [kuu lafdz;kvksa dh dkyh lwph esa u gksus lEcU/kh :0 100-00 ds bZ&LVkEi isij ij
uksVjkbZTM ‘kiFk&i= esa izLrqr fd;k tk;sxkA
10) vkosnd o mlds ifjokj ds fo:) [kuu ns;rk gksus ij vkosnu vLohdkj dj fn;k tk;sxkA ifjokj
¼vkosnd ds ekrk] firk] ifr] iRuh] iq=] HkkbZ] vfookfgr iq=h] vfookfgr cgu½ ds lnL;ksa ds fo:) [kuu
vns;rk ds lEcU/k esa vkosnd ds }kjk :0 100-00 ds bZ&LVkEi isij ij uksVjkbTM ‘kiFk i= izLrqr fd;k
tk;sxkA
11) fufonk izi= Ø; fd;s tkus ds lkis{k ‘kqYd :0 30]000-00 ¼rhl gtkj ek=½ ‘kqYd fufonknkrk ds }kjk
fuxe ds i{k esa tek fd;s tkus lEcfU?kr izek.k dh izfrA vkWu ykbZu viyksM ds lkFk ewy izfr fufonk tek
djus gsrq fu/kkZfjr frfFk ,oa le; ls iwoZ fuxe eq[;ky; esa tek dh tkuh gksxhA
12) fufonknkrk ^^futh O;fDr@QeZ@lfefr@dEiuh@lkslkbVh** ds }kjk foxr 03 o”kksZ dh vkbZ0Vh0vkj0 dh
izfrA
13) fufonknkrk ds }kjk bZ&fufonk gsrq opuc)rk ¼Undertaking½ dk izk:i :0 100-00 uksVjkbZTM ‘kiFk&i=
izLrqr fd;k tk;sxkA
14) bZ&fufonk esa izfrHkkx djus gsrq vko’;d vU; vfHkys[k] ‘kqYd ,oa /kujkf’k vkfn%&
i. /kjksgj jkf’k ¼Earnest Money½%& fdlh {ks= ds bZ&fufonk gsrq fcMlZ dks fcM eas Hkkx ysus gsrq /kjksgj
jkf’k (Earnest Money) tek djuk vfuok;Z gksxk] tks fufofnr [kuu ykWV ds dqy vk/kkj ewY; dk
25 % gksxhA /kjksgj jkf’k (Earnest Money) fdlh jk”Vªh;d`r cSad }kjk tkjh ,Q0Mh0vkj0 ds :i esa
tek djk;h tk;sxh] tks izcU/k funs’kd] dqekÅW e.My fodkl fuxe fy0 ds uke ,d o”kZ ¼01 o”kZ½ dh
vof/k gsrq cU/kd gks ewy eas tek dh tk;sxh rFkk mDr dh izfr rduhdh fufonk ds lkFk viyksM dh
tk;sxh rFkk ewy izfr rduhdh fufonk viyksM djus dh vfUre frfFk ,oa le; ls iwoZ fuxe eq[;ky;]
vksd ikdZ gkml] eYyhrky] uSuhrky esa tek djk;h tkuh vko’;d gksxhA /kjksgj jkf’k (Earnest
Money) dh ewy izfr [kuu vuqHkkx fuxe eq[;ky; es tek u fd;s tkus dh n’kk es ,sls vkosnu
rduhdh :i ls xzkg~; ugh gksaxsA
vkosnd }kjk /kjksgj jkf’k (Earnest Money) ds fy;s Lo;a ds [kkrs ls gh ,Q0Mh0vkj0
cuok;h tkuh gksxhA fdlh mi[kfut ykWV ds fy, foKkiu dh iqujko`fRr gksus ij /kjksgj jkf’k ds :Ik esa
tek ,Q0Mh0vkj0 dh oS/krk dh vof/k dks v|ru fd;s tkus dk nkf;Ro vkosnd dk gksxkA rduhdh
fufonk es lQy fufonknkrkvksa ds vfrfjDr vU; fufonknkrkvksa dh /kjksgj jkf’k ds :i es tek dh x;h
,Q0Mh0vkj0 fufonk dh dk;Zokgh iw.kZ gksus ds mijkUr okil dj nh tk;sxhA
ii. gSfl;r izek.k i=%& ftykf/kdkjh ;k ftykf/kdkjh }kjk izkf/kd`r l{ke vf/kdkjh }kjk tkjh dh x;h
gSfl;r izek.k i= ;k lEifRr izek.k&i= ;k lek’ksk/ku {kerk izek.k&i= (Solvency Certificate) tks
vkosfnr [kuu ykWV ds vk/kkj ewY; ls de u gks rFkk QeZ@dEiuh vkfn dh n’kk esa foxr 03 o”kksZ dh
lh0,0 }kjk izekf.kr cSysUl’khV (Balance Sheet) dh izfr ftldk VuZ vksoj ;k usVoFkZ (Net worth)
vk/kkj ewY; ls de u gksA
;k
;fn gSfl;r izek.k&i= v|ru u gks rks] bl ‘krZ ds lkFk vUrfje :i ls Lohdkj fd;k tk;sxk fd
vkosnd bldk ‘kiFk i= izLrqr djsa fd bl nkSjku ¼gSfl;r izek.k&i= dh frfFk ls v|ru½ fufonk
cksyhnkrk ds }kjk layXu gSfl;r izek.k i= esa vafdr py@vpy lEifRr dk foØ;@gLrkUrj.k ugha
fd;k x;k gSA
;k
9)

8

<!-- page 9 -->

gSfl;r izek.k i= ds ,ot esa vkosfnr [kuu {ks= ds vk/kkj ewY; ds cjkcj dh /kujkf’k dh ,Q0Mh0vkj0
¼jk”Vªh;d`r cSd ls cus gks] U;wure 6 ekg dh vof/k dh oS/krk gks½ tks izcU/k funs’kd] dqekÅW e.My
fodkl fuxe fy0 ds uke ca/kd gksxs] tek djk;s tk ldsxsA
;k
vkosfnr [kuu ykWV ds vk/kkj ewY; ls ;fn gSfl;r izek.k i= dh /kujkf’k de gS rks mDr /kujkf’k ds
cjkcj dh /kujkf’k dh ,Q-Mh-vkj- ¼jk”Vªh;d`r cSd ls cus gks] U;wure N% ekg dh vof/k dh oS/krk gks½
tks izcU/k funs’kd] dqekÅW e.My fodkl fuxe fy0 ds uke ca/kd gksxs] tek djk;s tk ldsxsA
¼uksV%& fufonknkrk }kjk ;fn iw.kZ@vo’ks”k gSfl;r /kujkf’k ,Q0Mh0vkj0 ds :Ik esa izsf”kr dh tkrh gS] rks
mldh izfr fufonk ds rduhdh Hkkx ds lkFk vkWu ykbZu viyksM fd;s tkus ds lkFk&lkFk ewy ,Q0Mh0vkj0
fuxe esa vU; vko;’dh; vfHkys[kksa ds lkFk fufonk izsf”kr fd;s tkus dh vfUre frfFk ,oa le; ls iwoZ fuxe
eq[;ky; esa tek dh tkuh vko’;d gksxh½A
6- rduhdh ,oa foRrh; fufonk viyksM djus rFkk ifj.kke ?kksf”kr fd;s tkus dh izfØ;k% &
1- bZ&fufonk ds fufonknkrkvksa ds }kjk vius Digital Signature Certificate (DSC) dh lgk;rk ls fufofnr
[kuu ykWV dh rduhdh fufonk leLr vfHkys[kksa lfgr fufonknkrk@vf/kd`r O;fDr ds }kjk gLrk{kj ds lkFk
PDF Format esa rS;kj dj www.uktenders.gov.in esa viyksM dh tk;sxh rFkk www.uktenders.gov.in ls
MkmuyksM dh x;h foRrh; fufonk ds fu/kkZfjr izk:i BOQ (Excel Format) esa fufonknkrk }kjk
la’kks/ku@izfrLFkkiu ugha fd;k tk;sxk rFkk lEcfU/kr dkWye Hkjus ds ckn www.uktenders.gov.in ij viyksM
fd;k tk;sxk] vU;Fkk fufonknkrk foRrh; fufonk ds vLohdkj fd;s tkus gsrq mRrjnk;h gksxkA fufonknkrkvksa dks
dsoy fufonknkrk dk uke vkSj ewY; ntZ djus dh vuqefr gksxhA
2- xfBr lfefr ds }kjk fu/kkZfjr frfFk dks rduhdh fufonk [kksyrs gq, mldk ijh{k.k@ewY;kadu fd;k tk;sxk ,ao
rduhdh fufonk esa lQy fufonknkrkvksa dh ?kks”k.kk lEcU/kh ifj.kke osclkbZV www.uktenders.gov.in ij
izdkf’kr djrs gq, foRrh; fufonk (Financial Bid) [kksyus gsrq fu/kkZfjr frfFk ,oa le; ij foRrh; fufonk
(Financial Bid) [kksyrs gq, lQy fufonknkrk H-1 ls H-3 rd dk ifj.kke osclkbZV ij izdkf’kr fd;k
tk;sxkA
7- [kuu ykWV ds vkoaVu dh izfØ;k% &
1- foRrh; fufonk dh dk;Zokgh iw.kZ gksus ,ao lQy cksyhnkvksa ¼H-1 ls H-3 rd½ dh Øeokj ?kks”k.kk fd;s tkus
ds mijkUr loZizFke foRrh; fufonk dsa lQy cksyhnkrkvksa esa H-1 cksyhnkrk dks muds }kjk izLrqr mPpre
cksyh dh /kujkf’k dk 25 % ds lerqY; /kujkf’k ¼iwoZ esa tek /kjksgj jkf’k (Earnest Money) dh /kujkf’k
ds vfrfjDr vo’ks”k /kujkf’k½ izfrHkwfr /kujkf’k (Security Money) ds :Ik esa lkr dk;Zfnolksa esa
,Q0Mh0vkj0 ds :Ik esa tek djkus dk volj iznku fd;k tk;sxkA H-1 cksyhnkrk }kjk fu/kkZfjr
le;kUrxZr ;fn mDr /kujkf’k tek ugha djkbZ tkrh gS rks lEcfU/kr dh tek vusZLV euh (Earnest
Money) dh /kujkf’k dks tCr djrs gq, muds fo:) fu;e&23 ¼2½ ds vuqlkj dk;Zokgh dh tk;sxh rFkk
dksfVØe esa H-2 cksyhnkrk dks H-1 }kjk cksyh x;h mPpre cksyh ij [kuu iV~Vk fy;s tkus rFkk mPpre
cksyh dh /kujkf’k dk 25 % ds lerqY; /kujkf’k ¼iwoZ esa tek /kjksgj /kujkf’k (Earnest Money) dh
/kujkf’k ds vfrfjDr vo’ks”k /kujkf’k½ izfrHkwfr /kujkf’k (Security Money) ds :Ik esa lkr dk;Zfnolksa esa
,Q0Mh0vkj0 ds :i esa tek djkus dk volj iznku fd;k tk;sxkA mDr izfØ;k dksfVØe esa H-3 rd
viukbZ tk;sxhA H-3 }kjk fu/kkZfjr le;kUrxZr mDrkuqlkj vuqikyu u fd;s tkus dh n’kk esa bZ&fufonk dh
izfØ;k dks lekIr ?kksf”kr djrs gq, iqu% bZ&fufonk dh dk;Zokgh dh tk;sxhA
2- lQy cksyhnkrk }kjk mPpre cksyh dh /kujkf’k dk 25 % izfrHkwfr /kujkf’k (Security Money) ,d lIrkg
ds vUrxZr tek djrs gq, leLr vkSipkfjdrk;sa iw.kZ djrs gq, [kuu dk;Z izkjEHk fd;k tkuk vfuok;Z gksxkA
9

<!-- page 10 -->

3- lQy fufonknkrk }kjk jktLo mi [kfut {ks= esa pqxku lafdz;kvksa ds lEcU/k esa Ik;kZoj.k] ou ,oa tyok;q

ea=ky;] Hkkjr ljdkj ds bZ0vkbZ0,0 uksfVfQds’ku ds vUrxZr fuxe ds i{k esa tkjh Ik;kZoj.kh; vuqefr dks
Lo;a ds O;; ,oa O;oLFkk ij Lo;a ds i{k esa gLrkarfjr fd;k tkuk vfuok;Z gksxkA
4- ‘kklu] ekuuh; U;k;ky;ksa ,ao ekuuh; jk”Vªh; gfjr izkf/kdj.k }kjk le;&le; ij fn;s x;s vkns’k
ck/;dkjh gksaxsA
5- lQy fufonknkrk }kjk [kuu iV~Vk ds laca/k esa dh tk jgh dk;Zokgh ds nkSjku vkdfLed fu/ku vFkok
xEHkhj vk’kDr gksus dh n’kk esa vxzsRrj dk;Zokgh muds fof/kd okfjl }kjk dh tk ldsxhA
6- vU; ekud o ‘krsZ] tks jkT; ldkj }kjk le;&le; ij fu/kkZfjr dh tk;] ykxw gksaxhA
8- iV~Vk foys[k dk fu”iknu% &
1- fuxe dks vkoafVr [kuu ykWVksa gsrq bZ&fufonk }kjk p;fur lQy fufonkdkj dks izcU/k funs’kd vFkok muds
}kjk ukfer l{ke vf/kdkjh ds lkFk lgefr i= ¼,e0vks0;w0½ fu”ikfnr dj lQy fufonknkrk dks vius O;;
ij LVkEi fM;wVh ,oa iathdj.k dk Hkqxrku djuk gksxk] ftldh leLr ftEesnkjh lQy fufonknkrk dh
gksxhA
9- [kuu iV~Vs dh ‘krsZ% &
1- vU; [kfutksa dh [kkst%&
¼1½ iV~Vsnkj] iV~Vs ij fn;s x;s {ks= esa fdlh ,sls [kfut dh lwpuk] tks iV~Vs esa fufnZ”V u gks] jkT; ljdkj
dks mDr [kkst ds fnukWd ls 30 fnu ds Hkhrj nsxkA
¼2½ ;fn iVVs ij fn;s {ks= esa fdlh ,sls [kfut dk irk py tk;s] tks iV~Vs esa fufnZ”V] u gks] rks iV~Vsnkj
[kfut dks rc rd yC/k ¼win½ vkSj mldk fuLrkj.k ugha djsxk] tc rd fd mlds fy;s i`Fkd iV~Vk u ys
fy;k tk;sA
2- jkT; ljdkj dh iwoZ vuqefr ds fcuk iV~Vsnkj [kuu lafØ;kvksa ds lEcU/k esa fdlh ,sls O;fDr dks lsok;qDr
ugh djsxk tks Hkkjrh; jkf”Vªd u gksA
3- flok; ml n’kk es tc jkT; ljdkj i;kZIr dkj.kksa ls vU;Fkk vuqefr ns] iV~Vsnkj iV~Vk foys[k ds fu”iknu
o mifucU/kd }kjk foys[k ds fucU/ku ds fnukad ls ,d ekg ds Hkhrj [kuu lafØ;k;sa izkjEHk vkSj rRi’pkr
tkucw>dj vkarjk;fud ¼baVjfe’ku½ fd;s fcuk ,slh lafØ;kvksa dk lapkyu mfpr vkSj n{krkiwoZ jhfr ls rFkk
dq’ky dkjhxj dh Hkkafr djsxkA
4- unhry mi[kfut ykWV ds [kfut fu{ksi ds lEcU/k esa [kuu lafØ;k;sa] funs’kd] HkwrRo ,oa [kfudeZ funs’kky;
nsgjknwu }kjk lE;d :i ls vuqeksfnr [kuu ;kstuk ds vuqlkj ftlesa okf”kZd fodkl ;kstukvksa dk C;kSjk
gksxk] dh tk;sxhA
5- lQy fufonknkrk }kjk pqxku {ks=kUrxZr ihyjcUnh lEcfU/kr foHkkxksa dh ns[k&js[k esa Lo;a ds O;; ij djuh
gksxhA ;fn ykWV ds vUrxZr dksbZ iqy LFkkfir gS] rks izcfU/kr Mkmu LVªhe ,oa vi LVªhe {ks= dks NksM+dj
lhekcfU/kr {ks= ds vUnj ls gh mi [kfutksa dks mBkuk gksxk rFkk lhekLrEHkksa dh lqj{kk djuh gksxhA
lhekcfU/kr {ks= ls ckgj mi [kfutksa ds mBku gksus dh n’kk esa fu;ekuqlkj fof/kd ,oa vU; dk;Zokgh vey
esa yk;h tk;sxhA
6- izHkkxh; ou vf/kdkjh (Divisional Forest Officer) dh fyf[kr iwoZ Lohd`fr ds fcuk u rks fdlh vkjf{kr
(reserved) lqjf{kr ;k fufgr ou esa izos’k fd;k tk;sxk vkSj u gh mDr vf/kdkjh dh fyf[kr Lohd`fr izkIr
fd;s fcuk vkSj u ,slh ‘krksZ ds foifjr tks jkT; ljdkj rnFkZ vkjksfir djs] fdlh bekjrh ydM+h ;k o`+{kks
dks fxjk;k] dkVk ;k mudk mi;ksx fd;k tk;sxkA
7- iV~Vsnkj ds }kjk unh ry esa Lohd`r [kuu ykWV esa [kuu@pqxku dk;Z lrg ls vf/kdre 3 ehVj dh xgjkbZ
rd vFkok Hkw&ty Lrj vFkok Ik;kZoj.kjh; vuqefr esa vuqer xgjkbZ] tks Hkh de gks] rd fd;k tk;sxkA
10

<!-- page 11 -->

8- [kfutksa dk Bhd&Bhd ys[kk d{k%&

iVVsnkj [kfutksa dk Bhd&Bhd ys[kk j[ksxk] ftlesa og [kku ¼Mine½ ls izkIr rFkk Hksts x;s lHkh
[kfutks dh ek=k rFkk vU; fooj.k nsxk vkSj lkFk gh ifjogu dh iz.kkyh okgu dk fucU/k ¼jftLVªs’ku½
la[;k] okgu ;k Ik’kq dk izHkkjh O;fDr rFkk <ks;s x;s [kfut dk izdkj vkSj ek=k] [kfut dh lHkh fcdzh ds
ewY; rFkk leLr vU; fooj.k] mlesa lsok ;qDr O;fDr;ksa dh la[;k vkSj jk”Vªh;rk rFkk [kku ds iwjs uD’ks nsxk
vkSj dsUnzh; ;k jkT; ljdkj }kjk rnFkZ izkf/kd`r fdlh vf/kdkjh dks fdlh le; mlds ¼iV~Vsnkj½ }kjk j[ks
x;s fdUgha ys[kksa] uD’kksa vkSj vfHkys[kksa dk ijh{k.k djus dh vuqefr nsxk vkSj dsUnzh; ;k jkT; ljdkj dks
,slh leLr lwpuk rFkk foojf.k;kW nsxk] tks dsUnzh; ;k jkT; ljdkj vFkok mleas ls fdlh ds }kjk rnFkZ
izkf/kd`r dksbZ vf/kdkjh vis{kk djsA
9- vxzdz;kf/kdkj ¼gd’kd½%&
¼1½ jkT; ljdkj dks lnj ,slh Hkwfe] ftlds lEcU/k esa iV~Vk fn;k x;k gks] ls yC/k [kfutksa ;k [kfutksa ds
lEiknu dk vxzdz;kf/kdkj ¼Right of pre-rmption½ gksxk] ftl ewY; dk Hkqxrku fd;k tk;sxk] og
vxzdz;kf/kdkj ds le; izpfyr mfpr cktkj ewY; gksxkA
¼2½ mDr ewY; fudkyus esa lgk;rk nsus ds fy;s iVVsnkj ;fn mlls ,slh vis{kk dh tk; rks jkT; ljdkj
dks mldh xksiuh; lwpuk ds fy;s vU; xzkgdksa dks csps x;s ,sls [kfutksa ;k muds mRiknuksa rFkk mUgsa <ksus ds
fy, vf/kdrj i=ksa dk fooj.k vkSj ewY; izLrqr djsxkA
10- lHkh nkoksa ds fo:) iV~Vsnkj ljdkj dks {kfriwfrZ djsxk%&
iV~Vsnkj lHkh gkfu ;k fo{ksi ds fy;s] tks iV~Vs }kjk fn;s x;s vf/kdkjksa dk iz;ksx djus esa mlds }kjk dh
x;h gks] Hkqxrku djus dh izR;kHkwfr ¼guatantee½ nsxk vkSj ,sls leqfpr izfrdj dk Hkqxrku djsxk tks jkT;
ljdkj }kjk fu/kkZfjr dh tk;s vkSj mu lHkh nkoksa] oknksa rFkk ekWxksa vkSj muds izfr tks fdlh ,slh gkfu] {kfr
;k fo{kkse ds lEcU/k esa fdlh O;fDr ;k fdUgha O;fDr;ksa }kjk dh tk;sxh ;k yk;h tk;s vkSj muds lEcU/k esa
lHkh ifjO;;ksa dh jkT; ljdkj dks {kfriwfrZ djsxk rFkk iw.kZr;k {kfriwfrZ djrk jgsxkA
11- iV~Vsnkj vfoyEc ftykf/kdkjh ,oa ftyk [kku vf/kdkjh dks izR;sd ,slh nq?kZVuk dk izfrosnu Hkstsxk] tks iV~Vs
ds v/khu fdUgha lafdz;kvksa ds nkSjku gks tk;s] vkSj ftlds dkj.k e`R;q gks tk;s ;k xEHkhj ‘kkjhfjd pksVas igqWps
;k lEifRr dks xEHkhj {kfr igqWps ;k ftlls thou ;k lEifRr ij xEHkhj izHkko ;k og ladV esa iM+ tk;sA
12- iÍk/kkjd ds }kjk pqxku@[kuu iÍk {ks= ds izos’k ,oa fudklh xsVksa ij dEI;wVªkbZTM /keZdkaVk ,oa okguksa ds
izos’k o fudklh ij fuxjkuh ds fy;s Loa; ds O;; ij 360 fMxzh dks.k ij n`’;rk fjdkfMkax ds ;ksX;
vk/kqfud vkbZ0ih0 csLM lh0lh0Vh0oh0 dSejk yxkus lfgr pSd iksLV@xsV dk fuekZ.k djsxkA iÍk/kkjd mDr
pSd iksLV@xsV ij vkj0,Q0 vkbZ0Mh0 LdSuj Hkh j[ksxk ftlls lEcfU/kr iÍk {ks= ls mi[kfutksa ds ifjogu
gsrq iz;qDr izR;sd ;ku ds lkis{k fuxZr fd;s x;s bZ&joUuk izi= ,e,e&11 ij vafdr ckjdksM dk MkVk iMus
o lqjf{kr j[kus dh lqfo/kk gksxh vkSj mldk leqfpr :Ik ls j[k&j[kko djsxk ,oa lnSo mls pkyw :Ik esa
vuqjf{kr j[ksxkA iÍk/kkjd mDr lh0lh0Vh0oh0 dSejs vkSj vkj0,Q0vkbZ0Mh0 LdSujksa }kjk dh x;h leLr
fjdkfMZx dks de ls de 30 fnuksa rd lqjf{kr j[ksxk vkSj fu;e&66 ds micU/kksa ds v/khu izkf/kd`r vf/kdkjh
ds }kjk fjdkMZ ekaxs tkus ij mDr fjdkfMax dks miyC/k djk;sxkA iV~Vk/kkjd }kjk mDr ds vuqikyu ds
lEcU/k esa le;&le; ij jkT; ljdkj }kjk tkjh fn’kk&funsZ’kska@vkns’kksa dk dM+kbZ ls vuqikyu lqfu’pr
fd;k tk;sxkA
13- iÍsnkj@vuqKki= /kkjd ds }kjk Lohd`r [kuu {ks= ds izos’k@fudklh xsV ij Lohd`r [kuu {ks= dk iw.kZ
fooj.k ;Fkk iV~Vk/kkjd dk uke ,ao irk] lEidZ@nwjHkk”k uEcj] Lohd`r {ks=Qy] Lohd`fr vkns’k dh la[;k
,oa fnukad] Lohd`r iV~Vkof/k] [kfut dk izdkj] izfro”kZ fudklh dh Lohd`r ek=k ,oa [kfueq[k ij [kfut ds
fodz; ewY; dh nj dks iznf’kZr djsxkA
11

<!-- page 12 -->

14- iV~Vk/kkjd ds }kjk [ku~u iV~Vk {ks= esa [kuu lafØ;kvksa gsrq mRrjk[k.M Ik;kZoj.k laj{k.k ,oa iznw”k.k fu;a=.k

cksMZ ls Consent to establish ,oa Consent to operate dh vuqefr Lo;a ds O;; ,oa O;oLFkk ij izkIr
dh tkuh vfuok;Z gksxhA
15- lQy fufonkdkj dks jktLo mi[kfut {ks=] tudqMh&[kVxsMk esa [kuu dk;ksZ ds lEcU/k esa tkjh i;kZoj.kh;
vuqefr la[;k& 253&01¼133½@2024 fnukWd 02-09-2024 dh leLr ‘krkZs dk vfuok;Z :Ik ls vuqikyu fd;k
tkuk gksxkA
16- lkoZtfud LFky] unh ij fufeZr iqy] unh ds fdukjksa vkfn ls lqjf{kr nwjh%& jkT; ds ou unh {ks=ksa esa unh
dh dqy pkSM+kbZ dk nksuksa fdukjkas ls ,d pkSFkkbZ Hkkx NksM+dj rFkk jktLo@ou Hkwfe ds unhry mi[kfut
ykWVksa esa unh dh dqy pkSM+kbZ dk nksuksa fdukjksa ls 15&15 % Hkkx vFkok U;wure 10 ehVj NksM+dj mi[kfut
dk pqxku dk;Z fd;k tk;sxkA
17- ‘e’kku] lkoZtfud LFky vkfn ls 50 ehVj dh nwjh rFkk unh iqy ds viLVªhe rFkk Mkmu LVªhe esa 100 ehVj
dh nwjh rd vFkok ‘kklu }kjk le;&le; ij fuxZr ‘kklukns’kksa esa fu/kkZfjr nwjh ds vUrxZr pqxku dk;Z
izfrcaf/kr gksxkA
18- pqxku iÍk {ks=ksa ls fudklh fd;s x;s mi[kfut dh ek=k dk vkax.ku vk;ru (Volume) esa u djds Hkkj
(Weight) ds vuqlkj fd;k tk;sxkA
19- pqxku iÍk {ks=ksa ls [kfutksa ds ifjogu gsrq mi;ksx esa yk;s tkus okys okguks dk iathdj.k HkwrRo ,oa [kfudeZ
funs’kky; esa djk;k tkuk vfuok;Z gksxk] ftl gsrq ;fn jkT; ljdkj ds }kjk dksbZ ‘kqYd fu/kkZfjr fd;k
tkrk gS rks] og okgu Lokeh ds }kjk ns; gksxkA
20- izR;sd iÍk/kkjd dks pqxku dk;Z izkjEHk djus ls iwoZ okf.kT;dj foHkkx ,oa HkwrRo ,oa [kfudeZ funs’kky; ds
tuin Lrjh; dk;kZy;ksa esa iathdj.k djk;k tkuk vfuok;Z gksxkA
21- unh ry mi[kfut ykWVksa esa ts0lh0ch0] iksdyS.M] lSD’ku e’khu] fyQVj vkfn e’khuksa }kjk [kuu@pqxku
dk;Z ugh fd;k tk;sxkA ijUrq fo’ks”k ifjLFkfr;ksa esa tSls igaqp ekxZ dk fuekZ.k fd;s tkus] {ks= esa cMs vkdkj
ds cksYMj dks gVkus] iÍk {ks= esa Qals okguksa dks fudkyus vkfn dh n’kk es vuqefr lEcfU/kr miftykf/kdkjh
ds }kjk [kku vf/kdkjh dh laLrqfr ds mijkUr iznku dh tk;sxhA
22- iÍk/kkjd iÍk {ks= ls mi[kfutksa dk fonksgu@ifjogu lw;ksZn; ls lw;kZLr ds e/; djsxkA
23- lQy fufonkdkj ,oa fuxe ds e/; pqxku ds dk;Z gsrq lEikfnr vuqcU/k dh vof/k ds vUrxZr ;fn lQy
fufonkdkj dh e`R;q gks tkrh gS rks mDr [kuu iV~Vk lQy fufonknkrk ds fof/kd okfjl dks l{ke Lrj ls
fuxZr mRrjkf/kdkjh izek.k i= rFkk mDr vkosnu gsrq bPNqd gksus dk uksVjkbZTM vuqjks/k ‘kiFk i= izcU/k
funs’kd] dqekÅW e.My fodkl fuxe fyfeVsM ds le{k 3 ekg dh vof/k ds vUrxZr izLrqr djuk vko’;d
gksxk] vU;Fkk dh fLFkfr esa vuqcU/k dks fujLr dj vkosfnr {ks= dks fjDr fd;s tkus gsrq vko’;d dk;Zokgh
dh tk;sxhA
24- mRrjk[k.M mi[kfut ifjgkj fu;ekoyh 2023 ds fu;e&58 ¼2½ ds vuqlkj bl fu;ekoyh ds micU/kksa ij
izfrdwy izHkko Mkys] fcuk mifu;e ¼1½ ds v/khu lwpuk dh vof/k dh lekfIr ds i’pkr bl fu;ekoyh ds
v/khu jkT; ljdkj dks ns; fdlh HkkVd LokfeRo] lhekdu ‘kqYd vksj fdUgh vU; ns;ksa ij 24 % izfr o”kZ
dh nj ls lk/kkj.k C;kt fy;k tk ldrk gSA
25- vukf/kd`r [kuu ds fy;s ‘kfDr%&
¼1½ tks dksbZ Hkh mRrjk[k.M mi [kfut ¼ifjgkj½ fu;ekoyh&2023 ds fu;e&3 ds micU/kks dk
mYya?ku djs o nks”k fl) gks tkus ij izFke ckj esa voS/k mR[kfur [kfut dh ek=k ij jk;YVh dk 2
¼nks½ xquk rFkk rn~Ik’pkr jk;YVh dk 3 ¼rhu½ xquk rd ds lerqY; /kujkf’k olwy dh tk;sxhA
12

<!-- page 13 -->

¼2½ voS/k [kuu dh iqf”V gksus ij izcU/k funs’kd] dqekÅW e.My fodkl fuxe fyfeVsM dks
fu;ekuqlkj vko’;d dk;Zokgh djus dk vf/kdkj gksxkA
26- lkekU;rk fu;ekas vkSj iV~Vs dh ‘krksZ ds mYya?ku dk ifj.kke %&
¼1½ iV~Vsnkj }kjk fu;eksa ;k iV~Vs esa nh xbZ le>h tkus okyh ‘krksZ vkSj izlafonkvksa ds flok; muds] tks
LokfeRo] HkkVd ;k jkT; ljdkj dks ns; vU; /kujkf’k;ksa ds Hkqxrku ls lEcfU/kr gks] Hkax ;k mYya?ku fd;s
tkus dh n’kk esa jkT; ljdkj iV~Vsnkj dks viuk ekeyk crkrs dk ;qfDr;qDr volj iznku djus ds i’pkr
iV~Vk lekIr dj ldrh gSA ;g vf/kdkj fu;e 59 ds micaU/kksa ds vfrfjDr gksxk vkSj bldk ml ij dksbZ
izHkko ugh iMs+xkA
¼2½ ;fn mi fu;e ¼1½ ds v/khu iV~Vk lekIr dj fn;k tkrk gS rks iV~Vsnkj dk uke izcU/k funs’kd] dqekÅW
e.My fodkl fuxe fy0 }kjk 5 o”kZ ls vukf/kd ,slh vof/k ds fy, tSlk mfpr le>k tk;sa dkyh lwph esa
Mky fn;k tk;sxk vkSj ,slh vof/k ds nkSjku mlds bl fu;ekoyh ds v/khu dksbZ [kfut ifjgkj Lohd`r ugh
fd;k tk;sxkA bl lEcU/k esa] ;FkkfLFkfr] [kuu iV~Vs ds jftLVj esa ;k bZ&fufonk jftLVj ds vH;qfDr okys
LrEHk esa ,d izfof”V vafdr dj nh tk;sxhA
27- unhry Lohd`r mi[kfut ykWVksa gsrq [kuu l= o”kkZdky ds mijkUr 1 vDVwcj ls 30 twu rd dh vof/k
gksxhA
28- [kfut ds ifjogu ij fucZU/ku %&
1) [kfutksa ds ifjogu gsrq iV~Vk/kkjd dks HkwrRo ,oa [kfudeZ funs’kky; ds bZ&joUuk iksVZy ij iathdj.k
djk;k tkuk vfuok;Z gksxkA
2) [kuu iV~Vk/kkjd ;k mlds }kjk rnFkZ izkf/kd`r O;fDr] fdlh xkMh] i’kq ;k ifjogu ds fdlh vU; lk/ku
}kjk mi[kfut dk ifj”k.k ¼dUlkbuesaV½ dj ys tkus okys izR;sd O;fDr dks bZ&joUuk izi= ,e,e& 11 esa
ikl tkjh djsxkA
3) dksbZ Hkh O;fDr jkT; ds Hkhrj jsy dks NksMdj] Ik’kq] xkMh ;k ifjogu ds fdlh vU; lk/ku }kjk dksbZ
mi[kfut mifu;e ¼1½ ds v/khu bZ&joUuk izi= ,e,e&11 esa rFkk jkT; ds ckgj bZ&joUuk izi=&11 ^^vks
,l** esa tkjh ikl ds fcuk ugh ys tk;sxkA
4) fdlh mi[kfut dks ys tkus okyk O;fDr] fu;ekoyh ds fu;e 66 ds v/khu izkf/kd`r fdlh vf/kdkjh ;k
jkT; ljdkj }kjk rnFkZ izkf/kd`r vf/kdkjh }kjk eakxus ij mDr ^^ikl^^ dks ,sls vf/kdkjh dks fn[kk;sxk
vkSj mls mi [kfut dh ek=k ds lanHkZ esa ^^ikl^^ ds fooj.kksa dh ‘kq}rk dks lR;kfir djus nsxkA
5) izcU/k funs’kd] dqekÅW e.My fodkl fuxe fy0 voS/k ifjogu dh jksdFkke gsrq [kuu iV~Vk esa lfEefyr
fdlh {ks= ds fy;s tkap pkSdh ¼psd iksLV½@eksckbZy pSd iksLV LFkkfir dj ldrk gSA dksbZ O;fDr] ,sls
mi[kfut dk ifjogu ,sls {ks= ls ml {ks= ds fy;s LFkkfir tkap pkSdh ij [kfut ds izdkj ;k eki ds
lR;kiu gsrq izLrqr fd;s fcuk ugh djsxkA
6) [kfut dk voS/k ifjogu djrs gq, ik;s tkus ij mRrjk[k.M [kfut ¼voS/k [kuu] ifjogu ,oa Hk.Mkj.k
dk fuokj.k½ fu;ekoyh ds lqlaxr fu;eksa ds vUrxZr dk;Zokgh dh tk;sxhA
7) dksbZ O;fDr ftlds lEcU/k esa ;g ik;k tk; fd mlus bl fu;e dk mYya?ku fd;k gS] nks”k fl} gks tkus
ij vFkZn.M ls n.Muh; gksxk tks :0 2-00 ¼nks½ yk[k rd gks ldrk gSA
8) voS/k ifjogu ;k bZ&joUuk izi=ksa dk nq:i;ksx ik;s tkus ij funs’kky; dks lEcfU/kr iV~Vk/kkjd dk
bZ&joUuk iksVZy fcuk iwoZ lwpuk ds vLFkkbZ :i ls fuyfEcr (Suspend) djus ,oa fu;ekuqlkj vU;
dk;Zokgh fd;s tkus dk vf/kdkj gksxkA
29- iV~Vk/kkjd }kjk [kku ,ao [kfut fodkl ,ao fofu;eu vf/kfu;e 1957 ¼le;&le; ij ;Fkkla’kksf/kr½]
mRrjk[k.M mi[kfut ifjgkj fu;ekoyh&2023] ekuuh; U;k;ky;ksa ,ao jk”Vªh; gfjr izkf/kdj.k rFkk ‘kklu
13

<!-- page 14 -->

}kjk le;&le; ij tkjh ‘kklukns’kksa@fn’kk funsZ’kksa rFkk izcU/k funs’kd] dqekÅW e.My fodkl fuxe fy0
}kjk tkjh funsZ’kksa dk vuqikyu lqfuf’pr fd;k tk;sxkA
30- bZ&fufonk dh izfdz;k ds nkSjku ,slk izdj.k ftldk mYys[k bl fufonk izi= esa of.kZr fd;k tkuk jgk x;k
gks vFkok iw.kZr% Li”V u fd;k tk ldk gks vFkok ,slk lelkef;d izdj.k tks [kfut fodkl ,ao jktLo
fgr esa vko’;d gks ,sls izdj.kksa ij izcU/k funs’kd] dqekÅW e.My fodkl fuxe fyfeVsM ds }kjk rRlEcU/kh
vU; ‘kklukns’kksa@vuqns’kksa dk vuqlj.k dj O;k[;kfir djrs gq, fu.kZ; fn;k tk ldsxk] izcU/k funs’kd]
dqekÅW e.My fodkl fuxe fyfeVsM dk fu.kZ; vfUre gksxk ,ao loZ i{kksa dks ekU; gksxkA
31- fufonknkrk dks fufonk dh ‘krksZ ds vuq:Ik leLr ‘kiFk i=ksa ,oa fufonk izi= ds Hkkx&3 rduhdh fufonk
izi= ¼pSd fyLV½ dks vkWu ykbZu viyksM fd;s tkus ds lkFk&lkFk fufonk izsf”kr fd;s tkus dh vfUre frfFk
,oa le; ls iwoZ fuxe eq[;ky; esa tek fd;s tkus vfuok;Z gksaxsA
izcU/k funs’kd]
dqekÅW e.My fodkl fuxe fy0
uSuhrky

14

<!-- page 15 -->

Hkkx&3
rduhdh fufonk izi=
pSd fyLV
izfrHkkxh fufonknkrkvkas ds }kjk rduhdh fufonk ds lEcU/k esa bZ&fufonk izi= ds Hkkx&2 ds vuqlkj fufonk
izi= ‘kqYd] /kjksgj /kujkf’k ,oa vU; okafNr vfHkys[k vkfn rduhdh fufonk ds lkFk fuEukuqlkj miyC/k djk;h tk;sxh%&
Øe
fooj.k
Hkjh tkus okyh lwpuk layXud la[;k
la0
1 vkosnd dk vk/kkj dkMZ@ernkrk igpku i= dh izfr] QeZ dh n’kk esa QeZ ds
Hkkxhnkjksa ds vk/kkj dkMZ@ernkrk igpku i= dh izfr rFkk dEiuh ds ekeys
esa dkjiksjsV vQs;lZ ea=ky; Hkkjr ljdkj }kjk fuxZr dEiuh ds izcU/k
funs’kd@funs’kd dk Director Identification Number (DIN) ds izek.k
i= dh izfr rFkk dkWijsfVo lkslkbVh@lfefr ds lEcU/k esa v/;{k] mik/;{k ,oa
lfpo dk vk/kkj dkMZ@ernkrk igpku i= dh izfrA
2 vkosnd dk LFkk;h fuokl izek.k&i= dh izfr] QeZ dh n’kk esa QeZ ds Hkkxhnkjksa
ds LFkk;h fuokl izek.k&i= dh izfr rFkk dkWijsfVo lkslkbVh@lfefr ds
lEcU/k esa v/;{k] mik/;{k ,oa lfpo dk LFkk;h fuokl izek.k&i= dh izfrA
3 vkosnd dk v|kof/kd pfj= izek.k i=] lfefr ds ekeyksa esa lfefr ds
v/;{k@lfpo dk pfj= izek.k i=] QeZ ds ekeys esa lHkh Hkkxhnkjksa dk pfj=
izek.k i= ,oa dEiuh ds ekeys eas bl vk’k; dk ‘kiFk i= fd dEiuh dks
fdlh vijkf/kd okn esa nf.Mr ugh fd;k x;k gSA pfj= izek.k i= ml ftys
ds ftykf/kdkjh vFkok ftykf/kdkjh }kjk ukfer l{ke izkf/kdkjh }kjk iznRr
gksxk] tgka vkosnd LFkk;h :i ls fuokl djrk gksA
4 vkosnd ds iSudkMZ dh izfrA
5 vkosnd ds th0,l0Vh0 dh izfrA
6 vkosnd ds cSad [kkrs dk fooj.k] ftlls bZ&fufonk ls lEcfU/kr leLr foRrh;
gLrkUrj.k fd;k tk;sxk] ;Fkk cSad o ‘kk[kk uke] [kkrk la[;k]
vkbZ0,Q0,l0lh0 dksM rFkk ,d fujLr psd dh izfrA
7 funs’kd] HkwrRo ,oa [kfudeZ funs’kky;] mRrjk[k.M }kjk izkf/kd`r vf/kdkjh
}kjk tkjh fd;k x;k [kuu vns;rk izek.k i= dh izfrA ;fn vkosnd vius x`g
tuin ds vfrfjDr vU; tuin esa fLFkr [kuu ykWV gsrq bZ&fufonk esa izfrHkkx
djrk gS rks vius x`g tuin ds lkFk&lkFk lEcfU/kr tuin gsrq funs’kd]
HkwrRo ,oa [kfudeZ funs’kky;] mRrjk[k.M }kjk izkf/kd`r vf/kdkjh ls [kuu
vns;rk izek.k&i= izkIr dh izfrA
8 dksijsfVo lkslkbVh ds lEcU/k esa dkWih vkWQ jsT;wys’ku ds leLr i`”Bksa dh
Loizekf.kr izfrA Hkkxhnkjh QeZ ds lEcU/k esa Hkkxhnkjh foys[k ,oa QeZ ds
iathdj.k dh izfr] dEiuh ds ekeys esa vkfVZdy vkQ ,lksf’k;s’ku dh izfrA
9 fdlh Hkh jkT; es [kuu lafdz;kvksa dh dkyh lwph esa u gksus lEcU/kh
:0 100-00 ds bZ&LVkEi isij ij uksVjkbTM ‘kiFk i= dh izfrA
10 vkosnd o mlds ifjokj ds fo:) [kuu ns;rk gksus ij vkosnu vLohdkj dj
fn;k tk;sxkA ifjokj ¼vkosnd ds ekrk] firk] ifr] iRuh] iq=] HkkbZ] vfookfgr
15

<!-- page 16 -->

11
12
13
14

15

iq=h] vfookfgr cgu½ ds lnL;ksa ds fo:) [kuu cdk;k u gksus ds lEcU/k esa
vkosnd ds }kjk :0 100-00 ds bZ&LVkEi isij ij uksVjkbTM ‘kiFk&i= dh
izfrA
fufonk izi= Ø; fd;s tkus ds lkis{k ‘kqYd :0 30]000-00 ¼rhl gtkj ek=½
tek fd;s tkus lEcfU/kr izek.k dh izfrA
fufonknkrk ds }kjk bZ&fufonk gsrq opuc)rk ¼Undertaking½ dk izk:i
:0 100-00 ds bZ&LVkEi isij ij uksVjkbTM ‘kiFk i= dh izfrA
fufonknkrk ^^futh O;fDr@QeZ@lfefr@dEiuh@lkslkbVh** ds }kjk foxr 3
o”kksZ dh vkbZ0Vh0vkj0 dh izfrA
fufofnr [kuu ykWV ds vk/kkj ewY; ds 25 % ds lerqY; /kujkf’k] /kjksgj jkf’k
(Earnest Money) ds :i esa fdlh jk”Vªh;d`r cSad }kjk tkjh ,Q0Mh0vkj0
ds :i esa tks izcU/k funs’kd] dqekÅW e.My fodkl fuxe fy0 ds uke ,d o”kZ
¼1 o”kZ½ dh vof/k gsrq cU/kd gks dh izfrA
ftykf/kdkjh ;k ftykf/kdkjh }kjk izkf/kd`r l{ke vf/kdkjh }kjk tkjh dh x;h
gSfl;r izek.k i= ;k lEifRr izek.k&i= ;k lek’ksk/ku {kerk izek.k&i=
(Solvency Certificate) tks vkosfnr [kuu ykWV ds vk/kkj ewY; ls de u gks
rFkk QeZ@dEiuh vkfn dh n’kk esa foxr 3 o”kksZ dh lh0,0 }kjk izekf.kr
cSysUl’khV (Balance Sheet) dh izfr ftldk VuZ vksoj ;k usVoFkZ (Net
worth) vk/kkj ewY; ls de u gksA
;k
;fn gSfl;r izek.k&i= v|ru u gks rks] bl ‘krZ ds lkFk vUrfje :i ls
Lohdkj fd;k tk;sxk fd vkosnd bldk ‘kiFk i= izLrqr djsa fd bl nkSjku
¼gSfl;r izek.k&i= dh frfFk ls v|ru½ fufonk cksyhnkrk ds }kjk layXu
gSfl;r izek.k i= esa vafdr py@vpy lEifRr dk foØ;@gLrkUrj.k ugha
fd;k x;k gSA
;k
gSfl;r izek.k i= ds ,ot esa vkosfnr [kuu {ks= ds vk/kkj ewY; ds cjkcj dh
/kujkf’k dk ,Q0Mh0vkj0 ¼jk”Vªh;d`r cSd ls cus gks] U;wure 6 ekg dh vof/k
dh oS/krk gks½ tks izcU/k funs’kd] dqekÅW e.My fodkl fuxe fy0 ds uke
ca/kd gksxs] tek djk;s tk ldsxsA
;k
vkosfnr [kuu ykWV ds vk/kkj ewY; ls ;fn gSfl;r izek.k i= dh /kujkf’k de
gS rks mDr /kujkf’k ds cjkcj dh /kujkf’k dk ,Q0Mh0vkj0 ¼jk”Vªh;d`r cSd ls
cus gks] U;wure 6 ekg dh vof/k dh oS/krk gks½ tks izcU/k funs’kd] dqekÅW
e.My fodkl fuxe fy0] ds uke cU/kd gksA
fufonknkrk@fufonknkrkvksa ds gLrk{kj
¼uke o inuke½
16

<!-- page 17 -->

Hkkx&4
foRrh; fufonk dk izk:i
fufonknkrk }kjk www.uktenders.gov.in ls foRrh; fufonk dk izk:i BOQ (Excel Format) MkmuyksM
fd;k tk;sxkA fufonkrkvksa ds }kjk fufofnr mi[kfut [kuu ykWV dh bZ&fufonk ds fy;s fu/kkZfjr izfrVu vk/kkj ewY;
(Base Price) ls vf/kd viuh vf/kdre cksyh BOQ esa ntZ dh tk;sxhA fufonknkrk }kjk BOQ esa la’kks/ku@izfrLFkkiu
ugha fd;k tk;sxk rFkk lEcfU/kr dkWye Hkjus ds ckn www.uktenders.gov.in ij viyksM fd;k tk;sxk] vU;Fkk
fufonknkrk foRrh; fufonk ds vLohdkj fd;s tkus gsrq mRrjnk;h gksxkA BOQ esa fufonknkrkvksa dks dsoy fufonknkrk dk
uke vkSj vf/kdre cksyh ntZ djus dh vuqefr gksxhA foRrh; fufonk ds BOQ dk izk:i esa fuEuuqlkj gksxk%&

lQy fufonkdkj }kjk izsf”kr fufonk njksa ij vkaxf.kr th0,l0Vh0 ,oa Vh0lh0,l0 dk Hkqxrku lQy
fufonkdkj }kjk fuxe dks fu;ekuqlkj vfrfjDr :Ik ls fd;k tkuk gksxkA

17

<!-- page 18 -->

Hkkx&5
bZ&fufonk gsrq opuc)rk (Undertaking) dk izk:Ik
lsok esa]

egksn;]

izcU/k funs’kd]
dqekÅW e.My fodkl fuxe fy0]
uSuhrky A

eSa@ge bl ‘kiFk&i= ds ek/;e ls opu nsrs gSa fd esjs@gekjs }kjk fufofnr mi[kfut ykWV gsrq tkjh
bZ&fufonk lEcU/kh leLr vfHkys[kksa ;Fkk fufonknkrkvksa gsrq funsZ’k] ‘krsZ ,oa çfrcU/k] fof’kf”Vrk;sa ,oa vU; lanHkZ vkfn
dk Hkyh&HkkWafr voyksdu ,oa v/;;u djus ds Ik’pkr esjs@gekjs }kjk bZ&fufonk izi= ds Hkkx&3 esa visf{kr leLr
vfHkys[kksa ds lHkh i`”Bksa dks Lo% gLrk{kfjr@gLrk{kfjr ¼eksgj lfgr½ bZ&fufonk ds :i esa viyksM dj fn;k x;k gSA
;fn esjs@gekjs i{k esa bZ&fufonk ds ek/;e ls esjs@gekjs }kjk fufofnr mi[kfut ykWV vkaofVr@Lohd`r fd;k
tkrk gS rks] eS@ge mDr fufofnr mi[kfut ykWV ds lEcU/k esa tkjh bl fufonk izi=] mi[kfut ifjgkj
fu;ekoyh&2023] iV~Vkfoys[k ,oa mDr ds lEcU/k esa le;&le; ij tkjh gksus okys fn’kk&funsZ’kksa@’kklkukns’kksa @[kuu
U;k;ky;ksa ds vkns’kksa bR;kfn dk vuqikyu djsaxsA
;fn esjs@gekjs }kjk bZ&fufonk esa izfrHkkx djus ds lEcU/k esa dksbZ Hkh viw.kZ lwpuk@vfHkys[k fn;s
tkrs gSa ;k dksbZ rF; Nqik;k tkrk gS rks bl gsrq eS@ge Loa; mRrjnk;h gksxas rFkk bl lEcU/k esa izcU/k funs’kd]
dqekÅW e.My fodkl fuxe fy0 dk fu.kZ; vafre@ekU; gksxkA
fnukad &
fufonknkrk
O;fDr@lfefr@QeZ@dEiuh@lkslkbVh ds
vf/kd`r izfrfuf/k ds gLrk{kj eksgj lfgr

18
