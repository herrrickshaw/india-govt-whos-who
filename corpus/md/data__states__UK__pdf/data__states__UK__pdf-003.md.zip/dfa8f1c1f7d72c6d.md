---
doc_id: "dfa8f1c1f7d72c6d"
source_url: "https://www.uau.ac.in/downloads/Second_Circular.pdf"
ministry: "Uttarakhand Ayurved University, Uttarakhand"
title: "International Conference on Medicinal Plants at Gurukul Campus, Haridwar; 5-6 Sept 2022"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a9aa0526d7dce187"
---

<!-- page 1 -->

Chief Patron:
Co-Chief
Patron:
Patron:

Co- Patron:
Chief Advisor:
Advisor:

Lt. Gen Gurmeet Singh
H.E. Governor Uttarakhand, Dehradun .
Shri. Pushkar Singh Dhami
Hon’ble Chief Minister & Minister of Ayush,
Govt. of Uttarakhand.
Prof. Sunil Kumar Joshi
Hon’ble, Vice Chancellor,
Uttarakhand Ayurved University, Dehradun
Dr. Pankaj Pandey
Secretary Ayush, Uttarakhand Govt. Dehradun.
Acharya Bal Krishana
Pantajali Yoga Trust, Haridwar
Dr. Rajesh Adhana
Registrar, Uttarakhand Ayurved University,
Dehradun

Chief Advisory Board.
Prof. (Dr.) Pankaj Kumar Sharma
Campus Director, Gurukul Campus,UAU, Haridwar.
Prof. (Dr.) D. C. Singh
Campus Director, Rishikul Campus, UAU, Haridwar.
Dr. D. P. Panuli,
Campus Director, Dehradun Campus, UAU, Dehradun

Prof. Meena Rani Ahuja
Prof. Khem Chand Sharma

Organizing Committee
Prof. Suresh Chaubey
Prof. Ramesh C. Tiwari

Medicinal plants of ganga river basin and
their therapeutic importance in Indian system
of medicine

5th – 6th September, 2022
at
Gurukul Campus,
Uttarakhand Ayurved University, Haridwar,
Uttarakhand, 249407

Organizing Secretary
Dr. Kiran Vashisht

Dr. Ved Bhushan Sharma
Dr. Yadevendra Yadav

Dr. Bhawan Mittal
Dr. Deepak Kr. Semwal

International Conference
on

Co-Organizing Secretary
Dr. Richa Sharma
Dr Ashutosh Chauhan.

Shri. Amit Jain, CFO, UAU
Dr. Sanjay Gupta, DR, UAU
Shri. Sanjiv Pandey, DR, UAU

Convener
Prof. BalKrishana Pawar, DR, UAU
Dr. Shailendra Pradhan, DR, UAU
Dr. Rajeev Kurele

Dr. Amit Tamadadi

Co-convener
Dr. Mahesh Chandra

Invited Speakers
Prof. S.S. Savrakar, Former VC GAU, Jamnagar.
Prof. C B Jha, Former, Head RS & BK Deptt, IMS- BHU, Varanasi (UP).
Prof. L K Diwedi, EX Head RS & BK, NIA, Jaipur.
Prof. VK Joshi, Former Dean, Faculty of Ayurved IMS- BHU, Varanasi (UP).
Prof. K N Dwivedi, Dean, Faculty of Ayurveda, IMS BHU, Varanasi (UP).
Prof. P K Prajapati, Head, Deptt of RS & BK, AIIA, New Delhi.
Prof. Anil kumar Singh, Deptt of Dravya Guna, IMS-BHU, Varanasi.
Prof. Charu S. Savrikar, Former Professor, Agad Tantra, PAC, Mumbai.
Prof. Neeraj Kumar, Former Head RS & BK, IMS-BHU, Varanasi.
Prof. R N Acharya, Director , CCRAS, New Delhi.
Prof. Anita Sharma, Head Agad Tantra, NIA Jaipur (Rajasthan).
Prof. Shobha Bhatt, Head Agad Tantra, ISM-BHU, Varanasi (UP).
Prof. M.C. Nautiyal, Head HAPPRC, HNBGU, Srinagar (Uttarakhand)
Prof. Partha Roy, Head Biotechnology, IIT Roorkee, (UK).
Prof. Sunil Shah, Senior Scientist, CAP, Dehradun (UK)
Dr. Anurag Varshney, Principal Scientist, PRI, Haridwar (UK).
Prof. Anil K. Sharma, Head Dravya Guna, Krukshetra.
Prof. Vineet Kumar, FRI, Dehradun.
Vaidya Balendu Prakash, Padaav Ay. Treatment Centre, Rudrapur.
Dr Madan Thangavelu, European Ayurveda Association, Cambridge, UK.
Vadiya Harish Verma, Canadian college of Ayurveda & Yoga, Toronto, Canada
Prof. Sanjay Gupta, Head, Bioscience, SRHU, Dehradun, Uttarakhand.
Dr. Mithilesh Singh, Scientist D, GBPNIHE, Almora, Uttarakhand.

Organised by:
Uttarakhand Ayurved University, Harrawala, Dehradun
(Uttarakhand) 248001

In Association with
Gurukula Kangri (Deemed to be University), Haridwar.
Patanjali Yogapeth Trust, Haridwar (Uttarakhand).
Devsanskriti Vishwavidayalya, Haridwar(Uttarakhand).
Parmarth Niketan, Rishikesh, Dehradun, (Uttarakhand).
Arovali, Raiwala, Dehradun, (Uttarakhand).
Email: gurukulgangaconf@gmail.com
Phone No. 9045951442; 9456364759
7535002277; 9411175362 Fax: 01334-246563.

Second Circular

<!-- page 2 -->

About Conference: The Ganga & the Himalaya are the two key vital factors
for the liveliness of the people of Uttarakhand. Moreover, these two are
considered as most sacred pilgrimage site in Hindu mythology. The Ganga-Jal
(Water of the Ganga) is used in many rituals as it is known as Triloka-pathagamini in the Vedas. All Vedas & other Hindu Scriptures are written in the
Gangetic region. The Fertile land of the Himalayas and Ganga is a treasure
trove of Herbs and minerals. Ayurveda is also spreads from this land. Thus,
the influence of the Ganga Basin on the Indigenous system of medicine will be
illustrated at this conference.
About Haridwar: The city is situated on the bank of the river Ganges, at the
foothills of the Shivalik ranges. This city is a confluence holy place of Hindus,
the excellent center of higher education, Industrial hub, and tourism. The
dense forest area of Rajaji national park, a vast number of temples, KumbhaKanwar Mela, Piran Kalyar, and Ganga canals are the major attraction of the
city. Uttarakhand is lovingly called as “Dev Bummi” is one of the Himalayan
states and is also known as “Ayush Pradesh” because of its medical flora and
fauna. Maharishi Charka emphasized the importance of Herbs of the
Himalaya-origin . Sanskrit is the second official language of the state and
various Asharama and Matha are engaged in Sanskrit education since Ancient
time. The entire land of the state is irrigated by the Perennial River such as
Ganga, Yamuna, Sharda, Saryu, Gomati, and Kali. About 150 Small and big
Ayurvedic pharmacies and herbal drug Industries are situated in Haridwar.
About Uttarakhand Ayurved University: Rishikul Ayurved College and
Hospital was established by Great Educationist and Philosopher Pt. Madan
Mohan Malviya Ji in 1919 with the sole aim to revive ancient indigenous
System of medicine. Gurukul Ayurved College and Hospital was founded in
1921 by Swami Shraddhananda ji. These two premier Ayurvedic education
institutes become the pillar of Ayurvedic education, training, and research in
Uttarakhand. After establishment of Uttrakhand Ayurved University, these
two premier institutes were declared as Campus Colleges of the University.
Themes of Conference
 Pharmacognosy & phytochemistry of medicinal plants
 Latest trends in cultivation, collection and conservation of medicinal and
Aromatic plants
 Ethnomedicine, Ethnobotany and Ethanopharmacology.
 Socio-economic importance of medicinal Plants.
 Supremacy of Himalayan-origin drugs in Ayurveda.
 Anukta & Controversial Drugs,
 Rationality of Agray-aushadhi explained in Brahatrayees.
 Authentication of Herbo-mineral drugs by classical and Modern
Instrumentation techniques.
 Utility of Herbs, mineral and animal-origin drug of Ganga basin.
 Adulteration and substitution of crude drugs.
 Vraksaryurveda in Current scenario.
 Use of Ayurvedic Drugs in Insect repellant and Pesticides.
 Importance of Rasa-ausdhadis in Ayurveda.
 Role of Rasa-ausdhadis in endemic.
 Novel and Innovative techniques in phytopharmaceutical Formulations and
nano-metallic medicine.
 Medicinal uses of Poisonous plants.
 Medicinal plants and their effect in the protection of environmental
pollution.
 Treatment modalities of plant and animal toxicities.
 Classical Ayurvedic methods of food consumption, food incompatibility and
their role in the reduction of food poisoning.
 Use of Agad Preparation in the current scenario.
 Medicinal Value of Ganga Water.
Call for abstracts and full papers.
Original unpublished abstracts and full paper from Researchers are invited for
the Oral/Poster presentation. The received abstract will be screened for the
suitability with the theme and shortlisted one will be communicated with in
due time. Please note that only few papers will be accepted for Oral
Presentation; however for Poster Presentation, there are enough slots. The
selected full paper will be published in a Book having ISBN number. There will
be 6 best awards, 3 each for Oral and Poster presentation. The abstract must
contain a concise title, Authors' name, Affiliation, email address and contact
number of presenting author. The abstract must be provided in MS doc file in
Times New Roman font with line spacing of 1.5 and structured in Background,
Aim, Method, Result, and Conclusion with maximum of 300 words and full
paper of 30000 words. The choice of presentation (Oral/Poster) must be
clearly mentioned. Abstract/full paper can be submitted via online through
email to gurukulgangaconf@gmail.com latest by August 20th, 2022.

Preparation of oral/ poster presentation:
Oral presentation must be prepared in PowerPoint. The PPT must contain 1015 slides focusing to aim, method, results and conclusion. Poster should be
printed in flex of 3 (width) x 4 (height) foot in size, to be scientific, simple,
brief and self-explanatory. An appropriate font size is to be selected for easy
read.
Registration*
The participants must be registered via either online or offline mode as per
following fee details latest by August 20th, 2022. Additional fee of ₹ 500 will
be charged for on-spot registration in each category.

For UG Students
₹ 1000.00

For PG/PhD scholars
₹ 2000.00

For academicians/scientists
₹ 3000.00

For industry representatives
₹ 3000.00
*Registration fee includes two days meals, delegate kit, entry for all sessions,
and cultural eve.
Sponsorship/ Advertisement/ Exhibition
A souvenir will be published on the occasion of the conference. The
advertisements of the product/organization for publication in souvenir and to
host an event is mentioned below. This facility will be available on
Half page Adv. in souvenir
₹ 25,000.00
Half page Adv. in souvenir & banner space
₹ 50,000.00
Full page Adv. in souvenir & exhibition space
₹1,00,000.00
Pharmaceutical and other companies can display their products and
service in the stall. The organizers will provide space for the same.
Gold Stall
₹50,000.00
Silver Stall
₹25,000.00
Scientific Committee
Dr. Shuchi Mitra
Prof. Usha Sharma
Dr. N C Tiwari
Dr. Virendra K. Tamta
Dr. Manisha Dikshit
Dr. Amita Junjunwala
Dr. Deep Chand Pandey
Dr. Rishi Arya
Advisary Committee
Prof. Anup Kumar Gakkar
Prof. Radhavallabh Sati
Prof. A N Pandey
Prof. K K Sharma
Prof. Ajai Kumar Gupta
Prof. Uttam K. Sharma
Prof. O P Singh
Prof. Naresh Chaudary
Prof. Suman Mishra
Prof. P C Shastri
Prof. S P Vashistha
Dr. Anil Verma
Dr. Madhvi Goswami
Prof. Griraj Garg
Prof. Kirti Verma
Prof. Avadhesh Mishra
Prof. Ruby Goyal
Prof. Vipin K. pandey
Prof. Seema Joshi
Prof. Dinesh K. Goyal
Prof. Gunjan Sharma
Prof. Sanjay Tripathi
Prof. Pravesh Tomer
Dr. R K Gautam
Dr. Vishal Verma
Dr. Alok Shrivastva
Dr. Reena Diksit
Dr. Mohan Sharma
Dr. Sheetal Verma
Dr. Sanjay Singh
Dr. Shobhit Varshney
Dr. Sunil Gupta
Dr. Puneeta Pandey
Dr. Mayank Bhatkoti
Dr. G M Kavya
Dr. Devash Shukla
Dr. Reenu Rao
Dr R K Biswal
Dr. Anurag Vatts
Dr. S P Singh
Dr U N Pandey
Dr. Vimal Kumar
Dr. Naveen Joshi
Dr. Aditi Sharma
Dr. Pravesh Kumar Mukariya
Dr. Gyanendra Shukla
Dr. Nand Kishor Dhadich
Dr. Umapati Bargi
Dr. Anjana Tak
Dr. lla Tanna
Dr. Shashikant Tiwari
Dr. Shikha Pandey
Dr. Hem Prakash
Dr. Pallavi Bhushan
Dr. Priyanka Sharma
Dr. Rajeev Kumar
Dr. Varsha Sexsana
Dr. Archana Singh
Dr. Mannat Marwaha
Dr. Prabodh Yararam
Dr. Akansha Anupam
Dr. Jaspreet Soddi
Dr. Deepshikha
Dr. Tarun Uppadaya
Dr. Vipin Kumar Arora
Dr. Sweta Shukla
Dr. Arun Kumar
Dr. Priyanka Rani
Dr. N N Tiwari
Dr. Arun K. Sharma
Dr. Parul Sharma
Dr. Neha Joshi
National Advisory Committee
Dr. Deopujari Jayant Yeshwant, Chairperson, CISM, New Delhi.
Prof. S P Mishra, Former, VC, UA University, Harrawala Dehradun.
Prof. Abhimanyu Kumar, VC , SRRA University, Jodhpur, Rajasthan
Dr. Mayaram Uniyal, Ex-director, CCRAS, New Delhi.

<!-- page 3 -->

Dr. Vinod Uppadaya, Gurukal Ayurvedic College, Haridwar.
Prof. Sanjeev Sharma, Director cum, VC I/C, NIA, Jaipur, Rajasthan.
Prof. Baldev Singh Dhiman, VC, SKA University, Kurukshetra, Haryana.
Prof. AK Singh, VC, MG University, Gorakpur, Uttar Pradesh.
Prof. Meeta Kutecha, Pro-VC, NIA, Jaipur, Rajasthan.
Prof. Tanuja Manoj Nesari, Director, AIIA, New Delhi.
Dr. Rajendra Dobhal, Director, UBC, Haldi, Pantnagar.
Prof. Durgesh Pant, DG, UCOST, Vigyan Dham, Dehradun.
Prof. Anup B. Thakar, Director- ITRA, Jamnagar, Jamnagar.
Prof. R K Shastri, Gurukula Kangri (deemed to be Univ), Haridwar.
Dr. Chinmay Pandya, Pro-VC, DSVV, Haridwar.
Prof. Govid Sahay Shukla, Principal, UCA,DSRRAU, Jodhpur.
Prof Awdesh Bhatt, Head RSBK, MMM G A, Udaipur.
Prof. D N Gautam, Head Deptt of RSBK, ISM-BHU, Varanasi. UP
Prof. KS Dhiman, Deptt of Salakaya Tantra, ISM-BHU, Varanasi, UP
Prof. Vidula Gujjarwar, Principal, CBPACS, Najafgarh, New Delhi.
Prof. Mitlesh Verma, Principal, SKDGAC, Muzaffarnagar, UP.
Prof. Neelam Gupta, Principal, GAC&H, Chaukaghat, Varanasi, UP.
Prof. Prof. A K Singh Principal, LBSMGAC & H Handia, Prayagraj, UP
Prof. PC Sexena, Principal, GAC&H, Tulsidas Marg, Lucknow, UP
Prof. CK Rajput, Principal, GAC&H, Atarra, Banda, UP
Prof. Ravi Prakash, Principal, Bundelkhand GAC&H, Jhansi, UP
Prof. D K Maurya, Principal, SRM GAC&H, Bansmandi, Bareilly, UP
Prof. S S Bedar, Principal, LH GAC& H Pilibhit, UP.
Prof. Bharat Kalsariya Principal, GAC, Vadodhara, Gujrat.
Prof. Rajesh Barvaliya, Principal, GAA College, Ahmedabad, Gujrat.
Dr. K. Kanakavalli. Director General, CCRS, Chennai.
Dr. N. Srikanth, Depty DG, CCRAS, New Delhi.
Dr. Vijay Chaudhary, Principal, RGGPGA College, Paprola, Kangra.
Prof. Prabhat Kr. Diwedi, Deptt of RS & BK, GAC Patana, Bihar.
Prof. Sanjay Pandey, Head Deptt of RSBK, GAC & H, Varanasi, UP.
Prof Anupam Srivastava, Deptt of of RSBK, NIA Jaipur.
Dr. Rajendra P. Sharma, Head Deptt. of RSBK, NIA Jaipur.
Dr. Anjana Diwedi, Head Deptt of RS & BK, GAC &H, Luknow, UP.
Dr. Summar Singh Tomar, Head RSBK, CBPACS, Najafgarh, New Delhi
Dr. C K Katiyar, CEO, Health Care Divison, Emami, Kolkota (WB).
Dr. Rajeev Rai, GM, R&D, Heath Care, DRDC, Ghazibad, U.P.
Prof. Mahesh Dhadhichi, BPSW, Khanpur Kalan, Haryana.
Prof. Kamini Kaushal, Head Dravya Guna, MMM GA College, Udaipur.
Prof. Mansi Deshpandey, Head Dravya Guna, TAC, BVPU, Pune.
Prof. Bhupesh R. Patel, Head, Deptt of Draya Guna, ITRA Jamnagar.
Prof. B Ram Head, Deptt of Draya Guna, IMS-BHU, Varanasi, UP.
Prof. Ashwini, Head, Deptt of Draya Guna, Paprola. HP.
Prof Makan Lal, Head, Deptt of Draya Guna, GAC Lucknow, UP.
Prof. Anil Shukla, Head, Deptt of Draya Guna, GAC, Bhopal, MP.
Prof Jaram Singh, Head, Deptt of Agad Tantra, Paprola, HP.
Prof. Urmila Shukla, Head, Deptt of Agad Tantra, GAC, Bhopal, MP.
Dr. Ritu Kapoor, Head, Deptt of Agad Tantra, UCA, Jodhpur.
Dr. Ashwini Kr. Bharti, Head, Deptt of Agad Tantra, Hasan, SDM.
Prof. Satendra Rajput, Head Pharmaceutical Science., GKU, Haridwar.
Prof. Ashwani Upadhaya, Head DG, RGGPGA College, Paprola, Kangra.
Dr. Shalini Varshney, Deptt of Draya Guna, AUTC, Delhi.
Dr. Mukesh Sharma, Microbiology, GKU, Haridwar.
Dr. Vipin Kumar, Incharg,e deptt of Pharmaceutical Sci., GKU, Haridwar.
Dr. Vinod Nautiyal, Pharmacognosy, deptt of Pharmaceutical Sci., GKU,
Haridwar.
Technical Advisory Committee
Prof P K Bhardwaj
Dr. AK Jha
Dr. Satendra Goyal
Dr. Simran Kaur
Dr. Rishab Jain
Dr. Abhishek B Sharma
Dr. Ashwani Kamboj
Dr. SMD Sharma
Dr. Mubarak Ali
Dr. Ashok Sharma
Mr. Munish Saini
Dr. Anil Yadav
Dr. Umesh Sawant
Dr. Archana S Kamble
Dr. Kwaljeet Singh
Dr. Vipul Bartwal
Dr. D D Badhani
Dr. J S Jangpangi
Dr. Rajeev Verma
Dr. Pinki Khatti
Shree Chandra Bhushan Sharma
Dr. Vijay Rai
Dr. J K Panuli
Dr. Ajay Vishwakarma
Dr. Madhukar L Shevale
Dr. Dusyant Pratap Singh
How to reach the conference Venue
The venue (UAU, Gurukul Campus, Haridwar) is a well-reputed institution
of Govt. of Uttarakhand & it is adjacent to Gurukula Kangri (Deemed to be
University) situated at a distance of about 5 km. from Hardwar Railway
station and Bus Stand on NH 58 (Dehradun to Delhi). The nearest domestic
airport is Jolly grant is about 42 km and IGI Airport, Delhi is 200 Km far from
the spot.

INTERNATIONAL CONFERENCE
on
MEDICINAL PLANTS OF GANGA RIVER BASIN AND THEIR
THERAPEUTIC IMPORTANCE IN INDIAN SYSTEM OF MEDICINE

(5th – 6th September 2022)
Registration Form
Full Name (Capital Letters): _________________
Designation: _____________________________
Name of institute__________________________
Qualification: _____________________________
Corresponding Address: ____________________
Whatsapp Number: _______________________
Email Id: _________________________________
Tittle of Abstract/Article____________________
________________________________________
Paper presentation: Yes/No/oral/Poster______
Payment amount ₹_________________________
Mode of Payment: NEFT/ Cheque/ DD No.
Date of Payment: _________________________
Bank and Branch details: ___________________
Date:_______ Signature: __________________
Payment mode detail for
NEFT / RTGS or DD
A/C: Uttarakhand Ayurved University Conference and Seminar
A/C
A/C No: 922010030172748
IFSC code: UTIB0004623
Bank Name: Axis Bank
Branch: Nakrodha, Dehradun

You can pay through this QR Scan Code.

Received on:

For Office Use only
Regd. No.

*Photocopy of this form can be used for registration

Google form Link:
https://forms.gle/DTvx6MWxCHrzLeer8
