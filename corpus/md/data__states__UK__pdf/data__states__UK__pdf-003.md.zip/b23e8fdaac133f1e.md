---
doc_id: "b23e8fdaac133f1e"
source_url: "https://tsms.b-cdn.net/staging/healthadvisory/health_advisory.pdf"
ministry: "Digital Uttarakhand Service Portal, Uttarakhand"
title: "Safety & Guidelines  Stay informed with official advisories, travel tips, and fraud prevention guidelines for a secure experience."
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "ccdcad84000d6a29"
---

<!-- page 1 -->

<!-- page 2 -->

YATRA DONT’S

YATRA DO’S

SWASTH
SATARK
SAFAL
YATRA

www.eswasthyadham.uk.gov.in

MEDICAL CHECKUP

MRP & SCREENING

REGISTER

JUNK FOOD

EXCESS LUGGAGE

DIZZINESS

ACCLIMATIZATION

EXERCISE

VOMITING
VOMITING

CHEST
PAIN

HEALTHY & WARM
FOOD & BEVERAGES

PACK LIGHT

EMERGENCY & PRESCRIBED

ADJUST AS PER CHANGING

MEDICINE

Healthy pilgrim,
Happy pilgrimage

WEATHER

DANGER ZONE

DO NOT IGNORE

ALCOHOL / SMOKING

DRUGS

Register on the website below for regular monitoring of your health during Yatra

www.eswasthyadham.uk.gov.in
Issued in public interest by Department of Medical Health &
Family Welfare, Government of Uttarakhand

Supported by

A ßagship programme of LEHS (Lords Education and Health Society)

<!-- page 3 -->

YATRA DONT’S

YATRA DO’S

SWASTH
SATARK
SAFAL
YATRA

www.eswasthyadham.uk.gov.in

MEDICAL CHECKUP

MRP & SCREENING

REGISTER

JUNK FOOD

EXCESS LUGGAGE

DIZZINESS

ACCLIMATIZATION

EXERCISE

VOMITING
VOMITING

CHEST
PAIN

HEALTHY & WARM
FOOD & BEVERAGES

PACK LIGHT

EMERGENCY & PRESCRIBED

ADJUST AS PER CHANGING

MEDICINE

Healthy pilgrim,
Happy pilgrimage

WEATHER

DANGER ZONE

DO NOT IGNORE

ALCOHOL / SMOKING

DRUGS

Register on the website below for regular monitoring of your health during Yatra

www.eswasthyadham.uk.gov.in
Issued in public interest by Department of Medical Health &
Family Welfare, Government of Uttarakhand

Supported by

A ßagship programme of LEHS (Lords Education and Health Society)

<!-- page 4 -->

YATRA DONT’S

YATRA DO’S

SWASTH
SATARK
SAFAL
YATRA

www.eswasthyadham.uk.gov.in

MEDICAL CHECKUP

MRP & SCREENING

REGISTER

JUNK FOOD

EXCESS LUGGAGE

DIZZINESS

ACCLIMATIZATION

EXERCISE

VOMITING
VOMITING

CHEST
PAIN

HEALTHY & WARM
FOOD & BEVERAGES

PACK LIGHT

EMERGENCY & PRESCRIBED

ADJUST AS PER CHANGING

MEDICINE

Healthy pilgrim,
Happy pilgrimage

WEATHER

DANGER ZONE

DO NOT IGNORE

ALCOHOL / SMOKING

DRUGS

Register on the website below for regular monitoring of your health during Yatra

www.eswasthyadham.uk.gov.in
Issued in public interest by Department of Medical Health &
Family Welfare, Government of Uttarakhand

Supported by

A ßagship programme of LEHS (Lords Education and Health Society)

<!-- page 5 -->

YATRA DONT’S

YATRA DO’S

SWASTH
SATARK
SAFAL
YATRA

www.eswasthyadham.uk.gov.in

MEDICAL CHECKUP

MRP & SCREENING

REGISTER

JUNK FOOD

EXCESS LUGGAGE

DIZZINESS

ACCLIMATIZATION

EXERCISE

VOMITING
VOMITING

CHEST
PAIN

HEALTHY & WARM
FOOD & BEVERAGES

PACK LIGHT

EMERGENCY & PRESCRIBED

ADJUST AS PER CHANGING

MEDICINE

Healthy pilgrim,
Happy pilgrimage

WEATHER

DANGER ZONE

DO NOT IGNORE

ALCOHOL / SMOKING

DRUGS

Register on the website below for regular monitoring of your health during Yatra

www.eswasthyadham.uk.gov.in
Issued in public interest by Department of Medical Health &
Family Welfare, Government of Uttarakhand

Supported by

A ßagship programme of LEHS (Lords Education and Health Society)
