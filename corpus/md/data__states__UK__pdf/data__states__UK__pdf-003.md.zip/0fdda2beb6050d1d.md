---
doc_id: "0fdda2beb6050d1d"
source_url: "https://cdn.s3waas.gov.in/s3e6b4b2a746ed40e1af829d1fa82daa10/uploads/2024/01/2024012021.pdf"
ministry: "Rudraprayag"
title: "(2)शासनादेशों की गार्ड फाइल नजारत अधिष्ठान  तहसील   बसुकेदार  दिनांक 01-04-2022 से 31-03-2023 तक"
date: ""
pages: 8
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e139718d22d90795"
---

<!-- page 1 -->

9.36

0.95 0.15 0.80

4.79

0.076

10

10.16

tra)

r4eei

12

.

120 0.16, 8.00

2.00 0.16 8,00

02:

MÍGR)

tY
vfàra)ue
15
y

1.,70 0.50 1.20

=
W

or

aidyga

24
fT
21

8,08 7.18 0.80 0.70

cxpenses)

0.76 16.17 4.865

1,03 20,54

05%)

TT
(4

31|a
GHKI
32

GT
+RFID
WY

(Operating

05

Relalcd
Polcy(12+t3) |4
T
44hogHoo

1

4

3

2

1

"22.14

29.35
1.30

5.0

5.0

1714

22.35

05%)

% WàNT

@

4

05

atag

4.91

8:18 7.33 0.85

=
W

t

0.076

0.70

expenses)
Operatingg N+RFID

0A2 16.72 0.80 15,92 4,986

0.55 21.80 1.04 20.76

(4.2+5) T 2.5

SYOT

AOOO
5 42

()

<!-- page 2 -->

(25)
3

21.67
0.51

16,93

22.08

16.31

5.0

5.0

SDY R 2.5 %
T(4.2 + 5)

0.38

130
28.38

21.31

1

4

1U

|11/

fo
2

15 yI)

ByaT (t)

T

JT (t2)
3 4

7.00

700

0.14

0.14

1:75

1:05

8.89

8.19

1.05

0,70

050

0.15

1.55

0.85

0.70

0.075

H

1 aas +RFID =W

0.70

RurcT 4 (Operating expenses)

4.56

18,63
0.90

13.60

(4+4.1)

19.53

14.28

2.5 %

0.47

0.36

aT (4.2+5)

20.00

14.64

6.0

5.0

4.1|oyoio 05 gfaIT (4
HOG T

5 4R

4.49

8.19

4 atT ((1+M3)
2

6.79

2 50 130.00 va q6A/

05%)

HT Y

0.68

1.30
26.30

19,64

<!-- page 3 -->

26.30

19,64

Raed
Pobcy

1.30

HIT

qI61/

130.00

5.0

5.0.

R

Ý

0

2

0,47 19.53 0.90 18.63

8.19

14,64 036: 14.28 0.4 13.60 4.56

20,00

(4
T

05

05%)

% wfàT

(4.+5)2qT2.5(4+4.1)

@

T

14R GlH0doyHocto

(Operating
|farcg
expenses)

|41 aT4
5.|42(14+2+3)

6.79

449

=
W

0.075

0:70 0.70

+RFID

GIyd
32 3:1
iis
3

0.85

1.55

0.15

050 1.05

8.19

8.89

0.14 7.00

1.05 0.14 7.00

175

yàNIG)
(re 15

BYT(t1)

fHIT 27

60/e)

1

2

1

21.31

28.38

1,30

6.0

5.0

22.08

0.38 16.93

0.81 21.67

(4.2+5)
aT

2.5 R
%

L2T(4+4.1)

<!-- page 4 -->

4

2

4

7.0

70

1.05

0.70

1.75

1.05

0.14

0.14. .

9,94

8,89

5.60

5.33

6

0.70

0,70

7

1624

14.92

0.33

0.14

16.57.

i5.06.

2 ayd (RIyrt 10 wtNrK)

Rruee

15 9RI)

4

5

9

0.03

10

16.60

15.06

11 soutoyHoclo 9 uATA
12 HOGoyoo 9 ufaa

149

1.35

149

1.35

0.33

030

19.92

18.06

3

4

4

7.0

70

2

1,05

0.70

13

ATOR (a 2%

2

Poicy Retetd

<!-- page 5 -->

1.06

1.78

0.14

0.14

8.89 5.33 0.70 14,920.14

8

9

10 11

030 18.06

12

HIAGT
@
2%

otoyoto
9vftNa

17.29 17.291.58 1.56 035 20.76

15.0615.06135 1.35

R
2
faNIa)

9,94 6.57 0.70 17.150.14

trul
2
MitNra)

7

giPrufRa/ta
7.00 0.14 1.05

aNa)
02
RI4G

2

3

0.15 0.70 0.70

Ía)

0.15 1.05 0.70

(I 5Hi

15
Yo a

afayd

ufaxIa) 10
1
(Rro)

7.00 0,14 1.75

(tso/gi)

2

1

0.075 1.50 11.32

T
GT

(Operating

expenses)

0.25 1.50 12.54

8dar

Polloy
RelstLed

<!-- page 6 -->

2

19.11

13,41

7.0

12.11 023

13.41 0.25

0.31

2%
NT

028 028

0.31

12
)odlovHOTIo
Mftura25

6

<!-- page 7 -->

17

yd

1988

frqR

fei#

/H-333/86

H-t-2854

GT

far
eT

fg

07

2018

Bqt,

feiT

#A-NIKXXVI()50(16)/2016

2.

D

/

(30)

No.
4Z%.)

(Lomputer

Dpartment
n52lZXXYMTYE-428)W202!
togn-

fmime

KAVI

/97207

IN

s

e

<!-- page 8 -->

274/2023

4.

Slhned biy DipJavakar

Date: 09-03-2023 21:0216

J05219

FisT

ZXXYIDE 428312022 gGit2TL

Signed byGang Prasad
Dale: 10-03-2023 10:1023

29

1

(39)
