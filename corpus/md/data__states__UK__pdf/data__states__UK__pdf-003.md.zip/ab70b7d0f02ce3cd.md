---
doc_id: "ab70b7d0f02ce3cd"
source_url: "https://scert.uk.gov.in/assets/cells/1783268118.pdf"
ministry: "State Council of Educational Research & Training, Uttarakhand"
title: "Nipun-Bharat-Guidelines"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "900dd1aea4506e5f"
---

<!-- no text layer: pending OCR -->
