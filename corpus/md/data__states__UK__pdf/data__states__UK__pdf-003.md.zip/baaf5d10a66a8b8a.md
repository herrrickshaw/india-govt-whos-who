---
doc_id: "baaf5d10a66a8b8a"
source_url: "https://scert.uk.gov.in/public/assets/cells/1699512937.pdf"
ministry: "State Council of Educational Research & Training, Uttarakhand"
title: "Draft of National Education Policy 2020 by Dr. K.Kasturirangan (Hindi)"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "6bac2fbeaf009e17"
---

<!-- no text layer: pending OCR -->
