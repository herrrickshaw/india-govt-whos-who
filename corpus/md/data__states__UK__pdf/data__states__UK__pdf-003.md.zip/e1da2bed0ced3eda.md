---
doc_id: "e1da2bed0ced3eda"
source_url: "https://startuputtarakhand.uk.gov.in/attachments/169710593715.pdf"
ministry: "Startup Uttarakhand"
title: "Office order_Sustainability.pdf"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "f8514662bc80c3fd"
---

<!-- page 1 -->

ss ]
Govt of Uttarakhand
Directorate of Industries
Industrial Area, nap Nagar, Dehradun — 24800!
Letter No.) - OI, (5)/startup/207-8
Dated: Iefogam
Tel: +935-2728272, 2728227,I2520604 Fax: +935-2728226
Toll Free: 7685 44555 Email: startupcelluk@gmail.com
Website: www.startuputtarakhand.com
Office Order
Startups working on renewable energy would engage in reducing carbon footprints through a
renewable and sustainable source of energy using clean technologies such as solar energy, wind energy, hydro
energy, tidal energy, geothermal energy biomass energy etc.

Startups working on climate change would engage in the areas of eco-friendly and/or climate-
friendly technologies/solutions that help in reducing and offsetting carbon emissions or increasing the green cover
of the region.

Startups working on sustainability would engage in green and sustainable practices along with
| next generation cutting edge technologies, processes or solutions that are enabling the world at large to recover
from years of overuse such as improving soil health, protection of endangered species, clean technologies for
alternative energy sources, etc.
(GK
(Shikhar Saxena)
Joint Director Industries
