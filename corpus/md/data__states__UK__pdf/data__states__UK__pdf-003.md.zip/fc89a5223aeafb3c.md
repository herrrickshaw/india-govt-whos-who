---
doc_id: "fc89a5223aeafb3c"
source_url: "https://cdn.s3waas.gov.in/s347d1e990583c9c67424d369f3414728e/uploads/2022/06/2022061065.pdf"
ministry: "Pithoragarh"
title: "sugam durgam posting (616 KB)"
date: ""
pages: 45
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "a49888a408c47e2b"
---

<!-- page 1 -->

fu;fer vf/k"Bku ftyk dk;kZy; fiFkkSjkx<+ vUrxZr orZeku esa dk;Zjr dkfeZd ls lacaf/kr fooj.k
fnukad 31-03-2021 rd
dz0 dkfeZdk dk uke ,Oka
la0
orZeku in uke

tUe frfFk

tuin@rglhydk;
kZy; dkuke

x`g rglhy

lqxe rglhy esa rSukrh dk fooj.k

nqxZe rglhy esa rSukrh dk fooj.k

rSukrh dk
in

dk;kZy; dk
uke

vof/k¼dCk ls
dc rd½

rSukrh dk
in

dk;kZy;
dk uke

vof/k¼dc ls
dc rd½

iVy dk uke

vof/k ¼dc ls dc rd½

10

11

12

13

1

2

3

4

5

6

7

8

9

1

Jh iznhi iqusM+kiz/kku
lgk;d ]'kL=] ftyk
dk;kZy;] fiFkkSjkx<+

14-07-1970

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;

11-05-1994 ls

ofj"B
lgk;d

ofj"B
lgk;d

ftyk
dk;kZy;

iz/kku
lgk;d

ftyk
dk;kZy;

Jherh xhrk
fljkSykofj"B lgk;d]
U;kf;d vfHkys[kkxkj]
ftyk dk;kZy;]fiFkkSjkx<+

28-06-1969

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

19-05-1998 rd
20-05-1998 ls

06-07-2010 ls

/kkjpwyk

23-07-2012 rd

&

&

&

&

equL;kjh

25-06-2019ls
31-03-2021

05-07-2010 rd
24-07-2012 ls
24-06-2019 rd
2s3o"kZ 23 fnu

;ksx
2

iVy esa dk;Zjr jgus dh vof/k

rglhy
fiFkkSjkx<+

25-06-2000 ls
12-11-2003 rd

dfu"B
lgk;d

xaxksyhgkV

jktLo
ys[kkdkj
rglhy
equL;kjh

25-06-2019 ls orZeku rd

03 o"kZ 09 ekg
23 fnu

&

01 o"kZ 09 ekg 06 fnu

05-11-1999 ls

ofj"B lgk;d]
U;kf;d
vfHkys[kkxkj]
ftyk dk;kZy;
fiFkkSjkx<+

20-07-2011 ls orZeku rd

&

09 o"kZ 08 ekg 11 fnu

24-06-2000rd

ofj"B
lgk;d

ftyk
dk;kZy;

13-11-2003 ls
31-03-2021 rd

&

&

&

;ksx

&

20 o"kZ 09 ekg 06
fnu

&

&

07ekg]20fnu

<!-- page 2 -->

-23

Jh ds'ko nRr cp[ksrh
iz/kku lgk;d rglhy
x.kkbZ xaxksyh

25-06-1970

fiFkkSjkx<+@x.kkbZa
xaxksyh

ckxs'oj

dfu"B
lgk;d

ftyk
dk;ky;

10-04-2000 ls
24-06-2000 rd

dfu"B
lgk;d

csjhukx

25-06-2000 ls
28-02-2004 rd

ofj"B
lgk;d

ftyk
dk;kZy;

15-07-2006 ls
27-09-2007 rd

ofj"B
lgk;d

csjhukx

01-03-2004 ls
14-07-2006 rd

ofj’B
lgk;d

ftyk
dk;kZy;

20-06-2018 ls
29-08-2018 rd

ofj"B
lgk;d

osjhukx

&

&

&

ofj"B
lgk;d

xaxksyhgkV

iz/kku
lgk;d

rglhy
x.kkbZ&

&

&

&

28-09-2007 ls
27-07-2011 rd

jktLo
ys[kkdkj
rglhy x.kkbZ
xaxksyh

29-08-2018 ls orZeku rd

28-07-2011 ls
19-06-2018 rd
30-08-2018 ls
31-03-2021 rd

xaxksyh

4

Jh egs'k pUnz tks'kh
iz/kku lgk;d rglhy
/kkjpwykA

18-02-1970

fiFkkSjkx<+@ equL;kjh@
rglhy dk;kZy;
equL;kjh

rste

;ksx

&

01 Ok"kZ] 07ekg]
08fnu

&

&

19 o"kZ 04 ekg
06 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

01-09-2000 ls

ofj"B
lgk;d

csjhukx

01-03-2004 ls

;ksx

28-02-2004 rd

&

03 Ok"kZ]
05ekg]28fnu

02 o"kZ 07 ekg 02 fnu

31-07-2009 rd

ofj"B
lgk;d

equL;kjh

01-08-2009 ls
29-08-2018 rd

iz/kku
lgk;d

rglhy
/kkjpwyk

30-08-2018 ls
31-03-2021 rd

&

&

17o"kZ] 01 ekg]
27 fnu

jktLo
ys[kkdkj]
rglhy
dk;kZy;
/kkjpwyk

29-08-2018 ls orZeku rd

02 o"kZ 07 ekg 02 fnu

<!-- page 3 -->

-35

6

7

Jherh deyk iUr
iz/kku lgk;d rglhy
csjhukx

Jherh deyk ukFk
iz/kku lgk;d rglhy
nsoyFky

Jh Hkwiky flag
iz/kku lgk;d jktLo]
ftyk dk;kZy;
fiFkkSjkx<+
ofj"B dkfeZd
30-09-2021 dks vf/ko"kZrk
ij lsokfuo`fRr izLrkfor

01-07-1964

14-12-1971

14-09-1961

fiFkkSjkx<+@ csjhukx@
rglhy dk;kZy;
csjhukx

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@fiFkkSjkx<+@
ftyk dk;kZy;
fiFkkSjkx<+

MhMhgkV

fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

fiFkkSjkx<+

02-10-2004 ls
29-07-2005 rd

dfu"B
lgk;d

xaxksyhgkV

ofj"B
lgk;d

MhMhgkV

30-07-2005 ls
07-07-2008 rd

iz/kku
lgk;d

csjhukx

10-08-2009 ls
31-03-2021 rd

ofj"B
lgk;d

fiFkkSjkx<+

08-07-2008 ls
09-08-2009 rd

&

&

&

;ksx

&

04 Ok"kZ] 10ekg] 08
fnu

&

&

14 o"kZ] 09 ekg]
06 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

15-07-2002 ls
30-07-2005 rd

ofj"B
lgk;d

equL;kjh

31-07-2005 ls

iz/kku
lgk;d

ftyk
dk;kZy;

14-07-2006 ls
28-09-2018 rd

iz/kku
lgk;d

nsoyFky

29-09-2018 ls
31-03-2021 rd

;ksx

&

15 Ok"kZ] 03 ekg]
01fnu

&

&

03 o"kZ] 08 ekg]
12 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

05-02-2003 ls
31-07-2005 rd

ofj"B
lgk;d

equL;kjh

01-08-2005 ls
04-08-2009 rd

ofj"B
lgk;d

dukyhNhuk

05-08-2009 ls
25-07-2011 rd

ofj"B
lgk;d

/kkjpwyk

07-10-2012 ls
22-06-2016 rd

ofj"B
lgk;d

MhMhgkV

26-07-2011 ls
06-10-2012 rd

&

&

&

ofj"B
lgk;d

rglhy
fiFkkSjkx<+

23-06-2016 ls
29-08-2018 rd

&

&

&

iz/kku
lgk;d

ftyk
dk;kZy;

30-08-2018 ls
31-03-2021 rd

;ksx

&

10 Ok"kZ] 03ekg
01fnu

&

&

07o"kZ] 08 ekg]
20fnu

-4-

16-08-2001 ls
01-10-2004 rd

13-07-2006 rd

jktLo
ys[kkdkj]
rglhy
dk;kZy;
csjhukx

29-08-2018 ls orZeku rd

02 o"kZ 07 ekg 02 fnu

jktLo
ys[kkdkj]
rglhy
dk;kZy;
nsoyFky

29-09-2018 ls orZeku rd

02 o"kZ 06 ekg 02 fnu
iz/kku lgk;d
jk0l0 ftyk
dk;kZy;
fiFkkSjkx<+

29-08-2018 ls orZeku rd

02 o"kZ 07 ekg 02 fnu

<!-- page 4 -->

8

9

10

Jh fnus'k eksgu ik.Ms;
iz/kku lgk;d@is”kdkj
ftykf/kdkjh dk;kZy;
fiFkkSjkx<+

Jh dey fd'kksj ik.Ms;
iz/kku lgk;d] uktjkr
ftyk dk;kZy;]
fiFkkSjkx<+

Jh uhjt dqekj iUr
iz/kku lgk;d vkcdkjh
ftyk dk;kZy;]
fiFkkSjkx<+

14-07-1972

01-01-1985

02-07-1981

fiFkkSjkx<+@nsoYkFky+@
rglhy dk;kZy;
nsoYkFky

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

nsoYkFky

fiFkkSjkx<+

xaxksyhgkV

ofj"B
lgk;d

MhMhgkV

01-10-2007
ls13-01-2015
rd

dfu"B
lgk;d

/kkjpwyk

06-02-2003 ls3009-2007 rd

iz/kku
lgk;d

ftyk
dk;kZy;

30-08-2018 ls
31-03-2021 rd

ofj"B
lgk;d

nsoyFky

14-01-2015 ls 2908-2018 rd

;ksx

&

09o"kZ] 10 ekg 11
fnu

&

&

08Ok"kZ]
03ekg]11fnu

dfu"B
lgk;d

ftyk
dk;kZy;

19-02-2003 ls
27-09-2007 rd

ofj"B
lgk;d

xaxksyhgkV

28-09-2007 ls

ofj’B
lgk;d

ftyk
dk;kZy;

02-08-2012 ls
29-08-2018 rd

ofj"B
lgk;d

nsoyFky

iz/kku
lgk;d

ftyk
dk;kZy;

30-08-2018 ls
31-03-2021 rd

ofj"B
lgk;d

/kkjpwyk

16-10-2013 ls

lEc)

12-12-2013 rd

;ksx

&

13Ok"kZ] 03ekg04fnu

&

&

05o"kZ] 0ekg]
03fnu

dfu"B
lgk;d

ftyk
dk;kZy;

09-04-2003 ls
08-02-2009 rd

&

&

&

ofj’B
lgk;d

ftyk
dk;kZy;

09-02-2009 ls
29-08-2018 rd

&

&

&

iz/kku
lgk;d

ftyk
dk;kZy;

29-08-2018 ls
31-03-2021 rd

;ksx

&

17Ok"kZ] 11 ekg]

&

&

&

21 fnu

is'kdkj]
U;k;ky;
ftykf/kdkjh
fiFkkSjkx<+

29-08-2018 ls orZeku rd

02 o"kZ 07 ekg 02 fnu

22-07-2011rd
23-07-2011 ls
01-08-2012 rd

iz/kku lgk;d]
uktjkr ftyk
dk;kZy;]
fiFkkSjkx<+

29-08-2018 ls orZeku rd

02 o"kZ 07 ekg 02 fnu
iz/kku lgk;d
vkcdkjh ftyk
dk;kZy;]
fiFkkSjkx<+

29-08-2018 ls orZeku rd

02 o"kZ 07 ekg 02 fnu

<!-- page 5 -->

-511

Jherh euh"kk pUn
ofj"B lgk;d] ou]
ftyk dk;kZy;]fiFkkSjkx<+

01-07-1973

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;

23-07-2009 ls
21-05-2010 rd

dfu"B
lgk;d

xaxksyhgkV

ofj"B
lgk;d

ftyk
dk;kZy;

22-05-2010 ls
31-03-2021 rd

&

&

&

;ksx

&

11 Ok"kZ] 08ekg]

&

&

05Ok"kZ]
01ekg]15fnu

dfu"B
lgk;d

nsoyFky

11-06-2004 ls

ofj"B
lgk;d

equL;kjh

ofj"B
lgk;d

csjhukx

ofj"B
lgk;d

equL;kjh

29-12-2017 ls
08-02-2018

ofj"B
lgk;d

rste

09-02-2018 ls
25-03-2019 rd

07fnu
12

Jh iadt dqekj
ofj"B lgk;d@uk;c
ukftj] rglhy equL;kjh

30-06-1979

fiFkkSjkx<+@equL;kjh@
rglhy dk;kZy;
equL;kjh

fiFkkSjkx<+

08-06-2004 ls
22-07-2009 rd

ofj"B
lgk;d

fiFkkSjkx<

ofj"B
lgk;d

ftyk
dk;kZy;

ofj"B
lgk;d

tux.kuk

02-08-2011 ls
26-12-2011 rd
27-12-2011 ls
24-01-2013 rd
25-01-2013 ls
26-03-2014 rd

26-09-2006 rd

27-07-2015 ls orZeku

fiFkkSjkx<+

05 o"kZ 08 ekg 4 fnu

ofj"B
lgk;d@uk;c
ukftj] rglhy
equL;kjh

fnukad 26-03-2019 ls
orZeku rd

27-09-2006 ls
01-08-2011 rd
11-07-2014 ls
28-12-2017 rd

ofj"B
lgk;d

ftyk
dk;kZy;

27-03-2014 ls
10-07-2014

ofj"B
lgk;d

equL;kjh

26-03-2019 ls
31-03-2021 rd

;ksx

&

02Ok"kZ] 11ekg]

&

&

14Ok"kZ] 08ekg]

09fnu

ofj"B lgk;d]
ou] ftyk
dk;kZy;]

28fnu

02 o"kZ 05 fnu

<!-- page 6 -->

-6-

13

Jh Hkjr yky
dfu"B lgk;d@ mi
rglhy ika[kwA

12-06-1985

fiFkkSjkx<+@
csjhukx@rglhy
dk;kZy; csjhukx

csjhukx

ofj"B
lgk;d

MhMhgkV

24-06-2019 ls
29-06-2020 rd

dfu"B
lgk;d

xaxksyhgkV

14-10-2004 ls
11-09-2006

&

&

&

ofj"B
lgk;d

csjhukx

12-09-2006 ls
20-07-2011 rd

&

&

&

ofj"B
lgk;d

xaxksyhgkV

21-07-2011 ls
15-03-2015 rd

&

&

&

ofj"B
lgk;d

x.kkbZ&
xaxksyh

16-03-2015 ls
21-07-2016rd

&

&

&

ofj"B
lgk;d

xaxksyhgkV

22-07-2016 ls
18-09-2016 rd

&

&

&

ofj"B
lgk;d

x.kkbZ&
xaxksyh

19-09-2016 ls
12-11-2017 rd

&

&

&

ofj"B
lgk;d

13-11-2017 ls
23-06-2019rd

&

&

&

dfu"B
lgk;d

30-06-2020 ls
31-03-2021 rd

1 o"kZ 05 fnu

&

;ksx

&

15 o"kZ 02 ekg
21 fnu

dfu"B
lgk;d
mi rglhy
ika[kw

30-06-2020 ls orZeku rd

09 ekg 01 fnu

<!-- page 7 -->

-714

15

Jh jktsUnz flag iky
ofj"B lgk;d rglhy
MhMhgkV

Jh ikjl dU;ky
ofj"B lgk;d@uk;c
ukftj] rglhy csjhukx

12-03-1973

18-08-1986

fiFkkSjkx<+@/kkjpwyk@
rglhy dk;kZy;
/kkjpwyk

fiFkkSjkx<+@ MhMhgkV@
rglhy dk;kZy;
MhMhgkV

/kkjpwyk

MhMhgkV

dfu"B
lgk;d

ftyk
dk;kZy;

dfu"B
lgk;d

ftyk
dk;kZy;

ofj"B
lgk;d

ftyk
dk;kZy;

ofj"B
lgk;d

dukyhNhuk

ofj"B
lgk;d

06-07-2010 ls

dfu"B
lgk;d

/kkjpwyk

ofj"B
lgk;d

/kkjpwyk

ofj"B
lgk;d

nsoyFky

05-07-2014 ls
28-06-2016

ofj"B
lgk;d

/kkjpwyk

14-11-2017 ls 2908-2018 rd

MhMhgkV

26-08-2020 ls
31-03-2021 rd

ofj"B
lgk;d

nsoyFky

30-08-2018 ls
25-08-2020

;ksx

&

11 o"kZ 07 ekg
11 fnu

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

04-03-2006 ls
03-11-2006 rd

ofj"B
lgk;d

nsoyFky

dfu"B
lgk;d

MhMhgkV

04-11-2006 ls
27-05-2014

ofj"B
lgk;d

csjhukx

06-07-2019 ls
30-08-2020 rd

ofj"B
lgk;d

MhMhgkV

13-01-2015 ls
05-07-2019 rd

ofj"B
lgk;d

equL;kjh

31-08-2020 ls
21-03-2021 rd

&

&

&

ofj"B
lgk;d

csjhukx

22-03-2021 ls
31-03-2021 rd

;ksx

&

12 o"kZ 06 ekg
75 fnu

;ksx

&

02 o"kZ 04 ekg
05 fnu

28-02-2005 ls
05-07-2010 rd
28-09-2010 ls
30-05-2014 rd
31-05-2014 ls
04-07-2014 rd

27-09-2010rd

uk;c ukftj
rglhy
MhMhgkV

26-08-2020 ls orZeku rd

29-06-2016 ls
22-07-2016 rd

23-07-2016 ls
13-11-2017

02 o"kZ 25 ekg
106 fnu
28-05-2014 ls
12-01-2015 rd

07 ekg 05 fnu
ofj"B
lgk;d@
uk;c ukftj]
rglhy
csjhukx

06-07-2019 ls
22-03-2021rd ¼foHkkxh;
dk;Zokgh izpfyr gksus ls
mDr dkfeZd fnukad
31-08-2020 ls
21-03-2021 rd vof/k 06
ekg 18 fnu rd fuyacu
mijkUr rglhy dk;kZy;
equL;kjh lEc) jgasA ½

01 o"kZ 08 ekg 25 fnu

<!-- page 8 -->

-816

Jh /kekZuUn ikBd
ofj"B lgk;d] vkaXy
vfHkys[kkxkj] ftyk
dk;kZy; fiFkkSjkx<+

10-06-1966

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

vYeksM+k

dfu"B
lgk;d

dfu"B
lgk;d

17

18

Jh [khekuUn HkV~V
ofj"B lgk;d@
is'kdkj] miftykf/kdkjh
U;k;ky; /kkjpwyk

Jh xks/ku flag thuk
ofj"B lgk;d@is'kdkj
miftykf/kdkjh U;k;ky;
MhMhgkV

20-04-1988

15-06-1968

fiFkkSjkx<+@/kkjpwyk@
rglhy dk;kZy;
/kkjpwyk

fiFkkSjkx<+@MhMhgkV@
rglhy dk;kZy;
MhMhgkV

/kkjpwyk

uSuhrky

ftyk
dk;kZy;

12-06-2006 ls
23-07-2011 rd

miftykf/kdkjh 24-07-2011 ls
dk;kZy;
02-06-2014 rd
fiFkkSjkx<+

ofj"B
lgk;d

nsoyFky

03-06-2014 ls
25-05-2016 rd

&

&

&

ofj"B
lgk;d]
vkaXy
vfHkys[kkxkj]
ftyk dk;kZy;
fiFkkSjkx<+

26-05-2016 ls orZeku
rd

ofj"B
lgk;d

ftyk
dk;kZy;

26-05-2016 ls
31-03-2021rd

&

&

&

;ksx

&

12Ok"kZ] 09ekg]23fnu

&

&

01 Ok"kZ] 11ekg]
23fnu

&

&

&

dfu"B
lgk;d

xaxksyhgkV

26-09-2006 ls
04-08-2012 rd

&

&

&

dfu"B
lgk;d

/kkjpwyk

05-08-2012 ls
28-05-2014 rd

&

&

&

ofj"B
lgk;d

/kkjpwyk

29-05-2014 ls
31-03-2021 rd

;ksx

&

&

&

&

14 Ok"kZ] 06 ekg]
02 fnu

06 o"kZ 10 ekg 02 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

13-06-2007 ls
17-11-2011 rd

&

&

&

11-03-2016 ls orZeku
rd

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

18-11-2011 ls
10-03-2016

&

&

&

ofj"B
lgk;d

rglhy
MhMhgkV

11-03-2016 ls
31-03-2021 rd

&

&

&

;ksx

&

13 Ok"kZ] 09
ekg]15 fnu

&

&

-9-

04 o"kZ 10 ekg 5 fnu

is'kdkj]
miftykf/kdkjh
U;k;ky;
/kkjpwyk

29-05-2014 ls orZeku rd

is'kdkj
miftykf/kdkjh
U;k;ky;
MhMhgkV

05 o"kZ 20 fnu

<!-- page 9 -->

19

20

Jh egs'k flag Hk.Mkjh
ofj"B lgk;d@is'kdkj]
U;k;ky;
miftykf/kdkjh] equL;kjh

Jh pUnz izdk'k ik.Ms;
ofj"B lgk;d@Hkwys[k

18-10-1989

10-06-1988

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

fiFkkSjkx<+

+

21

Jherh iq"ik clsM+k
ofj"B lgk;d@ uk;c
ukftj@jktLo ys[kkdkj]
rglhy Fky

22-10-1990

fiFkkSjkx<+@ Fky+@
rglhy dk;kZy; Fky

nsoyFky

dfu"B
lgk;d

ftyk
dk;kZy;

19-11-2008 ls
22-06-2016 rd

ofj"B
lgk;d

equL;kjh

26-07-2019 ls 3103-2021 rd

ofj"B
lgk;d

ftyk
dk;kZy;

23-06-2016 ls
25-07-2019 rd

&

&

&

;ksx

&

10Ok"kZ] 08ekg] 5fnu

&

&

01 Ok"kZ] 08 ekg]
03fnu

dfu"B
lgk;d

ftyk
dk;kZy;

27-06-2012 ls
22-06-2016 rd

dfu"B
lgk;d

xaxksyhgkV

10-02-2009 ls

ofj"B
lgk;d

ftyk
dk;kZy;

23-06-2016 ls
31-03-2021 rd

dfu"B
lgk;d

nsoyFky

;ksx

&

08 Ok"kZ] 09 ekg]
04 fnu

&

&

03 Ok"kZ] 04
ekg]17fnu

dfu"B
lgk;d

dukyhNhUkk

26-02-2009 ls

dfu"B
lgk;d

csjhukx

08-07-2014 ls

&

&

ofj"B
lgk;d

xa.kkbZ&

23-06-2016 ls

xaxksyh

13-09-2016 rd

ofj"B
lgk;d

csjhukx

14-09-2016 ls

&

07-07-2014 rd
&

&

&

12-07-2010 rd

26-07-2019 ls orZeku rd

01 Ok"kZ] 08 ekg] 03fnu
ofj"B
lgk;d@
Hkwys[k] ftyk
dk;kZy;

29-08-2018 ls orZeku rd

13-07-2010 ls
26-06-2012 rd

22-06-2016 rd

02 Ok"kZ] 07 ekg] 02 fnu
uk;c
ukftj@jktLo
ys[kkdkj]
rglhy Fky

22-11-2017 ls 31-03-2021
rd

21-11-2017

&

&

&

ofj"B
lgk;d

Fky

22-11-2017 ls
31-03-2021 rd

;ksx

&

05 Ok"kZ] 04 ekg]
13 fnu

&

&

06 o"kZ] 08 ekg]
21fnu

-10-

is'kdkj]
U;k;ky;
miftykf/kdkjh
] equL;kjh

03 o"kZ] 04 ekg] 09fnu

<!-- page 10 -->

22

23

Jherh xksik tks'kh
ofj"B lgk;d] rglhy
rste lEc) laxzg]
ftyk dk;kZy;]
fiFkkSjkx<+

Jh lUrks"k flag] ofj"B
lgk;d@uk;c ukftj]
rglhy dk;kZy;]
xaxksyhgkV

10-04-1982

20-03-1988

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@rglhy
dk;kZy; xaxksyhgkV

fiFkkSjkx<+

csjhukx

ofj’B
lgk;d

ftyk
dk;kZy;

13-07-2010 ls
31-03-2021 rd

dfu"B
lgk;d

nsoyFky

;ksx

&

10 Ok"kZ] 08 ekg] 18
fnu

&

&

01 Ok"kZ] 0 ekg]
21 fnu

&

&

&

dfu"B
lgk;d

xaxksyhgkV

22-07-2009 ls
28-07-2011 rd

&

&

&

dfu"B
lgk;d

csjhukx

29-07-2011 ls

ofj"B
lgk;d

ika[kw

&

24

Jh vkse izdk'k ofj"B
lgk;d@is'kdkj]
U;k;ky;
miftykf/kdkjh]
xaxksyhgkV

08-03-1981

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

}kjkgkV

&

&

23-06-2009 ls
12-07-2010 rd

04-05-2017 rd
05-05-17 ls

&

&

ofj"B
lgk;d

xaxksyhgkV

26-07-2019 ls
31-03-2021 rd

;ksx

&

&

&

&

11 Ok"kZ] 09 ekg]
04 fnu

ofj"B
lgk;d

ftyk
dk;kZy;

04-08-2011 ls
29-08-2018 rd

dfu"B
lgk;d

xaxksyhgkV

25-07-2009 ls

&

&

&

ofj"B
lgk;d

equL;kjh

01-09-2010 ls
03-08-2011 rd

ofj"B
lgk;d

xaxksyhgkV

30-08-2018 ls
31-03-2021 rd

&

&

04Ok"kZ] 07 ekg]
06fnu

&

07Ok"kZ]26fnu

fnukad 04-01-2017 ls
orZeku rd

04 o"kZ 02 ekg 27 fnu

uk;c ukftj]
rglhy
dk;kZy;]
xaxksyhgkV

26-07-2019 ls orZeku rd

25-07-2019 rd

&

;ksx

ofj"B lgk;d]
rglhy rste
lEc) laxzg]
ftyk
dk;kZy;]
fiFkkSjkx<+

31-08-2010 rd

01 o"kZ 08 ekg 05 fnu
is'kdkj]
U;k;ky;
miftykf/kdkjh
] xaxksyhgkV

30-08-2018 ls 31-03-2021
rd

02 o"kZ 07 ekg 01 fnu

<!-- page 11 -->

-1125

26

Jh izse pUnz tks'kh
ofj"B lgk;d
[kuu@is”kdkj vij
ftykf/kdkjh dk;kZy;
fiFkkSjkx<

02-08-1984

Jh nhid flag iqtkjh]
ofj"B lgk;d@uk;c
ukftj] rglhy
dk;kZy;] fiFkkSjkx<+A

01-04-1991

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@rglhy
dk;kZy; fiFkkSjkx<+

caxkikuh

MhMhgkV

ofj"B
lgk;d

ftyk
dk;kZy;

25-07-2009 ls
25-03-2021 rd

&

&

&

;ksx

&

11Ok"kZ] 08ekg]
0fnu

&

&

^&

dfu"B
lgk;d

MhMhgkV

04-06-2014 ls
07-04-2017 rd

dfu"B
lgk;d

equL;kjh

06-08-2009 ls

ofj’B
lgk;d

fiFkkSjkx<

26-07-2019 ls
31-03-2021 rd

dfu"B

xaxksyhgkV

&

&

&

27-07-2011 rd

rste

08-04-2017 ls 2908-2018 rd

ofj’B
lgk;d

equL;kjh

30-08-2019 ls
25-07-2019 rd

ofj"B

Jh izdk'k flag ckfQyk
ofj"B lgk;d@is'kdkj]
U;k;ky;
miftykf/kdkjh] csjhukx

13-07-1990

fiFkkSjkx<+@csjhukx

csjhukx

;ksx

&

04 Ok"kZ] 06 ekg]
06 fnu

&

&

07 Ok"kZ] 01 ekg]
13 fnu

&

&

&

dfu"B
lgk;d

/kkjpwyk

15-09-2009 ls
03-08-2012 rd

&

&

&

dfu"B
lgk;d

xaxksyhgkV

04-08-2012 ls
05-05-2017 rd

&

&

&

ofj"B
lgk;d

ik[kw

06-05-2017 ls

ofj"B
lgk;d

x.kakbZ&

18-11-2017 ls

xaxksyh

28-08-2018 rd

&

&

&

29-08-2018 ls orZeku rd

uk;c ukftj]
rglhy
dk;kZy;]
fiFkkSjkx<+A

26-07-2019 ls orZeku
rd

02 o"kZ 07 ekg 02 fnu

03-06-2014 rd

lgk;d

lgk;d

27

28-07-2011 rd

ofj"B lgk;d]
[kuu@is”kdkj]
vij
ftykf/kdkjh
dk;kZy;]
fiFkkSjkx<

01 Ok"kZ] 08 ekg] 03fnu

is'kdkj]
U;k;ky;
miftykf/kdkjh
] csjhukx

29-08-2018 ls orZeku rd

17-11-2017 rd

&

&

&

ofj"B
lgk;d

csjhukx

29-08-2018 ls
31-03-2021 rd

;ksx

&

&

&

&

11 o"kZ 06 ekg 11
fnu

02 o"kZ 07 ekg 02 fnu

<!-- page 12 -->

-1228

29

30

Jh egs'k pUnz ikBd]
ofj"B lgk;d@uk;c
ukftj] rglhy
dukyhNhukA

Jh /keZ flag uiyP;ky]
ofj’B lgk;d@uk;c
ukftj] rglhy
dk;kZy;] /kkjpwykA

Jh pUnz eksgu ik.Ms;
ofj’B lgk;d
LVkEi@ifjogu
f'k{kk@fpfdRlk] ftyk
dk;kZy;] fiFkkSjkx<+

04-04-1966

06-05-1972

fiFkkSjkx<+@dukyhNhuk

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

Fky

/kkjpwyk

dfu"B
lgk;d

ftyk
dk;kZy;

15-02-2005 ls
03-01-2007 rd

dfu"B
lgk;d

csjhukx

11-07-2008 ls
18-07-2008

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

04-01-2007 ls
10-07-2008 rd

dfu"B
lgk;d

csjhukx

01-01-2010 ls
31-12-2011 rd

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

19-07-2008 ls
31-12-2009 rd

dfu"B
lgk;d

equL;kjh

01-01-2012 ls
15-12-2016 rd

dfu’B
lgk;d

ftyk
dk;kZy;

08-06-2018 ls
03-08-2020 rd

dfu"B
lgk;d

Fky

16-12-2016 ls
19-01-2018 rd

ofj"B
lgk;d

dukyhNhuk

04-08-2020 ls
31-03-2021 rd

dfu"B
lgk;d

equL;kjh

20-01-2018 ls
08-06-2018 rd

;ksx

&

07 Ok"kZ] 07 ekg]
29 fnu

&

&

08 Ok"kZ] 05 ekg]
16 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

08-10-2009 ls
03-08-2020 rd

dfu’B
lgk;d

equL;kjh

09-06-2018 ls
29-08-2018 rd

ofj’B
lgk;d

25-09-1981

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

/kkjpwyk

30-08-2018 ls
25-03-2021 rd

;ksx

&

08 Ok"kZ] 08 ekg] 01
fnu

dfu"B
lgk;d

tux.kuk]
dk;kZy;]
fiFkkSjkx<+

03-04-2010 ls
18-07-2011 rd

dfu"B
lgk;d

/kkjpwyk

27-07-2011 ls
07-10-2012 rd

dfu"B
lgk;d

ftyk
dk;kZy;

19-07-2011 ls
26-07-2011 rd

&

&

&

dfu"B
lgk;d

tux.kuk]
ftyk
fiFkkSjkx<+

08-10-2012 ls
27-01-2013 rd

&

&

&

uk;c ukftj]
rglhy
dukyhNhukA

04-08-2020 ls orZeku
rd

07 ekg 27 fnu
uk;c ukftj]
rglhy
dk;kZy;]
/kkjpwykA

02 Ok"kZ] 07 ekg]
04 fnu

30-08-2018 ls 25-03-2021
rd
¼fnukad 13-04-2021 ls VªsM
lgk;d] Hkkjr&lhek O;kikj
dk vfrfjDr dk;ZHkkj½

02 o"kZ 07 ekg 01 fnu
ofj’B lgk;d
LVkEi@ifjogu
f'k{kk@fpfdRlk]
ftyk dk;kZy;]
fiFkkSjkx<+

30-08-2019 ls orZeku
rd

<!-- page 13 -->

-13-

31

32

Jh liu dqekj]
ofj’B lgk;d fofo/k]
ftyk dk;kZy;
fiFkkSjkx<+

Jh nsos'k ik.Ms;]
ofj’B lgk;d] mi Hkwfe
v/;kfIr dk;kZy;]
fiFkkSjkx<+

15-04-1984

03-07-1992

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

28-01-2013 ls
29-08-2018 rd

&

&

&

ofj’B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

30-08-2019 ls
31-03-2021 rd

;ksx

&

11Ok"kZ] 04ekg]
05fnu

&

&

01Ok"kZ]
02ekg]12fnu

dfu"B
lgk;d

rglhy
dukyhNhuk

13-08-2010 ls

&

&

&

dfu"B
lgk;d

rglhy
MhMhgkV

24-12-2010 ls
21-06-2016 rd

&

&

&

dfu"B
lgk;d

ftyk
dk;kZy;

22-06-2016 ls
29-08-2018 rd

&

&

&

ofj’B
lgk;d

ftyk
dk;kZy;

30-08-2018 ls
31-03-2021 rd

&

&

&

;ksx

&

12 Ok"kZ] 08 ekg] 26
fnu

&

&

&

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

29-07-2011 ls
29-08-2018 rd

dfu"B
lgk;d

nsoyFky

08-03-2011 ls

ofj’B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

30-08-2018 ls
31-03-2021 rd

;ksx

&

09 Ok"kZ] 07 ekg]
29 fnu

01 o"kZ 07 ekg 01 fnu

23-12-2010 rd

28-07-2011

04 ekg] 21 fnu

ofj’B lgk;d]
mi Hkwfe
v/;kfIr
dk;kZy;]
fiFkkSjkx<+

30-08-2018 ls orZeku
rd

02 o"kZ 07 ekg 01 fnu

<!-- page 14 -->

-14-

33

34

35

Jh fodze jkor]
dfu"B lgk;d] rglhy
dk;kZy; MhMhgkVA

Jh lqjs'k PkUnz HkV~V]
ofj’B lgk;d@is'kdkj]
miftykf/kdkjh
U;k;ky;] fiFkkSjkx<+

Jherh jatuk iar tks'kh

uk;c ukftj rglhy
nsoyFky

06-10-1988

01-01-1986

10-06-1992

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

fiFkkSjkx<+

csjhukx

dfu"B
lgk;d

MhMhgkV

dfu"B
lgk;d

ftyk
dk;kZy;

dfu"B
lgk;d

MhMhgkV

21-11-2011 ls

25-06-2016 ls
09-08-2016 rd

dfu"B
lgk;d

equL;kjh

07-02-2018 ls

dfu"B
lgk;d

csjhukx

10-08-2016 ls
02-01-2018 rd

dfu"B
lgk;d

/kkjpwyk

03-01-2018 ls
06-02-2018 rd

ofj’B
lgk;d

caxkikuh

30-08-2018 ls
01-09-2020 rd

29-08-2018 rd
02-09-2020 ls
31-03-2021 rd

24-06-2016 rd

;ksx

&

01 Ok"kZ] 03 ekg]
06 fnu

dfu"B
lgk;d

fiFkkSjkx<+

30-05-2017 ls
29-08-2018 rd

dfu"B
lgk;d

/kkjpwyk

29-11-2011 ls
29-05-2017 rd

ofj’B
lgk;d

fiFkkSjkx<+

29-08-2018 ls
31-03-2021 rd

&

&

&

;ksx

&

03 Ok"kZ] 10 ekg

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

08-10-2013 ls
02-06-2014 rd

dfu"B
lgk;d

csjhukx

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

03-06-2014 ls
25-08-2020 rd

ofj"B
lgk;d

nsoyFky

;ksx

06Ok"kZ] 09ekg]
47fnu

dfu"B
lgk;d]
rglhy
dk;kZy;
MhMhgkVA

08 o"kZ 09 ekg
55 fnu

06 ekg 29 fnu
is'kdkj]
miftykf/kdkjh
U;k;ky;]
fiFkkSjkx<+

05 Ok"kZ] 06 ekg]
01 fnu
19-07-2012 ls
07-10-2013 rd

02-09-2020 ls orZeku
rd

29-08-2018 ls 31-032021 rd

02 o"kZ 07 ekg 02 fnu

uk;c ukftj
rglhy
nsoyFky

26-08-2020 ls orZeku rd

26-08-2020 ls
31-03-2021 rd
01Ok"kZ] 09ekg]
21 fnu

07 ekg 05 fnu

<!-- page 15 -->

-1536

Jherh dfork vUuk
dfu"B lgk;d]rglhy

08-03-1989 fiFkkSjkx<+@ dukyhNhuk
rglhy dk;kZy;
dukyhNhuk

dukyhNhuk

37

Jh egs'k pUn

01-07-1982

dfu"B lgk;d mi
ftykf/kdkjh dk;kZy;
/kkjpwyk

38

Jh gfj 'akdj VEVk

12-07-1989

dfu"B lgk;d] jktLo]
ftyk dk;kZy;]
fiFkkSjkx<+

39

Jh izdk'k tks'kh
dfu"B
lgk;d@vgyen
miftykf/kdkjh
U;k;ky;] fiFkkSjkx<+A

dukyhNhuk

12-07-1984

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;

21-09-2013 ls
07-07-2014 rd

&

&

&

dfu"B
lgk;d

rglhy
dukyhNhuk

08-07-2014 ls
23-06-2019 rd

dfu"B
lgk;d

nsoyFky

24-06-2019 ls
12-02-2020 rd

dfu"B
lgk;d

rglhy
dukyhNhuk

13-02-2020 ls
31-03-2021 rd

;ksx

&

06 o"kZ 10 ekg
29 fnu

&

&

04 ekg 19 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

21-09-2013 ls
15-10-2013

dfu"B
lgk;d

/kkjpwyk

16-10-2013 ls
12-12-2013 rd

13-12-2013 ls
08-06-2018 rd

dfu"B
lgk;d

/kkjpwyk

;ksx

&

04Ok"kZ] 6ekg]
22 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

09-07-2014 ls
31-03-2021 rd

;ksx

&

6 o"kZ 8 ekg 22
fnu

dfu"B
lgk;d

fiFkkSjkx<+

16-06-2014 ls

;ksx

&

31-03-2021 rd

06Ok"kZ] 09ekg]
15fnu

lEc)

09-06-2018 ls
31-03-2021 rd

dfu"B lgk;d
rglhy
dukyhNhuk

01 o"kZ 01 ekg 18 fnu
dfu"B lgk;d
miftykf/kdkjh
dk;kZy;
/kkjpwyk

2 o"kZ 11 ekg 18
fnu

dfu"B
lgk;d

csjhukx

07-10-2013 ls

08-07-2014rd

9ekg]02fnu

dfu"B
lgk;d

csjhukx

16-11-2013 ls
15-06-2014 rd

06ekg]30fnu

13-02-2020 ls orZeku rd

fnukad 08-06-2018 ls
orZeku rd

2 o"kZ 09 ekg 23 fnu
dfu"B
lgk;d]
jktLo] ftyk
dk;kZy;]
fiFkkSjkx<+

29-08-2018 ls orZeku rd

02 o"kZ 07 ekg 02 fnu
dfu"B
fnukad 26-05-2014 ls orZeku
lgk;d@
rd
vgyen
miftykf/kdkjh
U;k;ky;]
fiFkkSjkx<+A

06 o"kZ 10 ekg 05 fnu

<!-- page 16 -->

-1640

41

42

43

44

Jh nhid Hk.Mkjh]
dfu"B lgk;d]
miftykf/kdkjh U;k;ky;
xaxksyhgkV

Jh enu eksgu tks'kh]
dfu"B lgk;d laxzg]
ftyk dk;kZy;
fiFkkSjkx<+

Jherh T;ksfr tks'kh]
dfu"B lgk;d] lSU;]
ftyk dk;kZy;]
fiFkkSjkx<+A

Jherh js[kk cksjk]
dfu"B lgk;d] rglhy
MhMhgkV

Jh uoy flag erksZfy;k]
dfu"B lgk;d] rglhy
equL;kjh

18-06-1980

23-07-1992

30-06-1979

10-06-1980

15-07-1991

fiFkkSjkx<+@
xaxksyhgkV@ rglhy
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ /kkjpwyk@
rglhy dk;kZy;
/kkjpwyk

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ MhMhgkV
rglhy dk;kZy;
MhMhgkV

fiFkkSjkx<+@equL;kjh@

fiFkkSjkx<+

fiFkkSjkx<+

fiFkkSjkx<+

csjhukx

equL;kjh

&

&

&

&

&

;ksx

&

dfu’B
lgk;d

ftyk
dk;kZy;

19-06-2019 ls
31-03-2021 rd

;ksx

&

01 o"kZ 09 ekg 12
fnu

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

06-09-2014 ls
31-03-2021 rd

;ksx

&

6 o"kZ 06 ekg 25
fnu

dfu"B
lgk;d

rglhy
dk;kZy;
MhMhgkV

25-11-2014 ls
31-03-2021 rd

;ksx

&

06 o"kZ 04 ekg 06
fnu

&

&

&

&

dfu"B
lgk;d

equL;kjh

dfu"B
lgk;d

xaxksyhgkV

18-11-2013 ls
26-11-2014 rd
27-11-2014 ls
31-03-2021 rd
07Ok"kZ]
04ekg]10fnu

rglhy dk;kZy;
equL;kjh

dfu"B
lgk;d

/kkjpwyk

18-11-2013 ls
18-06-2018 rd

&

&

&

&

&

-17-

fnukad 07-11-2017 ls
orZeku rd

03 o"kZ 04 ekg 24 fnu
dfu"B lgk;d
laxzg] ftyk
dk;kZy;
fiFkkSjkx<+

04Ok"kZ] 07ekg

fnukad 07-08-2020 ls
orZeku rd

07 ekg 24 fnu
dfu"B
lgk;d] lSU;]
ftyk
dk;kZy;]
fiFkkSjkx<+A

fnukad 04-08-2020 ls
orZeku rd

07 ekg 27 fnu

&

&

&

dfu"B
lgk;d]
rglhy
MhMhgkV

fnukad 25-11-2014 ls
orZeku rd
06 o"kZ 04 ekg 06 fnu

dfu"B
lgk;d

equL;kjh

25-11-2014 ls

31-03-2021
rd

;ksx

dfu"B
lgk;d]
miftykf/kdkjh
U;k;ky;
xaxksyhgkV

&

&

06 o"kZ 04 ekg 06
fnu

dfu"B
lgk;d]
rglhy
equL;kjh

fnukad 07-11-2017 ls
orZeku rd

03 o"kZ 04 ekg 24 fnu

<!-- page 17 -->

45

46

47

48

dq0 xhrk fc"V]
dfu"B lgk;d] izi=
iky] ftyk dk;kZy;]
fiFkkSjkx<+

Jh lanhi fc"V]
dfu"B lgk;d] U;k;]
ftyk dk;kZy;]
fiFkkSjkx<+

Jh lqpsr dqekj]
dfu"B lgk;d@
vgyen miftykf/kdkjh
MhMhgkV

Jh vfHkuUnu flag /kkeh]
dfu"B lg;d] rglhy
caxkikuh

10-07-1991

03-04-1993

30-11-1993

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ MhMhgkV@

vYeksM+k

fiFkkSjkx<+

fiFkkSjkx<+

rglhy dk;kZy;
MhMhgkV

28-03-1997

fiFkkSjkx<+@

/kkjpwyk

Jh eqds'k flag BxqUuk]
dfu"B lgk;d]
miftykf/kdkjh dk;kZy;
/kkjpwyk

ftyk
dk;kZy;

&

&

;ksx

&

06Ok"kZ] 02ekg]14fnu

&

&

dfu"B
lgk;d

ftyk
dk;kZy;

22-06-2015 ls
31-03-2021 rd

&

&

&

;ksx

&

05Ok"kZ] 09ekg]
09fnu

&

&

&

dfu"B
lgk;d

MhMhgkV

14-11-2017 ls
31-03-2021 rd

dfu"B
lgk;d

Fky

20-01-2016 ls

;ksx

&

03o’kZ] 04ekg]
17fnu

&

&

&

17-01-2015 ls

10-07-1998

fiFkkSjkx<+@/kkjpwyk@rg
lhy dk;kZy; /kkjpwyk

/kkjpwyk

&

31-03-2021 rd

caxkikuh@
rglhy dk;kZy;]
caxkikuh

49

dfu"B
lgk;d

13-11-2017 rd

caxkikuh

21-01-2016 ls
31-03-2021 rd

&

&

&

&

05Ok"kZ] 02ekg]10fnu

&

&

&

dfu"B
lgk;d

/kkjpwyk

29-07-2016 ls

&

&

&

&

dfu"B
lgk;d] U;k;]
ftyk
dk;kZy;]
fiFkkSjkx<+

31-03-2021 rd
04o’kZ]08ekg]

fnukad 04-08-2020 ls
orZeku rd

07 ekg 27 fnu
dfu"B
lgk;d@vgy
en
miftykf/kdkjh
MhMhgkV

01Ok"kZ] 09ekg]24fnu

dfu"B
lgk;d

fnukad 07-08-2020 ls
orZeu rd

07 ekg 24 fnu

;ksx

;ksx

dfu"B
lgk;d] izi=
iky] ftyk
dk;kZy;]
fiFkkSjkx

14-11-2017 ls
31-03-2021 rd

03o’kZ] 04ekg] 17fnu
dfu"B lg;d]
rglhy
caxkikuh

21-01-2016 ls
31-03-2021 rd
05Ok"kZ] 02ekg]10fnu

dfu"B
lgk;d]
miftykf/kdkjh
dk;kZy;
/kkjpwyk

fnukad 07-11-2017 ls
orZeku rd

03 o"kZ 04 ekg 24 fnu

<!-- page 18 -->

-1850

51

52

53

54

Jh ;ksxs'k dkdhZ] dfu"B
lgk;d@vgyen]
miftykf/kdkjh csjhukx

Jh izeksn flag cqQkZy]
dfu"B lgk;d] rglhy
csjhukx

dq0 dYiuk tks'kh]
dfu"B lgk;d] lkekU;]
ftyk dk;kZy;
fiFkkSjkx<+

Jherh yrk nsoh]
dfu’B lgk;d] rglhy
dk;kZy;] xaxksyhgkV

Jh fojsUnz flag
Mlhyk] dfu’B
lgk;d] rglhy
x.kkbZ&xaxksyh

09-11-1991

fiFkkSjkx<+@

csjhukx

csjhukx@ rglhy
dk;kZy; csjhukx

01-06-1994

07-04-1999

18-08-2018

07-12-2018

fiFkkSjkx<+@
csjhukx@rglhy
dk;kZy; csjhukx

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

dfu’B lgk;d] rglhy
xaxksyhgkV

dfu’B lgk;d] rglhy
x.kkbZ&xaxksyh

equL;kjh

fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;

08-09-2017 ls
08-11-2017 rd

dfu"B
lgk;d

csjhukx

09-11-2017 ls
31-03-2021 rd

;ksx

&

02ekg] 1 fnu

&

&

03o’kZ] 04ekg]22fnu

&

&

&

dfu"B
lgk;d

csjhukx

05-02-2018 ls
31-03-2021 rd

;ksx

&

&

&

&

03o’kZ] 01ekg]
26fnu

&

ftyk
dk;kZy;

06-02-2018 ls
31-05-2019 rd

&

&

&

;ksx

&

03 o"kZ 01 ekg 19
fnu

&

&

&

&

&

dfu"B
lgk;d

xaxksyhgkV

18-08-2018 ls
31-03-2021 rd

;ksx

&

&

&

&

02 o"kZ 07 ekg
13 fnu

dfu"B
lgk;d

x.kkbZ&

07-12-2018 ls
31-03-2021 rd

&

&

x.kkbZ&
xaxksyh

;ksx

&

&

xaxksyh

dfu"B
lgk;d@
vgyen]
miftykf/kdkjh
csjhukx

09-11-2017 ls
31-03-2021 rd

03o’kZ] 04ekg]22fnu
dfu"B
lgk;d]
rglhy
csjhukx

05-02-2018 ls 31-032021 rd
03o’kZ] 01ekg] 26fnu

dfu"B
lgk;d]
lkekU;] ftyk
dk;kZy;
fiFkkSjkx<+

fnukad 07-08-2020 ls
orZeu rd

07 ekg 24 fnu

02 o"kZ 03 ekg
24 fnu

dfu’B
lgk;d]
rglhy
xaxksyhgkV

18-08-2018 ls 31-032021 rd
02 o"kZ 07 ekg 13 fnu

dfu’B
lgk;d]
rglhy
x.kkbZ&xaxksyh

07-12-2018 ls orZeku
rd
02 o"kZ 03 ekg 24 fnu

<!-- page 19 -->

-1955

56

57

58

59

Jherh jsuw iUr]
dfu"B lgk;d]
rglhy dk;kZy;]
fiFkkSjkx<

dfu"B lgk;d] rglhy
fiFkkSjkx<+

Jh y{e.k fxjh]
dfu"B lgk;d]
i= izs"kd] ftyk
dk;kZy; fiFkkSjkx<+

dfu"B lgk;d] ftyk
dk;kZy; fiFkkSjkx<+

Jh vkuUn
fd'kksjdfu"B
lgk;d] rglhy
equL;kjh

fiFkkSjkx<+

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

;ksx

dfu"B lgk;d]

xaxksyhgkV

equL;kjh

dfu"B
lgk;d

&

ftyk
dk;kZy;
fiFkkSjkx<+

&

03-06-2019ls
31-03-2021 rd

&

&

&

01 o"kZ 09ekg 28
fnu

&

&

&

14-07-2019 ls
31-03-2021 rd

&

&

&

01 o"kZ 08 ekg
17 fnu

&

&

&

&

dfu"B
lgk;d

rglhy equL;kjh

Jherh 'kkfUr tks'kh
dfu"B lgk;d
vkaXy vfHkys[kkxkj
ftyk dk;kZy;
fiFkkSjkx<+

dfu"B lgk;d] ftyk
dk;kZy; fiFkkSjkx<+

Jh lkxj fc"V
dfu"B lgk;d
ftyk dk;kZy;
fiFkkSjkx<+

dfu"B lgk;d]
ftyk dk;kZy;]
fiFkkSjkx<+

fiFkkSjkx<+

vYeksM+k

dfu"B lgk;d]
rglhy dk;kZy;]
fiFkkSjkx<+

03-06-2019ls orZeku
rd
01 o"kZ 09ekg 28 fnu

dfu"B
lgk;d] i=
izs"kd] ftyk
dk;kZy;
fiFkkSjkx<+

14-07-2019 ls orZeku
rd

01 o"kZ 08 ekg 17 fnu

rglhy 13-08-2019 ls dfu"B lgk;d]
equL;kjh 31-03-2021 rd rglhy dk;kZy;]
equL;kjh

13-08-2019 ls
orZeku rd

&

&

&

;ksx

&

01 o"kZ 07ekg 18
fnu

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

13-08-2019 ls
31-03-2021 rd

&

&

&

;ksx

01 o"kZ 07ekg 18
fnu

&

&

&

dfu"B
lgk;d

rglhy
30-12-2019 ls
dukyhNhuk 13-09-2020 rd

&

&

&

dfu"B lgk;d
ftyk dk;kZy;
fiFkkSjkx<+

14-09-2020 ls orZeku

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

14-09-2020 ls
31-03-2021 rd

&

&

&

&

&

1 o"kZ 03 ekg 1
fnu

&

&

&

;ksx

01 o"kZ 07ekg 18 fnu
dfu"B
lgk;d] ftyk
dk;kZy;
fiFkkSjkx<+

13-08-2019 ls orZeku
rd
01 o"kZ 07ekg 18 fnu

06 ekg 17 fnu

<!-- page 20 -->

-2060

dq0 uwru vf/kdkjh
dfu"B lgk;d
jktLo
vfHkys[kkxkj ftyk
dk;kZy; fiFkkSjkx<+

dfu"B lgk;d]
ftyk dk;kZy;
fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

;ksx

dfu"B lgk;d ¼lkekU;½
ftyk dk;kZy;] fiFkkSjkx<+A

ftyk
dk;kZy;
fiFkkSjkx<+

23-01-2020 ls
25-03-2021 rd

&

&

&

01 o"kZ 02 ekg
08 fnu

&

&

&

dfu"B lgk;d
jktLo
vfHkys[kkxkj]
ftyk dk;kZy;
fiFkkSjkx<+

23-01-2020 ls ls
orZeku rd

01 o"kZ 02 ekg 08 fnu

ofj"B lgk;d ¼lkekU;½
izHkkjh vf/kdkjh ¼lkekU;½
ftyk dk;kZy;] fiFkkSjkx<+Ad`rs ftykf/kdkjh] fiFkkSjkx<+A

<!-- page 21 -->

fu;fer vf/k"Bku ftyk dk;kZy; fiFkkSjkx<+ vUrxZr orZeku esa dk;Zjr dkfeZd ls lacaf/kr fooj.k fnukad 31-03-2022 rd
dz0 dkfeZdk dk uke ,Oka
la0
orZeku in uke

tUe frfFk

tuin@rglhy
dk;kZy; dk uke

x`g rglhy

lqxe rglhy esa rSukrh dk fooj.k

nqxZe rglhy esa rSukrh dk fooj.k

rSukrh dk
in

dk;kZy; dk
uke

vof/k ¼dCk ls
dc rd½

rSukrh dk
in

dk;kZy;
dk uke

vof/k ¼dc ls
dc rd½

iVy dk uke

vof/k ¼dc ls dc rd½

10

11

12

13

1

2

3

4

5

6

7

8

9

1

Jh iznhi iqusM+k
iz/kku lgk;d ]'kL=]
ftyk dk;kZy;]
fiFkkSjkx<+

14-07-1970

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;

11-05-1994 ls

ofj"B
lgk;d

ofj"B
lgk;d

ftyk
dk;kZy;

iz/kku
lgk;d

ftyk
dk;kZy;

Jherh xhrk fljkSyk
ofj"B lgk;d] U;kf;d
vfHkys[kkxkj] ftyk
dk;kZy;]fiFkkSjkx<+

28-06-1969

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

19-05-1998 rd
20-05-1998 ls

06-07-2010 ls

/kkjpwyk

23-07-2012 rd

&

&

&

&

equL;kjh

25-06-2019ls
31-03-2022

05-07-2010 rd
24-07-2012 ls
24-06-2019 rd
23 o’kZ 24 fnu

;ksx
2

iVy esa dk;Zjr jgus dh vof/k

rglhy
fiFkkSjkx<+

25-06-2000 ls
12-11-2003 rd

dfu"B
lgk;d

xaxksyhgkV

jktLo
ys[kkdkj
rglhy
equL;kjh

25-06-2019 ls 31-03-2022

04 o’kZ 09 ekg
23 fnu

&

02 o"kZ 09 ekg 06 fnu

05-11-1999 ls

ofj"B lgk;d]
U;kf;d
vfHkys[kkxkj]
ftyk dk;kZy;
fiFkkSjkx<+

20-07-2011ls 31-03-2022

&

10 o"kZ 09 ekg11 fnu

24-06-2000 rd

ofj"B
lgk;d

ftyk
dk;kZy;

13-11-2003 ls
31-03-2022 rd

&

&

&

;ksx

&

21 o"kZ 09 ekg 04
fnu

&

&

07ekg]20fnu

<!-- page 22 -->

-23

Jh ds'ko nRr cp[ksrh
iz/kku lgk;d rglhy
x.kkbZ xaxksyh

25-06-1970

fiFkkSjkx<+@x.kkbZa
xaxksyh

ckxs'oj

dfu"B
lgk;d

ftyk
dk;ky;

10-04-2000 ls
24-06-2000 rd

dfu"B
lgk;d

csjhukx

25-06-2000 ls
28-02-2004 rd

ofj"B
lgk;d

ftyk
dk;kZy;

15-07-2006 ls
27-09-2007 rd

ofj"B
lgk;d

csjhukx

01-03-2004 ls
14-07-2006 rd

ofj’B
lgk;d

ftyk
dk;kZy;

20-06-2018 ls
28-08-2018 rd

ofj"B
lgk;d

osjhukx

&

&

&

ofj"B
lgk;d

xaxksyhgkV

iz/kku
lgk;d

rglhy
x.kkbZ&

&

&

&

28-09-2007 ls
27-07-2011 rd

jktLo
ys[kkdkj
rglhy x.kkbZ
xaxksyh

29-08-2018 ls 31-03-2022

28-07-2011 ls
19-06-2018 rd
29-08-2018 ls
31-03-2022 rd

xaxksyh

4

Jh egs'k pUnz tks'kh
iz/kku lgk;d rglhy
/kkjpwykA

18-02-1970

fiFkkSjkx<+@ equL;kjh@
rglhy dk;kZy;
equL;kjh

rste

;ksx

&

01 Ok"kZ] 07ekg]
08fnu

&

&

20 o"kZ 04 ekg
08 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

01-09-2000 ls

ofj"B
lgk;d

csjhukx

01-03-2004 ls

;ksx

28-02-2004 rd

&

03 Ok"kZ]
05ekg]28fnu

03 o"kZ 07 ekg 02 fnu

31-07-2009 rd

ofj"B
lgk;d

equL;kjh

01-08-2009 ls
28-08-2018 rd

iz/kku
lgk;d

rglhy
/kkjpwyk

29-08-2018 ls
31-03-2022 rd

&

&

18 o"kZ] 01 ekg]
27 fnu

jktLo
ys[kkdkj]
rglhy
dk;kZy;
/kkjpwyk

29-08-2018 ls 31-03-2022
rd

03 o"kZ 07 ekg 02 fnu

<!-- page 23 -->

-35

6

7

Jherh deyk iUr
iz/kku lgk;d rglhy
csjhukx

Jherh deyk ukFk
iz/kku lgk;d rglhy
nsoyFky

Jh fnus'k eksgu ik.Ms;
iz/kku lgk;d@is”kdkj
ftykf/kdkjh dk;kZy;
fiFkkSjkx<+

01-07-1964

14-12-1971

14-07-1972

fiFkkSjkx<+@ csjhukx@
rglhy dk;kZy;
csjhukx

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@nsoYkFky+@
rglhy dk;kZy;
nsoYkFky

MhMhgkV

fiFkkSjkx<+

nsoYkFky

dfu"B
lgk;d

fiFkkSjkx<+

02-10-2004 ls
29-07-2005 rd

dfu"B
lgk;d

xaxksyhgkV

ofj"B
lgk;d

16-08-2001 ls
01-10-2004 rd

MhMhgkV

30-07-2005 ls
07-07-2008 rd

ofj’B
lgk;d

csjhukx

10-08-2009 ls
29-08-2018 rd

ofj"B
lgk;d

fiFkkSjkx<+

08-07-2008 ls
09-08-2009 rd

iz/kku
lgk;d

csjhukx

29-08-2018 ls 3103-2022

;ksx

&

04 Ok"kZ] 10ekg] 08
fnu

&

&

15 o’kZ 09 ekg
07 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

15-07-2002 ls
30-07-2005 rd

ofj"B
lgk;d

equL;kjh

31-07-2005 ls
13-07-2006 rd

iz/kku
lgk;d

ftyk
dk;kZy;

14-07-2006 ls
28-09-2018 rd

iz/kku
lgk;d

nsoyFky

29-09-2018 ls
31-03-2022 rd

;ksx

&

15 Ok"kZ] 03 ekg]
01fnu

&

&

04 o"kZ] 08 ekg]
12 fnu

ofj"B
lgk;d

MhMhgkV

01-10-2007 ls
13-01-2015 rd

dfu"B
lgk;d

/kkjpwyk

06-02-2003 ls
30-09-2007 rd

iz/kku
lgk;d

ftyk
dk;kZy;

30-08-2018 ls
31-03-2022 rd

ofj"B
lgk;d

nsoyFky

14-01-2015 ls
29-08-2018 rd

;ksx

&

10 o"kZ] 10 ekg
11 fnu

&

&

08 Ok"kZ] 03 ekg]
11fnu

jktLo
ys[kkdkj]
rglhy
dk;kZy;
csjhukx

29-08-2018 ls 31-03-2022

03 o’kZ 07 ekg 02 fnu

iz/kku lgk;d
rglhy
nsoyFky

29-09-2018 ls 31-03-2022

03 o’kZ 06 ekg 02 fnu
is'kdkj]
U;k;ky;
ftykf/kdkjh
fiFkkSjkx<+

29-08-2018 ls 31-03-2022
rd

03 o"kZ 07 ekg 02 fnu

<!-- page 24 -->

-48

9

Jh dey fd'kksj ik.Ms;
iz/kku lgk;d] uktjkr
ftyk dk;kZy;]
fiFkkSjkx<+

Jh uhjt dqekj iUr
iz/kku lgk;d vkcdkjh
ftyk dk;kZy;]
fiFkkSjkx<+

01-01-1985

02-07-1981

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

xaxksyhgkV

dfu"B
lgk;d

ftyk
dk;kZy;

19-02-2003 ls
27-09-2007 rd

ofj"B
lgk;d

xaxksyhgkV

ofj’B
lgk;d

ftyk
dk;kZy;

02-08-2012 ls
29-08-2018 rd

ofj"B
lgk;d

nsoyFky

iz/kku
lgk;d

ftyk
dk;kZy;

30-08-2018 ls
31-03-2022 rd

ofj"B
lgk;d

/kkjpwyk

16-10-2013 ls

lEc)

12-12-2013 rd

;ksx

&

14 Ok"kZ] 03ekg
04fnu

&

&

05o"kZ] ekg]
03fnu

dfu"B
lgk;d

ftyk
dk;kZy;

09-04-2003 ls
08-02-2009 rd

&

&

&

ofj’B
lgk;d

ftyk
dk;kZy;

09-02-2009 ls
29-08-2018 rd

&

&

&

iz/kku
lgk;d

ftyk
dk;kZy;

29-08-2018 ls
31-03-2022 rd

;ksx

&

18 Ok"kZ] 11
ekg]

&

&

&

21 fnu

28-09-2007 ls
22-07-2011rd
23-07-2011 ls
01-08-2012 rd

iz/kku lgk;d]
uktjkr ftyk
dk;kZy;]
fiFkkSjkx<+

29-08-2018 ls 31-03-2022

03 o"kZ 07 ekg 02 fnu
iz/kku lgk;d
vkcdkjh ftyk
dk;kZy;]
fiFkkSjkx<+

29-08-2018 ls 31-03-2022

03 o"kZ 07 ekg 02 fnu

<!-- page 25 -->

-510

11

Jherh euh"kk pUn
ofj"B lgk;d] ou]
ftyk dk;kZy;]fiFkkSjkx<+

Jh iadt dqekj
ofj"B lgk;d@uk;c
ukftj] rglhy equL;kjh

01-07-1973

30-06-1979

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@equL;kjh@
rglhy dk;kZy;
equL;kjh

fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;

23-07-2009 ls
21-05-2010 rd

dfu"B
lgk;d

xaxksyhgkV

08-06-2004 ls
22-07-2009 rd

ofj"B
lgk;d

ftyk
dk;kZy;

22-05-2010 ls
30-04-2021 rd

&

&

&

iz/kku
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

01-05-2021 ls
09-09-2021 rd

&

&

&

iz/kku
lgk;d

rglhy
dukyhNhuk

10-09-2021 ls
31-03-2022 rd

;ksx

&

12 Ok"kZ] 08ekg]
08 fnu

&

&

05Ok"kZ]
01ekg]15fnu

ofj"B
lgk;d

fiFkkSjkx<

02-08-2011 ls

dfu"B
lgk;d

nsoyFky

11-06-2004 ls

ofj"B
lgk;d

ftyk
dk;kZy;

ofj"B
lgk;d

equL;kjh

ofj"B
lgk;d

tux.kuk

ofj"B
lgk;d

csjhukx

ofj"B
lgk;d

equL;kjh

29-12-2017 ls
08-02-2018

ofj"B
lgk;d

rste

09-02-2018 ls
25-03-2019 rd

26-12-2011 rd
27-12-2011 ls
24-01-2013 rd
25-01-2013 ls
26-03-2014 rd

26-09-2006 rd

10-09-2021ls 31-03-2022

06 ekg 21 fnu
ofj"B
lgk;d@uk;c
ukftj] rglhy
equL;kjh

fnukad 26-03-2019 ls 31-032022 rd

27-09-2006 ls
01-08-2011 rd
11-07-2014 ls
28-12-2017 rd

ofj"B
lgk;d

ftyk
dk;kZy;

27-03-2014 ls
10-07-2014

ofj"B
lgk;d

equL;kjh

26-03-2019 ls
31-03-2022 rd

;ksx

&

02Ok"kZ] 11ekg]

&

&

15 Ok"kZ] 08ekg]

09fnu

iz/kku lgk;d]
rglhy
dk;kZy;
dukyhNhuk

28fnu

03 o"kZ 05 fnu

<!-- page 26 -->

-612

Jh Hkjr yky
dfu"B lgk;d@ mi
rglhy ika[kwA

12-06-1985

fiFkkSjkx<+@
csjhukx@rglhy
dk;kZy; csjhukx

csjhukx

ofj"B
lgk;d

MhMhgkV

24-06-2019 ls
29-06-2020 rd

dfu"B
lgk;d

xaxksyhgkV

14-10-2004 ls
11-09-2006

&

&

&

ofj"B
lgk;d

csjhukx

12-09-2006 ls
20-07-2011 rd

&

&

&

ofj"B
lgk;d

xaxksyhgkV

21-07-2011 ls
15-03-2015 rd

&

&

&

ofj"B
lgk;d

x.kkbZ&
xaxksyh

16-03-2015 ls
21-07-2016rd

&

&

&

ofj"B
lgk;d

xaxksyhgkV

22-07-2016 ls
18-09-2016 rd

&

&

&

ofj"B
lgk;d

x.kkbZ&
xaxksyh

19-09-2016 ls
12-11-2017 rd

&

&

&

ofj"B
lgk;d

dfu"B
lgk;d
mi rglhy
ika[kw

30-06-2020 ls 31-03-2022

13-11-2017 ls
23-06-2019rd
xaxksyhgkV

&
;ksx

&

&

dfu"B
lgk;d

1 o"kZ 05 fnu

&

ika[kw

&

30-06-2020 ls
31-03-2022 rd

16 o"kZ 02 ekg
21 fnu

01 o’kZ 09 ekg 01 fnu

<!-- page 27 -->

-713

14

Jh egs'k pUnz ikBd]
ofj"B lgk;d@uk;c
ukftj] rglhy
dukyhNhukA

Jh jktsUnz flag iky
ofj"B lgk;d rglhy
MhMhgkV

04-04-1966

12-03-1973

fiFkkSjkx<+@dukyhNhuk

fiFkkSjkx<+@/kkjpwyk@
rglhy dk;kZy;
/kkjpwyk

Fky

/kkjpwyk

dfu"B
lgk;d

ftyk
dk;kZy;

15-02-2005 ls
03-01-2007 rd

dfu"B
lgk;d

csjhukx

11-07-2008 ls
18-07-2008

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

04-01-2007 ls
10-07-2008 rd

dfu"B
lgk;d

csjhukx

01-01-2010 ls
31-12-2011 rd

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

19-07-2008 ls
31-12-2009 rd

dfu"B
lgk;d

equL;kjh

01-01-2012 ls
15-12-2016 rd

dfu’B
lgk;d

ftyk
dk;kZy;

08-06-2018 ls
03-08-2020 rd

dfu"B
lgk;d

Fky

16-12-2016 ls
19-01-2018 rd

ofj"B
lgk;d

dukyhNhuk

04-08-2020 ls
31-03-2022 rd

dfu"B
lgk;d

equL;kjh

20-01-2018 ls
08-06-2018 rd

;ksx

&

08 Ok"kZ] 07 ekg]
29 fnu

&

&

08 Ok"kZ] 05 ekg]
16 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

28-02-2005 ls

dfu"B
lgk;d

/kkjpwyk

06-07-2010 ls

dfu"B
lgk;d

ftyk
dk;kZy;

ofj"B
lgk;d

/kkjpwyk

ofj"B
lgk;d

ftyk
dk;kZy;

ofj"B
lgk;d

nsoyFky

ofj"B
lgk;d

dukyhNhuk

05-07-2014 ls
28-06-2016

ofj"B
lgk;d

/kkjpwyk

14-11-2017 ls 2908-2018 rd

ofj"B
lgk;d

MhMhgkV

26-08-2020 ls
09-09-2021 rd

ofj"B
lgk;d

nsoyFky

30-08-2018 ls
25-08-2020

iz/kku

rglhy

10-09-2021 ls 31-

&

&

&

05-07-2010 rd
28-09-2010 ls
30-05-2014 rd
31-05-2014 ls
04-07-2014 rd

27-09-2010rd
29-06-2016 ls
22-07-2016 rd

23-07-2016 ls
13-11-2017

uk;c ukftj]
rglhy
dukyhNhukA

04-08-2020 ls 31-032022

01 o’kZ 07 ekg 27 fnu
jktLo
ys[kkdkj]
rglhy
dk;kZy;
fiFkkSjkx<+A

10-09-2021 ls 31-03-2022

<!-- page 28 -->

15

Jh ikjl dU;ky
ofj"B lgk;d@uk;c
ukftj] rglhy csjhukx

18-08-1986

fiFkkSjkx<+@ MhMhgkV@
rglhy dk;kZy;
MhMhgkV

MhMhgkV

lgk;d

fiFkkSjkx<+

03-2022

;ksx

&

12 o"kZ 07 ekg
11 fnu

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

04-03-2006 ls
03-11-2006 rd

ofj"B
lgk;d

nsoyFky

dfu"B
lgk;d

MhMhgkV

04-11-2006 ls
27-05-2014

ofj"B
lgk;d

csjhukx

06-07-2019 ls
30-08-2020 rd

ofj"B
lgk;d

MhMhgkV

13-01-2015 ls
05-07-2019 rd

ofj"B
lgk;d

equL;kjh

31-08-2020 ls
21-03-2021 rd

&

&

&

ofj"B
lgk;d

csjhukx

22-03-2021 ls
31-03-2022 rd

;ksx

&

12 o"kZ 06 ekg
75 fnu

;ksx

&

03 o"kZ 04 ekg
05 fnu

06 ekg 21 fnu

02 o"kZ 25 ekg
106 fnu
28-05-2014 ls
12-01-2015 rd

ofj"B
lgk;d@
uk;c ukftj]
rglhy
csjhukx

06-07-2019 ls
31-03-2022 rd
¼foHkkxh; dk;Zokgh izpfyr
gksus ls mDr dkfeZd fnukad
31-08-2020 ls
21-03-2021 rd vof/k 06
ekg 18 fnu rd fuyacu
mijkUr rglhy dk;kZy;
equL;kjh lEc) jgasA ½

02 o"kZ 07 ekg 25 fnu

<!-- page 29 -->

16

Jh /kekZuUn ikBd
ofj"B lgk;d] vkaXy
vfHkys[kkxkj] ftyk
dk;kZy; fiFkkSjkx<+

10-06-1966

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

vYeksM+k

dfu"B
lgk;d

dfu"B
lgk;d

ftyk
dk;kZy;

miftykf/kdkjh 24-07-2011 ls
dk;kZy;
02-06-2014 rd
fiFkkSjkx<+

Jh [khekuUn HkV~V
ofj"B lgk;d@
is'kdkj] miftykf/kdkjh
U;k;ky; /kkjpwyk

20-04-1988

fiFkkSjkx<+@/kkjpwyk@
rglhy dk;kZy;
/kkjpwyk

/kkjpwyk

Jh xks/ku flag thuk
ofj"B lgk;d@is'kdkj
miftykf/kdkjh U;k;ky;
MhMhgkV

15-06-1968

fiFkkSjkx<+@MhMhgkV@
rglhy dk;kZy;
MhMhgkV

uSuhrky

nsoyFky

&

&

&

25-05-2016 rd

ftyk
dk;kZy;

26-05-2016 ls
09-09-2021 rd

&

&

&

&

&

&

iz/kku
lgk;d

xaxksyhgkV

10-09-2021 ls
31-03-2022

13 o’kZ 03 ekg
04 fnu

&

&

02 o’kZ 06 ekg
13 fnu

&

dfu"B
lgk;d

xaxksyhgkV

26-09-2006 ls
04-08-2012 rd

&

dfu"B
lgk;d

/kkjpwyk

&

&

&

&

&

&

&

ofj"B
lgk;d

/kkjpwyk

29-05-2014 ls
09-09-2021 rd

iz/kku
lgk;d

rglhy
MhMhgkV

10-09-2021 ls
07-11-2021 rd

iz/kku
lgk;d

lEc)
rglhy
/kkjpwyk

08-11-2021 ls

01 ekg 28
fnu

&

&

15 o’kZ 03 ekg
06 fnu

13-06-2007 ls
17-11-2011 rd

&

&

&

;ksx
18

03-06-2014 ls

ofj"B
lgk;d

ofj"B
lgk;d

;ksx
17

12-06-2006 ls
23-07-2011 rd

dfu"B
lgk;d

ftyk
dk;kZy;

05-08-2012 ls
28-05-2014 rd

jktLo
ys[kkdkj]
rglhy
dk;kZy;
xaxksyhgkV

10-09-2021 ls
31-03-2022

06 ekg 21 fnu

iz/kku
lgk;d]
rglhy
dk;kZy;
MhMhgkV

10-0+9-2021 ls 31-03-2022
rd
¼fnukad 08-11-2021 ls
lEc) miftykf/kdkjh
dk;kZy; /kkjpwyk½

31-03-2022 rd

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

18-11-2011 ls
10-03-2016

&

&

&

ofj"B
lgk;d

rglhy
MhMhgkV

11-03-2016 ls
09-09-2021 rd

&

&

&

06 ekg 21 fnu

iz/kku
lgk;d]
jktLo] ftyk
dk;kZy;
fiFkkSjkx<+A

10-09-2021 ls 31-032022

<!-- page 30 -->

19

20

Jh egs'k flag Hk.Mkjh
ofj"B lgk;d@is'kdkj]
U;k;ky;
miftykf/kdkjh] equL;kjh

Jh pUnz izdk'k ik.Ms;
ofj"B lgk;d@Hkwys[k

18-10-1989

10-06-1988

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

fiFkkSjkx<+

+

21

Jherh iq"ik clsM+k
ofj"B lgk;d@ uk;c
ukftj@jktLo ys[kkdkj]
rglhy Fky

22-10-1990

fiFkkSjkx<+@ Fky+@
rglhy dk;kZy; Fky

nsoyFky

iz/kku
lgk;d

ftyk
dk;kZy;

10-09-2021 ls
31-03-2022 rd

&

&

&

;ksx

&

14 Ok"kZ] 09
ekg]15 fnu

&

&

&

&

06 ekg 21 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

19-11-2008 ls ofj"B
22-06-2016 rd lgk;d

equL;kjh

26-07-2019 ls
09-09-2021 rd

iz/kku lgk;d]
ftyk dk;kZy;
fiFkkSjkx<+

fnukad 10-09-2021 ls 31-032022 rd

ofj"B
lgk;d

ftyk
dk;kZy;

23-06-2016 ls &
25-07-2019 rd

&

&

iz/kku
lgk;d

ftyk
dk;kZy;

10-09-2021 ls
31-03-2022

&

&

;ksx

&

11 Ok"kZ] 02 ekg]
26 fnu

&

02 o"kZ 01 ekg
14 fnu

dfu"B
lgk;d

ftyk
dk;kZy;

27-06-2012 ls
22-06-2016 rd

dfu"B
lgk;d

xaxksyhgkV

ofj"B
lgk;d

ftyk
dk;kZy;

23-06-2016 ls
09-09-2021 rd

dfu"B
lgk;d

nsoyFky

iz/kku
lgk;d

ftyk
dk;kZy;

10-09-2021 ls
31-03-2022

;ksx

&

09 Ok"kZ] 09 ekg]
04 fnu

&

&

03 Ok"kZ] 04
ekg]17fnu

06 ekg 21 fnu

dfu"B
lgk;d

dukyhNhUkk

26-02-2009 ls

dfu"B
lgk;d

csjhukx

08-07-2014 ls

03-12-2021 ls 31-03-2022

&

&

ofj"B
lgk;d

xa.kkbZ&

23-06-2016 ls

xaxksyh

13-09-2016 rd

07-07-2014 rd
&

10-02-2009 ls

06 ekg 21 fnu

12-07-2010 rd

iz/kku lgk;d]
ftyk dk;kZy;
fiFkkSjkx<+A

10-09-2021 ls 31-03-2022

13-07-2010 ls
26-06-2012 rd

22-06-2016 rd

<!-- page 31 -->

&

&

&

ofj"B
lgk;d

csjhukx

ofj"B
lgk;d

Fky

14-09-2016 ls
21-11-2017

&

&

iz/kku
lgk;d

ftyk
dk;kZy;
lEc)
rglhy
MhMhgkV

03-12-2021 ls
31-03-2022 rd

;ksx

&

05 Ok"kZ] 08 ekg]
13 fnu

&

&

06 o"kZ] 08 ekg]
21fnu

dfu"B
lgk;d

nsoyFky

23-06-2009 ls

&

22-11-2017 ls

02-12-2021rd

05 ekg 28 fnu

-1022

23

Jherh xksik tks'kh
ofj"B lgk;d] rglhy
rste lEc) laxzg]
ftyk dk;kZy;]
fiFkkSjkx<+

Jh lUrks"k flag] ofj"B
lgk;d@uk;c ukftj]
rglhy dk;kZy;]
xaxksyhgkV

10-04-1982

20-03-1988

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@rglhy
dk;kZy; xaxksyhgkV

fiFkkSjkx<+

csjhukx

dfu’B
lgk;d

ftyk
dk;kZy;

13-07-2010 ls
03-01-2017 rd

ofj’B
lgk;d

ftyk
dk;kZy;

04-01-2017 ls
02-12-2021 rd

iz/kku
lgk;d

ftyk
dk;kZy;

03-12-2021 ls
31-03-2022

;ksx

&

11 Ok"kZ] 08 ekg] 18
fnu

&

&

01 Ok"kZ] 21 fnu

&

&

&

dfu"B
lgk;d

xaxksyhgkV

22-07-2009 ls
28-07-2011 rd

&

&

&

dfu"B
lgk;d

csjhukx

29-07-2011 ls

ofj"B
lgk;d

ika[kw

ofj"B
lgk;d

xaxksyhgkV

&

&

&

&

&

&

12-07-2010 rd

04-05-2017 rd
05-05-17 ls

25-07-2019 rd

26-07-2019 ls
31-03-2022 rd

iz/kku lgk;d]
ftyk
dk;kZy;]
fiFkkSjkx<+

03-12-2021 ls 31-03-2022

05 ekg 28 fnu

uk;c ukftj]
rglhy
dk;kZy;]
xaxksyhgkV

26-07-2019 ls 31-03-2022

<!-- page 32 -->

24

Jh vkse izdk'k ofj"B
lgk;d@is'kdkj]
U;k;ky;
miftykf/kdkjh]
xaxksyhgkV

08-03-1981

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

}kjkgkV

;ksx

&

&

&

&

12 Ok"kZ] 09 ekg]
04 fnu

ofj"B
lgk;d

ftyk
dk;kZy;

04-08-2011 ls
29-08-2018 rd

dfu"B
lgk;d

xaxksyhgkV

25-07-2009 ls

&

&

&

ofj"B
lgk;d

equL;kjh

01-09-2010 ls
03-08-2011 rd

ofj"B
lgk;d

xaxksyhgkV

30-08-2018 ls
31-03-2022rd

&

&

05 Ok"kZ] 07 ekg]
06fnu

;ksx

&

07 Ok"kZ] 26fnu

31-08-2010 rd

02o"kZ 08 ekg 05 fnu
is'kdkj]
U;k;ky;
miftykf/kdkjh
] xaxksyhgkV

30-08-2018 ls 31-032022rd

03 o"kZ 07 ekg 01 fnu

<!-- page 33 -->

-1125

26

Jh izse pUnz tks'kh
ofj"B lgk;d
[kuu@is”kdkj vij
ftykf/kdkjh dk;kZy;
fiFkkSjkx<

Jh nhid flag iqtkjh]
ofj"B lgk;d@uk;c
ukftj] rglhy
dk;kZy;] fiFkkSjkx<+A

02-08-1984

01-04-1991

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@rglhy
dk;kZy; fiFkkSjkx<+

caxkikuh

MhMhgkV

dfu’B
lgk;d
lgk;d

ftyk
dk;kZy;

25-07-2009 ls
28-08-2018 rd

&

&

&

ofj’B
lgk;d

ftyk
dk;kZy;

29-08-2018 ls
31-03-2022 rd

;ksx

&

12 o"kZ] 08ekg 06
fnu

&

&

^&

dfu"B
lgk;d

MhMhgkV

04-06-2014 ls
07-04-2017 rd

dfu"B
lgk;d

equL;kjh

06-08-2009 ls

ofj’B
lgk;d

fiFkkSjkx<

26-07-2019 ls
31-03-2022 rd

dfu"B

xaxksyhgkV

&

&

&

27-07-2011 rd

rste

08-04-2017 ls
29-08-2018 rd

ofj’B
lgk;d

equL;kjh

30-08-2019 ls
25-07-2019 rd

ofj"B

Jh izdk'k flag ckfQyk
ofj"B lgk;d@is'kdkj]
U;k;ky;
miftykf/kdkjh] csjhukx

13-07-1990

fiFkkSjkx<+@csjhukx

csjhukx

;ksx

&

05 Ok"kZ] 06 ekg]
06 fnu

&

&

07 Ok"kZ] 01 ekg]
13 fnu

&

&

&

dfu"B
lgk;d

/kkjpwyk

15-09-2009 ls
03-08-2012 rd

&

&

&

dfu"B
lgk;d

xaxksyhgkV

04-08-2012 ls
05-05-2017 rd

&

&

&

ofj"B
lgk;d

ik[kw

06-05-2017 ls

ofj"B
lgk;d

x.kakbZ&

18-11-2017 ls

xaxksyh

28-08-2018 rd

ofj"B
lgk;d

csjhukx

29-08-2018 ls
31-03-2022 rd

&

&

&

&

&

&

29-08-2018 ls 31-03-2022

03 o"kZ 07 ekg 02 fnu
uk;c ukftj]
rglhy
dk;kZy;]
fiFkkSjkx<+A

26-07-2019 ls 31-032022

03-06-2014 rd

lgk;d

lgk;d

27

28-07-2011 rd

ofj"B lgk;d]
[kuu@is”kdkj]
vij
ftykf/kdkjh
dk;kZy;]
fiFkkSjkx<

17-11-2017 rd

02 Ok"kZ] 08 ekg] 03fnu

is'kdkj]
U;k;ky;
miftykf/kdkjh
csjhukx

29-08-2018 ls 31-03-2022

<!-- page 34 -->

;ksx

&

&

&

&

12 o"kZ 06 ekg 11
fnu

03 o"kZ 07 ekg 02 fnu

<!-- page 35 -->

-1228

29

Jh /keZ flag uiyP;ky]
ofj’B lgk;d@uk;c
ukftj] rglhy
dk;kZy;] /kkjpwykA

Jh pUnz eksgu ik.Ms;
ofj’B lgk;d
LVkEi@ifjogu
f'k{kk@fpfdRlk] ftyk
dk;kZy;] fiFkkSjkx<+

06-05-1972

25-09-1981

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

/kkjpwyk

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;

08-10-2009 ls
03-08-2020 rd

dfu’B
lgk;d

equL;kjh

09-06-2018 ls
28-08-2018 rd

ofj’B
lgk;d

/kkjpwyk

29-08-2018 ls
31-03-2022 rd

;ksx

&

08 Ok"kZ] 08 ekg] 01
fnu

dfu"B
lgk;d

tux.kuk]
dk;kZy;]
fiFkkSjkx<+

03-04-2010 ls
18-07-2011 rd

dfu"B
lgk;d

/kkjpwyk

27-07-2011 ls
07-10-2012 rd

dfu"B
lgk;d

ftyk
dk;kZy;

19-07-2011 ls
26-07-2011 rd

&

&

&

dfu"B
lgk;d

tux.kuk]
ftyk
fiFkkSjkx<+

08-10-2012 ls
27-01-2013 rd

&

&

&

uk;c ukftj]
rglhy
dk;kZy;]
/kkjpwykA

03 Ok"kZ] 09 ekg]
21 fnu

29-08-2018 ls 31-03-2022

03 o"kZ 07 ekg 02 fnu

ofj’B lgk;d
LVkEi@ifjogu
f'k{kk@fpfdRlk]
ftyk dk;kZy;]
fiFkkSjkx<+

29-08-2018 ls 31-03-2022

<!-- page 36 -->

-13-

30

31

Jh liu dqekj]
ofj’B lgk;d fofo/k]
ftyk dk;kZy;
fiFkkSjkx<+

Jh nsos'k ik.Ms;]
ofj’B lgk;d] mi Hkwfe
v/;kfIr dk;kZy;]
fiFkkSjkx<+

15-04-1984

03-07-1992

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

28-01-2013 ls
28-08-2018 rd

&

&

&

ofj’B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

29-08-2018 ls
31-03-2022 rd

;ksx

&

12 Ok"kZ] 04ekg]
05 fnu

&

&

01 Ok"kZ] 02 ekg]
12 fnu

03 o"kZ 07 ekg 02 fnu

dfu"B
lgk;d

rglhy
dukyhNhuk

13-08-2010 ls

&

&

&

29-08-2018 ls 31-03-2022

dfu"B
lgk;d

rglhy
MhMhgkV

24-12-2010 ls
21-06-2016 rd

&

&

&

dfu"B
lgk;d

ftyk
dk;kZy;

22-06-2016 ls
28-08-2018 rd

&

&

&

ofj’B
lgk;d

ftyk
dk;kZy;

29-08-2018 ls
31-03-2022 rd

&

&

&

;ksx

&

12 Ok"kZ] 08 ekg] 26
fnu

&

&

&

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

29-07-2011 ls
29-08-2018 rd

dfu"B
lgk;d

nsoyFky

08-03-2011 ls

ofj’B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

30-08-2018 ls
31-03-2022 rd

;ksx

&

10 Ok"kZ] 07 ekg]
29 fnu

23-12-2010 rd

28-07-2011

04 ekg] 21 fnu

03 o"kZ 07 ekg 02 fnu
ofj’B lgk;d]
mi Hkwfe
v/;kfIr
dk;kZy;]
fiFkkSjkx<+

30-08-2018 ls 31-032022

03 o"kZ 07 ekg 01 fnu

<!-- page 37 -->

-14-

32

33

34

Jh fodze jkor]
dfu"B lgk;d] rglhy
dk;kZy; MhMhgkVA

Jh lqjs'k PkUnz HkV~V]
ofj’B lgk;d@is'kdkj]
miftykf/kdkjh
U;k;ky;] fiFkkSjkx<+

Jherh jatuk iar tks'kh

uk;c ukftj rglhy
nsoyFky

06-10-1988

01-01-1986

10-06-1992

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

fiFkkSjkx<+

csjhukx

dfu"B
lgk;d

MhMhgkV

dfu"B
lgk;d

ftyk
dk;kZy;

dfu"B
lgk;d

MhMhgkV

21-11-2011 ls

25-06-2016 ls
09-08-2016 rd

dfu"B
lgk;d

equL;kjh

07-02-2018 ls

dfu"B
lgk;d

csjhukx

10-08-2016 ls
02-01-2018 rd

dfu"B
lgk;d

/kkjpwyk

03-01-2018 ls
06-02-2018 rd

ofj’B
lgk;d

caxkikuh

30-08-2018 ls
01-09-2020 rd

29-08-2018 rd
02-09-2020 ls
31-03-2022 rd

24-06-2016 rd

;ksx

&

02 Ok"kZ] 03 ekg]
06 fnu

dfu"B
lgk;d

fiFkkSjkx<+

30-05-2017 ls
29-08-2018 rd

dfu"B
lgk;d

/kkjpwyk

29-11-2011 ls
29-05-2017 rd

ofj’B
lgk;d

fiFkkSjkx<+

29-08-2018 ls
31-03-2022 rd

&

&

&

;ksx

&

04 Ok"kZ] 10 ekg

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

08-10-2013 ls
02-06-2014 rd

dfu"B
lgk;d

csjhukx

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

03-06-2014 ls
25-08-2020 rd

ofj"B
lgk;d

nsoyFky

ofj’B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

08-11-2021 ls
31-03-2022 rd

;ksx

07 o’kZ 03 ekg 10
fnu

dfu"B
lgk;d]
rglhy
dk;kZy;
MhMhgkVA

08 o"kZ 09 ekg
55 fnu

01 o’kZ 06 ekg 29 fnu
is'kdkj]
miftykf/kdkjh
U;k;ky;]
fiFkkSjkx<+

05 Ok"kZ] 06 ekg]
01 fnu
19-07-2012 ls
07-10-2013 rd
26-08-2020 ls
07-11-2021 rd

01 o’kZ 02 ekg 12
fnu

02-09-2020 ls orZeku
rd

29-08-2018 ls 31-032022 rd

03 o"kZ 07 ekg 02 fnu

ofj’B
lgk;d]
vkaXy
vfHkys[kkxkj]
ftyk
dk;kZy;
fiFkkSjkx<+

08-11-2021 ls 31-03-2022

04 ekg 23 fnu

<!-- page 38 -->

-1535

Jherh dfork vUuk
dfu"B lgk;d]rglhy

08-03-1989 fiFkkSjkx<+@ dukyhNhuk
rglhy dk;kZy;
dukyhNhuk

dukyhNhuk

36

Jh egs'k pUn

01-07-1982

dfu"B lgk;d mi
ftykf/kdkjh dk;kZy;
/kkjpwyk

37

Jh gfj 'akdj VEVk

dukyhNhuk

12-07-1989

dfu"B lgk;d] jktLo]
ftyk dk;kZy;]
fiFkkSjkx<+

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;

21-09-2013 ls
07-07-2014 rd

dfu"B
lgk;d

rglhy
dukyhNhuk

08-07-2014 ls
23-06-2019 rd

dfu"B
lgk;d

rglhy
dukyhNhuk

24-06-2019 ls
09-09-2021 rd

ofj’B lgk;d

rglhy
MhMhgkV

10-09-2021 ls
31-03-2022 rd

;ksx

&

08 o’kZ 06 ekg 10
fnu

dfu"B
lgk;d

ftyk
dk;kZy;

21-09-2013 ls
15-10-2013

dfu"B
lgk;d

/kkjpwyk

13-12-2013 ls
08-06-2018 rd

dfu"B
lgk;d

/kkjpwyk

ofj’B
lgk;d

ftyk
dk;kZy;

10-09-2021 ls
31-03-2022

;ksx

&

05 o’kZ 01 ekg 11
fnu

dfu"B
lgk;d

ftyk
dk;kZy;

09-07-2014 ls
09-09-2021 rd

ofj’B
lgk;d

rglhy
MhMhgkV

10-09-2021 ls
31-03-2022 rd

Jh izdk'k tks'kh
dfu"B
lgk;d@vgyen
miftykf/kdkjh
U;k;ky;] fiFkkSjkx<+A

12-07-1984

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

&

dfu"B
lgk;d

miftykf/kdk
jh U;k;ky;
fiFkkSjkx<+

ofj’B

vkaXy
vfHkys[kkxkj]

16-06-2014 ls
09-09-2021 rd
10-09-2021 ls

&

ofj’B lgk;d
MhMhgkV

10-09-2021 ls 31-03-2022

06 ekg 21 fnu

lEc)

16-10-2013 ls
12-12-2013 rd

ofj’B lgk;d]
ftyk dk;kZy;

dfu"B
lgk;d

csjhukx

fnukad 10-09-2021 ls 31-032022

09-06-2018 ls
09-09-2021 rd

03 o’kZ 05 ekg 05
fnu

07-10-2013 ls

08-07-2014rd

9ekg]02fnu

07 o’kZ 10 ekg 22
fnu

;ksx
38

&

dfu"B
lgk;d

csjhukx

16-11-2013 ls
15-06-2014 rd

ofj’B

rglhy

08-11-2021 ls 3103-2022

06 ekg 21 fnu
ofj’Blgk;d]
uk;c uftj]
rglhy
MhMhgkV

10-09-2021 ls 31-03-2022

08 ekg 21 fnu
ofj’B lgk;d] fnukad 08-11-2021 ls 31-03rglhy
2022
nsoyFky

<!-- page 39 -->

lgk;d

ftyk
dk;kZy;

07-11-2021 rd

;ksx

&

07 o’kZ 04 ekg
22 fnu

lgk;d

nsoyFky
04 ekg 23 fnu

11 ekg 13
fnu

-1639

40

41

42

Jh nhid Hk.Mkjh]
dfu"B lgk;d]
miftykf/kdkjh U;k;ky;
xaxksyhgkV

Jh enu eksgu tks'kh]
dfu"B lgk;d laxzg]
ftyk dk;kZy;
fiFkkSjkx<+

Jherh T;ksfr tks'kh]
dfu"B lgk;d] lSU;]
ftyk dk;kZy;]
fiFkkSjkx<+A

Jherh js[kk cksjk]
dfu"B lgk;d] rglhy
MhMhgkV

18-06-1980

23-07-1992

30-06-1979

10-06-1980

fiFkkSjkx<+@
xaxksyhgkV@ rglhy
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ /kkjpwyk@
rglhy dk;kZy;
/kkjpwyk

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ MhMhgkV
rglhy dk;kZy;
MhMhgkV

fiFkkSjkx<+

fiFkkSjkx<+

fiFkkSjkx<+

csjhukx

&

&

&

dfu"B
lgk;d

equL;kjh

18-11-2013 ls
26-11-2014 rd

&

&

&

dfu"B
lgk;d

xaxksyhgkV

27-11-2014 ls
09-09-2021 rd

&

&

&

ofj’B
lgk;d

/kkjpwyk

10-09-2021 ls 3103-2022 rd

;ksx

&

&

&

&

08 Ok"kZ]
04ekg]10fnu

dfu’B
lgk;d

ftyk
dk;kZy;

18-06-2018 ls
09-09-2021 rd

dfu"B
lgk;d

/kkjpwyk

18-11-2013 ls
18-06-2018 rd

ofj’B
lgk;d

ftyk
dk;kZy;

10-09-2021 ls
31-03-2022 rd

;ksx

&

03 o’kZ 09 ekg
13 fnu

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

06-09-2014 ls
02-12-2021 rd

;ksx

&

07 o’kZ 02 ekg
26 fnu

dfu"B
lgk;d

rglhy
dk;kZy;
MhMhgkV

25-11-2014 ls
31-03-2021 rd

ofj’B
lgk;d@is”kd
kj]
miftykf/kdkjh
dk;kZy;
/kkjpwyk

06ekg 21 fnu

ofj’B lgk;d]
ftyk dk;kZy;
fiFkkSjkx<+

04Ok"kZ] 07ekg

ofj’B
lgk;d

rglhy
Fky

03-12-2021 ls
31-03-2022 rd

&

&

10-09-2021 ls 31-03-2022

06ekg 21 fnu

ofj’B lgk;d]
Fky

03 ekg 28 fnu

&

fnukad 10-09-202131-032022

fnukad 03-12-2021 ls
31-03-2022 rd

03 ekg 28 fnu

ofj’B lgk;d]
ftyk dk;kZy;

fnukad 03-12-2021 ls
31-03-2022

<!-- page 40 -->

43

Jh uoy flag erksZfy;k]
dfu"B lgk;d] rglhy
equL;kjh

15-07-1991

fiFkkSjkx<+@equL;kjh@

equL;kjh

ofj’B
lgk;d

ftyk
dk;kZy;

03-12-2021 ls
31-03-2022 rd

;ksx

&

07 o’kZ 04 ekg
06 fnu

&

&

&

rglhy dk;kZy;
equL;kjh

03 ekg 28 fnu

dfu"B
lgk;d

equL;kjh

25-11-2014 ls ofj’B lgk;d]
02-12-2021 rd
rglhy

fnukad 03-12-2021 ls3103-2022

equL;kjh

;ksx

ofj’B
lgk;d

equL;kjh

03-12-2021
ls 31-03-2022

&

&

&

07 o’kZ 04 ekg
06 fnu

17-01-2015 ls

&

&

&

03 ekg 28 fnu

-17-

44

45

dq0 xhrk fc"V]
dfu"B lgk;d] izi=
iky] ftyk dk;kZy;]
fiFkkSjkx<+

Jh lanhi fc"V]
dfu"B lgk;d] U;k;]
ftyk dk;kZy;]
fiFkkSjkx<+

10-07-1991

03-04-1993

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

vYeksM+k

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;

&

&

&

ofj’B
lgk;d

rglhy
Fky

03-12-2021 ls
31-03-2022

;ksx

&

06 o’kZ 10 ekg
16 fnu

&

&

03 ekg 28
fnu

dfu"B
lgk;d

ftyk
dk;kZy;

22-06-2015 ls
31-03-2021 rd

&

&

&

ofj’B
lgk;d

ftyk
dk;kZy;

01-01-2022 ls
31-01-2022 rd

ofj’B
lgk;d

rglhy
caxkikuh

03-12-2021 ls
30-12-2021 rd

ofj’B
lgk;d

rglhy
caxkikuh

01-02-2022 ls
31-03-2022 rd

&

&

02 ekg 25

;ksx

&

02-12-2021 rd

05 o’kZ 10 ekg

ofj’B lgk;d]
rglhy
dk;kZy; Fky

fnukad 03-12-2021 ls
31-03-2022

03 ekg 28 fnu
ofj’b lgk;d]
rglhy
dk;kZy;
caxkikuh

01-02-2022 ls 31-032022

02 ekg

<!-- page 41 -->

09 fnu
46

47

Jh lqpsr dqekj]
dfu"B lgk;d@
vgyen miftykf/kdkjh
MhMhgkV

Jh vfHkuUnu flag /kkeh]
dfu"B lg;d] rglhy
caxkikuh

30-11-1993

fiFkkSjkx<+@ MhMhgkV@

fiFkkSjkx<+

rglhy dk;kZy;
MhMhgkV

28-03-1997

fiFkkSjkx<+@

/kkjpwyk

Jh eqds'k flag BxqUuk]
dfu"B lgk;d]
miftykf/kdkjh dk;kZy;
/kkjpwyk

MhMhgkV

;ksx

&

04 o’kZ] 04ekg]
17fnu

&

&

&

14-11-2017 ls
31-03-2022 rd

caxkikuh@
rglhy dk;kZy;]
caxkikuh

48

dfu"B
lgk;d

10-07-1998

fiFkkSjkx<+@/kkjpwyk@rg
lhy dk;kZy; /kkjpwyk

/kkjpwyk

fnu
dfu"B
lgk;d

Fky

20-01-2016 ls
13-11-2017 rd
01Ok"kZ] 09ekg]24fnu

dfu"B
lgk;d

caxkikuh

21-01-2016 ls
31-03-2022 rd

;ksx

&

&

&

&

06 Ok"kZ]
02ekg]10fnu

&

&

&

dfu"B
lgk;d

/kkjpwyk

29-07-2016 ls

&

&

;ksx

&

&

dfu"B
lgk;d@vgy
en
miftykf/kdkjh
MhMhgkV

31-03-2022 rd
05 o’kZ]08ekg]

14-11-2017 ls
31-03-2022 rd

04 o’kZ] 04ekg] 17fnu
dfu"B lg;d]
rglhy
caxkikuh

21-01-2016 ls
31-03-2022 rd
06 Ok"kZ] 02ekg]10fnu

dfu"B
lgk;d]
miftykf/kdkjh
dk;kZy;
/kkjpwyk

29-07-2016 ls 31-03-2022

05 o’kZ]08ekg]

<!-- page 42 -->

-1849

50

51

52

53

Jh ;ksxs'k dkdhZ] dfu"B
lgk;d@vgyen]
miftykf/kdkjh csjhukx

Jh izeksn flag cqQkZy]
dfu"B lgk;d] rglhy
csjhukx

dq0 dYiuk tks'kh]
dfu"B lgk;d] lkekU;]
ftyk dk;kZy;
fiFkkSjkx<+

Jherh yrk nsoh]
dfu’B lgk;d] rglhy
dk;kZy;] xaxksyhgkV

Jh fojsUnz flag
Mlhyk] dfu’B
lgk;d] rglhy
x.kkbZ&xaxksyh

09-11-1991

fiFkkSjkx<+@

csjhukx

csjhukx@ rglhy
dk;kZy; csjhukx

01-06-1994

07-04-1999

18-08-2018

07-12-2018

fiFkkSjkx<+@
csjhukx@rglhy
dk;kZy; csjhukx

fiFkkSjkx<+@ ftyk
dk;kZy; fiFkkSjkx<+

dfu’B lgk;d] rglhy
xaxksyhgkV

dfu’B lgk;d] rglhy
x.kkbZ&xaxksyh

equL;kjh

fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

ftyk
dk;kZy;

08-09-2017 ls
08-11-2017 rd

dfu"B
lgk;d

csjhukx

09-11-2017 ls
31-03-2022 rd

;ksx

&

02ekg] 01 fnu

&

&

04 o’kZ]
04ekg]22fnu

&

&

&

dfu"B
lgk;d

csjhukx

dfu’B
lgk;d

f”kfoj dSEi]
fiFkkSjkx<+A

31-08-2021 ls
02-12-2021

05-02-2018 ls
30-08-2021 rd

dfu’B
lgk;d

U;k;] ftyk
dk;kZy;
fiFkkSjkx<+

03-12-2021 ls
31-03-2022

;ksx

&

07 ekg

&

&

03 o’kZ] 06ekg] 25
fnu

&

ftyk
dk;kZy;

06-02-2018 ls
31-03-2022 rd

&

&

&

;ksx

&

04 o"kZ 01 ekg 25
fnu

&

&

&

&

&

dfu"B
lgk;d

xaxksyhgkV

18-08-2018 ls
31-03-2022 rd

;ksx

&

&

&

&

03 o"kZ 07 ekg
13 fnu

dfu"B
lgk;d

x.kkbZ&

07-12-2018 ls
31-03-2022 rd

&

&

x.kkbZ&
xaxksyh

;ksx

&

&

xaxksyh

dfu"B
lgk;d@
vgyen]
miftykf/kdkjh
csjhukx

09-11-2017 ls
31-03-2022 rd

04o’kZ] 04ekg]22fnu
dfu’B
lgk;d] ftyk
dk;kZy;
fiFkkSjkx<+

31-08-2021 ls 31-032022

07 ekg
dfu"B
lgk;d]ftyk
dk;kZy;
fiFkkSjkx<+

fnukad 06-02-2018 ls
31-03-2022 rd
04 o"kZ 01 ekg 25 fnu

03 o"kZ 03 ekg
24 fnu

dfu’B
lgk;d]
rglhy
xaxksyhgkV

18-08-2018 ls 31-032022 rd
03 o"kZ 07 ekg 13 fnu

dfu’B
lgk;d]
rglhy
x.kkbZ&xaxksyh

07-12-2018 ls 31-032022
03 o"kZ 03 ekg 24 fnu

<!-- page 43 -->

-1954

55

56

57

Jherh jsuw iUr]
dfu"B lgk;d]
rglhy dk;kZy;]
fiFkkSjkx<

18-07-1990

Jh y{e.k fxjh]
dfu"B lgk;d]
i= izs"kd] ftyk
dk;kZy; fiFkkSjkx<+

05-07-1986

dfu"B lgk;d] rglhy
fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d

rglhy
fiFkkSjkx<+

;ksx

Jh vkuUn
fd'kksjdfu"B
lgk;d] rglhy
equL;kjh

13-08-1978

Jherh 'kkfUr tks'kh
dfu"B lgk;d
vkaXy vfHkys[kkxkj
ftyk dk;kZy;
fiFkkSjkx<+

03-12-1966

dfu"B lgk;d] ftyk
dk;kZy; fiFkkSjkx<+

dfu"B lgk;d]

xaxksyhgkV

equL;kjh

dfu"B
lgk;d

&

ftyk
dk;kZy;
fiFkkSjkx<+

&

03-06-2019ls
31-03-2022 rd

&

&

&

02 o"kZ 09ekg 28
fnu

&

&

&

14-07-2019 ls
31-03-2022 rd

&

&

&

02 o"kZ 08 ekg
17 fnu

&

&

&

&

dfu"B
lgk;d

rglhy equL;kjh

dfu"B lgk;d] ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

dfu"B
lgk;d] i=
izs"kd] ftyk
dk;kZy;
fiFkkSjkx<+

&

;ksx

&

02 o"kZ 07ekg 18
fnu

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

13-08-2019 ls
31-03-2022 rd

&

&

&

02 o"kZ 07ekg 18
fnu

&

&

&

14-07-2019 ls 31-032022

02 o"kZ 08 ekg 17 fnu

equL;kjh

&

03-06-2019ls 31-032022
02 o"kZ 09ekg 28 fnu

rglhy 13-08-2019 ls dfu"B lgk;d]
equL;kjh 31-03-2022 rd rglhy dk;kZy;]

&

;ksx

dfu"B lgk;d]
rglhy dk;kZy;]
fiFkkSjkx<+

13-08-2019 ls
31-03-2022
02 o"kZ 07ekg 18 fnu

dfu"B
lgk;d] ftyk
dk;kZy;
fiFkkSjkx<+

13-08-2019 ls 31-032022
02 o"kZ 07ekg 18 fnu

<!-- page 44 -->

-2058

59

dq0 uwru vf/kdkjh
dfu"B lgk;d
jktLo
vfHkys[kkxkj ftyk
dk;kZy; fiFkkSjkx<+

Jh lkxj fc"V
dfu"B lgk;d
ftyk dk;kZy;
fiFkkSjkx<+

16-01-1989

21-12-1998

dfu"B lgk;d]
ftyk dk;kZy;
fiFkkSjkx<+

dfu"B lgk;d]
ftyk dk;kZy;]
fiFkkSjkx<+

fiFkkSjkx<+

vYeksM+k

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

26-12-2019 ls
31-03-2022 rd

&

&

&

;ksx

02 o’kZ 03 ekg
05 fnu

&

&

&

dfu"B
lgk;d

rglhy
30-12-2019 ls
dukyhNhuk 13-09-2020 rd

&

&

&

dfu"B lgk;d
ftyk dk;kZy;
fiFkkSjkx<+

14-09-2020 ls 31-032022

dfu"B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

14-09-2020 ls
31-03-2022 rd

&

&

&

&

&

02 o’kZ 03 ekg
01 fnu

&

&

&

31-03-2021 ls
31-03-2022 rd

&

&

&

;ksx
60

Jherh lquhrk pUn]
dfu’B
lgk;d]ftyk
dk;kZy; fiFkkSjkx<+

10-06-1987

dfu’B lgk;d] ftyk
dk;kZy; fiFkkSjkx<+

fiFkkSjkx<+

dfu’B
lgk;d

ftyk
dk;kZy;
fiFkkSjkx<+

dfu"B lgk;d
jktLo
vfHkys[kkxkj]
ftyk dk;kZy;
fiFkkSjkx<+

23-01-2020 ls 31-032022

02 o’kZ 03 ekg 05 fnu

01 o’kZ 06 ekg 07 fnu

dfu’B
lgk;d ]
ftyk
dk;kZy;
fiFkkSjkx<+

01 o’kZ

31-03-2021 ls 31-03-2022

01 o’kZ

61

dq0 [khek] dfu’B
lgk;d] rglhy
xaxksyhgkV

28-04-1998

dfu’B lgk;d]
rglhy
xaxksyhgkVA

xaxksyhgkV

dfu’B
lgk;d

rglhy
xaxksyhgkV

01-04-2021 ls
31-03-2022

&

&

&

&

&

&

&

&

&

&

11 ekg 30
fnu

&

&

&

dfu’B
lgk;d]
rglhy
dk;kZy;
xaxksyhgkV

01-04-2022 ls 31-032022

11 ekg 30 fnu

<!-- page 45 -->

62

Jherh ehuk nsoh

07-07-1987

dfu’B lgk;d]
laxzg ] ftyk
dk;kZy; fiFkkSjkx<+

csjhukx

dfu’B
lgk;d

laxzg ]
ftyk
dk;kZy;
fiFkkSjkx<+

Jh iou flag

01-07-1995

dfu’B lgk;d]

fiFkkSjkx<+

rglhy nsoyFkyA

dfu’B
lgk;d]
laxzg ]
ftyk
dk;kZy;
fiFkkSjkx<+

10 ekg 07
fnu

;ksx
63

24-05-2021 ls
31-03-2022 rd

dfu’B
lgk;d

rglhy
fiFkkSjkx<+

03-12-2021 ls
31-03-2022

10 ekg 07 fnu
dfu’B
lgk;d

03 ekg 28
fnu
64

Jh iadt dqekj

07-02-1994

dfu’B lgk;d]
rglhy /kkjpwyk

MhMhgkV

&

&

&

&

&

&

24-05-2021 ls 31-032022

rglhy 02-07-2021 ls
nsoyFky 02-12-2021 rd

dfu’B
lgk;d]
rglhy
fiFkkSjkx<+A

05 ekg
dfu’B
lgk;d

rglhy 04-01-2022 ls
/kkjpwyk 31-03-2022 rd

02 ekg 27
fnu

03-12-2021 ls 31-032022 rd

03 ekg 28 fnu
dfu’B
lgk;d]
rglhy
/kkjpwyk

04-01-2022 ls 31-032022 rd

02 ekg 27 fnu

izHkkjh vf/kdkjh]
d`rs ftykf/kdkjh] fiFkkSjkx<+A
