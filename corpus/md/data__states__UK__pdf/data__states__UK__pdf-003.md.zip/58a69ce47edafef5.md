---
doc_id: "58a69ce47edafef5"
source_url: "https://startuputtarakhand.uk.gov.in/attachments/2479596586.pdf"
ministry: "Startup Uttarakhand"
title: "notification_Relaxations_for_startups.pdf"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "60e895fc677bff70"
---

<!-- page 1 -->

प्रेस प्रकाशनी PRESS RELEASE

भारतीय ररज़िव बैंक
संचार विभाग, केंद्रीय कायाालय, एस.बी.एस.मार्ा, मुंबई-400001
_____________________________________________________________________________________________________________________

DEPARTMENT OF COMMUNICATION, Central Office, S.B.S.Marg, Mumbai-400001
फोन/Phone: 91 22 2266 0502 फैक्स/Fax: 91 22 22660358

RESERVE BANK OF INDIA

: www.rbi.org.in/hindi
Website : www.rbi.org.in
इ-मेल email: helpdoc@rbi.org.in
वेबसाइट

February 02, 2016
RBI announces Regulatory Relaxations for Startups
In paragraph 14 of the Sixth Bi-monthly Monetary Policy Statement for 201516 released today, the Governor highlighted the steps being taken by the Reserve
Bank of India, in keeping with the Government’s initiatives to promote the ease of
doing business and contribute to an eco-system conducive for growth of
entrepreneurship, particularly in respect of the start-up enterprises. The details are:
The following regulatory changes for easing the cross-border transactions,
particularly relating to the operations of the start-up enterprises are proposed to be
made, in consultation with the Government of India.
(i) Enabling start-up enterprises, irrespective of the sector in which they are
engaged, to receive foreign venture capital investment and also explicitly
enabling transfer of shares from Foreign Venture Capital Investors to other
residents or non-residents;
(ii) Permitting, in case of transfer of ownership of a start-up enterprises, receipt of
the consideration amount on a deferred basis as also enabling escrow
arrangement or indemnity arrangement up to a period of 18 months;
(iii) Enabling online submission of A2 forms for outward remittances on the basis
of the form alone or with document(s) upload/submission, depending on the
nature of remittance; and
(iv) Simplifying the process for dealing with delayed reporting of Foreign Direct
Investment (FDI) related transaction by building a penalty structure into the
regulations itself.
The notifications/circulars under Foreign Exchange Management Act (FEMA),
wherever necessary, will be issued shortly.
In addition, the following proposals are under consideration, in consultation
with the Government of India
(i) Permitting start-up enterprises to access rupee loans under External
Commercial Borrowing (ECB) framework with relaxations in respect of eligible
lenders, etc.;
(ii) Issuance of innovative FDI instruments like convertible notes by start-up
enterprises; and
(iii) Streamlining of overseas investment operations for the start-up enterprises.

<!-- page 2 -->

2

Certain other issues that are permissible under the existing regime shall be
clarified
(i) Issue of shares without cash payment through sweat equity or against any
legitimate payment owed by the company remittance of which does not
require any permission under FEMA; and
(ii) Collection of payments by start-up enterprises on behalf of their
subsidiaries abroad
The Reserve Bank has already created a dedicated mailbox to provide
assistance and guidance to the start-up sector. Further, electronic reporting of
investment and subsequent transactions will be made on e-Biz platform only.
Submission of physical forms will be discontinued with effect from February 8, 2016.

Press Release : 2015-2016/1809

Alpana Killawala
Principal Adviser
