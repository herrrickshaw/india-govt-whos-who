---
doc_id: "cbe28d2da787ccee"
source_url: "https://startuputtarakhand.uk.gov.in/attachments/2339549218.pdf"
ministry: "Startup Uttarakhand"
title: "notification_Revised_notification_Startups_Notification_23_05_17 (1).pdf"
date: ""
pages: 4
method: "pdftotext"
script: "DEVANAGARI"
needs_ocr: false
sha1: "fa1b5c17f991e248"
---

<!-- page 1 -->

REGD. NO. D. L.-33004/99

jftLVªh laö Mhö ,yö&33004@99

vlk/kj.k
EXTRAORDINARY

Hkkx II—[k.M 3—mi&[k.M (i)
PART II—Section 3—Sub-section (i)
izkf/dkj ls izdkf'kr
PUBLISHED BY AUTHORITY

la- 402]

ubZ fnYyh] eaxyokj] ebZ 23] 2017@T;s"B 2] 1939

No. 402]

NEW DELHI, TUESDAY, MAY 23, 2017/JYAISTHA 2, 1939

वािणज्य और उ ोग मं ालय
(औ ोिगक नीित एवं संवधर्न िवभाग)

अिधसूचना
नई िदल्ली, 23 मई, 2017
सा.का.िन. 501(अ).—यह अिधसूचना भारत सरकार की िदनांक 17 फरवरी, 2016 की राजप

अिधसूचना सं. सा.का.िन.

180(ई) के अिध मण म जारी की जा रही है।
पिरभाषा
िकसी संस्था(एिन्टिट) को िन ानुसार स्टाटर्अप माना जाएगाः
(क) यिद यह एक िनजी िलिमटेड कं पनी (कं पनी अिधिनयम, 2013 म यथापिरभािषत) के रूप म िनगिमत हो या एक भागीदारी फमर्
(भागीदारी अिधिनयम, 1932 की धारा 59 के अधीन पंजीकृ त) के रूप म अथवा भारत म सीिमत देयता भागीदारी (सीिमत
देयता भागीदारी अिधिनयम, 2008 के अधीन) के रूप म पंजीकृ त हो; और
(ख) उसके िनगमीकरण/पंजीकरण की ितिथ से सात वषर् तक; तथािप, जैव ौ ोिगकी क्षे के स्टाटर्अप के मामले म, यह अविध उसके
िनगमीकरण/पंजीकरण की ितिथ से दस वषर् तक होगी; और
(ग) िनगमीकरण/पंजीकरण के बाद से यिद िकसी िव ीय वषर् म उसका कारोबार 25 करोड़ रुपए से अिधक नह हुआ हो; और
(घ) यिद यह उत्पाद या ि या

या सेवा

के अिभनवीकरण, िवकास या सुधार के संबंध म कायर् कर रहा है अथवा यह रोजगार

सृजन या धन सृजन की उ संभावना वाला एक स्के लेबल
पहले से ही मौजूद िकसी

वसाय के िवभाजन या उसके पुनिनर्मार्ण के माध्यम से बनायी गयी िकसी संस्था(एिन्टिट) को ‘स्टाटर्अप’

नह माना जाएगा।

3324 GI/2017

ावसाियक मॉडल है।

(1)

<!-- page 2 -->

2

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

स्प ीकरण
(i) िकसी संस्था(एिन्टिट) को उसके िनगमीकरण/पंजीकरण की ितिथ से सात वषर् पूरे होने पर अथवा िकसी िवगत वषर् म उसका
कारोबार 25 करोड़ रुपए से अिधक होने पर स्टाटर्अप नह माना जाएगा। तथािप, जैव ौ ोिगकी क्षे के स्टाटर्अप के मामले म,
िकसी संस्था(एिन्टिट) को उसके िनगमीकरण/पंजीकरण की ितिथ से 10 वषर् पूरा होने या िकसी िवगत वषर् म उसका कारोबार
25 करोड़ रुपए से अिधक होने पर स्टाटर्अप नह माना जाएगा।
(ii) कारोबार, कं पनी अिधिनयम 2013 के अधीन यथा पिरभािषत है।
मान्यता की ि या
स्टाटर्अप के रूप म मान्यता की ि या, औ ोिगक नीित एवं संवधर्न िवभाग ारा स्थािपत मोबाइल ऐप/पोटर्ल पर िदये गये ऑनलाइन
आवेदन के माध्यम से होगी। संस्था(एिन्टिट) ारा िनगमीकरण/पंजीकरण माण-प एवं यथा वांिछत अन्य संब िववरण के साथ
ऑनलाइन आवेदन स्तुत करना आवश्यक होगा। स्टाटर्अप को वसाय के स्वरुप का ब्यौरा देना होगा िजसम यह मुखता से दशार्ना होगा
िक वह उत्पाद या ि या या सेवा के अिभनवीकरण, िवकास या सुधार या रोजगार सृजन या धन सृजन के सन्दभर् म अपनी
स्के लेिबिलटी की िदशा म िकस कार कायर् कर रहा है।
कर लाभ
कर संबंधी लाभ ा करने के िलए एक स्टाटर्अप
(i) को िनजी िलिमटेड कं पनी (कं पनी अिधिनयम 2013 म यथापिरभािषत) या सीिमत देयता साझेदारी (सीिमत देयता साझेदारी
अिधिनयम, 2008 के तहत यथा पिरभािषत) होना चािहए,जो 1 अ ैल, 2016 को या उसके बाद, लेिकन 1 अ ैल, 2019 से
पहले, िनगिमत हुआ हो; तथा
(ii) उत्पाद या ि या

या सेवा

के अिभनवीकरण, िवकास या सुधार के संबंध म कायर् कर रहा हो, अथवा यह रोजगार सृजन

या धन सृजन की उ संभावना वाला एक स्के लेबल

ावसाियक मॉडल हो; तथा

(iii) को औ ोिगक नीित एवं संवधर्न िवभाग ारा समय-समय पर यथागिठत अन्तर-मं ालयी माणन बोडर् से पा कारोबार का
माण-प ा करना होगा।
भारत म अिभनवीकरण को बढ़ावा देने की आवश्यकता के म ेनजर, अिभनवीकरणीयता पर घरे लू दृिष्टकोण से िवचार िकया जाएगा।
मा िन िलिखत के िवकास संबंधी कायर्कलाप से कोई स्टाटर्अप कर संबंधी लाभ का पा नह होगाःI. उत्पाद या सेवाएं या ि याएं, िजनम वािणज्यीकरण की संभावना नह है, अथवा
II. एकसमान उत्पाद या सेवाएं या ि याएं, अथवा
III. ाहक या कायर्- वाह के िलए शून्य या सीिमत मूल्यवृि

वाले उत्पाद या सेवाएं या ि याएं

िनरसन
बाद म, अगर कोई उपरो मान्यता ऐसी पायी जाती है िजसे सम्ब दस्तावेज अपलोड िकये िबना या झूठी सूचना के आधार पर ाप्त
िकया गया हो, तो डीआईपीपी को मान्यता माण-प और कर लाभ के िलए पा
वसाय का माणप , िकसी पूवर् सूचना या कारण
बताए िबना िनरस्त करने का अिधकार होगा।
भाव
यह अिधसूचना, सरकारी राजप म काशन की तारीख से भावी होगी।
[फा.सं. 5(91)2015-बीई-I]
राजीव अ वाल, संयु

सिचव

<!-- page 3 -->

¹Hkkx IIμ[k.M 3(i)º

Hkkjr dk jkti=k % vlk/kj.k

3

MINISTRY OF COMMERCE AND INDUSTRY
(Department of Industrial Policy and Promotion)
NOTIFICATION
New Delhi, the 23rd May, 2017
G.S.R. 501 (E).—This notification is being issued in supersession of Gazette Notification No G.S.R.
180 (E) of Government of India dated 17th February, 2016.
Definition
An entity shall be considered as a Startup:
a) if it is incorporated as a private limited company (as defined in the Companies Act, 2013) or
registered as a partnership firm (registered under section 59 of the Partnership Act, 1932) or a
limited liability partnership (under the Limited Liability Partnership Act, 2008) in India; and
b) up to seven years from the date of its incorporation/ registration; however, in the case of Startups
in the biotechnology sector, the period shall be up to ten years from the date of its incorporation/
registration; and
c) if its turnover for any of the financial years since incorporation/ registration has not exceeded
Rupees 25 crores; and
d) if it is working towards innovation, development or improvement of products or processes or
services, or if it is a scalable business model with a high potential of employment generation or
wealth creation.
Provided that any such entity formed by splitting up or reconstruction of a business already in existence shall
not be considered a ‘Startup’.
Explanation
i.

ii.

An entity shall cease to be a Startup on completion of seven years from the date of its incorporation/
registration or if its turnover for any previous year exceeds Rupees 25 crores. However, in respect of
Startups in the biotechnology sector, an entity shall cease to be a Startup on completion of ten years
from the date of its incorporation/ registration or if its turnover for any previous year exceeds Rupees 25
crores.
Turnover is as defined under the Companies Act, 2013.

Process of recognition
The process of recognition as a ‘Startup’ shall be through an online application made over the mobile app/
portal set up by the Department of Industrial Policy and Promotion. Entities will be required to submit the
online application along with the Certificate of Incorporation/ Registration and other relevant details as may
be sought. Startups also have to submit a write-up about the nature of business highlighting how is it working
towards innovation, development or improvement of products or processes or services, or its scalability in
terms of employment generation or wealth creation.
Tax Benefits
In order to obtain tax benefits, a Startup should –
i.

ii.

iii.

be a private limited company (as defined in the Companies Act, 2013) or a limited liability
partnership (as defined under the Limited Liability Partnership Act, 2008) which is
incorporated on or after the 1st day of April, 2016 but before the 1st day of April, 2019, and
be working towards innovation, development or improvement of products or processes or
services, or should be a scalable business model with a high potential of employment
generation or wealth creation, and
obtain a certificate of an eligible business from the Inter-Ministerial Board of Certification as
constituted by Department of Industrial Policy and Promotion from time to time.

<!-- page 4 -->

4

THE GAZETTE OF INDIA : EXTRAORDINARY

[PART II—SEC. 3(i)]

Recognising the need to encourage innovation in India, innovativeness shall be considered from a domestic
standpoint.
Provided that the mere act of developing:
I. products or services or processes which do not have potential for commercialization, or
II. undifferentiated products or services or processes, or
III. products or services or processes with no or limited incremental value for customers or workflow
would not make a Startup eligible for tax benefits.
Revocation
Subsequently, if such recognition is found to have been obtained without uploading the relevant documents or
on the basis of false information, DIPP reserves the right to revoke the recognition certificate and certificate of
an eligible business for tax benefits immediately without any prior notice or reason.
Effect
This notification shall come into effect on the date of its publication in the Official Gazette.
[F. No. 5(91)/2015-BE-I]
RAJIV AGGARWAL, Jt. Secy.

Uploaded by Dte. of Printing at Government of India Press, Ring Road, Mayapuri, New Delhi-110064
and Published by the Controller of Publications, Delhi-110054.

SARVESH KUMAR
SRIVASTAVA

Digitally signed by SARVESH
KUMAR SRIVASTAVA
Date: 2017.05.24 22:51:29 +05'30'
