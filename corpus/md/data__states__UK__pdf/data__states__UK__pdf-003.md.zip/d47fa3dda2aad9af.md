---
doc_id: "d47fa3dda2aad9af"
source_url: "https://www.kmvn.in/medias/tender_document/tender493344177847834966452511827980882_1349400522.pdf"
ministry: "Kumaon Mandal Vikas Nigam Ltd., Uttarakhand"
title: ""
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "24b01bf2e67562d9"
---

<!-- page 1 -->

fuxe ds Ik;ZVd vkokl x`g] rYyhrky ¼uSuhrky½ esa 30 fd0xzk0 {kerk ds ykW.Mjh lsVvi ¼vkijsVj
lfgr½ dh LFkkiuk ,oa lapkyu ds dk;Z gsrq bZ&fufonk izi=
fuxe ds Ik;ZVd vkokl x`g] rYyhrky ¼uSuhrky½ esa Ik;ZVd vkokl x`g] rYyhrky ,oa uSuhrky ds vU;
vkokl x`gksa ds d{kksa bR;kfn dh ykW.Mjh ,oa vkxUrqdksa dks yk.Mjh lqfo/kk iznku fd;s tkus ds mn~ns’; ls fuxe
ds Ik;ZVd vkokl x`g] rYyhrky esa fpfUgr LFky 6-50 x 3-80 ehVj esa ,d U;wure 30 fdyks xzke {kerk dk
ykW.Mjh e’khu lsVvi LFkkfir fd;s tkus gsrq fuxe }kjk mRrjk[k.M bZ&fufonk iksVZy
www.uktenders.gov.in ds ek/;e ls bZ&fufonk vkeaf=r dh tk jgh gSA
fufonk ls lEcfU/kr egRoiw.kZ frfFk;kWa fuEuor gSa%&
foKkiu izdk’ku dh frfFk
uktenders.gov.in ij fufonk viyksM dh frfFk ,oa le;
uktenders.gov.in ls fufonk MkmuyksM vkjEHk djus dh frfFk
,oa le;
izhfcM&ehfVax dh frfFk ,oa le;
vkWuykbu bZ&fufonk tek djus gsrq vkjEHk frfFk ,oa le;
vkWuykbu bZ&fufonk tek djus dh vfUre frfFk ,oa le;
rduhdh fufonk [kksyus rFkk bZ&fufonk ds ijh{k.k@ ewY;kdau
vkjEHk fd;s tkus dh frfFk ,ao le;

fnukad 09 ebZ] 2026
fnukad 11 ebZ] 2026 le; izkr% 10-00 cts
fnukad 11 ebZ] 2026 le; izkr% 10-30 cts
fnukad 14 ebZ] 2026 le; vijkUg 01-00 cts
fnukad 15 ebZ] 2026 le; izkr% 10-00 cts
fnukad 25 ebZ] 2026 le; vijkUg 01-00 cts
rd
fnukad 25 ebZ] 2026 le; vijkUg 01-30 cts

lfefr }kjk Rkduhdh fufonk ds ijh{k.k@ewY;kadu ds mijkUr lQy fufonknkrkvksa dh lwph jkT;
ljdkj dh oSclkbV www.uktenders.gov.in esa viyksM djrs gq;s foRrh; fufonk [kksyus dh frfFk ,oa le;
fu/kkZfjr fd;k tk;sxkA
fufonk ls lEcfU/kr egRoiw.kZ fu;e ,oa ‘krsZ fuEuor gSa%&
1& bZ&fufonk izi= ,oa fooj.k fdlh Hkh dk;Zfnol eas dqekÅW e.My fodkl fuxe fy0] eq[;
dk;kZy;&vksd ikdZ gkml] eYyhrky] uSuhrky rFkk jkT; ljdkj dh osclkbZV www. uktenders.gov.in ,oa
foHkkxh; osclkbZV kmvn.in ls MkmuyksM dj Hkh izkIr fd;k tk ldrk gS] ftl gsrq :0 5]000-00 ¼ikWp gtkj
ek=½ ‘kqYd fuxe eq[;ky; eas tek dj jlhn izkIr dh tk ldrh gS] fufonk izi= ‘kqYd vkWu ykbZu Hkh tek
fd;k tk ldrk gS] ftl gsrq fuxe ds [kkrs dk fooj.k fuEukauqlkj gSA
[kkrk/kkjd dk uke& dqekÅW e.My fodkl fuxe fy0]
cSad dk uke& dsujk cSad
[kkrk la[;k& 87423070000122
vkbZ0,Q0,l0 dksM& CNRB0005871

<!-- page 2 -->

fufonk izi= ‘kqYd tek dh jlhn dh ewy izfr dks fufonk tek djus dh vfUre frfFk ,oa le; ls iwoZ
fuxe eq[;ky; vksd ikdZ gkml] eYyhrky uSuhrky esa tek fd;k tkuk vko’;d gksxk ,oa mDr dh ,d izfr
fufonk ds rduhdh vkosnu ds lkFk vkWu ykbZu viyksM Hkh djkbZ tkuh vko’;d gksxhA
2& ykW.Mjh e’khu lsVvi ¼vkijsVj lfgr½ gsrq fufonk;sa 02 Hkkxksa esa izsf”kr dh tkuh gksxhA fufonk ds
rduhdh Hkkx esa fufonknkrk }kjk fufonk dh ‘krksaZ ds vuq:Ik lHkh vko’;dh; izi= LdSu dj bZ&fufonk iksVZy
www.uktenders.gov.in ij viyksM fd;s tkus gksaxs ,oa fufonk ds foÙkh; Hkkx esa fufonkdkj }kjk uke ,oa
njksa ls lEcfU/kr fooj.k vafdr dj viyksM fd;s tkus gksaxsA
3& leLr fufonknkrkvksa ls vis{kk dh tkrh gS fd os fpfUgr LFky dk Hkyh&HkkWfr Lo;a fujh{k.k djus ds
mijkUr gh vk’oLr gksus ij gh fufonk dh dk;Zokgh esa izfrHkkx djsaA fufonk esa izfrHkkx djus ds mijkUr ;fn
fpfUgr LFky ds lEcU/k esa fdlh izdkj dh O;ogkfjd dfBukbZ mRiUu gksrh gS] rks bl gsrq fufonknkrk Lo;a
mRrjnk;h gksxkA
4& vkiwfrZ fd;s tkus okys ykW.Mjh lsVvi ls lEcfU/kr rduhdh fof’kf”V;ksa dk fooj.k fuEukuqlkj gS%&
dze
la0
01

Lkkexzh dk uke
Washer

02

Extractor

03

Dryer

04

Flat
Bed
Press (With
Compressor)

05

Press

fof’k”Vrk;sa
Basket Size – 700x960, MINIMUM 30KG LOAD CAPCITY (FRONT LOAD), SELF
HEATING UPTO 120 DEGREE CELSIUS.
3 PHASE MOTOR .75KW WITH MINIMUM 40 RPM WASH SPEED
DRAIN SIZE 2.5 MM
STAINLESS STEEL BASKET WITH STEEL BODY
BASKET SIZE- 550X300 (71) LTR 2.2 KW MOTOR MINIMUM 1000 RPM
DIRECT DRIVE MOTOR WITH SELF BALANCE AUTO D.C. INJECTION BREAK
OVERALL DIMENSION 800X100X1050
Stainless steel inner basket
Double walled glass wool insulated
Electrically Controlled protection provided for Auto Timing, & auto reversing
through Micro Controlled Base Cyclic Timer/PL
Steam radiator/Electric Heaters: made out of coil and aluminium fins for steam
heated, or fin type air heating elements for electrically heated machine.
Pneumatic operated bed with moisture and timer for bed releasing of head
with pneumatic push butter raising and lowering of the head.
Auto timed, Auto Temperature Control, Low Energy Consumption.
Size- 1600 x 1600 x 1300
600 Kg / 800 Kg, 1900 x 1900 x 1600, 5.77 mm
Steam Iron with table, Auto Cut-off boiler, Minimum length 4 by 5 feet

fufonknkrkvksa dks mijksDr U;wure fof’kf”Vrkvksa dk ykW.Mjh lsVvi LFkkfir fd;k tkuk gksxkA
5& lQy fufonknkrk dks mijksDr lsVvi dks 01 o”kZZ dh vof/k gsrq Lo;a dh O;oLFkk ij lapkfyr fd;k
tkuk gksxkA blds fy, ekuo ‘kfDr dh fu;qDr lQy fufonkdkj ds Lrj ls dh tkuh gksxhA

<!-- page 3 -->

6& mijksDr ykW.Mjh lsVvi izfrfnu ¼fcuk vodk’k ds½ 14 ls 15 ?k.Vs lapkfyr jgsxkA bl vof/k esa
ykW.Mjh lsVvi ds lapkyu gsrq lQy fufonknkrk dks U;wure ,d vkijsVj ,oa ,d gsYij dks vius O;; ij
dk;ksZftr fd;k tkuk vfuok;Z gksxkA
7& fufonknkrkvksa dks fufonk ds foRrh; Hkkx esa ykW.Mjh lsVvi dh LFkkiuk dh njsa rFkk 01 o”kZ dh vof/k
gsrq mDr lsVvi ds lapkyu gsrq njks dks i`Fkd&i`Fkd lHkh djksa ,oa vU; ‘kqYdksa lfgr vafdr fd;k tkuk
vfuok;Z gksxkA lQy fufonknkrk dk p;u ykW.Mjh lsVvi dh njksa ,oa 01 o”kZ dh vof/k gsrq lapkyu njksa ds
;ksx ds vk/kkj ij U;wure njnkrk dks ,y0&01 fufonknkrk p;fur fd;k tk;sxkA
8& 01 o”kZ dh vof/k iw.kZ gksus ds mijkUr ykW.Mkjh lsVvi ds lapkyu dh lsok;sa lUrks”ktud ik;s tkus dh
n’kk esa fuxe vfxze 01 o”kZ ;k vf/kd vof/k gsrq iwoZ Lohd`r lapkyu njksa esa dk;Z vof/k esa foLrkj fd;s tkus
ij fopkj fd;k tk ldrk gSA
9& fufonknkrk }kjk vafdr fufonk njksa esa ¼d½ ykW.Mkjh lsVvi dk ewY;] lsVvi dks LFky rd VªkUliksVZ
fd;s tkus] yksfMax&vuyksfMax] buLVkWys’ku rFkk bySfDVªdy dk;Z ,oa okbZfjax bR;kfn dk ewY; ¼leLr djksa ,oa
O;;ksa lfgr½ rFkk ¼[k½ /kqykbZ gsrq iz;qDr fMVjtsUV] dSfedy ,oa iz;qDr ekuo ‘kfDr bR;kfn dh vko’;drkuqlkj
O;oLFkk gsrq dqy okf”kZd nj ¼leLr djksa ,oa O;;ksa lfgr½ fufonk ds foRrh; Hkkx esa i`Fkd&i`Fkd vafdr dh
tkuh gksxhA
10& lQy fufonknkrk dks fufonk ds foRrh; Hkkx esa vafdr ykW.Mkjh lsVvi dh njksa dk Hkqxrku lsVvi ds
LFky lqpk: :Ik ls dk;Z djus ds 15 fnol ds mijkUr fd;k tk;sxk ,oa lapkyu lsokvksa dk Hkqxrku foRrh;
Hkkx esa vafdr njksa ds vuqlkj izR;sd ekg dh lekfIr ds mijkUr vxys ekg ds izFke lIrkg esa fd;k tk;sxkA
11& lQy fufonknkrk }kjk mijksDr iz;kstu gsrq fu;ksftr ekuo ‘kfDr ds Hkkstu ,oa vkokl dh O;oLFkk
fuxe }kjk ugha dh tk;sxhA
12& mijksDr dk;ksZ gsrq fu;ksftr O;fDr;ksa dh leLr izdkj dh ftEesnkjh lQy fufonknkrk dh gksxhA
13& vkiwfrZ fd;s x;s ykW.Mjh lsVvi ij U;wure 03 o”kksZ dh dkWEizhgSfUlo okj.Vh iznku fd;k tkuk vfuok;Z
gksxkA mDr vof/k esa ykW.Mjh lsVvi ds [kjkc gksus dh n’kk esa lQy fufonknkrk dks Lo;a ds O;; ,oa yscj
pktZ ij ykW.Mjh lsVvi dh ejEer dj ykW.Mjh lsVvi dks lqpk: fd;k tkuk gksxk ,oa e’khuksa ds fdlh ikVZ
ds [kjkc gks tkus ij mls Lo;a ds O;; ij cnyk tkuk vfuok;Z gksxkA
14& dkWEizhgSfUlo okj.Vh okWj.Vh dh vof/k rd ykW.Mjh lsVvi ds fdlh Hkh Hkkx ds [kjkc gks tkus dh n’kk
esa lQy fufonknkrk dks mls 48 ?k.Vksa ds vUrxZr lqpk: fd;k tkuk vfuok;Z gksxkA bu 48 ?k.Vs dh vof/k esa
lQy fufonknkrk dks fuxe dh ykW.Mjh O;oLFkk Lo;a ds O;; ,oa O;oLFkk ij dh tkuh gksxhA 48 ?k.Vs dh
vof/k rd lQy fufonknkrk lsVvi dks lqpk: u fd;s tkus dh n’kk esa bls lsok ‘krksZ dk mYya?ku ekurs gq,
lQy fufonkdkj ds fo:) dk;Zokgh vey esa yk;h tk;sxh ,oa fuxe }kjk vius Lrj ls dh x;h ykW.Mkjh
O;oLFkk ij O;; /kujkf’k dh olwyh lEcfU/kr lQy fufonknkrk ls dh tk;sxhA
15& okWf’kax dk;Z esa iz;qDr gksus okyk fMVjtsUV] dSfedy bR;kfn dh O;oLFkk Hkh lQy fufonkdkj }kjk dh
tkuh gksxhA iz;qDr fMVjtsUV rFkk dSfedy vPNh xq.koRrk ds gksus vfuok;Z gksaxsA
16& fufonk izfrHkkfx;ksa dks fufonk ds lkFk /kjksgj jkf’k :0 1-00 yk[k ¼,d yk[k :Ik;s ek=½ dh /kujkf’k
dh ,Q0Mh0vkj0@cSd Mªk¶V tks fd izcU/k funs’kd] dqekÅW e.My fodkl fuxe ds uke ls cU/kd @cuk gks]
fufonk ds rduhdh Hkkx ds lkFk vkWuykbZu bZ&fufonk iksVZy ij viyksM fd;k tkuk vfuok;Z gksxkA mDr

<!-- page 4 -->

,Q0Mh0vkj0@cSd Mªk¶V dks fufonk izfrHkkxh }kjk ewy esa fufonk tek fd;s tkus dh frfFk ,oa le; ls iwoZ
fuxe eq[;ky; vksd ikdZ gkml eYyhrky uSuhrky esa tek fd;k tkuk vfuok;Z gksxkA
17& fufonk izfrHkkx dks fufonk vkosnu ds rduhdh Hkkx ds lkFk iSu dkMZ rFkk th0,l0Vh0 jftLVªs’ku
izek.k i= dh izfr dks LdSu dj vkWu ykbZu bZ&fufonk iksVZy esa viyksM fd;k tkuk vfuok;Z gksxkA
18& fufonkdkj dks fufonk ds rduhdh Hkkx ds lkFk rduhdh fufonk QkWeZ LdSu dj vkWuykbZu viyksM
fd;k tkuk vfuok;Z gksxkA
19& p;fur fufonknkrk }kjk mUgsa ykW.Mjh lsVvi gsrq vkiwfrZ vkns’k izsf”kr fd;s tkus ds 15 fnol ds Hkhrj
lkexzh dh vkiwfrZ ,oa buLVkWys’ku iw.kZ djrs gq, lsVvi dks lapkfyr fd;k tkuk vfuok;Z gksxk vU;Fkk dh n’kk
esa lQy fufonknkrk dh /kjksgj /kujkf’k dks tCr djus ds mijkUr ,y&02 cksyhnkrk dks] U;wure cksyhnkrk }kjk
vafdr nj ij lkexzh dh vkiwfrZ gsrq izLrko fn;s tkus ij fuxe }kjk fopkj fd;k tk ldsxkA
20& fu/kkZfjr le; ds ckn izkIr dksbZ Hkh fufonk Lohdkj ugha dh tk;sxhA
21& fufonk esa fdlh Hkh izdkj dk ifjorZu gksus ij la’kks/ku gsrq ‘kqf) i= dsoy fuxe dh csclkbZM
www.kmvn.in ,oa mÙkjk[k.M bZ&fufonk iksVZy www.uktenders.gov.in ij gh viyksM fd;k tk;sxkA
22& fufonk esa izfrHkkx djus okys fufonknkrk dh rduhdh fufonk esa fdlh izdkj dh =qfV gksus dh n’kk esa
fufonknkrk dh fufonk ds foÙkh; Hkkx dks ugha [kksyk tk;sxkA
23& fufonk izi= vFkok fuxe }kjk izsf”kr vkiwfrZ vkns’k ds lEcU/k esa fdlh Hkh izdkj dk fookn mRiUu gksrk
gS rks fookn ds fuLrkj.k dk U;kf;d {ks= uSuhrky gksxkA
24& izcU/k funs’kd vFkok muds }kjk ukfer izfrfuf/k dks ,d vFkok leLr fufonkvksa dks fcuk dkj.k crk;s
fujLr djus ,oa fufonk izfdz;k dks fdlh Hkh pj.k esa fujLr djus dk iw.kZ vf/kdkj gksxkA
fufonkdkj ds gLrk{kj&
uke&
iw.kZ irk&

<!-- page 5 -->

fuxe ds Ik;ZVd vkokl x`g] rYyhrky ¼uSuhrky½ esa 30 fd0xzk0 {kerk ds ykW.Mjh lsVvi ¼vkijsVj
lfgr½ dh LFkkiuk ,oa lapkyu ds dk;Z gsrq
Rkduhdh fufonk QkeZ
1&

fufonknkrk dk uke % - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

2&

firk dk uke% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

3&

QeZ dk uke% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

4&

irk% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

5&

nwjHkk”k% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

6&

bZesy vkbZMh% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -- - - - - -

7&

iSu dkMZ la[;k ¼izfr viyksM djsa½ % - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

8&

th,lVh jftLVsª’ku la[;k ¼izfr viyksM djsa½ % - - - - - - - - - - - - - - - - - - - - - - - - - - - -

9&

QkeZ dz; dh jlhn la[;k ¼izfr viyksM djsa ,oa ewy es fuxe esa tek djsa½ - - - - - - - - - - - - -

10 & /kjksgj jkf’k :0 1-00 yk[k dk fooj.k tks ¼izcU/k funs’kd] dqekÅ¡ e.My fodkl fuxe ds uke cU/kd
gksxh] izfr viyksM djsa ,oa ewy eas fuxe esa tek djsa½ ------------------------------------------------------------

fufonkdkj ds gLrk{kj&
uke&
irk&
