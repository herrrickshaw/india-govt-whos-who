---
doc_id: "ed66daa3da22fef4"
source_url: "https://almoraurban.bank.in/Assets/Downloads/data_privacy_policy_of_the_bank.pdf"
ministry: "Almora Urban Co-operative Bank Ltd., Uttarakhand"
title: "Privacy Policy"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "401abf2597a6521e"
---

<!-- page 1 -->

Privacy Policy of Almora Urban Co-Operative Bank
You agree that we may use Customer Information for the purpose of statistical analysis and for
creation of data ("Statistical Information"), which does not contain individual Customer Information. In
addition to the information that the Bank elicits from you, you are free to volunteer any other
information that you feel that the Bank needs to know, but the security and confidentiality as per this
Policy is guaranteed only to the information that the Bank directly asks from you.
This Policy holds true for a non-customer who has provided information to the Bank, by any means,
with the intentions of establishing a relationship, of whatsoever nature, with the Bank. By divulging
any information to us you agree to the terms and conditions of this Policy.
Use of Customer Information / Statistical Information
We may use the Customer Information for, among other things, customer verification, provision of
products and services, for personalization of products or services, marketing or promotion of our
financial services or related products or that of our associates and affiliates; for creation of Statistical
Information, statistical analysis or credit scoring, enforcement of your obligations, any other purpose
that will help us in providing you with optimal and high quality services.
Security
We have taken reasonable measures to protect security and confidentiality of the Customer
Information and its transmission through the World Wide Web. You are required to follow the Terms
and Conditions while using this Website including the instructions stated therein in respect of
security and confidentiality of your Log-in and Password.
The Bank will give access to Customer Information to only authorized employees. Employees who
violate this Privacy Policy shall be subject to disciplinary process as per the byelaws of the Bank.
Any employee who withdraws from the employment of the Bank will have to undertake to abide by
this Privacy Policy and keep all Customer Information secure and confidential.
Disclosure
•

•
•
•

We shall not be held liable for disclosure of the Customer Information or Statistical
Information in accordance with this Privacy Commitment or in terms of any other
agreements with you.
We may disclose the Statistical Information to any person, without any limitation and you
hereby give your consent for the same.
We may disclose Customer Information to any of our associates and affiliates, without any
limitation and you hereby give your consent for the same.
We may disclose the Customer Information to third parties for following, among other
purposes, and will make reasonable efforts to bind them to obligation to keep the same secure
and confidential and an obligation to use the information for the purpose for which the same
is disclosed, and you hereby give your consent for the same: o For advertising. or
o For facilitating joint product promotion campaigns. or

<!-- page 2 -->

•

•

We may disclose the Customer Information, to third parties, without limitation, for the
following reasons;
o To comply with legal requirements, legal process, legal or regulatory directive/
instruction. or
o To enforce the Terms and Conditions of the products or services. or
o To protect or defend our rights, interests and property or that of our associates and
affiliates, or that of our or our Affiliate's employees, consultants etc. or
o For fraud prevention purposes. or
o As permitted or required by law.
o For participation in any telecommunication or electronic clearing network. or
o For availing of the support services from third parties e.g. collecting subscription
fees, and notifying or contacting you regarding any problem with, or the expiration
of, any services availed by you.
o For the purposes of credit reporting, verification and risk management to/ with
clearing house centers or credit information bureau and the like.
For sharing with third-parties information obtained with your consent, from your mobile
device like device location, device information (including storage, model, installed apps, WiFi, mobile network) transactional and promotional SMS, communication information
including contacts and call logs ,for statistical modelling, credit scoring and any other
purpose that will help us in providing you with optimal and high quality services

Grievances
For discrepancies and grievances pertaining to processing of Information, you shall get in touch with
our Grievance Officer, at info@almoraaurbanbank.com

Cookie Policy
To continually enhance your online experience, we use cookies that store your preferences and give
us data about your browsing behavior, such as the pages you visited on this website, how much time
you spent on our site, etc. This information helps us understand customer interests and helps us
improve our website. By visiting the website, you acknowledge, accept and expressly authorize us
for the placement of cookies on your computer or hand held device. Please find below some more
information regarding cookies and their application on our website:
What are Cookies?
A cookie is a simple text file that is stored on your computer or mobile device by a website’s server
and only that server will be able to retrieve or read the contents of that cookie. Every cookie is
unique to your particular web browser. It will contain some anonymous information such as a unique
identifier and the site name with some digits and numbers. It allows the website to remember your
browsing behavior & show you relevant ads based on the browsing pattern. The cookies also allow
the website to limit the number of ads shown.

<!-- page 3 -->

How does Almoraaurbanbank.com.com use Cookies?
Almoraaurbanbank.com uses cookies to capture following information –
•
•
•
•

Source of visit to the website
Time spent on the website
Pages viewed on the website
Ad clicks

In addition to analyzing anonymous user behavior on Almoraaurbanbank.com, aforementioned data
also allows us to pre-empt requirements of prospects and existing account holders (by capturing
their customer id number) & pitch relevant services through display advertising or tele calling.
Please note that the scope of this tracking is limited to the almoraaurbanbank.com domain. User
activity on other third-party websites is not tracked by Almoraaurbanbank.com cookies.
Further information about cookies
If you’d like to learn more about cookies in general and how to manage them,
visit www.aboutcookies.org.
Changes to this policy
The above may change at any time. We will endeavor to notify you of any major changes but you
may wish to check it each time you visit our website.
