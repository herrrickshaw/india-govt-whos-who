---
doc_id: "f3ab3f9ab2e3ad18"
source_url: "https://cdn.s3waas.gov.in/s3291597a100aadd814d197af4f4bab3a7/uploads/2025/09/17574969838162.pdf"
ministry: "Leh Ladakh"
title: "Traffic Advisory Ladakh Marathon Day-3RD (586 KB)"
date: ""
pages: 2
method: "tesseract:eng+urd"
script: "LATIN"
needs_ocr: false
sha1: "a64178036b16e8b3"
---

<!-- page 1 -->

THE ADMINISTRATION OF UNION TERRITORY OF LADAKH
TRAFFIC POLICE HEADQUARTERS LADAKH
(e-mail: - sp-traffic@police.ladakh.gov.in) (Office Phone Nos Leh: - 01982-255388)
(Kargil: - 01985-295196)
PUBLIC NOTICE
It is hereby informed to the General Public that the 12!* Edition of the Ladakh Marathon,
will be conducted on different routes/ tracks from 11" September to 14 September, 2025 spanning
over 04 days having different challenges. Participants from all over India and UT Ladakh are going
to participate in the event and there is an expectation of huge traffic flow on Leh city roads. In view
of the same commuters in particular and public of District Leh in general including Army/ CAPF/
GREEF authorities are requested to adhere to the following traffic advisory in order to ensure smooth
and successful conduct of the event: -
DAY 3°° Run For Fun (13™ SEPTEMBER, 2025 0730hrs to 0830Hrs) Marathon Route: - NDS
Stadium Leh to Mentokling Motors and Back to NDS Stadium (05 KMs),
» The route from Choglmsar Zampa towards Singhay Namgial Chowk Leh will remain closed for
vehicular traffic from O500hrs to 1000hrs on 138 September, 2025.
» Route from Singhay Namgial Chowk Leh to Choglamsar will remain closed for vehicular traffic
from 0500hrs to 1000hrs on 137 September, 2025.
» All link routes leading to the main road shall also remain plugged in order to ensure safety of
runners.
Important notes: -
1. Tour & travel operators are requested to aware and guide the tourists to desist travelling on the
above routes during the mentioned dates.
2. Only Medical Emergency Ambulances shall be allowed to ply.
3. Traffic on said day event shall be allowed to ply on the race/ Marathon rally routes/ track as per
feasibility and other necessary diversion shall be made as per ground requirement/ feasibility.
4. Traffic coming from different link roads towards Marathon rally/ race track shall not be allowed
during the event.
5. General Public/ Army/ CAPF/ GREEF authorities are requested to plan their journey accordingly
and also requested to plan the convoy movement as per the traffic advisory.
6. General Public and all the stake holders are requested for cooperation to make the event
successful.
TRAFFIC POLICE LADAKH, WE SERVE FOR YOUR SAFETY ۱ .
24X7 Helpline No. +91-8082863919 ‏بک‎
‎(Vikas ‏سوا‎ PS)
Sr. Superintendent of Police,
Traffic, UT-Ladakh.
No: - THQ/Traffic-Advisory/2025-2 )۹5۰ ‏0ھ‎ Dated: - 0۹/09/2025
Copy to: -
1. The Director General of Police, UT-Ladakh, PHQ Ladakh, Leh.
Page | 1

<!-- page 2 -->

2. The Station Commander 14 Corps Headquarter, C/O 56 APO.
3. The Deputy Inspector General of Police Leh-Kargil Range, PHQ Ladakh, Leh.
‏۵۲اآسسسسسسسممی‎ favor of kind information.
4. The Deputy Commissioner, District Leh for favor of information.
5. The Sr. Superintendent of Police, District Leh for information and necessary action.
6. The Adm. Commandant 14 Corps, C/O 56 APO for information.
7. The Commanding Officer CMP, C/O 56 APO for information.
8, Dy. Superintendent of Police Telecommunications, Leh for information and necessary action.
9, Dy. Superintendent of Police Traffic, Leh for information and necessary action.
10, Assistant Director Information, Leh for information with the request for wide publicity.
11. Assistant Director Doordarshan Kendra, Leh for information with the request for wide publicity.
12. Programme Head All India Radio, Leh for information with the request for wide publicity.
13. DTI/ IC Flying Squad Leh, for information and necessary action.
14. President Press Club Leh, UT-Ladakh for information with the request for wide publicity.
15. PCR PHQ/ PCR Leh for information and necessary action.
16. President Bus Union/ Mazda Union/ Truck Union/ Taxi Union/ Van Unioly for /information and
necessary action. Vea yp
Sr. Superintendent of Police,
. Traffic, UT-Ladakh.
Page | 2
