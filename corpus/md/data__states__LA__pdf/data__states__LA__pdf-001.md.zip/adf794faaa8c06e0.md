---
doc_id: "adf794faaa8c06e0"
source_url: "https://cdn.s3waas.gov.in/s341ae36ecb9b3eee609d05b90c14222fb/uploads/2026/10/17931854201842.pdf"
ministry: "Kargil"
title: "Issue of Notifications for general elections to all Panchayat Halqas by the State Election Commission"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e76bae3a64eaa177"
---

<!-- page 1 -->

भारत सरकार
GOVERNMENT OF INDIA

एस.जी.-एल.डी.-अ.-26102026-1866
xxxGIDHxxx
SG-LD-E-26102026-1866
xxxGIDExxx

असाधारण

EXTRAORDINARY

प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY

लद्दाख, 26 अक्टूबर, 2026
LADAKH, MONDAY, OCTOBER, 26, 2026

Part II - Section 3

केन्द्र-शासित प्रदे श लद्दाख प्रशािन
ADMINISTRATION OF UNION TERRITORY OF LADAKH

STATE ELECTION COMMISSION
LADAKH
F-Block, 1st Floor, M.S. Apartments,
Kasturba Gandhi Marg,
New Delhi – 110 001.
NOTIFICATION
No.10-1/EC/LD/2023
Dated the 26th October, 2026
Whereas, the Administrator, Union Territory of Ladakh, has, by a notification under Rule 7 of the Jammu
and Kashmir Panchayati Raj Rules, 1996 (as applicable to the UT of Ladakh), published in the Official Gazette on
the 26th October, 2026, called upon all constituencies of Panchayat Halqas in the Union Territory of Ladakh to
constitute new Panchayats;
Now, therefore, in pursuance of provisions of Rule 8 of the Jammu and Kashmir Panchayati Raj Rules,
1996 (as applicable to the UT of Ladakh), the State Election Commission, Ladakh (Election Authority), hereby
appoints the following dates for the said election: -

<!-- page 2 -->

LADAKH GAZETTE : EXTRAORDINARY

2

a) the 2nd November, 2026 (Monday), between 11.00 a.m. and 3.00 p.m., as the last date and hours for making
nominations;
b) the 3rd November, 2026 (Tuesday) 11.00 a.m., office of the respective Returning Officer as the date, time and
place for the scrutiny of nominations;
c) the 5th November, 2026 (Thursday), 3.00 p.m., as the last date and hour for the withdrawal of candidature;
d) the 21st November, 2026 (Saturday), between 8.00 a.m. and 5.00 p.m., as the date on which, and the hours during
which, a poll shall, if necessary, be taken; and
e) the 30th November, 2026 (Monday), as the date before which the elections shall be completed.
Sd/(Sudhanshu Pandey)
State Election Commissioner

“No legal responsibility is accepted for the contents of publication of advertisements/publications in this part of The
Ladakh Gazette. Persons notifying the advertisements/public notices will remain solely responsible for the legal
consequences and also for any other misrepresentation etc.”

PT
RUDRA
GOUD

Digitally signed
by P T RUDRA
GOUD
Date: 2026.10.26
18:56:50 +05'30'

signed
NIDHI Digitally
by NIDHI MALIK
Date: 2026.10.26
MALIK 18:53:53 +05'30'
