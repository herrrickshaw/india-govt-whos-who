---
doc_id: "f716edf9d84eda8e"
source_url: "https://cdn.s3waas.gov.in/s3291597a100aadd814d197af4f4bab3a7/uploads/2022/09/2022091440.pdf"
ministry: "Leh Ladakh"
title: "The Right to Information (Amendment) Act, 2019- Section-4 (1)(b) (DC Office Leh)"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "deafb949dc90f328"
---

<!-- page 1 -->

THE RIGHT TO INFORMATION ACT, 2005 (22 OF 2005)

AS AMENDED BY
THE JAMMU AND KASHMIR REORGANISATION ACT, 2019 (34 of
2019) (w.e.f. 31-10-2019)
And
THE RIGHT TO INFORMATION (AMENDMENT) ACT, 2019 (24 OF
2019)

OFFICE OF THE DEPUTY COMMISSIONER/CEO, LAHDC, LEH,
UNION TERRITORY OF LADAKH

OBLIGATIONS OF PUBLIC AUTHORITIES MANUAL OF
DEPUTY COMMISSIONER OFFICE LEH

<!-- page 2 -->

INTRODUCTION
In order to promote transparency and accountability in the working of every
public authority and to empower the citizens to secure access to information under the
control of each authority, the Government of India have enacted 'The Right to
Information (Amendment) Act, 2019', (RTI). In accordance with the provisions of
section 4(1) (b) of this Act, the office of the Deputy Commissioner/CEO, LAHDC, Leh
Union Territory of Ladakh has brought out this handbook for information and guidance
of the general public.
The handbook provides an overall view of DC office, Leh its functions and duties
of its officers and employees and records, composition, organizational structure etc.
This office is headed by a Deputy Commissioner/CEO, LAHDC, Leh assisted by
Additional Deputy Commissioner, Leh, Assistant Commissioner, (Rev), Leh, Chief
Planning Officer, Leh, Headquarter Assistant, Account Officer and officials staff and has
designated at the following one CPIO, and one CAPIO to government as its Central
Public Information Officer (CPIO) and Central Assistant Public Information Officer
(CAPIO) for matters concerning of this office. The telephone numbers of the
CPIO/CAPIO are mentioned against their name and sections assigned to them. Any
person requiring any information under the Act may contact the concerned officers to
this office.
Contact Person:
Sh. Shabir Hussain, Assistant Commissioner, (Rev), Leh
(Central Assistant Public Information Officer)
Phone No. 01982-257415
Procedure and fee structure for getting information:
As request under sub-section (1) of section 6 for obtaining information shall be
made
in form -1 and accompanied by an application gee of Rs.-10/- by Indian postal
order/demand draft/bankers cheque payable to accounts officer of the public
authority/concerned CPIO.
A request for obtaining information shall be deemed to be made duly accompanied by
prescribed application fee if it is written on a non-judicial stamp paper of Rs.50/
CHAPTER-ONE
Particulars of Organization function and duties
1.1. Objectives/purpose of the public authority:
The Deputy Commissioner is the head of the Revenue department in the District
and is also called the Collector under Land Revenue Act. It is under his supervision

<!-- page 3 -->

and guidance all the revenue records of the District are compiled and updated from
time to time as per the relevant rules.
The Deputy Commissioner is responsible for implementing state government’s
programmes and policies at the grassroots level and collecting information
regarding the needs and facilities to be provided to the general public, their
difficulties and redressal etc. and making the government aware of these. The
Deputy Commissioner also acts as the Chief Executive Officer of Ladakh
Autonomous Hill Development Council (LAHDC).
The Deputy Commissioner being the District Magistrate is responsible for
maintaining the law and order situation in the district. In times of any natural
calamity like floods, locusts, drought, storm etc, the Deputy Commissioner is the
primary relief agency he is designated as Chairman of District Disaster Management
Authority (DDMA). During the occurrence of natural calamities or during internal or
external disturbance, the Deputy Commissioner calls for military assistance and coordinates the efforts of the civil-military administration. There are number of other
officers at the district headquarters such as Additional Deputy Commissioner,
Assistant Commissioner Revenue, Chief Planning Officer, etc. for the assistance of
the Deputy Commissioner to carry out the workings of the district administration. At
the sub Divisional level, the Sub Divisional Magistrate (SDM) is responsible for the
administration who is assisted by the Tehsildar, Naib Tehsildar, Block Development
Officer, Qanungos, Patwaris and other officials. In fact more than being an officer,
the Deputy Commissioner is actually an institution itself, under whose governance
democracy reaches every nook and corner of the district. The Deputy Commissioner
is designated as District Election Officer and the elections are conducted under his
/her supervision.

1.2. Mission/Vision Statement of the Public Authority:
“To ensure a simple, moral accountable, responsive and transparent system of
administration leading to overall inclusive development of Leh district”.
1.3. Duties of the Public Authority-DC Office, Leh:
 To prepare the annual plan.
 To accord administrative approval other than PWD Department.
 To make progress report on monthly, quarterly and yearly basis.
 To conduct annual plan meeting.
1.4. Main Activities/Function of the Public Authority:
 Plays an active role in all development activities in the district under
programmes such as MP Local Area dev Fund and Plan Funds.
 Formulation of Annual Plan.
 Preparation of progress reports on monthly, quarterly and yearly basis.
 Keep an account of centrally sponsored schemes and providing state matching
share.
 Conduct a General Counsel Meeting/ Annual Plan Meetings.

<!-- page 4 -->

 Collection of plan related data from various head of departments through its
planning cells in the concerned departments
 Maintain active liaison with LAHDC Leh and the UT Administration of Ladakh.
1.5.

Organizational setup of DC office Leh.
Deputy Commissioner/
CEO, LAHDC Leh

Additional
Deputy
Commissioner (ADC)

Assistant
Commissioner
(Revenue)

Chief Planning
Officer
(Planning
Section

Account
Officer

Establishment

1.6. Expectation of the public authority from the public for enhancing its
effectiveness and efficiency:
The DC office Leh strives to bring its best services to the citizens/general public. The
DC office welcomes feedbacks from
the general public regarding various
activities/programmes implemented/executed by this department in the District.
1.7.

Arrangement and methods made for seeking public/contribution.

The citizens /general public may get any information under RTI Act regarding any
development activities implemented /executed by this department in the district
through the concerned CPIO or form planning & development section DC office Leh.
A request for obtaining information shall be accompanied by an application fee of
rupees Ten by way of cash aginst proper receipt or by Indian order/demand
draft/bankers cheque payable to the CPIO concerned.
1.8.

Mechanism available for monitoring the service delivery and public
grievence resolution

<!-- page 5 -->

Any specific information required or grievances related to any development
activities implemented/execute by this department in the district is addressed
immediate by the Deputy Commissioner /CEO LAHDC, Leh himself or through his
sub ordinate officers i.e ADC, ACR, CPO,SDMs and through the Tehsildar
concerned.
1.9.

Addresses of the main office and other offices at different level.
Main office: Deputy Commissioner’s Office complex, Leh near pologround Leh.

1.10. Office Timings
Monday- Saturday
Morning hours of the Office: 10:00 a.m
Closing hours of the office: 04:30 p.m
Closed on Sunday and Public holidays

CHAPTER-TWO
Powers and Duties of Officers and Employees
2.1.

Deputy Commissioner/CEO, LAHDC, Leh
Administrative power:- Deputy Commissioner is vested with the powers of
the District Magistrate, District Collector and Chief Executive Officer of LAHDC. As
District Magistrate, he is responsible for maintenance of law & order in the
district assisted by the Superintendent of Police and number of Executive
Magistrates under him. As District Collector, the Deputy Commissioner heads the
district revenue organization which is responsible for collection of land revenue,
maintenance of revenue records and implemented of various revenue law like
agrarian reforms Act. Revenue Act, Tenancy Act etc.
As the CEO of LAHDC, the Deputy Commissioner is responsible for preparing the
annual plan with the help of the district heads which after consolidated is
presented in the general council meeting. The annual district plan is approved by
the general council as per the LAHDC act. The Deputy Commissioner/ CEO
ensures the implementation of the plan.
The Deputy Commissioner is the chairman of the District Management Authority
and District crisis management group for dealing with disaster and cri is in the
district. The deputy Commissioner is the district election officer.The Deputy
Commissioner is also Chairman LAHDC-SSRB in recruitment of District cadre post
allocated under his control.
Duties:-

<!-- page 6 -->

 The Deputy Commissioner is the chief revenue officer and as district collector
is responsible for collection of revenues and other govt. Dues recoverable as
arrears of land revenue.
 The Deputy Commissioner being the Chief Executive officer of LAHDC, under
section 40(2) of LAHDC Act, Leh has a power to transfer Govt employees
after prior approval of the executive council and can take necessary action
against the employees posted in Leh district (as all the Govt employees
except the judicial and police shall be deemed to be transferred to the
LAHDC-Leh.
 He is also overall in charge of the planning & development section.
 Monitoring inspection and supervision of the performance of the various
schemes and programmers.
 Conduct of review meeting for assessing the performance of the schemes,
taking corrective actions and submission of reports to the higher authorities.
 To accord administrative approval for capex Plan.
 He is the CEO of LAHDC Leh and as the CEO of LAHDC implements they
decisions of LAHDC, Leh
 Acts as District Magistrate and is responsible for maintenance of law and
order within the District.
 Acts as District Development Commissioner to oversee the developmet
activities in the District under various Central/State schemes.
Additional Deputy Commissioner, Leh
Duties: Additional District Magistrate maintains law and order within the district.
 Disposed off all the revenue related cases referred to him/her.
 Deals with the Disaster/ Relief related matters as under District Disaster
Management Authority being a Chief Executive Officer, DDMA, Leh.
 Deals with court cases.
 Departmental enquiries.
 He/she is district census officer 2022 in the district
 Maintains national population register.
 He/she is designated as CPIO under RTI act 2005..
 Act as District Vigilance Officer, deals with complaints and submits enquiry report
before the State Vigilance Commission.
 He/ she is a designated a Regional Survey and Land Record Officer and
supervisor the work/digitalization of records under DILRMP.
 He/ she is the Registrar of Documents under Central Registration Act.
Chief Planning Officer:He is the officer in- incharge of the Planning section and scrutinizes the planning &
development matters submitted by the various departments and also provide assistance
to the Deputy Commissioner/ CEO LAHDC Leh.
Duties:-

<!-- page 7 -->

 Provides advice on planning matters as may be referrers to him by the Deputy
Commissioner or any other officer.
 Reports matters to the Deputy Commissioner / CEO LAHDC Leh or further orders.
 Monitors various plan related during formulation of annual plan.
 He also maintains Liaison with all district officers regarding collection of
information and preparation of annual district plan.
Assistant Commissioner Revenue (ACR)
The ACR is a revenue officer and assists the Deputy Commissioner in all the Revenues
related matters and is also designated as Additional District Magistrate and it is his
responsibility to guide/ brief the deputy Commissioner regarding all the revenue related
matters.
Duties: The ACR deals with all the revenue related matter of the district.
 The ACR is designated as sub registrar to register the various documents.
 The ACR disposed of the revenue cases within his jurisdiction or one refer to
higher revenue officer.
 It is also his responsibility to maintain law and order being the additional district
magistrate.
 It is through his office all that monthly report pertain the revenue department
are received and compiled and to submit the same to the higher authority on
monthly basis.

CHAPTER-THREE
Rules, Regulations, Instruction, Manual and Records, For Discharging
Functions
The list of rules, regulations, instruction and guidelines held by public authority or
under its control or used by its employees for discharging functions are governed by the
prescribed norms / guideline of the respective programmes / schemes/ departments,
can be obtained from the concerned implementing/ executing agencies.

CHAPTER- FOUR
Particulars of any arrangement that exists for consultation with or
representation by, the members of the public in relation to the formulation of
its policy or implementation thereof.
Formulation of policy:

<!-- page 8 -->

The Annual District Plan:- On the basis of the final ceiling/ instruction conveyed by the
planning & development department, the line departments are being directed to
formulate the annual plan usually during the month of April- May every year.
The annual plan of the line department is then compiled/ consolidated by the planning
& development section, DC office Leh keeping in view the priorities of the LAHDC Leh
and the instructions conveyed by the planning & development department, and is
presented on the floor house for discussion and decision making in the general council
meeting. Once the annual plan gets finalized/ approved in general council meeting, the
annual district plan is then forwarded to the planning & development department
allocated of UT of Ladakh for release of the funds.

CHAPTER FIVE
The Names, Designation And Other Particulars Of The Public Information
Officers.

Central Public Information Officer/Central Assistant Public Information
Officer
S.No.
Name
Designation
Contact No.
1
Shri Sonam Chosjor
Addl. Deputy
01982252049
Commissioner, Leh
2
Shri Shabir Hussain
Assistant
01982257415
Commissioner,
(Revenue) Leh
First Appellate Authority
S.No.
1

Name
Shri. Shrikant Balasaheb Suse
IAS

Designation
Deputy
Commissioner/CEO,
LAHDC, Leh

Contact No.
01982252010

CHAPTER SIX
DIRECTORY OF OFFICERS AND EMPLOYEE

S.No
1.
2.

Names
Shri. Shrikant Balasaheb Suse
IAS,
Shri Sonam Chosjor

Designation
Deputy
Commissioner Addl Deputy
Commissioner

Contact No
8275016521
9622113650

<!-- page 9 -->

3.

Shri. Shabir Hussain

4.

Smt. Nilza Angmo

5.

Skalzang Chospa

6.

Phuntsok Angdu ,

7.

Abdul Rouf,

Assistant
Commissioner,
Revenue
Headquarter
Assistant to Deputy
Commissioner
Accounts Officer to
Deputy
Commissioner
Section
Officer(Adm)Head Assistant-

7006546765

8.

Kunzang Dolma,

Head Assistant

9.
10

Kulsum Khatoon
Stanzin Dolma,

Head Assistant
Accountant

9622239512
9797677280

11

Rahim Ali,

SADDAR Quango

9622965370

12

Skarma Tashi Yangchan

Mohasib

9622047764

13

Nawang Dolma,

Senior Assisatant-

9469198517

14.
15.
16.
17.
18.
19.
20
21
22.
23.
24.
25.
26.
27.
28.
29.
30.
31.
32.
33.
34.
35.
36.

Tsering Ladol
Konchok Sherab
Konchok Zangmo
Tsering Diskit
Sonam Dolma
Gh.Haider
Amjad Khan
Phunchok Dolma
Namgail Angmo
Tsering Lamo
Chemat Angmo
Ishey Angmo
Stanzin Ladol
Mipham Thestop
Soanm Yangdol
Sonam Stobgais
Tsering Angmo
Tsewang Otsal
Sakina Bano
Padma Tsewang
Stanzin Dawa Meta
Stanzin Younzin
Urgain Namdol

Senior Assistant
Senior Assistant
Senior Assistant
Senior Assistant
Senior Assistant
Senior Assistant
Senior Assistant
Senior Assistant
Senior Assistant
Senior Assistant
Senior Assistant
Senior Assistant
Legal Assistant
Junior Assistant
Junior Assistant
Junior Assistant
Junior Assistant
Junior Assistant
Junior Assistant
Junior Assistant
Junior Assistant
Junior Assistant
Junior Assistant

8492832022
09419850759
9906984553
9469732499
9469368771
9622955195
9596268574
9797476706
9797545559
9419657448
9622381121

9469336576
9419177762
9419889544
9419219426

9622068634
9622046940
7051079931
8492076675
9622913103
8082560885
9596783627
8494074165
7051074987
8492074839

<!-- page 10 -->

37.
38.
39.
40.
41.
42
43.
44.
45.
46.
47.
48.
49.
50.
51.
52.
53.
54.
55.
56.
57.
58.
59.

Zahoor Ahmed
Thinley Norbu
Nargis Banoo
Jigmet Dorjey
Mohd. Ali
Tashi Tsomo
Tsering Tundup
Padma Dolker
Tsering Spaldon
Zara Khatoon
Dawa Dolma
Kunzang Takpa
Sonam Yangdol
Nilza Angmo
Tsering Dolker
Tsering Dolker
Rinchen Dolker
Padam Angmo
Padma Dolker
Fatima Bano
Farida Bano
Rigzin Yangdol
Tsewang Dorjey

60.

Iftikar Ali

61.

Rinchen Angchuk

62.

Rinchen Angmo

63.
64.
65.
66.
67.

Choezin Palmo
Tsewang Gyalson
Sonam Tundup
Jigmet Rabgais
Sheetal Bhagat

Junior Assistant
Junior Assistant
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
Orderly
I/C Election, Naib
Tehsildar
Election Assistant
Senior
Election Assistant
Senior
Election Assistant,
Junior
Orderly
CEO
Statistical Officer
Statistical Assistant
Statistical Assistant

9622047010
9906978460
9622958066
9484032475
9622998331
9622088576
7051154398
9906999116
7051123554
9622997900
8492832127
9596735494
8492977444
9622159655
6006499167
9541347131
9622323642
9797452770
7051102579
9797499861
9419312495
9797659233
9469337119
9797624448
9469626030

9469089722
9906115505
9622473459
9906245655
8082335352

<!-- page 11 -->

<!-- page 12 -->
