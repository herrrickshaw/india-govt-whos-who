---
doc_id: "2a5af8fdac565bd7"
source_url: "https://cdn.s3waas.gov.in/s341ae36ecb9b3eee609d05b90c14222fb/uploads/2026/10/17931851648459.pdf"
ministry: "Kargil"
title: "Publication of notification regarding revised list of ROs AROs for Panchayat -Notification"
date: ""
pages: 27
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "2d7b1d45ad1d08b2"
---

<!-- page 1 -->

भारत सरकार
GOVERNMENT OF INDIA

एस.जी.-एल.डी.-अ.-15102026-1840
xxxGIDHxxx
SG-LD-E-15102026-1840
xxxGIDExxx

असाधारण

EXTRAORDINARY

प्राधिकार से प्रकाशित
PUBLISHED BY AUTHORITY

लद्दाख, 15 अक्टूबर, 2026
LADAKH, THURSDAY, OCTOBER, 15, 2026

Part II - Section 3

केन्द्र-शासित प्रदे श लद्दाख प्रशािन
ADMINISTRATION OF UNION TERRITORY OF LADAK

Order No: 62 of RD&PR of 2026
Dated: 09.09.2026
Subject: Publication of notification regarding revised list of ROs/AROs for Panchayat
Halqas.
Apropos to the subject quoted above, the revised list of Returning Officers (ROs) and
Assistant Returning Officers (AROs) is hereby published for the information of the general
public of the Union Territory of Ladakh.
The notification is enclosed herewith.

<!-- page 2 -->

Sd/Nidhi Malik, IAS,
Administrative Secretary
RD&PR
UT Ladakh
File No: M/2578/2024-RD&PR SECTION
Copy to the:
1. Chief Secretary, UT Ladakh.
2. Secretary, Election Commission for UTs.
3. Director Rural Development & Panchayati Raj, UT Ladakh.

<!-- page 3 -->

<!-- page 4 -->

<!-- page 5 -->

<!-- page 6 -->

<!-- page 7 -->

<!-- page 8 -->

<!-- page 9 -->

<!-- page 10 -->

<!-- page 11 -->

<!-- page 12 -->

<!-- page 13 -->

<!-- page 14 -->

<!-- page 15 -->

<!-- page 16 -->

<!-- page 17 -->

<!-- page 18 -->

<!-- page 19 -->

<!-- page 20 -->

<!-- page 21 -->

<!-- page 22 -->

<!-- page 23 -->

<!-- page 24 -->

<!-- page 25 -->

<!-- page 26 -->

<!-- page 27 -->

“No legal responsibility is accepted for the contents of publication of advertisements/publications in this part of The
Ladakh Gazette. Persons notifying the advertisements/public notices will remain solely responsible for the legal
consequences and also for any other misrepresentation etc.”

P T RUDRA
GOUD

Digitally signed by
P T RUDRA GOUD
Date: 2026.10.15
15:06:43 +05'30'

NIDHI
MALIK

Digitally signed
by NIDHI MALIK
Date: 2026.10.15
14:58:51 +05'30'
