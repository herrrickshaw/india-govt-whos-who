---
doc_id: "7d9ba2ce3e2acec7"
source_url: "https://ehrmsladakh.in/files/guidelines.pdf"
ministry: "Property Return System, Ladakh"
title: "Guidelines"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e529a19333397a75"
---

<!-- page 1 -->

Steps to File Your IPR.
1. Visit https://ehrmsladakh.in/
2. Click on the Login Button.

3. Click on Employee

<!-- page 2 -->

4. Enter your phone number followed by your password or OTP.

5. Click on Submit Your IPR

<!-- page 3 -->

6. Fill your Immovable Property First

7. If you have multiple properties, Click on Save and add more; if you
want to move to the movable property, click Save and Next.

8. Make sure you review your filed property again before submitting
it. Once submitted, you cannot make any changes.

<!-- page 4 -->

9. You will see submitted once you have submitted your IPR.

10.

Click on IPR Filed to see all your filed IPRs.

<!-- page 5 -->
