---
doc_id: "aca4fb1aba5d19bb"
source_url: "https://dme.assam.gov.in/sites/default/files/swf_utility_folder/departments/dme_lipl_in_oid_8/latest/engagement_order_-_dme_sr_positing-may-2026_suppl.pdf"
ministry: "Directorate of Medical Education, Assam"
title: "Engagement Order - DME SR Positing-May-2026 (Suppl)"
date: ""
pages: 2
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "0c91b5e5a9125c46"
---

<!-- page 1 -->

ৰ
Bi
৪০5
GOVERNMENTOFASSAM
OFFICEOFTHEDIRECTOROFMEDICALEDUCATION, ASSAM SIX
MILE, KHANAPARA, GUWAHATI-22
WEBSITE:HTTPS://DME.ASSAM.GOV.IN/,£-mail:dmeassam@gmail.com
শী 7 লা
No.DME/720886/29 Dated:- Guwahati 2"?June, 2026
ORDER
As per the Medical Colleges of Assam (Regulation of Admission in to Post Graduate
Degree and Diploma Courses) (Amendment) Rules, 2024 and in purusuance of the
counselling held on 30" May, 2026, the following Doctors who passed their Post-Graduate
Courses under SSUHS (Result declared on 10", March, 2026), are hereby posted as Senior
Residents (SR) in various Department of Medical Colleges / Institutes / Office of DME, Assam
under this Directorate for a period of One Year w.e.f. the date of joining as follows:
ca Name Subject Place of engagement
1 | DR.PURBANIL ৰ M.D.(Anaesthesiology) | DMC&H, Diphu
= BARUAH : . চহ a. ||
2 | DR.ABIRDAS M.D.(General Medicine) | NUC&H, Nagaon
3 | DR.VIVEK GUPTA | M.D.(General Medicine) | KMC&H, Kokrajhar
4 | DR.HARSHAJYOTI M.D.(Pathology) | LMC&H, North Lakhimpur
DAS
5 |DR.MALEMKHOMBI __| M.D.(Pathology) "| DMC&H, Dhubri ১
__| LOUKRAKPAM ঃ টি
6 1101.101521২17/01/ M.D.(Pharmacology) DMC&H, Diphu
| 7 DRARITRAGUPTA | M.D.(Pharmacology) —) DMC&H, Dhubri
8 | DR.ATULKUMARRAI M.S.(General Surgery) SMC&H, Silchar
9 |DRBIPULRABHA | M.S.(General Surgery). | DMC&H, Dhubri
40 7
The selected candidates shall accordingly report to the respective Principal cum
Chief Superintendents of Medical Colleges of Assam within 6 June, 2026 positively. The
monthly remuneration will be Rs. 75,000/- per month from the date of joining for a period of
one year.
\
We
য় of Medical ওঁ), Assam
il

<!-- page 2 -->

০:
ecw
GOVERNMENTOFASSAM
OFFICEOFTHEDIRECTOROFMEDICALEDUCATION,ASSAM SIX
MILE, KHANAPARA, GUWAHATI-22
WEBSITE: HTTPS://DME.ASSAM.GOV.IN/,E-mail:dmeassam@gmail.com
Ae EEE ee ee eS.
No.DME/720886/29-A DatedGuwahati2™June, 2026
Copy for kind information/necessary action to:
1. TheCommissioner&Secretarytothe Govt.ofAssam,MedicalEducationandResearch
Department, Dispur, Guwahati-6
2. The Mission Director, National Health Mission, Assam
3. The Executive Director, National Health Mission, Assam.
4. The Principal cum Chief Superintendent, SMC&H, Silchar / DMC&H, Diphu /
DMC&H, Dhubri / LMC&H, North Lakhimpur / NUC&H, Nagaon / NMC&H, Nalbari.
They are requested to intimate this Directorate about joining status of the aforesaid
Post PG SRs along with fund requirement for payment of their remuneration.
5. Official Websites of DME, Assam and National Health Mission, Assam to upload the
order in the websites.
৮)
Director of Medical হি rasa
oe
2
