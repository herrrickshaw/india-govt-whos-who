---
doc_id: "41aaae2cf6f5eb45"
source_url: "https://finance.assam.gov.in/sites/default/files/swf1/dms73_notification_for_additional_charge_of_ao_and_aao.pdf"
ministry: "Finance Department, Assam"
title: "Additional Charge of Accounts Officer and Assistant Accounts Officer"
date: ""
pages: 4
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "c685c55292a3630a"
---

<!-- page 1 -->

FD-21/170/2025-ESTT_B-FIN-Finance Department

I/1707124/2026

GOVERNMENT OF ASSAM
FINANCE (ESTABLISHMENT-B) DEPARTMENT
DISPUR::GUWAHATI-06
ORDERS BY THE GOVERNOR
NOTIFICATION
Dated Dispur the19-08-2026
No. FEB. 645598/92: In the interest of public service, the following
oﬃcers are hereby allowed to hold the additional charge of the post of
Accounts Oﬃcer (AO)/Assistant Accounts Oﬃcer in the oﬃces shown
against their names below till posting of regular Accounts Oﬃcer/Deputy
Accounts Oﬃcer/Assistant Accounts Oﬃcer in addition to their normal
duties with immediate effect, unless otherwise specified below.
of
Division/Oﬃce of
Sl Oﬃcer
Name
and Name
No Substantive place of posting Additional charge of Accounts
Officer/As s i s t a n t Accounts
Officer
1 Shri
Dip
Kamal
Goswami, Additional charge of Accounts
Accounts
Oﬃcer,
O/o
the Oﬃcer in O/o the Executive
Executive
Engineer, Karimganj Engineer, PWRD, Karimganj North
District
Territorial
Building & South Territorial Road Division.
Division, Karimganj.
2

Shri Rajesh Saikia, Accounts Additional charge of Accounts
Oﬃcer,
O/o
the
Executive Oﬃcer in O/o the Executive
Engineer, PHE Division, North Engineer, W.R. Mechnical Division
Lakhimpur.
Lakhimpur w.e.f 01/09/2026.
Shri Biswajit Sarma, Assistant Additional

3

Accounts
Oﬃcer,
O/o
the Accounts
Executive
Engineer, Nalbari Executive
District
Territorial
Building Nalbari
Division.
Nalbari.

charge

of Assistant

Oﬃcer in O/o the
Engineer, BarkhetriDivision
(Irrigation),

4

Smti.
Shahnaz
Parveen, Additional
charge
of Assistant
Assistant Accounts Oﬃcer, O/o Accounts Oﬃcer in O/o the Director
the Executive Engineer, Inland of Economics and Statistics, Assam.
Water Transport Division, Ulubari Jawaharnagar, Beltola.
.

5

Shri Rupjyoti Sarma, Assistant Additional
charge
of Assistant
Accounts
Oﬃcer,
O/o
the Accounts Oﬃcer in O/o the

<!-- page 2 -->

FD-21/170/2025-ESTT_B-FIN-Finance Department

Executive
Engineer, Nalbari Executive
Engineer, PHE
District
Territorial
Road Division, Belsor.
Divisions, Nalbari.

I/1707124/2026

Belsor

6

Shri Bhaskar Jyoti Dihingia, Additional
charge
of Assistant
Assistant Accounts Oﬃcer, O/o Accounts Oﬃcer in O/o the
the Executive Engineer, Water Executive Engineer, PHE Dhemaji
Resource, Dhemaji.
Division, Dhemaji.

7

Smti. Baishali Bedi Sarma, Additional
charge
of Assistant
Assistant Accounts Oﬃcer, O/o Accounts Oﬃcer in O/o the
the
Executive
Engineer, Executive Engineer, Soil Research
Mech.W.R(FC), Basistha, Beltola. Division-1, Basistha.

8

Smti. Manisha Priyam Goswami, Additional
charge
of Assistant
Assistant Accounts Oﬃcer, O/o Accounts Oﬃcer in t h e O/o the
the Executive Engineer, PWD NH Executive Engineer Inland Water
Division, Jorhat.
Transport Division, Jorhat.

9

Additional charge of Accounts
Shri Chinmoy Hazarika, Accounts
Oﬃcer in O/o the Executive
O ﬃ c e r , O/o the Director of
E n g i n e e r , Dimoria,
Irrigation
Sericulture, Khanapara.
Sonapur Division w.e.f. 01/09/2026.

Smti Archana Barman, Accounts
Additional charge of Accounts
Oﬃcer,
O/o
the
Executive
Oﬃcer
in
O/o
the
General
10 Engineer,
East
Guwahati
Manager, DICC, Kamrup (Metro),
Territorial
Road
Division,
Bamunimaidan.
Guwahati.
Shri
Pradip
Ch.
Barman,
Additional charge of Accounts
Accounts
Oﬃcer,
O/o
the
Oﬃcer in O/o the Executive
11 Executive Engineer, Hojai District
E n g i n e e r Umrangshu PHE and
Territorial
Building
Division,
Umrangshu NEC Division.
Hojai.
Additional charge of Accounts
Shri Tarun Ch. Daimari , Accounts
Oﬃcer in O/o the Executive
Oﬃcer,
O/o
the
Executive
12
Engineer,
Champamati
Pro.
Engineer, PHE NO.II, Kokrajhar,
Division (Irrigation) , Garubhasa,
PO-Basugaon, Chirang.
Kokrajhar.
Shri Rajesh Kr. Nazir, Accounts Additional charge of Accounts
Oﬃcer,
O/o
the
Executive Oﬃcer
in
O/o
the Executive
13 E n g i n e e r , Dhubri-Golakganj- Engineer, Bilasipara-Birsing Jarua
Gauripur Division (Irrigation),

<!-- page 3 -->

FD-21/170/2025-ESTT_B-FIN-Finance Department

Dhubri.

I/1707124/2026

Division (Irrigation), Bilasipara.

Additional charge of Assistant
Shri Roktim Gogoi, Assistant
Accounts Oﬃcer in O/o the
Accounts
Oﬃcer,
O/o
the
14
Executive
Engineer, PWRD,
Executive
Engineer, Bokakhat
Bokakhat & Dergaon Territorial
PHE.
Road Division, Bokakhat.
Shri
Mitul
Boro,
Assistant Additional
charge
of Assistant
Accounts
Oﬃcer,
O/o
the Accounts Oﬃcer in O/o the
15 Executive Engineer, PHE Division Executive Engineer, PWRD, Silchar
NO.1, Cachar.
& Udharbond Territorial Road
Division.
Shri Chayaban Deori, Assistant Additional
charge
of Assistant
Accounts
Oﬃcer,
O/o
the Accounts Oﬃcer in O/o the
16 Executive Engineer, Naharkatia Executive
Engineer, Duliajan
& Duliajan Territorial Building Naharkatia & Territorial Road
Division, Dibrugarh.
Division, Naharkatia, Dibrugarh.
Shri Dipendra Chetry, Assistant
Accounts
Oﬃcer,
O/o
the Additional charge of Assistant
Executive
Engineer, Tinsukia- Accounts Oﬃcer in the O/o the
17
Makum-Division
(Irrigation), Executive
Engineer, DigboiTinsukia.
Margherita Division (Irrigation).

Deputy Secretary to the Govt. of Assam,
Finance (Establishment-B) Department.
Memo No. FEB. 645598/92- A
Dated Dispur the 19-08-2026
Copy for kind information and necessary action to:1. The P.S. to Hon’ble Minister, Finance etc. Department for kind

information.
2. P.S. to Sr. most Secretary, Finance Department for kind information.
3. The Executive Engineer…………..
4. The concerned Office...........
5. The Treasury Officer……….
6. The concerned Accounts Officer/Deputy Accounts Officer/Assistant
Accounts Officer for information and necessary action.

<!-- page 4 -->

FD-21/170/2025-ESTT_B-FIN-Finance Department

I/1707124/2026

7. The Content Manager for uploading the same in the Govt. website.

By orders etc.,
e-signed
Deputy Secretary to the Govt. of Assam,
Finance (Estt.-B) Department
