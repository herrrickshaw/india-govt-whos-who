---
doc_id: "ccb7f6bc8d98b97a"
source_url: "https://excise.assam.gov.in/sites/default/files/swf1/dms42_assam_excise_service_rules_1990.pdf"
ministry: "Excise Department, Assam"
title: "Assam Excise Service Rules 1990"
date: ""
pages: 14
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "a90cee9f6ae672b8"
---

<!-- page 1 -->

| ৮ ্ ৷ | ৷
| ce ao pea
1: ন : ৷
14; | বই |
ত j “8 PAR NA] THE assam GAZETTE | JULY 13,1990 565 /
| ২ এ শীত ASSAM Gazr 3 115:1990.:565
1০ The 19th April 1990 1
॥ | {
| No. EX. 86/64/90.—1n exercise of the powers conferred ]
| by the proviso to ‘Article 309 of the Constitution of India !
: } the Governor of Assam ig pleased to make the following |
ত | 0168 regulating the Tectuitment and — the conditions of ৷
৷ Service of persons appointed to the Assam Excise Service, |
i
| 1. Short Title and Commencement.—(1) These . rules |
| "ay be called the Assam Excise Service Rules, . 1990. |
| (2) They shall take effect from the .date of their ৷
/ Notification: চু
ত |
| কা ;, 2, 09610110751) these ‘rules, unless the:context other- |
wise: requires, — : |
I : ত 08) “Appointing Authority” means 006 “Governor of |
A Assam; "
/
,. (b) “Commission” means’ the Assam Public. Seryice
ৰা Cemmission টু - oe
ত (2) “Committee? means the Selection 01071771665 cons-
৷ (14০৫. ৫৩71২015193 ৰ
। ৰ i ৰ {
৷ “3 Ad) “Government” means. the State Government of |
Assam ‘3, |
| |
: (e) “Governor” means the Governor of Assam ; | ৷
ঢ়) [যচ Of the Service” means -a member of the |
থাম, +.%256. 3209106 3 গু ৬1
১ (8). 59190 List” means the list. 'preparea under |
ঙ (9) of sub-rule (1), of Rute 6: and clauses (a) and | |
6). Gi) of sub-rule (6) of Rule 18; |
| (h) “Schedule” means the schedule appended to these | ৷
rules. ; |
ৰ ্ | |
8812) “Service” means the Assam - Excise Service ; | ]
1 ৰ ] {
109 ওল means a calendar year ; on | |
এ তু ৷ | Rika |
; ee Ue |
i : oe | |

<!-- page 2 -->

: ‘ i 1
1566. এছ 25৪ 0.27 JULY 11, 1990 [PART 118, ON
1 = ea es পে লস ৷
: ৷ 3. Class and Cadre,—The Service shall consist of the |
following classes and cadres :— i
,  @ Class TF; shall: include the cadres of— 4
+ @) Joint Commissioner of Excise ০ ee 3
(ii) Deputy Commissioner of Excise. | 1 ৷
(8) 01888 ][.-]{ shall include the cadres of— ৰ i
ন ৫) Superintendent Of Excise ; :
Gi) Deputy Superintendent of Excise; ...’ ‘
es (iti) Inspector of Excise. ৰ ব্‌
1 * 4. Strength. of Service. —The strength ,0f. each cadre in
a iClass .of the Service Shall “be: such: ‘as determined: by the 5
Governor from time to time: The strength of ‘the cadre,
. OF the: Service on the: date of commencement of these i
Tules shall’ be as: shown;, in Scheduler I, 3... 7 বব
তু টি Method of Recruitment.--Recruitniént’ to the Service
' shall’ be made. in the manner Prescribed hereinafter:—.
© (1) Recruitment tothe cadre of Joint 00107185078
{ 5 Bade gaegrmmisioner and. Depury, TQet Commis of i
; _ Excise’ shal] be. made “bY promotion only. 7 ৰ vere :
| (2) Recruitment’ to the cadre of Superintendent of
1 Excise shall be made,—=" Jig . রঃ
i ~ (a) by direct recruitment “against 50, percent Of. ‘the i
| : Strength of the cadre ‘to’ the Gommission : and
: (b) by promotion in accordance with Rules Il and 12 ,
ডি against the balance 50: percent of ‘the strength of the oe
i. €adre of Superintendent of Excise from the cadre
চু of Deputy Superintendent of Excise. :
NOTE :~ If at any. time, cadre strength of ‘Superintendent : ;
Of Excise comes’ to a. position that there remains
4 : a balance: after dividing: the ‘tota} strength by two ত
এ “the said post shall: be filled up by Promotion: and
“direct Tecruitment, alternatively. a :
ঢ়) Recruitment to the-cadre of Inspector. of ‘Excise
‘shall he Made,— : এম

<!-- page 3 -->

1 |
by 8 ৰ }
ee oo গু র্
Bef <. it Wh ৰ
টা PART NAY. THE Assam GAZETTE JULY 111; 1990 567 |
রা Se a
: : (8); by direct recruitment against 56 ercent of the
Strenght of the cadre through the 0:11.
me হই হি ৰ
| (6) by Promotion in accordance with Rules 1] and 12
.  ABalnst 334. percent of the strenfth of the cadre from the
ee cadre: of “Assistant Inspector of Excise of the Assam Su- :
11 001018819108018৩. 99751052510 completed 10 99819 :০০2- (
i tinuous Service as Assistant Inspector on the’ first. day
{; ০ of the year in which promotion js considered; 1
fi 20৫ ]
Ri ন: |
i (¢) by. promotion in accordance with Rules 11 and 12. i
i against 10 percent of the strength of the cadre from the i
if cadre: of Upper Division Assistant of the office’ ‘of the ।
ৰ্‌ Commissioner. of Excise, Deputy. Gommissioner of: Excise :
{ and, Chemical Examiner .of Excise who. have: tendered me- 1
| * ritorious service for‘a minimum period. of 12 years as Assis- 4
_ / tant g@nd out of this period at least’ one year as. Upper টা
Division Assistant and, must have not’ crossed 45 years 1
of. age, on).the Ist day of January. of the year in which ]
| চা, considered,’ টি ৰি ৰ : i
i Be এ টু : a4
৷ & Direct Recruitment: (1) Subject to sub:rule (2) and
i sub-rule (3) of Rule 5, direct recruitment to the cadre of
] Superintendent of . Excise and Inspector: of Excise shall be: .
i made by. the Governor..on the basis, of recommendation
৷ 1809021,09 the Commission’ in accordance with the proce- ছা
i dure: hereinafter: provided :— 5 ii
| ; ৷ es 82 ৷
৷ _ (8) Before the end of each year the Appointing Au- ;
I thority, shall: make an assesoment: tegarding the likely num- rad
৷ ber of vacancies to be filled up by direct recruitment
৷ during the next year aut shall intimate the samé to. the '
i Commission together with the. details about reservation for |
৷ candidates, belonging to Scheduled Castes, Sckeduled Tri- 1
A bes Of argvother category as laid down, by fle Govern: i 11
৷ ment Yas provided under. Rule 15. and about carry forward ন |
৷ of sugh উপ 5 র on
৷ ', টু i
j 0 the Appeinting Authority shall _ simlutanccusly |
request the Commission. to. recommend a list cf candida- ৰ fia
1 tes fof direct recruitment in order of prefereace 3 1
[ i : i : es
৷ (8). 12 শঠা 15107, [121], 1162ত ৩1666, 0}; ৪০০০) ২, ৷
॥ 02505) আচ 01950210901 59190110 265011604 ৮: 075090৮753৭ এ os i
| 31153: , eS ea
i ees 8 77)
he ন 22528 ৷
1 : } নিমি ন Eee eae
a 1 ৷
লে t |
৷ 1 4 a
1৮ ie

<!-- page 4 -->

হর 5 ৰ ঢ়, ৰ: |
= ৰম 14459901৮0২ যা |
: y Dment” The Commission May *helq SUCH test <p it terview
i: + and undertake Scrutiny of 1688.67 articles, if any; tubs
oe (3+ lished by the candidates and other Certificates 24101480011.
টে Ments, ag May be Considereg Necessary, টু
| (d) The 9০701715507 Shall; furnish tothe Al rointing
Boy Authority a let Of candidates, Teccmmer, ded by jx. T (14007.
pik of Preference, found Suitable for dire ot 35010117771, The
# Number of “andidateg in Such. a list May be 4p brexima-
; . tely double the number of vacandigs.
¢ (©). The Commission shal] simultanec sly Publish th ¢ ‘
টি list in’ the Assam Gaze tte ang At Such othe» Placcs-as the না
8 Commissic n may. consider Prcper, রর রা
(2) The list Mentioned in clauses (৭) ২006) ০ ৬৮৮৮ :
2 C1) of “this Tule’ shall remain valid for 12 calendar months
ত from the date. of Tecommenda tion. ane ;
ৰ (3) In the’ evant OF ithe 07550 being Unable to
ay recommend sufficient “Dumber gf 68100102165 to 21]
“up all the Vacancies jn ৪.24 "3 Shall’ এ con-
a Sultation with the Appoiniing ’ Authority, 7680.21
: the Procedure: #8" Mentioned here 81010541675
| under SUb-ruje ৫0) OF this 2016, for; técommending a SUbse-
ৰ: Ment ist for “the Year: *
i Provided that the APpointing Authority Shall not make ৷
80019110050 of any. candidate from. the subsequent iste: 2 3
1: 081. aT, the candidates “of ‘the earlier lise of. he same yea, i
হে দু eligible for 4PPolntment have been’ offered: the appointment, ৷
ত চু 4
টু 50.ান7097831খ “FOR DIRECT “RECRU“?, vENT ৷
ate Aires he Candidate fo, direct recruitment ‘to: the ‘ser. i
Vice must have attained. the age 20, and not attained ‘the: 1:11
85০90 On the Ist January Of ‘the Year of ieoritinent eee
With Felaxation jn the: cases sof candidates 7708 to
x3 Special ‘Categories like Scheduled Castes, Scheduled tribes
"/ And, ag Other fategory. any laid re the Goverament in
789০0৫87705 With ‘the Ordérs: of the 0৮951171901 27::00106
-101:77)6 time being, he tate ee =
তে 8. গুণা, ৫80,009, Thy academic Walification ৰ
© ofa candidate fo, direct Tecruitment Shall’ be a8 prescribed ৷
ন |
ঞ f এ 1.1
৷ a
i It fac
ৰ

<!-- page 5 -->

| ই ৷ :
bY ae
= 7 দস NA) THE ASSAM GAZETTE: JULY.11, 1990569 |
| গু pe সু চু লব a eae pe ar vege ra i
ৰ by. thé Governor from time to: time. The ‘qualifications i |
| and exprietice prescribed ‘as’ on: the date of commencement ত |
~~.» ofthe rules: are given in 79019001৩-া- ৰ |
ৰি তা i |
: poe : |
i 9. Physical’ fitness:—A candidate for direct recruitment |
shall! be — = |
3) পু নবী ~ +
a (1) of sound health, both mentally and physically, |
# and flee ffom- organic. defect or bodily infirmity likely to
2 _interfere’ with the efficient teif¢imerce <f bis dutics ; and |
/ ম ন bee
| 1." (2)"1600]760. 00: 001007890 medical ৪771] 9807) ॥1)61616 ৷
৷ . appoifitment to the. service, : 7
: 16. Character.—A candidate fcr direct: recruitment. slall |
x produce to the Commissicn certificates ¢f goc.d character from:-
ৰ ৷ (a) ‘the Principal. Academic Officer of the University
“ or College.:in which he studied lasts and 7
০
২000) 480 19506921016 005০151:0 976 well: acquainted
: with: but, not related to the candidate. : |
‘ eae i
ন ঠা Promotion.—(1) Vacancies in the cadres: of Joint Co- : |
+ mimigsioner, Deputy Commissicncr and Deputy Superintén- পে:
dent: cf Excise end in’ the cadres of Superintendent and
Inspectcr .of Exercise . respectively ‘of the Service ‘to the A
exten? .as/'spécified in sub-rules (1) and 2(b) and. sub-rules ae ৷
3(b) tand 3(c) cf “Rule 5 shall “be filled.up by fromotion |
in ‘the manner prescribed — herein below: |
ৰ টা | ৷
i) (2). Subject. to suitability. «s_imay- be decided by the* ৮
Committee and, by the “Appcinting. Anthority or -the Co- q
minigsion as the case may be, and also. ‘subject’ to po-
-ssessing qualificaticns and. experiences as prescribed herein.
after;;a member of the «service shall be eligible: fer pro- ৮ :
motion from one cadre.to next. higher. cadre-of the: Service ]
in the mapner provided below :— ee \ ৷
' (0) টো] Deputy Commissioner ‘ to Joint Commi- |
oe y+ ssioner of Excise. : 4
"| Gi) From: Superintendent to Deputy Commissioner’ in = i
Bo of Excise ন me i
ৰ ec ihe
1 Pee
iG ee : ১
৷
র

<!-- page 6 -->

1
র 570 টান ASSAM GAZETTE. -. JULY J, 1.990 [PART _IIA.,
(ii) Form Deputy Superintende nt to Superintine,
nt of Excise,
i ঃ (iv) From Tnspector 10 Deputy Superintendent ©
১ Excise, না
ed ~ ন
“a (৮) From Assistant Inspector Of Excise. ang from
। Urper. Division Assistant te the renk-cf Inez e-
3 be Stor. of Excise ‘as Provided in Vb-Tile ও (b)
1 and 3c) of 1২৪1৩ 5. :
রর 3) 90719১10 Suitability, a membcr of the SEr Vice.
} ' wo Shay be“ cligible for Promotion: if pe 96550866506
| ৰ qualifications ang ©xperience as set forth below 1.
"| : " (a) For Promotion to the cadre of Joint Commissioner,
uf a member of the Service must. have completed 7 (Seven) years
| হই as Deputy Commissioner of Excise or in ny equivalent post
pe on deputation on the first day cf January of the year in
৷ which the Promc tion ‘js considered,
|| rr ৰ (9) For Promotion. to the ০৪01০ of Deputy Commissi-
7 গু এ ০0800, ৪8 member of the Service si must have completed 8
hi এ (2180) Years “as Superintendent of Excise ow the first day
i of January of the year in which the Promotion js considered, .
1 টি
Il : রে 3
| : (০) For Promotion. to the cadre \ of ‘Superintendent “of
i ; Excise, a member Cf the Service. must have Completed Tone) =
৷ “year of continuous: S€IVice as _ Deputy Superintendent of
। : “EXcisé on Ist day of January, of. the year in, which. the [0195
| > Motion, is considered, ; :
| ৰ (d) For Promotion to the cadre of Deputy. ‘Superinten-
| dent of Excise, a. Member of ‘the Service. must ‘be Confirmed.
টি and must have completed 5 (five): ‘years as Thspector ‘of
Excise on. the Ist 085:0? January ‘of the yeat in’ which the
Promotion js Considered. x
1.4৮". 2) 16 Promotion to the cadre ‘of Inspector of Excise,
= a candidate ‘has. to fulfil. the requirements 9৪ 1214 down. in
ub-rule 3(b) oF 3(¢) oF tule 9 of these rules.
: i নু = ৰব
+ a + নু পা রি ~ — te ok হট ০

<!-- page 7 -->

চু "জা ag টু a : ন ঢ় a
de ৰ ৰ f a ae : Ds
৷, ৷ oe 7 ডি
be fy ৰ :
k রা PART TAT THE ASSAM GAZETTE. JULY: 11, 1990 571 :
rs 12. General procedure of promotion. (Y=Béfore the end’ |
৷ | of each. year the Government chall make jan. assessment’ of ৰ ৰি
8 18; ely Dumber. Of vacancies to be’ filled up-by promot *
[| 10[0}.1]}, 8016.7630, 5688 1} .68০]) ৫৪016. : নু
ও eee Se 2 : 4
এ (2) The Appointing Atithority. shall then ‘furnish’ to the ৰ
yo Committee the’ following: documents.and: information with
| ৷ Tegard to .as many? offiders in. order ‘of Seniority as. four 1
৷ হু times the number ‘of vacancies, as assessed...’ under: sub- ” s
pa rule (1) :— :
4 | ৰ ৰ, 2 i
a (a) information , about the number: of vacancies a ঃ i
ae ৰ ; is
a ( ৰ eer es fh
ce (b). list of officers in order of seniority. eligible . for ৷
| promotion (separate' ‘list: for promotion to different cadres |; |! )
Ma shall be furnished) indicating’ the. cadre to-which the case i
| of promotion is to. be:considered: ~ 1.
৷ (c) character rolls and . personal - files of. the officers Bee
রী. ‘listed ; Oe 42 ৷
a 55 ঃ ৷
4 (d) details abotit reservation in. case of promotion..of i
the -service and about catry forward vacancies 3. 5 ৰ ৷
৷ , (e) any. বে and information 89 118) - ১৩ ৷
A considered necessary by the Appointing Authovity,or required চু |;
= by, the ‘Gomithities: § ci cig (yes oe asain ah Bee 7
টী; _ © (8) ‘The Appointing Authority shall simultaneously te- oe ৷
ছু quest. the. Committee to fecommend - within one-month a H
Bi. list of officers found. suitable for promotion in order of My
faa preference in: respect’of promotion “toéach« of: ‘the cadres’ i
he am which recruitment ‘is to be made by: promotion. ৰ 1
MESS) The selection shall ‘be madeon ‘the basis of eerie ‘|
ৰ ‘with due 02990, 101 58160, in: case of promotions stated ৰ্‌
hereinbefore’ under.) ub-rule(3). 01016 11. ce
| east 8885 1.
Hous aes eed
6) The Comnijittee, after examination. of: ‘the :
documents ana ihformation: furnished, by ‘the Appoint: ৷ |
ing Authority shall Feqommend to. . the _ Appomting MS
Authority: a list § of ‘officers. about the double 4
৮1 ৰ ; ৮
টি
টু টা |
4 =~ রি |
: হি |
গু ন ৰ ৰ : 45825 6
ৰ at

<!-- page 8 -->

পির ও
| =
| ; :
| ; 572 ‘THE SSSAM Gazerry JULY 1, 1990 [PART IIA,
the number. cf Probable Vacancies - jn order... of Prefe.
: | 167.668, 16000 Suitable. fo, Promotion. 12 Case the Ccmmj-
: tee does rot Consider. an ¢ fligcr Suitable ic 17611706072
According to SeMorjty® ip shal] রা leasons therecy
| ; in Writing ang Jorward these Wacons to. tho: Appointing
৷ ত Authority together with. tie 195
i 172 (6) The Appointing Authority On Yeceipt. of the. lists
| Tecommended by ‘the Committe. shall; ~ -
ঢ় এ (a) Consider the list Prepared: for Promotion (6 the i
{ Cadres of Joint Conimissicney and Deputy €omm|- 1
j ' ssioner {1 Excige by the Commitye along with, |
i 5 character Tolls and” pezsc nal files ‘of the €mployecs i
i ; ৰ: . 0. ৪0795 076 11570111983 it considers any change ৷
i necessary, If the (72876 4027) Considers ৷
ৰ it 1256-8890), to. make any cl ange in the list 76061. ৷
৷ ৰু ved from the Committce, he “shaty: inform: the i
y ? Commitise of the ch 8NZes Proposed ard after taking ৷৷
৷ ৰ into account the comments, jj any, tic Appointing ৷
] re Authority slay “ak prove -the list finally such Modi- i
৷ fication, if ‘any, as may, in ‘jig CPinion, ‘be just |
| : ‘and Proper, নে ৷
ত ন : hos ৷
| Pa 2 (by tts forward the list Prepares by Committee for ৷
১ রি Plomotion. to the cadres: of subetintendent, Desiey eee
{ 0 Superinicudent and Insnectay Ot Excise 4g the: ৷
{ ; 5p “Commission. together With “the Jnfor mation 2010. ৰ
1 ৰ রর i নি documents as rcferred 6:47. “sub-rule (2)of ২7110
| ; 12 with £ Tequest to approve “the Tist: “tl
! ৰ Ui) The Commission shalt: Consider the রা: |,
৷ : bs mmended by the Committee tOgether with infor- if
f ? Mation . and documients and such ctkey documents cat
] and luformation, as may’ pe. required by the Corn: 08:85]
{ ৰ mission and obtaineg from the Appointing Authority), ৷
i 2338 The Cominission sHall apPrOvE the list with ‘such ৷
/ ) modifications, as it COnsider just and: proper, ৷;
; ?
{ (7)'-The list 50 aPProved * py the Commission shall '
i form ‘the select list for the Purpose of aPpointment by £
{ Promotion, ৬ ety i
i ‘ ig চু
{ ৯16) The Promotion shall, be made from the Select list ৷
i it order of Pteference: 2 Y i
1 ৰ | ৷
{ ৰ ন
ৰত ৰ = ৰ ত এ বি 252 ৷
টা ৰ: ঠা? ৯: ০৯০১৯, Se ae = ১৪. ঃ a AN ও

<!-- page 9 -->

ৰ ৰ ন bs ৰ ৰ জি a
3 ৰ 4 ৰ
ঃ gag a 2 <
চি / PART MAJ THE ASSAM GAZETTE 704৮1 1990 573
bey: : ২ .
চি... 13295152৮07 Cotmmittees. For the ‘purpose -of- prc mo-
: j _ tion of a member cf the Service. from. one cadre ‘tothe
J next. higher cadre, there shall’ be. Selection Cominittees, :
[65] ccnsisting of the Following. Ahembers. :— i
ৰ (i) For considering  préthotion to the post of Joint :
2 Commissioner fof Excise. 2 ৰ
(1) The Chief Secretary to the Govt. cf Assam—Chairman ৰ
j (2) Secretary, Personnel Department— Member.
i (3). Commissioner of Excise, Assam— Memter,.. -
1 (4). Secretary, Excisé Department— Member —Secy.
্ Me :
i (ii) For considering . promotion to the post cf Deputy
[ Commissioner,“ Superintendent, Deputy Superinten-
dent and Inssector of Excise.
+ ;
(1). Secretary, Excite Department— Chairman,
ই. ন র্‌ ne
(2) Secretary, Persofinel Department or his—~ ‘Member:
representative not below the rank cf the Deputy — ঃ তু
Secretary. gee 2 3
ত 177
‘(Gy Comm'ssioner of Excise, “Assam— -° ‘Memiber.
(4) Jcint Commissioner cf Excise, Assam— “Member.
(5) Deputy S¢cretary, Excise, Depart ment—Member-Secy.
ন oar as Ree
‘14. Disqualificationi—_q])_ No person shall be eligible
for eppointment to. tketService = 9 = ত
চি / ৰ ৰ
: . (2) Unless. he is a ditizen of India; and
ste ৷ ,
(by “f, he has meré. than: one wife living ot in: case
of. a female candidate Who had married a person who:kas
one wife: living ; রং ণ
ৰ
"00951060091 the Governor may if he js’ setisfied that.
there'are special ground: fordoing: so, exempt any persen |,
from the. operation of this. clause, ৰ
a a ন
৷, ;
: ৰ + ত ৰ

<!-- page 10 -->

574 “THR ASSAM GAZETTE Yo JULY. U1, 1990 arp ITA.
চু (2.০ Person. who attempts. to 11151 SUPPort _ for his
zt candidature directly ‘op indireetly _ by any Tecommendation
7 Cither Written or ‘oral. dy by any other Means ‘shaly be
x Pe aDpointed to the Service,
(1:১৭ TS, Reservation. —In all cases” of @ppOintment by direct
৷ > Tecruitment as Well ag by Promotion, there shall be Teser~
fo Vation in the: case of candidate “belonging to: the member 7
গু ‘so Of Scheduled Castes, Scheduled Tribes “ag Pet the provyj-
চু SION: Of the Assam Scheduled: Castes and! Scheduled Tribes
| Reservation of Vacancies in Services and Posts) Act, 1978
# *| andthe Tules frameq thereunder. There Shall also be
eee reservation 07 candidate belonging to. Other Backward i
রা Classes including More Other Backward Classes as Per ৷
{ ঃ Government instructions Contained jn OM. No. ABP. 3387
1 83114, dated: 4th January, 1984. for direct 15001071676, only,
|; General Orders in Tespect of MES? t vation. in favour of other
11] Categories of candidates, ‘as May: be:-in-forge fer the time
ky being: shay be followad..": 3 ৰ
| 4 ৰ?
৷ : 16. Appointment, ~1) Subject to. the Provisions of rule
171 15 and Sub-ryle ১2). this rule. appointment under rye
11 ১: € গাহা, be ‘made by ‘the Appointing. Authority 1D. accor. 2
pan “dance with the order Of preference ( determined: In the list i
+ : Teferred:to in Clause. (d). of sub-rule: (1), Of: Tule 6, : ৰ j
by ॥ (2); ]'6 iéclusion ofa candidate's name iN the list
1 ৬ Mentioned: jn clause’ (q) “og Subsrule (1) > of tule’ 6 ‘shall {
144 '_ 60016 RO right 10. appointment’ ‘unless the Appointing
ee » Authority’ js ‘satisfied after Suck enquiry as Prescribed by
ঠা > tHe. Government fom time {6 time ang. also 8 May be
= > Considered NECEssary 1]]8{ 2 ০8701010816 js 80102161081
af © Tespects for appointment to “the Sétvign: 5
17. Joining time: a: Persen shall join Within Usdays mS
from: the date of Teceipt..of the order “of apr Ointment or
OF promotion ‘failing which the aprejntment «fall be can- i
celled unless’ the Appeinting Autherity “xtends the: period ]
which Shall Not; in all, exceed three MOnt} s, a i
4 18. Training, 4 member of the Service shall be re.
Qitired: to Undergo such training ang Pass’ such departmen-
tal ‘examination ag the Government: may prescribe. >from
time to: time, ন : i
roa Sasa . রি পপ.
ify 877
