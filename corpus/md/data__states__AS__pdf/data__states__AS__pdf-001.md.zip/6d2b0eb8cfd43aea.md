---
doc_id: "6d2b0eb8cfd43aea"
source_url: "https://labourcommissioner.assam.gov.in/sites/default/files/public_utility/website_policy.pdf"
ministry: "Commissionerate of Labour, Assam"
title: "Content Contribution, Moderation & Approval Policy (CMAP)"
date: ""
pages: 3
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "8d8c79e474436899"
---

<!-- page 1 -->

t
£3
Content Contribution, Moderation & Approval Policy (CMAP)
Content needs to be contributed by the authorized Content Manager from Groups/ Divisions of General
Administration Department (GAD) in a consistent fashion to maintain uniformity and to bring in standardization
along with associated metadata and keywords as explained in the section 3.5 (Guidelines for Content Categories in
GAD-Website) of this document. In order to present the content as per the requirement of the viewer,
organize the content in categorized manner and to retrieve the relevant content efficiently, it is required to
contribute the content to the website through a Content Management System which would be web-based having
user-friendly interface.
The content on the portal goes through the entire life-cycle process of:-
জট 21772
৯1100115708 8727 58
টা a ee
> cModeration:: by Ube ae 71 Aa ee
ই PUBLISHING 98 eS Cs ee
21175775577
251816117551588-1555513541558151781555855558
Once the content is contributed it needs to be approved and moderated prior to being published on the Website.
The moderation could be multilevel and is role based. If the content is rejected at any level then it is reverted back to
the originator of the content for modification.
Different Content Element is categorized as: -
@ Routine
®@ Priority and
@ Express
(Approver and the moderator for each of the content element)
SIN Content Element Type of Content (এত A ররর
. No. oderator pprover ‘ontributor
লন] ৮৮] ভজন
1 About Department Vv Web Information Secretary Content Manager
Manager
2 Programme/ v Web Information Master Trainer | Content Manager
Schemes Manager 7
3 Policies v v Web Information Master Trainer | Content Manager
Manager
4 Acts/Rules v v Web Information | Master Trainer | Content Manager
. Manager
Circulars/ Vv v Web Information | Master Trainer | Content Manager
Notifications Manager
Documents/ v v | | Web Information Content Manager
Publications/ Reports Manager
7 Directories v Web Information Master Trainer | Content Manager
Manager
What's New v v v Web Information \Content Manager| Content Manager
7 Manager
Tenders v v Web Information | Master Trainer | Content Manager
Manager .
Highlight Vv v Web Information |Web Information| Content Manager
ডে Manager Manager
+ 41 Banners v Vv Web Information | Master Trainer | Content Manager
Manager
12 Photo-gallery v Web Information Master Trainer | Content Manager
Manager
Thank You,
Web Information Manager “Sa
General Administration Department
Shri Bubul Lekharu, ACS. . ] fe 6\
Joint Secretary to the Govt. of Assam,
General Administration Department
Contact: 9435159159 . Email: bubul.lekharu@gov.in

<!-- page 2 -->

লে
Content Review Policy (CRP
GAD Website is the face of General Administration Department of Government of Assam. It is therefore required to
keep the content on the Website current and up-to -date and hence there is a need for the Content Review Policy. Since
the scope of the content is huge, different Review Policies are defined for the diverse content elements.
The Review Policy is based on different type of content elements, its validity and relevance aS well as the archival policy.
The matrix below gives the Content Review Policy:
Content Element a y Approver
i "|
|_2 [about Department! Web Information Manager
2 Programme/ Vv Vv v Web Information Manager
Schemes
3 Policies Vv Vv টু
Web Information Manager Master Trainer
5 Circulars/ v Vv Vv Web Information Manager Master Trainer
Notifications
Documents/ v v v . ॥
Publications/ Web Information Manager Master Trainer
Reports
| 8 | What's New | ৬" | ৮৬ || Web Information Manager Content Manager
10 Highlights Vv Vv Web Information
Web Information Manager Manager
13 Group Wise Vv Vv Vv Web Information Manager Master Trainer
Contents
The entire website content would be reviewed for syntax checks once a week by the Website Team.
Thank You,
Web Information Manager
General Administration Department
Shri Bubul Lekharu, ACS.
Joint Secretary to the Govt. of Assam, ৩
General Administration Department ত \ পৰ
Contact: 9435159159 b \s
Email: bubul.lekharu@gov.in ৰ
=== ঁনঁনননললবিবশদশকশিশশস্্্ঁনকঁঅলঁলল(ৌ(৷ '- (ৰৌ ’ ’'} - ৮৮৯০০০০০০০৮

<!-- page 3 -->

(57
Content Archival Policy (CAP
Each of the content components is accompanied by Meta data, source and validity date. For some of the components the
validity date may not be known i.e., the content is stated to be perpetual. Under this scenario, the validity date should be
ten years hence. Under no circumstances, any content is to be displayed on the Website after the validity date.
For few of the components like announcements, tenders, only the live content whose validity date is after the current date
is shown on the Website. For other components like documents, schemes, services, forms, websites and contact directory
there is a need for timely review of the same as per the Content Review Policy.
List of content contributed is sent to the content contributor two weeks prior to the validity date to revalidate the content
and if required Omodify the validity date. In case of no response, then a reminder is sent a week before the validity date
and therefore the content is archived and no longer published on the Website.
For the retrieval of content which has expired, there is a need to archive the content.
Government Websites, Forms, Services and Contact Directory which are discontinued should be expunged. The content
Element on the Website has different Entry/Exit Policy and Archival Policy as enlisted below:-
Table- (Content Archival Policy)
Content Element Entry Policy | extrotey {|
4 About Department | Whenever Departments/ Ministries are merged/ Perpetual (10 years) since date of
changed. entry into archival.
2 Programme/ Discontinuation of Sanction of Programme/ Five (05) years since date of
Schemes Schemes for Central Sector, State Sector or both. discontinuation.
3 Policies Discontinuation of Policy by Government - Perpetual (10 years) since date of
Central/State entry into archival.
4 Acts/Rules Issued through the gazette/ Passed by the Perpetual (10 years) to be always
Central or State Government available in the acts/ rules database.
5 Circulars/ Overruling Office Memorandum or Notification Five (05) years since date of
Notifications issued. discontinuation.
Documents/ Completion of its validity period. Perpetual (10 years) since date of
Publications/ entry into archival.
Reports
Not required Not Applicable
What's New As soon as it loses relevance. Automatically after the expiry of the
validity period.
Tenders As soon as it loses relevance. Five (05) years since date of
discontinuation.
10 Highlight As soon as it loses relevance. Automatically after the expiry of the
validity period.
1 Banners As soon as it loses relevance. Automatically after the expiry of the
রা validity period.
12 Photo-gallery As soon as it loses relevance. Five (05) years since date of
discontinuation.
13 Group Wise As soon as it loses relevance. Five (05) years since date of
ত Contents discontinuation.
Thank You,
Web Information Manager ০ ৬
General Administration Department |
Shri Bubul Lekharu, ACS. 7 \ 6\
Joint Secretary to the Govt. of Assam, 6০
General Administration Department
Contact: 9435159159
Email: bubul.lekharu @gov.in ৮
