---
doc_id: "e9c6edb60fd048df"
source_url: "https://dohua.assam.gov.in/sites/default/files/swf1/dms88_Tender_Extention_Notice_Hire_Office_Related_Assets.pdf"
ministry: "Housing & Urban Affairs Department, Assam"
title: "Tender_Extention_Notice_Hire_Office_Related_Assets.pdf"
date: ""
pages: 1
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "d8f0385c38322bb7"
---

<!-- page 1 -->

ৰ
GOVERNMENT OF ASSAM
MISSION DIRECTOR :: PMAY, HFA (URBAN) :: ASSAM
DISPUR ::: GUWAHATI-6
Phone No.:0361-2235166 E-mail:pmayhfauassam@gmail.com Website: www.pmayuassam.in
No.MD?PMAY/PRO/16/2017 Dated: Dispur the 6% May, 2017
Tender Extension Notice
It is hereby inform that due to some inconvenience, the tender for office
related assets TENDER NO.3 OF 20 17-18 is extend for the next 7 days from the
date of last date. The Tender will be reopen on same time on the date of 12-06-17 .
The other terms and conditioned is same as mentioned in earlier.
Mission Director,
Y-HFA (U),
Dispur, Guwahati-06
