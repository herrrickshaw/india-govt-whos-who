---
doc_id: "fd96cd9a9eee157d"
source_url: "https://irrigation.assam.gov.in/sites/default/files/public_utility/Holiday%20Corrigendum.pdf"
ministry: "Irrigation Department, Assam"
title: "Holiday Corrigendum 2023"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "d4c1c936a32bab44"
---

<!-- page 1 -->

GAD-14021/18/2022-ESTT-GAD-General Administrative
I/249975/2023

GOVERNMENT OF ASSAM
GENERAL ADMINISTRATION DEPARTMENT
DISPUR::GUWAHATI-6
Block-A, 2nd Floor,Janata Bhawan,email-ID:-gad.assam@gov.in, Website:-https://www.gad.assam.gov.in

ORDER BY THE GOVERNOR
CORRIGENDUM
Dated Dispur the

August,2023

e file No. 221561/ 10: Please read the following as shown in the table below towards the point No 1 of the Holiday
List, 2023 notified vide No.221561/1 dated 28th November, 2022:

Name of the Festival Gregarian calendar National Calendar Bhaskarabda Calendar
Tithi of Srimanta
16th
25th Bhadra instead 29th Bhada instead of 32nd
Sankardeva
Septemebr,2023
of 27th Sravan
Saon
th
instead of 18
August,2023
Karam Puja
25th September,
3rd Asvina instead of 7th Ahin instead of 9th
th
2023 instead of 27 5th Bhadra
Bhadra
August, 2023
Janmotsav of
24th September,
2nd Asvina instead of 6th Ahin instead of 7th Ahin
Srimanta
2023 instead of 25th 3rd Asvina
Sankardeva
September,2023

Days of the week
Saturday instead
of Friday

Monday instead of
Sunday
Sunday instead of
Monday

Commissioner & Secretary to the Govt. of Assam,
General Administration Department
Dated Dispur the
August,2023

Memo e file No. 221561/ 10- A
Copy to:
1.
The Director General of Police, Assam, Ulubari, Guwahati-7.
2.
All District Commissioners/Sub-Divisional Officers (Civil).
3.
All Principal Secretaries of Autonomous Councils.
4.
The Secretary Coordination to Chief Secretary, Assam, Dispur, Guwahati-6.
5.
The Commissioner of Police/Asstt. Commissioner of Police, Panbazar, Guwahati-1.
6.
The Accountant General, Assam, Guwahati-29.
7.
The Registrar General, Gauhati High Court, Guwahati-1.
8.
The Secretary, A.P.S.C, Khanapara, Guwahati-22.
9.
The Agriculture Production Commissioner, Assam, Guwahati-6.
10.
The Chairman, Assam Administrative Tribunal, Guwahati.
11.
The Chairman, Assam Board of Revenue, Guwahati.
12.
The Secretary, O/o the Upa-Lokayukta, Assam, Shaktigarh Road, Bhangagarh, Guwahati.
13.
The Secretary, State Information Commission, Housefed Complex, Dispur.
14.
The Secretary, State Election Commission, Dispur, Guwahati-6.
15.
The Registrar, Gauhati University, Guwahati / Dibrugarh University, Dibrugarh / Assam University,
Silchar/Assam Agricultural University, Jorhat / K. K. Handique State Open University, Guwahati /Tezpur
University, Tezpur/ Srimanta Sankar University of Health Sciences, Bhangarh./Cotton University,
Panbazar, Guwahati-1./Kumar Bhaskar Varma Sanskrit and Ancient Studies University, Nalbari /Assam Women
Society, Jorhat/ Rabindranath Tagore University, Hojai/Bodoland
University/ Bhattadev University Bajali/
Madhavdev University,Lakhimpur/ Majuli University of Culture, Majuli/Assam Science and
Technology
University, Guwahati/ Krishnaguru Adhyatmik Vishwavidyalaya, Barpeta / Royal Global University,
Guwahati/Assam Down Town University, Panikhaiti, Guwahati/ Kaziranga University,Golaghat /Assam Don
Bosco University, Guwahati/ Sati Sadhani University, Golaghat.
16.
The Secretary, SEBA/ AHSEC, Bamunimaidam, Guwahati-21.
17.
P.S. to the Principal Secretary to Chief Minister, Assam, Dispur, Guwahati-6.
18.
P.S. to the Commissioner & Secretary to the Governor of Assam, Guwahati-1
19.
The P.S to Secretary, Assam Legislative Assembly, Dispur, Guwahati-6.
20.
All P.S.s to Ministers, Assam, Dispur, Guwahati-6.
21.
All P.S.s to Addl. Chief Secretaries, Dispur, Guwahati-6.
22.
All P.S.s to Principal Secretaries/Commissioner & Secretaries / Secretaries, Assam, Dispur, Guwahati-6.
23.
The Director, Printing & Stationery, Assam, Guwahati-21.

<!-- page 2 -->

GAD-14021/18/2022-ESTT-GAD-General Administrative

24.
The Director, Information & Public Relations, Assam, Dispur for wide publicity of the above.
25.
The Director, All India Radio, Guwahati for wide publicity of the above.
I/249975/2023
26.
The Director, Doordarshan Kendra, Guwahati for wide publicity of the above.
27.
The D.R.C,Assam Bhawan/House, New Delhi /JRC., Assam House/ Bhawan, Kolkata/ JRC, Assam Bhawan,
Chennai/ Vellore/D.R.C.Assam Bhawan,Mumbai/DRC, Assam House, Shillong.
28.
All Departments of Assam Secretariat, Dispur, Guwahati-6.
29.
All Heads of Department, Guwahati.
By orders etc,

Joint Secretary to the Govt. of Assam,
General Administration Department
