---
doc_id: "fa216f4ba48a5efd"
source_url: "https://dlrs.assam.gov.in/sites/default/files/public_utility/notification-_holiday_list_year_2022.pdf"
ministry: "Directorate of Land Records, Assam"
title: "Holiday List 2022"
date: ""
pages: 4
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "14d2a14ecf47d85b"
---

<!-- page 1 -->

===
দা সু
eS
GOVERNMENT OF ASSAM
GENERAL ADMINISTRATION DEPARTMENT
DISPUR::GUWAHATI-6 .
Block-A, 24 Floor, Janata Bhawan, email-ID: gad.assam@gov.in, Website: https://www.gad.assam.gov.In
ORDERS BY THE GOVERNOR
NOTIFICATION
LIST OF HOLIDAYS FOR 2022 IN THE STATE OF ASSAM
No.GAG(A).81/2016/ 749: Dated Dispur the 28" October, 2021
The Governor of Assam is pleased to declare that the Offices under the Government of Assam and all Revenue
and Magisterial Courts in Assam will remain closed on the following days during the year-2022.
Gregorian Calendar| National Calendar [Assamese CalenderDays of the wee Name of the Festival etc.
(5.6) (Bhaskarabda)
14"January,2022 _|24™Pausa, 1943 5.6. 29" Puh, 1428 ;
Magh Bihu & Tusu Puja
15" January 25" Pausa, 1* Magh Saturday
23™January 3" Magha 9" Magh Netaji's Birthday
25" January 5” Magha 11° Magh [Tuesday —_[Gwther Bathou San
26" January 12" Magh [Wednesday [Republic Day |
31" January 11" Magha 17” Magh Monday Me-Dam-Me-Phi
16" February 27° Magha 3° Phagun [Wednesday Bir Chilaray Divas
14" April 24" Chaitra, 30° Chot Thursday Bohag Bihu
ত 15" April 25"Chaitra,1944 S.E. 1* Bohag, 1429 Friday Bohag Bihu & Good Friday
16" April 26" Chaitra, 2™ Bohag [Saturday Bohag Bihu
11 Vaisakha 17” 8০788 May Day/ Tithi of Damodardeva
13" Vaisakha 19” Bohag Id-U'I-Fitr
16" May 26" Vaisakha Buddha Purnima
Madhabdeva
10" July 19”Ashadha 24" Ahar Sunday lid-ui-zuha =i
115" August [24৭35480899 Saun [Monday Independence Day |
29"August 7" Bhadra 12 Bhada Monday Tithi of Srimanta Sankardeva
6" September 15* Bhadra 20” Bhada
14" September 23” Bhadra 28” Bhada Wednesday —_|Tithi of Sri Sri Madhabdeva
Durga Puja (Saptami)
[stOctober 11" Asvina [a6 Ain [Monday | ji
টির 90992 2 ina 16" লি Monday Durga Puja (Astami & Navami)
17° Ahin
rm 13” Asvina 18” Ahi দ্য
5" October 8" Ahin Wednesday [Durga Puja(Bijoya Dashomi) &
Janmotsav of Srimanta
- Sankarde
2a October [2 kartika [লা [Monday [kali Puj
7 i Puja & Diwali
fh ” Kartika ” Kati iwali
27" October 5 9” Kati [Thursday Bhatri Dwitiya
30" October B® Kartika 12° Kati [sunday [ehhat ua |
= = Guru Nanak's Birthday

<!-- page 2 -->

11Agrahayana 15" Aghun [দ02/ [Asom Divas (Su-Ka-Pha Divas)
+ The Governor of Assam is pleased to declare Half Holidays (at 1 P.M.) in the offices under the Government of
Assam and all Revenue and Magisterial Courts in Assam on the following days during the year 2022:
Gregorian National Calendar (S. E.)| Assamese Calender| Days of the week | Name of the Festival etc.
Calendar (Bhaskarabda)
S*August,2022__[18"Sravana_——=—=«di23™ Saun,1429  _][10650৪9৮/ [Muharram |
22" Ahin Lakshmi Puja |
+ All Sundays & Holidays falling on the days shown below are also declared as Public Holidays by the Governor
of Assam under Section 25 of the Negotiable Instrument Act,1881 (XXIV of 1881) read with the Government of
India, Ministry of Home Affairs Notification No.20/25/56 Pub-1.dated 8" June, 1957.
Gregorian Calendar |National Calendar (S.E.) | Assamese CalenderDays of the Name of the Festival etc.
(Bhaskarabda) [week |
782 5
15™January,2022 25" Pausa, 1943 S.E. 19128811428 Saturday Magh Bihu |
26" January 12" Magh Wednesday _|Republic Day |
18" March 27° Phalguna Dol Jatra |
14” April 24" Chaitra1944S.£. 1309 070 Thursday |
15" April 25" Chaitra 1" Bohag Bohag Bihu |
16" April 26" Chaitra 2" Bohag |
11" Vaisakha 47” Bohag May Day |
13" Vaisakha 19" Bohag 1d-U'l -Fitr |
10" July 19" Asadha 24" Ahar 10-01-2015 |
15" August Independence Day |
_ |29" August 7" Bhadra 12" Bhada Monday Tithi of Srimanta |
Sankardeva 1
2" October 10" Asvina 15" Ahin Sunday Birthday of Mahatma
Gandhi & Durga Puja
(Saptami) i
4" October 12" Asvina 17" Ain Durga Puja (Astami & |
Navami) |
5“ October 18" Ahin Wednesday —_|Bijoya Dashomi & Janmotsav|
lof Srimanta Sankardeva |
18" October 31% Ahin [Tuesday [kati Bihu |
24" October 2! Kartika Kali Puja & Diwali |
25" December Christmas Day
3(a) There will be no Public Transaction in the Nationalized Banks on the following days.
[লি লৰিলা |. ত ৰি 4 5
1 April, 2022 11" Chaitra(1943 S.E.) 17" Chot Friday Annual Closing of Bank
Accounts
4. All Second Saturdays and Fourth Saturdays of the months will be observed as Holidays. All other Saturdays will
be full working days.
5. Each employee may be allowed to avail 2(two) days as Restricted Holidays as notified below for the year 2022.
Gregorian Calendar | National Calendar (S.E) | Assamese CalendanDays of the Name of the Festi :
ival etc.
(Bhaskarabda) |week
T January, 2022 11" Pausa 1943 S.E. 16*Puh1428__|Saturday |New Year's Day]
2ল579088_ ']7দ0। ''7েেে]
12" January 22™ Pausa 27" Puh Wednesday টা Anniversary of Shri
ri Anirudhi
লিল নদ রন 0081754527
নল ০৮89 Saturday" [Gaan gsi +
[a7™january (27 Pausa 3 Magh [Monday "sip bivas_]
ত |
27” January 7” Magha 7 Magh [Thursday [Busu Dima Festival ৷
15" February 26" Magha 2" Phagun [Tuesday [Karbi-Dehal-kechir Dorm |
16" February 27° Magha 3" Phagun Wednesday [Ali Aye Ligang |
10" Phalguna 16" Phagun [Tuesday | gang |
March আদ. 0৮)
= ]

<!-- page 3 -->

চুর eee
Hs March [26° Phalguna 5০79৮৮42৮77
সুজন 24 chatre———[30®chot Thursday ahobicJayan_
927 8৭৯ ইিচ্ছটত০৫৮ [aster Saturday —_
99 achag Wednesday [Dew iw __
Be Aon Te vasa ns 39%)"; ||০৮ ৮ _]
লিন ৯5৮ উন ভগ
Fay berate উদ [Menday 18695 —__]
8৮ টি ভটদ04 [iti of rida
Shri_ Shri Krishnaguru
Bishnu Prasad Rabha
ভন কর ক্র 10092
Bhanu Bhakta Acharjya |
ee ভর Sravana 27" Saun saturday Death Anniversary of Bir
Tikendrajit
16" September 25" Bhadra 30" Bhada Friday Birthday of Sri Sri Thakur |
Anukul Chandra
তল }ন্নভভনভ্বঁঁ_ল টা [Sunday 7895
27* October S* Kartika 9" Kati Thursday Abirbhav Tithi of Sri |
নন ভাতার Tuesday _ Kuki Chavang Kut ৷
Teg Bahadurji. |
of Hmar Community.)
Martyr's Day |
|2ঞলট28৮63%/__7শ্চওণচনছ় {|| | |} ]8"70।;; 9099); ] Christmas Eve |
6. If any of the Holidays or Restricted Holidays for festivals notified above does not fall on the Day notified,
necessary modification changing the date will be issued in due course.
7. In addition to the Gazetted/Restricted Holidays and Holidays under N.I. Act 1881, all 2" and 4" Saturdays would
also be observed as Holidays. The Deputy Commissioners are allowed as in previous years to declare any one)
day which may be of local significance as local Holiday except Kamrup (M). With the approval of Hon’ble Chief
Minister, General Administration Department is authorized to declare 2(two) local Holidays for Kamrup (M)
District.
8. General Administration Department is allowed to declare 2 (two) additional holidays with the approval of
Hon’ble Chief Minister, Assam.
9.These Holidays will not be automatically applicable to the Educational Institutions, Medical/Engineering Colleges
unless they adopt the list but it is desirable that the number of holidays may be decreased for Educational
Institutions, Medical/Engineering Colleges etc. and they will adopt academic calendars decreasing the number of
holidays.
Sd/- (M.S, Manivannan, IAS)
Commissioner & Secretary to the Govt. of Assam,
General Administration Department. :
Memo No. GAG(A).81/2016/ 749 -A Dated Dispur the 28" October, 2021
Copy to:-
1, The Principal Secretary to the Chief Minister, Assam, Dispur, Guwahati-6.
| 2. The Commissioner & Secretary to the Governor of Assam, Raj Bhawan, Guwahati-1.
| ও. The Principal Secretary, Assam Legislative Assembly, Dispur, Guwahati-6, মৃ
| 4. All Addl. Chief Secretaries, Dispur, Guwahati-6.
৷ 5. All Principal Secretaries/Commissioner & Secretaries/ Secretaries, Assam,Dispur, Ghy-6,
| 6. All Commissioners of Divisions. টী + 8-6.
7. §S.0. to Chief Secretary, Assam, Dispur, Guwahati-6.
| 8. All Deputy Commissioners/Sub-Divisional Officers (Civil). le
| 9. The Director General of Police, Assam, Ulubari, Guwahati-7. hel
10. All P.S.s to Ministers, Assam, Dispur, Guwahati-6.
| 11, All P.S.s to Advisers to Chief Minister, Assam, Dispur, Guwahati-6, a
i 12. The Commissioner of Police, Panbazar, Guwahati-1.

<!-- page 4 -->

শক Sos ge = |
13, The Accountant General, (A&E)/ (Audit) Assam, Guwahati-29
14. The Registrar General Gauhati High i ৰু
7 igh Court, Guwahati-1.
15. The Secretary, AP.S.C, Khanapara, Guwahati-22,
16. The Agriculture Production Commissioner, Assam, Guwahati-6,
17. The Chairman, Assam Administrative Tribunal, Guwahati
18. The Chairman, Assam Board of Revenue, Guwahati ete
a tli ত ধ! যাও ০০৯-০০3, Assam, Shaktigarh Road, Bhangagarh, Guwahati.
21. The Secreta ৰ’ টি রা ormation Commission, Housefed Complex, Dispur.
22. The Rect ry, 62 lection Commission, Dispur, Guwahati-6.

৮ 1 egistrar, Gauhati University, Guwahati / Dibrugarh University, Dibrugarh / Assam University,
Silchar/Assam Agricultural University, Jorhat / kK. K. Handique State Open University, Guwahati / Tezpur
University, Tezpur/ Srimanta Sankar University of Health Sciences, Bhangarh./Cotton University, Panbazar,
Guwahati-1./Kumar Bhaskar Varma Sanskrit and Ancient Studies University, Nalbari /Assam Women Society,
Jorhat/ Rabindranath Tagore University, Hojai/Bodoland University/ Bhattadev University Bajali/ Madhavdev
University, Lakhimpur/ Majuli University of Culture, Majuli/Assam Science and Technology University,
Guwahati/ Krishnaguru Adhyatmik Vishwavidyalaya, Barpeta / Royal Global University, Guwahati/ Assam
Down Town University, Panikhaiti, Guwahati/ Kaziranga University, Golaghat /Assam Don Bosco University,
Guwahati/ Sati Sadhani University, Golaghat.

23. The Secretary, AHSEC/ SEBA, Bamunimaidam, Guwahati-21.

24. All Departments of Assam Secretariat, Dispur, Guwahati-6.

25. All Heads of Department, Guwahati.

26. All Principal Secretaries of Autonomous Councils.

27. All States/ Union Territories of India.

28. The Director, Printing & Stationery, Assam, Guwahati-21. He is requested to publish the above Notification in
the Extraordinary Assam Gazette.

29. The Director, Information & Public Relations, Assam, Dispur for wide publicity of the above
Notification.

30. The Director, All India Radio, Guwahati for wide publicity of the above Notification.

31. The Director, Dordarshan Kendra, Guwahati for wide publicity of the above Notification.

32. The Assistant General Manager (P), Reserve Bank of India, Guwahati-1.

33. The R.C., Assam Bhawan, New Delhi/ JRC, Assam House and Assam Bhawan, Kolkata/D.R.C., Assam Bhawan,

Mumbai/DRC, Assam House, Shillong/ JRC, Assam Bhawan, Chennai and Assam Bhawan, Vellore.
34. Astrologer concerned.
35. Copy for uploading in the Website.
By order etc,
গল ae
Joint Secretary to the Govt. of A:
General Administration Department
4
৮
