---
doc_id: "faedfb1c9318cafa"
source_url: "https://gdd.assam.gov.in/sites/default/files/swf1/dms38_notification_to_re-constitute_the_board_of_directors_for_guwahati_smart_city_limited.pdf"
ministry: "Guwahati Developement Department, Assam"
title: "Notification on re-construction of the Board of Directors for Guwahati Smart City Limited"
date: ""
pages: 1
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "4aac1b05b0da047f"
---

<!-- page 1 -->

রর GOVERNMENT OF ASSAM
GUWAHATI DEVELOPMENT DEPARTMENT
JANATA BHAWAN, BLOCK, 2ND FLOOR
DISPUR. GUWATIATI-6
E-mail:-gddassam.sectt@gmail.com
ORDERS BY THE GOVERNOR
NOTIFICATION
No. GDD.03/2015/Pt-V/221 Dated, Dispur the 34 January, 2020
The Governor of Assam is pleased to re-constitute the Board of Directors for
Guwahati Smart City Limited with the following Directors:-
Shri Kumar Sanjay Krishna, IAS, Chief Secretary to the Chairman
Govt. of Assam
Shri Munna Prasad Gupta, IPS, Commissioner of Police, Director |
Kamrup (M
sd/-
(Maninder Singh, IAS)
Additional Chief Secretary to the Govt. of Assam,
Guwahati Development Department
Memo No. GDD.03/2015/Pt-V/221-A Dated, Dispur the 3" January, 2020
Copy for information and necessary action to:-
1. Shri Anand Prakash, Ministry of Housing and Urban Development, Govt. of India,
Nirman Bhawan, New Delhi- 110011.
2. The Commissioner, Guwahati Municipal Corporation, Panbazar, Guwahati-01.
3. The Chief Executive Officer, Guwahati Metropolitan Development Authority,
Bhangagarh, Guwahati-5
4, The Managing Director, Guwahati Smart City Limited, 4" Floor, Aditya Tower, Opp.
Down Town Hospital, Guwahati.
5. Shri Munna Prasad Gupta, IPS, Commissioner of Police, Kamrup(M), Panbazar, |
Guwahati. |
6. The S.O. to Chief Secretary, Assam for kind appraisal of the Chief Secretary. ৷
7. The P.S. to the Hon'ble Chief Minister, Assam, Dispur, Guwahati-6. |
8. The P.S. to Addl. Chief Secretary, Finance & T&D Deptt. for kind appraisal of the Addl. |
Chief Secretary.
9. Smt Rupsikha Saikia Borah, Women & Independent Director, Guwahati Smart City
Limited. |
10; The Website Administrator, GDD for uploading in GDD website. i
৯711, The Director, Assam Govt. Press, Assam, Bamunimaidam, Guwahati-2, with a request ৷
to publish the above notification in the next issue of the Assam Gazette. |
{
By order etc, {
0 i
‘4322৮ i
5 ৷
Joint Secretary to the Govt. of Assam ৷
(2 Development Department |
1
Te ধথ[’ঘ(থৱীয়ী ৷৷৷ োৰৰযোৰোদো ০১: -
Scanned by CamScanner
