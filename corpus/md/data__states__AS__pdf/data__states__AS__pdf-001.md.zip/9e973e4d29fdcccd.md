---
doc_id: "9e973e4d29fdcccd"
source_url: "https://bpdd.assam.gov.in/sites/default/files/swf1/dms56_achievement_of_bpdd.pdf"
ministry: "Border Protection and Development Department, Assam"
title: "Achievements of Border Protection and Development Department, Assam"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "347c0ef96bd366fb"
---

<!-- page 1 -->

Annexure-“A”
Major Achievements of Border Protection and Development Department in the last two years:

1) Boundary Disputes:
The border disputes that: Assam has been facing with the neighboring states of Nagaland,
Meghalaya, Arunachal Pradesh and Mizoram since the creation of these states is one of the
most vexed problem, Assam has been afflicted with for over a decade. These States were
once part of Assam. After the curving out of these states from the erstwhile composite state
of Assam, these neighboring states have been claiming large areas of Assam for inclusion
into their respective states. These states have been relentlessly trying to encroach upon
areas of Assam and in some areas have illegally set up villages & settled their people.
a. Assam-Meghalaya Border Issue: In the last two years, the Govt. has made tangible and
unprecedented initiatives to end the border disputes conclusively by bilateral resolutions. The
State of Meghalaya has 12 areas of differences with Assam. A path breaking move was
made in the meeting between Chief Ministers of both the States held on 23/07/2021 at
Shillong to resolve the contentious boundary issues by setting up 3 Regional Committees
respect of the first 6 areas of differences out of the 12 areas of differences, headed by
Ministers of both the States to engage with local people and community organization. Based
on the recommendations of these 3 Regional Committees, an MoU has been signed by the
two Hon’ble Chief Ministers at New Delhi in the presence of Hon’ble Union Home Minister,
Govt. of India on 29/03/2022. As per direction of the Ministry of Home Affairs, Govt. of India,
the Survey of India is on the process for demarcation of boundaries in the 6 areas of
differences.
Another Chief Minister Level Meeting will be held shortly to resolve the issues of the
remaining 6 (Six) areas of differences for which 3 Regional committees have already been
constituted.

b. Assam-Arunachal Pradesh Border Issue: Another milestone has been achieved in
respect of Assam’s dispute with Arunachal Pradesh. Assam and Arunachal Pradesh shares
804.1 K.M of inter-state boundary having 8 districts of Assam and 12 districts of Arunachal
Pradesh. The State of Arunachal Pradesh claimed 123 villages on historical and other grounds
before the Local Commission in 2007. As per the decision taken in the meetings held in
Guwahati in the month of January and April, 2022 between the Chief Ministers of Assam and
Arunachal Pradesh,12 Regional Committees were constituted for joint verification of theses
123 villages. On July 15, 2022 the Historic Namsai Declaration was signed between the states
of Assam and Arunachal Pradesh at Namsai, Arunachal Pradesh wherein the 123 claimed by
Arunachal Pradesh were minimized to 86 villages.
Based on the recommendations of the 12Regional Committees, an MoU has been
signed by the two Hon’ble Chief Ministers at New Delhi in the presence of Hon’ble Union Home
Minister, Govt. of India on 20th of April 2023. 71 of the 123 villages have been amicably
resolved by the MoU and timelines have been fixed for finalization of the boundaries of the
remaining villages.

<!-- page 2 -->

c. Assam-Mizoram Border Issue: With Assam and its neighboring states of Meghalaya &
Arunachal Pradesh inching closer towards a permanent settlement of their border differences,
Mizoram & Nagaland have also advocated the need for a negotiated settlement. Discussions
have already started in a positive direction with Mizoram. Minister Level meetings have taken
place. Goodwill visit have been made between states, and as per the meeting held on 17th of
November, 2022, the Govt. of Mizoram has placed their claims. As had been done with
Meghalaya & Arunachal Pradesh, Regional Committees for Assam-Mizoram border issues will
be constituted.
2.Goodwill programme: To promote peaceful co-existence amongst the people of the
neighboring states, Border Festival has been organized at Bhalukpung in close co-ordination
with the counterpart District of Arunachal Pradesh and at Hailakandi in close co-ordination with
the counterpart District of Mizoram.
3. Inter-State Border Protection: For the first time, BOP Management Committees have
been constituted for strengthening sprucing and ameliorating the existing BOPs along the InterState Boundary. Grant-in-aids @ Rs. 5.00 lakhs each has been already been provided to 74
BOPs. Further in the pipeline is the construction of 50 New BOPs at strategic locations in
phased manner along the Inter-State Boundary.
In the last two years BOPs have been constructed and completed at Khatkhasla (AssamMeghalaya Inter-State Border), Bhalukpung, Moinajuli (Assam- Arunachal Pradesh Inter-State
Border), Upper Namchai (Assam-Nagaland Inter-State Border), Leiri, Tattephai (AssamManipur Inter-State Border).

4. Achievement under BADP: Various schemes under BADP in different bordering districts
have also been successfully completed in the last two years. Some of notable ones area) Construction/ improvement of Udalguri-Bhairabkunda road, Ph-II for Rs.15.38 crore under
BADP in Udalguri District.
b) Construction of CC block road from Biskhowa PMGSY road at Badurtola to Ratiadaha
Bazar via Baro Bhumtirvuta for Rs.1.09 crore in Dhubri District.
c) Construction of ICBP Road from Bandwguri Chowk to Odalguri village including 2 Nos. of
RCC Box Type Culvert, Ph-II of Rs.1.00 crore in Baksa District etc.

**************
