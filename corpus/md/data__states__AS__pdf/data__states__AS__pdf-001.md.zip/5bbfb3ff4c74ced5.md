---
doc_id: "5bbfb3ff4c74ced5"
source_url: "https://dme.assam.gov.in/sites/default/files/swf_utility_folder/departments/dme_lipl_in_oid_8/latest/speaking_order_pwd_category_2.pdf"
ministry: "Directorate of Medical Education, Assam"
title: "Speaking order (PwD category)"
date: ""
pages: 1
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "6013877ed3992ef8"
---

<!-- page 1 -->

GOVERNMENT OF ASSAM
OFFICE OF THE DIRECTOR OF MEDICAL EDUCATION, ASSAM
SIXMILE :: KHANAPARA :: GUWAHATI-22
Web site: www.dme.assam.gov.in, email: dmeassam@gmail.com
No. e. DME/UG/2026/770111/ Dated Guwahati the 17!" September, 2026
ORDER

Whereas, after the 2°4 round online counselling for admission into MBBS/BDS courses in the
Government Medical & Dental Colleges of Assam for the session 2026, the following candidates were provisionally
selected for admission into MBBS courses under PwD (DIVYANG) category as per their merit position and choice.

9]. NEET-UG- Assam
2026 Roll No. | State Rank Name of the Candidate College Allotted
1401106009 20289 URMILA DAS AMG, Dibrugarh

2] 1414102560| 11971 [ BIDYA SAGARKEMPRAT 7771 012, 09৭০৪
1401106209 15162 TMC, Tezpur
[4 | 1414105011 16670 RIJUWANUR HUSSAIN DMC, Diphu 2
1402102717 AKRAMUZ ZAMAN DMG, Dhubri
[6 | 1414106402 18391 RIJABUL ISLAM BMC, Bongaigaon

Whereas, vide this Directorate Notice No. e. DME/UG/2026/770111/20, Dated 11/09/2026, all the
aforementioned provisionally selected candidates under PWD (DIVYANG) category, whose PwD ststus were not assessed
earlier by the Medical Board, were directed to report with all their relevant certificates in original to the office of the Principal
cum Chief Superintendent, Gauhati Medical College & Hospital, Bhangagarh, Guwahati (Hospital premises), for verification of
their disability status by the Medical Board constituted by the DME, Assam vide letter No.e. DME/UG/2026/770111/1192,
dated 02/09/2026, on 14‘ September, 2026, failing which, his/her allotment are to be cancelled.

Whereas, Rijuwanur Hussain (NEET-UG-2026 Roll No. 1414105011), did not appear before the Medical
Board as directed, thus his candidature get automatically cancelled for admission into MBBS course under PwD
(DIVYANG) category, for the session 2026.

Whereas, the Principal cum Chief Superintendent, Gauhati Medical College & Hospital, Guwahati vide
letter no GMC&H/PwBD/01/2026/086, Dtd. 15/09/2026, submitted the verification of disability status report of the
candidates who appeared before the Medical Board.

Whereas, in pursuance of the aforementioned verification report submitted by the Principal, GMC,
Guwahati the status of the candidates for admission into MBBS course for the session 2026 are as follows:

Si. ১ ন ae
No. Name of the Candidate Disability Range Status
[1 [URMILADAS | 40% (Forty percent). Locomotor 1 1০7077৮9349 ।
BIDYA SAGAR KEMPRAT Not Eligible for PwD quota
ELEUS AHMED 40% (Forty percent) category-Ill (a). Visual Not Eligible for MBBS course
4 Not Eligible for PwD quota
5__| RABUL ISLAM 10% (Ten percent). Not Eligible for PwD quota

Whereas, Urmila Das (NEET-UG-2026 Roll No. 1401106009) is allowed for provisional admission into
MBBS course under PwD (DIVYANG) category at Assam Medical College, Dibrugarh, for the session 2026.

Thus, the matter is dispose thereof.

wok
VA
Prof. (Dr.) M. Kon dhury
Director of Medical Education, Assam
Memo No. e. DME/UG/2026/770111/ Dated Guwahati the 17 September, 2026
Copy to:
1. The Commissioner & Secretary to the Govt. of Assam, Medical Education & Research Deptt. Dispur, Guwahati-06, for
information.
2. The P.S. to Hon’ble Minister of Health & FW, Deptt. & MERD, Assam, for kind appraisal of the Hon’ble Minister.
3. Person concerned. Lost
১51৮
Director of Medical Education, Assam
