---
doc_id: "5b0149fd8dbe8cdf"
source_url: "https://elementary.assam.gov.in/sites/default/files/swf1/dms95_final_service_order_of_cte_iase.pdf"
ministry: "Elementary Education Department, Assam"
title: "final_service_order_of_cte_iase.pdf"
date: ""
pages: 8
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "a40e53cf71e063bf"
---

<!-- page 1 -->

Assam State Council of
Educational Research and

Training (CTEs, IASEs)
Promotional Service Order,

2020
Directorate of State Council of Educational
Research and Training, Assam
Kahilipara, Guwahati-19
Ph No. 0361-2382507

<!-- page 2 -->

Contents
[sino [Re Page No }
1. | Titleand Commencement )}
[2 | ০911০ ____]_1__ |
[3 [ Gassandcawe ]]]]]]]]]]][]1 ]
[+ [| Sewicemay alsoincude [2 ইি
[5_ StrengthofSevice 7
18. | Method ofRecritment PT
[6 | General procedure ofpromaton |) এ {(][ 2]
[2 [_SelectonBoard
[10. | 03010110101 8
[1.1 confirmation PS
ন [1 | ১০০০7 ) ]) ঘ 9 1;
[14 [ Fixation ofintialpay PT
[15 [increment 1  )}]}
[18 [ ভগা) )])
(119৮57705
[6 [ 0০৫5060117________1 5
19 transter ]3) |]
120. [| Otherprovisions ofSenice TS
[2 | Maintenance of PostBasedRegister | }
[81”৮7৮5755
124174৬৩505
[25 | scheduet 2 7
[2.1 ৩০০০/১-॥ __ 1 নন 7

<!-- page 3 -->

GOVERNMENT OF ASSAM
ELEMENTARY EDUCATION DEPARTMENT, DISPUR
7 ORDERS BY THE GOVERNOR OF ASSAM
NOTIFICATION
Dated Dispur, the 1st July, 2021
No. AEE.325/2020/4 : Pending finalization of the Service Rules, in exercise of the power conferred under the
proviso to Article 309 of the constitution of India, the Governor of Assam is pleased to make the following
orders regulating the recruitment and conditions of services of the persons appointed to the Assam State
Council of Educational Research (CTEs, IASEs) Service Order, 2020.
Part-I
TITLE AND : 1. i. This order may be called “Assam State Council of Educational
COMMENCEMENT Research (CTEs, IASEs) Service Order, 2020."
ii, These orders shall come into force with effect from the date of its
publication in the Assam Gazette.
> DEFINITION : 2, In these order, unless there is anything repugnant in the subject, or
context:-
a) “Appointing Authority’ means the Governor of Assam.
b) “Commission” means the Assam Public Service Commission.
c) “Government” means the State Government of Assam.
d) “Governor” means the Governor of Assam
e) “Director” means the Director of SCERT, Assam.
f) “Constitution” means the Constitution of India.
g) “Board” means the selection Board constituted under Rule 9 of the
Service order.
h) “Member” means the member of the Assam State Council of
Educational Research (SCERT) (CTEs, IASEs, Prov. B. Ed. College,
Govt. B.Ed. Colleges) Service.
i) “Select List” means the list as referred to Rule 7 & 8 of this Service
Order.
j) “Service” means the Assam State Council of Educational
Research (SCERT) (CTEs, IASEs) Service
k) ‘Year’ means the calendar year.
|) “SCERT” means the State Council of Educational Research and
Training Assam,
m) “CTE” means College of Teacher Education (CTE, Kokrajhar; Govt.
Shikshan Mahavidyalay, Nagaon; Teachers’ Training College, Silchar;
Govt. B.T. College, Goalpara; CTE, Tezpur; CTE, Golaghat and CTE,
Mangaldoi)
n) “IASE” means Institute of Advanced Studies in Education (Govt.
Banikanta College of Teacher Education, Guwahati, Post Graduate
Training College, Jorhat)
CLASS AND CADRE : 3. (1) The Service shall consist of the following Classes and Cadres :-
3) Class-1
1) Principal, CTEs, IASEs -
2) Professor, CTEs, IASEs
3) Lecturer, CTEs, IASEs
1
- শা” Ee

<!-- page 4 -->

THE SERVICE MAY ALSO : 4 (i) Any post equivalent to a post in any of the cadre, mentioned in sub-

INCLUDE tule (1) and,

(ii) Any cadre or post laid down by Government to be included in a cadre
of the service.

STRENGTH OF SERVICE : 5. The strength of each cadre of the service shall be such as determined by
the Government from time to time. The strength of the cadre of service on
the date of commencement of these orders shall be as shown in
Schedule-I
Provided that the Governor of Assam may hold in abeyance any post as
and when considered necessary.

PART-II
METHOD OF : 6. — Recruitment to the service shall be made in the manner prescribed here-in-
RECRUITMENT after.
1. Principal: By promotion from the post of Professor
2. Professor: By promotion from the post of Lecturer
3. Lecturer: 80% Direct recruitment through APSC and 20% by promotion
from the post of Demonstrator having requisite qualification for the post of
Lecturer as per Schedule II provided relaxation of percentage of marks
from the requisite qualification to the existing of man in position in the
post of Demonstrator having more than 25 years of experience as
Demonstrator.

RECRUITMENT BY : 7. The posts shall be filled up by promotion

PROMOTION Principal : The post of Principal shall be filled up from the post of
Professor having minimum 3 years experience as Professor.

Professor : The post of Professor shall be filled up from the post of

Lecturer having minimum 3 years experience as Lecturer.

Lecturer : 80% Direct recruitment through APSC and 20% by promotion from

the post of Demonstrator having requisite qualification for the post of Lecturer

as per Schedule Il provided relaxation of percentage of marks from the
requisite qualification to the existing of man in position in the post of

Demonstrator having more than 25 years of experience as Demonstrator.

GENERAL PROCEDURE OF : 8 (1) Before the end of each year the Appointing Authority shall make an

PROMOTION assessment of the likely number of vacancies to be filled up by

promotion in the next year in each cadre.

(2) Anyone who has rendered service in his respective cadre or

ৰ equivalent post will be eligible for promotion to next higher post.

(3) He must have rendered service in his respective cadre or an
equivalent posts have to be regularized by APSC/ Cabinet/
Departmental Selection Committee.

(4) The appointing authority shall then furnish to the selection Board the
following documents and information to as many officer in order of
seniority as 4 times the number of vacancies as assessed under Sub-
Rule (1)

(a) Information about the number of vacancies

(b) List of officers in order of seniority eligible for promotion (separate list
for promotion to different cadres shall be furnished) indicating the
cadre to which the case of promotion to be considered.

(c) Character Rolls and Other records of the officers and Non Teaching
staff listed.

(d) Any other documents and information as may be considered by the
Appointing Authority or required by the Board.

(5) The Appointing Authority shall simultaneously request the Board to
recommend within one month a list of officers, found suitable for
promotion to each of the cadres in which recruitment is to be made by
promotion.

(6) The selection shall be made on the basis of seniority in each case of
promotion.

(7) The Board, after examination of the documents and information

2
ooo

<!-- page 5 -->

furnished by the Appointing Authority shall recommend to the
Appointing Authority a select list of officers to the number of vacancies
in order of preference found suitable for promotion.

. (8) The Appointing Authority shall consider the select list prepared by the
Board along with character rolls and other records and approve the list
unless it consider any change necessary. If the Appointing Authority
considers it necessary to make any change in the list received from
the Board it shall inform the Board of the change proposed and after
taking into account the comments, if any, of the Board may approve
the list finally with such modifications, if any, as may in its opinion, be
just and proper.

(9) The select list shall be sent to the Commission for approval.

(10) The select list shall remain valid for 12 month from the date of
approval by the Commission.

(11) The promotion shall be in accordance with the list finally approved by
the Appointing Authority.

(12) The inclusion of candidates name in a select list shall confer no right
to promotion unless the Appointing Authority is satisfied after such
enquiry as may be considered necessary that a candidate is suitable
for promotion.

SELECTION BOARD : 9. The selection Board as referred Rule 13 shall consist of the following.
(1) Selection Board for considering promotion to the posts of Principal,
Professor and Lecturer

(i) Senior most Secretary to the Govt. of Assam,

ন Elementary Education Department - Chairman

(ii) Senior most Secretary to the Govt.

of Assam, Finance Department or his representative - Member
(iii) Senior most Secretary to the Govt.

of Assam, Personnel Department or his representative - Member
(iv) Senior most Secretary to the Govt.

of Assam, WPT&BC Department or his representative - Member

(v) Joint Secretary to the Govt. of Assam

Elementary Education Department - Member Secretary
PART Ill: GENERAL PROVISIONS
DISQUALIFICATION : 10. (1) No person shall be eligible for appointment to the service :
(a) Unless he is a citizen of India, and

. (b) If he has more than one wife living or in case of female candidates
who has married a person who has one wife living. Provided that the
Government may, if it is satisfied that there are special grounds for
doing so, exempt any person from the operation of this rule,

(2) No person who attempts to enlist support for his candidates directly or
indirectly by any recommendation either written or oral by other means
shall be appointed to the service.

CONFIRMATION : 11. A member shall be confirmed on the basis of seniority, if he is considered
fit otherwise for confirmation by the Appointing Authority.

DISCHARGE : 12. A member on probation shall be liable to discharged from service or
reverted to his next lower post or to his previous service to which he holds

a lien as the case may be, if his performance of duty has not been

satisfactory or if the Appointing Authority finds him unfit for holding the

post.

3
- eee

<!-- page 6 -->

SCALE OF PAY : 13. The scale of pay admissible to members of the different cadre of the
service shall be such as shown in Schedule I, subject to such revision as
may be made by the Government from time to time.

FIXATION OF INITIALPAY : 14. On promotion of a member from a lower to a higher cadre in service initial
pay shall be fixed in accordance with principles governing such fixation
under the Assam Fundamental Rules and Subsidiary Rules or any rules for
the time being in force.

INCREMENT : 15. (1) The first increment of a member of the service appointed on a time
scale shall accrue on the expiry of one year from the date of his
probation, but further increment shall be admissible only on his
confirmation.

(2) A member of the service on confirmation shall draw pay in the rate
corresponding to his position in the time scale but he shall not be
entitled to any arrear in pay on account of withholding of due
increment for the period to the date of his confirmation.

(3) A member of the service appointed against a temporary vacancy ina
cadre shall be eligible to draw his usual increments in the time scale
under the provision of Assam Fundamental Rules and Subsidiary
Rules subject to the condition that as and when placed on probation,

- he shall remain at the stage of Pay in the time scale where he was on
the date of probation till his confirmation.

SENIORITY : 16. (1) Seniority of a member of the service belonging to each of the cadres
shall be in the order of preference in which their names appear in the
recommendation list of APSC provided he/ She joins his appointment
within 15 days from the date of receipt of the order or within the
extended period or from the date of cabinet approval.

(2) Provided that if a member is prevented from joining within this period
by the circumstances of public nature or for reasons beyond his control
the Appointing Authority may extend it for a further period of 15 days .

If the period is not so extended the seniority shall be determined
according to the date of joining.

৷ (3) If the persons are appointed on the recommendation of the
Commission in two different batches, then the person who was |
recommended in the earlier batch shall be senior to the person who
was recommended in the latter batch.

(4) If two or more persons are bracketed in the merit list of the
Commission, the inter-se-seniority of these persons shall be
determined according to the date of birth.

(5) A member appointed by promotion’ Up-gradation against a vacancy
securing in a year shall be senior to a member appointed by direct
recruitment of that year.

(6) A member appointed under regulation 3 (F) of APSC (F&L), 1951, his/
her adhoc period will not be counted towards fixation of seniority

(7) Ifthe confirmation of a member of the service in a cadre is delayed on
account of his failure to quality for such confirmation he shall loose his
position in order to seniority in that case viz-viz such of his juniors as
may be confirmed in that particulars cadre. His seniority shall however,
be re-started on his confirmation subsequently.

Note:- টু (A) The period of appointed under APSC, 1951 (Limitation of Function)
before regulation through Commission shall always be ignored for
purpose of determining seniority.

GRADATION LIST : 17. A gradation list of the members of the service shall be published cadre

wise every year indicating their relative seniority and date of birth, date of
| a
আৱ LT

<!-- page 7 -->

appointment, date of joining, date of regularization (by the

Commission/Date of issue of Cabinet Approval) etc.

. CODE OF CONDUCT : 18. Every member of service shall maintain high standard of public services,
discipline and conduct and scrupulously bellow the general provisions of
the Assam Service (conduct) Rules as amended from time to time.

TRANSFER : 19. Every member of the service shall be liable to be transferred at any time to
any place in the interest of public service.
OTHER PROVISIONS OF : 20. 1. Except as provided in these rule, all matters relating to pay and
SERVICE allowances, leave, pension, discipline and other conditions of service
shall be regularized by the general rules frame by government from
time to time being in force.

2. The condition of the service of the members, in respect of matters, for
which no provision has been made in these rules, shall be the same as
are, for the time being, applicable to other officers of the Government
of the corresponding status and having similar functions.

MAINTENANCE OF POST : 21. The appointing Authority shall maintain such registers in suitable form as
BASED REGISTER may be prescribed by Government from time to time with a view to
recording the service particulars of the service.
PART IV. SPECIAL PROVISION
- RELAXATION : 22. Where the Government is satisfied that operation of any of these orders
may cause undue hardship in any particular case, it may dispense with or
1618) the requirement of that rule to such extend and subject to such
condition as it may consider necessary for dealing with the case in a just
and equitable manner.
Provided that the case of any person shall not be dealt with in any
manner less favorable to him than that provided in any these orders.
INTERPRETATION : 23. If any question arises relating to the interpretation of these orders, it shall
be referred to the Government in the Education Department whose
decision therein shall be final.
REPEAL AND SAVINGS : 24. The orders corresponding to these orders and in force immediately before
the commencement of these orders are hereby repealed:
Provided that all orders made or actions taken under the orders so
. repealed or under any general orders ancillary there to shall be deemed to
have been validity made or taken under the corresponding provision of
these orders.
5

<!-- page 8 -->

SCHEDULE -1
a ০
; post
30000/- to 110000/-| 14500 | 9 _ | By promotion at sl.2
30000/- to 110000/- | 13900- By promotion at sl. 3
3. Lecturer PB-4 | 30000/- to 110000/-| 13300 107 | 1. 80% Direct Recruitment as per
qualification at Schedule II
2. 20% promotion from the post of
Demonstrator having requisite
qualification for the post of Lecturer
as per Schedule I! provided
relaxation of percentage of marks
from the requisite qualification to the
existing of man in position in the
post of Demonstrator having more
than 25 years of experience as
Demonstrator.
22000/- to 87000/- | 9400 Direct Recruitment
* The Pay Scale has been reflected as per ROP 2017
টু SCHEDULE - Il
Qualification and Experiences prescribed for Direct Recruitment to the post of Lecturer
[SINo. | Name of Cadre Minimum qualification
2০22৮ 7 নল উন
4. Lecturer Essential Qualification
1, Master Degree with 55% marks in the concerned subjects from any recognized
University
2. M.Ed. with 55% marks from any recognized University
Experience
Candidates must have at least 5 years teaching experience in elementary or secondary
education
* | Desirable
i) Preference will be given to the candidates having Ph.D. M.Phil degree (Ph. D. in
education/ Educational Planning and Management shall be given special weightage).
ii) Preference (for lecturer in Assamese) will be given to the candidate having wide
knowledge about the socio-cultural linguistic diversity of NE region.
(Preetom Saikia, IAS)
Special Commissioner,
Elementary Education Department,
Dispur, Guwahati-6
6
