---
doc_id: "280bc3f7dcc3ca3d"
source_url: "https://doatfinance.assam.gov.in/sites/default/files/swf1/dms21_assam_treasuryammended_rules_2023.pdf"
ministry: "Directorate of Accounts & Treasuries, Assam"
title: "assam_treasuryammended_rules_2023.pdf"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b2edd5f2e00eff3f"
---

<!-- page 1 -->

FD-21030(11)/43/2023-ASPIRe-Finance
I/311947/2023

GOVERNMENT OF ASSAM
FINANCE DEPARTMENT (ESTT-B), JANATA BHAWAN,
DISPUR:: GUWAHATI-6

ORDERS BY THE GOVERNOR
NOTIFICATION

No.292641- In exercise of the powers conferred by Article 283 (2) of the
Constitution of India, the Governor of Assam is hereby pleased to make the following
rules, further to amend the Assam Treasury Rules, 2017, hereinafter referred to as the
principal Rules, in the manner hereinafter appearing, namely :Short title and
commencement

1. (1)
(2)

Amendment of
rule 69

2.

These rules shall be called
(Amendment) Rules, 2023.

the

Assam

Treasury

They shall come into force on the date of their publication in
the Official Gazette.

In the principal Rules, for rule 69, the following shall be
substituted, namely:–
“69. The Works Department shall not operate Works
Remittance head.”

Amendment of
rule 71

3.

In the principal Rules, for rule 71, the following shall be
substituted, namely :–
“71. The amounts paid at the instance of the Works
Department by municipalities or other local or public
bodies to meet the cost of works to be carried out by the
Works Department shall be paid as soon as possible to
the accredited bank for credit as civil deposit through the
Treasury Officer. In this case, the accompanying challan
should state clearly the name of the Works divisions to
which the amount is creditable and the works to which
it relates.”

Amendment of
rule 72

4. In the principal Rules, rule 72 shall be omitted.

<!-- page 2 -->

FD-21030(11)/43/2023-ASPIRe-Finance
I/311947/2023

Amendment of
rule 73

5.

In the principal Rules, for rule 73, the following shall be
substituted, namely :–
“73.

Amendment of
rule 75

6.

The Forest Department
Remittance head.”

shall

not

operate

Forest

In the principal Rules, for rule 75, the following shall be
substituted, namely :–
“75.

Money received by the Authority of the Forest
Department shall be paid as soon as possible to the
accredited bank for credit into revenue receipt through
the Treasury Officer.”

Amendment of
rule 76

7.

In the principal Rules, rule 76 shall be omitted

Amendment of
rule 98

8.

In the principal Rules, in rule 98, for the Note, the following
shall be substituted, namely:–

Amendment of
rule 228

9.

Amendment of
rule 229

10.

Amendment of
rule 243

11.

“Note: Forest Department and Works Department shall not
draw money by cheques. They shall draw money from
government exchequer b y s u b m i t t i n g online bills in
Treasury Form.”
In the principal Rules, for rule 228, the following shall be
substituted, namely:“228. Funds required for works expenditures are drawn on
bill in accordance with the prescribed procedures
except otherwise for special cases as directed by the
Finance department.”
In the principal Rules, for rule 229, the following shall be
substituted, namely:“229. The Disbursing Officers of The Works Divisions shall be
guided by the general rules as laid down in Section 1 of
Chapter 4 of the these rules in respect of Works
Expenditure.”
In the principal Rules, in rule 243, after clause (e) the
following new clause (f) shall be inserted, namely:“(f)

The Disbursing officers under Works department shall
furnish bills and vouchers as provided in this rule
along with online bills in T.R. FORM-59 and T.R. FORM60 for Deposit Work to the Treasury Officer at the time
of making payment to vendors deducting necessary
taxes and deduction as applicable.”

<!-- page 3 -->

FD-21030(11)/43/2023-ASPIRe-Finance
I/311947/2023

Amendment of
rule 272

12.

In the principal Rules, for rule 272, the following shall be
substituted, namely:“272. Funds may be supplied to Government officials of the Public
Works Department in the following ways,-

Amendment of
rule 274

13.

(1)

Government officials of the Works Department shall receive
Bills for pay, travelling allowance and contingent expenditure.

(2)

Works Divisions shall draw fund in T.R. FORM-59 for
Works related expenditure debiting functional head of
account instead of remittance
head.

(3)

The Works divisions shall draw fund for Deposit Work
( Class – III) in TR FORM-60 for Deposit Work.”

In the principal Rules, for rule 274, the following shall be
substituted, namely:274.

“Officers of the Works Department are authorized
to draw funds in Treasury Bill Forms in case of
establishment as well as works expenditures. The
bills of works expenditure shall be drawn in T.R.
FORM-59 which shall be encashed at E-Kuber on
payment orders endorsed thereupon by the Treasury
Officer and deduction shall be booked through book
transfer only.”

Amendment of
rule 275

14.

In the principal Rules, rule 275 shall be omitted.

Amendment of
rule 276

15.

In the principal Rules, for rule 276, the following shall be
substituted, namely : –
“276. The Divisional Head shall reconcile receipts and
payment figures with the treasury figures every
month and submit a consolidated statement of both
receipts and payment figures duly countersigned by
the Treasury Officer to the Competent Authority who
shall consolidate the same and arrange to reconcile
the receipts and payments figures quarterly with the
figures booked by the Accountant General. The
monthly accounts of Works divisions shall be
submitted to the Accountant General through cash
accounts, List of payment and schedules generated
in IFMIS by Treasury officer.”

Amendment of
rule 277

16.

In the principal Rules, rule 277 shall be omitted.

<!-- page 4 -->

FD-21030(11)/43/2023-ASPIRe-Finance
I/311947/2023

Amendment of
rule 278

17.

In the principal Rules, in rule 278, the following shall be
substituted , namely :–
“278. Subject to general provision of this section,
supplementary instruction for the guidance of the
departmental officers shall be provided in
departmental regulations and the instructions to
departmental officers for drawing works expenditure in
Treasury Bill Forms and accounting thereof shall be
provided in the departmental regulations.”

Amendment of
rule 280

18.

In the principal Rules, in rule 280, for clause (a), the
following shall be substituted, namely :–
“(a)

Amendment of
rule 281

19.

The Authority in charge of Forest Divisions are
authorized
to
obtain
funds
required
for
departmental disbursements by online bill form by
submitting
bills
and vouchers to the Treasury
with which they have been placed in
account by Finance Department.”

In the principal Rules, for rule 281, the following shall be
substituted, namely,-

“281. (a) The Competent Authority in charge of Forest

(b)

Amendment of
T.R. FORM 59
and 60

20.

divisions shall draw fund in T.R. FORM-59 for
forest grants expenditure which shall be debited
from the functional head of account instead of
remittance head.
The Divisional Head shall reconcile the receipt
and payments figures with the Treasury figures
every month and submit a consolidated
statement of both receipt and payments figures
duly countersigned by Treasury Officer to the
Competent Authority who shall consolidate the
same and arrange to reconcile the receipt and
payments figures quarterly with the figures
booked by the Accountant General .The
monthly accounts of Forest divisions shall
be submitted to the Accountant General
through cash accounts , List of Payment and
Schedules generated in IFMIS by Treasury
Officer.”

In the principal rule, in Part III Forms, The Following
New , T. R FORM - 59, and 60, the following shall be
inserted, namely:Additional Chief Secretary to the Government of Assam
Finance Department, Dispur , Guwahati

<!-- page 5 -->

FD-21030(11)/43/2023-ASPIRe-Finance
I/311947/2023

Memo no-292641
For kind information & necessary action:
1.
2.
3.
4.
5.
6.

The Accountant General (A&E), Assam, Maidmgaon Guwahati, Assam
The Accountant General Audit, Assam. Maidamgaon, Guwahati-29.
The Senior most Secretary of Works/Forest Department, Dispur.
P.S. to Honorable Finance Minister, Dispur, Guwahati-6
The Principal Chief Conservator of Forest, Panjabari, Guwhati.
The Chief Engineer , Public Works Department (Roads)/Public Works Department
(B&NH),Irrigation,Water Resource,Inland Water Transport, Public Health Engineering
7. P.S to the Principal Secretary to the Government of Assam,Janata Bhawan,Dipur, Guwahati-6
8. P.S. to Commissioner & Secretary to the Government of Assam, Finance Department.Janata
Bhawan, Dispur,Guwahati-6
9. P.S. to Secretary to the Government of Assam , Finance Department , Janata Bhawan ,
Dispur,Guwahati-6
10. Deputy Director of Assam Government Press, Bamunimaidan, Guwahati-21 for necessary
action of printing of the notification in the next issue of the Assam Gazette.

Secretary to the Government of Assam
Finance Department

<!-- page 6 -->

FD-21030(11)/43/2023-ASPIRe-Finance
I/311947/2023

<!-- page 7 -->

FD-21030(11)/43/2023-ASPIRe-Finance
I/311947/2023
