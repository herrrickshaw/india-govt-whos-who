---
doc_id: "2baae8b349ecf75a"
source_url: "https://it.assam.gov.in/sites/default/files/public_utility/Guidelines%20for%20granting%20Right%20of%20Way%20%28RoW%29%20to%20Telecommunication%20Infrastructure%20in%20Assam%2C%202023-compressed.pdf"
ministry: "Information Technology Department, Assam"
title: "Guidelines for granting Right of Way (RoW) to Telecommunication Infrastructure in Assam, 2023"
date: ""
pages: 40
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "eda224ebc08b4d65"
---

<!-- page 1 -->

a

IT/29/2023-Admin-IT-IT Department
1/146458/2023

GOVERNMENT OF ASSAM
INFORMATION TECHNOLOGY DEPARTMENT
ASSAM SECRETARIAT, BLOCK-C, 2ND FLOOR
DISPUR, GUWAHATI-781006
ORDERS BY THE GOVERNOR OF ASSAM
NOTIFICATION

No.E 268zH7

Dated Dispur the 14th March, 2023

In pursuance of the provision of the “Indian Right of Way Rules, 2016 as amended from time to
time (in 2017, 2021 and 2022)” and in supersession of earlier orders and guidelines of this
department, the Governor of Assam is hereby pleased to make the "Guidelines for granting Right of
Way (RoW) to Telecommunication Infrastructure in Assam, 2023” to bring uniformity, clarity and

simplicity for the matter related to Telecommunication infrastructure across the state of Assam,
which has received the assent of the Assam Cabinet on 22/02/2023 and is hereby published for
general information.

CHAPTER-I

PRELIMINARY
1.

Short Title and Commencement -

(1) The guideline may be called as “Guidelines for granting Right of Way (RoW) to
Telecommunication Infrastructure in Assam, 2023”
(2) The guideline shall come into force from the date of publishing it in the Official Gazette of
Assam.

2.

Definitions(1) in these guidelines, unless the context otherwise requires(a) “Act” means the Indian Telegraph Act, 1885.

(b) “Appellate Authority” means the Senior Most Secretary to the Government of
Assam, Information Technology Department as specified by the Gazette notification
issued by DoT on 19th June, 2017.

(c) “Assam LSA” means the Licensed Service Area of Assam of the Department of
Telecommunication, Government of India.

(d) “Assam RoW Portal" means the Right of Way Portal of Assam for obtaining the
permissions under these guidelines.

(e) “COW” means Cell-On-Wheels or any temporary Telecommunication infrastructure
for managing events/fares/festivals of short duration (maximum 60 days which may
be extended further) or to give coverage to shadow areas.

(f) “DITEC” means the Directorate of Information Technology, Electronics and
Communication, Government of Assam.

(g) “DeGS” means District e-Governance Society for each administrative district.
(h) “DoT” means the Department of Telecommunication, Government of India.

<!-- page 2 -->

e

IT/29/2023-Admin-IT-IT Department
1/14645 8/2023

(i) “DTC” means the District Telecom Committee formed under Para 25 of these
guidelines.

(j) “Form” means the form appended in these guidelines.
(k) “High Rise Building” means building above 15m in height as per the National Building
Code of India, 2016.

(1) “Infrastructure Provider (IP)” means any person or registered entity- holding an
Infrastructure Provider-1 registration issued by DoT.
(m) “Licensee” means any person or registered entity holding a license issued under subsectIon (1) of section 4 of the Act or Infrastructure Provider-I registration issued by
DoT

(n) “Mobile Tower” means any above-ground contrivance for carrying, suspending or
supporting a telecommunication infrastructure and does not include pole.
(o) “Local Body” means for Urban Areas, Municipal Corporation, Municipal Board or
Town committee declared by the relevant administrative law/order of the
Government of Assam and for Rural Areas, Gram Panchayat (GP) and Village Council
Development Committee (VCDC) under the relevant law/order of the Government
of Assam

(p) “OFC” means Optical Fibre Cable laid through
mechanism.

overground or underground

(q) “Para” means paragraphs of these guidelines.

(r) “Pole” means any above-ground contrivance of height not exceeding eight meters
for carrying, suspending or supporting a telecommunication infrastructure and does
not include Mobile Tower.

(s) “Rules” means the “Indian Right of Way Rules, 2016as amended from time to time
(in 2017, 2021 and 2022)”.

(t) “small Cells” means a low powered cellular radio access node that has a coverage
distance from ten meters to two hundred meters.
(u) “STC” means the State Telecom Committee as formed under Para 24 of these
guidelines.
(v) “street Furniture” means electrical line poles, street light poles, street shelter, foot
bridge1 over bridge or any other furniture installed across the streets by concerned

appropriate authority.
(w) “TSP” means Telecom Service Provider that includes a person, firm, registered entity
who is duly licensed by DoT under Section 4 of the Act for providing inter-alia mobile
network connectivity, internet, intranet and data transfer services.
(x) TelecommunicatIon Infrastructure Includes-

i)

TelecommunicatIon tower such as Ground Based Tower (GBT), Roof Top

Tower (RTT), Ground Based Pole (GBP), Ground Based Mast/Monopole
(GBM), Roof Top Pole (RTP), Micro Cell Tower (MCT) etc.
ii)

The TelecommunicatIon Base Station, Base Station Shelter, various types
Antenna, Base Transceiver System, Microwave System, Router, Switches,

Core Network Elements, Cables used for Telecommunication System,
Relevant Power Supply Equipment, Diesel/Petrol Generator or any other
cabin/infrastructure

iii)

for housing aforementioned

Telecommunication cable on pole/electric pole.

items.

<!-- page 3 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

iv)

Underground Telecommunication cabling system laid underground that
includes manholes, marker stones, appliances and apparatus for the
purpose of establishment/maintenance of the Telecommunication cabling

system.
(y) “SACFA” means the Standing Advisory Committee on Frequency Allocation of the
DoT

(2) The words and expressions used but not defined herein but defined in the Act or the
Rules shall have the same meaning as defined in the Act or Rules as the case may be.
3.

Nodal Officer
Under sub-rule (1) of rule (4) of the Rules, the Deputy Commissioner of each district shall be

4.

the Nodal Officer for that particular district for the purpose of these guidelines.
Mode of Application

Only online applications shall be accepted for installation or laying any kind of
TelecommunicationInfrastructure through Assam RoW Portal or any other portal authorized
by this department.

CHAPTER-II
APPLICATION FOR ESTABLISHMENT OF OVERGROUND

TELECOMMUNICATION INFRASTRUCTURE
5.

Application for Establishment of Mobile Towers
Application for establishing of mobile towers such as Ground Based Tower (GBT)1
Roof Top Tower (RTT) etc. shall be submitted by licensee to the Nodal OffIcer as
perForm-1 along with the following documents (sub-para 1 to 12) & Information (subpara 13)(1)

Location map from any publicly available sources such as Google Map on a
scale of 1:1000 along with exact latitude and longitude of the location in
which the tower is to be installed.

(2)

The Detailed Technical Design & Drawing for that particular tower including
specification of foundation. In case the tower is within 100 meters aerial
distance from high or low tension line or any high rise infrastructure1 then its

distance from the same shall be clearly indicated in the drawingrTo be
applicable only for high transmission line and not for high raised structure
and llKV line which is desirable for drawing power to the mobile
installation/tower).
(3)

Copy of Structural Stability CertIficate for that particulartower and the
building where the tower is to be installed(in case of RTT) obtained from
authorized Structural Engineer or/from recognized institute or a Structural
Engineer registered or employed in Central or State Government service or
anY Quasi-Government body or any other agency authorized by Government

from time to time.
(4)

In case of high-rise building,copy of No Objection CertifIcate from Fire Safety

Department
(5)

<!-- page 4 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023
a. Copy of SACFA clearance certificateORSACFAclearance application for

the tower submitted to the Wireless Planning and Coordination wing of
DoT.

b. Undertaking that in case of any objection/rejection, the licensee shall
remove the tower or take corrective measures.
(6)

In ra cd + ha +nlhlar ic +n ha : nc+nII arI in fn rar+

and/protected areas, copy of No
Environment and Forest Department,

from

(7)

Objection Certificate
Government of Assam
A self-declaration licensee

1

respect

System that all general public areas around the tower shall be within safe

(8)

Electro Magnetic Radiation (EMR) exposure limit as per peak traffic
measurement after the antenna starts radiating.
In case the mobile tower is to be installed over private property, the licensee
shall intimate the Nodal Officer in writing along with details of building or
structure where the mobile tower is proposed to be established and a copy
of structural safety certificate certified by an authorized structural engineer
before commencement of such work.

(9)

(10)

(11)

Self-attested copIes of ownership title document of the building/site

However, production of patta/approved map should not be insisted upon
but is specifIc cases; such documents are required to be submitted.
Copy of type test certificate issued by Automotive Research Association of
India (ARAI) to the Diesel/Petrol Generator manufacturer of the DG/PG set,
in case DG/PG is to be installed along with the infrastructure.
In case of Roof Based Tower, No Objection Certificate from building
owner/entIties/societies having roof top rights.

(12)

(13)

In case the permission is sought in the land/premises of central/state
government or a PSU of central/state government, the prior written consent
or copy of agreement from authority having legitimate right over the
land/premises required to be submitted along with the application.
The licensee shall submit the following information while submitting the
applicationa. The mode and time duration for execution of the work.

b. The inconvenience that is likely to be caused to the public and the
specific measure to be taken to mitigate such inconvenience.
c. The measure proposed to be taken to ensure public safety during the
execution of the work
d. The name and contact details of the employees of the licensee for the
purpose of communication in regards to the application made. proposed
to be undertaken.

e. Any other matter relevant, in the opinion of the licensee, connected
with or relative to the work proposed to be undertaken.
f. Any other matter specified by DoT, or State Govt. or the local body.
6. Application for Establishment of Poles
Application

for

establishment

of

poles

for

deployment

of

Small

Cells/TelecommunicationCablesshall be submitted by licensee to the Nodal Officer as per

<!-- page 5 -->

IT/29,/2023-Admin-IT-IT Department
1/146458/2023

Form-2 along with the following documents (sub-para 1 to 12) and Information(sub-para
14)

(1)

Location map from any publicly available sources such as Google Map on a
scale of 1:1000 along with exact latitude and longitude of the locatIons in
which the pole(s) is to be installed.

(2)

The

Detailed

Technical

Design &

Drawing

of

the

pole(s)

including

specification of foundation. In case the pole(s) is within 100 meters aerial
distance from high or low tension line, then its distance from the same shall
be clearly indicated in the drawing.
(3)

In case of high-rise building, copy of No Objection Certificate from Fire
Safety Department for Small Cells.

(4)

In case of the pole(s) is to used for deployment of Telecommunication Cable
or poles are to be established along a route, the detailed route plan along
with exact latitudes and longitudes.

(5)

In case the pole(s) is to be installed in forest land/protect areas, No
Objection

Certificate

from

Environment

and

Forest

Department,

Government of Assam.
(6)

In case of small cells, a self-declaration licensee in respect of Mobile Tower/
Base Transceiver System that all general public areas around the tower shall
be within safe Electro Magnetic Radiation (EMR) exposure limit as per peak

(7)

traffic measurement after the antenna starts radiating.
In case the pole(s) is to be installed over private property, the licensee shall

intimate the Nodal Officer in writing along with details of building or
structure where the pole(s) is proposed to be established and a copy of
structural safety certifIcate certified by an authorized structural engineer
before commencement of such work
(8)

(9)

Self-attested copies of ownership title document of the building/site.
However, production of patta/approved map should not be insisted upon
but is specific cases; such documents are required to submit.
Copy of type test certificate issued by Automotive Research Association of

India (ARAI) to the Diesel/Petrol Generator manufacturer of the DG/PG set,
in case DG/PG is to be installed along with the infrastructure.

(10)

in case of Roof Based Pole, No Objection CertifIcate from building
owner/entities/societies

(11)

having roof top rights.

in case the permission is sought in the land/premises of central/state
government or a PSU of central/state government, the prior written consent
or copy of agreement from authority

having legitimate

right over the

land/premises shall be submitted with the application.
(12)

The information as mentioned in Sub-Para 13 of Para 5.

7. Application for Use of Street Furniture
Application

for

use

of

street

furniture

for

deployment

of

small

cells/telecommunication cables shall be submitted to the Nodal Officer as per form-3
along with the following documents(sub-para 1 to 8) and information(sub-para 9)(1)
Photographs of the street furniture to be used.

<!-- page 6 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

The location showing the proposed route plan of street furniturealong with

(2)

exact latItude and longitude.
(3)

Detailed technical designed for establishing/laying Telecommunication
infrastructure on the street furniture.

(4)

Copy of structural safety certificate obtained from authorized Structural
Engineer or/from recognized institute or a Structural Engineer registered or
employed in Central or State Government service or any Quasi-Government
body or any other agency authorized by Government from time to time.

(14)

In case of small cells,A self-declaration licensee in respect of Mobile
Tower/Base Transceiver System that all general public areas around the
tower shall be within safe Electro Magnetic Radiation (EMR) exposure limit
as per peak traffic measurement after the antenna starts radiating.

(15)

(5)

In case of small cells, copy of type test certificate issued by Automotive
Research Association of India (ARAI) to the Diesel/Petrol Generator
manufacturer of the DG/PG set, in case DG/PG is to be installed along with

the infrastructure.
The information as mentioned in Sub-Para 13 of Para 5.

CHAPTER-III
APPLICATION FOR ESTABLISHMENT OF UNDERGROUND

TELECOMMUNICATION INFRASTRUCTURE
8. Application for laying underground Telecommunication infrastructure
Application for laying of underground Telecommunication infrastructure shall be submitted
to the Nodal Officer as per Form-4 along with the following documents(sub-para 1 to 3) and
information(sub-para 4)(1)

The location map showing the proposed underground Telecommunication
infrastructure including route plan, exact latitude and longitude and nature
of land.

(2)

In case, the route of such infrastructure falls under private property, copy of

consent of owner of such private property.
(3)

For forest protected area, copy of no objection from the state Environment

(4)

and Forest department.
The information as mentioned in Sub-Para 13 of Para 5.

CHAPTER-IV

APPLICATION FEES AND OTHER CHARGES
9.

APPLICATION FEES AND OTHER CHARGES

Fee For

Amount

One-time non-refundable- Administrative Charge
Establishment of mobile
e

Revenue Sharing
Model
Between DeGS&

<!-- page 7 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

towers

2)

mobile tower for state
government property and
private property.

DITEC in 80:20 ratio

NIL for central government

Not Applicable

prQperty.
B

Establishment of poles

1)

2)

One thousand rupees per
pole for property

understate government.
NIL for establishment of

Between DeGS&
DITEC in 80:20 ratio

Not Applicable

poles for Central

C

Laying of underground or

1)

D

overground
Telecommunicationcable
For installation of small
cells and
Telecommunication cable

1)

E

using street furniture
Restoration Charges
Establishment of
overground
Telecommunication
Infrastructure

Government and Private
Property.
One thousand rupees per
kilometer.

Between DeGS&
DITEC in 80:20 ratio

One hundred rupees per

Between Street

street furniture.

Furniture Provider &
DITEC in 90:10 ratio

If any damage to the
property of state
government of establishing
any overground
telecommunication
infrastructure, sum required
to restore immovable
property as per the rate
prescribed by Central Public
Works Department for that
area, if no rate has been

Not Applicable

prescribed by Central Public

Works Department for that
area, rate prescribed by the
State Public Works
Department for that area
shall be applicable
The licensee shall restore

the damage incurred in case
of establishment of poles
for installation of small cells

or Telecommunication
cables
F

Establishment of

underground
Telecommunication
Infrastructure where
undertaking is not given
by the licensee to

discharge the

responsibility to restore

Sum required to restore immovable
property as per the rate prescribed
by Central Public Works Department
for that area, if no rate has been
prescribed by Central Public Works
Department for that area, rate
prescribed by the State Public
Works Department for that area

Not Applicable

<!-- page 8 -->

IT/29/2023-Admin-IT-IT Department
1/ 146458/2023

G

H

the damages
shall be applicable.
Bank guarantee as
Sum required to restore immovable
security for performance
property as per the rate prescribed
in case of establishment
by Central Public Works Department
of underground
for that area, if no rate has been
Telecommunication
prescribed by Central Public Works
Infrastructure where
Department for that area, rate
undertaking is given by
prescribed by the State Public
the licensee to discharge Works Department for that area
shall be applicable.
the responsibility to
restore the damages
Recurring Annual Fees (Compensation)

Not Applicable

Not Applicable

s

Towers, Poles and laying

I

of underground or
overground cable
Use of street furniture
for installation of small
cells and
Telecommunication
cables

1)

For installation of small

Between Street

cells: Three hundred rupees
annually for urban area and

Furniture Provider
and DITEC in 90:10

one hundred and fifty
rupees per annum for rural
area per street furniture.

ratio

Between Street

2) For installation of
Telecommunication cables:
One hundred rupees per
annum per street furniture

Furniture Provider
and DITEC in 90:10

ratio

10. The restoration chargesreferenced above shall be deposited to the appropriate authority
having legitimate right over the land, infrastructure or furniture in form of any valid financial
instrument.

CHAPTER-V
OBLIGATION OF LICENSEE AND SUPERVISION OF WORK BY NODAL OFFICER
11. Overground Telecommunication Infrastructure
(1) Obligation of licensee in undertaking workThe licensee shall ensure thata
Prior to the commencement of establishment and maintenance
i)
of overground telecommunication infrastructure, the measures
to mitigate public inconvenience and ensure public safety,

ii)

barricading the surrounding within warning signs and structural
safety of such overground telecommunication infrastructure are
implemented.
The work of establishment and maintenance of overground
telecommunication

infrastructure

is carried out in accordance

<!-- page 9 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

with the conditions specified in the grant of permission by the
Nodal Officer.

(2) Powers of Nodal Officer to supervise the worka. The Nodal OffIcer may supervise the establishment and maintenance of

overgroundtelecommunication infrastructure to ascertain if the
conditions imposed for grant of permission are observed by the licensee
under clause (a) of sub-para (1) of Para 17, clause (a) of sub-para (3) of
Para 18 and clause (a) of sub-para (1) of Para 19 as the case may be.

b. The Nodal Officer may, based on such supervision, impose such other
reasonable conditions, as it may think fit.
c. If the Nodal Officer comes to the conclusion that the licensee has
willfully violated any of the conditions for grant of under clause (a) of
sub-para (1) of Para 17, clause (a) of sub-para (3) of Para 18 and clause
(a) of sub-para (1) of Para 19;the application shall be withdrawn and the
reasons for the same to be recorded in writing.
Provided that no action shall be taken under this sub-para unless the
licensee has been given an opportunity of being heard.

12. Underground Telecommunication Infrastructure
(1) Obligation of licensee in undertaking worka. The licensee shall make the payment of expenses or submit the bank
guarantee as determined by the Nodal Officer within a period of thirty
days from the date of grant of permission and prior to the
commencement of work of laying the underground telecommunication
infrastructure:
Provided that the Nodal Officer may, at its discretion, extend the said
period for payment of expenses or submission of bank guarantee on an
application made by the licensee seeking such extension.
b. The licensee shall ensure that-

i)

prior to the commencement of work of laying the underground
telecommunication infrastructure and at all times during the
execution of work, the measures to mitigate public
inconvenience and provide for public safety are implemented;
and

ii)

the work of laying underground telecommunication
infrastructure is carried out in accordance with the conditions

specified in the grant of permission by the Nodal Officer.
c. The licensee shall ensure provision of positional intelligence, through

appropriate technology, of all underground telecommunication
infrastructures to enable the Nodal Officer to obtain real time
information on its location

(2) Powers of Nodal Officer to supervise the work'
a. The Nodal Officer may supervise the execution of work to ascertain if
the conditions imposed for grant of permission under clause (a) of subpara (1) of Para 20 are observed by the licensee.

<!-- page 10 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023
b.

The Nodal Officer may, based on such supervision, impose such other
reasonable conditions as it may think fit.

C.

If the Nodal Officer comes to the conclusion that the licensee has
willfully violated any of the conditions for grant of permission under
clause (a) of sub-para (1) of Para 20, it may forfeit, in full or in part, the
bank guarantee submitted by the licensee and withdraw the permission
granted to the licensee, for reasons to be recorded in writing:
Provided that no action shall be taken under this sub-para unless the
licensee has been given an opportunity of being heard.

CHAPTER-VI
EXAMINATION AND SCRUTINY OF APPLICATIONS
13. Examination and Scrutiny of Applications for Establishment of Mobile Towers

(1) in case a mobile tower is proposed to be installed in rural area, the Nodal Officer shall
examine the matter related to land, public complaints or any other matter related to
administrative purview through Revenue Circle Officer and the matter related technical
purview of the mobile tower through PWD (Buildings).

(2) in case a mobile tower is proposed to be installed in urban area, the Nodal Officer shall
examine the matter related to land, public complaints or any other matter related to
administrative purview through concerned Urban Local Body and the matter related to
technical purview of the mobile tower through Engineering cell of the concerned Urban
Local Body.

(3) The Nodal Officer shall be assisted by the District Manager, DITEC,in all activities related
to this guideline.

14. Examination and Scrutiny of Applications for Establishment of Poles for Deployment of
Small Cells/Telecommunication

Line

(1) in case the pole is proposed to be installed in rural area, the Nodal Officer shall examine
the matter related to land, public complaints or any other matter related to
administrative purview through Revenue Circle Officer and the matter related technical
purview of the pole through PWD (Buildings).

(2) in case a pole is proposed to be installed in urban area, the Nodal Officer shall examine
the matter related to land, public complaints or any other matter related to

administrative purview through concerned Urban Local Body and the matter related to
technical purview of the pole through Engineering cell of the concerned Urban Local
Body

(4) The Nodal Officer shall be assisted by the District Manager, DITEC, in all activities matter
related to these guidelines.

15. Examination and Scrutiny of Applications for Use of Street Furniture for Deployment of
Small Cells/Aerial Cables

(1) The Nodal OffIcer shall examine the application through appropriate authority having
legitimate right over the street furniture.

<!-- page 11 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023
(5) The Nodal OffIcer shall be assisted by the District Manager, DITEC,in all activities related
to these guidelines.

16. Examination of Scrutiny of Applications for Laying Underground Telecommunication
Infrastructure
(1) The Nodal OffIcer shall examine route related matter and collect the damage restoration

estimate from appropriate authority having legitimate right over the route of the
proposed underground infrastructure such as PWD, ULB, GPs.
(2) For matter related to public complaints and land related matter, the Nodal Officer shall
scrutjnize the application through Revenue Circle Officer in case of rural area and Urban
Local Body in case of Urban area.

(3) The Nodal Officer shall be assisted by the District Manager, DITEC, in all activities related
to this guideline.

CHAPTER-VII
DISPOSAL OF APPLICATIONS
17. Disposal of applications for establishment of mobile towers
(1) The application submitted under Para 5 of these guidelines; the Nodal Officer shall
examine the application as per Para 13 of these guidelines. After examination and
scrutiny, the Nodal Officer shall, within a period not exceeding 60 (sixty) working days
from the date of applicaHon:

a.

Grant the application permission on such conditions including but not
limited to, the time, mode of execution, measure for mitigate public
inconvenience or enhance public safety or structural safety.

b.

Reject the application for permission, to be recorded in writing:
Provided that no application

shall be rejected unless the applicant

licensee has been given an opportunity of being heard on the reasons of

rejections.
c.

Revert to licensee for necessary correction if required.

(2) The permission for application made under Para 5 shall be delivered as per Form 5
annexed along with these guidelines.
18. Disposal

of

applications

for

establishment

of

poles

for

deployment

of

small

cells/telecommunication cable
(1) in case a licensee wants to establish poles for deployment of small cells over private
property or property of central government, the licensee shall intimate the concerned
Nodal Officer as per Para 6 of this guideline.

(2) in case a licensee wants to establish poles for deployment of telecommunication cable
over private property or property of central government, the licensee shall intimate the
concerned Nodal Officer as per Para 6 of this guideline and shall pay the fees for laying
overground telecommunication cable as per the rate specified at Para 9(C) of these
guidelines.
(3) in case a licensee wants to establish poles over property of state government, the
licensee shall submit application as per Para 6 of these guidelines; the Nodal Officer shall

<!-- page 12 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023
examine the application as per Para 14 of these guidelines. After examination and
scrutiny, the Nodal Officer shall, within a period not exceeding 60 (sixty) working days
from the date of application:
a. Grant the application permission on such conditions including but not
limited to, the time, mode of execution, measure for mitigate public
inconvenience or enhance public safety or structural safety.
b. Reject the application for permission, to be recorded in writing. Provided
that no application shall be rejected unless the applicant licensee has been
given an opportunity of being heard on the reasons of rejections.
c.

Revert to licensee for necessary correction as required.
(4) The permission for application made under Para 6 shall be delivered as per Form 6
annexed along with these guidelines.

19. Disposal of application for use of street furniture
(1) The application submitted under Para 7 of these guidelines; the Nodal Officer shall
examine the application as per Para 15 of these guidelines. After examination and
scrutiny, the Nodal Officer shall, within a period not exceeding 60 (sixty) working days
from the date of application:

a.

Grant the application permission on such conditions including but not
limited to, the time, mode of execution, measure for mitigate public
inconvenience or enhance public safety or structural safety etc.

b.

Reject the application for permission, to be recorded in writing:
Provided that no application

shall be rejected unless the applicant

licensee has been given an opportunity of being heard on the reasons of
rejections.
c.

Revert to licensee for necessary correction as required.

(2) The permission for application made under Para 7 shall be delivered as per form 7
annexed along with these guidelines.

20. Disposal of

applications

for

establishment

of

underground

Telecommunication

infrastructure

(1) The application submitted under Para 8 of these guidelines; the Nodal Officer shall
examine the application as per Para 16 of these guidelines. After examination and
scrutiny, the Nodal Officer shall, within a period not exceeding 60 (sixty) working days
from the date of application:
a.

Grant the application permission on such conditions including but not
limited to, the time, mode of execution, measure for mitigate public
inconvenience or enhance public safety or structural safety etc.

b.

Reject the application for permission, to be recorded in writing.
Provided that no application shall be rejected unless the applicant
licensee has been given an opportunity of being heard on the reasons
of rejections.

c.

Revert to licensee for necessary correction as required.
(2) The permission for application made under Para 8 shall be delivered as per form 8
annexed along with these guidelines.
21. Terms and Conditions for Deemed Approval

<!-- page 13 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

Application submitted under Para 5, 6 and 7 of these guidelines shall be deemed to

be granted if the Nodal Officer fails to either grant permission or reject the permission
within 60 (sixty) working days.
Provided further that if an application for permission is reverted by Nodal Officer for
necessary correction, the date of resubmission of the application shall be counted as the
date of submission for deemed approval after 60 (sixty) working days.

CHAPTER-VIII
TENURE OF PERMISSION, RENEWAL OF PERMISSION AND RIGHT OF
AUTHORITY TO SEEK REMOVAL OF UNDERGROUND OR OVERGROUND

TELECOMMUNICATION INFRASTRUCTURE
22. Tenure of Permission and Renewal

(1) The permission granted under these guidelines shall be valid from the date of issuance of
the permission totlll the date for which TSP/IP obtained permission/license/registration
granted by the DoT as per guidelines of DoT.
(2) The licensee shall submit the application for renewal of permission to the Nodal Officer at
least sixty official working days before the expiry of permission along with all the documents
as required for new permission. The Nodal Officer shall renew the permission after charging
the fee as prescribed under Chapter IV of these guidelines. The renewed permission shall be
valid from the date issuance till the periods of permission/licensee/registration granted by

the DoT.

(3) The Nodal Officer shall dispose of such renewal application within 15 (fifteen) working days.

If the renewal application is not submitted by licensee on time, the Nodal Officer shall
communicate in writing to the authorized representative of licensee to state the reason. If
the licensee fails to submit renewal application within 60 (sixty) working days, the Nodal
Officer may initiate proceeding against the TSP/IP . However, delay in disposal of renewal
application by the Nodal Officer, operation of such Telecommunication infrastructure shall
not be discontinued.

23. Right of Authority to Seek Removal
(1) Where the Nodal Officer, having regard to circumstances which have arisen since the
establishment of any underground or overground TelecommunicationInfrastructure under,
over, along, across, in or upon, any immoveable private, public or government property
vested in or under the control or management of that Nodal Officer, considers that it is
necessary and expedient to remove or alter such TelecommunicationInfrastructure, the
Nodal Officer shall issue a notice to the licensee for removal or alteratIon of
Telecommunication Infrastructure

(2) On receipt of the notice under sub-para (1), the licensee shall submit a detailed plan for
removal or alteration of such Telecommunication infrastructure within 30 (thirty) working
days to the Nodal Officer.
(3) After examination of the detailed plan submitted by the licensee under sub-para (2), The
Nodal Officer shall pass such orders as it deems fit:

<!-- page 14 -->

IT/29/2023-Admin-IT-IT Department
1,,'146458/2023
Provided that the Nodal Officer shallgive a reasonable time of not less than ninety days to
the licensee for removal or alteration of such Telecommunication infrastructure.

Responsibility and liability, including the cost thereof, for removal or alteration of such
Telecommunication infrastructure shall be borne by the licensee.
(4) The licensee shall submit the removal or alternation report to the Nodal Officer within 5
(five) working days after completion of such works.

CHAPTER-IX
THE STATE-LEVEL AND DISTRICT-LEVEL COMMITrEE
24. There shall be state-level committee (STC) in the state which shall act as the Apex
Committee for overall guidance, monitoring and implementing these guidelines under the
Chairpersonship of the Senior Most Secretary to the Government of Assam, Information
Technology Department with the following members. However, the Chairperson of STC is
authorized to co-opt any expert as necessitated.
Designation
Sr. Most Secretary to the Government

of Assam,

Membership
Chairperson

Information Technology Department
2

Commissioner & Secretary to the Government of
Assam, Home Department
Director General of Police

Commissioner & Secretary to the Government of
Assam, General Administration
5

Member
Member
Member

Department

Commissioner & Secretary to the Government of

Member

Assam, Health & Family Welfare Department
6

Commissioner & Secretary to the Government of

Member

Assam, Revenue & DM Department
7

8

Commissioner & Secretary to the Government of
Assam, Environment & Forest Department
Commissioner & Secretary to the Government of

Member
Member

Assam, Panchayat & Rural Development Departrnent
9

10
11
12

Commissioner & Secretary to the Government of
Assam, Department of Housing & Urban Affairs
Commissioner & Secretary to the Government of
Assam, PWD (Building & NH) Department
Commissioner & Secretary to the Government of
Assam, PWD (Roads) Department
Commissioner & Secretary to the Government of
Assam, Power Department
Deputy Director General, Assam LSA, DoT
Joint Secretary to the Government of Assam,
Information Technology Department
Representative of concerned licensee
Director, Directorate of Information Technology,
Electronics and Communication (DITEC)

Member
Member
Member
Member
Member
Member

Member
Member Secretary

<!-- page 15 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

25. There shall be a District Telecom Committee (DTC) in each district to implement these
guidelines under overall supervision of STC. The Deputy Commissioner of the District shall be
the Chairperson of the DTC and the members of the DTC are shown below. However, the
Chairperson is authorized to co-opt any expert as necessitated.
SI No

Membership
Chairperson
Member
Member

Designation
Deputy Commissioner
Superintendent of Police

I

Zila Parishad

4

Chairman, ULBs in the District

Member

5

Joint Director of Health Services of the district

Member

6

Member

I

7

Executive Engineer, PWD (Building) of respective Jurisdiction

Member

8

Executive Engineer, PWD (NH) of the Jurisdiction

Member

9

Executive Engineer, PWD (Roads) of respective Jurisdiction

Member

10

Assistant General Manager, APDCL of respective Jurisdiction

Member

Representative from Concerned Licensee
c
ty Commissioner, e-Governance

Member
Member Secretary

26. Duties and responsibilities of STC and DTC within their jurisdiction are as follows:
(1) Implementation

of these
Infrastructure in the state

guidelines

for

development

of

Telecommunication

(2) Resolving public grievances arising from establishing mobile towers or any other
overground Telecommunication infrastructure or laying underground cables in the state.
(3) Seizure/removal of unauthorized Telecommunication infrastructure in the state
(4) Designate 1 (one) no of authorized representative

not below the rank of Assistant

Engineer from PWD (Building), PWD (NH) and PWD (Roads) department for each
administrative district in consultation with the respectIve DTC for the works related to
PWD while implementing these guidelines.

CHAPTER-X

APPEALS, DISPUTE RESOLUTION, PUBLIC GRIEVANCES AND REMOVAL OF
DIFFICULTIES
27. Appeals/Dispute Resolution/Public Grievances
(1) Any dispute arising between a licensee and the Nodal officer in consequence of these
guidelines or anY complaint/ grievance by any individual/organization shall be taken up
as an agenda in the DTC meetIng within 30 days.

<!-- page 16 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

(2) Any party aggrieved by the decision of DTC may file an appeal before the STC within
30(thirty) days of the order of DTC. The STC shall decide the dispute/dispose of the
complaint/grievance within 30 (thirty) days of receipt of the grievance which shall be
final
(3) in case of any mishap/accident/damage caused due to installation of small cells, telecom
cables etc. the responsibility will be equally shared between/amongst user(s) (TSP/IP)
and owner of street furniture provider.

(4) The Government of Assam may notify any other order, amendment or notification as
required for establishment of Telecommunication Infrastructure from time to time.
(5) The Director, DITEC may notify any changes at the web-portal developed for the purpose
these guidelinesin consultation with DoT.

CHAPTER-XI

DIGITISATION OF TELECOMMUNICATION INFRASTRUCTURE’S RECORDS
28. The licensee shall ensure that all information

related to all existing overground

Telecommunication Infrastructure such as Mobile Towers and Poles are digitized as per
Form-9 and information related underground/overground telecommunication cable as per
Form-10 annexed along with this guideline at the Assam RoW Portal.

sd/---'
(Syedain Abbasi, IAS)
Addl. Chief Secretary to the Government of Assam
Information Technology Department
Memo: No. E 268447-A

Dated Dispur the 14th March, 2023

Copy to:

The Commissioner & Secretary to the Hon’ble Governor of Assam for kind apprisal of the
Hon’ble Governor
2. The Principal Secretary to the Hon’ble Chief Minister, Assam for kind apprisal of the Hon’ble
Chief Minister
3. The Secretary, Department of Telecommunications, Ministry of Communications, Govt. of
India, Sanchar Bhawan, 20, Ashoka Road, New Delhi- 110001.
4. The Secretary, Ministry of Electronics and Information Technology (MeitY), Govt. of India,
Electronics Niketan, 6-C.G.O. Complex, Lodhi Road, New Delhi- 110003.
5. The P.S to Hon’ble Minister, Information Technology Department, Assam for kind apprisal of
the Hon’ble Minister.
6. All P.S. to Ministers, Assam for kind apprisal of the Hon’ble Ministers.
7
Press Advisor to Hon’ble Chief Minister, Assam
1.

<!-- page 17 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

8. All Principal Secretaries of the Autonomous Councils, Assam.
9. Secretary, Coordination, O/o the Chief Secretary, Assam for kind apprisal of the Chief
Secretary, Assam.

10. All Additional Chief Secretary /Principal Secretary/Commissioner & Secretary/ Secretary to
the Govt. of Assam

11. All Heads of the administrative Departments with a request to instruct all HODs of the
organizations and Sub-Organizations under their control to collect the copy of the same from
their administrative Departments.
12. All Deputy Commissioners of the districts of Assam. He is requested to forward a copy of the
same to Sub-divisional Officers (Civil)/Circle Officers, etc. under his control.
13. The Director, Information and Public Relations, Assam with a request to give wide publicity
through electronic media, newspaper, etc.
14. The Managing Director, Assam Electronics Development Corporation Ltd. with a request to
print the same in the form of booklet and submit 500 copies of it to Information Technology
Department and to upload the same in their websites.
15. The SIO, NIC, Assam State Unit with a request to upload the same in their websites.
16. The Publisher, Assam Government Press, Bamunimaidan, Guwahati-21 with a request to

publish this Notification in the next issue of the Extra-Ordinary Gazette and to submit 250
copies of the Gazette notificatIon after publishing the same.
17. The Director, Directorate of Information Technology & Electronics Communication, Assam

for kind information
18. The Officer-on Special Duty, Political (Cabinet Cell) Department, CM Block, Dispur for kind
information. This has reference to his endorsement dated 24/02/2023.
19. The Head, SeMT with a request to make arrangement to upload in the website of
Inforrnation Technology Department.
20. P.S to the Principal Secretary to the Govt. of Assam, Information Technology Department,
for kind apprisal of the Principal Secretary.
21. P.S to the Secretary to the Govt. of Assam, Information Technology Department, for kind
apprisal of the Secretary.
By order etc.

Joint Secretary to the Govt. of Assam,
Information Technology Department.

<!-- page 18 -->

IT/29/2023-Admin-IT-IT Department
1,''146458/2023

FORM-1
[See Para 5&17]

Application for Permission for Establishing Mobile Tower
To,

The Nodal Officer
District

A

Details of Applicant/Licensee
1. License Details
2. Name of Licensee

3.
4.
5.

Registered Address
Assam Circle Office Address
Name of Authorised Person

6.
7.
8.

Designation of Authorised Person
Phone no/Mobile no of authorized person
Email

9. PIN
The nature of post/tower or other aboveground contrivances
The extent of land required (size and area in meters)

Details and location of land for the site
1. Area type (Urban/Rural)
2. In case of urban area, name of the ULB
3. In case of rural area, name of the Revenue Circle and
GP

4. Complete address of the location of the Mobile Tower
5. District
6. Exact Latitude and Longitude of the Site
E

Details of building or structure of the site, in case the tower is to be established on
building or structure
1. Name of building/structure
2. Height & stories of the building
3. Area of building/structure
4. Complete address of the building/structure
5. District
6. Exact latitude and longitude of the site
Name and address of the owner of fhe land or building
Details of tower/post
e
Ground/Roof

Whether on open plot/building

Pole/wall
mounted

No

Based

Area required

The

latitude

exact

of

antennae
and

longitude of tower/post
H

Other related information

<!-- page 19 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023
The mode of and time duration for, execution of work:

I

The inconvenience that is likely to be caused to the
public and the specific measure to be taken to
mitigate such inconvenience:
3 The measure proposed to be taken to ensure public
safety during the execution of the work:
4 The name and contact details of the employees of the
licensee for the purpose of communication in regard
to the application made. proposed to be undertaken:
5 Any other matter relevant, in the opinion of the
licensee, connected with or relative to the work
proposed to be undertaken:
6 Any other matter specified by DoT, or State Govt. or
the local body:
List of documents attached

Whether attached
(Yes/No)

Copy of licensee granted by DoT
Location Plan – (Scale 1: 1000)

The detailed technical design and drawing of
tower/post or other above ground telecom structure
including the specification of foundation. In case the
tower/post etc is in the vicinity or adjoining to high or
low tension line, drawings showing its distance from
the line
Copy of Structural Stability Certificate
Copy of No-objection Certificate issued by the Fire
Safety Department in case of high rise building where
fire clearance is mandatory
6.

Copy of SACFA clearance/copy of SACFA application
for the said location submitted along with undertaking
as Sub-Para 5 of Para 5

7. Copy of clearance from State Environment & Forest
Department (if Applicable )
8. Acknowledgement receipt issued by TERM Cell of the
self-certificate submitted by licensee.
9.

Copy of Certificate

issued by Automotive

Research

Association of India (ARAI) to the manufacturer of DG
sets

10. Ownership Document of the building site (Attested
Copy)

11. Attested copy of Lease Agreement Deed/Consent
Agreement Deed

12. Copy of relevant License/Infrastructure Provider
Registration Certificate issued from DoT.
13. Copy of No Objection Certificate (NOC) from Building
Owner/entities having roof top rights or roof top
tenants.

14. Prior written consent from the authority having
legitimate right over the land/premises belonging to
Central Govt./PSUs (if Applicable )
15. Any other document

<!-- page 20 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

Declarations
1.

I hereby declare that I have carefully read the "Guidelines for granting Right of Way (RoW)

to Telecommunication Infrastructure in Assam, 2023" . 1 fully comply with the terms and
conditions therein.
2.

3.

I understand this application, if found incomplete in any respect and/or if found with
conditional compliance, shall be summarily rejected.
I understand that after obtaining Letter of Intent (Lol) for this application, I am bound to pay
the

processing

fee

only

through

Assam RoWportal

and thereby

generate

the

RoW

Permission for establishing Mobile Tower in property of Assam State Government.
4.

I declare that if at any time any averments made or information furnished by me is found

incorrect or false, my application shall be liable to be rejected and any permission granted
on the basis of such information/documents shall be liable to be cancelled / rejected.
Date:
Place:

Signature & seal of authorised person with name

<!-- page 21 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

FORM-2
[See Para 6 &18]

Application for Permission/Renewal for Establishing Poles/Intimation for
Establishing Poles

To,

The Nodal Officer
District
A

Details of Applicant/Licensee
License Details
Name of Licensee
Registered Address
Assam Circle Office Address
Name of Authorised Person
Designation of Authorised Person

Phone no/Mobile no of authorized person
Email

9. PIN

Total number of pole(s) to be established
The pole(s) are to be used for (Deployment of Small Cells or
Overground Telecommunication Cable or Both)
D

E

In case the pols is to be used to deploy overground
Telecommunication Cable, specify the length of the
proposed route in KM
Details and location of land for the pole(s)
Area type (Urban/Rural)
In case of urban area, name of the ULB
In case of rural area, name of the Revenue Circle
Office

4. Nature of land where the pole(s) is to be erected
(Government/Public/Private/Mixed, in case of
multiple poles on a route)

o

ress of the pole/Route of the Poles

District
a
a
Watitude
F

tude and Longitude of the Pole 1
and Longitude of the Pole 2
and Longitude of the Pole n

In case pole(s) are to be established in a building, details of building or structure of the
site where pole is to be installed

Name of building/structure
Height & stories of the building
M
f building/structure (Urban/Rural)

<!-- page 22 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023
4. In case of urban Area, name of ULB
5. In case of rural area, name of the Revenue Circle

6. Complete address of the building/structure where
pole(s) is to be established
7. District

I

8. Exact latitude and longitude of the pole(s)
Name and address of the owner/authority of the land or building
Other related information
1. The mode of and time duration for, execution of work:
2. The inconvenience that is likely to be caused to the
public and the specific measure to be taken to
mitigate such inconvenience:
3
The measure proposed to be taken to ensure public
safety during the execution of the work:
4 The name and contact details of the employees of the
licensee for the purpose of communication in regard
to the application made. proposed to be undertaken:
5 Any other matter relevant, in the opinion of the
licensee, connected with or relative to the work
proposed to be undertaken:
6 Any other matter specified by DoT, or State Govt. or
the local body:
List of documents attached
Whether attached
(Yes/No)
Copy of licensee granted by DoT
Location Plan – ( Scale 1:1000)
The detailed technical design and drawing of pole or
other above ground telecom structure including the
specification of foundation. In case the tower/post etc
is in the vicinity or adjoining to high or low tension
line, drawings showing its distance from the line
Copy of Structural Stability Certificate
Copy of No-objection Certificate issued by the Fire
Safety Department in case of high rise building where
fire clearance is mandatory
6
Copy of SACFA clearance/copy of SACFA application
for the said location submitted along with undertaking
as Sub-Para 5 of Para 6
7 Route plan of the proposed pole(s) along with exact
latitude or longitude
8 Copy of clearance from State Environment & Forest
Department (if Applicable )
9 Acknowledgement receipt issued by TERM Cell of the
self-certificate submitted by licensee.
10. Copy of Certificate issued by Automotive

Research

Association of India (ARAI) to the manufacturer of DG
sets

11. Ownership Document of the building site (Attested
CQpy)

12. Attested copy of Lease Agreement Deed/Consent

<!-- page 23 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023
reement Deed

Copy of

relevant

License/Infrastructure

Provider

Regjstration Certificate issued from DoT
o

Owner/entities having roof top rights or roof top
tenants
Prior written

consent

from

the

authority

having

legitimate right over the land/premises belonging to
Central Govt./PSUs (if Applicable )
r

Declarations
1.

I hereby declare that I have carefully read the "Guidelines for granting Right of Way (RoW)

to Telecommunication Infrastructure in Assam, 2023" . 1 fully comply with the terms and
conditions therein.
2.

I understand this application, if found incomplete in any respect and/or if found with

3.

conditional compliance, shall be summarily rejected.
I understand that after obtaining Letter of Intent (Lol) for this application, I am bound to pay

the processing fee only through Assam RoWportal and thereby generate the RoW
Permission for establishing poles in property of Assam State Government.

4.

I declare that if at any time any averments made or information furnished by me is found

incorrect or false, my application shall be liable to be rejected and any permission granted
on the basis of such information/documents shall be liable to be cancelled / rejected.
Date:
Place:

Signature & seal of authorised person with name

<!-- page 24 -->

IT/29/2023-Admin-IT-IT Department
t /146458/2023

FORM-3
[See Para 7 &19]

Application of Use of Street Furniture for Deployment of Small
Cells/Deployment Telecom Line
To,

The Nodal Officer
District
A

Details of Applicant/Licensee
1. License Details
2.

Name of Licensee

3. Registered Address
4. Assam Circle Office Address
5. Name of Authorised Person

6. Designation of Authorised Person
7. Phone no/Mobile no of authorized person
8.

Errlail

9.

PIN

B

Name of the appropriate authority having legitimate right
over the street furniture

C

Purpose of utilising street furniture (installation of small cell/
telecom cable or both)

D

In case the street furniture is to be used to deploy
overground Telecommunication Cable, specify the length of
the proposed route in KM
Details of the street furniture

E

1

Type(s) of street furniture to be used (Electricity pole/

street light pole/bus shelter/other)
No of street furniture

F

Latitude & Longitude of Street Furniture 1
Ha tude & Longitude of Street Furniture 2
WIde & Longitude of Street Furniture n
Details of the location of the street furniture
Area type (Urban/Rural)

Name of the city/town/revenue village where the

G

street furniture is located
Name of the Revenue Circle
District
Other related information
The mode of and time duration for, execution of work:
The inconvenience that is likely to be caused to the
public and the specific measure to be taken to
mitigate such inconvenience:
3. The measure proposed to be taken to ensure public

<!-- page 25 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

safety during the execution of the work:
4. The name and contact details of the employees of the
licensee for the purpose of communication in regard
to the application made. proposed to be undertaken:

5. Any other matter relevant, in the opinion of the

H

licensee, connected with or relative to the work
proposed to be undertaken:
6. Any other matter specified by DoT, or State Govt. or
the local body:
List of documents attached

Whether attached
(Yes/No)

Copy of licensee granted by DoT
Photographs of the street furniture to be used

The location showing the proposed route plan of
street furniture along with exact latitude and
longitude.
4.

Detailed technical designed for establishing/laying
Telecommunication infrastructure on the street
furniture.
5. No Objection Certificate from the appropriate
authority having legitimate right over the street
furniture
6. Copy of structural safety certificate obtained from
authorized Structural Engineer or/from recognized
institute or a Structural Engineer registered or
employed in Central or State Government service or
any Quasi-Government
7.
8.

9.

body or any other agency

authorized by Government from Hme to time
Copy of clearance from State Environment & Forest
Department (if Applicable )
In case of small cells, copy of SACFA clearance
certificate/ SACFA application for the location where
the street furniture to be used along with undertaking
as per Sub-Para 6 of Para 7
In case of small cells, self-declaration by licensee in
respect of street furniture /Base Transceiver System
that all general public areas around the tower shall be
within

safe

Electro

Magnetic

Radiation

(EMR)

exposure limit as per peak traffic measurement after
the antenna starts radiating. (if applicable)
10. In case of small cells, copy of type test certificate
issued by Automotive Research Association of India
(ARAI) to the Diesel/Petrol Generator manufacturer of
the DG/PG set to be installed along with the street
furniture, if the same is to be installed (if applicable)
11- Any other document

<!-- page 26 -->

IT/29/2023-Admin-IT-IT Department
1,'146458/2023

Declarations
1.

I hereby declare that I have carefully read the "Guidelines for granting Right of Way (RoW)

to Telecommunication Infrastructure in Assam, 2023" . 1 fully comply with the terms and
conditions therein.
2.

I understand this application, if found incomplete in any respect and/or if found with

3.

conditional compliance, shall be summarily rejected.
I understand that after obtaining Letter of Intent (Lol) for this application, I am bound to pay

the processing fee only through Assam RoWportal and thereby generate the RoW
Permission.

4.

I declare that if at any time any averments made or information furnished by me is found

incorrect or false, my application shall be liable to be rejected and any permission granted
on the basis of such information/documents shall be liable to be cancelled / rejected.
Date:
Place:

Signature & seal of authorised person with name

<!-- page 27 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

FORM-4
[See Para 8&20]

Application for Permission for Laying Underground Telecommunication
Infrastructure
To,

odal Officer
District

A

Details of Applicant/Licensee

1. Licensee details
2. Name of the licensee
3. Registered Address
4. Assam Circle Office Address

5. Name of the authorized person
6. Designation of the authorized person
7. Phone no/mobile no of the authorized person

8. Email
9. Pin
B

Details of the proposed work to be laid

1. Total Length of the proposed work (in KM)
2.

Location type (Urban/Rural)

3.

Name of the ULB/Revenue Circle Office (if,
location type is Urban, the name of the ULB,
else, name of the revenue circle offIce)

<!-- page 28 -->

IT/29/2023-Admin-IT-IT Department
1,,’146458/2023

4.

Route under jurisdiction (PWD NH/PWD
Roads/PWD RR/ULB/GP/VCDC)

5.

Route planned for the proposed work [From
(latitude&longitude)..__to (latitude,
longitude)]

6. Methodology for execution of the proposed
work (Horizontal Directional Drilling
(HDD)/Ducting & Trenching/Mini Trenching/
Micro Trenching/Other)
7.

Location details including ward No. colony
etc.

C

Whether attached

List of enclosure

(Yes/No)

1. Copy of license granted by the DoT

2. The route map showing details of
underground OFC with exact latitude and
longitude (Including detailed information for

the route)
3. Copy of clearance from State Environment &
Forest department (if applicable)

4.

Copy of consent of the owner of the

land/building where the OFC infrastructure is
proposed to be laid (if applicable)
D

Other information for the proposed work
1. The details of land or structures where the laying of
OFC infrastructure

is proposed

2.

The time duration for execution of the work

3.

The time of the day when the work is expected to
bedone in case the applicant expects the work to
L>edone during specific time of the day.
The inconvenience that is likely to be caused to
thepublic and the specific measures proposed to

4.

betaken to mitigate such inconvenience.

<!-- page 29 -->

IT/29/2023-Admin-IT-IT Department
1,,'’146458/2023

5. The specific measure proposed to be taken to
ensure public safety during the execution of the
work.
Any other matter relevant in the opinion of the
licensee connected with or relative to the work
proposed to be undertaken
Any other information required under any order
ofDoT, State Govt. or Local Body

Declarations
5.

I hereby declare that I have carefully read the "Guidelines for granting Right of Way (RoW)

to Telecommunication Infrastructure in Assam, 2023" . 1 fully comply with the terms and
conditions therein.
6.

I understand this application, if found incomplete in any respect and/or if found with
conditional compliance, shall be summarily rejected.

7.

I understand that after obtaining Letter of Intent (Lol) for this applicatIon, I am bound to pay
the processing fee only through Assam RoWportal and thereby generate the RoW

Permission.
8.

I declare that if at any time any averments made or information furnished by me is found
incorrect or false, my application shall be liable to be rejected and any permission granted
on the basis of such information/documents shall be liable to be cancelled / rejected.

Date:
Place:

Signature & seal of authorised person with name

<!-- page 30 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

FORM-5
[See Para 17]
OFFICE OF THE NODAL OFFICER:: DISTRICT NAME

[Permission for Establishment of Mobile Towers)
Dated.

Case No.
To,

Licensee Details
Licensee Address

Sub:

Grant of permission under Para 17 of the “Guidelines for Granting Right of Way to
Telecommunication Infrastructure in Assam, 2023”
(1) The above applicant/licensee has applied to accord permission for establishment of mobile

towers under Para 5 of the “Guidelines for Granting Right of Way (RoW) to
Telecommunication Infrastructure in Assam, 2023" issued by Government of Assam. The
permission has been applied on the land or building mentioned below.
Details of Location

(2)

Details

of

/Buildi

Structure

Area Required Sq

Plot/Land I Site ID

Meter

That, I have examined the application and documents/statements submitted by the
applicant/licensee. I am on the opinion that the desired permission is consonance with
provisions of above-mentioned Rules and guidelines.

(3)

Therefore, I hereby grant the permission establishment of following mobile towers on the
aforementioned land or building.
Item

Details

The type of tower and location including exact
latitude and longitude of the mobile tower
The extent of land required for establishment of the
mobile tower
The details of land or building

The mode and time duration for execution of work
(4) The permission is granted on following terms and conditions: a. The radiation norms fixed by DoT have to be strictly followed by the licensee. Any citizen
can approach the DoT, Assam LSA with regard to grievance on any issue relating to
radiation

<!-- page 31 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023
b. Sign boards and Warning Signs ("Danger", "Warning", "Caution", etc.) as per guidelines

of DoT shall be provided at towers and antenna sites which are clearly visible and
identIfiable

c.

In the walled city area or in the area of Heritage importance the tower shall be designed

keeping in view the Heritage character of the area.

d. The licensee shall ensure the measure of public safety and mitigation public
inconvenience while establishing the mobile tower.
e. The licensee shall fix the equipmentwhich cause minimum noise and environmental
pollution for power back-up in the earmarked boundary adjacent to mobile tower.
f.

The structural stability of the towersand building in which it is established, shall be
ensured by the licensee and the towers and their foundations

shall be designed

accordingly.

(5) This permission shall be valid from this date up-to the period of license granted to the
licensee.

The permission is granted on this date (mention the date) under signature and seal of the
undersigned.

Name of the Nodal Officer

Nodal Officer-RoW
District Name

<!-- page 32 -->

IT/29,/2023-Admin-IT-IT Department
1/146458/2023

FORM-6
[See Para 18]
OFFICE OF THE NODAL OFFICER :: DISTRICT NAME

[Permission for Establishment of Poles)
Case No.

Dated.

To,

Licensee Details
Licensee Address

Sub:

Grant of permission under Para 18 of the “Guidelines for Granting Right of Way to

Telecommunication Infrastructure in Assam, 2023”
(1) The above applicant/licensee has applied to accord permission for establishrnent of poles for
deployment of Small Cells/Telecommunication Cable under Para 6 of the “Guidelines for
Granting Right of Way (RoW) to Telecommunication Infrastructure in Assam, 2023” issued by
Government of Assam. The permission has been applied for the following purpose.
Nos of poles to

be

be
used
for
Telecommunication Cable

To be used for Small I Site ID, if any

To

Cells

deployed

Mention the number Yes/No

Yes/No, if yes, length of
the route

of poles

That, I have examined the application and documents/statements submitted by the
applicant. I am on the opinion that the desired permission is consonance with provisions of
above-mentioned Rules and guidelines.
(3) Therefore, I hereby grant the permission establishment of following poles on the following
(2)

location:
Item
The exact latitude(s) and longitude(s) of the pole(s)

Details

The land owner/authority of the pole
The mode and time duration for execution of work

(4) The permission is granted on following terms and conditions: a. The radiation norms fixed by DoT have to be strictly followed by the licensee. Any citizen
can approach the DoT, Assam LSA with regard to grievance on any issue relating to
radiation.

b. Sign boards and Warning Signs ("Danger", "Warning", "Caution", etc.) as per guidelines

of DoT shall be provided at poles and antenna sites which are clearly visible and
identifiable
c.

In the walled city area or in the area of Heritage importance the Pole shall be designed
keeping in view the Heritage character of the area.

d. The licensee shall ensure the measure of public safety and mitIgation public
inconvenience while establishing the pole(s)

<!-- page 33 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

e. The licensee shall fix the equipment which cause minimum noise and environmental
pollution for power back-up in the earmarked boundary adjacent to the pole.
f. The structural stability of the pole(s) and building in which it is established, shall be
ensured by the licensee and the pole(s) and their foundations shall be designed
accordingly.
(5) This permission shall be valid from this date up-to the period of license granted to the
licensee.

The permission is granted on this date (mention the date) under signature and seal of the
undersigned.

Name of the Nodal Officer
Nodal Officer-RoW

District Name

<!-- page 34 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

FORM-7
[See Para 19]
OFFICE OF THE NODAL OFFICER :: DISTRICT NAME

[Permission for Use of Street Furniture)
Case No.

Dated.

To,

Licensee Details
Licensee Address

Sub:

Grant of permission under Para 19 of the "Guidelines for Granting Right of Way to

Telecommunication Infrastructure in Assam, 2023”

(1) The above applicant/licensee has applied to accord permission use of street furniture for
deployment of Small Cells/Telecomrnunication Cable under Para 7 of the “Guidelines for
Granting Right of Way (RoW) to Telecommunication Infrastructure in Assam, 2023” issued by
Government of Assam. The permission has been applied for the following purpose.

No of street furniture to be
Mention the number of street
furniture

(2)

for

To be used for Small Cells

To

Yes/No

Yes/No, if yes, length of the
route

used

be

used
Telecommunication Cable

That, I have examined the application and documents/statements submitted by the
applicant and the concerned authority of the street furniture has reported no objection for
use of these furniture. I am on the opinion that the desired permission is consonance with
provisions of above-mentioned Rules and guidelines.

(3) Therefore, I hereby grant the permission use of street furniture on the following locatIon:

Item

Details

The exact latitude(s) and longitude(s) of the street
furniture
The land owner/authority of the street furniture
The mode and time duration for executIon of work
(4) The permission is granted on following terms and conditions: -

a. While deploying Telecommunication Infrastructure on any street furniture, the licensee
shall ensure proper use of the furniture. In case any damage of the furniture due to the
infrastructure of licensee or while carrying out the deployment work, the licensee is
bound to repair the damages incurred.
b. The radiation norms fixed by DoT have to be strictly followed by the licensee. Any citizen
can approach the DoT, Assam LSA with regard to grievance on any issue relating to
radiation.

c. The licensee shall ensure the measure of public safety and mitigation public
inconvenience while deploying telecommunicatIon infrastructure over street furniture

<!-- page 35 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023
d. The licensee shall fix the equipment which cause minimum noise and environmental
pollution for power back-up in the earmarked boundary adjacent to the pole.
e. The structural stability of the street furniture, shall be ensured by the licensee and the
pole(s) and their foundations shall be designed accordingly.
(5)

This permission shall be valid from this date up-to the period of license granted to the
licensee

The permission is granted on this date (mention the date) under signature and seal of the
undersigned.

Name of the Nodal Officer

Nodal Officer-RoW
District Name

<!-- page 36 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023

FORM-8
[See Para 20]
OFFICE OF THE NODAL OFFICER :: DISTRICT NAME

[Permission for Laying Underground Telecommunication Infrastructure)
Case No.

Dated.

To,

Licensee Details
Licensee Address

Sub:

Grant of permission under Para 20 of the “Guidelines for Granting Right of Way to

Telecomrnunicatlon Infrastructure in Assam, 2023"

(1) The above applicant/licensee has applied to accord permission for laying of underground
Telecommunication Infrastructure under Para 8 of “Guidelines for granting Right of Way to
Telecommunication Infrastructure in Assam, 2023”. The permission has been applied for the
route mentioned below:
Details of the Route
Location Type=(Urban/Rural), Revenue Circle Name/ULB
Name=(ULB/CO), Route Start at= (Lat &; Long), Route Ends at = (Lat

Total Length (in KM)

&; Lon
(2)

That, I have examined the applicatIon and documents/statements submitted by the
applicant/licenseeHe/She has deposited the necessary fee and charges I have examined the
reports received from LocaIBody and field agencies. I am of the opinion that the desired
permission is consonance with provisions ofabove mentionedguidelines.

(3)

Therefore, I hereby grant the permission for establishment of following underground
Telecommunication Infrastructure on the land or building herein above mentioned.
Item

Details

Methodolo: for execution of proposed work
The tIme of the way when work is to be done
(4) The permission is granted on following terms and conditions:a. The work shall he started from the outer areas of the city and then to the core area
b. Damages of roads/lands/structure and filling up of pits caused during the laying of
underground Telecommunication Infrastructure and taking fibre to home will be

repaired by the concerned authorityand the entire expenses, for restoratIon of
damaged road portion shall be charged by the concerned authority from the
licensee. Charges for such expenses shall be fixed by the State Government
fromtime to time, on the basis of applicable schedule of rates for works for similar
nature. The BSRand guidelines issued by the PWD shall be followed for calculating
the restoration charges. Suchcharges shall be deposited in advance in the form of
valid applicable financial instrument/digitalpayment mode within a period of 30

<!-- page 37 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023
days from the date of grant of the permission and prior tothe commencement of
work of laying the underground telecommunication infrastructure. An amount equal
to 20%of the restoration charges as security shall be taken (in lieu of expenses for
restoration)

C.

priorto

the commencement

of such work

in the form of a Bank

Guarantee valid for one year if thelicensee has undertaken to discharge the
responsibility of restoration of damagedroad/land/structure portion.
Laying OFC through Micro- Trenching Method shall be allowed during monsoons,
provided thatthe applicant takes all security measures and makes arrangements for
immediate restoration ofthe damage caused.

d.

Supervision of the work :-

i.

The Nodal Officer, or any officer authorised by the appropriate authority,
may supervise theexecution of work to ascertain if the conditions imposed
under the guidelines.

11.

iii.

The Nodal Officer may, on the basis of such supervision, impose such other
reasonableconditions as it may think fit.
If the Nodal Officer comes to the conclusion that the licensee has willfully

violated any of theconditions, it may forfeit, in full or in part, the bank
guarantee submitted by the licensee andwithdraw the permission, for
reasons to be recorded in writing:Provided that no actIon shall be taken
under

this

clause unless the

licensee has been

given areasonable

opportunity of being heard
e.

Only pits of approximate size 1.5mtr.xl.5mtr.xl.5mtr. depth or as per requirement
at site shallbe excavated in the roads where optical fiber cables are to be laid, at the
distance of not lessthan 100 meter. The pits shall be refilled only with granular
material and shall be compacted asper the specifications. The pits/trenches shall be
reinstated within 48 hours, repeat shall bereinstated within 48 hours, after the work

f.

at that location is over, failing which, penalty asapplicable as per the guidelines for
trenching activities shall be applicable besides thecancellation of permission etc.
Number of ducts under the roads for which permission will be granted be as per
requirementof the licensee

The licensee shall ensure provision of positional intelligence, through appropriate
technology, ofall underground telecommunication infrastructures to enable the local
body to obtain real timeinformation on its location.
h. The licensee will carry out Ground Penetrating Radar (GPR) survey wherever

g.

necessary along theroute where the ducts will be laid for detection of existing
utilities. The data of utilities collectedby the licensee through GPR survey should be
unconditionally shared with Local Body, free ofcost.
1.

No damage shall be caused to any underground utilities while laying the ducts by
usingHorizontal Directional Drilling (HDD) methodology. In case any utility is
damaged, the damage socaused to the utilities, shall be rectified by the licensee at
his own cost.

J.

Ducts shall be laid approximately 2mtrs below the road crust. However, in case of
Had Rock, where HDD methodology is not possible, the depth of approx. 400 mm.
shall bemaintained with the duct installed inside G.I. Pipe covered with PCC 71.

<!-- page 38 -->

IT/29/2023-Admin-IT-IT Department
1/146458/2023
k. The cost of shifting conduits/OFC, wherever required, shall be borne by the licensee

andinstructions of Local Body in this respect shall be complied within the time frame
fixed by theconcerned Local Body.

I.

Local Body or concerned authority of the route of the infrastructure shall not be
responsible for any damage to OFC and resultant losses, if any, due to anyact of
employee of Govt. or Local Body, while performing official duties. However, prior
writtenintimation will be given by the Local Body or concerned authority to the
licensee.

m. The licensee shall make proper arrangement for access control of the chambers to
avoidmisuse/illegal use of ducts and the chambers.
n. The licensee shall ensure that

i.

prior to the commencement of work of laying the optical fibre and at all
times during theexecution of the work, the measures to mitigate public

ii.

The work of laying OFC/telecommunication

inconvenience and provide for publicsafety are implernented;
infrastructure

is carried out in

accordance with the conditions specified under the guidelines and order
made thereunder.

(5) This permission shall be valid from this date up-to the period of license granted to the
licensee

The permission is granted on this date (mention the date) under signature and seal of the
undersigned.

Name of the Nodal Officer

Nodal Officer-RoW
District Name

<!-- page 39 -->

IT/29/2023-Admin-IT-IT Department
1/146458,,'’2023

FORM-9
[See Para 28]

[Digitisation of Existing Overground Telecommunication Infrastructure’s
Record)
(1) Infrastructure Details

a. Type of Overground Telecommunication Infrastructure: Mobile Tower/Pole
b. Name of the District where installed: Enter the name of the district
c. Latitude and Longitude:
d. Address of the infrastructure:
e.

lsfiberized: Yes/ No

f.

Iffiberized, enter the bandwidth allocated in MB:

g. No of antenna installed:
h.

No of Base Transceiver Installed:

(2) Administrative Details

a. Submit the manual permission/NoC/Clearance Certificategranted to the infrastructure:
b. Submit the proof of payment for getting permission for the infrastructure:

Declarations
1.

I hereby declare that I have carefully read the "Guidelines for granting Right of Way (RoW)
to Telecommunication Infrastructure in Assam, 2023" . 1 fully comply with the terms and
conditions therein.

2.

I hereby declare that above information furnished by me is true to the best of my
knowledge.

Date:
Place:

Signature & seal of authorised person with name

<!-- page 40 -->

V

IT/29/2023-Admin-IT-IT Department
1/146458/2023

FORM-10
[See Para 28]

[Digitisation of Existing Overground/Underground Telecommunication
Cable’s Record)
(1)

Infrastructure Details
a. Type of Cable: Underground/Overground
b. Name of the District where installed: Enter the name of the district
c. Start and End Latitude & Longitude
d. Start and End address of the infrastructure:

(2)

Administrative Details
a. Submit the manual permission/NoC/Clearance Certificate granted to the infrastructure:
b. Submit the proof of payment for getting permission for the infrastructure:

Declarations
1.

I hereby declare that I have carefully read the "Guidelines for granting Right of Way (RoW)

to Telecommunication Infrastructure in Assam, 2023" . 1 fully comply with the terms and
conditions therein.
2.

I hereby declare that above information furnished by me is true to the best of my
knowledge.

Date:
Place:

Signature & seal of authorised person with name
