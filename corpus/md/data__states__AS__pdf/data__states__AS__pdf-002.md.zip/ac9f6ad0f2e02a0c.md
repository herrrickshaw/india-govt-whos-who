---
doc_id: "ac9f6ad0f2e02a0c"
source_url: "https://rural.assam.gov.in/sites/default/files/public_utility/CPRD%20Office%20Order_IT%20Based%20Professionals_Posting.pdf"
ministry: "Commissionerate of Rural Development, Assam"
title: "CPRD Office Order_IT Based Professionals_Posting"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "25b243de2e229921"
---

<!-- page 1 -->

CPRD-ESTC0SLCE(GC)/2/2024-EST-CP&RD-Commissionerate Of Panchayat & Rural Development Department

I/1201076/2025

OFFICE ORDER
No.577222/I/1201076/2025
Dated: 11-08-2025
In continuation of this oﬃce’s earlier Notice vide no. No. E-577222/ I/
1084519/2025, dated 26-05-2025 and No. E-577222/I/1169034/2025, dated 20-072025, the candidates selected under the recruitment of “IT Based Professionals”
have been posted as Assistant District Programme Manager/IT Assistant purely on
a contractual basis under the Mahatma Gandhi National Rural Employment
Guarantee Act (MGNREGA), Social Assistance Program (SAP), and Pradhan
Mantri Awaas Yojana – Gramin (PMAY-G). They have been posted at diﬀerent
district Zilla Parishads, DRDAs, and the Commissionerate of Panchayat & Rural
Development Department, Government of Assam, as per following districts and
programs.
Sl. Candidate
No. Name

Place of Posting

Posted
under
Scheme
O/o the CEO, Biswanath
SAP
Zilla Parishad

1

Hirakjyoti
Sharma

2

Himangshu
Choudhury

O/0 the PD, DRDA, Baksa

SAP

3

Tridip Sharma

O/o the CEO, Dibrugarh
Zilla Parishad

MGNREGA

4

Gunenja
O/o the CEO, Tinsukia Zilla MGNREGA
Gobinda Gohain
Parishad

5

Semima Hussain O/o the CEO, Sonitpur Zilla
Akhtar
Parishad

SAP

6

Kasturiniva Das

SAP

7

Pranati Kalita

O/o the Commissioner,
P&RD
O/o the CEO, Morigaon
Zilla Parishad

8

Pinki Pathak

O/o the CEO, Kamrup
Metro Zilla Parishad

SAP

9

Manash Pratim O/o the CEO, Kamrup Zilla

SAP

SAP

Designation

Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
IT Assistant
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District

<!-- page 2 -->

CPRD-ESTC0SLCE(GC)/2/2024-EST-CP&RD-Commissionerate Of Panchayat & Rural Development Department

Pathak

Parishad

10

Meraj Hussain

O/o the CEO, Jorhat Zilla
Parishad

SAP

11

Champak
Barman

O/o the CEO, Nalbari Zilla
Parishad

PMAY-G

12

Upanga Pathak O/o the CEO, Barpeta Zilla
Parishad

13

Nikita Barman

O/o the CEO, Kamrup
Metro Zilla Parishad

MGNREGA

14

Saurav Nandi

O/o the CEO, Bongaigaon
Zilla Parishad

SAP

15

Nisha Rani
Chamuah

O/o the CEO, Morigaon
Zilla Parishad

PMAY-G

O/o the PD, Kokrajhar
DRDA

SAP

16 Mwnthai Narzary

SAP

17 Bhaben Chandra O/o the CEO, Nalbari Zilla
Das
Parishad

SAP

18

Hanif Zafor

O/o the CEO, Dhubri Zilla
Parishad

SAP

19

Ajay Basfor

O/o the PD, Udalguri
DRDA

SAP

O/o the CEO, Lakhimpur
Zilla Parishad

SAP

20 Emdadul Hoque

21

Dipankar Saikia O/o the CEO, Dhemaji Zilla
Parishad

PMAY-G

22

Mahfuz Ahmed O/o the CEO, Cachar Zilla
Barbhuiya
Parishad

SAP

23

Atanu
Bhattacharjee

O/o the CEO, Sribhumi
Zilla Parishad

PMAY-G

24

Bibek Deka

O /o the CEO, Hojai Zilla
Parishad

SAP

25

Kishore Kanti
Roy

O/o the CEO, Hailakandi
Zilla Parishad

SAP

26

Tepa Narzary

O/o the PD, DRDA

PMAY-G

I/1201076/2025

Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District

<!-- page 3 -->

CPRD-ESTC0SLCE(GC)/2/2024-EST-CP&RD-Commissionerate Of Panchayat & Rural Development Department

Tamulpur
27

Monideep
Phukon

O/o the CEO,Sivasagar
Zilla Parishad

SAP

28

Hainary
Basumatary

O/o the PD DRDA Chirang

SAP

29

Bitumani
Talukdar

O/o the CEO, Darrang Zilla
Parishad

SAP

30

Mintu Kalita

O/o the CEO, Goalpara
Zilla Parishad

MGNREGA

31

Arunima Ahom O/o the CEO, Nagaon Zilla
Parishad

32 Dhruvajyoti Das

SAP

O/o the PD, DRDA
Tamulpur

MGNREGA

33

Dhiman
Choudhury

O/o the CEO, Hojai Zilla
Parishad

PMAY-G

34

Rahul Kumar
Talukdar

O/o the PD, DRDA Dima
Hasao

PMAY-G

35

Tauhidul Islam
Siddiki

O/o the CEO, Biswanath
Zilla Parishad

MGNREGA

36

Supratim Das

O/o the CEO, Sribhumi
Zilla Parishad

MGNREGA

37

Smritirekha
Sarma

O/o the PD, DRDA Karbi
Anglong

SAP

38

Mahmudul
Hassan

O/o the CEO, South
Salmara Mankachar Zilla
Parishad

SAP

39

Kripalaxmi
Bhuyan

O/o the CEO, Dibrugarh
Zilla Parishad

SAP

40

Pratap Jyoti
Saikia

O/o the CEO, Majuli Zilla
Parishad

SAP

41

Lalita Osga

O/o the CEO, Golaghat
Zilla Parishad

SAP

42

Amrit Jyoti
Bhuyan

O/o the CEO, Tinsukia Zilla
Parishad

PMAY-G

I/1201076/2025

Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager

<!-- page 4 -->

CPRD-ESTC0SLCE(GC)/2/2024-EST-CP&RD-Commissionerate Of Panchayat & Rural Development Department

43

Bandana Saud

O/o the CEO, Charaideo
Zilla Parishad

PMAY-G

44

Mustak Asaduz
Jaman

O/o the CEO, Sribhumi
Zilla Parishad

SAP

45

Nawaz Uddin
Ahmed

O/o the CEO, Majuli Zilla
Parishad

MGNREGA

46

Alakesh Baruah

O/o the CEO, Charaideo
Zilla Parishad

SAP

47

Arnab Kumar
Sarma

O/o the CEO, Dhemaji Zilla
Parishad

SAP

48

Mohd Abdur
Rakwib Laskar

O/o the CEO, Cachar Zilla MGNREGA
Parishad

49

Santu Kumar
Paul

O/o the PD, DRDA Dima
Hasao

SAP

50

Uday Saikia

O/o the CEO, Lakhimpur
Zilla Parishad

PMAY-G

51

Abu Shyama
Siddique

O/o the PD, DRDA West
Karbi Anglong

MGNREGA

52 Ashiqur Rahman O/o the PD, DRDA West
Karbi Anglong

PMAY-G

I/1201076/2025

Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager
Assistant District
Programme
Manager

The candidates are hereby directed to report to the assigned place of
posting within 15 working days from the date of issuance of this order. The
candidates thereafter, have to attend O/o the Commissioner, P&RD for signing
Agreement of Contract and to participate induction programme cum training for
which a separate intimation will be sent in due course of time.

Memo No.: 577222/I/1201076/2025
Copy to:

Commissioner
Panchayat & Rural Development,
Assam
Dated: 11-08-2025

1. The Chief Executive Officers (All) Zilla Parishads, for favour of kind
information and necessary action.
2. The Project Director, (All) DRDAs for favour of kind information and
necessary action.

<!-- page 5 -->

CPRD-ESTC0SLCE(GC)/2/2024-EST-CP&RD-Commissionerate Of Panchayat & Rural Development Department

3. PS to the Hon’ble Minister, Panchayat & Rural Development, Assam, for kind
appraisal of the Hon’ble Minister.
4. PS to the Additional Chief Secretary to the Govt. of Assam, Panchayat &
Rural Development for kind appraisal of the Additional Chief Secretary.
5. The Joint Commissioner (All), O/o the Commissioner, P&RD, Assam, for
information.
6. The Project Manager, HRMS Cell, O/o the Commissioner, P&RD, Assam, for
information and necessary action.
7. Person concerned.
(E-signed)
Commissioner
Panchayat & Rural Development, Assam

I/1201076/2025
