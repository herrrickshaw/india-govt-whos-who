---
doc_id: "e72aca2ddadbfff1"
source_url: "https://gad.assam.gov.in/sites/default/files/public_utility/Executive%20Order%207-9-2026.pdf"
ministry: "General Administration Department, Assam"
title: "Guidelines / Process relating to entitlement of benefits in respect of the “Lok Sewa Puraskar” awardees during the extended period of service acquired by virtue of the award."
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "48bf11f25eed8e09"
---

<!-- page 1 -->

GAD-16016/37/2025-ESTT-GAD-General Administration Department

I/1743459/2026

GOVERNMENT OF ASSAM
GENERAL ADMINISTRATION (A) DEPARTMENT
DISPUR:::::::GUWAHATI-6
Block-A, 2nd Floor, Janata Bhawan, gadassam2011@gmail.com, gad.assam@gov.in
ORDER BY THE GOVERNOR OF ASSAM
EXECUTIVE ORDER
No.GAD-16016/37/2025 (ecf No.634636)

Dated:- As on e -sign.

SUBJECT: Guidelines / Process relating to entitlement of benefits in respect of the “Lok Sewa Puraskar”
awardees during the extended period of service acquired by virtue of the award.

The Lok Sewa Puraskar is a State-level award instituted by the Government of Assam to
recognize extraordinary, exemplary, and innovative contributions made by non-gazetted employees
(excluding teachers). The award was originally introduced in 2022 as the Karmachari Award and was
subsequently renamed as the Lok Sewa Puraskar vide Notification No. GAG(A).66/2021/36 dated
20th July, 2022. The award is conferred annually on 5 th August (Lok Kalyan Divas) in honour of Lokapriya
Gopinath Bordoloi. Each year, maximum of 5 awardees are selected from each district and 10 at the State level,
based on their service performance. As per Finance Department OM No. FSI.17/2022/10 dated 14-12-2022,
“Lok Sewa Puraskar” awardees are entitled to a one-year extension of service beyond superannuation. The
General Administration Department (GAD), vide OM No. 299720/1 dated 29-05-2023, was empowered to
accord approval of both State and District-level awardees for such extension.
Recently, it has been brought to the notice of the Government that Heads of Office/Department, and
Administrative Departments are facing difficulties in processing the entitlements of “Lok Sewa Puraskar”
awardees during their extended service period. The absence of a uniform procedure has caused delays and
administrative uncertainty.
The Government of Assam, after much consideration and due consultation with Finance and Personnel
Department has come up with the following guidelines / procedures in respect of the awardees during extended
period of service acquired by virtue of the award, in alignment with the Executive order issued by Finance (SIU)
Department vide No.654648/494 dated: 30-01-2026 read with addendum issued vide No. 654648/577 Dated:
05-05-2026.
I.

Period of engagement :1)

The employee conferred with the Lok Sewa Puraskar (both District and State Level) shall be reemployed for only a period of 1 (one) year beyond the date of superannuation.

2)

As the extended period shall be treated as re-employment only, neither annual increment nor any
promotional benefit shall be awarded to the awardees during the period of such re-employment.

3)

The period of re-employment shall not be counted as qualifying service for pension &
pensionary benefits.

II.

Remuneration :1) During the period of re-employment, the incumbent shall get last pay minus pension plus DA.
The re-employed employee shall not be entitled to any benefits viz GPF, GIS and other
additional allowances.

III.

Procedures of engagement: 1) The Heads of Office/Head of Department shall intimate the list of such employees entitled for
extension to the General Administration Department through their respective Administrative
Departments not less than 12 months prior to the date of his/her superannuation for approval in

<!-- page 2 -->

GAD-16016/37/2025-ESTT-GAD-General Administration Department

I/1743459/2026

terms of Finance Department’s OM No. FSI.17/2022/10 dtd 14-12-2022 &OM No.299720/1
dated 29-05-2023.
2) Once the approval for the extension of service beyond the date of superannuation is received
from the General Administration Department for a case, thereafter a supernumerary post shall
have to be created, which shall be personal to the incumbent. Proposal for the same has to be
moved to Finance Department by concerned Administrative Department, observing all required
formalities on time to avoid undue delay.
3) All categories of awardees so re-employed shall be designated as “ Lok Sewa Awardee” and the
re-employment shall be made against supernumerary posts in the same office to be created for
the period of re - employment which shall be personal to the incumbent, and in the same
assignment, preceding his/her retirement.
IV.

Promotion of other employees:1) Under no circumstances, in service promotion of any employee should be affected due to reemployment of retired government officer/ employees in any department/ office.

All such cases shall henceforth be regulated in accordance with this Executive Order and shall
have retrospective effect, that is from the date from which the OM No.FSI.17/2022/10 dated 14-122022 has been issued.
The above guidelines and procedures shall be strictly adhered to by all authorities without exception.

Secretary to the Government of Assam
General Administration Department.
Memo No. NoNo.GAD-16016/37/2025 (ecf No.634636) -A
Dated:- As on e -sign.
Copy forwarded for information & necessary action to:1. The Commissioner & Secretary to Hon’ble Governor, Assam for kind apprisal of the Hon’ble Governor.
2. PPS to the Hon’ble Chief Minister, Assam for kind apprisal of the Hon’ble Chief Minister.
3. PS to the Hon’ble Ministers (All) for kind apprisal of the Hon’ble Ministers.
4. The SO to the Chief Secretary, Assam, Dispur for favour of kind apprisal of the Chief Secretary.
5. All Special /Additional Chief Secretaries to Govt. of Assam for kind information.
6. The DGP, Assam for kind information.
7. The A.G. (A&E), Assam, Maidamgaon, Beltola, Ghy – 29 for kind information.
8. All Principal Secretaries / Commissioner & Secretaries/Secretaries to the Govt. of Assam.
9. All Administrative Departments.
10. All District Commissioners/ SSPs.
11. All Co-District Commissioners/SDO (C).
12. All HoDs/HoOs.
13. The Director, Assam Government Press, Bamunimaidam, Guwahati-21 for publication of this Executive
Order in the next issue of the Assam Gazette with request to supply 300 copies to the Department
immediately.
14. The Under Secretary to the Govt. of Assam, Finance (SIU) Department, Dispur, Guwahati-6. This has a
reference to his endorsement in e-file No. 654648.
By order etc.,

Additional Secretary to the Government of Assam
General Administration Department.
