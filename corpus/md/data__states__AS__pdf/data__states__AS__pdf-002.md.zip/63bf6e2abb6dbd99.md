---
doc_id: "63bf6e2abb6dbd99"
source_url: "https://irrigation.assam.gov.in/sites/default/files/public_utility/Promotion%20order%20of%20Shri%20Pabitra%20Engti%20to%20CE%28Minor%20Irrig%29.pdf"
ministry: "Irrigation Department, Assam"
title: "Promotion order of Shri Pabitra Engti to CE(Minor Irrig)"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "602bd01f138b61bd"
---

<!-- page 1 -->

IGN-14015/1/2026-ESTT-IRRIGATION-Irrigation Department

I/1801073/2026

GOVERNMENT OF ASSAM
IRRIGATION DEPARTMENT : ESTABLISHMENT BRANCH
DISPUR : GUWAHATI – 781006
ORDERS BY THE GOVERNOR
NOTIFICATION
Dated Dispur, 12-10-2026
No. IGN(E)764050/147:

-

In the interest of public service, Shri Pabitra Engti,

Additional Chief Engineer cum Council Head of Department, Irrigation, Karbi
Anglong Autonomous Council, Diphu is hereby promoted to the rank of Chief
Engineer in Irrigation Department, AssamDepartment and allowed to oﬃciate in the said
rank in the scale of pay of Rs. 30,000/- to Rs. 1, 10,000/- (PB-4) with Grade Pay of Rs.
17,500/-, plus other allowances as admissible under the rules, with eﬀect from the date of
taking over charge and until further orders.
On promotion, Shri Pabitra Engti, Additional Chief Engineer cum Council Head of
Department, Irrigation, Karbi Anglong Autonomous Council,

Diphu

will be posted as

Chief Engineer, Minor Irrigation, Assam against vacant post, until further orders.
The above promotion is based on the recommendation of the Selection Board in
its meeting held on 08-09-2026 and shall be subject to reversion without prior notice and
without assigning any reason. The aforementioned promoted oﬃcer should join in his new
place of posting on promotion within 15 days from the date of receipt of this Notiﬁcation
as per provision of rule 19 of the Assam Engineering (Irrigation Department) Service
Rules, 1978.
The inter-se seniority of the officers in the promotional post will be fixed later on.

Secretary to the Govt. of Assam,
Irrigation Department, Dispur, Guwahati-6.
Memo No. IGN(E) 764050/147-A
Copy to :

Dated Dispur, 12-10-2026

1. The Accountant General, Assam, Maidamgaon, Beltola, Guwahati-29 for kind
information.
2. PPS to Hon’ble Chief Minister, Assam, Dispur, Guwahati-6 for kind apprisal of
Hon’ble Chief Minister.
3. The Principal Secretary, Karbi Anglong Autonomous Council, Diphu for kind
information.
4. The Chief Engineer (Irrigation) /Chief Engineer (Minor Irrigation), Assam, Dispur,
Guwahati-6 for kind information.
5. The Additional Secretary to the Govt. of Assam, Irrigation Department, Dispur,
Guwahati-6 for kind information.
6. The Joint Secretary to the Govt. of Assam, Irrigation Department, Dispur, Guwahati6 for kind information.

<!-- page 2 -->

IGN-14015/1/2026-ESTT-IRRIGATION-Irrigation Department

I/1801073/2026

7. All Additional Chief Engineers of Irrigation Department for kind information.

8. Shri Pabitra Engti, Additional Chief Engineer cum CHD, Irrigation, KAAC, Diphu for
kind information and necessary action. He is requested to hand over his current
charge

of Additional Chief Engineer cum CHD, Irrigation, KAAC, Diphu to Shri

Semson Sing Terang Rangsaiso, Director, O/o the Addl. CE cum CHD, Irrigation,
KAAC, Diphu.

9. Shri Semson Sing Terang Rangsaiso, Director, O/o the Addl. CE cum CHD, Irrigation,
KAAC, Diphu for information and necessary action. He is allowed to take over the
additional charge of Additional Chief Engineer cum CHD, Irrigation, KAAC, Diphu in
addition to his own duties until further orders.

10. All Superintending Engineers of Irrigation Department for kind information.
11. The

Deputy

Director

(Printing

&

Stationery),

Assam

Government

Press,

Bamunimaidam, Guwahati-21 for kind information with a request kindly to publish
the notification in the next issue of the Assam Gazette.

12. All subordinate Officers under Irrigation Department for kind information.
13. The Treasury oﬃcer, New Guwahati Treasury, Guwahati-3 for information
14.
15.
16.
17.
18.

and necessary action.
The Web Information Manager, Irrigation Department for uploading the notiﬁcation
in the Departmental Website.
PS to Hon'ble Minister, Irrigation, Assam, Dispur, Guwahati-6 for kind information of
Hon'ble Minister.
SO & PS to the Special Chief Secretary to the Govt. of Assam, Irrigation Department,
Dispur, Guwahati-6 for kind information of Special Chief Secretary.
Confidential Branch, Irrigation Department for information.
Personal file.
By Order, etc.

Deputy Secretary(E) to the Govt. of Assam
Irrigation Department, Dispur, Guwahati-6.
