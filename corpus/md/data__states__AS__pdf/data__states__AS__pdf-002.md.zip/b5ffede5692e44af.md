---
doc_id: "b5ffede5692e44af"
source_url: "https://fcsca.assam.gov.in/sites/default/files/swf1/dms75_transfer_posting-assistant_director_fpdca.pdf"
ministry: "Food, Civil Supplies and Consumer Affairs Department, Assam"
title: "Transfer & Posting"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "234362e6c81d7f30"
---

<!-- page 1 -->

FCSCA-12011(14)/1/2022-SUPPLY(B)-FCS AND CA-Food CS&CA
I/349747/2023

GOVERNMENT OF ASSAM
FOOD, PUBLIC DISTRIBUTION AND CONSUMER AFFAIRS (B) DEPARTMENT
JANATA BHAWAN: DISPUR: GUWAHATI-781006
ORDERS BY THE GOVERNOR
NOTIFICATION
Dated Dispur the 28th November, 2023
No.E-220375/261: Subject to reversion without notice and assigning any reason thereof, the
following Superintendents of Food, Public Distribution & Consumer Affairs Department are hereby
promoted temporarily and allowed to officiate as Assistant Director, Food, Public Distribution &
Consumer Affairs Department under Regulation 4 (d) of the APSC (Limitation of Function)
Regulation 1951, in the Pay Band-4 (Rs.30,000 - Rs.1,10,000) plus Grade Pay @Rs.13,900/- plus
other allowances as admissible as per rules and posted at the place shown against each of their names
with effect from the date of taking over charges.

Sl.
No.

Name of Superintendent, Food, Public Place of posting as Assistant
Distribution & Consumer Affairs Director, Food, Public Distribution
Department with present place of & Consumer Affairs Department
posting
1.

Sri Srimanta Goswami, Superintendent, Biswanath against existing vacancy.
FPD & CA, Gohpur

2.

Sri Dilip Kr. Deka, Superintendent, FPD Morigaon against existing vacancy.
& CA, BI (EO), Assam
The inter-se-seniority of the officers will be fixed later on.

(Paul Barua, ACS)
Addl. Secretary to the Govt. of Assam,
Food, Public Distribution & Consumer Affairs Department
Memo No.E-220375/261-A
Copy to:

Dated Dispur the 28th November, 2023

1. The Accountant General (A & E) GE-10, Assam, Maidamgaon, Beltola, Guwahati -781029 for
favour of his kind information & necessary action.
2. The Secretary to the Govt. of Assam, Home & Political (Vigilance Cell) Department for kind
information.
3. The Secretary, APSC, Khanapara, Guwahati-22 for kind information.
4. The Commissioner, Food, Public Distribution, Consumer Affairs and Legal Metrology, Assam,
Ulubari, Guwahati-07 for kind information.

<!-- page 2 -->

FCSCA-12011(14)/1/2022-SUPPLY(B)-FCS AND CA-Food CS&CA
I/349747/2023

5. The Director, (P&S) Assam, Govt. Press, Bamunimaidan, Guwahati -21 for publication of the
above notification in the next issue of the Assam Gazzette.
6. The District Commissioner, Biswanath/ Morigaon for kind information.
7. The S.D.O. (Civil), Gohpur for kind information and necessary action.
8. The Superintendent of Police, BI (EO), Assam, Srimantapur, Guwahati for kind information and
necessary action.
9. The Treasury Officer,.………………………………………for kind information and necessary
action.
10. The P.S to the Hon’ble Minister, Food, Public Distribution & Consumer Affairs Department,
Dispur for kind appraisal of Hon’ble Minister.
11. The P.S to the Additional Chief Secretary, Food, Public Distribution & Consumer Affairs
Department, Dispur for kind information of Additional Chief Secretary.
12. Officer concerned. Shri/Smti………………………………………………………………………..,
Superintendent,
Food,
Public
Distribution
&
Consumer
Affairs………………………………………………………………………………………………
for information and necessary action. He/ She is requested to exercise option regarding fixation of
pay within one month from the date of issue of this notification as per Rule-11 of Assam Services
(R.O.P) Rules, 2017.
13. Website (https://fcsca.assam.gov.in)
14. Office Copy.
By order etc.

Under Secretary to the Govt. of Assam,
Food, Public Distribution & Consumer Affairs Department
