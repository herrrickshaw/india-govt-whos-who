---
doc_id: "ab2d64d9caf3f0ad"
source_url: "https://police.assam.gov.in/sites/default/files/swf1/dms90_stu_si_ap.pdf"
ministry: "Assam Police"
title: "Download Appointment Order for Sub-Inspector(UB) and Physiotherapist"
date: ""
pages: 3
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3b22aee428738f3b"
---

<!-- page 1 -->

ASSAM POLICE HEADQUARTERS
ULUBARI, GUWAHATI
No: FB/I/329/2017/PT-I/24

Dated: May 25, 2023
ORDER

As per the recommendation of the State Level Police Recruitment Board,
Assam, Guwahati vide their Letter No. SLPRB/REC/SI(UB)/614 /2023/91
dated 08/05/2023, the following Candidates are appointed to the Posts against
existing Vacancies, as shown below against his/her name with effect from the
Date of Joining in the Scale of Pay as per AS(ROP) Rule, 2017 subject to
fulfilment of the following Terms and Conditions and subject to satisfactory
Notarized Affidavit submitted by the Candidates as per the Personnel(B)
Department O.M. No. ABP.78/2021/01, Dated 18/11/2021 in the format
prescribed therein regarding Character and Antecedents and subject to
satisfactory verification of documents and undertakings submitted by the
Candidate(s).
2.
The Candidates so appointed will not be governed by the existing Assam
Services (Pension) Rules, 1969 and orders issued thereunder from time to
time. They will be governed by a new set of Pension Rules under the “New
Defined Contribution Pension Scheme”.
SL.
NO.

ROLL
NO.

1

1808012

2

NAME OF THE
CANDIDATE

NAME OF THE
OFFICE TO WHICH
THE CANDIDATE IS
POSTED

ADDRESS

NAME OF
THE POST

SCALE OF PAY

CHANDAN
PHUKON

SIVASAGAR

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

SP SIVASAGAR

2009570

MADHURJYA
MEDHI

NAGAON

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

NAGAON DEF

3

2102808

PRINCE KEMPRAI

KARBIANGLONG

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

KARBI-ANGLONG
DEF

4

2103318

SAURAV
BORDOLOI

KARBIANGLONG

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

KARBI-ANGLONG
DEF

5

1810359

KASHYAP KUMAR
DUTTA

JORHAT

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

JORHAT DEF

6

2000113

ANISHA
BUNGRUNG

KAMRUP
METRO

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

POLICE
COMMISSIONERATE,
GUWAHATI

7

1207222

SAGAR SHARMA

TINSUKIA

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

TINSUKIA DEF

8

1813329

PRITIMOHAN
SAIKIA

JORHAT

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

JORHAT DEF

9

1204508

GANESH
DEHINGIA

TINSUKIA

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

TINSUKIA DEF

10

2804294

BHARGAB DAS

BARPETA

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

BARPETA DEF

Page 1 of 3

<!-- page 2 -->

SL.
NO.

ROLL
NO.

NAME OF THE
CANDIDATE

11

2810784

NUR SELIM
AKTAR

12

2009333

13

NAME OF THE
OFFICE TO WHICH
THE CANDIDATE IS
POSTED

NAME OF
THE POST

SCALE OF PAY

BARPETA

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

BARPETA DEF

KULDEEP
RAHANG

KAMRUP
METRO

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

POLICE
COMMISSIONERATE,
GUWAHATI

3003799

LAKHMI KANTA
GADAILI

SONITPUR

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

SONITPUR DEF

14

2408782

RUPAM DIHINGIA

DHEMAJI

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

DHEMAJI DEF

15

2008652

JUBIN KATHAR

KAMRUP
METRO

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

POLICE
COMMISSIONERATE,
GUWAHATI

16

2800635

DAYENA ALBUM
BARUAH

BARPETA

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

BARPETA DEF

17

2011491

PRABAL JYOTI
KALITA

KAMRUP
METRO

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

POLICE
COMMISSIONERATE,
GUWAHATI

18

1810756

LOBIK MACHARI

CHARAIDEO

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

CHARAIDEO

19

0600968

ABDUL AHAD
BARBHUIYA

CACHAR

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

KARIMGANJ DEF

20

2012478

RAKESH GOGOI

KAMRUP
METRO

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

KAMRUP DEF

21

2803648

ANJANJYOTI
NATH

BAKSA

SI(UB)

PB-II 14000-60500
G/PAY 8700/=

BAKSA DEF

22

0600094

APURBA CHANDA

KARIMGANJ

PHYSIO
THERAPIST

PB-II 14000-60500
G/PAY 8700/=

PTC, DERGAON

ADDRESS

Following are the Terms and Conditions of Service for the Appointee:
1.
During his/her Service period, he/she may be deputed or his/her
services may be placed on attachment or on secondment basis within the
Assam Police and its Organisations or to any other Department/Sub-Ordinate
Office/Public Sector Undertaking/Society/Mission under the State Govt. within
and outside the State having the same Pay Scale and Grade Pay for a period
decided and specified by the State Govt.
While on such Deputation or on attachment or placed on Secondment basis
he/she shall continue to be guided by the Assam Civil Services (Conduct)
Rules, 1965 and Assam Services (Discipline & Appeal) Rules, 1964 as well as
the Assam Police Act, 2007, Assam Police Manual and Rules related to both
the Act and the Manual.
2.
The
services
of
any
selected
Candidate
found
to
have
furnished
false/falsified
information
regarding
educational
qualification/caste/gender/EWS status etc. in his/her application and detected
subsequently, will be terminated and legal action will also be taken as per law.
3.
Any selected Candidate for Class IV Post found to be overqualified/found
to have suppressed information about over educational qualification, in terms
of the advertisement during entry in the service, his/her service will be
terminated and also legal action will be taken as per norms.
4.
If a Candidate or any of his/her family members is availing benefits
under the Orunodoi Scheme at the time of the appointment, he/she or the
concerned family member shall voluntarily opt out of the Scheme, as per
Orunodoi Guidelines for getting appointment to the post.

Page 2 of 3

<!-- page 3 -->

5.
The Appointee shall also have to furnish a signed undertaking/affidavit
at
the
time
of
joining
as“I,……….(Name),
appointed
as………….(Designation) in………………. Assam Police do hereby
solemnly affirm and declare that, I voluntarily and without duress
agree to the terms and conditions mentioned in the appointment
order. I also solemnly affirm and declare that I satisfy all the
qualifying criteria of the post to which I am appointed to. I also
declare that I do not have more than one wife living (applicable for
male candidates)/have married a person who has wife living
(applicable for female candidates). I also further declare that I do not
have more than two living children on or after 01-01-2021 from a
single or multiple partners. In case of any detection to the contrary in
due course, I shall be summarily discharged from the Service.”
6.
Further, the Appointee shall also have to submit a Notarized Affidavit as
per provisions of the Personnel (B) Department O.M. No. ABP.78/2021/01,
dated 18/11/2021. Format of the affidavit is enclosed in Annexure-I.
7.
The Appointee will have to undergo Basic Training Course and be on
Probation, as applicable.
8.

The above is subject to final Security Vetting of the selected individual.

9.

The Appointee should report at the place of posting on 01/06/2023.

(Subhasish Baruah, APS)
Asstt. Inspector General of Police (A&E)
Assam, Guwahati

Memo No.: FB/I/329/2017/PT/ PT-I/24

Dated: May 25, 2023.

To,
1.
2.
3.
4.

The Spl. Director General of Police (Border), Assam, Guwahati.
The Spl. Director General of Police (Comm.), Assam, Guwahati.
The Commissioner of Police, Guwahati.
All Superintendents of Police and Commandants.

With a request to provide appointment letters to individual candidates when the
candidates reports for joining and complete all joining formalities.
A proforma Appointment letter has been sent to your respective offices separately.
5.
The Nodal Officer, SLPRB, Assam, with a request to upload this order on the
SLPRB website.
Copy for kind information to:
1.
The Principal Secretary to the Govt. of Assam, Home & Political Department,
Dispur.

(Subhasish Baruah, APS)
Asstt. Inspector General of Police (A&E)
Assam, Guwahati

Page 3 of 3
