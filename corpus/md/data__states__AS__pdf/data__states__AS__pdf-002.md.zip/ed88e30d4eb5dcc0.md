---
doc_id: "ed88e30d4eb5dcc0"
source_url: "https://finance.assam.gov.in/sites/default/files/swf1/dms90_amendment_of_drpr_of_assam_legislative_assembly_dated_26.08.2026.pdf"
ministry: "Finance Department, Assam"
title: "Amendment of DRPR of Assam Legislative Assembly dated 26.08.2026"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "cfe12133aa2cf1b3"
---

<!-- page 1 -->

FD-21025/31/2026-ESTT_B-FIN-Finance Department

I/1722517/2026

GOVERNMENT OF ASSAM
FINANCE (ESTABLISHMENT-B) DEPARTMENT
2ND FLOOR, BLOCK ‘F’, JANATA BHAWAN
DISPUR, GUWAHATI-6
ORDERS BY THE GOVERNOR
NOTIFICATION
No.FEB.835383/04:In pursuance of Clause 3 of Article 166 of the
Constitution of India, the Governor of Assam is pleased to direct that the
following amendment be made to the Delegation of Financial Power
Rules, 2022.
In Schedule of Power to Subordinate Authority, the following shall be
added :
Sl.No.as
per
DFPR,2022

Nature of
Power

Extent
Authority

of
Power

Sanction of

1.The budget provision

i. House

must

building

be available

advance to

2.The methodology of

the Hon'ble

214

recovery of HBA/MCA

MLAs

Secretary,

ii.Advances

Assam

for

Legislative power

Purchase of

Assembly

motor
conveyance
for the
Hon'ble
MLAs

General Conditions

Full

shall
continue as per the
existing
pattern of recovery of
principal/interest.
3.Maximum repayable
period
is as per existing rule.

Secretary to the Govt. of Assam
Finance (Establishment-B) Department

<!-- page 2 -->

FD-21025/31/2026-ESTT_B-FIN-Finance Department

I/1722517/2026

Memo No. FEB.835383/04-A

Dated Dispur, the 26-08-2026

Copy for information and necessary action to:

1. The Principal Accountant General (A&E), Assam, Maidamgaon,
Beltola, Guwahati-29

2. The Addl. Chief Secretary to the Hon’ble Chief Minister, Assam for
kind appraisal.

3. The Senior Most Secretary, All Administrative Departments.
4. The Secretary, Assam Legislative Assembly Secretariate, Dispur.
5. The Secretary, Finance (Budget) Department.
6. PS to Hon’ble Minister Finance for kind appraisal of the Minister.
7. All Heads of Departments.
8. All Director Finance/Sr.F.A./ F.A./Sr.F&AO/ F&AO/TO.
9. The Additional Project Director, AS-CFMS for kind appraisal.
10. The Project Head, IFMIS, ﬁnassam to integrate the same in ﬁnassam,
accordingly.

11. The Deputy Director of Printing, Assam Govt. Press, Bamunimaidam,
Guwahati-21 for publication in the next issue of Assam.

12. The Content Manager, Finance Department for necessary uploading.
By Order etc….,
(Esigned)
Secretary to the Govt. of Assam
Finance (Establishment-B) Department
