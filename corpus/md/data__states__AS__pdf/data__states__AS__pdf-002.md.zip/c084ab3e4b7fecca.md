---
doc_id: "c084ab3e4b7fecca"
source_url: "https://elementary.assam.gov.in/sites/default/files/swf1/dms64_suspension_order_of_madhab_saha_beeo_udharbond.pdf"
ministry: "Elementary Education Department, Assam"
title: "suspension_order_of_madhab_saha_beeo_udharbond.pdf"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "f14c79409cee3989"
---

<!-- page 1 -->

EED/345/2025-Elementary Branch-Department of School Education

I/1382490/2026

GOVERNMENT OF ASSAM
DEPARTMENT OF SCHOOL EDUCATION
DISPUR :: GUWAHATI-06
ORDERS BY THE GOVERNOR OF ASSAM
NOTIFICATION
No. ECF-725350/7
Whereas, the Directorate of Vigilance and Anti Corruption has reported vide their letter no.
DGVA/RC/2025/6879 dated 19/11/2025 that Sri Madhab Saha, serving as Block Elementary Education Officer (BEEO),
Udharbond, Dist. Cachar, Assam was apprehended for demanding bribe in a trap operation launched by the officials of
Vigilance and Anti Corruption, Assam and after getting sufficient evidences Sri Madhab Saha was arrested by the
Directorate of Vigilance & Anti Corruption, Assam in connection with the ACB PS Case No.61/2025, U/S Sec.7(a) of
the Prevention of Corruption (PC) Act,1988 (as amended in 2018) on 18/11/2025. and;
Whereas, it has also been informed by the Superintendent of Police, Directorate of Vigilance & AntiCorruption, Assam, that Sri Madhab Saha was produced before the Hon'ble Court of Special Judge, Assam, Guwahati on
19/11/2025 and taken on Police remand for 3(three) days.
Whereas, the Governor of Assam is now satisfied and considers it expedient and in the interest of public service
to suspend Sri Madhab Saha, serving as Block Elementary Education Officer (BEEO), Udharbond, Dist. Cachar, Assam.
Now, therefore in view of the above, the Governor of Assam in exercise of powers conferred under Sub Rule 2
of Rule 6 of the Assam Services (Disciplinary & Appeal) Rules, 1964 is pleased to order that Sri Madhab Saha,
serving as Block Elementary Education Officer (BEEO), Udharbond, Dist. Cachar, Assam is deemed to have been
placed under suspension with effect from the date of arrest i.e. on 18/11/2025 until further orders.
During the period of suspension, the headquarters of said Sri Madhab Saha, if released from custody will be
Cachar District.
By Orders and in the name of
Governor of Assam

Secretary to the Govt. of Assam
Department of School Education
Memo No. ECF-725350/7-A
Copy for information and necessary action to:1. The Accountant General of Assam, Maidamgaon, Guwahati-29
2. The Sr. Standing Counsel, Education Department, Gauhati High Court, Guwahati-01
3. The Mission Director, SSA, Assam, Kahilipara, Guwahati-19
4. The Director of Vigilance and Anti Corruption, Assam, Srimantapur, Guwahati-32
5. The District Commissioner, Cachar
6. The Director of Elementary Education, Assam, Kahilipara, Guwahati-19.
7. The District Elementary Education Officer, Cachar
8. The Block Elementary Education Officer, Udharbond, Cachar
9. The Treasury Officer, Cachar Treasury/ New-Silchar Sub-Treasury/ Lakhipur Sub-Treasury
10. Sri Madhab Saha, Block Elementary Education Officer (BEEO), Udharbond, Dist. Cachar, Assam
11. Guard File.
By Order etc,

Deputy Secretary to the Govt. of Assam
Department of School Education
