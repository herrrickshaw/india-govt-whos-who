---
doc_id: "bba1dce1bfb60536"
source_url: "https://gdd.assam.gov.in/sites/default/files/swf1/dms58_Office%20order.pdf"
ministry: "Guwahati Developement Department, Assam"
title: "Office order related to appointment of Nodal Officer"
date: ""
pages: 1
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "9e1d29a5cf370ca7"
---

<!-- page 1 -->

GOVERNMENT OF ASSAM
GUWAHATI DEVELOPMENT DEPARTMENT
JANATA BHAWAN, 2? FLOOR, D-BLOCK
E-mail: gddassam.sectt@gmail.com
DISPUR, GUWAHATI-6.
NO.GDD.192/2013/449 Dated, Dispur the 9" Jan., 2019.
OFFICE ORDER
Smti Prajnya Saharia, Joint Secretary to the Govt. of Assam, Guwahati Dev.
Department has been designated as Nodal Officer for implementation of E-office in
Guwahati Development Department in addition to her allotted works. Her contact details
are as follows:-
Mob. No. 9954132787
E-mail id: gddassam.sectt@gmail.com
Sd/-
(S.S. Meenakshi Sundaram, TAS)
Secretary to the Govt. of Assam,
Guwahati Development Department.
Memo NO.GDD.192/2013/449-A Dated, Dispur the 9" Jan., 2019.
Copy to: ই রর
1) The Joint Secretary, S.A (Estt.) Deptt. Dispur for kind information. ৰ
2) Smti Prajnya Saharia, Joint Secretary, GDD for information and necessary action.
3) P.S. to Principal Secretary, GDD for kind apprisal of the Principal Secretary.
4) PS. to Secretary, GDD for kind apprisal of the Secretary.
By Order etc.,
1 \A
তত
4 ৮ Joint Secretary to the Govt. of Assam,
R. ত Guwahati Development Department.
সকসসসসস
eel’
Scanned by CamScanner
