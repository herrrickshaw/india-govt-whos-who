---
doc_id: "dce7a28c5fdbcf37"
source_url: "https://dgcd.assam.gov.in/sites/default/files/swf1/dms84_act_20_of_1983_1.pdf"
ministry: "Civil Defence & Home Guards, Assam"
title: "Civil Defence Act & Rules"
date: ""
pages: 19
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "e6dc8539b5bcdf8f"
---

<!-- page 1 -->

শন DELEGATED LEGISLATION: PROVISIONS

হু (AMENDMENT) ACT, 1983 ৷

০. ৷", No. 20 oF 1983 So
ত poe rt গলি [308 August, 1983.]

F + _- An Act to amend certain Acts to implement the recommendations of . :

ত ু the Committees on Subordinate Legislation regarding publi-

চু cation and laying of rules and other delegated legislation.

5 2. টু 10 6080৮], 5 চ21118106726 10 009 1917-0০0700 ৪৪6৫ 05৩ 160200110

' of India as follows:—-

ন 1.) This Act may be called the Delegated Legislation Provisions

© Short (Amendment) . Act,-1983. ূ ূ ূ

Stile , : :
2 and com: (2) It shall come into force on such ৫৪৮৫ as the Central Ggvernment

So. mence- may, by notification in the Official Gazette, appoint, and different dates

po ment, may be appointed for amendments. relating to different enactments men- ৰ
: ‘tioned. in the Schedule to this Act.

ৰ e
ডং A ৷ ‘12, The enactments specified in the Schedule are hereby amended to 7 .
॥ ক the extent and in the mannet mentioned in ‘the third. column thereof. -

©. certain ঢ় ত ৰ,

থৈ, ৩08০৮ ৃ THE SCHEDULE ৷ ঢু

১ ; ments, . . এ.

ৰ ৯৮০০- 1; (See section 2) ১1 oom

: ; ৷ _ AMENDMENTS ৷

৷", ন্রবাঁ =

ৰ No. Short title Amendments. 7 .

১ ~1. The Opium Act, 1857 After section 31, the following section. shall
3 (18 ০৫ 18517), be inserted, namely:—

! Publication __ “82. (1) Every rule required to be pres-

ৰ and laying of cribed ‘or sanctioned by the Central Govern

z ২৩ rules, ৰ ment shall be prescribed or sanctioned by. ন
Pu. ৷ রর ৷ that Government by notification’ in’ the

: 7, Official Gazette, .

a . (2) Every rule prescribed or sanctioned

: by the Central Government under this Act

Be shall be laid, as soon as may be after it is :

ৰ 2 ু | - 29500990102 38120601060, 1780:9-990]1 [70086 ত
E of Parliament, while. it is in session, for a .

Bo, | "কন্জতও 88; Vide Notification No. GSR. 85(8) dated 29-2-1984 Gazette of India,

; ৷ ৮1721 :

টি : - 198 - ৷
[+ we > . Ve es ৮" de ২১751

<!-- page 2 -->

ৰ্‌ ৷ 4 ৷ 1,
: : ৯ .
৷ [পে 20 or 1983] Delegated ‘Legislation Provisions (Amendment) 199
i 9. - ৷ ;
Poe No. Short title | - . Amendments
: ৷ total period of thirty days which may be
ত .  eomprised in one session or. in two or more ,
ত ৷ successive sessions, and if, before the expiry
; . rs of the . session _immediately following the
+ ৷ session, or the successive sessions aforesaid, ঢ়
২ se both Houses agree in making any modifica~
tion in the rule or both Houses agree that -
i . the rule should.not have effect, the rule +
: ৷ shall thereafter have effect only in such
টি . modified form or be of no effect, as the case-
be ~ ৷ may be; so, however, that any such modifica-
£ ৷ ১ tion or, annulment. shall be without preju- ~ ,
dice to the validity of anything previously -
b done under that. rule.”. *
} 2, The Religious In section 8,— . ফস
ৰণ টয় _ ().in paragraph 3, after the -words ত
ই 7 (20 of 1863) “ander such ‘rules’, the words’, by noti-°
} . fication in the Official Gazette,” shall ‘be
3 ত ঢ inserted;. . . ৷
ঃ এ 00100050150 1:88) after paragraph 3, the following . 1
তত - 7 ৷ paragraph shall. be inserted, namely: — |
চু ৷", “Every rule framed under this ৷
; nal, oo . section shall be laid, as'soon as it is
: . ১, framed, before the State Legislature.”.
২... ০৯ 3, The Press and Registra- (1) .For section 20, the following section shall * |
ৰু = tion of Books Act, 1867 he’ substituted, namely:—
i (25, of 1867). ০ .
z . Power. of State. ‘20. (1) The State Government may, by . {
যা to notification in the Official. Gazette, make ৷
ন rules. such rules (not inconsistent with the. rules ১ |
Boo. , ৷ 4 made by the Central Government under ৷
an are ৷ section 20A) as may be- necessary or desir- ৷
হু a oe able for carrying out. the objects of this Act.
- গতা তা aa (2) Every rule made by the:State Gov- ৷
ees 5 ernment under this section shall ‘be laid, as i
4 . ৷ soon as may. be after it is made, before the . I
ৰু নি? . . State Legislature.”. - |
. ৷ ঢু (2) In section 20A, in sub-section (2), for the |
ঠ- ‘ . : words “in two successive sessions, and if before |
ত ৷ “the expiry of the session in which it is so laid or |
the session immediately following”, the words .
য়ু 7 : “in two-or more successive sessions, und if, be- হু
; . : fore the expiry of. the session immediately
i ত following the session or the successive sessions :
; _ aforesaid” shall be substituted. 7 7
eo 4..The Indian © Section 83 shall be re-numbered as sub-section ot
: ত Christian Marriage « (1) thereof; and—
হি Act, 1872 (a) in sub-section (1)as so re-enumbered, ~
i , (15 of 1872). for the. words “may make rules”. the words’
টু _ “may, by notification. in the Official Gazette, 4
৷ oo make rules” shall be substituted; and ৷
৷ 17 Law—27 a | ৷ J
৮ , ঢু . . 7 ঢ ১ 3

<!-- page 3 -->

৷ 200° Delegated Législation Provisions (Amendment) . Lact 20 ,
ত Sl. ৷ .
: No. Short title Amendments , 7
: (6) after sub-section (J) as so renum- -
1 bered, the following sub-section shall be -
. ৷ inserted, namely: — .
© . ৰ, “(2) Every rule made by the State 7
: Government under this section shall be
5 oor laid, as soon as may be after it is made,
bs . before the State Legislature.”.
৷ 5. The Government In section 15, in sub-section (3), for the words
ৰু Savings Bank “m two successive sessions, and if before the
টু ু ~ Act, 1873 expiry of the session in which it is so laid or the .
. . (5 of 1878), . session immediately following”, the words “in
two or more successive sessions, and if, before
2 the expiry of the session immediately following
: ৷ the session or the successive sessions aforesaid”
z shall be substituted, 7
7 6. The Indian Reserve Section 4.shall be re-numbered ‘as sub-section
. ৩৫০৩ 40188840010) 109290 জা
= 1838). ? - me
} ॥ (i) in sub-section (1) as so re-number-
- = ed, after the words “The Céritral Govern- ,
. i ০০৮ ment may”, the words“, by notification in ৷
: ৷ the Official Gazette,” shall be inserted;
. (i) after sub-section (1) as so re-.
ও ৷ চু numbered, the following sub-section shall
ৰ be inserted, namely:—~ . ৷
“(2) Every rule. and every order ত
| made under sub-section (1) shall be laid,
as soon as may be after it is made, be-
. ৷ fore each House of Parliament, while it
. ত, ত isin session, for a total period cf thirty
5 ৰ . ‘days. which may be comprised in. one 7
° . session or in two or more successive
হৈ " , ত - sessions, and if, before ‘the expiry of the .
& 7 session immediately following the ses-
ত , sion or the successive ‘sessions afore- ৰ
নু - said, both Houses agree in making any
: . modification in the rule or order or both ,
| Houses agre@ that the rule or. order
L , should not be made, the rule or order .
g - shall thereafter have effect only in such ~ -
~ modified form or be of no effect, as the
7 : case may be; so, however, that any
- such modification or annulment shall. be
without prejudice to the validity of any-
7 thing previously done under. that rule
ত or order,”, . ন
৷ 7. The Indian Tolls In section 7, after ‘sub-section (4), the follow- ve :
: ত এ (গে and Air . ing sub-section shall be inserted, namely:— -
ত a Force) Act, 1901 - “ .
; (2 of 1901). (5) Every rule made by: the. Central
ত Government under, this section shall be Jaid,
5 . as soon as may be after it is made, before '
x শু . 2 “each ‘House of Parliament, while it is in -
ঢ় : . oo session, for a- total period of thirty davs . .
Le বা which.may be comprised. in one session or in i
1 two or more successive sessions. and if. be- t
: _ fore the expiry of the session immediately 7
Be eee শিপ ,_;
ফু 1
৷ |
7 ‘ : ,, ঢ়।

<!-- page 4 -->

.or 1983] Delegated Legislation Provisions (Amendment) 29
: Sl. 7 ‘ cae dl MB ad
. No. Short: title’ - । Amendments
ত ৷ | 01101060029. 99331017 or- the successive '
sessions aforesaid, both Houses agree in .
৷ - making any modification in the rule or both -
: ৷ Houses agree that the rule should not -be
ত made, the rule shall thereafter have effect
ৰ only in such modified form or be of no effect,
ৰ as the case may be; so, however, that any
| | such modification or annulment ‘shall be
. ৷ without prejudice to the ১২১8 of anything
. ৷ previousiy done under that rule.”, _
8. Code‘of Civil Procedure, In section 67; after sub-section (2), the follow-
ু 1908 (5 01 1908), ing sub-section shall be inserted, namely:— .
৷ “(3) Every rule-made under this section
shall be laid, as soon as may. be after it is ১.
. 7 ৷ made, before the State Legislature.”
9 The Indian Ports Act, In-section 6, after sub-section (2), the follow-
. 1908 (15 of 1908). ing ‘sub-seetions shall be inserted,’ namely: —
. . - “(2A) Every rule made by. the State
~ Government under. this Act shall ‘be laid, as - |. ও
soon as may be after it is made, before the
ৰ ৷ ন State. Legisiature. ঢ় ঢ় ১
্‌ . (2B) Every rule made by the Central
ত ৷ 1) Government under this Act shall be laid, as... ত
৷ soon as may be after it is made, before-each ত
- ৷ House of Parliament, while it is it session, :
7 for a total period of thirty days which may
2 ৷ ,. be comprised in one session or in. two or.
. more. successive sessions, and if, before the
৷ expiry of the session immediately following . -
7 : . the session or the successive sessions afore- ‘
, ক: 5 said, both Houses agree in makirig any modi- ১
- fication in the rule or both Houses agree that ৷ 1
: - . the rule should not.be made, the rule shall ৷
ু - thereafter have effect only in such modified
- ৰ: . form or be of no effect, as the case may be; -
ঢ় ৰ «; 80, however, that any such modification or io.
. annulment shall be without prejudice to the: _
SS validity of anything previously done under ‘ ,
£ , that rule.”, .
২৯
+ 10. ‘The’ Registration Act, Section 91 shall be re-tiumbered: as sub- i
- 1908 (16 of 1908). section (1) thereof; and— - i
৷ ত (i) in sub-section (1) as so re-numbered, 1
. for the words. “State Government prescribes i
in this behalf”, the words “State: Govern. |
+ : ment, by notification in the Official Gazette, 1
ৰ 7 prescribes in this behalf” shall be substitut: ৯
ed;
. | : (ii) after sub-section (1) as so re
| numbered, the following sub-section shall -
, be inserted, namely: — :
২১5 “(2) Every rule prescribed under
: ত, this. section or made under section 69
ত, shall be laid, as soon as it is made, be-
ঃ 7 ূ 1026 1086 50806 '],681518016., ত ু 7
চু . .
ই uo
iF .
|

<!-- page 5 -->

ু 09 Delegated Legislation: Provisions (Amendment) Laer 20
: - 91. a ৰ
} 1, No. — Shart. title - Amendments -
5 11. The Indian (1) In section 35,— “
: Electricity Act, 1910 (9 _ (a) in sub-section (3), for the words -
ঢ় ৷ of 1910). ' “by general or special order”, the words. “by
টু general or special order published in the |.
© , 2: Official Gazette” shall be substituted;
: - + 2205, (b) after sub-section (3), the following
ন wont oe sub-sections shall be inserted, namely:—
বা Lok - .“(4) Every order made by the State .
7 , , ত, ত, Government under sub-section (3) shall
1, ঢঁ্‌ ত be laid, as soon as may be after it is .
: made, before the State Legislature.
| ত. (5) Every order made by the Cen-
চু ৰ ঘৰতো tral Government under sub-section (3)
ত ২ 7 shall be laid, as soon as may be after it
: : ২২000 '_]9 70806, 26106 each House of Parlia-
৷ . ment, while it is in session, for a total
ৰ ু period of thirty days which may be
ন eee. coraprised in-one session or in two or .
: ১২০১৮ ২০০০ = mote successive sessions, and if, before
the expiry. of the session immediately
য়া ত . . ৷ . following the session or the ::90009951%9
১ - ws » sessions aforesaid, both Houses agree
5 7 in making any modification in the. order
টু 7 ৰ Lo or both Houses’ agree that the “order
হু . 7 ) , ১25৭ should not be-.madeé, the order shall
oO 1; : thereafter have effect only in such modi-
yo . fied form or be of no effect, as the case
ঢ় ৷ ৰ See |} may be; so,” howéver, that any ৪00
ৰ 7 1"; modification . or annulment shall be
, : without prejudice to the validity of any-
2 + , thing previously done under that order,”.
i , sont (2) In section 38, for sub-section (3), the
” ৰ? following sub-section shall be substituted,
h namely: —
ঢ়: ঢ় we । “(3) Every rule made under section 37 ৷
: ৷ তত bo. shall be published in the Gazetie of India
2 , and shall be laid, as soon as may be after it
: " is made, before each House of ' Parliament, ,
১ while it is in session, for a total period . of -
£ ৷ 80] 0855 17101) 0085 008 00177901590. in one..
_ id . session or in twe or more successive sessions, -
1 ত and if, before the expiry. of the ses-
D . oO sion immediately following the. session !
৷ ম্‌ or the successive sessions aforesaid, - both
- Houses agree in making any modification in
? . Lae ৷ the rule or both Houses agree. that the rule
৷ তৰ, should not be made, the ক'0]6 9]18]] চ]1676- j
are ৬ after have effect only in. such modified form
. মূ or be of.-no effect, ‘as the case may be; s0, ৷ ৷
. ৰ however, that. any such modification. or
i annulment shall be without prejudice to the |
ঃ validity of anything previously done under ।
৮0৪৮ 2819৮, *. ৷
৷ , ao 12, The Indian Museum. (1) In seétion 8— |
1 * Act, 1910 (10 of 1810). * --@) in sub-section (1), for - the words i
iE ৷ “make bye-laws”, the. words “make, by. noti-
? 28680015700 009] Gazette, bye-laws” ৷
৷ ু shal] be ‘substituted; টু
}
এ

<!-- page 6 -->

5 OF 1983] . Delegated Legislation Provisions (Amendment) 203
i No. — Short title , Amendments
. - (ii) after sub-section (2), 84৩ following
৷ ৰ sub-section shall be inserted, namely: —
: 7 “(3) The Central Government shall ১
yon ret - cause every bye-law made under this
৷ না : section to be laid as soonas_ may be
7 ৷ after it is made, before each House of
ঢ় > ঢ় =, Parliament, while it isin session,.for a
ত ১ ৷ ৷ total period of thirty days which may
4 ৷ লা ক be comprised in one session or in two or
ৰা 7 more successive sessions, and if, before
৷ the expiry of the session immediately
॥ ন . following the session or_ the successive
: ঢ় ত} ‘sessions aforesaid, both Houses agree in
"৷ making any modification in the bye-law
3 ০, or both Houses agree that the bye-law
: ত, ,_' should not be made, the bye-law shall .
: . - thereafter have effect only in such modi-
5 + ‘ . fied form or be of-no effect, as the case
৷ =, may be; so, however, that any such
oe wee Ee : modification ‘or annulment shall be with- .
- ন "ডলা out prejudice to the validity of anything
, - '_; ,)7০৮10ঘ৪]য 0০006. 10089} 0186. bye-law.”.
ৰ হু 518 va Lg (2) In section 15A, in sub-section (3), for 2
‘ ne bay. . the words “in two successive sessions.and if be- .
ত - . y ঢ় ৰ, fore the expiry of the session in which it is so ৷
এ, Tk 2... .. taid or the session immediately following”, the
ত ত ৷ words “ig two or more successive sessions, and . ,
এ 205৮ if, before the expiry of the session immediately
২5005 05 ঢু following the session or the successive sessions
' , ছু aforesaid” shall be substituted, -
: - টু ২
- °43. The Oficial Trustees In section. 30,— ৷
"৬০৮ 1918 @ of 1918), (a) after sub-section (3), the following
১. sub-section shall be inserted, namely:—
8 ৮) ৬. ৮) 4054) Every rule made by the State ৷
- নন, নাতি Government under this section shall be 4
3 7 wo, . laid, as soo as it is made, before the
: ৷ Mee ৷ State Legislature.”; +;
woke ales (b) i sub-section (4), for ithe words “
Oe ২ : "- “in two successive sessions, and if, before the ঢ
ৰ 7 expiry of the session in which it is so laid i
or the session immediately following”, the . ৷
, . ঢু words “in two or more successive sessions, / ৷
: and if, ‘before the expiry of the session eet
immediately following the session or the
» ত্বক successive sessions aforesaid” shall be substi- =
tuted, ত i
: . 14. The Local -Autlhotities In section 4; after sub-section (3), the follow-
তা 46 1914 09 0£ ing sub-section shall be inserted, ‘namely:—
4), : ৰু
1) “(4) Every rule made by the Central
য় a . . Government under this Act shall be laid as
. - ত soon as may be after it-is made, before each
চু ন. Ly House of Parliament, while it is in session,
: be 22855 for a total period: of thirty days which may
£ ত, _ be comprised in’one session or in two or more
Eo । ঢু : + " successive sessions, and if, before the expiry rs ৷ .
: aod of the session immediately following the. /
চু /
| & oo + ন 5
i .

<!-- page 7 -->

চু
ঢ় 294 Delegated Legislation Provisions (Amendment) ~ [act 20
z Sl. - ৷ 1, whos ৰ
৷ No. Short title Amendments চ -
ৰণ এ session or the successive sessions aforesaid,
ৰ a both Houses agree in making any modifica-
1 ot tion in the rule or both Houses agree that
: : ৰ ৰু the rule should not- be made, the rule shall -
ত ট : thereafter have effect only in such modified
: . পলি -- form or be of no effect, as the case may be;
x na ২:05. so, however, that any, such modification or
॥-- ৰ" 5 annulment shall be without prejudice to the 7
ৰ _ _ validity of anything previously done under
ৰু চ]8.6 016), = :
ie + 15, The Maintenance Section 12 shall be re-numbered as sub-section ন
Orders Enforcement: (1) thereof, and—
é 1 Act, 1921 (18 of 1921). ১ (0) 50.0-5500}0}3 (1) as so re-number-
ৰ ৷ “ed, for the words “may make rules”, the «
Pas ast “words “may, by notification in the Official
po 7, - Gazette, make rules” shall be substituted;
: oo, - (ii) after’ sub-section (1) as so re-num+
Bos হা এ 5:50, the following sub-section shall be
> হল £ inserted, namely:— :
x . =, “(2) Every rule made by the Cen-
gE ঢু mn . 2 tral Government under this Act shall be ৬
ৰ 7 ঢ় ‘ 7 : _ laid, as ‘soon as may be after it is made,
্ঠ ত ৰণ ‘before each House of Parliamerit, while
ৰ ৰ বতা . it isin session, for a total.’ period of
ৰ ৰ 7 thirty days which may be comprised in ৷
ঠু টু | , “one session or in two or more successive
ঢু 7 Co ৷ sessions, and if, before the expiry of the
2 . এ... ২০ , session immediately following the ses- ey
ৰে =, co sion or the successive sessions afore- i
ৰু - - ৷ ~ said, both Houses agree in making any . , 1
গে রর modification in the rule or’both Houses
i agree that the rule should not be made,
x Aloe. ৷ ২০০ the rule shall thereafter have effect only
ত হ্‌ এ in such modified form or be of ino effect, 1
? ce as the case may be; so, however, that |
ত 405 ~. any such modification .or annulment ২১
. shall be without prejudice to the validity i
| ন ু of anything previously. done under that |
. BY ৩805 |
ৰ? ‘18. The Cantonments In, section, 35, after sub-section (2), the follow+ \
(House-Accommoda- ing sub-section shall be inserted, namely:— !
সি) 5০ 1228.6 of “(3) Every rule made by the Central ৷ 1
Government under this Act shall be laid, as ৷ |
ৰ soon as may be after it is made, before’ each ৷
ৰ" House of. Parliament, while it is in session,
টু < for a total period of thirty days which-may 1
২ oo, be comprised in oné session or in two or more . |
af successive sessions, .and if, before the ex- !
. : piry of the session immediately following ~ ~
7 . ; ্‌ the ‘session or the successive sessions afore- -.. -
po, said, both Houses agree in making any
4 poets . modification in the rule ‘or both Houses
রি 7২205 - agree that ‘the rule should not be made, the .
Bot ges Fe 7 rule shall thereafter have effect only in such 7
৷; she eee ৷ oe modified form or be of no-effecf, as the-casé ~ =
ie -৮-7--777777-7--+7777777777---777--
৷:
| - , ু
| . : -
i
৷ ,: :

<!-- page 8 -->

OF 19831 Delegated ‘Legislation Provisions (Amendment) 205:
৷ 91. গ্ৰ .
: | No. Short title Amendments.
may be; so, however, that any such modi- ৷
fication. or annulméni shall: be without pre-
. - judice to the validity of anything previously
done under that rule.”
17, The Indian Succession-. -(7) In section 223, after the-words “rules to -
Act, 1925 (39 of 1925). be made”, the words “, by notification in the .
: Official Gazette,” shall be inserted.
: ৮ (2) In section 236, after the words “rules to
be made”, the words “, by. notifitation in the .
. 7 Official Gazette,” shall. be inserted,
. 7 - (3) After section 236. and before. “Chapter
Ii—Of ‘Limited Grants”, the following section ত
৷ shall be inserted, namely: —
| Laying of rule, ৰ “236A. Every rule made by the State
. 7 before State, ৷ Government under section 223 and. section
Legislature, 236 shall be laid, .as soon as it is made, be- ৩ .
ঢু ছী 1006.006 50846 [,921519696-৮
: ৷ 118. গা, 0097821005 * In section 36, ৪166 sub-section (2), the ত
ন Drugs Act, 1930 * following sub-sections shall -be_ inserted, name- -
(2 of 1930). ly: . .
“ ৷ - | “(8) ভাসা ৮৮1৪ 10206 0003 90905 00৮
ঢু _ ernment under this Act shall be laid, as soon
: 5" ০৩% ঢ় as may be after it is made, before the State
০ 9000, ~ 7
- (4) Every rule made by the 08019]
১ - Government under this Act shal] be laid, as
see we oe soon as may be after it is made, before each 7
৮ House of Parliament, while it is in session, ~ ৬
+ for a total period of thirty days which may ৷
: : be comprised: in one session or in two or i
ত more successive sessions, and if, before the
oo expiry of the session immediately following -
: . ae . the session or the . successive sessions হু
- aforesaid, both Houses agree in making .
< 7 any modification in the rule ‘or both - \
: . ৷ Houses agree that the rule should not be .
. ৰ made, the rule shall thereafter have effect 1
oo : only in such modified form or be of no effect,
ag the casé may he; so, however, that any :
such modification or annulment shall be
১ . without prejudice to. the validity of any- .
. thing previously done under that. rule.”, i
- 19. Thé Indian Partner- In. section 71,— |
৬ ship Act, 1932 (9 of ১২১ . - : |
1932). ৰ্‌ (0) ]]}}; ৪00-960007। (1), 100.106 স্ষ0]93
ঢু “may make rules”, the words “may by noti-
. - fication in the Official Gazette make rules”
. : shall be substituted; - . . : ১
ন (#) after sub-section (3), the following . 7 ৷
, sub-section shall be inserted, namely: — 7
৷ te ৮ ১২১ “(4) Every rule made by the State
Government under this: section shall be ত
+ . 7 , laid, as soon as. it is made, before the
য় , , 7" 5866 ].6%1518.চ01"6.গ), ৰ - ১.5
5 ত লি ত ত Et

<!-- page 9 -->

ত, - ০6 Delegated Legislation Provisions (Amendment)  [&পো 20" .
ৰ হয wets
ৰ No. Short title Amendments
SS ae
20,.The. Agricultural. Pro- Section 3 shall be re-numbered as sub-section
রে duce (Grading. and (1) thereof and after sub-section (1) as so re-
: Marking). Act, 1937 numbered, the following sub-section shall be .
ষ্ঠ ত (1 of 1937). inserted, namely: —
~ “(2) Every rule made by the Central
চু Government under this Act shall be laid, as
ৰ soon as may be after it is made, before each
z ৷ House of Parliament, while it is in session, ছু
: ৷ for a total period of thirty days which may
} be comprised in one session or in two or
‘ 5১ more successive sessions, and if, before the
expiry of the session immediately following
৷ ত “. the session or the successive sessions afore-
5 said, both. Houses agree in making any
৷ modification in the rule or both Houses agree
১ 80৪60790515, 97081027000. made, the rule.
shall thereafter have ‘effect “only in such ৮
2 modified form or be of no effect, as the case ৷
, may be; so, however, that ariy. such modi- ৰু
} -8080010 08000107577 shall be without pre- ৰ
তে . ৷ . judice to the validity of anything previously 7 "ত ৷
ঃ তে . done under that rule.”. ‘ .
4 21. The Muslim Personal, In section 4, after sub-section (3), the follow-
+ Law (Shariat)’ Appli- ing’ sub-section’ shall be’ inserted, namely:—
‘ . cation Act, 1937 (26 ৷
+ Of 1937), ত ত
i . . . . “(4) Every rule made by the State Gov-
৮. ernment under this Act shall be laid, as
ৰু soon as it is made, befote thé State Legis-
চু . Jature.”. * . তি
2 22" ‘The Insurance Act, (1) In section 34H, in sub-section (10),- for
‘ 1938 (4 of 1938). the words “may make rules”; the words “may, ৷
by notification in the Official Gazette, make ২
rules” shall be substituted.’
~ (2) In section 64UB— ~~ . ৷ ঢ়
৷ () in’ sub-section (1), after the words” =
ৰ . “The Central Government may”, the words . 7
7 “\ by _ notification in the Official Gazette,”
. shall be inserted;
. , . Gi) in sub-section (3), after the words ~ . ত
“The Advisory Committee may,”, the words
“by notification. in the Official Gazette,” :
shall be inserted, 7 .
(3) In section 114, for sub-section (3), the 7
৷ =, following sub-section shall be substituted,
i , . -namely;x— |
ৰ ু “(3) Every rule made under this section ৷ :
: + or under sub-section (10) of section 34H or ৷
ত under sub-section (1)- of section 64UB and ৷
1; ঢ় : every regulation made under sub-section (3) :
| oo of section 64UB and .evety regulation made
ad ১225 under this Part shall be laid, as soon as ৷ 1
ছা . may be after it is made, before each. House “|
1 পি ৯ , of Parliament, while it is in session, for a I
tt - ত! ৷ :,__ total period of thirty days which may be ৷ ৷
রে . ২, সঃ ._.comprised-in one session or in two or more. ; ৷
successive sessions, and ‘if, before the expiry :
5 OTT a ne ne geen ne |
‘ |

<!-- page 10 -->

| . -
ৰু ৷ ‘of 1983] Delegated: Legislation “Provisions (Amendment) - 207
ত. 8] ত]. CRP
SL . . " ৷ <
No. __ Short title ~~. «| Amendments 7
pa te
fos : . of the session immediately following ‘the
. ০ , session or the successive sessions aforesaid, .
- ৷ . both Houses agree in making any .modifica~ .
ঢ় - । tion in the rule or regulation or both Houses
o agree that the rule or regulation should not
১ be made, the rule or regulation shall 0162". . .
. after. have effect ionly in such modified form ~
. or be of no effect, as the case may be; so,
. . : however, that. ‘any such modification or .
৷ ~ annulment-shall be without prejudice to the
- validity of anything previously done. under
ৰ! . that rule-or. regulation.”,
- তন In section 12, for sub-section (2), the follow- .
2 . +" GD of 19475. ing sub-section’ shall be substituted, namely: == ঢ়
t ৷ - “(2) Every rule made under this section De
. shall be laid, as soon-as may be after it is
f & made, before each House of Parliament, .
ৰ? ছঠ ৷ while it is in session, for a total period of. -
thirty days which. may be.comprised in one é
৷ Co session or in two or more successive sessions,
ৰ and if, before the expiry of the session .
2 ৰু ৰ ত immediately following the ‘session or the >
ত ত “successive sessions aforesaid, both Houses +
i wo - agree in making any modification in the .
7 ০ rule or both Houses agree that the rule
৷ ৰ? eos ৰ coe should not be. made, the rule shall. there-
ve after have effect only in:such modified form ~ *,
৷ . or .be of ‘no effect, as the case may be; so, -
এ , : however, that any ‘such modification or
হল ু 5 annulment shall be ‘without prejudice to the - :
তত ,_ validity of anything previously done under
০ “ 809৮ 019,৮77
হর Gone 1948 qd) Section 4C shall be re-numbered as sub-
* |, i 11901 ane . t
+ তেৰ of 1948), > section (1) ‘thereof, ‘and - |
. ‘ + (i) in sub-section (1): as so re-number- ঢ়
ৰ ০৮০7০ ed, after the words .“The Authority may”, 1
. . aa ithe: words “, by notification in the Official "
ত Gazette,” shall be inserted; চু ,
ত - (ii) after. sub-section (1) as so re-rium- A
ত Sse. 7 bered, the following. sub-section. shall 126; *
. “ ০৮ inserted, namely:— ~ boone i
: . ঢ় “(2) The Central Government shall
হত তে ৷ . cause every regulation made under this “
. ১2278 section to be laid, as soon as may be
- : wpe ke oe after it is’. made, before each House i
. ভি সতত 0060 of Parliament, while it is in session, "1
1, 8 কিট FR মা 7700৮ a total period of thirty déys which ~ .
vee may be comprised in ong session or in
ু ৷ two or more successive’ sessions, and if, .
. . led before the expiry of the session imme- ৰ
এ diately following the ‘session or’ the.
৷ ২8580 ৪0০০০৪৪]1ঘণ্ড 3685101.8 ৪10069610, 120 700895 .
র ces . . agrée in making any modification in the
ot ao ৷ regulation, or both Houses agree that the
; - 2 - regulation shotld not. be made, the re- .
ত be gulation shall thereafter have effect ,
৷ uo _ only in such modified form or be of no 7
ত > ৰড ২০২ ডন ০৯০৯-০০০০ ৮০০ কল লও ০
