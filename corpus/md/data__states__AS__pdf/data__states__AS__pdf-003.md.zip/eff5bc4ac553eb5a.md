---
doc_id: "eff5bc4ac553eb5a"
source_url: "https://sfcassam.nic.in/home/contituition-notification-fasfc.pdf"
ministry: "State Finance Commission Cell, Assam"
title: "constituted by the Governor of Assam, on 23rd June, 1995,"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9f2626219a0277f7"
---

<!-- page 1 -->

GOVERNMENT OF ASSAM
FINANCE (ECONOMIC AFFAIRS) DEPARTMENT
NOTIFICATION
No.FEA.58/93/Pt/6

ORDERS BY THE GOVERNOR
Dated Dispur the 23rd June, 1995

In pursuance of the provisions of Article 243-I and Article 243-Y of the Constitution
of India, read with the provision of Section 2(1) of the Assam Finance Commission
(Miscellaneous Provision) Act, 1995, the Governor of Assam is pleased to constitute the
Assam Finance Commission consisting of Shri M.M. Taimur, IAS (Retd), Guwahati as the
Chairman and the following four other Members namely:
1.
2.

3.
4.

Dr. Harendranath Das, M.A, LL.M, Ph.D,
Advocate, Guwahati
Prof. Anil Sarma,
Formerly Head of Commerce &
Business Administration Department
Gauhati University,
Guwahati.
Shri Bhupendra Kr. Barua, IAS (Retd.)
Guwahati
Secretary to the Government of Assam
Finance Department

-

Member

-

Member

-

Member

-Member-Secretary

2.
The Chairman shall hold full time office and the other Members of the Commission
shall hold part-time office from the date on which they assume office. The tenure of the
Commission shall be one year from the date of its constitution.
Sd/(T. K. Kamilla)
Additional Chief Secretary to the
Government of Assam
Memo No. FEA.58/93/Pt/6-A
Dated Dispur the 23rd June, 1995
Copy forwarded to:
1. The Secretary to the Governor of Assam.
2. The O.S.D. to Chief Minister, Assam for favour of information of Chief
Minister.
3. Private Secretaries to all Ministers and Ministers of State for favour of
information of Ministers.
4. The Adviser to the Chief Minister of Assam.
5. Private Secretary to the Chief Secretary, Assam.
6. Private Secretaries to all the Additional Chief Secretaries to the Government
of Assam.
7. Shri M.M. Taimur, IAS (Retd.), Hatigaon, Guwahati-6.
8. Dr. Harendranath Das, M.A., LLM, Ph.D., behind Anuradha Cinema,
Bamunimaidan, Guwahati.

<!-- page 2 -->

9. Prof. Anil Sarma, Formerly Head of Commerce & Business Administration
Department, Gauhati University, Guwahati.
10. Shri Bhupendra Kumar Barua, IAS (Retd.) Narikalbasti, Guwahati.
11. The Chairman, Assam Administrative Tribunal.
12. The Chairman, Assam Board of Revenue.
13. The Chairman. Assam State Electricity Board.
14. Principal A.G. (Audit), Assam Shillong/Guwahati.
15. Accountant General Assam (A&E), Shillong/Guwahati.
16. All Special Commissioners and Special Secretaries/Commissioners and
Secretaries/ Secretaries to the Government of Assam.
17. The Commissioner & Secretary, Panchayat and Rural Development
Department.
18. The Secretary, Municipal Administration Department.
19. The Under Secretary to the Government of India, Ministry of Urban
Development, Nirman Bhavan, New Delhi.
20. All Heads of Departments.
21. All Commissioners of Divisions.
22. All Deputy Commissioners.
23. All Sub-Divisional Officers.
24. Principal Secretary, Karbi Anglong District Council, Diphu.
25. Principal Secretary, North Cachar Hills District Council, Haflong.
26. Principal Secretary, Bodoland Autonomous Council, Kokrajhar.
27. The Director, Assam Government Press, Bamunimaidan, Guwahati. He is
requested to publish the notification in the next issue of the Assam Gazette
and send 200 copies of the notification to the undersigned.
By order etc.,
Sd/(S. K. Dutta)
Director,
Finance (Economic Affairs) Department
