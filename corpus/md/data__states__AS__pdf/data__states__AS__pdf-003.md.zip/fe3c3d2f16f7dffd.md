---
doc_id: "fe3c3d2f16f7dffd"
source_url: "https://aec.ac.in/media/tenders/260603-NIT_for_Appointment_of_Statutory_Auditor_of_Assam_Engineering_College_AEC.pdf"
ministry: "Assam Engineering College (AEC)"
title: "NIT for Appointment of Statutory Auditor of Assam Engineering College (AEC)    Published: 03 Jun 2026 ·  Closes: 18 Jun 2026"
date: ""
pages: 12
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "7e3634b4f1a83caa"
---

<!-- page 1 -->

ffi
ffi
GOVERNMENT OF ASSAM
OFFICE OF THE PRINCIPAL:::ASSAM ENGINEERING COLLEGE

JALUKBARI, GUWAHATI, PIN. 781O1}ASSAM, INDIA
Email: principal@aec.ac.in

NO rtE|.I.TEI

o ate:. . . Q..b.1.. p..h. 1. .20.?

L

NOTTGE |NV|TING TENDER (NlT)

The Principal, Assam Engineering College (AEC) invites sealed tenders from eligible Chartered
Accountant firms for appointment as Statutory Auditor of Assam Engineering College (AEC) for the
Financial Year 2025-26.

lnterested firms fulfilling the eligibility criteria may submit their Technical Bid and Financial Bid in
separate sealed envelopes in accordance with the terms and conditions prescribed in this tender
document.
EMD (<)

sl"

01.

in the form
of DD in favour of
Principal. AEC

Items

No.

Appointment of Statutory Auditor of
Assam Engineering College (AEC) for
the Financial Year 2025-26.

10,000,00

Tender Document
Fee (<) in the form of
DD only in favour of

Principal, AEC
500.00

IMPORTANT DATES:

01. Last date & Time for Submission of bids :
02. Date/Time for 0pening of Tech. Bids :

18.06.2026 (14.00 HRS)
18.06.2026 (15:00 HRS)

After evaluation of technical bids, financial bids of the successful bidders will be opened on a later date
which will be notified.
Venue of Bid

Opening: Office of the Principal, Assam Engineering College, Jalukbari,
Guwahati, Assam-781 01 3

Page 1 of 12

<!-- page 2 -->

SECTION {: BAGKGROUND OF THE TNSTITUTTON

1.2 lntroduction

..

Assam Engineering College (AEC), established in 1955, is one of the
Government engineering
colleges under the Technical Education Department, Government of Assam,
and is located at Jalukbari,
Guwahati - 781013.

.
. The College functions as a prominent technical institution of the State and undertakes academic,
administrative,

developmental and student-related activities requiring maintenance of institutional

accounts and financial records.

2.2 lnstitutionalActivities
The College broadly undertakes the following activities:
- Academic and research activities,
- Administration of Government grants and funds,
- lnfrastructure development and maintenance.

- Studenlrelated services including hosteland scholarship-related administration.
- Procurement of goods and services.

3.2 FinancialFramework
The financial operations of the coilege generally include the following:
- Government grants and other sanctioned receipts.
- Student fee collections and related institutional receipts.
- Revenue and capital expenditures.
-Asset acquisition, maintenance and record keeping.

The accounts and records of the College are required to be maintained in accordance with
applicable Government instructions, accounting principles and relevant statutory requirements.

SEGTION 2: INSTRUGTIONS TO BTDDERS

2.1 Bid Structure
The bid shall consist of the following two parts:
- Technical Bid.
- Financial Bid.

The Technical Bid and Financial Bid shall be submitted in separate sealed envelopes, each
superscribed appropriately, and both envelopes shall be placed in one larger sealed envelope
addressed to lhe Principal, Assam Ensineering Cotlese, Jatukbari, Guwahati - TBlOlJ.

2.2 Submission of Bid
- The bid shall be submitted in sealed cover within the date and time as specified in the notice.

- Bids received after the prescribed date and time shall be rejected summarily.
- The College shall not be responsible for delay, loss or misplacement in transit.

- lncomplete bids or bids not accompanied by the required documents are liable to be rejected.

2.3 Earnest Money Deposit (EMD)
The bidder shall furnish Earnest Money Deposit (EMD) of the amount specified in the tender
notice, in the form and manner prescribed therein.

However, bidders holding valid Udyam Registration shall be eligible for exemption from
payment of EMD, subject to submission of self-attested copy of valid Udyam Registration Certificate
along with the Technical Bid.

Page 2 of 12

<!-- page 3 -->

2.4 Bid Validity
The bid submitted by the bidder shall remain valid for a period of g0 (ninety)
of opening of the Technical Bid,

days from the date

2.5 Clarification
. Assam Engineering College reserves the right to seek clarification or additional supporting
documents from any

bidder in respect of the bid submitted. Submission of clarification shall not'confe-r
any right upon the bidder to alter the substance of the original bid,

SEGTION 3: ELlGlBlLlTy CRITERIA
The bidder must satisfy the following minimum eligibility conditions:
The firm must be a Chartered Accountant firm registered with the lnstitute of Chartered
' Accountants
of lndia (lCAl).
. The firm must be empanelled with the Comptroller and Auditor General (CAG) of lndia.
. The firm must have at least 2 (two) Full-Time Fellow Chartered Accountant (FCA)
partners resident in Assam.
o -The firm shall have an office in the State of Assam for a minimum period of 5 years.
. The firm must have a minimum of 3 (three) years of continuous practice
as on the
relevant cut-off date.
o The firm should have experience in audit of Government Departments, Government

lnstitutions, PSUs, Autonomous Bodies, Educational lnstitutions or similar public sector
entities.

. The firm must not be under any disqualification, debarment or professional misconduct
order that materially affects its eligibility to undertake the assignment.
Documentary evidence in support of the above shall be furnished as part of the Technical Bid.

SEGTION 4: SGOPE OF WORK

4.1 General Scope
The selected firm shall conduct the statutory audit of Assam Engineering College for the
FinancialYear 2025-26 in accordance with:
- Standards on Auditing issued by lCAl.
- Applicable Government rules, regulations and instructions.
- Applicable accounting principles and reporting requirements relevant to the institution.

4.2 Detailed Scope
A. Financial Statements
Audit of the annual financial statements, including:
Balance Sheet.
lncome and Expenditure Account.
Receipts and Payments Account.
Notes, schedules and supporting statements, wherever prepared by the College,

-

B. Books ofAccounts
Examination of books of accounts and primary accounting records, including:
Cash Book.

-

Page 3 of 12

<!-- page 4 -->

- General Ledger.

: 3iilil3f if'.i.,

and registers made avaitabte.
Verification under this component shall ordinarily be carried out on

a test-check basis.

C. Bank and Cash
Review of:

- Bank accounts and bank reconciliation statements.
- Cash records and cash book balances.
- Relevant supporting records relating to receipts and payments.

D. Grants and Fund Utilisation
Verification of:
Grants, aids and other funds received.

- Utilisation with reference to sanction orders, terms and conditions, and records
made available,
- Expenditure mapping, wherever relevant, with supporting vouchers and records.

E. Fixed Assets
Verification of:

- Fixed Asset Register and related records.
- Additions, deletions and adjustments during the year.
- Supporting documents relating to acquisition and capitalization.

Physical verification, where considered necessary may be carried out on a sample basis
with reference to records and access made avairabre by the college.

F. Statutory Compliance
Verification of compliance records relating to, inter alia:
Tax Deducted at Source (TDS).
Goods and Services Tax (GST), wherever applicable.
Other statutory deductions and remittances reflected in records,

-

Such veriflcation shall be undertaken with reference to the books, returns, challans,
statements and records produced before the auditor, and reporting shallbe based thereon.

G. Payroll
Test-check of payroll records, including:
Salary payments.

- Statutory and other deductions.
- Relevant approvals and supporting records.

SEGTION 5: RESPONSIBILITIES OF THE GOLLEGE
The College shall:
Prepare the annual financial statements and connected schedules.
Maintain proper books of accounts, registers and records,

- Provide vouchers, sanction orders, utilisation records, bank reconciliation statements,
asset records and other supporting documents as may be required for audit.
- Facilitate access to records, officers and responsible functionaries for the purpose of audit.
- Furnish explanations, confirmations and representations, wherever considered necessary.
Page 4 of 12

<!-- page 5 -->

The audit shall be conducted on the basis of records, statements, explanations and
information made
available by the College during the course of audit.

SECTION 6: DELIVERABLES
The selected auditor shall submit the following in duplicate:

- FinalAudit Report
- Management Letter / Letter of Observations containing significant deficiencies,
irregularities or recommendations, if any.

SEGTION 7: PERIOD OF ENGAGEMENT
The engagement shall be for the Financial Year 2025-26.

SEGTION 8r TEGHNIGAL EVALUATTON GRITERIA

8.1 Technical Scoring Matrix
o Technical Proposals shall be evaluated on the basis of the following criteria with a
maximum score of 100 marks,
. The minimum qualifying marks in the Technical Evaluation shall be 20 marks.
'
The technical evaluation criteria shall be as follows:
sl.

Evaluation Criteria

No.

Maximum
Mark

Documents required

lCAl Firm Certificate
A

Minimum 3 years of continuous practice - 5 marks

15

as on0110412026

20

* on 0110412026

10

CAI Firm Certificate
ls on 01/04/2026

For every additional completed block of 5 year- 1 marks
umber of Full-Time Partners
B

c

CAI Firm Certificate

2mark per FCA
1 mark perACA
marks per partner associated with firm for over 10
Knowledge (any Partner)
Degree/Diploma in Procurement - 10 marks

ments and Tea

Certificate course in Procurement - 5 marks

D

Certificate Course on GST
2 ma
Note: Marks shall be awarded based only on

10

ions/certifications of the only one partner assigned
Experience of Government/PSU

of Work Orders

excluding private entities and banks)

1 mark per unique audit assignment during the last th
E

rancial years (max '10 marks)

Audit of at least one Externally Aided Project
JICA etc.) in the last three years - 5 marks

Past audit experience of at least one
nstitute/University in last three years - 5 marks

Page 5 of 12

20

<!-- page 6 -->

Evaluation Criteria
of Full-Time CA Employees
2 marks per fulltime CA employee associated for over 1

Annual Turnover of the Firm (Last 3 years i.e
-23,2023-24 &2024-25)

. Upto{9Lakhs-2Marks
. Above{9 Lakhsto{ l Crore-5marks
. Above { 1 Crore and up to t 2 Crore - 10 marks
. .Above t2 Crore- 15 marks

btalMarks
Total Marks: 100
Minimum Qualifying Marks: 20

The College reserves the right to verify any information furnished by the bidder and
to
disqualify a bid in case of misrepresentation, suppression of facts or. non-rubrission
of requisite

documentary evidence.

SEGTION 9: FINANC|AL BtD

o The Financial Bid shall be submitted strictly in the prescribed format only,
'

The minimum professional fee shall be Rs. 3,50,000/- (Rupees Three Lakh Fifty Thousand

'

Any financial bid quoting an amount below Rs. 3,50,000/- excluding GST shall be treated

'

Among the technically qualified bidders, the bidder quoting the lowest financial amount above
or equal to the minimum prescribed fee shall be considered for award.

only), excluding GST.

non-responsive and shall be rejected outright.

as

o ln the event that two or more technically qualified bidders quote the same financial rate, the
tender shall be awarded to the bidder securing the highest marks in the Technical Evaluation.

SEGTION 1O: GENERAL TERMS AND CONDITIONS

10.1 Confidentiality
The selected auditor shall maintain strict confidentiality in respect of all records, information
and documents obtained during the course of the assignment and shall not disclose the same to any
third party except as required by law or with prior written approval of the competent authority.

10,2 Independence and Gonflict of lnterest
The auditor shall remain independent throughout the period of engagement and shall prompfly
disclose any actual or potential conflict of interest that may impair professional independence'oi
objectivity.
Page 6 of 12

<!-- page 7 -->

10.3 No Subcontracting
The assignment shall not be subcontracted or assigned

to any other firm or entity without prior

writtenapprovaloftheCollege.ordinarily,subcontracting'li,iinotbe[ermitteJ

10.4 Right of Acceptance or Rejection
The College reserves the right to.accept or reject any

assigning any reason thereof, and the decision of the

or all bids, wholly or pargy, without

Colbge in irris regaro sn* oe final and binding.

10.5 Termination

The College reserves the right to terminate- the engagement

at any stage for unsatisfactory
loss of eligibiliir,;onflict of interest, or for administrative
reasons, subject to applicable rules and contractual conditions.
performance, breach of terms and conditions,

10.6 Jurisdiction
Any dispute arising out of or relating to this tender or the

jurisdiction of the competent courts at

engagement shall be subject to the

Guwahati, Assam.

SEGTION { 1: DOGUMENTS TO BE SUBMTTTED
The Technical Bid shall contain self-attested copies of the

following documents, as applicable:

- lcAl registration certificate / firm constitution certificate.
- CAG empanelment letter / proof of empanelment.
- Valid lD proof of partners resident in Assam (Voters Card/Adhaar/ Driving License)
- PAN of the firm.
' GST registration certificate, if applicable.
- valid udyam Registration certificate, if claiming EMD exemption.
- Details of partners with membership numbers ind fulltime status.
- certificate regarding years of practice / date of constitution.
- Details of relev_ant audit experience with copies of work orders, appointment letters or
completion certifi cates.
- Turnover / gross receipts certificate from a Chartered Accountant, wherever required.
- Declaration regarding non-blacklisting, non-debarment and absence of conflict of interest.
- Any other document as may be specified in the tender notice.

Page 7 of 12

<!-- page 8 -->

ANNEXURE - I
FIRM PROFILE
(To be submitted on the letterhead of the firm)

1. Name of the Firm:
2. lCAl Registration Number:
3, Date of Constitution;

4 Type of Firm: Partnership / LLp / proprietorsl"up

5. Head Office Address;
6. Address and date of establishment of Branch Offices
7. Total Full-Time Partners (FCA + ACA):
Average Annual Turnover (Fy 2022-25,2021-24 &2024-25):7
9
9. CAG Empanelment

Lakh

Number:

10. PAN of the Firm:
1'1. GSI Registration Number :

12. Contact Details:

. Name of Contact person:
. Mobile Number:
. EmaillD:
Declaration
All the information furnished above is true and correct to the best of our
knowledge and belief. We
conflrm that supporting documents including lCAl Firm Constitution
Certificate

as on 01/04 12026 are

enclosed.

Signature:
Name of Authorized Signatory:
Designation:
Seal of the Firm
Date:

Page 8 of 12

<!-- page 9 -->

Annexure.ll
Details of Chartered Accountants in the Firm (including Partners and paid Employees)
Name of the
Partner

Date of

Date of

registration
with lCAl

joining
the Firm

Mem No.

Date of
becoming
FCA

Signature:
Name of Authorized Signatory:
Designation:
Seal of the Firm
Date:

Page 9 of 12

Partner/Paid
Employee

Residential

Address

<!-- page 10 -->

Annexure !ll
Experience of the Firm in Iast three years:
l. Experience of audit in Government/pSU

sl.

Name of the Organization

Year of Assignment

Nature of Assignment

No.

ll" Experience of audit in Externally Aided project 1W
st.

Name of the 0rganization

No.

Year of

Nature of

Loan/CrediU

Assignment

Assignment

Project No

III. Experience of audit of Educational lnstitute/Universities

s!.

Name of the Organization

Year of Assignment

No.

Signature:
Name of Authorized Signatory:
Designation:

Seal of the Firm
Date:

Page 10 of 12

Nature of Assignment

<!-- page 11 -->

Annexure lV
Composition of Team
Details of Partner & Staff Assigned forAudit:
Name of CA

Names of Supporl

Address

Staff

Signature:
Name of Authorized Signatory:
Designation:

Sealof the Firm
Date:

Page 11 of 12

Qualifications

<!-- page 12 -->

F,uftlHIl'ff*X*o,
(To be submitted in a separat.,rrirO

Name of the Assignment: statutoryAudit

envelope)

of Assam Engineering college

for Fy 2025-26

Financialeuote:

we hereby quote our ,urL:Tilofessionar
(Rupees

fee for the above assignment as

folows:
only) (Exctuding GST)

Declaration:
fee is inclusive of all expenses such
'
as travel, boarding, lodging, and
out-of-pocket
]ff.:::ted
' we understand,that GST sha, be payabre extra as appricabre.
' we agree that the quoted amount shill remain varioroi tne entire period of the contract.

Signature:
Name of Authorized Signatory:
Designation:

Sealof the Firm
Date:

Page 12 of 12
