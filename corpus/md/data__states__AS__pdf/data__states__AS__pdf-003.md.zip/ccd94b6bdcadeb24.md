---
doc_id: "ccd94b6bdcadeb24"
source_url: "https://www.nluassam.ac.in/docs/tender_niq/2026/sniq-gold-medal.pdf"
ministry: "National Law University and Judicial Academy, Assam"
title: "click here for details"
date: ""
pages: 2
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "1677fe53d768bf68"
---

<!-- page 1 -->

fer National Law University and Judicial Academy, Assam
/; Se -ঙু।
Ge stn 0 (Established by Assam Act No. XXV of 2009)
৮
TRIE
No.: NLUJAA/ADMIN/CONVOCATION-4(P-1)/2026/70/ 4 {o Date: 14-09-2026
SHORT NOTICE INVITING QUOTATION (SNIQ)
National Law University and Judicial Academy (NLUJA), Assam invites sealed
quotations, affixed with non refundable Court fee stamps of Rs. 8.25/- (Rupees Eight
and Twenty Five paise) only, from reputed and acknowledged jewellers or registered
vendors for the fabrication, engraving, and supply of customised Convocation
Medals for the Convocation Ceremony, 2026.
1. Scope of Work & Technical Specifications
191. Category / Item | ু বিন | Total amount
No.| Description Qty. Technical Specifications | নি
Category I: Class Base of 50 gms pure silver, heavy |
01 Topper 01 000-2090660, 076051017-277060060 খখ|{|7 ৷
| \(B.A., LL.B. (Hons.) a 2.5 gms (24-carat) gold coin in
| | 5-Year Integrated) ৷ 1072 02108.
| \Category II: ‘Base of 50 gms pure silver, heavy |
02 10855 Topper | 01 gold-coated, precision-embedded with
] [ One-Year | (a 2.5 gms (24-carat) gold coin in
| Degree) | |the centre. |
| Ck Base of 50 gms high-grade
\ | | i ৰ |
3 (94. LLB. (Hons.) | 08 |) alloy, heavy gold |
___ |5-Year Integrated) | | : |
Note: All medals must be impeccably finished, featuring a sharp 3D embossing of
the NLUJA Assam University Emblem on the front and custom text engraving (Name,
Year, Course) on the reverse face as provided by the administration.
2. Schedule of Crucial Dates
ত Date of Issue of SNIQ: September 14, 2026
. Last Date & Time for Submission: September 21, 2026 (by 3:00 PM)
. Date & Time of Opening Quotations: September 21, 2026 (at 4:00 PM)
. Final Delivery Deadline: September 30, 2026
3. Mandatory Eligibility Criteria for Vendors
Bidders must submit copies of the following documents along with their financial
quotation. Failure to produce these will result in direct disqualification:
* Local Presence: The vendor must have a registered office within
Guwahati (GMC area). Proof of address (Trade License/Electricity Bill/Lease
Agreement) must be attached.
. Statutory Registrations: Valid GST Registration Certificate and PAN
Card.
Hajo Road, Amingaon, P.O. - Amingaon, District - Kamrup (Rural), Guwahati - 781031, Assam (INDIA)
Phone: +91-361-2738891, Website: www.nluassam.ac.in

<!-- page 2 -->

fen National Law University and Judicial Academy, Assam
de ঠা? ie (Established by Assam Act No. XXV of 2009)
৪

* Experience: Proof of having successfully supplied similar high-value medals,
trophies, or customized corporate jewellery to educational institutions or
government bodies in the past.

4. Earnest Money Deposit (EMD)

* Bidders must deposit a refundable Earnest Money Deposit (EMD) of ₹5,000/
(Rupees Five Thousand only) in the form of a Demand Draft drawn in favor
of "The Registrar, National Law University and Judicial Academy, Assam",
payable at Guwahati.

* Quotations submitted without the EMD will be summarily rejected. The EMD of
unsuccessful bidders will be returned within 15 days of contract finalization.

5. General Terms & Conditions

1. Submission Mode: The financial bid, along with eligibility credentials and EMD, must
be enclosed in a sealed envelope superscribed "Quotation for Convocation Medals
2026" and dropped in the Tender Box at the Admin Block, NLUJA, Amingaon campus
on or before the due date.

2. Rate Inclusions: Rates must be quoted in INR and must be inclusive of all costs—
including the cost of base metals, gold coins, die-making, electroplating, premium
velvet presentation boxes, ceremonial neck ribbons, logistics, and all applicable taxes
(GST).

3. Purity & Hallmarking: The selected vendor must provide an_ official
purity/hallmark certificate issued by an authorized assaying center for both the
silver base and the 24K gold coin components at the time of delivery.

4. Delivery Timeline & Liquidated Damages: Time is a critical element of this
contract. Delivery must be successfully completed on or before September 30, 2026.
In the event of an unexcused delay, a penalty of 1% of the total order value per day
of delay may be levied, up to a maximum ceiling of 10%. Continued failure to deliver
may result in the cancellation of the work order and the forfeiture of the Earnest Money
Deposit (EMD).

5. Sample Approval: The successful bidder will be required to show a base sample/3D
structural layout within 48 hours of receiving the Work Order before initiating bulk
production.

6. University Rights: The University reserves the right to verify vendor premises, check
materials during the manufacturing phase, or reject any or all bids without assigning
any reason.

Registrar
Memo No: No.: NLUJAA/ADMIN/CONVOCATION-4(P-I)/2026/70/ Date: 14-09-2026
Copy to: 41741 ০
1. Finance Officer I/C for information.
2. System Administrator, NLUJA, Assam with a request to upload in the University
website.
3. P.S. to VC for kind appraisal of the Hon’ble Vice-Chancellor.
4. Notice Board |.
Registrar
~~ Hajo Road, Amingaon, P.O. - Amingaon, District - Kamrup (Rural), Guwahati - 781 031, Assam (INDIA)
Phone: +91-361-2738891, Website: www.nluassam.ac.in
