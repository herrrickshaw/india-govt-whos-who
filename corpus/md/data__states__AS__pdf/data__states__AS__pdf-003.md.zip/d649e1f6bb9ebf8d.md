---
doc_id: "d649e1f6bb9ebf8d"
source_url: "https://prisons.assam.gov.in/sites/default/files/swf1/dms95_The%20Transfer%20of%20Prisoners%20Act_%201950.pdf"
ministry: "Assam Prison Headquarters, Assam"
title: "The Transfer of Prisoners Act, 1950 (Central Act XXIX of 1950)"
date: ""
pages: 4
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "99e639d5c09eb8fb"
---

<!-- page 1 -->

The Transfer of Prisoners Act, 1950
(ACT 29 OF 1950)
STATEMENT OF OBJECTS AND REASONS
Section 29 of the Prisoners Act, 1900, inter alia
provides for the interstate transfer of prisoners between the
States in Parts A.C. and D of the First Schedule to the
Constitution. There is no provision, however, either in the
Prisoners Act, 1900 or any other law for the transfer of
prisoners from prisons in those States to prisons in Part B
States and vice versa, Cases may arise where the removal or
transfer of prisoners from Parts A.C. and D States to Part B
States and vice versa may be considered administratively
desirable or necessary. This Bill is intended to provide legal
sanction to such transfers or removals.
(Gaz. of India, 1950, Pt. V., page 180).

<!-- page 2 -->

THE TRANSFER OF PRISONERS ACT, 1950
(ACT 29 OF 1950)
[12% April 1950]
An
Act
to provide for the removal from one State to another
of persons confined in a prison.
Be it enacted by Parliament as follows:
1. Short title and extent. -
(1) This Act may be called the transfer of prisoners Act,
1950.
(2) It extends to the whole of India !|* * *]
2. Definitions. -
In this Act, -
1. Words ‘except the State of Jammu and Kashmir’ omitted by the Central
Laws (Extension to Jammu and Kashmir} Act, 1968 (25 of 1968), w. e. f.
15,.8.1968.

<!-- page 3 -->

(a) “court” includes any officer lawfully exercising civil,
criminal or revenue jurisdiction;

1102) “Government” or “State Government” in relation to a
Union territory, means the administrator thereof;]

(c) “prison” includes any place which has been declared
by a State Government, by general or special order, to
be a subsidiary jail.

3. Removal of prisoners from one State to another. -

(1) Where any person is confined in a prison in a State, -
(a) under sentence of death, or
(b) under or in lieu of, a sentence of imprisonment

or transportation, or
(০) in default of payment of a fine, or
(d) in default of giving security for keeping the peace
or for maintaining good behaviour,
1. Substituted for former clause by A. O.,1956 w.e.f. 1-11-1956

<!-- page 4 -->

the Government of that State may, with the
consent of the Government of any other State,
by order, provide for the removal of the prisoner
from that prison to any prison in the other State.
(2) The officer in charge of the prison to which any person
is removed under sub-section (1) shall receive and
detain him, so far as may be, according to the exigency
of any writ, warrant or order of the court by which
such persons has been committed, or until such
person discharged or removed in due course of law.
4. Amendment of Section 29 of Act III of 1900. -
[Repealed by the Repealing and Amending Act, 1957 (36 of
1957), w. e. f. 17-9-1957.]
লু ৰ 4
