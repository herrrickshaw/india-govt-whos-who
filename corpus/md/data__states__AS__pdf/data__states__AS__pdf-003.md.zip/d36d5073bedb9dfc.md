---
doc_id: "d36d5073bedb9dfc"
source_url: "https://sfcassam.nic.in/home/constitution-notification-tasfc.pdf"
ministry: "State Finance Commission Cell, Assam"
title: "Notification No.FEA.182/2005/375"
date: ""
pages: 6
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "3500632f5bc42b2d"
---

<!-- page 1 -->

GOVERNMENT OF ASSSAM
FINANCE (ECONOMIC AFFAIRS) DEPARTMENT
NOTIFICATION
ORDER BY THE GOVERNOR
No FEA 182/2005/375

Dated Dispur the February 6, 2006

In pursuance of the provisions of Article 243-I and 243-Y of the
Constitution of India read with the provisions of Section 2(1) of the Finance
Commission (Miscellaneous Provisions) Act, 1995, the Governor of Assam is
pleased to constitute the Third Assam State Finance Commission with the
following Members only: 1.
2.
3.
4.
5.
6
2.

Shri H.N. Das,
Ex-Chief Secretary, Assam
Commissioner & Secretary,
Finance
Commissioner & Secretary
Panchayat & Rural Development Department
Commissioner & Secretary
Urban Development Department
Commissioner / Secretary
Guwahati Development Department
Shri H.N. Sharma,
Director, Finance (Economic Affairs) Department.

Chairman
Member
Member
Member
Member
Secretary

The Commission shall make recommendation as to the following
matters:
(a) The principles, which should govern(i)

(ii)

the distribution between the State of Assam and the
Panchayats/Municipalities of the net proceeds of the taxes,
duties, tolls and fees, leviable by the State, which may be
divided between them and the allocation between the
Panchayats/Municipalities at all levels of their respective
shares of such proceeds, after taking into account the transfers
that are to be made by the State of Assam to the Autonomous
District Councils constituted under the Sixth Schedule of the
Constitution;
the determination of the taxes, duties, tolls and fees, which
may be assigned to, or appropriated by, the Panchayats/
Municipalities;

<!-- page 2 -->

(ii)

the grants-in-aid to the Panchayats/Municipalities from the
Consolidated Fund of the State;
(b) The measures needed to improve the financial position of the
Panchayats/Municipalities with special emphasis on rationalization of
properties tax, collection of user charges and innovative realization
methods.
(c) Examine the feasibility and make recommendations on raising of
resources by the Urban Local Bodies through issuance of bonds.
(d) Examine the feasibility and make recommendations on creation of
urban infrastructure and other civic amenities by the Urban Local
Bodies through Public-Private partnership and exploring avenues
of viability gap funding.
(e) Any other matter referred to the State Finance Commission by
the Governor in the interests of the sound finance of the
Panchayts /Municipalities.
3.
The Commission may make an assessment of (a) the actual debt
position of each of the Local bodies as on 31-03-2005 and (b) estimated debt
position of each Local bodies as on 31-03-2006 and suggest suitable measures
relating to the debts as are deemed necessary, keeping in view the financial
requirements of the State Government also.
4.
In making its recommendations the Commission shall have regard,
among other Considerations, to: (i)
the objective of balancing the receipts and expenditure on
revenue account of both the Local Bodies as a whole and the State Government
and each Local Body;
(ii)
the resources of State Government and demands thereon, in
particular, on account of expenditure on maintaining of law and order, civil
administration, debt servicing and other committed expenditure;
(iii) the revenue of the resources of the Local Bodies for the five years
commencing on 1st April,2006 on the basis of the level of collection made
during 2004-05 from taxes, duties, tolls, fees, cess etc. levied by the them;
(iv) the potential for raising additional revenue from the existing
sources available to them; and
(v)
the scope for better financial management consistent with
efficiency and economy in expenditures.
5.
In making its recommendations on the various matters aforesaid, the
Commission shall adopt the population figures of latest Census available in all
cases where population is regarded as a factor for determination of devolution
of taxes and duties and grants-in-aid.

<!-- page 3 -->

6.
The Commission shall indicates the basis on which it has arrived at its
finding and make available the Local Body wise estimates of receipts and
expenditure.
7.
The Commission shall make its report available to the Governor of
Assam by 31st December, 2006 on each of the matters aforesaid, covering
period of five years commencing on the 1st April, 2006.
Sd/(H.S. Das)
Commissioner & Secretary
to the Government of Assam
Finance Department.

<!-- page 4 -->

GOVERNMENT OF ASSAM
FINANCE (ECONOMIC AFFAIRS) DEPARTMENT
NOTIFICATION
ORDERS BY THE GOVERNOR
NO FEA 266/2005/65

Dated Dispur the July 3, 2006

In partial modification of the notification NO FEA 182/2005/375 dated
06.02.2006, Governor of Assam is pleased to reconstitute the Third Assam
State Finance Commission (TASFC) with the following Members:
i
ii
iii
iv
v

Shri H.N Das, IAS (Retd) Ex-Chief
Secretary, Assam
Shri S.L Mewara, IAS
Commissioner & Secretary, Panchayat &
Rural Dev. Department
Shri B. Dutta, IAS
Commissioner & Secretary,
Urban Development Department
Dr. Ashish Bhutani, IAS
Secretary, G.D.Department
Shri K.V Eapen, IAS
Commissioner & Secretary,
Finance Department.

Chairman
Member
Member

Member
Member- Secretary

2. Others terms and conditions as mentioned in Para (2) to Para (7) of
the Notification No. FEA 182/2005/375 dated 06.02.2006 will continue.
Sd/(H. S.Das)
Commissioner & Secretary to the Govt. of Assam,
Finance Department

<!-- page 5 -->

GOVERNMENT OF ASSAM
FINANCE (ECONOMIC AFFAIRS) DEPARTMENT
NOTIFICATION
NO FEA 266/2005/Pt-I/5

Dated Dispur the March 16, 2007

Consequent upon transfer of Shri S.L. Mewara, Commissioner and
Secretary, Government of Assam, Panchayat and Rural development and
Member of the Third Assam State Finance Commission (TASFC) to Education
Department, Shri Davinder Kumar, IAS has joined as Commissioner and
Secretary, Government of Assam to Panchayat & Rural Development
Department from 26.09.2006. As such, it is hereby notified that Shri Davinder
Kumar, IAS, Commissioner and Secretary, Panchayat & Rural Development
Department has been appointed as a Member of TASFC retrospectively with
effect from the date of his joining as Commissioner & Secretary of Panchayat
and Rural Development Department i.e. from 26.09.2006 in addition to his
normal duties in place of Shri S.L Mewara , IAS.
Sd/(H.S Das)
Commissioner & Secretary to the Government of Assam,
Finance Department

<!-- page 6 -->

GOVERNMENT OF ASSAM
FINANCE (ECONOMIC AFFAIRS) DEPARTMENT
NOTIFICATION
NO FEA 266/2005/80

Dated Dispur the July 25,2006

In partial modification of earlier Notification No. FEA.
266/2005/66 dated 03/07/2006, Shri G.D. Tripathi, IAS, Joint Secretary,
Finance Department will work as Secretary, TASFC & head of the State
Finance Commission Cell in addition to his normal duties in place of Shri
H.N. Sharma, Director, Institutional Finance Department. For this purpose
he will be assisted by officers & staff to be provided by concerned
Departments to the State Finance Commission Cell. Shri G.D. Tripathi will
take immediate necessary steps to identify officers & staff from various
Departments to man the State Finance Commission Cell.
Sd/(K.V. Eapan)
Commissioner & Secretary to the Government of Assam,
Finance Department
