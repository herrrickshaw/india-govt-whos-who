---
doc_id: "fbe0f7bba777c49b"
source_url: "https://assampetrochemicals.co.in/pdf/Wages_Nomination_Form_I-2.pdf"
ministry: "Assam Petro-chemicals Limited (APL)"
title: "NOMINATION DECLARATION FORM - Payment of Wages (Nomination) Rules, 2009"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b7cf400f02606ea3"
---

<!-- page 1 -->

FORM – I
NOMINATION DECLARATION FORM
(See rule 3)
Payment of Wages (Nomination) Rules, 2009
1. Name of person making nomination :
(in block letters)
2. Father’s/Husband’s name

:

3. Date of Birth

:

4. Sex

:

5. Marital Status

:

6.

Address- Permanent:

Temporary:

I hereby nominate the person(s)/ cancel the nomination made by me previously and nominate the
person(s) mentioned below to receive any amount due to me from the employer, in the event to my death.
Name of the
nominee/nominees

(1)

Address

(2)

Nominee’s
relationship
with the
member

(3)

Date of
Birth

(4)

Total amount
of share of
accumulations
in credit to be
paid to each
nominee
(5)

If the nominee is minor,
name, relationship and
address of the guardian
who may receive the
amount during the
minority of nominee
(6)

<!-- page 2 -->

1. Certified that I have no family and should I acquire a family hereafter, the above nomination
shall be deemed as cancelled.
2. *Certified that my father/mother is/are dependent upon me.

3. *Strike out whichever is not applicable.

(Signature or the thumb Impression of the employed person)
APL Employee Code: ___________________________

Salary Code/ OIL ID

CERTIFICATE BY EMPLOYER

Certified that the above declaration and nomination has been signed/thumb impressed before
me by Shri/Smt./Kum …………………………………………………............................……employed
in my establishment after he/she has read the entry/entries have been read over to him/her by me and
got confirmed by him/her.

Signature of the employer or other authorised
Officer of the establishment and
Designation
Place:
Date:

Name and Address of the Factory/
Establishment and rubber stamp thereof
