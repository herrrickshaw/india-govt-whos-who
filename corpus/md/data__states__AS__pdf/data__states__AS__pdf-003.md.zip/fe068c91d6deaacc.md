---
doc_id: "fe068c91d6deaacc"
source_url: "https://dma.assam.gov.in/sites/default/files/swf1/dms62_sanction_for_delayed_interest_against_2nd_instt._of_2015-16_under_14th_fc.pdf"
ministry: "Directorate of Municipal Administration, Assam"
title: "sanction_for_delayed_interest_against_2nd_instt._of_2015-16_under_14th_fc.pdf"
date: ""
pages: 4
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "ea9b030d5f1e4281"
---

<!-- page 1 -->

CEE EE NS
te GOVERNMENT OF ASSAM
@ URBAN DEVELOPMENT DEPARTMENT
DISPUR:::GUWAHATI-6.
No. UDD(M)202/2015/PU08 Dated, Dispur the 1“ October, 2018
From : Shri H.K. Saikia,
Deputy Secretary to the Govt. of Assam,
Urban Development Department.
To : The Principal Accountant General (A&E), Assam, ,
Maidamgaon, Beltola, Guwahati-29.
Sub: Sanction towards release of delayed interest payment for an amount of Rs. 12,15,199.00 ,
against delay of release of 1 installment of General Basic Grant of ULBs under the Award of
14" Finance Commission for the year 2016-17 during the year 2018-19.
Ref: Director, Municipal Administration's letter No. DMA(Proposal)21 1/201 8/07 dated, 05.07.2018
Sir,
I am directed to convey the sanction of the Governor of Assam for an amount of
Rs. 12,15,199.00 (Twelve lakhs fifteen thousand one hundred ninety nine only ) against delay of release of 1
installment of General Basic Grant of ULBs under the Award of 14" Finance Commission for the year 2016-
17 during the year 2018-19...
A statement showing District wise breakup of amount of each ULBs is shown at
Annexure-I,
৷ The sanction is issued with the following conditions:-

1, This amount may be utilized against schemes to be selected by ULBs as per guidelines of Govt. of
India, MOF.

2. The Director, Municipal Administration, Assam who is declared as the DDO in respect of 14" FC
funds shall draw and disburse funds to each of the ULBs in their accounts duly registered under PFMS
and the amount shall be transferred through ECS.

3, The ULBs shall utilize the fund as per Guidelines of 14 FC and they shall be responsible for any
violation of guidelines. The overall responsibility for compliance of guidelines shall continue to rest
with the Director, Municipal Administration, Assam.

4. Utilization certificate are to be submitted by the Chairpersons of MBs/TCs for the period of 2010-11 to
2014-15 along with photographs of completion of schemes to the Director of Municipal
Administration, Assam who will submit UC duly countersigned by her to the Government for further
necessary action.

The expenditure is subject to observance of all financial rules, procedures and formalities,
Calling of NIT as per CVC Guidelines, and observance of the provisions of AFRBM Act, 2005.
The expenditure is debitable to the Head of Account “2217 — Urban Development _ 80 -
General — 192 — Assistance to Municipalities / Town Committees — 5463 — Award of Central Finance
Commission — 689 — Interest payments — 32 — Grants in aid(Non Salary) — 02-Spill Over TG-FFC ” under
Grant No. 34 for the financial year 2018-19.
The validity period in respect of Director, Municipal Administration, Assam to act as Drawing
& Disbursing Officer (DDO) for drawing & disbursement of fund to the MBs / TCs under the above Head of
Accounts will continue as per letter No.FEB37/2008/33 dated 10.01.2011 until further order.
The Sanction is issued with the concurrence of the Finance (Economic Affairs) Department's
U/O dated 27.09.2018.
This Sanction letter cancels the earlier Sanction accorded vide No, UDD(M) )202/2015/Pv0S
dated 20" July, 2018.
Yours faithfully,
৩৮
Qe iv
Deputy Secretary to the Govt. of Assam,
ও, // Urban Development Department
Scanned by CamScanner

<!-- page 2 -->

@
Memo No. UDD(M)202/2015/Pt/08-A Dated, Dispur the 1“ Getober, 201%
Copy to:
1, The Director, Municipal Administration,Assam, Dispur, Guwahati-6, This has reference to her letter
No. DMA(Proposal)21 1/2018/07 dated, 05.07.2018
2. The Director, Finance(EA) Department, Dispur, Guwahati-6.
3. The Director, Finance (Budget) Department, Dispur, Guwahati-6, ,
4. The Director, Accounts & Treasuries, Kar Bhawan, Dispur, Guwahati-6 for information and necessary
action.
5. The Director, Audit(Local Fund), Kar Bhawan, Dispur, Guwahati-6 for information and necessary
action
6. The Director of Financial Inspection, Assam, Kar Bhawan, Dispur, Guwahati-6. |
7, The Under Secretary, Ministry of Urban Development, Govt. of India, Nirman Bhawan, New Dethi-
110011.
8. The Director, Govt. of India, Ministry of Finance, Department of Expenditure, Finance Commission
Division, Block No.11, Floor, CGO Complex, New Delhi-110003.
9. The Principal Accountant General (Audit), Local Bodies ( Audit & A/C), Assam, Beltola,
Maidamgaon, Guwahati-29,
10. All Deputy (০011111951017075.,.......০০,,০০০০০০০০১০০ ASSAM.
By order etc.
% ০১৩৮৮
Deputy Secretary to the Govt. of Assam,
৬৮ Development Department
Memo No. UDD(M)202/2015/Pt/08-B Dated, Dispur the 1“ October, 2018
Copy to:
1.The Principal Accountant General (Audit), Assam, Maidamgaon, Beltola, Guwahati-29,
2.The Treasury Officer, Dispur, Guwahati-6. P
1
Financial Adviser,
৬৮ Development Department
Scanned by CamScanner

<!-- page 3 -->

| , ANWEXURE-f 212
ULB wise distribution of delay payment of interest against the Ist instt. of General Haste Grant of 1
i y * 3520:22,000.00 under 14th Finance Commission for the year 2016-17 during the year 2018-19
গু
In Rs.
91. City/Town Name ofthe | Released amount against | Proposed amount for delay গমন]
No. District | Ist instt. of General Basic interest (for 21 days) 8 or of
Cen ea tah re
6% upto Sth June, 2018)

[_ [০৮৮7ত a জজ
| ro
লু] 1 LL জল
[| _য্
=
না পল” | জজ ===
টি হল দিল
a a ee
মন্দ লা ল্ছদ
ছশ | হি
a ee
দল a _ কল
a a ক্র
আত য়
2 1
Sere টি
উর ৰম ===.
জী rere] $s
ই ery —— $$
৮
রিতু. |] a মস
মম
| ওগাঞঞ্মাত__ J 296009000 জাই
| 7০7 2047300.00 বি
|_37[Fisborte J 37538401,00) হজ
Kamrup (R) 1448410.00) ক
[ 2৬৪৮ত 5366490.00 ইজ

্থমছডতে 10878000 সন্তৰ hu
[_ ai Korineany ] Karimganj 7485760.00) Tei

a দাত সি আজ é

সপ ৫৩

Scanned by CamScanner

<!-- page 4 -->

FEE  ট িাীি )

. , ANNEXURE «J I"
15. City/Town Name of the | Released amount against Proposed amount for delay payment of
No. Ist inst, of General Basi | interest (Hor 21 days) against Ist instt. of
© Grant, 2016-17 during 2017] GHG of Rs. 3520.22 Inkhs for the year
18 2016-17 (current HBT Bank Interest rate

6% upto 5th June, 2018)

| ন 77
Lakhimpur 9306810,00) 32128.00
26288700017 90750)
2339810.00 আছ 8077.00
হা | 2289180.00 চু 7903.00
a 7 েনৰৰভভৰ = 7479
a দলদ|
| ভলল|
_ ম্ল্দ7্্
psi 17 লা
শাল -জ্লুললুদ
[জলজ]
নাজ্ঞ্ন্ল_7
নত] "লিল
লন] দি
oo ললল
নিল 7 7

|

জল ক্ছদদ্দদ্1_ | ₹

ct OKs

Scanned by CamScanner
