---
doc_id: "8bb5efda547ea63d"
source_url: "https://aau.ac.in/assets/files/temp/Corrigendum-1.pdf"
ministry: "Assam Agricultural University"
title: "Notification (PDF)"
date: ""
pages: 1
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "90917258bee50e57"
---

<!-- page 1 -->

১ Office of the Registrar
©) Assam Agricultural Gniversity
২ ewe 1 SD
উহ JORHAT - 785013
(RECIPIENT OF SARDAR PATEL OUTSTANDING INSTITUTE AWARD)
No. AAU/2.1(21)/-A-2026/RG/2025-26/ 12. 6 1% Dated 14 / Lo /2026
CORRIGENDUM
In partial modification of Advertisement No. 4/2026, notified vide Memo No. 2.1(21)/-A-
2026/RG/2025-26/11,296 dated 29.09.2026, the total number of posts in the following
departments shall be read as indicated below:
1. Agricultural Economics: 02 (Two) posts instead of 03 (Three) posts.
2. Tea Husbandry & Technology: 02 (Two) posts instead of 01 (One) post.
The other terms and conditions will remain the same.
, Sd/- Damodar Barman, ACS
Registrar,
দ্খ Assam Agricultural University,
Jorhat-785013.
Memo No. AAU/2.1(21)/-A-2026/RG/2025-26/_12,613-6%9 Dated _14 / Jo /2026
0 ‘opy forwarded | for information and necessary action to :
1, The Secretary to the Vice-Chancellor, AAU, Jorhat.
2. The Comptroller, AAU, Jorhat. =
3. The Dean, Faculty of Agriculture/ Community Science, AAU, Jorhat
4, The Director of P.G. Studies /Research (Agri.)/ Extension Education/Physical Plant/
Students Welfare/ Extension Education Institute AAU, Jorhat/ Khanapara, Guwahati-22.
5. The Associate Dean, B.N.C.A/ SCSCA/CH&FSR, AAU, Biswanath /Dhubri/Nalbari
6. The OSD, College of Sericulture, AAU, Titabor
7. The Jt. Registrar (Acad.), AAU, Jorhat
ৰু 8. The Deputy Registrar (P), AAU, Jorhat
: 9. Dr. A. Saikia, Professor and I/c AKMIT Cell, AAU, Jorhat
10. The IT Officer, AAU, Jorhat. He is requested to incorporate the Notification in the AAU website. 7
নার, ped ৰু
Registrar,
Assam Agricultural University,
Jorhat ~ 785013
