---
doc_id: "5f518eb2cccd7ff4"
source_url: "https://barpeta.assam.gov.in/sites/default/files/public_utility/SINT%20for%20hardware.pdf"
ministry: "Barpeta"
title: "Short Notice Inviting Tender for procurement of IT Equipment in connection with Census, 2027  New"
date: ""
pages: 2
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "f5c8554a89947b19"
---

<!-- page 1 -->

f t
GOVERNMENT OF ASSAM
OFFICE OF THE DISTRICT COMMISSIONER :2:::::¢:¢¢:2; BARPETA.
(Census Branch)

Address : Contact details :

Ward No-5, P.O- Barpeta, P.S- Barpeta Ph No-03665-252129
Pin-781301 Email-de-barpeta@nic.in
No. BDD-119/2026/Census-2027/Other/13 Date:- .%2 ./05/2026

SHORT NOTICE INVITING TENDER

Sealed quotations affixing court fee stamp of Rs. 8.25 (Rupees Eight and
Twenty-Five Paisa) only are hereby invited from registered/reputed intending local
firms/ agency for procurement of IT Equipment in connection with Census’2027,
under the following terms and conditions.

The quotations will be received up to 3:00 P.M. of 30/05/2026 & will be A
opened on the same day at 4.00 PM & venue in presence of intending bidders or
their authorized representatives. Quotations will have to be deposited in the tender
box kept addressed to the Office of the District Commissioner, Barpeta.
si. : Unit Price in
No: Item Description Specification/Configuration INR (Including

. all Taxes)

Intel 15 (14™ Generation), 16gb

4 Laptop with Windows, | RAM, 1TB Hard Drive, |

MS Office, Antivirus etc. Windows, MS Office and

| | Antivirus |

a. 24 inch Monitor (Full HD) >

| intel 13 (14™ Generation), 16gb |

RAM, 1TB Hard Drive, UPS |

Desktop with UPS with 1500v Windows, MS Office and | ৰ

| 2 3-4 hrs backup, Antivirus. / |

Windows, MS Office, b. 24 inch Monitor (Full HD) |

Antivirus etc. Intel 15 (14™ Generation), 16gb

i RAM, 1TB Hard Drive, UPS |
1500v, Windows, MS Office
and Antivirus |
<= চু Canon LBP6030B Single ee es
Function Monochrome Laser |
£ 3 Laser Printer Printer/Canon Image CLASS |
MF3010 Laser Multifunction |
Printer | |
Canon Ir 2006n Photocopier | |
চু নি Machine
3 EF Canon Image FORMULA P-
২ 6 Scanner Machine 208II/ HP ScanJet Pro 2000 $2 |
4 ৷ = Sheet- Feed Scanner |
ন নি Ee 88742 Screen 8 গিলে Per day hiring |
} ৷ Page 1 of 2 (১

<!-- page 2 -->

এ is
7 *
/ Terms and Conditions
ৰ 1. The tenders will have to be accompanied by up-to-date GST and Income
Tax documents from the competent authority. F
2. EMD/Bid Security of Rs. 20,000/- (Rupees Twenty Thousand) only are to
be deposited in cash or Bank Draft pledged in favour of District
Commissioner, Barpeta.
3. The rate should be quoted inclusive of all taxes,
4. The quotationer must attach photocopies of:
i.  Firm’s Govt. Registration Certificate
॥. GST Registration Certificate
iii, PAN Card
iv. Trade License from MB
v. IT Return of last 3 (three) years
vi. Bank Account Number
vii. GST Return for the last 3 (three) financial years
viii. Earlier experience, if any
5. L1 rate for each item will be decided in the tender. All work orders will be
issued in L1 rate only. Supply order for each listed item will be given to the
bidder who has quoted L1 rate for that particular item.
6. The approved firms/agency must supply the equipment at the Census
Branch immediately as and when required, at their own cost.
7. Rates once accepted will not be changed and will remain valid for a period
of one year.
8. Payment will be made as and when funds are received. ,
9. The details of the items can be collected from the Census Branch, O/o The
District Commissioner, Barpeta.
10.The Principal Census Officer has the right to accept or reject any or all
tenders without assigning any reason thereof and has the right to fix the
3 Price of any materials as per prevailing market rate.
ৰল soll 12,
District Commissioner
& Principal Census Officer, Barpeta
Memo:- BDD-1 19/2026/Census-2027/Other/ 13-A Date: 22/05/2026
£ Copy to:
1. The Director, Directorate of Census Operation, Assam, Amingaon, Ghy-31 01
7 of kind information
~. The DIO, NIC, Barpeta. He is requested to upload SINT in District Website
‘3. The DIPRO, Barpeta is directed to give widespread publigity td\the above tender
ৰ মাঃ
& Principal Cénsus Officer, Barpeta i
[ : Page 2 of 2
