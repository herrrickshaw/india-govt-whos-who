---
doc_id: "9add35dbaddc3a4e"
source_url: "https://barpeta.assam.gov.in/sites/default/files/public_utility/Tender_16-09-2026.pdf"
ministry: "Barpeta"
title: "Notice Inviting Tender for supply of IT equipment for office work of T& D Branch  New"
date: ""
pages: 1
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "7140c42ecef51e92"
---

<!-- page 1 -->

GOVT. OF ASSAM ১
OFFICE OF THE DISTRICT COMMISSIONER!) ARPETA
Address: ৰ Contact Details:
»~Ward No- 5, PO & PS. )
“BIN. 78120; Barpeta Ph No- 03665-25229
- 781301 ী an
2 ০-৯22 Email- dc-barpeta@nic.in
লা eh a eee |
NOTICE INV:/TING TEND}
33, Sealed Quotation affixing non-refundable 09006 Stamp of Rs. 815 (Rupees eight & twenty-five paisa) only are নু
মা: Supply of following items i conn:ction with smooth furtt oning of office works of T& D Branch trom
Tegistered/reputed intending local firms/agency for procurement of IT Equipmar.
কক ; The quotation will be Teceived at the office of the District Commissioner, Bartpeta up to 3:00 PM of 24 son ৫
and will be opened at 4:00 PM on the same day. a
Sl.No. | Item Description "| Specification/ Configuatioa Nos of item 07167165787
‘ | INR |
৷ |
73 78 টি ২৯৬ ৮০৯: -৪০০১ Hi ete ey eB |
1 Desktop all in one with UPS | All-in-one, AMD 855০৪: 750U(16 GB 8 (eight) Nos =
LPDDRS5,512GB SSD) CPU Model- Ryzen 5CPU |
Speed -4.3 GHz, 14! Generation,23.8 Inch: |
। Monitor.Operating system - Window 11 Home | |
4 ৯৯২ সা মজা ৰ চা ১5৯৬ ১১
হ্‌ | Loser Printer HP ৰ 8 (eight) Nos | |
L | | fn | |
a ee ৰি |
TERMS & CONDITIC INS:-
1. The rate once approved will be valid up to 1 (one) year from the date. + approval and will not change under any circumstances ন
2. The rates quoted should be inclusive of all admissible taxes ie SGST.¢ SGT, IT ete.
5. The quotation should invariably enclose copy of Firm/ Individual tugis ration certificate, GST registration certificate, 357
Clearance certificate with up to date validity, copies of PAN C 1-d, Income Tax return for last three years, Bank Account
documents where Account numbers, IFSC, Bank details etc. ar » avzilable with the quotation. Quotation without said
টী documents will be rejected.
4, Quotationer should submit documents of experience for supply of similar items is preferable.
5. If any rate against any items quoted by quotationer is found to; vel »w the normal market price. ihe undersigned also reserves
the right to the cancel his quoted rate against that item with :y. any rotice served upon hir : ough his rate seems te he
lowest.
6. The undersigned also reserved the right to cancel any rate quc ed ageiuist any items if the rate quoted against that in 1s found
to be in much higher side the normal available market rate.
7. The quotationer shall have to deposit security money of Rs. 20,000.00 (twenty thousand) 0 ¢ vide Bank Pv. Cail deposit in
favour of the District Commissioner, Barpeta.
8. The Supply of materials will have to complete in such a manner and ‘ime as stipuiatec in ti: work order «:thout fail. Under no
circumstance, the extension of time for completion of supply work will be aia-wed,
9. The work order for supply of stationary materials will be placed as per requireme”t and payment will be made subject to
availability of fund in the respect head of account after observing all nc cossary formalities there of no claim as regards to
Payment, advance payment etc. will be ntertained.
10. Ifany substandard quality of materials found in any lot, the entire supply will be returned, and work order will automatical ly
stand cancelled.
. 11, Rates should be quoted both in digit and words by the quotatiener.
12. If a party is not able to supply items at accept rate, the security money may be forfeited. ৰু
: 13. The undersigned reserves the right to accept or reject any or all quotation without assigning any reason thereof.
14. If the quotationer have quoted the lowest rate of materials and refuses to suprly the items could\be blacklisted for 5 years
এ
+ ৰু Distrfe-Commissioner,
টে
arpe ৫৮
Memo No. BDD-43/2026/Contingenoy/ #7 A Date: 2/9/2026
Copy forwarded for wide publicity to:-
1.The Addi. Secretary to the Govt. of Assam Transformation & Development Department , Dispur , Guwahati - for favour of
kind information and necessary action
ডি. The DIO, NIC, Barpeta for information and necessary action. Ge ০০৫৫০ )
3. The DIPRO, Barpeta; He is requested to publish the Quotation in any one of the“daily Assamese pewspapers.
4. Notice Board of D.C’s office, Barpeta. oe nw
[গসিপ মে সু
Barpeta,
aN
. ৮ pe
+
