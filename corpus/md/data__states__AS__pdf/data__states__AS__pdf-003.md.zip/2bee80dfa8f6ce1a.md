---
doc_id: "2bee80dfa8f6ce1a"
source_url: "https://jecassam.ac.in/wp-content/uploads/2026/08/Internet-connection-Hostel-13-tender-document.pdf"
ministry: "Jorhat Engineering College, Assam"
title: "download tender document"
date: ""
pages: 5
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "e2cb02172c14c94e"
---

<!-- page 1 -->

JORHAT ENGINEERING COLLEGE, JORHAT, ASSAM
NOTICE INVITING TENDER

Date : 27-07-2026

Tender for Establishment of Network Connectivity in Newly Constructed Boys’ Hostel No. 11
Jorhat Engineering College invites sealed quotations/tenders from eligible and experienced firms/agencies
for supply, installation, testing and commissioning of network infrastructure for providing
LAN/Internet connectivity in the rooms and other required areas of the newly constructed 3-storeyed, 200room Boys’ Hostel No. 11 of the College.
The work shall include supply of networking materials, OFC laying, LAN cable laying, rack installation,
termination/punching, configuration, testing and commissioning of approximately 220 LAN connections.
Last Date of Submission: 10-08-2026
Date & Time of Opening: 11-08-2026 , 11 AM
Tender Reference No.: JEC/Hostel/Network/1

1. Scope of Work
The successful bidder shall be responsible for:
1. Supply of all networking materials as specified in the Schedule of Requirements.
2. Laying and termination of 12-core optical fibre cable.
3. Installation of network racks, switches and patch panels.
4. Laying of CAT-6 networking cable to the required rooms/locations.
5. Installation of IO boxes, CAT-6 modules and RJ-45 connectors.
6. OFC jointing and installation of OFC patch cords and SFP modules.
7. Installation and dressing of all cables through suitable casing/capping and accessories.
8. Rack installation, cable management and proper labelling.
9. Punching/termination of LAN and OFC cables.
10. Configuration of network switches and testing of all LAN points.
11. Testing and commissioning of approximately 220 LAN connections.
12. Rectification of any defects noticed during testing and commissioning.
The quantities may be increased or decreased as per actual site requirements and the decision of the
College shall be final.

2. Schedule of Requirements
Sl. No.
1
2
3
4
5
6
7

Description
12 Core Fiber Optic Cable
SFP Cisco
OFC Patch Cord LC-LC
CAT-6 Networking Cable, 305 m/coil, as per requirement
9U Rack
24-Port Cisco Gigabit Switch with 2 SFP Ports
24-Port Switch, 10/100/1000

Qty.
900
7
6
18
11
3
8

Unit
Meter
Nos.
Pkt.
Drum
Nos.
Nos.
Nos.

<!-- page 2 -->

Sl. No.
8
9
10
11
12
13
14
15
16
17
18

Description
RJ-45 Connector, D-Link
OFC Joining
1-Meter LAN Cable
2-Meter LAN Cable
24-Port Patch Panel
L/Elbow/T/Tie and accessories
Cisco CAT-6 Module
IO Box
1½-inch Casing/Capping with all accessories
1-inch Casing/Capping with all accessories
Installation Charges – LAN connection, rack installation, cable laying,
punching, OFC laying and configuration

Qty.
30
20
220
220
11
700
8
220
300
390
220

Unit
Nos.
Nos.
Nos.
Sets
Pcs.
Pcs.
Pcs.
Nos.
Nos.
Pcs.
LAN
Connections

The above quantities are based on the material requirement supplied by the College and may be verified by
the bidder through a site visit before submission of the quotation.

3. Eligibility Criteria
The bidder must satisfy the following minimum eligibility requirements:
1. Previous Work Order: The firm/agency must have successfully executed or received previous
work orders for LAN/networking/OFC installation or similar networking works. A copy of at least
one relevant previous work order shall be submitted.
2. Trade Licence: Valid Trade Licence of the firm/agency shall be submitted.
3. GST Registration: Valid GST Registration Certificate shall be submitted.
4. The bidder shall have adequate technical manpower and experience to execute the work.
5. The bidder shall be capable of completing the work within the stipulated period.
6. All submitted documents must be valid as on the last date of submission of tender.

4. Documents to be Submitted
The tenderer shall submit self-attested copies of:







Valid Trade Licence.
GST Registration Certificate.
Previous relevant Work Order(s).
Firm/Agency details and contact information.
PAN Card.
Price bid/financial quotation duly signed and stamped.

5. Site Visit

<!-- page 3 -->

Interested bidders are advised to inspect the newly constructed Boys’ Hostel No. 11 before submitting their
quotation to assess the actual site conditions, cable routes, rack locations and installation requirements.
No claim for additional payment arising from failure to inspect the site shall ordinarily be entertained.

6. Installation and Commissioning
The successful bidder shall complete the entire work, including:










OFC laying and jointing;
LAN cable laying;
Rack and switch installation;
Patch-panel termination;
IO box and module installation;
Cable dressing through casing/capping;
Switch configuration;
Testing of each LAN point; and
Final commissioning.

All materials shall be new, unused and of acceptable quality and shall conform to the specifications
approved by the College.

7. Completion Period
The entire work shall be completed within 30 (thirty) days from the date of issue of the Work Order,
unless otherwise specified by the College.

8. Inspection and Acceptance
The supplied materials and completed installation shall be inspected and tested by the College or an
authorized committee. Payment shall be released only after satisfactory completion, testing and acceptance
of the work.

9. Warranty
The bidder shall provide a minimum 12-month warranty against manufacturing defects and installationrelated defects from the date of successful commissioning, wherever applicable.
Any defective material or installation-related fault during the warranty period shall be rectified/replaced by
the contractor without additional cost to the College.

10. Price Bid
The quoted rates shall be inclusive of:






Material cost;
Transportation;
Loading and unloading;
Labour;
Installation;

<!-- page 4 -->








Cable laying;
Termination/punching;
OFC jointing;
Configuration;
Testing and commissioning; and
All applicable taxes, duties and other incidental charges.

The bidder shall clearly indicate GST and other applicable taxes separately, wherever applicable.

11. Tender Evaluation
The technical eligibility of the bidders shall be examined first. Only technically eligible bidders shall be
considered for financial evaluation.
The College reserves the right to accept or reject any or all tenders, wholly or partly, without assigning any
reason.

12. General Conditions
1. The bidder shall quote rates for all required items/work components.
2. The bidder shall not subcontract the work without prior written permission of the College.
3. The contractor shall be responsible for safety of its workers and protection of College property
during installation.
4. Any damage caused to the building, electrical installation or other College property during
execution shall be repaired at the contractor's own cost.
5. The contractor shall maintain proper cable dressing, labelling and neatness of installation.
6. All measurements shall be verified jointly with the College's authorized representative before final
payment.
7. The College reserves the right to vary the quantities according to actual site requirements.
8. No extra payment shall be admissible for works/items necessary for proper completion of the
specified installation but omitted due to the bidder's failure to inspect the site.

13. Submission of Tender
The tender shall be submitted in a sealed envelope superscribed:
“TENDER FOR ESTABLISHMENT OF NETWORK CONNECTIVITY IN BOYS’ HOSTEL NO.
11, JORHAT ENGINEERING COLLEGE”
The tender shall be addressed to:
The Principal
Jorhat Engineering College
Jorhat, Assam

Dr. Rupam Baruah
Principal , Jorhat Engineering College
Jorhat - 785007

<!-- page 5 -->

PRICE BID
Sl. No.
Description
1 12 Core Fiber Optic Cable
2 SFP Cisco
3 OFC Patch Cord LC-LC
4 CAT-6 Networking Cable
5 9U Rack
6 24-Port Cisco Gigabit Switch with 2 SFP Ports
7 24-Port 10/100/1000 Switch
8 RJ-45 Connector
9 OFC Joining
10 1-Meter LAN Cable
11 2-Meter LAN Cable
12 24-Port Patch Panel
13 L/Elbow/T/Tie & Accessories
14 CAT-6 Module
15 IO Box
16 1½-inch Casing/Capping with Accessories
17 1-inch Casing/Capping with Accessories
18 Installation, Testing & Commissioning
Subtotal
GST
Grand Total

Qty.
Unit
Rate (₹) Amount (₹)
900 M
7
Nos.
6
Pkt.
18
Drum
11
Nos.
3
Nos.
8
Nos.
30
Nos.
20
Nos.
220 Nos.
220 Sets
11
Pcs.
700 Pcs.
8
Pcs.
220 Nos.
300 Nos.
390 Pcs.
220 LAN Connections

Amount in Words: Rupees __________________________________________ only.
Signature of the Authorized Signatory: ____________________
Name of Firm/Agency: ____________________
Seal: ____________________
Date: ____________________
