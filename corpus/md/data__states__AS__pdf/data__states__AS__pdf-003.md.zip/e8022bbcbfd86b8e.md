---
doc_id: "e8022bbcbfd86b8e"
source_url: "https://aec.ac.in/media/notices/pdfs/trasfer_students.pdf"
ministry: "Assam Engineering College (AEC)"
title: "Payment Notice for Other College Transfer Students"
date: ""
pages: 1
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "9588255c5a645d1a"
---

<!-- page 1 -->

ce. eee
এ দা - নীল ভাজি roe
এ 7228
টী লে 98০০-১7-85 29০)
তির 7 =
es Government of Assam ই
OFFICE OF THE PRINCIPAL: ASSAMENGINEERING COLLEGE
ইঃ রিনি, = টি fas
১ শিব JALUKBARI, GUWAHATI = 781 013. :
এ নর তা নর ধার চা রঃ
27751551855 ৷
হু এ. লা;
১৮, ডেল 7185 ৷
NOTICE FOR CANDIDATES TRANSFERR ED FROM OTHER INSTITUTES
(2"" SEMESTER B. Tech 2025-29 Batch)
rhe 2" semester students who have transferred from other Institutions under
৷] নল রি রা
ore and have taken admission in Assam Engineering 0৫ ye are to pay an
dditional amount as shown below:
এ |
