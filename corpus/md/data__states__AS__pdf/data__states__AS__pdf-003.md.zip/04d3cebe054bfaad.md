---
doc_id: "04d3cebe054bfaad"
source_url: "https://bajali.assam.gov.in/sites/default/files/public_utility/GIS%20Assistant%20Bajali%20Result%20Order.pdf"
ministry: "Bajali"
title: "Final Result -'GIS Assistant' Recruitment under Bajali District  New"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "43ee815675f868ab"
---

<!-- page 1 -->

.I

W'
ffi

.,.-.,'8:;i..,...--

GOVERNMENT OF ASSAM
OFFICE OF THE DISTRICT COMMISSIONER ::::::: BAJALI
MADAN.RAUTA NAGAR : : :: : : : PATHSALA
E-mail: dc-bajafi@assam. gov.in : : : : : : : Tel: 03666 -296999
(REVENUE BRANCH)
Dated Bajali,
No.- BJRS-as /2a24 /LK4 5

W

ORDER
In connection with walk-in interview for filling up the vacant position
of GIS A.ssistants in both the Revenue Circle of Bajali District, as advertised vide
No. BJRS-OS /2024 1261-262 12501 dated 29 I A6 I 2026, th"e following candidates
have been selected for the role of GiS Assistalt in Bajali District:
lYame of Selected Candidate:

1. Shri Gautam Borah
2. Shri Bhujyoti Das
The selected candidates are directed to report to the Addl. District
Commissioner (Revenue), Bajali on L7 /O712026 positively without fail. in case of
failure of the candidate to report, the resulting vacancy shall be filled up frorn the
waitlisted candidates.
Name of l[Iaitlisted Candidate:

1. Smt Priyakshi Bora
2. Smt Jogpun Pegu
3. Shri Arjun Biswakarma
4. Smt Nabamallika Sarma
District

&.

Bajali

Dated Bajali, the . July ,2026
Memo No: BJRS-A5/20241 L84 E.-e
Copy to1. The Additional Chief Secretary to the Govt. of Assam, Revenue & Disaster

Management Department, Dispur, Guwahati-O5 for favour of kind
information.
2.The Director of Land Records & Surveys etc. Assam, Rupnagar, Guwahati32 for favour of kind information and necessary action.
3. The Circle Officer, Sarupeta/Bqjali Revenue Circle for information.
4, The DIO, NIC, Barpeta for uploading the result in the district website.
5. Person concerned for information and necessary action.
6. Office Notice Board.
7. Office fiie.
District

Bajali
& "oW*",o.,.,
