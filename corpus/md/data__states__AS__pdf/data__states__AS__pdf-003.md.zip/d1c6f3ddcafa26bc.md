---
doc_id: "d1c6f3ddcafa26bc"
source_url: "https://aidcltd.assam.gov.in/sites/default/files/swf1/dms84_gazette_notification_iip_amendment_2023.pdf"
ministry: "Assam Industrial Development Corporation Ltd."
title: "“Industrial and Investment Policy of Assam (Amendment) 2023”"
date: ""
pages: 3
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "aa43b4ce893d473e"
---

<!-- page 1 -->

পঞ্জীভুক্ত নঘ্বৰ- ৭৬৮ /৯৭ Te Registered No.-768/97
অসম 4 ৷ ৰাজপত্ৰ
Gey
Te
EXTRAORDINARY
৫,
- প্রাপ্ত কৰ্তৃত্বৰ দ্বাৰা প্ৰকাশিত
PUBLISHED BY THE AUTHORITY
eee eeeeeekeOeoe®eo
নং 119 দিশপুৰ, বৃহস্পতিবাৰ, 23 ফেব্ৰুৱাৰী, 2023, 4 ফাগুন, 1944 (শক)

No. 119 Dispur, Thursday, 23rd February, 2023, 4th Phalguna, 1944 (S. E.)
SSeS ৭ -==
GOVERNMENT OF ASSAM
ORDERS BY THE GOVERNOR
INDUSTRIES, COMMERCE AND PUBLIC ENTERPRISES DEPARTMENT
NOTIFICATION
The 17th February, 2023
eFile No.261091/37.- The Governor of Assam is pleased to enunciate the “Industrial
and Investment Policy of Assam (Amendment) 2023”. The Policy will come into force

with immediate effect.

<!-- page 2 -->

2118 THE ASSAM GAZETTE, EXTRAORDINARY, FEBRUARY 23, 2023
8882 জা... উল
Industrial and Investment Policy of Assam (Amendment), 2023
In order to make Assam a globally competitive investment destination, thus igniting the
State’s sustainable, inclusive and balanced economic growth, it has been found
expedient to amend the Industrial and Investment Policy of Assam 2019 to include
attractive and bespoke incentive pack for Mega Investments.
The following amendments have been incorporated in the original policy:
Fiscal Incentives: !
In Clause 14 of Industrial and Investment Policy of Assam 2019, sub-clause 14.9 shall be :
replaced by the follawing:
74/0) Customised Incentivesifor Mega Projects" |
14.9.1, Customized Incentives for Mega Projects
Mega Project Units (Minimum Investment of Rs 100 Crore and 200 numbers of
permanent employment) may seck for customized incentives for implementation of
their project(s) along the following contours:
Capital Investment/ Production Linked Subsidy
Subsidy on Power Tariff
Subsidy on Land
Subsidy on Drawi of Power Lines
Stamp Duty Reimbursement
Employment/Payroll Subsidy
Any other incentive including government assistance for Road Connectivity,
Power line installation and providing utility support.
The customized Incentives for Mega Projects will also be subject to the following
conditions:
1. The minimum initial investment must be Rs.100 Crore;
2. The minimum requirement of 200 employments which may be relaxed by the
৷ Empowered Committee in case of special nature of the Industry Service;
3. 90% of the grade III/IV and non-skilled employment shall be for the candidates
of the state.
The Empowered Committee under the chairmanship of Minister, IC & PE Department
as chairman, Senior Most Secretary, Department of Industries and Commerce and
Public Enterprises as Member Secretary with Commissioner & Secretary or his
representative of Finance Department, Senior Most Secretary or his representative of
Mines & Minerals Department, Senior Most Secretary or his representative of Revenue
& Disaster Management Department, Senior Most Secretary or his representative of

<!-- page 3 -->

THE ASSAM GAZETTE, EXTRAORDINARY, FEBRUARY 23, 2023 119
Power Department, Senior Most Secretary or his representative of Tourism Department,
Commissioner Taxes and any other official co-opted by the chairman of the empowered
committee shall evaluate and recommend the customized package of incentives for any
such project to the Cabinet for approval, post obtaining ascent from Hon'ble Minister,
IC&PE and views from all concerned Departments.
LAKSHMANAN S.,
* Secretary to the Government of Assam,
Industries, Commerce and Public Enterprises Department.
OO
Guwahati: Printed and Published by the Director, Directorate of Printing & Stationery, Assam, Guwahati-21.
Extraordinary Gazette No. 237 - 100 + 10 - 23 - 02 - 2023. (visit at— dpns.assam. gov.in)
