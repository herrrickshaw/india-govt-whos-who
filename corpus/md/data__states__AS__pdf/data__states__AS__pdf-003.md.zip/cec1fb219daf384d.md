---
doc_id: "cec1fb219daf384d"
source_url: "https://baksa.assam.gov.in/sites/default/files/2026-06/Tender%20for%20Stationery%20%282%29.pdf"
ministry: "Baksa"
title: "Tender for supply of Stationery items to DC Office"
date: ""
pages: 7
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "857cfb88724f8de0"
---

<!-- page 1 -->

NAZ-28/5/2025-NAZ-BAK

I/487578/2026

SHORT NOTICE INVITING TENDER
Sealed Tender aﬃxing Court Fee Stamp of Rs.8.25 (Rupees
eight and twenty ﬁve paisa ) only are invited from intending
Firms/Suppliers/Individuals registered with Registrar of Societies, Assam,
or Individuals registered with any Govt. department, for supply of
stationery materials for use in the O/o. District Commissioner, Baksa as
per Terms & conditions given below:
(A) TERMS AND CONDITIONS

1. Tenderer should have adequate experience of supply of stationery
materials in huge volume and within limited time period.
2. Tenderer will be required to adhere strictly to time frame and no
delay will be accepted
3. In case of violation of any condition of the contract by the Tenderer
at any stage, the District Commissioner, Baksa reserves the right of
rejecting the materials supplied by him without making any
payment for such materials.
4. The tenderer must furnish the following up to date valid documents
along with their tender:

A. Registration certificate of the Firm. In case of individual, registration
B.
C.
D.
E.
F.

certificate with any Govt. department with up to date validity
GST Registration Certificate with latest GST return filing statement.
Xerox copy of self-signed PAN card.
Latest Income Tax Return statements.
Xerox copy of Bank pass book.
Record/documents in support of experience. if any.

5. In view of urgency of supply of materials at the fixed stipulated
date, local Tenderer of Baksa district having experience on the
works of supply shall be given preference.
6. The District Commissioner, Baksa reserves the right to accept/reject
any or all the tenders without assigning any reason thereof at any
time and stage and does not bind itself to accept the lowest rate
and no assurance is given to the lowest bidder to award the supply
work at his quoted rate.

<!-- page 2 -->

NAZ-28/5/2025-NAZ-BAK

I/487578/2026

7. The tenders should be addressed to the District Commissioner,
Baksa and must be submitted at the drop Box provided for the
purpose at the District Commissioner, Baksa, Mushalpur in sealed
cover latest by 02.00 PM on 25/06/2026. Tenders so received
shall be opened on the same day at 03.00 PM in the office of the
District Commissioner, Baksa. No separate notice will be served
upon tenderer to remain present at the time of opening of sealed
tenders.
8. Payment will be made subject to availability of fund in respective
head of accounts.
9. The rate should be quoted inclusive of all sources of tax by the
tenderer and on their Letter heads in the Format attached
herewith as Annexure A.

10. The undersigned is not responsible for payment of fund
beyond his control & authority.
e-Signed
Deputy Commissioner
Baksa, Mushalpur
Memo No.144808/ 5-A
Copy to:-

1. The Joint Secretary to the Govt. of Assam, General Administration
Deptt., Dispur for information.
2. The District Information and Public Relation Officer, Baksa with a
request for wide publicity.
3. DIO,NIC, Baksa for uploading at district website immediately.
4. Notice Board of DC’s Office, Baksa, Mushalpur.

District Commissioner
Baksa,
Mushalpur

<!-- page 3 -->

Stationery Items

Sl. No

Name of Items

1

A4 size Clip File Corporate

2

Add Gel Pen (Achiever)

3

Alpin Best Quality

4

Art paper Best Quality

5

Attendance Register 50 page Best Quality

6

Auto Clip File Best Quality

7

Ball Pen Blue/Red/Black Best Quality

8

Ball Pen General

9

Bamboo Broom, Best Quality

10

Bamboo Broom with long handle Best Quality

11

Bamboo Tukri

12

Bath Soap

13

Binding Register Rolling Best Quality

14

Blade

15

Bleacing Powder

16

Coconut Broom Best quality

17

Calculator above 10 digit Best Quality

18

Candle Medium Size

19

Cannon 2900 Tonner

20

Carbon paper Double Size (Blue)

21

Carbon Paper Small

22

Cartidge 925

23

Cartridge HP Laserjet 15 A

24

Cartridge HP Laserjet 05 A

25

Cartridge HP Laserjet 388 Universal

26

Cartridge HP Laserjet 55A

27

Cartridge HP Laserjet 88 A

28

Cartridge HP Laserjet 12 A

29

Cartridge HP Laserjet P1108

30

Cartridge HP Laserjet PLH 388 Prodot

31

Cartridge Cannon Laserjet 6030

32

Cartridge Dell 1033

33

Cat 6 Cable

34

Cello Tape (2 inches size)

35

Cello Tape coloured (1/2 inches)

36

Chalk Pencil

37

Citronella

38

Clip Board

39

Cloth for removing Ink (2Dt. X 1.5 Ft.)

Rate

<!-- page 4 -->

40

Colin

41

Compact Disc (C.D) Best Quality

42

Computer key board Branded

43

Computer mouse Branded

44

Computer paper A4 size Image

45

Computer paper Legal size Image

46

Correction (Whitener) Pen Luxour

47

Cotton Tape/Ribbon

48

Cotton Thread ball

49

Cover File

50

Cup Branded

51

Cup Plate Bonechina

52

Cup Plate VIP set

53

Cutter/Plier

54

Dak pad Best Quality

55

Dettol hand wash

56

Dettol Liquid 100ml

57

DFC paper

58

Distingushing Mark

59

D-Link switch 12/16 port

60

D-Link Switch 8 Port

61

Door mat Best Quality

62

Drawing Pen Best Quality

63

Drinking Glass (Treo)

64

DVD Best Quality

65

Charge light (having at least 4 to 6 hrs. back-up)

66

Envelope Legal Size (Polly coated)

67

Envelope A4 Size (Polly Coated)

68

Envelope Legal Size (Brown)

69

Envelope A4 Size (Brown)

70

Envelope Medium size (Yellow)

71

Envelope Size 10" x 5"

72

Envelope Size 14" x 12"

73

Envelope Size 9" x 4"

74

Eraser

75

Extention Board

76

External hardisk 1 Tb

77

External hardisk 500 Gb

78

FC Paper

79

Feviquick

80

File Board & Cover Best Quality

81

Flask 2 Lt Milton

82

Flex banner

83

Foot mat

<!-- page 5 -->

84

FS size Clip File Best quality

85

Glue Stick Best Quality

86

Good Night machine with Refill

87

Gum Liquid 100 ML Best Quality

88

Gum liquid 200 ML Best Quality

89

Gum Liquid 750 ML Best Quality

90

Gum Tube Best Quality

91

Gunny Bag

92

Harpic Liquid 500 ML

93

High Lighter

94

Hit Spray

95

Hi-Techpoint Pilot Pen V5

96

Jems Pin

97

Jug (Plastic) Milton

98

Knife

99

Lock & Key 120 mm Nayyers

100

Lock & Ky 90 mm nayyers

101

Magnifying Glass

102

Marker pen (Bold) Luxor

103

Marker Pen (Thin) Luxor

104

Markin Cloth

105

Match Box

106

Metal Roll

107

Maxo

108

Modem For Net

109

Monogram Seal

110

Mug (Plastic) Best Quality

111

Nepthalene Ball

112

Note Book

113

O'donil

114

Rubber Stamp Seal

115

Packing paper

116

Peper weight

117

Pen Ink 100 ML Best Quality

118

Pen Drive 16 Gb Best Quality

119

Pen Drive 4 Gb Best Quality

120

Pen Drive 8 Gb Best Quality

121

Pencil Wooden Best Quality

122

Peon book Rolling with binding best Quality

123

Phenyl (Red) Best Quality

124

Phenyl (White) Best Quality

125

PP bag

126

Polythene Carry Bag

127

Plastic Folder A4 size

<!-- page 6 -->

128
129

Plastic Folder FS size

130

Plastic Rope (Ball) Best Quality

131

Plastic Seal Best Quality

132

Plastic Wraping Sheet

133

Poker Best Quality

134

Punching Machine ( Single Hole) Best Quality

135

Punching Machine (Double Hole) Best Quality

136

RJ. Connector

137

Room Freshner

138

Rubber band Nylon 1 Inch

139

Rubber band Nylon 2 Inch

140

Rubber Seal above five inch.

141

Rubber Seal Four line

142

Rubber Seal Round

143

Rubber Seal Three line

144

Rubber Seal Two line

145

Scissors (Corporate)

146

Sealig Wax

147

Sharpener Best Quality

148

Sketch pen Luxor

149

Spoon (Steel) Best Quality (Ten)

150

Spoon VIP (Dozen)

151

Stamp Pad Big Faber Castell

152

Stamp pad Ink

153

Stamp Pad Small faber Castell

154

Stand Candle

155

Stapler Machine Big No. 24/6

156

Stapler Machine Small No.10

157

Stapler Pin No. 10

158

Stapler Pin No.24/6

159

Sticky Note Best Quality

160

Sutli Loose

161

PlasticTable Cloth

162

Tag Best Quality

163

Tea Tray

164

Toilet Brush

165

Toner for Xerox

166

Torch Light (3 cell)

167

Towel (Big) Bombay Dyeing

168

Towel (Small) Bombay Dying

169

Trunk (Tata) 36"x18"x12"

170

Trunk (Tata) 36"x18"X12" Over Size

171

Trunk (Tata) 40"x22"x36"

Plastic Gumla

<!-- page 7 -->

172
173

Tuber bulb Best Quality
Tuber Set Best Quality

174

Umbrella

175

Voting Compartment

176

Waste Paper Basket

177

Water Sponge

178

White Bed Sheet Double

179

Wire (Guna) Best Quality

180

Writing pad Best Quality Bilt Matrix
