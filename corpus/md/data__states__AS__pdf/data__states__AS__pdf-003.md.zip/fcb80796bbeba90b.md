---
doc_id: "fcb80796bbeba90b"
source_url: "https://aifa.assam.gov.in/sites/default/files/swf1/dms60_revised_guidelines_for_issue_of_aa_release_of_fund_.pdf"
ministry: "Assam Infrastructure Financing Authority, Government of Assam"
title: "Revised Guidelines for Issue of AA & Release of Fund"
date: ""
pages: 0
method: "pdftotext"
script: "LATIN"
needs_ocr: true
sha1: "d383050a5be5ad37"
---

<!-- no text layer: pending OCR -->
