---
doc_id: "a3b8ffe24b6f30ef"
source_url: "https://aasc.assam.gov.in/sites/default/files/swf1/dms6_The%20Industrial%20%20Tribunal%20%28Procedure%29%20Rules%2C%201949.pdf"
ministry: "Assam Administrative Staff College (AASC)"
title: "Industrial and Commerce Department"
date: ""
pages: 2
method: "tesseract:asm+ben+eng"
script: "LATIN"
needs_ocr: false
sha1: "56f34315806c7546"
---

<!-- page 1 -->

THE INDUSTRIAL TRIBUNAL (PROCEDURE)
RULES, 1949!

1. These rules may be called the Industrial Tribunal (Procedure)
Rules, 1949.

2. The Industrial Tribunal constituted under the Ministry of
Labour, Notification No. LR-2 (205), dated the 13 June,
1949, may entrust such cases or matters referred to it as it
deems fit to one or more members for enquiry and report.

3. The report under rule 2 shall be submitted to the Chairman
of the Tribunal. The Tribunal may withdraw any case or
matter referred to one or more members under rule 2 and
transfer the same to any other member or members.

1. See Ministry of Labour, Notification No. LR-2(245), dated 3:4 September,
1949, published in the Gazette of India, Extraordinary, dated 34
December, 1949.

<!-- page 2 -->

4. The Tribunal shall, after considering the report and making
such further enquiry as it deems fit, deliver its award.

5. For the purpose of making any enquiry under these rules, by
member or members, as the case may be, shall have all the
powers of the Tribunal under Section 1lland the provisions
of rules 14 to 21, 24, 30 and shall apply to such enquiry as if
the member or members were the Tribunal.
