---
doc_id: "b9e18a1a96dffede"
source_url: "https://www.gpmuz.ac.in/wp-content/uploads/sites/33/2026/07/Notification-A.Y.-2026-27.pdf"
ministry: "Government Polytechnic, Muzaffarpur, Bihar"
title: "AICTE scholarship scheme"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "b127c3cb27cd4058"
---

<!-- page 1 -->

darcq. qre
iffiq,iidr qrf, Etta gu, t{ ftd-rrooro

fi. wFrr rer

$qN : 0il-2958t399

crdr+a w{rd

d-to' ms@aicte-india.org

TrriRI qfuq
Prof. Shyama Rath

ALL INDIA COUNCIL FOR TECHNICAL EDUCATION
(A STATUTORY BODY OF THE GOW' OF INDIA)

Ministry of Education, Govt. of India
Nelson Mandela Marg, Vasant Kunj, New Delhi-110070

Member Secretary

Phone : 011-29581399
E-mail : ms@aicte-india.org

F. No. AICTE/StDC-SAG/Sch./Adv./Pragati,

Saksham & Swanath/2026-27 Date: 19.06.2026

NOTIFICATTON
It is hereby informed that the online portal for submission of applications under AICTE Pragati
Scholarship Scheme for girl students (Fresh & Renewal cases), AICTE Saksham Scholarship Scheme
for specially-abled students (Fresh & Renewal cases) & AICTE Swanath Scholarship Scheme (Fresh
& Renewal cases) has been opened & last date for submission of online applications is 31 .10.2026.The
details of online portal for various schemes are as follows:

Portal address

AICTE Pragati Scholarship Scheme (Fresh

applications -2026-2027 Batch & Renewal
application s -2023 -2024(Degree only), 202425 8.2025-26 Degree & Diploma Batches.)

National Scholarship Portal
https //scho larships. gov. in

AICTE Saksham Scholarship Scheme (Fresh
applications -2026-2027 Barch & Renewal
application s -2023 -2024(D egr ee only), 2024 25 &.2025-26Degree & Diploma Batches.)

National Scholarship Portal

:

https : //scholarships. gov. inl

AICTE Swanath Scholarship Scheme (Fresh
applications -2026-2027 Batch & Renewal

National Scholarship Portal https ://scholarships. gov. in

application s -2023 -2024(De gree only), 2024 ree & Diploma Batches.
25 &2025-26

The last date for first level of verification of bpplications (fresh and renewal cases) by
Institutions/(lNo) including re-submitted defective applications and second level of verification (Fresh
& Renewal cases) by State Nodal Officers for Pragati, Saksham and Swanath Scholarship Schemes
through National Scholarship Porlal (NSP) are as under: Last date for application submission
Last date for INO Level Verihcation
Last date fo. SNO feu"t Verifrcation

3t't October.2026
1

5"' Novcmber.2026
November 2026

The eligible institutions are also advised to verify applications of their students immediately
after receiving the applications on respective online portal.

Cont...

<!-- page 2 -->

The guidelines of each scheme are available at AICTE website (https://www.aicteindia.org/schemes/students-development-schemes). The students may submit

their Fresh & Renewal
applications at the respective portal. The students are advised to submit their online
applications well
in time so that their institutions are able to verify applications within the prescribed
timelines.
S.

Scheme

Link to the Scheme Guidelines:

N
o.

I

z

AICTE Pragati Scholarship Scheme

https://www.aicte-

(Degree)

rnd-re,plg/s-ites/_d_e-faulilfile_slstde/_prae?tjlAIC^Tpo/e?Ap

AICTE Pragati Scholarship Scheme
(Diploma)

hQrlAryuluatqle:
ragAtiT,o-20Sshe.me_%-q2-0Gui-d"gf lpeg*eip_Jo..ma,pdf

AICTE Saksham Scholarship
a

J.

A
'1.

https://www.aicte-

Scheme

(Degree)

%_q-_20$-c-h_e""-r_ne-7q2-0GUi_d9Jing-s*Dp_g1-e--9,p--df

AICTE Saksham Scholarship

https://www.aictg:

Scheme

(Diploma)

ipdi,a,og/s_i"1es/defau-f t/fi le_slst-d"slA-I.C_T_E%q2_0Saksh4m
%"-o"20$_-ch9"me-%q2QGuldqlin"es"*Dip!.q.ma,pd-f

AICTE Swanath Scholarship
5

Scheme
(Degree and Diploma)

S

TH,p-df

TP- t

,f l"l a-u-.4
(Shyama Rath)
