---
doc_id: "e01df49cb6d4abbe"
source_url: "https://cdn.s3waas.gov.in/s31bb91f73e9d31ea2830a5e73ce3ed328/uploads/2021/05/2021052798.pdf"
ministry: "Kishanganj"
title: "Mask Janch avam lockdown enforcement order dated 24052021"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "29110a4987799737"
---

<!-- page 1 -->

sttFt 06455-222535 (gFn+r)

fl-grs sEorr

06456-222520 (3{rqro
06456-222626 (3rEr{t
06456-222530 (6rqi.)
06456-22s480 c6rqf .

sqrF{uT|Erq,tffiq
Fffiq - 855102
(B-or lvfq ynaO

&f)

tk)

.

d
#{ ffi t #

taiFl-s-rg d€{ur d $c-trrErd EE 6f
g(r {s Erqldrq d f,rcifi e22^fr0,
zo.o+.zozr d am ffrdrt,td 6]Fis sscur st fi-qEd qr?i uc ir<rt area gFvr orerer
m"ri d fr(' gonil vcertr+ cFrcrii 6i
6T E-{ (,.i sryq
E(' s+
f+qfR-d Fhqr rrqr tr g{, g{r 6rsld-q d 3TrAFr drci{ 11211fr., ftffis 24.os.202t d arcr
3{risr C aTrtrrfi
ord gv g<: drs-srfi olt 3rqE
01.06.2021d6
Fb-qr rrqr
"fsttr{
,t7
t t 5s fu orolc* 3Tre$ Frqifi 1oeorfr. ,
.05.2021 d am
Rrdi qr crs d
srqtrr o1 frq ori fu aosnrornei w gft-e qcrErtFrF"f / Tdt dt ctrfSfu Frqsiur
C
qfs qi-q d fl'{-Enr gsrdtr+i-flrE-o qFrerif 6i Bq{ffi oTricr d 3Tret6 3rJcriq-{ 6-{d nq
o'1 rrfr tr 5-{: iirE-frrffi w Str€ qqrE6rffi / Tdt 6T cfiFlgffi ftffi6 01.06.2021 d6
Frqfiqur 6'l qrd :cfAF-9fr <rsrErfiRl6r {rq
cfrtrgcF gR-fi q(rErsffi 6r
tFo
cfrfrgft{ sd
gtr{ Td
qfirc rrc qtErfd +€
nlc qfirc t'E dcrfd +€

ffio

ffi6

ffi6

ffi

srffio

rff

Fffi

i

fr

t

irdn n't6 $ {Fd

2

qFqq lrcfi +6 d qqrc

ffi
3

'i-dr

+dr qt6 qrqr

go3{oFlo E-sq qrssra. cFdr

qr{r. f,ffiq qlo-62046?sss?

Fh:rflro, cto 9304792640
3fi ffiq 3rffi, eFr.F sFl.*n, qq F&roFlo ft-{rtrq 6, qrdrqld
tFF@, f;hrlrin ?9?809{20
fffiq 4lo-9a305e0216

Fri{ tqr{, sdr{s srE:qin, .Id{

'i tffiq
ffi{ fr6 d E:Is cd qqEsfl,
$nq qd +6 drf{
iri Eq :-q'* *qt 16

5

f Efic €crt, srrqo dd+a
Fqltrdrfi, qsldff olqldq,

?0043?12?3

go3roffo fi-{q t!n" 3qrqrq,
ftl5gr{ ic qrqr qlo-8?890a1211

,fi aw{ €qrq, lrffq 3rEq6r ftcr), il$roffo 6tis€ ?rq, qar.nit
liffi e852s8osao (ffdr lit6r€ fr h?Frti.n qlD-s?szz9492a
cYrr€r)

?rc'fc tqr{, s6rq6 3{EriiT, Fo3{ofio -r,nt{ irq, fur{4ii
+qr.tu st6 d rfif ,fi
qrfrlr 6rd ftt'{r4, 6r{ FqEsd-i, qr{r qlo-993128?8?i
th?Firtq 8oo223s5sz

?-qrd sd tg ,fi ftlqr{q rglE, F6Fr6 3rE?idr, ewroffD +qq rgr( ?Fftrf,
J-c'de d F{qr€r 4 Tdur !D-r4 ftt'rrr, 3I{{ cri.tcl-1, lihr{.iq qlnr 4lD-9?088593s0
tffiq

898691s1s1

flr f{ Fq€ {s €Fc, fr $dr F6rw ?rq, fris Edwsr riorofio cqra6q f*F qrqq,
Mq \r{ sF-€ ft i6r*r'i, tffi, qlo 620se186a8 ftffiq Er"r do-99ss2sos?6
Rqra{qtfig *J, qrrFr{
a

9

10

12

t3

qqld{ d nz d srci 3

tfi ?E tcR, fl$s sdqq 6lT{'i,
frbr=Fiq, d! %s26s6o42

@rgl Fra,EPElr ndr f dfiq Eqar Ri(, s{rq?F 3rFiqiir,
rle -csrdEc,rgr nclr dq <rs tr€ ccEw,
tkli iq
ne-qqrFr Yrt6c,6q +6

€o3rofro nriF€ 4Rl, fu|niq
Erlr qlo-79923?4283
€o3roFlo ?rq eq|? ?ra,
qFlI qto-9431225395

ftffiq

eE qrg, ?il{{r s6r{|6, Gdr Ro3roFlo 3rrfs qrqq, ry FiiE
Ffi f6 * {ft?rlnT ,fi
qtqil orqiqq,ffi 91232?s606 6lqitr, go6rqlo, liffiq clo
+s F6

f4 drd {d
gc60 €
Fa drd adl

@d
F4 drin {{

5dd
L4 drdl {cr
Sdo d

Fa dr& adl

@*

1-4 frr& {d

$60 rt
F4 ard {d

cdd

F4 dr6i {d
gdo *
1-4 dld {d

rdd

t.4 dr6l qo
5Cm0

Il

.idi nr6 * Fqiq dr6 rfi F+q fdsr46+4 3rft{idr (f$€-d). Eo3rofto rirq
Eqr{ srqR
fi{R EIIgr qtuq{r, fderrin tbgF lq qr{r qlD-966n3132s
d6 1rqr qii}€ 3ltfu rtg
rfitlt?t6*wcg
,fl ffiq Eqr{ tir, F€r6 qrq w so3roFto 3lYr{ tqE, qrdrqla

F4 ardi {d

w qfl C16 € dt6R

F4 dd Tar

q€ sdfi 4* d-r

COVID 19ORDER Page- 1

al.l, fiffiq 9934?9sos1
fffiq 4)o-62osa1ess1
afi 3JEd g{r{, Eirq6 nig.t6, so3roFo vr![ qssr{, fiffi

Gltf,rr), fjrr{.S.d., tl*r{+q

8809022011

x

qtjll qto-8?57978115

5dd

F4 drdt {d
qdo *

gdd

<!-- page 2 -->

fr{ Ecr", q}fir str{I6, tr.lr q3aoFto Et{r EqF, frIniq qrrl
Tgc9?t6dwc9 ,fr
qYffrr o]qiaq,iiffiq 9?988?2266 qio-95045?8926
tre€ A6 d rid ,fi {r{ tqr{, qtq{r firq6, F-dr €o3rcFto Tllr ffi(, qrdrqltl
d6 tr6 qrqr Fhd'r qlja{r 6rqi-q, furrain liffiq qlD-a2525??140
.Fd/Es{Rrqlr ter

1.4 and lat

q@b*
F4 ar6 qat

5d*

8013324523

6rd Eq

#-tr *6 d w.fr. ,fi YnE-{ ecr{, s6r{6 3rFlqiir, rwofio filsrr€ qFsrl, 5d,
w' ik dt-iq S q.rl q,rEsd, fhFPrq 930413S259 fkr{riq clD-9a?ogo??50 ql *

F4 drd qnr
5c60

cFFqfu) qlo-9??121s633

q

1-4 Flrd .rd
rfi {s gaTr qqr.Fl, rEis @ror sorofio sfuqFi( qr<ir, qrirrq|d
qlo-9534929?16
qd*
ftgf{
iq
c<rff6T{1. fFr{'fq ?00483e782
qtc :- t. cfrft{n srsrEror$/ gtra qfiErftr5/ gfts qa :rci-3rci cfrtttfr efd w str{6d H dt
eq{ *q 6{d 6o ov{m nH 6T vrd-cftcrd 3rJctil{ EFF{d F{rdi dqr ctrF{ 6I tffqt
ctrnfi olc"I{T o4.oo ifi iriF 3r*F 6s d qtrrfi q{rEr6dl, ffdr 3{rq{ rqEn, ffiq
17

(94?298513?) 61 3cder 6trdi I

sc{ff cFE-{ff qEsrEmrffi 5ft-s r{rEmr$ ar{I 3lqi cfrF-gffi eEi rr{ ToTJl?Ir d

ster 3qR{rd #w qrs-c,fiq rrs Esrdv-d|{srffi cFrsfii 6} EE otqldq d|zr firfd sMb'
922l:fr0, fd+6 zo.o4.2021 d urat+ i rlvr*+ ozror qr rdl t s{sr rfr? * T.iE-d 4'd qdiqur
I'q 3rflsul F|qifr-d rqlEmt qf+F-trd 4ti :(i) * rrFK 3rrd{' trdr {-!.d-{ qfltrsrfr' frlrflb
"**nt#fu .-, a
01 d 04 dF cfrfrg* s(r i'r )
-,"
qi'
(ii)
da 3r*q' {fi-q s Eqr.di' fffiq 8?s?*t -(oRF,- .",
+ *i." os d 10 d6 qfdf+gff s{ sr )
(iii) qlD 3FFf6 3l6'q, S qqr{ 3q sq|Fdt, €tsatid as4441234119102442717
€RFr€ '6' d qifi r * 14 d6 cfrfrgF sd 6r )
(iv) ,ff 3{E|n Eqrt qF{, 3r5{.rd d6 €r6r{rd ffsnrr qqro, ttsr{riq ?oo4o7o22o
(qFFrle F' + 6qi6 1s d fl d6 cFfrEF sd 6r )

3r1F5f, Cq

qrsrEmdt o1

cfFgfr

cfrF-F qrsTEmrtr{t o1 3rJqffi i sn-S sr{ qt

, ffiq

gtrs qqrE-6R1 61

firfrr

qfrfrfit;:
nfdlftFt ::

qFftFt::
cFAHq ::

cfrfrFt::
qfffaR::
cfrfrfit::
qfrfrFl ,:

ftffi{r

srcr6 [xr-os/2020-21] ..\.\A\..|fr.. ffiq. F{i
s'ff ctrFgff qrsTEr6rfi/Tft-n qdrEonT oi q-fi'S u{

iffd
qr{
qHiFff
qarffi/
glfi
S.ff. wqr{,
3rdd
3rEffirfli
Eff
rsns
fildlff
sff
ffiq trdr sl qr{d ci ir5vrr+f nffit

CfrFFt::

qfrfrfit::

I

q'dqr.m. q-qTFq-r$, TrR cRFq, ftlx|{'rq/ 6r{qdiF qqrffi, qIR riqrtld, €Eiriq tEi
oeab dt qrn{ tti srqs6 6drf iRdl
sntrs-d rdtrdrfr. ftffiq/fi{.rd qft-s qqEmrtt, frbsr{jiq 6} lTrJrPf w

3riT{6 firsirf nE-d I
cRqrfi r.n. gft-fl d{, ffiq

qr{{

s}
rs 3{rqs{6 6rqtg iF-d I
qcrErdrs,
G-dr 3{rqqr cdq{, Fbs|{riq o} W+r{ ltf eTlss{6 orql{ iF-dt
vrfi
€q-d qslffi/trdr 3n$
Fft{r rqrrd sq sqr6dt, E qqrr"T/ fficn
qqTEmrsF]Frqdqo, Erdr odrr d-{, ftkr{riq 6} qr{I{ tr+ sr+rao oraf$ ntrat
ffidr ctr{6{ qqrEffirs. fthslqrioTi3ltiF.F, qq f+qq, frr{ iq 6t qrfl{ lti 3rqs{6

q{

orsid iFldr

sfrfrfr ::
qfrfrF ::

...2021

3rq{ €fl6d1. tFr{riq/gc ff6|s 3Tqff, fuI{tiq dr q+tr{ tti .:rsFft6 6rq1{ iF|d|

gfcfs
3r|qffi,
3rqr E@

$fai oi trqt qr<rd
cqrsd, wqt 6) sr{r {d{Pf
, c-{r ftl skIr qsid l
, nffui ud-*,

r

\^
COVID 19 ORDER Page- 2

t

A$l:

ft-dr'ffi

tffiql
