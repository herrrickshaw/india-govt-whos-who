---
doc_id: "d15e5e8ff93b6aab"
source_url: "https://bsbccl.bihar.gov.in/New_V/UploadedImage/TenderPDF/173749.pdf"
ministry: "Bihar State Building Construction Corporation Limited (BSBCCL)"
title: "M/s Ashiyana Contract Pvt. Ltd.,Rajendra Nagar,Gopalganj,Pin-841428."
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4e088b1350f0487b"
---

<!-- page 1 -->

RE1-q {fRI qcr;T

Mor ft-{|q fuHs

An ISO 9001:2008, 14001:2004 & OHSAS 18001:2007 Cer.tified Cornpany

R-9rc gron or \ro sqlnq
*<qrg : www.bsbccl.bih.nic.in

BIHAR STATE BUILDING CONSTRUCTIGN CORPORATION LTD.
An ISO 9001:2008, 14001:2004 & OHSAS 18001:2007 Cerrified Conrpany

Build Grecn, Live Green!
CIN: U:{52008R2008SGC0

A Government of Bihar Undertaliing

13s I 3

\Vcbsitc: lvrvrv.bstrccl. bih.nic.in

qfls':-dlogtrodloqfro{froya;o-04 / 2014-gq frq+q Z

A,j

Iq-l Ich.-

o-rqfEru errter rsrqr-...i. -.4

/ zozt

Performance committee of d-df, q ftd .r$ Ftofq d 3rFffi q 'ilfu{m
gmrdo vro fu0. sars eFr, qr*qJrc,
q-cT-800013 qq en-Rr{|{r
d{. qtfuT

oYdce yro fuo. tt-s-<

.

slffi

ts,

-s41428 zhi fuqR gw fuur qrdt e

I

g{]. 3il?eT qr o*1q slf€rm'r{ or 3rj+fi qrw i'l

60/-.

5W rIdllIELIf,
rrqq
f$-ers wq
Frqfur frqq ffie,qsqr

1

srqifr- froqtrofiorftosfiogdo-o+ / 2014-Tq FrqrlT
ffioqfrfrfu - wfu{fq gmrdo sTo fuo. saTrr n-4, qr*-qls, qrffi a-{, q}R,T r}s, qs+i-aooor:
o) rpaqpl
l

60/-

g@ rIETqEeT6
M_{-\,,,,,
q{q
fr-aq rr-q
ti+ilul liJl+l 1s_^-'-._
ldo,q-flT

Srqm- froTsofroTftorfrogao-o+ / zot+-yoT fr-iir"T
- fra;os-frftfu - enPrqrcr oTdce sTo fuo, Rr-sq rrT{. dqr-clrfq-B4.'4zl o) rp++rzf

I

1

60/5iq

rt6Elqs|_ff

fraq nsq qem FrqfuT f{qq ffis qd-T

srqin- frosqodio{froqfroqao-o+ / zot+-gq ry,*t 20 82
ffin- 2 !/;f/Z;
s-frfrfr - sn€odo n-id{, fraq rt';u +1q{ ffinT frqq fr0, q-rT o) qqct.f vs 3TTTsq6

ffifui.Ror

1

/.

8{*n

5sI rtilqqeTo

G-ers.

rrw qq{ FrqflT ftqq fas,qdfl

1

bp-

n{fird 6rqf{q:;flogvodorfioqtosq,6rrct{ r}s, vnrxl;rrR, qz:rr-80002r, Xar1q. +91-612-22a4sor, d-rs, +gj-6.t2-22s0324, {-:to:bsbccl.patna@gmail.com
RegisteredOffice: BSBCCL,HospitalRoad,shastriNagar,patna-800023,TelephoneNo.:+91-6j2-2284861,Fax:

+g1-612-2280324,Emait:bsbccl.patna@gmail.com
