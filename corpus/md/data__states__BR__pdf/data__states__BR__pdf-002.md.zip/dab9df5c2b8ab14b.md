---
doc_id: "dab9df5c2b8ab14b"
source_url: "https://bsedc.bihar.gov.in/media/publications/primary/E-tender_notice_pdf.pdf"
ministry: "Bihar State Electronics Development Corporation Limited, Beltron, Patna"
title: "E-tender_notice_pdf.pdf"
date: ""
pages: 1
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "ce1ee7ea7e633cdd"
---

<!-- page 1 -->

ः es
| "Bihar State Electronics Development Corporation Ltd.
| hue (A Government of Bihar Undertaking)
aff : Beltron Bhawan, Shastri Nagar, Patna-800023,
ie Telephone No. 062-228242 Tele Fax No. 06!2-228857
| CIN No -U3I900BRI978SGC00I37 ।
| e-Tender Notice
Ref. No. BSEDC/.2!/..4/.2.02.6°24 Dated:- a
e- Tenders are invited by Bihar State Electronics Development ,
Corporation Ltd. for "Selection of System Integrator (SI) for Design and |
| Development Web Portal and Application the Child Labour Tracking
| System (CLTS) Project for Department of Labour Resources and
L | Migrant Workers Welfare", Government of Bihar. The details of the
tender and RFP document will be available on the website:
| https://eproc2.bihar.gov.in. Start date of Issuance of RFP document will
be 0.09.2026. Last date of tender submission will be 06/0/2026 till
| 03:30 PM. “a
ah
| Managing Director
