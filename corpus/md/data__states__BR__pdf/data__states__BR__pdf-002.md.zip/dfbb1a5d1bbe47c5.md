---
doc_id: "dfbb1a5d1bbe47c5"
source_url: "https://www.mitmuzaffarpur.org/wp-content/uploads/2024/06/Tender-Document.pdf"
ministry: "Muzaffarpur Institute of Technology, Bihar"
title: "3. Tender Document"
date: ""
pages: 7
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "33ecaec0c2b9f3ed"
---

<!-- page 1 -->

Ser,
=~
TENDER
FOR
Vehicle for Official Purposes
FOR
Muzaffarpur Institute of Technology, Muzaffarpur
Tender No.: 02/2024-25
Tender Start date: - Date of Advertisement
Last Date of submission: - Till 5 days from date of advertisement
000 ८
759]
Pvinvipal
Muzaffarp: rirstivis of pb
; Miizatfa दर
“v
0 ६-४१

<!-- page 2 -->

nn aaa
a ee al
Muzaffarpur Institute of Technology, Muzaffarpur |
Tender Notice For Vehicle |
fender Notice no. 02/2024-25 |
Sealed Technical and Financial bids are invited from any service provider or owner for providing vehicle |
round the clock for the MIT Muzaffarpur for annual contract period of I months, by Registered post /speed
post /Hand delivery. |
Last date of submission: Till I5 days from date of advertisement |
Opening of tender: 3 July 2024 at :00 A.M. at Conference room, MIT Muzaffarpur, Any Change in date |
will be intimated through Website. |
INSTRUCTIONS TO BIDDERS |
All interested vendors are requested to send their sealed quotation for supply of the above item under two bid systems |
in the following manner: |

a) Envelope —I: Technical Bid.

b) Envelope — II: Financial Bid. |
NOTE: The bid documents are not transferable and the firm's seal and signature of the authorize’ SUNS" SSS" The bid documents are not transfe and the firm's seal and signature of the authorized official must
appear on all papers and envelopes submitted. on all papers and envelopes submitt |
Both the envelops should be sealed, signed, marked and kept in a bigger envelop super scribed with the Tender |
Reference No. and Tender notice detail as appended hereunder.

|
TENDER for Vehicle |
a 3. 3 - ७७-ेाछआएणछछाप्रननाणभानाण —_——,
|
LENDER REF. NO.: FOR LAST DATE | |
SUBMISSION:
| | |
| a
| From: | |
| M/S |
Contact! Mobile no: To, The Principal है
| Email ID: Muzaffarpur Institute of |
Technology | |
|
| Muzaffarpur | |
| |
| | |
SS a विकास ८

<!-- page 3 -->

SS नममममम  ा ख आशा. |
Terms & Conditions for Vehicle Vehicle
पु l, Any person/owner/registered travel agent may apply. They have to submit all documents as
per format of Technical Bid and financial Bid.

2. The vehicle should be in good condition and it should not be more than three year old.

3. The tender fee of Rs. 500/- (Five Hundred Rupees only) : and E.M.D. of Rs. 0,000/- (Ten
‘Thousand Rupees) only in the shape of Demand Draft/Multi City Cheque separately on any
nationalized bank in favour of Principal, MIT Muzaffarpur payable at Muzaffarpur should
accompany tender paper. Without E.M_LD. will be ignored straightway.

4, The comparatively new vehicle and of higher model will be given priority.

5. The contract will be kept valid for a period of I! months which can be extended on mutual
consent basis on the same terms and conditions for further |] months (max three times).

6. Vehicles deployed should be good running condition and should have commercial registration,
current comprehensive insurance and road tax coverage, permit, fitness and driving license of
driver etc.

7. Owner should keep the vehicles in neat, clean and good running condition with sheet cloth
covers, which should be replaced with another set of washed covers once in a week. The
owner should carry out the periodical maintenance of the vehicles supplied and insure them
always in good condition.

8. All payment towards lubricants, repairs, insurance, any taxes etc and any other expenditure
related to vehicles is the owner’s/ travel agent’s sole responsibility, all payment to the driver
towards their salary, overtime ete is also the owner’ s/ travel agent’s responsibility.

9. Payment will be made on submission of bills.

0. The agreement can be terminated by giving one month’s notice in writing by either party. In
case of breach of terms and condition, MIT Muzaffarpur, reserves the right to terminate the
agreement without giving any notice.

ll.In case of accident etc. MIT Muzaffarpur has no responsibility whatsoever towards,
Police/RTA, Court of law, injured parties, damages to the vehicle or property or any claim
made for the loss ete. All these are entirely the owner’ s/ travel agent’s responsibility.

2. Any deviation/Violation or breach of the said terms and condition will be viewed seriously,
and the agreement will be terminated without prior notice.

3. The maximum limit for quoted amount will be 40,000/- (Including GST) per month including
fuel for [200 Km, Insurance, lubricants, taxes & duties as per norms, maintenance cost etc.

4, In case the owner refuses to supply vehicles ordered by MIT Muzaffarpur, it will be viewed
seriously, and contract will be terminated without giving any notice and their security money
will be seized.

<!-- page 4 -->

esses ae रत ।/फ"._.

]5. पल फुला30॥/०ज्ाशा[॥बएढ। 88ल्‍॥5 ९०, धार directed to submit Technical & Financial Bid in
separate envelope. The Financial Bid will be open only to technically qualified vendor.

6. The evaluation of tender will be done by the committee on the basis of weightage to Technical
and Financial part.

I7. The breakdown of weightage will be as Technical -50 % and Financial -50%, Technical (Age
of Vehicle 30%, Price of Vehicle- 20%). The detailed breakdown of marks is provided in
evaluation sheet in sections follows.

8. After evaluation of Bid, the successful bidder will be informed separately.

9. The agencies must put their initial on each page submitted. All pages must be numbered and a
note of this should be mentioned on covering letter. The Terms & Conditions duly signed
should be attached with tender paper.

20, The supply of vehicle has to start services within 07 days of intimation. The tenderer may
change vehicle of Quoted in tender by comparatively newer and higher model.

2I, The full E.M.D. shall be forfeited in case of backing out of the offer before acceptance.

22. The award of work shall be done on QCBS basis (Quality and Cost Based Selection approach)
among the technically qualified consultant after Technical Evaluation. The lowest financial
proposal (Fm) shall be given a financial score (Sf) of 50 points. The financial score of the
proposals shall be computed as follows:

Sf =30 x Fm/F
(F - Amount of financial Bid).

23. Formula for final score = F+T
Where, T= Marks awarded for Technical Proposal and F= The marks awarded for financial
proposal
The Bidder scoring highest Combined Score shall be declared as preferred Bidder for award of

Contract.

24. In case two or more bidders achieve same combined score, the bidder whose Financial
Proposal shall result in least cost to MIT Muzaffarpur shall be declared as selected bidder
eligible for award of Contract.

25. The undersigned reserves the right to rejects any or all the tenders without assigning any
reason thereof.

26. The owner is. required to submit an agreement on stamped paper as per the format to be
supplied by the Institute.

<!-- page 5 -->

“s II The evaluation parameters will as follow:
A. Technical: Total Marks: 50
l. Age of Vehicle: 30 Marks
Criteria If Age of If Age of If Age of If Age of More than
Vehicle < 0 Vehicle Vehicle Vehicle 36 Months
(One Months) | between 0 between 2 between 24
months to 2 months to 24 months to 36
Months) Months) Months)
Pe
Criteria If Price of If Price of If Price of If Price of Less than 8
Vehicle (on Vehicle (on Vehicle (on Vehicle (on Lakhs
toad) is more | road) between | road) between | road) between
than I5 Lakhs | 2 Lakhs to l5 | l0 Lakhs to l2 | 8 Lakhs to 0
Lakhs) Lakhs) Lakhs)
eres P
Re तएतण
ee

<!-- page 6 -->

“* Annexure-I
Technical bid documents

S.NO Enclosure Enclosed Yes/No

] Copy of Motor vehicle registration Certificate

2. Copy of Latest Pollution Test

3 Copy of Road Tax

4 Copy of Vehicle fitness Copy of Road Tax

5 Proof of Price of Vehicle (invoice)

6 Income Tax PAN of Agency/Individual

7 EMD Details

(Signature & Seal)

Note: In case of new vehicle which is proposed to be supplied SI. No. | to 4 is not mandatory. However it needs
to be provided before supply of vehicle, In this respect a declaration need to be given.

<!-- page 7 -->

| | 2
2
g
a धर
| | at ५
Se
26
z+@2
zfs
S33
Se a
ato
fis
5 a a wn
B25
Sa
a2 3
et+t&
Saf
2 =
3 222
2 a
sa
ee
2
= K
o:
=
x
3 5 ie ef
= = Be
3 ) 5
= if
= _
: ०
Ss
: 5
oO
a4
& z¢
2 55६
3 25
: : rE
- 5 38
3 = £E
3 = gh
= g 30
3 3 sé
3 A 2%
eS
Pe
2
‘Ss
>
2
g
<
