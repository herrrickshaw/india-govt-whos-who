---
doc_id: "3227a6dfb84dbdde"
source_url: "https://www.bsptcl.in/admin/GuidelineDoc/07-Mar-2014-12_NIT%20NO.37PR_BSPTCL_2014.pdf"
ministry: "Bihar State Power Transmission Company Limited (BSPTCL)"
title: "07-Mar-2014-12_NIT NO.37PR_BSPTCL_2014.pdf"
date: ""
pages: 1
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "4c9aca2af8e8cbbf"
---

<!-- page 1 -->

BIHAR STATE POWER TRANSMISSION COMPANY LIMITED
4th Floor Vidyut Bhawan, Bailey Road, Patna
(Through e-procurement mode only – www.eproc.bihar.gov.in)
NIT No. 37/PR/BSPTCL/2014
Online tender are invited by Bihar State Power Transmission Company Limited for Construction of
132/33 KV Grid Sub Station at Bakhri (District-Begusarai) on Turnkey Basis.
Scope of work.

Construction of 132/33 KV
Grid-Sub-Station at Bakhri
(District- Begusarai ) on
Turnkey Basis.

Estimated
cost in (Rs.)

Time of
completion

15.10Crores

12 months from the
date of Letter Of
Intent (LOI)

Cost of
Tender Paper
(Rs.)

Earnest
money
(Rs.)

Rs. 27000.00

20.10 Lacs

Tender schedule as per given below:Period of Sale / Request of Bid / e From documents from 03.03.2014 through website
www.eproc.bihar.gov.in.
Online Submission of tender 31.03.2014 (up to 13:00 Hrs.) & Original DD of COST of BOQ & EMD
in form of DD/BG will have to be deposited to BSPTCL at least one Hour before opening of the
Techno-Commercial Bid (Part–1)
Date of opening of Techno-Commercial Bid (Part-1) : 31.03.2014 (at 04:30 PM.), Date of Pre bid
meeting on 18.03.2014 at 11:00 Hrs.

All other terms & conditions shall remain same.
While participating in e-tendering process, the contractor shall have to get them registered to get user ID,
Passwords and digital signature. This will enable them to access the Website: www.eproc.bihar.gov.in only.
E- Tender can be downloaded or uploaded only on website www.eproc.bihar.gov.in
Date of opening of price part: To be notified after Technical Bid Evaluation (www.eproc.bihar.gov.in)
The tender documents are available at website www.eproc.bihar.gov.in. Tender documents must be accompanied
with scanned copy of Demand Draft in favour of “ Sr. Manager Finance & Accounts, BSPTCL” payable at Patna
towards the cost of BOQ & EMD in form Bank Guarantee in favour of “ Sr. Manager Finance & Accounts,
BSPTCL, failing which the tender shall be summarily rejected (original Demand Draft to be submitted to
BSPTCL, Vidyut Bhawan Patna.)
Sd/Chief Engineer (Transimssion)
For complains regarding corruption Vigilance Help Line No.- 9431821485, 0612-2504969 Consumer can
deposit electricity bills via Sahaz Centre or via bsebbills.org
e-tendering introduced in BSPTCL for tenders above Rs. 25 lacs. For registration logon to
www.eproc.bihar.gov.in and eProcurement Help Desk First Floor, M/22,Bank Of India Building, Road No25, Sri Krishna Nagar, Patna-800001 at 0612-2523006, Mob: 9939035696.
