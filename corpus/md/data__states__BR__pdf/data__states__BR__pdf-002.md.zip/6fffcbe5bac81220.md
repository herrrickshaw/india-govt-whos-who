---
doc_id: "6fffcbe5bac81220"
source_url: "https://basu.org.in/wp-content/uploads/2020/02/General-Instruction-1.pdf"
ministry: "Bihar Animal Sciences University (BASU)"
title: "Click here to download"
date: ""
pages: 2
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "8bf4f63f134631d1"
---

<!-- page 1 -->

—_=
rg बिहार पशु विज्ञान विश्वविद्यालय, पटना
कक... 36२ 56, 5८८75 एप ५टारशआयए, ए७7४५- 80004
SEY (Established in 206 under Bihar Animal Science University Act-206)

COLLEGE OF FISHERIES, KISHANGANJ
GENERAL INSTRUCTIONS & CONDITIONS

i The candidates are required to apply only through ONLINE mode. Application filled-up through any other mode will not be
entertained. Before filling-up the Online Application Form, the candidates are advised to read General Instructions, Essential
Qualification and other important conditions carefully.

2 The University reserves the right to:

a) Withdraw the advertisement partly or wholly at any time without assigning reason to this effect.

b) Fill or not to fill-up some or all the posts advertised for any reason whatsoever.

¢) Increase / decrease the number of posts at the time of selection and make appointments accordingly.

d) Alter / insert any corrections / additions in the advertisement / website in the event of any error / or otherwise before the
last date prescribed for the receipt of the application

3 Candidates are advised to check / visit website of the University regularly for updates of the recruitment process,

4 If there is any corrigendum / addendum, it shall only be published on the website of the University.

5 The prescribed qualifications and experience are minimum and the mere fact that a candidate possesses the same will not be
entitled, for being called him / her for interview.

6 The University reserves the right to restrict the candidates to be called for interview to a reasonable number on the basis of
qualifications and experience higher than the minimum prescribed, or by any other condition that may deemed fit.

7 Canvassing in any form on behalf of any candidate will disqualify such candidate.

8 Candidates have to fill retevant score card and mention respective page number in hard copy (PDF) for the post applying for;
otherwise application shall be treated as incomplete and rejected. Selection will be made on the basis of candidates’ previous
record (as per relevant score card) and their performance in the interview.

9 The in-service candidates should apply through proper channel, failing which their application is liable to be rejected.

40 At the time of recruitment in University and its Colleges, service agreement should be signed between University / College and
the teachers which should be lodged with the Registrar / Dean with a copy to concerned teacher. Self-appraisal of performance
should be a part of the service agreement.

ll Advance copy of application form may be considered subject to production of NOC / Vigilance Clearance Certificate from
Employer at the time of interview.

i2 Experience and qualifications will be reckoned as on the last date of receipt of applications.

हक Applications incomplete in any respect will not be considered.

[4 Every page of the application form and enclosures (hard copy) must be signed by the candidate at the bottom of the page.

I5 All the printout of PDF form of application must be self-attested by the candidate with date. Originals must not be enclosed with
the application form. The candidate will have to produce the original copies of all the certificates and documents attached at the
time of interview for verification.

6 No interim queries regarding test/interview/selection will be entertained.

7 University reserves the right not to fill up the post advertised, if the circumstances so warranted.

8 ‘New pension scheme will be applicable with subsequent amendments to fresh regular recruited person.

9 Information uploaded on the University website shall not be provided to the candidate under the RTI Act-2005. The uploaded
information on the University website shall remain for a specific period only. Therefore, the candidates are advised to
downloaded the information and preserve them for future reference. In mid-way of recruitment process neither any application
under RTI information Act-2005 shall be entertained nor information shall be provided. Factual information under RTI Act shall
be provided only after declaration of final results. Reply to inferential (Speculative) questions shall not be provided.

20 In case of any disputes/suites or legal proceedings against the University, the Jurisdiction shall be restricted to the Courts in
Patna, which is the Head quarter of the University.

2i The statutory provision for relaxing of age in case of the candidates belonging all reserved categories of state of Bihar will be .
made applicable as per GAD, Bihar norms in vogue at time of interview. SC/ST candidates shall have to produce caste certificate
whereas EBC/BC candidates shall have to produce non creamy layer certificates issued by C.O. in favour of their claim of
reservation. EWS candidates have to produce desirable certificates (Candidates are advised to check GAD, Bihar website for
update information). Submission of residential certificate for the applicants of reservation categories is mandatory.

22 a) Applications of University Professors-cum-Chief Scientist retired at the age of 65 may be considered against the
post of University Professors-cum-Chief Scientist for appointment on Contract basis. Salary and terms of
appointment will be made as per provisions N.No. 3/M-63/203 Gen. Admn. Deptt. {0000/ Patna dated 0,07.20i5
issued by Bihar Government.

b) Tenure appointment may be done only in case of Professors for a period of 5 Yrs. or till attaining the age of 65 Yrs,
whichever is earlier.

c)} Professors retired from other Universities maximum age limit is 63 Yrs. will be treated as re-em ployed after
retirement and salary will be fixed on the basis of Last Salary drawn minus pension,

23 Errors and omissions are subject to corrections.

24 Applications received after the last date and without complete information or without requisite fee will be summarily rejected.
The University will not be responsible for any postal delay.

4
40

<!-- page 2 -->

z=

25 The University shall verify the antecedents or documents submitted by a candidate at any time of selection procedure, at the time
appointment or during the tenure of the service. In case, it is detected that the documents submitted by the candidates are fake or
the candidate has a clandestine antecedents / background and has suppressed the said information, then his services shall be
terminated.

26 Whole text of publication need not be uploaded. Attach only first page/ pages showing the necessary details of publication like-
title, Author (s), date/year of publication and name of journal / publication.

27 In case of any inadvertent mistake in the process of selection, which may be detected at any stage even after the issue of
appointment letter, the University reserves the right to modify/withdraw/cancel any communication made to the candidates.

28 In-Service Applicants may be given the advantage of their basic pay protection in the mentioned Level / Pay Band and Grade
Pay of the post.

29 Persons appointed may be transferred to any equivalent post within the jurisdiction of the University.

30 The Chairman of Selection Committee shall have the power to lay-down the procedure in respect of any matter not mentioned
above. The Selection Committee may decide its own method of evaluating the performance of the candidate in interview.

3] The persons serving in Central/State Govt. /Universities or Research Stations may be taken on deputation for 0 to 03 years or
up to the age of superannuation.

32 Online Application fee for UR / EBC/ BC Candidates: - Rs.!000/- and for SC / ST Candidates: Rs, 250/-, will be payable online
by Internet Banking /Debit Card / Credit Card only.

33 Application fee once paid shall not be refunded under any circumstances.

34 Maximum age of applicant of Assistant Professor as per Resolution No, 294 dated 07.0I.20I6 issued by GAD, Patna is as

follows

a) Unreserved Category (Male)- 37 Yrs.

4) = Backward Class and Extremely Backward Class (Male & Female)- 40 Ys.

c) Unreserved Category (Female)- 40 Yrs.

a Scheduled Castes and Scheduled Tribes (Male & Female)- 42 Yrs,

Age relaxation in maximum age for the post of Assistant Professor is as follows: -

35 i) As per Resolution No. 3 /M-63/2005-2374 dated 6-07-2007 issued by the then personnel & Administrative reforms
Department (at present GAD), Patna five years extra age relaxation shall be admissible to the employees of Govt. of
Bihar applying for Higher Pay Scale (i.e. Grade Pay , Level etc) in services / cadres.

ii) As per Section 4.4 of Bihar Gazette (Extra) 2I“ March-207, (Bihar Agricultural University, Sabour Notification

dated 27" Feb. 2047)

a} The maximum age limit for entry into the service up to Asstt. Prof. rank in the University shall be as
prescribed by the State Govt. from time to time. However, there shall be no age limit for appointment on
Technical Posts such as Deans, Directors / Registrar/ University Professor/ Associate Professor or equivalent
in the university.

b) There will be no age restriction for employees of the University seeking higher posts under direct recruitment
procedures.

36 Reservation shall only be applicable to the original resident of Bihar State SC, SC(F), ST, ST (F), EBC, EBC (F), BC, BC
{F), EWS, EWS (F) and WBC. Horizontal Reservations to Divyang / Grandchild of freedom fighter, shall be applicable
as per Guidelines Govt. of Bihar.

37 As per Circular No. ]/atc-o-l-44,/205 #fowlo 2342 dated 5.02.2046 in case of unavailability of female candidate (UR-
F, SC-F, EBC-F, BC-F, EWS-F) post may be filled with male candidate of same category in the same transaction.

38 As per (Bihar Extra ordinary Gazette, Bihar Act-2,20I9 ) The Bihar Reservation in vacancies in posts and in Services
and in Admission in the Educational Institutes (For Economically Weaker Sections) Act,20I9 Clause-, if candidate
from EWS are not available to the extent of reservation percentage prescribed under Act the vacancies of this category
shall be filled up by the candidates of Open Merit Category in the same transaction.

39 submission of self-attested printed online application along with relevant / desired documents (PDF) along with print out of
the online fees receipt by registered / speed post within the envelope superscripted “Application for the post of.............” ‘
addressed to The Registrar, Bihar Animal Sciences University, PO: Bihar Veterinary College, Patna — 80004 .

) Last date of submission of the online application form and fees 2. 42/03/2020 वा

04:00 PM.

i) The last date of submission of self-attested printed online application along with relevant / : 27/03/2020 at
desired documents (PDF) along with print out of the anline fees receipt by registered / speed 04:00 PM.
post.

iii) Application Fee will be payable through online by Internet Banking / Debit Card / Credit Card only.

40 Selected candidates will have to submit a bond on non-judicial stamp paper at the time of joining the service to serve
the University for at least three years. No application for outside employment shall be forwarded during the bond
period of three years.

Place: Patna 5 ‘ae

Date: 2/22/2020 Vv BASU, Patna

a }
; 4६
