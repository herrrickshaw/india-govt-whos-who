---
doc_id: "acf8853e99f4eaec"
source_url: "https://tourism.bihar.gov.in/content/dam/bihar-tourism-aem/artist-notification-for-shrawa/Munger.pdf"
ministry: "Bihar Tourism"
title: "Download"
date: ""
pages: 11
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "9c4bd54cefcabb55"
---

<!-- page 1 -->

<!-- page 2 -->

Jko.kh esyk] 2025 ds volj ij lkaLd`frd dk;ZØe esa izLrqfr gsrq dykdkjksa }kjk izkIr vkosnuksa dh lwph
eqaxjs
Ø0

dykdkj dk uke

1

fleju Jqfr

2

Jh lqjsUnz izlkn

3

vfurk dqekjh

4

dfork pkS/kjh

5

Jh pUnu dqekj

6

fjadh dqekjh

7

fj;k fxjh

8

vjfoUn dqekj

9

_rq dqekjh

10

Hkksyk ikloku

11

v’kksd dqekj ¼vkn'kZ
lekt½
ƌƚŝƐƚƐůŝƐƚĨŽƌ^ŚƌĂǀĂŶŝDĞůĂϮϬϮϱͬϭ


irk@ eks0ua0@ bZesy

xzsM

vU; vk;kstuksa esa
izLrqfr
Jko.kh esyk 2024
gfjgj esyk 2023

izLrqfr dh
fo|k
yksd xkf;dk

iwoZ esa vf/kdre
Hkqxrku
&&

vH;qfDr

lksuiqj esyk 2022

yksdxhr

&&

&&

yksdxkf;dk

&&

xzsM izek.k i=
layXu
&&

nwjn’kZu dsUns 2018

Ykksdxhr
Hktu

&&

xzsM izek.k i=
layXu

&&

lkaLd`frd
dk;ZØe

&&

&&

ch&xzsM

lksuiqj esyk] 2017
jktxhj esyk] 2023
ljl esyk] 2023

lkaLd`frd
dk;ZØe

&&

xzsM izek.k i=
vizkIr

&&

&&

yksd xkf;dk

&&

&&

&&

&&

yksd xk;d

&&

&&

&&

&&

yksd xkf;dk

&&

&&

&&

&&

&&

&&

&&

&&

yksd xk;d
,oa ny
lkaLd`frd
dk;ZØe

&&

&&

irk&308] jke fudsru vikVZeVsa ] jksM
&&
ua&14] lgnso iFk] iVsy uxj]
iVuk&800023
eks0ua0&9304634344
bZesy& ƐŝŵƌĂŶƐŚƌƵƚŝϭϭΛŐŵĂŝů͘ĐŽŵ
ch gkbZ xzsM
jketh pd] ckVkxat] iVukA
eks0&9334707635] 7979882623
&&
irk&/kksHkh xyh] U;q ,fj;k] dnedqvk¡]
iVuk&800003] eks0& 7667447407
Tkkudh Le`fr] okVj iEi jksM] ihj ch gkbZ
eqgkuh] iVuk] fcgkjA
xzsM
Eks0&9473459885] 7091139918
&&
irk&’ksjiqj eusj iVuk& 801503]
fcgkj] eks0 ua0& 7563849976
bZesy& ĐŬϭϳϭϴϳϮϰΛŐŵĂŝů͘ĐŽŵ
gjnso bUDyso] CykWd ,] QySV ua 501]
dkyh eafnj jksM] guqeku uxj] dadM+ckx]
iVukA eks0&7033700745
bZesy&ƌŝŶŬŝĚƵďĞǇϭϰϰϱΛŐŵĂŝů͘ĐŽŵ
irk&oS’kkyh&844126]
eks0ua0& 9934235966]8804689496
irk&nkukiqj&801502] iVuk
eks0ua0& 91355324857
irk& lksuiqj] lkj.k& 841101]
eks0ua0& 8877662065
irk&fcgVk& 801103] iVukA
eks0ua0& 9128379199
irk&lSniqj]
dnedqvk¡]
ckadhiqj]
iVuk&800004]

&&

<!-- page 3 -->

eks0ua0&8800449985] 95600061720
bZesy& ĂĚĂƌƐŚĂŵĂũŝŶĨŽΛŐŵĂŝů͘ĐŽŵ

12

vkdka{kk oekZ

13

euksjatu flag

14
15

iVukA eks0&8434736884

irk&eksguiqj] /kjgjk] eqxjsa ]
eks0ua0& 8969887834
Jh latho dqekj frokjh U;w ekbdk dkWyksuh] nh?kk ?kkV] iVuk
eks0&8407838708] 8072011426
bZesy&ƐĂŶũŝǀƚŝǁĂƌǇϴϰϭϵϵϱΛŐŵĂŝů͘ĐŽŵ
HkkjrsUnq dqekj flag
fHk[kuk igkM+h] iVuk] fcgkjA
¼lfpo] lcsjk dyk dsUnz½ eks0&9931445078

&&

Jko.kh esyk] 2024

&&

Jko.kh esyk 2017
Jko.kh esyk 2016

&&

Jko.kh esyk 24]
fcgkj fnol 23]
lksuiqj esyk 23
Jko.kh esyk] 2017
lksuiqj esyk] 2016
eyekl esyk] 2018

&&

bZesy&ƐĂďĞƌĂŬĂůĂŬĞŶĚƌĂϭΛŐŵĂŝů͘ĐŽŵ

lkaLd`frd
dk;ZØe
yksdxhr ,oa
Hktu xk;d
Hktu

:0 40]000@&
Jko.kh esyk 2024
&&

&&

&&

&&

yksd u`R;

:0 50]000@&
lksuiqj esyk]
2016

&&

&&

&&

vktknh dk ve`r
egksRlo 2022

lkaLd`frd
dk;ZØe

&&

&&

&&

fcgkj fnol

yksd xkf;dk

&&

&&

18

lqj laxe dyk laLFkku

Loj eatjh laxhr dyk dsUnz]
xzke&gkml ua&56] fl)s’oj uxj]
eSuiqjk] iVukA eks0&9304332112
irk& lxquk eksM+] esuiqjk¼nkukiqj½]
iVuk
eks0ua0& 99055952924
irk&308] jke fudsru vikZVesVa jksM]
ua0& 14] 'knso iFk] iVsy uxj]
iVuk&23
eks0ua0& 8383923061@7532041182

&&

lqj laxe egksRlo
2024

lkaLd`frd
dk;ZØe

&&

&&

19

Jh vkpk;Z rfud ik.Ms; iapoVh uxj] cktkj lfefr] jktsUnz uxj]

&&

yksd xk;u

:0 40000@&
Jko.kh esyk 2024

20

Jh v:.k dqekj xkSre

21

jhuk dqekjh mQZ jhuk
esgrk

ch xzsM

Jko.kh esyk 24]
Jko.kh esyk 23]
lksuiqj esyk 22
lksuiqj esyk 16] fcgkj
fnol 19
Jko.kh esyk 2024

22

lksukfydk dqekjh

&&

Jko.kh esyk 24]

yksd xk;u

16

pqUuh yky ¼lfpo] Loj
eatjh½

17

iwtk dqekjh

iVuk] eks0&9334137162] 7004979373

ƌƚŝƐƚƐůŝƐƚĨŽƌ^ŚƌĂǀĂŶŝDĞůĂϮϬϮϱͬϮ


,e-,Q-&3] 7@30] ch-,p-dkWyksuh]
HkwrukFk jksM] iVukA eks0&9304895932
xzke&u[kkl]eaxy
v[kkM+k]
iks0&csxeiqj] ekylykeh] iVukA
eks0&7717773418
bZesy&ƌĞĞŶĂƐŝŶŐĞƌϬΛŐŵĂŝů͘ĐŽŵ
irk&vkj0,e0,l0 dkWyksuh] jksM ua0
03] dadM+ckx] iVukA
Ekks ua0& 9525629003

ch Js.kh

&&

yksdxhr

:0 40]000@& xzsM izek.k i=
lksuiqj esyk 2024
vizkIr
xzsM izek.k i=
&&
layXu
:0 40000@&
Jko.kh esyk 2024

&&

<!-- page 4 -->

23

24

25

26
27
28
29

bZesy ŬƐŽŶĂůŝŬĂϮϵΛŐŵĂŝů͘ĐŽŵ
yfyrk ;knosUnw ,oa lkFkh irk& v’kksd uxj] jksM ua0& 08] jke
y[ku iFk] dadM+ckx] iVuk&20
eks0ua0&9263350867
bZesy ǇĂĚǁĞŶĚƵůĂůŝƚĂΛŐŵĂŝů͘ĐŽŵ
MkW0 fo’oukFk 'kj.k flag irk& jkt ukjk;.k flag]

fiz;adk dqekjh

xzke o iksLV& dqYgfM+;k] Fkkuk&dksbZyoj]
ftyk&Hkkstiqj] vkjk ¼fcgkj½
eks0&9386743364] 7903344353
bZesy&ƐŚŝǀũŝƐŝŶŐŚϲΛŐŵĂŝů͘ĐŽŵ
irk& ¶ySV u 12] oS’kkyh fudsru] uh;j
cgknqjiqj]
cktkj
lfefr
jksM]
iVuk&800016] fcgkj
eks0ua0 7739765557

Jh txUukFk izlkn flag xzke&etfyliqj] iks0&vYyhiqj gV~Vk]
¼vkdk’kok.kh ,oa nwjn’kZu Fkkuk&egukj] oS’kkyhA
iVuk½
eks0&7667684506
Jherh lhrk nsoh
'kkafr fudsru dkWyksuh] HkwrukFk jksM]
iVukA eks0&9570736032

&&

Jko.kh esyk 24]

yksd xkf;dk

:0 40000@&
Jko.kh esyk 2024

&&

&&

fcgkj egksRlo ¼xksok½
2018

lkaLd`frd
dk;ZØe

:0 1]00]000@&
fcgkj egksRlo
¼xksok½ 2018

&&

&&

lksuiqj esyk 2024

lkaLd`frd
dk;ZØe

&&

&&

ch&xzsM

Jko.kh esyk 2024
Jko.kh esyk 2023

lkaLd`frd
dk;ZØe

:0 45]000@&
Jko.kh esyk 2023

xzsM izek.k i=
layXu

lkaLd`frd
dk;ZØe

35]000@&
Jko.kh esyk 23

&&

lkaLd`frd
dk;ZØe

&&

&&

lkaLd`frd
dk;ZØe

:0 90]000@&

&&

&&

&&

:0 40]000@&
Jko.kh esyk]
2023

xzsM izek.k i=
layXu

egukj egks0 2017 vkfn

dksey dqekjh

'kkafr fudsru dkWyksuh] HkwrukFk jksM
iVuk] fcgkjA
eks0&9693722340

&&

Jko.kh esyk 23]
Jko.kh esyk 22]
lksuiqj esyk 19]
&&

vfnrh flag

irk& ;’kw gkml] viksftV& xsV ua0&50]
esuiqjk] jktkiqj iVukA eks0&9123435823

&&

Jko.kh esyk 2024

;^ĂŶũƵŬƚĂ&ŽƵŶĚĂƚŝŽŶͿ

&&

bZesy&ĨŽƵŶĚĂƚŝŽŶƐĂŶũƵŬƚĂΛŐŵĂŝů͘ĐŽŵ
30

Lqjkt dqekj

31

lksgjkbZ dqekj fujkyk

32

Jherh fdj.k dqekjh
ƌƚŝƐƚƐůŝƐƚĨŽƌ^ŚƌĂǀĂŶŝDĞůĂϮϬϮϱͬϯ


irk&lkj.k] Nijk
eks0ua0& 6299726096

&&

&&

xzke&xkthiqj]iks0&lksuHknz] Fkkuk&ca’kh]
ftyk&vjoy] fcgkjA
eks0&7282919241
bZesy&ŵŝƐŚƌĂƌĂũŝǀϱϱϳΛŐŵĂŝů͘ĐŽŵ
,y,Q VkbZi 1] CykWd 5] QySV ua28] jksM ua- 10,Q] jktsUnzuxj] iVukA

ch gkbZ
xzsM

Jko.kh esyk] 2023

&&

fcgkj fnol 2023
Jko.kh esyk 2023
Jko.kh esyk 2024

fcgkj fnol] 2023

lkaLd`frd
dk;ZØe
lkaLd`frd
dk;ZØe
yksdxhr

Jko.kh esyk 2024

:0 40]000@&
Jko.kh esyk]
2023

<!-- page 5 -->

eks0&7004229353
33

e/kqckyk flag

34

iznhi dqekj ;kno

ŵĂŝůͲŬŝƌĂŶŬƵŵĂƌŝϲϴϭϵΛŐŵĂŝů͘ĐŽŵ

irk&pdQrg] iks0&dtjh cqtZx]
ftyk&oS’kkyh
eks0ua0& 8207694723
bZesy& ũŽŐŝĨŽƵŶĚĂƚŝŽŶΛŐŵĂŝů͘ĐŽŵ
irk&
xqnjhgkrk]
iksLV&dpukj]
Fkkuk&fllou] ftyk&lhoku ¼fcgkj½
841210
eks0ua0& 9304198508
bZesy&

&&

&&

lkaLd`frd
dk;ZØe

&&

&&

&&

xksikyxat egksRlo
2016
gksyh feyu lekjksg

yksdlxhr@
lqxe laxhr

&&

&&

irk& dksgok] [kq’k:iqj] iVuk&
803202 ¼fcgkj½
eks0ua0& 07903457624
bZesy ŚŝŶĚǇƵǀĂŶƐŚŬƚŝďŐƉΛŐŵĂŝů͘ĐŽŵ
irk&tkudh Le`fr] ikuh Vadh jksM]
ihjeqgkuh iVukA
eks0ua0& 9334032779] 7563817808
irk&xzko o iksLV& ljsutk] Fkkuk&
jktiqj] ftyk& cDlj] 805114] fcgkj
eks0us0& 6204798330] 7903454976
bZesy&ƐŝŶŐĞƌŵŽŶŽŚĂƌƉĂŶĚŝƚϭϮϯϰΛŐŵĂŝů͘

&&

nks fnolh; yksd jax
egksRlo 2017
laxhr ukVd vdknseh

lkaLd`frd
dk;ZØe

:0 50]000@&
laxhr ukVd
vdknseh

&&

ch gkbZ
xzsM

Jko.kh esyk 2023

xk;d

:0 40]000@&
Jko.kh esyk 2023

xzsMM
s izek.k
i= vizkIr

&&

Jko.kh esyk 2024
ljl esyk 2023

lkaLd`frd
dk;ZØe

:0 40]000@&
Jko.kh esyk 2024

&&

&&

Jko.kh esyk 2024
lksuiqj esyk 2023

Xkk;d

&&

&&

&&

fnO;kax egksRlo 2024

lkaLd`frd
dk;ZØe

&&

&&

&&

&&

Hktu

&&

&&

ƉƌĂĚĞĞƉƐŝŶŐŚǇĂĚĂǀϭϱϰϲϵΛŐŵĂŝů͘ĐŽŵ

35

fgUn ;qok 'kfDr

36

Jh vo/ks’k dqekj

37

nLrd xzkeh.k fodkl
lsok laLFkku

ĐŽŵ

38

:nz ukjk;.k mQZ dqekj
'kkyw

39

Jh pUnu ?kks"k

40

Jh vfHk"ksd dqekj
ƌƚŝƐƚƐůŝƐƚĨŽƌ^ŚƌĂǀĂŶŝDĞůĂϮϬϮϱͬϰ


irk&xzke
o
iksLV&
jlsu]
Fkkuk&jktkiqj] ftyk&cDlj] 802128]
fcgkj
eks0ua0& 9798247532
bZesy ƐŚĂůƵŬƵŵĂƌďǆƌΛŐŵĂŝů͘ĐŽŵ
irk& lSniqj] ugj jksM] uan uxj
dkWyksuh] leirpd] iVuk 800016]
fcgkj
eks0ua0&9693442239
irk& EdW͕dgyxkWo fcgkj

<!-- page 6 -->

41
42
43
44
45
46
47
48
49
50
51

eks0ua0& 82994449071
bZesy& ĂďŚŝƐŚĞŬŐƵƉƚĂĐůŐΛŐŵĂŝů͘ĐŽŵ
Jh Hkjr dqekj
irk& Hkkxyiqj] fcgkj
eks0ua0a& 7544988044
bZesy&ďŚĂƌĂƚŬƵŵĂƌũĞĞϬϭϰΛŐŵĂŝů͘ĐŽŵ
LohfV fiz;k
irk&lqyrkuxat fcgkj]
Eks0ua0& 7352653110
bZesy& ƐǁĞĞƚǇŬƵŵĂƌŝϵϭϮϮΛŐŵĂŝů͘ĐŽŵ
Jh nhid >k
irk&ckadk] fcgkj
eks0ua0& 9939223287
bZesy ĚĞĞƉĂŬũŚĂϬϲϱϰΛŐŵĂŝů͘ĐŽŵ
Jh vo/ks’k >k
irk& vejiqj] ckadk] fcgkj
eks0ua0& 8521209014
bZesy ĂďĚĞƐŚũϭϵΛŐŵĂŝů͘ĐŽŵ
Jh uhf[ky dqekj >k
irk& Hkkxyiqj] fcgkj
eks0ua0a& 7903905395
bZesy&ŶũũŚĂϵϭϳϴΛŐŵĂŝů͘ĐŽŵ
Jh fot; lksuh Lokjudj irk& eqxajs ] fcgkj
eks0ua0a& 8789706572
bZesy&ǀŝũĂǇƐŽŶŝϬϮϭΛŐŵĂŝ͘ĐŽŵ
Jh fizla dqekj
irk& csxqljk;] fcgkj
eks0ua0a& 8210055141
bZesy&ƉƌŝŶĐĞŬƵŵĂƌϮϰϭϴϮΛŐŵĂŝů͘ĐŽŵ
iqtk Hkkjrh
irk& Hkkxyiqj] fcgkj
eks0ua0a& 9523925094
bZesy&ƉŽŽũĂďŚĂƌƚŝƐŝŶŐĞƌΛŐŵĂŝů͘ĐŽŵ
ljLorh dqekjh
irk& EdW͕dgyxkWo fcgkj
eks0ua0& 99962916121
bZesy& ŐƵƉƚĂǀĞĞŶĂϭϱϵΛŐŵĂŝů͘ĐŽŵ
vkjrh dqekjh
irk& EdW͕dgyxkWo fcgkj
eks0ua0& 6207975719
bZesy& ĂƌƚŝŬƵŵĂƌŝϮϵϯϮϵΛŐŵĂŝů͘ĐŽŵ
Jh lfpu dqekj
irk& Hkkxyiqj] fcgkj
eks0ua0a& 7717781820
ƌƚŝƐƚƐůŝƐƚĨŽƌ^ŚƌĂǀĂŶŝDĞůĂϮϬϮϱͬϱ


&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu@ yksd
xf;dk

&&

&&

&&

&&

yksd xf;dk

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

<!-- page 7 -->

52
53
54
55
56
57
58
59
60
61
62

bZesy&ŬƐĂĐŚŝŶƐĂĐŚŝŶĂϰϭϬΛŐŵĂŝů͘ĐŽŵ
Jh lq/khj nkl@,l0 joh irk& Hkkxyiqj] fcgkj
dqekj
eks0ua0a& 9939822971] 8603472384
bZesy&ƚŚĞƌŽĐŬϴϭϯϮΛŐŵĂŝů͘ĐŽŵ
‘’kf’k izHkk tk;loky irk& Hkkxyiqj] fcgkj
eks0ua0a& 9546508098
bZesy&ƐŚĂƐŚŝƉƌĂďŚĂŵĚƉΛŐŵĂŝů͘ĐŽŵ
lsod dqekj >k
irk&ckadk] fcgkj
eks0ua0& 9934094333
bZesy ƐŝƉĂŬũŚĂΛŐŵĂŝů͘ĐŽŵ
_flrk jkt
irk& Hkjr] Hkkxyiqj] fcgkj
eks0ua0a& 9006131304
bZesy&ƌŝƐŚŝƚĂƌĂũŽĨĨŝĐŝĂůϭϮϭΛŐŵĂŝů͘ĐŽŵ
Jh jkgqy nso oekZ
irk& [kxfM+;k] fcgkj
eks0ua0a& 8210212032
bZesy&ƌĂŚƵůŬŚĂŐĂƌŝĂůϭϮϯΛŐŵĂŝů͘ĐŽŵ
uhosfnrk ;kno
irk& iVuk] fcgkj
eks0ua0a& 9708665460
bZesy&ŶŝǀĞĚŝƚĂǇ͘ϵϯΛŐŵĂŝů͘ĐŽŵ
eksgu dqekj
irk& e/kqcuh] fcgkj
ikloku@,e0ds0 eksgu eks0ua0a& 9931019332
bZesy&ŵŽŚĂŶŬƉĂƐǁĂŶϭϵϴϵΛŐŵĂŝů͘ĐŽŵ
eukst dqekj
irk& Hkkxyiqj] fcgkj
eks0ua0a& 62052875460
bZesy&ĂŶĐŚŽƌŵĂŶŽũďŚĂƌƚŝΛŐŵĂŝů͘ĐŽŵ
jh;k dqekjh@ jh;k lksuh irk& Hkkxyiqj] fcgkj
eks0ua0a& 9608726368
bZesy&ƌŝǇĂϳϱϮϲϬΛŐŵĂŝů͘ĐŽŵ
vkjrh dqekjh@ vkjksgh irk& Hkkxyiqj] fcgkj
>k
eks0ua0a& 7970525829
bZesy&ĂƌŽŚŝũŚĂϳϰΛŐŵĂŝů͘ĐŽŵ
lqfiz;k nsoh@ fiz;k jkt irk& dgyxkWo fcgkj
eks0ua0& 9102985756
bZesy& ƐŽŶƵƐĂũĂŶϯϵΛŐŵĂŝů͘ĐŽŵ
ƌƚŝƐƚƐůŝƐƚĨŽƌ^ŚƌĂǀĂŶŝDĞůĂϮϬϮϱͬϲ


&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu@ yksd
xk;d

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu@yksd
xf;dk

&&

&&

<!-- page 8 -->

63

irk& Hkkxyiqj] fcgkj
eks0ua0a& 8862977294
bZesy&ƐŝŶŐŚŬŚƵƐŚďƵϴϭϮϬϬϬϮΛŐŵĂŝů͘ĐŽ

&&

&&

Hktu

&&

&&

irk& Hkkxyiqj] fcgkj
eks0ua0a& 8757621678
bZesy&ĂŶũƵĚĞǀŝϵϲϲϲϵΛŐŵĂŝů͘ĐŽŵ
irk& Hkkxyiqj] fcgkj
eks0ua0a& 8298396724
bZesy&ĂŵĂŶƉĂŶĚĞǇϭϳϳϲϲΛŐŵĂŝů͘ĐŽŵ
irk& Hkkxyiqj] fcgkj
eks0ua0a&7992541997
bZesy&ĂƌƉĂŶƉĂŶĚĞǇϮϰϬϮΛŐŵĂŝů͘ĐŽŵ
irk& Hkkxyiqj] fcgkj
eks0ua0a&7631377331
bZesy&ŵĂŶŝƐŚďŐƉϮϬϭϮΛŐŵĂŝů͘ĐŽŵ
irk& Hkkxyiqj] fcgkj
eks0ua0a&9279014793
bZesy&ŬĂƌĂŶŬƵŵĂƌŐŐĂϴϭϯϮϬϱΛŐŵĂŝů͘ĐŽ

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

thrsUnz ikloku@ dqekj irk& Hkkxyiqj] fcgkj
thrq
eks0ua0a&8340224318
bZesy&ũŝƚƵũŽŚŶϬϰϲΛŐŵĂŝů͘ĐŽŵ
ctjax dqekj
irk& ckadk fcgkj
eks0ua0a&7004608168
bZesy&ďĂũƌĂŶŐŬƵŵĂƌĚƉϭϮϱΛŐŵĂŝů͘ĐŽŵ
vfer dqekj ikloku
irk& Hkkxyiqj] fcgkj
eks0ua0a&7004326335
bZesy&ĂƉĂϰϭϵϰϭϲϴΛŐŵĂŝů͘ĐŽŵ
vfHk"ksd dqekj lkg
irk& Hkkxyiqj] fcgkj
eks0ua0a&8271848035
bZesy&ĂďŚŝƐŚĞŬŬƵŵĂƌƐĂŚĂϯϬΛŐŵĂŝů͘ĐŽ

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

&&

&&

Hktu

&&

&&

[kq’kcq dqekjh

ŵ

64

vatq nsoh@ vatq >k

65

veu dqekj ik.Ms;

66

vjiu dqekjh@vjiu
ik.Ms;

67

euh"k dqekj pkS/kjh

68

dj.k dqekj lkg

ŵ

69
70
71
72

ŵ

73

larks"k flag
ƌƚŝƐƚƐůŝƐƚĨŽƌ^ŚƌĂǀĂŶŝDĞůĂϮϬϮϱͬϳ


irk& dfVgkj] fcgkj

<!-- page 9 -->

74

fLerk Lo:i

75

foDdh frokjh

76

lUUkh dqekj

77

xksyq dqekj

78

lksuq dqekj

79

eks0ua0a&7033211003
bZesy&ƐĂŶƚŽƐŚƐŝŶŐŚďĞĚŝΛŐŵĂŝů͘ĐŽŵ
irk& dfVgkj] fcgkj
eks0ua0a&78705853543
bZesy&ƐŝŶŐĞƌŵŝƚĂƐǁĂƌƵƉϭΛŐŵĂŝů͘ĐŽŵ
irk& xzke&NksVh cfy;k] iks0&
y[keuh;k] Fkkuk& NksVh cfy;k] ftyk
& csxqljk;] 8511211] fcgkj
eks0ua0& 8579876131
bZesy&ďŝŬŬŝƚŝǁĂƌŝϴΛŐŵĂŝů͘ĐŽŵ
irk& v’kksd uxj] dadM+ckx]ftyk&
iVuk] 800020] fcgkj
eks0ua0& 7079482316
bZesy&^ƵŶŶǇŬƵŵĂƌϰϱϲϮϯϲΛŐŵĂŝů͘ĐŽŵ
irk&
xzke&nfg;koka
iksLV]
lkgscxat]ftyk&lkj.k]fcgkj
eks0ua0& 9546735973
irk&xzke&dkyqiqj]iksLV&rqtkjiqj]
ftyk&lkj.k]fcgkj
eks0ua0& 7061718730

Jh lqjsUnz ukjk;.k ;kno ch&25] vYdkiqjh] xnZuhckx] iVuk&2
¼Jh d`".k E;wftdy xzqi½ eks0&9431414708] 8544105014]

80

pUnz dkUrk nsoh

81

efgek 'kadj

82

iwtk dqekjh
¼uo l`tu ,oa lokZaxh.k
fodkl laLFkku½

bZesy&ƐƵƌĞŶĚƌĂϵϰϯϭϰΛŐŵĂŝů͘ĐŽŵ
irk&fpjs;k VkaM iqy] dadM+ckx jksM]
dqUrh esfMdy ds ihNs] iVuk&20
eks0ua0& 9341240083

iwohZ yksgkuhiqj] jsyos gaVj jksM] ¶ySV
ua&204] , CykWd] dnedqvka&3
eks0&8234854908
if'peh yksgkuhiqj] cq) ewfrZ ds ihNs]
Kku Hkou] dnedqvka] iVukA
eks0&7870960967
bZesy&ŬƉƵũĂϵϴϯϯΛŐŵĂŝů͘ĐŽŵ
ǁĞďͲŶĂǀƐƌŝũĂŶďŝŚĂƌ͘ŽƌŐ

ƌƚŝƐƚƐůŝƐƚĨŽƌ^ŚƌĂǀĂŶŝDĞůĂϮϬϮϱͬϴ


&&

&&

Hktu

&&

&&

&&

&&

Hktu@’kkL=h
; laxhr

&&

&&

&&

&&

lkaLd`frd
dk;ZØe

&&

&&

&&

&&

lkaLd`frd
dk;ZØe

&&

&&

&&

&&

lkaLd`frd
dk;ZØe

&&

&&

ch gkbZ

Jko.kh esyk 2024
ljl egksRlo 2024

lkaLd`frd
dk;ZØe

&&

ch&xzsM

Jko.kh esyk 2024

Hktu laxhr

&&

ch gkbZ&xzsM
izek.k i=
layXu
ch&xzsM izek.k
i= layXu

&&

oS’kkyh egksRlo 2025

lkaLd`frd
dk;ZØe

&&

&&

&&

&&

lkaLd`frd
dk;ZØe

&&

&&

<!-- page 10 -->

83

iwtk dqekjh

84

Jhefr lquhrk lgk;

85

Jh lqjsUnz ukjk;.k ;kno

86

lkSE;k ,oa ny
lkSE;k 'kadj ,oa ny

87
88

89

90

91
92
93

irk&if'peh yksgkuhiqj] jsyos gaVj
jksM dne dqvka] iVuk&3
eks0&99934906136
irk& jktsUnz uxj] iVuk&16
eks0ua0 9430956104] 6200292596

&&

&&

lkaLd`frd
dk;ZØe

&&

&&

&&

lksuiqj esyk
jktxhj egksRlo

yksd xkf;dk

&&

&&

ch&25] vYdkiqjh] xnZuhckx] iVuk&2
eks0&9431414708] 8544105014]
bZesy&ƐƵƌĞŶĚƌĂϵϰϯϭϰΛŐŵĂŝů͘ĐŽŵ

ch gkbZ

Jko.kh esyk 2024
ljl egksRlo 2024
eyekl esyk 2023

lkaLd`frd
dk;ZØe

:0 50]000@&

iwohZ yksgkuhiqj jsyos gaVj jksM] ¶ySV
uaŒ 204] , CykWd] dne dqvka]
iVuk&3] eksŒ&9204296667
vafdrk fdj.k
mtkZ uxj] lxquk eksM+] [kxkSy jksM]
iVuk] fcgkjA eks0&7970811367
eSgj laxhr dyk fodkl irk&xksyk jksM cktkj lfefr]
lfefr
iVuk&801503]
eks0ua0& 9835408932
bZesy ƐĂŶŐĞĞƚŵĞŚĂƌΛŐŵĂŝů͘ĐŽŵ
egknso laxhr dyk dsUnz irk&jkeuxjh
lsDVj
04]
Fkkuk&jkthouxj] iVuk 25
eks0ua0& 7070902444] 9472241852
bZesy ŵƵƐŝĐŵĂŚĂĚĞǀϴΛŐŵĂŝů͘ĐŽŵ
jathr dqekj ¼ukyUnk
irk& eftLVªsV dkWyksuh] vkf’k;kuk
laxhr dyk fodkl
uxj] jke uxjh eksM]+ lsDVj&1] iVuk
laLFkku½
&25
eks0ua0 9835408932]9472241832
bZesy& ƌĂŶũĞĞƚŵƵƐŝĐϯϭΛŐŵĂŝů͘ĐŽŵ
ex/k laxhr laLFkku
vkf'k;kuk fn?kk jksM] iVukA
eks0&8294970463

ch gkbZ

oS’kkyh egksRlo 2025

lkaLd`frd
dk;ZØe

&&

ch gkbZ&xzsM
izek.k i=
layXu
ch gkbZ&xzsM
izek.k i=
layXu

&&

lksuiqj esyk 2024

xkf;dk

:0 40]000@&

&&

&&

jkT;Lrjh; d`f"k
;kaf=dj.k esyk ¼,xzks
fcgkj esyk½ 2023

lkaLd`frd
dk;ZØe

:0 40]000@&
¼,xzks fcgkj
esyk½ 2023

&&

&&

jkT;Lrjh; d`f"k
;kaf=dj.k esyk ¼,xzks
fcgkj esyk½ 2023

lkaLd`frd
dk;ZØe

:0 30]000@&
¼,xzks fcgkj
esyk½ 2023

&&

&&

lhrke<+h egksRlo
2025
mykj egks Rlo
2025

&&

:0
2]00]000@&
lhrke<+h
egksRlo 2025

&&

&&

lksuiqj esyk 2022

lkaLd`frd
dk;ZØe

:0
1]50]000@&

&&

Ekk¡ rkjk laxhr dyk dsUnz rqylhuxj] cktkj lfefr] xksyk jksM]
iVuk
Fkkuk&nkukiqj] ftyk& iVukA
eks0&9472241832
lkfjdk d`".k v[kkSjh
iVuk]
eks0ua0& 9262580576

&&

ƌƚŝƐƚƐůŝƐƚĨŽƌ^ŚƌĂǀĂŶŝDĞůĂϮϬϮϱͬϵ


&&

eyekl esyk
2023

lksuiqj esyk 2023

lksuiqj esyk 2022

Jko.kh esyk 2024
lksuiqj esyk 2022

lkaLd`frd
dk;ZØe

:0 90]000@&

Jko.kh esyk 2024

&&

&&

yksd u`R;

&&

&&

<!-- page 11 -->

94

vfu’kk dqekjh

irk& fHk[kuk igkM+h] iVuk
eks0ua0& 7764964558
Jh 'k’kkad dqekj ¼lfpo] irk&bUnzizLr dkWyksuh xksyk jksM]
'kkfUr dyk dsUnz] iVuk½ Fkkuk&nkukiqj] iVuk] fcgkjA
eks0&9142399457] 9835408932
veu dqekj
irk&xksyk
jksM]
Fkkuk&nkukiqj]
iVuk&801503] fcgkjA
eks0&8210828456
izhfr dqekjh
02 ua xkN] dkyh eafnj] NksVh
ds’koiqj] tekyiqj] nkukiqj] iVukA
eks0&9525835944] 7070332561
bZesy&ŵĂŶĚĂůĂůŽŬΛŐŵĂŝů͘ĐŽŵ
Ekk¡ fo/;kapy dyk dsUnz irk&bUnzizLr dkWyksuh xksyk jksM]
Fkkuk&nkukiqj] iVuk&801503] fcgkjA
eks0&9835408932
bZesy sŝŶĚŚǇĂĐŚĂůƐĂŶŐĞĞƚΛŐŵĂŝů͘ĐŽŵ
Jh 'k’kkad dqekj
irk&eksrh uxj] Fkkuk&[kxkSy] iVuk]
fcgkjA
eks0&9142399457]
xq:nso laxhr laLFkku irk&vkf’k;kuk nh/kk jksM] iVuk&
800025
eks0&9472241832

95
96
97

98

99
100



ƌƚŝƐƚƐůŝƐƚĨŽƌ^ŚƌĂǀĂŶŝDĞůĂϮϬϮϱͬϭϬ


&&

&&

yksd u`R;

&&

&&

&&

dkSenq h egksRlo] 24
ddksyr egksRlo] 24
lksuiqj esyk] 23
eankj egksRlo 2025

lkaLd`frd
dk;ZØe

&&

&&

Hktu

:0 40]000@&

&&

yksdxhr

:0 40]000@&

&&

:0 90]000@&

&&

&&

&&

lksuiqj esyk] 2024

&&

Jko.kh esyk 2024

lkaLd`frd
dk;ZØe

eankj egksRlo
2025

lksuiqj esyk 2024

Jko.kh esyk 2024

&&

&&

yksdxhr@yks
d u`R;

&&

&&

&&

jkT;Lrjh; d`f"k
;kaf=dj.k esyk ¼,xzks
fcgkj esyk½ 2023
lwQh egksRlo 2023

lkaLd`frd
dk;ZØe

:0 30]000@&
¼,xzks fcgkj
esyk½ 2023

&&
