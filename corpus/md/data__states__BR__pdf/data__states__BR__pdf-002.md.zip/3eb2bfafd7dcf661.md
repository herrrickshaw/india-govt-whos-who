---
doc_id: "3eb2bfafd7dcf661"
source_url: "https://pup.ac.in/UploadFile/2025/Feb/25-Feb-2025/MasterNotification/Notice%20inviting%20quotation%20for%20Post%20construction%20termite%20treatment.pdf"
ministry: "Patna University, Bihar"
title: "Download"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "6e4a45f01532f737"
---

<!-- page 1 -->

OFFICE OF THE UNIVERSITY ENGINEER

WORKS DEPARTMENT

PATNA UNIVERSITY, PATNA- 800 005
Email: puer@patnauniversity.ac.in
Website: www.pup.ac.in
Quotation No.:7 I2024-25
Date:22l62 12025
NOTICE INVITING QUOTATION
Sealed Quotations are invitedEMERGENT
in prescribed format for Post
construction Anti-termite treatment work in
Patna University. For detail terms
& conditions, please visit
the office of the
working days from 10:30 A.M. to 5:00 P.M. or obtain from
on any
Patna University website undersigned
www.pup.ac.in.
Designation of officer inviting quotation
University Engineer, Patna University, Patna
Last date of issue/download of Quotation Office
of The University Engineer Patna
University, Patna
document with Time and place
upto 5:00pm on ¢k.J.93../2025
Place, Time & Date of receiving of Ofice of the
University Engineer, Patna University, Patna
Quotation
Place, Time & Date of opening quotation
Sr.
No.
1

Particular

upto 3:00 pm one7..J03..12025
Office of the University Engineer, Patna University,
Patna
at 3:30 pm on2..e7.12025

Cost of quotation

Post construction Anti-termite
treatment work
in
Patna

document ()
1.250/

EMD ()
11,100/

Time of

completion

One month

University, Patna

TERMS &CONDITIONS:
1

Paper submitted with quotation:
Registration of Firm in Govt.of Bihar/C.P.W.D/ M.E.S. for appropriate category for Pest
Control or a member of Pest Management
Association (PMA).
(ü) GST & PAN
(ii)
(iv)

Experience -upto 50%of quoted rate.

Turnover-Audit Balance Sheet last three years (Turn over-double of quoted amount for
any one financial year)

2

(v) Return File of last three years
(a) Cost of quotation document is to be deposited in the shape of
D.D./Banker's cheque in favour
of "The University Engineer, Patna University, Patna" applicable
for all

(including MSME/NSIC registered agency)

quotationerlagencies

(b) Earnest money is to be deposited in the shape of D.D./ Banker's cheque in favour of The

University Engineer Patna University, Patna (including MSME/NSIC registered agency) which is

refunded after six months from date of completion of work without interest.
3.

(a) Completion of work: One month
(b) Termite Protection Warranty: 2 years from date of completion of work.

4.

Payment-100% against completion.

5.

The Bidder should inspect the site before filling in and submitting the quotation to get fully
acquainted with the scope of work as no claim whatsoever will be entertained for any alleged
ignorance thereof. Quotations must be submitted in original and without
making any additions,
alternations, and as per details given in other clauses given hereunder. The requisite details
shall
be filled in by the Bidder in the quotation document wherever
required.
Ihe agerncy should have experience of similar type of work at any Govemment organization or

6

Universities.

<!-- page 2 -->

7

The ENIQ document carn also be downloaded from the website www.pup.ac. in from intending
quotationer and will be submitted with cost of Quotation Paper in the form of Demand Draft in

favor of University Engineer. Quotation paper submitted without cost of Quotation Paper in the
form of demand draft will be sumhmarily rejected and the last date for downloading the quotation
document from the website is one day prior to the last day of receipt of quotation. ACcordingly, the
draft towards the quotation fee shall be dated one day prior to the last date of receipt of quotation.
8

The

sealed quotation should

also

be

sent through courierl/Registered/Speed Post.

Conditional quotation or quotations received after the due time and date shal

not be entertained

in any circumstances.

University Authority would not be responsible

for any delay or loss of the quotation documerit. The quotatiÚns will be opened in the

office of the undersigned in presence of any intending supplier or his/her authorized
representative who may wish to be present at the designated time and place. If the fixed
date tums out to be the holiday, the date of opening will be the next day.

At the time of opening of quotation only participant quotationer or his single authorized

representative with authority letter will be allowed to present.
10.

11.

The EMD shall be forfeited if the bidder withdraws his bid during the period of bid validity.

All disputes, what so ever shall be referred to the sole arbitration of The University Engineer

Patna University, Patna and his decision shall be final and binding on the agency.

12.

Allthe matters subject to the jurisdiction of Patna High Court.

13.

Bidders should submit details. in.the format given at Annexure-A and should
quote the rates in the fomat given at Annexure-B. Incomplete bids will summarily be rejected.

All corrections and alterations in the entries of quotation document will be signed in full by the

Bidder with date. No erasing or over-writings are permissible.
14.

The detaiis nay atso bë Seen at websitt vwv.pup.ac.in

15. Any changes w.r.t. this quotation will be notified through website.
16. The undersigned reserve the right to accept or reject any or all the quotation without assigning
any reasons.

University Engineer
Patna University, Patna
Date:2%.I02..J2025

Memo No.:/4S7UE
Copy to:

Finance Officer,
1. Financial Advisor, Patna University, Patna 2. Registrar, Patna University, Patna, 3. Incharge, Patna
Patna, 5,
Patna University, Patna, 4. Budget and Accounts Officer, Patna University,
in Patna University
document
quotation
University Computer Centre/l|T Cell for upload
Personal Assistant to
file.
6.
concern
on
taken
website(www.pup.ac.in). The approval of same has been
Patna University,
Enginger,
Vice Ch3ncellor, Pa'na University, Patna, 7. Er. R.K. Sinha, Assistan: University, Patna, 9. Mr.
Patna, 8. Er. C.B. Choudhary, Assistant Engineer (Site Incharge), Pana
Satyendra Kumar, UDC of Works Department, PatnaUniversity, Patna for

information.

University Engineer

Patna University, Patna
