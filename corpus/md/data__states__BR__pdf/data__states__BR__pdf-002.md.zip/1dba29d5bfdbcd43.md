---
doc_id: "1dba29d5bfdbcd43"
source_url: "https://fmiscwrdbihar.gov.in/fmis/tenders/NIQ_RTDASBKBDP_06072026.pdf"
ministry: "Flood Management Improvement Support Centre (FMISC), Bihar"
title: "NATIONAL COMPETITIVE BIDDING SHORT NOTICE INVITING QUOTATION ( Re-Tender )"
date: ""
pages: 4
method: "tesseract:hin+eng"
script: "LATIN"
needs_ocr: false
sha1: "d6d241284cf3a5c9"
---

<!-- page 1 -->

Office of the Joint Director
Flood Management Improvement Support Centre
2nd Floor, Block -A, Jal Sansadhan Bhawan, Anisabad, Patna - 800002
Email Address: fmiscbihar@gmail.com
Phone No. 062 - 2256999
NATIONAL COMPETITIVE BIDDING
SHORT NOTICE INVITING QUOTATION
(Through e-procurement mode only, website: https://eproc2.bihar.gov.in)
Re-Tender
NIQ NO.: व7/2026-275/2026/0 Dated-06/07/2026
NAME OF WORK Procurement of Services for Comprehensive Annual
Operation and Maintenance Contract of Real Time Data
Acquisition System (RTDAS) for the Kosi & Bagmati-
Adhwara Basins in Bihar, India
cH
PERIOD OF ONLINE AVAILABILITY From: - Date: 4/07/2026, Time 4:00 Hrs.
camer ||
https://eproc2. bihar.gov.in
TIME & DATE OF PRE-BID Date: 22 /07/2026, Time 5:00 Hrs.
CONFERENCE Venue - Conference Hall, Flood Management
Improvement Support Centre, 2™4 Floor, Block-A, Jal
Sansadhan Bhawan, Anisabad, Patna - 800002
Email Address: fmiscbihar@gmail.com
Phone No. 062 - 2256999
LAST DATE AND TIME FOR ONLINE Date: 29/07/2026, Time5:30 Hrs.
|
DATE AND TIME OF OPENING OF Date: 29/07/2026, Time 6:00 Hrs.
rE
TIME AND DATE OF OPENING OF Date will be announced after the finalization of technical
|
[7]
rH
[||
OFFICER INVITING BIDS Joint Director, Flood Management Improvement Support
Centre, 2"4 Floor, Block-A, Jal Sansadhan Bhawan,
Anisabad, Patna - 800002
Email Address: fmiscbihar@gmail.com
Phone No. 0622 - 2256999
te

<!-- page 2 -->

4

2. | Bidding will be conducted through National Competitive Bidding procedures. Any contractor registered
with the Central Government/ any State Government/ any PSU, or an agency of National repute may
participate in the Bid. However, registration with the Water Resources Department, Government of Bihar,
is required before the signing of contract. Bidders are advised to note the clauses on eligibility (Section I -
ITB Clause 3 & 4) and minimum Evaluation & Qualification Criteria (Section III - Evaluation & Qualification
Criteria) to qualify for the contract award.

3. | Joint Director, Flood Management Improvement Support Centre, Patna, invites the Procurement of
Services for Comprehensive Annual Operation & Maintenance of the RTDAS for the Kosi & Bagmati
- Adhwara Basins in Bihar, India in an electronic tendering system for prospective bidders under a two-
bid system.

Bidding documents are available online at https://eproc2.bihar.gov.in/from _4/07/2026 to
29/07/2026. Bids will be accepted in online mode only. While participating in the e-tender process, the
Bidder shall have to get themselves registered to get a user id, password, and digital signature. This will
enable them to access the website mentioned above for downloading/ participating in the e-tender process.

5, | Downloadable e-tender documents can only be uploaded on this website after properly filled out, including
copies of payment certificates and other documentation. Any addendum/corrigendum available on the
website must be downloaded and included, and the bidder is responsible for ensuring to do so. Before
uploading, the bidder must provide each scanned document's serial number to quickly locate the desired
document in the serial number/page number. All files must be uploaded in ZIP, JPEG, PDF, or Microsoft
Office (compatibility mode) formats. No claims will be considered if uploaded papers cannot download or
open, The bidder must be completely satisfied with the download capability and visibility of
scanned/uploaded documents. Furthermore, no claim will be heard if the bidders! internet service is
disrupted. Bidders are encouraged to submit their bids well in advance to minimise last-minute technical
difficulties.

The cost of the Bid Document (Non-refundable) paid through online mode i.e internet payment gateway
(credit/debit card), Net banking, NEFT/RTGS only.

7. | Submission of Original Documents: The bidders are required to separately submit (i) original payment

documents towards the cost of bid document; (ii) original bid security; and (iii) original affidavit
regarding correctness of information furnished with bid document, with the office of Joint Director, Flood
Management Improvement Support Centre, Patna payable at Patna, before the Bid submission deadline.
Bid security in the forms specified above or in the bidding document shall have to be valid for 45 days
beyond the validity of the bid. Any bid or modifications to the bid (including discount) received outside the
e-procurement system will not be considered.
A pre-bid meeting will be held on 22/07/2026, Time 5:00 Hrs., Venue - Conference Hall, Flood Management
Improvement Support Centre, 2" Floor, Block-A, Jal Sansadhan Bhawan, Anisabad, Patna - 800002 to
clarify the issues and to answer - questions on any matter that may be raised at that stage as stated in ITB
Clause 6.4 of ‘Instructions to Bidders’ of the bidding document. Bidders are advised to download the
bidding documents before the pre-bid to understand the scope of work under this contract for discussion
and clarification.

0] The bidder must be satisfied with the conditions and scenarios at the service performance/ delivery location,
the available resources, and related equipment, software, and others, i.e., conduct a physical survey of the
service performance/ delivery location. No claims will be entertained after the bid has been uploaded.

2] Other details can be seen in the bidding documents. The Employer shall not be held liable for any delays
due to system failure beyond its control. Even though the system will attempt to notify the bidders of any
bid updates, the Employer shall not be liable for any information not received by the bidder. The bidders
are responsible for verifying the website for the latest information related to the tender/ bid.

G

<!-- page 3 -->

3,| वगढ फ््रागालंब एव of the bid- of the bidders who are technically qualified/responsive will be opened
esr aes eal
4] Bids along with necessary enclosures must be uploaded to the web site http:// eproc2.bihar.gov.in and
first cover of the bids will be opened at the specified venue on the stipulated date and time, in the presence
of the bidders or their authorized representatives who wish to attend. If the office happens to be closed on
the date of opening of the bids as specified, the bids will be opened on the next working day at the same
time and venue.
5{ For any clarification regarding the e-tendering process,
Contact: e-tender Cell, Computer Cell, 2"¢ Floor, Sinchai Bhawan, Patna, Tel. No. 062-223524I or Help
Desk, M/22, Road No. 25, st Floor, bank of India Building, Sri Krishna Nagar, Patna, Tel. No. 062-2523006,
+9-75202864.
For any other clarification related to Bid,
Contact: Deputy Director -I, Flood Management Improvement Support Centre, 2" Floor, Block-A, Jal
Sansadhan Bhawan, Anisabad, Patna - 800002, Email Address: fmiscbihar@gmail.com, Phone No. 0622 -
2256999
6| For more information, bidders can visit the website:
०४०/ ५
Joint Director,
Flood Management Improvement Support Centre, Patna

<!-- page 4 -->
