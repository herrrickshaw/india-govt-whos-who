---
doc_id: "8ba1acd46aec66ce"
source_url: "https://cdn.s3waas.gov.in/s31bb91f73e9d31ea2830a5e73ce3ed328/uploads/2021/05/2021052784.pdf"
ministry: "Kishanganj"
title: "Lockdown Enforcement Order Dated 17052021"
date: ""
pages: 2
method: "pdftotext"
script: "LATIN"
needs_ocr: false
sha1: "0953c376b1632abb"
---

<!-- page 1 -->

-FlrtFt 06455-222535 (sFEr)

fl6lr s.6'r{

06456-222520 (JFIET
05456-222626 (JFlRr !F

fr,Fritl

"Tgrdzr]rdq,
fibYr{riq - Bsslo?

054s6 222530 (6ral.,
o6as6-z254so tdrqt. thFl

Grdr rnq:ftq vrr€r)

email: dn- kishaneani.bih@nic.in

olFls-rg +i6qvr d 3rc-trrFrd EE 6i M Ef' gd fiIgidq d grci.F szzrfro.
iaiqif 20.0a.2021 d a|{r fifdrii,fd dE-s r6qvr 6t FrqFd 6ri (ra iffi ersq qftr 3[tr4r
tFrri d fft(' gonil va€rfto ctrrsni 6t fr{
d efidA g[ -+ ffi qr fr+ w srq
'M lo?s/:fr., fr{i6 13.0s.2021 d a|{r Tfr
ffuiFd frqr rrqr tr g<' afl iFrsf{q d 3Tricr dtcifi
3Tricr d 3ritrro tylq+ ozd gv gr, alosrJ{ qtlt 3r{ft E-{i6 2s.0s.2021 TtF filHIFd fib-qr trql
tr go ig orqlds 3fleyr Frcio e?orfr.. ftt tF 22.04.2021 d artr drffi6 erat qt qno d
3rqtrr 61 trs ori d <rsrertortat w gft-s qqrEmrful / {d} qtl cfrfi-gk frrysqq ft C
qrs d-q d srer wrr g6nf/+{flIfu6 qfiern 6f 3q{ff 3TIAn A 3Trdt6 it 3rJcF{ o{ri ig
6'l rr$ tr S{: ffi
w gR-{ {{rEdlnd / Tdt olt ffifrgFh fr{i6 25.05.2021 d6
qfdfi'Ed sEctE'drfi
liFm .FI :m

cfrtftgtu sd

qairq (r4 q].rBd

cfrffgFgffiflqqrffi6I
nrq vfirc l'if

ffid.i{{

gF-s {d

-l

3

,fi ffis tcr{, aaqoddqg g6r6i1o €qq qsqr. qFr
q6nnt6dffi'ndr q{lftrddt,
dqf{€
16 .Frqtf,4, qFL fkrl iq 4lo-62046?5aa?
t4't92640
FFgI{ri.-r, 4io 9304?

+dfi Erffi,

€qFfi ri_dr dY6 :rrqr

lrfiqrr *6 d q:ils qd

frf'prl i-l 854442993{ | 947@$263

1lt ETF q{IF|qIT
€sttr 1|idr qi6 :rrqr ,fi 3rdt sw{, tlfr
qffi
?i{s!r a.EE,
dh d6 * qqrs Fi.fi 3{E6rS, €rdr
fffiq 9a9993993
*d6 T6
,fi swr tcrc, ffis
nq 3rE-{idr (H),
qtrF vd *6 dri{
ir
9a52580!'40
ao (&-6rr tl6r€
fkrl
dA E! 3 qft qi6 do

so3rofio ft-{Il?q tIFi, qrdrqrd

fikrl i.n 4)0-94306902'16
go3rofro ff-{q gqr{ @tqlq,

ftHr,l,tr qrll q)o-8?a9oa1211

qo3rofto 6IlF{t ?rq, qrdrind
l:krarq {p-a?s7?9492a

cr{D

,fi rrcrJd
trrrro nFi.lo, qo3rofio qlrf{ ?Iq, fiffi
r'
3 qr6. ni6 3 'ilff qFtor 6rd e'Ir{.
2rFr 41o 993128?a?1
ft{pr,
fhrl iq soo223558?

go:aofio--ffi rflR ?rq,n,

f fhrl{q FsK, eFdrs6 3rE_ditl
qr{"r 6d fr|Irtr,
fikr{ iq EI{r 4)o-e?08869350

3'qr& * dsr{r

f,kr{r|id 89a691s1s1

RI, frrlq dfu"r qo3r-fto vsrFsq- friir qr{q,
f re tratw ?r{
fiffiq qrlr dlo-995s2508?6
ftyF.i-r Id sft€ trt .naa'il fffid, qto 62059i8648
sdlrtfio iiffi qFi, jhr{ ri;
sqlF nor{ dt, dr.rdll f ?E .!qR. ffnc

fi? {Tr i?iF {s €rs,
drqTftr .i :l? d .|Fd *

fhrl,F, ab 826560a2

dE1 {IgiCrrgl tdr do aEn 3rd, fiilq
sindrflrsl irl liFtlrir, clo 9431s03354
'L
ic qndr {}.eror.!

q{qrqry14 'idt
10

11

12

13

?ffi4 qt.F d {dEzrlq
qlg tr6

3-qr.ft *6 t

.rFr 4lo ?9923242a3
6rTrrII,

Eo3rofio ilq tqrt ?rq, fulnrb
erFr clo-943122s39s

T{r{.F, F-dr ro3rofto 3rlaq {r<.r, a{ ftlq
f gtj qrg, d{{r E
.go6rqj!. jffi.n q\o

dffrr orqiirq,funrb{ !91232?5606

'fff {flifid). fitdn fiEfl

6tia.

so3roflo $rq

gde

f4 ardl €
qdd
.| n

1d.*

$F60 €

1.4 dtd {fi

gd rr

5d*
F4 drd -d

g@s

rJira *a
5ryq
F4 dfd ird

gdd

F4 drd ird

@*

1-o

"aA
gdd

tqR 3rrqrq

frkra?id qFn do-96611313?5

* Fr qfi qY6 tr €aq .Ecn qsrr. Aaqo qrq G do3roFo 3rs{4 gcR,
1affi clo-62o5419451
dti.. fiFl;r in 9934r?95051
3{F-d Eqr{, Fdr{6 !d{6, sw{oflo !F! qrFqF,
w qfl ni6 t drdr{ ,fi
CM), S3rr{.rfi .d., turi'in mfl xlo-a?sz9?8't16
qg6 sd
'i{f ft
8809022011
'iti

;;

g0iF0

-"

€

-dlsr

COV|D 19 OllDl R l ,r8e 1

14drdl{d

5d*

,

l

<!-- page 2 -->

/
t'

qi '1t,1, F thd qfl *l $d r tcR a) r-fi i.rdr.rj' FRl *oao *+r 1cc. Ax*s aar r + arA qd
{1r'! n ctaid4.fuI rtg s?s7rrt5
;* .*
,fi Ifi ecR, ql.trr Edr6. kr
dd;€ dr6 3 'filfi qira{r 6rstdq,
tur{'k
q_Jl

,

8013324523

*oii r'qflI'n Ynftq {qrl,

trft.idr,

grr. tfud 6i&J d L rr.F qcsw, fuFriq 9304134259
rrrrFiir .i6 {} &aAe"l dt rt;r a,Ir. 'tlnfi, ftiis 6dl!r

"I**

ltc :-

t*I? in 4i0 94?oso??50 ql d
ffAfrgFtst qlo 9??1?15633
llo3rcfio efu<I.i< ?rCI ?ndr.fla

liffi

| rarrt+rn.'mn#
1. cfaft{f <rsrEmrfi/ 5ftw q(rEdrfr/ 5ft{ {q 3{qi 3rri cfiFqffi erd rrq sF-se dri +1
dMd-cficrd 3f,1qrd{ qfr€dd ard:} dqr qfd€n 6r iFd
dq{ ds 6{i €(' 3qf€
d rt{|E q(IEr6rr1, ftdl slq{r Fqtr{. €Fsr{tln
cfrnfi sc"rfl oa.oo {d do :rqn
zoorererar

fia

dlo-9s34e29?16

rv

(94?298s13?) ol 3q.{61 iF{rdrl I

3q{ffi cfrF{€ <EsrEdrfli 5Frff wIEmrS aI{I 3tqi cfftF-qf{ elcT q{ dGFrdr 6
(ra gdrdt/-q{srtrs cFrBr{f 6t gs orut*a aI{I frtl-d drqlqt
BIYI 3rrRqd *oz qrs'fi
gzudo, G-<io 20.04.2o2't d mAi n rlcrct mrrn qr rdr t $EsI TS? * ti{trd 6rd q*iqvl
lr{ 3r5rrsvr ftqiE d q(rEr6r$ qFF{d rFti :-

(i) f ?rFK 3Trdc. ft'dT t3fj1 qqrEmfl, ft}tY|{rt'T 98013e2e?2(qPFre o' d qHq' 01 d 04 ?16 qfrfigfi €aI i5T )
(ii) i. ri$l 3Trd{, afrq 3q frqld-dt. fibs|{rfuI 8?5?8e0e8o (ctrFl€ '6'd 4qi6 05 d 1o 16 cfrfi-gd sd 6r )
tiii) 4}o s{"Fr6 316T{, rlff qqR 3q sc|{di. FhiEH'iq 854441234119102442?17qfrfiqfr
sd 6I )
(r{RFre '6'd 6ci6 n d 14 irdF
(iv) ,fi 3rr+ gqn qm, 3rTitd dr €l.F|qd ltqRur [qlo, Fl'c|,m,q 1oo4o7o22o
(qtrft€ '6' d 6qFF 15 d 17 T6 qfrfi-9ft Md 6I )
3r!d'r6 :- {g orqtqq 6r

8421fr0, f-ii6 11.04.202r,

arqi6 s22lflo,
frq Elrqi.6 970/S.

20.o4,2021
22,O4.2021

ftffiql

CTdFF::
qrftfftFt ;:

cfrfrFt::

srqi6 [xt-os/2020-21 1 .. I.n.SN..rS.. ffiq, ffi6 .1.f+\|JS.1.2021
s,n cfiFrq-tr s"ErErors,gdn\elE-dTfl 6i T'm{ l"i 3r1q'#d !Sa.l €ff 9rqug-Fl-6rs qqrtrfr$/ glfi 3iq-d 3Tffi/ Efr sr{lEqfsff $.fr. e-t{ffi.
fuf{'iq ftdr 4'l qr{{ u+ rlrrr+{ nRct
ordqrffi qdrEr6r$. qtr{ qEsE, fihnrioi mrdqw+ qEmrfr, q'lz riEITd' {dErifi rEi
arEEuriq dr

cfrftfit::
qfriaft::
qrd|ftR::

ctrfrE ::
qfdiaB ,,
crdfrFt ::
cfAfdfl :i

efrfrR ::

q{irf tEi 3rqsd 6rdr* lF:d I

.ilir"ir cEfrdrfr, thEr{rrq/3r5{s.d gft-s q{Emrs' Fbsn'iw tai TFr{r{ !q
srrqsq-6 Frsfti niqd r
qlr$ qqrErdrfl . trdr 3{rqd| giitf{, FbeFrFi +l qr+r*
w 3lrss+ 6rqtd iFld
'q{
sqd cqrEmrfi/trdr 3il[ffi
ftdr rq|{d sq Tr{r{dl, fulrtb/ Fidr
{<rEmfl/r|6rFi[*,, ft-en JdrI dR. fu|{rid +] qr<r{ oti snr*+ 6rqH nF-d
trdr qtr{6{ qqrEmr$, fibslrridisdrd. qq fiqq fthr{rid oi q*<rd ('o sng{o
6rqld iF-d I
3{q? flq|Fdf . fur{ridEq E-om s{rgff, €*ratiq o} {q+r* lti s{qsrd 6|qlt iRd I
gft-{ TdrFStrcF. EFidfi c*t, nFfet o} wrce q++nf
qq-sd. {itdfi ol st?z qfirrf l
3{rgff,
3r{r g@
,rFFh rT, trdr", {.{r of fl{t qrfl*|
I

t

tffiql
COV n.19 OltDlR l'jaBe 2
